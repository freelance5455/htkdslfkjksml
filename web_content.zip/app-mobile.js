(function(){
'use strict';

/* ------------------------------------------------------------------
   Instalação PWA / atalho no telemóvel

   O evento beforeinstallprompt só é disponibilizado pelo navegador em
   contexto seguro (HTTPS ou localhost) e depois de os critérios de PWA
   serem cumpridos. Guardamos o evento enquanto ele existir; quando não
   existe, o mesmo botão apresenta o caminho manual correto para Android,
   iOS ou navegador de computador, sem deixar a instalação "quebrar".
   ------------------------------------------------------------------ */
let _deferredInstallPrompt = null;
let _installWasCompleted = false;

function isAppStandalone(){
  try{
    return !!(
      (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
      window.navigator.standalone === true
    );
  }catch(_){ return false; }
}

function isAppleMobile(){
  return /iPad|iPhone|iPod/.test(navigator.userAgent || '') ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

function isAndroidMobile(){
  return /Android/i.test(navigator.userAgent || '');
}

function setInstallStatus(type, message){
  const status = document.getElementById('prefsInstallStatus');
  if(!status) return;
  status.textContent = message || '';
  status.className = 'prefs-status prefs-status-' + (type || 'info');
  status.hidden = !message;
}

function refreshInstallButton(){
  const button = document.getElementById('prefsBtnInstall');
  if(!button) return;
  const standalone = isAppStandalone() || _installWasCompleted;
  button.disabled = false;
  button.textContent = standalone
    ? 'App já instalado'
    : (_deferredInstallPrompt ? 'Instalar app' : 'Instalar app / criar atalho');
  button.setAttribute('aria-label', standalone ? 'App já instalado' : 'Instalar app ou criar atalho');
  if(standalone) button.classList.add('is-installed');
  else button.classList.remove('is-installed');
}

async function requestAppInstall(){
  refreshInstallButton();
  if(isAppStandalone() || _installWasCompleted){
    setInstallStatus('success', 'O app já está instalado e aberto como aplicação.');
    return;
  }

  if(_deferredInstallPrompt){
    const promptEvent = _deferredInstallPrompt;
    _deferredInstallPrompt = null;
    refreshInstallButton();
    try{
      await promptEvent.prompt();
      const choice = await promptEvent.userChoice;
      if(choice && choice.outcome === 'accepted'){
        _installWasCompleted = true;
        setInstallStatus('success', 'Instalação iniciada. O ícone ficará disponível no ecrã principal.');
      }else{
        setInstallStatus('info', 'Instalação cancelada. Pode tentar novamente quando quiser.');
      }
    }catch(_){
      setInstallStatus('error', 'O navegador não conseguiu iniciar a instalação. Use o menu do navegador para criar o atalho.');
    }finally{
      refreshInstallButton();
    }
    return;
  }

  if(!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1'){
    setInstallStatus('warning', 'A instalação direta exige HTTPS ou localhost. Neste endereço de rede, use o menu do navegador para criar um atalho.');
    return;
  }
  if(isAppleMobile()){
    setInstallStatus('info', 'No Safari, toque em Partilhar e depois em “Adicionar ao ecrã principal”.');
    return;
  }
  if(isAndroidMobile()){
    setInstallStatus('info', 'No Chrome, abra ⋮ e escolha “Instalar aplicação” ou “Adicionar ao ecrã principal”.');
    return;
  }
  setInstallStatus('info', 'Abra este endereço num navegador compatível e use o menu “Instalar” ou “Adicionar ao ecrã principal”.');
}

function initInstallability(){
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    _deferredInstallPrompt = event;
    refreshInstallButton();
  });
  window.addEventListener('appinstalled', () => {
    _installWasCompleted = true;
    _deferredInstallPrompt = null;
    refreshInstallButton();
    setInstallStatus('success', 'App instalado com sucesso no ecrã principal.');
  });
  const button = document.getElementById('prefsBtnInstall');
  if(button && !button.__installBound){
    button.__installBound = true;
    button.addEventListener('click', requestAppInstall);
  }
  refreshInstallButton();
}

initInstallability();

/* ------------------------------------------------------------------
   Cover fallback: quando o CDN original bloqueia (referrer/CORS/hot-
   link), tenta uma vez via proxy público images.weserv.nl antes de
   esconder o <img>. Suporta HTTPS e HTTP.
   ------------------------------------------------------------------ */
window.__coverFallback = function(img){
  try {
    if(!img || img.dataset.fbTried === '1'){
      img.style.display = 'none';
      return;
    }
    img.dataset.fbTried = '1';
    const orig = img.getAttribute('data-orig-src') || img.src;
    if(!orig || /images\.weserv\.nl/.test(orig)){
      img.style.display = 'none';
      return;
    }
    img.removeAttribute('crossorigin');
    img.removeAttribute('referrerpolicy');
    const clean = orig.replace(/^https?:\/\//, '');
    img.src = 'https://images.weserv.nl/?url=' + encodeURIComponent(clean);
  } catch(_) {
    try { img.style.display = 'none'; } catch(__){}
  }
};

/* ------------------------------------------------------------------
   Capa padrão (placeholder): usada quando o registro é salvo sem
   nenhuma imagem própria (nem enviada, nem colada por URL, nem
   encontrada na busca online). É um SVG embutido — não depende de
   rede nem de conexão — desenhado de propósito para destoar de uma
   capa real (borda tracejada, ícone de imagem "quebrada", texto
   "SEM CAPA"), para ficar óbvio ao ver o item que a capa precisa
   ser trocada depois.
   ------------------------------------------------------------------ */
const DEFAULT_COVER_PLACEHOLDER = 'data:image/svg+xml,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600">' +
  '<rect width="400" height="600" fill="#232838"/>' +
  '<rect x="14" y="14" width="372" height="572" rx="14" fill="none" stroke="#e8b240" stroke-width="4" stroke-dasharray="14 10"/>' +
  '<g fill="none" stroke="#e8b240" stroke-width="8" stroke-linecap="round" stroke-linejoin="round">' +
  '<rect x="130" y="195" width="140" height="110" rx="10"/>' +
  '<circle cx="170" cy="230" r="14"/>' +
  '<path d="M130 285 L180 240 L220 275 L245 255 L270 285"/>' +
  '</g>' +
  '<line x1="140" y1="180" x2="260" y2="320" stroke="#c7654b" stroke-width="9" stroke-linecap="round"/>' +
  '<text x="200" y="400" text-anchor="middle" font-family="IBM Plex Sans,sans-serif" font-size="34" font-weight="700" fill="#8ae3d7">SEM CAPA</text>' +
  '<text x="200" y="438" text-anchor="middle" font-family="IBM Plex Sans,sans-serif" font-size="20" fill="#9aa1b4">Toque para trocar</text>' +
  '</svg>'
);


/* -----------------------------------------------------------------------
   BUGFIX ("clicar no campo recua uma página"): quando o teclado virtual
   abre (ou a caixa de sugestões de gêneros muda para faixa fixa acima do
   teclado), o layout do modal reflui e encolhe. Se o toque acontece durante
   esse reflow, o alvo do evento 'click' pode se resolver para o
   .modal-backdrop em vez do input original, fechando o modal (efeito de
   "voltar uma página"). A solução é exigir que o pointerdown TAMBÉM tenha
   ocorrido sobre o backdrop antes de aceitar o clique como "clique fora".
   ----------------------------------------------------------------------- */
let _lastPointerDownTarget = null;
document.addEventListener('pointerdown', (e) => { _lastPointerDownTarget = e.target; }, true);
function _backdropTapHandler(closeFn){
  return function(e){
    if(e.currentTarget !== e.target) return;                 // clique veio de um filho
    if(_lastPointerDownTarget !== e.currentTarget) return;   // gesto começou noutro elemento
    closeFn();
  };
}
/* Os modais principais não são dispensáveis pelo fundo. Este bloqueio em
   captura permanece activo mesmo que algum módulo futuro acrescente um
   listener genérico ao document ou ao próprio backdrop. */
const NON_DISMISSIBLE_BACKDROPS = new Set(['prefsModalBackdrop','profileModalBackdrop','formModalBackdrop']);
function blockBackdropDismiss(e){
  const target = e.target;
  if(!target || target.nodeType !== 1) return;
  if(!NON_DISMISSIBLE_BACKDROPS.has(target.id)) return;
  e.preventDefault();
  e.stopImmediatePropagation();
}
document.addEventListener('pointerdown', blockBackdropDismiss, true);
document.addEventListener('click', blockBackdropDismiss, true);

// Mantém o zoom nativo do navegador disponível. A meta viewport usa escala
// normal, e os gestos de pinça/duplo toque não são cancelados pelo documento.

/* Desfoque individual das capas (só no modo Cartões). Cada obra tem o seu
   próprio olho; a preferência é só visual e não altera nenhum dado. */
function isCapaDesfocada(id){
  const key = String(id == null ? '' : id);
  if(!key || !Array.isArray(state.capasDesfocadasIds) ||
     !state.capasDesfocadasIds.some(savedId => String(savedId) === key)) return false;
  return !Array.isArray(state.capasReveladasPeloBotaoIds) ||
    !state.capasReveladasPeloBotaoIds.some(savedId => String(savedId) === key);
}
function toggleCapaDesfocada(id){
  if(!id) return;
  const key = String(id);
  state.capasDesfocadasIds = Array.isArray(state.capasDesfocadasIds)
    ? Array.from(new Set(state.capasDesfocadasIds.filter(savedId => savedId != null && String(savedId)).map(String)))
    : [];
  const idx = state.capasDesfocadasIds.indexOf(key);
  if(isCapaDesfocada(key)){
    if(idx >= 0) state.capasDesfocadasIds.splice(idx, 1);
  }else if(idx < 0){
    state.capasDesfocadasIds.push(key);
  }
  state.capasReveladasPeloBotaoIds = Array.isArray(state.capasReveladasPeloBotaoIds)
    ? state.capasReveladasPeloBotaoIds.filter(savedId => String(savedId) !== key)
    : [];
  const on = isCapaDesfocada(id);
  document.querySelectorAll(`[data-card-id="${id}"], [data-obra-id="${id}"]`).forEach(host => {
    host.classList.toggle('is-capa-desfocada', on);
    const btn = host.querySelector('.cover-blur-btn');
    if(btn){
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-pressed', String(on));
      btn.textContent = on ? '🙈' : '👁';
    }
  });
  persistCoverBlurStateImmediately();
  persistUiStateImmediately();
  syncToggleAllCoverBlurButton();
}
function syncToggleAllCoverBlurButton(){
  const button = document.getElementById('btnToggleAllCoverBlur');
  if(!button) return;
  const hasPendingRestore = Array.isArray(state.capasReveladasPeloBotaoIds) &&
    state.capasReveladasPeloBotaoIds.length > 0;
  const hasBlurredCovers = state.entries.some(entry => isCapaDesfocada(entry.id));
  const label = hasPendingRestore
    ? 'Reofuscar capas'
    : hasBlurredCovers ? 'Revelar capas' : 'Sem capas ofuscadas';
  button.disabled = !hasPendingRestore && !hasBlurredCovers;
  button.title = hasPendingRestore
    ? 'Ofuscar novamente apenas as capas que este botão revelou'
    : hasBlurredCovers
      ? 'Revelar apenas as capas ofuscadas manualmente'
      : 'Nenhuma obra está ofuscada manualmente';
  button.setAttribute('aria-label', button.title);
  button.innerHTML = `<span aria-hidden="true">${hasPendingRestore ? '🙈' : '👁'}</span> ${label}`;
}
function toggleAllCoverBlur(){
  const pendingIds = Array.isArray(state.capasReveladasPeloBotaoIds)
    ? normalizeCoverBlurIds(state.capasReveladasPeloBotaoIds)
    : [];
  if(pendingIds.length){
    const manuallyBlurredIds = new Set(normalizeCoverBlurIds(state.capasDesfocadasIds));
    state.capasReveladasPeloBotaoIds = [];
    // Só restaura o desfoque das obras que este botão revelou e que ainda
    // continuam manualmente marcadas como ofuscadas.
    state.capasDesfocadasIds = normalizeCoverBlurIds(state.capasDesfocadasIds);
    pendingIds.forEach(id => {
      if(manuallyBlurredIds.has(id) && state.entries.some(entry => String(entry.id) === id) &&
         !state.capasDesfocadasIds.includes(id)){
        state.capasDesfocadasIds.push(id);
      }
    });
  }else{
    const manuallyBlurredIds = normalizeCoverBlurIds(state.capasDesfocadasIds)
      .filter(id => state.entries.some(entry => String(entry.id) === id) && isCapaDesfocada(id));
    if(!manuallyBlurredIds.length) return;
    state.capasReveladasPeloBotaoIds = manuallyBlurredIds;
  }

  document.querySelectorAll('[data-card-id], [data-obra-id]').forEach(host => {
    const id = host.getAttribute('data-card-id') || host.getAttribute('data-obra-id');
    if(!id) return;
    const on = isCapaDesfocada(id);
    host.classList.toggle('is-capa-desfocada', on);
    const button = host.querySelector('.cover-blur-btn');
    if(button){
      button.classList.toggle('is-on', on);
      button.setAttribute('aria-pressed', String(on));
      button.textContent = on ? '🙈' : '👁';
    }
  });
  syncToggleAllCoverBlurButton();
  persistCoverBlurStateImmediately();
  persistUiStateImmediately();
}
document.addEventListener('click', (ev) => {
  const btn = ev.target && ev.target.closest ? ev.target.closest('.cover-blur-btn') : null;
  if(!btn) return;
  ev.preventDefault();
  ev.stopPropagation();
  const host = btn.closest('[data-card-id], [data-obra-id]');
  const id = host ? (host.getAttribute('data-card-id') || host.getAttribute('data-obra-id')) : null;
  toggleCapaDesfocada(id);
}, true);

const STORAGE_KEY = 'acervo-entries-v2';
const LISTS_STORAGE_KEY = 'acervo-listas-v1';
const ONLINE_CACHE_KEY = 'acervo-online-cache-v1';
const APP_STATE_STORAGE_KEY = 'acervo-ui-state-v1';
const COVER_BLUR_STORAGE_KEY = 'acervo-capas-desfocadas-v1';
const EXPORT_SEQUENCE_KEY = 'acervo-json-export-sequence-v1';
const EXPORT_LAST_KEY = 'acervo-last-export-at-v1';
const BACKUP_REMINDER_LAST_SHOWN_KEY = 'acervo-backup-reminder-last-shown-v1';
const BACKUP_REMINDER_INTERVAL_DAYS = 14;   // avisa se o último export foi há mais de 14 dias
const BACKUP_REMINDER_COOLDOWN_DAYS = 7;    // não repete o aviso antes de 7 dias
const PREFS_STORAGE_KEY = 'acervo-prefs-v1';
const ACCOUNT_SECURITY_DISABLED_KEY = 'acervo-seguranca-desativada-v1';
const ACCOUNT_STORAGE_KEY = 'acervo-conta-v1'; // legado (conta única) — mantido só para migração
const ACCOUNTS_STORAGE_KEY = 'acervo-contas-v1';
const ACTIVE_ACCOUNT_KEY = 'acervo-conta-ativa-v1';
const PIN_HASH_KEY = 'acervo-pin-hash-v1';
const SESSION_UNLOCKED_KEY = 'acervo-unlocked-v1';
const PROFILE_STORAGE_KEY = 'acervo-perfil-v1';
// Cada conta tem o seu próprio acervo (obras, listas, histórico e perfil):
// as chaves acima são a "base" e nsKey() acrescenta o id da conta ativa,
// para que o acervo de uma conta nunca apareça ao entrar com outra.
function nsKey(base){
  const id = (typeof getActiveAccountId === 'function') ? getActiveAccountId() : null;
  return id ? (base + '::' + id) : base;
}
const IDB_NAME = 'acervo-pessoal-db';
const IDB_STORE = 'kv';
const LOCAL_STORAGE_MIRROR_LIMIT = 1800000;
const REPORT_COVER_CACHE_LIMIT = 100000;
const JSON_REPORT_COVER_MAX_WIDTH = 360;
const JSON_REPORT_COVER_JPEG_QUALITY = 0.62;
const CLAUDE_STORAGE_AVAILABLE = (typeof window !== 'undefined') && !!window.storage && typeof window.storage.get === 'function';
let LOCAL_STORAGE_AVAILABLE = false;
try{
  if(typeof window !== 'undefined' && window.localStorage){
    const testKey = '__acervo_storage_test__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    LOCAL_STORAGE_AVAILABLE = true;
  }
}catch(e){ LOCAL_STORAGE_AVAILABLE = false; }

const CATEGORY_META = {
  anime:   {label:'Anime',   plural:'Animes',   icon:'i-anime',  color:'var(--c-anime)'},
  serie:   {label:'Série',   plural:'Séries',   icon:'i-anime',  color:'var(--c-serie)'},
  desenho: {label:'Desenho', plural:'Desenhos', icon:'i-anime',  color:'var(--c-desenho)'},
  filme:   {label:'Filme',   plural:'Filmes',   icon:'i-filme',  color:'var(--c-filme)'},
  manga:   {label:'Mangá',   plural:'Mangás',   icon:'i-manga',  color:'var(--c-manga)'},
  manhua:  {label:'Manhua',  plural:'Manhuas',  icon:'i-manhua', color:'var(--c-manhua)'},
  manhwa:  {label:'Manhwa',  plural:'Manhwas',  icon:'i-manhwa', color:'var(--c-manhwa)'},
  novel:   {label:'Novel',   plural:'Novels',   icon:'i-novel',  color:'var(--c-novel)'},
  livro:   {label:'Livro',   plural:'Livros',   icon:'i-livro',  color:'var(--c-livro)'}
};
// Subcategorias exclusivas de "filme" — cada uma tem seu próprio espaço na navegação.
const FILME_SUBCATEGORIAS = ['cinema','desenho','anime'];
const FILME_SUBCAT_META = {
  cinema:  {label:'Cinema',  short:'C', nome:'Cinema',  plural:'Cinema',  match:'cinema',  color:'#d94b3a'},
  desenho: {label:'Desenho', short:'D', nome:'Desenho', plural:'Desenho', match:'desenho', color:'#e8a13d'},
  anime:   {label:'Anime',   short:'A', nome:'Anime',   plural:'Anime',   match:'anime',   color:'#b8497a'}
};
// Subcategorias exclusivas de "novel" — espelham as opções do campo tipo_novel.
const NOVEL_SUBCATEGORIAS = ['light','web','classica'];
const NOVEL_SUBCAT_META = {
  light:    {label:'Light Novel',    short:'L', nome:'Light Novel',    plural:'Light Novel',    match:'light novel', color:'#c1d63a'},
  web:      {label:'Web Novel',      short:'W', nome:'Web Novel',      plural:'Web Novel',      match:'web novel',   color:'#3f7a4a'},
  classica: {label:'Novel Clássica', short:'N', nome:'Novel Clássica', plural:'Novel Clássica', match:'novel clássica', matchAlias:['novel','classica','clássica'], color:'#4fb0a0'}
};
function listaCategoriaLabel(categoria){
  const value = String(categoria || '').trim();
  if(!value) return 'Categoria não definida';
  const [base, sub] = value.split(':');
  if(base === 'filme' && sub && FILME_SUBCAT_META[sub]){
    return `${CATEGORY_META.filme.label} (${FILME_SUBCAT_META[sub].label})`;
  }
  if(base === 'novel' && sub && NOVEL_SUBCAT_META[sub]){
    return `${CATEGORY_META.novel.label} (${NOVEL_SUBCAT_META[sub].label})`;
  }
  return CATEGORY_META[value]?.plural || CATEGORY_META[base]?.plural || value;
}
function novelSubMatches(meta, tipo){
  if(!meta) return false;
  const t = String(tipo||'').toLowerCase().trim();
  if(!t) return false;
  if(t === meta.match) return true;
  return Array.isArray(meta.matchAlias) && meta.matchAlias.includes(t);
}
// Categorias com estrutura de temporadas/episódios (anime já tem OVAs/extras,
// serie/desenho reutilizam o builder de temporadas mas sem OVAs).
const CATEGORIAS_COM_TEMPORADAS = ['anime','serie','desenho'];
const CATEGORY_ORDER = ['anime','serie','desenho','filme','manga','manhua','manhwa','novel','livro'];

// Categorias "parecidas" entre si — ao trocar a categoria do formulário entre
// membros da mesma família, o progresso já preenchido (capítulos/volumes/
// temporadas) é mantido em vez de ser zerado. Só reseta o progresso quando a
// troca é para uma família diferente (ex: de "manga" para "anime").
const CATEGORIA_FAMILIA = {
  manga:'quadrinhos', manhua:'quadrinhos', manhwa:'quadrinhos',
  novel:'texto', livro:'texto',
  filme:'filme',
  anime:'audiovisual', desenho:'audiovisual', serie:'audiovisual'
};
function mesmaFamiliaCategoria(a, b){
  return !!a && !!b && !!CATEGORIA_FAMILIA[a] && CATEGORIA_FAMILIA[a] === CATEGORIA_FAMILIA[b];
}

const STATUS_ORDER = ['pretendo_ver','em_andamento','pausado','abandonado','concluido'];
const STATUS_META = {
  pretendo_ver: {label:'Pretendo Ver', color:'var(--s-pretendo)'},
  em_andamento: {label:'Em Andamento', color:'var(--s-andamento)'},
  pausado:      {label:'Pausado',      color:'var(--s-pausado)'},
  abandonado:   {label:'Abandonado',   color:'var(--s-abandonado)'},
  concluido:    {label:'Concluído',    color:'var(--s-concluido)'}
};
function statusLabel(s){ return (STATUS_META[s]||{}).label || s; }
function statusColor(s){ return (STATUS_META[s]||{}).color || 'var(--text-faint)'; }
function statusOptionsHtml(selected){
  const sorted = STATUS_ORDER.slice().sort((a,b) => statusLabel(a).localeCompare(statusLabel(b), 'pt-BR'));
  return sorted.map(s => `<option value="${s}" ${s===selected?'selected':''}>${statusLabel(s)}</option>`).join('');
}
function statusOptionsHtmlNoPretendo(selected){
  const sorted = STATUS_ORDER.filter(s => s !== 'pretendo_ver').sort((a,b) => statusLabel(a).localeCompare(statusLabel(b), 'pt-BR'));
  return sorted.map(s => `<option value="${s}" ${s===selected?'selected':''}>${statusLabel(s)}</option>`).join('');
}

// Status OFICIAL da obra (produção/publicação original) — independente do status
// pessoal de acompanhamento acima. Todas as categorias usam este campo, com
// exceção de filme, que representa um lançamento único.
const CATEGORIAS_COM_STATUS_OFICIAL = CATEGORY_ORDER.filter(categoria => categoria !== 'filme');
const OFFICIAL_STATUS_ORDER = ['em_andamento','hiato','concluido','cancelado','desconhecido'];
// A chave guardada 'em_andamento' mantém-se (dados existentes e backups continuam
// válidos); só o texto mostrado ao utilizador passa a ser "Em lançamento".
const OFFICIAL_STATUS_META = {
  em_andamento: {label:'Em lançamento', color:'var(--os-andamento)'},
  hiato:        {label:'Hiato',         color:'var(--os-hiato)'},
  concluido:    {label:'Concluído',     color:'var(--os-concluido)'},
  cancelado:    {label:'Cancelado',     color:'var(--os-cancelado)'},
  desconhecido: {label:'Desconhecido',  color:'var(--os-desconhecido)'}
};
function temStatusOficial(categoria){ return CATEGORIAS_COM_STATUS_OFICIAL.includes(categoria); }
function officialStatusLabel(s){ return (OFFICIAL_STATUS_META[s]||{}).label || ''; }
function statusCardLabel(s){
  const labels = {pretendo_ver:'Pretendo Ver', em_andamento:'Em andamento', pausado:'Pausado', abandonado:'Abandonado', concluido:'Concluído'};
  return labels[s] || statusLabel(s);
}
function officialStatusCardLabel(s){
  const labels = {em_andamento:'Em lançamento', hiato:'Hiato', concluido:'Concluído', cancelado:'Cancelado', desconhecido:'Desconhecido'};
  return labels[s] || officialStatusLabel(s);
}
function officialStatusColor(s){ return (OFFICIAL_STATUS_META[s]||{}).color || 'var(--text-faint)'; }
function officialStatusOptionsHtml(selected){
  const sorted = OFFICIAL_STATUS_ORDER.slice().sort((a,b) => officialStatusLabel(a).localeCompare(officialStatusLabel(b), 'pt-BR'));
  return `<option value="" ${!selected?'selected':''}>Não definido</option>` +
    sorted.map(s => `<option value="${s}" ${s===selected?'selected':''}>${officialStatusLabel(s)}</option>`).join('');
}

const BONUS_FIELDS = {
  anime:  [],
  serie:  [],
  desenho:[],
  filme:  [
    {key:'subcategoria', label:'Subcategoria', type:'select', options:['Cinema','Desenho','Anime'], primary:true},
    {key:'duracao_min', label:'Duração (minutos)', type:'number', min:0, placeholder:'ex: 125'}
  ],
  manga:  [],
  manhua: [],
  manhwa: [],
  novel:  [{key:'tipo_novel', label:'Subcategoria', type:'select', options:['Light Novel','Web Novel','Novel Clássica'], primary:true}],
  livro:  [
    {key:'autor', label:'Autor', type:'text', placeholder:'ex: Machado de Assis'},
    {key:'editora', label:'Editora', type:'text', placeholder:'ex: Companhia das Letras'},
    {key:'paginas_total', label:'Total de páginas', type:'number', min:1, placeholder:'ex: 320'}
  ]
};

let state = {
  entries: [],
  view: 'lista',
  categoriaAtiva: 'todos',
  filmeSubAtivo: 'todos',
  novelSubAtivo: 'todos',
  busca: '',
  filtroStatus: 'todos',
  filtroStatusOficial: 'todos',
  filtroTituloInicio: 'todos',
  filtroGenero: 'todos',
  notaMinima: 0,
  favoritosOnly: false,
  favoritosCategoria: 'todos',
  favoritosStatus: 'todos',
  favoritosOrdenacao: 'recente',
  favoritosViewMode: 'cards',
  filtroInacabadas: false,
  filtroSemStatusOficial: false,
  ordenacao: 'recente',
  obraViewMode: 'cards',
  listasViewMode: 'cards',
  listaObrasViewMode: 'rows',
  capasDesfocadasIds: [],
  capasReveladasPeloBotaoIds: [],
  editId: null,
  tags: [],
  builder: null,
  cover: {base64:null, url:''},
  listas: [],
  listaAtivaId: null,
  selectionMode: false,
  selectedIds: new Set(),
  listaDetalheSelectedIds: new Set(),
  selectedObraIdsForLista: new Set(),
  activitySelectionMode: false,
  selectedActivityIds: new Set(),
  pickerSelectedIds: new Set(),
  pickerBusca: '',
  obraDetalheId: null,
  listasSearchTerm: '',
  listaDetalheSearchTerm: '',
  formUserChangedCategory: false,
  historico: [],
  atividades: [],
  activityFilters: {
    categoria: 'todos',
    dataInicio: '',
    dataFim: '',
    obra: ''
  },
  activitySnapshot: null,
  lastMetadataResults: []
};
const HISTORY_STORAGE_KEY = 'acervo_historico_v1';
const HISTORY_LIMIT = 24;
const ACTIVITY_STORAGE_KEY = 'acervo_atividades_v1';
const ACTIVITY_SNAPSHOT_STORAGE_KEY = 'acervo_atividade_snapshot_v1';
const ACTIVITY_LIMIT = 500;
let activitySnapshotWarningShown = false;
const pendingActivitySnapshotWrites = new Map();
const activitySnapshotAccountsBeingRemoved = new Set();
function loadHistorico(){
  if(!LOCAL_STORAGE_AVAILABLE) return;
  try{
    const raw = window.localStorage.getItem(nsKey(HISTORY_STORAGE_KEY));
    if(raw){
      const arr = JSON.parse(raw);
      if(Array.isArray(arr)) state.historico = arr.slice(0, HISTORY_LIMIT);
    }
  }catch(_){}
}
function saveHistorico(){
  if(!LOCAL_STORAGE_AVAILABLE) return;
  try{ window.localStorage.setItem(nsKey(HISTORY_STORAGE_KEY), JSON.stringify(state.historico.slice(0, HISTORY_LIMIT))); }catch(_){}
}
function pushHistorico(id){
  if(!id) return;
  const prev = (state.historico||[])[0];
  state.historico = [id].concat((state.historico||[]).filter(x => x !== id)).slice(0, HISTORY_LIMIT);
  saveHistorico();
  if(prev !== id){ try{ renderSidebar(); }catch(_){} }
}
function loadAtividades(){
  state.atividades = [];
  if(!LOCAL_STORAGE_AVAILABLE) return;
  try{
    const raw = window.localStorage.getItem(nsKey(ACTIVITY_STORAGE_KEY));
    if(!raw) return;
    const arr = JSON.parse(raw);
    if(Array.isArray(arr)){
      state.atividades = arr.filter(item => item && typeof item === 'object' && item.timestamp)
        .map(item => item.snapshotStatus === 'saving' ? Object.assign({}, item, {snapshotStatus:'ready'}) : item)
        .slice(0, ACTIVITY_LIMIT);
    }
  }catch(_){}
}
function saveAtividades(){
  if(!LOCAL_STORAGE_AVAILABLE) return;
  const accountId = getActiveAccountId();
  if(accountId && activitySnapshotAccountsBeingRemoved.has(accountId)) return;
  try{
    window.localStorage.setItem(nsKey(ACTIVITY_STORAGE_KEY), JSON.stringify((state.atividades||[]).slice(0, ACTIVITY_LIMIT)));
  }catch(_){}
}
function activitySnapshotAccountPrefix(accountId){
  return `${ACTIVITY_SNAPSHOT_STORAGE_KEY}::${accountId || 'guest'}::`;
}
function activitySnapshotKey(activityId, accountId = getActiveAccountId()){
  return activitySnapshotAccountPrefix(accountId) + String(activityId || '');
}
async function idbDeletePrefix(prefix){
  const db = await openAppDb();
  if(!db) return false;
  return new Promise(resolve => {
    try{
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const cursorRequest = tx.objectStore(IDB_STORE).openCursor();
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result;
        if(!cursor) return;
        if(typeof cursor.key === 'string' && cursor.key.startsWith(prefix)) cursor.delete();
        cursor.continue();
      };
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    }catch(_){ resolve(false); }
  });
}
async function deletePersistedJsonPrefix(prefix){
  await idbDeletePrefix(prefix);
  if(LOCAL_STORAGE_AVAILABLE){
    try{
      const keys = [];
      for(let i=0;i<window.localStorage.length;i++){
        const key = window.localStorage.key(i);
        if(key && key.startsWith(prefix)) keys.push(key);
      }
      keys.forEach(key => window.localStorage.removeItem(key));
    }catch(_){}
  }
}
function cloneActivitySnapshot(entry){
  if(!entry || typeof entry !== 'object') return null;
  try{ return JSON.parse(JSON.stringify(entry)); }
  catch(_){ return null; }
}
function activityFieldLabel(key, category){
  const labels = {
    titulo:'Título principal', titulo_original:'Título original', categoria:'Categoria',
    status:'Status pessoal', status_oficial:'Status oficial', ano:'Ano',
    data_inicio:'Data de início', data_fim:'Data de conclusão', criado_em:'Data de adição',
    atualizado_em:'Última atualização', ultima_edicao_obra:'Edição da obra',
    ultima_edicao_comentarios:'Edição dos comentários', favorito:'Favorito',
    comentario:'Comentários', nota:'Nota', generos:'Gêneros',
    capa_base64:'Imagem / capa', capa_url:'Imagem / capa',
    temporadas:'Temporadas', volumes:'Volumes', extras_independentes:'Extras sem temporada',
    progresso_simples:'Progresso', progresso_simples_editado_em:'Data de edição do progresso',
    duracao_min:'Duração', subcategoria:'Subcategoria', tipo_novel:'Subcategoria',
    autor:'Autor', editora:'Editora', paginas_total:'Total de páginas'
  };
  if(labels[key]) return labels[key];
  const bonus = (BONUS_FIELDS[category] || []).find(field => field.key === key);
  if(bonus) return bonus.label;
  return String(key || '').replace(/_/g,' ').replace(/\b\w/g, letter => letter.toLocaleUpperCase('pt-BR'));
}
function activityFieldValue(value, key){
  if(value === undefined || value === null || value === '') return 'Não informado';
  if(key === 'categoria') return listaCategoriaLabel(value);
  if(key === 'status') return statusLabel(value);
  if(key === 'status_oficial') return officialStatusLabel(value) || 'Não informado';
  if(key === 'favorito') return value ? 'Sim' : 'Não';
  if(key === 'nota') return typeof value === 'number' ? `${value.toFixed(1)} / 10` : 'Sem nota';
  if(key === 'data_inicio' || key === 'data_fim') return formatDateLongPt(String(value)) || String(value);
  if(key && /(?:^|_)em$/.test(key)){
    const formatted = formatDateTime(value);
    return formatted || String(value);
  }
  if(Array.isArray(value)) return value.length ? value.map(item => typeof item === 'object' ? JSON.stringify(item) : String(item)).join(', ') : 'Vazio';
  if(typeof value === 'object'){
    try{ return JSON.stringify(value); }catch(_){ return 'Detalhes alterados'; }
  }
  return String(value);
}
function isActivityIgnoredChangeKey(key){
  const normalized = String(key || '');
  return new Set(['id','criado_em','atualizado_em','ultima_edicao_obra','ultima_edicao_comentarios','progresso_simples_editado_em']).has(normalized) || /(?:^|_)editado_em$/.test(normalized);
}
function activityValuesEqual(before, after){
  const normalize = value => {
    if(value === undefined || value === null || value === '') return null;
    if(typeof value === 'string') return value.trim() || null;
    if(Array.isArray(value)){
      const normalized = value.map(normalize);
      return normalized.length ? normalized : null;
    }
    if(typeof value === 'object'){
      const normalized = {};
      Object.keys(value).sort().forEach(key => {
        const item = normalize(value[key]);
        if(item !== null) normalized[key] = item;
      });
      return Object.keys(normalized).length ? normalized : null;
    }
    return value;
  };
  return JSON.stringify(normalize(before)) === JSON.stringify(normalize(after));
}
function isActivityVisibleChange(change){
  const label = String(change && change.label || '');
  return !!label && !/^(?:Última atualização|Edição da obra|Edição dos comentários|Data de adição|Data de edição do progresso)$/.test(label) && !/(?:^| · )(?:data de edição|data dos episódios|data dos capítulos)$/.test(label);
}
function addActivityChange(changes, label, before, after, key){
  if(isActivityIgnoredChangeKey(key) || !isActivityVisibleChange({label}) || activityValuesEqual(before, after)) return;
  changes.push({
    label,
    before:activityFieldValue(before, key),
    after:activityFieldValue(after, key)
  });
}
function activityProgressChanges(before, after, changes){
  const oldSeasons = Array.isArray(before && before.temporadas) ? before.temporadas : [];
  const newSeasons = Array.isArray(after && after.temporadas) ? after.temporadas : [];
  if(oldSeasons.length !== newSeasons.length){
    addActivityChange(changes, 'Número de temporadas', oldSeasons.length, newSeasons.length);
  }
  const seasonCount = Math.max(oldSeasons.length, newSeasons.length);
  for(let i=0;i<seasonCount;i++){
    const oldSeason = oldSeasons[i];
    const newSeason = newSeasons[i];
    const seasonNo = (newSeason && newSeason.numero) || (oldSeason && oldSeason.numero) || i + 1;
    if(!oldSeason || !newSeason){
      addActivityChange(changes, `Temporada ${seasonNo}`, oldSeason ? 'Presente' : 'Não informada', newSeason ? 'Presente' : 'Removida');
      addActivityChange(changes, `Temporada ${seasonNo} · status`, oldSeason && oldSeason.status, newSeason && newSeason.status, 'status');
      addActivityChange(changes, `Temporada ${seasonNo} · episódios`, oldSeason && oldSeason.episodios, newSeason && newSeason.episodios);
      continue;
    }
    addActivityChange(changes, `Temporada ${seasonNo} · status`, oldSeason.status, newSeason.status, 'status');
    addActivityChange(changes, `Temporada ${seasonNo} · episódios`, oldSeason.episodios, newSeason.episodios);
    addActivityChange(changes, `Temporada ${seasonNo} · extras`, oldSeason.extras, newSeason.extras);
  }

  const oldVolumes = Array.isArray(before && before.volumes) ? before.volumes : [];
  const newVolumes = Array.isArray(after && after.volumes) ? after.volumes : [];
  if(oldVolumes.length !== newVolumes.length){
    addActivityChange(changes, 'Número de volumes', oldVolumes.length, newVolumes.length);
  }
  const volumeCount = Math.max(oldVolumes.length, newVolumes.length);
  for(let i=0;i<volumeCount;i++){
    const oldVolume = oldVolumes[i];
    const newVolume = newVolumes[i];
    const volumeNo = (newVolume && newVolume.numero) || (oldVolume && oldVolume.numero) || i + 1;
    const volumeLabel = `Volume ${volumeNo}`;
    if(!oldVolume || !newVolume){
      addActivityChange(changes, volumeLabel, oldVolume ? 'Presente' : 'Não informado', newVolume ? 'Presente' : 'Removido');
      const addedOrRemovedVolume = newVolume || oldVolume;
      if(addedOrRemovedVolume){
        addActivityChange(changes, `${volumeLabel} · nome`, oldVolume && oldVolume.nome, newVolume && newVolume.nome);
        addActivityChange(changes, `${volumeLabel} · status`, oldVolume && oldVolume.status, newVolume && newVolume.status, 'status');
        addActivityChange(changes, `${volumeLabel} · total de capítulos`, oldVolume && oldVolume.capitulos, newVolume && newVolume.capitulos);
        const chapters = Array.isArray(addedOrRemovedVolume.capitulos_lista) ? addedOrRemovedVolume.capitulos_lista : [];
        chapters.forEach((chapter, chapterIndex) => {
          const chapterLabel = `${volumeLabel} · capítulo ${chapterIndex + 1}`;
          addActivityChange(changes, `${chapterLabel} · título`, oldVolume && oldVolume.capitulos_lista && oldVolume.capitulos_lista[chapterIndex] && oldVolume.capitulos_lista[chapterIndex].nome, newVolume && newVolume.capitulos_lista && newVolume.capitulos_lista[chapterIndex] && newVolume.capitulos_lista[chapterIndex].nome);
          addActivityChange(changes, `${chapterLabel} · quantidade`, oldVolume && oldVolume.capitulos_lista && oldVolume.capitulos_lista[chapterIndex] && oldVolume.capitulos_lista[chapterIndex].quantidade, newVolume && newVolume.capitulos_lista && newVolume.capitulos_lista[chapterIndex] && newVolume.capitulos_lista[chapterIndex].quantidade);
          addActivityChange(changes, `${chapterLabel} · página`, oldVolume && oldVolume.capitulos_lista && oldVolume.capitulos_lista[chapterIndex] && oldVolume.capitulos_lista[chapterIndex].pagina, newVolume && newVolume.capitulos_lista && newVolume.capitulos_lista[chapterIndex] && newVolume.capitulos_lista[chapterIndex].pagina);
        });
      }
      continue;
    }
    addActivityChange(changes, `${volumeLabel} · nome`, oldVolume.nome, newVolume.nome);
    addActivityChange(changes, `${volumeLabel} · status`, oldVolume.status, newVolume.status, 'status');
    addActivityChange(changes, `${volumeLabel} · total de capítulos`, oldVolume.capitulos, newVolume.capitulos);
    const oldChapters = Array.isArray(oldVolume.capitulos_lista) ? oldVolume.capitulos_lista : [];
    const newChapters = Array.isArray(newVolume.capitulos_lista) ? newVolume.capitulos_lista : [];
    const chapterCount = Math.max(oldChapters.length, newChapters.length);
    for(let j=0;j<chapterCount;j++){
      const oldChapter = oldChapters[j];
      const newChapter = newChapters[j];
      const chapterLabel = `${volumeLabel} · capítulo ${j + 1}`;
      if(!oldChapter || !newChapter){
        addActivityChange(changes, chapterLabel, oldChapter ? 'Presente' : 'Não informado', newChapter ? 'Presente' : 'Removido');
        continue;
      }
      addActivityChange(changes, `${chapterLabel} · título`, oldChapter.nome, newChapter.nome);
      addActivityChange(changes, `${chapterLabel} · quantidade`, oldChapter.quantidade, newChapter.quantidade);
      addActivityChange(changes, `${chapterLabel} · página`, oldChapter.pagina, newChapter.pagina);
    }
  }
  addActivityChange(changes, 'Progresso simples', before && before.progresso_simples, after && after.progresso_simples);
}
function describeActivityChanges(before, after){
  const changes = [];
  if(!before && after){
    changes.push({label:'Obra criada', before:'Não existia no acervo', after:'Adicionada ao acervo'});
    return changes;
  }
  if(before && !after){
    changes.push({label:'Obra removida', before:'Presente no acervo', after:'Apagada do acervo'});
    return changes;
  }
  if(!before || !after) return changes;
  const ignored = new Set(['capa_base64','capa_url','temporadas','volumes','progresso_simples']);
  const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
  keys.forEach(key => {
    if(ignored.has(key) || isActivityIgnoredChangeKey(key)) return;
    addActivityChange(changes, activityFieldLabel(key, after.categoria || before.categoria), before[key], after[key], key);
  });
  const oldCover = before.capa_base64 || before.capa_url;
  const newCover = after.capa_base64 || after.capa_url;
  if(oldCover !== newCover){
    changes.push({
      label:'Imagem / capa',
      before:oldCover ? 'Imagem anterior' : 'Sem imagem',
      after:newCover ? 'Imagem atualizada' : 'Imagem removida'
    });
  }
  activityProgressChanges(before, after, changes);
  return changes.filter(isActivityVisibleChange);
}
function activitySnapshotPayload(before, after, changes){
  const visibleChanges = (changes || describeActivityChanges(before, after)).filter(isActivityVisibleChange);
  const payload = {
    before:cloneActivitySnapshot(before),
    after:cloneActivitySnapshot(after),
    images:{},
    changes:visibleChanges
  };
  const beforeImage = before && before.capa_base64;
  const afterImage = after && after.capa_base64;
  if(beforeImage && beforeImage === afterImage){
    payload.images.shared = beforeImage;
    delete payload.before.capa_base64;
    if(payload.after) delete payload.after.capa_base64;
  } else {
    if(beforeImage){ payload.images.before = beforeImage; delete payload.before.capa_base64; }
    if(afterImage && payload.after){ payload.images.after = afterImage; delete payload.after.capa_base64; }
  }
  return payload;
}
function hydrateActivitySnapshot(entry, payload, version){
  const hydrated = cloneActivitySnapshot(entry);
  if(!hydrated) return null;
  const image = payload && payload.images && (payload.images.shared || payload.images[version]);
  if(image) hydrated.capa_base64 = image;
  return hydrated;
}
async function removeActivitySnapshot(activityId, accountId = getActiveAccountId()){
  if(activityId) await deletePersistedJson(activitySnapshotKey(activityId, accountId));
}
async function removeActivitySnapshotsForAccount(accountId){
  if(!accountId) return;
  const owner = String(accountId);
  const prefix = activitySnapshotAccountPrefix(owner);
  activitySnapshotAccountsBeingRemoved.add(owner);
  const pending = [...pendingActivitySnapshotWrites.entries()]
    .filter(([key]) => key.startsWith(prefix))
    .map(([, task]) => task);
  await Promise.allSettled(pending);
  await deletePersistedJsonPrefix(prefix);
}
function seedAtividadesFromEntries(){
  if((state.atividades||[]).length || !(state.entries||[]).length) return;
  const seeded = [];
  state.entries.forEach(entry => {
    const createdAt = Number(entry.criado_em || entry.atualizado_em || Date.now());
    seeded.push({
      id: 'seed-created-' + entry.id,
      timestamp: createdAt,
      action: 'created',
      target: 'obra',
      targetId: entry.id,
      title: String(entry.titulo || ''),
      detail: 'Registro existente; histórico inicializado a partir dos dados do acervo.',
      categoria: entry.categoria || null
    });
    const updatedAt = Number(entry.atualizado_em || createdAt);
    if(updatedAt > createdAt){
      seeded.push({
        id: 'seed-updated-' + entry.id,
        timestamp: updatedAt,
        action: 'updated',
        target: 'obra',
        targetId: entry.id,
        title: String(entry.titulo || ''),
        detail: 'Última modificação conhecida do registro.',
        categoria: entry.categoria || null
      });
    }
  });
  state.atividades = seeded.sort((a,b) => b.timestamp - a.timestamp).slice(0, ACTIVITY_LIMIT);
  saveAtividades();
}
function recordActivity(action, target, title, detail, options){
  const opts = options || {};
  const activityOwner = getActiveAccountId() || 'guest';
  const item = {
    id: uuid(),
    timestamp: Date.now(),
    action: String(action || 'updated'),
    target: String(target || 'obra'),
    targetId: opts.targetId || null,
    title: String(title || '').slice(0, 200),
    detail: String(detail || '').slice(0, 300),
    categoria: opts.categoria || null,
    searchTitles:[opts.titleBefore, title].filter(Boolean).map(value => String(value).slice(0, 200))
  };
  const previous = state.atividades || [];
  const next = [item].concat(previous);
  const dropped = next.slice(ACTIVITY_LIMIT);
  state.atividades = next.slice(0, ACTIVITY_LIMIT);
  dropped.forEach(oldItem => { if(oldItem && oldItem.id) removeActivitySnapshot(oldItem.id, activityOwner); });
  saveAtividades();
  const hasBefore = Object.prototype.hasOwnProperty.call(opts, 'beforeSnapshot');
  const hasAfter = Object.prototype.hasOwnProperty.call(opts, 'afterSnapshot');
  if(hasBefore || hasAfter){
    const before = hasBefore ? opts.beforeSnapshot : null;
    const after = hasAfter ? opts.afterSnapshot : null;
    const snapshot = activitySnapshotPayload(before, after, opts.changes);
    item.hasSnapshots = true;
    item.snapshotBeforeAvailable = !!before;
    item.snapshotAfterAvailable = !!after;
    item.changedFields = snapshot.changes.filter(isActivityVisibleChange).map(change => change.label).slice(0, 40);
    item.snapshotStatus = 'saving';
    saveAtividades();
    if(activitySnapshotAccountsBeingRemoved.has(activityOwner)){
      item.snapshotStatus = 'unavailable';
      saveAtividades();
    }else{
      const snapshotKey = activitySnapshotKey(item.id, activityOwner);
      const writeTask = writePersistedJson(snapshotKey, snapshot).then(ok => {
        if(!(state.atividades || []).includes(item) || activitySnapshotAccountsBeingRemoved.has(activityOwner)){
          return deletePersistedJson(snapshotKey);
        }
        item.snapshotStatus = ok ? 'ready' : 'unavailable';
        saveAtividades();
        if(!ok && !activitySnapshotWarningShown){
          activitySnapshotWarningShown = true;
          showToast('warning', 'Não foi possível guardar as versões desta alteração neste dispositivo.');
        }
        if(state.view === 'historico'){ try{ renderHistorico(); }catch(_){} }
      }).catch(() => {
        if((state.atividades || []).includes(item) && !activitySnapshotAccountsBeingRemoved.has(activityOwner)){
          item.snapshotStatus = 'unavailable';
          saveAtividades();
          if(state.view === 'historico'){ try{ renderHistorico(); }catch(_){} }
        }
      }).finally(() => {
        if(pendingActivitySnapshotWrites.get(snapshotKey) === writeTask){
          pendingActivitySnapshotWrites.delete(snapshotKey);
        }
      });
      pendingActivitySnapshotWrites.set(snapshotKey, writeTask);
    }
  }
  if(state.view === 'historico'){
    try{ renderHistorico(); }catch(_){}
  }
  return item;
}
function recordEntriesActivity(action, entries, detail){
  (Array.isArray(entries) ? entries : []).forEach(entry => {
    if(!entry) return;
    const beforeSnapshot = action === 'deleted' ? cloneActivitySnapshot(entry) : null;
    const afterSnapshot = action === 'restored' ? cloneActivitySnapshot(entry) : null;
    recordActivity(action, 'obra', entry.titulo, detail, {
      targetId: entry.id,
      categoria: entry.categoria,
      beforeSnapshot,
      afterSnapshot,
      changes:action === 'restored'
        ? [{label:'Obra restaurada', before:'Fora do acervo', after:'Restaurada ao acervo'}]
        : undefined
    });
  });
}
function activityMeta(item){
  const meta = {
    created:  {label:'Adicionada',   icon:'i-plus',     tone:'success'},
    updated:  {label:'Editada',      icon:'i-edit',    tone:'info'},
    deleted:  {label:'Apagada',      icon:'i-trash',   tone:'danger'},
    restored: {label:'Restaurada',   icon:'i-history', tone:'success'},
    viewed:   {label:'Consultada',   icon:'i-search',  tone:'muted'},
    favorite_added:   {label:'Favoritada',       icon:'i-star',   tone:'success'},
    favorite_removed: {label:'Favorito removido', icon:'i-star',   tone:'muted'},
    list:     {label:'Lista alterada',icon:'i-list',   tone:'info'},
    imported: {label:'Importação',   icon:'i-upload',  tone:'info'},
    exported: {label:'Backup exportado', icon:'i-download', tone:'info'},
    wiped:    {label:'Acervo limpo', icon:'i-trash',   tone:'danger'}
  };
  return meta[item && item.action] || meta.updated;
}
function activityTimestamp(item){
  const numeric = Number(item && item.timestamp);
  if(Number.isFinite(numeric) && numeric > 0) return numeric;
  const parsed = Date.parse(item && item.timestamp);
  return Number.isFinite(parsed) ? parsed : 0;
}
function activityDateBoundary(value, endOfDay){
  if(!value) return null;
  const parts = String(value).split('-').map(Number);
  if(parts.length !== 3 || parts.some(part => !Number.isInteger(part))) return null;
  const date = endOfDay
    ? new Date(parts[0], parts[1] - 1, parts[2], 23, 59, 59, 999)
    : new Date(parts[0], parts[1] - 1, parts[2], 0, 0, 0, 0);
  const time = date.getTime();
  return Number.isFinite(time) ? time : null;
}
function activityMatchesFilters(item){
  const filters = state.activityFilters || {};
  const category = String(item && item.categoria || '').split(':')[0];
  if(filters.categoria && filters.categoria !== 'todos' && category !== filters.categoria) return false;
  const obraSearch = String(filters.obra || '').trim().toLocaleLowerCase('pt-BR');
  const titles = [item.title].concat(Array.isArray(item.searchTitles) ? item.searchTitles : []).filter(Boolean);
  if(obraSearch && (item.target !== 'obra' || !titles.some(title => String(title).toLocaleLowerCase('pt-BR').includes(obraSearch)))) return false;
  const timestamp = activityTimestamp(item);
  const from = activityDateBoundary(filters.dataInicio, false);
  const to = activityDateBoundary(filters.dataFim, true);
  if(from !== null && timestamp < from) return false;
  if(to !== null && timestamp > to) return false;
  return true;
}
function activityCategoryOptionsHtml(selected){
  return [
    '<option value="todos">Todas as categorias</option>',
    ...CATEGORY_ORDER.map(category => {
      const meta = CATEGORY_META[category];
      return `<option value="${category}" ${selected === category ? 'selected' : ''}>${escapeHtml(meta.plural)}</option>`;
    })
  ].join('');
}
function activityFiltersAreActive(){
  const filters = state.activityFilters || {};
  return (filters.categoria && filters.categoria !== 'todos') || !!filters.dataInicio || !!filters.dataFim || !!String(filters.obra || '').trim();
}
function refreshActivitySearchResults(content){
  if(!content) return;
  const allActivities = Array.isArray(state.atividades) ? state.atividades : [];
  const activities = allActivities.filter(activityMatchesFilters);
  const visibleActivities = new Set(activities);
  content.querySelectorAll('.activity-item[data-activity-index]').forEach(element => {
    const activity = allActivities[Number(element.dataset.activityIndex)];
    element.hidden = !activity || !visibleActivities.has(activity);
  });

  const summary = content.querySelector('.activity-summary');
  if(summary){
    const obras = activities.filter(item => item.target === 'obra').length;
    const changes = activities.filter(item => ['created','updated','deleted','restored','favorite_added','favorite_removed'].includes(item.action)).length;
    [activities.length, obras, changes].forEach((value, index) => {
      const counter = summary.querySelectorAll('strong')[index];
      if(counter) counter.textContent = String(value);
    });
  }

  const latest = activities[0];
  const toolbar = content.querySelector('.activity-toolbar');
  if(toolbar){
    const labels = toolbar.querySelectorAll('span');
    if(labels[0]) labels[0].textContent = latest ? `Última atividade no filtro em ${formatDateTime(latest.timestamp)}` : '';
    if(labels[1]) labels[1].textContent = activityFiltersAreActive()
      ? `De ${allActivities.length} eventos, ${activities.length} correspondem`
      : `Mostrando até ${ACTIVITY_LIMIT} eventos`;
    toolbar.hidden = activities.length === 0;
  }

  const list = content.querySelector('.activity-list');
  if(list) list.hidden = activities.length === 0;
  const empty = content.querySelector('.activity-empty--filtered');
  if(empty) empty.hidden = activities.length > 0;

  const clearButton = content.querySelector('#activityFilterClear');
  if(clearButton) clearButton.disabled = !activityFiltersAreActive();
  const toggleSelectionButton = content.querySelector('#btnToggleActivitySelection');
  if(toggleSelectionButton) toggleSelectionButton.disabled = activities.length === 0;
  const selectAllButton = content.querySelector('#btnSelectAllActivities');
  if(selectAllButton){
    const selectedIds = state.selectedActivityIds instanceof Set ? state.selectedActivityIds : new Set();
    const visibleIds = activities.map(item => item.id).filter(Boolean);
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => selectedIds.has(id));
    selectAllButton.textContent = `Selecionar ${allSelected ? 'nenhuma' : 'todas'}`;
    selectAllButton.disabled = visibleIds.length === 0;
  }
}
function renderHistorico(){
  const content = document.getElementById('pageOverlayBody');
  if(!content) return;
  const allActivities = Array.isArray(state.atividades) ? state.atividades : [];
  const activities = allActivities.filter(activityMatchesFilters);
  const activitySelectionMode = state.activitySelectionMode === true;
  const selectedActivityIds = state.selectedActivityIds instanceof Set ? state.selectedActivityIds : new Set();
  const obras = activities.filter(item => item.target === 'obra').length;
  const changes = activities.filter(item => ['created','updated','deleted','restored','favorite_added','favorite_removed'].includes(item.action)).length;
  const latest = activities[0];
  const filters = state.activityFilters || {categoria:'todos', dataInicio:'', dataFim:'', obra:''};
  const activeFilters = activityFiltersAreActive();
  const visibleActivities = new Set(activities);
  let html = `
    <section class="activity-page">
      <div class="activity-page-intro">
        <div>
          <p class="activity-kicker">REGISTRO DO ACERVO</p>
          <h2>Histórico de atividades</h2>
          <p>Veja quando uma obra foi apenas consultada, quando os dados ou comentários foram editados e quando houve favoritos, listas, apagamentos, restaurações ou backups.</p>
        </div>
        <div class="activity-summary">
          <div><strong>${activities.length}</strong><span>eventos</span></div>
          <div><strong>${obras}</strong><span>em obras</span></div>
          <div><strong>${changes}</strong><span>alterações</span></div>
        </div>
      </div>
      <div class="activity-filters" aria-label="Filtros do histórico">
        <label class="activity-filter-field activity-filter-field--search">
          <span>Pesquisar obra</span>
          <input id="activityFilterWork" type="search" value="${escapeHtml(filters.obra || '')}" placeholder="Nome da obra..." aria-label="Pesquisar obras no histórico">
        </label>
        <label class="activity-filter-field">
          <span>Categoria</span>
          <select id="activityFilterCategory">${activityCategoryOptionsHtml(filters.categoria)}</select>
        </label>
        <label class="activity-filter-field">
          <span>De</span>
          <input id="activityFilterStart" type="date" value="${escapeHtml(filters.dataInicio || '')}" aria-label="Data inicial">
        </label>
        <label class="activity-filter-field">
          <span>Até</span>
          <input id="activityFilterEnd" type="date" value="${escapeHtml(filters.dataFim || '')}" aria-label="Data final">
        </label>
        <button type="button" class="btn btn-ghost btn-sm activity-filter-clear" id="activityFilterClear" ${activeFilters ? '' : 'disabled'}>Limpar filtros</button>
      </div>
      <div class="activity-management">
        <span>Apagar atividades não remove nem altera obras do acervo.</span>
        <div class="activity-management-actions">
          ${activitySelectionMode
            ? `<button type="button" class="btn btn-ghost btn-sm" id="btnSelectAllActivities" ${activities.length ? '' : 'disabled'}>Selecionar ${activities.length === selectedActivityIds.size && activities.length ? 'nenhuma' : 'todas'}</button>
               <button type="button" class="btn btn-danger btn-sm" id="btnDeleteSelectedActivities" ${selectedActivityIds.size ? '' : 'disabled'}><svg class="icon"><use href="#i-trash"/></svg> Apagar selecionadas (${selectedActivityIds.size})</button>
               <button type="button" class="btn btn-ghost btn-sm" id="btnCancelActivitySelection">Cancelar</button>`
            : `<button type="button" class="btn btn-ghost btn-sm" id="btnToggleActivitySelection" ${activities.length ? '' : 'disabled'}>Selecionar para apagar</button>`}
          <button type="button" class="btn btn-danger btn-sm" id="btnClearActivityHistory" ${allActivities.length ? '' : 'disabled'}>
            <svg class="icon"><use href="#i-trash"/></svg> Limpar todo o histórico
          </button>
        </div>
      </div>
  `;
  if(!allActivities.length){
    html += activeFilters
      ? `<div class="activity-empty"><svg class="icon"><use href="#i-search"/></svg><h3>Nenhum resultado encontrado</h3><p>Não há atividades para os filtros selecionados.</p><button type="button" class="btn btn-ghost btn-sm" data-action="clear-activity-filters">Limpar filtros</button></div>`
      : `<div class="activity-empty"><svg class="icon"><use href="#i-history"/></svg><h3>Nenhuma atividade registrada</h3><p>As próximas ações no seu acervo aparecerão aqui automaticamente.</p></div>`;
  } else {
    html += `<div class="activity-toolbar"${activities.length ? '' : ' hidden'}><span>${latest ? 'Última atividade no filtro em ' + escapeHtml(formatDateTime(latest.timestamp)) : ''}</span><span class="activity-limit">${activeFilters ? `De ${allActivities.length} eventos, ${activities.length} correspondem` : `Mostrando até ${ACTIVITY_LIMIT} eventos`}</span></div>
      <div class="activity-empty activity-empty--filtered"${activities.length ? ' hidden' : ''}><svg class="icon"><use href="#i-search"/></svg><h3>Nenhum resultado encontrado</h3><p>Não há atividades para os filtros selecionados.</p><button type="button" class="btn btn-ghost btn-sm" data-action="clear-activity-filters">Limpar filtros</button></div>
      <div class="activity-list"${activities.length ? '' : ' hidden'}>`;
    allActivities.forEach((item, activityIndex) => {
      const meta = activityMeta(item);
      const targetLabel = item.target === 'lista' ? 'Lista' : item.target === 'backup' ? 'Backup' : item.target === 'acervo' ? 'Acervo' : 'Obra';
      const categoryLabel = item.categoria ? listaCategoriaLabel(item.categoria) : '';
      const canOpenCurrent = item.target === 'obra' && item.targetId && state.entries.some(entry => entry.id === item.targetId);
      const canOpenBefore = item.snapshotStatus === 'ready' && item.snapshotBeforeAvailable === true;
      const beforeLabel = item.snapshotStatus === 'saving'
        ? 'A guardar versão…'
        : item.snapshotStatus === 'unavailable'
          ? 'Versão indisponível'
          : canOpenBefore ? 'Ver versão anterior' : 'Sem versão anterior';
      const visibleChangedFields = Array.isArray(item.changedFields) ? item.changedFields.filter(label => isActivityVisibleChange({label})) : [];
      const changedFields = visibleChangedFields.length
        ? `<p class="activity-changed-fields"><strong>Campos alterados:</strong> ${escapeHtml(visibleChangedFields.join(', '))}${visibleChangedFields.length >= 40 ? '…' : ''}</p>`
        : '';
      html += `
        <article class="activity-item activity-item--${meta.tone}${activitySelectionMode ? ' activity-item--selectable' : ''}" data-activity-id="${escapeHtml(item.id || '')}" data-activity-index="${activityIndex}"${visibleActivities.has(item) ? '' : ' hidden'}>
          ${activitySelectionMode ? `<input type="checkbox" class="activity-checkbox" data-activity-checkbox="${escapeHtml(item.id || '')}" ${selectedActivityIds.has(item.id) ? 'checked' : ''} aria-label="Selecionar atividade de ${escapeHtml(item.title || 'atividade do acervo')}">` : ''}
          <div class="activity-icon"><svg class="icon"><use href="#${meta.icon}"/></svg></div>
          <div class="activity-content">
            <div class="activity-line"><strong>${escapeHtml(meta.label)}</strong><span class="activity-target">${escapeHtml(targetLabel)}</span>${categoryLabel ? `<span class="activity-category">${escapeHtml(categoryLabel)}</span>` : ''}<time>${escapeHtml(formatDateTime(item.timestamp))}</time></div>
            <div class="activity-title">${escapeHtml(item.title || 'Atividade do acervo')}</div>
            ${item.detail && !(item.action === 'updated' && changedFields) ? `<p>${escapeHtml(item.detail)}</p>` : ''}
            ${changedFields}
            ${item.target === 'obra' && !canOpenCurrent && item.action === 'deleted' ? '<p class="activity-deleted-note">Esta obra foi apagada do acervo e continua apenas no histórico.</p>' : ''}
          </div>
          <div class="activity-record-actions">
            ${item.target === 'obra' ? `
              <div class="activity-version-actions">
                <button type="button" class="btn btn-ghost btn-sm" data-activity-current="${escapeHtml(item.targetId || '')}" ${canOpenCurrent ? '' : 'disabled'}>Ver versão atual</button>
                <button type="button" class="btn btn-ghost btn-sm" data-activity-before="${escapeHtml(item.id || '')}" ${canOpenBefore ? '' : 'disabled'}>${escapeHtml(beforeLabel)}</button>
              </div>` : ''}
            <button type="button" class="activity-delete-btn" data-delete-activity="${escapeHtml(item.id || '')}" aria-label="Apagar esta atividade" title="Apagar esta atividade">
              <svg class="icon"><use href="#i-trash"/></svg><span>Apagar registro</span>
            </button>
          </div>
        </article>`;
    });
    html += '</div>';
  }
  html += '</section>';
  content.innerHTML = html;
  content.querySelectorAll('[data-activity-current]').forEach(button => {
    button.addEventListener('click', () => {
      if(!button.disabled && button.dataset.activityCurrent) openDetailModal(button.dataset.activityCurrent);
    });
  });
  content.querySelectorAll('[data-activity-before]').forEach(button => {
    button.addEventListener('click', () => {
      if(!button.disabled) openActivitySnapshotPage(button.dataset.activityBefore);
    });
  });
  content.querySelectorAll('[data-delete-activity]').forEach(button => {
    button.addEventListener('click', () => confirmDeleteActivity(button.dataset.deleteActivity));
  });
  content.querySelectorAll('[data-activity-checkbox]').forEach(checkbox => {
    checkbox.addEventListener('click', event => {
      event.stopPropagation();
      toggleActivitySelected(checkbox.dataset.activityCheckbox);
    });
  });
  const toggleActivitySelectionButton = content.querySelector('#btnToggleActivitySelection');
  if(toggleActivitySelectionButton) toggleActivitySelectionButton.addEventListener('click', () => {
    state.activitySelectionMode = true;
    state.selectedActivityIds = new Set();
    renderHistorico();
  });
  const cancelActivitySelectionButton = content.querySelector('#btnCancelActivitySelection');
  if(cancelActivitySelectionButton) cancelActivitySelectionButton.addEventListener('click', () => {
    state.activitySelectionMode = false;
    state.selectedActivityIds = new Set();
    renderHistorico();
  });
  const selectAllActivitiesButton = content.querySelector('#btnSelectAllActivities');
  if(selectAllActivitiesButton) selectAllActivitiesButton.addEventListener('click', () => {
    const visibleIds = activities.map(item => item.id).filter(Boolean);
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => state.selectedActivityIds.has(id));
    visibleIds.forEach(id => allSelected ? state.selectedActivityIds.delete(id) : state.selectedActivityIds.add(id));
    renderHistorico();
  });
  const deleteSelectedActivitiesButton = content.querySelector('#btnDeleteSelectedActivities');
  if(deleteSelectedActivitiesButton) deleteSelectedActivitiesButton.addEventListener('click', confirmDeleteSelectedActivities);
  const clearHistoryButton = content.querySelector('#btnClearActivityHistory');
  if(clearHistoryButton) clearHistoryButton.addEventListener('click', confirmClearActivityHistory);
  const clearActivityFilters = () => {
    state.activityFilters = {categoria:'todos', dataInicio:'', dataFim:'', obra:''};
    renderHistorico();
  };
  const workSearch = content.querySelector('#activityFilterWork');
  if(workSearch) workSearch.addEventListener('input', event => {
    state.activityFilters.obra = event.currentTarget.value;
    refreshActivitySearchResults(content);
  });
  const categoryFilter = content.querySelector('#activityFilterCategory');
  const startFilter = content.querySelector('#activityFilterStart');
  const endFilter = content.querySelector('#activityFilterEnd');
  if(categoryFilter) categoryFilter.addEventListener('change', event => {
    state.activityFilters.categoria = event.target.value;
    renderHistorico();
  });
  if(startFilter) startFilter.addEventListener('change', event => {
    state.activityFilters.dataInicio = event.target.value;
    renderHistorico();
  });
  if(endFilter) endFilter.addEventListener('change', event => {
    state.activityFilters.dataFim = event.target.value;
    renderHistorico();
  });
  const clearFiltersButton = content.querySelector('#activityFilterClear');
  if(clearFiltersButton) clearFiltersButton.addEventListener('click', clearActivityFilters);
  const emptyClearButton = content.querySelector('[data-action="clear-activity-filters"]');
  if(emptyClearButton) emptyClearButton.addEventListener('click', clearActivityFilters);
}
function toggleActivitySelected(activityId){
  if(!activityId) return;
  if(!(state.selectedActivityIds instanceof Set)) state.selectedActivityIds = new Set();
  if(state.selectedActivityIds.has(activityId)) state.selectedActivityIds.delete(activityId);
  else state.selectedActivityIds.add(activityId);
  renderHistorico();
}
function confirmDeleteSelectedActivities(){
  const selected = new Set(state.selectedActivityIds instanceof Set ? state.selectedActivityIds : []);
  const items = (state.atividades || []).filter(item => selected.has(item.id));
  if(!items.length) return;
  openConfirmModal(
    'Apagar atividades selecionadas',
    `Apagar os <strong>${items.length} registros selecionados</strong> do histórico? As obras e os dados do acervo não serão alterados.`,
    () => {
      state.atividades = (state.atividades || []).filter(item => !selected.has(item.id));
      saveAtividades();
      Promise.all(items.map(item => removeActivitySnapshot(item.id)));
      state.activitySelectionMode = false;
      state.selectedActivityIds = new Set();
      renderHistorico();
      showToast('success', `${items.length} ${items.length === 1 ? 'atividade apagada' : 'atividades apagadas'} do histórico.`);
    }
  );
}
function confirmDeleteActivity(activityId){
  const item = (state.atividades || []).find(activity => activity.id === activityId);
  if(!item) return;
  openConfirmModal(
    'Apagar atividade do histórico',
    `Apagar o registro <strong>${escapeHtml(activityMeta(item).label.toLowerCase())}</strong> de <strong>${escapeHtml(item.title || 'Atividade do acervo')}</strong>? A obra e os dados do acervo não serão alterados.`,
    () => {
      state.atividades = (state.atividades || []).filter(activity => activity.id !== activityId);
      if(item.target === 'obra' && item.targetId && !state.entries.some(entry => entry.id === item.targetId)){
        // Apagar apenas o evento não restaura nem remove a obra do acervo.
      }
      saveAtividades();
      removeActivitySnapshot(activityId);
      renderHistorico();
      showToast('success', 'Atividade apagada do histórico.');
    }
  );
}
function confirmClearActivityHistory(){
  const count = (state.atividades || []).length;
  if(!count) return;
  openConfirmModal(
    'Limpar todo o histórico',
    `Apagar os <strong>${count} registros</strong> do histórico e as versões salvas? As obras do acervo permanecerão intactas.`,
    () => {
      const ids = (state.atividades || []).map(item => item.id).filter(Boolean);
      state.atividades = [];
      saveAtividades();
      Promise.all(ids.map(removeActivitySnapshot));
      renderHistorico();
      showToast('success', 'Histórico apagado. As obras do acervo não foram alteradas.');
    }
  );
}
function activitySnapshotComparisonHtml(changes){
  changes = Array.isArray(changes) ? changes.filter(isActivityVisibleChange) : [];
  if(!changes.length) return '';
  return `<section class="activity-snapshot-changes">
    <h3>Alterações registradas neste evento</h3>
    <div class="activity-snapshot-change-list">
      ${changes.map(change => `<div class="activity-snapshot-change">
        <strong>${escapeHtml(change.label || 'Campo alterado')}</strong>
        <span>${escapeHtml(change.before || 'Não informado')} <b aria-hidden="true">→</b> ${escapeHtml(change.after || 'Não informado')}</span>
      </div>`).join('')}
    </div>
  </section>`;
}
async function openActivitySnapshotPage(activityId){
  const item = (state.atividades || []).find(activity => activity.id === activityId);
  if(!item || item.snapshotStatus !== 'ready' || item.snapshotBeforeAvailable !== true) return;
  const payload = await readPersistedJson(activitySnapshotKey(activityId), null);
  const savedEntry = payload && payload.before;
  const entry = hydrateActivitySnapshot(savedEntry, payload, 'before');
  if(!entry){
    item.snapshotStatus = 'unavailable';
    saveAtividades();
    renderHistorico();
    showToast('warning', 'A versão anterior não está disponível neste dispositivo.');
    return;
  }
  const scrollSnapshot = getActiveScrollSnapshot();
  state.obraDetalheReturn = {
    view:'historico',
    categoriaAtiva:state.categoriaAtiva,
    filmeSubAtivo:state.filmeSubAtivo,
    novelSubAtivo:state.novelSubAtivo,
    listaAtivaId:state.listaAtivaId,
    scrollY:scrollSnapshot.scrollY,
    scrollContext:scrollSnapshot,
    fromActivityId:activityId
  };
  state.activitySnapshot = {
    entry,
    activityId,
    timestamp:item.timestamp,
    action:item.action,
    version:'before',
    changes:Array.isArray(payload.changes) ? payload.changes : []
  };
  state.obraDetalheId = entry.id;
  state.view = 'obra-detalhe';
  renderMain();
}
let pendingDeleteId = null;
let pendingDuplicateSubmit = null;
let pendingDeleteListId = null;
let pendingDeleteIds = null;
let editingListId = null;
let pickerTargetListaId = null;
let onlineMetaRequestId = 0;
let onlineMetaSearching = false;
let exportSequenceFallback = 0;

function uuid(){
  if(window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
  return 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2);
}
function escapeHtml(str){
  if(str === undefined || str === null) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function clamp(n, min, max){ return Math.min(max, Math.max(min, n)); }
function debounce(fn, ms){ let t; return function(...args){ clearTimeout(t); t = setTimeout(()=>fn.apply(this,args), ms); }; }
function isValidUrl(str){ if(!str) return true; try{ new URL(str); return true; } catch(e){ return false; } }
function currentYear(){ return new Date().getFullYear(); }
function formatDate(d){ if(!d) return ''; const parts = d.split('-'); if(parts.length !== 3) return d; return parts[2] + '/' + parts[1] + '/' + parts[0]; }
const MESES_PT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
function formatDateLongPt(d){
  if(!d) return '';
  const parts = d.split('-');
  if(parts.length !== 3) return d;
  const [y,m,day] = parts;
  const mesNome = MESES_PT[parseInt(m,10)-1];
  if(!mesNome) return d;
  return `${day}/${mesNome}/${y}`;
}
function normalizeText(value){
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}
function formatDateTime(value){
  if(!value) return '';
  const d = new Date(value);
  if(Number.isNaN(d.getTime())) return '';
  const day = String(d.getDate()).padStart(2,'0');
  const mesNome = MESES_PT[d.getMonth()];
  const hh = String(d.getHours()).padStart(2,'0');
  const mm = String(d.getMinutes()).padStart(2,'0');
  return `${day}/${mesNome}/${d.getFullYear()}, ${hh}:${mm}`;
}
function nextBrowserTick(){
  return new Promise(resolve => setTimeout(resolve, 0));
}
function normalizeEntryEditDates(entry){
  if(!entry || typeof entry !== 'object') return entry;
  const fallback = entry.atualizado_em || entry.criado_em || Date.now();
  if(!entry.ultima_edicao_obra) entry.ultima_edicao_obra = fallback;
  if(!entry.ultima_edicao_comentarios) entry.ultima_edicao_comentarios = fallback;
  (Array.isArray(entry.temporadas) ? entry.temporadas : []).forEach(season => {
    if(season && !season.episodios_editado_em) season.episodios_editado_em = fallback;
  });
  (Array.isArray(entry.volumes) ? entry.volumes : []).forEach(volume => {
    if(!volume) return;
    if(!volume.editado_em) volume.editado_em = fallback;
    if(!volume.capitulos_editado_em) volume.capitulos_editado_em = fallback;
    (Array.isArray(volume.capitulos_lista) ? volume.capitulos_lista : []).forEach(chapter => {
      if(chapter && !chapter.editado_em) chapter.editado_em = volume.capitulos_editado_em;
    });
  });
  if(entry.progresso_simples != null && !entry.progresso_simples_editado_em){
    entry.progresso_simples_editado_em = fallback;
  }
  return entry;
}
function progressRecordSignature(record, ignoredKeys){
  const ignored = new Set(['aberta', ...(ignoredKeys || [])]);
  const comparable = {};
  Object.keys(record || {}).sort().forEach(key => {
    if(!ignored.has(key)) comparable[key] = record[key];
  });
  return JSON.stringify(comparable);
}
function applyProgressEditDates(previous, next, now, isNew){
  const oldSeasons = Array.isArray(previous && previous.temporadas) ? previous.temporadas : [];
  if(Array.isArray(next.temporadas)){
    next.temporadas = next.temporadas.map((season, index) => {
      const oldSeason = oldSeasons[index];
      const episodesChanged = !oldSeason || Number(oldSeason.episodios || 0) !== Number(season.episodios || 0);
      const seasonChanged = !oldSeason || progressRecordSignature(oldSeason, ['editado_em','episodios_editado_em']) !== progressRecordSignature(season, ['editado_em','episodios_editado_em']);
      return Object.assign({}, season, {
        editado_em:seasonChanged ? now : (oldSeason.editado_em || now),
        episodios_editado_em:episodesChanged ? now : (oldSeason.episodios_editado_em || oldSeason.editado_em || now)
      });
    });
  }

  const oldVolumes = Array.isArray(previous && previous.volumes) ? previous.volumes : [];
  if(Array.isArray(next.volumes)){
    next.volumes = next.volumes.map((volume, index) => {
      const oldVolume = oldVolumes[index];
      const oldChapters = Array.isArray(oldVolume && oldVolume.capitulos_lista) ? oldVolume.capitulos_lista : [];
      const chapters = Array.isArray(volume.capitulos_lista) ? volume.capitulos_lista : [];
      const withoutChapterDates = list => list.map(chapter => {
        const copy = Object.assign({}, chapter);
        delete copy.editado_em;
        return copy;
      });
      const chapterListChanged = !oldVolume ||
        Number(oldVolume.capitulos || 0) !== Number(volume.capitulos || 0) ||
        JSON.stringify(withoutChapterDates(oldChapters)) !== JSON.stringify(withoutChapterDates(chapters));
      const volumeChanged = !oldVolume || progressRecordSignature(oldVolume, ['editado_em','capitulos_editado_em','capitulos_lista']) !== progressRecordSignature(volume, ['editado_em','capitulos_editado_em','capitulos_lista']) || chapterListChanged;
      const datedChapters = chapters.map((chapter, chapterIndex) => {
        const oldChapter = oldChapters[chapterIndex];
        const changed = !oldChapter || progressRecordSignature(oldChapter, ['editado_em']) !== progressRecordSignature(chapter, ['editado_em']);
        return Object.assign({}, chapter, {
          editado_em:changed ? now : (oldChapter.editado_em || (oldVolume && oldVolume.capitulos_editado_em) || now)
        });
      });
      return Object.assign({}, volume, {
        capitulos_lista:datedChapters,
        editado_em:volumeChanged ? now : (oldVolume.editado_em || now),
        capitulos_editado_em:chapterListChanged ? now : (oldVolume.capitulos_editado_em || oldVolume.editado_em || now)
      });
    });
  }

  if(next.progresso_simples != null){
    const changed = isNew || !previous || Number(previous.progresso_simples || 0) !== Number(next.progresso_simples || 0);
    next.progresso_simples_editado_em = changed
      ? now
      : (previous.progresso_simples_editado_em || previous.atualizado_em || previous.criado_em || now);
  }
  return next;
}
function entryEditTimestamp(entry){
  if(!entry || typeof entry !== 'object') return 0;
  const candidates = [entry.ultima_edicao_obra, entry.atualizado_em, entry.criado_em];
  for(const value of candidates){
    if(typeof value === 'number' && Number.isFinite(value) && value > 0) return value;
    if(typeof value === 'string' && value.trim()){
      const numeric = Number(value);
      if(Number.isFinite(numeric) && numeric > 0) return numeric;
      const parsed = Date.parse(value);
      if(Number.isFinite(parsed) && parsed > 0) return parsed;
    }
  }
  return 0;
}
function entryDuplicateKey(entry){
  if(!entry || !entry.titulo || !entry.categoria) return '';
  return entry.categoria + '::' + normalizeLookupText(entry.titulo);
}
function relevantEntrySignature(entry, includeComment){
  const ignored = new Set(['id','criado_em','atualizado_em','ultima_edicao_obra','ultima_edicao_comentarios']);
  if(!includeComment) ignored.add('comentario');
  const out = {};
  Object.keys(entry || {}).sort().forEach(key => {
    if(!ignored.has(key)) out[key] = entry[key];
  });
  return JSON.stringify(out);
}

function isOnline(){
  return !(typeof navigator !== 'undefined' && navigator.onLine === false);
}
function readOnlineCache(){
  if(!LOCAL_STORAGE_AVAILABLE) return {metadata:{}, covers:{}};
  try{
    const raw = window.localStorage.getItem(ONLINE_CACHE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return {
      metadata: parsed && parsed.metadata && typeof parsed.metadata === 'object' ? parsed.metadata : {},
      covers: parsed && parsed.covers && typeof parsed.covers === 'object' ? parsed.covers : {}
    };
  }catch(e){ return {metadata:{}, covers:{}}; }
}
function writeOnlineCache(cache){
  if(!LOCAL_STORAGE_AVAILABLE || !cache) return;
  try{
    window.localStorage.setItem(ONLINE_CACHE_KEY, JSON.stringify({
      metadata: cache.metadata || {},
      covers: cache.covers || {}
    }));
  }catch(e){ /* cache é opcional: se encher, a app continua funcional */ }
}
let _idbPromise = null;
function openAppDb(){
  if(typeof indexedDB === 'undefined') return Promise.resolve(null);
  if(_idbPromise) return _idbPromise;
  _idbPromise = new Promise(resolve => {
    let req;
    try{ req = indexedDB.open(IDB_NAME, 1); }
    catch(e){ resolve(null); return; }
    req.onupgradeneeded = () => {
      const db = req.result;
      if(!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(null);
    req.onblocked = () => resolve(null);
  });
  return _idbPromise;
}
async function idbGet(key){
  const db = await openAppDb();
  if(!db) return null;
  return new Promise(resolve => {
    try{
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(key);
      req.onsuccess = () => resolve(req.result == null ? null : req.result);
      req.onerror = () => resolve(null);
    }catch(e){ resolve(null); }
  });
}
async function idbSet(key, value){
  const db = await openAppDb();
  if(!db) return false;
  return new Promise(resolve => {
    try{
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(value, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    }catch(e){ resolve(false); }
  });
}
async function idbDelete(key){
  const db = await openAppDb();
  if(!db) return false;
  return new Promise(resolve => {
    try{
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    }catch(e){ resolve(false); }
  });
}
function readLocalStorageJson(key, fallback){
  if(!LOCAL_STORAGE_AVAILABLE) return fallback;
  try{
    const raw = window.localStorage.getItem(key);
    if(!raw) return fallback;
    return JSON.parse(raw);
  }catch(e){ return fallback; }
}
async function readPersistedJson(key, fallback){
  const fromIdb = await idbGet(key);
  if(fromIdb){
    try{ return JSON.parse(fromIdb); }
    catch(e){ /* tenta localStorage */ }
  }
  return readLocalStorageJson(key, fallback);
}
async function writePersistedJson(key, value){
  const text = JSON.stringify(value);
  const idbOk = await idbSet(key, text);
  let lsOk = false;
  if(LOCAL_STORAGE_AVAILABLE){
    try{
      if(text.length <= LOCAL_STORAGE_MIRROR_LIMIT) window.localStorage.setItem(key, text);
      else window.localStorage.removeItem(key);
      lsOk = text.length <= LOCAL_STORAGE_MIRROR_LIMIT;
    }catch(e){
      try{ window.localStorage.removeItem(key); }catch(_){}
    }
  }
  return idbOk || lsOk;
}
async function deletePersistedJson(key){
  await idbDelete(key);
  if(LOCAL_STORAGE_AVAILABLE){
    try{ window.localStorage.removeItem(key); }catch(e){}
  }
  if(CLAUDE_STORAGE_AVAILABLE){
    try{ await window.storage.delete(key, false); }catch(e){}
  }
}
async function requestPersistentStorage(){
  if(!navigator.storage || typeof navigator.storage.persist !== 'function') return;
  try{
    const already = typeof navigator.storage.persisted === 'function' ? await navigator.storage.persisted() : false;
    if(!already) await navigator.storage.persist();
  }catch(e){ /* o navegador pode negar sem afetar o app */ }
}
function cacheKey(categoria, query){
  return String(categoria || 'todos') + '|' + normalizeLookupText(query || '');
}

let _viewportRaf = null;
function setViewportVars(){
  const vv = window.visualViewport;
  const appH = Math.max(1, Math.round(window.innerHeight || document.documentElement.clientHeight || 0));
  const visualH = Math.max(1, Math.round((vv && vv.height) || appH));
  document.documentElement.style.setProperty('--app-height', appH + 'px');
  document.documentElement.style.setProperty('--visual-height', visualH + 'px');
}
function scheduleViewportVars(){
  if(_viewportRaf) cancelAnimationFrame(_viewportRaf);
  _viewportRaf = requestAnimationFrame(() => {
    _viewportRaf = null;
    setViewportVars();
    if(typeof scheduleStickyOffsets === 'function') scheduleStickyOffsets();
  });
}
function hasOpenModal(){
  return ['formModalBackdrop','detailModalBackdrop','confirmModalBackdrop','listaFormModalBackdrop','obraPickerModalBackdrop','listSelectorModalBackdrop']
    .some(id => {
      const el = document.getElementById(id);
      return el && !el.hidden;
    });
}
function repairInteractiveState(forceRender){
  // BUGFIX: esta função roda sempre que o app volta ao primeiro plano (troca
  // de app, troca de aba, o celular "acorda" a janela — ver os listeners de
  // 'pageshow'/'visibilitychange'/'focus' mais abaixo), NÃO só quando o
  // usuário realmente navega para outra página. Ela acaba forçando um
  // renderMain() "cru" que reconstrói a grade/página do zero sem passar pelo
  // caminho normal de troca de view (o que salva/restaura a rolagem) — por
  // isso a posição em que a pessoa estava sempre se perdia, voltando para
  // uma posição praticamente fixa perto do topo, em QUALQUER página (grade
  // principal, Minhas Listas, detalhe da lista, Estatísticas). Por isso a
  // posição de rolagem é capturada AQUI, logo no início, antes de qualquer
  // alteração no DOM (o código abaixo mexe nas classes do overlay, o que
  // atrapalharia a detecção do contêiner certo se a captura fosse feita
  // depois) e devolvida ao contêiner certo depois do render.
  const _resumeScrollSnapshot = (typeof getActiveScrollSnapshot === 'function') ? getActiveScrollSnapshot() : null;
  setViewportVars();
  prepareTextInputs(document);
  if(typeof scheduleStickyOffsets === 'function') scheduleStickyOffsets();
  document.querySelectorAll('button, input, select, textarea').forEach(el => {
    if(el.dataset && el.dataset.keepDisabled === '1') return;
    if(el.matches('[data-lista-id][disabled], .list-selector-item[disabled]')) return;
    if(el.id === 'btnDeleteSelectedObras' || el.id === 'btnRemoveSelectedObras' || el.id === 'btnAddToListObras') return;
    if(el.hasAttribute('aria-disabled')) el.removeAttribute('aria-disabled');
  });
  const sidebarBackdrop = document.getElementById('sidebarBackdrop');
  const sidebar = document.getElementById('sidebar');
  if(sidebarBackdrop && !(sidebar && sidebar.classList.contains('is-open'))) sidebarBackdrop.remove();
  // Sincroniza as camadas com a view persistida sem reconstruir o conteúdo.
  // A Visão geral também é renderizada em #pageOverlay; deixá-la fora desta
  // lista fazia o retorno do background fechar o overlay e revelar a tela
  // anterior, que não era redesenhada neste caminho de recuperação.
  const pageOverlay = document.getElementById('pageOverlay');
  const overlayViews = ['listas','lista-detalhe','estatisticas','obra-detalhe','historico','favoritos'];
  const shouldShowPageOverlay = overlayViews.includes(state.view);
  if(pageOverlay){
    pageOverlay.classList.toggle('is-open', shouldShowPageOverlay);
    pageOverlay.setAttribute('aria-hidden', shouldShowPageOverlay ? 'false' : 'true');
    document.body.classList.toggle('has-overlay', shouldShowPageOverlay);
  }
  const listOverlay = document.getElementById('listPageOverlay');
  if(listOverlay && typeof listPageState !== 'undefined'){
    const shouldShowListPage = !!listPageState.isOpen;
    listOverlay.classList.toggle('is-active', shouldShowListPage);
    // openListPage usa overflow inline; limpá-lo quando a camada já não está
    // ativa evita que a página anterior fique sem rolagem após a reentrada.
    document.body.style.overflow = shouldShowListPage ? 'hidden' : '';
  }
  // Voltar ao foco/à aba não é uma navegação. Reconstruir a aplicação aqui
  // desmonta a grelha, dispara várias medições de layout e faz o utilizador
  // ver a página a piscar antes de a posição ser restaurada. O render só deve
  // acontecer quando a página foi realmente restaurada pelo BFCache (ou
  // quando o chamador o pede explicitamente).
  if(forceRender && !hasOpenModal()){
    renderMain();
    if(_resumeScrollSnapshot && typeof _resumeScrollSnapshot.scrollY === 'number'){
      requestAnimationFrame(() => requestAnimationFrame(() => {
        if(_resumeScrollSnapshot.container === 'page-overlay'){
          restoreElementScrollUntilStable(document.getElementById('pageOverlay'), _resumeScrollSnapshot.scrollY);
        } else if(_resumeScrollSnapshot.container === 'list-page'){
          restoreElementScrollUntilStable(document.getElementById('listPageContent'), _resumeScrollSnapshot.scrollY);
        } else {
          restoreScrollUntilStable(() => {
            setScrollerPos(_resumeScrollSnapshot.scrollY);
            return {height:getScrollerHeight(), landed:Math.abs(getScrollerPos()-_resumeScrollSnapshot.scrollY)<1};
          });
        }
      }));
    }
  }
}
function prepareTextInputs(scope){
  const root = scope || document;
  // Este arquivo pertence exclusivamente ao modo telefone.
  const mobileForceNone = true;
  root.querySelectorAll('input, textarea').forEach(el => {
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    // Campos de data usam o seletor nativo do navegador/telefone. Eles não
    // podem receber inputmode="none", senão o toque não abre o calendário.
    if(type === 'date') return;
    if(['file','checkbox','radio','range','button','submit','reset','color'].includes(type)) return;
    const isNumeric = type === 'number' || ['numeric','decimal'].includes((el.getAttribute('inputmode')||'').toLowerCase());
    const isCredential = type === 'password';
    const isUrlOrEmail = type === 'url' || type === 'email';
    const isComment = el.tagName === 'TEXTAREA' || el.id === 'f_comentario';
    const isSearch = type === 'search' || el.id === 'searchInput' || /search/i.test(el.id || '');
    const isName = /titulo|nome|autor|editora|perfil|usuario/i.test(el.id || '');
    // Mantém a ajuda do sistema onde ela é útil e desliga apenas nos campos
    // em que sugestões/capitalização automáticas atrapalham (senha, URL e
    // valores numéricos). O teclado próprio continua controlando a entrada.
    // IMPORTANTE: o app usa o SEU teclado (sugestões, correção e maiúsculas são
    // feitas por ele). Qualquer ajuda nativa ligada aqui (autopreenchimento,
    // autocorreção, sublinhado ortográfico) fazia o Chrome/Android desenhar
    // barras e teclados por cima do app — por isso fica SEMPRE desligada.
    el.setAttribute('autocomplete', 'off');
    el.setAttribute('autocorrect', 'off');
    el.setAttribute('autocapitalize', 'off');
    el.setAttribute('spellcheck', 'false');
    el.setAttribute('data-lpignore', 'true');
    el.setAttribute('data-1p-ignore', '');
    el.setAttribute('data-form-type', 'other');
    if(!el.hasAttribute('lang')) el.setAttribute('lang', 'pt-BR');
    if(!el.hasAttribute('enterkeyhint')) el.setAttribute('enterkeyhint', isComment ? 'enter' : (isSearch ? 'search' : 'next'));
    if(type === 'number' && !el.hasAttribute('inputmode')) el.setAttribute('inputmode', el.getAttribute('step') === 'any' ? 'decimal' : 'numeric');
    if(type === 'search' && !el.hasAttribute('inputmode')) el.setAttribute('inputmode', 'search');
    if(mobileForceNone){
      // Sobrepõe qualquer inputmode existente para garantir que o teclado do
      // sistema não é chamado; o teclado virtual do próprio app fornece a
      // entrada de texto. Também remove type="number"/"tel"/"email" para
      // evitar que o Chrome force um teclado numérico/e-mail próprio.
      // Os campos permanecem editáveis para que o navegador posicione o cursor
      // no ponto tocado; inputmode="none" basta para manter o teclado nativo fechado.
      // Antes de sobrepor, guarda o inputmode original (ex.: "numeric" do
      // campo de PIN) para o teclado virtual saber mostrar o layout
      // numérico em vez do alfabético — ver pickModeFor() em initCustomKeyboard.
      if(!el.dataset._origInputmode){
        const curIm = el.getAttribute('inputmode');
        if(curIm) el.dataset._origInputmode = curIm;
      }
      el.setAttribute('inputmode','none');
      if(['number','tel','email','url'].includes(type)){
        // Preserva o type original em data-*, para validação/formatação de app
        if(!el.dataset._origType) el.dataset._origType = type;
        el.setAttribute('type','text');
      }
    }
    ensureInputClearButton(el);
  });
}

/* ------------------------------------------------------------------
   Barra visual de inserção.
   Só é usada nos campos readonly que precisam do teclado personalizado:
   campos editáveis usam o cursor nativo, que acompanha corretamente o toque.
   ------------------------------------------------------------------ */
(function installVisualInputCaret(){
  const caret = document.createElement('span');
  caret.className = 'input-visual-caret';
  caret.setAttribute('aria-hidden', 'true');
  document.body.appendChild(caret);

  let active = null;
  let mirror = null;
  let rafId = 0;
  let settleRafId = 0;

  function isEditable(el){
    if(!el || !el.matches || !el.matches('input,textarea')) return false;
    if(el.disabled) return false;
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    if(['hidden','checkbox','radio','range','file','button','submit','reset','color'].includes(type)) return false;
    return el.readOnly && el.dataset.ckbReadonlyOk === '1';
  }

  function scheduleUpdate(){
    if(rafId) return;
    const raf = window.requestAnimationFrame || (fn => setTimeout(fn, 0));
    rafId = raf(() => { rafId = 0; update(); });
  }

  // O campo de lista recebe foco no mesmo instante em que o modal começa a
  // animar e o teclado virtual altera a altura visível. Como o cursor visual
  // fica no body, acompanha o campo por alguns frames até o layout estabilizar.
  function settlePosition(){
    const raf = window.requestAnimationFrame || (fn => setTimeout(fn, 16));
    let remaining = 36;
    const tick = () => {
      settleRafId = 0;
      if(!active) return;
      update();
      if(--remaining > 0) settleRafId = raf(tick);
    };
    if(!settleRafId) settleRafId = raf(tick);
  }

  function update(){
    if(!active || !document.body.contains(active) || !isEditable(active) || document.activeElement !== active){
      hide();
      return;
    }
    const rect = active.getBoundingClientRect();
    if(rect.width <= 0 || rect.height <= 0 || rect.bottom < 0 || rect.top > window.innerHeight || rect.right < 0 || rect.left > window.innerWidth){
      caret.classList.remove('is-visible');
      return;
    }
    // TRAVA DO CURSOR: o traço só é desenhado se o próprio campo estiver
    // realmente visível nesse ponto do ecrã. Se outra coisa o cobrir (teclado,
    // modal, barra fixa, página que mudou) o cursor some em vez de ficar
    // "solto" por cima de outra parte do app.
    try{
      const px = Math.min(Math.max(rect.left + Math.min(8, rect.width / 2), 0), window.innerWidth - 1);
      const py = Math.min(Math.max(rect.top + rect.height / 2, 0), window.innerHeight - 1);
      const topEl = document.elementFromPoint(px, py);
      const box = active.parentElement;
      if(!topEl || !(topEl === active || active.contains(topEl) || (box && box.contains(topEl)))){
        caret.classList.remove('is-visible');
        return;
      }
    }catch(_){}
    const cs = getComputedStyle(active);
    const value = active.value || '';
    // selectionEnd é a posição visualmente correta quando o utilizador
    // seleciona texto e volta a inserir; em digitação normal é igual ao
    // selectionStart.
    const pos = typeof active.selectionEnd === 'number' ? active.selectionEnd : value.length;
    const borderLeft = parseFloat(cs.borderLeftWidth) || 0;
    const borderRight = parseFloat(cs.borderRightWidth) || 0;
    const borderTop = parseFloat(cs.borderTopWidth) || 0;
    const borderBottom = parseFloat(cs.borderBottomWidth) || 0;
    const padLeft = parseFloat(cs.paddingLeft) || 0;
    const fontSize = parseFloat(cs.fontSize) || 16;
    let lineHeight = parseFloat(cs.lineHeight);
    if(!Number.isFinite(lineHeight)) lineHeight = fontSize * 1.2;
    let left = rect.left + borderLeft + padLeft - (active.scrollLeft || 0);
    const contentHeight = Math.max(0, rect.height - borderTop - borderBottom);
    let top = rect.top + borderTop + Math.max(0, (contentHeight - lineHeight) / 2);

    if(!mirror){
      mirror = document.createElement('div');
      mirror.style.position = 'absolute';
      mirror.style.visibility = 'hidden';
      mirror.style.pointerEvents = 'none';
      mirror.style.top = '-9999px';
      mirror.style.left = '-9999px';
      document.body.appendChild(mirror);
    }
    mirror.style.font = cs.font;
    mirror.style.letterSpacing = cs.letterSpacing;
    mirror.style.fontKerning = cs.fontKerning;
    mirror.style.fontStretch = cs.fontStretch;
    mirror.style.fontVariant = cs.fontVariant;
    mirror.style.fontFeatureSettings = cs.fontFeatureSettings;
    mirror.style.textTransform = cs.textTransform;
    mirror.style.wordSpacing = cs.wordSpacing;
    mirror.style.direction = cs.direction;
    mirror.style.textIndent = cs.textIndent;
    mirror.style.tabSize = cs.tabSize;

    if(active.tagName === 'TEXTAREA'){
      // Replica o wrapping do textarea e mede o marcador na linha exata do
      // caret, para a barra ficar à direita também em comentários multilinha.
      mirror.style.whiteSpace = 'pre-wrap';
      mirror.style.wordWrap = 'break-word';
      mirror.style.overflowWrap = 'break-word';
      mirror.style.boxSizing = cs.boxSizing;
      mirror.style.width = active.clientWidth + 'px';
      mirror.style.padding = cs.padding;
      mirror.style.lineHeight = cs.lineHeight;
      mirror.innerHTML = '';
      mirror.appendChild(document.createTextNode(value.slice(0, pos)));
      const marker = document.createElement('span');
      marker.textContent = '\u200b';
      mirror.appendChild(marker);
      const mirrorRect = mirror.getBoundingClientRect();
      const markerRect = marker.getBoundingClientRect();
      left = rect.left + borderLeft + (markerRect.left - mirrorRect.left) - (active.scrollLeft || 0);
      top = rect.top + borderTop + (markerRect.top - mirrorRect.top) - (active.scrollTop || 0);
      lineHeight = Math.min(lineHeight, Math.max(12, rect.height - (parseFloat(cs.paddingTop)||0) - (parseFloat(cs.paddingBottom)||0)));
    } else {
      // Mede o prefixo e o valor completo para respeitar o alinhamento visual
      // do campo. Em inputs centralizados, o prefixo começa no centro quando
      // vazio e a barra acompanha cada letra/número dentro do grupo centrado.
      mirror.style.whiteSpace = 'pre';
      mirror.style.display = 'inline-block';
      mirror.style.webkitTextSecurity = cs.webkitTextSecurity || 'none';
      mirror.style.textSecurity = cs.textSecurity || 'none';
      mirror.textContent = value.slice(0, pos);
      const prefixWidth = mirror.getBoundingClientRect().width;
      mirror.textContent = value;
      const fullWidth = mirror.getBoundingClientRect().width;
      const padRight = parseFloat(cs.paddingRight) || 0;
      const contentWidth = Math.max(0, rect.width - borderLeft - borderRight - padLeft - padRight);
      const align = (cs.textAlign || 'start').toLowerCase();
      if(align === 'center'){
        left += Math.max(0, (contentWidth - fullWidth) / 2) + prefixWidth;
      } else if(align === 'right' || (align === 'end' && cs.direction !== 'rtl')){
        left += Math.max(0, contentWidth - fullWidth) + prefixWidth;
      } else {
        left += prefixWidth;
      }
    }

    // O cursor desenhado pelo app nunca pode sair da área útil do campo.
    // Em alguns WebViews Android o cálculo do espelho recebe uma largura
    // diferente da escala visual do input (especialmente com initial-scale),
    // e a barra acabava sendo pintada sobre a borda direita ou fora dela.
    // Limitar a posição mantém o cursor dentro do campo sem alterar o texto,
    // a seleção ou o comportamento do teclado.
    const minLeft = rect.left + borderLeft + padLeft;
    const maxLeft = Math.max(minLeft, rect.right - borderRight - (parseFloat(cs.paddingRight) || 0) - 2);
    left = Math.min(Math.max(left, minLeft), maxLeft);
    const minTop = rect.top + borderTop + Math.max(0, (contentHeight - lineHeight) / 2);
    const maxTop = Math.max(minTop, rect.bottom - borderBottom - lineHeight - 1);
    top = Math.min(Math.max(top, minTop), maxTop);

    caret.style.left = Math.round(left) + 'px';
    caret.style.top = Math.round(top) + 'px';
    caret.style.height = Math.max(14, Math.round(lineHeight)) + 'px';
    caret.classList.add('is-visible');
  }

  function show(el){
    if(!isEditable(el)){
      if(active) hide();
      return;
    }
    if(active && active !== el) active.classList.remove('visual-caret-target');
    active = el;
    active.classList.add('visual-caret-target');
    document.body.classList.add('has-visual-input-caret');
    scheduleUpdate();
    settlePosition();
    startWatch();
  }

  function hide(){
    if(active) active.classList.remove('visual-caret-target');
    active = null;
    caret.classList.remove('is-visible');
    document.body.classList.remove('has-visual-input-caret');
  }

  // Vigia enquanto o cursor existe: a cada ~80 ms confirma que o campo continua
  // no documento, com foco e no mesmo sítio. Isto cobre o que nenhum evento
  // avisa (campo removido ao trocar de página, modal a deslizar, scroll interno),
  // que era o que deixava o traço a piscar parado noutra zona da página.
  let watchId = 0;
  function startWatch(){
    if(watchId) return;
    const tick = () => {
      watchId = 0;
      if(!active) return;
      update();               // esconde e limpa `active` se algo estiver errado
      if(active) watchId = setTimeout(tick, 80);
    };
    watchId = setTimeout(tick, 80);
  }
  ['popstate','hashchange','pagehide','orientationchange'].forEach(ev =>
    window.addEventListener(ev, () => { if(active) scheduleUpdate(); }, {passive:true}));
  document.addEventListener('visibilitychange', () => { if(document.hidden) hide(); });

  document.addEventListener('focusin', e => show(e.target), true);
  document.addEventListener('focusout', e => {
    setTimeout(() => { if(active === e.target && document.activeElement !== e.target) hide(); }, 0);
  }, true);
  document.addEventListener('input', e => { if(active === e.target) scheduleUpdate(); }, true);
  document.addEventListener('keyup', e => { if(active === e.target) scheduleUpdate(); }, true);
  document.addEventListener('click', e => { if(isEditable(e.target)) show(e.target); }, true);
  document.addEventListener('selectionchange', () => { if(active) scheduleUpdate(); }, true);
  window.addEventListener('resize', scheduleUpdate, {passive:true});
  window.addEventListener('scroll', scheduleUpdate, {passive:true, capture:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize', scheduleUpdate, {passive:true});
    window.visualViewport.addEventListener('scroll', scheduleUpdate, {passive:true});
  }
})();
function ensureInputClearButton(el){
  if(!el || el.dataset.clearableReady === '1') { updateInputClearButton(el); return; }
  if(el.closest('.search-wrap') || el.closest('.tag-input-wrap')) return;
  // Não adicionar botão de limpar em campos numéricos pequenos (qtd de OVA/Filme):
  // o botão sobrepõe o campo e dificulta a entrada de dados.
  if(el.classList && el.classList.contains('extra-qtd')) return;
  const type = (el.getAttribute('type') || 'text').toLowerCase();
  if(['hidden','file','checkbox','radio','range','button','submit','reset','color','date'].includes(type)) return;
  // Campos de senha/PIN do app são convertidos para type="text" (ver
  // forceNoNativeKeyboard), por isso são reconhecidos pela marca guardada.
  const pwdWrap = el.closest ? el.closest('.pwd-wrap') : null;
  if(type === 'password' && !pwdLikeReady(el)) return; // ainda não convertido: o teclado do app marca-o a seguir
  // Mover um campo que está com foco faria perder o foco/cursor: adia até sair do campo.
  if(document.activeElement === el && !pwdWrap){
    el.addEventListener('blur', () => ensureInputClearButton(el), {once:true});
    return;
  }
  let wrap = null;
  if(pwdWrap){
    // Senha/PIN já têm a sua caixa (.pwd-wrap, com o olho): o X entra nela, ao lado do olho.
    wrap = pwdWrap;
    wrap.classList.add('has-clear-btn');
  } else {
    wrap = el.parentElement && el.parentElement.classList && el.parentElement.classList.contains('clearable-field-wrap') ? el.parentElement : null;
    if(!wrap){
      wrap = document.createElement('span');
      wrap.className = 'clearable-field-wrap';
      if(el.classList.contains('extra-qtd')) wrap.classList.add('is-extra-qtd');
      el.parentNode.insertBefore(wrap, el);
      wrap.appendChild(el);
    }
  }
  // Já existe um X nesta caixa (ex.: campo "Nome do volume", que traz o seu
  // próprio botão no HTML): não criar um segundo.
  if(wrap.querySelector(':scope > .input-clear-btn, :scope > .search-clear-btn')){
    el.dataset.clearableReady = '1';
    return;
  }
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'input-clear-btn' + (pwdWrap ? ' pwd-clear-btn' : '');
  btn.setAttribute('aria-label', 'Limpar campo');
  btn.innerHTML = '<svg class="icon"><use href="#i-close"/></svg>';
  // Evita que o toque no X tire o foco do input: sem isto, no telemóvel o
  // teclado virtual fecha, a página faz reflow e o "click" cai no campo
  // seguinte (ex.: data de início).
  btn.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); });
  btn.addEventListener('mousedown', (e) => { e.preventDefault(); e.stopPropagation(); });
  btn.addEventListener('touchstart', (e) => { e.stopPropagation(); }, {passive:true});
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    el.value = '';
    el.dispatchEvent(new Event('input', {bubbles:true}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
    updateInputClearButton(el);
    try{ el.focus({preventScroll:true}); }catch(_){ el.focus(); }
    try{ el.setSelectionRange(0,0); }catch(_){}
  });
  // Em .pwd-wrap o X fica antes do olho; nos restantes, no fim da caixa.
  const eye = pwdWrap ? pwdWrap.querySelector('.pwd-toggle') : null;
  if(eye) wrap.insertBefore(btn, eye); else wrap.appendChild(btn);
  const refresh = () => updateInputClearButton(el);
  el.addEventListener('input', refresh);
  el.addEventListener('change', refresh);
  el.dataset.clearableReady = '1';
  updateInputClearButton(el);
}
// Um campo type="password" só entra na regra de senha depois de o teclado do app o
// ter convertido; até lá não mexemos nele (evita criar o X duas vezes).
function pwdLikeReady(el){ return !!(el && el.dataset && (el.dataset.ckbReadonlyOk === '1' || el.dataset._origType === 'password')); }
function updateInputClearButton(el){
  if(!el) return;
  const wrap = el.parentElement;
  const btn = wrap && wrap.querySelector ? wrap.querySelector('.input-clear-btn') : null;
  if(btn) btn.hidden = !el.value;
}
function updateAllInputClearButtons(scope){
  const root = scope || document;
  root.querySelectorAll('.clearable-field-wrap input, .clearable-field-wrap textarea').forEach(updateInputClearButton);
}
function updateSearchClearButtons(scope){
  const root = scope || document;
  root.querySelectorAll('.search-clear-btn[data-clear-target]').forEach(btn => {
    const input = document.getElementById(btn.dataset.clearTarget);
    if(!input) return;
    btn.hidden = !input.value;
  });
}

async function loadEntries(){
  if(CLAUDE_STORAGE_AVAILABLE){
    try{
      const res = await window.storage.get(nsKey(STORAGE_KEY), false);
      if(res && res.value){
        const parsed = JSON.parse(res.value);
        state.entries = Array.isArray(parsed) ? parsed.map(normalizeEntryEditDates) : [];
      } else { state.entries = []; }
      return;
    }catch(e){ /* se falhar aqui, tenta localStorage abaixo */ }
  }
  const parsed = await readPersistedJson(nsKey(STORAGE_KEY), []);
  state.entries = Array.isArray(parsed) ? parsed.map(normalizeEntryEditDates) : [];
}
async function _persistEntriesNow(){
  ensureDefaultLists();
  if(CLAUDE_STORAGE_AVAILABLE){
    try{
      const ok = await window.storage.set(nsKey(STORAGE_KEY), JSON.stringify(state.entries), false);
      if(!ok) showToast('error', 'Não foi possível salvar os dados. Tente novamente.');
      return;
    }catch(e){ /* se falhar aqui, tenta localStorage abaixo */ }
  }
  const ok = await writePersistedJson(nsKey(STORAGE_KEY), state.entries);
  if(ok){
    return;
  }
  showToast('warning', 'Armazenamento indisponível neste ambiente — alterações não serão salvas ao recarregar.');
}
let _persistTimer = null;
// Marca que a grelha do dashboard ficou desatualizada (uma entrada foi
// criada/editada/removida/favoritada) e precisa de ser reconstruída da
// próxima vez que a view 'lista' for exibida — mesmo que estejamos a
// "pular" a reconstrução por a grelha já existir intacta (ver _renderMainNow).
let _gridStale = true; // true no arranque, para garantir a 1ª renderização
function persistEntries(){
  _gridStale = true;
  if(_persistTimer) clearTimeout(_persistTimer);
  _persistTimer = setTimeout(() => { _persistTimer = null; _persistEntriesNow(); }, 250);
}
window.addEventListener('beforeunload', () => { if(_persistTimer){ clearTimeout(_persistTimer); _persistTimer = null; _persistEntriesNow(); } });

async function loadListas(){
  if(CLAUDE_STORAGE_AVAILABLE){
    try{
      const res = await window.storage.get(nsKey(LISTS_STORAGE_KEY), false);
      if(res && res.value){ const parsed = JSON.parse(res.value); state.listas = Array.isArray(parsed) ? parsed : []; }
      else { state.listas = []; }
      return;
    }catch(e){ /* tenta localStorage abaixo */ }
  }
  const parsed = await readPersistedJson(nsKey(LISTS_STORAGE_KEY), []);
  state.listas = Array.isArray(parsed) ? parsed : [];
}
async function persistListas(){
  if(CLAUDE_STORAGE_AVAILABLE){
    try{
      const ok = await window.storage.set(nsKey(LISTS_STORAGE_KEY), JSON.stringify(state.listas), false);
      if(!ok) showToast('error', 'Não foi possível salvar as listas. Tente novamente.');
      return;
    }catch(e){ /* tenta localStorage abaixo */ }
  }
  const ok = await writePersistedJson(nsKey(LISTS_STORAGE_KEY), state.listas);
  if(ok){
    return;
  }
  showToast('warning', 'Armazenamento indisponível — as listas não serão salvas ao recarregar.');
}

async function reloadPersistedState(forceRender){
  if(_persistTimer){
    clearTimeout(_persistTimer);
    _persistTimer = null;
    await _persistEntriesNow();
  }
  if(hasOpenModal()){
    repairInteractiveState(forceRender);
    return;
  }
  await loadEntries();
  await loadListas();
  ensureDefaultLists();
  repairInteractiveState(forceRender);
}

function getUiStateSnapshot(){
  const scrollSnapshot = (typeof getActiveScrollSnapshot === 'function') ? getActiveScrollSnapshot() : null;
  rememberActiveScrollSnapshot(scrollSnapshot);
  return {
    categoriaAtiva: state.categoriaAtiva,
    filmeSubAtivo: state.filmeSubAtivo,
    novelSubAtivo: state.novelSubAtivo,
    busca: state.busca,
    filtroStatus: state.filtroStatus,
    filtroStatusOficial: state.filtroStatusOficial,
    filtroTituloInicio: state.filtroTituloInicio,
    filtroGenero: state.filtroGenero,
    notaMinima: state.notaMinima,
    favoritosOnly: state.favoritosOnly,
    ordenacao: state.ordenacao,
    obraViewMode: state.obraViewMode,
    favoritosBusca: state.favoritosBusca || '',
    favoritosCategoria: state.favoritosCategoria,
    favoritosStatus: state.favoritosStatus,
    favoritosOrdenacao: state.favoritosOrdenacao,
    favoritosViewMode: state.favoritosViewMode,
    listasViewMode: state.listasViewMode,
    listaObrasViewMode: state.listaObrasViewMode,
    capasDesfocadasIds: Array.isArray(state.capasDesfocadasIds) ? state.capasDesfocadasIds.slice(0, 5000) : [],
    capasReveladasPeloBotaoIds: Array.isArray(state.capasReveladasPeloBotaoIds) ? state.capasReveladasPeloBotaoIds.slice(0, 5000) : [],
    view: ['lista','estatisticas','listas','lista-detalhe','obra-detalhe','historico','favoritos'].includes(state.view) ? state.view : 'lista',
    listaAtivaId: typeof state.listaAtivaId === 'string' ? state.listaAtivaId : null,
    obraDetalheId: typeof state.obraDetalheId === 'string' ? state.obraDetalheId : null,
    obraDetalheReturn: state.obraDetalheReturn && typeof state.obraDetalheReturn === 'object'
      ? state.obraDetalheReturn
      : null,
    // A posição atual continua sendo guardada para restaurar a tela que estava
    // aberta no recarregamento. O mapa abaixo mantém, além dela, uma posição
    // independente para cada página/contexto visitado.
    scrollSnapshot,
    scrollMemory: getScrollMemorySnapshot()
  };
}
function normalizeCoverBlurIds(ids){
  if(!Array.isArray(ids)) return [];
  return Array.from(new Set(ids
    .filter(id => id != null && String(id).trim() !== '')
    .map(id => String(id).trim()))).slice(0, 5000);
}
function normalizeCoverBlurRecord(value){
  if(Array.isArray(value)) return {ids:normalizeCoverBlurIds(value), updatedAt:0};
  if(!value || typeof value !== 'object' || !Array.isArray(value.ids)) return null;
  const updatedAt = Number(value.updatedAt);
  return {
    ids:normalizeCoverBlurIds(value.ids),
    updatedAt:Number.isFinite(updatedAt) && updatedAt > 0 ? updatedAt : 0
  };
}
let _coverBlurWriteQueue = Promise.resolve();
function persistCoverBlurStateImmediately(){
  const key = nsKey(COVER_BLUR_STORAGE_KEY);
  const record = {
    ids:normalizeCoverBlurIds(state.capasDesfocadasIds),
    updatedAt:Date.now()
  };
  state.capasDesfocadasIds = record.ids;
  const text = JSON.stringify(record);
  if(LOCAL_STORAGE_AVAILABLE){
    try{ window.localStorage.setItem(key, text); }catch(_){}
  }
  // Serializa as gravações de IndexedDB para que um clique rápido seguido
  // de outro não permita que uma gravação antiga termine por último.
  _coverBlurWriteQueue = _coverBlurWriteQueue
    .catch(() => false)
    .then(() => idbSet(key, text))
    .catch(() => false);
}
async function loadCoverBlurPreference(savedUiState){
  const dedicatedBlurKey = nsKey(COVER_BLUR_STORAGE_KEY);
  const persistedBlurRecord = normalizeCoverBlurRecord(await readPersistedJson(dedicatedBlurKey, null));
  const mirroredBlurRecord = normalizeCoverBlurRecord(readLocalStorageJson(dedicatedBlurKey, null));
  const dedicatedBlurRecord = [persistedBlurRecord, mirroredBlurRecord]
    .filter(Boolean)
    .sort((a,b) => b.updatedAt - a.updatedAt)[0];
  const mirroredUiState = readLocalStorageJson(nsKey(APP_STATE_STORAGE_KEY), null);
  const legacyBlurIds = mirroredUiState && Array.isArray(mirroredUiState.capasDesfocadasIds)
    ? mirroredUiState.capasDesfocadasIds
    : savedUiState && savedUiState.capasDesfocadasIds;
  state.capasDesfocadasIds = dedicatedBlurRecord
    ? dedicatedBlurRecord.ids
    : normalizeCoverBlurIds(legacyBlurIds);
  if(!dedicatedBlurRecord && Array.isArray(legacyBlurIds)) persistCoverBlurStateImmediately();
}
async function loadUiState(){
  const saved = await readPersistedJson(nsKey(APP_STATE_STORAGE_KEY), null);
  _bootScrollSnapshot = null;
  if(!saved || typeof saved !== 'object'){
    await loadCoverBlurPreference(null);
    return;
  }
  if(saved.categoriaAtiva === 'todos' || CATEGORY_META[saved.categoriaAtiva]) state.categoriaAtiva = saved.categoriaAtiva;
  if(saved.filmeSubAtivo === 'todos' || FILME_SUBCATEGORIAS.includes(saved.filmeSubAtivo)) state.filmeSubAtivo = saved.filmeSubAtivo;
  if(saved.novelSubAtivo === 'todos' || NOVEL_SUBCATEGORIAS.includes(saved.novelSubAtivo)) state.novelSubAtivo = saved.novelSubAtivo;
  if(typeof saved.busca === 'string') state.busca = saved.busca.slice(0, 200);
  if(saved.filtroStatus === 'todos' || STATUS_META[saved.filtroStatus]) state.filtroStatus = saved.filtroStatus;
  if(saved.filtroStatusOficial === 'todos' || OFFICIAL_STATUS_META[saved.filtroStatusOficial]) state.filtroStatusOficial = saved.filtroStatusOficial;
  if(typeof saved.filtroTituloInicio === 'string') state.filtroTituloInicio = saved.filtroTituloInicio;
  if(typeof saved.filtroGenero === 'string') state.filtroGenero = saved.filtroGenero;
  if(typeof saved.notaMinima === 'number') state.notaMinima = saved.notaMinima;
  state.favoritosOnly = !!saved.favoritosOnly;
  if(['recente','antigo','notaDesc','notaAsc','az','za','anoDesc','anoAsc','progressoDesc','atualizadoAsc','atualizadoDesc'].includes(saved.ordenacao)) state.ordenacao = saved.ordenacao;
  if(['cards','compact','rows'].includes(saved.obraViewMode)) state.obraViewMode = saved.obraViewMode;
  if(['cards','rows'].includes(saved.listasViewMode)) state.listasViewMode = saved.listasViewMode;
  if(typeof saved.favoritosBusca === 'string') state.favoritosBusca = saved.favoritosBusca.slice(0, 200);
  if(CATEGORY_META[saved.favoritosCategoria] || saved.favoritosCategoria === 'todos') state.favoritosCategoria = saved.favoritosCategoria;
  if(STATUS_META[saved.favoritosStatus] || saved.favoritosStatus === 'todos') state.favoritosStatus = saved.favoritosStatus;
  if(['recente','alfabetica','nota'].includes(saved.favoritosOrdenacao)) state.favoritosOrdenacao = saved.favoritosOrdenacao;
  if(['cards','compact','rows'].includes(saved.favoritosViewMode)) state.favoritosViewMode = saved.favoritosViewMode;
  if(['rows','cards'].includes(saved.listaObrasViewMode)) state.listaObrasViewMode = saved.listaObrasViewMode;
  // A preferência do olho tem uma chave própria e também migra do estado de
  // interface legado, se ainda não houver uma gravação dedicada.
  await loadCoverBlurPreference(saved);
  state.capasReveladasPeloBotaoIds = normalizeCoverBlurIds(saved.capasReveladasPeloBotaoIds)
    .filter(id => state.capasDesfocadasIds.some(savedId => String(savedId) === id));
  if(['lista','estatisticas','listas','lista-detalhe','obra-detalhe','historico','favoritos'].includes(saved.view)) state.view = saved.view;
  if(typeof saved.listaAtivaId === 'string') state.listaAtivaId = saved.listaAtivaId;
  if(typeof saved.obraDetalheId === 'string') state.obraDetalheId = saved.obraDetalheId;
  if(saved.obraDetalheReturn && typeof saved.obraDetalheReturn === 'object') state.obraDetalheReturn = saved.obraDetalheReturn;
  if(saved.scrollMemory && typeof saved.scrollMemory === 'object'){
    if(saved.scrollMemory.dashboard && typeof saved.scrollMemory.dashboard.scrollY === 'number'){
      _dashboardScrollSaved = {scrollY: Math.max(0, saved.scrollMemory.dashboard.scrollY)};
    }
    if(saved.scrollMemory.pageOverlay && typeof saved.scrollMemory.pageOverlay === 'object'){
      Object.keys(saved.scrollMemory.pageOverlay).forEach(key => {
        const y = saved.scrollMemory.pageOverlay[key];
        if(typeof y === 'number' && Number.isFinite(y) && y >= 0) _pageOverlayScrollMemory[key] = y;
      });
    }
    if(typeof saved.scrollMemory.listPage === 'number' && Number.isFinite(saved.scrollMemory.listPage) && saved.scrollMemory.listPage >= 0){
      _listPageScrollMemory = saved.scrollMemory.listPage;
    }
  }
  if(saved.scrollSnapshot && typeof saved.scrollSnapshot === 'object' && typeof saved.scrollSnapshot.scrollY === 'number'){
    _bootScrollSnapshot = saved.scrollSnapshot;
    // Compatibilidade com estados gravados antes do mapa por contexto existir.
    if(!saved.scrollMemory){
      const y = Math.max(0, saved.scrollSnapshot.scrollY);
      if(saved.scrollSnapshot.container === 'main') _dashboardScrollSaved = {scrollY:y};
      else if(saved.scrollSnapshot.container === 'list-page') _listPageScrollMemory = y;
      else if(saved.scrollSnapshot.container === 'page-overlay' && saved.view && saved.view !== 'obra-detalhe'){
        _pageOverlayScrollMemory[pageOverlayScrollMemoryKey(saved.view, saved.listaAtivaId)] = y;
      }
    }
  }
  const search = document.getElementById('searchInput');
  if(search) search.value = state.busca || '';
}
// Guarda o snapshot de rolagem lido do armazenamento persistido (ver
// getUiStateSnapshot/loadUiState acima) até o primeiro render do boot
// consumi-lo, através de applyBootScrollSnapshot().
let _bootScrollSnapshot = null;
// Chamado uma única vez, logo ANTES do primeiro render do boot (continueInit
// / reloadAccountData) — arma o alvo de rolagem certo (grade principal,
// overlay de página ou página de lista) para que a primeira renderização já
// nasça na posição em que o usuário estava antes do app ser recarregado do
// zero, em vez de sempre começar do topo.
function applyBootScrollSnapshot(){
  const snap = _bootScrollSnapshot;
  _bootScrollSnapshot = null;
  if(!snap || typeof snap.scrollY !== 'number' || snap.scrollY <= 0) return;
  if(snap.container === 'main' && state.view === 'lista'){
    _pendingGridScrollTarget = { y: snap.scrollY };
  } else if(snap.container === 'page-overlay' && ['listas','lista-detalhe','estatisticas','obra-detalhe','historico','favoritos'].includes(state.view)){
    _pendingPageOverlayScrollTarget = { view: state.view, scrollY: snap.scrollY };
  } else if(snap.container === 'list-page'){
    _pendingListPageScrollTarget = { scrollY: snap.scrollY };
  }
}
function persistUiStateImmediately(){
  const key = nsKey(APP_STATE_STORAGE_KEY);
  let snapshot;
  let text;
  try{
    snapshot = getUiStateSnapshot();
    text = JSON.stringify(snapshot);
  }catch(_){ return; }
  // Grava primeiro a cópia síncrona; ela protege a preferência contra um
  // recarregamento imediato enquanto o IndexedDB ainda está a concluir.
  if(LOCAL_STORAGE_AVAILABLE){
    try{
      if(text.length <= LOCAL_STORAGE_MIRROR_LIMIT) window.localStorage.setItem(key, text);
    }catch(_){}
  }
  writePersistedJson(key, snapshot).catch(() => {});
}
const persistUiState = debounce(() => {
  writePersistedJson(nsKey(APP_STATE_STORAGE_KEY), getUiStateSnapshot());
}, 300);
// Mantém a posição de rolagem persistida atualizada enquanto o usuário rola
// a página — não só quando algo re-renderiza. persistUiState já é debounced
// (300ms) internamente, então isto é barato de chamar a cada evento.
window.addEventListener('scroll', () => { try{ persistUiState(); }catch(_){} }, {passive:true});
document.addEventListener('scroll', () => { try{ persistUiState(); }catch(_){} }, {passive:true, capture:true});

function showToast(type, message){
  const region = document.getElementById('toastRegion');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = message;
  region.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .25s'; setTimeout(()=>el.remove(), 260); }, 3800);
}

// Toast com botão "Desfazer" — usado nas ações destrutivas (apagar obra(s),
// limpar acervo) para dar uma janela de tempo em que o usuário pode reverter
// a ação em vez de perder os dados na hora.
function showUndoToast(message, undoFn, duration){
  const region = document.getElementById('toastRegion');
  const el = document.createElement('div');
  el.className = 'toast info toast-undo';
  const msg = document.createElement('span');
  msg.className = 'toast-undo-msg';
  msg.textContent = message;
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'toast-undo-btn';
  btn.textContent = 'Desfazer';
  let done = false;
  const dismiss = () => {
    if(done) return; done = true;
    el.style.opacity='0'; el.style.transition='opacity .25s';
    setTimeout(()=>el.remove(), 260);
  };
  const timer = setTimeout(dismiss, duration || 6000);
  btn.addEventListener('click', () => {
    if(done) return; done = true;
    clearTimeout(timer);
    try{ undoFn(); }catch(_){}
    el.style.opacity='0'; el.style.transition='opacity .25s';
    setTimeout(()=>el.remove(), 260);
  });
  el.appendChild(msg); el.appendChild(btn);
  region.appendChild(el);
}

const COMMON_GENRES_PT = [
  'Ação','Aventura','Animação','Artes marciais','Comédia','Crime','Documentário','Drama',
  'Fantasia','Ficção científica','Histórico','Horror','Mistério','Romance','Suspense',
  'Terror','Thriller','Escolar','Militar','Música','Esportes','Sobrenatural','Psicológico',
  'Slice of life','Seinen','Shoujo','Shounen','Josei','Isekai','Mecha','Cyberpunk',
  'Distopia','Pós-apocalíptico','Viagem no tempo','Superpoderes','Magia','Mitologia',
  'Vida cotidiana','Família','Infantil','Juvenil','Guerra','Policial','Biografia',
  'Autobiografia','Não ficção','Ficção juvenil','Graphic novel','Banda desenhada',
  'Webtoon','Manhwa','Manhua','Light novel','Novel clássica','Web novel'
];
// Cache curto: a lista era reconstruída e ordenada (localeCompare) a CADA tecla
// escrita no campo de gêneros, o que pesava em telefones mais lentos.
let _genreListCache = { list: null, at: 0, n: -1 };
const _genreNormMemo = new Map();
function _genreNorm(g){
  let v = _genreNormMemo.get(g);
  if(v === undefined){ v = normalizeLookupText(g); _genreNormMemo.set(g, v); }
  return v;
}
function getAllKnownGenres(){
  const now = Date.now();
  if(_genreListCache.list && _genreListCache.n === state.entries.length && (now - _genreListCache.at) < 2000) return _genreListCache.list;
  const set = new Set(COMMON_GENRES_PT);
  Object.values(GENRE_PT || {}).forEach(g => { if(g) set.add(g); });
  state.entries.forEach(e => (e.generos||[]).forEach(g => { if(g) set.add(g); }));
  const list = Array.from(set).sort((a,b)=>a.localeCompare(b, 'pt-BR'));
  _genreListCache = { list, at: now, n: state.entries.length };
  return list;
}
function getGenreSegments(value){
  return String(value || '').split(',').map(s => s.trim()).filter(Boolean);
}
function renderGenreSuggestBox(){
  const input = document.getElementById('f_generos');
  const box = document.getElementById('generosSuggestBox');
  if(!input || !box) return;
  const allGenres = getAllKnownGenres();
  const segments = input.value.split(',');
  const typing = (segments[segments.length - 1] || '').trim();
  const typingNorm = normalizeLookupText(typing);
  const selectedNorm = new Set(getGenreSegments(input.value).map(g => normalizeLookupText(g)));
  const filtered = typingNorm ? allGenres.filter(g => _genreNorm(g).includes(typingNorm)) : allGenres;
  if(!filtered.length){
    box.innerHTML = `<div class="genre-suggest-empty">${allGenres.length ? 'Nenhum gênero encontrado' : 'Nenhum gênero cadastrado ainda'}</div>`;
    return;
  }
  box.innerHTML = filtered.map(g => {
    const isSel = selectedNorm.has(_genreNorm(g));
    return `<div class="genre-suggest-item${isSel ? ' is-selected' : ''}" data-genre="${escapeHtml(g)}" role="option" aria-selected="${isSel}">`
      + `<span>${escapeHtml(g)}</span>`
      + `<span class="genre-suggest-check">✓</span>`
      + `</div>`;
  }).join('');
  if (typeof _syncGenreSuggestStripMode === 'function') { try{ _syncGenreSuggestStripMode(); }catch(_){} }
}
let _genreAutoOpenSuppressedUntil = 0;
function suppressGenreAutoOpen(ms){
  _genreAutoOpenSuppressedUntil = Date.now() + (ms || 500);
}
function isGenreAutoOpenSuppressed(){
  return Date.now() < _genreAutoOpenSuppressedUntil;
}
function _syncGenreSuggestStripMode(){
  const box = document.getElementById('generosSuggestBox');
  const input = document.getElementById('f_generos');
  const btn = document.getElementById('generosOpenListBtn');
  if(!box || !input) return;
  const ckbOpen = document.body.classList.contains('ckb-open');
  const focused = (document.activeElement === input) || input.matches(':focus');
  const listMode = !!(btn && btn.classList.contains('is-open'));
  const stripActive = ckbOpen && focused && !box.hidden && !listMode;
  const listActive = ckbOpen && !box.hidden && listMode;
  box.classList.toggle('is-ckb-strip', stripActive);
  box.classList.toggle('is-ckb-list', listActive);
  document.body.classList.toggle('ckb-suggest', stripActive);
  document.body.classList.toggle('ckb-list', listActive);
}

function openGenreSuggestBox(opts){
  const box = document.getElementById('generosSuggestBox');
  if(!box) return;
  if(!(opts && opts.force) && isGenreAutoOpenSuppressed()) return;
  renderGenreSuggestBox();
  box.hidden = false;
  _syncGenreSuggestStripMode();
}
function closeGenreSuggestBox(){
  const box = document.getElementById('generosSuggestBox');
  if(!box) return;
  box.hidden = true;
  box.classList.remove('is-ckb-strip');
  box.classList.remove('is-ckb-list');
  document.body.classList.remove('ckb-suggest');
  document.body.classList.remove('ckb-list');
}
function addGenreToInput(genre){
  const input = document.getElementById('f_generos');
  if(!input) return;
  // Descarta o segmento em digitação (última parte após a última vírgula) para
  // que o gênero selecionado substitua o que o usuário estava escrevendo.
  const rawSegments = String(input.value || '').split(',');
  const committed = rawSegments.slice(0, -1).map(s => s.trim()).filter(Boolean);
  const list = committed.slice();
  const normGenre = normalizeLookupText(genre);
  const idx = list.findIndex(s => normalizeLookupText(s) === normGenre);
  let removed = false;
  if(idx >= 0){ list.splice(idx, 1); removed = true; }
  else{ list.push(genre); }
  input.value = list.length ? list.join(', ') + (removed ? '' : ', ') : '';
  input.dispatchEvent(new Event('input', {bubbles:true}));
  // Não devolve foco ao input: em "modo lista" o input é readonly e devolver
  // foco reabriria o teclado; em modo digitação o input já está focado.
  try{ const end = input.value.length; input.setSelectionRange(end, end); }catch(_){}
  renderGenreSuggestBox();
}
function openGenreListMode(){
  const input = document.getElementById('f_generos');
  const btn = document.getElementById('generosOpenListBtn');
  if(!input) return;
  // MUTUAMENTE EXCLUSIVO: primeiro fecha o teclado, depois marca o input como
  // readonly para que o teclado virtual não reabra ao receber foco. Só então
  // abre a caixa de sugestões (lista completa de gêneros).
  if (window.__ckb && typeof window.__ckb.hide === 'function') { try{ window.__ckb.hide(); }catch(_){ } }
  try{ input.blur(); }catch(_){}
  input.setAttribute('readonly','readonly');
  if(btn){ btn.classList.add('is-open'); btn.setAttribute('aria-expanded','true'); const lbl = btn.querySelector('span'); if(lbl) lbl.textContent = 'Fechar lista de gêneros'; }
  openGenreSuggestBox({force:true});
}
function closeGenreListMode(){
  const input = document.getElementById('f_generos');
  const btn = document.getElementById('generosOpenListBtn');
  if(input) input.removeAttribute('readonly');
  if(btn){ btn.classList.remove('is-open'); btn.setAttribute('aria-expanded','false'); const lbl = btn.querySelector('span'); if(lbl) lbl.textContent = 'Escolher da lista de gêneros'; }
  closeGenreSuggestBox();
}
function setupGenreSuggestBox(){
  const input = document.getElementById('f_generos');
  const box = document.getElementById('generosSuggestBox');
  const btn = document.getElementById('generosOpenListBtn');
  if(!input || !box) return;
  // REGRA: teclado e caixa de sugestões são MUTUAMENTE EXCLUSIVOS.
  //  - Teclado ativo (input focado, editável) -> caixa de sugestões fechada.
  //  - Modo "lista de gêneros" (botão) ativo -> caixa aberta, teclado fechado,
  //    input em readonly (o utilizador só escolhe da lista).
  input.addEventListener('focus', () => {
    // Ao focar para digitar, mostra a tira de sugestões acima do teclado.
    if(!input.readOnly) openGenreSuggestBox();
  });
  input.addEventListener('click', (e) => {
    // BUGFIX: só reagir quando o clique é REALMENTE no input.
    // Cliques em botões do rodapé do modal (Cancelar/Atualizar) por vezes
    // eram interpretados aqui (delegação/ghost click) e "activavam" o campo
    // de gêneros mesmo o utilizador não o tendo tocado.
    if(e.target !== input) return;
    if(input.readOnly){
      // veio do modo lista: sair do modo lista e reactivar teclado.
      closeGenreListMode();
      try{ input.focus(); }catch(_){ }
      if (window.__ckb && typeof window.__ckb.show === 'function') { try{ window.__ckb.show(input); }catch(_){ } }
      openGenreSuggestBox();
      return;
    }
    // Toque em campo já editável: mantém teclado + tira de sugestões.
    openGenreSuggestBox();
  });
  input.addEventListener('input', () => {
    // Enquanto digita, mantém a tira de sugestões visível e filtrada.
    if(!input.readOnly){ openGenreSuggestBox(); }
  });
  if(btn){
    // Impede que o toque no botão foque/edite o input (o botão fica fora do
    // <label>, mas ainda assim reforçamos para evitar cliques fantasma).
    btn.addEventListener('pointerdown', (e) => {
      const startedOnButton = e.isTrusted && e.button === 0 && (e.target === btn || btn.contains(e.target));
      btn.__pointerGesture = startedOnButton ? {id:e.pointerId, startedAt:Date.now(), releasedAt:0, released:false} : null;
      e.preventDefault();
      e.stopPropagation();
    });
    btn.addEventListener('pointerup', (e) => {
      const gesture = btn.__pointerGesture;
      if(gesture && gesture.id === e.pointerId && (e.target === btn || btn.contains(e.target))){
        gesture.released = true;
        gesture.releasedAt = Date.now();
      }
    });
    btn.addEventListener('pointercancel', () => { btn.__pointerGesture = null; });
    btn.addEventListener('mousedown', (e) => { e.preventDefault(); e.stopPropagation(); });
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      // REGRA: este botão só atua quando a pessoa realmente o toca. Um "click"
      // sem toque prévio NO botão (clique fantasma depois de o layout mexer
      // enquanto se escreve, ou clique sintético) é ignorado. Ativação por
      // teclado físico (Enter/Espaço com o botão focado) continua a funcionar.
      const gesture = btn.__pointerGesture;
      const clickedButton = e.target === btn || btn.contains(e.target);
      const recentDirectPress = gesture && clickedButton && (Date.now() - gesture.startedAt) < 900;
      const trustedPointerClick = e.isTrusted && e.detail > 0
        && recentDirectPress && gesture.released && (Date.now() - gesture.releasedAt) < 700;
      // O teclado virtual às vezes fecha no pointerup e chama .click() no
      // botão antes do pointerup chegar ao próprio botão. Aceita esse click
      // sintético somente se a pressão real começou diretamente nele.
      const keyboardBridgeClick = !e.isTrusted && e.detail === 0
        && recentDirectPress && !gesture.released;
      const pointerActivated = trustedPointerClick || keyboardBridgeClick;
      const keyboardActivated = e.detail === 0 && e.isTrusted && document.activeElement === btn;
      btn.__pointerGesture = null;
      if(!pointerActivated && !keyboardActivated) return;
      const listOpen = btn.classList.contains('is-open');
      if(listOpen){
        // REGRA: fechar a lista NÃO deve reactivar o campo de gêneros.
        // Antes o input era refocado aqui, o que reabria teclado + sugestões
        // (o utilizador percebia como "o botão activa o campo em vez de fechar").
        closeGenreListMode();
        try{ input.blur(); }catch(_){ }
        if (window.__ckb && typeof window.__ckb.hide === 'function') { try{ window.__ckb.hide(); }catch(_){ } }
      } else {
        openGenreListMode();
      }
    });
  }
  box.addEventListener('mousedown', (e) => {
    const item = e.target.closest('.genre-suggest-item');
    if(!item) return;
    e.preventDefault();
    addGenreToInput(item.dataset.genre);
  });
  document.addEventListener('click', (e) => {
    if(box.hidden) return;
    if(e.target === input || box.contains(e.target)) return;
    if(btn && (e.target === btn || btn.contains(e.target))) return;
    // Toques no teclado virtual (que só existe quando a lista está fechada)
    // nunca chegam aqui na prática, mas mantém-se por segurança.
    if(e.target.closest && e.target.closest('#customKb')) return;
    closeGenreListMode();
  });
  input.addEventListener('keydown', (e) => {
    if(e.key === 'Escape'){ closeGenreListMode(); input.blur(); }
  });
}
function countByCategoria(){
  const counts = {}; CATEGORY_ORDER.forEach(c => counts[c]=0);
  state.entries.forEach(e => { if(counts[e.categoria]!==undefined) counts[e.categoria]++; });
  return counts;
}
function getFiltered(){
  const term = normalizeText(state.busca);
  const genreFilter = normalizeText(state.filtroGenero === 'todos' ? '' : state.filtroGenero);
  return state.entries.filter(e => {
    if(state.categoriaAtiva !== 'todos' && e.categoria !== state.categoriaAtiva) return false;
    if(state.categoriaAtiva === 'filme' && state.filmeSubAtivo !== 'todos'){
      const sub = String(e.subcategoria||'').toLowerCase();
      if(sub !== state.filmeSubAtivo) return false;
    }
    if(state.categoriaAtiva === 'novel' && state.novelSubAtivo !== 'todos'){
      const meta = NOVEL_SUBCAT_META[state.novelSubAtivo];
      const tipo = String(e.tipo_novel||'').toLowerCase().trim();
      if(!novelSubMatches(meta, tipo)) return false;
    }
    if(state.filtroStatus !== 'todos' && e.status !== state.filtroStatus) return false;
    if(state.filtroStatusOficial !== 'todos' && temStatusOficial(e.categoria) && e.status_oficial !== state.filtroStatusOficial) return false;
    if(genreFilter && !(e.generos||[]).some(g => normalizeText(g) === genreFilter)) return false;
    if(state.filtroTituloInicio !== 'todos'){
      const primeiroChar = e.titulo.toUpperCase().charAt(0);
      const ehNumero = /[0-9]/.test(primeiroChar);
      if(state.filtroTituloInicio !== 'todos'){
        if(state.filtroTituloInicio === '0'){
          if(!ehNumero) return false;
        } else {
          if(primeiroChar !== state.filtroTituloInicio) return false;
        }
      }
    }
    if(state.notaMinima > 0 && !(typeof e.nota === 'number' && e.nota >= state.notaMinima)) return false;
    if(state.favoritosOnly && !e.favorito) return false;
    if(state.filtroInacabadas && e.status === 'concluido') return false;
    if(state.filtroSemStatusOficial && (!temStatusOficial(e.categoria) || e.status_oficial)) return false;
    if(term){
      // Busca global: título tem prioridade, mas também procura em autor,
      // editora, gêneros, comentário, status e nas listas que contêm a obra.
      if(!entryMatchesSearchTerm(e, term)) return false;
    }
    return true;
  });
}
function entryMatchesSearchTerm(e, term){
  const nomesListas = (state.listas||[]).filter(l => Array.isArray(l.obraIds) && l.obraIds.includes(e.id)).map(l => l.nome);
  const camposTexto = [
    e.titulo, e.titulo_original, e.autor, e.editora, e.comentario,
    (e.generos||[]).join(' '),
    CATEGORY_META[e.categoria] ? CATEGORY_META[e.categoria].plural : '',
    statusLabel(e.status),
    (temStatusOficial(e.categoria) && e.status_oficial) ? officialStatusLabel(e.status_oficial) : '',
    e.subcategoria, e.tipo_novel,
    nomesListas.join(' ')
  ];
  const haystack = normalizeText(camposTexto.filter(Boolean).join(' '));
  return textMatchesSearchTerm(term, haystack);
}
const SEARCH_EQUIVALENT_GROUPS = [
  ['water','água','aguas','eau','wasser','acqua','mizu','水','물'],
  ['fire','fogo','fuego','feu','feuer','fuoco','hi','火','불'],
  ['earth','terra','tierra','terre','erde','tsuchi','土','땅'],
  ['wind','vento','viento','vent','kaze','風','바람'],
  ['air','ar','aire','luft','aria','kuki','空気','공기'],
  ['sea','mar','ocean','oceano','mer','meer','mare','umi','海','바다'],
  ['moon','lua','luna','lune','mond','tsuki','月','달'],
  ['sun','sol','soleil','sonne','sole','taiyo','太陽','해'],
  ['star','estrela','estrelas','estrella','étoile','stern','stella','hoshi','星','별'],
  ['flower','flor','flores','fleur','blume','fiore','hana','花','꽃'],
  ['love','amor','amour','liebe','amore','ai','愛','사랑'],
  ['night','noite','noche','nuit','nacht','notte','yoru','夜','밤'],
  ['day','dia','día','jour','tag','giorno','日','날'],
  ['world','mundo','monde','welt','mondo','sekai','世界','세계'],
  ['time','tempo','tiempo','temps','zeit','jikan','時間','시간'],
  ['life','vida','vie','leben','vita','inochi','命','생명'],
  ['death','morte','muerte','mort','tod','shi','死','죽음'],
  ['shadow','sombra','ombre','schatten','kage','影','그림자'],
  ['dark','escuro','oscuro','sombre','dunkel','scuro','yami','闇','어둠'],
  ['light','luz','lumiere','licht','luce','hikari','光','빛'],
  ['dragon','dragão','dragao','dragón','drache','drago','ryu','竜','용'],
  ['angel','anjo','ángel','ange','engel','angelo','tenshi','天使','천사'],
  ['demon','demônio','demonio','demon','démon','damon','demone','oni','鬼','악마'],
  ['ghost','fantasma','fantome','geist','yurei','幽霊','유령'],
  ['king','rei','rey','roi','konig','re','ou','王','왕'],
  ['queen','rainha','reina','reine','konigin','regina','joou','女王','여왕'],
  ['princess','princesa','princesse','prinzessin','principessa','hime','姫','공주'],
  ['hero','herói','heroe','héros','held','eroe','eiyu','英雄','영웅'],
  ['sword','espada','epee','schwert','spada','ken','剣','검'],
  ['magic','magia','magie','zauber','mahou','魔法','마법'],
  ['school','escola','escuela','ecole','schule','scuola','gakkou','学校','학교'],
  ['girl','menina','garota','niña','fille','madchen','ragazza','shoujo','少女','소녀'],
  ['boy','menino','garoto','niño','garçon','junge','ragazzo','shounen','少年','소년'],
  ['cat','gato','chat','katze','gatto','neko','猫','고양이'],
  ['dog','cão','cao','cachorro','perro','chien','hund','cane','inu','犬','개'],
  ['book','livro','libro','livre','buch','hon','本','책'],
  ['story','história','historia','histoire','geschichte','storia','monogatari','物語','이야기'],
  ['heart','coração','coracao','corazón','coeur','herz','cuore','kokoro','心','마음'],
  ['ice','gelo','hielo','glace','eis','ghiaccio','kori','氷','얼음'],
  ['rain','chuva','lluvia','pluie','regen','pioggia','ame','雨','비'],
  ['mountain','montanha','montaña','montagne','berg','montagna','yama','山','산'],
  ['forest','floresta','bosque','forêt','wald','foresta','mori','森','숲']
];
const SEARCH_EQUIVALENTS = new Map();
SEARCH_EQUIVALENT_GROUPS.forEach(group => {
  const aliases = Array.from(new Set(group.map(normalizeText).filter(Boolean)));
  aliases.forEach(alias => {
    let equivalents = SEARCH_EQUIVALENTS.get(alias);
    if(!equivalents){ equivalents = new Set(); SEARCH_EQUIVALENTS.set(alias, equivalents); }
    aliases.forEach(value => equivalents.add(value));
  });
});
const SEARCH_STOP_WORDS = new Set(
  'a an the and of to in on with for e de do da das dos um uma o os y el la los las le les du des un una une et der die ein eine und im auf mit von il lo gli di degli'.split(' ')
);
function searchWordAlternatives(word){
  const normalized = normalizeText(word);
  const exact = SEARCH_EQUIVALENTS.get(normalized);
  if(exact) return exact;
  const alternatives = new Set([normalized]);
  if(normalized.length >= 3){
    SEARCH_EQUIVALENTS.forEach((equivalents, alias) => {
      if(alias.startsWith(normalized)) equivalents.forEach(value => alternatives.add(value));
    });
  }
  return alternatives;
}
function textMatchesSearchTerm(term, haystack){
  const query = normalizeText(term);
  if(!query || haystack.includes(query)) return true;
  let words = query.split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const meaningfulWords = words.filter(word => !SEARCH_STOP_WORDS.has(word));
  if(meaningfulWords.length) words = meaningfulWords;
  return words.length > 0 && words.every(word =>
    Array.from(searchWordAlternatives(word)).some(alias => haystack.includes(alias))
  );
}
function progressoNumerico(e){
  if(e.categoria === 'filme') return 0;
  if(CATEGORIAS_COM_TEMPORADAS.includes(e.categoria)){
    const ts = e.temporadas || [];
    return ts.reduce((sum,t) => sum + (Math.floor(Number(t.episodios)||0)), 0);
  }
  if(e.categoria === 'novel'){
    const vs = e.volumes || [];
    return vs.reduce((sum,v) => {
      const lista = v.capitulos_lista;
      const caps = (lista && lista.length) ? capitulostotalNumericOnly(lista, 0) : Math.floor(Number(v.capitulos)||0);
      return sum + caps;
    }, 0);
  }
  return Math.floor(Number(e.progresso_simples)||0);
}
function getFilteredSorted(){
  const list = getFiltered();
  const sorters = {
    recente: (a,b) => (b.criado_em||0) - (a.criado_em||0),
    antigo:  (a,b) => (a.criado_em||0) - (b.criado_em||0),
    notaDesc:(a,b) => (b.nota ?? -1) - (a.nota ?? -1),
    notaAsc: (a,b) => (a.nota ?? 99) - (b.nota ?? 99),
    az:      (a,b) => a.titulo.localeCompare(b.titulo),
    za:      (a,b) => b.titulo.localeCompare(a.titulo),
    anoDesc: (a,b) => (b.ano||0) - (a.ano||0),
    anoAsc:  (a,b) => (a.ano||0) - (b.ano||0),
    progressoDesc: (a,b) => progressoNumerico(b) - progressoNumerico(a),
    atualizadoAsc: (a,b) => entryEditTimestamp(a) - entryEditTimestamp(b),
    atualizadoDesc: (a,b) => entryEditTimestamp(b) - entryEditTimestamp(a)
  };
  return list.sort(sorters[state.ordenacao] || sorters.recente);
}

function abbrevChapterName(nome){
  const s = String(nome||'').trim();
  if(!s) return '';
  // Palavras: usa iniciais das duas primeiras (ex: "Interlúdio Final" → "IF")
  const parts = s.split(/\s+/).filter(Boolean);
  if(parts.length >= 2){
    return (parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
  }
  // Palavra única: duas primeiras letras (ex: "Prólogo" → "Pr", "Epílogo" → "Ep")
  return s.slice(0,2).charAt(0).toUpperCase() + (s.slice(1,2).toLowerCase());
}

function progressoTexto(e){
  if(e.categoria === 'filme') return '';
  if(CATEGORIAS_COM_TEMPORADAS.includes(e.categoria)){
    const ts = e.temporadas || [];
    if(ts.length){ const lt = ts[ts.length-1]; return 'T' + lt.numero + ' · Ep ' + lt.episodios; }
    return '';
  }
  if(e.categoria === 'novel'){
    const vs = e.volumes || [];
    if(vs.length){
      // Prefere o último volume com capítulos numéricos; recua para o último se todos têm 0
      let lv = vs[vs.length-1];
      for(let _vi = vs.length-1; _vi >= 0; _vi--){
        const _v = vs[_vi];
        const _c = capitulostotalNumericOnly(_v.capitulos_lista||[], 0);
        if(_c > 0){ lv = _v; break; }
      }
      const _ptLista = lv.capitulos_lista||[];
      const caps = _ptLista.length ? capitulostotalNumericOnly(_ptLista, 0) : Math.floor(Number(lv.capitulos)||0);
      const volLabel = (lv.nome && lv.nome.trim()) ? lv.nome.trim() : ('V' + lv.numero);
      // Regra: abreviatura do capítulo nomeado só aparece quando o ÚLTIMO
      // registo do volume for um capítulo escrito. Se houver um capítulo
      // numérico registado depois de um nomeado, a abreviatura não aparece.
      const _lastEntry = _ptLista.length ? _ptLista[_ptLista.length - 1] : null;
      const _lastIsNamed = !!(_lastEntry && _lastEntry.nome && _lastEntry.nome.trim());
      const namedAbbr = _lastIsNamed ? abbrevChapterName(_lastEntry.nome) : '';
      // Página do último registo — anexada logo depois do campo a que pertence
      // (abreviatura do nomeado, ou número de capítulo), para deixar claro
      // qual dos dois valores a página está a referenciar.
      const pagina = (_lastEntry && _lastEntry.pagina && Number(_lastEntry.pagina) > 0)
        ? Math.floor(Number(_lastEntry.pagina)) : null;
      const pageStr = pagina ? ' · Pág. ' + pagina : '';
      let capStr;
      if(_lastIsNamed){
        const capPart = caps > 0 ? ('Cap ' + caps) : '';
        capStr = capPart ? (capPart + ' · ' + namedAbbr + pageStr) : (namedAbbr + pageStr);
      } else {
        capStr = caps > 0 ? ('Cap ' + caps + pageStr) : '';
      }
      return volLabel + (capStr ? ' · ' + capStr : '');

    }
    return '';
  }
  if(e.categoria === 'livro'){
    const p = Number(e.progresso_simples)||0;
    const tot = Number(e.paginas_total)||0;
    if(tot) return 'Pág. ' + p + '/' + tot;
    if(p) return 'Pág. ' + p;
    return '';
  }
  return e.progresso_simples ? ('Cap. ' + e.progresso_simples) : '';
}

function extraQuantidade(ex){
  const n = Number(ex && ex.quantidade);
  return Number.isFinite(n) && n > 0 ? Math.max(1, Math.floor(n)) : 1;
}
function extraAceitaQuantidade(ex){
  return ex && (ex.tipo === 'OVA' || ex.tipo === 'Filme' || ex.tipo === 'Extra');
}
function pluralExtra(tipo, qtd){
  if(tipo === 'OVA') return qtd === 1 ? 'OVA' : 'OVAs';
  if(tipo === 'Filme') return qtd === 1 ? 'filme' : 'filmes';
  if(tipo === 'Extra') return qtd === 1 ? 'extra' : 'extras';
  return tipo || 'extra';
}
function extraLabel(ex){
  const qtd = extraQuantidade(ex);
  const nome = (ex && ex.nome ? String(ex.nome).trim() : '');
  if(nome) return qtd > 1 ? `${nome} (${qtd} ${pluralExtra(ex.tipo, qtd)})` : nome;
  return `${qtd} ${pluralExtra(ex && ex.tipo, qtd)}`;
}

function isValidIsoDate(value){
  if(typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}
function validationNumber(value, options){
  options = options || {};
  if(value === null || value === undefined || value === '') return {empty:true, valid:true};
  const n = Number(value);
  const valid = Number.isFinite(n) && (!options.integer || Number.isInteger(n)) && (options.min === undefined || n >= options.min) && (options.max === undefined || n <= options.max);
  return {empty:false, valid, value:n};
}
function validateEntry(data){
  const errors = {};
  const addError = (key, message) => { if(!errors[key]) errors[key] = message; };
  const categoria = data && data.categoria;
  const titulo = String(data && data.titulo || '').trim();
  const tituloOriginal = String(data && data.titulo_original || '').trim();

  if(!titulo) addError('titulo', 'O título é obrigatório.');
  else if(titulo.length > 200) addError('titulo', 'Título muito longo (máx. 200 caracteres).');
  if(tituloOriginal.length > 200) addError('titulo', 'O título original não pode ultrapassar 200 caracteres.');
  if(!CATEGORY_META[categoria]) addError('categoria', 'Selecione uma categoria válida.');
  if(!STATUS_META[data.status]) addError('status', 'Selecione um status pessoal válido.');

  if(data.ano !== null && data.ano !== undefined && data.ano !== ''){
    const ano = validationNumber(data.ano, {integer:true, min:1900, max:currentYear()+1});
    if(!ano.valid) addError('ano', 'Informe um ano inteiro entre 1900 e ' + (currentYear()+1) + '.');
  }

  const inicioValido = !data.data_inicio || isValidIsoDate(data.data_inicio);
  const fimValido = !data.data_fim || isValidIsoDate(data.data_fim);
  if(!inicioValido || !fimValido) addError('datas', 'Informe datas válidas no formato indicado.');
  else if(data.data_inicio && data.data_fim && data.data_fim < data.data_inicio) addError('datas', 'A data de conclusão não pode ser anterior à data de início.');

  if(data.nota !== null && data.nota !== undefined && data.nota !== ''){
    const nota = validationNumber(data.nota, {min:0, max:10});
    if(!nota.valid || Math.abs((nota.value * 2) - Math.round(nota.value * 2)) > 1e-9) addError('nota', 'A nota deve estar entre 0 e 10, em passos de 0,5.');
  }

  if(temStatusOficial(categoria)){
    if(data.status_oficial && !OFFICIAL_STATUS_META[data.status_oficial]) addError('status_oficial', 'Selecione um Status Oficial válido.');
  } else if(data.status_oficial) {
    addError('status_oficial', 'Esta categoria não aceita Status Oficial.');
  }

  if(categoria === 'filme'){
    if(data.subcategoria && !FILME_SUBCATEGORIAS.includes(normalizeText(data.subcategoria))) addError('detalhes', 'Selecione uma subcategoria de filme válida.');
    if(data.duracao_min !== null && data.duracao_min !== undefined && data.duracao_min !== ''){
      const duracao = validationNumber(data.duracao_min, {integer:true, min:0});
      if(!duracao.valid) addError('detalhes', 'A duração do filme deve ser um número inteiro igual ou superior a zero.');
    }
  }
  if(categoria === 'novel' && data.tipo_novel && !BONUS_FIELDS.novel[0].options.includes(data.tipo_novel)) addError('detalhes', 'Selecione um tipo de novel válido.');
  if(categoria === 'livro' && data.paginas_total !== null && data.paginas_total !== undefined && data.paginas_total !== ''){
    const totalPaginas = validationNumber(data.paginas_total, {integer:true, min:1});
    if(!totalPaginas.valid) addError('detalhes', 'O total de páginas deve ser um número inteiro superior a zero.');
    else if(data.progresso_simples !== null && data.progresso_simples !== undefined && Number(data.progresso_simples) > totalPaginas.value) addError('progresso_simples', 'As páginas lidas não podem ultrapassar o total de páginas.');
  }

  const validateExtras = (extras) => {
    if(!Array.isArray(extras)) return false;
    for(const extra of extras){
      if(!extra || !['OVA','Extra','Filme'].includes(extra.tipo)) return false;
      const nome = String(extra.nome || '').trim();
      const qtd = validationNumber(extra.quantidade, {integer:true, min:1});
      if(!nome && qtd.empty) return false;
      if(!qtd.empty && !qtd.valid) return false;
      if(nome && !qtd.empty) return false;
    }
    return true;
  };

  if(CATEGORIAS_COM_TEMPORADAS.includes(categoria)){
    if(!Array.isArray(data.temporadas) || !data.temporadas.length) addError('temporadas', 'Adicione pelo menos uma temporada.');
    else {
      for(const temporada of data.temporadas){
        const episodios = validationNumber(temporada.episodios, {integer:true, min:0});
        if(!STATUS_META[temporada.status] || !episodios.valid){
          addError('temporadas', 'Cada temporada deve ter um status válido e um número inteiro de episódios igual ou superior a zero.');
          break;
        }
        if(!validateExtras(temporada.extras || [])){
          addError('temporadas', 'Verifique os extras: informe um nome ou uma quantidade inteira positiva, mas não ambos.');
          break;
        }
      }
      if(!errors.temporadas && Array.isArray(data.extras_independentes) && !validateExtras(data.extras_independentes)) addError('temporadas', 'Verifique os extras independentes: informe um nome ou uma quantidade inteira positiva, mas não ambos.');
    }
  }

  if(categoria === 'novel'){
    if(!Array.isArray(data.volumes) || !data.volumes.length) addError('volumes', 'Adicione pelo menos um volume.');
    else {
      const nomes = new Set();
      for(let i=0; i<data.volumes.length; i++){
        const volume = data.volumes[i];
        const capitulos = validationNumber(volume.capitulos, {integer:true, min:0});
        const nome = normalizeText((volume.nome || '').trim() || ('Volume ' + (i+1)));
        if(!STATUS_META[volume.status] || !capitulos.valid){ addError('volumes', 'Cada volume deve ter um status válido e um número inteiro de capítulos igual ou superior a zero.'); break; }
        if(nomes.has(nome)){ addError('volumes', 'Dois ou mais volumes têm o mesmo nome. Renomeie-os antes de guardar.'); break; }
        nomes.add(nome);
        if(!Array.isArray(volume.capitulos_lista)) continue;
        for(const capitulo of volume.capitulos_lista){
          const qtd = validationNumber(capitulo.quantidade, {integer:true, min:1});
          const pagina = validationNumber(capitulo.pagina, {integer:true, min:1});
          const nomeCapitulo = String(capitulo.nome || '').trim();
          if(!nomeCapitulo && qtd.empty || (!qtd.empty && !qtd.valid) || (!pagina.empty && !pagina.valid) || (!nomeCapitulo && qtd.empty)){
            addError('volumes', 'Cada capítulo deve ter um nome ou uma quantidade inteira positiva; a página, quando indicada, também deve ser positiva.');
            break;
          }
        }
        if(errors.volumes) break;
      }
    }
  }

  if(['manga','manhua','manhwa','livro'].includes(categoria)){
    const progresso = validationNumber(data.progresso_simples, {min:0});
    if(!progresso.valid || (categoria === 'livro' && !Number.isInteger(progresso.value))) addError('progresso_simples', categoria === 'livro' ? 'O progresso do livro deve ser um número inteiro igual ou superior a zero.' : 'O progresso não pode ser negativo nem inválido.');
  }

  if(!data.capa_base64 && !data.capa_url) addError('capa', 'Selecione uma capa: envie uma imagem, busque online ou cole uma URL.');
  else if(data.capa_url && !data.capa_base64 && !isValidUrl(data.capa_url)) addError('capa', 'A URL da capa não parece válida.');

  return {valid: Object.keys(errors).length === 0, errors};
}
function checkDuplicate(titulo, categoria, excludeId, tituloOriginal){
  // Normalização rigorosa: ignora acentuação, maiúsculas/minúsculas e espaços
  // duplicados/extremidades, para pegar variações como "Naruto", "NARUTO!",
  // "  naruto " ou "Nárutô" como o mesmo título. Compara também o título
  // original em ambos os sentidos, já que a mesma obra pode ter sido
  // cadastrada uma vez pelo título traduzido e outra pelo original.
  const norm = s => normalizeText(s).replace(/[^\p{L}\p{N}]+/gu, ' ').replace(/\s+/g, ' ').trim();
  const t = norm(titulo);
  const to = norm(tituloOriginal || '');
  if(!t && !to) return false;
  return state.entries.some(e => {
    if(e.id === excludeId) return false;
    if(e.categoria !== categoria) return false;
    const et = norm(e.titulo);
    const eto = norm(e.titulo_original || '');
    if(t && (et === t || (eto && eto === t))) return true;
    if(to && (et === to || (eto && eto === to))) return true;
    return false;
  });
}

function renderSidebar(){
  const counts = countByCategoria();
  const total = state.entries.length;
  const mobileCatBar = document.getElementById('mobileCatBar');
  let html = '<div class="sidebar-section-label">Acervo</div>';
  html += navItemHtml('todos', 'Todos os itens', 'i-shelf', total, 'var(--c-gold)');
  html += '<div class="sidebar-section-label">Categorias</div>';
  // Todas as categorias ficam visíveis para que a navegação seja completa,
  // inclusive antes de o primeiro item de uma categoria ser cadastrado.
  CATEGORY_ORDER.forEach(cat => { const meta = CATEGORY_META[cat]; html += navItemHtml(cat, meta.plural, meta.icon, counts[cat], meta.color); });
  html += '<div class="sidebar-section-label">Painel</div>';
  html += `<button class="nav-item ${state.view==='estatisticas'?'is-active':''}" data-view="estatisticas" style="--cat-color:var(--c-gold)"><svg class="icon"><use href="#i-chart"/></svg> Visão geral</button>`;
  html += `<button class="nav-item ${(state.view==='listas'||state.view==='lista-detalhe')?'is-active':''}" data-view="listas" style="--cat-color:var(--c-gold)"><svg class="icon"><use href="#i-list"/></svg> Listas</button>`;
  html += `<button class="nav-item ${state.view==='historico'?'is-active':''}" data-view="historico" style="--cat-color:var(--c-gold)"><svg class="icon"><use href="#i-history"/></svg> Atividades</button>`;
  html += `<button class="nav-item ${state.view==='favoritos'?'is-active':''}" data-view="favoritos" style="--cat-color:var(--c-rose)"><svg class="icon"><use href="#i-heart"/></svg> Favoritos <span class="count">${state.entries.filter(e => e.favorito).length}</span></button>`;
  // Histórico — últimas obras visitadas
  const histIds = (state.historico||[]).filter(id => state.entries.some(e => e.id === id)).slice(0, 8);
  if(histIds.length){
    html += '<div class="sidebar-section-label" style="display:flex;align-items:center;justify-content:space-between;gap:6px;">Histórico<button type="button" data-action="clear-history" title="Limpar histórico" style="background:none;border:0;color:var(--text-faint);cursor:pointer;font-size:0.6rem;">Limpar</button></div>';
    histIds.forEach(id => {
      const en = state.entries.find(x => x.id === id);
      if(!en) return;
      const m = CATEGORY_META[en.categoria] || {color:'var(--c-gold)', icon:'i-shelf'};
      html += `<button class="nav-item" data-history-id="${en.id}" style="--cat-color:${m.color};" title="${escapeHtml(en.titulo)}"><svg class="icon"><use href="#${m.icon}"/></svg><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(en.titulo)}</span></button>`;
    });
  }
  document.getElementById('sidebar').innerHTML = html;
  if(mobileCatBar){
    if(state.view === 'lista'){
      mobileCatBar.hidden = false;
      mobileCatBar.innerHTML = chipToggleHtml('todos', 'Todos', total) + CATEGORY_ORDER.map(cat => chipToggleHtml(cat, CATEGORY_META[cat].plural, counts[cat])).join('');
    } else {
      mobileCatBar.innerHTML = '';
      mobileCatBar.hidden = true;
    }
  }
}
function navItemHtml(key, label, icon, count, color){
  const active = (state.view==='lista' && state.categoriaAtiva===key) ? 'is-active' : '';
  return `<button class="nav-item ${active}" data-cat="${key}" style="--cat-color:${color}"><svg class="icon"><use href="#${icon}"/></svg><span>${escapeHtml(label)}</span><span class="count">${count}</span></button>`;
}
function chipToggleHtml(key, label, count){
  const on = (state.view==='lista' && state.categoriaAtiva===key) ? 'is-on' : '';
  return `<button class="chip-toggle ${on}" data-cat="${key}">${escapeHtml(label)} · ${count}</button>`;
}

function renderListsPanel(){
  const searchInput = document.getElementById('listsPanelSearch');
  const content = document.getElementById('listsPanelContent');
  if(!searchInput || !content) return;
  
  const searchTerm = (searchInput.value || '').toLowerCase();
  let filteredListas = state.listas.filter(l => l.nome.toLowerCase().includes(searchTerm));
  
  if(filteredListas.length === 0){
    content.innerHTML = '<div class="lists-panel-empty">' + (searchTerm ? 'Nenhuma lista encontrada' : 'Nenhuma lista criada ainda') + '</div>';
  } else {
    let html = '';
    filteredListas.forEach(lista => {
      const itemCount = lista.obraIds.length;
      const isActive = state.listaAtivaId === lista.id;
      html += `
        <button class="lists-panel-item ${isActive ? 'is-active' : ''}" data-lista-id="${lista.id}">
          <svg class="icon"><use href="#i-folder-plus"/></svg>
          <div class="lists-panel-item-info">
            <div class="lists-panel-item-name" title="${escapeHtml(lista.nome)}">${escapeHtml(lista.nome)}</div>
            <div class="lists-panel-item-count">${itemCount} ${itemCount===1 ? 'item' : 'itens'}</div>
          </div>
        </button>
      `;
    });
    content.innerHTML = html;
    
    document.querySelectorAll('.lists-panel-item').forEach(item => {
      item.addEventListener('click', () => {
        const listaId = item.dataset.listaId;
        state.listaAtivaId = listaId;
        if(window.__pushNav) window.__pushNav();
        state.view = 'lista-detalhe';
        exitSelectionMode();
        document.getElementById('listsPanel').classList.remove('is-open');
        const backdrop = document.getElementById('listsPanelBackdrop');
        if(backdrop) backdrop.classList.remove('is-open');
        renderMain();
      });
    });
  }
}

function categoriaTemObras(){
  if(state.categoriaAtiva === 'todos') return state.entries.length > 0;
  return state.entries.some(e => e.categoria === state.categoriaAtiva);
}
function genresForActiveCategory(){
  const cat = state.categoriaAtiva;
  const set = new Set();
  state.entries.forEach(e => {
    if(cat !== 'todos' && e.categoria !== cat) return;
    (e.generos||[]).forEach(g => set.add(g));
  });
  return Array.from(set).sort((a,b)=>a.localeCompare(b));
}
function filmeSubChipsHtml(){
  if(state.categoriaAtiva !== 'filme') return '';
  const total = state.entries.filter(e => e.categoria === 'filme').length;
  const counts = {cinema:0, desenho:0, anime:0};
  state.entries.forEach(e => {
    if(e.categoria !== 'filme') return;
    const s = String(e.subcategoria||'').toLowerCase();
    if(counts[s] !== undefined) counts[s]++;
  });
  const chip = (key, label, n) => `<button class="chip-toggle filme-sub-chip ${state.filmeSubAtivo===key?'is-on':''}" data-filme-sub="${key}">${escapeHtml(label)} · ${n}</button>`;
  return `<div class="filme-subcat-bar">${chip('todos','Todos',total)}${FILME_SUBCATEGORIAS.map(k => chip(k, FILME_SUBCAT_META[k].label, counts[k])).join('')}</div>`;
}
function novelSubChipsHtml(){
  if(state.categoriaAtiva !== 'novel') return '';
  const total = state.entries.filter(e => e.categoria === 'novel').length;
  const counts = {light:0, web:0, classica:0};
  state.entries.forEach(e => {
    if(e.categoria !== 'novel') return;
    NOVEL_SUBCATEGORIAS.forEach(key => {
      if(novelSubMatches(NOVEL_SUBCAT_META[key], e.tipo_novel)) counts[key]++;
    });
  });
  const chip = (key, label, n) => `<button class="chip-toggle filme-sub-chip ${state.novelSubAtivo===key?'is-on':''}" data-novel-sub="${key}">${escapeHtml(label)} · ${n}</button>`;
  return `<div class="filme-subcat-bar">${chip('todos','Todos',total)}${NOVEL_SUBCATEGORIAS.map(k => chip(k, NOVEL_SUBCAT_META[k].label, counts[k])).join('')}</div>`;
}
function viewModeControlsHtml(scope, active, label){
  const options = scope === 'obras'
    ? [['cards','Cartões','i-grid'],['compact','Compacto','i-list'],['rows','Lista','i-list']]
    : scope === 'listas'
      ? [['cards','Cartões','i-grid'],['rows','Lista','i-list']]
      : [['rows','Lista','i-list'],['cards','Cartões','i-grid']];
  return `<div class="view-mode-controls" data-view-scope="${scope}" role="group" aria-label="${label}">
    <span class="view-mode-label">${label}</span>
    <div class="view-mode-buttons">${options.map(([mode, text, icon]) =>
      `<button type="button" class="view-mode-btn ${active===mode?'is-active':''}" data-view-mode="${mode}" title="${text}" aria-label="${text}" aria-pressed="${active===mode}">
        <svg class="icon"><use href="#${icon}"/></svg><span>${text}</span>
      </button>`).join('')}</div>
  </div>`;
}
function bindViewModeControls(root, scope, onChange){
  if(!root) return;
  root.querySelectorAll(`[data-view-scope="${scope}"] [data-view-mode]`).forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.dataset.viewMode;
      onChange(mode);
    });
  });
}
// ---- Âncora de posição ao trocar o tipo de visualização ----
// Antes de trocar (cartões <-> compacto <-> lista), guardamos qual item está
// no topo da área visível e a que distância do topo ele está. Depois da
// troca, reposicionamos o scroll para que o MESMO item continue no mesmo
// ponto da tela, em vez de a página "saltar" para outra posição.
function getActiveScrollerEl(){
  const listPageContent = document.getElementById('listPageContent');
  if(typeof listPageState !== 'undefined' && listPageState && listPageState.isOpen && listPageContent) return listPageContent;
  const pageOverlay = document.getElementById('pageOverlay');
  if(pageOverlay && pageOverlay.classList.contains('is-open')) return pageOverlay;
  const { el, useWindow } = getMainScroller();
  return useWindow ? null : el;
}
function _scrollerTop(el){ return el ? el.scrollTop : (window.pageYOffset || document.documentElement.scrollTop || 0); }
function _setScrollerTop(el, y){
  const next = Math.max(0, y);
  if(el) el.scrollTop = next;
  else window.scrollTo(0, next);
}
function getViewAnchorTop(root, scroller){
  const scope = root || document;
  const scrollerTop = scroller ? scroller.getBoundingClientRect().top : 0;
  const candidates = [
    scope.querySelector && scope.querySelector('.filterbar'),
    document.querySelector('#pageOverlay .page-overlay-header'),
    document.querySelector('#listPageOverlay .list-page-header'),
    scope.querySelector && scope.querySelector('.action-box'),
    document.querySelector('#pageOverlayBody .action-box')
  ].filter(Boolean);
  let refTop = scrollerTop;
  candidates.forEach(el => {
    const r = el.getBoundingClientRect();
    if(r.bottom > refTop && r.top <= refTop + 12) refTop = Math.max(refTop, r.bottom);
  });
  return refTop + 8;
}
function captureViewAnchor(root, itemSelector){
  try{
    const scope = root || document;
    const items = Array.from(scope.querySelectorAll(itemSelector));
    if(!items.length) return null;
    const scroller = getActiveScrollerEl();
    const refTop = getViewAnchorTop(scope, scroller);
    for(const el of items){
      const r = el.getBoundingClientRect();
      if(r.height === 0) continue;
      if(r.bottom > refTop) return { el, offset: r.top - refTop };
    }
    const last = items[items.length - 1];
    return { el: last, offset: last.getBoundingClientRect().top - refTop };
  }catch(_){ return null; }
}
function restoreViewAnchor(anchor){
  if(!anchor || !anchor.el || !anchor.el.isConnected) return;
  const scroller = getActiveScrollerEl();
  const refTop = getViewAnchorTop(document, scroller);
  const current = anchor.el.getBoundingClientRect().top - refTop;
  const delta = current - anchor.offset;
  if(Math.abs(delta) < 1) return;
  _setScrollerTop(scroller, _scrollerTop(scroller) + delta);
}
function withViewAnchor(root, itemSelector, apply){
  const anchor = captureViewAnchor(root, itemSelector);
  apply();
  restoreViewAnchor(anchor);
  requestAnimationFrame(() => {
    restoreViewAnchor(anchor);
    requestAnimationFrame(() => restoreViewAnchor(anchor));
    setTimeout(() => restoreViewAnchor(anchor), 120);
  });
}
function applyViewModeWithoutRebuild(root, scope, mode, containerSelector){
  if(!root) return false;
  const container = root.querySelector(containerSelector);
  if(!container) return false;
  Array.from(container.classList).forEach(className => {
    if(className.startsWith('view-mode-')) container.classList.remove(className);
  });
  container.classList.add(`view-mode-${mode}`);
  root.querySelectorAll(`[data-view-scope="${scope}"] [data-view-mode]`).forEach(btn => {
    const active = btn.dataset.viewMode === mode;
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-pressed', String(active));
  });
  requestAnimationFrame(() => {
    if(typeof ensureOrnamentVisibility === 'function') ensureOrnamentVisibility();
    window.dispatchEvent(new Event('resize'));
  });
  return true;
}
function rerenderKeepingPagePosition(){
  const snapshot = getActiveScrollSnapshot();
  renderMain();
  requestAnimationFrame(() => requestAnimationFrame(() => {
    if(snapshot.container === 'page-overlay'){
      restoreElementScrollUntilStable(document.getElementById('pageOverlay'), snapshot.scrollY);
    } else if(snapshot.container === 'list-page'){
      restoreElementScrollUntilStable(document.getElementById('listPageContent'), snapshot.scrollY);
    } else {
      restoreScrollUntilStable(() => {
        setScrollerPos(snapshot.scrollY);
        return {height:getScrollerHeight(), landed:Math.abs(getScrollerPos()-snapshot.scrollY)<1};
      });
    }
  }));
}
// Ao trocar o MODO de visualização (Cartões/Compacto/Lista), cada layout tem
// uma altura de item bem diferente — então restaurar a mesma posição em
// PIXELS acaba mostrando um item diferente do que a pessoa estava vendo.
// Estas duas funções guardam qual item específico (pelo id) está visível no
// topo antes da troca, e o recolocam no topo depois — então trocar de
// visualização enquanto se olha para a obra/lista X continua mostrando a
// obra/lista X, não importa o quanto o layout novo seja mais alto ou baixo.
function getTopVisibleItemId(scrollEl, itemSelector, idAttr){
  if(!scrollEl) return null;
  const headerEl = scrollEl.querySelector('.page-overlay-header') || document.querySelector('#pageOverlay .page-overlay-header');
  const headerH = headerEl ? headerEl.getBoundingClientRect().height : 0;
  const threshold = scrollEl.getBoundingClientRect().top + headerH + 4;
  const items = scrollEl.querySelectorAll(itemSelector);
  for(const item of items){
    if(item.getBoundingClientRect().bottom > threshold) return item.getAttribute(idAttr);
  }
  return null;
}
function scrollItemIntoView(scrollEl, itemSelector, idAttr, id){
  if(!scrollEl || !id) return false;
  const headerEl = scrollEl.querySelector('.page-overlay-header') || document.querySelector('#pageOverlay .page-overlay-header');
  const headerH = headerEl ? headerEl.getBoundingClientRect().height : 0;
  const item = Array.from(scrollEl.querySelectorAll(itemSelector)).find(el => el.getAttribute(idAttr) === id);
  if(!item) return false;
  const delta = item.getBoundingClientRect().top - scrollEl.getBoundingClientRect().top - headerH - 8;
  scrollEl.scrollTop += delta;
  return true;
}
// Roda depois que rerenderKeepingPagePosition() já assentou (ela mesma usa
// dois requestAnimationFrame encadeados), para a correção pelo id do item
// ter a palavra final sobre a posição em pixels — que fica só como uma
// posição inicial razoável enquanto o item exato ainda não é localizado.
function refineScrollToItem(scrollElId, itemSelector, idAttr, anchorId){
  if(!anchorId) return;
  requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(() => {
    scrollItemIntoView(document.getElementById(scrollElId), itemSelector, idAttr, anchorId);
  })));
}
function renderFilterbar(filteredList){
  const filterbar = document.getElementById('filterbar');
  filterbar.classList.remove('pdf-menu-open');
  if(state.view !== 'lista'){
    filterbar.innerHTML='';
    filterbar.hidden = true;
    return;
  }
  // Se a categoria ativa não tem nenhuma obra, mostramos apenas os controlos
  // essenciais (pesquisa fica no header, mas escondemos os selects de status/
  // gênero/etc para a barra não "encher" com filtros irrelevantes).
  const temObras = categoriaTemObras();
  filterbar.hidden = false;
  const filtered = Array.isArray(filteredList) ? filteredList : getFilteredSorted();
  const genreOptions = genresForActiveCategory().map(g => `<option value="${escapeHtml(g)}" ${state.filtroGenero===g?'selected':''}>${escapeHtml(g)}</option>`).join('');
  if(!temObras){
    filterbar.classList.add('filterbar-empty');
    filterbar.innerHTML = filmeSubChipsHtml() + novelSubChipsHtml() + `
      <div class="filterbar-empty-msg">Nenhuma obra nesta categoria ainda.</div>
     <div class="filter-spacer"></div>
      <span class="results-count">0 ITENS</span>`;
    const subChips = filterbar.querySelectorAll('[data-filme-sub]');
    subChips.forEach(btn => btn.addEventListener('click', () => { state.filmeSubAtivo = btn.dataset.filmeSub; renderMain(); }));
    filterbar.querySelectorAll('[data-novel-sub]').forEach(btn => btn.addEventListener('click', () => { state.novelSubAtivo = btn.dataset.novelSub; renderMain(); }));
    return;
  }
  filterbar.classList.remove('filterbar-empty');
  filterbar.innerHTML = filmeSubChipsHtml() + novelSubChipsHtml() + `
    <select id="selStatus" title="Status pessoal" aria-label="Status pessoal"><option value="todos">Todos os status</option>${statusOptionsHtml(state.filtroStatus)}</select>
    ${temStatusOficial(state.categoriaAtiva) ? `<select id="selStatusOficial" title="Status Oficial" aria-label="Status Oficial"><option value="todos">Todos os Status Oficiais</option>${OFFICIAL_STATUS_ORDER.slice().sort((a,b) => officialStatusLabel(a).localeCompare(officialStatusLabel(b), 'pt-BR')).map(s => `<option value="${s}" ${s===state.filtroStatusOficial?'selected':''}>${officialStatusLabel(s)}</option>`).join('')}</select>` : ''}
    <select id="selGenero" title="Gêneros" aria-label="Gêneros"><option value="todos">Todos os gêneros</option>${genreOptions}</select>
    <select id="selTituloInicio" title="Título inicial" aria-label="Título inicial"><option value="todos">Todas as letras</option><option value="A" ${state.filtroTituloInicio==='A'?'selected':''}>A</option><option value="B" ${state.filtroTituloInicio==='B'?'selected':''}>B</option><option value="C" ${state.filtroTituloInicio==='C'?'selected':''}>C</option><option value="D" ${state.filtroTituloInicio==='D'?'selected':''}>D</option><option value="E" ${state.filtroTituloInicio==='E'?'selected':''}>E</option><option value="F" ${state.filtroTituloInicio==='F'?'selected':''}>F</option><option value="G" ${state.filtroTituloInicio==='G'?'selected':''}>G</option><option value="H" ${state.filtroTituloInicio==='H'?'selected':''}>H</option><option value="I" ${state.filtroTituloInicio==='I'?'selected':''}>I</option><option value="J" ${state.filtroTituloInicio==='J'?'selected':''}>J</option><option value="K" ${state.filtroTituloInicio==='K'?'selected':''}>K</option><option value="L" ${state.filtroTituloInicio==='L'?'selected':''}>L</option><option value="M" ${state.filtroTituloInicio==='M'?'selected':''}>M</option><option value="N" ${state.filtroTituloInicio==='N'?'selected':''}>N</option><option value="O" ${state.filtroTituloInicio==='O'?'selected':''}>O</option><option value="P" ${state.filtroTituloInicio==='P'?'selected':''}>P</option><option value="Q" ${state.filtroTituloInicio==='Q'?'selected':''}>Q</option><option value="R" ${state.filtroTituloInicio==='R'?'selected':''}>R</option><option value="S" ${state.filtroTituloInicio==='S'?'selected':''}>S</option><option value="T" ${state.filtroTituloInicio==='T'?'selected':''}>T</option><option value="U" ${state.filtroTituloInicio==='U'?'selected':''}>U</option><option value="V" ${state.filtroTituloInicio==='V'?'selected':''}>V</option><option value="W" ${state.filtroTituloInicio==='W'?'selected':''}>W</option><option value="X" ${state.filtroTituloInicio==='X'?'selected':''}>X</option><option value="Y" ${state.filtroTituloInicio==='Y'?'selected':''}>Y</option><option value="Z" ${state.filtroTituloInicio==='Z'?'selected':''}>Z</option><option value="0" ${state.filtroTituloInicio==='0'?'selected':''}>0–9</option></select>
    <select id="selNota" title="Nota mínima" aria-label="Nota mínima"><option value="0">Qualquer nota</option>${[9,8,7,6,5,4,3,2,1].map(n => `<option value="${n}" ${state.notaMinima===n?'selected':''}>Nota mínima: ${n}</option>`).join('')}</select>
    <select id="selOrdenacao" title="Ordenação" aria-label="Ordenação">
      <option value="recente" ${state.ordenacao==='recente'?'selected':''}>Mais recentes</option>
      <option value="antigo" ${state.ordenacao==='antigo'?'selected':''}>Mais antigos</option>
      <option value="notaDesc" ${state.ordenacao==='notaDesc'?'selected':''}>Maior nota</option>
      <option value="notaAsc" ${state.ordenacao==='notaAsc'?'selected':''}>Menor nota</option>
      <option value="az" ${state.ordenacao==='az'?'selected':''}>Título A-Z</option>
      <option value="za" ${state.ordenacao==='za'?'selected':''}>Título Z-A</option>
      <option value="anoDesc" ${state.ordenacao==='anoDesc'?'selected':''}>Ano mais recente</option>
      <option value="anoAsc" ${state.ordenacao==='anoAsc'?'selected':''}>Ano mais antigo</option>
      <option value="progressoDesc" ${state.ordenacao==='progressoDesc'?'selected':''}>Maior progresso</option>
      <option value="atualizadoDesc" ${state.ordenacao==='atualizadoDesc'?'selected':''}>Atualizadas recentemente</option>
      <option value="atualizadoAsc" ${state.ordenacao==='atualizadoAsc'?'selected':''}>Atualizadas há mais tempo</option>
    </select>
    <button class="chip-toggle ${state.favoritosOnly?'is-on':''}" id="btnFavToggle" title="Somente favoritos" aria-label="Somente favoritos"><svg class="icon"><use href="#i-heart"/></svg><span>Favoritos</span></button>
    <button class="chip-toggle ${state.filtroInacabadas?'is-on':''}" id="btnInacabadasToggle" title="Somente obras não concluídas" aria-label="Somente obras não concluídas">Não concluídas</button>
    <button class="chip-toggle ${state.filtroSemStatusOficial?'is-on':''}" id="btnSemStatusOficialToggle" title="Obras sem Status Oficial definido" aria-label="Obras sem Status Oficial definido">Sem Status Oficial</button>
    <div class="pdf-dropdown-wrap" style="position:relative;">
      <button type="button" class="btn btn-sm" id="btnGeneratePDF"><svg class="icon"><use href="#i-download"/></svg> PDF</button>
      <div class="pdf-dropdown-menu" id="pdfDropdownMenu" hidden style="position:absolute; top:calc(100% + 4px); left:0; z-index:60; background:var(--bg-elevated-3); border:1px solid var(--border-strong); border-radius:8px; box-shadow:var(--shadow-modal); width:max-content; padding:4px; display:flex; flex-direction:column; gap:1px;">
        <button type="button" class="btn btn-ghost btn-sm" id="pdfOptGeral" style="justify-content:flex-start;">Relatório geral</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="anime" style="justify-content:flex-start;">Animes</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="serie" style="justify-content:flex-start;">Séries</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="desenho" style="justify-content:flex-start;">Desenhos</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="filme" style="justify-content:flex-start;">Filmes</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="filme" data-sub="cinema" style="justify-content:flex-start;padding-left:22px;font-size:0.72rem;color:var(--text-muted);">↳ ${FILME_SUBCAT_META.cinema.label}</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="filme" data-sub="desenho" style="justify-content:flex-start;padding-left:22px;font-size:0.72rem;color:var(--text-muted);">↳ ${FILME_SUBCAT_META.desenho.label}</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="filme" data-sub="anime" style="justify-content:flex-start;padding-left:22px;font-size:0.72rem;color:var(--text-muted);">↳ ${FILME_SUBCAT_META.anime.label}</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="manga" style="justify-content:flex-start;">Mangás</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="manhua" style="justify-content:flex-start;">Manhuas</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="manhwa" style="justify-content:flex-start;">Manhwas</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="novel" style="justify-content:flex-start;">Novels</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="novel" data-sub="light" style="justify-content:flex-start;padding-left:22px;font-size:0.72rem;color:var(--text-muted);">↳ ${NOVEL_SUBCAT_META.light.label}</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="novel" data-sub="web" style="justify-content:flex-start;padding-left:22px;font-size:0.72rem;color:var(--text-muted);">↳ ${NOVEL_SUBCAT_META.web.label}</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="novel" data-sub="classica" style="justify-content:flex-start;padding-left:22px;font-size:0.72rem;color:var(--text-muted);">↳ ${NOVEL_SUBCAT_META.classica.label}</button>
        <button type="button" class="btn btn-ghost btn-sm pdf-cat-btn" data-cat="livro" style="justify-content:flex-start;">Livros</button>
      </div>
    </div>
    <button type="button" class="btn btn-ghost btn-sm mobile-shortcut-btn" id="btnMobileMenu" title="Menu" aria-label="Menu"><svg class="icon"><use href="#i-list"/></svg></button>
    <button type="button" class="btn btn-primary btn-sm mobile-shortcut-btn" id="btnMobileNew" title="Novo registro" aria-label="Novo registro"><svg class="icon"><use href="#i-plus"/></svg></button>
    ${filtered.length ? `<div class="filterbar-selection-controls${state.selectionMode?' is-select-mode':''}" id="mainSelectionControls">
      <button class="btn btn-sm${state.selectionMode?' btn-primary':''}" id="btnToggleSelectionObras"><svg class="icon"><use href="#i-check-square"/></svg> <span class="sel-toggle-label">${state.selectionMode?'Cancelar':'Selecionar'}</span></button>
      <button class="btn btn-sm btn-ghost" id="btnOpenActivityHistory" title="Histórico de atividades"><svg class="icon"><use href="#i-history"/></svg> Histórico</button>
      <button type="button" class="btn btn-sm btn-ghost" id="btnToggleAllCoverBlur"></button>
      <span class="selection-actions-break" aria-hidden="true"></span>
      <button class="btn btn-sm sel-only" id="btnAddToListObras" ${state.selectedIds.size===0?'disabled':''}><svg class="icon"><use href="#i-folder-plus"/></svg> Adicionar a lista</button>
      <button class="btn btn-sm btn-danger sel-only" id="btnDeleteSelectedObras" ${state.selectedIds.size===0?'disabled':''}><svg class="icon"><use href="#i-trash"/></svg> Apagar</button>
      <button class="btn btn-sm btn-ghost sel-only" id="btnSelectAllObras">Selecionar tudo</button>
      <span class="count sel-only" id="selectionCountObras">${state.selectedIds.size} selecionada(s)</span>
    </div>` : ''}
    <div class="filter-spacer"></div>
    ${(state.filtroStatus!=='todos'||state.filtroStatusOficial!=='todos'||state.filtroTituloInicio!=='todos'||state.filtroGenero!=='todos'||state.notaMinima>0||state.favoritosOnly||state.filtroInacabadas||state.filtroSemStatusOficial||state.busca) ? '<button class="link-reset" id="btnClearFilters">Limpar filtros</button>' : ''}
    <span class="results-count">${filtered.length} ITEM${filtered.length===1?'':'S'}</span>
  `;
  document.getElementById('selStatus').value = state.filtroStatus;
  document.getElementById('selStatus').addEventListener('change', e => { state.filtroStatus = e.target.value; renderMain(); });
  { const selOf = document.getElementById('selStatusOficial'); if(selOf) selOf.addEventListener('change', e => { state.filtroStatusOficial = e.target.value; renderMain(); }); }
  document.getElementById('selGenero').addEventListener('change', e => { state.filtroGenero = e.target.value; renderMain(); });
  document.getElementById('selTituloInicio').addEventListener('change', e => { state.filtroTituloInicio = e.target.value; renderMain(); });
  document.getElementById('selNota').addEventListener('change', e => { state.notaMinima = Number(e.target.value); renderMain(); });
  document.getElementById('selOrdenacao').addEventListener('change', e => { state.ordenacao = e.target.value; renderMain(); });
  const activityHistoryBtn = document.getElementById('btnOpenActivityHistory');
  if(activityHistoryBtn) activityHistoryBtn.addEventListener('click', () => {
    if(window.__pushNav) window.__pushNav();
    state.view = 'historico';
    exitSelectionMode();
    renderMain();
  });
  const toggleAllCoverBlurBtn = document.getElementById('btnToggleAllCoverBlur');
  if(toggleAllCoverBlurBtn) toggleAllCoverBlurBtn.addEventListener('click', toggleAllCoverBlur);
  syncToggleAllCoverBlurButton();
  document.getElementById('btnFavToggle').addEventListener('click', () => { state.favoritosOnly = !state.favoritosOnly; renderMain(); });
  document.getElementById('btnInacabadasToggle').addEventListener('click', () => { state.filtroInacabadas = !state.filtroInacabadas; renderMain(); });
  document.getElementById('btnSemStatusOficialToggle').addEventListener('click', () => { state.filtroSemStatusOficial = !state.filtroSemStatusOficial; renderMain(); });
  bindViewModeControls(filterbar, 'obras', mode => {
    if(!['cards','compact','rows'].includes(mode)) return;
    state.obraViewMode = mode;
    persistUiState();
    withViewAnchor(document, '#mainGrid > .card', () => {
      applyViewModeWithoutRebuild(document, 'obras', mode, '#mainGrid');
    });
  });
  filterbar.querySelectorAll('[data-filme-sub]').forEach(btn => btn.addEventListener('click', () => { state.filmeSubAtivo = btn.dataset.filmeSub; renderMain(); }));
  filterbar.querySelectorAll('[data-novel-sub]').forEach(btn => btn.addEventListener('click', () => { state.novelSubAtivo = btn.dataset.novelSub; renderMain(); }));
  const pdfMenu = document.getElementById('pdfDropdownMenu');
  const pdfToggle = document.getElementById('btnGeneratePDF');
  const setPdfMenuOpen = open => filterbar.classList.toggle('pdf-menu-open', !!open);
  if(pdfToggle){
    pdfToggle.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      if(pdfMenu){
        const willOpen = pdfMenu.hidden;
        if(willOpen){
          const rect = pdfToggle.getBoundingClientRect();
          const viewportH = window.visualViewport ? window.visualViewport.height : window.innerHeight;
          const spaceBelow = Math.floor(viewportH - rect.bottom - 12);
          const spaceAbove = Math.floor(rect.top - 12);
          // Se não sobra espaço suficiente abaixo do botão mas há mais espaço
          // acima, abre o menu para cima em vez de para baixo, pra ele não
          // ficar cortado/inacessível na parte de baixo da tela.
          const openUp = spaceBelow < 200 && spaceAbove > spaceBelow;
          pdfMenu.classList.toggle('is-open-up', openUp);
          const available = openUp ? spaceAbove : spaceBelow;
          pdfMenu.style.setProperty('max-height', Math.max(160, available) + 'px', 'important');
          pdfMenu.style.left = '0';
          pdfMenu.style.right = 'auto';
        } else {
          pdfMenu.style.removeProperty('max-height');
          if(willOpen){
            // No desktop o botão pode cair perto da borda direita da barra de
            // filtros (linha larga com vários selects). Se abrir para a
            // esquerda (padrão) o menu estourasse a tela, abre para a direita.
            const rect = pdfToggle.getBoundingClientRect();
            const menuWidth = pdfMenu.offsetWidth || 220;
            const estouraDireita = rect.left + menuWidth > window.innerWidth - 8;
            pdfMenu.style.left = estouraDireita ? 'auto' : '0';
            pdfMenu.style.right = estouraDireita ? '0' : 'auto';
            // Mesma lógica vertical do mobile: se não houver espaço suficiente
            // abaixo, abre para cima.
            const spaceBelow = Math.floor(window.innerHeight - rect.bottom - 12);
            const spaceAbove = Math.floor(rect.top - 12);
            const openUp = spaceBelow < 200 && spaceAbove > spaceBelow;
            pdfMenu.classList.toggle('is-open-up', openUp);
            if(openUp){
              pdfMenu.style.setProperty('max-height', Math.max(160, spaceAbove) + 'px', 'important');
            }
          }
        }
        pdfMenu.hidden = !pdfMenu.hidden;
        setPdfMenuOpen(!pdfMenu.hidden);
      }
    });
  }
  const hidePdfMenu = () => {
    if(pdfMenu) pdfMenu.hidden = true;
    setPdfMenuOpen(false);
  };
  const pdfGeneralBtn = document.getElementById('pdfOptGeral');
  if(pdfGeneralBtn){
    pdfGeneralBtn.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); hidePdfMenu(); generateReportPDF(null); });
  }
  document.querySelectorAll('.pdf-cat-btn').forEach(btn => {
    btn.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); hidePdfMenu(); generateReportPDF(btn.dataset.cat, btn.dataset.sub || null); });
  });
  if(!window.__pdfMenuOutsideClickBound){
    window.__pdfMenuOutsideClickBound = true;
    document.addEventListener('click', (ev) => {
      const menu = document.getElementById('pdfDropdownMenu');
      if(menu && !menu.hidden && !ev.target.closest('.pdf-dropdown-wrap')){
        menu.hidden = true;
        const owner = menu.closest('#filterbar');
        if(owner) owner.classList.remove('pdf-menu-open');
      }
    });
    document.addEventListener('keydown', (ev) => {
      if(ev.key === 'Escape'){
        const menu = document.getElementById('pdfDropdownMenu');
        if(menu && !menu.hidden){
          menu.hidden = true;
          const owner = menu.closest('#filterbar');
          if(owner) owner.classList.remove('pdf-menu-open');
        }
      }
    });
  }
  const mobMenu = document.getElementById('btnMobileMenu');
  if(mobMenu) mobMenu.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); const b = document.getElementById('btnToggleSidebar'); if(b) b.click(); });
  const mobNew = document.getElementById('btnMobileNew');
  if(mobNew) mobNew.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); const b = document.getElementById('btnNew'); if(b) b.click(); else openFormModal(null); });
  const clearBtn = document.getElementById('btnClearFilters');
  if(clearBtn) clearBtn.addEventListener('click', () => {
    state.filtroStatus='todos'; state.filtroStatusOficial='todos'; state.filtroTituloInicio='todos'; state.filtroGenero='todos'; state.notaMinima=0; state.favoritosOnly=false; state.filtroInacabadas=false; state.filtroSemStatusOficial=false; state.filmeSubAtivo='todos'; state.novelSubAtivo='todos';
    renderMain();
  });
}

let _stickyOffsetsRaf = null;
function updateStickyOffsets(){
  const root = document.documentElement;
  const isMobile = true;
  const isVisible = (el) => el && !el.hidden && window.getComputedStyle(el).display !== 'none';
  const overlayHeader = document.querySelector('#pageOverlay .page-overlay-header');
  const overlayHeaderHeight = isVisible(overlayHeader)
    ? Math.round(overlayHeader.getBoundingClientRect().height * 100) / 100
    : 0;
  root.style.setProperty('--page-overlay-header-height', overlayHeaderHeight + 'px');
  if(state.view !== 'lista'){
    root.style.removeProperty('--sticky-cat-offset');
    root.style.removeProperty('--sticky-action-offset');
    return;
  }
  const catBar = document.getElementById('mobileCatBar');
  const filterbar = document.getElementById('filterbar');
  // Altura FRACIONÁRIA (sem Math.ceil): arredondar para cima empurrava a barra
  // de filtros até 1px para baixo da barra de categorias, deixando uma fresta
  // por onde os cartões apareciam. O CSS ainda sobrepõe 1px por segurança.
  const catHeight = (isMobile && isVisible(catBar)) ? Math.round(catBar.getBoundingClientRect().height * 100) / 100 : 0;
  const filterHeight = isVisible(filterbar) ? Math.round(filterbar.getBoundingClientRect().height * 100) / 100 : 0;
  root.style.setProperty('--sticky-cat-offset', catHeight + 'px');
  root.style.setProperty('--sticky-action-offset', (catHeight + filterHeight) + 'px');
}
// Reajusta os offsets sempre que a altura real das barras mudar (fonte a
// carregar, rotação, zoom, quebra de linha dos chips), em qualquer tamanho de ecrã.
(function observeStickyBars(){
  if(typeof ResizeObserver === 'undefined') return;
  const hook = () => {
    try{
      const ro = new ResizeObserver(() => { if(typeof scheduleStickyOffsets === 'function') scheduleStickyOffsets(); });
      ['mobileCatBar','filterbar'].forEach(id => { const el = document.getElementById(id); if(el) ro.observe(el); });
    }catch(_){}
  };
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hook); else hook();
})();
function scheduleStickyOffsets(){
  if(_stickyOffsetsRaf) cancelAnimationFrame(_stickyOffsetsRaf);
  _stickyOffsetsRaf = requestAnimationFrame(() => {
    _stickyOffsetsRaf = null;
    updateStickyOffsets();
  });
}

function showPageOverlay(title){
  const ov = document.getElementById('pageOverlay');
  if(!ov) return;
  document.getElementById('pageOverlayTitle').textContent = title || '';
  ov.classList.add('is-open');
  ov.setAttribute('aria-hidden', 'false');
  document.body.classList.add('has-overlay');
  const back = document.getElementById('pageOverlayBack');
  if(back && !back._bound){
    back._bound = true;
    back.addEventListener('click', () => {
      if(state.view === 'lista-detalhe'){ state.view = 'listas'; exitSelectionMode(); renderMain(); }
      else if(state.view === 'historico'){ state.view = 'lista'; exitSelectionMode(); renderMain(); }
      else { state.view = 'lista'; exitSelectionMode(); renderMain(); }
    });
  }
}
function hidePageOverlay(){
  const ov = document.getElementById('pageOverlay');
  if(!ov) return;
  ov.classList.remove('is-open');
  ov.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('has-overlay');
}
let _renderPending = false;

// Fast path para troca de categoria: evita reconstruir sidebar+filterbar inteiros, apenas
// atualiza estado visual dos botões e re-renderiza a grade. Muito mais rápido em acervos grandes.
function fastSwitchCategoria(cat){
  if(state.view === 'lista' && state.categoriaAtiva === cat){
    // já está nessa categoria — só garante grid pronto
    return;
  }
  // Se viemos de outra view (ex: estatísticas/listas), a filterbar está oculta.
  // Nesse caso fazemos um render completo para reexibi-la corretamente.
  const cameFromOtherView = state.view !== 'lista';
  state.view = 'lista';
  state.categoriaAtiva = cat;
  if(cameFromOtherView){
    // Uma categoria é uma nova página de resultados. Não reutiliza a
    // posição do dashboard anterior, porque a grelha pode ter uma altura e
    // uma distribuição de linhas completamente diferentes (principalmente
    // Novels, que também têm a barra de subcategorias).
    _dashboardScrollSaved = null;
    _pendingGridScrollTarget = null;
    setScrollerPos(0);
    exitSelectionMode();
    renderMain();
    return;
  }
  // A troca rápida não desmonta o shell da aplicação, mas deve começar no
  // início da nova categoria. Sem isto, clicar em "Novels" enquanto se está
  // a meio de outra categoria deixa o primeiro card da Novel cortado.
  _dashboardScrollSaved = null;
  _pendingGridScrollTarget = null;
  setScrollerPos(0);
  exitSelectionMode();
  // Atualiza classes ativas no sidebar
  try{
    document.querySelectorAll('#sidebar .nav-item').forEach(b => {
      const isCat = b.dataset.cat && b.dataset.cat === cat;
      const isView = !b.dataset.cat;
      b.classList.toggle('is-active', !!isCat && !isView);
    });
    document.querySelectorAll('#mobileCatBar .chip-toggle').forEach(b => {
      b.classList.toggle('is-on', b.dataset.cat === cat);
    });
  }catch(_){}
  // Reconstrói a filterbar para (re)mostrar as sub-chips de Filme/Novel e
  // atualizar contagens/filtros específicos da categoria ativa.
  const filteredForSwitch = getFilteredSorted();
  try{ renderFilterbar(filteredForSwitch); }catch(_){}
  // Re-renderiza apenas a grade (chunked) — não toca sidebar/filterbar
  scheduleStickyOffsets();
  if(typeof renderGrid === 'function') renderGrid(filteredForSwitch);
}

function renderMain(){
  if(_renderPending) return;
  _renderPending = true;
  requestAnimationFrame(() => {
    _renderPending = false;
    _renderMainNow();
  });
}
let _lastRenderedView = null;
let _lastRenderedListaId = null;
// Detecta QUEM realmente rola a página do dashboard: no desktop é o próprio
// #main (overflow-y:auto), mas no mobile (<=880px) o CSS muda #main para
// overflow-y:visible/height:auto — quem rola de verdade é a janela/documento.
// Esse é o motivo pelo qual tentar corrigir mainEl.scrollTop no celular não
// tinha efeito nenhum: o elemento certo era outro. Toda a lógica de
// salvar/restaurar posição usa esta mesma detecção (igual à já usada pela
// barra de navegação de scroll mais abaixo no arquivo), para não haver
// divergência entre onde a posição foi lida e onde ela é aplicada.
function getMainScroller(){
  const isMobile = true;
  if(isMobile) return { el: document.scrollingElement || document.documentElement, useWindow: true };
  return { el: document.getElementById('main'), useWindow: false };
}
function getScrollerPos(){
  const { el, useWindow } = getMainScroller();
  if(useWindow) return window.pageYOffset || (el ? el.scrollTop : 0) || 0;
  return el ? el.scrollTop : 0;
}
function setScrollerPos(y){
  const { el, useWindow } = getMainScroller();
  if(useWindow){ window.scrollTo(0, y); if(el) el.scrollTop = y; }
  else if(el){ el.scrollTop = y; }
}
function getActiveScrollSnapshot(){
  const pageOverlay = document.getElementById('pageOverlay');
  // O detalhe da obra pode ser aberto por cima da página autónoma. Nesse caso
  // o contêiner ativo é o overlay, não a página que ficou por baixo.
  if(pageOverlay && pageOverlay.classList.contains('is-open')){
    return { container:'page-overlay', scrollY:pageOverlay.scrollTop };
  }
  const listPageContent = document.getElementById('listPageContent');
  if(typeof listPageState !== 'undefined' && listPageState.isOpen && listPageContent){
    return { container:'list-page', scrollY:listPageContent.scrollTop };
  }
  return { container:'main', scrollY:getScrollerPos() };
}
function getScrollerHeight(){
  const { el, useWindow } = getMainScroller();
  if(useWindow) return document.documentElement.scrollHeight;
  return el ? el.scrollHeight : document.documentElement.scrollHeight;
}
function getScrollerClientHeight(){
  const { useWindow } = getMainScroller();
  if(useWindow) return window.innerHeight;
  const el = document.getElementById('main');
  return el ? el.clientHeight : window.innerHeight;
}
// Guarda a posição de scroll da dashboard sempre que saímos dela para outra
// página (Estatísticas, Listas) e a restaura ao voltar — exceto na rota
// "detalhes da obra", que já tem seu próprio mecanismo mais preciso (inclui
// recentralizar o card exato de onde veio).
let _dashboardScrollSaved = null;
// Quando definido antes de uma renderização da grade, indica que existe uma
// posição de scroll para restaurar. renderGrid() consome este valor e monta
// os cards necessários de forma síncrona (sem esperar frames) até cobrir
// essa altura, aplicando o scroll correto ANTES do primeiro paint — o
// mesmo princípio usado por feeds como Instagram/TikTok/Facebook: a tela
// já "nasce" na posição certa, em vez de aparecer do topo (ou de um estado
// parcial que ainda não tem altura suficiente, o que fazia o navegador
// prender o scroll no fundo do conteúdo parcial até o resto carregar).
let _pendingGridScrollTarget = null;
let _pendingPageOverlayScrollTarget = null;
let _pendingListPageScrollTarget = null;
let _pageScrollRestoreGeneration = 0;
const _elementScrollRestoreTokens = new WeakMap();
function cancelPageScrollRestores(){
  _pageScrollRestoreGeneration += 1;
}
function restoreElementScrollUntilStable(el, y){
  if(!el || typeof y !== 'number') return false;
  const target = Math.max(0, y);
  const generation = _pageScrollRestoreGeneration;
  const previousRestore = _elementScrollRestoreTokens.get(el);
  if(previousRestore) previousRestore.cancelled = true;
  const restoreToken = {cancelled:false};
  _elementScrollRestoreTokens.set(el, restoreToken);
  restoreScrollUntilStable(() => {
    if(restoreToken.cancelled || generation !== _pageScrollRestoreGeneration){
      return {height:el.scrollHeight, landed:true};
    }
    const height = el.scrollHeight;
    const max = Math.max(0, height - el.clientHeight);
    const desired = Math.min(target, max);
    el.scrollTop = desired;
    return {
      height,
      landed: Math.abs(el.scrollTop - desired) < 1 && target <= max + 1
    };
  }, {shouldCancel:() => restoreToken.cancelled || generation !== _pageScrollRestoreGeneration});
  return true;
}
function restorePendingPageOverlayScroll(view){
  const pending = _pendingPageOverlayScrollTarget;
  if(!pending || pending.view !== view) return false;
  _pendingPageOverlayScrollTarget = null;
  return restoreElementScrollUntilStable(document.getElementById('pageOverlay'), pending.scrollY);
}
function restorePendingListPageScroll(){
  const pending = _pendingListPageScrollTarget || (typeof _listPageScrollMemory === 'number'
    ? {scrollY:_listPageScrollMemory} : null);
  if(!pending) return false;
  _pendingListPageScrollTarget = null;
  return restoreElementScrollUntilStable(document.getElementById('listPageContent'), pending.scrollY);
}
// BUGFIX: só existia salvamento/restauração de posição para o dashboard
// ("lista") e para o retorno vindo de "obra-detalhe". Trocar diretamente
// entre "Minhas Listas", "Detalhes da lista" e "Estatísticas" (ex.: abrir
// uma lista e depois voltar) não guardava posição nenhuma nesses casos —
// a página sempre reaparecia do topo, mesmo quando o usuário esperava
// voltar exatamente onde tinha deixado. Esta memória cobre esse buraco:
// guarda a posição de rolagem destas páginas sempre que se sai delas, e
// restaura-a ao voltar (a menos que já exista um alvo mais específico
// pendente, como o retorno do detalhe de uma obra).
const _pageOverlayScrollMemory = Object.create(null);
let _listPageScrollMemory = null;
function pageOverlayScrollMemoryKey(view, listaId){
  return view === 'lista-detalhe' ? ('lista-detalhe:' + (listaId || '')) : view;
}
function savePageOverlayScrollIfLeaving(fromView, toView, fromListaId){
  if(fromView === toView) return;
  if(!['listas','lista-detalhe','estatisticas','historico','favoritos'].includes(fromView)) return;
  const pageOverlay = document.getElementById('pageOverlay');
  if(!pageOverlay) return;
  _pageOverlayScrollMemory[pageOverlayScrollMemoryKey(fromView, fromListaId)] = pageOverlay.scrollTop;
}
function rememberActiveScrollSnapshot(snapshot){
  if(!snapshot || typeof snapshot.scrollY !== 'number' || !Number.isFinite(snapshot.scrollY)) return;
  const y = Math.max(0, snapshot.scrollY);
  // Durante renderMain(), state já aponta para a página de destino enquanto o
  // DOM ainda representa a página anterior. Use o último contexto realmente
  // renderizado para nunca gravar a posição de uma página em outra.
  const renderedView = _lastRenderedView || state.view;
  const renderedListaId = _lastRenderedListaId;
  if(snapshot.container === 'main' && renderedView === 'lista'){
    _dashboardScrollSaved = {scrollY:y};
  }else if(snapshot.container === 'page-overlay' && ['listas','lista-detalhe','estatisticas','historico','favoritos'].includes(renderedView)){
    _pageOverlayScrollMemory[pageOverlayScrollMemoryKey(renderedView, renderedListaId)] = y;
  }else if(snapshot.container === 'list-page'){
    _listPageScrollMemory = y;
  }
}
function getScrollMemorySnapshot(){
  const pageOverlay = {};
  Object.keys(_pageOverlayScrollMemory).forEach(key => {
    const y = _pageOverlayScrollMemory[key];
    if(typeof y === 'number' && Number.isFinite(y) && y >= 0) pageOverlay[key] = y;
  });
  return {
    dashboard: _dashboardScrollSaved && typeof _dashboardScrollSaved.scrollY === 'number'
      ? {scrollY: Math.max(0, _dashboardScrollSaved.scrollY)} : null,
    pageOverlay,
    listPage: typeof _listPageScrollMemory === 'number' ? Math.max(0, _listPageScrollMemory) : null
  };
}
function restoreRememberedPageOverlayScroll(view){
  const y = _pageOverlayScrollMemory[pageOverlayScrollMemoryKey(view, state.listaAtivaId)];
  if(typeof y !== 'number' || y <= 0) return false;
  return restoreElementScrollUntilStable(document.getElementById('pageOverlay'), y);
}
function saveDashboardScrollIfLeaving(fromView, toView){
  if(fromView !== 'lista' || toView === 'lista') return;
  _dashboardScrollSaved = { scrollY: getScrollerPos() };
}
// Altura real (em px, relativa à janela) ocupada pelas barras fixas/sticky
// no topo da grade (barra de categorias no mobile + barra de filtros — esta
// última fica mais alta na categoria Novel/Filme por causa das abas de
// subcategoria). Um card pode estar geometricamente "dentro" da viewport
// (rect.top >= 0) e mesmo assim estar escondido atrás dessas barras — é
// exatamente esse caso que fazia o retorno "mostrar de baixo" do card em
// vez do topo dele, principalmente na categoria Novel (barra mais alta).
function getGridFixedHeaderBottom(){
  let bottom = 0;
  ['mobileCatBar','filterbar'].forEach(id => {
    const el = document.getElementById(id);
    if(el && !el.hidden && window.getComputedStyle(el).display !== 'none'){
      const b = el.getBoundingClientRect().bottom;
      if(b > bottom) bottom = b;
    }
  });
  const header = document.querySelector('.app-header');
  if(header && window.getComputedStyle(header).position === 'sticky'){
    const b = header.getBoundingClientRect().bottom;
    if(b > bottom) bottom = b;
  }
  return bottom;
}
// Restaura uma posição de scroll de forma imediata e exata, mesmo quando o
// conteúdo alvo (grade de cards) ainda está sendo montado em blocos (chunks)
// ou capas ainda estão carregando e alterando a altura da página.
//
// Em vez de "chutar" um número fixo de frames/ms (o que ou termina cedo
// demais — deixando a posição errada em listas grandes — ou espera tempo
// demais em listas pequenas, gerando um atraso perceptível), a função:
//  1) aplica a posição alvo em TODO frame, desde já (por isso o primeiro
//     frame já fica visualmente correto sempre que possível — "imediato");
//  2) continua corrigindo enquanto a altura do conteúdo ainda estiver
//     mudando (chunks/imagens carregando) ou o valor não "colou" (clamp);
//  3) para assim que a altura estabilizar por alguns frames seguidos E a
//     posição aplicada bater com a desejada — geralmente 1 frame para
//     listas pequenas, o necessário para listas grandes — com um teto de
//     segurança para nunca rodar indefinidamente.
function restoreScrollUntilStable(applyTick, opts){
  opts = opts || {};
  const maxAttempts = opts.maxAttempts || 90; // ~1.5s a 60fps, teto de segurança
  const stableFramesNeeded = opts.stableFramesNeeded || 3;
  const shouldCancel = typeof opts.shouldCancel === 'function' ? opts.shouldCancel : () => false;
  let attempts = 0;
  let lastHeight = -1;
  let stableCount = 0;
  const tick = () => {
    if(shouldCancel()) return;
    // applyTick faz a aplicação (na ordem correta: posição bruta primeiro,
    // depois ajustes finos como recentralizar um card) e devolve o quanto
    // for preciso para decidirmos se já estabilizou.
    const r = applyTick() || {};
    attempts++;
    const currentHeight = typeof r.height === 'number' ? r.height : document.documentElement.scrollHeight;
    const heightStable = currentHeight === lastHeight;
    stableCount = heightStable ? stableCount + 1 : 0;
    lastHeight = currentHeight;
    const done = r.landed !== false && stableCount >= stableFramesNeeded;
    if(done || attempts >= maxAttempts) return;
    requestAnimationFrame(tick);
  };
  // CORREÇÃO (piscar ao trocar/voltar de página): antes o primeiro "tick"
  // só corria dentro de um requestAnimationFrame, ou seja, sempre havia
  // pelo menos 1 frame pintado com o scroll ainda na posição antiga (a
  // sobra do contêiner reutilizado, ex.: #pageOverlay) por cima do
  // conteúdo já novo — esse é o "flash"/piscar relatado ao sair ou trocar
  // de página. Chamando tick() já de imediato, de forma síncrona, a
  // posição correta é aplicada ANTES do navegador pintar o próximo frame
  // (o DOM já foi atualizado por quem chamou esta função), eliminando essa
  // primeira pintura errada. As chamadas seguintes (se a altura ainda
  // estiver instável, ex.: chunks/imagens carregando) continuam via
  // requestAnimationFrame, como antes.
  tick();
}
function restoreDashboardScrollIfNeeded(fromView, toView){
  if(toView !== 'lista' || fromView === 'obra-detalhe' || !_dashboardScrollSaved) return;
  const saved = _dashboardScrollSaved;
  restoreScrollUntilStable(() => {
    setScrollerPos(saved.scrollY);
    const height = getScrollerHeight();
    const clientHeight = getScrollerClientHeight();
    const landed = getScrollerPos() === saved.scrollY || height <= saved.scrollY + clientHeight;
    return { height, landed };
  });
}
// Re-renderizar depois de uma edição pode alterar a altura de capas, selos ou
// linhas, principalmente no telemóvel. Guarda e repõe o mesmo contêiner e a
// mesma posição depois de o DOM novo existir, em vez de deixar a tela voltar
// ao topo ou parar alguns pixels antes/depois da posição anterior.
function restoreScrollAfterEntryUpdate(snapshot){
  if(!snapshot || typeof snapshot.scrollY !== 'number') return;
  const restore = () => {
    if(snapshot.container === 'page-overlay'){
      restoreElementScrollUntilStable(document.getElementById('pageOverlay'), snapshot.scrollY);
    }else if(snapshot.container === 'list-page'){
      restoreElementScrollUntilStable(document.getElementById('listPageContent'), snapshot.scrollY);
    }else{
      restoreScrollUntilStable(() => {
        setScrollerPos(snapshot.scrollY);
        const height = getScrollerHeight();
        return {
          height,
          landed: Math.abs(getScrollerPos() - snapshot.scrollY) < 1
        };
      });
    }
  };
  requestAnimationFrame(() => requestAnimationFrame(restore));
}
// Prepara a posição ANTES de pedir a reconstrução da tela. Sem este passo,
// renderGrid() podia limpar a grade e montar apenas o primeiro bloco; durante
// esse intervalo o navegador pintava uma página vazia/quebrada e só depois a
// restauração tardia recolocava o usuário no ponto certo.
function prepareScrollBeforeEntryUpdate(snapshot){
  if(!snapshot || typeof snapshot.scrollY !== 'number') return;
  if(snapshot.container === 'page-overlay'){
    _pendingPageOverlayScrollTarget = {view: state.view, scrollY: snapshot.scrollY};
  }else if(snapshot.container === 'list-page'){
    _pendingListPageScrollTarget = {scrollY: snapshot.scrollY};
  }else{
    _pendingGridScrollTarget = {y: snapshot.scrollY};
  }
}
// Reseta o scroll para o topo de todos os contêineres possíveis (janela,
// #main no desktop, e a página sobreposta de listas). Usado sempre que
// entramos numa página que NÃO é a principal (dashboard) — a dashboard é a
// única que deve lembrar a posição de rolagem de antes de sair dela.
function resetPageScroll(){
  try{ window.scrollTo({top:0, left:0, behavior:'instant'}); }catch(_){ window.scrollTo(0,0); }
  document.documentElement.scrollTop = 0; document.body.scrollTop = 0;
  const mainEl = document.getElementById('main');
  if(mainEl) mainEl.scrollTop = 0;
  const overlay = document.getElementById('pageOverlay');
  if(overlay) overlay.scrollTop = 0;
  const overlayBody = document.getElementById('pageOverlayBody');
  if(overlayBody && typeof overlayBody.scrollTo === 'function') overlayBody.scrollTo(0,0);
  const content = document.getElementById('content');
  if(content && typeof content.scrollTo === 'function') content.scrollTo(0,0);
}
function _renderMainNow(){
  persistUiState();
  document.body.classList.toggle('is-detail-view', state.view === 'obra-detalhe');
  document.body.classList.toggle('is-listas-view', state.view === 'listas' || state.view === 'lista-detalhe');
  document.body.classList.toggle('is-historico-view', state.view === 'historico');
  const previousView = _lastRenderedView;
  const previousListaId = _lastRenderedListaId;
  const enteringNewView = state.view !== previousView;
  const enteringNewPageContext = enteringNewView || (
    state.view === 'lista-detalhe' && state.listaAtivaId !== previousListaId
  );
  if(enteringNewPageContext){
    cancelScrollNavAnimations();
    cancelPageScrollRestores();
  }
  if(enteringNewView) saveDashboardScrollIfLeaving(previousView, state.view);
  if(enteringNewPageContext) savePageOverlayScrollIfLeaving(previousView, state.view, previousListaId);
  renderSidebar();
  renderListsPanel();
  const filteredForView = state.view === 'lista' ? getFilteredSorted() : null;
  renderFilterbar(filteredForView);
  scheduleStickyOffsets();
  // BUGFIX: a barra de rolagem customizada (pageOverlayScrollNav e as demais)
  // só se recalcula sozinha quando ocorre um evento nativo de "scroll" ou
  // "resize" no contêiner que ela observa. Ao entrar numa página nova (ex.:
  // "Minhas Listas") cujo scroll já nasce em 0, trocar de página não gera
  // nenhum desses dois eventos — então a barra ficava "presa" no estado de
  // antes (às vezes invisível, às vezes sem refletir o conteúdo novo). Um
  // resize sintético força todas as barras a recalcularem a cada render,
  // exatamente como já acontece de forma natural nas páginas onde a barra
  // funciona bem hoje.
  requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  _lastRenderedView = state.view;
  _lastRenderedListaId = state.listaAtivaId;
  if(state.view === 'listas'){
    showPageOverlay('Minhas Listas');
    renderListasOverview();
    const restored = restorePendingPageOverlayScroll('listas') ||
      (enteringNewView && restoreRememberedPageOverlayScroll('listas'));
    if(enteringNewView && !restored) resetPageScroll();
    return;
  }
  if(state.view === 'lista-detalhe'){
    showPageOverlay('Detalhes da lista');
    renderListaDetalhe();
    const restored = restorePendingPageOverlayScroll('lista-detalhe') ||
      (enteringNewPageContext && restoreRememberedPageOverlayScroll('lista-detalhe'));
    if(enteringNewPageContext && !restored) resetPageScroll();
    return;
  }
  // BUGFIX: "Estatísticas" e o detalhe de uma obra também são renderizados
  // dentro de #pageOverlayBody (mesmo contêiner usado por Listas), mas até
  // aqui só Listas chamava showPageOverlay() para tornar esse contêiner
  // visível — as outras duas ficavam escrevendo conteúdo dentro de um
  // elemento com display:none. Na prática isso fazia essas páginas nunca
  // aparecerem de verdade por cima do dashboard (o grid por trás continuava
  // visível e rolável), o que também é a causa principal do dashboard
  // "parecer" mudar de posição ao entrar/voltar dessas páginas: o scroll
  // era salvo/restaurado, mas a página por cima nunca tinha assumido o
  // controlo visual de verdade. Ao mostrar o overlay corretamente aqui, o
  // grid do dashboard fica coberto (e intacto, sem ser desmontado) enquanto
  // essas páginas estão abertas — exatamente como um feed do Instagram/
  // TikTok/Facebook, que nunca é destruído por baixo de outra tela, só fica
  // escondido atrás dela. Isso resolve o problema do dashboard "mudar de
  // posição" ao entrar/voltar destas páginas — mas a posição DENTRO de cada
  // uma delas (ex.: onde se estava a olhar em "Estatísticas") ainda precisa
  // da sua própria memória, feita acima por savePageOverlayScrollIfLeaving /
  // restoreRememberedPageOverlayScroll.
  if(state.view === 'estatisticas'){
    showPageOverlay('Visão geral');
    renderStats();
    const restored = enteringNewView && restoreRememberedPageOverlayScroll('estatisticas');
    if(enteringNewView && !restored) resetPageScroll();
    return;
  }
  if(state.view === 'historico'){
    showPageOverlay('Histórico de atividades');
    renderHistorico();
    const restored = enteringNewView && restoreRememberedPageOverlayScroll('historico');
    if(enteringNewView && !restored) resetPageScroll();
    return;
  }
  if(state.view === 'favoritos'){
    showPageOverlay('Favoritos');
    renderFavoritos();
    const restored = restorePendingPageOverlayScroll('favoritos') ||
      (enteringNewView && restoreRememberedPageOverlayScroll('favoritos'));
    if(enteringNewView && !restored) resetPageScroll();
    return;
  }
  if(state.view === 'obra-detalhe'){
    showPageOverlay('');
    renderObraDetalhe();
    // Ao reabrir a aplicação, o detalhe é a página actual e deve continuar
    // aberto. O renderizador limpa o scroll por defeito, portanto restauramos
    // aqui o snapshot persistido somente quando ele pertence ao detalhe.
    restorePendingPageOverlayScroll('obra-detalhe');
    return;
  } // O cabeçalho genérico do overlay fica oculto via CSS; o detalhe tem o seu próprio botão "Voltar".
  hidePageOverlay();
  {
    if(enteringNewView && state.view === 'lista' && previousView !== 'obra-detalhe' && _dashboardScrollSaved){
      // Arma o alvo ANTES de renderizar: renderGrid() vai montar os cards
      // necessários de forma síncrona para já nascer na posição certa.
      _pendingGridScrollTarget = { y: _dashboardScrollSaved.scrollY };
    }
    renderGrid(filteredForView);
    if(enteringNewView) restoreDashboardScrollIfNeeded(previousView, state.view);
  }
}

const GRID_PAGE_SIZE = 80;
let _gridRenderKey = 0;

function renderGrid(filteredList){
  const list = Array.isArray(filteredList) ? filteredList : getFilteredSorted();
  const content = document.getElementById('content');
  if(state.entries.length === 0){ content.innerHTML = emptyStateHtml('shelf', 'Seu acervo está vazio', 'Comece registrando o primeiro anime, filme, mangá ou novel que você já viu ou leu.', true); bindEmptyState(); return; }
  if(list.length === 0){ content.innerHTML = emptyStateHtml('search', 'Nenhum item encontrado', 'Tente ajustar os filtros ou o termo de busca.', false); bindEmptyState(); return; }

  const renderKey = ++_gridRenderKey;

  content.innerHTML = `<div class="grid view-mode-${state.obraViewMode||'cards'}${state.selectionMode?' is-select-mode':''}" id="mainGrid"></div>`;
  const gridEl = content.querySelector('#mainGrid');

  const _btnToggle = document.getElementById('btnToggleSelectionObras');
  if(_btnToggle) _btnToggle.addEventListener('click', () => {
    // Toggle instantâneo — sem re-render
    state.selectionMode = !state.selectionMode;
    state.selectedIds = new Set();
    const selectionControls = document.getElementById('mainSelectionControls');
    if(selectionControls) selectionControls.classList.toggle('is-select-mode', state.selectionMode);
    _btnToggle.classList.toggle('btn-primary', state.selectionMode);
    const lbl = _btnToggle.querySelector('.sel-toggle-label');
    if(lbl) lbl.textContent = state.selectionMode ? 'Cancelar' : 'Selecionar';
    gridEl.classList.toggle('is-select-mode', state.selectionMode);
    // Limpa estado visual de seleção sem reconstruir o grid
    gridEl.querySelectorAll('.obra-card-checkbox').forEach(cb => { cb.checked = false; });
    gridEl.querySelectorAll('.card.is-selected-card').forEach(c => c.classList.remove('is-selected-card'));
    const cnt = document.getElementById('selectionCountObras');
    if(cnt) cnt.textContent = '0 selecionada(s)';
    const delBtn = document.getElementById('btnDeleteSelectedObras');
    if(delBtn) delBtn.disabled = true;
    const addBtn = document.getElementById('btnAddToListObras');
    if(addBtn) addBtn.disabled = true;
  });
  const _btnSelectAll = document.getElementById('btnSelectAllObras');
  if(_btnSelectAll) _btnSelectAll.addEventListener('click', () => {
    const allSelected = state.selectedIds.size === list.length;
    if(allSelected) state.selectedIds = new Set();
    else state.selectedIds = new Set(list.map(e => e.id));
    // Optimistic: atualiza checkboxes sem re-render
    gridEl.querySelectorAll('[data-card-id]').forEach(card => {
      const id = card.getAttribute('data-card-id');
      const cb = card.querySelector('.obra-card-checkbox');
      if(cb) cb.checked = !allSelected;
    });
    const cnt = document.getElementById('selectionCountObras');
    if(cnt) cnt.textContent = state.selectedIds.size + ' selecionada(s)';
    const delBtn = document.getElementById('btnDeleteSelectedObras');
    if(delBtn) delBtn.disabled = state.selectedIds.size === 0;
    const addBtn = document.getElementById('btnAddToListObras');
    if(addBtn) addBtn.disabled = state.selectedIds.size === 0;
  });
  const _btnAddToList = document.getElementById('btnAddToListObras');
  if(_btnAddToList) _btnAddToList.addEventListener('click', () => openListSelectorModalForMultiple(Array.from(state.selectedIds)));
  const _btnDelSel = document.getElementById('btnDeleteSelectedObras');
  if(_btnDelSel) _btnDelSel.addEventListener('click', () => openConfirmDeleteMultiple(Array.from(state.selectedIds)));
  const cancelMainSel = document.getElementById('btnCancelSelectionObrasMain');
  if(cancelMainSel) cancelMainSel.addEventListener('click', () => { exitSelectionMode(); renderMain(); });

  // Event delegation — um único listener para toda a grelha
  gridEl.addEventListener('click', (ev) => {
    const card = ev.target.closest('[data-card-id]');
    if(!card) return;
    const id = card.getAttribute('data-card-id');
    if(ev.target.closest('.obra-card-checkbox')){ ev.stopPropagation(); toggleObraSelected(id); return; }
    if(ev.target.closest('.fav-btn')){ ev.stopPropagation(); toggleFavorite(id); return; }
    const editBtn = ev.target.closest('.icon-btn[data-action="edit"]');
    if(editBtn){ ev.stopPropagation(); openFormModal(id); return; }
    const delBtn = ev.target.closest('.icon-btn[data-action="delete"]');
    if(delBtn){ ev.stopPropagation(); openConfirmDelete(id); return; }
    if(ev.target.closest('.card-clickable')){
      if(state.selectionMode){ toggleObraSelected(id); } else { openDetailModal(id); }
    }
  });

  // Se há uma posição de scroll pendente para restaurar, monta os cards
  // necessários de forma SÍNCRONA (sem esperar requestAnimationFrame) até
  // cobrir a altura alvo, e só então aplica o scrollTop — antes do usuário
  // ver qualquer frame. Isso evita o efeito de "pular para o final e depois
  // voltar": como as capas são carregadas com lazy-loading e a caixa da
  // capa já reserva a altura via aspect-ratio, criar os nós do DOM é rápido
  // e não espera nenhuma imagem — mesmo para acervos com milhares de itens,
  // isso normalmente cobre a altura alvo em poucos blocos.
  const _target = _pendingGridScrollTarget;
  _pendingGridScrollTarget = null;
  let _primedOffset = 0;
  if(_target && typeof _target.y === 'number'){
    const neededHeight = _target.y + getScrollerClientHeight();
    while(_primedOffset < list.length){
      const chunk = list.slice(_primedOffset, _primedOffset + GRID_PAGE_SIZE);
      if(!chunk.length) break;
      const frag = document.createDocumentFragment();
      chunk.forEach(e => {
        const tmp = document.createElement('div');
        tmp.innerHTML = cardHtml(e);
        if(tmp.firstElementChild) frag.appendChild(tmp.firstElementChild);
      });
      gridEl.appendChild(frag);
      _primedOffset += GRID_PAGE_SIZE;
      if(getScrollerHeight() >= neededHeight) break;
    }
    setScrollerPos(_target.y);
    ensureOrnamentVisibility();
  }

  // Renderização incremental por chunks (restante, em segundo plano, fora
  // da tela) — não trava o browser com milhares de obras.
  function renderChunk(offset){
    if(renderKey !== _gridRenderKey) return; // estado mudou, aborta este render
    const chunk = list.slice(offset, offset + GRID_PAGE_SIZE);
    if(!chunk.length){
      if(state.selectionMode){
        list.forEach(e => {
          const card = gridEl.querySelector(`[data-card-id="${e.id}"]`);
          const cb = card && card.querySelector('.obra-card-checkbox');
          if(cb) cb.checked = state.selectedIds.has(e.id);
        });
      }
      return;
    }
    const frag = document.createDocumentFragment();
    chunk.forEach(e => {
      const tmp = document.createElement('div');
      tmp.innerHTML = cardHtml(e);
      if(tmp.firstElementChild) frag.appendChild(tmp.firstElementChild);
    });
    gridEl.appendChild(frag);
    requestAnimationFrame(() => {
      ensureOrnamentVisibility();
      renderChunk(offset + GRID_PAGE_SIZE);
    });
  }
  renderChunk(_primedOffset);
}
function emptyStateHtml(icon, title, text, showCta){
  return `<div class="empty-state"><svg class="icon"><use href="#i-${icon==='shelf'?'shelf':'search'}"/></svg><h3>${escapeHtml(title)}</h3><p>${escapeHtml(text)}</p>${showCta ? '<button class="btn btn-primary" id="emptyStateCta"><svg class="icon"><use href="#i-plus"/></svg> Adicionar primeiro item</button>' : ''}</div>`;
}
function bindEmptyState(){ const cta = document.getElementById('emptyStateCta'); if(cta) cta.addEventListener('click', () => openFormModal(null)); }

function cardHtml(e){
  const meta = CATEGORY_META[e.categoria];
  let metaLine = [];
  if(e.ano) metaLine.push(e.ano);
  const prog = progressoTexto(e);
  if(prog) metaLine.push(prog);
  if(e.categoria==='filme' && e.duracao_min) metaLine.push(e.duracao_min + ' min');
  const genres = (e.generos||[]).slice(0,3);
  const coverSrc = e.capa_base64 || e.capa_url;
  const _cardSubInfo = entrySubcategoryInfo(e);
  const _hasSub = _cardSubInfo && _cardSubInfo.key !== 'sem-subcategoria';
  const catTabLabel = _hasSub ? meta.label + ' ' + _cardSubInfo.short : meta.label;
  const cardColor = _hasSub && _cardSubInfo.color ? _cardSubInfo.color : meta.color;
  const rowStatus = e.categoria !== 'filme'
    ? `<span class="card-row-status" style="color:${statusColor(e.status)}">${escapeHtml(statusLabel(e.status))}</span>`
    : '';
  const rowRating = typeof e.nota === 'number'
    ? `<span class="card-row-rating">${e.nota.toFixed(1).replace('.0','')}</span>`
    : '';
  return `<div class="card${isCapaDesfocada(e.id)?' is-capa-desfocada':''}" data-card-id="${e.id}" style="--cat-color:${cardColor}">
    <input type="checkbox" class="obra-card-checkbox">
    <button class="card-clickable" aria-label="Ver detalhes de ${escapeHtml(e.titulo)}"></button>
    <span class="cat-tab"><svg class="icon"><use href="#${meta.icon}"/></svg>${catTabLabel}</span>
    <div class="card-cover">
      ${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="window.__coverFallback(this)">` : `<svg class="icon placeholder-icon"><use href="#${meta.icon}"/></svg>`}
      ${typeof e.nota === 'number' ? `<span class="stamp stamp--rating">${e.nota.toFixed(1).replace('.0','')}</span>` : ''}
      ${e.categoria !== 'filme' ? `<span class="stamp stamp--status" style="color:${statusColor(e.status)}"><span class="stamp-label-full">${statusLabel(e.status)}</span><span class="stamp-label-short">${statusCardLabel(e.status)}</span></span>` : ''}
      ${e.status_oficial ? `<span class="stamp stamp--official" style="color:${officialStatusColor(e.status_oficial)}" title="Status Oficial da obra"><span class="stamp-label-full">${officialStatusLabel(e.status_oficial)}</span><span class="stamp-label-short">${officialStatusCardLabel(e.status_oficial)}</span></span>` : ''}
      <button class="fav-btn ${e.favorito?'is-fav':''}" aria-label="Favorito" data-action="fav"><svg class="icon"><use href="#i-heart"/></svg></button>
      <button type="button" class="cover-blur-btn${isCapaDesfocada(e.id)?' is-on':''}" data-action="toggle-cover-blur" aria-label="Desfocar capa" aria-pressed="${isCapaDesfocada(e.id)}" title="Mostrar ou desfocar esta capa">${isCapaDesfocada(e.id)?'🙈':'👁'}</button>
    </div>
    <div class="card-body">
      <div class="card-title">${escapeHtml(e.titulo)}</div>
      ${e.titulo_original ? `<div class="card-title-original">${escapeHtml(e.titulo_original)}</div>` : ''}
      ${metaLine.length || rowStatus || rowRating ? `<div class="card-meta">${metaLine.map(escapeHtml).join(' · ')}${rowStatus}${rowRating}</div>` : ''}
      ${genres.length ? `<div class="genre-row">${genres.map(g=>`<span class="genre-pill">${escapeHtml(g)}</span>`).join('')}</div>` : ''}
      <div class="card-footer">
        <button class="icon-btn" data-action="edit" aria-label="Editar"><svg class="icon"><use href="#i-edit"/></svg></button>
        <button class="icon-btn danger" data-action="delete" aria-label="Remover"><svg class="icon"><use href="#i-trash"/></svg></button>
      </div>
    </div>
  </div>`;
}

/* ------------------------------------------------------------------
   Ornamento por categoria: preenche o espaço vazio dos cards mais curtos
   com uma ilustração grande, colorida (variação da cor da categoria) e
   animada. Cada categoria tem uma forma e um movimento diferentes. Só
   é exibido quando sobra espaço vertical suficiente (medido depois do
   render em ensureOrnamentVisibility()).
   ------------------------------------------------------------------ */
const ORNAMENT_SHAPES = {
  // Roda de anime — estrela ninja / shuriken
  anime: '<g><path d="M32 4 L38 26 L60 24 L42 36 L54 56 L32 44 L10 56 L22 36 L4 24 L26 26 Z"/><circle cx="32" cy="32" r="4" fill="none" stroke="currentColor" stroke-width="2"/></g>',
  // TV clássica
  serie: '<g><rect x="8" y="16" width="48" height="34" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><rect x="14" y="22" width="36" height="22" rx="2"/><line x1="22" y1="52" x2="18" y2="60" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><line x1="42" y1="52" x2="46" y2="60" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="50" cy="12" r="3"/></g>',
  // Balão de fala com estrela — desenho animado
  desenho: '<g><path d="M8 14 Q8 8 14 8 L50 8 Q56 8 56 14 L56 38 Q56 44 50 44 L28 44 L18 54 L20 44 L14 44 Q8 44 8 38 Z"/><path d="M32 16 L34 22 L40 22 L35 26 L37 32 L32 28 L27 32 L29 26 L24 22 L30 22 Z" fill="var(--bg-elevated)" opacity="0.9"/></g>',
  // Rolo de filme
  filme: '<g><circle cx="32" cy="32" r="24"/><circle cx="32" cy="32" r="6" fill="var(--bg-elevated)"/><circle cx="32" cy="14" r="3" fill="var(--bg-elevated)"/><circle cx="32" cy="50" r="3" fill="var(--bg-elevated)"/><circle cx="14" cy="32" r="3" fill="var(--bg-elevated)"/><circle cx="50" cy="32" r="3" fill="var(--bg-elevated)"/><circle cx="19" cy="19" r="3" fill="var(--bg-elevated)"/><circle cx="45" cy="45" r="3" fill="var(--bg-elevated)"/><circle cx="45" cy="19" r="3" fill="var(--bg-elevated)"/><circle cx="19" cy="45" r="3" fill="var(--bg-elevated)"/></g>',
  // Balão japonês com traços
  manga: '<g><path d="M6 12 Q6 6 12 6 L52 6 Q58 6 58 12 L58 40 Q58 46 52 46 L36 46 L26 58 L28 46 L12 46 Q6 46 6 40 Z"/><g stroke="var(--bg-elevated)" stroke-width="2.5" stroke-linecap="round"><line x1="16" y1="18" x2="42" y2="18"/><line x1="16" y1="26" x2="48" y2="26"/><line x1="16" y1="34" x2="36" y2="34"/></g></g>',
  // Leque chinês
  manhua: '<g><path d="M32 56 L6 22 Q32 4 58 22 Z"/><g stroke="var(--bg-elevated)" stroke-width="2" fill="none"><path d="M32 56 L18 26"/><path d="M32 56 L32 20"/><path d="M32 56 L46 26"/></g><circle cx="32" cy="56" r="4"/></g>',
  // Painéis de quadrinhos coreanos
  manhwa: '<g><rect x="8" y="8" width="20" height="24" rx="2"/><rect x="32" y="8" width="24" height="14" rx="2"/><rect x="32" y="26" width="24" height="30" rx="2"/><rect x="8" y="36" width="20" height="20" rx="2"/></g>',
  // Livro aberto com "página virando"
  novel: '<g><path d="M32 14 Q20 8 8 12 L8 50 Q20 46 32 52 Q44 46 56 50 L56 12 Q44 8 32 14 Z"/><path d="M32 14 L32 52" stroke="var(--bg-elevated)" stroke-width="2" fill="none"/><g stroke="var(--bg-elevated)" stroke-width="1.5" fill="none" opacity="0.7"><line x1="14" y1="22" x2="28" y2="22"/><line x1="14" y1="28" x2="28" y2="28"/><line x1="14" y1="34" x2="28" y2="34"/><line x1="36" y1="22" x2="50" y2="22"/><line x1="36" y1="28" x2="50" y2="28"/><line x1="36" y1="34" x2="50" y2="34"/></g></g>',
  // Livro fechado com marcador
  livro: '<g><rect x="12" y="6" width="40" height="52" rx="3"/><rect x="12" y="6" width="8" height="52" fill="var(--bg-elevated)" opacity="0.35"/><path d="M40 6 L40 30 L46 24 L52 30 L52 6 Z" fill="color-mix(in srgb, var(--cat-color) 60%, #000000)"/><g stroke="var(--bg-elevated)" stroke-width="1.5" opacity="0.6"><line x1="24" y1="20" x2="40" y2="20"/><line x1="24" y1="28" x2="40" y2="28"/><line x1="24" y1="36" x2="36" y2="36"/></g></g>'
};
function categoryOrnamentSvg(e){
  const cat = e && e.categoria;
  const shape = ORNAMENT_SHAPES[cat];
  if(!shape) return '';
  return `<div class="card-ornament cat-${cat}" aria-hidden="true"><svg viewBox="0 0 64 64" preserveAspectRatio="xMidYMid meet">${shape}</svg></div>`;
}

/* Mede cada card e mostra o ornamento só quando sobra espaço suficiente
   (senão fica apertado sobre título/meta). Chamado após cada renderização
   principal e em resize. */
function ensureOrnamentVisibility(){
  const nodes = document.querySelectorAll('.card-ornament');
  nodes.forEach(o => {
    // clientHeight = espaço reservado pelo flex:1 dentro do card-body
    const h = o.clientHeight;
    o.classList.toggle('is-visible', h >= 56);
  });
}
if(typeof window !== 'undefined'){
  let __ornResizeT = null;
  window.addEventListener('resize', () => {
    clearTimeout(__ornResizeT);
    __ornResizeT = setTimeout(ensureOrnamentVisibility, 120);
  });
}

function toggleFavorite(id){
  const entry = state.entries.find(e => e.id === id);
  if(!entry) return;
  const before = cloneActivitySnapshot(entry);
  const now = Date.now();
  entry.favorito = !entry.favorito;
  entry.atualizado_em = now;
  entry.ultima_edicao_obra = now;
  recordActivity(entry.favorito ? 'favorite_added' : 'favorite_removed', 'obra', entry.titulo, entry.favorito ? 'Marcada como favorita.' : 'Retirada dos favoritos.', {
    targetId: entry.id,
    categoria: entry.categoria,
    beforeSnapshot:before,
    afterSnapshot:cloneActivitySnapshot(entry)
  });
  persistEntries();
  // Optimistic DOM update — evita re-render completo só para mudar ícone de favorito
  const card = document.querySelector(`[data-card-id="${id}"]`);
  if(card){
    const btn = card.querySelector('.fav-btn');
    if(btn) btn.classList.toggle('is-fav', !!entry.favorito);
    if(state.favoritosOnly && !entry.favorito){
      card.style.transition = 'opacity 0.2s';
      card.style.opacity = '0';
      setTimeout(() => renderMain(), 220);
    }
  } else {
    renderMain();
  }
}

function renderStats(){
  const content = document.getElementById('pageOverlayBody');
  const total = state.entries.length;
  if(total === 0){ content.innerHTML = emptyStateHtml('shelf', 'Nada para mostrar ainda', 'Adicione itens ao seu acervo para ver estatísticas aqui.', true); bindEmptyState(); return; }
  const counts = countByCategoria();
  const rated = state.entries.filter(e => typeof e.nota === 'number');
  const mediaGeral = rated.length ? (rated.reduce((s,e)=>s+e.nota,0)/rated.length) : null;
  const favoritos = state.entries.filter(e => e.favorito).length;
  const concluidos = state.entries.filter(e => e.status==='concluido').length;
  const genreFreq = {};
  state.entries.forEach(e => (e.generos||[]).forEach(g => { genreFreq[g]=(genreFreq[g]||0)+1; }));
  const topGenres = Object.entries(genreFreq).sort((a,b)=>b[1]-a[1]).slice(0,6);
  const maxGenre = topGenres.length ? topGenres[0][1] : 1;
  const statusCounts = {}; STATUS_ORDER.forEach(s => statusCounts[s]=0);
  state.entries.forEach(e => { if(statusCounts[e.status]!==undefined) statusCounts[e.status]++; });
  const officialStatusCounts = {}; OFFICIAL_STATUS_ORDER.forEach(s => officialStatusCounts[s]=0);
  let officialStatusTotal = 0;
  state.entries.forEach(e => { if(e.status_oficial && officialStatusCounts[e.status_oficial]!==undefined){ officialStatusCounts[e.status_oficial]++; officialStatusTotal++; } });
  const maxOfficialStatus = Math.max(1, ...Object.values(officialStatusCounts));
  const maxStatus = Math.max(1, ...Object.values(statusCounts));
  const maxCat = Math.max(1, ...Object.values(counts));

  // Calcular estatísticas detalhadas por categoria
  const detailedStats = {};
  CATEGORY_ORDER.forEach(cat => {
    const obras = state.entries.filter(e => e.categoria === cat);
    const catStats = { count: obras.length, mediaNotas: 0, concluidas: 0 };
    
    if(cat === 'anime'){
      catStats.totalTemporadas = 0;
      catStats.totalEpisodios = 0;
      catStats.totalOvas = 0;
      catStats.totalFilmes = 0;
      const countExtras = (extras) => {
        (extras||[]).forEach(x => {
          if(x.tipo === 'OVA'){
            // Se a OVA tem quantidade (ex: "10"), conta as 10. Caso contrário conta como 1.
            catStats.totalOvas += extraQuantidade(x);
          } else if(x.tipo === 'Filme'){
            // Mesma lógica das OVAs: filme sem nome pode representar N filmes vistos.
            catStats.totalFilmes += extraQuantidade(x);
          }
        });
      };
      obras.forEach(o => {
        if(o.temporadas){
          o.temporadas.forEach(t => {
            const ep = Math.round(Number(t.episodios)||0);
            if(ep > 0){ catStats.totalTemporadas += 1; catStats.totalEpisodios += ep; }
            countExtras(t.extras);
          });
        }
        countExtras(o.extras_independentes);
      });
    } else if(cat === 'desenho'){
      catStats.totalTemporadas = 0;
      catStats.totalEpisodios = 0;
      catStats.totalExtras = 0;
      catStats.totalFilmes = 0;
      const countDesExtras = (extras) => {
        (extras||[]).forEach(x => {
          if(x.tipo === 'Extra') catStats.totalExtras += extraQuantidade(x);
          else if(x.tipo === 'Filme') catStats.totalFilmes += extraQuantidade(x);
        });
      };
      obras.forEach(o => {
        if(o.temporadas){
          o.temporadas.forEach(t => {
            const ep = Math.round(Number(t.episodios)||0);
            if(ep > 0){ catStats.totalTemporadas += 1; catStats.totalEpisodios += ep; }
            countDesExtras(t.extras);
          });
        }
        countDesExtras(o.extras_independentes);
      });
    } else if(cat === 'serie'){
      catStats.totalTemporadas = 0;
      catStats.totalEpisodios = 0;
      obras.forEach(o => {
        if(o.temporadas){
          o.temporadas.forEach(t => {
            const ep = Math.round(Number(t.episodios)||0);
            if(ep > 0){ catStats.totalTemporadas += 1; catStats.totalEpisodios += ep; }
          });
        }
      });
    } else if(['manga','manhua','manhwa'].includes(cat)){
      catStats.totalCapitulos = 0;
      obras.forEach(o => {
        catStats.totalCapitulos += Math.floor(o.progresso_simples || 0);
      });
    } else if(cat === 'novel'){
      catStats.totalVolumes = 0;
      catStats.totalCapitulos = 0;
      catStats.totalPaginas = 0;
      obras.forEach(o => {
        if(o.volumes){
          o.volumes.forEach(v => {
            const _rvLista = v.capitulos_lista||[];
            const _rvCaps = _rvLista.length ? capitulostotalFromLista(_rvLista, 0) : Math.floor(Number(v.capitulos)||0);
            if(_rvCaps > 0){ catStats.totalVolumes += 1; catStats.totalCapitulos += _rvCaps; }
            // Página total do volume = maior página registada em qualquer capítulo (nomeado ou numérico)
            const _rvMaxPag = _rvLista.reduce((m,c) => {
              const p = Number(c && c.pagina)||0;
              return p > m ? p : m;
            }, 0);
            if(_rvMaxPag > 0) catStats.totalPaginas += Math.floor(_rvMaxPag);
          });
        }
      });
    } else if(cat === 'livro'){
      catStats.totalPaginasLidas = 0;
      catStats.totalPaginasTotais = 0;
      obras.forEach(o => {
        catStats.totalPaginasLidas += Math.floor(Number(o.progresso_simples)||0);
        catStats.totalPaginasTotais += Math.floor(Number(o.paginas_total)||0);
      });
    }
    
    const notasObras = obras.filter(o => typeof o.nota === 'number');
    catStats.mediaNotas = notasObras.length ? notasObras.reduce((s,o)=>s+o.nota,0)/notasObras.length : null;
    catStats.concluidas = obras.filter(o => o.status === 'concluido').length;
    
    detailedStats[cat] = catStats;
  });

  content.innerHTML = `
    <div class="stats-header">Visão geral do acervo</div>
    <div class="stats-sub">${total} ITENS REGISTRADOS</div>
    <div class="stat-cards">
      <div class="stat-card"><div class="num">${total}</div><div class="lbl">Total de itens</div></div>
      <div class="stat-card"><div class="num">${mediaGeral!==null ? mediaGeral.toFixed(1) : '—'}</div><div class="lbl">Nota média</div></div>
      <div class="stat-card"><div class="num">${concluidos}</div><div class="lbl">Concluídos</div></div>
      <div class="stat-card"><div class="num">${favoritos}</div><div class="lbl">Favoritos</div></div>
    </div>
    <div class="stats-block stats-category-block"><h3>Itens por categoria com detalhes</h3>
      <div class="stats-category-grid">
      ${CATEGORY_ORDER.map(cat => { 
        const meta = CATEGORY_META[cat]; 
        const c = counts[cat];
        const stats = detailedStats[cat];
        let detalhes = '';
        if(cat === 'anime'){
          detalhes = `${Math.round(stats.totalTemporadas)} temp. · ${Math.round(stats.totalEpisodios)} ep. · ${Math.round(stats.totalOvas)} OVAs · ${Math.round(stats.totalFilmes)} filmes`;
        } else if(cat === 'desenho'){
          detalhes = `${Math.round(stats.totalTemporadas)} temp. · ${Math.round(stats.totalEpisodios)} ep.` + (stats.totalExtras||stats.totalFilmes ? ` · ${Math.round(stats.totalExtras||0)} extras · ${Math.round(stats.totalFilmes||0)} filmes` : '');
        } else if(cat === 'serie'){
          detalhes = `${Math.round(stats.totalTemporadas)} temp. · ${Math.round(stats.totalEpisodios)} ep.`;
        } else if(cat === 'filme'){
          detalhes = `${c} filme(s)`;
        } else if(['manga','manhua','manhwa'].includes(cat)){
          detalhes = `${Math.round(stats.totalCapitulos)} capítulos`;
        } else if(cat === 'novel'){
          const pag = stats.totalPaginas || 0;
          detalhes = `${Math.round(stats.totalVolumes)} volumes · ${Math.round(stats.totalCapitulos)} capítulos` + (pag ? ` · ${Math.round(pag)} pág.` : '');
        } else if(cat === 'livro'){
          const lidas = stats.totalPaginasLidas || 0;
          const totais = stats.totalPaginasTotais || 0;
          detalhes = totais ? `${Math.round(lidas)} pág. lidas · ${Math.round(totais)} pág. total` : `${Math.round(lidas)} pág. lidas`;
        }
        return `<div class="bar-row"><span class="bar-label"><svg class="icon" style="color:${meta.color}"><use href="#${meta.icon}"/></svg>${meta.plural}</span><div style="flex:1;"><div class="bar-track"><span class="bar-fill" style="width:${(c/maxCat)*100}%; background:${meta.color}"></span></div><div style="font-size:0.75rem; color:var(--text-muted); margin-top:4px;">${detalhes}</div></div><span class="bar-val">${c}</span></div>`;
      }).join('')}
      </div>
    </div>
    <div class="stats-block"><h3>Status Pessoal</h3>
      ${STATUS_ORDER.slice().sort((a,b) => statusLabel(a).localeCompare(statusLabel(b), 'pt-BR')).map(s => { const c = statusCounts[s];
        return `<div class="bar-row"><span class="bar-label">${statusLabel(s)}</span><span class="bar-track"><span class="bar-fill" style="width:${(c/maxStatus)*100}%; background:${statusColor(s)}"></span></span><span class="bar-val">${c}</span></div>`;
      }).join('')}
    </div>
    ${officialStatusTotal > 0 ? `<div class="stats-block"><h3>Status Oficial</h3>
      <p style="font-size:0.78rem; color:var(--text-muted); margin:-4px 0 10px;">Considera todas as categorias, exceto filmes, com Status Oficial definido.</p>
      ${OFFICIAL_STATUS_ORDER.slice().sort((a,b) => officialStatusLabel(a).localeCompare(officialStatusLabel(b), 'pt-BR')).map(s => { const c = officialStatusCounts[s];
        return `<div class="bar-row"><span class="bar-label">${officialStatusLabel(s)}</span><span class="bar-track"><span class="bar-fill" style="width:${(c/maxOfficialStatus)*100}%; background:${officialStatusColor(s)}"></span></span><span class="bar-val">${c}</span></div>`;
      }).join('')}
    </div>` : ''}
    ${topGenres.length ? `<div class="stats-block"><h3>Gêneros mais frequentes</h3>
      ${topGenres.map(([g,c]) => `<div class="bar-row"><span class="bar-label">${escapeHtml(g)}</span><span class="bar-track"><span class="bar-fill" style="width:${(c/maxGenre)*100}%; background:var(--c-gold)"></span></span><span class="bar-val">${c}</span></div>`).join('')}
    </div>` : ''}
    <div class="stats-block"><h3>Zona de risco</h3>
      <p style="font-size:0.82rem; color:var(--text-muted); margin-bottom:10px;">Remover permanentemente todos os itens do acervo.</p>
      <button class="btn btn-danger btn-sm" id="btnWipeAll">Limpar todo o acervo</button>
    </div>
  `;
  const wipeBtn = document.getElementById('btnWipeAll');
  if(wipeBtn) wipeBtn.addEventListener('click', openConfirmWipe);
}

/* ===================== LISTAS PERSONALIZADAS ===================== */
function getListaById(id){ return state.listas.find(l => l.id === id); }
// Só as listas padrão (por categoria/subcategoria) devem ser permanentes.
// Uma lista personalizada que fica sem nenhuma obra (porque a obra foi
// removida do acervo, ou foi tirada manualmente da lista) é descartada
// automaticamente em vez de continuar ocupando espaço na página de Listas.
function cleanupEmptyCustomLists(){
  const antes = state.listas.length;
  state.listas = state.listas.filter(l => l.defaultCat || (Array.isArray(l.obraIds) && l.obraIds.length > 0));
  return state.listas.length !== antes;
}
function getEntriesOfLista(lista){
  if(!lista) return [];
  return lista.obraIds.map(id => state.entries.find(e => e.id === id)).filter(Boolean);
}
// Listas específicas aceitam apenas a respetiva categoria; listas criadas
// como "Mista" (categoria "todos") aceitam qualquer categoria e nunca
// ficam travadas na primeira obra adicionada.
function listaAceitaCategoria(lista, categoria){
  if(!lista || !categoria) return false;
  return !lista.categoria || lista.categoria === 'todos' || lista.categoria === categoria;
}
function listaSubcategoryInfo(lista){
  if(!lista || !lista.defaultCat || !lista.defaultSub) return null;
  if(lista.defaultCat === 'filme' && FILME_SUBCAT_META[lista.defaultSub]){
    const m = FILME_SUBCAT_META[lista.defaultSub];
    return {key:lista.defaultSub, label:m.label, parent:'Filme', parentLabel:'Filme', color:m.color, type:'filme'};
  }
  if(lista.defaultCat === 'novel' && NOVEL_SUBCAT_META[lista.defaultSub]){
    const m = NOVEL_SUBCAT_META[lista.defaultSub];
    return {key:lista.defaultSub, label:m.label, parent:'Novel', parentLabel:'Novel', color:m.color, type:'novel'};
  }
  return null;
}
function entrySubcategoryInfo(entry){
  if(!entry) return null;
  if(entry.categoria === 'filme'){
    const key = String(entry.subcategoria || '').toLowerCase().trim();
    const meta = FILME_SUBCAT_META[key];
    return meta ? {key, label:meta.label, short:meta.short, color:meta.color, type:'filme'} : {key:'sem-subcategoria', label:'Sem subcategoria', short:'', color:null, type:'filme'};
  }
  if(entry.categoria === 'novel'){
    const tipo = String(entry.tipo_novel || '').toLowerCase().trim();
    const key = NOVEL_SUBCATEGORIAS.find(k => novelSubMatches(NOVEL_SUBCAT_META[k], tipo));
    return key ? {key, label:NOVEL_SUBCAT_META[key].label, short:NOVEL_SUBCAT_META[key].short, color:NOVEL_SUBCAT_META[key].color, type:'novel'} : {key:'sem-subcategoria', label:'Sem subcategoria', short:'', color:null, type:'novel'};
  }
  return null;
}
function subcategoryGroupsForCategory(cat, items){
  const order = cat === 'filme' ? FILME_SUBCATEGORIAS : (cat === 'novel' ? NOVEL_SUBCATEGORIAS : []);
  const buckets = new Map();
  items.forEach(entry => {
    const info = entrySubcategoryInfo(entry) || {key:'sem-subcategoria', label:'Sem subcategoria', type:cat};
    if(!buckets.has(info.key)) buckets.set(info.key, {info, items:[]});
    buckets.get(info.key).items.push(entry);
  });
  const keys = order.filter(k => buckets.has(k));
  if(buckets.has('sem-subcategoria')) keys.push('sem-subcategoria');
  Array.from(buckets.keys()).forEach(k => { if(!keys.includes(k)) keys.push(k); });
  return keys.map(k => buckets.get(k));
}
function exitSelectionMode(){ state.selectionMode = false; state.selectedIds = new Set(); state.listaDetalheSelectedIds = new Set(); }

// Cria (se necessário) e sincroniza listas padrão automáticas, uma por categoria,
// que reúnem sempre todas as obras dessa categoria existentes no acervo.
// Também cria listas padrão para cada subcategoria de "filme" (Cinema, Desenho,
// Anime) e de "novel" (Light Novel, Web Novel, Novel Clássica), com o nome
// acompanhado da categoria mãe entre parênteses — ex: "Cinema (Filmes)".
function ensureDefaultLists(){
  if(!Array.isArray(state.listas)) state.listas = [];
  // Dedup defensivo: remove listas duplicadas antes de qualquer processamento.
  //   1) duplicados por id (mantém a primeira ocorrência);
  //   2) listas padrão duplicadas com a mesma (defaultCat + defaultSub) —
  //      preserva a que tem mais obras vinculadas.
  //   3) listas personalizadas duplicadas (sem defaultCat) com mesmo
  //      nome+categoria — preserva a mais antiga (menor criado_em) e
  //      funde os obraIds das restantes.
  (function dedupListas(){
    const seenIds = new Set();
    const byId = [];
    for(const l of state.listas){
      if(!l || !l.id) continue;
      if(seenIds.has(l.id)) continue;
      seenIds.add(l.id);
      byId.push(l);
    }
    const defaults = new Map(); // key defaultCat|defaultSub -> lista
    const customs = new Map();  // key nome|categoria (lowercase) -> lista
    const out = [];
    for(const l of byId){
      if(l.defaultCat){
        const k = `${l.defaultCat}|${l.defaultSub||''}`;
        const prev = defaults.get(k);
        if(!prev){ defaults.set(k, l); out.push(l); }
        else {
          const a = Array.isArray(prev.obraIds) ? prev.obraIds.length : 0;
          const b = Array.isArray(l.obraIds) ? l.obraIds.length : 0;
          if(b > a){
            const idx = out.indexOf(prev);
            if(idx >= 0) out[idx] = l;
            defaults.set(k, l);
          }
        }
      } else {
        const k = `${String(l.nome||'').trim().toLowerCase()}|${String(l.categoria||'').toLowerCase()}`;
        const prev = customs.get(k);
        if(!prev){ customs.set(k, l); out.push(l); }
        else {
          // Funde obraIds no mais antigo e descarta o duplicado.
          const set = new Set(Array.isArray(prev.obraIds) ? prev.obraIds : []);
          (Array.isArray(l.obraIds) ? l.obraIds : []).forEach(x => set.add(x));
          prev.obraIds = Array.from(set);
          if((l.criado_em||0) && (!prev.criado_em || l.criado_em < prev.criado_em)){
            prev.criado_em = l.criado_em;
          }
        }
      }
    }
    if(out.length !== state.listas.length){ state.listas = out; try{ persistListas(); }catch(_){ } }
    else state.listas = out;
  })();
  let changed = false;


  CATEGORY_ORDER.forEach(cat => {
    let lista = state.listas.find(l => l.defaultCat === cat && !l.defaultSub);
    const idsDaCategoria = state.entries.filter(e => e.categoria === cat).map(e => e.id);
    if(!lista){
      lista = { id: uuid(), nome: CATEGORY_META[cat].plural, categoria: cat, defaultCat: cat, obraIds: idsDaCategoria, criado_em: Date.now() };
      state.listas.unshift(lista);
      changed = true;
    } else {
      const atual = JSON.stringify(lista.obraIds);
      lista.obraIds = idsDaCategoria;
      lista.nome = CATEGORY_META[cat].plural;
      lista.categoria = cat;
      if(atual !== JSON.stringify(lista.obraIds)) changed = true;
    }
  });

  // Sublistas padrão para as subcategorias de "filme"
  FILME_SUBCATEGORIAS.forEach(sub => {
    const meta = FILME_SUBCAT_META[sub];
    const nome = `${meta.label} (${CATEGORY_META.filme.plural})`;
    const ids = state.entries
      .filter(e => e.categoria === 'filme' && String(e.subcategoria||'').toLowerCase() === sub)
      .map(e => e.id);
    let lista = state.listas.find(l => l.defaultCat === 'filme' && l.defaultSub === sub);
    if(!lista){
      lista = { id: uuid(), nome, categoria: 'filme', defaultCat: 'filme', defaultSub: sub, obraIds: ids, criado_em: Date.now() };
      // Insere logo após a lista padrão "Filmes" para agrupar visualmente
      const parentIdx = state.listas.findIndex(l => l.defaultCat === 'filme' && !l.defaultSub);
      if(parentIdx >= 0) state.listas.splice(parentIdx + 1, 0, lista);
      else state.listas.unshift(lista);
      changed = true;
    } else {
      const atual = JSON.stringify(lista.obraIds);
      lista.obraIds = ids;
      lista.nome = nome;
      lista.categoria = 'filme';
      if(atual !== JSON.stringify(lista.obraIds)) changed = true;
    }
  });

  // Sublistas padrão para as subcategorias de "novel"
  NOVEL_SUBCATEGORIAS.forEach(sub => {
    const meta = NOVEL_SUBCAT_META[sub];
    if(!meta) return;
    const nome = `${meta.label} (${CATEGORY_META.novel.plural})`;
    const ids = state.entries
      .filter(e => e.categoria === 'novel' && novelSubMatches(meta, e.tipo_novel))
      .map(e => e.id);
    let lista = state.listas.find(l => l.defaultCat === 'novel' && l.defaultSub === sub);
    if(!lista){
      lista = { id: uuid(), nome, categoria: 'novel', defaultCat: 'novel', defaultSub: sub, obraIds: ids, criado_em: Date.now() };
      const parentIdx = state.listas.findIndex(l => l.defaultCat === 'novel' && !l.defaultSub);
      if(parentIdx >= 0) state.listas.splice(parentIdx + 1, 0, lista);
      else state.listas.unshift(lista);
      changed = true;
    } else {
      const atual = JSON.stringify(lista.obraIds);
      lista.obraIds = ids;
      lista.nome = nome;
      lista.categoria = 'novel';
      if(atual !== JSON.stringify(lista.obraIds)) changed = true;
    }
  });

  if(changed) persistListas();
}

/* ===================== PESQUISA DE OBRAS (dentro da página Listas) ===================== */
function bindObraSearch(){
  const input = document.getElementById('obraSearchInput');
  const results = document.getElementById('obraSearchResults');
  if(!input || !results) return;
  const runSearch = debounce(() => renderObraSearchResults(input.value), 180);
  input.addEventListener('input', runSearch);
  input.addEventListener('focus', () => { if(input.value.trim()) renderObraSearchResults(input.value); });
  document.addEventListener('click', (e) => {
    if(!results.contains(e.target) && e.target !== input) results.classList.remove('is-open');
  });
}
function renderObraSearchResults(term){
  const results = document.getElementById('obraSearchResults');
  if(!results) return;
  const q = normalizeText(term);
  if(!q){ results.classList.remove('is-open'); results.innerHTML = ''; return; }
  const matches = state.entries.filter(e => {
    const haystack = normalizeText([e.titulo, e.titulo_original].filter(Boolean).join(' '));
    return textMatchesSearchTerm(q, haystack);
  }).slice(0, 20);
  if(!matches.length){
    results.innerHTML = '<div class="obra-search-empty">Nenhuma obra encontrada</div>';
  } else {
    results.innerHTML = matches.map(e => {
      const meta = CATEGORY_META[e.categoria];
      return `<button type="button" class="obra-search-item" data-obra-id="${e.id}">
        <svg class="icon" style="color:${meta.color};"><use href="#${meta.icon}"/></svg>
        <span>${escapeHtml(e.titulo)}</span>
        <span class="cat-tag">${meta.label}</span>
      </button>`;
    }).join('');
    results.querySelectorAll('.obra-search-item').forEach(btn => {
      btn.addEventListener('click', () => {
        results.classList.remove('is-open');
        openListSelectorForObra(btn.dataset.obraId);
      });
    });
  }
  results.classList.add('is-open');
}

// Ordena listas: padrões primeiro (na ordem categoria/subcategoria), depois
// personalizadas em ordem alfabética (pt-BR, case-insensitive).
function sortListasForOverview(listas){
  const collator = new Intl.Collator('pt-BR', {sensitivity:'base', numeric:true});
  const parentName = (l) => {
    if(l.defaultCat && CATEGORY_META[l.defaultCat]) return CATEGORY_META[l.defaultCat].plural;
    return l.nome || '';
  };
  const subLabel = (l) => {
    if(!l.defaultSub) return '';
    if(l.defaultCat === 'filme' && FILME_SUBCAT_META[l.defaultSub]) return FILME_SUBCAT_META[l.defaultSub].label;
    if(l.defaultCat === 'novel' && NOVEL_SUBCAT_META[l.defaultSub]) return NOVEL_SUBCAT_META[l.defaultSub].label;
    return '';
  };
  return listas.slice().sort((a,b) => {
    const aDef = !!a.defaultCat, bDef = !!b.defaultCat;
    if(aDef && !bDef) return -1;
    if(!aDef && bDef) return 1;
    if(aDef && bDef){
      // Ordena por nome do pai (alfabético), agrupando pai + subs juntos.
      const pa = parentName(a), pb = parentName(b);
      const cmpParent = collator.compare(pa, pb);
      if(cmpParent !== 0) return cmpParent;
      // Mesmo pai: a lista-mãe (sem defaultSub) vem antes das subs.
      const aHasSub = !!a.defaultSub, bHasSub = !!b.defaultSub;
      if(!aHasSub && bHasSub) return -1;
      if(aHasSub && !bHasSub) return 1;
      // Ambos são subs do mesmo pai: alfabético pelo label da sub.
      return collator.compare(subLabel(a), subLabel(b));
    }
    return collator.compare(a.nome||'', b.nome||'');
  });
}

function favoriteRowHtml(e){
  const meta = CATEGORY_META[e.categoria] || {label:e.categoria || 'Obra', color:'var(--c-gold)', icon:'i-shelf'};
  const coverSrc = e.capa_base64 || e.capa_url;
  const prog = progressoTexto(e);
  const subInfo = entrySubcategoryInfo(e);
  const rowColor = subInfo && subInfo.key !== 'sem-subcategoria' && subInfo.color ? subInfo.color : meta.color;
  return `<div class="obra-row favorites-obra-row" data-card-id="${escapeHtml(e.id)}" data-obra-id="${escapeHtml(e.id)}" style="--cat-color:${rowColor}">
    <div class="obra-row-cover">
      ${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="window.__coverFallback(this)">` : `<svg class="icon"><use href="#${meta.icon}"/></svg>`}
      <button class="favorite-row-open" type="button" aria-label="Abrir detalhes de ${escapeHtml(e.titulo)}"></button>
    </div>
    <div class="obra-row-main">
      <div class="obra-row-title">${escapeHtml(e.titulo)}</div>
      <div class="obra-row-meta">
        ${e.categoria!=='filme' ? `<span class="obra-row-status" style="color:${statusColor(e.status)}">${escapeHtml(statusLabel(e.status))}</span>` : ''}
        ${e.status_oficial ? `<span class="obra-row-status" style="color:${officialStatusColor(e.status_oficial)}" title="Status Oficial da obra">${escapeHtml(officialStatusLabel(e.status_oficial))}</span>` : ''}
        ${subInfo ? `<span class="obra-row-subcat">${escapeHtml(subInfo.label)}</span>` : ''}
        ${typeof e.nota === 'number' ? `<span class="obra-row-rating">${e.nota.toFixed(1).replace('.0','')}</span>` : ''}
        ${e.ano ? `<span>${escapeHtml(e.ano)}</span>` : ''}
        ${prog ? `<span>${escapeHtml(prog)}</span>` : ''}
      </div>
    </div>
    <div class="obra-row-actions">
      <button class="icon-btn favorite-row-toggle is-fav" type="button" data-action="fav" aria-label="Remover dos favoritos" aria-pressed="true" title="Remover dos favoritos"><svg class="icon"><use href="#i-heart"/></svg></button>
      <button class="icon-btn" data-action="edit" aria-label="Editar"><svg class="icon"><use href="#i-edit"/></svg></button>
      <button class="icon-btn danger" data-action="delete" aria-label="Remover"><svg class="icon"><use href="#i-trash"/></svg></button>
    </div>
  </div>`;
}

function getFavoriteResultItems(favoriteEntries){
  const term = String(state.favoritosBusca || '').trim().toLocaleLowerCase('pt-BR');
  let items = favoriteEntries.filter(e => {
    if(state.favoritosCategoria !== 'todos' && e.categoria !== state.favoritosCategoria) return false;
    if(state.favoritosStatus !== 'todos' && e.status !== state.favoritosStatus) return false;
    if(!term) return true;
    return normalizeText([e.titulo, e.titulo_original, ...(e.generos || [])].join(' ')).includes(normalizeText(term));
  });
  const collator = new Intl.Collator('pt-BR', {sensitivity:'base', numeric:true});
  if(state.favoritosOrdenacao === 'alfabetica') items.sort((a,b) => collator.compare(a.titulo || '', b.titulo || ''));
  else if(state.favoritosOrdenacao === 'nota') items.sort((a,b) => (Number(b.nota)||0) - (Number(a.nota)||0) || collator.compare(a.titulo || '', b.titulo || ''));
  else items.sort((a,b) => Number(b.atualizado_em || b.criado_em || 0) - Number(a.atualizado_em || a.criado_em || 0));
  return items;
}

function updateFavoritesResults(content){
  const favoriteEntries = state.entries.filter(e => e.favorito);
  const items = getFavoriteResultItems(favoriteEntries);
  const count = content.querySelector('.favorites-count');
  if(count) count.textContent = `${items.length} de ${favoriteEntries.length} exibida(s)`;

  const results = content.querySelector('#favoritesResults');
  if(!results) return null;
  if(!favoriteEntries.length){
    results.innerHTML = emptyStateHtml('shelf', 'Ainda não há favoritos', 'Marque o coração nas capas do dashboard para reunir aqui as suas obras preferidas.', false);
  }else if(!items.length){
    results.innerHTML = emptyStateHtml('search', 'Nenhum favorito encontrado', 'Experimente limpar a pesquisa ou ajustar os filtros.', false);
  }else if(state.favoritosViewMode === 'rows'){
    results.innerHTML = `<div class="obra-list favorites-obra-list view-mode-rows" id="favoritesGrid">${items.map(favoriteRowHtml).join('')}</div>`;
  }else{
    results.innerHTML = `<div class="grid view-mode-${state.favoritosViewMode || 'cards'}" id="favoritesGrid">${items.map(cardHtml).join('')}</div>`;
  }
  return results;
}

function renderFavoritos(){
  const content = document.getElementById('pageOverlayBody');
  if(!content) return;
  const categories = CATEGORY_ORDER.filter(cat => state.entries.some(e => e.favorito && e.categoria === cat));
  const favoriteEntries = state.entries.filter(e => e.favorito);
  const items = getFavoriteResultItems(favoriteEntries);
  const categoryOptions = CATEGORY_ORDER.map(cat => `<option value="${cat}" ${state.favoritosCategoria===cat?'selected':''}>${escapeHtml(CATEGORY_META[cat].plural)}</option>`).join('');
  const statusOptions = STATUS_ORDER.map(status => `<option value="${status}" ${state.favoritosStatus===status?'selected':''}>${escapeHtml(statusLabel(status))}</option>`).join('');
  let html = `<div class="favorites-page"><div class="favorites-intro"><div><div class="activity-kicker">ACERVO · CURADORIA</div><h2>Minhas obras favoritas</h2><p>Organize, filtre e reveja as obras que marcou com o coração.</p></div><div class="activity-summary"><div><strong>${favoriteEntries.length}</strong><span>favoritas</span></div><div><strong>${categories.length}</strong><span>categorias</span></div></div></div><div class="favorites-toolbar"><label class="favorites-search">Pesquisar<input id="favoritesSearchInput" type="text" value="${escapeHtml(state.favoritosBusca || '')}" placeholder="Título, autor ou gênero..."></label><label>Categoria<select id="favoritesCategory"><option value="todos" ${state.favoritosCategoria==='todos'?'selected':''}>Todas as categorias</option>${categoryOptions}</select></label><label>Status<select id="favoritesStatus"><option value="todos" ${state.favoritosStatus==='todos'?'selected':''}>Todos os status</option>${statusOptions}</select></label><label>Ordenar<select id="favoritesSort"><option value="recente" ${state.favoritosOrdenacao==='recente'?'selected':''}>Mais recentes</option><option value="alfabetica" ${state.favoritosOrdenacao==='alfabetica'?'selected':''}>A–Z</option><option value="nota" ${state.favoritosOrdenacao==='nota'?'selected':''}>Melhor avaliação</option></select></label>${viewModeControlsHtml('favoritos', state.favoritosViewMode, 'Visualização')}<span class="favorites-count">${items.length} de ${favoriteEntries.length} exibida(s)</span></div>`;
  html += '<div id="favoritesResults"></div>';
  html += '</div>'; content.innerHTML = html;
  const results = updateFavoritesResults(content);
  const rerender = () => { persistUiState(); renderMain(); };
  const search = content.querySelector('#favoritesSearchInput');
  if(search) search.addEventListener('input', debounce(e => {
    state.favoritosBusca = e.target.value;
    persistUiState();
    updateFavoritesResults(content);
  }, 180));
  const category = content.querySelector('#favoritesCategory'); if(category) category.addEventListener('change', e => { state.favoritosCategoria = e.target.value; rerender(); });
  const status = content.querySelector('#favoritesStatus'); if(status) status.addEventListener('change', e => { state.favoritosStatus = e.target.value; rerender(); });
  const sort = content.querySelector('#favoritesSort'); if(sort) sort.addEventListener('change', e => { state.favoritosOrdenacao = e.target.value; rerender(); });
  bindViewModeControls(content, 'favoritos', mode => { state.favoritosViewMode = mode; persistUiState(); renderMain(); });
  if(results) results.addEventListener('click', ev => {
    const card = ev.target.closest('[data-card-id]');
    if(!card) return;
    const id = card.dataset.cardId;
    if(ev.target.closest('.fav-btn, .favorite-row-toggle')){ ev.stopPropagation(); toggleFavorite(id); updateFavoritesResults(content); return; }
    if(ev.target.closest('.cover-blur-btn')){ ev.stopPropagation(); toggleCapaDesfocada(id); return; }
    if(ev.target.closest('[data-action="edit"]')){ ev.stopPropagation(); openFormModal(id); return; }
    if(ev.target.closest('[data-action="delete"]')){ ev.stopPropagation(); openConfirmDelete(id); return; }
    if(ev.target.closest('.card-clickable') || ev.target.closest('.favorite-row-open')) openDetailModal(id);
  });
}
function renderListasOverview(){
  const content = document.getElementById('pageOverlayBody');
  let html = `<div class="search-wrap" style="max-width:420px; margin:0 0 16px; position:relative;">
    <svg class="icon" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-faint);width:16px;height:16px;"><use href="#i-search"/></svg>
    <input type="text" id="listasSearchInput" class="search-input" placeholder="Pesquisar suas listas..." value="${escapeHtml(state.listasSearchTerm||'')}" autocomplete="off" style="padding-left:32px;">
    <button type="button" class="search-clear-btn" data-clear-target="listasSearchInput" aria-label="Limpar pesquisa" ${state.listasSearchTerm?'':'hidden'}><svg class="icon"><use href="#i-close"/></svg></button>
  </div>`;
  html += `<div class="action-box">
    <button class="btn ${state.selectionMode?'btn-primary':''}" id="btnToggleSelectionListas"><svg class="icon"><use href="#i-check-square"/></svg> ${state.selectionMode?'Cancelar seleção':'Selecionar listas'}</button>
    ${state.selectionMode ? `
      <button type="button" class="btn btn-sm btn-danger" id="btnDeleteSelectedListas" ${state.selectedIds.size===0?'disabled':''}><svg class="icon"><use href="#i-trash"/></svg> Apagar</button>
      <button type="button" class="btn btn-sm btn-ghost" id="btnSelectAllListas">Selecionar tudo</button>
      <span class="count" id="selectionCountListas" style="font-family:var(--font-mono); font-size:0.72rem; color:var(--text-muted);">${state.selectedIds.size} selecionada(s)</span>
    ` : ''}
    <div class="action-box-spacer"></div>
    <button type="button" class="btn btn-primary" id="btnCreateLista"><svg class="icon"><use href="#i-folder-plus"/></svg> Criar lista personalizada</button>
     ${viewModeControlsHtml('listas', state.listasViewMode, 'Visualização')}
  </div>`;

  if(state.listas.length === 0){
    html += emptyStateHtml('shelf', 'Nenhuma lista criada ainda', 'Crie listas personalizadas para organizar suas obras como quiser — por humor, maratona, prioridade etc.', false);
    html = html.replace('</p>', '</p><button class="btn btn-primary" id="emptyStateCreateLista"><svg class="icon"><use href="#i-folder-plus"/></svg> Criar primeira lista</button>');
  } else {
    const _listasTerm = (state.listasSearchTerm||'').toLowerCase();
    const _listasFiltradas = sortListasForOverview(_listasTerm ? state.listas.filter(l => l.nome.toLowerCase().includes(_listasTerm)) : state.listas);
    if(_listasFiltradas.length === 0){
      html += `<div style="padding:24px;text-align:center;color:var(--text-muted);">Nenhuma lista encontrada para "${escapeHtml(state.listasSearchTerm)}".</div>`;
    } else {
       html += `<div class="lists-grid view-mode-${state.listasViewMode||'cards'}">${_listasFiltradas.map(listaCardHtml).join('')}</div>`;
    }
  }
  content.innerHTML = html;
  scheduleListRowNameMarquee();


  const btnToggleSelectionListas = document.getElementById('btnToggleSelectionListas');
  if(btnToggleSelectionListas) btnToggleSelectionListas.addEventListener('click', () => { state.selectionMode = !state.selectionMode; state.selectedIds = new Set(); renderMain(); });
  const btnCreateLista = document.getElementById('btnCreateLista');
  if(btnCreateLista) btnCreateLista.addEventListener('click', () => openListaFormModal(null));
   bindViewModeControls(content, 'listas', mode => {
     if(!['cards','rows'].includes(mode)) return;
     state.listasViewMode = mode;
     persistUiState();
      const overlay = document.getElementById('pageOverlay');
      const scrollY = overlay ? overlay.scrollTop : 0;
      applyViewModeWithoutRebuild(content, 'listas', mode, '.lists-grid');
      // Não usar scrollIntoView/âncoras aqui: em listas com alturas diferentes
      // isso empurrava sobretudo a última linha para cima. O contêiner é a
      // única fonte de verdade e a posição é reaplicada até o layout estabilizar.
      if(overlay) restoreElementScrollUntilStable(overlay, scrollY);
   });
  const emptyCta = document.getElementById('emptyStateCreateLista');
  if(emptyCta) emptyCta.addEventListener('click', () => openListaFormModal(null));
  const btnSelectAllListas = document.getElementById('btnSelectAllListas');
  if(btnSelectAllListas) btnSelectAllListas.addEventListener('click', () => {
    const listasSelectaveis = state.listas.filter(l => !l.defaultCat);
    if(state.selectedIds.size === listasSelectaveis.length) state.selectedIds = new Set();
    else state.selectedIds = new Set(listasSelectaveis.map(l => l.id));
    renderMain();
  });
  const btnDeleteSelectedListas = document.getElementById('btnDeleteSelectedListas');
  if(btnDeleteSelectedListas) btnDeleteSelectedListas.addEventListener('click', () => openConfirmDeleteListas(Array.from(state.selectedIds)));
  const _listasSearchEl = document.getElementById('listasSearchInput');
  if(_listasSearchEl){
    _listasSearchEl.addEventListener('input', (ev) => {
      state.listasSearchTerm = ev.target.value;
      // Atualiza apenas a grade sem re-renderizar toda a página (mantém foco e teclado no mobile)
      const term = (state.listasSearchTerm||'').toLowerCase();
      const filtered = sortListasForOverview(term ? state.listas.filter(l => l.nome.toLowerCase().includes(term)) : state.listas);
      const body = document.getElementById('pageOverlayBody');
      let grid = body && body.querySelector('.lists-grid');
      const clearBtn = body && body.querySelector('.search-clear-btn[data-clear-target="listasSearchInput"]');
      if(clearBtn) clearBtn.hidden = !term;
      if(!grid){
        // Recria a grade se antes estava vazia
        const container = body && body.querySelector('.action-box');
        if(container && container.parentNode){
          const div = document.createElement('div');
           div.className = 'lists-grid view-mode-' + (state.listasViewMode||'cards');
          container.parentNode.insertBefore(div, container.nextSibling);
          grid = div;
        }
      }
      if(grid){
        grid.innerHTML = filtered.map(listaCardHtml).join('');
        // Rebind eventos dos cards recém-criados
        filtered.forEach(l => {
          const card = grid.querySelector(`[data-lista-id="${l.id}"]`);
          if(!card) return;
          const openBtn = card.querySelector('.list-card-open');
          if(openBtn) openBtn.addEventListener('click', () => { if(state.selectionMode){ toggleListaSelected(l.id); } else { state.listaAtivaId = l.id; if(window.__pushNav) window.__pushNav(); state.view = 'lista-detalhe'; exitSelectionMode(); renderMain(); } });
          const editBtn = card.querySelector('[data-action="edit-lista"]');
          if(editBtn) editBtn.addEventListener('click', (ev2) => { ev2.stopPropagation(); openListaFormModal(l.id); });
          const delBtn = card.querySelector('[data-action="delete-lista"]');
          if(delBtn) delBtn.addEventListener('click', (ev2) => { ev2.stopPropagation(); openConfirmDeleteListas([l.id]); });
          const cb = card.querySelector('.list-card-checkbox');
          if(cb){
            cb.checked = state.selectedIds.has(l.id);
            cb.addEventListener('click', (ev2) => { ev2.stopPropagation(); toggleListaSelected(l.id); });
          }
        });
      }
      scheduleListRowNameMarquee();
    });
  }
  const _cancelListasSel = document.getElementById('btnCancelSelectionListas');
  if(_cancelListasSel) _cancelListasSel.addEventListener('click', () => { exitSelectionMode(); renderMain(); });

  const listasRenderizadas = Array.from(content.querySelectorAll('[data-lista-id]')).map(card => card.dataset.listaId);
  listasRenderizadas.forEach(listaId => {
    const l = getListaById(listaId);
    if(!l) return;
    const card = document.querySelector(`[data-lista-id="${l.id}"]`);
    if(!card) return;
    const checkbox = card.querySelector('.obra-row-checkbox, .list-card-checkbox');
    if(checkbox){
      checkbox.checked = state.selectedIds.has(l.id);
      checkbox.addEventListener('click', (ev) => { ev.stopPropagation(); toggleListaSelected(l.id); });
    }
    const openBtn = card.querySelector('.list-card-open');
    if(openBtn) openBtn.addEventListener('click', () => { if(state.selectionMode){ toggleListaSelected(l.id); } else { state.listaAtivaId = l.id; if(window.__pushNav) window.__pushNav(); state.view = 'lista-detalhe'; exitSelectionMode(); renderMain(); } });
    const editBtn = card.querySelector('[data-action="edit-lista"]');
    if(editBtn) editBtn.addEventListener('click', (ev) => { ev.stopPropagation(); openListaFormModal(l.id); });
    const delBtn = card.querySelector('[data-action="delete-lista"]');
    if(delBtn) delBtn.addEventListener('click', (ev) => { ev.stopPropagation(); openConfirmDeleteListas([l.id]); });
  });
}
function toggleListaSelected(id){
  const lista = getListaById(id);
  if(lista && lista.defaultCat) return; // Não permite selecionar listas padrões
  if(state.selectedIds.has(id)) state.selectedIds.delete(id); else state.selectedIds.add(id);
  renderMain();
}
function toggleObraSelected(id){
  if(state.selectedIds.has(id)) state.selectedIds.delete(id); else state.selectedIds.add(id);
  renderMain();
}
function openConfirmDeleteMultiple(ids){
  if(!ids.length) return;
  const count = ids.length;
  state.confirmDeleteIds = ids;
  const msg = count === 1 ? '1 obra será removida do acervo.' : count + ' obras serão removidas do acervo.';
  document.getElementById('confirmModalTitle').textContent = 'Remover ' + count + ' obra' + (count===1?'':'s');
  document.getElementById('confirmModalText').textContent = msg;
  document.getElementById('confirmModalOk').textContent = 'Remover';
  document.getElementById('confirmModalOk').onclick = () => { deleteMultipleEntries(ids); closeConfirmModal(); };
  document.getElementById('confirmModalBackdrop').hidden = false;
}
function deleteMultipleEntries(ids){
  const idSet = new Set(ids);
  const removedEntries = state.entries.filter(e => idSet.has(e.id));
  const affectedListas = (state.listas||[]).filter(l => Array.isArray(l.obraIds) && l.obraIds.some(oid => idSet.has(oid))).map(l => JSON.parse(JSON.stringify(l)));
  state.entries = state.entries.filter(e => !idSet.has(e.id));
  // Cascata: remove das listas personalizadas
  (state.listas||[]).forEach(lista => { if(Array.isArray(lista.obraIds)) lista.obraIds = lista.obraIds.filter(oid => !idSet.has(oid)); });
  cleanupEmptyCustomLists();
  exitSelectionMode();
  recordEntriesActivity('deleted', removedEntries, removedEntries.length === 1 ? 'Obra apagada do acervo.' : `${removedEntries.length} obras apagadas do acervo.`);
  persistEntries();
  persistListas();
  renderMain();
  showUndoToast(ids.length + ' obra(s) removida(s).', () => {
    removedEntries.forEach(e => { if(!state.entries.some(x => x.id === e.id)) state.entries.push(e); });
    recordEntriesActivity('restored', removedEntries, removedEntries.length === 1 ? 'Obra restaurada após desfazer.' : `${removedEntries.length} obras restauradas após desfazer.`);
    affectedListas.forEach(snapLista => {
      const lista = state.listas.find(l => l.id === snapLista.id);
      if(lista){ snapLista.obraIds.forEach(oid => { if(!lista.obraIds.includes(oid)) lista.obraIds.push(oid); }); }
      else state.listas.push(snapLista);
    });
    persistEntries(); persistListas(); renderMain();
    showToast('success', 'Obras restauradas.');
  });
}
function openListSelectorModalForMultiple(ids){
  const categoriasPresentes = new Set();
  ids.forEach(id => {
    const entry = state.entries.find(e => e.id === id);
    if(entry) categoriasPresentes.add(entry.categoria);
  });
  state.selectedObraIdsForLista = new Set(ids);
  pickerTargetListaId = null;
  const categoriaSelecionada = Array.from(categoriasPresentes)[0] || 'todos';
  const catLabel = categoriasPresentes.size > 1 ? 'categorias diferentes' : (CATEGORY_META[categoriaSelecionada] ? CATEGORY_META[categoriaSelecionada].plural : 'a categoria selecionada');
  // Neste seletor aparecem apenas listas personalizadas, sempre em ordem alfabética.
  // As listas padrão são sincronizadas automaticamente e não precisam ser escolhidas aqui.
  const listasDisponiveis = state.listas
    .filter(l => !l.defaultCat)
    .sort((a, b) => String(a.nome || '').localeCompare(String(b.nome || ''), 'pt-BR', { sensitivity: 'base' }));
  // IMPORTANTE: usa um id próprio (listSelectorMultiModalBackdrop) diferente do modal estático
  // (listSelectorModalBackdrop) para evitar IDs duplicados no DOM, o que fazia os listeners
  // serem ligados ao elemento errado (modal estático oculto) e o botão "Cancelar" não funcionar.
  const html = `<div id="listSelectorMultiModalBackdrop" class="modal-backdrop">
    <div class="modal">
      <div class="modal-header">
        <h2>Adicionar a lista</h2>
        <button type="button" id="listSelectorMultiModalClose" class="btn btn-ghost"><svg class="icon"><use href="#i-close"/></svg></button>
      </div>
      <div class="modal-body">
        <p class="field-hint" style="margin-top:0;">Selecionadas: <strong>${escapeHtml(catLabel)}</strong>. Listas específicas respeitam a categoria; listas mistas aceitam qualquer obra.</p>
        ${listasDisponiveis.length === 0 ? '<p style="color:var(--text-muted);">Nenhuma lista personalizada criada ainda. Crie uma lista primeiro.</p>' : ''}
        <div style="display:grid; gap:8px;">${listasDisponiveis.map(l => {
          const canAdd = listaAceitaCategoria(l, categoriaSelecionada);
          const listaCatLabel = listaCategoriaLabel(l.categoria);
          const categoryNote = canAdd ? '' : ` (${listaCatLabel})`;
          return `<button type="button" class="list-selector-item ${canAdd?'':'disabled'}" data-lista-id="${l.id}" ${canAdd?'':'disabled'} style="padding:12px; border:1px solid var(--border); border-radius:6px; background:var(--bg-elevated-2); color:var(--text); text-align:left; cursor:${canAdd?'pointer':'not-allowed'}; opacity:${canAdd?'1':'0.5'};">${escapeHtml(l.nome)}${escapeHtml(categoryNote)}</button>`;
        }).join('')}</div>
      </div>
      <div class="modal-footer">
        <button type="button" id="listSelectorMultiCancelBtn" class="btn btn-ghost">Cancelar</button>
      </div>
    </div>
  </div>`;
  document.body.insertAdjacentHTML('beforeend', html);
  const backdrop = document.getElementById('listSelectorMultiModalBackdrop');
  backdrop.addEventListener('click', _backdropTapHandler(closeListSelectorMultiModal));
  document.getElementById('listSelectorMultiModalClose').addEventListener('click', closeListSelectorMultiModal);
  document.getElementById('listSelectorMultiCancelBtn').addEventListener('click', closeListSelectorMultiModal);
  document.querySelectorAll('.list-selector-item:not(.disabled)').forEach(btn => {
    btn.addEventListener('click', () => {
      const listaId = btn.dataset.listaId;
      const lista = getListaById(listaId);
      if(!lista) return;
      // Revalida no momento do clique: uma lista só pode ter obras da mesma categoria, sempre.
      if(!listaAceitaCategoria(lista, categoriaSelecionada)){
        const catLabel = CATEGORY_META[lista.categoria] ? CATEGORY_META[lista.categoria].plural.toLowerCase() : 'outra categoria';
        showToast('error', 'Essa lista é apenas de ' + catLabel + '. Não é possível adicionar obras de categorias diferentes.');
        closeListSelectorMultiModal();
        renderMain();
        return;
      }
      let adicionadas = 0;
      Array.from(state.selectedObraIdsForLista).forEach(obraId => {
        if(!lista.obraIds.includes(obraId)) { lista.obraIds.push(obraId); adicionadas++; }
      });
      persistListas();
      state.selectedIds = new Set();
      state.selectedObraIdsForLista = new Set();
      exitSelectionMode();
      closeListSelectorMultiModal();
      renderMain();
      if(adicionadas > 0) showToast('success', adicionadas + ' obra(s) adicionada(s) à lista "' + lista.nome + '".');
      else showToast('warning', 'As obras selecionadas já estavam nesta lista.');
    });
  });
}
function closeListSelectorMultiModal(){
  const backdrop = document.getElementById('listSelectorMultiModalBackdrop');
  if(backdrop) backdrop.remove();
}
// Mantido por compatibilidade (modal estático único de obra usa este nome)
function closeListSelectorModal(){
  const backdrop = document.getElementById('listSelectorModalBackdrop');
  if(backdrop) backdrop.hidden = true;
  listSelectorObraId = null;
}
function listaCardHtml(lista){
  const count = getEntriesOfLista(lista).length;
  const meta = lista.categoria && lista.categoria !== 'todos' ? CATEGORY_META[lista.categoria] : null;
  const catColorBase = meta ? meta.color : 'var(--c-gold)';
  const catLabel = meta ? meta.plural : 'Mista';
  const isDefault = !!lista.defaultCat;
  const subInfo = listaSubcategoryInfo(lista);
  // Cor: subcategoria usa variante própria; categoria pai usa a cor da categoria.
  const catColor = subInfo ? subInfo.color : catColorBase;
  const cardClass = 'list-card' + (subInfo ? ' list-card--subcategory list-card--' + subInfo.type + '-subcategory' : '');
  // Título: para subcategorias mostra "Filme · Cinema", "Novel · Web Novel", etc.
  const subCombined = subInfo ? `${subInfo.parentLabel} · ${subInfo.label}` : '';
  const displayTitle = subInfo ? subCombined : lista.nome;
  const kicker = subInfo ? subCombined : `${catLabel}${isDefault ? ' · Padrão' : ''}`;
  // Nome branco redundante é escondido para listas padrão e de subcategoria
  // (o kicker já identifica a lista). Listas personalizadas mantêm o nome visível.
  const showName = !subInfo && !isDefault;

  return `<div class="${cardClass}" data-lista-id="${lista.id}" style="--cat-color:${catColor}; border-left:4px solid ${catColor};">
    ${state.selectionMode ? `<input type="checkbox" class="list-card-checkbox" ${isDefault?'disabled':''} style="position:absolute; top:10px; left:10px; width:18px; height:18px; accent-color:var(--c-gold); ${isDefault?'cursor:not-allowed;opacity:0.5;':''}">` : ''}
    <button class="card-clickable list-card-open" aria-label="Abrir lista ${escapeHtml(displayTitle)}" style="${state.selectionMode?'left:0;':''}"></button>
    <div class="list-card-actions">
      ${isDefault ? '' : `<button class="icon-btn" data-action="edit-lista" aria-label="Editar lista"><svg class="icon"><use href="#i-edit"/></svg></button>
      <button class="icon-btn danger" data-action="delete-lista" aria-label="Remover lista"><svg class="icon"><use href="#i-trash"/></svg></button>`}
    </div>
    <div class="list-card-kicker">
      <svg class="icon icon-list" style="color:${catColor};"><use href="#i-list"/></svg>
      <span>${escapeHtml(kicker)}</span>
    </div>
    ${showName ? `<div class="list-card-name" title="${escapeHtml(displayTitle)}"><span class="marquee-track">${escapeHtml(displayTitle)}</span></div>` : ''}
    <div class="list-card-count">${count} OBRA${count===1?'':'S'}</div>
  </div>`;
}

// "Modo lista" (linhas) deixa pouco espaço horizontal para o nome da lista.
// Em vez de esconder o nome ou cortá-lo com reticências, quando o texto não
// cabe ele desliza para mostrar a informação completa. A pausa inicial e a
// velocidade mais baixa são intencionais: dão tempo para ler o começo do
// nome antes de a faixa começar a avançar.
function applyListRowNameMarquee(){
  document.querySelectorAll('.lists-grid.view-mode-rows .list-card-name').forEach(el => {
    const track = el.querySelector('.marquee-track');
    if(!track) return;
    el.classList.remove('is-marquee');
    track.style.removeProperty('--marquee-shift');
    track.style.animationDuration = '';
    const overflow = track.scrollWidth - el.clientWidth;
    if(overflow > 4){
      const shift = overflow + 6;
      track.style.setProperty('--marquee-shift', '-' + shift + 'px');
      // Nomes longos precisam de alguns segundos a mais para serem lidos;
      // não acelerar a faixa quando o espaço disponível for muito pequeno.
      track.style.animationDuration = Math.max(7, shift / 18) + 's';
      el.classList.add('is-marquee');
    }
  });
}
let _listRowMarqueeResizeBound = false;
function scheduleListRowNameMarquee(){
  // Roda depois do próximo paint, para medir larguras já com o layout
  // final aplicado (fontes, ícones e paddings do card já renderizados).
  requestAnimationFrame(() => requestAnimationFrame(applyListRowNameMarquee));
  // Fontes customizadas (var(--font-display)) podem só terminar de carregar
  // DEPOIS da primeira medição, mudando a largura real do texto — sem isso,
  // um nome que só "estoura" com a fonte final ficava com a animação
  // desligada por ter sido medida cedo demais, com a fonte de fallback.
  if(document.fonts && document.fonts.ready){
    document.fonts.ready.then(() => {
      if(state.view === 'listas' && state.listasViewMode === 'rows') applyListRowNameMarquee();
    }).catch(() => {});
  }
  if(!_listRowMarqueeResizeBound){
    _listRowMarqueeResizeBound = true;
    window.addEventListener('resize', debounce(() => {
      if(state.view === 'listas' && state.listasViewMode === 'rows') applyListRowNameMarquee();
    }, 200));
  }
}

function renderListaDetalhe(){
  const lista = getListaById(state.listaAtivaId);
  const content = document.getElementById('pageOverlayBody');
  if(!lista){ state.view = 'listas'; renderMain(); return; }
  const entriesInLista = getEntriesOfLista(lista);
  const listaMeta = lista.categoria && lista.categoria !== 'todos' ? CATEGORY_META[lista.categoria] : null;
  const listaCategoriaLabel = listaMeta ? listaMeta.plural : 'Mista — várias categorias';
  const listaCategoriaColor = listaMeta ? listaMeta.color : 'var(--c-gold)';
  const listaSubInfo = listaSubcategoryInfo(lista);

  let html = `<div class="list-detail-header${listaSubInfo ? ' list-detail-header--subcategory' : ''}" style="--cat-color:${listaCategoriaColor};">
    <h2 title="${escapeHtml(lista.nome)}">${escapeHtml(lista.nome)}</h2>
    <span class="list-detail-category">${escapeHtml(listaCategoriaLabel)}${listaSubInfo ? ' · ' + escapeHtml(listaSubInfo.label) : ''}${lista.defaultCat ? ' · Padrão' : ''}</span>
  </div>`;

  if(listaSubInfo){
    html += `<div class="list-detail-subcategory-callout"><span>Subcategoria</span><strong>${escapeHtml(listaSubInfo.label)}</strong><em>${escapeHtml(listaSubInfo.parent)}</em></div>`;
  }
  html += `<div class="list-detail-sub">${entriesInLista.length} OBRA${entriesInLista.length===1?'':'S'} NESTA LISTA${lista.defaultCat ? ' · LISTA PADRÃO (sincronizada automaticamente)' : ''}</div>`;
  html += `<div class="action-box${state.selectionMode?' is-floating':''}" id="listaDetalheActionBox">
    <button class="btn${state.selectionMode?' btn-primary':''}" id="btnToggleSelectionObras"><svg class="icon"><use href="#i-check-square"/></svg> <span class="sel-toggle-label">${state.selectionMode?'Cancelar':'Selecionar'}</span></button>
    <button class="btn btn-sm btn-danger sel-only" id="btnRemoveSelectedObras" ${state.listaDetalheSelectedIds.size===0?'disabled':''}><svg class="icon"><use href="#i-trash"/></svg> ${lista.defaultCat ? 'Apagar do acervo' : 'Apagar da lista'}</button>
    <div class="action-box-spacer sel-only"></div>
    <button class="btn btn-sm btn-ghost sel-only" id="btnSelectAllObras">Selecionar tudo</button>
    <span class="count sel-only" id="selectionCountObras" style="font-family:var(--font-mono); font-size:0.72rem; color:var(--text-muted);">${state.listaDetalheSelectedIds.size} selecionada(s)</span>
    ${lista.defaultCat ? '' : `<button class="btn btn-primary" id="btnAddObrasLista" style="${state.selectionMode?'display:none;':''}"><svg class="icon"><use href="#i-plus"/></svg> Adicionar obras</button>`}
    <button class="btn btn-sm" id="btnPdfLista" title="Gerar PDF desta lista" style="margin-left:auto;"${entriesInLista.length===0?' disabled':''}><svg class="icon"><use href="#i-download"/></svg> PDF</button>
     ${viewModeControlsHtml('lista-obras', state.listaObrasViewMode, 'Obras')}
  </div>
  <div class="action-box-placeholder" id="listaDetalheActionBoxPlaceholder"></div>`;
  html += `<div class="search-wrap" style="max-width:420px; margin:0 0 16px; position:relative;">
    <svg class="icon" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-faint);width:16px;height:16px;"><use href="#i-search"/></svg>
    <input type="text" id="listaDetalheSearchInput" class="search-input" placeholder="Pesquisar obras nesta lista..." value="${escapeHtml(state.listaDetalheSearchTerm||'')}" autocomplete="off" style="padding-left:32px;">
    <button type="button" class="search-clear-btn" data-clear-target="listaDetalheSearchInput" aria-label="Limpar pesquisa" ${state.listaDetalheSearchTerm?'':'hidden'}><svg class="icon"><use href="#i-close"/></svg></button>
  </div>`;

  // Aplica filtro de busca apenas para exibição
  const _ldTerm = (state.listaDetalheSearchTerm||'').toLowerCase();
  const _entriesView = _ldTerm ? entriesInLista.filter(e => normalizeText([e.titulo, e.titulo_original].filter(Boolean).join(' ')).includes(normalizeText(_ldTerm))) : entriesInLista;

  if(entriesInLista.length === 0){
    html += emptyStateHtml('shelf', 'Lista vazia', 'Adicione obras do seu acervo a esta lista personalizada.', false);
  } else {
    if(_ldTerm && _entriesView.length === 0){
      html += `<div style="padding:24px;text-align:center;color:var(--text-muted);">Nenhuma obra encontrada para "${escapeHtml(state.listaDetalheSearchTerm)}".</div>`;
    }
    // Ordem alfabética (A-Z, 0-9) dentro de cada lista/categoria
    const _alphaSort = (a,b) => String(a.titulo||'').localeCompare(String(b.titulo||''), 'pt-BR', {numeric:true, sensitivity:'base'});
    CATEGORY_ORDER.forEach(cat => {
      const items = _entriesView.filter(e => e.categoria === cat).slice().sort(_alphaSort);
      if(!items.length) return;
      const meta = CATEGORY_META[cat];
      html += `<div class="category-group"><div class="category-group-label" style="--cat-color:${meta.color}"><svg class="icon"><use href="#${meta.icon}"/></svg>${meta.plural} · ${items.length}</div>`;
      if(cat === 'filme' || cat === 'novel'){
        subcategoryGroupsForCategory(cat, items).forEach(group => {
          const sortedGroup = group.items.slice().sort(_alphaSort);
          html += `<div class="subcategory-group" style="--cat-color:${meta.color};">
            <div class="subcategory-group-label"><span>Subcategoria</span><strong>${escapeHtml(group.info.label)}</strong><em>${sortedGroup.length} obra${sortedGroup.length===1?'':'s'}</em></div>
             <div class="obra-list view-mode-${state.listaObrasViewMode||'rows'}${state.selectionMode?' is-select-mode':''}">${sortedGroup.map(e => obraRowHtml(e, lista)).join('')}</div>
          </div>`;
        });
      } else {
        html += `<div class="obra-list view-mode-${state.listaObrasViewMode||'rows'}${state.selectionMode?' is-select-mode':''}">${items.map(e => obraRowHtml(e, lista)).join('')}</div>`;
      }
      html += `</div>`;
    });
  }
  content.innerHTML = html;
  bindViewModeControls(content, 'lista-obras', mode => {
    if(!['rows','cards'].includes(mode)) return;
    state.listaObrasViewMode = mode;
    persistUiState();
    const overlay = document.getElementById('pageOverlay');
    const scrollY = overlay ? overlay.scrollTop : 0;
    content.querySelectorAll('.obra-list').forEach(list => {
      Array.from(list.classList).forEach(className => {
        if(className.startsWith('view-mode-')) list.classList.remove(className);
      });
      list.classList.add(`view-mode-${mode}`);
    });
    if(overlay) restoreElementScrollUntilStable(overlay, scrollY);
    content.querySelectorAll('[data-view-scope="lista-obras"] [data-view-mode]').forEach(btn => {
      const active = btn.dataset.viewMode === mode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  });
  bindListaDetalheEvents(lista, entriesInLista);
}
function obraRowHtml(e, lista){
  const meta = CATEGORY_META[e.categoria];
  const coverSrc = e.capa_base64 || e.capa_url;
  const prog = progressoTexto(e);
  const subInfo = entrySubcategoryInfo(e);
  
  let extras = '';
  if(e.categoria === 'anime' && (e.temporadas || e.extras_independentes)){
    const allExtras = [];
    (e.temporadas||[]).forEach(t => { (t.extras||[]).forEach(ex => allExtras.push(ex)); });
    (e.extras_independentes||[]).forEach(ex => allExtras.push(ex));
    const hasFilme = allExtras.some(ex => ex.tipo === 'Filme');
    const hasOVA = allExtras.some(ex => ex.tipo === 'OVA');
    if(hasFilme || hasOVA){
      const badges = [];
      if(hasFilme) badges.push('<span title="Tem filme" class="obra-row-extra-badge">F</span>');
      if(hasOVA) badges.push('<span title="Tem OVA" class="obra-row-extra-badge obra-row-extra-badge--ova">O</span>');
      // No modo Lista (padrão), ficam soltos no canto superior direito de
      // toda a linha (como sempre foi) — só no modo Cartões é que o CSS os
      // reposiciona para dentro da capa (canto superior esquerdo), já que
      // aí a capa ocupa a linha inteira. Ver .obra-list.view-mode-cards
      // .obra-row-extras no CSS.
      extras = `<div class="obra-row-extras">${badges.join('')}</div>`;
    }
  }
  
  const _rowColor = (subInfo && subInfo.key !== 'sem-subcategoria' && subInfo.color) ? subInfo.color : meta.color;
  return `<div class="obra-row${isCapaDesfocada(e.id)?' is-capa-desfocada':''}" data-obra-id="${e.id}" style="--cat-color:${_rowColor};position:relative;">
    <input type="checkbox" class="obra-row-checkbox" ${state.listaDetalheSelectedIds.has(e.id)?'checked':''}>
    ${extras}
    <div class="obra-row-cover">
      ${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="window.__coverFallback(this)">` : `<svg class="icon"><use href="#${meta.icon}"/></svg>`}
      ${e.categoria!=='filme' ? `<span class="obra-row-stamp obra-row-stamp--status" style="color:${statusColor(e.status)}">${statusLabel(e.status)}</span>` : ''}
      ${e.status_oficial ? `<span class="obra-row-stamp obra-row-stamp--official" style="color:${officialStatusColor(e.status_oficial)}" title="Status Oficial da obra">${officialStatusLabel(e.status_oficial)}</span>` : ''}
      <button type="button" class="cover-blur-btn${isCapaDesfocada(e.id)?' is-on':''}" data-action="toggle-cover-blur" aria-label="Desfocar capa" aria-pressed="${isCapaDesfocada(e.id)}" title="Mostrar ou desfocar esta capa">${isCapaDesfocada(e.id)?'🙈':'👁'}</button>
    </div>
    <div class="obra-row-main">
      <div class="obra-row-title">${escapeHtml(e.titulo)}</div>
      <div class="obra-row-meta">
        ${e.categoria!=='filme' ? `<span class="obra-row-status" style="color:${statusColor(e.status)}">${statusLabel(e.status)}</span>` : ''}
        ${e.status_oficial ? `<span class="obra-row-status" style="color:${officialStatusColor(e.status_oficial)}" title="Status Oficial da obra">${officialStatusLabel(e.status_oficial)}</span>` : ''}
        ${subInfo ? `<span class="obra-row-subcat">${escapeHtml(subInfo.label)}</span>` : ''}
        ${typeof e.nota === 'number' ? `<span class="obra-row-rating">${e.nota.toFixed(1).replace('.0','')}</span>` : ''}
        ${e.ano ? `<span>${e.ano}</span>` : ''}
        ${prog ? `<span>${escapeHtml(prog)}</span>` : ''}
      </div>
    </div>
    <div class="obra-row-actions">
      <button class="icon-btn" data-action="view-detail" aria-label="Editar"><svg class="icon"><use href="#i-edit"/></svg></button>
      <button class="icon-btn danger" data-action="remove-from-lista" aria-label="Remover da lista"><svg class="icon"><use href="#i-trash"/></svg></button>
    </div>
  </div>`;
}
function bindListaDetalheEvents(lista, entriesInLista){
  // Botão "Voltar" agora vive no cabeçalho do overlay (#pageOverlayBack)

  // Escopo TODAS as consultas ao pageOverlayBody para evitar colisão de IDs
  // com a renderGrid (que também usa #btnToggleSelectionObras, #btnSelectAllObras, etc.)
  const _ldScope = document.getElementById('pageOverlayBody');
  const _ldToggle = _ldScope.querySelector('#btnToggleSelectionObras');
  if(_ldToggle) _ldToggle.addEventListener('click', () => {
    // Toggle instantâneo — mesmo comportamento do botão da página de listas (sem re-render)
    state.selectionMode = !state.selectionMode;
    state.listaDetalheSelectedIds = new Set();
    const actionBox = _ldScope.querySelector('#listaDetalheActionBox');
    if(actionBox) actionBox.classList.toggle('is-floating', state.selectionMode);
    _ldToggle.classList.toggle('btn-primary', state.selectionMode);
    const lbl = _ldToggle.querySelector('.sel-toggle-label');
    if(lbl) lbl.textContent = state.selectionMode ? 'Cancelar' : 'Selecionar';
    // Esconde "Adicionar obras" durante seleção (para listas não-padrão)
    const addBtn = _ldScope.querySelector('#btnAddObrasLista');
    if(addBtn) addBtn.style.display = state.selectionMode ? 'none' : '';
    // Toggle nas obra-list para mostrar/esconder checkboxes via CSS
    _ldScope.querySelectorAll('.obra-list').forEach(ol => {
      ol.classList.toggle('is-select-mode', state.selectionMode);
    });
    // Limpa estado visual de seleção sem reconstruir o DOM
    _ldScope.querySelectorAll('.obra-row .obra-row-checkbox').forEach(cb => { cb.checked = false; });
    _ldScope.querySelectorAll('.obra-row.is-selected').forEach(r => r.classList.remove('is-selected'));
    const cnt = _ldScope.querySelector('#selectionCountObras');
    if(cnt) cnt.textContent = '0 selecionada(s)';
    const removeBtn = _ldScope.querySelector('#btnRemoveSelectedObras');
    if(removeBtn) removeBtn.disabled = true;
  });
  const addObrasBtn = _ldScope.querySelector('#btnAddObrasLista');
  if(addObrasBtn) addObrasBtn.addEventListener('click', () => openObraPickerModal(lista.id));
  const _ldPdfBtn = _ldScope.querySelector('#btnPdfLista');
  if(_ldPdfBtn) _ldPdfBtn.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); generateReportPDFForLista(lista.id); });
  const _ldSelectAll = _ldScope.querySelector('#btnSelectAllObras');
  if(_ldSelectAll) _ldSelectAll.addEventListener('click', () => {
    const allSelected = state.listaDetalheSelectedIds.size === entriesInLista.length;
    if(allSelected) state.listaDetalheSelectedIds = new Set();
    else state.listaDetalheSelectedIds = new Set(entriesInLista.map(e => e.id));
    // Optimistic: atualiza rows sem re-render
    entriesInLista.forEach(e => {
      const row = _ldScope.querySelector(`[data-obra-id="${e.id}"]`);
      if(!row) return;
      row.classList.toggle('is-selected', !allSelected);
      const cb = row.querySelector('.obra-row-checkbox');
      if(cb) cb.checked = !allSelected;
    });
    const cnt = _ldScope.querySelector('#selectionCountObras');
    if(cnt) cnt.textContent = state.listaDetalheSelectedIds.size + ' selecionada(s)';
    const removeBtn = _ldScope.querySelector('#btnRemoveSelectedObras');
    if(removeBtn) removeBtn.disabled = state.listaDetalheSelectedIds.size === 0;
  });
  const removeSelectedBtn = _ldScope.querySelector('#btnRemoveSelectedObras');
  if(removeSelectedBtn) removeSelectedBtn.addEventListener('click', () => {
    const ids = Array.from(state.listaDetalheSelectedIds);
    if(!ids.length) return;
    if(lista.defaultCat) openConfirmDeleteMultiple(ids);
    else openConfirmRemoveFromLista(lista.id, ids);
  });
  const _ldSearchEl = _ldScope.querySelector('#listaDetalheSearchInput');
  if(_ldSearchEl){
    _ldSearchEl.addEventListener('input', (ev) => {
      state.listaDetalheSearchTerm = ev.target.value;
      // Filtragem in-place: mostra/oculta linhas e grupos sem re-render (preserva foco/teclado)
      const term = normalizeText((state.listaDetalheSearchTerm||'').toLowerCase());
      const clearBtn = _ldScope.querySelector('.search-clear-btn[data-clear-target="listaDetalheSearchInput"]');
      if(clearBtn) clearBtn.hidden = !term;
      _ldScope.querySelectorAll('.obra-row').forEach(row => {
        const id = row.getAttribute('data-obra-id');
        const entry = entriesInLista.find(x => x.id === id);
        if(!entry){ row.style.display = ''; return; }
        const hay = normalizeText([entry.titulo, entry.titulo_original].filter(Boolean).join(' '));
        row.style.display = (!term || hay.includes(term)) ? '' : 'none';
      });
      // Oculta grupos vazios
      _ldScope.querySelectorAll('.subcategory-group, .category-group').forEach(g => {
        const visible = Array.from(g.querySelectorAll('.obra-row')).some(r => r.style.display !== 'none');
        g.style.display = visible ? '' : 'none';
      });
    });
  }
  const _cancelLdSel = _ldScope.querySelector('#btnCancelSelectionListaDetalhe');
  if(_cancelLdSel) _cancelLdSel.addEventListener('click', () => { state.selectionMode = false; state.listaDetalheSelectedIds = new Set(); renderMain(); });
  entriesInLista.forEach(e => {
    const row = _ldScope.querySelector(`[data-obra-id="${e.id}"]`);
    if(!row) return;
    const checkbox = row.querySelector('.obra-row-checkbox');
    if(checkbox) checkbox.addEventListener('click', (ev) => { ev.stopPropagation(); toggleListaDetalheObraSelected(e.id); });
    const cover = row.querySelector('.obra-row-cover');
    if(cover) cover.style.cursor = 'pointer';
    // Detalhe abre APENAS ao clicar na capa
    if(cover) cover.addEventListener('click', (ev) => {
      ev.stopPropagation();
      if(state.selectionMode){ toggleListaDetalheObraSelected(e.id); }
      else { openDetailModal(e.id); }
    });
    // Clique no restante da linha: só serve para seleção em modo de seleção
    row.addEventListener('click', (ev) => {
      if(ev.target.closest('.obra-row-actions') || ev.target.closest('.obra-row-checkbox') || ev.target.closest('.obra-row-cover')) return;
      if(state.selectionMode){ toggleListaDetalheObraSelected(e.id); }
    });
    const viewBtn = row.querySelector('[data-action="view-detail"]');
    if(viewBtn) viewBtn.addEventListener('click', (ev) => { ev.stopPropagation(); openFormModal(e.id); });
    const removeBtn = row.querySelector('[data-action="remove-from-lista"]');
    if(removeBtn) removeBtn.addEventListener('click', (ev) => { ev.stopPropagation(); if(lista.defaultCat) openConfirmDelete(e.id); else openConfirmRemoveFromLista(lista.id, [e.id]); });
  });
}
function toggleListaDetalheObraSelected(id){
  const wasSelected = state.listaDetalheSelectedIds.has(id);
  if(wasSelected) state.listaDetalheSelectedIds.delete(id); else state.listaDetalheSelectedIds.add(id);
  // Optimistic DOM update — apenas atualiza o row, sem re-render completo
  // Escopo: pageOverlayBody para não bater com IDs duplicados em #content (renderGrid)
  const scope = document.getElementById('pageOverlayBody') || document;
  const row = scope.querySelector(`[data-obra-id="${id}"]`);
  if(row){
    row.classList.toggle('is-selected', !wasSelected);
    const cb = row.querySelector('.obra-row-checkbox');
    if(cb) cb.checked = !wasSelected;
    // Atualiza contador e botão de apagar
    const cnt = scope.querySelector('#selectionCountObras');
    if(cnt) cnt.textContent = state.listaDetalheSelectedIds.size + ' selecionada(s)';
    const delBtn = scope.querySelector('#btnRemoveSelectedObras');
    if(delBtn) delBtn.disabled = state.listaDetalheSelectedIds.size === 0;
  } else {
    renderMain();
  }
}
function toggleObraSelected(id){
  const wasSelected = state.selectedIds.has(id);
  if(wasSelected) state.selectedIds.delete(id); else state.selectedIds.add(id);
  // Optimistic DOM update — apenas atualiza o card, sem re-render completo
  const card = document.querySelector(`[data-card-id="${id}"]`);
  if(card){
    const cb = card.querySelector('.obra-card-checkbox');
    if(cb) cb.checked = !wasSelected;
    card.classList.toggle('is-selected-card', !wasSelected);
    // Atualiza contador e botões de ação
    const cnt = document.getElementById('selectionCountObras');
    if(cnt) cnt.textContent = state.selectedIds.size + ' selecionada(s)';
    const delBtn = document.getElementById('btnDeleteSelectedObras');
    if(delBtn) delBtn.disabled = state.selectedIds.size === 0;
    const addBtn = document.getElementById('btnAddToListObras');
    if(addBtn) addBtn.disabled = state.selectedIds.size === 0;
  } else {
    renderMain();
  }
}

function renderActivitySnapshotDetail(snapshotView, entry, meta, content){
  const changes = Array.isArray(snapshotView.changes) ? snapshotView.changes.filter(isActivityVisibleChange) : [];
  const hasCoverChange = changes.some(change => String(change.label || '').toLocaleLowerCase('pt-BR').includes('imagem'));
  const coverSrc = entry.capa_base64 || entry.capa_url;
  const rows = changes.length
    ? changes.map(change => `<div class="activity-version-row">
        <div class="activity-version-field">${escapeHtml(change.label || 'Campo alterado')}</div>
        <div class="activity-version-old">${escapeHtml(change.before || 'Não informado')}</div>
        <div class="activity-version-new">${escapeHtml(change.after || 'Não informado')}</div>
      </div>`).join('')
    : `<div class="activity-version-empty">Não há campos alterados para apresentar nesta versão.</div>`;
  const html = `<section class="activity-version-page">
    <button class="btn btn-ghost activity-version-back" id="btnBackFromDetail"><svg class="icon"><use href="#i-arrow-left"/></svg> Voltar ao histórico</button>
    <header class="activity-version-hero">
      <div class="activity-version-kicker">VERSÃO ANTERIOR · SOMENTE LEITURA</div>
      <h1>${escapeHtml(entry.titulo || 'Obra')}</h1>
      <p>${escapeHtml(meta.label || 'Obra')} · ${escapeHtml(formatDateTime(snapshotView.timestamp) || '')}</p>
    </header>
    <section class="activity-version-card">
      <div class="activity-version-card-head"><div><span class="activity-version-eyebrow">ALTERAÇÕES DESTE EVENTO</span><h2>O que foi alterado</h2></div><span class="activity-version-count">${changes.length} ${changes.length === 1 ? 'campo' : 'campos'}</span></div>
      <div class="activity-version-columns"><span>Campo</span><span>Versão anterior</span><span>Versão atual</span></div>
      <div class="activity-version-list">${rows}</div>
    </section>
    ${hasCoverChange && coverSrc ? `<section class="activity-version-cover"><span class="activity-version-eyebrow">IMAGEM / CAPA NA VERSÃO ANTERIOR</span><img src="${escapeHtml(coverSrc)}" alt="Capa da versão anterior" decoding="async" referrerpolicy="no-referrer" onerror="window.__coverFallback(this)"></section>` : ''}
  </section>`;
  content.innerHTML = html;
  resetPageScroll();
  const back = content.querySelector('#btnBackFromDetail');
  if(back) back.addEventListener('click', () => {
    const ret = state.obraDetalheReturn || {view:'historico'};
    const scrollContext = ret.scrollContext || {container:'page-overlay', scrollY:ret.scrollY};
    state.obraDetalheId = null;
    state.obraDetalheReturn = null;
    state.activitySnapshot = null;
    state.view = ret.view || 'historico';
    if(scrollContext.container === 'page-overlay' && typeof scrollContext.scrollY === 'number'){
      _pendingPageOverlayScrollTarget = {view:state.view, scrollY:scrollContext.scrollY};
    }
    renderMain();
  });
}

function renderObraDetalhe(){
  const snapshotView = state.activitySnapshot;
  const e = snapshotView && snapshotView.entry
    ? snapshotView.entry
    : state.entries.find(x => x.id === state.obraDetalheId);
  if(!e){ state.view = 'lista'; renderMain(); return; }
  
  const meta = CATEGORY_META[e.categoria] || CATEGORY_META.filme;
  const content = document.getElementById('pageOverlayBody');
  if(snapshotView){
    renderActivitySnapshotDetail(snapshotView, e, meta, content);
    return;
  }
  
  let rows = [];
  rows.push(['Categoria', meta.plural]);
  const _detSubInfo = entrySubcategoryInfo(e);
  if(_detSubInfo && _detSubInfo.key !== 'sem-subcategoria') rows.push(['Subcategoria', meta.label + ' ' + _detSubInfo.short]);
  if(e.categoria !== 'filme') rows.push(['Status Pessoal', statusLabel(e.status)]);
  if(e.status_oficial) rows.push(['Status Oficial', officialStatusLabel(e.status_oficial)]);
  if(e.ano) rows.push(['Ano', e.ano]);
  if(e.data_inicio) rows.push(['Data de início', formatDateLongPt(e.data_inicio)]);
  if(e.data_fim) rows.push(['Data de conclusão', formatDateLongPt(e.data_fim)]);
  if(typeof e.nota === 'number') rows.push(['Classificação', e.nota.toFixed(1) + ' / 10']);
  if(Array.isArray(e.fontes) && e.fontes.length) rows.push(['Fontes', e.fontes.filter(x => typeof x === 'string' && x.trim()).join(', ')]);
  // Subcategoria já exibida acima com label formatado — ignora os campos duplicados
  const _skipDetailKeys = new Set(['subcategoria','tipo_novel']);
  (BONUS_FIELDS[e.categoria]||[]).forEach(f => { if(_skipDetailKeys.has(f.key)) return; if(e[f.key]) rows.push([f.label, e[f.key]]); });
  if((e.generos||[]).length) rows.push(['Gêneros', e.generos.join(', ')]);
  rows.push(['Favorito', e.favorito ? 'Sim' : 'Não']);
  if(e.criado_em) rows.push(['Adicionado em', formatDateTime(e.criado_em)]);
  if(e.ultima_edicao_obra) rows.push(['Última edição da obra', formatDateTime(e.ultima_edicao_obra)]);
  if(e.ultima_edicao_comentarios) rows.push(['Última edição dos comentários', formatDateTime(e.ultima_edicao_comentarios)]);

  const extraPill = (x) => {
    if(extraAceitaQuantidade(x) && (!x.nome || !x.nome.trim()) && x.quantidade){
      return `<span class="genre-pill">${escapeHtml(extraLabel(x))}</span>`;
    }
    return `<span class="genre-pill">${escapeHtml(x.tipo)}: ${escapeHtml(extraLabel(x))}</span>`;
  };
  let progressHtml = '';
  if(e.categoria === 'anime' && ((e.temporadas||[]).length || (e.extras_independentes||[]).length)){
    const tempHtml = (e.temporadas||[]).map(t => `
        <div class="detail-season-row"><span>Temporada ${t.numero}</span><span>${statusLabel(t.status)} · ${t.episodios} ep.</span></div>
        <div class="detail-progress-date">Episódios atualizados em ${escapeHtml(formatDateTime(t.episodios_editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</div>
        ${(t.extras||[]).length ? `<div class="detail-extras">${t.extras.map(extraPill).join('')}</div>` : ''}
      `).join('');
    const indep = e.extras_independentes||[];
    const indepHtml = indep.length ? `<div class="detail-season-row" style="margin-top:6px;"><span>OVAs / Filmes (sem temporada)</span><span></span></div><div class="detail-extras">${indep.map(extraPill).join('')}</div>` : '';
    progressHtml = `<div class="detail-progress-block"><h4>Temporadas</h4>${tempHtml}${indepHtml}</div>`;
  } else if(e.categoria === 'desenho' && ((e.temporadas||[]).length || (e.extras_independentes||[]).length)){
    const tempHtml = (e.temporadas||[]).map(t => `
        <div class="detail-season-row"><span>Temporada ${t.numero}</span><span>${statusLabel(t.status)} · ${t.episodios} ep.</span></div>
        <div class="detail-progress-date">Episódios atualizados em ${escapeHtml(formatDateTime(t.episodios_editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</div>
        ${(t.extras||[]).length ? `<div class="detail-extras">${t.extras.map(extraPill).join('')}</div>` : ''}
      `).join('');
    const indepDes = e.extras_independentes||[];
    const indepDesHtml = indepDes.length ? `<div class="detail-season-row" style="margin-top:6px;"><span>Extras / Filmes (sem temporada)</span><span></span></div><div class="detail-extras">${indepDes.map(extraPill).join('')}</div>` : '';
    progressHtml = `<div class="detail-progress-block"><h4>Temporadas</h4>${tempHtml}${indepDesHtml}</div>`;
  } else if(e.categoria === 'serie' && (e.temporadas||[]).length){
    const tempHtml = (e.temporadas||[]).map(t => `
        <div class="detail-season-row"><span>Temporada ${t.numero}</span><span>${statusLabel(t.status)} · ${t.episodios} ep.</span></div>
        <div class="detail-progress-date">Episódios atualizados em ${escapeHtml(formatDateTime(t.episodios_editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</div>
      `).join('');
    progressHtml = `<div class="detail-progress-block"><h4>Temporadas</h4>${tempHtml}</div>`;
  } else if(e.categoria === 'novel' && (e.volumes||[]).length){
    const volRows = e.volumes.map(v => {
      const lista = v.capitulos_lista||[];
      const numericCaps = lista.length ? capitulostotalNumericOnly(lista, 0) : (Math.floor(Number(v.capitulos)||0));
      const namedCaps = lista.filter(c => c.nome && c.nome.trim()).map(c => c.nome.trim());
      const lastEntry = lista.length > 0 ? lista[lista.length-1] : null;
      const lastIsNamed = lastEntry && lastEntry.nome && lastEntry.nome.trim() ? lastEntry.nome.trim() : null;
      const nomesHtml = namedCaps.map(n => escapeHtml(n)).join(' · ');
      let capsDisplay;
      // Mesma regra do card: abreviatura do nomeado só aparece quando o
      // ÚLTIMO registo é escrito; a página anexa-se ao campo dono dela.
      const lastPageStr = lastEntry && lastEntry.pagina ? ' · Pág. ' + lastEntry.pagina : '';
      const chapterDatesHtml = lista.map((chapter, chapterIndex) => {
        const chapterLabel = chapter.nome && chapter.nome.trim()
          ? chapter.nome.trim()
          : Number(chapter.quantidade) > 0
            ? `${chapter.quantidade} capítulos`
            : `Capítulo ${chapterIndex + 1}`;
        const pageLabel = Number(chapter.pagina) > 0 ? ` · pág. ${chapter.pagina}` : '';
        const editedAt = chapter.editado_em || v.capitulos_editado_em || v.editado_em || e.atualizado_em || e.criado_em;
        return `<div class="detail-vol-chapter"><span>${escapeHtml(chapterLabel + pageLabel)}</span><time>Atualizado em ${escapeHtml(formatDateTime(editedAt) || 'Data não registrada')}</time></div>`;
      }).join('');
      if(lista.length){
        if(lastIsNamed){
          const capPart = numericCaps > 0 ? (numericCaps + ' cap.') : '';
          const abbr = abbrevChapterName(lastIsNamed);
          capsDisplay = capPart ? (capPart + ' · ' + abbr + lastPageStr) : (abbr + lastPageStr);
        } else if(numericCaps > 0){
          capsDisplay = numericCaps + ' cap.' + lastPageStr;
        } else {
          capsDisplay = '0 cap.';
        }
      } else {
        capsDisplay = numericCaps + ' cap.';
      }
      return `<div class="detail-season-row">
        <span>${escapeHtml(v.nome && v.nome.trim() ? v.nome.trim() : 'Volume ' + v.numero)}</span>
        <span>${statusLabel(v.status)}${capsDisplay ? ' · ' + capsDisplay : ''}</span>
        ${nomesHtml ? `<span class="detail-vol-caps">${nomesHtml}</span>` : ''}
        <span class="detail-progress-date">Volume atualizado em ${escapeHtml(formatDateTime(v.editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</span>
        <span class="detail-progress-date">Capítulos atualizados em ${escapeHtml(formatDateTime(v.capitulos_editado_em || v.editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</span>
        ${chapterDatesHtml}
      </div>`;
    }).join('');
    progressHtml = `<div class="detail-progress-block"><h4>Volumes</h4>${volRows}</div>`;
  } else if(['manga','manhua','manhwa'].includes(e.categoria) && e.progresso_simples != null){
    let capLabel;
    if(e.status === 'concluido') capLabel = 'Total de capítulos';
    else if(e.status === 'pretendo_ver') capLabel = 'Último capítulo visto';
    else capLabel = 'Capítulo atual';
    progressHtml = `<div class="detail-row"><span>${capLabel}</span><span>${e.progresso_simples}</span></div><div class="detail-progress-date">Progresso atualizado em ${escapeHtml(formatDateTime(e.progresso_simples_editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</div>`;
  } else if(e.categoria === 'livro' && (e.progresso_simples != null || e.paginas_total)){
    let pageLabel;
    if(e.status === 'concluido') pageLabel = 'Total de páginas lidas';
    else if(e.status === 'pretendo_ver') pageLabel = 'Última página vista';
    else pageLabel = 'Página atual';
    const val = e.paginas_total ? ((e.progresso_simples||0) + ' / ' + e.paginas_total) : String(e.progresso_simples||0);
    progressHtml = `<div class="detail-row"><span>${pageLabel}</span><span>${escapeHtml(val)}</span></div><div class="detail-progress-date">Progresso atualizado em ${escapeHtml(formatDateTime(e.progresso_simples_editado_em || e.atualizado_em || e.criado_em) || 'Data não registrada')}</div>`;
  }

  const coverSrc = e.capa_base64 || e.capa_url;
  const snapshotBanner = snapshotView ? `
      <div class="activity-snapshot-banner">
        <strong>Versão anterior à alteração</strong>
        <span>${escapeHtml(formatDateTime(snapshotView.timestamp) || '')} · somente leitura</span>
      </div>
      ${activitySnapshotComparisonHtml(snapshotView.changes)}
    ` : '';
  const detalhesHtml = `
    <div style="max-width:1000px; margin:0 auto;">
      <button class="btn btn-ghost" id="btnBackFromDetail" style="margin-bottom:20px;"><svg class="icon"><use href="#i-arrow-left"/></svg> Voltar</button>
      ${snapshotBanner}
      <div class="obra-detail-grid">
        <div class="obra-detail-cover">
          ${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" decoding="async" referrerpolicy="no-referrer" onerror="window.__coverFallback(this)">` : `<svg class="icon" style="width:80px; height:80px;"><use href="#${meta.icon}"/></svg>`}
        </div>
        <div>
          <h1 class="obra-detail-title">${escapeHtml(e.titulo)}</h1>
          ${e.titulo_original ? `<p class="obra-detail-subtitle">${escapeHtml(e.titulo_original)}</p>` : ''}
          <div class="obra-detail-highlights">
            <span class="obra-detail-rating ${typeof e.nota === 'number' ? '' : 'is-empty'}" title="Classificação">
              <svg class="icon" aria-hidden="true"><use href="#i-star"/></svg>
              ${typeof e.nota === 'number' ? e.nota.toFixed(1).replace('.0','') + ' / 10' : 'Sem classificação'}
            </span>
            <span class="obra-detail-fav ${e.favorito ? 'is-fav' : ''}" title="Favorito">
              <svg class="icon" aria-hidden="true"><use href="#i-heart"/></svg>
              ${e.favorito ? 'Favorito' : 'Não favorito'}
            </span>
          </div>
          <div class="obra-detail-info">
            ${rows.map(([k,v]) => `<div class="detail-row"><span>${escapeHtml(k)}</span><span>${escapeHtml(v)}</span></div>`).join('')}
          </div>
          ${progressHtml}
          ${e.comentario ? `<div class="obra-detail-info"><h3 style="margin-top:0; margin-bottom:12px;">Comentários</h3><p style="margin:0; white-space:pre-wrap; font-size:0.9rem;">${escapeHtml(e.comentario)}</p></div>` : ''}
          ${snapshotView ? '' : `<div class="obra-detail-actions">
            <button class="btn btn-primary" id="detailEditBtnPage"><svg class="icon"><use href="#i-edit"/></svg> Editar</button>
            <button class="btn btn-ghost" id="detailAddToListBtnPage"><svg class="icon"><use href="#i-list"/></svg> Adicionar a lista</button>
            <button class="btn btn-danger" id="detailDeleteBtnPage"><svg class="icon"><use href="#i-trash"/></svg> Remover</button>
          </div>`}
        </div>
      </div>
    </div>
  `;
  
  content.innerHTML = detalhesHtml;
  resetPageScroll();
  
  const restoreFromDetail = () => {
    const ret = state.obraDetalheReturn || { view: 'lista' };
    const scrollContext = ret.scrollContext || { container:'main', scrollY:ret.scrollY };
    state.obraDetalheId = null;
    state.obraDetalheReturn = null;
    state.activitySnapshot = null;
    state.view = ret.view || 'lista';
    if(ret.categoriaAtiva) state.categoriaAtiva = ret.categoriaAtiva;
    if(ret.filmeSubAtivo) state.filmeSubAtivo = ret.filmeSubAtivo;
    if(ret.novelSubAtivo) state.novelSubAtivo = ret.novelSubAtivo;
    if(ret.listaAtivaId) state.listaAtivaId = ret.listaAtivaId;
    if(scrollContext.container === 'main' && state.view === 'lista' && typeof scrollContext.scrollY === 'number'){
      // Arma o alvo ANTES de renderizar: renderGrid() vai montar os cards
      // necessários de forma síncrona para já nascer na posição certa, em
      // vez de aparecer do topo e só depois pular para o lugar certo.
      _pendingGridScrollTarget = { y: scrollContext.scrollY };
    } else if(scrollContext.container === 'page-overlay' && typeof scrollContext.scrollY === 'number'){
      _pendingPageOverlayScrollTarget = { view:state.view, scrollY:scrollContext.scrollY };
    } else if(scrollContext.container === 'list-page' && typeof scrollContext.scrollY === 'number'){
      _pendingListPageScrollTarget = { scrollY:scrollContext.scrollY };
    }
    renderMain();
    if(ret.listPageOpen && typeof openListPage === 'function') openListPage();
    if(scrollContext.container !== 'main') return;
    // Restaura de forma imediata e exata: aplica a posição salva já no
    // primeiro frame (sem esperar tempo fixo) e continua corrigindo apenas
    // enquanto a grade ainda estiver crescendo (renderização em blocos /
    // capas carregando), recentralizando o card exato de onde o usuário
    // saiu assim que ele existir no DOM.
    restoreScrollUntilStable(() => {
      // 1) Aplica primeiro a posição bruta salva (rápido, sempre correto
      //    quando o card alvo já está visível nela).
      if(typeof ret.scrollY === 'number') setScrollerPos(ret.scrollY);
      // 2) Em seguida, se o card exato de onde saímos existir no DOM mas não
      //    estiver visível (ex.: pequenas variações de altura por imagens
      //    carregando), recentraliza nele — mecanismo mais preciso que o
      //    scrollY bruto.
      let cardFocused = true;
      if(ret.fromCardId){
        const card = document.querySelector(`[data-card-id="${ret.fromCardId}"]`);
        if(card){
          const r = card.getBoundingClientRect();
          const safeTop = getGridFixedHeaderBottom();
          if(r.top < safeTop || r.bottom > window.innerHeight){
            // Em vez de recentralizar (scrollIntoView({block:'center'}) jogava
            // o card para o meio da tela, afastando-o de onde ele realmente
            // estava), ajusta o scroll só o suficiente para tirar o card de
            // baixo da barra fixa (topo) ou do fundo da tela — mantendo-o o
            // mais próximo possível da posição exata de onde o usuário saiu.
            const { el, useWindow } = getMainScroller();
            const current = useWindow ? (window.pageYOffset || (el ? el.scrollTop : 0) || 0) : (el ? el.scrollTop : 0);
            let delta = 0;
            if(r.top < safeTop) delta = (r.top - safeTop) - 8;
            else if(r.bottom > window.innerHeight) delta = (r.bottom - window.innerHeight) + 8;
            if(delta){
              const next = current + delta;
              if(useWindow){ window.scrollTo(0, next); if(el) el.scrollTop = next; }
              else if(el){ el.scrollTop = next; }
            }
          }
        } else {
          cardFocused = false; // card ainda não renderizado — segue tentando
        }
      }
      const height = getScrollerHeight();
      return { height, landed: cardFocused };
    });
  };
  document.getElementById('btnBackFromDetail').addEventListener('click', restoreFromDetail);
  if(!snapshotView){
    document.getElementById('detailEditBtnPage').addEventListener('click', () => { openFormModal(e.id); });
    document.getElementById('detailDeleteBtnPage').addEventListener('click', () => { const id = e.id; restoreFromDetail(); openConfirmDelete(id); });
    document.getElementById('detailAddToListBtnPage').addEventListener('click', () => { openListSelectorForObra(e.id); });
  }
}


function openListaFormModal(id){
  editingListId = id;
  const lista = id ? getListaById(id) : null;
  document.getElementById('listaFormTitle').textContent = lista ? 'Editar lista' : 'Nova lista personalizada';
  document.getElementById('f_lista_nome').value = lista ? lista.nome : '';
  const categoriaSelect = document.getElementById('f_lista_categoria');
  categoriaSelect.value = lista ? (lista.categoria || '') : '';
  categoriaSelect.disabled = !!lista;
  categoriaSelect.title = lista ? 'A categoria não pode ser alterada depois da criação da lista.' : '';
  document.getElementById('err_lista_nome').textContent = '';
  document.getElementById('err_lista_categoria').textContent = '';
  document.getElementById('listaFormSubmitBtn').textContent = lista ? 'Salvar alterações' : 'Criar lista';
  document.getElementById('listaFormModalBackdrop').hidden = false;
  const nomeInput = document.getElementById('f_lista_nome');
  nomeInput.focus({preventScroll:true});
  try{
    const cursorPosition = nomeInput.value.length;
    nomeInput.setSelectionRange(cursorPosition, cursorPosition);
  }catch(_){}
}
function closeListaFormModal(){ document.getElementById('listaFormModalBackdrop').hidden = true; editingListId = null; }
function handleListaFormSubmit(e){
  e.preventDefault();
  const nome = document.getElementById('f_lista_nome').value.trim();
  const categoria = document.getElementById('f_lista_categoria').value;
  if(!nome){ document.getElementById('err_lista_nome').textContent = 'Dê um nome para a lista.'; return; }
  if(nome.length > 80){ document.getElementById('err_lista_nome').textContent = 'Nome muito longo (máx. 80 caracteres).'; return; }
  if(!categoria){ document.getElementById('err_lista_categoria').textContent = 'Selecione uma categoria.'; return; }
  if(editingListId){
    const lista = getListaById(editingListId);
    if(lista){
      lista.nome = nome; lista.categoria = categoria;
      recordActivity('list', 'lista', lista.nome, 'Lista atualizada.', {targetId: lista.id});
    }
    showToast('success', 'Lista atualizada.');
  } else {
    const novaLista = {id: uuid(), nome, categoria, obraIds: [], criado_em: Date.now()};
    state.listas.push(novaLista);
    recordActivity('list', 'lista', novaLista.nome, 'Lista criada.', {targetId: novaLista.id});
    showToast('success', 'Lista criada.');
  }
  persistListas(); closeListaFormModal(); renderMain();
}
function openConfirmDeleteListas(ids){
  if(!ids.length) return;
  const defaults = ids.filter(id => { const l = getListaById(id); return l && l.defaultCat; });
  const deletableIds = ids.filter(id => !defaults.includes(id));
  if(defaults.length){
    showToast('warning', 'Listas padrão por categoria não podem ser apagadas.' + (deletableIds.length ? ' As demais selecionadas podem.' : ''));
  }
  if(!deletableIds.length) return;
  pendingDeleteListId = deletableIds.slice();
  const multi = pendingDeleteListId.length > 1;
  document.getElementById('confirmModalTitle').textContent = multi ? 'Remover listas' : 'Remover lista';
  document.getElementById('confirmModalText').innerHTML = multi
    ? `Remover <strong>${pendingDeleteListId.length} listas</strong> selecionadas? As obras continuam no seu acervo. Esta ação não pode ser desfeita.`
    : `Remover a lista <strong>${escapeHtml((getListaById(pendingDeleteListId[0])||{}).nome||'')}</strong>? As obras continuam no seu acervo. Esta ação não pode ser desfeita.`;
  document.getElementById('confirmModalOk').textContent = 'Remover';
  document.getElementById('confirmModalOk').onclick = () => {
    const idsToDelete = Array.isArray(pendingDeleteListId) ? pendingDeleteListId.slice() : [];
    const listasRemovidas = state.listas.filter(l => idsToDelete.includes(l.id));
    state.listas = state.listas.filter(l => !idsToDelete.includes(l.id));
    if(state.listaAtivaId && idsToDelete.includes(state.listaAtivaId)){
      state.listaAtivaId = null;
      state.view = 'listas';
    }
    state.selectedIds = new Set([...state.selectedIds].filter(id => !idsToDelete.includes(id)));
    listasRemovidas.forEach(lista => recordActivity('deleted', 'lista', lista.nome, 'Lista removida; as obras permaneceram no acervo.', {targetId: lista.id}));
    persistListas();
    closeConfirmModal();
    exitSelectionMode();
    renderMain();
    showToast('success', multi ? 'Listas removidas.' : 'Lista removida.');
    pendingDeleteListId = null;
  };
  document.getElementById('confirmModalBackdrop').hidden = false;
}
function openConfirmRemoveFromLista(listaId, obraIds){
  const lista = getListaById(listaId);
  if(!lista) return;
  const multi = obraIds.length > 1;
  document.getElementById('confirmModalTitle').textContent = 'Remover da lista';
  document.getElementById('confirmModalText').innerHTML = multi
    ? `Remover <strong>${obraIds.length} obras</strong> selecionadas da lista <strong>${escapeHtml(lista.nome)}</strong>? As obras continuam no seu acervo.`
    : `Remover esta obra da lista <strong>${escapeHtml(lista.nome)}</strong>? Ela continua no seu acervo.`;
  document.getElementById('confirmModalOk').textContent = 'Remover';
  document.getElementById('confirmModalOk').onclick = () => {
    lista.obraIds = lista.obraIds.filter(oid => !obraIds.includes(oid));
    cleanupEmptyCustomLists();
    recordActivity('list', 'lista', lista.nome, `${obraIds.length} obra(s) removida(s) da lista.`, {targetId: lista.id});
    persistListas(); closeConfirmModal(); exitSelectionMode(); renderMain();
    showToast('success', multi ? 'Obras removidas da lista.' : 'Obra removida da lista.');
  };
  document.getElementById('confirmModalBackdrop').hidden = false;
}

/* ===================== SELETOR DE OBRAS PARA LISTA ===================== */
function openObraPickerModal(listaId){
  const lista = getListaById(listaId);
  if(!lista) return;
  pickerTargetListaId = listaId;
  state.pickerSelectedIds = new Set(lista.obraIds);
  state.pickerBusca = '';
  document.getElementById('pickerListaNome').textContent = lista.nome;
  document.getElementById('pickerSearchInput').value = '';
  updateSearchClearButtons(document);
  renderObraPickerList(listaId);
  document.getElementById('obraPickerModalBackdrop').hidden = false;
}
function renderObraPickerList(listaId){
  const lista = getListaById(listaId);
  const container = document.getElementById('pickerList');
  const term = normalizeText(state.pickerBusca);
  
  const obrasExistentes = getEntriesOfLista(lista);
  const categoriasExistentes = new Set(obrasExistentes.map(o => o.categoria));
  
  // Se lista é específica de categoria, filtra por essa categoria
  // Se lista é "mista" (todos), permite qualquer categoria
  // Se lista não tem categoria definida mas tem obras, usa categoria das obras
  const isMista = lista.categoria === 'todos';
  let categoriaFiltro = null;
  if(lista.categoria && lista.categoria !== 'todos'){
    categoriaFiltro = lista.categoria;
  } else if(categoriasExistentes.size > 0 && !isMista){
    categoriaFiltro = Array.from(categoriasExistentes)[0];
  }
  
  let items = state.entries.filter(e => {
    if(categoriaFiltro && e.categoria !== categoriaFiltro) return false;
    if(!term) return true;
    const haystack = normalizeText([e.titulo, e.titulo_original].filter(Boolean).join(' '));
    return haystack.includes(term);
  });
  if(!items.length){ container.innerHTML = '<p class="field-hint">Nenhuma obra encontrada' + (categoriaFiltro ? ' nesta categoria' : '') + '.</p>'; return; }
  container.innerHTML = items.map(e => {
    const meta = CATEGORY_META[e.categoria];
    const coverSrc = e.capa_base64 || e.capa_url;
    const checked = state.pickerSelectedIds.has(e.id);
    return `<label class="picker-row" data-picker-id="${e.id}">
      <input type="checkbox" ${checked?'checked':''}>
      <div class="picker-row-cover">${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="window.__coverFallback(this)">` : ''}</div>
      <span class="picker-row-title">${escapeHtml(e.titulo)}</span>
      <span class="picker-row-cat">${meta.label}</span>
    </label>`;
  }).join('');
  container.querySelectorAll('.picker-row').forEach(row => {
    const id = row.dataset.pickerId;
    const checkbox = row.querySelector('input');
    checkbox.addEventListener('change', () => {
      if(checkbox.checked) state.pickerSelectedIds.add(id); else state.pickerSelectedIds.delete(id);
      updatePickerCount();
    });
  });
  updatePickerCount();
}
function updatePickerCount(){
  const el = document.getElementById('pickerSelectedCount');
  if(el) el.textContent = state.pickerSelectedIds.size + ' selecionada(s)';
}
function closeObraPickerModal(){ document.getElementById('obraPickerModalBackdrop').hidden = true; }
function saveObraPickerSelection(listaId){
  const lista = getListaById(listaId);
  if(!lista) return;
  
  const novasObras = Array.from(state.pickerSelectedIds);
  
  // Validação 1: cada obra selecionada precisa ser aceite pela lista (categoria igual em todos os casos)
  const obraInvalida = novasObras.map(id => state.entries.find(e => e.id === id)).find(o => o && !listaAceitaCategoria(lista, o.categoria));
  if(obraInvalida){
    const catLabel = lista.categoria && lista.categoria !== 'todos' ? CATEGORY_META[lista.categoria].plural.toLowerCase() : (CATEGORY_META[obraInvalida.categoria] ? CATEGORY_META[obraInvalida.categoria].plural.toLowerCase() : 'outra categoria');
    showToast('error', 'Essa lista é apenas de ' + catLabel + '. Adicione apenas obras dessa categoria.');
    return;
  }
  // Substitui atomicamente o conjunto pelo que o utilizador confirmou no picker.
  // (O picker inicializa selectedIds com as obras já pertencentes à lista, portanto
  // esta operação preserva as existentes e adiciona as novas de uma só vez.)
  const previousCount = Array.isArray(lista.obraIds) ? lista.obraIds.length : 0;
  lista.obraIds = Array.from(new Set(novasObras));
  if(previousCount !== lista.obraIds.length){
    recordActivity('list', 'lista', lista.nome, `Lista atualizada: ${lista.obraIds.length} obra(s) vinculada(s).`, {targetId: lista.id});
  }
  persistListas(); closeObraPickerModal(); renderMain();
  showToast('success', 'Lista atualizada.');
}

/* ===================== ADICIONAR OBRA A LISTAS (a partir do detalhe) ===================== */
let listSelectorObraId = null;
function openListSelectorForObra(obraId){
  listSelectorObraId = obraId;
  const obra = state.entries.find(e => e.id === obraId);
  if(!obra) return;
  
  const listEl = document.getElementById('listSelectorList');
  const emptyHint = document.getElementById('listSelectorEmptyHint');
  const listasDisponiveis = state.listas
    .filter(l => !l.defaultCat)
    .slice()
    .sort((a, b) => String(a.nome || '').localeCompare(String(b.nome || ''), 'pt-BR', { numeric:true, sensitivity:'base' }));
  if(listasDisponiveis.length === 0){
    listEl.innerHTML = ''; emptyHint.hidden = false;
  } else {
    emptyHint.hidden = true;
    listEl.innerHTML = listasDisponiveis.map(l => {
      const validCount = getEntriesOfLista(l).length;
      const podeAdicionar = listaAceitaCategoria(l, obra.categoria);
      const aviso = !podeAdicionar ? ` (${listaCategoriaLabel(l.categoria)})` : '';
      return `<label class="picker-row" data-lista-id="${l.id}" style="opacity:${podeAdicionar?'1':'0.5'}; pointer-events:${podeAdicionar?'auto':'none'};">
      <input type="checkbox" ${l.obraIds.includes(obraId)?'checked':''} ${podeAdicionar?'':'disabled'}>
      <span class="picker-row-title">${escapeHtml(l.nome)}</span>
      <span class="picker-row-cat">${validCount} obra${validCount===1?'':'s'}${escapeHtml(aviso)}</span>
    </label>`;
    }).join('');
  }
  document.getElementById('listSelectorModalBackdrop').hidden = false;
}
function saveListSelectorForObra(){
  if(!listSelectorObraId) return;
  const obra = state.entries.find(e => e.id === listSelectorObraId);
  if(!obra) return;
  
  const rows = document.querySelectorAll('#listSelectorList .picker-row');
  rows.forEach(row => {
    const lista = getListaById(row.dataset.listaId);
    if(!lista) return;
    const checked = row.querySelector('input').checked;
    const has = lista.obraIds.includes(listSelectorObraId);
    
    if(checked && !has){
      if(!listaAceitaCategoria(lista, obra.categoria)){
        showToast('error', 'Não é possível adicionar obras de categorias diferentes na mesma lista.');
        row.querySelector('input').checked = false;
        return;
      }
      lista.obraIds.push(listSelectorObraId);
    }
    else if(!checked && has) lista.obraIds = lista.obraIds.filter(id => id !== listSelectorObraId);
  });
  recordActivity('list', 'lista', 'Listas personalizadas', `Vínculos da obra "${obra.titulo}" atualizados.`, {targetId: listSelectorObraId});
  persistListas(); closeListSelectorModal();
  showToast('success', 'Listas atualizadas.');
  if(state.view === 'lista-detalhe') renderMain();
}

function defaultBuilder(){
  return { temporadas:[{status:'pretendo_ver', episodios:0, extras:[], aberta:true}], volumes:[{status:'pretendo_ver', nome:'Volume 1', capitulos:0, capitulos_lista:[], aberta:false}], progresso_simples:0, extras_independentes:[] };
}
function ensureDefaultSeason(){ if(state.builder.temporadas.length===0) state.builder.temporadas.push({status:'pretendo_ver', episodios:0, extras:[], aberta:true}); }
function ensureDefaultVolume(){ if(state.builder.volumes.length===0) state.builder.volumes.push({status:'pretendo_ver', nome:'Volume 1', capitulos:0, capitulos_lista:[], aberta:false}); }

// Ordena extras: OVA/Extra primeiro, Filme por último (dentro do mesmo tipo mantém inserção)
function sortExtras(arr){ return arr.slice().sort((a,b) => (a.tipo==='Filme'?1:0) - (b.tipo==='Filme'?1:0)); }

function seasonCardHtml(s, idx, total, categoria){
  const isConcluido = s.status === 'concluido';
  const episLabel = isConcluido ? 'Total de episódios *' : 'Último episódio visto *';
  const aberta = s.aberta === true;
  const hasExtras = (categoria === 'anime' || categoria === 'desenho' || categoria == null);
  const sortedExtras = sortExtras(s.extras||[]);
  // Sincroniza o array de estado com a ordem visual (OVA/Extra primeiro, Filme depois)
  if(s.extras) s.extras.splice(0, s.extras.length, ...sortedExtras);
  const extrasBlock = hasExtras ? `
      <div class="extras-list">${sortedExtras.map((ex,exi)=>extraRowHtml(ex, idx, exi)).join('')}</div>
      <div class="extras-actions">
        ${(categoria === 'anime') ? `<button type="button" class="btn btn-ghost btn-sm" data-add-extra="OVA" data-season-idx="${idx}">+ OVA</button>` : `<button type="button" class="btn btn-ghost btn-sm" data-add-extra="Extra" data-season-idx="${idx}">+ Extra</button>`}
        <button type="button" class="btn btn-ghost btn-sm" data-add-extra="Filme" data-season-idx="${idx}">+ Filme especial</button>
      </div>` : '';

  return `<div class="season-card">
    <div class="season-header" data-toggle-season="${idx}">
      <span class="season-title">Temporada ${idx+1}</span>
      <div class="season-header-right">
        <span class="season-summary">${statusLabel(s.status)} · ${s.episodios||0} ep.</span>
        ${total>1 ? `<button type="button" class="icon-btn danger" data-remove-season="${idx}" aria-label="Remover temporada"><svg class="icon"><use href="#i-trash"/></svg></button>` : ''}
      </div>
    </div>
    <div class="season-body${aberta ? '' : ' is-collapsed'}">
      <div class="form-grid">
        <label class="field"><span>Status desta temporada *</span><select data-season-field="status" data-season-idx="${idx}">${statusOptionsHtml(s.status)}</select></label>
        <label class="field"><span data-episodios-label>${episLabel}</span><input type="number" min="0" value="${s.episodios ?? 0}" data-season-field="episodios" data-season-idx="${idx}"></label>
      </div>` + extrasBlock + `
    </div>
  </div>`;
}
function extraRowHtml(ex, seasonIdx, exIdx){
  const isOva = ex.tipo === 'OVA';
  const isExtra = ex.tipo === 'Extra';
  const hasNome = !!(ex.nome && ex.nome.trim());
  const hasQtd  = (ex.quantidade != null && ex.quantidade > 0);
  const nameDisabled = (hasQtd && !hasNome) ? ' disabled' : '';
  const qtdDisabled  = hasNome ? ' disabled' : '';
  const qtdField = extraAceitaQuantidade(ex) ? `<input type="number" min="1" class="extra-qtd" value="${hasQtd&&!hasNome?ex.quantidade:''}" placeholder="Qtd" title="Quantidade sem nome" data-extra-qtd data-season-idx="${seasonIdx}" data-extra-idx="${exIdx}"${qtdDisabled}>` : '';
  const placeholder = isOva ? 'Nome da OVA (opcional)...' : isExtra ? 'Nome do extra (opcional)...' : 'Nome do filme (opcional)...';
  return `<div class="extra-row">
    <span class="extra-tag">${escapeHtml(ex.tipo)}</span>
    <input type="text" value="${escapeHtml(ex.nome||'')}" placeholder="${placeholder}" data-extra-name data-season-idx="${seasonIdx}" data-extra-idx="${exIdx}"${nameDisabled}>
    ${qtdField}
    <button type="button" class="icon-btn danger" data-remove-extra data-season-idx="${seasonIdx}" data-extra-idx="${exIdx}" aria-label="Remover"><svg class="icon"><use href="#i-close"/></svg></button>
  </div>`;
}
function indepExtraRowHtml(ex, exIdx){
  const isOva = ex.tipo === 'OVA';
  const isExtra = ex.tipo === 'Extra';
  const hasNome = !!(ex.nome && ex.nome.trim());
  const hasQtd  = (ex.quantidade != null && ex.quantidade > 0);
  const nameDisabled = (hasQtd && !hasNome) ? ' disabled' : '';
  const qtdDisabled  = hasNome ? ' disabled' : '';
  const qtdField = extraAceitaQuantidade(ex) ? `<input type="number" min="1" class="extra-qtd" value="${hasQtd&&!hasNome?ex.quantidade:''}" placeholder="Qtd" title="Quantidade sem nome" data-indep-qtd data-indep-idx="${exIdx}"${qtdDisabled}>` : '';
  const placeholder = isOva ? 'Nome da OVA (opcional)...' : isExtra ? 'Nome do extra (opcional)...' : 'Nome do filme (opcional)...';
  return `<div class="extra-row">
    <span class="extra-tag">${escapeHtml(ex.tipo)}</span>
    <input type="text" value="${escapeHtml(ex.nome||'')}" placeholder="${placeholder}" data-indep-name data-indep-idx="${exIdx}"${nameDisabled}>
    ${qtdField}
    <button type="button" class="icon-btn danger" data-remove-indep data-indep-idx="${exIdx}" aria-label="Remover"><svg class="icon"><use href="#i-close"/></svg></button>
  </div>`;
}
function capitulostotalFromLista(lista, fallback){
  if(!lista || !lista.length) return fallback || 0;
  return lista.reduce((s, c) => s + (Number(c.quantidade) > 0 ? Math.floor(Number(c.quantidade)) : 1), 0);
}
// Conta apenas capítulos numerados (ignora nomeados como Prólogo/Epílogo)
function capitulostotalNumericOnly(lista, fallback){
  if(!lista || !lista.length) return fallback || 0;
  const n = lista.filter(c => !(c.nome && c.nome.trim()) && Number(c.quantidade) > 0).reduce((s, c) => s + Math.floor(Number(c.quantidade)), 0);
  return n || fallback || 0;
}
// Retorna o próximo número de volume sem pular (ex: após Vol 2.5 → 3)
function nextVolumeNumber(){
  const vols = state.builder.volumes;
  if(!vols.length) return 1;
  const last = vols[vols.length-1];
  if(last.nome && last.nome.trim()){
    const m = last.nome.trim().match(/(\d+(?:[.,]\d+)?)\s*$/);
    if(m){ const n = parseFloat(m[1].replace(',','.')); return Number.isInteger(n) ? n+1 : Math.ceil(n); }
  }
  return vols.length + 1;
}
function capituloRowHtml(c, volIdx, capIdx){
  const hasNome = !!(c.nome && c.nome.trim());
  const hasQtd  = (c.quantidade != null && c.quantidade > 0);
  const nameDisabled = (hasQtd && !hasNome) ? ' disabled' : '';
  const qtdDisabled  = hasNome ? ' disabled' : '';
  return `<div class="extra-row">
    <span class="extra-tag">Cap.</span>
    <input type="text" value="${escapeHtml(c.nome||'')}" placeholder="Título do capítulo (opcional)..." data-cap-name data-vol-idx="${volIdx}" data-cap-idx="${capIdx}"${nameDisabled}>
    <input type="number" min="0" class="extra-qtd" value="${hasQtd&&!hasNome?c.quantidade:''}" placeholder="Qtd" title="Nº de capítulos sem título" data-cap-qtd data-vol-idx="${volIdx}" data-cap-idx="${capIdx}"${qtdDisabled}>
    <button type="button" class="icon-btn danger" data-remove-cap data-vol-idx="${volIdx}" data-cap-idx="${capIdx}" aria-label="Remover"><svg class="icon"><use href="#i-close"/></svg></button>
    <div class="cap-pagina-wrap">
      <span class="cap-pagina-label">Parei na pág.:</span>
      <input type="number" min="1" value="${c.pagina||''}" placeholder="—" title="Página onde parei neste capítulo (opcional)" data-cap-pagina data-vol-idx="${volIdx}" data-cap-idx="${capIdx}">
    </div>
  </div>`;
}
function _volumeSummaryText(lista, fallbackCapitulos){
  const nc = capitulostotalNumericOnly(lista, fallbackCapitulos);
  return (nc||0) + ' cap.';
}
function _volumeSummaryFull(v){
  const lista = v.capitulos_lista || [];
  const txt = _volumeSummaryText(lista, v.capitulos);
  let maxPag = 0;
  lista.forEach(c => { if(c.pagina && Number(c.pagina) > 0 && Number(c.pagina) > maxPag) maxPag = Math.floor(Number(c.pagina)); });
  return txt + (maxPag > 0 ? ' · Pág. ' + maxPag : '');
}
function volumeCardHtml(v, idx, total){
  const lista = v.capitulos_lista || [];
  const summaryText = _volumeSummaryFull(v);
  const nomeLabel = (v.nome && v.nome.trim()) ? escapeHtml(v.nome.trim()) : `Volume ${idx+1}`;
  return `<div class="season-card">
    <div class="season-header" data-toggle-volume="${idx}">
      <span class="season-title">${nomeLabel}</span>
      <div class="season-header-right">
        <span class="season-summary">${statusLabel(v.status)} · ${summaryText}</span>
        <button type="button" class="icon-btn danger" data-remove-volume="${idx}" aria-label="Remover volume"><svg class="icon"><use href="#i-trash"/></svg></button>
      </div>
    </div>
    <div class="season-body${v.aberta ? '' : ' is-collapsed'}">
      <div class="form-grid">
        <label class="field full"><span>Nome / rótulo do volume <span style="font-weight:400;font-style:italic;">(opcional — ex: Volume 8.5, Especial, Prólogo…)</span></span>
          <div class="clearable-field-wrap">
            <input type="text" placeholder="Deixe em branco para usar &quot;Volume ${idx+1}&quot;" maxlength="120" autocomplete="off" autocorrect="off" spellcheck="false" data-volume-field="nome" data-volume-idx="${idx}" value="${escapeHtml(v.nome||'')}">
            <button type="button" class="input-clear-btn" ${(v.nome||'') ? '' : 'hidden'} aria-label="Limpar nome" onpointerdown="event.preventDefault();event.stopPropagation();" onmousedown="event.preventDefault();event.stopPropagation();" onclick="this.previousElementSibling.value='';this.hidden=true;const ev=new Event('input',{bubbles:true});this.previousElementSibling.dispatchEvent(ev);this.previousElementSibling.focus();"><svg class="icon"><use href="#i-close"/></svg></button>
          </div>
        </label>
        <label class="field full"><span>Status deste volume *</span><select data-volume-field="status" data-volume-idx="${idx}">${statusOptionsHtml(v.status)}</select></label>
      </div>
      <div class="extras-list" id="capsList_${idx}">${lista.map((c,ci) => capituloRowHtml(c, idx, ci)).join('')}</div>
      <div class="extras-actions">
        <button type="button" class="btn btn-ghost btn-sm" data-add-cap="cap" data-vol-idx="${idx}">+ Capítulo</button>
      </div>
    </div>
  </div>`;
}
function renderProgressBuilder(categoria){
  const container = document.getElementById('progressBuilder');
  if(CATEGORIAS_COM_TEMPORADAS.includes(categoria)){
    const hasOvas = (categoria === 'anime' || categoria === 'desenho');
    ensureDefaultSeason();
    if(!Array.isArray(state.builder.extras_independentes)) state.builder.extras_independentes = [];
    const indepLabel = categoria === 'desenho' ? 'Extras e filmes (sem temporada definida)' : 'OVAs e filmes (sem temporada definida)';
    const indepHint = categoria === 'desenho' ? 'Use aqui extras ou filmes que não pertencem a nenhuma temporada.' : 'Use aqui quando não souber a qual temporada a OVA/filme pertence. Se não souber o nome, informe exatamente a quantidade que assistiu.';
    const ovasSection = hasOvas ? `
      <div class="builder-label" style="margin-top:18px;">${indepLabel}</div>
      <p class="field-hint">${indepHint}</p>
      <div class="extras-list" id="indepExtrasList">${(()=>{ const sorted=sortExtras(state.builder.extras_independentes); state.builder.extras_independentes.splice(0,state.builder.extras_independentes.length,...sorted); return sorted.map((ex,i)=>indepExtraRowHtml(ex,i)).join(''); })()}</div>
      <div class="extras-actions">
        ${categoria === 'anime' ? `<button type="button" class="btn btn-ghost btn-sm" id="btnAddIndepOva">+ OVA</button>` : `<button type="button" class="btn btn-ghost btn-sm" id="btnAddIndepExtra">+ Extra</button>`}
        <button type="button" class="btn btn-ghost btn-sm" id="btnAddIndepFilme">+ Filme</button>
      </div>` : '';
    container.innerHTML = `<div class="builder-label">Temporadas</div>
      <div id="seasonsList">${state.builder.temporadas.map((s,i)=>seasonCardHtml(s,i,state.builder.temporadas.length,categoria)).join('')}</div>
      <button type="button" class="btn btn-ghost btn-sm" id="btnAddSeason"><svg class="icon"><use href="#i-plus"/></svg> Nova Temporada</button>
      <span class="field-error" id="err_temporadas"></span>` + ovasSection;
    document.getElementById('btnAddSeason').addEventListener('click', () => {
      // Fecha as demais e abre apenas a nova temporada
      state.builder.temporadas.forEach(t => { t.aberta = false; });
      state.builder.temporadas.push({status:'pretendo_ver', episodios:0, extras:[], aberta:true});
      renderProgressBuilder(categoria);
    });
    if(hasOvas){
      const addOva = document.getElementById('btnAddIndepOva');
      const addExtra = document.getElementById('btnAddIndepExtra');
      const _addIndepExtra = (tipo) => {
        const newEx = {tipo, nome:'', quantidade:null};
        state.builder.extras_independentes.push(newEx);
        const sorted = sortExtras(state.builder.extras_independentes);
        state.builder.extras_independentes.splice(0, state.builder.extras_independentes.length, ...sorted);
        const list = document.getElementById('indepExtrasList');
        if(list){
          list.innerHTML = state.builder.extras_independentes.map((ex,i) => indepExtraRowHtml(ex,i)).join('');
          const newIdx = state.builder.extras_independentes.findIndex(x => x === newEx);
          const rows = list.querySelectorAll('.extra-row');
          const targetRow = rows[newIdx >= 0 ? newIdx : rows.length - 1];
          if(targetRow) setTimeout(() => targetRow.scrollIntoView({block:'nearest', behavior:'smooth'}), 30);
        }
      };
      if(addOva) addOva.addEventListener('click', () => _addIndepExtra('OVA'));
      if(addExtra) addExtra.addEventListener('click', () => _addIndepExtra('Extra'));
      document.getElementById('btnAddIndepFilme').addEventListener('click', () => _addIndepExtra('Filme'));
    }
  } else if(categoria === 'novel'){
    ensureDefaultVolume();
    container.innerHTML = `<div class="builder-label">Volumes</div>
      <div id="volumesList">${state.builder.volumes.map((v,i)=>volumeCardHtml(v,i,state.builder.volumes.length)).join('')}</div>
      <button type="button" class="btn btn-ghost btn-sm" id="btnAddVolume"><svg class="icon"><use href="#i-plus"/></svg> Novo Volume</button>
      <span class="field-error" id="err_volumes"></span>`;
    document.getElementById('btnAddVolume').addEventListener('click', () => { state.builder.volumes.forEach(v => { v.aberta = false; }); const _nxtNum = nextVolumeNumber(); state.builder.volumes.push({status:'pretendo_ver', nome:'Volume ' + _nxtNum, capitulos:0, capitulos_lista:[], aberta:true}); renderProgressBuilder('novel'); });
  } else if(['manga','manhua','manhwa'].includes(categoria)){
    const statusAtual = document.getElementById('f_status').value;
    const isConcluido = statusAtual === 'concluido';
    const isPretendo = statusAtual === 'pretendo_ver';
    const label = isConcluido ? 'Total de capítulos *' : isPretendo ? 'Capítulos lidos (0 = ainda não comecei) *' : 'Último capítulo lido *';
    
    container.innerHTML = `<label class="field full">
        <span id="lbl_progresso_simples">${label}</span>
        <input type="number" min="0" step="any" inputmode="decimal" id="f_progresso_simples" value="${state.builder.progresso_simples ?? 0}">
        <span class="field-error" id="err_progresso_simples"></span>
      </label>`;
  } else if(categoria === 'livro'){
    const statusAtual = document.getElementById('f_status').value;
    let livroLabel;
    if(statusAtual === 'concluido') livroLabel = 'Total de páginas lidas *';
    else if(statusAtual === 'pretendo_ver') livroLabel = 'Páginas lidas (0 = ainda não comecei) *';
    else livroLabel = 'Página atual *';
    container.innerHTML = `<label class="field full">
        <span id="lbl_progresso_simples">${livroLabel}</span>
        <input type="number" min="0" step="1" inputmode="numeric" id="f_progresso_simples" value="${state.builder.progresso_simples ?? 0}">
        <span class="field-hint">Se preferir, informe o total de páginas do livro no campo "Total de páginas" acima.</span>
        <span class="field-error" id="err_progresso_simples"></span>
      </label>`;
  } else {
    container.innerHTML = `<p class="field-hint">Filmes não têm progresso de episódios ou capítulos — apenas o Status Pessoal acima.</p>`;
  }
}

function primarySubtypeFields(categoria){
  return (BONUS_FIELDS[categoria] || []).filter(f => f.primary);
}
function additionalBonusFields(categoria){
  return (BONUS_FIELDS[categoria] || []).filter(f => !f.primary);
}
function renderPrimarySubtypeField(categoria, entry){
  const container = document.getElementById('primarySubtypeContainer');
  if(!container) return;
  const fields = primarySubtypeFields(categoria);
  if(!fields.length){
    container.innerHTML = '';
    container.hidden = true;
    return;
  }
  container.hidden = false;
  container.innerHTML = fields.map(f => bonusFieldHtml(f, entry ? entry[f.key] : '')).join('');
}
function renderBonusFields(categoria, entry){
  const container = document.getElementById('bonusFieldsContainer');
  const fields = additionalBonusFields(categoria);
  if(!fields.length){ container.innerHTML = '<p class="field-hint">Nenhum detalhe adicional para esta categoria.</p>'; return; }
  container.innerHTML = `<div class="form-grid">${fields.map(f => bonusFieldHtml(f, entry ? entry[f.key] : '')).join('')}</div>`;
}
function bonusFieldHtml(f, value){
  const val = (value===undefined||value===null) ? '' : value;
  if(f.type === 'select'){
    // Subcategorias são obrigatórias e restritas às opções reais — sem placeholder "—".
    // Se a entrada não tem valor ainda, a primeira opção é assumida por padrão.
    const hasVal = f.options.some(o => o === val);
    return `<label class="field"><span>${f.label}</span><select id="bf_${f.key}">${f.options.map((o,i)=>`<option value="${o}" ${(hasVal ? o===val : i===0)?'selected':''}>${o}</option>`).join('')}</select></label>`;
  }
  return `<label class="field"><span>${f.label}</span><input type="${f.type}" id="bf_${f.key}" value="${escapeHtml(val)}" ${f.min!==undefined?`min="${f.min}"`:''} placeholder="${f.placeholder||''}"></label>`;
}

// (campo de gêneros removido — funções de chips/sugestões eliminadas)

function updateNotaDisplay(){
  const range = document.getElementById('f_nota_range');
  const display = document.getElementById('f_nota_display');
  const cleared = range.dataset.cleared === '1';
  const value = cleared ? 0 : Number(range.value);
  const pct = (value / 10) * 100;
  range.style.background = `linear-gradient(to right, var(--c-gold) ${pct}%, var(--bg-elevated-3) ${pct}%)`;
  display.textContent = cleared ? '—' : value.toFixed(1);
}
function clearFormErrors(){ document.querySelectorAll('.field-error').forEach(el => el.textContent = ''); }

function updateCoverPreview(){
  const preview = document.getElementById('coverPreview');
  const img = document.getElementById('coverPreviewImg');
  const src = state.cover.base64 || state.cover.url;
  if(src){ img.src = src; preview.hidden = false; } else { img.src = ''; preview.hidden = true; }
  document.getElementById('err_capa').textContent = '';
}
function handleCoverUpload(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    const img = new Image();
    img.onload = () => {
      const maxW = 1024;
      const scale = Math.min(1, maxW / img.width);
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      let compressed;
      try{ compressed = canvas.toDataURL('image/jpeg', 0.8); } catch(e){ compressed = ev.target.result; }
      state.cover = {base64: compressed, url: ''};
      document.getElementById('f_capa_url_input').value = '';
      updateCoverPreview();
    };
    img.onerror = () => showToast('error', 'Não foi possível processar essa imagem.');
    img.src = ev.target.result;
  };
  reader.onerror = () => showToast('error', 'Não foi possível ler o arquivo selecionado.');
  reader.readAsDataURL(file);
}
function blobToDataUrl(blob){
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
function imageBlobToCompressedDataUrl(blob, options){
  options = options || {};
  const maxW = options.maxWidth || 1024;
  const quality = typeof options.quality === 'number' ? options.quality : 0.8;
  const mime = options.mime || 'image/jpeg';
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(blob);
    img.onload = () => {
      try{
        const scale = Math.min(1, maxW / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        // JPEG não tem transparência. Preenche antes para evitar fundo preto
        // acidental em capas PNG/WebP com alpha.
        ctx.fillStyle = '#14171f';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(objectUrl);
        resolve(canvas.toDataURL(mime, quality));
      }catch(e){
        URL.revokeObjectURL(objectUrl);
        reject(e);
      }
    };
    img.onerror = () => { URL.revokeObjectURL(objectUrl); reject(new Error('image load')); };
    img.src = objectUrl;
  });
}
async function dataUrlToBlob(dataUrl){
  const res = await fetch(dataUrl);
  return await res.blob();
}
async function compressCoverDataUrlForJson(dataUrl){
  if(!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) return dataUrl || null;
  try{
    const blob = await dataUrlToBlob(dataUrl);
    const compressed = await imageBlobToCompressedDataUrl(blob, {
      maxWidth: JSON_REPORT_COVER_MAX_WIDTH,
      quality: JSON_REPORT_COVER_JPEG_QUALITY,
      mime: 'image/jpeg'
    });
    // Se uma capa já era menor, mantém a menor versão.
    return compressed && compressed.length < dataUrl.length ? compressed : dataUrl;
  }catch(e){
    return dataUrl;
  }
}
async function convertImageUrlToDataUrl(url){
  if(!url || !isOnline()) return null;
  const res = await fetch(url, {mode:'cors', cache:'no-cache'});
  if(!res.ok) throw new Error('status ' + res.status);
  const blob = await res.blob();
  if(!blob.type || !blob.type.startsWith('image/')) return null;
  try{
    return await imageBlobToCompressedDataUrl(blob);
  }catch(e){
    if(blob.size <= 1600000) return await blobToDataUrl(blob);
    return null;
  }
}
async function convertImageUrlToCompactJsonDataUrl(url){
  if(!url || !isOnline()) return null;
  const res = await fetch(url, {mode:'cors', cache:'no-cache'});
  if(!res.ok) throw new Error('status ' + res.status);
  const blob = await res.blob();
  if(!blob.type || !blob.type.startsWith('image/')) return null;
  return await imageBlobToCompressedDataUrl(blob, {
    maxWidth: JSON_REPORT_COVER_MAX_WIDTH,
    quality: JSON_REPORT_COVER_JPEG_QUALITY,
    mime: 'image/jpeg'
  });
}
async function cacheExternalCoverUrl(url){
  if(!url || !isValidUrl(url) || !('caches' in window) || !isOnline()) return false;
  try{
    const cache = await caches.open('acervo-covers-v1');
    const res = await fetch(url, {mode:'no-cors', cache:'reload'});
    if(res && (res.ok || res.type === 'opaque')){
      await cache.put(url, res.clone());
      return true;
    }
  }catch(e){ /* Cache API pode não existir em file:// ou modo privado */ }
  return false;
}
async function cacheCurrentCoverForOffline(){
  if(state.cover.base64) return true;
  const url = state.cover.url || (document.getElementById('f_capa_url_input') && document.getElementById('f_capa_url_input').value.trim());
  if(!url || !isValidUrl(url) || !isOnline()) return false;
  try{
    const dataUrl = await convertImageUrlToDataUrl(url);
    if(dataUrl){
      state.cover = {base64:dataUrl, url:''};
      updateCoverPreview();
      return true;
    }
  }catch(e){ /* mantém URL externa como fallback */ }
  return await cacheExternalCoverUrl(url);
}
function cleanCoverQuery(value){
  return String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\[[^\]]*]/g, ' ')
    .replace(/\([^)]*\)/g, ' ')
    // Remove marcadores tipo "S2", "S02", "T3", "T03" (usados para temporadas)
    .replace(/\b[ST]\d{1,3}\b/gi, ' ')
    .replace(/\b(original|chapter|capitulo|episodio|episode|temporada|season|volume|vol|ova|filme|movie|classico|classic|editado|dublado|legendado|part|parte)\b\.?\s*\d*/gi, ' ')
    .replace(/\b\d{1,5}\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
function categoryCoverTerms(categoria){
  const map = {
    anime:['anime'],
    serie:['tv series','series','poster'],
    desenho:['cartoon','animated series','animation'],
    filme:['movie','film','poster'],
    manga:['manga','mangá'],
    manhwa:['manhwa','webtoon'],
    manhua:['manhua','donghua'],
    novel:['light novel','web novel','book cover'],
    livro:['book cover','book']
  };
  return map[categoria] || [];
}
function coverSearchQueries(titulo, original, categoria){
  const seeds = [titulo, original].filter(Boolean);
  const queries = [];
  const catTerms = categoryCoverTerms(categoria);
  seeds.forEach(seed => {
    const s = String(seed).trim();
    if(!s) return;
    queries.push(s);
    const beforeDash = s.split(/\s[-–—]\s/)[0].trim();
    if(beforeDash && beforeDash !== s) queries.push(beforeDash);
    const cleaned = cleanCoverQuery(s);
    if(cleaned && cleaned !== s) queries.push(cleaned);
    if(cleaned){
      catTerms.forEach(term => queries.push(cleaned + ' ' + term));
      const words = cleaned.split(/\s+/).filter(w => w.length > 2);
      if(words.length > 2) queries.push(words.slice(0, 3).join(' '));
      if(words.length > 3) queries.push(words.slice(0, 4).join(' '));
    }
  });
  const seen = new Set();
  return queries
    .map(q => q.replace(/\s+/g,' ').trim())
    .filter(q => q.length >= 2)
    .filter(q => { const k = q.toLowerCase(); if(seen.has(k)) return false; seen.add(k); return true; })
    .slice(0, 8);
}
async function fetchJsonWithTimeout(url, timeoutMs, options){
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs || 9000);
  try{
    const opts = Object.assign({signal: ctrl.signal, headers:{'Accept':'application/json'}}, options || {});
    opts.signal = ctrl.signal;
    opts.headers = Object.assign({'Accept':'application/json'}, (options && options.headers) || {});
    const res = await fetch(url, opts);
    if(!res.ok) throw new Error('status ' + res.status);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}
function addCoverResult(results, seen, url, source, title){
  if(!url) return;
  url = String(url).replace(/^http:\/\//i, 'https://');
  const key = url.replace(/\?.*$/, '');
  if(seen.has(key)) return;
  seen.add(key);
  results.push({url, source, title: title || source});
}
function coverSourceRank(source, categoria){
  const common = {AniList:1, Kitsu:2, Jikan:3, TVmaze:1, 'Google Books':4, OpenLibrary:5, 'Apple Movies':1, Wikipedia:8};
  if(categoria === 'serie' || categoria === 'desenho') return ({TVmaze:1, Wikipedia:3, 'Apple Movies':5}[source] || 9);
  if(categoria === 'filme') return ({'Apple Movies':1, Wikipedia:3, Jikan:5}[source] || 9);
  if(categoria === 'novel') return ({'Google Books':1, OpenLibrary:2, AniList:3, Jikan:4, Wikipedia:8}[source] || 9);
  if(categoria === 'livro') return ({'Google Books':1, OpenLibrary:2, Wikipedia:5}[source] || 9);
  return common[source] || 9;
}
async function searchJikanCovers(query, endpoint, extra, results, seen){
  const json = await fetchJsonWithTimeout(`https://api.jikan.moe/v4/${endpoint}?q=${encodeURIComponent(query)}&limit=8${extra||''}`, 9000);
  (json.data || []).forEach(it => {
    const jpg = it.images && it.images.jpg;
    addCoverResult(results, seen, jpg && (jpg.large_image_url || jpg.image_url), 'Jikan', it.title || it.title_english);
  });
}
async function searchGoogleBooksCovers(query, results, seen){
  const json = await fetchJsonWithTimeout(`https://www.googleapis.com/books/v1/volumes?q=intitle:${encodeURIComponent(query)}&maxResults=8&printType=books`, 9000);
  (json.items || []).forEach(it => {
    const info = it.volumeInfo || {};
    const img = info.imageLinks || {};
    addCoverResult(results, seen, img.extraLarge || img.large || img.medium || img.thumbnail || img.smallThumbnail, 'Google Books', info.title);
  });
}
async function searchOpenLibraryCovers(query, results, seen){
  const json = await fetchJsonWithTimeout(`https://openlibrary.org/search.json?title=${encodeURIComponent(query)}&limit=8`, 9000);
  (json.docs || []).forEach(doc => {
    if(doc.cover_i) addCoverResult(results, seen, `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg`, 'OpenLibrary', doc.title);
  });
}
async function searchItunesMovieCovers(query, results, seen){
  const json = await fetchJsonWithTimeout(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=movie&entity=movie&limit=8`, 9000);
  (json.results || []).forEach(it => {
    const art = it.artworkUrl100 ? it.artworkUrl100.replace(/100x100bb(\.(jpg|png))?$/i, '600x900bb$1') : '';
    addCoverResult(results, seen, art, 'Apple Movies', it.trackName);
  });
}
async function searchTvMazeCovers(query, results, seen){
  const json = await fetchJsonWithTimeout(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(query)}`, 9000);
  (json || []).slice(0, 8).forEach(row => {
    const show = row && row.show ? row.show : {};
    const img = show.image || {};
    addCoverResult(results, seen, img.original || img.medium, 'TVmaze', show.name);
  });
}
async function searchAniListCovers(query, type, results, seen){
  const body = JSON.stringify({
    query: 'query($search:String,$type:MediaType){Page(page:1,perPage:8){media(search:$search,type:$type){title{romaji english native} coverImage{extraLarge large medium}}}}',
    variables: {search: query, type: type}
  });
  const json = await fetchJsonWithTimeout('https://graphql.anilist.co', 9000, {
    method:'POST',
    headers:{'Content-Type':'application/json','Accept':'application/json'},
    body
  });
  (((json.data || {}).Page || {}).media || []).forEach(it => {
    const title = (it.title && (it.title.english || it.title.romaji || it.title.native)) || 'AniList';
    const img = it.coverImage || {};
    addCoverResult(results, seen, img.extraLarge || img.large || img.medium, 'AniList', title);
  });
}
async function searchKitsuCovers(query, kind, results, seen){
  const json = await fetchJsonWithTimeout(`https://kitsu.io/api/edge/${kind}?filter[text]=${encodeURIComponent(query)}&page[limit]=8`, 9000);
  (json.data || []).forEach(it => {
    const attrs = it.attributes || {};
    const poster = attrs.posterImage || {};
    addCoverResult(results, seen, poster.original || poster.large || poster.medium || poster.small, 'Kitsu', attrs.canonicalTitle);
  });
}
async function searchWikipediaImages(query, categoria, results, seen){
  const term = [query].concat(categoryCoverTerms(categoria)).join(' ');
  const json = await fetchJsonWithTimeout(`https://en.wikipedia.org/w/api.php?origin=*&action=query&generator=search&gsrsearch=${encodeURIComponent(term)}&gsrlimit=8&prop=pageimages&pithumbsize=700&format=json`, 9000);
  const pages = ((json.query || {}).pages) || {};
  Object.keys(pages).forEach(id => {
    const p = pages[id];
    addCoverResult(results, seen, p.thumbnail && p.thumbnail.source, 'Wikipedia', p.title);
  });
}
function renderCoverSearchResults(grid, results, categoria){
  results.sort((a,b) => coverSourceRank(a.source, categoria) - coverSourceRank(b.source, categoria));
  grid.innerHTML = results.slice(0, 12).map(item => `<button type="button" class="cover-thumb" data-url="${escapeHtml(item.url)}" title="${escapeHtml(item.title || item.source)}"><img src="${escapeHtml(item.url)}" loading="lazy" decoding="async" alt="" referrerpolicy="no-referrer"><span class="cover-thumb-source">${escapeHtml(item.source)}</span></button>`).join('');
  grid.querySelectorAll('.cover-thumb').forEach(btn => {
    btn.addEventListener('click', async () => {
      state.cover = {base64:null, url: btn.dataset.url};
      document.getElementById('f_capa_upload').value = '';
      document.getElementById('f_capa_url_input').value = btn.dataset.url;
      updateCoverPreview();
      grid.hidden = true;
      await cacheCurrentCoverForOffline();
    });
  });
}
async function buscarCapaOnline(){
  const titulo = document.getElementById('f_titulo').value.trim();
  const tituloOriginal = document.getElementById('f_titulo_original').value.trim();
  const categoria = document.getElementById('f_categoria').value;
  // Se for filme, considera a subcategoria (Cinema/Desenho/Anime) para direcionar
  // a busca. Cinema → filmes comuns (iTunes/Wikipedia); Anime → filmes de anime
  // (AniList/Kitsu/Jikan tipo movie); Desenho → animação ocidental (iTunes/Wikipedia
  // com termos como "animated movie"/"animation").
  const filmeSubEl = document.getElementById('bf_subcategoria');
  const filmeSub = (categoria === 'filme' && filmeSubEl) ? String(filmeSubEl.value||'').toLowerCase() : '';
  if(!titulo){ showToast('warning', 'Preencha o título antes de buscar a capa.'); return; }
  const grid = document.getElementById('coverSearchGrid');
  grid.hidden = false;
  grid.innerHTML = '<div class="cover-search-status">Buscando capas...</div>';
  const queries = coverSearchQueries(titulo, tituloOriginal, categoria);
  const primaryKey = cacheKey(categoria, queries[0] || titulo);
  const cache = readOnlineCache();
  if(!isOnline() && cache.covers[primaryKey] && cache.covers[primaryKey].length){
    renderCoverSearchResults(grid, cache.covers[primaryKey], categoria);
    return;
  }
  const results = [];
  const seen = new Set();
  try{
    if(!isOnline()) throw new Error('offline');
    const tasks = [];
    queries.forEach(q => {
      if(categoria === 'anime'){
        tasks.push(searchAniListCovers(q, 'ANIME', results, seen));
        tasks.push(searchKitsuCovers(q, 'anime', results, seen));
        tasks.push(searchJikanCovers(q, 'anime', '', results, seen));
        tasks.push(searchJikanCovers(q, 'manga', '', results, seen));
      } else if(categoria === 'serie'){
        tasks.push(searchTvMazeCovers(q, results, seen));
        tasks.push(searchWikipediaImages(q + ' television series', categoria, results, seen));
      } else if(categoria === 'desenho'){
        tasks.push(searchTvMazeCovers(q, results, seen));
        tasks.push(searchTvMazeCovers(q + ' animated', results, seen));
        tasks.push(searchTvMazeCovers(q + ' cartoon', results, seen));
        tasks.push(searchWikipediaImages(q + ' animated series', categoria, results, seen));
        tasks.push(searchWikipediaImages(q + ' cartoon', categoria, results, seen));
      } else if(categoria === 'filme'){
        if(filmeSub === 'anime'){
          // Filme de anime — busca em bases de anime, tipo movie
          tasks.push(searchAniListCovers(q, 'ANIME', results, seen));
          tasks.push(searchKitsuCovers(q, 'anime', results, seen));
          tasks.push(searchJikanCovers(q, 'anime', '&type=movie', results, seen));
          tasks.push(searchWikipediaImages(q, categoria, results, seen));
        } else if(filmeSub === 'desenho'){
          // Desenho animado ocidental — iTunes movies + Wikipedia com termos de animação
          tasks.push(searchItunesMovieCovers(q, results, seen));
          tasks.push(searchItunesMovieCovers(q + ' animated', results, seen));
          tasks.push(searchWikipediaImages(q + ' animated film', categoria, results, seen));
          tasks.push(searchWikipediaImages(q + ' animation movie', categoria, results, seen));
        } else {
          // Cinema (padrão) — filmes comuns: iTunes movies + Wikipedia
          tasks.push(searchItunesMovieCovers(q, results, seen));
          tasks.push(searchWikipediaImages(q + ' film', categoria, results, seen));
          tasks.push(searchWikipediaImages(q, categoria, results, seen));
        }
      } else if(categoria === 'novel'){
        tasks.push(searchAniListCovers(q, 'MANGA', results, seen));
        tasks.push(searchGoogleBooksCovers(q, results, seen));
        tasks.push(searchOpenLibraryCovers(q, results, seen));
        tasks.push(searchJikanCovers(q, 'manga', '&type=lightnovel', results, seen));
      } else if(categoria === 'livro'){
        tasks.push(searchGoogleBooksCovers(q, results, seen));
        tasks.push(searchOpenLibraryCovers(q, results, seen));
        tasks.push(searchWikipediaImages(q + ' book cover', categoria, results, seen));
      } else {
        tasks.push(searchAniListCovers(q, 'MANGA', results, seen));
        tasks.push(searchKitsuCovers(q, 'manga', results, seen));
        tasks.push(searchJikanCovers(q, 'manga', '', results, seen));
        tasks.push(searchGoogleBooksCovers(q, results, seen));
      }
      tasks.push(searchWikipediaImages(q, categoria, results, seen));
    });
    await Promise.allSettled(tasks);
    if(!results.length){ grid.innerHTML = '<div class="cover-search-status">Nenhum resultado encontrado. Tente um título mais curto, envie uma imagem ou cole uma URL.</div>'; return; }
    cache.covers[primaryKey] = results.slice(0, 20);
    writeOnlineCache(cache);
    renderCoverSearchResults(grid, results, categoria);
  }catch(e){
    const cached = cache.covers[primaryKey];
    if(cached && cached.length){
      renderCoverSearchResults(grid, cached, categoria);
    } else {
      grid.innerHTML = '<div class="cover-search-status">Sem conexão/cache de capas para este título. Envie uma imagem do dispositivo ou cole uma URL manualmente.</div>';
    }
  }
}

function setOnlineMetaStatus(text, kind){
  const el = document.getElementById('onlineMetaStatus');
  if(!el) return;
  el.textContent = text || '';
  el.hidden = !text;
  el.classList.toggle('is-ok', kind === 'ok');
  el.classList.toggle('is-error', kind === 'error');
}
function setOnlineMetaSearching(active){
  onlineMetaSearching = !!active;
  const searchBtn = document.getElementById('btnBuscarDadosOnline');
  const cancelBtn = document.getElementById('btnCancelarDadosOnline');
  if(searchBtn) searchBtn.disabled = onlineMetaSearching;
  if(cancelBtn) cancelBtn.hidden = !onlineMetaSearching;
}
function cancelOnlineMetadataSearch(){
  if(!onlineMetaSearching) return;
  onlineMetaRequestId++;
  setOnlineMetaSearching(false);
  setOnlineMetaStatus('Pesquisa online cancelada.', 'error');
}
function setOnlineMetaOptionsAvailable(hasOptions){
  const btn = document.getElementById('btnVerOpcoesOnline');
  if(!btn) return;
  btn.hidden = !hasOptions;
}
function openMetadataPicker(){
  const list = state.lastMetadataResults || [];
  const container = document.getElementById('metadataPickerList');
  if(!container) return;
  if(!list.length){
    container.innerHTML = '<p class="field-hint">Nenhum resultado disponível. Faça uma nova pesquisa.</p>';
  } else {
    container.innerHTML = list.map((r, i) => {
      const cover = r.cover ? `<img src="${escapeHtml(r.cover)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" style="width:56px;height:80px;object-fit:cover;border-radius:4px;background:#222;flex-shrink:0;" onerror="window.__coverFallback(this)">` : `<div style="width:56px;height:80px;background:#222;border-radius:4px;flex-shrink:0;display:flex;align-items:center;justify-content:center;color:#666;font-size:20px;">🖼</div>`;
      const genres = (r.genres||[]).slice(0,3).join(', ');
      return `<button type="button" data-meta-idx="${i}" style="display:flex;gap:10px;align-items:flex-start;padding:8px;background:var(--bg-elevated-2);border:1px solid var(--border);border-radius:8px;text-align:left;cursor:pointer;color:inherit;font:inherit;">
        ${cover}
        <div style="flex:1;min-width:0;">
          <div style="font-weight:600;font-size:0.9rem;line-height:1.25;">${escapeHtml(r.title)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:3px;">${r.year ? escapeHtml(String(r.year)) + ' · ' : ''}${escapeHtml(r.source)}${r.categoria ? ' · ' + escapeHtml(r.categoria) : ''}</div>
          ${genres ? `<div style="font-size:0.7rem;color:var(--text-faint);margin-top:3px;">${escapeHtml(genres)}</div>` : ''}
        </div>
      </button>`;
    }).join('');
    container.querySelectorAll('[data-meta-idx]').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.dataset.metaIdx);
        const chosen = (state.lastMetadataResults||[])[idx];
        if(chosen){
          // Aplica ainda que os campos já estejam preenchidos — o usuário está escolhendo manualmente.
          const changed = applyOnlineMetadata(chosen, {overwrite:true});
          setOnlineMetaStatus(changed.length ? 'Aplicado: ' + changed.join(', ') + '.' : 'Aplicado.', 'ok');
        }
        closeMetadataPicker();
      });
    });
  }
  document.getElementById('metadataPickerBackdrop').hidden = false;
}
function closeMetadataPicker(){
  const bd = document.getElementById('metadataPickerBackdrop');
  if(bd) bd.hidden = true;
}
function normalizeLookupText(value){
  return String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}
function hasNonWesternTitleChars(value){
  return /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af]/.test(String(value || ''));
}
// Remove blocos CJK (japonês/chinês/coreano) preservando texto ocidental.
// "Naruto ナルト" -> "Naruto"; "進撃の巨人 (Attack on Titan)" -> "(Attack on Titan)".
function stripCJK(value){
  return String(value || '')
    .replace(/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af\u3000-\u303f\uff00-\uffef]+/g, ' ')
    .replace(/[\s\-–—:·|]*[\(\[\{]\s*[\)\]\}][\s\-–—:·|]*/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[\s\-–—:·|,.]+|[\s\-–—:·|,.]+$/g, '')
    .trim();
}
function westernTitle(){
  for(let i = 0; i < arguments.length; i++){
    const value = String(arguments[i] || '').trim();
    if(!value) continue;
    if(!hasNonWesternTitleChars(value)) return value;
    // Título misto: extrai a parte ocidental legível.
    const stripped = stripCJK(value);
    if(stripped && stripped.replace(/[^A-Za-zÀ-ÿ0-9]/g, '').length >= 2) return stripped;
  }
  return '';
}
function sanitizeWesternTitle(value, fallback){
  const safe = westernTitle(value);
  if(safe) return safe;
  return westernTitle(fallback) || '';
}
function metadataTitleScore(query, title){
  const q = normalizeLookupText(query);
  const t = normalizeLookupText(title);
  if(!q || !t) return 99;
  if(t === q) return 0;
  if(t.startsWith(q)) return 1;
  if(q.startsWith(t)) return 2;
  // Pontuação por sobreposição de tokens (estilo Google): mais palavras da
  // pesquisa presentes no título = melhor. Considera também correspondências
  // parciais (prefixo de palavra) para tolerar variações e traduções.
  const qTokens = q.split(/\s+/).filter(w => w.length >= 2);
  const tTokens = new Set(t.split(/\s+/).filter(Boolean));
  if(qTokens.length){
    let matched = 0;
    qTokens.forEach(w => {
      if(tTokens.has(w)) { matched += 1; return; }
      // prefixo (>=3 chars) — tolera sufixos, plurais, variações
      if(w.length >= 3 && Array.from(tTokens).some(tw => tw.startsWith(w) || w.startsWith(tw))) matched += 0.7;
    });
    const ratio = matched / qTokens.length;
    if(ratio >= 0.999) return 3;
    if(ratio >= 0.75) return 4;
    if(ratio >= 0.5) return 5;
    if(ratio >= 0.25) return 6;
  }
  if(t.includes(q) || q.includes(t)) return 4;
  return 8;
}
function metadataCategoryFromAniList(media, fallback){
  const type = media && media.type;
  const format = media && media.format;
  const country = media && media.countryOfOrigin;
  if(type === 'ANIME') return format === 'MOVIE' ? 'filme' : 'anime';
  if(type === 'MANGA'){
    if(format === 'NOVEL') return 'novel';
    if(country === 'KR') return 'manhwa';
    if(country === 'CN') return 'manhua';
    return 'manga';
  }
  return fallback || 'anime';
}
function metadataCategoryFromJikan(item, endpoint, fallback){
  const type = String((item && item.type) || '').toLowerCase();
  if(endpoint === 'anime') return type === 'movie' ? 'filme' : 'anime';
  if(type.includes('light novel') || type === 'novel') return 'novel';
  if(type === 'manhwa') return 'manhwa';
  if(type === 'manhua') return 'manhua';
  return fallback && fallback !== 'anime' && fallback !== 'filme' ? fallback : 'manga';
}
function isoYear(value){
  if(!value) return null;
  const m = String(value).match(/\b(19\d{2}|20\d{2}|2100)\b/);
  return m ? Number(m[1]) : null;
}
const GENRE_PT = {
  action:'Ação',
  adventure:'Aventura',
  avantgarde:'Avant-garde',
  'avant garde':'Avant-garde',
  awardwinning:'Premiado',
  'award winning':'Premiado',
  boyslove:'Boys Love',
  'boys love':'Boys Love',
  comedy:'Comédia',
  drama:'Drama',
  ecchi:'Ecchi',
  fantasy:'Fantasia',
  girlslove:'Girls Love',
  'girls love':'Girls Love',
  gourmet:'Gastronomia',
  horror:'Terror',
  mystery:'Mistério',
  romance:'Romance',
  scifi:'Ficção científica',
  'sci fi':'Ficção científica',
  'sci-fi':'Ficção científica',
  sliceoflife:'Slice of Life',
  'slice of life':'Slice of Life',
  sports:'Esporte',
  supernatural:'Sobrenatural',
  suspense:'Suspense',
  thriller:'Suspense',
  erotica:'Erótica',
  hentai:'Hentai',
  adultcast:'Elenco adulto',
  'adult cast':'Elenco adulto',
  anthropomorphic:'Antropomórfico',
  cgdct:'CGDCT',
  childcare:'Cuidado infantil',
  'combat sports':'Esportes de combate',
  combatsports:'Esportes de combate',
  crossdressing:'Crossdressing',
  delinquent:'Delinquentes',
  detective:'Detetive',
  educational:'Educacional',
  gaghumor:'Humor gag',
  'gag humor':'Humor gag',
  gore:'Gore',
  harem:'Harém',
  highstakesgame:'Jogo de alto risco',
  'high stakes game':'Jogo de alto risco',
  historical:'Histórico',
  idolsfemale:'Idols femininas',
  'idols female':'Idols femininas',
  idolsmale:'Idols masculinos',
  'idols male':'Idols masculinos',
  isekai:'Isekai',
  iyashikei:'Iyashikei',
  'love polygon':'Polígono amoroso',
  lovepolygon:'Polígono amoroso',
  magicalsexshift:'Troca mágica de sexo',
  'magical sex shift':'Troca mágica de sexo',
  mahoushoujo:'Mahou Shoujo',
  'mahou shoujo':'Mahou Shoujo',
  martialarts:'Artes marciais',
  'martial arts':'Artes marciais',
  mecha:'Mecha',
  medical:'Medicina',
  military:'Militar',
  music:'Música',
  mythology:'Mitologia',
  organizedcrime:'Crime organizado',
  'organized crime':'Crime organizado',
  otakuculture:'Cultura otaku',
  'otaku culture':'Cultura otaku',
  parody:'Paródia',
  performingsarts:'Artes performáticas',
  performingarts:'Artes performáticas',
  'performing arts':'Artes performáticas',
  pets:'Animais de estimação',
  psychological:'Psicológico',
  racing:'Corrida',
  reincarnation:'Reencarnação',
  reverseharem:'Harém reverso',
  'reverse harem':'Harém reverso',
  romance:'Romance',
  samurai:'Samurai',
  school:'Escolar',
  showbiz:'Showbiz',
  space:'Espaço',
  strategygame:'Jogo de estratégia',
  'strategy game':'Jogo de estratégia',
  superpower:'Superpoderes',
  survival:'Sobrevivência',
  teamsports:'Esportes coletivos',
  'team sports':'Esportes coletivos',
  'time travel':'Viagem no tempo',
  timetravel:'Viagem no tempo',
  vampire:'Vampiro',
  videogame:'Videojogo',
  'video game':'Videojogo',
  villainess:'Vilã',
  visualarts:'Artes visuais',
  'visual arts':'Artes visuais',
  workplace:'Ambiente de trabalho',
  animation:'Animação',
  anime:'Anime',
  manga:'Mangá',
  comics:'Banda desenhada',
  graphicnovels:'Graphic novels',
  'graphic novels':'Graphic novels',
  comicsgraphicnovels:'Banda desenhada e graphic novels',
  'comics graphic novels':'Banda desenhada e graphic novels',
  fiction:'Ficção',
  nonfiction:'Não ficção',
  'non fiction':'Não ficção',
  juvenilefiction:'Ficção juvenil',
  'juvenile fiction':'Ficção juvenil',
  youngadultfiction:'Ficção jovem adulta',
  'young adult fiction':'Ficção jovem adulta',
  sciencefiction:'Ficção científica',
  'science fiction':'Ficção científica',
  crime:'Crime',
  family:'Família',
  movie:'Filme',
  movies:'Filmes',
  film:'Filme',
  documentary:'Documentário',
  josei:'Josei',
  kids:'Infantil',
  seinen:'Seinen',
  shoujo:'Shoujo',
  shounen:'Shounen'
};
function translateGenrePt(genre){
  const raw = String(genre || '').trim();
  if(!raw) return '';
  const compact = normalizeLookupText(raw).replace(/\s+/g, '');
  const spaced = normalizeLookupText(raw);
  return GENRE_PT[compact] || GENRE_PT[spaced] || raw;
}
function addMetadataResult(results, item){
  if(!item || !item.title) return;
  // Try to get a western-friendly title, but don't reject results that only have CJK titles
  const westernized = sanitizeWesternTitle(item.title, item.titleOriginal) || sanitizeWesternTitle(item.titleOriginal, '');
  if(westernized){
    item.title = westernized;
  } else {
    // Regra: sugestões SEMPRE em alfabeto ocidental. Se o resultado só tiver
    // título em CJK (japonês/chinês/coreano) e nenhum equivalente romaji/
    // english, descartamos — o utilizador não consegue ler nem usar.
    return;
  }
  // titleOriginal DEVE preservar o título nativo (inclusive CJK — japonês, chinês,
  // coreano) porque é justamente o "nome original" que o utilizador quer registar.
  // Só usa o título principal como último recurso.
  item.titleOriginal = String(item.titleOriginal || '').trim() || sanitizeWesternTitle(item.title, '') || String(item.title || '').trim();
  if(item.year) item.year = Number(item.year);
  item.genres = (item.genres || []).map(translateGenrePt).filter(Boolean);
  results.push(item);
}
async function searchAniListMetadata(query, type, results){
  const body = JSON.stringify({
    query: 'query($search:String,$type:MediaType){Page(page:1,perPage:8){media(search:$search,type:$type){title{romaji english native} type format countryOfOrigin startDate{year month day} genres description(asHtml:false) coverImage{extraLarge large medium} status}}}',
    variables: {search: query, type}
  });
  const json = await fetchJsonWithTimeout('https://graphql.anilist.co', 9000, {
    method:'POST',
    headers:{'Content-Type':'application/json','Accept':'application/json'},
    body
  });
  (((json.data || {}).Page || {}).media || []).forEach(media => {
    const titleObj = media.title || {};
    const mainTitle = westernTitle(titleObj.english, titleObj.romaji, titleObj.native);
    // Nome original = título NATIVO (japonês/CJK) sempre que existir;
    // se não houver, cai para romaji e por fim english.
    const originalTitle = westernTitle(titleObj.romaji, titleObj.english) || titleObj.romaji || titleObj.english || '';
    addMetadataResult(results, {
      source: 'AniList',
      title: mainTitle || titleObj.english || titleObj.romaji || titleObj.native,
      titleOriginal: originalTitle,
      year: media.startDate && media.startDate.year,
      categoria: metadataCategoryFromAniList(media),
      genres: media.genres || [],
      cover: media.coverImage && (media.coverImage.extraLarge || media.coverImage.large || media.coverImage.medium),
      synopsis: media.description ? String(media.description).replace(/<[^>]+>/g, '').trim() : '',
      statusOficial: media.status || '',
      durationMin: media.duration || null
    });
  });
}
async function searchJikanMetadata(query, endpoint, extra, results, fallbackCategoria){
  const json = await fetchJsonWithTimeout(`https://api.jikan.moe/v4/${endpoint}?q=${encodeURIComponent(query)}&limit=8${extra||''}`, 9000);
  (json.data || []).forEach(item => {
    const genreList = []
      .concat(item.genres || [])
      .concat(item.themes || [])
      .concat(item.demographics || [])
      .map(g => g && g.name)
      .filter(Boolean);
    const date = (item.aired && item.aired.from) || (item.published && item.published.from) || '';
    const mainTitle = westernTitle(item.title_english, item.title, item.title_japanese);
    // Nome original = título JAPONÊS (kanji/kana) se existir, senão o title romaji.
    const originalTitle = westernTitle(item.title, item.title_english) || item.title || item.title_english || '';
    addMetadataResult(results, {
      source: 'Jikan',
      title: mainTitle || item.title_english || item.title || item.title_japanese,
      titleOriginal: originalTitle,
      year: item.year || isoYear(date),
      categoria: metadataCategoryFromJikan(item, endpoint, fallbackCategoria),
      genres: genreList,
      cover: item.images && item.images.jpg && (item.images.jpg.large_image_url || item.images.jpg.image_url),
      synopsis: item.synopsis || '',
      authors: (item.authors || []).map(a => a && a.name).filter(Boolean),
      statusOficial: item.status || '',
      durationMin: typeof item.duration === 'number' ? item.duration : null
    });
  });
}
async function searchGoogleBooksMetadata(query, results, categoria){
  // Sem prefixo intitle: — muitas novels famosas não batem intitle exato
  // (títulos traduzidos, subtítulos, edições). A busca livre traz muito mais.
  const json = await fetchJsonWithTimeout(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}&maxResults=12&printType=books`, 9000);
  const outCategoria = categoria || 'novel';
  (json.items || []).forEach(item => {
    const info = item.volumeInfo || {};
    const img = info.imageLinks || {};
    const mainTitle = westernTitle(info.title, info.subtitle);
    const originalTitle = westernTitle(info.subtitle, info.title);
    let cover = img.extraLarge || img.large || img.medium || img.thumbnail || img.smallThumbnail || '';
    if(cover) cover = cover.replace(/^http:\/\//, 'https://');
    addMetadataResult(results, {
      source: 'Google Books',
      title: mainTitle || info.title,
      titleOriginal: originalTitle && originalTitle !== mainTitle ? originalTitle : '',
      year: isoYear(info.publishedDate),
      categoria: outCategoria,
      genres: info.categories || [],
      cover,
      synopsis: info.description || '',
      authors: info.authors || [],
      publisher: info.publisher || '',
      pagesTotal: info.pageCount || null
    });
  });
}
async function searchOpenLibraryMetadata(query, results, categoria){
  // Usa q= (busca ampla em título, autor e assuntos) — pega novels traduzidas e edições variantes.
  const json = await fetchJsonWithTimeout(`https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=15`, 9000);
  const outCategoria = categoria || 'novel';
  (json.docs || []).forEach(doc => {
    addMetadataResult(results, {
      source: 'OpenLibrary',
      title: doc.title,
      titleOriginal: doc.title_english || '',
      year: doc.first_publish_year || null,
      categoria: outCategoria,
      genres: doc.subject ? doc.subject.slice(0, 8) : [],
      cover: doc.cover_i ? `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg` : '',
      authors: doc.author_name || [],
      publisher: (doc.publisher && doc.publisher[0]) || '',
      pagesTotal: doc.number_of_pages_median || null
    });
  });
}
async function searchItunesMovieMetadata(query, results){
  // country=us garante catálogo global consistente (o padrão varia por IP).
  const json = await fetchJsonWithTimeout(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=movie&entity=movie&limit=12&country=us`, 9000);
  (json.results || []).forEach(item => {
    const art = item.artworkUrl100 ? item.artworkUrl100.replace(/100x100bb(\.(jpg|png))?$/i, '600x900bb$1') : '';
    addMetadataResult(results, {
      source: 'Apple Movies',
      title: item.trackName,
      titleOriginal: item.trackCensoredName || item.trackName,
      year: isoYear(item.releaseDate),
      categoria: 'filme',
      genres: item.primaryGenreName ? [item.primaryGenreName] : [],
      cover: art,
      durationMin: item.trackTimeMillis ? Math.round(item.trackTimeMillis / 60000) : null
    });
  });
}
async function searchTvMazeMetadata(query, results, categoria){
  const json = await fetchJsonWithTimeout(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(query)}`, 9000);
  (json || []).slice(0, 10).forEach(row => {
    const show = row && row.show ? row.show : {};
    const img = show.image || {};
    addMetadataResult(results, {
      source: 'TVmaze',
      title: show.name,
      titleOriginal: '',
      year: isoYear(show.premiered),
      categoria: categoria || 'serie',
      genres: show.genres || [],
      cover: img.original || img.medium || '',
      statusOficial: show.status || ''
    });
  });
}
async function searchKitsuMetadata(query, kind, results, categoria){
  const json = await fetchJsonWithTimeout(`https://kitsu.io/api/edge/${kind}?filter[text]=${encodeURIComponent(query)}&page[limit]=8`, 9000);
  (json.data || []).forEach(it => {
    const attrs = it.attributes || {};
    const poster = attrs.posterImage || {};
    addMetadataResult(results, {
      source: 'Kitsu',
      title: attrs.canonicalTitle || attrs.titles && (attrs.titles.en || attrs.titles.en_jp) || '',
      titleOriginal: (attrs.titles && (attrs.titles.ja_jp || attrs.titles.ja || attrs.titles.en_jp)) || attrs.canonicalTitle || '',
      year: isoYear(attrs.startDate),
      categoria: categoria || 'manga',
      genres: [],
      cover: poster.original || poster.large || poster.medium || poster.small || ''
    });
  });
}
async function searchWikipediaByTerm(term, categoria, results){
  const json = await fetchJsonWithTimeout(`https://en.wikipedia.org/w/api.php?origin=*&action=query&generator=search&gsrsearch=${encodeURIComponent(term)}&gsrlimit=10&prop=pageimages|pageterms&piprop=original|thumbnail&pithumbsize=700&format=json`, 9000);
  const pages = ((json.query || {}).pages) || {};
  Object.values(pages).forEach(p => {
    const cover = (p.original && p.original.source) || (p.thumbnail && p.thumbnail.source) || '';
    const desc = p.terms && p.terms.description ? String(p.terms.description[0] || '') : '';
    const yearMatch = desc.match(/\b(19|20)\d{2}\b/);
    // Filtro leve: se buscando novel, ignore páginas com "film" na descrição, e vice-versa.
    const descLower = desc.toLowerCase();
    if(categoria === 'filme' && /\bnovel\b|\blight novel\b|\bmanga\b/.test(descLower) && !/\bfilm\b|\bmovie\b/.test(descLower)) return;
    if(categoria === 'novel' && /\bfilm\b|\bmovie\b/.test(descLower) && !/\bnovel\b|\bbook\b/.test(descLower)) return;
    addMetadataResult(results, {
      source: 'Wikipedia',
      title: p.title,
      titleOriginal: '',
      year: yearMatch ? Number(yearMatch[0]) : null,
      categoria,
      genres: [],
      cover
    });
  });
}
async function searchWikipediaMovieMetadata(query, results){
  // Duas passadas: com sufixo "film" (clássico) e sem sufixo (títulos únicos famosos).
  await Promise.allSettled([
    searchWikipediaByTerm(query + ' film', 'filme', results),
    searchWikipediaByTerm(query, 'filme', results)
  ]);
}
async function searchWikipediaNovelMetadata(query, results){
  await Promise.allSettled([
    searchWikipediaByTerm(query + ' novel', 'novel', results),
    searchWikipediaByTerm(query + ' light novel', 'novel', results),
    searchWikipediaByTerm(query, 'novel', results)
  ]);
}
async function searchWikipediaTvMetadata(query, categoria, results){
  const animated = categoria === 'desenho';
  await Promise.allSettled([
    searchWikipediaByTerm(query + (animated ? ' animated television series' : ' television series'), categoria, results),
    searchWikipediaByTerm(query + (animated ? ' cartoon' : ' TV series'), categoria, results),
    searchWikipediaByTerm(query, categoria, results)
  ]);
}
async function searchWikipediaBookMetadata(query, results){
  await Promise.allSettled([
    searchWikipediaByTerm(query + ' book', 'livro', results),
    searchWikipediaByTerm(query + ' novel', 'livro', results),
    searchWikipediaByTerm(query, 'livro', results)
  ]);
}
// ----------------------------------------------------------------------
// TMDb (The Movie Database) — /search/multi.
// Defina sua chave v3 em window.TMDB_API_KEY antes do app carregar, ou
// substitua a string abaixo. Sem chave, esta fonte é ignorada em silêncio.
// ----------------------------------------------------------------------
const TMDB_API_KEY = (typeof window !== 'undefined' && window.TMDB_API_KEY) || '';
async function searchTmdbMultiMetadata(query, results, categoria){
  if(!TMDB_API_KEY) return;
  const url = 'https://api.themoviedb.org/3/search/multi'
    + '?api_key=' + encodeURIComponent(TMDB_API_KEY)
    + '&language=pt-BR&include_adult=false'
    + '&query=' + encodeURIComponent(query);
  const json = await fetchJsonWithTimeout(url, 9000);
  (json.results || []).slice(0, 15).forEach(item => {
    if(!item || item.media_type === 'person') return;
    const isTv = item.media_type === 'tv';
    const title    = isTv ? (item.name || item.original_name) : (item.title || item.original_title);
    if(!title) return;
    const original = isTv ? (item.original_name  || '') : (item.original_title || '');
    const date     = isTv ? item.first_air_date : item.release_date;
    const isAnimation = Array.isArray(item.genre_ids) && item.genre_ids.indexOf(16) !== -1;
    // Filtra o tipo de mídia conforme a categoria pedida.
    if(categoria === 'filme'   && isTv)  return;
    if(categoria === 'serie'   && (!isTv || isAnimation)) return;
    if(categoria === 'desenho' && (!isTv || !isAnimation)) return;
    let cat = categoria;
    if(!cat) cat = isTv ? (isAnimation ? 'desenho' : 'serie') : 'filme';
    const cover = item.poster_path ? ('https://image.tmdb.org/t/p/w500' + item.poster_path) : '';
    addMetadataResult(results, {
      source: 'TMDb',
      title: title,
      titleOriginal: (original && original !== title) ? (sanitizeWesternTitle(original, title) || westernTitle(original) || original) : '',
      year: isoYear(date),
      categoria: cat,
      genres: [],
      cover: cover,
      synopsis: item.overview || '',
      externalId: item.id
    });
  });
}

// ----------------------------------------------------------------------
// Google Custom Search — fonte "web ampla" para complementar as APIs
// especializadas. Defina window.GOOGLE_CSE_KEY e window.GOOGLE_CSE_CX
// (Programmable Search Engine). Sem chaves, esta fonte é ignorada.
// ----------------------------------------------------------------------
const GOOGLE_CSE_KEY = (typeof window !== 'undefined' && window.GOOGLE_CSE_KEY) || '';
const GOOGLE_CSE_CX  = (typeof window !== 'undefined' && window.GOOGLE_CSE_CX)  || '';
async function searchGoogleCseMetadata(query, categoria, results){
  if(!GOOGLE_CSE_KEY || !GOOGLE_CSE_CX) return;
  const url = 'https://www.googleapis.com/customsearch/v1?num=10'
    + '&key=' + encodeURIComponent(GOOGLE_CSE_KEY)
    + '&cx='  + encodeURIComponent(GOOGLE_CSE_CX)
    + '&q='   + encodeURIComponent(query);
  const json = await fetchJsonWithTimeout(url, 9000);
  (json.items || []).forEach(item => {
    const pm = item.pagemap || {};
    const meta = (pm.metatags && pm.metatags[0]) || {};
    const cover = (pm.cse_image && pm.cse_image[0] && pm.cse_image[0].src)
      || meta['og:image']
      || (pm.cse_thumbnail && pm.cse_thumbnail[0] && pm.cse_thumbnail[0].src)
      || '';
    const rawTitle = meta['og:title'] || item.title || '';
    const title = rawTitle.replace(/\s*[\|\-–—]\s*(Wikipedia|IMDb|MyAnimeList|AniList|TMDB|Rotten Tomatoes).*$/i, '').trim();
    const desc  = meta['og:description'] || item.snippet || '';
    const ym = (title + ' ' + desc).match(/\b(19|20)\d{2}\b/);
    addMetadataResult(results, {
      source: 'Google',
      title,
      titleOriginal: '',
      year: ym ? Number(ym[0]) : null,
      categoria,
      genres: [],
      cover,
      synopsis: desc
    });
  });
}

async function buscarMetadadosOnline(query, categoria, subcategoria){
  // ------------------------------------------------------------------
  // Roteamento condicional de APIs conforme a categoria selecionada:
  //   - anime                            -> AniList (type ANIME)
  //   - manga | manhua | manhwa | novel  -> AniList (type MANGA)
  //   - filme | serie | desenho          -> TMDb /search/multi
  //   - livro                            -> Google Books + Open Library
  // O título é higienizado com cleanCoverQuery + encodeURIComponent
  // (o encode é feito dentro de cada helper ao montar a URL).
  // Todos os helpers já normalizam para o formato universal esperado
  // pelo app: {title, titleOriginal, year, cover, synopsis, categoria, id/externalId}.
  // ------------------------------------------------------------------
  const filmeSub = (categoria === 'filme') ? String(subcategoria||'').toLowerCase() : '';
  const key = cacheKey(categoria, (filmeSub ? filmeSub + ':' : '') + query);
  const cache = readOnlineCache();
  if(!isOnline() && cache.metadata[key]){
    state.lastMetadataResults = [cache.metadata[key]];
    return cache.metadata[key];
  }
  const results = [];
  const tasks = [];
  // Sanitização do título — cleanCoverQuery remove ruído, encodeURIComponent
  // é aplicado nas requisições.
  const cleanQuery = (cleanCoverQuery(query) || query || '').trim();

  // ------------------------------------------------------------------
  // Roteamento por CATEGORIA (o app conhece bem cada uma):
  //   anime   -> AniList (ANIME) + Jikan + Kitsu + Wikipedia (anime)
  //   manga   -> AniList (MANGA japonês) + Jikan + Kitsu + Wikipedia
  //   manhua  -> AniList (MANGA) + Wikipedia (manhua / chinese comic)
  //   manhwa  -> AniList (MANGA) + Wikipedia (manhwa / korean webtoon)
  //   novel   -> AniList (MANGA/light novel) + Google Books + OpenLibrary + Wikipedia
  //   livro   -> Google Books + OpenLibrary + Wikipedia (livro)
  //   serie   -> TMDb (TV live-action) + TVmaze + Wikipedia (série)
  //   desenho -> TMDb (TV animação ocidental) + TVmaze + Wikipedia (cartoon)
  //   filme   -> TMDb (movie) + iTunes + Wikipedia (film)
  //              subcategorias: cinema (live), desenho (animation), anime (AniList)
  // Google Custom Search entra em TODAS as categorias como sinal web amplo
  // (quando window.GOOGLE_CSE_KEY / CX estão definidos).
  // ------------------------------------------------------------------
  if(categoria === 'anime'){
    tasks.push(searchAniListMetadata(cleanQuery, 'ANIME', results));
    tasks.push(searchJikanMetadata(cleanQuery, 'anime', '', results, 'anime'));
    tasks.push(searchKitsuMetadata(cleanQuery, 'anime', results, 'anime'));
    tasks.push(searchWikipediaByTerm(cleanQuery + ' anime', 'anime', results));
  } else if(categoria === 'manga'){
    tasks.push(searchAniListMetadata(cleanQuery, 'MANGA', results));
    tasks.push(searchJikanMetadata(cleanQuery, 'manga', '', results, 'manga'));
    tasks.push(searchKitsuMetadata(cleanQuery, 'manga', results, 'manga'));
    tasks.push(searchWikipediaByTerm(cleanQuery + ' manga', 'manga', results));
  } else if(categoria === 'manhua'){
    tasks.push(searchAniListMetadata(cleanQuery, 'MANGA', results));
    tasks.push(searchJikanMetadata(cleanQuery, 'manga', '&type=manhua', results, 'manhua'));
    tasks.push(searchWikipediaByTerm(cleanQuery + ' manhua', 'manhua', results));
    tasks.push(searchWikipediaByTerm(cleanQuery + ' chinese comic', 'manhua', results));
  } else if(categoria === 'manhwa'){
    tasks.push(searchAniListMetadata(cleanQuery, 'MANGA', results));
    tasks.push(searchJikanMetadata(cleanQuery, 'manga', '&type=manhwa', results, 'manhwa'));
    tasks.push(searchWikipediaByTerm(cleanQuery + ' manhwa', 'manhwa', results));
    tasks.push(searchWikipediaByTerm(cleanQuery + ' korean webtoon', 'manhwa', results));
  } else if(categoria === 'novel'){
    tasks.push(searchAniListMetadata(cleanQuery, 'MANGA', results));
    tasks.push(searchJikanMetadata(cleanQuery, 'manga', '&type=lightnovel', results, 'novel'));
    tasks.push(searchGoogleBooksMetadata(cleanQuery, results, 'novel'));
    tasks.push(searchOpenLibraryMetadata(cleanQuery, results, 'novel'));
    tasks.push(searchWikipediaNovelMetadata(cleanQuery, results));
  } else if(categoria === 'livro'){
    tasks.push(searchGoogleBooksMetadata(cleanQuery, results, 'livro'));
    tasks.push(searchOpenLibraryMetadata(cleanQuery, results, 'livro'));
    tasks.push(searchWikipediaBookMetadata(cleanQuery, results));
  } else if(categoria === 'serie'){
    tasks.push(searchTmdbMultiMetadata(cleanQuery, results, 'serie'));
    tasks.push(searchTvMazeMetadata(cleanQuery, results, 'serie'));
    tasks.push(searchWikipediaTvMetadata(cleanQuery, 'serie', results));
  } else if(categoria === 'desenho'){
    // "Desenho" no app = desenho animado (cartoon / animação ocidental em TV).
    tasks.push(searchTmdbMultiMetadata(cleanQuery, results, 'desenho'));
    tasks.push(searchTvMazeMetadata(cleanQuery, results, 'desenho'));
    tasks.push(searchWikipediaTvMetadata(cleanQuery, 'desenho', results));
  } else if(categoria === 'filme'){
    if(filmeSub === 'anime'){
      // Filme > Anime: prioriza AniList/Jikan (filmes de animação japonesa).
      tasks.push(searchAniListMetadata(cleanQuery, 'ANIME', results));
      tasks.push(searchJikanMetadata(cleanQuery, 'anime', '&type=movie', results, 'filme'));
    }
    tasks.push(searchTmdbMultiMetadata(cleanQuery, results, 'filme'));
    tasks.push(searchItunesMovieMetadata(cleanQuery, results));
    tasks.push(searchWikipediaMovieMetadata(cleanQuery, results));
  } else {
    // Fallback amplo caso a categoria seja desconhecida.
    tasks.push(searchAniListMetadata(cleanQuery, 'ANIME', results));
    tasks.push(searchAniListMetadata(cleanQuery, 'MANGA', results));
    tasks.push(searchTmdbMultiMetadata(cleanQuery, results, null));
    tasks.push(searchGoogleBooksMetadata(cleanQuery, results));
    tasks.push(searchOpenLibraryMetadata(cleanQuery, results));
  }
  // Google Custom Search entra sempre — sinal web amplo, respeitando a categoria.
  tasks.push(searchGoogleCseMetadata(cleanQuery, categoria, results));

  if(!isOnline()){
    state.lastMetadataResults = cache.metadata[key] ? [cache.metadata[key]] : [];
    return cache.metadata[key] || null;
  }
  await Promise.allSettled(tasks);

  // Ranking: prioriza obras cuja categoria bate com a solicitada, depois
  // relevância do título; fonte especializada como desempate.
  const sourceRank = {
    AniList: 1, Jikan: 1, Kitsu: 2,
    TMDb: 1, TVmaze: 2, 'Apple Movies': 3,
    'Google Books': 1, OpenLibrary: 2,
    Wikipedia: 3, Google: 4
  };
  const sorted = results
    .filter(r => r.title)
    .sort((a,b) => {
      const catA = a.categoria === categoria ? 0 : (a.categoria ? 1 : 2);
      const catB = b.categoria === categoria ? 0 : (b.categoria ? 1 : 2);
      if(catA !== catB) return catA - catB;
      return metadataTitleScore(query, a.title) - metadataTitleScore(query, b.title)
        || (sourceRank[a.source] || 9) - (sourceRank[b.source] || 9);
    });
  // Dedupe por título+ano.
  const seen = new Set();
  const uniq = [];
  sorted.forEach(r => {
    const k = normalizeText(r.title) + '|' + (r.year || '');
    if(seen.has(k)) return;
    seen.add(k); uniq.push(r);
  });
  state.lastMetadataResults = uniq.slice(0, 20);
  const best = uniq[0] || null;
  if(best){
    // Fontes diferentes costumam devolver a mesma obra com campos distintos
    // (por exemplo, OpenLibrary traz capa/autor e Google Books traz editora/
    // páginas). Combina apenas correspondências muito próximas, sem trocar o
    // título escolhido nem misturar resultados de outra obra.
    const bestScore = metadataTitleScore(query, best.title);
    uniq.slice(1, 8).forEach(candidate => {
      const sameYear = !best.year || !candidate.year || Number(best.year) === Number(candidate.year);
      const closeTitle = metadataTitleScore(query, candidate.title) <= Math.min(3, bestScore + 2);
      if(!sameYear || !closeTitle || candidate.categoria !== best.categoria) return;
      if(!best.titleOriginal && candidate.titleOriginal) best.titleOriginal = candidate.titleOriginal;
      if(!best.year && candidate.year) best.year = candidate.year;
      if((!best.genres || !best.genres.length) && candidate.genres?.length) best.genres = candidate.genres.slice();
      else if(candidate.genres?.length) best.genres = Array.from(new Set([...(best.genres||[]), ...candidate.genres])).slice(0, 12);
      if(!best.cover && candidate.cover) best.cover = candidate.cover;
      if(!best.synopsis && candidate.synopsis) best.synopsis = candidate.synopsis;
      if(!best.authors?.length && candidate.authors?.length) best.authors = candidate.authors.slice();
      if(!best.publisher && candidate.publisher) best.publisher = candidate.publisher;
      if(!best.pagesTotal && candidate.pagesTotal) best.pagesTotal = candidate.pagesTotal;
      if(!best.durationMin && candidate.durationMin) best.durationMin = candidate.durationMin;
      if(!best.statusOficial && candidate.statusOficial) best.statusOficial = candidate.statusOficial;
    });
    cache.metadata[key] = best;
    writeOnlineCache(cache);
  }
  if(!best && cache.metadata[key]) state.lastMetadataResults = [cache.metadata[key]];
  return best || cache.metadata[key] || null;
}
function shouldAutoLookupMetadata(){
  const titulo = document.getElementById('f_titulo');
  if(!titulo || titulo.value.trim().length < 3) return false;
  const ano = document.getElementById('f_ano');
  const original = document.getElementById('f_titulo_original');
  const generos = document.getElementById('f_generos');
  return !(ano && ano.value) || !(original && original.value.trim()) || !(generos && generos.value.trim()) || !(state.cover.base64 || state.cover.url);
}
function mergeGenreText(current, incoming){
  const out = [];
  const seen = new Set();
  String(current || '').split(',').concat(incoming || []).forEach(g => {
    g = String(g || '').trim();
    if(!g) return;
    const k = normalizeLookupText(g);
    if(seen.has(k)) return;
    seen.add(k);
    out.push(g);
  });
  return out.slice(0, 12).join(', ');
}
function switchFormCategoryFromOnline(categoria){
  const catSelect = document.getElementById('f_categoria');
  if(!catSelect || !CATEGORY_META[categoria] || catSelect.value === categoria) return false;
  if(state.formUserChangedCategory || state.editId) return false;
  catSelect.value = categoria;
  catSelect.dataset.prevCategoria = categoria;
  state.builder = defaultBuilder();
  renderProgressBuilder(categoria);
  renderPrimarySubtypeField(categoria, null);
  renderBonusFields(categoria, null);
  prepareTextInputs(document.getElementById('entryForm'));
  toggleStatusFieldVisibility(categoria);
  toggleOfficialStatusFieldVisibility(categoria);
  toggleDateFieldsVisibility(categoria);
  return true;
}
function metadataOfficialStatus(value){
  const v = normalizeLookupText(value).replace(/\s+/g, '_');
  if(!v) return '';
  if(/cancel|aband/.test(v)) return 'cancelado';
  if(/hiato|on_hold|onhold/.test(v)) return 'hiato';
  if(/finished|complete|completed|ended|conclu/.test(v)) return 'concluido';
  if(/releasing|airing|publishing|ongoing|current|returning|running|in_production|in_development|planned|not_yet_released|em_andamento/.test(v)) return 'em_andamento';
  return '';
}
function selectOnlineOption(select, value){
  if(!select || value === undefined || value === null) return false;
  const wanted = normalizeLookupText(value);
  const option = Array.from(select.options || []).find(o => normalizeLookupText(o.value) === wanted || normalizeLookupText(o.textContent) === wanted);
  if(!option) return false;
  if(select.value === option.value) return false;
  select.value = option.value;
  return true;
}
function applyOnlineMetadata(meta, opts){
  if(!meta) return [];
  opts = opts || {};
  const overwrite = !!opts.overwrite;
  // Título principal preferimos ocidental (para leitura), mas se só houver CJK
  // mantemos para não perder o resultado.
  meta.title = sanitizeWesternTitle(meta.title, meta.titleOriginal) || String(meta.title || '').trim();
  // Título original também deve ser ocidental (romaji/latin) — sem CJK.
  meta.titleOriginal = sanitizeWesternTitle(meta.titleOriginal, meta.title) || String(meta.titleOriginal || '').trim();
  const changed = [];
  if(overwrite){
    // Escolher outro resultado é uma substituição de obra, não uma mesclagem.
    // Limpa somente dados geridos pela pesquisa; progresso, datas, nota,
    // favoritos e comentários continuam sendo dados pessoais do utilizador.
    ['f_titulo','f_titulo_original','f_ano','f_generos','f_capa_url_input','f_status_oficial',
     'bf_autor','bf_editora','bf_paginas_total','bf_duracao_min'].forEach(id => {
      const el = document.getElementById(id);
      if(el) el.value = '';
    });
    state.cover = {base64:null, url:''};
    updateCoverPreview();
  }
  const titulo = document.getElementById('f_titulo');
  const original = document.getElementById('f_titulo_original');
  const ano = document.getElementById('f_ano');
  const generos = document.getElementById('f_generos');
  // Uma nova escolha na pesquisa é uma ação explícita do utilizador: nesse
  // caso substitui também o título principal. Antes ele ficava preservado,
  // deixando a obra anterior misturada com os metadados da nova escolha.
  if(titulo && meta.title && (overwrite || !titulo.value.trim())){
    const nextTitle = String(meta.title).trim();
    if(nextTitle && titulo.value !== nextTitle){ titulo.value = nextTitle; changed.push('título'); }
  }
  if(meta.categoria && switchFormCategoryFromOnline(meta.categoria)){
    changed.push('categoria');
  }
  if(original && (overwrite || !original.value.trim()) && meta.titleOriginal){
    const nextOriginal = String(meta.titleOriginal).trim();
    if(nextOriginal && original.value !== nextOriginal){
      original.value = nextOriginal;
      changed.push('título original');
    }
  }
  if(ano && (overwrite || !ano.value) && meta.year){
    ano.value = meta.year;
    changed.push('ano');
  }
  if(generos && meta.genres && meta.genres.length){
    const before = generos.value;
    generos.value = mergeGenreText(overwrite ? '' : generos.value, meta.genres);
    if(generos.value !== before) changed.push('gêneros');
  }
  const official = document.getElementById('f_status_oficial');
  const officialValue = metadataOfficialStatus(meta.statusOficial || meta.status_oficial || meta.status);
  if(official && officialValue && (overwrite || !official.value) && selectOnlineOption(official, officialValue)) changed.push('status oficial');
  const subtype = document.getElementById('bf_subcategoria');
  if(subtype && meta.subcategoria && (overwrite || !subtype.value) && selectOnlineOption(subtype, meta.subcategoria)) changed.push('subcategoria');
  const novelType = document.getElementById('bf_tipo_novel');
  if(novelType && meta.tipo_novel && (overwrite || !novelType.value) && selectOnlineOption(novelType, meta.tipo_novel)) changed.push('subcategoria');
  const duration = document.getElementById('bf_duracao_min');
  if(duration && meta.durationMin && (overwrite || !duration.value)){ duration.value = Math.round(Number(meta.durationMin)); changed.push('duração'); }
  const pages = document.getElementById('bf_paginas_total');
  if(pages && meta.pagesTotal && (overwrite || !pages.value)){ pages.value = Math.round(Number(meta.pagesTotal)); changed.push('páginas'); }
  if(meta.cover && (overwrite || !(state.cover.base64 || state.cover.url))){
    state.cover = {base64:null, url: meta.cover};
    const coverInput = document.getElementById('f_capa_url_input');
    if(coverInput) coverInput.value = meta.cover;
    updateCoverPreview();
    changed.push('capa');
  }
  // Campos extra — só preenche se estiverem visíveis no formulário atual
  // (por ex.: autor/editora só existem em "livro").
  const autorEl = document.getElementById('bf_autor');
  if(autorEl && (overwrite || !autorEl.value.trim()) && meta.authors && meta.authors.length){
    autorEl.value = meta.authors.slice(0, 3).join(', ');
    changed.push('autor');
  }
  const editoraEl = document.getElementById('bf_editora');
  if(editoraEl && (overwrite || !editoraEl.value.trim()) && meta.publisher){
    editoraEl.value = String(meta.publisher).trim();
    changed.push('editora');
  }
  // Comentários: campo pessoal — a pesquisa automática NUNCA preenche
  // este campo (nem quando vazio). O utilizador escreve os seus próprios
  // comentários manualmente.
  updateAllInputClearButtons(document.getElementById('entryForm'));
  return changed;
}
async function buscarDadosOnlineFormulario(options){
  options = options || {};
  const tituloEl = document.getElementById('f_titulo');
  const catEl = document.getElementById('f_categoria');
  if(!tituloEl || !catEl) return;
  const titulo = tituloEl.value.trim();
  if(titulo.length < 3){
    if(options.force) setOnlineMetaStatus('Digite pelo menos 3 caracteres no título.', 'error');
    return;
  }
  if(!options.force && !shouldAutoLookupMetadata()) return;
  const token = ++onlineMetaRequestId;
  if(options.force){
    setOnlineMetaStatus('Buscando dados online...', '');
    setOnlineMetaSearching(true);
  }
  try{
    // Sempre pesquisa a 1ª temporada da obra — remove sufixos como "Temporada 2", "S2", "Season 3" etc.
    const tituloBase = cleanCoverQuery(titulo) || titulo;
    const categoriaSolicitada = catEl.value;
    // Para filmes, encaminha também a subcategoria (Cinema/Desenho/Anime) para
    // que o motor de busca escolha as APIs certas (filmes comuns × anime × desenho).
    const subEl = document.getElementById('bf_subcategoria');
    const subValue = subEl ? subEl.value : '';
    const meta = await buscarMetadadosOnline(tituloBase, catEl.value, subValue);
    if(token !== onlineMetaRequestId) return;
    const nResults = (state.lastMetadataResults || []).length;
    setOnlineMetaOptionsAvailable(nResults > 1 || (!!state.editId && !!titulo));
    if(options.openOptions && nResults > 0){
      openMetadataPicker();
    }
    if(!meta){
      if(options.force) setOnlineMetaStatus(isOnline() ? 'Nenhum dado online encontrado para esse título.' : 'Sem conexão e sem dados em cache para esse título.', 'error');
      return;
    }
    // A categoria escolhida no formulário é a autoridade final. Assim, uma
    // resposta de AniList/Jikan não transforma acidentalmente um manhwa em
    // mangá (ou um filme em anime) só por causa da classificação da fonte.
    meta.categoria = categoriaSolicitada;
    // Pesquisa manual (botão) -> overwrite:true para garantir que ano/nome
    // original/capa/gêneros sejam realmente aplicados mesmo que já tenham
    // valor parcial. Pesquisa automática (ao digitar) permanece não-destrutiva.
    const changed = applyOnlineMetadata(meta, {overwrite: !!options.force});
    const optHint = nResults > 1 ? ` (${nResults} opções — toque em "Ver outras opções" se não for esta)` : '';
    if(changed.length){
      setOnlineMetaStatus('Dados preenchidos: ' + changed.join(', ') + '.' + optHint, 'ok');
    } else if(options.force){
      setOnlineMetaStatus('Resultado sem dados novos para preencher.' + optHint, 'ok');
    }
  }catch(e){
    if(options.force) setOnlineMetaStatus('Não foi possível buscar dados online agora.', 'error');
  }finally{
    if(token === onlineMetaRequestId) setOnlineMetaSearching(false);
  }
}
function toggleStatusFieldVisibility(categoria){
  document.getElementById('f_status_wrap').style.display = categoria === 'filme' ? 'none' : '';
}
function toggleOfficialStatusFieldVisibility(categoria){
  const wrap = document.getElementById('f_status_oficial_wrap');
  if(wrap) wrap.style.display = temStatusOficial(categoria) ? '' : 'none';
}
function toggleDateFieldsVisibility(categoria){
  const hidden = categoria === 'filme' ? 'none' : '';
  document.getElementById('dataInicioField').style.display = hidden;
  document.getElementById('dataFimField').style.display = hidden;
}
function renderEntrySourceFields(values){
  const container = document.getElementById('entrySourcesContainer');
  if(!container) return;
  const sources = Array.isArray(values) ? values.filter(value => typeof value === 'string' && value.trim()) : [];
  container.innerHTML = sources.map(value => `
    <div class="entry-source-row">
      <input type="text" name="entryFonte" maxlength="120" lang="pt-BR" inputmode="text" autocomplete="off" autocorrect="on" autocapitalize="sentences" spellcheck="true" aria-label="Fonte" value="${escapeHtml(value.trim())}">
      <button type="button" class="icon-btn danger" data-remove-entry-source aria-label="Remover fonte"><svg class="icon"><use href="#i-trash"/></svg></button>
    </div>
  `).join('');
  prepareTextInputs(container);
}
function openFormModal(id){
  state.editId = id;
  state.formUserChangedCategory = false;
  const entry = id ? state.entries.find(e=>e.id===id) : null;
  if(entry) pushHistorico(entry.id);
  state.tags = entry ? (entry.generos||[]).slice() : [];
  state.builder = defaultBuilder();
  state.cover = {base64:null, url:''};

  document.getElementById('formModalTitle').textContent = entry ? 'Editar registro' : 'Novo registro';
  document.getElementById('formSubmitBtn').textContent = entry ? 'Atualizar registro' : 'Salvar registro';

  const catSelect = document.getElementById('f_categoria');
  catSelect.innerHTML = CATEGORY_ORDER.map(c => `<option value="${c}">${CATEGORY_META[c].plural}</option>`).join('');
  const categoria = entry ? entry.categoria : (state.categoriaAtiva!=='todos' ? state.categoriaAtiva : 'anime');
  catSelect.value = categoria;
  catSelect.dataset.prevCategoria = categoria;

  document.getElementById('f_status').innerHTML = statusOptionsHtml(entry ? entry.status : 'pretendo_ver');
  toggleStatusFieldVisibility(categoria);
  document.getElementById('f_status_oficial').innerHTML = officialStatusOptionsHtml(entry ? (entry.status_oficial||'') : '');
  toggleOfficialStatusFieldVisibility(categoria);
  toggleDateFieldsVisibility(categoria);

  document.getElementById('f_titulo').value = entry ? entry.titulo : '';
  document.getElementById('f_titulo_original').value = entry ? (entry.titulo_original||'') : '';
  document.getElementById('f_ano').value = entry && entry.ano ? entry.ano : '';
  document.getElementById('f_favorito').checked = entry ? !!entry.favorito : false;
  document.getElementById('f_data_inicio').value = entry ? (entry.data_inicio||'') : '';
  document.getElementById('f_data_fim').value = entry ? (entry.data_fim||'') : '';
  document.getElementById('f_comentario').value = entry ? (entry.comentario||'') : '';
  renderEntrySourceFields(entry && Array.isArray(entry.fontes) ? entry.fontes : []);
  { const gi = document.getElementById('f_generos'); if(gi){ gi.value = (entry && entry.generos||[]).join(', '); closeGenreListMode(); } }
  document.getElementById('f_nota_range').value = entry && typeof entry.nota === 'number' ? entry.nota : 0;
  document.getElementById('f_nota_range').dataset.cleared = (entry && typeof entry.nota === 'number') ? '0' : '1';
  updateNotaDisplay();
  clearFormErrors();

  if(entry){
    if(CATEGORIAS_COM_TEMPORADAS.includes(entry.categoria) && entry.temporadas && entry.temporadas.length){
      state.builder.temporadas = entry.temporadas.map((t,i,arr) => ({status:t.status, episodios:t.episodios, extras:(t.extras||[]).map(x=>Object.assign({},x)), aberta: false}));
    }
    if(entry.categoria === 'anime'){
      state.builder.extras_independentes = (entry.extras_independentes||[]).map(x=>Object.assign({},x));
    }
    if(entry.categoria === 'novel' && entry.volumes && entry.volumes.length){
      state.builder.volumes = entry.volumes.map(v => ({status:v.status, nome:v.nome||'', capitulos:v.capitulos||0, capitulos_lista:(v.capitulos_lista||[]).map(c=>Object.assign({},c)), aberta:false}));
    }
    if(['manga','manhua','manhwa'].includes(entry.categoria)){
      state.builder.progresso_simples = entry.progresso_simples ?? 0;
    }
    state.cover = {base64: entry.capa_base64 || null, url: entry.capa_url || ''};
  }

  renderPrimarySubtypeField(categoria, entry);
  renderProgressBuilder(categoria);
  renderBonusFields(categoria, entry);
  prepareTextInputs(document.getElementById('entryForm'));
  document.getElementById('f_capa_upload').value = '';
  document.getElementById('f_capa_url_input').value = state.cover.url || '';
  document.getElementById('coverSearchGrid').hidden = true;
  document.getElementById('coverSearchGrid').innerHTML = '';
  setOnlineMetaStatus('', '');
  state.lastMetadataResults = [];
  // Em uma edição, o botão permanece disponível antes da nova consulta;
  // o clique fará a pesquisa online atualizada.
  setOnlineMetaOptionsAvailable(!!entry && !!entry.titulo);
  setOnlineMetaSearching(false);
  updateCoverPreview();

  document.body.classList.add('form-modal-open');
  document.getElementById('formModalBackdrop').hidden = false;
  const modalBody = document.querySelector('#formModalBackdrop .modal-body');
  if(modalBody) modalBody.scrollTop = 0;
}
function closeFormModal(){
  // REGRA: ao fechar o modal, garantir que o modo lista de gêneros é
  // totalmente desmontado (readonly removido, botão resetado, sugestões
  // fechadas) e o teclado personalizado escondido — senão o próximo toque
  // parece "activar" o campo de gêneros.
  try{ closeGenreListMode(); }catch(_){ }
  try{ closeGenreSuggestBox(); }catch(_){ }
  if (window.__ckb && typeof window.__ckb.hide === 'function') { try{ window.__ckb.hide(); }catch(_){ } }
  const gi = document.getElementById('f_generos');
  if(gi){ try{ gi.blur(); }catch(_){ } }
  document.getElementById('formModalBackdrop').hidden = true;
  document.body.classList.remove('form-modal-open');
  cancelOnlineMetadataSearch();
  state.editId = null; state.tags = []; state.builder = null; state.cover = {base64:null, url:''}; state.formUserChangedCategory = false;
}
function resetCadastroForm(){
  const form = document.getElementById('entryForm');
  if(!form) return;
  cancelOnlineMetadataSearch();
  clearFormErrors();
  const categoriaEl = document.getElementById('f_categoria');
  const categoria = categoriaEl ? (categoriaEl.value || 'anime') : 'anime';
  state.tags = [];
  state.builder = defaultBuilder();
  state.cover = {base64:null, url:''};
  renderEntrySourceFields([]);
  const statusEl = document.getElementById('f_status');
  if(statusEl) statusEl.innerHTML = statusOptionsHtml('pretendo_ver');
  toggleStatusFieldVisibility(categoria);
  const statusOficialEl = document.getElementById('f_status_oficial');
  if(statusOficialEl) statusOficialEl.innerHTML = officialStatusOptionsHtml('');
  toggleOfficialStatusFieldVisibility(categoria);
  toggleDateFieldsVisibility(categoria);
  // Nota: 'f_titulo' foi removido propositalmente — o reset preserva o campo do título.
  ['f_titulo_original','f_ano','f_generos','f_data_inicio','f_data_fim','f_comentario','f_capa_url_input'].forEach(id => {
    const el = document.getElementById(id);
    if(el) el.value = '';
  });
  document.querySelectorAll('#entryForm [id^="bf_"]').forEach(el => { el.value = ''; });
  const fav = document.getElementById('f_favorito');
  if(fav) fav.checked = false;
  const nota = document.getElementById('f_nota_range');
  if(nota){ nota.value = 0; nota.dataset.cleared = '1'; }
  updateNotaDisplay();
  renderPrimarySubtypeField(categoria, null);
  renderProgressBuilder(categoria);
  renderBonusFields(categoria, null);
  prepareTextInputs(form);
  updateAllInputClearButtons(form);
  const upload = document.getElementById('f_capa_upload');
  if(upload) upload.value = '';
  const coverGrid = document.getElementById('coverSearchGrid');
  if(coverGrid){ coverGrid.hidden = true; coverGrid.innerHTML = ''; }
  setOnlineMetaStatus('', ''); setOnlineMetaOptionsAvailable(false); state.lastMetadataResults = [];
  setOnlineMetaSearching(false);
  updateCoverPreview();
}

function collectFormData(){
  const categoria = document.getElementById('f_categoria').value;
  const data = {
    categoria,
    titulo: document.getElementById('f_titulo').value.trim(),
    titulo_original: document.getElementById('f_titulo_original').value.trim(),
    ano: document.getElementById('f_ano').value ? Number(document.getElementById('f_ano').value) : null,
    status: document.getElementById('f_status').value,
    status_oficial: (temStatusOficial(categoria) && document.getElementById('f_status_oficial')) ? (document.getElementById('f_status_oficial').value || null) : null,
    generos: (function(){ const gi = document.getElementById('f_generos'); const raw = gi ? gi.value : ''; const arr = raw.split(',').map(s=>s.trim()).filter(Boolean); const seen = new Set(); const out = []; arr.forEach(g=>{ const k=g.toLowerCase(); if(!seen.has(k)){ seen.add(k); out.push(g); } }); return out; })(),
    fontes: (function(){ const fields = document.querySelectorAll('#entrySourcesContainer input[name="entryFonte"]'); const seen = new Set(); const out = []; fields.forEach(el => { const value = el.value.trim(); const key = value.toLocaleLowerCase('pt-BR'); if(value && !seen.has(key)){ seen.add(key); out.push(value); } }); return out; })(),
    data_inicio: document.getElementById('f_data_inicio').value || null,
    data_fim: document.getElementById('f_data_fim').value || null,
    favorito: document.getElementById('f_favorito').checked,
    comentario: document.getElementById('f_comentario').value.trim(),
    nota: document.getElementById('f_nota_range').dataset.cleared === '1' ? null : Number(document.getElementById('f_nota_range').value),
    capa_base64: state.cover.base64 || null,
    capa_url: state.cover.url || (document.getElementById('f_capa_url_input').value.trim() || '')
  };
  if(data.capa_base64) data.capa_url = '';
  // Nenhuma capa própria foi definida (nem upload, nem URL colada, nem
  // resultado da busca online escolhido): usa a capa padrão em vez de
  // bloquear o salvamento, para o usuário poder trocar depois com calma.
  if(!data.capa_base64 && !data.capa_url){
    data.capa_base64 = DEFAULT_COVER_PLACEHOLDER;
  }
  (BONUS_FIELDS[categoria]||[]).forEach(f => {
    const el = document.getElementById('bf_'+f.key);
    if(!el) return;
    data[f.key] = f.type === 'number' ? (el.value === '' ? null : Number(el.value)) : el.value.trim();
  });
  if(CATEGORIAS_COM_TEMPORADAS.includes(categoria)){
    const mapExtra = ex => {
      const out = {tipo: ex.tipo, nome: (ex.nome||'').trim()};
      if(extraAceitaQuantidade(ex) && ex.quantidade != null && ex.quantidade > 0) out.quantidade = extraQuantidade(ex);
      return out;
    };
    const validExtra = ex => (ex.nome && ex.nome.trim()) || (extraAceitaQuantidade(ex) && ex.quantidade != null && ex.quantidade > 0);
    const includeExtras = (categoria === 'anime' || categoria === 'desenho');
    data.temporadas = state.builder.temporadas.map((s,i) => ({numero:i+1, status:s.status, episodios:Number(s.episodios)||0, extras: includeExtras ? (s.extras||[]).filter(validExtra).map(mapExtra) : []}));
    if(includeExtras) data.extras_independentes = (state.builder.extras_independentes||[]).filter(validExtra).map(mapExtra);
  } else if(categoria === 'novel'){
    const validCap = c => (c.nome && c.nome.trim()) || (Number(c.quantidade) > 0) || (c.pagina && Number(c.pagina) > 0);
    data.volumes = state.builder.volumes.map((v,i) => {
      const lista = (v.capitulos_lista||[]).filter(validCap).map(c => { const cd={nome:(c.nome||'').trim(), quantidade: Number(c.quantidade)>0 ? Math.floor(Number(c.quantidade)) : null}; if(c.pagina!=null&&Number(c.pagina)>0) cd.pagina=Math.floor(Number(c.pagina)); return cd; });
      // Conta apenas capítulos numéricos (capítulos nomeados como Prólogo/Epílogo não somam ao total)
      const capitulos = lista.length ? lista.filter(c=>!(c.nome&&c.nome.trim())&&Number(c.quantidade)>0).reduce((s,c)=>s+Math.floor(Number(c.quantidade)),0) : (Number(v.capitulos)||0);
      const vol = {numero:i+1, status:v.status, capitulos, capitulos_lista: lista.length ? lista : undefined};
      if(v.nome && v.nome.trim()) vol.nome = v.nome.trim();
      return vol;
    });
  } else if(['manga','manhua','manhwa'].includes(categoria) || categoria === 'livro'){
    const el = document.getElementById('f_progresso_simples');
    data.progresso_simples = el ? (Number(el.value)||0) : 0;
  }
  return data;
}
function applyFormErrors(errors){
  clearFormErrors();
  const map = {titulo:'err_titulo', categoria:'err_categoria', status:'err_status', status_oficial:'err_status_oficial', ano:'err_ano', datas:'err_datas', nota:'err_nota', detalhes:'err_detalhes', capa:'err_capa', temporadas:'err_temporadas', volumes:'err_volumes', progresso_simples:'err_progresso_simples'};
  Object.keys(errors).forEach(key => {
    const elId = map[key];
    const el = elId ? document.getElementById(elId) : null;
    if(el) el.textContent = errors[key];
  });
}
async function handleFormSubmit(e){
  e.preventDefault();
  await cacheCurrentCoverForOffline();
  const data = collectFormData();
  const {valid, errors} = validateEntry(data);
  if(!valid){
    applyFormErrors(errors);
    const firstKey = Object.keys(errors)[0];
    showToast('error', errors[firstKey] || 'Corrija os campos destacados antes de salvar.');
    return;
  }
  // Verifica duplicados tanto ao criar como ao editar (ex.: renomear um
  // registro existente para um título que já pertence a outro item).
  if(checkDuplicate(data.titulo, data.categoria, state.editId || null, data.titulo_original)){
    pendingDuplicateSubmit = data;
    openConfirmDuplicate();
    return;
  }
  saveEntry(data);
}
function saveEntry(data){
  const now = Date.now();
  const editScrollSnapshot = state.editId ? getActiveScrollSnapshot() : null;
  prepareScrollBeforeEntryUpdate(editScrollSnapshot);
  let activityEntry = null;
  let activityAction = null;
  let activityDetail = '';
  let activityBefore = null;
  let activityTitleBefore = '';
  if(state.editId){
    const idx = state.entries.findIndex(e => e.id === state.editId);
    if(idx > -1){
      const previous = normalizeEntryEditDates(state.entries[idx]);
      activityBefore = cloneActivitySnapshot(previous);
      activityTitleBefore = previous.titulo || '';
      const merged = applyProgressEditDates(previous, Object.assign({}, previous, data), now, false);
      const obraChanged = relevantEntrySignature(previous, false) !== relevantEntrySignature(merged, false);
      const commentsChanged = String(previous.comentario || '') !== String(data.comentario || '');
      state.entries[idx] = Object.assign({}, merged, {
        atualizado_em: now,
        ultima_edicao_obra: obraChanged ? now : (previous.ultima_edicao_obra || now),
        ultima_edicao_comentarios: commentsChanged ? now : (previous.ultima_edicao_comentarios || now)
      });
      activityEntry = state.entries[idx];
      activityAction = 'updated';
      const changedLabels = describeActivityChanges(activityBefore, activityEntry).map(change => change.label);
      activityDetail = changedLabels.length
        ? `Campos alterados: ${changedLabels.slice(0, 12).join(', ')}${changedLabels.length > 12 ? '…' : ''}.`
        : 'Salvou o registro novamente sem alterar os dados.';
    }
    showToast('success', 'Registro atualizado.');
  } else {
    const newEntry = applyProgressEditDates(null, Object.assign({id: uuid(), criado_em: now, atualizado_em: now, ultima_edicao_obra: now, ultima_edicao_comentarios: now}, data), now, true);
    state.entries.push(newEntry);
    activityEntry = newEntry;
    activityAction = 'created';
    activityDetail = 'Obra adicionada ao acervo.';
    showToast('success', 'Registro adicionado ao acervo.');
  }
  if(activityEntry && activityAction){
    recordActivity(activityAction, 'obra', activityEntry.titulo, activityDetail, {
      targetId: activityEntry.id,
      categoria: activityEntry.categoria,
      titleBefore:activityTitleBefore,
      beforeSnapshot:activityBefore,
      afterSnapshot:cloneActivitySnapshot(activityEntry)
    });
  }
  persistEntries(); closeFormModal(); renderMain();
  if(typeof listPageState !== 'undefined' && listPageState.isOpen){
    renderListPage();
    // A página autónoma é renderizada de forma síncrona; repõe já a posição
    // para não depender de dois frames posteriores nem mostrar um salto.
    restorePendingListPageScroll();
  }
  restoreScrollAfterEntryUpdate(editScrollSnapshot);
}

/* ===================== DETAIL MODAL ===================== */
function openDetailModal(id){
  const e = state.entries.find(x => x.id === id);
  if(!e) return;
  state.activitySnapshot = null;
  recordActivity('viewed', 'obra', e.titulo, 'Acessou os detalhes da obra.', {
    targetId: e.id,
    categoria: e.categoria
  });
  const scrollSnapshot = getActiveScrollSnapshot();
  state.obraDetalheReturn = {
    view: state.view,
    categoriaAtiva: state.categoriaAtiva,
    filmeSubAtivo: state.filmeSubAtivo,
    novelSubAtivo: state.novelSubAtivo,
    listaAtivaId: state.listaAtivaId,
    listPageOpen: (typeof listPageState !== 'undefined' && listPageState.isOpen),
    scrollY: scrollSnapshot.scrollY,
    scrollContext: scrollSnapshot,
    fromCardId: id
  };
  state.obraDetalheId = id;
  state.view = 'obra-detalhe';
  pushHistorico(id);
  renderMain();
}
function closeDetailModal(){ document.getElementById('detailModalBackdrop').hidden = true; }

/* ===================== CONFIRM MODAL ===================== */
function openConfirmDelete(id){
  const e = state.entries.find(x => x.id === id);
  if(!e) return;
  pendingDeleteId = id;
  document.getElementById('confirmModalTitle').textContent = 'Remover registro';
  document.getElementById('confirmModalText').innerHTML = `Remover <strong>${escapeHtml(e.titulo)}</strong> do acervo?`;
  document.getElementById('confirmModalOk').textContent = 'Remover';
  document.getElementById('confirmModalOk').onclick = () => {
    const delId = pendingDeleteId;
    const removedEntry = state.entries.find(x => x.id === delId);
    // Guarda uma cópia das listas afetadas (as que continham esta obra) para
    // poder restaurá-las exatamente como estavam se o usuário desfizer —
    // inclusive se alguma delas acabar removida por ficar vazia.
    const affectedListas = (state.listas||[]).filter(l => Array.isArray(l.obraIds) && l.obraIds.includes(delId)).map(l => JSON.parse(JSON.stringify(l)));
    state.entries = state.entries.filter(x => x.id !== delId);
    // Cascata: tira a obra de todas as listas personalizadas
    (state.listas||[]).forEach(lista => { if(Array.isArray(lista.obraIds)) lista.obraIds = lista.obraIds.filter(oid => oid !== delId); });
    cleanupEmptyCustomLists();
      recordEntriesActivity('deleted', removedEntry ? [removedEntry] : [], 'Obra apagada do acervo.');
    persistEntries(); persistListas(); closeConfirmModal(); renderMain();
    showUndoToast('Registro removido.', () => {
      if(removedEntry && !state.entries.some(x => x.id === removedEntry.id)) state.entries.push(removedEntry);
      recordEntriesActivity('restored', removedEntry ? [removedEntry] : [], 'Obra restaurada após desfazer.');
      affectedListas.forEach(snapLista => {
        const lista = state.listas.find(l => l.id === snapLista.id);
        if(lista){ if(!lista.obraIds.includes(delId)) lista.obraIds.push(delId); }
        else state.listas.push(snapLista);
      });
      persistEntries(); persistListas(); renderMain();
      showToast('success', 'Registro restaurado.');
    });
  };
  document.getElementById('confirmModalBackdrop').hidden = false;
}
function openConfirmDuplicate(){
  document.getElementById('confirmModalTitle').textContent = 'Título já existe';
  document.getElementById('confirmModalText').innerHTML = `Já existe um item com o título <strong>${escapeHtml(pendingDuplicateSubmit.titulo)}</strong> nessa categoria. Adicionar mesmo assim?`;
  document.getElementById('confirmModalOk').textContent = 'Adicionar mesmo assim';
  document.getElementById('confirmModalOk').onclick = () => {
    const data = pendingDuplicateSubmit; pendingDuplicateSubmit = null;
    closeConfirmModal(); saveEntry(data);
  };
  document.getElementById('confirmModalBackdrop').hidden = false;
}
function openConfirmWipe(){
  document.getElementById('confirmModalTitle').textContent = 'Limpar acervo';
  document.getElementById('confirmModalText').innerHTML = `Remover <strong>todos os ${state.entries.length} itens</strong> do acervo?`;
  document.getElementById('confirmModalOk').textContent = 'Limpar tudo';
  document.getElementById('confirmModalOk').onclick = () => {
    const removedEntries = state.entries.slice();
    // Guarda as listas personalizadas inteiras (serão removidas) e uma cópia
    // das listas padrão (só os obraIds serão zerados) para poder restaurar
    // tudo exatamente como estava.
    const removedCustomListas = (state.listas||[]).filter(l => !l.defaultCat).map(l => JSON.parse(JSON.stringify(l)));
    const defaultListasBefore = (state.listas||[]).filter(l => l.defaultCat).map(l => JSON.parse(JSON.stringify(l)));
    state.entries = [];
    // Limpar o acervo também remove as listas personalizadas — só as
    // listas padrão (por categoria) permanecem, agora vazias.
    state.listas = (state.listas||[]).filter(l => l.defaultCat);
    state.listas.forEach(l => { l.obraIds = []; });
    exitSelectionMode();
    recordEntriesActivity('deleted', removedEntries, 'Obra apagada ao limpar o acervo.');
    recordActivity('wiped', 'acervo', 'Todo o acervo', `${removedEntries.length} obras removidas e listas personalizadas limpas.`);
    persistEntries(); persistListas(); closeConfirmModal(); renderMain();
    showUndoToast('Acervo limpo.', () => {
      state.entries = removedEntries;
      defaultListasBefore.forEach(snap => {
        const lista = state.listas.find(l => l.id === snap.id);
        if(lista) lista.obraIds = snap.obraIds;
      });
      removedCustomListas.forEach(snap => { if(!state.listas.some(l => l.id === snap.id)) state.listas.push(snap); });
      recordEntriesActivity('restored', removedEntries, 'Obra restaurada ao desfazer a limpeza do acervo.');
      recordActivity('restored', 'acervo', 'Todo o acervo', 'Acervo restaurado após desfazer.');
      persistEntries(); persistListas(); renderMain();
      showToast('success', 'Acervo restaurado.');
    }, 8000);
  };
  document.getElementById('confirmModalBackdrop').hidden = false;
}
function openConfirmModal(title, messageHtml, onConfirm){
  document.getElementById('confirmModalTitle').textContent = title;
  document.getElementById('confirmModalText').innerHTML = messageHtml;
  document.getElementById('confirmModalOk').textContent = 'Confirmar';
  document.getElementById('confirmModalOk').onclick = () => {
    if(typeof onConfirm === 'function') onConfirm();
    closeConfirmModal();
  };
  document.getElementById('confirmModalBackdrop').hidden = false;
}
function closeConfirmModal(){ document.getElementById('confirmModalBackdrop').hidden = true; pendingDeleteId = null; pendingDuplicateSubmit = null; pendingDeleteListId = null; }

/* ===================== IMPORT / EXPORT ===================== */
/* ===================== PREFERÊNCIAS: TEMA, MOVIMENTO, LEMBRETES ===================== */
function loadPrefs(){
  const defaults = {tema:'escuro', reduceMotion:false, reminderIntervalDays:BACKUP_REMINDER_INTERVAL_DAYS, defaultCategoria:'ultima'};
  if(!LOCAL_STORAGE_AVAILABLE) return defaults;
  try{
    const raw = window.localStorage.getItem(PREFS_STORAGE_KEY);
    if(!raw) return defaults;
    const parsed = JSON.parse(raw);
    let reminderIntervalDays = BACKUP_REMINDER_INTERVAL_DAYS;
    if(typeof parsed.reminderIntervalDays === 'number') reminderIntervalDays = parsed.reminderIntervalDays;
    else if(parsed.backupReminder === false) reminderIntervalDays = 0; // migração da versão antiga (checkbox on/off)
    return {
      tema: parsed.tema === 'claro' ? 'claro' : 'escuro',
      reduceMotion: !!parsed.reduceMotion,
      reminderIntervalDays: reminderIntervalDays,
      defaultCategoria: (parsed.defaultCategoria === 'ultima' || parsed.defaultCategoria === 'todos' || CATEGORY_META[parsed.defaultCategoria]) ? parsed.defaultCategoria : 'ultima'
    };
  }catch(e){ return defaults; }
}
function savePrefs(prefs){
  if(!LOCAL_STORAGE_AVAILABLE) return;
  try{ window.localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(prefs)); }catch(e){}
}
function applyPrefs(prefs){
  document.documentElement.setAttribute('data-theme', prefs.tema);
  document.documentElement.classList.toggle('reduce-motion', !!prefs.reduceMotion);
  const meta = document.querySelector('meta[name="theme-color"]');
  if(meta) meta.setAttribute('content', prefs.tema === 'claro' ? '#f5f1e8' : '#5cc8bd');
}
let userPrefs = loadPrefs();
applyPrefs(userPrefs);

// Mostra a mensagem tanto no toast padrão quanto, se o modal de preferências
// estiver aberto, diretamente dentro dele — para o usuário ver o resultado
// de exportar/importar/copiar sem precisar procurar o toast.
function prefsNotify(type, message){
  showToast(type, message);
  const modal = document.getElementById('prefsModalBackdrop');
  if(modal && !modal.hidden){
    const status = document.getElementById('prefsBackupStatus');
    if(status){
      status.textContent = message;
      status.className = 'prefs-status prefs-status-' + type;
      status.hidden = false;
    }
  }
}
function passwordStatusMsg(type, message){
  // Os erros da troca de senha aparecem no próprio cartão, além do toast,
  // para não desaparecerem enquanto o formulário continua aberto.
  showToast(type, message);
  const status = document.getElementById('prefsChangePasswordStatus');
  if(status){
    status.textContent = message;
    status.className = 'prefs-status prefs-status-' + type;
    status.hidden = false;
  }
}
function pinStatusMsg(type, message){
  const status = document.getElementById('prefsPinStatus');
  if(!status) return;
  status.textContent = message;
  status.className = 'prefs-status prefs-status-' + type;
  status.hidden = false;
}
const DEFAULT_PROFILE_AVATAR = './icons/default-avatar.svg';
function profileDefaults(){
  const account = (typeof findAccountById === 'function') ? findAccountById(getActiveAccountId()) : null;
  return { nome: account && account.usuario ? account.usuario : '', foto:null, avatar:DEFAULT_PROFILE_AVATAR };
}
function normalizeStoredProfile(parsed){
  const defaults = profileDefaults();
  if(!parsed || typeof parsed !== 'object') return defaults;
  return {
    nome: typeof parsed.nome === 'string' ? parsed.nome.slice(0, 80) : defaults.nome,
    foto: typeof parsed.foto === 'string' && parsed.foto.startsWith('data:image') ? parsed.foto : null,
    avatar: DEFAULT_PROFILE_AVATAR
  };
}
function loadProfile(){
  // Sem e-mail nem qualquer forma de recuperação online: o perfil é 100%
  // local. Se um perfil salvo antes ainda tiver um e-mail gravado, ele é
  // ignorado aqui e some assim que o perfil for salvo de novo.
  // O perfil é isolado por conta (nsKey), então cada usuário vê só o seu.
  const defaults = profileDefaults();
  if(!LOCAL_STORAGE_AVAILABLE) return defaults;
  try{
    const raw = window.localStorage.getItem(nsKey(PROFILE_STORAGE_KEY));
    if(!raw) return defaults;
    return normalizeStoredProfile(JSON.parse(raw));
  }catch(_){ return defaults; }
}
async function loadPersistedProfile(){
  const key = nsKey(PROFILE_STORAGE_KEY);
  const localSaved = readLocalStorageJson(key, null);
  let indexedDbSaved = null;
  const raw = await idbGet(key);
  if(raw){
    try{ indexedDbSaved = typeof raw === 'string' ? JSON.parse(raw) : raw; }catch(_){}
  }
  const localSavedAt = Number(localSaved && localSaved.savedAt) || 0;
  const indexedDbSavedAt = Number(indexedDbSaved && indexedDbSaved.savedAt) || 0;
  _profileLastSavedAt = Math.max(_profileLastSavedAt, localSavedAt, indexedDbSavedAt);
  const saved = indexedDbSaved && indexedDbSavedAt > localSavedAt
    ? indexedDbSaved
    : (localSaved || indexedDbSaved);
  return saved && typeof saved === 'object' ? normalizeStoredProfile(saved) : loadProfile();
}
let _profileWriteQueue = Promise.resolve(false);
let _profileLastSavedAt = 0;
function saveProfile(profile){
  const key = nsKey(PROFILE_STORAGE_KEY);
  const savedAt = Math.max(Date.now(), _profileLastSavedAt + 1);
  _profileLastSavedAt = savedAt;
  const text = JSON.stringify(Object.assign({}, profile, { savedAt }));
  let localStorageSaved = false;
  if(LOCAL_STORAGE_AVAILABLE){
    try{
      // Grava a cópia síncrona primeiro, para que um recarregamento imediato
      // não perca a foto enquanto o IndexedDB conclui a gravação.
      window.localStorage.setItem(key, text);
      localStorageSaved = true;
    }catch(_){
      // Não apagar a versão anterior: uma quota cheia não deve destruir o perfil.
    }
  }
  refreshHeaderProfile();
  _profileWriteQueue = _profileWriteQueue
    .catch(() => false)
    .then(() => idbSet(key, text))
    .catch(() => false);
  return _profileWriteQueue.then(indexedDbSaved => !!indexedDbSaved || localStorageSaved);
}
let userProfile = loadProfile();
function profileAvatarSrc(profile){
  if(profile && profile.foto) return profile.foto;
  return DEFAULT_PROFILE_AVATAR;
}
function refreshProfileModal(){
  const name = document.getElementById('profileName');
  const conta = readAccount();
  if(name) name.value = userProfile.nome || (conta && conta.usuario) || '';
  renderProfileAvatarPreview(userProfile.foto || null, userProfile.avatar);
  document.getElementById('profileStatObras').textContent = String(state.entries.length);
  document.getElementById('profileStatListas').textContent = String((state.listas||[]).length);
  document.getElementById('profileStatSince').textContent = conta && conta.criado_em ? new Date(conta.criado_em).toLocaleDateString('pt-BR') : '—';
}
// Mostra o nome e a foto de quem entrou no botão de perfil do cabeçalho
// (dashboard), sem alterar o resto do layout do cabeçalho.
function refreshHeaderProfile(){
  const img = document.getElementById('headerAvatarImg');
  const initial = document.getElementById('headerAvatarInitial');
  const nameEl = document.getElementById('headerProfileName');
  if(!img || !initial || !nameEl) return;
  const conta = (typeof readAccount === 'function') ? readAccount() : null;
  const displayName = (userProfile && userProfile.nome) ? userProfile.nome : (conta ? conta.usuario : '');
  nameEl.textContent = displayName || '';
  initial.textContent = String(displayName || '?').trim().slice(0, 1).toLocaleUpperCase('pt-BR') || '?';
  img.onerror = () => {
    img.onerror = null;
    if(img.getAttribute('src') !== DEFAULT_PROFILE_AVATAR){
      img.src = DEFAULT_PROFILE_AVATAR;
      return;
    }
    img.hidden = true;
    initial.hidden = false;
  };
  img.onload = () => { img.hidden = false; initial.hidden = true; };
  img.hidden = false;
  initial.hidden = true;
  img.src = profileAvatarSrc(userProfile);
}
function renderProfileAvatarPreview(dataUrl, avatarSrc){
  const img = document.getElementById('profileAvatarImg');
  const initial = document.getElementById('profileAvatarInitial');
  const removeBtn = document.getElementById('profileBtnRemovePhoto');
  if(!img || !initial) return;
  if(dataUrl){
    img.src = dataUrl; img.hidden = false; initial.hidden = true;
    if(removeBtn) removeBtn.hidden = false;
  } else {
    img.src = DEFAULT_PROFILE_AVATAR;
    img.hidden = false; initial.hidden = true;
    if(removeBtn) removeBtn.hidden = true;
  }
}

/* ===================== CONTA LOCAL + PIN RÁPIDO (offline) =====================
   Tudo fica só neste dispositivo: nunca é enviado a nenhum servidor. Senha e
   PIN são guardados como hash — nunca em texto puro — mas isso não substitui
   um cofre de senhas de verdade; é uma trava simples para impedir o acesso
   casual de outra pessoa ao aparelho.
   IMPORTANTE: usamos sempre o MESMO algoritmo (síncrono, sem depender de
   crypto.subtle). Antes o código tentava SHA-256 via crypto.subtle e caía
   num fallback diferente quando isso não estava disponível — como a
   disponibilidade de crypto.subtle pode variar entre "contexto seguro" e não
   (http simples, file://, alguns WebViews), a senha podia ser hasheada de um
   jeito ao criar a conta e de outro jeito ao tentar entrar, fazendo a senha
   certa parecer errada. Usar um único algoritmo determinístico resolve isso. */
function localHash(text){
  const s = 'acervo-local-salt::' + text;
  // FNV-1a de 32 bits, aplicado duas vezes com sementes diferentes para
  // reduzir colisões — suficiente para uma trava local, não para cofre real.
  function fnv1a(str, seed){
    let h = seed >>> 0;
    for(let i=0;i<str.length;i++){
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h;
  }
  const a = fnv1a(s, 0x811c9dc5);
  const b = fnv1a(s.split('').reverse().join(''), 0x01000193);
  return a.toString(16).padStart(8,'0') + b.toString(16).padStart(8,'0');
}
async function sha256Hex(text){
  return localHash(text);
}
/* ── Contas múltiplas no mesmo dispositivo ──────────────────────────────
   Cada dispositivo pode ter várias contas locais (ex.: um usuário por
   pessoa da casa). Cada conta tem o seu próprio id, e esse id é usado por
   nsKey() para isolar completamente o acervo (obras, listas, histórico e
   perfil) de cada uma — entrar com a conta errada nunca mostra o acervo de
   outra pessoa; uma conta nova sempre começa com o acervo vazio. */
function readAccounts(){
  if(!LOCAL_STORAGE_AVAILABLE) return [];
  try{
    const raw = window.localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  }catch(e){ return []; }
}
function writeAccounts(list){
  try{ window.localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(list)); }catch(e){}
}
function genAccountId(){
  return 'acc_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function getActiveAccountId(){
  if(!LOCAL_STORAGE_AVAILABLE) return null;
  try{ return window.localStorage.getItem(ACTIVE_ACCOUNT_KEY) || null; }catch(e){ return null; }
}
function setActiveAccountId(id){
  try{
    if(id) window.localStorage.setItem(ACTIVE_ACCOUNT_KEY, id);
    else window.localStorage.removeItem(ACTIVE_ACCOUNT_KEY);
  }catch(e){}
}
// Migração: versões antigas do app guardavam só uma conta (sem lista) e o
// acervo era único e global. Se detectarmos essa conta antiga e nenhuma
// lista de contas ainda, convertemos para o novo formato preservando o
// acervo já existente (ele passa a pertencer a essa conta).
function migrateLegacyAccountIfNeeded(){
  if(!LOCAL_STORAGE_AVAILABLE) return;
  if(readAccounts().length > 0) return;
  let legacy = null;
  try{ const raw = window.localStorage.getItem(ACCOUNT_STORAGE_KEY); legacy = raw ? JSON.parse(raw) : null; }catch(e){ legacy = null; }
  if(!legacy || !legacy.usuario || !legacy.hash) return;
  const id = genAccountId();
  const conta = {id, usuario: legacy.usuario, hash: legacy.hash, criado_em: legacy.criado_em || Date.now()};
  writeAccounts([conta]);
  setActiveAccountId(id);
  // Migra o PIN antigo (chave global) para a chave por conta.
  try{
    const legacyPin = window.localStorage.getItem(PIN_HASH_KEY);
    if(legacyPin) window.localStorage.setItem(PIN_HASH_KEY + '::' + id, legacyPin);
  }catch(e){}
  // Migra os dados do acervo antigo (chaves sem sufixo de conta) para as
  // novas chaves isoladas por conta, em localStorage e no IndexedDB.
  [STORAGE_KEY, LISTS_STORAGE_KEY, APP_STATE_STORAGE_KEY, HISTORY_STORAGE_KEY, ACTIVITY_STORAGE_KEY, PROFILE_STORAGE_KEY].forEach(base => {
    try{
      const oldVal = window.localStorage.getItem(base);
      if(oldVal != null) window.localStorage.setItem(base + '::' + id, oldVal);
    }catch(e){}
    idbGet(base).then(val => { if(val != null) idbSet(base + '::' + id, val); }).catch(()=>{});
  });
}
function readAccount(){ return findAccountById(getActiveAccountId()); }
function findAccountById(id){
  if(!id) return null;
  return readAccounts().find(a => a.id === id) || null;
}
function hasAnyAccount(){ return readAccounts().length > 0; }
function hasAccount(){ return !!readAccount(); }
function usernameTaken(usuario, ignoreId){
  const u = (usuario || '').trim().toLowerCase();
  return readAccounts().some(a => a.usuario.toLowerCase() === u && a.id !== ignoreId);
}
async function createAccount(usuario, senha){
  const hash = await sha256Hex(senha);
  const id = genAccountId();
  const conta = {id, usuario: usuario.trim(), hash, criado_em: Date.now()};
  const list = readAccounts();
  list.push(conta);
  writeAccounts(list);
  setActiveAccountId(id);
  return conta;
}
async function verifyPassword(senha){
  const conta = readAccount();
  if(!conta) return true;
  const hash = await sha256Hex(senha);
  return hash === conta.hash;
}
// Troca a senha da conta ativa SEM criar uma conta nova (mantém o mesmo id
// e portanto o mesmo acervo) — diferente de createAccount(), que é só para
// o primeiro acesso ou para um usuário realmente novo.
async function updateActiveAccountPassword(novaSenha){
  const id = getActiveAccountId();
  if(!id) return;
  const hash = await sha256Hex(novaSenha);
  const list = readAccounts();
  const idx = list.findIndex(a => a.id === id);
  if(idx !== -1){ list[idx] = Object.assign({}, list[idx], {hash}); writeAccounts(list); }
}
// "Esqueci minha senha": NÃO existe recuperação — de propósito. Como cada
// conta tem seu próprio acervo isolado, qualquer forma de "redefinir a
// senha mantendo os dados" seria, na prática, uma porta para acessar o
// acervo de outra pessoa sem saber a senha dela. Por isso a única opção
// quando a senha é esquecida é apagar essa conta (e o acervo dela) por
// completo — nunca redefinir credenciais mantendo os dados.
async function deleteAccountCompletely(id){
  if(!id) return;
  const wasActive = getActiveAccountId() === id;
  const list = readAccounts().filter(a => a.id !== id);
  writeAccounts(list);
  await Promise.all([
    deletePersistedJson(STORAGE_KEY + '::' + id),
    deletePersistedJson(LISTS_STORAGE_KEY + '::' + id),
    deletePersistedJson(APP_STATE_STORAGE_KEY + '::' + id),
    deletePersistedJson(COVER_BLUR_STORAGE_KEY + '::' + id),
    deletePersistedJson(HISTORY_STORAGE_KEY + '::' + id),
    deletePersistedJson(ACTIVITY_STORAGE_KEY + '::' + id),
    removeActivitySnapshotsForAccount(id),
    deletePersistedJson(PROFILE_STORAGE_KEY + '::' + id)
  ]);
    try{
      window.localStorage.removeItem(PIN_HASH_KEY + '::' + id);
      window.localStorage.removeItem(ACCOUNT_SECURITY_DISABLED_KEY + '::' + id);
    }catch(e){}
  if(wasActive){
    setActiveAccountId(null);
    try{ window.sessionStorage.removeItem(SESSION_UNLOCKED_KEY); }catch(e){}
  }
}
function pinKeyForActive(){
  const id = getActiveAccountId();
  return id ? (PIN_HASH_KEY + '::' + id) : null;
}
function hasPinSet(){
  const key = pinKeyForActive();
  if(!key || !LOCAL_STORAGE_AVAILABLE) return false;
  try{ return !!window.localStorage.getItem(key); }catch(e){ return false; }
}
async function setPin(pin){
  const key = pinKeyForActive(); if(!key) return;
  const hash = await sha256Hex('pin::' + pin);
  try{ window.localStorage.setItem(key, hash); }catch(e){}
}
function removePin(){
  const key = pinKeyForActive(); if(!key) return;
  try{ window.localStorage.removeItem(key); }catch(e){}
}
async function verifyPin(pin){
  const key = pinKeyForActive();
  let stored = null;
  if(key){ try{ stored = window.localStorage.getItem(key); }catch(e){} }
  if(!stored) return false;
  const hash = await sha256Hex('pin::' + pin);
  return hash === stored;
}
function accountSecurityKey(id){
  return id ? (ACCOUNT_SECURITY_DISABLED_KEY + '::' + id) : null;
}
function isSecurityDisabledForAccount(id){
  const key = accountSecurityKey(id || getActiveAccountId());
  if(!key || !LOCAL_STORAGE_AVAILABLE) return false;
  try{ return window.localStorage.getItem(key) === '1'; }catch(e){ return false; }
}
function setSecurityDisabledForActiveAccount(disabled){
  const key = accountSecurityKey(getActiveAccountId());
  if(!key || !LOCAL_STORAGE_AVAILABLE) return;
  try{
    if(disabled) window.localStorage.setItem(key, '1');
    else window.localStorage.removeItem(key);
  }catch(e){}
}
function migrateLegacySecurityPreferenceForActiveAccount(){
  const id = getActiveAccountId();
  if(!id || !LOCAL_STORAGE_AVAILABLE || isSecurityDisabledForAccount(id)) return;
  try{
    const raw = window.localStorage.getItem(PREFS_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if(parsed && parsed.disableSecurity === true){
      window.localStorage.setItem(accountSecurityKey(id), '1');
      delete parsed.disableSecurity;
      window.localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(parsed));
    }
  }catch(e){}
}
function isSessionUnlocked(){
  try{
    const id = getActiveAccountId();
    const expected = id ? ('1::' + id) : '1';
    return window.sessionStorage.getItem(SESSION_UNLOCKED_KEY) === expected;
  }catch(e){ return false; }
}
function markSessionUnlocked(){
  try{
    const id = getActiveAccountId();
    window.sessionStorage.setItem(SESSION_UNLOCKED_KEY, id ? ('1::' + id) : '1');
  }catch(e){}
}
function logoutSession(){
  try{ window.sessionStorage.removeItem(SESSION_UNLOCKED_KEY); }catch(e){}
}
function needsUnlock(){ return LOCAL_STORAGE_AVAILABLE && !isSecurityDisabledForAccount() && !isSessionUnlocked(); }

function hideAllLockForms(){
  ['lockChooseAccount','lockCreateForm','lockOfferPin','lockLoginForm','lockPinForm','lockForgotBlock'].forEach(id => {
    const el = document.getElementById(id);
    el.hidden = true;
    // Reforço: além de "hidden", marca como inert para que nenhum campo
    // dentro de um formulário escondido possa ganhar foco por engano (ex.:
    // o botão "próximo campo" do teclado, autofill do navegador, etc.)
    // — é isso que às vezes fazia o PIN funcionar mas a tela de senha
    // aparecer/roubar o foco logo em seguida.
    try{ el.inert = true; }catch(_){}
  });
}
function initialLetter(name){
  return name && name.trim() ? name.trim().charAt(0).toUpperCase() : '?';
}
function accountProfile(a){
  try{
    const raw = window.localStorage.getItem(PROFILE_STORAGE_KEY + '::' + a.id);
    const p = raw ? JSON.parse(raw) : null;
    return {nome: p && typeof p.nome === 'string' && p.nome.trim() ? p.nome.trim() : (a.usuario || ''), foto: p && typeof p.foto === 'string' && p.foto.startsWith('data:image') ? p.foto : null};
  }catch(_){ return {nome:a.usuario || '',foto:null}; }
}
function renderLockAccountList(){
  const wrap = document.getElementById('lockAccountList');
  if(!wrap) return;
  const accounts = readAccounts();
  wrap.innerHTML = accounts.map(a => {
    const p = accountProfile(a);
    const avatar = p.foto ? '<img src="' + escapeHtml(p.foto) + '" alt="" loading="lazy">' : '<span>' + initialLetter(p.nome) + '</span>';
    return '<button type="button" class="lock-account-item" data-account-id="' + escapeHtml(a.id) + '">' +
      '<span class="header-avatar">' + avatar + '</span>' +
      '<span>' + escapeHtml(p.nome) + '</span>' +
    '</button>';
  }).join('');
}
function lockShowChooseAccount(){
  hideAllLockForms();
  renderLockAccountList();
  document.getElementById('lockChooseAccount').hidden = false; try{ document.getElementById('lockChooseAccount').inert = false; }catch(_){}
}
function lockShowCreateAccount(isAddingAnother){
  hideAllLockForms();
  const form = document.getElementById('lockCreateForm');
  document.getElementById('lockCreateTitle').textContent = isAddingAnother ? 'Criar novo usuário' : 'Criar conta local';
  document.getElementById('lockCreateHint').textContent = isAddingAnother
    ? 'Esse usuário terá o seu próprio acervo neste dispositivo, separado dos demais.'
    : 'Escolha um usuário e uma senha para proteger o seu acervo neste dispositivo.';
  document.getElementById('lockCreateCancel').hidden = !isAddingAnother;
  form.reset();
  document.getElementById('lockCreateError').hidden = true;
  form.hidden = false;
  try{ form.inert = false; }catch(_){}
  setTimeout(() => document.getElementById('lockCreateUser').focus(), 50);
}
let _lockOnUnlockCallback = null;
function lockGoToLoginOrPin(){
  hideAllLockForms();
  if(isSecurityDisabledForAccount()){
    lockFinishUnlock();
    return;
  }
  const conta = readAccount();
  if(hasPinSet()){
    document.getElementById('lockPinForm').hidden = false; try{ document.getElementById('lockPinForm').inert = false; }catch(_){}
    document.getElementById('lockPinError').hidden = true;
    document.getElementById('lockPinUserLabel').textContent = conta ? conta.usuario : '';
    const inp = document.getElementById('lockPinInput'); inp.value = ''; setTimeout(() => inp.focus(), 50);
  } else {
    document.getElementById('lockLoginForm').hidden = false; try{ document.getElementById('lockLoginForm').inert = false; }catch(_){}
    document.getElementById('lockLoginUserLabel').textContent = conta ? conta.usuario : '';
    document.getElementById('lockLoginError').hidden = true;
    const inp = document.getElementById('lockLoginPwd'); inp.value = ''; setTimeout(() => inp.focus(), 50);
  }
}
function lockFinishUnlock(){
  // Ao concluir o acesso, limpa imediatamente o teclado personalizado e o
  // foco do campo anterior. Sem isto, ao reabrir a tela para trocar/criar
  // utilizador, o pointerup seguinte podia continuar associado ao formulário
  // antigo e impedir o novo botão de entrada de responder no telefone.
  if(window.__ckb && typeof window.__ckb.hide === 'function'){
    try{ window.__ckb.hide(); }catch(_){ }
  }
  try{ if(document.activeElement && document.activeElement.closest && document.activeElement.closest('#lockOverlay')) document.activeElement.blur(); }catch(_){ }
  hideAllLockForms();
  markSessionUnlocked();
  document.getElementById('lockOverlay').hidden = true;
  userProfile = loadProfile(); // recarrega o perfil da conta que acabou de entrar
  refreshHeaderProfile();
  const cb = _lockOnUnlockCallback; _lockOnUnlockCallback = null;
  if(cb) cb();
}
function lockShakeCard(){
  const card = document.getElementById('lockOverlay').querySelector('.lock-card');
  card.classList.remove('lock-shake'); void card.offsetWidth; card.classList.add('lock-shake');
}
function showLockScreen(onUnlock, options){
  migrateLegacyAccountIfNeeded();
  options = options || {};
  if(options.forceChooseAccount) setActiveAccountId(null);
  if(!options.forceChooseAccount && isSecurityDisabledForAccount()){
    markSessionUnlocked();
    const overlay = document.getElementById('lockOverlay');
    if(overlay) overlay.hidden = true;
    if(typeof onUnlock === 'function') onUnlock();
    return;
  }
  _lockOnUnlockCallback = onUnlock;
  const overlay = document.getElementById('lockOverlay');
  overlay.hidden = false;
  overlay.scrollTop = 0;
  // Nunca reabre uma tela de acesso com o formulário anterior ainda ativo.
  hideAllLockForms();
  if(!hasAnyAccount()){
    lockShowCreateAccount(false);
    return;
  }
  // Se a conta ativa guardada ainda existir, vai direto para o login/PIN
  // dela; senão (nenhuma ainda escolhida, ou foi removida), mostra a lista
  // de usuários deste dispositivo para escolher — e de lá dá para criar um novo.
  if(readAccount()){
    lockGoToLoginOrPin();
  } else {
    lockShowChooseAccount();
  }
}
function keepLockFieldVisible(field){
  if(!field || !field.closest('#lockOverlay')) return;
  const overlay = document.getElementById('lockOverlay');
  if(!overlay || overlay.hidden) return;
  const vv = window.visualViewport;
  const visibleBottom = Math.min(
    overlay.getBoundingClientRect().bottom,
    vv ? vv.height : window.innerHeight
  );
  const visibleTop = Math.max(0, overlay.getBoundingClientRect().top);
  const rect = field.getBoundingClientRect();
  const padding = 16;
  let delta = 0;
  if(rect.bottom > visibleBottom - padding) delta = rect.bottom - (visibleBottom - padding);
  else if(rect.top < visibleTop + padding) delta = rect.top - (visibleTop + padding);
  if(delta) overlay.scrollTop = Math.max(0, overlay.scrollTop + delta);
}
function scheduleLockFieldVisibility(field){
  [0, 70, 220].forEach(delay => setTimeout(() => keepLockFieldVisible(field), delay));
}
function bindLockViewport(){
  if(window.__lockViewportBound) return;
  window.__lockViewportBound = true;
  document.addEventListener('focusin', (e) => {
    if(e.target && e.target.closest && e.target.closest('#lockOverlay')) scheduleLockFieldVisibility(e.target);
  }, true);
  const onViewportChange = () => {
    const overlay = document.getElementById('lockOverlay');
    const active = document.activeElement;
    if(overlay && !overlay.hidden && active && overlay.contains(active)) scheduleLockFieldVisibility(active);
  };
  window.addEventListener('resize', onViewportChange, {passive:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize', onViewportChange, {passive:true});
    window.visualViewport.addEventListener('scroll', onViewportChange, {passive:true});
  }
}
bindLockViewport();
// Liga os listeners das telas de bloqueio UMA única vez (a tela pode ser
// reaberta várias vezes na mesma sessão, ex.: após "Sair da conta").
function bindLockForms(){
  document.getElementById('lockCreateForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const usuario = document.getElementById('lockCreateUser').value.trim();
    const p1 = document.getElementById('lockCreatePwd1').value;
    const p2 = document.getElementById('lockCreatePwd2').value;
    const err = document.getElementById('lockCreateError');
    if(usuario.length < 2){ err.textContent = 'Digite um usuário com pelo menos 2 caracteres.'; err.hidden = false; return; }
    if(p1.length < 6){ err.textContent = 'A senha precisa ter pelo menos 6 caracteres.'; err.hidden = false; return; }
    if(p1 !== p2){ err.textContent = 'As senhas digitadas são diferentes.'; err.hidden = false; return; }
    if(usernameTaken(usuario)){ err.textContent = 'Esse usuário já existe neste dispositivo. Escolha outro nome.'; err.hidden = false; return; }
    err.hidden = true;
    await createAccount(usuario, p1);
    // Depois de criar a conta, oferece o PIN rápido antes de entrar de vez.
    hideAllLockForms();
    document.getElementById('lockOfferPin').hidden = false; try{ document.getElementById('lockOfferPin').inert = false; }catch(_){}
    document.getElementById('lockOfferPinError').hidden = true;
    const firstPin = document.getElementById('lockOfferPin1');
    const secondPin = document.getElementById('lockOfferPin2');
    firstPin.value = '';
    secondPin.value = '';
    // A criação do PIN começa sempre no campo da esquerda. Só depois de
    // completar os quatro dígitos o foco passa para a confirmação à direita.
    setTimeout(() => firstPin.focus(), 50);
  });
  document.getElementById('lockOfferPin1').addEventListener('input', (e) => {
    const input = e.currentTarget;
    input.value = input.value.replace(/\D/g, '').slice(0, 4);
    if(input.value.length === 4) document.getElementById('lockOfferPin2').focus();
  });
  document.getElementById('lockCreateCancel').addEventListener('click', () => {
    if(hasAnyAccount()) lockShowChooseAccount(); else lockShowCreateAccount(false);
  });

  document.getElementById('lockOfferPinConfirm').addEventListener('click', async () => {
    const p1 = document.getElementById('lockOfferPin1').value.trim();
    const p2 = document.getElementById('lockOfferPin2').value.trim();
    const err = document.getElementById('lockOfferPinError');
    if(!/^\d{4}$/.test(p1)){ err.textContent = 'O PIN precisa ter exatamente 4 números.'; err.hidden = false; return; }
    if(p1 !== p2){ err.textContent = 'Os dois PINs digitados são diferentes.'; err.hidden = false; return; }
    await setPin(p1);
    lockFinishUnlock();
  });
  document.getElementById('lockOfferPinSkip').addEventListener('click', () => { lockFinishUnlock(); });

  document.getElementById('lockLoginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const senha = document.getElementById('lockLoginPwd').value;
    const ok = await verifyPassword(senha);
    if(ok){ lockFinishUnlock(); }
    else{
      document.getElementById('lockLoginError').hidden = false;
      document.getElementById('lockLoginPwd').value = '';
      document.getElementById('lockLoginPwd').focus();
      lockShakeCard();
    }
  });

  document.getElementById('lockPinForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const pin = document.getElementById('lockPinInput').value.trim();
    const ok = await verifyPin(pin);
    if(ok){ lockFinishUnlock(); }
    else{
      document.getElementById('lockPinError').hidden = false;
      document.getElementById('lockPinInput').value = '';
      document.getElementById('lockPinInput').focus();
      lockShakeCard();
    }
  });
  document.getElementById('lockUsePasswordInstead').addEventListener('click', () => {
    hideAllLockForms();
    const conta = readAccount();
    document.getElementById('lockLoginForm').hidden = false; try{ document.getElementById('lockLoginForm').inert = false; }catch(_){}
    document.getElementById('lockLoginUserLabel').textContent = conta ? conta.usuario : '';
    document.getElementById('lockLoginError').hidden = true;
    const inp = document.getElementById('lockLoginPwd'); inp.value = ''; setTimeout(() => inp.focus(), 50);
  });

  // Tela de "escolher usuário": toca numa conta existente para entrar com
  // ela, ou cria um usuário novo (com o seu próprio acervo, vazio).
  document.getElementById('lockAccountList').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-account-id]');
    if(!btn) return;
    setActiveAccountId(btn.dataset.accountId);
    lockGoToLoginOrPin();
  });
  document.getElementById('lockChooseAccountNew').addEventListener('click', () => { lockShowCreateAccount(true); });
  document.getElementById('lockLoginSwitchUser').addEventListener('click', () => { lockShowChooseAccount(); });
  document.getElementById('lockPinSwitchUser').addEventListener('click', () => { lockShowChooseAccount(); });
  document.querySelectorAll('.lock-delete-account-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const conta = readAccount();
      if(!conta) return;
      openConfirmModal(
        'Apagar conta permanentemente',
        `Apagar a conta <strong>${escapeHtml(conta.usuario)}</strong> e remover permanentemente o acervo, as listas, o perfil e o PIN salvos neste dispositivo? <strong>Essa ação não pode ser desfeita.</strong>`,
        async () => {
          await deleteAccountCompletely(conta.id);
          hideAllLockForms();
          if(hasAnyAccount()) lockShowChooseAccount();
          else lockShowCreateAccount(false);
        }
      );
    });
  });

  // "Esqueci minha senha": NÃO existe redefinição mantendo os dados — a
  // única opção mostrada aqui é apagar esta conta e o acervo isolado dela.
  document.getElementById('lockForgotPwd').addEventListener('click', () => {
    hideAllLockForms();
    document.getElementById('lockForgotBlock').hidden = false; try{ document.getElementById('lockForgotBlock').inert = false; }catch(_){}
  });
  document.getElementById('lockForgotCancel').addEventListener('click', () => { lockGoToLoginOrPin(); });
  document.getElementById('lockForgotConfirm').addEventListener('click', async () => {
    const id = getActiveAccountId();
    await deleteAccountCompletely(id);
    hideAllLockForms();
    if(hasAnyAccount()) lockShowChooseAccount();
    else lockShowCreateAccount(false);
  });
}
bindLockForms();

// ===================== MOSTRAR/OCULTAR SENHA =====================
// Delegado no document (funciona para qualquer campo de senha atual ou
// futuro, incluindo os da tela de bloqueio e os de Preferências).
if(!window.__pwdToggleBound){
  window.__pwdToggleBound = true;
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.pwd-toggle');
    if(!btn) return;
    const targetId = btn.getAttribute('data-toggle-pwd');
    const input = targetId && document.getElementById(targetId);
    if(!input) return;
    // Campos sob o teclado personalizado (mobile) já foram convertidos para
    // type="text" + readonly, com o mascaramento sendo só a classe CSS
    // .ckb-masked — isso existe de propósito para impedir o teclado nativo
    // de abrir por baixo do teclado do app. Nesse caso, alternamos só a
    // classe, sem tocar em type/readonly (mexer nisso reabria o problema do
    // teclado nativo aparecendo por baixo). Em campos "normais" (ex.: sem o
    // teclado personalizado ativo), alternamos o type de verdade.
    const usesCkbMask = input.dataset && input.dataset.ckbReadonlyOk === '1';
    let showing;
    if(usesCkbMask){
      showing = !input.classList.contains('ckb-masked');
      input.classList.toggle('ckb-masked');
    } else {
      showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
    }
    btn.classList.toggle('is-visible', !showing);
    btn.setAttribute('aria-label', showing ? 'Mostrar senha' : 'Ocultar senha');
    btn.textContent = showing ? '👁' : '🙈';
    input.focus();
    // Mantém o cursor no fim do texto ao alternar a máscara do campo.
    const len = input.value.length;
    try{ input.setSelectionRange(len, len); }catch(_){}
    // Avisa o teclado personalizado (que controla o cursor/arraste da
    // barra de espaço) que este é o campo ativo agora — sem isso, depois
    // de trocar a máscara do campo, o teclado ficava "sem saber" qual campo
    // seguir, e o gesto de arrastar para mover o cursor parava de responder.
    if(window.__ckb && typeof window.__ckb.show === 'function'){
      try{ window.__ckb.show(input); }catch(_){}
    }
  });
}

function refreshPrefsSecurityCard(){
  const conta = readAccount();
  document.getElementById('prefsAccountUser').textContent = conta ? conta.usuario : '';
  document.getElementById('prefsChangePasswordBlock').hidden = true;
  document.getElementById('prefsAccountInfo').hidden = false;
  const hasPin = hasPinSet();
  document.getElementById('prefsDisableSecurity').checked = isSecurityDisabledForAccount();
  document.getElementById('prefsPinSetForm').hidden = hasPin;
  document.getElementById('prefsPinActiveInfo').hidden = !hasPin;
  document.getElementById('prefsPinNew1').value = '';
  document.getElementById('prefsPinNew2').value = '';
  const passwordStatus = document.getElementById('prefsChangePasswordStatus');
  if(passwordStatus){ passwordStatus.hidden = true; passwordStatus.textContent = ''; }
  const status = document.getElementById('prefsPinStatus');
  if(status){ status.hidden = true; status.textContent = ''; }
}

function openPrefsModal(){
  const backdrop = document.getElementById('prefsModalBackdrop');
  const countLbl = document.getElementById('prefsBackupCount');
  const lastLbl = document.getElementById('prefsBackupLast');
  const status = document.getElementById('prefsBackupStatus');
  if(status) status.hidden = true;
  countLbl.textContent = `${state.entries.length} obra(s) · ${(state.listas||[]).length} lista(s)`;
  let lastTs = null;
  if(LOCAL_STORAGE_AVAILABLE){
    try{ const raw = window.localStorage.getItem(EXPORT_LAST_KEY); lastTs = raw ? Number(raw) : null; }catch(e){}
  }
  lastLbl.textContent = lastTs ? `Último backup: ${new Date(lastTs).toLocaleString('pt-BR')}` : 'Nenhum backup exportado ainda.';
  document.getElementById('prefsTema').value = userPrefs.tema;
  document.getElementById('prefsReduceMotion').checked = !!userPrefs.reduceMotion;
  document.getElementById('prefsReminderInterval').value = String(userPrefs.reminderIntervalDays);
  document.getElementById('prefsDefaultCategoria').value = userPrefs.defaultCategoria;
  backdrop.hidden = false;
}
function closePrefsModal(){ document.getElementById('prefsModalBackdrop').hidden = true; }

function openProfileModal(){
  refreshProfileModal();
  refreshPrefsSecurityCard();
  const status = document.getElementById('profileStatus');
  if(status) status.hidden = true;
  document.getElementById('profileModalBackdrop').hidden = false;
}
function closeProfileModal(){ document.getElementById('profileModalBackdrop').hidden = true; }
function profileStatusMsg(type, message){
  const status = document.getElementById('profileStatus');
  if(!status) return;
  status.textContent = message;
  status.className = 'prefs-status prefs-status-' + type;
  status.hidden = false;
}
function bindProfileModal(){
  document.getElementById('btnProfile').addEventListener('click', openProfileModal);
  document.getElementById('profileModalClose').addEventListener('click', closeProfileModal);
  document.getElementById('profileBtnClose').addEventListener('click', closeProfileModal);
  document.getElementById('profileBtnPhoto').addEventListener('click', () => document.getElementById('profilePhotoFile').click());
  document.getElementById('profilePhotoFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if(!file) return;
    try{
      const compressed = await imageBlobToCompressedDataUrl(file, { maxWidth: 240, quality: 0.85 });
      userProfile = Object.assign({}, userProfile, { foto: compressed, avatar: null });
      const saved = await saveProfile(userProfile);
      renderProfileAvatarPreview(userProfile.foto, userProfile.avatar);
      profileStatusMsg(saved ? 'success' : 'error', saved
        ? 'Foto de perfil atualizada.'
        : 'Não foi possível guardar a foto neste dispositivo.');
    }catch(_){ profileStatusMsg('error', 'Não foi possível processar essa imagem.'); }
  });
  document.getElementById('profileBtnRemovePhoto').addEventListener('click', async () => {
    userProfile = Object.assign({}, userProfile, { foto: null, avatar: DEFAULT_PROFILE_AVATAR });
    const saved = await saveProfile(userProfile);
    renderProfileAvatarPreview(null, userProfile.avatar);
    profileStatusMsg(saved ? 'info' : 'error', saved
      ? 'Figura padrão restaurada.'
      : 'Não foi possível guardar a alteração neste dispositivo.');
  });
  document.getElementById('profileForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const nome = document.getElementById('profileName').value.trim();
    if(nome.length > 80){ profileStatusMsg('error', 'O nome do perfil pode ter no máximo 80 caracteres.'); return; }
    userProfile = Object.assign({}, userProfile, { nome });
    const saved = await saveProfile(userProfile);
    renderProfileAvatarPreview(userProfile.foto || null, userProfile.avatar);
    profileStatusMsg(saved ? 'success' : 'error', saved
      ? 'Perfil salvo neste dispositivo.'
      : 'Não foi possível guardar o perfil neste dispositivo.');
  });
  document.getElementById('prefsDisableSecurity').addEventListener('change', (e) => {
    setSecurityDisabledForActiveAccount(e.target.checked);
    logoutSession();
    profileStatusMsg('success', e.target.checked ? 'Segurança desta conta desativada.' : 'Segurança desta conta ativada.');
  });
}

async function copyJsonToClipboard(){
  try{
    prefsNotify('info', 'A preparar o JSON…');
    const generatedAt = new Date();
    const meta = {
      __meta: true,
      tipo: 'relatorio_acervo_pessoal',
      generated_at_iso: generatedAt.toISOString(),
      generated_at_local: generatedAt.toLocaleString('pt-BR'),
      total_obras: state.entries.length,
      total_listas: (state.listas||[]).length,
      listas: Array.isArray(state.listas) ? state.listas.map(l => ({
        id: l.id, nome: l.nome, categoria: l.categoria,
        defaultCat: l.defaultCat || null, defaultSub: l.defaultSub || null,
        obraIds: Array.isArray(l.obraIds) ? l.obraIds.slice() : [],
        criado_em: l.criado_em || Date.now()
      })) : [],
      capas_desfocadas_ids: normalizeCoverBlurIds(state.capasDesfocadasIds),
      foto_perfil: getProfilePhotoForJsonReport(),
      imagens: 'capas_embutidas_compactadas',
      capa_largura_max: JSON_REPORT_COVER_MAX_WIDTH,
      capa_qualidade_jpeg: JSON_REPORT_COVER_JPEG_QUALITY,
      json: 'minificado',
      app_version: 'acervo-pessoal'
    };
    const normalized = await prepareEntriesForCompactJsonReport(state.entries);
    const content = await stringifyEntriesChunked([meta].concat(normalized));
    if(navigator.clipboard && navigator.clipboard.writeText){
      await navigator.clipboard.writeText(content);
    } else {
      const ta = document.createElement('textarea');
      ta.value = content; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.focus(); ta.select();
      document.execCommand('copy'); ta.remove();
    }
    prefsNotify('success', 'JSON copiado para a área de transferência (' + generatedAt.toLocaleString('pt-BR') + ').');
  }catch(e){ prefsNotify('error', 'Não foi possível copiar o JSON.'); }
}

function getProfilePhotoForJsonReport(){
  const photo = userProfile && userProfile.foto;
  return typeof photo === 'string' && photo.startsWith('data:image/') ? photo : undefined;
}

function bindPrefsModal(){
  document.getElementById('btnPrefs').addEventListener('click', openPrefsModal);
  document.getElementById('prefsModalClose').addEventListener('click', closePrefsModal);
  document.getElementById('prefsBtnClose').addEventListener('click', closePrefsModal);
  document.getElementById('prefsBtnExport').addEventListener('click', exportData);
  document.getElementById('prefsBtnCopyJson').addEventListener('click', copyJsonToClipboard);
  document.getElementById('prefsBtnImport').addEventListener('click', () => {
    const picker = document.getElementById('prefsImportFile');
    if(!picker) return;
    try{
      if(typeof picker.showPicker === 'function') picker.showPicker();
      else picker.click();
    }catch(_){ picker.click(); }
  });
  document.getElementById('prefsImportFile').addEventListener('change', (e) => {
    const input = e.target;
    const file = input.files && input.files[0];
    if(!file) return;
    Promise.resolve(importData(file)).finally(() => { input.value = ''; });
  });
  document.getElementById('prefsTema').addEventListener('change', (e) => {
    userPrefs = Object.assign({}, userPrefs, {tema: e.target.value});
    applyPrefs(userPrefs); savePrefs(userPrefs);
  });
  document.getElementById('prefsReduceMotion').addEventListener('change', (e) => {
    userPrefs = Object.assign({}, userPrefs, {reduceMotion: e.target.checked});
    applyPrefs(userPrefs); savePrefs(userPrefs);
  });
  document.getElementById('prefsReminderInterval').addEventListener('change', (e) => {
    userPrefs = Object.assign({}, userPrefs, {reminderIntervalDays: Number(e.target.value)});
    savePrefs(userPrefs);
  });
  document.getElementById('prefsDefaultCategoria').addEventListener('change', (e) => {
    userPrefs = Object.assign({}, userPrefs, {defaultCategoria: e.target.value});
    savePrefs(userPrefs);
  });
  document.getElementById('prefsBtnWipe').addEventListener('click', () => {
    closePrefsModal();
    openConfirmWipe();
  });

  // --- Conta: trocar senha ---
  document.getElementById('prefsBtnChangePassword').addEventListener('click', () => {
    document.getElementById('prefsAccountInfo').hidden = true;
    document.getElementById('prefsChangePasswordBlock').hidden = false;
    document.getElementById('prefsNewPwd1').value = '';
    document.getElementById('prefsNewPwd2').value = '';
    const status = document.getElementById('prefsChangePasswordStatus');
    if(status){ status.hidden = true; status.textContent = ''; }
    document.getElementById('prefsNewPwd1').focus();
  });
  document.getElementById('prefsBtnCancelChangePassword').addEventListener('click', () => {
    document.getElementById('prefsChangePasswordBlock').hidden = true;
    document.getElementById('prefsAccountInfo').hidden = false;
  });
  document.getElementById('prefsChangePasswordForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const p1 = document.getElementById('prefsNewPwd1').value;
    const p2 = document.getElementById('prefsNewPwd2').value;
    if(p1.length < 6){ passwordStatusMsg('error', 'A nova senha precisa ter pelo menos 6 caracteres.'); return; }
    if(p1 !== p2){ passwordStatusMsg('error', 'As novas senhas digitadas são diferentes.'); return; }
    const conta = readAccount();
    if(!conta){ passwordStatusMsg('error', 'Não foi possível identificar a conta ativa.'); return; }
    await updateActiveAccountPassword(p1);
    document.getElementById('prefsChangePasswordBlock').hidden = true;
    document.getElementById('prefsAccountInfo').hidden = false;
    prefsNotify('success', 'Senha alterada com sucesso.');
  });
  document.getElementById('prefsBtnLogout').addEventListener('click', () => {
    logoutSession();
    closeProfileModal();
    closePrefsModal();
    // Ao sair, volta sempre à escolha de usuário. Ao escolher a conta, o
    // fluxo normal decide entre entrada direta (segurança desativada) e
    // senha/PIN (segurança ativada).
    showLockScreen(() => { reloadAccountData(); }, {forceChooseAccount: true});
  });
  document.getElementById('prefsBtnDeleteAccount').addEventListener('click', () => {
    const conta = readAccount();
    if(!conta){ prefsNotify('error', 'Nenhuma conta ativa para apagar.'); return; }
    openConfirmModal(
      'Apagar conta permanentemente',
      `Apagar a conta <strong>${escapeHtml(conta.usuario)}</strong> e remover permanentemente o acervo, as listas, o perfil e o PIN salvos neste dispositivo? <strong>Essa ação não pode ser desfeita.</strong>`,
      async () => {
        closeProfileModal();
        await deleteAccountCompletely(conta.id);
        logoutSession();
        showLockScreen(() => { reloadAccountData(); });
      }
    );
  });

  // --- PIN rápido ---
  document.getElementById('prefsPinSetForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const p1 = document.getElementById('prefsPinNew1').value.trim();
    const p2 = document.getElementById('prefsPinNew2').value.trim();
    if(!/^\d{4}$/.test(p1)){ pinStatusMsg('error', 'O PIN precisa ter exatamente 4 números.'); return; }
    if(p1 !== p2){ pinStatusMsg('error', 'Os dois PINs digitados são diferentes.'); return; }
    await setPin(p1);
    refreshPrefsSecurityCard();
    prefsNotify('success', 'PIN rápido ativado.');
  });
  document.getElementById('prefsBtnRemovePin').addEventListener('click', () => {
    removePin();
    refreshPrefsSecurityCard();
    prefsNotify('success', 'PIN rápido removido.');
  });
  document.getElementById('prefsBtnChangePin').addEventListener('click', () => {
    removePin();
    refreshPrefsSecurityCard();
    document.getElementById('prefsPinNew1').focus();
  });
}

function exportData(){
  exportDataAsync();
}
function nextJsonReportFilename(){
  let seq = 0;
  if(LOCAL_STORAGE_AVAILABLE){
    try{ seq = Number(window.localStorage.getItem(EXPORT_SEQUENCE_KEY) || '0') || 0; }catch(e){ seq = 0; }
  } else seq = exportSequenceFallback;
  // Nome do arquivo inclui data e hora de geração (formato local seguro para nomes)
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}h${pad(d.getMinutes())}`;
  const suffix = seq === 0 ? '' : ` (${seq})`;
  const filename = `Relatório AC ${stamp}${suffix}.json`;
  if(LOCAL_STORAGE_AVAILABLE){
    try{ window.localStorage.setItem(EXPORT_SEQUENCE_KEY, String(seq + 1)); }catch(e){}
  } else exportSequenceFallback = seq + 1;
  return filename;
}
function compactJsonValue(value){
  if(Array.isArray(value)){
    return value
      .map(compactJsonValue)
      .filter(item => item !== undefined && item !== null && item !== '');
  }
  if(value && typeof value === 'object'){
    const out = {};
    Object.keys(value).forEach(key => {
      const compact = compactJsonValue(value[key]);
      if(compact === undefined || compact === null || compact === '') return;
      if(Array.isArray(compact) && compact.length === 0) return;
      if(compact && typeof compact === 'object' && !Array.isArray(compact) && Object.keys(compact).length === 0) return;
      out[key] = compact;
    });
    return out;
  }
  return value;
}
function compactJsonObject(obj){ return compactJsonValue(obj) || {}; }
async function prepareEntriesForCompactJsonReport(entries){
  const out = [];
  for(let i=0; i<entries.length; i++){
    const entry = normalizeEntryEditDates(Object.assign({}, entries[i]));
    if(entry.capa_base64){
      entry.capa_base64 = await compressCoverDataUrlForJson(entry.capa_base64);
      entry.capa_url = '';
    } else if(entry.capa_url && isValidUrl(entry.capa_url)){
      try{
        const dataUrl = await convertImageUrlToCompactJsonDataUrl(entry.capa_url);
        if(dataUrl){
          entry.capa_base64 = dataUrl;
          entry.capa_url = '';
        }
      }catch(e){
        // Se a origem bloquear CORS/offline, mantém a URL como fallback.
      }
    }
    out.push(compactJsonObject(entry));
    if(i > 0 && i % 12 === 0) await nextBrowserTick();
  }
  return out;
}
async function stringifyEntriesChunked(entries){
  const parts = ['['];
  for(let i=0; i<entries.length; i++){
    if(i) parts.push(',');
    // Minificado para reduzir o peso final do JSON.
    parts.push(JSON.stringify(entries[i]));
    if(i > 0 && i % 80 === 0) await nextBrowserTick();
  }
  parts.push(']');
  return parts.join('');
}
async function exportDataAsync(){
  try{
    prefsNotify('info', 'A compactar capas para o JSON…');
    const generatedAt = new Date();
    // Prepara metadata como PRIMEIRO item da lista; a importação ignora itens sem `titulo`/`categoria` válidos.
    const meta = {
      __meta: true,
      tipo: 'relatorio_acervo_pessoal',
      generated_at_iso: generatedAt.toISOString(),
      generated_at_local: generatedAt.toLocaleString('pt-BR'),
      total_obras: state.entries.length,
      total_listas: (state.listas||[]).length,
      listas: Array.isArray(state.listas) ? state.listas.map(l => ({
        id: l.id,
        nome: l.nome,
        categoria: l.categoria,
        defaultCat: l.defaultCat || null,
        defaultSub: l.defaultSub || null,
        obraIds: Array.isArray(l.obraIds) ? l.obraIds.slice() : [],
        criado_em: l.criado_em || Date.now()
      })) : [],
      capas_desfocadas_ids: normalizeCoverBlurIds(state.capasDesfocadasIds),
      foto_perfil: getProfilePhotoForJsonReport(),
      imagens: 'capas_embutidas_compactadas',
      capa_largura_max: JSON_REPORT_COVER_MAX_WIDTH,
      capa_qualidade_jpeg: JSON_REPORT_COVER_JPEG_QUALITY,
      json: 'minificado',
      app_version: 'acervo-pessoal'
    };
    const normalized = await prepareEntriesForCompactJsonReport(state.entries);
    prefsNotify('info', 'A gerar JSON leve com imagens…');
    const content = await stringifyEntriesChunked([meta].concat(normalized));
    const blob = new Blob([content], {type:'application/json;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = nextJsonReportFilename();
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    recordActivity('exported', 'backup', 'Backup do acervo', `${state.entries.length} obra(s) e ${(state.listas||[]).length} lista(s) exportada(s).`);
    prefsNotify('success', 'Exportação concluída (' + generatedAt.toLocaleString('pt-BR') + ').');
    try{ window.localStorage.setItem(EXPORT_LAST_KEY, String(Date.now())); }catch(_){}
  }catch(e){ prefsNotify('error', 'Não foi possível exportar os dados.'); }
}

function downloadFile(filename, content, mimeType){
  const blob = new Blob([content], {type: mimeType || 'text/html;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}
async function importData(file){
  if(!file) return;
  let rawText = '';
  try{
    // File.text() é mais fiável em WebViews Android modernas; o fallback
    // mantém compatibilidade com WebViews antigas e com o navegador.
    if(typeof file.text === 'function') rawText = await file.text();
    else rawText = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('read error'));
      reader.readAsText(file, 'UTF-8');
    });
  }catch(e){ prefsNotify('error', 'Erro ao ler o arquivo.'); return; }
  let parsed;
  try{
    // Remove BOM, que aparece em alguns ficheiros exportados no Android.
    parsed = JSON.parse(String(rawText).replace(/^\uFEFF/, '').trim());
  }catch(e){ prefsNotify('error', 'Arquivo inválido: não é um JSON válido.'); return; }
  // Aceita também backups que tenham sido envolvidos por um objeto por outro
  // gestor de ficheiros, sem mudar o formato normal exportado pela app.
  if(!Array.isArray(parsed) && parsed && typeof parsed === 'object'){
    parsed = Array.isArray(parsed.itens) ? parsed.itens
      : Array.isArray(parsed.entries) ? parsed.entries
      : Array.isArray(parsed.obras) ? parsed.obras : null;
  }
  if(!Array.isArray(parsed)){ prefsNotify('error', 'Formato inesperado: esperado uma lista de itens.'); return; }
  let imported = 0, replaced = 0, kept = 0, skipped = 0, listasImp = 0;
  parsed.forEach(item => {
      if(item && typeof item === 'object' && item.__meta){
        // Metadata do relatório — restaura listas personalizadas se existirem.
        if(typeof item.foto_perfil === 'string' && item.foto_perfil.startsWith('data:image/')){
          userProfile = Object.assign({}, userProfile, {foto:item.foto_perfil, avatar:null});
          saveProfile(userProfile);
          renderProfileAvatarPreview(userProfile.foto, userProfile.avatar);
        }
        if(Array.isArray(item.capas_desfocadas_ids)){
          const mergedBlurIds = normalizeCoverBlurIds(state.capasDesfocadasIds.concat(item.capas_desfocadas_ids));
          if(mergedBlurIds.length !== normalizeCoverBlurIds(state.capasDesfocadasIds).length ||
             mergedBlurIds.some((id,index) => id !== state.capasDesfocadasIds[index])){
            state.capasDesfocadasIds = mergedBlurIds;
            persistCoverBlurStateImmediately();
            persistUiStateImmediately();
          }
        }
        if(Array.isArray(item.listas)){
          if(!Array.isArray(state.listas)) state.listas = [];
          item.listas.forEach(l => {
            if(!l || !l.id || !l.nome) return;
            const exists = state.listas.some(x => x.id === l.id);
            if(exists) return;
            state.listas.push({
              id: l.id,
              nome: String(l.nome).slice(0,120),
              categoria: l.categoria || 'todos',
              defaultCat: l.defaultCat || null,
              defaultSub: l.defaultSub || null,
              obraIds: Array.isArray(l.obraIds) ? l.obraIds.slice() : [],
              criado_em: l.criado_em || Date.now()
            });
            listasImp++;
          });
        }
        return;
      }
      if(!item || typeof item !== 'object' || !item.titulo || !CATEGORY_META[item.categoria]){ skipped++; return; }

      // Relatórios antigos podem não ter data de edição. Nesse caso, são
      // válidos para adicionar obras novas, mas nunca vencem uma obra local
      // apenas por terem sido importados neste momento.
      const incomingEdit = entryEditTimestamp(item);
      const incoming = normalizeEntryEditDates(Object.assign({}, item, {
        id: item.id || uuid(),
        titulo: String(item.titulo).slice(0,200),
        status: STATUS_META[item.status] ? item.status : 'em_andamento',
        status_oficial: (temStatusOficial(item.categoria) && OFFICIAL_STATUS_META[item.status_oficial]) ? item.status_oficial : null,
        generos: Array.isArray(item.generos) ? item.generos : [],
        criado_em: item.criado_em || incomingEdit,
        atualizado_em: item.atualizado_em || incomingEdit,
        ultima_edicao_obra: item.ultima_edicao_obra || item.atualizado_em || item.criado_em || incomingEdit,
        ultima_edicao_comentarios: item.ultima_edicao_comentarios || item.atualizado_em || item.criado_em || incomingEdit
      }));
      const dupKey = entryDuplicateKey(incoming);
      const sameIdIndex = incoming.id ? state.entries.findIndex(e => e.id === incoming.id) : -1;
      const sameKeyIndex = dupKey ? state.entries.findIndex(e => entryDuplicateKey(e) === dupKey) : -1;
      const matchIndex = sameIdIndex >= 0 ? sameIdIndex : sameKeyIndex;

      if(matchIndex < 0){
        state.entries.push(incoming);
        imported++;
        return;
      }

      const existing = normalizeEntryEditDates(state.entries[matchIndex]);
      const existingEdit = entryEditTimestamp(existing);
      if(incomingEdit > existingEdit){
        // Mantém o ID local: listas e histórico continuam ligados à mesma obra.
        state.entries[matchIndex] = Object.assign({}, incoming, {id: existing.id || incoming.id});
        replaced++;
      } else {
        kept++;
      }
    });
    // Grava imediatamente (em vez de depender apenas do temporizador de 250 ms),
    // porque o APK pode suspender a WebView logo após o seletor de ficheiros fechar.
    if(_persistTimer){ clearTimeout(_persistTimer); _persistTimer = null; }
    await _persistEntriesNow();
    if(listasImp > 0 && typeof persistListas === 'function') await persistListas();
    recordActivity('imported', 'backup', 'Importação de backup', `${imported} adicionada(s), ${replaced} atualizada(s)${skipped ? ` e ${skipped} ignorada(s)` : ''}.`);
    renderMain();
    const listaMsg = listasImp > 0 ? `, ${listasImp} lista(s) restaurada(s)` : '';
    const resultMsg = `Importação concluída: ${imported} adicionadas, ${replaced} actualizadas, ${kept} mantidas${skipped ? `, ${skipped} ignoradas` : ''}${listaMsg}.`;
    prefsNotify(skipped > 0 ? 'warning' : 'success', resultMsg);
}

/* ===================== PÁGINA DE LISTA AUTÓNOMA ===================== */
let listPageState = {
  isOpen: false,
  selectedIds: new Set(),
  listMode: false
};

function openListPage(){
  cancelScrollNavAnimations();
  cancelPageScrollRestores();
  listPageState.isOpen = true;
  listPageState.selectedIds.clear();
  listPageState.listMode = false;
  const overlay = document.getElementById('listPageOverlay');
  overlay.classList.add('is-active');
  document.body.style.overflow = 'hidden';
  updateListPageSelectionBar();
  renderListPage();
  restorePendingListPageScroll();
}

function closeListPage(){
  cancelScrollNavAnimations();
  cancelPageScrollRestores();
  const listPageContent = document.getElementById('listPageContent');
  if(listPageContent){
    _listPageScrollMemory = listPageContent.scrollTop;
    _pendingListPageScrollTarget = { scrollY:listPageContent.scrollTop };
    if(typeof persistUiState === 'function') persistUiState();
  }
  listPageState.isOpen = false;
  listPageState.selectedIds.clear();
  listPageState.listMode = false;
  document.getElementById('listPageOverlay').classList.remove('is-active');
  document.getElementById('listPageSelectionBar').classList.remove('is-active');
  updateListPageSelectionBar();
  document.body.style.overflow = '';
}

function toggleListPageItem(entryId){
  if(listPageState.selectedIds.has(entryId)){
    listPageState.selectedIds.delete(entryId);
  } else {
    listPageState.selectedIds.add(entryId);
  }
  updateListPageSelectionBar();
  updateListPageItemUI(entryId);
}

function updateListPageSelectionBar(){
  const count = listPageState.selectedIds.size;
  const headerCancel = document.getElementById('btnListPageCancelSelectionHeader');
  const headerStart = document.getElementById('btnListPageStartSelection');
  if(listPageState.listMode || count > 0){
    document.getElementById('listPageSelectionBar').classList.add('is-active');
    if(headerStart) headerStart.style.display = 'none';
    if(headerCancel) headerCancel.style.display = 'inline-flex';
    document.getElementById('listPageSelectCount').textContent = count;
    listPageState.listMode = true;
  } else {
    document.getElementById('listPageSelectionBar').classList.remove('is-active');
    if(headerStart) headerStart.style.display = 'inline-flex';
    if(headerCancel) headerCancel.style.display = 'none';
    listPageState.listMode = false;
  }
}

function updateListPageItemUI(entryId){
  const row = Array.from(document.querySelectorAll('.obra-list-item[data-entry-id]')).find(item => item.dataset.entryId === entryId);
  if(row){
    const checkbox = row.querySelector('.checkbox-indicator');
    if(listPageState.selectedIds.has(entryId)){
      if(checkbox) checkbox.classList.add('is-checked');
      row.classList.add('is-selected');
    } else {
      if(checkbox) checkbox.classList.remove('is-checked');
      row.classList.remove('is-selected');
    }
  }
}

function renderListPage(){
  const container = document.getElementById('listPageContent');
  const entries = state.entries || [];
  
  if(entries.length === 0){
    container.innerHTML = '<div class="empty-state"><svg class="icon"><use href="#i-shelf"/></svg><h3>Sem obras</h3><p>Seu acervo está vazio. Adicione suas primeiras obras!</p></div>';
    updateListPageSelectionBar();
    return;
  }

  let html = '';
  entries.forEach(entry => {
    const isSelected = listPageState.selectedIds.has(entry.id);
    const coverSrc = entry.capa_base64 || entry.capa_url;
    const meta = CATEGORY_META[entry.categoria] || {label:entry.categoria, color:'var(--c-gold)', icon:'i-shelf'};
    const prog = progressoTexto(entry);
    
    const _lpSubInfo = entrySubcategoryInfo(entry);
    const _lpCatLabel = (_lpSubInfo && _lpSubInfo.key !== 'sem-subcategoria') ? meta.label + ' ' + _lpSubInfo.short : meta.label;
    const _lpColor = (_lpSubInfo && _lpSubInfo.key !== 'sem-subcategoria' && _lpSubInfo.color) ? _lpSubInfo.color : meta.color;
    html += `<div class="obra-list-item obra-list-item--plain ${isSelected ? 'is-selected' : ''}" data-entry-id="${entry.id}" style="--cat-color:${_lpColor}">
    
      ${listPageState.listMode ? `<span class="checkbox-indicator is-visible ${isSelected ? 'is-checked' : ''}" aria-hidden="true"><svg class="icon"><use href="#i-check-square"/></svg></span>` : ''}
      ${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" class="obra-thumbnail" loading="lazy" decoding="async">` : `<div class="obra-thumbnail-placeholder"></div>`}
      <div class="obra-info">
        <div class="obra-title">${escapeHtml(entry.titulo)}</div>
        <div class="obra-meta">${escapeHtml(_lpCatLabel)}${entry.ano ? ' · ' + escapeHtml(entry.ano) : ''}${prog ? ' · ' + escapeHtml(prog) : ''}${typeof entry.nota === 'number' ? ' · ★ ' + entry.nota.toFixed(1).replace('.0','') : ''}</div>
      </div>
      <div class="obra-row-actions">
        <button class="icon-btn" data-action="add-to-list-page" aria-label="Adicionar a lista" title="Adicionar a uma lista"><svg class="icon"><use href="#i-folder-plus"/></svg></button>
        <button class="icon-btn" data-action="edit-list-page" aria-label="Editar"><svg class="icon"><use href="#i-edit"/></svg></button>
        <button class="icon-btn danger" data-action="delete-list-page" aria-label="Apagar"><svg class="icon"><use href="#i-trash"/></svg></button>
      </div>
    </div>`;
  });

  container.innerHTML = html;
  container.querySelectorAll('.obra-list-item').forEach(row => {
    const entryId = row.dataset.entryId;
    row.addEventListener('click', (ev) => {
      if(ev.target.closest('.obra-row-actions')) return;
      if(listPageState.listMode){ toggleListPageItem(entryId); return; }
      openDetailModal(entryId);
      closeListPage();
    });
    const addToListBtn = row.querySelector('[data-action="add-to-list-page"]');
    if(addToListBtn) addToListBtn.addEventListener('click', (ev) => { ev.stopPropagation(); openListSelectorModalForMultiple([entryId]); });
    const editBtn = row.querySelector('[data-action="edit-list-page"]');
    if(editBtn) editBtn.addEventListener('click', (ev) => { ev.stopPropagation(); openFormModal(entryId); });
    const deleteBtn = row.querySelector('[data-action="delete-list-page"]');
    if(deleteBtn) deleteBtn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const entry = state.entries.find(e => e.id === entryId);
      if(!entry) return;
      openConfirmModal('Apagar obra', `Remover <strong>${escapeHtml(entry.titulo)}</strong> do acervo? Esta ação não pode ser desfeita.`, () => {
        state.entries = state.entries.filter(e => e.id !== entryId);
        state.listas.forEach(lista => { lista.obraIds = lista.obraIds.filter(id => id !== entryId); });
        cleanupEmptyCustomLists();
        recordEntriesActivity('deleted', [entry], 'Obra apagada do acervo.');
        persistEntries();
        persistListas();
        renderListPage();
        renderMain();
        showToast('success', 'Obra apagada.');
      });
    });
  });
}
function startListPageSelection(){
  if(!(state.entries || []).length){ showToast('warning', 'Não há obras para selecionar.'); return; }
  listPageState.listMode = true;
  updateListPageSelectionBar();
  renderListPage();
}
function cancelListPageSelection(){
  listPageState.selectedIds.clear();
  listPageState.listMode = false;
  updateListPageSelectionBar();
  renderListPage();
}

/* ===================== EVENTOS ===================== */
function bindEvents(){
  document.getElementById('searchInput').addEventListener('input', debounce((e) => { if(state.busca === e.target.value) return; state.busca = e.target.value; renderMain(); }, 320));
  document.addEventListener('input', (e) => {
    if(e.target && e.target.id) updateSearchClearButtons(document);
  });
  document.addEventListener('click', (e) => {
    const btn = e.target.closest && e.target.closest('.search-clear-btn[data-clear-target]');
    if(!btn) return;
    const input = document.getElementById(btn.dataset.clearTarget);
    if(!input) return;
    input.value = '';
    updateSearchClearButtons(document);
    input.dispatchEvent(new Event('input', {bubbles:true}));
    input.focus();
  });
  window.addEventListener('resize', debounce(scheduleViewportVars, 80));
  window.addEventListener('orientationchange', scheduleViewportVars);
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize', scheduleViewportVars);
    window.visualViewport.addEventListener('scroll', scheduleViewportVars);
  }
  window.addEventListener('pageshow', (ev) => {
    // pageshow com persisted=true é a restauração do BFCache: o navegador
    // já trouxe o DOM e o scroll de volta. Fazer render aqui desmonta essa
    // restauração e produz o pisca precisamente ao regressar à página.
    reloadPersistedState(false);
  });
  document.addEventListener('visibilitychange', () => {
    if(document.visibilityState === 'hidden'){
      if(_persistTimer){
        clearTimeout(_persistTimer);
        _persistTimer = null;
        _persistEntriesNow();
      }
      persistListas();
      // Grava a posição de rolagem AGORA, de forma imediata (sem esperar o
      // debounce de 300ms de persistUiState) — o app pode ser morto pelo
      // sistema poucos instantes depois de ir para segundo plano, e sem
      // isto a última posição rolada podia nunca chegar a ser salva.
      try{ writePersistedJson(nsKey(APP_STATE_STORAGE_KEY), getUiStateSnapshot()); }catch(_){}
      return;
    }
    // O DOM continua intacto ao voltar de outra aplicação/aba; não o
    // re-renderizar evita o flash e conserva o scroll nativo sem intervenção.
    reloadPersistedState(false);
  });
  window.addEventListener('focus', () => reloadPersistedState(false));
  // Quando a conexão volta, tenta converter capas-URL pendentes para base64 (offline-ready)
  window.addEventListener('online', () => {
    try{
      ensureReportCoversCached(null).then(() => {
        if(typeof renderMain === 'function') renderMain();
        if(typeof listPageState !== 'undefined' && listPageState.isOpen && typeof renderListPage === 'function') renderListPage();
      }).catch(()=>{});
    }catch(_){}
  });
  // Logo após carregar, tenta cachear capas pendentes (se já estiver online)
  setTimeout(() => {
    try{ ensureReportCoversCached(null).catch(()=>{}); }catch(_){}
  }, 1500);
  document.addEventListener('focusin', (ev) => {
    const el = ev.target;
    if(!el || !el.matches || !el.matches('input, textarea, select')) return;
    prepareTextInputs(document);
    scheduleViewportVars();
    if(el.closest('#lockOverlay')){
      setTimeout(() => { try{ keepLockFieldVisible(el); }catch(_){} }, 0);
      return;
    }
    setTimeout(() => {
      try{ el.scrollIntoView({block:'center', inline:'nearest', behavior:'smooth'}); }catch(_){}
    }, 260);
  });
  document.getElementById('btnNew').addEventListener('click', () => openFormModal(null));
  document.getElementById('btnStats').addEventListener('click', () => { if(state.view !== 'estatisticas' && window.__pushNav) window.__pushNav(); state.view = 'estatisticas'; renderMain(); });
  // btnOpenListPage removido — a página de lista autônoma continua acessível via outras navegações.
  function toggleSidebarOpen(){
    const sidebar = document.getElementById('sidebar');
    const willOpen = !sidebar.classList.contains('is-open');
    sidebar.classList.toggle('is-open', willOpen);
    if(willOpen){
      // Sobrepõe overlays de página/lista (z-index 300).
      sidebar.style.zIndex = '410';
      sidebar.style.display = 'block';
      sidebar.style.position = 'fixed';
      sidebar.style.left = '0';
      sidebar.style.top = '60px';
      sidebar.style.width = '240px';
      sidebar.style.height = 'calc(100vh - 60px)';
      sidebar.style.overflowY = 'auto';
      const backdrop = document.createElement('div');
      backdrop.id = 'sidebarBackdrop';
      backdrop.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:405;';
      document.body.appendChild(backdrop);
      const close = () => {
        sidebar.classList.remove('is-open');
        sidebar.removeAttribute('style');
        backdrop.remove();
      };
      backdrop.addEventListener('click', close);
    } else {
      sidebar.removeAttribute('style');
      const backdrop = document.getElementById('sidebarBackdrop');
      if(backdrop) backdrop.remove();
    }
  }
  document.getElementById('btnToggleSidebar').addEventListener('click', toggleSidebarOpen);
  const _plSidebarToggle = document.getElementById('pageOverlaySidebarToggle');
  if(_plSidebarToggle) _plSidebarToggle.addEventListener('click', toggleSidebarOpen);
  const _lpSidebarToggle = document.getElementById('listPageSidebarToggle');
  if(_lpSidebarToggle) _lpSidebarToggle.addEventListener('click', toggleSidebarOpen);
  function closeSidebarIfOpen(){
    const sidebar = document.getElementById('sidebar');
    if(!sidebar.classList.contains('is-open')) return;
    sidebar.classList.remove('is-open');
    sidebar.removeAttribute('style');
    const backdrop = document.getElementById('sidebarBackdrop');
    if(backdrop) backdrop.remove();
  }
  document.addEventListener('click', (e) => {
    const sidebar = document.getElementById('sidebar');
    if(!sidebar.classList.contains('is-open')) return;
    if(sidebar.contains(e.target)) return;
    if(document.getElementById('btnToggleSidebar').contains(e.target)) return;
    const pl = document.getElementById('pageOverlaySidebarToggle'); if(pl && pl.contains(e.target)) return;
    const lp = document.getElementById('listPageSidebarToggle'); if(lp && lp.contains(e.target)) return;
    const bd = document.getElementById('sidebarBackdrop'); if(bd && bd.contains(e.target)) return;
    closeSidebarIfOpen();
  });
  bindPrefsModal();
  bindProfileModal();

  document.getElementById('sidebar').addEventListener('click', (e) => {
    const clearBtn = e.target.closest('[data-action="clear-history"]');
    if(clearBtn){ e.stopPropagation(); state.historico = []; saveHistorico(); renderSidebar(); return; }
    const histBtn = e.target.closest('[data-history-id]');
    if(histBtn){
      closeSidebarIfOpen();
      openDetailModal(histBtn.dataset.historyId);
      return;
    }
    const navBtn = e.target.closest('.nav-item'); if(!navBtn) return;
    closeSidebarIfOpen();
    if(navBtn.dataset.view === 'estatisticas'){ if(state.view !== 'estatisticas' && window.__pushNav) window.__pushNav(); state.view = 'estatisticas'; renderMain(); return; }
    if(navBtn.dataset.view === 'listas'){ if(state.view !== 'listas' && window.__pushNav) window.__pushNav(); state.view = 'listas'; exitSelectionMode(); renderMain(); return; }
    if(navBtn.dataset.view === 'historico'){ if(state.view !== 'historico' && window.__pushNav) window.__pushNav(); state.view = 'historico'; exitSelectionMode(); renderMain(); return; }
    if(navBtn.dataset.view === 'favoritos'){ if(state.view !== 'favoritos' && window.__pushNav) window.__pushNav(); state.view = 'favoritos'; exitSelectionMode(); renderMain(); return; }
    fastSwitchCategoria(navBtn.dataset.cat);
  });
  document.getElementById('mobileCatBar').addEventListener('click', (e) => {
    const btn = e.target.closest('.chip-toggle'); if(!btn) return;
    fastSwitchCategoria(btn.dataset.cat);
  });

  document.getElementById('entryForm').addEventListener('submit', handleFormSubmit);
  document.getElementById('formModalClose').addEventListener('click', closeFormModal);
  document.getElementById('formCancelBtn').addEventListener('click', closeFormModal);
  document.getElementById('addEntrySourceBtn').addEventListener('click', () => {
    const container = document.getElementById('entrySourcesContainer');
    if(!container) return;
    const row = document.createElement('div');
    row.className = 'entry-source-row';
    row.innerHTML = '<input type="text" name="entryFonte" maxlength="120" lang="pt-BR" inputmode="text" autocomplete="off" autocorrect="on" autocapitalize="sentences" spellcheck="true" aria-label="Fonte"><button type="button" class="icon-btn danger" data-remove-entry-source aria-label="Remover fonte"><svg class="icon"><use href="#i-trash"/></svg></button>';
    container.appendChild(row);
    prepareTextInputs(row);
    row.querySelector('input').focus();
  });
  document.getElementById('entrySourcesContainer').addEventListener('click', (e) => {
    const remove = e.target.closest('[data-remove-entry-source]');
    if(remove) remove.closest('.entry-source-row').remove();
  });

  /* ============================================================
     BUGFIX: botões Cancelar / Atualizar / Fechar do formulário
     ------------------------------------------------------------
     Sintoma reportado: ao tocar em "Cancelar" ou "Atualizar registro"
     (rodapé do modal de cadastro), o toque estava a ACTIVAR o campo
     de gêneros ou a abrir a lista de gêneros — mesmo o utilizador
     não os tendo tocado.

     Causa: quando o campo de gêneros está focado, o teclado
     personalizado está aberto e a caixa de sugestões está visível.
     Ao tocar num botão do rodapé:
       - o layout reflowa (o teclado fecha, o modal sobe);
       - eventos pointer/click podem ser reprocessados como se
         tivessem ocorrido sobre o input/lista de gêneros
         (ghost click / event delegation).

     Correção: em fase de CAPTURA (antes de qualquer outro listener
     bubbling do documento), interceptamos o toque nestes botões e:
       1. Fechamos a lista de gêneros e a caixa de sugestões.
       2. Fazemos blur no input de gêneros.
       3. Escondemos o teclado personalizado.
       4. Paramos a propagação do evento — o handler nativo do botão
          continua a executar normalmente (o próprio botão recebe o
          click), mas nada mais reage a este toque.
     ============================================================ */
  (function armModalActionButtons(){
    /* Correção definitiva:
       - Ao tocar Cancelar/Atualizar/Fechar com o teclado aberto, o
         layout reflowa entre pointerdown e click e o click original
         chegava a outro elemento (ou nunca aos handlers do botão).
       - Resultado: "Atualizar" só fechava o teclado; "Cancelar"
         acabava por focar o input de gêneros e reabrir o teclado.
       Solução: DECIDIMOS no pointerdown — fechamos teclado/sugestões
       e disparamos a ação manualmente. Bloqueamos todos os eventos
       subsequentes (touch/mouse/click) para eliminar cliques-fantasma. */
    const neutralizeGeneros = () => {
      try{ closeGenreListMode(); }catch(_){ }
      try{ closeGenreSuggestBox(); }catch(_){ }
      const gi = document.getElementById('f_generos');
      if(gi){ try{ gi.blur(); }catch(_){ } }
      const ae = document.activeElement;
      if(ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA')){
        try{ ae.blur(); }catch(_){ }
      }
      if(window.__ckb && typeof window.__ckb.hide === 'function'){
        try{ window.__ckb.hide(); }catch(_){ }
      }
    };
    const submitEntryForm = () => {
      const form = document.getElementById('entryForm');
      if(!form) return;
      if(form.requestSubmit){
        try{ form.requestSubmit(); return; }catch(_){ }
      }
      form.dispatchEvent(new Event('submit', { bubbles:true, cancelable:true }));
    };
    const arm = (el, action) => {
      if(!el || el.__armedModalAction) return;
      el.__armedModalAction = true;
      let firing = false;
      let swallowPointerClick = false;
      let swallowPointerClickTimer = null;
      const fire = (e) => {
        if(firing) return;
        if(e.pointerType === 'mouse' && e.button != null && e.button !== 0) return;
        firing = true;
        swallowPointerClick = true;
        if(swallowPointerClickTimer) clearTimeout(swallowPointerClickTimer);
        swallowPointerClickTimer = setTimeout(() => {
          swallowPointerClick = false;
          swallowPointerClickTimer = null;
        }, 900);
        try{ e.preventDefault(); }catch(_){ }
        try{ e.stopImmediatePropagation(); }catch(_){ e.stopPropagation && e.stopPropagation(); }
        neutralizeGeneros();
        setTimeout(() => {
          try{ action(); }catch(_){ }
          finally{ firing = false; }
        }, 0);
      };
      el.addEventListener('pointerdown', fire, true);
      // Engolir eventos subsequentes para impedir cliques-fantasma
      // (o click nativo do botão não deve disparar — já executámos a ação).
      const swallow = (e) => {
        try{ e.preventDefault(); }catch(_){ }
        try{ e.stopImmediatePropagation(); }catch(_){ e.stopPropagation && e.stopPropagation(); }
      };
      const swallowPointerGeneratedClick = (e) => {
        // Enter, Espaço e tecnologias assistivas geram clicks confiáveis
        // sem pointerdown; esses clicks devem seguir o handler normal.
        if(!swallowPointerClick || (e.isTrusted && e.detail === 0)) return;
        swallowPointerClick = false;
        if(swallowPointerClickTimer){
          clearTimeout(swallowPointerClickTimer);
          swallowPointerClickTimer = null;
        }
        swallow(e);
      };
      el.addEventListener('keydown', (e) => {
        if(!e.repeat && (e.key === 'Enter' || e.key === ' ')){
          swallowPointerClick = false;
          if(swallowPointerClickTimer){
            clearTimeout(swallowPointerClickTimer);
            swallowPointerClickTimer = null;
          }
        }
      }, true);
      el.addEventListener('mousedown',  swallow, { capture:true });
      el.addEventListener('mouseup',    swallow, { capture:true });
      el.addEventListener('pointerup',  swallow, { capture:true });
      el.addEventListener('touchstart', swallow, { capture:true, passive:false });
      el.addEventListener('touchend',   swallow, { capture:true, passive:false });
      el.addEventListener('click',      swallowPointerGeneratedClick, { capture:true });
    };
    arm(document.getElementById('formCancelBtn'),  () => closeFormModal());
    arm(document.getElementById('formSubmitBtn'),  submitEntryForm);
    arm(document.getElementById('formModalClose'), () => closeFormModal());
  })();

  document.getElementById('f_categoria').addEventListener('change', (e) => {
    state.formUserChangedCategory = true;
    const categoria = e.target.value;
    const categoriaAnterior = e.target.dataset.prevCategoria;
    // Só zera o progresso (capítulos/volumes/temporadas) quando a nova
    // categoria pertence a uma família diferente da anterior. Entre
    // categorias parecidas (ex: manga -> manhwa, anime -> desenho,
    // novel -> livro) o progresso já preenchido é preservado.
    if(!state.builder || !mesmaFamiliaCategoria(categoriaAnterior, categoria)){
      state.builder = defaultBuilder();
    }
    e.target.dataset.prevCategoria = categoria;
    renderProgressBuilder(categoria);
    renderPrimarySubtypeField(categoria, null);
    renderBonusFields(categoria, null);
    prepareTextInputs(document.getElementById('entryForm'));
    toggleStatusFieldVisibility(categoria);
    toggleOfficialStatusFieldVisibility(categoria);
    toggleDateFieldsVisibility(categoria);
    setOnlineMetaStatus('', ''); setOnlineMetaOptionsAvailable(false); state.lastMetadataResults = [];
  });
  document.getElementById('f_titulo').addEventListener('input', () => {
    setOnlineMetaStatus('', ''); setOnlineMetaOptionsAvailable(false); state.lastMetadataResults = [];
  });
  setupGenreSuggestBox();
  document.getElementById('btnBuscarDadosOnline').addEventListener('click', () => buscarDadosOnlineFormulario({force:true}));
  document.getElementById('btnCancelarDadosOnline').addEventListener('click', resetCadastroForm);
  const _verOpcoesBtn = document.getElementById('btnVerOpcoesOnline');
  if(_verOpcoesBtn) _verOpcoesBtn.addEventListener('click', async () => {
    if((state.lastMetadataResults || []).length > 0){
      openMetadataPicker();
      return;
    }
    await buscarDadosOnlineFormulario({force:true, openOptions:true});
    if((state.lastMetadataResults || []).length === 0) openMetadataPicker();
  });
  const _mpClose = document.getElementById('metadataPickerClose');
  if(_mpClose) _mpClose.addEventListener('click', closeMetadataPicker);
  const _mpCancel = document.getElementById('metadataPickerCancel');
  if(_mpCancel) _mpCancel.addEventListener('click', closeMetadataPicker);
  const _mpBd = document.getElementById('metadataPickerBackdrop');
  if(_mpBd) _mpBd.addEventListener('click', _backdropTapHandler(closeMetadataPicker));
  document.getElementById('f_status').addEventListener('change', () => {
    const categoria = document.getElementById('f_categoria').value;
    const statusVal = document.getElementById('f_status').value;
    const isPretendo = statusVal === 'pretendo_ver';
    const lbl = document.getElementById('lbl_progresso_simples');
    const inp = document.getElementById('f_progresso_simples');
    if(['manga','manhua','manhwa'].includes(categoria)){
      if(lbl){
        if(statusVal === 'concluido') lbl.textContent = 'Total de capítulos *';
        else if(isPretendo) lbl.textContent = 'Capítulos lidos (0 = ainda não comecei) *';
        else lbl.textContent = 'Último capítulo lido *';
      }
      if(inp){
        inp.min = '0';
        if(isPretendo && Number(inp.value) <= 0) inp.value = '0';
        else if(!isPretendo && Number(inp.value) <= 0) inp.value = '1';
        state.builder.progresso_simples = Number(inp.value);
      }
    } else if(categoria === 'livro'){
      if(lbl){
        if(statusVal === 'concluido') lbl.textContent = 'Total de páginas lidas *';
        else if(isPretendo) lbl.textContent = 'Páginas lidas (0 = ainda não comecei) *';
        else lbl.textContent = 'Página atual *';
      }
      if(inp){
        inp.min = '0';
        if(isPretendo && Number(inp.value) <= 0) inp.value = '0';
        else if(!isPretendo && Number(inp.value) <= 0) inp.value = '1';
        state.builder.progresso_simples = Number(inp.value);
      }
    }
  });
  document.getElementById('f_nota_range').addEventListener('input', (e) => { e.target.dataset.cleared = '0'; updateNotaDisplay(); });
  document.getElementById('btnClearNota').addEventListener('click', () => { document.getElementById('f_nota_range').dataset.cleared = '1'; updateNotaDisplay(); });

  document.getElementById('f_capa_upload').addEventListener('change', (e) => handleCoverUpload(e.target.files[0]));
  document.getElementById('f_capa_url_input').addEventListener('input', debounce((e) => {
    const val = e.target.value.trim();
    if(val){ state.cover = {base64:null, url: val}; document.getElementById('f_capa_upload').value=''; }
    else if(!state.cover.base64){ state.cover = {base64:null, url:''}; }
    updateCoverPreview();
  }, 300));
  document.getElementById('btnRemoveCover').addEventListener('click', () => {
    state.cover = {base64:null, url:''};
    document.getElementById('f_capa_upload').value = '';
    document.getElementById('f_capa_url_input').value = '';
    updateCoverPreview();
  });
  document.getElementById('btnBuscarCapa').addEventListener('click', buscarCapaOnline);

  document.getElementById('progressBuilder').addEventListener('click', (e) => {
    const remCap = e.target.closest('[data-remove-cap]');
    if(remCap){ const vi = Number(remCap.dataset.volIdx), ci = Number(remCap.dataset.capIdx); if(state.builder.volumes[vi]) { state.builder.volumes[vi].capitulos_lista.splice(ci,1); if(state.builder.volumes[vi].capitulos_lista.length === 0) state.builder.volumes[vi].capitulos = 0; renderProgressBuilder('novel'); } return; }
    const addCap = e.target.closest('[data-add-cap]');
    if(addCap){
      const vi = Number(addCap.dataset.volIdx);
      if(state.builder.volumes[vi]){
        if(!state.builder.volumes[vi].capitulos_lista) state.builder.volumes[vi].capitulos_lista = [];
        const ci = state.builder.volumes[vi].capitulos_lista.length;
        const newCap = {nome:'', quantidade:null};
        state.builder.volumes[vi].capitulos_lista.push(newCap);
        // Inserção cirúrgica — não re-renderiza o builder todo
        const capsList = document.getElementById(`capsList_${vi}`);
        if(capsList){
          const tmp = document.createElement('div');
          tmp.innerHTML = capituloRowHtml(newCap, vi, ci);
          const newRow = tmp.firstElementChild;
          capsList.appendChild(newRow);
          setTimeout(() => newRow.scrollIntoView({block:'nearest', behavior:'smooth'}), 30);
          // Actualiza o resumo do volume
          const sum = capsList.closest('.season-card')?.querySelector('.season-summary');
          if(sum){ sum.textContent = statusLabel(state.builder.volumes[vi].status) + ' · ' + _volumeSummaryFull(state.builder.volumes[vi]); }
        }
      }
      return;
    }
    const remIndep = e.target.closest('[data-remove-indep]');
    if(remIndep){ const ii = Number(remIndep.dataset.indepIdx); state.builder.extras_independentes.splice(ii,1); const cat = document.getElementById('f_categoria').value; renderProgressBuilder(cat); return; }
    const remExtra = e.target.closest('[data-remove-extra]');
    if(remExtra){ const si = Number(remExtra.dataset.seasonIdx), ei = Number(remExtra.dataset.extraIdx); state.builder.temporadas[si].extras.splice(ei,1); const cat = document.getElementById('f_categoria').value; renderProgressBuilder(cat); return; }
    const remSeason = e.target.closest('[data-remove-season]');
    if(remSeason){ const si = Number(remSeason.dataset.removeSeason); state.builder.temporadas.splice(si,1); const cat = document.getElementById('f_categoria').value; renderProgressBuilder(cat); return; }
    const remVolume = e.target.closest('[data-remove-volume]');
    if(remVolume){ const vi = Number(remVolume.dataset.removeVolume); state.builder.volumes.splice(vi,1); state.builder.volumes.forEach((v,i) => { if(i >= vi && /^Volume\s+\d+$/.test(v.nome||'') && parseInt((v.nome||'').match(/\d+$/)[0]) === i+2) v.nome = 'Volume ' + (i+1); }); renderProgressBuilder('novel'); return; }
    const addExtra = e.target.closest('[data-add-extra]');
    if(addExtra){
      const si = Number(addExtra.dataset.seasonIdx);
      const tipo = addExtra.dataset.addExtra;
      const newEx = {tipo, nome:'', quantidade:null};
      state.builder.temporadas[si].extras.push(newEx);
      // Ordena in-place (OVA/Extra antes de Filme)
      const sorted = sortExtras(state.builder.temporadas[si].extras);
      state.builder.temporadas[si].extras.splice(0, state.builder.temporadas[si].extras.length, ...sorted);
      state.builder.temporadas[si].aberta = true;
      // Atualiza só a extras-list da temporada — sem reconstruir o builder todo
      const seasonCards = document.querySelectorAll('#seasonsList .season-card');
      const card = seasonCards[si];
      if(card){
        card.querySelector('.season-body')?.classList.remove('is-collapsed');
        const extrasList = card.querySelector('.extras-list');
        if(extrasList){
          extrasList.innerHTML = state.builder.temporadas[si].extras.map((ex,exi) => extraRowHtml(ex, si, exi)).join('');
          const newIdx = state.builder.temporadas[si].extras.findIndex(x => x === newEx);
          const targetRow = extrasList.querySelectorAll('.extra-row')[newIdx >= 0 ? newIdx : extrasList.querySelectorAll('.extra-row').length - 1];
          if(targetRow) setTimeout(() => targetRow.scrollIntoView({block:'nearest', behavior:'smooth'}), 30);
        }
      }
      return;
    }
    const toggle = e.target.closest('[data-toggle-season]');
    if(toggle){
      const si = Number(toggle.dataset.toggleSeason);
      if(!Number.isNaN(si) && state.builder.temporadas[si]){
        const wasOpen = state.builder.temporadas[si].aberta;
        state.builder.temporadas.forEach(t => { t.aberta = false; });
        state.builder.temporadas[si].aberta = !wasOpen;
        const list = toggle.closest('#seasonsList');
        if(list){
          list.querySelectorAll('.season-body').forEach((b, i) => b.classList.toggle('is-collapsed', !state.builder.temporadas[i].aberta));
          if(!wasOpen){
            const openedCard = list.querySelectorAll('.season-card')[si];
            if(openedCard) setTimeout(() => openedCard.scrollIntoView({block:'nearest', behavior:'smooth'}), 30);
          }
        }
      }
    }
    const toggleVol = e.target.closest('[data-toggle-volume]');
    if(toggleVol){
      const vi = Number(toggleVol.dataset.toggleVolume);
      if(!Number.isNaN(vi) && state.builder.volumes[vi]){
        const wasOpen = state.builder.volumes[vi].aberta;
        state.builder.volumes.forEach(v => { v.aberta = false; });
        state.builder.volumes[vi].aberta = !wasOpen;
        const list = toggleVol.closest('#volumesList');
        if(list){
          list.querySelectorAll('.season-body').forEach((b, i) => b.classList.toggle('is-collapsed', !state.builder.volumes[i].aberta));
          if(!wasOpen){
            const openedCard = list.querySelectorAll('.season-card')[vi];
            if(openedCard) setTimeout(() => openedCard.scrollIntoView({block:'nearest', behavior:'smooth'}), 30);
          }
        }
      }
    }
  });
  document.getElementById('progressBuilder').addEventListener('input', (e) => {
    const sf = e.target.closest('[data-season-field]');
    if(sf){
      const si = Number(sf.dataset.seasonIdx); const field = sf.dataset.seasonField;
      state.builder.temporadas[si][field] = field === 'episodios' ? Number(sf.value) : sf.value;
      const card = sf.closest('.season-card'); const summary = card ? card.querySelector('.season-summary') : null;
      if(summary) summary.textContent = statusLabel(state.builder.temporadas[si].status) + ' · ' + (state.builder.temporadas[si].episodios||0) + ' ep.';
      if(field === 'status' && card){
        const lbl = card.querySelector('[data-episodios-label]');
        if(lbl) lbl.textContent = state.builder.temporadas[si].status === 'concluido' ? 'Total de episódios *' : 'Último episódio visto *';
      }
      return;
    }
    const vf = e.target.closest('[data-volume-field]');
    if(vf){
      const vi = Number(vf.dataset.volumeIdx); const field = vf.dataset.volumeField;
      state.builder.volumes[vi][field] = field === 'capitulos' ? Number(vf.value) : vf.value;
      const card = vf.closest('.season-card'); const summary = card ? card.querySelector('.season-summary') : null;
      if(summary) summary.textContent = statusLabel(state.builder.volumes[vi].status) + ' · ' + capitulostotalFromLista(state.builder.volumes[vi].capitulos_lista, state.builder.volumes[vi].capitulos) + ' cap.';
      if(field === 'nome' && card){
        const titleEl = card.querySelector('.season-title');
        if(titleEl) titleEl.textContent = vf.value.trim() || `Volume ${vi+1}`;
        // mostra/oculta botão de limpar embutido no clearable-field-wrap
        const clearBtn = vf.nextElementSibling;
        if(clearBtn && clearBtn.classList.contains('input-clear-btn')) clearBtn.hidden = !vf.value.trim();
      }
      if(field === 'status' && card){
        const lbl = card.querySelector('[data-capitulos-label]');
        if(lbl) lbl.textContent = state.builder.volumes[vi].status === 'concluido' ? 'Total de capítulos *' : 'Último capítulo visto *';
      }
      return;
    }
    // Helper: bloqueia/desbloqueia o campo par dentro da mesma .extra-row
    const _mutuoNome = (row, nameEl, qtdSel) => {
      const hasNome = nameEl.value.trim() !== '';
      const qtd = row ? row.querySelector(qtdSel) : null;
      if(qtd){ qtd.disabled = hasNome; if(hasNome){ qtd.value = ''; } }
    };
    const _mutuoQtd = (row, qtdEl, nameSel) => {
      const hasQtd = qtdEl.value.trim() !== '';
      const nome = row ? row.querySelector(nameSel) : null;
      if(nome){ nome.disabled = hasQtd; if(hasQtd){ nome.value = ''; } }
    };
    const en = e.target.closest('[data-extra-name]');
    if(en){ const si=Number(en.dataset.seasonIdx),ei=Number(en.dataset.extraIdx); state.builder.temporadas[si].extras[ei].nome=en.value; if(en.value.trim()) state.builder.temporadas[si].extras[ei].quantidade=null; _mutuoNome(en.closest('.extra-row'),en,'[data-extra-qtd]'); return; }
    const eq = e.target.closest('[data-extra-qtd]');
    if(eq){ const si=Number(eq.dataset.seasonIdx),ei=Number(eq.dataset.extraIdx); state.builder.temporadas[si].extras[ei].quantidade=eq.value===''?null:Math.max(1,Number(eq.value)||0); if(eq.value.trim()) state.builder.temporadas[si].extras[ei].nome=''; _mutuoQtd(eq.closest('.extra-row'),eq,'[data-extra-name]'); return; }
    const inn = e.target.closest('[data-indep-name]');
    if(inn){ const ii=Number(inn.dataset.indepIdx); state.builder.extras_independentes[ii].nome=inn.value; if(inn.value.trim()) state.builder.extras_independentes[ii].quantidade=null; _mutuoNome(inn.closest('.extra-row'),inn,'[data-indep-qtd]'); return; }
    const inq = e.target.closest('[data-indep-qtd]');
    if(inq){ const ii=Number(inq.dataset.indepIdx); state.builder.extras_independentes[ii].quantidade=inq.value===''?null:Math.max(1,Number(inq.value)||0); if(inq.value.trim()) state.builder.extras_independentes[ii].nome=''; _mutuoQtd(inq.closest('.extra-row'),inq,'[data-indep-name]'); return; }
    const cn = e.target.closest('[data-cap-name]');
    if(cn){ const vi=Number(cn.dataset.volIdx),ci=Number(cn.dataset.capIdx); if(state.builder.volumes[vi]&&state.builder.volumes[vi].capitulos_lista[ci]!=null){ state.builder.volumes[vi].capitulos_lista[ci].nome=cn.value; if(cn.value.trim()) state.builder.volumes[vi].capitulos_lista[ci].quantidade=null; _mutuoNome(cn.closest('.extra-row'),cn,'[data-cap-qtd]'); } const card=cn.closest('.season-card'),sum=card?card.querySelector('.season-summary'):null; if(sum&&state.builder.volumes[vi]){sum.textContent=statusLabel(state.builder.volumes[vi].status)+' · '+_volumeSummaryFull(state.builder.volumes[vi]);} return; }
    const cq = e.target.closest('[data-cap-qtd]');
    if(cq){ const vi=Number(cq.dataset.volIdx),ci=Number(cq.dataset.capIdx); if(state.builder.volumes[vi]&&state.builder.volumes[vi].capitulos_lista[ci]!=null){ state.builder.volumes[vi].capitulos_lista[ci].quantidade=cq.value===''?null:Math.max(0,Number(cq.value)||0); if(cq.value.trim()) state.builder.volumes[vi].capitulos_lista[ci].nome=''; _mutuoQtd(cq.closest('.extra-row'),cq,'[data-cap-name]'); } const card=cq.closest('.season-card'),sum=card?card.querySelector('.season-summary'):null; if(sum&&state.builder.volumes[vi]){sum.textContent=statusLabel(state.builder.volumes[vi].status)+' · '+_volumeSummaryFull(state.builder.volumes[vi]);} return; }
    const cpg = e.target.closest('[data-cap-pagina]');
    if(cpg){ const vi=Number(cpg.dataset.volIdx),ci=Number(cpg.dataset.capIdx); if(state.builder.volumes[vi]&&state.builder.volumes[vi].capitulos_lista[ci]!=null){ state.builder.volumes[vi].capitulos_lista[ci].pagina=cpg.value===''?null:Math.max(1,Math.floor(Number(cpg.value)||1)); } const card=cpg.closest('.season-card'),sum=card?card.querySelector('.season-summary'):null; if(sum&&state.builder.volumes[vi]){sum.textContent=statusLabel(state.builder.volumes[vi].status)+' · '+_volumeSummaryFull(state.builder.volumes[vi]);} return; }
    if(e.target.id === 'f_progresso_simples'){ state.builder.progresso_simples = Number(e.target.value) || 0; }
  });

  // Cascata de renomeação de volumes: ao sair do campo nome, se o novo nome for "Volume N"
  // e os volumes seguintes forem sequenciais (Volume N, N+1…), actualiza-os automaticamente.
  document.getElementById('progressBuilder').addEventListener('focusout', e => {
    const vf = e.target.closest('[data-volume-field="nome"]');
    if(!vf) return;
    const vi = Number(vf.dataset.volumeIdx);
    const newName = (vf.value || '').trim();
    const m = newName.match(/^Volume\s+(\d+)$/i);
    if(!m) return;
    const N = parseInt(m[1]);
    let changed = false;
    for(let i = vi + 1; i < state.builder.volumes.length; i++){
      const v = state.builder.volumes[i];
      if(!v || !/^Volume\s+\d+$/i.test(v.nome || '')) break;
      const oldN = parseInt((v.nome || '').match(/\d+$/)[0]);
      if(oldN !== N + (i - vi - 1)) break; // sequência interrompida
      v.nome = 'Volume ' + (N + (i - vi));
      changed = true;
    }
    if(changed) renderProgressBuilder('novel');
  });

  document.getElementById('detailModalClose').addEventListener('click', closeDetailModal);
  document.getElementById('detailModalBackdrop').addEventListener('click', _backdropTapHandler(closeDetailModal));
  document.getElementById('confirmModalClose').addEventListener('click', closeConfirmModal);
  document.getElementById('confirmModalCancel').addEventListener('click', closeConfirmModal);
  document.getElementById('confirmModalBackdrop').addEventListener('click', _backdropTapHandler(closeConfirmModal));

  document.getElementById('listaForm').addEventListener('submit', handleListaFormSubmit);
  document.getElementById('listaFormModalClose').addEventListener('click', closeListaFormModal);
  document.getElementById('listaFormCancelBtn').addEventListener('click', closeListaFormModal);
  document.getElementById('listaFormModalBackdrop').addEventListener('click', _backdropTapHandler(closeListaFormModal));

  document.getElementById('obraPickerModalClose').addEventListener('click', closeObraPickerModal);
  document.getElementById('obraPickerCancelBtn').addEventListener('click', closeObraPickerModal);
  document.getElementById('obraPickerSaveBtn').addEventListener('click', () => saveObraPickerSelection(pickerTargetListaId));
  document.getElementById('obraPickerModalBackdrop').addEventListener('click', _backdropTapHandler(closeObraPickerModal));
  document.getElementById('pickerSearchInput').addEventListener('input', debounce((e) => { state.pickerBusca = e.target.value; renderObraPickerList(pickerTargetListaId); }, 200));

  document.getElementById('listSelectorModalClose').addEventListener('click', closeListSelectorModal);
  document.getElementById('listSelectorCancelBtn').addEventListener('click', closeListSelectorModal);
  document.getElementById('listSelectorSaveBtn').addEventListener('click', saveListSelectorForObra);
  document.getElementById('listSelectorModalBackdrop').addEventListener('click', _backdropTapHandler(closeListSelectorModal));

  // Event listeners para página de lista autónoma
  document.getElementById('btnCloseListPage').addEventListener('click', closeListPage);
  document.getElementById('btnListPageHistory').addEventListener('click', (e) => {
    e.stopPropagation();
    closeListPage();
    if(state.view !== 'historico' && window.__pushNav) window.__pushNav();
    state.view = 'historico';
    exitSelectionMode();
    renderMain();
  });
  document.getElementById('btnListPageStartSelection').addEventListener('click', (e) => { e.stopPropagation(); startListPageSelection(); });
  document.getElementById('btnListPageCancelSelectionHeader').addEventListener('click', (e) => { e.stopPropagation(); cancelListPageSelection(); });
  document.getElementById('btnListPageCancelSelection').addEventListener('click', (e) => { e.stopPropagation(); cancelListPageSelection(); });
  document.getElementById('btnListPageDelete').addEventListener('click', (e) => {
    e.stopPropagation();
    if(listPageState.selectedIds.size === 0){ showToast('warning', 'Selecione pelo menos uma obra.'); return; }
    openConfirmModal('Apagar obras', `Tem certeza que deseja apagar ${listPageState.selectedIds.size} obra(s)?`, () => {
      const ids = new Set(listPageState.selectedIds);
      const removedEntries = state.entries.filter(e => ids.has(e.id));
      const affectedListas = (state.listas||[]).filter(l => Array.isArray(l.obraIds) && l.obraIds.some(id => ids.has(id))).map(l => JSON.parse(JSON.stringify(l)));
      state.entries = state.entries.filter(e => !ids.has(e.id));
      state.listas.forEach(lista => { lista.obraIds = lista.obraIds.filter(id => !ids.has(id)); });
      cleanupEmptyCustomLists();
      recordEntriesActivity('deleted', removedEntries, removedEntries.length === 1 ? 'Obra apagada do acervo.' : `${removedEntries.length} obras apagadas do acervo.`);
      persistEntries();
      persistListas();
      cancelListPageSelection();
      renderMain();
      showUndoToast(removedEntries.length + ' obra(s) apagada(s).', () => {
        removedEntries.forEach(e => { if(!state.entries.some(x => x.id === e.id)) state.entries.push(e); });
        recordEntriesActivity('restored', removedEntries, removedEntries.length === 1 ? 'Obra restaurada após desfazer.' : `${removedEntries.length} obras restauradas após desfazer.`);
        affectedListas.forEach(snapLista => {
          const lista = state.listas.find(l => l.id === snapLista.id);
          if(lista){ snapLista.obraIds.forEach(id => { if(!lista.obraIds.includes(id)) lista.obraIds.push(id); }); }
          else state.listas.push(snapLista);
        });
        persistEntries(); persistListas(); renderMain();
        showToast('success', 'Obras restauradas.');
      });
    });
  });

  document.addEventListener('keydown', (e) => {
    if(e.key !== 'Escape') return;
    if(listPageState.isOpen){ closeListPage(); }
    else if(!document.getElementById('confirmModalBackdrop').hidden) closeConfirmModal();
    else if(!document.getElementById('listSelectorModalBackdrop').hidden) closeListSelectorModal();
    else if(!document.getElementById('obraPickerModalBackdrop').hidden) closeObraPickerModal();
    else if(!document.getElementById('listaFormModalBackdrop').hidden) closeListaFormModal();
    else if(!document.getElementById('detailModalBackdrop').hidden) closeDetailModal();
    else if(!document.getElementById('formModalBackdrop').hidden) closeFormModal();
    else { const r = document.getElementById('obraSearchResults'); if(r) r.classList.remove('is-open'); }
  });
  initScrollNav();
}

/* ===================== BARRA DE NAVEGAÇÃO FLUTUANTE ===================== */
function initScrollNav(){
  setupScrollNavToggle();
  setupScrollNav('mainScrollNav', 'mainScrollNavThumb', 'mainScrollNavTop', () => {
    if(true){
      return { el: document.scrollingElement || document.documentElement, useWindow: true };
    }
    return { el: document.getElementById('main'), useWindow: false };
  });
  setupScrollNav('pageOverlayScrollNav', 'pageOverlayScrollNavThumb', 'pageOverlayScrollNavTop', () => ({ el: document.getElementById('pageOverlay'), useWindow: false }));
  setupScrollNav('listPageScrollNav', 'listPageScrollNavThumb', 'listPageScrollNavTop', () => ({ el: document.getElementById('listPageContent'), useWindow: false }));
  // Barra de navegação também nos modais longos (cadastro, detalhes da obra)
  setupScrollNav('formModalScrollNav', 'formModalScrollNavThumb', 'formModalScrollNavTop', () => {
    const backdrop = document.getElementById('formModalBackdrop');
    if(!backdrop || backdrop.hasAttribute('hidden')) return { el: null, useWindow: false };
    const body = backdrop.querySelector('.modal-body');
    return { el: body, useWindow: false };
  });
  setupScrollNav('detailModalScrollNav', 'detailModalScrollNavThumb', 'detailModalScrollNavTop', () => {
    const backdrop = document.getElementById('detailModalBackdrop');
    if(!backdrop || backdrop.hasAttribute('hidden')) return { el: null, useWindow: false };
    return { el: document.getElementById('detailModalBody'), useWindow: false };
  });
}

function setupScrollNavToggle(){
  const btn = document.getElementById('scrollNavToggle');
  if(!btn || btn.dataset.bound === '1') return;
  btn.dataset.bound = '1';
  const key = 'acervo-scroll-nav-enabled-v1';

  function readEnabled(){
    if(!LOCAL_STORAGE_AVAILABLE) return true;
    try{ return window.localStorage.getItem(key) !== '0'; }
    catch(_){ return true; }
  }
  function writeEnabled(enabled){
    if(!LOCAL_STORAGE_AVAILABLE) return;
    try{ window.localStorage.setItem(key, enabled ? '1' : '0'); }
    catch(_){}
  }
  function applyEnabled(enabled){
    document.body.classList.toggle('scroll-nav-off', !enabled);
    btn.setAttribute('aria-pressed', enabled ? 'true' : 'false');
    btn.setAttribute('aria-label', enabled ? 'Ocultar barra de navegação' : 'Mostrar barra de navegação');
    btn.setAttribute('title', enabled ? 'Ocultar barra' : 'Mostrar barra');
    const mark = btn.querySelector('.scroll-nav-toggle-mark');
    if(mark) mark.textContent = enabled ? '—' : '';
  }

  applyEnabled(readEnabled());
  btn.addEventListener('click', () => {
    const enabled = document.body.classList.contains('scroll-nav-off');
    applyEnabled(enabled);
    writeEnabled(enabled);
  });
}

function setupScrollNav(navId, thumbId, topBtnId, resolveTarget){
  const nav = document.getElementById(navId);
  if(!nav) return;
  const thumb = document.getElementById(thumbId);
  const topBtn = document.getElementById(topBtnId);
  if(!nav || !thumb || !topBtn) return;
  let dragging = false;
  let recentTimer = null;
  let scrollAnimation = 0;
  let snapPressTimer = null;
  // Cada interação inaugura uma geração própria. Assim, um passe de
  // alinhamento agendado por um clique anterior nunca pode mover o conteúdo
  // depois de o utilizador já ter escolhido outro marcador.
  let navigationGeneration = 0;
  function cancelNavigation(){
    navigationGeneration += 1;
    if(scrollAnimation){
      cancelAnimationFrame(scrollAnimation);
      scrollAnimation = 0;
    }
    if(snapPressTimer){
      clearTimeout(snapPressTimer);
      snapPressTimer = null;
    }
    dragging = false;
    nav.classList.remove('is-active','is-pressed');
  }
  nav.__cancelScrollNavigation = cancelNavigation;

  // Descobre qual elemento REALMENTE rola. Antes a barra assumia um contêiner
  // fixo (ex.: #pageOverlay) que em alguns layouts/páginas não é o que rola —
  // então o polegar se movia mas a página ficava parada.
  function isScrollableEl(el){
    if(!el) return false;
    const docEl = document.scrollingElement || document.documentElement;
    if(el === docEl || el === document.body) return (el.scrollHeight - el.clientHeight) > 4;
    let oy = '';
    try{ oy = window.getComputedStyle(el).overflowY; }catch(_){ oy = ''; }
    const canScroll = oy === 'auto' || oy === 'scroll' || oy === 'overlay';
    return canScroll && (el.scrollHeight - el.clientHeight) > 4;
  }
  function pickScroller(el){
    const docEl = document.scrollingElement || document.documentElement;
    if(!el) return null;
    if(el === docEl || el === document.body) return el;
    if(isScrollableEl(el)) return el;
    const inner = Array.from(el.children || []).find(isScrollableEl);
    if(inner) return inner;
    let p = el.parentElement;
    while(p && p !== document.body){ if(isScrollableEl(p)) return p; p = p.parentElement; }
    if((docEl.scrollHeight - docEl.clientHeight) > 4) return docEl;
    return el;
  }
  function getScroller(){
    const r = resolveTarget() || { el:null, useWindow:false };
    const docEl = document.scrollingElement || document.documentElement;
    const el = pickScroller(r.el);
    return { el, useWindow: el === docEl || el === document.body };
  }
  // Rola com verificação: se o scroll suave não pegar (contêiner errado ou
  // bloqueado), aplica a posição de forma direta e, em último caso, na janela.
  function scrollScrollerTo(m, top, onSettled){
    if(!m || !m.el) return;
    const max = Math.max(0, m.scrollHeight - m.clientHeight);
    const target = Math.max(0, Math.min(top, max));
    const readNow = () => m.useWindow ? (window.pageYOffset || 0) : m.el.scrollTop;
    const before = readNow();
    if(scrollAnimation) cancelAnimationFrame(scrollAnimation);
    if(Math.abs(target - before) < 1){ update(); if(onSettled) onSettled(); return; }
    // Animação própria com duração mínima: o scroll nativo encurtava ou até
    // eliminava a transição em percursos pequenos, deixando a barra LED seca.
    const distance = Math.abs(target - before);
    // Quanto MAIOR a distância, MAIOR a velocidade: a duração cresce de forma
    // sublinear (raiz quadrada) e tem tecto, então percursos longos são
    // percorridos muito mais depressa (px/ms) sem ficarem bruscos.
    const duration = Math.max(260, Math.min(900, 200 + Math.sqrt(distance) * 9));
    const started = performance.now();
    const write = value => {
      const v = Math.round(value);
      if(m.useWindow) window.scrollTo(0, v);
      else m.el.scrollTop = v;
    };
    const frame = now => {
      const t = Math.min(1, (now - started) / duration);
      // easeInOutCubic: arranca e trava suavemente, mantendo o miolo rápido.
      const eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      write(before + (target - before) * eased);
      update();
      if(t < 1) scrollAnimation = requestAnimationFrame(frame);
      else {
        scrollAnimation = 0; write(target); update();
        if(onSettled) setTimeout(onSettled, 90);
      }
    };
    scrollAnimation = requestAnimationFrame(frame);
  }
  function metrics(){
    const { el, useWindow } = getScroller();
    if(!el) return null;
    const scrollTop = useWindow ? (window.pageYOffset || el.scrollTop || 0) : el.scrollTop;
    const scrollHeight = useWindow ? el.scrollHeight : el.scrollHeight;
    const clientHeight = useWindow ? window.innerHeight : el.clientHeight;
    return { el, useWindow, scrollTop, scrollHeight, clientHeight };
  }
  function update(){
    const m = metrics();
    if(!m){ nav.classList.remove('is-available'); return; }
     bindResolvedScroller(m.el);
    const overflow = m.scrollHeight - m.clientHeight;
    // A barra deve continuar disponível em páginas curtas: mesmo com poucas
    // obras, Topo/25/50/75/Fim precisam apontar para posições proporcionais
    // diferentes sempre que existir overflow real. A regra de alinhar o início
    // de uma linha com a barra fixa é aplicada separadamente, apenas quando há
    // pelo menos cinco linhas distintas — uma linha para cada marcador.
    // Assim, páginas curtas não ficam com alvos repetidos, padding artificial
    // ou uma barra que parece estar desativada.
    const showThreshold = 8;
    // HISTERESE: uma vez visível, só esconde se o overflow cair bem abaixo
    // do limiar de exibição — evita a barra aparecer/desaparecer sozinha
    // por causa de 1-2px de ruído enquanto o conteúdo ainda está a carregar.
    const hideThreshold = nav.classList.contains('is-available')
      ? showThreshold * 0.5
      : showThreshold;
    if(overflow < hideThreshold){ nav.classList.remove('is-available','is-active','is-recent'); return; }
    // Only show when its parent context is visible
    if(navId === 'pageOverlayScrollNav'){
      const overlay = document.getElementById('pageOverlay');
      if(!overlay || !overlay.classList.contains('is-open')){
        nav.classList.remove('is-available','is-active','is-recent');
        return;
      }
    } else if(navId === 'listPageScrollNav'){
      const overlay = document.getElementById('listPageOverlay');
      if(!overlay || !overlay.classList.contains('is-active')){ nav.classList.remove('is-available','is-active','is-recent'); return; }
    } else if(navId === 'formModalScrollNav' || navId === 'detailModalScrollNav'){
      const backdropId = navId === 'formModalScrollNav' ? 'formModalBackdrop' : 'detailModalBackdrop';
      const bd = document.getElementById(backdropId);
      if(!bd || bd.hasAttribute('hidden')){ nav.classList.remove('is-available','is-active','is-recent'); return; }
    } else {
      const listOverlay = document.getElementById('listPageOverlay');
      if(listOverlay && listOverlay.classList.contains('is-active')){ nav.classList.remove('is-available','is-active','is-recent'); return; }
      const pageOverlay = document.getElementById('pageOverlay');
      if(pageOverlay && pageOverlay.classList.contains('is-open')){ nav.classList.remove('is-available','is-active','is-recent'); return; }
      const anyModalOpen = ['formModalBackdrop','detailModalBackdrop','obraPickerModalBackdrop','listaFormModalBackdrop']
        .some(id => { const bd = document.getElementById(id); return bd && !bd.hasAttribute('hidden'); });
      if(anyModalOpen){ nav.classList.remove('is-available','is-active','is-recent'); return; }
    }
    nav.classList.add('is-available');
    const track = nav.querySelector('.scroll-nav-track');
    const trackH = track.clientHeight;
    const ratio = m.clientHeight / m.scrollHeight;
    const thumbH = Math.max(24, Math.round(trackH * ratio));
    const maxTop = trackH - thumbH;
    const pos = overflow > 0 ? (m.scrollTop / overflow) * maxTop : 0;
    thumb.style.height = thumbH + 'px';
    thumb.style.top = pos + 'px';
    const progress = overflow > 0 ? (m.scrollTop / overflow) : 0;
    const snapButtons = Array.from(nav.querySelectorAll('.scroll-nav-snap'));
    let closestSnap = null;
    let closestDelta = Infinity;
    snapButtons.forEach(btn => {
      const r = parseFloat(btn.getAttribute('data-snap') || '0');
      const delta = Math.abs((isFinite(r) ? r : 0) - progress);
      if(delta < closestDelta){ closestDelta = delta; closestSnap = btn; }
    });
    snapButtons.forEach(btn => {
      btn.classList.toggle('is-current', btn === closestSnap);
    });
  }
  function flashRecent(){
    nav.classList.add('is-recent');
    if(recentTimer) clearTimeout(recentTimer);
    recentTimer = setTimeout(() => { nav.classList.remove('is-recent'); }, 900);
  }
  // Atualizar a posição não deve reiniciar um timer/alterar a opacidade em
  // cada pixel de um gesto de toque. Isso causava sensação de "falha" na
  // barra, sobretudo em páginas pequenas. A barra só fica destacada quando
  // o utilizador inicia uma ação nela.
  function onScroll(){ update(); }
   let resolvedScroller = null;
   function bindResolvedScroller(el){
     if(!el || el === resolvedScroller) return;
     if(resolvedScroller) resolvedScroller.removeEventListener('scroll', onScroll);
     resolvedScroller = el;
     resolvedScroller.addEventListener('scroll', onScroll, {passive:true});
   }

  let docListenerBound = false;
  function attach(){
    if(docListenerBound) { update(); return; }
    docListenerBound = true;
    // Captura pega scroll de qualquer contêiner (janela, main, overlays, modais),
    // então a barra continua sincronizada mesmo se o contêiner mudar de página.
    window.addEventListener('scroll', onScroll, { passive:true });
    document.addEventListener('scroll', onScroll, { passive:true, capture:true });
  }
  attach();
  window.addEventListener('resize', () => { update(); ensureAlignmentSpace(); });
  // Re-attach on viewport changes (mobile/desktop swap)
  let lastMode = null;
  const reattach = () => {
    const mode = 'mobile';
    if(mode !== lastMode){
      lastMode = mode;
      // Remove old listeners (cheap re-init: just add again — both listeners will fire but it's idempotent on update())
      attach();
    }
    update();
    ensureAlignmentSpace();
  };
  window.addEventListener('resize', reattach);
  reattach();

  // Drag to scrub
  const track = nav.querySelector('.scroll-nav-track');
  function scrubFromClientY(clientY){
    const m = metrics(); if(!m) return;
    const rect = track.getBoundingClientRect();
    const trackH = rect.height;
    const ratio = m.clientHeight / m.scrollHeight;
    const thumbH = Math.max(24, Math.round(trackH * ratio));
    let y = clientY - rect.top - thumbH/2;
    if(y < 0) y = 0;
    const maxTop = trackH - thumbH;
    if(y > maxTop) y = maxTop;
    const overflow = m.scrollHeight - m.clientHeight;
    const newScroll = maxTop > 0 ? (y / maxTop) * overflow : 0;
    if(m.useWindow) window.scrollTo({ top:newScroll, behavior:'auto' });
    else m.el.scrollTop = newScroll;
  }
  track.addEventListener('pointerdown', (ev) => {
    // Um marcador também vive dentro do trilho. Se o evento escapar até
    // aqui, o scrubber move a página para a coordenada do toque antes de o
    // clique aplicar o marcador — exatamente o salto para o lado errado.
    if(ev.target && ev.target.closest && ev.target.closest('.scroll-nav-snap')) return;
    navigationGeneration += 1;
    if(scrollAnimation){ cancelAnimationFrame(scrollAnimation); scrollAnimation = 0; }
    dragging = true;
    nav.classList.add('is-active','is-pressed');
    track.setPointerCapture && track.setPointerCapture(ev.pointerId);
    scrubFromClientY(ev.clientY);
    ev.preventDefault();
  });
  track.addEventListener('pointermove', (ev) => { if(dragging) scrubFromClientY(ev.clientY); });
  const endDrag = (ev) => { if(!dragging) return; dragging = false; nav.classList.remove('is-active','is-pressed'); flashRecent(); try{ track.releasePointerCapture && track.releasePointerCapture(ev.pointerId); }catch(_){} };
  track.addEventListener('pointerup', endDrag);
  track.addEventListener('pointercancel', endDrag);

  function isElementVisible(el){
    return !!(el && !el.hidden && window.getComputedStyle(el).display !== 'none');
  }
  function stickyOffsetForSnap(m){
    let offset = 0;
    if(navId === 'mainScrollNav'){
      const filterbar = document.getElementById('filterbar');
      if(isElementVisible(filterbar)) offset += filterbar.getBoundingClientRect().height;
      if(m && m.useWindow){
        const catBar = document.getElementById('mobileCatBar');
        if(isElementVisible(catBar)) offset += catBar.getBoundingClientRect().height;
      }
    } else if(navId === 'pageOverlayScrollNav'){
      const overlayHeader = document.querySelector('#pageOverlay .page-overlay-header');
      if(isElementVisible(overlayHeader)) offset += overlayHeader.getBoundingClientRect().height;
      const actionBox = document.querySelector('#pageOverlayBody .action-box');
      if(isElementVisible(actionBox)){
        const actionPosition = window.getComputedStyle(actionBox).position;
        if(actionPosition === 'sticky' || actionPosition === 'fixed'){
          offset += actionBox.getBoundingClientRect().height;
        }
      }
      // O histórico de atividades usa uma barra sticky própria para as
      // ações de limpeza. Ela não é .action-box, por isso precisava de ser
      // incluída separadamente; sem este offset os pontos da barra de
      // rolagem colocavam o início do card por trás dessa barra.
      const activityManagement = document.querySelector('#pageOverlayBody .activity-management');
      if(isElementVisible(activityManagement)){
        const activityPosition = window.getComputedStyle(activityManagement).position;
        if(activityPosition === 'sticky' || activityPosition === 'fixed'){
          offset += activityManagement.getBoundingClientRect().height;
        }
      }
    }
    return Math.ceil(offset) + 1;
  }
  function getAlignedItems(){
    if(navId === 'mainScrollNav'){
      const cards = Array.from(document.querySelectorAll('#mainGrid > .card'));
      if(cards.length) return cards;
      return Array.from(document.querySelectorAll('#mainGrid > *'));
    }
    if(navId === 'listPageScrollNav'){
      return Array.from(document.querySelectorAll('#listPageContent .grid > .card, #listPageContent [data-card-id], #listPageContent .obra-list-item, #listPageContent .list-card'));
    }
    if(navId === 'pageOverlayScrollNav'){
      return Array.from(document.querySelectorAll('#pageOverlayBody .grid > .card, #pageOverlayBody .card, #pageOverlayBody .list-card, #pageOverlayBody .obra-row, #pageOverlayBody [data-card-id], #pageOverlayBody .obra-list-item, #pageOverlayBody .activity-item'));
    }
    return [];
  }
  // Elemento cujo padding-bottom é ajustado para garantir que sempre exista
  // espaço de rolagem suficiente para a ÚLTIMA linha de cards/itens poder
  // ficar alinhada com o topo (logo abaixo das barras fixas), em vez de
  // ficar parcialmente cortada porque o conteúdo "acabou" antes de a linha
  // conseguir subir até essa posição.
  function alignSpacerContainer(){
    if(navId === 'mainScrollNav') return document.getElementById('main');
    if(navId === 'pageOverlayScrollNav') return document.getElementById('pageOverlayBody');
    if(navId === 'listPageScrollNav') return document.getElementById('listPageContent');
    return null;
  }
  // Topo (scrollTop) necessário para que "el" fique com o seu início colado
  // logo abaixo das barras fixas (filterbar/action-box/header do overlay).
  function alignedScrollTopForTop(m, el){
    const offset = stickyOffsetForSnap(m);
    const rect = el.getBoundingClientRect();
    if(m.useWindow) return m.scrollTop + rect.top - offset;
    const containerRect = m.el.getBoundingClientRect();
    return m.scrollTop + rect.top - containerRect.top - offset;
  }
  function ensureAlignmentSpace(){
    // Todas as páginas com cards/linhas usam a mesma regra: reservar somente
    // o espaço que falta para o início da última linha poder ficar colado
    // abaixo das barras fixas. O cálculo é feito antes do clique e também
    // após cada renderização, para o destino já nascer correto sem um segundo
    // salto de correção.
    const containerEl = alignSpacerContainer();
    if(!containerEl) return;
    const m = metrics();
    if(!m || !m.el) return;
    const items = getAlignedItems();
    if(!items.length){
      // O #main é reutilizado entre categorias. Nunca deixar o padding
      // artificial da categoria anterior contaminar a Novel ou uma lista
      // curta.
      containerEl.style.removeProperty('padding-bottom');
      return;
    }
    // Com uma única linha não há um destino de alinhamento adicional.
    const rowTops = [];
    items.forEach(it => {
      const r = it.getBoundingClientRect();
      if(r.height >= 4 && !rowTops.some(top => Math.abs(top - r.top) <= 8)){
        rowTops.push(r.top);
      }
    });
    if(rowTops.length < 2){
      containerEl.style.removeProperty('padding-bottom');
      return;
    }
    // Agrupa visualmente a última linha (todos os itens cujo topo bate com
    // o item mais abaixo), para medir a partir do início dela.
    let lastEl = items[items.length - 1];
    let lastTop = -Infinity;
    items.forEach(it => {
      const r = it.getBoundingClientRect();
      if(r.height < 4) return;
      if(r.top > lastTop + 2){ lastTop = r.top; lastEl = it; }
    });
    const desiredScrollTop = Math.max(0, alignedScrollTopForTop(m, lastEl));
    const requiredHeight = Math.ceil(desiredScrollTop + m.clientHeight);

    // Mede sempre a partir do padding natural. Em contêineres com altura fixa
    // e `box-sizing:border-box`, o primeiro padding candidato pode aumentar o
    // scrollHeight menos do que o valor pedido; por isso há uma segunda medição
    // do resultado efetivo e um ajuste pelo défice observado.
    const priorExtra = containerEl.style.paddingBottom;
    containerEl.style.paddingBottom = '';
    const basePad = parseFloat(window.getComputedStyle(containerEl).paddingBottom) || 0;
    const naturalHeight = m.el.scrollHeight;
    const extraNeeded = Math.max(0, requiredHeight - naturalHeight);
    let newPad = basePad + extraNeeded;

    if(extraNeeded > 0){
      containerEl.style.paddingBottom = newPad + 'px';
      const measuredHeight = m.el.scrollHeight;
      const remainingDeficit = requiredHeight - measuredHeight;
      if(remainingDeficit > 1){
        newPad += remainingDeficit;
        containerEl.style.paddingBottom = newPad + 'px';
      }
    } else if(priorExtra){
      // Limpa o reforço anterior quando o conteúdo já cabe naturalmente.
      containerEl.style.removeProperty('padding-bottom');
    }
  }
  function rowStartFor(target, items){
    if(!target) return null;
    const targetRect = target.getBoundingClientRect();
    let best = target;
    items.forEach(item => {
      const r = item.getBoundingClientRect();
      if(Math.abs(r.top - targetRect.top) <= 6 && r.left < best.getBoundingClientRect().left){
        best = item;
      }
    });
    return best;
  }
  function scrollToAlignedElement(m, el, alignEnd, onSettled){
    if(!m || !el) return false;
    const overflow = Math.max(0, m.scrollHeight - m.clientHeight);
    // "alignEnd" deixou de significar "colar o fim do item ao fim do
    // contêiner": mesmo a última linha deve alinhar o SEU INÍCIO com a barra
    // fixa, tal como qualquer outra linha — isso é o que garante que ela
    // nunca fique cortada/desencontrada. ensureAlignmentSpace() garante que
    // sempre existe espaço de rolagem suficiente para este alvo ser
    // alcançado de verdade (não apenas "clampado" no fim do conteúdo).
    const target = alignedScrollTopForTop(m, el);
    scrollScrollerTo(m, clamp(target, 0, overflow), onSettled);
    return true;
  }
  // Converte um destino livre de scroll no início da linha de cards mais
  // próxima (descontando barras fixas), para os cards nunca ficarem cortados.
  function alignedTargetNear(m, rawTarget, ratio, tolerance){
    if(!m) return null;
    const overflow = Math.max(0, m.scrollHeight - m.clientHeight);
    if(ratio <= 0) return 0;
    if(ratio >= 1) return overflow;
    const items = getAlignedItems();
    if(!items.length) return null;
    const offset = stickyOffsetForSnap(m);
    const containerTop = m.useWindow ? 0 : m.el.getBoundingClientRect().top;
    const rowStarts = [];
    items.forEach(item => {
      const rect = item.getBoundingClientRect();
      if(rect.height < 4) return;
      const rawPos = m.scrollTop + rect.top - containerTop - offset;
      const pos = clamp(rawPos, 0, overflow);
      if(!rowStarts.some(start => Math.abs(start - pos) <= 8)) rowStarts.push(pos);
    });
    rowStarts.sort((a, b) => a - b);

    const isCardPageNavigation = navId === 'mainScrollNav'
      || navId === 'listPageScrollNav'
      || navId === 'pageOverlayScrollNav';
    if(!rowStarts.length) return null;
    // O alinhamento por linha só é seguro quando há pelo menos três linhas.
    // Com uma ou duas linhas, 50%, 75% e Fim caem naturalmente na mesma
    // linha; devolver null faz o chamador usar o percentual real do overflow,
    // mantendo cada marcador com um destino próprio mesmo em categorias curtas.
    if(rowStarts.length < 3) return null;

    // Para listas longas, cada percentual aponta para uma linha diferente
    // de cards. Usar o índice proporcional, em vez da linha simplesmente
    // mais próxima do alvo, impede que dois marcadores "colem" na mesma
    // linha quando existem grandes espaços entre os cards.
    const index = Math.max(0, Math.min(
      rowStarts.length - 1,
      Math.round((rowStarts.length - 1) * ratio),
    ));
    const aligned = rowStarts[index];

    // Se os cards ainda estão a ser renderizados ou o layout mudou, não
    // força um salto para uma linha muito distante do percentual pedido.
    // O chamador usa então o destino proporcional, que é sempre válido.
    const baseLimit = typeof tolerance === 'number'
      ? tolerance
      : Math.max(160, m.clientHeight * 0.6);
    if(isCardPageNavigation) return aligned;
    const limit = Math.max(baseLimit, overflow * 0.25);
    if(Math.abs(aligned - rawTarget) > limit) return null;
    return aligned;
  }

  function goToAlignedSnap(ratio, generation){
    const m = metrics(); if(!m) return false;
    const items = getAlignedItems();
    if(!items.length) return false;
    // Em páginas com uma ou duas linhas, inclusive o marcador Fim deve usar
    // o destino proporcional bruto. Nunca aplicar o alinhamento especial em
    // uma grade tão curta, pois 50%, 75% e Fim podem colidir na mesma linha.
    // A regra de três ou mais linhas mantém o alinhamento visual sem sacrificar
    // os pontos intermediários.
    const rowTops = [];
    items.forEach(item => {
      const r = item.getBoundingClientRect();
      if(r.height >= 4 && !rowTops.some(top => Math.abs(top - r.top) <= 8)) rowTops.push(r.top);
    });
    if(rowTops.length < 2) return false;
    if(ratio >= 0.999){
      // A última linha alinha o INÍCIO dela com a barra fixa, exatamente
      // como qualquer outra linha (antes ficava "colada" ao fim do
      // contêiner, o que a deixava fora de alinhamento com o topo).
      const last = rowStartFor(items[items.length - 1], items) || items[items.length - 1];
      const overflowEnd = Math.max(0, m.scrollHeight - m.clientHeight);
      const alignedEnd = alignedScrollTopForTop(m, last);
      const requestedDirection = Math.sign(alignedEnd - m.scrollTop);
      return scrollToAlignedElement(m, last, false, () => settleAlignment(1, 8, generation, requestedDirection));
    }
    const index = Math.max(0, Math.min(items.length - 1, Math.round((items.length - 1) * Math.max(0, ratio))));
    const target = rowStartFor(items[index], items) || items[index];
    return scrollToAlignedElement(m, target, false);
  }

  // Snap markers (Topo, 25%, 50%, 75%, Fim) — alinha no começo da linha de cards
  const snapBtns = nav.querySelectorAll('.scroll-nav-snap');
  // Depois do scroll parar, o conteúdo pode ter mudado de altura (imagens das
  // capas a carregar, cards renderizados por partes, barras fixas a mudar).
  // Este passe final volta a medir e encaixa o topo da linha de capas.
  function settleAlignment(ratio, passesLeft, generation, requestedDirection){
    if(generation !== navigationGeneration || ratio <= 0 || passesLeft <= 0) return;
    const m2 = metrics(); if(!m2) return;
    const current = m2.scrollTop;
    let aligned = null;
    const overflow = Math.max(0, m2.scrollHeight - m2.clientHeight);
    if(ratio >= 0.999){
      // O último bloco de cards pode ainda estar a ser anexado pela
      // renderização incremental. Recalcula o verdadeiro último item a cada
      // passe, em vez de ficar preso ao "fim" do primeiro chunk de Novels.
      const items = getAlignedItems();
      if(items.length){
        const last = rowStartFor(items[items.length - 1], items) || items[items.length - 1];
        const alignedEnd = alignedScrollTopForTop(m2, last);
      aligned = clamp(alignedEnd, 0, overflow);
      }
    } else {
      const rawTarget = overflow * ratio;
      aligned = alignedTargetNear(m2, rawTarget, ratio, Math.max(120, m2.clientHeight * 0.45));
    }
    if(aligned == null){
      requestAnimationFrame(() => settleAlignment(ratio, passesLeft - 1, generation, requestedDirection));
      return;
    }
    const target = clamp(aligned, 0, overflow);
    const delta = Math.abs(target - current);
    // Se o layout mudou depois do clique, o novo cálculo pode cair do lado
    // oposto ao percurso pedido. Não aplica essa correção: voltar primeiro
    // faria a barra parecer invertida e só depois chegar ao destino.
    if(requestedDirection && delta >= 1 && Math.sign(target - current) !== requestedDirection) return;
    if(delta >= 1){
      // O primeiro passe já fez a animação principal. Aqui só corrigimos a
      // diferença imediata causada por cards/chunks que chegaram depois.
      if(m2.useWindow) window.scrollTo({top:target, left:0, behavior:'auto'});
      else m2.el.scrollTop = target;
      update();
    }
    requestAnimationFrame(() => settleAlignment(ratio, passesLeft - 1, generation, requestedDirection));
  }
  function goToSnap(ratio){
    const generation = ++navigationGeneration;
    const clamped = Math.max(0, Math.min(1, ratio));
    // Recalcula o espaço antes de medir o overflow. Isto é importante quando
    // o utilizador clica logo após uma renderização, antes de o observer ou o
    // resize sintético ter executado: sem este passo, um destino de 25/50/75
    // podia ser calculado com a altura antiga e ficar clampado no fim.
    ensureAlignmentSpace();
    // Topo e Fim são absolutos: o início da primeira/última linha de cards
    // TEM de encostar exatamente abaixo da barra fixa, sempre, de primeira.
    // ensureAlignmentSpace() garante espaço de rolagem suficiente para que
    // o alvo da última linha seja mesmo alcançável (nunca fique "clampado"
    // no fim do conteúdo antes de alinhar).
    if(clamped >= 0.999){
      if(goToAlignedSnap(1, generation)){
        nav.classList.add('is-pressed');
        if(snapPressTimer) clearTimeout(snapPressTimer);
        snapPressTimer = setTimeout(() => { nav.classList.remove('is-pressed'); }, 750);
        flashRecent();
        return;
      }
    }
    const m = metrics(); if(!m) return;
    const overflow = Math.max(0, m.scrollHeight - m.clientHeight);
    let target;
    if(clamped <= 0.001){
      target = 0;
    } else {
      // Em grades/listas com pelo menos três filas, prevalece o alinhamento
      // com o início da fila (logo abaixo das barras fixas). Em páginas com
      // uma ou duas filas, alignedTargetNear devolve null e usamos a
      // percentagem real do espaço disponível, evitando que 50%, 75% e Fim
      // caiam no mesmo ponto.
      const aligned = alignedTargetNear(m, overflow * clamped, clamped, Infinity);
      target = aligned != null ? aligned : overflow * clamped;
    }
    // Após a animação, mede novamente as linhas. Isto corrige mudanças de
    // altura provocadas por imagens lazy, renderização em blocos ou barras
    // sticky que se ajustem durante o percurso, sem alterar o comportamento
    // de páginas curtas (onde alignedTargetNear devolve null).
    const requestedDirection = Math.sign(target - m.scrollTop);
    const settle = clamped > 0.001
      ? () => settleAlignment(clamped, 8, generation, requestedDirection)
      : null;
    scrollScrollerTo(m, target, settle);
    nav.classList.add('is-pressed');
    if(snapPressTimer) clearTimeout(snapPressTimer);
    snapPressTimer = setTimeout(() => { nav.classList.remove('is-pressed'); }, 750);
    flashRecent();
  }
  snapBtns.forEach(btn => {
    btn.addEventListener('pointerdown', (ev) => {
      ev.stopPropagation();
      navigationGeneration += 1;
      if(scrollAnimation){ cancelAnimationFrame(scrollAnimation); scrollAnimation = 0; }
      nav.classList.add('is-pressed');
    });
    btn.addEventListener('pointerup', (ev) => { ev.stopPropagation(); });
    btn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      ev.preventDefault();
      const r = parseFloat(btn.getAttribute('data-snap') || '0');
      goToSnap(isFinite(r) ? r : 0);
    });
  });

  topBtn.addEventListener('click', () => {
    navigationGeneration += 1;
    const m = metrics(); if(!m) return;
    scrollScrollerTo(m, 0);
    flashRecent();
  });

  // Re-evaluate when content changes
  let observerTarget = null;
  if(navId === 'pageOverlayScrollNav') observerTarget = document.getElementById('pageOverlayBody');
  else if(navId === 'listPageScrollNav') observerTarget = document.getElementById('listPageContent');
  else if(navId === 'formModalScrollNav') observerTarget = document.querySelector('#formModalBackdrop .modal-body');
  else if(navId === 'detailModalScrollNav') observerTarget = document.getElementById('detailModalBody');
  else observerTarget = document.getElementById('content');
  if(observerTarget && typeof MutationObserver !== 'undefined'){
    const mo = new MutationObserver(() => { update(); ensureAlignmentSpace(); });
    // A grelha é preenchida por blocos dentro de #content. Observar apenas
    // os filhos diretos deixava a barra sem recalcular quando os blocos da
    // Novel/Listas chegavam depois do primeiro frame.
    mo.observe(observerTarget, { childList:true, subtree:true });
  }
  // Re-evaluate when overlays toggle
  let overlayId = 'listPageOverlay';
  if(navId === 'pageOverlayScrollNav') overlayId = 'pageOverlay';
  else if(navId === 'formModalScrollNav') overlayId = 'formModalBackdrop';
  else if(navId === 'detailModalScrollNav') overlayId = 'detailModalBackdrop';
  const watchIds = [overlayId];
  if(navId === 'mainScrollNav'){
    watchIds.push('pageOverlay','formModalBackdrop','detailModalBackdrop','obraPickerModalBackdrop','listaFormModalBackdrop');
  }
  if(typeof MutationObserver !== 'undefined'){
    watchIds.forEach(id => {
      const target = document.getElementById(id);
      if(!target) return;
      const mo2 = new MutationObserver(() => {
        attach(); update(); ensureAlignmentSpace();
        setTimeout(() => { update(); ensureAlignmentSpace(); }, 100);
        setTimeout(() => { update(); ensureAlignmentSpace(); }, 300);
      });
      mo2.observe(target, { attributes:true, attributeFilter:['class','style','hidden'] });
    });
  }
  setTimeout(() => { update(); ensureAlignmentSpace(); }, 50);
}

function cancelScrollNavAnimations(){
  document.querySelectorAll('.scroll-nav').forEach(nav => {
    if(typeof nav.__cancelScrollNavigation === 'function'){
      nav.__cancelScrollNavigation();
    }
  });
}

// Nº de capas processadas em paralelo. Antes era sequencial (1 a 1), o que
// tornava a geração de relatórios grandes muito lenta (cada capa esperava a
// anterior terminar, mesmo sendo pedidos de rede independentes). Processar
// em lotes paralelos acelera bastante sem sobrecarregar a rede/memória.
const REPORT_COVER_CACHE_CONCURRENCY = 8;
async function ensureReportCoversCached(categoriaFiltro, entriesOverride){
  if(!isOnline()) return;
  let entries;
  if(Array.isArray(entriesOverride)) entries = entriesOverride;
  else entries = categoriaFiltro ? state.entries.filter(e => e.categoria === categoriaFiltro) : state.entries;
  const missing = entries.filter(e => !e.capa_base64 && e.capa_url && isValidUrl(e.capa_url));
  if(!missing.length) return;
  const toProcess = missing.slice(0, REPORT_COVER_CACHE_LIMIT);
  if(missing.length > REPORT_COVER_CACHE_LIMIT){
    showToast('info', `Relatório grande: cacheando ${REPORT_COVER_CACHE_LIMIT} capas e mantendo as demais por URL para evitar lentidão.`);
  }
  let changed = false;
  let cursor = 0;
  const processOne = async (entry) => {
    try{
      const dataUrl = await convertImageUrlToDataUrl(entry.capa_url);
      if(dataUrl){
        entry.capa_base64 = dataUrl;
        entry.capa_url = '';
        entry.atualizado_em = Date.now();
        changed = true;
      } else {
        await cacheExternalCoverUrl(entry.capa_url);
      }
    }catch(e){
      await cacheExternalCoverUrl(entry.capa_url);
      /* se a imagem externa bloquear CORS, mantém a URL */
    }
  };
  const worker = async () => {
    while(cursor < toProcess.length){
      const entry = toProcess[cursor++];
      await processOne(entry);
      await nextBrowserTick();
    }
  };
  const workers = Array.from({length: Math.min(REPORT_COVER_CACHE_CONCURRENCY, toProcess.length)}, worker);
  await Promise.all(workers);
  if(changed) persistEntries();
}

function filterEntriesBySub(categoriaFiltro, subFiltro){
  let list = categoriaFiltro ? state.entries.filter(e => e.categoria === categoriaFiltro) : state.entries.slice();
  if(subFiltro && categoriaFiltro === 'filme'){
    list = list.filter(e => String(e.subcategoria||'').toLowerCase() === subFiltro);
  } else if(subFiltro && categoriaFiltro === 'novel'){
    const meta = NOVEL_SUBCAT_META[subFiltro];
    if(meta){
      list = list.filter(e => novelSubMatches(meta, e.tipo_novel));
    }
  }
  return list;
}
let _offlinePdfLibrarySources = null;
let _offlinePdfLibrarySourcesPromise = null;
function loadOfflinePdfLibrarySources(){
  if(_offlinePdfLibrarySources) return Promise.resolve(_offlinePdfLibrarySources);
  if(_offlinePdfLibrarySourcesPromise) return _offlinePdfLibrarySourcesPromise;
  const loadSource = path => fetch(new URL(path, document.baseURI).href)
    .then(response => {
      if(!response.ok) throw new Error('PDF library unavailable');
      return response.text();
    });
  _offlinePdfLibrarySourcesPromise = Promise.all([
    loadSource('./vendor/html2canvas.min.js'),
    loadSource('./vendor/jspdf.umd.min.js')
  ]).then(([html2canvas, jspdf]) => {
    _offlinePdfLibrarySources = {html2canvas, jspdf};
    return _offlinePdfLibrarySources;
  }).catch(() => null);
  return _offlinePdfLibrarySourcesPromise;
}
function escapeInlineScriptSource(source){
  return String(source || '').replace(/<\/script/gi, '<\\/script');
}
function generateReportPDF(categoriaFiltro, subFiltro){
  showToast('info', 'A preparar o relatório…');
  // Usa setTimeout para não bloquear a UI thread antes do toast aparecer
  setTimeout(async () => {
    try {
      const filteredEntries = filterEntriesBySub(categoriaFiltro, subFiltro);
      await ensureReportCoversCached(categoriaFiltro, subFiltro ? filteredEntries : undefined);
      await loadOfflinePdfLibrarySources();
      await nextBrowserTick();
      const html = generateReportHTML(categoriaFiltro, subFiltro ? {entries: filteredEntries, subFiltro} : {subFiltro});
      const blob = new Blob([html], {type: 'text/html; charset=utf-8'});
      const url = URL.createObjectURL(blob);
      // Abre em nova aba — o utilizador decide quando imprimir/guardar
      const win = window.open(url, '_blank');
      if(!win){
        // APK/WebView frequentemente bloqueia pop-ups. Disponibiliza o mesmo
        // relatório como ficheiro HTML, que pode ser aberto/imprimido no telefone.
        downloadFile('relatorio-my-fan-a-list.html', html, 'text/html;charset=utf-8');
        showToast('success', 'Relatório guardado. Abra o ficheiro HTML para ver ou imprimir.');
      }
      // Revoga o blob URL após tempo suficiente para o browser carregar
      setTimeout(() => URL.revokeObjectURL(url), 30000);
    } catch(e) {
      showToast('error', 'Erro ao gerar o relatório: ' + e.message);
    }
  }, 50);
}

function generateReportPDFForLista(listaId){
  const lista = getListaById(listaId);
  if(!lista){ showToast('error', 'Lista não encontrada.'); return; }
  const entries = getEntriesOfLista(lista);
  if(!entries.length){ showToast('warning', 'Esta lista não tem obras para gerar PDF.'); return; }
  showToast('info', 'A preparar o relatório da lista…');
  setTimeout(async () => {
    try {
      await ensureReportCoversCached(null, entries);
      await loadOfflinePdfLibrarySources();
      await nextBrowserTick();
      const html = generateReportHTML(null, {entries, tituloOverride: `Relatório — ${lista.nome}`, listaContext: lista});
      const blob = new Blob([html], {type: 'text/html; charset=utf-8'});
      const url = URL.createObjectURL(blob);
      const win = window.open(url, '_blank');
      if(!win){
        downloadFile('relatorio-lista-my-fan-a-list.html', html, 'text/html;charset=utf-8');
        showToast('success', 'Relatório guardado. Abra o ficheiro HTML para ver ou imprimir.');
      }
      setTimeout(() => URL.revokeObjectURL(url), 30000);
    } catch(e) {
      showToast('error', 'Erro ao gerar o relatório: ' + e.message);
    }
  }, 50);
}
function generateAllCategoryReportsPDF(){
  const categoriasComObras = CATEGORY_ORDER.filter(cat => state.entries.some(e => e.categoria === cat));
  if(!categoriasComObras.length){ showToast('warning', 'Não há obras para gerar relatório.'); return; }
  let i = 0;
  const next = () => {
    if(i >= categoriasComObras.length) return;
    generateReportPDF(categoriasComObras[i]);
    i++;
    setTimeout(next, 1300);
  };
  next();
}

function generateReportHTML(categoriaFiltro, options){
  options = options || {};
  const entriesFiltradas = Array.isArray(options.entries)
    ? options.entries
    : (categoriaFiltro ? state.entries.filter(e => e.categoria === categoriaFiltro) : state.entries);
  const stats = calculateDetailedStats(entriesFiltradas);
  const now = formatDateTime(new Date());
  let tituloRelatorio;
  if(options.tituloOverride){
    tituloRelatorio = options.tituloOverride;
  } else if(categoriaFiltro && options.subFiltro){
    const subMeta = categoriaFiltro === 'filme' ? FILME_SUBCAT_META[options.subFiltro] : (categoriaFiltro === 'novel' ? NOVEL_SUBCAT_META[options.subFiltro] : null);
    const subLabel = subMeta ? subMeta.label : options.subFiltro;
    tituloRelatorio = `Relatório — ${CATEGORY_META[categoriaFiltro].label} (${subLabel})`;
  } else if(categoriaFiltro){
    tituloRelatorio = `Relatório — ${CATEGORY_META[categoriaFiltro].plural}`;
  } else {
    tituloRelatorio = 'Relatório My Fan A List';
  }
  const isListaContext = !!options.listaContext;

  let html = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${escapeHtml(tituloRelatorio)}</title><style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Helvetica Neue',Arial,sans-serif;padding:16px 8px;color:#222;background:#fff;font-size:11px;line-height:1.4;max-width:100%;overflow-x:hidden;overflow-wrap:break-word;word-wrap:break-word;}
    @media(max-width:600px){body{padding:14px 7px 14px 7px;font-size:11px;}}
    .report-header{border-bottom:2px solid #5cc8bd;padding-bottom:8px;margin-bottom:14px;}
    h1{color:#b48a3f;font-size:17px;margin-bottom:2px;word-break:break-word;}
    .gen{font-size:10px;color:#999;}
    h2{color:#3a7770;font-size:12px;margin:16px 0 8px;text-transform:uppercase;letter-spacing:.7px;border-bottom:1px solid #e8e1d0;padding-bottom:4px;}
    .stats-grid{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;}
    .stat-box{flex:1;min-width:80px;padding:7px 10px;background:#fbf8f1;border-left:3px solid #5cc8bd;border-radius:4px;}
    .stat-total{font-size:16px;font-weight:700;color:#b48a3f;line-height:1.2;word-break:break-word;overflow-wrap:break-word;}
    .stat-label{font-size:9px;color:#999;margin-top:2px;text-transform:uppercase;letter-spacing:.4px;}
    .obra-list{display:block;margin-bottom:18px;}
    .obra-row{display:flex;gap:8px;border:1px solid #e6e1d3;border-radius:6px;background:#fff;padding:7px 8px;margin-bottom:6px;break-inside:avoid;page-break-inside:avoid;page-break-after:auto;max-width:100%;overflow:hidden;}
    .cover{flex:none;width:36px;height:54px;background:#f3eee2;border-radius:3px;overflow:hidden;display:flex;align-items:center;justify-content:center;}
    .cover img{width:100%;height:100%;object-fit:cover;display:block;}
    .cover .ph{color:#c4b896;font-size:14px;font-weight:700;}
    .body{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px;overflow:visible;}
    .row-head{display:flex;justify-content:space-between;align-items:flex-start;gap:4px;}
    .titulo{font-weight:700;font-size:12px;color:#1a1a1a;line-height:1.2;overflow-wrap:break-word;word-break:break-word;}
    .original{font-size:9px;color:#aaa;font-style:italic;overflow-wrap:break-word;word-break:break-word;}
    .cat-tab{display:inline-block;background:#14171f;color:#5cc8bd;font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;padding:1px 5px;border-radius:2px;flex:none;white-space:nowrap;}
    .badges{display:flex;flex-wrap:wrap;gap:3px;}
    .badge{display:inline-block;padding:1px 5px;border-radius:3px;font-weight:600;font-size:9px;}
    .badge.rating{background:#fff4d6;color:#8a6418;}
    .badge.fav{background:#fde2dc;color:#a13c2a;}
    .badge.status{background:#e8f0ee;color:#2a544f;}
    .badge.official{background:#eee8f8;color:#5d3b8f;}
    .info-grid{display:flex;flex-wrap:wrap;gap:2px 10px;font-size:9.5px;color:#444;}
    .info-row{display:flex;gap:3px;align-items:baseline;max-width:100%;}
    .lbl{color:#aaa;font-weight:700;text-transform:uppercase;font-size:8px;letter-spacing:.3px;white-space:nowrap;}
    .val{color:#333;overflow-wrap:break-word;word-break:break-word;}
    .generos{display:flex;flex-wrap:wrap;gap:3px;}
    .gen-pill{font-size:8px;padding:1px 5px;border-radius:8px;background:#f3eee2;color:#7a5a23;border:1px solid #e6dcc1;}
    .comentario{font-size:9.5px;color:#666;background:#fbf8f1;border-left:2px solid #5cc8bd;padding:3px 6px;border-radius:0 3px 3px 0;font-style:italic;line-height:1.35;overflow-wrap:break-word;word-break:break-word;}
    .progresso-block{font-size:9px;color:#666;background:#faf6ec;border-radius:3px;padding:4px 6px;overflow-wrap:break-word;}
    .ph-title{font-weight:700;color:#7a5a23;font-size:8px;text-transform:uppercase;letter-spacing:.3px;margin-bottom:3px;}
    .temp-row{padding:1px 0;border-top:1px dotted #e6dcc1;}
    .temp-row:first-of-type{border-top:none;}
    .extra-line{font-size:8px;color:#5a4a25;margin:1px 0 1px 6px;line-height:1.3;overflow-wrap:break-word;}
    .extra-lbl{font-weight:700;color:#7a5a23;text-transform:uppercase;font-size:7.5px;}
    .section-note{font-size:10px;color:#aaa;margin-bottom:10px;font-style:italic;}
    .status-grid{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px;}
    .status-box{flex:1 1 22%;min-width:80px;padding:6px 10px;border-radius:4px;border-left:3px solid #aaa;background:#fafafa;}
    .status-box .num{font-size:15px;font-weight:700;line-height:1;}
    .status-box .lbl{font-size:9px;color:#666;margin-top:3px;text-transform:uppercase;letter-spacing:.4px;}
    .status-box.s-pretendo_ver{border-left-color:#7a5fc4;background:#f1eefb;}
    .status-box.s-pretendo_ver .num{color:#5a3fa3;}
    .status-box.s-em_andamento{border-left-color:#3a7770;background:#eef5f3;}
    .status-box.s-em_andamento .num{color:#2a544f;}
    .status-box.s-pausado{border-left-color:#b87f2d;background:#fbf3e2;}
    .status-box.s-pausado .num{color:#8a5618;}
    .status-box.s-abandonado{border-left-color:#a13c2a;background:#fde2dc;}
    .status-box.s-abandonado .num{color:#7a2e1d;}
    .status-box.s-concluido{border-left-color:#2a8a4a;background:#e6f4ea;}
    .status-box.s-concluido .num{color:#1f6736;}
    @media(max-width:600px){
      .status-box{flex:1 1 45%;min-width:70px;}
      .obra-row{gap:6px;padding:7px 6px;}
      .cover{width:32px;height:48px;}
      .row-head{flex-wrap:wrap;gap:3px;}
      .info-grid{gap:2px 8px;}
    }
    @media print{.status-box{flex:1 1 22%;}}
    html,body{-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact;}
    .toolbar{position:fixed;bottom:16px;right:16px;display:flex;flex-direction:column;gap:8px;z-index:99;align-items:flex-end;}
    .print-btn{background:#5cc8bd;color:#1a1408;border:none;padding:8px 16px;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 3px 10px rgba(0,0,0,0.2);white-space:nowrap;}
    .print-btn:hover{background:#8ae3d7;}
    .print-btn:disabled{opacity:.65;cursor:wait;}
    .print-btn.secondary{background:#14171f;color:#5cc8bd;}
    .print-btn.secondary:hover{background:#262b38;}
    @media print{
      body{padding:8mm 2mm;font-size:10px;}
      .obra-list{display:block;}
      .obra-row{break-inside:avoid;page-break-inside:avoid;}
      .obra-row > *{break-inside:avoid;page-break-inside:avoid;}
      .progresso-block,.comentario,.badges,.info-grid,.generos{break-inside:avoid;page-break-inside:avoid;}
      h2{break-after:avoid;page-break-after:avoid;}
      .toolbar{display:none;}
      @page{margin:10mm 6mm;}
    }
  </style></head><body>
    <div class="toolbar no-pdf">
      <button class="print-btn" id="btnBaixarPdf" onclick="baixarComoPDF()">⬇️ Baixar PDF</button>
      <button class="print-btn secondary" onclick="window.print()">🖨️ Imprimir</button>
    </div>
    <div class="report-header">
      <h1>📊 ${escapeHtml(tituloRelatorio)}</h1>
      <div class="gen">Gerado em: ${now}${isListaContext ? ' · ' + escapeHtml(entriesFiltradas.length + ' obra' + (entriesFiltradas.length===1?'':'s') + ' nesta lista') : ''}</div>
    </div>
  `;

  // Helper: contagem de status (apenas obras com status, ou seja, exclui filmes que não usam status)
  const buildStatusCounts = (entries) => {
    const c = {pretendo_ver:0, em_andamento:0, pausado:0, abandonado:0, concluido:0};
    entries.forEach(e => { if(e.status && c[e.status] !== undefined) c[e.status]++; });
    return c;
  };
  const statusGridHtml = (entries) => {
    const c = buildStatusCounts(entries);
    const items = [
      {k:'abandonado',   label:'Abandonado'},
      {k:'concluido',    label:'Concluídos'},
      {k:'em_andamento', label:'Em Andamento'},
      {k:'pausado',      label:'Pausado'},
      {k:'pretendo_ver', label:'Pretendo Ver'}
    ];
    return `<div class="status-section-title">Status pessoal</div><div class="status-grid">${items.map(it => `<div class="status-box s-${it.k}"><div class="num">${c[it.k]}</div><div class="lbl">${it.label}</div></div>`).join('')}</div>`;
  };

  if(isListaContext){
    // Relatório de lista: SEM resumo geral, SEM headers de categoria.
    // Mostra apenas os dados consolidados desta lista (total, nota média, status counts).
    html += `<h2>Resumo da lista</h2>
      <div class="stats-grid">
        <div class="stat-box"><div class="stat-total">${entriesFiltradas.length}</div><div class="stat-label">Obras na lista</div></div>
        <div class="stat-box"><div class="stat-total">${(stats.notaMedia || 0).toFixed(1)}</div><div class="stat-label">Nota Média</div></div>
      </div>
      ${statusGridHtml(entriesFiltradas)}`;
  } else if(categoriaFiltro){
    const catStats = stats[categoriaFiltro] || {count:0, notaMedia:0, temporadas:0, episodios:0, ovas:0, filmes:0, capitulos:0, volumes:0};
    const meta = CATEGORY_META[categoriaFiltro];
    let detalhes = '';
    if(categoriaFiltro === 'anime'){
      detalhes = `${Math.round(catStats.temporadas||0)} temporadas, ${Math.round(catStats.episodios||0)} episódios, ${Math.round(catStats.ovas||0)} OVAs, ${Math.round(catStats.filmes||0)} filmes`;
    } else if(categoriaFiltro === 'desenho'){
      detalhes = `${Math.round(catStats.temporadas||0)} temporadas, ${Math.round(catStats.episodios||0)} episódios` + ((catStats.extras||0) ? `, ${Math.round(catStats.extras||0)} extras` : '') + ((catStats.filmes||0) ? `, ${Math.round(catStats.filmes||0)} filmes` : '');
    } else if(categoriaFiltro === 'serie'){
      detalhes = `${Math.round(catStats.temporadas||0)} temporadas, ${Math.round(catStats.episodios||0)} episódios`;
    } else if(categoriaFiltro === 'filme'){
      detalhes = `${Math.round(catStats.filmes||catStats.count||0)} filmes`;
    } else if(['manga','manhua','manhwa'].includes(categoriaFiltro)){
      detalhes = `${Math.round(catStats.capitulos||0)} capítulos`;
    } else if(categoriaFiltro === 'novel'){
      detalhes = `${Math.round(catStats.volumes||0)} volumes, ${Math.round(catStats.capitulos||0)} capítulos` + ((catStats.paginas||0) ? `, ${Math.round(catStats.paginas)} pág.` : '');
    } else if(categoriaFiltro === 'livro'){
      const lidas = Math.round(catStats.paginas||0);
      const totais = Math.round(catStats.paginasTotais||0);
      detalhes = totais ? `${lidas} pág. lidas · ${totais} pág. total` : `${lidas} pág. lidas`;
    }

    html += `<h2>Resumo da categoria</h2>
      <div class="stats-grid">
        <div class="stat-box"><div class="stat-total">${entriesFiltradas.length}</div><div class="stat-label">Obras</div></div>
        <div class="stat-box"><div class="stat-total">${(catStats.notaMedia || 0).toFixed(1)}</div><div class="stat-label">Nota média</div></div>
        ${detalhes ? `<div class="stat-box"><div class="stat-total" style="font-size:14px;">${escapeHtml(detalhes)}</div><div class="stat-label">${escapeHtml(meta.plural)}</div></div>` : ''}
      </div>
      ${categoriaFiltro !== 'filme' ? statusGridHtml(entriesFiltradas) : ''}
      <p class="section-note">Este relatório mostra apenas ${escapeHtml(meta.plural.toLowerCase())}.</p>`;
  } else {
    html += `<h2>Resumo Geral</h2>
      <div class="stats-grid">
        <div class="stat-box"><div class="stat-total">${entriesFiltradas.length}</div><div class="stat-label">Obras Totais</div></div>
        <div class="stat-box"><div class="stat-total">${(stats.notaMedia || 0).toFixed(1)}</div><div class="stat-label">Nota Média Geral</div></div>
      </div>
      ${statusGridHtml(entriesFiltradas)}`;
  }

  const categoriasParaMostrar = categoriaFiltro ? [categoriaFiltro] : CATEGORY_ORDER.filter(cat => entriesFiltradas.some(e => e.categoria === cat));
  const fmtDate = (d) => formatDateLongPt(d);
  const collator = new Intl.Collator('pt-BR', {sensitivity:'base'});
  categoriasParaMostrar.forEach(cat => {
    const obras = entriesFiltradas.filter(e => e.categoria === cat).slice().sort((a,b) => collator.compare(a.titulo||'', b.titulo||''));
    if(!obras.length) return;
    const metaCat = CATEGORY_META[cat];
    if(!categoriaFiltro && !isListaContext){
      const catStats = stats[cat] || {count:0, notaMedia:0, temporadas:0, episodios:0, ovas:0, filmes:0, capitulos:0, volumes:0};
      let detalhes = '';
      if(cat === 'anime'){
        detalhes = `${Math.round(catStats.temporadas||0)} temporadas, ${Math.round(catStats.episodios||0)} episódios, ${Math.round(catStats.ovas||0)} OVAs, ${Math.round(catStats.filmes||0)} filmes`;
      } else if(cat === 'desenho'){
        detalhes = `${Math.round(catStats.temporadas||0)} temporadas, ${Math.round(catStats.episodios||0)} episódios` + ((catStats.extras||0) ? `, ${Math.round(catStats.extras||0)} extras` : '') + ((catStats.filmes||0) ? `, ${Math.round(catStats.filmes||0)} filmes` : '');
      } else if(cat === 'serie'){
        detalhes = `${Math.round(catStats.temporadas||0)} temporadas, ${Math.round(catStats.episodios||0)} episódios`;
      } else if(cat === 'filme'){
        detalhes = `${Math.round(catStats.filmes||catStats.count||0)} filmes`;
      } else if(['manga','manhua','manhwa'].includes(cat)){
        detalhes = `${Math.round(catStats.capitulos||0)} capítulos`;
      } else if(cat === 'novel'){
        detalhes = `${Math.round(catStats.volumes||0)} volumes, ${Math.round(catStats.capitulos||0)} capítulos` + ((catStats.paginas||0) ? `, ${Math.round(catStats.paginas)} pág.` : '');
      } else if(cat === 'livro'){
        const lidas = Math.round(catStats.paginas||0);
        const totais = Math.round(catStats.paginasTotais||0);
        detalhes = totais ? `${lidas} pág. lidas · ${totais} pág. total` : `${lidas} pág. lidas`;
      }
      html += `<h2>${escapeHtml(metaCat.plural)}</h2>
        <div class="stats-grid">
          <div class="stat-box"><div class="stat-total">${obras.length}</div><div class="stat-label">Obras</div></div>
          <div class="stat-box"><div class="stat-total">${(catStats.notaMedia || 0).toFixed(1)}</div><div class="stat-label">Nota média</div></div>
          ${detalhes ? `<div class="stat-box"><div class="stat-total" style="font-size:13px;">${escapeHtml(detalhes)}</div><div class="stat-label">${escapeHtml(metaCat.plural)}</div></div>` : ''}
        </div>`;
    } else if(isListaContext){
      // Cabeçalho leve por categoria, apenas para separar visualmente as obras
      html += `<h2>${escapeHtml(metaCat.plural)} <span style="color:#aaa;font-size:10px;font-weight:400;">· ${obras.length} obra${obras.length===1?'':'s'}</span></h2>`;
    }
    html += `<div class="obra-list">`;
    obras.forEach(o => {
      // Usa base64 quando disponível para o relatório continuar com capas offline.
      const coverSrc = o.capa_base64 || o.capa_url || null;
      const prog = progressoTexto(o);
      const meta = CATEGORY_META[cat];
      const isFilme = o.categoria === 'filme';

      const info = [];
      info.push(['Categoria', meta.label]);
      if(o.ano) info.push(['Ano', o.ano]);
      if(prog) info.push(['Progresso', prog]);
      if(Array.isArray(o.fontes) && o.fontes.length){
        const fontes = o.fontes.filter(source => typeof source === 'string' && source.trim());
        if(fontes.length) info.push(['Fontes', fontes.join(', ')]);
      }
      if(isFilme && o.duracao_min) info.push(['Duração', o.duracao_min + ' min']);
      if(o.data_inicio) info.push(['Início', fmtDate(o.data_inicio)]);
      if(o.data_fim) info.push(['Conclusão', fmtDate(o.data_fim)]);
      if(o.ultima_edicao_obra) info.push(['Editado', formatDateTime(o.ultima_edicao_obra)]);
      if(o.ultima_edicao_comentarios) info.push(['Comentários editados', formatDateTime(o.ultima_edicao_comentarios)]);
      (BONUS_FIELDS[cat]||[]).forEach(f => { if(o[f.key]!==undefined && o[f.key]!==null && o[f.key]!=='') info.push([f.label, o[f.key]]); });

      // conta OVAs/filmes considerando quantidade (ex: quantidade 10 conta 10)
      const extraCount = (arr) => arr.reduce((acc,x)=> acc + extraQuantidade(x), 0);
      const extraName = (x) => escapeHtml(extraLabel(x));
      const extrasBlock = (extras) => {
        const ovas = extras.filter(x => x.tipo === 'OVA');
        const extrasT = extras.filter(x => x.tipo === 'Extra');
        const filmes = extras.filter(x => x.tipo === 'Filme');
        const outros = extras.filter(x => x.tipo !== 'OVA' && x.tipo !== 'Extra' && x.tipo !== 'Filme');
        let html = '';
        if(ovas.length) html += `<div class="extra-line"><span class="extra-lbl">OVAs (${extraCount(ovas)}):</span> ${ovas.map(extraName).join(' • ')}</div>`;
        if(extrasT.length) html += `<div class="extra-line"><span class="extra-lbl">Extras (${extraCount(extrasT)}):</span> ${extrasT.map(extraName).join(' • ')}</div>`;
        if(filmes.length) html += `<div class="extra-line"><span class="extra-lbl">Filmes (${extraCount(filmes)}):</span> ${filmes.map(extraName).join(' • ')}</div>`;
        if(outros.length) html += `<div class="extra-line"><span class="extra-lbl">Outros:</span> ${outros.map(x=>escapeHtml(x.tipo)+': '+escapeHtml(x.nome)).join(' • ')}</div>`;
        return html;
      };
      let progressoExtra = '';
      if(cat === 'anime' && ((o.temporadas||[]).length || (o.extras_independentes||[]).length)){
        const tempLines = (o.temporadas||[]).map(t => {
          return `<div class="temp-row"><strong>Temporada ${t.numero}</strong> — ${escapeHtml(statusLabel(t.status))} · ${Math.round(Number(t.episodios)||0)} ep.${extrasBlock(t.extras||[])}</div>`;
        }).join('');
        const indep = o.extras_independentes||[];
        const indepLines = indep.length ? `<div class="temp-row"><strong>Sem temporada definida</strong>${extrasBlock(indep)}</div>` : '';
        progressoExtra = `<div class="progresso-block"><div class="ph-title">Temporadas (${(o.temporadas||[]).length})</div>${tempLines}${indepLines}</div>`;
      } else if(['serie','desenho'].includes(cat) && ((o.temporadas||[]).length || (cat==='desenho' && (o.extras_independentes||[]).length))){
        const tempLines = (o.temporadas||[]).map(t => {
          const extHtml = cat === 'desenho' ? extrasBlock(t.extras||[]) : '';
          return `<div class="temp-row"><strong>Temporada ${t.numero}</strong> — ${escapeHtml(statusLabel(t.status))} · ${Math.round(Number(t.episodios)||0)} ep.${extHtml}</div>`;
        }).join('');
        const indepDesHtml = cat==='desenho' && (o.extras_independentes||[]).length ? `<div class="temp-row"><strong>Extras / Filmes (sem temporada)</strong>${extrasBlock(o.extras_independentes)}</div>` : '';
        progressoExtra = `<div class="progresso-block"><div class="ph-title">Temporadas (${(o.temporadas||[]).length})</div>${tempLines}${indepDesHtml}</div>`;
      } else if(cat === 'novel' && (o.volumes||[]).length){
        const volLines = o.volumes.map((v,i) => {
          const _pvNome = (v.nome && v.nome.trim()) ? v.nome.trim() : '';
          const _pvNumM = _pvNome.match(/(\d+(?:[.,]\d+)?)\s*$/);
          const volLabel = _pvNumM ? 'Vol. ' + _pvNumM[1] : (_pvNome || ('Vol. ' + (v.numero||(i+1))));
          const _pvLista = v.capitulos_lista || [];
          const _pvNumeric = _pvLista.length ? _pvLista.filter(c=>!(c.nome&&c.nome.trim())&&Number(c.quantidade)>0).reduce((s,c)=>s+Math.floor(Number(c.quantidade)),0) : Math.round(Number(v.capitulos)||0);
          const _pvNamedEntries = _pvLista.filter(c=>c.nome&&c.nome.trim());
          const _pvNamed = _pvNamedEntries.map(c => {
            const nome = c.nome.trim();
            const pg = Number(c.pagina)||0;
            return pg > 0 ? `${nome} (Pág. ${Math.floor(pg)})` : nome;
          });
          const _pvCaps = _pvLista.length ? (_pvNumeric > 0 ? _pvNumeric + ' cap.' + (_pvNamed.length ? ' + ' + _pvNamed.join(' · ') : '') : (_pvNamed.length ? _pvNamed.join(' · ') : '0 cap.')) : (_pvNumeric + ' cap.');
          const _pvLastE = _pvLista.length ? _pvLista[_pvLista.length-1] : null;
          const _pvLastPag = _pvLastE && _pvLastE.pagina && Number(_pvLastE.pagina) > 0 ? Math.floor(Number(_pvLastE.pagina)) : null;
          // Só mostra a página do volume se o último capítulo NÃO for nomeado
          // (chapters nomeados já mostram a página junto ao nome acima)
          const _pvLastIsNamed = _pvLastE && _pvLastE.nome && _pvLastE.nome.trim();
          const _pvPagStr = (_pvLastPag && !_pvLastIsNamed) ? ` · Pág. ${_pvLastPag}` : '';
          return `<div class="temp-row"><strong>${escapeHtml(volLabel)}</strong> — ${escapeHtml(statusLabel(v.status))} · ${escapeHtml(_pvCaps)}${_pvPagStr}</div>`;
        }).join('');
        progressoExtra = `<div class="progresso-block"><div class="ph-title">Volumes (${o.volumes.length})</div>${volLines}</div>`;
      }

      html += `<div class="obra-row">
        <div class="cover">${coverSrc ? `<img src="${escapeHtml(coverSrc)}" alt="" referrerpolicy="no-referrer" crossorigin="anonymous" loading="eager" decoding="sync" onerror="if(this.hasAttribute('crossorigin')){this.removeAttribute('crossorigin');var s=this.src;this.src='';this.src=s;}else{this.style.display='none';}">` : `<div class="ph">${escapeHtml(((o.titulo||meta.label).trim().charAt(0)||'?').toUpperCase())}</div>`}</div>
        <div class="body">
          <div class="row-head">
            <div style="flex:1;min-width:0;">
              <div class="titulo">${escapeHtml(o.titulo)}</div>
              ${o.titulo_original ? `<div class="original">${escapeHtml(o.titulo_original)}</div>` : ''}
            </div>
            <span class="cat-tab">${escapeHtml(meta.label)}</span>
          </div>
          <div class="badges">
            ${typeof o.nota === 'number' ? `<span class="badge rating">★ ${o.nota.toFixed(1).replace('.0','')} / 10</span>` : ''}
            ${!isFilme ? `<span class="badge status">Status pessoal: ${escapeHtml(statusLabel(o.status))}</span>` : ''}
            ${temStatusOficial(cat) && o.status_oficial ? `<span class="badge official">Status Oficial: ${escapeHtml(officialStatusLabel(o.status_oficial))}</span>` : ''}
            ${o.favorito ? `<span class="badge fav">♥ Favorito</span>` : ''}
          </div>
          ${info.length ? `<div class="info-grid">${info.map(([l,v]) => `<div class="info-row"><span class="lbl">${escapeHtml(l)}:</span><span class="val">${escapeHtml(String(v))}</span></div>`).join('')}</div>` : ''}
          ${(o.generos||[]).length ? `<div class="generos">${o.generos.map(g => `<span class="gen-pill">${escapeHtml(g)}</span>`).join('')}</div>` : ''}
          ${progressoExtra}
          ${o.comentario ? `<div class="comentario">"${escapeHtml(o.comentario)}"</div>` : ''}
        </div>
      </div>`;
    });
    html += `</div>`;
  });

  const pdfFileName = (tituloRelatorio || 'Relatorio My Fan A List')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'relatorio-my-fan-a-list';

  if(_offlinePdfLibrarySources){
    html += '<script>' + escapeInlineScriptSource(_offlinePdfLibrarySources.html2canvas) + '</script>';
    html += '<script>' + escapeInlineScriptSource(_offlinePdfLibrarySources.jspdf) + '</script>';
  }

  html += `<script>
    // Gerador de PDF com paginação própria: em vez de capturar o documento
    // inteiro num único canvas (o que provocava páginas em branco, obras
    // cortadas e categorias sem informação quando o relatório era longo),
    // dividimos o conteúdo em folhas A4 e capturamos cada folha
    // individualmente, adicionando-as uma a uma ao PDF.
    var __H2C_SRC = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
    var __JSPDF_SRC = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
    var __h2pPromise = null;
    function __loadScript(src){
      return new Promise(function(resolve, reject){
        var s = document.createElement('script');
        s.src = src;
        s.crossOrigin = 'anonymous';
        s.referrerPolicy = 'no-referrer';
        s.onload = function(){ resolve(); };
        s.onerror = function(){ reject(new Error('offline')); };
        document.head.appendChild(s);
      });
    }
    function __loadHtml2Pdf(){
      if(window.html2canvas && (window.jspdf || window.jsPDF)) return Promise.resolve();
      if(__h2pPromise) return __h2pPromise;
      __h2pPromise = Promise.all([
        window.html2canvas ? Promise.resolve() : __loadScript(__H2C_SRC),
        (window.jspdf || window.jsPDF) ? Promise.resolve() : __loadScript(__JSPDF_SRC)
      ]).then(function(){
        if(!window.html2canvas || !(window.jspdf || window.jsPDF)) throw new Error('offline');
      });
      return __h2pPromise;
    }
    function __getJsPDF(){
      if(window.jspdf && window.jspdf.jsPDF) return window.jspdf.jsPDF;
      if(window.jsPDF) return window.jsPDF;
      throw new Error('jsPDF indisponível');
    }
    // Garante que todas as capas estão carregadas antes de capturar
    function __waitImages(root){
      var imgs = Array.from(root.querySelectorAll('img'));
      return Promise.all(imgs.map(function(img){
        if(img.complete) return Promise.resolve();
        return new Promise(function(res){
          var done = function(){ res(); };
          img.addEventListener('load', done, {once:true});
          img.addEventListener('error', done, {once:true});
          setTimeout(done, 6000);
        });
      }));
    }
    // Larguras/alturas em px equivalentes à área útil da folha A4
    var PDF_MM_W = 210, PDF_MM_H = 297, PDF_MARGIN_X = 6, PDF_MARGIN_Y = 8;
    var PDF_CONTENT_MM_W = PDF_MM_W - PDF_MARGIN_X * 2;   // 198mm
    var PDF_CONTENT_MM_H = PDF_MM_H - PDF_MARGIN_Y * 2;   // 281mm
    var PDF_PX_W = 749;                                    // 198mm @ ~96dpi
    var PX_PER_MM = PDF_PX_W / PDF_CONTENT_MM_W;
    var PDF_PX_H = Math.floor(PDF_CONTENT_MM_H * PX_PER_MM);

    // Divide o conteúdo em blocos indivisíveis (cada obra é um bloco)
    function __collectBlocks(){
      var blocks = [];
      Array.from(document.body.children).forEach(function(el){
        if(el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
        if(el.classList && el.classList.contains('no-pdf')) return;
        if(el.classList && el.classList.contains('obra-list')){
          Array.from(el.children).forEach(function(child){
            blocks.push({ el: child, wrap: 'obra-list', keepWithNext: false });
          });
        } else {
          blocks.push({ el: el, wrap: null, keepWithNext: el.tagName === 'H2' });
        }
      });
      return blocks;
    }
    function __newPage(stage){
      var page = document.createElement('div');
      page.className = 'pdf-page';
      page.style.cssText = 'width:' + PDF_PX_W + 'px;min-height:' + PDF_PX_H + 'px;height:' + PDF_PX_H + 'px;overflow:hidden;background:#fff;position:relative;';
      stage.appendChild(page);
      return page;
    }
    function __appendBlock(page, block){
      var host = page;
      if(block.wrap === 'obra-list'){
        var last = page.lastElementChild;
        if(last && last.classList.contains('obra-list')){
          host = last;
        } else {
          host = document.createElement('div');
          host.className = 'obra-list';
          host.style.marginBottom = '0';
          page.appendChild(host);
        }
      }
      var clone = block.el.cloneNode(true);
      host.appendChild(clone);
      return clone;
    }
    function __buildPages(){
      var stage = document.createElement('div');
      stage.id = 'pdfStage';
      stage.className = 'no-pdf';
      stage.style.cssText = 'position:fixed;left:-20000px;top:0;width:' + PDF_PX_W + 'px;background:#fff;z-index:-1;';
      document.body.appendChild(stage);

      var blocks = __collectBlocks();
      var page = __newPage(stage);
      var pending = [];   // blocos "keepWithNext" (ex: título de categoria)

      blocks.forEach(function(block){
        if(block.keepWithNext){
          pending.push(block);
          return;
        }
        var added = [];
        pending.forEach(function(p){ added.push(__appendBlock(page, p)); });
        added.push(__appendBlock(page, block));

        if(page.scrollHeight > PDF_PX_H){
          // não cabe: remove o que acabámos de acrescentar e passa para nova folha
          added.forEach(function(node){
            var parent = node.parentNode;
            parent.removeChild(node);
            if(parent !== page && !parent.children.length) parent.remove();
          });
          if(page.children.length){
            page = __newPage(stage);
          }
          pending.forEach(function(p){ __appendBlock(page, p); });
          __appendBlock(page, block);
          // bloco individual maior que a folha: fica sozinho e a folha cresce
          if(page.scrollHeight > PDF_PX_H){
            page.style.height = 'auto';
            page = __newPage(stage);
            pending = [];
            return;
          }
        }
        pending = [];
      });
      // remove folha final vazia
      var pages = Array.from(stage.querySelectorAll('.pdf-page'));
      pages.forEach(function(p){ if(!p.children.length) p.remove(); });
      return stage;
    }
    async function baixarComoPDF(){
      var btn = document.getElementById('btnBaixarPdf');
      var originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = '⏳ A gerar PDF…';
      var stage = null;
      try{
        await __loadHtml2Pdf();
        await __waitImages(document.body);
        stage = __buildPages();
        await new Promise(function(r){ setTimeout(r, 60); });
        await __waitImages(stage);

        var pages = Array.from(stage.querySelectorAll('.pdf-page'));
        if(!pages.length) throw new Error('sem conteúdo');
        var JsPDF = __getJsPDF();
        var pdf = new JsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });

        for(var i = 0; i < pages.length; i++){
          btn.textContent = '⏳ Página ' + (i+1) + '/' + pages.length + '…';
          var canvas = await window.html2canvas(pages[i], {
            scale: 2,
            useCORS: true,
            backgroundColor: '#ffffff',
            logging: false,
            windowWidth: PDF_PX_W,
            width: PDF_PX_W,
            height: pages[i].scrollHeight
          });
          var imgData = canvas.toDataURL('image/jpeg', 0.92);
          var imgH = Math.min(PDF_CONTENT_MM_H, (canvas.height / canvas.width) * PDF_CONTENT_MM_W);
          if(i > 0) pdf.addPage();
          pdf.addImage(imgData, 'JPEG', PDF_MARGIN_X, PDF_MARGIN_Y, PDF_CONTENT_MM_W, imgH);
        }
        pdf.save(${JSON.stringify(pdfFileName)} + '.pdf');
      }catch(e){
        alert('Não foi possível gerar o PDF automaticamente. Use o botão "Imprimir" e escolha "Guardar como PDF"; essa opção também funciona sem internet.');
      }finally{
        if(stage && stage.parentNode) stage.parentNode.removeChild(stage);
        btn.disabled = false;
        btn.textContent = originalText;
      }
    }
  <\/script>`;

  html += `</body></html>`;
  return html;
}

function calculateDetailedStats(entries = state.entries){
  const stats = {
    total: entries.length,
    notaMedia: 0,
    pretendo_ver: 0,
    concluido: 0,
    em_andamento: 0,
    pausado: 0,
    abandonado: 0
  };

  const notas = entries.filter(e => typeof e.nota === 'number').map(e => e.nota);
  if(notas.length) stats.notaMedia = notas.reduce((a,b)=>a+b,0)/notas.length;

  CATEGORY_ORDER.forEach(cat => {
    const obras = entries.filter(e => e.categoria === cat);
    const count = obras.length;
    const catStats = {
      count,
      notaMedia: 0,
      temporadas: 0,
      episodios: 0,
      ovas: 0,
      filmes: 0,
      capitulos: 0,
      volumes: 0,
      paginas: 0
    };
    const notasCat = obras.filter(e => typeof e.nota === 'number').map(e => e.nota);
    if(notasCat.length) catStats.notaMedia = notasCat.reduce((a,b)=>a+b,0)/notasCat.length;

    const addAnimeExtras = (extras) => {
      (extras||[]).forEach(ex => {
        if(ex.tipo === 'OVA') catStats.ovas += extraQuantidade(ex);
        if(ex.tipo === 'Filme') catStats.filmes += extraQuantidade(ex);
      });
    };

    obras.forEach(o => {
      if(o.status && stats[o.status] !== undefined) stats[o.status]++;
      if(cat === 'anime'){
        const temporadas = o.temporadas || [];
        temporadas.forEach(t => {
          const ep = Math.floor(Number(t.episodios)||0);
          if(ep > 0){ catStats.temporadas += 1; catStats.episodios += ep; }
          addAnimeExtras(t.extras);
        });
        addAnimeExtras(o.extras_independentes);
      } else if(['serie','desenho'].includes(cat)){
        const temporadas = o.temporadas || [];
        temporadas.forEach(t => {
          const ep = Math.floor(Number(t.episodios)||0);
          if(ep > 0){ catStats.temporadas += 1; catStats.episodios += ep; }
          if(cat === 'desenho'){
            (t.extras||[]).forEach(ex => {
              if(ex.tipo === 'Filme') catStats.filmes += extraQuantidade(ex);
              else if(ex.tipo === 'OVA') catStats.ovas += extraQuantidade(ex);
              else if(ex.tipo === 'Extra') catStats.extras = (catStats.extras||0) + extraQuantidade(ex);
            });
          }
        });
        if(cat === 'desenho'){
          (o.extras_independentes||[]).forEach(ex => {
            if(ex.tipo === 'Filme') catStats.filmes += extraQuantidade(ex);
            else if(ex.tipo === 'OVA') catStats.ovas += extraQuantidade(ex);
            else if(ex.tipo === 'Extra') catStats.extras = (catStats.extras||0) + extraQuantidade(ex);
          });
        }
      } else if(cat === 'novel' && o.volumes){
        o.volumes.forEach(v => {
          const _stLista = v.capitulos_lista;
          let _stCaps;
          if(_stLista && _stLista.length){
            _stCaps = capitulostotalFromLista(_stLista, 0);
          } else {
            _stCaps = Math.floor(Number(v.capitulos)||0);
          }
          if(_stCaps > 0){ catStats.volumes += 1; catStats.capitulos += _stCaps; }
          const _stMaxPag = (_stLista||[]).reduce((m,c) => {
            const p = Number(c && c.pagina)||0;
            return p > m ? p : m;
          }, 0);
          if(_stMaxPag > 0) catStats.paginas += Math.floor(_stMaxPag);
        });
      } else if(['manga','manhua','manhwa'].includes(cat)){
        catStats.capitulos += Math.floor(Number(o.progresso_simples)||0);
      } else if(cat === 'filme'){
        catStats.filmes += 1;
      } else if(cat === 'livro'){
        catStats.paginas += Math.floor(Number(o.progresso_simples)||0);
        catStats.paginasTotais = (catStats.paginasTotais||0) + Math.floor(Number(o.paginas_total)||0);
      }
    });

    stats[cat] = catStats;
  });

  return stats;
}

async function init(){
  setViewportVars();
  migrateLegacyAccountIfNeeded();
  migrateLegacySecurityPreferenceForActiveAccount();
  if(needsUnlock()){
    showLockScreen(() => { continueInit(); });
    return;
  }
  await continueInit();
}
// Recarrega TUDO que pertence à conta ativa (obras, listas, histórico,
// preferências de UI salvas e perfil) e redesenha a tela — usado depois de
// trocar de conta com o app já em execução (login inicial já roda isso via
// continueInit, então esta função cobre só o caso de troca "a quente").
// Importante: NÃO chama bindEvents() de novo (os listeners já existem);
// só troca os DADOS em memória para os da conta que acabou de entrar.
async function reloadAccountData(){
  // Fecha qualquer modal aberto: pode estar referenciando um item (id de
  // obra/lista) que só existe no acervo da conta anterior.
  closeFormModal();
  closeDetailModal();
  closeConfirmModal();
  closeListaFormModal();
  closeObraPickerModal();
  closeListSelectorModal();
  closeListSelectorMultiModal();
  if(typeof closeListPage === 'function') closeListPage();
  // Zera o estado em memória antes de recarregar, para não haver nenhuma
  // chance de um card antigo (com a capa antiga) piscar na tela.
  state.entries = [];
  state.listas = [];
  state.historico = [];
  state.atividades = [];
  await loadEntries();
  await loadListas();
  await loadUiState();
  if(userPrefs.defaultCategoria && userPrefs.defaultCategoria !== 'ultima'){
    state.categoriaAtiva = userPrefs.defaultCategoria;
  }
  loadHistorico();
  loadAtividades();
  seedAtividadesFromEntries();
  ensureDefaultLists();
  userProfile = await loadPersistedProfile();
  refreshHeaderProfile();
  applyBootScrollSnapshot();
  _renderMainNow();
}

function consumeLaunchShortcut(){
  let action = '';
  let view = '';
  try{
    const params = new URLSearchParams(window.location.search || '');
    action = params.get('action') || '';
    view = params.get('view') || '';
    if(!action && !view) return;
    // Remove os parâmetros uma única vez. Assim, atualizar a tela não
    // reabre o formulário ou a página de listas em ciclo.
    const cleanUrl = window.location.pathname + window.location.hash;
    window.history.replaceState(window.history.state, document.title, cleanUrl);
  }catch(_){ return; }

  setTimeout(() => {
    try{
      if(action === 'new'){
        openFormModal(null);
      }else if(view === 'listas'){
        openListPage();
      }
    }catch(_){
      // Um atalho inválido nunca deve impedir o arranque normal do acervo.
    }
  }, 0);
}

async function continueInit(){
  prepareTextInputs(document);
  await loadEntries();
  await loadListas();
  await loadUiState();
  if(userPrefs.defaultCategoria && userPrefs.defaultCategoria !== 'ultima'){
    state.categoriaAtiva = userPrefs.defaultCategoria;
  }
  loadHistorico();
  loadAtividades();
  seedAtividadesFromEntries();
  ensureDefaultLists();
  bindEvents();
  requestPersistentStorage();
  userProfile = await loadPersistedProfile();
  refreshHeaderProfile();
  applyBootScrollSnapshot();
  _renderMainNow(); // render imediato no init, sem aguardar RAF
  consumeLaunchShortcut();
  if(!CLAUDE_STORAGE_AVAILABLE && !LOCAL_STORAGE_AVAILABLE && typeof indexedDB === 'undefined') showToast('warning', 'Este ambiente não suporta armazenamento persistente — os dados serão perdidos ao recarregar a página.');
  else if(!CLAUDE_STORAGE_AVAILABLE) showToast('success', 'Dados salvos neste navegador. Exporte o JSON antes de limpar os dados do site; a limpeza pode apagar o acervo.');
  maybeShowBackupReminder();
}

// ===================== LEMBRETE DE BACKUP =====================
// Aditivo: só lê/escreve duas chaves novas no localStorage (data do último
// export bem-sucedido e data do último lembrete mostrado). Não interfere em
// nenhum fluxo existente de export/import/persistência.
function maybeShowBackupReminder(){
  try{
    if(!LOCAL_STORAGE_AVAILABLE) return; // sem localStorage, não há como calcular o intervalo com segurança
    const intervalDays = (userPrefs && typeof userPrefs.reminderIntervalDays === 'number') ? userPrefs.reminderIntervalDays : BACKUP_REMINDER_INTERVAL_DAYS;
    if(!intervalDays || intervalDays <= 0) return; // usuário desligou o lembrete nas preferências
    if(!Array.isArray(state.entries) || state.entries.length === 0) return; // nada para fazer backup ainda

    const now = Date.now();
    const DAY = 24 * 60 * 60 * 1000;

    const lastExportRaw = window.localStorage.getItem(EXPORT_LAST_KEY);
    const lastExportAt = lastExportRaw ? Number(lastExportRaw) : 0;
    if(lastExportAt && (now - lastExportAt) < intervalDays * DAY) return; // export recente, nada a avisar

    const lastShownRaw = window.localStorage.getItem(BACKUP_REMINDER_LAST_SHOWN_KEY);
    const lastShownAt = lastShownRaw ? Number(lastShownRaw) : 0;
    if(lastShownAt && (now - lastShownAt) < BACKUP_REMINDER_COOLDOWN_DAYS * DAY) return; // já avisou recentemente

    window.localStorage.setItem(BACKUP_REMINDER_LAST_SHOWN_KEY, String(now));
    const msg = lastExportAt
      ? 'Já faz um tempo desde seu último backup. Que tal exportar seus dados?'
      : 'Você ainda não exportou um backup do seu acervo. Recomendamos fazer isso periodicamente.';
    // Pequeno atraso para não competir com os toasts de inicialização.
    setTimeout(() => showToast('info', msg), 1600);
  }catch(_){ /* lembrete é best-effort; nunca deve quebrar a inicialização */ }
}

/* ===================== NAV / BACK BUTTON HANDLING (unificado) =====================
   ANTES: existiam DOIS listeners de 'popstate' independentes (este bloco +
   o bloco "Botão Back do Android" mais abaixo), cada um com sua própria
   lista de prioridades do que fechar. Como o navegador dispara UM único
   evento 'popstate' por "voltar" físico, os DOIS listeners reagiam ao MESMO
   evento: um fechava o teclado/sugestões de gênero e o OUTRO, sem saber que
   isso já tinha acontecido, também fechava o modal/página seguinte — dois
   níveis fechando de uma vez só. Era essa a causa do "Voltar" involuntário/
   "cliques fantasma": um único gesto colapsava o teclado E o formulário (ou
   levava direto a "Detalhes da Obra") em vez de fechar só uma camada por vez.
   AGORA: um único ponto de decisão (handleBackIntent) resolve, em ordem de
   prioridade, exatamente UMA camada por evento: teclado > sugestões de
   gênero > modais/páginas/telas. O listener do botão físico do Android
   (Capacitor) só decide quando NÃO há histórico para voltar (ver bloco
   abaixo); quando há, delega para window.history.back(), que por sua vez
   dispara este mesmo 'popstate' — garantindo um único caminho de decisão.
================================================================================== */
(function(){
  try { history.replaceState({lov:'root'}, ''); } catch(_){}
  function pushNav(){ try { history.pushState({lov:true}, ''); } catch(_){} }
  window.__pushNav = pushNav;
  function wrap(getFn, setFn, opts){
    opts = opts || {};
    const orig = getFn();
    if(typeof orig !== 'function') return;
    setFn(function(){
      const skip = typeof opts.skipIf === 'function' && opts.skipIf.apply(this, arguments);
      const r = orig.apply(this, arguments);
      if(!skip) pushNav();
      return r;
    });
  }
  wrap(() => openDetailModal, (f) => { openDetailModal = f; });
  wrap(() => openFormModal, (f) => { openFormModal = f; });
  wrap(() => openConfirmDelete, (f) => { openConfirmDelete = f; });
  wrap(() => openConfirmDuplicate, (f) => { openConfirmDuplicate = f; });
  wrap(() => openConfirmWipe, (f) => { openConfirmWipe = f; });
  wrap(() => openConfirmModal, (f) => { openConfirmModal = f; });
  wrap(() => openListaFormModal, (f) => { openListaFormModal = f; });
  wrap(() => openObraPickerModal, (f) => { openObraPickerModal = f; });
  wrap(() => openListSelectorForObra, (f) => { openListSelectorForObra = f; });
  wrap(() => openListSelectorModalForMultiple, (f) => { openListSelectorModalForMultiple = f; });
  wrap(() => openListPage, (f) => { openListPage = f; });
  wrap(() => showPageOverlay, (f) => { showPageOverlay = f; }, {
    skipIf: function(){
      const ov = document.getElementById('pageOverlay');
      return !!(ov && ov.classList.contains('is-open'));
    }
  });
  function isVisible(id){ const el = document.getElementById(id); return el && !el.hidden; }

  // ---- Camada 1 (mais alta): teclado virtual customizado. ----
  // 1º clique em "Voltar" deve SÓ fechar o teclado, nunca navegar junto.
  function closeKeyboardLayer(){
    if (window.__ckb && window.__ckb.isOpen()){
      const active = document.activeElement;
      if (active && active.id === 'f_generos'){
        try { suppressGenreAutoOpen(700); } catch(_){}
        try { typeof closeGenreListMode === 'function' && closeGenreListMode(); } catch(_){}
      }
      window.__ckb.hide();
      if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) active.blur();
      return true;
    }
    return false;
  }
  // ---- Camada 2: barra/lista de sugestões de gênero. ----
  function closeGenreLayer(){
    const gBox = document.getElementById('generosSuggestBox');
    if (gBox && !gBox.hidden){
      try { suppressGenreAutoOpen(700); } catch(_){}
      try { typeof closeGenreListMode === 'function' && closeGenreListMode(); } catch(_){}
      const input = document.getElementById('f_generos');
      try { if(input) input.blur(); } catch(_){}
      return true;
    }
    return false;
  }
  function closeTopLayer(){
    if(isVisible('confirmModalBackdrop')) { closeConfirmModal(); return true; }
    if(isVisible('obraPickerModalBackdrop')) { closeObraPickerModal(); return true; }
    if(isVisible('listSelectorMultiModalBackdrop')) { closeListSelectorMultiModal(); return true; }
    if(isVisible('listSelectorModalBackdrop')) { closeListSelectorModal(); return true; }
    if(isVisible('listaFormModalBackdrop')) { closeListaFormModal(); return true; }
    if(isVisible('metadataPickerBackdrop')) { closeMetadataPicker(); return true; }
    if(isVisible('formModalBackdrop')) { closeFormModal(); return true; }
    if(typeof listPageState !== 'undefined' && listPageState.isOpen){ closeListPage(); return true; }
    if(state.view === 'obra-detalhe'){
      const btn = document.getElementById('btnBackFromDetail');
      if(btn){ btn.click(); return true; }
      const ret = state.obraDetalheReturn || { view: 'lista' };
      state.obraDetalheId = null; state.obraDetalheReturn = null;
      state.view = ret.view || 'lista';
      if(ret.categoriaAtiva) state.categoriaAtiva = ret.categoriaAtiva;
      if(ret.listaAtivaId) state.listaAtivaId = ret.listaAtivaId;
      renderMain();
      if(ret.listPageOpen && typeof openListPage === 'function') openListPage();
      return true;
    }
    if(state.view === 'lista-detalhe'){ state.view = 'listas'; if(typeof exitSelectionMode==='function') exitSelectionMode(); renderMain(); return true; }
    if(state.view === 'listas'){ state.view = 'lista'; if(typeof exitSelectionMode==='function') exitSelectionMode(); renderMain(); return true; }
    if(state.view === 'estatisticas'){ state.view = 'lista'; renderMain(); return true; }
    if(state.view === 'historico'){ state.view = 'lista'; if(typeof exitSelectionMode==='function') exitSelectionMode(); renderMain(); return true; }
    if(state.view === 'favoritos'){ state.view = 'lista'; if(typeof exitSelectionMode==='function') exitSelectionMode(); renderMain(); return true; }
    return false;
  }

  // Único ponto de decisão: cada evento de "voltar" consome NO MÁXIMO uma
  // camada, na ordem teclado > sugestões de gênero > app (modal/página/tela).
  function handleBackIntent(){
    if (closeKeyboardLayer()) return true;
    if (closeGenreLayer()) return true;
    if (closeTopLayer()) return true;
    return false;
  }
  // Exposto para o listener do botão físico do Android (bloco mais abaixo),
  // usado apenas quando NÃO há entrada de histórico para "voltar" (ex.: já
  // estamos na raiz e ainda há um teclado/lista aberta a fechar antes de
  // decidir se o app deve encerrar).
  window.__handleBackIntent = handleBackIntent;

  window.addEventListener('popstate', function(){
    // Teclado e sugestões de gênero são camadas "leves": elas NÃO empurram
    // estado próprio ao abrir (pushNav só é chamado pelas funções open* dos
    // modais/páginas). Por isso, ao consumi-las aqui, devolvemos a entrada de
    // histórico que o navegador acabou de retirar — assim o próximo "Voltar"
    // físico avança corretamente para a camada seguinte (modal/página/tela),
    // em vez de "pular" uma camada por causa de um desalinhamento no histórico.
    if (closeKeyboardLayer() || closeGenreLayer()){
      try { history.pushState({lov:true}, ''); } catch(_){}
      return;
    }
    // Camadas de app (modais/páginas/telas) já correspondem 1:1 a uma entrada
    // empurrada por pushNav() quando foram abertas — não é preciso devolver nada.
    closeTopLayer();
  });
})();

document.addEventListener('DOMContentLoaded', init);

// Mantém o app e as capas disponíveis quando aberto pelo navegador em origem segura.
if('serviceWorker' in navigator && location.protocol !== 'file:'){
  navigator.serviceWorker.register('./sw.js', {updateViaCache:'none'})
    .then(registration => {
      // Pede a verificação imediatamente depois de uma atualização do
      // pacote, sem forçar recarregamentos que poderiam interromper a
      // digitação ou a edição de uma obra.
      if(registration && typeof registration.update === 'function'){
        registration.update().catch(() => {});
      }
    })
    .catch(() => {});
}
// Ponte para o bloco do teclado (que vive FORA desta função): sem ela, o teclado
// não via ensureInputClearButton, nsKey nem o estado, e por isso o dicionário
// com as palavras das suas obras nunca chegava a ser usado.
window.__acervoBridge = {
  ensureInputClearButton: (el) => ensureInputClearButton(el),
  nsKey: (k) => nsKey(k),
  entries: () => (state && Array.isArray(state.entries)) ? state.entries : null
};
})();

/* ============================================================
   Teclado virtual customizado (substitui o teclado do Chrome)
   - Sem barra de sugestões / preenchimento de senhas do Google
   - Aparece ao focar inputs de texto / textarea
   - Envia eventos "input" para o app reagir normalmente
   ============================================================ */
(function forceNoNativeKeyboard(){
  // Impede que o teclado nativo do sistema seja acionado em QUALQUER campo:
  // marcamos todo <input>/<textarea> com inputmode="none". O nosso teclado
  // personalizado (initCustomKeyboard) trata da digitação.
  const isMobileNoKb = () => true;
  function tag(el){
    if(!el || el.__ckbTagged) return;
    const tag = el.tagName;
    if(tag !== 'INPUT' && tag !== 'TEXTAREA') return;
    const t = (el.type || 'text').toLowerCase();
    // O calendário de input[type="date"] é nativo e não deve ser convertido
    // para readonly/inputmode="none" pelo teclado virtual.
    if(t === 'date') return;
    if(['file','checkbox','radio','range','color','submit','button','image','reset','hidden'].includes(t)) return;
    try{
      // Guarda o inputmode original (ex.: "numeric" do campo de PIN) antes
      // de forçar 'none', para o teclado virtual mostrar o layout certo.
      if(!el.dataset._origInputmode){
        const curIm = el.getAttribute('inputmode');
        if(curIm && curIm !== 'none') el.dataset._origInputmode = curIm;
      }
      el.setAttribute('inputmode','none');
    }catch(_){}
    // BUG CORRIGIDO: em campos type="password", navegadores móveis costumam
    // IGNORAR inputmode="none" e abrir o teclado nativo (com a barra de
    // preenchimento automático) por baixo do teclado personalizado do app —
    // é exatamente essa sobreposição de dois teclados que aparecia nas
    // telas de login/PIN. A solução, igual à já usada para number/tel/email/
    // url, é trocar o campo para type="text" em mobile e mascarar visualmente
    // com CSS (classe .ckb-masked), preservando o comportamento normal em
    // desktop (onde o teclado do sistema não é um problema).
    // Reforço extra: mesmo com type="text" e autocomplete="off", o Chrome
    // e o serviço de autopreenchimento do Android às vezes ainda reconhecem
    // o campo como login/senha (pelo rótulo, id ou histórico) e tentam abrir
    // teclado/sugestões nativas. Como o teclado personalizado já escreve o
    // valor via JavaScript (não depende de digitação nativa), marcamos o
    // campo como "readonly" — isso bloqueia qualquer teclado ou popup nativo
    // do sistema sem impedir o teclado do app de preencher o campo.
    if(t === 'password' && isMobileNoKb()){
      try{
        if(!el.dataset._origType) el.dataset._origType = 'password';
        el.setAttribute('type','text');
        el.setAttribute('readonly','readonly');
        el.setAttribute('data-ckb-readonly-ok','1');
        el.setAttribute('data-lpignore','true');
        el.classList.add('ckb-masked');
      }catch(_){}
    }
    try{ el.setAttribute('autocomplete','off'); }catch(_){}
    try{ el.setAttribute('autocorrect','off'); }catch(_){}
    try{ el.setAttribute('autocapitalize','off'); }catch(_){}
    try{ el.setAttribute('spellcheck','false'); }catch(_){}
    el.__ckbTagged = true;
    // Todas as barras de entrada ganham o botão X de limpar (as regras de quais
    // campos ficam de fora estão dentro de ensureInputClearButton).
    try{ const br = window.__acervoBridge; if(br && br.ensureInputClearButton) br.ensureInputClearButton(el); }catch(_){}
  }
  // Reafirma "sem teclado nativo" no instante ANTES de o campo receber foco.
  // O MutationObserver abaixo só corre depois de o campo já estar no DOM; se
  // o foco acontecesse nesse intervalo (modais, autofocus, campos criados por
  // innerHTML) o Android abria o teclado do sistema por cima do app.
  function reassert(el){
    if(!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA')) return;
    const t = (el.type || 'text').toLowerCase();
    if(t === 'date') return;
    if(['file','checkbox','radio','range','color','submit','button','image','reset','hidden'].includes(t)) return;
    if(!el.__ckbTagged) tag(el);
    try{
      if(el.getAttribute('inputmode') !== 'none'){
        const cur = el.getAttribute('inputmode');
        if(cur && !el.dataset._origInputmode) el.dataset._origInputmode = cur;
        el.setAttribute('inputmode','none');
      }
      if(el.getAttribute('autocomplete') !== 'off') el.setAttribute('autocomplete','off');
      if(el.getAttribute('autocorrect') !== 'off') el.setAttribute('autocorrect','off');
      if(el.getAttribute('autocapitalize') !== 'off') el.setAttribute('autocapitalize','off');
      if(el.getAttribute('spellcheck') !== 'false') el.setAttribute('spellcheck','false');
    }catch(_){}
  }
  ['pointerdown','touchstart','mousedown','focusin'].forEach(ev => {
    document.addEventListener(ev, e => {
      const t = e.target;
      if(!t || !t.closest) return;
      reassert(t.closest('input,textarea'));
    }, {capture:true, passive:true});
  });
  function scan(root){
    (root || document).querySelectorAll && (root || document).querySelectorAll('input,textarea').forEach(tag);
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', () => scan(document));
  } else {
    scan(document);
  }
  const mo = new MutationObserver(muts => {
    for(const m of muts){
      m.addedNodes && m.addedNodes.forEach(n => {
        if(n.nodeType !== 1) return;
        if(n.tagName === 'INPUT' || n.tagName === 'TEXTAREA') tag(n);
        if(n.querySelectorAll) n.querySelectorAll('input,textarea').forEach(tag);
      });
    }
  });
  try{ mo.observe(document.documentElement, { childList:true, subtree:true }); }catch(_){}
})();

(function initCustomKeyboard(){
  if (window.__ckbInit) return; window.__ckbInit = true;

  const isMobile = () => true;
  if (!isMobile()) return;
  // nsKey vive no bloco principal do app; aqui usa-se através da ponte.
  const nsKey = (k) => (window.__acervoBridge && window.__acervoBridge.nsKey) ? window.__acervoBridge.nsKey(k) : k;

  /* ── MAPA DE ACENTOS ─────────────────────────────────────────────────── */
  const ACCENT_MAP = {
    // Fila de cima: o toque longo também oferece o dígito (q=1 … p=0), como no Gboard.
    'q':['1'], 'w':['2'], 'r':['4'], 't':['5'], 'y':['6'], 'p':['0'],
    'Q':['1'], 'W':['2'], 'R':['4'], 'T':['5'], 'Y':['6'], 'P':['0'],
    'a':['à','á','â','ã','ä'],  'e':['è','é','ê','ë','3'],
    'i':['ì','í','î','ï','8'],  'o':['ò','ó','ô','õ','ö','9'],
    'u':['ù','ú','û','ü','7'],  'c':['ç'],    'n':['ñ'],
    'A':['À','Á','Â','Ã','Ä'],  'E':['È','É','Ê','Ë','3'],
    'I':['Ì','Í','Î','Ï','8'],  'O':['Ò','Ó','Ô','Õ','Ö','9'],
    'U':['Ù','Ú','Û','Ü','7'],  'C':['Ç'],    'N':['Ñ'],
    '-':['–','—','·'],          '.':['…'],
    '?':['¿'],                   '!':['¡'],
    "'":["'",'\u00B4','\u0060'], '"':['\u201C','\u201D','\u00AB','\u00BB'],
    '$':['€','£','¥'],           '0':['°'],'+':['±'],
  };

  /* ── LAYOUTS ─────────────────────────────────────────────────────────── */
  const LANGS = ['pt','en','ja','ko','zh'];
  const LANG_LABELS = {pt:'PT', en:'EN', ja:'かな', ko:'한', zh:'中'};
  let language = 'pt';
  const MULTI_DICT = {
    pt: 'olá oi bom dia obrigado obrigada por favor você vocês meu minha meus minhas porque também então porém ainda sempre nunca anime animes mangá manga manhua manhua manhwa novel novels filme filmes série séries desenho desenhos livro livros capítulo capítulos volume volumes episódio episódios temporada temporadas comentário comentários avaliação nota favorito favorita favoritos assistir assistir lido ler quero gosto gostei excelente incrível história histórias personagem personagens enredo final começo temporada capa autor autora editora páginas progresso status concluído concluída andamento pausado abandono pesquisa buscar preencher dados online gênero gêneros ação aventura animação artes marciais comédia crime documentário drama fantasia ficção científica histórico horror mistério romance suspense terror escolar sobrenatural psicológico hoje amanhã depois antes com para uma um não sim',
    en: 'hello hi thanks thank you please you your my mine because also then but still always never anime manga manhua manhwa novel novels movie movies film films series show cartoon book books chapter chapters volume volumes episode episodes season seasons comment comments review rating score favorite watch watching read reading want like liked excellent amazing story stories character characters plot ending cover author publisher pages progress status completed ongoing paused dropped search find fill online data genre genres action adventure animation martial arts comedy crime documentary drama fantasy science fiction historical horror mystery romance suspense thriller school supernatural psychological today tomorrow after before with for a an not yes',
    ja: 'こんにちは おはよう ありがとう どういたしまして お願いします あなた 私 私たち はい いいえ アニメ 漫画 映画 ドラマ シリーズ 本 小説 ライトノベル 章 巻 話 コメント 評価 お気に入り 見る 読む 好き 素晴らしい 物語 登場人物 作者 出版社 表紙 ジャンル アクション 冒険 コメディ ドラマ ファンタジー ホラー ミステリー ロマンス 今日 明日 昨日',
    ko: '안녕하세요 좋은 아침 감사합니다 천만에요 부탁합니다 당신 나 우리 네 아니요 애니메이션 만화 웹툰 웹소설 영화 드라마 시리즈 책 소설 장 권 에피소드 댓글 평가 점수 즐겨찾기 보기 읽기 좋아요 훌륭한 이야기 등장인물 작가 출판사 표지 장르 액션 모험 코미디 범죄 다큐멘터리 드라마 판타지 공포 미스터리 로맨스 오늘 내일 어제',
    zh: '你好 早上好 谢谢 不客气 请 你 我 我们 是 不是 动漫 漫画 国漫 韩漫 轻小说 网络小说 电影 电视剧 系列 书 章节 卷 集 评论 评价 分数 收藏 观看 阅读 喜欢 优秀 故事 人物 作者 出版社 封面 类型 动作 冒险 动画 喜剧 犯罪 纪录片 戏剧 奇幻 恐怖 悬疑 爱情 今天 明天 昨天'
  };
  const SCRIPT_LAYOUTS = {
    ja: [['あ','か','さ','た','な','は','ま','や','ら','わ'],['い','き','し','ち','に','ひ','み','ゆ','り','を'],['う','く','す','つ','ぬ','ふ','む','よ','る','ん']],
    ko: [['ㅂ','ㅈ','ㄷ','ㄱ','ㅅ','ㅛ','ㅕ','ㅑ','ㅐ','ㅔ'],['ㅁ','ㄴ','ㅇ','ㄹ','ㅎ','ㅗ','ㅓ','ㅏ','ㅣ'],['ㅋ','ㅌ','ㅊ','ㅍ','ㅠ','ㅜ','ㅡ','BACK']],
    zh: [['你','我','他','她','的','是','不','了','在','人'],['有','和','就','也','看','说','想','要','好','这'],['中','国','日','本','学','生','爱','新','更','BACK']]
  };
  const layouts = {
    lower: [
      ['q','w','e','r','t','y','u','i','o','p'],
      ['a','s','d','f','g','h','j','k','l','ç'],
      ['SHIFT','z','x','c','v','b','n','m','BACK'],
      ['123',',','SPACE','.','LANG','ENTER']
    ],
    upper: [
      ['Q','W','E','R','T','Y','U','I','O','P'],
      ['A','S','D','F','G','H','J','K','L','Ç'],
      ['SHIFT','Z','X','C','V','B','N','M','BACK'],
      ['123',',','SPACE','.','LANG','ENTER']
    ],
    sym: [
      ['1','2','3','4','5','6','7','8','9','0'],
      ['-','/',':',';','(',')','$','&','@','"'],
      ['#+=','.',',','?','!',"'",'BACK'],
      ['ABC','SPACE','LANG','ENTER']
    ],
    emoji: [
      ['😀','😁','😂','🤣','😃','😄','😅','😉'],
      ['😊','😍','🥰','😘','😎','😭','😢','😡'],
      ['👍','👎','🙏','👏','💛','💙','🔥','🎉'],
      ['ABC','123','SPACE','BACK','ENTER']
    ],
    more: [
      ['[',']','{','}','#','%','^','*','+','='],
      ['_','\\','|','~','<','>','€','£','¥','•'],
      ['123','.',',','?','!',"'",'BACK'],
      ['ABC','SPACE','LANG','ENTER']
    ],
    num: [
      ['1','2','3'],
      ['4','5','6'],
      ['7','8','9'],
      ['ENTER','0','BACK']
    ],
    dec: [
      ['1','2','3'],
      ['4','5','6'],
      ['7','8','9'],
      ['ENTER','0','.','BACK']
    ]
  };
  const NUMERIC_MODES = new Set(['num','dec']);
  const EMOJI_CATEGORIES = [
    {id:'recent', icon:'🕘', label:'Recentes', items:''},
    {id:'smileys', icon:'😀', label:'Rostos e emoções', items:'😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🫡 🤫 🫠 😶 😐 😑 😬 🙄 😮‍💨 😴 🤤 😪 😵‍💫 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 👻 💀 ☠️ 👽 🤖 💩 🎃'},
    {id:'people', icon:'👋', label:'Pessoas e gestos', items:'👋 🤚 🖐 ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 🫵 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🦿 🦵 🦶 👂 🦻 👃 🧠 🫀 🫁 🦷 🦴 👀 👁 👅 👄 🫦 👶 🧒 👦 👧 🧑 👨 👩 🧔 👱 👴 👵 🧓 🙍 🙎 🙅 🙆 💁 🙋 🧏 🙇 🤦 🤷 👮 🕵️ 💂 🥷 👷 🤴 👸 👳 👲 🧕 🤵 👰 🤰 🫃 🫄 🤱 👼 🎅 🤶 🧑‍🎄 🦸 🦹 🧙 🧚 🧛 🧜 🧝 🧞 🧟 🧌 💃 🕺 🕴 👯 🧖 🧗 🤺 🏇 ⛷ 🏂 🏌️ 🏄 🚣 🏊 ⛹️ 🏋️ 🚴 🚵 🤸 🤼 🤽 🤾 🤹 🧘 🛀 🛌 👭 👫 👬 💏 💑 👪 🗣 👤 👥'},
    {id:'nature', icon:'🐻', label:'Animais e natureza', items:'🐵 🐒 🦍 🦧 🐶 🐕 🦮 🐕‍🦺 🐩 🐺 🦊 🦝 🐱 🐈 🦁 🐯 🐅 🐆 🐴 🫎 🫏 🐎 🦄 🦓 🦌 🦬 🐮 🐂 🐃 🐄 🐷 🐖 🐗 🐽 🐏 🐑 🐐 🐪 🐫 🦙 🦒 🐘 🦣 🦏 🦛 🐭 🐁 🐀 🐹 🐰 🐇 🐿 🦫 🦔 🦇 🐻 🐻‍❄️ 🐨 🐼 🦥 🦦 🦨 🦘 🦡 🐾 🦃 🐔 🐓 🐣 🐤 🐥 🐦 🐧 🕊 🦅 🦆 🦢 🦉 🦤 🪶 🦩 🦚 🦜 🪽 🐸 🐊 🐢 🦎 🐍 🐲 🐉 🦕 🦖 🐳 🐋 🐬 🦭 🐟 🐠 🐡 🦈 🐙 🐚 🪸 🪼 🦀 🦞 🦐 🦑 🪲 🐌 🦋 🐛 🐜 🐝 🪰 🪱 🦗 🕷 🕸 🦂 🦟 🪳 🪻 💐 🌸 💮 🪷 🏵 🌹 🥀 🌺 🌻 🌼 🌷 🪴 🌱 🪹 🪺 🌲 🌳 🌴 🌵 🌾 🌿 ☘️ 🍀 🍁 🍂 🍃 🪨 🪵 🌍 🌎 🌏 🌑 🌒 🌓 🌔 🌕 🌖 🌗 🌘 🌙 🌚 🌛 🌜 🌝 🌞 🪐 ⭐ 🌟 🌠 🌌 ☁️ ⛅ 🌤 🌥 🌦 🌧 ⛈ 🌩 🌨 ☀️ 🌈 🌪 🌫 🌬 🌀 🌊 💧 💦 ☔ ⚡ 🔥 ❄️ ☃️ ⛄'},
    {id:'food', icon:'🍕', label:'Comida e bebida', items:'🍏 🍎 🍐 🍊 🍋 🍋‍🟩 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🫒 🥑 🍆 🥔 🥕 🌽 🌶 🫑 🥒 🥬 🥦 🧄 🧅 🥜 🫘 🌰 🫚 🫛 🍄 🥯 🍞 🥐 🥖 🫓 🥨 🥞 🧇 🧀 🍖 🍗 🥩 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🫔 🥙 🧆 🥚 🍳 🥘 🍲 🫕 🥣 🥗 🍿 🧈 🧂 🥫 🍱 🍘 🍙 🍚 🍛 🍜 🍝 🍠 🍢 🍣 🍤 🍥 🥮 🍡 🥟 🥠 🥡 🦪 🍦 🍧 🍨 🍩 🍪 🎂 🍰 🧁 🥧 🍫 🍬 🍭 🍮 🍯 🍼 🥛 ☕ 🫖 🍵 🍶 🍾 🍷 🍸 🍹 🍺 🍻 🥂 🥃 🫗 🥤 🧋 🧃 🧉 🧊'},
    {id:'travel', icon:'🚗', label:'Viagens e lugares', items:'🚗 🚕 🚙 🚌 🚎 🏎 🚓 🚑 🚒 🚐 🛻 🚚 🚛 🚜 🛵 🏍 🛺 🚲 🛴 🛹 🛼 🚏 🛣 🛤 🛢 ⛽ 🛞 🚨 🚥 🚦 🚧 ⚓ 🛟 ⛵ 🛶 🚤 🛳 ⛴ 🛥 🚢 ✈️ 🛩 🛫 🛬 🪂 💺 🚁 🚟 🚠 🚡 🛰 🚀 🛸 🌍 🌎 🌏 🌐 🗺 🧭 🏔 ⛰ 🌋 🗻 🏕 🏖 🏜 🏝 🏞 🏟 🏛 🏗 🧱 🪨 🪵 🛖 🏘 🏚 🏠 🏡 🏢 🏣 🏤 🏥 🏦 🏨 🏩 🏪 🏫 🏬 🏭 🏯 🏰 💒 🗼 🗽 ⛪ 🕌 🛕 🕍 ⛩ 🕋 ⛲ ⛺ 🌁 🌃 🏙 🌄 🌅 🌆 🌇 🌉 ♨️ 🎠 🛝 🎡 🎢 💈 🗿 🛎 🧳 🪧'},
    {id:'activities', icon:'⚽', label:'Atividades e esportes', items:'⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🥏 🪃 🏓 🏸 🏒 🏑 🥍 🏏 🪁 🥅 ⛳ 🪀 🏹 🎣 🤿 🥊 🥋 🎽 🛹 🛼 🛷 ⛸ 🥌 🎿 ⛷ 🏂 🪂 🏋️ 🤼 🤸 ⛹️ 🤾 🏌️ 🏇 🧘 🏄 🏊 🚣 🚴 🚵 🧗 🪇 🎮 🕹 🎰 🎲 🧩 🧸 🪅 🪩 🪆 ♟ 🎯 🎳 🎮 🎱 🪄 🧿 🪬 🏆 🥇 🥈 🥉 🏅 🎖 🏵 🎗 🎫 🎟 🎪 🤹 🎭 🎨 🧵 🪡 🧶 🪢'},
    {id:'objects', icon:'💡', label:'Objetos', items:'⌚ 📱 📲 💻 ⌨️ 🖥 🖨 🖱 🖲 🕹 💽 💾 💿 📀 📼 📷 📸 📹 🎥 📽 🎞 📞 ☎️ 📟 📠 📺 📻 🎙 🎚 🎛 🧭 ⏱ ⏲ ⏰ 🕰 ⌛ ⏳ 📡 🔋 🪫 🔌 💡 🔦 🕯 🪔 🧯 🛢 🪞 🪟 🛏 🛋 🪑 🚪 🪠 🚽 🚿 🛁 🪤 🪒 🧴 🧷 🧹 🧺 🧻 🪣 🧼 🫧 🪥 🧽 🧸 🧵 🪡 🧶 🪢 👓 🕶 🥽 🦺 👔 👕 👖 🧣 🧤 🧥 🧦 👗 👘 🥻 🩱 🩲 🩳 👙 👚 🪭 👛 👜 👝 🛍 🎒 🩴 👞 👟 🥾 🥿 👠 👡 🩰 👢 👑 👒 🎩 🎓 🧢 ⛑ 📿 💄 💍 💎 🔇 🔈 🔉 🔊 📢 📣 📯 🔔 🔕 🎼 🎵 🎶 🎤 🎧 📻 🎷 🪗 🎸 🎹 🎺 🎻 🪕 🥁 🪘 📔 📕 📖 📗 📘 📙 📚 📓 📒 📃 📜 📄 📰 🗞 📑 🔖 🏷 💰 🪙 💴 💵 💶 💷 💸 💳 🧾 💹 ✉️ 📧 📨 📩 📤 📥 📦 🏷 📪 📫 📬 📭 📮 📝 💼 📁 📂 🗂 📅 📆 🗒 🗓 📇 📈 📉 📊 📋 📌 📍 📎 🖇 📏 📐 ✂️ 🗃 🗄 🗑 🔒 🔓 🔏 🔐 🔑 🗝 🔨 🪓 ⛏ ⚒ 🛠 🗡 ⚔️ 💣 🪃 🛡 🪚 🔧 🪛 🔩 ⚙️ 🗜 ⚖️ 🦯 🔗 ⛓ 🪝 🧰 🧲 🪜 🧪 🧫 🧬 🔬 🔭 📡 💉 🩸 💊 🩹 🩺 🩻 🚬 ⚰️ 🪦 ⚱️ 🧿 🪬 🗿 🪧'},
    {id:'symbols', icon:'❤️', label:'Símbolos', items:'❤️ 🧡 💛 💚 💙 🩵 💜 🤎 🖤 🩶 🤍 💔 ❤️‍🔥 ❤️‍🩹 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ☮️ ✝️ ☪️ 🕉 ☸️ ✡️ 🔯 🕎 ☯️ ☦️ 🛐 ⛎ ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ 🆔 ⚛️ 🉑 ☢️ ☣️ 📴 📳 🈶 🈚 🈸 🈺 🈷️ ✴️ 🆚 💮 🉐 ㊙️ ㊗️ 🈴 🈵 🈹 🈲 🅰️ 🅱️ 🆎 🆑 🅾️ 🆘 ❌ ⭕ 🛑 ⛔ 📛 🚫 💯 💢 ♨️ 🚷 🚯 🚳 🚱 🔞 📵 🚭 ❗ ❕ ❓ ❔ ‼️ ⁉️ 🔅 🔆 〽️ ⚠️ 🚸 🔱 ⚜️ 🔰 ♻️ ✅ 🈯 💹 ❇️ ✳️ ❎ 🌐 💠 Ⓜ️ 🌀 💤 🏧 🚾 ♿ 🅿️ 🛗 🛄 🛅 🚹 🚺 🚼 🚻 🚮 🎦 📶 🈁 🔣 ℹ️ 🔤 🔡 🔠 🆕 🆓 🆙 🆒 🆗 🆖 🆗 🆙 🆕 🆓 🆕 🔟 🔢 #️⃣ *️⃣ 0️⃣ 1️⃣ 2️⃣ 3️⃣ 4️⃣ 5️⃣ 6️⃣ 7️⃣ 8️⃣ 9️⃣ ➕ ➖ ➗ ✖️ ♾️ 💲 💱 ™️ ©️ ®️〰️ ➰ ➿ 🔚 🔙 🔛 🔝 🔜 ⬆️ ↗️ ➡️ ↘️ ⬇️ ↙️ ⬅️ ↖️ ↕️ ↔️ ↩️ ↪️ ⤴️ ⤵️ 🔀 🔁 🔂 🔄 🔃 🎵 🎶 🔼 🔽 ⏫ ⏬ ➡️ ⬅️ ⬆️ ⬇️ 🔺 🔻 🔸 🔹 🔶 🔷 🔳 🔲 ▪️ ▫️ ◾ ◽ ◼️ ◻️ ⬛ ⬜ 🔴 🟠 🟡 🟢 🔵 🟣 🟤 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 🟫 ⬜ 🏁 🚩 🎌 🏴 🏳️ 🏳️‍🌈 🏳️‍⚧️'},
    {id:'flags', icon:'🏳️', label:'Bandeiras', items:'🏁 🚩 🎌 🏴 🏳️ 🏳️‍🌈 🏳️‍⚧️ 🇦🇴 🇧🇷 🇵🇹 🇺🇸 🇬🇧 🇨🇦 🇫🇷 🇩🇪 🇪🇸 🇮🇹 🇯🇵 🇰🇷 🇨🇳 🇮🇳 🇲🇽 🇦🇷 🇨🇱 🇨🇴 🇵🇪 🇺🇾 🇿🇦 🇳🇬 🇪🇬 🇲🇦 🇨🇻 🇲🇿 🇸🇹 🇬🇼 🇹🇱 🇹🇷 🇸🇦 🇦🇪 🇮🇱 🇺🇦 🇷🇺 🇸🇪 🇳🇴 🇫🇮 🇩🇰 🇳🇱 🇧🇪 🇨🇭 🇦🇺 🇳🇿 🇹🇭 🇵🇭 🇮🇩 🇸🇬 🇹🇼 🇭🇰 🏴‍☠️'}
  ];
  let emojiCategory = 'smileys';
  let recentEmojis = [];

  function pickModeFor(el){
    if(!el) return 'lower';
    // Usa o tipo original guardado em data-_origType (prepareTextInputs converte number→text)
    const origType=(el.dataset&&el.dataset._origType)||'';
    const t=(origType||el.type||'').toLowerCase();
    // Usa o inputmode ORIGINAL guardado em data-_origInputmode quando existir
    // (o atributo inputmode real foi forçado para 'none' para bloquear o
    // teclado nativo — ver tag()/prepareTextInputs), senão cai no atual.
    const im=((el.dataset&&el.dataset._origInputmode)||(el.getAttribute&&el.getAttribute('inputmode'))||'').toLowerCase();
    const step=el.getAttribute&&el.getAttribute('step');
    if(t==='number'||im==='numeric'||im==='decimal')
      return(im==='decimal'||step==='any')?'dec':'num';
    return 'lower';
  }

  /* ── POLÍTICA DE MAIÚSCULAS (como no teclado do Android) ────────────────
     none      -> pesquisa, URL, utilizador, senha/PIN, números: tudo minúsculo
     words     -> títulos, nomes, autores, gêneros, nomes de lista: cada palavra
     sentences -> comentários/textos corridos: início do texto e depois de . ! ?
     Só os textos corridos têm autocorreção ao espaço (em títulos/nomes seria
     errado "corrigir" nomes próprios e romaji). */
  function capPolicy(el){
    if(!el) return 'none';
    const t=((el.dataset&&el.dataset._origType)||el.type||'text').toLowerCase();
    if(['password','url','email','number','tel','search'].includes(t)) return 'none';
    if(el.dataset && el.dataset.ckbReadonlyOk==='1') return 'none';
    const id=el.id||'';
    if(/search|busca|pesquis|capa_url|pwd|pin|senha|usuario|lockcreateuser/i.test(id)) return 'none';
    if(el.tagName==='TEXTAREA' || id==='f_comentario') return 'sentences';
    return 'words';
  }

  /* ── DOM ─────────────────────────────────────────────────────────────── */
  // Container principal do teclado
  const KB = document.createElement('div');
  KB.id = 'customKb'; KB.className = 'ckb';
  KB.setAttribute('aria-hidden','true');
  document.body.appendChild(KB);

  // Mede a altura REAL do teclado (em vez de confiar no valor fixo de
  // --ckb-h no CSS) e mantém a variável CSS sincronizada. Sem isso, em
  // telas com tamanho de fonte diferente (ver breakpoints de html{font-size}
  // na folha móvel) a altura reservada para o teclado podia não bater com a
  // altura real, deixando uma faixa do conteúdo por trás aparecer — foi essa
  // a sobreposição observada na tela de login/PIN.
  if(typeof ResizeObserver !== 'undefined'){
    try{
      const ro = new ResizeObserver(() => {
        const h = KB.getBoundingClientRect().height;
        if(h > 0){
          document.documentElement.style.setProperty('--ckb-h', h + 'px');
          if(!KB.classList.contains('ckb-emoji-mode')){
            document.documentElement.style.setProperty('--ckb-standard-h', h + 'px');
          }
        }
      });
      ro.observe(KB);
    }catch(_){}
  }

  // Barra de sugestões — DENTRO do teclado, primeira linha, altura fixa
  const SBAR = document.createElement('div');
  SBAR.className = 'ckb-sbar';
  KB.appendChild(SBAR);

  // Popup de acentos — flutuante, z-index máximo, NÃO afecta layout
  const POP = document.createElement('div');
  POP.id = 'ckbAccentPop'; POP.className = 'ckb-accent-pop';
  KB.appendChild(POP);

  /* ── ESTADO ───────────────────────────────────────────────────────────── */
  let mode       = 'upper';
  let modeBeforeEmoji = 'lower';
  let capsLockBeforeEmoji = false;
  let capsLock   = false;
  let target     = null;
  let lastShift  = 0;
  let lastSpace  = 0;
  let clipText   = ''; // último texto copiado, para sugestão de colar (como no teclado nativo)

  // Long-press
  let _lpTimer    = null;
  let _lpKey      = null;
  let _lpBtn      = null;
  let _lpPid      = null;     // pointer id que iniciou o long-press
  let _lpDX       = 0, _lpDY = 0;
  let _lpOpen     = false;    // popup está aberto
  let _lpConsumed = false;    // impede click de inserir a letra base

  // ── Navegação lateral pela barra de espaço (arrastar para mover o cursor,
  //    tal como no teclado nativo do iOS/Android) ──────────────────────────
  let _spPid        = null;   // pointer id que iniciou o arrasto na barra de espaço
  let _spStartX     = 0;
  let _spStartCaret = 0;      // posição do cursor no início do gesto
  let _spLastCaret  = -1;     // evita focar/selecionar novamente a mesma posição
  let _spDragging   = false;  // já ultrapassou o limiar e está a mover o cursor
  let _spConsumed   = false;  // impede o click de inserir um espaço depois do arrasto
  const SP_STEP_PX = 20;      // px por caractere movido (arrasto controlado)
  const SP_DRAG_THRESHOLD = 12; // px mínimos para começar a considerar arrasto

  // ── Apagar contínuo ao segurar BACKSPACE (tal como no teclado nativo) ────
  let _bkPid       = null;   // pointer id que iniciou o toque em BACK
  let _bkTimer     = null;   // timer do delay inicial / dos passos de repetição
  let _bkRepeating = false;  // já entrou em modo de repetição contínua
  let _bkConsumed  = false;  // impede o click de apagar mais um caractere depois da repetição
  let _bkCount     = 0;      // nº de apagões já feitos na repetição (para acelerar)
  const BACK_REPEAT_DELAY    = 420; // ms segurando antes de começar a repetir
  const BACK_REPEAT_START_MS = 110; // intervalo inicial entre apagões
  const BACK_REPEAT_MIN_MS   = 30;  // intervalo mínimo (velocidade máxima)

  /* ── SUGESTÕES DE PALAVRAS ────────────────────────────────────────────── */
  const PT = ('a o e é de da do das dos um uma os as ao aos na no nas nos por para com em que se não mas ou ele ela eles elas eu tu nós isso isto aqui ali lá cá aí já bem mal muito pouco mais menos também só ainda assim sempre nunca jamais como quando onde quem qual quais porque pois então porém contudo entretanto logo todavia sou és somos são era eram fui foi fomos foram será serão seria seríamos seriam sendo sido ser estou está estamos estão estava estavam estive esteve estivemos estiveram estará estarão estaria estando estado estar tenho tens tem temos têm tinha tínhamos tinham tive teve tivemos tiveram terá terão teria teremos tendo tido ter vou vai vamos vão ia iam irá irão iria indo ir faço faz fazemos fazem fazia faziam fiz fez fizemos fizeram feito fazendo farei fará farão faria fazer posso pode podemos podem podia podiam pude pôde pudemos puderam poderia podendo podido poder quero quer queremos querem queria queriam quis quisemos quiseram querido querendo querer sei sabe sabemos sabem sabia sabiam soube soubemos souberam sabendo sabido saber vejo vê vemos veem via viam vi viu vimos viram visto vendo verei verá verão veria ver dou dá damos dão dava davam dei deu demos deram dado dando darei dará darão daria dar venho vem vêm vinha vinham vim veio viemos vieram vindo virei virá virão viria vir digo diz dizemos dizem dizia diziam disse dissemos disseram dito dizendo direi dirá dirão diria dizer falo fala falamos falam falava falavam falei falou falaram falado falando falarei falará falarão falaria falar gosto gosta gostamos gostam gostava gostavam gostei gostou gostaram gostado gostando gostarei gostará gostaria gostar assisto assiste assistimos assistem assistia assistiam assisti assistiu assistiram assistido assistindo assistirei assistirá assistiria assistir leio lê lemos leem lia liam li leu leram lido lendo lerei lerá lerão leria ler amo ama amamos amam amava amavam amei amou amaram amado amando amarei amará amarão amaria amar adoro adora adoramos adoram adorava adoravam adorei adorou adoraram adorado adorando adorarei adorará adoraria adorar odeio odeia odiamos odeiam odiava odiavam odiei odiou odiaram odiado odiando odiarei odiará odiaria odiar começo começa começamos começam começava começavam comecei começou começaram começado começando começarei começará começaria começar termino termina terminamos terminam terminava terminavam terminei terminou terminaram terminado terminando terminarei terminará terminaria terminar acho acha achamos acham achava achavam achei achou acharam achado achando acharei achará achariam achar penso pensa pensamos pensam pensava pensavam pensei pensou pensaram pensado pensando pensarei pensará pensaria pensar sinto sente sentimos sentem sentia sentiam senti sentiu sentiram sentido sentindo sentirei sentirá sentiria sentir recomendo recomenda recomendamos recomendam recomendava recomendei recomendou recomendaram recomendado recomendando recomendarei recomendará recomendaria recomendar preciso precisa precisamos precisam precisava precisei precisou precisaram precisado precisando precisarei precisará precisaria precisar continuo continua continuamos continuam continuava continuei continuou continuaram continuado continuando continuarei continuará continuaria continuar espero espera esperamos esperam esperava esperei esperou esperaram esperado esperando esperarei esperará esperaria esperar volto volta voltamos voltam voltava voltei voltou voltaram voltado voltando voltarei voltará voltaria voltar compro compra compramos compram comprava comprei comprou compraram comprado comprando comprarei comprará compraria comprar deixo deixa deixamos deixam deixava deixei deixou deixaram deixado deixando deixarei deixará deixaria deixar chego chega chegamos chegam chegava cheguei chegou chegaram chegado chegando chegarei chegará chegaria chegar entendo entende entendemos entendem entendia entendi entendeu entenderam entendido entendendo entenderei entenderá entenderia entender conheço conhece conhecemos conhecem conhecia conheci conheceu conheceram conhecido conhecendo conhecerei conhecerá conheceria conhecer descubro descobre descobrimos descobrem descobria descobri descobriu descobriram descoberto descobrindo descobrirei descobrirá descobriria descobrir sigo segue seguimos seguem seguia segui seguiu seguiram seguido seguindo seguirei seguirá seguiria seguir conto conta contamos contam contava contei contou contaram contado contando contarei contará contaria contar curto curte curtimos curtem curtia curtei curtiu curtiram curtido curtindo curtir detesto detesta detestamos detestam detestava detestei detestou detestaram detestado detestando detestar aprecio aprecia apreciamos apreciam apreciava apreciei apreciou apreciaram apreciado apreciando apreciar novo nova novos novas bom boa bons boas ruim ruins grande grandes pequeno pequena pequenos pequenas belo bela belos belas bonito bonita bonitos bonitas feio feia feios feias lindo linda lindos lindas horrível horríveis ótimo ótima ótimos ótimas péssimo péssima péssimos péssimas excelente excelentes terrível terríveis incrível incríveis impressionante impressionantes emocionante emocionantes empolgante empolgantes envolvente envolventes cativante cativantes triste tristes feliz felizes alegre alegres chato chata chatos chatas divertido divertida divertidos divertidas interessante interessantes entediante entediantes cansativo cansativa cansativos cansativas intenso intensa intensos intensas épico épica épicos épicas dramático dramática dramáticos dramáticas cômico cômica cômicos cômicas sério séria sérios sérias engraçado engraçada engraçados engraçadas estranho estranha estranhos estranhas normal normais especial especiais único única únicos únicas perfeito perfeita perfeitos perfeitas completo completa completos completas longo longa longos longas curta curtos curtas rápido rápida rápidos rápidas lento lenta lentos lentas forte fortes fraco fraca fracos fracas claro clara claros claras escuro escura escuros escuras rico rica ricos ricas pobre pobres simples complexo complexa complexos complexas profundo profunda profundos profundas superficial superficiais real reais falso falsa verdadeiro verdadeira verdadeiros verdadeiras importante importantes necessário necessária possível possíveis impossível impossíveis provável prováveis improvável improváveis fácil fáceis difícil difíceis favorito favorita favoritos favoritas preferido preferida preferidos preferidas diferente diferentes igual iguais similar similares típico típica clássico clássica moderno moderna antigo antiga surpreendente surpreendentes previsível previsíveis imprevisível imprevisíveis satisfatório satisfatória decepcionante decepcionantes melhor melhores pior piores maior maiores menor menores primeiro primeira segundo segunda terceiro terceira último última próximo próxima anterior anteriores mesmo mesma outros outras todo toda todos todas cada qualquer nenhum algum vários várias certo certa legal legais maravilhoso maravilhosa magnifico magnífica glorioso gloriosa sublime sublimes medíocre medíocres razoável razoáveis aceitável aceitáveis história histórias personagem personagens enredo enredos final finais começos início inícios cena cenas capítulo capítulos temporada temporadas episódio episódios arco arcos saga sagas tomo tomos volume volumes obra obras narrativa narrativas trama tramas diálogo diálogos anime animes manga mangá mangas novel novels livro livros filme filmes série séries programa programas streaming plataforma plataformas jogo jogos quadrinho quadrinhos autor autora autores autoras escritor escritora escritores escritoras diretor diretora diretores diretoras roteirista roteiristas animador animadora estúdio estúdios editora editoras produtora produtoras gênero gêneros estilo estilos animação animações dublagem legendas legenda protagonista protagonistas antagonista antagonistas vilão vilã vilões vilãs herói heroína heróis heroínas principal secundário secundária poderes magia batalha batalhas guerra guerras paz amizade família fantasia ação romance comédia terror suspense mistério mistérios ficção científica histórica medieval contemporâneo sobrenatural psicológico adaptação adaptações remake reboot clichê clichês reviravolta reviravoltas surpresa surpresas revelação revelações twist cliffhanger worldbuilding lore plot abertura encerramento openning ending filler canon spin-off crossover nota avaliação classificação estrelas pontuação recomendação tempo tempos lugar lugares coisa coisas parte partes momento momentos forma formas modo modos verdade verdades vida vidas mundo mundos pessoa pessoas gente povo homem mulher homens mulheres menino menina meninos meninas criança crianças adulto adulta jovem jovens idoso idosa país países cidade cidades casa casas escola escolas trabalho dinheiro famílias amigo amiga amigos amigas filho filha filhos filhas pai mãe irmão irmã coração mente olhos mãos voz vozes nome nomes data datas hora horas dia dias noite noites semana semanas mês meses ano anos ideia ideias razão razões motivo motivos resultado resultados problema problemas solução soluções ponto pontos nível níveis caso casos situação situações contexto contextos detalhe detalhes sentidos amor amores bastante demais quase apenas somente simplesmente totalmente completamente absolutamente realmente verdadeiramente obviamente claramente infelizmente felizmente naturalmente facilmente dificilmente rapidamente lentamente fortemente especialmente principalmente finalmente provavelmente certamente geralmente normalmente raramente frequentemente hoje ontem amanhã cedo tarde depois antes passado presente futuro recente releitura reassistir rever reler reli reassisti absurdo absurda absurdos absurdas nossa caramba cara tipo né enfim').split(' ').filter(Boolean);

  // Vocabulário geral do dia-a-dia (fora do domínio de animes/séries/livros),
  // para o teclado sugerir palavras comuns como "água", números, cores, dias
  // da semana, família, casa, comida, tecnologia, saudações, etc. — o que
  // antes faltava (ex.: escrever "ag" não sugeria "água").
  const PT_EXTRA = ('água agua fogo terra ar vento sol lua estrela estrelas céu ceu chuva nuvem nuvens '+
  'praia mar rio montanha floresta árvore arvore árvores flor flores animal animais cachorro cão gato '+
  'pássaro passaro peixe peixes calor frio quente fresco tempo clima '+
  'olá ola oi oii tchau adeus obrigado obrigada por favor desculpa desculpe perdão perdao com licença licenca '+
  'bom dia boa tarde boa noite tudo bem como vai vais tudo bom até já ate ja até logo ate logo '+
  'sim não nao talvez claro certeza obviamente '+
  'zero um dois duas três tres quatro cinco seis sete oito nove dez onze doze treze catorze quatorze quinze '+
  'dezasseis dezesseis dezassete dezessete dezoito dezanove dezenove vinte trinta quarenta cinquenta sessenta '+
  'setenta oitenta noventa cem cento duzentos trezentos quatrocentos quinhentos mil milhão milhao milhões milhoes '+
  'primeiro segundo terceiro quarto quinto sexto sétimo setimo oitavo nono décimo decimo '+
  'branco branca preto preta vermelho vermelha azul verde amarelo amarela laranja roxo roxa rosa cinza cinzento '+
  'marrom castanho dourado dourada prateado prateada '+
  'domingo segunda terça terca quarta quinta sexta sábado sabado feira semana '+
  'janeiro fevereiro março marco abril maio junho julho agosto setembro outubro novembro dezembro '+
  'cabeça cabeca cabelo cabelos olho olhos nariz boca dente dentes orelha orelhas braço braco braços bracos '+
  'perna pernas mão mao mãos maos pé pe pés pes dedo dedos costas barriga corpo rosto pele '+
  'avô avo avó tio tia primo prima sobrinho sobrinha namorado namorada marido esposa noivo noiva '+
  'casa quarto sala cozinha banheiro casa-de-banho jardim quintal porta portão portao janela mesa cadeira '+
  'cama sofá sofa televisão televisao tv computador portátil portatil telemóvel telemovel celular telefone '+
  'carro ônibus onibus autocarro avião aviao comboio trem metro bicicleta moto chave chaves carteira bolsa '+
  'dinheiro roupa roupas sapato sapatos camisa camiseta calça calca calças calcas casaco vestido '+
  'pão pao arroz feijão feijao carne frango peixe fruta frutas maçã maca banana laranja uva manga morango '+
  'leite queijo ovo ovos café cafe chá cha suco sumo cerveja vinho açúcar acucar sal pimenta '+
  'almoço almoco jantar café-da-manhã cafe da manha lanche sobremesa comida bebida cozinhar receita '+
  'escola universidade faculdade hospital mercado mercearia supermercado loja shopping rua avenida cidade '+
  'país pais bairro praça praca parque estádio estadio igreja aeroporto estação estacao hotel restaurante '+
  'hoje amanhã amanha ontem agora depois antes sempre nunca cedo tarde manhã manha noite '+
  'ano meses mês mes dia dias hora horas minuto minutos segundo segundos '+
  'grande pequeno pequena alto alta baixo baixa gordo gorda magro magra forte fraco fraca rápido rapido '+
  'lenta lento fácil facil difícil dificil caro cara barato barata limpo limpa sujo suja velho velha jovem '+
  'internet aplicativo app site página pagina senha email correio arquivo ficheiro pasta download descarregar '+
  'upload wifi bateria tela ecrã ecra aplicação aplicacao atualização atualizacao configuração configuracao '+
  'mensagem mensagens notificação notificacao câmara camara câmera camera fotografia foto vídeo video áudio audio '+
  'ajuda ajudar preciso quero necessito problema solução solucao pergunta perguntas resposta respostas '+
  'trabalho emprego escritório escritorio reunião reuniao projeto tarefa tarefas horário horario '+
  'estudo estudar aprender ensinar professor professora aluno aluna escola aula aulas exame prova nota notas '+
  'saúde saude doença doenca médico medico médica medica hospital farmácia farmacia remédio remedio '+
  'feliz aniversário aniversario parabéns parabens presente festa convite convidado '+
  'viagem viajar férias ferias passeio passear hotel bagagem mala malas passaporte bilhete bilhetes '+
  'desporto esporte esportes futebol basquete vôlei volei corrida ginásio ginasio treino '+
  'música musica cantor cantora banda concerto show teatro cinema livro livraria biblioteca '+
  'natureza planta plantas jardim horta '+
  'obrigado desde já obrigado desde ja por enquanto enquanto isso portanto entretanto contudo').split(/\s+/).filter(Boolean);

  function nW(w){ return w.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,''); }
  function eD(a,b){
    if(Math.abs(a.length-b.length)>2) return 99;
    const m=a.length,n=b.length,dp=[];
    for(let i=0;i<=m;i++){dp[i]=[];for(let j=0;j<=n;j++)dp[i][j]=i?j?0:i:j;}
    for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]:1+Math.min(dp[i-1][j],dp[i][j-1],dp[i-1][j-1]);
    return dp[m][n];
  }
  // PERF: normaliza o dicionário base UMA vez (em vez de recalcular nW() a
  // cada tecla digitada, que era o principal gargalo do teclado). O mesmo
  // vale para as palavras aprendidas do usuário (_uwNorm), recalculadas só
  // quando o cache de uW() é invalidado.
  // Junta o vocabulário de domínio (animes/séries/livros/avaliações) com o
  // vocabulário geral do dia-a-dia, sem repetir palavras.
  const PT_ALL = Array.from(new Set([...PT, ...PT_EXTRA]));
  const LANG_DICT = Object.fromEntries(LANGS.map(code => [code, Array.from(new Set((MULTI_DICT[code] || '').split(/\s+/).filter(Boolean)))]));
  const PT_NORM = PT_ALL.map(w => [w, nW(w)]);
  // PERF: agrupa o dicionário por primeira letra (sem acento) — como uma
  // sugestão de prefixo só pode vir de palavras que começam pela mesma
  // letra que já foi digitada, isto evita varrer o dicionário inteiro a
  // cada tecla, o que importa cada vez mais à medida que o dicionário cresce.
  function buildBuckets(pairs){
    const map = new Map();
    for(const pair of pairs){
      const c = pair[1].charAt(0);
      let arr = map.get(c);
      if(!arr){ arr = []; map.set(c, arr); }
      arr.push(pair);
    }
    return map;
  }
  const PT_BUCKETS = buildBuckets(PT_NORM);
  const LANG_BUCKETS = Object.fromEntries(LANGS.map(code => [code, buildBuckets((LANG_DICT[code] || []).map(w => [w, nW(w)]))]));
  // Correções curtas e previsíveis aparecem antes das sugestões genéricas,
  // mas continuam sendo opcionais: o usuário sempre decide ao tocar nelas.
  const COMMON_FIXES = {
    vc:'você', vcs:'vocês', tb:'também', tbm:'também', pq:'porque', q:'que',
    ñao:'não', nao:'não', n:'não', voce:'você', voces:'vocês',
    filmee:'filme', series:'séries', capitulo:'capítulo', capitulos:'capítulos',
    episodio:'episódio', episodios:'episódios', avaliacao:'avaliação',
    otimo:'ótimo', otima:'ótima', pessimo:'péssimo', pessima:'péssima'
  };
  let _uwC=null,_uwT=0,_uwNorm=null,_uwBuckets=null;
  function uW(){
    const now=Date.now();if(_uwC&&now-_uwT<30000)return _uwC;
    try{
      const ws=new Set();
      const addWords=t=>String(t).split(/[\s,.:;!?()\[\]{}\n]+/)
        .forEach(w=>{const c=w.replace(/[^\p{L}\p{M}]/gu,'');if([...c].length>=2)ws.add(c.toLowerCase());});
      // PERF: usa as obras que o app já tem em memória. Antes lia e fazia
      // JSON.parse de TODO o acervo (com capas) no localStorage, o que travava
      // o teclado de tempos a tempos enquanto se escrevia.
      const mem=(window.__acervoBridge && window.__acervoBridge.entries) ? window.__acervoBridge.entries() : null;
      if(mem){
        mem.forEach(e=>{ if(e) [e.titulo,e.titulo_original,e.comentario,e.autor].filter(Boolean).forEach(addWords); });
      } else {
        const raw=localStorage.getItem(nsKey('acervo-entries-v2'));
        if(raw) JSON.parse(raw).forEach(e=>[e.titulo,e.titulo_original,e.comentario,e.autor].filter(Boolean).forEach(addWords));
      }
      const cust=localStorage.getItem(nsKey('acervo-uwords'));
      if(cust){try{JSON.parse(cust).forEach(w=>{if(w)ws.add(w.toLowerCase());});}catch(_){}}
      _uwC=[...ws];_uwT=now;_uwNorm=_uwC.map(w=>[w,nW(w)]);_uwBuckets=buildBuckets(_uwNorm);return _uwC;
    }catch(_){_uwC=[];_uwT=now;_uwNorm=[];_uwBuckets=new Map();return _uwC;}
  }
  function learnWord(w){
    if(!w||[...String(w)].length<2)return;
    const wl=String(w).toLowerCase().replace(/[^\p{L}\p{M}]/gu,'');
    if(wl.length<3)return;
    const nw=nW(wl);
    if(PT_NORM.some(p=>p[1]===nw))return; // já está no dicionário base
    try{
      const raw=localStorage.getItem(nsKey('acervo-uwords'));
      const arr=raw?JSON.parse(raw):[];
      if(!arr.includes(wl)){arr.push(wl);localStorage.setItem(nsKey('acervo-uwords'),JSON.stringify(arr));}
      _uwC=null;_uwNorm=null; // invalida cache
    }catch(_){}
  }
  function learnWordsFromText(txt){
    String(txt||'').split(/[\s,.:;!?()\[\]{}\n"'“”«»]+/).forEach(w=>{
      const c=w.replace(/[^a-zA-ZÀ-ÿ]/g,'');
      if(c.length>=3) learnWord(c);
    });
  }
  function getSugs(word){
    if(!word||word.length<2) return [];
    const n=nW(word),up1=word[0]!==word[0].toLowerCase(),cap=s=>s?s[0].toUpperCase()+s.slice(1):s;
    const directFix = COMMON_FIXES[n] && nW(COMMON_FIXES[n]) !== n ? [cap(COMMON_FIXES[n])] : [];
    uW(); // garante _uwNorm/_uwBuckets atualizados (cache de 30s, não recalcula a cada tecla)
    const c0 = n.charAt(0);
    // Só olha para palavras que começam pela mesma letra (sem acento) — é
    // impossível uma sugestão de prefixo vir de outro lugar do dicionário.
    // Palavras que o próprio utilizador já usou (títulos, comentários,
    // palavras aprendidas) vêm primeiro: são mais relevantes para o seu
    // acervo do que uma palavra genérica do dicionário.
    const userBucket = (_uwBuckets && _uwBuckets.get(c0)) || [];
    const langBucket = (LANG_BUCKETS[language] && LANG_BUCKETS[language].get(c0)) || [];
    const staticBucket = language === 'pt' ? (PT_BUCKETS.get(c0) || []) : langBucket;
    const preUser=[], preDict=[], cl=[];
    for(const pair of userBucket){
      const n2=pair[1];
      if(n2!==n && n2.startsWith(n) && n2.length>n.length) preUser.push(pair[0]);
    }
    for(const pair of staticBucket){
      const n2=pair[1];
      if(n2!==n && n2.startsWith(n) && n2.length>n.length) preDict.push(pair[0]);
    }
    preUser.sort((a,b)=>a.length-b.length);
    preDict.sort((a,b)=>a.length-b.length);
    const pre = preUser.concat(preDict);
    // Tolerância a erros de digitação (distância de edição 1): só é
    // calculada quando ainda faltam sugestões por prefixo — evita centenas
    // de cálculos a cada tecla quando já temos o suficiente.
    if(pre.length<3 && n.length>=4){
      const dict = userBucket.concat(staticBucket);
      for(const pair of dict){
        const w2=pair[0], n2=pair[1];
        if(n2===n)continue;
        if(n2.length>=n.length-1&&n2.length<=n.length+1&&eD(n,n2)===1)cl.push(w2);
      }
    }
    const seen=new Set(),out=[];
    for(const w2 of [...directFix,...pre,...cl]){
      const f=up1?cap(w2):w2;
      if(!seen.has(f.toLowerCase())&&f.toLowerCase()!==word.toLowerCase()){seen.add(f.toLowerCase());out.push(f);}
      if(out.length>=4)break;
    }
    return out;
  }
  function currWord(){
    if(!target)return '';
    try{
      const v=target.value||'',p=target.selectionStart??v.length;
      const m=v.slice(0,p).match(/([^\s,.:;!?'"()\[\]{}\n]+)$/);
      return m?m[1]:'';
    }catch(_){return '';}
  }

  function _renderSbarNow(){
    SBAR.replaceChildren();
    if(!target||NUMERIC_MODES.has(mode))return;
    const emojiToggle=document.createElement('button');
    emojiToggle.type='button';
    emojiToggle.className='ckb-sbar-emoji';
    emojiToggle.textContent=mode==='emoji'?'ABC':'😊';
    emojiToggle.setAttribute('aria-label',mode==='emoji'?'Voltar ao teclado de letras':'Abrir emojis');
    emojiToggle.addEventListener('pointerdown',e=>e.preventDefault());
    emojiToggle.addEventListener('mousedown',e=>e.preventDefault());
    emojiToggle.addEventListener('click',e=>{
      e.preventDefault(); e.stopPropagation();
      if(mode==='emoji'){
        mode=modeBeforeEmoji;
        capsLock=capsLockBeforeEmoji;
      } else {
        const keyboardHeight = KB.getBoundingClientRect().height;
        if(keyboardHeight > 0){
          document.documentElement.style.setProperty('--ckb-standard-h', keyboardHeight + 'px');
        }
        modeBeforeEmoji=mode;
        capsLockBeforeEmoji=capsLock;
        mode='emoji';
        capsLock=false;
      }
      closeAccentPop();
      render();
      renderSbar();
    });
    SBAR.appendChild(emojiToggle);
    const word=currWord();
    const items=[];
    if(!word && clipText && clipText.trim()){
      const preview=clipText.trim().replace(/\s+/g,' ');
      items.push({t:'📋 '+(preview.length>28?preview.slice(0,28)+'…':preview), clip:true});
    }
    if(word&&word.length>=2){
      const sugs=getSugs(word);
      if(sugs[0])items.push({t:sugs[0],c:false});
      items.push({t:word,c:true});
      if(sugs[1])items.push({t:sugs[1],c:false});
      if(sugs[2])items.push({t:sugs[2],c:false});
    }
    if(!items.length)return;
    const sep=document.createElement('span');sep.className='ckb-sbar-sep';SBAR.appendChild(sep);

    items.forEach((it,i)=>{
      if(i>0){const s=document.createElement('span');s.className='ckb-sbar-sep';SBAR.appendChild(s);}
      const b=document.createElement('button');
      b.type='button'; b.className='ckb-sbar-item'+(it.c?' is-cur':'')+(it.clip?' is-clip':'');
      b.textContent=it.t;
      b.addEventListener('pointerdown',e=>e.preventDefault());
      b.addEventListener('mousedown',e=>e.preventDefault());
      b.addEventListener('click',ev=>{ev.preventDefault();it.clip?acceptClip():acceptSug(it.t);});
      SBAR.appendChild(b);
    });
  }

  let _sbarRaf = 0;
  function renderSbar(){
    if(_sbarRaf) return;
    const raf = window.requestAnimationFrame || (fn => setTimeout(fn, 0));
    _sbarRaf = raf(() => { _sbarRaf = 0; _renderSbarNow(); });
  }

  function acceptSug(word){
    if(!target||!word)return;
    try{
      const v=target.value||'',p=target.selectionStart??v.length;
      const m=v.slice(0,p).match(/([^\s,.:;!?'"()\[\]{}\n]+)$/);
      if(m){
        const st=p-m[1].length;
        // Salta também a parte da palavra que está DEPOIS do cursor
        const afterM=v.slice(p).match(/^([^\s,.:;!?'"()\[\]{}\n]*)/);
        const wordEnd=p+(afterM?afterM[1].length:0);
        const isGenreField = target.id === 'f_generos';
        const trailSpace = isGenreField ? ((wordEnd < v.length && /,\s*/.test(v.slice(wordEnd, wordEnd + 2))) ? '' : ', ') : ((wordEnd<v.length&&v[wordEnd]===' ')?'':' ');
        target.value=v.slice(0,st)+word+trailSpace+v.slice(wordEnd);
        const np=st+word.length+trailSpace.length;try{target.setSelectionRange(np,np);}catch(_){}
        _lastAuto=null;
        rememberCaret(target);
        target.dispatchEvent(new Event('input',{bubbles:true}));
        scrollCaretIntoView(target);
      learnWord(word);
        syncShift();
      }
      renderSbar();
    }catch(_){}
  }

  function acceptClip(){
    if(!target||!clipText)return;
    try{
      insertText(clipText.trim());
      learnWordsFromText(clipText);
      clipText='';
      renderSbar();
    }catch(_){}
  }

  /* ── MAIÚSCULAS AUTOMÁTICAS + TROCA RÁPIDA DE CASO ───────────────────── */
  function autoCapNeeded(){
    if(!target) return false;
    const pol=capPolicy(target);
    if(pol==='none') return false;
    const v=target.value||'';
    let p=target.selectionStart; if(typeof p!=='number') p=v.length;
    const before=v.slice(0,p);
    if(pol==='words') return before.length===0 || /[\s(\[{"\u201C\u00AB]$/.test(before);
    return before.trim().length===0 || /[.!?\u2026]["\u201D')\]]*\s+$/.test(before) || /\n\s*$/.test(before);
  }
  function paintShift(b){
    b.classList.remove('active','caps-lock');
    if(capsLock){ b.innerHTML='⬆'; b.style.removeProperty('font-size'); b.classList.add('caps-lock'); }
    else{ b.innerHTML='⇧'; b.style.fontSize='17px'; if(mode==='upper') b.classList.add('active'); }
  }
  // Troca minúsculas/maiúsculas EDITANDO as teclas existentes. Antes, cada
  // palavra nova reconstruía o teclado inteiro (≈35 botões + listeners), que
  // era a principal causa da lentidão ao escrever.
  function repaintCase(){
    const rows=layouts[mode]; if(!rows) return false;
    const rowEls=KB.querySelectorAll('.ckb-row');
    if(rowEls.length!==rows.length) return false;
    for(let r=0;r<rows.length;r++){
      const kids=rowEls[r].children;
      if(kids.length!==rows[r].length) return false;
      for(let c=0;c<rows[r].length;c++){
        const k=rows[r][c], b=kids[c];
        if(k==='SHIFT'){ paintShift(b); continue; }
        if(b.dataset.key===k) continue;
        const tn=b.firstChild;
        if(!tn || tn.nodeType!==3) return false;
        b.dataset.key=k; tn.nodeValue=k;
        if(b.__preview) b.__preview.textContent=k;
      }
    }
    return true;
  }
  function setMode(m){
    const prev=mode; mode=m;
    if((prev==='lower'||prev==='upper')&&(m==='lower'||m==='upper')){
      if(['ja','ko','zh'].includes(language)) return;   // o layout é igual nos dois modos
      if(repaintCase()) return;
    }
    render();
  }
  function syncShift(){
    if(!target||capsLock) return;
    if(mode!=='upper'&&mode!=='lower') return;
    const want=autoCapNeeded()?'upper':'lower';
    if(want!==mode) setMode(want);
  }

  /* ── AUTOCORREÇÃO (só textos corridos) + DESFAZER COM APAGAR ──────────── */
  const AUTO_FIX = {
    vc:'você', vcs:'vocês', voce:'você', voces:'vocês', tb:'também', tbm:'também', tambem:'também',
    pq:'porque', nao:'não', porem:'porém', entao:'então', alem:'além', ja:'já', ola:'olá',
    estao:'estão', sao:'são', ninguem:'ninguém', alguem:'alguém',
    historia:'história', historias:'histórias', serie:'série', series:'séries',
    capitulo:'capítulo', capitulos:'capítulos', episodio:'episódio', episodios:'episódios',
    avaliacao:'avaliação', avaliacoes:'avaliações', otimo:'ótimo', otima:'ótima',
    pessimo:'péssimo', pessima:'péssima', musica:'música', pagina:'página',
    ultimo:'último', ultima:'última', proximo:'próximo', proxima:'próxima',
    unico:'único', unica:'única', facil:'fácil', dificil:'difícil', possivel:'possível',
    impossivel:'impossível', incrivel:'incrível', horrivel:'horrível',
    acao:'ação', emocao:'emoção', producao:'produção', versao:'versão', adaptacao:'adaptação',
    animacao:'animação', coracao:'coração'
  };
  let _lastAuto=null;   // última autocorreção feita (para o apagar desfazer)
  let _skipAuto=null;   // palavra que o utilizador acabou de desfazer: não corrigir outra vez
  function tryAutoCorrect(){
    const el=target; if(!el||language!=='pt') return null;
    if(capPolicy(el)!=='sentences') return null;
    const v=el.value||'', p=el.selectionStart??v.length;
    if(p!==(el.selectionEnd??p)) return null;
    if(p<v.length && !/^[\s,.:;!?'"()\[\]{}\n]/.test(v.slice(p))) return null; // cursor no meio de uma palavra
    const m=v.slice(0,p).match(/([^\s,.:;!?'"()\[\]{}\n]+)$/);
    if(!m) return null;
    const w=m[1], low=w.toLowerCase(), fix=AUTO_FIX[low];
    if(!fix) return null;
    let out;
    if(w===low) out=fix;
    else if(w===low.charAt(0).toUpperCase()+low.slice(1)) out=fix.charAt(0).toUpperCase()+fix.slice(1);
    else if(w.length>1 && w===w.toUpperCase()) out=fix.toUpperCase();
    else return null;
    const st=p-w.length;
    if(_skipAuto && _skipAuto.el===el && _skipAuto.start===st && _skipAuto.orig===w){ _skipAuto=null; return null; }
    el.value=v.slice(0,st)+out+v.slice(p);
    const np=st+out.length; try{el.setSelectionRange(np,np);}catch(_){}
    return {el,start:st,orig:w,fixed:out};
  }

  /* ── GUARDA DO CURSOR (nunca "salta" para antes da 1ª letra) ──────────── */
  let _caretMem=null;          // última posição conhecida do cursor no campo ativo
  let _lastTouchInField=0;     // último toque do utilizador dentro do campo
  function rememberCaret(el){
    if(!el) return;
    try{ _caretMem={el,s:el.selectionStart,e:el.selectionEnd,v:el.value}; }catch(_){}
  }
  function restoreCaretIfMoved(el,expectedValue,pos){
    try{
      if(el.value===expectedValue && (el.selectionStart!==pos||el.selectionEnd!==pos)) el.setSelectionRange(pos,pos);
    }catch(_){}
    rememberCaret(el);
  }
  function onSelectionChange(){
    const el=target;
    if(!el||document.activeElement!==el||_spDragging) return;
    let s,e2; try{ s=el.selectionStart; e2=el.selectionEnd; }catch(_){ return; }
    const m=_caretMem;
    // Salto indevido: o cursor estava no FIM do texto e, sem nenhum toque do
    // utilizador no campo, foi parar ao início (0,0) com o texto igual.
    if(m && m.el===el && s===0 && e2===0 && m.s>0 && m.s===m.v.length && el.value===m.v
       && Date.now()-_lastTouchInField>900){
      try{ el.setSelectionRange(m.s,m.e); }catch(_){}
      return;
    }
    _caretMem={el,s,e:e2,v:el.value};
    syncShift();
  }
  document.addEventListener('selectionchange', onSelectionChange);
  (function trackUserTouch(){
    const mark=e=>{
      if(!target||!e.target||!e.target.closest) return;
      const f=e.target.closest('input,textarea');
      if(f===target) _lastTouchInField=Date.now();
    };
    ['pointerdown','pointerup','touchstart','touchend','mousedown'].forEach(ev=>document.addEventListener(ev,mark,{capture:true,passive:true}));
  })();

  /* ── POPUP DE ACENTOS (flutuante, como Gboard) ───────────────────────── */
  function openAccentPop(key, btnEl){
    const variants = ACCENT_MAP[key];
    if(!variants||!variants.length) return false;
    if(btnEl.__preview) btnEl.__preview.classList.remove('is-visible');

    POP.innerHTML = '';

    // Grid: até 5 por linha
    const cols = Math.min(5, variants.length);
    POP.style.setProperty('--pop-cols', cols);

    // Letra base com destaque (como o Gboard mostra a letra atual)
    const baseEl = document.createElement('div');
    baseEl.className = 'ckb-pop-base'; baseEl.textContent = key;
    POP.appendChild(baseEl);

    variants.forEach(v => {
      const el = document.createElement('button');
      el.type = 'button'; el.className = 'ckb-pop-item';
      el.textContent = v;
      el.addEventListener('pointerdown', e => e.preventDefault());
      el.addEventListener('mousedown',   e => e.preventDefault());
      el.addEventListener('click', ev => {
        ev.preventDefault(); ev.stopPropagation();
        closeAccentPop();
        insertText(v);
        renderSbar();
      });
      POP.appendChild(el);
    });

    // Posicionar dentro do teclado (position:absolute relativo ao KB)
    const kbRect = KB.getBoundingClientRect();
    POP.style.removeProperty('display');
    POP.classList.add('open');

    // Posição horizontal centrada na tecla premida, contida dentro do KB
    const btnRect = btnEl.getBoundingClientRect();
    const popW = cols * 52 + 16; // estimativa
    let left = (btnRect.left - kbRect.left) + btnRect.width / 2 - popW / 2;
    left = Math.max(8, Math.min(left, KB.offsetWidth - popW - 8));
    POP.style.left = left + 'px';
    // Aparece logo abaixo da barra de sugestões, dentro do teclado
    POP.style.top = (SBAR.offsetHeight + 6) + 'px';
    POP.style.removeProperty('bottom');

    _lpOpen = true;
    try{ navigator.vibrate && navigator.vibrate(10); }catch(_){}
    return true;
  }

  function closeAccentPop(){
    POP.classList.remove('open');
    _lpOpen = false; _lpKey = null; _lpBtn = null; _lpPid = null;
    if(_lpTimer){ clearTimeout(_lpTimer); _lpTimer = null; }
  }

  function renderEmojiPicker(){
    KB.querySelectorAll('.ckb-emoji-picker').forEach(existing => existing.remove());
    const picker = document.createElement('div');
    picker.className = 'ckb-emoji-picker';
    const tabs = document.createElement('div');
    tabs.className = 'ckb-emoji-tabs';
    tabs.setAttribute('role', 'tablist');
    tabs.setAttribute('aria-label', 'Categorias de emojis');

    EMOJI_CATEGORIES.forEach(category => {
      const tab = document.createElement('button');
      tab.type = 'button';
      tab.className = 'ckb-emoji-tab' + (emojiCategory === category.id ? ' is-active' : '');
      tab.textContent = category.icon;
      tab.title = category.label;
      tab.setAttribute('role', 'tab');
      tab.setAttribute('aria-label', category.label);
      tab.setAttribute('aria-selected', emojiCategory === category.id ? 'true' : 'false');
      tab.addEventListener('pointerdown', event => event.preventDefault());
      tab.addEventListener('mousedown', event => event.preventDefault());
      tab.addEventListener('click', event => {
        event.preventDefault();
        emojiCategory = category.id;
        renderEmojiPicker();
      });
      tabs.appendChild(tab);
    });
    picker.appendChild(tabs);

    const grid = document.createElement('div');
    grid.className = 'ckb-emoji-grid';
    grid.setAttribute('role', 'tabpanel');
    const activeCategory = EMOJI_CATEGORIES.find(category => category.id === emojiCategory) || EMOJI_CATEGORIES[1];
    const emojis = activeCategory.id === 'recent'
      ? recentEmojis
      : Array.from(new Set(activeCategory.items.split(/\s+/).filter(Boolean)));
    if(!emojis.length){
      const empty = document.createElement('div');
      empty.className = 'ckb-emoji-empty';
      empty.textContent = 'Os emojis usados recentemente aparecem aqui.';
      grid.appendChild(empty);
    } else {
      emojis.forEach(emoji => {
        const key = document.createElement('button');
        key.type = 'button';
        key.className = 'ckb-emoji-key';
        key.textContent = emoji;
        key.setAttribute('aria-label', emoji);
        key.addEventListener('pointerdown', event => event.preventDefault());
        key.addEventListener('mousedown', event => event.preventDefault());
        key.addEventListener('click', event => {
          event.preventDefault();
          recentEmojis = [emoji, ...recentEmojis.filter(item => item !== emoji)].slice(0, 36);
          insertText(emoji);
          renderSbar();
          if(emojiCategory === 'recent') renderEmojiPicker();
        });
        grid.appendChild(key);
      });
    }
    picker.appendChild(grid);

    const footer = document.createElement('div');
    footer.className = 'ckb-emoji-footer';
    [
      {key:'ABC', label:'ABC', aria:'Voltar ao teclado de letras'},
      {key:'123', label:'123', aria:'Abrir números e símbolos'},
      {key:'SPACE', label:'', aria:'Espaço'},
      {key:'BACK', label:'⌫', aria:'Apagar'},
      {key:'ENTER', label:'⏎', aria:'Enter'}
    ].forEach(item => {
      const key = document.createElement('button');
      key.type = 'button';
      key.className = 'ckb-key k-func' + (item.key === 'SPACE' ? ' k-space ckb-emoji-space' : '') + (item.key === 'ENTER' ? ' k-enter' : '');
      key.textContent = item.label;
      key.setAttribute('aria-label', item.aria);
      key.addEventListener('pointerdown', event => event.preventDefault());
      key.addEventListener('mousedown', event => event.preventDefault());
      key.addEventListener('click', event => {
        event.preventDefault();
        if(item.key === 'ABC'){
          mode = modeBeforeEmoji;
          capsLock = capsLockBeforeEmoji;
          render();
          renderSbar();
          return;
        }
        handle(item.key);
      });
      footer.appendChild(key);
    });
    picker.appendChild(footer);
    KB.appendChild(picker);
  }

  /* ── RENDER DAS TECLAS ───────────────────────────────────────────────── */
  function render(){
    // Remove tudo excepto a barra de sugestões e o popup de acentos
    [...KB.children].forEach(c=>{ if(c!==SBAR && c!==POP) c.remove(); });

    // Marca o modo numérico apenas para permitir o estilo visual do teclado
    // numérico (CSS). Não altera a ordem/posição das teclas.
    const _isNum = NUMERIC_MODES.has(mode);
    KB.classList.toggle('ckb-numeric', _isNum);
    document.body.classList.toggle('ckb-numeric', _isNum);
    KB.classList.toggle('ckb-emoji-mode', mode === 'emoji');
    if(mode === 'emoji'){
      renderEmojiPicker();
      return;
    }

    const activeRows = (['ja','ko','zh'].includes(language) && !NUMERIC_MODES.has(mode) && mode !== 'sym' && mode !== 'more' && mode !== 'emoji')
      ? [...SCRIPT_LAYOUTS[language], ['123','SPACE','LANG','ENTER']]
      : layouts[mode];
    activeRows.forEach(row=>{
      const r=document.createElement('div');
      r.className='ckb-row';
      row.forEach(k=>{
        const b=document.createElement('button');
        b.type='button'; b.className='ckb-key'; b.dataset.key=k;
        const hasAcc = !!ACCENT_MAP[k] && !NUMERIC_MODES.has(mode);

        switch(k){
          case 'SPACE': b.classList.add('k-space');b.setAttribute('aria-label','Espaço');break;
          case 'BACK':  b.classList.add('k-func');b.innerHTML='⌫';b.style.fontSize='17px';b.setAttribute('aria-label','Apagar');break;
          case 'ENTER': b.classList.add('k-func','k-enter');b.innerHTML='⏎';b.setAttribute('aria-label','Enter');break;
          case 'SHIFT':
            b.classList.add('k-func');
            if(capsLock){b.innerHTML='⬆';b.classList.add('caps-lock');}
            else{b.innerHTML='⇧';b.style.fontSize='17px';if(mode==='upper')b.classList.add('active');}
            break;
          case '123':b.classList.add('k-func');b.textContent='123';break;
          case 'ABC': b.classList.add('k-func');b.textContent='ABC';break;
          case 'LANG': b.classList.add('k-func','k-lang'); b.textContent=LANG_LABELS[language]; b.setAttribute('aria-label','Idioma do teclado: '+language); break;
          case '#+=':b.classList.add('k-func');b.textContent='#+=';break;
          default:
            b.textContent=k;
            if(hasAcc) b.classList.add('has-accent');
            // Bolha de pré-visualização (estilo teclado nativo Android): letra
            // ampliada por cima do dedo enquanto a tecla está premida.
            {
              const prev=document.createElement('span');
              prev.className='ckb-key-preview'; prev.textContent=k;
              prev.setAttribute('aria-hidden','true');
              b.appendChild(prev);
              b.__preview=prev;
            }
        }

        b.addEventListener('pointerdown', e=>{
          e.preventDefault();
          try{ navigator.vibrate && navigator.vibrate(6); }catch(_){}
          // Fechar popup se aberto e tocar noutra tecla
          if(_lpOpen){ closeAccentPop(); return; }
          if(b.__preview) b.__preview.classList.add('is-visible');
          if(hasAcc){
            _lpKey=b.dataset.key; _lpBtn=b; _lpPid=e.pointerId;
            _lpDX=e.clientX; _lpDY=e.clientY;
            _lpConsumed=false;
            _lpTimer=setTimeout(()=>{
              _lpTimer=null;
              _lpConsumed=true;
              openAccentPop(b.dataset.key,b);
            },450);
          }
          if(k==='SPACE'){
            _spPid=e.pointerId;
            _spStartX=e.clientX;
            _spStartCaret=target ? (target.selectionStart ?? (target.value||'').length) : 0;
            _spLastCaret=_spStartCaret;
            _spDragging=false; _spConsumed=false;
            try{ b.setPointerCapture(e.pointerId); }catch(_){}
          }
          if(k==='BACK'){
            _bkPid=e.pointerId; _bkConsumed=false; _bkRepeating=false;
            try{ b.setPointerCapture(e.pointerId); }catch(_){}
            _bkTimer=setTimeout(_bkStartRepeat, BACK_REPEAT_DELAY);
            // Apaga logo ao tocar (antes esperava pelo "click", depois de levantar
            // o dedo) e marca como consumido para o click não apagar outra vez.
            _bkConsumed=true;
            handle('BACK');
          }
        });
        b.addEventListener('mousedown',e=>e.preventDefault());

        if(hasAcc){
          b.addEventListener('pointermove',e=>{
            if(e.pointerId!==_lpPid)return;
            if(_lpTimer&&Math.hypot(e.clientX-_lpDX,e.clientY-_lpDY)>8){
              clearTimeout(_lpTimer);_lpTimer=null;
            }
          });
          b.addEventListener('pointerup',e=>{
            if(e.pointerId!==_lpPid)return;
            if(_lpTimer){clearTimeout(_lpTimer);_lpTimer=null;}
            _lpPid=null;
            // Popup aberto: fica à espera de tap no popup
          });
          b.addEventListener('pointercancel',()=>{
            if(_lpTimer){clearTimeout(_lpTimer);_lpTimer=null;}
            _lpPid=null;
          });
        }

        if(k==='SPACE'){
          b.classList.add('k-space-nav');
          b.addEventListener('pointermove',e=>{
            if(e.pointerId!==_spPid || !target) return;
            const dx=e.clientX-_spStartX;
            if(!_spDragging && Math.abs(dx)>SP_DRAG_THRESHOLD){
              _spDragging=true; _spConsumed=true;
              b.classList.add('is-cursor-drag');
            }
            if(_spDragging){
              // Calcula sempre a posição a partir do ponto inicial. Isso evita
              // acumular erro quando o sistema agrupa eventos de pointermove e
              // mantém o cursor suave mesmo quando o dedo desliza rapidamente.
              const delta = Math.trunc(dx / SP_STEP_PX);
              const valueLength = target.value ? target.value.length : 0;
              const next = Math.max(0, Math.min(valueLength, _spStartCaret + delta));
              if(next !== _spLastCaret){
                moveCaretTo(next);
                _spLastCaret=next;
              }
            }
          });
          b.addEventListener('pointerup',e=>{
            if(e.pointerId!==_spPid)return;
            _spPid=null; _spDragging=false; _spLastCaret=-1;
            b.classList.remove('is-cursor-drag');
            try{ b.releasePointerCapture(e.pointerId); }catch(_){}
          });
          b.addEventListener('pointercancel',()=>{
            _spPid=null; _spDragging=false; _spLastCaret=-1;
            b.classList.remove('is-cursor-drag');
          });
        }

        if(k==='BACK'){
          b.addEventListener('pointerup',e=>{
            if(e.pointerId!==_bkPid)return;
            _bkStopRepeat();
            try{ b.releasePointerCapture(e.pointerId); }catch(_){}
          });
          b.addEventListener('pointercancel',()=>{ _bkStopRepeat(); });
        }

        // Esconde a bolha de pré-visualização assim que o dedo levanta ou
        // sai da tecla — independentemente de a tecla ter acentos ou não.
        if(b.__preview){
          const hidePrev=()=>{ b.__preview.classList.remove('is-visible'); };
          b.addEventListener('pointerup', hidePrev);
          b.addEventListener('pointercancel', hidePrev);
        }

        b.addEventListener('click',e=>{
          e.preventDefault();
          if(b.__preview) b.__preview.classList.remove('is-visible');
          if(_lpConsumed){_lpConsumed=false;return;}
          if(_spConsumed){_spConsumed=false;return;}
          if(_bkConsumed){_bkConsumed=false;return;}
          if(_lpOpen)return; // esperar tap no popup
          handle(b.dataset.key);
        });

        r.appendChild(b);
      });
      KB.appendChild(r);
    });
  }

  /* ── ROLAGEM AUTOMÁTICA ATÉ AO CURSOR ────────────────────────────────────
     Ao escrever/apagar/mover o cursor programaticamente (o nosso teclado
     escreve directamente em el.value), o campo nem sempre acompanha o
     cursor sozinho — o texto pode ficar escondido fora da vista. Esta
     função garante que o cursor fica sempre visível, tanto em <input>
     de uma linha (rolagem horizontal) como em <textarea> (rolagem vertical
     usando um "espelho" invisível para calcular a posição do cursor). */
  let _ckbMirror = null, _ckbMirrorBlock = null;
  function _scrollCaretIntoViewNow(el){
    if(!el) return;
    try{
      const val = el.value || '';
      const pos = el.selectionStart ?? val.length;
      const cs = getComputedStyle(el);
      if(el.tagName === 'TEXTAREA'){
        if(!_ckbMirrorBlock){
          _ckbMirrorBlock = document.createElement('div');
          _ckbMirrorBlock.style.position='absolute';
          _ckbMirrorBlock.style.visibility='hidden';
          _ckbMirrorBlock.style.top='-9999px';
          _ckbMirrorBlock.style.left='-9999px';
          _ckbMirrorBlock.style.whiteSpace='pre-wrap';
          _ckbMirrorBlock.style.wordWrap='break-word';
          _ckbMirrorBlock.style.overflowWrap='break-word';
          document.body.appendChild(_ckbMirrorBlock);
        }
        const m=_ckbMirrorBlock;
        m.style.font=cs.font; m.style.letterSpacing=cs.letterSpacing;
        m.style.width=el.clientWidth+'px'; m.style.boxSizing=cs.boxSizing;
        m.style.paddingLeft=cs.paddingLeft; m.style.paddingRight=cs.paddingRight;
        m.style.paddingTop=cs.paddingTop; m.style.paddingBottom=cs.paddingBottom;
        m.style.lineHeight=cs.lineHeight;
        m.innerHTML='';
        m.appendChild(document.createTextNode(val.slice(0,pos)));
        const marker=document.createElement('span'); marker.textContent='\u200b';
        m.appendChild(marker);
        const markerTop=marker.offsetTop;
        const markerH=marker.offsetHeight || parseFloat(cs.lineHeight) || 16;
        const padTop=parseFloat(cs.paddingTop)||0, padBottom=parseFloat(cs.paddingBottom)||0;
        const visibleH=el.clientHeight - padTop - padBottom;
        if(markerTop - el.scrollTop + markerH > visibleH){
          el.scrollTop = markerTop + markerH - visibleH;
        } else if(markerTop < el.scrollTop){
          el.scrollTop = Math.max(0, markerTop);
        }
      } else {
        if(!_ckbMirror){
          _ckbMirror=document.createElement('span');
          _ckbMirror.style.position='absolute';
          _ckbMirror.style.visibility='hidden';
          _ckbMirror.style.whiteSpace='pre';
          _ckbMirror.style.top='-9999px';
          _ckbMirror.style.left='-9999px';
          document.body.appendChild(_ckbMirror);
        }
        _ckbMirror.style.font=cs.font; _ckbMirror.style.letterSpacing=cs.letterSpacing;
        _ckbMirror.textContent=val.slice(0,pos);
        const caretX=_ckbMirror.offsetWidth;
        const padLeft=parseFloat(cs.paddingLeft)||0, padRight=parseFloat(cs.paddingRight)||0;
        const visibleW=el.clientWidth - padLeft - padRight;
        if(caretX - el.scrollLeft > visibleW){
          el.scrollLeft = caretX - visibleW + 4;
        } else if(caretX < el.scrollLeft){
          el.scrollLeft = Math.max(0, caretX - 4);
        }
      }
    }catch(_){}
  }

  // Agrupa leituras/escritas do layout numa única animação. Sem este
  // agendamento, cada tecla media fonte, largura e scroll individualmente,
  // provocando atraso visível em telefones mais lentos.
  let _caretRaf = 0, _caretPending = null;
  function scrollCaretIntoView(el){
    _caretPending = el;
    if(_caretRaf) return;
    const raf = window.requestAnimationFrame || (fn => setTimeout(fn, 0));
    _caretRaf = raf(() => {
      _caretRaf = 0;
      const pending = _caretPending;
      _caretPending = null;
      _scrollCaretIntoViewNow(pending);
    });
  }

  // Move o cursor `delta` caracteres (negativo = esquerda, positivo = direita),
  // usado pelo arrasto na barra de espaço.
  function moveCaretTo(position){
    const el=target; if(!el) return;
    const v=el.value||'';
    const p=Math.max(0, Math.min(v.length, position));
    try{
      // O foco já costuma estar no campo; não o solicita novamente a cada
      // movimento, evitando trabalho e eventos redundantes em telemóveis.
      if(document.activeElement !== el) el.focus({preventScroll:true});
      el.setSelectionRange(p,p);
      el.classList.add('ckb-caret-active');
    }catch(_){}
    rememberCaret(el);
    scrollCaretIntoView(el);
  }
  function moveCaret(delta){
    const el=target; if(!el) return;
    const v=el.value||'';
    moveCaretTo((el.selectionStart ?? v.length) + delta);
  }

  /* ── INSERÇÃO / BACKSPACE ────────────────────────────────────────────── */
  function insertText(txt){
    const el=target;if(!el)return;
    _lastAuto=null;
    let expected=null, pos=null;
    if(el.type==='number'){el.value=el.value+txt;}
    else{
      const s=el.selectionStart??el.value.length,e2=el.selectionEnd??el.value.length;
      el.value=el.value.slice(0,s)+txt+el.value.slice(e2);
      const p=s+txt.length;try{el.setSelectionRange(p,p);}catch(_){}
      expected=el.value; pos=p;
    }
    rememberCaret(el);
    el.dispatchEvent(new Event('input',{bubbles:true}));
    // Se algum handler da app mexeu no cursor sem alterar o texto, repõe-no.
    if(pos!==null) restoreCaretIfMoved(el,expected,pos);
    scrollCaretIntoView(el);
    syncShift();
  }

  function backspace(){
    const el=target;if(!el)return;
    // Apagar logo a seguir a uma autocorreção desfaz-a (volta à palavra escrita).
    if(_lastAuto && _lastAuto.el===el && el.selectionStart===el.selectionEnd && el.selectionStart===_lastAuto.caret
       && el.value.slice(_lastAuto.start,_lastAuto.start+_lastAuto.fixed.length+1)===_lastAuto.fixed+' '){
      const a=_lastAuto; _lastAuto=null;
      const v=el.value;
      el.value=v.slice(0,a.start)+a.orig+v.slice(a.start+a.fixed.length+1);
      const np=a.start+a.orig.length; try{el.setSelectionRange(np,np);}catch(_){}
      _skipAuto={el,start:a.start,orig:a.orig};
      rememberCaret(el);
      el.dispatchEvent(new Event('input',{bubbles:true}));
      restoreCaretIfMoved(el,el.value,np);
      scrollCaretIntoView(el); syncShift();
      return;
    }
    _lastAuto=null;
    if(el.type==='number'){el.value=String(el.value).slice(0,-1);}
    else{
      const s=el.selectionStart??el.value.length,e2=el.selectionEnd??el.value.length;
      if(s!==e2){
        el.value=el.value.slice(0,s)+el.value.slice(e2);try{el.setSelectionRange(s,s);}catch(_){}
      }else if(s>0){
        const seg=[...el.value.slice(0,s)];seg.pop();
        const nb=seg.join('');el.value=nb+el.value.slice(s);
        try{el.setSelectionRange(nb.length,nb.length);}catch(_){}
      }
    }
    rememberCaret(el);
    const _bsExpected=el.value, _bsPos=el.selectionStart;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    if(typeof _bsPos==='number') restoreCaretIfMoved(el,_bsExpected,_bsPos);
    // Campo vazio: sai dos símbolos e prepara a maiúscula conforme o tipo de campo.
    if(!NUMERIC_MODES.has(mode)){
      if(!String(el.value || '').length && (mode==='sym'||mode==='more')){ capsLock = false; mode = 'lower'; render(); }
      syncShift();
    }
    scrollCaretIntoView(el);
  }

  // ── Repetição contínua do BACKSPACE ao segurar ──────────────────────────
  function _bkStep(){
    if(!target){ _bkStopRepeat(); return; }
    backspace(); renderSbar();
    _bkCount++;
    const delay = Math.max(BACK_REPEAT_MIN_MS, BACK_REPEAT_START_MS - _bkCount*7);
    _bkTimer = setTimeout(_bkStep, delay);
  }
  function _bkStartRepeat(){
    _bkTimer = null; _bkRepeating = true; _bkConsumed = true; _bkCount = 0;
    _bkStep();
  }
  function _bkStopRepeat(){
    if(_bkTimer){ clearTimeout(_bkTimer); _bkTimer = null; }
    _bkPid = null; _bkRepeating = false;
  }

  /* ── LÓGICA DAS TECLAS ───────────────────────────────────────────────── */
  function handle(k){
    if(!target)return;
    switch(k){
      case 'SPACE':{
        const now=Date.now();
        const textMode=!NUMERIC_MODES.has(mode)&&mode!=='sym'&&mode!=='more'&&mode!=='emoji';
        if(textMode){
          const v=target.value||'',p=target.selectionStart??v.length;
          // Duplo espaço -> ". " só em textos corridos (comentários), como no Android.
          if(capPolicy(target)==='sentences'&&now-lastSpace<400&&p>=2&&v[p-1]===' '&&!/[\s.!?,;:]/.test(v[p-2])){
            target.value=v.slice(0,p-1)+'. ';const np=p+1;
            try{target.setSelectionRange(np,np);}catch(_){}
            _lastAuto=null; rememberCaret(target);
            target.dispatchEvent(new Event('input',{bubbles:true}));
            restoreCaretIfMoved(target,target.value,np);
            scrollCaretIntoView(target);
            lastSpace=0;syncShift();renderSbar();break;
          }
        }
        // (já não se "aprende" cada palavra ao espaço: gravava erros de digitação
        //  no dicionário e depois sugeria-os. Aprende-se só ao aceitar uma sugestão.)
        const fixed = textMode ? tryAutoCorrect() : null;
        lastSpace=now; insertText(' ');
        if(fixed) _lastAuto={el:fixed.el,start:fixed.start,orig:fixed.orig,fixed:fixed.fixed,caret:target.selectionStart};
        renderSbar();break;
      }
      case 'BACK': backspace();renderSbar();break;
      case 'ENTER':
        if(target.tagName==='TEXTAREA'){insertText('\n');break;}
        if(target.id==='f_generos'){
          const v=target.value||'';if(v&&!/,\s*$/.test(v))insertText(', ');break;
        }{
          const form=target.closest('form');
          // Antes o ENTER submetia o formulário inteiro a partir de QUALQUER
          // campo, o que podia enviar um cadastro incompleto sem querer.
          // Agora, se houver um próximo campo de texto visível no mesmo
          // formulário, o ENTER só move o foco pra ele (como "próximo" no
          // teclado nativo); só submete quando já está no último campo.
          if(form){
            const focusables = [...form.querySelectorAll('input,textarea')]
              .filter(el => isEditable(el) && el.offsetParent !== null);
            const idx = focusables.indexOf(target);
            const next = idx >= 0 ? focusables[idx+1] : null;
            if(next){
              next.focus();
              try{ const L=(next.value||'').length; next.setSelectionRange(L,L); }catch(_){}
              break;
            }
          }
          target.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));
          if(form&&form.requestSubmit){try{form.requestSubmit();}catch(_){}}
          hide();
        }break;
      case 'SHIFT':{
        if(NUMERIC_MODES.has(mode))break;
        const now=Date.now();
        if(now-lastShift<350){capsLock=!capsLock;mode=capsLock?'upper':'lower';}
        else{capsLock=false;mode=(mode==='upper')?'lower':'upper';}
        lastShift=now;render();break;
      }
      case '123':if(NUMERIC_MODES.has(mode))break;mode='sym';render();break;
      case 'LANG':
        if(NUMERIC_MODES.has(mode)) break;
        language = LANGS[(LANGS.indexOf(language) + 1) % LANGS.length];
        mode = (['ja','ko','zh'].includes(language)) ? 'lower' : 'upper';
        capsLock = false; render(); renderSbar(); break;
      case 'ABC': if(NUMERIC_MODES.has(mode))break;mode='lower';capsLock=false;render();break;
      case '#+=':if(NUMERIC_MODES.has(mode))break;mode='more';render();break;
      default:
        if(mode==='num'&&k==='.')break;
        {
          // Mantém 123/#+= aberto após inserir uma tecla; a saída é explícita
          // pelo botão ABC, para evitar que o teclado volte às letras sozinho.
          insertText(k);
          renderSbar();
        }
    }
  }

  /* ── MOSTRAR / ESCONDER ──────────────────────────────────────────────── */
  const EDITABLE=new Set(['text','search','url','email','tel','password','number','']);
  function isEditable(el){
    // Campos marcados com data-ckb-readonly-ok são readonly DE PROPÓSITO
    // (ver forceNoNativeKeyboard) só para bloquear o teclado/autofill nativo
    // do sistema — o teclado personalizado continua podendo escrever neles
    // via JS, então não entram na exclusão normal de campos readonly.
    if(!el||el.disabled)return false;
    if(el.readOnly && el.dataset && el.dataset.ckbReadonlyOk === '1'){ /* permitido */ }
    else if(el.readOnly) return false;
    if(el.tagName==='TEXTAREA')return true;
    if(el.tagName!=='INPUT')return false;
    return EDITABLE.has((el.type||'text').toLowerCase());
  }

  // Elementos que não fecham o teclado quando tocados
  const KEEP=[
    '[data-ckb-keep]','#generosSuggestBox','.genre-suggest-item','.genre-suggest-empty',
    '.obra-search-results','.obra-search-item',
    '#customKb','#ckbAccentPop','.ckb-pop-item','.ckb-pop-base',
    '.ckb-sbar','.ckb-sbar-item',
    '.input-clear-btn','.clearable-field-wrap','.search-clear-btn',
    '.pwd-toggle','[data-toggle-pwd]',
    '.scroll-nav','.scroll-nav-snap','.scroll-nav-thumb','.scroll-nav-track','.scroll-nav-top','.scroll-nav-toggle',
  ].join(',');

  function show(el){
    target=el; el.setAttribute('inputmode','none');
    el.classList.add('ckb-caret-active');
    const w=pickModeFor(el);
    if(NUMERIC_MODES.has(w)){
      mode=w;
    } else {
      // Sai do modo numérico/símbolos herdado de um campo anterior e aplica a
      // regra de maiúsculas do tipo de campo (início de texto, palavras, etc.).
      if(NUMERIC_MODES.has(mode)||mode==='sym'||mode==='more'||mode==='emoji') mode='lower';
      mode = capsLock ? 'upper' : (autoCapNeeded() ? 'upper' : 'lower');
    }
    _lastAuto=null;
    // Foco por código (não por toque): cursor no fim do texto, nunca antes da 1ª letra.
    try{
      if(Date.now()-_lastTouchInField>900 && el.value && el.selectionStart===0 && el.selectionEnd===0){
        el.setSelectionRange(el.value.length,el.value.length);
      }
    }catch(_){}
    rememberCaret(el);
    _startHealth();
    closeAccentPop();
    SBAR.innerHTML='';
    render();
    KB.classList.add('open');
    document.body.classList.add('ckb-open');
    if(el.id==='f_generos'&&typeof openGenreSuggestBox==='function'){try{openGenreSuggestBox();}catch(_){}}
    else if(typeof _syncGenreSuggestStripMode==='function'){try{_syncGenreSuggestStripMode();}catch(_){}}
    renderSbar();
    if(navigator.clipboard&&navigator.clipboard.readText){
      navigator.clipboard.readText().then(t=>{
        if(t&&t.trim()&&t.trim()!==clipText.trim()){clipText=t;if(target===el)renderSbar();}
      }).catch(()=>{});
    }
    setTimeout(()=>{
      try{
        if(el.closest('#lockOverlay')) keepLockFieldVisible(el);
          else el.scrollIntoView({block:'center',behavior:'auto'});
      }catch(_){ }
      scrollCaretIntoView(el);
      syncShift();
    },60);
  }

  // Segurança: se o campo desaparecer (troca de página/modal) sem aviso de
  // "blur", o teclado fecha em vez de ficar preso a um campo que já não existe.
  let _healthTimer=null;
  function _startHealth(){
    if(_healthTimer) return;
    _healthTimer=setInterval(()=>{
      if(!target){ _stopHealth(); return; }
      if(!target.isConnected || (document.activeElement!==target && !isEditable(document.activeElement))) hide();
    },350);
  }
  function _stopHealth(){ if(_healthTimer){ clearInterval(_healthTimer); _healthTimer=null; } }

  function hide(){
    _stopHealth(); _lastAuto=null; _caretMem=null;
    if(target){
      try{target.setAttribute('inputmode','none');}catch(_){}
      try{target.classList.remove('ckb-caret-active');}catch(_){}
    }
    target=null; _lpConsumed=false;
    if(_lpTimer){clearTimeout(_lpTimer);_lpTimer=null;}
    closeAccentPop();
    KB.classList.remove('open');
    document.body.classList.remove('ckb-open');
    document.body.classList.remove('ckb-suggest');
    const box=document.getElementById('generosSuggestBox');
    if(box)box.classList.remove('is-ckb-strip');
  }

  window.__ckb={hide,show,isOpen:()=>KB.classList.contains('open')};

  // Rede de segurança contra o teclado do sistema: se, com um campo focado,
  // a área visível encolher bastante (sinal de teclado nativo aberto), o campo
  // perde e recupera o foco já com inputmode="none". Máx. 3 tentativas por campo.
  (function nativeKeyboardGuard(){
    const vv=window.visualViewport; if(!vv) return;
    let base=vv.height, lastW=window.innerWidth, lastFix=0, fixes=0, lastEl=null;
    vv.addEventListener('resize',()=>{
      if(window.innerWidth!==lastW){ lastW=window.innerWidth; base=vv.height; return; }
      if(vv.height>base) base=vv.height;
      const el=document.activeElement;
      if(!el||!isEditable(el)||base-vv.height<=180) return;
      if(lastEl!==el){ lastEl=el; fixes=0; }
      const now=Date.now();
      if(now-lastFix<700||fixes>=3) return;
      lastFix=now; fixes++;
      let s=null,e=null; try{ s=el.selectionStart; e=el.selectionEnd; }catch(_){}
      try{ el.setAttribute('inputmode','none'); el.setAttribute('autocomplete','off'); el.blur(); }catch(_){}
      setTimeout(()=>{ try{ el.focus({preventScroll:true}); if(typeof s==='number') el.setSelectionRange(s,e); }catch(_){} },60);
    });
  })();

  // Fechar popup ao tocar fora dele
  document.addEventListener('pointerdown',e=>{
    if(!_lpOpen)return;
    if(POP.contains(e.target))return;
    closeAccentPop();
  },true);

  document.addEventListener('focusin',e=>{const el=e.target;if(isEditable(el))show(el);});
  document.addEventListener('focusout',()=>{setTimeout(()=>{if(!isEditable(document.activeElement))hide();},0);});

  // Aprende palavras de texto colado (copiado de outro lugar), tal como o teclado nativo faz.
  document.addEventListener('paste',e=>{
    const el=e.target;if(!isEditable(el))return;
    try{
      const txt=(e.clipboardData||window.clipboardData).getData('text');
      if(txt) setTimeout(()=>{learnWordsFromText(txt);if(target===el)renderSbar();},0);
    }catch(_){}
  });

  // Guarda o texto copiado dentro da própria app como sugestão de colar.
  document.addEventListener('copy',()=>{
    try{
      const sel=window.getSelection?window.getSelection().toString():'';
      if(sel&&sel.trim()){clipText=sel;if(target)renderSbar();}
    }catch(_){}
  });

  // Fechar teclado ao tocar fora
  let _dx=0,_dy=0,_dt=null,_dm=false,_ckbSyntheticClick=false;
  document.addEventListener('pointerdown',e=>{_dx=e.clientX;_dy=e.clientY;_dt=e.target;_dm=false;},true);
  document.addEventListener('pointermove',e=>{if(!_dt)return;if(Math.abs(e.clientX-_dx)>10||Math.abs(e.clientY-_dy)>10)_dm=true;},true);
  document.addEventListener('pointerup',e=>{
    const downTarget=_dt;
    const wasTap=downTarget&&!_dm;_dt=null;if(!wasTap)return;
    if(KB.contains(e.target))return;
    if(POP.contains(e.target))return;
    // Ao tocar num botão enquanto o teclado está aberto, o focusout pode
    // fechar/refluir o teclado antes do pointerup. Nesse caso, e.target já
    // pode ser outro elemento que ficou sob o dedo; o alvo guardado no
    // pointerdown continua a representar a intenção real do toque.
    const gestureTarget = downTarget || e.target;
    if(gestureTarget.closest&&gestureTarget.closest(KEEP))return;
    if(e.target.closest&&e.target.closest(KEEP))return;
    const el=(gestureTarget.closest&&gestureTarget.closest('input,textarea')) || (e.target.closest&&e.target.closest('input,textarea'));
    if(isEditable(el))return;
    if(target){
      // Fechar o teclado liberta o espaço que ele ocupava e a página faz
      // reflow logo a seguir. O "click" fantasma que o navegador dispara
      // depois do pointerup usa as mesmas coordenadas do toque, mas contra
      // o layout já realocado — e acaba caindo em quem ficou por baixo do
      // dedo (tipicamente o campo de data, por vir logo abaixo dos
      // comentários). Bloqueamos esse click fantasma explicitamente.
      //
      // MAS: se o toque foi em cima de um controle acionável de verdade
      // (botão, link, etc.), a pessoa QUERIA acionar aquilo — não só
      // fechar o teclado. Por isso capturamos aqui, ANTES do reflow, qual
      // controle estava mesmo sob o dedo, e disparamos ELE diretamente.
      //
      // IMPORTANTE: usamos uma "flag" (_ckbSyntheticClick) para o bloqueio
      // do clique fantasma saber diferenciar o NOSSO clique sintético (que
      // deve passar normalmente) do clique fantasma de verdade do navegador
      // (que continua bloqueado). Sem essa flag, o próprio addEventListener
      // com {once:true} se auto-consumia no NOSSO clique sintético — e o
      // clique nunca chegava a acionar o botão (foi isso que quebrou o
      // olho de mostrar senha e o handler que ele dispara).
      const actionable = (gestureTarget.closest && gestureTarget.closest(
        'button, a[href], [role="button"], input[type="date"], input[type="submit"], input[type="button"], input[type="checkbox"], input[type="radio"], select, label, .btn, .chip-toggle, [data-account-id], [data-toggle-pwd]'
      )) || (e.target.closest && e.target.closest(
        'button, a[href], [role="button"], input[type="date"], input[type="submit"], input[type="button"], input[type="checkbox"], input[type="radio"], select, label, .btn, .chip-toggle, [data-account-id], [data-toggle-pwd]'
      ));
      try{ e.preventDefault(); }catch(_){ }
      const swallowGhostClick = (ev) => {
        if(_ckbSyntheticClick) return; // deixa passar o nosso próprio clique sintético
        try{ ev.preventDefault(); ev.stopImmediatePropagation(); }catch(_){ }
      };
      document.addEventListener('click', swallowGhostClick, {capture:true});
      setTimeout(() => document.removeEventListener('click', swallowGhostClick, true), 400);
      hide();
      if(actionable && !actionable.disabled){
        _ckbSyntheticClick = true;
        try{ actionable.click(); }
        finally{ _ckbSyntheticClick = false; }
      }
    }
  },true);
  document.addEventListener('pointercancel',()=>{_dt=null;_dm=false;},true);

  render();
})();

/* ============================================================
   Botão "Back" do Android (Capacitor)
   ------------------------------------------------------------
   BUGFIX: este bloco tinha SEU PRÓPRIO listener de 'popstate' e sua própria
   função de fechar camadas (tryCloseOverlays), totalmente independente do
   bloco "NAV / BACK BUTTON HANDLING" acima. Um único toque físico no botão
   Voltar disparava os DOIS handlers de 'popstate' para o MESMO evento,
   fechando duas camadas de uma vez (ex.: teclado + formulário, ou
   sugestões de gênero + navegação para "Detalhes da Obra"). Também havia um
   listener legado 'backbutton' (Cordova, minúsculo) sem uso real neste app
   (que é Capacitor), somando mais uma fonte de duplicidade.
   AGORA: não há mais listener de 'popstate' aqui. O único listener de
   'popstate' do app vive no bloco acima (window.__handleBackIntent). Este
   bloco cuida apenas da ponte com o plugin nativo App do Capacitor:
     - Se o WebView pode voltar no histórico, delega para window.history.back(),
       que dispara o 'popstate' único e deixa TODA a decisão a cargo dele.
     - Se já estamos na raiz do histórico (nada para voltar), ainda assim
       tentamos fechar teclado/sugestões/modal pendente antes de sair do app.
   ============================================================ */
(function initBackButton(){
  if (window.__backInit) return; window.__backInit = true;

  function bindCapacitor(){
    const Cap = window.Capacitor;
    const App = Cap && Cap.Plugins && Cap.Plugins.App;
    if (!App || typeof App.addListener !== 'function') return false;
    App.addListener('backButton', ({ canGoBack } = {}) => {
      if (canGoBack) { window.history.back(); return; }
      if (window.__handleBackIntent && window.__handleBackIntent()) return;
      try { App.exitApp && App.exitApp(); } catch(_){}
    });
    return true;
  }

  if (!bindCapacitor()){
    document.addEventListener('deviceready', bindCapacitor, { once: true });
    // BUGFIX: uma única tentativa 800ms depois não chegava a tempo em
    // arranques a frio (cold start) — a ponte nativa window.Capacitor pode
    // demorar mais do que isso a ficar pronta, sobretudo em dispositivos
    // mais lentos ou quando o app acabou de abrir. Quando isso acontecia,
    // o listener do botão físico "Voltar" NUNCA chegava a ser registado
    // nessa sessão, e o botão caía no comportamento padrão do Android
    // (sair da app), em vez de ser interceptado pelo handleBackIntent.
    // Agora repetimos a tentativa em intervalos curtos durante uma janela
    // bem mais larga, até a ponte ficar disponível.
    let _backAttempts = 0;
    const _backRetry = setInterval(() => {
      _backAttempts++;
      if (bindCapacitor() || _backAttempts >= 40) clearInterval(_backRetry);
    }, 500); // até ~20s
  }
})();

// ===================== ACESSIBILIDADE: FOCUS TRAP NOS MODAIS =====================
// Bloco 100% aditivo — não altera nenhuma função existente de abrir/fechar
// modal. Observa o atributo "hidden" de cada .modal-backdrop já presente no
// HTML e, quando um modal fica visível, prende o Tab dentro dele e devolve o
// foco ao elemento que o abriu assim que ele fecha. Funciona com qualquer
// forma de abrir/fechar o modal (definir .hidden diretamente, tecla Escape,
// clique no backdrop, etc.), pois todas passam por essa mesma propriedade.
(function(){
  function getFocusable(container){
    if(!container) return [];
    const sel = 'a[href], button:not([disabled]), textarea:not([disabled]), ' +
      'input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
    return Array.from(container.querySelectorAll(sel)).filter(el => {
      return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
    });
  }

  const modalFocusState = new WeakMap();

  function trapFocusKeydown(e, modalEl){
    if(e.key !== 'Tab') return;
    const focusable = getFocusable(modalEl);
    if(!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if(e.shiftKey && document.activeElement === first){
      e.preventDefault(); last.focus();
    } else if(!e.shiftKey && document.activeElement === last){
      e.preventDefault(); first.focus();
    }
  }

  function onModalOpened(backdrop){
    const modalEl = backdrop.querySelector('.modal') || backdrop;
    const previouslyFocused = document.activeElement;
    const keydownHandler = (e) => trapFocusKeydown(e, modalEl);
    modalFocusState.set(backdrop, { previouslyFocused, keydownHandler });
    backdrop.addEventListener('keydown', keydownHandler);
    requestAnimationFrame(() => {
      // Se algo já recebeu foco explicitamente (ex.: um input do form), não interfere.
      if(modalEl.contains(document.activeElement)) return;
      const focusable = getFocusable(modalEl);
      if(focusable.length) focusable[0].focus();
    });
  }

  function onModalClosed(backdrop){
    const st = modalFocusState.get(backdrop);
    if(!st) return;
    backdrop.removeEventListener('keydown', st.keydownHandler);
    modalFocusState.delete(backdrop);
    const el = st.previouslyFocused;
    if(el && typeof el.focus === 'function' && document.contains(el)){
      try{ el.focus(); }catch(_){}
    }
  }

  function watchModal(backdrop){
    if(!backdrop || backdrop.dataset.focusTrapWatched === '1') return;
    backdrop.dataset.focusTrapWatched = '1';
    let wasHidden = backdrop.hidden;
    const observer = new MutationObserver(() => {
      const isHidden = backdrop.hidden;
      if(isHidden === wasHidden) return;
      wasHidden = isHidden;
      if(!isHidden) onModalOpened(backdrop); else onModalClosed(backdrop);
    });
    observer.observe(backdrop, { attributes: true, attributeFilter: ['hidden'] });
  }

  function initModalFocusTrap(){
    document.querySelectorAll('.modal-backdrop').forEach(watchModal);
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', initModalFocusTrap);
  } else {
    initModalFocusTrap();
  }
})();
