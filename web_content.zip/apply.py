from pathlib import Path
import re
root=Path('/mnt/data/mounty_edit')
for rel in ['index.html','server/index.html']:
    p=root/rel
    s=p.read_text(encoding='utf-8')
    # Brand and contact
    reps={
      'متجر أحمد شوب | A7MED SHOP':'MUNTY STORE | متجر مونتي',
      'متجر <span>أحمد شوب</span> | A7MED':'<span>MUNTY</span> STORE',
      'A7MED SHOP':'MUNTY STORE',
      'متجر أحمد شوب':'MUNTY STORE',
      'A7MEDSTORE':'MUNTY STORE',
      'A7MED ACCOUNT ♥️🇸🇩':'MUNTY STORE • ACCOUNTS 🎮🇸🇩',
      'https://wa.me/249901053880':'https://wa.me/249901663428',
      '+249 90 105 3880':'0901663428',
      'A7MED SHOP.':'MUNTY STORE.',
      'A7MED SHOP —':'MUNTY STORE —',
      'A7MED SHOP</':'MUNTY STORE</',
      'alt="A7MED SHOP"':'alt="MUNTY STORE"',
      'src="logo.png"':'src="logo.png"',
    }
    for a,b in reps.items(): s=s.replace(a,b)
    # Replace old bank-only notice with three payment cards
    old='''<div class="notice">\n      <strong>💳 التحويل البنكي</strong><br>\n      بنكك: <b>4187606</b><br>\n      باسم: <b>هند محمد</b><br>\n      <small>بعد التحويل أرسل إشعار العملية للتأكد من الدفع.</small>\n    </div>'''
    new='''<div class="payment-grid">\n      <div class="payment-card mycash"><div class="pay-icon">M</div><div><strong>الدفع عبر ماي كاشي 🇸🇩</strong><div class="pay-number">402924602</div><div>موسى ميكائيل</div></div></div>\n      <div class="payment-card bankak"><div class="pay-icon">⌂</div><div><strong>الدفع عبر بنكك 🇸🇩</strong><div class="pay-number">5367698</div><div>فاطمه الشريف</div><small>مونتي مقابل خدمه الكترونيه 🛍</small></div></div>\n      <div class="payment-card bravo"><div class="pay-icon">B</div><div><strong>الدفع عبر برافو 🇸🇩</strong><div class="pay-number">51390744</div><div>موسى ميكائيل</div></div></div>\n    </div>\n    <div class="notice"><strong>☑️ بعد التحويل:</strong> أرسل الإشعار والمبلغ المتفق عليه للتأكد من الدفع.</div>'''
    s=s.replace(old,new)
    # Any remaining old payment info in the second occurrence
    s=s.replace('<strong>بنكك:</strong> 4187606<br>\n      <strong>باسم:</strong> هند محمد', '<strong>ماي كاشي:</strong> 402924602 — موسى ميكائيل<br><strong>بنكك:</strong> 5367698 — فاطمه الشريف<br><strong>برافو:</strong> 51390744 — موسى ميكائيل')
    # FF order select add 300 if absent
    s=s.replace('<option value="ff-200">200💎 — 17,000 SDG</option><option value="ff-500">', '<option value="ff-200">200💎 — 17,000 SDG</option><option value="ff-300">300💎 — 25,500 SDG</option><option value="ff-500">')
    # Inject premium gold/black design overrides before </head>
    design=r'''<style>
:root{--gold:#f5b700;--gold2:#ffd84a;--bg:#03070b;--panel:#091019;--muted:#aab4c2;--line:rgba(245,183,0,.28)}
body{background:radial-gradient(circle at 50% -10%,#1b1605 0,#03070b 42%,#010305 100%);color:#f7f7f7}
header{position:sticky;top:0;z-index:50;padding:14px 5%;background:rgba(3,7,11,.92);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);box-shadow:0 8px 30px rgba(0,0,0,.35)}
.logo{font-size:26px;letter-spacing:.5px;color:#fff;text-transform:uppercase}.logo span{color:var(--gold)}nav a{color:#eee}nav a:hover{color:var(--gold)}
.hero{position:relative;overflow:hidden;padding:78px 6% 70px;background:radial-gradient(circle at 50% 30%,rgba(245,183,0,.18),transparent 35%),linear-gradient(135deg,#05080c,#0d0d08 50%,#03070b)}
.hero:before,.hero:after{content:"";position:absolute;inset:auto -10% 0;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);box-shadow:0 0 22px var(--gold)}
.hero:before{transform:rotate(-3deg);bottom:16%}.hero:after{transform:rotate(3deg);bottom:11%}
.hero img{width:105px;height:105px;object-fit:cover;border-radius:24px;border:2px solid var(--gold);box-shadow:0 0 35px rgba(245,183,0,.35);filter:saturate(.9)}
.hero h1{font-size:clamp(42px,8vw,78px);font-weight:1000;letter-spacing:2px;margin:18px 0 4px;background:linear-gradient(180deg,#fff 0,#ffd43d 55%,#e49c00 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 10px 30px rgba(245,183,0,.12)}
.hero p{color:#d5d7db}.btn{background:linear-gradient(135deg,#ffd43d,#e49c00);color:#090909;box-shadow:0 8px 24px rgba(245,183,0,.2);border:1px solid #ffe47b}.btn:hover{transform:translateY(-2px)}
section{max-width:1180px}.title,h2{color:#fff}.title:after,h2:after{content:"";display:block;width:54px;height:3px;margin:12px auto 0;background:var(--gold);box-shadow:0 0 14px var(--gold)}
.grid,.cards{gap:18px}.card,.cards .card,.contact,.notice,.charge-folder,.offer-card{background:linear-gradient(145deg,rgba(13,20,28,.96),rgba(5,10,15,.96));border:1px solid rgba(255,255,255,.07);box-shadow:0 14px 35px rgba(0,0,0,.28);transition:.22s}.card:hover,.charge-folder:hover{border-color:rgba(245,183,0,.45);transform:translateY(-4px);box-shadow:0 16px 40px rgba(245,183,0,.08)}.card h3{color:#fff}.card p,.lead{color:#aeb8c5}.charge-folder{color:#fff}.folder-icon{filter:drop-shadow(0 0 10px rgba(245,183,0,.3))}
.payment-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:20px 0}.payment-card{display:flex;align-items:center;gap:14px;text-align:right;padding:20px;border-radius:18px;background:linear-gradient(145deg,#101923,#060a0e);border:1px solid var(--line);box-shadow:0 10px 28px rgba(0,0,0,.3)}.pay-icon{width:48px;height:48px;display:grid;place-items:center;border-radius:14px;background:linear-gradient(145deg,#ffd83f,#bd7d00);color:#111;font-weight:1000;font-size:22px;flex:none}.pay-number{font-size:24px;font-weight:900;color:var(--gold2);margin:7px 0}.payment-card small{display:block;color:#ffd84a;margin-top:5px}.mycash{border-color:rgba(45,220,100,.35)}.bankak{border-color:rgba(255,70,90,.35)}.bravo{border-color:rgba(245,183,0,.4)}
footer{border-top:1px solid rgba(245,183,0,.18);background:#020406;color:#8d97a5}
input,select,textarea{background:#070c12!important;color:#fff!important;border:1px solid #27313e!important}button{background:linear-gradient(135deg,#ffd43d,#e49c00)!important;color:#111!important}
@media(max-width:800px){.payment-grid{grid-template-columns:1fr}.hero{padding:55px 5%}.hero h1{font-size:42px}}
</style>'''
    s=s.replace('</head>',design+'\n</head>')
    p.write_text(s,encoding='utf-8')

# Server branding and AI payment verification
p=root/'server.js'; s=p.read_text(encoding='utf-8')
s=s.replace("service:'A7MED SHOP'","service:'MUNTY STORE'")
s=s.replace('بيانات المتجر المتوقعة: بنكك، رقم الحساب 4187606، الاسم هند محمد.', 'بيانات الدفع المتوقعة للمتجر: ماي كاشي 402924602 باسم موسى ميكائيل؛ بنكك 5367698 باسم فاطمه الشريف؛ برافو 51390744 باسم موسى ميكائيل. اعتبر receiver_matches=true إذا طابق الإشعار إحدى هذه البيانات بوضوح.')
s=s.replace('A7MED AI server running', 'MUNTY AI server running')
p.write_text(s,encoding='utf-8')

# Update visible README labels only
for rel in ['README.md','README_RENDER_AR.md','README_DEPLOY.txt','ابدأ_من_هنا.txt']:
    p=root/rel
    if p.exists():
        s=p.read_text(encoding='utf-8').replace('A7MED SHOP','MUNTY STORE').replace('a7med shop','MUNTY STORE')
        p.write_text(s,encoding='utf-8')
