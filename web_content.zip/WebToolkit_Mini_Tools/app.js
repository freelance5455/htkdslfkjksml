const $ = (id) => document.getElementById(id);
document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b === btn));
  document.querySelectorAll('.tool-panel').forEach(p => p.classList.toggle('active', p.id === 'tool-' + btn.dataset.tool));
}));

function readDataURL(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
function loadImage(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=reject;img.src=src;});}
function downloadBlob(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function safeName(s){return (s||'image').replace(/[^a-z0-9-_]+/gi,'-').replace(/^-+|-+$/g,'')||'image';}

// Image to PDF
let pdfImages=[];
$('pdfFiles').addEventListener('change', async e=>{
  pdfImages=Array.from(e.target.files||[]).filter(f=>f.type.startsWith('image/'));
  $('pdfPreview').innerHTML='';
  for(const file of pdfImages){const img=document.createElement('img');img.alt=file.name;img.src=await readDataURL(file);$('pdfPreview').appendChild(img);}
  $('makePdf').disabled=pdfImages.length===0;
});
$('makePdf').addEventListener('click', async ()=>{
  if(!window.jspdf){alert('PDF library could not load. Please check your internet connection and try again.');return;}
  const {jsPDF}=window.jspdf;let doc=null;
  for(let i=0;i<pdfImages.length;i++){
    const data=await readDataURL(pdfImages[i]);const img=await loadImage(data);
    const landscape=img.width>img.height;
    const orientation=landscape?'landscape':'portrait';
    if(!doc)doc=new jsPDF({orientation,unit:'mm',format:'a4'});
    else doc.addPage('a4',orientation);
    const pageW=doc.internal.pageSize.getWidth(),pageH=doc.internal.pageSize.getHeight(),margin=8;
    const scale=Math.min((pageW-margin*2)/img.width,(pageH-margin*2)/img.height);
    const w=img.width*scale,h=img.height*scale;
    doc.addImage(data, fileFormat(data), (pageW-w)/2,(pageH-h)/2,w,h,undefined,'FAST');
  }
  if(doc)doc.save('webtoolkit-images.pdf');
});
function fileFormat(data){if(data.startsWith('data:image/png'))return 'PNG';if(data.startsWith('data:image/webp'))return 'WEBP';return 'JPEG';}

// Convert to PNG
let pngData=null,pngName='image';
$('pngFile').addEventListener('change',async e=>{
  const file=e.target.files&&e.target.files[0];if(!file)return;
  pngName=safeName(file.name.replace(/\.[^.]+$/,''));pngData=await readDataURL(file);
  $('pngPreview').innerHTML='';const img=document.createElement('img');img.src=pngData;img.alt='Image preview';$('pngPreview').appendChild(img);$('convertPng').disabled=false;
});
$('convertPng').addEventListener('click',async()=>{
  if(!pngData)return;try{const img=await loadImage(pngData);const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;c.getContext('2d').drawImage(img,0,0);c.toBlob(blob=>{if(blob)downloadBlob(blob,pngName+'.png');else alert('Could not convert this image.');},'image/png');}catch(e){alert('Could not open this image.');}
});

// Image to HTML snippet
let imageSnippetData=null;
async function updateImageSnippet(file){
  if(!file)return;imageSnippetData=await readDataURL(file);
  $('imageCodePreview').innerHTML='';const img=document.createElement('img');img.src=imageSnippetData;img.alt='Uploaded image preview';$('imageCodePreview').appendChild(img);
  const alt=($('altText').value||file.name).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  $('imageCodeOutput').textContent='<img src="'+imageSnippetData+'" alt="'+alt+'" style="max-width:100%;height:auto;">';
  $('copyImageCode').disabled=false;
}
$('codeImageFile').addEventListener('change',e=>updateImageSnippet(e.target.files&&e.target.files[0]));
$('altText').addEventListener('input',()=>{const f=$('codeImageFile').files&&$('codeImageFile').files[0];if(f)updateImageSnippet(f);});
$('copyImageCode').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('imageCodeOutput').textContent);$('copyImageCode').textContent='Copied!';setTimeout(()=>$('copyImageCode').textContent='Copy code',1200);}catch(e){alert('Copy not available in this browser. Select the code and copy it manually.');}});

// Code to image
function drawCodeImage(){
  const canvas=$('codeCanvas'),ctx=canvas.getContext('2d'),theme=$('codeTheme').value,font=parseInt($('fontSize').value,10)||16;
  const text=$('codeInput').value||'Paste your code here to create an image.';
  const lines=text.split(/\r?\n/);const pad=36,lineH=Math.round(font*1.65),gutter=48;
  ctx.font=font+'px Consolas, "Courier New", monospace';
  const maxWidth=Math.max(500,...lines.map(line=>ctx.measureText(line).width));
  canvas.width=Math.min(2400,Math.ceil(maxWidth+pad*2+gutter));canvas.height=Math.min(5000,Math.max(170,lines.length*lineH+pad*2+28));
  const dark=theme==='dark';ctx.fillStyle=dark?'#101827':'#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle=dark?'#202b3d':'#f1f4f9';ctx.fillRect(0,0,canvas.width,46);
  ['#ff625b','#ffc044','#28c840'].forEach((color,i)=>{ctx.fillStyle=color;ctx.beginPath();ctx.arc(22+i*20,23,5,0,Math.PI*2);ctx.fill();});
  ctx.fillStyle=dark?'#9aa9c0':'#7b8495';ctx.font='12px Arial';ctx.fillText('WebToolkit · Code Image',90,27);
  ctx.font=font+'px Consolas, "Courier New", monospace';ctx.textBaseline='top';
  lines.forEach((line,i)=>{const y=60+i*lineH;ctx.fillStyle=dark?'#72809a':'#9ba5b5';ctx.fillText(String(i+1),pad,y);ctx.fillStyle=dark?'#e6edf7':'#202b3d';ctx.fillText(line,pad+gutter,y);});
}
$('renderCode').addEventListener('click',drawCodeImage);
$('codeInput').addEventListener('input',drawCodeImage);
$('codeTheme').addEventListener('change',drawCodeImage);
$('fontSize').addEventListener('change',drawCodeImage);
$('downloadCodeImage').addEventListener('click',()=>{drawCodeImage();$('codeCanvas').toBlob(blob=>{if(blob)downloadBlob(blob,'webtoolkit-code-image.png');});});
drawCodeImage();
