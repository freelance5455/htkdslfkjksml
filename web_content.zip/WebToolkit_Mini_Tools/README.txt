# WebToolkit Mini Tools

A small responsive HTML/CSS/JavaScript project containing:
1. Image to PDF (multiple images, one image per PDF page)
2. Convert image to PNG
3. Image to Code (creates an HTML `<img>` snippet with the image embedded as a data URL)
4. Code to Image (renders pasted text/code into a PNG)

## Run
- Extract the ZIP.
- Open `index.html` in a modern browser.
- Image-to-PDF loads jsPDF from a CDN, so it needs internet access.
- The other tools work locally in the browser.

## Important
- “Image to Code” here means generating HTML to display the uploaded image. It does not use an AI model to recreate a full webpage from a screenshot.
- This is a website project, not an APK. To create an APK, package it using a suitable Android WebView wrapper/converter and test the generated app.
- Add your own logo by replacing the `W` inside `.brand-mark` in `index.html` with an `<img>` element and adjusting its CSS in `style.css`.
