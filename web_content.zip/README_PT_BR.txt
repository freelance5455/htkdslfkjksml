INVENTÁRIO CARGILL — PROJETO ANDROID

Este pacote é o projeto-fonte para gerar um APK instalável, não é o APK compilado.
O ambiente desta entrega não tem Android SDK/Gradle instalado para compilar e testar
o APK final.

Como gerar o APK:
1. Instale Android Studio em um computador autorizado.
2. Abra a pasta deste projeto no Android Studio.
3. Aguarde o Gradle sincronizar e instale o Android SDK solicitado.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste costuma aparecer em app/build/outputs/apk/debug/app-debug.apk.
6. Transfira o APK para o Android e instale somente após autorização das regras de TI.

O app abre a interface offline embutida no APK. Dados ficam no armazenamento local
do WebView/aparelho. Não há conexão com SAP/SharePoint e não há sincronização entre
dispositivos. Valide importação/exportação de CSV e o leitor Zebra em aparelho real.

Antes de distribuir em ambiente corporativo, peça aprovação da TI/Segurança da Informação.
