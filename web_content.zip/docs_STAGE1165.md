# CPLS Stage 1165 — Backend-Authoritative Reward Claim Protocol

- Added a client-side claim-intent boundary only.
- The client never selects an authoritative reward amount.
- Claim intents require account reference, valid EVM wallet address, client nonce, and short expiry.
- Maximum client claim-intent TTL is 10 minutes.
- Client signing and transaction broadcast remain disabled.
- Backend authorization remains mandatory.
- No private key, seed, secret, or authoritative reward balance is exposed to WebView.
- This stage does not claim a deployed backend or live claim transaction.
