rootProject.name = "VYRO"
include(":app")
