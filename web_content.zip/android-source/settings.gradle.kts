rootProject.name = "VYRO-V26"
include(":app")
