VYRO™ V26 Android Source
========================
هذه نسخة Android بدون Texas King وبدون مراقبة الشاشة أو خدماتها.
تحتوي على WebView لتشغيل واجهة VYRO وبناء APK عبر GitHub Actions.
