plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.vyro.app"; compileSdk = 35
    defaultConfig { applicationId = "com.vyro.app"; minSdk = 26; targetSdk = 35; versionCode = 24; versionName = "V24" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}

// The complete bundle keeps one copy of the web files at the bundle root.
// Before Android builds, copy those files into app/src/main/assets automatically.
val syncVYROAssets by tasks.registering {
    doLast {
        val bundleRoot = project.rootDir.parentFile
        val assetsDir = project.file("src/main/assets")
        assetsDir.deleteRecursively()
        assetsDir.mkdirs()
        bundleRoot.listFiles()?.filter { it.isFile && it.extension.equals("html", true) }?.forEach { it.copyTo(assetsDir.resolve(it.name), overwrite = true) }
        val rootAssets = bundleRoot.resolve("assets")
        if (rootAssets.exists()) rootAssets.copyRecursively(assetsDir.resolve("assets"), overwrite = true)
    }
}

tasks.named("preBuild") { dependsOn(syncVYROAssets) }
