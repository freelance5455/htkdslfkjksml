package com.vyro.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val captureRequest = 7001

    companion object {
        var instance: MainActivity? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun askCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequest) return
        if (resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            androidx.core.content.ContextCompat.startForegroundService(this, i)
            startFloating()
            web.evaluateJavascript("window.vyroScreenCaptureStarted && window.vyroScreenCaptureStarted()", null)
        } else {
            web.evaluateJavascript("window.vyroScreenCaptureDenied && window.vyroScreenCaptureDenied()", null)
        }
    }

    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FloatingMonitorService::class.java))
    }

    fun pushDetection(result: String) {
        runOnUiThread {
            val safe = result.replace("\\", "\\\\").replace("'", "\\'")
            web.evaluateJavascript("window.vyroRoundDetected && window.vyroRoundDetected('$safe')", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun toggleScreenCapture(): Boolean {
            runOnUiThread { askCapture() }
            return true
        }

        @JavascriptInterface fun setDetectionMode(mode: String): Boolean {
            ScreenCaptureService.mode = when (mode) {
                "center" -> ScreenCaptureService.DetectionMode.CENTER
                "upper" -> ScreenCaptureService.DetectionMode.UPPER_CENTER
                "full" -> ScreenCaptureService.DetectionMode.BROAD
                else -> ScreenCaptureService.DetectionMode.CENTER
            }
            return true
        }

        @JavascriptInterface fun stopScreenCapture(): Boolean {
            stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
            stopService(Intent(this@MainActivity, FloatingMonitorService::class.java))
            web.evaluateJavascript("window.vyroScreenCaptureStopped && window.vyroScreenCaptureStopped()", null)
            return true
        }
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
