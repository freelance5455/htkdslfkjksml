package com.vyro.app

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import kotlin.math.max

class ScreenCaptureService : Service() {
    enum class DetectionMode { CENTER, UPPER_CENTER, BROAD }
    companion object { var mode = DetectionMode.CENTER }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastCandidate: String? = null
    private var candidateSince = 0L
    private var lastCommit = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(4101, Notification.Builder(this, "vyro_monitor")
            .setContentTitle("VYRO™ Texas King")
            .setContentText("مراقبة النتائج تعمل")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build())

        val code = intent?.getIntExtra("resultCode", 0) ?: return START_NOT_STICKY
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
            ?: return START_NOT_STICKY

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            r.acquireLatestImage()?.use { analyze(it) }
        }, Handler(Looper.getMainLooper()))
        display = projection!!.createVirtualDisplay(
            "VYRO-TexasKing", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("vyro_monitor", "VYRO Monitor", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun analyze(image: android.media.Image) {
        val w = image.width
        val h = image.height
        val (x0, y0, x1, y1) = when (mode) {
            DetectionMode.CENTER -> intArrayOf((w * .20).toInt(), (h * .22).toInt(), (w * .80).toInt(), (h * .80).toInt())
            DetectionMode.UPPER_CENTER -> intArrayOf((w * .16).toInt(), (h * .12).toInt(), (w * .84).toInt(), (h * .62).toInt())
            DetectionMode.BROAD -> intArrayOf((w * .06).toInt(), (h * .10).toInt(), (w * .94).toInt(), (h * .90).toInt())
        }
        val plane = image.planes[0]
        val buf = plane.buffer
        val row = plane.rowStride
        val px = plane.pixelStride
        var red = 0
        var blue = 0
        var samples = 0
        for (y in y0 until y1 step 10) {
            val base = y * row
            for (x in x0 until x1 step 10) {
                val pos = base + x * px
                if (pos + 2 >= buf.limit()) continue
                val r = buf.get(pos).toInt() and 255
                val g = buf.get(pos + 1).toInt() and 255
                val b = buf.get(pos + 2).toInt() and 255
                val maxC = max(r, maxOf(g, b))
                val minC = minOf(r, g, b)
                if (maxC < 80 || maxC - minC < 35) continue
                if (r > 165 && r > g * 1.35 && r > b * 1.18) red++
                if (b > 150 && b > r * 1.18 && b > g * 1.04) blue++
                samples++
            }
        }
        if (samples < 20) return
        val candidate = when {
            red > blue * 1.35 && red > 12 -> "R"
            blue > red * 1.35 && blue > 12 -> "B"
            else -> null
        }
        val now = System.currentTimeMillis()
        if (candidate == null) { lastCandidate = null; return }
        if (candidate != lastCandidate) {
            lastCandidate = candidate
            candidateSince = now
            return
        }
        if (now - candidateSince >= 1700 && now - lastCommit >= 5000) {
            lastCommit = now
            MainActivity.instance?.pushDetection(candidate)
            candidateSince = now
            lastCandidate = null
        }
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
