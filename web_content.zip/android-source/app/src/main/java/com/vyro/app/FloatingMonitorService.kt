package com.vyro.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.TextView

class FloatingMonitorService:Service(){ private var wm:WindowManager?=null; private var v:TextView?=null
 override fun onCreate(){super.onCreate(); if(!Settings.canDrawOverlays(this))return; wm=getSystemService(WINDOW_SERVICE) as WindowManager; v=TextView(this).apply{ text="📺"; textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(220,35,55)); setPadding(16,10,16,10); setOnClickListener{ setBackgroundColor(Color.rgb(28,170,110)); postDelayed({setBackgroundColor(Color.rgb(220,35,55))},900) }}; val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE; val lp=WindowManager.LayoutParams(64,64,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); lp.gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL; wm?.addView(v,lp) }
 override fun onDestroy(){v?.let{wm?.removeView(it)};super.onDestroy()};override fun onBind(i:Intent?)=null }
