Assets are copied from the bundle root before building.
