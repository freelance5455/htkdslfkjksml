# VYRO Texas King: no custom shrinking rules required for debug/release prototype.
