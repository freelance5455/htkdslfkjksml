-- ScoreDeck Update Centre: additive Supabase migration
-- Run once in Supabase Dashboard -> SQL Editor for the existing ScoreDeck project.
-- This creates a read-only public feed. Publishing is done by the project owner in the dashboard.

create table if not exists public.app_updates (
  id uuid primary key default gen_random_uuid(),
  version text not null,
  version_code integer not null check (version_code > 0),
  title text not null,
  message text not null default '',
  release_notes text not null default '',
  update_url text not null default '',
  is_active boolean not null default true,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table public.app_updates enable row level security;
revoke all on public.app_updates from anon, authenticated;
grant select on public.app_updates to anon, authenticated;

drop policy if exists "Anyone can read active ScoreDeck updates" on public.app_updates;
create policy "Anyone can read active ScoreDeck updates"
  on public.app_updates
  for select
  to anon, authenticated
  using (is_active = true);

-- Intentionally no INSERT/UPDATE/DELETE policies for app clients.
-- Add/publish announcements through the Supabase Dashboard as the project owner.
-- Before activating an announcement, replace update_url with your real Google Drive folder URL.
