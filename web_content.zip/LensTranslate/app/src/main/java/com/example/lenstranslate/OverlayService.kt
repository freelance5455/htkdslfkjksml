package com.example.lenstranslate

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.*
import com.google.mlkit.nl.translate.*
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var frame: FrameLayout
    private lateinit var resultView: TextView
    private lateinit var lp: WindowManager.LayoutParams

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var screenW = 0
    private var screenH = 0

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)   // لغة النص الأصلي
            .setTargetLanguage(TranslateLanguage.ARABIC)    // لغة الترجمة
            .build()
    )
    private var modelReady = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        setupProjection(code, data)
        setupOverlay()

        // تحميل نموذج الترجمة مرة واحدة (يحتاج إنترنت أول مرة فقط)
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { modelReady = true }
            .addOnFailureListener { resultView.text = "فشل تحميل نموذج الترجمة" }
        return START_NOT_STICKY
    }

    // ---------- Foreground ----------
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("lens", "Lens Translate", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "lens")
            .setContentTitle("المترجم يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- التقاط الشاشة ----------
    private fun setupProjection(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))
        }
        val dm = resources.displayMetrics
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        vDisplay = projection!!.createVirtualDisplay(
            "lens", screenW, screenH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
    }

    private fun grabCroppedBitmap(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val plane = img.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * screenW
        val full = Bitmap.createBitmap(
            screenW + rowPadding / plane.pixelStride, screenH, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(plane.buffer)
        img.close()

        val loc = IntArray(2)
        frame.getLocationOnScreen(loc)
        val x = loc[0].coerceIn(0, screenW - 1)
        val y = loc[1].coerceIn(0, screenH - 1)
        val w = frame.width.coerceAtMost(screenW - x)
        val h = frame.height.coerceAtMost(screenH - y)
        return Bitmap.createBitmap(full, x, y, w, h)
    }

    // ---------- OCR + ترجمة ----------
    private fun translateUnderLens() {
        if (!modelReady) { resultView.text = "النموذج لم يجهز بعد..."; return }
        val bmp = grabCroppedBitmap() ?: run { resultView.text = "تعذر التقاط الشاشة"; return }
        resultView.text = "..."
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { vt ->
                val text = vt.text.replace("\n", " ").trim()
                if (text.isEmpty()) { resultView.text = "لا يوجد نص"; return@addOnSuccessListener }
                translator.translate(text)
                    .addOnSuccessListener { resultView.text = it }
                    .addOnFailureListener { resultView.text = "فشلت الترجمة" }
            }
            .addOnFailureListener { resultView.text = "فشلت قراءة النص" }
    }

    // ---------- النافذة العائمة ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // الإطار الشفاف (المكبّر)
        frame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(3), Color.parseColor("#FF4081"))
                cornerRadius = dp(12).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(300), dp(140))
        }

        val btn = Button(this).apply {
            text = "ترجم"
            setOnClickListener { translateUnderLens() }
        }
        val close = Button(this).apply {
            text = "✕"
            setOnClickListener { stopSelf() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btn, LinearLayout.LayoutParams(0, -2, 1f))
            addView(close, LinearLayout.LayoutParams(dp(60), -2))
        }

        resultView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#CC000000"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            textSize = 16f
            text = "حرّك الإطار فوق النص ثم اضغط ترجم"
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(frame)
            addView(row)
            addView(resultView, LinearLayout.LayoutParams(dp(300), -2))
        }

        lp = WindowManager.LayoutParams(
            -2, -2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(40); y = dp(200) }

        // سحب الإطار
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        frame.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        wm.addView(root, lp)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::root.isInitialized) wm.removeView(root)
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        translator.close()
        recognizer.close()
    }
}
