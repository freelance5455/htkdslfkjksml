# ظل الليل — APK WebView

هذا المشروع يلف ملف اللعبة HTML داخل تطبيق Android، ويفتحه محلياً من `android_asset` بدل رابط ويب خارجي.

## بناء APK من GitHub
1. ارفع كل ملفات المشروع إلى Repository جديد في GitHub.
2. افتح تبويب Actions.
3. شغّل **Build Shadow Night APK**.
4. بعد انتهاء البناء افتح الـworkflow ثم Artifacts وحمّل `ShadowNight-debug-apk`.
5. فك الضغط وستجد `app-debug.apk`.

ملف اللعبة الأصلي موجود في: `app/src/main/assets/index.html`.
