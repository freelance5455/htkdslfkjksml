# v1.62.33 — Imprensa Internacional

- Mantido o portal ge para partidas de competições brasileiras.
- Criada identidade editorial Sky Sports para partidas da Inglaterra/Premier League.
- Criada identidade editorial MARCA para partidas da Espanha/LaLiga.
- Coletivas passam a selecionar jornalistas e veículos de acordo com o país/competição da partida.
- Manchetes e cores do cabeçalho pós-jogo variam conforme o portal.
- Preservadas perguntas, respostas, efeitos da coletiva, histórico e fluxo pós-jogo.
- Atualizado cache do service worker para evitar reutilização da versão anterior.
