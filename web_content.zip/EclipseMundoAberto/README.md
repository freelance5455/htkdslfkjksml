# Eclipse Mundo Aberto — projeto Android

Este projeto empacota o jogo HTML em um aplicativo Android de tela cheia, com controles de toque e armazenamento local do WebView.

## Como gerar o APK

1. Instale o **Android Studio** no computador.
2. Extraia esta pasta ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `EclipseMundoAberto` extraída.
4. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitado.
5. No menu, escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Ao terminar, clique em **locate** na notificação do Android Studio. O arquivo normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para o celular Android e abra-o para instalar. Se o Android pedir, permita a instalação dessa fonte.

## Observação importante

O jogo usa Three.js carregado do CDN `cdnjs.cloudflare.com` e fontes do Google Fonts. Por isso, a primeira inicialização e o carregamento 3D precisam de conexão com a internet. O progresso e as configurações são armazenados no armazenamento local do aplicativo.

## Requisitos

- Android Studio recente
- JDK 17 (incluído nas versões atuais do Android Studio)
- Android SDK Platform 35
- Gradle 8.7 (o Android Studio baixa automaticamente durante a sincronização)
