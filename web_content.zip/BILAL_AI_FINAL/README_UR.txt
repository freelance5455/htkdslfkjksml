BILAL AI FINAL WEB/PWA PROTOTYPE

SETUP (Android):
1. ZIP extract karein.
2. Files ko kisi HTTPS static host par upload karein (GitHub Pages/Netlify etc.) ya local web server par chalayein.
3. Chrome mein hosted link open karein. HTTPS zaroori hai for microphone and PWA install.
4. Settings > Gemini/Groq API key paste karein > Save.
5. TEST CONNECTION dabayein. Phir chat ya microphone use karein.

APK:
Yeh ZIP HTML/PWA source project hai, native Android Gradle project nahi.
AppMint/Appment tabhi use karein jab woh HTML/PWA ZIP ko explicitly support karta ho. Agar woh Android Studio/Gradle project maangta hai to direct upload se APK nahi banegi; Capacitor/Android WebView wrapper aur Android build environment chahiye.

FEATURES IMPLEMENTED:
- Responsive dark purple/gold-ish neon UI with animated orb
- Gemini and Groq API settings
- Provider selection and automatic fallback if primary fails and backup key exists
- Chat context for current session
- Browser speech recognition (if browser/device supports it)
- Browser text-to-speech
- PWA manifest and basic offline caching of app shell

IMPORTANT LIMITATIONS (no false claims):
- Background always-on microphone / listening while app is closed is NOT implemented. Android requires a native foreground service, explicit permissions, persistent notification and platform-specific code. Force-stop prevents services.
- Native phone notifications/call details/battery integration are NOT implemented.
- This is not yet a native APK.
- Browser speech recognition support varies. Chrome/Android and HTTPS are recommended.
- API keys are stored in this browser's localStorage. This is acceptable only for a private personal prototype. Never publish/share the app with your keys. A public release needs a secure backend proxy and server-side secrets.
- API quotas, model access and network/CORS behavior depend on provider/account/browser.
- Chat history is kept only in current session memory; no cloud sync or persistent conversation archive.

If a provider fails, check the key, model ID, quota, internet and provider status. Do not paste API keys into public GitHub repositories.
