BLOCKS FORMATIONS - PROYECTO ANDROID

Este paquete contiene el proyecto Android que envuelve el juego HTML en una app Android (WebView).
Incluye el icono que enviaste y el juego optimizado.

IMPORTANTE:
Este entorno no tiene Android SDK/Build Tools instalados, por eso no puedo compilar ni adjuntar un APK firmado desde aquí.
El proyecto sí está preparado para abrirse y compilarse con Android Studio.

CÓMO GENERAR EL APK:
1. Instala Android Studio en una computadora.
2. Descomprime BlocksFormationsAndroid.zip.
3. En Android Studio, elige Open y selecciona la carpeta BlocksFormationsAndroid.
4. Espera a que Gradle sincronice y que Android Studio descargue los componentes Android necesarios.
5. En el menú: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. El APK de prueba aparecerá en:
   app/build/outputs/apk/debug/app-debug.apk

Para crear un APK instalable para compartir:
Build > Generate Signed Bundle / APK > APK, y sigue el asistente para crear una clave de firma.

Requisitos del proyecto:
- Android mínimo: 6.0 (API 23)
- Android objetivo: API 35
- Nombre: Blocks Formations
- ID: com.blocksformations.game
- Funciona sin conexión; el juego está incluido dentro de la app.
