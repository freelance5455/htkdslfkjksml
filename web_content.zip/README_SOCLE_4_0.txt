CGD V117 — SOCLE 4.0
Modèles humanoïdes 3D détaillés et présentation des damistes

Ouvrir index.html dans un navigateur récent prenant en charge WebGL.
Sur mobile, privilégier le format paysage et un navigateur avec accélération graphique.
Le mode 3D reste désactivable ; la vue classique est conservée en solution de repli.

Voir STAGE_4_0_MODELES_DAMISTES_3D_PRESENTATION.md pour les évolutions et limites.
Lancer les tests avec : npm test
