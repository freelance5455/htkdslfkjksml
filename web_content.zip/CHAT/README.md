# CHAT — application de messagerie (base de production à configurer)

CHAT est une application web responsive, installable comme PWA et emballable en Android avec Capacitor. Elle utilise Firebase Authentication, Cloud Firestore, Firebase Storage et WebRTC.

## Ce qui fonctionne après configuration Firebase
- Inscription e-mail/mot de passe et connexion/déconnexion.
- Profil de membre et identifiant unique.
- Recherche des comptes existants dans Firestore.
- Discussions privées Firestore en temps réel.
- Messages texte, photos, vidéos et messages vocaux.
- Marquage des messages lus.
- Signalisation d'appels audio/vidéo via Firestore et flux média WebRTC.

## Important : configuration indispensable
Ce dépôt n'inclut aucune clé Firebase, aucun compte hébergeur et aucune infrastructure TURN. Sans votre propre projet Firebase, les fonctions connectées ne peuvent pas fonctionner. Ne publiez jamais les clés privées de service Firebase dans le navigateur.

### 1. Créer le projet Firebase
1. Ouvrir https://console.firebase.google.com/ et créer un projet nommé `CHAT`.
2. Ajouter une application Web et copier la configuration Firebase.
3. Dans `public/app.js`, remplacer les six valeurs `VOTRE_...` de `firebaseConfig`.
4. Dans Authentication > Sign-in method, activer **Email/Password**.
5. Créer la base Firestore en mode production.
6. Activer Firebase Storage.
7. Dans les paramètres du projet, ajouter le domaine de votre futur site aux domaines autorisés d'Authentication.

### 2. Déployer les règles
Installer Node.js (version LTS), puis dans ce dossier :
```bash
npm install
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore:rules,firestore:indexes,storage
```
Le projet doit être sélectionné comme projet Firebase par défaut.

### 3. Ajouter le champ de recherche nom
Lors de la création du profil, le code doit enregistrer `nameLower`. Pour les comptes existants, compléter ce champ une fois dans Firestore. Pour que la recherche par nom fonctionne pour tous les nouveaux comptes, ajoutez `nameLower` dans l'objet `setDoc` d'inscription de `public/app.js` :
```js
nameLower: $("regName").value.trim().toLowerCase(),
```
La recherche par identifiant fonctionne directement.

### 4. Hébergement sécurisé
```bash
firebase deploy --only hosting
```
Firebase affiche alors une adresse HTTPS de type `https://VOTRE_PROJET.web.app`. C'est cette adresse qu'il faudra partager.

### 5. Android APK
Prérequis : ordinateur Windows/macOS/Linux, Node.js LTS, Android Studio et Android SDK.
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
Dans Android Studio : Build > Build Bundle(s) / APK(s) > Build APK(s). Le fichier APK est généré dans `android/app/build/outputs/apk/`.
Pour Google Play, générer plutôt un Android App Bundle (AAB) signé via Build > Generate Signed Bundle / APK. Créer et conserver soigneusement la clé de signature.

## Notifications
Le service worker fourni met en cache l'interface mais ne constitue pas à lui seul un service de notifications push. Pour les notifications push web/Android, il faut activer Firebase Cloud Messaging, ajouter une clé VAPID, demander l'autorisation de notification et utiliser une fonction serveur sécurisée (Cloud Functions) pour envoyer les notifications. Pour les appels entrants lorsque l'application est fermée, une notification push/FCM et un traitement Android natif sont nécessaires.

## Limites à résoudre avant une publication publique
- **TURN WebRTC** : le STUN public aide à établir les appels, mais ne suffit pas sur certains réseaux mobiles/pare-feu. Déployer un serveur TURN (ex. coturn ou fournisseur géré), puis ajouter ses identifiants protégés dans `rtcConfig`.
- **Sécurité et confidentialité** : les règles fournies sont une base stricte, mais elles doivent être auditées et testées. Pour un produit public, ajouter limitation anti-spam, validation côté serveur, modération/rapport, blocage, suppression de compte et politique de confidentialité.
- **Chiffrement** : Firebase en transit et au repos ne signifie pas chiffrement de bout en bout. Ne pas annoncer E2EE sans protocole et audit dédiés.
- **Présence** : Firestore ne fournit pas la présence native. La présence affichée est indicative et doit être améliorée avec Realtime Database + Cloud Functions pour gérer les fermetures brutales et appareils multiples.
- **Identifiants uniques** : la vérification actuelle côté client doit être remplacée par une réservation transactionnelle/Cloud Function pour éviter deux inscriptions simultanées avec le même identifiant.
- **Recherche** : Firestore ne fournit pas de recherche plein texte native. La recherche actuelle est un préfixe simple; ajouter un moteur dédié si nécessaire.
- **Appels** : le code inclut la signalisation de base, pas une infrastructure télécom garantie. Tester avec plusieurs téléphones et réseaux, gérer les délais, les appels occupés et les permissions.
- **Messages** : les médias doivent être protégés par des règles adaptées aux membres. Les pièces jointes sont limitées par taille; définir quotas et coûts.
- **Conformité Play Store** : fournir politique de confidentialité, fiche de sécurité des données, procédure de suppression de compte et déclarations exactes avant publication.

## Structure
- `public/CHAT.html` : page principale.
- `public/styles.css` : design responsive.
- `public/app.js` : application Firebase / WebRTC.
- `public/sw.js`, `manifest.webmanifest`, `icon.svg` : PWA.
- `firebase/` : règles et index Firestore.
- `firebase.json`, `capacitor.config.json`, `package.json` : déploiement et Android.

## État honnête du livrable
Le code source et les fichiers de configuration sont fournis. Il ne s'agit pas encore d'une application publiée ni d'un APK précompilé : ces deux livrables dépendent du projet Firebase, du domaine d'hébergement et de la chaîne de compilation Android du propriétaire. Configurez et testez toutes les fonctions avant toute diffusion publique.
