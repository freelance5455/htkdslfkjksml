import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, updateDoc, collection, query, where, orderBy, limit, onSnapshot, addDoc, serverTimestamp, getDocs, writeBatch } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

// 1) Remplacez les valeurs ci-dessous par celles de votre projet Firebase.
const firebaseConfig = {
  apiKey: "VOTRE_API_KEY",
  authDomain: "VOTRE_PROJET.firebaseapp.com",
  projectId: "VOTRE_PROJET",
  storageBucket: "VOTRE_PROJET.appspot.com",
  messagingSenderId: "VOTRE_SENDER_ID",
  appId: "VOTRE_APP_ID"
};
const configured = !Object.values(firebaseConfig).some(v => String(v).startsWith("VOTRE_"));
const $ = id => document.getElementById(id);
const app = configured ? initializeApp(firebaseConfig) : null;
const auth = app ? getAuth(app) : null, db = app ? getFirestore(app) : null, storage = app ? getStorage(app) : null;
let me = null, activePeer = null, activeChatId = null, stopMessages = null, stopChats = null, stopPresence = null;
let selectedFile = null, mediaRecorder = null, audioChunks = [], localStream = null, peerConnection = null, currentCall = null, stopCall = null;
const toast = msg => { $("toast").textContent=msg; $("toast").classList.add("show"); setTimeout(()=>$("toast").classList.remove("show"),2800); };
const err = (id,msg) => $(id).textContent = msg || "";
const initials = s => (s||"C").trim().slice(0,1).toUpperCase();
const chatIdFor = (a,b) => [a,b].sort().join("_");
const safeText = s => String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function showAuthTab(tab){document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===tab));$("loginForm").classList.toggle("hidden",tab!=="login");$("registerForm").classList.toggle("hidden",tab!=="register");err("authError","");}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showAuthTab(b.dataset.tab));
document.querySelectorAll(".side-tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".side-tab").forEach(x=>x.classList.toggle("active",x===b));["chats","people","calls","profile"].forEach(p=>$ (p+"Page").classList.toggle("hidden",p!==b.dataset.page));});
function requireConfig(){if(!configured){toast("Configuration Firebase requise : consultez le fichier README.");return false;}return true;}
$("registerForm").onsubmit=async e=>{e.preventDefault();if(!requireConfig())return;err("authError","");try{
 const username=$("regUsername").value.trim().toLowerCase().replace(/^@/,"");
 if(!/^[a-z0-9_]{3,20}$/.test(username))throw Error("Identifiant invalide (3 à 20 lettres, chiffres ou _).");
 const existing=await getDocs(query(collection(db,"users"),where("username","==",username),limit(1)));
 if(!existing.empty)throw Error("Cet identifiant est déjà utilisé.");
 const cred=await createUserWithEmailAndPassword(auth,$("regEmail").value,$("regPassword").value);
 await setDoc(doc(db,"users",cred.user.uid),{uid:cred.user.uid,name:$("regName").value.trim(),username,email:$("regEmail").value.toLowerCase(),bio:"",photoURL:"",createdAt:serverTimestamp(),online:true,lastSeen:serverTimestamp()});
 toast("Compte créé. Bienvenue sur CHAT !");
 }catch(e){err("authError",friendlyError(e));}};
$("loginForm").onsubmit=async e=>{e.preventDefault();if(!requireConfig())return;try{await signInWithEmailAndPassword(auth,$("loginEmail").value,$("loginPassword").value);}catch(e){err("authError",friendlyError(e));}};
$("logoutBtn").onclick=async()=>{if(me)await updateDoc(doc(db,"users",me.uid),{online:false,lastSeen:serverTimestamp()}).catch(()=>{});await signOut(auth);};
function friendlyError(e){const map={"auth/email-already-in-use":"Cette adresse e-mail est déjà utilisée.","auth/invalid-credential":"Identifiants incorrects.","auth/weak-password":"Mot de passe trop faible.","auth/network-request-failed":"Vérifiez votre connexion Internet."};return map[e.code]||e.message||"Une erreur est survenue.";}
onAuthStateChanged(auth||{onAuthStateChanged:()=>{}},async user=>{
 if(!configured){$("authView").classList.remove("hidden");$("mainView").classList.add("hidden");err("authError","Ajoutez d'abord la configuration Firebase dans app.js pour activer CHAT.");return;}
 if(!user){me=null;$("authView").classList.remove("hidden");$("mainView").classList.add("hidden");$("logoutBtn").classList.add("hidden");if(stopChats)stopChats();return;}
 const snap=await getDoc(doc(db,"users",user.uid));if(!snap.exists()){await signOut(auth);return;}me={...snap.data(),uid:user.uid};
 $("authView").classList.add("hidden");$("mainView").classList.remove("hidden");$("logoutBtn").classList.remove("hidden");
 $("profileName").value=me.name||"";$("profileBio").value=me.bio||"";$("profileHandle").textContent="@"+me.username;
 await updateDoc(doc(db,"users",me.uid),{online:true,lastSeen:serverTimestamp()});
 window.addEventListener("beforeunload",()=>updateDoc(doc(db,"users",me.uid),{online:false,lastSeen:serverTimestamp()}).catch(()=>{}),{once:true});
 listenChats(); listenCalls();
});
async function listenChats(){
 if(stopChats)stopChats();
 stopChats=onSnapshot(query(collection(db,"chats"),where("members","array-contains",me.uid),orderBy("updatedAt","desc")),async snap=>{
  const list=$("chatList");list.innerHTML="";
  if(snap.empty){list.innerHTML='<p class="muted pad">Aucune discussion. Recherchez une personne pour commencer.</p>';return;}
  for(const d of snap.docs){const data=d.data(),peerId=data.members.find(x=>x!==me.uid);const p=await getDoc(doc(db,"users",peerId));if(!p.exists())continue;const u=p.data();
   const item=document.createElement("div");item.className="chat-item"+(activeChatId===d.id?" selected":"");
   item.innerHTML=`<div class="person-avatar">${u.photoURL?`<img src="${safeText(u.photoURL)}">`:safeText(initials(u.name))}</div><div class="chat-details"><b>${safeText(u.name)}</b><small>${safeText(data.lastMessage||"Nouvelle conversation")}</small></div>`;
   item.onclick=()=>openChat(peerId,u,d.id);list.append(item);
  }
 });
}
async function startChat(peerId,peer){const id=chatIdFor(me.uid,peerId),r=doc(db,"chats",id),s=await getDoc(r);if(!s.exists())await setDoc(r,{members:[me.uid,peerId],createdAt:serverTimestamp(),updatedAt:serverTimestamp(),lastMessage:""});openChat(peerId,peer,id);}
function openChat(peerId,peer,id){activePeer={...peer,uid:peerId};activeChatId=id;$("emptyState").classList.add("hidden");$("threadView").classList.remove("hidden");$("threadName").textContent=peer.name;$("threadAvatar").textContent=initials(peer.name);$("threadStatus").textContent=peer.online?"En ligne":"@"+peer.username;$("messages").innerHTML="";document.querySelector(".conversation").classList.add("mobile-open");
 if(stopMessages)stopMessages();
 stopMessages=onSnapshot(query(collection(db,"chats",id,"messages"),orderBy("createdAt","asc"),limit(300)),snap=>{
  const box=$("messages");box.innerHTML="";
  snap.forEach(m=>{const d=m.data(),mine=d.senderId===me.uid;const b=document.createElement("div");b.className="bubble"+(mine?" mine":"");
   let content=safeText(d.text||"");
   if(d.type==="image")content=`<img src="${safeText(d.mediaURL)}" alt="Image envoyée">`;
   if(d.type==="video")content=`<video src="${safeText(d.mediaURL)}" controls playsinline></video>`;
   if(d.type==="audio")content=`<audio src="${safeText(d.mediaURL)}" controls></audio>`;
   b.innerHTML=`${content}<small>${d.createdAt?.toDate?d.createdAt.toDate().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"À l'instant"} ${mine?(d.readBy?.includes(peerId)?"✓✓":d.delivered?"✓":""):""}</small>`;box.append(b);
   if(!mine && !(d.readBy||[]).includes(me.uid))updateDoc(doc(db,"chats",id,"messages",m.id),{readBy:[...(d.readBy||[]),me.uid]}).catch(()=>{});
  });box.scrollTop=box.scrollHeight;
 });
}
$("messageForm").onsubmit=async e=>{e.preventDefault();if(!activeChatId)return;const text=$("messageInput").value.trim();if(!text&&!selectedFile)return;try{
 let type="text",mediaURL="";if(selectedFile){type=selectedFile.type.startsWith("image/")?"image":selectedFile.type.startsWith("video/")?"video":"file";const path=`chat-media/${activeChatId}/${me.uid}/${Date.now()}-${selectedFile.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const fileRef=ref(storage,path);await uploadBytes(fileRef,selectedFile);mediaURL=await getDownloadURL(fileRef);}
 await addDoc(collection(db,"chats",activeChatId,"messages"),{senderId:me.uid,text,type,mediaURL,createdAt:serverTimestamp(),readBy:[me.uid],delivered:false});
 await updateDoc(doc(db,"chats",activeChatId),{lastMessage:text||(type==="image"?"📷 Photo":type==="video"?"🎬 Vidéo":"Fichier"),updatedAt:serverTimestamp()});
 $("messageInput").value="";selectedFile=null;$("mediaPreview").classList.add("hidden");
 }catch(e){err("threadError",friendlyError(e));}};
$("mediaFile").onchange=e=>{selectedFile=e.target.files[0]||null;if(selectedFile){$("mediaPreview").textContent="Fichier prêt : "+selectedFile.name;$("mediaPreview").classList.remove("hidden");}};
$("voiceBtn").onclick=async()=>{if(!activeChatId)return;if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast("Enregistrement vocal non pris en charge par ce navigateur.");return;}
 try{if(!mediaRecorder){localStream=await navigator.mediaDevices.getUserMedia({audio:true});mediaRecorder=new MediaRecorder(localStream);audioChunks=[];mediaRecorder.ondataavailable=e=>audioChunks.push(e.data);mediaRecorder.onstop=async()=>{const blob=new Blob(audioChunks,{type:mediaRecorder.mimeType||"audio/webm"});const fileRef=ref(storage,`chat-media/${activeChatId}/${me.uid}/${Date.now()}-voice.webm`);await uploadBytes(fileRef,blob);const url=await getDownloadURL(fileRef);await addDoc(collection(db,"chats",activeChatId,"messages"),{senderId:me.uid,text:"",type:"audio",mediaURL:url,createdAt:serverTimestamp(),readBy:[me.uid]});await updateDoc(doc(db,"chats",activeChatId),{lastMessage:"🎙 Message vocal",updatedAt:serverTimestamp()});localStream.getTracks().forEach(t=>t.stop());localStream=null;mediaRecorder=null;};mediaRecorder.start();$("voiceBtn").textContent="■";toast("Enregistrement… appuyez à nouveau pour envoyer.");}else{mediaRecorder.stop();$("voiceBtn").textContent="🎙";}}catch(e){toast("Microphone indisponible : "+e.message);}};
let searchTimer; $("userSearch").oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(searchUsers,350);};
async function searchUsers(){const term=$("userSearch").value.trim().toLowerCase().replace(/^@/,"");const box=$("searchResults");box.innerHTML="";if(term.length<2){box.innerHTML='<p class="muted pad">Saisissez au moins 2 caractères.</p>';return;}
 try{const byName=await getDocs(query(collection(db,"users"),where("nameLower"," >=",term),where("nameLower","<=",term+"\uf8ff"),limit(15))).catch(()=>null);
  const byUser=await getDocs(query(collection(db,"users"),where("username",">=",term),where("username","<=",term+"\uf8ff"),limit(15)));
  const users=new Map();if(byName)byName.forEach(d=>users.set(d.id,d.data()));byUser.forEach(d=>users.set(d.id,d.data()));users.delete(me.uid);
  if(!users.size){box.innerHTML='<p class="muted pad">Aucun membre trouvé.</p>';return;}
  users.forEach(u=>{const item=document.createElement("div");item.className="chat-item";item.innerHTML=`<div class="person-avatar">${safeText(initials(u.name))}</div><div class="chat-details"><b>${safeText(u.name)}</b><small>@${safeText(u.username)}</small></div><button class="primary">Message</button>`;item.querySelector("button").onclick=()=>startChat(u.uid,u);box.append(item);});
 }catch(e){box.innerHTML='<p class="error pad">Recherche impossible. Réessayez.</p>';}}
$("profileForm").onsubmit=async e=>{e.preventDefault();try{let photoURL=me.photoURL||"";const file=$("avatarFile").files[0];if(file){if(!file.type.startsWith("image/")||file.size>5*1024*1024)throw Error("Image invalide ou supérieure à 5 Mo.");const r=ref(storage,`avatars/${me.uid}/${Date.now()}`);await uploadBytes(r,file);photoURL=await getDownloadURL(r);}
 const name=$("profileName").value.trim();await updateDoc(doc(db,"users",me.uid),{name,nameLower:name.toLowerCase(),bio:$("profileBio").value.trim(),photoURL});me={...me,name,photoURL};toast("Profil mis à jour.");}catch(e){toast(friendlyError(e));}};
$("newChatBtn").onclick=()=>{document.querySelector('[data-page="people"]').click();$("userSearch").focus();};

// WebRTC: signalisation Firestore. Pour les réseaux restrictifs, configurez un serveur TURN privé.
const rtcConfig={iceServers:[{urls:"stun:stun.l.google.com:19302"}]};
async function beginCall(kind,incoming=false,callId=null){
 if(!activePeer&&!incoming){toast("Ouvrez d'abord une conversation.");return;}
 try{
  currentCall=callId?{id:callId}:null;
  $("callModal").classList.remove("hidden");$("callTitle").textContent=kind==="video"?"Appel vidéo":"Appel audio";$("callInfo").textContent=incoming?"Appel entrant…":"Appel en cours…";$("acceptCallBtn").classList.toggle("hidden",!incoming);
  if(incoming){const c=await getDoc(doc(db,"calls",callId));currentCall={id:callId,...c.data()};activePeer={uid:currentCall.from,name:currentCall.fromName};}
  localStream=await navigator.mediaDevices.getUserMedia({audio:true,video:kind==="video"});$("localVideo").srcObject=localStream;
  peerConnection=new RTCPeerConnection(rtcConfig);localStream.getTracks().forEach(t=>peerConnection.addTrack(t,localStream));
  peerConnection.ontrack=e=>{$("remoteVideo").srcObject=e.streams[0];};
  const callRef=currentCall?doc(db,"calls",currentCall.id):doc(collection(db,"calls"));
  if(!incoming){currentCall={id:callRef.id};await setDoc(callRef,{from:me.uid,fromName:me.name,to:activePeer.uid,kind,status:"ringing",createdAt:serverTimestamp()});}
  const candidates=collection(db,"calls",currentCall.id,incoming?"callerCandidates":"calleeCandidates");
  peerConnection.onicecandidate=e=>{if(e.candidate)addDoc(candidates,e.candidate.toJSON()).catch(()=>{});};
  if(!incoming){const offer=await peerConnection.createOffer();await peerConnection.setLocalDescription(offer);await updateDoc(callRef,{offer:{type:offer.type,sdp:offer.sdp}});
   onSnapshot(collection(db,"calls",currentCall.id,"calleeCandidates"),s=>s.docChanges().forEach(ch=>{if(ch.type==="added")peerConnection.addIceCandidate(new RTCIceCandidate(ch.doc.data())).catch(()=>{});}));
   stopCall=onSnapshot(callRef,s=>{const d=s.data();if(d?.answer&&!peerConnection.currentRemoteDescription)peerConnection.setRemoteDescription(new RTCSessionDescription(d.answer));if(d?.status==="ended")endCall(false);});
  }else{
   $("acceptCallBtn").onclick=async()=>{const c=await getDoc(callRef);await peerConnection.setRemoteDescription(new RTCSessionDescription(c.data().offer));const answer=await peerConnection.createAnswer();await peerConnection.setLocalDescription(answer);await updateDoc(callRef,{answer:{type:answer.type,sdp:answer.sdp},status:"accepted"});$("acceptCallBtn").classList.add("hidden");};
   onSnapshot(collection(db,"calls",currentCall.id,"callerCandidates"),s=>s.docChanges().forEach(ch=>{if(ch.type==="added")peerConnection.addIceCandidate(new RTCIceCandidate(ch.doc.data())).catch(()=>{});}));
  }
 }catch(e){toast("Appel impossible : "+e.message);endCall(false);}
}
$("audioCallBtn").onclick=()=>beginCall("audio");$("videoCallBtn").onclick=()=>beginCall("video");
async function endCall(update=true){if(update&&currentCall?.id)await updateDoc(doc(db,"calls",currentCall.id),{status:"ended"}).catch(()=>{});if(stopCall){stopCall();stopCall=null;}if(peerConnection){peerConnection.close();peerConnection=null;}if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null;}$("localVideo").srcObject=null;$("remoteVideo").srcObject=null;$("callModal").classList.add("hidden");currentCall=null;}
$("declineCallBtn").onclick=()=>endCall(true);
function listenCalls(){onSnapshot(query(collection(db,"calls"),where("to","==",me.uid),where("status","==","ringing"),limit(5)),snap=>snap.docChanges().forEach(async ch=>{if(ch.type==="added"){const c=ch.doc.data();if(!currentCall){const ok=confirm(`Appel ${c.kind==="video"?"vidéo":"audio"} entrant de ${c.fromName||"un membre CHAT"}. Accepter ?`);if(ok)beginCall(c.kind,true,ch.doc.id);else updateDoc(ch.doc.ref,{status:"declined"});}}}));}
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
if(!configured)console.info("CHAT: renseignez firebaseConfig dans public/app.js pour activer les services.");
