// مفكرة جني – خادم الذكاء الاصطناعي (Node 18+ بلا مكتبات خارجية)
// الخادم هو الوحيد الذي يحمل المفاتيح. التطبيق لا يرى أي مفتاح أبدًا.
//
// المتغيرات:
//   ANTHROPIC_API_KEY      (مطلوب للمحادثة)
//   OPENAI_API_KEY         (اختياري، للتفريغ الصوتي للتسجيلات فقط)
//   CLAUDE_MODEL           (افتراضي: claude-haiku-5-5)
//   ENABLE_WEB_SEARCH      (1 لتفعيل البحث في الإنترنت عبر أداة Claude)
//   WEB_SEARCH_MAX_USES    (افتراضي: 3)
//   ALLOWED_ORIGINS        (افتراضي: https://localhost,capacitor://localhost,http://localhost)
//   RATE_LIMIT_PER_MIN     (افتراضي: 30 طلبًا لكل عنوان IP في الدقيقة)
//   TRUST_PROXY            (1 إذا كان الخادم خلف وكيل مثل Render أو Nginx)
//   PORT                   (افتراضي: 8787)
//   ANTHROPIC_BASE_URL, OPENAI_BASE_URL, ANTHROPIC_VERSION  (للاختبار أو الإعدادات المتقدمة)

import http from "node:http";

const cfg = {
  port: Number(process.env.PORT || 8787),
  anthropicKey: process.env.ANTHROPIC_API_KEY || "",
  anthropicUrl: (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, ""),
  anthropicVersion: process.env.ANTHROPIC_VERSION || "2023-06-01",
  model: process.env.CLAUDE_MODEL || "claude-haiku-5-5",
  webSearch: process.env.ENABLE_WEB_SEARCH === "1",
  webSearchMaxUses: Number(process.env.WEB_SEARCH_MAX_USES || 3),
  openaiKey: process.env.OPENAI_API_KEY || "",
  openaiUrl: (process.env.OPENAI_BASE_URL || "https://api.openai.com").replace(/\/$/, ""),
  transcribeModel: process.env.TRANSCRIBE_MODEL || "whisper-1",
  allowedOrigins: (process.env.ALLOWED_ORIGINS || "https://localhost,capacitor://localhost,http://localhost")
    .split(",").map(s => s.trim()).filter(Boolean),
  rateLimit: Number(process.env.RATE_LIMIT_PER_MIN || 30),
  trustProxy: process.env.TRUST_PROXY === "1",
};

const MAX_BODY = 12 * 1024 * 1024;          // 12MB: صور وتسجيلات
const MAX_MESSAGES = 30;
const MAX_TEXT = 4000;
const MAX_IMAGE_B64 = 6_000_000;            // حجم الصورة بعد الترميز
const MAX_AUDIO_BYTES = 8 * 1024 * 1024;
const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const ANTHROPIC_TIMEOUT = 45_000;
const MAX_TOOL_ROUNDS = 3;

const SYSTEM_BASE = [
  "أنت جني، مساعد ذكي عربي يعمل داخل تطبيق «مفكرة جني».",
  "أجب بالعربية الواضحة والمختصرة ما لم يكتب المستخدم بلغة أخرى، واستخدم تنسيقًا بسيطًا (قوائم أو عناوين قصيرة) عند الحاجة.",
  "إذا أُرفقت صورة فصفها وأجب عن السؤال المتعلق بها، ولا تفترض ما لا يظهر فيها.",
  "لا تدّعِ أنك أضفت تذكيرًا أو مهمة أو ملاحظة إلى المفكرة، فهذه الأوامر تُنفَّذ محليًا في التطبيق، وإذا طلبها المستخدم فوجّهه إلى قولها بصيغة الأمر مثل «ذكرني بكذا بعد 10 دقائق».",
  "إذا كنت غير متأكد من معلومة حديثة فقل ذلك بوضوح.",
].join("\n");

// ---------- تحديد عدد الطلبات ----------
const hits = new Map();
function rateOk(ip) {
  const now = Date.now();
  const rec = hits.get(ip);
  if (!rec || now > rec.reset) { hits.set(ip, { count: 1, reset: now + 60_000 }); return true; }
  rec.count++;
  return rec.count <= cfg.rateLimit;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (now > v.reset) hits.delete(k); }, 60_000).unref();

// ---------- أدوات ----------
function corsHeaders(origin) {
  const h = { "Vary": "Origin", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, GET, OPTIONS", "Access-Control-Max-Age": "600" };
  if (origin && cfg.allowedOrigins.includes(origin)) h["Access-Control-Allow-Origin"] = origin;
  return h;
}
function send(res, status, body, origin) {
  res.writeHead(status, { ...corsHeaders(origin), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => {
      size += c.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error("too_large"), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}
const clip = (s, n) => String(s == null ? "" : s).slice(0, n);
const isB64 = s => typeof s === "string" && s.length > 0 && /^[A-Za-z0-9+/=\r\n]+$/.test(s);

// يحوّل الرسائل الواردة إلى شكل صالح لـ Anthropic: يبدأ بالمستخدم، ويتناوب الدور، وينتهي برسالة المستخدم
function buildMessages(input) {
  let list = Array.isArray(input.messages) ? input.messages : null;
  if (!list && typeof input.message === "string") list = [{ role: "user", content: input.message }];
  if (!list || list.length === 0) throw Object.assign(new Error("no_messages"), { status: 400 });
  if (list.length > MAX_MESSAGES) list = list.slice(-MAX_MESSAGES);

  const out = [];
  for (const m of list) {
    if (!m || (m.role !== "user" && m.role !== "assistant")) continue;
    const text = clip(m.content ?? m.text ?? "", MAX_TEXT);
    const blocks = [];
    if (m.role === "user" && m.image) {
      const img = m.image;
      if (!IMAGE_TYPES.has(img.mime) || !isB64(img.data) || img.data.length > MAX_IMAGE_B64) {
        throw Object.assign(new Error("bad_image"), { status: 400 });
      }
      blocks.push({ type: "image", source: { type: "base64", media_type: img.mime, data: img.data } });
    }
    if (text.trim()) blocks.push({ type: "text", text });
    if (blocks.length === 0) continue;
    const last = out[out.length - 1];
    if (last && last.role === m.role) {
      // دمج الرسائل المتتالية من الدور نفسه
      last.content = [...(Array.isArray(last.content) ? last.content : [{ type: "text", text: last.content }]), ...blocks];
    } else {
      out.push({ role: m.role, content: blocks.length === 1 && blocks[0].type === "text" ? blocks[0].text : blocks });
    }
  }
  while (out.length && out[0].role !== "user") out.shift();
  if (out.length === 0 || out[out.length - 1].role !== "user") throw Object.assign(new Error("no_user_message"), { status: 400 });
  return out;
}

// ---------- الدردشة مع Claude ----------
async function callClaude(messages, name, now) {
  const system = `${SYSTEM_BASE}\nالوقت الحالي: ${clip(now, 40) || new Date().toISOString()}. اسم المستخدم: ${clip(name, 60) || "غير معروف"}.`;
  const tools = cfg.webSearch ? [{ type: "web_search_20250305", name: "web_search", max_uses: cfg.webSearchMaxUses }] : undefined;
  let convo = messages;
  let content = [];

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const body = { model: cfg.model, max_tokens: 1024, system, messages: convo };
    if (tools) body.tools = tools;
    const res = await fetch(`${cfg.anthropicUrl}/v1/messages`, {
      method: "POST",
      headers: { "x-api-key": cfg.anthropicKey, "anthropic-version": cfg.anthropicVersion, "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(ANTHROPIC_TIMEOUT),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      console.error("upstream error", res.status, errText.slice(0, 300));
      throw Object.assign(new Error("upstream"), { status: res.status === 429 ? 429 : 502 });
    }
    const json = await res.json();
    content = json.content || [];
    if (json.stop_reason === "pause_turn" && round < MAX_TOOL_ROUNDS) {
      // استئناف الدورة: نعيد رسالة المساعد كما هي دون تعديل
      convo = [...convo, { role: "assistant", content }];
      continue;
    }
    break;
  }
  const text = content.filter(b => b.type === "text").map(b => b.text).join("").trim();
  // مصادر البحث في الإنترنت (إن وُجدت) تُضاف كروابط في آخر الرد
  const sources = [];
  for (const b of content) {
    if (b.type !== "web_search_tool_result" || !Array.isArray(b.content)) continue;
    for (const r of b.content) {
      if (r && /^https?:\/\//.test(r.url) && !sources.includes(r.url)) sources.push(r.url);
    }
  }
  const body = text || "لم أتمكن من توليد رد. حاول بصياغة أخرى.";
  return sources.length ? body + "\n\nالمصادر:\n" + sources.slice(0, 5).map(u => "• " + u).join("\n") : body;
}

// ---------- التفريغ الصوتي (OpenAI، اختياري) ----------
async function transcribe(audioB64, mime, language) {
  if (!cfg.openaiKey) throw Object.assign(new Error("transcription_unavailable"), { status: 501 });
  if (!isB64(audioB64)) throw Object.assign(new Error("bad_audio"), { status: 400 });
  const buf = Buffer.from(audioB64, "base64");
  if (buf.length === 0 || buf.length > MAX_AUDIO_BYTES) throw Object.assign(new Error("bad_audio"), { status: 400 });
  const m = String(mime || "").toLowerCase();
  const ext = m.includes("ogg") ? "ogg" : m.includes("mp4") || m.includes("m4a") || m.includes("aac") ? "m4a"
    : m.includes("wav") ? "wav" : m.includes("mpeg") || m.includes("mp3") ? "mp3" : "webm";
  const fd = new FormData();
  fd.append("file", new Blob([buf], { type: mime || "audio/webm" }), "audio." + ext);
  fd.append("model", cfg.transcribeModel);
  fd.append("language", /^[a-z]{2}$/.test(language || "") ? language : "ar");
  const res = await fetch(`${cfg.openaiUrl}/v1/audio/transcriptions`, {
    method: "POST", headers: { Authorization: "Bearer " + cfg.openaiKey }, body: fd,
    signal: AbortSignal.timeout(60_000),
  });
  if (!res.ok) { console.error("transcribe upstream", res.status); throw Object.assign(new Error("upstream"), { status: 502 }); }
  const json = await res.json();
  return String(json.text || "").trim();
}

// ---------- الخادم ----------
const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (req.method === "OPTIONS") { res.writeHead(204, corsHeaders(origin)); return res.end(); }
  if (req.method === "GET" && req.url === "/health") {
    return send(res, 200, { ok: true, model: cfg.model, chat: !!cfg.anthropicKey, webSearch: cfg.webSearch, transcription: !!cfg.openaiKey }, origin);
  }
  if (req.method !== "POST") return send(res, 405, { error: "method_not_allowed" }, origin);

  const ip = (cfg.trustProxy && String(req.headers["x-forwarded-for"] || "").split(",")[0].trim()) || req.socket.remoteAddress || "unknown";
  if (!rateOk(ip)) return send(res, 429, { error: "rate_limited" }, origin);

  try {
    const input = JSON.parse(await readBody(req) || "{}");
    const action = input.action || "chat";

    if (action === "chat") {
      if (!cfg.anthropicKey) return send(res, 503, { error: "not_configured" }, origin);
      const messages = buildMessages(input);
      const reply = await callClaude(messages, input.name, input.now);
      return send(res, 200, { reply }, origin);
    }
    if (action === "transcribe") {
      const text = await transcribe(input.audio, input.mime, input.language);
      return send(res, 200, { text }, origin);
    }
    return send(res, 400, { error: "unknown_action" }, origin);
  } catch (e) {
    if (e instanceof SyntaxError) return send(res, 400, { error: "bad_json" }, origin);
    const status = e.status || (e.name === "TimeoutError" ? 504 : 500);
    if (status === 500) console.error("server error", e.name);
    return send(res, status, { error: e.message || "server_error" }, origin);
  }
});

// الاستيراد من الاختبار يعطّل بدء الاستماع
if (process.env.JANNI_NO_LISTEN !== "1") {
  server.listen(cfg.port, () => console.log(`Janni AI server on :${cfg.port} (model ${cfg.model})`));
}

export { server, buildMessages };
