// اختبار دخان للخادم مع مزوّد وهمي (لا يحتاج مفاتيح حقيقية ولا إنترنت)
// التشغيل: node server/test/smoke.mjs
import http from "node:http";
import assert from "node:assert/strict";

const seen = { anthropic: [], openai: [] };
let anthropicMode = "ok";

const fake = http.createServer(async (req, res) => {
  let body = ""; for await (const c of req) body += c;
  const j = (s, o) => { res.writeHead(s, { "content-type": "application/json" }); res.end(JSON.stringify(o)); };
  if (req.url === "/v1/messages") {
    seen.anthropic.push({ headers: req.headers, body: JSON.parse(body) });
    if (anthropicMode === "down") return j(500, { error: "boom" });
    if (anthropicMode === "search") return j(200, { content: [
      { type: "server_tool_use", id: "s1", name: "web_search", input: { query: "q" } },
      { type: "web_search_tool_result", tool_use_id: "s1", content: [{ type: "web_search_result", url: "https://example.org/a", title: "A" }, { type: "web_search_result", url: "https://example.org/a", title: "A" }] },
      { type: "text", text: "الجواب من الإنترنت" }], stop_reason: "end_turn" });
    if (anthropicMode === "pause") {
      const first = seen.anthropic.length === 1;
      return j(200, first
        ? { content: [{ type: "text", text: "أبحث..." }], stop_reason: "pause_turn" }
        : { content: [{ type: "text", text: "الخلاصة: " }, { type: "text", text: "يوم جميل" }], stop_reason: "end_turn" });
    }
    return j(200, { content: [{ type: "text", text: "رد تجريبي" }], stop_reason: "end_turn" });
  }
  if (req.url === "/v1/audio/transcriptions") {
    seen.openai.push({ auth: req.headers.authorization, size: body.length });
    return j(200, { text: "نص مفرّغ" });
  }
  j(404, {});
});
await new Promise(r => fake.listen(0, r));
const up = `http://127.0.0.1:${fake.address().port}`;

process.env.JANNI_NO_LISTEN = "1";
process.env.ANTHROPIC_API_KEY = "sk-test-SECRET";
process.env.OPENAI_API_KEY = "sk-oa-SECRET";
process.env.ANTHROPIC_BASE_URL = up;
process.env.OPENAI_BASE_URL = up;
process.env.RATE_LIMIT_PER_MIN = "100";
process.env.ENABLE_WEB_SEARCH = "1";
const { server } = await import("../server.js");
await new Promise(r => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;
const origin = "https://localhost";

const post = (obj, extra = {}) => fetch(base + "/", {
  method: "POST", headers: { "content-type": "application/json", origin, ...extra }, body: JSON.stringify(obj),
});

let passed = 0;
const t = async (name, fn) => { try { await fn(); passed++; console.log("PASS", name); } catch (e) { console.log("FAIL", name, "-", e.message); process.exitCode = 1; } };

await t("T1 health reports configuration without exposing keys", async () => {
  const r = await fetch(base + "/health", { headers: { origin } });
  const j = await r.json();
  assert.equal(j.chat, true); assert.equal(j.transcription, true); assert.equal(j.webSearch, true);
  assert.ok(!JSON.stringify(j).includes("SECRET"));
});

await t("T2 chat sends history, system prompt, key only server-side, and returns reply", async () => {
  seen.anthropic.length = 0; anthropicMode = "ok";
  const r = await post({ action: "chat", name: "أبا يزيد", now: "2026-11-12T10:00:00Z",
    messages: [{ role: "user", content: "مرحبا" }, { role: "assistant", content: "أهلًا" }, { role: "user", content: "ما عاصمة السودان؟" }] });
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.reply, "رد تجريبي");
  const sent = seen.anthropic[0];
  assert.equal(sent.headers["x-api-key"], "sk-test-SECRET");
  assert.equal(sent.body.messages.length, 3);
  assert.equal(sent.body.model, "claude-haiku-5-5");
  assert.equal(sent.body.tools[0].type, "web_search_20250305");
  assert.equal(sent.body.tools[0].max_uses, 3);
  assert.match(sent.body.system, /أبا يزيد/);
  assert.equal(r.headers.get("access-control-allow-origin"), origin);
});

await t("T3 image block is forwarded for user turns only", async () => {
  seen.anthropic.length = 0;
  const r = await post({ action: "chat", messages: [{ role: "user", content: "ما هذا؟", image: { mime: "image/jpeg", data: "/9j/AA==" } }] });
  assert.equal(r.status, 200);
  const blk = seen.anthropic[0].body.messages[0].content;
  assert.equal(blk[0].type, "image"); assert.equal(blk[0].source.media_type, "image/jpeg");
  assert.equal(blk[1].text, "ما هذا؟");
});

await t("T4 bad image type and bad base64 are rejected", async () => {
  let r = await post({ action: "chat", messages: [{ role: "user", content: "x", image: { mime: "text/html", data: "AAAA" } }] });
  assert.equal(r.status, 400);
  r = await post({ action: "chat", messages: [{ role: "user", content: "x", image: { mime: "image/png", data: "<script>" } }] });
  assert.equal(r.status, 400);
});

await t("T5 conversation must end with a user message; leading assistant turns dropped", async () => {
  let r = await post({ action: "chat", messages: [{ role: "assistant", content: "x" }] });
  assert.equal(r.status, 400);
  seen.anthropic.length = 0;
  r = await post({ action: "chat", messages: [{ role: "assistant", content: "زائد" }, { role: "user", content: "a" }, { role: "user", content: "b" }] });
  assert.equal(r.status, 200);
  const msgs = seen.anthropic[0].body.messages;
  assert.equal(msgs[0].role, "user");
  assert.equal(msgs.length, 1);
});

await t("T6 pause_turn is continued and text blocks are joined", async () => {
  seen.anthropic.length = 0; anthropicMode = "pause";
  const r = await post({ action: "chat", messages: [{ role: "user", content: "ابحث" }] });
  const j = await r.json();
  anthropicMode = "ok";
  assert.equal(seen.anthropic.length, 2);
  assert.equal(seen.anthropic[1].body.messages.at(-1).role, "assistant");
  assert.equal(j.reply, "الخلاصة: يوم جميل");
});

await t("T7 upstream failure returns 502 without leaking details", async () => {
  anthropicMode = "down";
  const r = await post({ action: "chat", messages: [{ role: "user", content: "x" }] });
  anthropicMode = "ok";
  const txt = await r.text();
  assert.equal(r.status, 502);
  assert.ok(!txt.includes("boom") && !txt.includes("SECRET"));
});

await t("T8 transcription forwards audio with server-side key", async () => {
  const r = await post({ action: "transcribe", audio: Buffer.from("fake-audio").toString("base64"), mime: "audio/webm", language: "ar" });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).text, "نص مفرّغ");
  assert.equal(seen.openai.at(-1).auth, "Bearer sk-oa-SECRET");
});

await t("T9 non-https origins get no CORS allow header", async () => {
  const r = await fetch(base + "/health", { headers: { origin: "https://evil.example" } });
  assert.equal(r.headers.get("access-control-allow-origin"), null);
});

await t("T10 unknown action and malformed JSON are rejected", async () => {
  let r = await post({ action: "delete_everything" });
  assert.equal(r.status, 400);
  r = await fetch(base + "/", { method: "POST", headers: { "content-type": "application/json" }, body: "{bad" });
  assert.equal(r.status, 400);
});

await t("T12 web search sources are appended as links, once each", async () => {
  anthropicMode = "search";
  const r = await post({ action: "chat", message: "ما أخبار اليوم؟" });
  anthropicMode = "ok";
  const j = await r.json();
  assert.ok(j.reply.startsWith("الجواب من الإنترنت"));
  assert.ok(j.reply.includes("المصادر:\n• https://example.org/a"));
  assert.equal(j.reply.split("https://example.org/a").length - 1, 1);
});

await t("T11 rate limit is enforced (separate process, limit=2)", async () => {
  const { spawn } = await import("node:child_process");
  const port = 18700 + Math.floor(Math.random() * 200);
  const child = spawn(process.execPath, ["server/server.js"], {
    env: { ...process.env, JANNI_NO_LISTEN: "0", PORT: String(port), RATE_LIMIT_PER_MIN: "2", ANTHROPIC_API_KEY: "k", ANTHROPIC_BASE_URL: up },
    stdio: ["ignore", "pipe", "pipe"],
  });
  try {
    await new Promise((res, rej) => { child.stdout.on("data", d => String(d).includes("listening") || String(d).includes("Janni") ? res() : null); child.on("error", rej); setTimeout(res, 1500); });
    const statuses = [];
    for (let i = 0; i < 3; i++) {
      const r = await fetch(`http://127.0.0.1:${port}/`, { method: "POST", headers: { "content-type": "application/json", origin }, body: JSON.stringify({ action: "chat", message: "hi" }) });
      statuses.push(r.status);
    }
    assert.deepEqual(statuses, [200, 200, 429]);
  } finally { child.kill(); }
});

server.close(); fake.close();
console.log(`\n${passed} tests passed` + (process.exitCode ? " (with failures)" : ""));
