بناء ملف APK (يحتاج Node.js و Android Studio):

1) افتح الطرفية داخل هذا المجلد ونفّذ:
   npm install
   npx cap add android
   npx cap sync android

2) الطريقة الأسهل: npx cap open android
   ثم من Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

3) أو من سطر الأوامر:
   cd android
   ./gradlew assembleDebug      (على ويندوز: gradlew.bat assembleDebug)
   الملف: android/app/build/outputs/apk/debug/app-debug.apk

4) انقل app-debug.apk للموبايل وثبّته (فعّل "التثبيت من مصادر غير معروفة").

لتعديل البرنامج: عدّل www/index.html ثم npx cap sync android وأعد البناء.
