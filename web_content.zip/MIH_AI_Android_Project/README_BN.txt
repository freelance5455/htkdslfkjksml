MIH.AI — TEXT INPUT + SPOKEN ANSWERS (NO MICROPHONE)

This is a native Android WebView project. The microphone UI and microphone permission have been removed.
The user types a question; MIH.AI displays the answer and uses Android/WebView Text-to-Speech to speak it.
The animated AI core changes to its speaking animation only while speech is playing.

Permissions:
- INTERNET only (normal Android permission, no runtime prompt), needed only for a deployed HTTPS AI backend.
- No microphone, camera, location, contacts, or animation permission. Android has no special permission for CSS/UI animation.

IMPORTANT:
- API_BASE_URL in app/src/main/assets/index.html is blank. Set it to your deployed HTTPS backend URL to enable general AI answers.
- Text-to-Speech uses the device speech engine and may require an installed language voice pack.
- This ZIP is project source, not a prebuilt APK. It requires a compatible Android Gradle build environment.
