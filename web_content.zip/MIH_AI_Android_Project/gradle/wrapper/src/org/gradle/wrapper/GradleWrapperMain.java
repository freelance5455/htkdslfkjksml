package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Small bootstrap launcher for environments that require GradleWrapperMain.
 * It reads the standard wrapper properties, downloads the declared Gradle
 * distribution when absent, then delegates all arguments to that Gradle binary.
 */
public final class GradleWrapperMain {
  public static void main(String[] args) throws Exception {
    Path project = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
    Path props = project.resolve("gradle/wrapper/gradle-wrapper.properties");
    if (!Files.exists(props)) throw new FileNotFoundException("Missing " + props);
    Properties p = new Properties();
    try (InputStream in = Files.newInputStream(props)) { p.load(in); }
    String url = p.getProperty("distributionUrl");
    if (url == null || url.isBlank()) throw new IllegalStateException("distributionUrl is missing");
    url = url.replace("\\:", ":");
    String file = url.substring(url.lastIndexOf('/') + 1);
    String base = file.replaceFirst("-(bin|all)\\.zip$", "");
    String home = System.getenv("GRADLE_USER_HOME");
    Path gradleHome = (home == null || home.isBlank())
      ? Paths.get(System.getProperty("user.home"), ".gradle") : Paths.get(home);
    Path distRoot = gradleHome.resolve("wrapper/dists").resolve(base).resolve("mihai-bootstrap");
    Path gradleDir = distRoot.resolve(base);
    Path executable = gradleDir.resolve("bin/gradle");
    if (!Files.isExecutable(executable)) {
      Files.createDirectories(distRoot);
      Path zip = distRoot.resolve(file);
      System.out.println("Downloading Gradle distribution: " + url);
      URLConnection conn = new URL(url).openConnection();
      conn.setConnectTimeout(30000); conn.setReadTimeout(120000);
      try (InputStream in = conn.getInputStream(); OutputStream out = Files.newOutputStream(zip)) {
        byte[] b = new byte[65536]; int n;
        while ((n = in.read(b)) >= 0) out.write(b, 0, n);
      }
      try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
        ZipEntry e;
        while ((e = zin.getNextEntry()) != null) {
          Path target = distRoot.resolve(e.getName()).normalize();
          if (!target.startsWith(distRoot)) throw new IOException("Invalid distribution archive path");
          if (e.isDirectory()) Files.createDirectories(target);
          else {
            Files.createDirectories(target.getParent());
            try (OutputStream out = Files.newOutputStream(target)) { zin.transferTo(out); }
          }
          zin.closeEntry();
        }
      }
      Files.deleteIfExists(zip);
      if (!Files.isRegularFile(executable)) throw new IOException("Gradle distribution did not contain " + executable);
      executable.toFile().setExecutable(true);
    }
    List<String> command = new ArrayList<>();
    command.add(executable.toString());
    command.addAll(Arrays.asList(args));
    ProcessBuilder pb = new ProcessBuilder(command).directory(project.toFile()).inheritIO();
    pb.environment().put("MIH_AI_PROJECT_ROOT", project.toString());
    int code = pb.start().waitFor();
    if (code != 0) System.exit(code);
  }
}
