@echo off
set APP_HOME=%~dp0
pushd "%APP_HOME%"
if exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  set BUILD_EXIT=%ERRORLEVEL%
  popd
  exit /b %BUILD_EXIT%
) else (
  echo Gradle wrapper JAR is not bundled. Use an online builder that restores wrapper files.
  popd
  exit /b 1
)
