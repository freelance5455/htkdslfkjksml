package com.example.myapp;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings;
public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings(); s.setJavaScriptEnabled(true); s.setAllowFileAccess(true); s.setDomStorageEnabled(true);
        wv.loadUrl("file:///android_asset/index.html");
        setContentView(wv);
    }
}