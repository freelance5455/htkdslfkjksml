package com.example.neura; // apna package name yahan set karein (build.gradle se match karna chahie)

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);          // app ka JS (chat, theme toggle, tabs) chalane ke liye zaroori
        settings.setDomStorageEnabled(true);           // localStorage (theme save karne ke liye) ke liye zaroori
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // sirf app ke andar hi khule, koi bahar browser na khule
        webView.setWebViewClient(new WebViewClient());

        // assets/neura-index.html se file load ho rahi hai
        webView.loadUrl("file:///android_asset/neura-index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
