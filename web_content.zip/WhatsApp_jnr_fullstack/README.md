# WhatsApp jnr — Full-stack starter

A responsive, dark-themed, one-to-one messaging website built with HTML, CSS, JavaScript and Supabase.

**This is a full-stack project starter, not a deployed public service.** It becomes a real multi-user app after you create a Supabase project, run the SQL, add your project URL/key, and host the frontend. Users can then create accounts and exchange live messages.

> Independent learning project. Not affiliated with WhatsApp or Meta. Do not use WhatsApp branding or imply official affiliation when publishing.

## Included

- Email + password registration and login using Supabase Auth
- Profile creation and display-name editing
- Search for other registered members by display name
- Private one-to-one text messages
- Realtime incoming messages using Supabase Realtime
- Database Row Level Security (RLS) policies
- Responsive mobile and desktop layout
- Original SVG brand logo and favicon
- Animated startup splash screen
- Animated loading indicators for startup and login
- Separate HTML, CSS, JavaScript, SQL and configuration files

## 1. Create a Supabase project

1. Visit https://supabase.com and create an account/project.
2. Save your database password somewhere private.
3. Open **Project Settings → API** (or API Keys).
4. Copy the **Project URL** and the **anon / publishable public key**.
5. Open `js/config.js` and replace the two placeholder values.

Only use the anon/publishable key in this browser app. **Never paste a `service_role` key or secret key into `config.js`, HTML, JavaScript, a public repository, or a ZIP shared with others.**

## 2. Create the database

1. In your Supabase project, open **SQL Editor**.
2. Choose **New query**.
3. Open this project's `sql/schema.sql`, copy all its contents and paste them into the editor.
4. Click **Run**.
5. Check **Database → Publications** and confirm `messages` is included in `supabase_realtime` if Realtime events do not arrive.

The SQL creates `profiles` and `messages`, indexes, access policies and Realtime publication membership. RLS is essential: it limits message reads to the sender and recipient, and prevents users from sending messages as someone else.

## 3. Configure authentication

1. In Supabase, open **Authentication → URL Configuration**.
2. For local testing, add your local app URL to the allowed redirect URLs if Supabase asks for it.
3. For a deployed site, set the Site URL and add the exact deployed URL to Redirect URLs.
4. In **Authentication → Providers → Email**, decide whether to require email confirmation. Keeping confirmation enabled is recommended. Configure email delivery before expecting confirmation emails to arrive reliably.

## 4. Run the website locally

Do not open `index.html` by double-clicking it; JavaScript modules work best through a local web server.

If Python is installed:
```bash
python -m http.server 8000
```
Run that command from the project folder, then open:
`http://localhost:8000`

Alternatively, use VS Code with the Live Server extension. Keep the terminal/server running while testing.

## 5. Test real messaging

1. Open the site in two separate browser profiles/devices.
2. Create two different accounts (use email addresses you control).
3. If email confirmation is enabled, confirm both accounts.
4. Log in to each account.
5. In one account, choose **Find people**, search for the other account's display name, and select **Message**.
6. Send a message. It should appear in the other signed-in account through Supabase Realtime.

A single account cannot test a conversation with itself.

## 6. Publish it

You can host this static frontend on a service such as Netlify, Vercel or Cloudflare Pages. Upload the project folder (or connect a private Git repository), then set the deployed URL in Supabase Authentication URL Configuration.

Before publishing:
- Test with two accounts and two browsers/devices.
- Confirm the RLS policies are enabled and working.
- Never expose secret/service-role credentials.
- Use a trusted adult's help for hosting accounts, billing, domain purchases or other services that require an adult account.
- Add a privacy notice and a way for users to report abuse before inviting people to use it.

## Project structure

```text
WhatsApp_jnr_fullstack/
├── index.html
├── README.md
├── assets/
│   ├── favicon.svg
│   ├── logo.svg
│   └── splash.svg
├── css/
│   ├── style.css
│   └── responsive.css
├── js/
│   ├── app.js
│   └── config.js
└── sql/
    └── schema.sql
```

## Current limits

This starter includes live one-to-one **text** messaging. It does not yet include group chats, file/photo uploads, voice notes, push notifications, end-to-end encryption, message deletion, blocking/reporting or moderation tools. Supabase stores messages in the database; this starter does not claim end-to-end encryption. Add and security-test those features before treating the site as a public production messaging service.

## Troubleshooting

- **“Setup needed”**: check `js/config.js` for the correct Project URL and anon/publishable key.
- **Invalid API key**: make sure you copied the anon/publishable key, not a secret/service-role key.
- **No profile or people found**: make sure the SQL ran successfully and that at least two users have signed up.
- **Messages do not appear live**: confirm `messages` is in the `supabase_realtime` publication and check browser console errors.
- **Email confirmation missing**: check spam and configure Supabase email delivery / SMTP settings.
- **RLS error**: rerun `sql/schema.sql` and check policies under Database → Tables.
