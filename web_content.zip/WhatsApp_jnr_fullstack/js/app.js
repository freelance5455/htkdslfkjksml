import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./config.js";

const $ = (id) => document.getElementById(id);
const supabaseReady = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_URL.includes("YOUR_PROJECT_ID") &&
  SUPABASE_ANON_KEY.length > 30 &&
  !SUPABASE_ANON_KEY.includes("YOUR_SUPABASE");

const state = { user: null, profile: null, mode: "login", contacts: [], selected: null, messages: [], messageChannel: null, listChannel: null, searchTimer: null };
let toastTimer;

function toast(message, error = false) {
  const el = $("toast"); el.textContent = message; el.classList.toggle("error", error); el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
}
function initials(name = "?") { return name.trim().split(/\s+/).slice(0,2).map(p => p[0] || "").join("").toUpperCase() || "?"; }
function escapeHTML(value = "") { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function formatTime(value) { return new Intl.DateTimeFormat([], {hour:"2-digit",minute:"2-digit"}).format(new Date(value)); }
function requireConfig() {
  if (!supabaseReady) { toast("Add your Supabase URL and anon key in js/config.js first.", true); return false; }
  return true;
}
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});

function setAuthMode(mode) {
  state.mode = mode;
  $("loginTab").classList.toggle("active", mode === "login");
  $("signupTab").classList.toggle("active", mode === "signup");
  $("nameField").classList.toggle("hidden", mode !== "signup");
  $("displayName").required = mode === "signup";
  $("authSubmit").textContent = mode === "login" ? "Log in" : "Create account";
  $("authHint").textContent = mode === "login" ? "Use your account email and password." : "A confirmation email may be sent before you can log in.";
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
}
$("loginTab").addEventListener("click", () => setAuthMode("login"));
$("signupTab").addEventListener("click", () => setAuthMode("signup"));

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault(); if (!requireConfig()) return;
  const email = $("email").value.trim().toLowerCase(), password = $("password").value;
  $("authSubmit").disabled = true;
  $("authSubmit").querySelector(".button-spinner")?.classList.remove("hidden");
  try {
    if (state.mode === "signup") {
      const display_name = $("displayName").value.trim();
      if (display_name.length < 2) throw new Error("Please enter a display name with at least 2 characters.");
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name } } });
      if (error) throw error;
      if (!data.session) toast("Account created. Check your email to confirm, then log in.");
      else toast("Account created successfully.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
    }
  } catch (error) { toast(error.message || "Authentication failed.", true); }
  finally {
    $("authSubmit").disabled = false;
    $("authSubmit").querySelector(".button-spinner")?.classList.add("hidden");
  }
});

async function loadProfile() {
  const { data, error } = await supabase.from("profiles").select("id, display_name").eq("id", state.user.id).maybeSingle();
  if (error) throw error;
  if (!data) {
    const name = state.user.user_metadata?.display_name || state.user.email.split("@")[0];
    const { data: created, error: insertError } = await supabase.from("profiles").insert({id:state.user.id, display_name:name}).select().single();
    if (insertError) throw insertError;
    state.profile = created;
  } else state.profile = data;
  $("myName").textContent = state.profile.display_name;
  $("myEmail").textContent = state.user.email;
  $("myAvatar").textContent = initials(state.profile.display_name);
  $("profileName").value = state.profile.display_name;
}

async function enterApp(user) {
  state.user = user;
  $("authView").classList.add("hidden"); $("chatView").classList.remove("hidden");
  try {
    await loadProfile();
    await loadConversations();
    subscribeToInbox();
  } catch (error) { toast(error.message || "Could not load your profile.", true); }
}
function leaveApp() {
  if (state.messageChannel) supabase.removeChannel(state.messageChannel);
  if (state.listChannel) supabase.removeChannel(state.listChannel);
  state.user = null; state.profile = null; state.selected = null; state.contacts = [];
  $("chatView").classList.add("hidden"); $("chatView").classList.remove("mobile-chat");
  $("authView").classList.remove("hidden"); $("activeChat").classList.add("hidden"); $("welcomePanel").classList.remove("hidden");
}
let enteringUserId = null;
supabase.auth.onAuthStateChange((event, session) => {
  if (session?.user) {
    if (!state.user && enteringUserId !== session.user.id) {
      enteringUserId = session.user.id;
      setTimeout(async () => {
        try { await enterApp(session.user); }
        finally { enteringUserId = null; }
      }, 0);
    }
  } else if (state.user) {
    leaveApp();
  }
});

async function loadConversations() {
  // RLS ensures a user can only read messages where they are sender or recipient.
  const { data, error } = await supabase.from("messages")
    .select("id, sender_id, recipient_id, body, created_at")
    .or(`sender_id.eq.${state.user.id},recipient_id.eq.${state.user.id}`)
    .order("created_at", {ascending:false}).limit(500);
  if (error) throw error;
  const latestByPeer = new Map();
  for (const msg of data || []) {
    const peerId = msg.sender_id === state.user.id ? msg.recipient_id : msg.sender_id;
    if (!latestByPeer.has(peerId)) latestByPeer.set(peerId, msg);
  }
  const peerIds = [...latestByPeer.keys()];
  let profiles = [];
  if (peerIds.length) {
    const result = await supabase.from("profiles").select("id, display_name").in("id", peerIds);
    if (result.error) throw result.error;
    profiles = result.data || [];
  }
  state.contacts = profiles.map(profile => ({...profile, lastMessage:latestByPeer.get(profile.id)}))
    .sort((a,b) => new Date(b.lastMessage.created_at)-new Date(a.lastMessage.created_at));
  renderConversations();
}
function renderConversations() {
  const query = $("chatSearch").value.trim().toLowerCase();
  const list = state.contacts.filter(c => c.display_name.toLowerCase().includes(query));
  $("chatCount").textContent = String(state.contacts.length);
  $("conversationList").innerHTML = list.length ? list.map(c => {
    const last = c.lastMessage;
    const preview = last.sender_id === state.user.id ? `You: ${last.body}` : last.body;
    return `<button class="conversation-item ${state.selected?.id===c.id?"selected":""}" data-peer="${c.id}">
      <div class="avatar">${escapeHTML(initials(c.display_name))}</div>
      <div class="conversation-meta"><div class="conversation-top"><strong>${escapeHTML(c.display_name)}</strong><time>${formatTime(last.created_at)}</time></div>
      <div class="conversation-bottom"><small>${escapeHTML(preview)}</small></div></div></button>`;
  }).join("") : `<div class="empty-list">${query ? "No matching conversations." : "No conversations yet. Find someone to say hello."}</div>`;
  $("conversationList").querySelectorAll("[data-peer]").forEach(btn => btn.addEventListener("click", () => {
    const contact = state.contacts.find(c => c.id === btn.dataset.peer); if (contact) openChat(contact);
  }));
}
$("chatSearch").addEventListener("input", renderConversations);

async function openChat(peer) {
  state.selected = peer;
  $("welcomePanel").classList.add("hidden"); $("activeChat").classList.remove("hidden");
  $("peerName").textContent = peer.display_name; $("peerAvatar").textContent = initials(peer.display_name);
  $("peerStatus").textContent = "Direct message";
  $("chatView").classList.add("mobile-chat");
  renderConversations();
  await loadMessages();
  subscribeToMessages();
  $("messageInput").focus();
}
async function loadMessages() {
  if (!state.selected) return;
  const peerId = state.selected.id;
  const { data, error } = await supabase.from("messages").select("id,sender_id,recipient_id,body,created_at")
    .or(`and(sender_id.eq.${state.user.id},recipient_id.eq.${peerId}),and(sender_id.eq.${peerId},recipient_id.eq.${state.user.id})`)
    .order("created_at", {ascending:true}).limit(300);
  if (error) { toast(error.message, true); return; }
  state.messages = data || []; renderMessages();
}
function renderMessages() {
  const list = $("messageList");
  if (!state.messages.length) { list.innerHTML = '<div class="message-placeholder">Say hello to start the conversation.</div>'; return; }
  list.innerHTML = state.messages.map(msg => {
    const mine = msg.sender_id === state.user.id;
    return `<div class="message-row ${mine?"mine":""}"><div class="message-bubble">${escapeHTML(msg.body)}</div><time class="message-time">${formatTime(msg.created_at)}</time></div>`;
  }).join("");
  list.scrollTop = list.scrollHeight;
}
function subscribeToMessages() {
  if (state.messageChannel) supabase.removeChannel(state.messageChannel);
  if (!state.selected) return;
  const peerId = state.selected.id;
  state.messageChannel = supabase.channel(`messages-${state.user.id}-${peerId}`)
    .on("postgres_changes", {event:"INSERT", schema:"public", table:"messages"}, payload => {
      const msg = payload.new;
      const belongs = (msg.sender_id===state.user.id && msg.recipient_id===peerId) ||
        (msg.sender_id===peerId && msg.recipient_id===state.user.id);
      if (belongs && !state.messages.some(m => m.id===msg.id)) {
        state.messages.push(msg); state.messages.sort((a,b)=>new Date(a.created_at)-new Date(b.created_at)); renderMessages();
        loadConversations().catch(e=>toast(e.message,true));
      }
    }).subscribe();
}
function subscribeToInbox() {
  if (state.listChannel) supabase.removeChannel(state.listChannel);
  state.listChannel = supabase.channel(`inbox-${state.user.id}`)
    .on("postgres_changes", {event:"INSERT", schema:"public", table:"messages"}, payload => {
      const m=payload.new;
      if (m.sender_id===state.user.id || m.recipient_id===state.user.id) loadConversations().catch(e=>toast(e.message,true));
    }).subscribe();
}
$("messageForm").addEventListener("submit", async event => {
  event.preventDefault();
  const body=$("messageInput").value.trim(); if (!body || !state.selected) return;
  if (body.length>4000) return toast("Message is too long.",true);
  $("messageInput").disabled=true;
  try {
    const {data,error}=await supabase.from("messages").insert({sender_id:state.user.id,recipient_id:state.selected.id,body}).select().single();
    if(error) throw error;
    if(!state.messages.some(m=>m.id===data.id)){state.messages.push(data);renderMessages();}
    $("messageInput").value="";
    await loadConversations();
  } catch(error){toast(error.message||"Message could not be sent.",true);}
  finally{$("messageInput").disabled=false;$("messageInput").focus();}
});

function openModal(id){$(id).classList.remove("hidden");}
function closeModal(id){$(id).classList.add("hidden");}
document.querySelectorAll("[data-close]").forEach(btn=>btn.addEventListener("click",()=>closeModal(btn.dataset.close)));
$("newChatBtn").addEventListener("click",()=>{openModal("peopleModal");$("peopleSearch").focus();});
$("findPeopleWelcome").addEventListener("click",()=>{openModal("peopleModal");$("peopleSearch").focus();});
$("profileBtn").addEventListener("click",()=>openModal("profileModal"));
$("backBtn").addEventListener("click",()=>{$("chatView").classList.remove("mobile-chat");});
$("chatInfoBtn").addEventListener("click",()=>toast("Direct, private conversation."));
$("peopleSearch").addEventListener("input",()=>{
  clearTimeout(state.searchTimer);
  state.searchTimer=setTimeout(searchPeople,350);
});
async function searchPeople(){
  const q=$("peopleSearch").value.trim();
  if(q.length<2){$("peopleResults").innerHTML='<p class="muted">Enter at least 2 characters to search.</p>';return;}
  const {data,error}=await supabase.from("profiles").select("id,display_name").ilike("display_name",`%${q}%`).neq("id",state.user.id).limit(20);
  if(error){$("peopleResults").innerHTML=`<p class="muted">${escapeHTML(error.message)}</p>`;return;}
  if(!data.length){$("peopleResults").innerHTML='<p class="muted">No people found. Ask them to create an account first.</p>';return;}
  $("peopleResults").innerHTML=data.map(p=>`<div class="person-result"><div class="avatar">${escapeHTML(initials(p.display_name))}</div><div class="person-copy"><strong>${escapeHTML(p.display_name)}</strong><small>WhatsApp jnr member</small></div><button data-start="${p.id}">Message</button></div>`).join("");
  $("peopleResults").querySelectorAll("[data-start]").forEach(btn=>btn.addEventListener("click",async()=>{
    const peer=data.find(p=>p.id===btn.dataset.start);closeModal("peopleModal");
    // Create an initial conversation by opening the chat; no empty database row is needed.
    const existing=state.contacts.find(c=>c.id===peer.id);
    await openChat(existing||{...peer,lastMessage:{created_at:new Date().toISOString(),body:"",sender_id:peer.id}});
  }));
}
$("profileForm").addEventListener("submit",async event=>{
  event.preventDefault();const display_name=$("profileName").value.trim();
  if(display_name.length<2)return toast("Name must have at least 2 characters.",true);
  const {data,error}=await supabase.from("profiles").update({display_name}).eq("id",state.user.id).select().single();
  if(error)return toast(error.message,true);
  state.profile=data;$("myName").textContent=data.display_name;$("myAvatar").textContent=initials(data.display_name);closeModal("profileModal");toast("Profile updated.");
});
$("signOutBtn").addEventListener("click",async()=>{const {error}=await supabase.auth.signOut();if(error)toast(error.message,true);else closeModal("profileModal");});

function hideStartupSplash() {
  const splash = $("startupSplash");
  if (splash) setTimeout(() => splash.classList.add("done"), 450);
}
async function boot(){
  if(!supabaseReady){
    hideStartupSplash();
    toast("Setup needed: add your Supabase project details in js/config.js.",true);
    return;
  }
  const {data:{session}}=await supabase.auth.getSession();
  if(session?.user && !state.user && enteringUserId !== session.user.id) {
    enteringUserId = session.user.id;
    try { await enterApp(session.user); }
    finally { enteringUserId = null; }
  }
  hideStartupSplash();
}
boot().catch(error=>{hideStartupSplash();toast(error.message||"Could not start the app.",true);});
