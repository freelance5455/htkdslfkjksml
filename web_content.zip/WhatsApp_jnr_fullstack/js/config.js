// Supabase public client configuration.
// Never put a Supabase secret/service_role key in browser-side code.
export const SUPABASE_URL = "https://iqonbhfffpvtkaxfqenp.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_H6tJAgF6Cq_euKSaXsGOFg_7nju-ENf";
