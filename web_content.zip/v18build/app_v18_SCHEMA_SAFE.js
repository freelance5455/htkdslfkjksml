const APP_DIAG_VERSION = "HTMLTOAPK_SCHEMA_SAFE_V18";
console.log(APP_DIAG_VERSION);
const SURAH_DATA = [["الفاتحة",7],["البقرة",286],["آل عمران",200],["النساء",176],["المائدة",120],["الأنعام",165],["الأعراف",206],["الأنفال",75],["التوبة",129],["يونس",109],["هود",123],["يوسف",111],["الرعد",43],["إبراهيم",52],["الحجر",99],["النحل",128],["الإسراء",111],["الكهف",110],["مريم",98],["طه",135],["الأنبياء",112],["الحج",78],["المؤمنون",118],["النور",64],["الفرقان",77],["الشعراء",227],["النمل",93],["القصص",88],["العنكبوت",69],["الروم",60],["لقمان",34],["السجدة",30],["الأحزاب",73],["سبأ",54],["فاطر",45],["يس",83],["الصافات",182],["ص",88],["الزمر",75],["غافر",85],["فصلت",54],["الشورى",53],["الزخرف",89],["الدخان",59],["الجاثية",37],["الأحقاف",35],["محمد",38],["الفتح",29],["الحجرات",18],["ق",45],["الذاريات",60],["الطور",49],["النجم",62],["القمر",55],["الرحمن",78],["الواقعة",96],["الحديد",29],["المجادلة",22],["الحشر",24],["الممتحنة",13],["الصف",14],["الجمعة",11],["المنافقون",11],["التغابن",18],["الطلاق",12],["التحريم",12],["الملك",30],["القلم",52],["الحاقة",52],["المعارج",44],["نوح",28],["الجن",28],["المزمل",20],["المدثر",56],["القيامة",40],["الإنسان",31],["المرسلات",50],["النبأ",40],["النازعات",46],["عبس",42],["التكوير",29],["الانفطار",19],["المطففين",36],["الانشقاق",25],["البروج",22],["الطارق",17],["الأعلى",19],["الغاشية",26],["الفجر",30],["البلد",20],["الشمس",15],["الليل",21],["الضحى",11],["الشرح",8],["التين",8],["العلق",19],["القدر",5],["البينة",8],["الزلزلة",8],["العاديات",11],["القارعة",11],["التكاثر",8],["العصر",3],["الهمزة",9],["الفيل",5],["قريش",4],["الماعون",7],["الكوثر",3],["الكافرون",6],["النصر",3],["المسد",5],["الإخلاص",4],["الفلق",5],["الناس",6]];
let user=null,circles=[],students=[],activeCircle=null,activeStudent=null,lessonType='new';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const msg=(id,text,ok=false)=>{const e=$(id);if(!e)return;e.textContent=text;e.className=ok?'ok':'err';};
function screen(id){document.querySelectorAll('.screen').forEach(x=>x.classList.add('hidden'));const e=$(id);if(e)e.classList.remove('hidden');window.scrollTo(0,0)}
function empty(t){return `<div class="empty">${esc(t)}</div>`}
function goHome(){screen('home')}
function openCircles(){screen('circles');loadCircles()}
async function openReport(){screen('report'); const d=new Date(); $('reportDate').value=d.toISOString().slice(0,10); await renderAllCircleReports()}
function openCircleView(){if(!activeCircle)return openCircles();screen('circle');loadStudents()}
function openStudentView(){if(!activeStudent)return openCircleView();screen('student');loadHistory()}

async function login(){
  const email=$('email').value.trim(),password=$('password').value;
  if(!email||!password){msg('loginMsg','اكتب البريد الإلكتروني وكلمة المرور.');return}
  const b=$('loginBtn');b.disabled=true;msg('loginMsg','جاري الدخول...');
  try{
    const r=await sb.auth.signInWithPassword({email,password});
    if(r.error){msg('loginMsg',r.error.message);return}
    user=r.data?.user||null;
    if(!user){msg('loginMsg','تعذر الحصول على جلسة الدخول.');return}
    await checkRole();
  }catch(e){console.error(e);msg('loginMsg','تعذر الاتصال بـ Supabase: '+(e?.message||e))}
  finally{b.disabled=false}
}
async function checkRole(){
  const r=await sb.from('profiles').select('role').eq('id',user.id).maybeSingle();
  if(r.error){msg('loginMsg','خطأ في قراءة صلاحية الحساب: '+r.error.message);return}
  if(!r.data||r.data.role!=='teacher'){await sb.auth.signOut();msg('loginMsg','هذا الحساب ليس حساب محفظ.');return}
  $('login').classList.add('hidden');$('app').classList.remove('hidden');await loadCircles();goHome();
}
async function loadCircles(){
  const r=await sb.from('circles').select('*').eq('teacher_id',user.id).order('created_at',{ascending:true});
  if(r.error){msg('circleMsg',r.error.message);return}
  circles=r.data||[];$('circleCount').textContent=circles.length+' حلقة';
  $('circleList').innerHTML=circles.map(c=>`<button class="cardRow" data-circle-id="${c.id}"><span class="rowIcon">📚</span><span class="rowText"><b>${esc(c.name)}</b><small>فتح الحلقة والطلاب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا توجد حلقات بعد. أضف أول حلقة.');
  document.querySelectorAll('[data-circle-id]').forEach(b=>b.onclick=()=>chooseCircle(b.dataset.circleId));
}
async function addCircle(){
  const name=$('circleName').value.trim();if(!name){msg('circleMsg','اكتب اسم الحلقة أولاً.');return}
  const b=$('addCircle');b.disabled=true;msg('circleMsg','جاري الإضافة...');
  try{const r=await sb.from('circles').insert({teacher_id:user.id,name});if(r.error){msg('circleMsg',r.error.message);return}$('circleName').value='';msg('circleMsg','تمت إضافة الحلقة.',true);await loadCircles()}finally{b.disabled=false}
}
async function chooseCircle(id){activeCircle=circles.find(c=>c.id===id)||null;if(!activeCircle)return;$('circleTitle').textContent=activeCircle.name;screen('circle');await loadStudents()}
async function loadStudents(){
  const r=await sb.from('students').select('*').eq('circle_id',activeCircle.id).eq('active',true).order('name');
  if(r.error){$('studentList').innerHTML=empty(r.error.message);return}students=r.data||[];
  $('studentList').innerHTML=students.map(s=>`<button class="cardRow" data-student-id="${s.id}"><span class="avatar">${esc(s.name).slice(0,1)}</span><span class="rowText"><b>${esc(s.name)}</b><small>فتح ملف الطالب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا يوجد طلاب في هذه الحلقة.');
  document.querySelectorAll('[data-student-id]').forEach(b=>b.onclick=()=>chooseStudent(b.dataset.studentId));
}
async function addStudent(){
  const name=$('studentName').value.trim();if(!name){msg('studentMsg','اكتب اسم الطالب أولاً.');return}
  const b=$('addStudent');b.disabled=true;msg('studentMsg','جاري الإضافة...');
  try{const r=await sb.from('students').insert({circle_id:activeCircle.id,name});if(r.error){msg('studentMsg',r.error.message);return}$('studentName').value='';msg('studentMsg','تمت إضافة الطالب.',true);await loadStudents()}finally{b.disabled=false}
}
function chooseStudent(id){activeStudent=students.find(s=>s.id===id)||null;if(!activeStudent)return;$('studentTitle').textContent=activeStudent.name;screen('student');loadHistory()}
async function loadHistory(){
  const r=await sb.from('recitations').select('*').eq('student_id',activeStudent.id).order('created_at',{ascending:false}).limit(50);
  if(r.error){$('history').innerHTML=empty(r.error.message);return}
  $('history').innerHTML=(r.data||[]).map(x=>{
    const fa=x.from_ayah??x.from_verse??x.start_ayah??x.start_verse??x.ayah_from??x.from??'—';
    const ta=x.to_ayah??x.to_verse??x.end_ayah??x.end_verse??x.ayah_to??x.to??'—';
    const sn=x.surah_number||x.surah||1;
    return `<div class="history"><b>${x.type==='new'?'📖 حفظ جديد':'🔄 مراجعة'}</b><span>${esc(SURAH_DATA[(Number(sn)||1)-1]?.[0]||'سورة')} — الآيات ${esc(fa)}–${esc(ta)}</span><small>${esc(x.created_at?new Date(x.created_at).toLocaleDateString('ar-EG'):(x.date||''))}</small></div>`
  }).join('')||empty('لا يوجد سجل لهذا الطالب.');
}
function openLesson(t){lessonType=t;$('lessonTitle').textContent=t==='new'?'حفظ جديد':'مراجعة';$('lessonMsg').textContent='';$('fromAyah').value='';$('toAyah').value='';$('surah').value='0';updateAyahLimit();screen('lesson')}
function updateAyahLimit(){const m=SURAH_DATA[Number($('surah').value)][1];$('fromAyah').max=m;$('toAyah').max=m;$('surahHint').textContent='عدد آيات السورة: '+m}
function serverMissingColumn(msg){
  const m=String(msg||'').match(/(?:Could not find the '([^']+)' column|column ["']([^"']+)["'])/i);
  return m?.[1]||m?.[2]||null;
}
function serverNotNullColumn(msg){
  const m=String(msg||'').match(/null value in column ["']([^"']+)["']/i);
  return m?.[1]||null;
}
function valueForColumn(col,ctx){
  const c=String(col||'').toLowerCase();
  if(c==='circle_id') return ctx.circle_id;
  if(c==='student_id') return ctx.student_id;
  if(c==='teacher_id') return ctx.teacher_id;
  if(c==='type') return ctx.type;
  if(c.includes('surah') && c.includes('number')) return ctx.surah_number;
  if(c==='surah_from') return ctx.surah_number;
  if(c==='surah_to') return ctx.surah_number;
  if(c.includes('from') && (c.includes('ayah')||c.includes('verse'))) return ctx.from_ayah;
  if(c.includes('to') && (c.includes('ayah')||c.includes('verse'))) return ctx.to_ayah;
  if(c==='from_ayah') return ctx.from_ayah;
  if(c==='to_ayah') return ctx.to_ayah;
  if(c==='recitation_date') return ctx.date;
  if(c==='attendance_date') return ctx.date;
  if(c==='report_date') return ctx.date;
  if(c==='date') return ctx.date;
  if(c==='created_at') return ctx.created_at||new Date().toISOString();
  if(c==='updated_at') return new Date().toISOString();
  if(c==='hours') return ctx.hours??0;
  if(c==='notes') return ctx.notes??'';
  if(c==='status') return ctx.status||'present';
  return undefined;
}
async function adaptiveInsert(table, initial, ctx, maxTries=12){
  let payload={...initial};
  for(let attempt=0;attempt<maxTries;attempt++){
    const r=await sb.from(table).insert(payload);
    if(!r.error) return null;
    const msg=String(r.error.message||r.error);
    const missing=serverMissingColumn(msg);
    if(missing && Object.prototype.hasOwnProperty.call(payload,missing)){
      delete payload[missing];
      continue;
    }
    const nn=serverNotNullColumn(msg);
    if(nn && !Object.prototype.hasOwnProperty.call(payload,nn)){
      const v=valueForColumn(nn,ctx);
      if(v!==undefined){payload[nn]=v;continue}
    }
    return new Error('['+APP_DIAG_VERSION+'] '+table+': '+msg);
  }
  return new Error('['+APP_DIAG_VERSION+'] '+table+': تعذر تجهيز البيانات تلقائياً.');
}
async function saveLesson(e){
  if(e){e.preventDefault();e.stopPropagation()}
  try{
    if(!activeCircle || !activeStudent){msg('lessonMsg','اختر الحلقة والطالب أولاً.');return}
    const surahSel=$('surah'),fromEl=$('fromAyah'),toEl=$('toAyah');
    if(!surahSel||!fromEl||!toEl){msg('lessonMsg','خطأ في واجهة الحفظ: عناصر الإدخال غير موجودة.');return}
    const i=Number(surahSel.value||0),from=Number(fromEl.value||0),to=Number(toEl.value||0);
    if(!i||!from||!to){msg('lessonMsg','اختر السورة وأدخل الآيات.');return}
    const max=SURAH_DATA[i]?.[1]||0;
    if(from<1||to<1||from>to||to>max){msg('lessonMsg','رقم الآيات غير صحيح لهذه السورة.');return}
    const today=new Date().toISOString().slice(0,10);
    const ctx={circle_id:activeCircle.id,student_id:activeStudent.id,teacher_id:user?.id,type:lessonType,surah_number:i,from_ayah:from,to_ayah:to,date:today};
    const broad={circle_id:ctx.circle_id,student_id:ctx.student_id,teacher_id:ctx.teacher_id,type:ctx.type,surah_number:i,surah_from:i,surah_to:i,from_ayah:from,to_ayah:to,start_ayah:from,end_ayah:to,from_verse:from,to_verse:to,recitation_date:today,date:today};
    const b=$('saveLesson');if(b)b.disabled=true;msg('lessonMsg','جاري الحفظ...');
    const err=await adaptiveInsert('recitations',broad,ctx);
    if(err){console.error(err);msg('lessonMsg','فشل الحفظ: '+err.message);return}
    msg('lessonMsg','تم الحفظ بنجاح.',true);await loadHistory();
  }catch(err){console.error(APP_DIAG_VERSION,err);msg('lessonMsg','خطأ أثناء الحفظ: '+(err?.message||String(err)))}
  finally{const b=$('saveLesson');if(b)b.disabled=false}
}

async function renderAllCircleReports(){
  const box=$('allCircleReports');if(!circles.length){box.innerHTML=empty('لا توجد حلقات.');return}
  box.innerHTML=empty('جاري تحميل الحلقات...');
  const parts=[];
  for(const c of circles){
    const r=await sb.from('students').select('id,name').eq('circle_id',c.id).eq('active',true).order('name');
    if(r.error){box.innerHTML=empty(r.error.message);return}
    const list=r.data||[];
    parts.push(`<div class="report-card" data-circle="${c.id}"><h3>📚 ${esc(c.name)}</h3><label>ساعات الحلقة</label><input class="circle-hours" type="number" min="0" step="0.5" placeholder="مثال: 2"><div class="attendance-box"><b>الحضور:</b>${list.length?list.map(s=>`<label class="att"><input type="checkbox" class="circle-att" data-student="${s.id}"><span>${esc(s.name)}</span></label>`).join(''):'<p class="muted">لا يوجد طلاب.</p>'}</div></div>`)
  }
  box.innerHTML=parts.join('');
}
async function saveAttendance(cid,date,studentIds){
  for(const student_id of studentIds){
    const ctx={circle_id:cid,student_id,teacher_id:user?.id,date,status:'present'};
    const broad={circle_id:cid,student_id,teacher_id:user?.id,date,attendance_date:date,status:'present'};
    const err=await adaptiveInsert('attendance',broad,ctx);
    if(err && !/duplicate|already exists|unique/i.test(err.message)) return err;
  }
  return null;
}
async function saveOrUpdateReport(cid,date,hours,notes){
  const ctx={teacher_id:user.id,circle_id:cid,date,hours,notes,created_at:new Date(date+'T12:00:00').toISOString()};
  const broad={teacher_id:user.id,circle_id:cid,date,report_date:date,hours,notes,created_at:ctx.created_at};
  // Insert directly with adaptive columns. This avoids depending on a specific date column name.
  return await adaptiveInsert('daily_reports',broad,ctx);
}
async function sendReport(e){
  if(e){e.preventDefault();e.stopPropagation()}
  try{
    const b=$('sendReport'),date=$('reportDate')?.value,notes=$('reportNotes')?.value?.trim()||'';
    if(!date){msg('reportMsg','اختر التاريخ.');return}
    if(!user){msg('reportMsg','جلسة الدخول انتهت. سجّل الدخول مرة أخرى.');return}
    const cards=[...document.querySelectorAll('.report-card')];
    if(!cards.length){msg('reportMsg','لا توجد حلقات لإرسالها.');return}
    if(b)b.disabled=true;msg('reportMsg','جاري إرسال التقرير...');
    for(let n=0;n<cards.length;n++){
      const card=cards[n],cid=card.dataset.circle;
      const hours=Number(card.querySelector('.circle-hours')?.value||0);
      const checked=[...card.querySelectorAll('.circle-att:checked')].map(x=>x.dataset.student);
      msg('reportMsg',`جاري إرسال الحلقة ${n+1} من ${cards.length}...`);
      const ae=await saveAttendance(cid,date,checked);if(ae)throw new Error('الحضور: '+ae.message);
      const re=await saveOrUpdateReport(cid,date,hours,notes);if(re)throw new Error('التقرير: '+re.message);
    }
    msg('reportMsg','تم إرسال تقرير جميع الحلقات للمدير بنجاح.',true)
  }catch(e2){console.error(APP_DIAG_VERSION,e2);msg('reportMsg','لم يتم الإرسال: '+(e2?.message||String(e2)))}
  finally{const b=$('sendReport');if(b)b.disabled=false}
}

function bind(){
  SURAH_DATA.forEach((s,i)=>$('surah').insertAdjacentHTML('beforeend',`<option value="${i}">${i+1} — ${s[0]}</option>`));
  $('surah').onchange=updateAyahLimit;
  $('loginBtn').onclick=login;
  $('logout').onclick=async()=>{await sb.auth.signOut();location.reload()};
  $('addCircle').addEventListener('click',addCircle);$('addStudent').addEventListener('click',addStudent);$('saveLesson').addEventListener('click',saveLesson);$('sendReport').addEventListener('click',sendReport);
}
async function init(){
  bind();
  try{
    const r=await sb.auth.getSession();
    if(r.error)throw r.error;
    user=r.data?.session?.user||null;
    if(user) await checkRole(); else {$('login').classList.remove('hidden');$('app').classList.add('hidden')}
  }catch(e){console.error(e);msg('loginMsg','تعذر الاتصال بالخادم: '+(e?.message||e))}
}
sb.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_OUT'){user=null;$('app').classList.add('hidden');$('login').classList.remove('hidden')}});
init();
