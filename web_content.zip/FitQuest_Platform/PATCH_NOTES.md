# FitQuest 2.0 — исправления кандидата сборки

## Исправлено в исходниках
- Статические ссылки в HTML переведены на относительные пути (`./...`) для размещения страницы в `/web/index.html` внутри HTML to APK.
- Добавлен `public/config.js` с настройкой адреса backend API для Android WebView.
- Клиентский API-клиент поддерживает отдельный HTTPS API origin и credentials для сессии.
- Сервер получил точечный CORS allow-list через `APP_ALLOWED_ORIGINS`; произвольные origins не разрешаются.
- Добавлена настройка cookie `COOKIE_SAME_SITE` для cross-site WebView; для обычного локального запуска остаётся `lax`.
- Исправлены параметры очистки cookie при выходе и удалении аккаунта.
- Service Worker обновлён и не регистрируется в Android appassets origin.
- Добавлена инструкция `ANDROID_WEBVIEW.md` и корректный Windows launcher `Start-FitQuest.bat`.

## Проверки
- `npm test` — успешно (проверка синтаксиса JS и структурная проверка клиент/server/DB контрактов).
- Полный запуск с PostgreSQL не выполнялся: в среде проверки нет Docker и не был подключён PostgreSQL.
- APK не собран: в исходном архиве отсутствует Android Studio/WebView проект, а опубликованный HTTPS адрес backend ещё не задан.

## Что обязательно задать перед APK
1. Развернуть backend + PostgreSQL на HTTPS.
2. В `public/config.js` указать реальный API URL.
3. В серверном `.env` указать `APP_ALLOWED_ORIGINS=https://appassets.androidplatform.net` и `COOKIE_SAME_SITE=none`.
4. Упаковать содержимое `public/` в папку `web/` и указать стартовый файл `web/index.html`.
