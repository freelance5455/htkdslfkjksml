'use strict';
// Для обычного сайта оставь пустую строку: API будет работать на том же домене.
// Для APK укажи HTTPS-адрес опубликованного FitQuest-сервера.
window.FITQUEST_API_BASE = window.FITQUEST_API_BASE || '';
