# FitQuest 2.0 — подключение Android WebView / HTML to APK

## Почему возникал `ERR_HTTP_RESPONSE_CODE_FAILURE`

Архив FitQuest 2.0 содержит full-stack приложение: HTML/CSS/JS-клиент и Node.js API с PostgreSQL. Если просто упаковать `public/` в APK, страница откроется с origin `https://appassets.androidplatform.net`, но запросы `/api/...` по умолчанию тоже уйдут на этот локальный origin. В APK нет Node.js и PostgreSQL, поэтому API там не существует.

## Правильная схема

1. Сначала разверни `FitQuest_Platform` на HTTPS-хостинге вместе с PostgreSQL.
2. В `.env` на сервере задай `NODE_ENV=production`, длинный `SESSION_SECRET`, `DATABASE_URL`, `DATABASE_SSL` при необходимости.
3. Для APK с локальным HTML задай `APP_ALLOWED_ORIGINS=https://appassets.androidplatform.net` и `COOKIE_SAME_SITE=none`. Это разрешает только указанный origin, а не любой сайт. Используй только HTTPS API.
4. В `public/config.js` пропиши реальный адрес backend, например `window.FITQUEST_API_BASE = 'https://твой-домен.example';` (без завершающего `/`). Не оставляй примерный домен.
5. Упаковывай в HTML to APK содержимое папки `public/` в папку `web/`, включая `index.html`, `config.js`, `app.js`, `style.css`, `manifest.webmanifest` и `service-worker.js`. Пути к HTML/CSS/JS теперь относительные (`./...`), поэтому они рассчитаны на страницу `/web/index.html`.
6. В настройках конвертера укажи стартовую страницу `web/index.html`, включи JavaScript, DOM storage и cookies. Разреши загрузку HTTPS-содержимого. Не включай mixed content.
7. Собери новый APK, удали старую тестовую версию только после того, как сохранишь нужные данные, и проверь регистрацию, повторный вход, запись тренировки и выход.

## Проверка backend до APK

Открой `https://твой-домен.example/api/health`. Ожидаемый ответ:

```json
{"ok":true,"service":"FitQuest API"}
```

Если ответ 503 — проверь PostgreSQL и `DATABASE_URL`. Если 404 — неверный адрес/путь публикации. Если APK показывает CORS/сетевую ошибку — проверь `APP_ALLOWED_ORIGINS`, `COOKIE_SAME_SITE=none`, HTTPS и настройки cookies в WebView.

## Важное ограничение

Сам APK нельзя корректно собрать из одного этого архива: в нём нет Android Studio-проекта и адреса опубликованного backend. Этот патч подготавливает frontend и backend к работе через WebView, но для окончательной сборки нужны реальный HTTPS-домен сервера и исходный APK-конвертер/Android-проект. Не публикуй секреты `.env` и пароль PostgreSQL.
