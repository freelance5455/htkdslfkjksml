'use strict';

// Dependency-free structural checks for the FitQuest client/server contract.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const schema = fs.readFileSync(path.join(root, 'db/schema.sql'), 'utf8');
const config = fs.readFileSync(path.join(root, 'public/config.js'), 'utf8');
const failures = [];

const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
for (const match of js.matchAll(/\$\('([^']+)'\)/g)) {
  if (!ids.has(match[1])) failures.push(`app.js обращается к отсутствующему HTML id: ${match[1]}`);
}

for (const match of html.matchAll(/data-page="([^"]+)"/g)) {
  const page = match[1];
  if (!ids.has(`page-${page}`)) failures.push(`Для вкладки «${page}» нет элемента #page-${page}`);
}

const requiredRoutes = [
  "app.post('/api/auth/register'", "app.post('/api/auth/login'", "app.post('/api/auth/logout'",
  "app.get('/api/state'", "app.patch('/api/profile'", "app.delete('/api/account'",
  "app.post('/api/gps/point'", "app.post('/api/gps/stop'", "app.post('/api/shop/buy'",
  "app.post('/api/shop/equip'", "app.post('/api/workouts'", "app.get('/api/leaderboard'"
];
for (const route of requiredRoutes) if (!server.includes(route)) failures.push(`Не найден обязательный API-маршрут: ${route}`);

for (const table of ['users', 'player_state', 'completed_tasks', 'shop_purchases', 'workout_logs', 'program_progress']) {
  if (!new RegExp(`CREATE TABLE IF NOT EXISTS\\s+${table}\\b`, 'i').test(schema)) {
    failures.push(`В db/schema.sql отсутствует таблица ${table}`);
  }
}

if (!/client_request_id UUID/.test(schema) || !/workout_logs_user_request_uq/.test(schema)) failures.push('Не настроена идемпотентность офлайн-записей тренировок.');
if (!server.includes('clientRequestId') || !js.includes('clientRequestId: crypto.randomUUID()')) failures.push('Клиент и сервер не передают ключ идемпотентности тренировок.');
if (/\bon(click|change|submit)\s*=/.test(html)) failures.push('Найдены inline-обработчики событий; проверь CSP и безопасность.');
if (!html.includes('./config.js') || !html.includes('./app.js') || !html.includes('./style.css')) failures.push('Ресурсы HTML должны подключаться относительными путями для /web/index.html.');
if (!js.includes('API_BASE')) failures.push('Клиент не поддерживает отдельный API origin.');
if (!server.includes('APP_ALLOWED_ORIGINS') || !server.includes('Access-Control-Allow-Credentials')) failures.push('Не настроен allow-list CORS для Android WebView.');
if (!config.includes('FITQUEST_API_BASE')) failures.push('Отсутствует конфигурация API base URL.');
if (failures.length) {
  console.error(`Проверка FitQuest: ${failures.length} ошибок`);
  for (const failure of failures) console.error(`- ${failure}`);
  process.exitCode = 1;
} else {
  console.log('Проверка FitQuest пройдена: HTML id, вкладки, API-маршруты и таблицы БД согласованы.');
}
