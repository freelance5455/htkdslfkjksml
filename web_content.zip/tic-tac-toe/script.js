// --- Confetti Particle System ---
class ConfettiCannon {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.particles = [];
    this.animId = null;
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  fire(count = 90) {
    const colors = ['#00f2fe', '#ff007f', '#10b981', '#f59e0b', '#ec4899', '#3b82f6'];
    const originX = this.canvas.width / 2;
    const originY = this.canvas.height * 0.45;

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const velocity = 5 + Math.random() * 9;
      this.particles.push({
        x: originX,
        y: originY,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity - 3,
        size: 6 + Math.random() * 6,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 12,
        alpha: 1,
        drag: 0.98,
        gravity: 0.25
      });
    }

    if (!this.animId) {
      this.loop();
    }
  }

  loop() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.vx *= p.drag;
      p.vy = p.vy * p.drag + p.gravity;
      p.x += p.vx;
      p.y += p.vy;
      p.rotation += p.rotationSpeed;
      p.alpha -= 0.012;

      if (p.alpha <= 0 || p.y > this.canvas.height) {
        this.particles.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.translate(p.x, p.y);
      this.ctx.rotate((p.rotation * Math.PI) / 180);
      this.ctx.fillStyle = p.color;
      this.ctx.globalAlpha = Math.max(p.alpha, 0);
      this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.7);
      this.ctx.restore();
    }

    if (this.particles.length > 0) {
      this.animId = requestAnimationFrame(() => this.loop());
    } else {
      this.animId = null;
    }
  }

  stop() {
    this.particles = [];
    if (this.animId) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }
}

// --- Web Audio Sound Synthesizer ---
class SoundEffects {
  constructor() {
    this.ctx = null;
    this.muted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playMove(isX) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      const freq = isX ? 480 : 640;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      osc.type = 'sine';

      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.1);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.1);
    } catch (_) {}
  }

  playWin() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.connect(gain);
        gain.connect(this.ctx.destination);

        const startTime = this.ctx.currentTime + idx * 0.08;
        osc.frequency.setValueAtTime(freq, startTime);
        osc.type = 'triangle';

        gain.gain.setValueAtTime(0.14, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.28);

        osc.start(startTime);
        osc.stop(startTime + 0.28);
      });
    } catch (_) {}
  }

  playTie() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.setValueAtTime(260, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(130, this.ctx.currentTime + 0.28);
      osc.type = 'sawtooth';

      gain.gain.setValueAtTime(0.09, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.28);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.28);
    } catch (_) {}
  }

  playBuzzer() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      osc.type = 'square';

      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.2);
    } catch (_) {}
  }
}

// --- Game Logic & UI Controller ---
const confetti = new ConfettiCannon(document.getElementById('confetti-canvas'));
const sounds = new SoundEffects();

const WINNING_COMBINATIONS = [
  { combo: [0, 1, 2], line: { x1: 20, y1: 50, x2: 280, y2: 50 } },
  { combo: [3, 4, 5], line: { x1: 20, y1: 150, x2: 280, y2: 150 } },
  { combo: [6, 7, 8], line: { x1: 20, y1: 250, x2: 280, y2: 250 } },
  { combo: [0, 3, 6], line: { x1: 50, y1: 20, x2: 50, y2: 280 } },
  { combo: [1, 4, 7], line: { x1: 150, y1: 20, x2: 150, y2: 280 } },
  { combo: [2, 5, 8], line: { x1: 250, y1: 20, x2: 250, y2: 280 } },
  { combo: [0, 4, 8], line: { x1: 25, y1: 25, x2: 275, y2: 275 } },
  { combo: [2, 4, 6], line: { x1: 275, y1: 25, x2: 25, y2: 275 } }
];

let boardState = Array(9).fill(null);
let moveHistory = [];
let currentPlayer = 'X';
let isGameOver = false;
let scores = { X: 0, ties: 0, O: 0 };
let stats = { currentStreak: 0, bestStreak: 0, totalGames: 0, wins: 0 };

// Timer State
let timerSeconds = 0;
let timerRemaining = 0;
let timerInterval = null;

// DOM Elements
const boardEl = document.getElementById('board');
const cells = document.querySelectorAll('.cell');
const statusMessage = document.getElementById('status-message');
const strikeLine = document.getElementById('strike-line');
const cardX = document.getElementById('card-x');
const cardO = document.getElementById('card-o');
const scoreX = document.getElementById('score-x');
const scoreO = document.getElementById('score-o');
const scoreTies = document.getElementById('score-ties');
const labelX = document.getElementById('label-x');
const labelO = document.getElementById('label-o');
const streakVal = document.getElementById('streak-val');
const bestStreakVal = document.getElementById('best-streak-val');
const winRateVal = document.getElementById('win-rate-val');
const gameModeSelect = document.getElementById('game-mode');
const aiDifficultySelect = document.getElementById('ai-difficulty');
const difficultyGroup = document.getElementById('difficulty-group');
const playerSideSelect = document.getElementById('player-side');
const playerChoiceGroup = document.getElementById('player-choice-group');
const themeSelect = document.getElementById('theme-select');
const turnTimerSelect = document.getElementById('turn-timer-select');
const timerBarContainer = document.getElementById('timer-bar-container');
const timerBarFill = document.getElementById('timer-bar-fill');
const btnRestart = document.getElementById('btn-restart');
const btnResetScores = document.getElementById('btn-reset-scores');
const btnUndo = document.getElementById('btn-undo');
const btnSoundToggle = document.getElementById('btn-sound-toggle');
const soundIcon = document.getElementById('sound-icon');

function getGameMode() {
  return gameModeSelect.value;
}

function getHumanSide() {
  return playerSideSelect.value;
}

function getAiSide() {
  return getHumanSide() === 'X' ? 'O' : 'X';
}

function updateLabels() {
  const mode = getGameMode();
  if (mode === 'pve') {
    const human = getHumanSide();
    labelX.textContent = human === 'X' ? 'You (X)' : 'AI (X)';
    labelO.textContent = human === 'O' ? 'You (O)' : 'AI (O)';
    difficultyGroup.style.display = 'flex';
    playerChoiceGroup.style.display = 'flex';
  } else {
    labelX.textContent = 'Player X';
    labelO.textContent = 'Player O';
    difficultyGroup.style.display = 'none';
    playerChoiceGroup.style.display = 'none';
  }
}

function updateTurnIndicator() {
  boardEl.dataset.turn = currentPlayer;

  if (isGameOver) {
    cardX.classList.remove('active');
    cardO.classList.remove('active');
    return;
  }

  if (currentPlayer === 'X') {
    cardX.classList.add('active');
    cardO.classList.remove('active');
  } else {
    cardO.classList.add('active');
    cardX.classList.remove('active');
  }

  const mode = getGameMode();
  if (mode === 'pve') {
    const isHuman = currentPlayer === getHumanSide();
    statusMessage.textContent = isHuman ? 'Your turn' : 'AI is thinking...';
  } else {
    statusMessage.textContent = `Player ${currentPlayer}'s turn`;
  }

  btnUndo.disabled = moveHistory.length === 0 || (mode === 'pve' && currentPlayer === getAiSide());
}

function checkWin(board) {
  for (const item of WINNING_COMBINATIONS) {
    const [a, b, c] = item.combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], combo: item.combo, line: item.line };
    }
  }
  return null;
}

function isBoardFull(board) {
  return board.every(cell => cell !== null);
}

function getAvailableMoves(board) {
  const moves = [];
  board.forEach((cell, idx) => {
    if (cell === null) moves.push(idx);
  });
  return moves;
}

// Minimax with Alpha-Beta Pruning
function minimax(board, depth, isMaximizing, aiMark, humanMark, alpha = -Infinity, beta = Infinity) {
  const win = checkWin(board);
  if (win) {
    return win.winner === aiMark ? { score: 10 - depth } : { score: depth - 10 };
  }
  if (isBoardFull(board)) return { score: 0 };

  const available = getAvailableMoves(board);

  if (isMaximizing) {
    let maxScore = -Infinity;
    let bestMove = null;
    for (const move of available) {
      board[move] = aiMark;
      const res = minimax(board, depth + 1, false, aiMark, humanMark, alpha, beta);
      board[move] = null;
      if (res.score > maxScore) {
        maxScore = res.score;
        bestMove = move;
      }
      alpha = Math.max(alpha, maxScore);
      if (beta <= alpha) break;
    }
    return { score: maxScore, move: bestMove };
  } else {
    let minScore = Infinity;
    let bestMove = null;
    for (const move of available) {
      board[move] = humanMark;
      const res = minimax(board, depth + 1, true, aiMark, humanMark, alpha, beta);
      board[move] = null;
      if (res.score < minScore) {
        minScore = res.score;
        bestMove = move;
      }
      beta = Math.min(beta, minScore);
      if (beta <= alpha) break;
    }
    return { score: minScore, move: bestMove };
  }
}

function getAIMove() {
  const available = getAvailableMoves(boardState);
  if (available.length === 0) return null;

  const difficulty = aiDifficultySelect.value;
  const aiMark = getAiSide();
  const humanMark = getHumanSide();

  if (difficulty === 'easy') {
    return available[Math.floor(Math.random() * available.length)];
  }

  if (difficulty === 'medium') {
    if (Math.random() > 0.6) {
      // Check immediate win or immediate block
      for (const m of available) {
        boardState[m] = aiMark;
        if (checkWin(boardState)) {
          boardState[m] = null;
          return m;
        }
        boardState[m] = null;
      }
      for (const m of available) {
        boardState[m] = humanMark;
        if (checkWin(boardState)) {
          boardState[m] = null;
          return m;
        }
        boardState[m] = null;
      }
      return available[Math.floor(Math.random() * available.length)];
    }
  }

  const best = minimax(boardState, 0, true, aiMark, humanMark);
  return best.move !== null && best.move !== undefined
    ? best.move
    : available[Math.floor(Math.random() * available.length)];
}

function drawStrikeLine(lineCoords) {
  strikeLine.setAttribute('x1', lineCoords.x1);
  strikeLine.setAttribute('y1', lineCoords.y1);
  strikeLine.setAttribute('x2', lineCoords.x2);
  strikeLine.setAttribute('y2', lineCoords.y2);
  // Trigger redraw
  strikeLine.classList.remove('draw');
  void strikeLine.offsetWidth;
  strikeLine.classList.add('draw');
}

function clearStrikeLine() {
  strikeLine.classList.remove('draw');
  strikeLine.setAttribute('x1', 0);
  strikeLine.setAttribute('y1', 0);
  strikeLine.setAttribute('x2', 0);
  strikeLine.setAttribute('y2', 0);
}

function startTimer() {
  stopTimer();
  if (timerSeconds <= 0 || isGameOver) {
    timerBarContainer.style.display = 'none';
    return;
  }

  timerBarContainer.style.display = 'block';
  timerRemaining = timerSeconds;
  timerBarFill.style.width = '100%';
  timerBarFill.style.backgroundColor = currentPlayer === 'X' ? 'var(--color-x)' : 'var(--color-o)';

  const intervalMs = 100;
  const decrement = intervalMs / 1000;

  timerInterval = setInterval(() => {
    timerRemaining -= decrement;
    const percentage = Math.max((timerRemaining / timerSeconds) * 100, 0);
    timerBarFill.style.width = `${percentage}%`;

    if (timerRemaining <= 0) {
      stopTimer();
      sounds.playBuzzer();
      handleTimeout();
    }
  }, intervalMs);
}

function stopTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function handleTimeout() {
  if (isGameOver) return;
  boardEl.classList.add('shake');
  setTimeout(() => boardEl.classList.remove('shake'), 400);

  const timedOutPlayer = currentPlayer;
  statusMessage.textContent = `⏰ Time's up for ${timedOutPlayer}! Switch turn.`;
  currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  updateTurnIndicator();

  if (getGameMode() === 'pve' && currentPlayer === getAiSide()) {
    triggerAIMove();
  } else {
    startTimer();
  }
}

function makeMove(index, player) {
  boardState[index] = player;
  moveHistory.push({ index, player });

  const cell = cells[index];
  cell.textContent = player;
  cell.classList.add(player.toLowerCase());
  cell.disabled = true;
  sounds.playMove(player === 'X');

  stopTimer();

  const winResult = checkWin(boardState);

  if (winResult) {
    isGameOver = true;
    winResult.combo.forEach(idx => cells[idx].classList.add('winner'));
    drawStrikeLine(winResult.line);
    scores[player]++;
    updateScores();
    sounds.playWin();
    confetti.fire(110);

    const mode = getGameMode();
    if (mode === 'pve') {
      const isHuman = player === getHumanSide();
      statusMessage.textContent = isHuman ? '🎉 VICTORY! You won!' : '🤖 AI won this match!';
      stats.totalGames++;
      if (isHuman) {
        stats.wins++;
        stats.currentStreak++;
        if (stats.currentStreak > stats.bestStreak) {
          stats.bestStreak = stats.currentStreak;
        }
      } else {
        stats.currentStreak = 0;
      }
    } else {
      statusMessage.textContent = `🎉 Player ${player} wins!`;
      stats.totalGames++;
    }

    updateStats();
    updateTurnIndicator();
    return;
  }

  if (isBoardFull(boardState)) {
    isGameOver = true;
    scores.ties++;
    stats.totalGames++;
    stats.currentStreak = 0;
    updateScores();
    updateStats();
    sounds.playTie();
    boardEl.classList.add('shake');
    setTimeout(() => boardEl.classList.remove('shake'), 400);
    statusMessage.textContent = "🤝 It's a draw!";
    updateTurnIndicator();
    return;
  }

  currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  updateTurnIndicator();

  if (getGameMode() === 'pve' && currentPlayer === getAiSide() && !isGameOver) {
    triggerAIMove();
  } else {
    startTimer();
  }
}

function triggerAIMove() {
  setBoardDisabled(true);
  setTimeout(() => {
    if (!isGameOver) {
      const aiMove = getAIMove();
      if (aiMove !== null) {
        makeMove(aiMove, getAiSide());
      }
    }
    setBoardDisabled(false);
  }, 320);
}

function setBoardDisabled(disabled) {
  cells.forEach((cell, idx) => {
    if (boardState[idx] === null) {
      cell.disabled = disabled;
    }
  });
}

function undoMove() {
  if (moveHistory.length === 0 || isGameOver) return;

  const mode = getGameMode();

  if (mode === 'pve') {
    // Revert AI move and player move
    if (currentPlayer === getAiSide()) return; // cannot undo while AI thinks

    if (moveHistory.length >= 2) {
      const last1 = moveHistory.pop();
      const last2 = moveHistory.pop();
      revertCell(last1.index);
      revertCell(last2.index);
    } else if (moveHistory.length === 1) {
      const last = moveHistory.pop();
      revertCell(last.index);
      currentPlayer = last.player;
    }
  } else {
    // 2 Player mode: undo last single move
    const last = moveHistory.pop();
    revertCell(last.index);
    currentPlayer = last.player;
  }

  clearStrikeLine();
  updateTurnIndicator();
  startTimer();
}

function revertCell(index) {
  boardState[index] = null;
  const cell = cells[index];
  cell.textContent = '';
  cell.className = 'cell';
  cell.disabled = false;
}

function updateScores() {
  scoreX.textContent = scores.X;
  scoreO.textContent = scores.O;
  scoreTies.textContent = scores.ties;
}

function updateStats() {
  streakVal.textContent = `🔥 ${stats.currentStreak}`;
  bestStreakVal.textContent = `⭐ ${stats.bestStreak}`;
  const rate = stats.totalGames > 0 ? Math.round((stats.wins / stats.totalGames) * 100) : 0;
  winRateVal.textContent = `${rate}%`;
}

function resetBoard() {
  stopTimer();
  confetti.stop();
  clearStrikeLine();

  boardState = Array(9).fill(null);
  moveHistory = [];
  isGameOver = false;
  currentPlayer = 'X';

  cells.forEach(cell => {
    cell.textContent = '';
    cell.className = 'cell';
    cell.disabled = false;
  });

  updateLabels();
  updateTurnIndicator();

  if (getGameMode() === 'pve' && getHumanSide() === 'O') {
    triggerAIMove();
  } else {
    startTimer();
  }
}

function resetScores() {
  scores = { X: 0, ties: 0, O: 0 };
  stats = { currentStreak: 0, bestStreak: 0, totalGames: 0, wins: 0 };
  updateScores();
  updateStats();
  resetBoard();
}

// Event Listeners
cells.forEach(cell => {
  cell.addEventListener('click', () => {
    const idx = parseInt(cell.getAttribute('data-index'), 10);
    if (boardState[idx] !== null || isGameOver) return;

    if (getGameMode() === 'pve' && currentPlayer !== getHumanSide()) {
      return;
    }

    makeMove(idx, currentPlayer);
  });
});

btnRestart.addEventListener('click', resetBoard);
btnResetScores.addEventListener('click', resetScores);
btnUndo.addEventListener('click', undoMove);

btnSoundToggle.addEventListener('click', () => {
  sounds.muted = !sounds.muted;
  soundIcon.textContent = sounds.muted ? '🔇' : '🔊';
  btnSoundToggle.title = sounds.muted ? 'Sound Muted' : 'Sound On';
});

gameModeSelect.addEventListener('change', () => {
  resetScores();
});

playerSideSelect.addEventListener('change', () => {
  resetBoard();
});

aiDifficultySelect.addEventListener('change', () => {
  resetBoard();
});

themeSelect.addEventListener('change', e => {
  document.documentElement.dataset.theme = e.target.value;
});

turnTimerSelect.addEventListener('change', e => {
  timerSeconds = parseInt(e.target.value, 10);
  startTimer();
});

// Initialization
updateLabels();
updateTurnIndicator();
updateScores();
updateStats();
