#!/usr/bin/env python3
"""
Enhanced Interactive Tic Tac Toe Game (Terminal CLI)
Features:
- Local 2-Player or 1-Player vs AI (Easy, Medium, Unbeatable Minimax)
- Undo move capability ('u' to undo)
- Visual highlight for winning line
- Win streaks & match statistics
- ANSI color graphics
"""

import sys
import random

# ANSI Color Codes
CYAN = "\033[96m"
MAGENTA = "\033[95m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BOLD = "\033[1m"
DIM = "\033[2m"
BG_GREEN = "\033[42m\033[30m"
RESET = "\033[0m"

WINNING_COMBINATIONS = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),
    (0, 3, 6), (1, 4, 7), (2, 5, 8),
    (0, 4, 8), (2, 4, 6)
]


def print_banner():
    print(f"\n{BOLD}{CYAN}╔════════════════════════════════════════╗{RESET}")
    print(f"{BOLD}{CYAN}║         TIC TAC TOE DELUXE             ║{RESET}")
    print(f"{BOLD}{CYAN}║     Type 1-9 to move, 'u' to undo      ║{RESET}")
    print(f"{BOLD}{CYAN}╚════════════════════════════════════════╝{RESET}\n")


def display_board(board, win_indices=None):
    win_set = set(win_indices) if win_indices else set()

    def fmt(idx):
        val = board[idx]
        if idx in win_set:
            return f"{BG_GREEN}{BOLD} {val} {RESET}"
        if val == 'X':
            return f" {CYAN}{BOLD}X{RESET} "
        elif val == 'O':
            return f" {RED}{BOLD}O{RESET} "
        else:
            return f" {DIM}{idx + 1}{RESET} "

    print()
    print(f"  {fmt(0)}│{fmt(1)}│{fmt(2)}")
    print("  ───┼───┼───")
    print(f"  {fmt(3)}│{fmt(4)}│{fmt(5)}")
    print("  ───┼───┼───")
    print(f"  {fmt(6)}│{fmt(7)}│{fmt(8)}")
    print()


def check_win(board, player):
    for a, b, c in WINNING_COMBINATIONS:
        if board[a] == board[b] == board[c] == player:
            return (a, b, c)
    return None


def is_board_full(board):
    return all(cell in ('X', 'O') for cell in board)


def get_available_moves(board):
    return [i for i, cell in enumerate(board) if cell not in ('X', 'O')]


def minimax(board, depth, is_maximizing, ai_player, human_player, alpha=-float('inf'), beta=float('inf')):
    if check_win(board, ai_player):
        return 10 - depth, None
    if check_win(board, human_player):
        return depth - 10, None
    if is_board_full(board):
        return 0, None

    available = get_available_moves(board)

    if is_maximizing:
        max_score = -float('inf')
        best_move = None
        for move in available:
            board[move] = ai_player
            score, _ = minimax(board, depth + 1, False, ai_player, human_player, alpha, beta)
            board[move] = ' '
            if score > max_score:
                max_score = score
                best_move = move
            alpha = max(alpha, max_score)
            if beta <= alpha:
                break
        return max_score, best_move
    else:
        min_score = float('inf')
        best_move = None
        for move in available:
            board[move] = human_player
            score, _ = minimax(board, depth + 1, True, ai_player, human_player, alpha, beta)
            board[move] = ' '
            if score < min_score:
                min_score = score
                best_move = move
            beta = min(beta, min_score)
            if beta <= alpha:
                break
        return min_score, best_move


def get_ai_move(board, difficulty, ai_player, human_player):
    available = get_available_moves(board)
    if not available:
        return None

    if difficulty == 'easy':
        return random.choice(available)
    elif difficulty == 'medium':
        if random.random() < 0.4:
            return random.choice(available)

    _, move = minimax(board, 0, True, ai_player, human_player)
    return move if move is not None else random.choice(available)


def get_player_move(board, player_name, mark, can_undo):
    mark_color = CYAN if mark == 'X' else RED
    undo_prompt = f" or {YELLOW}'u'{RESET} to undo" if can_undo else ""

    while True:
        try:
            choice = input(
                f"{BOLD}{player_name} ({mark_color}{mark}{RESET}{BOLD}), enter cell (1-9){undo_prompt}: {RESET}"
            ).strip()
            if choice.lower() in ('q', 'quit', 'exit'):
                print("\nThanks for playing! Goodbye!")
                sys.exit(0)
            if choice.lower() == 'u':
                if can_undo:
                    return 'undo'
                else:
                    print(f"{YELLOW}No moves to undo!{RESET}")
                    continue

            val = int(choice) - 1
            if 0 <= val <= 8:
                if board[val] not in ('X', 'O'):
                    return val
                else:
                    print(f"{YELLOW}Cell already taken! Try another.{RESET}")
            else:
                print(f"{YELLOW}Invalid number! Choose a number between 1 and 9.{RESET}")
        except ValueError:
            print(f"{YELLOW}Please enter 1-9, 'u' to undo, or 'q' to quit.{RESET}")


def play_game():
    print_banner()

    print(f"{BOLD}Choose Game Mode:{RESET}")
    print("  1. 👤 Player vs 🤖 AI")
    print("  2. 👥 Two Players (Pass & Play)")

    while True:
        mode = input(f"{BOLD}Select mode (1 or 2): {RESET}").strip()
        if mode in ('1', '2'):
            break
        print(f"{YELLOW}Invalid choice. Enter 1 or 2.{RESET}")

    difficulty = 'impossible'
    human_mark = 'X'
    ai_mark = 'O'

    if mode == '1':
        print(f"\n{BOLD}Choose AI Difficulty:{RESET}")
        print("  1. Easy (Casual random)")
        print("  2. Medium (Balanced)")
        print("  3. Impossible (Minimax AI)")
        while True:
            diff_choice = input(f"{BOLD}Select difficulty (1-3): {RESET}").strip()
            if diff_choice == '1':
                difficulty = 'easy'
                break
            elif diff_choice == '2':
                difficulty = 'medium'
                break
            elif diff_choice == '3':
                difficulty = 'impossible'
                break
            print(f"{YELLOW}Invalid choice. Enter 1, 2, or 3.{RESET}")

        while True:
            side = input(f"{BOLD}Choose your side (X goes first, O goes second) [X/O]: {RESET}").strip().upper()
            if side in ('X', 'O'):
                human_mark = side
                ai_mark = 'O' if side == 'X' else 'X'
                break
            print(f"{YELLOW}Invalid side. Enter X or O.{RESET}")

    scores = {'X': 0, 'O': 0, 'Ties': 0}
    streak = 0
    best_streak = 0

    while True:
        board = [' '] * 9
        move_history = []
        current_turn = 'X'
        print("\n" + "=" * 42)
        print(f"{BOLD}New Round! Enter 1-9 to place your marker:{RESET}")

        while True:
            display_board(board)

            if mode == '1':
                if current_turn == human_mark:
                    action = get_player_move(board, "You", human_mark, can_undo=(len(move_history) >= 2 or len(move_history) == 1))
                    if action == 'undo':
                        if len(move_history) >= 2:
                            m1 = move_history.pop()
                            m2 = move_history.pop()
                            board[m1] = ' '
                            board[m2] = ' '
                            print(f"{YELLOW}Undid last turn.{RESET}")
                        elif len(move_history) == 1:
                            m = move_history.pop()
                            board[m] = ' '
                            current_turn = human_mark
                            print(f"{YELLOW}Undid move.{RESET}")
                        continue
                    move = action
                else:
                    print(f"{YELLOW}🤖 AI ({ai_mark}) is thinking...{RESET}")
                    move = get_ai_move(board, difficulty, ai_mark, human_mark)
            else:
                player_name = "Player 1" if current_turn == 'X' else "Player 2"
                action = get_player_move(board, player_name, current_turn, can_undo=(len(move_history) > 0))
                if action == 'undo':
                    m = move_history.pop()
                    board[m] = ' '
                    current_turn = 'O' if current_turn == 'X' else 'X'
                    print(f"{YELLOW}Undid move. Now {current_turn}'s turn.{RESET}")
                    continue
                move = action

            board[move] = current_turn
            move_history.append(move)

            # Check victory
            win_combo = check_win(board, current_turn)
            if win_combo:
                display_board(board, win_indices=win_combo)
                scores[current_turn] += 1
                if mode == '1':
                    if current_turn == human_mark:
                        streak += 1
                        if streak > best_streak:
                            best_streak = streak
                        print(f"{GREEN}{BOLD}🎉 VICTORY! You won! (Streak: 🔥 {streak}){RESET}\n")
                    else:
                        streak = 0
                        print(f"{RED}{BOLD}🤖 AI took this round! (Streak reset){RESET}\n")
                else:
                    winner_color = CYAN if current_turn == 'X' else RED
                    print(f"{GREEN}{BOLD}🎉 Player {winner_color}{current_turn}{RESET}{GREEN}{BOLD} wins!{RESET}\n")
                break

            # Check tie
            if is_board_full(board):
                display_board(board)
                scores['Ties'] += 1
                streak = 0
                print(f"{YELLOW}{BOLD}🤝 It's a draw!{RESET}\n")
                break

            # Switch turn
            current_turn = 'O' if current_turn == 'X' else 'X'

        # Scorecard
        total_games = scores['X'] + scores['O'] + scores['Ties']
        print(f"{BOLD}📊 Scoreboard:{RESET} Player X: {scores['X']} │ Player O: {scores['O']} │ Ties: {scores['Ties']}")
        if mode == '1':
            print(f"🔥 Current Streak: {streak} │ ⭐ Best Streak: {best_streak} │ Total Games: {total_games}")

        again = input(f"\n{BOLD}Play another round? (y/n): {RESET}").strip().lower()
        if again not in ('y', 'yes'):
            print(f"\n{CYAN}{BOLD}Thanks for playing Tic Tac Toe Deluxe!{RESET}\n")
            break


if __name__ == '__main__':
    try:
        play_game()
    except KeyboardInterrupt:
        print("\n\nGame exited. Goodbye!")
        sys.exit(0)
