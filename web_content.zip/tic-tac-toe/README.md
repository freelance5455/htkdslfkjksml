# 🎮 Tic Tac Toe Deluxe

A polished, responsive Tic Tac Toe game with an arcade-grade **Web UI** and an enhanced **Terminal CLI**.

---

## 🌟 Key Features

### 🌐 Web Experience
- **4 Visual Themes**:
  - **Cyberpunk**: Dark slate with neon cyan and magenta accents.
  - **Retro Arcade**: High-contrast 8-bit aesthetic with arcade green and hot pink.
  - **Midnight Gold**: Obsidian black with warm amber & gold highlights.
  - **Pastel Dream**: Soft, clean modern pastel design.
- **Victory Celebration**: Custom particle confetti burst on victory.
- **Glowing Strike-Through**: Animated SVG strike line tracing across winning rows, columns, or diagonals.
- **Ghost Hover Previews**: Shows a translucent preview of your marker before clicking on any empty cell.
- **Blitz / Speed Mode**: Optional turn timer (5s Blitz or 10s Standard) with a smooth animated countdown bar.
- **Undo Move (`↩ Undo`)**: Easily step back if you make a misclick.
- **Win Streaks & Analytics**: Tracks current win streak (🔥), personal best (⭐), and overall win rate (%).
- **Synthesized Audio**: Procedural move sounds, win fanfare, tie tones, and buzzer via Web Audio API (with 🔊/🔇 toggle).
- **Unbeatable AI**: Minimax algorithm with alpha-beta pruning, alongside Medium and Easy modes.

### 💻 Terminal CLI
- **Winning Line Highlight**: Winning 3-cell combo is highlighted with green background.
- **Undo Move**: Type `u` on your turn to undo moves.
- **Stats Tracking**: Keeps track of streaks and round scores in real-time.
- **ANSI Colorized Display**: Distinct colors for X and O.

---

## 🚀 How to Run

### Web Version
Launch a local server inside the project directory:
```bash
python3 -m http.server 8080 --directory /workspace/tic-tac-toe
```
Open [http://localhost:8080](http://localhost:8080) in your browser.

### Terminal CLI Version
Run directly from your shell:
```bash
python3 /workspace/tic-tac-toe/tic_tac_toe.py
```
