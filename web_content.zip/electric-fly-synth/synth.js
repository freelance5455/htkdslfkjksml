/**
 * Electric Fly Synth – Web Audio engine
 * Polyphonic, with filter, envelope, LFO, swarm (unison), chorus, delay, reverb
 */

class ElectricFlySynth {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.filter = null;
    this.lfo = null;
    this.lfoGain = null;
    this.chorus = null;
    this.delay = null;
    this.reverb = null;
    this.analyser = null;
    this.voices = new Map(); // note -> voice objects
    this.activeNotes = new Set();
    this.params = {
      wave: 'sawtooth',
      tuning: 0,       // cents
      cutoff: 0.68,
      resonance: 0.22,
      attack: 0.08,
      release: 0.28,
      lfo: 0.12,
      swarm: 0.18,
      chorus: 0.14,
      delay: 0.12,
      reverb: 0.18,
      master: 0.72,
      muted: false,
      masterOn: true
    };
    this.octave = 3;
    this.maxVoices = 12;
  }

  async init() {
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();

    // Master chain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = this.params.master;

    // Analyser for visualizer
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.smoothingTimeConstant = 0.75;

    // Filter (shared lowpass)
    this.filter = this.ctx.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.frequency.value = this._cutoffHz();
    this.filter.Q.value = this._resQ();

    // LFO
    this.lfo = this.ctx.createOscillator();
    this.lfo.type = 'sine';
    this.lfo.frequency.value = 4.5;
    this.lfoGain = this.ctx.createGain();
    this.lfoGain.gain.value = this.params.lfo * 800;
    this.lfo.connect(this.lfoGain);
    this.lfoGain.connect(this.filter.frequency);
    this.lfo.start();

    // Simple chorus (delay + LFO)
    this.chorus = this._createChorus();

    // Delay
    this.delay = this._createDelay();

    // Reverb (convolver with generated impulse)
    this.reverb = this._createReverb();

    // Routing: filter -> chorus -> delay -> reverb dry/wet -> analyser -> master -> destination
    this.filter.connect(this.chorus.input);
    this.chorus.output.connect(this.delay.input);
    this.delay.output.connect(this.reverb.input);
    this.reverb.output.connect(this.analyser);
    this.analyser.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);

    this._updateAllParams();
  }

  async resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }

  _cutoffHz() {
    // Map 0-1 to ~80 Hz – 12 kHz (exponential-ish)
    const t = this.params.cutoff;
    return 80 * Math.pow(150, t);
  }

  _resQ() {
    return 0.5 + this.params.resonance * 18;
  }

  _createChorus() {
    const input = this.ctx.createGain();
    const delayNode = this.ctx.createDelay(0.05);
    delayNode.delayTime.value = 0.012;
    const lfo = this.ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 0.8;
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 0.004;
    lfo.connect(lfoGain);
    lfoGain.connect(delayNode.delayTime);
    lfo.start();

    const wet = this.ctx.createGain();
    const dry = this.ctx.createGain();
    const output = this.ctx.createGain();

    input.connect(dry);
    input.connect(delayNode);
    delayNode.connect(wet);
    dry.connect(output);
    wet.connect(output);

    return { input, output, wet, dry, setAmount: (v) => {
      wet.gain.value = v * 0.55;
      dry.gain.value = 1 - v * 0.25;
    }};
  }

  _createDelay() {
    const input = this.ctx.createGain();
    const delayNode = this.ctx.createDelay(1.0);
    delayNode.delayTime.value = 0.28;
    const feedback = this.ctx.createGain();
    feedback.gain.value = 0.35;
    const wet = this.ctx.createGain();
    const dry = this.ctx.createGain();
    const output = this.ctx.createGain();

    input.connect(dry);
    input.connect(delayNode);
    delayNode.connect(feedback);
    feedback.connect(delayNode);
    delayNode.connect(wet);
    dry.connect(output);
    wet.connect(output);

    return { input, output, wet, dry, setAmount: (v) => {
      wet.gain.value = v * 0.5;
      dry.gain.value = 1 - v * 0.2;
      feedback.gain.value = 0.2 + v * 0.35;
    }};
  }

  _createReverb() {
    const input = this.ctx.createGain();
    const convolver = this.ctx.createConvolver();
    const wet = this.ctx.createGain();
    const dry = this.ctx.createGain();
    const output = this.ctx.createGain();

    // Generate a simple impulse response
    const rate = this.ctx.sampleRate;
    const length = rate * 1.8;
    const impulse = this.ctx.createBuffer(2, length, rate);
    for (let ch = 0; ch < 2; ch++) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2.2);
      }
    }
    convolver.buffer = impulse;

    input.connect(dry);
    input.connect(convolver);
    convolver.connect(wet);
    dry.connect(output);
    wet.connect(output);

    return { input, output, wet, dry, setAmount: (v) => {
      wet.gain.value = v * 0.65;
      dry.gain.value = 1 - v * 0.3;
    }};
  }

  noteToFreq(midi) {
    // A4 = 440, midi 69
    const cents = this.params.tuning;
    return 440 * Math.pow(2, (midi - 69 + cents / 100) / 12);
  }

  noteOn(midi, velocity = 0.85) {
    if (!this.ctx) return;
    this.resume();

    // Limit polyphony
    if (this.voices.size >= this.maxVoices && !this.voices.has(midi)) {
      const oldest = this.voices.keys().next().value;
      this.noteOff(oldest, true);
    }

    // Retrigger if already playing
    if (this.voices.has(midi)) {
      this.noteOff(midi, true);
    }

    const now = this.ctx.currentTime;
    const freq = this.noteToFreq(midi);
    const attack = 0.005 + this.params.attack * 0.9;
    const swarm = this.params.swarm;

    // Unison / swarm: 1–5 detuned oscillators
    const count = 1 + Math.round(swarm * 4);
    const oscillators = [];
    const voiceGain = this.ctx.createGain();
    voiceGain.gain.setValueAtTime(0, now);
    voiceGain.gain.linearRampToValueAtTime(velocity * (0.55 / Math.sqrt(count)), now + attack);

    for (let i = 0; i < count; i++) {
      const osc = this.ctx.createOscillator();
      osc.type = this.params.wave;
      const detune = count === 1 ? 0 : ((i / (count - 1)) - 0.5) * swarm * 28;
      osc.frequency.setValueAtTime(freq, now);
      osc.detune.setValueAtTime(detune, now);
      osc.connect(voiceGain);
      osc.start(now);
      oscillators.push(osc);
    }

    voiceGain.connect(this.filter);

    this.voices.set(midi, { oscillators, gain: voiceGain, start: now });
    this.activeNotes.add(midi);
  }

  noteOff(midi, immediate = false) {
    const voice = this.voices.get(midi);
    if (!voice) return;

    const now = this.ctx.currentTime;
    const release = immediate ? 0.02 : 0.04 + this.params.release * 1.6;

    voice.gain.gain.cancelScheduledValues(now);
    voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
    voice.gain.gain.linearRampToValueAtTime(0.0001, now + release);

    voice.oscillators.forEach(osc => {
      try { osc.stop(now + release + 0.05); } catch (_) {}
    });

    setTimeout(() => {
      voice.oscillators.forEach(osc => {
        try { osc.disconnect(); } catch (_) {}
      });
      try { voice.gain.disconnect(); } catch (_) {}
      this.voices.delete(midi);
      this.activeNotes.delete(midi);
    }, (release + 0.1) * 1000);
  }

  allNotesOff() {
    for (const midi of [...this.voices.keys()]) {
      this.noteOff(midi, true);
    }
  }

  setParam(name, value) {
    if (!(name in this.params)) return;
    this.params[name] = value;

    if (!this.ctx) return;

    switch (name) {
      case 'cutoff':
        this.filter.frequency.setTargetAtTime(this._cutoffHz(), this.ctx.currentTime, 0.03);
        break;
      case 'resonance':
        this.filter.Q.setTargetAtTime(this._resQ(), this.ctx.currentTime, 0.03);
        break;
      case 'lfo':
        this.lfoGain.gain.setTargetAtTime(value * 800, this.ctx.currentTime, 0.05);
        break;
      case 'chorus':
        this.chorus.setAmount(value);
        break;
      case 'delay':
        this.delay.setAmount(value);
        break;
      case 'reverb':
        this.reverb.setAmount(value);
        break;
      case 'master':
        if (!this.params.muted && this.params.masterOn) {
          this.masterGain.gain.setTargetAtTime(value, this.ctx.currentTime, 0.02);
        }
        break;
      case 'muted':
      case 'masterOn':
        const on = this.params.masterOn && !this.params.muted;
        this.masterGain.gain.setTargetAtTime(on ? this.params.master : 0, this.ctx.currentTime, 0.02);
        break;
      case 'wave':
        // New notes will use the new wave; existing keep their wave
        break;
      case 'tuning':
        // Update currently playing notes
        for (const [midi, voice] of this.voices) {
          const freq = this.noteToFreq(midi);
          voice.oscillators.forEach(osc => {
            osc.frequency.setTargetAtTime(freq, this.ctx.currentTime, 0.01);
          });
        }
        break;
    }
  }

  _updateAllParams() {
    this.setParam('cutoff', this.params.cutoff);
    this.setParam('resonance', this.params.resonance);
    this.setParam('lfo', this.params.lfo);
    this.setParam('chorus', this.params.chorus);
    this.setParam('delay', this.params.delay);
    this.setParam('reverb', this.params.reverb);
    this.setParam('master', this.params.master);
  }

  getAnalyserData() {
    if (!this.analyser) return null;
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteTimeDomainData(data);
    return data;
  }

  getActiveVoiceCount() {
    return this.voices.size;
  }

  // Presets
  static PRESETS = {
    'Electric Fly': {
      wave: 'sawtooth', tuning: 0, cutoff: 0.68, resonance: 0.22,
      attack: 0.08, release: 0.28, lfo: 0.12, swarm: 0.18,
      chorus: 0.14, delay: 0.12, reverb: 0.18, master: 0.72
    },
    'Neon Cicada': {
      wave: 'square', tuning: 3, cutoff: 0.55, resonance: 0.45,
      attack: 0.02, release: 0.15, lfo: 0.35, swarm: 0.08,
      chorus: 0.22, delay: 0.25, reverb: 0.12, master: 0.68
    },
    'Copper Wasp': {
      wave: 'sawtooth', tuning: -4, cutoff: 0.42, resonance: 0.62,
      attack: 0.04, release: 0.45, lfo: 0.08, swarm: 0.32,
      chorus: 0.18, delay: 0.08, reverb: 0.28, master: 0.70
    },
    'Glasswing': {
      wave: 'triangle', tuning: 0, cutoff: 0.78, resonance: 0.12,
      attack: 0.15, release: 0.55, lfo: 0.05, swarm: 0.05,
      chorus: 0.28, delay: 0.18, reverb: 0.42, master: 0.65
    },
    'Night Drone': {
      wave: 'sine', tuning: -7, cutoff: 0.35, resonance: 0.18,
      attack: 0.45, release: 0.85, lfo: 0.22, swarm: 0.42,
      chorus: 0.35, delay: 0.32, reverb: 0.55, master: 0.60
    }
  };

  loadPreset(name) {
    const p = ElectricFlySynth.PRESETS[name];
    if (!p) return;
    Object.keys(p).forEach(k => {
      this.params[k] = p[k];
      this.setParam(k, p[k]);
    });
  }

  getState() {
    return { ...this.params };
  }

  loadState(state) {
    if (!state) return;
    Object.keys(state).forEach(k => {
      if (k in this.params) {
        this.params[k] = state[k];
        this.setParam(k, state[k]);
      }
    });
  }
}

window.ElectricFlySynth = ElectricFlySynth;
