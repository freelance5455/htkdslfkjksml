/**
 * Electric Fly Synth – UI & interaction layer
 */

(() => {
  const synth = new ElectricFlySynth();
  let currentOctave = 3;
  let isMuted = false;
  let deferredInstallPrompt = null;

  // MIDI state
  let midiAccess = null;
  let midiSustain = false;
  const midiHeld = new Set();       // notes currently held by MIDI input
  const midiSustained = new Set();  // notes held by sustain pedal
  const midiOutChannel = 0;         // MIDI channel 1 (0-indexed)
  let hasMidiOut = false;

  // MIDI note mapping for the visible keyboard (2 octaves starting at C of current octave)
  // White keys: C D E F G A B  (indices 0,2,4,5,7,9,11 relative)
  const WHITE_OFFSETS = [0, 2, 4, 5, 7, 9, 11];
  const BLACK_MAP = [
    { offset: 1, left: 4.4 },   // C#
    { offset: 3, left: 11.0667 }, // D#
    { offset: 6, left: 24.4 },  // F#
    { offset: 8, left: 31.0667 }, // G#
    { offset: 10, left: 37.7333 }, // A#
  ];

  // Computer keyboard mapping (A–L = white + black in one octave)
  const KEY_MAP = {
    'a': 0, 'w': 1, 's': 2, 'e': 3, 'd': 4,
    'f': 5, 't': 6, 'g': 7, 'y': 8, 'h': 9,
    'u': 10, 'j': 11, 'k': 12, 'o': 13, 'l': 14
  };

  // ---------- DOM helpers ----------
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  function updateSliderFill(el) {
    const min = +el.min || 0;
    const max = +el.max || 100;
    const val = +el.value;
    const pct = ((val - min) / (max - min)) * 100;
    el.style.setProperty('--fill', pct + '%');
  }

  function setValueDisplay(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }

  // ---------- Keyboard rendering ----------
  function buildKeyboard() {
    const bed = $('#keybed');
    bed.innerHTML = '';

    // White keys (15 = 2 octaves + 1)
    for (let i = 0; i < 15; i++) {
      const oct = Math.floor(i / 7);
      const idx = i % 7;
      const midiOffset = WHITE_OFFSETS[idx] + oct * 12;
      const noteName = ['C','D','E','F','G','A','B'][idx];

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'key-white';
      btn.dataset.midi = midiOffset;
      btn.setAttribute('aria-label', `Play ${noteName}${currentOctave + oct}`);
      btn.innerHTML = `<span>${noteName}</span>`;
      bed.appendChild(btn);
    }

    // Black keys overlay
    const overlay = document.createElement('div');
    overlay.className = 'black-overlay';
    overlay.style.cssText = 'position:absolute;inset:0;pointer-events:none;';

    // Two octaves of black keys
    for (let oct = 0; oct < 2; oct++) {
      BLACK_MAP.forEach(({ offset, left }) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'key-black';
        btn.dataset.midi = offset + oct * 12;
        btn.style.left = (left + oct * 50) + '%';
        btn.style.width = '4.4%';
        btn.style.pointerEvents = 'auto';
        const names = {1:'C♯',3:'D♯',6:'F♯',8:'G♯',10:'A♯'};
        btn.innerHTML = `<span class="sr-only">${names[offset]}</span>`;
        overlay.appendChild(btn);
      });
    }
    bed.appendChild(overlay);

    // Event listeners (pointer events for touch + mouse)
    bed.querySelectorAll('button').forEach(btn => {
      const midiRel = +btn.dataset.midi;

      const down = (e) => {
        e.preventDefault();
        btn.classList.add('active');
        const midi = midiRel + (currentOctave + 1) * 12; // C3 = midi 48 when octave=3
        synth.noteOn(midi);
        sendMidiNoteOn(midi);
        updateVoiceCount();
      };
      const up = (e) => {
        e.preventDefault();
        btn.classList.remove('active');
        const midi = midiRel + (currentOctave + 1) * 12;
        synth.noteOff(midi);
        sendMidiNoteOff(midi);
        updateVoiceCount();
      };

      btn.addEventListener('pointerdown', down);
      btn.addEventListener('pointerup', up);
      btn.addEventListener('pointerleave', up);
      btn.addEventListener('pointercancel', up);
    });
  }

  function updateVoiceCount() {
    const n = synth.getActiveVoiceCount();
    const el = $('#voice-count');
    if (el) el.textContent = String(n).padStart(2, '0') + ' VOICES';
  }

  // ---------- Visualizer ----------
  function startVisualizer() {
    const canvas = $('#visualizer');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    }
    resize();
    window.addEventListener('resize', resize);

    function draw() {
      requestAnimationFrame(draw);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);

      const data = synth.getAnalyserData();
      if (!data) {
        // Idle line
        ctx.strokeStyle = 'rgba(240,212,90,0.25)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, h / 2);
        ctx.lineTo(w, h / 2);
        ctx.stroke();
        return;
      }

      ctx.strokeStyle = '#f0d45a';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      const slice = w / data.length;
      for (let i = 0; i < data.length; i++) {
        const v = data[i] / 128.0;
        const y = (v * h) / 2;
        if (i === 0) ctx.moveTo(0, y);
        else ctx.lineTo(i * slice, y);
      }
      ctx.stroke();
    }
    draw();
  }

  // ---------- Controls binding ----------
  function bindControls() {
    // Waveform buttons
    $$('.wave-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.wave-btn').forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-pressed', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-pressed', 'true');
        synth.setParam('wave', btn.dataset.wave);
        markCustom();
      });
    });

    // Range sliders
    const sliders = {
      tuning: { id: 'val-tuning', fmt: v => (v >= 0 ? '+' : '') + v + ' ct' },
      cutoff: { id: 'val-cutoff', fmt: v => v + '%' },
      resonance: { id: 'val-resonance', fmt: v => v + '%' },
      attack: { id: 'val-attack', fmt: v => v + '%' },
      release: { id: 'val-release', fmt: v => v + '%' },
      lfo: { id: 'val-lfo', fmt: v => v + '%' },
      swarm: { id: 'val-swarm', fmt: v => v + '%' },
      chorus: { id: 'val-chorus', fmt: v => v + '%' },
      delay: { id: 'val-delay', fmt: v => v + '%' },
      reverb: { id: 'val-reverb', fmt: v => v + '%' },
      master: { id: 'val-master', fmt: v => v + '%' }
    };

    // CC numbers to mirror out when the user moves these controls
    const PARAM_CC = {
      lfo: 1,       // Mod wheel
      master: 7,    // Volume
      resonance: 71,
      cutoff: 74
    };

    Object.entries(sliders).forEach(([name, conf]) => {
      const el = document.getElementById(name);
      if (!el) return;
      updateSliderFill(el);
      el.addEventListener('input', () => {
        updateSliderFill(el);
        const val = +el.value;
        setValueDisplay(conf.id, conf.fmt(val));
        // Normalize most to 0-1
        const paramVal = name === 'tuning' ? val : val / 100;
        synth.setParam(name, paramVal);
        if (PARAM_CC[name] !== undefined) {
          sendMidiCC(PARAM_CC[name], paramVal);
        }
        markCustom();
      });
    });

    // Octave
    $('#oct-down').addEventListener('click', () => {
      currentOctave = Math.max(1, currentOctave - 1);
      $('#octave-display').textContent = 'OCT ' + currentOctave;
      synth.allNotesOff();
    });
    $('#oct-up').addEventListener('click', () => {
      currentOctave = Math.min(6, currentOctave + 1);
      $('#octave-display').textContent = 'OCT ' + currentOctave;
      synth.allNotesOff();
    });

    // Mute
    $('#btn-mute').addEventListener('click', () => {
      isMuted = !isMuted;
      synth.setParam('muted', isMuted);
      const btn = $('#btn-mute');
      btn.classList.toggle('muted', isMuted);
      btn.setAttribute('aria-pressed', isMuted);
    });

    // Master toggle
    $('#master-toggle').addEventListener('click', () => {
      const on = !synth.params.masterOn;
      synth.setParam('masterOn', on);
      const toggle = $('#master-toggle .toggle');
      toggle.classList.toggle('on', on);
      $('#master-toggle').setAttribute('aria-checked', on);
      $('#master-toggle span:last-child').textContent = on ? 'Master on' : 'Master off';
    });

    // Preset select
    $('#preset').addEventListener('change', (e) => {
      const name = e.target.value;
      if (name === 'Custom') {
        const saved = localStorage.getItem('efs-custom-patch');
        if (saved) {
          try {
            const state = JSON.parse(saved);
            applyStateToUI(state);
            synth.loadState(state);
          } catch (_) {}
        }
        return;
      }
      synth.loadPreset(name);
      applyStateToUI(synth.getState());
    });

    // Save patch
    $('#btn-save').addEventListener('click', () => {
      const state = synth.getState();
      localStorage.setItem('efs-custom-patch', JSON.stringify(state));
      $('#preset').value = 'Custom';
      // Brief feedback
      const btn = $('#btn-save');
      btn.style.borderColor = '#afd581';
      setTimeout(() => { btn.style.borderColor = ''; }, 600);
    });
  }

  function markCustom() {
    if ($('#preset').value !== 'Custom') {
      $('#preset').value = 'Custom';
    }
  }

  function applyStateToUI(state) {
    // Wave
    $$('.wave-btn').forEach(b => {
      const active = b.dataset.wave === state.wave;
      b.classList.toggle('active', active);
      b.setAttribute('aria-pressed', active);
    });

    // Sliders
    const map = {
      tuning: state.tuning,
      cutoff: Math.round(state.cutoff * 100),
      resonance: Math.round(state.resonance * 100),
      attack: Math.round(state.attack * 100),
      release: Math.round(state.release * 100),
      lfo: Math.round(state.lfo * 100),
      swarm: Math.round(state.swarm * 100),
      chorus: Math.round(state.chorus * 100),
      delay: Math.round(state.delay * 100),
      reverb: Math.round(state.reverb * 100),
      master: Math.round(state.master * 100)
    };
    Object.entries(map).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) {
        el.value = val;
        updateSliderFill(el);
      }
    });
    setValueDisplay('val-tuning', (state.tuning >= 0 ? '+' : '') + state.tuning + ' ct');
    setValueDisplay('val-cutoff', map.cutoff + '%');
    setValueDisplay('val-resonance', map.resonance + '%');
    setValueDisplay('val-attack', map.attack + '%');
    setValueDisplay('val-release', map.release + '%');
    setValueDisplay('val-lfo', map.lfo + '%');
    setValueDisplay('val-swarm', map.swarm + '%');
    setValueDisplay('val-chorus', map.chorus + '%');
    setValueDisplay('val-delay', map.delay + '%');
    setValueDisplay('val-reverb', map.reverb + '%');
    setValueDisplay('val-master', map.master + '%');
  }

  // ---------- Computer keyboard ----------
  const pressedKeys = new Set();

  function onKeyDown(e) {
    if (e.repeat) return;
    const key = e.key.toLowerCase();

    if (key === 'z') {
      currentOctave = Math.max(1, currentOctave - 1);
      $('#octave-display').textContent = 'OCT ' + currentOctave;
      return;
    }
    if (key === 'x') {
      currentOctave = Math.min(6, currentOctave + 1);
      $('#octave-display').textContent = 'OCT ' + currentOctave;
      return;
    }

    if (key in KEY_MAP) {
      e.preventDefault();
      const rel = KEY_MAP[key];
      const midi = rel + (currentOctave + 1) * 12;
      if (!pressedKeys.has(key)) {
        pressedKeys.add(key);
        synth.noteOn(midi);
        sendMidiNoteOn(midi);
        const btn = $(`#keybed button[data-midi="${rel}"]`);
        if (btn) btn.classList.add('active');
        updateVoiceCount();
      }
    }
  }

  function onKeyUp(e) {
    const key = e.key.toLowerCase();
    if (key in KEY_MAP) {
      const rel = KEY_MAP[key];
      const midi = rel + (currentOctave + 1) * 12;
      pressedKeys.delete(key);
      synth.noteOff(midi);
      sendMidiNoteOff(midi);
      const btn = $(`#keybed button[data-midi="${rel}"]`);
      if (btn) btn.classList.remove('active');
      updateVoiceCount();
    }
  }

  // ---------- MIDI input + output ----------
  function setMidiStatus(state, label) {
    const dot = $('#midi-dot');
    const text = $('#midi-text');
    if (!dot || !text) return;
    dot.classList.remove('midi-off', 'midi-on', 'midi-active');
    if (state === 'off') {
      dot.classList.add('midi-off');
      text.textContent = label || 'NO MIDI';
    } else if (state === 'on') {
      dot.classList.add('midi-on');
      text.textContent = label || 'MIDI';
    } else if (state === 'active') {
      dot.classList.add('midi-active');
      text.textContent = label || 'MIDI';
    }
  }

  function updateMidiStatusLabel() {
    if (!midiAccess) {
      setMidiStatus('off', 'NO MIDI');
      return;
    }
    const inputs = [...midiAccess.inputs.values()];
    const outputs = [...midiAccess.outputs.values()];
    hasMidiOut = outputs.length > 0;

    if (inputs.length === 0 && outputs.length === 0) {
      setMidiStatus('off', 'NO MIDI');
      return;
    }

    let label = 'MIDI';
    if (inputs.length && outputs.length) {
      label = 'MIDI I/O';
    } else if (outputs.length) {
      label = 'MIDI OUT';
    } else {
      const name = inputs[0].name || 'MIDI';
      label = name.length > 12 ? name.slice(0, 10) + '…' : name;
    }
    setMidiStatus('on', label);
  }

  function highlightMidiKey(midi, on) {
    const base = (currentOctave + 1) * 12;
    const rel = midi - base;
    if (rel < 0 || rel > 24) return;
    const btn = $(`#keybed button[data-midi="${rel}"]`);
    if (btn) btn.classList.toggle('active', on);
  }

  /** Send Note On to all connected MIDI outputs */
  function sendMidiNoteOn(note, velocity = 0.85) {
    if (!midiAccess || !hasMidiOut) return;
    const vel = Math.max(1, Math.min(127, Math.round(velocity * 127)));
    const msg = [0x90 | midiOutChannel, note & 0x7f, vel];
    for (const output of midiAccess.outputs.values()) {
      try { output.send(msg); } catch (_) {}
    }
  }

  /** Send Note Off to all connected MIDI outputs */
  function sendMidiNoteOff(note) {
    if (!midiAccess || !hasMidiOut) return;
    const msg = [0x80 | midiOutChannel, note & 0x7f, 0];
    for (const output of midiAccess.outputs.values()) {
      try { output.send(msg); } catch (_) {}
    }
  }

  /** Send a Control Change to all outputs */
  function sendMidiCC(cc, value) {
    if (!midiAccess || !hasMidiOut) return;
    const val = Math.max(0, Math.min(127, Math.round(value * 127)));
    const msg = [0xb0 | midiOutChannel, cc & 0x7f, val];
    for (const output of midiAccess.outputs.values()) {
      try { output.send(msg); } catch (_) {}
    }
  }

  function handleMidiMessage(event) {
    const [status, data1, data2] = event.data;
    const cmd = status & 0xf0;
    const note = data1;
    const velocity = data2 / 127;

    // Note On
    if (cmd === 0x90 && data2 > 0) {
      midiHeld.add(note);
      midiSustained.delete(note);
      synth.noteOn(note, Math.max(0.15, velocity));
      highlightMidiKey(note, true);
      setMidiStatus('active', 'MIDI I/O');
      updateVoiceCount();
      return;
    }

    // Note Off (or Note On with velocity 0)
    if (cmd === 0x80 || (cmd === 0x90 && data2 === 0)) {
      midiHeld.delete(note);
      if (midiSustain) {
        midiSustained.add(note);
      } else {
        synth.noteOff(note);
        highlightMidiKey(note, false);
        updateVoiceCount();
      }
      if (midiHeld.size === 0) updateMidiStatusLabel();
      return;
    }

    // Control Change
    if (cmd === 0xb0) {
      const cc = data1;
      const val = data2 / 127;

      // CC 64 – Sustain pedal
      if (cc === 64) {
        const wasOn = midiSustain;
        midiSustain = data2 >= 64;
        if (wasOn && !midiSustain) {
          for (const n of [...midiSustained]) {
            if (!midiHeld.has(n)) {
              synth.noteOff(n);
              highlightMidiKey(n, false);
            }
          }
          midiSustained.clear();
          updateVoiceCount();
        }
        return;
      }

      // CC 1 – Mod wheel → LFO amount
      if (cc === 1) {
        synth.setParam('lfo', val);
        const el = $('#lfo');
        if (el) {
          el.value = Math.round(val * 100);
          updateSliderFill(el);
          setValueDisplay('val-lfo', Math.round(val * 100) + '%');
        }
        markCustom();
        return;
      }

      // CC 7 – Volume → Master
      if (cc === 7) {
        synth.setParam('master', val);
        const el = $('#master');
        if (el) {
          el.value = Math.round(val * 100);
          updateSliderFill(el);
          setValueDisplay('val-master', Math.round(val * 100) + '%');
        }
        return;
      }

      // CC 74 – Filter cutoff
      if (cc === 74) {
        synth.setParam('cutoff', val);
        const el = $('#cutoff');
        if (el) {
          el.value = Math.round(val * 100);
          updateSliderFill(el);
          setValueDisplay('val-cutoff', Math.round(val * 100) + '%');
        }
        markCustom();
        return;
      }

      // CC 71 – Resonance
      if (cc === 71) {
        synth.setParam('resonance', val);
        const el = $('#resonance');
        if (el) {
          el.value = Math.round(val * 100);
          updateSliderFill(el);
          setValueDisplay('val-resonance', Math.round(val * 100) + '%');
        }
        markCustom();
        return;
      }
    }
  }

  function bindMidiInputs() {
    if (!midiAccess) return;
    for (const input of midiAccess.inputs.values()) {
      input.onmidimessage = handleMidiMessage;
    }
  }

  async function initMIDI() {
    if (!navigator.requestMIDIAccess) {
      setMidiStatus('off', 'NO MIDI');
      return;
    }
    try {
      midiAccess = await navigator.requestMIDIAccess({ sysex: false });
      updateMidiStatusLabel();
      bindMidiInputs();

      midiAccess.onstatechange = () => {
        updateMidiStatusLabel();
        bindMidiInputs();
      };
    } catch (err) {
      console.warn('MIDI access denied or failed:', err);
      setMidiStatus('off', 'NO MIDI');
    }
  }

  // ---------- Online / offline status ----------
  function updateNetworkStatus() {
    const online = navigator.onLine;
    const netDots = document.querySelectorAll('#network-status .dot, #footer-status .dot');
    netDots.forEach(d => d.classList.toggle('offline', !online));
    const text = online ? 'ONLINE' : 'OFFLINE';
    const footer = online ? 'ONLINE · INSTALL FOR OFFLINE' : 'OFFLINE · READY';
    const st = $('#status-text');
    const ft = $('#footer-status-text');
    if (st) st.textContent = text;
    if (ft) ft.textContent = footer;
  }

  // ---------- PWA install ----------
  function setupInstall() {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredInstallPrompt = e;
      const btn = $('#btn-install');
      if (btn) btn.hidden = false;
    });

    $('#btn-install')?.addEventListener('click', async () => {
      if (!deferredInstallPrompt) return;
      deferredInstallPrompt.prompt();
      const { outcome } = await deferredInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        $('#btn-install').hidden = true;
      }
      deferredInstallPrompt = null;
    });

    window.addEventListener('appinstalled', () => {
      $('#btn-install').hidden = true;
    });
  }

  // ---------- Service Worker ----------
  function registerSW() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  // ---------- Boot ----------
  async function boot() {
    buildKeyboard();
    bindControls();
    startVisualizer();
    updateNetworkStatus();
    setupInstall();
    registerSW();
    initMIDI();

    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // First user gesture starts audio
    const startAudio = async () => {
      await synth.init();
      await synth.resume();
      document.removeEventListener('pointerdown', startAudio);
      document.removeEventListener('keydown', startAudio);
    };
    document.addEventListener('pointerdown', startAudio, { once: true });
    document.addEventListener('keydown', startAudio, { once: true });

    // Load default preset into UI
    applyStateToUI(ElectricFlySynth.PRESETS['Electric Fly']);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
