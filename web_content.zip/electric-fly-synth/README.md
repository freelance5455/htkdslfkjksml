# Electric Fly Synth — Offline Edition

A self-contained, fully offline synthesizer you can run in any modern browser or install as a Progressive Web App (PWA).

## Features

- Polyphonic keyboard (touch / mouse / computer keys)
- **MIDI input & output** (notes, velocity, sustain, mod wheel, filter CCs; notes & CCs sent to external gear)
- 5 factory presets + custom patch saving (localStorage)
- Waveforms: sawtooth, square, triangle, sine
- Filter (cutoff + resonance), envelope (attack / release)
- LFO, Swarm (unison detune), Chorus, Delay, Reverb
- Live signal visualizer
- Works completely offline after first load
- Installable on Android / desktop (Chrome / Edge)

## How to use

### Quickest – just open it

1. Open `index.html` in Chrome, Edge, Firefox or Safari.
2. Tap / click anywhere or press a key to start the audio engine.
3. Play the on-screen keyboard or use computer keys:
   - **A S D F G H J K L** – notes
   - **W E T Y U O** – black keys
   - **Z / X** – octave down / up

### Install as an app (recommended)

**Android (Chrome)**  
Open the page → tap the **Install** button (or browser menu → “Install app” / “Add to Home screen”).

**Desktop (Chrome / Edge)**  
Look for the install icon in the address bar, or use the **Install** button inside the app.

Once installed it runs like a native app and works offline.

### Fully offline folder

You can copy the entire `electric-fly-synth` folder to any device (USB, phone storage, etc.).  
As long as you open `index.html` from that folder (or serve it with any static file server), everything works without internet.

## Keyboard layout

```
White keys:  A  S  D  F  G  H  J  K  L
Black keys:   W  E   T  Y  U   O
Octave:      Z = down   X = up
```

## MIDI input & output

Connect any class-compliant MIDI keyboard, controller, or external synth.  
Uses the Web MIDI API (best support in Chrome, Edge, Opera).

### Input (controller → synth)

| Message / CC        | Action              |
|---------------------|---------------------|
| Note On / Off       | Play & release notes (with velocity) |
| CC 64               | Sustain pedal       |
| CC 1 (Mod wheel)    | LFO amount          |
| CC 7 (Volume)       | Master level        |
| CC 74               | Filter cutoff       |
| CC 71               | Resonance           |

### Output (synth → external gear)

Playing the on-screen keyboard or computer keys also sends MIDI Note On/Off (channel 1) to every connected output.

Moving these controls also sends the matching CC:

| Control   | CC sent |
|-----------|---------|
| LFO       | 1 (Mod) |
| Master    | 7 (Vol) |
| Resonance | 71      |
| Cutoff    | 74      |

The header shows **MIDI**, **MIDI OUT**, or **MIDI I/O** depending on what is connected.  
On-screen keys light up when MIDI notes are received.

## Saving patches

Adjust any control, then press the **Save** (disk) button.  
Your settings are stored in the browser under the “Custom” preset.

## Technical notes

- Pure Web Audio API – no external libraries
- Service Worker caches all assets for offline use
- No accounts, no tracking, no network requests after first load
- All sound processing stays on your device

Enjoy the buzz.
