/* Surf Dash automated tests (headless Chromium via Playwright).
 *
 *   cd tests && npm install playwright && npx playwright install chromium && node run-tests.js
 *
 * The game exposes extra hooks (window.SD_TEST) only when loaded with ?test=1.
 * These tests drive the real game code in a browser. They do NOT run on an Android device or WebView.
 */
const path = require('path');
let chromium;
try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright')); }

const URL = 'file://' + path.resolve(__dirname, '../app/src/main/assets/index.html') + '?test=1';
const SHOTS = path.resolve(__dirname, 'screenshots');
require('fs').mkdirSync(SHOTS, { recursive: true });

let browser; const results = []; let currentErrors = [];
const eq = (a, b, msg) => { if (a !== b) throw new Error(`${msg || 'expected equal'}: got ${JSON.stringify(a)}, expected ${JSON.stringify(b)}`); };
const ok = (c, msg) => { if (!c) throw new Error(msg || 'assertion failed'); };
const near = (a, b, tol, msg) => { if (Math.abs(a - b) > tol) throw new Error(`${msg || 'not near'}: got ${a}, expected ${b} ± ${tol}`); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function newPage(w = 854, h = 390, ctxOpt = {}) {
  const ctx = await browser.newContext(Object.assign({ viewport: { width: w, height: h }, hasTouch: true, deviceScaleFactor: 2 }, ctxOpt));
  const page = await ctx.newPage();
  page.on('pageerror', e => currentErrors.push('pageerror: ' + e));
  page.on('console', m => { if (m.type() === 'error') currentErrors.push('console: ' + m.text()); });
  await page.goto(URL); await page.waitForTimeout(250);
  page.ctx = ctx; return page;
}
async function test(name, fn) {
  if (process.env.ONLY && !name.includes(process.env.ONLY)) return;
  currentErrors = []; const t0 = Date.now();
  try { await fn(); if (currentErrors.length) throw new Error('JS errors: ' + currentErrors.join(' | ')); results.push({ name, pass: true, ms: Date.now() - t0 }); console.log('  PASS', name); }
  catch (e) { results.push({ name, pass: false, err: e.message }); console.log('  FAIL', name, '\n       ', e.message); }
}
const S = page => page.evaluate(() => SD_TEST.s);
const startManual = async page => { await page.evaluate(() => { SD_TEST.startRun(); SD_TEST.manual = true; SD_TEST.clearCourse(); }); };
const swipe = (page, dx, dy, x0 = 427, y0 = 200, id = 1) => page.evaluate(([dx, dy, x0, y0, id]) => {
  const c = document.getElementById('game');
  const mk = (t, x, y) => new PointerEvent(t, { pointerId: id, clientX: x, clientY: y, bubbles: true, pointerType: 'touch', isPrimary: true });
  c.dispatchEvent(mk('pointerdown', x0, y0)); c.dispatchEvent(mk('pointerup', x0 + dx, y0 + dy));
}, [dx, dy, x0, y0, id]);
const pressAbility = page => page.evaluate(() => document.getElementById('abilityBtn').dispatchEvent(new PointerEvent('pointerdown', { pointerId: 9, bubbles: true, cancelable: true, pointerType: 'touch' })));

(async () => {
  browser = await chromium.launch();
  console.log('\n== Collision fairness ==');
  for (const w of [640, 740, 854, 915, 1000]) {
    await test(`collisions @${w}px: every lane/type hits when unavoided, adjacent lanes are safe`, async () => {
      const p = await newPage(w, 390); const out = [];
      for (const L of [0, 1, 2]) for (const type of ['jump', 'duck', 'block']) {
        await startManual(p);
        await p.evaluate(([L, type]) => { SD_TEST.setLane(L); SD_TEST.addObstacle(L, type, SD_TEST.HIT_Z - 0.03); SD_TEST.step(12); }, [L, type]);
        if ((await S(p)).running) out.push(`L${L}-${type} did not hit`);
        await p.evaluate(() => SD_TEST.showMenu('start'));
        // same obstacle in a neighbouring lane must not hurt
        await startManual(p);
        const N = L === 1 ? 0 : 1;
        await p.evaluate(([L, N, type]) => { SD_TEST.setLane(L); SD_TEST.addObstacle(N, type, SD_TEST.HIT_Z - 0.03); SD_TEST.step(12); }, [L, N, type]);
        if (!(await S(p)).running) out.push(`L${L} died to neighbour-lane ${type}`);
        await p.evaluate(() => SD_TEST.showMenu('start'));
      }
      eq(out.length, 0, out.join('; ')); await p.ctx.close();
    });
  }
  await test('correct avoid actions work in every lane (jump barrier, duck beam, lane-change around buoy)', async () => {
    const p = await newPage(); const out = [];
    for (const L of [0, 1, 2]) {
      await startManual(p);
      await p.evaluate(L => { SD_TEST.setLane(L); SD_TEST.addObstacle(L, 'jump', SD_TEST.HIT_Z - 0.1); SD_TEST.doJump(); SD_TEST.step(30); }, L); if (!(await S(p)).running) out.push(`jump L${L}`);
      await p.evaluate(() => SD_TEST.showMenu('start')); await startManual(p);
      await p.evaluate(L => { SD_TEST.setLane(L); SD_TEST.addObstacle(L, 'duck', SD_TEST.HIT_Z - 0.1); SD_TEST.doDuck(); SD_TEST.step(30); }, L); if (!(await S(p)).running) out.push(`duck L${L}`);
      await p.evaluate(() => SD_TEST.showMenu('start')); await startManual(p);
      await p.evaluate(L => { SD_TEST.setLane(L); SD_TEST.addObstacle(L, 'block', SD_TEST.HIT_Z - 0.2); SD_TEST.doLane(L === 1 ? 1 : (L === 0 ? 1 : -1)); SD_TEST.step(40); }, L); if (!(await S(p)).running) out.push(`lane-change L${L}`);
      await p.evaluate(() => SD_TEST.showMenu('start'));
    }
    eq(out.length, 0, out.join('; '));
    // wrong actions still hurt: jumping a duck beam / ducking a barrier / jumping a buoy
    for (const [type, act] of [['duck', 'doJump'], ['jump', 'doDuck'], ['block', 'doJump']]) {
      await startManual(p);
      const alive = await p.evaluate(([type, act]) => { SD_TEST.setLane(1); SD_TEST.addObstacle(1, type, SD_TEST.HIT_Z - 0.1); SD_TEST[act](); SD_TEST.step(30); return SD_TEST.s.running; }, [type, act]);
      ok(!alive, `${act} should not save you from ${type}`); await p.evaluate(() => SD_TEST.showMenu('start'));
    }
    await p.ctx.close();
  });

  console.log('\n== Controls ==');
  await test('swipes and taps: lane left/right, jump, duck, left/right half taps', async () => {
    const p = await newPage(); await startManual(p);
    await swipe(p, 80, 0); eq((await S(p)).lane, 2, 'swipe right'); await swipe(p, -80, 0); await swipe(p, -80, 0); eq((await S(p)).lane, 0, 'swipe left x2');
    await swipe(p, 80, 0); await swipe(p, 0, 0, 100, 200); eq((await S(p)).lane, 0, 'tap left half clamps at lane 0');
    await swipe(p, 0, 0, 700, 200); eq((await S(p)).lane, 1, 'tap right half');
    await swipe(p, 0, -80); ok((await S(p)).jump > 0.7, 'swipe up jumps'); await swipe(p, 0, 80); const s = await S(p); ok(s.duck > 0.5 && s.jump === 0, 'swipe down ducks and cancels jump');
    await p.ctx.close();
  });
  await test('multi-touch: a swipe with one finger and an ability tap with another both register once', async () => {
    const p = await newPage(); await startManual(p);
    await p.evaluate(() => { const c = document.getElementById('game'); c.dispatchEvent(new PointerEvent('pointerdown', { pointerId: 1, clientX: 300, clientY: 200, bubbles: true })); });
    await pressAbility(p);
    await p.evaluate(() => { const c = document.getElementById('game'); c.dispatchEvent(new PointerEvent('pointerup', { pointerId: 1, clientX: 380, clientY: 200, bubbles: true })); });
    const s = await S(p); eq(s.lane, 2, 'swipe still registered'); eq(await p.evaluate(() => SD_TEST.inst().phase), 'active', 'ability activated');
    await p.ctx.close();
  });

  console.log('\n== Coins ==');
  await test('coin pickup: right lane collects exactly once, wrong lane does not, balance updates immediately', async () => {
    const p = await newPage(); await startManual(p);
    await p.evaluate(() => { SD_TEST.setLane(1); SD_TEST.addCoinAt(1, SD_TEST.HIT_Z - 0.03); SD_TEST.addCoinAt(0, SD_TEST.HIT_Z - 0.03); SD_TEST.addCoinAt(2, SD_TEST.HIT_Z - 0.03); SD_TEST.step(20); });
    eq((await S(p)).runCoins, 1); eq(await p.evaluate(() => SD.Save.coins), 1); eq(await p.evaluate(() => document.getElementById('runCoins').textContent), '1', 'HUD counter');
    await p.evaluate(() => SD_TEST.step(200)); eq(await p.evaluate(() => SD.Save.coins), 1, 'no extra coins later'); await p.ctx.close();
  });
  await test('air coins need a jump; ground coins are skipped while high', async () => {
    const p = await newPage(); await startManual(p);
    await p.evaluate(() => { SD_TEST.setLane(1); SD_TEST.addCoinAt(1, SD_TEST.HIT_Z - 0.03, 1); SD_TEST.step(20); }); eq((await S(p)).runCoins, 0, 'air coin ignored on the ground');
    await p.evaluate(() => { SD_TEST.addCoinAt(1, SD_TEST.HIT_Z - 0.02, 1); SD_TEST.doJump(); SD_TEST.step(12); }); eq((await S(p)).runCoins, 1, 'air coin collected mid-jump');
    await p.evaluate(() => { SD_TEST.clearCourse(); SD_TEST.addCoinAt(1, SD_TEST.HIT_Z - 0.02, 0); SD_TEST.doJump(); SD_TEST.step(12); }); eq((await S(p)).runCoins, 1, 'ground coin skipped under a jump');
    await p.ctx.close();
  });
  await test('no duplicate rewards across pause/resume/restart (real-time loop)', async () => {
    const p = await newPage(); await p.evaluate(() => { SD_TEST.startRun(); SD_TEST.clearCourse(); SD_TEST.god(); });
    // coin about to be collected, then pause right before and wait; nothing may change while paused
    await p.evaluate(() => { SD_TEST.setLane(1); SD_TEST.addCoinAt(1, SD_TEST.HIT_Z - 0.2); });
    await p.waitForTimeout(150); await p.evaluate(() => SD_TEST.pause()); const before = await p.evaluate(() => [SD.Save.coins, SD_TEST.s.runCoins]);
    await p.waitForTimeout(1500); eq(JSON.stringify(await p.evaluate(() => [SD.Save.coins, SD_TEST.s.runCoins])), JSON.stringify(before), 'paused: no change');
    await p.evaluate(() => SD_TEST.resume()); await p.waitForTimeout(3600);
    const after = await p.evaluate(() => [SD.Save.coins, SD_TEST.s.runCoins]); eq(after[0], 1, 'collected exactly once after resume'); eq(after[1], 1);
    // restart keeps the bank and resets the run counter
    await p.evaluate(() => { SD_TEST.pause(); SD_TEST.showMenu('start'); SD_TEST.startRun(); SD_TEST.clearCourse(); });
    eq(await p.evaluate(() => [SD.Save.coins, SD_TEST.s.runCoins].join()), '1,0', 'restart: bank kept, run counter reset');
    await p.ctx.close();
  });
  await test('coins survive an app restart (reload), including pickups from the last 250 ms', async () => {
    const p = await newPage(); await startManual(p);
    await p.evaluate(() => { SD_TEST.setLane(1); for (let i = 0; i < 7; i++) { SD_TEST.addCoinAt(1, SD_TEST.HIT_Z - 0.03 - i * 0.03); } SD_TEST.step(60); });
    eq(await p.evaluate(() => SD.Save.coins), 7); await p.reload(); await p.waitForTimeout(250);
    eq(await p.evaluate(() => SD.Save.coins), 7, 'after reload'); eq(await p.evaluate(() => document.getElementById('menuBank').textContent), '7', 'menu shows saved balance'); await p.ctx.close();
  });

  console.log('\n== Shop ==');
  await test('purchase rules via the real UI: insufficient funds, exact deduction, ownership, equip, double-tap', async () => {
    const p = await newPage(); const buy = id => p.evaluate(id => document.querySelector(`.buy-btn[data-id="${id}"]`).click(), id);
    const st = () => p.evaluate(() => ({ c: SD.Save.coins, owned: SD.Save.data.owned.join(), eq: SD.Save.equipped, toast: document.getElementById('toast').textContent }));
    await p.click('#shopButton'); await p.waitForTimeout(400);
    let s = await st(); eq(s.owned, 'kai', 'starter is the only free character'); eq(s.eq, 'kai');
    await buy('luna'); s = await st(); eq(s.c, 0); eq(s.owned, 'kai'); ok(/Need 150/.test(s.toast), 'failure message: ' + s.toast);
    await p.evaluate(() => SD.Save.addCoins(149)); await buy('luna'); s = await st(); eq(s.c, 149, 'one coin short: no deduction'); eq(s.owned, 'kai');
    await p.evaluate(() => SD.Save.addCoins(1)); await buy('luna'); s = await st(); eq(s.c, 0, 'exactly 150 deducted'); eq(s.owned, 'kai,luna'); eq(s.eq, 'luna', 'auto-equipped');
    await buy('luna'); s = await st(); eq(s.c, 0, 'tapping equipped does nothing');
    await buy('kai'); s = await st(); eq(s.eq, 'kai', 'switch back for free'); eq(s.c, 0);
    await buy('luna'); s = await st(); eq(s.eq, 'luna', 'switch again for free'); eq(s.c, 0);
    await p.evaluate(() => SD.Save.addCoins(450));
    await p.evaluate(() => { const b = document.querySelector('.buy-btn[data-id="mako"]'); b.click(); b.click(); });   // frantic double tap
    s = await st(); eq(s.c, 50, 'double tap charges once (450 - 400)'); eq(s.owned, 'kai,luna,mako');
    eq(await p.evaluate(() => SD.Save.equip('tala')), false, 'cannot equip a locked character'); eq(await p.evaluate(() => SD.Save.purchase('tala', 750).ok), false); eq((await st()).c, 50);
    eq(await p.evaluate(() => SD.Save.purchase('luna', 150).reason), 'owned', 'cannot rebuy');
    await p.ctx.close();
  });
  await test('purchases, equipped character and settings persist across restart', async () => {
    const p = await newPage(); await p.evaluate(() => SD.Save.addCoins(600));
    await p.click('#shopButton'); await p.waitForTimeout(300); await p.evaluate(() => document.querySelector('.buy-btn[data-id="mako"]').click());
    await p.click('#shopBack'); await p.click('#musicToggle'); await p.reload(); await p.waitForTimeout(250);
    eq(await p.evaluate(() => JSON.stringify([SD.Save.coins, SD.Save.data.owned, SD.Save.equipped, SD.Save.settings.music, SD.Save.settings.sfx])), JSON.stringify([200, ['kai', 'mako'], 'mako', false, true]));
    eq(await p.evaluate(() => document.getElementById('menuName').textContent), 'Mako', 'menu card reflects equipped surfer');
    await p.ctx.close();
  });
  await test('equipping changes the real gameplay model and ability (all four surfers)', async () => {
    const p = await newPage(); await p.evaluate(() => SD.Save.addCoins(5000)); await p.click('#shopButton'); await p.waitForTimeout(300);
    const want = { kai: ['surge', 'Surge'], luna: ['tidepull', 'Tide Pull'], mako: ['skyflip', 'Sky Flip'], tala: ['coralward', 'Coral Ward'] };
    for (const id of Object.keys(want)) {
      await p.evaluate(id => { const b = document.querySelector(`.buy-btn[data-id="${id}"]`); b.click(); if (SD.Save.equipped !== id) b.click(); }, id);
      await p.click('#shopBack'); await p.waitForTimeout(150); await p.evaluate(() => SD_TEST.startRun());
      const r = await p.evaluate(() => ({ def: SD_TEST.def().id, ab: SD_TEST.inst().def.id, vis: !document.getElementById('abilityBtn').classList.contains('is-hidden'), label: document.getElementById('abilityBtn').getAttribute('aria-label') }));
      eq(r.def, id); eq(r.ab, want[id][0]); ok(r.vis, 'ability button visible'); eq(r.label, 'Use ' + want[id][1]);
      await p.evaluate(() => { SD_TEST.pause(); SD_TEST.showMenu('start'); }); await p.click('#shopButton'); await p.waitForTimeout(250);
    }
    await p.ctx.close();
  });

  console.log('\n== Abilities ==');
  const equip = async (p, id) => p.evaluate(id => { SD.Save.addCoins(5000); const def = SD.Characters.get(id); SD.Save.purchase(id, def.price); SD.Save.equip(id); }, id);
  await test('Surge: +40% speed / +25% score for 4.5 s, then 12 s cooldown, then ready', async () => {
    const p = await newPage(); await startManual(p); await p.evaluate(() => SD_TEST.god());
    await p.evaluate(() => { SD_TEST.setDistance(0); SD_TEST.setSpeed(300); SD_TEST.step(60); }); const dBase = await p.evaluate(() => SD_TEST.s.distance);
    await p.evaluate(() => { SD_TEST.setDistance(0); SD_TEST.setSpeed(300); }); await pressAbility(p);
    await p.evaluate(() => SD_TEST.step(135)); // 2.25 s: mid-ability
    const mid = await p.evaluate(() => ({ m: Object.assign({}, SD_TEST.mods()), ph: SD_TEST.inst().phase, d: SD_TEST.s.distance }));
    eq(mid.ph, 'active'); near(mid.m.speedMul, 1.4, 0.001); near(mid.m.scoreMul, 1.25, 0.001);
    await p.evaluate(() => SD_TEST.step(140)); eq(await p.evaluate(() => SD_TEST.inst().phase), 'cooldown', 'ends after 4.5 s');
    near(await p.evaluate(() => SD_TEST.mods().speedMul), 1, 0.001, 'effect gone');
    await p.evaluate(() => SD_TEST.step(60 * 11)); eq(await p.evaluate(() => SD_TEST.inst().phase), 'cooldown', 'still cooling at ~11 s');
    await p.evaluate(() => SD_TEST.step(70)); eq(await p.evaluate(() => SD_TEST.inst().phase), 'ready', 'ready after 12 s');
    // rate check: distance per second while active vs base
    await p.evaluate(() => { SD_TEST.setDistance(0); SD_TEST.setSpeed(300); }); await pressAbility(p); await p.evaluate(() => SD_TEST.step(120)); const dAct = await p.evaluate(() => SD_TEST.s.distance);
    ok(dAct / (dBase * 2) > 1.55 && dAct / (dBase * 2) < 1.8, `distance rate ratio ${dAct / (dBase * 2)} should be ~1.75 (1.4 speed x 1.25 bonus, ramp-in reduces slightly)`);
    await p.ctx.close();
  });
  await test('Tide Pull: pulls coins from all three lanes; without it only your own lane counts', async () => {
    const p = await newPage(); await equip(p, 'luna'); await startManual(p);
    await p.evaluate(() => { SD_TEST.setLane(1); for (const l of [0, 1, 2]) SD_TEST.addCoinAt(l, SD_TEST.HIT_Z - 0.2); SD_TEST.step(120); }); eq((await S(p)).runCoins, 1, 'no ability: 1 of 3');
    await p.evaluate(() => { SD_TEST.clearCourse(); }); await pressAbility(p);
    await p.evaluate(() => { for (const l of [0, 1, 2]) SD_TEST.addCoinAt(l, SD_TEST.HIT_Z - 0.2); SD_TEST.addCoinAt(2, SD_TEST.HIT_Z - 0.2, 1); SD_TEST.step(120); }); eq((await S(p)).runCoins, 1 + 4, 'ability: all lanes and heights');
    await p.evaluate(() => SD_TEST.step(60 * 6)); eq(await p.evaluate(() => SD_TEST.inst().phase), 'cooldown'); eq(await p.evaluate(() => SD_TEST.inst().t > 14), true, 'cooldown ~16 s');
    await p.ctx.close();
  });
  await test('Tide Pull never creates coins: balance equals coins that existed', async () => {
    const p = await newPage(); await equip(p, 'luna'); await startManual(p); await p.evaluate(() => { SD_TEST.clearCourse(); SD_TEST.god(); });
    const bank0 = await p.evaluate(() => SD.Save.coins); await pressAbility(p);
    const n = await p.evaluate(() => { for (const l of [0, 1, 2]) for (let i = 0; i < 4; i++) SD_TEST.addCoinAt(l, SD_TEST.HIT_Z - 0.25 - i * 0.05); SD_TEST.step(360); return [SD.Save.coins, SD_TEST.s.runCoins]; });
    eq((n[0] - bank0) + ',' + n[1], '12,12', 'bank gained exactly the 12 coins that existed'); await p.ctx.close();
  });
  await test('Sky Flip: clears barriers and buoys, not beams; ducking cancels; 9 s cooldown', async () => {
    const p = await newPage(); await equip(p, 'mako');
    const flipVs = async (type, duckAt) => { await startManual(p); return p.evaluate(([type, duckAt]) => { SD_TEST.setLane(1); SD_TEST.useAbility(); SD_TEST.addObstacle(1, type, SD_TEST.HIT_Z - 0.16); for (let i = 0; i < 70; i++) { if (i === duckAt) SD_TEST.doDuck(); SD_TEST.step(1, 1 / 60, true); } return { alive: SD_TEST.s.running, ph: SD_TEST.inst() && SD_TEST.inst().phase }; }, [type, duckAt]); };
    eq((await flipVs('jump', -1)).alive, true, 'flips over a barrier'); eq((await flipVs('block', -1)).alive, true, 'flips over a buoy'); eq((await flipVs('duck', -1)).alive, false, 'a beam still hits at flip height');
    const c = await flipVs('duck', 6); eq(c.alive, true, 'duck mid-flip drops you under the beam'); eq(c.ph, 'cooldown', 'cancelling still costs the cooldown');
    await startManual(p); await p.evaluate(() => { SD_TEST.useAbility(); SD_TEST.step(70, 1 / 60, true); }); eq(await p.evaluate(() => SD_TEST.inst().phase), 'cooldown');
    await p.evaluate(() => SD_TEST.step(60 * 8.5, 1 / 60, true)); eq(await p.evaluate(() => SD_TEST.inst().phase), 'cooldown'); await p.evaluate(() => SD_TEST.step(60, 1 / 60, true)); eq(await p.evaluate(() => SD_TEST.inst().phase), 'ready');
    await p.ctx.close();
  });
  await test('Sky Flip cannot be used to skip a crash that arrives after the flip ends', async () => {
    const p = await newPage(); await equip(p, 'mako'); await startManual(p);
    const alive = await p.evaluate(() => { SD_TEST.setLane(1); SD_TEST.useAbility(); SD_TEST.addObstacle(1, 'block', SD_TEST.HIT_Z - 0.4); SD_TEST.step(100, 1 / 60, true); return SD_TEST.s.running; });
    eq(alive, false, 'landing before a buoy = crash'); await p.ctx.close();
  });
  await test('Coral Ward: absorbs exactly one crash, grants a short grace period, then 22 s cooldown', async () => {
    const p = await newPage(); await equip(p, 'tala'); await startManual(p);
    const r = await p.evaluate(() => {
      SD_TEST.setLane(1); SD_TEST.useAbility(); const o = {};
      SD_TEST.addObstacle(1, 'block', SD_TEST.HIT_Z - 0.2); SD_TEST.step(70, 1 / 60, true); o.afterFirst = SD_TEST.s.running; o.phase = SD_TEST.inst().phase; o.invuln = SD_TEST.s.invuln > 0.3;
      SD_TEST.addObstacle(1, 'block', SD_TEST.HIT_Z - 0.05); SD_TEST.step(20, 1 / 60, true); o.duringGrace = SD_TEST.s.running;
      SD_TEST.step(60 * 2, 1 / 60, true); SD_TEST.addObstacle(1, 'block', SD_TEST.HIT_Z - 0.05); SD_TEST.step(20, 1 / 60, true); o.afterGrace = SD_TEST.s.running; return o;
    });
    eq(r.afterFirst, true, 'survived first crash'); eq(r.phase, 'cooldown', 'shield consumed'); ok(r.invuln, 'grace period active'); eq(r.duringGrace, true, 'grace protects'); eq(r.afterGrace, false, 'second crash after grace is fatal (shield on cooldown)');
    await p.ctx.close();
  });
  await test('Coral Ward: expires unused after 6 s into the full cooldown', async () => {
    const p = await newPage(); await equip(p, 'tala'); await startManual(p); await p.evaluate(() => { SD_TEST.useAbility(); SD_TEST.step(60 * 6 + 5, 1 / 60, true); });
    const i = await p.evaluate(() => ({ ph: SD_TEST.inst().phase, t: SD_TEST.inst().t })); eq(i.ph, 'cooldown'); ok(i.t > 21 && i.t <= 22, 'cooldown ' + i.t);
    await p.ctx.close();
  });
  await test('Ability button: states, guards (no activation on cooldown / when paused), labels', async () => {
    const p = await newPage(); await startManual(p); await p.evaluate(() => SD_TEST.god());
    const btn = () => p.evaluate(() => ({ ph: document.getElementById('abilityBtn').dataset.phase, label: document.getElementById('abilityLabel').textContent }));
    let b = await btn(); eq(b.ph, 'ready'); eq(b.label, 'READY');
    await pressAbility(p); await p.evaluate(() => SD_TEST.step(30)); b = await btn(); eq(b.ph, 'active'); ok(/^\d\.\d$/.test(b.label), 'active shows seconds: ' + b.label);
    const t1 = await p.evaluate(() => SD_TEST.inst().t); await pressAbility(p); await p.evaluate(() => SD_TEST.step(1)); ok(Math.abs((await p.evaluate(() => SD_TEST.inst().t)) - (t1 - 1 / 60)) < 0.001, 'pressing while active does not restart it');
    await p.evaluate(() => SD_TEST.step(60 * 5)); b = await btn(); eq(b.ph, 'cooldown'); ok(/^\d+s$/.test(b.label), 'cooldown label ' + b.label);
    await pressAbility(p); eq(await p.evaluate(() => SD_TEST.inst().phase), 'cooldown', 'press on cooldown ignored');
    await p.evaluate(() => SD_TEST.pause()); const t2 = await p.evaluate(() => SD_TEST.inst().t); await pressAbility(p); await p.waitForTimeout(300); eq(await p.evaluate(() => SD_TEST.inst().t), t2, 'paused: nothing advances');
    const box = await p.evaluate(() => { const r = document.getElementById('abilityBtn').getBoundingClientRect(); return [r.width, r.height]; }); ok(box[0] >= 72 && box[1] >= 72, 'touch target at least 72px: ' + box);
    await p.ctx.close();
  });
  await test('Pause freezes ability timers in the REAL loop (and the resume countdown does too); restart resets cooldown', async () => {
    const p = await newPage(); await p.evaluate(() => { SD_TEST.startRun(); SD_TEST.clearCourse(); SD_TEST.god(); }); await pressAbility(p); await p.waitForTimeout(1000);
    await p.evaluate(() => SD_TEST.pause()); const t0 = await p.evaluate(() => SD_TEST.inst().t); await p.waitForTimeout(3000);
    near(await p.evaluate(() => SD_TEST.inst().t), t0, 0.001, 'frozen while paused');
    await p.evaluate(() => SD_TEST.resume()); await p.waitForTimeout(1200); ok((await S(p)).countdownT > 0, 'countdown is showing'); near(await p.evaluate(() => SD_TEST.inst().t), t0, 0.001, 'frozen during the 3-2-1 countdown');
    await p.waitForFunction(() => SD_TEST.s.countdownT <= 0, null, { timeout: 8000, polling: 100 }); await p.waitForTimeout(900); const t1 = await p.evaluate(() => SD_TEST.inst().t); ok(t1 < t0 - 0.2 && t1 > t0 - 1.6, `runs again after countdown: ${t0} -> ${t1}`);
    await p.evaluate(() => { SD_TEST.pause(); SD_TEST.showMenu('start'); SD_TEST.startRun(); }); eq(await p.evaluate(() => SD_TEST.inst().phase), 'ready', 'new run starts with the ability ready');
    await p.ctx.close();
  });
  await test('Auto-pause hook (used by Android onPause) and Back-button handling', async () => {
    const p = await newPage(); const back = () => p.evaluate(() => SurfDash.onBack());
    eq(await back(), false, 'start menu: Back exits the app');
    await p.click('#shopButton'); await p.waitForTimeout(200); eq(await back(), true); eq(await p.evaluate(() => SD.UI.shopIsOpen()), false, 'Back closes the shop');
    await p.evaluate(() => SD_TEST.startRun()); eq(await back(), true); eq((await S(p)).paused, true, 'Back pauses a run'); eq(await back(), true); eq((await S(p)).running, true, 'Back on pause resumes');
    await p.evaluate(() => SurfDash.autoPause()); eq((await S(p)).paused, true, 'autoPause pauses'); await p.ctx.close();
  });

  console.log('\n== Course generation ==');
  await test('coins never lead into crashes; obstacles are always escapable (12 simulated minutes, mixed speeds)', async () => {
    const p = await newPage(); await p.evaluate(() => { SD_TEST.startRun(); SD_TEST.manual = true; });
    const r = await p.evaluate(() => {
      SD_TEST.god(); SD_TEST.step(1); const bad = [], gaps = []; let coinsSeen = new Set(), groundSeen = 0, airSeen = 0, lastObs = null;
      for (const sp of [300, 450, 600]) { SD_TEST.setSpeed(sp); for (let f = 0; f < 60 * 240; f++) {
        SD_TEST.setSpeed(sp); SD_TEST.step(1, 1 / 60, true); const obs = SD_TEST.obstacles(), cs = SD_TEST.coins();
        for (const c of cs) { if (c.z < -0.9) continue;
          for (const o of obs) { if (o.lane !== c.lane) continue; const dz = Math.abs(o.z - c.z);
            if (c.h === 0 && dz < 0.055) bad.push(`ground coin ${dz.toFixed(3)} from ${o.type} lane ${o.lane} sp=${sp} f=${f} oz=${o.z.toFixed(3)} cz=${c.z.toFixed(3)} obs=${JSON.stringify(obs.map(x => [x.lane, x.type, +x.z.toFixed(2)]))} laneCoins=${JSON.stringify(cs.filter(x => x.lane === c.lane).map(x => [+x.z.toFixed(2), x.h]))}`);
            if (c.h === 1 && o.type !== 'jump' && dz < 0.09) bad.push(`air coin near ${o.type}`); } }
        if (obs.length > 1) for (let i = 1; i < obs.length; i++) gaps.push(Math.abs(obs[i - 1].z - obs[i].z));
        for (const c of cs) if (!coinsSeen.has(c)) { coinsSeen.add(c); c.h ? airSeen++ : groundSeen++; } } }
      return { bad: bad.slice(0, 1), nBad: bad.length, minGap: Math.min.apply(null, gaps), ground: groundSeen, air: airSeen };
    });
    eq(r.nBad, 0, 'violations: ' + r.bad.join('; ')); ok(r.minGap > 0.16, 'min obstacle gap ' + r.minGap + ' (design minimum is 0.169)'); ok(r.ground > 500 && r.air > 20, `coins generated: ${r.ground} ground / ${r.air} air`); await p.ctx.close();
  });
  await test('Automated player: survives 90 s runs, coin bank == sum of run coins (no duplicates), prints income estimate', async () => {
    const p = await newPage();
    const res = await p.evaluate(() => {
      const runs = [];
      for (const skill of [1, 0.5]) for (let r = 0; r < 3; r++) {
        SD_TEST.startRun(); SD_TEST.manual = true; let t = 0, died = false, target = null;
        while (t < 90) {
          const s = SD_TEST.s; if (!s.running) { died = true; break; }
          const obs = SD_TEST.obstacles(), spd = s.speed, tHit = o => (SD_TEST.HIT_Z - o.z) * 850 / spd;
          const threats = obs.filter(o => !o.checked && tHit(o) > 0 && tHit(o) < 1.1).sort((a, b) => tHit(a) - tHit(b));
          const lane = s.lane, mine = threats.find(o => o.lane === lane);
          if (mine) {
            const th = tHit(mine);
            if (mine.type === 'jump' && th < 0.2) SD_TEST.doJump();
            else if (mine.type === 'duck' && th < 0.28) SD_TEST.doDuck();
            else if (mine.type === 'block' && th < 0.85) { const free = [0, 1, 2].filter(l => Math.abs(l - lane) === 1 && !threats.some(o => o.lane === l && tHit(o) < 0.9)); if (free.length) SD_TEST.doLane(free[0] - lane); }
          } else if (Math.random() < skill) {
            const cs = SD_TEST.coins().filter(c => !c.got && c.z > 0.1 && c.z < SD_TEST.HIT_Z - 0.05 && !threats.some(o => o.lane === c.lane && tHit(o) < 1.0)).sort((a, b) => b.z - a.z)[0];
            if (cs && cs.lane !== lane && Math.abs(cs.lane - lane) === 1) SD_TEST.doLane(cs.lane - lane);
            else if (cs && cs.h === 1 && Math.abs(cs.z - SD_TEST.HIT_Z) < 0.2 && cs.lane === lane) SD_TEST.doJump();
          }
          SD_TEST.step(1, 1 / 60, true); t += 1 / 60;
        }
        const s = SD_TEST.s; runs.push({ skill, secs: Math.round(t), died, coins: s.runCoins, dist: Math.floor(s.distance), bank: SD.Save.coins });
        if (SD_TEST.s.running) SD_TEST.pause(); SD_TEST.showMenu('start');
      }
      return runs;
    });
    const sum = res.reduce((a, r) => a + r.coins, 0); eq(res[res.length - 1].bank, sum, 'bank equals the sum of per-run coins');
    const perMin = a => a.length ? Math.round(a.reduce((s, r) => s + r.coins / r.secs * 60, 0) / a.length) : 0;
    const hi = res.filter(r => r.skill === 1), lo = res.filter(r => r.skill === 0.5);
    console.log('       bot runs:', JSON.stringify(res)); console.log(`       estimated coins/min — attentive bot: ${perMin(hi)}, half-attentive bot: ${perMin(lo)}`);
    ok(res.filter(r => r.skill === 1).every(r => r.secs >= 30), 'attentive bot should survive at least 30 s every run (obstacles are always escapable)');
    await p.ctx.close();
  });

  console.log('\n== Save data robustness ==');
  await test('corrupt / hostile save data is sanitised, v1 best score migrates', async () => {
    const seeded = async seed => { const ctx = await browser.newContext({ viewport: { width: 854, height: 390 } }); await ctx.addInitScript(seed => { for (const k in seed) localStorage.setItem(k, seed[k]); }, seed);
      const page = await ctx.newPage(); page.on('pageerror', e => currentErrors.push('pageerror: ' + e)); await page.goto(URL); await page.waitForTimeout(200); page.ctx = ctx; return page; };
    let p = await seeded({ 'surfdash-save-v2': '{not json' });
    eq(await p.evaluate(() => JSON.stringify([SD.Save.coins, SD.Save.data.owned, SD.Save.equipped])), '[0,["kai"],"kai"]'); await p.ctx.close();
    p = await seeded({ 'surfdash-save-v2': JSON.stringify({ v: 2, coins: -50, owned: ['ghost', 'luna', 7], equipped: 'tala', best: 'x' }) });
    eq(await p.evaluate(() => JSON.stringify([SD.Save.coins, SD.Save.data.owned, SD.Save.equipped, SD.Save.best])), '[0,["kai","luna"],"kai",0]', 'unknown ids dropped, negative coins clamped, equip of a non-owned surfer rejected'); await p.ctx.close();
    p = await seeded({ 'surfdash-best': '1234' });
    eq(await p.evaluate(() => SD.Save.best), 1234, 'v1 best score migrated'); eq(await p.evaluate(() => document.getElementById('best').textContent), '1234'); await p.ctx.close();
  });
  await test('music and SFX toggles are independent and persisted', async () => {
    const p = await newPage(); await p.click('#sfxToggle'); let s = await p.evaluate(() => [SD.Audio.musicOn, SD.Audio.sfxOn]); eq(s.join(), 'true,false');
    await p.click('#musicToggle'); s = await p.evaluate(() => [SD.Audio.musicOn, SD.Audio.sfxOn]); eq(s.join(), 'false,false');
    await p.click('#sfxToggle'); await p.reload(); await p.waitForTimeout(200); eq(await p.evaluate(() => [SD.Audio.musicOn, SD.Audio.sfxOn].join()), 'false,true');
    await p.evaluate(() => { for (const n of ['coin', 'hit', 'jump', 'duck', 'lane', 'buy', 'deny', 'equip', 'click', 'record', 'gameover', 'shield_pop', 'ability_surge', 'ability_tidepull', 'ability_skyflip', 'ability_coralward', 'ability_end', 'ability_ready']) SD.Audio.play(n, { step: 3 }); });
    await p.ctx.close();
  });

  console.log('\n== Layout on phone-sized landscape screens ==');
  for (const [w, h] of [[640, 360], [740, 360], [800, 360], [854, 390], [915, 412], [960, 432]]) {
    await test(`layout ${w}x${h}: nothing clipped sideways, 80px ability button clear of HUD, shop usable`, async () => {
      const p = await newPage(w, h); await equip(p, 'luna'); await p.evaluate(() => SD.Save.addCoins(300));
      await p.screenshot({ path: `${SHOTS}/menu_${w}x${h}.png` });
      await p.click('#shopButton'); await p.waitForTimeout(500); await p.screenshot({ path: `${SHOTS}/shop_${w}x${h}.png` });
      const m = await p.evaluate(() => { const t = document.getElementById('shopTrack'), cards = [...t.children].map(c => c.getBoundingClientRect()); return { sw: document.documentElement.scrollWidth, iw: innerWidth, btnVisible: [...document.querySelectorAll('.buy-btn')].every(b => { const r = b.getBoundingClientRect(); return r.bottom <= innerHeight + 1 && r.height >= 36; }), cardH: cards[0].height }; });
      ok(m.sw <= m.iw, 'horizontal overflow'); ok(m.btnVisible, 'every buy button fully on-screen with >=36px height');
      await p.click('#shopBack'); await p.waitForTimeout(300); await p.evaluate(() => { SD_TEST.startRun(); SD_TEST.manual = true; SD_TEST.clearCourse(); SD_TEST.god(); SD_TEST.step(180); }); await p.waitForTimeout(100);
      const r = await p.evaluate(() => { const a = document.getElementById('abilityBtn').getBoundingClientRect(), b = document.getElementById('pause').getBoundingClientRect(), bh = document.getElementById('bottom-hints').getBoundingClientRect(); const o = (x, y) => !(x.right < y.left || x.left > y.right || x.bottom < y.top || x.top > y.bottom); return { w: a.width, inView: a.left >= 0 && a.right <= innerWidth && a.top >= 0 && a.bottom <= innerHeight, hitsPause: o(a, b), hitsHints: o(a, { left: bh.right - 150, right: bh.right, top: bh.top, bottom: bh.bottom }) }; });
      ok(r.w >= 76 && r.inView && !r.hitsPause, `ability button geometry ${JSON.stringify(r)}`);
      await p.screenshot({ path: `${SHOTS}/run_${w}x${h}.png` }); await p.ctx.close();
    });
  }

  await browser.close();
  const failed = results.filter(r => !r.pass);
  console.log(`\n${results.length - failed.length}/${results.length} tests passed`); if (failed.length) { console.log('FAILED:\n' + failed.map(f => ' - ' + f.name + ': ' + f.err).join('\n')); process.exit(1); }
})();
