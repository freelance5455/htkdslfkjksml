# Surf Dash v2 — characters, coins, shop, abilities

Android WebView app (Java wrapper + HTML/CSS/JS canvas game in `app/src/main/assets`). Works offline, landscape, no libraries.

## What's new
- **4 surfers**, each with its own art, board and ability: Kai (free, Surge), Luna 150 (Tide Pull), Mako 400 (Sky Flip), Tala 750 (Coral Ward).
- **Coins** spawn in trains/arcs placed around scheduled obstacles so they never lead you into a crash. Each coin is paid exactly once, immediately, and saved.
- **Shop** (menu -> SURFERS & SHOP): carousel with live previews, prices, balance, buy/equip/equipped states, toasts, purchase burst.
- **Ability system** (`js/abilities.js`) + large ability button (bottom-right), ring shows active/cooldown time. Timers only advance in the running game loop; resume has a 3-2-1 countdown.
- Music / SFX toggles (independent, saved). Sounds are synthesised placeholders; see `assets/audio/README.txt`.
- Android Back: closes shop / pauses / resumes; app going to background auto-pauses.

### Bug fixed in the original
Outer-lane obstacles never collided on screens wider than ~700 px (hit test used a perspective-shifted x). Player, obstacles and coins now share one lane mapping (`laneX`/`laneProj` in `game.js`); lane centres moved slightly inward (0.27/0.73 -> 0.30/0.70 of width). **Outer lanes are now dangerous, so the game is harder than before.**

## Build
- **Android Studio**: open this folder, let it sync, Run. (No `gradlew` is included; Studio uses `gradle/wrapper/gradle-wrapper.properties`, or run `gradle wrapper` once.)
- **Cloud**: push to GitHub; `.github/workflows/build-apk.yml` builds `app-debug.apk` as an artifact.
- Changed build files: `app/build.gradle` no longer repeats the plugin version (root already declares it).

## Test
`cd tests && npm i playwright && npx playwright install chromium && node run-tests.js` (headless Chromium, uses `?test=1` hooks).

## Add a character / ability
1. `js/abilities.js`: add an entry to `DEFS` (duration, cooldown, `apply` to edit modifiers, optional `onHit`, `drawFx`).
2. `js/characters.js`: write `drawX(ctx, pose)` and add an entry to `LIST` (`id, name, title, price, ability, palette, draw`).
Shop, menu card, previews, saves and gameplay pick it up automatically.

## Known limitations
- APK **not built** here; Android APIs in `MainActivity.java` only compile-checked against stubs.
- Never run on a real phone/WebView; touch feel, performance, audio output unverified.
- Prices are estimates (a test bot earned ~150-180 coins/min; humans will earn less). Tune in `characters.js`.
- Sounds are simple synth placeholders; no real music.
- Back key on Android 13+ with predictive-back may need `enableOnBackInvokedCallback` handling.
