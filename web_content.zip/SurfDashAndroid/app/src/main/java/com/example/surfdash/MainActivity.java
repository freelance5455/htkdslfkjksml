package com.example.surfdash;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        web = new WebView(this);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);   // required: coins, unlocks and best score live in localStorage
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(0xff071e35);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    // Leaving the app pauses the run (so cooldown timers and obstacles stop) before the WebView is frozen.
    @Override protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.SurfDash && window.SurfDash.autoPause && window.SurfDash.autoPause()", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    // Back closes the shop / pauses a run / resumes from pause. From the main menu it exits as before.
    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript(
            "(window.SurfDash && window.SurfDash.onBack) ? String(window.SurfDash.onBack()) : 'false'",
            new ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    if (value == null || !value.contains("true")) {
                        MainActivity.super.onBackPressed();
                    }
                }
            });
    }
}
