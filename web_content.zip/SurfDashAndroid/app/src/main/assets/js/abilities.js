/* Surf Dash — special abilities
 *
 * An ability is a data object in DEFS. The runtime below handles the shared life cycle:
 *     ready  --activate()-->  active (duration)  -->  cooldown  -->  ready
 * All timers advance only inside update(dt), which the game calls from its running loop,
 * so pausing (or the resume countdown) can never advance them.
 *
 * Definition fields
 *   id, name, icon (symbol id in index.html), color, duration, cooldown, desc
 *   canActivate(g)            optional activation condition
 *   onStart(g, inst)          optional, runs once on activation
 *   onEnd(g, inst, reason)    optional, reason = 'expired' | 'absorbed' | 'cancel'
 *   apply(g, inst, m)         optional, edits the per-frame modifier object m while active:
 *                               m.speedMul, m.scoreMul, m.magnetZ, m.lift, m.spin, m.clears.{jump,block}
 *   onHit(g, inst, obstacle)  optional, return true to absorb a collision
 *   motion(f)                 optional, {lift, spin} for body motion (also used by shop previews)
 *   drawFx(ctx, p)            optional, aura around the surfer (also used by shop previews)
 *   drawWorldFx(ctx, g, inst) optional, full-scene effects (game only)
 *
 * `g` is the small API object the game passes in (see makeApi in game.js).
 * To add an ability: add an entry here, then set `ability: '<id>'` on a character.
 */
(function () {
  'use strict';
  const SD = (window.SD = window.SD || {});
  const TAU = Math.PI * 2;
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const ease = t => t * t * (3 - 2 * t);

  function glow(ctx, x, y, r, color) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  const DEFS = {
    /* ---------------- Kai: Surge ---------------- */
    surge: {
      id: 'surge', name: 'Surge', icon: 'i-bolt', color: '#27e9dc', duration: 4.5, cooldown: 12,
      desc: 'Rocket forward 40% faster and earn 25% extra distance. Obstacles are spaced to match, so it stays fair.',
      short: '+40% speed, +25% distance',
      apply(g, inst, m) {
        const ramp = Math.min(1, inst.elapsed * 5, inst.t * 5);   // ease in and out so speed never snaps
        m.speedMul *= 1 + 0.4 * ramp; m.scoreMul *= 1 + 0.25 * ramp;
      },
      onStart(g) { g.audio('ability_surge'); g.flash('rgba(120,255,245,.35)', 0.25); g.fx.ring(g.px, g.py - 10, 10, 90, '#a8fff4', 0.45); },
      drawFx(ctx, p) {
        ctx.save();
        glow(ctx, p.x, p.y - 8 * p.s, 78 * p.s, 'rgba(70,255,238,.38)');
        for (let i = 0; i < 7; i++) {
          const ox = (i - 3) * 9 * p.s, len = (34 + ((i * 17 + (p.now * 0.35)) % 38)) * p.s, y0 = p.y + 30 * p.s;
          ctx.strokeStyle = `rgba(210,255,250,${0.5 - (i % 3) * 0.1})`; ctx.lineWidth = (2.2 - (i % 2) * 0.8) * p.s; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(p.x + ox, y0); ctx.lineTo(p.x + ox * 1.25, y0 + len); ctx.stroke();
        }
        ctx.restore();
      },
      drawWorldFx(ctx, g, inst) {
        const cx = g.W * 0.5, cy = g.H * 0.46, a = 0.22 * Math.min(1, inst.elapsed * 4, inst.t * 4);
        ctx.save(); ctx.lineCap = 'round';
        for (let i = 0; i < 16; i++) {
          const ang = (i / 16) * TAU + Math.sin(i * 7.3) * 0.2, r0 = g.H * (0.35 + ((i * 0.37 + g.now * 0.0021) % 0.5)), r1 = r0 + g.H * 0.22;
          ctx.strokeStyle = `rgba(230,255,252,${a})`; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.moveTo(cx + Math.cos(ang) * r0 * 1.5, cy + Math.sin(ang) * r0); ctx.lineTo(cx + Math.cos(ang) * r1 * 1.5, cy + Math.sin(ang) * r1); ctx.stroke();
        }
        ctx.restore();
      }
    },

    /* ---------------- Luna: Tide Pull ---------------- */
    tidepull: {
      id: 'tidepull', name: 'Tide Pull', icon: 'i-magnet', color: '#ffc94d', duration: 6, cooldown: 16,
      desc: 'Pulls every coin in reach toward you, from all three lanes, for 6 seconds.',
      short: 'Pulls coins from all lanes',
      apply(g, inst, m) { m.magnetZ = Math.max(m.magnetZ, 0.36); },
      onStart(g) { g.audio('ability_tidepull'); g.fx.ring(g.px, g.py - 10, 12, 120, '#ffd978', 0.6); g.fx.ring(g.px, g.py - 10, 6, 80, '#ff9ccb', 0.5); },
      drawFx(ctx, p) {
        ctx.save();
        glow(ctx, p.x, p.y - 8 * p.s, 70 * p.s, 'rgba(255,205,90,.30)');
        for (let i = 0; i < 3; i++) {
          const k = ((p.now * 0.0011 + i / 3) % 1), r = (24 + k * 60) * p.s;
          ctx.globalAlpha = (1 - k) * 0.7; ctx.strokeStyle = i % 2 ? '#ff9ccb' : '#ffd978'; ctx.lineWidth = 2.2 * p.s;
          ctx.beginPath(); ctx.ellipse(p.x, p.y - 8 * p.s, r * 1.25, r * 0.8, 0, 0, TAU); ctx.stroke();
        }
        ctx.restore();
      },
      drawWorldFx(ctx, g) {
        const list = g.pulled; if (!list.length) return;
        ctx.save(); ctx.lineCap = 'round';
        for (const c of list) {
          ctx.strokeStyle = `rgba(255,222,130,${0.12 + c.pull * 0.4})`; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.quadraticCurveTo((c.x + g.px) / 2, Math.min(c.y, g.py) - 24, g.px, g.py - 24); ctx.stroke();
        }
        ctx.restore();
      }
    },

    /* ---------------- Mako: Sky Flip ---------------- */
    skyflip: {
      id: 'skyflip', name: 'Sky Flip', icon: 'i-flip', color: '#b6ff4f', duration: 0.95, cooldown: 9,
      desc: 'Launch a huge flip that clears barriers and buoys. Overhead beams still need a duck. Ducking mid-air cuts the flip short.',
      short: 'Flip over barriers and buoys',
      canActivate(g) { return !g.isDucking; },
      motion(f) { return { lift: 1.7 * Math.sin(Math.PI * f), spin: ease(f) * TAU }; },
      apply(g, inst, m) {
        const mo = DEFS.skyflip.motion(inst.elapsed / inst.def.duration);
        m.lift = Math.max(m.lift, mo.lift); m.spin = mo.spin;
        const f = inst.elapsed / inst.def.duration;
        if (f > 0.1 && f < 0.9) { m.clears.jump = true; m.clears.block = true; }  // only while genuinely high
      },
      onStart(g) { g.audio('ability_skyflip'); g.fx.ring(g.px, g.py + 22, 8, 70, '#e4ff9c', 0.4); g.fx.burst(g.px, g.py + 20, 10, ['#e4ff9c', '#ffffff', '#b6ff4f']); },
      onEnd(g, inst, reason) { if (reason === 'expired') g.fx.ring(g.px, g.py + 24, 6, 60, '#e4ff9c', 0.35); },
      drawFx(ctx, p) {
        const f = p.f == null ? 0 : p.f; ctx.save();
        glow(ctx, p.x, p.y - 8 * p.s, 64 * p.s, 'rgba(190,255,90,.30)');
        const spin = ease(clamp(f, 0, 1)) * TAU;
        for (let i = 0; i < 3; i++) {
          ctx.strokeStyle = `rgba(235,255,170,${0.65 - i * 0.2})`; ctx.lineWidth = (3.4 - i) * p.s; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.arc(p.x, p.y - 10 * p.s, (46 + i * 7) * p.s, spin - 1.6 - i * 0.5, spin - 0.2 - i * 0.2); ctx.stroke();
        }
        ctx.restore();
      }
    },

    /* ---------------- Tala: Coral Ward ---------------- */
    coralward: {
      id: 'coralward', name: 'Coral Ward', icon: 'i-shield', color: '#ff8a68', duration: 6, cooldown: 22,
      desc: 'A shield for 6 seconds that absorbs one crash, then gives a moment of safety. Recharges slowly.',
      short: 'Survive one crash',
      onStart(g) { g.audio('ability_coralward'); g.fx.ring(g.px, g.py - 10, 14, 80, '#ffc2a8', 0.5); },
      onHit(g, inst, obstacle) {
        g.audio('shield_pop'); g.shake(7, 0.28); g.flash('rgba(255,170,140,.4)', 0.3); g.setInvuln(1.0);
        g.fx.ring(g.px, g.py - 10, 20, 130, '#ffd5c2', 0.5);
        g.fx.burst(g.px, g.py - 12, 22, ['#ff8a68', '#ffd1b8', '#ffffff', '#ffcf6a']);
        g.fx.text(g.px, g.py - 70, 'SHIELD!', '#ffd5c2');
        return true;
      },
      drawFx(ctx, p) {
        const warn = p.remaining != null && p.remaining < 1.3 && Math.floor(p.now / 110) % 2 === 0;
        const r = 56 * p.s, cy = p.y - 8 * p.s, pulse = 1 + Math.sin(p.now * 0.006) * 0.03;
        ctx.save(); ctx.globalAlpha = warn ? 0.4 : 1;
        const g = ctx.createRadialGradient(p.x - r * 0.25, cy - r * 0.3, r * 0.1, p.x, cy, r * pulse);
        g.addColorStop(0, 'rgba(255,230,215,.05)'); g.addColorStop(0.7, 'rgba(255,160,130,.16)'); g.addColorStop(1, 'rgba(255,140,110,.46)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(p.x, cy, r * 0.92 * pulse, r * pulse, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(255,225,205,.85)'; ctx.lineWidth = 2 * p.s; ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 3 * p.s; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(p.x, cy, r * 0.8, Math.PI * 1.15, Math.PI * 1.45); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,215,190,.35)'; ctx.lineWidth = 1.2 * p.s;
        for (let i = 0; i < 4; i++) { const a = p.now * 0.0009 + i * 1.6; ctx.beginPath(); ctx.arc(p.x + Math.cos(a) * r * 0.45, cy + Math.sin(a) * r * 0.5, 7 * p.s, 0, TAU); ctx.stroke(); }
        ctx.restore();
      }
    }
  };

  /* ---------------- runtime ---------------- */
  const mods = { speedMul: 1, scoreMul: 1, magnetZ: 0, lift: 0, spin: 0, clears: { jump: false, block: false } };
  let inst = null;

  function resetMods() {
    mods.speedMul = 1; mods.scoreMul = 1; mods.magnetZ = 0; mods.lift = 0; mods.spin = 0; mods.clears.jump = false; mods.clears.block = false;
  }
  function toCooldown(g) { inst.phase = 'cooldown'; inst.t = inst.def.cooldown; inst.elapsed = 0; inst.cdTotal = inst.def.cooldown; }

  const Abilities = {
    defs: DEFS,
    mods,
    get(id) { return DEFS[id] || null; },
    get inst() { return inst; },

    /** New run: the ability starts ready, with nothing carried over. */
    reset(id) {
      const def = DEFS[id];
      inst = def ? { def, phase: 'ready', t: 0, elapsed: 0, cdTotal: def.cooldown } : null;
      resetMods();
    },

    activate(g) {
      if (!inst || inst.phase !== 'ready') return false;
      if (inst.def.canActivate && !inst.def.canActivate(g)) return false;
      inst.phase = 'active'; inst.t = inst.def.duration; inst.elapsed = 0;
      if (inst.def.onStart) inst.def.onStart(g, inst);
      return true;
    },

    /** Ends an active ability early and starts its cooldown. */
    end(g, reason) {
      if (!inst || inst.phase !== 'active') return;
      if (inst.def.onEnd) inst.def.onEnd(g, inst, reason);
      if (reason === 'expired' && inst.def.id !== 'skyflip') g.audio('ability_end');
      toCooldown(g);
    },

    update(g, dt) {
      resetMods();
      if (!inst) return;
      if (inst.phase === 'active') {
        inst.elapsed += dt; inst.t -= dt;
        if (inst.def.apply) inst.def.apply(g, inst, mods);
        if (inst.t <= 0) Abilities.end(g, 'expired');
      } else if (inst.phase === 'cooldown') {
        inst.t -= dt; inst.elapsed += dt;
        if (inst.t <= 0) { inst.phase = 'ready'; inst.t = 0; g.abilityReady(); }
      }
    },

    /** Collision hook: true means the ability absorbed the crash (the game then survives it). */
    onHit(g, obstacle) {
      if (!inst || inst.phase !== 'active' || !inst.def.onHit) return false;
      if (!inst.def.onHit(g, inst, obstacle)) return false;
      Abilities.end(g, 'absorbed');
      return true;
    },

    /** Ducking mid-flip cancels the flip (it still costs the cooldown). */
    onDuck(g) { if (inst && inst.phase === 'active' && inst.def.id === 'skyflip') Abilities.end(g, 'cancel'); },

    /** Snapshot for the HUD button. frac is 0..1 of the ring to fill. */
    status() {
      if (!inst) return null;
      const d = inst.def;
      if (inst.phase === 'active') return { phase: 'active', frac: clamp(inst.t / d.duration, 0, 1), secs: inst.t };
      if (inst.phase === 'cooldown') return { phase: 'cooldown', frac: clamp(1 - inst.t / inst.cdTotal, 0, 1), secs: inst.t };
      return { phase: 'ready', frac: 1, secs: 0 };
    },

    drawFx(ctx, p) {
      if (inst && inst.phase === 'active' && inst.def.drawFx) {
        inst.def.drawFx(ctx, Object.assign({ f: inst.elapsed / inst.def.duration, remaining: inst.t }, p));
      }
    },
    drawWorldFx(ctx, g) {
      if (inst && inst.phase === 'active' && inst.def.drawWorldFx) inst.def.drawWorldFx(ctx, g, inst);
    }
  };

  SD.Abilities = Abilities;
})();
