/* Surf Dash — playable surfers
 *
 * Each entry in LIST is plain data plus one draw function. To add a surfer:
 *   1. Write a draw function (see drawKai for the pattern) — it paints in local units
 *      around the board centre; the pose argument says whether to crouch/jump/etc.
 *   2. Add an entry to LIST with a price and the id of an ability from abilities.js.
 * The shop, menu card, previews, save data and gameplay pick it up automatically.
 */
(function () {
  'use strict';
  const SD = (window.SD = window.SD || {});
  const TAU = Math.PI * 2;

  /* ---------- tiny canvas helpers (take the context explicitly so previews can reuse them) ---------- */
  function rr(c, x, y, w, h, r, fill, stroke) {
    c.beginPath(); c.roundRect(x, y, w, h, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.stroke(); }
  }
  function poly(c, pts, fill, stroke, lw) {
    c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw || 1; c.stroke(); }
  }
  function ell(c, x, y, rx, ry, rot, fill) {
    c.beginPath(); c.ellipse(x, y, rx, ry, rot || 0, 0, TAU); c.fillStyle = fill; c.fill();
  }
  function circ(c, x, y, r, fill) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fillStyle = fill; c.fill(); }
  function lgrad(c, x0, x1, stops) {
    const g = c.createLinearGradient(x0, 0, x1, 0); stops.forEach((s, i) => g.addColorStop(i / (stops.length - 1), s)); return g;
  }

  /* ---------- shared pose maths ---------- */
  function P(p) {
    const ducking = !!p.ducking, jumping = !!p.jumping;
    return { ducking, jumping, crouch: ducking ? 8 : 0, armLift: jumping ? -8 : 0, torsoRot: ducking ? 0.22 : jumping ? -0.12 : 0, now: p.now || 0, lean: p.lean || 0, fx: !!p.fx };
  }

  /* =====================================================================================
   * KAI — The Speedster. This is the original Surf Dash surfer, unchanged.
   * ===================================================================================== */
  function drawKai(c, pose) {
    const q = P(pose), crouch = q.crouch, armLift = q.armLift;
    // surfboard with pointed nose, rails, sunburst stripe and tail fin
    c.beginPath(); c.moveTo(-40, 17); c.quadraticCurveTo(-33, 10, -17, 12); c.quadraticCurveTo(12, 14, 39, 18); c.quadraticCurveTo(28, 33, 0, 34); c.quadraticCurveTo(-28, 32, -40, 17); c.closePath();
    c.fillStyle = lgrad(c, -40, 38, ['#ff9d64', '#ffdf75', '#79ffe2']); c.fill(); c.strokeStyle = '#fff8ce'; c.lineWidth = 1.3; c.stroke();
    c.beginPath(); c.moveTo(-28, 20); c.quadraticCurveTo(0, 28, 29, 21); c.strokeStyle = '#ef6b63'; c.lineWidth = 2.3; c.stroke();
    poly(c, [[-7, 31], [-1, 39], [4, 32]], '#0c7e94'); circ(c, 25, 19, 2, '#fff5c4');
    // legs: navy wetsuit with bright cuffs
    c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = '#092e4a'; c.lineWidth = 8; c.beginPath();
    c.moveTo(-6, 1 + crouch * 0.25); c.lineTo(-15, 17); c.moveTo(6, 1 + crouch * 0.25); c.lineTo(17, 17); c.stroke();
    c.strokeStyle = '#ffcf7a'; c.lineWidth = 2.1; c.beginPath(); c.moveTo(-17, 15); c.lineTo(-12, 18); c.moveTo(14, 15); c.lineTo(19, 18); c.stroke();
    // torso: turquoise shoulders and coral life vest
    c.save(); c.translate(0, -10 + crouch); c.rotate(q.torsoRot);
    c.beginPath(); c.moveTo(-10, -14); c.quadraticCurveTo(0, -19, 10, -13); c.lineTo(12, 5); c.quadraticCurveTo(0, 11, -12, 5); c.closePath(); c.fillStyle = '#087f96'; c.fill();
    rr(c, -10, -13, 20, 20, 6, '#13c9c2'); rr(c, -8, -11, 16, 16, 5, '#ff7763');
    c.strokeStyle = '#ffd776'; c.lineWidth = 2; c.beginPath(); c.moveTo(-5, -8); c.lineTo(5, -8); c.moveTo(-5, 1); c.lineTo(5, 1); c.stroke(); c.restore();
    // arms
    c.strokeStyle = '#0b3851'; c.lineWidth = 6.2; c.beginPath();
    c.moveTo(-8, -17 + crouch * 0.5); c.quadraticCurveTo(-18, -17 + armLift, -25, -9 + armLift);
    c.moveTo(8, -17 + crouch * 0.5); c.quadraticCurveTo(18, -21 - armLift * 0.3, 25, -12 - armLift * 0.3); c.stroke();
    c.strokeStyle = '#15c7c3'; c.lineWidth = 4; c.beginPath();
    c.moveTo(-21, -11 + armLift); c.lineTo(-25, -9 + armLift); c.moveTo(21, -13 - armLift * 0.3); c.lineTo(25, -12 - armLift * 0.3); c.stroke();
    // neck and head
    rr(c, -4, -27 + crouch, 8, 8, 3, '#bd7658'); ell(c, 0, -33 + crouch, 9.2, 10.7, -0.07, '#c98562');
    // thick windswept hair
    c.fillStyle = '#132b42'; c.beginPath(); c.moveTo(-9, -34 + crouch); c.quadraticCurveTo(-13, -45 + crouch, -3, -46 + crouch); c.quadraticCurveTo(5, -49 + crouch, 10, -41 + crouch);
    c.lineTo(9, -34 + crouch); c.quadraticCurveTo(2, -38 + crouch, -2, -37 + crouch); c.lineTo(-7, -32 + crouch); c.closePath(); c.fill();
    // cheek, nose and sporty shades
    ell(c, 6, -31 + crouch, 2.4, 3.3, -0.3, '#f4b185'); rr(c, -7, -34 + crouch, 7, 4, 1.5, '#102a43'); rr(c, 1, -34 + crouch, 7, 4, 1.5, '#102a43');
    c.strokeStyle = '#102a43'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(0, -32 + crouch); c.lineTo(1, -32 + crouch); c.stroke();
    // backlight edge
    c.strokeStyle = '#a7fff0aa'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-11, -18 + crouch); c.quadraticCurveTo(-15, -7 + crouch, -10, 3 + crouch); c.stroke();
  }

  /* =====================================================================================
   * LUNA — The Magnet Surfer. Orchid rash guard, hibiscus, long ponytail, swallow-tail fish board.
   * ===================================================================================== */
  function drawLuna(c, pose) {
    const q = P(pose), crouch = q.crouch, armLift = q.armLift, now = q.now;
    const sway = Math.sin(now * 0.006) * 4 - q.lean * 28;
    // fish board with a swallow tail
    c.beginPath(); c.moveTo(-38, 18); c.quadraticCurveTo(-30, 9, -10, 11); c.quadraticCurveTo(14, 12, 38, 12); c.lineTo(33, 23); c.lineTo(42, 31); c.quadraticCurveTo(22, 36, 0, 35); c.quadraticCurveTo(-28, 33, -38, 18); c.closePath();
    c.fillStyle = lgrad(c, -38, 42, ['#b86bff', '#ff79b0', '#ffd9a0']); c.fill(); c.strokeStyle = '#fff3f8'; c.lineWidth = 1.3; c.stroke();
    c.beginPath(); c.moveTo(-28, 21); c.quadraticCurveTo(-14, 16, -2, 23); c.quadraticCurveTo(10, 29, 28, 22); c.strokeStyle = '#ffffffd0'; c.lineWidth = 2.4; c.stroke();
    for (let i = 0; i < 3; i++) circ(c, -16 + i * 12, 27 - (i % 2) * 3, 1.5, '#fff3f8');
    poly(c, [[-9, 32], [-3, 39], [3, 33]], '#5b2a9d');
    // legs + wrap skirt
    c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = '#341a66'; c.lineWidth = 7.4; c.beginPath();
    c.moveTo(-6, 1 + crouch * 0.25); c.lineTo(-14, 17); c.moveTo(6, 1 + crouch * 0.25); c.lineTo(16, 17); c.stroke();
    c.strokeStyle = '#ffd776'; c.lineWidth = 2; c.beginPath(); c.moveTo(-16, 15.5); c.lineTo(-11.5, 18); c.moveTo(13, 15.5); c.lineTo(18, 18); c.stroke();
    const sk = crouch * 0.25;
    c.beginPath(); c.moveTo(-10, 2 + sk); c.lineTo(10, 2 + sk); c.quadraticCurveTo(15, 8, 19, 13 + sk); c.quadraticCurveTo(0, 17, -19, 13 + sk); c.quadraticCurveTo(-15, 8, -10, 2 + sk); c.closePath();
    const sg = c.createLinearGradient(-18, 0, 18, 0); sg.addColorStop(0, '#ff7a8a'); sg.addColorStop(1, '#ffc46b'); c.fillStyle = sg; c.fill();
    c.strokeStyle = '#fff0c8'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-18, 13 + sk); c.quadraticCurveTo(0, 17, 18, 13 + sk); c.stroke();
    // ponytail streaming behind (drawn before head so it tucks behind)
    c.beginPath(); c.moveTo(-6, -40 + crouch);
    c.bezierCurveTo(-24, -44 + crouch, -34 + sway * 0.5, -28 + crouch, -40 + sway, -9 + crouch + Math.abs(sway) * 0.3);
    c.bezierCurveTo(-32 + sway, -16 + crouch, -22, -29 + crouch, -7, -32 + crouch); c.closePath(); c.fillStyle = '#3a1f6b'; c.fill();
    c.strokeStyle = '#ff6fa8'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(-14, -39 + crouch); c.bezierCurveTo(-27 + sway * 0.4, -35 + crouch, -34 + sway * 0.7, -22 + crouch, -37 + sway, -12 + crouch); c.stroke();
    // torso: orchid rash guard with hibiscus print
    c.save(); c.translate(0, -10 + crouch); c.rotate(q.torsoRot);
    c.beginPath(); c.moveTo(-9, -14); c.quadraticCurveTo(0, -19, 9, -13); c.lineTo(10.5, 5); c.quadraticCurveTo(0, 10, -10.5, 5); c.closePath(); c.fillStyle = '#6d34c9'; c.fill();
    rr(c, -9, -13, 18, 19, 6, '#8b4ff0'); rr(c, -8, -12, 16, 6, 3, '#ff7ab6');
    [[-4, -1], [3, -3], [1, 2.5], [-5, 3]].forEach(d => circ(c, d[0], d[1], 1.5, '#ffb199'));
    c.strokeStyle = '#ffd776'; c.lineWidth = 1.8; c.beginPath(); c.moveTo(-8, 4.5); c.lineTo(8, 4.5); c.stroke();
    // gold shell pendant — pulses while Tide Pull is active
    const pr = 2.6 + (q.fx ? 0.9 + Math.sin(now * 0.02) * 0.5 : 0);
    if (q.fx) { c.save(); c.globalAlpha = 0.5; circ(c, 0, -5, pr * 2.4, '#ffe58a'); c.restore(); }
    c.beginPath(); c.arc(0, -5, pr, Math.PI, TAU); c.closePath(); c.fillStyle = '#ffd24a'; c.fill();
    c.strokeStyle = '#b8791f'; c.lineWidth = 0.7; c.beginPath(); c.moveTo(0, -5); c.lineTo(0, -5 - pr); c.moveTo(0, -5); c.lineTo(-pr * 0.7, -5 - pr * 0.7); c.moveTo(0, -5); c.lineTo(pr * 0.7, -5 - pr * 0.7); c.stroke();
    c.restore();
    // arms: violet sleeves, bare hands
    c.strokeStyle = '#6d34c9'; c.lineWidth = 5.8; c.beginPath();
    c.moveTo(-8, -17 + crouch * 0.5); c.quadraticCurveTo(-17, -17 + armLift, -23, -10 + armLift);
    c.moveTo(8, -17 + crouch * 0.5); c.quadraticCurveTo(17, -21 - armLift * 0.3, 23, -13 - armLift * 0.3); c.stroke();
    circ(c, -24.5, -9 + armLift, 3.1, '#9a6446'); circ(c, 24.5, -12 - armLift * 0.3, 3.1, '#9a6446');
    // neck + head
    rr(c, -3.6, -27 + crouch, 7.2, 8, 3, '#835035'); ell(c, 0, -33 + crouch, 8.6, 10.2, -0.05, '#9a6446');
    // hair cap
    c.fillStyle = '#3a1f6b'; c.beginPath(); c.moveTo(-9, -33 + crouch); c.quadraticCurveTo(-13, -46 + crouch, -1, -46.5 + crouch); c.quadraticCurveTo(10, -46 + crouch, 9.4, -34 + crouch);
    c.quadraticCurveTo(3, -40 + crouch, -3, -38 + crouch); c.quadraticCurveTo(-6, -36 + crouch, -7.5, -31 + crouch); c.closePath(); c.fill();
    // hibiscus
    for (let i = 0; i < 5; i++) { const a = i / 5 * TAU - 1.2; ell(c, 6.5 + Math.cos(a) * 3.2, -42 + crouch + Math.sin(a) * 3.2, 2.5, 1.7, a, '#ff5d73'); }
    circ(c, 6.5, -42 + crouch, 1.5, '#ffe27a');
    // round pink shades + smile
    c.lineWidth = 1.1; c.strokeStyle = '#5b2a9d'; circ(c, -3.4, -32.5 + crouch, 3.5, '#ff5fa2'); c.stroke(); circ(c, 4.6, -32.5 + crouch, 3.5, '#ff5fa2'); c.stroke();
    c.beginPath(); c.moveTo(0.1, -32.5 + crouch); c.lineTo(1.2, -32.5 + crouch); c.stroke();
    c.strokeStyle = '#6b3a24'; c.lineWidth = 1.2; c.beginPath(); c.arc(2.2, -27.6 + crouch, 2.6, 0.25, Math.PI - 0.5); c.stroke();
    c.strokeStyle = '#d9b6ffaa'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-10, -18 + crouch); c.quadraticCurveTo(-14, -8 + crouch, -9, 3 + crouch); c.stroke();
  }

  /* =====================================================================================
   * MAKO — The Acrobat. Lean and tall, topknot + trailing headband, slim lightning shortboard.
   * ===================================================================================== */
  function drawMako(c, pose) {
    const q = P(pose), crouch = q.crouch, armLift = q.armLift, now = q.now;
    const flutter = Math.sin(now * 0.012) * 3 - q.lean * 22;
    // slim shortboard with lightning stripe and thruster fins
    c.beginPath(); c.moveTo(-43, 19); c.quadraticCurveTo(-20, 11, 14, 13); c.quadraticCurveTo(34, 15, 43, 22); c.quadraticCurveTo(30, 30, 6, 31); c.quadraticCurveTo(-24, 31, -43, 19); c.closePath();
    c.fillStyle = lgrad(c, -43, 43, ['#8eed44', '#e6ff6a', '#ffd84f']); c.fill(); c.strokeStyle = '#f6ffd0'; c.lineWidth = 1.3; c.stroke();
    c.strokeStyle = '#183a2b'; c.lineWidth = 2.4; c.lineJoin = 'round'; c.beginPath(); c.moveTo(-30, 19.5); c.lineTo(-15, 17); c.lineTo(-9, 23); c.lineTo(6, 18.5); c.lineTo(12, 25); c.lineTo(31, 22); c.stroke();
    poly(c, [[-16, 29], [-12, 35], [-8, 29.5]], '#126b4a'); poly(c, [[-4, 30], [0, 36], [4, 30]], '#126b4a'); poly(c, [[8, 29.5], [12, 35], [16, 29]], '#126b4a');
    // body group is stretched a little taller and narrower than Kai
    c.save(); c.translate(0, 14); c.scale(0.94, 1.1); c.translate(0, -14);
    // legs: dark green capris, bare ankles, yellow straps
    c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = '#124a36'; c.lineWidth = 7.2; c.beginPath();
    c.moveTo(-6, 1 + crouch * 0.25); c.lineTo(-12, 12); c.moveTo(6, 1 + crouch * 0.25); c.lineTo(14, 12); c.stroke();
    c.strokeStyle = '#e0b08a'; c.lineWidth = 5.4; c.beginPath(); c.moveTo(-12, 12); c.lineTo(-15, 17.5); c.moveTo(14, 12); c.lineTo(17, 17.5); c.stroke();
    c.strokeStyle = '#ffd23f'; c.lineWidth = 2.2; c.beginPath(); c.moveTo(-17.5, 14.5); c.lineTo(-12.5, 15.5); c.moveTo(14.5, 14.5); c.lineTo(19.5, 15.5); c.stroke();
    // torso: lime sleeveless top, cross straps, yellow belt
    c.save(); c.translate(0, -10 + crouch); c.rotate(q.torsoRot);
    c.beginPath(); c.moveTo(-9, -14); c.quadraticCurveTo(0, -18, 9, -13); c.lineTo(10, 5); c.quadraticCurveTo(0, 10, -10, 5); c.closePath(); c.fillStyle = '#e0b08a'; c.fill();
    c.beginPath(); c.moveTo(-8, -12); c.quadraticCurveTo(0, -15, 8, -12); c.lineTo(9.4, 5); c.quadraticCurveTo(0, 9, -9.4, 5); c.closePath(); c.fillStyle = '#a5f04c'; c.fill();
    c.strokeStyle = '#173326'; c.lineWidth = 1.9; c.beginPath(); c.moveTo(-6, -13); c.lineTo(6, 4); c.moveTo(6, -13); c.lineTo(-6, 4); c.stroke();
    rr(c, -10, 2, 20, 4, 2, '#ffd23f'); circ(c, 0, -4.5, q.fx ? 2.6 : 1.8, '#173326');
    c.restore();
    // arms spread wide for balance, yellow wrist wraps
    c.strokeStyle = '#e0b08a'; c.lineWidth = 5.2; c.beginPath();
    c.moveTo(-8, -17 + crouch * 0.5); c.quadraticCurveTo(-21, -19 + armLift, -29, -8 + armLift);
    c.moveTo(8, -17 + crouch * 0.5); c.quadraticCurveTo(21, -23 - armLift * 0.3, 29, -13 - armLift * 0.3); c.stroke();
    c.strokeStyle = '#ffd23f'; c.lineWidth = 5.6; c.beginPath(); c.moveTo(-26, -11 + armLift); c.lineTo(-29, -8 + armLift); c.moveTo(26, -15.5 - armLift * 0.3); c.lineTo(29, -13 - armLift * 0.3); c.stroke();
    // head
    rr(c, -3.6, -27 + crouch, 7.2, 8, 3, '#c8956e'); ell(c, 0, -33 + crouch, 8.4, 10, -0.04, '#e0b08a');
    // headband tails flutter behind
    c.strokeStyle = '#ffd23f'; c.lineWidth = 2.6; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-8.4, -37 + crouch); c.bezierCurveTo(-16, -36 + crouch, -20 + flutter * 0.4, -31 + crouch, -25 + flutter, -30 + crouch + flutter * 0.25); c.stroke();
    c.beginPath(); c.moveTo(-8.2, -36 + crouch); c.bezierCurveTo(-15, -33 + crouch, -19 + flutter * 0.5, -27 + crouch, -23 + flutter * 0.9, -24 + crouch - flutter * 0.2); c.stroke();
    // hair cap + topknot
    c.fillStyle = '#2a1c14'; c.beginPath(); c.moveTo(-8.6, -35 + crouch); c.quadraticCurveTo(-10, -45 + crouch, 0, -45.5 + crouch); c.quadraticCurveTo(10, -45 + crouch, 8.8, -35 + crouch); c.quadraticCurveTo(0, -40 + crouch, -8.6, -35 + crouch); c.closePath(); c.fill();
    circ(c, 0, -50 + crouch, 5.6, '#2a1c14'); rr(c, -3, -46.5 + crouch, 6, 3, 1.4, '#ffd23f');
    // headband across the forehead
    c.strokeStyle = '#ffd23f'; c.lineWidth = 3; c.beginPath(); c.moveTo(-8.6, -37.6 + crouch); c.quadraticCurveTo(0, -40.4 + crouch, 8.6, -37.6 + crouch); c.stroke();
    // lively eyes, brows and grin
    ell(c, -3.3, -32 + crouch, 2.3, 2.1, 0, '#ffffff'); ell(c, 3.9, -32 + crouch, 2.3, 2.1, 0, '#ffffff');
    circ(c, -2.7, -31.9 + crouch, 1.15, '#1b1210'); circ(c, 4.5, -31.9 + crouch, 1.15, '#1b1210');
    c.strokeStyle = '#2a1c14'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-6, -35 + crouch); c.lineTo(-1.8, -34.2 + crouch); c.moveTo(7, -35 + crouch); c.lineTo(2.6, -34.2 + crouch); c.stroke();
    c.strokeStyle = '#8a4b33'; c.lineWidth = 1.3; c.beginPath(); c.arc(0.4, -28.4 + crouch, 3.2, 0.2, Math.PI - 0.2); c.stroke();
    c.restore();
  }

  /* =====================================================================================
   * TALA — The Guardian. Broad lifeguard-knight: finned helmet, shell pauldrons, life-ring chest plate, longboard.
   * ===================================================================================== */
  function drawTala(c, pose) {
    const q = P(pose), crouch = q.crouch, armLift = q.armLift;
    // long, wide cream longboard with red rails and a life-ring emblem
    c.beginPath(); c.moveTo(-52, 20); c.quadraticCurveTo(-50, 10, -28, 11); c.quadraticCurveTo(16, 13, 50, 17); c.quadraticCurveTo(44, 34, 8, 36); c.quadraticCurveTo(-34, 36, -52, 20); c.closePath();
    c.fillStyle = lgrad(c, -52, 50, ['#fff8e6', '#ffe9bd', '#ffd48f']); c.fill(); c.strokeStyle = '#e5483f'; c.lineWidth = 2; c.stroke();
    c.beginPath(); c.moveTo(-40, 22); c.quadraticCurveTo(0, 29, 42, 23); c.strokeStyle = '#e5483f'; c.lineWidth = 3; c.stroke();
    c.beginPath(); c.moveTo(-40, 25); c.quadraticCurveTo(0, 32, 40, 26); c.strokeStyle = '#ffcf6a'; c.lineWidth = 1.2; c.stroke();
    c.beginPath(); c.arc(-30, 21, 4.6, 0, TAU); c.strokeStyle = '#ffffff'; c.lineWidth = 3; c.stroke();
    c.setLineDash([3.6, 3.6]); c.beginPath(); c.arc(-30, 21, 4.6, 0, TAU); c.strokeStyle = '#e5483f'; c.lineWidth = 3; c.stroke(); c.setLineDash([]);
    poly(c, [[-4, 34], [2, 42], [8, 35]], '#c93a35');
    // body group is a little broader than the others
    c.save(); c.translate(0, 14); c.scale(1.1, 1.0); c.translate(0, -14);
    // legs: red boardshorts to the knee, bare calves, gold anklets
    c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = '#d9423a'; c.lineWidth = 9; c.beginPath();
    c.moveTo(-6, 1 + crouch * 0.25); c.lineTo(-11, 10); c.moveTo(6, 1 + crouch * 0.25); c.lineTo(13, 10); c.stroke();
    c.strokeStyle = '#a8683f'; c.lineWidth = 6.4; c.beginPath(); c.moveTo(-11, 10); c.lineTo(-15, 17.5); c.moveTo(13, 10); c.lineTo(17, 17.5); c.stroke();
    c.strokeStyle = '#ffcf6a'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(-18, 15); c.lineTo(-12.5, 17.5); c.moveTo(14.5, 15); c.lineTo(20, 17.5); c.stroke();
    // chest plate with life-ring emblem
    c.save(); c.translate(0, -10 + crouch); c.rotate(q.torsoRot);
    c.beginPath(); c.moveTo(-12, -14); c.quadraticCurveTo(0, -20, 12, -14); c.lineTo(13.5, 5); c.quadraticCurveTo(0, 12, -13.5, 5); c.closePath(); c.fillStyle = '#ff7a45'; c.fill(); c.strokeStyle = '#ffcf6a'; c.lineWidth = 1.8; c.stroke();
    rr(c, -12.5, 2, 25, 4.5, 2, '#ffcf6a');
    circ(c, 0, -5, 6.2, '#fff3dc');
    for (let i = 0; i < 4; i++) { c.beginPath(); c.arc(0, -5, 4.7, i * Math.PI / 2 + 0.15, i * Math.PI / 2 + Math.PI / 4 + 0.15); c.strokeStyle = '#e5483f'; c.lineWidth = 2.6; c.stroke(); }
    circ(c, 0, -5, 2.4, q.fx ? '#ffe9a8' : '#ff7a45');
    c.restore();
    // arms: thick, with gold bracers and fists
    c.strokeStyle = '#a8683f'; c.lineWidth = 7.2; c.beginPath();
    c.moveTo(-10, -17 + crouch * 0.5); c.quadraticCurveTo(-19, -16 + armLift, -25, -9 + armLift);
    c.moveTo(10, -17 + crouch * 0.5); c.quadraticCurveTo(19, -20 - armLift * 0.3, 25, -12 - armLift * 0.3); c.stroke();
    c.strokeStyle = '#ffcf6a'; c.lineWidth = 8; c.beginPath(); c.moveTo(-21.5, -11.5 + armLift); c.lineTo(-24, -10 + armLift); c.moveTo(21.5, -14 - armLift * 0.3); c.lineTo(24, -12.6 - armLift * 0.3); c.stroke();
    circ(c, -26.6, -8.6 + armLift, 3.8, '#a8683f'); circ(c, 26.6, -11.6 - armLift * 0.3, 3.8, '#a8683f');
    // shell pauldrons make the shoulders unmistakable
    [-1, 1].forEach(s => {
      const cx = s * 13, cy = -15 + crouch * 0.5;
      c.beginPath(); c.arc(cx, cy, 8, Math.PI, TAU); c.closePath(); c.fillStyle = '#ffcf6a'; c.fill(); c.strokeStyle = '#d99a3b'; c.lineWidth = 1; c.stroke();
      c.beginPath(); for (let k = -1; k <= 1; k++) { c.moveTo(cx, cy); c.lineTo(cx + k * 5.2, cy - 7); } c.stroke();
    });
    // head: neck, face, helmet with dorsal fin, zinc stripe
    rr(c, -4, -27 + crouch, 8, 8, 3, '#8f5733'); ell(c, 0, -33 + crouch, 9.6, 10.6, -0.04, '#a8683f');
    c.beginPath(); c.moveTo(-10.2, -33 + crouch); c.quadraticCurveTo(-13, -52 + crouch, 0, -52 + crouch); c.quadraticCurveTo(13, -52 + crouch, 10.2, -33 + crouch);
    c.quadraticCurveTo(0, -39.5 + crouch, -10.2, -33 + crouch); c.closePath(); c.fillStyle = '#fff3dc'; c.fill(); c.strokeStyle = '#ffcf6a'; c.lineWidth = 1.6; c.stroke();
    poly(c, [[-3, -51 + crouch], [3, -63 + crouch], [8.5, -50.5 + crouch]], '#ff7a45', '#ffcf6a', 1);
    c.strokeStyle = '#e5483f'; c.lineWidth = 2; c.beginPath(); c.moveTo(-9, -40 + crouch); c.quadraticCurveTo(0, -45 + crouch, 9, -40 + crouch); c.stroke();
    circ(c, -10, -33.5 + crouch, 2.4, '#ffcf6a'); circ(c, 10, -33.5 + crouch, 2.4, '#ffcf6a');
    rr(c, -5.8, -31.2 + crouch, 12.4, 2.8, 1.4, '#ffffff');
    ell(c, -3.4, -34.4 + crouch, 1.6, 1.9, 0, '#1b1210'); ell(c, 4, -34.4 + crouch, 1.6, 1.9, 0, '#1b1210');
    c.strokeStyle = '#2a1810'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-6, -37.4 + crouch); c.lineTo(-1.5, -36.4 + crouch); c.moveTo(7, -37.4 + crouch); c.lineTo(2.5, -36.4 + crouch); c.stroke();
    c.strokeStyle = '#6b3a24'; c.lineWidth = 1.2; c.beginPath(); c.arc(0.4, -27.4 + crouch, 2.6, 0.3, Math.PI - 0.3); c.stroke();
    c.restore();
  }

  /* =====================================================================================
   * Roster. `ability` must match an id in abilities.js. `price` 0 = free starter.
   * ===================================================================================== */
  const LIST = [
    { id: 'kai', name: 'Kai', title: 'The Speedster', price: 0, ability: 'surge', blurb: 'Born on the break. Always first to the horizon.',
      palette: { a: '#12d9d3', b: '#07476f', glow: 'rgba(80,255,240,.38)' }, draw: drawKai },
    { id: 'luna', name: 'Luna', title: 'The Magnet Surfer', price: 150, ability: 'tidepull', blurb: 'The tide brings her treasure, and she never misses a shell.',
      palette: { a: '#c56dff', b: '#3d1b7a', glow: 'rgba(255,214,110,.38)' }, draw: drawLuna },
    { id: 'mako', name: 'Mako', title: 'The Acrobat', price: 400, ability: 'skyflip', blurb: 'Treats every swell like a launch ramp.',
      palette: { a: '#a4f04a', b: '#0e5a3d', glow: 'rgba(210,255,120,.38)' }, draw: drawMako },
    { id: 'tala', name: 'Tala', title: 'The Guardian', price: 750, ability: 'coralward', blurb: 'Reef-watch captain. Nothing gets past her shield.',
      palette: { a: '#ff8a5c', b: '#8f2438', glow: 'rgba(255,150,130,.4)' }, draw: drawTala }
  ];

  const Characters = {
    list: LIST,
    starter: 'kai',
    get(id) { return LIST.find(c => c.id === id) || LIST[0]; },
    ids() { return LIST.map(c => c.id); },

    /**
     * Paint a surfer. pose = { x, y, scale, now, lean, ducking, jumping, flip, fx, alpha }
     * (x, y) is the board centre. flip rotates the whole body (radians) for the Acrobat's flip.
     */
    draw(ctx, def, pose) {
      ctx.save();
      ctx.translate(pose.x, pose.y); ctx.scale(pose.scale, pose.scale);
      if (pose.alpha != null && pose.alpha < 1) ctx.globalAlpha = pose.alpha;
      ctx.rotate((pose.lean || 0) + Math.sin((pose.now || 0) * 0.003) * 0.018);
      if (pose.flip) { ctx.translate(0, -8); ctx.rotate(pose.flip); ctx.translate(0, 8); }
      def.draw(ctx, pose);
      ctx.restore();
    },

    /** Water shadow; stays on the surface while the surfer is airborne. air = 0..1+ */
    shadow(ctx, x, y, scale, air) {
      ctx.save(); ctx.globalAlpha = Math.max(0.12, 0.55 - air * 0.3); ctx.fillStyle = '#003249';
      ctx.beginPath(); ctx.ellipse(x, y, 33 * scale * Math.max(0.6, 1 - air * 0.18), 7 * scale, 0, 0, TAU); ctx.fill(); ctx.restore();
    }
  };
  SD.Characters = Characters;
  SD.Draw = { rr, poly, ell, circ };
})();
