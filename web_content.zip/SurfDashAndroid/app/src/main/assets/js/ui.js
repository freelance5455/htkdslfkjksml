/* Surf Dash — interface (menu, shop, HUD widgets)
 * Pure DOM. The game core calls into SD.UI; UI buttons call back into SD.Game, which is looked up
 * lazily at click time, so script order does not matter.
 */
(function () {
  'use strict';
  const SD = (window.SD = window.SD || {});
  const $ = id => document.getElementById(id);
  const Save = SD.Save, Chars = SD.Characters, Abil = SD.Abilities, Audio = SD.Audio;
  const TAU = Math.PI * 2;

  const el = {
    overlay: $('overlay'), shop: $('shop'), toast: $('toast'), fx: $('fxLayer'), hints: $('bottom-hints'),
    title: $('overlayTitle'), subtitle: $('overlaySubtitle'), eyebrow: $('eyebrowText'), actionText: $('actionText'),
    resultCard: $('resultCard'), resultDistance: $('resultDistance'), resultBest: $('resultBest'), resultCoins: $('resultCoins'), recordBadge: $('recordBadge'),
    shopButton: $('shopButton'), menuButton: $('menuButton'), menuBank: $('menuBank'),
    dist: $('dist'), best: $('best'), runCoins: $('runCoins'), runCoinChip: $('runCoinChip'),
    abilityBtn: $('abilityBtn'), abilityRing: $('abilityRing'), abilityIcon: $('abilityIcon'), abilityLabel: $('abilityLabel'),
    shopTrack: $('shopTrack'), shopCoins: $('shopCoins'), shopBalance: $('shopBalance'), countdown: $('countdown'),
    menuName: $('menuName'), menuRole: $('menuRole'), menuAbilityName: $('menuAbilityName'), menuAbilityDesc: $('menuAbilityDesc'), menuAbilityIcon: $('menuAbilityIcon'),
    musicToggle: $('musicToggle'), sfxToggle: $('sfxToggle'), menuPreview: $('menuPreview')
  };

  const ico = id => `<svg class="ico"><use href="#${id}"/></svg>`;
  const game = () => SD.Game;

  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    const f = v => Math.max(0, Math.min(255, Math.round(amt < 0 ? v * (1 + amt) : v + (255 - v) * amt)));
    return '#' + ((1 << 24) + (f(r) << 16) + (f(g) << 8) + f(b)).toString(16).slice(1);
  }
  const secs = d => (d.duration >= 10 ? d.duration : Number(d.duration.toFixed(1))) + 's';

  /* ---------------------------------------------------------------- toast / celebration */
  let toastTimer = 0;
  function toast(msg, kind) {
    el.toast.textContent = msg; el.toast.className = 'show ' + (kind || '') + (el.shop.classList.contains('is-open') ? ' shop' : '');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.toast.className = ''; }, 2300);
  }
  function celebrate(node) {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const r = node.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height * 0.4;
    for (let i = 0; i < 14; i++) {
      const s = document.createElement('span'); s.className = 'coin-fly'; s.innerHTML = '<svg><use href="#i-coin"/></svg>';
      const a = (i / 14) * TAU + Math.random() * 0.4, d = 70 + Math.random() * 90;
      s.style.left = cx + 'px'; s.style.top = cy + 'px';
      s.style.setProperty('--dx', Math.cos(a) * d + 'px'); s.style.setProperty('--dy', Math.sin(a) * d - 30 + 'px'); s.style.setProperty('--rot', (Math.random() * 540 - 270) + 'deg');
      el.fx.appendChild(s); setTimeout(() => s.remove(), 1000);
    }
  }
  function bump(node, cls) { node.classList.remove(cls); void node.offsetWidth; node.classList.add(cls); }

  /* ---------------------------------------------------------------- animated previews */
  const previews = []; let prevRaf = 0, prevLast = 0, prevOn = false;

  function drawPreview(entry, now) {
    const cv = entry.cv, w = cv.clientWidth, h = cv.clientHeight; if (!w || !h) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const c = cv.getContext('2d'), def = entry.def(), ab = Abil.get(def.ability); if (!c || !def) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    // soft glow tinted per character
    const cx = w / 2, sc = Math.min(w / 118, h / 114);
    const g = c.createRadialGradient(cx, h * 0.62, 4, cx, h * 0.62, w * 0.6); g.addColorStop(0, def.palette.glow); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(220,255,250,.22)'; c.lineWidth = 1;
    for (let i = 0; i < 4; i++) { const y = h * (0.7 + i * 0.075) + Math.sin(now * 0.002 + i) * 1.5; c.beginPath(); c.moveTo(w * 0.1, y); c.quadraticCurveTo(cx, y + 4, w * 0.9, y); c.stroke(); }
    // showcase loop: ability plays for ~45% of every 4.4s
    const cyc = (now % 4400) / 4400, active = cyc < 0.45, f = active ? cyc / 0.45 : 0;
    const mo = active && ab && ab.motion ? ab.motion(f) : { lift: 0, spin: 0 };
    const bob = Math.sin(now * 0.003 + (def.id.length)) * 2 * sc, baseY = h * 0.66, y = baseY - mo.lift * h * 0.15 + bob;
    Chars.shadow(c, cx, baseY + 28 * sc, sc, mo.lift);
    if (active && ab && ab.drawFx) ab.drawFx(c, { x: cx, y, s: sc, now, f, remaining: (1 - f) * ab.duration });
    Chars.draw(c, def, { x: cx, y, scale: sc, now, lean: Math.sin(now * 0.0016) * 0.07, jumping: mo.lift > 0.2, flip: mo.spin, fx: active });
  }
  function previewLoop(now) {
    if (!prevOn) { prevRaf = 0; return; }
    if (now - prevLast > 30) { prevLast = now; for (const e of previews) if (e.cv.isConnected && e.cv.offsetParent !== null) drawPreview(e, now); }
    prevRaf = requestAnimationFrame(previewLoop);
  }
  function startPreviews() { prevOn = true; if (!prevRaf) prevRaf = requestAnimationFrame(previewLoop); }
  function stopPreviews() { prevOn = false; }

  /* ---------------------------------------------------------------- menu panel */
  function refreshMenuCard() {
    const def = Chars.get(Save.equipped), ab = Abil.get(def.ability);
    el.menuName.textContent = def.name; el.menuRole.textContent = def.title.toUpperCase();
    el.menuAbilityName.textContent = ab.name + ' · ' + secs({ duration: ab.cooldown }) + ' cooldown'; el.menuAbilityDesc.textContent = ab.desc;
    el.menuAbilityIcon.innerHTML = `<use href="#${ab.icon}"/>`; el.menuAbilityIcon.style.setProperty('--abc', ab.color);
  }
  function refreshBalance() {
    const n = Save.coins;
    el.menuBank.textContent = n; el.shopCoins.textContent = n;
    if (el.shop.classList.contains('is-open')) updateShop();
  }
  function refreshToggles() {
    el.musicToggle.setAttribute('aria-pressed', String(Audio.musicOn)); el.sfxToggle.setAttribute('aria-pressed', String(Audio.sfxOn));
  }

  /** mode: 'start' | 'over' | 'paused'.  data (over): { distance, best, record, coins } */
  function showOverlay(mode, data) {
    data = data || {}; el.overlay.dataset.mode = mode;
    el.resultCard.classList.remove('show'); el.recordBadge.classList.remove('show');
    el.shopButton.classList.toggle('is-hidden', mode === 'paused'); el.menuButton.classList.toggle('show', mode === 'paused');
    if (mode === 'start') {
      el.eyebrow.textContent = 'THE TROPICAL ENDLESS RUN'; el.title.innerHTML = 'RIDE THE <span>BLUE.</span>';
      el.subtitle.textContent = 'Find your flow. Chase the next wave. Collect coins, unlock new surfers, and see how far you can ride.';
      el.actionText.textContent = 'DROP IN';
    } else if (mode === 'over') {
      el.eyebrow.textContent = data.record ? 'NEW PERSONAL BEST ✦' : 'RIDE COMPLETE'; el.title.innerHTML = 'WIPEOUT<span> & RESET.</span>';
      el.subtitle.textContent = 'Every wipeout teaches the rhythm. Spend your coins, find your line, and beat your last run.';
      el.resultCard.classList.add('show'); el.resultDistance.textContent = data.distance; el.resultBest.textContent = data.best; el.resultCoins.textContent = data.coins;
      if (data.record) el.recordBadge.classList.add('show');
      el.actionText.textContent = 'RIDE AGAIN';
    } else {
      el.eyebrow.textContent = 'THE OCEAN CAN WAIT'; el.title.innerHTML = 'CATCH YOUR<span> BREATH.</span>';
      el.subtitle.textContent = 'Your board is steady. Your run is paused. Jump back in whenever you’re ready.';
      el.actionText.textContent = 'RESUME RIDE';
    }
    refreshMenuCard(); refreshBalance(); refreshToggles();
    el.overlay.classList.add('is-open'); el.overlay.setAttribute('aria-hidden', 'false');
    startPreviews();
  }
  function hideOverlay() { el.overlay.classList.remove('is-open'); el.overlay.setAttribute('aria-hidden', 'true'); }

  /* ---------------------------------------------------------------- shop */
  let shopBuilt = false;
  const cards = {};

  function buildShop() {
    if (shopBuilt) return; shopBuilt = true;
    Chars.list.forEach(def => {
      const ab = Abil.get(def.ability), card = document.createElement('article');
      card.className = 'shop-card'; card.dataset.id = def.id; card.setAttribute('role', 'listitem');
      card.style.setProperty('--c1', def.palette.a); card.style.setProperty('--c2', def.palette.b); card.style.setProperty('--abc', ab.color);
      card.innerHTML =
        `<div class="card-stage"><canvas aria-hidden="true"></canvas><span class="status-badge"></span></div>` +
        `<div class="card-body"><div><div class="card-name">${def.name}</div><div class="card-role">${def.title.toUpperCase()}</div></div>` +
        `<div class="card-ability">${ico(ab.icon)}<div><b>${ab.name}</b><span>${ab.short}</span></div></div>` +
        `<div class="card-stats"><span>${secs({ duration: ab.duration })} active</span><span>${secs({ duration: ab.cooldown })} cooldown</span></div></div>` +
        `<div class="afford" hidden><i></i></div><button class="buy-btn" data-id="${def.id}"></button>`;
      el.shopTrack.appendChild(card);
      cards[def.id] = { card, badge: card.querySelector('.status-badge'), btn: card.querySelector('.buy-btn'), afford: card.querySelector('.afford'), bar: card.querySelector('.afford i') };
      previews.push({ cv: card.querySelector('canvas'), def: () => def });
    });
    el.shopTrack.addEventListener('click', e => { const b = e.target.closest('.buy-btn'); if (b) onCardAction(b.dataset.id); });
  }

  function updateShop() {
    const coins = Save.coins, eq = Save.equipped;
    Chars.list.forEach(def => {
      const c = cards[def.id]; if (!c) return;
      const owned = Save.owns(def.id), equipped = owned && eq === def.id, afford = coins >= def.price;
      c.card.classList.toggle('is-equipped', equipped); c.card.classList.toggle('is-locked', !owned);
      c.badge.innerHTML = equipped ? ico('i-check') + 'EQUIPPED' : owned ? 'UNLOCKED' : ico('i-lock') + 'LOCKED';
      c.afford.hidden = owned;
      if (!owned) c.bar.style.width = Math.min(100, Math.round(coins / def.price * 100)) + '%';
      c.btn.className = 'buy-btn ' + (equipped ? 'is-equipped' : owned ? 'is-equip' : afford ? 'is-buy' : 'is-poor');
      c.btn.innerHTML = equipped ? ico('i-check') + 'EQUIPPED'
        : owned ? 'EQUIP'
        : afford ? `BUY ${ico('i-coin')} ${def.price}`
        : `${ico('i-lock')} ${ico('i-coin')} ${def.price}<span class="need">need ${def.price - coins}</span>`;
      c.btn.setAttribute('aria-disabled', String(equipped));
    });
  }

  function onCardAction(id) {
    const def = Chars.get(id), c = cards[id];
    if (Save.owns(id)) {
      if (Save.equipped === id) return;
      Save.equip(id); Audio.play('equip'); bump(c.card, 'pop'); toast(def.name + ' equipped', 'good'); refreshMenuCard(); updateShop(); return;
    }
    const r = Save.purchase(id, def.price);               // the only place coins are spent
    if (r.ok) {
      Save.equip(id); Audio.play('buy'); bump(c.card, 'pop'); celebrate(c.card); bump(el.shopBalance, 'spend');
      toast(def.name + ' unlocked and equipped!', 'good'); refreshMenuCard(); refreshBalance();
    } else {
      Audio.play('deny'); bump(c.card, 'shake'); bump(el.shopBalance, 'flash');
      toast(r.reason === 'poor' ? `Need ${r.missing} more coins for ${def.name}.` : 'Purchase failed.', 'bad');
    }
  }

  function openShop() {
    buildShop(); updateShop(); refreshBalance();
    el.shop.classList.add('is-open'); el.shop.setAttribute('aria-hidden', 'false'); Audio.play('click');
    const eqc = cards[Save.equipped]; if (eqc) setTimeout(() => { try { eqc.card.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'auto' }); } catch (e) {} }, 30);
    startPreviews();
  }
  function closeShop() { el.shop.classList.remove('is-open'); el.shop.setAttribute('aria-hidden', 'true'); Audio.play('click'); refreshMenuCard(); }
  const shopIsOpen = () => el.shop.classList.contains('is-open');

  /* ---------------------------------------------------------------- HUD widgets */
  let abLast = { phase: '', label: '', p: -1 };
  function setAbility(def) {
    abLast = { phase: '', label: '', p: -1 };
    if (!def) { el.abilityBtn.classList.add('is-hidden'); return; }
    el.abilityBtn.classList.remove('is-hidden');
    el.abilityBtn.style.setProperty('--ab-a', shade(def.color, 0.15)); el.abilityBtn.style.setProperty('--ab-b', shade(def.color, -0.38));
    el.abilityIcon.innerHTML = `<use href="#${def.icon}"/>`;
    el.abilityBtn.setAttribute('aria-label', 'Use ' + def.name);
  }
  function updateAbility(st) {
    if (!st) return;
    const label = st.phase === 'ready' ? 'READY' : st.phase === 'active' ? st.secs.toFixed(1) : Math.ceil(st.secs) + 's';
    const p = Math.round(st.frac * 200) / 2;
    if (abLast.phase !== st.phase) { el.abilityBtn.dataset.phase = st.phase; abLast.phase = st.phase; }
    if (abLast.label !== label) { el.abilityLabel.textContent = label; abLast.label = label; }
    if (abLast.p !== p) { el.abilityBtn.style.setProperty('--p', p); abLast.p = p; }
  }
  function setRunCoins(n, pulse) { el.runCoins.textContent = n; if (pulse) bump(el.runCoinChip, 'pulse'); }
  function countdownTick(n) { el.countdown.textContent = n; el.countdown.classList.remove('tick'); void el.countdown.offsetWidth; el.countdown.classList.add('tick'); }
  function countdownClear() { el.countdown.classList.remove('tick'); el.countdown.textContent = ''; }
  function fadeHints(hide) { el.hints.classList.toggle('faded', !!hide); }

  /* ---------------------------------------------------------------- wiring */
  function wire() {
    el.shopButton.addEventListener('click', openShop);
    $('shopBack').addEventListener('click', closeShop);
    el.menuButton.addEventListener('click', () => game().quitToMenu());
    el.musicToggle.addEventListener('click', () => { Audio.setMusic(!Audio.musicOn); refreshToggles(); Audio.play('click'); });
    el.sfxToggle.addEventListener('click', () => { Audio.setSfx(!Audio.sfxOn); refreshToggles(); Audio.play('click'); });
    previews.push({ cv: el.menuPreview, def: () => Chars.get(Save.equipped) });
    Save.onChange(refreshBalance);
    window.addEventListener('resize', () => { if (prevOn) prevLast = 0; });
  }

  SD.UI = {
    el, wire, showOverlay, hideOverlay, openShop, closeShop, shopIsOpen, refreshMenuCard, refreshBalance, refreshToggles,
    startPreviews, stopPreviews, toast, setAbility, updateAbility, setRunCoins, countdownTick, countdownClear, fadeHints,
    buildShop, updateShop, onCardAction
  };
})();
