/* Surf Dash — game core
 * Loop, controls, obstacle/coin director, collisions, pause/resume, saving hooks.
 * Background, obstacle art and the three-lane runner mechanics are the original game's; the new
 * systems (coins, characters, abilities, shop) plug into the same loop instead of running beside it.
 */
(function () {
'use strict';
const SD = window.SD, Save = SD.Save, Audio = SD.Audio, Chars = SD.Characters, Abil = SD.Abilities, UI = SD.UI;
const TAU = Math.PI * 2;

// Older WebViews lack roundRect; the original art relies on it.
if (!CanvasRenderingContext2D.prototype.roundRect) {
  CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
    r = Math.min(typeof r === 'number' ? r : (r && r[0]) || 0, Math.abs(w) / 2, Math.abs(h) / 2);
    this.moveTo(x + r, y); this.arcTo(x + w, y, x + w, y + h, r); this.arcTo(x + w, y + h, x, y + h, r); this.arcTo(x, y + h, x, y, r); this.arcTo(x, y, x + w, y, r); this.closePath();
  };
}

const canvas = document.getElementById('game'), ctx = canvas.getContext('2d');
const actionButton = document.getElementById('actionButton'), pauseButton = document.getElementById('pause'), abilityBtn = document.getElementById('abilityBtn');
const distEl = UI.el.dist, bestEl = UI.el.best;

let W = 0, H = 0, dpr = 1, running = false, paused = false, gameOver = false, dying = false, menuIdle = false, last = 0, idleLast = 0, raf = 0;
let distance = 0, speed = 300, courseZ = 0, obstacles = [], coins = [], parts = [], queue = [], lastCoinPos = 0;
let lane = 1, playerX = 0, jump = 0, duck = 0, invuln = 0, sessionBest = false, runTime = 0, runId = 0;
let runCoins = 0, combo = 0, lastCoinT = 0, countdownT = 0, lastCdNum = 0, curPy = 0, curLiftN = 0;
let shakeT = 0, shakeAmp = 0, flashT = 0, flashMax = 1, flashColor = '#fff', menuMode = 'start', lastDistShown = -1;
let equippedDef = Chars.get(Save.equipped), manual = false;   // manual: tests step the simulation themselves
const HIT_Z = 0.57;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = t => t * t * (3 - 2 * t);

function resize() { dpr = Math.min(window.devicePixelRatio || 1, 2); W = window.innerWidth; H = window.innerHeight; canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); playerX = laneX(lane); }
// Lane centres. The player, obstacles and coins all share this one mapping, so what you see is what you hit.
function laneX(l) { return W * (0.5 + (l - 1) * 0.2); }
function laneProj(l, p) { return W * 0.5 + (laneX(l) - W * 0.5) * (0.18 + p * (0.82 / HIT_Z)); }   // equals laneX(l) exactly at HIT_Z
function obstacleX(o, p = o.z) { return laneProj(o.lane, p); }

function roundedRect(x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,Math.min(r,Math.abs(w)/2,Math.abs(h)/2));if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.stroke()}}
function poly(points,fill,stroke,lineWidth=1){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lineWidth;ctx.stroke()}}
function glow(x,y,r,color){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
function cloud(x,y,s,a){ctx.save();ctx.globalAlpha=a;ctx.fillStyle='#f4ffff';ctx.beginPath();ctx.ellipse(x,y,s*.65,s*.22,0,0,Math.PI*2);ctx.ellipse(x-s*.3,y-s*.08,s*.3,s*.23,0,0,Math.PI*2);ctx.ellipse(x+s*.04,y-s*.19,s*.37,s*.32,0,0,Math.PI*2);ctx.ellipse(x+s*.36,y-s*.04,s*.28,s*.19,0,0,Math.PI*2);ctx.fill();ctx.restore()}
function drawIsland(points,color){poly(points,color)}

function drawBackground(t){
 const horizon=H*.425;
 const sky=ctx.createLinearGradient(0,0,0,horizon);sky.addColorStop(0,'#68d9ed');sky.addColorStop(.48,'#a7f0ee');sky.addColorStop(1,'#ffe0b0');ctx.fillStyle=sky;ctx.fillRect(0,0,W,horizon+2);
 glow(W*.79,H*.18,H*.19,'rgba(255,226,144,.20)');const sunR=Math.min(W,H)*.075;const sun=ctx.createRadialGradient(W*.79,H*.19,sunR*.08,W*.79,H*.19,sunR);sun.addColorStop(0,'#fff9d1');sun.addColorStop(.72,'#ffdfa0');sun.addColorStop(1,'#ffc58a00');ctx.fillStyle=sun;ctx.beginPath();ctx.arc(W*.79,H*.19,sunR,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff6c8';ctx.beginPath();ctx.arc(W*.79,H*.19,sunR*.48,0,Math.PI*2);ctx.fill();
 cloud(W*.18+(t*.006% (W+170))-80,H*.17,W*.13,.27);cloud(W*.53-(t*.003%(W+150)),H*.12,W*.09,.23);cloud(W*.96-(t*.004%(W+200)),H*.29,W*.15,.22);
 // distant tropical headlands
 drawIsland([[0,horizon*.84],[W*.055,horizon*.72],[W*.12,horizon*.77],[W*.19,horizon*.62],[W*.26,horizon*.77],[W*.37,horizon*.72],[W*.44,horizon*.86],[W*.44,horizon],[0,horizon]],'#589fa3');
 drawIsland([[W*.51,horizon*.88],[W*.62,horizon*.7],[W*.71,horizon*.78],[W*.78,horizon*.6],[W*.85,horizon*.74],[W*.94,horizon*.69],[W,horizon*.79],[W,horizon],[W*.51,horizon]],'#478c95');
 // tiny palm silhouettes on the right headland
 ctx.strokeStyle='#36737c';ctx.lineWidth=Math.max(1,W*.002);for(const [x,y,s] of [[.86,.78,.7],[.9,.72,1],[.95,.78,.6]]){const xx=W*x,yy=horizon*y;ctx.beginPath();ctx.moveTo(xx,yy+9*s);ctx.quadraticCurveTo(xx-2*s,yy,xx+1*s,yy-16*s);ctx.stroke();ctx.beginPath();ctx.moveTo(xx+1*s,yy-15*s);ctx.quadraticCurveTo(xx-10*s,yy-22*s,xx-13*s,yy-17*s);ctx.moveTo(xx+1*s,yy-15*s);ctx.quadraticCurveTo(xx+8*s,yy-25*s,xx+14*s,yy-20*s);ctx.moveTo(xx+1*s,yy-15*s);ctx.quadraticCurveTo(xx+13*s,yy-14*s,xx+14*s,yy-10*s);ctx.moveTo(xx+1*s,yy-15*s);ctx.quadraticCurveTo(xx-1*s,yy-26*s,xx-6*s,yy-26*s);ctx.stroke()}
 const sea=ctx.createLinearGradient(0,horizon,0,H);sea.addColorStop(0,'#32c8c8');sea.addColorStop(.25,'#0daebc');sea.addColorStop(.62,'#087ba1');sea.addColorStop(1,'#06476f');ctx.fillStyle=sea;ctx.fillRect(0,horizon,W,H-horizon);
 // shimmer under the sun
 for(let i=0;i<13;i++){const q=(i+1)/14;const yy=horizon+q*(H-horizon)*.9;const xx=W*.79+(Math.sin(t*.0018+i*1.7)*.035*W);const ww=(10+q*66)*(W/800);ctx.strokeStyle=`rgba(255,239,183,${.1+(Math.sin(t*.002+i)*.06)})`;ctx.lineWidth=1+q*1.2;ctx.beginPath();ctx.moveTo(xx-ww,yy);ctx.lineTo(xx+ww,yy);ctx.stroke()}
 // broad rolling ocean lines
 for(let i=0;i<13;i++){const p=i/12,yy=horizon+Math.pow(p,1.23)*(H-horizon);ctx.beginPath();for(let x=-10;x<=W+10;x+=12){const amp=1.2+p*5;const yw=yy+Math.sin(x*.012+i*1.6+t*.0015*(i%2?1:-1))*amp+Math.sin(x*.027-t*.001+i)*amp*.35;if(x===-10)ctx.moveTo(x,yw);else ctx.lineTo(x,yw)}ctx.strokeStyle=i%3===0?'rgba(201,255,248,.21)':'rgba(184,255,247,.10)';ctx.lineWidth=.7+p*1.15;ctx.stroke()}
 // the clean, readable three-lane surf course
 const bottom=H*1.08;const center=W*.5;const left=W*.045,right=W*.955;const course=ctx.createLinearGradient(0,horizon,0,H);course.addColorStop(0,'rgba(218,255,250,.015)');course.addColorStop(.5,'rgba(209,255,247,.075)');course.addColorStop(1,'rgba(185,255,244,.055)');poly([[center,H*.46],[right,bottom],[left,bottom]],course);
 // side rails are soft foam streaks
 for(const edge of [-1,1]){ctx.beginPath();ctx.moveTo(center,H*.46);ctx.bezierCurveTo(center+edge*W*.05,H*.62,center+edge*W*.28,H*.79,center+edge*W*.455,H*1.07);ctx.strokeStyle='rgba(220,255,251,.52)';ctx.lineWidth=Math.max(1.5,W*.0025);ctx.stroke();ctx.beginPath();ctx.moveTo(center,H*.46);ctx.bezierCurveTo(center+edge*W*.05,H*.62,center+edge*W*.28,H*.79,center+edge*W*.455,H*1.07);ctx.strokeStyle='rgba(17,238,217,.26)';ctx.lineWidth=Math.max(4,W*.008);ctx.stroke()}
 // lane dividers: moving pearl-white dashes create depth and speed
 const flow=(distance*.009)%1;
 for(const divider of [.4,.6]){const bx=W*divider;for(let i=0;i<10;i++){let p=(i/10+flow/1.1)%1;p=Math.pow(p,1.38);const y=H*.46+p*(H*.64);const x=center+(bx-center)*p;const sz=1+p*3.7;ctx.save();ctx.globalAlpha=.25+p*.48;roundedRect(x-sz*.5,y-sz*1.9,sz,sz*3.8,sz*.6,'#cafff5');ctx.restore()}}
 // occasional tiny spray on the course, all deterministic so rendering stays lightweight
 for(let i=0;i<18;i++){const f=(i*.173+distance*.003)%1;const side=i%2?1:-1;const xx=center+side*(W*.025+f*W*.42);const yy=H*.49+f*H*.5;ctx.fillStyle=`rgba(218,255,248,${.07+f*.13})`;ctx.beginPath();ctx.ellipse(xx,yy,1+f*2,1+f*1.5,side*.3,0,Math.PI*2);ctx.fill()}
 // two distant gull silhouettes
 for(let i=0;i<3;i++){const x=(W*(.31+i*.07)+t*.012)%(W*.55);const y=H*(.3+(i%2)*.035);ctx.strokeStyle='#417e83aa';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(x-5,y+1);ctx.quadraticCurveTo(x-2,y-3,x,y);ctx.quadraticCurveTo(x+3,y-3,x+6,y+1);ctx.stroke()}
}

function drawSplash(x,y,s,alpha=.4){ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle='#ddfffa';ctx.lineWidth=1.5*s;for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(x+(i-1)*10*s,y+Math.sin(i*2)*2*s,5*s,2*s,-.3+i*.3,Math.PI,Math.PI*2);ctx.stroke()}ctx.restore()}
function drawObstacle(o){const p=o.z,y=H*.48+p*H*.55,x=obstacleX(o,p),s=.2+p*1.2;ctx.save();ctx.translate(x,y);ctx.scale(s,s);
 // submerged shadow & foamy wake
 ctx.fillStyle='#00304b35';ctx.beginPath();ctx.ellipse(0,22,34,7,0,0,Math.PI*2);ctx.fill();drawSplash(-21,20,1.05,.34);drawSplash(22,19,.85,.25);
 if(o.type==='jump'){
   // Bright floating barrier: visually reads as something to jump over.
   roundedRect(-28,4,11,20,4,'#df594b');roundedRect(17,4,11,20,4,'#df594b');roundedRect(-34,-15,68,25,8,'#ef654f','#ffb16c');roundedRect(-33,-16,66,7,4,'#ffd36c');
   ctx.save();ctx.beginPath();ctx.roundRect(-28,-8,56,12,3);ctx.clip();for(let k=-2;k<5;k++){poly([[k*16-5,-10],[k*16+1,-10],[k*16-8,5],[k*16-14,5]],'#fff0b7')}ctx.restore();roundedRect(-8,-3,16,6,3,'#b94545');ctx.fillStyle='#fff3ba';ctx.beginPath();ctx.moveTo(-3,-1);ctx.lineTo(3,-1);ctx.lineTo(0,3);ctx.fill();
 }else if(o.type==='duck'){
   // Overhead foam-covered beam with clear side supports.
   roundedRect(-33,-41,8,62,3,'#bd7850');roundedRect(25,-41,8,62,3,'#bd7850');roundedRect(-39,-45,78,15,6,'#f5c16e','#fff0bd');roundedRect(-34,-48,68,7,3,'#fff0bc');
   for(let k=0;k<5;k++){roundedRect(-30+k*15,-42,5,8,2,k%2?'#e87b58':'#fff0bd')}
   roundedRect(-36,-30,72,4,2,'#dba45b');
 }else{
   // Tall striped channel buoy with a sun-yellow cap.
   ctx.fillStyle='#f65d54';ctx.beginPath();ctx.moveTo(-10,-22);ctx.lineTo(-13,12);ctx.quadraticCurveTo(0,20,13,12);ctx.lineTo(10,-22);ctx.closePath();ctx.fill();roundedRect(-10,-5,20,8,3,'#ffdf79');roundedRect(-9,-23,18,7,3,'#ff926a');
   ctx.fillStyle='#ffe0a0';ctx.beginPath();ctx.ellipse(0,-22,9,4,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#f5a15c';ctx.beginPath();ctx.arc(0,-31,5,Math.PI,Math.PI*2);ctx.lineTo(5,-22);ctx.lineTo(-5,-22);ctx.closePath();ctx.fill();
   ctx.strokeStyle='#fff1b9';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,-13);ctx.lineTo(0,-8);ctx.stroke();ctx.fillStyle='#fff1b9';ctx.beginPath();ctx.arc(0,-2,2,0,Math.PI*2);ctx.fill();
 }
 ctx.restore();}


/* ======================================================================== coin art */
const COIN_FRAMES = 14, COIN_S = 72, coinSprites = [];
function renderCoinFrame(c, ang) {
  const S = COIN_S, cx = S / 2, cy = S / 2, R = S * 0.36, cw = Math.cos(ang), sx = Math.max(0.17, Math.abs(cw));
  const halo = c.createRadialGradient(cx, cy, R * 0.5, cx, cy, S / 2); halo.addColorStop(0, 'rgba(255,214,90,.5)'); halo.addColorStop(1, 'rgba(255,214,90,0)'); c.fillStyle = halo; c.fillRect(0, 0, S, S);
  const th = R * 0.1 + R * 0.14 * (1 - sx);
  c.fillStyle = '#a85e0a'; for (const d of [-th, th]) { c.beginPath(); c.ellipse(cx + d, cy, R * sx, R, 0, 0, TAU); c.fill(); }
  c.save(); c.translate(cx, cy); c.scale(sx, 1);
  const g = c.createRadialGradient(-R * 0.3, -R * 0.35, R * 0.1, 0, 0, R); g.addColorStop(0, '#fff3a8'); g.addColorStop(0.55, '#ffc93d'); g.addColorStop(1, '#e48a16');
  c.beginPath(); c.arc(0, 0, R, 0, TAU); c.fillStyle = g; c.fill(); c.lineWidth = R * 0.1; c.strokeStyle = '#c4730d'; c.stroke();
  c.beginPath(); c.arc(0, 0, R * 0.74, 0, TAU); c.lineWidth = R * 0.07; c.strokeStyle = 'rgba(255,244,190,.85)'; c.stroke();
  // embossed sparkle, matching the brand mark
  const k = R * 0.5; c.fillStyle = '#b3640b'; c.beginPath(); c.moveTo(0, -k); c.quadraticCurveTo(k * 0.16, -k * 0.16, k, 0); c.quadraticCurveTo(k * 0.16, k * 0.16, 0, k); c.quadraticCurveTo(-k * 0.16, k * 0.16, -k, 0); c.quadraticCurveTo(-k * 0.16, -k * 0.16, 0, -k); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(255,240,170,.6)'; c.lineWidth = R * 0.05; c.beginPath(); c.moveTo(0, -k * 0.62); c.quadraticCurveTo(k * 0.1, -k * 0.1, k * 0.62, 0); c.stroke();
  c.beginPath(); c.arc(0, 0, R * 0.9, Math.PI * 1.1, Math.PI * 1.45); c.strokeStyle = 'rgba(255,255,255,.75)'; c.lineWidth = R * 0.09; c.stroke();
  c.restore();
}
function buildCoinSprites() {
  for (let i = 0; i < COIN_FRAMES; i++) { const cv = document.createElement('canvas'); cv.width = cv.height = COIN_S; renderCoinFrame(cv.getContext('2d'), i / COIN_FRAMES * TAU); coinSprites.push(cv); }
}

/* ======================================================================== particles / feedback */
const fx = {
  spark(x, y, n, color) { for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = 60 + Math.random() * 110; add({ k: 's', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40, life: 0.45 + Math.random() * 0.2, r: 2.6 + Math.random() * 2.2, color, rot: Math.random() * 3, g: 160 }); } },
  text(x, y, str, color) { add({ k: 't', x, y, vx: 0, vy: -46, life: 0.7, text: str, color, r: 15 }); },
  ring(x, y, r0, r1, color, life) { add({ k: 'r', x, y, vx: 0, vy: 0, life, r0, r1, color }); },
  burst(x, y, n, colors) { for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = 90 + Math.random() * 190; add({ k: 'd', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 70, life: 0.6 + Math.random() * 0.5, r: 3 + Math.random() * 4, color: colors[i % colors.length], rot: Math.random() * 6, vr: (Math.random() - 0.5) * 12, g: 380 }); } }
};
function add(p) { p.max = p.life; if (parts.length > 160) parts.splice(0, 20); parts.push(p); }
function updateFx(dt) {
  for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.life -= dt; if (p.life <= 0) { parts.splice(i, 1); continue; } p.x += p.vx * dt; p.y += p.vy * dt; if (p.g) p.vy += p.g * dt; if (p.vr) p.rot += p.vr * dt; else if (p.rot != null) p.rot += dt * 6; }
  shakeT = Math.max(0, shakeT - dt); flashT = Math.max(0, flashT - dt);
}
function drawParts() {
  for (const p of parts) {
    const a = clamp(p.life / p.max, 0, 1); ctx.save(); ctx.globalAlpha = a;
    if (p.k === 's') { ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = p.color; const r = p.r * (0.5 + a * 0.7); ctx.beginPath(); ctx.moveTo(0, -r * 1.7); ctx.lineTo(r * 0.45, -r * 0.45); ctx.lineTo(r * 1.7, 0); ctx.lineTo(r * 0.45, r * 0.45); ctx.lineTo(0, r * 1.7); ctx.lineTo(-r * 0.45, r * 0.45); ctx.lineTo(-r * 1.7, 0); ctx.lineTo(-r * 0.45, -r * 0.45); ctx.closePath(); ctx.fill(); }
    else if (p.k === 't') { ctx.font = `1000 ${p.r}px system-ui,sans-serif`; ctx.textAlign = 'center'; ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(70,40,0,.7)'; ctx.strokeText(p.text, p.x, p.y); ctx.fillStyle = p.color; ctx.fillText(p.text, p.x, p.y); }
    else if (p.k === 'r') { const t = 1 - a; ctx.strokeStyle = p.color; ctx.lineWidth = 3 * a + 0.5; ctx.beginPath(); ctx.ellipse(p.x, p.y, lerp(p.r0, p.r1, ease(t)), lerp(p.r0, p.r1, ease(t)) * 0.7, 0, 0, TAU); ctx.stroke(); }
    else { ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = p.color; ctx.fillRect(-p.r, -p.r * 0.6, p.r * 2, p.r * 1.2); }
    ctx.restore();
  }
}

/* The small surface abilities are allowed to touch (see abilities.js). */
const api = {
  get W() { return W; }, get H() { return H; }, now: 0, px: 0, py: 0, isDucking: false, pulled: [], fx,
  audio(n) { Audio.play(n); },
  flash(color, t) { flashColor = color; flashT = flashMax = t; },
  shake(a, t) { shakeAmp = a; shakeT = t; },
  setInvuln(t) { invuln = Math.max(invuln, t); },
  abilityReady() { Audio.play('ability_ready'); }
};

/* ======================================================================== course director */
// Obstacles and coins are placed by course position (pos), not timers, so coin trains can be laid out
// around obstacles that are already scheduled — coins never lead you into a crash.
function rollObstacle(prevPos) {
  const gap = (Math.max(0.48, 1.15 - distance / 1800) + Math.random() * 0.3) * speed / 850, r = Math.random();
  return { pos: prevPos + gap, lane: Math.floor(Math.random() * 3), type: r < 0.34 ? 'jump' : r < 0.62 ? 'duck' : 'block' };
}
// Keep scheduled obstacles known far enough ahead (in distance, not just count) for coin trains to be laid out safely.
function fillQueue() { while (queue.length < 4 || queue[queue.length - 1].pos < courseZ + 1.6) queue.push(rollObstacle(queue.length ? queue[queue.length - 1].pos : courseZ)); }
function addCoin(l, pos, h) { coins.push({ lane: l, z: courseZ - pos, h, phase: Math.random() * COIN_FRAMES, got: false, pull: 0 }); }

function placeCoins(cur) {
  const C = cur.pos;
  // An arc of coins hovering over a barrier rewards the jump — only when nothing else is near it in that lane.
  const laneClear = (from, to) => !queue.some(o => o.lane === cur.lane && o.pos > from && o.pos < to) && !obstacles.some(o => o.lane === cur.lane && o.z !== undefined && courseZ - o.z > from && courseZ - o.z < to && Math.abs(courseZ - o.z - C) > 1e-6);
  if (cur.type === 'jump' && laneClear(C - 0.2, C + 0.25) && Math.random() < 0.5) {
    for (let k = -2; k <= 2; k++) addCoin(cur.lane, C + k * 0.04, 1);
    lastCoinPos = Math.max(lastCoinPos, C + 0.1);
  }
  if (Math.random() > 0.55) return;
  const start = Math.max(C + 0.12, lastCoinPos + 0.12), sp = 0.08, n = 4 + Math.floor(Math.random() * 4), end = start + (n - 1) * sp;
  if (end > C + 0.9) return;
  const blocked = [false, false, false];
  for (const ob of [cur].concat(queue)) if (ob.pos > start - 0.07 && ob.pos < end + 0.07) blocked[ob.lane] = true;
  if (cur.type === 'block' && start < C + 0.2) blocked[cur.lane] = true;
  const free = [0, 1, 2].filter(l => !blocked[l]); if (!free.length) return;
  const A = free[Math.floor(Math.random() * free.length)];
  let B = A; if (free.length > 1 && Math.random() < 0.3) { const others = free.filter(l => l !== A); B = others[Math.floor(Math.random() * others.length)]; }
  for (let i = 0; i < n; i++) addCoin(i < n / 2 ? A : B, start + i * sp, 0);
  lastCoinPos = end;
}
function director() {
  while (queue.length && queue[0].pos <= courseZ) {
    const q = queue.shift();
    obstacles.push({ lane: q.lane, z: courseZ - q.pos, type: q.type, checked: false, smashed: false, phase: Math.random() * 6 });
    fillQueue(); placeCoins(q);
  }
}

/* ======================================================================== coins */
function itemPos(c, out) {
  const p = c.z, base = H * 0.48 + p * H * 0.55, s = 0.2 + p * 1.2;
  out.s = s; out.gy = base; out.x = laneProj(c.lane, p); out.y = base - 20 * s - (c.h ? H * 0.085 * (s / 0.884) : 0);
  if (c.pull > 0) { const e = ease(c.pull); out.x = lerp(out.x, playerX, e); out.y = lerp(out.y, curPy - 26, e); }
  return out;
}
const tmpPos = { x: 0, y: 0, gy: 0, s: 1 };
function collectCoin(c) {
  c.got = true; runCoins++; Save.addCoins(1);            // the only place coins are earned: once per coin object
  const t = performance.now(); combo = (t - lastCoinT < 900) ? combo + 1 : 0; lastCoinT = t;
  Audio.play('coin', { step: combo });
  itemPos(c, tmpPos); const s = Math.max(0.6, tmpPos.s);
  fx.spark(tmpPos.x, tmpPos.y, 6, '#ffe27a'); fx.spark(tmpPos.x, tmpPos.y, 2, '#ffffff'); fx.text(tmpPos.x, tmpPos.y - 20 * s, '+1', '#fff2b0');
  UI.setRunCoins(runCoins, true);
}
function drawCoin(c, now) {
  itemPos(c, tmpPos); const x = tmpPos.x, y = tmpPos.y, s = tmpPos.s, fade = clamp(c.z / 0.1, 0, 1);
  if (c.pull === 0) { ctx.save(); ctx.globalAlpha = 0.25 * fade; ctx.fillStyle = '#00304b'; ctx.beginPath(); ctx.ellipse(x, tmpPos.gy + 2 * s, 11 * s, 3.2 * s, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  const size = 28 * s / 0.72, f = (Math.floor(now * 0.011 + c.phase) % COIN_FRAMES + COIN_FRAMES) % COIN_FRAMES;
  ctx.globalAlpha = fade; ctx.drawImage(coinSprites[f], x - size / 2, y - size / 2, size, size); ctx.globalAlpha = 1;
}

/* ======================================================================== state */
function pickEquipped() { equippedDef = Chars.get(Save.equipped); return equippedDef; }
function reset() {
  runId++; distance = 0; speed = 300; courseZ = 0; obstacles = []; coins = []; parts = []; lastCoinPos = 0; lane = 1; playerX = laneX(lane);
  jump = 0; duck = 0; invuln = 0; gameOver = false; dying = false; paused = false; sessionBest = false; runTime = 0; runCoins = 0; combo = 0; lastCoinT = 0;
  shakeT = 0; flashT = 0; countdownT = 0; curLiftN = 0; lastDistShown = -1;
  const def = pickEquipped();                                  // equipping changes the model AND the ability here
  Abil.reset(def.ability); UI.setAbility(Abil.get(def.ability));
  queue = [{ pos: 0.62 * 300 / 850, lane: Math.floor(Math.random() * 3), type: ['jump', 'duck', 'block'][Math.floor(Math.random() * 3)] }]; fillQueue();
  UI.setRunCoins(0, false); UI.fadeHints(false); UI.countdownClear(); distEl.textContent = '0';
}

function begin() { running = true; menuIdle = false; UI.hideOverlay(); UI.stopPreviews(); Audio.setMode('run'); last = performance.now(); kick(); }
function startRun() { reset(); menuMode = 'run'; begin(); }
function resume() { if (!paused) return; paused = false; countdownT = 2.4; lastCdNum = 0; begin(); }
function primary() { Audio.play('click'); if (paused) resume(); else startRun(); }
function pause() {
  if (!running || dying) return;
  running = false; paused = true; countdownT = 0; UI.countdownClear(); Save.flush(); Audio.setMode('pause'); menuMode = 'paused'; UI.showOverlay('paused');
}
function showMenu(mode) {
  menuMode = mode; running = false; paused = false; UI.setAbility(null); lane = 1; playerX = laneX(1); startIdle(); UI.showOverlay('start');
}
function startIdle() { menuIdle = true; idleLast = 0; Audio.setMode('menu'); kick(); }
function quitToMenu() {                                         // from the pause screen: bank the distance, keep coins
  if (!paused) return;
  const fd = Math.floor(distance); Save.setBest(fd); bestEl.textContent = Save.best; Save.recordRun(); Save.flush();
  runId++; obstacles = []; coins = []; parts = []; Audio.play('click'); showMenu('start');
}
function die() {
  running = false; gameOver = true; dying = true; UI.setAbility(null);
  const fd = Math.floor(distance); sessionBest = Save.setBest(fd); bestEl.textContent = Save.best; Save.recordRun(); Save.flush();
  Audio.play('hit'); Audio.setMode('menu'); UI.countdownClear();
  shakeAmp = 12; shakeT = 0.45; flashColor = 'rgba(255,90,70,.5)'; flashT = flashMax = 0.4;
  fx.burst(playerX, curPy - 8, 26, ['#ffffff', '#bff6ff', '#ff8a68', '#ffd66b']); fx.ring(playerX, curPy + 20, 10, 110, '#ffffff', 0.5);
  const id = runId, coinsThisRun = runCoins;
  setTimeout(() => {
    if (id !== runId) return;
    dying = false; menuMode = 'over'; startIdle();
    UI.showOverlay('over', { distance: fd, best: Save.best, record: sessionBest, coins: coinsThisRun });
    Audio.play(sessionBest ? 'record' : 'gameover');
  }, 560);
}

/* ======================================================================== update */
function useAbility() {
  if (!running || countdownT > 0 || dying) return;
  api.px = playerX; api.py = curPy; api.isDucking = duck > 0;
  Abil.activate(api);
}
function doJump() { jump = 0.78; duck = 0; Audio.play('jump'); }
function doDuck() { duck = 0.62; jump = 0; Abil.onDuck(api); Audio.play('duck'); }
function doLane(d) { const n = clamp(lane + d, 0, 2); if (n !== lane) { lane = n; Audio.play('lane'); } }

function update(dt) {
  runTime += dt; api.px = playerX; api.py = curPy; api.isDucking = duck > 0;
  Abil.update(api, dt);
  const m = Abil.mods, eff = Math.min(speed * m.speedMul, 700), dz = dt * eff / 850;
  courseZ += dz; distance += eff * dt * 0.035 * m.scoreMul; speed = Math.min(600, speed + dt * 2.5);
  if (runTime > 9) UI.fadeHints(true);
  director();
  jump = Math.max(0, jump - dt * 1.7); duck = Math.max(0, duck - dt); invuln = Math.max(0, invuln - dt); playerX += (laneX(lane) - playerX) * Math.min(1, dt * 12);
  const jumpN = jump > 0 ? Math.sin((1 - jump) * Math.PI) : 0; curLiftN = Math.max(jumpN, m.lift);
  const groundY = H * 0.79 + (duck > 0 ? H * 0.025 : 0); curPy = groundY - curLiftN * H * 0.16;
  api.px = playerX; api.py = curPy;

  for (let i = 0; i < obstacles.length; i++) {
    const o = obstacles[i], oldZ = o.z; o.z += dz;
    if (!o.checked && oldZ <= HIT_Z && o.z >= HIT_Z) {
      o.checked = true;
      const dx = Math.abs(laneX(o.lane) - playerX), playerHalf = Math.max(13, Math.min(23, W * 0.032)), hazardHalf = (o.type === 'duck' ? 26 : 15) * (0.2 + HIT_Z * 1.2);
      if (dx < playerHalf + hazardHalf && invuln <= 0) {
        const safe = (o.type === 'jump' && (jump > 0.16 || m.clears.jump)) || (o.type === 'block' && m.clears.block) || (o.type === 'duck' && duck > 0.12);
        if (!safe) {
          if (Abil.onHit(api, o)) { o.smashed = true; fx.burst(obstacleX(o, HIT_Z), H * 0.48 + HIT_Z * H * 0.55 - 12, 14, ['#ef654f', '#ffd36c', '#fff0b7']); }
          else { die(); return; }
        } else distance += 8;
      }
    }
  }
  obstacles = obstacles.filter(o => o.z < 1.2 && !o.smashed);

  const pullZ = m.magnetZ, win = 0.04, laneTol = W * 0.075; api.pulled.length = 0;
  for (const c of coins) {
    c.z += dz; if (c.got || c.z < 0) continue;
    if (c.pull > 0 || (pullZ > 0 && c.z > HIT_Z - pullZ && c.z < HIT_Z + 0.03)) c.pull = Math.min(1, c.pull + dt * 3.4);
    if (c.pull >= 1) { collectCoin(c); continue; }
    if (c.pull === 0) {
      const heightOk = c.h === 0 ? curLiftN < 0.55 : curLiftN > 0.4;
      if (Math.abs(c.z - HIT_Z) <= win && heightOk && Math.abs(laneX(c.lane) - playerX) < laneTol) collectCoin(c);
    } else { itemPos(c, tmpPos); api.pulled.push({ x: tmpPos.x, y: tmpPos.y, pull: c.pull }); }
  }
  coins = coins.filter(c => !c.got && c.z < 1.15);
  updateFx(dt);
  const dn = Math.floor(distance); if (dn !== lastDistShown) { lastDistShown = dn; distEl.textContent = dn; }
  UI.updateAbility(Abil.status());
}

/* ======================================================================== render */
const drawList = [];
function drawItem(it, now) { if (it.type !== undefined) drawObstacle(it); else drawCoin(it, now); }
function drawPlayer(now, idle) {
  const m = Abil.mods, def = equippedDef, sc = Math.min(W / 430, 1.5);
  const groundY = idle ? H * 0.79 : H * 0.79 + (duck > 0 ? H * 0.025 : 0), py = idle ? groundY + Math.sin(now * 0.003) * 2 : curPy;
  const lean = clamp((laneX(lane) - playerX) * 0.022, -0.32, 0.32);
  Chars.shadow(ctx, playerX, groundY + 28 * sc, sc, curLiftN);
  if (!idle) Abil.drawFx(ctx, { x: playerX, y: py, s: sc, now });
  Chars.draw(ctx, def, { x: playerX, y: py, scale: sc, now, lean, ducking: duck > 0, jumping: curLiftN > 0.08 && !idle, flip: idle ? 0 : m.spin, fx: !idle && Abil.inst && Abil.inst.phase === 'active', alpha: invuln > 0 ? 0.55 + Math.sin(now * 0.04) * 0.3 : 1 });
  // fast, tiny wake flecks trailing the board (kept on the water surface)
  for (let i = 0; i < 5; i++) { const xx = playerX + Math.sin(now * 0.007 + i * 2) * 26 * sc / 1.2, yy = groundY + 21 * sc + ((i * 7 + now * 0.03) % 12); ctx.fillStyle = `rgba(218,255,250,${0.18 + (i % 3) * 0.12})`; ctx.beginPath(); ctx.ellipse(xx, yy, 1.2 + (i % 2), 0.8 + (i % 2) * 0.5, -0.2, 0, TAU); ctx.fill(); }
}
function render(now) {
  ctx.save();
  if (shakeT > 0) ctx.translate((Math.random() - 0.5) * shakeAmp * (shakeT / 0.4 > 1 ? 1 : shakeT / 0.4), (Math.random() - 0.5) * shakeAmp * (shakeT / 0.4 > 1 ? 1 : shakeT / 0.4));
  drawBackground(now);
  api.now = now; Abil.drawWorldFx(ctx, api);
  drawList.length = 0;
  for (const o of obstacles) if (!o.smashed) drawList.push(o);
  for (const c of coins) if (!c.got && c.z >= 0) drawList.push(c);
  drawList.sort((a, b) => a.z - b.z);
  let i = 0; for (; i < drawList.length && drawList[i].z <= HIT_Z; i++) drawItem(drawList[i], now);   // farther than the surfer
  drawPlayer(now, false);
  for (; i < drawList.length; i++) drawItem(drawList[i], now);                                         // already passing the surfer
  drawParts();
  ctx.restore();
  if (flashT > 0) { ctx.save(); ctx.globalAlpha = clamp(flashT / flashMax, 0, 1); ctx.fillStyle = flashColor; ctx.fillRect(0, 0, W, H); ctx.restore(); }
}
function renderIdle(now) { drawBackground(now); drawPlayer(now, true); }

/* ======================================================================== loop */
function kick() { if (!raf) raf = requestAnimationFrame(frame); }
function frame(now) {
  raf = 0;
  if (running) {
    const dt = Math.min((now - last) / 1000, 0.035); last = now;
    if (countdownT > 0) {
      countdownT -= dt; const n = Math.ceil(countdownT / 0.8); if (n > 0 && n !== lastCdNum) { lastCdNum = n; UI.countdownTick(n); } if (countdownT <= 0) UI.countdownClear();
      updateFx(dt);
    } else if (!manual) update(dt);
    render(now); kick();
  } else if (dying) {
    const dt = Math.min((now - last) / 1000, 0.035); last = now; updateFx(dt); render(now); kick();
  } else if (menuIdle) {
    if (now - idleLast > 30) { idleLast = now; renderIdle(now); } kick();
  }
}

/* ======================================================================== input */
const pointers = new Map();
canvas.addEventListener('pointerdown', e => { pointers.set(e.pointerId, { x: e.clientX, y: e.clientY }); try { canvas.setPointerCapture(e.pointerId); } catch (_) {} }, { passive: true });
canvas.addEventListener('pointerup', e => {
  const s = pointers.get(e.pointerId); pointers.delete(e.pointerId);
  if (!s || !running || countdownT > 0) return;
  const dx = e.clientX - s.x, dy = e.clientY - s.y;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 30) { doLane(e.clientX < W / 2 ? -1 : 1); }
  else if (Math.abs(dx) > Math.abs(dy)) doLane(dx > 0 ? 1 : -1);
  else if (dy < 0) doJump(); else doDuck();
}, { passive: true });
canvas.addEventListener('pointercancel', e => { pointers.delete(e.pointerId); });
// Ability button reacts on press (lowest latency) and is a separate element, so it never starts a swipe.
abilityBtn.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); useAbility(); });
abilityBtn.addEventListener('click', e => { if (e.detail === 0) useAbility(); });
window.addEventListener('keydown', e => {
  if (e.key === 'Escape') { if (UI.shopIsOpen()) UI.closeShop(); else if (running && !dying) pause(); return; }
  if (!running || countdownT > 0) return;
  const k = e.key;
  if (k === 'ArrowLeft' || k === 'a' || k === 'A') doLane(-1);
  if (k === 'ArrowRight' || k === 'd' || k === 'D') doLane(1);
  if (k === 'ArrowUp' || k === ' ') doJump();
  if (k === 'ArrowDown' || k === 's' || k === 'S') doDuck();
  if (k === 'e' || k === 'E' || k === 'Shift' || k === 'f' || k === 'F') useAbility();
});
actionButton.addEventListener('click', primary);
pauseButton.addEventListener('click', () => { if (running) pause(); else if (paused) resume(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && running && !dying) pause(); });
window.addEventListener('resize', resize);

/* Hooks for the Android wrapper (MainActivity.java). */
window.SurfDash = {
  onBack() {                                  // true = handled here, false = let Android close the app
    if (UI.shopIsOpen()) { UI.closeShop(); return true; }
    if (running && !dying) { pause(); return true; }
    if (paused) { resume(); return true; }
    if (menuMode === 'over') { showMenu('start'); return true; }
    return false;
  },
  autoPause() { if (running && !dying) pause(); }
};

/* ======================================================================== boot */
function boot() {
  Audio.init(); Save.validate(Chars.ids()); UI.wire(); buildCoinSprites(); resize();
  bestEl.textContent = Save.best; UI.refreshMenuCard(); UI.refreshBalance(); UI.refreshToggles(); pickEquipped();
  UI.setAbility(null); showMenu('start');
}
SD.Game = { startRun, resume, pause, quitToMenu, primary, get running() { return running; }, get paused() { return paused; } };

if (/[?&]test=1/.test(location.search)) {
  // Automated-test hooks (only active with ?test=1; never used in normal play)
  window.SD_TEST = {
    get s() { return { running, paused, dying, gameOver, distance, speed, lane, playerX, jump, duck, invuln, runCoins, curLiftN, W, H, courseZ, countdownT, obstacles: obstacles.length, coins: coins.length, menuMode }; },
    obstacles: () => obstacles, coins: () => coins, laneX, HIT_Z, api, mods: () => Abil.mods, inst: () => Abil.inst,
    clearCourse() { obstacles = []; coins = []; queue = []; queue.push({ pos: courseZ + 999, lane: 0, type: 'block' }); },
    addObstacle(l, type, z) { obstacles.push({ lane: l, z: z == null ? 0.1 : z, type, checked: false, smashed: false, phase: 0 }); },
    addCoinAt(l, z, h) { coins.push({ lane: l, z, h: h || 0, phase: 0, got: false, pull: 0 }); },
    setLane(l) { lane = l; playerX = laneX(l); }, doJump, doDuck, doLane, useAbility, pause, resume, startRun, showMenu,
    freezeSpawns() { queue = [{ pos: courseZ + 9999, lane: 1, type: 'block' }]; },
    setSpeed(v) { speed = v; }, setDistance(v) { distance = v; },
    set manual(v) { manual = !!v; }, god() { invuln = 1e9; },
    def: () => equippedDef,
    step(n, dt, skipRender) { dt = dt || 1 / 60; for (let i = 0; i < n && running && countdownT <= 0; i++) update(dt); if (!skipRender) render(performance.now()); }
  };
}
boot();
})();
