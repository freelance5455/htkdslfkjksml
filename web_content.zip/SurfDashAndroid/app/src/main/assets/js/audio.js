/* Surf Dash — audio
 *
 * Everything here is generated with the Web Audio API, so the game ships with no audio files.
 * To use real recordings instead, drop files into assets/audio/ and list them in CONFIG below.
 * Music and sound effects are independent switches (SD.Audio.setMusic / SD.Audio.setSfx),
 * persisted through SD.Save.
 *
 * SFX names used by the game:
 *   click, lane, jump, duck, coin, hit, deny, buy, equip,
 *   ability_ready, ability_surge, ability_tidepull, ability_skyflip, ability_coralward,
 *   ability_end, shield_pop, record, gameover
 */
(function () {
  'use strict';
  const SD = (window.SD = window.SD || {});

  const CONFIG = {
    // Example: musicFile: 'audio/tropical-loop.ogg'
    musicFile: null,
    // Example: sfxFiles: { coin: 'audio/coin.ogg', jump: 'audio/jump.ogg' }
    sfxFiles: {},
    musicVolume: 0.5,   // 0..1
    sfxVolume: 0.8      // 0..1
  };

  let ctx = null, master = null, sfxBus = null, musicBus = null, noiseBuf = null;
  let musicOn = true, sfxOn = true, musicMode = 'menu';
  let schedTimer = 0, nextNoteTime = 0, stepIndex = 0;
  let musicEl = null;
  const fileCache = {};
  const MODE_LEVEL = { menu: 0.55, run: 0.4, pause: 0.18 };

  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 1; master.connect(ctx.destination);
      sfxBus = ctx.createGain(); sfxBus.gain.value = 0.55 * CONFIG.sfxVolume; sfxBus.connect(master);
      musicBus = ctx.createGain(); musicBus.gain.value = 0; musicBus.connect(master);
      const len = ctx.sampleRate * 0.5;
      noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const ch = noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
    } catch (e) { ctx = null; }
    return ctx;
  }

  /* ---------- synth primitives ---------- */
  function tone(o) {
    if (!ctx) return;
    const t0 = ctx.currentTime + (o.delay || 0);
    const osc = ctx.createOscillator(), g = ctx.createGain();
    osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(o.f, t0);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.f2), t0 + o.dur);
    const peak = o.vol == null ? 0.5 : o.vol, atk = o.attack || 0.006;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(peak, t0 + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    osc.connect(g); g.connect(o.bus || sfxBus);
    osc.start(t0); osc.stop(t0 + o.dur + 0.05);
  }
  function noise(o) {
    if (!ctx) return;
    const t0 = ctx.currentTime + (o.delay || 0);
    const src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
    const filt = ctx.createBiquadFilter(); filt.type = o.filter || 'bandpass';
    filt.frequency.setValueAtTime(o.f || 1200, t0);
    if (o.f2) filt.frequency.exponentialRampToValueAtTime(o.f2, t0 + o.dur);
    filt.Q.value = o.q || 0.9;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(o.vol == null ? 0.4 : o.vol, t0 + (o.attack || 0.008));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    src.connect(filt); filt.connect(g); g.connect(o.bus || sfxBus);
    src.start(t0); src.stop(t0 + o.dur + 0.05);
  }

  const semis = (base, n) => base * Math.pow(2, n / 12);
  const MAJOR_PENT = [0, 2, 4, 7, 9, 12, 14, 16];

  /* ---------- placeholder sound recipes ---------- */
  const RECIPES = {
    click() { tone({ f: 620, f2: 880, dur: 0.07, type: 'triangle', vol: 0.25 }); },
    lane() { noise({ f: 1800, f2: 700, dur: 0.07, vol: 0.14, q: 0.6 }); },
    jump() { tone({ f: 300, f2: 760, dur: 0.16, type: 'sine', vol: 0.32 }); noise({ f: 900, f2: 2200, dur: 0.12, vol: 0.08 }); },
    duck() { tone({ f: 520, f2: 220, dur: 0.14, type: 'sine', vol: 0.28 }); },
    coin(o) {
      const step = Math.min(7, (o && o.step) || 0), f = semis(988, MAJOR_PENT[step] || 0);
      tone({ f: f, dur: 0.09, type: 'triangle', vol: 0.34 });
      tone({ f: f * 1.5, dur: 0.16, type: 'sine', vol: 0.26, delay: 0.055 });
    },
    hit() { tone({ f: 170, f2: 45, dur: 0.38, type: 'square', vol: 0.34 }); noise({ f: 700, f2: 120, dur: 0.4, vol: 0.5, filter: 'lowpass' }); },
    deny() { tone({ f: 190, dur: 0.1, type: 'square', vol: 0.2 }); tone({ f: 150, dur: 0.16, type: 'square', vol: 0.2, delay: 0.1 }); },
    buy() { [0, 4, 7, 12].forEach((n, i) => tone({ f: semis(523, n), dur: 0.22, type: 'triangle', vol: 0.3, delay: i * 0.07 })); },
    equip() { tone({ f: 660, dur: 0.08, type: 'triangle', vol: 0.3 }); tone({ f: 990, dur: 0.16, type: 'triangle', vol: 0.3, delay: 0.07 }); },
    ability_ready() { tone({ f: 880, dur: 0.1, type: 'sine', vol: 0.2 }); tone({ f: 1320, dur: 0.18, type: 'sine', vol: 0.18, delay: 0.08 }); },
    ability_surge() { tone({ f: 220, f2: 1100, dur: 0.45, type: 'sawtooth', vol: 0.18 }); noise({ f: 600, f2: 4200, dur: 0.45, vol: 0.2 }); },
    ability_tidepull() { [0, 7, 12, 19].forEach((n, i) => tone({ f: semis(440, n), dur: 0.35, type: 'sine', vol: 0.22, delay: i * 0.06 })); },
    ability_skyflip() { noise({ f: 500, f2: 3000, dur: 0.3, vol: 0.2 }); tone({ f: 330, f2: 990, dur: 0.3, type: 'triangle', vol: 0.25 }); },
    ability_coralward() { [0, 4, 7].forEach((n, i) => tone({ f: semis(392, n), dur: 0.5, type: 'sine', vol: 0.2, delay: i * 0.05 })); noise({ f: 2500, dur: 0.25, vol: 0.06 }); },
    ability_end() { tone({ f: 520, f2: 300, dur: 0.18, type: 'sine', vol: 0.18 }); },
    shield_pop() { noise({ f: 3200, f2: 800, dur: 0.3, vol: 0.4 }); tone({ f: 900, f2: 240, dur: 0.25, type: 'triangle', vol: 0.3 }); },
    record() { [0, 4, 7, 12, 16].forEach((n, i) => tone({ f: semis(523, n), dur: 0.2, type: 'triangle', vol: 0.28, delay: i * 0.08 })); },
    gameover() { tone({ f: 330, f2: 165, dur: 0.6, type: 'triangle', vol: 0.25 }); }
  };

  /* ---------- optional real audio files (HTMLAudioElement works from file:///android_asset) ---------- */
  function playFile(name) {
    const url = CONFIG.sfxFiles[name];
    if (!url) return false;
    try {
      let base = fileCache[name];
      if (!base) { base = fileCache[name] = new Audio(url); base.preload = 'auto'; base.addEventListener('error', () => { delete CONFIG.sfxFiles[name]; }); }
      const a = base.cloneNode(); a.volume = CONFIG.sfxVolume; a.play().catch(() => {});
      return true;
    } catch (e) { return false; }
  }

  /* ---------- procedural music: a relaxed marimba arpeggio over four chords ---------- */
  const BPM = 104, EIGHTH = 60 / BPM / 2;
  const CHORDS = [[0, 4, 7, 11], [-3, 0, 4, 7], [-7, -3, 0, 4], [-5, -1, 2, 5]]; // Cmaj7, Am7, Fmaj7, G7 (semitones from C4)
  const ARP = [0, 1, 2, 3, 2, 1, 2, 1];
  const C4 = 261.63;

  function scheduleStep(t, idx) {
    const bar = Math.floor(idx / 8) % 4, step = idx % 8, chord = CHORDS[bar];
    const f = semis(C4, chord[ARP[step]] + (step === 3 || step === 7 ? 12 : 0));
    const mk = (freq, vol, dur) => {
      const osc = ctx.createOscillator(), g = ctx.createGain();
      osc.type = 'triangle'; osc.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      osc.connect(g); g.connect(musicBus); osc.start(t); osc.stop(t + dur + 0.05);
    };
    if (step !== 6) mk(f, 0.2, 0.32);
    if (step === 0 || step === 4) {
      const b = ctx.createOscillator(), g = ctx.createGain();
      b.type = 'sine'; b.frequency.value = semis(C4 / 2, chord[0]);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.32, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + EIGHTH * 3.4);
      b.connect(g); g.connect(musicBus); b.start(t); b.stop(t + EIGHTH * 3.6);
    }
    if (step % 2 === 1) { // soft shaker
      const src = ctx.createBufferSource(); src.buffer = noiseBuf;
      const filt = ctx.createBiquadFilter(); filt.type = 'highpass'; filt.frequency.value = 6000;
      const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.05, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
      src.connect(filt); filt.connect(g); g.connect(musicBus); src.start(t); src.stop(t + 0.1);
    }
  }
  function pump() {
    if (!ctx || ctx.state !== 'running' || !musicOn || CONFIG.musicFile) return;
    while (nextNoteTime < ctx.currentTime + 0.3) {
      if (nextNoteTime < ctx.currentTime - 0.2) nextNoteTime = ctx.currentTime + 0.05; // recover after a stall
      scheduleStep(nextNoteTime, stepIndex++);
      nextNoteTime += EIGHTH;
    }
  }
  function applyMusicLevel() {
    const level = musicOn ? MODE_LEVEL[musicMode] * CONFIG.musicVolume * 0.5 : 0;
    if (ctx && musicBus) musicBus.gain.setTargetAtTime(level, ctx.currentTime, 0.12);
    if (musicEl) { musicEl.volume = Math.min(1, musicOn ? MODE_LEVEL[musicMode] * CONFIG.musicVolume * 1.4 : 0); if (!musicOn) musicEl.pause(); else if (musicEl.paused) musicEl.play().catch(() => {}); }
  }
  function startMusic() {
    if (CONFIG.musicFile) {
      if (!musicEl) { musicEl = new Audio(CONFIG.musicFile); musicEl.loop = true; musicEl.addEventListener('error', () => { CONFIG.musicFile = null; musicEl = null; startMusic(); }); }
      applyMusicLevel(); return;
    }
    if (!ensure()) return;
    if (!schedTimer) { nextNoteTime = ctx.currentTime + 0.1; schedTimer = setInterval(pump, 90); }
    applyMusicLevel();
  }

  const Audio_ = {
    CONFIG,
    /** Call from the first user gesture (browsers/WebViews may block audio before that). */
    unlock() {
      if (!ensure()) return;
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      if (musicOn) startMusic();
    },
    play(name, opts) {
      if (!sfxOn) return;
      if (playFile(name)) return;
      if (!ensure() || ctx.state !== 'running') return;
      const r = RECIPES[name]; if (r) { try { r(opts); } catch (e) { /* never let audio break gameplay */ } }
    },
    setMusic(on) { musicOn = !!on; SD.Save && SD.Save.setSetting('music', musicOn); if (musicOn) { this.unlock(); } applyMusicLevel(); },
    setSfx(on) { sfxOn = !!on; SD.Save && SD.Save.setSetting('sfx', sfxOn); },
    get musicOn() { return musicOn; },
    get sfxOn() { return sfxOn; },
    /** 'menu' | 'run' | 'pause' — changes the music loudness. */
    setMode(mode) { musicMode = mode; applyMusicLevel(); },
    suspend() { if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {}); if (musicEl) musicEl.pause(); },
    resume() { if (ctx && ctx.state === 'suspended' && unlockedOnce) ctx.resume().catch(() => {}); if (musicEl && musicOn) musicEl.play().catch(() => {}); },
    init() {
      const s = SD.Save ? SD.Save.settings : { music: true, sfx: true };
      musicOn = s.music; sfxOn = s.sfx;
    }
  };
  let unlockedOnce = false;
  const firstGesture = () => { unlockedOnce = true; Audio_.unlock(); };
  window.addEventListener('pointerdown', firstGesture, { once: true, capture: true });
  window.addEventListener('keydown', firstGesture, { once: true, capture: true });
  document.addEventListener('visibilitychange', () => { document.hidden ? Audio_.suspend() : Audio_.resume(); });

  SD.Audio = Audio_;
})();
