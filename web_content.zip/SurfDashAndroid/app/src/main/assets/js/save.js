/* Surf Dash — save data
 * One versioned JSON blob in localStorage. All game code goes through SD.Save so that
 * coins can only change via addCoins() / purchase(), which keeps rewards and purchases
 * duplicate-proof. Falls back to memory-only if storage is unavailable (nothing crashes).
 */
(function () {
  'use strict';
  const SD = (window.SD = window.SD || {});
  const KEY = 'surfdash-save-v2';
  const LEGACY_BEST_KEY = 'surfdash-best'; // v1 stored only the best distance here
  const STARTER = 'kai';                   // free character, always owned

  const defaults = () => ({
    v: 2,
    coins: 0,            // spendable balance
    lifetimeCoins: 0,    // total ever collected (never decreases)
    best: 0,             // best distance in metres
    runs: 0,
    owned: [STARTER],
    equipped: STARTER,
    settings: { music: true, sfx: true }
  });

  let data = defaults();
  let persistent = true;
  let timer = 0;
  const listeners = [];

  const toInt = (n, d = 0) => (Number.isFinite(Number(n)) && Number(n) >= 0 ? Math.floor(Number(n)) : d);

  function sanitize(o) {
    const d = defaults();
    if (!o || typeof o !== 'object') return d;
    d.coins = toInt(o.coins);
    d.lifetimeCoins = Math.max(toInt(o.lifetimeCoins), d.coins);
    d.best = toInt(o.best);
    d.runs = toInt(o.runs);
    const owned = Array.isArray(o.owned) ? o.owned.filter(x => typeof x === 'string') : [];
    d.owned = Array.from(new Set([STARTER].concat(owned)));
    d.equipped = typeof o.equipped === 'string' && d.owned.indexOf(o.equipped) >= 0 ? o.equipped : STARTER;
    if (o.settings && typeof o.settings === 'object') {
      d.settings.music = o.settings.music !== false;
      d.settings.sfx = o.settings.sfx !== false;
    }
    return d;
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        data = sanitize(JSON.parse(raw));
      } else {
        // First launch of v2: carry over the old best score so nobody loses progress.
        data = defaults();
        data.best = toInt(localStorage.getItem(LEGACY_BEST_KEY));
      }
    } catch (e) {
      persistent = false;
      data = defaults();
    }
  }

  function writeNow() {
    clearTimeout(timer); timer = 0;
    try { localStorage.setItem(KEY, JSON.stringify(data)); persistent = true; }
    catch (e) { persistent = false; }
  }
  // Coin pickups are batched (cheap); purchases/run ends flush immediately.
  function scheduleWrite() { if (!timer) timer = setTimeout(writeNow, 250); }
  function notify() { for (const fn of listeners) { try { fn(data); } catch (e) { /* UI errors must not break saving */ } } }

  const Save = {
    STARTER,
    load,
    get data() { return data; },
    get coins() { return data.coins; },
    get best() { return data.best; },
    get equipped() { return data.equipped; },
    get persistent() { return persistent; },
    get settings() { return data.settings; },
    onChange(fn) { listeners.push(fn); },
    owns(id) { return data.owned.indexOf(id) >= 0; },
    flush: writeNow,

    /** Drop unknown character ids (e.g. a character removed in a later version). */
    validate(knownIds) {
      data.owned = data.owned.filter(id => knownIds.indexOf(id) >= 0);
      if (data.owned.indexOf(STARTER) < 0) data.owned.unshift(STARTER);
      if (data.owned.indexOf(data.equipped) < 0) data.equipped = STARTER;
      writeNow();
    },

    /** Called once per collected coin object. Returns the new balance. */
    addCoins(n) {
      n = toInt(n);
      if (!n) return data.coins;
      data.coins += n; data.lifetimeCoins += n;
      scheduleWrite(); notify();
      return data.coins;
    },

    /** Atomic purchase: checks ownership + funds, deducts once, saves immediately. */
    purchase(id, price) {
      price = toInt(price, -1);
      if (price < 0) return { ok: false, reason: 'invalid' };
      if (Save.owns(id)) return { ok: false, reason: 'owned' };
      if (data.coins < price) return { ok: false, reason: 'poor', missing: price - data.coins };
      data.coins -= price;
      data.owned.push(id);
      writeNow(); notify();
      return { ok: true, coins: data.coins };
    },

    equip(id) {
      if (!Save.owns(id)) return false;
      data.equipped = id;
      writeNow(); notify();
      return true;
    },

    /** Returns true if this distance is a new personal best. */
    setBest(m) {
      m = toInt(m);
      if (m > data.best) { data.best = m; writeNow(); notify(); return true; }
      return false;
    },
    recordRun() { data.runs += 1; scheduleWrite(); },

    setSetting(key, value) { data.settings[key] = !!value; writeNow(); notify(); },

    /** Test/debug helper: wipe everything. */
    reset() { data = defaults(); writeNow(); notify(); }
  };

  SD.Save = Save;
  load();
  window.addEventListener('pagehide', writeNow);
  document.addEventListener('visibilitychange', () => { if (document.hidden) writeNow(); });
})();
