Surf Dash audio
===============
The game ships with NO audio files: every effect and the music loop are synthesised with the
Web Audio API (see assets/js/audio.js). To use real recordings, copy .ogg/.mp3 files into this
folder and list them in the CONFIG block at the top of assets/js/audio.js, e.g.

  musicFile: 'audio/tropical-loop.ogg',
  sfxFiles:  { coin: 'audio/coin.ogg', jump: 'audio/jump.ogg', hit: 'audio/crash.ogg' },

Any effect you do not list keeps its synthesised placeholder. Effect names:
  click lane jump duck coin hit deny buy equip record gameover shield_pop
  ability_ready ability_end ability_surge ability_tidepull ability_skyflip ability_coralward
Music and effects have separate on/off switches (menu screen) saved in the player's save data.
