GONDAL CONTACT DIRECTORY — ANDROID PROJECT SOURCE

This is a native Android Studio project (Java + WebView UI) preconfigured with your Google Sheet ID:
1hAtSuOm_-ChPW_HhEQX4Dy9aBiN5wuM25UMIB5dTucw

FEATURES
- Fetches CSV data directly from Google Sheets on Refresh (no separate website hosting).
- Refreshes automatically when the app opens.
- Search across all columns.
- Direct dialler, SMS and email shortcuts when those columns are present.
- Read-only: it never writes to the spreadsheet.

IMPORTANT SHEET SETUP
For the no-login version, the Google Sheet must be readable by anyone with the link:
Google Sheets > Share > General access > Anyone with the link > Viewer.
Do not use this setting for sensitive or private contact information. Private sheets need Google sign-in / authenticated Sheets API setup, which is not included in this simple build.

HOW TO MAKE APK ONLINE
1. Upload this ZIP to an online Android project builder that supports Android Studio / Gradle source projects, or open it in Android Studio.
2. Build using Gradle and Android Gradle Plugin 8.7.3, with JDK 17 and Android SDK 35.
3. Build > Build APK(s). The debug APK is typically at app/build/outputs/apk/debug/app-debug.apk.

PROJECT REQUIREMENTS
- Android Gradle Plugin: 8.7.3
- compileSdk: 35
- minSdk: 23
- JDK: 17

NOTES
- Some online APK converters only wrap websites and do not compile Android Studio projects. Choose one that accepts a Gradle Android project.
- Google may change its export endpoint or access policy; if refresh fails, verify sheet sharing and network access.
- The app only reads the first/default worksheet. If your contacts are on another tab, update the URL in MainActivity.java to include the correct gid or worksheet configuration.
