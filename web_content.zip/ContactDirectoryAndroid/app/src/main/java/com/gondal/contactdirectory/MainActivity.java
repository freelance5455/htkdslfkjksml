package com.gondal.contactdirectory;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private final String sheetId = "1hAtSuOm_-ChPW_HhEQX4Dy9aBiN5wuM25UMIB5dTucw";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 248, 252));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SheetBridge(), "AndroidSheet");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("sms:")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class SheetBridge {
        @JavascriptInterface public void refresh() {
            new Thread(() -> {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL("https://docs.google.com/spreadsheets/d/" + sheetId + "/gviz/tq?tqx=out:csv");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(20000);
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 ContactDirectoryAndroid");
                    int code = connection.getResponseCode();
                    InputStream stream = (code >= 200 && code < 300) ? connection.getInputStream() : connection.getErrorStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                    StringBuilder body = new StringBuilder(); String line;
                    while ((line = reader.readLine()) != null) body.append(line).append('\n');
                    reader.close();
                    String result = body.toString();
                    if (code < 200 || code >= 300 || result.trim().startsWith("<!DOCTYPE") || result.trim().startsWith("<html")) {
                        throw new Exception("Google Sheet is not publicly readable. Set General access to Anyone with the link — Viewer, or configure an authenticated API.");
                    }
                    String js = "window.onSheetData(" + org.json.JSONObject.quote(result) + ")";
                    mainHandler.post(() -> webView.evaluateJavascript(js, null));
                } catch (Exception e) {
                    String message = e.getMessage() == null ? "Could not load the Google Sheet." : e.getMessage();
                    String js = "window.onSheetError(" + org.json.JSONObject.quote(message) + ")";
                    mainHandler.post(() -> webView.evaluateJavascript(js, null));
                } finally { if (connection != null) connection.disconnect(); }
            }).start();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
