/* JOSTECH — MANUEL 09 : GÉNIE LOGICIEL NIVEAU 3 */
registerLessonDetail(9, 3, "gl-3-1-1", {
  title: "Leçon 1 : Pyramide des Tests, CI/CD, Dette Technique et Maintenance",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Concevoir une stratégie complète selon la Pyramide des Tests (Unitaires, Intégration, E2E).",
    "Automatiser qualité et déploiement via un pipeline CI/CD.",
    "Identifier la Dette Technique et maîtriser les 4 types de maintenance logicielle."
  ],
  prerequisites: ["Niveau 2 — Architecture et Git."],
  sections: [
    {
      type: "table",
      title: "1. La Pyramide des Tests Automatisés",
      headers: ["Étage", "Ce qui est vérifié", "Vitesse & Volume"],
      rows: [
        ["Tests Unitaires (Base large)", "1 fonction isolée (ex: vérifier que calculerNote(10,10)=20).", "Ultra rapides (ms), très nombreux."],
        ["Tests d'Intégration (Milieu)", "Dialogue réel entre deux modules (ex: API + Base SQL).", "Moyens, ciblent les interfaces."],
        ["Tests E2E / Bout-en-Bout (Sommet)", "Robot ouvrant le navigateur et cliquant comme un vrai humain.", "Lents/fragiles : réservés aux parcours vitaux."]
      ]
    },
    {
      type: "definition",
      term: "Intégration Continue (CI) et Déploiement Continu (CD)",
      text: "• CI (Continuous Integration) : à chaque « git push », un serveur distant (ex: GitHub Actions) lance automatiquement tous les tests et vérifie qu'aucune ancienne fonctionnalité n'a été cassée (Non-régression).\n• CD (Continuous Deployment) : si 100 % des tests passent au vert, la nouvelle version est publiée automatiquement en ligne sans intervention manuelle risquée."
    },
    {
      type: "theory",
      title: "2. Dette Technique et les 4 types de Maintenance",
      text: "Prendre un raccourci sale pour livrer vite crée une Dette Technique (Ward Cunningham) : tout comme un prêt bancaire, on paie des « intérêts » en temps perdu chaque fois qu'on ajoute une nouvelle fonction. Il faut régulièrement faire du Refactoring (améliorer la structure interne sans changer le comportement externe).\n\nEn exploitation, on distingue 4 maintenances : Corrective (corriger un bug), Adaptative (adapter à un nouvel Android/navigateur), Perfective/Évolutive (ajouter de nouvelles fonctions) et Préventive (nettoyer avant que ça casse)."
    },
    {
      type: "warning",
      title: "Piège classique : Tester uniquement « à la main »",
      text: "Vérifier manuellement 50 écrans après chaque petite modification est épuisant et source d'oublis. Automatiser les tests critiques (calcul de notes, authentification) garantit qu'une correction n'introduit pas de régression ailleurs."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Identifier le type de maintenance",
      question: "Qualifiez chaque tâche :\nA) Réparer un bouton de quiz qui ne calculait plus la note.\nB) Mettre à jour l'app pour supporter Android 17.\nC) Ajouter un mode sombre demandé par les étudiants.",
      solution: "A) Maintenance corrective.\nB) Maintenance adaptative.\nC) Maintenance évolutive / perfective."
    },
    {
      title: "Exercice 2 — Bâtir un test unitaire",
      question: "Pourquoi un test unitaire ne doit-il jamais dépendre d'une vraie connexion Internet ni d'une horloge aléatoire ?",
      solution: "Un test unitaire doit être rapide et déterministe (toujours le même résultat si le code est bon). On simule (Mock) donc le réseau pour tester la fonction de manière 100 % isolée."
    }
  ],
  summary: "La qualité logicielle durable combine la Pyramide des Tests, l'automatisation CI/CD, le Refactoring pour maîtriser la dette technique et une maintenance structurée.",
  references: ["Martin, R. C. — Clean Code, Prentice Hall.", "Fowler, M. — Refactoring: Improving the Design of Existing Code."]
});