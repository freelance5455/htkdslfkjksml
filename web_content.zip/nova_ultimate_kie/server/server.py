import os
import requests
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder='static')
CORS(app, resources={r"/api/*": {"origins": "*"}, r"/health": {"origins": "*"}})
BASE = 'https://api.kie.ai'

def key_from_request():
    # Key is supplied per request; it is never written to disk or logged.
    return request.headers.get('X-KIE-KEY') or os.environ.get('KIE_API_KEY')

def headers():
    key = key_from_request()
    if not key:
        raise ValueError('Clé API KIE manquante. Ajoute-la dans les paramètres de NOVA.')
    return {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}

def safe_response(resp):
    try:
        data = resp.json()
    except Exception:
        return {'error': 'Réponse inattendue du fournisseur.'}, 502
    if resp.status_code >= 400 or (isinstance(data, dict) and data.get('code') not in (None, 200)):
        msg = data.get('msg') or data.get('message') or 'Erreur retournée par KIE.'
        return {'error': str(msg)}, 400
    return data, 200

@app.get('/health')
def health():
    return jsonify({'ok': True, 'app': 'NOVA ULTIMATE AI'})

@app.post('/api/chat')
def chat():
    try:
        h = headers()
        body = request.get_json(force=True) or {}
        model = body.get('model') or 'gemini-3.8-flash'
        messages = body.get('input') or []
        payload = {'model': model, 'input': messages}
        r = requests.post(BASE + '/openai/v1/responses', headers=h, json=payload, timeout=120)
        data, status = safe_response(r)
        if status != 200:
            return jsonify(data), status
        text = data.get('output_text')
        if not text:
            parts = []
            for item in data.get('output', []):
                for c in item.get('content', []):
                    if c.get('type') in ('output_text', 'text'):
                        parts.append(c.get('text', ''))
            text = '\n'.join(parts)
        return jsonify({'text': text or 'Réponse reçue.', 'raw': data})
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except requests.RequestException:
        return jsonify({'error': 'Connexion à KIE impossible. Réessaie plus tard.'}), 502
    except Exception:
        return jsonify({'error': 'Erreur interne du serveur NOVA.'}), 500

@app.post('/api/task')
def create_task():
    try:
        h = headers()
        body = request.get_json(force=True) or {}
        model = body.get('model')
        inputs = body.get('input')
        if not model or not isinstance(inputs, dict):
            return jsonify({'error': 'Modèle ou paramètres de génération manquants.'}), 400
        r = requests.post(BASE + '/api/v1/jobs/createTask', headers=h, json={'model': model, 'input': inputs}, timeout=120)
        data, status = safe_response(r)
        if status != 200:
            return jsonify(data), status
        task_id = (data.get('data') or {}).get('taskId') or data.get('taskId')
        if not task_id:
            return jsonify({'error': 'KIE n’a pas renvoyé de taskId.', 'details': data}), 502
        return jsonify({'taskId': task_id})
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except requests.RequestException:
        return jsonify({'error': 'Connexion à KIE impossible. Réessaie plus tard.'}), 502
    except Exception:
        return jsonify({'error': 'Erreur interne du serveur NOVA.'}), 500

@app.get('/api/task/<task_id>')
def task_info(task_id):
    try:
        h = headers()
        r = requests.get(BASE + '/api/v1/jobs/recordInfo', headers=h, params={'taskId': task_id}, timeout=60)
        data, status = safe_response(r)
        return jsonify(data), status
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except requests.RequestException:
        return jsonify({'error': 'Impossible de vérifier la tâche auprès de KIE.'}), 502

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8000)))
