NOVA ULTIMATE AI — KIE EDITION
================================

CONTENU
- index.html, style.css, app.js : interface web Android, sans React/Vite/Node.
- server/server.py : petit serveur sécurisé qui fait le relais vers KIE.
- server/requirements.txt et server/render.yaml : déploiement du serveur.

IMPORTANT
Le ZIP seul est l'interface. Les vraies fonctions IA nécessitent aussi le serveur Python en ligne.
La clé API n'est pas incluse dans le ZIP. Ne l'envoie jamais dans une conversation et ne la publie pas sur GitHub.
Les générations utilisent les crédits du compte KIE; elles ne sont pas illimitées.

DÉMARRAGE SIMPLE
1. Déploie le dossier server sur Render comme Web Service (runtime Python).
2. Le dossier racine du service doit être server. Build: pip install -r requirements.txt. Start: gunicorn server:app.
3. Après déploiement, copie l'adresse HTTPS du serveur.
4. Ouvre index.html dans le navigateur ou importe le ZIP dans ton convertisseur web-vers-APK.
5. Dans NOVA > Paramètres, colle l'adresse HTTPS du serveur et ta clé KIE, puis Enregistrer.
6. Teste le serveur. Ensuite essaie une création courte.

CLÉ API
La clé est gardée temporairement dans la session du navigateur, puis envoyée au serveur via HTTPS dans l'en-tête X-KIE-KEY. Le serveur ne l'enregistre pas sur disque. Pour un usage public, configure plutôt KIE_API_KEY dans les variables d'environnement Render et limite l'accès à ton application.

MODÈLES PAR DÉFAUT
- Image : seedream/5-pro-text-to-image
- Vidéo : kling-3.0/video
- Musique : ai-music-api/generate
- Chat : gemini-3.8-flash
Les modèles et paramètres peuvent changer. Si un modèle n'est pas disponible sur ton compte, vérifie le Market et la documentation KIE.

LIMITES DE CETTE VERSION
- Chat, création d'image, tâche vidéo et génération musicale sont branchés au relais KIE.
- La section manga utilise le générateur d'images pour créer une planche à partir d'un prompt.
- Le studio vidéo génère un plan à la fois. Il ne monte pas encore automatiquement plusieurs plans en un long film final.
- Le résultat peut prendre plusieurs minutes. Les crédits KIE sont consommés selon le modèle.
