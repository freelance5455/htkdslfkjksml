import http from 'node:http';
import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createDiagnosticSessionStore } from './diagnostic-session-store.mjs';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
try { for (const line of fs.readFileSync(path.join(ROOT,'.env'),'utf8').split(/\r?\n/)) { const m=line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if(m&&!process.env[m[1]]) process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,''); } } catch {}

const PORT = Number(process.env.PORT || 8787);
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.5';
const API_KEY = process.env.OPENAI_API_KEY || '';
const APP_ACCESS_TOKEN = process.env.APP_ACCESS_TOKEN || '';
const ALLOWED_ORIGINS = new Set((process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean));
const WINDOW_MS = 60 * 60 * 1000;
const LIMIT = Number(process.env.RATE_LIMIT_PER_HOUR || 20);
const hits = new Map();
const SESSION_STORE_PATH = process.env.DIAGNOSTIC_SESSION_STORE || path.join(ROOT, '.data', 'diagnostic-sessions.json');
const DIAGNOSTIC_STORE_KEY = process.env.DIAGNOSTIC_STORE_KEY || '';
const diagnosticSessions = createDiagnosticSessionStore(SESSION_STORE_PATH, { encryptionKey: DIAGNOSTIC_STORE_KEY });
function pruneDiagnosticSessions(){ diagnosticSessions.prune(); }
const MAX_BODY = 24 * 1024;

const json = (res, status, body, origin) => {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff', ...(origin ? {'Access-Control-Allow-Origin':origin,'Vary':'Origin'} : {}) });
  res.end(JSON.stringify(body));
};
const clean = (v, max=1000) => typeof v === 'string' ? v.trim().slice(0,max) : '';
function takeRate(ip) {
  const now=Date.now(), old=(hits.get(ip)||[]).filter(t=>now-t<WINDOW_MS);
  if(old.length>=LIMIT) return false;
  old.push(now); hits.set(ip,old); return true;
}
async function readBody(req) {
  let raw='';
  for await (const chunk of req) { raw += chunk; if(raw.length>MAX_BODY) throw Object.assign(new Error('body_too_large'),{status:413}); }
  try { return JSON.parse(raw || '{}'); } catch { throw Object.assign(new Error('invalid_json'),{status:400}); }
}
function getOutputText(data) {
  if(typeof data.output_text==='string') return data.output_text;
  for(const item of data.output||[]) for(const part of item.content||[]) if(part.type==='output_text'&&typeof part.text==='string') return part.text;
  return '';
}
async function askModel({instructions,input,maxOutputTokens=1200}) {
  if(!API_KEY) throw Object.assign(new Error('ai_not_configured'),{status:503});
  const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),35000);
  try {
    const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:MODEL,instructions,input,max_output_tokens:maxOutputTokens,store:false}),signal:controller.signal});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) { const e=new Error(r.status===401?'ai_auth_failed':r.status===429?'ai_rate_limited':'ai_provider_error'); e.status=r.status===429?429:502; throw e; }
    const output=getOutputText(data);
    if(!output) throw Object.assign(new Error('empty_ai_response'),{status:502});
    return output;
  } catch(e) { if(e.name==='AbortError') throw Object.assign(new Error('ai_timeout'),{status:504}); throw e; }
  finally { clearTimeout(timer); }
}
function parseJsonOutput(raw) {
  try { return JSON.parse(raw.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'')); }
  catch { throw Object.assign(new Error('invalid_ai_json'),{status:502}); }
}
function parseTask(raw, track, minutes) {
  const obj=parseJsonOutput(raw);
  const text=(v,min,max)=>typeof v==='string'&&v.trim().length>=min&&v.length<=max;
  if(!obj||!text(obj.title,8,120)||!Array.isArray(obj.steps)||obj.steps.length<3||obj.steps.length>7||obj.steps.some(x=>!text(x,5,180))||!text(obj.successCriteria,10,300)||!text(obj.deliverable,5,160)||!Number.isInteger(obj.durationMinutes)||obj.durationMinutes<5||obj.durationMinutes>minutes||!['تمهيدي','متوسط','متقدم'].includes(obj.difficulty)) throw Object.assign(new Error('invalid_task_schema'),{status:502});
  if(['strength','health'].includes(track)&&/دواء|علاج|تشخيص|جرعة|مكمل|ألم حاد|تمرين حتى الفشل/.test([obj.title,...obj.steps,obj.successCriteria].join(' '))) throw Object.assign(new Error('safety_rejected'),{status:422});
  return {title:obj.title.trim(),steps:obj.steps.map(x=>x.trim()),successCriteria:obj.successCriteria.trim(),durationMinutes:obj.durationMinutes,difficulty:obj.difficulty,deliverable:obj.deliverable.trim()};
}
const TRACKS={strength:'القوة واللياقة البدنية',intelligence:'الذكاء والتفكير',learning:'التعلم والمعرفة',discipline:'التركيز والانضباط',health:'الصحة والتعافي',practical:'المهارات العملية'};
const server=http.createServer(async(req,res)=>{
  const origin=req.headers.origin||'';
  if(origin && ALLOWED_ORIGINS.size && !ALLOWED_ORIGINS.has(origin)) return json(res,403,{error:'origin_not_allowed'},null);
  if(req.method==='OPTIONS') { res.writeHead(204,{'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Max-Age':'600',...(origin?{'Access-Control-Allow-Origin':origin,'Vary':'Origin'}:{})}); return res.end(); }
  const url=new URL(req.url,'http://localhost');
  if(req.method==='GET'&&url.pathname==='/api/health') return json(res,200,{ok:true,configured:Boolean(API_KEY),model:API_KEY?MODEL:null,authRequired:Boolean(APP_ACCESS_TOKEN),diagnosticSessionPersistence:'enabled'},origin||null);
  if(req.method==='GET' && !url.pathname.startsWith('/api/')) {
    let pathname=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
    const target=path.resolve(ROOT,'.'+pathname);
    if(!target.startsWith(ROOT+path.sep)) return json(res,403,{error:'forbidden'},origin||null);
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};
    try { const stat=fs.statSync(target); if(!stat.isFile()) throw new Error('not_file'); res.writeHead(200,{'Content-Type':types[path.extname(target)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':path.basename(target)==='index.html'?'no-cache':'public, max-age=3600'}); return fs.createReadStream(target).pipe(res); } catch { return json(res,404,{error:'not_found'},origin||null); }
  }
  if(req.method!=='POST'||!['/api/coach','/api/tasks/generate','/api/diagnostics/session/start','/api/diagnostics/session/answer','/api/mastery/evaluate','/api/progress/review','/api/plans/generate'].includes(url.pathname)) return json(res,404,{error:'not_found'},origin||null);
  if(APP_ACCESS_TOKEN && req.headers.authorization!==`Bearer ${APP_ACCESS_TOKEN}`) return json(res,401,{error:'unauthorized'},origin||null);
  const forwarded=process.env.TRUST_PROXY==='1'?(req.headers['x-forwarded-for']||''):'';
  const ip=(forwarded||req.socket.remoteAddress||'unknown').toString().split(',')[0].trim();
  if(!takeRate(ip)) return json(res,429,{error:'rate_limit_exceeded'},origin||null);
  try {
    const body=await readBody(req), track=clean(body.track,40);
    if(!TRACKS[track]) return json(res,400,{error:'invalid_track'},origin||null);
    const context=body.context&&typeof body.context==='object'?body.context:{};
    const safeContext={weaknesses:Array.isArray(context.weaknesses)?context.weaknesses.slice(0,8).map(x=>({skill:clean(x.skill,100),reason:clean(x.reason,240)})):[],recentPerformance:clean(context.recentPerformance,700),openTasks:Array.isArray(context.openTasks)?context.openTasks.slice(0,8).map(x=>clean(x,120)):[],availableMinutes:Math.max(5,Math.min(120,Number(body.availableMinutes)||25))};
    if(url.pathname==='/api/coach') {
      const question=clean(body.question,1200); if(question.length<3) return json(res,400,{error:'question_required'},origin||null);
      const output=await askModel({instructions:'أنت مدرب تطوير شخصي وتعليمي عملي. أجب بالعربية الواضحة، بخطوات قابلة للتنفيذ، واستند فقط إلى سياق اللاعب. افصل بين المعلومة والاقتراح. لا تخترع نتائج ولا تمنح XP أو عملات أو رتباً. في الصحة واللياقة لا تقدم تشخيصاً أو علاجاً أو جرعات أو أحمالاً خطرة. لا تتخذ قرارات نيابة عن اللاعب.',input:JSON.stringify({track:TRACKS[track],question,playerContext:safeContext}),maxOutputTokens:1000});
      return json(res,200,{ok:true,answer:output.slice(0,5000),source:'openai-responses',model:MODEL},origin||null);
    }
    const minutes=safeContext.availableMinutes;
    async function generateAdaptiveQuestion(trackId,index,difficulty,prior,ctx){
      const raw=await askModel({instructions:'أنت محرك اختبار تكيفي. أنشئ سؤال اختيار من متعدد واحداً فقط باللغة العربية للمسار المحدد. أخرج JSON فقط بمفاتيح skill,difficulty,question,options,correctIndex,rationale. options أربعة نصوص مختلفة. difficulty يجب أن يساوي targetDifficulty. السؤال يقيس التطبيق والفهم وليس حفظ صياغة. راجع سجل الإجابات السابقة: إذا أجاب اللاعب إجابة صحيحة، حافظ على المستوى أو ارفع التحدي تدريجياً؛ وإذا أخطأ، خفّض المستوى أو اختبر المهارة ذاتها من زاوية أبسط. تجنب تكرار المهارات والأسئلة حرفياً، وغطّ مهارات متنوعة في المسار. لا تكشف الإجابة الصحيحة داخل السؤال. في الصحة واللياقة تجنب التشخيص والعلاج والدواء والجرعات والنصائح الطبية؛ استخدم معرفة عامة آمنة فقط.',input:JSON.stringify({track:TRACKS[trackId],questionNumber:index+1,totalQuestions:5,targetDifficulty:difficulty,priorResults:prior,weaknesses:ctx.weaknesses,recentPerformance:ctx.recentPerformance}),maxOutputTokens:850});
      const obj=parseJsonOutput(raw);
      const valid=obj&&typeof obj.skill==='string'&&obj.skill.trim().length>=2&&obj.skill.length<=80&&obj.difficulty===difficulty&&typeof obj.question==='string'&&obj.question.trim().length>=20&&obj.question.length<=500&&Array.isArray(obj.options)&&obj.options.length===4&&obj.options.every(o=>typeof o==='string'&&o.trim().length>=2&&o.length<=180)&&new Set(obj.options).size===4&&Number.isInteger(obj.correctIndex)&&obj.correctIndex>=0&&obj.correctIndex<4&&typeof obj.rationale==='string'&&obj.rationale.trim().length>=10&&obj.rationale.length<=300;
      if(!valid)throw Object.assign(new Error('invalid_adaptive_question_schema'),{status:502});
      if(trackId==='health'&&/تشخيص|علاج|دواء|جرعة|مكمل|مرض|أعراض/.test(obj.question+' '+obj.options.join(' ')))throw Object.assign(new Error('safety_rejected'),{status:422});
      return {skill:obj.skill.trim(),difficulty:obj.difficulty,question:obj.question.trim(),options:obj.options.map(x=>x.trim()),correctIndex:obj.correctIndex,rationale:obj.rationale.trim()};
    }
    if(url.pathname==='/api/diagnostics/session/start'){
      pruneDiagnosticSessions();
      const question=await generateAdaptiveQuestion(track,0,2,[],safeContext);
      const sessionId=randomUUID();const questionToken=randomUUID();diagnosticSessions.set(sessionId,{track,createdAt:Date.now(),index:0,difficulty:2,current:question,questionToken,results:[],context:safeContext});
      return json(res,200,{ok:true,sessionId,questionToken,question:{skill:question.skill,difficulty:question.difficulty,question:question.question,options:question.options},questionNumber:1,totalQuestions:5},origin||null);
    }
    if(url.pathname==='/api/diagnostics/session/answer'){
      pruneDiagnosticSessions();
      const sessionId=clean(body.sessionId,64),questionToken=clean(body.questionToken,64),choice=Number(body.choiceIndex),session=diagnosticSessions.get(sessionId);
      if(!session||!questionToken||questionToken!==session.questionToken||!Number.isInteger(choice)||choice<0||choice>3)return json(res,400,{error:'invalid_diagnostic_session_answer'},origin||null);
      session.questionToken=null;
      const q=session.current,correct=choice===q.correctIndex;
      session.results.push({skill:q.skill,correct,chosenText:q.options[choice],correctText:q.options[q.correctIndex],difficulty:q.difficulty,rationale:q.rationale});
      session.index++;
      if(session.index<5){session.difficulty=Math.max(1,Math.min(5,q.difficulty+(correct?1:-1)));session.current=await generateAdaptiveQuestion(session.track,session.index,session.difficulty,session.results.map(x=>({skill:x.skill,correct:x.correct,difficulty:x.difficulty})),session.context);session.questionToken=randomUUID();diagnosticSessions.set(sessionId,session);return json(res,200,{ok:true,complete:false,correct,questionToken:session.questionToken,question:{skill:session.current.skill,difficulty:session.current.difficulty,question:session.current.question,options:session.current.options},questionNumber:session.index+1,totalQuestions:5},origin||null);}
      const correctCount=session.results.filter(x=>x.correct).length,score=Math.round(correctCount*20);
      let analysis=null;
      try{
        const raw=await askModel({instructions:'حلل نتيجة اختبار تشخيصي تعليمي بناءً على الإجابات المعطاة فقط. أخرج JSON فقط بمفاتيح summary, strengths, weaknesses, recommendedFocus. summary نص من 30 إلى 500 حرف. strengths مصفوفة من 1 إلى 3 عناصر نصية. weaknesses مصفوفة من 1 إلى 3 عناصر، كل عنصر كائن بمفاتيح skill, observation, nextStep. recommendedFocus نص من 10 إلى 200 حرف. لا تستنتج سمات شخصية ثابتة ولا تدّع قياساً موضوعياً أو إتقاناً مثبتاً. كن محدداً، متوازناً، ولا تعمم من خمسة أسئلة فقط. في مسار الصحة لا تقدم تشخيصاً أو علاجاً أو نصائح دوائية؛ اقتصر على عادات عامة غير طبية.',input:JSON.stringify({track:TRACKS[session.track],answers:session.results,context:{weaknesses:session.context.weaknesses,recentPerformance:session.context.recentPerformance}}),maxOutputTokens:1000});
        const obj=parseJsonOutput(raw);if(obj&&typeof obj.summary==='string'&&obj.summary.length>=30&&obj.summary.length<=500&&Array.isArray(obj.strengths)&&obj.strengths.length>=1&&obj.strengths.length<=3&&Array.isArray(obj.weaknesses)&&obj.weaknesses.length>=1&&obj.weaknesses.length<=3&&typeof obj.recommendedFocus==='string'&&obj.recommendedFocus.length>=10&&obj.recommendedFocus.length<=200)analysis={summary:obj.summary,strengths:obj.strengths,weaknesses:obj.weaknesses,recommendedFocus:obj.recommendedFocus};
      }catch{}
      diagnosticSessions.delete(sessionId);
      return json(res,200,{ok:true,complete:true,score,correctCount,answers:session.results,analysis,notice:'نتيجة إرشادية لا تثبت الإتقان بمفردها.'},origin||null);
    }
    if(url.pathname==='/api/mastery/evaluate'){
      const skill=clean(body.skill,100),evidenceType=clean(body.evidenceType,20),artifact=clean(body.artifact,3500),criteria=clean(body.successCriteria,800);
      if(skill.length<2||!['test','practical','project'].includes(evidenceType)||artifact.length<30||criteria.length<10)return json(res,400,{error:'invalid_mastery_evidence'});
      if(track==='health'&&/مرض|أعراض|تشخيص|علاج|دواء|جرعة|مكمل/.test(artifact+' '+criteria))throw Object.assign(new Error('safety_rejected'),{status:422});
      const raw=await askModel({instructions:'أنت مقيّم تعلم ومهارات. قيّم الدليل المقدم وفق معيار النجاح، ولا تفترض صحة ادعاءات لا يمكن التحقق منها. أخرج JSON فقط بالمفاتيح score, confidence, rationale, strengths, gaps, nextEvidence. score عدد صحيح 0-100 يعكس جودة الدليل المعروض لا قدرة الشخص المطلقة. confidence إحدى low,medium,high. rationale نص 30-400 حرف. strengths وgaps قائمتان من 1-3 عناصر قصيرة. nextEvidence نص 10-200 حرف. إذا كان الدليل مجرد وصف ذاتي بلا مخرج ملموس، اجعل الثقة low ولا تمنح درجة عالية. لا تمنح إتقاناً أو XP أو رتبة؛ القرار النهائي للمستخدم. في الصحة لا تقيّم حالة طبية أو تقدم تشخيصاً.',input:JSON.stringify({track:TRACKS[track],skill,evidenceType,successCriteria:criteria,evidence:artifact}),maxOutputTokens:900});
      const obj=parseJsonOutput(raw),valid=obj&&Number.isInteger(obj.score)&&obj.score>=0&&obj.score<=100&&['low','medium','high'].includes(obj.confidence)&&typeof obj.rationale==='string'&&obj.rationale.length>=30&&obj.rationale.length<=400&&Array.isArray(obj.strengths)&&obj.strengths.length>=1&&obj.strengths.length<=3&&Array.isArray(obj.gaps)&&obj.gaps.length>=1&&obj.gaps.length<=3&&typeof obj.nextEvidence==='string'&&obj.nextEvidence.length>=10&&obj.nextEvidence.length<=200;
      if(!valid)throw Object.assign(new Error('invalid_mastery_evaluation'),{status:502});
      return json(res,200,{ok:true,evaluation:{score:obj.score,confidence:obj.confidence,rationale:obj.rationale,strengths:obj.strengths,gaps:obj.gaps,nextEvidence:obj.nextEvidence},status:'suggested_not_verified'},origin||null);
    }
    if(url.pathname==='/api/progress/review') {
      const records=Array.isArray(body.records)?body.records.slice(-30):[];
      if(records.length<2||records.some(x=>!x||typeof x.skill!=='string'||x.skill.length>100||!Number.isInteger(x.score)||x.score<0||x.score>100||!['test','practical','project'].includes(x.evidenceType)||typeof x.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(x.date)))return json(res,400,{error:'invalid_progress_history'},origin||null);
      const raw=await askModel({instructions:'أنت محلل تطور تعليمي. حلل سجلاً زمنياً من تقييمات مهارات. لا تستنتج سبباً نفسياً أو طبياً ولا تخلط بين الارتباط والسببية. ميّز التحسن والتراجع والثبات مع مراعاة عدد التقييمات والفواصل الزمنية. إذا كانت البيانات قليلة فصرّح بذلك. أخرج JSON فقط بالمفاتيح summary,pattern,priorities,adjustment,nextCheck. summary نص 30-300 حرف، pattern نص 20-300 حرف، priorities مصفوفة 1-3 عناصر، adjustment نص 20-300 حرف، nextCheck نص 10-200 حرف. لا تغير أهداف اللاعب ولا تمنح XP أو إتقاناً.',input:JSON.stringify({track:TRACKS[track],records,context:{recentPerformance:safeContext.recentPerformance,weaknesses:safeContext.weaknesses}}),maxOutputTokens:900});
      const obj=parseJsonOutput(raw),valid=obj&&typeof obj.summary==='string'&&obj.summary.length>=30&&obj.summary.length<=300&&typeof obj.pattern==='string'&&obj.pattern.length>=20&&obj.pattern.length<=300&&Array.isArray(obj.priorities)&&obj.priorities.length>=1&&obj.priorities.length<=3&&obj.priorities.every(x=>typeof x==='string'&&x.length>=5&&x.length<=180)&&typeof obj.adjustment==='string'&&obj.adjustment.length>=20&&obj.adjustment.length<=300&&typeof obj.nextCheck==='string'&&obj.nextCheck.length>=10&&obj.nextCheck.length<=200;
      if(!valid)throw Object.assign(new Error('invalid_progress_review'),{status:502});
      return json(res,200,{ok:true,review:obj,status:'advisory_only'},origin||null);
    }
    if(url.pathname==='/api/plans/generate') {
      const raw=await askModel({instructions:'أنشئ خطة تطوير شخصية لمدة 7 أيام للمسار المحدد. أخرج JSON فقط بمفاتيح title,objective,durationDays,tasks. tasks من 3 إلى 5 مهام. كل مهمة: title,steps (3 إلى 5 خطوات),successCriteria,durationMinutes (5 إلى الوقت المتاح),difficulty (تمهيدي أو متوسط أو متقدم),deliverable. اربط الخطة بنقاط الضعف والسياق المعطى، ووزع المهام على أيام مختلفة بإضافة day (1 إلى 7). لا تضف XP أو عملات أو مكافآت. لا تغيّر أهداف اللاعب ولا تدّع قياس الإتقان. في القوة والصحة نشاطات عامة منخفضة المخاطر فقط، بلا تشخيص أو علاج أو جرعات أو مكملات أو أحمال عالية.',input:JSON.stringify({track:TRACKS[track],weaknesses:safeContext.weaknesses,recentPerformance:safeContext.recentPerformance,openTasks:safeContext.openTasks,availableMinutes:minutes}),maxOutputTokens:2200});
      const obj=parseJsonOutput(raw), tasks=obj&&obj.tasks;
      const valid=obj&&typeof obj.title==='string'&&obj.title.trim().length>=5&&obj.title.length<=120&&typeof obj.objective==='string'&&obj.objective.trim().length>=10&&obj.objective.length<=300&&obj.durationDays===7&&Array.isArray(tasks)&&tasks.length>=3&&tasks.length<=5&&tasks.every(x=>Number.isInteger(x.day)&&x.day>=1&&x.day<=7&&typeof x.title==='string'&&x.title.trim().length>=8&&x.title.length<=120&&Array.isArray(x.steps)&&x.steps.length>=3&&x.steps.length<=5&&x.steps.every(v=>typeof v==='string'&&v.trim().length>=5&&v.length<=180)&&typeof x.successCriteria==='string'&&x.successCriteria.trim().length>=10&&x.successCriteria.length<=300&&Number.isInteger(x.durationMinutes)&&x.durationMinutes>=5&&x.durationMinutes<=minutes&&['تمهيدي','متوسط','متقدم'].includes(x.difficulty)&&typeof x.deliverable==='string'&&x.deliverable.trim().length>=5&&x.deliverable.length<=160);
      if(!valid) throw Object.assign(new Error('invalid_plan_schema'),{status:502});
      if(['health','strength'].includes(track)&&/دواء|علاج|تشخيص|جرعة|مكمل|ألم حاد|تمرين حتى الفشل|أوزان قصوى/.test(JSON.stringify(obj))) throw Object.assign(new Error('safety_rejected'),{status:422});
      return json(res,200,{ok:true,plan:{title:obj.title.trim(),objective:obj.objective.trim(),durationDays:7,tasks:tasks.map(x=>({...x,title:x.title.trim(),steps:x.steps.map(v=>v.trim()),successCriteria:x.successCriteria.trim(),deliverable:x.deliverable.trim()}))},source:'openai-responses',model:MODEL,status:'proposed'},origin||null);
    }
    const raw=await askModel({instructions:'أنشئ مسودة مهمة تدريب عربية عملية للمسار المحدد. أخرج JSON فقط بمفاتيح title,steps,successCriteria,durationMinutes,difficulty,deliverable. steps من 3 إلى 7. difficulty إحدى: تمهيدي، متوسط، متقدم. المدة عدد صحيح بين 5 والوقت المتاح. لا تضع XP أو عملات أو نقاطاً أو مكافآت. المهمة يجب أن يكون لها ناتج قابل للمراجعة ومعيار نجاح واضح. لا تدّع قياس الإتقان. في القوة والصحة اقترح نشاطاً عاماً منخفض المخاطر فقط، بلا تشخيص أو علاج أو جرعات أو مكملات أو أحمال عالية.',input:JSON.stringify({track:TRACKS[track],weaknesses:safeContext.weaknesses,recentPerformance:safeContext.recentPerformance,openTasks:safeContext.openTasks,availableMinutes:minutes}),maxOutputTokens:900});
    const task=parseTask(raw,track,minutes);
    return json(res,200,{ok:true,task,source:'openai-responses',model:MODEL,status:'proposed'},origin||null);
  } catch(e) {
    const status=e.status||500; const known=['ai_not_configured','ai_auth_failed','ai_rate_limited','ai_provider_error','empty_ai_response','ai_timeout','invalid_ai_json','invalid_task_schema','safety_rejected','invalid_plan_schema','invalid_diagnostic_session_answer','invalid_mastery_evidence','invalid_mastery_evaluation','invalid_progress_history','invalid_progress_review','body_too_large','invalid_json'];
    return json(res,status,{error:known.includes(e.message)?e.message:'internal_error'},origin||null);
  }
});
server.listen(PORT,()=>{console.log(`Player Awakening 3.10.0 server listening on :${PORT}`);if(!API_KEY)console.warn('AI disabled: set OPENAI_API_KEY in server .env');if(!APP_ACCESS_TOKEN)console.warn('WARNING: APP_ACCESS_TOKEN is empty; AI endpoints are not access-protected');if(process.env.NODE_ENV==='production'&&!APP_ACCESS_TOKEN){console.error('Refusing production start without APP_ACCESS_TOKEN');process.exit(1);}if(process.env.NODE_ENV==='production'&&!DIAGNOSTIC_STORE_KEY){console.error('Refusing production start without DIAGNOSTIC_STORE_KEY');process.exit(1);}if(!DIAGNOSTIC_STORE_KEY)console.warn('WARNING: diagnostic sessions are persisted without encryption; configure DIAGNOSTIC_STORE_KEY.');});
