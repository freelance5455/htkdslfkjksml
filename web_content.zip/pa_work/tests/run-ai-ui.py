from pathlib import Path
import os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
SHIM=r'''(()=>{const d=new Map();const s={getItem:k=>d.has(String(k))?d.get(String(k)):null,setItem:(k,v)=>d.set(String(k),String(v)),removeItem:k=>d.delete(String(k)),clear:()=>d.clear(),key:i=>Array.from(d.keys())[i]??null};Object.defineProperty(s,'length',{get:()=>d.size});Object.defineProperty(window,'localStorage',{configurable:true,value:s});})();'''
with sync_playwright() as pw:
    args={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
    exe=os.environ.get('CHROMIUM_EXECUTABLE')
    if exe: args['executable_path']=exe
    elif Path('/usr/bin/chromium').exists(): args['executable_path']='/usr/bin/chromium'
    browser=pw.chromium.launch(**args); page=browser.new_page(); errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('about:blank'); page.evaluate(SHIM); page.set_content(HTML,wait_until='load'); page.wait_for_timeout(700)
    assert page.locator('#aiCoachCard').count()==1
    page.evaluate('''() => { window.fetch=async()=>new Response(JSON.stringify({ok:true,task:{title:'مراجعة مفهوم واحد وحل مثال',steps:['حدد المفهوم الأساسي','اكتب تعريفه من الذاكرة','حل مثالاً تطبيقياً'],successCriteria:'شرح المفهوم وحل المثال دون الرجوع للمصدر',durationMinutes:20,difficulty:'متوسط',deliverable:'ملخص من خمس نقاط ومثال محلول'}}),{status:200,headers:{'Content-Type':'application/json'}}); }''')
    page.locator('#aiGenerateBtn').click(); page.wait_for_timeout(100)
    assert 'مراجعة مفهوم' in page.locator('#aiTaskPreview').inner_text()
    before=page.evaluate('() => PA.app.getState().progress.lifetimeXp')
    page.locator('#aiAcceptTask').click(); page.wait_for_timeout(150)
    after=page.evaluate('() => PA.app.getState().progress.lifetimeXp')
    added=page.evaluate("() => PA.app.getState().tasks.some(t=>t.title==='مراجعة مفهوم واحد وحل مثال'&&t.kind==='side')")
    assert added and before==after, 'accepted draft should create a task but not grant XP immediately'
    page.locator('.tab[data-view="development"]').click()
    page.evaluate('''() => { const analysis={ok:true,analysis:{summary:'يظهر الاختبار أساساً جيداً مع حاجة إلى تحسين الاسترجاع والتطبيق.',strengths:['فهم المفاهيم الأساسية'],weaknesses:[{skill:'الاسترجاع',observation:'تحتاج إلى تدريب منتظم.',nextStep:'استخدم الاسترجاع النشط يومياً.'}],recommendedFocus:'ابدأ بمراجعة قصيرة ثم تطبيق عملي.'}}; const plan={ok:true,plan:{title:'خطة التعلم الأسبوعية',objective:'تحسين الاسترجاع النشط والتطبيق العملي بصورة تدريجية.',durationDays:7,tasks:[1,2,3].map(i=>({day:i*2-1,title:'تدريب تطبيقي رقم '+i,steps:['حدد الهدف','نفذ التدريب','راجع النتيجة'],successCriteria:'إنتاج مخرج قابل للمراجعة مع توثيق النتيجة.',durationMinutes:15,difficulty:'تمهيدي',deliverable:'ملخص قصير رقم '+i}))}}; window.adaptiveCalls=[];let sessionIndex=0;window.fetch=async(url,opts={})=>{const path=String(url);if(path.includes('diagnostics/session/start'))return new Response(JSON.stringify({ok:true,sessionId:'test-session',questionToken:'token-1',questionNumber:1,question:{skill:'مهارة 1',difficulty:2,question:'كيف تطبق المفهوم في موقف عملي رقم 1؟',options:['الخيار أ','الخيار ب','الخيار ج','الخيار د']}}),{status:200,headers:{'Content-Type':'application/json'}});if(path.includes('diagnostics/session/answer')){const body=JSON.parse(opts.body);window.adaptiveCalls.push(body);sessionIndex++;const complete=sessionIndex===5;return new Response(JSON.stringify(complete?{ok:true,complete:true,score:100,correctCount:5,answers:Array.from({length:5},(_,i)=>({skill:'مهارة '+(i+1),correct:true,chosenText:'الخيار ج',correctText:'الخيار ج',difficulty:i+2,rationale:'هذا الخيار يطبق المفهوم بخطوات صحيحة وواضحة.'})),analysis:analysis.analysis,notice:'نتيجة إرشادية.'}:{ok:true,complete:false,correct:true,questionToken:'token-'+(sessionIndex+1),questionNumber:sessionIndex+1,question:{skill:'مهارة '+(sessionIndex+1),difficulty:sessionIndex+2,question:'كيف تطبق المفهوم في موقف عملي رقم '+(sessionIndex+1)+'؟',options:['الخيار أ','الخيار ب','الخيار ج','الخيار د']}}),{status:200,headers:{'Content-Type':'application/json'}});}if(path.includes('mastery/evaluate'))return new Response(JSON.stringify({ok:true,evaluation:{score:82,confidence:'medium',rationale:'الدليل يوضح فهماً جيداً مع خطوات تطبيق مناسبة ومخرج يمكن مراجعته.',strengths:['شرح منظم','تطبيق واضح'],gaps:['يحتاج إلى مثال إضافي'],nextEvidence:'أرفق مثالاً ثانياً مستقلاً يطبق المهارة في سياق مختلف.'}}),{status:200,headers:{'Content-Type':'application/json'}});return new Response(JSON.stringify(plan),{status:200,headers:{'Content-Type':'application/json'}});}; }''')
    page.locator('#aiDiagnosticBtn').click(); page.wait_for_timeout(100)
    assert page.locator('input[name="aiAdaptiveAnswer"]').count()==4, 'adaptive diagnostic should show one question at a time'
    for i in range(5):
        page.locator('input[name="aiAdaptiveAnswer"][value="2"]').check()
        page.locator('#aiAdaptiveSubmit').click(); page.wait_for_timeout(100)
    saved=page.evaluate("() => PA.app.getState().development.aiDiagnosticHistory.slice(-1)[0]")
    calls=page.evaluate('() => window.adaptiveCalls')
    assert saved and saved['score']==100 and saved['correct']==5 and saved['analysis']['weaknesses'][0]['skill']=='الاسترجاع', 'adaptive diagnostic score and analysis should be saved in development history'
    assert len(calls)==5 and all(x['choiceIndex']==2 for x in calls), 'answers should be submitted to the server-side session for scoring'
    before_plan_xp=page.evaluate('() => PA.app.getState().progress.lifetimeXp')
    page.locator('#aiPlanBtn').click(); page.wait_for_timeout(100)
    assert 'خطة التعلم الأسبوعية' in page.locator('#aiPlanPanel').inner_text()
    page.locator('#aiApprovePlan').click(); page.wait_for_timeout(250)
    plan_tasks=page.evaluate("() => PA.app.getState().tasks.filter(t=>t.kind==='side'&&t.title.includes('تدريب تطبيقي رقم')).length")
    after_plan_xp=page.evaluate('() => PA.app.getState().progress.lifetimeXp')
    assert plan_tasks==3 and before_plan_xp==after_plan_xp, 'weekly plan should add tasks only after approval and award no XP'
    page.locator('#masterySkill-learning').select_option('understanding_explaining')
    page.locator('#masteryType-learning').select_option('practical')
    page.locator('#masteryNote-learning').fill('قدمت شرحاً للمفهوم ثم طبقت الخطوات على مثال مستقل وسجلت الناتج ومراجعة الأخطاء بالتفصيل.')
    page.locator('[data-action="evaluateMastery"][data-track="learning"]').click(); page.wait_for_timeout(100)
    assert page.locator('#masteryScore-learning').input_value()=='82' and 'درجة مقترحة' in page.locator('#masteryAi-learning').inner_text(), 'AI evidence review should suggest a score without auto-saving it'
    pre_assessments=page.evaluate("() => PA.app.getState().mastery.assessments.length")
    page.locator('[data-action="recordMastery"][data-track="learning"]').click(); page.wait_for_timeout(120)
    post_assessments=page.evaluate("() => PA.app.getState().mastery.assessments.length")
    assert post_assessments==pre_assessments+1, 'mastery assessment should only be saved after explicit player approval'
    assert not errors, errors
    print('AI UI: task proposal approval, server-scored adaptive diagnostic (5 server session answers), saved analysis/history, weekly plan approval, AI evidence score suggestion with explicit save, no premature XP; zero browser errors.')
    browser.close()
