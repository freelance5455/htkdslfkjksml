'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
assert.match(sw, /player-awakening-3\.10\.0-shell/);
const handlers = {};
let cachedAssets = [], deleted = [], claimed = 0, skipped = 0, networkCalls = 0, cachePuts = 0;
const cachedIndex = { id: 'cached-index' };
const cache = {
  addAll: async list => { cachedAssets = list.slice(); },
  match: async url => String(url).endsWith('/index.html') ? cachedIndex : null,
  put: async () => { cachePuts++; }
};
const cachesMock = {
  open: async () => cache,
  keys: async () => ['player-awakening-old-shell', 'unrelated-cache'],
  delete: async key => { deleted.push(key); return true; }
};
const selfMock = {
  location: { origin: 'https://player.example' },
  registration: { scope: 'https://player.example/' },
  clients: { claim: async () => { claimed++; } },
  skipWaiting: async () => { skipped++; },
  addEventListener: (name, fn) => { handlers[name] = fn; }
};
const fetchMock = async request => {
  networkCalls++;
  return { ok: true, type: 'basic', request, clone() { return this; } };
};
vm.runInNewContext(sw, { self: selfMock, caches: cachesMock, URL, fetch: fetchMock, Promise });

(async () => {
  let wait;
  handlers.install({ waitUntil: p => { wait = p; } });
  await wait;
  assert.ok(cachedAssets.includes('./index.html'));
  assert.ok(cachedAssets.includes('./manifest.webmanifest'));
  assert.ok(cachedAssets.includes('./icons/icon-512.png'));
  assert.equal(skipped, 1);

  handlers.activate({ waitUntil: p => { wait = p; } });
  await wait;
  assert.ok(deleted.includes('player-awakening-old-shell'));
  assert.ok(!deleted.includes('unrelated-cache'));
  assert.equal(claimed, 1);

  let response;
  handlers.fetch({
    request: { method: 'GET', url: 'https://player.example/index.html', mode: 'navigate' },
    respondWith: p => { response = p; }
  });
  assert.equal(await response, cachedIndex);
  assert.equal(networkCalls, 0);

  handlers.fetch({
    request: { method: 'GET', url: 'https://player.example/icons/icon-512.png', mode: 'no-cors' },
    respondWith: p => { response = p; }
  });
  const assetResponse = await response;
  assert.equal(assetResponse.ok, true);
  assert.equal(networkCalls, 1);
  assert.equal(cachePuts, 1);

  let intercepted = false;
  handlers.fetch({ request: { method: 'GET', url: 'https://player.example/api/player-data', mode: 'cors' }, respondWith: () => { intercepted = true; } });
  handlers.fetch({ request: { method: 'GET', url: 'https://player.example/private/export.json', mode: 'cors' }, respondWith: () => { intercepted = true; } });
  handlers.fetch({ request: { method: 'GET', url: 'https://cdn.example/x.js', mode: 'cors' }, respondWith: () => { intercepted = true; } });
  handlers.fetch({ request: { method: 'POST', url: 'https://player.example/api', mode: 'cors' }, respondWith: () => { intercepted = true; } });
  assert.equal(intercepted, false, 'dynamic/API/private, external, or non-GET requests must not be intercepted');
  assert.equal(networkCalls, 1, 'dynamic responses must not be fetched through the cache handler');
  console.log('PWA shell allowlist, service-worker lifecycle, and no-dynamic-cache tests passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
