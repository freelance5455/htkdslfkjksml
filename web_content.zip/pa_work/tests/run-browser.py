from pathlib import Path
import os
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')
STORAGE_SHIM = r'''(() => {
  const data = new Map();
  const store = {
    getItem: k => data.has(String(k)) ? data.get(String(k)) : null,
    setItem: (k,v) => data.set(String(k), String(v)),
    removeItem: k => data.delete(String(k)), clear: () => data.clear(),
    key: i => Array.from(data.keys())[i] ?? null
  };
  Object.defineProperty(store, 'length', { get: () => data.size });
  Object.defineProperty(window, 'localStorage', { configurable: true, value: store });
})();'''

with sync_playwright() as pw:
    launch_args = {'headless': True, 'args': ['--no-sandbox','--disable-dev-shm-usage','--disable-web-security']}
    executable = os.environ.get('CHROMIUM_EXECUTABLE')
    if executable:
        launch_args['executable_path'] = executable
    elif Path('/usr/bin/chromium').exists():
        launch_args['executable_path'] = '/usr/bin/chromium'
    browser = pw.chromium.launch(**launch_args)
    page = browser.new_page(viewport={'width': 1440, 'height': 1000})
    page.goto('about:blank')
    page.evaluate(STORAGE_SHIM)
    errors = []
    page.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)))
    page.on('console', lambda m: errors.append('console error: ' + m.text) if m.type == 'error' else None)
    page.set_content(HTML, wait_until='load')
    page.wait_for_timeout(700)
    assert 'النظام نشط' in page.locator('#statusPill').inner_text()
    assert page.locator('.tab').count() >= 10
    assert page.locator('#installAppBtn').is_hidden()
    page.evaluate('''() => { const e=new Event('beforeinstallprompt'); e.prompt=()=>{window.__installPrompted=true;}; e.userChoice=Promise.resolve({outcome:'accepted'}); window.dispatchEvent(e); }''')
    assert page.locator('#installAppBtn').is_visible()
    page.locator('#installAppBtn').click()
    page.wait_for_timeout(50)
    assert page.locator('#installAppBtn').is_hidden()
    assert page.evaluate('() => window.__installPrompted === true')
    print('PASS boot + navigation shell + PWA install prompt UI')

    # Verify legacy v1 migration from a representative player_awakening.html state.
    migration = page.evaluate('''() => {
      const old = {
        level: 2, xp: 20, totalXp: 120, wallet: 120, points: 5, streak: 4,
        lastDate: '2026-11-15', name: 'Legacy Player', mode: 'normal', missed: 1,
        stats: { intelligence: 10, strength: 11, vitality: 10, agility: 10, discipline: 10, spirituality: 10 },
        tasks: [{ id: 'study', title: 'مهمة قديمة', cat: 'الدراسة', xp: 15, kind: 'daily', done: true }],
        spirit: [{ id: 'quran', title: 'قراءة القرآن', detail: 'متابعة', done: true }],
        spiritHistory: [], quranTotal: 12, reflection: 'ملاحظة قديمة',
        rewards: [{ title: 'مكافأة قديمة', cost: 20, type: 'شخصية' }], mainQuest: 'هدف قديم', noticeMessage: 'تنبيه قديم', comp: null
      };
      const result = PA.schema.migrateV1(old, new Date('2026-11-15T12:00:00Z'));
      const s = result.state;
      return { name:s.player.name, task:s.tasks[0].title, level:s.progress.level, lifetime:s.progress.lifetimeXp, wallet:s.progress.wallet, coins:s.progress.coinWallet, goal:s.goals[0].title, quran:s.quran.total, spirit:s.spirit[0].title, schema:s.schema };
    }''')
    assert migration['name'] == 'Legacy Player' and migration['task'] == 'مهمة قديمة'
    assert migration['level'] == 2 and migration['lifetime'] == 120
    assert migration['wallet'] == 0 and migration['coins'] == 120
    assert migration['goal'] == 'هدف قديم' and migration['quran'] == 12
    print('PASS original v1 migration + XP/coin separation + player fields preserved')

    economy = page.evaluate('''() => {
      const st=PA.schema.fresh(new Date('2026-11-15T12:00:00Z'));
      const now=new Date('2026-11-15T12:00:00Z');
      const gain=PA.engine.awardXp(st,now,15,{kind:'test',ref:'award'},'browser-test-award');
      const spend=PA.engine.spendCoins(st,now,10,{kind:'reward',ref:'test_reward'});
      return {gain:gain.ok,spend:spend.ok,lifetime:st.progress.lifetimeXp,levelXp:st.progress.levelXp,xpWallet:st.progress.wallet,coins:st.progress.coinWallet,audit:PA.engine.audit(st)};
    }''')
    assert economy['gain'] and economy['spend']
    assert economy['lifetime'] == 15 and economy['levelXp'] == 15 and economy['xpWallet'] == 15 and economy['coins'] == 5
    assert economy['audit'] == []
    print('PASS XP and reward coins remain independent after reward spending')

    # Persistence session backup/restore and failed import safety on an isolated memory adapter.
    persistence = page.evaluate('''async () => {
      const clock={now:()=>new Date('2026-11-16T12:00:00.000Z')};
      const adapter=PA.storage.createMemoryAdapter();
      const session=PA.persistence.createSession(adapter,clock);
      const boot=await session.boot();
      const st=boot.state; st.player.name='QA-ORIGINAL';
      await session.save(st);
      const id=await session.backup('manual-roundtrip',JSON.stringify(st),'schema-v5');
      st.player.name='QA-MUTATED'; await session.save(st);
      const restored=await session.restoreBackup(id);
      const afterRestore=await adapter.getState();
      const badId=await adapter.addBackup({ts:clock.now().toISOString(),reason:'invalid-test',kind:'test',json:'{not-json'});
      const beforeBad=await adapter.getState();
      const rejected=await session.restoreBackup(badId);
      const afterBad=await adapter.getState();
      return {ok:restored.ok,name:restored.state.player.name,persisted:JSON.parse(afterRestore.json).player.name,backups:(await adapter.listBackups()).map(x=>x.reason),badRejected:!rejected.ok,badUnchanged:beforeBad.json===afterBad.json};
    }''')
    assert persistence['ok'] and persistence['name']=='QA-ORIGINAL' and persistence['persisted']=='QA-ORIGINAL'
    assert 'manual-roundtrip' in persistence['backups'] and 'pre-restore' in persistence['backups']
    assert persistence['badRejected'] and persistence['badUnchanged']
    print('PASS backup/restore round-trip + pre-restore backup + invalid restore leaves current data unchanged')

    # Simulate a storage read-back mismatch after writing an import; the previous state must be restored.
    rollback = page.evaluate('''async () => {
      const clock={now:()=>new Date('2026-11-16T12:00:00.000Z')};
      const base=PA.storage.createMemoryAdapter();
      const original=PA.schema.fresh(clock.now()); original.player.name='ROLLBACK-ORIGINAL';
      base._setRawState(JSON.stringify(original),1);
      let sabotage=false;
      const adapter={...base,
        async getState(){const r=await base.getState();if(sabotage){sabotage=false;return r?{...r,json:r.json+' '}:r;}return r;},
        async putState(json,expectedRev){const r=await base.putState(json,expectedRev);sabotage=true;return r;}
      };
      const session=PA.persistence.createSession(adapter,clock);
      const incoming=PA.schema.fresh(clock.now());incoming.player.name='IMPORT-SHOULD-ROLL-BACK';
      const result=await session.importText(JSON.stringify(incoming));
      const final=await base.getState();
      return {ok:result.ok,errors:result.errors||[],name:JSON.parse(final.json).player.name,backups:(await base.listBackups()).map(x=>x.reason)};
    }''')
    assert not rollback['ok'] and rollback['name']=='ROLLBACK-ORIGINAL', rollback
    assert 'pre-import' in rollback['backups'], rollback
    print('PASS failed read-back rolls back to original state; pre-import backup retained')

    # Dungeons, boss battles, one-time XP rewards, achievements, titles, and rank evaluation.
    encounters = page.evaluate('''() => {
      const now=new Date('2026-11-16T12:00:00.000Z'),st=PA.schema.fresh(now);
      const started=PA.encounters.start(st,'dungeon','echo-trail',now);
      const before=st.progress.lifetimeXp;
      const blocked=PA.encounters.complete(st,now);
      for(let i=0;i<st.encounters.active.steps.length;i++)PA.encounters.toggleStep(st,i,true);
      const dungeon=PA.encounters.complete(st,now);
      const afterDungeon=st.progress.lifetimeXp;
      const level=PA.engine.awardXp(st,now,75,{kind:'test',ref:'boss-unlock'},'boss-unlock-xp');
      const unlocked=PA.encounters.catalog(st).bosses.find(x=>x.id==='gatekeeper').unlocked;
      const bossStart=PA.encounters.start(st,'boss','gatekeeper',now);
      for(let i=0;i<st.encounters.active.steps.length;i++)PA.encounters.toggleStep(st,i,true);
      const boss=PA.encounters.complete(st,now);
      const xpAfterBoss=st.progress.lifetimeXp;
      const duplicateStart=PA.encounters.start(st,'boss','gatekeeper',now);
      const rank=PA.progression.sync(st,now);
      const earned=st.progression.earned.map(x=>x.id);
      const titles=PA.progression.unlockedTitles(st).map(x=>x.id);
      const earnedCount=earned.length;PA.progression.sync(st,now);
      return {started:started.ok,blocked:blocked.reason,before, dungeon:dungeon.ok,dungeonXp:afterDungeon-before,level:level.ok,unlocked,bossStart:bossStart.ok,boss:boss.ok,bossXp:xpAfterBoss-afterDungeon-75,duplicate:duplicateStart.reason,earned, titles,rank:rank.overallRank,stableAchievements:st.progression.earned.length===earnedCount};
    }''')
    assert encounters['started'] and encounters['blocked']=='objectives_incomplete'
    assert encounters['dungeon'] and encounters['dungeonXp']==25 and encounters['level']
    assert encounters['unlocked'] and encounters['bossStart'] and encounters['boss'] and encounters['bossXp']==50
    assert encounters['duplicate']=='completed'
    assert 'first_dungeon' in encounters['earned'] and 'first_boss' in encounters['earned']
    assert 'gate_explorer' in encounters['titles'] and 'boss_slayer' in encounters['titles']
    assert encounters['rank'] in ['E','D','C','B','A','S'] and encounters['stableAchievements']
    print('PASS dungeon/boss gating + objective lock + one-time XP + achievements/titles/rank stability')

    schedule = page.evaluate('''() => {
      const now=new Date(), today=PA.util.dateKey(now);
      const target=new Date(now); target.setDate(target.getDate()+1);
      const targetDate=PA.util.dateKey(target);
      const st=PA.schema.fresh(now);
      const g=PA.engine.addGoal(st,'عنوان لا يتغير','وصف ثابت لا يتغير',targetDate);
      const m=PA.engine.addMilestone(st,g.id,'مرحلة ثابتة','وصف المرحلة الثابت',targetDate);
      const before={id:st.goals[0].id,title:st.goals[0].title,description:st.goals[0].description,status:st.goals[0].status,milestoneId:st.goals[0].milestones[0].id,milestoneTitle:st.goals[0].milestones[0].title,milestoneDescription:st.goals[0].milestones[0].description,milestoneStatus:st.goals[0].milestones[0].status};
      const built=PA.adaptive.buildProposal(st,{context:'low',sleepHours:4,energy:1,stress:5,focus:2,availableMinutes:60},now);
      const changeCount=built.ok?built.proposal.scheduleChanges.length:0;
      const applied=built.ok?PA.adaptive.approveProposal(st,now):{ok:false,reason:built.reason};
      return {changeCount,applied,goal:st.goals[0],before};
    }''')
    assert schedule['changeCount'] == 2 and schedule['applied']['ok']
    assert schedule['goal']['id'] == schedule['before']['id']
    assert schedule['goal']['status'] == schedule['before']['status']
    assert schedule['goal']['milestones'][0]['id'] == schedule['before']['milestoneId']
    assert schedule['goal']['milestones'][0]['status'] == schedule['before']['milestoneStatus']
    assert schedule['goal']['title'] == schedule['before']['title']
    assert schedule['goal']['description'] == schedule['before']['description']
    assert schedule['goal']['milestones'][0]['title'] == schedule['before']['milestoneTitle']
    assert schedule['goal']['milestones'][0]['description'] == schedule['before']['milestoneDescription']
    print('PASS adaptive approval changes only due dates; goal and milestone identities/text stay fixed')

    task_scaling = page.evaluate('''() => {
      const st=PA.schema.fresh(new Date('2026-11-15T12:00:00Z'));
      PA.development.normalize(st);
      const low=PA.development.generateAdaptiveTask('learning','2026-11-15',0,20,'normal');
      const mid=PA.development.generateAdaptiveTask('learning','2026-11-15',0,60,'normal');
      const high=PA.development.generateAdaptiveTask('learning','2026-11-15',0,90,'normal');
      const constrained=PA.development.generateAdaptiveTask('learning','2026-11-15',0,100,'low');
      return {tiers:[low.adaptiveTier,mid.adaptiveTier,high.adaptiveTier,constrained.adaptiveTier],xp:[low.xp,mid.xp,high.xp],steps:[low.steps.length,mid.steps.length,high.steps.length],scores:[low.diagnosticScore,mid.diagnosticScore,high.diagnosticScore]};
    }''')
    assert task_scaling['tiers'] == [1,2,3,1]
    assert task_scaling['xp'][0] < task_scaling['xp'][1] < task_scaling['xp'][2]
    assert task_scaling['steps'][2] > task_scaling['steps'][1]
    assert task_scaling['scores'] == [20,60,90]
    print('PASS diagnostic score scales task tier, XP and steps; low-energy mode caps challenge')

    page.locator('.tab[data-view="development"]').click()
    page.locator('#development [data-action="startDiagnostic"]').click()
    page.wait_for_timeout(150)
    assert '/5' in page.locator('#diagnosticPanel').inner_text()
    first = page.evaluate('''() => { const q=PA.development.currentDiagnosticQuestion(PA.app.getState()); return {id:q.question.id, fp:q.question.fingerprint, diff:q.difficulty, total:q.total, track:q.trackId}; }''')
    assert first['total'] == 3 and first['diff'] == 2
    print('PASS adaptive diagnostic starts at level 2/5 with 3 questions per track')

    # Complete one full six-track assessment, choosing the highest-scoring option each time.
    count = 0
    seen = []
    while page.locator('#diagnosticPanel [data-action="answerDiagnostic"]').count() and count < 30:
        current = page.evaluate('''() => { const q=PA.development.currentDiagnosticQuestion(PA.app.getState()); const max=Math.max(...q.question.s); return {choice:q.question.s.indexOf(max), fp:q.question.fingerprint, diff:q.difficulty}; }''')
        seen.append(current['fp'])
        page.locator(f'#diagnosticPanel [data-action="answerDiagnostic"][data-choice="{current["choice"]}"]').click()
        page.wait_for_timeout(20)
        count += 1
    assert count == 18, f'expected 18 questions, got {count}'
    summary = page.evaluate('''() => PA.development.diagnosticSummary(PA.app.getState())''')
    assert len(summary) == 6 and all(x['questionCount'] == 3 for x in summary)
    assert len(seen) == len(set(seen)), 'duplicate fingerprint within one assessment'
    print('PASS adaptive branching + 18 answers + six summaries + no within-run repeats')

    # A second assessment should avoid recently used questions.
    page.locator('#development [data-action="startDiagnostic"]').click()
    page.wait_for_timeout(100)
    second_seen = []
    count2 = 0
    while page.locator('#diagnosticPanel [data-action="answerDiagnostic"]').count() and count2 < 30:
        current = page.evaluate('''() => { const q=PA.development.currentDiagnosticQuestion(PA.app.getState()); const max=Math.max(...q.question.s); return {choice:q.question.s.indexOf(max), fp:q.question.fingerprint}; }''')
        second_seen.append(current['fp'])
        page.locator(f'#diagnosticPanel [data-action="answerDiagnostic"][data-choice="{current["choice"]}"]').click()
        page.wait_for_timeout(10)
        count2 += 1
    assert count2 == 18
    assert not (set(seen) & set(second_seen)), 'recent question repeated across adjacent runs'
    print('PASS recent-question rotation across repeated assessments')

    # Daily proposal must wait for approval.
    before = page.evaluate('''() => ({tasks:PA.app.getState().tasks.length, goal:PA.app.getState().goals.map(g=>({id:g.id,title:g.title,description:g.description,targetDate:g.targetDate}))})''')
    page.locator('#development [data-action="analyzeDay"]').click()
    page.wait_for_timeout(120)
    after_proposal = page.evaluate('''() => ({tasks:PA.app.getState().tasks.length, status:PA.app.getState().adaptive?.proposal?.status || PA.app.getState().development?.adaptive?.proposal?.status || null})''')
    assert after_proposal['tasks'] == before['tasks'], 'proposal changed tasks before approval'
    assert page.locator('#development [data-action="approvePlan"]').count() == 1
    page.locator('#development [data-action="approvePlan"]').click()
    page.wait_for_timeout(150)
    after_approval = page.evaluate('''() => PA.app.getState().tasks.length''')
    assert after_approval >= before['tasks']
    print('PASS adaptive plan waits for explicit approval')

    # Create a main goal and a side task, then verify encounters and backup UI.
    page.locator('.tab[data-view="goals"]').click()
    page.locator('#goalTitleInput').fill('هدف اختبار التوافق')
    page.locator('#goalDescriptionInput').fill('وصف ثابت للاختبار')
    page.locator('#goalTargetDateInput').fill('2026-12-31')
    page.locator('[data-action="addGoal"]').click()
    page.wait_for_timeout(120)
    assert 'هدف اختبار التوافق' in page.locator('#goalList').inner_text()

    page.locator('.tab[data-view="quests"]').click()
    page.locator('#newKind').select_option('side')
    page.locator('#newTitle').fill('مهمة جانبية للاختبار')
    page.locator('#newDuration').fill('15')
    page.locator('[data-action="addTask"]').click()
    page.wait_for_timeout(120)
    assert 'مهمة جانبية للاختبار' in page.locator('#sideTasks').inner_text()

    page.locator('.tab[data-view="encounters"]').click()
    page.wait_for_timeout(120)
    assert page.locator('#dungeonCatalog .encounter-card').count() == 3
    assert page.locator('#bossCatalog .encounter-card').count() == 3
    page.locator('.tab[data-view="settings"]').click()
    page.wait_for_timeout(150)
    assert page.locator('#backupList').inner_text().strip() != ''
    assert not errors, errors
    print('PASS goals + side tasks + 3 dungeons + 3 bosses + backup view')
    print('PASS browser errors: 0')
    browser.close()
