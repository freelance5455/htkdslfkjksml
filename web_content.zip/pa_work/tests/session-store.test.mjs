import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createDiagnosticSessionStore } from '../diagnostic-session-store.mjs';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pa-session-store-'));
const file = path.join(dir, 'sessions.json');
const key = 'test-only-long-encryption-secret';
test('diagnostic sessions survive store recreation and remain encrypted at rest', () => {
  const first = createDiagnosticSessionStore(file, { encryptionKey:key });
  first.set('session-a', {track:'learning',createdAt:Date.now(),index:2,results:[],current:{correctIndex:1}});
  const raw = fs.readFileSync(file, 'utf8');
  assert.match(raw, /aes-256-gcm/);
  assert.doesNotMatch(raw, /session-a|correctIndex|learning/);
  const second = createDiagnosticSessionStore(file, { encryptionKey:key });
  assert.equal(second.get('session-a').current.correctIndex, 1);
  assert.equal(second.get('session-a').track, 'learning');
});
test('encrypted store refuses to open without its key', () => {
  assert.throws(() => createDiagnosticSessionStore(file), /DIAGNOSTIC_STORE_KEY_required_to_decrypt/);
});
test('expired sessions are pruned after reload', () => {
  const oldFile = path.join(dir, 'expired.json');
  const first = createDiagnosticSessionStore(oldFile, { encryptionKey:key, now:()=>100000, ttlMs:1000 });
  first.set('old', {track:'learning',createdAt:100000,index:0,results:[]});
  const second = createDiagnosticSessionStore(oldFile, { encryptionKey:key, now:()=>102000, ttlMs:1000 });
  assert.equal(second.get('old'), undefined);
});
