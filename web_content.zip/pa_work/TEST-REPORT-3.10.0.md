# Player Awakening 3.10.0 — Test Report

Date: 2026-11-16

## Scope

This release adds durable adaptive-diagnostic session storage on the server. Sessions survive process restarts within the existing 30-minute session lifetime. The store uses atomic file replacement, restrictive file permissions, expiry pruning, and a 500-session cap. AES-256-GCM encryption at rest is supported through `DIAGNOSTIC_STORE_KEY` and is mandatory when `NODE_ENV=production`.

The player's main profile remains browser-local using IndexedDB with localStorage fallback. No cloud profile synchronization or multi-user identity system is introduced in this release.

## Automated results

`npm run test:all` completed successfully.

- Node gateway and storage tests: 18 passed, 0 failed.
- Static integrity checks: passed; original source SHA-256 unchanged; manifest and PWA assets present; 13 inline JavaScript blocks parse.
- PWA tests: passed; service-worker shell cache lifecycle validated and API responses remain outside the cache.
- Browser regression suite: passed; navigation, migrations, XP/coins separation, backup/restore, progression, adaptive diagnostics, adaptive plans, and gameplay checks passed; zero browser errors.
- AI UI suite: passed with mocked provider responses; approval gates, server-scored diagnostic flow, history persistence, weekly plan approval, evidence evaluation save, and no premature XP were verified.
- Diagnostic session store tests: restart persistence, AES-256-GCM ciphertext at rest, missing-key rejection, and TTL pruning passed.

## Security and operation notes

- `OPENAI_API_KEY` remains server-side only and is not embedded in the HTML or release archive.
- Set a separate long random `DIAGNOSTIC_STORE_KEY` in the hosting provider's secret manager. Do not reuse or share it. Losing it makes encrypted session data unreadable.
- `APP_ACCESS_TOKEN` remains a shared private-deployment access gate, not individual user authentication.
- In local development without `DIAGNOSTIC_STORE_KEY`, diagnostic sessions persist unencrypted and the server warns. Do not expose this mode publicly.
- `.data/` is excluded from version control and release archives; it contains runtime session data.

## Not verified / still required before final production sign-off

- No live OpenAI request was made because no API key was configured in this environment.
- No production hosting, TLS domain, secret manager, or live deployment was configured.
- No physical Android/iOS device test was performed.
- Cross-device cloud synchronization and per-user accounts are not included.
- The browser-local player database remains the source of truth for player profile data; users should continue exporting backups before replacing versions or changing devices.

## Verdict

3.10.0 passes all automated tests available in this environment. It is a release candidate for local/private deployment after configuring `OPENAI_API_KEY`, `APP_ACCESS_TOKEN`, and `DIAGNOSTIC_STORE_KEY`. It is **not yet certified as a fully production-complete live AI service** until live-provider, hosting, and real-device checks are completed.
