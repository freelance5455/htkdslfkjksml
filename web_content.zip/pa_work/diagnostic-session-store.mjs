import fs from 'node:fs';
import path from 'node:path';
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';

const SESSION_TTL_MS = 30 * 60 * 1000;
const MAX_SESSIONS = 500;

export function createDiagnosticSessionStore(filePath, { now = () => Date.now(), ttlMs = SESSION_TTL_MS, maxSessions = MAX_SESSIONS, encryptionKey = '' } = {}) {
  const key = encryptionKey ? createHash('sha256').update(encryptionKey).digest() : null;
  const sessions = new Map();
  function persist() {
    fs.mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
    const tmp = `${filePath}.${process.pid}.tmp`;
    const plain = JSON.stringify({ version: 1, savedAt: new Date(now()).toISOString(), sessions: [...sessions.entries()] });
    let payload = plain;
    if (key) { const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', key, iv); const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]); payload = JSON.stringify({ version: 2, algorithm: 'aes-256-gcm', iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), data: encrypted.toString('base64') }); }
    const fd = fs.openSync(tmp, 'w', 0o600);
    try { fs.writeFileSync(fd, payload, 'utf8'); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, filePath);
    try { fs.chmodSync(filePath, 0o600); } catch {}
  }
  function prune() {
    const t = now();
    let changed = false;
    for (const [id, session] of sessions) if (!session || !Number.isFinite(session.createdAt) || t - session.createdAt > ttlMs) { sessions.delete(id); changed = true; }
    while (sessions.size > maxSessions) { sessions.delete(sessions.keys().next().value); changed = true; }
    if (changed) persist();
  }
  function load() {
    try {
      let parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (parsed?.version === 2 && parsed.algorithm === 'aes-256-gcm') {
        if (!key) throw new Error('DIAGNOSTIC_STORE_KEY_required_to_decrypt');
        const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(parsed.iv, 'base64'));
        decipher.setAuthTag(Buffer.from(parsed.tag, 'base64'));
        parsed = JSON.parse(Buffer.concat([decipher.update(Buffer.from(parsed.data, 'base64')), decipher.final()]).toString('utf8'));
      }
      if (parsed?.version !== 1 || !Array.isArray(parsed.sessions)) return;
      for (const pair of parsed.sessions) {
        if (!Array.isArray(pair) || pair.length !== 2 || typeof pair[0] !== 'string' || !pair[1] || typeof pair[1] !== 'object') continue;
        const s = pair[1];
        if (!Number.isFinite(s.createdAt) || typeof s.track !== 'string' || !Number.isInteger(s.index) || !Array.isArray(s.results)) continue;
        sessions.set(pair[0], s);
      }
      prune();
    } catch (error) { if (error.code !== 'ENOENT') throw new Error(`diagnostic_session_store_unreadable: ${error.message}`); }
  }
  load();
  return {
    get size() { return sessions.size; },
    get(id) { prune(); return sessions.get(id); },
    set(id, value) { prune(); sessions.set(id, value); prune(); persist(); return this; },
    delete(id) { const result = sessions.delete(id); if (result) persist(); return result; },
    prune,
    close() { persist(); }
  };
}
