-- YOUTU v9: crear/ajustar historial y sus permisos.
create table if not exists public.watch_history (
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  watched_at timestamptz not null default now(),
  primary key (user_id, video_id)
);
alter table public.watch_history add column if not exists watched_at timestamptz not null default now();
alter table public.watch_history enable row level security;
drop policy if exists "Users read own watch history" on public.watch_history;
create policy "Users read own watch history" on public.watch_history for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users add own watch history" on public.watch_history;
create policy "Users add own watch history" on public.watch_history for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users update own watch history" on public.watch_history;
create policy "Users update own watch history" on public.watch_history for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update on public.watch_history to authenticated;
