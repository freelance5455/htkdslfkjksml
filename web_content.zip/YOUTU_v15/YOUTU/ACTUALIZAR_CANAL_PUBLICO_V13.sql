-- YOUTU v13: permitir ver perfiles públicos y videos públicos de otros canales.
-- Ejecuta una sola vez en Supabase > SQL Editor > New query.
alter table public.profiles enable row level security;
alter table public.videos enable row level security;

drop policy if exists "YOUTU v13 perfiles visibles" on public.profiles;
create policy "YOUTU v13 perfiles visibles"
on public.profiles for select to authenticated
using (true);

drop policy if exists "YOUTU v13 videos publicos visibles" on public.videos;
create policy "YOUTU v13 videos publicos visibles"
on public.videos for select to authenticated
using (visibility = 'public' and status = 'approved');

grant select on public.profiles to authenticated;
grant select on public.videos to authenticated;
