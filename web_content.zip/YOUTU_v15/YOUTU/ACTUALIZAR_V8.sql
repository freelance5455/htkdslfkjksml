-- YOUTU v8: tabla para dislikes.
create table if not exists public.video_dislikes (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(video_id,user_id)
);
alter table public.video_dislikes enable row level security;
drop policy if exists "Dislikes are readable" on public.video_dislikes;
create policy "Dislikes are readable" on public.video_dislikes for select to authenticated using (true);
drop policy if exists "Users add own dislikes" on public.video_dislikes;
create policy "Users add own dislikes" on public.video_dislikes for insert to authenticated with check (auth.uid()=user_id);
drop policy if exists "Users remove own dislikes" on public.video_dislikes;
create policy "Users remove own dislikes" on public.video_dislikes for delete to authenticated using (auth.uid()=user_id);
grant select,insert,delete on public.video_dislikes to authenticated;
