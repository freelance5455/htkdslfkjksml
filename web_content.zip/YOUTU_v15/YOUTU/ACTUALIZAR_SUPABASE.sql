-- YOUTU: actualizar el flujo de denuncias a 50 reportes.
-- Ejecutar en Supabase > SQL Editor > New query.
-- Publicación automática: la app nueva inserta status='approved'.
-- Al llegar a 50 reportes únicos, se cambia a 'under_review' y desaparece del feed.

create or replace function public.report_video(
  p_video_id uuid,
  p_reason text default 'Otro'
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  total integer;
begin
  if auth.uid() is null then
    raise exception 'Debes iniciar sesión para reportar.';
  end if;

  if not exists (
    select 1 from public.videos
    where id = p_video_id
      and visibility = 'public'
      and status = 'approved'
  ) then
    raise exception 'El video no está disponible para reportes.';
  end if;

  insert into public.video_reports(video_id, reporter_id, reason)
  values (p_video_id, auth.uid(), left(coalesce(p_reason, 'Otro'), 120))
  on conflict (video_id, reporter_id) do nothing;

  select count(*)::integer into total
  from public.video_reports
  where video_id = p_video_id;

  if total >= 50 then
    update public.videos
    set status = 'under_review'
    where id = p_video_id
      and status = 'approved';
  end if;

  return total;
end;
$$;

revoke all on function public.report_video(uuid, text) from public;
grant execute on function public.report_video(uuid, text) to authenticated;
