# Melodrift

Drift into your sound. A music app made of plain HTML, CSS and JavaScript (no build step).
Songs are real tracks looked up by artist and title in the Apple Music catalogue (iTunes Search API) and played as 30-second previews, so the phone needs an internet connection.

```
melodrift-app/
  www/                  the app (open www/index.html in a browser to try it)
    index.html
    css/style.css
    js/app.js
    manifest.webmanifest
    sw.js               caches the app files only (not songs)
    icons/              192, 512 and maskable icons
  assets/               source images for the Android icon and splash screen
  capacitor.config.json app id: com.melodrift.app
  package.json
```

## Option 1: build an APK with Capacitor (recommended)

You need: Node 18 or newer, JDK 17 and Android Studio (it installs the Android SDK).

```bash
cd melodrift-app
npm install
npx cap add android        # creates the android/ project once
npm run icons              # optional: app icon and splash screen from assets/
npx cap sync android       # copies www/ into the Android project
npx cap open android       # opens Android Studio
```

In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is saved at `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to a phone and install it.

For the Play Store use **Build > Generate Signed Bundle / APK** and create a signing key.

After you change anything in `www/`, run `npx cap sync android` again.

## Option 2: no Android Studio (PWABuilder)

1. Upload the `www/` folder to any HTTPS host (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Open https://www.pwabuilder.com, enter the site address and choose **Package for stores > Android**.
3. Download the APK/AAB it generates.

## Try it on your computer

```bash
npm run serve        # then open http://localhost:8080
```

## Good to know

- Songs, search and cover art need internet. The app screen itself also works offline once installed.
- Previews are 30 seconds. Full songs need a streaming service with a licence.
- Voice search only appears where the browser supports it (Chrome on desktop, some Android browsers). Inside the Capacitor WebView it is hidden automatically.
- Music may stop when the app goes to the background in a WebView app. Keeping it playing needs an extra Android foreground-service plugin.
- The Android back button closes the player or the playlist sheet first, then leaves the app.
- Uploaded songs in Artist Corner stay on the device and clear when the app is closed.
- The heading font (Exo 2) loads from Google Fonts when online and falls back to a system font otherwise.
