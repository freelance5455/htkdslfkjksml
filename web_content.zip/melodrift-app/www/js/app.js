"use strict";
/* ---------- helpers ---------- */
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const store={
  get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch{return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}
};
const fmt=s=>{s=Math.max(0,Math.floor(s||0));return Math.floor(s/60)+":"+String(s%60).padStart(2,"0")};

const ICON={
  home:'<path d="M3 11l9-8 9 8M5 10v10h14V10"/>',
  mood:'<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/>',
  discover:'<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  library:'<path d="M4 4v16M9 4v16M14 5.5l5 14.5"/>',
  mic:'<path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM5 11a7 7 0 0 0 14 0M12 18v3"/>',
  moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5z"/>',
  play:'<path d="M8 5v14l11-7z"/>', pause:'<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>',
  next:'<path d="M6 5l9 7-9 7zM17 5h2v14h-2z"/>', prev:'<path d="M18 5l-9 7 9 7zM5 5h2v14H5z"/>',
  heart:'<path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  shuffle:'<path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
  down:'<path d="M6 9l6 6 6-6"/>', back:'<path d="M15 5l-7 7 7 7"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  timer:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6"/>',
  dots:'<circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>', upload:'<path d="M12 16V4M7 9l5-5 5 5M5 20h14"/>'
};
const FILLED=new Set(["play","pause","next","prev","dots"]);
const ic=(n,extra="")=>`<svg viewBox="0 0 24 24" class="ic${FILLED.has(n)?" f":""} ${extra}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">${ICON[n]}</svg>`;
const GLYPH='<svg viewBox="0 0 50 40" aria-hidden="true"><rect x="2" y="14" width="7" height="12" rx="3.5" fill="currentColor"/><rect x="12" y="7" width="7" height="26" rx="3.5" fill="currentColor"/><rect x="22" y="0" width="7" height="40" rx="3.5" fill="#FFB033"/><rect x="32" y="8" width="7" height="24" rx="3.5" fill="currentColor"/><rect x="42" y="14" width="7" height="12" rx="3.5" fill="currentColor"/></svg>';
const LOGO='<svg class="logo" viewBox="0 0 1024 1024" role="img" aria-label="Melodrift"><rect width="1024" height="1024" rx="240" fill="url(#lg)"/><path d="M240 0h544a240 240 0 0 1 240 240v120C800 450 224 450 0 360V240A240 240 0 0 1 240 0z" fill="#fff" opacity=".28"/><rect x="248" y="392" width="80" height="240" rx="40" fill="#fff"/><rect x="356" y="302" width="80" height="420" rx="40" fill="#fff"/><rect x="472" y="212" width="80" height="600" rx="40" fill="url(#lgo)"/><rect x="588" y="312" width="80" height="400" rx="40" fill="#fff"/><rect x="696" y="392" width="80" height="240" rx="40" fill="#fff"/></svg>';


const WM=()=>`<svg class="wm" viewBox="0 0 560 124" role="img" aria-label="Melodrift"><g transform="translate(26 0) skewX(-12)" font-family="'Exo 2',Impact,'Arial Black',sans-serif" font-weight="900" font-size="96" stroke-linejoin="round"><text x="14" y="96" textLength="500" lengthAdjust="spacingAndGlyphs" fill="none" stroke="#06143A" stroke-width="20">Melodrift</text><text x="14" y="96" textLength="500" lengthAdjust="spacingAndGlyphs" fill="none" stroke="url(#wmGold)" stroke-width="11">Melodrift</text><text x="14" y="96" textLength="500" lengthAdjust="spacingAndGlyphs" fill="url(#wmFill)">Melodrift</text></g></svg>`;
const MICRO="MELODRIFT LIVE SESSION AT MIDNIGHT · DRIFT INTO YOUR SOUND · 30-SECOND PREVIEWS FROM THE APPLE MUSIC CATALOGUE · ";
document.documentElement.style.setProperty("--micro",JSON.stringify(MICRO.repeat(6)));
function microTile(color,fs){
  const lh=fs+3,lines=16,W=720;let t="";
  for(let i=0;i<lines;i++){const off=(i*41)%MICRO.length;t+=`<text x="${-(i%3)*14}" y="${(i+1)*lh}">${esc((MICRO.slice(off)+MICRO.repeat(8)).slice(0,Math.ceil(W/(fs*.55))))}</text>`}
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${lines*lh+3}"><g font-family="Tahoma,Verdana,sans-serif" font-weight="700" font-size="${fs}" fill="${color}">${t}</g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
}
document.documentElement.style.setProperty("--micro-tile-w",microTile("rgba(255,255,255,.11)",8));

/* ---------- the songs (real tracks; looked up by artist and title) ---------- */
const MIXES={
  chill:{name:"Slow Tide",label:"Chill",blurb:"Easy, warm and unhurried.",g:["#6CC3FF","#1D6BFF"],ink:"#06143A",bars:[.4,.7,1,.6,.35],keys:[
    "Khruangbin|Maria También","Bon Iver|Holocene","Sade|By Your Side","Tom Misch|Movie","Jack Johnson|Better Together","Norah Jones|Don't Know Why","Men I Trust|Show Me How","Cigarettes After Sex|Apocalypse"]},
  focus:{name:"Deep Work",label:"Focus",blurb:"Steady, wordless and calm.",g:["#1D6BFF","#0A2A7A"],bars:[.3,.5,.8,.5,.3],keys:[
    "Brian Eno|An Ending (Ascent)","Ludovico Einaudi|Nuvole Bianche","Nujabes|Aruarian Dance","Tycho|A Walk","Bonobo|Kerala","Jon Hopkins|Open Eye Signal","Hans Zimmer|Time","Explosions in the Sky|Your Hand in Mine"]},
  party:{name:"Neon Waves",label:"Party",blurb:"Turn it up and move.",g:["#FFC247","#FF6A00"],ink:"#06143A",bars:[.9,.5,1,.7,.95],keys:[
    "Dua Lipa|Levitating","Daft Punk|Get Lucky","Calvin Harris|Summer","Mark Ronson|Uptown Funk","The Weeknd|Blinding Lights","Justin Timberlake|Can't Stop the Feeling!","Lizzo|About Damn Time","DNCE|Cake By The Ocean"]},
  run:{name:"Tempo",label:"Run",blurb:"Songs that keep your pace.",g:["#C6FF4A","#19C9B0"],ink:"#06143A",bars:[.5,.8,1,.9,.6],keys:[
    "Eminem|Lose Yourself","Kanye West|Stronger","Survivor|Eye of the Tiger","Imagine Dragons|Believer","Queen|Don't Stop Me Now","Avicii|Wake Me Up","Foo Fighters|The Pretender","Fall Out Boy|Centuries"]},
  happy:{name:"Sunny Side",label:"Happy",blurb:"Songs that lift the room.",g:["#FFE95C","#FF9E1B"],ink:"#06143A",bars:[.6,.9,.7,1,.5],keys:[
    "Pharrell Williams|Happy","Earth, Wind & Fire|September","Katrina & The Waves|Walking On Sunshine","ABBA|Dancing Queen","Bruno Mars|Treasure","Taylor Swift|Shake It Off","The Beach Boys|Good Vibrations","Electric Light Orchestra|Mr. Blue Sky"]},
  heartbreak:{name:"After the Rain",label:"Heartbreak",blurb:"For when you need to feel it.",g:["#1B3C9E","#7A5BFF"],bars:[.7,.4,.9,.35,.6],keys:[
    "Adele|Someone Like You","Billie Eilish|when the party's over","Radiohead|Creep","Sam Smith|Stay With Me","Lewis Capaldi|Someone You Loved","Johnny Cash|Hurt","Coldplay|Fix You","Gotye|Somebody That I Used To Know"]},
  road:{name:"Midnight Drive",label:"Road trip",blurb:"Windows down, volume up.",g:["#0A2A7A","#19A3E8"],bars:[.35,.6,.9,1,.7],keys:[
    "Tom Petty|Free Fallin'","Fleetwood Mac|Go Your Own Way","Journey|Don't Stop Believin'","Bruce Springsteen|Born to Run","Queen|Bohemian Rhapsody","Toto|Africa","John Denver|Take Me Home, Country Roads","The Killers|Mr. Brightside"]},
  sleep:{name:"Quiet Hours",label:"Sleep",blurb:"Soft sounds to fall asleep to.",g:["#06123A","#2B49B8"],bars:[.2,.35,.5,.35,.2],keys:[
    "Max Richter|On the Nature of Daylight","Claude Debussy|Clair de Lune","Erik Satie|Gymnopédie No. 1","Brian Eno|1/1","Nils Frahm|Says","Ólafur Arnalds|Near Light","Hania Rani|Esja","Frédéric Chopin|Nocturne in E-Flat Major, Op. 9 No. 2"]}
};
const MOODS=["chill","focus","party","run","happy","heartbreak"];
const GENRES={
  Pop:["Billie Eilish|bad guy","Olivia Rodrigo|drivers license","Harry Styles|As It Was","Ed Sheeran|Shape of You","Ariana Grande|7 rings","Lorde|Royals"],
  Rock:["Arctic Monkeys|Do I Wanna Know?","Nirvana|Smells Like Teen Spirit","Red Hot Chili Peppers|Can't Stop","Pink Floyd|Comfortably Numb","Alice in Chains|Man in the Box","The Strokes|Last Nite"],
  "Hip-hop":["Kendrick Lamar|HUMBLE.","Tyler, The Creator|EARFQUAKE","OutKast|Ms. Jackson","Drake|Hotline Bling","Lauryn Hill|Doo Wop (That Thing)","Travis Scott|SICKO MODE"],
  Electronic:["Daft Punk|One More Time","Justice|D.A.N.C.E.","Disclosure|Latch","Skrillex|Scary Monsters and Nice Sprites","Kavinsky|Nightcall","Röyksopp|Eple"],
  Jazz:["Miles Davis|So What","Dave Brubeck|Take Five","John Coltrane|My Favorite Things","Nina Simone|Feeling Good","Ella Fitzgerald|Summertime","Casiopea|Asayake"],
  Latin:["Bad Bunny|Tití Me Preguntó","Shakira|Hips Don't Lie","Luis Fonsi|Despacito","Rosalía|DESPECHÁ","J Balvin|Mi Gente","Karol G|TUSA"]
};
const ARTISTS=["Faye Webster|Kingston","Mac DeMarco|Chamber of Reflection","beabadoobee|Coffee","Clairo|Sofia","Rex Orange County|Sunflower","girl in red|we fell in love in october","Wallows|Are You Bored Yet?","Omar Apollo|Evergreen"];

/* ---------- state ---------- */
let cache=new Map(Object.entries(store.get("md.cache.v1",{})));
let liked=store.get("md.liked",[]);
const defaultLists=()=>[
  {id:"study",name:"Study",keys:MIXES.focus.keys.slice()},
  {id:"road",name:"Road Trip",keys:MIXES.road.keys.slice()},
  {id:"gym",name:"Gym Mix",keys:MIXES.run.keys.slice()},
  {id:"sleep",name:"Sleep",keys:MIXES.sleep.keys.slice()}
];
let lists=store.get("md.lists",null)||defaultLists();
let recent=store.get("md.recent",[]);
const S={view:"home",arg:null,genre:"Pop",mood:"chill",sleepTab:"sleep",searchSeq:0,uploads:0,deleteArm:null};
let queue=[],qi=0,cur=null,shuffleOn=false;
const LISTS={};let listSeq=0;

let saveT;
function saveCache(){clearTimeout(saveT);saveT=setTimeout(()=>{
  const o={};let n=0;
  for(const [k,v] of [...cache.entries()].reverse()){ if(k.startsWith("up:")) continue; if(n++>700) break; o[k]=v; }
  store.set("md.cache.v1",o);
},400)}
const saveLists=()=>store.set("md.lists",lists), saveLiked=()=>store.set("md.liked",liked), saveRecent=()=>store.set("md.recent",recent);

/* ---------- catalogue lookup ---------- */
const norm=s=>String(s).normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/&/g," and ").replace(/[^a-z0-9 ]+/g," ").replace(/\s+/g," ").trim();
const BAD=/\b(live|remix|karaoke|tribute|instrumental|cover|lullaby)\b/;
function pick(results,artist,title){
  const na=norm(artist), nt=norm(title);
  const aw=na.split(" ").filter(w=>w.length>2&&w!=="the");
  const tw=nt.split(" ").filter(w=>w.length>1).slice(0,3);
  let best=null,bs=-9;
  for(const r of results){
    if(!r.previewUrl) continue;
    const ra=norm(r.artistName), rt=norm(r.trackName);
    let s=0;
    if(aw.length?aw.every(w=>ra.includes(w)):ra.includes(na)) s+=4; else if(aw.some(w=>ra.includes(w))) s+=1;
    if(tw.every(w=>rt.includes(w))) s+=4;
    if(rt===nt||rt.startsWith(nt)) s+=1;
    if(BAD.test(rt)&&!BAD.test(nt)) s-=3;
    if(s>bs){bs=s;best=r}
  }
  return bs>=8?best:null;
}
const toTrack=(r,key)=>({key,id:r.trackId,title:r.trackName,artist:r.artistName,album:r.collectionName||"",art:r.artworkUrl100||"",preview:r.previewUrl,ms:r.trackTimeMillis||0});
const artUrl=(t,px)=>t.art?t.art.replace(/\/\d+x\d+(bb)?\.(jpg|png)$/,`/${px}x${px}bb.$2`):"";

let failStreak=0;
async function itunes(p){
  if(!navigator.onLine) throw new Error("offline");
  const url="https://itunes.apple.com/search?"+new URLSearchParams({media:"music",entity:"song",country:"US",...p});
  let err;
  const tries=failStreak>=2?1:4;
  for(let i=0;i<tries;i++){
    try{const r=await fetch(url); if(r.ok){failStreak=0;return await r.json()} err=new Error("HTTP "+r.status)}catch(e){err=e}
    if(i<tries-1) await wait(1500*(i+1));
  }
  failStreak++; throw err;
}
/* small queue so we stay under the catalogue's rate limit */
const Q=[];let active=0;
function enqueue(fn,front){return new Promise((res,rej)=>{(front?Q.unshift.bind(Q):Q.push.bind(Q))({fn,res,rej});pump()})}
function pump(){while(active<2&&Q.length){const t=Q.shift();active++;t.fn().then(t.res,t.rej).finally(()=>{active--;setTimeout(pump,180)})}}
const inflight=new Map();
function resolveKey(key){
  if(cache.has(key)) return Promise.resolve(cache.get(key));
  if(inflight.has(key)) return inflight.get(key);
  const i=key.indexOf("|"); if(i<0) return Promise.resolve(null);
  const artist=key.slice(0,i), title=key.slice(i+1);
  const p=enqueue(async()=>{
    const d=await itunes({term:artist+" "+title,limit:10});
    const r=pick(d.results||[],artist,title);
    const t=r?toTrack(r,key):null;
    cache.set(key,t);saveCache();return t;
  }).finally(()=>inflight.delete(key));
  inflight.set(key,p);return p;
}

/* ---------- views ---------- */
const main=$("#main"), app=$("#app"), audio=$("#audio");
function artHTML(t,px=120){return t&&t.art?`<img class="art" src="${esc(artUrl(t,px*2))}" alt="">`:`<div class="art ph">${GLYPH}</div>`}
const isLiked=k=>liked.includes(k);
function rowHTML(t,lid,i){
  const on=cur&&cur.key===t.key;
  return `<div class="row${on?" on":""}" data-slot="${i}" data-k="${esc(t.key)}">
    <button class="main" data-a="play" data-l="${lid}" data-i="${i}" aria-label="Play ${esc(t.title)} by ${esc(t.artist)}">
      <div class="cover sm">${artHTML(t,52)}</div>
      <div class="meta"><div class="t">${esc(t.title)}</div><div class="a">${esc(t.artist)}</div></div>
      <span class="eq" aria-hidden="true"><i></i><i></i><i></i></span>
    </button>
    <button class="ib like${isLiked(t.key)?" on":""}" data-a="like" data-key="${esc(t.key)}" aria-pressed="${isLiked(t.key)}" aria-label="Like ${esc(t.title)}">${ic("heart")}</button>
    <button class="ib" data-a="more" data-key="${esc(t.key)}" aria-label="Save ${esc(t.title)} to a playlist">${ic("plus")}</button>
  </div>`;
}
const skRow=i=>`<div class="row sk" data-slot="${i}" aria-hidden="true"><div class="cover sm"></div><div class="meta"><i></i><i></i></div></div>`;
const errRow=(i,k)=>`<div class="row err" data-slot="${i}"><button class="main" data-a="retry" data-i="${i}" data-key="${esc(k)}"><div class="meta"><div class="t">Couldn't load this song</div><div class="a">Tap to try again</div></div></button></div>`;

function renderList(host,keys,opts={}){
  const id="L"+(++listSeq);
  const L=LISTS[id]={keys,tracks:new Array(keys.length).fill(undefined)};
  host.dataset.list=id;
  host.innerHTML=keys.map((k,i)=>skRow(i)).join("");
  const live=()=>host.isConnected&&host.dataset.list===id;
  const slot=i=>host.querySelector(`[data-slot="${i}"]`);
  let failed=0;
  const load=(k,i)=>resolveKey(k).then(t=>{
    L.tracks[i]=t; if(!live()) return;
    const el=slot(i); if(!el) return;
    if(t) el.outerHTML=rowHTML(t,id,i); else el.remove();
  }).catch(()=>{
    L.tracks[i]=null;failed++; if(!live()) return;
    const el=slot(i); if(el) el.outerHTML=errRow(i,k);
  });
  const jobs=keys.map(load);
  L.reload=(i)=>{const el=slot(i);if(el)el.outerHTML=skRow(i);load(keys[i],i)};
  Promise.allSettled(jobs).then(()=>{
    if(!live()) return;
    if(failed&&failed===keys.length){
      host.innerHTML=`<div class="notice"><b>Can't reach the music catalogue</b>Check your internet connection, then <button data-a="retry-all" data-l="${id}" style="text-decoration:underline;font-weight:800">try again</button>.</div>`;
    }else if(!keys.length||!L.tracks.some(Boolean)&&!failed){
      host.innerHTML=`<div class="empty"><b>${opts.empty||"Nothing here yet"}</b>${opts.emptyHint||""}</div>`;
    }
  });
  (async()=>{
    for(let i=0;i<jobs.length;i++){
      await jobs[i];
      if(L.tracks[i]){ if(opts.autoplay&&live()) playFrom(id,i); break; }
    }
  })();
  return id;
}

const greeting=()=>{const h=new Date().getHours();return h<5?"Still up?":h<12?"Good morning":h<18?"Good afternoon":"Good evening"};
const hourPick=()=>{const h=new Date().getHours();return h<5?"sleep":h<11?"happy":h<17?"focus":h<22?"chill":"sleep"};
const bars=(m)=>`<span class="glyph" aria-hidden="true">${m.bars.map((h,i)=>`<i style="height:${Math.round(h*100)}%${i===2?";background:"+(m.ink?"#fff":"#FFB033"):""}"></i>`).join("")}</span>`;
const grad=m=>`background:linear-gradient(145deg,${m.g[0]},${m.g[1]});--faceink:${m.ink||"#fff"}`;

const VIEWS={
  home(){
    const pick=MIXES[hourPick()], pk=hourPick();
    const rec=recent.map(k=>cache.get(k)).filter(Boolean);
    main.innerHTML=`
      <div class="top">${LOGO}${WM()}<span class="sp"></span>
        <button class="ib" data-a="theme" aria-label="Switch between dark and light mode">${ic("sun")}</button></div>
      <h1>${greeting()}</h1>
      <p class="sub">What do you feel like right now?</p>
      <div class="chips" role="list">${MOODS.map(m=>`<button class="chip" role="listitem" data-a="go" data-view="mood" data-arg="${m}"><span class="dot" style="background:${MIXES[m].g[0]}"></span>${MIXES[m].label}</button>`).join("")}</div>
      <button class="hero" style="${grad(pick)};width:100%;text-align:left" data-a="go" data-view="mood" data-arg="${pk}" data-autoplay="1" aria-label="Play ${esc(pick.name)}">
        <span class="txt"><b>${esc(pick.name)}</b><span>${esc(pick.label)} mix picked for this time of day</span></span>
        <span class="go">${ic("play")}</span>
      </button>
      <section><h2>Made for you</h2>
        <div class="hscroll">${["party","road","chill","focus","run","happy","heartbreak"].map(k=>{const m=MIXES[k];return `<button class="tile" data-a="go" data-view="mood" data-arg="${k}"><div class="face" style="${grad(m)}">${bars(m)}<b>${esc(m.name)}</b></div><div class="cap">${esc(m.label)}</div></button>`}).join("")}</div>
      </section>
      ${rec.length?`<section><h2>Recently played</h2><div class="hscroll" id="rec"></div></section>`:`<section><h2>Find a song fast</h2><button class="search" data-a="go" data-view="discover" data-arg="focus" style="margin-top:2px">${ic("search")}<span class="ph">Search songs and artists</span></button></section>`}`;
    if(rec.length){
      const id="L"+(++listSeq);LISTS[id]={tracks:rec};
      $("#rec").innerHTML=rec.map((t,i)=>`<button class="tile" data-a="play" data-l="${id}" data-i="${i}" aria-label="Play ${esc(t.title)}"><div class="cover">${artHTML(t,148)}</div><div class="t">${esc(t.title)}</div><div class="a">${esc(t.artist)}</div></button>`).join("");
    }
  },
  mood(_,arg,opts={}){
    const k=MIXES[arg]?arg:S.mood; S.mood=k; const m=MIXES[k];
    main.innerHTML=`
      <h1>Mood Mix</h1><p class="sub">Pick a feeling, get a playlist.</p>
      <div class="chips">${MOODS.map(x=>`<button class="chip" data-a="go" data-view="mood" data-arg="${x}" aria-pressed="${x===k}">${MIXES[x].label}</button>`).join("")}</div>
      <div class="mixhead" style="${grad(m)}">${bars(m)}
        <h2>${esc(m.name)}</h2><p>${esc(m.blurb)}</p>
        <div class="actions"><button class="btn" data-a="playall" data-host="list">${ic("play")}Play</button><button class="btn ghost" data-a="shuffleall" data-host="list">${ic("shuffle")}Shuffle</button></div>
      </div>
      <div class="list" id="list" style="margin-top:14px"></div>`;
    renderList($("#list"),m.keys,{autoplay:!!opts.autoplay});
  },
  discover(_,arg){
    main.innerHTML=`
      <h1>Discover</h1><p class="sub">Search any song or artist, or browse a genre.</p>
      <form id="searchForm" class="search" role="search" style="margin-top:16px">${ic("search")}
        <input id="q" type="search" placeholder="Songs, artists" aria-label="Search songs and artists" autocomplete="off" enterkeyhint="search">
        <button type="button" class="ib" data-a="voice" id="voiceBtn" aria-label="Search by voice" hidden>${ic("mic")}</button></form>
      <div class="chips" id="genres">${Object.keys(GENRES).map(g=>`<button class="chip" data-a="genre" data-g="${esc(g)}" aria-pressed="${g===S.genre}">${esc(g)}</button>`).join("")}</div>
      <div id="resHead" class="sub" style="margin-top:18px"></div>
      <div class="list" id="results" style="margin-top:6px"></div>`;
    renderList($("#results"),GENRES[S.genre]);
    if(window.SpeechRecognition||window.webkitSpeechRecognition) $("#voiceBtn").hidden=false;
    if(arg==="focus") setTimeout(()=>$("#q").focus(),50);
  },
  library(){
    const lk=liked;
    main.innerHTML=`
      <h1>My Library</h1><p class="sub">Your playlists and liked songs.</p>
      <section style="margin-top:16px"><div class="list">
        <button class="row plrow" data-a="go" data-view="playlist" data-arg="liked"><span class="main"><span class="cover"><span class="lk">${ic("heart")}</span></span><span class="meta"><span class="t" style="display:block">Liked songs</span><span class="a" style="display:block">${lk.length} ${lk.length===1?"song":"songs"}</span></span></span></button>
        ${lists.map(l=>`<button class="row plrow" data-a="go" data-view="playlist" data-arg="${esc(l.id)}"><span class="main"><span class="cover">${mosaic(l)}</span><span class="meta"><span class="t" style="display:block">${esc(l.name)}</span><span class="a" style="display:block">${l.keys.length} ${l.keys.length===1?"song":"songs"}</span></span></span></button>`).join("")}
      </div>
      <form class="newform" data-form="newlist"><input class="field" name="n" placeholder="Name a new playlist" maxlength="40" aria-label="New playlist name" required><button class="btn sm" type="submit">Create</button></form></section>`;
  },
  playlist(_,arg){
    const isLikedList=arg==="liked";
    const l=isLikedList?{id:"liked",name:"Liked songs",keys:liked}:lists.find(x=>x.id===arg);
    if(!l){go("library");return}
    S.arg=arg;
    main.innerHTML=`
      <div class="top"><button class="ib" data-a="go" data-view="library" aria-label="Back to My Library">${ic("back")}</button><span class="word">My Library</span></div>
      <h1>${esc(l.name)}</h1><p class="sub">${l.keys.length} ${l.keys.length===1?"song":"songs"}</p>
      <div class="actions"><button class="btn" data-a="playall" data-host="list">${ic("play")}Play</button><button class="btn ghost" data-a="shuffleall" data-host="list">${ic("shuffle")}Shuffle</button>
        ${isLikedList?"":`<button class="btn ghost" data-a="del-list" data-id="${esc(l.id)}">${S.deleteArm===l.id?"Tap again to delete":"Delete"}</button>`}</div>
      <div class="list" id="list"></div>`;
    renderList($("#list"),l.keys.slice(),{empty:isLikedList?"No liked songs yet":"This playlist is empty",emptyHint:isLikedList?"Tap the heart on any song to keep it here.":"Tap + on any song to add it."});
  },
  artists(){
    const ups=[...cache.keys()].filter(k=>k.startsWith("up:"));
    main.innerHTML=`
      <h1>Artist Corner</h1><p class="sub">Indie artists on the rise, plus your own songs.</p>
      <label class="upload">${ic("upload")}<span><b>Upload your own song</b><small>MP3, M4A or WAV. It stays on this device and clears when you close the tab.</small></span>
        <input type="file" accept="audio/*" id="file"></label>
      ${ups.length?`<section><h2>Your uploads</h2><div class="list" id="ups"></div></section>`:""}
      <section><h2>On the rise</h2><div class="list" id="list"></div></section>`;
    if(ups.length) renderList($("#ups"),ups);
    renderList($("#list"),ARTISTS);
  },
  sleep(){
    const tab=S.sleepTab, m=MIXES[tab==="sleep"?"sleep":"focus"];
    main.innerHTML=`
      <h1>Sleep &amp; Focus</h1><p class="sub">Calm sounds for study and rest.</p>
      <div class="timer"><b>Sleep timer</b><div class="state" id="sleepState" data-sleeplabel>${sleepLabel()}</div>
        <div class="chips">${[15,30,45,60].map(x=>`<button class="chip" data-a="sleep" data-min="${x}" aria-pressed="${sleepMin===x}">${x} min</button>`).join("")}<button class="chip" data-a="sleep" data-min="0" aria-pressed="${!sleepEnd}">Off</button></div></div>
      <div class="chips"><button class="chip" data-a="sleeptab" data-t="sleep" aria-pressed="${tab==="sleep"}">Sleep</button><button class="chip" data-a="sleeptab" data-t="focus" aria-pressed="${tab==="focus"}">Focus</button></div>
      <div class="mixhead" style="${grad(m)}">${bars(m)}<h2>${esc(m.name)}</h2><p>${esc(m.blurb)}</p>
        <div class="actions"><button class="btn" data-a="playall" data-host="list">${ic("play")}Play</button></div></div>
      <div class="list" id="list" style="margin-top:14px"></div>`;
    renderList($("#list"),m.keys);
  }
};
function mosaic(l){
  const ts=l.keys.map(k=>cache.get(k)).filter(Boolean);
  if(ts.length>=4) return `<span class="mosaic">${ts.slice(0,4).map(t=>`<img src="${esc(artUrl(t,120))}" alt="">`).join("")}</span>`;
  if(ts.length) return artHTML(ts[0],56);
  const m=MIXES[{study:"focus",road:"road",gym:"run",sleep:"sleep"}[l.id]]||MIXES.party;
  return `<span class="art ph" style="${grad(m)};display:grid;width:100%;height:100%">${GLYPH}</span>`;
}

const NAV=[["home","Home","home"],["mood","Mood","mood"],["discover","Discover","discover"],["library","Library","library"],["artists","Artists","mic"],["sleep","Sleep","moon"]];
$("#nav").innerHTML=NAV.map(([v,l,i])=>`<button data-a="go" data-view="${v}" aria-label="${l==="Artists"?"Artist Corner":l==="Sleep"?"Sleep and Focus":l}">${ic(i)}<span>${l}</span></button>`).join("");
function go(view,arg,opts){
  S.view=view;S.deleteArm=(view==="playlist"&&S.deleteArm===arg)?arg:null;
  for(const k in LISTS) delete LISTS[k];
  VIEWS[view](main,arg,opts||{});
  main.scrollTop=0;
  const navView=view==="playlist"?"library":view;
  $$("#nav button").forEach(b=>{if(b.dataset.view===navView)b.setAttribute("aria-current","page");else b.removeAttribute("aria-current")});
}

/* ---------- playback ---------- */
function playFrom(lid,i){
  const L=LISTS[lid]; if(!L) return;
  const q=L.tracks.filter(Boolean), t=L.tracks[i]; if(!t) return;
  queue=q;qi=q.indexOf(t);load(t,true);
}
function load(t,autoplay){
  cur=t;audio.src=t.preview;
  if(autoplay) audio.play().catch(()=>{});
  recent=[t.key,...recent.filter(k=>k!==t.key)].slice(0,12);saveRecent();
  renderCur();
}
function next(){
  if(!queue.length) return;
  if(shuffleOn&&queue.length>1){let n;do{n=(Math.random()*queue.length)|0}while(n===qi);qi=n}else qi=(qi+1)%queue.length;
  load(queue[qi],true);
}
function prev(){
  if(!queue.length) return;
  if(audio.currentTime>3){audio.currentTime=0;return}
  qi=(qi-1+queue.length)%queue.length;load(queue[qi],true);
}
function toggle(){ if(!cur) return; if(audio.paused) audio.play().catch(()=>{}); else audio.pause(); }
audio.addEventListener("play",syncPlay);audio.addEventListener("pause",syncPlay);
audio.addEventListener("ended",next);
audio.addEventListener("error",()=>{ if(!cur) return; toast("That preview can't be played. Skipping to the next song."); if(queue.length>1) setTimeout(next,600); });
audio.addEventListener("timeupdate",()=>{
  const d=audio.duration||30, p=Math.min(1,audio.currentTime/d);
  $("#mini").style.setProperty("--p",p);
  $("#miniBar").style.setProperty("--p",p);
  const sk=$("#seek"); if(!seeking){sk.value=p*1000;sk.style.setProperty("--p",p)}
  $("#tNow").textContent=fmt(audio.currentTime);$("#tEnd").textContent=fmt(d);
});
let seeking=false;
$("#seek").addEventListener("input",e=>{seeking=true;const p=e.target.value/1000;e.target.style.setProperty("--p",p);$("#tNow").textContent=fmt(p*(audio.duration||30))});
$("#seek").addEventListener("change",e=>{audio.currentTime=e.target.value/1000*(audio.duration||30);seeking=false});

function syncPlay(){
  const pl=!audio.paused;
  app.classList.toggle("playing",pl);
  const icn=ic(pl?"pause":"play");
  $("#miniPP").innerHTML=icn;$("#bigPP").innerHTML=icn;
  const lab=pl?"Pause":"Play";$("#miniPP").setAttribute("aria-label",lab);$("#bigPP").setAttribute("aria-label",lab);
  if("mediaSession" in navigator) navigator.mediaSession.playbackState=pl?"playing":"paused";
}
function renderCur(){
  if(!cur) return;
  app.classList.add("has-cur");$("#mini").hidden=false;
  $("#miniCover").innerHTML=artHTML(cur,46);$("#miniT").textContent=cur.title;$("#miniA").textContent=cur.artist;
  $("#pCover").innerHTML=artHTML(cur,268);$("#pT").textContent=cur.title;$("#pA").textContent=cur.artist;
  $("#bgart").style.backgroundImage=cur.art?`url("${artUrl(cur,200)}")`:"none";
  syncLike();
  $$(".row[data-k]").forEach(r=>r.classList.toggle("on",r.dataset.k===cur.key));
  syncPlay();
  if("mediaSession" in navigator){
    navigator.mediaSession.metadata=new MediaMetadata({title:cur.title,artist:cur.artist,album:cur.album,artwork:cur.art?[{src:artUrl(cur,512),sizes:"512x512",type:"image/jpeg"}]:[]});
  }
}
if("mediaSession" in navigator){
  const ms=navigator.mediaSession;
  ms.setActionHandler("play",()=>audio.play());ms.setActionHandler("pause",()=>audio.pause());
  ms.setActionHandler("nexttrack",next);ms.setActionHandler("previoustrack",prev);
}
function syncLike(){
  if(cur){const on=isLiked(cur.key);const b=$("#pLike");b.classList.toggle("on",on);b.setAttribute("aria-pressed",on);}
  $$(".like[data-key]").forEach(b=>{const on=isLiked(b.dataset.key);b.classList.toggle("on",on);b.setAttribute("aria-pressed",on)});
}
function toggleLike(key){
  const i=liked.indexOf(key);
  if(i>=0){liked.splice(i,1);toast("Removed from Liked songs")}else{liked.unshift(key);toast("Added to Liked songs")}
  saveLiked();syncLike();
}

/* player sheet + save sheet */
/* Back button support: each open layer (player, sheet) gets a history entry,
   so the Android back button / swipe closes the top layer instead of the app. */
const layers=[];
function pushLayer(n){layers.push(n);try{history.pushState({md:n},"")}catch{}}
function openPlayer(){
  if(app.classList.contains("player-open")) return;
  app.classList.add("player-open");$("#player").inert=false;$("#closePlayer").focus({preventScroll:true});pushLayer("player");
}
function _closePlayer(){app.classList.remove("player-open");$("#player").inert=true}
function closePlayer(){ if(layers[layers.length-1]==="player") history.back(); else _closePlayer(); }
function openSheet(html,focusSel){
  const was=app.classList.contains("sheet-open");
  const sh=$("#sheet");sh.innerHTML=html;sh.inert=false;$("#scrim").hidden=false;app.classList.add("sheet-open");
  const f=(focusSel&&$(focusSel,sh))||$("button",sh);f&&f.focus({preventScroll:true});
  if(!was) pushLayer("sheet");
}
function _closeSheet(){app.classList.remove("sheet-open");$("#scrim").hidden=true;$("#sheet").inert=true}
function closeSheet(){ if(layers[layers.length-1]==="sheet") history.back(); else _closeSheet(); }
addEventListener("popstate",()=>{const n=layers.pop();if(n==="sheet")_closeSheet();else if(n==="player")_closePlayer();});
function saveSheet(key,focusId){
  const t=cache.get(key);if(!t) return;
  const chk=`<span class="chk">${ic("check")}</span>`;
  const ctx=S.view==="playlist"&&S.arg!=="liked"?lists.find(l=>l.id===S.arg):null;
  const inCtx=ctx&&ctx.keys.includes(key);
  openSheet(`<div class="grab"></div>
    <div class="shead"><div class="cover">${artHTML(t,52)}</div><div><div class="t">${esc(t.title)}</div><div class="a">${esc(t.artist)}</div></div></div>
    <button class="pl" data-a="tog-like" data-key="${esc(key)}" data-id="liked">${ic("heart")}Liked songs${isLiked(key)?chk:""}</button>
    ${lists.map(l=>`<button class="pl" data-a="tog-list" data-key="${esc(key)}" data-id="${esc(l.id)}">${ic("library")}${esc(l.name)}${l.keys.includes(key)?chk:""}</button>`).join("")}
    <form class="newform" data-form="newlist" data-key="${esc(key)}"><input class="field" name="n" placeholder="New playlist" maxlength="40" aria-label="New playlist name" required><button class="btn sm" type="submit">Create</button></form>
    ${inCtx?`<button class="pl rm" data-a="remove" data-key="${esc(key)}" data-id="${esc(ctx.id)}">Remove from ${esc(ctx.name)}</button>`:""}
    <button class="btn ghost" data-a="close-sheet">Done</button>`,focusId?`[data-id="${focusId}"]`:null);
}
function newList(name,key){
  const id="u"+Date.now().toString(36);
  lists.push({id,name:name.trim(),keys:key?[key]:[]});saveLists();
  toast(key?`Saved to ${name.trim()}`:`Created ${name.trim()}`);
}

/* ---------- sleep timer ---------- */
let sleepEnd=null,sleepMin=0,sleepT=null,fadeT=null;const FADE=15;
function sleepLabel(){
  if(!sleepEnd) return "Off. Pick a time and the music fades out by itself.";
  return `Music fades out in ${fmt((sleepEnd-Date.now())/1000)}`;
}
function setSleep(min){
  clearTimeout(sleepT);clearInterval(fadeT);audio.volume=1;
  if(!min){sleepEnd=null;sleepMin=0;toast("Sleep timer off");tickSleep();return}
  sleepMin=min;sleepEnd=Date.now()+min*60000;
  sleepT=setTimeout(fadeOut,Math.max(0,min*60000-FADE*1000));
  toast(`Music will fade out in ${min} minutes`);tickSleep();
}
function fadeOut(){
  const start=Date.now();
  fadeT=setInterval(()=>{
    const p=(Date.now()-start)/(FADE*1000);
    if(p>=1){clearInterval(fadeT);audio.pause();audio.volume=1;sleepEnd=null;sleepMin=0;tickSleep();toast("Sleep timer ended. Good night.");return}
    audio.volume=Math.max(0,1-p);
  },250);
}
function tickSleep(){
  const lab=sleepLabel();
  $$("[data-sleeplabel]").forEach(e=>e.textContent=lab);
  const pill=$("#sleepPill");
  if(sleepEnd){pill.hidden=false;pill.innerHTML=ic("moon")+fmt((sleepEnd-Date.now())/1000)}else pill.hidden=true;
  if(S.view==="sleep") $$('[data-a="sleep"]').forEach(b=>b.setAttribute("aria-pressed",String((+b.dataset.min===0&&!sleepEnd)||(+b.dataset.min===sleepMin&&!!sleepEnd))));
}
setInterval(()=>{if(sleepEnd)tickSleep()},1000);

/* ---------- search ---------- */
async function doSearch(term){
  const out=$("#results"),head=$("#resHead");if(!out) return;
  const seq=++S.searchSeq;
  $$("#genres .chip").forEach(c=>c.setAttribute("aria-pressed","false"));
  head.textContent=`Searching for “${term}”`;
  out.innerHTML=Array.from({length:6},(_,i)=>skRow(i)).join("");
  try{
    const d=await enqueue(()=>itunes({term,limit:25}),true);
    if(seq!==S.searchSeq) return;
    const ts=(d.results||[]).filter(r=>r.previewUrl&&r.trackId).map(r=>{const t=toTrack(r,"id:"+r.trackId);cache.set(t.key,t);return t});
    saveCache();
    if(!ts.length){head.textContent="";out.innerHTML=`<div class="empty"><b>No songs found for “${esc(term)}”</b>Check the spelling or try an artist name.</div>`;return}
    head.textContent=`${ts.length} ${ts.length===1?"song":"songs"} for “${term}”`;
    renderList(out,ts.map(t=>t.key));
  }catch{
    if(seq!==S.searchSeq) return;
    head.textContent="";
    out.innerHTML=`<div class="notice"><b>Can't reach the music catalogue</b>Check your internet connection, then search again.</div>`;
  }
}
function voice(){
  const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R) return;
  const r=new R();r.lang="en-US";r.interimResults=false;
  const btn=$("#voiceBtn");btn.style.color="var(--like)";toast("Listening. Say a song, artist or mood.");
  r.onresult=e=>{const s=e.results[0][0].transcript;$("#q").value=s;doSearch(s)};
  r.onerror=()=>toast("Couldn't hear that. Check your microphone and try again.");
  r.onend=()=>{btn.style.color=""};
  try{r.start()}catch{}
}

/* ---------- toast + theme ---------- */
let toastT;
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove("show"),2600)}
function setTheme(th){document.documentElement.dataset.theme=th;document.documentElement.style.setProperty("--micro-tile",microTile(th==="dark"?"rgba(143,216,255,.1)":"rgba(10,60,200,.14)",10));store.set("md.theme2",th);$('meta[name="theme-color"]').content=th==="dark"?"#06123A":"#EAF3FF"}
setTheme(store.get("md.theme2","light"));

/* ---------- events ---------- */
const ACT={
  go:b=>go(b.dataset.view,b.dataset.arg,{autoplay:!!b.dataset.autoplay}),
  play:b=>playFrom(b.dataset.l,+b.dataset.i),
  playall:b=>{const id=$("#"+b.dataset.host).dataset.list,L=LISTS[id];if(!L) return;shuffleOn=false;syncShuf();const i=L.tracks.findIndex(Boolean);if(i<0)return toast("Songs are still loading");playFrom(id,i)},
  shuffleall:b=>{const id=$("#"+b.dataset.host).dataset.list,L=LISTS[id];if(!L) return;const ok=L.tracks.map((t,i)=>t?i:-1).filter(i=>i>=0);if(!ok.length)return toast("Songs are still loading");shuffleOn=true;syncShuf();playFrom(id,ok[(Math.random()*ok.length)|0])},
  like:b=>toggleLike(b.dataset.key),
  "like-cur":()=>cur&&toggleLike(cur.key),
  more:b=>saveSheet(b.dataset.key),
  "more-cur":()=>cur&&saveSheet(cur.key),
  retry:b=>{const L=LISTS[b.closest("[data-list]").dataset.list];L&&L.reload(+b.dataset.i)},
  "retry-all":b=>{const h=b.closest("[data-list]");const L=LISTS[b.dataset.l];failStreak=0;if(L)renderList(h,L.keys)},
  toggle,next,prev,
  shuffle:()=>{shuffleOn=!shuffleOn;syncShuf()},
  "open-player":openPlayer,"close-player":closePlayer,"close-sheet":closeSheet,
  "go-sleep":()=>{closePlayer();go("sleep")},
  theme:()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark"),
  genre:b=>{S.genre=b.dataset.g;$$("#genres .chip").forEach(c=>c.setAttribute("aria-pressed",String(c.dataset.g===S.genre)));S.searchSeq++;$("#q").value="";$("#resHead").textContent="";renderList($("#results"),GENRES[S.genre])},
  sleep:b=>setSleep(+b.dataset.min),
  sleeptab:b=>{S.sleepTab=b.dataset.t;go("sleep")},
  "tog-like":b=>{toggleLike(b.dataset.key);saveSheet(b.dataset.key,"liked")},
  "tog-list":b=>{
    const l=lists.find(x=>x.id===b.dataset.id),k=b.dataset.key,i=l.keys.indexOf(k);
    if(i>=0){l.keys.splice(i,1);toast(`Removed from ${l.name}`)}else{l.keys.push(k);toast(`Saved to ${l.name}`)}
    saveLists();saveSheet(k,l.id);
  },
  remove:b=>{const l=lists.find(x=>x.id===b.dataset.id);l.keys=l.keys.filter(k=>k!==b.dataset.key);saveLists();closeSheet();go("playlist",l.id);toast(`Removed from ${l.name}`)},
  "del-list":b=>{
    if(S.deleteArm!==b.dataset.id){S.deleteArm=b.dataset.id;b.textContent="Tap again to delete";setTimeout(()=>{if(S.deleteArm===b.dataset.id&&b.isConnected){S.deleteArm=null;b.textContent="Delete"}},3500);return}
    lists=lists.filter(l=>l.id!==b.dataset.id);saveLists();S.deleteArm=null;toast("Playlist deleted");go("library");
  },
  voice
};
function syncShuf(){const b=$("#shuf");b.setAttribute("aria-pressed",String(shuffleOn))}
document.addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(b&&ACT[b.dataset.a]){ACT[b.dataset.a](b,e)}});
document.addEventListener("submit",e=>{
  const f=e.target;
  if(f.id==="searchForm"){e.preventDefault();const v=$("#q").value.trim();if(v)doSearch(v);return}
  if(f.dataset.form==="newlist"){
    e.preventDefault();const n=f.n.value.trim();if(!n) return;
    const key=f.dataset.key||null;newList(n,key);
    if(key){saveSheet(key)}else go("library");
  }
});
document.addEventListener("change",e=>{
  if(e.target.id!=="file") return;
  const f=e.target.files[0];if(!f) return;
  const key="up:"+(++S.uploads)+":"+Date.now();
  const title=f.name.replace(/\.[^.]+$/,"").replace(/[_-]+/g," ").trim()||"Untitled";
  cache.set(key,{key,id:key,title,artist:"Your upload",album:"",art:"",preview:URL.createObjectURL(f),ms:0});
  toast(`Added “${title}”`);go("artists");
});
let typing;
document.addEventListener("input",e=>{
  if(e.target.id!=="q") return;
  clearTimeout(typing);const v=e.target.value.trim();
  if(v.length>=3) typing=setTimeout(()=>doSearch(v),700);
});
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"){ if(app.classList.contains("sheet-open")) closeSheet(); else if(app.classList.contains("player-open")) closePlayer(); }
  if(e.code==="Space"&&cur&&!/^(INPUT|BUTTON|TEXTAREA|A)$/.test(document.activeElement.tagName)){e.preventDefault();toggle()}
});

/* ---------- start ---------- */
$("#brandMark").innerHTML=WM();$("#closePlayer").innerHTML=ic("down");$("#plMore").innerHTML=ic("plus");$("#pLike").innerHTML=ic("heart");
$("#shuf").innerHTML=ic("shuffle");$("#bPrev").innerHTML=ic("prev");$("#bNext").innerHTML=ic("next");$("#bTimer").innerHTML=ic("timer");
$("#miniPP").innerHTML=ic("play");$("#bigPP").innerHTML=ic("play");
go("home");

/* offline shell (only when served over http/https; skipped inside file:// previews) */
if("serviceWorker" in navigator && /^https?:$/.test(location.protocol)){
  addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
}
