const grid=document.getElementById("lessonGrid");
const filters=document.getElementById("filters");
const search=document.getElementById("search");
let activeGrade="Баары";
function grades(){return ["Баары",...new Set(lessons.map(x=>x.grade+"-класс"))]}
function renderFilters(){
  filters.innerHTML="";
  grades().forEach(g=>{const b=document.createElement("button");b.className="filter"+(g===activeGrade?" active":"");b.textContent=g;b.onclick=()=>{activeGrade=g;renderFilters();renderLessons()};filters.appendChild(b)})
}
function renderLessons(){
  const q=search.value.trim().toLocaleLowerCase("ky");
  const list=lessons.filter(l=>(activeGrade==="Баары"||activeGrade===l.grade+"-класс")&&(l.title+" "+l.desc+" "+l.grade).toLocaleLowerCase("ky").includes(q));
  grid.innerHTML="";
  if(!list.length){grid.innerHTML="<p>Бул сөз боюнча тема табылган жок. Башкача жазып көр.</p>";return}
  list.forEach((l,i)=>{const card=document.createElement("article");card.className="lesson-card";
    card.innerHTML=`<span class="grade">${l.grade}-класс</span><h3>${l.title}</h3><p>${l.desc}</p><button class="open-lesson">Сабакты окуу →</button>`;
    card.querySelector("button").onclick=()=>showLesson(l);grid.appendChild(card)})
}
function showLesson(l){
 let old=document.getElementById("lessonDetail");if(old)old.remove();
 const box=document.createElement("section");box.id="lessonDetail";box.className="lesson-detail";
 box.innerHTML=`<span class="grade">${l.grade}-класс</span><h2>${l.title}</h2><h3>1. Түшүндүрмө</h3><p>${l.explain}</p><h3>2. Негизги формула</h3><div class="formula">${l.formula}</div><h3>3. Кадам-кадам мисал</h3><ol>${l.steps.map(s=>`<li>${s}</li>`).join("")}</ol><div class="example"><b>Дагы бир мисал:</b><br>${l.example}</div><div class="task"><h3>4. Өзүңдү текшер</h3><p>${l.question}</p><input id="answerInput" aria-label="Жообуң" placeholder="Жообуңду жаз"><button id="checkAnswer">Текшерүү</button><p id="feedback" class="feedback" aria-live="polite"></p><p><b>Кеңеш:</b> <span id="hintText" hidden>${l.hint}</span><button id="showHint" class="open-lesson">Кеңешти көрсөт</button></p></div>`;
 grid.parentNode.insertBefore(box,grid.nextSibling);
 box.querySelector("#checkAnswer").onclick=()=>{
   const got=box.querySelector("#answerInput").value.trim().toLocaleLowerCase("ky").replace(",",".").replace(/\s+/g,"");
   const expected=l.answer.toLocaleLowerCase("ky").replace(",",".").replace(/\s+/g,"");
   const f=box.querySelector("#feedback");
   f.textContent=got===expected?"Туура! Азаматсың! Эми мисалды түшүндүрүп бере аласыңбы?":"Азырынча туура эмес окшойт. Кеңешти окуп, кадамдарды кайра карап көр.";
   f.style.color=got===expected?"#16804a":"#b45309";
 };
 box.querySelector("#showHint").onclick=()=>{box.querySelector("#hintText").hidden=false};
 box.scrollIntoView({behavior:"smooth",block:"start"});
}
search.addEventListener("input",renderLessons);
renderFilters();renderLessons();
