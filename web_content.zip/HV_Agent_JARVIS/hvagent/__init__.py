"""HV Agent — local Windows AI desktop assistant."""
__version__ = '0.1.0'
