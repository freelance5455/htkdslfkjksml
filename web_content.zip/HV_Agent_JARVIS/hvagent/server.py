"""Local-only, same-session authenticated HTTP UI. No external web service needed."""
from __future__ import annotations
import json
import mimetypes
import secrets
import urllib.parse
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from hvagent.core import Engine

class HVServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self, addr, root):
        super().__init__(addr, HVHandler)
        self.root=Path(root)
        self.engine=Engine(self.root)
        self.token=secrets.token_urlsafe(32)
        self.preview_token=secrets.token_urlsafe(24)

class HVHandler(BaseHTTPRequestHandler):
    server:HVServer
    def log_message(self,*_): pass

    def send_bytes(self,payload,content_type='application/octet-stream',code=200,cache=False,frame=False,cookie=False):
        self.send_response(code)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        if cookie: self.send_header('Set-Cookie',f'HVPreview={self.server.preview_token}; HttpOnly; SameSite=Lax; Path=/preview/')
        self.send_header('Cache-Control','public,max-age=3600' if cache else 'no-store')
        if not frame:
            self.send_header('Content-Security-Policy',"default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; media-src 'self' data:; frame-src 'self'; object-src 'none'; base-uri 'none'")
        else: self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'self' 'unsafe-inline' data:; img-src 'self' data: https:; script-src 'unsafe-inline' 'self'; font-src 'self'; connect-src 'none'; form-action 'none'")
        self.end_headers()
        if self.command!='HEAD': self.wfile.write(payload)

    def json(self,data,code=200):
        self.send_bytes(json.dumps(data,ensure_ascii=False,default=str).encode('utf-8'),'application/json; charset=utf-8',code)

    def auth(self):
        if self.headers.get('X-HV-Token','')!=self.server.token:
            self.json({'error':'Unauthorized local session'},403)
            return False
        return True

    def get_file(self,path,base,frame=False):
        base=base.resolve()
        path=(base/path).resolve()
        if (base not in path.parents and base!=path) or not path.is_file():
            self.json({'error':'Not found'},404);return
        kind=mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
        if kind.startswith('text/') or kind in {'application/javascript','application/json','image/svg+xml'}: kind+='; charset=utf-8'
        self.send_bytes(path.read_bytes(),kind,cache=not frame,frame=frame)

    def do_GET(self):
        u=urllib.parse.urlsplit(self.path)
        path=urllib.parse.unquote(u.path)
        if path=='/':
            data=(self.server.root/'web'/'index.html').read_text(encoding='utf-8')
            data=data.replace('__HV_SESSION__',self.server.token)
            self.send_bytes(data.encode('utf-8'),'text/html; charset=utf-8',cookie=True); return
        if path.startswith('/static/'):
            self.get_file(path[len('/static/'):],self.server.root/'web');return
        if path.startswith('/preview/'):
            if f'HVPreview={self.server.preview_token}' not in self.headers.get('Cookie',''):
                self.json({'error':'Preview session required'},403);return
            self.get_file(path[len('/preview/'):],self.server.root/'projects',frame=True);return
        if not self.auth(): return
        e=self.server.engine
        if path=='/api/state': self.json(e.state())
        elif path=='/api/messages':self.json({'items':e.store.messages(35)})
        elif path=='/api/memories':self.json({'items':e.store.memories()})
        elif path=='/api/reminders':self.json({'items':e.store.reminders()})
        elif path=='/api/screenshot':
            try: self.json({'base64':e.actions.screenshot_base64()})
            except Exception as err: self.json({'error':str(err)},400)
        elif path=='/api/projects':
            items=[]
            for p in sorted(e.projects.iterdir())[:150]:
                items.append({'name':p.name,'type':'folder' if p.is_dir() else 'file'})
            self.json({'items':items})
        else: self.json({'error':'Not found'},404)

    def do_POST(self):
        if not self.auth(): return
        origin=self.headers.get('Origin')
        if origin and origin!=f'http://{self.headers.get("Host", "")}':
            self.json({'error':'Invalid origin'},403);return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>12000 or length<0: raise ValueError('Request too large')
            data=json.loads(self.rfile.read(length) or b'{}')
            if not isinstance(data,dict): raise ValueError('Expected JSON object')
            e=self.server.engine
            path=urllib.parse.urlsplit(self.path).path
            if path=='/api/task': result={'id':e.start(data.get('text',''),data.get('mode','chat'))}
            elif path=='/api/stop': result={'ok':e.stop()}
            elif path=='/api/approve':
                e.approve(data.get('id'),data.get('choice'));result={'ok':True}
            elif path=='/api/settings':
                e.save_settings(data);result={'settings':e.public_settings()}
            elif path=='/api/memory/add':
                content=str(data.get('content','')).strip()
                if not content or len(content)>1000: raise ValueError('Memory must be 1–1000 chars')
                result={'id':e.store.add_memory(content)}
            elif path=='/api/memory/delete':
                e.store.delete_memory(int(data.get('id')));result={'ok':True}
            elif path=='/api/reminder/add':
                note=str(data.get('note','')).strip()
                due=datetime.fromisoformat(str(data.get('due_at','')))
                cadence=data.get('recurrence','once')
                if not note or len(note)>500 or cadence not in {'once','daily','weekly'}: raise ValueError('Invalid reminder')
                if due<=datetime.now(): raise ValueError('Please select a future date and time')
                result={'id':e.store.add_reminder(note,due.isoformat(timespec='seconds'),cadence)}
            elif path=='/api/reminder/delete':
                e.store.delete_reminder(int(data.get('id')));result={'ok':True}
            elif path=='/api/chat/clear':
                e.store.clear_messages();result={'ok':True}
            else: self.json({'error':'Not found'},404);return
            self.json(result)
        except (ValueError,TypeError,KeyError) as err:
            self.json({'error':str(err)},400)
        except Exception as err:
            self.json({'error':'Operation failed: '+str(err)[:200]},500)
