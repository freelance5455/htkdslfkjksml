"""A small, explicitly bounded set of Windows desktop and coding actions."""
from __future__ import annotations
import base64
import io
import os
import re
import subprocess
import sys
import time
import webbrowser
import shlex
from pathlib import Path
from urllib.parse import quote

class ActionError(RuntimeError): pass

APPS={
 'notepad':'notepad.exe', 'calculator':'calc.exe','calc':'calc.exe',
 'explorer':'explorer.exe','file explorer':'explorer.exe',
 'chrome':'chrome.exe','edge':'msedge.exe','vs code':'Code.exe',
 'vscode':'Code.exe','powershell':'powershell.exe','terminal':'wt.exe',
 'paint':'mspaint.exe',
}
DESKTOP_ACTIONS={'click','double_click','right_click','move','scroll','type_text','hotkey'}
SENSITIVE_ACTIONS={'run_command','open_app','open_url'}
VALID_ACTIONS=DESKTOP_ACTIONS|SENSITIVE_ACTIONS|{'list_dir','read_file','write_file','show_preview','wait','observe'}

class Actions:
    def __init__(self, projects:Path, log_fn, stop_event):
        self.projects=projects.resolve()
        self.projects.mkdir(exist_ok=True,parents=True)
        self.log=log_fn
        self.stop_event=stop_event
        self.preview=None

    def project_path(self, requested:str):
        if not isinstance(requested,str) or len(requested)>300: raise ActionError('Invalid project path')
        if not requested.strip(): requested='.'
        p=(self.projects / requested).resolve()
        if p!=self.projects and self.projects not in p.parents:
            raise ActionError('Files must stay inside the projects folder')
        return p

    def screenshot_base64(self):
        try:
            # Pillow ImageGrab is available for most Windows setups.
            from PIL import ImageGrab
            shot=ImageGrab.grab(all_screens=False)
            shot.thumbnail((1366,768))
            buffer=io.BytesIO(); shot.convert('RGB').save(buffer,format='JPEG',quality=67,optimize=True)
            return base64.b64encode(buffer.getvalue()).decode('ascii')
        except Exception as e:
            raise ActionError(f'Cannot capture display: {e}')

    @staticmethod
    def _pyautogui():
        try:
            import pyautogui
            pyautogui.FAILSAFE=True
            pyautogui.PAUSE=0.15
            return pyautogui
        except Exception as e:
            raise ActionError(f'Computer control package unavailable: {e}')

    def execute(self, action:dict, mode:str):
        kind=action.get('type','')
        args=action.get('args') or {}
        if kind not in VALID_ACTIONS: raise ActionError(f'Unknown action: {kind}')
        if not isinstance(args,dict): raise ActionError('Action arguments must be object')
        if self.stop_event.is_set(): raise ActionError('STOP requested')
        if kind in DESKTOP_ACTIONS:
            p=self._pyautogui()
            if kind in {'click','double_click','right_click','move'}:
                x=int(args['x']); y=int(args['y'])
                if x<0 or y<0 or x>=p.size()[0] or y>=p.size()[1]:
                    raise ActionError('Coordinates are outside the primary monitor')
                if kind=='click': p.click(x,y)
                elif kind=='double_click': p.doubleClick(x,y,interval=0.13)
                elif kind=='right_click': p.click(x,y,button='right')
                else: p.moveTo(x,y,duration=0.25)
            elif kind=='scroll': p.scroll(max(-8,min(8,int(args.get('amount',-3)))))
            elif kind=='hotkey':
                keys=args.get('keys',[])
                allowed={'ctrl','shift','alt','win','enter','tab','esc','escape','up','down','left','right','home','end','f5','a','c','v','s','x','z','backspace','delete','space','t','w','l','n','p','r'}
                if not isinstance(keys,list) or not (1<=len(keys)<=4) or any(k not in allowed for k in keys):
                    raise ActionError('Unsupported key combination')
                p.hotkey(*keys)
            elif kind=='type_text':
                content=str(args.get('text',''))[:2500]
                try:
                    import pyperclip
                    before=pyperclip.paste()
                    pyperclip.copy(content); p.hotkey('ctrl','v'); time.sleep(.2)
                    pyperclip.copy(before)
                except Exception:
                    # PyAutoGUI write supports ASCII only; suggest clipboard if needed.
                    if not content.isascii(): raise ActionError('Unicode typing requires pyperclip')
                    p.write(content,interval=.012)
            return f'{kind} executed'
        if kind=='open_app':
            app=str(args.get('name','')).lower().strip()
            if app not in APPS: raise ActionError('App not allowlisted; supported: '+', '.join(APPS))
            try: subprocess.Popen([APPS[app]], shell=False,stdin=subprocess.DEVNULL,
                                  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            except OSError as e: raise ActionError(f'App not found / failed to launch: {e}') from e
            return 'Launched '+app
        if kind=='open_url':
            url=str(args.get('url',''))
            if not re.match(r'^https?://[^\s/]+',url,re.I) or len(url)>2000:
                raise ActionError('Only HTTP(S) URLs are allowed')
            webbrowser.open(url)
            return 'Opened URL in default browser'
        if kind=='list_dir':
            p=self.project_path(args.get('path','.'))
            if not p.is_dir(): raise ActionError('Not a directory')
            entries=list(p.iterdir())[:80]
            return '\n'.join(('[DIR] ' if e.is_dir() else '[FILE] ')+e.name for e in entries) or '(empty)'
        if kind=='read_file':
            p=self.project_path(args.get('path',''))
            if not p.is_file() or p.stat().st_size>100000: raise ActionError('File not found or too large (>100KB)')
            return p.read_text(encoding='utf-8')[:20000]
        if kind=='write_file':
            if mode not in {'coder','creative'}: raise ActionError('File writing requires Coder/Creative mode')
            p=self.project_path(args.get('path',''))
            if p==self.projects: raise ActionError('Choose a filename')
            code=args.get('content')
            if not isinstance(code,str) or len(code)>120000: raise ActionError('File content missing or too large')
            p.parent.mkdir(parents=True,exist_ok=True)
            existed=p.exists()
            p.write_text(code,encoding='utf-8')
            return f'{"Updated" if existed else "Created"}: {p.relative_to(self.projects)} ({len(code)} characters)'
        if kind=='show_preview':
            p=self.project_path(args.get('path',''))
            if not p.is_file() or p.suffix.lower() not in {'.html','.htm'}: raise ActionError('Preview needs an existing .html file')
            self.preview='/preview/'+quote(p.relative_to(self.projects).as_posix(),safe='/')
            return f'Preview available: {self.preview}'
        if kind=='run_command':
            if mode!='coder': raise ActionError('Terminal access requires Coder mode')
            argv=args.get('argv',[])
            if not isinstance(argv,list) or not (1<=len(argv)<=25) or any(not isinstance(i,str) or not i or len(i)>500 for i in argv):
                raise ActionError('Expected argv as list of short strings (no shell)')
            allowed={'python','python.exe','py','node','npm','npm.cmd','git','git.exe','pytest'}
            exe=Path(argv[0]).name.lower()
            if exe not in allowed: raise ActionError('Executable not allowlisted: '+exe)
            cwd=self.project_path(args.get('cwd','.'))
            if not cwd.is_dir(): raise ActionError('Working directory is missing')
            # Commands run with the current user's permissions. User approval is mandatory.
            proc=subprocess.Popen(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                  text=True,encoding='utf-8',errors='replace',shell=False)
            try:
                deadline=time.monotonic()+35
                while proc.poll() is None:
                    if self.stop_event.is_set() or time.monotonic()>deadline:
                        proc.kill(); proc.wait(timeout=3)
                        raise ActionError('Command stopped or timed out (35 sec).')
                    time.sleep(.25)
                out=(proc.stdout.read() or '')[-10000:]
                return f'Exit code {proc.returncode}\n{out}'
            finally:
                if proc.poll() is None: proc.kill()
        if kind=='wait':
            seconds=max(0,min(3,float(args.get('seconds',1))))
            end=time.monotonic()+seconds
            while time.monotonic()<end:
                if self.stop_event.is_set(): raise ActionError('STOP requested')
                time.sleep(.1)
            return f'Waited {seconds} seconds'
        if kind=='observe':
            try:
                self.screenshot_base64()
                return 'New screenshot captured; next observation will see updated screen.'
            except ActionError as e: return str(e)
        raise ActionError('Unhandled action')
