"""Minimal official Gemini REST generateContent integration (no SDK dependency)."""
from __future__ import annotations
import json
import os
import re
import urllib.request
import urllib.error

API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'

class GeminiError(RuntimeError): pass

class Gemini:
    def __init__(self, key_getter, model_getter):
        self.key_getter=key_getter
        self.model_getter=model_getter

    def generate(self, system: str, prompt: str, screenshot: str|None=None, json_mode: bool=False, ground_search: bool=False) -> str:
        key=(self.key_getter() or os.getenv('GEMINI_API_KEY') or '').strip()
        if not key: raise GeminiError('Gemini API key missing. Settings mein key add karo.')
        model=self.model_getter().strip()
        if not re.fullmatch(r'[\w.-]{3,90}',model): raise GeminiError('Invalid model ID.')
        parts=[{'text':prompt}]
        if screenshot: parts.append({'inlineData':{'mimeType':'image/jpeg','data':screenshot}})
        payload={
            'systemInstruction': {'parts':[{'text':system}]},
            'contents':[{'role':'user','parts':parts}],
            'generationConfig':{'temperature':0.25 if json_mode else 0.65,'maxOutputTokens':8192}
        }
        if json_mode: payload['generationConfig']['responseMimeType']='application/json'
        if ground_search: payload['tools']=[{'googleSearch':{}}]
        request=urllib.request.Request(API_URL.format(model=model),
            data=json.dumps(payload).encode('utf-8'),
            headers={'Content-Type':'application/json','x-goog-api-key':key}, method='POST')
        try:
            with urllib.request.urlopen(request, timeout=65) as result:
                data=json.load(result)
        except urllib.error.HTTPError as e:
            try: detail=json.loads(e.read().decode('utf-8'))['error']['message']
            except Exception: detail=f'HTTP {e.code}'
            raise GeminiError(f'Gemini request failed: {detail[:500]}') from e
        except (urllib.error.URLError, TimeoutError) as e:
            raise GeminiError(f'Gemini network error: {e}') from e
        candidates=data.get('candidates') or []
        if not candidates: raise GeminiError(f'Gemini gave no answer: {str(data.get("promptFeedback", ""))[:200]}')
        result='\n'.join(p.get('text','') for p in candidates[0].get('content',{}).get('parts',[]) if 'text' in p).strip()
        if not result: raise GeminiError('Gemini response was empty.')
        if ground_search:
            metadata=candidates[0].get('groundingMetadata') or {}
            sources=[]
            for chunk in metadata.get('groundingChunks') or []:
                web=chunk.get('web') or {}
                url=web.get('uri','')
                if url.startswith('https://') and url not in sources: sources.append(url)
            if sources: result += '\n\nSources (Google Search grounding):\n'+'\n'.join(sources[:8])
            else: result += '\n\nNote: Search grounding supplied no source links; verify important facts.'
        return result

    @staticmethod
    def as_json(raw):
        raw=raw.strip()
        if raw.startswith('```'):
            raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw,flags=re.I)
        try: parsed=json.loads(raw)
        except json.JSONDecodeError as e: raise GeminiError('Gemini returned an invalid action plan.') from e
        if not isinstance(parsed,dict): raise GeminiError('Action plan should be a JSON object.')
        return parsed
