"""SQLite persistence for chat, explicit memory and reminders."""
from __future__ import annotations
import json
import sqlite3
import threading
from pathlib import Path
from datetime import datetime

class Store:
    def __init__(self, data_dir: Path):
        data_dir.mkdir(parents=True, exist_ok=True)
        self.db = data_dir / 'hv.sqlite3'
        self.lock = threading.RLock()
        with self._connect() as conn:
            conn.executescript('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY, role TEXT NOT NULL, mode TEXT NOT NULL,
                text TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY, content TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY, note TEXT NOT NULL, due_at TEXT NOT NULL,
                recurrence TEXT NOT NULL DEFAULT 'once', active INTEGER NOT NULL DEFAULT 1
            );
            ''')

    def _connect(self):
        conn = sqlite3.connect(self.db, timeout=5)
        conn.row_factory = sqlite3.Row
        return conn

    def add_message(self, role, mode, text):
        with self.lock, self._connect() as db:
            db.execute('INSERT INTO messages(role,mode,text,created_at) VALUES(?,?,?,?)',
                       (role, mode, text[:20000], datetime.now().isoformat(timespec='seconds')))

    def messages(self, n=20):
        with self.lock, self._connect() as db:
            rows = db.execute('SELECT * FROM (SELECT * FROM messages ORDER BY id DESC LIMIT ?) ORDER BY id', (n,)).fetchall()
            return [dict(r) for r in rows]

    def clear_messages(self):
        with self.lock, self._connect() as db: db.execute('DELETE FROM messages')

    def memories(self):
        with self.lock, self._connect() as db:
            return [dict(r) for r in db.execute('SELECT * FROM memories ORDER BY id DESC LIMIT 60').fetchall()]

    def add_memory(self, content):
        with self.lock, self._connect() as db:
            cur=db.execute('INSERT INTO memories(content,created_at) VALUES (?,?)',
                           (content[:1000],datetime.now().isoformat(timespec='seconds')))
            return cur.lastrowid

    def delete_memory(self, id):
        with self.lock, self._connect() as db: db.execute('DELETE FROM memories WHERE id=?', (id,))

    def reminders(self):
        with self.lock, self._connect() as db:
            return [dict(r) for r in db.execute('SELECT * FROM reminders ORDER BY due_at').fetchall()]

    def add_reminder(self, note, due_at, recurrence):
        with self.lock, self._connect() as db:
            cur=db.execute('INSERT INTO reminders(note,due_at,recurrence) VALUES (?,?,?)', (note[:500],due_at,recurrence))
            return cur.lastrowid

    def delete_reminder(self, id):
        with self.lock, self._connect() as db: db.execute('DELETE FROM reminders WHERE id=?', (id,))

    def due_reminders(self, now):
        with self.lock, self._connect() as db:
            rows=db.execute('SELECT * FROM reminders WHERE active=1 AND due_at <= ? ORDER BY due_at', (now.isoformat(timespec='seconds'),)).fetchall()
            found=[dict(r) for r in rows]
            for r in found:
                d=datetime.fromisoformat(r['due_at'])
                if r['recurrence']=='daily':
                    from datetime import timedelta
                    while d<=now: d+=timedelta(days=1)
                    db.execute('UPDATE reminders SET due_at=? WHERE id=?',(d.isoformat(timespec='seconds'),r['id']))
                elif r['recurrence']=='weekly':
                    from datetime import timedelta
                    while d<=now: d+=timedelta(days=7)
                    db.execute('UPDATE reminders SET due_at=? WHERE id=?',(d.isoformat(timespec='seconds'),r['id']))
                else:
                    db.execute('UPDATE reminders SET active=0 WHERE id=?',(r['id'],))
            return found
