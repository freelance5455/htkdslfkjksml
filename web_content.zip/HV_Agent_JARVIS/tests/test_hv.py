import json
import tempfile
import threading
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch
from hvagent.actions import Actions, ActionError
from hvagent.gemini import Gemini
from hvagent.storage import Store
from hvagent.core import Engine

class StorageTests(unittest.TestCase):
    def test_memory_chat_reminders(self):
        with tempfile.TemporaryDirectory() as d:
            db=Store(Path(d))
            db.add_message('user','chat','hello')
            self.assertEqual(db.messages()[-1]['text'],'hello')
            mid=db.add_memory('I prefer Roman Urdu')
            self.assertEqual(db.memories()[0]['id'],mid)
            db.delete_memory(mid)
            self.assertEqual(db.memories(),[])
            due=(datetime.now()-timedelta(seconds=1)).isoformat(timespec='seconds')
            db.add_reminder('hello',due,'once')
            self.assertEqual(len(db.due_reminders(datetime.now())),1)
            self.assertEqual(len(db.due_reminders(datetime.now())),0)

class SecurityTests(unittest.TestCase):
    def test_path_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            a=Actions(Path(d)/'projects',print,threading.Event())
            for path in ['../../outside','/etc/passwd','C:/Windows/System32']:
                if path.startswith('C:') and __import__('os').name!='nt': continue
                with self.assertRaises(ActionError):a.project_path(path)
    def test_unknown_action(self):
        with tempfile.TemporaryDirectory() as d:
            a=Actions(Path(d)/'projects',print,threading.Event())
            with self.assertRaises(ActionError):a.execute({'type':'delete_file'},'coder')
    def test_write_and_preview(self):
        with tempfile.TemporaryDirectory() as d:
            a=Actions(Path(d)/'projects',print,threading.Event())
            s=a.execute({'type':'write_file','args':{'path':'site/index.html','content':'<h1>test</h1>'}},'coder')
            self.assertIn('Created',s)
            a.execute({'type':'show_preview','args':{'path':'site/index.html'}},'coder')
            self.assertEqual(a.preview,'/preview/site/index.html')
    def test_unknown_terminal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            a=Actions(Path(d)/'projects',print,threading.Event())
            with self.assertRaises(ActionError):a.execute({'type':'run_command','args':{'argv':['powershell','-Command','Get-Process']}},'coder')
    def test_no_key_error(self):
        with self.assertRaises(Exception):Gemini(lambda:'',lambda:'gemini-2.5-flash').generate('a','b')

class CoreTests(unittest.TestCase):

    def test_coder_loop_creates_preview(self):
        with tempfile.TemporaryDirectory() as d:
            e=Engine(Path(d))
            plans=[
              {'say':'Writing HTML','action':{'type':'write_file','args':{'path':'restaurant/index.html','content':'<h1>Restaurant</h1>'},'risk':'normal','summary':'Write file'},'done':False},
              {'say':'Showing preview','action':{'type':'show_preview','args':{'path':'restaurant/index.html'},'risk':'normal','summary':'Preview'},'done':False},
              {'say':'Website file created and preview opened.','action':None,'done':True}
            ]
            e.gemini.generate=lambda *args,**kwargs:json.dumps(plans.pop(0))
            e.job={'step':0,'status':'running','approval':None}
            ans=e._agent('Create a restaurant page','coder')
            self.assertEqual(ans,'Website file created and preview opened.')
            self.assertEqual((Path(d)/'projects'/'restaurant'/'index.html').read_text(),'<h1>Restaurant</h1>')
            self.assertEqual(e.actions.preview,'/preview/restaurant/index.html')
    def test_engine_initial_state(self):
        with tempfile.TemporaryDirectory() as d:
            e=Engine(Path(d))
            self.assertEqual(e.state()['job'],None)
            self.assertFalse(e.public_settings()['has_key'])
            e.save_settings({'model':'gemini-2.5-flash','personality':'professional'})
            self.assertEqual(e.public_settings()['personality'],'professional')

if __name__=='__main__':unittest.main()
