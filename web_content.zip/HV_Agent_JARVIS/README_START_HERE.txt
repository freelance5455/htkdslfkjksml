HV AGENT — JARVIS COMMAND CENTER  |  Windows starter application
==============================================================

YEH KYA HAI?
This is a working integrated local HV Agent foundation, NOT a claim that
all 21 advanced features in your vision are production-ready.

INCLUDED NOW
- Futuristic original desktop-style GUI running in Microsoft Edge app mode
  (or your default browser if Edge is unavailable).
- Animated human-like character made entirely from 2100 glowing dust particles.
- Original Windows startup spoken greeting (uses local System.Speech),
  browser voice responses, and microphone input when browser supports it.
- Gemini AI chatbot, memory-based conversation, Roman Urdu / Urdu / English.
- Gemini Google Search grounded Research mode (may incur API costs).
- Full-screen screenshot => Gemini vision => one desktop action => new screenshot.
- Approval before EVERY mouse / keyboard / application / URL / command action.
- HV Coder / Creative project file creation, safe project-folder confinement,
  HTML preview and tool-based coding / commands with approval.
- Local SQLite chat memory, manually added memories, date/time reminders.
- Live action audit log, per-action ALLOW/DENY, red STOP HV control.

FIRST TIME (Windows 10 / 11)
1. Install Python 3.10 or newer from https://www.python.org/downloads/
   Select the checkbox "Add Python to PATH" during installation.
2. Extract this whole folder to your PC. Do not run directly inside ZIP.
3. Double click START_HV_WINDOWS.bat
4. The app should open in Edge, or otherwise in your default browser.
5. Click "System Config" -> paste your own Gemini API key -> Save.
   Obtain a key from https://aistudio.google.com/apikey
   Default model: gemini-2.5-flash. If your key does not have access,
   change model in System Config to one enabled for your account.
6. Mode select from left, then type command and press Enter.

EXAMPLE COMMANDS
[Brain] Yar mujhe ek professional website ka idea do.
[Computer] HV calculator kholo.    (approve open_app)
[Computer] Chrome kholo aur Google search karo. (approve each action)
[Coder] Ek modern one-page restaurant website banao. Files projects/ mein.
[Creative] Meri perfume brand ke liye luxury HTML landing page banao.
[Research] Aaj AI industry ki latest news sources ke saath research karo.

VOICE
- Windows will try to say "HV systems online" at startup via SAPI.
- Browser voice replies can be toggled; exact voice varies by installed OS.
- Microphone depends on permission and browser recognition support.
- This project does NOT include a copied Iron Man/JARVIS film audio clip/voice.
- Full-duplex streaming speech, realistic emotions, wake-word detection,
  or advanced voice cloning are NOT part of this version.

IMPORTANT SAFETY / PRIVACY
- All HV server endpoints bind ONLY to localhost (127.0.0.1).
- The app sends text and screenshots you choose to analyze to Google's
  Gemini API. Close sensitive documents before using Computer mode.
- The API key in GUI settings is stored locally in data/settings.json.
  For stronger secrecy set GEMINI_API_KEY environment variable instead.
- Never share your data/ folder, especially the settings JSON and SQLite DB.
- Every screen click and keypress requires your confirmation. Once clicked,
  a user-approved action can still have effects; review carefully.
- Tool commands are run with your Windows user permissions, not sandboxed.
  Only approve terminal commands you understand.
- STOP HV prevents additional steps; it may not instantly terminate an
  in-flight Gemini network call or reverse already executed actions.
- Do not let HV control elevated admin prompts, password managers,
  banking sites, security settings or sensitive accounts.
- The app does NOT automatically send WhatsApp messages, manage external
  accounts, use Android remote access or create real image/video output.
  Browser-based interaction with these applications needs additional integration.
- Google Gemini rates/pricing/availability depend on your account and model.
- Reminder notifications work only while this program is running.

FOLDER STRUCTURE
  START_HV_WINDOWS.bat  double-click launcher (installs Python packages)
  run.py                main local HTTP server and Windows greeting
  web/                  original HUD and dust figure animation
  hvagent/gemini.py     official REST API requests
  hvagent/core.py       Gemini reasoning + observe/act/verify loop
  hvagent/actions.py    approved Windows desktop and coding tools
  hvagent/storage.py    SQLite memory and reminders
  hvagent/server.py     local protected API and preview
  projects/             sites and code created by HV Coder
  data/                 private key, chat history, memory, reminders
  tests/                offline tests

TROUBLESHOOTING
- BAT window closes? Open Command Prompt in this directory, run:
    python run.py
- API error? Check API key and model name, and internet access.
- No mouse control? Run on actual Windows desktop session, not a remote/headless host.
- Browser voice won't start? Click once inside the interface to permit audio.
- Preview not showing? Try Preview tab and Refresh; keep server open.
- To stop completely: close BAT terminal or press Ctrl+C inside it.

NEXT-LEVEL EXTENSIONS NOT IMPLEMENTED HERE
Android companion, secure remote pairing, WhatsApp official integrations,
Canva/CapCut automation reliability, video/image generation APIs, automatic
GitHub deploy, fully autonomous long-horizon planning, 3D game-engine avatar.
These need significant additional engineering, app permissions and tests.

HV is an independent original project using Gemini; no affiliation with Marvel.
