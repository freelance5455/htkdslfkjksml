(() => {
'use strict';
const token=document.querySelector('meta[name="hv-token"]').content;
const $=id=>document.getElementById(id);
const ui={mode:'chat',state:null,lastJobId:'',lastJobStatus:'',lastNotice:'',lastEventId:0,shownApproval:'',previewTab:'preview',voice:true,recognizer:null,waiting:false,notificationIds:new Set(),messagesFingerprint:''};
const modeNames={chat:'BRAIN',computer:'COMPUTER',coder:'CODER',creative:'CREATIVE',research:'RESEARCH'};
function toast(text){const e=$('toast');e.textContent=text;e.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('show'),3400)}
async function api(path,body){
  const args={headers:{'X-HV-Token':token}};
  if(body!==undefined){args.method='POST';args.headers['Content-Type']='application/json';args.body=JSON.stringify(body)}
  const r=await fetch(path,args);let result;
  try{result=await r.json()}catch{throw Error('Unexpected response from HV server')}
  if(!r.ok)throw Error(result.error||'HTTP '+r.status);
  return result;
}
function safe(fn){return (...args)=>Promise.resolve().then(()=>fn(...args)).catch(e=>toast(e.message||String(e)))}
function timeClock(){
  const d=new Date();$('clock').textContent=d.toLocaleTimeString('en-GB',{hour12:false});
}
setInterval(timeClock,1000);timeClock();
function selectMode(mode){
  ui.mode=mode;
  document.querySelectorAll('.mode').forEach(x=>x.classList.toggle('active',x.dataset.mode===mode));
  $('heroMode').textContent=modeNames[mode];
  $('prompt').placeholder=({chat:'Ask HV anything... Roman Urdu, Urdu or English',computer:'e.g. "HV WhatsApp kholo" or "Chrome mein Google open karo"',coder:'e.g. "Mere liye modern restaurant website banao"',creative:'e.g. "Premium landing page ka design create karo"',research:'e.g. "Pakistan AI market ki latest research karo"'})[mode];
  if(mode==='computer')toast('Computer mode: each mouse/keyboard action needs approval.');
}
document.querySelectorAll('.mode').forEach(x=>x.addEventListener('click',()=>selectMode(x.dataset.mode)));
function addMessage(role,text,meta){
  const msg=document.createElement('div');msg.className='message '+(role==='user'?'user':'assistant');
  if(role!=='user') {const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent='HV';msg.append(avatar)}
  const bubble=document.createElement('div');bubble.className='bubble';
  const name=document.createElement('div');name.className='msg-name';name.textContent=role==='user'?'YOU / COMMAND':'HV AGENT';
  const span=document.createElement('small');span.textContent=meta||'';name.append(span);
  const content=document.createElement('div');content.textContent=text; // textContent intentionally prevents LLM HTML injection
  bubble.append(name,content);msg.append(bubble);$('messages').append(msg);$('messages').scrollTop=$('messages').scrollHeight;
}
async function loadMessages(){
  let r=await api('/api/messages');
  let fingerprint=r.items.map(x=>x.id).join(',');
  if(fingerprint===ui.messagesFingerprint)return;
  ui.messagesFingerprint=fingerprint;
  if(!r.items.length)return;
  $('messages').replaceChildren();
  r.items.forEach(x=>addMessage(x.role,x.text,x.mode.toUpperCase()));
}
async function send(){
  const text=$('prompt').value.trim();if(!text||ui.waiting)return;
  ui.waiting=true;
  try{
    const d=await api('/api/task',{text,mode:ui.mode});
    $('prompt').value='';$('sendButton').disabled=true;
    addMessage('user',text,ui.mode.toUpperCase());
    ui.messagesFingerprint='';ui.lastJobId=d.id;ui.lastJobStatus='running';
    $('heroState').textContent='PROCESSING YOUR COMMAND';
    window.HVParticles?.setState('thinking');
  }catch(e){toast(e.message)}finally{ui.waiting=false}
}
$('sendButton').addEventListener('click',safe(send));
$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
function setStatus(job){
  const active=job&&['running','approval','stopping'].includes(job.status);
  $('sendButton').disabled=!!active;
  $('taskState').textContent=!job?'IDLE':job.status.toUpperCase();
  $('taskStep').textContent=String(job?.step||0).padStart(2,'0')+' / 12';
  $('engineState').textContent=active?'WORKING':'READY';
  $('neuralLabel').textContent=active?'CONNECTED':'STANDBY';
  $('systemLabel').textContent=active?'HV EXECUTION ENGINE ACTIVE':'CORE ONLINE • LOCAL SECURITY ACTIVE';
  if(active){$('heroState').textContent=job.status==='approval'?'AWAITING USER AUTHORIZATION':'PROCESSING · '+modeNames[job.mode];}
  else $('heroState').textContent='SYSTEM READY FOR YOUR COMMAND';
  if(job && job.id===ui.lastJobId && job.status!==ui.lastJobStatus){
    ui.lastJobStatus=job.status;
    if(['completed','error','stopped'].includes(job.status)){
      loadMessages().catch(()=>{});
      if(job.status==='completed'&&job.answer){speak(job.answer.slice(0,650));toast('HV task completed')}
      if(job.status==='error'){addMessage('assistant',job.answer||'Task error','ERROR');toast(job.answer||'Task error')}
      if(job.status==='stopped'){addMessage('assistant',job.answer||'Stopped','STOPPED');toast('HV stopped')}
      window.HVParticles?.setState('idle');
    }
  }
}
function updateEvents(events){
  if(!events.length)return;
  if(events[events.length-1].id===ui.lastEventId)return;
  ui.lastEventId=events[events.length-1].id;
  const list=$('activityList');list.replaceChildren();
  events.slice(-18).reverse().forEach(event=>{
    const item=document.createElement('div');item.className='activity-item '+event.level.toLowerCase();
    const time=document.createElement('span');time.className='activity-time';time.textContent=event.time;
    const mark=document.createElement('span');mark.className='activity-mark';mark.textContent=({ERROR:'!',STOP:'■',APPROVAL:'◆',DONE:'✓',VISION:'◉',ACTION:'↳'})[event.level]||'◈';
    const body=document.createElement('span');body.textContent=event.text;
    item.append(time,mark,body);list.append(item);
  });
}
function reviewApproval(job){
  if(!job||job.status!=='approval'||!job.approval){if($('approvalDialog').open)$('approvalDialog').close();ui.shownApproval='';return}
  const key=job.id+':'+job.step;
  if(ui.shownApproval===key)return; ui.shownApproval=key;
  $('approvalSummary').textContent=job.approval.summary;
  $('approvalKind').textContent=job.approval.type.toUpperCase()+' • '+(job.approval.risk||'normal').toUpperCase();
  $('approvalArgs').textContent=JSON.stringify(job.approval.args_preview||{},null,2);
  if(!$('approvalDialog').open)$('approvalDialog').showModal();
}
async function approve(choice){
  const job=ui.state?.job;if(!job)return;
  await api('/api/approve',{id:job.id,choice});
  ui.shownApproval='';$('approvalDialog').close();
}
$('allowBtn').addEventListener('click',safe(()=>approve('allow')));
$('denyBtn').addEventListener('click',safe(()=>approve('deny')));
$('denyClose').addEventListener('click',safe(()=>approve('deny')));
$('approvalDialog').addEventListener('cancel',e=>{e.preventDefault();approve('deny').catch(()=>{})});
async function stop(){window.speechSynthesis?.cancel();await api('/api/stop',{});window.HVParticles?.setState('idle');toast('STOP sent to HV engine')}
$('stopSide').addEventListener('click',safe(stop));
function setPreview(state){
  if(ui.previewTab==='screen')return;
  const url=state.preview_url||'';
  const frame=$('previewFrame');
  if(url && frame.dataset.src!==url){frame.dataset.src=url;frame.src=url;frame.hidden=false;$('workspacePlaceholder').hidden=true;
    $('workspaceStatus').textContent='● LIVE HTML PROJECT'}
  else if(!url){frame.hidden=true;$('workspacePlaceholder').hidden=false;$('workspaceStatus').textContent='● NO ACTIVE PREVIEW'}
}
function showTab(tab){
  ui.previewTab=tab;
  document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));
  if(tab==='screen'){
    $('previewFrame').hidden=true;
    $('workspacePlaceholder').hidden=true;
    $('desktopFrame').hidden=false;
    refreshScreen();
  }else{
    $('desktopFrame').hidden=true;
    $('previewFrame').hidden=false;
    setPreview(ui.state||{});
  }
}
async function refreshScreen(){
  if(ui.previewTab!=='screen')return;
  const data=await api('/api/screenshot');$('desktopFrame').src='data:image/jpeg;base64,'+data.base64;
  $('workspaceStatus').textContent='● DESKTOP SNAPSHOT';
}
document.querySelectorAll('.tab').forEach(x=>x.addEventListener('click',safe(()=>showTab(x.dataset.tab))));
$('refreshPreview').addEventListener('click',safe(async()=>{
  if(ui.previewTab==='screen')await refreshScreen();
  else if($('previewFrame').dataset.src){const f=$('previewFrame');f.src=f.dataset.src;}else toast('No preview created yet');
}));
function speak(text){
  if(!ui.voice||!window.speechSynthesis)return;
  window.speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text.replace(/https?:\/\/\S+/g,'').slice(0,800));
  const lang=ui.state?.settings?.language||'auto';
  u.lang=lang==='auto'?( /[\u0600-\u06ff]/.test(text)?'ur-PK':'en-US'):lang;
  u.rate=ui.state?.settings?.personality==='professional'?.97:1.03;u.pitch=.85;u.volume=.85;
  const voices=speechSynthesis.getVoices();
  u.voice=voices.find(v=>v.lang.toLowerCase().startsWith(u.lang.slice(0,2).toLowerCase())&&/male|david|mark|guy|ryan/i.test(v.name)) || voices.find(v=>v.lang.toLowerCase().startsWith(u.lang.slice(0,2).toLowerCase())) || null;
  u.onstart=()=>{$('voiceBars').classList.add('active');window.HVParticles?.setState('speaking')};
  u.onend=u.onerror=()=>{$('voiceBars').classList.remove('active');window.HVParticles?.setState('idle')};
  window.speechSynthesis.speak(u);
}
$('voiceToggle').addEventListener('click',()=>{ui.voice=!ui.voice; if(!ui.voice){speechSynthesis.cancel();window.HVParticles?.setState('idle')} $('voiceToggle').textContent=ui.voice?'◖ VOICE ON':'◖ VOICE OFF';toast(ui.voice?'Voice responses enabled':'Voice muted')});
$('micBtn').addEventListener('click',()=>{
  const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SpeechRecognition){toast('Voice input needs Chrome/Edge Speech Recognition. Type a command instead.');return;}
  if(ui.recognizer){ui.recognizer.stop();return;}
  let r=new SpeechRecognition();ui.recognizer=r;r.lang=ui.state?.settings?.language==='ur-PK'?'ur-PK':'en-US';r.interimResults=false;r.continuous=false;
  r.onresult=e=>{$('prompt').value=(e.results[0]?.[0]?.transcript||'').trim();toast('Voice captured; press Send to execute')};
  r.onend=()=>{ui.recognizer=null;$('micBtn').classList.remove('listening');window.HVParticles?.setState('idle')};
  r.onerror=e=>toast('Microphone: '+e.error);
  try{r.start();$('micBtn').classList.add('listening');window.HVParticles?.setState('listening');toast('Listening...')}catch(e){toast(e.message)}
});
function openDialog(id){$(id).showModal()}
for(const b of document.querySelectorAll('[data-close]'))b.addEventListener('click',()=>$(b.dataset.close).close());
async function settingsOpen(){
  const s=ui.state?.settings||{};
  $('apiKey').value=''; $('apiKey').placeholder=s.has_key?'Key saved. Leave blank to keep existing key':'Paste your Gemini API key';
  $('modelInput').value=s.model||'gemini-2.5-flash';
  $('personalitySelect').value=s.personality||'friendly';$('languageSelect').value=s.language||'auto';
  openDialog('settingsDialog');
}
['settingsButton','settingsShortcut'].forEach(id=>$(id).addEventListener('click',safe(settingsOpen)));
$('saveSettings').addEventListener('click',safe(async()=>{
  const data={model:$('modelInput').value.trim(),personality:$('personalitySelect').value,language:$('languageSelect').value};
  if($('apiKey').value.trim())data.api_key=$('apiKey').value.trim();
  await api('/api/settings',data);$('apiKey').value='';$('settingsDialog').close();toast('HV settings saved')
}));
function element(tag,txt){const node=document.createElement(tag);node.textContent=txt;return node}
async function memoriesOpen(){
  const r=await api('/api/memories');const list=$('memoryList');list.replaceChildren();
  if(!r.items.length)list.append(element('p','No memories saved yet.'));
  r.items.forEach(m=>{const row=element('div','');row.className='record-row';const txt=element('span',m.content),del=element('button','×');del.title='Delete';del.onclick=safe(async()=>{await api('/api/memory/delete',{id:m.id});await memoriesOpen(false)});row.append(txt,del);list.append(row)});
  if(!$('memoryDialog').open)openDialog('memoryDialog');
}
$('memoryButton').addEventListener('click',safe(memoriesOpen));
$('addMemory').addEventListener('click',safe(async()=>{await api('/api/memory/add',{content:$('memoryText').value});$('memoryText').value='';await memoriesOpen();toast('Memory saved locally')}));
async function remindersOpen(){
  const r=await api('/api/reminders');const list=$('reminderList');list.replaceChildren();
  if(!r.items.length)list.append(element('p','No reminders yet.'));
  r.items.forEach(m=>{const row=element('div','');row.className='record-row';const txt=element('span',(m.active?'● ':'○ ')+m.note+' • '+m.due_at.replace('T',' ')+' • '+m.recurrence),del=element('button','×');del.title='Delete';del.onclick=safe(async()=>{await api('/api/reminder/delete',{id:m.id});await remindersOpen()});row.append(txt,del);list.append(row)});
  if(!$('remindersDialog').open)openDialog('remindersDialog');
}
$('remindersButton').addEventListener('click',safe(remindersOpen));
$('addReminder').addEventListener('click',safe(async()=>{await api('/api/reminder/add',{note:$('reminderText').value,due_at:$('reminderDate').value,recurrence:$('reminderRepeat').value});$('reminderText').value='';await remindersOpen();toast('Reminder created')}));
function notify(notices){
  for(const n of notices){if(ui.notificationIds.has(n.id))continue;ui.notificationIds.add(n.id);toast(n.text);speak(n.text)}
}
async function poll(){
  try{
    const data=await api('/api/state');ui.state=data;
    $('modelLabel').textContent=data.settings.model||'GEMINI ENGINE';
    $('voiceStatus').textContent=ui.voice?'VOICE ENABLED':'VOICE MUTED';
    setStatus(data.job);updateEvents(data.events);reviewApproval(data.job);setPreview(data);notify(data.notifications);
  }catch(err){$('systemLabel').textContent='HV SERVER DISCONNECTED';}
}
async function boot(){
  try{await poll();await loadMessages();if(!ui.state?.settings.has_key)toast('Open System Config and add your Gemini API key to activate HV Brain.');
    // Browser speech autoplay rules may require a click; Windows launcher speaks the startup line.
    document.addEventListener('pointerdown',()=>{if(!window._hvWelcomed){window._hvWelcomed=true;speak('HV systems online. Welcome back, boss.')}},{once:true});
  }catch(e){toast(e.message)}
  setInterval(poll,900);
}
boot();
})();
