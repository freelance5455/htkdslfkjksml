/* Original glowing dust-particle hologram. No character assets or copyrighted voices. */
(() => {
  'use strict';
  const canvas=document.getElementById('particleCanvas');
  const stage=document.getElementById('visualStage');
  if(!canvas || !stage) return;
  const ctx=canvas.getContext('2d',{alpha:true});
  const particles=[];
  let W=650,H=400,DPR=1,start=performance.now(),mode='idle',speaking=false,listen=false;
  let pointerX=0;
  const r=(a,b)=>a+Math.random()*(b-a);
  function shapePoint(i){
    // Human-like head, neck, shoulders, chest and upper arms constructed only from luminous dust.
    // Model coordinates: x ±175, y [-185,180], z ±100.
    let x,y,z;
    const part=Math.random();
    if(part<.45){ // head with narrowing jaw
      const theta=r(0,Math.PI*2),phi=Math.acos(r(-1,1));
      const yy=Math.cos(phi), xy=Math.sin(phi);
      const jaw= yy>.12 ? 1 : .78+.22*(yy+1)/1.12;
      x=Math.cos(theta)*68*xy*jaw;
      y=-104+91*yy;
      z=Math.sin(theta)*69*xy*jaw;
      // slightly flat face plane and cheek detail
      if(z>42 && y>-115 && Math.random()<.22) z=48+r(0,5);
    }else if(part<.55){ // neck
      const a=r(0,Math.PI*2),v=r(0,1);
      x=Math.cos(a)*(21+v*5);z=Math.sin(a)*(22+v*4);
      y=-20+v*51;
    }else if(part<.92){ // trapezoid torso
      const v=r(0,1),a=r(0,Math.PI*2);
      const width=110-(v*36),depth=48-v*11;
      x=width*Math.cos(a);
      z=depth*Math.sin(a);
      y=31+v*152;
      if(y<65 && Math.abs(x)>70) x*=1.16;
    }else{ // arms toward hands fade out
      const side=Math.random()<.5?-1:1,v=r(0,1),a=r(0,Math.PI*2);
      x=side*(113+v*37+Math.cos(a)*16);
      y=58+v*110;
      z=Math.sin(a)*25;
    }
    return {x,y,z};
  }
  for(let i=0;i<2100;i++){
    const p=shapePoint(i);
    particles.push({x:p.x,y:p.y,z:p.z,seed:r(0,100),size:r(.4,1.75),
       startX:r(-350,350),startY:r(-320,320),startZ:r(-120,120),
       opacity:r(.33,1),warm:Math.random()<.085});
  }
  function resize(){
    const box=stage.getBoundingClientRect();
    W=box.width; H=box.height;DPR=Math.min(2,window.devicePixelRatio||1);
    canvas.width=Math.round(W*DPR);canvas.height=Math.round(H*DPR);
    ctx.setTransform(DPR,0,0,DPR,0,0);
  }
  const ro=new ResizeObserver(resize);ro.observe(stage);resize();
  let last=0;
  function render(t){
    if(t-last<16){requestAnimationFrame(render);return;}last=t;
    ctx.clearRect(0,0,W,H);
    const sec=(t-start)/1000, entry=Math.min(1,Math.max(0,(sec-.15)/2.2));
    const eased=1-Math.pow(1-entry,3);
    const scale=Math.min(W/570,H/435)*1.08;
    const cx=W*.50,cy=H*.51;
    const rot=Math.sin(sec*.36)*.19+pointerX*.1;
    const spin=Math.cos(rot),sine=Math.sin(rot);
    const energy=(speaking?1.38:listen?1.18:1);
    // Moving circular HUD rings behind the dust figure.
    ctx.save();ctx.translate(cx,cy);ctx.strokeStyle='rgba(34,192,223,.11)';ctx.lineWidth=1;
    for(let k=0;k<3;k++){
      const radius=(146+k*41)*scale;
      ctx.beginPath();ctx.ellipse(0,7*scale,radius,radius*.56,.15,sec*(k%2?-.11:.12),sec*(k%2?-.11:.12)+Math.PI*1.28);ctx.stroke();
    }
    const rr=175*scale;
    for(let a=0;a<48;a++){
      let theta=(a/48)*Math.PI*2+sec*.12;
      let x=Math.cos(theta)*rr,y=Math.sin(theta)*rr*.92;
      ctx.strokeStyle=a%4===0?'rgba(74,226,239,.24)':'rgba(74,226,239,.09)';
      ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x*1.02,y*1.02);ctx.stroke();
    }
    ctx.restore();
    // sort by pseudo depth for volumetric appearance
    const mapped=[];
    for(let p of particles){
      const zz=p.z*spin-p.x*sine;
      const xx=p.z*sine+p.x*spin;
      const pulse=Math.sin(sec*1.9+p.seed)*1.6+(speaking?Math.sin(sec*14+p.seed)*2.1:0);
      const drift=(1-eased);
      const xp=(xx*eased+p.startX*drift+pulse)*scale;
      const yp=((p.y+Math.sin(sec*1.3+p.seed)*.7)*eased+p.startY*drift)*scale;
      const persp=370/(370-(zz*eased+p.startZ*drift)*.31);
      mapped.push({x:cx+xp*persp,y:cy+yp*persp,z:zz,p,alpha:persp});
    }
    mapped.sort((a,b)=>a.z-b.z);
    // Particle body + electric flecks, no source artwork required.
    for(const m of mapped){
      const {p,x,y,z}=m;
      if(x<-3||y<-3||x>W+3||y>H+3)continue;
      let a=p.opacity*(.47+.45*(z+90)/180);
      a=Math.max(.08,Math.min(.94,a))*(.6+.4*eased);
      const spark=Math.sin(sec*2.1+p.seed*2.5);
      if(spark>.96)a=Math.min(1,a+.37);
      let rad=p.size*scale*(.73+.28*m.alpha)*energy;
      if(spark>.98)rad*=1.6;
      ctx.fillStyle=p.warm?`rgba(245,189,111,${a*.78})`:`rgba(81,217,237,${a})`;
      ctx.beginPath();ctx.arc(x,y,Math.max(.35,rad),0,Math.PI*2);ctx.fill();
    }
    // Light particles orbit around the torso; subtle dust trails.
    for(let i=0;i<34;i++){
      let a=sec*(i%2?-.36:.35)+i*2.39996;
      let radius=(114+i%9*12)*scale;
      let x=cx+Math.cos(a)*radius,y=cy+Math.sin(a*1.6)*(75+i%11*8)*scale;
      let alpha=.12+.10*Math.sin(sec*2+i);
      ctx.fillStyle=`rgba(119,241,250,${alpha})`;
      ctx.beginPath();ctx.arc(x,y,Math.max(.3,(i%4===0?1.5:.7)*scale),0,Math.PI*2);ctx.fill();
    }
    requestAnimationFrame(render);
  }
  requestAnimationFrame(render);
  document.addEventListener('pointermove',ev=>{pointerX=(ev.clientX/window.innerWidth-.5)*2});
  window.HVParticles={setState(v){mode=v;listen=v==='listening';speaking=v==='speaking';}, restart(){start=performance.now()}};
})();
