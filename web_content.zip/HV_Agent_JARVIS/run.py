"""Windows: python run.py. Automatically opens a full-window HV interface."""
from __future__ import annotations
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from hvagent.server import HVServer

ROOT=Path(__file__).resolve().parent

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        return s.getsockname()[1]

def startup_chime():
    if platform.system() != 'Windows': return
    try:
        import winsound
        winsound.PlaySound(str(ROOT/'assets'/'hv_boot.wav'), winsound.SND_FILENAME|winsound.SND_ASYNC)
    except Exception: pass

def windows_greeting():
    # Windows System.Speech local TTS; no cloned movie character voice.
    if platform.system()!='Windows': return
    ps=(shutil.which('powershell.exe') or shutil.which('powershell'))
    if not ps: return
    command=("Add-Type -AssemblyName System.Speech; "
             "$v=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
             "$v.Rate=-1; $v.Speak('HV systems online. Welcome back, boss.')")
    try: subprocess.Popen([ps,'-NoProfile','-NonInteractive','-Command',command],
                          creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),
                          stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except OSError: pass

def open_ui(url):
    if platform.system()=='Windows':
        edge=shutil.which('msedge.exe')
        if not edge:
            for loc in [os.environ.get('PROGRAMFILES(X86)',r'C:\Program Files (x86)'),
                        os.environ.get('PROGRAMFILES',r'C:\Program Files')]:
                path=Path(loc)/'Microsoft'/'Edge'/'Application'/'msedge.exe'
                if path.is_file(): edge=str(path);break
        if edge:
            subprocess.Popen([edge,'--app='+url,'--window-size=1500,930'])
            return
    webbrowser.open(url)

if __name__=='__main__':
    os.chdir(ROOT)
    port=free_port()
    server=HVServer(('127.0.0.1',port),ROOT)
    url=f'http://127.0.0.1:{port}/'
    print('\nHV AGENT — JARVIS INTERFACE')
    print('OPEN:',url)
    print('Local only | press CTRL+C to quit\n')
    threading.Thread(target=lambda:(time.sleep(.65),open_ui(url)),daemon=True).start()
    threading.Thread(target=lambda:(time.sleep(1.2),startup_chime(),time.sleep(2.4),windows_greeting()),daemon=True).start()
    try: server.serve_forever(poll_interval=.3)
    except KeyboardInterrupt: print('Shutting down HV...')
    finally:server.server_close()
