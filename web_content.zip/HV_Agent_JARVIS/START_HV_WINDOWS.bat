@echo off
setlocal
cd /d "%~dp0"
title HV AGENT - JARVIS COMMAND CENTER
color 0B
where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON=py -3"
) else (
  set "PYTHON=python"
)
if not exist ".venv\Scripts\python.exe" (
  echo [HV] Preparing local Python environment...
  %PYTHON% -m venv .venv
  if errorlevel 1 (
    echo [ERROR] Python 3.10+ is required. Install Python from python.org and select Add to PATH.
    pause
    exit /b 1
  )
)
echo [HV] Installing required packages (first launch only, or updates)...
".venv\Scripts\python.exe" -m pip install -r requirements.txt --disable-pip-version-check
if errorlevel 1 (
  echo [ERROR] Package installation failed. Check internet and Python installation.
  pause
  exit /b 1
)
echo [HV] Booting HV Command Center...
".venv\Scripts\python.exe" run.py
if errorlevel 1 pause
endlocal
