GASTEI AÍ — protótipo web atualizado

RECURSOS
- Tela de boas-vindas, perfil com foto e saudação.
- Gastos por data, categoria, pessoa, Pix ou dinheiro.
- Comprovantes anexados localmente e link para abrir cada um.
- Modo kids simplificado para registrar gastos de um perfil infantil.
- Adicionar e excluir perfis; a exclusão do perfil não apaga gastos anteriores.
- Ditado da descrição por voz (navegadores compatíveis) e leitura de respostas por voz.
- Conexão opcional com OpenRouter para ideias financeiras e leitura de fotos de comprovantes (o app preenche rascunho para revisar antes de salvar).
- Lembretes locais de contas de água/luz por notificação do navegador.
- Exportação de relatório PNG e planilha Excel (.xlsx) com abas Gastos e Resumo.

COMO ABRIR
Extraia o ZIP e abra index.html em navegador moderno. Para ativar notificações e permissões de voz, normalmente é preciso abrir por HTTPS ou localhost. Se necessário, na pasta extraída rode `python3 -m http.server 8000` e abra `http://localhost:8000`.

OPENROUTER
O usuário precisa fornecer a própria chave API e selecionar/usar um modelo disponível na conta. A chave fica apenas na sessão da aba (não é salva no servidor). Ao pedir ideias, o app envia totais, categorias, pagamentos e até 12 descrições recentes; não envia nomes de pessoas nem anexos. Ao clicar em “Ler foto com IA”, a foto selecionada é enviada ao OpenRouter para extrair descrição, valor e categoria; isso pode expor dados impressos no comprovante e pode gerar cobrança conforme a conta/modelo. Não envie fotos sensíveis. A leitura requer modelo compatível com visão; PDF só pode ser anexado/aberto, não analisado.

PRIVACIDADE E LIMITES
Este é um protótipo local, não um aplicativo publicado em lojas. Os dados e anexos ficam no navegador/aparelho e não sincronizam entre aparelhos. Lembretes usam notificações do navegador e só disparam com o app aberto neste protótipo; não é um serviço de push em segundo plano garantido. Recursos de voz dependem do navegador, idioma e permissões. Para produção: servidor seguro, autenticação, proteção de chaves, backups, sincronização, políticas para dados de crianças e serviço confiável de notificações.
