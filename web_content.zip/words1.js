NORSK_ADD({
  themes: {
    klienter: {
      w: [
        ["massasje","масаж"],["massør","масажист"],["klient","клієнт"],["time","запис, сеанс (на певний час)"],
        ["rygg","спина"],["nakke","шия, потилиця"],["skulder","плече"],["smerte","біль"],
        ["muskel","м'яз"],["spenning","напруга"],["trykk","тиск, сила натиску"],["olje","олія"],
        ["benk","кушетка, лава"],["håndkle","рушник"],["avtale","домовленість, запис"],["pris","ціна"],
        ["betaling","оплата"],["kvittering","чек, квитанція"],["avbestilling","скасування запису"],["varighet","тривалість"],
        ["behandling","процедура, лікування"],["stiv","скутий, задубілий"],["øm","болючий на дотик"],["ledd","суглоб"],
        ["hode","голова"],["bein","нога (також: кістка)"],["arm","рука"],["å slappe av","розслаблятися"],
        ["å puste","дихати"],["å snu seg","перевернутися"]
      ],
      p: [
        ["Velkommen!","Ласкаво просимо!"],
        ["Hvordan har du det i dag?","Як ви сьогодні?"],
        ["Hva kan jeg hjelpe deg med?","Чим можу допомогти?"],
        ["Har du vondt noe sted?","У вас щось болить?"],
        ["Hvor har du vondt?","Де у вас болить?"],
        ["Er trykket greit?","Сила натиску нормальна?"],
        ["Litt hardere, eller litt mykere?","Трохи сильніше чи трохи м'якше?"],
        ["Si fra hvis det gjør vondt.","Скажіть, якщо буде боляче."],
        ["Du kan ta av deg klærne.","Ви можете роздягнутися."],
        ["Legg deg på magen, takk.","Ляжте на живіт, будь ласка."],
        ["Snu deg på ryggen.","Переверніться на спину."],
        ["Slapp helt av.","Повністю розслабтеся."],
        ["Pust rolig.","Дихайте спокійно."],
        ["Behandlingen varer i en time.","Сеанс триває одну годину."],
        ["Vil du bestille ny time?","Бажаєте записатися ще раз?"],
        ["Hvilken tid passer for deg?","Який час вам підходить?"],
        ["Du kan betale med kort.","Ви можете заплатити карткою."],
        ["Du må avbestille senest 24 timer før.","Скасувати запис треба щонайпізніше за 24 години."],
        ["Drikk mye vann etterpå.","Пийте багато води після цього."],
        ["Det er normalt å være litt støl.","Це нормально, що м'язи трохи болітимуть."],
        ["Er det noe jeg bør vite?","Чи є щось, що я маю знати?"],
        ["Har du allergi?","У вас є алергія?"],
        ["Har du vært hos legen for dette?","Ви були з цим у лікаря?"],
        ["Hvor lenge har du hatt smertene?","Як довго у вас цей біль?"],
        ["Takk for i dag!","Дякую за сьогодні!"]
      ],
      s: [
        ["Jeg jobber som massør.","Я працюю масажистом."],
        ["Mange klienter har vondt i nakken og skuldrene.","У багатьох клієнтів болять шия й плечі."],
        ["Etter behandlingen kan du føle deg sliten.","Після процедури ви можете відчувати втому."],
        ["Jeg anbefaler å komme hver andre uke.","Я раджу приходити раз на два тижні."],
        ["Smertene kommer av at du sitter mye foran datamaskinen.","Біль виникає через те, що ви багато сидите за комп'ютером."],
        ["Du bør strekke ut musklene hver dag.","Вам слід розтягувати м'язи щодня."],
        ["Jeg kan ikke behandle deg hvis du har feber.","Я не можу робити вам масаж, якщо у вас температура."],
        ["Hvis du har en skade, må du snakke med legen først.","Якщо у вас травма, спершу треба поговорити з лікарем."],
        ["Timen koster seks hundre kroner.","Сеанс коштує шістсот крон."],
        ["Du får kvittering på e-post.","Ви отримаєте чек на електронну пошту."],
        ["Beklager, men jeg har ikke ledig tid i dag.","Вибачте, але сьогодні в мене немає вільного часу."],
        ["Neste ledige time er på torsdag klokken ti.","Найближчий вільний час у четвер о десятій."],
        ["Kan du komme ti minutter før timen?","Чи можете ви прийти за десять хвилин до сеансу?"],
        ["Hvis du kommer for sent, blir behandlingen kortere.","Якщо ви запізнитеся, сеанс буде коротшим."],
        ["Jeg bruker olje som ikke har sterk lukt.","Я використовую олію без різкого запаху."],
        ["Fortell meg hvis det er for kaldt i rommet.","Скажіть мені, якщо в кімнаті занадто холодно."],
        ["Du kan legge klærne dine på stolen.","Ви можете покласти свій одяг на стілець."],
        ["Jeg forstår ikke helt. Kan du si det en gang til?","Я не зовсім розумію. Чи можете повторити?"],
        ["Jeg lærer norsk, så jeg snakker litt sakte.","Я вчу норвезьку, тому говорю трохи повільно."],
        ["Det var hyggelig å møte deg.","Було приємно з вами познайомитися."]
      ]
    },

    nav: {
      w: [
        ["søknad","заява"],["å søke","подавати заяву, шукати"],["skjema","форма, бланк"],["vedlegg","додаток (документ)"],
        ["dokumentasjon","документи, підтвердження"],["saksbehandler","працівник, що веде справу"],["vedtak","рішення (органу)"],["klage","скарга, оскарження"],
        ["frist","кінцевий термін"],["stønad","допомога, виплата"],["dagpenger","допомога по безробіттю"],["sykepenger","виплати по хворобі"],
        ["sosialhjelp","соціальна допомога"],["bostøtte","житлова субсидія"],["skatt","податок"],["skattekort","податкова картка"],
        ["fødselsnummer","особистий ідентифікаційний номер"],["bankkonto","банківський рахунок"],["inntekt","дохід"],["utgift","витрата"],
        ["husleie","орендна плата"],["leieavtale","договір оренди"],["kontaktperson","контактна особа"],["tolk","перекладач"],
        ["fastlege","сімейний лікар"],["legeerklæring","медична довідка"],["melding","повідомлення"],["svar","відповідь"],
        ["BankID","BankID (електронна ідентифікація)"],["opplysninger","відомості, інформація"]
      ],
      p: [
        ["Jeg vil søke om dagpenger.","Я хочу подати заяву на допомогу по безробіттю."],
        ["Hvor finner jeg skjemaet?","Де я можу знайти форму?"],
        ["Jeg trenger hjelp til å fylle ut skjemaet.","Мені потрібна допомога із заповненням форми."],
        ["Kan du forklare dette enklere?","Чи можете пояснити це простіше?"],
        ["Jeg forstår ikke dette brevet.","Я не розумію цього листа."],
        ["Kan jeg få en tolk?","Чи можу я отримати перекладача?"],
        ["Hvem er saksbehandleren min?","Хто веде мою справу?"],
        ["Når får jeg svar?","Коли я отримаю відповідь?"],
        ["Har dere mottatt søknaden min?","Ви отримали мою заяву?"],
        ["Hvilke dokumenter må jeg levere?","Які документи мені треба подати?"],
        ["Jeg har sendt inn alle vedleggene.","Я надіслав усі додатки."],
        ["Jeg vil klage på vedtaket.","Я хочу оскаржити рішення."],
        ["Når er fristen?","Який кінцевий термін?"],
        ["Jeg har en avtale klokken ni.","У мене запис на дев'яту годину."],
        ["Jeg vil bestille time.","Я хочу записатися на прийом."],
        ["Kan du ringe meg tilbake?","Чи можете ви мені передзвонити?"],
        ["Jeg har ikke fått pengene ennå.","Я ще не отримав гроші."],
        ["Hvor mye får jeg utbetalt?","Скільки мені виплатять?"],
        ["Situasjonen min har endret seg.","Моя ситуація змінилася."],
        ["Jeg har mistet jobben.","Я втратив роботу."],
        ["Jeg er syk og kan ikke jobbe.","Я хворий і не можу працювати."],
        ["Jeg trenger bekreftelse skriftlig.","Мені потрібне підтвердження письмово."],
        ["Kan jeg få en kopi av vedtaket?","Чи можу я отримати копію рішення?"],
        ["Jeg logger inn med BankID.","Я входжу через BankID."],
        ["Takk for hjelpen.","Дякую за допомогу."]
      ],
      s: [
        ["Jeg har bodd i Norge en stund.","Я живу в Норвегії вже деякий час."],
        ["Jeg bor alene i en liten leilighet.","Я живу сам у невеликій квартирі."],
        ["Jeg har fått et brev fra NAV.","Я отримав листа від NAV."],
        ["Brevet sier at jeg må levere flere opplysninger.","У листі сказано, що я маю подати більше відомостей."],
        ["Jeg må levere dokumentene innen fredag.","Я маю подати документи до п'ятниці."],
        ["Hvis du ikke svarer innen fristen, kan saken bli avslått.","Якщо ви не відповісте до кінцевого терміну, справу можуть відхилити."],
        ["Du har rett til å klage på vedtaket.","Ви маєте право оскаржити рішення."],
        ["Saksbehandleren trenger flere opplysninger om inntekten din.","Працівникові потрібно більше відомостей про ваш дохід."],
        ["Jeg har ikke inntekt for øyeblikket.","Зараз у мене немає доходу."],
        ["Utgiftene mine er høyere enn inntekten min.","Мої витрати перевищують мій дохід."],
        ["Jeg betaler husleie hver måned.","Я щомісяця плачу орендну плату."],
        ["Jeg må oppdatere kontaktinformasjonen min.","Мені треба оновити свої контактні дані."],
        ["Du kan sende meldingen via nav.no.","Ви можете надіслати повідомлення через nav.no."],
        ["Jeg ber om at dere vurderer saken min på nytt.","Прошу вас переглянути мою справу ще раз."],
        ["Jeg har legeerklæring fra fastlegen min.","У мене є медична довідка від мого сімейного лікаря."],
        ["Jeg ønsker å komme tilbake i arbeid.","Я хочу повернутися до роботи."],
        ["Jeg trenger mer tid til å lære norsk.","Мені потрібно більше часу, щоб вивчити норвезьку."],
        ["Kan vi ta møtet på norsk? Jeg prøver å snakke så mye jeg kan.","Чи можемо ми провести зустріч норвезькою? Я намагаюся говорити якомога більше."],
        ["Etter møtet fikk jeg en skriftlig oppsummering.","Після зустрічі я отримав письмовий підсумок."],
        ["Jeg har ikke forstått alt, så jeg ringer tilbake.","Я зрозумів не все, тому передзвоню."]
      ]
    },

    hverdag: {
      w: [
        ["butikk","магазин"],["å handle","робити покупки"],["mat","їжа"],["brød","хліб"],
        ["melk","молоко"],["ost","сир"],["egg","яйця"],["å betale","платити"],
        ["billett","квиток"],["buss","автобус"],["tog","потяг"],["holdeplass","зупинка"],
        ["vær","погода"],["regn","дощ"],["kald","холодний"],["leilighet","квартира"],
        ["nabo","сусід"],["lege","лікар"],["apotek","аптека"],["resept","рецепт"],
        ["hodepine","головний біль"],["arbeid","робота"],["kollega","колега"],["helg","вихідні"],
        ["ferie","відпустка"],["venn","друг"],["familie","сім'я"],["mobil","мобільний телефон"],
        ["regning","рахунок до сплати"],["post","пошта"]
      ],
      p: [
        ["God morgen!","Доброго ранку!"],
        ["Hvordan går det?","Як справи?"],
        ["Det går bra, takk.","Добре, дякую."],
        ["Hyggelig å møte deg.","Приємно познайомитися."],
        ["Unnskyld, hvor er toalettet?","Вибачте, де туалет?"],
        ["Kan du hjelpe meg?","Чи можете мені допомогти?"],
        ["Jeg forstår ikke.","Я не розумію."],
        ["Kan du si det en gang til?","Чи можете повторити ще раз?"],
        ["Kan du snakke litt saktere?","Чи можете говорити трохи повільніше?"],
        ["Hva betyr det?","Що це означає?"],
        ["Hvor mye koster det?","Скільки це коштує?"],
        ["Jeg tar den.","Я візьму це."],
        ["Kan jeg betale med kort?","Чи можу я заплатити карткою?"],
        ["Jeg leter etter apoteket.","Я шукаю аптеку."],
        ["Hvilken buss går til sentrum?","Який автобус їде до центру?"],
        ["Når går neste tog?","Коли наступний потяг?"],
        ["Jeg vil gjerne bestille time hos legen.","Я хотів би записатися до лікаря."],
        ["Jeg har vondt i hodet.","У мене болить голова."],
        ["Jeg trenger medisin mot forkjølelse.","Мені потрібні ліки від застуди."],
        ["Hva skal du gjøre i helgen?","Що ти робитимеш на вихідних?"],
        ["Skal vi ta en kaffe?","Вип'ємо кави?"],
        ["Jeg har ikke tid nå.","Зараз у мене немає часу."],
        ["Jeg kommer litt for sent.","Я трохи запізнюся."],
        ["Ha en fin dag!","Гарного дня!"],
        ["Vi ses!","Побачимось!"]
      ],
      s: [
        ["Jeg står opp klokken seks hver morgen.","Я встаю о шостій щоранку."],
        ["Det regner mye om høsten.","Восени багато дощів."],
        ["Jeg sykler til jobben når det er fint vær.","Я їжджу на роботу велосипедом, коли гарна погода."],
        ["Naboen min er veldig hyggelig.","Мій сусід дуже приємний."],
        ["Jeg kjøper brød og melk i butikken hver uke.","Я щотижня купую хліб і молоко в магазині."],
        ["Bussen var forsinket, så jeg kom for sent.","Автобус запізнився, тому я прийшов пізно."],
        ["Jeg må gå til apoteket og hente en resept.","Мені треба піти в аптеку й отримати за рецептом."],
        ["Legen sa at jeg må hvile noen dager.","Лікар сказав, що мені треба відпочити кілька днів."],
        ["Jeg liker å bade i sjøen selv om vannet er kaldt.","Я люблю купатися в морі, навіть коли вода холодна."],
        ["I helgen skal jeg på tur i skogen.","На вихідних я піду на прогулянку в ліс."],
        ["Jeg skal ringe til familien min i kveld.","Увечері я зателефоную своїй сім'ї."],
        ["Jeg lærer norsk fordi jeg vil forstå og bli forstått.","Я вчу норвезьку, бо хочу розуміти й бути зрозумілим."],
        ["Jeg synes norsk grammatikk er vanskelig, men jeg gjør fremskritt.","Мені здається, що норвезька граматика складна, але я роблю успіхи."],
        ["Kan du anbefale en god restaurant?","Чи можете порадити гарний ресторан?"],
        ["Telefonen min er ødelagt, og jeg må kjøpe en ny.","Мій телефон зламаний, і мені треба купити новий."],
        ["Jeg har fått en regning som jeg må betale innen fredag.","Я отримав рахунок, який маю сплатити до п'ятниці."],
        ["Hvis det blir fint vær, tar jeg sykkelen.","Якщо буде гарна погода, я поїду на велосипеді."],
        ["Jeg savner familien min, men vi snakker sammen hver uke.","Я сумую за сім'єю, але ми розмовляємо щотижня."],
        ["Takk for at du hjalp meg!","Дякую, що допомогли мені!"],
        ["Jeg har ikke tid til å handle i dag.","Сьогодні в мене немає часу на покупки."]
      ]
    }
  },

  reading: [
    {
      lvl: "A2", title: "Е-пошта від подруги",
      text: "Hei Anna! Jeg skriver til deg fordi jeg har flyttet til en ny leilighet i Bergen. Den ligger nær sentrum, og jeg kan gå til jobben på ti minutter. Leiligheten er liten, men lys og fin. Neste lørdag skal jeg ha en liten innflyttingsfest klokken fem. Kan du komme? Du kan gjerne ta med noe å drikke. Hilsen Mari",
      uk: "Привіт, Анно! Пишу тобі, бо я переїхала в нову квартиру в Бергені. Вона розташована поруч із центром, і до роботи я можу дійти за десять хвилин. Квартира маленька, але світла й гарна. Наступної суботи о п'ятій я влаштовую невелику вечірку з нагоди новосілля. Ти зможеш прийти? Можеш узяти щось попити. З привітом, Марі",
      q: [
        ["Hvor bor Mari nå?", ["I Bergen", "I Oslo", "I Stavanger"], 0],
        ["Hvor lang tid tar det å gå til jobb?", ["Fem minutter", "Ti minutter", "Tjue minutter"], 1],
        ["Hva skal Mari gjøre på lørdag?", ["Jobbe", "Ha en fest", "Flytte"], 1]
      ]
    },
    {
      lvl: "A2–B1", title: "Brev fra NAV",
      text: "Hei! Vi har mottatt søknaden din om dagpenger. For å kunne behandle saken trenger vi flere opplysninger. Du må sende oss en kopi av arbeidsavtalen din og dokumentasjon på hvorfor du ikke lenger har jobb. Vi må ha dokumentene innen 15. november. Hvis vi ikke får dem i tide, kan søknaden bli avslått. Du kan sende dokumentene via nav.no eller levere dem på kontoret. Hilsen NAV",
      uk: "Привіт! Ми отримали вашу заяву на допомогу по безробіттю. Щоб розглянути справу, нам потрібні додаткові відомості. Ви маєте надіслати нам копію трудового договору та документи, що підтверджують, чому у вас більше немає роботи. Ми маємо отримати документи до 15 листопада. Якщо ми не отримаємо їх вчасно, заяву можуть відхилити. Ви можете надіслати документи через nav.no або подати їх в офісі. З повагою, NAV",
      q: [
        ["Hva trenger NAV fra deg?", ["Flere dokumenter", "Penger", "En ny søknad"], 0],
        ["Når er fristen?", ["15. oktober", "15. november", "15. desember"], 1],
        ["Hva kan skje hvis dokumentene kommer for sent?", ["Du får mer penger", "Søknaden kan bli avslått", "Du må flytte"], 1],
        ["Hvordan kan du sende dokumentene?", ["Bare per post", "Via nav.no eller på kontoret", "Bare på telefon"], 1]
      ]
    },
    {
      lvl: "B1", title: "Bading i sjøen om vinteren",
      text: "Stadig flere nordmenn bader i sjøen hele året. Mange mener at kaldt vann gir mer energi og bedre humør. Ekspertene sier at det er viktig å gå sakte ut i vannet og aldri bade alene. Man bør også ha varme klær og en varm drikke klar etter badet. De som har hjerteproblemer eller høyt blodtrykk, bør snakke med legen før de begynner.",
      uk: "Дедалі більше норвежців купаються в морі цілий рік. Багато хто вважає, що холодна вода додає енергії та покращує настрій. Експерти кажуть, що важливо заходити у воду повільно й ніколи не купатися наодинці. Після купання також слід мати теплий одяг і гарячий напій. Тим, хто має проблеми із серцем або високий тиск, варто поговорити з лікарем, перш ніж починати.",
      q: [
        ["Hva mener mange som bader om vinteren?", ["Det gir mer energi og bedre humør", "Det er farlig", "Det er dyrt"], 0],
        ["Hva sier ekspertene?", ["Man bør bade alene", "Man bør gå sakte ut i vannet og ikke bade alene", "Man bør bade så lenge som mulig"], 1],
        ["Hvem bør snakke med legen først?", ["Alle barn", "De som har hjerteproblemer eller høyt blodtrykk", "Bare eldre mennesker"], 1]
      ]
    }
  ],

  writing: [
    {
      lvl: "A2", n: "40–60",
      uk: "Напишіть коротке повідомлення другові й запросіть його на вечерю.",
      no: "Skriv en kort e-post til en venn og inviter ham på middag.",
      ph: [["Hei! / Hei Ola!","Привіт!"],["Jeg vil gjerne invitere deg på middag.","Я хочу запросити тебе на вечерю."],["Kan du komme på lørdag klokken seks?","Ти можеш прийти в суботу о шостій?"],["Gi meg beskjed så snart som mulig.","Дай мені знати якнайшвидше."],["Hilsen Mykhailo","З привітом, ..."]]
    },
    {
      lvl: "A2", n: "40–60",
      uk: "Ви не можете прийти до лікаря. Напишіть повідомлення і попросіть новий час.",
      no: "Du kan ikke komme til legen. Skriv en melding og be om en ny time.",
      ph: [["Hei, jeg har time hos dere på torsdag.","Добрий день, у мене запис до вас на четвер."],["Dessverre kan jeg ikke komme.","На жаль, я не зможу прийти."],["Kan jeg få en ny time neste uke?","Чи можу я отримати новий час наступного тижня?"],["Beklager ulempen.","Вибачте за незручності."],["Med vennlig hilsen","З повагою"]]
    },
    {
      lvl: "B1", n: "80–100",
      uk: "Ви не отримали відповіді на свою заяву. Напишіть листа до NAV.",
      no: "Du har ikke fått svar på søknaden din. Skriv en e-post til NAV.",
      ph: [["Jeg skriver til dere angående søknaden min.","Пишу вам щодо моєї заяви."],["Jeg sendte søknaden for tre uker siden.","Я надіслав заяву три тижні тому."],["Jeg har ikke fått noe svar ennå.","Я ще не отримав жодної відповіді."],["Kan dere si hvor langt saken har kommet?","Чи можете сказати, на якому етапі справа?"],["Jeg trenger pengene for å betale husleien.","Мені потрібні гроші, щоб платити за житло."],["Jeg ser frem til svar fra dere.","Чекаю на вашу відповідь."]]
    },
    {
      lvl: "B1", n: "80–100",
      uk: "Розкажіть про свою роботу та що вам у ній подобається найбільше.",
      no: "Fortell om jobben din og hva du liker best med den.",
      ph: [["Jeg jobber som ...","Я працюю ..."],["Det jeg liker best, er ...","Найбільше мені подобається ..."],["Jeg møter mange forskjellige mennesker.","Я зустрічаю багато різних людей."],["Noen ganger er jobben krevende, men ...","Іноді робота виснажлива, але ..."],["Jeg er glad for at jeg kan hjelpe andre.","Я радий, що можу допомагати іншим."]]
    },
    {
      lvl: "B1", n: "80–100",
      uk: "Клієнт хоче скасувати запис. Напишіть ввічливу відповідь.",
      no: "En klient vil avbestille en time. Skriv et høflig svar.",
      ph: [["Takk for beskjeden.","Дякую за повідомлення."],["Det er helt greit at du avbestiller timen.","Нічого страшного, що ви скасовуєте запис."],["Husk at avbestilling må skje senest 24 timer før.","Пам'ятайте, що скасувати треба щонайпізніше за 24 години."],["Vil du bestille en ny time?","Бажаєте записатися на інший час?"],["Jeg har ledig tid på tirsdag og fredag.","У мене є вільний час у вівторок і п'ятницю."]]
    },
    {
      lvl: "B1", n: "80–120",
      uk: "Напишіть, що ви робите у вільний час.",
      no: "Skriv om hva du gjør i fritiden.",
      ph: [["I fritiden liker jeg å ...","У вільний час я люблю ..."],["Når det er fint vær, ...","Коли гарна погода, ..."],["Jeg bruker mye tid på ...","Я проводжу багато часу ..."],["Det gir meg energi og ro.","Це дає мені енергію та спокій."],["I helgene pleier jeg å ...","На вихідних я зазвичай ..."]]
    }
  ],

  speaking: [
    {
      lvl: "A2", uk: "Розкажіть про себе: ім'я, де живете, чим займаєтесь.",
      no: "Presenter deg selv: navn, hvor du bor og hva du jobber med.",
      ph: [["Jeg heter ... og kommer fra Ukraina.","Мене звати ..., я з України."],["Jeg bor i ...","Я живу в ..."],["Jeg jobber som ...","Я працюю ..."]]
    },
    {
      lvl: "A2", uk: "Розкажіть про звичайний день.",
      no: "Fortell om en vanlig dag.",
      ph: [["Først står jeg opp klokken ...","Спочатку я встаю о ..."],["Etterpå går jeg til jobben.","Потім я йду на роботу."],["På kvelden pleier jeg å ...","Увечері я зазвичай ..."]]
    },
    {
      lvl: "A2", uk: "Розкажіть про свою сім'ю.",
      no: "Fortell om familien din.",
      ph: [["Jeg har en bror som heter ...","У мене є брат, якого звати ..."],["Han bor i ...","Він живе в ..."],["Vi snakker sammen hver uke.","Ми розмовляємо щотижня."]]
    },
    {
      lvl: "A2", uk: "Опишіть своє житло.",
      no: "Beskriv hjemmet ditt.",
      ph: [["Jeg bor i en leilighet.","Я живу в квартирі."],["Det er to rom og et lite kjøkken.","Є дві кімнати й маленька кухня."],["Jeg trives godt her.","Мені тут добре."]]
    },
    {
      lvl: "B1", uk: "Що ви любите робити у вільний час? Поясніть чому.",
      no: "Hva liker du å gjøre i fritiden, og hvorfor?",
      ph: [["Jeg liker best å ...","Найбільше я люблю ..."],["Det er fordi ...","Це тому, що ..."],["For meg er det viktig å ...","Для мене важливо ..."]]
    },
    {
      lvl: "B1", uk: "Ви телефонуєте до NAV із запитанням. Що ви скажете?",
      no: "Du ringer til NAV for å stille et spørsmål. Hva sier du?",
      ph: [["Hei, jeg ringer angående søknaden min.","Добрий день, я телефоную щодо моєї заяви."],["Kan du forklare hva som står i brevet?","Чи можете пояснити, що написано в листі?"],["Kan du gjenta det, takk?","Чи можете повторити, будь ласка?"]]
    },
    {
      lvl: "B1", uk: "Розкажіть про подорож, у якій ви були.",
      no: "Fortell om en reise du har vært på.",
      ph: [["I fjor reiste jeg til ...","Торік я їздив до ..."],["Vi bodde på ... og så ...","Ми жили в ... і бачили ..."],["Det beste med turen var ...","Найкращим у подорожі було ..."]]
    },
    {
      lvl: "B1", uk: "Які переваги й недоліки життя в Норвегії?",
      no: "Hva er fordeler og ulemper med å bo i Norge?",
      ph: [["En fordel er at ...","Перевага в тому, що ..."],["En ulempe er at ...","Недолік у тому, що ..."],["Alt i alt synes jeg at ...","Загалом, мені здається, що ..."]]
    }
  ]
});
