વિદ્યાર્થી હાજરી એપ

આ ZIPમાં સંપૂર્ણ standalone HTML એપ છે.

Features:
- Login નથી
- વિદ્યાર્થી નામ + 10 અંકનો મોબાઈલ નંબર
- Add bug fix: button/Enter બંનેથી વિદ્યાર્થી ઉમેરાય
- Default status = હાજર
- હાજર અને ગેરહાજર બંને buttons શરૂઆતથી દેખાય
- ગેરહાજર કર્યા પછી જ WhatsApp + SMS buttons દેખાય
- પાછા હાજર કરવાથી બંને message buttons છુપાય
- LocalStorage persistence
- Search
- Attendance report
- CSV export
- Delete
- WhatsApp માટે Android intent + web fallback
- SMS app માટે sms: link
- Browser history back support
- Capacitorમાં wrap કરશો તો Android back button handler પણ તૈયાર છે

ઉપયોગ:
index.html ને browserમાં ખોલો. Android app બનાવવા માટે આ web app ને Capacitor/WebView projectમાં મૂકી શકાય છે.
