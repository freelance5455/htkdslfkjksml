function toggleMenu() {
    const navMenu = document.getElementById("navMenu");

    if (navMenu) {
        navMenu.classList.toggle("show");
    }
}


function enterApp() {
    window.location.href = "about.html";
}


function searchCourses() {

    const searchInput = document.getElementById("courseSearch");

    if (!searchInput) {
        return;
    }

    const searchText = searchInput.value.toLowerCase();

    const faculties = document.querySelectorAll(".faculty-card");

    faculties.forEach(function(faculty) {

        const courses = faculty.querySelectorAll(".course-item");

        let facultyHasMatch = false;

        courses.forEach(function(course) {

            const courseText = course.textContent.toLowerCase();

            if (courseText.includes(searchText)) {
                course.style.display = "block";
                facultyHasMatch = true;
            } else {
                course.style.display = "none";
            }

        });

        if (searchText === "") {
            faculty.style.display = "block";

        } else if (facultyHasMatch) {
            faculty.style.display = "block";

        } else {
            faculty.style.display = "none";
        }

    });
}

function searchCutoff() {

    const searchInput = document.getElementById("cutoffSearch");

    if (!searchInput) {
        return;
    }

    const searchText = searchInput.value.toLowerCase();

    const cards = document.querySelectorAll(".cutoff-card");

    cards.forEach(function(card) {

        const rows = card.querySelectorAll(
            ".cutoff-row:not(.cutoff-title)"
        );

        let hasMatch = false;

        rows.forEach(function(row) {

            const text = row.textContent.toLowerCase();

            if (text.includes(searchText)) {

                row.style.display = "grid";
                hasMatch = true;

            } else {

                row.style.display = "none";

            }

        });

        if (searchText === "") {

            card.style.display = "block";

            rows.forEach(function(row) {
                row.style.display = "grid";
            });

        } else if (hasMatch) {

            card.style.display = "block";

        } else {

            card.style.display = "none";

        }

    });
}