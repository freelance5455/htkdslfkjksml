# Wildbound: install on your Android phone

The game is in `www/index.html`. Capacitor wraps it as a real Android app.
You need a computer (Windows, Mac or Linux) for the build. Your phone only needs the finished app.

## A. One-time setup
1. Install Node.js (LTS): https://nodejs.org
2. Install Android Studio: https://developer.android.com/studio (let it install the SDK)

## B. Create the Android project (run in this folder)
    npm install
    npm install @capacitor/core @capacitor/android
    npm install -D @capacitor/cli @capacitor/assets
    npx cap add android
    npx capacitor-assets generate --android
    npx cap sync android
    npx cap open android

## C. Put it on YOUR phone (no store needed)
Option 1, USB cable:
1. On the phone: Settings > About phone > tap "Build number" 7 times, then enable Developer options > USB debugging.
2. Plug the phone in and accept the prompt on the phone.
3. In Android Studio choose your phone at the top and press the green Run button.

Option 2, APK file:
1. Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).
2. Click "locate" when it finishes: app-debug.apk is in android/app/build/outputs/apk/debug/
3. Send the file to your phone (cable, Drive, WhatsApp to yourself).
4. Open it on the phone and allow "Install unknown apps" for that app when asked.

## D. Publish on Google Play (optional)
1. Before publishing, set a unique `appId` in capacitor.config.json (e.g. com.yourschool.wildbound). Do this BEFORE step B.
2. Android Studio > Build > Generate Signed App Bundle > Android App Bundle (.aab). Create a keystore and BACK IT UP.
3. Create a Google Play Console developer account (one-time fee, identity check).
4. Upload the .aab, fill in the store listing (see store-listing.md), content rating, target audience and Data safety.
   Wildbound collects no personal data and makes no network calls. It stores coins and best level on the device only.
5. Add a privacy policy URL (see privacy-policy.md, host it anywhere public).
Google's rules change (target Android version, testing rules for new personal accounts). Follow the Play Console checklist.

## Updating the game later
Edit www/index.html, run `npx cap sync android`, raise versionCode in android/app/build.gradle, rebuild.
