# Google Play listing text

**App name:** Wildbound: Open World Survivor

**Short description (80 chars max):**
Explore an endless world, slay monsters, level up and beat bosses.

**Full description:**
Step into an endless 2D world of meadows, deserts and frozen wastes. Your hero fights automatically. You steer, dodge, and choose how to grow stronger.

- Endless open world with lakes, forests, desert and snow, plus a day and night cycle
- Defeat monsters to collect XP. Every level, pick 1 of 3 abilities from 16 upgrades
- Five heroes with unique looks and playstyles: Ranger, Knight, Mage, Rogue and Warden
- Different monsters in each region, and a boss fight every few minutes
- Collect coins and buy stronger armor in the shop
- Critical hits, orbiting blades, thunder shockwaves, frost aura and more
- Works offline. No ads, no accounts, no tracking

**Category:** Games > Action. **Content rating:** answer the questionnaire honestly (cartoon fantasy violence, no blood).
