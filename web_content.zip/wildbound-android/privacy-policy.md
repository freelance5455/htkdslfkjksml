# Privacy Policy for Wildbound

Last updated: [DATE]

Wildbound does not collect, store on servers, share or sell any personal information.
The game does not require an account and does not connect to the internet.
Your progress (coins, purchased armor, best level) is saved only on your own device and is removed if you uninstall the app.

Contact: [YOUR EMAIL]
