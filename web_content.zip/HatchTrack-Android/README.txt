HATCHTRACK ANDROID BUILD PACKAGE

This package contains the working HatchTrack web app and a GitHub Actions workflow to build an Android debug APK.

IMPORTANT:
- The APK has NOT been built yet; this is the source package and build workflow.
- Do not put private hatchery/customer records into this repository. The app stores records locally at runtime; this package contains only app code.
- To build, upload these files to a GitHub repository, then open Actions and run "Build HatchTrack APK". Once successful, download the HatchTrack-debug-APK artifact and extract app-debug.apk.
- The workflow uses Capacitor 8, Node 22, Java 21 and GitHub-hosted Linux build tools.
