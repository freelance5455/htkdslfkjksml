

PEMBARUAN UI MODERN
- Home screen terpisah dengan tombol Lawan Komputer dan Lawan Teman.
- Tampilan gelap premium dengan aksen emas, panel membulat, dan tata letak responsif.
- Bidak catur diberi gaya warna, bayangan, dan kontras yang lebih elegan.
- Panel permainan dan riwayat baru tampil setelah memilih mode.
