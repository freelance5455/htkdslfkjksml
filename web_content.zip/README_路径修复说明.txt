可爱豆丁 Android 项目 - 路径修复版

本包同时提供：
1. Android 原生项目文件（settings.gradle、build.gradle、app/...）
2. ZIP 根目录的 index.html，供将 ZIP 当作网页项目导入的手机端 IDE 使用。

如果手机端 IDE 的导入方式是“网页/HTML 转 APK”：请把 ZIP 解压后，选择根目录的 index.html 作为首页，或把 index.html 放在该工具要求的 web 根目录；不要选择 app/src/main/assets/index.html 这个嵌套路径。

如果 IDE 是 Android 项目编译器：请打开包含 settings.gradle 的项目根目录，按 Android 项目方式构建；MainActivity 加载 file:///android_asset/index.html，网页文件应位于 app/src/main/assets/index.html。

注意：重新安装/更换应用包名或 WebView 存储来源可能导致旧本地记录无法自动显示。操作前请先从旧应用导出 JSON/CSV 备份。
