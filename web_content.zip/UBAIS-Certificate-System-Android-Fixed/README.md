# UBAIS Certificate System — Android Studio Project

This project packages the supplied offline UBAIS Certificate System HTML application as a native Android WebView app.

## Included
- Current corrected `ubais-certificate-system.html`
- Offline WebView with JavaScript + IndexedDB/DOM storage enabled
- Native Android Print Framework bridge for `window.print()`
- A4 print attributes
- Android file picker for HTML import operations
- DownloadManager integration for ordinary WebView downloads
- No server/backend required

## Build
1. Open this folder in Android Studio.
2. Allow Android Studio/Gradle to download the Android Gradle Plugin and Android SDK if prompted.
3. Use **Build > Make Project**.
4. For an APK use **Build > Build APK(s)**.
5. The debug APK will normally be under `app/build/outputs/apk/debug/`.

## Important
The source HTML is bundled in `app/src/main/assets/`. To update the web application later, replace that file while keeping the Android wrapper unchanged.

The Android wrapper redirects the web app's `window.print()` to Android's native Print Framework, so users can select a printer or **Save as PDF** from the Android print dialog.
