# UBAIS Certificate System: no custom shrinking rules required.
