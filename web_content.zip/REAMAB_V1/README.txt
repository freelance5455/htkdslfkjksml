REAMAB V1
Salary & Expense Manager

Files:
- index.html
- style.css
- script.js

Features:
- Arabic / English
- 10 currencies
- Local storage
- Salary and expenses
- Editable budget distribution; saving requires 100%
- Expense deletion
- JSON export/import
- Print / Save as PDF
- Theme colors: olive, pink, purple, silver, beige, white + dark mode

Phone use:
Open index.html in a mobile code editor such as Acode, or use a WebView/HTML-to-APK builder.
