JUICE FACTORY APP — INSTALL GUIDE

This package is prepared as a Progressive Web App (PWA). To install it like an app on Android/iPhone, the files must be hosted on a secure HTTPS website. Opening index.html directly from a ZIP or file manager will not enable full PWA installation.

Steps:
1. Upload the contents of this folder to a static HTTPS host or your own HTTPS domain. Keep index.html, manifest.webmanifest, sw.js, and icon.svg in the same folder.
2. Open the hosted HTTPS address in Chrome on Android, or Safari on iPhone.
3. Android/Chrome: use the Install App prompt or browser menu > Install app / Add to Home screen.
4. iPhone/Safari: Share > Add to Home Screen.
5. On desktop Chrome/Edge: use the Install icon in the address bar or browser menu.

IMPORTANT DATA WARNING:
This starter app still stores business data locally in the browser. The service worker caches app files only; it does NOT back up business records to the cloud. Secure cloud database, login, role-based access, automated encrypted backups and multi-device sync are separate production tasks. Do not use this prototype as the sole business record or for tax filing.
