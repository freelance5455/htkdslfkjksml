package com.dar3alaman.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebChromeClient;

/**
 * يمنح الصفحة إذن الكاميرا داخل الـ WebView:
 * إن كان إذن أندرويد للكاميرا ممنوحاً يُنفَّذ request.grant فوراً، وإلا يُطلب من المستخدم ثم يُمنح بعد موافقته.
 * (منح الإذن للصفحة بلا إذن أندرويد لا يكفي، فتفشل الكاميرا بـ NotAllowedError أو NotReadableError.)
 * نمدّ BridgeWebChromeClient بدل استبداله كي تبقى بقية خصائص Capacitor (اختيار الملفات، الموقع...) تعمل.
 */
public class MainActivity extends BridgeActivity {
    private static final int REQ_CAMERA = 4201;
    private PermissionRequest pending;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // زر داخل التطبيق يفتح صفحة أذونات التطبيق في إعدادات أندرويد (يستدعيه الجافاسكربت: DarAndroid.openSettings())
        getBridge().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void openSettings() {
                runOnUiThread(() -> {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                });
            }
        }, "DarAndroid");
        getBridge().getWebView().setWebChromeClient(new BridgeWebChromeClient(getBridge()) {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean needsCamera = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) needsCamera = true;
                    }
                    if (!needsCamera || ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        pending = request;
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && pending != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pending.grant(pending.getResources());
            } else {
                pending.deny();
            }
            pending = null;
        }
    }
}
