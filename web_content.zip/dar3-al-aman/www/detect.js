/* محرك كشف اللهب والدخان على إطارات الكاميرا الحقيقية (دالات نقية بلا واجهة).
   اللهب: لون نار (أحمر مع أصفر) + وميض في السطوع + حركة شكل غير منتظمة.
   اللون الأحمر أو البرتقالي الثابت، أو الجسم الذي يتحرك ككتلة واحدة، ليس لهباً. */
(function (g) {
  const W = 160, H = 90, N = W * H;
  const FT = [0.012, 0.008, 0.005, 0.003, 0.002];
  const ST = [0.10, 0.07, 0.05, 0.035, 0.025];

  function newState() { return { bg: null, prevF: new Uint8Array(N), prevY: new Uint8Array(N), trail: [], n: 0 }; }

  function buildMask(rects) {
    const m = new Uint8Array(N);
    (rects || []).forEach(r => {
      const x0 = Math.floor(r.x * W), x1 = Math.ceil((r.x + r.w) * W);
      const y0 = Math.floor(r.y * H), y1 = Math.ceil((r.y + r.h) * H);
      for (let y = Math.max(0, y0); y < Math.min(H, y1); y++)
        for (let x = Math.max(0, x0); x < Math.min(W, x1); x++) m[y * W + x] = 1;
    });
    return m;
  }

  // مركز اللهب يغيّر اتجاهه (رمية عشوائية) بدل الانزلاق في خط واحد.
  function irregular(st, cx, cy, fl) {
    if (fl < 6) { st.trail.length = 0; return false; }
    st.trail.push(cx, cy);
    if (st.trail.length > 10) st.trail.splice(0, st.trail.length - 10);
    if (st.trail.length < 6) return false;
    let turns = 0, steps = 0, prev = 0;
    for (let t = 2; t < st.trail.length; t += 2) {
      const dx = st.trail[t] - st.trail[t - 2], dy = st.trail[t + 1] - st.trail[t - 1];
      if (Math.hypot(dx, dy) < 0.35) continue;
      const ang = Math.atan2(dy, dx);
      if (steps) {
        let d = Math.abs(ang - prev);
        if (d > Math.PI) d = 2 * Math.PI - d;
        if (d > 0.7) turns++;
      }
      prev = ang; steps++;
    }
    return steps >= 2 && turns >= 1;
  }

  // d: مصفوفة RGBA بطول N*4. المناطق المحجوبة (mask) لا تُحلَّل إطلاقاً.
  function analyze(st, d, mask, o) {
    const sens = Math.min(5, Math.max(1, (o && o.sens) || 3));
    if (!st.bg) {
      st.bg = new Float32Array(N);
      for (let i = 0; i < N; i++) st.bg[i] = (d[i * 4] * 299 + d[i * 4 + 1] * 587 + d[i * 4 + 2] * 114) / 1000;
    }
    if (!st.prevY) st.prevY = new Uint8Array(N);
    if (!st.trail) st.trail = [];
    const cur = new Uint8Array(N), ys = new Float32Array(N), nextY = new Uint8Array(N);
    let valid = 0, fl = 0, fg = 0, changed = 0;
    let sumX = 0, sumY = 0, sumL = 0, sumL2 = 0, flick = 0, born = 0, died = 0, overlap = 0;
    for (let i = 0; i < N; i++) {
      const r = d[i * 4], gg = d[i * 4 + 1], b = d[i * 4 + 2];
      const y = (r * 299 + gg * 587 + b * 114) / 1000; ys[i] = y; nextY[i] = y;
      if (mask && mask[i]) { st.bg[i] = y; continue; }
      valid++;
      const v = Math.max(r, gg, b), s = v ? (v - Math.min(r, gg, b)) / v : 0;
      // نار: أحمر مع أخضر ظاهر (قلب أصفر/برتقالي). الأحمر المسطح أخضره ضعيف فيُرفض هنا.
      const fireColor = r > 180 && gg > 85 && gg < r && b < 90 && b < gg * 0.7 && s > 0.45;
      if (fireColor) {
        cur[i] = 1; fl++;
        sumX += i % W; sumY += (i / W) | 0; sumL += y; sumL2 += y * y;
        if (st.prevF[i]) { overlap++; if (Math.abs(y - st.prevY[i]) > 16) flick++; }
        else born++;
      } else if (st.prevF[i]) died++;
      const diff = Math.abs(y - st.bg[i]);
      if (diff > 14) { changed++; if (s < 0.22 && y > 50 && y < 235) fg++; }
    }
    const globalChange = valid ? changed / valid : 0;
    for (let i = 0; i < N; i++) {
      const diff = Math.abs(ys[i] - st.bg[i]);
      st.bg[i] = globalChange > 0.6 ? ys[i] : st.bg[i] + (ys[i] - st.bg[i]) * (diff > 14 ? 0.01 : 0.05);
    }
    const mean = fl ? sumL / fl : 0;
    const variance = fl ? Math.max(0, sumL2 / fl - mean * mean) : 0;
    const flicker = overlap >= 8 ? flick / overlap : 0;
    const denom = overlap + born + died;
    const morph = denom ? (born + died) / denom : 0;
    const moved = fl ? irregular(st, sumX / fl, sumY / fl, fl) : (st.trail.length = 0, false);
    st.prevF = cur; st.prevY = nextY; const warm = st.n++ < 2;
    const flameRatio = valid ? fl / valid : 0, smokeRatio = valid ? fg / valid : 0;
    const grayShare = changed ? fg / changed : 0;
    const ft = FT[sens - 1];
    return {
      flame: !warm && flameRatio >= ft && variance >= 20 && flicker >= 0.12 && (morph >= 0.1 || moved),
      smoke: smokeRatio >= ST[sens - 1] && grayShare >= 0.6 && globalChange < 0.6,
      flameRatio, smokeRatio, flickRatio: flicker, grayShare, globalChange
    };
  }

  const api = { W, H, N, newState, buildMask, analyze };
  if (typeof module !== "undefined") module.exports = api;
  g.DET = api;
})(typeof window !== "undefined" ? window : globalThis);
