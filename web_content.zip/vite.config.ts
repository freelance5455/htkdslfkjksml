import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import type {ServerResponse} from 'http';
import path from 'path';
import zlib from 'zlib';
import {defineConfig, type Plugin} from 'vite';

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c >>> 0;
  }
  return t;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function collectProjectFiles(rootDir: string, relDir = ''): Array<{name: string; data: Buffer}> {
  const skipNames = new Set(['node_modules', 'dist', '.git', '.env', 'bun.lock']);
  const fullDir = path.join(rootDir, relDir);
  const out: Array<{name: string; data: Buffer}> = [];
  for (const entry of fs.readdirSync(fullDir, {withFileTypes: true})) {
    if (skipNames.has(entry.name)) continue;
    const relPath = relDir ? `${relDir}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      out.push(...collectProjectFiles(rootDir, relPath));
    } else if (entry.isFile()) {
      out.push({name: relPath, data: fs.readFileSync(path.join(rootDir, relPath))});
    }
  }
  return out;
}

function buildZipBuffer(rootDir: string): Buffer {
  const files = collectProjectFiles(rootDir);
  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const f of files) {
    const nameBuf = Buffer.from(f.name, 'utf8');
    const compBuf = zlib.deflateRawSync(f.data, {level: 9});
    const crc = crc32(f.data);

    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(20, 4);
    lh.writeUInt16LE(0x0800, 6);
    lh.writeUInt16LE(8, 8);
    lh.writeUInt16LE(0, 10);
    lh.writeUInt16LE(0x5421, 12);
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(compBuf.length, 18);
    lh.writeUInt32LE(f.data.length, 22);
    lh.writeUInt16LE(nameBuf.length, 26);
    lh.writeUInt16LE(0, 28);

    localParts.push(lh, nameBuf, compBuf);

    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(0x0800, 8);
    cd.writeUInt16LE(8, 10);
    cd.writeUInt16LE(0, 12);
    cd.writeUInt16LE(0x5421, 14);
    cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(compBuf.length, 20);
    cd.writeUInt32LE(f.data.length, 24);
    cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt16LE(0, 30);
    cd.writeUInt16LE(0, 32);
    cd.writeUInt16LE(0, 34);
    cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE(0, 38);
    cd.writeUInt32LE(offset, 42);

    centralParts.push(cd, nameBuf);
    offset += lh.length + nameBuf.length + compBuf.length;
  }

  const centralBuf = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(centralBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localParts, centralBuf, eocd]);
}

function standaloneHtmlDownloadPlugin(): Plugin {
  const sendStandaloneHtml = (res: ServerResponse) => {
    const filePath = path.resolve(__dirname, 'index.html');
    const html = fs.readFileSync(filePath, 'utf8');
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="air-traffic-control-simulator.html"');
    res.setHeader('Cache-Control', 'no-store');
    res.end(html);
  };

  const sendFullZip = (res: ServerResponse) => {
    const zipBuf = buildZipBuffer(path.resolve(__dirname));
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="air-traffic-control-simulator.zip"');
    res.setHeader('Content-Length', String(zipBuf.length));
    res.setHeader('Cache-Control', 'no-store');
    res.end(zipBuf);
  };

  return {
    name: 'standalone-html-download',
    configureServer(server) {
      server.middlewares.use('/air-traffic-control-simulator.html', (_req, res) => {
        sendStandaloneHtml(res);
      });
      server.middlewares.use('/air-traffic-control-simulator.zip', (_req, res) => {
        sendFullZip(res);
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use('/air-traffic-control-simulator.html', (_req, res) => {
        sendStandaloneHtml(res);
      });
      server.middlewares.use('/air-traffic-control-simulator.zip', (_req, res) => {
        sendFullZip(res);
      });
    },
    closeBundle() {
      const distDir = path.resolve(__dirname, 'dist');
      if (fs.existsSync(distDir)) {
        fs.copyFileSync(
          path.resolve(__dirname, 'index.html'),
          path.resolve(distDir, 'air-traffic-control-simulator.html')
        );
        fs.writeFileSync(
          path.resolve(distDir, 'air-traffic-control-simulator.zip'),
          buildZipBuffer(path.resolve(__dirname))
        );
      }
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), standaloneHtmlDownloadPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
