import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    define: {
      'import.meta.env.VITE_FIREBASE_API_KEY': JSON.stringify('AIzaSyCThSCwYJVrTsyu1y7so47yafljPHHDE-w'),
      'import.meta.env.VITE_FIREBASE_AUTH_DOMAIN': JSON.stringify('gen-lang-client-0855094775.firebaseapp.com'),
      'import.meta.env.VITE_FIREBASE_PROJECT_ID': JSON.stringify('gen-lang-client-0855094775'),
      'import.meta.env.VITE_FIREBASE_STORAGE_BUCKET': JSON.stringify('gen-lang-client-0855094775.firebasestorage.app'),
      'import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID': JSON.stringify('510510526409'),
      'import.meta.env.VITE_FIREBASE_APP_ID': JSON.stringify('1:510510526409:web:2808d5c309e4e0c1db4218'),
      'import.meta.env.VITE_FIREBASE_DATABASE_ID': JSON.stringify('ai-studio-shanjusaasecomme-a2b0df37-3970-4d0b-a1d3-866216f60be4'),
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      strictPort: true,
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
