import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import path from 'path';
import fs from 'fs';
import {defineConfig} from 'vite';

function sanitizeSingleHtmlPlugin() {
  return {
    name: 'sanitize-single-html',
    closeBundle() {
      const distPath = path.resolve(import.meta.dirname, 'dist', 'index.html');
      if (fs.existsSync(distPath)) {
        let content = fs.readFileSync(distPath, 'utf8');
        // Replace raw control characters like \u001f with safe \\u001f escape
        content = content.replace(/\u001f/g, '\\u001f');
        fs.writeFileSync(distPath, content, 'utf8');
      }
    },
  };
}

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss(), viteSingleFile(), sanitizeSingleHtmlPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
