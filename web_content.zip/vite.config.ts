import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';

const ROOT_DIR = import.meta.dirname;

const APK_ROOT_ASSETS = [
  'manifest.json',
  'icon.svg',
  'icon-192.png',
  'icon-512.png',
  'icon-maskable-512.png',
  'apple-touch-icon.png',
];

export default defineConfig(() => {
  return {
    base: './',
    plugins: [
      react(),
      tailwindcss(),
      // Copies src/assets and APK verification assets into dist/ so both
      // root-level ZIP uploads and dist/ uploads resolve all assets cleanly in WebView.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(ROOT_DIR, 'dist');
          if (!fs.existsSync(distDir)) {
            return;
          }

          const srcAssets = path.resolve(ROOT_DIR, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, { recursive: true, force: true });
          }

          for (const assetName of APK_ROOT_ASSETS) {
            const srcFile = path.resolve(ROOT_DIR, assetName);
            const destFile = path.resolve(distDir, assetName);
            if (fs.existsSync(srcFile)) {
              fs.copyFileSync(srcFile, destFile);
            }
          }

          const apkDir = path.resolve(ROOT_DIR, 'apk');
          const distApkDir = path.resolve(distDir, 'apk');
          if (fs.existsSync(apkDir)) {
            fs.cpSync(apkDir, distApkDir, { recursive: true, force: true });
          }

          // Keep manifest & icon hrefs stable at ./ root inside dist/index.html so
          // relative icon paths inside manifest.json always resolve in APK WebViews.
          const distIndex = path.resolve(distDir, 'index.html');
          if (fs.existsSync(distIndex)) {
            let html = fs.readFileSync(distIndex, 'utf8');
            html = html
              .replace(/href="\.\/assets\/manifest-[^"]+\.json"/g, 'href="./manifest.json"')
              .replace(/href="\.\/assets\/icon-[^"]+\.svg"/g, 'href="./icon.svg"')
              .replace(/href="\.\/assets\/icon-192-[^"]+\.png"/g, 'href="./icon-192.png"')
              .replace(
                /href="\.\/assets\/apple-touch-icon-[^"]+\.png"/g,
                'href="./apple-touch-icon.png"'
              );
            fs.writeFileSync(distIndex, html, 'utf8');
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(ROOT_DIR, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
