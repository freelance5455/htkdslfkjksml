import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';

// Custom plugin to ensure Android WebView & file:// offline compatibility:
// 1. In dev mode, ensures Vite dev server processes the TSX source.
// 2. In build mode, converts module scripts to classic defer scripts with no type="module".
// 3. Removes any modulepreload links and strips crossorigin attributes.
function androidWebViewCompatPlugin(): Plugin {
  return {
    name: 'android-webview-compat',
    transformIndexHtml: {
      order: 'pre',
      handler(html) {
        // Allow Vite internal compiler to resolve ./src/main.tsx as an entry point
        return html.replace(
          /<script defer src="(\.?\/src\/main\.tsx)"><\/script>/,
          '<script type="module" src="$1"></script>'
        );
      },
    },
  };
}

function androidWebViewPostProcessPlugin(): Plugin {
  return {
    name: 'android-webview-post-process',
    transformIndexHtml: {
      order: 'post',
      handler(html, ctx) {
        // Dev server should keep module scripts for live development & HMR
        if (ctx?.server) return html;

        // Production build: Strip type="module" and crossorigin
        return html
          .replace(
            /<script\s+type="module"\s+crossorigin\s+src="([^"]+)"><\/script>/g,
            '<script defer src="$1"></script>'
          )
          .replace(
            /<script\s+crossorigin\s+type="module"\s+src="([^"]+)"><\/script>/g,
            '<script defer src="$1"></script>'
          )
          .replace(
            /<script\s+type="module"\s+src="([^"]+)"><\/script>/g,
            '<script defer src="$1"></script>'
          )
          .replace(/<link\s+rel="modulepreload"[^>]*>\s*/g, '')
          .replace(/(href|src)="\/assets\//g, '$1="./assets/');
      },
    },
  };
}

export default defineConfig(() => {
  return {
    base: './', // Strict relative paths for Android WebView & file://
    plugins: [
      androidWebViewCompatPlugin(),
      react(),
      tailwindcss(),
      androidWebViewPostProcessPlugin(),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
      target: 'es2015',
      rollupOptions: {
        output: {
          format: 'iife' as const,
          name: 'PoketSafeApp',
          entryFileNames: 'assets/[name].js',
          chunkFileNames: 'assets/[name].js',
          assetFileNames: 'assets/[name].[ext]',
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

