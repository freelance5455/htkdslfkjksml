import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

function youtubeSearchPlugin() {
  return {
    name: 'youtube-search-plugin',
    configureServer(server: any) {
      server.middlewares.use('/api/search-youtube', async (req: any, res: any) => {
        try {
          const urlObj = new URL(req.url || '', 'http://localhost:3000');
          const query = urlObj.searchParams.get('q') || '';
          if (!query.trim()) {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ results: [] }));
            return;
          }

          const cleanQuery = query.replace(/(kids?|children|nursery|rhymes?|cocomelon|baby)/gi, '').trim() || query;
          const searchParam = encodeURIComponent(cleanQuery + ' music audio song -kids -nursery -cocomelon');

          const ytRes = await fetch(
            'https://www.youtube.com/results?search_query=' + searchParam,
            {
              headers: {
                'User-Agent':
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept-Language': 'en-US,en;q=0.9',
              },
            }
          );
          const html = await ytRes.text();
          const match = html.match(/var ytInitialData = ({.*?});<\/script>/);
          if (!match) {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ results: [] }));
            return;
          }

          const data = JSON.parse(match[1]);
          const contents =
            data?.contents?.twoColumnSearchResultsRenderer?.primaryContents
              ?.sectionListRenderer?.contents?.[0]?.itemSectionRenderer
              ?.contents || [];

          // Exclusion list: strictly NO kids songs, nursery rhymes, toddlers, cartoons
          const KIDS_EXCLUDE_REGEX = /(kids?|nursery|rhymes?|cocomelon|chuchu|chu chu|baby shark|lullab(y|ies)|toddler|kindergarten|preschool|cartoon|peppa|chota bheem|motu patlu|infant|bedtime stories|wheels on the bus|johny johny|finger family|children songs)/i;

          const results: any[] = [];
          for (const item of contents) {
            const v = item.videoRenderer;
            if (v && v.videoId) {
              const rawTitle = v.title?.runs?.[0]?.text || query;
              const rawArtist = v.ownerText?.runs?.[0]?.text || 'YouTube Music';
              
              // Skip any kids songs or nursery rhymes
              if (KIDS_EXCLUDE_REGEX.test(rawTitle) || KIDS_EXCLUDE_REGEX.test(rawArtist)) {
                continue;
              }

              const durationText = v.lengthText?.simpleText || '3:30';

              const parts = durationText.split(':').map((p: string) => parseInt(p, 10));
              let durationSec = 210;
              if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                durationSec = parts[0] * 60 + parts[1];
              } else if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
                durationSec = parts[0] * 3600 + parts[1] * 60 + parts[2];
              }

              results.push({
                id: 'yt-' + v.videoId,
                youtubeId: v.videoId,
                title: rawTitle,
                artist: rawArtist,
                album: 'YouTube Music Official',
                duration: durationSec,
                durationText,
                coverUrl: `https://img.youtube.com/vi/${v.videoId}/hqdefault.jpg`,
                genre: 'YouTube Music',
                mood: 'Trending',
                year: 2024,
              });
            }
          }

          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ results: results.slice(0, 25) }));
        } catch (err: any) {
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: err.message, results: [] }));
        }
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      youtubeSearchPlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg'],
        manifest: {
          id: '/',
          name: 'YT Music & Studio',
          short_name: 'YT Music',
          description: 'YouTube Music player with background lockscreen playback, synchronized lyrics, audio equalizer, and YT Create studio.',
          theme_color: '#030303',
          background_color: '#030303',
          display: 'standalone',
          orientation: 'portrait',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/images\.unsplash\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'unsplash-images-cache',
                expiration: {
                  maxEntries: 60,
                  maxAgeSeconds: 60 * 60 * 24 * 30, // 30 days
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname || process.cwd(), '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
