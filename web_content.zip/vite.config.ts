import path from "path";

export interface ViteWebViewConfig {
  base: string;
  resolve: {
    alias: Record<string, string>;
  };
  build: {
    outDir: string;
    assetsDir: string;
    emptyOutDir: boolean;
    sourcemap: boolean;
    rollupOptions: {
      output: {
        entryFileNames: string;
        chunkFileNames: string;
        assetFileNames: string;
      };
    };
  };
  server: {
    host: boolean;
    port: number;
  };
}

/**
 * Production Vite Configuration for Mobile / Android WebView (`file://`) & Hybrid Bundling
 * `base: './'` guarantees all generated JS/CSS/Image references in `index.html` use relative `./assets/...` paths.
 */
const viteConfig: ViteWebViewConfig = {
  base: "./",
  resolve: {
    alias: {
      "@": path.resolve(process.cwd(), "./src"),
    },
  },
  build: {
    outDir: "dist",
    assetsDir: "assets",
    emptyOutDir: true,
    sourcemap: false,
    rollupOptions: {
      output: {
        entryFileNames: "assets/[name]-[hash].js",
        chunkFileNames: "assets/[name]-[hash].js",
        assetFileNames: "assets/[name]-[hash].[ext]",
      },
    },
  },
  server: {
    host: true,
    port: 3000,
  },
};

export default viteConfig;
