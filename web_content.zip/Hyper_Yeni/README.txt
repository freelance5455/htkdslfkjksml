HYPER - YENİ ANDROID PROJESİ

Bu ZIP bir Android Studio kaynak projesidir; doğrudan kurulabilir APK değildir.

İçerik:
- Uygulama açılışında ana menü gelir.
- Kazanç Sistemi ve Hesap Satış kartları yan yana durur.
- Üç nokta menüsünden Ana Menü, Kazanç Sistemi ve Hesap Satış bölümlerine geçilir.
- Hedef kazanç özelliği bulunmaz.
- Gelir/gider kaydı, günlük ve aylık grafikler.
- Hesap stoku, düşük stok uyarısı, müşteri/satış bilgileri için not alanı ve satış geçmişi.
- Satış işaretlenince satış fiyatı - alış maliyeti net kâr olarak Kazanç Sistemi'ne otomatik eklenir. Aynı satış tekrar eklenmez.
- Tek dosyada birleşik JSON yedekleme ve geri yükleme.

GÜVENLİK / VERİ:
- Veriler cihaz içindeki WebView localStorage alanında tutulur; uygulama verisini temizlemek veya uygulamayı kaldırmak kayıtları silebilir. Düzenli yedek alın.
- Bu basit kişisel kayıt aracında hesap şifreleri yerel olarak saklanır; cihaz kilidi kullanın ve yedek dosyasını başkalarıyla paylaşmayın.
- APK oluşturmak için Android Studio'da bu klasörü açıp Gradle senkronizasyonu ve Build > Build APK(s) işlemi gerekir. İnternet ilk Gradle derlemesi için gerekebilir.
