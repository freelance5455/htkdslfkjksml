const PROFILE_KEY='overtime_tracker_profile_v1';
let userName='';
function loadUserProfile(){try{const p=JSON.parse(localStorage.getItem(PROFILE_KEY)||'null');userName=p&&p.name?String(p.name):''}catch(e){userName=''}if(userName){$('welcomeName').textContent=userName}else{$('nameScreen').classList.add('open')}}
function saveUserName(event){event.preventDefault();const name=$('userNameInput').value.trim();if(!name)return;userName=name;localStorage.setItem(PROFILE_KEY,JSON.stringify({name}));$('nameScreen').classList.remove('open');$('welcomeName').textContent=userName;renderDashboard();notify('Welcome, '+userName+'!')}
const KEY='overtime_tracker_html_v1';
const defaultSettings={basicSalary:2500,otRate:20,absentPenalty:0,unpaidPenalty:0,currency:'SAR'};
let settings={...defaultSettings},records={};
let viewDate=new Date();viewDate.setDate(1);
let selectedDate='',draftStatus='OT1',draftOT=1;
const $=id=>document.getElementById(id);
const money=n=>`${settings.currency} ${Number(n||0).toLocaleString(undefined,{minimumFractionDigits:0,maximumFractionDigits:2})}`;
const pad=n=>String(n).padStart(2,'0');
const dateKey=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const statusClass=s=>s==='Absent'?'absent':s==='Sick Leave'?'sick':s==='Unpaid Leave'?'unpaid':String(s||'').startsWith('OT')?'present':'';
function loadData(){try{const raw=JSON.parse(localStorage.getItem(KEY)||'{}');settings={...defaultSettings,...(raw.settings||{})};records=raw.records||{}}catch(e){settings={...defaultSettings};records={}}}
function persist(){try{localStorage.setItem(KEY,JSON.stringify({settings,records}))}catch(e){notify('Could not save locally. Check available device storage.')}}
function showPage(name){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===name));document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===name));if(name==='calendar')renderCalendar();if(name==='dashboard')renderDashboard();window.scrollTo({top:0,behavior:'smooth'})}
function monthRecords(){const prefix=`${viewDate.getFullYear()}-${pad(viewDate.getMonth()+1)}-`;return Object.entries(records).filter(([k])=>k.startsWith(prefix))}
function statsForMonth(date=viewDate){const prefix=`${date.getFullYear()}-${pad(date.getMonth()+1)}-`;let s={ot:0,duty:0,present:0,absent:0,sick:0,unpaid:0,off:0};for(const [k,r] of Object.entries(records)){if(!k.startsWith(prefix))continue;s.ot+=Number(r.ot||0);if(String(r.status||'').startsWith('OT')){s.present++;s.duty+=8;s.ot+=0}else if(r.status==='Sick Leave'){s.sick++;s.duty+=8}else if(r.status==='Absent')s.absent++;else if(r.status==='Unpaid Leave')s.unpaid++}return s}
function calculate(){const s=statsForMonth();const otPay=s.ot*Number(settings.otRate||0);const deductions=s.absent*Number(settings.absentPenalty||0)+s.unpaid*Number(settings.unpaidPenalty||0);return {...s,otPay,deductions,total:Number(settings.basicSalary||0)+otPay-deductions}}
function renderDashboard(){const s=calculate();$('totalSalary').textContent=money(s.total);$('basicMini').textContent=money(settings.basicSalary);$('otMini').textContent=money(s.otPay);$('otHours').innerHTML=`${s.ot} <small style="font-size:12px;color:var(--muted)">hrs</small>`;$('dutyHours').innerHTML=`${s.duty} <small style="font-size:12px;color:var(--muted)">hrs</small>`;$('absentDays').textContent=s.absent;$('otPay').textContent=money(s.otPay);$('dashSubtitle').textContent=viewDate.toLocaleDateString(undefined,{month:'long',year:'numeric'})+' · Attendance and pay overview';const recent=Object.entries(records).sort(([a],[b])=>b.localeCompare(a)).slice(0,5);$('recentActivity').innerHTML=recent.length?recent.map(([k,r])=>`<div class="activity-row"><div><div class="activity-date">${new Date(k+'T12:00:00').toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric',year:'numeric'})}</div><div class="activity-meta">${String(r.status||'').startsWith('OT')?`8 duty hrs · ${r.ot||0} OT hrs`:r.status}${r.note?' · '+esc(r.note):''}</div></div><span class="pill ${statusClass(r.status)}">${esc(String(r.status||'').startsWith('OT')?`OT ${r.ot} Hour${Number(r.ot)===1?'':'s'}`:r.status)}</span></div>`).join(''):'<div class="activity-empty">No attendance recorded yet.<br>Open Calendar and tap a date to get started.</div>'}
function renderCalendar(){const y=viewDate.getFullYear(),m=viewDate.getMonth();$('monthTitle').textContent=viewDate.toLocaleDateString(undefined,{month:'long',year:'numeric'});const first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate(),today=dateKey(new Date());let out='';for(let i=0;i<first;i++)out+='<button class="day blank" tabindex="-1"></button>';for(let d=1;d<=days;d++){const key=`${y}-${pad(m+1)}-${pad(d)}`,r=records[key],cls=['day',key===today?'today':'',key===selectedDate?'selected':'',r?statusClass(r.status):''].filter(Boolean).join(' ');out+=`<button class="${cls}" onclick="openDay('${key}')"><span class="day-num">${d}</span><span class="day-status">${r?esc(r.status==='Sick Leave'?'Sick':r.status==='Unpaid Leave'?'Unpaid':String(r.status||'').startsWith('OT')?`OT ${r.ot}h`:r.status):'·'}</span></button>`}$('calendarGrid').innerHTML=out;const s=statsForMonth();$('sumPresent').textContent=s.present+' days';$('sumSick').textContent=s.sick+' days';$('sumUnpaid').textContent=s.unpaid+' days'}
function changeMonth(n){viewDate=new Date(viewDate.getFullYear(),viewDate.getMonth()+n,1);renderCalendar()}
function goToday(){viewDate=new Date();viewDate.setDate(1);renderCalendar()}
function openDay(key){selectedDate=key;const r=records[key]||{status:'OT1',ot:1,note:''};draftStatus=r.status;draftOT=Number(r.ot||1);$('modalTitle').textContent=new Date(key+'T12:00:00').toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'});$('dayNote').value=r.note||'';$('deleteDayBtn').style.display=records[key]?'block':'none';updateChoices();$('dayModal').classList.add('open')}
function closeModal(){$('dayModal').classList.remove('open')}
function chooseStatus(s){draftStatus=s;draftOT=s==='OT1'?1:s==='OT2'?2:s==='OT3'?3:0;updateChoices()}
function updateChoices(){document.querySelectorAll('[data-status]').forEach(b=>b.classList.toggle('selected',b.dataset.status===draftStatus))}
function saveDay(){if(!selectedDate)return;records[selectedDate]={status:draftStatus,ot:String(draftStatus).startsWith('OT')?draftOT:0,note:$('dayNote').value.trim()};persist();closeModal();renderCalendar();renderDashboard();notify('Attendance saved on this device')}
function deleteDay(){if(!selectedDate)return;delete records[selectedDate];persist();closeModal();renderCalendar();renderDashboard();notify('Day record removed')}
function saveSettings(){const num=id=>Math.max(0,Number($(id).value)||0);settings={currency:$('currency').value,basicSalary:num('basicSalary'),otRate:num('otRate'),absentPenalty:num('absentPenalty'),unpaidPenalty:num('unpaidPenalty')};persist();renderDashboard();notify('Settings saved')}
function fillSettings(){ $('currency').value=settings.currency;$('basicSalary').value=settings.basicSalary;$('otRate').value=settings.otRate;$('absentPenalty').value=settings.absentPenalty;$('unpaidPenalty').value=settings.unpaidPenalty}
function exportData(){const blob=new Blob([JSON.stringify({app:'Overtime Tracker',exportedAt:new Date().toISOString(),settings,records},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='overtime-tracker-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('Backup export started')}
function confirmClear(){if(confirm('Delete all attendance records on this device? This cannot be undone.')){records={};persist();renderDashboard();renderCalendar();notify('Attendance records cleared')}}
function notify(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),2300)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
loadData();fillSettings();renderDashboard();renderCalendar();loadUserProfile();
// Hide the branded splash screen before the app is used.
window.addEventListener('load', () => {
  window.setTimeout(() => {
    const splash = document.getElementById('splashScreen');
    if (splash) splash.classList.add('hidden');
  }, 1900);
});

