OVERTIME TRACKER — COMPLETE WEB APP PACKAGE

Package contents:
- index.html: app structure
- style.css: app styling
- app.js: app logic
- assets/app-icon.png: app icon artwork
- assets/splash-screen.png: splash screen artwork
- assets/favicon.png: browser preview icon

First launch:
- No login or password page.
- The app asks only for the user's name, then shows the Dashboard.
- Dashboard, Calendar, and Settings remain separate sections.

Calendar choices:
- OT 1 Hour, OT 2 Hours, OT 3 Hours, Absent, Sick Leave, Unpaid Leave.

Settings:
- Basic salary, OT hourly rate, absent penalty, unpaid-leave penalty, and currency.

To convert to APK:
1. Upload this ZIP to an online HTML-to-APK builder that accepts ZIP packages.
2. Keep index.html at the ZIP root (already arranged).
3. Ensure the builder preserves the assets/ folder and linked CSS/JS files.
4. Set the app name to Overtime Tracker and build the APK.

Storage note:
This version stores records and settings locally on the device/browser. It does not yet cloud-sync between phones.
The splash image is included as a web splash overlay; some APK builders may also need a separate native splash/icon setting.
