/*--- Avanquest WebEasy Custom Script ---*/

onClick="Close"

/*--- EndOfFile ---*/
