package net.hanimex.app

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.preference.PreferenceManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var prefs: SharedPreferences

    private var prefsChanged = false
    private val prefsListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> prefsChanged = true }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        prefs = PreferenceManager.getDefaultSharedPreferences(this)
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)

        webView = findViewById(R.id.webView)
        swipe = findViewById(R.id.swipe)
        progress = findViewById(R.id.progress)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().setAcceptCookie(true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                // شاشة البداية المحلية (HTML داخل التطبيق)
                if (uri.scheme == "file" && uri.toString().startsWith("file:///android_asset/")) return false
                val host = uri.host.orEmpty()
                val internal = (uri.scheme == "https" || uri.scheme == "http") &&
                    host.endsWith(SettingsKeys.ALLOWED_HOST_SUFFIX)
                if (internal) return false
                // أي رابط خارجي (واتساب، اتصال، إيميل، موقع تاني) يفتح بالتطبيق المناسب
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                }
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                injectCss(view)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                injectCss(view)
                progress.visibility = View.GONE
                swipe.isRefreshing = false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }
        }

        swipe.setOnRefreshListener { webView.reload() }
        swipe.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(startUrl())
        }
    }

    private fun startUrl(): String =
        prefs.getString(SettingsKeys.START_PAGE, SettingsKeys.START_SCREEN)
            ?.takeIf { it.isNotBlank() } ?: SettingsKeys.START_SCREEN

    private fun buildCss(): String {
        val selectors = SettingsKeys.HIDE_MAP
            .filter { (key, _) -> prefs.getBoolean(key, false) }
            .values
        return if (selectors.isEmpty()) ""
        else selectors.joinToString(",") + "{display:none !important}"
    }

    private fun injectCss(view: WebView) {
        // لا نطبق الإخفاء على شاشة البداية المحلية
        val css = if (view.url?.startsWith("file:") == true) "" else buildCss()
        val create = if (css.isEmpty()) "" else
            "var s=document.createElement('style');s.id=id;" +
                "s.innerHTML=" + JSONObject.quote(css) + ";" +
                "(document.head||document.documentElement).appendChild(s);"
        val js = "(function(){var id='hx-style';" +
            "var e=document.getElementById(id);if(e){e.remove();}" +
            create + "})();"
        view.evaluateJavascript(js, null)
    }

    override fun onResume() {
        super.onResume()
        if (prefsChanged) {
            prefsChanged = false
            injectCss(webView)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        super.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_home -> {
            webView.loadUrl(startUrl())
            true
        }
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
