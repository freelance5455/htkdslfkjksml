package net.hanimex.app

/**
 * مفاتيح الإعدادات + الـ CSS selectors الخاصة بكل عنصر يمكن إخفاؤه.
 * لو الموقع غيّر تصميمه، عدّل الـ selectors هنا فقط.
 */
object SettingsKeys {
    const val HOME_URL = "https://www.hanimex.net/"
    const val START_SCREEN = "file:///android_asset/start.html"
    const val ALLOWED_HOST_SUFFIX = "hanimex.net"

    const val START_PAGE = "start_page"
    const val HIDE_HEADER = "hide_header"
    const val HIDE_FOOTER = "hide_footer"
    const val HIDE_PRICES = "hide_prices"
    const val HIDE_ADD_TO_CART = "hide_add_to_cart"
    const val HIDE_CATEGORY_MENU = "hide_category_menu"

    /** key -> CSS selector(s) */
    val HIDE_MAP: Map<String, String> = mapOf(
        HIDE_HEADER to "header, #wrapwrap > header",
        HIDE_FOOTER to "footer, #footer",
        HIDE_PRICES to ".oe_currency_value, .product_price, [itemprop='price'], .oe_price",
        HIDE_ADD_TO_CART to "#add_to_cart, a.a-submit, .js_add_cart_json, #buy_now",
        HIDE_CATEGORY_MENU to "#o_wsale_offcanvas, .o_wsale_products_main_row > #products_grid_before"
    )
}
