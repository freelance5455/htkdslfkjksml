Ghost Box Pro 4.0 – Alain Delay Edition

Startdatei: index.html

APKForge:
- Quelle: Gebuendelter Inhalt
- Startseite: index.html
- App-Name: Ghost Box Pro 4.0
- Paket-ID: com.alaindelay.ghostboxpro.v4
- Versionsname: 4.0.0
- Versionscode: 4

Die App ist ein experimenteller Audio-Synthesizer. Sprache, Wörter, Töne und Rauschen werden künstlich erzeugt; es werden keine Geisterstimmen empfangen.
