# EduZone — mobil ilova loyihasi

Bu loyiha oldingi o‘quv markazi sahifasini Android (APK) va iOS (IPA) ilovalariga o‘rash uchun tayyorlangan Capacitor boshlang‘ich loyihasidir.

## Hozir nimalar bor?
- O‘zbekcha interfeys
- O‘quvchi va ustoz kabinetlari
- Ballar va uy vazifalari
- Yorug‘/qorong‘i rejim
- Firebase/Firestore bilan ishlash uchun avvalgi sahifa kodi
- Firestore xavfsizlik qoidalari (`firestore.rules`)

## Muhim: Firebase sozlash
`www/index.html` ichidagi `FIREBASE_CONFIG` qiymatlarini Firebase loyihangizdan olingan qiymatlar bilan almashtiring.
`OWNER_UID` qiymatiga ustozning Firebase Authentication UID qiymatini yozing.
Firebase Console’da Authentication (Google) va Cloud Firestore’ni yoqing, so‘ng `firestore.rules` qoidalarini joylang.

## Android APK yaratish
Kompyuterda Node.js va Android Studio kerak:
1. Ushbu papkada terminal oching.
2. `npm install`
3. `npx cap add android`
4. `npx cap sync android`
5. `npx cap open android`
6. Android Studio’da Build → Build APK(s) ni tanlang.

## iPhone IPA yaratish
IPA yaratish uchun macOS kompyuter, Xcode va Apple Developer imzolash sozlamalari kerak:
1. `npm install`
2. `npx cap add ios`
3. `npx cap sync ios`
4. `npx cap open ios`
5. Xcode’da Signing & Capabilities sozlang va Archive/Distribute qiling.

## Hozircha yakunlanmagan
Bu — build qilishga tayyor boshlang‘ich loyiha, tayyor imzolangan APK yoki IPA emas.
Firebase konfiguratsiyasi va ustoz UID kiritilmagan. Mobil qurilmadagi Google login uchun OAuth/redirect sozlamalarini ham Firebase va Capacitor konfiguratsiyasiga moslab tekshirish kerak.
