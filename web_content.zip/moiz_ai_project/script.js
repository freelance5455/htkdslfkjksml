// Moiz AI Assistant
// Offline features work without an API key. For online AI, add a Gemini API key below.
// For a public release, put the API call behind your own server; never publish a private key in an APK.
const GEMINI_API_KEY = ""; // Optional: paste your Google AI Studio key between the quotes.
const GEMINI_MODEL = "gemini-2.5-flash";

const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");
const sendButton = document.getElementById("sendButton");
const conversation = [];

const knowledge = [
  { keys: ["capital of france"], answer: "Paris is the capital of France." },
  { keys: ["largest planet", "biggest planet"], answer: "Jupiter is the largest planet in our solar system." },
  { keys: ["smallest prime"], answer: "2 is the smallest prime number and the only even prime." },
  { keys: ["largest ocean"], answer: "The Pacific Ocean is the largest ocean on Earth." },
  { keys: ["who wrote romeo and juliet"], answer: "William Shakespeare wrote Romeo and Juliet." },
  { keys: ["chemical symbol for water", "formula of water"], answer: "Water's chemical formula is H₂O." },
  { keys: ["atomic number of carbon"], answer: "Carbon's atomic number is 6." },
  { keys: ["plants absorb", "gas plants absorb"], answer: "Plants absorb carbon dioxide during photosynthesis." },
  { keys: ["powerhouse of the cell"], answer: "Mitochondria are commonly called the powerhouse of the cell." },
  { keys: ["largest organ"], answer: "The skin is the largest organ of the human body." },
  { keys: ["photosynthesis"], answer: "Photosynthesis is the process by which plants use light energy to make sugars from carbon dioxide and water, releasing oxygen." },
  { keys: ["speed of light"], answer: "The speed of light in a vacuum is about 299,792 kilometres per second." },
  { keys: ["unit of electrical resistance"], answer: "The unit of electrical resistance is the ohm (Ω)." },
  { keys: ["value of pi"], answer: "Pi is approximately 3.14159." },
  { keys: ["15 multiplied by 15", "15 times 15"], answer: "15 × 15 = 225." },
  { keys: ["square root of 144"], answer: "The square root of 144 is 12." },
  { keys: ["past tense of run"], answer: "The past tense of 'run' is 'ran'." },
  { keys: ["plural of child"], answer: "The plural of 'child' is 'children'." },
  { keys: ["what is a noun"], answer: "A noun is a word that names a person, place, thing, or idea." },
  { keys: ["rule of 3 in survival"], answer: "A rough survival reminder: about 3 minutes without breathable air, 3 hours in harsh conditions without adequate shelter, 3 days without water, and 3 weeks without food. These are not guarantees; conditions vary." }
];

const emergency = [
  { keys: ["heart attack", "chest pain"], answer: "POSSIBLE HEART ATTACK: Call your local emergency number immediately. Keep the person resting and calm. Loosen tight clothing. Do not let them drive themselves. If they become unresponsive and are not breathing normally, start CPR if trained and follow the emergency operator's instructions." },
  { keys: ["not breathing", "cpr", "cardiac arrest"], answer: "UNRESPONSIVE / NOT BREATHING NORMALLY: Call emergency services and ask someone to bring an AED. Start chest compressions in the centre of the chest, hard and fast (about 100–120 per minute). Use an AED as soon as available and follow its prompts. Follow dispatcher instructions." },
  { keys: ["bleeding", "heavy bleeding"], answer: "SEVERE BLEEDING: Call emergency services. Apply firm, continuous direct pressure with clean cloth or gauze. Do not repeatedly lift the dressing to check. If blood soaks through, add more material on top and keep pressing. For life-threatening limb bleeding, use a commercial tourniquet only if available and you know how to use it." },
  { keys: ["burn", "burned", "scald"], answer: "BURN: Cool the burn under cool running water for 20 minutes if possible. Remove jewellery and loose clothing near it, but do not pull off anything stuck to skin. Do not use ice, butter, toothpaste, or creams. Cover loosely with clean non-fluffy material. Get urgent medical help for large, deep, face, hand, genital, or chemical/electrical burns." },
  { keys: ["choking"], answer: "CHOKING: If the person can cough or speak, encourage coughing. If they cannot breathe, speak, or cough effectively, call emergency services and give age-appropriate choking first aid. For an adult/child, alternate 5 back blows with 5 abdominal thrusts. For an infant, use 5 back blows and 5 chest thrusts—never abdominal thrusts. Follow local first-aid guidance." },
  { keys: ["earthquake"], answer: "EARTHQUAKE: DROP, COVER, and HOLD ON. Get under sturdy furniture, protect your head and neck, and stay away from windows. Do not use lifts. After shaking stops, move carefully to an open area if the building is damaged; expect aftershocks and follow official alerts." },
  { keys: ["flood", "flooding"], answer: "FLOOD: Move to higher ground immediately. Never walk, swim, or drive through floodwater. Avoid electrical wires and contaminated water. Take essential medicines and documents only if safe. Follow evacuation orders and official local alerts." },
  { keys: ["fire", "house fire"], answer: "FIRE: Alert everyone and leave immediately using stairs, not lifts. Stay low under smoke. Close doors behind you if safe. Do not re-enter. Once outside, call the fire service. If your clothes catch fire: STOP, DROP, and ROLL." },
  { keys: ["snake bite", "snakebite"], answer: "SNAKEBITE: Keep the person still and calm, immobilise the bitten limb, and get emergency medical care immediately. Remove rings or tight items. Do not cut, suck, ice, or apply a tourniquet to the bite. Do not try to catch the snake; a safe photo from a distance may help clinicians." },
  { keys: ["poison", "poisoning"], answer: "POISONING: Contact emergency medical services or a poison centre immediately. Do not induce vomiting or give food/drink unless a professional instructs you. Keep the container or product label for clinicians. If the person is unconscious, having seizures, or struggling to breathe, call emergency services now." },
  { keys: ["survival kit", "emergency kit"], answer: "BASIC EMERGENCY KIT: Drinking water, ready-to-eat food, essential medicines, first-aid kit, torch/flashlight and spare batteries, power bank, radio, whistle, hygiene supplies, masks, copies of important documents, cash, and sturdy shoes. Adjust for your family, climate, and local hazards." },
  { keys: ["water in the wild", "purify water"], answer: "WATER SAFETY: Prefer sealed bottled water or an approved filter/disinfection method. If boiling is possible, bring clear water to a rolling boil for 1 minute (3 minutes above 2,000 m / 6,500 ft), then cool and store covered. Boiling does not remove chemical contamination or salt." }
];

function normalize(s) {
  return s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function safeText(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function appendMessage(text, sender) {
  const div = document.createElement("div");
  div.className = "message " + (sender === "user" ? "user-message" : "bot-message");
  div.innerHTML = safeText(text).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
  return div;
}
function findAnswer(list, query) {
  const q = normalize(query);
  const hit = list.find(item => item.keys.some(k => q.includes(normalize(k))));
  return hit ? hit.answer : null;
}
function localReply(input) {
  const q = normalize(input);
  if (/^(hi|hello|hey|salam|assalamualaikum|aoa)\b/.test(q)) return "Hello! 😊 How are you doing? What would you like to talk about?";
  if (q.includes("who created you") || q.includes("who made you")) return "I was created by Muhammad Moiz.";
  if (q.includes("your name") || q === "who are you") return "I am Moiz AI Assistant, created by Muhammad Moiz. I can chat and answer some questions offline.";
  if (q.includes("thank")) return "You're very welcome! 😊 I'm always happy to help.";
  if (q.includes("how are you")) return "I'm doing well, thanks for asking! How are you?";
  if (q.includes("good morning")) return "Good morning! ☀️ Hope you have a great day.";
  if (q.includes("good night")) return "Good night! Take care and sleep well. 🌙";
  if (q.includes("joke")) return "Why did the computer go to the doctor? Because it caught a virus! 😄";
  if (q.includes("what can you do") || q.includes("features")) return "I can have simple conversations, answer my built-in general knowledge and school questions, and give emergency guidance—all without internet. With an internet connection and a configured Gemini API key, I can also ask online AI.";
  if (q.includes("homework") || q.includes("exam") || q.includes("study")) return "Let's study together! Try 25 minutes of focused study followed by a 5-minute break. Tell me the subject or question and I'll help you understand it.";
  const emergencyAnswer = findAnswer(emergency, input);
  if (emergencyAnswer) return emergencyAnswer;
  const known = findAnswer(knowledge, input);
  if (known) return known;
  return null;
}

async function onlineReply(prompt) {
  if (!GEMINI_API_KEY) return null;
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
  const history = conversation.slice(-10).map(m => ({
    role: m.role,
    parts: [{ text: m.text }]
  }));
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: history.length ? history : [{ role: "user", parts: [{ text: prompt }] }] })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `Online AI error (${response.status})`);
  return data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim() || "Sorry, I couldn't generate a response.";
}

let busy = false;
async function sendMessage() {
  const text = userInput.value.trim();
  if (!text || busy) return;
  appendMessage(text, "user");
  userInput.value = "";
  conversation.push({ role: "user", text });
  const local = localReply(text);
  if (local) {
    conversation.push({ role: "model", text: local });
    setTimeout(() => appendMessage(local, "bot"), 180);
    return;
  }

  if (!navigator.onLine) {
    const offline = "I'm currently offline. I can still chat casually and answer my built-in questions. Try asking about greetings, general knowledge, school subjects, or emergency help.";
    conversation.push({ role: "model", text: offline });
    appendMessage(offline, "bot");
    return;
  }
  if (!GEMINI_API_KEY) {
    const offline = "I don't have a built-in answer for that yet, and online AI hasn't been configured. Add your Gemini API key in script.js to enable online answers. My basic chat and emergency guidance still work offline.";
    conversation.push({ role: "model", text: offline });
    appendMessage(offline, "bot");
    return;
  }

  busy = true;
  sendButton.disabled = true;
  const thinking = appendMessage("Thinking...", "bot");
  try {
    const answer = await onlineReply(text);
    thinking.textContent = answer;
    conversation.push({ role: "model", text: answer });
  } catch (err) {
    thinking.textContent = "I couldn't connect to online AI. Your offline features are still available. " + err.message;
  } finally {
    busy = false;
    sendButton.disabled = false;
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}
sendButton.addEventListener("click", sendMessage);
userInput.addEventListener("keydown", e => { if (e.key === "Enter") sendMessage(); });
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
