# Moiz AI Assistant — project ZIP

This ZIP contains a small offline-first web app using the interface style from the HTML/CSS you supplied.

## Included
- `index.html`, `style.css`, `script.js`
- Offline simple conversation and a small built-in Q&A collection
- Offline emergency guidance for common situations
- Optional online Gemini connection
- Service worker and manifest for caching when hosted as a PWA
- `original-apk/base.apk`: the APK you supplied, included unchanged for reference

## Important about the APK
The supplied APK is a compiled Android package (a WebView-style wrapper); it does not contain the editable HTML/CSS/JS project you pasted. This ZIP therefore provides the editable app source, but **does not claim to be a rebuilt or modified APK**. The original APK is included unchanged.

To turn this source into an installable Android APK, open it in an Android/PWA packaging workflow (for example, a Capacitor Android project or a trusted PWA-to-APK builder), then build and sign it. An Android SDK/Gradle project and signing key are not present in the uploaded APK.

## Run locally
For basic testing, open `index.html` in a browser. For service-worker offline caching, serve this folder over localhost or HTTPS (service workers do not register from ordinary `file://` pages).

## Enable online AI
1. Create a Gemini API key in Google AI Studio.
2. In `script.js`, set `GEMINI_API_KEY` to your key.
3. Rebuild/repackage the app.

**Security:** A key placed in client-side JavaScript can be extracted from an APK or website. Do not use a private production key this way. For a public app, create a small backend that keeps the key secret and forwards requests. Without a key and internet connection, local chat, built-in answers, and emergency guidance continue to work.

## Emergency guidance disclaimer
This is general first-aid information, not a substitute for emergency services or professional medical training. In a real emergency, contact local emergency services immediately and follow their instructions. Emergency numbers and available services vary by location.
