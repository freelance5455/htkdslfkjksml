NAMMA BIKE — DEMO APP (Kannada)

ಈ ZIP ಒಂದು ಕೆಲಸ ಮಾಡುವ UI demo. ಇದು production Rapido app ಅಥವಾ Android APK ಅಲ್ಲ.

Android ನಲ್ಲಿ ತೆರೆಯುವುದು:
1. ZIP ಫೈಲ್ ಅನ್ನು Downloads ನಲ್ಲಿ save ಮಾಡಿ.
2. Files / My Files app ತೆರೆಯಿರಿ.
3. ZIP ಮೇಲೆ ಒತ್ತಿ Extract / Unzip ಆಯ್ಕೆ ಮಾಡಿ.
4. ಹೊರಬಂದ Namma_Bike_Full_Demo ಫೋಲ್ಡರ್ ತೆರೆಯಿರಿ.
5. index.html ಮೇಲೆ ಒತ್ತಿ Chrome ಅಥವಾ browser ಆಯ್ಕೆ ಮಾಡಿ.

ಸೇರಿಸಿರುವ demo:
- Customer pickup/drop ಮತ್ತು ಅಂದಾಜು ದರ
- Demo booking list
- Rider online/offline ಮತ್ತು demo ride accept
- Admin dashboard ಮತ್ತು commission estimate
- ಸ್ಥಳೀಯ browser storage

ಇನ್ನೂ ಇಲ್ಲದ production ವೈಶಿಷ್ಟ್ಯಗಳು:
- Android APK build/signing
- OTP login ಮತ್ತು user accounts
- Live GPS/maps/distance routing
- Server/database ಮತ್ತು rider matching
- Real UPI/payment gateway
- Push notifications, support, cancellation/refunds
- Driver KYC, insurance, legal/licensing compliance

ನಿಜವಾದ business app launch ಮಾಡಲು developer, backend hosting, map/SMS/payment services, testing ಮತ್ತು ಕಾನೂನು ಅನುಸರಣೆ ಬೇಕಾಗುತ್ತದೆ.
