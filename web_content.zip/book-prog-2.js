/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : PROG-1-1-2 */
registerLessonDetail(2, 1, "prog-1-1-2", {
  title: "Leçon 2 : Fonctions, Pile d'appels, Portée et Récursivité",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Appliquer la décomposition modulaire (« Diviser pour régner » et principe DRY).",
    "Distinguer paramètres formels, arguments réels, return et print.",
    "Comprendre la Pile d'appels (Call Stack) et la portée locale vs globale.",
    "Maîtriser les deux règles vitales de la récursivité et éviter le Stack Overflow."
  ],
  prerequisites: ["Leçon 1 — Variables, types et boucles."],
  sections: [
    {
      type: "theory",
      title: "1. Pourquoi décomposer un programme en fonctions ?",
      text: "Écrire un logiciel complet dans un seul bloc de 5 000 lignes le rend impossible à maintenir. En génie logiciel, on applique la stratégie « Diviser pour régner » et le principe DRY (Don't Repeat Yourself) : on isole chaque logique précise dans une fonction autonome dotée d'un nom clair, d'entrées (paramètres) et d'une sortie (valeur retournée)."
    },
    {
      type: "definition",
      term: "Paramètre vs Argument, et return vs print",
      text: "• Paramètre formel : variable dans la définition (ex: def carre(x): → x est le paramètre).\n• Argument réel : valeur transmise à l'appel (ex: carre(5) → 5 est l'argument).\n• print() affiche seulement du texte à l'écran pour l'humain ; le programme ne récupère aucune valeur.\n• return termine immédiatement la fonction et livre le résultat calculé au reste du programme."
    },
    {
      type: "theory",
      title: "2. Portée des variables (Scope) et Pile d'Appels (Call Stack)",
      text: "Lorsqu'une fonction A appelle une fonction B, le système crée en RAM (dans la Pile) un espace isolé appelé « Cadre de pile » (Stack Frame) réservé aux variables créées dans B. Ces variables sont dites « locales » : elles disparaissent dès que B exécute return.\n\nUne variable déclarée hors de toute fonction est « globale » : les bonnes pratiques universitaires recommandent d'éviter de la modifier depuis les fonctions (principe de Fonction Pure)."
    },
    {
      type: "code",
      lang: "Python — Conception modulaire avec Docstring",
      code: [
        "def calculer_moyenne(notes):",
        "    \"\"\"Calcule la moyenne arithmétique d'une liste de notes.\"\"\"",
        "    if not notes:",
        "        return 0.0",
        "    return sum(notes) / len(notes)",
        "",
        "def determiner_mention(moyenne):",
        "    if moyenne >= 16: return 'Très Bien'",
        "    if moyenne >= 14: return 'Bien'",
        "    if moyenne >= 10: return 'Admis'",
        "    return 'Ajourné'",
        "",
        "m = calculer_moyenne([15.5, 17.0, 14.5])",
        "print(f'Moyenne : {m:.2f}/20 — Mention : {determiner_mention(m)}')"
      ].join("\n")
    },
    {
      type: "theory",
      title: "3. La Récursivité : quand une fonction s'appelle elle-même",
      text: "Une fonction récursive résout un problème en s'appelant elle-même sur une version réduite du problème. Elle exige deux règles absolues :\n1) Un Cas de Base (condition d'arrêt directe).\n2) Une Convergence (chaque appel se rapproche du cas de base)."
    },
    {
      type: "code",
      lang: "Trace de la Pile d'appels : factorielle(4)",
      code: [
        "def factorielle(n):",
        "    if n <= 1:                      # 1) Cas de base",
        "        return 1",
        "    return n * factorielle(n - 1)   # 2) Convergence vers 1",
        "",
        "# Descente (empilement en RAM) :",
        "#   factorielle(4) attend 4 * factorielle(3)",
        "#     factorielle(3) attend 3 * factorielle(2)",
        "#       factorielle(2) attend 2 * factorielle(1)",
        "#         factorielle(1) → renvoie 1",
        "# Remontée (dépilement et multiplication) :",
        "#       factorielle(2) → 2 * 1 = 2",
        "#     factorielle(3) → 3 * 2 = 6",
        "#   factorielle(4) → 4 * 6 = 24"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter",
      text: "1) Oublier return : une fonction sans return renvoie None, ce qui fait planter toute opération mathématique sur son résultat.\n2) Oublier le cas de base récursif : la pile sature la RAM et provoque un « Stack Overflow » (RecursionError).\n3) Code mort : toute instruction placée après un return dans le même bloc n'est jamais exécutée."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Déboguer None",
      question: "Pourquoi ce code déclenche-t-il une erreur TypeError ? Corrigez-le :\ndef double(x):\n    print(x * 2)\ntotal = double(10) + 5",
      solution: "double() utilise print() au lieu de return : elle renvoie None, et None + 5 est impossible.\nCorrection :\ndef double(x):\n    return x * 2"
    },
    {
      title: "Exercice 2 — Portée locale vs globale",
      question: "Qu'affiche ce script et pourquoi ?\nx = 100\ndef tester():\n    x = 5\n    return x * 2\ny = tester()\nprint(x, y)",
      solution: "Il affiche : 100 10.\nDans tester(), « x = 5 » crée une variable locale indépendante sur la Pile qui ne modifie pas le x global."
    },
    {
      title: "Exercice 3 — Somme récursive",
      question: "Écrivez une fonction récursive somme_n(n) qui calcule 1 + 2 + ... + n pour n >= 1.",
      solution: "def somme_n(n):\n    if n <= 1:\n        return n\n    return n + somme_n(n - 1)"
    }
  ],
  summary: "Les fonctions rendent le code modulaire, lisible et isolé via la Pile d'appels. La maîtrise de return, de la portée locale et des règles de récursivité (cas de base + convergence) est indispensable en génie logiciel.",
  references: [
    "Downey, A. — Think Python: How to Think Like a Computer Scientist.",
    "Cormen, T. et al. — Algorithmique, Dunod."
  ]
});