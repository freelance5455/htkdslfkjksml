Birthday app files for Ansa. Keep index.html and all photo/video files together in the same folder or copy them into the app assets folder. Original media files are copied without editing.
