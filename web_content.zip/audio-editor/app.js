// Audio Editor - Client-Side Web Audio Workstation (Lexis Style)
class AudioEditorApp {
  constructor() {
    this.audioCtx = null;
    this.audioBuffer = null;
    this.undoStack = [];
    this.clipboardBuffer = null;

    // Playback & Recording State
    this.isPlaying = false;
    this.isPaused = false;
    this.isRecording = false;
    this.sourceNode = null;
    this.analyserNode = null;
    this.startTime = 0;
    this.pauseOffset = 0;
    this.playbackRate = 1.0;

    // Recording nodes
    this.mediaStream = null;
    this.scriptProcessor = null;
    this.recordedChunksL = [];
    this.recordedChunksR = [];
    this.recGainDb = 0;

    // Selection & Zoom
    this.selStart = 0; // in seconds
    this.selEnd = 0;   // in seconds
    this.hasSelection = false;
    this.zoomLevel = 1;
    this.scrollOffset = 0; // in seconds

    this.initDOM();
    this.bindEvents();
    this.initEQModal();
    this.renderWaveform();
    this.startMeterLoop();
  }

  ensureAudioContext() {
    if (!this.audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.audioCtx = new AudioContext({ sampleRate: 48000 });
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  initDOM() {
    this.canvas = document.getElementById('waveformCanvas');
    this.ctx = this.canvas.getContext('2d');
    this.canvasArea = document.getElementById('canvasArea');
    this.playheadLine = document.getElementById('playheadLine');
    this.rightCursorLine = document.getElementById('rightCursorLine');
    this.selectionOverlay = document.getElementById('selectionOverlay');
    this.zoomWatermark = document.getElementById('zoomWatermark');

    this.vuLeft = document.getElementById('vuLeft');
    this.vuRight = document.getElementById('vuRight');
    this.recGainSlider = document.getElementById('recGainSlider');
    this.recGainLabel = document.getElementById('recGainLabel');

    this.posDisplay = document.getElementById('posDisplay');
    this.selDisplay = document.getElementById('selDisplay');
    this.fileInfoDisplay = document.getElementById('fileInfoDisplay');

    this.btnPlay = document.getElementById('btnPlay');
    this.btnPause = document.getElementById('btnPause');
    this.btnRecord = document.getElementById('btnRecord');
    this.btnMark = document.getElementById('btnMark');
    this.btnStop = document.getElementById('btnStop');

    this.resizeCanvas();
    window.addEventListener('resize', () => {
      this.resizeCanvas();
      this.renderWaveform();
    });
  }

  resizeCanvas() {
    const rect = this.canvasArea.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  bindEvents() {
    // Open file
    document.getElementById('btnOpen').addEventListener('click', () => {
      document.getElementById('fileInput').click();
    });

    document.getElementById('fileInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      await this.loadAudioFile(file);
      e.target.value = '';
    });

    // Save modal
    document.getElementById('btnSave').addEventListener('click', () => {
      if (!this.audioBuffer) return alert('No audio loaded or recorded yet.');
      document.getElementById('saveModal').classList.remove('hidden');
    });

    document.getElementById('btnConfirmSave').addEventListener('click', () => {
      this.exportAudio();
      document.getElementById('saveModal').classList.add('hidden');
    });

    // Zoom
    document.getElementById('btnZoomIn').addEventListener('click', () => {
      this.zoomLevel = Math.min(32, this.zoomLevel * 2);
      this.zoomWatermark.textContent = `x${this.zoomLevel}`;
      this.clampScroll();
      this.renderWaveform();
      this.updateCursorsUI();
    });

    document.getElementById('btnZoomOut').addEventListener('click', () => {
      this.zoomLevel = Math.max(1, this.zoomLevel / 2);
      this.zoomWatermark.textContent = `x${this.zoomLevel}`;
      this.clampScroll();
      this.renderWaveform();
      this.updateCursorsUI();
    });

    // Dropdown Menu
    const btnMenu = document.getElementById('btnMenu');
    const dropdown = document.getElementById('dropdownMenu');
    btnMenu.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('hidden');
    });
    document.addEventListener('click', () => dropdown.classList.add('hidden'));

    dropdown.querySelectorAll('button[data-action]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        this.handleMenuAction(action);
      });
    });

    document.getElementById('mixFileInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) await this.mixWithFile(file);
      e.target.value = '';
    });

    // Rec Gain Slider
    this.recGainSlider.addEventListener('input', (e) => {
      this.recGainDb = parseInt(e.target.value, 10);
      const sign = this.recGainDb >= 0 ? '+' : '-';
      this.recGainLabel.textContent = `Rec Vol ${sign} ${Math.abs(this.recGainDb)} dB`;
    });

    // Transport Controls
    this.btnPlay.addEventListener('click', () => this.play());
    this.btnPause.addEventListener('click', () => this.pause());
    this.btnRecord.addEventListener('click', () => this.toggleRecord());
    this.btnMark.addEventListener('click', () => this.toggleSelectionMarker());
    this.btnStop.addEventListener('click', () => this.stop());

    // Waveform scrubbing & handle dragging
    this.setupWaveformInteraction();

    // Modals close
    document.querySelectorAll('.close-modal').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.getElementById(btn.dataset.close).classList.add('hidden');
      });
    });

    // Speed & Pitch Modal
    const speedSlider = document.getElementById('speedSlider');
    const pitchSlider = document.getElementById('pitchSlider');
    speedSlider.addEventListener('input', () => {
      document.getElementById('speedValLabel').textContent = `${parseFloat(speedSlider.value).toFixed(2)}x`;
    });
    pitchSlider.addEventListener('input', () => {
      document.getElementById('pitchValLabel').textContent = `${pitchSlider.value} st`;
    });
    document.getElementById('btnApplySpeedPitch').addEventListener('click', () => {
      this.applySpeedAndPitch(parseFloat(speedSlider.value), parseInt(pitchSlider.value, 10));
      document.getElementById('speedPitchModal').classList.add('hidden');
    });
  }

  setupWaveformInteraction() {
    let dragging = null; // 'left', 'right', or 'scrub'

    const getTimeFromClientX = (clientX) => {
      if (!this.audioBuffer) return 0;
      const rect = this.canvasArea.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      const visibleDuration = this.audioBuffer.duration / this.zoomLevel;
      return Math.max(0, Math.min(this.audioBuffer.duration, this.scrollOffset + ratio * visibleDuration));
    };

    document.getElementById('leftHandle').addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      dragging = 'left';
    });

    document.getElementById('rightHandle').addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      dragging = 'right';
    });

    this.canvasArea.addEventListener('pointerdown', (e) => {
      if (!this.audioBuffer) return;
      dragging = 'scrub';
      const t = getTimeFromClientX(e.clientX);
      this.pauseOffset = t;
      this.selStart = t;
      if (!this.hasSelection) {
        this.selEnd = this.audioBuffer.duration;
      }
      this.updateStatusDisplay();
      this.updateCursorsUI();
    });

    window.addEventListener('pointermove', (e) => {
      if (!dragging || !this.audioBuffer) return;
      const t = getTimeFromClientX(e.clientX);
      if (dragging === 'left' || dragging === 'scrub') {
        this.pauseOffset = t;
        this.selStart = Math.min(t, this.selEnd);
      } else if (dragging === 'right') {
        this.hasSelection = true;
        this.rightCursorLine.style.display = 'block';
        this.selEnd = Math.max(t, this.selStart);
      }
      this.updateStatusDisplay();
      this.updateCursorsUI();
    });

    window.addEventListener('pointerup', () => {
      dragging = null;
    });
  }

  toggleSelectionMarker() {
    if (!this.audioBuffer) return;
    if (!this.hasSelection) {
      this.hasSelection = true;
      this.selStart = this.pauseOffset;
      this.selEnd = Math.min(this.audioBuffer.duration, this.selStart + Math.max(1, this.audioBuffer.duration * 0.25));
      this.rightCursorLine.style.display = 'block';
      this.btnMark.classList.add('marked');
    } else {
      this.hasSelection = false;
      this.selStart = 0;
      this.selEnd = this.audioBuffer.duration;
      this.rightCursorLine.style.display = 'none';
      this.btnMark.classList.remove('marked');
    }
    this.updateStatusDisplay();
    this.updateCursorsUI();
  }

  async loadAudioFile(file) {
    this.stop();
    this.ensureAudioContext();
    const arrayBuffer = await file.arrayBuffer();
    const decoded = await this.audioCtx.decodeAudioData(arrayBuffer);
    this.pushUndo();
    this.audioBuffer = this.ensureStereo(decoded);
    this.resetSelectionAndView();
    this.fileInfoDisplay.textContent = `${file.name} • ${this.audioBuffer.sampleRate} Hz`;
    this.renderWaveform();
  }

  ensureStereo(buffer) {
    if (buffer.numberOfChannels >= 2) return buffer;
    const stereo = this.audioCtx.createBuffer(2, buffer.length, buffer.sampleRate);
    const mono = buffer.getChannelData(0);
    stereo.copyToChannel(mono, 0);
    stereo.copyToChannel(mono, 1);
    return stereo;
  }

  resetSelectionAndView() {
    this.pauseOffset = 0;
    this.selStart = 0;
    this.selEnd = this.audioBuffer ? this.audioBuffer.duration : 0;
    this.hasSelection = false;
    this.zoomLevel = 1;
    this.scrollOffset = 0;
    this.zoomWatermark.textContent = 'x1';
    this.rightCursorLine.style.display = 'none';
    this.btnMark.classList.remove('marked');
    this.updateStatusDisplay();
    this.updateCursorsUI();
  }

  pushUndo() {
    if (!this.audioBuffer) return;
    const copy = this.audioCtx.createBuffer(
      this.audioBuffer.numberOfChannels,
      this.audioBuffer.length,
      this.audioBuffer.sampleRate
    );
    for (let ch = 0; ch < this.audioBuffer.numberOfChannels; ch++) {
      copy.copyToChannel(this.audioBuffer.getChannelData(ch), ch);
    }
    this.undoStack.push(copy);
    if (this.undoStack.length > 10) this.undoStack.shift();
  }

  undo() {
    if (this.undoStack.length === 0) return alert('Nothing to undo.');
    this.stop();
    this.audioBuffer = this.undoStack.pop();
    this.resetSelectionAndView();
    this.renderWaveform();
  }

  // Transport: Play
  play() {
    if (!this.audioBuffer) return;
    if (this.isRecording) this.stopRecording();
    if (this.isPlaying) return;

    this.ensureAudioContext();
    this.sourceNode = this.audioCtx.createBufferSource();
    this.sourceNode.buffer = this.audioBuffer;
    this.sourceNode.playbackRate.value = this.playbackRate;

    this.analyserNode = this.audioCtx.createAnalyser();
    this.analyserNode.fftSize = 256;

    this.sourceNode.connect(this.analyserNode);
    this.analyserNode.connect(this.audioCtx.destination);

    const startAt = this.hasSelection ? this.selStart : this.pauseOffset;
    const duration = this.hasSelection ? Math.max(0.01, this.selEnd - this.selStart) : undefined;

    this.startTime = this.audioCtx.currentTime - startAt / this.playbackRate;
    if (duration !== undefined) {
      this.sourceNode.start(0, startAt, duration);
    } else {
      this.sourceNode.start(0, startAt);
    }

    this.isPlaying = true;
    this.isPaused = false;
    this.setActiveTransport(this.btnPlay);
    this.btnPlay.classList.add('playing');

    this.sourceNode.onended = () => {
      if (this.isPlaying) {
        this.isPlaying = false;
        this.pauseOffset = this.hasSelection ? this.selStart : 0;
        this.btnPlay.classList.remove('playing');
        this.updateStatusDisplay();
        this.updateCursorsUI();
      }
    };
  }

  // Transport: Pause
  pause() {
    if (this.isRecording) {
      this.stopRecording();
      return;
    }
    if (!this.isPlaying) return;
    this.pauseOffset = (this.audioCtx.currentTime - this.startTime) * this.playbackRate;
    this.isPlaying = false;
    this.isPaused = true;
    if (this.sourceNode) {
      try { this.sourceNode.stop(); } catch (_) {}
      this.sourceNode = null;
    }
    this.btnPlay.classList.remove('playing');
    this.setActiveTransport(this.btnPause);
    this.btnPause.classList.add('paused');
  }

  // Transport: Stop
  stop() {
    if (this.isRecording) {
      this.stopRecording();
    }
    if (this.sourceNode) {
      try { this.sourceNode.stop(); } catch (_) {}
      this.sourceNode = null;
    }
    this.isPlaying = false;
    this.isPaused = false;
    this.pauseOffset = this.hasSelection ? this.selStart : 0;
    this.btnPlay.classList.remove('playing');
    this.btnPause.classList.remove('paused');
    this.setActiveTransport(this.btnStop);
    this.updateStatusDisplay();
    this.updateCursorsUI();
  }

  // Transport: Record Microphone
  async toggleRecord() {
    if (this.isRecording) {
      this.stopRecording();
      return;
    }
    if (this.isPlaying) this.stop();

    try {
      this.ensureAudioContext();
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const micSource = this.audioCtx.createMediaStreamSource(this.mediaStream);
      const gainNode = this.audioCtx.createGain();
      gainNode.gain.value = Math.pow(10, this.recGainDb / 20);

      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 256;

      this.scriptProcessor = this.audioCtx.createScriptProcessor(4096, 2, 2);
      this.recordedChunksL = [];
      this.recordedChunksR = [];

      this.scriptProcessor.onaudioprocess = (e) => {
        if (!this.isRecording) return;
        gainNode.gain.value = Math.pow(10, this.recGainDb / 20);
        const inL = e.inputBuffer.getChannelData(0);
        const inR = e.inputBuffer.numberOfChannels > 1 ? e.inputBuffer.getChannelData(1) : inL;
        this.recordedChunksL.push(new Float32Array(inL));
        this.recordedChunksR.push(new Float32Array(inR));
      };

      micSource.connect(gainNode);
      gainNode.connect(this.analyserNode);
      gainNode.connect(this.scriptProcessor);
      this.scriptProcessor.connect(this.audioCtx.destination);

      this.isRecording = true;
      this.setActiveTransport(this.btnRecord);
      this.btnRecord.classList.add('recording');
      this.fileInfoDisplay.textContent = 'Recording Live...';
    } catch (err) {
      alert('Microphone permission denied or unavailable: ' + err.message);
    }
  }

  stopRecording() {
    if (!this.isRecording) return;
    this.isRecording = false;
    this.btnRecord.classList.remove('recording');

    if (this.scriptProcessor) {
      this.scriptProcessor.disconnect();
      this.scriptProcessor = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }

    const totalSamples = this.recordedChunksL.reduce((acc, c) => acc + c.length, 0);
    if (totalSamples > 0) {
      this.pushUndo();
      const newBuf = this.audioCtx.createBuffer(2, totalSamples, this.audioCtx.sampleRate);
      const ch0 = newBuf.getChannelData(0);
      const ch1 = newBuf.getChannelData(1);
      let offset = 0;
      for (let i = 0; i < this.recordedChunksL.length; i++) {
        ch0.set(this.recordedChunksL[i], offset);
        ch1.set(this.recordedChunksR[i], offset);
        offset += this.recordedChunksL[i].length;
      }
      this.audioBuffer = newBuf;
      this.resetSelectionAndView();
      this.fileInfoDisplay.textContent = `Recorded Stereo • ${this.audioBuffer.sampleRate} Hz`;
      this.renderWaveform();
    }
  }

  setActiveTransport(activeBtn) {
    [this.btnPlay, this.btnPause, this.btnRecord, this.btnMark, this.btnStop].forEach((b) => {
      b.classList.remove('active-border');
    });
    activeBtn.classList.add('active-border');
  }

  // Editing & DSP Actions
  getSelectionSampleRange() {
    const sr = this.audioBuffer.sampleRate;
    const start = this.hasSelection ? Math.floor(this.selStart * sr) : 0;
    const end = this.hasSelection ? Math.floor(this.selEnd * sr) : this.audioBuffer.length;
    return [Math.max(0, start), Math.min(this.audioBuffer.length, end)];
  }

  handleMenuAction(action) {
    if (action === 'undo') return this.undo();
    if (!this.audioBuffer) return alert('Open or record an audio file first.');

    const [start, end] = this.getSelectionSampleRange();
    const len = end - start;

    switch (action) {
      case 'selectAll':
        this.hasSelection = true;
        this.selStart = 0;
        this.selEnd = this.audioBuffer.duration;
        this.rightCursorLine.style.display = 'block';
        this.updateStatusDisplay();
        this.updateCursorsUI();
        break;

      case 'copy':
        if (len <= 0) return;
        this.clipboardBuffer = this.sliceBuffer(this.audioBuffer, start, end);
        break;

      case 'cut':
        if (len <= 0) return;
        this.pushUndo();
        this.clipboardBuffer = this.sliceBuffer(this.audioBuffer, start, end);
        this.audioBuffer = this.removeRange(this.audioBuffer, start, end);
        this.resetSelectionAndView();
        this.renderWaveform();
        break;

      case 'delete':
        if (len <= 0) return;
        this.pushUndo();
        this.audioBuffer = this.removeRange(this.audioBuffer, start, end);
        this.resetSelectionAndView();
        this.renderWaveform();
        break;

      case 'trim':
        if (len <= 0) return;
        this.pushUndo();
        this.audioBuffer = this.sliceBuffer(this.audioBuffer, start, end);
        this.resetSelectionAndView();
        this.renderWaveform();
        break;

      case 'paste':
        if (!this.clipboardBuffer) return alert('Clipboard is empty.');
        this.pushUndo();
        const insertPos = Math.floor(this.pauseOffset * this.audioBuffer.sampleRate);
        this.audioBuffer = this.insertBufferAt(this.audioBuffer, this.clipboardBuffer, insertPos);
        this.resetSelectionAndView();
        this.renderWaveform();
        break;

      case 'silence':
        this.pushUndo();
        const silBuf = this.audioCtx.createBuffer(2, this.audioBuffer.sampleRate, this.audioBuffer.sampleRate);
        const pos = Math.floor(this.pauseOffset * this.audioBuffer.sampleRate);
        this.audioBuffer = this.insertBufferAt(this.audioBuffer, silBuf, pos);
        this.resetSelectionAndView();
        this.renderWaveform();
        break;

      case 'fadeIn':
        this.pushUndo();
        for (let ch = 0; ch < 2; ch++) {
          const data = this.audioBuffer.getChannelData(ch);
          for (let i = start; i < end; i++) {
            data[i] *= (i - start) / Math.max(1, len);
          }
        }
        this.renderWaveform();
        break;

      case 'fadeOut':
        this.pushUndo();
        for (let ch = 0; ch < 2; ch++) {
          const data = this.audioBuffer.getChannelData(ch);
          for (let i = start; i < end; i++) {
            data[i] *= 1 - (i - start) / Math.max(1, len);
          }
        }
        this.renderWaveform();
        break;

      case 'normalize':
        this.pushUndo();
        let peak = 0;
        for (let ch = 0; ch < 2; ch++) {
          const data = this.audioBuffer.getChannelData(ch);
          for (let i = start; i < end; i++) {
            const abs = Math.abs(data[i]);
            if (abs > peak) peak = abs;
          }
        }
        if (peak > 0.0001) {
          const gain = 0.98 / peak;
          for (let ch = 0; ch < 2; ch++) {
            const data = this.audioBuffer.getChannelData(ch);
            for (let i = start; i < end; i++) {
              data[i] *= gain;
            }
          }
        }
        this.renderWaveform();
        break;

      case 'noiseReduction':
        this.pushUndo();
        for (let ch = 0; ch < 2; ch++) {
          const data = this.audioBuffer.getChannelData(ch);
          let prev = 0;
          for (let i = start; i < end; i++) {
            // Simple 1-pole high-pass + soft noise gate
            const hp = data[i] - 0.96 * prev;
            prev = data[i];
            data[i] = Math.abs(hp) < 0.012 ? hp * 0.15 : hp;
          }
        }
        this.renderWaveform();
        break;

      case 'compressor':
        this.pushUndo();
        const threshold = 0.35;
        const ratio = 4.0;
        for (let ch = 0; ch < 2; ch++) {
          const data = this.audioBuffer.getChannelData(ch);
          for (let i = start; i < end; i++) {
            const s = data[i];
            const abs = Math.abs(s);
            if (abs > threshold) {
              const compressed = threshold + (abs - threshold) / ratio;
              data[i] = Math.sign(s) * compressed * 1.4;
            } else {
              data[i] = s * 1.4;
            }
          }
        }
        this.renderWaveform();
        break;

      case 'vocalSplit':
        this.pushUndo();
        const L = this.audioBuffer.getChannelData(0);
        const R = this.audioBuffer.getChannelData(1);
        for (let i = start; i < end; i++) {
          const side = (L[i] - R[i]) * 0.85;
          L[i] = side;
          R[i] = -side;
        }
        this.renderWaveform();
        break;

      case 'eq':
        document.getElementById('eqModal').classList.remove('hidden');
        break;

      case 'speedPitch':
        document.getElementById('speedPitchModal').classList.remove('hidden');
        break;

      case 'mixFile':
        document.getElementById('mixFileInput').click();
        break;
    }
  }

  sliceBuffer(buf, start, end) {
    const len = Math.max(1, end - start);
    const out = this.audioCtx.createBuffer(2, len, buf.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      out.getChannelData(ch).set(buf.getChannelData(ch).subarray(start, end));
    }
    return out;
  }

  removeRange(buf, start, end) {
    const newLen = Math.max(1, buf.length - (end - start));
    const out = this.audioCtx.createBuffer(2, newLen, buf.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const src = buf.getChannelData(ch);
      const dst = out.getChannelData(ch);
      dst.set(src.subarray(0, start), 0);
      dst.set(src.subarray(end), start);
    }
    return out;
  }

  insertBufferAt(baseBuf, insBuf, pos) {
    const newLen = baseBuf.length + insBuf.length;
    const out = this.audioCtx.createBuffer(2, newLen, baseBuf.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const base = baseBuf.getChannelData(ch);
      const ins = insBuf.getChannelData(ch);
      const dst = out.getChannelData(ch);
      dst.set(base.subarray(0, pos), 0);
      dst.set(ins, pos);
      dst.set(base.subarray(pos), pos + ins.length);
    }
    return out;
  }

  async mixWithFile(file) {
    this.ensureAudioContext();
    const arr = await file.arrayBuffer();
    const mixDecoded = this.ensureStereo(await this.audioCtx.decodeAudioData(arr));
    this.pushUndo();
    const maxLen = Math.max(this.audioBuffer.length, mixDecoded.length);
    const out = this.audioCtx.createBuffer(2, maxLen, this.audioBuffer.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const a = this.audioBuffer.getChannelData(ch);
      const b = mixDecoded.getChannelData(ch);
      const dst = out.getChannelData(ch);
      for (let i = 0; i < maxLen; i++) {
        const va = i < a.length ? a[i] : 0;
        const vb = i < b.length ? b[i] : 0;
        dst[i] = Math.max(-1, Math.min(1, (va + vb) * 0.75));
      }
    }
    this.audioBuffer = out;
    this.resetSelectionAndView();
    this.renderWaveform();
  }

  // 10-Band EQ
  initEQModal() {
    const freqs = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
    const container = document.getElementById('eqSlidersContainer');
    freqs.forEach((f) => {
      const div = document.createElement('div');
      div.className = 'eq-band';
      const label = f >= 1000 ? `${f / 1000}k` : `${f}`;
      div.innerHTML = `<input type="range" min="-12" max="12" value="0" step="1" data-freq="${f}" /><span>${label}</span>`;
      container.appendChild(div);
    });

    document.getElementById('btnResetEq').addEventListener('click', () => {
      container.querySelectorAll('input').forEach((inp) => (inp.value = 0));
    });

    document.getElementById('btnApplyEq').addEventListener('click', async () => {
      if (!this.audioBuffer) return;
      this.pushUndo();
      const offline = new OfflineAudioContext(2, this.audioBuffer.length, this.audioBuffer.sampleRate);
      const src = offline.createBufferSource();
      src.buffer = this.audioBuffer;

      let prevNode = src;
      container.querySelectorAll('input').forEach((inp) => {
        const filter = offline.createBiquadFilter();
        filter.type = 'peaking';
        filter.frequency.value = parseFloat(inp.dataset.freq);
        filter.Q.value = 1.4;
        filter.gain.value = parseFloat(inp.value);
        prevNode.connect(filter);
        prevNode = filter;
      });
      prevNode.connect(offline.destination);
      src.start(0);
      this.audioBuffer = await offline.startRendering();
      this.renderWaveform();
      document.getElementById('eqModal').classList.add('hidden');
    });
  }

  async applySpeedAndPitch(speed, semitones) {
    if (!this.audioBuffer) return;
    this.pushUndo();
    const pitchRatio = Math.pow(2, semitones / 12);
    const totalRate = speed * pitchRatio;
    const newLength = Math.max(1, Math.floor(this.audioBuffer.length / totalRate));
    const offline = new OfflineAudioContext(2, newLength, this.audioBuffer.sampleRate);
    const src = offline.createBufferSource();
    src.buffer = this.audioBuffer;
    src.playbackRate.value = totalRate;
    src.connect(offline.destination);
    src.start(0);
    this.audioBuffer = await offline.startRendering();
    this.resetSelectionAndView();
    this.renderWaveform();
  }

  // Export WAV 16-bit PCM
  exportAudio() {
    const fileName = (document.getElementById('exportFileName').value || 'edited_audio').trim();
    const wavBlob = this.encodeWAV(this.audioBuffer);
    const url = URL.createObjectURL(wavBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}.wav`;
    a.click();
    URL.revokeObjectURL(url);
  }

  encodeWAV(buffer) {
    const numChannels = 2;
    const sampleRate = buffer.sampleRate;
    const length = buffer.length * numChannels * 2;
    const arrayBuffer = new ArrayBuffer(44 + length);
    const view = new DataView(arrayBuffer);

    const writeString = (offset, str) => {
      for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numChannels * 2, true);
    view.setUint16(32, numChannels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length, true);

    const ch0 = buffer.getChannelData(0);
    const ch1 = buffer.getChannelData(1);
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      const s0 = Math.max(-1, Math.min(1, ch0[i]));
      const s1 = Math.max(-1, Math.min(1, ch1[i]));
      view.setInt16(offset, s0 < 0 ? s0 * 0x8000 : s0 * 0x7fff, true);
      view.setInt16(offset + 2, s1 < 0 ? s1 * 0x8000 : s1 * 0x7fff, true);
      offset += 4;
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  clampScroll() {
    if (!this.audioBuffer) return;
    const visible = this.audioBuffer.duration / this.zoomLevel;
    this.scrollOffset = Math.max(0, Math.min(this.audioBuffer.duration - visible, this.scrollOffset));
  }

  // Render Lexis-style Stereo Waveform
  renderWaveform() {
    const rect = this.canvasArea.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;
    const ctx = this.ctx;

    ctx.clearRect(0, 0, w, h);

    // Horizontal center zero-lines for Left (top) & Right (bottom) channels
    const topCenter = h * 0.25;
    const bottomCenter = h * 0.75;

    ctx.strokeStyle = '#707070';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, topCenter);
    ctx.lineTo(w, topCenter);
    ctx.moveTo(0, bottomCenter);
    ctx.lineTo(w, bottomCenter);
    ctx.stroke();

    // Divider line between channels
    ctx.strokeStyle = '#333333';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.5);
    ctx.lineTo(w, h * 0.5);
    ctx.stroke();

    if (!this.audioBuffer) return;

    const totalSamples = this.audioBuffer.length;
    const visibleSamples = Math.floor(totalSamples / this.zoomLevel);
    const startSample = Math.floor((this.scrollOffset / this.audioBuffer.duration) * totalSamples);
    const step = Math.max(1, Math.floor(visibleSamples / w));

    const drawChannel = (channelData, centerY, maxAmp) => {
      ctx.fillStyle = '#3aa3c7';
      for (let x = 0; x < w; x++) {
        const idx = startSample + x * step;
        if (idx >= totalSamples) break;
        let min = 1.0;
        let max = -1.0;
        for (let j = 0; j < step && idx + j < totalSamples; j++) {
          const val = channelData[idx + j];
          if (val < min) min = val;
          if (val > max) max = val;
        }
        const yTop = centerY - max * maxAmp;
        const yBot = centerY - min * maxAmp;
        ctx.fillRect(x, yTop, 1, Math.max(1, yBot - yTop));
      }
    };

    drawChannel(this.audioBuffer.getChannelData(0), topCenter, h * 0.22);
    drawChannel(this.audioBuffer.getChannelData(1), bottomCenter, h * 0.22);
  }

  formatTime(sec) {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    const ms = Math.floor((sec % 1) * 1000);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(ms).padStart(3, '0')}`;
  }

  updateStatusDisplay() {
    const currentPos = this.isPlaying
      ? Math.min(this.audioBuffer.duration, (this.audioCtx.currentTime - this.startTime) * this.playbackRate)
      : this.pauseOffset;
    this.posDisplay.textContent = this.formatTime(currentPos);
    this.selDisplay.textContent = `${this.formatTime(this.selStart)} - ${this.formatTime(this.selEnd)}`;
  }

  updateCursorsUI() {
    if (!this.audioBuffer) {
      this.playheadLine.style.left = '0px';
      return;
    }
    const rect = this.canvasArea.getBoundingClientRect();
    const visibleDur = this.audioBuffer.duration / this.zoomLevel;
    const currentPos = this.isPlaying
      ? Math.min(this.audioBuffer.duration, (this.audioCtx.currentTime - this.startTime) * this.playbackRate)
      : this.pauseOffset;

    const leftRatio = (currentPos - this.scrollOffset) / visibleDur;
    const leftPx = Math.max(0, Math.min(rect.width, leftRatio * rect.width));
    this.playheadLine.style.left = `${leftPx}px`;

    if (this.hasSelection) {
      const selStartPx = Math.max(0, Math.min(rect.width, ((this.selStart - this.scrollOffset) / visibleDur) * rect.width));
      const selEndPx = Math.max(0, Math.min(rect.width, ((this.selEnd - this.scrollOffset) / visibleDur) * rect.width));
      this.rightCursorLine.style.left = `${selEndPx}px`;
      this.selectionOverlay.style.left = `${selStartPx}px`;
      this.selectionOverlay.style.width = `${Math.max(0, selEndPx - selStartPx)}px`;
    } else {
      this.selectionOverlay.style.width = '0px';
    }
  }

  startMeterLoop() {
    const dataArray = new Uint8Array(128);
    const loop = () => {
      if ((this.isPlaying || this.isRecording) && this.analyserNode) {
        this.analyserNode.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
        const avg = sum / dataArray.length;
        const pct = Math.min(100, (avg / 140) * 100);
        this.vuLeft.style.width = `${pct}%`;
        this.vuRight.style.width = `${Math.min(100, pct * 0.96)}%`;

        if (this.isPlaying) {
          this.updateStatusDisplay();
          this.updateCursorsUI();
        }
      } else {
        this.vuLeft.style.width = '0%';
        this.vuRight.style.width = '0%';
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.editor = new AudioEditorApp();
});
