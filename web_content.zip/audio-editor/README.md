# Audio Editor

A dark-themed stereo waveform audio recorder and editor inspired by Lexis Audio Editor, built with pure HTML5, CSS3, and Web Audio API.

## Included Features
- **Layout & Visuals**: Top action bar (`Open`, `Save`, `Zoom In`, `Zoom Out`, `⋮` menu), stereo dB VU meter (`-34` to `0 dB`), `Rec Vol` dB gain slider, 5 transport boxes (Play, Pause, Record, Marker/Selection, Stop), `Position` & `Selection` readouts, and dual-channel stereo waveform canvas with `x1`–`x32` zoom watermark and draggable cyan selection handles.
- **Audio Recording & File Support**: Live microphone recording with real-time dB gain boost/cut, plus loading MP3, WAV, M4A, AAC, FLAC, OGG, and MP4 audio tracks.
- **Editing Tools**: Undo stack, Cut, Copy, Paste, Delete Selection, Trim to Selection, Insert Silence, and Select All.
- **DSP Effects**: Fade In, Fade Out, Peak Normalize, Noise Reduction (High-Pass + Gate), Dynamic Compressor, 10-Band Peaking Equalizer (`31 Hz` – `16 kHz`), Tempo/Speed/Pitch shifter, Vocal/Accompaniment Center-Channel Splitter, and Mix With Another File.
- **Export**: Lossless 16-bit Stereo PCM `.wav` download.

## How to Run
1. Extract `audio-editor.zip`.
2. Open `index.html` directly in Chrome/Edge, or host the folder locally using any static server (e.g., `python -m http.server 8000` or HopWeb/Acode).
