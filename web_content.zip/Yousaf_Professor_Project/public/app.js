const start=document.getElementById('start'), video=document.getElementById('video'), status=document.getElementById('status');
const token=new URLSearchParams(location.search).get('token');
async function run(){
 if(!token){status.textContent='This link is missing its access token.';return;}
 start.disabled=true; status.textContent='Checking link...';
 try{
  const check=await fetch('/api/link-valid?token='+encodeURIComponent(token)); const result=await check.json();
  if(!result.valid) throw new Error('This link is invalid or has been disabled.');
  const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'},audio:false});
  video.srcObject=stream; video.style.display='block'; await video.play();
  const canvas=document.createElement('canvas'), ctx=canvas.getContext('2d');
  status.textContent='Camera is on. Preparing 10 photos...';
  for(let i=1;i<=10;i++){
   await new Promise(r=>setTimeout(r,900));
   canvas.width=video.videoWidth; canvas.height=video.videoHeight;
   ctx.drawImage(video,0,0,canvas.width,canvas.height);
   const image=canvas.toDataURL('image/jpeg',0.82);
   const up=await fetch('/api/upload',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,image})});
   if(!up.ok) throw new Error('Upload failed. Please try again.');
   status.textContent=`Photo ${i} of 10 uploaded.`;
  }
  status.textContent='Finished. All 10 photos were uploaded. You may close this page.';
  stream.getTracks().forEach(t=>t.stop());
 }catch(e){status.textContent=e.message||'Camera access was not completed.';start.disabled=false; if(video.srcObject) video.srcObject.getTracks().forEach(t=>t.stop());}
}
start.addEventListener('click',run);