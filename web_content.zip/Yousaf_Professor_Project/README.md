# Yousaf Professor — consent-based camera link project

This is a deployable mobile-friendly web app (not a compiled APK and not hosted yet).

## What it does
- Admin dashboard creates a unique link.
- Visitor opens the link and sees a clear disclosure explaining that 10 photos will be taken and uploaded.
- Visitor must press **Agree & Start** and approve the browser camera permission.
- The page visibly shows the camera preview and progress while 10 photos upload.
- Admin dashboard displays uploaded photos and can disable links.

## Run locally
1. Install Node.js 18 or newer.
2. Open this folder in a terminal.
3. Run `ADMIN_KEY='use-a-long-private-password' node server.js`
4. Open `http://localhost:3000/admin` and enter the same admin key.
5. Generate a link. For camera access on another phone, deploy behind HTTPS; browsers require a secure context for camera access.

## Deploy
Deploy this folder to a Node.js host that supports persistent disk storage. Set:
- `ADMIN_KEY` to a long random secret
- `PORT` if your host requires it

The host must preserve `data.json` and the `uploads/` folder between restarts. Use HTTPS. Do not publish the admin URL/key. This demo has no user accounts or encryption-at-rest; use it only with people who knowingly consent. Add authentication, rate limiting, retention/deletion controls, and encrypted storage before production use.

## Android
This is a mobile web app that works in Android Chrome once hosted over HTTPS. It is not an APK. A native APK wrapper can be made later, but it must retain the same visible consent and permission flow.
