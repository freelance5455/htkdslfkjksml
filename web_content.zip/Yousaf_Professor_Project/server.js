const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || "CHANGE_THIS_ADMIN_KEY";
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const UPLOADS = path.join(ROOT, "uploads");
const DB = path.join(ROOT, "data.json");
if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({ links: [], photos: [] }, null, 2));

function readDB() { return JSON.parse(fs.readFileSync(DB, "utf8")); }
function writeDB(db) { fs.writeFileSync(DB, JSON.stringify(db, null, 2)); }
function send(res, status, body, type="application/json") {
  res.writeHead(status, {"Content-Type": type, "Cache-Control":"no-store", "X-Content-Type-Options":"nosniff"});
  res.end(body);
}
function json(res, status, obj) { send(res, status, JSON.stringify(obj)); }
function body(req) {
  return new Promise((resolve, reject) => {
    let data = ""; req.on("data", c => { data += c; if (data.length > 18*1024*1024) reject(new Error("Too large")); });
    req.on("end", () => { try { resolve(JSON.parse(data || "{}")); } catch(e) { reject(e); } });
    req.on("error", reject);
  });
}
function admin(req, url) {
  return req.headers["x-admin-key"] === ADMIN_KEY || url.searchParams.get("key") === ADMIN_KEY;
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  try {
    if (req.method === "GET" && url.pathname === "/") {
      return send(res, 200, fs.readFileSync(path.join(PUBLIC, "home.html")), "text/html; charset=utf-8");
    }
    if (req.method === "GET" && url.pathname === "/admin") {
      return send(res, 200, fs.readFileSync(path.join(PUBLIC, "admin.html")), "text/html; charset=utf-8");
    }
    if (req.method === "GET" && url.pathname === "/app.js") {
      return send(res, 200, fs.readFileSync(path.join(PUBLIC, "app.js")), "text/javascript; charset=utf-8");
    }
    if (req.method === "GET" && url.pathname === "/admin.js") {
      return send(res, 200, fs.readFileSync(path.join(PUBLIC, "admin.js")), "text/javascript; charset=utf-8");
    }
    if (req.method === "GET" && url.pathname === "/api/link-valid") {
      const token = url.searchParams.get("token"); const db = readDB();
      return json(res, 200, { valid: !!db.links.find(x => x.token === token && x.active) });
    }
    if (req.method === "POST" && url.pathname === "/api/create-link") {
      if (!admin(req, url)) return json(res, 401, {error:"Admin key incorrect"});
      const db = readDB(); const token = crypto.randomBytes(16).toString("hex");
      db.links.unshift({ token, createdAt: new Date().toISOString(), active: true });
      writeDB(db);
      return json(res, 200, { token });
    }
    if (req.method === "POST" && url.pathname === "/api/upload") {
      const b = await body(req); const db = readDB();
      const link = db.links.find(x => x.token === b.token && x.active);
      if (!link) return json(res, 403, {error:"Invalid or inactive link"});
      if (typeof b.image !== "string" || !b.image.startsWith("data:image/jpeg;base64,")) return json(res, 400, {error:"Invalid image"});
      const raw = Buffer.from(b.image.split(",")[1], "base64");
      if (raw.length > 2*1024*1024) return json(res, 413, {error:"Image too large"});
      const id = crypto.randomBytes(10).toString("hex");
      const filename = `${id}.jpg`; fs.writeFileSync(path.join(UPLOADS, filename), raw);
      db.photos.unshift({ id, token: b.token, filename, createdAt: new Date().toISOString() });
      writeDB(db); return json(res, 200, {ok:true});
    }
    if (req.method === "GET" && url.pathname === "/api/admin-data") {
      if (!admin(req, url)) return json(res, 401, {error:"Admin key incorrect"});
      const db = readDB();
      return json(res, 200, {links:db.links, photos:db.photos});
    }
    if (req.method === "POST" && url.pathname === "/api/deactivate") {
      if (!admin(req, url)) return json(res, 401, {error:"Admin key incorrect"});
      const b = await body(req); const db = readDB(); const link = db.links.find(x=>x.token===b.token);
      if (link) link.active = false; writeDB(db); return json(res, 200, {ok:true});
    }
    if (req.method === "GET" && url.pathname.startsWith("/uploads/")) {
      const name = path.basename(url.pathname);
      if (!/^[a-f0-9]+\\.jpg$/.test(name)) return json(res,404,{error:"Not found"});
      const file = path.join(UPLOADS,name); if (!fs.existsSync(file)) return json(res,404,{error:"Not found"});
      return send(res,200,fs.readFileSync(file),"image/jpeg");
    }
    return json(res,404,{error:"Not found"});
  } catch (e) { return json(res,400,{error:"Request failed"}); }
});
server.listen(PORT, () => console.log(`Yousaf Professor running on port ${PORT}`));
