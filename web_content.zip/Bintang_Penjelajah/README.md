BINTANG PENJELAJAH — APK INPUT (VERSI PERBAIKAN)

Game HTML5 offline untuk dibungkus menjadi APK Android.
Perubahan versi ini:
- Mencegah pemilihan teks / menu Salin saat tekan lama.
- Roket digambar ulang dengan badan metalik, kokpit bercahaya, sirip merah, dan api mesin.
- Setiap bintang yang dikumpulkan menambah 1 nyawa tanpa batas maksimum.

File utama: index.html
