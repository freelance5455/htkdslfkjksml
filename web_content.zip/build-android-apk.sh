#!/usr/bin/env bash
set -euo pipefail

echo "=== Dawitai Android APK Build Helper ==="
echo "1) Installing dependencies..."
npm install

echo "2) Building web assets..."
npm run build

echo "3) Setting up Capacitor Android project..."
if [ ! -d "android" ]; then
  npm install @capacitor/core @capacitor/cli @capacitor/android
  npx cap add android
fi

npx cap sync android
echo "Done! Open ./android in Android Studio or run: cd android && ./gradlew assembleDebug"
