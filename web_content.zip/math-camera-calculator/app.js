(function () {
  "use strict";

  const expressionEl = document.getElementById("expression");
  const resultEl = document.getElementById("result");
  const calcPad = document.getElementById("calcPad");
  const sourceSection = document.getElementById("sourceSection");
  const cameraSection = document.getElementById("cameraSection");
  const previewSection = document.getElementById("previewSection");
  const video = document.getElementById("video");
  const canvas = document.getElementById("canvas");
  const previewImg = document.getElementById("previewImg");
  const ocrStatus = document.getElementById("ocrStatus");
  const fileInput = document.getElementById("fileInput");
  const sourceError = document.getElementById("sourceError");

  let stream = null;
  let currentExpr = "";

  // ---------- Calculator core ----------
  function updateDisplay() {
    expressionEl.textContent = currentExpr;
    if (!currentExpr) {
      resultEl.textContent = "0";
      return;
    }
    try {
      const cleaned = prepareExpr(currentExpr);
      const val = math.evaluate(cleaned);
      if (typeof val === "number" && isFinite(val)) {
        resultEl.textContent = formatNumber(val);
      } else if (val && typeof val.toString === "function") {
        resultEl.textContent = val.toString();
      } else {
        resultEl.textContent = "…";
      }
    } catch {
      resultEl.textContent = "…";
    }
  }

  function prepareExpr(str) {
    return str
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/%/g, "/100")
      .replace(/√\s*\(?\s*([^)]+)\)?/g, "sqrt($1)")
      .replace(/√(\d+(\.\d+)?)/g, "sqrt($1)")
      .trim();
  }

  function formatNumber(n) {
    if (Number.isInteger(n)) return n.toString();
    const s = n.toPrecision(12);
    return parseFloat(s).toString();
  }

  function append(val) {
    currentExpr += val;
    updateDisplay();
  }

  function clearAll() {
    currentExpr = "";
    updateDisplay();
  }

  function backspace() {
    currentExpr = currentExpr.slice(0, -1);
    updateDisplay();
  }

  function equals() {
    try {
      const cleaned = prepareExpr(currentExpr);
      const val = math.evaluate(cleaned);
      if (typeof val === "number" && isFinite(val)) {
        currentExpr = formatNumber(val);
        resultEl.textContent = currentExpr;
        expressionEl.textContent = "";
      } else {
        resultEl.textContent = "Ошибка";
      }
    } catch (e) {
      resultEl.textContent = "Ошибка";
    }
  }

  // ---------- Button handlers ----------
  calcPad.addEventListener("click", (e) => {
    const btn = e.target.closest(".btn");
    if (!btn) return;

    const action = btn.dataset.action;
    const value = btn.dataset.value;

    if (action === "clear") clearAll();
    else if (action === "backspace") backspace();
    else if (action === "percent") append("%");
    else if (action === "equals") equals();
    else if (action === "photo") showSourceChoice();
    else if (value) append(value);
  });

  expressionEl.addEventListener("input", () => {
    currentExpr = expressionEl.textContent;
    updateDisplay();
  });

  // ---------- Source choice ----------
  function showSourceChoice() {
    sourceError.textContent = "";
    sourceSection.classList.remove("hidden");
    cameraSection.classList.add("hidden");
    previewSection.classList.add("hidden");
    calcPad.classList.add("hidden");
  }

  function hideAllPhotoUI() {
    sourceSection.classList.add("hidden");
    cameraSection.classList.add("hidden");
    previewSection.classList.add("hidden");
    calcPad.classList.remove("hidden");
    stopCamera();
  }

  document.getElementById("btnCancelSource").addEventListener("click", hideAllPhotoUI);

  document.getElementById("btnGallery").addEventListener("click", () => {
    sourceError.textContent = "";
    // Prefer pure gallery (no capture attribute forced)
    fileInput.removeAttribute("capture");
    fileInput.click();
  });

  document.getElementById("btnCamera").addEventListener("click", () => {
    sourceError.textContent = "";
    openCamera();
  });

  // ---------- Gallery (file input) — works in most APKs ----------
  fileInput.addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      previewImg.src = reader.result;
      sourceSection.classList.add("hidden");
      cameraSection.classList.add("hidden");
      previewSection.classList.remove("hidden");
      ocrStatus.textContent = "";
      // reset input so same file can be chosen again
      fileInput.value = "";
    };
    reader.onerror = () => {
      sourceError.textContent = "Не удалось прочитать файл";
    };
    reader.readAsDataURL(file);
  });

  // ---------- Camera (often broken in WebView APKs) ----------
  async function openCamera() {
    sourceError.textContent = "";

    // Check support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      sourceError.textContent =
        "Камера не поддерживается в этом APK.\nИспользуй «Галерею» — сфотографируй пример обычной камерой и выбери фото.";
      return;
    }

    // Secure context check (file:// and many WebViews fail)
    if (!window.isSecureContext && location.protocol !== "https:" && location.hostname !== "localhost") {
      sourceError.textContent =
        "Камера требует безопасный контекст (https).\nВ APK это часто не работает.\nИспользуй «Галерею».";
      return;
    }

    try {
      // Try with simpler constraints first (more compatible)
      const constraints = {
        video: {
          facingMode: "environment"
        },
        audio: false
      };

      stream = await navigator.mediaDevices.getUserMedia(constraints);
      video.srcObject = stream;

      // Wait for video to be ready
      await new Promise((resolve) => {
        if (video.readyState >= 2) resolve();
        else video.onloadedmetadata = resolve;
      });

      sourceSection.classList.add("hidden");
      cameraSection.classList.remove("hidden");
      previewSection.classList.add("hidden");
    } catch (err) {
      console.error("Camera error:", err);
      let msg = "Не удалось открыть камеру.\n";

      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        msg += "Разрешение отклонено. В настройках Android → Приложения → это приложение → Разрешения → Камера → Разрешить.\n\nИли просто используй «Галерею».";
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        msg += "Камера не найдена на устройстве.";
      } else if (err.name === "NotReadableError" || err.name === "TrackStartError") {
        msg += "Камера занята другим приложением. Закрой другие приложения с камерой.";
      } else if (err.name === "OverconstrainedError") {
        msg += "Не удалось применить настройки камеры.";
      } else {
        msg += (err.message || err.name || "Неизвестная ошибка") + "\n\nРекомендуется использовать «Галерею».";
      }

      sourceError.textContent = msg;
    }
  }

  function stopCamera() {
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
      stream = null;
    }
    video.srcObject = null;
  }

  function closeCamera() {
    stopCamera();
    cameraSection.classList.add("hidden");
    // go back to source choice
    sourceSection.classList.remove("hidden");
  }

  document.getElementById("closeCameraBtn").addEventListener("click", closeCamera);

  document.getElementById("captureBtn").addEventListener("click", () => {
    if (!stream) return;
    const w = video.videoWidth || 640;
    const h = video.videoHeight || 480;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, w, h);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
    previewImg.src = dataUrl;
    stopCamera();
    cameraSection.classList.add("hidden");
    previewSection.classList.remove("hidden");
    ocrStatus.textContent = "";
  });

  document.getElementById("retryBtn").addEventListener("click", () => {
    previewSection.classList.add("hidden");
    showSourceChoice();
  });

  document.getElementById("recognizeBtn").addEventListener("click", recognize);

  // ---------- OCR + solve ----------
  async function recognize() {
    const dataUrl = previewImg.src;
    if (!dataUrl) return;

    ocrStatus.textContent = "Распознаю… (5–20 сек)";
    const btn = document.getElementById("recognizeBtn");
    btn.disabled = true;

    try {
      const { data: { text } } = await Tesseract.recognize(dataUrl, "eng+rus", {
        logger: (m) => {
          if (m.status === "recognizing text") {
            ocrStatus.textContent = "Распознаю… " + Math.round(m.progress * 100) + "%";
          }
        }
      });

      const cleaned = cleanOcrText(text);
      ocrStatus.textContent = cleaned ? "Найдено: " + cleaned : "Ничего не распознано. Попробуй другое фото.";

      if (cleaned) {
        currentExpr = cleaned;
        updateDisplay();
        setTimeout(() => {
          equals();
          hideAllPhotoUI();
        }, 700);
      }
    } catch (err) {
      ocrStatus.textContent = "Ошибка OCR: " + (err.message || err);
      console.error(err);
    } finally {
      btn.disabled = false;
    }
  }

  function cleanOcrText(raw) {
    if (!raw) return "";

    let s = raw
      .replace(/\n/g, " ")
      .replace(/[|Il]/g, "1")
      .replace(/[Oo]/g, "0")
      .replace(/[Ss]/g, "5")
      .replace(/×|x|X|х|Х/g, "*")
      .replace(/÷/g, "/")
      .replace(/−|–|—/g, "-")
      .replace(/,/g, ".")
      .replace(/[^0-9+\-*/().^=√% ]/g, "")
      .replace(/\s+/g, "")
      .trim();

    s = s.replace(/^=/, "").replace(/=$/, "");

    if (s.includes("=")) {
      const parts = s.split("=");
      if (parts.length === 2 && parts[0]) {
        s = parts[0];
      }
    }

    return s;
  }

  // Initial
  updateDisplay();
})();
