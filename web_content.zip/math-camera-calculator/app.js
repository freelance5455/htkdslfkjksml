(function () {
  "use strict";

  const expressionEl = document.getElementById("expression");
  const resultEl = document.getElementById("result");
  const calcPad = document.getElementById("calcPad");
  const cameraSection = document.getElementById("cameraSection");
  const previewSection = document.getElementById("previewSection");
  const video = document.getElementById("video");
  const canvas = document.getElementById("canvas");
  const previewImg = document.getElementById("previewImg");
  const ocrStatus = document.getElementById("ocrStatus");

  let stream = null;
  let currentExpr = "";

  // ---------- Calculator core ----------
  function updateDisplay() {
    expressionEl.textContent = currentExpr;
    if (!currentExpr) {
      resultEl.textContent = "0";
      return;
    }
    try {
      const cleaned = prepareExpr(currentExpr);
      const val = math.evaluate(cleaned);
      if (typeof val === "number" && isFinite(val)) {
        resultEl.textContent = formatNumber(val);
      } else if (val && typeof val.toString === "function") {
        resultEl.textContent = val.toString();
      } else {
        resultEl.textContent = "…";
      }
    } catch {
      resultEl.textContent = "…";
    }
  }

  function prepareExpr(str) {
    return str
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/%/g, "/100")
      .replace(/√\s*\(?\s*([^)]+)\)?/g, "sqrt($1)")
      .replace(/√(\d+(\.\d+)?)/g, "sqrt($1)")
      .trim();
  }

  function formatNumber(n) {
    if (Number.isInteger(n)) return n.toString();
    const s = n.toPrecision(12);
    return parseFloat(s).toString();
  }

  function append(val) {
    currentExpr += val;
    updateDisplay();
  }

  function clearAll() {
    currentExpr = "";
    updateDisplay();
  }

  function backspace() {
    currentExpr = currentExpr.slice(0, -1);
    updateDisplay();
  }

  function equals() {
    try {
      const cleaned = prepareExpr(currentExpr);
      const val = math.evaluate(cleaned);
      if (typeof val === "number" && isFinite(val)) {
        currentExpr = formatNumber(val);
        resultEl.textContent = currentExpr;
        expressionEl.textContent = "";
      } else {
        resultEl.textContent = "Ошибка";
      }
    } catch (e) {
      resultEl.textContent = "Ошибка";
    }
  }

  // ---------- Button handlers ----------
  calcPad.addEventListener("click", (e) => {
    const btn = e.target.closest(".btn");
    if (!btn) return;

    const action = btn.dataset.action;
    const value = btn.dataset.value;

    if (action === "clear") clearAll();
    else if (action === "backspace") backspace();
    else if (action === "percent") append("%");
    else if (action === "equals") equals();
    else if (action === "camera") openCamera();
    else if (value) append(value);
  });

  // Allow typing on the expression field (desktop)
  expressionEl.addEventListener("input", () => {
    currentExpr = expressionEl.textContent;
    updateDisplay();
  });

  // ---------- Camera ----------
  async function openCamera() {
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });
      video.srcObject = stream;
      cameraSection.classList.remove("hidden");
      previewSection.classList.add("hidden");
      calcPad.classList.add("hidden");
    } catch (err) {
      alert("Не удалось открыть камеру.\nРазреши доступ к камере в настройках браузера.\n\n" + err.message);
    }
  }

  function closeCamera() {
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
      stream = null;
    }
    video.srcObject = null;
    cameraSection.classList.add("hidden");
    previewSection.classList.add("hidden");
    calcPad.classList.remove("hidden");
  }

  document.getElementById("closeCameraBtn").addEventListener("click", closeCamera);

  document.getElementById("captureBtn").addEventListener("click", () => {
    if (!stream) return;
    const w = video.videoWidth;
    const h = video.videoHeight;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, w, h);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
    previewImg.src = dataUrl;
    cameraSection.classList.add("hidden");
    previewSection.classList.remove("hidden");
    ocrStatus.textContent = "";
  });

  document.getElementById("retryBtn").addEventListener("click", () => {
    previewSection.classList.add("hidden");
    cameraSection.classList.remove("hidden");
  });

  document.getElementById("recognizeBtn").addEventListener("click", recognize);

  // ---------- OCR + solve ----------
  async function recognize() {
    const dataUrl = previewImg.src;
    if (!dataUrl) return;

    ocrStatus.textContent = "Распознаю… (может занять 5–15 сек)";
    document.getElementById("recognizeBtn").disabled = true;

    try {
      const { data: { text } } = await Tesseract.recognize(dataUrl, "eng+rus", {
        logger: (m) => {
          if (m.status === "recognizing text") {
            ocrStatus.textContent = `Распознаю… ${Math.round(m.progress * 100)}%`;
          }
        }
      });

      const cleaned = cleanOcrText(text);
      ocrStatus.textContent = cleaned ? `Найдено: ${cleaned}` : "Ничего не распознано. Попробуй ещё раз.";

      if (cleaned) {
        currentExpr = cleaned;
        updateDisplay();
        // Try to solve immediately
        setTimeout(() => {
          equals();
          closeCamera();
          calcPad.classList.remove("hidden");
        }, 600);
      }
    } catch (err) {
      ocrStatus.textContent = "Ошибка OCR: " + err.message;
      console.error(err);
    } finally {
      document.getElementById("recognizeBtn").disabled = false;
    }
  }

  function cleanOcrText(raw) {
    if (!raw) return "";

    // Keep only math-relevant characters and common OCR mistakes
    let s = raw
      .replace(/\n/g, " ")
      .replace(/[|Il]/g, "1")
      .replace(/[Oo]/g, "0")
      .replace(/[Ss]/g, "5")
      .replace(/×|x|X|х|Х/g, "*")
      .replace(/÷/g, "/")
      .replace(/−|–|—/g, "-")
      .replace(/,/g, ".")
      .replace(/[^0-9+\-*/().^=√% ]/g, "")
      .replace(/\s+/g, "")
      .trim();

    // Simple fixes
    s = s.replace(/^\=/, "");
    s = s.replace(/\=$/, "");

    // If it looks like an equation "a=b", try to move everything to left
    if (s.includes("=")) {
      const parts = s.split("=");
      if (parts.length === 2 && parts[0] && parts[1]) {
        // For simple cases just evaluate right side or leave expression
        s = parts[0]; // keep left side for now, or could do parts[0] - (parts[1])
      }
    }

    return s;
  }

  // Initial
  updateDisplay();
})();
