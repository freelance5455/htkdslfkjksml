EVSL AUTO MAINTENANCE MANAGEMENT – ADVANCED PROFESSIONAL PACKAGE v9

Included:
1) EVSL_Auto_Maintenance_Advanced_v9_Offline.html – main maintenance app.
2) sap-learning.html – separate SAP-style mobile learning and practice module.
3) EVSL_Professional_Source/ – Android WebView project source and offline web assets.
4) SAP service worker and manifest files.

How to use:
- Extract the ZIP on your phone or computer.
- Open EVSL_Auto_Maintenance_Advanced_v8_Offline.html in a modern browser.
- Tap “SAP Mobile Learning / SAP ट्रेनिंग” in the header to open the SAP learning module.
- Main maintenance records are stored locally in the browser/device. Use Backup Now regularly and keep JSON backups safe.
- SAP practice module is a learning simulator; it is not connected to EVSL/company SAP server and does not post real SAP transactions.

Important:
- This ZIP is a source/offline web package, not an installable APK.
- The included Android folder is project source. Building an APK requires Android Studio/Gradle and a signing setup.
- For preserving existing APK data, do not uninstall the old app. APK updates require the same application ID and signing key, and WebView storage migration/backup should be tested before replacing an installed app.
