EVSL AUTO MAINTENANCE MANAGEMENT – PROFESSIONAL SOURCE PACKAGE

इस ZIP में क्या है
1) www/index.html – उपलब्ध Advanced Offline v4 का web source
2) www/manifest.webmanifest और www/sw.js – PWA/offline install support
3) android/ – Android Studio WebView wrapper का source scaffold
4) REQUIREMENTS_NEXT_VERSION.txt – अगली Professional build की feature checklist

महत्वपूर्ण स्थिति
- यह ZIP Source Project है, signed installable APK नहीं है।
- इस environment में Android SDK/Gradle build tool उपलब्ध नहीं मिला, इसलिए APK compile नहीं किया गया।
- पुराने APK का package name और signing certificate उपलब्ध नहीं है। इन्हें जाने बिना नया APK पुराने APK के ऊपर सुरक्षित update के रूप में install होने की गारंटी नहीं दी जा सकती।
- पुराने APK को uninstall न करें। पहले app के Backup/Restore पेज से JSON backup डाउनलोड करके सुरक्षित रखें।
- पुराने APK की signing key यदि user ke paas नहीं है, तो same-app update संभव नहीं हो सकता; ऐसी स्थिति में data export/import migration जरूरी होगी।

Android Studio में खोलना
- android/ फ़ोल्डर को Android Studio में खोलें।
- Gradle sync करें और Android SDK install/configure करें।
- Build > Build APK(s) से debug APK बनाया जा सकता है।
- Release APK के लिए अपनी सुरक्षित signing key configure करनी होगी।

वर्तमान v4 में मौजूद प्रमुख भाग
Dashboard, Vehicle Master, Breakdown Entry, Preventive Maintenance (basic vehicle-level hour interval), Service History, Spare Parts Inventory, Daily Work Report, Fault Diagnosis, Reports, Vehicle Parts Master, Analytics, Backup/Restore.

नोट: अगली checklist में fabrication-only entry, multi-complaint/multi-part breakdown, per-service hour/month intervals, part image catalogue/search, editable vehicle master, richer vehicle specifications, और data migration validation शामिल हैं। इन सुविधाओं को पूरी तरह implement/test किए बिना उन्हें complete नहीं माना जाना चाहिए।
