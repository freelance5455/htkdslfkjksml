'use strict';
// إنشاء حساب «مشرف المنصة» من سطر الأوامر فقط — لا توجد صفحة عامة لذلك.
// الاستعمال:  node server/create-account.js supervisor اسم_المستخدم "الاسم الكامل"
// (حسابات المديرين يصدرها المشرف من داخل المنصة، لكل مؤسسة على حدة)
const readline = require('node:readline');
const { platform } = require('./db');
const { hashPw } = require('./server');

const [role, username, ...nameParts] = process.argv.slice(2);
const full_name = nameParts.join(' ');
if (role !== 'supervisor' || !/^[a-z0-9_.]{3,30}$/.test(username || '') || !full_name) {
  console.log('الاستعمال: node server/create-account.js supervisor <username> "الاسم الكامل"');
  process.exit(1);
}
function ask(q) {
  if (process.env.WASL_PASSWORD) return Promise.resolve(process.env.WASL_PASSWORD);
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(r => rl.question(q, a => { rl.close(); r(a); }));
}
(async () => {
  const pw = await ask('كلمة المرور (8 أحرف على الأقل): ');
  if (pw.length < 8) { console.log('كلمة المرور قصيرة'); process.exit(1); }
  if (platform.prepare('SELECT id FROM users WHERE username=?').get(username)) { console.log('اسم المستخدم موجود'); process.exit(1); }
  platform.prepare("INSERT INTO users(username,pass_hash,full_name,role,status,created_at) VALUES(?,?,?,?,'active',?)")
    .run(username, hashPw(pw), full_name, 'supervisor', new Date().toISOString());
  console.log(`تم إنشاء المشرف: ${username} — يدخل بـ«رمز المؤسسة» = ${process.env.PLATFORM_CODE || 'platform'}`);
  process.exit(0);
})();
