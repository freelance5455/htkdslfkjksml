'use strict';
// طبقة قواعد البيانات — عزل المؤسسات بالتصميم:
//  • platform.db : سجل المؤسسات + حسابات المشرفين + سجل عمليات المنصة.
//  • tenants/<code>.db : قاعدة بيانات مستقلة تمامًا لكل مؤسسة (أعضاؤها، غياباتها، علاماتها...).
// لا يوجد أي استعلام يمكنه الوصول إلى مؤسستين معًا، لأن كل طلب يعمل على ملف واحد فقط.
const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

const DATA = process.env.WASL_DATA || path.join(__dirname, '..', 'data');
const TENANTS = path.join(DATA, 'tenants');
fs.mkdirSync(TENANTS, { recursive: true });

const SCHEMA = `
CREATE TABLE IF NOT EXISTS institutions(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE, name TEXT NOT NULL UNIQUE, region TEXT,
  status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sections(
  id INTEGER PRIMARY KEY, level TEXT NOT NULL, branch TEXT, name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT,
  pass_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',      -- pending | active | disabled | rejected
  section_id INTEGER REFERENCES sections(id),   -- القسم (للتلميذ، ولقسم ابن الولي)
  subject TEXT,                                 -- مادة الأستاذ
  child_name TEXT,                              -- اسم ابن الولي كما كتبه عند التسجيل
  child_id INTEGER REFERENCES users(id),        -- الربط الفعلي بالتلميذ بعد الموافقة
  institution_id INTEGER REFERENCES institutions(id),
  must_change INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS teacher_sections(
  teacher_id INTEGER NOT NULL REFERENCES users(id),
  section_id INTEGER NOT NULL REFERENCES sections(id),
  PRIMARY KEY(teacher_id, section_id)
);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS roster(            -- القائمة الرسمية التي يرفعها المدير
  id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, role TEXT NOT NULL,
  section_id INTEGER REFERENCES sections(id), claimed_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS announcements(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, audience TEXT NOT NULL,
  author_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attendance(
  id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES users(id),
  date TEXT NOT NULL, status TEXT NOT NULL, recorded_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS grades(
  id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL, kind TEXT NOT NULL, mark REAL NOT NULL,
  teacher_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS lessons(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, subject TEXT NOT NULL, kind TEXT NOT NULL, body TEXT NOT NULL,
  section_id INTEGER NOT NULL REFERENCES sections(id), author_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS summons(
  id INTEGER PRIMARY KEY, parent_id INTEGER NOT NULL REFERENCES users(id),
  student_id INTEGER NOT NULL REFERENCES users(id), reason TEXT NOT NULL, date TEXT,
  status TEXT NOT NULL, created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, assignee_id INTEGER NOT NULL REFERENCES users(id),
  assigned_by INTEGER REFERENCES users(id), status TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, visibility TEXT NOT NULL,
  anonymous INTEGER NOT NULL DEFAULT 0, sender_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'جديد', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), text TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS approvals(          -- طلبات الناظر الحساسة بانتظار المدير
  id INTEGER PRIMARY KEY, type TEXT NOT NULL, payload TEXT NOT NULL, description TEXT NOT NULL,
  requested_by INTEGER NOT NULL REFERENCES users(id), status TEXT NOT NULL DEFAULT 'pending',
  decided_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id), action TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_att_student ON attendance(student_id);
CREATE INDEX IF NOT EXISTS idx_grades_student ON grades(student_id);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_email ON users(email) WHERE email IS NOT NULL;
`;

function open(file) {
  const d = new DatabaseSync(file);
  d.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
  d.exec(SCHEMA);
  return d;
}

const platform = open(path.join(DATA, 'platform.db'));
const CODE_RE = /^[a-z0-9-]{3,30}$/;   // يمنع أي محاولة للخروج من المجلد عبر اسم الملف
const cache = new Map();
function tenant(code) {
  if (typeof code !== 'string' || !CODE_RE.test(code)) return null;
  if (cache.has(code)) return cache.get(code);
  const inst = platform.prepare("SELECT id FROM institutions WHERE code=? AND status='active'").get(code);
  if (!inst) return null;
  const d = open(path.join(TENANTS, code + '.db'));
  cache.set(code, d);
  return d;
}

module.exports = { platform, tenant, CODE_RE };
