'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { platform, tenant, CODE_RE } = require('./db');
let DB = platform;            // قاعدة بيانات الطلب الحالي (قاعدة المؤسسة أو المنصة) — الطلبات تُنفَّذ بشكل متزامن فلا تتداخل
let SCOPE = '_platform';
const PLATFORM_CODE = (process.env.PLATFORM_CODE || 'platform').toLowerCase(); // «رمز المؤسسة» الخاص بالمشرف
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const ALLOW_APP = process.env.WASL_ALLOW_APP !== '0';   // السماح لتطبيق الهاتف (واجهة مضمّنة) بالاتصال: Bearer + CORS

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';          // محلي فقط افتراضيًا (أأمن)
const PUBLIC = path.join(__dirname, '..', 'public');
const SECURE_COOKIE = process.env.COOKIE_SECURE === '1'; // فعّله عند استعمال HTTPS

/* ───────────── ثوابت ───────────── */
const ROLE_AR = { director: 'مدير المؤسسة', vice: 'الناظر', teacher: 'أستاذ', student: 'تلميذ', parent: 'ولي',
  admin_staff: 'عامل إداري', professional_staff: 'عامل مهني', counselor: 'مستشار التوجيه', supervisor: 'مشرف المنصة' };
const REGISTERABLE = ['teacher', 'student', 'parent', 'admin_staff', 'professional_staff', 'counselor', 'vice'];
const NOT_MANAGEABLE = ['director', 'supervisor', 'vice']; // لا يعطّلهم ولا يعيد كلمة مرورهم المدير/الناظر
const AUDIENCES = { all: 'الجميع', teachers: 'الأساتذة', students: 'التلاميذ', parents: 'الأولياء', staff: 'الموظفون' };
const AUD_ROLES = { teachers: ['teacher'], students: ['student'], parents: ['parent'], staff: ['admin_staff', 'professional_staff', 'counselor'] };
const SUMMONS_AR = { pending_review: 'بانتظار مراجعة الإدارة', sent: 'تم الإرسال', received: 'تم الاستلام' };

/* ───────────── أدوات عامة ───────────── */
class HttpError extends Error { constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; } }
const bad = m => new HttpError(400, m);
const forbidden = () => new HttpError(403, 'غير مسموح لك بهذا الإجراء');
const notFound = () => new HttpError(404, 'غير موجود');

const nv = v => (v === undefined ? null : v);
const one = (sql, ...p) => DB.prepare(sql).get(...p.map(nv));
const all = (sql, ...p) => DB.prepare(sql).all(...p.map(nv));
const run = (sql, ...p) => { const r = DB.prepare(sql).run(...p.map(nv)); return { changes: r.changes, id: Number(r.lastInsertRowid) }; };
function tx(fn) { DB.exec('BEGIN'); try { const r = fn(); DB.exec('COMMIT'); return r; } catch (e) { DB.exec('ROLLBACK'); throw e; } }
const now = () => new Date().toISOString();
const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'Africa/Algiers' });
const inList = a => a.map(() => '?').join(',');

const str = (v, name, min = 1, max = 200) => {
  if (typeof v !== 'string') throw bad(`${name} مطلوب`);
  const s = v.trim().replace(/\s+/g, ' ');
  if (s.length < min || s.length > max) throw bad(`${name}: الطول المسموح بين ${min} و${max} حرفًا`);
  return s;
};
const text = (v, name, max = 2000) => { // نص طويل: نحافظ على الأسطر
  if (typeof v !== 'string' || !v.trim() || v.length > max) throw bad(`${name} مطلوب (حتى ${max} حرفًا)`);
  return v.trim();
};
const int = (v, name) => { const n = Number(v); if (!Number.isInteger(n) || n <= 0) throw bad(`${name} غير صالح`); return n; };
const oneOf = (v, list, name) => { if (!list.includes(v)) throw bad(`${name} غير صالح`); return v; };
const dateStr = (v, name) => { if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw bad(`${name} غير صالح`); return v; };

/* ───────────── كلمات المرور والجلسات ───────────── */
const hashPw = pw => { const salt = crypto.randomBytes(16); return salt.toString('hex') + ':' + crypto.scryptSync(pw, salt, 64).toString('hex'); };
const checkPw = (pw, stored) => {
  const [s, h] = stored.split(':'); const calc = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64); const hb = Buffer.from(h, 'hex');
  return hb.length === calc.length && crypto.timingSafeEqual(hb, calc);
};
const DUMMY_HASH = hashPw('dummy-password-for-timing'); // لتساوي زمن الرد سواء وُجد المستخدم أم لا
const sha = t => crypto.createHash('sha256').update(t).digest('hex');
const tempPassword = () => crypto.randomBytes(8).toString('base64url').slice(0, 10);
const validPassword = (p, name = 'كلمة المرور') => {
  if (typeof p !== 'string' || p.length < 8 || p.length > 100) throw bad(`${name} يجب ألا تقل عن 8 أحرف`);
  return p;
};
const SCOPE_RE = CODE_RE;
function useScope(scope) {
  if (scope === '_platform') { DB = platform; SCOPE = scope; return true; }
  const d = tenant(scope); if (!d) return false;
  DB = d; SCOPE = scope; return true;
}
const useInstitution = code => typeof code === 'string' && SCOPE_RE.test(code) && useScope(code);
function newSession(userId) {
  const t = crypto.randomBytes(32).toString('hex');
  run('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)', sha(t), userId, Date.now() + 7 * 864e5);
  return SCOPE + '.' + t;                     // نطاق المؤسسة + الرمز العشوائي (الرمز لا يصلح إلا في قاعدة مؤسسته)
}
const cookie = (v, maxAge, secure) => `sid=${v}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
const cookieParts = req => {
  const SC = '(_platform|[a-z0-9-]{3,30})\\.([a-f0-9]{64})';
  if (req.headers.authorization) {          // وضع التطبيق: لا نلتفت للكوكي إطلاقًا (يمنع التحايل على فحص Origin)
    const b = new RegExp('^Bearer ' + SC + '$').exec(req.headers.authorization);
    return b ? { scope: b[1], token: b[2], bearer: true } : null;
  }
  const m = new RegExp('(?:^|;\\s*)sid=' + SC).exec(req.headers.cookie || '');
  return m ? { scope: m[1], token: m[2] } : null;
};
function getUser(req) {
  const c = cookieParts(req); if (!c || !useScope(c.scope)) return null;
  const u = one('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?', sha(c.token), Date.now());
  return u && u.status === 'active' ? u : null;
}

/* تحديد المحاولات (ضد تخمين كلمات المرور) */
const buckets = new Map();
function limit(key, max, windowMs) {
  const n = Date.now(); let b = buckets.get(key);
  if (!b || b.until < n) b = { count: 0, until: n + windowMs };
  b.count++; buckets.set(key, b);
  if (b.count > max) throw new HttpError(429, 'محاولات كثيرة. حاول لاحقًا.');
}
setInterval(() => { const n = Date.now(); for (const [k, b] of buckets) if (b.until < n) buckets.delete(k); }, 60000).unref();

/* ───────────── سجل العمليات والإشعارات ───────────── */
const audit = (user, action) => run('INSERT INTO audit(user_id,action,created_at) VALUES(?,?,?)', user ? user.id : null, action, now());
function notify(ids, msg) { for (const id of new Set(ids)) run('INSERT INTO notifications(user_id,text,created_at) VALUES(?,?,?)', id, msg, now()); }
const parentsOf = studentId => all("SELECT id FROM users WHERE role='parent' AND child_id=? AND status='active'", studentId).map(r => r.id);
const teacherSections = id => all('SELECT section_id FROM teacher_sections WHERE teacher_id=?', id).map(r => r.section_id);

/* نطاق التلاميذ المسموح لكل دور (كجزء من WHERE) — alias الجدول: st */
function studentScope(user) {
  switch (user.role) {
    case 'director': case 'vice': case 'admin_staff': return { sql: '1=1', params: [] };
    case 'teacher': return { sql: 'st.section_id IN (SELECT section_id FROM teacher_sections WHERE teacher_id=?)', params: [user.id] };
    case 'student': return { sql: 'st.id=?', params: [user.id] };
    case 'parent': return { sql: 'st.id=?', params: [user.child_id || 0] };
    default: throw forbidden();
  }
}
function getStudent(id) {
  const s = one("SELECT * FROM users WHERE id=? AND role='student' AND status='active'", id);
  if (!s) throw bad('التلميذ غير موجود');
  return s;
}
function assertTeacherOwns(user, sectionId) {
  if (user.role === 'teacher' && !teacherSections(user.id).includes(sectionId)) throw new HttpError(403, 'هذا القسم ليس ضمن أقسامك');
}

/* ───────────── الموافقات ───────────── */
function createAnnouncement(title, body, audience, authorId) {
  const id = run('INSERT INTO announcements(title,body,audience,author_id,created_at) VALUES(?,?,?,?,?)', title, body, audience, authorId, now()).id;
  const rows = audience === 'all'
    ? all("SELECT id FROM users WHERE status='active' AND role!='supervisor'")
    : all(`SELECT id FROM users WHERE status='active' AND role IN (${inList(AUD_ROLES[audience])})`, ...AUD_ROLES[audience]);
  notify(rows.map(r => r.id), 'إعلان جديد: ' + title);
  return id;
}
function requestApproval(user, type, payload, description) {
  run('INSERT INTO approvals(type,payload,description,requested_by,created_at) VALUES(?,?,?,?,?)', type, JSON.stringify(payload), description, user.id, now());
  audit(user, 'طلب موافقة: ' + description);
  const dirs = all("SELECT id FROM users WHERE role='director' AND status='active'").map(r => r.id);
  notify(dirs, 'طلب موافقة جديد: ' + description);
  return { pending: true, message: 'أُرسل الطلب إلى المدير، وسيُنفَّذ بعد موافقته.' };
}
function executeApproval(type, p) {
  if (type === 'announcement') createAnnouncement(p.title, p.body, p.audience, p.author_id);
  else if (type === 'disable_user') { run("UPDATE users SET status='disabled' WHERE id=?", p.user_id); run('DELETE FROM sessions WHERE user_id=?', p.user_id); }
  else if (type === 'edit_absence') run('UPDATE attendance SET status=? WHERE id=?', p.status, p.id);
  else if (type === 'edit_grade') run('UPDATE grades SET mark=? WHERE id=?', p.mark, p.id);
}

/* مطابقة طلب التسجيل مع القائمة الرسمية */
const rosterMatch = u => one('SELECT id FROM roster WHERE claimed_by IS NULL AND role=? AND full_name=? AND IFNULL(section_id,0)=IFNULL(?,0) LIMIT 1',
  u.role, u.full_name, u.role === 'student' ? u.section_id : null);
const childMatch = u => all("SELECT id FROM users WHERE role='student' AND status='active' AND full_name=? AND section_id=?", u.child_name, u.section_id);
function isGreen(u) {
  if (u.role === 'parent') return childMatch(u).length === 1;
  if (u.role === 'vice') return false; // الناظر يتطلب مراجعة المدير دائمًا
  return !!rosterMatch(u);
}
function approveUser(u, actor) {
  if (u.role === 'parent') {
    const c = childMatch(u);
    if (c.length !== 1) throw bad('لم يُعثر على تلميذ مطابق (الاسم والقسم). وافق على حساب التلميذ أولًا.');
    run('UPDATE users SET child_id=? WHERE id=?', c[0].id, u.id);
  } else {
    const r = rosterMatch(u); if (r) run('UPDATE roster SET claimed_by=? WHERE id=?', u.id, r.id);
  }
  if (u.role === 'vice' && one("SELECT id FROM users WHERE role='vice' AND status='active'")) throw bad('يوجد ناظر مفعّل بالفعل');
  run("UPDATE users SET status='active' WHERE id=?", u.id);
  audit(actor, `قبول تسجيل: ${u.full_name} (${ROLE_AR[u.role]})`);
}

/* ───────────── الراوتر ───────────── */
const routes = [];
const route = (method, pattern, roles, fn) => routes.push({ method, roles, fn, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') });
const ANY = 'any', PUBLIC_ROUTE = null;
const NOT_SUP = ['director', 'vice', 'teacher', 'student', 'parent', 'admin_staff', 'professional_staff', 'counselor'];
const ADMINS = ['director', 'vice'];

/* — عامّة — */
route('GET', '/api/public/sections', PUBLIC_ROUTE, (c) => {
  if (!useInstitution((c.query.get('institution') || '').trim().toLowerCase())) throw bad('رمز المؤسسة غير صحيح');
  return all('SELECT id,level,branch,name FROM sections ORDER BY level,name');
});

route('POST', '/api/auth/login', PUBLIC_ROUTE, (c) => {
  const code = str(c.body.institution_code, 'رمز المؤسسة', 1, 40).toLowerCase();
  const ident = str(c.body.identifier, 'اسم المستخدم أو البريد', 1, 120).toLowerCase();
  const password = typeof c.body.password === 'string' ? c.body.password : '';
  limit(`login|${c.ip}|${code}|${ident}`, 5, 10 * 60000);
  limit(`loginip|${c.ip}`, 40, 10 * 60000);
  const scope = code === PLATFORM_CODE ? '_platform' : (SCOPE_RE.test(code) ? code : null);
  const u = scope && useScope(scope) ? one('SELECT * FROM users WHERE username=? OR email=?', ident, ident) : null;
  const right = u && ((scope === '_platform') === (u.role === 'supervisor')); // المشرف لا يدخل من مؤسسة، والعكس
  const pwOk = checkPw(password, right ? u.pass_hash : DUMMY_HASH);            // نفس الزمن في كل الحالات (ضد التخمين)
  if (!right || !pwOk) throw new HttpError(401, 'بيانات الدخول غير صحيحة');
  if (u.status === 'pending') throw new HttpError(403, 'حسابك بانتظار موافقة المدير');
  if (u.status !== 'active') throw new HttpError(403, 'هذا الحساب غير مفعّل. تواصل مع إدارة مؤسستك.');
  buckets.delete(`login|${c.ip}|${code}|${ident}`);
  const sess = newSession(u.id); audit(u, 'تسجيل دخول');
  const user = { id: u.id, name: u.full_name, role: u.role };
  if (c.body.client === 'app') return { user, token: sess };       // التطبيق: رمز Bearer بدل الكوكي
  c.headers['Set-Cookie'] = cookie(sess, 7 * 86400, c.secure);
  return { user };
});

route('POST', '/api/register', PUBLIC_ROUTE, (c) => {
  limit(`reg|${c.ip}`, 30, 3600000);
  const b = c.body;
  if (!useInstitution(typeof b.institution_code === 'string' ? b.institution_code.trim().toLowerCase() : '')) throw bad('رمز المؤسسة غير صحيح');
  const username = str(b.username, 'اسم المستخدم', 3, 30).toLowerCase();
  if (!/^[a-z0-9_.]+$/.test(username)) throw bad('اسم المستخدم: أحرف إنجليزية صغيرة وأرقام و _ . فقط');
  const email = b.email ? str(b.email, 'البريد الإلكتروني', 5, 120).toLowerCase() : null;
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw bad('البريد الإلكتروني غير صالح');
  const password = validPassword(b.password);
  const full_name = str(b.full_name, 'الاسم الكامل', 3, 80);
  const role = oneOf(b.role, REGISTERABLE, 'نوع الحساب');
  if (one('SELECT id FROM users WHERE username=? OR email=? OR username=?', username, email, email)) throw bad('اسم المستخدم أو البريد مستعمل');
  let section_id = null, subject = null, child_name = null, secIds = [];
  if (role === 'student' || role === 'parent') {
    section_id = int(b.section_id, 'القسم');
    if (!one('SELECT id FROM sections WHERE id=?', section_id)) throw bad('القسم غير موجود');
  }
  if (role === 'parent') child_name = str(b.child_name, 'اسم الابن', 3, 80);
  if (role === 'teacher') {
    subject = str(b.subject, 'المادة', 2, 60);
    secIds = (Array.isArray(b.section_ids) ? b.section_ids : []).map(x => int(x, 'القسم'));
    for (const s of secIds) if (!one('SELECT id FROM sections WHERE id=?', s)) throw bad('قسم غير موجود');
  }
  if (role === 'vice' && one("SELECT id FROM users WHERE role='vice' AND status IN ('active','pending')")) throw bad('يوجد ناظر مسجّل بالفعل');
  tx(() => {
    const id = run('INSERT INTO users(username,email,pass_hash,full_name,role,status,section_id,subject,child_name,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
      username, email, hashPw(password), full_name, role, 'pending', section_id, subject, child_name, now()).id;
    for (const s of new Set(secIds)) run('INSERT INTO teacher_sections VALUES(?,?)', id, s);
    notify(all("SELECT id FROM users WHERE role='director' AND status='active'").map(r => r.id), `طلب تسجيل جديد: ${full_name} (${ROLE_AR[role]})`);
  });
  return { ok: true, message: 'تم إرسال طلبك. سيراجعه المدير، وبعد الموافقة تستطيع الدخول.' };
});

/* — الحساب — */
route('POST', '/api/auth/logout', ANY, (c) => {
  const p = cookieParts(c.req); if (p) run('DELETE FROM sessions WHERE token_hash=?', sha(p.token));
  c.headers['Set-Cookie'] = cookie('', 0, c.secure); return { ok: true };
});
route('GET', '/api/auth/me', ANY, (c) => {
  const u = c.user; return { user: { id: u.id, name: u.full_name, role: u.role, username: u.username, email: u.email, must_change: !!u.must_change } };
});
route('POST', '/api/auth/password', ANY, (c) => {
  limit(`pw|${c.user.id}`, 10, 10 * 60000);
  if (!checkPw(String(c.body.current || ''), c.user.pass_hash)) throw bad('كلمة المرور الحالية غير صحيحة');
  const np = validPassword(c.body.new, 'كلمة المرور الجديدة');
  if (np === c.body.current) throw bad('اختر كلمة مرور مختلفة عن الحالية');
  run('UPDATE users SET pass_hash=?, must_change=0 WHERE id=?', hashPw(np), c.user.id);
  run('DELETE FROM sessions WHERE user_id=?', c.user.id);
  const sess = newSession(c.user.id); audit(c.user, 'تغيير كلمة المرور');
  if (c.bearer) return { ok: true, token: sess };
  c.headers['Set-Cookie'] = cookie(sess, 7 * 86400, c.secure); return { ok: true };
});

/* — الأقسام — */
route('GET', '/api/sections', ANY, () => all('SELECT id,level,branch,name FROM sections ORDER BY level,name'));
route('POST', '/api/sections', ['director'], (c) => {
  const level = str(c.body.level, 'المستوى', 1, 40), name = str(c.body.name, 'اسم القسم', 1, 40);
  const branch = c.body.branch ? str(c.body.branch, 'الشعبة', 1, 40) : null;
  if (one('SELECT id FROM sections WHERE name=?', name)) throw bad('اسم القسم موجود');
  run('INSERT INTO sections(level,branch,name) VALUES(?,?,?)', level, branch, name);
  audit(c.user, 'إضافة قسم: ' + name); return { ok: true };
});

/* — المستخدمون والموافقات — */
route('GET', '/api/users', ['director', 'vice', 'admin_staff', 'counselor'], (c) => {
  const status = oneOf(c.query.get('status') || 'active', ['active', 'pending', 'disabled', 'rejected'], 'الحالة');
  const roleFilter = c.user.role === 'counselor' ? 'student' : c.query.get('role');
  let sql = `SELECT u.id,u.username,u.full_name,u.role,u.status,u.subject,s.name AS section,
    (SELECT group_concat(ss.name,'، ') FROM teacher_sections ts JOIN sections ss ON ss.id=ts.section_id WHERE ts.teacher_id=u.id) AS teaching
    FROM users u LEFT JOIN sections s ON s.id=u.section_id WHERE u.status=? AND u.role!='supervisor'`;
  const p = [status];
  if (roleFilter) { sql += ' AND u.role=?'; p.push(roleFilter); }
  const rows = all(sql + ' ORDER BY u.role,u.full_name LIMIT 1000', ...p);
  return rows.map(r => ({ ...r, role_ar: ROLE_AR[r.role] }));
});
route('GET', '/api/students', ['director', 'vice', 'admin_staff', 'counselor', 'teacher'], (c) => {
  const f = c.user.role === 'counselor' ? { sql: '1=1', params: [] } : studentScope(c.user);
  return all(`SELECT st.id,st.full_name,sec.name AS section FROM users st LEFT JOIN sections sec ON sec.id=st.section_id
    WHERE st.role='student' AND st.status='active' AND ${f.sql} ORDER BY sec.name,st.full_name`, ...f.params);
});
route('GET', '/api/staff', ['director', 'vice', 'admin_staff'], () =>
  all("SELECT id,full_name,role FROM users WHERE role IN ('admin_staff','professional_staff') AND status='active' ORDER BY full_name"));

route('GET', '/api/approvals', ['director'], () => {
  const rows = [];
  for (const u of all("SELECT u.*,s.name AS section_name FROM users u LEFT JOIN sections s ON s.id=u.section_id WHERE u.status='pending' ORDER BY u.id")) {
    const green = isGreen(u);
    rows.push({ kind: 'user', id: u.id, title: `طلب تسجيل — ${u.full_name} (${ROLE_AR[u.role]})`,
      detail: u.role === 'parent' ? `ولي ${u.child_name} — ${u.section_name}` : (u.section_name || u.subject || ''),
      status: green ? 'مطابق للقائمة' : 'يحتاج مراجعة', level: green ? 'green' : 'yellow' });
  }
  for (const a of all("SELECT a.*,u.full_name AS who FROM approvals a JOIN users u ON u.id=a.requested_by WHERE a.status='pending' ORDER BY a.id"))
    rows.push({ kind: 'request', id: a.id, title: a.description, detail: `بطلب من ${a.who}`, status: 'قرار المدير مطلوب', level: 'sensitive' });
  return rows;
});
route('POST', '/api/users/approve-green', ['director'], (c) => {
  let n = 0;
  tx(() => { for (const u of all("SELECT * FROM users WHERE status='pending'")) if (isGreen(u)) { approveUser(u, c.user); n++; } });
  return { approved: n };
});
route('POST', '/api/users/:id/approve', ['director'], (c) => {
  const u = one("SELECT * FROM users WHERE id=? AND status='pending'", int(c.params.id, 'المعرّف')); if (!u) throw notFound();
  tx(() => approveUser(u, c.user)); return { ok: true };
});
route('POST', '/api/users/:id/reject', ['director'], (c) => {
  const u = one("SELECT * FROM users WHERE id=? AND status='pending'", int(c.params.id, 'المعرّف')); if (!u) throw notFound();
  run("UPDATE users SET status='rejected' WHERE id=?", u.id); audit(c.user, 'رفض تسجيل: ' + u.full_name); return { ok: true };
});
route('POST', '/api/approvals/:id/:action', ['director'], (c) => {
  const a = one("SELECT * FROM approvals WHERE id=? AND status='pending'", int(c.params.id, 'المعرّف')); if (!a) throw notFound();
  const action = oneOf(c.params.action, ['approve', 'reject'], 'الإجراء');
  tx(() => {
    if (action === 'approve') executeApproval(a.type, JSON.parse(a.payload));
    run('UPDATE approvals SET status=?,decided_by=? WHERE id=?', action === 'approve' ? 'approved' : 'rejected', c.user.id, a.id);
    audit(c.user, (action === 'approve' ? 'موافقة على: ' : 'رفض: ') + a.description);
    notify([a.requested_by], (action === 'approve' ? 'تمت الموافقة على طلبك: ' : 'رُفض طلبك: ') + a.description);
  });
  return { ok: true };
});
route('POST', '/api/users/:id/disable', ADMINS, (c) => {
  const u = one('SELECT * FROM users WHERE id=?', int(c.params.id, 'المعرّف'));
  if (!u || u.status !== 'active') throw notFound();
  if (NOT_MANAGEABLE.includes(u.role)) throw forbidden();
  if (c.user.role === 'vice') return requestApproval(c.user, 'disable_user', { user_id: u.id }, `تعطيل حساب ${u.full_name} (${ROLE_AR[u.role]})`);
  tx(() => { run("UPDATE users SET status='disabled' WHERE id=?", u.id); run('DELETE FROM sessions WHERE user_id=?', u.id); audit(c.user, 'تعطيل حساب: ' + u.full_name); });
  return { ok: true };
});
route('POST', '/api/users/:id/reset-password', ADMINS, (c) => {
  const u = one('SELECT * FROM users WHERE id=?', int(c.params.id, 'المعرّف'));
  if (!u) throw notFound(); if (NOT_MANAGEABLE.includes(u.role)) throw forbidden();
  const t = tempPassword();
  run('UPDATE users SET pass_hash=?,must_change=1 WHERE id=?', hashPw(t), u.id); run('DELETE FROM sessions WHERE user_id=?', u.id);
  audit(c.user, 'إعادة تعيين كلمة مرور: ' + u.full_name); return { temp_password: t };
});

route('POST', '/api/import', ['director'], (c) => {
  const csv = text(c.body.csv, 'الملف', 2000000).replace(/^\uFEFF/, '');
  const roleMap = { ...Object.fromEntries(Object.entries(ROLE_AR).map(([k, v]) => [v, k])), 'التلميذ': 'student', 'الأستاذ': 'teacher', 'الولي': 'parent', 'العامل الإداري': 'admin_staff', 'العامل المهني': 'professional_staff' };
  const lines = csv.split(/\r?\n/).filter(l => l.trim()); if (lines.length > 5001) throw bad('الحد الأقصى 5000 سطر');
  let added = 0; const errors = [];
  tx(() => lines.forEach((l, i) => {
    const [n, r, s] = l.split(/[,;\t]/).map(x => (x || '').trim());
    if (i === 0 && /name|الاسم/i.test(n)) return; // سطر العناوين
    const role = REGISTERABLE.includes(r) ? r : roleMap[r];
    const sec = s ? one('SELECT id FROM sections WHERE name=?', s) : null;
    if (!n || n.length > 80 || !role || role === 'parent' || (role === 'student' && !sec) || (s && !sec)) { errors.push(i + 1); return; }
    run('INSERT INTO roster(full_name,role,section_id) VALUES(?,?,?)', n.replace(/\s+/g, ' '), role, sec ? sec.id : null); added++;
  }));
  audit(c.user, `استيراد قائمة رسمية: ${added} سجل`); return { added, errors };
});

/* — الإعلانات — */
route('GET', '/api/announcements', NOT_SUP, (c) => {
  const r = c.user.role;
  const auds = ADMINS.includes(r) ? Object.keys(AUDIENCES) : ['all', r === 'teacher' ? 'teachers' : r === 'student' ? 'students' : r === 'parent' ? 'parents' : 'staff'];
  const lim = Math.min(Number(c.query.get('limit')) || 100, 200);
  return all(`SELECT a.id,a.title,a.body,a.audience,a.created_at,u.full_name AS author FROM announcements a LEFT JOIN users u ON u.id=a.author_id
    WHERE a.audience IN (${inList(auds)}) ORDER BY a.id DESC LIMIT ?`, ...auds, lim).map(a => ({ ...a, audience_ar: AUDIENCES[a.audience] }));
});
route('POST', '/api/announcements', ADMINS, (c) => {
  const title = str(c.body.title, 'العنوان', 2, 120), body = text(c.body.body, 'النص'), audience = oneOf(c.body.audience, Object.keys(AUDIENCES), 'الجمهور');
  if (c.user.role === 'vice') return requestApproval(c.user, 'announcement', { title, body, audience, author_id: c.user.id }, `نشر إعلان: ${title}`);
  tx(() => { createAnnouncement(title, body, audience, c.user.id); audit(c.user, 'نشر إعلان: ' + title); });
  return { ok: true };
});

/* — الغيابات — */
route('POST', '/api/attendance', ['director', 'vice', 'admin_staff'], (c) => {
  const st = getStudent(int(c.body.student_id, 'التلميذ')), date = dateStr(c.body.date, 'التاريخ'), status = oneOf(c.body.status, ['غياب', 'تأخر'], 'الحالة');
  tx(() => {
    run('INSERT INTO attendance(student_id,date,status,recorded_by,created_at) VALUES(?,?,?,?,?)', st.id, date, status, c.user.id, now());
    notify([st.id, ...parentsOf(st.id)], `سُجّل ${status} للتلميذ ${st.full_name} بتاريخ ${date}`);
    audit(c.user, `تسجيل ${status}: ${st.full_name}`);
  });
  return { ok: true };
});
route('GET', '/api/attendance', ['director', 'vice', 'admin_staff', 'teacher', 'student', 'parent'], (c) => {
  const f = studentScope(c.user);
  return all(`SELECT a.id,a.date,a.status,st.full_name AS student,sec.name AS section FROM attendance a JOIN users st ON st.id=a.student_id
    LEFT JOIN sections sec ON sec.id=st.section_id WHERE ${f.sql} ORDER BY a.date DESC,a.id DESC LIMIT 300`, ...f.params);
});
route('PATCH', '/api/attendance/:id', ['director', 'vice', 'admin_staff'], (c) => {
  const a = one('SELECT a.*,st.full_name FROM attendance a JOIN users st ON st.id=a.student_id WHERE a.id=?', int(c.params.id, 'المعرّف')); if (!a) throw notFound();
  const status = oneOf(c.body.status, ['غياب', 'تأخر', 'مبرَّر'], 'الحالة');
  if (c.user.role !== 'director') return requestApproval(c.user, 'edit_absence', { id: a.id, status }, `تعديل غياب ${a.full_name} (${a.date}) إلى «${status}»`);
  run('UPDATE attendance SET status=? WHERE id=?', status, a.id); audit(c.user, `تعديل غياب: ${a.full_name}`); return { ok: true };
});

/* — العلامات — */
const markOf = v => { const m = Number(v); if (v === '' || !Number.isFinite(m) || m < 0 || m > 20) throw bad('العلامة بين 0 و20'); return Math.round(m * 100) / 100; };
route('POST', '/api/grades', ['teacher', 'director', 'vice'], (c) => {
  const st = getStudent(int(c.body.student_id, 'التلميذ'));
  assertTeacherOwns(c.user, st.section_id);
  const subject = str(c.body.subject, 'المادة', 2, 60), kind = oneOf(c.body.kind, ['فرض', 'اختبار', 'تقويم مستمر'], 'نوع التقييم'), mark = markOf(c.body.mark);
  tx(() => {
    run('INSERT INTO grades(student_id,subject,kind,mark,teacher_id,created_at) VALUES(?,?,?,?,?,?)', st.id, subject, kind, mark, c.user.id, now());
    notify([st.id, ...parentsOf(st.id)], `علامة جديدة في ${subject} (${kind}) للتلميذ ${st.full_name}`);
    audit(c.user, `إضافة علامة: ${st.full_name} — ${subject}`);
  });
  return { ok: true };
});
route('GET', '/api/grades', ['director', 'vice', 'admin_staff', 'teacher', 'student', 'parent'], (c) => {
  const f = studentScope(c.user);
  const rows = all(`SELECT g.id,g.subject,g.kind,g.mark,st.full_name AS student FROM grades g JOIN users st ON st.id=g.student_id
    WHERE ${f.sql} ORDER BY g.id DESC LIMIT 500`, ...f.params);
  const average = ['student', 'parent'].includes(c.user.role) && rows.length ? Math.round(rows.reduce((s, r) => s + r.mark, 0) / rows.length * 100) / 100 : null;
  return { rows, average };
});
route('PATCH', '/api/grades/:id', ['teacher', 'director', 'vice'], (c) => {
  const g = one('SELECT g.*,st.full_name,st.section_id FROM grades g JOIN users st ON st.id=g.student_id WHERE g.id=?', int(c.params.id, 'المعرّف')); if (!g) throw notFound();
  assertTeacherOwns(c.user, g.section_id);
  const mark = markOf(c.body.mark);
  if (c.user.role !== 'director') return requestApproval(c.user, 'edit_grade', { id: g.id, mark }, `تعديل علامة ${g.full_name} في ${g.subject} من ${g.mark} إلى ${mark}`);
  run('UPDATE grades SET mark=? WHERE id=?', mark, g.id); audit(c.user, `تعديل علامة: ${g.full_name}`); return { ok: true };
});

/* — الدروس — */
route('POST', '/api/lessons', ['teacher', 'vice'], (c) => {
  const section_id = int(c.body.section_id, 'القسم'); if (!one('SELECT id FROM sections WHERE id=?', section_id)) throw bad('القسم غير موجود');
  assertTeacherOwns(c.user, section_id);
  const title = str(c.body.title, 'العنوان', 2, 120), subject = str(c.body.subject, 'المادة', 2, 60), kind = oneOf(c.body.kind, ['درس', 'تمرين', 'واجب'], 'النوع'), body = text(c.body.body, 'المحتوى', 5000);
  tx(() => {
    run('INSERT INTO lessons(title,subject,kind,body,section_id,author_id,created_at) VALUES(?,?,?,?,?,?,?)', title, subject, kind, body, section_id, c.user.id, now());
    const sts = all("SELECT id FROM users WHERE role='student' AND status='active' AND section_id=?", section_id).map(r => r.id);
    notify([...sts, ...sts.flatMap(parentsOf)], `${kind} جديد في ${subject}: ${title}`);
    audit(c.user, `نشر ${kind}: ${title}`);
  });
  return { ok: true };
});
route('GET', '/api/lessons', ['director', 'vice', 'teacher', 'student', 'parent'], (c) => {
  let where = '1=1'; const p = [];
  if (c.user.role === 'teacher') { where = 'l.section_id IN (SELECT section_id FROM teacher_sections WHERE teacher_id=?)'; p.push(c.user.id); }
  if (c.user.role === 'student') { where = 'l.section_id=?'; p.push(c.user.section_id || 0); }
  if (c.user.role === 'parent') { where = 'l.section_id=(SELECT section_id FROM users WHERE id=?)'; p.push(c.user.child_id || 0); }
  return all(`SELECT l.id,l.title,l.subject,l.kind,l.body,sec.name AS section FROM lessons l JOIN sections sec ON sec.id=l.section_id WHERE ${where} ORDER BY l.id DESC LIMIT 200`, ...p);
});

/* — الاستدعاءات — */
route('POST', '/api/summons', ['teacher', 'counselor', 'director', 'vice', 'admin_staff'], (c) => {
  const st = getStudent(int(c.body.student_id, 'التلميذ'));
  assertTeacherOwns(c.user, st.section_id);
  const reason = str(c.body.reason, 'السبب', 3, 300), date = c.body.date ? dateStr(c.body.date, 'الموعد') : null;
  const parent = parentsOf(st.id)[0]; if (!parent) throw bad('لا يوجد ولي مفعّل مرتبط بهذا التلميذ');
  const status = ['teacher', 'counselor'].includes(c.user.role) ? 'pending_review' : 'sent';
  tx(() => {
    run('INSERT INTO summons(parent_id,student_id,reason,date,status,created_by,created_at) VALUES(?,?,?,?,?,?,?)', parent, st.id, reason, date, status, c.user.id, now());
    if (status === 'sent') notify([parent], `استدعاء من الإدارة بخصوص ${st.full_name}: ${reason}`);
    audit(c.user, `إنشاء استدعاء: ${st.full_name}`);
  });
  return { ok: true, message: status === 'sent' ? 'تم إرسال الاستدعاء إلى الولي.' : 'أُحيل الطلب إلى الإدارة للمراجعة.' };
});
route('GET', '/api/summons', ['director', 'vice', 'admin_staff', 'teacher', 'counselor', 'parent'], (c) => {
  let where = '1=1'; const p = [];
  if (c.user.role === 'parent') { where = "s.parent_id=? AND s.status!='pending_review'"; p.push(c.user.id); }
  if (['teacher', 'counselor'].includes(c.user.role)) { where = 's.created_by=?'; p.push(c.user.id); }
  return all(`SELECT s.id,s.reason,s.date,s.status,st.full_name AS student,pu.full_name AS parent FROM summons s JOIN users st ON st.id=s.student_id
    JOIN users pu ON pu.id=s.parent_id WHERE ${where} ORDER BY s.id DESC LIMIT 200`, ...p).map(s => ({ ...s, status_ar: SUMMONS_AR[s.status] }));
});
route('POST', '/api/summons/:id/send', ['director', 'vice', 'admin_staff'], (c) => {
  const s = one("SELECT s.*,st.full_name AS sn FROM summons s JOIN users st ON st.id=s.student_id WHERE s.id=? AND s.status='pending_review'", int(c.params.id, 'المعرّف')); if (!s) throw notFound();
  tx(() => { run("UPDATE summons SET status='sent' WHERE id=?", s.id); notify([s.parent_id], `استدعاء من الإدارة بخصوص ${s.sn}: ${s.reason}`); audit(c.user, 'إرسال استدعاء: ' + s.sn); });
  return { ok: true };
});
route('POST', '/api/summons/:id/receive', ['parent'], (c) => {
  const s = one("SELECT * FROM summons WHERE id=? AND parent_id=? AND status='sent'", int(c.params.id, 'المعرّف'), c.user.id); if (!s) throw notFound();
  tx(() => { run("UPDATE summons SET status='received' WHERE id=?", s.id); notify([s.created_by], `أكّد الولي ${c.user.full_name} استلام الاستدعاء`); audit(c.user, 'تأكيد استلام استدعاء'); });
  return { ok: true };
});

/* — المهام — */
route('POST', '/api/tasks', ['director', 'vice', 'admin_staff'], (c) => {
  const title = str(c.body.title, 'عنوان المهمة', 2, 150);
  const a = one("SELECT * FROM users WHERE id=? AND role IN ('admin_staff','professional_staff') AND status='active'", int(c.body.assignee_id, 'المكلّف')); if (!a) throw bad('المكلّف غير صالح');
  tx(() => { run('INSERT INTO tasks(title,assignee_id,assigned_by,status,created_at) VALUES(?,?,?,?,?)', title, a.id, c.user.id, 'جديدة', now()); notify([a.id], 'مهمة جديدة: ' + title); audit(c.user, `إسناد مهمة: ${title} إلى ${a.full_name}`); });
  return { ok: true };
});
route('GET', '/api/tasks', ['director', 'vice', 'admin_staff', 'professional_staff'], (c) => {
  const own = c.user.role === 'professional_staff';
  return all(`SELECT t.id,t.title,t.status,u.full_name AS assignee,t.assignee_id FROM tasks t JOIN users u ON u.id=t.assignee_id
    ${own ? 'WHERE t.assignee_id=?' : ''} ORDER BY t.id DESC LIMIT 200`, ...(own ? [c.user.id] : []));
});
route('PATCH', '/api/tasks/:id', ['director', 'vice', 'admin_staff', 'professional_staff'], (c) => {
  const t = one('SELECT * FROM tasks WHERE id=?', int(c.params.id, 'المعرّف')); if (!t) throw notFound();
  if (c.user.role === 'professional_staff' && t.assignee_id !== c.user.id) throw forbidden();
  if (c.user.role === 'admin_staff' && t.assignee_id !== c.user.id) throw forbidden();
  const status = oneOf(c.body.status, ['جديدة', 'قيد التنفيذ', 'منجزة'], 'الحالة');
  run('UPDATE tasks SET status=? WHERE id=?', status, t.id); audit(c.user, `تحديث مهمة: ${t.title} → ${status}`); return { ok: true };
});

/* — فضاء المؤسسة / التبليغات — */
route('POST', '/api/reports', NOT_SUP, (c) => {
  const visibility = oneOf(c.body.visibility, ['public', 'private'], 'نوع البلاغ');
  const anonymous = c.body.anonymous === 'true' || c.body.anonymous === true ? 1 : 0;
  const title = str(c.body.title, 'الموضوع', 3, 150), body = text(c.body.body, 'التفاصيل', 3000);
  tx(() => {
    run('INSERT INTO reports(title,body,visibility,anonymous,sender_id,created_at) VALUES(?,?,?,?,?,?)', title, body, visibility, anonymous, c.user.id, now());
    notify(all("SELECT id FROM users WHERE role IN ('director','vice') AND status='active'").map(r => r.id), 'بلاغ جديد: ' + title);
    audit(anonymous ? null : c.user, anonymous ? 'بلاغ جديد (مجهول): ' + title : 'بلاغ جديد: ' + title);
  });
  return { ok: true };
});
route('GET', '/api/reports', NOT_SUP, (c) => {
  const admin = ADMINS.includes(c.user.role);
  const rows = all(`SELECT r.id,r.title,r.body,r.visibility,r.anonymous,r.status,r.sender_id,u.full_name AS sender FROM reports r JOIN users u ON u.id=r.sender_id
    ${admin ? '' : "WHERE r.visibility='public' OR r.sender_id=?"} ORDER BY r.id DESC LIMIT 200`, ...(admin ? [] : [c.user.id]));
  return rows.map(r => ({ id: r.id, title: r.title, body: r.body, status: r.status, anonymous: !!r.anonymous,
    visibility_ar: r.visibility === 'public' ? 'عام' : 'خاص بالإدارة', mine: r.sender_id === c.user.id,
    sender: r.anonymous ? 'مجهول' : (r.sender_id === c.user.id ? 'أنت' : r.sender) }));
});
route('PATCH', '/api/reports/:id', ADMINS, (c) => {
  const r = one('SELECT * FROM reports WHERE id=?', int(c.params.id, 'المعرّف')); if (!r) throw notFound();
  run('UPDATE reports SET status=? WHERE id=?', oneOf(c.body.status, ['جديد', 'قيد المعالجة', 'تم الحل'], 'الحالة'), r.id);
  audit(c.user, 'تحديث حالة بلاغ: ' + r.title); return { ok: true };
});
route('POST', '/api/reports/:id/reveal', ['director'], (c) => { // كشف هوية المجهول: للمدير فقط وتُسجَّل العملية
  const r = one('SELECT r.*,u.full_name AS sender FROM reports r JOIN users u ON u.id=r.sender_id WHERE r.id=?', int(c.params.id, 'المعرّف')); if (!r) throw notFound();
  audit(c.user, `كشف هوية مرسل البلاغ #${r.id}: ${r.title}`); return { sender: r.sender };
});

/* — الإشعارات — */
route('GET', '/api/notifications', NOT_SUP, (c) =>
  all('SELECT id,text,is_read,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100', c.user.id));
route('POST', '/api/notifications/read-all', NOT_SUP, (c) => { run('UPDATE notifications SET is_read=1 WHERE user_id=?', c.user.id); return { ok: true }; });

/* — أقسام الأستاذ، السجل، الإحصاءات — */
route('GET', '/api/classes', ['teacher'], (c) =>
  all(`SELECT s.id,s.name,(SELECT COUNT(*) FROM users st WHERE st.section_id=s.id AND st.role='student' AND st.status='active') AS students
    FROM teacher_sections ts JOIN sections s ON s.id=ts.section_id WHERE ts.teacher_id=? ORDER BY s.name`, c.user.id).map(r => ({ ...r, subject: c.user.subject })));
route('GET', '/api/audit', ['director', 'supervisor'], () =>
  all('SELECT a.action,a.created_at,u.full_name AS who FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200'));

const count = (sql, ...p) => one(sql, ...p).n;
route('GET', '/api/stats', NOT_SUP.concat('supervisor'), (c) => {
  const u = c.user, d = today();
  const cards = {
    director: () => [['طلبات الموافقة', count("SELECT (SELECT COUNT(*) FROM users WHERE status='pending')+(SELECT COUNT(*) FROM approvals WHERE status='pending') AS n")],
      ['الأعضاء', count("SELECT COUNT(*) AS n FROM users WHERE status='active' AND role NOT IN ('supervisor')")],
      ['الإعلانات', count('SELECT COUNT(*) AS n FROM announcements')], ['الأقسام', count('SELECT COUNT(*) AS n FROM sections')]],
    vice: () => [['غيابات اليوم', count('SELECT COUNT(*) AS n FROM attendance WHERE date=?', d)], ['استدعاءات مفتوحة', count("SELECT COUNT(*) AS n FROM summons WHERE status!='received'")],
      ['الأقسام', count('SELECT COUNT(*) AS n FROM sections')], ['مهام غير منجزة', count("SELECT COUNT(*) AS n FROM tasks WHERE status!='منجزة'")]],
    teacher: () => [['أقسامي', count('SELECT COUNT(*) AS n FROM teacher_sections WHERE teacher_id=?', u.id)],
      ['التلاميذ', count("SELECT COUNT(*) AS n FROM users WHERE role='student' AND status='active' AND section_id IN (SELECT section_id FROM teacher_sections WHERE teacher_id=?)", u.id)],
      ['دروسي', count('SELECT COUNT(*) AS n FROM lessons WHERE author_id=?', u.id)], ['علامات سجّلتها', count('SELECT COUNT(*) AS n FROM grades WHERE teacher_id=?', u.id)]],
    student: () => { const g = one('SELECT AVG(mark) AS a FROM grades WHERE student_id=?', u.id).a;
      return [['دروس القسم', count('SELECT COUNT(*) AS n FROM lessons WHERE section_id=?', u.section_id || 0)], ['المعدل', g == null ? '—' : (Math.round(g * 100) / 100)],
        ['الغيابات', count('SELECT COUNT(*) AS n FROM attendance WHERE student_id=?', u.id)], ['إشعارات جديدة', count('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND is_read=0', u.id)]]; },
    parent: () => { const g = one('SELECT AVG(mark) AS a FROM grades WHERE student_id=?', u.child_id || 0).a;
      return [['المعدل', g == null ? '—' : (Math.round(g * 100) / 100)], ['الغيابات', count('SELECT COUNT(*) AS n FROM attendance WHERE student_id=?', u.child_id || 0)],
        ['استدعاءات بانتظار الاستلام', count("SELECT COUNT(*) AS n FROM summons WHERE parent_id=? AND status='sent'", u.id)], ['إشعارات جديدة', count('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND is_read=0', u.id)]]; },
    admin_staff: () => [['استدعاءات للمراجعة', count("SELECT COUNT(*) AS n FROM summons WHERE status='pending_review'")], ['غيابات اليوم', count('SELECT COUNT(*) AS n FROM attendance WHERE date=?', d)],
      ['مهامي', count("SELECT COUNT(*) AS n FROM tasks WHERE assignee_id=? AND status!='منجزة'", u.id)], ['الأعضاء', count("SELECT COUNT(*) AS n FROM users WHERE status='active' AND role!='supervisor'")]],
    professional_staff: () => [['مهامي', count("SELECT COUNT(*) AS n FROM tasks WHERE assignee_id=? AND status!='منجزة'", u.id)], ['مهام جديدة', count("SELECT COUNT(*) AS n FROM tasks WHERE assignee_id=? AND status='جديدة'", u.id)],
      ['تبليغاتي', count('SELECT COUNT(*) AS n FROM reports WHERE sender_id=?', u.id)], ['إشعارات جديدة', count('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND is_read=0', u.id)]],
    counselor: () => [['التلاميذ', count("SELECT COUNT(*) AS n FROM users WHERE role='student' AND status='active'")], ['استدعاءاتي', count('SELECT COUNT(*) AS n FROM summons WHERE created_by=?', u.id)],
      ['بلاغات عامة', count("SELECT COUNT(*) AS n FROM reports WHERE visibility='public'")], ['إشعارات جديدة', count('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND is_read=0', u.id)]],
    supervisor: () => { const ds = allDirectors(); return [['المؤسسات', count('SELECT COUNT(*) AS n FROM institutions')], ['حسابات المديرين', ds.length],
      ['مديرون مفعّلون', ds.filter(x => x.status === 'active').length], ['عمليات اليوم', count('SELECT COUNT(*) AS n FROM audit WHERE created_at>=?', d)]]; },
  }[u.role];
  return cards();
});
route('GET', '/api/stats/report', ['director'], (c) => {
  const days = { week: 7, month: 30, term: 120 }[c.query.get('period')] || 7;
  const since = new Date(Date.now() - days * 864e5).toISOString();
  return [['سجلات الغياب', count('SELECT COUNT(*) AS n FROM attendance WHERE created_at>=?', since)], ['استدعاءات مفتوحة', count("SELECT COUNT(*) AS n FROM summons WHERE status!='received' AND created_at>=?", since)],
    ['البلاغات', count('SELECT COUNT(*) AS n FROM reports WHERE created_at>=?', since)], ['بلاغات تم حلها', count("SELECT COUNT(*) AS n FROM reports WHERE status='تم الحل' AND created_at>=?", since)]];
});

/* — المشرف: المؤسسات وحسابات المديرين (بلا أي اطلاع على بيانات التلاميذ) — */
function inTenant(code, fn) {  // تنفيذ عملية داخل قاعدة مؤسسة معيّنة ثم العودة لقاعدة المنصة
  const prevDB = DB, prevScope = SCOPE, d = tenant(code); if (!d) throw bad('المؤسسة غير موجودة أو موقوفة');
  DB = d; SCOPE = code; try { return fn(); } finally { DB = prevDB; SCOPE = prevScope; }
}
function allDirectors() {
  const out = [];
  for (const i of all('SELECT code,name FROM institutions')) inTenant(i.code, () => {
    for (const d of all("SELECT id,full_name,username,email,status FROM users WHERE role='director'")) out.push({ ...d, id: `${i.code}~${d.id}`, institution: i.name, code: i.code });
  });
  return out;
}
route('GET', '/api/institutions', ['supervisor'], () => all('SELECT id,code,name,region,status FROM institutions ORDER BY id DESC'));
route('POST', '/api/institutions', ['supervisor'], (c) => {
  const name = str(c.body.name, 'اسم المؤسسة', 2, 100), region = c.body.region ? str(c.body.region, 'المنطقة', 1, 60) : null;
  const code = str(c.body.code, 'رمز المؤسسة', 3, 30).toLowerCase();
  if (!SCOPE_RE.test(code) || code === PLATFORM_CODE) throw bad('رمز المؤسسة: أحرف إنجليزية صغيرة وأرقام و - فقط (3 إلى 30)');
  if (one('SELECT id FROM institutions WHERE name=? OR code=?', name, code)) throw bad('الاسم أو الرمز مستعمل');
  run('INSERT INTO institutions(code,name,region,created_at) VALUES(?,?,?,?)', code, name, region, now());
  tenant(code);                                   // إنشاء قاعدة بيانات المؤسسة المستقلة
  audit(c.user, `إنشاء مؤسسة: ${name} (${code})`); return { ok: true };
});
route('GET', '/api/directors', ['supervisor'], () => allDirectors());
route('POST', '/api/directors', ['supervisor'], (c) => {
  const full_name = str(c.body.full_name, 'اسم المدير', 3, 80), username = str(c.body.username, 'اسم المستخدم', 3, 30).toLowerCase();
  if (!/^[a-z0-9_.]+$/.test(username)) throw bad('اسم المستخدم: أحرف إنجليزية صغيرة وأرقام و _ . فقط');
  const email = c.body.email ? str(c.body.email, 'البريد', 5, 120).toLowerCase() : null;
  const inst = one('SELECT * FROM institutions WHERE id=?', int(c.body.institution_id, 'المؤسسة')); if (!inst) throw bad('المؤسسة غير موجودة');
  const t = tempPassword();
  inTenant(inst.code, () => {
    if (one("SELECT id FROM users WHERE role='director' AND status='active'")) throw bad('لهذه المؤسسة مدير مفعّل بالفعل');
    if (one('SELECT id FROM users WHERE username=? OR email=?', username, email)) throw bad('اسم المستخدم أو البريد مستعمل');
    run("INSERT INTO users(username,email,pass_hash,full_name,role,status,must_change,created_at) VALUES(?,?,?,?,'director','active',1,?)", username, email, hashPw(t), full_name, now());
  });
  audit(c.user, `إصدار حساب مدير: ${full_name} — ${inst.name}`);
  return { username, institution_code: inst.code, temp_password: t };
});
route('POST', '/api/directors/:id/reset-password', ['supervisor'], (c) => {
  const [code, uid] = String(c.params.id).split('~'); const t = tempPassword();
  const name = inTenant(code, () => {
    const u = one("SELECT * FROM users WHERE id=? AND role='director'", int(uid, 'المعرّف')); if (!u) throw notFound();
    run("UPDATE users SET pass_hash=?,must_change=1,status='active' WHERE id=?", hashPw(t), u.id); run('DELETE FROM sessions WHERE user_id=?', u.id); return u.full_name;
  });
  audit(c.user, `إعادة تعيين كلمة مرور المدير: ${name} (${code})`); return { temp_password: t };
});

/* ───────────── معالجة الطلبات ───────────── */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function secHeaders(res) {
  res.setHeader('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'same-origin'); res.setHeader('X-Frame-Options', 'DENY');
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', ch => { size += ch.length; if (size > 3e6) { reject(new HttpError(413, 'الطلب كبير جدًا')); req.destroy(); } else chunks.push(ch); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { const o = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(o && typeof o === 'object' && !Array.isArray(o) ? o : {}); }
      catch { reject(bad('صيغة الطلب غير صحيحة')); }
    });
    req.on('error', reject);
  });
}
function send(res, status, data, headers = {}) {
  if (data && data.error && !data.message) data = { ...data, message: data.error }; // الواجهة تقرأ message
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(data));
}
async function handleApi(req, res, url) {
  const r = routes.find(x => x.method === req.method && x.re.test(url.pathname));
  if (!r) throw notFound();
  const viaBearer = !!req.headers.authorization;
  if (req.method !== 'GET' && req.headers.origin && !viaBearer) { // حماية CSRF إضافية: يجب أن يطابق مصدر الطلب عنوان الخادم
    let h = ''; try { h = new URL(req.headers.origin).host; } catch { /* فارغ */ }
    if (h !== req.headers.host) throw new HttpError(403, 'مصدر الطلب غير مسموح');
  }
  const params = url.pathname.match(r.re).groups || {};
  let body = {};
  if (req.method !== 'GET') {
    if (!(req.headers['content-type'] || '').startsWith('application/json') && Number(req.headers['content-length'] || 0) > 0) throw new HttpError(415, 'يجب إرسال JSON');
    body = await readBody(req);
  }
  const user = getUser(req);
  if (r.roles !== PUBLIC_ROUTE) {
    if (!user) throw new HttpError(401, 'يجب تسجيل الدخول');
    if (user.must_change && !['/api/auth/me', '/api/auth/password', '/api/auth/logout'].includes(url.pathname)) throw new HttpError(403, 'يجب تغيير كلمة المرور المؤقتة أولًا', { must_change: true });
    if (r.roles !== ANY && !r.roles.includes(user.role)) throw forbidden();
  }
  const c = { req, user, body, params, query: url.searchParams, headers: {}, ip: (TRUST_PROXY && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || '',
    bearer: viaBearer, secure: SECURE_COOKIE || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https') };
  const out = r.fn(c);
  DB = platform; SCOPE = '_platform';
  send(res, 200, out === undefined ? { ok: true } : out, c.headers);
}
function serveStatic(req, res, url) {
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); return res.end(); }
  let p; try { p = decodeURIComponent(url.pathname); } catch { res.writeHead(400); return res.end(); }
  if (p.endsWith('/')) p += 'index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); } // منع الخروج من مجلد public
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('الصفحة غير موجودة'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}
const server = http.createServer(async (req, res) => {
  secHeaders(res);
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      if (ALLOW_APP) {
        res.setHeader('Access-Control-Allow-Origin', '*');          // بدون Allow-Credentials: الكوكي لا يُرسل من موقع آخر
        res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS'); res.setHeader('Access-Control-Max-Age', '600');
      }
      if (req.method === 'OPTIONS') { res.writeHead(ALLOW_APP ? 204 : 404); return res.end(); }
      await handleApi(req, res, url);
    } else serveStatic(req, res, url);
  } catch (e) {
    if (e instanceof HttpError) send(res, e.status, { error: e.message, ...(e.extra || {}) });
    else if (e && /UNIQUE/.test(String(e.message))) send(res, 400, { error: 'القيمة مستعملة بالفعل' });
    else { console.error(e); send(res, 500, { error: 'خطأ داخلي في الخادم' }); }
  }
});

if (require.main === module) server.listen(PORT, HOST, () => console.log(`همزة وصل تعمل على http://${HOST}:${PORT}`));
module.exports = { server, hashPw, platform };
