// إعدادات الاتصال. على الويب تبقى القيم كما هي (نفس الخادم). أداة tools/make-app.js تكتب هنا عنوان الخادم عند بناء ملف التطبيق.
window.WASL_API_BASE = "";
window.WASL_APP = false;
