/* Hamza Wasl — production-oriented frontend shell.
   Authentication and all data operations are provided by the backend API. */
const ROLE_NAMES={director:"مدير المؤسسة",vice:"الناظر / نائب المدير",teacher:"الأستاذ",student:"التلميذ",parent:"الولي",admin_staff:"العامل الإداري",professional_staff:"العامل المهني",counselor:"مستشار التوجيه",supervisor:"مشرف المنصة"};
const MENUS={
director:[["home","الرئيسية","⌂"],["approvals","الموافقات","✓"],["institution","المؤسسة والهيكل","▦"],["members","الأعضاء","♙"],["announcements","الإعلانات","▤"],["space","فضاء المؤسسة","◇"],["reports","التقارير","▥"],["audit","سجل العمليات","◷"],["settings","الإعدادات","⚙"]],
vice:[["home","الرئيسية","⌂"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["announcements","الإعلانات","▤"],["tasks","المهام","✓"],["lessons","الدروس","▣"],["settings","الإعدادات","⚙"]],
teacher:[["home","الرئيسية","⌂"],["classes","أقسامي","▦"],["lessons","الدروس والتمارين","▣"],["grades","العلامات","▥"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["settings","الإعدادات","⚙"]],
student:[["home","الرئيسية","⌂"],["lessons","الدروس","▣"],["grades","العلامات","▥"],["attendance","الغيابات","◷"],["announcements","الإعلانات","▤"],["notifications","الإشعارات","♧"],["settings","الإعدادات","⚙"]],
parent:[["home","الرئيسية","⌂"],["grades","العلامات","▥"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["announcements","الإعلانات","▤"],["notifications","الإشعارات","♧"],["settings","الإعدادات","⚙"]],
admin_staff:[["home","الرئيسية","⌂"],["attendance","الغيابات","◷"],["summons","الاستدعاءات","✉"],["tasks","المهام","✓"],["members","الأعضاء","♙"],["announcements","الإعلانات","▤"],["settings","الإعدادات","⚙"]],
professional_staff:[["home","الرئيسية","⌂"],["tasks","المهام","✓"],["notifications","التبليغات","✉"],["announcements","الإعلانات","▤"],["settings","الإعدادات","⚙"]],
counselor:[["home","الرئيسية","⌂"],["members","التلاميذ","♙"],["space","فضاء المؤسسة","◇"],["summons","الاستدعاءات","✉"],["announcements","الإعلانات","▤"],["settings","الإعدادات","⚙"]],
supervisor:[["home","الرئيسية","⌂"],["institutions","المؤسسات","▦"],["accounts","حسابات المديرين","♙"],["audit","سجل العمليات","◷"],["settings","الإعدادات","⚙"]]};
const TITLES={home:"الرئيسية",approvals:"الموافقات",institution:"المؤسسة والهيكل",members:"الأعضاء",announcements:"الإعلانات",space:"فضاء المؤسسة",reports:"التقارير",audit:"سجل العمليات",settings:"الإعدادات",attendance:"الغيابات",summons:"الاستدعاءات",tasks:"المهام",lessons:"الدروس والتمارين",grades:"العلامات والنتائج",notifications:"الإشعارات",classes:"أقسامي",institutions:"المؤسسات",accounts:"حسابات المديرين"};
const BASE=(window.WASL_API_BASE||"").replace(/\/+$/,""),APP_MODE=!!window.WASL_APP,API=BASE+"/api"; // وضع التطبيق: الواجهة داخل APK والخادم على عنوان آخر
const getToken=()=>{try{return localStorage.getItem("hwToken")}catch(_){return null}},setToken=t=>{try{t?localStorage.setItem("hwToken",t):localStorage.removeItem("hwToken")}catch(_){}};
const $=id=>document.getElementById(id);
async function api(path,options={}){const tk=APP_MODE?getToken():null;let response;try{response=await fetch(API+path,{...options,credentials:APP_MODE?"omit":"include",headers:{"Accept":"application/json",...(options.body?{"Content-Type":"application/json"}:{}),...(tk?{"Authorization":"Bearer "+tk}:{}),...(options.headers||{})}})}catch(_){const e=new Error("تعذر الاتصال بالخادم. تحقق من الإنترنت.");e.status=0;throw e}let data={};try{data=await response.json()}catch(_){}if(!response.ok){const e=new Error(data.message||"تعذر إتمام الطلب.");e.status=response.status;throw e}if(APP_MODE&&data.token)setToken(data.token);return data}
function notify(message){const el=$("toast");if(!el)return;el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2800)}
async function login(){const form=$("loginForm");if(!form)return;form.onsubmit=async e=>{e.preventDefault();const button=$("loginButton"),message=$("loginMessage");button.disabled=true;button.textContent="جارٍ التحقق...";message.textContent="";const payload={institution_code:$("institution").value.trim(),identifier:$("identity").value.trim(),password:$("password").value,...(APP_MODE?{client:"app"}:{})};try{const result=await api("/auth/login",{method:"POST",body:JSON.stringify(payload)});const role=result.user?.role||result.role;if(!MENUS[role])throw new Error("لم يتم إرجاع دور حساب صالح من الخادم.");location.href=`roles/${role}/dashboard.html`}catch(error){message.textContent=error.message||"تعذر تسجيل الدخول. تحقق من البيانات وحاول مجددًا."}finally{button.disabled=false;button.textContent="الدخول إلى المنصة ←"}}}

/* ───────── ملاءمات على قوائم المنتج ─────────
   أُضيفت صفحتا «فضاء المؤسسة» (ليرفع أي عضو بلاغًا) و«الإشعارات» للأدوار التي تنقصها. */
const names = ROLE_NAMES;
const AUD = [['all', 'الجميع'], ['teachers', 'الأساتذة'], ['students', 'التلاميذ'], ['parents', 'الأولياء'], ['staff', 'الموظفون']];

function addMenu(role, item) { const m = MENUS[role]; if (m && !m.some(x => x[0] === item[0])) m.splice(m.length - 1, 0, item); }
for (const r of ['vice', 'teacher', 'student', 'parent', 'admin_staff', 'professional_staff']) addMenu(r, ['space', r === 'professional_staff' ? 'بلاغ للإدارة' : 'فضاء المؤسسة', '◇']);
for (const r of ['director', 'vice', 'teacher', 'admin_staff', 'counselor']) addMenu(r, ['notifications', 'الإشعارات', '♧']);
const DESC={approvals:"مراجعة طلبات التسجيل والتغييرات واعتمادها وفق صلاحيات الإدارة.",institution:"إدارة بيانات المؤسسة والأطوار والمستويات والأقسام.",members:"إدارة حسابات أعضاء المؤسسة وربط كل حساب بصفته وبياناته.",announcements:"إنشاء الإعلانات وتحديد الفئات المستهدفة ومتابعة حالة النشر.",space:"متابعة البلاغات والطلبات المرسلة إلى الجهات المختصة.",reports:"تقارير المؤسسة وإحصاءاتها حسب الفترة والصلاحيات.",audit:"سجل موثق للعمليات التي تمت داخل المنصة.",settings:"إعدادات الحساب والتفضيلات الشخصية.",attendance:"تسجيل الغيابات والتأخرات ومتابعة سجلات الحضور.",summons:"إدارة الاستدعاءات ومواعيد التواصل مع الأولياء.",tasks:"عرض المهام المسندة ومتابعة حالتها.",lessons:"الوصول إلى الدروس والتمارين والموارد التعليمية.",grades:"الاطلاع على العلامات والنتائج أو إدارتها حسب الصلاحية.",notifications:"الإشعارات والتنبيهات الخاصة بحسابك.",classes:"الأقسام المسندة إليك والبيانات المرتبطة بها.",institutions:"إدارة المؤسسات المسجلة في المنصة.",accounts:"إدارة حسابات مديري المؤسسات."};
const LOGIN_URL = '../../index.html';
async function req(path, method = 'GET', body) {
  try { return await api(path, { method, body: body ? JSON.stringify(body) : undefined }); }
  catch (e) { if (e.status === 401) { setToken(null); location.replace(LOGIN_URL); } throw e; }
}
/* ───────── أدوات ───────── */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = d => new Date(d).toLocaleString('ar-DZ');
const today = () => new Date().toLocaleDateString('sv-SE');
const cell = x => (x && x.html !== undefined ? x.html : esc(x));
const btn = (label, attrs, cls = 'soft small') => ({ html: `<button class="btn ${cls}" ${attrs}>${esc(label)}</button>` });
const tag = (text, cls = '') => ({ html: `<span class="tag ${cls}">${esc(text)}</span>` });

const toast = m => notify(m);
function openModal(title, body) {
  const box = document.createElement('div'); box.className = 'modalbg show';
  box.innerHTML = `<div class="modal"><h3>${esc(title)}</h3>${body}<button class="btn line small" id="closeM">إغلاق</button></div>`;
  document.body.appendChild(box); box.querySelector('#closeM').onclick = () => box.remove(); box.onclick = e => { if (e.target === box) box.remove(); }; return box;
}
function pick(title, options) {
  return new Promise(res => {
    const box = document.createElement('div'); box.className = 'modalbg show';
    box.innerHTML = `<div class="modal"><h3>${esc(title)}</h3>${options.map((o, i) => `<button class="btn soft small" data-i="${i}" style="margin:4px">${esc(o)}</button>`).join('')}<br><button class="btn line small" data-i="-1" style="margin-top:10px">إلغاء</button></div>`;
    document.body.appendChild(box);
    box.onclick = e => { const b = e.target.closest('button'); if (b || e.target === box) { box.remove(); res(b && +b.dataset.i >= 0 ? options[+b.dataset.i] : null); } };
  });
}
const secret = (title, note, pw) => openModal(title, `<p>${esc(note)}</p><p style="text-align:center"><b dir="ltr" style="font-size:18px;user-select:all">${esc(pw)}</b></p><p>تُعرض مرة واحدة فقط، وسيُطلب تغييرها عند أول دخول.</p>`);

function table(head, rows) {
  if (!rows.length) return '<p class="empty">لا توجد بيانات بعد.</p>';
  return `<div class="tablewrap"><table class="data"><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(x => `<td>${cell(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
/* حقل: {n:اسم, l:عنوان, t:نوع, o:[[قيمة,نص]], v:افتراضي, r:false لجعله اختياريًا, full:true} */
function form(name, fields, button) {
  const input = f => {
    const req = f.r === false ? '' : 'required';
    if (f.t === 'textarea') return `<textarea class="field" name="${f.n}" rows="3" ${req}></textarea>`;
    if (f.t === 'select') return `<select class="field" name="${f.n}" ${req}><option value="">— اختر —</option>${f.o.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join('')}</select>`;
    const type = { date: 'date', number: 'number', password: 'password' }[f.t] || 'text';
    return `<input class="field" name="${f.n}" type="${type}" ${f.t === 'number' ? 'min="0" max="20" step=".25" inputmode="decimal"' : ''} ${f.v ? `value="${esc(f.v)}"` : ''} ${f.t === 'password' ? 'autocomplete="new-password"' : ''} ${req}>`;
  };
  return `<form class="panel formgrid" data-form="${name}">${fields.map(f => `<div class="${f.full ? 'full' : ''}"><label>${f.l}</label>${input(f)}</div>`).join('')}<div class="full"><button class="btn primary">${button}</button></div></form>`;
}
function bindForm(el, name, fn, again) {
  const f = el.querySelector(`form[data-form="${name}"]`); if (!f) return;
  f.onsubmit = async e => {
    e.preventDefault();
    const d = {}; new FormData(f).forEach((v, k) => { d[k] = v; });
    const b = f.querySelector('button'); b.disabled = true;
    try { const r = await fn(d); toast((r && r.message) || 'تم الحفظ'); f.reset(); await again(); } catch (err) { toast(err.message); }
    b.disabled = false;
  };
}
function bind(el, handlers, again) {
  el.querySelectorAll('[data-act]').forEach(b => b.onclick = async () => {
    try { const r = await handlers[b.dataset.act](b.dataset); if (r === false) return; if (r && r.message) toast(r.message); await again(); } catch (e) { toast(e.message); }
  });
}
function bindSearch(el) {
  const q = el.querySelector('.search'); if (!q) return;
  q.oninput = () => el.querySelectorAll('tbody tr').forEach(r => { r.style.display = r.textContent.includes(q.value.trim()) ? '' : 'none'; });
}
const options = (rows, label) => rows.map(r => [r.id, label(r)]);
const annHtml = a => `<article class="ann"><b>${esc(a.title)}</b><p style="white-space:pre-wrap">${esc(a.body)}</p><span class="tag">${esc(a.audience_ar)}</span> <small style="color:var(--muted);font-size:9px">${esc(a.author || '')} — ${fmt(a.created_at)}</small></article>`;

/* ───────── الحالة العامة ───────── */
let role = document.body.dataset.role, me = null;
const is = (...r) => r.includes(role);

/* ───────── الصفحات: كل صفحة تجلب بياناتها من الخادم ───────── */
const P = {};

P.approvals = async (el, again) => {
  const rows = await req('/approvals');
  const lv = { green: 'green', yellow: 'yellow', sensitive: 'red' };
  el.innerHTML = `<div class="toolbar"><input class="field search" placeholder="بحث في الطلبات"><button class="btn primary small" data-act="green">قبول الطلبات الخضراء</button></div>` +
    table(['الطلب', 'التفاصيل', 'الحالة', 'إجراء'], rows.map(r => [r.title, r.detail, tag(r.status, lv[r.level]),
      { html: `<button class="btn primary small" data-act="ok" data-kind="${r.kind}" data-id="${r.id}">قبول</button> <button class="btn line small" data-act="no" data-kind="${r.kind}" data-id="${r.id}">رفض</button>` }]));
  bind(el, {
    green: async () => { const r = await req('/users/approve-green', 'POST'); return { message: `تم قبول ${r.approved} طلب` }; },
    ok: d => req(d.kind === 'user' ? `/users/${d.id}/approve` : `/approvals/${d.id}/approve`, 'POST').then(() => ({ message: 'تمت الموافقة' })),
    no: d => req(d.kind === 'user' ? `/users/${d.id}/reject` : `/approvals/${d.id}/reject`, 'POST').then(() => ({ message: 'تم الرفض' })),
  }, again); bindSearch(el);
};

P.institution = async (el, again) => {
  const secs = await req('/sections');
  el.innerHTML = form('sec', [{ n: 'level', l: 'المستوى (مثال: 2 ثانوي)' }, { n: 'branch', l: 'الشعبة (اختياري)', r: false }, { n: 'name', l: 'اسم القسم (مثال: 2 ثانوي علوم 1)', full: true }], 'إضافة قسم') +
    `<div class="panel"><h3>الأقسام (${secs.length})</h3>${table(['القسم', 'المستوى', 'الشعبة'], secs.map(s => [s.name, s.level, s.branch || '—']))}</div>`;
  bindForm(el, 'sec', d => req('/sections', 'POST', d), again);
};

let memberStatus = 'active';
P.members = async (el, again) => {
  const rows = await req('/users?status=' + memberStatus);
  const manage = is('director', 'vice');
  el.innerHTML = `<div class="toolbar"><input class="field search" placeholder="بحث عن عضو"><select class="field" id="st"><option value="active">المفعّلون</option><option value="disabled">المعطّلون</option></select>` +
    (is('director') ? `<button class="btn primary small" id="csv">استيراد قائمة CSV</button><input type="file" id="csvf" accept=".csv,.txt" hidden>` : '') + `</div>` +
    (is('director') ? `<p class="intro">صيغة الملف: سطر لكل شخص — الاسم، الصفة، القسم (للتلميذ). مثال: <b dir="ltr">مريم بن صالح,student,2 ثانوي 1</b><br>الصفات: student, teacher, admin_staff, professional_staff, counselor, vice. القائمة تُستعمل لمطابقة طلبات التسجيل تلقائيًا.</p>` : '') +
    table(['الاسم', 'الصفة', 'التفاصيل', 'اسم المستخدم', ...(manage ? ['إجراء'] : [])], rows.map(r => [r.full_name, r.role_ar, r.section || r.teaching || r.subject || '—', r.username,
      ...(manage ? [['director', 'vice', 'supervisor'].includes(r.role) || r.status !== 'active' ? '' : { html: `<button class="btn soft small" data-act="reset" data-id="${r.id}">كلمة مرور</button> <button class="btn line small" data-act="off" data-id="${r.id}">تعطيل</button>` }] : [])]));
  const st = el.querySelector('#st'); st.value = memberStatus; st.onchange = e => { memberStatus = e.target.value; again(); };
  if (is('director')) {
    el.querySelector('#csv').onclick = () => el.querySelector('#csvf').click();
    el.querySelector('#csvf').onchange = async e => {
      const file = e.target.files[0]; if (!file) return;
      try { const r = await req('/import', 'POST', { csv: await file.text() }); toast(`أُضيف ${r.added} سجل${r.errors.length ? ` — أسطر مرفوضة: ${r.errors.slice(0, 10).join('، ')}` : ''}`); } catch (err) { toast(err.message); }
      e.target.value = '';
    };
  }
  bind(el, {
    reset: async d => { if (!confirm('إعادة تعيين كلمة مرور هذا العضو؟')) return false; const r = await req(`/users/${d.id}/reset-password`, 'POST'); secret('كلمة مرور مؤقتة', 'سلّمها للعضو بشكل مباشر:', r.temp_password); return false; },
    off: async d => { if (!confirm('تعطيل هذا الحساب؟')) return false; const r = await req(`/users/${d.id}/disable`, 'POST'); return { message: r.message || 'تم التعطيل' }; },
  }, again); bindSearch(el);
};

P.announcements = async (el, again) => {
  const list = await req('/announcements');
  el.innerHTML = (is('director', 'vice') ? form('ann', [{ n: 'title', l: 'عنوان الإعلان' }, { n: 'audience', l: 'الجمهور', t: 'select', o: AUD }, { n: 'body', l: 'نص الإعلان', t: 'textarea', full: true }], 'نشر الإعلان') : '') +
    `<div class="panel"><h3>الإعلانات</h3>${list.length ? list.map(annHtml).join('') : '<p class="empty">لا توجد إعلانات.</p>'}</div>`;
  bindForm(el, 'ann', d => req('/announcements', 'POST', d), again);
};

P.attendance = async (el, again) => {
  const canWrite = is('director', 'vice', 'admin_staff');
  const [rows, sts] = await Promise.all([req('/attendance'), canWrite ? req('/students') : []]);
  el.innerHTML = (canWrite ? form('att', [{ n: 'student_id', l: 'التلميذ', t: 'select', o: options(sts, s => `${s.full_name} — ${s.section || ''}`), full: true }, { n: 'date', l: 'التاريخ', t: 'date', v: today() }, { n: 'status', l: 'الحالة', t: 'select', o: [['غياب', 'غياب'], ['تأخر', 'تأخر']] }], 'تسجيل الغياب / التأخر') : '') +
    `<div class="panel"><h3>سجل الغيابات</h3>${table(['التلميذ', 'القسم', 'التاريخ', 'الحالة', ...(canWrite ? ['إجراء'] : [])], rows.map(r => [r.student, r.section || '—', r.date, tag(r.status, r.status === 'مبرَّر' ? 'green' : 'yellow'), ...(canWrite ? [btn('تعديل', `data-act="edit" data-id="${r.id}"`)] : [])]))}</div>`;
  bindForm(el, 'att', d => req('/attendance', 'POST', d), again);
  bind(el, { edit: async d => { const s = await pick('الحالة الجديدة', ['غياب', 'تأخر', 'مبرَّر']); if (!s) return false; const r = await req(`/attendance/${d.id}`, 'PATCH', { status: s }); return { message: r.message || 'تم التعديل' }; } }, again);
};

P.lessons = async (el, again) => {
  const canWrite = is('teacher', 'vice');
  const [rows, secs] = await Promise.all([req('/lessons'), canWrite ? req(is('teacher') ? '/classes' : '/sections') : []]);
  el.innerHTML = (canWrite ? form('les', [{ n: 'title', l: 'عنوان الدرس / التمرين' }, { n: 'subject', l: 'المادة' }, { n: 'section_id', l: 'القسم', t: 'select', o: options(secs, s => s.name) }, { n: 'kind', l: 'النوع', t: 'select', o: [['درس', 'درس'], ['تمرين', 'تمرين'], ['واجب', 'واجب']] }, { n: 'body', l: 'النص أو الرابط', t: 'textarea', full: true }], 'نشر المورد') : '') +
    `<div class="panel"><h3>الموارد المنشورة</h3>${rows.length ? rows.map(r => `<article class="ann"><b>${esc(r.title)}</b><p style="white-space:pre-wrap">${esc(r.body)}</p><span class="tag">${esc(r.kind)}</span> <span class="tag green">${esc(r.subject)}</span> <span class="tag">${esc(r.section)}</span></article>`).join('') : '<p class="empty">لا توجد موارد بعد.</p>'}</div>`;
  bindForm(el, 'les', d => req('/lessons', 'POST', d), again);
};

P.grades = async (el, again) => {
  const canWrite = is('teacher', 'director', 'vice');
  const [g, sts] = await Promise.all([req('/grades'), canWrite ? req('/students') : []]);
  el.innerHTML = (canWrite ? form('gr', [{ n: 'student_id', l: 'التلميذ', t: 'select', o: options(sts, s => `${s.full_name} — ${s.section || ''}`), full: true }, { n: 'subject', l: 'المادة' }, { n: 'kind', l: 'نوع التقييم', t: 'select', o: [['فرض', 'فرض'], ['اختبار', 'اختبار'], ['تقويم مستمر', 'تقويم مستمر']] }, { n: 'mark', l: 'العلامة / 20', t: 'number' }], 'إضافة علامة') : '') +
    `<div class="panel"><h3>العلامات${g.average != null ? ` — المعدل: ${g.average}` : ''}</h3>${table(['التلميذ', 'المادة', 'التقييم', 'العلامة', ...(canWrite ? ['إجراء'] : [])], g.rows.map(r => [r.student, r.subject, r.kind, String(r.mark), ...(canWrite ? [btn('تعديل', `data-act="edit" data-id="${r.id}"`)] : [])]))}</div>`;
  bindForm(el, 'gr', d => req('/grades', 'POST', d), again);
  bind(el, { edit: async d => { const m = prompt('العلامة الجديدة من 20:'); if (m === null) return false; const r = await req(`/grades/${d.id}`, 'PATCH', { mark: m }); return { message: r.message || 'تم التعديل' }; } }, again);
};

P.summons = async (el, again) => {
  const canWrite = is('teacher', 'counselor', 'director', 'vice', 'admin_staff'), reviewer = is('director', 'vice', 'admin_staff');
  const [rows, sts] = await Promise.all([req('/summons'), canWrite ? req('/students') : []]);
  el.innerHTML = (canWrite ? form('sm', [{ n: 'student_id', l: 'التلميذ (يُستدعى وليه)', t: 'select', o: options(sts, s => `${s.full_name} — ${s.section || ''}`), full: true }, { n: 'reason', l: 'سبب الاستدعاء' }, { n: 'date', l: 'موعد مقترح (اختياري)', t: 'date', r: false }], 'إنشاء طلب استدعاء') : '') +
    `<div class="panel"><h3>الاستدعاءات</h3>${table(['الولي', 'التلميذ', 'السبب', 'الحالة', 'إجراء'], rows.map(r => [r.parent, r.student, r.reason, tag(r.status_ar, r.status === 'received' ? 'green' : 'yellow'),
      reviewer && r.status === 'pending_review' ? btn('إرسال للولي', `data-act="send" data-id="${r.id}"`) : is('parent') && r.status === 'sent' ? btn('تم الاستلام', `data-act="recv" data-id="${r.id}"`, 'primary small') : '']))}</div>`;
  bindForm(el, 'sm', d => req('/summons', 'POST', d), again);
  bind(el, { send: d => req(`/summons/${d.id}/send`, 'POST').then(() => ({ message: 'أُرسل الاستدعاء' })), recv: d => req(`/summons/${d.id}/receive`, 'POST').then(() => ({ message: 'تم تأكيد الاستلام' })) }, again);
};

P.tasks = async (el, again) => {
  const canAssign = is('director', 'vice', 'admin_staff');
  const [rows, staff] = await Promise.all([req('/tasks'), canAssign ? req('/staff') : []]);
  el.innerHTML = (canAssign ? form('tk', [{ n: 'title', l: 'عنوان المهمة' }, { n: 'assignee_id', l: 'المكلّف', t: 'select', o: options(staff, s => `${s.full_name} (${names[s.role]})`) }], 'إسناد المهمة') : '') +
    `<div class="panel"><h3>المهام</h3>${table(['المهمة', 'المكلّف', 'الحالة', 'إجراء'], rows.map(r => [r.title, r.assignee, tag(r.status, r.status === 'منجزة' ? 'green' : r.status === 'قيد التنفيذ' ? 'yellow' : ''),
      r.status !== 'منجزة' && (is('director', 'vice') || r.assignee_id === me.id) ? { html: `<button class="btn soft small" data-act="st" data-s="قيد التنفيذ" data-id="${r.id}">قيد التنفيذ</button> <button class="btn primary small" data-act="st" data-s="منجزة" data-id="${r.id}">تم الإنجاز</button>` } : '']))}</div>`;
  bindForm(el, 'tk', d => req('/tasks', 'POST', d), again);
  bind(el, { st: d => req(`/tasks/${d.id}`, 'PATCH', { status: d.s }).then(() => ({ message: 'تم التحديث' })) }, again);
};

P.space = async (el, again) => {
  const rows = await req('/reports'), admin = is('director', 'vice');
  el.innerHTML = `<div class="intro">ارفع مشكلة أو بلاغًا للإدارة. اختر إن كان عامًّا يراه الجميع أو خاصًّا بالإدارة فقط، وإن كان باسمك أو مجهولًا.</div>` +
    form('rp', [{ n: 'visibility', l: 'نوع البلاغ', t: 'select', o: [['private', 'خاص بالإدارة'], ['public', 'عام']] }, { n: 'anonymous', l: 'الهوية', t: 'select', o: [['false', 'باسمي'], ['true', 'مجهول']] }, { n: 'title', l: 'موضوع البلاغ', full: true }, { n: 'body', l: 'التفاصيل', t: 'textarea', full: true }], 'إرسال البلاغ') +
    `<div class="panel"><h3>البلاغات</h3>${rows.length ? rows.map(r => `<article class="ann"><b>${esc(r.title)}</b><p style="white-space:pre-wrap">${esc(r.body)}</p><span class="tag">${esc(r.visibility_ar)}</span> <span class="tag ${r.status === 'تم الحل' ? 'green' : 'yellow'}">${esc(r.status)}</span> <span class="tag">${esc(r.sender)}</span>${
      admin ? ` <button class="btn soft small" data-act="status" data-id="${r.id}">تغيير الحالة</button>` : ''}${is('director') && r.anonymous && !r.mine ? ` <button class="btn line small" data-act="reveal" data-id="${r.id}">كشف المرسل</button>` : ''}</article>`).join('') : '<p class="empty">لا توجد بلاغات.</p>'}</div>`;
  bindForm(el, 'rp', d => req('/reports', 'POST', d), again);
  bind(el, {
    status: async d => { const s = await pick('حالة البلاغ', ['جديد', 'قيد المعالجة', 'تم الحل']); if (!s) return false; await req(`/reports/${d.id}`, 'PATCH', { status: s }); return { message: 'تم التحديث' }; },
    reveal: async d => { if (!confirm('كشف هوية المرسل يُسجَّل في سجل العمليات. المتابعة؟')) return false; const r = await req(`/reports/${d.id}/reveal`, 'POST'); openModal('مرسل البلاغ', `<p><b>${esc(r.sender)}</b></p>`); return false; },
  }, again);
};

P.notifications = async (el) => {
  const rows = await req('/notifications');
  el.innerHTML = `<div class="panel">${rows.length ? rows.map(n => `<article class="ann"><b${n.is_read ? '' : ' style="color:var(--blue)"'}>${esc(n.text)}</b><p>${fmt(n.created_at)}</p></article>`).join('') : '<p class="empty">لا توجد إشعارات.</p>'}</div>`;
  req('/notifications/read-all', 'POST').catch(() => { });
};

P.reports = async (el, again) => {
  const period = P.reports.period || 'week';
  const cards = await req('/stats/report?period=' + period);
  el.innerHTML = `<div class="toolbar"><select class="field" id="per"><option value="week">آخر 7 أيام</option><option value="month">آخر 30 يومًا</option><option value="term">آخر 4 أشهر</option></select></div><div class="stats">${cards.map(c => `<div class="stat"><label>${esc(c[0])}</label><strong>${esc(c[1])}</strong></div>`).join('')}</div>`;
  const s = el.querySelector('#per'); s.value = period; s.onchange = () => { P.reports.period = s.value; again(); };
};

P.audit = async (el) => {
  const rows = await req('/audit');
  el.innerHTML = `<div class="panel"><h3>آخر العمليات</h3>${table(['العملية', 'المستخدم', 'التاريخ'], rows.map(r => [r.action, r.who || 'مجهول / النظام', fmt(r.created_at)]))}</div>`;
};

P.classes = async (el) => {
  const rows = await req('/classes');
  el.innerHTML = table(['القسم', 'المادة', 'عدد التلاميذ'], rows.map(r => [r.name, r.subject || '—', String(r.students)]));
};

P.institutions = async (el, again) => {
  const rows = await req('/institutions');
  el.innerHTML = form('in', [{ n: 'name', l: 'اسم المؤسسة' }, { n: 'code', l: 'رمز المؤسسة (إنجليزي صغير، مثال: amal-2026)' }, { n: 'region', l: 'المنطقة (اختياري)', r: false }], 'إنشاء مؤسسة') +
    `<div class="panel">${table(['المؤسسة', 'الرمز', 'المنطقة'], rows.map(r => [r.name, r.code, r.region || '—']))}</div>`;
  bindForm(el, 'in', d => req('/institutions', 'POST', d), again);
};

P.accounts = async (el, again) => {
  const [dirs, insts] = await Promise.all([req('/directors'), req('/institutions')]);
  el.innerHTML = form('dr', [{ n: 'full_name', l: 'اسم المدير' }, { n: 'username', l: 'اسم المستخدم (إنجليزي)' }, { n: 'email', l: 'البريد الإلكتروني (اختياري)', r: false }, { n: 'institution_id', l: 'المؤسسة', t: 'select', o: options(insts, i => i.name), full: true }], 'إصدار حساب مدير') +
    `<div class="panel">${table(['المدير', 'اسم المستخدم', 'المؤسسة', 'الحالة', 'إجراء'], dirs.map(d => [d.full_name, d.username, `${d.institution} (${d.code})`, d.status, btn('كلمة مرور جديدة', `data-act="rp" data-id="${d.id}"`)]))}</div>`;
  bindForm(el, 'dr', async d => { const r = await req('/directors', 'POST', d); secret('تم إصدار الحساب', `رمز المؤسسة: ${r.institution_code} — اسم المستخدم: ${r.username} — كلمة المرور المؤقتة:`, r.temp_password); return { message: 'تم إصدار الحساب' }; }, again);
  bind(el, { rp: async d => { if (!confirm('إصدار كلمة مرور جديدة لهذا المدير؟')) return false; const r = await req(`/directors/${d.id}/reset-password`, 'POST'); secret('كلمة مرور مؤقتة', 'سلّمها للمدير مباشرة:', r.temp_password); return false; } }, again);
};

P.settings = async (el) => {
  el.innerHTML = `<div class="panel"><h3>المظهر</h3><button class="btn soft" id="light">نهاري</button> <button class="btn primary" id="dark">ليلي</button> <button class="btn line" id="auto">تلقائي</button></div>
  <div class="panel"><h3>الحساب</h3><p style="font-size:11px;color:var(--muted)">${esc(me.full_name)} — ${esc(names[role])} — <span dir="ltr">${esc(me.username)}</span></p></div>` +
    form('pw', [{ n: 'current', l: 'كلمة المرور الحالية', t: 'password' }, { n: 'new', l: 'كلمة المرور الجديدة (8 أحرف على الأقل)', t: 'password' }, { n: 'again', l: 'أعد كتابة الجديدة', t: 'password' }], 'تغيير كلمة المرور');
  $('light').onclick = () => setTheme('light'); $('dark').onclick = () => setTheme('dark'); $('auto').onclick = () => setTheme(matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light');
  bindForm(el, 'pw', async d => { if (d.new !== d.again) throw new Error('كلمتا المرور غير متطابقتين'); await req('/auth/password', 'POST', { current: d.current, new: d.new }); me.must_change = false; return { message: 'تم تغيير كلمة المرور' }; }, () => { });
};

function setTheme(theme){document.body.classList.toggle("dark",theme==="dark");localStorage.setItem("hwTheme",theme)}

/* ───────── هيكل لوحة التحكم ───────── */
const pageIds = r => (MENUS[r] || []).map(x => x[0]).filter(x => x !== 'home');
function renderMenu(r) {
  const m = MENUS[r] || [];
  $('menu').innerHTML = m.map((x, i) => `<button class="navbtn ${i === 0 ? 'active' : ''}" data-go="${x[0]}"><span>${x[2]}</span>${esc(x[1])}</button>`).join('');
  const mobile = [...m.slice(0, 4), ...(m.length > 5 ? [['more', 'المزيد', '•••']] : m.slice(4, 5))];
  $('mobile').innerHTML = mobile.map((x, i) => `<button class="${i === 0 ? 'active' : ''}" data-mob="${x[0]}"><span>${x[2]}</span>${esc(x[1])}</button>`).join('');
  document.querySelectorAll('[data-go]').forEach(x => x.onclick = () => showPage(x.dataset.go));
  document.querySelectorAll('[data-mob]').forEach(x => x.onclick = () => {
    if (x.dataset.mob !== 'more') return showPage(x.dataset.mob);
    const box = openModal('المزيد', m.slice(4).map(v => `<button class="btn soft small" data-extra="${v[0]}" style="margin:4px">${esc(v[1])}</button>`).join(''));
    box.querySelectorAll('[data-extra]').forEach(z => z.onclick = () => { box.remove(); showPage(z.dataset.extra); });
  });
}
function buildPages(r) {
  $('pages').innerHTML = pageIds(r).map(id => `<section class="page" id="page-${id}"><div class="heading"><div><h1>${esc(TITLES[id] || '')}</h1><p>${esc(DESC[id] || '')}</p></div><span class="badge">${esc(ROLE_NAMES[r])}</span></div><div id="body-${id}"></div></section>`).join('');
}
async function render(id) {
  const el = $('body-' + id); if (!el || !P[id]) return;
  try { await P[id](el, () => render(id)); } catch (e) { el.innerHTML = `<div class="panel">${esc(e.message)}</div>`; }
}
function showPage(id) {
  const p = id === 'home' ? $('home') : $('page-' + id); if (!p) return;
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active')); p.classList.add('active');
  document.querySelectorAll('[data-go]').forEach(x => x.classList.toggle('active', x.dataset.go === id));
  document.querySelectorAll('[data-mob]').forEach(x => x.classList.toggle('active', x.dataset.mob === id));
  $('crumb').textContent = TITLES[id] || 'الرئيسية'; window.scrollTo({ top: 0, behavior: 'smooth' });
  if (id === 'home') buildHome(); else render(id);
}
async function buildHome() {
  try { const cards = await req('/stats'); $('stats').innerHTML = cards.map(s => `<article class="stat"><label>${esc(s[0])}</label><strong>${esc(s[1])}</strong></article>`).join(''); } catch (e) { $('stats').innerHTML = ''; }
  $('quick').innerHTML = pageIds(role).slice(0, 4).map(id => { const x = MENUS[role].find(m => m[0] === id); return `<button data-quick="${id}"><span>${x[2]}</span>${esc(x[1])}</button>`; }).join('');
  document.querySelectorAll('[data-quick]').forEach(x => x.onclick = () => showPage(x.dataset.quick));
  if (role === 'supervisor') { $('latest').textContent = 'لا إعلانات في هذا الدور.'; return; }
  try { const a = await req('/announcements?limit=3'); $('latest').innerHTML = a.length ? a.map(annHtml).join('') : 'لا توجد إعلانات جديدة.'; } catch (e) { /* تجاهل */ }
}
async function loadDashboard() {
  try {
    const m = await api('/auth/me'); const u = m.user; me = u; role = u && u.role;
    if (!role || !MENUS[role]) throw new Error('بيانات الحساب غير مكتملة.');
    if (role !== document.body.dataset.role) { location.replace(`../${role}/dashboard.html`); return; } // راحة فقط؛ الحماية الحقيقية في الخادم
    document.querySelectorAll('[data-user]').forEach(e => { e.textContent = u.name; });
    document.querySelectorAll('[data-role-label]').forEach(e => { e.textContent = ROLE_NAMES[role]; });
    renderMenu(role); buildPages(role);
    if (u.must_change) { showPage('settings'); notify('يجب تغيير كلمة المرور المؤقتة أولًا.'); } else buildHome();
  } catch (error) {
    if (error.status === 401 || error.status === 403) { location.replace(LOGIN_URL); return; }
    document.querySelector('.content').innerHTML = '<section class="panel connection-state"><h2>تعذر الاتصال بالمنصة</h2><p>لم نتمكن من التحقق من جلسة الدخول. تحقق من اتصال الخادم ثم أعد المحاولة.</p><button class="btn primary" id="retry">إعادة المحاولة</button></section>';
    $('retry').onclick = () => location.reload();
  }
}
function initRegister() {
  const loadSections = async () => {
    const code = $('institution').value.trim().toLowerCase(); if (code.length < 3) return;
    try {
      const secs = await api('/public/sections?institution=' + encodeURIComponent(code)); const opt = secs.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
      $('section_id').innerHTML = '<option value="">— اختر القسم —</option>' + opt; $('section_ids').innerHTML = opt; $('msg').textContent = '';
    } catch (e) { $('msg').textContent = e.message; }
  };
  $('institution').onchange = loadSections;
  const sync = () => { const r = $('role').value; document.querySelectorAll('[data-for]').forEach(x => { x.hidden = !x.dataset.for.split(' ').includes(r); }); };
  $('role').onchange = sync; sync();
  $('send').onclick = async () => {
    const msg = $('msg'); msg.textContent = ''; msg.style.color = '';
    if ($('password').value !== $('password2').value) { msg.textContent = 'كلمتا المرور غير متطابقتين'; return; }
    const r = $('role').value;
    const body = { institution_code: $('institution').value.trim(), role: r, full_name: $('full_name').value, username: $('username').value, email: $('email').value || undefined, password: $('password').value };
    if (['student', 'parent'].includes(r)) body.section_id = $('section_id').value;
    if (r === 'parent') body.child_name = $('child_name').value;
    if (r === 'teacher') { body.subject = $('subject').value; body.section_ids = [...$('section_ids').selectedOptions].map(o => o.value); }
    try { const out = await api('/register', { method: 'POST', body: JSON.stringify(body) }); msg.style.color = '#13865f'; msg.textContent = out.message; $('send').disabled = true; } catch (e) { msg.textContent = e.message; }
  };
}
function init() {
  if (document.body.classList.contains('register')) { initRegister(); return; }
  if (document.body.classList.contains('login')) { login(); return; }
  if (localStorage.getItem('hwTheme') === 'dark') document.body.classList.add('dark');
  $('theme')?.addEventListener('click', () => setTheme(document.body.classList.contains('dark') ? 'light' : 'dark'));
  $('logout')?.addEventListener('click', async () => { try { await api('/auth/logout', { method: 'POST' }); } catch (_) { } setToken(null); location.replace(LOGIN_URL); });
  $('bell')?.addEventListener('click', () => showPage((MENUS[role] || []).some(x => x[0] === 'notifications') ? 'notifications' : 'announcements'));
  loadDashboard();
}
document.addEventListener('DOMContentLoaded', init);
