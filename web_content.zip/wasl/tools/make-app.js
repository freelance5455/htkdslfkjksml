'use strict';
// يجهّز ملف ZIP للواجهة ليُحوَّل إلى تطبيق (APK) بأداة «ZIP → APK».
// الاستعمال:  node tools/make-app.js https://عنوان-الخادم
// الناتج:     app-build/wasl-app.zip  (index.html في جذر الملف، وconfig.js مكتوب فيه عنوان خادمك)
const fs = require('node:fs'), path = require('node:path'), zlib = require('node:zlib');

const url = (process.argv[2] || '').trim().replace(/\/+$/, '');
if (!/^https?:\/\/[^\s/]+/i.test(url)) {
  console.log('الاستعمال: node tools/make-app.js https://عنوان-الخادم\nمثال:     node tools/make-app.js https://wasl.example.com');
  process.exit(1);
}
if (url.startsWith('http://') && !/^http:\/\/(127\.0\.0\.1|localhost)/i.test(url))
  console.log('تنبيه: العنوان بدون HTTPS. أندرويد قد يمنع الاتصال غير المشفّر، وكلمات المرور ستُرسل مكشوفة. استعمل HTTPS.');

const SRC = path.join(__dirname, '..', 'public'), OUT = path.join(__dirname, '..', 'app-build');
const files = [];
(function walk(dir, rel) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const r = rel ? rel + '/' + e.name : e.name;
    if (e.isDirectory()) walk(path.join(dir, e.name), r); else files.push({ name: r, data: fs.readFileSync(path.join(dir, e.name)) });
  }
})(SRC, '');
const cfg = files.find(f => f.name === 'assets/js/config.js');
cfg.data = Buffer.from(`// أُنشئ بواسطة tools/make-app.js\nwindow.WASL_API_BASE = ${JSON.stringify(url)};\nwindow.WASL_APP = true;\n`);

// كتابة ZIP (بدون ضغط) بلا مكتبات خارجية
const u16 = n => { const b = Buffer.alloc(2); b.writeUInt16LE(n); return b; }, u32 = n => { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0); return b; };
const parts = [], central = []; let offset = 0;
for (const f of files) {
  const name = Buffer.from(f.name, 'utf8'), crc = zlib.crc32(f.data);
  const local = Buffer.concat([u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(0), u16(33), u32(crc), u32(f.data.length), u32(f.data.length), u16(name.length), u16(0), name]);
  central.push(Buffer.concat([u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(33), u32(crc), u32(f.data.length), u32(f.data.length), u16(name.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), name]));
  parts.push(local, f.data); offset += local.length + f.data.length;
}
const cd = Buffer.concat(central);
parts.push(cd, Buffer.concat([u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(cd.length), u32(offset), u16(0)]));
fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'wasl-app.zip'), Buffer.concat(parts));
console.log(`تم: ${path.join(OUT, 'wasl-app.zip')}\nعنوان الخادم داخل التطبيق: ${url}\nعدد الملفات: ${files.length}`);
