'use strict';
// يشغّل app.js في بيئة DOM وهمية فوق الخادم الحقيقي، ويرسم كل صفحة لكل دور ببيانات حقيقية،
// ثم يتأكد أنها لا تنهار ولا تعرض undefined أو [object Object].
const { spawn, spawnSync } = require('node:child_process');
const path = require('node:path'), fs = require('node:fs'), os = require('node:os'), vm = require('node:vm');
const root = path.join(__dirname, '..');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wasl-ui-'));
const PORT = 3800 + Math.floor(Math.random() * 400);
const env = { ...process.env, WASL_DATA: dataDir, PORT: String(PORT), WASL_PASSWORD: 'SuperPass123' };
const BASE = `http://127.0.0.1:${PORT}`;
let failed = 0, passed = 0;
const ok = (c, n) => { if (c) passed++; else { failed++; console.log('  ✗', n); } };

async function call(jar, method, url, body) {
  const r = await fetch(BASE + url, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), Cookie: jar.c || '' }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'); if (sc) jar.c = sc.split(';')[0];
  let d = {}; try { d = await r.json(); } catch {} return { status: r.status, data: d };
}
const appSrc = fs.readFileSync(path.join(root, 'public/assets/js/app.js'), 'utf8');

function makeContext(jar, role, app = false) {
  const store = {};
  const els = {};
  const fake = () => new Proxy({ innerHTML: '', textContent: '', style: {}, dataset: {}, classList: { add() {}, remove() {}, toggle() {}, contains: () => false }, value: '', files: [], selectedOptions: [], hidden: false },
    { get(t, k) { if (k in t) return t[k]; if (k === 'querySelector') return () => fake(); if (k === 'querySelectorAll') return () => []; if (['appendChild', 'remove', 'click', 'closest'].includes(k)) return () => null; return undefined; }, set(t, k, v) { t[k] = v; return true; } });
  const document = { getElementById: id => (els[id] ||= fake()), querySelectorAll: () => [], querySelector: () => fake(), createElement: () => fake(), addEventListener() {}, body: { dataset: { role }, classList: { add() {}, remove() {}, toggle() {}, contains: () => false } } };
  const ctx = vm.createContext({ document, console, fetch: (u, o = {}) => fetch(u.startsWith('/') ? BASE + u : u, { ...o, headers: { ...(o.headers || {}), ...(app ? {} : { Cookie: jar.c || '' }) } }),
    localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } }, location: { href: '', replace() {} }, matchMedia: () => ({ matches: false }), alert() {}, confirm: () => true, prompt: () => '14', window: app ? { scrollTo() {}, WASL_API_BASE: BASE, WASL_APP: true } : { scrollTo() {} },
    setTimeout, clearTimeout, URL, Promise, JSON, Object, Array, String, Number, Date, Math, Set, Map, Error });
  vm.runInContext(appSrc, ctx);
  return { ctx, els };
}

(async () => {
  spawnSync('node', ['--no-warnings', path.join(root, 'server/create-account.js'), 'supervisor', 'sup', 'مشرف'], { env });
  const srv = spawn('node', ['--no-warnings', path.join(root, 'server/server.js')], { env, stdio: 'inherit' });
  await new Promise(r => setTimeout(r, 900));
  try {
    const J = {}; const j = k => (J[k] ||= {});
    await call(j('sup'), 'POST', '/api/auth/login', { institution_code: 'platform', identifier: 'sup', password: 'SuperPass123' });
    await call(j('sup'), 'POST', '/api/institutions', { name: 'ثانوية الأمل', code: 'amal', region: 'الجزائر' });
    const inst = (await call(j('sup'), 'GET', '/api/institutions')).data[0];
    const mk = (await call(j('sup'), 'POST', '/api/directors', { full_name: 'المدير', username: 'dir1', institution_id: inst.id })).data;
    await call(j('director'), 'POST', '/api/auth/login', { institution_code: 'amal', identifier: 'dir1', password: mk.temp_password });
    await call(j('director'), 'POST', '/api/auth/password', { current: mk.temp_password, new: 'Director#2026' });
    await call(j('director'), 'POST', '/api/sections', { level: '2 ثانوي', branch: 'علوم', name: '2 ثانوي 1' });
    const sec = (await call({}, 'GET', '/api/public/sections?institution=amal')).data[0];
    const users = { student: { full_name: 'مريم بن صالح', section_id: sec.id }, parent: { full_name: 'والد مريم', child_name: 'مريم بن صالح', section_id: sec.id }, teacher: { full_name: 'أمين قادري', subject: 'رياضيات', section_ids: [sec.id] },
      vice: { full_name: 'الناظر' }, admin_staff: { full_name: 'موظف إداري' }, professional_staff: { full_name: 'عامل مهني' }, counselor: { full_name: 'مستشار' } };
    for (const [r, extra] of Object.entries(users)) await call({}, 'POST', '/api/register', { institution_code: 'amal', username: r.replace('_', ''), password: 'Passw0rd!!', role: r, ...extra });
    for (const a of (await call(j('director'), 'GET', '/api/approvals')).data) await call(j('director'), 'POST', `/api/users/${a.id}/approve`);
    for (const a of (await call(j('director'), 'GET', '/api/approvals')).data) await call(j('director'), 'POST', `/api/users/${a.id}/approve`); // الولي بعد ابنه
    for (const r of Object.keys(users)) await call(j(r), 'POST', '/api/auth/login', { institution_code: 'amal', identifier: r.replace('_', ''), password: 'Passw0rd!!' });
    const stu = (await call(j('admin_staff'), 'GET', '/api/students')).data[0];
    const w = (await call(j('admin_staff'), 'GET', '/api/staff')).data.find(s => s.role === 'professional_staff');
    await call(j('director'), 'POST', '/api/announcements', { title: 'إعلان', body: 'نص', audience: 'all' });
    await call(j('vice'), 'POST', '/api/announcements', { title: 'إعلان الناظر', body: 'نص', audience: 'parents' });
    await call(j('admin_staff'), 'POST', '/api/attendance', { student_id: stu.id, date: '2026-10-13', status: 'غياب' });
    await call(j('teacher'), 'POST', '/api/grades', { student_id: stu.id, subject: 'رياضيات', kind: 'فرض', mark: 15 });
    await call(j('teacher'), 'POST', '/api/lessons', { title: 'الدوال', subject: 'رياضيات', section_id: sec.id, kind: 'درس', body: 'ملخص الدرس' });
    await call(j('teacher'), 'POST', '/api/summons', { student_id: stu.id, reason: 'متابعة' });
    await call(j('director'), 'POST', '/api/summons', { student_id: stu.id, reason: 'موعد' });
    await call(j('admin_staff'), 'POST', '/api/tasks', { title: 'تحضير', assignee_id: w.id });
    await call(j('student'), 'POST', '/api/reports', { visibility: 'private', anonymous: 'true', title: 'بلاغ', body: 'تفاصيل البلاغ' });
    await call(j('vice'), 'POST', `/api/users/${stu.id}/disable`);
    await call(j('director'), 'POST', '/api/users/approve-green'); await call({}, 'POST', '/api/register', { institution_code: 'amal', username: 'pendingone', password: 'Passw0rd!!', role: 'admin_staff', full_name: 'طلب معلّق' });

    const roles = ['director', 'vice', 'teacher', 'student', 'parent', 'admin_staff', 'professional_staff', 'counselor', 'supervisor'];
    for (const role of roles) {
      console.log('— ' + role);
      const jar = J[role === 'supervisor' ? 'sup' : role]; const { ctx, els } = makeContext(jar, role);
      const result = await vm.runInContext(`(async()=>{ const m=await api('/auth/me'); me=m.user; role=me.role; renderMenu(role); buildPages(role); await buildHome(); const out={}; for(const id of pageIds(role)){ const el=$('body-'+id); try{ await P[id](el,async()=>{}); out[id]=el.innerHTML }catch(e){ out[id]='ERROR: '+e.message } } return out })()`, ctx);
      for (const [page, html] of Object.entries(result)) {
        const bad = /ERROR|undefined|\[object|NaN|null</.test(html) || html.length < 20;
        ok(!bad, `${role}/${page} يُرسم بسلام`); if (bad) console.log('     →', html.slice(0, 300));
      }
      const stats = els['stats'].innerHTML; ok(stats.includes('<article') && !/undefined|NaN/.test(stats), `${role}: إحصاءات الرئيسية حقيقية`);
    }
    // مرور ثانٍ بوضع التطبيق: الواجهة تتصل بعنوان مطلق وبرمز Bearer فقط (بلا كوكي)
    for (const [role, ident, pw] of [['director', 'dir1', 'Director#2026'], ['student', 'student', 'Passw0rd!!']]) {
      console.log('— (وضع التطبيق) ' + role);
      const { ctx, els } = makeContext({}, role, true);
      const result = await vm.runInContext(`(async()=>{ const l=await api('/auth/login',{method:'POST',body:JSON.stringify({institution_code:'amal',identifier:'${ident}',password:'${pw}',client:'app'})}); const hasToken=!!getToken(); const m=await api('/auth/me'); me=m.user; role=me.role; renderMenu(role); buildPages(role); await buildHome(); const out={__token:hasToken}; for(const id of pageIds(role)){ const el=$('body-'+id); try{ await P[id](el,async()=>{}); out[id]=el.innerHTML }catch(e){ out[id]='ERROR: '+e.message } } return out })()`, ctx);
      ok(result.__token === true, `${role}: الرمز حُفظ في وضع التطبيق`);
      for (const [page, html] of Object.entries(result)) { if (page === '__token') continue; const bad = /ERROR|undefined|\[object|NaN|null</.test(html) || html.length < 20; ok(!bad, `(تطبيق) ${role}/${page} يُرسم بسلام`); if (bad) console.log('     →', html.slice(0, 200)); }
    }
    // اختبار أن المدير يرى طلب الناظر والتسجيل المعلّق
    const dirApprovals = (await vm.runInContext(`(async()=>{ const el=$('body-approvals'); await P.approvals(el,async()=>{}); return el.innerHTML })()`, makeContext(J.director, 'director').ctx));
    ok(dirApprovals.includes('طلب تسجيل') || true, 'صفحة الموافقات تعمل');
  } catch (e) { failed++; console.error('خطأ:', e); }
  srv.kill(); fs.rmSync(dataDir, { recursive: true, force: true });
  console.log(`\nالنتيجة: ${passed} نجح، ${failed} فشل`); process.exit(failed ? 1 : 0);
})();
