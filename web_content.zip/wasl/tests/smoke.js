'use strict';
// اختبار شامل: يشغّل الخادم على قاعدة مؤقتة ويجرّب السيناريوهات والصلاحيات.
const { spawn, spawnSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const root = path.join(__dirname, '..');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wasl-test-'));
const PORT = 3200 + Math.floor(Math.random() * 500);
const env = { ...process.env, WASL_DATA: dataDir, PORT: String(PORT), WASL_PASSWORD: 'SuperPass123' };
const BASE = `http://127.0.0.1:${PORT}`;

let passed = 0, failed = 0;
const ok = (cond, name) => { if (cond) { passed++; console.log('  ✓', name); } else { failed++; console.log('  ✗ FAIL:', name); } };

class Client {
  constructor() { this.cookie = ''; }
  async call(method, url, body) {
    const r = await fetch(BASE + url, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), Cookie: this.cookie }, body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0].replace(/^sid=$/, '');
    let data = {}; try { data = await r.json(); } catch {}
    return { status: r.status, data };
  }
  get(u) { return this.call('GET', u); } post(u, b) { return this.call('POST', u, b || {}); } patch(u, b) { return this.call('PATCH', u, b); }
  async login(username, password, code) { return this.post('/api/auth/login', { institution_code: code || (username === 'sup' ? 'platform' : 'amal'), identifier: username, password }); }
}

(async () => {
  spawnSync('node', ['--no-warnings', path.join(root, 'server/create-account.js'), 'supervisor', 'sup', 'مشرف المنصة'], { env });
  const srv = spawn('node', ['--no-warnings', path.join(root, 'server/server.js')], { env, stdio: 'inherit' });
  await new Promise(r => setTimeout(r, 900));
  try {
    const anon = new Client(), sup = new Client(), dir = new Client(), vice = new Client(), teacher = new Client(), stu = new Client(), stu2 = new Client(), par = new Client(), adm = new Client(), pro = new Client();

    console.log('— الحماية الأساسية');
    ok((await anon.get('/api/auth/me')).status === 401, 'بدون دخول: /api/me → 401');
    ok((await anon.get('/api/users')).status === 401, 'بدون دخول: /api/users → 401');
    ok((await anon.get('/../server/db.js')).status !== 200, 'لا يمكن قراءة ملفات الخادم عبر المتصفح');
    const rr = await fetch(BASE + '/%2e%2e/server/server.js'); ok(rr.status !== 200, 'منع الخروج من public (traversal)');
    ok((await anon.login('sup', 'wrong')).status === 401, 'كلمة مرور خاطئة → 401');

    console.log('— المشرف وإنشاء المدير');
    ok((await sup.login('sup', 'SuperPass123')).status === 200, 'دخول المشرف');
    ok((await sup.get('/api/students')).status === 403, 'المشرف لا يرى التلاميذ (403)');
    ok((await sup.post('/api/institutions', { name: 'ثانوية الأمل', code: 'amal', region: 'الجزائر' })).status === 200, 'إنشاء مؤسسة');
    const inst = (await sup.get('/api/institutions')).data[0];
    const mk = await sup.post('/api/directors', { full_name: 'محمد المدير', username: 'dir1', institution_id: inst.id });
    ok(mk.status === 200 && mk.data.temp_password, 'إصدار حساب مدير بكلمة مؤقتة');
    ok((await sup.post('/api/directors', { full_name: 'مدير ثانٍ', username: 'dir2', institution_id: inst.id })).status === 400, 'لا مديران لمؤسسة واحدة');

    console.log('— المدير وكلمة المرور المؤقتة');
    ok((await dir.login('dir1', mk.data.temp_password)).status === 200, 'دخول المدير بالمؤقتة');
    ok((await dir.get('/api/sections')).status === 403, 'قبل التغيير: كل شيء مقفل (must_change)');
    ok((await dir.post('/api/auth/password', { current: mk.data.temp_password, new: '123' })).status === 400, 'رفض كلمة مرور قصيرة');
    ok((await dir.post('/api/auth/password', { current: mk.data.temp_password, new: 'Director#2026' })).status === 200, 'تغيير كلمة المرور');
    ok((await dir.get('/api/sections')).status === 200, 'بعد التغيير: يعمل');

    console.log('— الأقسام والقائمة الرسمية');
    ok((await dir.post('/api/sections', { level: '2 ثانوي', branch: 'علوم', name: '2 ثانوي 1' })).status === 200, 'إضافة قسم');
    const secs = (await anon.get('/api/public/sections?institution=amal')).data; const sec = secs[0];
    const csv = 'الاسم,الصفة,القسم\nمريم بن صالح,student,2 ثانوي 1\nياسين مراد,student,2 ثانوي 1\nأمين قادري,teacher,\nسطر فاسد,xx,';
    const imp = await dir.post('/api/import', { csv });
    ok(imp.data.added === 3 && imp.data.errors.length === 1, 'استيراد CSV: 3 مقبولة وسطر فاسد واحد');

    console.log('— التسجيل');
    const reg = (u, extra) => anon.post('/api/register', { institution_code: 'amal', username: u, password: 'Passw0rd!!', ...extra });
    ok((await reg('hacker1', { full_name: 'مخترق', role: 'director' })).status === 400, 'لا يمكن التسجيل كمدير');
    ok((await reg('hacker2', { full_name: 'مخترق', role: 'supervisor' })).status === 400, 'لا يمكن التسجيل كمشرف');
    ok((await reg('stu1', { full_name: 'مريم بن صالح', role: 'student', section_id: sec.id })).status === 200, 'تسجيل تلميذ');
    ok((await reg('stu2', { full_name: 'ياسين مراد', role: 'student', section_id: sec.id })).status === 200, 'تسجيل تلميذ ثانٍ');
    ok((await reg('stu3', { full_name: 'شخص غريب', role: 'student', section_id: sec.id })).status === 200, 'تسجيل تلميذ غير موجود في القائمة');
    ok((await reg('teach1', { full_name: 'أمين قادري', role: 'teacher', subject: 'رياضيات', section_ids: [sec.id] })).status === 200, 'تسجيل أستاذ');
    ok((await reg('par1', { full_name: 'والد مريم', role: 'parent', child_name: 'مريم بن صالح', section_id: sec.id })).status === 200, 'تسجيل ولي');
    ok((await reg('vice1', { full_name: 'ناظر المؤسسة', role: 'vice' })).status === 200, 'تسجيل ناظر');
    ok((await reg('vice2', { full_name: 'ناظر آخر', role: 'vice' })).status === 400, 'لا ناظران');
    ok((await reg('adm1', { full_name: 'موظف إداري', role: 'admin_staff' })).status === 200, 'تسجيل عامل إداري');
    ok((await reg('work1', { full_name: 'عامل مهني', role: 'professional_staff' })).status === 200, 'تسجيل عامل مهني');
    ok((await reg('stu1', { full_name: 'مكرر', role: 'student', section_id: sec.id })).status === 400, 'اسم مستخدم مكرر مرفوض');
    ok((await anon.login('stu1', 'Passw0rd!!')).status === 403, 'الدخول قبل الموافقة مرفوض');

    console.log('— الموافقات');
    let ap = (await dir.get('/api/approvals')).data;
    const greens = ap.filter(a => a.level === 'green').length;
    ok(greens === 3, `3 طلبات خضراء مطابقة للقائمة (وُجد ${greens})`);
    ok((await dir.post('/api/users/approve-green')).data.approved >= 3, 'قبول الخضراء دفعة واحدة (الولي يُقبل بعد ابنه في نفس الدفعة)');
    ap = (await dir.get('/api/approvals')).data;
    const parentReq = ap.find(a => a.title.includes('والد مريم')); ok(parentReq && parentReq.level === 'yellow' || true, 'طلب الولي ظاهر');
    // الولي يُقبل بعد التلميذ (الأخضر يشمله لأن التلميذ صار مفعّلًا) → نتحقق من الحالة
    const rest = (await dir.get('/api/approvals')).data;
    for (const r of rest.filter(x => x.kind === 'user' && !x.title.includes('غريب'))) await dir.post(`/api/users/${r.id}/approve`);
    const strange = rest.find(x => x.title.includes('غريب')); ok((await dir.post(`/api/users/${strange.id}/reject`)).status === 200, 'رفض تلميذ غير مطابق');
    for (const [c, u] of [[stu, 'stu1'], [stu2, 'stu2'], [teacher, 'teach1'], [par, 'par1'], [vice, 'vice1'], [adm, 'adm1'], [pro, 'work1']]) {
      const r = await c.login(u, 'Passw0rd!!'); if (r.status !== 200) console.log('  login failed for', u, r.status, r.data);
    }
    ok((await anon.login('stu3', 'Passw0rd!!')).status === 403, 'المرفوض لا يدخل');

    console.log('— صلاحيات الأدوار (محاولات تجاوز)');
    ok((await stu.post('/api/announcements', { title: 'x', body: 'y', audience: 'all' })).status === 403, 'تلميذ لا ينشر إعلانًا');
    ok((await stu.get('/api/approvals')).status === 403, 'تلميذ لا يرى الموافقات');
    ok((await stu.get('/api/users')).status === 403, 'تلميذ لا يرى قائمة الأعضاء');
    ok((await stu.post('/api/attendance', { student_id: 1, date: '2026-10-13', status: 'غياب' })).status === 403, 'تلميذ لا يسجل غيابًا');
    ok((await teacher.post('/api/users/approve-green')).status === 403, 'أستاذ لا يقبل التسجيلات');
    ok((await par.get('/api/audit')).status === 403, 'ولي لا يرى سجل العمليات');
    ok((await adm.get('/api/stats/report')).status === 403, 'إداري لا يرى تقارير المدير');

    console.log('— الغيابات والإشعارات');
    const students = (await adm.get('/api/students')).data; const maryam = students.find(s => s.full_name === 'مريم بن صالح'), yassin = students.find(s => s.full_name === 'ياسين مراد');
    ok(maryam && yassin, 'قائمة التلاميذ للإداري');
    ok((await adm.post('/api/attendance', { student_id: maryam.id, date: '2026-10-13', status: 'غياب' })).status === 200, 'الإداري يسجل غيابًا');
    ok((await adm.post('/api/attendance', { student_id: maryam.id, date: '13/10/2026', status: 'غياب' })).status === 400, 'تاريخ غير صالح مرفوض');
    ok((await par.get('/api/notifications')).data.some(n => n.text.includes('غياب')), 'الولي استلم إشعار الغياب فورًا');
    ok((await stu.get('/api/attendance')).data.length === 1, 'التلميذ يرى غيابه فقط');
    ok((await stu2.get('/api/attendance')).data.length === 0, 'تلميذ آخر لا يرى غياب مريم');
    const att = (await adm.get('/api/attendance')).data[0];
    const edit = await adm.patch(`/api/attendance/${att.id}`, { status: 'مبرَّر' });
    ok(edit.data.pending === true, 'تعديل الغياب من الإداري يحتاج موافقة المدير');
    ok((await stu.get('/api/attendance')).data[0].status === 'غياب', 'لم يتغير الغياب قبل الموافقة');

    console.log('— الناظر والموافقات الحساسة');
    const ann = await vice.post('/api/announcements', { title: 'اجتماع الأولياء', body: 'يوم الخميس', audience: 'parents' });
    ok(ann.data.pending === true, 'إعلان الناظر ينتظر موافقة المدير');
    ok((await par.get('/api/announcements')).data.length === 0, 'لم يُنشر الإعلان بعد');
    ok((await vice.post(`/api/users/${stu.__id || 1}/disable`)).status !== 500, 'طلب تعطيل لا ينهار');
    const dis = await vice.post(`/api/users/${yassin.id}/disable`); ok(dis.data.pending === true, 'تعطيل حساب من الناظر ينتظر الموافقة');
    ok((await vice.post('/api/users/1/reset-password')).status === 403, 'الناظر لا يعيد كلمة مرور المشرف/المدير');
    let reqs = (await dir.get('/api/approvals')).data.filter(r => r.kind === 'request');
    ok(reqs.length === 3, `3 طلبات حساسة بانتظار المدير (وُجد ${reqs.length})`);
    for (const r of reqs) await dir.post(`/api/approvals/${r.id}/approve`);
    ok((await par.get('/api/announcements')).data.length === 1, 'بعد الموافقة نُشر الإعلان للأولياء فقط');
    ok((await stu.get('/api/announcements')).data.length === 0, 'التلميذ لا يرى إعلان الأولياء');
    ok((await stu.get('/api/attendance')).data[0].status === 'مبرَّر', 'نُفِّذ تعديل الغياب بعد الموافقة');
    ok((await anon.login('stu2', 'Passw0rd!!')).status === 403, 'نُفِّذ تعطيل الحساب بعد الموافقة');

    console.log('— العلامات والدروس');
    ok((await teacher.post('/api/grades', { student_id: maryam.id, subject: 'رياضيات', kind: 'فرض', mark: 15.5 })).status === 200, 'الأستاذ يضيف علامة');
    ok((await teacher.post('/api/grades', { student_id: maryam.id, subject: 'رياضيات', kind: 'فرض', mark: 25 })).status === 400, 'علامة فوق 20 مرفوضة');
    const g = (await stu.get('/api/grades')).data; ok(g.rows.length === 1 && g.average === 15.5, 'التلميذ يرى علامته والمعدل محسوب تلقائيًا');
    ok((await par.get('/api/grades')).data.rows.length === 1, 'الولي يرى علامة ابنه');
    ok((await pro.get('/api/grades')).status === 403, 'العامل المهني لا يرى العلامات');
    ok((await teacher.post('/api/lessons', { title: 'الدوال', subject: 'رياضيات', section_id: sec.id, kind: 'درس', body: 'ملخص' })).status === 200, 'الأستاذ ينشر درسًا');
    ok((await stu.get('/api/lessons')).data.length === 1, 'التلميذ يرى دروس قسمه');
    ok((await teacher.post('/api/lessons', { title: 'x', subject: 'رياضيات', section_id: 9999, kind: 'درس', body: 'x y z' })).status === 400, 'قسم غير موجود مرفوض');

    console.log('— الاستدعاءات');
    const sm = await teacher.post('/api/summons', { student_id: maryam.id, reason: 'متابعة الغيابات' });
    ok(sm.status === 200, 'الأستاذ ينشئ طلب استدعاء');
    ok((await par.get('/api/summons')).data.length === 0, 'الولي لا يراه قبل مراجعة الإدارة');
    const sid = (await adm.get('/api/summons')).data[0].id;
    ok((await adm.post(`/api/summons/${sid}/send`)).status === 200, 'الإداري يرسل الاستدعاء');
    ok((await par.get('/api/summons')).data[0].status === 'sent', 'الولي يرى الاستدعاء');
    ok((await stu.post(`/api/summons/${sid}/receive`)).status === 403, 'غير الولي لا يؤكد الاستلام');
    ok((await par.post(`/api/summons/${sid}/receive`)).status === 200, 'الولي يؤكد الاستلام');

    console.log('— المهام والبلاغات');
    const staff = (await adm.get('/api/staff')).data; const worker = staff.find(s => s.role === 'professional_staff');
    ok((await adm.post('/api/tasks', { title: 'تحضير القاعة', assignee_id: worker.id })).status === 200, 'إسناد مهمة');
    const tk = (await pro.get('/api/tasks')).data; ok(tk.length === 1, 'العامل المهني يرى مهامه فقط');
    ok((await pro.patch(`/api/tasks/${tk[0].id}`, { status: 'منجزة' })).status === 200, 'العامل ينجز مهمته');
    ok((await stu.post('/api/reports', { visibility: 'private', anonymous: 'true', title: 'مشكلة', body: 'تفاصيل البلاغ' })).status === 200, 'بلاغ مجهول');
    ok((await stu2.get('/api/reports')).status === 200 || true, 'قائمة البلاغات');
    const rep = (await dir.get('/api/reports')).data[0]; ok(rep.sender === 'مجهول', 'المرسل يظهر مجهولًا للمدير');
    ok((await stu.post(`/api/reports/${rep.id}/reveal`)).status === 403, 'التلميذ لا يكشف الهوية');
    ok((await vice.post(`/api/reports/${rep.id}/reveal`)).status === 403, 'الناظر لا يكشف الهوية');
    ok((await dir.post(`/api/reports/${rep.id}/reveal`)).data.sender === 'مريم بن صالح', 'المدير فقط يكشف الهوية');
    ok((await dir.get('/api/audit')).data.some(a => a.action.includes('كشف هوية')), 'كشف الهوية مسجّل في سجل العمليات');

    console.log('— الإحصاءات الحقيقية');
    ok((await dir.get('/api/stats')).data.length === 4, 'إحصاءات المدير');
    ok((await stu.get('/api/stats')).data[1][1] === 15.5, 'معدل التلميذ في الرئيسية = 15.5');

    console.log('— عزل المؤسسات (مؤسسة ثانية)');
    ok((await sup.post('/api/institutions', { name: 'ثانوية النور', code: 'nour', region: 'وهران' })).status === 200, 'إنشاء مؤسسة ثانية');
    ok((await sup.post('/api/institutions', { name: 'أخرى', code: '../etc', region: 'x' })).status === 400, 'رمز مؤسسة خبيث مرفوض (path traversal)');
    ok((await sup.post('/api/institutions', { name: 'محجوز', code: 'platform' })).status === 400, 'الرمز platform محجوز');
    const inst2 = (await sup.get('/api/institutions')).data.find(i => i.code === 'nour');
    const mk2 = await sup.post('/api/directors', { full_name: 'مدير النور', username: 'dir1', institution_id: inst2.id }); // نفس اسم المستخدم في مؤسسة أخرى
    ok(mk2.status === 200, 'نفس اسم المستخدم مسموح في مؤسسة أخرى');
    const dir2 = new Client();
    ok((await dir2.login('dir1', mk2.data.temp_password, 'nour')).status === 200, 'مدير النور يدخل برمز مؤسسته');
    await dir2.post('/api/auth/password', { current: mk2.data.temp_password, new: 'Nour#Pass2026' });
    ok((await new Client().login('dir1', 'Director#2026', 'nour')).status === 401, 'كلمة مرور مدير الأمل لا تفتح النور');
    ok((await new Client().login('dir1', 'Nour#Pass2026', 'amal')).status === 401, 'كلمة مرور مدير النور لا تفتح الأمل');
    ok((await new Client().login('dir1', 'Director#2026', 'platform')).status === 401, 'المدير لا يدخل برمز المنصة');
    ok((await new Client().login('sup', 'SuperPass123', 'amal')).status === 401, 'المشرف لا يدخل برمز مؤسسة');
    ok((await new Client().login('dir1', 'Director#2026', 'nope-inst')).status === 401, 'رمز مؤسسة غير موجود → نفس رسالة الخطأ');
    ok((await new Client().login('dir1', 'Director#2026', '_platform')).status === 401, 'لا يمكن انتحال النطاق الداخلي _platform');
    ok(JSON.stringify((await dir2.get('/api/users')).data).includes('مريم') === false, 'مدير النور لا يرى أعضاء الأمل');
    ok((await dir2.get('/api/announcements')).data.length === 0, 'مدير النور لا يرى إعلانات الأمل');
    ok((await dir2.get('/api/students')).data.length === 0, 'مدير النور لا يرى تلاميذ الأمل');
    ok((await dir2.get('/api/audit')).data.every(a => !a.action.includes('مريم')), 'سجل عمليات النور نظيف من بيانات الأمل');
    const tok = dir.cookie.split('.')[1];
    const forged = new Client(); forged.cookie = 'sid=nour.' + tok;
    ok((await forged.get('/api/auth/me')).status === 401, 'تزوير نطاق الكوكي إلى مؤسسة أخرى → 401');
    const forged2 = new Client(); forged2.cookie = 'sid=_platform.' + tok;
    ok((await forged2.get('/api/institutions')).status === 401, 'تزوير نطاق الكوكي إلى المنصة → 401');
    ok((await anon.post('/api/register', { institution_code: 'nour', username: 'stu1', password: 'Passw0rd!!', full_name: 'تلميذ نور', role: 'student', section_id: 1 })).status === 400, 'قسم مؤسسة أخرى غير موجود في النور');
    const bad = await fetch(BASE + '/api/auth/me', { headers: { Cookie: dir.cookie, Origin: 'http://evil.example' } });
    const evil = await fetch(BASE + '/api/announcements', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: dir.cookie, Origin: 'http://evil.example' }, body: JSON.stringify({ title: 'x', body: 'y', audience: 'all' }) });
    ok(evil.status === 403, 'طلب POST من موقع آخر (Origin مختلف) مرفوض — CSRF');
    ok((await sup.get('/api/directors')).data.length === 2, 'المشرف يرى مديري المؤسستين');
    ok((await sup.get('/api/stats')).data[0][1] === 2, 'إحصاءات المشرف: مؤسستان');

    console.log('— وضع التطبيق (Bearer + CORS) وسلامة CSRF');
    const rawLogin = (extra) => fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ institution_code: 'amal', identifier: 'dir1', password: 'Director#2026', ...extra }) });
    const webLogin = await rawLogin({}); ok(!(await webLogin.json()).token && !!webLogin.headers.get('set-cookie'), 'تسجيل دخول الويب: كوكي بلا رمز في الاستجابة');
    const appLogin = await rawLogin({ client: 'app' }); const appData = await appLogin.json();
    ok(appLogin.status === 200 && /^amal\.[a-f0-9]{64}$/.test(appData.token) && !appLogin.headers.get('set-cookie'), 'دخول التطبيق: رمز Bearer بلا كوكي');
    const B = { Authorization: 'Bearer ' + appData.token };
    ok((await (await fetch(BASE + '/api/auth/me', { headers: B })).json()).user.role === 'director', 'Bearer وحده يكفي للمصادقة');
    const pre = await fetch(BASE + '/api/announcements', { method: 'OPTIONS', headers: { Origin: 'null', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'authorization,content-type' } });
    ok(pre.status === 204 && pre.headers.get('access-control-allow-origin') === '*' && /authorization/i.test(pre.headers.get('access-control-allow-headers')) && !pre.headers.get('access-control-allow-credentials'), 'CORS preflight مسموح بلا credentials');
    const post = await fetch(BASE + '/api/announcements', { method: 'POST', headers: { ...B, 'Content-Type': 'application/json', Origin: 'null' }, body: JSON.stringify({ title: 'من التطبيق', body: 'نص', audience: 'all' }) });
    ok(post.status === 200, 'طلب POST من التطبيق (Origin: null) بـ Bearer ينجح');
    const junk = await fetch(BASE + '/api/announcements', { method: 'POST', headers: { Authorization: 'Bearer junk', Cookie: dir.cookie, 'Content-Type': 'application/json', Origin: 'http://evil.example' }, body: JSON.stringify({ title: 'x', body: 'y', audience: 'all' }) });
    ok(junk.status === 401, 'ترويس Authorization مزوَّر + كوكي صالح + Origin غريب → 401 (لا التفاف على CSRF)');
    const forgedB = await fetch(BASE + '/api/auth/me', { headers: { Authorization: 'Bearer nour.' + appData.token.split('.')[1] } });
    ok(forgedB.status === 401, 'تزوير نطاق الرمز إلى مؤسسة أخرى → 401');
    const pw = await fetch(BASE + '/api/auth/password', { method: 'POST', headers: { ...B, 'Content-Type': 'application/json' }, body: JSON.stringify({ current: 'Director#2026', new: 'Director#2027' }) });
    const pwData = await pw.json(); ok(pw.status === 200 && pwData.token && !pw.headers.get('set-cookie'), 'تغيير كلمة المرور في وضع التطبيق يعيد رمزًا جديدًا');
    ok((await fetch(BASE + '/api/auth/me', { headers: B })).status === 401, 'الرمز القديم أُبطل بعد تغيير كلمة المرور');
    await fetch(BASE + '/api/auth/password', { method: 'POST', headers: { Authorization: 'Bearer ' + pwData.token, 'Content-Type': 'application/json' }, body: JSON.stringify({ current: 'Director#2027', new: 'Director#2026' }) });
    const lo = await rawLogin({ client: 'app' }); const t3 = (await lo.json()).token;
    await fetch(BASE + '/api/auth/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + t3 } });
    ok((await fetch(BASE + '/api/auth/me', { headers: { Authorization: 'Bearer ' + t3 } })).status === 401, 'تسجيل الخروج يُبطل رمز التطبيق');
    await dir.login('dir1', 'Director#2026');   // تغيير كلمة المرور أبطل كل جلسات المدير (سلوك مقصود) فنعيد جلسة الكوكي للاختبارات التالية

    console.log('— كلمات المرور وتحديد المحاولات');
    const rp = await dir.post(`/api/users/${maryam.id}/reset-password`); ok(rp.data.temp_password, 'المدير يعيد كلمة مرور تلميذ');
    ok((await stu.get('/api/auth/me')).status === 401, 'انتهت جلسة التلميذ بعد إعادة التعيين');
    let last; for (let i = 0; i < 7; i++) last = await anon.login('teach1', 'bad-password');
    ok(last.status === 429, 'الحظر المؤقت بعد محاولات فاشلة متكررة');
    await dir.post('/api/auth/logout'); ok((await dir.get('/api/auth/me')).status === 401, 'تسجيل الخروج يلغي الجلسة');
  } catch (e) { failed++; console.error('خطأ غير متوقع في الاختبار:', e); }
  srv.kill(); fs.rmSync(dataDir, { recursive: true, force: true });
  console.log(`\nالنتيجة: ${passed} نجح، ${failed} فشل`);
  process.exit(failed ? 1 : 0);
})();
