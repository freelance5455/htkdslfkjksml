M ALHAISAM CUSTOMER SERVICE v8

ISO A7 bill (74 x 105 mm), clearer item/quantity/rate/amount spacing, clickable Bill History with full Bill Preview and Print Bill. All prior features retained.
