(() => {
  const $ = id => document.getElementById(id);
  const audio = $("audio");
  const fileInput = $("fileInput");
  let songs = [];
  let current = -1;
  let shuffle = false;
  let repeat = false;
  let speed = 1;
  let queueOpen = false;
  const stateKey = "javid_music_state_v3";
  const DB_NAME = "JavidMusicAudioDB", STORE = "songs";
  let state;
  try { state = JSON.parse(localStorage.getItem(stateKey) || localStorage.getItem("javid_music_state_v2") || "{}"); } catch { state = {}; }
  state = {
    favorites: Array.isArray(state.favorites) ? state.favorites : [],
    recent: Array.isArray(state.recent) ? state.recent : [],
    playlists: state.playlists && typeof state.playlists === "object" ? state.playlists : {}
  };
  let db;

  const saveState = () => localStorage.setItem(stateKey, JSON.stringify(state));
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
  const fmt = t => !isFinite(t) ? "0:00" : `${Math.floor(Math.max(0,t)/60)}:${String(Math.floor(Math.max(0,t)%60)).padStart(2,"0")}`;
  let toastTimer;
  function toast(msg){ const el=$("toast"); if(!el)return; el.textContent=msg; el.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2200); }

  function openDB(){
    return new Promise((resolve,reject)=>{
      if(db) return resolve(db);
      if(!window.indexedDB) return reject(new Error("IndexedDB unavailable"));
      const req=indexedDB.open(DB_NAME,1);
      req.onupgradeneeded=e=>{ const d=e.target.result; if(!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE,{keyPath:"id"}); };
      req.onsuccess=e=>{ db=e.target.result; resolve(db); };
      req.onerror=()=>reject(req.error || new Error("DB error"));
    });
  }
  async function saveFile(file,meta){
    const d=await openDB();
    return new Promise((resolve,reject)=>{
      const tx=d.transaction(STORE,"readwrite");
      tx.objectStore(STORE).put({id:meta.id,name:file.name,size:file.size,lastModified:file.lastModified,type:file.type,blob:file});
      tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error);
    });
  }
  async function loadSavedSongs(){
    try{
      const d=await openDB();
      const rows=await new Promise((resolve,reject)=>{const tx=d.transaction(STORE,"readonly");const r=tx.objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});
      rows.forEach(x=>addSongFromFile(new File([x.blob],x.name,{type:x.type,lastModified:x.lastModified}),false,x.id));
      render();
    }catch(e){ console.warn("Audio library load failed",e); }
  }
  function addSongFromFile(file,persist=true,forcedId=null){
    const id=forcedId || `${file.name}_${file.size}_${file.lastModified}`;
    if(songs.some(s=>s.id===id)) return false;
    const base=file.name.replace(/\.[^.]+$/,'');
    const parts=base.split(" - ");
    songs.push({id,title:parts.length>1?parts.slice(1).join(" - "):base,artist:parts.length>1?parts[0]:"هنرمند نامشخص",url:URL.createObjectURL(file),file});
    if(persist) saveFile(file,{id}).catch(e=>console.warn("save failed",e));
    return true;
  }
  function updateStats(){
    const n=new Intl.NumberFormat("fa-IR");
    if($("songCount")) $("songCount").textContent=n.format(songs.length);
    if($("favCount")) $("favCount").textContent=n.format(state.favorites.length);
    if($("recentCount")) $("recentCount").textContent=n.format(state.recent.length);
  }
  function render(){
    updateStats();
    const q=($("searchBox")?.value||"").trim().toLowerCase();
    const list=songs.filter(s=>!q||`${s.title} ${s.artist}`.toLowerCase().includes(q));
    renderSongs($("songs"),list); renderSongs($("librarySongs"),list); renderSongs($("results"),list); renderRecent(); renderGenres(q);
    $("songsEmpty")?.classList.toggle("hidden",songs.length>0);
    $("recentEmpty")?.classList.toggle("hidden",state.recent.length>0);
    if($("favBtn") && current>=0) $("favBtn").textContent=state.favorites.includes(songs[current]?.id)?"♥":"♡";
  }
  function renderSongs(el,list){
    if(!el)return;
    el.innerHTML=list.map(s=>{const i=songs.indexOf(s),fav=state.favorites.includes(s.id);return `<div class="song" data-index="${i}"><div class="mini">♫</div><div class="info"><b>${esc(s.title)}</b><small>${esc(s.artist)}</small></div><button class="row-play" data-play="${i}" aria-label="پخش">▶</button><button class="more" data-fav="${i}" aria-label="پسندیدن">${fav?"♥":"♡"}</button></div>`}).join("");
    el.querySelectorAll("[data-play]").forEach(b=>b.addEventListener("click",e=>{e.stopPropagation();play(+b.dataset.play)}));
    el.querySelectorAll("[data-fav]").forEach(b=>b.addEventListener("click",e=>{e.stopPropagation();toggleFav(+b.dataset.fav)}));
    el.querySelectorAll(".song").forEach(x=>x.addEventListener("click",()=>play(+x.dataset.index)));
  }
  function renderRecent(){
    const el=$("recent"); if(!el)return;
    const recent=state.recent.map(id=>songs.find(s=>s.id===id)).filter(Boolean);
    el.innerHTML=recent.map(s=>`<div class="card" data-recent="${songs.indexOf(s)}"><div class="art">♫</div><b>${esc(s.title)}</b><small>${esc(s.artist)}</small></div>`).join("");
    el.querySelectorAll("[data-recent]").forEach(x=>x.addEventListener("click",()=>play(+x.dataset.recent)));
  }
  function renderGenres(q=""){
    const el=$("genres"); if(!el)return;
    const genres=["همه","پاپ","راک","رپ","سنتی","الکترونیک","بی‌کلام"];
    el.innerHTML=genres.map(g=>`<button class="genre ${g==="همه"&&!q?"active":""}" data-genre="${esc(g)}">${g}</button>`).join("");
    el.querySelectorAll("[data-genre]").forEach(b=>b.addEventListener("click",()=>{
      $("searchBox").value=b.dataset.genre==="همه"?"":b.dataset.genre; render();
      el.querySelectorAll("button").forEach(x=>x.classList.remove("active")); b.classList.add("active");
    }));
  }
  function play(i){
    if(!songs[i]) return;
    current=i; const s=songs[i];
    audio.src=s.url; audio.playbackRate=speed;
    $("nowTitle").textContent=s.title; $("nowArtist").textContent=s.artist; $("playerCover").textContent="♫";
    state.recent=[s.id,...state.recent.filter(x=>x!==s.id)].slice(0,12); saveState(); render();
    audio.play().catch(()=>toast("برای پخش، دکمه ▶ را بزن"));
  }
  function togglePlay(){
    if(current<0){ if(songs.length) play(0); else requestMusicAccess(); return; }
    if(audio.paused) audio.play().catch(()=>{}); else audio.pause();
  }
  function next(){
    if(!songs.length)return;
    if(repeat && current>=0){ audio.currentTime=0; audio.play().catch(()=>{}); return; }
    let n=shuffle?Math.floor(Math.random()*songs.length):(current+1)%songs.length;
    if(!shuffle && current===songs.length-1){audio.pause();return;}
    play(n);
  }
  function prev(){if(!songs.length)return;if(audio.currentTime>3){audio.currentTime=0;return;}play((current-1+songs.length)%songs.length);}
  function toggleFav(i){const id=songs[i]?.id;if(!id)return;state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];saveState();render();}
  function requestMusicAccess(){ if(fileInput) fileInput.click(); }
  function showQueue(){
    const items=songs.map((s,i)=>`${i+1}. ${s.title} — ${s.artist}`).join("\n");
    toast(songs.length?`صف پخش: ${songs.length} آهنگ`:`صف پخش خالی است`);
    if($("queuePanel")) $("queuePanel").classList.toggle("hidden");
    if($("queueList")) $("queueList").textContent=items||"هنوز آهنگی اضافه نشده است.";
  }
  function openPlaylistDialog(){
    const d=$("playlistDialog"); if(!d){toast("ساخت پلی‌لیست در دسترس نیست");return;}
    $("playlistName").value=""; if(typeof d.showModal==="function") d.showModal(); else d.setAttribute("open","");
  }
  function createPlaylist(){
    const name=$("playlistName")?.value.trim(); if(!name){toast("نام پلی‌لیست را وارد کن");return;}
    state.playlists[name]=state.playlists[name]||[]; saveState(); renderPlaylists(); toast("پلی‌لیست ساخته شد");
  }
  function renderPlaylists(){
    const el=$("playlistView"); if(!el)return;
    const names=Object.keys(state.playlists);
    el.innerHTML=names.length?names.map(n=>`<div class="song"><div class="mini">▰</div><div class="info"><b>${esc(n)}</b><small>${state.playlists[n].length} آهنگ</small></div></div>`).join(""):"<div class=\"empty\">هنوز پلی‌لیستی ساخته نشده است.</div>";
  }

  fileInput?.addEventListener("change",async e=>{
    const files=[...e.target.files]; let added=0;
    for(const file of files){if(file.type.startsWith("audio/")||/\.(mp3|m4a|wav|ogg|aac|flac|opus)$/i.test(file.name)){if(addSongFromFile(file,true))added++;}}
    e.target.value=""; render(); toast(added?`${added} آهنگ به کتابخانه اضافه شد`:"آهنگی انتخاب نشد");
  });
  ["musicAccess","heroAccess","libraryImport"].forEach(id=>$(id)?.addEventListener("click",requestMusicAccess));
  $("clearRecent")?.addEventListener("click",()=>{state.recent=[];saveState();render();toast("اخیراً پخش‌شده پاک شد")});
  $("playBtn")?.addEventListener("click",togglePlay); $("nextBtn")?.addEventListener("click",next); $("prevBtn")?.addEventListener("click",prev);
  $("shuffleBtn")?.addEventListener("click",()=>{shuffle=!shuffle;$("shuffleBtn").classList.toggle("active",shuffle);toast(shuffle?"پخش تصادفی روشن شد":"پخش تصادفی خاموش شد")});
  $("repeatBtn")?.addEventListener("click",()=>{repeat=!repeat;$("repeatBtn").classList.toggle("active",repeat);toast(repeat?"تکرار روشن شد":"تکرار خاموش شد")});
  $("favBtn")?.addEventListener("click",()=>current>=0&&toggleFav(current));
  $("queueBtn")?.addEventListener("click",showQueue);
  $("expandBtn")?.addEventListener("click",()=>$("player")?.classList.toggle("expanded"));
  $("volume")?.addEventListener("input",e=>audio.volume=+e.target.value);
  $("speedBtn")?.addEventListener("click",()=>{speed=speed===1?1.25:speed===1.25?1.5:speed===1.5?2:1;audio.playbackRate=speed;$("speedBtn").textContent=speed+"×"});
  $("seek")?.addEventListener("input",e=>{if(audio.duration)audio.currentTime=(+e.target.value/100)*audio.duration});
  $("searchBox")?.addEventListener("input",render); $("clearSearch")?.addEventListener("click",()=>{$("searchBox").value="";render()});
  audio.addEventListener("timeupdate",()=>{$("currentTime").textContent=fmt(audio.currentTime);$("duration").textContent=fmt(audio.duration);$("seek").value=audio.duration?(audio.currentTime/audio.duration)*100:0});
  audio.addEventListener("play",()=>$("playBtn").textContent="❚❚"); audio.addEventListener("pause",()=>$("playBtn").textContent="▶"); audio.addEventListener("ended",next);
  document.querySelectorAll(".nav").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));btn.classList.add("active");$(btn.dataset.page)?.classList.add("active")}));
  document.querySelectorAll("#libraryTabs button").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll("#libraryTabs button").forEach(x=>x.classList.remove("active"));btn.classList.add("active");if(btn.dataset.tab==="favorites")renderSongs($("librarySongs"),songs.filter(s=>state.favorites.includes(s.id)));else if(btn.dataset.tab==="songs")renderSongs($("librarySongs"),songs);else {renderPlaylists();$("librarySongs").innerHTML="";$("playlistView")?.classList.remove("hidden");}}));
  $("playlistDialog")?.querySelector("form")?.addEventListener("submit",e=>{if(e.submitter?.value==="ok"){e.preventDefault();createPlaylist();$("playlistDialog").close();}});
  render(); renderPlaylists(); loadSavedSongs();
})();
