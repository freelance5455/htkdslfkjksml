#!/bin/bash
# Krytex Stable 20-04-26
# Todos com 2>/dev/null || true

echo "Aplicando Krytex Stable..."

setprop ro.input.noresample 1 2>/dev/null || true
setprop windowsmgr.max_events_per_sec 300 2>/dev/null || true
setprop view.touch_slop 1 2>/dev/null || true
setprop ro.min_pointer_dur 0 2>/dev/null || true
setprop touch.distance.scale 0 2>/dev/null || true
setprop view.scroll_friction 10 2>/dev/null || true
setprop ro.min.fling_velocity 160 2>/dev/null || true
setprop ro.max.fling_velocity 25000 2>/dev/null || true
setprop debug.input.enable_game_mode 1 2>/dev/null || true
setprop persist.vendor.touch.game_mode 1 2>/dev/null || true
setprop ro.vendor.touch_sensitivity 1 2>/dev/null || true
setprop persist.sys.miui.touch_catch_miss 0 2>/dev/null || true

settings put system pointer_speed 7 2>/dev/null || true
settings put secure long_press_timeout 130 2>/dev/null || true
settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true

echo "Krytex Stable aplicado!"
