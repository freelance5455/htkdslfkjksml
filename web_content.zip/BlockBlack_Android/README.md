# Block Black Android App

Android Studio project based on Block Black V12 + Share.
Version 1.0.27 / versionCode 27.

Open this folder in Android Studio and use Build > Build APK(s).
