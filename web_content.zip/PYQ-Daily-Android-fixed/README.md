# PYQ Daily — Android wrapper (fixed)

This version fixes the `net::ERR_HTTP_RESPONSE_CODE_FAILURE` / `appassets.androidplatform.net/web/index.html` problem by explicitly serving the bundled web files at the same secure appassets URL used by Android WebView asset wrappers.

The complete PYQ Daily web app is bundled locally under `app/src/main/assets/web/`, so the app does not depend on a hosted copy of the site.

Build with Android Studio or any Android Gradle cloud builder.

Package: `com.pyqdaily.app`
Version: `1.1`
Min Android: 6.0 (API 23)
