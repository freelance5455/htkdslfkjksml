FF Tournament Arena — Complete ZIP Demo

Includes Login/Register, User Panel, Easypaisa Deposit (03269879448), transaction ID submission, deposit history, admin approve/reject, PKR tournaments, join/payment requests, leaderboard, referral code, room ID/password management.

Demo admin login: admin@ffarena.local
Password: arena123

IMPORTANT: This is a local browser demo using localStorage. It is not a real online multi-user app; data is not shared between devices. Easypaisa payments are manual and must be verified by the admin. Do not use real payments until a secure backend is built.
