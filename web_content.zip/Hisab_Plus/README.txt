HISAB+ - EXPENSE TRACKER & CALCULATOR

Features:
- Expense name, amount, category, date
- Today's, current month's and all-time totals
- Search and month filter
- Delete individual expenses or clear all
- Export records as CSV
- Basic calculator: +, -, x, divide, percent
- Mobile-friendly, offline-friendly single-page app

TEST:
Extract the ZIP and open index.html in a browser.

APK NOTE:
This ZIP is a simple HTML web app, not a native Android Studio project. Upload it only to a converter that accepts plain HTML/PWA ZIP projects. Some ZIP-to-APK sites require their own format and may not work with this ZIP.

DATA:
Expense entries are stored locally in the browser on the same device. Clearing browser/app data can erase them. Use CSV Export for a backup. No bank sync, login, or cloud backup is included.
