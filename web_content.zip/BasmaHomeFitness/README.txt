BASMA HOME FITNESS
Files: index.html, assets/basma-logo.png (provided logo unchanged), manifest.webmanifest.

Features:
- Basma profile: height, weight, goal, training level, optional birthday and notes.
- InBody history: weight, body-fat %, fat mass, skeletal muscle mass (SMM), total body water, BMI, visceral fat, score, waist/hip measurements and notes.
- Beginner home workout plan for 3 days weekly.
- Add workout plans, days and exercises; each exercise has sets, reps, resistance/weight and notes.
- Print workout sheets and export/import JSON backups.
- Local browser storage, no external libraries.

Use: extract ZIP and open index.html in a modern browser. This is an offline-friendly web app prototype, not an Android APK. Data is saved in this browser on this device. Export backups regularly because clearing browser data may delete records. Stop exercises that cause pain; adapt the example program to fitness level and any medical restrictions.
