
/* AsimAI enhancement interactions: additive and isolated from existing app modules. */
(() => {
  'use strict';
  const menu = document.getElementById('asimUploadMenu');
  const trigger = document.getElementById('attachmentBtn');
  const input = document.getElementById('chatInput');
  const fileInput = document.getElementById('fileInput');
  if (!menu || !trigger || !input) return;

  const taskPrompts = {
    image: ' [TASK: IMAGE ANALYSIS] Analyze the image I attach. Describe what is visible, extract relevant text, explain the context, and answer my question about it: ',
    code: ' [TASK: SOFTWARE ENGINEERING] Act as a senior software engineer. Build or debug the requested solution, inspect edge cases, preserve existing functionality, and provide complete runnable code with clear file names: ',
    document: ' [TASK: DOCUMENT ANALYSIS] Read the attached document carefully. Summarize its key points, extract important facts, explain difficult sections, and answer questions grounded in the document: ',
    research: ' [TASK: RESEARCH] Research this topic thoroughly. Separate verified facts from uncertainty, compare credible perspectives, and provide sources when web search is enabled: ',
    data: ' [TASK: DATA ANALYSIS] Analyze the attached data. Explain its structure, identify trends and anomalies, perform relevant calculations, and present useful conclusions: ',
    creative: ' [TASK: CREATIVE STUDIO] Help me create polished, original content. First understand the goal and audience, then produce a complete, well-structured result: '
  };

  function closeMenu() {
    menu.classList.add('hidden');
    trigger.setAttribute('aria-expanded', 'false');
  }
  menu.addEventListener('click', (event) => {
    const button = event.target.closest('[data-ai-task]');
    if (!button) return;
    const task = button.dataset.aiTask;
    closeMenu();
    if (task === 'browse') {
      fileInput?.click();
      return;
    }
    const prompt = taskPrompts[task];
    if (!prompt) return;
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    const before = input.value.slice(0, start);
    const after = input.value.slice(end);
    input.value = before + prompt + after;
    input.focus();
    const caret = before.length + prompt.length;
    input.setSelectionRange(caret, caret);
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
  document.addEventListener('click', (event) => {
    if (!menu.classList.contains('hidden') && !menu.contains(event.target) && !trigger.contains(event.target)) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !menu.classList.contains('hidden')) closeMenu();
  });
})();
