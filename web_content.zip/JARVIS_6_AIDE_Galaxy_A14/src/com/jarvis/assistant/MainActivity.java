package com.jarvis.assistant;
import android.Manifest;import android.app.Activity;import android.os.Bundle;import android.content.Intent;import android.content.ActivityNotFoundException;import android.content.pm.PackageManager;import android.net.Uri;import android.provider.Settings;import android.speech.RecognizerIntent;import android.speech.tts.TextToSpeech;import android.webkit.WebView;import android.webkit.WebViewClient;import android.webkit.JavascriptInterface;import android.webkit.WebChromeClient;import java.util.ArrayList;import java.util.Locale;
public class MainActivity extends Activity {
 WebView web;TextToSpeech tts;static final int SPEECH=12;static final int MIC=13;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){Uri u=request.getUrl();if("file".equals(u.getScheme())&&"/android_asset/index.html".equals(u.getPath()))return false;openUrl(u.toString());return true;}});web.setWebChromeClient(new WebChromeClient());web.addJavascriptInterface(new Bridge(),"Android");setContentView(web);web.loadUrl("file:///android_asset/index.html");tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("pt","BR"));});}
 void js(String fn,String value){runOnUiThread(()->web.evaluateJavascript(fn+"("+org.json.JSONObject.quote(value)+")",null));}
 void speak(String text){if(tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis");}
 void listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);return;}try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Fale com a JARVIS");startActivityForResult(i,SPEECH);}catch(Exception e){js("failed","Reconhecimento de voz indisponível neste aparelho.");}}
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==14&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED){startForegroundService(new Intent(this,HotwordService.class).setAction(HotwordService.START));return;}if(request==MIC&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)listen();else js("failed","Permissão do microfone necessária.");}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==SPEECH){if(result==RESULT_OK&&data!=null){ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(words!=null&&!words.isEmpty())js("heard",words.get(0));}else js("failed","Não ouvi o comando. Tente novamente.");}}
 void open(String pkg,String fallback){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){startActivity(i);return;}}catch(Exception ignored){}openUrl(fallback);}
 void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){js("say","Não foi possível abrir o endereço.");}}
 void command(String raw){String c=java.text.Normalizer.normalize(raw.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").trim();
 if(c.startsWith("ei jarvis"))c=c.substring(9).trim();
 if(c.contains("proximo")||c.contains("avancar")||c.contains("passar video")||c.contains("rolar para cima")){gesture(true);return;}
 if(c.contains("anterior")||c.contains("voltar video")||c.contains("rolar para baixo")){gesture(false);return;}
 if(c.contains("pausar")||c.contains("reproduzir video")){if(JarvisAccessibilityService.instance!=null){JarvisAccessibilityService.instance.tap();js("say","Toque enviado.");}else js("say","Ative a acessibilidade da JARVIS nas configurações.");return;}
 if(c.contains("abrir youtube")||c.contains("abre youtube")){js("say","Abrindo YouTube.");open("com.google.android.youtube","https://youtube.com");return;}
 if(c.contains("abrir instagram")||c.contains("abre instagram")){js("say","Abrindo Instagram.");open("com.instagram.android","https://instagram.com");return;}
 if(c.contains("abrir tiktok")||c.contains("abre tiktok")){js("say","Abrindo TikTok.");open("com.zhiliaoapp.musically","https://tiktok.com");return;}
 if(c.contains("abrir whatsapp")||c.contains("abre whatsapp")){js("say","Abrindo WhatsApp.");open("com.whatsapp","https://wa.me/");return;}
 if(c.contains("abrir spotify")||c.contains("abre spotify")){js("say","Abrindo Spotify.");open("com.spotify.music","https://open.spotify.com");return;}
 if(c.startsWith("pesquis")||c.startsWith("busc")){String q=c.replaceFirst("^(pesquisar|pesquise|pesquisa|buscar|busque|busca)(\\s+(sobre|por))?\\s*","");if(q.isEmpty()){js("say","Diga o que deseja pesquisar.");return;}js("say","Pesquisando "+q);openUrl("https://www.google.com/search?q="+Uri.encode(q));return;}
 if(c.startsWith("abrir site ")||c.startsWith("entrar no site ")){String host=c.replaceFirst("^(abrir site|entrar no site)\\s+","").replaceAll("\\s+","");if(!host.contains("."))host+=".com";if(host.matches("[a-z0-9.-]+\\.[a-z]{2,}")){js("say","Abrindo site.");openUrl("https://"+host);}else js("say","Endereço inválido.");return;}
 if(c.contains("hora")){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",new Locale("pt","BR"));js("say","Agora são "+f.format(new java.util.Date()));return;}
 askAI(raw);}
 void gesture(boolean next){JarvisAccessibilityService a=JarvisAccessibilityService.instance;if(a==null){js("say","Ative o serviço de acessibilidade JARVIS nas configurações do Android.");return;}boolean ok=a.swipe(next);js("say",ok?(next?"Avançando vídeo.":"Voltando vídeo."):"Não foi possível executar o gesto.");}
 void askAI(String question){
  String key=getPreferences(0).getString("ai_api_key","");
  if(key.isEmpty()){js("say","Configure sua chave de API para conversar com a inteligência artificial.");return;}
  js("say","Consultando inteligência artificial...");
  new Thread(()->{
   java.net.HttpURLConnection conn=null;
   try{
    java.net.URL endpoint=new java.net.URL("https://api.openai.com/v1/responses");
    conn=(java.net.HttpURLConnection)endpoint.openConnection();conn.setRequestMethod("POST");conn.setConnectTimeout(12000);conn.setReadTimeout(30000);conn.setDoOutput(true);
    conn.setRequestProperty("Authorization","Bearer "+key);conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
    org.json.JSONObject payload=new org.json.JSONObject();payload.put("model","gpt-4.1-mini");payload.put("instructions","Você é JARVIS, uma assistente útil. Responda em português brasileiro de forma breve, clara e natural. Não afirme ter realizado ações no celular.");payload.put("input",question);
    try(java.io.OutputStream out=conn.getOutputStream()){out.write(payload.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    if(conn.getResponseCode()<200||conn.getResponseCode()>=300)throw new Exception("API retornou HTTP "+conn.getResponseCode());
    StringBuilder body=new StringBuilder();try(java.io.BufferedReader reader=new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream(),java.nio.charset.StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null)body.append(line);}
    org.json.JSONObject result=new org.json.JSONObject(body.toString());StringBuilder answer=new StringBuilder();org.json.JSONArray output=result.optJSONArray("output");
    if(output!=null)for(int i=0;i<output.length();i++){org.json.JSONArray content=output.getJSONObject(i).optJSONArray("content");if(content!=null)for(int k=0;k<content.length();k++){org.json.JSONObject part=content.getJSONObject(k);if("output_text".equals(part.optString("type")))answer.append(part.optString("text"));}}
    String response=answer.length()>0?answer.toString():"Não consegui interpretar a resposta da IA.";
    js("say",response);runOnUiThread(()->speak(response));
   }catch(Exception e){js("say","Não consegui consultar a IA. Verifique a internet, a chave e os créditos da API.");}
   finally{if(conn!=null)conn.disconnect();}
  }).start();
 }
 class Bridge{
  @JavascriptInterface public void saveAiKey(String key){runOnUiThread(()->{getPreferences(0).edit().putString("ai_api_key",key.trim()).apply();js("say",key.trim().isEmpty()?"Chave de IA apagada.":"Chave de IA salva neste aparelho.");});}
  @JavascriptInterface public void askAI(String question){runOnUiThread(()->MainActivity.this.askAI(question));}
@JavascriptInterface public void startHotword(){runOnUiThread(()->{if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},14);return;}try{startForegroundService(new Intent(MainActivity.this,HotwordService.class).setAction(HotwordService.START));js("say","Escuta Ei Jarvis ativada.");}catch(Exception e){js("failed","Abra o aplicativo e tente novamente.");}});}@JavascriptInterface public void stopHotword(){runOnUiThread(()->{stopService(new Intent(MainActivity.this,HotwordService.class));js("say","Escuta desativada.");});}@JavascriptInterface public void listen(){runOnUiThread(()->MainActivity.this.listen());}@JavascriptInterface public void speak(String s){runOnUiThread(()->MainActivity.this.speak(s));}@JavascriptInterface public void command(String s){runOnUiThread(()->MainActivity.this.command(s));}@JavascriptInterface public void accessibilitySettings(){runOnUiThread(()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));}}
 @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}web.destroy();super.onDestroy();}
}
