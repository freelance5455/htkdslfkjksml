package com.jarvis.assistant;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.util.DisplayMetrics;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.view.View;

public class JarvisAccessibilityService extends AccessibilityService {
 static JarvisAccessibilityService instance;
 private WindowManager window;private View floatingButton;
 @Override public void onServiceConnected(){instance=this;showFloatingButton();}
 private void showFloatingButton(){
  if(floatingButton!=null)return;
  window=(WindowManager)getSystemService(WINDOW_SERVICE);
  TextView button=new TextView(this);button.setText("🎙");button.setTextSize(27);button.setTextColor(Color.WHITE);button.setGravity(Gravity.CENTER);
  GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(8,44,65));bg.setCornerRadius(100);bg.setStroke(3,Color.CYAN);button.setBackground(bg);
  WindowManager.LayoutParams p=new WindowManager.LayoutParams(64*(int)getResources().getDisplayMetrics().density,64*(int)getResources().getDisplayMetrics().density,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
  p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;p.x=12;p.y=0;
  button.setOnClickListener(v->{Intent i=new Intent(this,VoiceCommandActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});
  try{window.addView(button,p);floatingButton=button;}catch(Exception ignored){}
 }

 @Override public void onAccessibilityEvent(AccessibilityEvent event){}
 @Override public void onInterrupt(){}
 @Override public void onDestroy(){if(window!=null&&floatingButton!=null){window.removeView(floatingButton);floatingButton=null;}instance=null;super.onDestroy();}
 public boolean swipe(boolean next){DisplayMetrics m=getResources().getDisplayMetrics();float x=m.widthPixels*.5f;float y1=m.heightPixels*(next?.78f:.28f),y2=m.heightPixels*(next?.28f:.78f);Path p=new Path();p.moveTo(x,y1);p.lineTo(x,y2);GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,380);return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(),null,null);}
 public boolean tap(){DisplayMetrics m=getResources().getDisplayMetrics();float x=m.widthPixels*.5f,y=m.heightPixels*.5f;Path p=new Path();p.moveTo(x,y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,80);return dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null);}
}
