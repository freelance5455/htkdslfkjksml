package com.jarvis.assistant;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.net.Uri;
import java.text.Normalizer;
import java.util.*;

/** Opt-in foreground speech recognition prototype. Not a dedicated low-power hotword engine. */
public class HotwordService extends Service implements RecognitionListener {
 public static final String START="com.jarvis.assistant.START_HOTWORD", STOP="com.jarvis.assistant.STOP_HOTWORD";
 private SpeechRecognizer recognizer; private TextToSpeech tts; private Handler handler; private boolean active=false, awaiting=false;
 private int failures=0; private boolean speaking=false; private boolean listening=false;
 private static final String CHANNEL="jarvis_microphone";
 @Override public void onCreate(){super.onCreate();handler=new Handler(Looper.getMainLooper());tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("pt","BR"));});NotificationChannel ch=new NotificationChannel(CHANNEL,"JARVIS - microfone",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(ch);}
 @Override public int onStartCommand(Intent intent,int flags,int startId){if(intent!=null&&STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){stopSelf();return START_NOT_STICKY;}active=true;Intent stop=new Intent(this,HotwordService.class).setAction(STOP);PendingIntent pi=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("JARVIS ouvindo").setContentText("Diga Ei Jarvis. Toque em Parar para desligar.").addAction(new Notification.Action.Builder(null,"Parar",pi).build()).setOngoing(true).build();if(Build.VERSION.SDK_INT>=29)startForeground(42,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);else startForeground(42,n);startListening();return START_NOT_STICKY;}
 private void startListening(){if(!active||speaking||listening)return;try{if(recognizer==null){recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(this);}Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);recognizer.startListening(i);listening=true;}catch(Exception e){retry();}}
 private void retry(){if(!active)return;listening=false;handler.removeCallbacksAndMessages(null);long delay=Math.min(12000,1200L*(1L<<Math.min(failures,3)));handler.postDelayed(()->{if(recognizer!=null){recognizer.destroy();recognizer=null;}startListening();},delay);}
 private String norm(String s){return Normalizer.normalize(s.toLowerCase(Locale.ROOT),Normalizer.Form.NFD).replaceAll("\\p{M}","").trim();}
 private void parse(String raw){String s=norm(raw);int at=s.indexOf("ei jarvis");if(at<0)at=s.indexOf("hey jarvis");if(at>=0){awaiting=true;String rest=s.substring(at+(s.startsWith("hey jarvis",at)?10:9)).trim();if(!rest.isEmpty()){awaiting=false;execute(rest);}else speak("Pode falar.");return;}if(awaiting&&!s.isEmpty()){awaiting=false;execute(s);}}
 private void speak(String s){if(tts!=null){speaking=true;tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis-hotword");handler.postDelayed(()->{speaking=false;if(active&&!listening)startListening();},Math.max(1100,s.length()*85L));}}
 private void open(String pkg,String url){Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null)i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(i);}catch(Exception e){speak("Abra o aplicativo manualmente.");}}
 private void execute(String s){JarvisAccessibilityService a=JarvisAccessibilityService.instance;
 if(s.contains("parar de ouvir")||s.contains("desligar jarvis")){speak("Desativando escuta");stopSelf();return;}
 if(s.contains("proximo")||s.contains("avancar")||s.contains("passar video")){speak(a!=null&&a.swipe(true)?"Próximo vídeo":"Ative a acessibilidade da JARVIS");return;}
 if(s.contains("anterior")||s.contains("voltar video")){speak(a!=null&&a.swipe(false)?"Vídeo anterior":"Ative a acessibilidade da JARVIS");return;}
 if(s.contains("pausar")||s.contains("reproduzir")){speak(a!=null&&a.tap()?"Pronto":"Ative a acessibilidade da JARVIS");return;}
 if(s.contains("spotify")){open("com.spotify.music","https://open.spotify.com");return;}
 if(s.contains("instagram")){open("com.instagram.android","https://instagram.com");return;}
 if(s.contains("tiktok")){open("com.zhiliaoapp.musically","https://tiktok.com");return;}
 if(s.contains("youtube")){open("com.google.android.youtube","https://youtube.com");return;}
 if(s.contains("whatsapp")){open("com.whatsapp","https://wa.me/");return;}
 if(s.contains("que horas")||s.equals("horas")){speak("Agora são "+new java.text.SimpleDateFormat("HH:mm",new Locale("pt","BR")).format(new Date()));return;}
 if(s.startsWith("pesquis")||s.startsWith("busc")){String q=s.replaceFirst("^(pesquisar|pesquise|pesquisa|buscar|busque|busca)(\\s+(sobre|por))?\\s*","");if(!q.isEmpty()){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q)));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(i);}catch(Exception e){speak("Não foi possível abrir a pesquisa");}}return;}
 if(s.startsWith("abrir site ")||s.startsWith("entrar no site ")){String host=s.replaceFirst("^(abrir site|entrar no site)\\s+","").replaceAll("\\s+","");if(!host.contains("."))host+=".com";if(host.matches("[a-z0-9.-]+\\.[a-z]{2,}")){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://"+host));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(i);}catch(Exception e){speak("Não foi possível abrir o site");}}else speak("Endereço inválido");return;}
 speak("Comando não reconhecido");}
 @Override public void onResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);listening=false;if(r!=null&&!r.isEmpty()){failures=0;parse(r.get(0));}retry();}
 @Override public void onPartialResults(Bundle b){} @Override public void onError(int error){if(error==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS){stopSelf();return;}listening=false;failures++;retry();}
 @Override public void onReadyForSpeech(Bundle b){} @Override public void onBeginningOfSpeech(){} @Override public void onRmsChanged(float rms){} @Override public void onBufferReceived(byte[] b){} @Override public void onEndOfSpeech(){} @Override public void onEvent(int type,Bundle b){}
 @Override public void onDestroy(){active=false;handler.removeCallbacksAndMessages(null);if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
