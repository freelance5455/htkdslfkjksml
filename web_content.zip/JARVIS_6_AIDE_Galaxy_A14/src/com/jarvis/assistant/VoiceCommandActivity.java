package com.jarvis.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.net.Uri;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

/** Short-lived voice interface launched by the user's explicit overlay tap. */
public class VoiceCommandActivity extends Activity {
 private static final int SPEECH=31, MIC=32;
 private TextToSpeech tts;
 @Override public void onCreate(Bundle state){super.onCreate(state);tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("pt","BR"));});listen();}
 private void listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);return;}try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"JARVIS: qual é o comando?");startActivityForResult(i,SPEECH);}catch(Exception e){Toast.makeText(this,"Reconhecimento de voz indisponível",Toast.LENGTH_LONG).show();finish();}}
 @Override public void onRequestPermissionsResult(int req,String[] p,int[] r){super.onRequestPermissionsResult(req,p,r);if(req==MIC&&r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)listen();else finish();}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==SPEECH&&result==RESULT_OK&&data!=null){ArrayList<String> list=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(list!=null&&!list.isEmpty())command(list.get(0));}finish();}
 private void say(String message){Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();if(tts!=null)tts.speak(message,TextToSpeech.QUEUE_ADD,null,"jarvis-overlay");}
 private void url(String value){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(value)));}catch(Exception e){say("Não consegui abrir o endereço.");}}
 private void app(String pkg,String fallback){Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);else url(fallback);}
 private void command(String raw){String c=java.text.Normalizer.normalize(raw.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").trim();JarvisAccessibilityService a=JarvisAccessibilityService.instance;
 if(c.contains("proximo")||c.contains("avancar")||c.contains("passar video")){if(a!=null&&a.swipe(true))say("Próximo vídeo");else say("Ative a acessibilidade da JARVIS");return;}
 if(c.contains("anterior")||c.contains("voltar video")){if(a!=null&&a.swipe(false))say("Vídeo anterior");else say("Ative a acessibilidade da JARVIS");return;}
 if(c.contains("pausar")||c.contains("reproduzir")){if(a!=null&&a.tap())say("Toque enviado");else say("Ative a acessibilidade da JARVIS");return;}
 if(c.contains("instagram")){say("Abrindo Instagram");app("com.instagram.android","https://instagram.com");return;}
 if(c.contains("tiktok")){say("Abrindo TikTok");app("com.zhiliaoapp.musically","https://tiktok.com");return;}
 if(c.contains("youtube")){say("Abrindo YouTube");app("com.google.android.youtube","https://youtube.com");return;}
 if(c.contains("whatsapp")){say("Abrindo WhatsApp");app("com.whatsapp","https://wa.me/");return;}
 if(c.contains("spotify")){say("Abrindo Spotify");app("com.spotify.music","https://open.spotify.com");return;}
 if(c.startsWith("pesquis")||c.startsWith("busc")){String q=c.replaceFirst("^(pesquisar|pesquise|pesquisa|buscar|busque|busca)(\\s+(sobre|por))?\\s*","");if(!q.isEmpty()){say("Pesquisando "+q);url("https://www.google.com/search?q="+Uri.encode(q));}else say("O que deseja pesquisar?");return;}
 if(c.startsWith("abrir site ")||c.startsWith("entrar no site ")){String host=c.replaceFirst("^(abrir site|entrar no site)\\s+","").replaceAll("\\s+","");if(!host.contains("."))host+=".com";if(host.matches("[a-z0-9.-]+\\.[a-z]{2,}")){say("Abrindo site");url("https://"+host);}else say("Endereço inválido");return;}
 say("Comando não reconhecido");}
 @Override protected void onDestroy(){if(tts!=null){tts.shutdown();}super.onDestroy();}
}
