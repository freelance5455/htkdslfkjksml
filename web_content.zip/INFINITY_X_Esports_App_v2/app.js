import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, doc, getDoc, updateDoc, deleteDoc, query, where, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

/* Replace with your Firebase Web App config. Never paste a service-account key here. */
const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};
const $ = id => document.getElementById(id);
const configured = firebaseConfig.apiKey.startsWith("AIza") && !firebaseConfig.projectId.startsWith("PASTE_");
let app, auth, db, storage, currentUser=null, isAdmin=false, myPlayer=null;
let players=[], scrims=[], tournaments=[], matches=[], attendance=[], notices=[], awards=[], funds=[], applications=[];
const placeholder = "data:image/svg+xml;charset=UTF-8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><rect width="100%" height="100%" fill="#202027"/><text x="50%" y="54%" fill="#f02b42" font-size="30" text-anchor="middle" font-family="Arial">IX</text></svg>');
const escapeHTML = (v="") => String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dateText = v => {if(!v)return "Date not set";try{return new Date(v+"T00:00:00").toLocaleDateString(undefined,{year:"numeric",month:"short",day:"numeric"});}catch{return v;}};
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),3300);}
function message(id,msg,good=false){const e=$(id);if(e){e.textContent=msg;e.style.color=good?"#54d69a":"#ff9ba6";}}
function errText(e){if(e?.code==="permission-denied"||e?.code==="firestore/permission-denied")return "Permission denied. Check Firebase rules and account permissions.";if(e?.code==="auth/invalid-credential")return "Incorrect email or password.";if(e?.code==="auth/too-many-requests")return "Too many attempts. Try again later.";return e?.message||"Something went wrong.";}
function needConfig(){if(!configured){toast("Add your Firebase config in app.js first.");return false;}return true;}
if(configured){
 app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);storage=getStorage(app);
 onAuthStateChanged(auth,async user=>{
   currentUser=user;isAdmin=false;myPlayer=null;
   if(user){
     try{const adminSnap=await getDoc(doc(db,"admins",user.uid));isAdmin=adminSnap.exists();}catch(e){console.error(e);}
     if(!isAdmin){try{const pSnap=await getDocs(query(collection(db,"players"),where("accountUid","==",user.uid)));if(!pSnap.empty)myPlayer={id:pSnap.docs[0].id,...pSnap.docs[0].data()};}catch(e){console.error(e);}}
   }
   $("sessionLabel").textContent=isAdmin?"ADMIN SESSION":myPlayer?"PLAYER SESSION":"PUBLIC VIEW";
   $("loginOpen").textContent=isAdmin?"Open Admin Panel":user&&myPlayer?"My Profile / Logout":"Player / Admin Login";
   $("myProfile").classList.toggle("hidden",!myPlayer);
   if(myPlayer)renderMyProfile();
   if(isAdmin)await refreshAll();else await loadPublic();
 });
}else{
 ["playersGrid","performanceGrid","scrimsGrid","tournamentsGrid","matchesList","attendanceGrid","noticesGrid","achievementsGrid"].forEach(id=>$(id).innerHTML='<div class="empty">Firebase setup required. Follow README.md to connect the online database.</div>');
 $("rankingBody").innerHTML='<tr><td colspan="6" class="empty">Connect Firebase to load rankings.</td></tr>';
}
$("loginOpen").addEventListener("click",()=>{
 if(isAdmin){$("adminModal").classList.remove("hidden");return;}
 if(currentUser&&myPlayer){renderMyProfile();$("myProfile").scrollIntoView({behavior:"smooth"});return;}
 if(currentUser&&!isAdmin){signOut(auth);return;}
 $("authModal").classList.remove("hidden");
});
$("closeAuth").addEventListener("click",()=>$("authModal").classList.add("hidden"));
$("closeAdmin").addEventListener("click",()=>$("adminModal").classList.add("hidden"));
$("authModal").addEventListener("click",e=>{if(e.target===$("authModal"))$("authModal").classList.add("hidden");});
$("adminModal").addEventListener("click",e=>{if(e.target===$("adminModal"))$("adminModal").classList.add("hidden");});
$("loginForm").addEventListener("submit",async e=>{e.preventDefault();if(!needConfig())return;try{await signInWithEmailAndPassword(auth,$("loginEmail").value.trim(),$("loginPassword").value);$("authModal").classList.add("hidden");message("authMessage","");}catch(err){message("authMessage",errText(err));}});
$("logoutBtn").addEventListener("click",async()=>{await signOut(auth);$("adminModal").classList.add("hidden");toast("Signed out");});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".admin-form").forEach(f=>f.classList.toggle("hidden",f.id!==b.dataset.tab));}));
async function readAll(name){try{const s=await getDocs(collection(db,name));return s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>String(b.date||b.createdAt?.seconds||"").localeCompare(String(a.date||a.createdAt?.seconds||"")));}catch(e){console.error(name,e);return [];}}
async function loadPublic(){if(!db)return;players=(await readAll("players")).filter(p=>p.active!==false);scrims=await readAll("scrims");tournaments=await readAll("tournaments");matches=await readAll("matches");notices=await readAll("notices");awards=await readAll("awards");attendance=await readAll("attendance");renderPublic();}
async function refreshAll(){await loadPublic();if(!isAdmin)return;funds=await readAll("funds");applications=await readAll("applications");renderAdmin();}
function renderPublic(){
 $("playerCount").textContent=players.length;$("tournamentCount").textContent=tournaments.length;$("matchCount").textContent=matches.length;$("winCount").textContent=matches.filter(m=>(m.result||"").toUpperCase()==="WIN").length;
 const sorted=[...players].sort((a,b)=>(+b.points||0)-(+a.points||0)||(+b.kills||0)-(+a.kills||0));
 $("playersGrid").innerHTML=players.length?["Main Squad","Substitute Squad","Academy"].map(group=>{const list=players.filter(p=>(p.squad||"Main Squad")===group);return list.length?`<div class="group-label">${group}</div>`+list.map(playerCard).join(""):"";}).join(""):'<div class="empty">No players added yet.</div>';
 $("performanceGrid").innerHTML=sorted.slice(0,3).map((p,i)=>`<article class="player-card"><img class="player-photo" src="${escapeHTML(p.photoURL||placeholder)}" alt=""><div class="player-info"><span class="role">RANK #${i+1}</span><h3 style="margin-top:7px">${escapeHTML(p.name)}</h3><div class="mini-stats"><span>Kills <b>${+p.kills||0}</b></span><span>MVP <b>${+p.mvp||0}</b></span><span>Points <b>${+p.points||0}</b></span></div></div></article>`).join("")||'<div class="empty">Player performance will appear here.</div>';
 $("rankingBody").innerHTML=sorted.map((p,i)=>`<tr><td>#${i+1}</td><td>${escapeHTML(p.name)}</td><td>${escapeHTML(p.uid||"—")}</td><td>${+p.kills||0}</td><td>${+p.mvp||0}</td><td>${+p.points||0}</td></tr>`).join("")||'<tr><td colspan="6" class="empty">No ranking data yet.</td></tr>';
 $("scrimsGrid").innerHTML=scrims.map(s=>itemCard(s.title,s.status||"Scheduled",`${dateText(s.date)}${s.time?" · "+s.time:""}`,`${s.opponent||"Opponent TBA"}${s.details?" — "+s.details:""}`)).join("")||'<div class="empty">No scrims scheduled.</div>';
 $("tournamentsGrid").innerHTML=tournaments.map(t=>`<article class="item-card">${t.photoURL?`<img src="${escapeHTML(t.photoURL)}" alt="">`:""}<span class="status ${(t.status||"").toLowerCase()}">${escapeHTML(t.status||"Upcoming")}</span><h3>${escapeHTML(t.name)}</h3><p>${escapeHTML(dateText(t.date))}</p><p>${escapeHTML(t.details||"Details coming soon.")}</p></article>`).join("")||'<div class="empty">No tournaments announced.</div>';
 $("matchesList").innerHTML=matches.map(m=>`<article class="match-card"><div><h3>${escapeHTML(m.opponent||"Match")}</h3><p>${escapeHTML(dateText(m.date))}${m.score?" · "+escapeHTML(m.score):""} · Kills ${+m.kills||0} · Placement ${+m.placement||0}</p></div><strong class="result ${(m.result||"").toUpperCase()==="LOSS"?"loss":""}">${escapeHTML((m.result||"").toUpperCase())}</strong></article>`).join("")||'<div class="empty">No match results published.</div>';
 $("attendanceGrid").innerHTML=attendance.slice(0,8).map(a=>itemCard(a.playerName||"Player",a.status||"Recorded",dateText(a.date),a.notes||"Practice attendance record")).join("")||'<div class="empty">Attendance records will appear here.</div>';
 $("noticesGrid").innerHTML=notices.map(n=>itemCard(n.title,n.priority||"Normal",dateText(n.date||""),n.body||"")).join("")||'<div class="empty">No notices posted.</div>';
 $("achievementsGrid").innerHTML=awards.map(a=>itemCard(a.title,"Award",`${escapeHTML(a.winner||"Team")} · ${dateText(a.date)}`,a.details||"")).join("")||'<div class="empty">Achievements will appear here.</div>';
 if(isAdmin)renderFund();
}
function playerCard(p){return `<article class="player-card"><img class="player-photo" src="${escapeHTML(p.photoURL||placeholder)}" alt=""><div class="player-info"><h3>${escapeHTML(p.name||"Player")}</h3><p class="uid">UID: ${escapeHTML(p.uid||"—")}</p><span class="role">${escapeHTML(p.role||"Player")}</span><div class="mini-stats"><span>Kills <b>${+p.kills||0}</b></span><span>MVP <b>${+p.mvp||0}</b></span><span>Points <b>${+p.points||0}</b></span></div></div></article>`;}
function itemCard(title,badge,meta,body){return `<article class="item-card"><span class="status ${String(badge).toLowerCase()}">${escapeHTML(badge)}</span><h3>${escapeHTML(title||"")}</h3><p>${escapeHTML(meta||"")}</p><p>${escapeHTML(body||"")}</p></article>`;}
function renderMyProfile(){const p=myPlayer;if(!p)return;$("myProfileContent").innerHTML=`<article class="player-card"><img class="player-photo" style="width:100px;height:100px" src="${escapeHTML(p.photoURL||placeholder)}" alt=""><div class="player-info"><h3>${escapeHTML(p.name)}</h3><p class="uid">UID: ${escapeHTML(p.uid||"—")}</p><span class="role">${escapeHTML(p.role||"Player")} · ${escapeHTML(p.squad||"Main Squad")}</span><div class="mini-stats"><span>Kills <b>${+p.kills||0}</b></span><span>MVP <b>${+p.mvp||0}</b></span><span>Matches <b>${+p.matches||0}</b></span><span>Points <b>${+p.points||0}</b></span></div></div></article><p class="muted">Profile stats are managed by the team admin. Contact the admin to correct your details.</p>`;}
async function upload(file,folder){if(!file)return "";if(!file.type.startsWith("image/"))throw Error("Choose an image file.");if(file.size>5*1024*1024)throw Error("Image must be 5 MB or less.");const path=`${folder}/${currentUser.uid}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const r=ref(storage,path);await uploadBytes(r,file,{contentType:file.type});return await getDownloadURL(r);}
function renderAdmin(){
 $("adminIdentity").textContent=currentUser?.email+" · authorized admin";
 $("adminPlayersList").innerHTML=players.map(p=>record(p.name+" · "+p.uid,`<button class="small-btn" data-edit="${p.id}">Edit</button><button class="small-btn danger" data-del="players|${p.id}">Delete</button>`)).join("")||"<p class='muted'>No players.</p>";
 $("adminScrimsList").innerHTML=scrims.map(s=>record(s.title,`<button class="small-btn danger" data-del="scrims|${s.id}">Delete</button>`)).join("");
 $("adminTournamentsList").innerHTML=tournaments.map(t=>record(t.name,`<button class="small-btn danger" data-del="tournaments|${t.id}">Delete</button>`)).join("");
 $("adminMatchesList").innerHTML=matches.map(m=>record(m.opponent+" · "+m.result,`<button class="small-btn danger" data-del="matches|${m.id}">Delete</button>`)).join("");
 $("adminAttendanceList").innerHTML=attendance.map(a=>record((a.playerName||"Player")+" · "+a.status+" · "+a.date,`<button class="small-btn danger" data-del="attendance|${a.id}">Delete</button>`)).join("");
 $("adminNoticesList").innerHTML=notices.map(n=>record(n.title,`<button class="small-btn danger" data-del="notices|${n.id}">Delete</button>`)).join("");
 $("adminAwardsList").innerHTML=awards.map(a=>record(a.title+" · "+a.winner,`<button class="small-btn danger" data-del="awards|${a.id}">Delete</button>`)).join("");
 $("adminApplicationsList").innerHTML=applications.map(a=>record(`${a.name} · ${a.uid} · ${a.role} · ${a.contact||"no contact"}`,`<button class="small-btn" data-approve="${a.id}">Mark reviewed</button><button class="small-btn danger" data-del="applications|${a.id}">Delete</button>`)).join("")||"<p class='muted'>No applications.</p>";
 $("attPlayer").innerHTML=players.map(p=>`<option value="${p.id}">${escapeHTML(p.name)} (${escapeHTML(p.uid)})</option>`).join("");
 document.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>editPlayer(b.dataset.edit)));
 document.querySelectorAll("[data-del]").forEach(b=>b.addEventListener("click",()=>{const [c,id]=b.dataset.del.split("|");deleteRecord(c,id);}));
 document.querySelectorAll("[data-approve]").forEach(b=>b.addEventListener("click",async()=>{try{await updateDoc(doc(db,"applications",b.dataset.approve),{reviewed:true});await refreshAll();}catch(e){message("adminMessage",errText(e));}}));
 renderFund();
}
function record(label,actions){return `<div class="admin-record"><span>${escapeHTML(label)}</span><span class="record-actions">${actions}</span></div>`;}
function renderFund(){
 if(!isAdmin)return;
 const income=funds.filter(f=>["Income","Prize Money"].includes(f.type)).reduce((s,f)=>s+(+f.amount||0),0);
 const expense=funds.filter(f=>f.type==="Expense").reduce((s,f)=>s+(+f.amount||0),0);
 const html=`<div class="fund-box"><span>INCOME + PRIZE MONEY</span><strong>৳${income.toLocaleString()}</strong></div><div class="fund-box"><span>EXPENSES</span><strong>৳${expense.toLocaleString()}</strong></div><div class="fund-box"><span>NET BALANCE</span><strong>৳${(income-expense).toLocaleString()}</strong></div>`;
 $("fundSummary").innerHTML=html;$("adminFundSummary").innerHTML=html;
 $("adminFundList").innerHTML=funds.map(f=>record(`${f.type} · ৳${(+f.amount||0).toLocaleString()} · ${f.description}`,`<button class="small-btn danger" data-del="funds|${f.id}">Delete</button>`)).join("")||"<p class='muted'>No fund entries.</p>";
 document.querySelectorAll('#adminFundList [data-del]').forEach(b=>b.addEventListener("click",()=>deleteRecord("funds",b.dataset.del.split("|")[1])));
}
function editPlayer(id){const p=players.find(x=>x.id===id);if(!p)return;$("editPlayerId").value=id;$("pName").value=p.name||"";$("pUid").value=p.uid||"";$("pRole").value=p.role||"Player";$("pSquad").value=p.squad||"Main Squad";$("pKills").value=+p.kills||0;$("pMvp").value=+p.mvp||0;$("pPoints").value=+p.points||0;$("pMatches").value=+p.matches||0;$("pAccountUid").value=p.accountUid||"";$("pActive").checked=p.active!==false;document.querySelector('[data-tab="playersAdmin"]').click();$("pName").focus();}
$("clearPlayer").addEventListener("click",()=>{$("playersAdmin").reset();$("editPlayerId").value="";$("pKills").value=$("pMvp").value=$("pPoints").value=$("pMatches").value=0;$("pActive").checked=true;});
async function saveForm(form,collectionName,makeData,after){form.addEventListener("submit",async e=>{e.preventDefault();if(!isAdmin){message("adminMessage","Admin permission required.");return;}const btn=form.querySelector('button[type="submit"]');if(btn)btn.disabled=true;try{const data=await makeData();await addDoc(collection(db,collectionName),{...data,createdAt:serverTimestamp()});form.reset();if(after)after();message("adminMessage","Saved successfully.",true);await refreshAll();}catch(err){console.error(err);message("adminMessage",errText(err));}finally{if(btn)btn.disabled=false;}});}
$("playersAdmin").addEventListener("submit",async e=>{e.preventDefault();if(!isAdmin)return;const btn=$("playersAdmin").querySelector('button[type="submit"]');btn.disabled=true;try{const id=$("editPlayerId").value;const existing=players.find(p=>p.id===id);let photoURL=existing?.photoURL||"";if($("pPhoto").files[0])photoURL=await upload($("pPhoto").files[0],"players");const data={name:$("pName").value.trim(),uid:$("pUid").value.trim(),role:$("pRole").value,squad:$("pSquad").value,kills:+$("pKills").value||0,mvp:+$("pMvp").value||0,points:+$("pPoints").value||0,matches:+$("pMatches").value||0,accountUid:$("pAccountUid").value.trim(),active:$("pActive").checked,photoURL,updatedAt:serverTimestamp()};if(id)await updateDoc(doc(db,"players",id),data);else await addDoc(collection(db,"players"),{...data,createdAt:serverTimestamp()});$("playersAdmin").reset();$("editPlayerId").value="";$("pKills").value=$("pMvp").value=$("pPoints").value=$("pMatches").value=0;$("pActive").checked=true;message("adminMessage","Player saved.",true);await refreshAll();}catch(err){message("adminMessage",errText(err));}finally{btn.disabled=false;}});
saveForm($("scrimsAdmin"),"scrims",async()=>({title:$("sTitle").value.trim(),opponent:$("sOpponent").value.trim(),date:$("sDate").value,time:$("sTime").value,details:$("sDetails").value.trim(),status:"Scheduled"}));
saveForm($("tournamentsAdmin"),"tournaments",async()=>({name:$("tName").value.trim(),status:$("tStatus").value,date:$("tDate").value,details:$("tDetails").value.trim(),photoURL:await upload($("tPhoto").files[0],"tournaments")}));
saveForm($("matchesAdmin"),"matches",async()=>({opponent:$("mOpponent").value.trim(),result:$("mResult").value,date:$("mDate").value,kills:+$("mKills").value||0,placement:+$("mPlacement").value||0,score:$("mScore").value.trim()}));
saveForm($("attendanceAdmin"),"attendance",async()=>{const p=players.find(x=>x.id===$("attPlayer").value);return {playerId:p?.id||"",playerName:p?.name||"",date:$("attDate").value,status:$("attStatus").value,notes:$("attNotes").value.trim()};});
saveForm($("noticesAdmin"),"notices",async()=>({title:$("nTitle").value.trim(),priority:$("nPriority").value,body:$("nBody").value.trim(),date:new Date().toISOString().slice(0,10)}));
saveForm($("awardsAdmin"),"awards",async()=>({title:$("awTitle").value.trim(),winner:$("awWinner").value.trim(),date:$("awDate").value,details:$("awDetails").value.trim()}));
saveForm($("fundAdmin"),"funds",async()=>({type:$("fType").value,description:$("fDesc").value.trim(),amount:+$("fAmount").value,date:$("fDate").value,notes:$("fNotes").value.trim()}));
$("applicationForm").addEventListener("submit",async e=>{e.preventDefault();if(!db){message("applicationMessage","Firebase setup is required.");return;}try{await addDoc(collection(db,"applications"),{name:$("aName").value.trim(),uid:$("aUid").value.trim(),role:$("aRole").value,contact:$("aContact").value.trim(),reviewed:false,createdAt:serverTimestamp()});$("applicationForm").reset();message("applicationMessage","Application submitted. The team admin will review it.",true);}catch(err){message("applicationMessage",errText(err));}});
async function deleteRecord(c,id){if(!isAdmin||!confirm("Delete this record permanently?"))return;try{await deleteDoc(doc(db,c,id));toast("Record deleted");await refreshAll();}catch(e){message("adminMessage",errText(e));}}
