# INFINITY X Free Fire Esports App — v2

Responsive black/red esports web app using HTML, CSS, JavaScript modules, Firebase Authentication, Firestore and Storage.

## Features
- Public squad roster with Main Squad / Substitute Squad / Academy
- Player UID, photo, role, kills, MVPs, matches and points
- Performance leaderboard and player ranking
- Scrim schedule
- Tournaments and banner uploads
- Match results, kills and placement points
- Practice attendance (admin recorded)
- Public notices
- Achievements and awards
- Admin-only team fund ledger and balance summary
- Public trial/player application form
- Admin email/password login
- Player login to view own linked profile
- Firestore/Storage rules; only authorized admins can write team records

## A. Firebase setup
1. Create a project at https://console.firebase.google.com/
2. Add a Web App in Project settings.
3. Copy the web app config into `firebaseConfig` in `app.js`.
4. Authentication → Sign-in method → enable **Email/Password**.
5. Firestore Database → Create database.
6. Storage → Get started.
7. Paste `firestore.rules` into Firestore Rules and Publish.
8. Paste `storage.rules` into Storage Rules and Publish.

Never put a Firebase service-account key or private server credential in frontend code.

## B. Create the admin account
1. Authentication → Users → Add user, create admin email/password.
2. Copy the admin user's Firebase Auth UID.
3. Firestore → Data → create collection `admins`.
4. Set document ID to exactly the admin UID and add field `role` (string) = `admin`.
5. The admin record cannot be created or changed from the client app.

## C. Create player accounts and link profiles
1. Authentication → Users → Add user, create a player's email/password. Public sign-up is intentionally disabled.
2. Copy that player's Auth UID.
3. In the app, sign in as admin → Players → add/edit the matching player.
4. Paste the player's Auth UID into **Linked player account UID** and save.
5. The player can sign in with those credentials and use **My Profile** to see the linked player record. Players cannot change their stats or roster data.
6. Do not share admin credentials with players. If a player account is not linked, it will not show a profile.

## D. Host the app
Run from a web server because `app.js` uses JavaScript modules. Do not open `index.html` with a `file://` URL.

Example with Firebase Hosting:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
```
Choose your Firebase project and set the public directory to this folder (where `index.html` is). Avoid overwriting these files. Then:
```bash
firebase deploy
```
Alternatively use VS Code + Live Server for local testing.

## E. Security and data notes
- Admin writes require a document at `admins/{authenticated Firebase UID}`.
- The app does not provide self-service account registration. Admin creates player accounts in Firebase Console and links each UID to the player record.
- Public roster, scrims, tournaments, matches, notices, awards and attendance records are readable by anyone. Do not store sensitive private information in those collections.
- Team fund records are admin-only (both read and write).
- Trial applications can be created publicly but are readable/editable only by admins. Use the trial form for in-game details only; don't ask for passwords or sensitive personal data.
- Storage uploads are admin-only and limited to image files smaller than 5 MB.
- Firebase plan/quota requirements can vary. Check the current Firebase Console if Storage asks for billing setup.
- Player cards are displayed in the app; a downloadable PNG export is not implemented in this version.
- Push notifications, chat, auto-sync with Garena, player self-service stats submission and APK packaging are not included.
