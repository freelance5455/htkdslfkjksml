# NABD — APK-ready (current UI)

هذه النسخة تحتوي واجهة NABD الحالية داخل WebView، ومضمّنة داخل JavaScript حتى تُحزم مع التطبيق ولا تعتمد على وجود ملف HTML خارجي بعد البناء.

## بناء APK على الهاتف عبر Replit أو على الكمبيوتر

1. افتح مجلد `nabd-apk`.
2. ثبّت الحزم:
```bash
npm install
```
3. ثبّت EAS CLI:
```bash
npm install -g eas-cli
```
4. سجّل الدخول:
```bash
eas login
```
5. أنشئ إعدادات EAS إن طلبها:
```bash
eas build:configure
```
6. ابنِ APK:
```bash
eas build -p android --profile preview
```

اختر Android APK عند الطلب. بعد انتهاء البناء سيظهر رابط تنزيل APK من EAS.

## ملاحظة
هذه الخطوة تحوّل النسخة الحالية إلى تطبيق Android قابل للبناء والتثبيت، لكنها لا تضيف بعد Firebase أو الحسابات الحقيقية أو المكالمات الحقيقية. هذه ستكون خطوات لاحقة.
