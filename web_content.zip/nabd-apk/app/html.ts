export const NABD_HTML = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NABD — Messenger</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--p:#6d28d9;--p2:#4f46e5;--soft:#eee9ff;--chat:#f3f1f7}
*{box-sizing:border-box}body{margin:0;font-family:Arial,Tahoma,sans-serif;background:#dfe1e7}
.app{height:100vh;width:100%;max-width:1500px;margin:auto;background:white;display:flex;overflow:hidden;box-shadow:0 0 35px #0002}
.side{width:360px;border-left:1px solid #ddd;display:flex;flex-direction:column;background:#fff}
.top{height:70px;background:linear-gradient(135deg,#312e81,var(--p));color:white;display:flex;align-items:center;justify-content:space-between;padding:10px 16px}
.brand{font-size:24px;font-weight:800}.avatar{width:44px;height:44px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#a78bfa,#6366f1);font-weight:800}
.search{margin:10px 12px;background:#f1f1f5;border-radius:9px;height:42px;display:flex;align-items:center;padding:0 13px;gap:10px}.search input{border:0;outline:0;background:transparent;width:100%}
.tabs{display:flex;border-bottom:1px solid #eee}.tab{flex:1;text-align:center;padding:11px 3px;font-size:13px;color:#777;cursor:pointer}.tab.active{color:var(--p);font-weight:700;border-bottom:3px solid var(--p)}
.list{overflow:auto;flex:1}.item{display:flex;gap:12px;padding:12px 14px;cursor:pointer;border-bottom:1px solid #f0f0f2}.item:hover,.item.active{background:#f5f2ff}.item .avatar{width:50px;height:50px;flex:none}.meta{min-width:0;flex:1}.row{display:flex;justify-content:space-between;gap:8px}.name{font-weight:700}.time{font-size:11px;color:#888}.preview{font-size:13px;color:#777;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:4px}.badge{background:var(--p);color:#fff;border-radius:20px;font-size:10px;padding:2px 6px}
.main{flex:1;display:flex;flex-direction:column;min-width:0;background:#eeeaf2}
.header{height:70px;background:#f7f7f9;border-bottom:1px solid #ddd;display:flex;align-items:center;justify-content:space-between;padding:10px 18px}.person{display:flex;align-items:center;gap:11px}.status{font-size:11px;color:var(--p)}
.messages{flex:1;overflow:auto;padding:24px 7%;display:flex;flex-direction:column;gap:9px;background-color:#efeef3;background-image:radial-gradient(#6d28d90d 1px,transparent 1px);background-size:20px 20px}
.day{align-self:center;background:white;color:#777;border-radius:8px;padding:5px 10px;font-size:11px}
.msg{max-width:65%;padding:8px 11px;border-radius:9px;box-shadow:0 1px 2px #0001;font-size:14px;line-height:1.5}.in{align-self:flex-start;background:white;border-top-right-radius:3px}.out{align-self:flex-end;background:#e7ddff;border-top-left-radius:3px}.stamp{text-align:left;color:#888;font-size:10px;margin-top:3px}
.composer{height:68px;background:#f7f7f9;display:flex;align-items:center;gap:10px;padding:10px 14px}.composer input{flex:1;border:0;outline:0;background:white;border-radius:22px;padding:12px 17px}.btn{border:0;width:43px;height:43px;border-radius:50%;display:grid;place-items:center;cursor:pointer}.icon{background:#eeeafa;color:var(--p)}.send{background:var(--p);color:white}
.empty{display:none;flex:1;align-items:center;justify-content:center;color:#777}.mobile-back{display:none}
@media(max-width:800px){
 body{background:white}.app{height:100dvh}.side{width:100%;border:0}.main{display:none}.app.chat-open .side{display:none}.app.chat-open .main{display:flex;width:100%}.mobile-back{display:inline}.desktop-only{display:none}.messages{padding:16px 4%}.msg{max-width:82%}
}

.status-page{position:absolute;inset:0;background:#f5f3f8;display:none;z-index:20;flex-direction:column}
.status-page.show{display:flex}
.status-head{height:70px;background:linear-gradient(135deg,#312e81,#6d28d9);color:#fff;display:flex;align-items:center;justify-content:space-between;padding:10px 18px}
.status-head h2{margin:0;font-size:21px}.status-head button{background:#ffffff22;color:#fff;border:0;border-radius:50%;width:40px;height:40px;cursor:pointer}
.status-body{overflow:auto;padding:22px;max-width:850px;width:100%;margin:auto}
.my-status{background:#fff;border-radius:14px;padding:14px;display:flex;align-items:center;gap:14px;box-shadow:0 2px 8px #0000000d;margin-bottom:18px}
.add-status{width:56px;height:56px;border-radius:50%;border:3px solid #6d28d9;background:#eee9ff;color:#6d28d9;display:grid;place-items:center;font-size:21px}
.status-title{font-weight:700}.status-sub{font-size:12px;color:#888;margin-top:4px}
.section-label{font-size:13px;font-weight:700;color:#666;margin:14px 4px 8px}
.status-card{background:#fff;border-radius:15px;padding:13px;display:flex;align-items:center;gap:13px;margin-bottom:8px;cursor:pointer;box-shadow:0 1px 5px #0000000a}
.status-ring{width:58px;height:58px;border-radius:50%;padding:3px;background:linear-gradient(135deg,#6d28d9,#4f46e5,#a78bfa);flex:none}
.status-ring>div{width:100%;height:100%;border-radius:50%;display:grid;place-items:center;color:#fff;font-weight:800;background:#6366f1;border:2px solid #fff}
.status-card:hover{background:#f8f6ff}
.status-viewer{position:fixed;inset:0;background:#17131fdd;display:none;z-index:40;align-items:center;justify-content:center}
.status-viewer.show{display:flex}.viewer-box{width:min(420px,92vw);height:min(720px,90vh);border-radius:20px;overflow:hidden;background:linear-gradient(160deg,#312e81,#6d28d9,#4f46e5);color:#fff;display:flex;flex-direction:column;position:relative}
.viewer-top{padding:15px;display:flex;align-items:center;gap:10px}.viewer-progress{height:3px;background:#ffffff55;margin:8px 12px 0}.viewer-progress i{display:block;height:100%;width:70%;background:#fff}.viewer-content{flex:1;display:grid;place-items:center;text-align:center;padding:35px;font-size:27px;font-weight:700}.viewer-close{position:absolute;top:12px;left:14px;background:#ffffff22;color:#fff;border:0;border-radius:50%;width:38px;height:38px}

.calls-page,.settings-page{position:absolute;inset:0;background:#f5f3f8;display:none;z-index:25;flex-direction:column}
.calls-page.show,.settings-page.show{display:flex}
.sub-head{height:70px;background:linear-gradient(135deg,#312e81,#6d28d9);color:#fff;display:flex;align-items:center;gap:14px;padding:10px 18px}
.sub-head button{background:#ffffff22;color:#fff;border:0;border-radius:50%;width:40px;height:40px}
.sub-body{overflow:auto;padding:18px;max-width:850px;width:100%;margin:auto}
.call-card,.setting-card{background:#fff;border-radius:14px;padding:14px;display:flex;align-items:center;gap:13px;margin-bottom:9px;box-shadow:0 1px 5px #0000000b}
.call-icon{width:42px;height:42px;border-radius:50%;display:grid;place-items:center;background:#eee9ff;color:#6d28d9}
.call-info{flex:1}.call-time{font-size:11px;color:#888;margin-top:4px}
.setting-card{cursor:pointer}.setting-card:hover{background:#faf8ff}.setting-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:#eee9ff;color:#6d28d9}
.profile-box{background:#fff;border-radius:16px;padding:22px;text-align:center;margin-bottom:16px}.profile-big{width:82px;height:82px;margin:auto;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#a78bfa,#4f46e5);color:white;font-size:28px;font-weight:bold}
.switch{width:42px;height:23px;border-radius:20px;background:#6d28d9;position:relative}.switch:after{content:"";position:absolute;width:19px;height:19px;right:2px;top:2px;border-radius:50%;background:#fff}
</style>
</head>
<body>
<div class="app" id="app">
  <aside class="side">
    <div class="top">
      <div class="flex items-center gap-3"><div class="avatar">أ</div><div><div class="brand">NABD</div><div class="text-xs opacity-80">رسائلك في مكان واحد</div></div></div>
      <div class="flex gap-4 text-lg"><i class="fa-solid fa-camera"></i><i class="fa-solid fa-ellipsis-vertical"></i></div>
    </div>
    <div class="search"><i class="fa-solid fa-magnifying-glass text-gray-400"></i><input id="search" placeholder="بحث أو بدء محادثة جديدة"></div>
    <div class="tabs"><div class="tab active" onclick="renderList(document.getElementById('search').value)">المحادثات</div><div class="tab" onclick="openStatuses()">الحالات</div><div class="tab" onclick="openPage('callsPage')">المكالمات</div></div>
    <div class="list" id="list"></div>
  </aside>

  <main class="main">
    <header class="header">
      <div class="person"><button class="btn icon mobile-back" onclick="closeChat()"><i class="fa-solid fa-arrow-right"></i></button><div class="avatar" id="headAvatar">م</div><div><div class="font-bold" id="headName">محمد علي</div><div class="status" id="headStatus">متصل الآن</div></div></div>
      <div class="flex gap-6 text-gray-500 text-lg"><i class="fa-solid fa-video cursor-pointer" onclick="alert('مكالمة فيديو تجريبية')"></i><i class="fa-solid fa-phone cursor-pointer" onclick="alert('مكالمة صوتية تجريبية')"></i><i class="fa-solid fa-magnifying-glass"></i><i class="fa-solid fa-ellipsis-vertical"></i></div>
    </header>
    <section class="messages" id="messages"></section>
    <div class="composer">
      <button class="btn icon" onclick="alert('اختيار ملف تجريبي')"><i class="fa-solid fa-plus"></i></button>
      <button class="btn icon"><i class="fa-regular fa-face-smile"></i></button>
      <input id="message" placeholder="اكتب رسالة..." onkeydown="if(event.key==='Enter')send()">
      <button class="btn send" onclick="send()"><i class="fa-solid fa-paper-plane"></i></button>
    </div>
  </main>
</div>
<script>
const chats=[
 {id:1,n:'محمد علي',a:'م',c:'bg-purple-600',t:'10:42 م',p:'أهلاً بك، هل انتهيت من المشروع؟',s:'متصل الآن',msgs:[
  ['in','أهلاً بك، هل انتهيت من المشروع؟','10:40 م'],['out','نعم، لقد أتممت التصميم بالكامل وسأقوم بإرساله لك الآن.','10:42 م']
 ]},
 {id:2,n:'سارة أحمد',a:'س',c:'bg-indigo-500',t:'أمس',p:'شكراً جزيلاً لك على المساعدة.',s:'متصلة منذ قليل',msgs:[
  ['in','شكراً جزيلاً لك على المساعدة.','أمس']
 ]},
 {id:3,n:'مجموعة المشروع',a:'ن',c:'bg-violet-600',t:'أمس',p:'تم رفع الملفات الجديدة.',s:'3 أعضاء متصلون',msgs:[
  ['in','تم رفع الملفات الجديدة.','أمس']
 ]},
 {id:4,n:'يوسف',a:'ي',c:'bg-blue-600',t:'الاثنين',p:'سأراسلك لاحقاً.',s:'آخر ظهور مؤخراً',msgs:[
  ['in','سأراسلك لاحقاً.','الاثنين']
 ]}
];
let current=1;
function renderList(q=''){
 const el=document.getElementById('list');el.innerHTML='';
 chats.filter(x=>x.n.includes(q)||x.p.includes(q)).forEach(x=>{
  el.innerHTML+=\`<div class="item \${x.id===current?'active':''}" onclick="openChat(\${x.id})"><div class="avatar \${x.c} text-white">\${x.a}</div><div class="meta"><div class="row"><div class="name truncate">\${x.n}</div><div class="time">\${x.t}</div></div><div class="preview">\${x.p}</div></div>\${x.id===1?'<span class="badge">2</span>':''}</div>\`;
 });
}
function openChat(id){
 current=id;const x=chats.find(c=>c.id===id);
 document.getElementById('headName').textContent=x.n;document.getElementById('headAvatar').textContent=x.a;
 document.getElementById('headAvatar').className='avatar '+x.c+' text-white';
 document.getElementById('headStatus').textContent=x.s;
 const m=document.getElementById('messages');m.innerHTML='<div class="day">اليوم</div>';
 x.msgs.forEach(v=>m.innerHTML+=\`<div class="msg \${v[0]}"><div>\${v[1]}</div><div class="stamp">\${v[2]} \${v[0]==='out'?'✓✓':''}</div></div>\`);
 m.scrollTop=m.scrollHeight;renderList(document.getElementById('search').value);
 document.getElementById('app').classList.add('chat-open');
}
function closeChat(){document.getElementById('app').classList.remove('chat-open')}
function send(){
 const inp=document.getElementById('message'),v=inp.value.trim();if(!v)return;
 const m=document.getElementById('messages');m.innerHTML+=\`<div class="msg out"><div>\${escapeHtml(v)}</div><div class="stamp">الآن ✓</div></div>\`;
 inp.value='';m.scrollTop=m.scrollHeight;
 const x=chats.find(c=>c.id===current);x.p=v;x.t='الآن';renderList(document.getElementById('search').value);
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
document.getElementById('search').addEventListener('input',e=>renderList(e.target.value));
renderList();openChat(1);
</script>

<div class="status-page" id="statusPage">
  <div class="status-head">
    <div class="flex items-center gap-3"><button onclick="closeStatuses()" class="text-lg"><i class="fa-solid fa-arrow-right"></i></button><h2>الحالات</h2></div>
    <div class="flex gap-5 text-lg"><i class="fa-solid fa-camera cursor-pointer" onclick="newStatus('صورة جديدة 📸')"></i><i class="fa-solid fa-ellipsis-vertical"></i></div>
  </div>
  <div class="status-body">
    <div class="my-status" onclick="newStatus('اكتب حالتك هنا ✨')">
      <div class="add-status"><i class="fa-solid fa-plus"></i></div>
      <div><div class="status-title">حالتي</div><div class="status-sub">أضف تحديثًا إلى حالتك</div></div>
    </div>
    <div class="section-label">التحديثات الأخيرة</div>
    <div id="statusList"></div>
    <div class="section-label">التحديثات التي شاهدتها</div>
    <div class="status-card" onclick="viewStatus('سارة أحمد','شكرًا لكم على الدعم 💜','منذ أمس')">
      <div class="status-ring" style="filter:grayscale(1);opacity:.65"><div>س</div></div>
      <div><div class="status-title">سارة أحمد</div><div class="status-sub">منذ أمس · تمت المشاهدة</div></div>
    </div>
  </div>
</div>
<div class="status-viewer" id="statusViewer" onclick="if(event.target===this)closeViewer()">
  <div class="viewer-box">
    <div class="viewer-progress"><i></i></div>
    <div class="viewer-top"><div class="avatar">م</div><div><b id="viewerName">محمد علي</b><div class="text-xs opacity-80" id="viewerTime">منذ 10 دقائق</div></div></div>
    <button class="viewer-close" onclick="closeViewer()"><i class="fa-solid fa-xmark"></i></button>
    <div class="viewer-content" id="viewerText"></div>
  </div>
</div>

<script>
const statuses=[
 {n:'محمد علي',a:'م',t:'منذ 10 دقائق',text:'أجواء جميلة اليوم ✨'},
 {n:'يوسف',a:'ي',t:'منذ 35 دقيقة',text:'يوم جديد، بداية جديدة 💜'},
 {n:'مجموعة المشروع',a:'ن',t:'منذ ساعة',text:'تم الانتهاء من العمل 🚀'}
];
function renderStatuses(){
 const el=document.getElementById('statusList');el.innerHTML='';
 statuses.forEach(s=>el.innerHTML+=\`<div class="status-card" onclick="viewStatus('\${s.n}','\${s.text}','\${s.t}')"><div class="status-ring"><div>\${s.a}</div></div><div><div class="status-title">\${s.n}</div><div class="status-sub">\${s.t}</div></div></div>\`);
}
function openStatuses(){renderStatuses();document.getElementById('statusPage').classList.add('show')}
function closeStatuses(){document.getElementById('statusPage').classList.remove('show')}
function viewStatus(n,t,time){document.getElementById('viewerName').textContent=n;document.getElementById('viewerTime').textContent=time;document.getElementById('viewerText').textContent=t;document.getElementById('statusViewer').classList.add('show')}
function closeViewer(){document.getElementById('statusViewer').classList.remove('show')}
function newStatus(text){viewStatus('حالتي',text,'الآن')}
</script>

<div class="calls-page" id="callsPage">
 <div class="sub-head"><button onclick="closePage('callsPage')"><i class="fa-solid fa-arrow-right"></i></button><h2>المكالمات</h2></div>
 <div class="sub-body">
  <div class="call-card"><div class="call-icon"><i class="fa-solid fa-phone"></i></div><div class="call-info"><b>محمد علي</b><div class="call-time">اليوم · 10:42 م · مكالمة صوتية واردة</div></div><i class="fa-solid fa-phone text-purple-700"></i></div>
  <div class="call-card"><div class="call-icon"><i class="fa-solid fa-video"></i></div><div class="call-info"><b>سارة أحمد</b><div class="call-time">أمس · 8:15 م · مكالمة فيديو فائتة</div></div><i class="fa-solid fa-video text-purple-700"></i></div>
  <div class="call-card"><div class="call-icon"><i class="fa-solid fa-phone"></i></div><div class="call-info"><b>يوسف</b><div class="call-time">الاثنين · 6:30 م · مكالمة صادرة</div></div><i class="fa-solid fa-phone text-purple-700"></i></div>
 </div>
</div>
<div class="settings-page" id="settingsPage">
 <div class="sub-head"><button onclick="closePage('settingsPage')"><i class="fa-solid fa-arrow-right"></i></button><h2>الإعدادات</h2></div>
 <div class="sub-body">
  <div class="profile-box"><div class="profile-big">أ</div><h3 class="mt-3 font-bold">أحمد</h3><div class="text-xs text-gray-500">متاح على NABD</div></div>
  <div class="setting-card"><div class="setting-icon"><i class="fa-solid fa-key"></i></div><div class="setting-info flex-1"><b>الحساب</b><div class="text-xs text-gray-500 mt-1">الخصوصية والأمان ورقم الهاتف</div></div><i class="fa-solid fa-chevron-left text-gray-400"></i></div>
  <div class="setting-card"><div class="setting-icon"><i class="fa-solid fa-bell"></i></div><div class="setting-info flex-1"><b>الإشعارات</b><div class="text-xs text-gray-500 mt-1">الرسائل والمكالمات</div></div><i class="fa-solid fa-chevron-left text-gray-400"></i></div>
  <div class="setting-card" onclick="toggleDark()"><div class="setting-icon"><i class="fa-solid fa-moon"></i></div><div class="setting-info flex-1"><b>الوضع الداكن</b><div class="text-xs text-gray-500 mt-1">تغيير مظهر NABD</div></div><div class="switch"></div></div>
  <div class="setting-card"><div class="setting-icon"><i class="fa-solid fa-lock"></i></div><div class="setting-info flex-1"><b>الخصوصية</b><div class="text-xs text-gray-500 mt-1">آخر ظهور، الصورة والحالات</div></div><i class="fa-solid fa-chevron-left text-gray-400"></i></div>
  <div class="setting-card"><div class="setting-icon"><i class="fa-solid fa-circle-info"></i></div><div class="setting-info flex-1"><b>حول NABD</b><div class="text-xs text-gray-500 mt-1">الإصدار التجريبي 1.0</div></div></div>
 </div>
</div>

<script>
function openPage(id){document.getElementById(id).classList.add('show')}
function closePage(id){document.getElementById(id).classList.remove('show')}
function toggleDark(){
 document.body.classList.toggle('dark-demo');
 const d=document.querySelector('.dark-demo');
 if(d){
  document.body.style.background='#15131b';
  document.querySelectorAll('.setting-card,.profile-box').forEach(x=>{x.style.background='#25212f';x.style.color='#fff'});
 }else{
  document.body.style.background='';
  document.querySelectorAll('.setting-card,.profile-box').forEach(x=>{x.style.background='';x.style.color=''});
 }
}
</script>
</body>
</html>`;
