import React from "react";
import { WebView } from "react-native-webview";
import { StatusBar } from "expo-status-bar";
import { NABD_HTML } from "./html";

export default function Index() {
  return (
    <>
      <StatusBar style="dark" />
      <WebView
        source={{ html: NABD_HTML, baseUrl: "https://nabd.local/" }}
        originWhitelist={["*"]}
        javaScriptEnabled
        domStorageEnabled
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        style={{ flex: 1 }}
      />
    </>
  );
}
