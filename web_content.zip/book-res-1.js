/* JOSTECH — MANUEL 06 : RÉSEAUX & MAINTENANCE NIVEAU 1 */
registerLessonDetail(6, 1, "res-1-1-1", {
  title: "Leçon 1 : Architecture Matérielle, Assemblage et Maintenance",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Identifier les rôles du Chipset, des slots RAM/PCIe, du SSD NVMe et de l'alimentation (PSU).",
    "Maîtriser la séquence de démarrage (BIOS/UEFI, POST, Bootloader, OS).",
    "Planifier une maintenance préventive rigoureuse et mener un diagnostic curatif méthodique."
  ],
  prerequisites: ["Notions d'Informatique générale (CPU, RAM)."],
  sections: [
    {
      type: "theory",
      title: "1. Anatomie interne d'un ordinateur de bureau ou portable",
      text: "La Carte Mère est le circuit imprimé central qui interconnecte tous les composants via ses pistes et son Chipset. Le Processeur (CPU) s'insère dans le Socket et doit impérativement être recouvert d'une fine couche de pâte thermique sous son ventirad : sans cela, le CPU atteint 100 °C en quelques secondes et se coupe par sécurité.\n\nLes disques SSD NVMe se branchent directement sur le bus rapide PCIe (M.2), offrant des débits de 3 000 à 7 000 Mo/s contre ~120 Mo/s pour un vieux disque dur mécanique (HDD). Enfin, le bloc d'alimentation (PSU) transforme le courant alternatif mural (220 V AC) en tensions continues précises (+12 V pour CPU/GPU, +5 V et +3,3 V)."
    },
    {
      type: "code",
      lang: "Séquence exacte de démarrage (Boot Sequence)",
      code: [
        "1. Bouton Power → L'alimentation stabilise ses tensions (signal Power Good).",
        "2. BIOS / UEFI (en mémoire Flash sur la carte mère) lance le test POST :",
        "   Vérifie CPU, RAM, carte graphique, clavier. (Si panne → Bips d'erreur !)",
        "3. UEFI cherche un disque amorçable et charge le Bootloader (GRUB / Windows Boot).",
        "4. Le Bootloader charge le noyau du Système d'Exploitation (Linux, Windows) en RAM."
      ].join("\n")
    },
    {
      type: "table",
      title: "2. Maintenance Préventive vs Maintenance Corrective",
      headers: ["Maintenance", "Actions concrètes"],
      rows: [
        ["Préventive (Planifiée)", "Dépoussiérage à l'air sec, remplacement pâte thermique, onduleur (UPS), SMART des disques, mises à jour, sauvegardes."],
        ["Corrective (Panne)", "Méthode par élimination : vérifier câbles/alim → écouter bips POST → tester barrettes RAM une par une → vérifier températures."]
      ]
    },
    {
      type: "warning",
      title: "Règle absolue : Protection ESD (Décharge Électrostatique)",
      text: "Le corps humain accumule facilement 3 000 V d'électricité statique sans la sentir, alors qu'une puce RAM grille dès 30 V ! Avant d'ouvrir un PC : débranchez le câble secteur, appuyez 5 secondes sur le bouton Power pour vider les condensateurs, puis touchez une partie métallique nue du boîtier (ou portez un bracelet antistatique)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Diagnostic de panne au démarrage",
      question: "Un ordinateur démarre ses ventilateurs mais l'écran reste noir et la carte mère émet une série de bips courts/longs répétés. Quelle étape bloque et comment diagnostiquer ?",
      solution: "C'est le test POST (Power-On Self-Test) du BIOS/UEFI qui échoue avant d'allumer l'écran. On consulte le manuel de la carte mère pour le code de bip (souvent la RAM ou le GPU), on coupe le courant, et on teste chaque barrette de RAM séparément."
    },
    {
      title: "Exercice 2 — Goulot de stockage",
      question: "Un PC ancien met 2 minutes pour démarrer Windows et bloquer à 100 % disque sur un HDD mécanique. Pourquoi remplacer le HDD par un SSD transforme-t-il l'ordinateur même sans changer le processeur ?",
      solution: "Un HDD a un temps d'accès mécanique (~10 ms) très lent pour lire des milliers de petits fichiers système. Un SSD flash accède aléatoirement en ~0,1 ms (100x plus vite), supprimant le goulot d'étranglement E/S."
    }
  ],
  summary: "Assembler et maintenir un parc informatique exige le respect de la sécurité ESD, une bonne dissipation thermique, la maîtrise du test POST et une maintenance préventive planifiée.",
  references: ["Mueller, S. — Upgrading and Repairing PCs.", "CompTIA A+ Complete Study Guide."]
});