(function () {
  var A = window.App, Au = window.Auth;
  if (A.redirectIfAuth()) return;
  Au.bindEyes();
  var form = document.getElementById('login-form');
  var step2 = document.getElementById('twofa-step');
  var pending = null;

  function finish(u) {
    if (!A.setSession(u.id, document.getElementById('remember').checked)) {
      var box = document.getElementById('form-error');
      box.textContent = 'Oturum açılamadı: tarayıcı depolamaya izin vermiyor.'; box.classList.remove('hidden'); return;
    }
    location.replace('home.html');
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var id = form.identifier.value.trim(), pw = form.password.value, ok = true;
    Au.showErr('identifier', ''); Au.showErr('password', '');
    document.getElementById('form-error').classList.add('hidden');
    if (!id) { Au.showErr('identifier', 'E-posta veya kullanıcı adı gir.'); ok = false; }
    if (!pw) { Au.showErr('password', 'Şifreni gir.'); ok = false; }
    if (!ok) return;
    var btn = form.querySelector('button[type="submit"]');
    Au.loading(btn, true, 'Giriş yap');
    A.checkLogin(id, pw).then(function (u) {
      if (u.twofa && u.twofa.secret) {
        pending = u;
        form.classList.add('hidden'); step2.classList.remove('hidden');
        document.getElementById('code').focus();
      } else finish(u);
    }).catch(function (err) {
      var box = document.getElementById('form-error');
      box.textContent = err.message; box.classList.remove('hidden');
    }).then(function () { Au.loading(btn, false, 'Giriş yap'); });
  });

  document.getElementById('twofa-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var code = document.getElementById('code').value.trim();
    Au.showErr('code', '');
    A.verifyTotp(pending.twofa.secret, code).then(function (ok) {
      if (ok) finish(pending); else Au.showErr('code', 'Kod hatalı veya süresi dolmuş.');
    });
  });
  document.getElementById('twofa-back').addEventListener('click', function () {
    pending = null; step2.classList.add('hidden'); form.classList.remove('hidden'); form.password.value = '';
  });

  document.getElementById('forgot').addEventListener('click', function (e) {
    e.preventDefault();
    var s = A.sheet(A.sheetHeader('Şifreyi sıfırla', 'Hesabının e-postasını ve yeni şifreni gir') +
      '<form id="rp-form" class="space-y-3" novalidate>' +
      '<input id="rp-email" type="email" placeholder="E-posta" autocomplete="email" class="w-full h-12 rounded-2xl bg-input border border-border px-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring" />' +
      '<input id="rp-pw" type="password" placeholder="Yeni şifre (en az 8 karakter)" autocomplete="new-password" class="w-full h-12 rounded-2xl bg-input border border-border px-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring" />' +
      '<p id="rp-err" class="hidden text-xs font-bold text-destructive"></p>' +
      '<p class="text-[11px] text-muted-foreground font-semibold">Veriler yalnızca bu cihazda tutulduğu için e-posta gönderilmez; sıfırlama doğrudan bu cihazdaki hesaba uygulanır.</p>' +
      '<button type="submit" class="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold">Şifreyi güncelle</button></form>');
    s.$('#rp-form').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var err = s.$('#rp-err'), pw = s.$('#rp-pw').value;
      err.classList.add('hidden');
      if (pw.length < 8) { err.textContent = 'Şifre en az 8 karakter olmalı.'; err.classList.remove('hidden'); return; }
      A.resetPassword(s.$('#rp-email').value, pw).then(function () {
        s.close(); A.toast('Şifren güncellendi, giriş yapabilirsin.');
      }).catch(function (x) { err.textContent = x.message; err.classList.remove('hidden'); });
    });
  });
})();
