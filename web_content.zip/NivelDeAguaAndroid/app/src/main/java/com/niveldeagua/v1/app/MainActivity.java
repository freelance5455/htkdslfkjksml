package com.niveldeagua.v1.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 1001;
    private final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket socket;
    private Thread readerThread;
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        web.addJavascriptInterface(new AndroidBluetooth(), "AndroidBluetooth");
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
    }

    private void js(final String call) { runOnUiThread(() -> web.evaluateJavascript(call, null)); }

    public class AndroidBluetooth {
        @JavascriptInterface public void connect() { new Thread(() -> connectBt()).start(); }
        @JavascriptInterface public void disconnect() { closeBt(); }
    }

    private void connectBt() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) throw new IOException("Bluetooth no disponible");
            if (!adapter.isEnabled()) throw new IOException("Activa Bluetooth en Android");
            BluetoothDevice chosen = null;
            Set<BluetoothDevice> paired = adapter.getBondedDevices();
            for (BluetoothDevice d : paired) {
                String n = d.getName();
                if (n != null && (n.toUpperCase().contains("HC-05") || n.toUpperCase().contains("HC-06"))) { chosen = d; break; }
            }
            if (chosen == null && paired.size() == 1) chosen = paired.iterator().next();
            if (chosen == null) throw new IOException("Empareja primero el HC-05/HC-06 en Ajustes de Bluetooth");
            socket = chosen.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            js("window.bluetoothConnected && window.bluetoothConnected()") ;
            readerThread = new Thread(() -> readLoop()); readerThread.start();
        } catch (Exception e) {
            js("window.bluetoothDisconnected && window.bluetoothDisconnected()");
            js("document.getElementById('bleStatus').textContent='● '+" + quote(e.getMessage()) + ";");
        }
    }

    private void readLoop() {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line; StringBuilder packet = new StringBuilder();
            while (socket != null && socket.isConnected() && (line = r.readLine()) != null) {
                packet.append(line).append('\n');
                if (line.startsWith("ALARMA:")) {
                    String p = packet.toString().replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n");
                    js("window.setBluetoothData && window.setBluetoothData('" + p + "')");
                    packet.setLength(0);
                }
            }
        } catch (Exception ignored) { }
        js("window.bluetoothDisconnected && window.bluetoothDisconnected()");
    }

    private String quote(String x) { if (x == null) x = "Error Bluetooth"; return "'" + x.replace("\\", "\\\\").replace("'", "\\'") + "'"; }
    private void closeBt() { try { if (socket != null) socket.close(); } catch (Exception ignored) {} socket = null; js("window.bluetoothDisconnected && window.bluetoothDisconnected()"); }
    @Override protected void onDestroy() { closeBt(); super.onDestroy(); }
}
