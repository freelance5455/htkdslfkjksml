@echo off
REM Sobe um servidor HTTP local so para abrir o app pelo navegador em http://localhost:8080
REM (o app tambem funciona sem isso, abrindo o index.html direto no navegador).
echo Abrindo o Anjo da Guarda em http://localhost:8080 ...
echo Feche esta janela para encerrar.
cd /d "%~dp0"
python -m http.server 8080
