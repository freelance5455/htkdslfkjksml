# ClockTx v1.2 — changelog (cumulative)

## Step 1 (done): live wallpaper, lock screen, icon, Gradle
- WallpaperService rewritten around a dedicated EGL/GLES2 thread (`WallpaperGLThread.kt`) bound to the real wallpaper surface (replaces the GLSurfaceView hack). One loop per engine, sleeps while hidden, releases GL/EGL on surface destroy, recreates context after EGL context loss.
- `ClockRenderer`: shader/program compile+link checks with logcat output, old programs deleted on reload, `release()`, down-sampled image decode, bitmaps recycled.
- Design files written atomically (config last) so the wallpaper never loads a half-written design.
- Lock screen: state detection (`getLockState`, re-checked on every app resume), "Home only" still image via `FLAG_SYSTEM`, recovery guide, re-open live picker without re-export. Existing "static lock image" (`FLAG_LOCK`) kept.
- New adaptive launcher icon from the supplied artwork (all densities + round + wallpaper thumbnail).
- Gradle Wrapper completed (gradlew, gradlew.bat, gradle-wrapper.jar 8.5). versionName 1.2 / versionCode 2. Manifest: GLES 2.0 feature, allowBackup=false.

## Step 2 (done): layers editor, background editor, Glass sync, animations (all in assets/index.html; no Kotlin change)
- Layers: one ordered stack (below clock | CLOCK | above clock). Every layer has X, Y, Scale, Rotation, Opacity, Shadow, Visibility, order buttons (top / up / down / bottom / above clock / below clock) and its own Reset (animated). Same panel for all layers.
- Touch on the stage: drag, two-finger pinch (scale) and rotate for the active target (clock, layer or background, chosen by the open tab). Tap selects a layer; an un-selected layer is never moved by an accidental drag. Layer list supports touch drag & drop with animated reordering.
- Preview, exported image and live wallpaper use the SAME drawLayers() (layers are now drawn on a canvas, not DOM), so order, position, rotation, opacity and shadow match. Layer shadow is now part of the export (before it was preview-only).
- Background editor: Fit / Fill / Width (the old behaviour, kept as default), size, X, Y, rotation (numeric + touch), non-destructive Crop tool (move/resize frame, aspect presets, pinch, OK/Cancel), Reset Background. Background import keeps up to 2600 px (was 1600).
- Saved projects store all new values (order, transforms, shadow, defaults, bg transform/crop); old projects load unchanged.
- Glass / Liquid Glass shaders and controls untouched.
- Animations: panel enter, screen exit transition, list reorder (FLIP), selection box fade, animated resets, button press; all disabled under reduced-motion.
## Step 3 (done): .ctxpreset, app security, reports
- `.ctxpreset` = ZIP (manifest.json + design.json + thumb.jpg + res/* for Full). Lite = settings only, Full = settings + background/layer images + custom font. Format version 1.
- Export: name, description, Lite/Full, approximate size, Save (system "save to" dialog, Storage Access Framework) and Share (Android Sharesheet via FileProvider; Telegram, Bluetooth, ...).
- Import: pick file or open it from another app -> structure/version/resource validation -> preview + info + missing-resource warnings -> confirm -> new project. Layers whose image is missing stay in place (marked with a warning) and can be given an image later.
- Security: strict file-name allow-list (Zip Slip), size caps before and while inflating (Zip Bomb), CRC check, image type/size by real bytes (PNG/JPEG only, max 8192 px, 40 MP), font magic check, at most 30 layers, rebuilt-and-clamped design values, no HTML/JS/APK/SVG ever accepted, texts only shown as plain text, newer format versions refused with a message.
- App: WebView no longer allows file/content URL access and cannot navigate away from the bundled page; Content-Security-Policy meta (no network, no eval); the unused remote font link was removed (the app has no INTERNET permission); only permission is SET_WALLPAPER.
