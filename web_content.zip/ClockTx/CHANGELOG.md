# ClockTx v1.2 — changelog (cumulative)

## Step 1 (done): live wallpaper, lock screen, icon, Gradle
- WallpaperService rewritten around a dedicated EGL/GLES2 thread (`WallpaperGLThread.kt`) bound to the real wallpaper surface (replaces the GLSurfaceView hack). One loop per engine, sleeps while hidden, releases GL/EGL on surface destroy, recreates context after EGL context loss.
- `ClockRenderer`: shader/program compile+link checks with logcat output, old programs deleted on reload, `release()`, down-sampled image decode, bitmaps recycled.
- Design files written atomically (config last) so the wallpaper never loads a half-written design.
- Lock screen: state detection (`getLockState`, re-checked on every app resume), "Home only" still image via `FLAG_SYSTEM`, recovery guide, re-open live picker without re-export. Existing "static lock image" (`FLAG_LOCK`) kept.
- New adaptive launcher icon from the supplied artwork (all densities + round + wallpaper thumbnail).
- Gradle Wrapper completed (gradlew, gradlew.bat, gradle-wrapper.jar 8.5). versionName 1.2 / versionCode 2. Manifest: GLES 2.0 feature, allowBackup=false.

## Step 2 (pending): layers editor, background editor, Glass sync, animations
## Step 3 (pending): .ctxpreset, security, tests report, final ZIP
