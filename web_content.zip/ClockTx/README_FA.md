# Clock Tx — نسخه ۱٫۲ (Live Wallpaper)

سازنده: امیرسام محمدی · Amirsam Mohammadi

## داخل این ZIP چیه؟
- `app/` پروژه کامل اندروید (Kotlin). `MainActivity` برنامه رو نشون می‌ده (سه بخش: تصویر زمینه‌های من، گالری پریست، استودیو).
- `app/src/main/assets/index.html` همون صفحه استودیو که دیدی.
- `ClockWallpaperService` + `ClockRenderer` والپیپر زنده‌ست. ساعت شیشه‌ای رو با همون شیدرِ استودیو، با GPU می‌کشه و هر ثانیه به‌روز می‌کنه.
- `.github/workflows/build.yml` ساخت خودکار APK روی GitHub.
- `build.yml.txt` همون فایل ساخت، برای وقتی که پوشه `.github` آپلود نشد.

## راه ۱: ساخت APK با GitHub (رایگان، حدود ۱۵ دقیقه)
1. ZIP رو توی لپ‌تاپ **Extract (استخراج)** کن.
2. برو github.com ← بالا **+** ← **New repository (مخزن جدید)**. اسمش `clocktx`، نوع **Private (خصوصی)** ← **Create repository**.
3. **uploading an existing file (آپلود فایل موجود)** رو بزن. همه چیزهای **داخل** پوشه ClockTx رو با drag & drop بکش توی صفحه (نه خود پوشه رو)، از جمله پوشه `.github`.
4. پایین صفحه **Commit changes (ثبت تغییرات)** رو بزن.
5. تب **Actions (اکشن‌ها)** ← **Build APK**. اگه چیزی نبود، پوشه `.github` آپلود نشده. راه‌حل: **Add file ← Create new file** ، توی اسم فایل بنویس `.github/workflows/build.yml` و محتوای `build.yml.txt` رو Paste کن و Commit بزن.
6. صبر کن تیک سبز بیاد. روی اجرا کلیک کن، پایین صفحه **Artifacts (خروجی‌ها)** ← **ClockTx-APK** رو دانلود کن (یه ZIP که داخلش APK هست).

**زمان تخمینی:** آپلود ۳ تا ۵ دقیقه. اولین ساخت معمولاً ۶ تا ۱۲ دقیقه، چون باید Gradle و کتابخانه‌ها دانلود بشن. ساخت‌های بعدی ۳ تا ۶ دقیقه.

## راه ۲: سایت‌های Build APK
ZIP رو همون‌طور که هست آپلود کن (فایل‌های `settings.gradle.kts` و پوشه `app` توی ریشه‌ان). تنظیمات: JDK 17، Gradle 8.5، compileSdk 34، دستور `assembleDebug`.
فایل `gradle/wrapper/gradle-wrapper.properties` (نسخه Gradle 8.5) توی ZIP هست. فایل‌های `gradlew`، `gradlew.bat` و `gradle/wrapper/gradle-wrapper.jar` (رسمی، Gradle 8.5) از نسخه ۱٫۲ داخل ZIP هستن، پس سایت‌هایی که از `./gradlew` استفاده می‌کنن هم کار می‌کنن. شناسه بسته (Package name) رو `com.clocktx.app` بذار.

## نصب روی گوشی
1. APK رو به گوشی منتقل کن و بازش کن. اگه خواست، **Install unknown apps (نصب برنامه‌های ناشناس)** رو برای همون برنامه (مرورگر یا فایل‌ها) روشن کن.
2. برنامه **Clock Tx** رو باز کن ← **استودیو (Studio)** ← طرحت رو بساز ← **اعمال · Apply**.
3. صفحه انتخاب والپیپر زنده باز می‌شه. **Set wallpaper (تنظیم والپیپر)** رو بزن و اگه پرسید، **Lock screen (صفحه قفل)** رو انتخاب کن.
4. ساعت سامسونگ: از **Settings ← Lock screen ← Clock style (استایل ساعت)** ساعت خودش رو تا جای ممکن کوچک یا خاموش کن.
- دکمه **عکس ثابت روی Lock screen** فقط یه عکس می‌ذاره و مطمئن فقط روی Lock screen ست می‌شه.

## اگه ساخت خطا داد
این نسخه رو جایی کامپایل نکردم. ممکنه اولین ساخت خطای کوچیک بده. روی مرحله قرمز **Build debug + release APK** کلیک کن، خطوطی که با `e:` یا `error:` شروع می‌شن رو کپی کن و برام بفرست.

## محدودیت‌های این نسخه
- والپیپر زنده فقط ساعت شیشه‌ای حالت «استوانه‌ای» رو پشتیبانی می‌کنه، نه فونت وارد‌شده.
- انیمیشن حرکت شیشه (Motion) توی والپیپر زنده خاموشه.
- فونت «دوران»: فایل `Doran.ttf` رو توی `app/src/main/assets/fonts/` بذار.
