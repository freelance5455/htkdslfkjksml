# ساخت APK

- JDK 17، Gradle 8.5 (wrapper داخل پروژه)، AGP 8.2.2، Kotlin 1.9.22، compileSdk 34، minSdk 26.
- دستور: `./gradlew assembleDebug` (خروجی: app/build/outputs/apk/debug/).
- برای سایت‌های Build APK: همین ZIP را بدهید (build/ و .gradle/ داخلش نیست).
- مجوز: فقط SET_WALLPAPER. بدون INTERNET، مخاطبین، پیامک، تماس، مکان یا Accessibility. allowBackup=false.
