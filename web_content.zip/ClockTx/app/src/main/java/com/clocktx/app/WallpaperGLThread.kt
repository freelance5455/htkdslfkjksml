package com.clocktx.app

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.util.Log
import android.view.SurfaceHolder
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * One dedicated EGL/OpenGL ES 2.0 render thread bound to the REAL wallpaper surface
 * (the SurfaceHolder that WallpaperService.Engine gives us).
 *
 * Why not GLSurfaceView: it is a View that expects a window; hacking it into an Engine
 * gives no control over EGL context loss, pause/resume and teardown order.
 *
 * Guarantees:
 *  - exactly ONE loop per instance (the Engine owns at most one instance at a time);
 *  - while not visible the thread just sleeps on a condition (0% CPU, no GL calls);
 *  - when the surface goes away the thread releases renderer GL objects, the EGL surface,
 *    the EGL context and terminates its EGL display reference, then exits;
 *  - if the EGL context is lost, it is recreated and the renderer re-initialised.
 */
class WallpaperGLThread(
    private val holder: SurfaceHolder,
    private val renderer: ClockRenderer
) : Thread("ClockTx-GL") {

    private val lock = ReentrantLock()
    private val cond = lock.newCondition()

    // guarded by [lock]
    private var running = true
    private var visible = false
    private var width = 0
    private var height = 0
    private var sizeDirty = false
    private var frameRequested = true

    // touched only from this thread
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var eglConfig: EGLConfig? = null
    private var contextReady = false   // context+surface current and renderer.onSurfaceCreated done
    private var lastW = 0
    private var lastH = 0

    // ---------------------------------------------------------------- called from the main thread

    fun setVisible(v: Boolean) {
        lock.withLock {
            visible = v
            if (v) frameRequested = true
            cond.signalAll()
        }
    }

    fun setSize(w: Int, h: Int) {
        lock.withLock {
            width = w
            height = h
            sizeDirty = true
            frameRequested = true
            cond.signalAll()
        }
    }

    fun requestFrame() {
        lock.withLock {
            frameRequested = true
            cond.signalAll()
        }
    }

    /** Stops the loop and waits (bounded) until all GL/EGL resources have been released. */
    fun shutdown() {
        lock.withLock {
            running = false
            cond.signalAll()
        }
        if (currentThread() !== this) {
            try {
                join(1500)
            } catch (e: InterruptedException) {
                currentThread().interrupt()
            }
        }
    }

    // ---------------------------------------------------------------- render thread

    override fun run() {
        try {
            loop()
        } catch (t: Throwable) {
            Log.e(TAG, "render thread failed", t)
        } finally {
            releaseEgl(true)
        }
    }

    private fun loop() {
        while (true) {
            var w = 0
            var h = 0
            var resized = false
            lock.lock()
            try {
                while (running && !(visible && width > 0 && height > 0)) cond.await()
                if (!running) return
                w = width
                h = height
                resized = sizeDirty
                sizeDirty = false
            } finally {
                lock.unlock()
            }

            if (!contextReady) {
                if (!initEgl()) {
                    releaseEgl(false)
                    if (!sleepInterruptibly(1500)) return
                    continue
                }
                renderer.onSurfaceCreated(null, null)
                contextReady = true
                resized = true
            }
            if (resized || w != lastW || h != lastH) {
                lastW = w
                lastH = h
                renderer.onSurfaceChanged(null, w, h)
            }

            renderer.checkReload()
            try {
                renderer.onDrawFrame(null)
            } catch (t: Throwable) {
                Log.e(TAG, "draw failed", t)
            }

            if (!EGL14.eglSwapBuffers(display, eglSurface)) {
                val err = EGL14.eglGetError()
                Log.w(TAG, "eglSwapBuffers failed: 0x" + Integer.toHexString(err))
                if (err == EGL14.EGL_CONTEXT_LOST || err == EGL14.EGL_BAD_CONTEXT) {
                    // GPU reset: rebuild everything and let the renderer re-upload its textures
                    releaseEgl(false)
                } else if (err == EGL14.EGL_BAD_SURFACE || err == EGL14.EGL_BAD_NATIVE_WINDOW) {
                    // the window went away; onSurfaceDestroyed will stop us, until then do not spin
                    releaseEgl(false)
                    if (!sleepInterruptibly(500)) return
                } else if (!sleepInterruptibly(200)) {
                    return
                }
                continue
            }

            // sleep until the next wall-clock second (clock digits change) or until woken
            val ms = 1000L - (System.currentTimeMillis() % 1000L) + 5L
            lock.lock()
            try {
                if (running && visible && !frameRequested) cond.await(ms, TimeUnit.MILLISECONDS)
                frameRequested = false
            } finally {
                lock.unlock()
            }
        }
    }

    /** @return false if the thread should stop. */
    private fun sleepInterruptibly(ms: Long): Boolean {
        lock.lock()
        try {
            if (running) cond.await(ms, TimeUnit.MILLISECONDS)
            return running
        } finally {
            lock.unlock()
        }
    }

    private fun initEgl(): Boolean {
        val surface = holder.surface
        if (surface == null || !surface.isValid) return false

        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (d == EGL14.EGL_NO_DISPLAY) return false
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(d, ver, 0, ver, 1)) return false
        display = d

        val cfgAttr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_DEPTH_SIZE, 0,
            EGL14.EGL_STENCIL_SIZE, 0,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(d, cfgAttr, 0, configs, 0, 1, num, 0) || num[0] < 1) return false
        val cfg = configs[0] ?: return false
        eglConfig = cfg

        val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        val ctx = EGL14.eglCreateContext(d, cfg, EGL14.EGL_NO_CONTEXT, ctxAttr, 0)
        if (ctx == null || ctx == EGL14.EGL_NO_CONTEXT) return false
        eglContext = ctx

        val surfAttr = intArrayOf(EGL14.EGL_NONE)
        val s = EGL14.eglCreateWindowSurface(d, cfg, surface, surfAttr, 0)
        if (s == null || s == EGL14.EGL_NO_SURFACE) return false
        eglSurface = s

        if (!EGL14.eglMakeCurrent(d, s, s, ctx)) return false
        EGL14.eglSwapInterval(d, 1)
        return true
    }

    /**
     * Frees everything created by [initEgl]. [ending] = thread is ending: the renderer's GL
     * objects are deleted while the context is still current.
     */
    private fun releaseEgl(ending: Boolean) {
        if (display != EGL14.EGL_NO_DISPLAY) {
            if (contextReady && eglContext != EGL14.EGL_NO_CONTEXT && ending) {
                try {
                    renderer.release()
                } catch (t: Throwable) {
                    Log.w(TAG, "renderer.release failed", t)
                }
            }
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglContext)
            EGL14.eglTerminate(display)
        }
        display = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
        eglConfig = null
        contextReady = false
        lastW = 0
        lastH = 0
    }

    private companion object {
        const val TAG = "ClockTxGL"
    }
}
