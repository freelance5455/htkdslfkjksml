package com.clocktx.app

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/**
 * Official Android live-wallpaper service. It does not depend on MainActivity being open:
 * the design (wp_cfg.json / wp_bg.img / wp_fg.img in filesDir) is read by the renderer itself,
 * so a restarted service or process simply loads the last applied design again.
 *
 * Engine lifecycle -> render thread:
 *   onSurfaceCreated   -> create ONE WallpaperGLThread bound to the real wallpaper surface
 *   onSurfaceChanged   -> tell the thread the new size
 *   onVisibilityChanged-> wake / put to sleep the thread (no frames while hidden)
 *   onSurfaceDestroyed / onDestroy -> stop the thread, which frees all GL + EGL resources
 */
class ClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = GLEngine()

    inner class GLEngine : Engine() {
        private var thread: WallpaperGLThread? = null
        private var visibleNow = false
        private var surfaceW = 0
        private var surfaceH = 0

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            stopThread() // never two render loops for one engine
            val t = WallpaperGLThread(holder, ClockRenderer(applicationContext))
            t.setVisible(visibleNow)
            if (surfaceW > 0 && surfaceH > 0) t.setSize(surfaceW, surfaceH)
            thread = t
            t.start()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceW = width
            surfaceH = height
            thread?.setSize(width, height)
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            super.onSurfaceRedrawNeeded(holder)
            thread?.requestFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            visibleNow = visible
            thread?.setVisible(visible)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            stopThread()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            stopThread()
            super.onDestroy()
        }

        private fun stopThread() {
            thread?.shutdown()
            thread = null
        }
    }
}
