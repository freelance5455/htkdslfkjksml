package com.clocktx.app

import android.app.Activity
import android.app.WallpaperInfo
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingSave: ByteArray? = null     // .ctxpreset waiting for the "save to" dialog
    private var pendingPreset: ByteArray? = null   // .ctxpreset opened from outside (Telegram, Files, ...)

    private companion object {
        const val REQ_CHOOSER = 77
        const val REQ_SAVE = 78
        const val MAX_PRESET = 20 * 1024 * 1024    // keep in sync with PF.maxFile in index.html
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        // The page is local and needs no file/content URL access (file pickers go through onShowFileChooser).
        s.allowContentAccess = false
        s.allowFileAccess = false
        @Suppress("DEPRECATION")
        s.allowFileAccessFromFileURLs = false
        @Suppress("DEPRECATION")
        s.allowUniversalAccessFromFileURLs = false
        s.mediaPlaybackRequiresUserGesture = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            // Never navigate away from the bundled page (no external sites inside the app).
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != "appassets.androidplatform.net"
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                return try {
                    startActivityForResult(params.createIntent(), REQ_CHOOSER)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        handleViewIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntent(intent)
    }

    /** A .ctxpreset opened from another app: read it (size-limited) and let the page validate + preview it. */
    private fun handleViewIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { ins ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(64 * 1024)
                var total = 0
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_PRESET) {
                        pendingPreset = null
                        web.post { web.evaluateJavascript("window.onPresetTooBig&&window.onPresetTooBig()", null) }
                        return
                    }
                    out.write(buf, 0, n)
                }
                pendingPreset = out.toByteArray()
            }
        } catch (e: Exception) {
            pendingPreset = null
        }
        if (pendingPreset != null) {
            web.post { web.evaluateJavascript("window.onPendingPreset&&window.onPendingPreset()", null) }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_SAVE) {
            val bytes = pendingSave
            pendingSave = null
            var ok = false
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && bytes != null) {
                ok = try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            val cancelled = resultCode != RESULT_OK
            web.evaluateJavascript("window.onPresetSaved&&window.onPresetSaved($ok,$cancelled)", null)
        } else if (requestCode == REQ_CHOOSER) {
            val res = if (resultCode == RESULT_OK && data != null)
                WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCb?.onReceiveValue(res)
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onResume() {
        super.onResume()
        // The system wallpaper picker / settings may have changed the lock wallpaper while we were away.
        pushLockState()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.nativeBack?window.nativeBack():false)") { r ->
            if (r != "true") finish()
        }
    }

    private fun launchPicker() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        i.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, ClockWallpaperService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    // ------------------------------------------------------------------ lock-screen state

    private val lockPrefs by lazy { getSharedPreferences("clocktx_lock", MODE_PRIVATE) }

    private fun isOurs(info: WallpaperInfo?): Boolean =
        info != null && info.packageName == packageName &&
            info.serviceName == ClockWallpaperService::class.java.name

    /** Live-wallpaper info for one screen (FLAG_SYSTEM / FLAG_LOCK). Public API 34+, read by reflection
     *  so older SDKs and vendor builds that lack it simply report "unknown" instead of crashing. */
    private fun liveInfoFor(wm: WallpaperManager, which: Int): Pair<Boolean, WallpaperInfo?> = try {
        val m = WallpaperManager::class.java.getMethod("getWallpaperInfo", Int::class.javaPrimitiveType)
        Pair(true, m.invoke(wm, which) as WallpaperInfo?)
    } catch (e: Exception) {
        Pair(false, null)
    }

    /**
     * Reports whether ClockTx is the live wallpaper on Home / Lock.
     * status: live_on_lock | lost | not_set | likely_ok | unknown
     */
    private fun lockState(): JSONObject {
        val o = JSONObject()
        val wm = WallpaperManager.getInstance(this)
        var homeLive: Boolean? = null
        var lockLive: Boolean? = null
        var lockId = -1
        try {
            lockId = wm.getWallpaperId(WallpaperManager.FLAG_LOCK)
            val sys = liveInfoFor(wm, WallpaperManager.FLAG_SYSTEM)
            val lck = liveInfoFor(wm, WallpaperManager.FLAG_LOCK)
            if (sys.first) homeLive = isOurs(sys.second) else homeLive = isOurs(wm.wallpaperInfo)
            if (lck.first) lockLive = isOurs(lck.second)
        } catch (e: Exception) {
        }
        val hadLive = lockPrefs.getBoolean("lockLiveSeen", false)
        val baseId = lockPrefs.getInt("lockBaselineId", Int.MIN_VALUE)
        val status = when {
            lockLive == true -> {
                lockPrefs.edit().putBoolean("lockLiveSeen", true).putInt("lockBaselineId", lockId).apply()
                "live_on_lock"
            }
            lockLive == false -> if (hadLive) "lost" else "not_set"
            hadLive && baseId != Int.MIN_VALUE -> if (lockId != baseId) "lost" else "likely_ok"
            else -> "unknown"
        }
        o.put("api", Build.VERSION.SDK_INT)
        o.put("brand", Build.MANUFACTURER)
        o.put("homeLive", homeLive ?: JSONObject.NULL)
        o.put("lockLive", lockLive ?: JSONObject.NULL)
        o.put("status", status)
        return o
    }

    private fun pushLockState() {
        val js = "window.onLockState&&window.onLockState(" + lockState().toString() + ")"
        web.post { web.evaluateJavascript(js, null) }
    }

    private fun writeAtomic(name: String, bytes: ByteArray) {
        val tmp = File(filesDir, "$name.tmp")
        tmp.writeBytes(bytes)
        val dst = File(filesDir, name)
        if (!tmp.renameTo(dst)) {
            dst.writeBytes(bytes)
            tmp.delete()
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isApp(): Boolean = true

        @JavascriptInterface
        fun applyWallpaper(cfg: String, bgB64: String, fgB64: String): String {
            return try {
                // images first, config LAST: the wallpaper reloads when wp_cfg.json changes,
                // so it never sees a half-written design.
                writeAtomic("wp_bg.img", Base64.decode(bgB64, Base64.DEFAULT))
                writeAtomic("wp_fg.img", Base64.decode(fgB64, Base64.DEFAULT))
                writeAtomic("wp_cfg.json", cfg.toByteArray(Charsets.UTF_8))
                runOnUiThread { launchPicker() }
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        @JavascriptInterface
        fun setLockImage(pngB64: String): String {
            return try {
                val bytes = Base64.decode(pngB64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                WallpaperManager.getInstance(this@MainActivity)
                    .setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                // the lock screen is now an intentional static image, not the live wallpaper
                lockPrefs.edit().putBoolean("lockLiveSeen", false).apply()
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        /** Current Home/Lock state as JSON (see [lockState]). */
        @JavascriptInterface
        fun getLockState(): String = lockState().toString()

        /** Re-open the system live-wallpaper preview for the already-saved design (no re-export). */
        @JavascriptInterface
        fun openLivePicker(): String {
            if (!File(filesDir, "wp_cfg.json").exists()) return "err:no_design"
            runOnUiThread { launchPicker() }
            return "ok"
        }

        /** User confirms ClockTx is live on the lock screen (needed where Android cannot tell us, API < 34). */
        @JavascriptInterface
        fun confirmLiveOnLock(): String {
            val id = try {
                WallpaperManager.getInstance(this@MainActivity).getWallpaperId(WallpaperManager.FLAG_LOCK)
            } catch (e: Exception) {
                -1
            }
            lockPrefs.edit().putBoolean("lockLiveSeen", true).putInt("lockBaselineId", id).apply()
            return "ok"
        }

        /**
         * Sets a still image on the HOME screen only (FLAG_SYSTEM). Whether the live wallpaper survives
         * on the lock screen is decided by the system / One UI, so the caller re-reads [getLockState] afterwards.
         */
        @JavascriptInterface
        fun setHomeStaticImage(imgB64: String): String {
            return try {
                val wm = WallpaperManager.getInstance(this@MainActivity)
                if (!wm.isWallpaperSupported || !wm.isSetWallpaperAllowed) return "err:not_allowed"
                val bytes = Base64.decode(imgB64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return "err:bad_image"
                wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM)
                bmp.recycle()
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        private fun safeName(n: String): String {
            val t = n.replace(Regex("[^A-Za-z0-9_-]+"), "_").trim('_')
            return (if (t.isEmpty()) "ClockTx-design" else t).take(40)
        }

        /** Opens the system "save to" dialog (Storage Access Framework) for a .ctxpreset. */
        @JavascriptInterface
        fun savePresetToDevice(name: String, b64: String): String {
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (bytes.size > MAX_PRESET) return "err:too_big"
                pendingSave = bytes
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/octet-stream"
                    putExtra(Intent.EXTRA_TITLE, safeName(name) + ".ctxpreset")
                }
                runOnUiThread { startActivityForResult(i, REQ_SAVE) }
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        /** Android Sharesheet (Telegram, Bluetooth, ...) for a .ctxpreset; the file lives in the app cache. */
        @JavascriptInterface
        fun sharePreset(name: String, b64: String): String {
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (bytes.size > MAX_PRESET) return "err:too_big"
                val dir = File(cacheDir, "presets")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, safeName(name) + ".ctxpreset")
                f.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/octet-stream"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(send, "ClockTx")) }
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        /** Returns (once) a preset that was opened from another app, base64; empty string if none. */
        @JavascriptInterface
        fun takePendingPreset(): String {
            val b = pendingPreset ?: return ""
            pendingPreset = null
            return Base64.encodeToString(b, Base64.NO_WRAP)
        }
    }
}
