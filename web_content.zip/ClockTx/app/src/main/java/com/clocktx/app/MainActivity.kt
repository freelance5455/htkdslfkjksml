package com.clocktx.app

import android.app.Activity
import android.app.WallpaperInfo
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowContentAccess = true
        s.mediaPlaybackRequiresUserGesture = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            val res = if (resultCode == RESULT_OK && data != null)
                WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCb?.onReceiveValue(res)
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onResume() {
        super.onResume()
        // The system wallpaper picker / settings may have changed the lock wallpaper while we were away.
        pushLockState()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.nativeBack?window.nativeBack():false)") { r ->
            if (r != "true") finish()
        }
    }

    private fun launchPicker() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        i.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, ClockWallpaperService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    // ------------------------------------------------------------------ lock-screen state

    private val lockPrefs by lazy { getSharedPreferences("clocktx_lock", MODE_PRIVATE) }

    private fun isOurs(info: WallpaperInfo?): Boolean =
        info != null && info.packageName == packageName &&
            info.serviceName == ClockWallpaperService::class.java.name

    /** Live-wallpaper info for one screen (FLAG_SYSTEM / FLAG_LOCK). Public API 34+, read by reflection
     *  so older SDKs and vendor builds that lack it simply report "unknown" instead of crashing. */
    private fun liveInfoFor(wm: WallpaperManager, which: Int): Pair<Boolean, WallpaperInfo?> = try {
        val m = WallpaperManager::class.java.getMethod("getWallpaperInfo", Int::class.javaPrimitiveType)
        Pair(true, m.invoke(wm, which) as WallpaperInfo?)
    } catch (e: Exception) {
        Pair(false, null)
    }

    /**
     * Reports whether ClockTx is the live wallpaper on Home / Lock.
     * status: live_on_lock | lost | not_set | likely_ok | unknown
     */
    private fun lockState(): JSONObject {
        val o = JSONObject()
        val wm = WallpaperManager.getInstance(this)
        var homeLive: Boolean? = null
        var lockLive: Boolean? = null
        var lockId = -1
        try {
            lockId = wm.getWallpaperId(WallpaperManager.FLAG_LOCK)
            val sys = liveInfoFor(wm, WallpaperManager.FLAG_SYSTEM)
            val lck = liveInfoFor(wm, WallpaperManager.FLAG_LOCK)
            if (sys.first) homeLive = isOurs(sys.second) else homeLive = isOurs(wm.wallpaperInfo)
            if (lck.first) lockLive = isOurs(lck.second)
        } catch (e: Exception) {
        }
        val hadLive = lockPrefs.getBoolean("lockLiveSeen", false)
        val baseId = lockPrefs.getInt("lockBaselineId", Int.MIN_VALUE)
        val status = when {
            lockLive == true -> {
                lockPrefs.edit().putBoolean("lockLiveSeen", true).putInt("lockBaselineId", lockId).apply()
                "live_on_lock"
            }
            lockLive == false -> if (hadLive) "lost" else "not_set"
            hadLive && baseId != Int.MIN_VALUE -> if (lockId != baseId) "lost" else "likely_ok"
            else -> "unknown"
        }
        o.put("api", Build.VERSION.SDK_INT)
        o.put("brand", Build.MANUFACTURER)
        o.put("homeLive", homeLive ?: JSONObject.NULL)
        o.put("lockLive", lockLive ?: JSONObject.NULL)
        o.put("status", status)
        return o
    }

    private fun pushLockState() {
        val js = "window.onLockState&&window.onLockState(" + lockState().toString() + ")"
        web.post { web.evaluateJavascript(js, null) }
    }

    private fun writeAtomic(name: String, bytes: ByteArray) {
        val tmp = File(filesDir, "$name.tmp")
        tmp.writeBytes(bytes)
        val dst = File(filesDir, name)
        if (!tmp.renameTo(dst)) {
            dst.writeBytes(bytes)
            tmp.delete()
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isApp(): Boolean = true

        @JavascriptInterface
        fun applyWallpaper(cfg: String, bgB64: String, fgB64: String): String {
            return try {
                // images first, config LAST: the wallpaper reloads when wp_cfg.json changes,
                // so it never sees a half-written design.
                writeAtomic("wp_bg.img", Base64.decode(bgB64, Base64.DEFAULT))
                writeAtomic("wp_fg.img", Base64.decode(fgB64, Base64.DEFAULT))
                writeAtomic("wp_cfg.json", cfg.toByteArray(Charsets.UTF_8))
                runOnUiThread { launchPicker() }
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        @JavascriptInterface
        fun setLockImage(pngB64: String): String {
            return try {
                val bytes = Base64.decode(pngB64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                WallpaperManager.getInstance(this@MainActivity)
                    .setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                // the lock screen is now an intentional static image, not the live wallpaper
                lockPrefs.edit().putBoolean("lockLiveSeen", false).apply()
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }

        /** Current Home/Lock state as JSON (see [lockState]). */
        @JavascriptInterface
        fun getLockState(): String = lockState().toString()

        /** Re-open the system live-wallpaper preview for the already-saved design (no re-export). */
        @JavascriptInterface
        fun openLivePicker(): String {
            if (!File(filesDir, "wp_cfg.json").exists()) return "err:no_design"
            runOnUiThread { launchPicker() }
            return "ok"
        }

        /** User confirms ClockTx is live on the lock screen (needed where Android cannot tell us, API < 34). */
        @JavascriptInterface
        fun confirmLiveOnLock(): String {
            val id = try {
                WallpaperManager.getInstance(this@MainActivity).getWallpaperId(WallpaperManager.FLAG_LOCK)
            } catch (e: Exception) {
                -1
            }
            lockPrefs.edit().putBoolean("lockLiveSeen", true).putInt("lockBaselineId", id).apply()
            return "ok"
        }

        /**
         * Sets a still image on the HOME screen only (FLAG_SYSTEM). Whether the live wallpaper survives
         * on the lock screen is decided by the system / One UI, so the caller re-reads [getLockState] afterwards.
         */
        @JavascriptInterface
        fun setHomeStaticImage(imgB64: String): String {
            return try {
                val wm = WallpaperManager.getInstance(this@MainActivity)
                if (!wm.isWallpaperSupported || !wm.isSetWallpaperAllowed) return "err:not_allowed"
                val bytes = Base64.decode(imgB64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return "err:bad_image"
                wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM)
                bmp.recycle()
                "ok"
            } catch (e: Exception) {
                "err:" + e.message
            }
        }
    }
}
