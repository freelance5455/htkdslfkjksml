package com.clocktx.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.util.Log
import android.os.SystemClock
import androidx.core.graphics.PathParser
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Calendar
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Draws the saved background, the live glass clock (same GLSL as the editor) and the foreground layer.
 * Textures are built at half screen resolution.
 */
class ClockRenderer(private val ctx: Context) : GLSurfaceView.Renderer {

    private var cfg: JSONObject? = null
    private var cfgStamp = 0L
    @Volatile private var reloadFlag = true
    private var glProg = 0
    private var blitProg = 0
    private val tex = IntArray(6)
    private var hasFg = false
    private var sw = 1
    private var sh = 1
    private var tw = 2
    private var th = 2
    private var lastTime = ""
    private val locs = HashMap<String, Int>()
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(32)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }

    private val vs = "attribute vec2 p;varying vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}"
    private val blitFs = "precision mediump float;varying vec2 uv;uniform sampler2D t;void main(){gl_FragColor=texture2D(t,uv);}"

    private val glyphs = mapOf(
        '0' to "M25 50A25 25 0 0 1 75 50V110A25 25 0 0 1 25 110Z",
        '1' to "M34 52L56 28V132",
        '2' to "M26 52A24 24 0 0 1 74 52C74 84 26 104 26 132H76",
        '3' to "M27 46A23 20 0 1 1 73 46C73 66 56 76 46 79C62 81 76 93 76 110A26 24 0 1 1 24 110",
        '4' to "M64 132V28L24 102H78",
        '5' to "M72 29H32L28 72C52 64 76 76 76 103C76 124 60 134 50 134C38 134 29 128 24 118",
        '6' to "M68 31C38 43 25 76 25 108A25 26 0 1 0 75 108A25 26 0 1 0 25 108",
        '7' to "M25 29H75L46 132",
        '8' to "M50 80A22 24 0 1 1 50 31A22 24 0 1 1 50 80A26 26 0 1 1 50 133A26 26 0 1 1 50 80",
        '9' to "M32 129C62 117 75 84 75 52A25 26 0 1 0 25 52A25 26 0 1 0 75 52"
    )

    fun checkReload() {
        val f = File(ctx.filesDir, "wp_cfg.json")
        if (f.exists() && f.lastModified() != cfgStamp) reloadFlag = true
    }

    /** Free GL objects. Must be called on the GL thread while the context is still current. */
    fun release() {
        if (glProg != 0) GLES20.glDeleteProgram(glProg)
        if (blitProg != 0) GLES20.glDeleteProgram(blitProg)
        GLES20.glDeleteTextures(tex.size, tex, 0)
        glProg = 0
        blitProg = 0
        locs.clear()
        cfg = null
        hasFg = false
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glGenTextures(tex.size, tex, 0)
        for (t in tex) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }
        blitProg = link(vs, blitFs)
        glProg = 0
        locs.clear()
        cfgStamp = 0
        reloadFlag = true
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        sw = width
        sh = height
        tw = max(2, width / 2)
        th = max(2, height / 2)
        GLES20.glViewport(0, 0, sw, sh)
        reloadFlag = true
    }

    override fun onDrawFrame(gl: GL10?) {
        if (reloadFlag) {
            reloadFlag = false
            try {
                reload()
            } catch (e: Exception) {
                Log.e(TAG, "reload failed", e)
                cfg = null
            }
        }
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val c = cfg ?: return
        val t = timeStr(c)
        if (t != lastTime) {
            lastTime = t
            try {
                buildMasks(c)
            } catch (e: Exception) {
            }
        }
        GLES20.glViewport(0, 0, sw, sh)
        GLES20.glDisable(GLES20.GL_BLEND)
        blit(0)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        drawGlass(c)
        if (hasFg) blit(5)
    }

    private fun reload() {
        val f = File(ctx.filesDir, "wp_cfg.json")
        if (!f.exists()) {
            cfg = null
            return
        }
        val c = JSONObject(f.readText())
        cfgStamp = f.lastModified()
        if (glProg != 0) GLES20.glDeleteProgram(glProg)
        glProg = link(vs, c.getString("frag"))
        locs.clear()
        val uPS = tw.toFloat() / c.getDouble("stageW").toFloat()
        val bgSrc = decodeScaled(File(ctx.filesDir, "wp_bg.img").path)
        if (bgSrc != null) {
            val bg = fit(bgSrc)
            bgSrc.recycle()
            upload(0, bg)
            val bl = blur(bg, (c.getDouble("bb") * uPS).toFloat())
            upload(1, bl)
            bg.recycle()
            bl.recycle()
        }
        val fgSrc = decodeScaled(File(ctx.filesDir, "wp_fg.img").path)
        hasFg = fgSrc != null
        if (fgSrc != null) {
            val fg = fit(fgSrc)
            fgSrc.recycle()
            upload(5, fg)
            fg.recycle()
        }
        lastTime = ""
        cfg = c
    }

    private fun buildMasks(c: JSONObject) {
        val uPS = tw.toFloat() / c.getDouble("stageW").toFloat()
        val m = glyphBitmap(c)
        upload(2, m)
        val h = blur(m, (c.getDouble("hb") * uPS * 0.5).toFloat())
        upload(3, h)
        h.recycle()
        val sd = blur(m, (c.getDouble("sb") * uPS * 0.5).toFloat())
        upload(4, sd)
        sd.recycle()
        m.recycle()
    }

    private fun drawGlass(c: JSONObject) {
        if (glProg == 0) return
        GLES20.glUseProgram(glProg)
        val names = arrayOf("uBG", "uBL", "uM", "uH", "uS")
        for (i in names.indices) GLES20.glUniform1i(loc(names[i]), i)
        val arr = c.getJSONArray("params")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val l = loc("u_" + o.getString("id"))
            if (o.getInt("c") == 1) {
                val col = Color.parseColor(o.getString("v"))
                GLES20.glUniform3f(l, Color.red(col) / 255f, Color.green(col) / 255f, Color.blue(col) / 255f)
            } else {
                GLES20.glUniform1f(l, o.getDouble("v").toFloat())
            }
        }
        val b = c.getJSONObject("box")
        GLES20.glUniform2f(loc("uRes"), tw.toFloat(), th.toFloat())
        GLES20.glUniform2f(
            loc("uC"),
            (b.getDouble("x") + b.getDouble("w") / 2).toFloat(),
            (1.0 - (b.getDouble("y") + b.getDouble("h") / 2)).toFloat()
        )
        GLES20.glUniform1f(loc("uT"), (SystemClock.uptimeMillis() % 100000L) / 1000f)
        GLES20.glUniform1f(loc("uPS"), tw.toFloat() / c.getDouble("stageW").toFloat())
        drawQuad()
    }

    private fun blit(unit: Int) {
        if (blitProg == 0) return
        GLES20.glUseProgram(blitProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[unit])
        GLES20.glUniform1i(GLES20.glGetUniformLocation(blitProg, "t"), unit)
        drawQuad()
    }

    private fun drawQuad() {
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun loc(name: String): Int = locs.getOrPut(name) { GLES20.glGetUniformLocation(glProg, name) }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(TAG, "shader compile failed: " + GLES20.glGetShaderInfoLog(s))
            GLES20.glDeleteShader(s)
            return 0
        }
        return s
    }

    /** @return program id, or 0 if compiling/linking failed (nothing is drawn with it then). */
    private fun link(v: String, f: String): Int {
        val vsh = compile(GLES20.GL_VERTEX_SHADER, v)
        val fsh = compile(GLES20.GL_FRAGMENT_SHADER, f)
        if (vsh == 0 || fsh == 0) {
            if (vsh != 0) GLES20.glDeleteShader(vsh)
            if (fsh != 0) GLES20.glDeleteShader(fsh)
            return 0
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vsh)
        GLES20.glAttachShader(p, fsh)
        GLES20.glBindAttribLocation(p, 0, "p")
        GLES20.glLinkProgram(p)
        GLES20.glDeleteShader(vsh)
        GLES20.glDeleteShader(fsh)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(TAG, "program link failed: " + GLES20.glGetProgramInfoLog(p))
            GLES20.glDeleteProgram(p)
            return 0
        }
        return p
    }

    /** Decode a saved image, down-sampled so it is never much larger than the render target. */
    private fun decodeScaled(path: String): Bitmap? {
        if (!File(path).exists()) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= tw && o.outHeight / (sample * 2) >= th) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return try {
            BitmapFactory.decodeFile(path, o2)
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "image too large", e)
            null
        }
    }

    /** Flip vertically (GL origin is bottom-left) and upload into texture unit [i]. */
    private fun upload(i: Int, src: Bitmap) {
        val m = Matrix()
        m.postScale(1f, -1f)
        val flipped = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, false)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + i)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[i])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, flipped, 0)
        flipped.recycle()
    }

    private fun fit(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val ta = tw.toFloat() / th
        val sa = src.width.toFloat() / src.height
        val r = if (sa > ta) {
            val w = (src.height * ta).toInt()
            Rect((src.width - w) / 2, 0, (src.width + w) / 2, src.height)
        } else {
            val h = (src.width / ta).toInt()
            Rect(0, (src.height - h) / 2, src.width, (src.height + h) / 2)
        }
        cv.drawBitmap(src, r, Rect(0, 0, tw, th), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun timeStr(c: JSONObject): String {
        val cal = Calendar.getInstance()
        var h = cal.get(Calendar.HOUR_OF_DAY)
        if (!c.getBoolean("h24")) h = if (h % 12 == 0) 12 else h % 12
        var s = String.format(Locale.US, "%02d:%02d", h, cal.get(Calendar.MINUTE))
        if (c.getBoolean("sec")) s += String.format(Locale.US, ":%02d", cal.get(Calendar.SECOND))
        return s
    }

    /** Same capsule digits as the editor, drawn as white strokes. */
    private fun glyphBitmap(c: JSONObject): Bitmap {
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val b = c.getJSONObject("box")
        val cw = (b.getDouble("w") * tw).toFloat()
        val ch = (b.getDouble("h") * th).toFloat()
        cv.save()
        cv.translate(
            ((b.getDouble("x") + b.getDouble("w") / 2) * tw).toFloat(),
            ((b.getDouble("y") + b.getDouble("h") / 2) * th).toFloat()
        )
        cv.rotate(b.getDouble("r").toFloat())
        cv.translate(-cw / 2f, -ch / 2f)

        val str = timeStr(c)
        val thk = c.getDouble("thk").toFloat()
        val sp = c.getDouble("sp").toFloat()
        val ad = 86f + sp
        val ac = 46f
        var x = 0f
        var last = 0f
        val xs = ArrayList<Float>()
        for (k in str) {
            xs.add(x)
            last = x
            x += if (k == ':') ac else ad
        }
        val span = last + 75f - 25f
        val sxu = cw / (span + thk)
        val t = thk * sxu
        val syu = (ch - t) / 110f

        val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = t
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.color = Color.WHITE
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.style = Paint.Style.FILL
        fill.color = Color.WHITE

        for (i in str.indices) {
            val k = str[i]
            val tx = (xs[i] - 25f) * sxu + t / 2f
            val ty = t / 2f - 25f * syu
            if (k == ':') {
                cv.drawCircle(tx + 31f * sxu, ty + 58f * syu, t / 2f, fill)
                cv.drawCircle(tx + 31f * sxu, ty + 102f * syu, t / 2f, fill)
            } else {
                val d = glyphs[k] ?: continue
                val path = PathParser.createPathFromPathData(d)
                val m = Matrix()
                m.setScale(sxu, syu)
                m.postTranslate(tx, ty)
                path.transform(m)
                cv.drawPath(path, stroke)
            }
        }
        cv.restore()
        return bmp
    }

    private companion object {
        const val TAG = "ClockTxRenderer"
    }

    // ---- 3-pass box blur approximating a gaussian of the given sigma ----
    private fun blur(src: Bitmap, sigma: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        if (sigma > 0.3f) {
            val r = (((sqrt(4f * sigma * sigma + 1f) - 1f) / 2f) + 0.5f).toInt().coerceAtLeast(1)
            for (n in 0 until 3) {
                boxPass(px, w, h, r, true)
                boxPass(px, w, h, r, false)
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun boxPass(px: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
        val n = if (horiz) w else h
        val lines = if (horiz) h else w
        val step = if (horiz) 1 else w
        val tmp = IntArray(n)
        val div = 2 * r + 1
        for (l in 0 until lines) {
            val base = if (horiz) l * w else l
            for (ch in 0 until 4) {
                val sh = ch * 8
                var sum = 0
                for (i in -r..r) {
                    val k = i.coerceIn(0, n - 1)
                    sum += (px[base + k * step] ushr sh) and 255
                }
                for (i in 0 until n) {
                    tmp[i] = sum / div
                    val add = (i + r + 1).coerceAtMost(n - 1)
                    val rem = (i - r).coerceAtLeast(0)
                    sum += ((px[base + add * step] ushr sh) and 255) - ((px[base + rem * step] ushr sh) and 255)
                }
                val keep = (255 shl sh).inv()
                for (i in 0 until n) {
                    val idx = base + i * step
                    px[idx] = (px[idx] and keep) or (tmp[i] shl sh)
                }
            }
        }
    }
}
