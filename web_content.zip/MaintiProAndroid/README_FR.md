# SNCN Android — projet version 2.0

Ce dossier contient un projet Android Studio qui embarque l'application SNCN dans une WebView locale. Les écrans et fonctions principales sont disponibles sans connexion Internet une fois l'application installée.

## Fonctions incluses
- Parc machines et composants
- Interventions / ordres de travail, techniciens, durées, arrêts et coûts
- Planification préventive et échéances signalées à l'ouverture
- Stock de pièces, seuils minimums, entrées et sorties
- Tableau de bord et rapports filtrables
- Export JSON et CSV vers le dossier Téléchargements/SNCN sur Android récent
- Import de sauvegarde via le sélecteur de fichiers Android

## Générer un APK avec Android Studio
1. Décompressez le ZIP sur un ordinateur.
2. Installez Android Studio et un JDK 17.
3. Ouvrez le dossier `SNCNAndroid` dans Android Studio.
4. Autorisez Gradle à synchroniser le projet et installez Android SDK Platform 35 si Android Studio le demande.
5. Dans le menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Le fichier de test sera normalement créé dans `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur un téléphone
Transférez `app-debug.apk` sur le téléphone Android et ouvrez-le pour l'installer. Android peut demander d'autoriser l'installation depuis cette source. Ne partagez l'APK qu'avec des personnes de confiance.

## Stockage et limites
Les données sont conservées dans le stockage local du navigateur intégré à l'application. Elles ne sont pas synchronisées entre appareils et ne sont pas protégées par un système de comptes. Exportez des sauvegardes régulièrement. Cette archive contient le projet source prêt à être compilé, pas un APK déjà compilé.

## Compatibilité
- Android 8.0 ou plus récent (API 26+)
- JDK 17
- Android SDK Platform 35
