#!/usr/bin/env python3
"""
Formato de Justificación — servidor mínimo (alternativa a api.php).
Sirve la app (index.html y demás archivos de esta carpeta) y guarda los
formatos por ticket en ./datos, con la MISMA API que api.php.

Uso:  python3 servidor.py [puerto]     (puerto por defecto: 8080)
Luego abre en el navegador:  http://<IP-de-tu-NAS>:8080/

Sin dependencias: solo la librería estándar de Python 3.
"""
import json
import re
import sys
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).resolve().parent
DATOS = BASE / "datos"
DATOS.mkdir(exist_ok=True)


def keyfile(key: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(key))
    if safe in ("", ".", ".."):
        safe = "sin_ticket"
    return DATOS / f"{safe}.json"


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)

    def log_message(self, *args):  # consola limpia
        pass

    def _json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        raw = self.rfile.read(n) if n > 0 else b""
        try:
            return json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            return {}

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/api.php":
            action = (parse_qs(u.query).get("action") or [""])[0]
            if action == "ping":
                return self._json({"ok": True, "mode": "nas-python"})
            if action == "list":
                out = []
                for f in sorted(DATOS.glob("*.json")):
                    try:
                        rec = json.loads(f.read_text(encoding="utf-8"))
                    except Exception:
                        continue
                    if isinstance(rec, dict) and "data" in rec:
                        out.append({
                            "key": rec.get("key", f.stem),
                            "data": rec["data"],
                            "savedAt": rec.get("savedAt"),
                        })
                return self._json({"ok": True, "formatos": out})
            return self._json({"ok": False, "error": "Acción no válida"}, 400)
        return super().do_GET()

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/api.php":
            return self._json({"ok": False, "error": "Ruta no válida"}, 404)
        body = self._read_body()
        action = body.get("action", "")
        if action == "save":
            key = str(body.get("key", "")).strip()
            if not key:
                return self._json({"ok": False, "error": "Falta el ticket"}, 400)
            rec = {
                "key": key,
                "data": body.get("data", {}),
                "savedAt": body.get("savedAt") or datetime.now(timezone.utc).isoformat(),
            }
            keyfile(key).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
            return self._json({"ok": True})
        if action == "delete":
            f = keyfile(body.get("key", ""))
            if f.is_file():
                f.unlink()
            return self._json({"ok": True})
        return self._json({"ok": False, "error": "Acción no válida"}, 400)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"Formato de Justificación sirviendo en http://0.0.0.0:{port}/  (Ctrl+C para detener)")
    srv.serve_forever()
