// ============================================================
//  Formato de Justificación — configuración OPCIONAL
// ============================================================
//  Google Drive (opcional):
//  Si quieres que la app también sincronice tus formatos con tu
//  Google Drive cuando la montes en tu NAS, necesitas TU propio
//  "Client ID" de Google (es gratis, se crea en 5 minutos —
//  los pasos están en LEEME.txt) y pegar aquí su valor.
//
//  Déjalo vacío ("") si no lo vas a usar: la app guarda en tu
//  NAS (o en el dispositivo) y todo lo demás funciona igual.
//
//  OJO: Google solo permite iniciar sesión desde direcciones
//  HTTPS (o localhost). Si entras a tu NAS por http://192.168.x.x,
//  el guardado en el NAS funciona perfecto, pero el inicio de
//  sesión de Drive NO: para Drive usa el acceso HTTPS de tu NAS
//  (DDNS + certificado, p. ej. https://tunombre.synology.me).
// ============================================================
window.FJ_CONFIG = {
  driveClientId: ""
};
