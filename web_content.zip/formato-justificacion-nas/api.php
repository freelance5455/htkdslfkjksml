<?php
// Formato de Justificación — API mínima para guardar formatos por ticket en ESTE servidor (NAS).
// Guarda un archivo JSON por ticket en la carpeta /datos junto a este archivo.
// Sin base de datos, sin dependencias: solo PHP estándar.
header('Content-Type: application/json; charset=utf-8');

$dir = __DIR__ . '/datos';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }

function fj_keyfile($dir, $key) {
    $safe = preg_replace('/[^A-Za-z0-9._-]/', '_', (string)$key);
    if ($safe === '' || $safe === '.' || $safe === '..') { $safe = 'sin_ticket'; }
    return $dir . '/' . $safe . '.json';
}

$raw  = file_get_contents('php://input');
$body = $raw ? json_decode($raw, true) : null;
$action = isset($_GET['action']) ? $_GET['action'] : '';
if (is_array($body) && isset($body['action'])) { $action = $body['action']; }

switch ($action) {
    case 'ping':
        echo json_encode(['ok' => true, 'mode' => 'nas-php']);
        break;

    case 'list':
        $out = [];
        foreach (glob($dir . '/*.json') as $f) {
            $rec = json_decode(@file_get_contents($f), true);
            if (is_array($rec) && isset($rec['data'])) {
                $out[] = [
                    'key'     => isset($rec['key']) ? $rec['key'] : basename($f, '.json'),
                    'data'    => $rec['data'],
                    'savedAt' => isset($rec['savedAt']) ? $rec['savedAt'] : null
                ];
            }
        }
        echo json_encode(['ok' => true, 'formatos' => $out], JSON_UNESCAPED_UNICODE);
        break;

    case 'save':
        $key = is_array($body) && isset($body['key']) ? trim((string)$body['key']) : '';
        if ($key === '') {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Falta el ticket']);
            break;
        }
        $rec = [
            'key'     => $key,
            'data'    => isset($body['data']) ? $body['data'] : [],
            'savedAt' => isset($body['savedAt']) ? $body['savedAt'] : date('c')
        ];
        $ok = @file_put_contents(fj_keyfile($dir, $key), json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        if ($ok === false) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => 'No se pudo escribir en /datos (revisa permisos de la carpeta)']);
        } else {
            echo json_encode(['ok' => true]);
        }
        break;

    case 'delete':
        $key = is_array($body) && isset($body['key']) ? (string)$body['key'] : '';
        $f = fj_keyfile($dir, $key);
        if (is_file($f)) { @unlink($f); }
        echo json_encode(['ok' => true]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Acción no válida']);
}
