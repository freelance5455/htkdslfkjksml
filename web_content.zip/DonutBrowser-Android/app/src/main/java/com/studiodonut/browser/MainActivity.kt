package com.studiodonut.browser

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private data class BrowserTab(var title: String, val web: WebView)
    private val tabs = mutableListOf<BrowserTab>()
    private var active = 0
    private lateinit var tabStrip: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var address: EditText
    private lateinit var backButton: TextView
    private lateinit var forwardButton: TextView

    private val bg = Color.rgb(13, 11, 24)
    private val panel = Color.rgb(23, 19, 34)
    private val purple = Color.rgb(124, 58, 237)
    private val text = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 7, 17)
        window.navigationBarColor = Color.rgb(9, 7, 17)
        buildInterface()
        addTab()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }

        val tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(9, 7, 17))
        }
        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
        tabScroll.addView(tabStrip)
        root.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(48)))

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            setBackgroundColor(panel)
        }

        backButton = toolButton("‹") { goBack() }
        forwardButton = toolButton("›") { goForward() }
        toolbar.addView(backButton, LinearLayout.LayoutParams(dp(38), dp(40)))
        toolbar.addView(forwardButton, LinearLayout.LayoutParams(dp(38), dp(40)))
        toolbar.addView(toolButton("↻") { currentWeb()?.reload() }, LinearLayout.LayoutParams(dp(38), dp(40)))
        toolbar.addView(toolButton("⌂") { showHome() }, LinearLayout.LayoutParams(dp(38), dp(40)))

        address = EditText(this).apply {
            setSingleLine(true)
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(153, 143, 171))
            hint = "Search or enter website"
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(15, 12, 25), Color.rgb(68, 48, 103), 24)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                    navigate(address.text.toString())
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(windowToken, 0)
                    true
                } else false
            }
        }
        toolbar.addView(address, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            leftMargin = dp(7)
        })
        root.addView(toolbar)

        content = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun toolButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(41, 35, 59), Color.TRANSPARENT, 10)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun rounded(color: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    private fun addTab() {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: ""
                return if (scheme == "http" || scheme == "https") false else {
                    try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (_: Exception) {}
                    true
                }
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (tabs.getOrNull(active)?.web === view && !url.isNullOrBlank() &&
                    (url.startsWith("http://") || url.startsWith("https://"))) {
                    address.setText(url)
                }
                updateNavButtons()
            }
            override fun onPageFinished(view: WebView, url: String?) {
                updateNavButtons()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView, title: String?) {
                val tab = tabs.firstOrNull { it.web === view } ?: return
                tab.title = title?.take(24)?.ifBlank { "Web Page" } ?: "Web Page"
                if (tabs.getOrNull(active) === tab) renderTabs()
            }
        }
        tabs.add(BrowserTab("Donut Home", web))
        web.loadUrl("file:///android_asset/home.html")
        active = tabs.lastIndex
        showActive()
    }

    private fun renderTabs() {
        tabStrip.removeAllViews()
        tabs.forEachIndexed { index, tab ->
            val chip = TextView(this).apply {
                text = (if (index == active) "● " else "") + tab.title + "  ×"
                textSize = 12f
                setTextColor(if (index == active) Color.WHITE else Color.rgb(217, 212, 232))
                setPadding(dp(13), dp(10), dp(13), dp(10))
                background = rounded(if (index == active) Color.rgb(58, 40, 89) else Color.rgb(27, 23, 40), Color.TRANSPARENT, 10)
                setOnClickListener { active = index; showActive() }
                setOnLongClickListener { closeTab(index); true }
            }
            tabStrip.addView(chip, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        }
        val plus = TextView(this).apply {
            text = "+"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener { addTab() }
        }
        tabStrip.addView(plus, LinearLayout.LayoutParams(dp(42), dp(38)))
    }

    private fun showActive() {
        content.removeAllViews()
        val web = currentWeb() ?: return
        (web.parent as? ViewGroup)?.removeView(web)
        content.addView(web, FrameLayout.LayoutParams(-1, -1))
        val current = web.url.orEmpty()
        address.setText(if (current.startsWith("http")) current else "")
        renderTabs()
        updateNavButtons()
    }

    private fun currentWeb(): WebView? = tabs.getOrNull(active)?.web

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            currentWeb()?.stopLoading()
            currentWeb()?.loadUrl("file:///android_asset/home.html")
            tabs[0].title = "Donut Home"
            showActive()
            return
        }
        val removed = tabs.removeAt(index)
        removed.web.stopLoading()
        removed.web.destroy()
        if (active >= tabs.size) active = tabs.lastIndex
        else if (index < active) active--
        showActive()
    }

    private fun navigate(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = when {
            value.matches(Regex("(?i)^https?://.*")) -> value
            value.matches(Regex("^[^\\s]+\\.[^\\s]+$")) -> "https://$value"
            else -> "https://www.google.com/search?q=" + Uri.encode(value)
        }
        val tab = tabs[active]
        tab.title = if (url.contains("google.com/search")) "Search" else value.take(24)
        tab.web.loadUrl(url)
        renderTabs()
    }

    private fun showHome() {
        val tab = tabs[active]
        tab.title = "Donut Home"
        tab.web.loadUrl("file:///android_asset/home.html")
        address.setText("")
        renderTabs()
    }

    private fun goBack() {
        currentWeb()?.let { if (it.canGoBack()) it.goBack() }
    }

    private fun goForward() {
        currentWeb()?.let { if (it.canGoForward()) it.goForward() }
    }

    private fun updateNavButtons() {
        val web = currentWeb()
        backButton.alpha = if (web?.canGoBack() == true) 1f else 0.45f
        forwardButton.alpha = if (web?.canGoForward() == true) 1f else 0.45f
    }

    override fun onBackPressed() {
        val web = currentWeb()
        if (web?.canGoBack() == true) web.goBack() else showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
