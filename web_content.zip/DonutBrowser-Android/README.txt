# Donut Browser — Android Edition (source project)

This is an Android Studio project adapted from the supplied original Donut Browser project and its purple/dark visual identity.

## Included
- Native Android app shell (Kotlin)
- Android WebView for real website browsing
- Address/search bar (Google search for ordinary search terms)
- Back, forward, reload and home controls
- Multiple tabs (tap a tab to switch; long-press a tab to close it; + creates a tab)
- Responsive Donut home screen and supplied Donut Browser logo
- Original desktop `index.html` and `package.json` preserved in `original-desktop-source/` for reference

## Build it
1. Install Android Studio on a computer that supports it, with Android SDK Platform 33 and Java 11 support.
2. Open the `DonutBrowser-Android` folder in Android Studio (choose **Open**, not Import).
3. Allow Gradle sync to finish. The project uses Android Gradle Plugin 7.4.2, Kotlin 1.8.10 and Gradle 7.6.
4. Select an Android phone or emulator, then press **Run**.
5. To create an installable APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the APK location.

## Important notes
- This ZIP contains the Android Studio source project, not a prebuilt APK.
- The project has not been compiled on a device in this environment. Website browsing uses Android System WebView, so site compatibility can vary by website.
- Android Studio / SDK versions compatible with an older macOS release may be limited. If Gradle sync or Android Studio will not run on the old iMac, build this same ZIP on a supported computer.
- This first mobile build does not include Studio Helper AI yet. We can add it after the browser itself is tested.
- The original desktop files in `original-desktop-source/` are reference copies and are not used by the Android app.
