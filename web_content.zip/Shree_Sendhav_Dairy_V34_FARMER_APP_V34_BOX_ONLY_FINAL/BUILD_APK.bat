@echo off
cd /d "%~dp0"
where gradle >nul 2>nul
if %errorlevel%==0 ( gradle assembleDebug ) else ( echo Gradle not found. Open this project in Android Studio and Build APK. )
pause
