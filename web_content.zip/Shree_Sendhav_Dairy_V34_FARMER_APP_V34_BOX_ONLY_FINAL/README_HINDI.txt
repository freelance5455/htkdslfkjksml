SHREE SENDHAV DAIRY V34 - FARMER APP

Base: Shree Sendhav Dairy V34 Desktop.
Sync: V34 Desktop + V34 Mobile -> Firebase -> Farmer App realtime.
Farmer App is READ ONLY. Farmer can only submit complaints.

LOGIN:
Plant select + Farmer Code + 4-digit PIN. Code/PIN is generated/managed from V34 Desktop/Mobile Farmer Master.

IMPORTANT FIREBASE:
Firebase Authentication -> Sign-in method -> Anonymous must be enabled, because Farmer App signs in anonymously and then uses the secure V34 loginIndex/session rules.

Data shown after login:
- Farmer name, code, mobile number
- Morning/Evening Buffalo/Cow milk, FAT, SNF/CLR, amount
- Farmer product purchases
- Advance, installment, running payment, AD, cut-off
- 10-day current bill
- Complaint box: milk/FAT/SNF/other complaint

SYNC BEHAVIOR:
Desktop V34 is source of truth. When Desktop/Mobile edits or deletes old data, Farmer Portal is rebuilt from current V34 data. Farmer App realtime listeners show only current records; deleted/old records disappear automatically. Plant data is isolated: main, arandiya, narsinggarh.

BUILD:
Open this folder in Android Studio, Gradle Sync, Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk


FIXED: Firebase Web API key corrected to the V34 project key. Farmer login uses Plant + Farmer Code + 4 digit PIN.
