import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Volume2, VolumeX, Moon, Sun, Battery, Wifi, Signal } from 'lucide-react';
import { soundManager, triggerHaptic } from '../utils/haptics';

interface AndroidShellProps {
  children: React.ReactNode;
  companyName: string;
}

export const AndroidShell: React.FC<AndroidShellProps> = ({ children, companyName }) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<string>('09:41');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isDark, setIsDark] = useState<boolean>(true);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 30000);
    return () => clearInterval(timer);
  }, []);

  const toggleSound = () => {
    triggerHaptic('light');
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.enabled = next;
  };

  const toggleTheme = () => {
    triggerHaptic('light');
    setIsDark(!isDark);
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 ${isDark ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'} flex flex-col items-center justify-start p-0 sm:p-4 md:p-6`}>
      {/* Top Universal Control Strip */}
      <div className="w-full max-w-5xl flex items-center justify-between px-3 py-2 mb-2 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md rounded-xl border border-slate-200 dark:border-slate-800 text-xs shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-xs tracking-tighter shadow-sm">
            K
          </div>
          <span className="font-bold text-slate-800 dark:text-slate-100 tracking-tight hidden sm:inline">
            Keshri Nandan
          </span>
          <span className="text-slate-400 dark:text-slate-500 hidden sm:inline">·</span>\n          <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300">हिंदी | English</span>
          <span className="text-slate-600 dark:text-slate-400 truncate max-w-[180px] sm:max-w-xs font-medium">
            {companyName}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Phone Frame Toggle */}
          <button
            onClick={() => {
              triggerHaptic('light');
              setIsPhoneFrame(!isPhoneFrame);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              isPhoneFrame
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
            title="Toggle Android Device Frame view"
          >
            {isPhoneFrame ? <Smartphone className="w-3.5 h-3.5" /> : <Monitor className="w-3.5 h-3.5" />}
            <span className="hidden xs:inline">{isPhoneFrame ? 'Phone Frame' : 'Full Screen'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-emerald-600 transition-colors"
            title={soundEnabled ? 'Mute sound' : 'Enable sound'}
            aria-label="Toggle Sound"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-amber-500 transition-colors"
            title={isDark ? 'Light mode' : 'Dark mode'}
            aria-label="Toggle Theme"
          >
            {isDark ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Container: Android Phone Mockup or Responsive Canvas */}
      <div
        className={`w-full transition-all duration-300 ${
          isPhoneFrame
            ? 'max-w-[420px] rounded-[44px] shadow-2xl border-[10px] border-slate-900 dark:border-slate-800 overflow-hidden bg-slate-900 relative ring-1 ring-slate-800/40 my-auto'
            : 'max-w-4xl rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl overflow-hidden'
        }`}
        style={isPhoneFrame ? { minHeight: '840px', maxHeight: '92vh', display: 'flex', flexDirection: 'column' } : { minHeight: '80vh' }}
      >
        {/* Android Status Bar (Shown in Phone Frame) */}
        {isPhoneFrame && (
          <div className="bg-emerald-950 text-emerald-100 px-5 pt-3 pb-1 flex items-center justify-between text-[11px] font-medium tracking-tight select-none shrink-0 z-50">
            {/* Left: Clock */}
            <span className="font-semibold">{currentTime}</span>

            {/* Center: Punch-hole camera & speaker */}
            <div className="flex items-center gap-1.5">
              <div className="w-3.5 h-3.5 rounded-full bg-black ring-1 ring-slate-800"></div>
            </div>

            {/* Right: Network, Wi-Fi, Battery */}
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-bold tracking-wider">5G</span>
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px]">98%</span>
                <Battery className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>
        )}

        {/* Content Viewport */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col relative bg-slate-50 dark:bg-slate-950">
          {children}
        </div>

        {/* Android Bottom Navigation Pill (in phone frame) */}
        {isPhoneFrame && (
          <div className="h-4 bg-slate-900 dark:bg-slate-950 flex items-center justify-center shrink-0 select-none pb-1">
            <div className="w-28 h-1 rounded-full bg-slate-500/70"></div>
          </div>
        )}
      </div>
    </div>
  );
};
