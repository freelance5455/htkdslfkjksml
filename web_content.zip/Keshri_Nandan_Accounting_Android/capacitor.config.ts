import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'in.keshrinandan.accounting',
  appName: 'Keshri Nandan Accounting',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: { backgroundColor: '#020617' }
};

export default config;
