# Keshri Nandan Accounting

Android-ready Tally-style accounting app for **Keshri Nandan Infra Structure**.

Features include GST sales/purchase vouchers, payment/receipt/contra/journal entries, ledgers, stock, Day Book, Trial Balance, Balance Sheet, Profit & Loss, GST reports, data backup and invoice preview.

## Run
```bash
npm install
npm run dev
```

## Build Android
See [ANDROID_BUILD_GUIDE_HI_EN.md](./ANDROID_BUILD_GUIDE_HI_EN.md).
