# Keshri Nandan Accounting – Android Build Guide

## App identity
- App name: Keshri Nandan Accounting
- Company: Keshri Nandan Infra Structure
- Package ID: `in.keshrinandan.accounting`
- Currency: INR (₹)
- GST: Indian GST voucher and report support

## Build APK (Windows)
1. Install Node.js LTS and Android Studio.
2. Extract this ZIP.
3. Open a terminal in this project folder and run:
   `npm install`
4. Build the web app:
   `npm run build`
5. Add the Android project:
   `npx cap add android`
6. Copy the built app into Android:
   `npx cap sync android`
7. Open Android Studio:
   `npx cap open android`
8. In Android Studio select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
9. The debug APK is usually at `android/app/build/outputs/apk/debug/app-debug.apk`.

## हिंदी में
1. Node.js LTS और Android Studio इंस्टॉल करें।
2. ZIP फ़ाइल को Extract करें।
3. इस फ़ोल्डर में Terminal खोलकर `npm install` चलाएँ।
4. `npm run build` चलाएँ।
5. `npx cap add android` चलाएँ।
6. `npx cap sync android` चलाएँ।
7. `npx cap open android` से Android Studio खोलें।
8. Android Studio में **Build > Build Bundle(s) / APK(s) > Build APK(s)** चुनें।

## Important notes
- This ZIP is the Android-ready source project, not a signed production APK.
- Enter your actual GSTIN, PAN, address and contact details in Company settings before issuing tax invoices.
- Accounting sample ledgers and stock items are demo data. Review and replace them before live bookkeeping.
- GST rates and tax treatment should be verified for each HSN/SAC and transaction by your tax professional.
- Local browser storage is used by the current app. Configure backups and test restore before relying on it for business records.
