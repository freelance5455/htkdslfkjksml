LAKSH CLASSES — STARTER DEMO

Run:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Open Admin Panel to add live/recorded class links, notes, and MCQ tests.

What works in this demo:
- Student-facing classes, notes, tests screens
- Add class links (Google Meet/Zoom/YouTube etc.)
- Select notes files and open them during the current browser session
- Create and take MCQ tests
- Demo premium gating and ₹11 / 2-month subscription display

Important limitations:
- This is a browser prototype, not a production app.
- No real payment is collected; the premium button is intentionally a demo.
- Files/content are not shared between devices/users and are not stored in a cloud database.
- Admin panel has no login/security.
- Live lecture streaming requires a video/meeting provider.
- Before launch, connect authentication, cloud storage/database, a server-verified payment gateway, secure admin roles, and subscription expiry checks.
- Use your own authorized teaching content and comply with applicable privacy/payment rules.

Supabase docs for authentication, database and storage:
https://supabase.com/docs
