# Astra Trade Lab — APK banane ke tareeke

## Tareeka A: Online "website to APK" tool (sabse aasaan)
`Astra-Trade-Lab-APK-ready.zip` upload karo (isme `index.html` zip ke root me hai, sab paths relative hain,
routing `#/` hash-based hai, isliye bina server ke chalta hai). Ye wahi folder hai jo yahan `apk/www/` me bhi hai.

## Tareeka B: Android Studio / Capacitor (apna APK, full control)
Requirements: Node 20+, JDK 17, Android SDK.
    cd apk
    npm install
    npx cap add android      # sirf pehli baar
    npm run apk              # APK: android/app/build/outputs/apk/debug/app-debug.apk

## Web app me change karne ke baad
    pnpm install
    pnpm --filter @workspace/trading-research run build      # output: artifacts/trading-research/dist/public
    # dist/public ke andar ki files ko apk/www/ me copy karo, phir `cd apk && npm run apk`

## Kya fix hua (original zip me kya missing tha)
1. Built static bundle nahi tha (source index.html -> /src/main.tsx sirf Vite dev server par chalta hai).
2. vite.config.ts bina PORT/BASE_PATH env ke crash hota tha; ab default PORT=5173, BASE_PATH='./' (relative).
3. Path routing (/scanner) APK me 404 deti; ab hash routing (#/scanner).
4. Android wrapper (Capacitor), icons aur manifest nahi the; ab apk/, icon-192/512.png, manifest.json hain.

## Note
- Data abhi bhi DEMO/fictional hai (app ke andar bhi "NOT LIVE" labelled).
- Google Fonts online load hote hain; offline hone par system font dikhega.
- Android build (Gradle) is environment me test nahi ho paya; static web build Chromium me test hua hai.
