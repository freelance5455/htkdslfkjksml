import { Fragment, type CSSProperties, type ReactNode, useMemo, useState } from 'react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { useHashLocation } from 'wouter/use-hash-location';
import {
  Activity, ArrowDown, ArrowRight, ArrowUp, BarChart3, Bell, BookOpen, CircleHelp,
  LayoutDashboard, Menu, Newspaper, Plus, Search, SlidersHorizontal, Star, Target, X,
} from 'lucide-react';
import { demoMarketData, type Exchange, type NewsItem, type Stock } from '@/data/demo-data';
import {
  calculateRiskReward,
  filterAndSortStocks,
  toggleWatchlistSymbol,
  type ScannerSortDirection,
  type ScannerSortField,
} from '@/data/scanner-utils';
import { buildDemoRecommendation } from '@/data/recommendation-utils';
import { MarketHistoryChart } from '@/components/market-history-chart';
import {
  RecommendationEngineCard,
  TargetTrackingCard,
  TradeSetupCard,
} from '@/components/recommendation-panels';

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/scanner', label: 'Stock scanner', icon: Search },
  { href: '/watchlist', label: 'Watchlist', icon: Star },
  { href: '/technical', label: 'Technical', icon: Activity },
  { href: '/fundamentals', label: 'Fundamentals', icon: BarChart3 },
  { href: '/recommendations', label: 'Recommendations', icon: Target },
  { href: '/order-book', label: 'Order book', icon: BookOpen },
  { href: '/news', label: 'Market news', icon: Newspaper },
  { href: '/signals', label: 'Signal review', icon: SlidersHorizontal },
];
const data = demoMarketData;
const fmt = (n: number) => n.toLocaleString('en-IN', { maximumFractionDigits: 2 });
const money = (n: number) => `₹${fmt(n)}`;
const volume = (n: number) => `${(n / 100000).toFixed(1)}L`;
const marketCapLabel = (n: number) => `₹${(n / 100000).toFixed(2)}L Cr`;

type ScannerRangeValues = {
  minPrice: string;
  maxPrice: string;
  minChangePct: string;
  maxChangePct: string;
  minVolume: string;
  maxVolume: string;
  minMarketCap: string;
  maxMarketCap: string;
};

const emptyScannerRanges: ScannerRangeValues = {
  minPrice: '',
  maxPrice: '',
  minChangePct: '',
  maxChangePct: '',
  minVolume: '',
  maxVolume: '',
  minMarketCap: '',
  maxMarketCap: '',
};

const optionalNumber = (value: string): number | undefined => {
  if (!value.trim()) return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
};

// Hash routing (#/scanner) so the app works inside an APK/WebView and from file:// with no server.
function App() {
  return (
    <WouterRouter hook={useHashLocation}>
      <Shell />
    </WouterRouter>
  );
}

function Shell() {
  const [path] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState('RELIANCE');
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tre-demo-watchlist');
      return stored ? JSON.parse(stored) as string[] : ['RELIANCE', 'ICICIBANK', 'TCS', 'SBIN'];
    } catch { return ['RELIANCE', 'ICICIBANK', 'TCS', 'SBIN']; }
  });
  const setWatch = (next: string[]) => {
    setWatchlist(next);
    localStorage.setItem('tre-demo-watchlist', JSON.stringify(next));
  };
  const toggleWatch = (symbol: string) => setWatch(toggleWatchlistSymbol(watchlist, symbol));
  const current = navItems.find((item) => item.href === path) ?? navItems[0];
  const activeStock = data.getStocks().find((stock) => stock.symbol === selected) ?? data.getStocks()[0];
  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="Primary navigation">
        <Brand />
        <div className="nav-label">RESEARCH DESK</div>
        <nav className="nav-list">
          {navItems.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href} className={`nav-link${path === href ? ' active' : ''}`} data-testid={`nav-${href === '/' ? 'overview' : href.slice(1)}`}>
              <Icon aria-hidden="true" /><span>{label}</span>
              {href === '/watchlist' && <span style={{ marginLeft: 'auto', font: '9px var(--app-font-mono)', color: '#6f7b86' }}>{watchlist.length}</span>}
            </Link>
          ))}
        </nav>
        <div className="sidebar-foot"><span className="mono">TRE / DEMO 01</span><br />Local research environment<br />No live feeds connected</div>
      </aside>
      <div className="main-column">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu" aria-label="Open menu" data-testid="button-mobile-menu" onClick={() => setMenuOpen(!menuOpen)}><Menu size={18} /></button>
            <span className="crumb">Research desk</span><span className="crumb">/</span><span className="crumb-current">{current.label}</span>
          </div>
          <div className="topbar-right">
            <div className="market-status"><span className="status-dot" />DEMO SESSION · 09:42 IST</div>
            <span className="demo-pill">SAMPLE DATA · NOT LIVE</span>
            <span aria-label="Notifications unavailable in demo" title="Demo notifications are not connected" className="watch-star"><Bell size={15} /></span>
            <div className="profile" aria-label="Analyst profile">AR</div>
          </div>
        </header>
        {menuOpen && <div className="mobile-menu-panel">
          <div className="mobile-menu-head"><strong>Research desk</strong><button aria-label="Close menu" onClick={() => setMenuOpen(false)} data-testid="button-close-menu"><X size={16} /></button></div>
          {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMenuOpen(false)} className={`nav-link${path === href ? ' active' : ''}`} data-testid={`mobile-nav-${href === '/' ? 'overview' : href.slice(1)}`}><Icon size={16} />{label}</Link>)}
        </div>}
        <main className="page" id="main-content">
          <Switch>
            <Route path="/" component={() => <Overview selected={selected} onSelect={setSelected} watchlist={watchlist} onToggleWatch={toggleWatch} />} />
            <Route path="/scanner" component={() => <Scanner selected={selected} onSelect={setSelected} watchlist={watchlist} onToggleWatch={toggleWatch} />} />
            <Route path="/watchlist" component={() => <Watchlist stocks={data.getStocks().filter((s) => watchlist.includes(s.symbol))} selected={selected} onSelect={setSelected} onRemove={toggleWatch} />} />
            <Route path="/technical" component={() => <Technical stock={activeStock} selected={selected} onSelect={setSelected} />} />
            <Route path="/recommendations" component={() => <Recommendations stock={activeStock} selected={selected} onSelect={setSelected} />} />
            <Route path="/fundamentals" component={() => <Fundamentals stocks={data.getStocks()} selected={selected} onSelect={setSelected} />} />
            <Route path="/order-book" component={() => <OrderBookPage selected={selected} onSelect={setSelected} />} />
            <Route path="/news" component={NewsPage} />
            <Route path="/signals" component={() => <Signals stocks={data.getStocks()} selected={selected} onSelect={setSelected} />} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {navItems.slice(0, 5).map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={path === href ? 'active' : ''} data-testid={`mobile-tab-${href === '/' ? 'overview' : href.slice(1)}`}><Icon /><span>{label === 'Stock scanner' ? 'Scanner' : label === 'Overview' ? 'Overview' : label === 'Technical' ? 'Technical' : label}</span></Link>)}
      </nav>
    </div>
  );
}

function Brand() {
  return <div className="brand"><div className="brand-mark"><Activity size={17} /></div><div><div className="brand-name">TRADING RESEARCH</div><div className="brand-sub">ENGINE / INDIA</div></div></div>;
}

function PageHeading({ eyebrow, title, description, right }: { eyebrow: string; title: string; description: string; right?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p className="page-description">{description}</p></div>{right}</div>;
}

function DemoNotice() {
  return <div className="market-banner" role="note" data-testid="notice-demo-data"><CircleHelp /><span><strong>Fictional demo market data.</strong> Values and research signals are illustrative only, not live information or trade advice.</span></div>;
}

function Panel({ title, meta, action, children, className = '' }: { title: string; meta?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-heading"><div><div className="panel-title">{title}</div>{meta && <div className="panel-meta" style={{ marginTop: 5 }}>{meta}</div>}</div>{action}</div>{children}</section>;
}

function IndexCards() {
  return <div className="index-grid">{data.getIndices().map((index, i) => <article className="panel index-card" key={index.symbol} data-testid={`index-card-${i}`}>
    <div className="index-head"><span className="index-name">{index.symbol}</span><span className="index-symbol">NSE · DEMO</span></div>
    <div className="index-value">{fmt(index.value)}</div>
    <div className={`index-change ${index.changePct < 0 ? 'negative' : ''}`}>{index.changePct > 0 ? '+' : ''}{index.changePct.toFixed(2)}% <span style={{ color: '#73808a' }}>today</span></div>
    <Sparkline seed={i + 2} down={index.changePct < 0} />
    <div className="index-stats">{[['OPEN', index.open], ['HIGH', index.high], ['LOW', index.low], ['PREV CLOSE', index.prevClose]].map(([label, val]) => <div key={label} className="mini-stat"><span>{label}</span><strong>{fmt(Number(val))}</strong></div>)}</div>
  </article>)}</div>;
}

function Sparkline({ seed = 0, down = false }: { seed?: number; down?: boolean }) {
  const points = Array.from({ length: 26 }, (_, i) => {
    const wave = Math.sin((i + seed) * 0.75) * 7 + Math.sin((i + seed) * 0.31) * 5;
    const drift = (i / 25) * (down ? 13 : -13);
    return `${i * 4},${18 + wave + drift}`;
  }).join(' ');
  return <svg className="sparkline" viewBox="0 0 100 40" preserveAspectRatio="none" aria-hidden="true"><polyline fill="none" stroke={down ? '#d77c75' : '#65c997'} strokeWidth="1.8" points={points} /></svg>;
}

function SignalTag({ signal }: { signal: string }) {
  return <span className={`signal-tag signal-${signal.toLowerCase()}`}>{signal}</span>;
}

function StockTable({ stocks, selected, onSelect, watchlist, onToggleWatch, compact = false, detailed = false }: { stocks: Stock[]; selected: string; onSelect: (symbol: string) => void; watchlist?: string[]; onToggleWatch?: (symbol: string) => void; compact?: boolean; detailed?: boolean }) {
  return <div className="table-wrap"><table className="data-table" data-testid="table-stocks"><thead><tr>{onToggleWatch && <th aria-label="Watchlist" /> }<th>Company</th>
    {detailed ? <>
      <th>Exchange</th><th>Price</th><th>% Change</th><th>Volume</th><th>Market cap</th>
      <th>RSI</th><th>EMA 20</th><th>EMA 50</th><th>MACD</th><th>Signal</th>
      <th>Entry price</th><th>Target price</th><th>Stop loss</th><th>Risk / reward</th><th>Sector</th>
    </> : <>
      <th>Price</th><th>Change</th><th>Volume</th><th>RSI</th><th>Trend</th><th>Signal</th>{!compact && <th>Sector</th>}
    </>}</tr></thead><tbody>
    {stocks.map((stock) => <tr key={stock.symbol} onClick={() => onSelect(stock.symbol)} data-testid={`row-stock-${stock.symbol}`} aria-selected={selected === stock.symbol}>
      {onToggleWatch && <td><button className="watch-star" aria-label={`${watchlist?.includes(stock.symbol) ? 'Remove' : 'Add'} ${stock.symbol} ${watchlist?.includes(stock.symbol) ? 'from' : 'to'} watchlist`} data-testid={`watch-toggle-${stock.symbol}`} onClick={(e) => { e.stopPropagation(); onToggleWatch(stock.symbol); }}><Star size={14} fill={watchlist?.includes(stock.symbol) ? 'currentColor' : 'none'} /></button></td>}
      <td><div className="stock-cell"><button className="symbol-button stock-symbol" data-testid={`select-stock-${stock.symbol}`} onClick={(e) => { e.stopPropagation(); onSelect(stock.symbol); }}>{stock.symbol}</button><span className="stock-company">{stock.company}</span></div></td>
      {detailed ? <>
        <td><span className="exchange-tag">{stock.exchange} · DEMO</span></td>
        <td data-testid={`stock-price-${stock.symbol}`}>{money(stock.price)}</td>
        <td className={stock.changePct < 0 ? 'negative' : 'positive'}>{stock.changePct > 0 ? '+' : ''}{stock.changePct.toFixed(2)}%</td>
        <td>{volume(stock.volume)}</td><td>{marketCapLabel(stock.marketCap)}</td>
        <td>{stock.rsi.toFixed(1)}</td><td>{money(stock.ema20)}</td><td>{money(stock.ema50)}</td>
        <td className={stock.macd < 0 ? 'negative' : 'positive'}>{stock.macd > 0 ? '+' : ''}{stock.macd.toFixed(2)}</td>
        <td><SignalTag signal={stock.signal} /></td>
        <td>{money(stock.entry)}</td><td>{money(stock.target)}</td><td>{money(stock.stopLoss)}</td>
        <td className="risk-reward-value" data-testid={`risk-reward-${stock.symbol}`}>
          {calculateRiskReward(stock)?.toFixed(2) ?? '—'}{calculateRiskReward(stock) === null ? '' : '×'}
        </td>
        <td style={{ fontFamily: 'var(--app-font-sans)', fontSize: 9 }}>{stock.sector}</td>
      </> : <>
        <td>{money(stock.price)}</td><td className={stock.changePct < 0 ? 'negative' : 'positive'}>{stock.changePct > 0 ? '+' : ''}{stock.changePct.toFixed(2)}%</td><td>{volume(stock.volume)}</td><td>{stock.rsi.toFixed(1)}</td><td>{stock.trend}</td><td><SignalTag signal={stock.signal} /></td>{!compact && <td style={{ fontFamily: 'var(--app-font-sans)', fontSize: 9 }}>{stock.sector}</td>}
      </>}
    </tr>)}
  </tbody></table></div>;
}

function Overview({ selected, onSelect, watchlist, onToggleWatch }: { selected: string; onSelect: (s: string) => void; watchlist: string[]; onToggleWatch: (s: string) => void }) {
  const movers = [...data.getStocks()].sort((a, b) => b.changePct - a.changePct).slice(0, 5);
  const chartStock = data.getStocks().find((stock) => stock.symbol === selected) ?? data.getStocks()[0];
  return <>
    <PageHeading eyebrow="Monday · 24 March 2025 / India" title="Market overview" description="A clear read on the session, built from local illustrative market fixtures." right={<span className="demo-pill">RESEARCH MODE</span>} />
    <DemoNotice /><IndexCards />
    <div className="section-grid overview-grid">
      <div className="span-8"><MarketHistoryChart stock={chartStock} /></div>
      <div className="span-4"><Panel title="Signal distribution" meta="Across demo coverage universe"><div className="signal-content"><div className="donut"><div className="donut-center">15<small>stocks</small></div></div><div className="signal-legend">{[['Bullish', 6, '#64c998'], ['Neutral', 4, '#d3a952'], ['Bearish', 5, '#ca716c']].map(([label, count, color]) => <div className="signal-legend-row" key={String(label)}><span className="signal-left"><i style={{ background: String(color) }} />{label}</span><span className="mono">{count}</span></div>)}</div></div></Panel></div>
      <div className="span-7"><Panel title="Stocks in focus" meta="High activity names · fictional snapshots" action={<Link href="/scanner" className="small-link">Open scanner <ArrowRight size={11} style={{ verticalAlign: 'middle' }} /></Link>}><StockTable stocks={movers} selected={selected} onSelect={onSelect} watchlist={watchlist} onToggleWatch={onToggleWatch} compact /></Panel></div>
      <div className="span-5"><Panel title="Sector pulse" meta="Illustrative session change"><div className="sector-list">{[['Banking', 1.6], ['Energy', 1.1], ['Healthcare', .8], ['Infrastructure', .4], ['IT', -1.2], ['Automotive', -.7]].map(([sector, value]) => <div className="sector-row" key={String(sector)}><span>{sector}</span><div className="bar-track"><div className={`bar-fill${Number(value) < 0 ? ' down' : ''}`} style={{ width: `${Math.max(12, Math.abs(Number(value)) * 48)}%` }} /></div><span className={`sector-val ${Number(value) < 0 ? 'negative' : 'positive'}`}>{Number(value) > 0 ? '+' : ''}{Number(value).toFixed(1)}%</span></div>)}</div></Panel></div>
      <div className="span-12"><NewsPanel /></div>
    </div>
  </>;
}

function Scanner({ selected, onSelect, watchlist, onToggleWatch }: { selected: string; onSelect: (s: string) => void; watchlist: string[]; onToggleWatch: (s: string) => void }) {
  const [search, setSearch] = useState('');
  const [exchange, setExchange] = useState<Exchange | 'ALL'>('ALL');
  const [sector, setSector] = useState('ALL');
  const [signal, setSignal] = useState<Stock['signal'] | 'ALL'>('ALL');
  const [sortBy, setSortBy] = useState<ScannerSortField>('changePct');
  const [sortDirection, setSortDirection] = useState<ScannerSortDirection>('desc');
  const [ranges, setRanges] = useState<ScannerRangeValues>(emptyScannerRanges);
  const stocks = useMemo(() => filterAndSortStocks(data.getStocks(), {
    query: search,
    exchange,
    sector,
    signal,
    minPrice: optionalNumber(ranges.minPrice),
    maxPrice: optionalNumber(ranges.maxPrice),
    minChangePct: optionalNumber(ranges.minChangePct),
    maxChangePct: optionalNumber(ranges.maxChangePct),
    minVolume: optionalNumber(ranges.minVolume),
    maxVolume: optionalNumber(ranges.maxVolume),
    minMarketCap: optionalNumber(ranges.minMarketCap),
    maxMarketCap: optionalNumber(ranges.maxMarketCap),
    sortBy,
    sortDirection,
  }), [search, exchange, sector, signal, ranges, sortBy, sortDirection]);
  const sectors = Array.from(new Set(data.getStocks().map((s) => s.sector)));
  const updateRange = (field: keyof ScannerRangeValues, value: string) =>
    setRanges((current) => ({ ...current, [field]: value }));
  const resetFilters = () => {
    setSearch('');
    setExchange('ALL');
    setSector('ALL');
    setSignal('ALL');
    setRanges(emptyScannerRanges);
    setSortBy('changePct');
    setSortDirection('desc');
  };
  return <>
    <PageHeading eyebrow="Universe / NSE · Demo fixtures" title="Stock scanner" description="Search the fictional coverage universe and compare market snapshots." />
    <DemoNotice />
    <section className="scanner-controls" aria-label="Stock scanner filters">
      <div className="scanner-toolbar">
        <label className="scanner-search"><span className="sr-only">Search by company or symbol</span><Search size={14} aria-hidden="true" /><input className="control" placeholder="Search symbol or company" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-scanner-search" /></label>
        <select className="select-control" value={exchange} onChange={(e) => setExchange(e.target.value as Exchange | 'ALL')} data-testid="filter-exchange" aria-label="Filter by exchange">
          <option value="ALL">All exchanges</option><option value="NSE">NSE · demo</option><option value="BSE">BSE · demo</option>
        </select>
        <select className="select-control" value={sector} onChange={(e) => setSector(e.target.value)} data-testid="filter-sector" aria-label="Filter by sector">
          <option value="ALL">All sectors</option>{sectors.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select className="select-control" value={signal} onChange={(e) => setSignal(e.target.value as Stock['signal'] | 'ALL')} data-testid="filter-signal" aria-label="Filter by signal">
          <option value="ALL">All signals</option><option value="Bullish">Bullish</option><option value="Bearish">Bearish</option><option value="Neutral">Neutral</option>
        </select>
        <label className="scanner-sort"><span className="sr-only">Sort stocks by</span><select className="select-control" value={sortBy} onChange={(e) => setSortBy(e.target.value as ScannerSortField)} data-testid="sort-stocks">
          <option value="changePct">Sort: Change %</option><option value="price">Sort: Price</option><option value="volume">Sort: Volume</option>
        </select></label>
        <button className="button secondary sort-direction" onClick={() => setSortDirection((current) => current === 'desc' ? 'asc' : 'desc')} data-testid="toggle-sort-direction" aria-label={`Sort ${sortDirection === 'desc' ? 'ascending' : 'descending'}`} title={`Current order: ${sortDirection === 'desc' ? 'highest first' : 'lowest first'}`}>
          {sortDirection === 'desc' ? <ArrowDown size={13} /> : <ArrowUp size={13} />}
          {sortDirection === 'desc' ? 'High first' : 'Low first'}
        </button>
      </div>
      <div className="scanner-range-grid">
        <ScannerRange label="Price range" unit="₹" testId="filter-price" minValue={ranges.minPrice} maxValue={ranges.maxPrice} onMinChange={(value) => updateRange('minPrice', value)} onMaxChange={(value) => updateRange('maxPrice', value)} nonNegative />
        <ScannerRange label="Change range" unit="%" testId="filter-change" minValue={ranges.minChangePct} maxValue={ranges.maxChangePct} onMinChange={(value) => updateRange('minChangePct', value)} onMaxChange={(value) => updateRange('maxChangePct', value)} />
        <ScannerRange label="Volume range" unit="shares" testId="filter-volume" minValue={ranges.minVolume} maxValue={ranges.maxVolume} onMinChange={(value) => updateRange('minVolume', value)} onMaxChange={(value) => updateRange('maxVolume', value)} nonNegative />
        <ScannerRange label="Market cap range" unit="₹ crore" testId="filter-market-cap" minValue={ranges.minMarketCap} maxValue={ranges.maxMarketCap} onMinChange={(value) => updateRange('minMarketCap', value)} onMaxChange={(value) => updateRange('maxMarketCap', value)} nonNegative />
      </div>
      <div className="scanner-result-line">
        <span className="panel-meta" data-testid="scanner-result-count">{stocks.length} / {data.getStocks().length} DEMO STOCKS</span>
        <button className="scanner-reset" onClick={resetFilters} data-testid="button-reset-filters">Reset filters</button>
      </div>
    </section>
    <div className="panel table-panel">{stocks.length ? <>
      <div className="panel-heading scanner-table-heading"><div><div className="panel-title">Scanner results</div><div className="panel-meta" style={{ marginTop: 5 }}>DEMO QUOTES · DEMO INDICATORS · SAMPLE LEVELS · SCROLL TABLE FOR MORE</div></div><span className="demo-pill">NOT LIVE</span></div>
      <StockTable stocks={stocks} selected={selected} onSelect={onSelect} watchlist={watchlist} onToggleWatch={onToggleWatch} detailed />
    </> : <div className="empty-state" data-testid="empty-scanner"><div className="empty-icon"><Search size={16} /></div><h3>No stocks match these filters</h3><p>Try another symbol, exchange, range or signal, or reset the filters.</p><button className="button secondary" onClick={resetFilters} data-testid="button-reset-empty-filters">Reset filters</button></div>}</div>
    <div className="page-description" style={{ marginTop: 12 }}>Click a row to focus it in technical, fundamental and order-book views.</div>
  </>;
}

function ScannerRange({ label, unit, testId, minValue, maxValue, onMinChange, onMaxChange, nonNegative = false }: {
  label: string;
  unit: string;
  testId: string;
  minValue: string;
  maxValue: string;
  onMinChange: (value: string) => void;
  onMaxChange: (value: string) => void;
  nonNegative?: boolean;
}) {
  return <fieldset className="scanner-range">
    <legend>{label}<span>{unit}</span></legend>
    <div className="scanner-range-inputs">
      <input className="range-control" type="number" step="any" min={nonNegative ? 0 : undefined} placeholder="Min" value={minValue} onChange={(e) => onMinChange(e.target.value)} aria-label={`${label} minimum (${unit})`} data-testid={`${testId}-min`} />
      <input className="range-control" type="number" step="any" min={nonNegative ? 0 : undefined} placeholder="Max" value={maxValue} onChange={(e) => onMaxChange(e.target.value)} aria-label={`${label} maximum (${unit})`} data-testid={`${testId}-max`} />
    </div>
  </fieldset>;
}

function Watchlist({ stocks, selected, onSelect, onRemove }: { stocks: Stock[]; selected: string; onSelect: (s: string) => void; onRemove: (s: string) => void }) {
  const [search, setSearch] = useState('');
  const visible = stocks.filter((s) => `${s.symbol} ${s.company}`.toLowerCase().includes(search.toLowerCase()));
  return <>
    <PageHeading eyebrow="Personal workspace / local only" title="Watchlist" description="A focused set of names to revisit during the demo session." right={<span className="demo-pill">{stocks.length} SAVED</span>} />
    <DemoNotice />
    <div className="filters"><div className="filter-left"><label style={{ position: 'relative', display: 'flex', alignItems: 'center' }}><Search size={14} style={{ position: 'absolute', left: 11, color: '#77848e' }} /><input className="control" style={{ paddingLeft: 33 }} placeholder="Find in watchlist" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-watchlist-search" aria-label="Search watchlist" /></label><Link href="/scanner" className="button"><Plus size={13} /> Find stocks</Link></div><span className="panel-meta">SAVED IN THIS BROWSER</span></div>
    <div className="panel table-panel">{visible.length ? <StockTable stocks={visible} selected={selected} onSelect={onSelect} watchlist={stocks.map((s) => s.symbol)} onToggleWatch={onRemove} /> : <div className="empty-state" data-testid="empty-watchlist"><div className="empty-icon"><Star size={16} /></div><h3>{stocks.length ? 'No matching names' : 'Your watchlist is clear'}</h3><p>{stocks.length ? 'Try a different symbol or company name.' : 'Add fictional sample stocks from the scanner to keep them close.'}</p>{!stocks.length && <Link href="/scanner" className="button"><Search size={13} /> Browse scanner</Link>}</div>}</div>
  </>;
}

function StockPicker({ selected, onSelect, allStocks = false }: { selected: string; onSelect: (s: string) => void; allStocks?: boolean }) {
  const stocks = allStocks ? data.getStocks() : data.getStocks().slice(0, 8);
  return <div className="stock-picker" role="group" aria-label="Select stock">{stocks.map((s) => <button key={s.symbol} className={`stock-chip${selected === s.symbol ? ' active' : ''}`} onClick={() => onSelect(s.symbol)} data-testid={`stock-chip-${s.symbol}`} aria-pressed={selected === s.symbol}>{s.symbol}</button>)}</div>;
}

function Technical({ stock, selected, onSelect }: { stock: Stock; selected: string; onSelect: (s: string) => void }) {
  const recommendation = buildDemoRecommendation(stock);
  return <>
    <PageHeading eyebrow="Technical snapshot / illustrative" title="Technical analysis" description="Price structure and common indicators for the selected fictional equity." />
    <DemoNotice /><div style={{ marginBottom: 14 }}><StockPicker selected={selected} onSelect={onSelect} /></div>
    <div className="two-col"><div><MarketHistoryChart stock={stock} />
      <Panel title="Indicator readings" meta="Indicative thresholds · not predictive"><Indicator name="RSI · 14" value={stock.rsi} min="Oversold" max="Overbought" /><Indicator name="Trend strength" value={stock.trend === 'Uptrend' ? 72 : stock.trend === 'Downtrend' ? 31 : 51} min="Weak" max="Strong" /><Indicator name="Volume impulse" value={Math.min(88, 36 + stock.volume % 51)} min="Low" max="Elevated" /></Panel>
    </div><div className="section-grid">
      <section className="panel snapshot"><div className="eyebrow">SELECTED INSTRUMENT</div><div className="snapshot-head"><div><div className="snapshot-price">{money(stock.price)}</div><div className="snapshot-stock">{stock.symbol} · {stock.company}</div></div><span className={`index-change ${stock.changePct < 0 ? 'negative' : ''}`}>{stock.changePct > 0 ? '+' : ''}{stock.changePct.toFixed(2)}%</span></div><div className="snapshot-grid"><Snapshot label="Trend" value={stock.trend} /><Snapshot label="Signal" value={stock.signal} /><Snapshot label="RSI (14)" value={stock.rsi.toFixed(1)} /><Snapshot label="Volume" value={`${volume(stock.volume)} shares`} /><Snapshot label="Sector" value={stock.sector} /><Snapshot label="Reference" value="Fictional" /></div></section>
      <Panel title="Technical read" meta="Rule-based demo interpretation"><div style={{ padding: '0 18px 17px' }}><SignalTag signal={stock.signal} /><p className="rationale">{stock.signal === 'Bullish' ? 'The illustrative setup shows positive short-term momentum with price structure holding above a recent range. Confirm levels against independent research before use.' : stock.signal === 'Bearish' ? 'The illustrative setup shows weakening momentum and a softer recent price structure. This is a sample observation, not a directional recommendation.' : 'The illustrative setup appears range-bound, with mixed momentum cues. No clear directional bias is assigned in this sample.'}</p></div></Panel>
    </div></div>
    <div className="recommendation-grid" data-testid="recommendation-grid-technical">
      <RecommendationEngineCard recommendation={recommendation} />
      <TradeSetupCard recommendation={recommendation} />
    </div>
    <div className="target-tracking-wrap" style={{ marginTop: 14 }}>
      <TargetTrackingCard recommendation={recommendation} currentPrice={stock.price} />
    </div>
  </>;
}

function Recommendations({ stock, selected, onSelect }: { stock: Stock; selected: string; onSelect: (symbol: string) => void }) {
  const recommendation = buildDemoRecommendation(stock);
  return <>
    <PageHeading eyebrow="Rule-based signals / demo only" title="Recommendations" description="Transparent technical scoring and simulated trade levels for the selected sample equity." />
    <DemoNotice />
    <div style={{ marginBottom: 14 }}><StockPicker selected={selected} onSelect={onSelect} allStocks /></div>
    <div className="recommendation-grid" data-testid="recommendation-grid-main">
      <RecommendationEngineCard recommendation={recommendation} />
      <TradeSetupCard recommendation={recommendation} />
    </div>
    <div className="target-tracking-wrap" style={{ marginTop: 14 }} data-testid="target-tracking-main">
      <TargetTrackingCard recommendation={recommendation} currentPrice={stock.price} />
    </div>
  </>;
}

function Indicator({ name, value, min, max }: { name: string; value: number; min: string; max: string }) {
  return <div className="indicator-row"><span className="indicator-name">{name}</span><div><div className="indicator-track"><i className="indicator-marker" style={{ left: `${Math.min(96, Math.max(4, value))}%` }} /></div><div style={{ display: 'flex', justifyContent: 'space-between', color: '#606e78', font: '8px var(--app-font-mono)', marginTop: 6 }}><span>{min}</span><span>{max}</span></div></div><span className="indicator-value">{value.toFixed(1)}</span></div>;
}
function Snapshot({ label, value }: { label: string; value: string }) { return <div className="snapshot-item"><span>{label}</span><strong>{value}</strong></div>; }

function Fundamentals({ stocks, selected, onSelect }: { stocks: Stock[]; selected: string; onSelect: (s: string) => void }) {
  const stock = stocks.find((s) => s.symbol === selected) ?? stocks[0];
  return <>
    <PageHeading eyebrow="Company metrics / sample universe" title="Fundamental snapshot" description="A concise view of valuation, returns and scale using static fictional values." />
    <DemoNotice /><div style={{ marginBottom: 14 }}><StockPicker selected={selected} onSelect={onSelect} /></div>
    <div className="two-col"><section className="panel snapshot"><div className="eyebrow">COMPANY PROFILE</div><div className="snapshot-head"><div><div className="snapshot-price">{stock.symbol}</div><div className="snapshot-stock">{stock.company} · {stock.sector}</div></div><span className="demo-pill">FICTIONAL</span></div><div className="snapshot-grid">{[['Market cap', `₹${(stock.marketCap / 100000).toFixed(2)}L Cr`], ['P/E ratio', `${stock.pe.toFixed(1)}×`], ['Return on equity', `${stock.roe.toFixed(1)}%`], ['Price', money(stock.price)], ['Session change', `${stock.changePct > 0 ? '+' : ''}${stock.changePct.toFixed(2)}%`], ['Coverage set', 'Nifty 50 sample']].map(([label, value]) => <Snapshot key={label} label={label} value={value} />)}</div></section>
      <Panel title="Peer context" meta="Simple sector comparison · demo values"><div className="table-wrap"><table className="data-table"><thead><tr><th>Company</th><th>P/E</th><th>ROE</th><th>Market cap</th></tr></thead><tbody>{stocks.filter((s) => s.sector === stock.sector).slice(0, 5).map((s) => <tr key={s.symbol} onClick={() => onSelect(s.symbol)} data-testid={`peer-row-${s.symbol}`}><td><div className="stock-cell"><span className="stock-symbol">{s.symbol}</span><span className="stock-company">{s.company}</span></div></td><td>{s.pe.toFixed(1)}×</td><td>{s.roe.toFixed(1)}%</td><td>₹{(s.marketCap / 100000).toFixed(2)}L Cr</td></tr>)}</tbody></table></div><div style={{ padding: '0 18px 17px' }} className="disclaimer">Peer set may be incomplete. Figures are made-up for interface demonstration and are not company disclosures.</div></Panel>
    </div>
    <div className="panel table-panel" style={{ marginTop: 14 }}><div className="panel-heading"><div><div className="panel-title">Coverage fundamentals</div><div className="panel-meta" style={{ marginTop: 5 }}>Reference metrics · fictional sample universe</div></div></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Company</th><th>Sector</th><th>Price</th><th>P/E</th><th>ROE</th><th>Market cap</th><th>Signal</th></tr></thead><tbody>{stocks.map((s) => <tr key={s.symbol} onClick={() => onSelect(s.symbol)} data-testid={`fundamental-row-${s.symbol}`}><td><span className="stock-symbol">{s.symbol}</span><span className="stock-company" style={{ marginLeft: 8 }}>{s.company}</span></td><td>{s.sector}</td><td>{money(s.price)}</td><td>{s.pe.toFixed(1)}×</td><td>{s.roe.toFixed(1)}%</td><td>₹{(s.marketCap / 100000).toFixed(2)}L Cr</td><td><SignalTag signal={s.signal} /></td></tr>)}</tbody></table></div></div>
  </>;
}

function OrderBookPage({ selected, onSelect }: { selected: string; onSelect: (s: string) => void }) {
  const stock = data.getStocks().find((s) => s.symbol === selected) ?? data.getStocks()[0];
  const book = data.getOrderBooks().find((b) => b.symbol === stock.symbol)!;
  const max = Math.max(...book.bidLevels.map((l) => l.quantity), ...book.askLevels.map((l) => l.quantity));
  return <>
    <PageHeading eyebrow="Market microstructure / local sample" title="Order-book depth" description="Illustrative five-level depth snapshots for selected sample instruments." />
    <DemoNotice /><div style={{ marginBottom: 14 }}><StockPicker selected={selected} onSelect={onSelect} /></div>
    <div className="two-col"><Panel title={`${stock.symbol} · Depth`} meta="Level 2 style sample view"><div className="depth"><div className="depth-header"><span>Bid quantity</span><span>Price (₹)</span><span>Ask quantity</span></div>{Array.from({ length: 5 }, (_, i) => <Fragment key={i}><div className="depth-row bid" style={{ '--depth': `${(book.bidLevels[i].quantity / max) * 94}%` } as CSSProperties}><span className="positive">{fmt(book.bidLevels[i].quantity)}</span><span>{fmt(book.bidLevels[i].price)}</span><span>—</span></div><div className="depth-row ask" style={{ '--depth': `${(book.askLevels[i].quantity / max) * 94}%` } as CSSProperties}><span>—</span><span>{fmt(book.askLevels[i].price)}</span><span className="negative">{fmt(book.askLevels[i].quantity)}</span></div></Fragment>)}</div></Panel>
      <div className="section-grid"><section className="panel snapshot"><div className="eyebrow">DEPTH SUMMARY</div><div className="snapshot-grid" style={{ gridTemplateColumns: 'repeat(2,1fr)' }}><Snapshot label="Bid quantity" value={fmt(book.bidQty)} /><Snapshot label="Ask quantity" value={fmt(book.askQty)} /><Snapshot label="Bid / ask" value={`${(book.bidQty / book.askQty).toFixed(2)}×`} /><Snapshot label="Spread reference" value={`${fmt(book.askLevels[0].price - book.bidLevels[0].price)} pts`} /></div></section><Panel title="Reading the book" meta="About this sample"><div style={{ padding: '0 18px 17px' }}><p className="rationale">Bid and ask quantities are generated local fixtures and do not reflect executable orders. Use this panel only to review interface behavior and relative depth presentation.</p><p className="disclaimer">This is not exchange order-book data. No live market connectivity is present.</p></div></Panel></div>
    </div>
  </>;
}

function NewsPanel() {
  return <Panel title="Market headlines" meta="Fictional desk feed · not current news" action={<Link href="/news" className="small-link">All headlines <ArrowRight size={11} style={{ verticalAlign: 'middle' }} /></Link>}><div className="news-list">{data.getNews().slice(0, 3).map((item, i) => <NewsRow key={item.headline} item={item} index={i} />)}</div></Panel>;
}
function NewsRow({ item, index }: { item: NewsItem; index: number }) {
  return <article className="news-row" data-testid={`news-item-${index}`}><div><div className="news-headline">{item.headline}</div><div style={{ display: 'flex', gap: 10, marginTop: 7, alignItems: 'center' }}><span className="news-source">{item.source}</span><span className={`sentiment ${item.sentiment.toLowerCase()}`}>{item.sentiment}</span></div></div><time className="news-time">{item.publishedAt}</time></article>;
}
function NewsPage() {
  const [sentiment, setSentiment] = useState('All sentiments');
  const news = data.getNews().filter((item) => sentiment === 'All sentiments' || item.sentiment === sentiment);
  return <>
    <PageHeading eyebrow="Desk feed / sample headlines" title="Market news" description="Fictional headlines for evaluating the research workflow. Not a live news service." right={<select className="select-control" value={sentiment} onChange={(e) => setSentiment(e.target.value)} data-testid="filter-news-sentiment"><option>All sentiments</option><option>Positive</option><option>Negative</option><option>Mixed</option></select>} />
    <DemoNotice /><Panel title="Headlines" meta={`${news.length} SAMPLE ITEMS · PUBLISHED TIMES ARE PLACEHOLDERS`}><div className="news-list">{news.map((item, i) => <NewsRow item={item} index={i} key={item.headline} />)}</div>{news.length === 0 && <div className="empty-state"><h3>No headlines in this view</h3><p>Change sentiment filter to see sample items.</p></div>}</Panel>
    <div className="disclaimer" style={{ marginTop: 12 }}>Headlines and sources on this screen are fictional and do not describe actual events, companies or market conditions.</div>
  </>;
}

function Signals({ stocks, selected, onSelect }: { stocks: Stock[]; selected: string; onSelect: (s: string) => void }) {
  const stock = stocks.find((s) => s.symbol === selected) ?? stocks[0];
  const peers = stocks.filter((s) => s.signal !== 'Neutral').slice(0, 8);
  return <>
    <PageHeading eyebrow="Signal review / analyst workflow" title="Signal review" description="Compare opposing sample setups with transparent levels and rationale." />
    <DemoNotice />
    <div className="filters"><div className="filter-left"><select className="select-control" value={selected} onChange={(e) => onSelect(e.target.value)} data-testid="select-signal-stock" aria-label="Select stock for signal review">{stocks.map((s) => <option key={s.symbol} value={s.symbol}>{s.symbol} · {s.company}</option>)}</select><span className="panel-meta">ILLUSTRATIVE LEVELS ONLY</span></div></div>
    <div className="two-col"><SignalCard stock={stock} /><Panel title="Coverage signal board" meta="Select a row to review sample setup"><div className="table-wrap"><table className="data-table"><thead><tr><th>Instrument</th><th>Change</th><th>RSI</th><th>Signal</th></tr></thead><tbody>{peers.map((s) => <tr key={s.symbol} onClick={() => onSelect(s.symbol)} data-testid={`signal-row-${s.symbol}`}><td><div className="stock-cell"><span className="stock-symbol">{s.symbol}</span><span className="stock-company">{s.company}</span></div></td><td className={s.changePct < 0 ? 'negative' : 'positive'}>{s.changePct > 0 ? '+' : ''}{s.changePct.toFixed(2)}%</td><td>{s.rsi.toFixed(1)}</td><td><SignalTag signal={s.signal} /></td></tr>)}</tbody></table></div></Panel></div>
    <div className="disclaimer" style={{ marginTop: 13 }}>Entry, targets and stop-loss levels are derived from static demo fixtures. They are not live data, calibrated forecasts or trading advice.</div>
  </>;
}
function SignalCard({ stock }: { stock: Stock }) {
  const recommendation = buildDemoRecommendation(stock);
  return <div className="signal-recommendation-stack">
    <RecommendationEngineCard recommendation={recommendation} />
    <TradeSetupCard recommendation={recommendation} />
    <TargetTrackingCard recommendation={recommendation} currentPrice={stock.price} />
  </div>;
}
function NotFound() {
  return <div className="empty-state"><div className="empty-icon"><CircleHelp size={16} /></div><h3>View not found</h3><p>This research view does not exist in the demo workspace.</p><Link href="/" className="button">Return to overview</Link></div>;
}

export default App;
