import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { CircleHelp } from 'lucide-react';
import type { Stock } from '@/data/demo-data';
import {
  DAYS_TO_EXPIRY,
  FUTURES_MARGIN_PCT,
  RISK_FREE_RATE,
  SIGNAL_STRATEGIES,
  buildSignalBook,
  filterAndSortSignals,
  planFuturesPosition,
  planOptionsPosition,
  summarizeSignals,
  type AnySignal,
  type FuturesSignal,
  type OptionsSignal,
  type SignalBase,
  type SignalFilter,
  type SignalSort,
  type SignalStrategy,
  type SwingSignal,
} from '@/data/signals-utils';
import {
  RecommendationEngineCard,
  TargetTrackingCard,
  TradeSetupCard,
  breakdownLabels,
} from '@/components/recommendation-panels';

const price = (value: number) =>
  `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const whole = (value: number) => `₹${Math.round(value).toLocaleString('en-IN')}`;
const signedWhole = (value: number) => `${value >= 0 ? '+' : '−'}₹${Math.abs(Math.round(value)).toLocaleString('en-IN')}`;
const ratio = (value: number | null) => (value === null ? '—' : `${value.toFixed(2)}×`);

const STRATEGY_META: Record<SignalStrategy, { label: string; blurb: string; desk: string }> = {
  swing: { label: 'Swing', blurb: 'Stocks · multi-day', desk: 'Cash-market trades held for several sessions. Levels come straight from the rule-based recommendation engine.' },
  options: { label: 'Options', blurb: 'Long CE / PE · monthly', desk: 'Buy-side option trades only (call for bullish, put for bearish), so the most you can lose is the premium paid. Premiums are model estimates.' },
  futures: { label: 'Futures', blurb: 'Stock futures · monthly', desk: 'Long or short stock futures with cost-of-carry pricing, assumed margin and a lot-based position planner.' },
};

const sideTone = (side: SignalBase['side']) => (side === 'LONG' ? 'buy' : side === 'SHORT' ? 'sell' : 'hold');

function pillText(signal: AnySignal): string {
  if (signal.strategy === 'options') return `BUY ${signal.optionType}`;
  if (signal.strategy === 'futures') return signal.side === 'LONG' ? 'LONG FUT' : 'SHORT FUT';
  return signal.action;
}

function subtitle(signal: AnySignal): string {
  return signal.strategy === 'swing' ? signal.name : signal.contract;
}

export function TradeSignalsPage({
  strategy,
  stocks,
  selected,
  onSelect,
}: {
  strategy: SignalStrategy;
  stocks: Stock[];
  selected: string;
  onSelect: (symbol: string) => void;
}) {
  const book = useMemo(() => buildSignalBook(stocks), [stocks]);
  const [filter, setFilter] = useState<SignalFilter>('ALL');
  const [sort, setSort] = useState<SignalSort>('confidence');
  const all = book[strategy] as AnySignal[];
  const visible = filterAndSortSignals(all, filter, sort);
  const active = visible.find((signal) => signal.symbol === selected) ?? visible[0];
  const summary = summarizeSignals(all);
  const meta = STRATEGY_META[strategy];
  const filters: SignalFilter[] = strategy === 'swing' ? ['ALL', 'LONG', 'SHORT', 'WATCH'] : ['ALL', 'LONG', 'SHORT'];
  const filterLabel = (value: SignalFilter) =>
    value === 'ALL' ? 'All' : value === 'LONG' ? (strategy === 'options' ? 'Calls' : 'Long') : value === 'SHORT' ? (strategy === 'options' ? 'Puts' : 'Short') : 'Watch';

  const changeFilter = (value: SignalFilter) => setFilter(value);
  // On narrow screens the detail sits below the list, so bring it into view after a pick.
  const selectSignal = (symbol: string) => {
    onSelect(symbol);
    if (typeof window !== 'undefined' && window.matchMedia('(max-width: 1050px)').matches) {
      requestAnimationFrame(() => document.querySelector('[data-testid^="signal-detail-"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    }
  };

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">Trade signals / simulated desks</div>
          <h1>Trade signals</h1>
          <p className="page-description">Swing, options and futures setups on separate desks, each with full levels and reasoning.</p>
        </div>
        <span className="demo-pill">SIMULATED · NOT LIVE</span>
      </div>

      <div className="market-banner" role="note" data-testid="notice-signals-demo">
        <CircleHelp />
        <span>
          <strong>Simulated signals on fictional data.</strong> Rules are transparent but inputs are demo fixtures; contract details
          (expiry, lot size, margin, volatility) are labelled assumptions. This is research output, not trade advice.
        </span>
      </div>

      <nav className="ts-tabs" aria-label="Signal desks" data-testid="signal-desks">
        {SIGNAL_STRATEGIES.map((id) => (
          <Link
            key={id}
            href={`/trade-signals/${id}`}
            className={`ts-tab${strategy === id ? ' is-active' : ''}`}
            aria-current={strategy === id ? 'page' : undefined}
            data-testid={`signals-tab-${id}`}
          >
            <strong>{STRATEGY_META[id].label}</strong>
            <span>{STRATEGY_META[id].blurb}</span>
            <em data-testid={`signals-tab-count-${id}`}>{book[id].length}</em>
          </Link>
        ))}
      </nav>
      <p className="ts-desk-note" data-testid="signals-desk-note">{meta.desk}</p>

      <div className="ts-summary" data-testid="signals-summary">
        <SummaryTile label={strategy === 'options' ? 'Call signals' : 'Long signals'} value={String(summary.long)} tone="positive" id="long" />
        <SummaryTile label={strategy === 'options' ? 'Put signals' : 'Short signals'} value={String(summary.short)} tone="negative" id="short" />
        <SummaryTile label="Avg confidence" value={`${summary.averageConfidence} / 100`} id="confidence" />
        <SummaryTile label="Best R:R (T3)" value={ratio(summary.bestRiskReward || null)} id="rr" />
      </div>

      <div className="ts-toolbar">
        <div className="mh-control-group" role="group" aria-label="Filter signals">
          {filters.map((value) => (
            <button
              key={value}
              type="button"
              className={`mh-control${filter === value ? ' is-active' : ''}`}
              aria-pressed={filter === value}
              onClick={() => changeFilter(value)}
              data-testid={`signals-filter-${value.toLowerCase()}`}
            >
              {filterLabel(value)}
            </button>
          ))}
        </div>
        <label className="ts-sort">
          <span className="sr-only">Sort signals</span>
          <select className="select-control" value={sort} onChange={(event) => setSort(event.target.value as SignalSort)} data-testid="signals-sort">
            <option value="confidence">Sort: Confidence</option>
            <option value="riskReward">Sort: Risk : reward</option>
          </select>
        </label>
        <span className="panel-meta" data-testid="signals-count">{visible.length} / {all.length} {meta.label.toUpperCase()} SIGNALS</span>
      </div>

      {strategy !== 'swing' && book.skipped.length > 0 && (
        <p className="ts-skipped" data-testid="signals-skipped">
          No {meta.label.toLowerCase()} signal for {book.skipped.join(', ')}: their rule read is neutral, so there is no directional edge.
        </p>
      )}

      {visible.length === 0 || !active ? (
        <div className="panel empty-state" data-testid="signals-empty">
          <h3>No signals in this view</h3>
          <p>Try a different filter on this desk.</p>
          <button type="button" className="button secondary" onClick={() => setFilter('ALL')}>Show all</button>
        </div>
      ) : (
        <div className="ts-layout">
          <section className="panel ts-list" aria-label={`${meta.label} signals`} data-testid="signals-list">
            {visible.map((signal) => (
              <SignalRow key={signal.id} signal={signal} active={signal.id === active.id} onSelect={() => selectSignal(signal.symbol)} />
            ))}
          </section>
          <div className="ts-detail" data-testid={`signal-detail-${strategy}`} key={active.id}>
            <SignalHeader signal={active} />
            {active.strategy === 'swing' && <SwingDetail signal={active} />}
            {active.strategy === 'futures' && <FuturesDetail signal={active} />}
            {active.strategy === 'options' && <OptionsDetail signal={active} />}
          </div>
        </div>
      )}
    </>
  );
}

function SummaryTile({ label, value, tone, id }: { label: string; value: string; tone?: 'positive' | 'negative'; id: string }) {
  return (
    <div className="detail-box" data-testid={`signals-summary-${id}`}>
      <div className="detail-label">{label}</div>
      <div className={`detail-value${tone ? ` ${tone}` : ''}`}>{value}</div>
    </div>
  );
}

function SignalRow({ signal, active, onSelect }: { signal: AnySignal; active: boolean; onSelect: () => void }) {
  const t3 = signal.targets[2];
  return (
    <button
      type="button"
      className={`ts-row${active ? ' is-active' : ''}`}
      onClick={onSelect}
      aria-pressed={active}
      data-testid={`signal-row-${signal.strategy}-${signal.symbol}`}
    >
      <span className="ts-row-id">
        <strong>{signal.symbol}</strong>
        <small>{subtitle(signal)}</small>
      </span>
      <span className={`action-pill action-${sideTone(signal.side)}`}>{pillText(signal)}</span>
      <span className="ts-row-levels">
        <span><small>ENTRY</small><b>{price(signal.entry)}</b></span>
        <span><small>SL</small><b className="negative">{price(signal.stopLoss)}</b></span>
        <span><small>T3</small><b className="positive">{price(t3.price)}</b></span>
        <span><small>R:R</small><b>{ratio(t3.riskReward)}</b></span>
      </span>
      <span className="ts-row-conf" aria-label={`Confidence ${signal.confidence} out of 100`}>
        <b>{signal.confidence}</b>
        <i><u style={{ width: `${signal.confidence}%` }} /></i>
      </span>
    </button>
  );
}

function StatusChip({ status }: { status: AnySignal['status'] }) {
  const tone = status === 'SL HIT' ? 'stop' : status === 'ACTIVE' ? 'active' : 'hit';
  return (
    <span className={`rp-tracking-status rp-tracking-${tone}`} data-testid="signal-status" title="Simulated status from the demo underlying price">
      {status}
    </span>
  );
}

function SignalHeader({ signal }: { signal: AnySignal }) {
  const strength = signal.action.startsWith('STRONG') ? 'STRONG' : 'STANDARD';
  return (
    <header className="panel ts-header" data-testid="signal-header">
      <div className="ts-header-main">
        <div className="eyebrow">{STRATEGY_META[signal.strategy].label.toUpperCase()} DESK · SIMULATED</div>
        <div className="ts-header-title">
          <strong data-testid="signal-header-symbol">{signal.symbol}</strong>
          <span>{signal.name} · {signal.sector}</span>
        </div>
        {signal.strategy !== 'swing' && <div className="ts-contract" data-testid="signal-contract">{signal.contract} · expiry {signal.expiryLabel}</div>}
      </div>
      <div className="ts-header-side">
        <span className={`action-pill action-${sideTone(signal.side)}`} data-testid="signal-header-action">{pillText(signal)}</span>
        <span className="ts-strength" data-testid="signal-strength">{strength} · {signal.action}</span>
        <StatusChip status={signal.status} />
      </div>
    </header>
  );
}

// ------------------------------------------------------------------ Swing
function SwingDetail({ signal }: { signal: SwingSignal }) {
  return (
    <>
      <div className="recommendation-grid ts-reco-grid" data-testid="swing-detail">
        <RecommendationEngineCard recommendation={signal.recommendation} />
        <div className="signal-recommendation-stack">
          <TradeSetupCard recommendation={signal.recommendation} />
          <article className="panel ts-card" data-testid="swing-plan">
            <div className="rp-panel-title-row"><div><div className="eyebrow">SWING PLAN · {signal.symbol}</div><h2>Holding and risk profile</h2></div></div>
            <DetailGrid
              items={[
                ['Holding window', signal.holdingWindow],
                ['Risk to stop', `${signal.riskPct.toFixed(2)}%`],
                ['Reward to T3', `${signal.rewardPctT3.toFixed(2)}%`],
                ['Simulated price', price(signal.currentPrice)],
              ]}
              testPrefix="swing"
            />
          </article>
        </div>
      </div>
      <div className="target-tracking-wrap" style={{ marginTop: 14 }}>
        <TargetTrackingCard recommendation={signal.recommendation} currentPrice={signal.currentPrice} />
      </div>
    </>
  );
}

// ------------------------------------------------------------------ shared pieces
function DetailGrid({ items, testPrefix }: { items: [string, string][]; testPrefix: string }) {
  return (
    <div className="ts-detail-grid">
      {items.map(([label, value]) => (
        <div className="detail-box" key={label} data-testid={`${testPrefix}-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}>
          <div className="detail-label">{label}</div>
          <div className="detail-value">{value}</div>
        </div>
      ))}
    </div>
  );
}

function LevelsPanel({ signal, entryLabel, extra }: { signal: FuturesSignal | OptionsSignal; entryLabel: string; extra?: (index: number | 'entry' | 'stop') => string | null }) {
  const underEntry = extra?.('entry');
  const underStop = extra?.('stop');
  return (
    <article className="panel trade-setup-card rp-setup-card" data-testid={`levels-${signal.strategy}`}>
      <div className="rp-panel-title-row">
        <div><div className="eyebrow">LEVEL MAP · {signal.symbol}</div><h2>Trade levels</h2></div>
        <span className="rp-demo-stamp">SIMULATED · DEMO ONLY</span>
      </div>
      <div className="trade-primary-levels">
        <div className="trade-level trade-entry">
          <span className="trade-level-label">{entryLabel}</span>
          <strong data-testid={`${signal.strategy}-entry`}>{price(signal.entry)}</strong>
          {underEntry && <small className="ts-under">{underEntry}</small>}
        </div>
        <div className="trade-level trade-stop">
          <span className="trade-level-label">STOP LOSS</span>
          <strong data-testid={`${signal.strategy}-stop-loss`}>{price(signal.stopLoss)}</strong>
          {underStop && <small className="ts-under">{underStop}</small>}
        </div>
      </div>
      <div className="targets-heading"><span>PROFIT TARGETS</span><span>PRICE / RISK : REWARD</span></div>
      <div className="trade-targets rp-target-list">
        {signal.targets.map((target, index) => (
          <div className="trade-target rp-target" key={target.label} data-testid={`${signal.strategy}-target-${target.label.toLowerCase()}`}>
            <span className="target-label">{target.label}</span>
            <strong data-testid={`${signal.strategy}-target-price-${target.label.toLowerCase()}`}>{price(target.price)}</strong>
            <span className="target-ratio">RISK : REWARD <b data-testid={`${signal.strategy}-target-rr-${target.label.toLowerCase()}`}>{ratio(target.riskReward)}</b></span>
            {extra?.(index) && <small className="ts-under">{extra(index)}</small>}
          </div>
        ))}
      </div>
    </article>
  );
}

function PositionCalculator({ signal }: { signal: FuturesSignal | OptionsSignal }) {
  const [lotsText, setLotsText] = useState('1');
  const lots = Number(lotsText);
  const plan = signal.strategy === 'futures' ? planFuturesPosition(signal, lots) : planOptionsPosition(signal, lots);
  const capitalLabel = signal.strategy === 'futures' ? 'Margin needed (assumed)' : 'Premium to pay';
  return (
    <article className="panel ts-card" data-testid="position-calculator">
      <div className="rp-panel-title-row">
        <div><div className="eyebrow">POSITION PLANNER · {signal.symbol}</div><h2>Lots and exposure</h2></div>
        <span className="rp-demo-stamp">ESTIMATE</span>
      </div>
      <label className="ts-lots">
        <span>LOTS ({signal.lotSize.toLocaleString('en-IN')} qty per lot)</span>
        <input
          className="range-control"
          type="number"
          min={0}
          step={1}
          inputMode="numeric"
          value={lotsText}
          onChange={(event) => setLotsText(event.target.value)}
          data-testid="input-lots"
          aria-label="Number of lots"
        />
      </label>
      <div className="ts-detail-grid">
        <div className="detail-box"><div className="detail-label">Quantity</div><div className="detail-value" data-testid="calc-quantity">{plan.quantity.toLocaleString('en-IN')}</div></div>
        <div className="detail-box"><div className="detail-label">{capitalLabel}</div><div className="detail-value" data-testid="calc-capital">{whole(plan.capital)}</div></div>
        <div className="detail-box"><div className="detail-label">Loss at stop-loss</div><div className="detail-value negative" data-testid="calc-planned-loss">{signedWhole(-plan.plannedLoss)}</div></div>
        {plan.worstCaseLoss !== null && (
          <div className="detail-box"><div className="detail-label">Worst case (premium)</div><div className="detail-value negative" data-testid="calc-worst-case">{signedWhole(-plan.worstCaseLoss)}</div></div>
        )}
        {plan.profits.map((profit) => (
          <div className="detail-box" key={profit.label}><div className="detail-label">Profit at {profit.label}</div><div className="detail-value positive" data-testid={`calc-profit-${profit.label.toLowerCase()}`}>{signedWhole(profit.amount)}</div></div>
        ))}
      </div>
      <p className="disclaimer">
        {signal.strategy === 'futures'
          ? `Futures losses can exceed margin. Margin here is an assumed ${(FUTURES_MARGIN_PCT * 100).toFixed(0)}% of contract value; brokerage, taxes and gaps through the stop are not included.`
          : 'Long options cannot lose more than the premium paid. Brokerage, taxes and bid-ask spread are not included, and the stop-loss assumes the model premium is achievable.'}
      </p>
    </article>
  );
}

function AnalysisCard({ signal }: { signal: FuturesSignal | OptionsSignal }) {
  const { recommendation } = signal;
  const breakdown = recommendation.confidenceBreakdown;
  const total = Object.values(breakdown).reduce((sum, value) => sum + value, 0);
  return (
    <article className="panel recommendation-card rp-engine-card" data-testid={`analysis-${signal.strategy}`}>
      <div className="recommendation-card-head">
        <div>
          <div className="eyebrow">RULE-BASED READ · UNDERLYING</div>
          <div className="recommendation-stock">{recommendation.name} <span>· {recommendation.symbol} · {recommendation.action}</span></div>
        </div>
        <span className="rp-demo-stamp">SIMULATED · DEMO ONLY</span>
      </div>
      <div className="confidence-row rp-confidence-row">
        <div>
          <div className="confidence-label">RULE CONFIDENCE</div>
          <div className="confidence-score" data-testid={`${signal.strategy}-confidence`}>{signal.confidence}<small> / 100</small></div>
        </div>
        <div className="rp-confidence-right">
          <div className="confidence-meter" aria-label={`Confidence ${signal.confidence} out of 100`}><span style={{ width: `${signal.confidence}%` }} /></div>
          <span className="rp-confidence-caption">Score is a rule tally, not a probability.</span>
        </div>
      </div>
      <section className="rp-breakdown" aria-label="Confidence score breakdown">
        <div className="rp-breakdown-head"><strong>How the score is built</strong><span>{total} raw points · capped at 100</span></div>
        {breakdownLabels.map(([key, label, rule]) => (
          <div className="rp-breakdown-row" key={key}><span>{label}<small>{rule}</small></span><b>{breakdown[key]}<i> pts</i></b></div>
        ))}
      </section>
      <section className="rp-confirmations">
        <div className="reasons-heading">TECHNICAL CONFIRMATION · STATIC FIXTURE</div>
        <div className="rp-indicator-grid">
          {recommendation.technicalIndicators.map((indicator) => (
            <div className="rp-indicator" key={indicator.label}>
              <span>{indicator.label}</span>
              <strong>{indicator.value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</strong>
              <em className={`rp-status rp-status-${indicator.status.toLowerCase()}`}>{indicator.status}</em>
            </div>
          ))}
        </div>
      </section>
      <div className="reasons-heading">WHY THIS SETUP</div>
      <ul className="recommendation-reasons" data-testid={`${signal.strategy}-reasons`}>
        {signal.reasons.map((reason, index) => <li key={`${index}-${reason}`}>{reason}</li>)}
      </ul>
      <div className="rp-timestamp"><span>LAST ANALYZED</span><time>{recommendation.lastAnalyzedAt}</time></div>
      <p className="disclaimer recommendation-disclaimer">Illustrative rule output only. Not a live signal, investment advice, or a promise of performance.</p>
    </article>
  );
}

// ------------------------------------------------------------------ Futures
function FuturesDetail({ signal }: { signal: FuturesSignal }) {
  return (
    <div className="ts-stack" data-testid="futures-detail">
      <article className="panel ts-card">
        <div className="rp-panel-title-row"><div><div className="eyebrow">CONTRACT · {signal.contract}</div><h2>Futures contract details</h2></div><span className="rp-demo-stamp">DEMO ASSUMPTIONS</span></div>
        <DetailGrid
          testPrefix="fut"
          items={[
            ['Underlying spot', price(signal.spot)],
            ['Futures price', price(signal.futuresPrice)],
            ['Basis', `${signal.basis >= 0 ? '+' : ''}${price(signal.basis)} (${signal.basisPct.toFixed(2)}%)`],
            ['Expiry', `${signal.expiryLabel} · ${signal.daysToExpiry}d`],
            ['Lot size', signal.lotSize.toLocaleString('en-IN')],
            ['Contract value', whole(signal.contractValue)],
            [`Margin / lot (${(signal.marginPct * 100).toFixed(0)}%)`, whole(signal.marginPerLot)],
            ['Risk / lot at SL', whole(signal.riskPerLot)],
          ]}
        />
      </article>
      <div className="recommendation-grid ts-reco-grid">
        <LevelsPanel signal={signal} entryLabel={`ENTRY · ${signal.side === 'LONG' ? 'BUY' : 'SELL'} FUTURES`} />
        <PositionCalculator signal={signal} />
      </div>
      <AnalysisCard signal={signal} />
    </div>
  );
}

// ------------------------------------------------------------------ Options
function OptionsDetail({ signal }: { signal: OptionsSignal }) {
  const { greeks } = signal;
  const under = (key: number | 'entry' | 'stop') => {
    if (key === 'entry') return `Underlying ${price(signal.underlyingLevels.entry)}`;
    if (key === 'stop') return `Underlying ${price(signal.underlyingLevels.stopLoss)}`;
    return `Underlying ${price(signal.underlyingLevels.targets[key].price)}`;
  };
  return (
    <div className="ts-stack" data-testid="options-detail">
      <article className="panel ts-card">
        <div className="rp-panel-title-row"><div><div className="eyebrow">CONTRACT · {signal.contract}</div><h2>Option contract details</h2></div><span className="rp-demo-stamp">MODEL ESTIMATE</span></div>
        <DetailGrid
          testPrefix="opt"
          items={[
            ['Underlying spot', price(signal.underlying)],
            ['Strike', `${signal.strike.toLocaleString('en-IN')} ${signal.optionType}`],
            ['Expiry', `${signal.expiryLabel} · ${signal.daysToExpiry}d`],
            ['Lot size', signal.lotSize.toLocaleString('en-IN')],
            ['Assumed IV', `${signal.assumedIvPct.toFixed(1)}%`],
            ['Breakeven at expiry', price(signal.breakeven)],
            ['Premium / lot', whole(signal.premiumPerLot)],
            ['Risk / lot at SL', whole(signal.riskPerLot)],
          ]}
        />
      </article>
      <article className="panel ts-card" data-testid="option-greeks">
        <div className="rp-panel-title-row"><div><div className="eyebrow">SENSITIVITIES · AT ENTRY</div><h2>Greeks</h2></div><span className="rp-demo-stamp">BLACK-SCHOLES</span></div>
        <DetailGrid
          testPrefix="greek"
          items={[
            ['Delta', greeks.delta.toFixed(2)],
            ['Gamma', greeks.gamma.toFixed(4)],
            ['Theta / day', `${greeks.thetaPerDay >= 0 ? '+' : '−'}₹${Math.abs(greeks.thetaPerDay).toFixed(2)}`],
            ['Vega / 1 vol pt', `₹${greeks.vegaPerVolPoint.toFixed(2)}`],
          ]}
        />
        <p className="disclaimer">
          Model inputs: assumed IV {signal.assumedIvPct.toFixed(1)}%, risk-free rate {(RISK_FREE_RATE * 100).toFixed(0)}%, {DAYS_TO_EXPIRY} days to expiry. Theta is per share
          per calendar day; the premium ladder below re-prices at one instant and ignores decay between entry and target.
        </p>
      </article>
      <div className="recommendation-grid ts-reco-grid">
        <LevelsPanel signal={signal} entryLabel={`ENTRY · BUY ${signal.optionType} PREMIUM`} extra={under} />
        <PositionCalculator signal={signal} />
      </div>
      <AnalysisCard signal={signal} />
    </div>
  );
}
