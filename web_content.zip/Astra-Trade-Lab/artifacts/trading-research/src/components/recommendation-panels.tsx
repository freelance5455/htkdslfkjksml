import { useMemo } from 'react';
import {
  getDemoTargetTrackingStatus,
  type DemoRecommendation,
} from '@/data/recommendation-utils';

const price = (value: number) =>
  `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const actionTone = (action: DemoRecommendation['action']) =>
  action.includes('BUY') ? 'buy' : action.includes('SELL') ? 'sell' : 'hold';

export const breakdownLabels: Array<[keyof DemoRecommendation['confidenceBreakdown'], string, string]> = [
  ['base', 'Base score', 'Starting score for every rule set'],
  ['momentum', 'Momentum', 'Up to 8 points · sample move × 2'],
  ['rsi', 'RSI distance', 'Up to 10 points · distance from 50 × 0.25'],
  ['trend', 'Trend alignment', '10 points when the trend aligns'],
  ['indicators', 'Indicator confirmation', '5 points per two confirmations · max 10'],
];

function DemoStamp() {
  return <span className="rp-demo-stamp" data-testid="recommendation-demo-only">SIMULATED · DEMO ONLY</span>;
}

export function RecommendationEngineCard({ recommendation }: { recommendation: DemoRecommendation }) {
  const { confidenceBreakdown } = recommendation;
  const breakdownTotal = useMemo(
    () => Object.values(confidenceBreakdown).reduce((sum, value) => sum + value, 0),
    [confidenceBreakdown],
  );
  const tone = actionTone(recommendation.action);

  return (
    <article className="panel recommendation-card rp-engine-card" data-testid="card-recommendation-engine">
      <div className="recommendation-card-head">
        <div>
          <div className="eyebrow">RULE-BASED READ · DEMO</div>
          <div className="recommendation-stock" data-testid="recommendation-identity">
            {recommendation.name} <span>· {recommendation.symbol}</span>
          </div>
        </div>
        <span className={`action-pill action-${tone}`} data-testid="recommendation-action">{recommendation.action}</span>
      </div>

      <div className="rp-entry-strip">
        <span>REFERENCE ENTRY</span>
        <strong data-testid="recommendation-entry">{price(recommendation.entry)}</strong>
        <DemoStamp />
      </div>

      <div className="confidence-row rp-confidence-row">
        <div>
          <div className="confidence-label">RULE CONFIDENCE</div>
          <div className="confidence-score" data-testid="recommendation-confidence">
            {recommendation.confidenceScore}<small> / 100</small>
          </div>
        </div>
        <div className="rp-confidence-right">
          <div className="confidence-meter" aria-label={`Confidence ${recommendation.confidenceScore} out of 100`}>
            <span style={{ width: `${Math.max(0, Math.min(100, recommendation.confidenceScore))}%` }} />
          </div>
          <span className="rp-confidence-caption">Score is a rule tally, not a probability.</span>
        </div>
      </div>

      <section className="rp-breakdown" aria-label="Confidence score breakdown">
        <div className="rp-breakdown-head">
          <strong>How the score is built</strong>
          <span data-testid="recommendation-breakdown-total">{breakdownTotal} raw points · capped at 100</span>
        </div>
        {breakdownLabels.map(([key, label, rule]) => (
          <div className="rp-breakdown-row" key={key} data-testid={`confidence-factor-${key}`}>
            <span>{label}<small>{rule}</small></span>
            <b>{confidenceBreakdown[key]}<i> pts</i></b>
          </div>
        ))}
      </section>

      <section className="rp-confirmations">
        <div className="reasons-heading">TECHNICAL CONFIRMATION · STATIC FIXTURE</div>
        <div className="rp-indicator-grid">
          {recommendation.technicalIndicators.map((indicator) => (
            <div className="rp-indicator" key={indicator.label} data-testid={`recommendation-indicator-${indicator.label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}>
              <span>{indicator.label}</span>
              <strong>{indicator.value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</strong>
              <em className={`rp-status rp-status-${indicator.status.toLowerCase()}`}>{indicator.status}</em>
            </div>
          ))}
        </div>
      </section>

      <div className="reasons-heading">WHY THIS READ</div>
      <ul className="recommendation-reasons" data-testid="recommendation-reasons">
        {recommendation.reasons.map((reason, index) => <li key={`${index}-${reason}`} data-testid={`recommendation-reason-${index + 1}`}>{reason}</li>)}
      </ul>
      <div className="rp-timestamp" data-testid="recommendation-timestamp">
        <span>LAST ANALYZED</span><time>{recommendation.lastAnalyzedAt}</time>
      </div>
      <p className="disclaimer recommendation-disclaimer">Illustrative rule output only. Not a live signal, investment advice, or a promise of performance.</p>
    </article>
  );
}

export function TradeSetupCard({ recommendation }: { recommendation: DemoRecommendation }) {
  const tone = actionTone(recommendation.action);
  return (
    <article className="panel trade-setup-card rp-setup-card" data-testid="card-trade-setup">
      <div className="rp-panel-title-row">
        <div>
          <div className="eyebrow">LEVEL MAP · {recommendation.symbol}</div>
          <h2>Trade setup</h2>
        </div>
        <DemoStamp />
      </div>
      <div className="rp-setup-summary">
        <span className={`action-pill action-${tone}`} data-testid="setup-action">{recommendation.action}</span>
        <span data-testid="setup-identity">{recommendation.name} · {recommendation.symbol}</span>
      </div>
      <div className="trade-primary-levels">
        <div className="trade-level trade-entry">
          <span className="trade-level-label">ENTRY · REFERENCE</span>
          <strong data-testid="setup-entry">{price(recommendation.entry)}</strong>
        </div>
        <div className="trade-level trade-stop">
          <span className="trade-level-label">STOP LOSS</span>
          <strong data-testid="setup-stop-loss">{price(recommendation.stopLoss)}</strong>
        </div>
      </div>
      <div className="targets-heading"><span>PROFIT TARGETS</span><span>PRICE / RISK : REWARD</span></div>
      <div className="trade-targets rp-target-list">
        {recommendation.targets.map((target) => (
          <div className="trade-target rp-target" key={target.label} data-testid={`setup-target-${target.label.toLowerCase()}`}>
            <span className="target-label">{target.label} · DEMO LEVEL</span>
            <strong data-testid={`setup-target-price-${target.label.toLowerCase()}`}>{price(target.price)}</strong>
            <span className="target-ratio">RISK : REWARD <b data-testid={`setup-target-rr-${target.label.toLowerCase()}`}>{target.riskReward === null ? '—' : `${target.riskReward.toFixed(2)}×`}</b></span>
          </div>
        ))}
      </div>
      <div className="rp-setup-foot">
        <span>ANALYZED <time data-testid="setup-timestamp">{recommendation.lastAnalyzedAt}</time></span>
        <span className="rp-demo-note">SIMULATED LEVELS · NOT LIVE</span>
      </div>
      <p className="disclaimer">Price levels are illustrative fixtures for research interface demonstration only.</p>
    </article>
  );
}

export function TargetTrackingCard({ recommendation, currentPrice }: { recommendation: DemoRecommendation; currentPrice: number }) {
  const status = getDemoTargetTrackingStatus(recommendation, currentPrice);
  const hitLabel = status === 'ACTIVE' || status === 'SL HIT' ? status : `${status.slice(0, 2)} REACHED`;
  const tone = status === 'SL HIT' ? 'stop' : status.includes('HIT') ? 'hit' : 'active';

  return (
    <article className="panel rp-tracking-card" data-testid="card-target-tracking">
      <div className="rp-panel-title-row">
        <div>
          <div className="eyebrow">LEVEL MONITOR · {recommendation.symbol}</div>
          <h2>Target tracking</h2>
        </div>
        <DemoStamp />
      </div>
      <div className="rp-tracking-top">
        <div className="rp-current-price">
          <span>SIMULATED CURRENT PRICE</span>
          <strong data-testid="tracking-current-price">{price(currentPrice)}</strong>
        </div>
        <span className={`rp-tracking-status rp-tracking-${tone}`} data-testid="tracking-status" aria-live="polite">{hitLabel}</span>
      </div>
      <div className="rp-track-table" role="table" aria-label="Simulated target level status">
        <div className="rp-track-head" role="row"><span role="columnheader">LEVEL</span><span role="columnheader">PRICE</span><span role="columnheader">RISK : REWARD</span><span role="columnheader">STATE</span></div>
        <div className="rp-track-row rp-track-stop" role="row" data-testid="tracking-stop-row">
          <span role="cell">STOP LOSS</span><strong role="cell" data-testid="tracking-stop-price">{price(recommendation.stopLoss)}</strong><span role="cell">—</span><span role="cell" className={status === 'SL HIT' ? 'rp-level-hit' : ''} data-testid="tracking-stop-state">{status === 'SL HIT' ? 'TRIGGERED' : 'INACTIVE'}</span>
        </div>
        {recommendation.targets.map((target) => {
          const hit = status === `${target.label} HIT` ||
            (status === 'T3 HIT' && target.label !== 'T3') ||
            (status === 'T2 HIT' && target.label === 'T1');
          return (
            <div className="rp-track-row" role="row" key={target.label} data-testid={`tracking-row-${target.label.toLowerCase()}`}>
              <span role="cell">{target.label}</span>
              <strong role="cell" data-testid={`tracking-price-${target.label.toLowerCase()}`}>{price(target.price)}</strong>
              <span role="cell" data-testid={`tracking-rr-${target.label.toLowerCase()}`}>{target.riskReward === null ? '—' : `${target.riskReward.toFixed(2)}×`}</span>
              <span role="cell" className={hit ? 'rp-level-hit' : ''} data-testid={`tracking-state-${target.label.toLowerCase()}`}>{hit ? 'REACHED' : 'PENDING'}</span>
            </div>
          );
        })}
      </div>
      <div className="rp-track-context">
        <span>{recommendation.name} · {recommendation.symbol}</span>
        <span>Entry reference {price(recommendation.entry)}</span>
      </div>
      <p className="disclaimer">Status is derived from the supplied demo price and rule levels; no live price feed is connected.</p>
    </article>
  );
}
