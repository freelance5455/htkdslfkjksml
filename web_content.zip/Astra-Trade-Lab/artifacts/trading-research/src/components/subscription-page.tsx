import { useState } from 'react';
import { Check, CircleHelp, Crown } from 'lucide-react';
import {
  PLANS,
  getPlan,
  planPrice,
  yearlySavings,
  type BillingCycle,
  type PlanId,
} from '@/data/profile';

const rupees = (value: number) => `₹${value.toLocaleString('en-IN')}`;

export function SubscriptionPage({ currentPlan, onChangePlan }: { currentPlan: PlanId; onChangePlan: (plan: PlanId) => void }) {
  const [cycle, setCycle] = useState<BillingCycle>('monthly');
  const [notice, setNotice] = useState('');
  const active = getPlan(currentPlan);

  const choose = (id: PlanId) => {
    if (id === currentPlan) return;
    onChangePlan(id);
    setNotice(`Switched to the ${getPlan(id).name} plan on this device. No payment was taken.`);
  };

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">Account / plan preview</div>
          <h1>Subscription</h1>
          <p className="page-description">Compare plans and see which one is active on this device.</p>
        </div>
        <span className="demo-pill">PREVIEW · NO BILLING</span>
      </div>

      <div className="market-banner" role="note" data-testid="notice-subscription-demo">
        <CircleHelp />
        <span>
          <strong>Plan preview only.</strong> Billing is not connected and prices are sample figures. Every feature that already exists is
          unlocked on all plans; items marked “Soon” are not built yet.
        </span>
      </div>

      <section className="panel sub-current" data-testid="subscription-current">
        <div>
          <div className="eyebrow">CURRENT PLAN</div>
          <div className="sub-current-name" data-testid="current-plan-name">{active.name}</div>
          <div className="sub-current-meta">{active.tagline}</div>
        </div>
        <div className="sub-current-side">
          <span className="plan-badge" data-plan={active.id}>{active.name.toUpperCase()}</span>
          <span className="sub-current-meta">Renewal: not applicable (no billing)</span>
        </div>
      </section>

      <div className="sub-toolbar">
        <div className="mh-control-group" role="group" aria-label="Billing cycle">
          {(['monthly', 'yearly'] as const).map((value) => (
            <button
              key={value}
              type="button"
              className={`mh-control${cycle === value ? ' is-active' : ''}`}
              aria-pressed={cycle === value}
              onClick={() => setCycle(value)}
              data-testid={`billing-${value}`}
            >
              {value === 'monthly' ? 'Monthly' : 'Yearly · save ~17%'}
            </button>
          ))}
        </div>
        <span className="panel-meta" role="status" aria-live="polite" data-testid="subscription-notice">{notice}</span>
      </div>

      <div className="plan-grid" data-testid="plan-grid">
        {PLANS.map((plan) => {
          const isCurrent = plan.id === currentPlan;
          const price = planPrice(plan, cycle);
          const savings = yearlySavings(plan);
          return (
            <article
              key={plan.id}
              className={`panel plan-card${plan.highlight ? ' is-featured' : ''}${isCurrent ? ' is-current' : ''}`}
              data-testid={`plan-card-${plan.id}`}
              aria-current={isCurrent ? 'true' : undefined}
            >
              <div className="plan-head">
                <div className="plan-name">
                  {plan.highlight && <Crown size={13} aria-hidden="true" />}
                  {plan.name}
                </div>
                {isCurrent
                  ? <span className="plan-badge" data-plan={plan.id} data-testid={`plan-current-${plan.id}`}>CURRENT</span>
                  : plan.highlight && <span className="plan-badge plan-badge-soft">POPULAR</span>}
              </div>
              <p className="plan-tagline">{plan.tagline}</p>
              <div className="plan-price" data-testid={`plan-price-${plan.id}`}>
                {price === 0 ? 'Free' : rupees(price)}
                {price > 0 && <small>/{cycle === 'monthly' ? 'month' : 'year'}</small>}
              </div>
              <div className="plan-save">
                {price > 0 && cycle === 'yearly' ? `Saves ${rupees(savings)} vs monthly` : price > 0 ? `${rupees(plan.yearly)}/year if billed yearly` : 'No card needed'}
              </div>
              <ul className="plan-features">
                {plan.features.map((feature) => (
                  <li key={feature.label} className={feature.soon ? 'is-soon' : ''}>
                    <Check size={12} aria-hidden="true" />
                    <span>{feature.label}</span>
                    {feature.soon && <em>SOON</em>}
                  </li>
                ))}
              </ul>
              <button
                type="button"
                className={`button plan-button${isCurrent ? ' secondary' : ''}`}
                disabled={isCurrent}
                onClick={() => choose(plan.id)}
                data-testid={`plan-select-${plan.id}`}
              >
                {isCurrent ? 'Current plan' : `Switch to ${plan.name}`}
              </button>
            </article>
          );
        })}
      </div>

      <p className="disclaimer">
        Sample pricing in Indian rupees for interface preview. Selecting a plan only changes the label stored in this browser; it does not
        charge anything or restrict features.
      </p>
    </>
  );
}
