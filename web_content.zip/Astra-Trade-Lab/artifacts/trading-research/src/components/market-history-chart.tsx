import { useId, useMemo, useState } from 'react';
import type { PointerEvent, KeyboardEvent } from 'react';
import type { Stock } from '@/data/demo-data';
import {
  CHART_TIMEFRAMES,
  generateDemoChartHistory,
  type ChartStyle,
  type ChartTimeframe,
} from '@/data/chart-utils';

const formatPrice = (value: number) =>
  `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const formatVolume = (value: number) =>
  value >= 1_000_000 ? `${(value / 1_000_000).toFixed(2)}M` : `${(value / 1_000).toFixed(0)}K`;

const SVG_WIDTH = 720;
const PLOT_LEFT = 54;
const PLOT_RIGHT = 704;
const PLOT_TOP = 18;
const PLOT_BOTTOM = 208;
const VOLUME_TOP = 234;
const VOLUME_BOTTOM = 290;

export function MarketHistoryChart({ stock }: { stock: Stock }) {
  const [timeframe, setTimeframe] = useState<ChartTimeframe>('1D');
  const [style, setStyle] = useState<ChartStyle>('line');
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const history = useMemo(() => generateDemoChartHistory(stock, timeframe), [stock, timeframe]);
  const activeIndex = hoverIndex === null ? history.points.length - 1 : hoverIndex;
  const active = history.points[activeIndex];
  const id = useId().replace(/:/g, '');
  const gradientId = `market-chart-fill-${id}`;
  const prices = history.points.flatMap((point) => [point.high, point.low]);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const pad = Math.max((maxPrice - minPrice) * 0.12, stock.price * 0.002);
  const scaleMin = minPrice - pad;
  const scaleMax = maxPrice + pad;
  const xAt = (index: number) => PLOT_LEFT + (index / Math.max(history.points.length - 1, 1)) * (PLOT_RIGHT - PLOT_LEFT);
  const yAt = (value: number) => PLOT_BOTTOM - ((value - scaleMin) / (scaleMax - scaleMin)) * (PLOT_BOTTOM - PLOT_TOP);
  const maxVolume = Math.max(...history.points.map((point) => point.volume));
  const linePoints = history.points.map((point, index) => `${xAt(index)},${yAt(point.close)}`).join(' ');
  const areaPath = `M ${xAt(0)} ${PLOT_BOTTOM} ${history.points.map((point, index) => `L ${xAt(index)} ${yAt(point.close)}`).join(' ')} L ${xAt(history.points.length - 1)} ${PLOT_BOTTOM} Z`;
  const positive = history.percentageChange >= 0;
  const changeLabel = `${positive ? '+' : ''}${history.percentageChange.toFixed(2)}%`;

  const onPointerMove = (event: PointerEvent<SVGSVGElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const svgX = ((event.clientX - bounds.left) / bounds.width) * SVG_WIDTH;
    const progress = Math.max(0, Math.min(1, (svgX - PLOT_LEFT) / (PLOT_RIGHT - PLOT_LEFT)));
    setHoverIndex(Math.round(progress * (history.points.length - 1)));
  };
  const onKeyDown = (event: KeyboardEvent<SVGSVGElement>) => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      setHoverIndex((current) => {
        const index = current ?? history.points.length - 1;
        return Math.max(0, Math.min(history.points.length - 1, index + (event.key === 'ArrowLeft' ? -1 : 1)));
      });
    } else if (event.key === 'Home') {
      event.preventDefault();
      setHoverIndex(0);
    } else if (event.key === 'End') {
      event.preventDefault();
      setHoverIndex(history.points.length - 1);
    }
  };

  return (
    <section className="panel mh-chart" data-testid="card-market-history-chart" aria-label={`${stock.symbol} simulated market history`}>
      <div className="mh-heading">
        <div className="mh-title-block">
          <div className="eyebrow">PRICE STRUCTURE · SIMULATED</div>
          <div className="mh-instrument">
            <strong data-testid="chart-stock-symbol">{stock.symbol}</strong>
            <span>{stock.company} · {stock.exchange} fixture</span>
          </div>
          <div className="mh-change-line">
            <strong className={positive ? 'positive' : 'negative'} data-testid="chart-percentage-change">{changeLabel}</strong>
            <span>period change · {timeframe}</span>
          </div>
        </div>
        <span className="demo-pill mh-demo-pill">DEMO HISTORY · NOT LIVE</span>
      </div>
      <div className="mh-toolbar">
        <div className="mh-control-group" role="group" aria-label="Chart timeframe">
          {CHART_TIMEFRAMES.map((range) => (
            <button key={range} type="button" className={`mh-control${timeframe === range ? ' is-active' : ''}`} aria-pressed={timeframe === range} onClick={() => { setTimeframe(range); setHoverIndex(null); }} data-testid={`chart-timeframe-${range.toLowerCase()}`}>{range}</button>
          ))}
        </div>
        <div className="mh-control-group mh-style-group" role="group" aria-label="Chart style">
          {(['line', 'candlestick'] as const).map((mode) => (
            <button key={mode} type="button" className={`mh-control${style === mode ? ' is-active' : ''}`} aria-pressed={style === mode} onClick={() => setStyle(mode)} data-testid={`chart-style-${mode}`}>
              {mode === 'line' ? 'Line' : 'Candles'}
            </button>
          ))}
        </div>
      </div>
      <div className="mh-readout" aria-live="polite" data-testid="chart-hover-readout">
        <span className="mh-readout-date" data-testid="chart-hover-date">{active.dateLabel} <i>· {timeframe} · DEMO</i></span>
        <span><small>O</small><b data-testid="chart-hover-open">{formatPrice(active.open)}</b></span>
        <span><small>H</small><b data-testid="chart-hover-high">{formatPrice(active.high)}</b></span>
        <span><small>L</small><b data-testid="chart-hover-low">{formatPrice(active.low)}</b></span>
        <span><small>C</small><b data-testid="chart-hover-close">{formatPrice(active.close)}</b></span>
        <span><small>VOL</small><b data-testid="chart-hover-volume">{formatVolume(active.volume)}</b></span>
      </div>
      <div className="mh-svg-wrap">
        <svg
          className="mh-svg"
          viewBox={`0 0 ${SVG_WIDTH} 316`}
          role="img"
          aria-label={`${stock.symbol} simulated ${timeframe} ${style} chart. Use left and right arrow keys to inspect values.`}
          tabIndex={0}
          onPointerMove={onPointerMove}
          onPointerLeave={() => setHoverIndex(null)}
          onPointerDown={onPointerMove}
          onKeyDown={onKeyDown}
          data-testid="chart-plot"
        >
          <defs>
            <linearGradient id={gradientId} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={positive ? '#67c998' : '#dd8179'} stopOpacity=".22" />
              <stop offset="100%" stopColor={positive ? '#67c998' : '#dd8179'} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0, 1, 2, 3].map((row) => {
            const y = PLOT_TOP + ((PLOT_BOTTOM - PLOT_TOP) / 3) * row;
            const value = scaleMax - ((scaleMax - scaleMin) / 3) * row;
            return <g key={row}><line x1={PLOT_LEFT} x2={PLOT_RIGHT} y1={y} y2={y} className="mh-gridline" /><text x="0" y={y + 3} className="mh-axis-value">{formatPrice(value)}</text></g>;
          })}
          {history.points.map((point, index) => {
            const x = xAt(index);
            const height = Math.max(2, (point.volume / maxVolume) * (VOLUME_BOTTOM - VOLUME_TOP));
            return <rect key={`vol-${index}`} x={x - Math.max(1.5, 250 / history.points.length)} y={VOLUME_BOTTOM - height} width={Math.max(2, 500 / history.points.length)} height={height} className={`mh-volume${point.close >= point.open ? ' up' : ' down'}`} />;
          })}
          {style === 'line' ? (
            <>
              <path d={areaPath} fill={`url(#${gradientId})`} />
              <polyline points={linePoints} className={`mh-price-line${positive ? '' : ' down'}`} />
            </>
          ) : history.points.map((point, index) => {
            const x = xAt(index);
            const candleWidth = Math.max(3, Math.min(11, 420 / history.points.length));
            const up = point.close >= point.open;
            const yOpen = yAt(point.open);
            const yClose = yAt(point.close);
            return <g key={`candle-${index}`} className={up ? 'mh-candle-up' : 'mh-candle-down'}>
              <line x1={x} x2={x} y1={yAt(point.high)} y2={yAt(point.low)} className="mh-candle-wick" />
              <rect x={x - candleWidth / 2} y={Math.min(yOpen, yClose)} width={candleWidth} height={Math.max(1.5, Math.abs(yClose - yOpen))} className="mh-candle-body" />
            </g>;
          })}
          <text x={PLOT_LEFT} y="314" className="mh-axis-label">{history.axisLabels[0]}</text>
          <text x={(PLOT_LEFT + PLOT_RIGHT) / 2} y="314" textAnchor="middle" className="mh-axis-label">{history.axisLabels[2]}</text>
          <text x={PLOT_RIGHT} y="314" textAnchor="end" className="mh-axis-label">{history.axisLabels[4]}</text>
          {hoverIndex !== null && (
            <g className="mh-crosshair" aria-hidden="true">
              <line x1={xAt(activeIndex)} x2={xAt(activeIndex)} y1={PLOT_TOP} y2={VOLUME_BOTTOM} />
              <circle cx={xAt(activeIndex)} cy={yAt(active.close)} r="4" />
              <rect x={Math.min(PLOT_RIGHT - 65, Math.max(PLOT_LEFT, xAt(activeIndex) - 32))} y="2" width="64" height="15" rx="3" />
              <text x={Math.min(PLOT_RIGHT - 33, Math.max(PLOT_LEFT + 32, xAt(activeIndex)))} y="12" textAnchor="middle">{active.dateLabel}</text>
            </g>
          )}
        </svg>
      </div>
      <div className="mh-chart-foot">
        <span><i className={`mh-legend-line${positive ? '' : ' down'}`} />{style === 'line' ? 'Close' : 'OHLC'} <i className="mh-legend-volume" />Volume</span>
        <span data-testid="chart-data-label">Generated locally · fictional history</span>
      </div>
      <p className="mh-accessible-note">Hover, touch, or focus the plot and use arrow keys to inspect simulated OHLC and volume values.</p>
    </section>
  );
}
