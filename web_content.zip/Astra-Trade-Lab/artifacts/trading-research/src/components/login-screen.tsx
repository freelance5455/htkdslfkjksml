import { useState, type FormEvent } from 'react';
import { Activity, ArrowRight, CircleHelp } from 'lucide-react';
import { MAX_NAME_LENGTH, normalizeName, validateName } from '@/data/profile';

export function LoginScreen({ onLogin }: { onLogin: (name: string) => void }) {
  const [name, setName] = useState('');
  const [touched, setTouched] = useState(false);
  const error = validateName(name);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    setTouched(true);
    if (error) return;
    onLogin(normalizeName(name));
  };

  return (
    <div className="login-shell" data-testid="login-screen">
      <form className="login-card panel" onSubmit={submit} noValidate>
        <div className="login-brand">
          <div className="brand-mark"><Activity size={18} /></div>
          <div>
            <div className="brand-name">ASTRA TRADE LAB</div>
            <div className="brand-sub">RESEARCH ENGINE / INDIA</div>
          </div>
        </div>
        <h1 className="login-title">Welcome back</h1>
        <p className="page-description">Enter your name to open your research desk.</p>

        <label className="login-field" htmlFor="login-name">
          <span>YOUR NAME</span>
          <input
            id="login-name"
            className="control"
            autoComplete="given-name"
            autoFocus
            maxLength={MAX_NAME_LENGTH + 10}
            placeholder="e.g. Aakash"
            value={name}
            onChange={(event) => setName(event.target.value)}
            onBlur={() => setTouched(true)}
            aria-invalid={touched && !!error}
            aria-describedby="login-error"
            data-testid="input-login-name"
          />
        </label>
        <div id="login-error" className="login-error" role="alert" data-testid="login-error">
          {touched && error ? error : ''}
        </div>

        <button type="submit" className="button login-button" data-testid="button-login">
          Open research desk <ArrowRight size={13} />
        </button>

        <div className="market-banner login-note" role="note" data-testid="login-note">
          <CircleHelp />
          <span>
            <strong>Local profile only.</strong> Your name is saved on this device so the app can greet you. There is no password or
            server account yet, and all market data is fictional demo data.
          </span>
        </div>
      </form>
    </div>
  );
}
