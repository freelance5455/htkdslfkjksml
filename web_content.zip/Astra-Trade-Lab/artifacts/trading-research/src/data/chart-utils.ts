import type { Stock } from './demo-data.ts';

export const CHART_TIMEFRAMES = ['1D', '1W', '1M', '3M', '6M', '1Y', '5Y'] as const;
export type ChartTimeframe = (typeof CHART_TIMEFRAMES)[number];
export type ChartStyle = 'line' | 'candlestick';

export type DemoCandle = {
  dateLabel: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type DemoChartHistory = {
  timeframe: ChartTimeframe;
  points: DemoCandle[];
  axisLabels: string[];
  percentageChange: number;
};

const HISTORY_CONFIG: Record<ChartTimeframe, { count: number; days: number; driftFactor: number; volatility: number }> = {
  '1D': { count: 32, days: 1, driftFactor: 1, volatility: 0.006 },
  '1W': { count: 35, days: 7, driftFactor: 1.5, volatility: 0.014 },
  '1M': { count: 30, days: 30, driftFactor: 2, volatility: 0.025 },
  '3M': { count: 36, days: 90, driftFactor: 2.8, volatility: 0.045 },
  '6M': { count: 26, days: 180, driftFactor: 3.5, volatility: 0.065 },
  '1Y': { count: 24, days: 365, driftFactor: 4.5, volatility: 0.09 },
  '5Y': { count: 40, days: 1825, driftFactor: 6, volatility: 0.14 },
};

const DEMO_END_DATE = Date.UTC(2025, 2, 24);
const DAY_MS = 24 * 60 * 60 * 1000;
const rounded = (value: number) => Number(value.toFixed(2));

function dateLabel(timeframe: ChartTimeframe, index: number, count: number, days: number): string {
  const progress = index / Math.max(count - 1, 1);
  if (timeframe === '1D') {
    const minuteOfDay = 9 * 60 + 15 + progress * (6 * 60 + 15);
    const hours = Math.floor(minuteOfDay / 60);
    const minutes = Math.round(minuteOfDay % 60);
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  }

  const date = new Date(DEMO_END_DATE - (1 - progress) * days * DAY_MS);
  const month = new Intl.DateTimeFormat('en-IN', { month: 'short', timeZone: 'UTC' }).format(date);
  return timeframe === '5Y'
    ? `${month} ${date.getUTCFullYear()}`
    : `${date.getUTCDate()} ${month}`;
}

export function generateDemoChartHistory(stock: Stock, timeframe: ChartTimeframe): DemoChartHistory {
  const config = HISTORY_CONFIG[timeframe];
  const symbolSeed = stock.symbol.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
  const drift = Math.max(-25, Math.min(25, stock.changePct * config.driftFactor)) / 100;
  const rawPoints = Array.from({ length: config.count }, (_, index) => {
    const progress = index / (config.count - 1);
    const wave = Math.sin((index + symbolSeed % 11) * 0.61) * 0.56 +
      Math.cos((index + symbolSeed % 7) * 0.27) * 0.44;
    const finalWave = Math.sin((config.count - 1 + symbolSeed % 11) * 0.61) * 0.56 +
      Math.cos((config.count - 1 + symbolSeed % 7) * 0.27) * 0.44;
    const normalizedWave = (wave - finalWave) * config.volatility;
    const close = stock.price * (1 - drift * (1 - progress) + normalizedWave);
    return {
      progress,
      close: rounded(close),
      dateLabel: dateLabel(timeframe, index, config.count, config.days),
    };
  });

  const points = rawPoints.map((point, index) => {
    const previousClose = index === 0 ? point.close * (1 - stock.changePct / 100) : rawPoints[index - 1].close;
    const open = rounded(previousClose * (1 + Math.sin((index + symbolSeed) * 0.8) * config.volatility * 0.22));
    const wick = config.volatility * (0.18 + Math.abs(Math.sin(index + symbolSeed)) * 0.38);
    const high = rounded(Math.max(open, point.close) * (1 + wick));
    const low = rounded(Math.min(open, point.close) * (1 - wick));
    const volume = Math.round(
      120_000 +
      Math.abs(Math.sin(index * 1.7 + symbolSeed)) * 1_100_000 +
      Math.abs(Math.cos(index * 0.31 + symbolSeed)) * 540_000,
    );

    return { dateLabel: point.dateLabel, open, high, low, close: point.close, volume };
  });

  const labelIndexes = [0, 0.25, 0.5, 0.75, 1].map((fraction) =>
    Math.round(fraction * (points.length - 1)),
  );

  return {
    timeframe,
    points,
    axisLabels: labelIndexes.map((index) => points[index].dateLabel),
    percentageChange: rounded(((points.at(-1)!.close - points[0].close) / points[0].close) * 100),
  };
}
