/**
 * Local user profile, greeting and subscription plans.
 *
 * IMPORTANT: this is a device-local profile, not account security. There is no password,
 * server, or payment processor yet. Plan changes are stored in this browser only.
 */

export type PlanId = 'starter' | 'pro' | 'elite';
export type BillingCycle = 'monthly' | 'yearly';

export type PlanFeature = { label: string; soon?: boolean };

export type Plan = {
  id: PlanId;
  name: string;
  tagline: string;
  monthly: number;
  yearly: number;
  features: PlanFeature[];
  highlight?: boolean;
};

export const PLANS: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    tagline: 'Core research desk for getting started.',
    monthly: 0,
    yearly: 0,
    features: [
      { label: 'Market overview, scanner and watchlist' },
      { label: 'Technical and fundamental snapshots' },
      { label: 'Swing trade signals' },
      { label: 'Interactive price charts (7 timeframes)' },
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    tagline: 'Derivatives desks and position planning.',
    monthly: 499,
    yearly: 4990,
    highlight: true,
    features: [
      { label: 'Everything in Starter' },
      { label: 'Options signals with Greeks and premium levels' },
      { label: 'Futures signals with margin and basis' },
      { label: 'Position-size calculator for every signal' },
      { label: 'Price and target alerts', soon: true },
    ],
  },
  {
    id: 'elite',
    name: 'Elite',
    tagline: 'Full research workflow and automation.',
    monthly: 999,
    yearly: 9990,
    features: [
      { label: 'Everything in Pro' },
      { label: 'Strategy backtesting', soon: true },
      { label: 'Portfolio and P&L tracker', soon: true },
      { label: 'AI research summaries', soon: true },
      { label: 'Live market data connection', soon: true },
    ],
  },
];

export type Profile = { name: string; plan: PlanId };

export const PROFILE_STORAGE_KEY = 'astra-profile';
export const MAX_NAME_LENGTH = 30;

type StorageLike = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;

const browserStorage = (): StorageLike | null => {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage;
  } catch {
    return null;
  }
};

export const isPlanId = (value: unknown): value is PlanId =>
  value === 'starter' || value === 'pro' || value === 'elite';

export function validateName(raw: string): string | null {
  const name = raw.trim();
  if (name.length < 2) return 'Please enter at least 2 characters.';
  if (name.length > MAX_NAME_LENGTH) return `Name can be at most ${MAX_NAME_LENGTH} characters.`;
  if (!/\p{L}/u.test(name)) return 'Name must contain at least one letter.';
  return null;
}

export const normalizeName = (raw: string) => raw.trim().replace(/\s+/g, ' ');

export function loadProfile(storage: StorageLike | null = browserStorage()): Profile | null {
  if (!storage) return null;
  try {
    const parsed = JSON.parse(storage.getItem(PROFILE_STORAGE_KEY) ?? 'null') as Partial<Profile> | null;
    if (!parsed || typeof parsed.name !== 'string' || validateName(parsed.name) !== null) return null;
    return { name: normalizeName(parsed.name), plan: isPlanId(parsed.plan) ? parsed.plan : 'starter' };
  } catch {
    return null;
  }
}

export function saveProfile(profile: Profile, storage: StorageLike | null = browserStorage()): void {
  try {
    storage?.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
  } catch {
    /* storage unavailable (private mode): the session still works in memory */
  }
}

export function clearProfile(storage: StorageLike | null = browserStorage()): void {
  try {
    storage?.removeItem(PROFILE_STORAGE_KEY);
  } catch {
    /* ignore */
  }
}

export type Greeting = 'Good morning' | 'Good afternoon' | 'Good evening';

/** 05:00–11:59 morning, 12:00–16:59 afternoon, everything else evening. */
export function getGreeting(hour: number): Greeting {
  const h = ((Math.floor(hour) % 24) + 24) % 24;
  if (h >= 5 && h < 12) return 'Good morning';
  if (h >= 12 && h < 17) return 'Good afternoon';
  return 'Good evening';
}

export function getInitials(name: string): string {
  const parts = normalizeName(name).split(' ').filter(Boolean);
  if (!parts.length) return '?';
  const letters = parts.length === 1 ? [...parts[0]].slice(0, 2) : [[...parts[0]][0], [...parts[parts.length - 1]][0]];
  return letters.join('').toUpperCase();
}

export const getPlan = (id: PlanId): Plan => PLANS.find((plan) => plan.id === id) ?? PLANS[0];

export function planPrice(plan: Plan, cycle: BillingCycle): number {
  return cycle === 'monthly' ? plan.monthly : plan.yearly;
}

/** Whole rupees saved by paying yearly instead of 12 monthly payments. */
export const yearlySavings = (plan: Plan) => Math.max(0, plan.monthly * 12 - plan.yearly);
