export type IndexQuote = {
  symbol: string;
  value: number;
  changePct: number;
  open: number;
  high: number;
  low: number;
  prevClose: number;
};

export type Exchange = 'NSE' | 'BSE';

export type Stock = {
  symbol: string;
  company: string;
  sector: string;
  exchange: Exchange;
  price: number;
  changePct: number;
  volume: number;
  rsi: number;
  ema20: number;
  ema50: number;
  macd: number;
  trend: 'Uptrend' | 'Downtrend' | 'Sideways';
  signal: 'Bullish' | 'Bearish' | 'Neutral';
  entry: number;
  target: number;
  stopLoss: number;
  pe: number;
  roe: number;
  marketCap: number;
};

export type OrderBook = {
  symbol: string;
  bidQty: number;
  askQty: number;
  bidLevels: { price: number; quantity: number }[];
  askLevels: { price: number; quantity: number }[];
};

export type NewsItem = {
  headline: string;
  source: string;
  sentiment: 'Positive' | 'Negative' | 'Mixed';
  publishedAt: string;
};

type BaseDemoStock = Omit<Stock, 'exchange' | 'ema20' | 'ema50' | 'macd'>;

const baseStocks: BaseDemoStock[] = [
  { symbol: 'RELIANCE', company: 'Reliance Industries', sector: 'Energy', price: 2846.35, changePct: 1.24, volume: 4281900, rsi: 62.8, trend: 'Uptrend', signal: 'Bullish', entry: 2828, target: 2910, stopLoss: 2788, pe: 28.4, roe: 9.8, marketCap: 1926400 },
  { symbol: 'HDFCBANK', company: 'HDFC Bank', sector: 'Banking', price: 1684.2, changePct: -0.48, volume: 7654200, rsi: 46.2, trend: 'Sideways', signal: 'Neutral', entry: 1695, target: 1740, stopLoss: 1660, pe: 18.7, roe: 16.2, marketCap: 1287100 },
  { symbol: 'ICICIBANK', company: 'ICICI Bank', sector: 'Banking', price: 1248.6, changePct: 1.87, volume: 5940800, rsi: 67.4, trend: 'Uptrend', signal: 'Bullish', entry: 1237, target: 1288, stopLoss: 1214, pe: 19.2, roe: 17.1, marketCap: 876500 },
  { symbol: 'INFY', company: 'Infosys', sector: 'Information Technology', price: 1482.75, changePct: -1.12, volume: 3897600, rsi: 39.6, trend: 'Downtrend', signal: 'Bearish', entry: 1496, target: 1438, stopLoss: 1522, pe: 22.8, roe: 31.6, marketCap: 615800 },
  { symbol: 'TCS', company: 'Tata Consultancy Services', sector: 'Information Technology', price: 3914.5, changePct: 0.62, volume: 1145200, rsi: 55.1, trend: 'Uptrend', signal: 'Bullish', entry: 3890, target: 3998, stopLoss: 3844, pe: 30.1, roe: 51.4, marketCap: 1419800 },
  { symbol: 'SBIN', company: 'State Bank of India', sector: 'Banking', price: 812.35, changePct: 2.16, volume: 8723400, rsi: 71.2, trend: 'Uptrend', signal: 'Bullish', entry: 803, target: 841, stopLoss: 790, pe: 10.7, roe: 17.4, marketCap: 725600 },
  { symbol: 'LT', company: 'Larsen & Toubro', sector: 'Infrastructure', price: 3628.8, changePct: 0.36, volume: 1425600, rsi: 58.3, trend: 'Sideways', signal: 'Neutral', entry: 3610, target: 3705, stopLoss: 3568, pe: 34.6, roe: 16.8, marketCap: 499200 },
  { symbol: 'TATAMOTORS', company: 'Tata Motors', sector: 'Automotive', price: 974.6, changePct: -2.08, volume: 6321500, rsi: 34.8, trend: 'Downtrend', signal: 'Bearish', entry: 991, target: 945, stopLoss: 1009, pe: 10.2, roe: 36.3, marketCap: 358700 },
  { symbol: 'BHARTIARTL', company: 'Bharti Airtel', sector: 'Telecom', price: 1438.25, changePct: 1.03, volume: 2167300, rsi: 61.1, trend: 'Uptrend', signal: 'Bullish', entry: 1426, target: 1480, stopLoss: 1404, pe: 72.5, roe: 14.1, marketCap: 861400 },
  { symbol: 'ITC', company: 'ITC Limited', sector: 'Consumer Staples', price: 428.9, changePct: 0.18, volume: 4519000, rsi: 51.4, trend: 'Sideways', signal: 'Neutral', entry: 427, target: 441, stopLoss: 419, pe: 26.3, roe: 27.5, marketCap: 535100 },
  { symbol: 'AXISBANK', company: 'Axis Bank', sector: 'Banking', price: 1124.75, changePct: -0.76, volume: 3412700, rsi: 43.7, trend: 'Downtrend', signal: 'Bearish', entry: 1136, target: 1098, stopLoss: 1154, pe: 12.8, roe: 16.4, marketCap: 347800 },
  { symbol: 'SUNPHARMA', company: 'Sun Pharmaceutical', sector: 'Healthcare', price: 1688.3, changePct: 1.46, volume: 1289600, rsi: 64.2, trend: 'Uptrend', signal: 'Bullish', entry: 1670, target: 1732, stopLoss: 1642, pe: 38.9, roe: 16.9, marketCap: 405900 },
  { symbol: 'MARUTI', company: 'Maruti Suzuki', sector: 'Automotive', price: 12472, changePct: -0.34, volume: 284300, rsi: 48.5, trend: 'Sideways', signal: 'Neutral', entry: 12520, target: 12840, stopLoss: 12280, pe: 27.2, roe: 15.8, marketCap: 392600 },
  { symbol: 'WIPRO', company: 'Wipro Limited', sector: 'Information Technology', price: 486.1, changePct: -1.64, volume: 2956400, rsi: 37.2, trend: 'Downtrend', signal: 'Bearish', entry: 493, target: 468, stopLoss: 502, pe: 22.1, roe: 15.2, marketCap: 253400 },
  { symbol: 'ADANIPORTS', company: 'Adani Ports', sector: 'Infrastructure', price: 1387.7, changePct: 2.42, volume: 1843900, rsi: 73.5, trend: 'Uptrend', signal: 'Bullish', entry: 1368, target: 1436, stopLoss: 1342, pe: 29.8, roe: 18.4, marketCap: 299700 },
];

// These exchange tags and indicator readings are deterministic demo fixtures,
// not exchange-sourced listings or calculations from live market candles.
const stocks: Stock[] = baseStocks.map((stock, index) => {
  const sampleMove = stock.changePct / 100;
  const ema20 = Number((stock.price * (1 - sampleMove * 0.22)).toFixed(2));
  const ema50 = Number((stock.price * (1 - sampleMove * 0.45)).toFixed(2));

  return {
    ...stock,
    exchange: index % 2 === 0 ? 'NSE' : 'BSE',
    ema20,
    ema50,
    macd: Number((ema20 - ema50).toFixed(2)),
  };
});

export const marketDemo = {
  indices: [
    { symbol: 'NIFTY 50', value: 22493.55, changePct: 0.74, open: 22334.2, high: 22521.8, low: 22298.4, prevClose: 22328.4 },
    { symbol: 'BANK NIFTY', value: 48256.9, changePct: -0.28, open: 48412.5, high: 48540.2, low: 48096.7, prevClose: 48392.1 },
  ] satisfies IndexQuote[],
  stocks,
  orderBooks: stocks.map((stock, i) => {
    const bidLevels = [1, 2, 3, 4, 5].map((step) => ({ price: +(stock.price - step * stock.price * 0.0007).toFixed(2), quantity: 340 + ((i * 173 + step * 239) % 1850) }));
    const askLevels = [1, 2, 3, 4, 5].map((step) => ({ price: +(stock.price + step * stock.price * 0.0007).toFixed(2), quantity: 280 + ((i * 211 + step * 197) % 1640) }));
    return { symbol: stock.symbol, bidQty: bidLevels.reduce((a, b) => a + b.quantity, 0), askQty: askLevels.reduce((a, b) => a + b.quantity, 0), bidLevels, askLevels } satisfies OrderBook;
  }),
  news: [
    { headline: 'Private lenders lead early gains as credit growth stays firm in latest sector data', source: 'Market Ledger', sentiment: 'Positive', publishedAt: '09:42 IST' },
    { headline: 'IT stocks under pressure; analysts watch demand commentary ahead of quarterly updates', source: 'The Exchange Brief', sentiment: 'Negative', publishedAt: '09:26 IST' },
    { headline: 'Crude eases from session highs, offering a modest tailwind to downstream names', source: 'Capital Wire', sentiment: 'Positive', publishedAt: '09:11 IST' },
    { headline: 'Auto names diverge as monthly dispatch expectations remain mixed across manufacturers', source: 'Market Ledger', sentiment: 'Mixed', publishedAt: '08:54 IST' },
    { headline: 'Rupee opens steady; foreign flows remain in focus for domestic equity desks', source: 'The Exchange Brief', sentiment: 'Mixed', publishedAt: '08:38 IST' },
  ] satisfies NewsItem[],
};

// Adapter seam: replace this local fixture implementation with an approved provider later.
// No network calls or live market information are used in this demo.
export interface MarketDataAdapter {
  getIndices(): IndexQuote[];
  getStocks(): Stock[];
  getOrderBooks(): OrderBook[];
  getNews(): NewsItem[];
}

export const demoMarketData: MarketDataAdapter = {
  getIndices: () => marketDemo.indices,
  getStocks: () => marketDemo.stocks,
  getOrderBooks: () => marketDemo.orderBooks,
  getNews: () => marketDemo.news,
};
