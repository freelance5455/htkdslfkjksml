import type { Stock } from './demo-data.ts';
import { calculateRiskReward } from './scanner-utils.ts';

export type RecommendationAction = 'STRONG BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG SELL';
export type BaseRecommendationAction = 'BUY' | 'SELL' | 'HOLD';
export type TargetLabel = 'T1' | 'T2' | 'T3';
export type TargetTrackingStatus = 'T1 HIT' | 'T2 HIT' | 'T3 HIT' | 'SL HIT' | 'ACTIVE';
export type ConfirmationStatus = 'ALIGNED' | 'MIXED' | 'NEUTRAL';
export const DEMO_SCORING_RULE =
  'Demo score: 50 base + up to 8 momentum points (2 per percentage point of sample move) + up to 10 RSI points (0.25 per point from 50) + 10 for trend alignment + 5 for 2–3 or 10 for 4 technical confirmations. Scores are capped at 100; directional ratings become STRONG at 75. HOLD remains neutral.';

export type DemoRecommendation = {
  name: string;
  symbol: string;
  action: RecommendationAction;
  entry: number;
  stopLoss: number;
  targets: {
    label: TargetLabel;
    price: number;
    riskReward: number | null;
  }[];
  confidenceScore: number;
  scoringRule: string;
  confidenceBreakdown: {
    base: number;
    momentum: number;
    rsi: number;
    trend: number;
    indicators: number;
  };
  technicalIndicators: {
    label: 'RSI (14)' | 'MACD' | 'EMA 20' | 'EMA 50';
    value: number;
    status: ConfirmationStatus;
  }[];
  reasons: string[];
  lastAnalyzedAt: string;
  demoOnly: true;
};

const roundPrice = (value: number) => Number(value.toFixed(2));

export function buildDemoRecommendation(stock: Stock): DemoRecommendation {
  const baseAction: BaseRecommendationAction =
    stock.signal === 'Bullish' ? 'BUY' : stock.signal === 'Bearish' ? 'SELL' : 'HOLD';
  const targetDirection =
    baseAction === 'BUY' ? 1 : baseAction === 'SELL' ? -1 : stock.target < stock.entry ? -1 : 1;
  const entry = stock.entry;
  const riskDistance = Math.abs(stock.entry - stock.stopLoss);
  const stopLoss = roundPrice(entry - targetDirection * riskDistance);
  const configuredTargetDistance = Math.abs(stock.target - entry);
  const targetDistance = configuredTargetDistance || riskDistance * 3;
  const targetFractions = [1 / 3, 2 / 3, 1] as const;

  const targets = targetFractions.map((fraction, index) => {
    const price = roundPrice(entry + targetDirection * targetDistance * fraction);
    return {
      label: `T${index + 1}` as TargetLabel,
      price,
      riskReward: calculateRiskReward({ entry, target: price, stopLoss }),
    };
  });

  const actionDirection = baseAction === 'BUY' ? 1 : baseAction === 'SELL' ? -1 : targetDirection;
  const confirmations = [
    baseAction === 'BUY' ? stock.rsi >= 50 : baseAction === 'SELL' ? stock.rsi <= 50 : stock.rsi >= 45 && stock.rsi <= 55,
    baseAction === 'BUY' ? stock.macd >= 0 : baseAction === 'SELL' ? stock.macd <= 0 : Math.abs(stock.macd) <= stock.price * 0.003,
    baseAction === 'BUY' ? stock.price >= stock.ema20 : baseAction === 'SELL' ? stock.price <= stock.ema20 : Math.abs(stock.price - stock.ema20) <= stock.price * 0.03,
    baseAction === 'BUY' ? stock.price >= stock.ema50 : baseAction === 'SELL' ? stock.price <= stock.ema50 : Math.abs(stock.price - stock.ema50) <= stock.price * 0.03,
  ];
  const trendAligned =
    baseAction === 'HOLD'
      ? stock.trend === 'Sideways'
      : (baseAction === 'BUY' && stock.trend === 'Uptrend') ||
        (baseAction === 'SELL' && stock.trend === 'Downtrend');
  const confidenceBreakdown = {
    base: 50,
    momentum: Math.min(Math.abs(stock.changePct) * 2, 8),
    rsi: Math.min(Math.abs(stock.rsi - 50) * 0.25, 10),
    trend: trendAligned ? 10 : 0,
    indicators: Math.min(10, Math.floor(confirmations.filter(Boolean).length / 2) * 5),
  };
  const confidenceScore = Math.min(
    100,
    Math.max(0, Math.round(Object.values(confidenceBreakdown).reduce((sum, points) => sum + points, 0))),
  );
  const action: RecommendationAction =
    baseAction === 'BUY'
      ? confidenceScore >= 75 ? 'STRONG BUY' : 'BUY'
      : baseAction === 'SELL'
        ? confidenceScore >= 75 ? 'STRONG SELL' : 'SELL'
        : 'HOLD';

  const emaAbove = stock.ema20 >= stock.ema50;
  const momentumAligned =
    baseAction === 'HOLD'
      ? stock.trend === 'Sideways'
      : confirmations[1] && stock.ema20 >= stock.ema50 === (actionDirection === 1);
  const rsiTone = stock.rsi > 50 ? 'above' : stock.rsi < 50 ? 'below' : 'at';
  const macdTone = stock.macd > 0 ? 'positive' : stock.macd < 0 ? 'negative' : 'flat';
  const confirmationStatus = (aligned: boolean): ConfirmationStatus =>
    baseAction === 'HOLD' ? 'NEUTRAL' : aligned ? 'ALIGNED' : 'MIXED';
  const technicalIndicators: DemoRecommendation['technicalIndicators'] = [
    { label: 'RSI (14)', value: stock.rsi, status: confirmationStatus(confirmations[0]) },
    { label: 'MACD', value: stock.macd, status: confirmationStatus(confirmations[1]) },
    { label: 'EMA 20', value: stock.ema20, status: confirmationStatus(confirmations[2]) },
    { label: 'EMA 50', value: stock.ema50, status: confirmationStatus(confirmations[3]) },
  ];
  const reasons = [
    `Demo trend is ${stock.trend.toLowerCase()} with a ${stock.changePct > 0 ? '+' : ''}${stock.changePct.toFixed(2)}% sample move.`,
    `EMA 20 is ${emaAbove ? 'above' : 'below'} EMA 50; this ${momentumAligned ? 'aligns with' : 'does not fully confirm'} the ${action} setup.`,
    `RSI is ${rsiTone} 50 at ${stock.rsi.toFixed(1)}; it ${confirmations[0] ? 'confirms' : 'does not confirm'} the ${action} direction.`,
    `MACD is ${macdTone} at ${stock.macd.toFixed(2)}; both EMA levels and MACD are static demo confirmations.`,
  ];

  return {
    name: stock.company,
    symbol: stock.symbol,
    action,
    entry,
    stopLoss,
    targets,
    confidenceScore,
    scoringRule: DEMO_SCORING_RULE,
    confidenceBreakdown,
    technicalIndicators,
    reasons,
    lastAnalyzedAt: '24 Mar 2025 · 09:45 IST · DEMO',
    demoOnly: true,
  };
}

export function getDemoTargetTrackingStatus(
  recommendation: DemoRecommendation,
  currentPrice: number,
): TargetTrackingStatus {
  if (!Number.isFinite(currentPrice)) return 'ACTIVE';
  const direction = recommendation.action.includes('BUY')
    ? 1
    : recommendation.action.includes('SELL')
      ? -1
      : Math.sign(recommendation.targets[2].price - recommendation.entry) || 1;

  if ((currentPrice - recommendation.stopLoss) * direction <= 0) return 'SL HIT';

  for (const target of [...recommendation.targets].reverse()) {
    if ((currentPrice - target.price) * direction >= 0) return `${target.label} HIT`;
  }
  return 'ACTIVE';
}
