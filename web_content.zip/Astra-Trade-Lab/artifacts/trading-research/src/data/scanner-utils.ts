import type { Exchange, Stock } from './demo-data.ts';

export type ScannerSortField = 'price' | 'changePct' | 'volume';
export type ScannerSortDirection = 'asc' | 'desc';

export type ScannerFilters = {
  query: string;
  exchange: Exchange | 'ALL';
  sector: string;
  signal: Stock['signal'] | 'ALL';
  minPrice?: number;
  maxPrice?: number;
  minChangePct?: number;
  maxChangePct?: number;
  minVolume?: number;
  maxVolume?: number;
  minMarketCap?: number;
  maxMarketCap?: number;
  sortBy: ScannerSortField;
  sortDirection: ScannerSortDirection;
};

const withinRange = (value: number, min?: number, max?: number) =>
  (min === undefined || value >= min) && (max === undefined || value <= max);

export function filterAndSortStocks(stocks: Stock[], filters: ScannerFilters): Stock[] {
  const query = filters.query.trim().toLowerCase();

  return stocks
    .filter((stock) => {
      const matchesQuery =
        !query ||
        stock.symbol.toLowerCase().includes(query) ||
        stock.company.toLowerCase().includes(query);
      const matchesExchange = filters.exchange === 'ALL' || stock.exchange === filters.exchange;
      const matchesSector = filters.sector === 'ALL' || stock.sector === filters.sector;
      const matchesSignal = filters.signal === 'ALL' || stock.signal === filters.signal;

      return (
        matchesQuery &&
        matchesExchange &&
        matchesSector &&
        matchesSignal &&
        withinRange(stock.price, filters.minPrice, filters.maxPrice) &&
        withinRange(stock.changePct, filters.minChangePct, filters.maxChangePct) &&
        withinRange(stock.volume, filters.minVolume, filters.maxVolume) &&
        withinRange(stock.marketCap, filters.minMarketCap, filters.maxMarketCap)
      );
    })
    .sort((a, b) => {
      const direction = filters.sortDirection === 'asc' ? 1 : -1;
      const valueDifference = (a[filters.sortBy] - b[filters.sortBy]) * direction;
      return valueDifference || a.symbol.localeCompare(b.symbol);
    });
}

export function calculateRiskReward(stock: Pick<Stock, 'entry' | 'target' | 'stopLoss'>): number | null {
  const { entry, target, stopLoss } = stock;
  if (![entry, target, stopLoss].every(Number.isFinite)) return null;

  const risk = Math.abs(entry - stopLoss);
  if (risk === 0) return null;

  return Math.abs(target - entry) / risk;
}

export function toggleWatchlistSymbol(watchlist: string[], symbol: string): string[] {
  return watchlist.includes(symbol)
    ? watchlist.filter((savedSymbol) => savedSymbol !== symbol)
    : [...watchlist, symbol];
}
