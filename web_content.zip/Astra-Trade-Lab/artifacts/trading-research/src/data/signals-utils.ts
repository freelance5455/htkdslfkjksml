import type { Stock } from './demo-data.ts';
import {
  buildDemoRecommendation,
  getDemoTargetTrackingStatus,
  type DemoRecommendation,
  type RecommendationAction,
  type TargetLabel,
  type TargetTrackingStatus,
} from './recommendation-utils.ts';
import { calculateRiskReward } from './scanner-utils.ts';

/**
 * Trade-signal engine for the three separate desks: swing, options and futures.
 *
 * Everything here is deterministic and derived from the same rule-based recommendation
 * the rest of the app uses. Nothing is fetched or fabricated: contract data (expiry,
 * lot size, implied volatility, margin) are clearly-labelled DEMO ASSUMPTIONS, and the
 * option premium is a Black-Scholes MODEL ESTIMATE, not a market quote.
 */

export const SIGNAL_STRATEGIES = ['swing', 'options', 'futures'] as const;
export type SignalStrategy = (typeof SIGNAL_STRATEGIES)[number];
export type SignalSide = 'LONG' | 'SHORT' | 'WATCH';

// ---- Demo assumptions (single source of truth, shown in the UI) -------------------------
export const DEMO_AS_OF_LABEL = '24 Mar 2025';
export const DEMO_EXPIRY_LABEL = '24 Apr 2025';
export const DEMO_EXPIRY_SHORT = 'APR';
export const DAYS_TO_EXPIRY = 31;
export const RISK_FREE_RATE = 0.07;
export const FUTURES_MARGIN_PCT = 0.15;
export const SWING_HOLDING_WINDOW = '3–15 trading days (guideline)';

/** Illustrative lot sizes. Real lot sizes are set by the exchange and change over time. */
export const LOT_SIZES: Record<string, number> = {
  RELIANCE: 250, HDFCBANK: 550, ICICIBANK: 700, INFY: 400, TCS: 175, SBIN: 750, LT: 150,
  TATAMOTORS: 575, BHARTIARTL: 475, ITC: 1600, AXISBANK: 625, SUNPHARMA: 350, MARUTI: 50,
  WIPRO: 1500, ADANIPORTS: 625,
};
const DEFAULT_LOT_SIZE = 100;

export type SignalLevel = { label: TargetLabel; price: number; riskReward: number | null };

export type SignalBase = {
  id: string;
  strategy: SignalStrategy;
  symbol: string;
  name: string;
  sector: string;
  side: SignalSide;
  action: RecommendationAction;
  confidence: number;
  /** Entry / stop / targets in the price of the instrument being traded (stock, future or option premium). */
  entry: number;
  stopLoss: number;
  targets: SignalLevel[];
  status: TargetTrackingStatus;
  reasons: string[];
  recommendation: DemoRecommendation;
  demoOnly: true;
};

export type SwingSignal = SignalBase & {
  strategy: 'swing';
  currentPrice: number;
  holdingWindow: string;
  riskPct: number;
  rewardPctT3: number;
};

export type FuturesSignal = SignalBase & {
  strategy: 'futures';
  contract: string;
  expiryLabel: string;
  daysToExpiry: number;
  lotSize: number;
  spot: number;
  futuresPrice: number;
  basis: number;
  basisPct: number;
  marginPct: number;
  contractValue: number;
  marginPerLot: number;
  riskPerLot: number;
};

export type OptionGreeks = { delta: number; gamma: number; thetaPerDay: number; vegaPerVolPoint: number };

export type OptionsSignal = SignalBase & {
  strategy: 'options';
  optionType: 'CE' | 'PE';
  contract: string;
  strike: number;
  strikeStep: number;
  expiryLabel: string;
  daysToExpiry: number;
  lotSize: number;
  underlying: number;
  assumedIvPct: number;
  riskFreeRate: number;
  greeks: OptionGreeks;
  breakeven: number;
  premiumPerLot: number;
  riskPerLot: number;
  underlyingLevels: { entry: number; stopLoss: number; targets: { label: TargetLabel; price: number }[] };
};

export type AnySignal = SwingSignal | FuturesSignal | OptionsSignal;

export type SignalBook = {
  swing: SwingSignal[];
  options: OptionsSignal[];
  futures: FuturesSignal[];
  /** Symbols with no directional edge — excluded from options and futures. */
  skipped: string[];
};

// ---- Maths helpers ---------------------------------------------------------------------
export const roundTick = (value: number) => Math.round(value * 20) / 20; // 0.05 tick
const round2 = (value: number) => Number(value.toFixed(2));

/** Standard normal PDF. */
export const normalPdf = (x: number) => Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);

/** Standard normal CDF (Abramowitz & Stegun 26.2.17, |error| < 7.5e-8). */
export function normalCdf(x: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const poly = t * (0.31938153 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  const upper = normalPdf(x) * poly;
  return x >= 0 ? 1 - upper : upper;
}

export type BlackScholesInput = {
  spot: number;
  strike: number;
  years: number;
  rate: number;
  vol: number;
  type: 'CE' | 'PE';
};

export function blackScholesPrice({ spot, strike, years, rate, vol, type }: BlackScholesInput): number {
  if (years <= 0 || vol <= 0) {
    return Math.max(type === 'CE' ? spot - strike : strike - spot, 0);
  }
  const sqrtT = Math.sqrt(years);
  const d1 = (Math.log(spot / strike) + (rate + 0.5 * vol * vol) * years) / (vol * sqrtT);
  const d2 = d1 - vol * sqrtT;
  const discount = Math.exp(-rate * years);
  return type === 'CE'
    ? spot * normalCdf(d1) - strike * discount * normalCdf(d2)
    : strike * discount * normalCdf(-d2) - spot * normalCdf(-d1);
}

export function blackScholesGreeks({ spot, strike, years, rate, vol, type }: BlackScholesInput): OptionGreeks {
  const sqrtT = Math.sqrt(years);
  const d1 = (Math.log(spot / strike) + (rate + 0.5 * vol * vol) * years) / (vol * sqrtT);
  const d2 = d1 - vol * sqrtT;
  const discount = Math.exp(-rate * years);
  const pdf = normalPdf(d1);
  const delta = type === 'CE' ? normalCdf(d1) : normalCdf(d1) - 1;
  const gamma = pdf / (spot * vol * sqrtT);
  const thetaYear = type === 'CE'
    ? -(spot * pdf * vol) / (2 * sqrtT) - rate * strike * discount * normalCdf(d2)
    : -(spot * pdf * vol) / (2 * sqrtT) + rate * strike * discount * normalCdf(-d2);
  return {
    delta,
    gamma,
    thetaPerDay: thetaYear / 365,
    vegaPerVolPoint: (spot * pdf * sqrtT) / 100,
  };
}

/** Demo strike grid: step grows with the underlying price. */
export function strikeStepFor(price: number): number {
  if (price < 250) return 5;
  if (price < 500) return 10;
  if (price < 1000) return 20;
  if (price < 2500) return 50;
  if (price < 20000) return 100;
  return 250;
}

export const nearestStrike = (price: number) => {
  const step = strikeStepFor(price);
  return Math.round(price / step) * step;
};

/** Assumed IV (percent): transparent demo rule, NOT a market-implied volatility. */
export const assumedIvPct = (stock: Pick<Stock, 'changePct' | 'rsi'>) =>
  Number(Math.min(45, 18 + Math.abs(stock.changePct) * 2 + Math.abs(stock.rsi - 50) * 0.3).toFixed(1));

// ---- Builders --------------------------------------------------------------------------
const sideOf = (recommendation: DemoRecommendation): SignalSide =>
  recommendation.action.includes('BUY') ? 'LONG' : recommendation.action.includes('SELL') ? 'SHORT' : 'WATCH';

function baseFor(stock: Stock, recommendation: DemoRecommendation, strategy: SignalStrategy) {
  return {
    id: `${strategy}-${stock.symbol}`,
    strategy,
    symbol: stock.symbol,
    name: stock.company,
    sector: stock.sector,
    side: sideOf(recommendation),
    action: recommendation.action,
    confidence: recommendation.confidenceScore,
    status: getDemoTargetTrackingStatus(recommendation, stock.price),
    recommendation,
    demoOnly: true as const,
  };
}

function levelsFrom(entry: number, stopLoss: number, prices: number[]): SignalLevel[] {
  return prices.map((price, index) => ({
    label: `T${index + 1}` as TargetLabel,
    price,
    riskReward: calculateRiskReward({ entry, target: price, stopLoss }),
  }));
}

export function buildSwingSignal(stock: Stock): SwingSignal {
  const recommendation = buildDemoRecommendation(stock);
  const t3 = recommendation.targets[2].price;
  return {
    ...baseFor(stock, recommendation, 'swing'),
    strategy: 'swing',
    entry: recommendation.entry,
    stopLoss: recommendation.stopLoss,
    targets: recommendation.targets.map((target) => ({ ...target })),
    reasons: recommendation.reasons,
    currentPrice: stock.price,
    holdingWindow: SWING_HOLDING_WINDOW,
    riskPct: round2((Math.abs(recommendation.entry - recommendation.stopLoss) / recommendation.entry) * 100),
    rewardPctT3: round2((Math.abs(t3 - recommendation.entry) / recommendation.entry) * 100),
  };
}

export function buildFuturesSignal(stock: Stock): FuturesSignal | null {
  const recommendation = buildDemoRecommendation(stock);
  if (recommendation.action === 'HOLD') return null;

  const carry = 1 + (RISK_FREE_RATE * DAYS_TO_EXPIRY) / 365;
  const futuresPrice = roundTick(stock.price * carry);
  const factor = futuresPrice / stock.price;
  const scale = (value: number) => roundTick(value * factor);
  const entry = scale(recommendation.entry);
  const stopLoss = scale(recommendation.stopLoss);
  const targets = levelsFrom(entry, stopLoss, recommendation.targets.map((target) => scale(target.price)));
  const lotSize = LOT_SIZES[stock.symbol] ?? DEFAULT_LOT_SIZE;
  const side = sideOf(recommendation);
  const contractValue = round2(entry * lotSize);
  const basis = round2(futuresPrice - stock.price);

  return {
    ...baseFor(stock, recommendation, 'futures'),
    strategy: 'futures',
    entry,
    stopLoss,
    targets,
    contract: `${stock.symbol} ${DEMO_EXPIRY_SHORT} FUT`,
    expiryLabel: DEMO_EXPIRY_LABEL,
    daysToExpiry: DAYS_TO_EXPIRY,
    lotSize,
    spot: stock.price,
    futuresPrice,
    basis,
    basisPct: round2((basis / stock.price) * 100),
    marginPct: FUTURES_MARGIN_PCT,
    contractValue,
    marginPerLot: round2(contractValue * FUTURES_MARGIN_PCT),
    riskPerLot: round2(Math.abs(entry - stopLoss) * lotSize),
    reasons: [
      ...recommendation.reasons,
      `${side === 'LONG' ? 'Long' : 'Short'} futures follow the ${recommendation.action} read on the underlying; levels are scaled by the futures/spot ratio (${factor.toFixed(4)}).`,
      `Futures price is a cost-of-carry estimate: spot × (1 + ${(RISK_FREE_RATE * 100).toFixed(0)}% × ${DAYS_TO_EXPIRY}/365), basis ₹${basis.toFixed(2)}. Dividends are ignored.`,
      `Margin is an assumed ${(FUTURES_MARGIN_PCT * 100).toFixed(0)}% of contract value; real SPAN + exposure margin differs by broker and day.`,
    ],
  };
}

export function buildOptionsSignal(stock: Stock): OptionsSignal | null {
  const recommendation = buildDemoRecommendation(stock);
  if (recommendation.action === 'HOLD') return null;

  const side = sideOf(recommendation);
  const type: 'CE' | 'PE' = side === 'LONG' ? 'CE' : 'PE';
  const strikeStep = strikeStepFor(stock.price);
  const strike = nearestStrike(stock.price);
  const iv = assumedIvPct(stock);
  const years = DAYS_TO_EXPIRY / 365;
  const priceAt = (spot: number) =>
    Math.max(0.05, roundTick(blackScholesPrice({ spot, strike, years, rate: RISK_FREE_RATE, vol: iv / 100, type })));

  const entry = priceAt(recommendation.entry);
  const stopLoss = priceAt(recommendation.stopLoss);
  const targets = levelsFrom(entry, stopLoss, recommendation.targets.map((target) => priceAt(target.price)));
  const lotSize = LOT_SIZES[stock.symbol] ?? DEFAULT_LOT_SIZE;
  const greeks = blackScholesGreeks({ spot: recommendation.entry, strike, years, rate: RISK_FREE_RATE, vol: iv / 100, type });
  const breakeven = type === 'CE' ? strike + entry : strike - entry;

  return {
    ...baseFor(stock, recommendation, 'options'),
    strategy: 'options',
    optionType: type,
    contract: `${stock.symbol} ${DEMO_EXPIRY_SHORT} ${strike} ${type}`,
    strike,
    strikeStep,
    expiryLabel: DEMO_EXPIRY_LABEL,
    daysToExpiry: DAYS_TO_EXPIRY,
    lotSize,
    underlying: stock.price,
    assumedIvPct: iv,
    riskFreeRate: RISK_FREE_RATE,
    greeks,
    breakeven: round2(breakeven),
    premiumPerLot: round2(entry * lotSize),
    riskPerLot: round2(Math.max(entry - stopLoss, 0) * lotSize),
    entry,
    stopLoss,
    targets,
    underlyingLevels: {
      entry: recommendation.entry,
      stopLoss: recommendation.stopLoss,
      targets: recommendation.targets.map((target) => ({ label: target.label, price: target.price })),
    },
    reasons: [
      ...recommendation.reasons,
      `${side === 'LONG' ? 'Buy CALL (CE)' : 'Buy PUT (PE)'} because the underlying read is ${recommendation.action}. Only long options are generated, so the maximum loss is the premium paid.`,
      `Strike ${strike} is the nearest at-the-money strike on the demo grid (step ₹${strikeStep}).`,
      `Premium levels are Black-Scholes model estimates with an assumed IV of ${iv}% and a ${(RISK_FREE_RATE * 100).toFixed(0)}% rate. They re-price the option at each underlying level at the same instant, so time decay between entry and target is not included.`,
    ],
  };
}

export function buildSignalBook(stocks: Stock[]): SignalBook {
  const byConfidence = <T extends SignalBase>(list: T[]) =>
    [...list].sort((a, b) => b.confidence - a.confidence || a.symbol.localeCompare(b.symbol));
  const swing = stocks.map(buildSwingSignal);
  const directionalSwing = byConfidence(swing.filter((signal) => signal.side !== 'WATCH'));
  const watchSwing = swing.filter((signal) => signal.side === 'WATCH').sort((a, b) => a.symbol.localeCompare(b.symbol));
  const options = byConfidence(stocks.map(buildOptionsSignal).filter((s): s is OptionsSignal => s !== null));
  const futures = byConfidence(stocks.map(buildFuturesSignal).filter((s): s is FuturesSignal => s !== null));

  return {
    swing: [...directionalSwing, ...watchSwing],
    options,
    futures,
    skipped: watchSwing.map((signal) => signal.symbol),
  };
}

// ---- Position calculators ---------------------------------------------------------------
export type PositionPlan = {
  lots: number;
  quantity: number;
  /** Capital to deploy: margin for futures, premium paid for options. */
  capital: number;
  /** Loss if the stop-loss level is honoured. */
  plannedLoss: number;
  /** Profit at each target. */
  profits: { label: TargetLabel; amount: number }[];
  /** Futures: 100% of capital is not at risk; options: worst case = premium. */
  worstCaseLoss: number | null;
};

const sanitizeLots = (lots: number) => (Number.isFinite(lots) ? Math.max(0, Math.floor(lots)) : 0);

export function planFuturesPosition(signal: FuturesSignal, lots: number): PositionPlan {
  const count = sanitizeLots(lots);
  const quantity = count * signal.lotSize;
  const direction = signal.side === 'SHORT' ? -1 : 1;
  return {
    lots: count,
    quantity,
    capital: round2(signal.marginPerLot * count),
    plannedLoss: round2(Math.abs(signal.entry - signal.stopLoss) * quantity),
    profits: signal.targets.map((target) => ({
      label: target.label,
      amount: round2((target.price - signal.entry) * direction * quantity),
    })),
    worstCaseLoss: null,
  };
}

export function planOptionsPosition(signal: OptionsSignal, lots: number): PositionPlan {
  const count = sanitizeLots(lots);
  const quantity = count * signal.lotSize;
  return {
    lots: count,
    quantity,
    capital: round2(signal.entry * quantity),
    plannedLoss: round2(Math.max(signal.entry - signal.stopLoss, 0) * quantity),
    profits: signal.targets.map((target) => ({
      label: target.label,
      amount: round2((target.price - signal.entry) * quantity),
    })),
    worstCaseLoss: round2(signal.entry * quantity),
  };
}

// ---- List helpers -----------------------------------------------------------------------
export type SignalFilter = 'ALL' | 'LONG' | 'SHORT' | 'WATCH';
export type SignalSort = 'confidence' | 'riskReward';

export const bestRiskReward = (signal: SignalBase) => signal.targets.at(-1)?.riskReward ?? 0;

export function filterAndSortSignals<T extends SignalBase>(signals: T[], filter: SignalFilter, sort: SignalSort): T[] {
  return signals
    .filter((signal) => filter === 'ALL' || signal.side === filter)
    .sort((a, b) => {
      const primary = sort === 'confidence' ? b.confidence - a.confidence : bestRiskReward(b) - bestRiskReward(a);
      return primary || a.symbol.localeCompare(b.symbol);
    });
}

export function summarizeSignals(signals: SignalBase[]) {
  const actionable = signals.filter((signal) => signal.side !== 'WATCH');
  const confidences = actionable.map((signal) => signal.confidence);
  return {
    total: signals.length,
    long: signals.filter((signal) => signal.side === 'LONG').length,
    short: signals.filter((signal) => signal.side === 'SHORT').length,
    watch: signals.filter((signal) => signal.side === 'WATCH').length,
    averageConfidence: confidences.length ? Math.round(confidences.reduce((a, b) => a + b, 0) / confidences.length) : 0,
    bestRiskReward: actionable.length ? Math.max(...actionable.map(bestRiskReward)) : 0,
  };
}
