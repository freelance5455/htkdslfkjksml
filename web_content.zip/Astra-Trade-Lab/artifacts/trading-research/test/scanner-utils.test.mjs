import assert from 'node:assert/strict';
import test from 'node:test';

import { marketDemo } from '../src/data/demo-data.ts';
import { CHART_TIMEFRAMES, generateDemoChartHistory } from '../src/data/chart-utils.ts';
import { buildDemoRecommendation, getDemoTargetTrackingStatus } from '../src/data/recommendation-utils.ts';
import {
  calculateRiskReward,
  filterAndSortStocks,
  toggleWatchlistSymbol,
} from '../src/data/scanner-utils.ts';

const stocks = marketDemo.stocks;

const withFilters = (overrides = {}) => ({
  query: '',
  exchange: 'ALL',
  sector: 'ALL',
  signal: 'ALL',
  sortBy: 'changePct',
  sortDirection: 'desc',
  ...overrides,
});

test('search matches symbols and company names without case sensitivity', () => {
  assert.deepEqual(filterAndSortStocks(stocks, withFilters({ query: 'infy' })).map((stock) => stock.symbol), ['INFY']);
  assert.deepEqual(filterAndSortStocks(stocks, withFilters({ query: 'infosys' })).map((stock) => stock.symbol), ['INFY']);
});

test('NSE and BSE exchange filters return only their demo-tagged stocks', () => {
  for (const exchange of ['NSE', 'BSE']) {
    const result = filterAndSortStocks(stocks, withFilters({ exchange }));
    assert.ok(result.length > 0);
    assert.ok(result.every((stock) => stock.exchange === exchange));
  }
});

test('signal and sector filters narrow the scanner results', () => {
  for (const signal of ['Bullish', 'Bearish', 'Neutral']) {
    const result = filterAndSortStocks(stocks, withFilters({ signal }));
    assert.ok(result.length > 0);
    assert.ok(result.every((stock) => stock.signal === signal));
  }

  const banking = filterAndSortStocks(stocks, withFilters({ sector: 'Banking' }));
  assert.ok(banking.length > 0);
  assert.ok(banking.every((stock) => stock.sector === 'Banking'));
});

test('price, percentage change, volume, and market cap ranges are applied', () => {
  const rangeCases = [
    ['price', { minPrice: 2000, maxPrice: 3000 }, (stock) => stock.price, 2000, 3000],
    ['change', { minChangePct: 1, maxChangePct: 2 }, (stock) => stock.changePct, 1, 2],
    ['volume', { minVolume: 3000000, maxVolume: 6000000 }, (stock) => stock.volume, 3000000, 6000000],
    ['market cap', { minMarketCap: 500000, maxMarketCap: 1000000 }, (stock) => stock.marketCap, 500000, 1000000],
  ];

  for (const [name, bounds, getValue, min, max] of rangeCases) {
    const result = filterAndSortStocks(stocks, withFilters(bounds));
    assert.ok(result.length > 0, `${name} range should retain matching demo stocks`);
    assert.ok(result.every((stock) => getValue(stock) >= min && getValue(stock) <= max), `${name} range should exclude values outside its bounds`);
  }
});

test('price, percentage change, and volume each sort in both directions', () => {
  for (const sortBy of ['price', 'changePct', 'volume']) {
    for (const sortDirection of ['asc', 'desc']) {
      const result = filterAndSortStocks(stocks, withFilters({ sortBy, sortDirection }));
      const actual = result.map((stock) => stock[sortBy]);
      const expected = [...actual].sort((a, b) => sortDirection === 'asc' ? a - b : b - a);
      assert.deepEqual(actual, expected, `${sortBy} should sort ${sortDirection}`);
    }
  }
});

test('risk/reward calculation handles bullish, bearish, and invalid risk levels', () => {
  const bullish = stocks.find((stock) => stock.symbol === 'RELIANCE');
  const bearish = stocks.find((stock) => stock.symbol === 'INFY');
  assert.equal(calculateRiskReward(bullish), 2.05);
  assert.equal(calculateRiskReward(bearish), 58 / 26);
  assert.equal(calculateRiskReward({ entry: 100, target: 120, stopLoss: 100 }), null);
});

test('watchlist toggle adds and removes symbols without mutating the original list', () => {
  const initial = ['RELIANCE'];
  const added = toggleWatchlistSymbol(initial, 'INFY');
  assert.deepEqual(added, ['RELIANCE', 'INFY']);
  assert.deepEqual(initial, ['RELIANCE']);
  assert.deepEqual(toggleWatchlistSymbol(added, 'INFY'), ['RELIANCE']);
});

test('BUY recommendation keeps stop below entry and builds three ascending targets', () => {
  const stock = stocks.find((item) => item.symbol === 'RELIANCE');
  const recommendation = buildDemoRecommendation(stock);

  assert.equal(recommendation.action, 'STRONG BUY');
  assert.equal(recommendation.demoOnly, true);
  assert.equal(recommendation.entry, stock.entry);
  assert.ok(recommendation.stopLoss < recommendation.entry);
  assert.equal(recommendation.targets.length, 3);
  assert.ok(recommendation.targets[0].price > recommendation.entry);
  assert.ok(recommendation.targets[1].price > recommendation.targets[0].price);
  assert.ok(recommendation.targets[2].price > recommendation.targets[1].price);
  assert.ok(recommendation.targets[0].riskReward < recommendation.targets[1].riskReward);
  assert.ok(recommendation.targets[1].riskReward < recommendation.targets[2].riskReward);
  assert.equal(recommendation.targets[2].price, stock.target);
  assert.equal(recommendation.targets[2].riskReward, 2.05);
  assert.ok(recommendation.confidenceScore >= 0 && recommendation.confidenceScore <= 100);
  assert.ok(recommendation.confidenceBreakdown.base > 0);
  assert.equal(recommendation.technicalIndicators.length, 4);
  assert.match(recommendation.lastAnalyzedAt, /DEMO/);
});

test('SELL recommendation keeps stop above entry and all three targets below entry', () => {
  const stock = stocks.find((item) => item.symbol === 'INFY');
  const recommendation = buildDemoRecommendation(stock);

  assert.equal(recommendation.action, 'STRONG SELL');
  assert.ok(recommendation.stopLoss > recommendation.entry);
  assert.ok(recommendation.targets.every((target) => target.price < recommendation.entry));
  assert.ok(recommendation.targets[0].price > recommendation.targets[1].price);
  assert.ok(recommendation.targets[1].price > recommendation.targets[2].price);
  assert.ok(recommendation.targets[0].riskReward < recommendation.targets[1].riskReward);
  assert.ok(recommendation.targets[1].riskReward < recommendation.targets[2].riskReward);
});

test('HOLD recommendation stays neutral and its levels update with the selected stock', () => {
  const neutralStock = stocks.find((item) => item.symbol === 'HDFCBANK');
  const recommendation = buildDemoRecommendation(neutralStock);
  const otherRecommendation = buildDemoRecommendation(stocks.find((item) => item.symbol === 'ITC'));

  assert.equal(recommendation.action, 'HOLD');
  assert.ok(recommendation.targets.every((target) => target.price > recommendation.entry));
  assert.ok(recommendation.stopLoss < recommendation.entry);
  assert.notEqual(recommendation.entry, otherRecommendation.entry);
  assert.notEqual(recommendation.confidenceScore, otherRecommendation.confidenceScore);
  assert.equal(recommendation.reasons.length, 4);
  assert.ok(recommendation.reasons.every((reason) => reason.length > 0));
});

test('rule-based scoring covers regular and strong directional recommendations', () => {
  assert.equal(buildDemoRecommendation(stocks.find((stock) => stock.symbol === 'TCS')).action, 'BUY');
  assert.equal(buildDemoRecommendation(stocks.find((stock) => stock.symbol === 'AXISBANK')).action, 'SELL');
  assert.equal(buildDemoRecommendation(stocks.find((stock) => stock.symbol === 'SBIN')).action, 'STRONG BUY');
  assert.equal(buildDemoRecommendation(stocks.find((stock) => stock.symbol === 'TATAMOTORS')).action, 'STRONG SELL');
});

test('demo target tracker reports active, each target, and stop status for both directions', () => {
  const buy = buildDemoRecommendation(stocks.find((stock) => stock.symbol === 'RELIANCE'));
  const sell = buildDemoRecommendation(stocks.find((stock) => stock.symbol === 'AXISBANK'));

  assert.equal(getDemoTargetTrackingStatus(buy, buy.entry), 'ACTIVE');
  assert.equal(getDemoTargetTrackingStatus(buy, buy.targets[0].price), 'T1 HIT');
  assert.equal(getDemoTargetTrackingStatus(buy, buy.targets[1].price), 'T2 HIT');
  assert.equal(getDemoTargetTrackingStatus(buy, buy.targets[2].price), 'T3 HIT');
  assert.equal(getDemoTargetTrackingStatus(buy, buy.stopLoss), 'SL HIT');
  assert.equal(getDemoTargetTrackingStatus(sell, sell.entry), 'ACTIVE');
  assert.equal(getDemoTargetTrackingStatus(sell, sell.targets[0].price), 'T1 HIT');
  assert.equal(getDemoTargetTrackingStatus(sell, sell.targets[1].price), 'T2 HIT');
  assert.equal(getDemoTargetTrackingStatus(sell, sell.targets[2].price), 'T3 HIT');
  assert.equal(getDemoTargetTrackingStatus(sell, sell.stopLoss), 'SL HIT');
});

test('all seven demo chart timeframes generate appropriate deterministic OHLCV history', () => {
  const stock = stocks.find((item) => item.symbol === 'RELIANCE');
  const histories = CHART_TIMEFRAMES.map((timeframe) => generateDemoChartHistory(stock, timeframe));
  const counts = histories.map((history) => history.points.length);

  assert.deepEqual(CHART_TIMEFRAMES, ['1D', '1W', '1M', '3M', '6M', '1Y', '5Y']);
  assert.equal(new Set(counts).size, CHART_TIMEFRAMES.length);
  for (const history of histories) {
    assert.equal(history.points.at(-1).close, stock.price);
    assert.equal(history.axisLabels.length, 5);
    assert.ok(Number.isFinite(history.percentageChange));
    assert.ok(history.points.every((candle) =>
      candle.low <= Math.min(candle.open, candle.close) &&
      candle.high >= Math.max(candle.open, candle.close) &&
      candle.volume > 0,
    ));
  }
  assert.notDeepEqual(histories[0].axisLabels, histories.at(-1).axisLabels);
});
