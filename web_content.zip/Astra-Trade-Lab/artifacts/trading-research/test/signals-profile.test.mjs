import assert from 'node:assert/strict';
import test from 'node:test';

import { marketDemo } from '../src/data/demo-data.ts';
import {
  blackScholesGreeks,
  blackScholesPrice,
  buildFuturesSignal,
  buildOptionsSignal,
  buildSignalBook,
  filterAndSortSignals,
  nearestStrike,
  normalCdf,
  planFuturesPosition,
  planOptionsPosition,
  roundTick,
  strikeStepFor,
  summarizeSignals,
  DAYS_TO_EXPIRY,
  FUTURES_MARGIN_PCT,
  RISK_FREE_RATE,
} from '../src/data/signals-utils.ts';
import {
  PLANS,
  clearProfile,
  getGreeting,
  getInitials,
  getPlan,
  loadProfile,
  planPrice,
  saveProfile,
  validateName,
  yearlySavings,
} from '../src/data/profile.ts';

const stocks = marketDemo.stocks;
const stock = (symbol) => stocks.find((item) => item.symbol === symbol);
const close = (actual, expected, tolerance, message) =>
  assert.ok(Math.abs(actual - expected) <= tolerance, `${message ?? ''} expected ${expected} ± ${tolerance}, got ${actual}`);

const memoryStorage = (initial = {}) => {
  const data = { ...initial };
  return {
    getItem: (key) => (key in data ? data[key] : null),
    setItem: (key, value) => { data[key] = String(value); },
    removeItem: (key) => { delete data[key]; },
    data,
  };
};

// ---------------------------------------------------------------- pricing maths
test('normal CDF matches reference values and is symmetric', () => {
  close(normalCdf(0), 0.5, 1e-7);
  close(normalCdf(1.96), 0.9750021, 1e-6);
  close(normalCdf(-1.96), 0.0249979, 1e-6);
  close(normalCdf(1) + normalCdf(-1), 1, 1e-9);
});

test('Black-Scholes reproduces the textbook call/put values and put-call parity', () => {
  const base = { spot: 100, strike: 100, years: 1, rate: 0.05, vol: 0.2 };
  close(blackScholesPrice({ ...base, type: 'CE' }), 10.4506, 0.001, 'call');
  close(blackScholesPrice({ ...base, type: 'PE' }), 5.5735, 0.001, 'put');
  const parity = blackScholesPrice({ ...base, type: 'CE' }) - blackScholesPrice({ ...base, type: 'PE' });
  close(parity, base.spot - base.strike * Math.exp(-base.rate * base.years), 1e-6, 'parity');
  assert.equal(blackScholesPrice({ ...base, years: 0, spot: 110, type: 'CE' }), 10);
  assert.equal(blackScholesPrice({ ...base, years: 0, spot: 110, type: 'PE' }), 0);
});

test('Greeks agree with finite differences and have the expected signs', () => {
  const input = { spot: 2846, strike: 2850, years: 31 / 365, rate: 0.07, vol: 0.25 };
  const call = blackScholesGreeks({ ...input, type: 'CE' });
  const put = blackScholesGreeks({ ...input, type: 'PE' });
  close(call.delta - put.delta, 1, 1e-9, 'delta parity');
  assert.ok(call.delta > 0 && call.delta < 1 && put.delta < 0 && put.delta > -1);
  assert.ok(call.gamma > 0 && close(call.gamma, put.gamma, 1e-12) === undefined);
  assert.ok(call.thetaPerDay < 0 && put.thetaPerDay < 0);
  assert.ok(call.vegaPerVolPoint > 0);

  const h = 0.01;
  const up = blackScholesPrice({ ...input, spot: input.spot + h, type: 'CE' });
  const down = blackScholesPrice({ ...input, spot: input.spot - h, type: 'CE' });
  close(call.delta, (up - down) / (2 * h), 1e-4, 'delta finite difference');
  const volUp = blackScholesPrice({ ...input, vol: 0.26, type: 'CE' });
  const volDown = blackScholesPrice({ ...input, vol: 0.24, type: 'CE' });
  close(call.vegaPerVolPoint, (volUp - volDown) / 2, 1e-3, 'vega finite difference');
  const later = blackScholesPrice({ ...input, years: input.years - 1 / 365, type: 'CE' });
  close(call.thetaPerDay, later - blackScholesPrice({ ...input, type: 'CE' }), 0.2, 'theta finite difference');
});

test('strike grid and tick rounding are deterministic', () => {
  assert.equal(strikeStepFor(200), 5);
  assert.equal(strikeStepFor(428.9), 10);
  assert.equal(strikeStepFor(812.35), 20);
  assert.equal(strikeStepFor(1684.2), 50);
  assert.equal(strikeStepFor(2846.35), 100);
  assert.equal(nearestStrike(2846.35), 2800);
  assert.equal(nearestStrike(812.35), 820);
  assert.equal(roundTick(100.07), 100.05);
  assert.equal(roundTick(100.03), 100.05);
  assert.equal(roundTick(100.02), 100);
});

// ---------------------------------------------------------------- signal book
test('signal book separates swing, options and futures and skips neutral names', () => {
  const book = buildSignalBook(stocks);
  const neutral = stocks.filter((item) => item.signal === 'Neutral').map((item) => item.symbol).sort();

  assert.equal(book.swing.length, stocks.length);
  assert.equal(book.options.length, stocks.length - neutral.length);
  assert.equal(book.futures.length, stocks.length - neutral.length);
  assert.deepEqual([...book.skipped].sort(), neutral);
  assert.ok(book.options.every((signal) => signal.strategy === 'options' && signal.side !== 'WATCH'));
  assert.ok(book.futures.every((signal) => signal.strategy === 'futures' && signal.side !== 'WATCH'));
  assert.ok(book.swing.every((signal) => signal.strategy === 'swing' && signal.demoOnly === true));
  assert.equal(new Set([...book.swing, ...book.options, ...book.futures].map((signal) => signal.id)).size, book.swing.length + book.options.length + book.futures.length);

  for (const list of [book.options, book.futures]) {
    const confidences = list.map((signal) => signal.confidence);
    assert.deepEqual(confidences, [...confidences].sort((a, b) => b - a), 'sorted by confidence');
  }
  const firstWatch = book.swing.findIndex((signal) => signal.side === 'WATCH');
  assert.ok(book.swing.slice(firstWatch).every((signal) => signal.side === 'WATCH'), 'watch names last');
});

test('swing signals reuse the rule-based recommendation levels', () => {
  const book = buildSignalBook(stocks);
  const reliance = book.swing.find((signal) => signal.symbol === 'RELIANCE');
  assert.equal(reliance.side, 'LONG');
  assert.equal(reliance.action, 'STRONG BUY');
  assert.equal(reliance.entry, reliance.recommendation.entry);
  assert.equal(reliance.targets[2].price, stock('RELIANCE').target);
  assert.ok(reliance.riskPct > 0 && reliance.rewardPctT3 > reliance.riskPct);
  assert.equal(book.swing.find((signal) => signal.symbol === 'INFY').side, 'SHORT');
  assert.equal(book.swing.find((signal) => signal.symbol === 'HDFCBANK').side, 'WATCH');
});

// ---------------------------------------------------------------- futures
test('long futures: stop below entry, ascending targets, contango basis, margin maths', () => {
  const signal = buildFuturesSignal(stock('RELIANCE'));
  assert.equal(signal.side, 'LONG');
  assert.ok(signal.stopLoss < signal.entry);
  assert.ok(signal.targets[0].price > signal.entry);
  assert.ok(signal.targets[0].price < signal.targets[1].price && signal.targets[1].price < signal.targets[2].price);
  assert.ok(signal.targets[0].riskReward < signal.targets[1].riskReward && signal.targets[1].riskReward < signal.targets[2].riskReward);
  close(signal.futuresPrice, roundTick(stock('RELIANCE').price * (1 + (RISK_FREE_RATE * DAYS_TO_EXPIRY) / 365)), 0.0001);
  assert.ok(signal.basis > 0);
  assert.equal(signal.contractValue, Number((signal.entry * signal.lotSize).toFixed(2)));
  close(signal.marginPerLot, signal.contractValue * FUTURES_MARGIN_PCT, 0.01);
  close(signal.riskPerLot, Math.abs(signal.entry - signal.stopLoss) * signal.lotSize, 0.01);
  assert.equal(signal.contract, 'RELIANCE APR FUT');
});

test('short futures: stop above entry, descending targets', () => {
  const signal = buildFuturesSignal(stock('INFY'));
  assert.equal(signal.side, 'SHORT');
  assert.ok(signal.stopLoss > signal.entry);
  assert.ok(signal.targets.every((target) => target.price < signal.entry));
  assert.ok(signal.targets[0].price > signal.targets[1].price && signal.targets[1].price > signal.targets[2].price);
  assert.ok(signal.targets.every((target) => target.riskReward > 0));
});

test('neutral stocks produce no futures or options signal', () => {
  assert.equal(buildFuturesSignal(stock('HDFCBANK')), null);
  assert.equal(buildOptionsSignal(stock('HDFCBANK')), null);
});

test('futures position planner sizes margin, planned loss and profits for both sides', () => {
  const long = buildFuturesSignal(stock('RELIANCE'));
  const plan = planFuturesPosition(long, 2);
  assert.equal(plan.quantity, 2 * long.lotSize);
  close(plan.capital, long.marginPerLot * 2, 0.01);
  close(plan.plannedLoss, Math.abs(long.entry - long.stopLoss) * plan.quantity, 0.01);
  assert.ok(plan.profits.every((profit) => profit.amount > 0));
  assert.ok(plan.profits[0].amount < plan.profits[2].amount);

  const short = buildFuturesSignal(stock('INFY'));
  assert.ok(planFuturesPosition(short, 1).profits.every((profit) => profit.amount > 0), 'short profits are positive when price falls');

  for (const bad of [0, -3, NaN, Infinity]) {
    const empty = planFuturesPosition(long, bad);
    assert.equal(empty.lots, 0);
    assert.equal(empty.capital, 0);
    assert.equal(empty.plannedLoss, 0);
  }
  assert.equal(planFuturesPosition(long, 2.9).lots, 2);
});

// ---------------------------------------------------------------- options
test('bullish names get a CALL and bearish names get a PUT with consistent premium ladders', () => {
  for (const symbol of ['RELIANCE', 'SBIN', 'TCS', 'INFY', 'TATAMOTORS', 'AXISBANK']) {
    const signal = buildOptionsSignal(stock(symbol));
    const bullish = stock(symbol).signal === 'Bullish';
    assert.equal(signal.optionType, bullish ? 'CE' : 'PE', symbol);
    assert.equal(signal.side, bullish ? 'LONG' : 'SHORT', symbol);
    assert.equal(signal.strike, nearestStrike(stock(symbol).price), symbol);
    assert.ok(signal.entry > 0 && signal.stopLoss > 0, `${symbol} premiums positive`);
    // The option is always BOUGHT, so premium must rise towards the targets and fall to the stop.
    assert.ok(signal.stopLoss < signal.entry, `${symbol} stop premium below entry`);
    assert.ok(signal.entry < signal.targets[0].price && signal.targets[0].price < signal.targets[1].price && signal.targets[1].price < signal.targets[2].price, `${symbol} ascending premium targets`);
    assert.ok(signal.targets.every((target) => target.riskReward > 0), `${symbol} positive R:R`);
    assert.ok(bullish ? signal.greeks.delta > 0 : signal.greeks.delta < 0, `${symbol} delta sign`);
    assert.ok(signal.greeks.thetaPerDay < 0, `${symbol} theta negative for long option`);
    close(signal.breakeven, bullish ? signal.strike + signal.entry : signal.strike - signal.entry, 0.01, `${symbol} breakeven`);
    assert.equal(signal.premiumPerLot, Number((signal.entry * signal.lotSize).toFixed(2)));
    assert.ok(signal.assumedIvPct >= 18 && signal.assumedIvPct <= 45);
  }
});

test('option premium equals the Black-Scholes model value at the underlying entry level', () => {
  const signal = buildOptionsSignal(stock('RELIANCE'));
  const model = blackScholesPrice({
    spot: signal.underlyingLevels.entry,
    strike: signal.strike,
    years: signal.daysToExpiry / 365,
    rate: signal.riskFreeRate,
    vol: signal.assumedIvPct / 100,
    type: signal.optionType,
  });
  close(signal.entry, model, 0.03);
  assert.equal(signal.contract, `RELIANCE APR ${signal.strike} CE`);
});

test('options position planner: capital is the premium paid and worst case equals capital', () => {
  const signal = buildOptionsSignal(stock('SBIN'));
  const plan = planOptionsPosition(signal, 3);
  assert.equal(plan.quantity, 3 * signal.lotSize);
  close(plan.capital, signal.entry * plan.quantity, 0.01);
  assert.equal(plan.worstCaseLoss, plan.capital);
  assert.ok(plan.plannedLoss > 0 && plan.plannedLoss < plan.capital);
  assert.ok(plan.profits.every((profit) => profit.amount > 0));
  assert.equal(planOptionsPosition(signal, -1).capital, 0);
});

// ---------------------------------------------------------------- list helpers
test('filter and sort helpers work on signal lists', () => {
  const book = buildSignalBook(stocks);
  const longs = filterAndSortSignals(book.swing, 'LONG', 'confidence');
  assert.ok(longs.length > 0 && longs.every((signal) => signal.side === 'LONG'));
  assert.deepEqual(longs.map((s) => s.confidence), longs.map((s) => s.confidence).sort((a, b) => b - a));
  const byRr = filterAndSortSignals(book.futures, 'ALL', 'riskReward');
  const rr = byRr.map((signal) => signal.targets[2].riskReward);
  assert.deepEqual(rr, [...rr].sort((a, b) => b - a));
  assert.equal(filterAndSortSignals(book.swing, 'WATCH', 'confidence').length, book.skipped.length);
});

test('summary counts add up and ignore watch names in averages', () => {
  const book = buildSignalBook(stocks);
  const summary = summarizeSignals(book.swing);
  assert.equal(summary.long + summary.short + summary.watch, summary.total);
  assert.equal(summary.long, stocks.filter((s) => s.signal === 'Bullish').length);
  assert.equal(summary.short, stocks.filter((s) => s.signal === 'Bearish').length);
  assert.ok(summary.averageConfidence > 50 && summary.averageConfidence <= 100);
  assert.deepEqual(summarizeSignals([]), { total: 0, long: 0, short: 0, watch: 0, averageConfidence: 0, bestRiskReward: 0 });
});

// ---------------------------------------------------------------- profile / greeting / plans
test('greeting follows the time of day', () => {
  assert.equal(getGreeting(5), 'Good morning');
  assert.equal(getGreeting(11), 'Good morning');
  assert.equal(getGreeting(12), 'Good afternoon');
  assert.equal(getGreeting(16), 'Good afternoon');
  assert.equal(getGreeting(17), 'Good evening');
  assert.equal(getGreeting(23), 'Good evening');
  assert.equal(getGreeting(0), 'Good evening');
  assert.equal(getGreeting(4), 'Good evening');
  assert.equal(getGreeting(29), 'Good morning', 'hours wrap around');
});

test('name validation and initials', () => {
  assert.notEqual(validateName(''), null);
  assert.notEqual(validateName(' a '), null);
  assert.notEqual(validateName('12345'), null);
  assert.notEqual(validateName('x'.repeat(31)), null);
  assert.equal(validateName('Aakash'), null);
  assert.equal(validateName('  आकाश  '), null);
  assert.equal(getInitials('Aakash Sharma'), 'AS');
  assert.equal(getInitials('aakash'), 'AA');
  assert.equal(getInitials('  rahul   kumar   verma '), 'RV');
  assert.equal(getInitials(''), '?');
});

test('profile persists, survives bad data and can be cleared', () => {
  const storage = memoryStorage();
  assert.equal(loadProfile(storage), null);
  saveProfile({ name: 'Aakash', plan: 'pro' }, storage);
  assert.deepEqual(loadProfile(storage), { name: 'Aakash', plan: 'pro' });
  clearProfile(storage);
  assert.equal(loadProfile(storage), null);

  assert.equal(loadProfile(memoryStorage({ 'astra-profile': '{not json' })), null);
  assert.equal(loadProfile(memoryStorage({ 'astra-profile': JSON.stringify({ name: '', plan: 'pro' }) })), null);
  assert.deepEqual(loadProfile(memoryStorage({ 'astra-profile': JSON.stringify({ name: ' Ravi  K ', plan: 'gold' }) })), { name: 'Ravi K', plan: 'starter' });
  assert.equal(loadProfile(null), null);
  assert.doesNotThrow(() => saveProfile({ name: 'Aakash', plan: 'pro' }, null));
  const broken = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('blocked'); }, removeItem() { throw new Error('blocked'); } };
  assert.equal(loadProfile(broken), null);
  assert.doesNotThrow(() => saveProfile({ name: 'Aakash', plan: 'pro' }, broken));
  assert.doesNotThrow(() => clearProfile(broken));
});

test('plans: three tiers, valid prices, yearly cheaper than 12 months, unknown id falls back', () => {
  assert.deepEqual(PLANS.map((plan) => plan.id), ['starter', 'pro', 'elite']);
  assert.equal(PLANS.filter((plan) => plan.highlight).length, 1);
  assert.equal(planPrice(getPlan('starter'), 'monthly'), 0);
  assert.equal(planPrice(getPlan('pro'), 'monthly'), 499);
  assert.equal(planPrice(getPlan('pro'), 'yearly'), 4990);
  for (const plan of PLANS.filter((p) => p.monthly > 0)) {
    assert.ok(plan.yearly < plan.monthly * 12);
    assert.equal(yearlySavings(plan), plan.monthly * 12 - plan.yearly);
  }
  assert.equal(yearlySavings(getPlan('starter')), 0);
  assert.equal(getPlan('nope').id, 'starter');
  assert.ok(PLANS.every((plan) => plan.features.length > 0));
});
