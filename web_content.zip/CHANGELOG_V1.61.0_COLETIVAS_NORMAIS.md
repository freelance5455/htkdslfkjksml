# Carreira de Craque v1.61.0 — Coletivas normais mais coerentes

- Reformuladas apenas as perguntas das coletivas de partidas comuns.
- Perguntas agora consideram resultado, placar, minutos jogados, gols, assistências, nota e cartões registrados.
- Quando o atleta não entra em campo, a imprensa pergunta sobre a visão do jogo, disputa por espaço e preparação; não cobra desempenho individual que não aconteceu.
- Quando há gol, assistência, cartão, atuação destacada ou atuação abaixo do esperado, as perguntas abordam o fato correspondente.
- Mantido o conjunto de perguntas especiais de clássicos sem alterações.
- Mantidas as respostas, os efeitos das respostas e o fluxo de conclusão da coletiva.
