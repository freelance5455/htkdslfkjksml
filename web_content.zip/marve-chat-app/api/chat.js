// Vercel serverless function. Keeps your AI key on the server.
// Env vars: AI_API_KEY, AI_BASE_URL (OpenAI-compatible, e.g. https://api.groq.com/openai/v1), AI_MODEL
const hits = new Map();
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const { AI_API_KEY, AI_BASE_URL, AI_MODEL } = process.env;
  if (!AI_API_KEY || !AI_BASE_URL || !AI_MODEL)
    return res.status(500).json({ error: "Server not configured: set AI_API_KEY, AI_BASE_URL, AI_MODEL" });
  const ip = String(req.headers["x-forwarded-for"] || "x").split(",")[0];
  const now = Date.now(), recent = (hits.get(ip) || []).filter(t => now - t < 60000);
  if (recent.length >= 15) return res.status(429).json({ error: "Too many requests, wait a minute" });
  hits.set(ip, [...recent, now]);
  const { system = "", messages = [] } = req.body || {};
  if (!Array.isArray(messages) || !messages.length || JSON.stringify(messages).length > 60000)
    return res.status(400).json({ error: "Invalid messages" });
  try {
    const r = await fetch(AI_BASE_URL.replace(/\/$/, "") + "/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + AI_API_KEY },
      body: JSON.stringify({
        model: AI_MODEL, max_tokens: 4000,
        messages: [{ role: "system", content: String(system).slice(0, 4000) },
          ...messages.map(m => ({ role: m.role === "user" ? "user" : "assistant", content: String(m.content) }))],
      }),
    });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ error: "AI provider error" });
    res.status(200).json({ text: j.choices?.[0]?.message?.content || "" });
  } catch { res.status(502).json({ error: "AI provider unreachable" }); }
}
