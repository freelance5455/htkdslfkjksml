# Marve Chat — Website + Android APK

## What is ready
- The web app is a Progressive Web App (PWA) with a manifest, icons, and service worker.
- The chat API is a Vercel serverless function at `api/chat.js`.
- The AI feature will not work until server environment variables are configured.

## Part 1 — Put the website online
1. Create/sign in to a Vercel account.
2. Import this project folder from a GitHub repository, or deploy this folder using Vercel CLI.
3. In Vercel Project Settings → Environment Variables, set:
   - `AI_API_KEY` = your AI provider's secret API key
   - `AI_BASE_URL` = provider's OpenAI-compatible API base URL (example: `https://api.groq.com/openai/v1`)
   - `AI_MODEL` = a model name supported by that provider
4. Redeploy after setting the variables.
5. Open the deployed HTTPS website on Android Chrome. Use the browser menu → **Install app** or **Add to Home screen**.

Never put the AI API key in `index.html` or any browser-side JavaScript. Keep it as a server environment variable.

## Part 2 — Make an Android APK
The APK should open the hosted HTTPS site so the server-side AI endpoint remains available. A native Android build needs Android Studio/Android SDK and signing/build steps; this ZIP alone is not a compiled APK.

Recommended route after Part 1:
1. Install Android Studio on a computer and install its Android SDK.
2. Use a Trusted Web Activity (TWA) wrapper such as Bubblewrap for the deployed HTTPS PWA, or create a Capacitor Android wrapper configured to load the deployed site.
3. Build a signed release APK in Android Studio/Bubblewrap.
4. Test the APK on your phone before sharing it through Xender.

You must know the final website URL before packaging the Android app. If you use a TWA, Android app/site association (Digital Asset Links) must also be configured for a verified full-screen experience.

## Important limits
- The site can cache its shell for opening offline, but AI replies require internet access.
- Chat history is stored locally on each device and is not synced between devices.
- Hosting and AI provider accounts/API usage may have costs or free-tier limits.
