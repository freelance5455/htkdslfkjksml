# Marve Chat (installable PWA)
1. Create a free account at vercel.com and put this folder in a GitHub repo (or use `npx vercel`).
2. Pick an OpenAI-compatible AI provider and get an API key (check its current free limits and terms).
3. In Vercel > Settings > Environment Variables add: AI_API_KEY, AI_BASE_URL (e.g. https://api.groq.com/openai/v1), AI_MODEL (a model name from that provider).
4. Deploy. Open the URL on your phone and choose Add to Home Screen (Android: Install app).
Chats are stored on the device only. Add accounts later (e.g. Supabase) for sync.
