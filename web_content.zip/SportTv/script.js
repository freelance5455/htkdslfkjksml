
/* =========================================
   SPORT APP — Main JavaScript
   ========================================= */

"use strict";

document.addEventListener("DOMContentLoaded", () => {
  initializeMenu();
  initializeNavigation();
});

/* -----------------------------------------
   Popup menu
   ----------------------------------------- */

function initializeMenu() {
  const menuButton = document.getElementById("menuButton");
  const menuPopup = document.getElementById("menuPopup");
  const closeButton = document.getElementById("closeMenu");
  const backdrop = document.getElementById("popupBackdrop");

  if (!menuButton || !menuPopup || !closeButton || !backdrop) {
    return;
  }

  function openMenu() {
    menuPopup.hidden = false;
    backdrop.hidden = false;
    menuButton.setAttribute("aria-expanded", "true");
    closeButton.focus();
  }

  function closeMenu() {
    menuPopup.hidden = true;
    backdrop.hidden = true;
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.focus();
  }

  menuButton.addEventListener("click", () => {
    if (menuPopup.hidden) {
      openMenu();
    } else {
      closeMenu();
    }
  });

  closeButton.addEventListener("click", closeMenu);
  backdrop.addEventListener("click", closeMenu);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !menuPopup.hidden) {
      closeMenu();
    }
  });

  // Close the popup when an internal navigation link is selected.
  menuPopup.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", closeMenu);
  });
}

/* -----------------------------------------
   Bottom navigation active state
   ----------------------------------------- */

function initializeNavigation() {
  const navItems = document.querySelectorAll(".nav-item");

  if (!navItems.length) {
    return;
  }

  const currentPage = window.location.pathname
    .split("/")
    .pop()
    .toLowerCase() || "index.html";

  navItems.forEach((item) => {
    const href = item.getAttribute("href");

    if (!href) {
      return;
    }

    const targetPage = href.split("?")[0].toLowerCase();
    const isActive = targetPage === currentPage;

    item.classList.toggle("active", isActive);

    if (isActive) {
      item.setAttribute("aria-current", "page");
    } else {
      item.removeAttribute("aria-current");
    }
  });
}
