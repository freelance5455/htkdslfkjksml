BAD BOYS ESPORTS Admin Panel

ব্যবহার:
1. ZIP ফাইল Extract করুন।
2. index.html ফাইলটি SPCK Editor-এ খুলুন অথবা ওয়েব হোস্টিংয়ে আপলোড করুন।
3. Firebase Console-এ এই প্রজেক্টের Authentication থেকে Anonymous sign-in চালু থাকতে হবে।
4. Firestore Rules-এ নিরাপদ admin-only access সেট না করা পর্যন্ত বাস্তব টাকা/ব্যালেন্স ব্যবস্থাপনায় ব্যবহার করবেন না।

সতর্কতা: বর্তমান কোডে Anonymous sign-in আছে। শুধু এই পেজ লুকিয়ে রাখলে নিরাপত্তা হয় না।
Firestore Rules দিয়ে অনুমোদিত অ্যাডমিন ছাড়া settings, users, tournaments, requests ও announcements পরিবর্তন বন্ধ করুন।
