const $ = (id) => document.getElementById(id);
const authView=$('authView'), dashboard=$('dashboard');
let currentUser='', numbers=[], activities=[], messages=[];
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function logActivity(msg){activities.unshift({msg,time:new Date().toLocaleString('ar')});renderActivity()}
function showLogin(){ $('loginForm').classList.remove('hidden');$('registerForm').classList.add('hidden');}
$('showRegister').onclick=()=>{$('loginForm').classList.add('hidden');$('registerForm').classList.remove('hidden')};
$('showLogin').onclick=showLogin;
$('registerForm').onsubmit=e=>{e.preventDefault();const u=$('regUser').value.trim(),p=$('regPass').value,c=$('regConfirm').value;if(p!==c){toast('كلمتا السر غير متطابقتين');return}if(p.length<6){toast('كلمة السر يجب أن تكون 6 أحرف على الأقل');return}localStorage.setItem('sy_demo_user',u);localStorage.setItem('sy_demo_pass',p);toast('تم إنشاء حساب تجريبي');$('loginUser').value=u;showLogin()};
$('loginForm').onsubmit=e=>{e.preventDefault();const u=$('loginUser').value.trim(),p=$('loginPass').value;if(u===localStorage.getItem('sy_demo_user')&&p===localStorage.getItem('sy_demo_pass'))enterApp(u);else toast('بيانات الدخول غير صحيحة أو أنشئ حساباً تجريبياً أولاً')};
function enterApp(u){currentUser=u;authView.classList.add('hidden');dashboard.classList.remove('hidden');$('userLabel').textContent=u;logActivity('تسجيل الدخول');}
$('logoutBtn').onclick=()=>{dashboard.classList.add('hidden');authView.classList.remove('hidden');$('loginPass').value='';toast('تم تسجيل الخروج')};
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));$('page-'+b.dataset.page).classList.remove('hidden')});
function renderNumbers(){$('numberList').innerHTML=numbers.length?numbers.map(n=>`<article class="number-card"><small>${n.country} • ${n.type}</small><strong>${n.number}</strong><small>حالة تجريبية • ${n.date}</small></article>`).join(''):'<div class="empty">لا توجد أرقام مضافة بعد.</div>'}
$('generateBtn').onclick=()=>{toast('هذه محاكاة فقط: اربط API بمزود مرخّص للحصول على رقم حقيقي');logActivity('محاولة طلب رقم — وضع تجريبي')};
function renderActivity(){$('activityList').innerHTML=activities.length?activities.map(a=>`<div class="message-item"><b>${a.msg}</b><br><small>${a.time}</small></div>`).join(''):'<div class="empty">لا يوجد نشاط بعد.</div>'}
$('refreshMessages').onclick=()=>toast('لا يوجد اتصال بمزود الرسائل في النسخة التجريبية');
$('keypad').onclick=e=>{if(e.target.tagName==='BUTTON')$('dialNumber').value+=$('dialNumber').value?e.target.textContent:e.target.textContent};
$('callBtn').onclick=()=>toast('الاتصال الحقيقي يتطلب مزود اتصالات وخادماً مرخصاً');
$('themeBtn').onclick=()=>{document.body.classList.toggle('light');$('darkToggle').checked=!document.body.classList.contains('light')};
$('darkToggle').onchange=()=>document.body.classList.toggle('light',!$('darkToggle').checked);
const answers=[
 [/حساب|تسجيل|انش/i,'لإنشاء حساب، افتح شاشة إنشاء حساب، أدخل اسم مستخدم وكلمة مرور ثم أكد كلمة المرور. هذه النسخة تحفظ حساباً تجريبياً على الجهاز فقط.'],
 [/رقم|توليد/i,'من صفحة الأرقام اختر الدولة ونوع الخدمة ثم اطلب رقماً. في النسخة الفعلية يجب أن يخصص الخادم رقماً من مزود مرخّص عبر API.'],
 [/رسائل|صندوق/i,'افتح تبويب الرسائل. ستظهر الرسائل التي يرسلها مزود الخدمة إلى الأرقام المخصصة لحسابك بعد ربط Webhook والخادم.'],
 [/كلمة السر|كلمه السر|نسيت/i,'لا تشارك كلمة المرور أو رموز التحقق مع أي شخص. استخدم آلية استعادة كلمة المرور الآمنة عند تنفيذ الخادم.']
];
function ask(q){const hit=answers.find(a=>a[0].test(q));$('botAnswer').textContent=hit?hit[1]:'لم أجد إجابة مؤكدة. تواصل مع الدعم الفني: ibrahimalhusseinialhuseeini@gmail.com';$('botAnswer').classList.remove('hidden')}
$('askBtn').onclick=()=>{const q=$('questionInput').value.trim();if(q)ask(q)};
document.querySelectorAll('[data-question]').forEach(b=>b.onclick=()=>ask(b.dataset.question));
