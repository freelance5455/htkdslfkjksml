import { pipeline } from "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.0.0";

// ---- Language catalogue (FLORES-200 / NLLB codes) ----------------------
const LANGUAGES = [
  { code: "arb_Arab", name: "العربية" },
  { code: "eng_Latn", name: "الإنجليزية" },
  { code: "fra_Latn", name: "الفرنسية" },
  { code: "spa_Latn", name: "الإسبانية" },
  { code: "deu_Latn", name: "الألمانية" },
  { code: "por_Latn", name: "البرتغالية" },
  { code: "ita_Latn", name: "الإيطالية" },
  { code: "tur_Latn", name: "التركية" },
  { code: "rus_Cyrl", name: "الروسية" },
  { code: "pes_Arab", name: "الفارسية" },
  { code: "urd_Arab", name: "الأردية" },
  { code: "hin_Deva", name: "الهندية" },
  { code: "zho_Hans", name: "الصينية" },
  { code: "jpn_Jpan", name: "اليابانية" },
  { code: "kor_Hang", name: "الكورية" },
  { code: "ind_Latn", name: "الإندونيسية" },
];

const MODEL_ID = "Xenova/nllb-200-distilled-600M";

// ---- DOM refs ------------------------------------------------------------
const el = (id) => document.getElementById(id);
const sourceLangSel = el("sourceLang");
const targetLangSel = el("targetLang");
const sourceText = el("sourceText");
const outputText = el("outputText");
const charCount = el("charCount");
const outputHint = el("outputHint");
const swapBtn = el("swapBtn");
const clearBtn = el("clearBtn");
const copyBtn = el("copyBtn");
const statusChip = el("statusChip");
const statusText = el("statusText");
const modelBar = el("modelBar");
const modelBarFill = el("modelBarFill");
const modelBarPct = el("modelBarPct");
const modelBarLabel = el("modelBarLabel");

outputText.setAttribute("data-placeholder", "ستظهر الترجمة هنا فور الكتابة");

function fillLangSelect(select, defaultCode) {
  select.innerHTML = "";
  for (const lang of LANGUAGES) {
    const opt = document.createElement("option");
    opt.value = lang.code;
    opt.textContent = lang.name;
    if (lang.code === defaultCode) opt.selected = true;
    select.appendChild(opt);
  }
}
fillLangSelect(sourceLangSel, "arb_Arab");
fillLangSelect(targetLangSel, "eng_Latn");

function setStatus(state, text) {
  statusChip.dataset.state = state;
  statusText.textContent = text;
}

// ---- Model loading ---------------------------------------------------
let translator = null;
let modelReady = false;

const bytesSeen = {}; // per-file progress tracking

function onProgress(data) {
  if (data.status === "progress" && data.file) {
    bytesSeen[data.file] = data.progress || 0;
    const values = Object.values(bytesSeen);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    modelBarFill.style.width = `${avg.toFixed(0)}%`;
    modelBarPct.textContent = `${avg.toFixed(0)}%`;
    modelBarLabel.textContent = "تنزيل نموذج الترجمة (مرة واحدة فقط)";
  } else if (data.status === "done") {
    modelBarLabel.textContent = "جارٍ تجهيز النموذج…";
  }
}

async function loadModel() {
  setStatus("loading", "جارٍ تحميل نموذج الترجمة…");
  modelBar.classList.add("visible");
  try {
    translator = await pipeline("translation", MODEL_ID, {
      progress_callback: onProgress,
      dtype: "q8",
    });
    modelReady = true;
    modelBar.classList.remove("visible");
    setStatus("ready", "جاهز — يعمل الآن بلا إنترنت");
    outputHint.textContent = "النموذج محفوظ على جهازك، الترجمة تتم محليًا";
    maybeTranslate();
  } catch (err) {
    console.error(err);
    modelBar.classList.remove("visible");
    setStatus("error", "تعذّر تحميل النموذج — تحقق من الاتصال أول مرة");
    outputHint.textContent = "يحتاج التطبيق اتصالًا بالإنترنت لتنزيل النموذج مرة واحدة فقط";
  }
}

// ---- Translation -------------------------------------------------------
let debounceTimer = null;
let inFlight = false;
let pendingRerun = false;

function maybeTranslate() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(runTranslation, 350);
}

async function runTranslation() {
  const text = sourceText.value.trim();

  if (!text) {
    outputText.textContent = "";
    outputHint.textContent = modelReady ? "النموذج محفوظ على جهازك، الترجمة تتم محليًا" : "ستظهر الترجمة هنا فور الكتابة";
    return;
  }
  if (!modelReady) return;

  if (inFlight) {
    pendingRerun = true;
    return;
  }
  inFlight = true;
  setStatus("busy", "جارٍ الترجمة محليًا…");
  try {
    const result = await translator(text, {
      src_lang: sourceLangSel.value,
      tgt_lang: targetLangSel.value,
    });
    outputText.textContent = result[0]?.translation_text ?? "";
    outputHint.textContent = "تمت الترجمة محليًا بلا اتصال بالإنترنت";
  } catch (err) {
    console.error(err);
    outputHint.textContent = "حدث خطأ أثناء الترجمة، حاول مجددًا";
  } finally {
    inFlight = false;
    setStatus("ready", "جاهز — يعمل الآن بلا إنترنت");
    if (pendingRerun) {
      pendingRerun = false;
      runTranslation();
    }
  }
}

// ---- Events --------------------------------------------------------------
sourceText.addEventListener("input", () => {
  charCount.textContent = sourceText.value.length;
  maybeTranslate();
});
sourceLangSel.addEventListener("change", maybeTranslate);
targetLangSel.addEventListener("change", maybeTranslate);

swapBtn.addEventListener("click", () => {
  const s = sourceLangSel.value;
  sourceLangSel.value = targetLangSel.value;
  targetLangSel.value = s;
  const t = sourceText.value;
  sourceText.value = outputText.textContent;
  outputText.textContent = t;
  charCount.textContent = sourceText.value.length;
  maybeTranslate();
});

clearBtn.addEventListener("click", () => {
  sourceText.value = "";
  outputText.textContent = "";
  charCount.textContent = "0";
  outputHint.textContent = modelReady ? "النموذج محفوظ على جهازك، الترجمة تتم محليًا" : "ستظهر الترجمة هنا فور الكتابة";
  sourceText.focus();
});

copyBtn.addEventListener("click", async () => {
  if (!outputText.textContent) return;
  try {
    await navigator.clipboard.writeText(outputText.textContent);
    outputHint.textContent = "تم نسخ الترجمة";
    setTimeout(() => (outputHint.textContent = "تمت الترجمة محليًا بلا اتصال بالإنترنت"), 1600);
  } catch (err) {
    console.error(err);
  }
});

// ---- Offline / PWA -------------------------------------------------------
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch((err) => console.warn("SW registration failed", err));
  });
}

window.addEventListener("offline", () => {
  if (modelReady) setStatus("ready", "غير متصل — الترجمة تعمل محليًا بلا مشاكل");
});
window.addEventListener("online", () => {
  if (modelReady) setStatus("ready", "جاهز — يعمل الآن بلا إنترنت");
});

loadModel();
