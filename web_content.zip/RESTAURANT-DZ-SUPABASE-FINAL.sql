-- RESTAURANT DZ — SAFE PERMISSIONS + RPC PATCH
-- Idempotent: can be run more than once. Does not drop tables, policies, or data.
-- Fixes PostgREST "permission denied for table wilayas" by granting table privileges
-- while leaving Row Level Security enabled and enforced.
BEGIN;

GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- Public app data. RLS policies still decide which rows are visible.
GRANT SELECT ON TABLE
  public.wilayas,
  public.categories,
  public.restaurants,
  public.restaurant_images,
  public.menu_sections,
  public.products,
  public.promo_offers,
  public.platform_settings
TO anon, authenticated;

-- Authenticated application data. RLS restricts each owner to their own records
-- and administrators to the records allowed by the existing is_admin() policies.
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE
  public.profiles,
  public.restaurants,
  public.restaurant_images,
  public.menu_sections,
  public.products,
  public.orders,
  public.order_items,
  public.subscriptions,
  public.payments,
  public.complaints,
  public.standalone_app_requests,
  public.admin_audit_logs,
  public.platform_settings,
  public.categories,
  public.promo_offers,
  public.wilayas
TO authenticated;

-- Sequence privileges needed by identity/bigserial columns (RLS still applies to tables).
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- Guest order creation. Amounts are recalculated from live product prices server-side.
create or replace function public.create_guest_order(
  p_restaurant_id uuid,
  p_customer_name text,
  p_customer_phone text,
  p_wilaya_id bigint,
  p_commune_name text,
  p_customer_address text,
  p_customer_note text,
  p_items jsonb
)
returns table(order_id uuid, tracking_code text, subtotal numeric, delivery_fee numeric, total numeric)
language plpgsql security definer set search_path = '' as $$
declare
  v_order_id uuid; v_tracking text; v_subtotal numeric(12,2):=0; v_delivery numeric;
  v_item jsonb; v_product public.products%rowtype; v_qty integer; v_name text; v_phone text; v_address text;
begin
  v_name:=btrim(coalesce(p_customer_name,''));
  v_phone:=regexp_replace(coalesce(p_customer_phone,''),'[^0-9+]','','g');
  v_address:=btrim(coalesce(p_customer_address,''));
  if length(v_name)<2 then raise exception 'Please enter a valid customer name'; end if;
  if length(v_phone)<8 or length(v_phone)>16 then raise exception 'Please enter a valid phone number'; end if;
  if length(v_address)<5 then raise exception 'Please enter a complete delivery address'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Order must contain at least one item'; end if;
  if jsonb_array_length(p_items)>50 then raise exception 'Too many different products in one order'; end if;
  if not exists(select 1 from public.restaurants r where r.id=p_restaurant_id and r.is_approved and r.is_active and r.is_open) then raise exception 'Restaurant is not currently accepting orders'; end if;
  select r.delivery_fee into v_delivery from public.restaurants r where r.id=p_restaurant_id;
  for v_item in select value from jsonb_array_elements(p_items) loop
    if coalesce(v_item->>'product_id','')='' then raise exception 'Invalid product'; end if;
    begin v_qty:=(v_item->>'quantity')::integer; exception when others then raise exception 'Invalid product quantity'; end;
    if v_qty<1 or v_qty>50 then raise exception 'Product quantity must be between 1 and 50'; end if;
    select * into v_product from public.products p where p.id=(v_item->>'product_id')::uuid and p.restaurant_id=p_restaurant_id and p.is_available for share;
    if not found then raise exception 'A selected product is unavailable'; end if;
    v_subtotal:=v_subtotal+(v_product.price*v_qty);
  end loop;
  v_tracking:=upper(substr(replace(gen_random_uuid()::text,'-',''),1,16));
  insert into public.orders(tracking_code,restaurant_id,customer_name,customer_phone,wilaya_id,commune_name,customer_address,customer_note,subtotal,delivery_fee,total)
  values(v_tracking,p_restaurant_id,v_name,v_phone,p_wilaya_id,nullif(btrim(coalesce(p_commune_name,'')),''),v_address,nullif(btrim(coalesce(p_customer_note,'')),''),v_subtotal,v_delivery,v_subtotal+v_delivery)
  returning id into v_order_id;
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_qty:=(v_item->>'quantity')::integer;
    select * into v_product from public.products p where p.id=(v_item->>'product_id')::uuid and p.restaurant_id=p_restaurant_id and p.is_available for share;
    insert into public.order_items(order_id,restaurant_id,product_id,product_name,product_image,unit_price,quantity,note)
    values(v_order_id,p_restaurant_id,v_product.id,v_product.name,v_product.image_url,v_product.price,v_qty,nullif(btrim(coalesce(v_item->>'note','')),''));
  end loop;
  return query select v_order_id,v_tracking,v_subtotal,v_delivery,v_subtotal+v_delivery;
end;
$$;

create or replace function public.track_guest_order(p_tracking_code text,p_customer_phone text)
returns jsonb language sql security definer set search_path = '' as $$
  select jsonb_build_object(
    'id',o.id,'tracking_code',o.tracking_code,'restaurant_id',o.restaurant_id,'restaurant_name',r.name,
    'customer_name',o.customer_name,'customer_phone',o.customer_phone,'wilaya_id',o.wilaya_id,
    'commune_name',o.commune_name,'customer_address',o.customer_address,'customer_note',o.customer_note,
    'subtotal',o.subtotal,'delivery_fee',o.delivery_fee,'total',o.total,'status',o.status,'created_at',o.created_at,
    'items',coalesce((select jsonb_agg(jsonb_build_object('product_id',oi.product_id,'product_name',oi.product_name,'product_image',oi.product_image,'unit_price',oi.unit_price,'quantity',oi.quantity,'note',oi.note) order by oi.created_at) from public.order_items oi where oi.order_id=o.id),'[]'::jsonb)
  ) from public.orders o join public.restaurants r on r.id=o.restaurant_id
  where upper(o.tracking_code)=upper(btrim(coalesce(p_tracking_code,'')))
    and regexp_replace(o.customer_phone,'[^0-9+]','','g')=regexp_replace(coalesce(p_customer_phone,''),'[^0-9+]','','g') limit 1;
$$;

create or replace function public.update_order_status(p_order_id uuid,p_new_status text)
returns boolean language plpgsql security definer set search_path = '' as $$
declare v_restaurant uuid; v_current text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select o.restaurant_id,o.status into v_restaurant,v_current from public.orders o where o.id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if not public.is_admin() and not exists(select 1 from public.restaurants r where r.id=v_restaurant and r.owner_id=auth.uid()) then raise exception 'Not allowed to update this order'; end if;
  if p_new_status not in ('accepted','preparing','delivering','delivered','rejected','cancelled') then raise exception 'Invalid order status'; end if;
  if v_current in ('delivered','rejected','cancelled') then raise exception 'This order is already closed'; end if;
  update public.orders set status=p_new_status,updated_at=now() where id=p_order_id;
  return true;
end;
$$;

REVOKE ALL ON FUNCTION public.create_guest_order(uuid,text,text,bigint,text,text,text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_guest_order(uuid,text,text,bigint,text,text,text,jsonb) TO anon, authenticated;
REVOKE ALL ON FUNCTION public.track_guest_order(text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.track_guest_order(text,text) TO anon, authenticated;
REVOKE ALL ON FUNCTION public.update_order_status(uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.update_order_status(uuid,text) TO authenticated;

COMMIT;
