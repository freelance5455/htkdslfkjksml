Drob Loot Update 1.0.1

Fix: The connection-code text areas are now editable and accept typing/pasting.
Open index.html through an HTTPS website in Chrome for camera/microphone access.
This is still a manual WebRTC test: exchange the long offer/answer text between both devices.
