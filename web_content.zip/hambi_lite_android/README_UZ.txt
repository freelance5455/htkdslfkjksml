HAMBI LITE — ANDROID STUDIO LOYIHA MANBA KODI

Bu mustaqil demo/prototip. Rasmiy Hambi ilovasi emas; Hambi serverlari, hisoblar va haqiqiy to'lovlarga ulanmaydi.

APK yaratish:
1. Android Studio o'rnating: https://developer.android.com/studio
2. ZIP arxivni chiqaring.
3. Android Studio > Open orqali hambi_lite_android papkasini oching.
4. Gradle sync tugashini kuting. SDK 35 va mos JDK o'rnatilgan bo'lishi kerak.
5. Telefonni USB debugging orqali ulang yoki emulator oching, so'ng Run tugmasini bosing.
6. APK olish: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK odatda app/build/outputs/apk/debug/app-debug.apk ichida yaratiladi.

Eslatma: Android Studio/SDK bilan bu loyihani build qilish talab etiladi. Bu muhitda tayyor APK kompilyatsiya qilinmagan.
Brend nomi/logo va haqiqiy xizmatlarga ulanish uchun tegishli ruxsat/API kerak bo'lishi mumkin.
