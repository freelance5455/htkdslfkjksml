AJIYATA — DEMO NA FARKO

Yana da:
- Ƙara masu ajiya da lambar waya
- Rubuta biyan kuɗi da yawan makonni
- Tarihin biya da rasit da za a buga/ajiye PDF
- Ajiyar bayanai a browser na wannan na'ura
- Sauke da mayar da madadin JSON
- Fayilolin PWA da offline cache

MUHIMMI:
Wannan demo ba a haɗa shi da Supabase ba tukuna kuma ba a kammala login/tsaron admin ba.
Bayanan da aka shigar suna kan wannan browser/waya kawai. Kada a saka bayanan kuɗi na gaske har sai an kammala tsaro da cloud sync.
Domin a girka kamar app, sai an ɗora fayilolin a hosting mai HTTPS. Bayan haka buɗe shafin a Chrome Android sannan zaɓi "Install app" ko "Add to Home screen".
Ba za a iya girka PWA ta hanyar buɗe index.html kai tsaye daga Downloads ba.
