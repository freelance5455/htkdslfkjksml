पशुधन मित्र — पहिली प्रोटोटाइप आवृत्ती

फाइल्स:
- index.html: मुख्य वेब ॲप
- manifest.json: installable PWA manifest
- sw.js: basic offline cache

चालवण्याची पद्धत:
1. ZIP extract करा.
2. index.html ब्राउझरमध्ये उघडा. काही ब्राउझरमध्ये PWA/offline सुविधा चालण्यासाठी HTTPS किंवा localhost आवश्यक असते.
3. Chrome मध्ये hosted HTTPS आवृत्ती उघडल्यावर menu > Add to Home screen / Install app वापरता येते.

सध्याच्या मर्यादा:
- हा कार्यरत प्रोटोटाइप आहे; अधिकृत सरकारी Bharat Pashudhan ॲप नाही.
- नोंदी त्या ब्राउझर/डिव्हाइसच्या local storage मध्ये राहतात.
- OTP login, cloud sync, server database, automatic scheduled notifications आणि अधिकृत सरकारी API integration जोडलेले नाहीत.
- टॅग स्कॅनिंगसाठी या आवृत्तीत प्रत्यक्ष QR/barcode scanner जोडलेला नाही; टॅग नंबर टाइप करून नोंद करता येते.
- मोबाईल/ब्राउझर डेटा साफ केल्यास स्थानिक नोंदी नष्ट होऊ शकतात. नियमित JSON backup घ्या.
- प्रत्यक्ष वापरापूर्वी security, privacy, backup, validation आणि device testing करणे आवश्यक आहे.
