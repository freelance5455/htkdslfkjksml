const fs=require("fs"),p="android/app/src/main/AndroidManifest.xml";
let m=fs.readFileSync(p,"utf8");
if(!m.includes("CAMERA")){m=m.replace(/(<uses-permission android:name="android.permission.INTERNET"\s*\/>)/,'$1\n    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />');fs.writeFileSync(p,m);console.log("Permissão de câmera adicionada.")}
