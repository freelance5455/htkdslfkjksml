# Carreira Pro — Android

Projeto Android Studio que empacota o simulador HTML offline em WebView. Os salvamentos locais do jogo (localStorage) ficam habilitados.


## Gerar o APK
1. Instale Android Studio (versão recente) e Android SDK Platform 35.
2. Abra esta pasta no Android Studio (Open).
3. Aguarde a sincronização do Gradle.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.


Não foi incluído APK compilado: o ambiente que gerou este projeto não possui Android SDK/Gradle instalado.
