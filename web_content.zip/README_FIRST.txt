BELARUS BAZAAR — READY FOR ONLINE APK BUILDING

This ZIP is intentionally structured for website-to-APK builders:
- index.html is at the ZIP ROOT
- all images use relative paths
- all filenames are lowercase
- no node_modules or external CSS/JS dependencies
- icon.png is included

Recommended builder: HTML to APK Builder
Upload this ZIP, set the app name to BELARUS BAZAAR, use icon.png, package name com.belarusbazaar.app, and build a signed APK.

The app includes:
- 5 products and AFN prices
- search
- categories
- featured products
- shopping cart and quantity controls
- WhatsApp order summary
- Dari/English interface
- CEO Hakim Khan Buniri profile/photo
- BELARUS BAZAAR branding
