TST CALCO - CONVERTER PACKAGE (MUBASHIR AMJED)

IMPORTANT: This ZIP is deliberately arranged with index.html at the ZIP ROOT.
The APK you uploaded declares localContent=true and localEntry=index.html,
but its APK archive did not contain the web page at all.

HOW TO REBUILD IN HTML TO APK
1. Remove/uninstall the old TST Calco APK from the phone (optional, but avoids confusion).
2. In the HTML-to-APK app, create a new project using LOCAL/OFFLINE HTML content.
3. Import/extract this ZIP and select the ROOT index.html as the start page.
   Do not select the outer folder as a website URL.
4. Keep app name TST Calco and package name com.app.tstcalco if the builder allows it.
5. Enable/include local website files/assets in the APK; do not use a remote URL.
6. Build a NEW APK, install it, then test in Airplane mode.

This ZIP contains a self-contained HTML file (CSS and JavaScript are inline).
The uploaded APK itself cannot be repaired by changing its filename; it must be rebuilt
by the HTML-to-APK builder so the HTML file is actually packaged inside the APK.
