S✨ UNIFIED UPSC UNIVERSE — VOLTBUILDER PACKAGE v5.2
=====================================================

WHAT IS INCLUDED
- www/index.html: the complete updated S✨ app
- App display name: S✨
- Uploaded logo installed as the Android launcher icon, browser icon, and in-app brand mark
- Android launcher icon files for ldpi through xxxhdpi
- config.xml: Cordova project configuration
- cordova-plugin-file: native Android/iOS app-private file storage
- Native Cordova bridge for app exports and the SGold-Vault
- Build notes and test checklist

BUILD
1. Upload this ZIP to https://volt.build/ (do not re-zip its contents).
2. Choose Android and build a DEBUG APK for the first test.
3. Install the APK on your Android device and grant only the file access
   permissions requested by Android's system picker when you export/import.
4. Test the checklist in BUILD_NOTES.txt before relying on it for study data.

IMPORTANT STORAGE BEHAVIOUR
- The app's SGold-Vault and exports use Cordova's native File plugin in the
  app-private persistent data directory. They remain through normal app restarts
  and app updates.
- Android deletes app-private data when the app is uninstalled or its data is
  cleared. No package can prevent that. Export regular backups to a user-chosen
  location or cloud storage before uninstalling/resetting the phone.
- Android does not permit silent scanning of all phone storage. Importing from
  shared storage must be initiated by the user through Android's file picker.
- This package does not claim to sync an arbitrary Obsidian folder automatically.
  The browser's showDirectoryPicker API is not available in Android WebView.
  Use the app's import/export flows and keep external backups.

The Cordova File plugin is a VoltBuilder core plugin. The package does not need
Capacitor, a private keystore, or broad MANAGE_EXTERNAL_STORAGE permission.
