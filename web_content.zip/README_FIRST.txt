MICRO PANEL ONLY

Want to try it right away?
1. Open the 'web' folder.
2. Tap index.html in a browser. It works offline after the files are extracted, and the artwork should stay next to index.html.

Want an installable Android APK?
Open the 'android' folder as a project in Android Studio and follow android/README_BUILD_APK.md.
This download is not itself an APK. The current environment cannot compile an APK binary.
