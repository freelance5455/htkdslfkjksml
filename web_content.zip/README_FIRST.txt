SMART STORE MANAGER — ANDROID BUILD PACKAGE

Contents
- index.html: copy of Smart_Store_Manager_Safer_Updated.html prepared as the app entry page.

IMPORTANT BEFORE INSTALLING
1. Keep your existing working HTML file and smart-store-backup-2026-10-29.json safe.
2. This package contains the app code only; it does NOT contain your private business backup or sales records.
3. The app currently saves records in local browser/WebView storage. An APK has its own separate storage, so restore your JSON backup inside the installed app and verify the counts before using it for real work.
4. The backup available for this build has 111 products, 10 sales, 0 stock receipts and 0 expenses. It cannot restore receipt/expense records that are not present in the backup.
5. Test offline, close/reopen, add a test record, export a new backup, and confirm it opens before relying on the app.

Build identity suggestion
App name: Smart Store Manager
Package ID suggestion: com.smartstoremanager.app
Choose the package ID carefully because it is difficult to change after a Play Store release.

This is a WebView-wrapped web app, not yet a fully native Android app. Further work is needed before commercial/Play Store release, including device testing, privacy/data protection review, signing-key ownership, and Play policy checks.
