GOD EDITZ STUDIO - WEB APP STARTER

This ZIP is intended for an HTML-to-APK converter.
IMPORTANT:
- index.html is at the top level of this ZIP.
- This is a working starter interface: video/audio import, video preview, trim-range preview, text overlay, visual preview filters, and project-recipe export.
- It does NOT yet render a finished MP4 or provide full AI, CGI, motion tracking, keyframes, beat-sync, or After Effects-level tools. Those need a real rendering/AI engine and are not included in this starter.
- For an HTML-to-APK builder, choose this ZIP as the website/project input and set index.html as the start page if asked.
- Test the app in the converter preview before installing. Only install APKs from services you trust.
