FARMTOOL CIRCLE - MANDI PRICE STARTER
=====================================

This starter project displays official mandi prices in BOTH:
- INR per quintal (as reported)
- INR per kg (calculated by dividing by 100)

Coverage:
- All commodities and markets returned by the selected government dataset.
- This does NOT guarantee every crop or every APMC reports every day.

IMPORTANT:
This is a starter integration, not a live-connected finished app.
You must configure the official data.gov.in resource/API details and deploy the
Google Apps Script backend before live prices appear.

1. Open https://www.data.gov.in/catalog/current-daily-price-various-commodities-various-markets-mandi
2. Locate the current API/resource documentation and obtain an API key if required.
3. In Code.gs, set DATA_GOV_API_KEY and verify RESOURCE_ID and API field names against
   the current dataset documentation. Do not share your API key.
4. Deploy the Apps Script as a Web App, allowing access appropriate for your app.
5. Copy the Web App URL into app.js at API_URL.
6. Open index.html to preview, then package the project using your Android app builder.

The code deliberately shows an error instead of inventing prices when the API is
not configured or the government endpoint returns an unexpected response.

Price conversion:
INR/kg = INR/quintal / 100

The official market price is a reported mandi price, not a guaranteed sale price.
Always show the actual reporting date. A market may not publish a new record daily.
