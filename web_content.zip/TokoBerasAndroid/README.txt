TOKO BERAS PRO MAX - proyek Android WebView

Catatan: folder ini adalah SOURCE PROJECT Android, bukan file APK yang sudah dikompilasi.
Cara membuat APK:
1. Buka Android Studio di komputer.
2. Pilih Open, lalu pilih folder TokoBerasAndroid.
3. Tunggu Gradle Sync selesai (perlu internet untuk mengunduh komponen).
4. Pilih Build > Build APK(s).
5. APK biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Aplikasi menyimpan data pada penyimpanan browser lokal perangkat. Jangan hapus data aplikasi jika ingin mempertahankan catatan.
Beberapa pustaka UI/font di HTML diambil dari internet.
