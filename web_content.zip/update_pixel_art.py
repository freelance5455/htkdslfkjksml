import re

INDEX_PATH = 'app/src/main/assets/index.html'

with open(INDEX_PATH, 'r', encoding='utf-8') as f:
    html = f.read()

print("Initial file size:", len(html))

# ==========================================
# 1. CSS UPDATES
# ==========================================
css_target = ".souls-title {"
css_replacement = """    .px-icon {
      display: inline-block;
      vertical-align: middle;
      image-rendering: pixelated;
      image-rendering: crisp-edges;
      flex-shrink: 0;
    }
    .px-icon svg {
      display: block;
      width: 100%;
      height: 100%;
      shape-rendering: crispEdges;
      pointer-events: none;
    }
    .px-coin-sm { width: 15px; height: 15px; }
    .px-coin-md { width: 18px; height: 18px; }
    .px-trophy-sm { width: 16px; height: 16px; }
    .px-play-sm { width: 14px; height: 14px; }
    .px-trash-sm { width: 14px; height: 14px; }
    .px-plus-sm { width: 14px; height: 14px; }
    .px-restart-sm { width: 14px; height: 14px; }
    .px-home-sm { width: 15px; height: 15px; }
    .px-boot-sm { width: 14px; height: 14px; }
    .px-target-sm { width: 14px; height: 14px; }
    .px-hat-sm { width: 15px; height: 15px; }
    .px-bandana-sm { width: 15px; height: 15px; }
    .px-cap-sm { width: 15px; height: 15px; }
    .px-bare-sm { width: 15px; height: 15px; }
    .px-star-sm { width: 14px; height: 14px; }
    .px-thunder-sm { width: 14px; height: 14px; }
    .px-shield-sm { width: 16px; height: 16px; }
    .px-sound-on, .px-sound-off { width: 20px; height: 20px; }
    .px-pause { width: 16px; height: 16px; }
    .hud-shield-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-left: 5px;
      filter: drop-shadow(0 0 4px #00f5d4);
      animation: shieldPulse 1.8s ease-in-out infinite alternate;
    }
    @keyframes shieldPulse {
      0% { transform: scale(1); filter: drop-shadow(0 0 2px #00bbf9); }
      100% { transform: scale(1.12); filter: drop-shadow(0 0 6px #00f5d4); }
    }
    .souls-title {"""
assert css_target in html, "CSS target not found"
html = html.replace(css_target, css_replacement, 1)

# ==========================================
# 2. HUD MARKUP UPDATES (lives + shield, buffs, coins, sound, pause)
# ==========================================
lives_target = """        <span class="life-heart" id="h-5">
          <svg class="heart-svg" viewBox="0 0 11 10" width="100%" height="100%" shape-rendering="crispEdges">
            <path class="heart-border" d="M 2 0 H 4 V 1 H 7 V 0 H 9 V 1 H 10 V 2 H 11 V 4 H 10 V 5 H 9 V 6 H 8 V 7 H 7 V 8 H 6 V 9 H 5 V 8 H 4 V 7 H 3 V 6 H 2 V 5 H 1 V 4 H 0 V 2 H 1 V 1 H 2 Z M 4 1 H 7 V 2 H 4 Z"/>
            <path class="heart-fill" d="M 2 1 H 4 V 2 H 2 Z M 7 1 H 9 V 2 H 7 Z M 1 2 H 10 V 4 H 9 V 5 H 8 V 6 H 7 V 7 H 6 V 8 H 5 V 7 H 4 V 6 H 3 V 5 H 2 V 4 H 1 Z"/>
            <path class="heart-shadow" d="M 8 3 H 9 V 5 H 8 V 6 H 7 V 7 H 5 V 8 H 6 V 7 H 7 V 6 H 8 Z"/>
            <path class="heart-pink" d="M 3 2 H 4 V 3 H 3 Z M 1 3 H 2 V 4 H 2 Z M 2 4 H 3 V 5 H 2 Z"/>
            <path class="heart-shine" d="M 2 2 H 3 V 4 H 2 Z"/>
          </svg>
        </span>
      </div>
    </div>"""

lives_replacement = """        <span class="life-heart" id="h-5">
          <svg class="heart-svg" viewBox="0 0 11 10" width="100%" height="100%" shape-rendering="crispEdges">
            <path class="heart-border" d="M 2 0 H 4 V 1 H 7 V 0 H 9 V 1 H 10 V 2 H 11 V 4 H 10 V 5 H 9 V 6 H 8 V 7 H 7 V 8 H 6 V 9 H 5 V 8 H 4 V 7 H 3 V 6 H 2 V 5 H 1 V 4 H 0 V 2 H 1 V 1 H 2 Z M 4 1 H 7 V 2 H 4 Z"/>
            <path class="heart-fill" d="M 2 1 H 4 V 2 H 2 Z M 7 1 H 9 V 2 H 7 Z M 1 2 H 10 V 4 H 9 V 5 H 8 V 6 H 7 V 7 H 6 V 8 H 5 V 7 H 4 V 6 H 3 V 5 H 2 V 4 H 1 Z"/>
            <path class="heart-shadow" d="M 8 3 H 9 V 5 H 8 V 6 H 7 V 7 H 5 V 8 H 6 V 7 H 7 V 6 H 8 Z"/>
            <path class="heart-pink" d="M 3 2 H 4 V 3 H 3 Z M 1 3 H 2 V 4 H 2 Z M 2 4 H 3 V 5 H 2 Z"/>
            <path class="heart-shine" d="M 2 2 H 3 V 4 H 2 Z"/>
          </svg>
        </span>
        <span id="hud-shield-indicator" class="hud-shield-icon" style="display:none;" title="Escudo Ativo">
          <svg class="px-icon px-shield-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges">
            <path fill="#120904" d="M2,1h12v1H2ZM1,2h14v1H1ZM1,3h14v6H1ZM2,9h12v2H2ZM3,11h10v2H3ZM5,13h6v1H5ZM6,14h4v1H6ZM7,15h2v1H7Z"/>
            <path fill="#8f5624" d="M2,2h12v1H2ZM2,3h2v6H2ZM12,3h2v6H12ZM3,9h2v2H3ZM11,9h2v2H11ZM4,11h2v1H4ZM10,11h2v1H10Z"/>
            <path fill="#3a4454" d="M4,3h8v6H4ZM4,9h8v1H4ZM5,10h6v2H5ZM6,12h4v1H6ZM7,13h2v1H7Z"/>
            <path fill="#708090" d="M5,3h2v3H5ZM7,5h2v3H7ZM9,7h2v2H9Z"/>
            <path fill="#ffffff" d="M6,3h1v2H6ZM8,5h1v2H8ZM7,5h2v1H7Z"/>
            <path fill="#ffd166" d="M3,3h1v1H3ZM12,3h1v1H12ZM7,13h2v1H7Z"/>
            <path fill="#00bbf9" d="M7,4h2v6H7ZM5,6h6v2H5Z"/>
            <path fill="#00f5d4" d="M7,6h2v2H7Z"/>
          </svg>
        </span>
      </div>
    </div>"""
assert lives_target in html, "lives_target not found"
html = html.replace(lives_target, lives_replacement, 1)

hud_target = """    <div class="hud-buffs">
      <div id="buff-spd" class="buff-badge">⚡ VELOCIDADE</div>
      <div id="buff-tri" class="buff-badge">💥 TIRO TRIPLO</div>
      <div id="buff-shield" class="buff-badge" style="background:#4361ee; border-color:#4cc9f0; color:#fff;">🛡️ ESCUDO</div>
    </div>
    <div class="hud-box">
      <span>🪙 <span id="hud-coins" style="color:#ffd166;">0</span></span>
      <span>ONDA: <span id="hud-wave" style="color:#ffd166;">1</span></span>
      <span>PONTOS: <span id="hud-score" style="color:#ffd166;">0</span></span>
      <button class="btn-sound" id="btn-sound" title="Som">🔊</button>
      <button class="btn-pause" id="btn-pause" title="Pausar jogo" aria-label="Pausar jogo">❚❚</button>
    </div>"""

hud_replacement = """    <div class="hud-buffs">
      <div id="buff-spd" class="buff-badge">
        <svg class="px-icon px-boot-sm" viewBox="0 0 16 16" width="14" height="14" shape-rendering="crispEdges">
          <path fill="#140803" d="M4,2h6v1H4ZM3,3h1v8H3ZM10,3h1v5H10ZM11,8h3v1H11ZM14,9h2v3H14ZM2,11h1v3H2ZM3,14h12v1H3Z"/>
          <path fill="#8f4614" d="M4,4h6v6H4ZM4,8h7v2H4ZM4,10h10v2H4Z"/>
          <path fill="#e09443" d="M4,3h6v1H4Z"/>
          <path fill="#ba6a28" d="M5,4h1v6H5Z"/>
          <path fill="#c86d26" d="M6,10h6v1H6Z"/>
          <path fill="#5a2d0c" d="M3,12h11v2H3Z"/>
          <path fill="#ffd166" d="M1,11h2v2H1Z"/>
          <path fill="#a0c4ff" d="M1,6h3v3H1Z"/>
          <path fill="#ffffff" d="M0,12h2v1H0ZM2,7h2v1H2Z"/>
        </svg> VELOCIDADE
      </div>
      <div id="buff-tri" class="buff-badge">
        <svg class="px-icon px-triple-sm" viewBox="0 0 16 16" width="14" height="14" shape-rendering="crispEdges">
          <path fill="#800e13" d="M2,6h3v7H2ZM11,6h3v7H11Z"/>
          <path fill="#c1121f" d="M6,4h4v8H6Z"/>
          <path fill="#ffd166" d="M2,13h3v2H2ZM6,12h4v3H6ZM11,13h3v2H11Z"/>
          <path fill="#e63946" d="M3,5h2v2H3ZM11,5h2v2H11Z"/>
          <path fill="#ff4d6d" d="M7,2h2v3H7Z"/>
          <path fill="#ffffff" d="M7,4h1v8H7ZM7,0h2v2H7Z"/>
          <path fill="#ffba08" d="M1,2h2v2H1ZM13,2h2v2H13Z"/>
        </svg> TIRO TRIPLO
      </div>
      <div id="buff-shield" class="buff-badge" style="background:#1d3557; border-color:#4cc9f0; color:#fff;">
        <svg class="px-icon px-shield-sm" viewBox="0 0 16 16" width="14" height="14" shape-rendering="crispEdges">
          <path fill="#120904" d="M2,1h12v1H2ZM1,2h14v1H1ZM1,3h14v6H1ZM2,9h12v2H2ZM3,11h10v2H3ZM5,13h6v1H5ZM6,14h4v1H6ZM7,15h2v1H7Z"/>
          <path fill="#8f5624" d="M2,2h12v1H2ZM2,3h2v6H2ZM12,3h2v6H12ZM3,9h2v2H3ZM11,9h2v2H11ZM4,11h2v1H4ZM10,11h2v1H10Z"/>
          <path fill="#3a4454" d="M4,3h8v6H4ZM4,9h8v1H4ZM5,10h6v2H5ZM6,12h4v1H6ZM7,13h2v1H7Z"/>
          <path fill="#708090" d="M5,3h2v3H5ZM7,5h2v3H7ZM9,7h2v2H9Z"/>
          <path fill="#ffffff" d="M6,3h1v2H6ZM8,5h1v2H8ZM7,5h2v1H7Z"/>
          <path fill="#ffd166" d="M3,3h1v1H3ZM12,3h1v1H12ZM7,13h2v1H7Z"/>
          <path fill="#00bbf9" d="M7,4h2v6H7ZM5,6h6v2H5Z"/>
          <path fill="#00f5d4" d="M7,6h2v2H7Z"/>
        </svg> ESCUDO
      </div>
    </div>
    <div class="hud-box">
      <span>
        <svg class="px-icon px-coin-sm" viewBox="0 0 16 16" width="15" height="15" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
          <path fill="#2b1404" d="M5,1h6v1H5ZM11,2h2v1H11ZM13,3h1v2H13ZM14,5h1v6H14ZM13,11h1v2H13ZM11,13h2v1H11ZM5,14h6v1H5ZM3,13h2v1H3ZM2,11h1v2H2ZM1,5h1v6H1ZM2,3h1v2H2ZM3,2h2v1H3Z"/>
          <path fill="#8f5624" d="M5,2h6v1H5ZM11,3h2v1H11ZM13,5h1v6H13ZM11,12h2v1H11ZM5,13h6v1H5ZM3,12h2v1H3ZM2,5h1v6H2ZM3,3h2v1H3Z"/>
          <path fill="#ffd166" d="M4,3h8v10H4ZM3,4h10v8H3Z"/>
          <path fill="#e09f3e" d="M5,4h6v8H5Z"/>
          <path fill="#fff9db" d="M7,5h2v6H7ZM5,7h6v2H5Z"/>
          <path fill="#8f5624" d="M7,7h2v2H7Z"/>
          <path fill="#ffffff" d="M4,3h2v2H4Z"/>
        </svg><span id="hud-coins" style="color:#ffd166;">0</span>
      </span>
      <span>ONDA: <span id="hud-wave" style="color:#ffd166;">1</span></span>
      <span>PONTOS: <span id="hud-score" style="color:#ffd166;">0</span></span>
      <button class="btn-sound" id="btn-sound" title="Som" aria-label="Som">
        <svg id="sound-icon-svg" class="px-icon px-sound-on" viewBox="0 0 16 16" width="18" height="18" shape-rendering="crispEdges">
          <path fill="#1b0e06" d="M1,6h3v4H1ZM4,5h2v6H4ZM6,4h2v8H6ZM8,3h2v10H8ZM11,5h1v1H11ZM11,10h1v1H11ZM13,3h1v1H13ZM13,12h1v1H13Z"/>
          <path fill="#8f5624" d="M1,7h3v2H1Z"/>
          <path fill="#c9873c" d="M4,6h2v4H4ZM9,4h1v8H9Z"/>
          <path fill="#ffd166" d="M6,5h2v6H6ZM11,6h1v4H11ZM12,7h1v2H12ZM15,6h1v4H15Z"/>
          <path fill="#ffe6a7" d="M8,4h1v8H8ZM14,4h1v8H14Z"/>
        </svg>
      </button>
      <button class="btn-pause" id="btn-pause" title="Pausar jogo" aria-label="Pausar jogo">
        <svg class="px-icon px-pause" viewBox="0 0 16 16" width="15" height="15" shape-rendering="crispEdges">
          <path fill="#140803" d="M3,2h4v12H3ZM9,2h4v12H9Z"/>
          <path fill="#ffd166" d="M4,3h2v10H4ZM10,3h2v10H10Z"/>
          <path fill="#ffe6a7" d="M4,3h1v10H4ZM10,3h1v10H10Z"/>
          <path fill="#c9873c" d="M5,3h1v10H5ZM11,3h1v10H11Z"/>
        </svg>
      </button>
    </div>"""
assert hud_target in html, "hud_target not found"
html = html.replace(hud_target, hud_replacement, 1)

# ==========================================
# 3. JOYSTICKS HINTS
# ==========================================
hint_l_target = '<div id="hint-l" class="joy-hint">👢 MOVER</div>'
hint_l_replacement = """<div id="hint-l" class="joy-hint">
        <svg class="px-icon px-boot-sm" viewBox="0 0 16 16" width="14" height="14" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
          <path fill="#140803" d="M4,2h6v1H4ZM3,3h1v8H3ZM10,3h1v5H10ZM11,8h3v1H11ZM14,9h2v3H14ZM2,11h1v3H2ZM3,14h12v1H3Z"/>
          <path fill="#8f4614" d="M4,4h6v6H4ZM4,8h7v2H4ZM4,10h10v2H4Z"/>
          <path fill="#e09443" d="M4,3h6v1H4Z"/>
          <path fill="#ba6a28" d="M5,4h1v6H5Z"/>
          <path fill="#c86d26" d="M6,10h6v1H6Z"/>
          <path fill="#5a2d0c" d="M3,12h11v2H3Z"/>
          <path fill="#ffd166" d="M1,11h2v2H1Z"/>
          <path fill="#a0c4ff" d="M1,6h3v3H1Z"/>
          <path fill="#ffffff" d="M0,12h2v1H0ZM2,7h2v1H2Z"/>
        </svg> MOVER
      </div>"""
assert hint_l_target in html, "hint_l_target not found"
html = html.replace(hint_l_target, hint_l_replacement, 1)

hint_r_target = '<div id="hint-r" class="joy-hint">🎯 MIRAR / TIRO</div>'
hint_r_replacement = """<div id="hint-r" class="joy-hint">
        <svg class="px-icon px-target-sm" viewBox="0 0 16 16" width="14" height="14" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
          <path fill="#140803" d="M5,1h6v1H5ZM11,2h3v1H11ZM14,5h1v6H14ZM11,13h3v1H11ZM5,14h6v1H5ZM2,11h3v1H2ZM1,5h1v6H1ZM2,2h3v1H2ZM7,0h2v3H7ZM7,13h2v3H7ZM0,7h3v2H0ZM13,7h3v2H13Z"/>
          <path fill="#e63946" d="M5,2h6v2H5ZM11,3h2v3H11ZM12,5h2v6H12ZM11,10h2v3H11ZM5,12h6v2H5ZM3,10h2v3H3ZM2,5h2v6H2ZM3,3h2v3H3ZM6,6h4v4H6Z"/>
          <path fill="#ffffff" d="M5,4h6v8H5ZM4,5h8v6H4Z"/>
          <path fill="#ffd166" d="M7,7h2v2H7Z"/>
        </svg> MIRAR / TIRO
      </div>"""
assert hint_r_target in html, "hint_r_target not found"
html = html.replace(hint_r_target, hint_r_replacement, 1)

# ==========================================
# 4. ACHIEVEMENT TOAST
# ==========================================
toast_target = '<div id="ach-toast">🏆 <span id="ach-txt">Conquista!</span></div>'
toast_replacement = """<div id="ach-toast">
    <svg class="px-icon px-trophy-sm" viewBox="0 0 16 16" width="18" height="18" shape-rendering="crispEdges" style="vertical-align:-3px; margin-right:4px;">
      <path fill="#241005" d="M4,1h8v1H4ZM1,3h2v1H1ZM2,6h1v1H2ZM13,3h2v1H13ZM13,6h1v1H13ZM3,15h10v1H3Z"/>
      <path fill="#ffd166" d="M3,2h10v5H3ZM4,7h8v2H4ZM1,4h1v3H1Z"/>
      <path fill="#c9873c" d="M6,9h4v2H6ZM8,3h4v4H8ZM14,4h1v3H14Z"/>
      <path fill="#8f5624" d="M7,11h2v2H7Z"/>
      <path fill="#4a2810" d="M4,13h8v2H4Z"/>
      <path fill="#ffffff" d="M4,3h2v3H4Z"/>
    </svg> <span id="ach-txt">Conquista!</span>
  </div>"""
assert toast_target in html, "toast_target not found"
html = html.replace(toast_target, toast_replacement, 1)

# ==========================================
# 5. SCREEN 1 MENU PRINCIPAL
# ==========================================
menu_btn_target = """      <div style="display:flex; flex-direction:column; gap:8px; width:100%; max-width:280px; margin:10px auto;">
        <button id="btn-menu-play" class="btn-arc">▶ JOGAR</button>
        <button id="btn-menu-ach" class="btn-arc sec">🏆 CONQUISTAS</button>
      </div>"""

menu_btn_replacement = """      <div style="display:flex; flex-direction:column; gap:8px; width:100%; max-width:280px; margin:10px auto;">
        <button id="btn-menu-play" class="btn-arc">
          <svg class="px-icon px-play-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges" style="margin-right:6px;">
            <path fill="#140803" d="M3,2h2v12H3ZM5,3h2v10H5ZM7,4h2v8H7ZM9,5h2v6H9ZM11,6h2v4H11ZM13,7h2v2H13Z"/>
            <path fill="#ffe6a7" d="M4,3h1v10H4Z"/>
            <path fill="#ffd166" d="M5,4h2v8H5ZM7,5h2v6H7Z"/>
            <path fill="#e09f3e" d="M9,6h2v4H9Z"/>
            <path fill="#c9873c" d="M11,7h2v2H11Z"/>
          </svg> JOGAR
        </button>
        <button id="btn-menu-ach" class="btn-arc sec">
          <svg class="px-icon px-trophy-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges" style="margin-right:6px;">
            <path fill="#241005" d="M4,1h8v1H4ZM1,3h2v1H1ZM2,6h1v1H2ZM13,3h2v1H13ZM13,6h1v1H13ZM3,15h10v1H3Z"/>
            <path fill="#ffd166" d="M3,2h10v5H3ZM4,7h8v2H4ZM1,4h1v3H1Z"/>
            <path fill="#c9873c" d="M6,9h4v2H6ZM8,3h4v4H8ZM14,4h1v3H14Z"/>
            <path fill="#8f5624" d="M7,11h2v2H7Z"/>
            <path fill="#4a2810" d="M4,13h8v2H4Z"/>
            <path fill="#ffffff" d="M4,3h2v3H4Z"/>
          </svg> CONQUISTAS
        </button>
      </div>"""
assert menu_btn_target in html, "menu_btn_target not found"
html = html.replace(menu_btn_target, menu_btn_replacement, 1)

# ==========================================
# 6. SCREEN CHARACTER CREATION
# ==========================================
char_btn_target = """            <button class="choice-btn active" data-h="cowboy">🤠 Chapéu</button>
            <button class="choice-btn" data-h="bandana">🧣 Bandana</button>
            <button class="choice-btn" data-h="cap">🧢 Boné</button>
            <button class="choice-btn" data-h="none">👤 Sem</button>"""

char_btn_replacement = """            <button class="choice-btn active" data-h="cowboy">
              <svg class="px-icon px-hat-sm" viewBox="0 0 16 16" width="15" height="15" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
                <path fill="#1b0d04" d="M5,3h6v1H5ZM4,4h8v4H4ZM1,9h14v2H1Z"/>
                <path fill="#783808" d="M5,3h6v1H5ZM1,10h14v1H1ZM0,8h2v2H0ZM14,8h2v2H14Z"/>
                <path fill="#542807" d="M4,5h8v3H4Z"/>
                <path fill="#3b1c05" d="M6,4h4v1H6Z"/>
                <path fill="#ffd166" d="M4,8h8v1H4Z"/>
              </svg> Chapéu
            </button>
            <button class="choice-btn" data-h="bandana">
              <svg class="px-icon px-bandana-sm" viewBox="0 0 16 16" width="15" height="15" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
                <path fill="#780000" d="M2,3h12v3H2ZM7,12h2v2H7ZM1,3h2v2H1ZM13,3h2v2H13Z"/>
                <path fill="#c1121f" d="M2,4h12v2H2ZM3,6h10v3H3ZM5,9h6v3H5Z"/>
                <path fill="#ffffff" d="M4,4h2v1H4ZM9,5h2v1H9ZM6,7h2v1H6Z"/>
              </svg> Bandana
            </button>
            <button class="choice-btn" data-h="cap">
              <svg class="px-icon px-cap-sm" viewBox="0 0 16 16" width="15" height="15" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
                <path fill="#1d3557" d="M4,3h8v1H4ZM3,4h10v4H3ZM1,8h14v2H1Z"/>
                <path fill="#f1faee" d="M4,4h6v4H4Z"/>
                <path fill="#457b9d" d="M0,9h6v2H0Z"/>
                <path fill="#e63946" d="M6,2h2v1H6Z"/>
              </svg> Boné
            </button>
            <button class="choice-btn" data-h="none">
              <svg class="px-icon px-bare-sm" viewBox="0 0 16 16" width="15" height="15" shape-rendering="crispEdges" style="vertical-align:-2px; margin-right:3px;">
                <path fill="#2b170a" d="M5,2h6v1H5Z"/>
                <path fill="#e09f3e" d="M4,3h8v6H4Z"/>
                <path fill="#542807" d="M5,3h6v2H5Z"/>
                <path fill="#c9873c" d="M6,9h4v2H6Z"/>
                <path fill="#8f5624" d="M3,11h10v4H3Z"/>
              </svg> Sem
            </button>"""
assert char_btn_target in html, "char_btn_target not found"
html = html.replace(char_btn_target, char_btn_replacement, 1)

# ==========================================
# 7. SCREEN SHOP
# ==========================================
shop_target = """      <div style="font-size:14px; font-weight:bold; color:#ffd166; margin-bottom:6px;">
        Saldo Atual: 🪙 <span id="shop-coins-val">0</span> Moedas
      </div>
      <div id="shop-items-list" class="shop-grid"></div>
      <button id="btn-shop-next" class="btn-arc" style="margin-top:6px;">PRÓXIMA RONDA ▶</button>"""

shop_replacement = """      <div style="font-size:14px; font-weight:bold; color:#ffd166; margin-bottom:6px;">
        Saldo Atual:
        <svg class="px-icon px-coin-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges" style="vertical-align:-3px; margin-right:3px;">
          <path fill="#2b1404" d="M5,1h6v1H5ZM11,2h2v1H11ZM13,3h1v2H13ZM14,5h1v6H14ZM13,11h1v2H13ZM11,13h2v1H11ZM5,14h6v1H5ZM3,13h2v1H3ZM2,11h1v2H2ZM1,5h1v6H1ZM2,3h1v2H2ZM3,2h2v1H3Z"/>
          <path fill="#8f5624" d="M5,2h6v1H5ZM11,3h2v1H11ZM13,5h1v6H13ZM11,12h2v1H11ZM5,13h6v1H5ZM3,12h2v1H3ZM2,5h1v6H2ZM3,3h2v1H3Z"/>
          <path fill="#ffd166" d="M4,3h8v10H4ZM3,4h10v8H3Z"/>
          <path fill="#e09f3e" d="M5,4h6v8H5Z"/>
          <path fill="#fff9db" d="M7,5h2v6H7ZM5,7h6v2H5Z"/>
          <path fill="#8f5624" d="M7,7h2v2H7Z"/>
          <path fill="#ffffff" d="M4,3h2v2H4Z"/>
        </svg><span id="shop-coins-val">0</span> Moedas
      </div>
      <div id="shop-items-list" class="shop-grid"></div>
      <button id="btn-shop-next" class="btn-arc" style="margin-top:6px;">
        PRÓXIMA RONDA
        <svg class="px-icon px-play-sm" viewBox="0 0 16 16" width="14" height="14" shape-rendering="crispEdges" style="margin-left:6px;">
          <path fill="#140803" d="M3,2h2v12H3ZM5,3h2v10H5ZM7,4h2v8H7ZM9,5h2v6H9ZM11,6h2v4H11ZM13,7h2v2H13Z"/>
          <path fill="#ffe6a7" d="M4,3h1v10H4Z"/>
          <path fill="#ffd166" d="M5,4h2v8H5ZM7,5h2v6H7Z"/>
          <path fill="#e09f3e" d="M9,6h2v4H9Z"/>
          <path fill="#c9873c" d="M11,7h2v2H11Z"/>
        </svg>
      </button>"""
assert shop_target in html, "shop_target not found"
html = html.replace(shop_target, shop_replacement, 1)

# ==========================================
# 8. SCREEN PAUSE
# ==========================================
pause_target = """      <div style="display:flex; flex-direction:column; gap:10px; width:100%; max-width:280px; margin:16px auto 6px;">
        <button id="btn-pause-resume" class="btn-arc">▶ CONTINUAR</button>
        <button id="btn-pause-restart" class="btn-arc sec">🔄 REINICIAR</button>
        <button id="btn-pause-menu" class="btn-arc sec">🏠 MENU PRINCIPAL</button>
      </div>"""

pause_replacement = """      <div style="display:flex; flex-direction:column; gap:10px; width:100%; max-width:280px; margin:16px auto 6px;">
        <button id="btn-pause-resume" class="btn-arc">
          <svg class="px-icon px-play-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges" style="margin-right:6px;">
            <path fill="#140803" d="M3,2h2v12H3ZM5,3h2v10H5ZM7,4h2v8H7ZM9,5h2v6H9ZM11,6h2v4H11ZM13,7h2v2H13Z"/>
            <path fill="#ffe6a7" d="M4,3h1v10H4Z"/>
            <path fill="#ffd166" d="M5,4h2v8H5ZM7,5h2v6H7Z"/>
            <path fill="#e09f3e" d="M9,6h2v4H9Z"/>
            <path fill="#c9873c" d="M11,7h2v2H11Z"/>
          </svg> CONTINUAR
        </button>
        <button id="btn-pause-restart" class="btn-arc sec">
          <svg class="px-icon px-restart-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges" style="margin-right:6px;">
            <path fill="#ffd166" d="M5,2h6v2H5ZM3,4h2v4H3ZM11,4h2v3H11ZM10,2h4v4H10Z"/>
            <path fill="#c9873c" d="M2,8h2v4H2ZM12,7h2v5H12ZM4,12h8v2H4Z"/>
            <path fill="#ffe6a7" d="M11,1h2v2H11Z"/>
          </svg> REINICIAR
        </button>
        <button id="btn-pause-menu" class="btn-arc sec">
          <svg class="px-icon px-home-sm" viewBox="0 0 16 16" width="16" height="16" shape-rendering="crispEdges" style="margin-right:6px;">
            <path fill="#4a2810" d="M10,3h2v3H10Z"/>
            <path fill="#ffd166" d="M7,1h2v2H7ZM5,3h6v2H5Z"/>
            <path fill="#c9873c" d="M3,5h10v2H3Z"/>
            <path fill="#542807" d="M1,7h14v2H1Z"/>
            <path fill="#8f5624" d="M3,9h10v6H3Z"/>
            <path fill="#241005" d="M6,11h4v4H6Z"/>
          </svg> MENU PRINCIPAL
        </button>
      </div>"""
assert pause_target in html, "pause_target not found"
html = html.replace(pause_target, pause_replacement, 1)

# ==========================================
# 9. PIXEL_ICONS & DropSpriteSheet JAVASCRIPT INJECTION
# ==========================================
js_lib_injection = """
// ==========================================
// 16-BIT PIXEL ART ICONS & ASSET ENGINE
// ==========================================
const PIXEL_ICONS = {
  coin: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#2b1404" d="M5,1h6v1H5ZM11,2h2v1H11ZM13,3h1v2H13ZM14,5h1v6H14ZM13,11h1v2H13ZM11,13h2v1H11ZM5,14h6v1H5ZM3,13h2v1H3ZM2,11h1v2H2ZM1,5h1v6H1ZM2,3h1v2H2ZM3,2h2v1H3Z"/><path fill="#8f5624" d="M5,2h6v1H5ZM11,3h2v1H11ZM13,5h1v6H13ZM11,12h2v1H11ZM5,13h6v1H5ZM3,12h2v1H3ZM2,5h1v6H2ZM3,3h2v1H3Z"/><path fill="#ffd166" d="M4,3h8v10H4ZM3,4h10v8H3Z"/><path fill="#e09f3e" d="M5,4h6v8H5Z"/><path fill="#fff9db" d="M7,5h2v6H7ZM5,7h6v2H5Z"/><path fill="#8f5624" d="M7,7h2v2H7Z"/><path fill="#ffffff" d="M4,3h2v2H4Z"/></svg>',
  shield: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#120904" d="M2,1h12v1H2ZM1,2h14v1H1ZM1,3h14v6H1ZM2,9h12v2H2ZM3,11h10v2H3ZM5,13h6v1H5ZM6,14h4v1H6ZM7,15h2v1H7Z"/><path fill="#8f5624" d="M2,2h12v1H2ZM2,3h2v6H2ZM12,3h2v6H12ZM3,9h2v2H3ZM11,9h2v2H11ZM4,11h2v1H4ZM10,11h2v1H10Z"/><path fill="#3a4454" d="M4,3h8v6H4ZM4,9h8v1H4ZM5,10h6v2H5ZM6,12h4v1H6ZM7,13h2v1H7Z"/><path fill="#708090" d="M5,3h2v3H5ZM7,5h2v3H7ZM9,7h2v2H9Z"/><path fill="#ffffff" d="M6,3h1v2H6ZM8,5h1v2H8ZM7,5h2v1H7Z"/><path fill="#ffd166" d="M3,3h1v1H3ZM12,3h1v1H12ZM7,13h2v1H7Z"/><path fill="#00bbf9" d="M7,4h2v6H7ZM5,6h6v2H5Z"/><path fill="#00f5d4" d="M7,6h2v2H7Z"/></svg>',
  boot: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#140803" d="M4,2h6v1H4ZM3,3h1v8H3ZM10,3h1v5H10ZM11,8h3v1H11ZM14,9h2v3H14ZM2,11h1v3H2ZM3,14h12v1H3Z"/><path fill="#8f4614" d="M4,4h6v6H4ZM4,8h7v2H4ZM4,10h10v2H4Z"/><path fill="#e09443" d="M4,3h6v1H4Z"/><path fill="#ba6a28" d="M5,4h1v6H5Z"/><path fill="#c86d26" d="M6,10h6v1H6Z"/><path fill="#5a2d0c" d="M3,12h11v2H3Z"/><path fill="#ffd166" d="M1,11h2v2H1Z"/><path fill="#a0c4ff" d="M1,6h3v3H1Z"/><path fill="#ffffff" d="M0,12h2v1H0ZM2,7h2v1H2Z"/></svg>',
  heart: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#0a0402" d="M3,2h4v1H3ZM9,2h4v1H9ZM2,3h2v1H2ZM7,3h2v1H7ZM12,3h2v1H12ZM1,4h2v4H1ZM13,4h2v4H13ZM2,8h2v2H2ZM12,8h2v2H12ZM3,10h2v2H3ZM11,10h2v2H11ZM4,12h2v2H4ZM10,12h2v2H10ZM5,14h2v1H5ZM9,14h2v1H9ZM7,15h2v1H7Z"/><path fill="#e63946" d="M3,3h4v1H3ZM9,3h4v1H9ZM2,4h12v4H2ZM3,8h10v2H3ZM4,10h8v2H4ZM5,12h6v2H5ZM7,14h2v1H7Z"/><path fill="#780000" d="M9,5h3v2H9ZM8,7h4v2H8ZM7,9h4v2H7ZM6,11h3v2H6Z"/><path fill="#ffffff" d="M3,4h2v2H3ZM2,5h1v2H2ZM4,4h3v1H4Z"/><path fill="#ffb3c1" d="M5,5h2v1H5Z"/></svg>',
  triple: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#800e13" d="M2,6h3v7H2ZM11,6h3v7H11Z"/><path fill="#c1121f" d="M6,4h4v8H6Z"/><path fill="#ffd166" d="M2,13h3v2H2ZM6,12h4v3H6ZM11,13h3v2H11Z"/><path fill="#e63946" d="M3,5h2v2H3ZM11,5h2v2H11Z"/><path fill="#ff4d6d" d="M7,2h2v3H7Z"/><path fill="#ffffff" d="M7,4h1v8H7ZM7,0h2v2H7Z"/><path fill="#ffba08" d="M1,2h2v2H1ZM13,2h2v2H13Z"/></svg>',
  sound_on: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#1b0e06" d="M1,6h3v4H1ZM4,5h2v6H4ZM6,4h2v8H6ZM8,3h2v10H8ZM11,5h1v1H11ZM11,10h1v1H11ZM13,3h1v1H13ZM13,12h1v1H13Z"/><path fill="#8f5624" d="M1,7h3v2H1Z"/><path fill="#c9873c" d="M4,6h2v4H4ZM9,4h1v8H9Z"/><path fill="#ffd166" d="M6,5h2v6H6ZM11,6h1v4H11ZM12,7h1v2H12ZM15,6h1v4H15Z"/><path fill="#ffe6a7" d="M8,4h1v8H8ZM14,4h1v8H14Z"/></svg>',
  sound_off: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#1b0e06" d="M1,6h3v4H1ZM4,5h2v6H4ZM6,4h2v8H6ZM8,3h2v10H8ZM10,3h1v2H10ZM17,3h1v2H17ZM10,11h1v2H10ZM17,11h1v2H17Z"/><path fill="#8f5624" d="M1,7h3v2H1Z"/><path fill="#c9873c" d="M4,6h2v4H4ZM9,4h1v8H9Z"/><path fill="#ffd166" d="M6,5h2v6H6Z"/><path fill="#ffe6a7" d="M8,4h1v8H8Z"/><path fill="#e63946" d="M11,3h2v2H11ZM15,3h2v2H15ZM12,5h4v2H12ZM13,7h2v2H13ZM12,9h4v2H12ZM11,11h2v2H11ZM15,11h2v2H15Z"/><path fill="#ff4d6d" d="M13,7h2v2H13Z"/></svg>',
  pause: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#140803" d="M3,2h4v12H3ZM9,2h4v12H9Z"/><path fill="#ffd166" d="M4,3h2v10H4ZM10,3h2v10H10Z"/><path fill="#ffe6a7" d="M4,3h1v10H4ZM10,3h1v10H10Z"/><path fill="#c9873c" d="M5,3h1v10H5ZM11,3h1v10H11Z"/></svg>',
  play: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#140803" d="M3,2h2v12H3ZM5,3h2v10H5ZM7,4h2v8H7ZM9,5h2v6H9ZM11,6h2v4H11ZM13,7h2v2H13Z"/><path fill="#ffe6a7" d="M4,3h1v10H4Z"/><path fill="#ffd166" d="M5,4h2v8H5ZM7,5h2v6H7Z"/><path fill="#e09f3e" d="M9,6h2v4H9Z"/><path fill="#c9873c" d="M11,7h2v2H11Z"/></svg>',
  trophy: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#241005" d="M4,1h8v1H4ZM1,3h2v1H1ZM2,6h1v1H2ZM13,3h2v1H13ZM13,6h1v1H13ZM3,15h10v1H3Z"/><path fill="#ffd166" d="M3,2h10v5H3ZM4,7h8v2H4ZM1,4h1v3H1Z"/><path fill="#c9873c" d="M6,9h4v2H6ZM8,3h4v4H8ZM14,4h1v3H14Z"/><path fill="#8f5624" d="M7,11h2v2H7Z"/><path fill="#4a2810" d="M4,13h8v2H4Z"/><path fill="#ffffff" d="M4,3h2v3H4Z"/></svg>',
  skull: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#0f172a" d="M4,1h8v1H4ZM2,2h12v1H2ZM1,3h14v6H1ZM2,9h12v2H2ZM4,11h8v4H4ZM3,5h3v4H3ZM10,5h3v4H10ZM7,8h2v2H7Z"/><path fill="#f1f5f9" d="M4,2h8v1H4ZM2,3h12v6H2ZM5,12h6v2H5Z"/><path fill="#cbd5e1" d="M3,9h10v2H3Z"/><path fill="#ffffff" d="M3,3h2v4H3Z"/><path fill="#0f172a" d="M6,12h1v2H6ZM8,12h1v2H8ZM10,12h1v2H10Z"/></svg>',
  cactus: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#081c15" d="M6,1h4v1H6ZM1,4h3v1H1ZM12,3h3v1H12ZM1,5h1v4H1ZM14,4h1v4H14ZM6,2h4v13H6Z"/><path fill="#2d6a4f" d="M7,2h2v13H7ZM3,7h3v2H3ZM12,4h2v3H12Z"/><path fill="#52b788" d="M6,2h1v13H6ZM2,5h2v3H2Z"/><path fill="#1b4332" d="M8,2h1v13H8ZM10,6h3v2H10Z"/><path fill="#d8f3dc" d="M5,4h1v1H5ZM10,3h1v1H10ZM5,9h1v1H5ZM10,8h1v1H10Z"/><path fill="#8f5624" d="M4,14h8v2H4Z"/></svg>',
  cowboy: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#1b0d04" d="M5,3h6v1H5ZM4,4h8v4H4ZM1,9h14v2H1Z"/><path fill="#783808" d="M5,3h6v1H5ZM1,10h14v1H1ZM0,8h2v2H0ZM14,8h2v2H14Z"/><path fill="#542807" d="M4,5h8v3H4Z"/><path fill="#3b1c05" d="M6,4h4v1H6Z"/><path fill="#ffd166" d="M4,8h8v1H4Z"/></svg>',
  bandana: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#780000" d="M2,3h12v3H2ZM7,12h2v2H7ZM1,3h2v2H1ZM13,3h2v2H13Z"/><path fill="#c1121f" d="M2,4h12v2H2ZM3,6h10v3H3ZM5,9h6v3H5Z"/><path fill="#ffffff" d="M4,4h2v1H4ZM9,5h2v1H9ZM6,7h2v1H6Z"/></svg>',
  cap: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#1d3557" d="M4,3h8v1H4ZM3,4h10v4H3ZM1,8h14v2H1Z"/><path fill="#f1faee" d="M4,4h6v4H4Z"/><path fill="#457b9d" d="M0,9h6v2H0Z"/><path fill="#e63946" d="M6,2h2v1H6Z"/></svg>',
  bare: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#2b170a" d="M5,2h6v1H5Z"/><path fill="#e09f3e" d="M4,3h8v6H4Z"/><path fill="#542807" d="M5,3h6v2H5Z"/><path fill="#c9873c" d="M6,9h4v2H6Z"/><path fill="#8f5624" d="M3,11h10v4H3Z"/></svg>',
  star: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#ffd166" d="M7,1h2v3H7ZM5,4h6v3H5ZM1,6h14v3H1ZM4,9h8v3H4ZM2,12h4v3H2Z"/><path fill="#e09f3e" d="M10,12h4v3H10Z"/><path fill="#ffffff" d="M7,2h2v8H7ZM6,7h4v2H6Z"/></svg>',
  star_empty: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#8f5624" d="M7,1h2v1H7ZM6,2h1v2H6ZM9,2h1v2H9ZM1,6h5v1H1ZM10,6h5v1H10ZM2,7h2v1H2ZM12,7h2v1H12ZM4,9h2v1H4ZM10,9h2v1H10ZM2,14h3v1H2ZM11,14h3v1H11ZM5,12h2v1H5ZM9,12h2v1H9ZM7,10h2v1H7Z"/><path fill="#1c0e06" d="M5,6h6v4H5Z"/></svg>',
  crown: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#ffe6a7" d="M2,4h2v2H2ZM12,4h2v2H12Z"/><path fill="#ffffff" d="M7,2h2v2H7Z"/><path fill="#ffd166" d="M2,6h12v6H2Z"/><path fill="#c9873c" d="M1,12h14v2H1Z"/><path fill="#8f5624" d="M3,12h10v2H3Z"/><path fill="#e63946" d="M7,8h2v2H7Z"/><path fill="#00bbf9" d="M4,9h1v1H4ZM11,9h1v1H11Z"/></svg>',
  target: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#140803" d="M5,1h6v1H5ZM11,2h3v1H11ZM14,5h1v6H14ZM11,13h3v1H11ZM5,14h6v1H5ZM2,11h3v1H2ZM1,5h1v6H1ZM2,2h3v1H2ZM7,0h2v3H7ZM7,13h2v3H7ZM0,7h3v2H0ZM13,7h3v2H13Z"/><path fill="#e63946" d="M5,2h6v2H5ZM11,3h2v3H11ZM12,5h2v6H12ZM11,10h2v3H11ZM5,12h6v2H5ZM3,10h2v3H3ZM2,5h2v6H2ZM3,3h2v3H3ZM6,6h4v4H6Z"/><path fill="#ffffff" d="M5,4h6v8H5ZM4,5h8v6H4Z"/><path fill="#ffd166" d="M7,7h2v2H7Z"/></svg>',
  trash: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#475569" d="M5,2h6v1H5ZM4,5h8v9H4Z"/><path fill="#64748b" d="M3,3h10v2H3Z"/><path fill="#334155" d="M5,6h1v7H5ZM7,6h2v7H7ZM10,6h1v7H10Z"/><path fill="#1e293b" d="M3,14h10v1H3Z"/></svg>',
  plus: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#140803" d="M6,2h4v12H6ZM2,6h12v4H2Z"/><path fill="#ffd166" d="M7,3h2v10H7ZM3,7h10v2H3Z"/><path fill="#ffe6a7" d="M7,3h1v10H7ZM3,7h10v1H3Z"/></svg>',
  restart: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#ffd166" d="M5,2h6v2H5ZM3,4h2v4H3ZM11,4h2v3H11ZM10,2h4v4H10Z"/><path fill="#c9873c" d="M2,8h2v4H2ZM12,7h2v5H12ZM4,12h8v2H4Z"/><path fill="#ffe6a7" d="M11,1h2v2H11Z"/></svg>',
  home: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#4a2810" d="M10,3h2v3H10Z"/><path fill="#ffd166" d="M7,1h2v2H7ZM5,3h6v2H5Z"/><path fill="#c9873c" d="M3,5h10v2H3Z"/><path fill="#542807" d="M1,7h14v2H1Z"/><path fill="#8f5624" d="M3,9h10v6H3Z"/><path fill="#241005" d="M6,11h4v4H6Z"/></svg>',
  revolver: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#94a3b8" d="M6,5h8v2H6ZM5,10h1v1H5Z"/><path fill="#475569" d="M12,4h2v1H12ZM5,5h3v4H5Z"/><path fill="#cbd5e1" d="M6,6h1v2H6Z"/><path fill="#8f5624" d="M2,8h3v5H2Z"/><path fill="#c9873c" d="M3,8h1v4H3Z"/><path fill="#64748b" d="M4,9h2v2H4Z"/></svg>',
  dual: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#94a3b8" d="M1,4h6v2H1ZM9,4h6v2H9Z"/><path fill="#8f5624" d="M1,6h2v4H1ZM13,6h2v4H13Z"/><path fill="#ffd166" d="M7,7h2v2H7Z"/></svg>',
  shotgun: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#8f5624" d="M1,9h5v4H1Z"/><path fill="#334155" d="M6,7h2v3H6Z"/><path fill="#94a3b8" d="M8,5h7v2H8Z"/><path fill="#c9873c" d="M6,8h3v2H6Z"/><path fill="#cbd5e1" d="M14,4h1v1H14Z"/></svg>',
  fire: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#542807" d="M3,8h10v7H3Z"/><path fill="#8f5624" d="M7,6h2v9H7Z"/><path fill="#ff0054" d="M6,2h4v4H6Z"/><path fill="#ffbe0b" d="M7,3h2v3H7Z"/><path fill="#ffffff" d="M7,4h2v2H7Z"/><path fill="#fb5607" d="M5,4h2v2H5Z"/></svg>',
  laser: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#3a0ca3" d="M2,6h12v3H2Z"/><path fill="#4cc9f0" d="M10,5h4v2H10Z"/><path fill="#00f5d4" d="M12,6h3v1H12Z"/><path fill="#1b0e06" d="M4,9h3v4H4Z"/><path fill="#7209b7" d="M6,7h3v2H6Z"/></svg>',
  thunder: '<svg viewBox="0 0 16 16" width="100%" height="100%" shape-rendering="crispEdges"><path fill="#ffd166" d="M8,1h4v2H8ZM7,3h4v3H7ZM5,6h7v2H5ZM4,8h6v2H4ZM3,10h4v3H3ZM2,13h2v2H2Z"/><path fill="#ffffff" d="M7,2h2v5H7ZM5,7h2v3H5Z"/></svg>'
};

function getPixelIcon(name, size = 16) {
  const svg = PIXEL_ICONS[name] || PIXEL_ICONS.star;
  return `<span class="px-icon" style="width:${size}px; height:${size}px;">${svg}</span>`;
}

function renderPixelStars(count) {
  let s = '';
  for (let i = 1; i <= 3; i++) {
    s += i <= count ? getPixelIcon('star', 12) : getPixelIcon('star_empty', 12);
  }
  return s;
}

// Dedicated 16x16 Offscreen Canvas Pixel Art Drop Spritesheet for 60 FPS mobile performance
const DropSpriteSheet = {
  coinFrames: [],
  bossCoinFrames: [],
  shieldCanvas: null,
  speedCanvas: null,
  heartCanvas: null,
  spreadCanvas: null,

  createCanvas(w = 16, h = 16) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    return { canvas: c, ctx };
  },

  init() {
    this.coinFrames = [
      this.drawCoin(0, false),
      this.drawCoin(1, false),
      this.drawCoin(2, false),
      this.drawCoin(3, false)
    ];
    this.bossCoinFrames = [
      this.drawCoin(0, true),
      this.drawCoin(1, true),
      this.drawCoin(2, true),
      this.drawCoin(3, true)
    ];
    this.shieldCanvas = this.drawShield();
    this.speedCanvas = this.drawSpeed();
    this.heartCanvas = this.drawHeart();
    this.spreadCanvas = this.drawSpread();
  },

  drawCoin(frame, isBoss) {
    const { canvas, ctx } = this.createCanvas(16, 16);
    if (isBoss) {
      // Sparkling white aura for magnetic boss coins
      ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
      ctx.fillRect(2, 2, 12, 12);
    }

    if (frame === 0) {
      // Front full face
      ctx.fillStyle = '#2b1404'; ctx.fillRect(4, 2, 8, 12); ctx.fillRect(2, 4, 12, 8);
      ctx.fillStyle = '#8f5624'; ctx.fillRect(4, 3, 8, 10); ctx.fillRect(3, 4, 10, 8);
      ctx.fillStyle = '#ffd166'; ctx.fillRect(4, 4, 8, 8);
      ctx.fillStyle = '#e09f3e'; ctx.fillRect(5, 5, 6, 6);
      // 4-pixel carved star in center
      ctx.fillStyle = '#fff9db'; ctx.fillRect(7, 5, 2, 6); ctx.fillRect(5, 7, 6, 2);
      ctx.fillStyle = '#8f5624'; ctx.fillRect(7, 7, 2, 2);
      // Brilliant light glint
      ctx.fillStyle = '#ffffff'; ctx.fillRect(4, 3, 2, 2);
    } else if (frame === 1) {
      // 3/4 turn
      ctx.fillStyle = '#2b1404'; ctx.fillRect(5, 2, 6, 12); ctx.fillRect(4, 4, 8, 8);
      ctx.fillStyle = '#8f5624'; ctx.fillRect(5, 3, 6, 10); ctx.fillRect(10, 4, 2, 8); // Thickness edge
      ctx.fillStyle = '#ffd166'; ctx.fillRect(5, 4, 5, 8);
      ctx.fillStyle = '#e09f3e'; ctx.fillRect(6, 5, 3, 6);
      ctx.fillStyle = '#fff9db'; ctx.fillRect(7, 6, 2, 4);
      ctx.fillStyle = '#ffffff'; ctx.fillRect(5, 3, 2, 2);
    } else if (frame === 2) {
      // Edge-on side
      ctx.fillStyle = '#2b1404'; ctx.fillRect(6, 2, 4, 12);
      ctx.fillStyle = '#8f5624'; ctx.fillRect(6, 3, 4, 10);
      ctx.fillStyle = '#ffd166'; ctx.fillRect(7, 3, 2, 10);
      ctx.fillStyle = '#ffffff'; ctx.fillRect(7, 6, 2, 4);
    } else {
      // 3/4 reverse
      ctx.fillStyle = '#2b1404'; ctx.fillRect(5, 2, 6, 12); ctx.fillRect(4, 4, 8, 8);
      ctx.fillStyle = '#8f5624'; ctx.fillRect(5, 3, 6, 10); ctx.fillRect(4, 4, 2, 8); // Thickness edge
      ctx.fillStyle = '#ffd166'; ctx.fillRect(6, 4, 5, 8);
      ctx.fillStyle = '#e09f3e'; ctx.fillRect(7, 5, 3, 6);
      ctx.fillStyle = '#fff9db'; ctx.fillRect(7, 6, 2, 4);
      ctx.fillStyle = '#ffffff'; ctx.fillRect(8, 3, 2, 2);
    }
    return canvas;
  },

  drawShield() {
    const { canvas, ctx } = this.createCanvas(16, 16);
    // Dark outline
    ctx.fillStyle = '#120904';
    ctx.fillRect(2, 1, 12, 1); ctx.fillRect(1, 2, 14, 7);
    ctx.fillRect(2, 9, 12, 2); ctx.fillRect(3, 11, 10, 2);
    ctx.fillRect(5, 13, 6, 1); ctx.fillRect(6, 14, 4, 1); ctx.fillRect(7, 15, 2, 1);

    // Bronze reinforced rim
    ctx.fillStyle = '#8f5624';
    ctx.fillRect(2, 2, 12, 1); ctx.fillRect(2, 3, 2, 6); ctx.fillRect(12, 3, 2, 6);
    ctx.fillRect(3, 9, 2, 2); ctx.fillRect(11, 9, 2, 2);
    ctx.fillRect(4, 11, 2, 1); ctx.fillRect(10, 11, 2, 1);

    // Inner steel plate
    ctx.fillStyle = '#3a4454';
    ctx.fillRect(4, 3, 8, 6); ctx.fillRect(4, 9, 8, 1);
    ctx.fillRect(5, 10, 6, 2); ctx.fillRect(6, 12, 4, 1); ctx.fillRect(7, 13, 2, 1);

    // Diagonal metallic highlight
    ctx.fillStyle = '#708090';
    ctx.fillRect(5, 3, 2, 3); ctx.fillRect(7, 5, 2, 3); ctx.fillRect(9, 7, 2, 2);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(6, 3, 1, 2); ctx.fillRect(8, 5, 1, 2);

    // Corner rivets
    ctx.fillStyle = '#ffd166';
    ctx.fillRect(3, 3, 1, 1); ctx.fillRect(12, 3, 1, 1); ctx.fillRect(7, 13, 2, 1);

    // Glowing cyan gem/cross
    ctx.fillStyle = '#0077b6'; ctx.fillRect(7, 4, 2, 6); ctx.fillRect(5, 6, 6, 2);
    ctx.fillStyle = '#00bbf9'; ctx.fillRect(7, 5, 2, 4); ctx.fillRect(6, 6, 4, 2);
    ctx.fillStyle = '#00f5d4'; ctx.fillRect(7, 6, 2, 2);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(7, 5, 2, 1);
    return canvas;
  },

  drawSpeed() {
    const { canvas, ctx } = this.createCanvas(16, 16);
    // Dark outline
    ctx.fillStyle = '#140803';
    ctx.fillRect(4, 2, 6, 1); ctx.fillRect(3, 3, 1, 8); ctx.fillRect(10, 3, 1, 5);
    ctx.fillRect(11, 8, 3, 1); ctx.fillRect(14, 9, 2, 3); ctx.fillRect(2, 11, 1, 3);
    ctx.fillRect(3, 14, 12, 1);

    // Rich leather boot
    ctx.fillStyle = '#8f4614';
    ctx.fillRect(4, 4, 6, 6); ctx.fillRect(4, 8, 7, 2); ctx.fillRect(4, 10, 10, 2);
    ctx.fillStyle = '#5a2d0c'; ctx.fillRect(3, 12, 11, 2); // Sole
    ctx.fillStyle = '#e09443'; ctx.fillRect(4, 3, 6, 1); // Collar highlight
    ctx.fillStyle = '#ba6a28'; ctx.fillRect(5, 4, 1, 6); // Fold
    ctx.fillStyle = '#c86d26'; ctx.fillRect(6, 10, 6, 1);

    // Golden spur on heel
    ctx.fillStyle = '#ffd166'; ctx.fillRect(1, 11, 2, 2);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 12, 2, 1);

    // Wing feathers on heel
    ctx.fillStyle = '#a0c4ff'; ctx.fillRect(1, 6, 3, 3);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(2, 7, 2, 1);
    return canvas;
  },

  drawHeart() {
    const { canvas, ctx } = this.createCanvas(16, 16);
    // Wood cork on top
    ctx.fillStyle = '#5c3516'; ctx.fillRect(6, 1, 4, 2);
    ctx.fillStyle = '#9c6634'; ctx.fillRect(7, 1, 2, 2);
    ctx.fillStyle = '#d49a44'; ctx.fillRect(7, 1, 1, 2);

    // Flask glass & ruby contour
    ctx.fillStyle = '#0a0402';
    ctx.fillRect(5, 3, 6, 1); ctx.fillRect(4, 4, 8, 1);
    ctx.fillRect(3, 5, 10, 6); ctx.fillRect(4, 11, 8, 2);
    ctx.fillRect(5, 13, 6, 1); ctx.fillRect(7, 14, 2, 1);

    // Ruby liquid
    ctx.fillStyle = '#e63946';
    ctx.fillRect(4, 5, 8, 5); ctx.fillRect(5, 10, 6, 2); ctx.fillRect(6, 12, 4, 1);
    ctx.fillStyle = '#780000'; // Deep crimson shadow
    ctx.fillRect(8, 6, 4, 4); ctx.fillRect(7, 10, 4, 2);

    // Glass curve highlight
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(4, 5, 2, 2); ctx.fillRect(3, 6, 1, 3);
    ctx.fillStyle = '#ffb3c1'; ctx.fillRect(5, 6, 2, 1);
    return canvas;
  },

  drawSpread() {
    const { canvas, ctx } = this.createCanvas(16, 16);
    // Left cartridge
    ctx.fillStyle = '#800e13'; ctx.fillRect(2, 6, 3, 7);
    ctx.fillStyle = '#e63946'; ctx.fillRect(3, 5, 2, 2);
    ctx.fillStyle = '#ffd166'; ctx.fillRect(2, 13, 3, 2);
    // Center cartridge
    ctx.fillStyle = '#c1121f'; ctx.fillRect(6, 4, 4, 8);
    ctx.fillStyle = '#ff4d6d'; ctx.fillRect(7, 2, 2, 3);
    ctx.fillStyle = '#ffd166'; ctx.fillRect(6, 12, 4, 3);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(7, 4, 1, 8);
    // Right cartridge
    ctx.fillStyle = '#800e13'; ctx.fillRect(11, 6, 3, 7);
    ctx.fillStyle = '#e63946'; ctx.fillRect(11, 5, 2, 2);
    ctx.fillStyle = '#ffd166'; ctx.fillRect(11, 13, 3, 2);
    // Sparks
    ctx.fillStyle = '#ffba08'; ctx.fillRect(1, 2, 2, 2); ctx.fillRect(13, 2, 2, 2);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(7, 0, 2, 2);
    return canvas;
  }
};
"""

achs_anchor = "const ACHS = ["
assert achs_anchor in html, "achs_anchor not found"
html = html.replace(achs_anchor, js_lib_injection + "\n" + achs_anchor, 1)

# ==========================================
# 10. ACHS ARRAY UPDATE (remove emojis)
# ==========================================
old_achs_block = """const ACHS = [
  {
    id: 'first_blood',
    title: 'Primeiro Sangue',
    desc: 'Abater 25 Cactos no deserto.',
    icon: '🌵',
    target: 25,
    getCur: () => lifetimeKills
  },
  {
    id: 'desert_gunslinger',
    title: 'Pistoleiro do Deserto',
    desc: 'Abater 250 Cactos.',
    icon: '🤠',
    target: 250,
    getCur: () => lifetimeKills
  },
  {
    id: 'flora_terror',
    title: 'Terror da Flora Alienígena',
    desc: 'Abater 1.000 Cactos.',
    icon: '💀',
    target: 1000,
    getCur: () => lifetimeKills
  },
  {
    id: 'survivor_10',
    title: 'Sobrevivente Tenaz',
    desc: 'Chegar à Rodada 10.',
    icon: '⭐',
    target: 10,
    getCur: () => maxWave
  },
  {
    id: 'prairie_legend',
    title: 'Lenda da Pradaria',
    desc: 'Chegar à Rodada 25.',
    icon: '👑',
    target: 25,
    getCur: () => maxWave
  },
  {
    id: 'titan_hunter',
    title: 'Caçador de Titãs',
    desc: 'Derrotar 3 Chefes Cactos.',
    icon: '🏆',
    target: 3,
    getCur: () => bossesDefeated
  },
  {
    id: 'coin_tycoon',
    title: 'Magnata das Moedas',
    desc: 'Acumular 150 moedas em uma partida.',
    icon: '🪙',
    target: 150,
    getCur: () => maxCoinsSingleMatch
  },
  {
    id: 'full_arsenal',
    title: 'Arsenal Completo',
    desc: 'Comprar todas as 5 armas da loja.',
    icon: '🔫',
    target: 5,
    getCur: () => Object.keys(lifetimeWeaponsUnlocked).length
  }
];"""

new_achs_block = """const ACHS = [
  {
    id: 'first_blood',
    title: 'Primeiro Sangue',
    desc: 'Abater 25 Cactos no deserto.',
    icon: 'cactus',
    target: 25,
    getCur: () => lifetimeKills
  },
  {
    id: 'desert_gunslinger',
    title: 'Pistoleiro do Deserto',
    desc: 'Abater 250 Cactos.',
    icon: 'cowboy',
    target: 250,
    getCur: () => lifetimeKills
  },
  {
    id: 'flora_terror',
    title: 'Terror da Flora Alienígena',
    desc: 'Abater 1.000 Cactos.',
    icon: 'skull',
    target: 1000,
    getCur: () => lifetimeKills
  },
  {
    id: 'survivor_10',
    title: 'Sobrevivente Tenaz',
    desc: 'Chegar à Rodada 10.',
    icon: 'star',
    target: 10,
    getCur: () => maxWave
  },
  {
    id: 'prairie_legend',
    title: 'Lenda da Pradaria',
    desc: 'Chegar à Rodada 25.',
    icon: 'crown',
    target: 25,
    getCur: () => maxWave
  },
  {
    id: 'titan_hunter',
    title: 'Caçador de Titãs',
    desc: 'Derrotar 3 Chefes Cactos.',
    icon: 'trophy',
    target: 3,
    getCur: () => bossesDefeated
  },
  {
    id: 'coin_tycoon',
    title: 'Magnata das Moedas',
    desc: 'Acumular 150 moedas em uma partida.',
    icon: 'coin',
    target: 150,
    getCur: () => maxCoinsSingleMatch
  },
  {
    id: 'full_arsenal',
    title: 'Arsenal Completo',
    desc: 'Comprar todas as 5 armas da loja.',
    icon: 'revolver',
    target: 5,
    getCur: () => Object.keys(lifetimeWeaponsUnlocked).length
  }
];"""
assert old_achs_block in html, "old_achs_block not found"
html = html.replace(old_achs_block, new_achs_block, 1)

# Toast in checkAchievements()
toast_text_target = "document.getElementById('ach-txt').textContent = `${a.icon} ${a.title}!`;"
toast_text_replacement = "document.getElementById('ach-txt').innerHTML = `${getPixelIcon(a.icon, 16)} ${a.title}!`;"
assert toast_text_target in html, "toast_text_target not found"
html = html.replace(toast_text_target, toast_text_replacement, 1)

# renderAchModal() icon rendering
ach_icon_target = '<div class="ach-icon">${a.icon}</div>'
ach_icon_replacement = '<div class="ach-icon">${getPixelIcon(a.icon, 24)}</div>'
assert ach_icon_target in html, "ach_icon_target not found"
html = html.replace(ach_icon_target, ach_icon_replacement, 1)

# ==========================================
# 11. WEAPON_DATA (remove emojis & star characters)
# ==========================================
old_weapon_data = """const WEAPON_DATA = {
  revolver: {
    id: 'revolver',
    name: 'Revólver Enferrujado',
    icon: '🔫',
    basePrice: 0,
    levels: {
      1: { cost: 0, stars: '★☆☆', title: 'Nível 1', desc: 'Cadência 1.0x | Alcance limitado', interval: 0.18, speed: 310, dmg: 1, life: 0.46, pierce: 1 },
      2: { cost: 10, stars: '★★☆', title: 'Nível 2', desc: 'Cadência 1.0x | Projétil cruza arena inteira', interval: 0.18, speed: 350, dmg: 1.2, life: 1.5, pierce: 1 },
      3: { cost: 20, stars: '★★★ MAX', title: 'Nível MAX', desc: 'Cadência 1.25x | Projétil veloz por toda arena', interval: 0.144, speed: 420, dmg: 1.5, life: 1.5, pierce: 1 }
    }
  },
  dual: {
    id: 'dual',
    name: 'Pistolas Duplas',
    icon: '⚡',
    basePrice: 25,
    levels: {
      1: { cost: 0, stars: '★☆☆', title: 'Nível 1', desc: 'Cadência 1.3x | Tiros alternados entre as mãos', interval: 0.14, speed: 360, dmg: 1.2, life: 1.3, pierce: 1 },
      2: { cost: 25, stars: '★★☆', title: 'Nível 2', desc: 'Cadência 1.3x | Dispara ambas as armas juntas', interval: 0.14, speed: 380, dmg: 1.4, life: 1.3, pierce: 1 },
      3: { cost: 40, stars: '★★★ MAX', title: 'Nível MAX', desc: 'Cadência 1.6x furiosa | Ambas as armas juntas', interval: 0.11, speed: 420, dmg: 1.8, life: 1.3, pierce: 1 }
    }
  },
  shotgun: {
    id: 'shotgun',
    name: 'Espingarda / Shotgun',
    icon: '💥',
    basePrice: 50,
    levels: {
      1: { cost: 0, stars: '★☆☆', title: 'Nível 1', desc: '3 balotes em leque | Recuo moderado', interval: 0.28, speed: 310, dmg: 2, spread: [-0.28, 0, 0.28], recoil: 3.5, pierce: 1 },
      2: { cost: 35, stars: '★★☆', title: 'Nível 2', desc: '4 balotes concentrados | Recuo reduzido', interval: 0.26, speed: 340, dmg: 2.2, spread: [-0.18, -0.06, 0.06, 0.18], recoil: 2.0, pierce: 1 },
      3: { cost: 50, stars: '★★★ MAX', title: 'Nível MAX', desc: '5 balotes | Chance de perfurar o primeiro cacto', interval: 0.24, speed: 360, dmg: 2.5, spread: [-0.22, -0.11, 0, 0.11, 0.22], recoil: 1.5, pierce: 2 }
    }
  },
  fire: {
    id: 'fire',
    name: 'Cajado Ígneo',
    icon: '🔥',
    basePrice: 80,
    levels: {
      1: { cost: 0, stars: '★☆☆', title: 'Nível 1', desc: 'Esfera lenta | Explosão em raio pequeno', interval: 0.24, speed: 230, dmg: 4, aoe: 24, pierce: 2, leavesFire: false },
      2: { cost: 50, stars: '★★☆', title: 'Nível 2', desc: 'Velocidade aumentada | Raio de explosão +50%', interval: 0.22, speed: 320, dmg: 5, aoe: 36, pierce: 2, leavesFire: false },
      3: { cost: 70, stars: '★★★ MAX', title: 'Nível MAX', desc: 'Explosão devastadora | Chão em chamas por 2s', interval: 0.20, speed: 350, dmg: 6, aoe: 42, pierce: 2, leavesFire: true }
    }
  },
  laser: {
    id: 'laser',
    name: 'Canhão Laser Alienígena',
    icon: '🔮',
    basePrice: 120,
    levels: {
      1: { cost: 0, stars: '★☆☆', title: 'Nível 1', desc: 'Feixe rápido contínuo perfurando 2 inimigos', interval: 0.12, speed: 560, dmg: 4, pierce: 2, beamWidth: 3, doubleBeam: false },
      2: { cost: 80, stars: '★★☆', title: 'Nível 2', desc: 'Feixe espesso perfurando todos os inimigos da linha', interval: 0.11, speed: 600, dmg: 5.5, pierce: 999, beamWidth: 6, doubleBeam: false },
      3: { cost: 100, stars: '★★★ MAX', title: 'Nível MAX', desc: 'Disparo laser duplo perfurante devastador', interval: 0.09, speed: 640, dmg: 6.5, pierce: 999, beamWidth: 5, doubleBeam: true }
    }
  }
};"""

new_weapon_data = """const WEAPON_DATA = {
  revolver: {
    id: 'revolver',
    name: 'Revólver Enferrujado',
    icon: 'revolver',
    basePrice: 0,
    levels: {
      1: { cost: 0, starLevel: 1, title: 'Nível 1', desc: 'Cadência 1.0x | Alcance limitado', interval: 0.18, speed: 310, dmg: 1, life: 0.46, pierce: 1 },
      2: { cost: 10, starLevel: 2, title: 'Nível 2', desc: 'Cadência 1.0x | Projétil cruza arena inteira', interval: 0.18, speed: 350, dmg: 1.2, life: 1.5, pierce: 1 },
      3: { cost: 20, starLevel: 3, title: 'Nível MAX', desc: 'Cadência 1.25x | Projétil veloz por toda arena', interval: 0.144, speed: 420, dmg: 1.5, life: 1.5, pierce: 1 }
    }
  },
  dual: {
    id: 'dual',
    name: 'Pistolas Duplas',
    icon: 'dual',
    basePrice: 25,
    levels: {
      1: { cost: 0, starLevel: 1, title: 'Nível 1', desc: 'Cadência 1.3x | Tiros alternados entre as mãos', interval: 0.14, speed: 360, dmg: 1.2, life: 1.3, pierce: 1 },
      2: { cost: 25, starLevel: 2, title: 'Nível 2', desc: 'Cadência 1.3x | Dispara ambas as armas juntas', interval: 0.14, speed: 380, dmg: 1.4, life: 1.3, pierce: 1 },
      3: { cost: 40, starLevel: 3, title: 'Nível MAX', desc: 'Cadência 1.6x furiosa | Ambas as armas juntas', interval: 0.11, speed: 420, dmg: 1.8, life: 1.3, pierce: 1 }
    }
  },
  shotgun: {
    id: 'shotgun',
    name: 'Espingarda / Shotgun',
    icon: 'shotgun',
    basePrice: 50,
    levels: {
      1: { cost: 0, starLevel: 1, title: 'Nível 1', desc: '3 balotes em leque | Recuo moderado', interval: 0.28, speed: 310, dmg: 2, spread: [-0.28, 0, 0.28], recoil: 3.5, pierce: 1 },
      2: { cost: 35, starLevel: 2, title: 'Nível 2', desc: '4 balotes concentrados | Recuo reduzido', interval: 0.26, speed: 340, dmg: 2.2, spread: [-0.18, -0.06, 0.06, 0.18], recoil: 2.0, pierce: 1 },
      3: { cost: 50, starLevel: 3, title: 'Nível MAX', desc: '5 balotes | Chance de perfurar o primeiro cacto', interval: 0.24, speed: 360, dmg: 2.5, spread: [-0.22, -0.11, 0, 0.11, 0.22], recoil: 1.5, pierce: 2 }
    }
  },
  fire: {
    id: 'fire',
    name: 'Cajado Ígneo',
    icon: 'fire',
    basePrice: 80,
    levels: {
      1: { cost: 0, starLevel: 1, title: 'Nível 1', desc: 'Esfera lenta | Explosão em raio pequeno', interval: 0.24, speed: 230, dmg: 4, aoe: 24, pierce: 2, leavesFire: false },
      2: { cost: 50, starLevel: 2, title: 'Nível 2', desc: 'Velocidade aumentada | Raio de explosão +50%', interval: 0.22, speed: 320, dmg: 5, aoe: 36, pierce: 2, leavesFire: false },
      3: { cost: 70, starLevel: 3, title: 'Nível MAX', desc: 'Explosão devastadora | Chão em chamas por 2s', interval: 0.20, speed: 350, dmg: 6, aoe: 42, pierce: 2, leavesFire: true }
    }
  },
  laser: {
    id: 'laser',
    name: 'Canhão Laser Alienígena',
    icon: 'laser',
    basePrice: 120,
    levels: {
      1: { cost: 0, starLevel: 1, title: 'Nível 1', desc: 'Feixe rápido contínuo perfurando 2 inimigos', interval: 0.12, speed: 560, dmg: 4, pierce: 2, beamWidth: 3, doubleBeam: false },
      2: { cost: 80, starLevel: 2, title: 'Nível 2', desc: 'Feixe espesso perfurando todos os inimigos da linha', interval: 0.11, speed: 600, dmg: 5.5, pierce: 999, beamWidth: 6, doubleBeam: false },
      3: { cost: 100, starLevel: 3, title: 'Nível MAX', desc: 'Disparo laser duplo perfurante devastador', interval: 0.09, speed: 640, dmg: 6.5, pierce: 999, beamWidth: 5, doubleBeam: true }
    }
  }
};"""
assert old_weapon_data in html, "old_weapon_data not found"
html = html.replace(old_weapon_data, new_weapon_data, 1)

# ==========================================
# 12. RENDER SHOP UPDATES
# ==========================================
shop_upgrade_btn_target = """      <button id="btn-shop-upgrade" class="shop-upgrade-btn" ${canAfford ? '' : 'disabled'}>
        ⚡ MELHORAR ARMA ATUAL (${nextCfg.cost} 🪙)
      </button>"""

shop_upgrade_btn_replacement = """      <button id="btn-shop-upgrade" class="shop-upgrade-btn" ${canAfford ? '' : 'disabled'}>
        ${getPixelIcon('thunder', 14)} MELHORAR ARMA ATUAL (${nextCfg.cost} ${getPixelIcon('coin', 14)})
      </button>"""
assert shop_upgrade_btn_target in html, "shop_upgrade_btn_target not found"
html = html.replace(shop_upgrade_btn_target, shop_upgrade_btn_replacement, 1)

shop_max_target = '<div class="shop-max-tag">⭐ NÍVEL MÁXIMO ALCANÇADO (PODER SUPREMO) ⭐</div>'
shop_max_replacement = '<div class="shop-max-tag">${getPixelIcon(\'star\', 14)} NÍVEL MÁXIMO ALCANÇADO (PODER SUPREMO) ${getPixelIcon(\'star\', 14)}</div>'
assert shop_max_target in html, "shop_max_target not found"
html = html.replace(shop_max_target, shop_max_replacement, 1)

shop_header_target = """      <div class="shop-featured-header">
        <div style="font-size:14px; font-weight:bold; color:#ffd166;">
          ${wDef.icon} ${wDef.name}
        </div>
        <div class="shop-stars">${curCfg.stars}</div>
      </div>"""

shop_header_replacement = """      <div class="shop-featured-header">
        <div style="font-size:14px; font-weight:bold; color:#ffd166; display:flex; align-items:center; gap:6px;">
          ${getPixelIcon(wDef.id, 20)} ${wDef.name}
        </div>
        <div class="shop-stars">${renderPixelStars(curCfg.starLevel || curLvl)}</div>
      </div>"""
assert shop_header_target in html, "shop_header_target not found"
html = html.replace(shop_header_target, shop_header_replacement, 1)

shop_buy_btn_target = "actionBtnHtml = `<button class=\"btn-buy\" id=\"btn-buy-${w.id}\" ${canAfford ? '' : 'disabled'}>COMPRAR (${w.basePrice} 🪙)</button>`;"
shop_buy_btn_replacement = "actionBtnHtml = `<button class=\"btn-buy\" id=\"btn-buy-${w.id}\" ${canAfford ? '' : 'disabled'}>COMPRAR (${w.basePrice} ${getPixelIcon('coin', 14)})</button>`;"
assert shop_buy_btn_target in html, "shop_buy_btn_target not found"
html = html.replace(shop_buy_btn_target, shop_buy_btn_replacement, 1)

shop_card_title_target = '<div class="weapon-name">${w.icon} ${w.name} <span style="font-size:11px; color:#ffd166;">[${wCfg.stars}]</span></div>'
shop_card_title_replacement = '<div class="weapon-name" style="display:flex; align-items:center; gap:6px;">${getPixelIcon(w.id, 18)} ${w.name} <span class="shop-stars" style="margin-left:4px;">${renderPixelStars(wCfg.starLevel || wLvl)}</span></div>'
assert shop_card_title_target in html, "shop_card_title_target not found"
html = html.replace(shop_card_title_target, shop_card_title_replacement, 1)

# ==========================================
# 13. RENDER SAVE SLOTS UPDATES
# ==========================================
slots_title_target = '<span class="slot-title">SLOT ${id} - 🤠 ${data.hero ? data.hero.name : \'PISTOLEIRO\'}</span>'
slots_title_replacement = '<span class="slot-title" style="display:inline-flex; align-items:center; gap:5px;">SLOT ${id} - ${getPixelIcon(\'cowboy\', 14)} ${data.hero ? data.hero.name : \'PISTOLEIRO\'}</span>'
assert slots_title_target in html, "slots_title_target not found"
html = html.replace(slots_title_target, slots_title_replacement, 1)

slots_coins_target = '<div style="color:#ffd166; font-weight:bold; font-size:13px;">Onda ${data.wave} | 🪙 ${data.coins} Moedas</div>'
slots_coins_replacement = '<div style="color:#ffd166; font-weight:bold; font-size:13px; display:flex; align-items:center; gap:4px;">Onda ${data.wave} | ${getPixelIcon(\'coin\', 14)} ${data.coins} Moedas</div>'
assert slots_coins_target in html, "slots_coins_target not found"
html = html.replace(slots_coins_target, slots_coins_replacement, 1)

slots_stars_target = '<span style="color:#ffd166;">[${wCfg.stars}]</span>'
slots_stars_replacement = '<span class="shop-stars" style="margin-left:4px;">${renderPixelStars(wCfg.starLevel || wLvl)}</span>'
assert slots_stars_target in html, "slots_stars_target not found"
html = html.replace(slots_stars_target, slots_stars_replacement, 1)

slots_actions_target = """        <div class="slot-actions">
          <button class="btn-slot-load" id="btn-load-slot-${id}">▶ CONTINUAR</button>
          <button class="btn-slot-del" id="btn-del-slot-${id}">🗑 APAGAR</button>
        </div>"""
slots_actions_replacement = """        <div class="slot-actions">
          <button class="btn-slot-load" id="btn-load-slot-${id}">
            <svg class="px-icon px-play-sm" viewBox="0 0 16 16" width="13" height="13" shape-rendering="crispEdges" style="margin-right:4px;">
              <path fill="#140803" d="M3,2h2v12H3ZM5,3h2v10H5ZM7,4h2v8H7ZM9,5h2v6H9ZM11,6h2v4H11ZM13,7h2v2H13Z"/>
              <path fill="#ffe6a7" d="M4,3h1v10H4Z"/>
              <path fill="#ffd166" d="M5,4h2v8H5ZM7,5h2v6H7Z"/>
              <path fill="#e09f3e" d="M9,6h2v4H9Z"/>
              <path fill="#c9873c" d="M11,7h2v2H11Z"/>
            </svg> CONTINUAR
          </button>
          <button class="btn-slot-del" id="btn-del-slot-${id}">
            <svg class="px-icon px-trash-sm" viewBox="0 0 16 16" width="13" height="13" shape-rendering="crispEdges" style="margin-right:4px;">
              <path fill="#475569" d="M5,2h6v1H5ZM4,5h8v9H4Z"/><path fill="#64748b" d="M3,3h10v2H3Z"/>
              <path fill="#334155" d="M5,6h1v7H5ZM7,6h2v7H7ZM10,6h1v7H10Z"/><path fill="#1e293b" d="M3,14h10v1H3Z"/>
            </svg> APAGAR
          </button>
        </div>"""
assert slots_actions_target in html, "slots_actions_target not found"
html = html.replace(slots_actions_target, slots_actions_replacement, 1)

slots_new_btn_target = '<button class="btn-slot-new" id="btn-new-slot-${id}">➕ INICIAR NOVO JOGO</button>'
slots_new_btn_replacement = """<button class="btn-slot-new" id="btn-new-slot-${id}">
            <svg class="px-icon px-plus-sm" viewBox="0 0 16 16" width="13" height="13" shape-rendering="crispEdges" style="margin-right:4px;">
              <path fill="#140803" d="M6,2h4v12H6ZM2,6h12v4H2Z"/><path fill="#ffd166" d="M7,3h2v10H7ZM3,7h10v2H3Z"/>
            </svg> INICIAR NOVO JOGO
          </button>"""
assert slots_new_btn_target in html, "slots_new_btn_target not found"
html = html.replace(slots_new_btn_target, slots_new_btn_replacement, 1)

# ==========================================
# 14. SOUND TOGGLE BUTTON
# ==========================================
sound_toggle_target = """bindFastClick(document.getElementById('btn-sound'), () => {
  sfx.muted = !sfx.muted;
  document.getElementById('btn-sound').textContent = sfx.muted ? '🔇' : '🔊';
});"""

sound_toggle_replacement = """bindFastClick(document.getElementById('btn-sound'), () => {
  sfx.muted = !sfx.muted;
  const sBtn = document.getElementById('btn-sound');
  if (sBtn) {
    sBtn.innerHTML = sfx.muted ? getPixelIcon('sound_off', 18) : getPixelIcon('sound_on', 18);
  }
});"""
assert sound_toggle_target in html, "sound_toggle_target not found"
html = html.replace(sound_toggle_target, sound_toggle_replacement, 1)

# ==========================================
# 15. UPDATE HEARTS SHIELD VISIBILITY
# ==========================================
update_hearts_target = """function updateHearts() {
  const maxL = player ? (player.maxLives || 5) : 5;
  const curL = player ? player.lives : 5;
  for (let i = 1; i <= maxL; i++) {
    const el = document.getElementById(`h-${i}`);
    if (el) {
      if (i <= curL) el.classList.remove('empty');
      else el.classList.add('empty');
    }
  }
}"""

update_hearts_replacement = """function updateHearts() {
  const maxL = player ? (player.maxLives || 5) : 5;
  const curL = player ? player.lives : 5;
  for (let i = 1; i <= maxL; i++) {
    const el = document.getElementById(`h-${i}`);
    if (el) {
      if (i <= curL) el.classList.remove('empty');
      else el.classList.add('empty');
    }
  }
  const shieldEl = document.getElementById('hud-shield-indicator');
  if (shieldEl) {
    shieldEl.style.display = (player && player.hasShield) ? 'inline-flex' : 'none';
  }
}"""
assert update_hearts_target in html, "update_hearts_target not found"
html = html.replace(update_hearts_target, update_hearts_replacement, 1)

# ==========================================
# 16. DROP CLASS DRAW LOGIC REWRITE
# ==========================================
old_drop_draw = """    if (this.type === 'coin') {
      c.fillStyle = '#ffd166'; c.beginPath(); c.arc(0, 0, 5, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#8a4b16'; c.fillRect(-1, -3, 2, 6);
      if (this.magnetic) {
        c.strokeStyle = '#ffffff';
        c.lineWidth = 1.2;
        c.beginPath(); c.arc(0, 0, 6.5, 0, Math.PI * 2); c.stroke();
      }
    } else if (this.type === 'speed') {
      c.fillStyle = '#ffd166'; c.fillRect(-4, -6, 8, 12);
    } else if (this.type === 'spread') {
      c.fillStyle = '#e63946'; c.fillRect(-4, -4, 8, 8);
    } else if (this.type === 'heart') {
      // 16-bit pixel art heart drop
      c.fillStyle = '#0a0402';
      c.fillRect(-4, -4, 3, 1); c.fillRect(1, -4, 3, 1);
      c.fillRect(-5, -3, 1, 3); c.fillRect(4, -3, 1, 3);
      c.fillRect(-1, -3, 2, 1);
      c.fillRect(-4, 0, 1, 1); c.fillRect(3, 0, 1, 1);
      c.fillRect(-3, 1, 1, 1); c.fillRect(2, 1, 1, 1);
      c.fillRect(-2, 2, 1, 1); c.fillRect(1, 2, 1, 1);
      c.fillRect(-1, 3, 2, 1);
      // Scarlet Fill
      c.fillStyle = '#e63946';
      c.fillRect(-4, -3, 8, 3);
      c.fillRect(-3, 0, 6, 1);
      c.fillRect(-2, 1, 4, 1);
      c.fillRect(-1, 2, 2, 1);
      // Crimson Shadow
      c.fillStyle = '#780000';
      c.fillRect(1, -1, 2, 1);
      c.fillRect(0, 0, 2, 1);
      c.fillRect(0, 1, 1, 1);
      // Top-Left Pixel Highlight
      c.fillStyle = '#ffffff';
      c.fillRect(-3, -3, 1, 2);
      c.fillStyle = '#ffb3c1';
      c.fillRect(-2, -3, 1, 1);
    } else if (this.type === 'shield') {
      // Ícone Pixel Art de Escudo / Broquel e Bolha Azul
      c.fillStyle = '#4cc9f0';
      c.beginPath(); c.arc(0, 0, 6, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#4361ee';
      c.beginPath(); c.arc(0, 0, 4, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#ffffff';
      c.fillRect(-2, -2, 4, 4);
    }"""

new_drop_draw = """    // 1. Soft grounded drop shadow for 3D depth
    c.fillStyle = 'rgba(20, 10, 4, 0.45)';
    c.beginPath();
    c.ellipse(0, 7, 7, 2.5, 0, 0, Math.PI * 2);
    c.fill();

    // 2. Offscreen Canvas Stamp rendering (Zero-CPU 60 FPS)
    const drawX = -8;
    const drawY = Math.round(-8);

    if (this.type === 'coin') {
      // 4-frame rotation animation with center star & highlight
      const frameIdx = Math.floor(this.anim * 2.2) % 4;
      const sheet = this.magnetic ? DropSpriteSheet.bossCoinFrames : DropSpriteSheet.coinFrames;
      const img = sheet[frameIdx] || sheet[0];
      if (img) c.drawImage(img, drawX, drawY);
    } else if (this.type === 'shield') {
      // Steel & Bronze Buckler with pulsing cyan aura
      const pulse = 0.5 + Math.sin(this.anim * 2) * 0.35;
      c.fillStyle = `rgba(0, 245, 212, ${pulse * 0.28})`;
      c.beginPath();
      c.arc(0, 0, 9.5, 0, Math.PI * 2);
      c.fill();
      if (DropSpriteSheet.shieldCanvas) c.drawImage(DropSpriteSheet.shieldCanvas, drawX, drawY);
    } else if (this.type === 'speed') {
      // Leather vaqueiro boot with golden spur and wing
      if (DropSpriteSheet.speedCanvas) c.drawImage(DropSpriteSheet.speedCanvas, drawX, drawY);
    } else if (this.type === 'heart') {
      // Ruby potion flask pulsing gently
      const hPulse = 1.0 + Math.sin(this.anim * 3.2) * 0.08;
      c.save();
      c.scale(hPulse, hPulse);
      if (DropSpriteSheet.heartCanvas) c.drawImage(DropSpriteSheet.heartCanvas, -8, -8);
      c.restore();
    } else if (this.type === 'spread') {
      // Triple shotgun shells with muzzle sparks
      if (DropSpriteSheet.spreadCanvas) c.drawImage(DropSpriteSheet.spreadCanvas, drawX, drawY);
    }"""
assert old_drop_draw in html, "old_drop_draw not found"
html = html.replace(old_drop_draw, new_drop_draw, 1)

# Initialize DropSpriteSheet at startup
init_target = "ajustarTela();"
init_replacement = "DropSpriteSheet.init();\najustarTela();"
assert init_target in html, "init_target not found"
html = html.replace(init_target, init_replacement, 1)

# ==========================================
# 17. BANNER & FLOATING TEXTS (remove emojis)
# ==========================================
duel_banner_target = "banner('⚔️ INÍCIO DO DUELO! ⚔️');"
duel_banner_replacement = "banner('INÍCIO DO DUELO!');"
assert duel_banner_target in html, "duel_banner_target not found"
html = html.replace(duel_banner_target, duel_banner_replacement, 1)

floating_coin_target = "floatingTexts.push(new FloatingText(d.x, d.y, '+1 🪙', '#ffd166'));"
floating_coin_replacement = "floatingTexts.push(new FloatingText(d.x, d.y, '+1 MOEDA', '#ffd166'));"
assert floating_coin_target in html, "floating_coin_target not found"
html = html.replace(floating_coin_target, floating_coin_replacement, 1)

# Check for any remaining emojis
emoji_pat = re.compile(r'[\U00010000-\U0010ffff\u2600-\u27bf\u2300-\u23ff\u2b50-\u2b55\u2700-\u27bf\u25a0-\u25ff]')
remaining = emoji_pat.findall(html)
print("Remaining emoji count:", len(remaining), set(remaining))

with open(INDEX_PATH, 'w', encoding='utf-8') as f:
    f.write(html)

print("Update completed successfully! New file size:", len(html))
