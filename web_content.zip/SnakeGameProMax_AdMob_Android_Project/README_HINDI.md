# Snake Game Pro Max — Android + AdMob source project

## इस ZIP में क्या है?
- आपकी उपलब्ध `snake_game_pro_max_admob.html` गेम फ़ाइल को Android assets में रखा गया है।
- Kotlin Android WebView wrapper और Native Google Mobile Ads SDK sample integration।
- Banner test ad और Rewarded test ad।
- Rewarded ad पूरा होने पर HTML गेम के मौजूदा Promise handler को `true` मिलता है; गेम तभी 50 coins देता है। Ad न मिले तो `false` मिलता है।
- GitHub Actions workflow ताकि Android मोबाइल से cloud में debug APK build कर सकें।

## ज़रूरी सीमा
`main.js` आपकी HTML में संदर्भित था, लेकिन अलग `main.js` फ़ाइल उपलब्ध नहीं थी। इसलिए उसकी script reference हटाई गई है। HTML के अंदर का game code मौजूद है। अगर आपका कोई जरूरी code उस अलग फ़ाइल में था, तो उसे भी assets में जोड़ना होगा।

## Android मोबाइल से APK बनाना
1. https://github.com/ पर account/sign in करें।
2. **New repository** बनाएँ, नाम `SnakeGameProMaxAdMob` रखें।
3. इस ZIP को फोन में डाउनलोड करके extract करें। Repository में ZIP के अंदर के सभी files/folders upload करें। `.github/workflows/build-apk.yml` भी upload होना चाहिए।
4. Repository के **Actions** tab में `Build Snake Game Pro Max APK` चुनें → **Run workflow** दबाएँ। पहली बार GitHub Actions enable करने का prompt आए तो enable करें।
5. Workflow green/successful होने पर run खोलें, नीचे **Artifacts** से `Snake-Game-Pro-Max-debug-apk` डाउनलोड करें। Artifact ZIP extract करके `app-debug.apk` install करें।
6. यदि build fail हो, Actions run में लाल error का screenshot या text भेजें।

## अभी Test Ads ही इस्तेमाल करें
इस source में Google के official sample IDs हैं:
- App ID: `ca-app-pub-3940256099942544~3347511713`
- Banner: `ca-app-pub-3940256099942544/9214589741`
- Rewarded: `ca-app-pub-3940256099942544/5224354917`
ये test IDs हैं, कमाई नहीं करते। खुद के live ads पर क्लिक न करें। Production से पहले अपना AdMob app बनाकर IDs बदलें और privacy/consent आवश्यकताएँ पूरी करें।

## Package / update नोट
Package name `com.rktechhub.snakegamepromax` है। मौजूदा APK को update की तरह install करने के लिए package name और signing key दोनों match होने चाहिए। इस workflow का debug APK आपकी पुरानी APK के signing key से match नहीं करेगा; इसलिए संभव है कि इसे अलग app की तरह install करना पड़े या पहले पुराना app uninstall करना पड़े। Uninstall करने से local game progress हट सकती है।

## SDK नोट
यह starter अभी legacy Google Mobile Ads SDK API (`play-services-ads:25.5.0`) का sample उपयोग करता है। Google ने GMA Next-Gen SDK को preferred SDK घोषित किया है। Public release से पहले official Next-Gen guide के अनुसार migration करें:
- https://developers.google.com/admob/android/next-gen/quick-start
- https://developers.google.com/admob/android/quick-start
- GitHub Actions: https://docs.github.com/en/actions
