package com.rktechhub.snakegamepromax

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var adView: AdView
    private var rewardedAd: RewardedAd? = null
    private var adsReady = false

    // Google's official test ad unit IDs. Do not click live ads during testing.
    private val bannerTestId = "ca-app-pub-3940256099942544/9214589741"
    private val rewardedTestId = "ca-app-pub-3940256099942544/5224354917"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(11, 16, 32))
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(SnakeAdsBridge(), "snakeAds")
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))

        adView = AdView(this).apply {
            adUnitId = bannerTestId
            setAdSize(AdSize.BANNER)
        }
        root.addView(adView, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        MobileAds.initialize(this) {
            runOnUiThread {
                adsReady = true
                adView.loadAd(AdRequest.Builder().build())
                loadRewardedAd()
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun loadRewardedAd() {
        if (!adsReady) return
        RewardedAd.load(this, rewardedTestId, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            })
    }

    private inner class SnakeAdsBridge {
        @JavascriptInterface
        fun showRewarded() {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) {
                    Toast.makeText(this@MainActivity, "Ad अभी तैयार नहीं है। थोड़ी देर बाद कोशिश करें।", Toast.LENGTH_SHORT).show()
                    loadRewardedAd()
                    webView.evaluateJavascript("window.__snakeRewardResolve && window.__snakeRewardResolve(false)", null)
                    return@runOnUiThread
                }
                rewardedAd = null
                ad.show(this@MainActivity) {
                    // The HTML should define this callback to add 50 coins only after the reward is earned.
                    webView.evaluateJavascript("window.__snakeRewardResolve && window.__snakeRewardResolve(true)", null)
                }
                loadRewardedAd()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::adView.isInitialized) adView.resume()
    }

    override fun onPause() {
        if (::adView.isInitialized) adView.pause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::adView.isInitialized) adView.destroy()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("snakeAds")
            webView.destroy()
        }
        super.onDestroy()
    }
}
