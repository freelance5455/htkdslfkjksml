plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rktechhub.snakegamepromax"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.rktechhub.snakegamepromax"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    // Legacy Mobile Ads SDK sample implementation. See README for current Next-Gen SDK note.
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
