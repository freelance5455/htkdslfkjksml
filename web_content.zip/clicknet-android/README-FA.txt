تبدیل فایل کلیک‌نت به APK اندروید

این پروژه، فایل HTML نسخه پنجم کلیک‌نت را داخل یک برنامه اندرویدی WebView قرار می‌دهد.

روش ساخت APK:
۱) Android Studio را روی کامپیوتر نصب کن.
۲) از داخل Android Studio گزینه Open را بزن و پوشه clicknet-android را انتخاب کن.
۳) صبر کن Gradle Sync تمام شود. اگر Android SDK Platform 35 نصب نیست، از SDK Manager نصبش کن.
۴) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را انتخاب کن.
۵) بعد از پایان ساخت، روی اعلان locate کلیک کن تا فایل APK را پیدا کنی.

مسیر معمول APK:
app/build/outputs/apk/debug/app-debug.apk

نکته‌ها:
- برای بارگذاری فونت‌ها و آیکون‌هایی که در HTML از اینترنت دریافت می‌شوند، اتصال اینترنت لازم است.
- این پروژه نسخه Debug می‌سازد و برای نصب و آزمایش مناسب است. برای انتشار عمومی، از Build > Generate Signed Bundle / APK استفاده کن و نسخه Release امضاشده بساز.
- نام برنامه: کلیک‌نت
- شناسه برنامه: com.clicknet.app
