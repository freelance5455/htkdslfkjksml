plugins { id("com.android.application") }

android { namespace = "com.hekel.pedidos"; compileSdk = 35
    defaultConfig { applicationId = "com.hekel.pedidos"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
