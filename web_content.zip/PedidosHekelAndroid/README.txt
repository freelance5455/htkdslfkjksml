PEDIDOS HEKEL - APP ANDROID

Este proyecto envuelve la planilla HTML Pedidos_Hekel en una app Android offline.

Incluye:
- Buscador de productos.
- Pedido actual y cantidades.
- Pedidos guardados.
- Copiar para Excel.
- Imprimir / PDF desde la pagina.
- Compartir por WhatsApp.
- Actualizacion de precios mediante CSV.
- Fotos de productos.
- Guardado local en el telefono.

COMO OBTENER EL APK
1. Instalar Android Studio en una PC.
2. Abrir esta carpeta como proyecto.
3. Esperar a que Gradle descargue las herramientas.
4. Menu Build > Build APK(s).
5. El APK de prueba queda en app/build/outputs/apk/debug/app-debug.apk.

NOTA
El entorno donde se preparo este proyecto no tiene instalado Android SDK/Gradle, por eso no se entrega un APK ya compilado desde aqui. El proyecto esta listo para compilar en Android Studio.
