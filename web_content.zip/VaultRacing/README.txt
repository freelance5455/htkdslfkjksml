Vault'sracing - Android project

1. Put your intro image at app/src/main/assets/vault.png (optional; the intro shows the text either way).
2. Build:
   - GitHub: upload this folder to a new repo -> Actions tab -> "Build APK" -> download the artifact (Vault'sracing.apk).
   - Or Android Studio: open folder -> Build > Build APK(s).

--- Update: new vehicle & zombie artwork ---
* All 10 vehicles now use the supplied artwork (assets/vspr.js holds the sprites; game.html draws them).
  Wheels are separate sprites, so tyres spin and the suspension still moves.
* Zombie uses the supplied artwork, animated procedurally (legs swing, body sways).
* Zombie chase speed reduced by 20%.
* Build the APK: push this folder to GitHub -> Actions -> "Build APK" -> download "Vault-racing-apk"
  (or open in Android Studio and run Build > Build APK).

--- Update 2 ---
* Vehicle engine sound volume x0.8.
* Brake / Gas pedals restyled as metal plates with 6 holes on a post (like the reference screenshot).
* Gameplay zoom x1.4 (camera follow offsets rescaled so the vehicle stays in the same screen position).

--- Update 2 ---
* Engine/vehicle sound volume x0.8 (on top of the previous level).
* Brake / Gas pedals restyled to brushed-metal plates with 6 holes, label and post (like the reference screenshot).
* Gameplay camera zoom x1.4 (ZM 1.4 -> 1.96).

--- Update 3 ---
* New cinematic intro: assets/intro.mp4 (6 s, 1280x720, H.264 + AAC with synthesized intro sound) built around the supplied
  Vault logo. assets/intro.html plays it; tap to skip; falls back to a still logo (assets/vault_logo.png) if video can't play.
* Landscape: manifest already used sensorLandscape; now also forced in MainActivity.onCreate.
* Audio balance: vehicle/engine volume x0.6, music volume x1.8 (MG gain 0.55 -> 1.0).

--- Update 4: guns, vehicle HP, monster zombies ---
* Every vehicle has an auto-aiming, auto-firing gun (leads moving targets, prefers zombies attacking the vehicle and monsters).
* Garage: new upgrades - Gun Power (damage + fire rate + bullet colour, twin barrels from level 3), Gun Size (bigger gun, range, bullets),
  Armor (more vehicle HP) and HP Booster. Garage shows damage / shots per second / HP for the selected vehicle.
* Zombies: many more, spawn faster, have HP and are killed by bullets (+3 coins each at the end of the run).
* Vehicle HP bar (HUD + HP gauge). Zombies hitting the vehicle (and lava) reduce HP. At 0 HP the vehicle burns out, zombies swarm the wreck,
  the driver is killed and a metallic silver GAME OVER screen appears.
* Monster zombie every 1000 m (Unlimited mode, and worlds whose finish line is beyond 1000 m): each one is bigger, faster, has far more HP and hits harder.
  Kill it (bonus coins) or get 40 m ahead of it - then it disappears forever and a stronger one appears at the next 1000 m.
* Nitro boost removed. The old boost button is now the HP Booster (green): tap to heal when the ring is charged. Green repair kits replace the old boost pickups.

--- Update 5: always opens in landscape ---
* Android app: already locked to landscape in AndroidManifest.xml (sensorLandscape) and MainActivity.onCreate - unchanged.
* Browser / other wrappers: the game and the intro now ask the browser to lock landscape on the first tap (full-screen + orientation lock, where supported)
  and add landscape meta hints. If the phone is held upright and the browser will not lock, the whole game (intro, menus, race, controls) is rotated
  to landscape automatically, so it never shows the "rotate your phone" screen on touch devices; it straightens itself the moment the phone is turned.
