# Tyvi Android — LAN otomatis (WebView + NSD)

## Struktur
```
settings.gradle.kts / build.gradle.kts / gradle.properties
app/build.gradle.kts            compileSdk=targetSdk=36, minSdk 26, TANPA dependensi
app/src/main/AndroidManifest.xml
app/src/main/res/values/themes.xml
app/src/main/assets/tyvi.html   = tyvi-game-4.html + hook LAN (engine/sync/editor tidak ditulis ulang)
app/src/main/java/com/tyvi/game/MainActivity.kt   WebView, insets edge-to-edge, file chooser, siklus hidup
app/src/main/java/com/tyvi/game/LanBridge.kt      JavascriptInterface "TyviLan": NSD + TCP pairing + probe gateway
tests/                          uji Node (JS) + skrip patch
```
Sudah punya proyek Android? Salin 2 file .kt, izin manifest, dan tyvi.html ke assets.

## JavascriptInterface <-> HTML
`web.addJavascriptInterface(lan, "TyviLan")` => `window.TyviLan.*` (JS -> native, hanya String/Int).
Native -> JS: `evaluateJavascript("window.TyviLanNative.emit(type, jsonString)")`, argumen di-quote `JSONObject.quote`.
Di browser biasa `window.TyviLan` tidak ada => `Lan.ok=false`, semua UI otomatis menampilkan "pakai kode manual".

## Alur pairing otomatis (WebRTC tetap di WebView)
Host `hostStart` -> TCP :47321 + NSD `_tyvi._tcp`. Guest: NSD + probe gateway Wi-Fi (hotspot) -> pilih sesi ->
TCP: banner -> hi -> host JS `createInvite()` -> offer(+kandidat) -> guest JS `join()` -> answer(+kandidat) -> host `acceptAnswer()`.
Setelah itu DataChannel jalan seperti biasa; TCP ditutup. Hello/sync/chat/kick/batas pemain = kode lama.

## mDNS ICE
WebView menyamarkan IP host sebagai `uuid.local`. Tidak ada edit teks SDP. Native melaporkan IPv4 privat;
JS membangun ulang kandidat host `.local` sebagai kandidat TERSTRUKTUR (field di-parse regex ketat) dan memasukkannya
via `addIceCandidate()`. Kandidat dari peer divalidasi: typ host, IPv4 RFC1918, port 1–65535, maks 12.
Karena kandidat mDNS tidak memuat IP-nya, IP dicoba dari semua antarmuka lokal (kandidat salah gagal tanpa efek).

## Build
Android Studio (JDK 17) -> Open -> Sync -> Run. Versi AGP 8.11.1 / Kotlin 2.0.21 = titik awal, sesuaikan jika Studio meminta.
Android 17+/target 37: ganti NEARBY_WIFI_DEVICES -> ACCESS_LOCAL_NETWORK (izin runtime).

## Uji manual 2 HP (belum dilakukan)
1. Satu Wi-Fi: HP A Host -> "Siaran aktif"; HP B Join -> sesi muncul -> Gabung -> masuk game.
2. Hotspot: A hotspot+Host, B terhubung ke hotspot A -> Join.
3. Cek: gerak/lompat/collision, chat, batas pemain (pemain ke-N+1 ditolak "sesi penuh"), kick, keluar, host tutup.
4. Matikan Wi-Fi guest saat transfer -> pesan gagal, tidak macet. Host tekan Batalkan -> sesi hilang dari daftar.
5. `adb logcat -s TyviLan chromium` bila gagal; manual kode tetap bisa dipakai.
