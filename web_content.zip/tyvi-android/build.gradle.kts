// Versi plugin = titik awal; sesuaikan dengan Android Studio-mu (compileSdk 36 butuh AGP >= 8.9).
plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
