import re,sys
src=open('/mnt/user-data/uploads/tyvi-game-4.html',encoding='utf-8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    assert n==cnt,(n,old[:80])
    src=src.replace(old,new)
lancand=open('/home/claude/lancand.js').read(); lan=open('/home/claude/lan_module.js').read()
# 1. LanCand sebelum class Link
rep("/* ---------------- Link: satu koneksi peer ---------------- */\nclass Link {", lancand+"/* ---------------- Link: satu koneksi peer ---------------- */\nclass Link {")
# 2. Link: tangkap kandidat + metode LAN
rep("    this.pc = new RTCPeerConnection({ iceServers: [] });\n    this.ctl =",
    "    this.pc = new RTCPeerConnection({ iceServers: [] });\n    this.cands = [];   // kandidat lokal (untuk LAN otomatis; pairing manual tidak memakainya)\n    this.pc.addEventListener('icecandidate', e => { if (e.candidate && this.cands.length < 40) this.cands.push({ candidate: e.candidate.candidate, sdpMid: e.candidate.sdpMid, sdpMLineIndex: e.candidate.sdpMLineIndex }); });\n    this.ctl =")
rep("  _msg(e, max) {\n    if (this.closed ||",
    "  lanCands(ips) { return LanCand.expand(this.cands, ips || []); }\n  async addCands(list) {\n    let n = 0; if (this.closed) return n;\n    for (const c of LanCand.clean(list)) { try { await this.pc.addIceCandidate(c); n++; } catch (e) { /* satu kandidat buruk tidak boleh menggagalkan pairing */ } }\n    return n;\n  }\n  _msg(e, max) {\n    if (this.closed ||")
# 3. Host
rep("  async createInvite() {","  async createInvite(ips) {")
rep("this.emit('players'); return { slot, code };","this.emit('players'); return { slot, code, cands: ips ? link.lanCands(ips) : [] };")
rep("  async acceptAnswer(code) {","  async acceptAnswer(code, cands) {")
rep("    await p.link.pc.setRemoteDescription({ type: 'answer', sdp: o.sdp });\n","    await p.link.pc.setRemoteDescription({ type: 'answer', sdp: o.sdp });\n    if (cands) await p.link.addCands(cands);\n")
# 4. Member
rep("  async join(code) {","  async join(code, lan) {")
rep("      await pc.setRemoteDescription({ type: 'offer', sdp: o.sdp });\n      await pc.setLocalDescription(await pc.createAnswer()); await gather(pc, MPC.ICE_WAIT);\n",
    "      await pc.setRemoteDescription({ type: 'offer', sdp: o.sdp });\n      if (lan) await this.link.addCands(lan.cands);\n      await pc.setLocalDescription(await pc.createAnswer()); await gather(pc, MPC.ICE_WAIT);\n      this.myCands = lan ? this.link.lanCands(lan.ips) : [];\n")
rep("now - this.t0 > 180000","now - this.t0 > (this.pairMs || 180000)")
# 5. Modul Lan sebelum kartu Halaman Utama
rep("/* ---------------- kartu di Halaman Utama ---------------- */", lan+"\n/* ---------------- kartu di Halaman Utama ---------------- */")
# 6. UI
rep("    row(false, 'Pencarian sesi otomatis (multicast/mDNS/server socket) TIDAK tersedia di HTML murni — pakai kode pairing'));",
    "    Lan.ok ? row(null, 'Pencarian sesi otomatis: komponen native tersedia (belum terbukti antar perangkat sampai diuji di 2 HP)') : row(false, 'Pencarian sesi otomatis hanya di aplikasi Android Tyvi — di sini pakai kode pairing'));")
rep("h('h2', null, 'Sesi Host — ' + sess.level.name), cnt, invitePanel(sess),","h('h2', null, 'Sesi Host — ' + sess.level.name), cnt, Lan.hostPanel(sess), invitePanel(sess),")
rep("  openModal(h('div', { class: 'dialog' }, h('h2', null, 'Join Sesi Lokal'), code, status, prog, out,",
    "  const auto = Lan.joinPanel(M, (t, bad) => { status.textContent = t; status.style.color = bad ? '#ff8a80' : ''; });\n  openModal(h('div', { class: 'dialog' }, h('h2', null, 'Join Sesi Lokal'), auto, h('div', { class: 'small dim' }, 'Atau tempel kode manual:'), code, status, prog, out,")
rep("Pemain lain: Join, tempel kode dari host.","Pemain lain: Join (otomatis di aplikasi Android, atau tempel kode dari host).")
open('/home/claude/tyvi-android/app/src/main/assets/tyvi.html','w',encoding='utf-8').write(src)
print('ok',len(src))
