/* =====================================================================
   LAN OTOMATIS — hanya di aplikasi Android (JavascriptInterface "TyviLan").
   Native HANYA membawa teks pairing (kode TYVI1 + kandidat ICE) lewat TCP lokal.
   WebRTC, DataChannel, sinkronisasi, chat, kick tetap kode di atas. Di browser biasa: Lan.ok=false, semua no-op.
   Pairing manual (salin-tempel) TETAP ada sebagai fallback.
   ===================================================================== */
const Lan = (() => {
  const N = (typeof window !== 'undefined' && window.TyviLan && typeof window.TyviLan.info === 'function') ? window.TyviLan : null;
  const L = { ok: !!N, ips: [], H: null, G: null };
  const pj = s => { try { return JSON.parse(s); } catch (e) { return null; } };
  const call = (fn, ...a) => { try { return N[fn](...a); } catch (e) { console.error('TyviLan.' + fn, e); return null; } };
  const send = (fn, conn, o) => call(fn, conn, JSON.stringify(o));
  const refresh = () => { const i = pj(call('info')); L.ips = i && Array.isArray(i.ips) ? i.ips.filter(x => LanCand.ip(x)).slice(0, 4) : []; return i; };

  /* ---------- HOST ---------- */
  function hostStop() {
    const H = L.H; if (!H) return; L.H = null;
    for (const e of H.conns.values()) clearTimeout(e.t);
    H.conns.clear(); call('hostStop');
  }
  const hostDrop = (H, e) => { clearTimeout(e.t); if (e.slot && !e.answered && H.sess.pending.has(e.slot)) H.sess.drop(e.slot, 'error'); };
  function hostPanel(sess) {
    const st = h('div', { class: 'small dim' });
    const box = h('div', { class: 'rule' }, h('div', { class: 'title-sm' }, 'SIARAN LAN OTOMATIS'), st);
    if (!L.ok) { st.textContent = 'Hanya di aplikasi Android Tyvi. Di sini pakai kode manual di bawah.'; return box; }
    refresh();
    const r = pj(call('hostStart', sess.sid, sess.level.name, sess.maxMembers));
    if (!r || !r.ok) { st.textContent = '✗ Siaran gagal: ' + ((r && r.err) || 'tidak diketahui') + '. Pakai kode manual.'; st.style.color = '#ff8a80'; return box; }
    L.H = { sess, conns: new Map(), st };
    const d0 = sess.destroy.bind(sess); sess.destroy = delay => { hostStop(); d0(delay); };   // bersihkan native saat sesi berakhir
    st.textContent = 'Siaran dimulai (port ' + r.port + '). Menunggu pemain di Wi-Fi/hotspot yang sama…';
    return box;
  }

  /* ---------- JOIN ---------- */
  function joinStop() {
    const G = L.G; if (!G) return; L.G = null;
    clearTimeout(G.t); clearTimeout(G.scan); call('discoveryStop'); if (G.conn) call('closeConn', G.conn);
  }
  function giveUp(G, msg, retry) {
    clearTimeout(G.t); if (G.conn) call('closeConn', G.conn); G.conn = 0; G.offered = false;
    G.setStatus('✗ ' + msg + (G.M.closed ? ' (tutup dialog ini lalu coba lagi)' : retry === false ? '' : ' — coba lagi atau pakai kode manual'), true);
    if (!G.M.closed && L.G === G) G.scan();
  }
  function joinPanel(M, setStatus) {
    const info = h('div', { class: 'small dim' }), list = h('div', { class: 'col' });
    const again = h('button', { class: 'btn sm', onclick: () => { if (L.G && !L.G.conn) L.G.scan(); } }, 'Cari ulang');
    const box = h('div', { class: 'rule' }, h('div', { class: 'title-sm' }, 'CARI SESI OTOMATIS'), info, list);
    if (!L.ok) { info.textContent = 'Hanya di aplikasi Android Tyvi. Di sini tempel kode dari host di bawah.'; return box; }
    const G = { M, sessions: new Map(), conn: 0, offered: false, t: 0, scan: null, setStatus, render: null };
    G.render = () => {
      const seen = new Set(), rows = [];
      for (const s of G.sessions.values()) {
        if (seen.has(s.sid)) continue; seen.add(s.sid);
        rows.push(h('div', { class: 'row' }, h('div', { style: 'flex:1' }, s.name + ' (maks ' + s.cap + ')'), h('button', { class: 'btn primary sm', onclick: () => pick(s) }, 'Gabung')));
      }
      list.replaceChildren(...rows);
    };
    G.scan = () => {
      refresh(); clearTimeout(G.scan_t); G.sessions.clear(); G.render();
      const r = pj(call('discoveryStart'));
      if (!r || !r.ok) { info.textContent = '✗ Pencarian gagal: ' + ((r && r.err) || 'tidak diketahui'); return; }
      info.textContent = 'Mencari sesi di jaringan ini…'; info.style.color = '';
      G.scan_t = setTimeout(() => { if (!G.sessions.size) info.textContent = 'Belum ada sesi. Pastikan satu Wi-Fi/hotspot dengan host, atau pakai kode manual.'; }, 15000);
    };
    const pick = s => {
      if (G.conn) return; refresh(); clearTimeout(G.scan_t); call('discoveryStop');
      const c = call('connect', s.host, s.port, deviceId());
      if (!c || c < 0) { setStatus('✗ Gagal membuka koneksi ke host', true); return; }
      G.conn = c; G.offered = false; setStatus('Menghubungi ' + s.name + '…');
      G.t = setTimeout(() => { if (!G.offered) giveUp(G, 'Host tidak merespons'); }, 25000);
    };
    L.G = G; box.append(h('div', { class: 'row' }, again));
    const d0 = M.destroy.bind(M); M.destroy = delay => { joinStop(); d0(delay); };   // M.destroy dipakai batal/gagal/selesai
    M.on('go', joinStop);
    G.scan();
    return box;
  }

  /* ---------- event dari native (semua input dianggap tidak tepercaya) ---------- */
  const handlers = {
    async hostGuest(d) {
      const H = L.H, conn = d.conn;
      if (!H || H.sess.closed) return send('hostReply', conn, { t: 'deny', r: 'closed' });
      const e = { slot: 0, answered: false, t: 0 }; H.conns.set(conn, e);
      let inv;
      try { inv = await H.sess.createInvite(L.ips); }
      catch (err) { H.conns.delete(conn); return send('hostReply', conn, { t: 'deny', r: /Batas/.test(String(err && err.message)) ? 'full' : 'error' }); }
      e.slot = inv.slot;
      if (L.H !== H || !H.conns.has(conn)) { hostDrop(H, e); return; }            // tamu pergi saat undangan dibuat
      e.t = setTimeout(() => { H.conns.delete(conn); hostDrop(H, e); call('hostClose', conn); }, 30000);
      send('hostReply', conn, { t: 'offer', slot: inv.slot, code: inv.code, cands: inv.cands });
    },
    async hostAnswer(d) {
      const H = L.H, e = H && H.conns.get(d.conn); if (!e || e.answered || !e.slot) return;
      e.answered = true; clearTimeout(e.t);
      const link = H.sess.pending.get(e.slot) && H.sess.pending.get(e.slot).link;
      try {
        const o = await decodeSig(d.code);
        if (o.t !== 'answer' || o.slot !== e.slot) throw new Error('slot tidak cocok');   // cegah jawaban untuk slot milik tamu lain
        await H.sess.acceptAnswer(d.code, d.cands);
        if (link) setTimeout(() => H.sess.dropIf(e.slot, link, 'timeout'), 25000);        // tidak jadi terhubung => bebaskan slot
      } catch (err) { if (link) H.sess.dropIf(e.slot, link, 'error'); }
      H.conns.delete(d.conn); call('hostClose', d.conn);
    },
    hostGuestClosed(d) { const H = L.H, e = H && H.conns.get(d.conn); if (!e) return; H.conns.delete(d.conn); hostDrop(H, e); },
    hostAdv(d) {
      const H = L.H; if (!H) return;
      H.st.textContent = d.ok ? 'Siaran aktif (mDNS terdaftar). Menunggu pemain…' : '⚠ Pendaftaran mDNS gagal (kode ' + (d.code | 0) + '). Pemain di hotspot-mu masih bisa menemukan lewat gateway; selain itu pakai kode manual.';
      H.st.style.color = d.ok ? '' : 'var(--gold)';
    },
    session(d) { const G = L.G, s = G && LanCand.sess(d); if (s) { G.sessions.set(s.id, s); G.render(); } },
    sessionLost(d) { const G = L.G; if (G && typeof d.id === 'string') { G.sessions.delete(d.id); G.render(); } },
    async guestMsg(d) {
      const G = L.G; if (!G || d.conn !== G.conn || G.offered) return;
      const m = d.msg; if (!m || typeof m !== 'object') return;
      if (m.t === 'deny') return giveUp(G, 'Ditolak host: ' + ({ full: 'sesi penuh', closed: 'sesi ditutup' }[m.r] || 'host gagal menyiapkan undangan'), false);
      if (m.t !== 'offer') return;
      G.offered = true; clearTimeout(G.t);
      try {
        G.M.pairMs = 25000;
        const ans = await G.M.join(m.code, { cands: m.cands, ips: L.ips });
        send('guestSend', G.conn, { t: 'answer', code: ans, cands: G.M.myCands });
        G.setStatus('Menunggu host menyambungkan…');
      } catch (e) { giveUp(G, (e && e.message) || 'pairing gagal'); }
    },
    guestClosed(d) { const G = L.G; if (!G || d.conn !== G.conn) return; if (!G.offered) giveUp(G, 'Koneksi ke host terputus (' + String(d.why).slice(0, 30) + ')'); else G.conn = 0; },
    discoveryError(d) { const G = L.G; if (G) G.setStatus('✗ Pencarian gagal (kode ' + (d.code | 0) + ')', true); }
  };
  if (N) window.TyviLanNative = { emit(type, json) {
    const d = pj(json), f = Object.prototype.hasOwnProperty.call(handlers, type) ? handlers[type] : null;
    if (!d || typeof d !== 'object' || !f) return;
    Promise.resolve().then(() => f(d)).catch(e => console.error('Lan', type, e));
  } };
  return { ok: L.ok, hostPanel, joinPanel, hostStop, joinStop, refresh, _L: L };
})();
