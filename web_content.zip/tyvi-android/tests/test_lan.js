const fs=require('fs'), assert=require('assert');
let pass=0; const t=(n,f)=>{ try{ const r=f(); if(r&&r.then) return r.then(()=>{pass++;console.log('ok  ',n)},e=>{console.log('FAIL',n,e.message);process.exitCode=1}); pass++;console.log('ok  ',n);}catch(e){console.log('FAIL',n,e.message);process.exitCode=1}};
const LC=new Function(fs.readFileSync('lancand.js','utf8')+';return LanCand;')();
const real='candidate:842163049 1 udp 1677729535 192.168.1.20 54321 typ host generation 0 ufrag ab12 network-id 1 network-cost 10';
const mdns='candidate:842163049 1 udp 2113937151 3f2a9c1e-1111-4222-8333-444455556666.local 54321 typ host generation 0 ufrag ab12 network-id 1';
(async()=>{
await t('expand: mDNS -> IP terstruktur (tanpa ubah SDP)',()=>{const o=LC.expand([{candidate:mdns,sdpMid:'0',sdpMLineIndex:0}],['192.168.43.1','10.0.0.5']);assert.equal(o.length,2);assert.ok(o[0].candidate.startsWith('candidate:842163049 1 udp 2113937151 192.168.43.1 54321 typ host generation 0 ufrag ab12 network-id 1'));assert.equal(o[0].sdpMid,'0')});
await t('expand: kandidat IP asli tidak diduplikasi',()=>assert.equal(LC.expand([{candidate:real,sdpMid:'0',sdpMLineIndex:0}],['192.168.1.20']).length,0));
await t('expand: IP publik/ngawur ditolak',()=>assert.equal(LC.expand([{candidate:mdns,sdpMid:'0',sdpMLineIndex:0}],['8.8.8.8','999.1.1.1','1.2.3']).length,0));
await t('clean: terima RFC1918',()=>assert.equal(LC.clean([{candidate:real,sdpMid:'0',sdpMLineIndex:0}]).length,1));
await t('clean: tolak IP publik, loopback, link-local, .local, srflx, injeksi baris',()=>{
  const bad=['candidate:1 1 udp 1 8.8.8.8 5000 typ host','candidate:1 1 udp 1 127.0.0.1 5000 typ host','candidate:1 1 udp 1 169.254.1.1 5000 typ host','candidate:1 1 udp 1 x.local 5000 typ host','candidate:1 1 udp 1 192.168.1.2 5000 typ srflx raddr 0.0.0.0 rport 0','candidate:1 1 udp 1 192.168.1.2 5000 typ host\r\na=evil:1','candidate:1 1 udp 1 192.168.1.2 0 typ host','candidate:1 1 udp 1 192.168.1.2 70000 typ host'];
  assert.equal(LC.clean(bad.map(c=>({candidate:c,sdpMid:'0',sdpMLineIndex:0}))).length,0)});
await t('clean: batas jumlah & tipe bukan array',()=>{assert.equal(LC.clean(Array(50).fill({candidate:real,sdpMid:'0',sdpMLineIndex:0})).length,12);assert.deepEqual(LC.clean('x'),[]);assert.deepEqual(LC.clean(null),[])});
await t('sess: validasi',()=>{assert.ok(LC.sess({id:'nsd:a',sid:'abc',name:'G',host:'192.168.1.5',port:47321,cap:4}));assert.equal(LC.sess({id:'x',sid:'s',host:'8.8.8.8',port:47321,cap:4}),null);assert.equal(LC.sess({id:'x',sid:'s',host:'192.168.1.5',port:80,cap:4}),null)});

// ---- orkestrasi Lan dengan bridge native tiruan ----
const calls=[]; let timers=[]; const real_st=global.setTimeout, real_ct=global.clearTimeout;
global.setTimeout=(f,ms)=>{const x={f,ms,on:true};timers.push(x);return x}; global.clearTimeout=x=>{if(x)x.on=false};
const fire=ms=>{for(const x of timers.filter(x=>x.on&&x.ms<=ms)){x.on=false;x.f()}};
const nat={info:()=>JSON.stringify({ok:true,ips:['192.168.1.20','8.8.8.8']}),hostStart:(...a)=>{calls.push(['hostStart',...a]);return JSON.stringify({ok:true,port:47321})},hostStop:()=>calls.push(['hostStop']),hostReply:(c,j)=>calls.push(['hostReply',c,JSON.parse(j)]),hostClose:c=>calls.push(['hostClose',c]),discoveryStart:()=>{calls.push(['discoveryStart']);return JSON.stringify({ok:true})},discoveryStop:()=>calls.push(['discoveryStop']),connect:(...a)=>{calls.push(['connect',...a]);return 7},closeConn:c=>calls.push(['closeConn',c]),guestSend:(c,j)=>calls.push(['guestSend',c,JSON.parse(j)])};
global.window={TyviLan:nat}; global.h=(tag,at,...ch)=>({tag,at,ch,textContent:'',style:{},append(...x){this.ch.push(...x)},replaceChildren(...x){this.ch=x}});
global.deviceId=()=>'dev-12345678'; global.decodeSig=async c=>JSON.parse(c);
const Lan=new Function('LanCand',fs.readFileSync('lan_module.js','utf8')+';return Lan;')(LC);
const mkSess=()=>{const s={sid:'SID1',level:{name:'G'},maxMembers:2,closed:false,pending:new Map(),n:0,dropped:[],destroyed:0,
  async createInvite(ips){if(s.n>=s.maxMembers)throw new Error('Batas pemain tercapai (2)');const slot=++s.n;s.pending.set(slot,{link:{}});return{slot,code:'OFFER'+slot,cands:[{ips}]}},
  async acceptAnswer(code,c){s.accepted=(s.accepted||[]).concat([[code,c]])},drop(slot,w){s.dropped.push([slot,w]);s.pending.delete(slot)},dropIf(slot,l,w){const p=s.pending.get(slot);if(p&&p.link===l)s.drop(slot,w)},destroy(){s.destroyed++}};return s};
const emit=(t,d)=>window.TyviLanNative.emit(t,JSON.stringify(d)); const tick=()=>new Promise(r=>setImmediate(r));
const S=mkSess();
await t('host: hostStart dipanggil, ip publik disaring',()=>{Lan.hostPanel(S);assert.deepEqual(calls[0],['hostStart','SID1','G',2]);assert.deepEqual(Lan._L.ips,['192.168.1.20'])});
await t('host: tamu -> offer dikirim ke conn yang benar',async()=>{emit('hostGuest',{conn:11});await tick();await tick();const r=calls.find(c=>c[0]==='hostReply'&&c[1]===11);assert.equal(r[2].t,'offer');assert.equal(r[2].slot,1)});
await t('host: jawaban untuk slot lain DITOLAK (anti-hijack) & slot dibebaskan',async()=>{emit('hostAnswer',{conn:11,code:JSON.stringify({t:'answer',slot:2}),cands:[]});await tick();await tick();assert.equal(S.accepted,undefined);assert.ok(S.dropped.some(d=>d[0]===1));assert.ok(calls.some(c=>c[0]==='hostClose'&&c[1]===11))});
await t('host: jawaban sah diteruskan ke acceptAnswer',async()=>{emit('hostGuest',{conn:12});await tick();await tick();const slot=[...S.pending.keys()].pop();emit('hostAnswer',{conn:12,code:JSON.stringify({t:'answer',slot}),cands:['x']});await tick();await tick();await tick();assert.equal(S.accepted.length,1)});
await t('host: tamu putus sebelum menjawab -> undangan pending dibuang',async()=>{S.n=0;emit('hostGuest',{conn:13});await tick();await tick();const slot=[...S.pending.keys()].pop();emit('hostGuestClosed',{conn:13});await tick();assert.ok(S.dropped.some(d=>d[0]===slot&&d[1]==='error'))});
await t('host: sesi penuh -> deny full',async()=>{S.n=5;emit('hostGuest',{conn:14});await tick();await tick();const r=calls.filter(c=>c[0]==='hostReply'&&c[1]===14).pop();assert.deepEqual(r[2],{t:'deny',r:'full'})});
await t('host: timeout 30 dtk tanpa jawaban membebaskan slot & menutup koneksi',async()=>{S.n=0;S.pending.clear();emit('hostGuest',{conn:15});await tick();await tick();const slot=[...S.pending.keys()].pop();fire(30000);assert.ok(S.dropped.some(d=>d[0]===slot));assert.ok(calls.some(c=>c[0]==='hostClose'&&c[1]===15))});
await t('host: sess.destroy() memanggil hostStop native',()=>{const n=calls.filter(c=>c[0]==='hostStop').length;S.destroy(100);assert.equal(calls.filter(c=>c[0]==='hostStop').length,n+1);assert.equal(S.destroyed,1)});
await t('event tak dikenal / prototype-pollution diabaikan',()=>{emit('constructor',{});emit('__proto__',{});emit('nope',{})});
// join
const M={closed:false,_h:{},on(e,f){this._h[e]=f},destroy(){this.closed=true},async join(code,l){M.joined=[code,l];return'ANS'},myCands:[{c:1}]};const st=[];
await t('join: mulai pencarian, daftar sesi dedupe per sid',()=>{Lan.joinPanel(M,(x,b)=>st.push([x,b]));assert.ok(calls.some(c=>c[0]==='discoveryStart'));emit('session',{id:'nsd:a',sid:'S1',name:'A',host:'192.168.1.5',port:47321,cap:4});emit('session',{id:'gw:1',sid:'S1',name:'A',host:'192.168.1.1',port:47321,cap:4});return tick().then(()=>assert.equal(Lan._L.G.sessions.size,2))});
await t('join: sesi dengan host publik diabaikan',()=>{emit('session',{id:'x',sid:'S9',name:'E',host:'8.8.8.8',port:47321,cap:4});return tick().then(()=>assert.ok(!Lan._L.G.sessions.has('x')))});
await t('join: offer -> M.join -> answer dikirim lewat conn yang sama',async()=>{const G=Lan._L.G;G.conn=7;emit('guestMsg',{conn:7,msg:{t:'offer',code:'OFFER1',cands:[1]}});await tick();await tick();assert.equal(M.joined[0],'OFFER1');assert.equal(M.pairMs,25000);const g=calls.filter(c=>c[0]==='guestSend').pop();assert.equal(g[1],7);assert.equal(g[2].code,'ANS')});
await t('join: pesan dari conn lain diabaikan',async()=>{const n=calls.filter(c=>c[0]==='guestSend').length;emit('guestMsg',{conn:99,msg:{t:'offer',code:'X'}});await tick();assert.equal(calls.filter(c=>c[0]==='guestSend').length,n)});
await t('join: M.destroy membersihkan discovery + koneksi',()=>{calls.length=0;M.destroy();assert.ok(calls.some(c=>c[0]==='discoveryStop'));assert.ok(calls.some(c=>c[0]==='closeConn'&&c[1]===7));assert.equal(Lan._L.G,null)});
global.setTimeout=real_st;global.clearTimeout=real_ct;
console.log(pass+' lulus');
})();
