/* ---------------- kandidat ICE terstruktur untuk LAN (pengganti mDNS .local) ----------------
   TIDAK mengubah teks SDP. Kandidat host ber-alamat "<uuid>.local" (mDNS) dibangun ulang sebagai kandidat
   TERSTRUKTUR dengan IPv4 privat dari native, lalu didaftarkan lewat RTCPeerConnection.addIceCandidate()
   (API standar). Semua kandidat dari peer divalidasi ketat: hanya typ host, IPv4 RFC1918, port 1-65535. */
const LanCand = {
  PRIV: /^(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})$/,
  CAND: /^candidate:(\S{1,32}) ([12]) (udp|tcp) (\d{1,10}) (\S{1,255}) (\d{1,5}) typ host((?: (?:tcptype|generation|network-id|network-cost|ufrag) \S{1,64})*)$/,
  MAX: 12,
  ip(s) { return typeof s === 'string' && this.PRIV.test(s) && s.split('.').every(p => +p <= 255); },
  build(m, addr) { return 'candidate:' + m[1] + ' ' + m[2] + ' ' + m[3] + ' ' + m[4] + ' ' + addr + ' ' + m[6] + ' typ host' + m[7]; },
  expand(cands, ips) {                     // cands: [{candidate,sdpMid,sdpMLineIndex}] dari event icecandidate lokal
    const out = [], seen = new Set();
    for (const c of cands) {
      const m = this.CAND.exec((c && c.candidate) || ''); if (!m || !/\.local$/i.test(m[5])) continue;
      for (const ip of ips) {
        if (!this.ip(ip) || out.length >= this.MAX) continue;
        const s = this.build(m, ip), k = s + '|' + c.sdpMid; if (seen.has(k)) continue; seen.add(k);
        out.push({ candidate: s, sdpMid: c.sdpMid == null ? null : String(c.sdpMid), sdpMLineIndex: c.sdpMLineIndex == null ? null : c.sdpMLineIndex });
      }
    }
    return out;
  },
  clean(list) {                            // validasi kandidat DARI PEER sebelum addIceCandidate
    const out = []; if (!Array.isArray(list)) return out;
    for (const c of list.slice(0, this.MAX)) {
      if (!c || typeof c !== 'object' || typeof c.candidate !== 'string' || c.candidate.length > 300) continue;
      const m = this.CAND.exec(c.candidate); if (!m || !this.ip(m[5])) continue;
      const port = +m[6]; if (port < 1 || port > 65535) continue;
      const mid = typeof c.sdpMid === 'string' && c.sdpMid.length <= 16 ? c.sdpMid : null;
      const idx = Number.isInteger(c.sdpMLineIndex) && c.sdpMLineIndex >= 0 && c.sdpMLineIndex <= 3 ? c.sdpMLineIndex : null;
      if (mid === null && idx === null) continue;
      out.push({ candidate: this.build(m, m[5]), sdpMid: mid, sdpMLineIndex: idx });
    }
    return out;
  },
  sess(d) {                                // validasi sesi yang dilaporkan native
    if (!d || typeof d.id !== 'string' || d.id.length > 80 || typeof d.sid !== 'string' || d.sid.length > 40 || !this.ip(d.host)) return null;
    if (!Number.isInteger(d.port) || d.port < 1024 || d.port > 65535 || !Number.isInteger(d.cap) || d.cap < 1 || d.cap > 4) return null;
    return { id: d.id, sid: d.sid, name: String(d.name || 'Game').slice(0, 60), host: d.host, port: d.port, cap: d.cap };
  }
};

