package com.tyvi.game

import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

private const val TAG = "TyviLan"
private const val SVC = "_tyvi._tcp"
private const val PORT = 47321            // port tetap: dipakai juga untuk probe gateway hotspot
private const val VER = 1
private const val MAX_LINE = 40_000       // > MAX_CODE(24000) + kandidat; batas keras per baris
private const val MAX_CONNS = 6           // koneksi pairing bersamaan (anti-flood)
private const val SESSION_MS = 30_000L    // batas total satu pairing
private val PRIV = Regex("^(10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|172\\.(1[6-9]|2\\d|3[01])\\.\\d{1,3}\\.\\d{1,3})$")
private val BAD_IF = listOf("rmnet", "ccmni", "tun", "v4-", "dummy", "clat", "ppp")

/**
 * Penemuan sesi + pertukaran teks pairing. TIDAK menyentuh WebRTC: WebView tetap membuat offer/answer.
 *  Host : TCP server (port 47321, fallback acak) + iklan NSD "_tyvi._tcp".
 *  Guest: NSD discovery + probe gateway Wi-Fi (untuk hotspot) -> TCP ke host -> tukar baris JSON.
 * Protokol (satu JSON per baris, UTF-8):
 *   host->guest {"t":"banner","v":1,"sid","name","cap"}   guest->host {"t":"hi","v":1,"dev"}
 *   host->guest {"t":"offer","code","cands","slot"} | {"t":"deny","r"}   guest->host {"t":"answer","code","cands"}
 * Native hanya menyampaikan; validasi isi (kode, kandidat) dilakukan di JS.
 */
class LanBridge(private val ctx: Context, private val web: WebView) {
    private class Conn(val id: Int, val sock: Socket) {
        private val out by lazy { sock.getOutputStream() }
        private val inp by lazy { BufferedInputStream(sock.getInputStream(), 8192) }
        @Volatile var hi = false
        fun write(o: JSONObject) { synchronized(this) { out.write((o.toString() + "\n").toByteArray(Charsets.UTF_8)); out.flush() } }
        fun readLine(): String? {
            val buf = ByteArrayOutputStream()
            while (true) {
                val b = inp.read()
                if (b < 0) return if (buf.size() == 0) null else throw IOException("eof")
                if (b == '\n'.code) break
                buf.write(b)
                if (buf.size() > MAX_LINE) throw IOException("line too long")
            }
            return buf.toString("UTF-8")
        }
        fun close() { try { sock.close() } catch (_: Exception) { } }
    }

    private class HostInfo(val sid: String, val name: String, val cap: Int)

    private val main = Handler(Looper.getMainLooper())
    private val pool: ExecutorService = Executors.newCachedThreadPool()
    private val sched = Executors.newSingleThreadScheduledExecutor()
    private val ids = java.util.concurrent.atomic.AtomicInteger(0)
    private val cm = ctx.getSystemService(ConnectivityManager::class.java)
    private val nsd = ctx.getSystemService(NsdManager::class.java)
    @Volatile private var dead = false

    private val hostConns = ConcurrentHashMap<Int, Conn>()
    private val guestConns = ConcurrentHashMap<Int, Conn>()
    @Volatile private var host: HostInfo? = null
    private var server: ServerSocket? = null
    private var regListener: NsdManager.RegistrationListener? = null

    private var discListener: NsdManager.DiscoveryListener? = null
    private var probeTask: ScheduledFuture<*>? = null
    private val known: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val svcCallbacks = ConcurrentHashMap<String, Any>()          // API 34+: ServiceInfoCallback
    private val resolveQ = java.util.ArrayDeque<NsdServiceInfo>()        // API < 34: resolveService harus berurutan
    private var resolving = false

    /* ------------------------------ util ------------------------------ */
    private fun emit(type: String, data: JSONObject) {
        if (dead) return
        val js = "window.TyviLanNative&&window.TyviLanNative.emit(" + JSONObject.quote(type) + "," + JSONObject.quote(data.toString()) + ")"
        main.post { if (!dead) web.evaluateJavascript(js, null) }
    }
    private fun ok(vararg kv: Pair<String, Any?>) = JSONObject().put("ok", true).also { o -> kv.forEach { o.put(it.first, it.second) } }.toString()
    private fun err(m: String) = JSONObject().put("ok", false).put("err", m).toString()
    private fun remaining(deadline: Long): Int = maxOf(1L, deadline - SystemClock.elapsedRealtime()).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    @Suppress("DEPRECATION")
    private fun wifiNetwork(): Network? = try {
        cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
    } catch (e: Exception) { null }

    /** Ikat socket ke Wi-Fi: tanpa ini, Wi-Fi tanpa internet bisa kalah dari data seluler untuk alamat LAN. */
    private fun bindWifi(s: Socket) { try { wifiNetwork()?.bindSocket(s) } catch (e: Exception) { Log.w(TAG, "bindSocket: $e") } }

    private fun gatewayIp(): String? = try {
        val lp = wifiNetwork()?.let { cm.getLinkProperties(it) }
        lp?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
    } catch (e: Exception) { null }

    private fun localIps(): JSONArray {
        val set = LinkedHashSet<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (BAD_IF.any { n.startsWith(it) }) continue          // lewati data seluler/VPN
                for (ia in ni.inetAddresses) { val a = ia.hostAddress ?: continue; if (ia is Inet4Address && PRIV.matches(a)) set.add(a) }
            }
            wifiNetwork()?.let { cm.getLinkProperties(it) }?.linkAddresses?.forEach { la ->
                val a = la.address; val s = a.hostAddress
                if (a is Inet4Address && s != null && PRIV.matches(s)) set.add(s)
            }
        } catch (e: Exception) { Log.w(TAG, "localIps: $e") }
        return JSONArray(set.toList())
    }

    /* ------------------------------ API untuk JS ------------------------------ */
    @JavascriptInterface
    fun info(): String = try {
        val perm = Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(android.Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
        ok("sdk" to Build.VERSION.SDK_INT, "ips" to localIps(), "gw" to gatewayIp(), "nearby" to perm)
    } catch (e: Exception) { err(e.toString()) }

    /* ---------- HOST ---------- */
    @Synchronized @JavascriptInterface
    fun hostStart(sid: String, name: String, cap: Int): String {
        try {
            if (dead || sid.length !in 4..40 || cap !in 1..4) return err("parameter tidak valid")
            stopHostInternal()
            val ss = try { ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) } }
                     catch (e: IOException) { ServerSocket(0) }                 // port tetap dipakai app lain: pakai acak (NSD saja)
            server = ss
            val nm = name.take(30)
            host = HostInfo(sid, nm, cap)
            pool.execute { acceptLoop(ss) }
            val rl = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) { emit("hostAdv", JSONObject().put("ok", true)) }
                override fun onRegistrationFailed(i: NsdServiceInfo, code: Int) { emit("hostAdv", JSONObject().put("ok", false).put("code", code)) }
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, code: Int) {}
            }
            regListener = rl
            try {
                val si = NsdServiceInfo().apply {
                    serviceName = "Tyvi-" + sid.take(6); serviceType = SVC; port = ss.localPort
                    setAttribute("v", "1"); setAttribute("sid", sid); setAttribute("cap", cap.toString()); setAttribute("nm", nm)
                }
                nsd.registerService(si, NsdManager.PROTOCOL_DNS_SD, rl)
            } catch (e: Exception) { emit("hostAdv", JSONObject().put("ok", false).put("code", -1)); regListener = null }
            return ok("port" to ss.localPort, "fixedPort" to (ss.localPort == PORT))
        } catch (e: Exception) { return err(e.toString()) }
    }

    @Synchronized @JavascriptInterface fun hostStop() { stopHostInternal() }

    private fun stopHostInternal() {
        host = null
        regListener?.let { try { nsd.unregisterService(it) } catch (_: Exception) { } }
        regListener = null
        try { server?.close() } catch (_: Exception) { }
        server = null
        hostConns.values.forEach { it.close() }; hostConns.clear()
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (!dead && !ss.isClosed) {
            val s = try { ss.accept() } catch (e: IOException) { break }
            if (hostConns.size >= MAX_CONNS) { try { s.close() } catch (_: Exception) { }; continue }
            try { pool.execute { hostConn(s) } } catch (e: RejectedExecutionException) { try { s.close() } catch (_: Exception) { } }
        }
    }

    private fun hostConn(s: Socket) {
        val c = Conn(ids.incrementAndGet(), s); hostConns[c.id] = c
        val deadline = SystemClock.elapsedRealtime() + SESSION_MS
        try {
            val h = host ?: return
            s.tcpNoDelay = true
            c.write(JSONObject().put("t", "banner").put("v", VER).put("sid", h.sid).put("name", h.name).put("cap", h.cap))
            s.soTimeout = 8000
            val hi = JSONObject(c.readLine() ?: return)               // probe gateway: tutup tanpa 'hi' => tidak ada undangan
            if (hi.optString("t") != "hi" || hi.optInt("v") != VER || hi.optString("dev").length !in 8..64) return
            c.hi = true
            emit("hostGuest", JSONObject().put("conn", c.id))
            s.soTimeout = remaining(deadline)
            val ans = JSONObject(c.readLine() ?: return)
            if (ans.optString("t") != "answer") return
            emit("hostAnswer", JSONObject().put("conn", c.id).put("code", ans.optString("code")).put("cands", ans.optJSONArray("cands") ?: JSONArray()))
            s.soTimeout = minOf(remaining(deadline), 5000)
            while (c.readLine() != null) { /* abaikan; JS menutup via hostClose */ }
        } catch (_: Exception) {
        } finally {
            hostConns.remove(c.id); c.close()
            if (c.hi) emit("hostGuestClosed", JSONObject().put("conn", c.id))
        }
    }

    @JavascriptInterface
    fun hostReply(conn: Int, json: String) {
        val c = hostConns[conn] ?: return
        try {
            val o = JSONObject(json)
            pool.execute { try { c.write(o) } catch (e: Exception) { c.close() } }
            if (o.optString("t") == "deny") sched.schedule({ c.close() }, 1, TimeUnit.SECONDS)
        } catch (e: Exception) { c.close() }
    }
    @JavascriptInterface fun hostClose(conn: Int) { hostConns[conn]?.close() }

    /* ---------- GUEST ---------- */
    @JavascriptInterface
    fun connect(hostIp: String, port: Int, dev: String): Int {
        if (dead || !PRIV.matches(hostIp) || port !in 1024..65535 || dev.length !in 8..64 || guestConns.size >= MAX_CONNS) return -1
        val s = Socket(); val c = Conn(ids.incrementAndGet(), s); guestConns[c.id] = c
        try { pool.execute { guestConn(c, hostIp, port, dev) } } catch (e: RejectedExecutionException) { guestConns.remove(c.id); c.close(); return -1 }
        return c.id
    }

    private fun guestConn(c: Conn, hostIp: String, port: Int, dev: String) {
        val s = c.sock; val deadline = SystemClock.elapsedRealtime() + SESSION_MS
        var why = "closed"
        try {
            bindWifi(s)
            s.connect(InetSocketAddress(hostIp, port), 4000)
            s.tcpNoDelay = true; s.soTimeout = 5000
            val b = JSONObject(c.readLine() ?: throw IOException("no banner"))
            if (b.optString("t") != "banner" || b.optInt("v") != VER) throw IOException("bad banner")
            c.write(JSONObject().put("t", "hi").put("v", VER).put("dev", dev))
            var n = 0
            while (n++ < 4) {
                s.soTimeout = remaining(deadline)
                val line = c.readLine() ?: break
                emit("guestMsg", JSONObject().put("conn", c.id).put("msg", JSONObject(line)))
            }
        } catch (e: SocketTimeoutException) { why = "timeout"
        } catch (e: Exception) { why = e.javaClass.simpleName
        } finally {
            guestConns.remove(c.id); c.close()
            emit("guestClosed", JSONObject().put("conn", c.id).put("why", why))
        }
    }

    @JavascriptInterface
    fun guestSend(conn: Int, json: String) {
        val c = guestConns[conn] ?: return
        try { val o = JSONObject(json); pool.execute { try { c.write(o) } catch (e: Exception) { c.close() } } } catch (e: Exception) { c.close() }
    }
    @JavascriptInterface fun closeConn(conn: Int) { guestConns[conn]?.close() }

    /* ---------- discovery ---------- */
    @Synchronized @JavascriptInterface
    fun discoveryStart(): String {
        try {
            if (dead) return err("ditutup")
            discoveryStopInternal()
            val dl = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t: String) {}
                override fun onServiceFound(i: NsdServiceInfo) { if (i.serviceType.startsWith(SVC)) resolve(i) }
                override fun onServiceLost(i: NsdServiceInfo) { lost("nsd:" + i.serviceName) }
                override fun onDiscoveryStopped(t: String) {}
                override fun onStartDiscoveryFailed(t: String, code: Int) { emit("discoveryError", JSONObject().put("code", code)) }
                override fun onStopDiscoveryFailed(t: String, code: Int) {}
            }
            discListener = dl
            nsd.discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, dl)
            probeTask = sched.scheduleWithFixedDelay({ try { probeGateway() } catch (_: Exception) { } }, 0, 5, TimeUnit.SECONDS)
            return ok()
        } catch (e: Exception) { return err(e.toString()) }
    }

    @Synchronized @JavascriptInterface fun discoveryStop() { discoveryStopInternal() }

    private fun discoveryStopInternal() {
        probeTask?.cancel(false); probeTask = null
        discListener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) { } }
        discListener = null
        if (Build.VERSION.SDK_INT >= 34) unregisterAllInfoCallbacks()
        synchronized(resolveQ) { resolveQ.clear(); resolving = false }
        known.clear()
    }

    private fun lost(id: String) { if (known.remove(id)) emit("sessionLost", JSONObject().put("id", id)) }

    private fun resolve(i: NsdServiceInfo) {
        if (Build.VERSION.SDK_INT >= 34) resolveModern(i) else synchronized(resolveQ) { resolveQ.add(i); if (!resolving) nextResolve() }
    }

    @TargetApi(34)
    private fun resolveModern(i: NsdServiceInfo) {
        val key = i.serviceName
        val cb = object : NsdManager.ServiceInfoCallback {
            override fun onServiceInfoCallbackRegistrationFailed(code: Int) {}
            override fun onServiceUpdated(r: NsdServiceInfo) { report(r) }
            override fun onServiceLost() { lost("nsd:$key") }
            override fun onServiceInfoCallbackUnregistered() {}
        }
        (svcCallbacks.put(key, cb) as? NsdManager.ServiceInfoCallback)?.let { try { nsd.unregisterServiceInfoCallback(it) } catch (_: Exception) { } }
        try { nsd.registerServiceInfoCallback(i, pool, cb) } catch (e: Exception) { Log.w(TAG, "registerServiceInfoCallback: $e") }
    }

    @TargetApi(34)
    private fun unregisterAllInfoCallbacks() {
        svcCallbacks.values.forEach { (it as? NsdManager.ServiceInfoCallback)?.let { cb -> try { nsd.unregisterServiceInfoCallback(cb) } catch (_: Exception) { } } }
        svcCallbacks.clear()
    }

    @Suppress("DEPRECATION")
    private fun nextResolve() {                                  // dipanggil di dalam synchronized(resolveQ)
        val i = resolveQ.poll() ?: run { resolving = false; return }
        resolving = true
        try {
            nsd.resolveService(i, object : NsdManager.ResolveListener {
                override fun onResolveFailed(s: NsdServiceInfo, code: Int) { synchronized(resolveQ) { nextResolve() } }
                override fun onServiceResolved(r: NsdServiceInfo) { report(r); synchronized(resolveQ) { nextResolve() } }
            })
        } catch (e: Exception) { resolving = false }
    }

    @Suppress("DEPRECATION")
    private fun ipv4Of(r: NsdServiceInfo): String? =
        if (Build.VERSION.SDK_INT >= 34) r.hostAddresses.firstOrNull { it is Inet4Address }?.hostAddress
        else (r.host as? Inet4Address)?.hostAddress

    private fun report(r: NsdServiceInfo) {
        val ip = ipv4Of(r) ?: return
        if (!PRIV.matches(ip)) return
        fun a(k: String) = r.attributes[k]?.toString(Charsets.UTF_8) ?: ""
        val sid = a("sid")
        if (sid.isEmpty() || sid == host?.sid) return              // jangan menampilkan sesi milik sendiri
        val id = "nsd:" + r.serviceName; known.add(id)
        emit("session", JSONObject().put("id", id).put("sid", sid).put("name", a("nm").ifEmpty { r.serviceName })
            .put("host", ip).put("port", r.port).put("cap", a("cap").toIntOrNull() ?: 4).put("src", "nsd"))
    }

    /** Hotspot: NSD sering tidak melintasi AP. Gateway Wi-Fi = HP host, jadi coba port tetap di sana. */
    private fun probeGateway() {
        val gw = gatewayIp()?.takeIf { PRIV.matches(it) } ?: return
        val id = "gw:$gw"
        val s = Socket(); val c = Conn(-1, s)
        try {
            bindWifi(s); s.connect(InetSocketAddress(gw, PORT), 1200); s.soTimeout = 1500
            val b = JSONObject(c.readLine() ?: return)
            if (b.optString("t") != "banner" || b.optInt("v") != VER) return
            val sid = b.optString("sid"); if (sid.isEmpty() || sid == host?.sid) return
            known.add(id)
            emit("session", JSONObject().put("id", id).put("sid", sid).put("name", b.optString("name", "Game")).put("host", gw)
                .put("port", PORT).put("cap", b.optInt("cap", 4)).put("src", "gw"))
        } catch (e: Exception) { lost(id) } finally { c.close() }
    }

    /* ------------------------------ siklus hidup ------------------------------ */
    fun shutdown() {
        dead = true
        synchronized(this) { stopHostInternal(); discoveryStopInternal() }
        guestConns.values.forEach { it.close() }; guestConns.clear()
        sched.shutdownNow(); pool.shutdownNow()
    }
}
