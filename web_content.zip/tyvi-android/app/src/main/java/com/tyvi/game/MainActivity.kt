package com.tyvi.game

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest

/** WebView penampung tyvi.html. Tanpa androidx. Jembatan LAN = LanBridge (JavascriptInterface "TyviLan"). */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var lan: LanBridge
    private var fileCb: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        // targetSdk 35+ memaksa edge-to-edge: beri padding sesuai system bars / cutout
        web.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            }
            ins
        }
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true                 // localStorage (Store) dipakai game
            allowFileAccess = false                  // android_asset tetap bisa dibaca; file system lain tidak
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        // Kunci navigasi: hanya halaman lokal. Jembatan hanya boleh dilihat halaman milik kita.
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean =
                !r.url.toString().startsWith(PAGE_PREFIX)
        }
        web.webChromeClient = object : WebChromeClient() {   // <input type=file> (impor JSON / sprite)
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { startActivityForResult(p.createIntent(), REQ_FILE); true }
                catch (e: Exception) { fileCb = null; cb.onReceiveValue(null); false }
            }
        }
        lan = LanBridge(applicationContext, web)
        web.addJavascriptInterface(lan, "TyviLan")           // -> window.TyviLan di JS

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), REQ_PERM)

        if (savedInstanceState == null) web.loadUrl(PAGE_PREFIX + "tyvi.html") else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); web.saveState(out) }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_FILE) { fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); fileCb = null }
    }

    // Pencarian dihentikan saat app tak terlihat; sesi host/WebRTC ditutup total di onDestroy.
    override fun onStop() { lan.discoveryStop(); super.onStop() }
    override fun onDestroy() { lan.shutdown(); web.removeJavascriptInterface("TyviLan"); web.destroy(); super.onDestroy() }

    companion object {
        const val PAGE_PREFIX = "file:///android_asset/"
        private const val REQ_FILE = 7
        private const val REQ_PERM = 8
    }
}
