plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tyvi.game"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.tyvi.game"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0-lan"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = false } }
}
// Sengaja TANPA dependensi (framework Android saja): tidak ada androidx / library pihak ketiga.
