const $ = selector => document.querySelector(selector);
const canvas = $('#drawing-canvas');
const context = canvas.getContext('2d');
const tools = {
  crayon: { color: '#ef3558', width: 12, label: 'RED CRAYON' },
  pencil: { color: '#151515', width: 3, label: 'BLACK PENCIL' },
  green: { color: '#28df17', width: 7, label: 'GREEN PENCIL' },
  brush: { color: '#167bdf', width: 9, label: 'BLUE BRUSH' }
};
let selectedTool = 'crayon';
let drawing = false;
let lastPoint = null;
let publishing = false;
let drawings = [];

function sizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const oldCanvas = document.createElement('canvas');
  oldCanvas.width = canvas.width;
  oldCanvas.height = canvas.height;
  if (oldCanvas.width && oldCanvas.height) oldCanvas.getContext('2d').drawImage(canvas, 0, 0);
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(rect.width * ratio);
  canvas.height = Math.round(rect.height * ratio);
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.fillStyle = '#fff';
  context.fillRect(0, 0, rect.width, rect.height);
  if (oldCanvas.width && oldCanvas.height) context.drawImage(oldCanvas, 0, 0, oldCanvas.width, oldCanvas.height, 0, 0, rect.width, rect.height);
}
function pointFromEvent(event) {
  const rect = canvas.getBoundingClientRect();
  return { x: event.clientX - rect.left, y: event.clientY - rect.top };
}
function beginStroke(event) {
  event.preventDefault();
  canvas.setPointerCapture(event.pointerId);
  drawing = true;
  lastPoint = pointFromEvent(event);
  const tool = tools[selectedTool];
  context.beginPath();
  context.fillStyle = tool.color;
  context.arc(lastPoint.x, lastPoint.y, tool.width / 2, 0, Math.PI * 2);
  context.fill();
}
function continueStroke(event) {
  if (!drawing) return;
  const point = pointFromEvent(event);
  const tool = tools[selectedTool];
  context.beginPath();
  context.strokeStyle = tool.color;
  context.lineWidth = tool.width;
  context.lineCap = 'round';
  context.lineJoin = 'round';
  context.moveTo(lastPoint.x, lastPoint.y);
  context.lineTo(point.x, point.y);
  context.stroke();
  lastPoint = point;
}
function endStroke() {
  drawing = false;
  lastPoint = null;
}
function selectTool(button) {
  selectedTool = button.dataset.tool;
  document.querySelectorAll('.tool').forEach(item => {
    const active = item === button;
    item.classList.toggle('is-selected', active);
    item.setAttribute('aria-pressed', String(active));
  });
  $('#tool-caption').textContent = tools[selectedTool].label;
}
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char]));
}
function renderGallery() {
  $('#gallery-count').textContent = drawings.length;
  if (!drawings.length) {
    $('#gallery-feed').innerHTML = '<div class="empty-gallery"><span class="empty-doodle" aria-hidden="true">☹</span><h3>All caught up!</h3><p>You saw every drawing on Carnblox. People’s drawings will show up here.</p></div>';
    return;
  }
  $('#gallery-feed').innerHTML = drawings.map(item => {
    const name = escapeHtml(item.username || 'player');
    const title = escapeHtml(item.title || 'Untitled drawing');
    const profile = 'https://websim.com/@' + encodeURIComponent(item.username || '');
    const avatar = 'https://images.websim.com/avatar/' + encodeURIComponent(item.username || '');
    const date = item.created_at ? new Date(item.created_at).toLocaleDateString([], { month: 'short', day: 'numeric' }) : '';
    return '<article class="drawing-card"><img class="drawing-image" src="' + escapeHtml(item.image_url) + '" alt="' + title + '" loading="lazy"><div class="drawing-info"><h3>' + title + '</h3><div class="drawing-author"><a class="author-link" href="' + profile + '" target="_blank" rel="noopener noreferrer"><img src="' + avatar + '" alt=""><span>@' + name + '</span></a><time>' + date + '</time></div></div></article>';
  }).join('');
}
async function loadDrawings() {
  try {
    const response = await fetch('/api/drawings', { cache: 'no-store' });
    if (!response.ok) throw new Error('The gallery is taking a break.');
    drawings = await response.json();
    renderGallery();
  } catch {
    $('#gallery-count').textContent = '—';
    $('#gallery-feed').innerHTML = '<p class="gallery-state">Couldn’t load the wall right now. Try again in a moment.</p>';
  }
}
async function publishDrawing() {
  if (publishing) return;
  const title = $('#drawing-name').value.trim();
  if (!title) {
    $('#status').textContent = 'Give your drawing a name first.';
    $('#drawing-name').focus();
    return;
  }
  if (!window.websim?.upload) {
    $('#status').textContent = 'Uploads are unavailable right now.';
    return;
  }
  let user = null;
  try { user = await window.websim.getUser(); } catch { /* Show the sign-in message below. */ }
  if (!user?.id || user.username === 'anonymous') {
    $('#status').textContent = 'Sign in to Websim to share your drawing with everyone.';
    return;
  }
  publishing = true;
  $('#publish-button').disabled = true;
  $('#publish-button').innerHTML = '<span class="publish-spinner" aria-hidden="true"></span> Publishing';
  $('#status').textContent = 'Putting your drawing on the wall...';
  try {
    const blob = await new Promise((resolve, reject) => canvas.toBlob(result => result ? resolve(result) : reject(new Error('Could not export this drawing.')), 'image/png'));
    const file = new File([blob], 'carn-drawing.png', { type: 'image/png' });
    const imageUrl = await window.websim.upload(file);
    const response = await fetch('/api/drawings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, image_url: imageUrl })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not publish this drawing.');
    $('#status').textContent = 'Your drawing is on the wall!';
    drawings.unshift(result.drawing);
    renderGallery();
    $('#gallery-dialog').showModal();
  } catch (error) {
    $('#status').textContent = error.message || 'Could not publish this drawing. Try again.';
  } finally {
    publishing = false;
    $('#publish-button').disabled = false;
    $('#publish-button').innerHTML = 'Publish <span aria-hidden="true">↗</span>';
  }
}

document.querySelectorAll('.tool').forEach(button => button.addEventListener('click', () => selectTool(button)));
canvas.addEventListener('pointerdown', beginStroke);
canvas.addEventListener('pointermove', continueStroke);
canvas.addEventListener('pointerup', endStroke);
canvas.addEventListener('pointercancel', endStroke);
window.addEventListener('resize', sizeCanvas);
$('#publish-button').addEventListener('click', publishDrawing);
$('#gallery-button').addEventListener('click', () => {
  $('#gallery-dialog').showModal();
  if (!drawings.length) loadDrawings();
});
$('#close-gallery').addEventListener('click', () => $('#gallery-dialog').close());
$('#gallery-dialog').addEventListener('click', event => {
  if (event.target === $('#gallery-dialog')) $('#gallery-dialog').close();
});
$('#drawing-name').addEventListener('input', () => {
  if ($('#status').textContent === 'Give your drawing a name first.') $('#status').textContent = '';
});
if (window.websim?.getUser) {
  window.websim.getUser().then(user => {
    $('.sign-in').hidden = !!user?.id && user.username !== 'anonymous';
  }).catch(() => {});
}
sizeCanvas();
loadDrawings();
