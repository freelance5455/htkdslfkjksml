plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.maintenanceapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.maintenanceapp"
        minSdk = 23
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.0"
    }
}
