
package com.factofern.revision

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Factofern"
        val message = intent.getStringExtra("message") ?: "Revision reminder"
        val id = intent.getIntExtra("id", System.currentTimeMillis().toInt())
        NotificationHelper.show(context, title, message, id)

        if (intent.getBooleanExtra("daily", false)) {
            val hour = intent.getIntExtra("hour", 20)
            val minute = intent.getIntExtra("minute", 0)
            AlarmScheduler.scheduleDaily(context, title, message, hour, minute)
        }
    }
}
