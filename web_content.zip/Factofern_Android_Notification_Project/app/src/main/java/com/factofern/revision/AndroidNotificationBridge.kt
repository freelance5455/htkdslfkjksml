
package com.factofern.revision

import android.content.Context
import android.webkit.JavascriptInterface

class AndroidNotificationBridge(private val context: Context) {

    @JavascriptInterface
    fun scheduleDailyNotification(title: String, message: String, hour: Int, minute: Int) {
        AlarmScheduler.scheduleDaily(context, title, message, hour, minute)
    }

    @JavascriptInterface
    fun cancelDailyNotification() {
        AlarmScheduler.cancelDaily(context)
    }

    @JavascriptInterface
    fun testNotification(title: String, message: String) {
        NotificationHelper.show(context, title, message, System.currentTimeMillis().toInt())
    }

    @JavascriptInterface
    fun scheduleRevisionReminder(id: String, title: String, message: String, triggerMillis: Long) {
        AlarmScheduler.scheduleRevision(context, id, title, message, triggerMillis)
    }

    @JavascriptInterface
    fun cancelRevisionReminder(id: String) {
        AlarmScheduler.cancelRevision(context, id)
    }

    @JavascriptInterface
    fun cancelAllRevisionReminders() {
        AlarmScheduler.cancelAllRevisions(context)
    }
}
