
package com.factofern.revision

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {
    private const val DAILY_REQ = 100
    private const val REV_BASE = 100000

    fun scheduleDaily(context: Context, title: String, message: String, hour: Int, minute: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("title", title); putExtra("message", message)
            putExtra("daily", true); putExtra("hour", hour); putExtra("minute", minute)
            putExtra("id", DAILY_REQ)
        }
        val pi = PendingIntent.getBroadcast(context, DAILY_REQ, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm(context).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    fun cancelDaily(context: Context) {
        alarm(context).cancel(pending(context, DAILY_REQ))
    }

    fun scheduleRevision(context: Context, id: String, title: String, message: String, triggerMillis: Long) {
        val req = REV_BASE + (id.hashCode() and 0x7FFF)
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("title", title); putExtra("message", message); putExtra("id", req)
        }
        val pi = PendingIntent.getBroadcast(context, req, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm(context).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
    }

    fun cancelRevision(context: Context, id: String) {
        val req = REV_BASE + (id.hashCode() and 0x7FFF)
        alarm(context).cancel(pending(context, req))
    }

    fun cancelAllRevisions(context: Context) {
        // Revision IDs are owned by the HTML localStorage. Individual cancellations
        // are performed when a chapter becomes incomplete.
    }

    private fun pending(context: Context, req: Int): PendingIntent {
        val i = Intent(context, NotificationReceiver::class.java)
        return PendingIntent.getBroadcast(context, req, i,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            ?: PendingIntent.getBroadcast(context, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun alarm(context: Context) = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
}
