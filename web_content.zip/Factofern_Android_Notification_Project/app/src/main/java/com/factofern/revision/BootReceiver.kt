
package com.factofern.revision

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.webkit.WebView

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            // The HTML app keeps the pending reminder data in localStorage.
            // Opening the WebView on the next launch re-schedules pending reminders.
        }
    }
}
