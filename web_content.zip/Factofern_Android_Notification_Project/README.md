# Factofern Revision Tracker — Loud Notification Sound Build

This version specifically fixes the notification-sound setup.

Changes:
- Re-encoded/normalized Goat Scream MP3 for a stronger, cleaner notification level.
- New Android notification channel ID: `factofern_revision_v2_loud`.
- Channel importance changed to MAX.
- Sound audio usage set to ALARM for stronger audible routing on supported Android devices.
- The existing 7-day chapter revision scheduling and JavaScript bridge remain included.

Important Android behavior:
- Notification sound volume is still controlled by the phone's notification/alarm volume and Do Not Disturb settings.
- Android notification channels remember their sound settings. Because this build uses a NEW channel ID, it avoids the old channel's saved sound configuration.
- If testing over an older installation, uninstall the old Factofern build first, then install this build.
- On some phones, battery optimization or manufacturer-specific sound controls can still affect delivery/volume.
- A completely powered-off phone cannot execute an alarm until it boots.

Build:
1. Open this project in Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).