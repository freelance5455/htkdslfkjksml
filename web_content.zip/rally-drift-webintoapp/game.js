/* Game: renderer, camera, input, main menu, garage (car + paint), Stage mode (1/2/5/10 km or endless), Circuit mode (1-5 laps), replay / new, best times, pause, HUD, minimap. */
(() => {
  const $ = (id) => document.getElementById(id);
  const OFF_EDGE = 10;                              // metres beyond the road EDGE before you are put back on the road
  const LOOP_KM = 1.7;                              // length of one circuit lap
  let LAPS = 3;

  const TOUCH = !!(window.RallyTouch && window.RallyTouch.enabled);          // phone / tablet: touch buttons + a lighter renderer
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, TOUCH ? 1.5 : 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.id = 'view';
  document.body.prepend(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xa5d8ff);
  scene.fog = new THREE.Fog(0xa5d8ff, 140, 340);
  const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.5, 2000);

  scene.add(new THREE.HemisphereLight(0xdff2ff, 0x5a8f3a, 0.85));
  const sun = new THREE.DirectionalLight(0xfff2d0, 0.9);
  sun.castShadow = true; sun.shadow.mapSize.set(TOUCH ? 1024 : 2048, TOUCH ? 1024 : 2048);
  Object.assign(sun.shadow.camera, { left: -45, right: 45, top: 45, bottom: -45, near: 1, far: 200 });
  sun.shadow.bias = -0.0005;
  scene.add(sun, sun.target);

  const stageTrack = new Track(scene);        // endless world (also the menu backdrop at first start)
  let circuitTrack = null;                    // created on first Circuit start
  let track = stageTrack;
  const car = new Car(scene); scene.add(car.group);
  const dust = new Dust(scene);

  function onResize() {
    renderer.setSize(innerWidth, innerHeight);
    camera.aspect = innerWidth / Math.max(1, innerHeight); camera.updateProjectionMatrix();
  }
  addEventListener('resize', onResize);
  addEventListener('orientationchange', () => { onResize(); setTimeout(onResize, 300); });   // some mobile browsers report the new size late
  if (window.visualViewport) visualViewport.addEventListener('resize', onResize);          // address bar showing / hiding

  // ---------- state ----------
  // state: 'menu' | 'garage' | 'countdown' | 'racing' | 'paused' | 'finished'      mode: 'stage' | 'circuit'
  let state = 'menu', mode = 'stage', resumeState = 'racing';
  let countdown = 3.2, raceTime = 0, maxIdx = 0, nextCp = 500, topSpeed = 0, driftScore = 0, msgTimer = 0, wrong = 0;
  let lapTimes = [], lapStart = 0, finishDelay = 0, menuT = 0, hudKey = '';
  let camH = 0, camY = 0, steerSmooth = 0, lastCd = 0;
  let prev = performance.now(), acc = 0, booted = false, bootFrames = 0;
  const pv = { x: 0, y: 0, z: 0, h: 0 };            // car state of the previous physics step (render interpolation)
  const hudCache = {};
  const setT = (id, v) => { if (hudCache[id] !== v) { hudCache[id] = v; $(id).textContent = v; } };
  const hudSet = setT;
  let pr = Math.min(devicePixelRatio, TOUCH ? 1.5 : 2), prAcc = 0, prN = 0;   // adaptive resolution: drops the pixel ratio if the GPU struggles
  function adaptRes(dt) {
    prAcc += dt; prN++;
    if (prAcc < 1.5) return;
    const avg = prAcc / prN; prAcc = prN = 0;
    if (avg > 0.026 && pr > 1) { pr = Math.max(1, pr - 0.25); renderer.setPixelRatio(pr); }
  }
  const STEP = 1 / 60;

  // ---------- stage length, current run (mode + length + seed) and best times ----------
  const LAP_OPTS = [1, 2, 3, 4, 5], STAGE_OPTS = [1, 2, 5, 10, 0], STORE_KM = 'rallydrift.laps', STORE_STAGE = 'rallydrift.stagekm', STORE_BEST = 'rallydrift.bests';
  let laps = 3, stageKm = 0, run = null, finalTime = 0, prevBest = null, prevLast = null;
  try { const v = +RallyStore.get(STORE_KM); if (LAP_OPTS.includes(v)) laps = v; } catch (e) { /* ignore */ }
  try { const v = +RallyStore.get(STORE_STAGE); if (STAGE_OPTS.includes(v)) stageKm = v; } catch (e) { /* ignore */ }
  let bests = {};
  try { bests = JSON.parse(RallyStore.get(STORE_BEST)) || {}; } catch (e) { bests = {}; }
  function saveBests() {
    const ks = Object.keys(bests); if (ks.length > 40) delete bests[ks[0]];
    try { RallyStore.set(STORE_BEST, JSON.stringify(bests)); } catch (e) { /* ignore */ }
  }
  const timed = () => run.mode === 'circuit' || run.n > 0;      // endless stage has no finish, so no times
  const newSeed = () => Math.floor(Math.random() * 2147483000) + 1;

  const ui = { menu: $('menu'), garage: $('garage'), pause: $('pause'), results: $('results'), hud: $('hud') };
  const show = (el, on) => el.classList.toggle('hidden', !on);
  function setState(s) {
    state = s;
    document.body.classList.toggle('playing', s !== 'menu' && s !== 'garage');
    if (window.RallyTouch) RallyTouch.show(s === 'countdown' || s === 'racing');
    Sound.scene(s);
    CG.gameplay(s === 'racing');                // CrazyGames: gameplay only counts while actually driving
    show(ui.menu, s === 'menu'); show(ui.garage, s === 'garage'); show(ui.pause, s === 'paused'); show(ui.hud, s !== 'menu' && s !== 'garage');
  }
  const fade = $('fade');
  function flash() {                          // short fade-from-black to hide hard camera cuts
    fade.style.transition = 'none'; fade.style.opacity = 1; void fade.offsetWidth;
    fade.style.transition = 'opacity .55s ease'; fade.style.opacity = 0;
  }
  const blurFocus = () => { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); };

  function fmt(t) {
    const m = Math.floor(t / 60), s = t - m * 60;
    return m + ':' + (s < 10 ? '0' : '') + s.toFixed(3);
  }
  function say(text, secs, small) { $('msg').textContent = text; $('msg').className = small ? 'small' : ''; msgTimer = secs; }

  // remove all meshes of a track (it is rebuilt by reset() when it is used again)
  function wipe(t) {
    for (const g of t.chunks.values()) t.disposeChunk(g);
    for (const m of t.tiles.values()) { scene.remove(m); m.geometry.dispose(); }
    t.chunks.clear(); t.tiles.clear();
  }


  // ---------- garage: selected car + paint (saved in localStorage, car 0 / white is the default) ----------
  const STORE = 'rallydrift.car';
  let sel = { car: 0, color: CAR_COLORS[0].hex };
  try {
    const j = JSON.parse(RallyStore.get(STORE));
    if (j && CAR_MODELS[j.car] && CAR_COLORS.some((c) => c.hex === j.color)) sel = { car: j.car, color: j.color };
  } catch (e) { /* storage unavailable: just use the default */ }
  car.setModel(sel.car, sel.color);
  const saveSel = () => { try { RallyStore.set(STORE, JSON.stringify(sel)); } catch (e) { /* ignore */ } };

  const chips = CAR_MODELS.map((m, i) => {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = m.name;
    b.addEventListener('click', () => pickCar(i)); $('carList').appendChild(b); return b;
  });
  const swatches = CAR_COLORS.map((c) => {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'swatch'; b.title = c.name; b.setAttribute('aria-label', c.name);
    b.style.background = '#' + c.hex.toString(16).padStart(6, '0');
    b.addEventListener('click', () => pickColor(c.hex)); $('swatches').appendChild(b); return b;
  });
  const barFills = Car.stats(0).bars.map(([label]) => {
    const row = document.createElement('div'); row.className = 'stat';
    const name = document.createElement('span'); name.textContent = label;
    const bar = document.createElement('div'); bar.className = 'bar'; const fill = document.createElement('i'); bar.appendChild(fill);
    row.append(name, bar); $('statBars').appendChild(row); return fill;
  });

  // Length row: Circuit -> 1-5 laps, Stage -> 1 / 2 / 5 / 10 km or Endless (rebuilt whenever the mode changes)
  let lenChips = [], lenMode = '';
  function refreshMode() {
    const c = mode === 'circuit';
    if (lenMode !== mode) {
      lenMode = mode; $('lengths').textContent = ''; $('lenHead').textContent = c ? 'Laps' : 'Length';
      lenChips = (c ? LAP_OPTS : STAGE_OPTS).map((v) => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'chip';
        b.textContent = c ? v + (v === 1 ? ' lap' : ' laps') : (v ? v + ' km' : 'Endless');
        b.addEventListener('click', () => pickLength(v)); $('lengths').appendChild(b); return b;
      });
    }
    const cur = c ? laps : stageKm, opts = c ? LAP_OPTS : STAGE_OPTS;
    $('gMode').textContent = c ? 'Circuit, ' + laps + (laps === 1 ? ' lap' : ' laps') : 'Stage, ' + (stageKm ? stageKm + ' km' : 'endless road');
    lenChips.forEach((b, i) => { b.classList.toggle('sel', opts[i] === cur); b.setAttribute('aria-pressed', opts[i] === cur); });
  }
  function pickLength(v) {
    if (mode === 'circuit') { laps = v; try { RallyStore.set(STORE_KM, String(v)); } catch (e) { /* ignore */ } }
    else { stageKm = v; try { RallyStore.set(STORE_STAGE, String(v)); } catch (e) { /* ignore */ } }
    refreshMode(); $('btnPlay').focus();
  }

  function refreshGarage() {
    const m = CAR_MODELS[sel.car], st = Car.stats(sel.car);
    $('carName').textContent = m.name; $('carTag').textContent = m.tag;
    st.bars.forEach(([, v], i) => { barFills[i].style.width = Math.round(v * 100) + '%'; });
    $('nTop').textContent = st.topKmh + ' km/h'; $('nAcc').textContent = st.t100.toFixed(1) + ' s';
    chips.forEach((c, i) => { c.classList.toggle('sel', i === sel.car); c.setAttribute('aria-pressed', i === sel.car); });
    swatches.forEach((b, i) => { const on = CAR_COLORS[i].hex === sel.color; b.classList.toggle('sel', on); b.setAttribute('aria-pressed', on); });
  }
  function pickCar(i) {
    sel.car = (i + CAR_MODELS.length) % CAR_MODELS.length;
    car.setModel(sel.car, sel.color); saveSel(); refreshGarage(); $('btnPlay').focus();
  }
  function pickColor(hex) {
    sel.color = hex; car.setModel(sel.car, sel.color); saveSel(); refreshGarage(); $('btnPlay').focus();
  }
  function openGarage(m) {
    mode = m; menuT = 0;
    camera.fov = 40; camera.updateProjectionMatrix();
    setState('garage'); refreshMode(); refreshGarage(); $('btnPlay').focus();
  }
  function backToMenu() {
    camera.fov = 42; camera.updateProjectionMatrix(); setState('menu'); blurFocus();
  }

  // ---------- pace notes: co-pilot banner + audio ----------
  // track.paceScan() gives the next real turn (peak curvature, direction, total angle, gap to the turn after it).
  // Here it becomes a rally call, the top-centre banner, and exactly one audio cue per turn.
  const paceEl = $('pace'), paceIcon = $('paceIcon'), paceName = $('paceName');
  // classification by peak curvature (1 / radius): hairpin < 25 m radius, tight 25-45 m, medium 45-80 m, fast > 80 m
  const CALLS = [{ name: 'HAIRPIN', min: 0.04, sev: 4 }, { name: 'TIGHT', min: 0.022, sev: 3 }, { name: 'MEDIUM', min: 0.0125, sev: 2 }, { name: 'FAST', min: 0, sev: 1 }];
  const callOf = (k) => CALLS.find((c) => k >= c.min);
  const PACE_COL = { 1: '#7dff7d', 2: '#ffd23f', 3: '#ff9a1a', 4: '#ff5a4a' }, BEND = { 1: 35, 2: 65, 3: 100, 4: 150 };
  const CHICANE_GAP = 26, CHICANE_MAX_ANGLE = 1.9;         // opposite turns closer than 26 m, neither of them a hairpin (< ~110 deg) = chicane
  const paceCalled = new Set();
  let paceT = 0, paceKey = '', paceShown = false;

  // icon: a road bending by an angle that matches the severity (chicane: an S-shaped jog); the arrow head follows the end of the bend
  function paceSvg(sev, left, chi) {
    const f = (v) => +v.toFixed(1), head = (ex, ey, dx, dy) => {
      const px = -dy, py = dx, bx = ex + dx * 1, by = ey + dy * 1;
      return '<polygon fill="currentColor" points="' + [bx + px * 7, by + py * 7, bx - px * 7, by - py * 7, ex + dx * 11, ey + dy * 11].map(f).join(' ') + '"/>';
    };
    if (chi) {
      const x = (v) => (left ? v : 44 - v), pts = [[22, 46], [22, 38], [10, 29], [10, 22], [22, 13]].map(([a, b]) => x(a) + ',' + b).join(' ');
      return '<polyline points="' + pts + '" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>' + head(x(22), 13, 0, -1);
    }
    const th = BEND[sev] * Math.PI / 180, r = 11, sn = Math.sin(th), cs = Math.cos(th);
    const cx = left ? 22 - r : 22 + r, cy = 26;                                // arc centre sits on the inside of the bend
    const ex = left ? cx + r * cs : cx - r * cs, ey = cy - r * sn, dx = left ? -sn : sn, dy = -cs;      // end point + heading after the bend
    return '<path d="M22 46 L22 26 A' + r + ' ' + r + ' 0 0 ' + (left ? 0 : 1) + ' ' + f(ex) + ' ' + f(ey) + '" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>' + head(ex, ey, dx, dy);
  }
  function hidePace() { if (paceShown) { paceShown = false; paceKey = ''; paceEl.classList.add('hidden'); } }

  function paceUpdate(dt) {
    paceT -= dt; if (paceT > 0) return; paceT = 0.1;                       // 10 scans per second is plenty
    const n = wrong > 0.3 ? null : track.paceScan(car.hint, car.speed);
    if (!n) { hidePace(); return; }
    const c = callOf(n.k), left = n.dir > 0;
    const chi = n.gap <= CHICANE_GAP && n.nextDir === -n.dir && n.angle < CHICANE_MAX_ANGLE && n.nextAngle < CHICANE_MAX_ANGLE;
    const sev = chi ? Math.max(c.sev, callOf(n.nextK).sev, 2) : c.sev;
    const name = (chi ? 'CAUTION CHICANE ' : c.name + ' ') + (left ? 'LEFT' : 'RIGHT'), key = name + sev;
    if (key !== paceKey) {
      paceKey = key; paceName.textContent = name; paceIcon.innerHTML = paceSvg(c.sev, left, chi);
      paceEl.style.setProperty('--pc', PACE_COL[sev]); paceEl.classList.toggle('caution', chi);
    }
    if (!paceShown) { paceShown = true; paceEl.classList.remove('hidden'); }
    const callDist = Math.max(45, Math.min(140, 30 + car.speed * 2.4));    // the cue lands a little earlier the faster you go
    paceEl.classList.toggle('near', n.dist <= callDist);
    hudSet('paceDist', Math.round(n.dist / 10) * 10 + ' m');
    if (n.dist <= callDist && !paceCalled.has(n.id) && Sound.pace(sev, n.dir, chi)) {
      paceCalled.add(n.id); if (chi && n.nextId >= 0) paceCalled.add(n.nextId);       // a chicane is one call: its second half stays silent
    }
  }

  // ---------- flow: menu -> garage -> race -> pause / results ----------
  // m: mode, k: laps (circuit) or km (stage, 0 = endless). seed given = replay of exactly that road; no seed = a freshly generated one
  function startRace(m, k, seed) {
    mode = m || mode; if (k === undefined) k = mode === 'circuit' ? laps : stageKm;
    const next = mode === 'circuit' ? (circuitTrack || (circuitTrack = new CircuitTrack(scene))) : stageTrack;
    if (track !== next) wipe(track);
    track = next;
    seed = seed || newSeed();
    run = { mode, n: k, seed, key: mode + ':' + k + ':' + seed };
    LAPS = mode === 'circuit' ? k : 1;
    track.reset(seed, mode === 'circuit' ? LOOP_KM : k);      // same seed + same length = identical road

    const startIdx = mode === 'circuit' ? track.startIdx : 12;
    car.place(track, startIdx); camH = car.h; camY = car.y + 4.8;
    camera.fov = 62; camera.updateProjectionMatrix();
    steerSmooth = 0; acc = 0;
    countdown = 3.2; raceTime = 0; maxIdx = startIdx; nextCp = 500; topSpeed = 0; driftScore = 0; wrong = 0;
    lapTimes = []; lapStart = 0; finishDelay = 0; hudKey = ''; lastCd = 0;
    paceCalled.clear(); hidePace(); paceT = 0;
    const rec = timed() ? bests[run.key] : null;
    $('bestTxt').textContent = rec ? 'Best ' + fmt(rec.best) : '';
    $('msg').textContent = ''; $('msg2').textContent = ''; $('msg2').className = '';
    $('laps').textContent = ''; $('laps').style.display = mode === 'circuit' ? '' : 'none';
    if (mode === 'circuit') buildMapCache();
    show(ui.results, false);
    setState('countdown');
    blurFocus(); flash();
  }

  function goMenu() {
    show(ui.results, false);
    hidePace();
    if (mode === 'stage') track.reset();                      // short fresh stage as menu backdrop
    $('msg2').textContent = '';
    car.place(track, mode === 'circuit' ? track.startIdx : 12);
    steerSmooth = 0; menuT = 0; $('msg').textContent = '';
    camera.fov = 42; camera.updateProjectionMatrix();
    setState('menu');
    blurFocus(); flash();
  }

  function resetToRoad() {
    const i = mode === 'circuit' ? car.hint - 6 : Math.max(track.base + 8, car.hint - 6);
    car.place(track, i); camH = car.h; camY = car.y + 4.8;
    Sound.whoosh();
  }

  function pause() {
    if (state === 'racing' || state === 'countdown') { resumeState = state; setState('paused'); $('btnResume').focus(); }
  }
  function resume() {
    if (state === 'paused') { setState(resumeState); acc = 0; blurFocus(); }
  }

  const fmtD = (x) => (x < 0 ? '-' : '+') + Math.abs(x).toFixed(3) + ' s';
  // better or worse than your best time on this very stage?
  function verdict() {
    if (prevBest === null) return { cls: 'first', text: 'FIRST RUN ON THIS ' + (run.mode === 'circuit' ? 'CIRCUIT' : 'STAGE'), sub: 'Replay it to beat this time' };
    const d = finalTime - prevBest, prev = prevLast !== null ? '\nLast run ' + fmt(prevLast) : '';
    return d < 0
      ? { cls: 'better', text: 'NEW BEST  ' + fmtD(d), sub: 'Previous best ' + fmt(prevBest) + prev }
      : { cls: 'worse', text: 'SLOWER  ' + fmtD(d), sub: 'Your best ' + fmt(prevBest) + prev };
  }
  function finishRace() {
    finalTime = raceTime;
    const rec = bests[run.key];
    prevBest = rec ? rec.best : null; prevLast = rec ? rec.last : null;
    bests[run.key] = { best: prevBest === null ? finalTime : Math.min(prevBest, finalTime), last: finalTime };
    saveBests();
    setState('finished'); say('FINISH!', 3.5); finishDelay = 2.2;
    const v = verdict(); $('msg2').textContent = v.text; $('msg2').className = v.cls;
    Sound.finish(v.cls !== 'worse'); if (v.cls === 'better') CG.happy();
  }
  function showResults() {
    const v = verdict(), isCircuit = run.mode === 'circuit';
    $('rTotal').textContent = fmt(finalTime);
    $('rCaption').textContent = 'Total time  ' + (isCircuit ? run.n + (run.n === 1 ? ' lap' : ' laps') : run.n + ' km stage');
    $('rVerdict').textContent = v.text; $('rVerdict').className = 'verdict ' + v.cls;
    $('rPrev').textContent = v.sub;
    const best = Math.min(...lapTimes);
    $('rLaps').style.display = isCircuit && lapTimes.length ? '' : 'none';
    $('rLaps').innerHTML = lapTimes.map((t, i) => `<li class="${t === best && lapTimes.length > 1 ? 'best' : ''}"><span>Lap ${i + 1}</span><b>${fmt(t)}</b></li>`).join('');
    $('rTop').textContent = Math.round(topSpeed) + ' km/h';
    $('rDrift').textContent = Math.floor(driftScore);
    show(ui.results, true); $('btnAgain').focus();
  }

  $('btnStage').addEventListener('click', () => openGarage('stage'));
  $('btnCircuit').addEventListener('click', () => openGarage('circuit'));
  $('btnPlay').addEventListener('click', () => startRace(mode));
  $('btnBack').addEventListener('click', backToMenu);
  $('prevCar').addEventListener('click', () => pickCar(sel.car - 1));
  $('nextCar').addEventListener('click', () => pickCar(sel.car + 1));
  $('btnResume').addEventListener('click', resume);
  $('btnPauseMenu').addEventListener('click', goMenu);
  $('btnResultsMenu').addEventListener('click', goMenu);
  $('btnAgain').addEventListener('click', () => CG.ad(() => startRace(run.mode, run.n, run.seed)));   // replay: the exact same road
  $('btnNew').addEventListener('click', () => CG.ad(() => startRace(run.mode, run.n)));               // new: another generated road
  addEventListener('pointerdown', () => { try { window.focus(); } catch (e) { /* ignore */ } });
  addEventListener('blur', pause);
  $('btnPauseRestart').addEventListener('click', () => { if (run) startRace(run.mode, run.n, run.seed); });   // restart the same road
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });                      // tab / app in background
  const portraitMQ = matchMedia('(orientation: portrait)');
  const isTouchUI = () => document.body.classList.contains('touch');
  if (window.RallyTouch) {
    RallyTouch.onPause = () => { if (state === 'racing' || state === 'countdown') pause(); };
    RallyTouch.onReset = () => { if (state === 'racing') resetToRoad(); };
  }
  const onRot = (e) => { if (e.matches && isTouchUI()) pause(); };                      // turned the phone upright: stop the race
  portraitMQ.addEventListener ? portraitMQ.addEventListener('change', onRot) : portraitMQ.addListener(onRot);
  const RT = window.RallyTouch ? RallyTouch.keys : {};
  const down = (...codes) => codes.some((c) => keys[c] || RT[c]);          // keyboard OR touch button                            // auto-pause when the window loses focus

  // ---------- input ----------
  const keys = {};
  addEventListener('keydown', (e) => {
    if (e.code === 'Escape') {
      e.preventDefault();
      if (!e.repeat) { if (state === 'paused') resume(); else if (state === 'garage') backToMenu(); else pause(); }
      return;
    }
    if (state === 'garage' && !e.repeat) {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') pickCar(sel.car - 1);
      if (e.code === 'ArrowRight' || e.code === 'KeyD') pickCar(sel.car + 1);
    }
    keys[e.code] = true;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code) && state !== 'menu' && state !== 'paused') e.preventDefault();
    if (e.code === 'KeyR' && state === 'racing') resetToRoad();
    if (e.code === 'Enter' && (state === 'racing' || state === 'countdown') && run) startRace(run.mode, run.n, run.seed);   // restart the same road
  });
  addEventListener('keyup', (e) => { keys[e.code] = false; });

  // ---------- camera ----------
  const angDiff = (a, b) => ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
  function updateCamera(dt) {
    let target = car.h;
    if (car.speed > 6) target = car.h + angDiff(car.h, Math.atan2(car.vx, car.vz)) * 0.5;
    camH += angDiff(camH, target) * Math.min(1, 4 * dt);
    const sx = Math.sin(camH), sz = Math.cos(camH);
    camY += (car.y + 4.8 - camY) * Math.min(1, 6 * dt);
    camera.position.set(car.x - sx * 9.5, camY, car.z - sz * 9.5);
    camera.lookAt(car.x + sx * 5, car.y + 1, car.z + sz * 5);
    const fov = 62 + Math.min(car.speed, 50) * 0.35 + Math.min(12, (fitFactor() - 1) * 10);
    if (Math.abs(camera.fov - fov) > 0.05) { camera.fov += (fov - camera.fov) * Math.min(1, 3 * dt); camera.updateProjectionMatrix(); }
    sun.position.set(car.x + 40, car.y + 70, car.z + 25); sun.target.position.set(car.x, car.y, car.z);
  }
  // narrow / portrait screens have a small horizontal view: pull the camera back so the whole car always fits
  function fitFactor() { const asp = innerWidth / Math.max(1, innerHeight); return Math.min(3.2, Math.max(1, 1.55 / asp)); }
  function garageCamera() {                   // turntable; car sits slightly left so the stats panel stays clear
    const f = fitFactor(), asp = innerWidth / Math.max(1, innerHeight);
    const a = car.h + 0.6 + menuT * 0.45, r = 7.4 * f, side = asp > 1.3 ? 1.6 : 0, lift = (f - 1) * 0.9;
    camera.position.set(car.x + Math.sin(a) * r, car.y + 2.0 + (f - 1) * 0.8, car.z + Math.cos(a) * r);
    camera.lookAt(car.x + Math.cos(a) * side, car.y + 0.8 - lift, car.z - Math.sin(a) * side);
    sun.position.set(car.x + 40, car.y + 70, car.z + 25); sun.target.position.set(car.x, car.y, car.z);
  }
  function menuCamera() {                     // slow showroom sway around the parked car
    const f = fitFactor();
    const a = car.h + 0.75 + Math.sin(menuT * 0.35) * 0.5, r = 8.4 * f;
    camera.position.set(car.x + Math.sin(a) * r, car.y + 2.2 + (f - 1) * 0.8, car.z + Math.cos(a) * r);
    camera.lookAt(car.x, car.y + 0.9 - (f - 1) * 0.5, car.z);
    sun.position.set(car.x + 40, car.y + 70, car.z + 25); sun.target.position.set(car.x, car.y, car.z);
  }

  // ---------- dust ----------
  let dustAcc = 0;
  function emitDust(dt, input) {
    const slide = Math.abs(car.vR) > 2.5 || (input.handbrake && car.speed > 5) || (input.throttle > 0 && car.speed < 8 && car.speed > 0.5);
    const offroad = !car.onRoad && car.speed > 4;
    if (!slide && !offroad) return;
    dustAcc += dt * 36;
    const color = car.onRoad ? 0xcdb08a : 0x8fc86a;
    const sh = Math.sin(car.h), ch = Math.cos(car.h);
    while (dustAcc >= 1) {
      dustAcc -= 1;
      for (const s of [-1, 1]) {
        const ox = -ch * s * 1.0 - sh * 1.4, oz = sh * s * 1.0 - ch * 1.4;
        dust.emit(car.x + ox, car.y + 0.3, car.z + oz, car.vx, car.vz, color);
      }
    }
  }

  // ---------- minimap ----------
  // Stage: heading-up, shows the road ahead.   Circuit: whole loop (north-up) with the car on it.
  const mm = $('minimap'), mctx = mm.getContext('2d');
  let mapCache = null, mapT = null;
  function buildMapCache() {
    const W = mm.width, H = mm.height, c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d');
    let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
    for (const s of track.S) { x0 = Math.min(x0, s.x); x1 = Math.max(x1, s.x); z0 = Math.min(z0, s.z); z1 = Math.max(z1, s.z); }
    const pad = 20, sc = Math.min((W - 2 * pad) / (x1 - x0), (H - 2 * pad) / (z1 - z0));
    mapT = { sc, mx: (x0 + x1) / 2, mz: (z0 + z1) / 2 };
    g.beginPath();
    track.S.forEach((s, i) => { const [px, py] = toMap(s.x, s.z, W, H); i ? g.lineTo(px, py) : g.moveTo(px, py); });
    g.closePath(); g.lineJoin = 'round';
    g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 9; g.stroke();
    g.strokeStyle = '#d9a46f'; g.lineWidth = 5; g.stroke();
    const s0 = track.S[0], [sx, sy] = toMap(s0.x, s0.z, W, H);          // start/finish tick
    g.save(); g.translate(sx, sy); g.rotate(-Math.atan2(s0.tx, s0.tz)); g.fillStyle = '#fff'; g.fillRect(-6, -1.5, 12, 3); g.restore();
    mapCache = c;
  }
  function toMap(x, z, W, H) { return [W / 2 - (x - mapT.mx) * mapT.sc, H / 2 - (z - mapT.mz) * mapT.sc]; }

  function drawCar(cx, cy, rot) {
    mctx.save(); mctx.translate(cx, cy); mctx.rotate(rot);
    mctx.fillStyle = '#ff7a1a'; mctx.strokeStyle = '#fff'; mctx.lineWidth = 2;
    mctx.beginPath(); mctx.moveTo(0, -10); mctx.lineTo(-6, 7); mctx.lineTo(6, 7); mctx.closePath(); mctx.fill(); mctx.stroke();
    mctx.restore();
  }
  function drawMinimap() {
    const W = mm.width, H = mm.height;
    mctx.clearRect(0, 0, W, H);
    if (mode === 'circuit' && mapCache) {
      mctx.drawImage(mapCache, 0, 0);
      const [px, py] = toMap(car.x, car.z, W, H);
      drawCar(px, py, -car.h);
      return;
    }
    const cx = W / 2, cy = H * 0.74, sc = 0.8;
    const sh = Math.sin(car.h), ch = Math.cos(car.h);
    const lo = Math.max(track.base, car.hint - 15), hi = Math.min(track.base + track.S.length - 1, car.hint + 80);
    mctx.beginPath();
    for (let i = lo; i <= hi; i += 2) {
      const s = track.s(i), dx = s.x - car.x, dz = s.z - car.z;
      const f = dx * sh + dz * ch, r = -dx * ch + dz * sh;
      const px = cx + r * sc, py = cy - f * sc;
      i === lo ? mctx.moveTo(px, py) : mctx.lineTo(px, py);
    }
    mctx.lineJoin = 'round'; mctx.lineCap = 'round';
    mctx.strokeStyle = 'rgba(0,0,0,.5)'; mctx.lineWidth = 10; mctx.stroke();
    mctx.strokeStyle = '#d9a46f'; mctx.lineWidth = 6; mctx.stroke();
    drawCar(cx, cy, 0);
  }

  // ---------- main loop ----------
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.1, (now - prev) / 1000); prev = now;

    if (state === 'menu' || state === 'garage') {   // parked car + camera behind the menu / garage
      menuT += dt;
      track.update(car.hint, false, car.x, car.z);
      car.updateMesh(dt); state === 'garage' ? garageCamera() : menuCamera();
      renderer.render(scene, camera);
      Sound.update(null);
      // loading screen leaves only when the 3D menu backdrop (car + road + terrain) is fully built and has been drawn a few times
      if (!booted && ++bootFrames > 8 && !track._pend) { booted = true; if (window.Loader) Loader.done(); CG.loadingStop(); }
      return;
    }
    if (state === 'paused') { Sound.update(null); renderer.render(scene, camera); return; }

    if (portraitMQ.matches && isTouchUI() && (state === 'racing' || state === 'countdown')) { pause(); renderer.render(scene, camera); return; }
    acc += dt;
    const driving = state === 'racing';
    const input = {
      throttle: driving ? ((down('KeyW', 'ArrowUp') ? 1 : 0) - (down('KeyS', 'ArrowDown') ? 1 : 0)) : 0,
      steer: 0,
      handbrake: driving && down('Space'),
    };
    const st = (down('KeyD', 'ArrowRight') ? 1 : 0) - (down('KeyA', 'ArrowLeft') ? 1 : 0);
    steerSmooth += ((driving ? st : 0) - steerSmooth) * Math.min(1, 9 * dt);
    input.steer = steerSmooth;

    if (Math.hypot(car.x - pv.x, car.z - pv.z) > 6) { pv.x = car.x; pv.y = car.y; pv.z = car.z; pv.h = car.h; }   // teleport: no sliding
    while (acc >= STEP) {
      acc -= STEP;
      pv.x = car.x; pv.y = car.y; pv.z = car.z; pv.h = car.h;
      if (state === 'countdown') {
        countdown -= STEP;
        $('msg').className = '';
        if (countdown <= 0) { state = 'racing'; CG.gameplay(true); Sound.scene('racing'); Sound.count(true); say('GO!', 0.8); }
        else { const n = Math.ceil(countdown); if (n !== lastCd) { lastCd = n; if (n <= 3) Sound.count(false); } $('msg').textContent = n; }
      }
      car.step(STEP, input, track);
      const hit = car.collide(track);
      if (hit > 3) Sound.crash(hit);
      if (state === 'racing') {
        raceTime += STEP;
        if (car.hint > maxIdx) maxIdx = car.hint;
        if (car.speed > 8 && Math.abs(car.vR) > 4) driftScore += Math.abs(car.vR) * STEP * 10;
        if (mode === 'stage') {
          if (run.n > 0 && maxIdx >= track.finishIdx) finishRace();
          else if (maxIdx * track.ds >= nextCp) { if (!run.n || nextCp < run.n * 1000 - 100) say('CHECKPOINT  ' + fmt(raceTime), 1.8, true), Sound.chime(); nextCp += 500; }
        } else {
          const done = Math.floor(maxIdx / track.N);          // laps completed = how often index N*k was passed
          if (done > lapTimes.length) {
            const t = raceTime - lapStart; lapTimes.push(t); lapStart = raceTime;
            $('laps').innerHTML = lapTimes.map((v, i) => 'Lap ' + (i + 1) + '  ' + fmt(v)).join('<br>');
            if (done >= LAPS) finishRace(); else { say('LAP ' + done + '  ' + fmt(t), 2, true); Sound.chime(); }
          }
        }
      }
    }

    track.update(car.hint, false, car.x, car.z);
    if (mode === 'stage' && state !== 'finished' && car.hint < track.base + 8) resetToRoad();
    if (state === 'racing' && (Math.abs(car.lat) > track.hw + OFF_EDGE || (mode === 'circuit' && track.offDist > track.hw + OFF_EDGE))) { say('BACK ON ROAD', 1, true); resetToRoad(); }
    if (state === 'racing') {
      const s = track.s(car.hint);
      if (car.vx * s.tx + car.vz * s.tz < -3) { wrong += dt; if (wrong > 1.5) say('WRONG WAY - press R', 0.2, true); } else wrong = 0;
    }

    if (state === 'racing') paceUpdate(dt); else if (paceShown) hidePace();
    if (msgTimer > 0) { msgTimer -= dt; if (msgTimer <= 0) $('msg').textContent = ''; }
    if (state === 'finished' && finishDelay > 0) { finishDelay -= dt; if (finishDelay <= 0) showResults(); }
    topSpeed = Math.max(topSpeed, car.speed * 3.6);
    // physics runs at a fixed 60 Hz; draw the car and camera BETWEEN the last two steps so motion stays smooth at any refresh rate
    const al = acc / STEP, rx = car.x, ry = car.y, rz = car.z, rh = car.h;
    car.x = pv.x + (rx - pv.x) * al; car.y = pv.y + (ry - pv.y) * al; car.z = pv.z + (rz - pv.z) * al; car.h = pv.h + angDiff(pv.h, rh) * al;
    car.updateMesh(dt);
    emitDust(dt, input);
    dust.update(dt);
    updateCamera(dt);
    car.x = rx; car.y = ry; car.z = rz; car.h = rh;
    adaptRes(dt);
    Sound.update({ on: true, speed: car.speed, maxSpeed: car.cfg.maxSpeed, throttle: input.throttle, slip: Math.abs(car.vR), handbrake: input.handbrake, offroad: !car.onRoad && car.speed > 4, model: car.model });

    // HUD
    let label, bar;
    if (mode === 'stage') {
      if (run.n > 0) {
        const meters = Math.min(run.n * 1000, Math.max(0, maxIdx - 25) * track.ds);
        label = 'STAGE  ' + (meters / 1000).toFixed(2) + ' / ' + run.n + ' km'; bar = meters / (run.n * 10);
      } else {
        const meters = maxIdx * track.ds;
        label = 'ENDLESS STAGE  ' + (meters / 1000).toFixed(2) + ' km'; bar = (meters % 1000) / 10;
      }
    } else {
      const done = Math.max(0, Math.floor(maxIdx / track.N));
      label = 'LAP ' + Math.min(LAPS, done + 1) + '/' + LAPS;
      bar = lapTimes.length >= LAPS ? 100 : (Math.max(0, maxIdx) % track.N) / track.N * 100;
    }
    if (label !== hudKey) { hudKey = label; $('lapTxt').textContent = label; }
    const bw = bar.toFixed(1); if (hudCache.bar !== bw) { hudCache.bar = bw; $('barfill').style.width = bw + '%'; }
    setT('speed', Math.round(car.speed * 3.6));
    setT('time', fmt(raceTime));
    setT('best', Math.round(topSpeed));
    setT('last', Math.floor(driftScore));
    drawMinimap();
    renderer.render(scene, camera);
  }

  // ---------- boot: main menu with the endless world as backdrop ----------
  car.place(track, 12);
  camera.fov = 42; camera.updateProjectionMatrix();
  setState('menu');
  if (window.Loader) Loader.set(85, 'Almost ready');
  requestAnimationFrame(frame);
})();
