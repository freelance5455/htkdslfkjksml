/* Sound: everything is generated with the Web Audio API (no audio files needed).
   Engine (rpm + gears + shifts + pops + turbo), drift (tyre squeal + gravel spray + handbrake), gravel / wind, crash,
   countdown, checkpoint / lap chimes, finish jingles, UI blips and a small looping rally-funk track.
   M or the speaker button mutes everything.
   The AudioContext is only created after the first tap / key press (browser autoplay rules). */
const Sound = (() => {
  const AC = window.AudioContext || window.webkitAudioContext;
  const STORE = 'rallydrift.mute';
  const PITCH = [1, 1.2, 0.8, 0.9, 1.05, 0.85, 1.35, 0.95, 0.88, 0.75, 1.1];   // engine pitch per car model
  let ctx = null, master, sfx, music, noiseBuf, E = null, N = null, SQ = null, HS = null, CR = null;
  let adMuted = false;
  let muted = false; try { muted = (window.RallyStore ? RallyStore.get(STORE) : localStorage.getItem(STORE)) === '1'; } catch (e) { /* ignore */ }
  let scene = 'menu', crashAt = 0, musicTimer = 0, step = 0, nextT = 0;
  // engine / drift state
  let lastT = 0, rpmS = 0.15, prevGear = -1, shiftT = 0, prevThr = 0, prevHb = false, wasSliding = false, popAt = 0;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  const SPK_ON = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M3 9v6h4l5 4V5L7 9z"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12"/></svg>';
  const SPK_OFF = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M3 9v6h4l5 4V5L7 9z"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M16 9l6 6M22 9l-6 6"/></svg>';
  function paintButton() {
    const b = document.getElementById('btnSound'); if (!b) return;
    b.innerHTML = muted ? SPK_OFF : SPK_ON; b.setAttribute('aria-pressed', muted); b.setAttribute('aria-label', muted ? 'Sound off' : 'Sound on');
  }

  // ---------------- helpers for the engine ----------------
  // harmonic-rich waveform (like an exhaust pulse train): strong even harmonics, slowly falling off
  function enginePeriodicWave() {
    const n = 30, re = new Float32Array(n + 1), im = new Float32Array(n + 1);
    for (let k = 1; k <= n; k++) im[k] = (1 / Math.pow(k, 1.0)) * (k % 2 === 0 ? 1.35 : 1) * (k === 3 ? 0.75 : 1);
    return ctx.createPeriodicWave(re, im);
  }
  function satCurve(k) {
    const n = 1024, c = new Float32Array(n);
    for (let i = 0; i < n; i++) { const x = i * 2 / n - 1; c[i] = Math.tanh(x * k) / Math.tanh(k); }
    return c;
  }
  function noiseLoop(dest, type, freq, q) {
    const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.value = freq; fl.Q.value = q;
    const gn = ctx.createGain(); gn.gain.value = 0;
    s.connect(fl); fl.connect(gn); if (dest) gn.connect(dest); s.start(0, Math.random());
    return { gn, fl, src: s };
  }

  function init() {
    if (ctx || !AC) return;
    try { ctx = new AC(); } catch (e) { return; }
    master = ctx.createGain(); master.gain.value = muted ? 0 : 0.85; master.connect(ctx.destination);
    sfx = ctx.createGain(); sfx.gain.value = 1; sfx.connect(master);
    music = ctx.createGain(); music.gain.value = 0.6; music.connect(master);

    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

    // ---------- ENGINE ----------
    // two slightly detuned exhaust-pulse oscillators + a sub sine -> soft saturation -> lowpass -> body resonance
    // -> "lumpy" combustion modulation -> output.  Plus exhaust rasp noise and a quiet turbo whistle.
    const wave = enginePeriodicWave();
    const oA = ctx.createOscillator(), oB = ctx.createOscillator(), oSub = ctx.createOscillator();
    oA.setPeriodicWave(wave); oB.setPeriodicWave(wave); oSub.type = 'sine';
    const mixA = ctx.createGain(), mixB = ctx.createGain(), mixS = ctx.createGain();
    mixA.gain.value = 0.55; mixB.gain.value = 0.4; mixS.gain.value = 0.55;
    const sat = ctx.createWaveShaper(); sat.curve = satCurve(2.4); sat.oversample = '2x';
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 0.9; lp.frequency.value = 800;
    const body = ctx.createBiquadFilter(); body.type = 'peaking'; body.frequency.value = 170; body.Q.value = 1.1; body.gain.value = 6;
    const pulse = ctx.createGain(); pulse.gain.value = 0.8;
    const out = ctx.createGain(); out.gain.value = 0;
    oA.connect(mixA); oB.connect(mixB); oSub.connect(mixS);
    mixA.connect(sat); mixB.connect(sat); mixS.connect(sat);
    sat.connect(lp); lp.connect(body); body.connect(pulse); pulse.connect(out); out.connect(sfx);
    // uneven combustion: slow amplitude wobble at half the firing rate
    const lump = ctx.createOscillator(), lumpDepth = ctx.createGain(); lump.type = 'sine'; lumpDepth.gain.value = 0.2;
    lump.connect(lumpDepth); lumpDepth.connect(pulse.gain);
    // exhaust rasp
    const rasp = noiseLoop(out, 'bandpass', 700, 0.7);
    // turbo whistle
    const tw = ctx.createOscillator(), twg = ctx.createGain(); tw.type = 'sine'; tw.frequency.value = 2400; twg.gain.value = 0;
    tw.connect(twg); twg.connect(sfx);
    oA.start(); oB.start(); oSub.start(); lump.start(); tw.start();
    E = { oA, oB, oSub, lp, body, out, lump, lumpDepth, rasp, tw, twg };

    // ---------- CONTINUOUS NOISE LAYERS ----------
    const gravel = noiseLoop(sfx, 'lowpass', 650, 0.7);          // off-road rumble / road roll
    const wind = noiseLoop(sfx, 'lowpass', 1400, 0.5);
    // drift layer 1: gravel / dirt spray hiss while sliding
    const hiss = noiseLoop(sfx, 'bandpass', 2400, 0.8); HS = hiss;
    // drift layer 2: crunchy, grainy sliding (noise chopped by a fast LFO)
    const crunch = noiseLoop(sfx, 'bandpass', 1300, 0.6);
    crunch.gn.gain.value = 0;
    const crunchMod = ctx.createGain(); crunchMod.gain.value = 0;          // sits after crunch.gn, modulated by LFO
    crunch.gn.disconnect(); crunch.gn.connect(crunchMod); crunchMod.connect(sfx);
    const clfo = ctx.createOscillator(), clg = ctx.createGain(); clfo.type = 'square'; clfo.frequency.value = 18; clg.gain.value = 0.5;
    crunchMod.gain.value = 0.5; clfo.connect(clg); clg.connect(crunchMod.gain); clfo.start();
    CR = { lfo: clfo, g: crunch.gn };
    // drift layer 3: tyre squeal (saw tones + breathy noise through a resonant bandpass, with a wobble)
    const q1 = ctx.createOscillator(), q2 = ctx.createOscillator(); q1.type = 'sawtooth'; q2.type = 'sawtooth';
    q1.frequency.value = 900; q2.frequency.value = 1350;
    const qg1 = ctx.createGain(), qg2 = ctx.createGain(); qg1.gain.value = 0.6; qg2.gain.value = 0.3;
    const qbp = ctx.createBiquadFilter(); qbp.type = 'bandpass'; qbp.frequency.value = 1600; qbp.Q.value = 5;
    const qn = noiseLoop(null, 'bandpass', 1600, 10); qn.gn.gain.value = 0.9;
    const sqGain = ctx.createGain(); sqGain.gain.value = 0;
    q1.connect(qg1); q2.connect(qg2); qg1.connect(qbp); qg2.connect(qbp); qbp.connect(sqGain);
    qn.gn.connect(sqGain); sqGain.connect(sfx);
    const wob = ctx.createOscillator(), wg1 = ctx.createGain(), wg2 = ctx.createGain(); wob.type = 'sine'; wob.frequency.value = 7;
    wg1.gain.value = 50; wg2.gain.value = 75; wob.connect(wg1); wob.connect(wg2); wg1.connect(q1.frequency); wg2.connect(q2.frequency);
    q1.start(); q2.start(); wob.start();
    SQ = { q1, q2, qbp, qnf: qn.fl, wob, g: sqGain };

    N = { gravel: gravel.gn, wind: wind.gn, hiss: hiss.gn, crunch: crunchMod, squeal: sqGain };
    N._gravelF = gravel.fl;

    startMusic(); scene_(scene); paintButton();
  }

  function unlock() { init(); if (ctx && ctx.state === 'suspended') ctx.resume(); }

  // ---------------- one-shots ----------------
  function tone(freq, dur, type, vol, delay, slideTo) {
    if (!ctx) return;
    const t = ctx.currentTime + (delay || 0), o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'square'; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(sfx); o.start(t); o.stop(t + dur + 0.05);
  }
  function noiseBurst(dur, freq, vol, type, delay) {
    if (!ctx) return;
    const t = ctx.currentTime + (delay || 0), s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noiseBuf; f.type = type || 'lowpass'; f.frequency.setValueAtTime(freq, t); f.frequency.exponentialRampToValueAtTime(Math.max(80, freq * 0.2), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(sfx); s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }
  // exhaust pop / crackle on lift-off
  function pop(delay, vol) {
    if (!ctx) return;
    noiseBurst(0.07, 1100, vol, 'bandpass', delay);
    tone(95, 0.07, 'triangle', vol * 0.9, delay, 55);
  }

  // ---------------- co-pilot pace-note cues ----------------
  // One short rhythm per call: more notes, faster and harder timbre = tighter turn.
  // Direction: left = panned left + falling glide, right = panned right + rising glide. Caution (chicane) adds a warning triplet first.
  let paceAt = 0;
  function pn(freq, dur, type, vol, delay, slideTo, pan) {
    if (!ctx) return;
    const t = ctx.currentTime + (delay || 0), o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    if (ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = pan || 0; g.connect(p); p.connect(sfx); } else g.connect(sfx);
    o.start(t); o.stop(t + dur + 0.05);
  }
  // returns true when the cue was actually played (the caller then marks the turn as announced)
  function pace(sev, dir, caution) {
    if (!ctx || ctx.state !== 'running') return false;
    const now = performance.now(); if (now - paceAt < 700) return false; paceAt = now;      // throttle: never two cues on top of each other
    sev = clamp(sev | 0, 1, 4);
    const pan = dir > 0 ? -0.75 : 0.75, base = [0, 500, 560, 640, 760][sev], gap = [0, 0.16, 0.13, 0.1, 0.075][sev];
    const type = sev >= 4 ? 'sawtooth' : sev >= 3 ? 'square' : 'triangle', vol = sev >= 3 ? 0.045 : 0.08, len = sev >= 3 ? 0.07 : 0.11;
    let t0 = 0;
    if (caution) { [880, 620, 880].forEach((f, i) => pn(f, 0.09, 'square', 0.045, i * 0.11, 0, 0)); t0 = 0.42; }
    for (let i = 0; i < sev; i++) { const f = base * (1 + i * 0.06); pn(f, len, type, vol, t0 + i * gap, f * (dir > 0 ? 0.82 : 1.22), pan); }
    if (sev === 4) tone(110, 0.22, 'sine', 0.25, t0);                                       // hairpin: low thump under the rattle
    return true;
  }

  // ---------------- engine + continuous layers (call every frame) ----------------
  // s: { on, speed, maxSpeed, throttle, slip, handbrake, offroad, model }
  function update(s) {
    if (!ctx || !E) return;
    const t = ctx.currentTime, now = performance.now();
    const dt = clamp((now - (lastT || now)) / 1000, 0.001, 0.1); lastT = now;

    if (!s || !s.on) {
      E.out.gain.setTargetAtTime(0, t, 0.08); E.twg.gain.setTargetAtTime(0, t, 0.08);
      for (const k in N) if (k !== 'crunch' && N[k] && N[k].gain) N[k].gain.setTargetAtTime(0, t, 0.1);
      CR.g.gain.setTargetAtTime(0, t, 0.1);
      prevGear = -1; prevThr = 0; prevHb = false; wasSliding = false; rpmS = 0.15;
      return;
    }

    // ----- gears & rpm -----
    const sp = clamp(s.speed / s.maxSpeed, 0, 1.05), gear = Math.min(4, Math.floor(sp * 5)), f = clamp(sp * 5 - gear, 0, 1);
    const thr = s.throttle > 0 ? 1 : 0;
    const slideAmt = clamp((s.slip - 2) / 8, 0, 1) * (s.speed > 4 ? 1 : 0);

    if (prevGear >= 0 && gear > prevGear && s.speed > 3) {          // upshift: lift, dip, little chirp
      shiftT = 0.14;
      if (thr) noiseBurst(0.12, 3200, 0.05, 'bandpass');
    }
    prevGear = gear;
    shiftT = Math.max(0, shiftT - dt);

    let target = 0.2 + 0.8 * f;                                     // rpm climbs in each of 5 gears, drops on the shift
    if (thr && s.speed < 9) target = Math.max(target, 0.55);          // wheelspin off the line
    if (thr && slideAmt > 0.2) target = Math.max(target, 0.45 + 0.35 * slideAmt);   // wheels spinning loose in a drift
    if (!thr) target *= 0.82;                                         // engine braking
    if (shiftT > 0) target -= 0.1;
    const k = target > rpmS ? 13 : 8;                                 // revs rise quickly, fall a bit lazier -> audible swoop on shifts
    rpmS += (target - rpmS) * (1 - Math.exp(-dt * k));
    const rpm = clamp(rpmS, 0.06, 1);

    // ----- engine voice -----
    const pitch = PITCH[s.model] || 1, fund = pitch * (48 + rpm * 210);    // firing frequency
    E.oA.frequency.setTargetAtTime(fund, t, 0.03);
    E.oB.frequency.setTargetAtTime(fund * 1.006, t, 0.03);
    E.oSub.frequency.setTargetAtTime(fund * 0.5, t, 0.03);
    E.lump.frequency.setTargetAtTime(fund * 0.5, t, 0.03);
    E.lumpDepth.gain.setTargetAtTime(0.06 + 0.24 * (1 - rpm), t, 0.1);            // lumpier at low rpm, smooth when revving
    const load = thr ? 1 : 0.4;
    E.lp.frequency.setTargetAtTime(420 + rpm * 2400 + load * 900, t, 0.05);
    E.body.frequency.setTargetAtTime(130 + rpm * 160, t, 0.08);
    E.rasp.fl.frequency.setTargetAtTime(500 + rpm * 1800, t, 0.06);
    E.rasp.gn.gain.setTargetAtTime((0.25 + 0.75 * rpm) * (thr ? 0.9 : 0.3), t, 0.06);
    const duck = shiftT > 0 ? 0.4 : 1;
    E.out.gain.setTargetAtTime((0.075 + 0.13 * load * (0.45 + 0.55 * rpm)) * duck, t, 0.05);
    // turbo whistle (quiet, only under load)
    E.tw.frequency.setTargetAtTime(1800 + rpm * 3200, t, 0.08);
    E.twg.gain.setTargetAtTime(thr && shiftT <= 0 ? 0.012 * rpm * rpm : 0, t, 0.08);

    // lift-off: blow-off + a few pops at high revs
    if (prevThr && !thr && rpm > 0.55 && s.speed > 12) {
      noiseBurst(0.35, 3800, 0.1, 'bandpass');
      if (now - popAt > 400) { popAt = now; pop(0.05, 0.1); if (Math.random() < 0.7) pop(0.13, 0.08); if (Math.random() < 0.4) pop(0.22, 0.06); }
    }
    prevThr = thr;

    // ----- drift / slide -----
    const hbOn = !!(s.handbrake && s.speed > 5), hb = hbOn ? 0.6 : 0, sl = Math.max(slideAmt, hb);
    if (hbOn && !prevHb) {                                            // handbrake yank: ratchet + scrape
      noiseBurst(0.35, 3000, 0.2, 'bandpass'); tone(1700, 0.025, 'square', 0.04, 0); tone(1700, 0.025, 'square', 0.04, 0.045); tone(1700, 0.025, 'square', 0.04, 0.09);
    }
    prevHb = hbOn;
    if (sl > 0.3 && !wasSliding) noiseBurst(0.25, 3400, 0.12, 'bandpass');    // tyres letting go
    wasSliding = sl > 0.3;

    // gravel / dirt spray: hiss + crunchy grain, louder and brighter the harder the slide
    HS.fl.frequency.setTargetAtTime(1900 + sl * 1700 + s.speed * 8, t, 0.08);
    N.hiss.gain.setTargetAtTime(0.15 * Math.pow(sl, 0.9), t, 0.06);
    CR.lfo.frequency.setTargetAtTime(14 + s.speed * 0.45 + sl * 8, t, 0.1);
    CR.g.gain.setTargetAtTime(0.3 * Math.pow(sl, 0.8), t, 0.06);

    // tyre squeal: only once the slide is properly committed; pitch rises with slip + speed
    const sq = clamp((sl - 0.28) / 0.72, 0, 1), sqF = 620 + clamp(s.slip, 0, 12) * 65 + s.speed * 9;
    SQ.q1.frequency.setTargetAtTime(sqF, t, 0.08); SQ.q2.frequency.setTargetAtTime(sqF * 1.51, t, 0.08);
    SQ.qbp.frequency.setTargetAtTime(sqF * 1.7, t, 0.08); SQ.qnf.frequency.setTargetAtTime(sqF * 1.7, t, 0.08);
    SQ.wob.frequency.setTargetAtTime(5 + sq * 5, t, 0.2);
    N.squeal.gain.setTargetAtTime(0.1 * Math.pow(sq, 1.1), t, 0.06);

    N.gravel.gain.setTargetAtTime((s.offroad ? 0.22 * clamp(s.speed / 30, 0, 1) : 0.03 * clamp(s.speed / 40, 0, 1)) + 0.06 * sl, t, 0.08);
    N.wind.gain.setTargetAtTime(0.1 * Math.pow(clamp(s.speed / 50, 0, 1), 2), t, 0.15);
  }

  // ---------------- events ----------------
  const api = {
    unlock, update,
    get muted() { return muted; },
    toggleMute() {
      muted = !muted; try { window.RallyStore ? RallyStore.set(STORE, muted ? '1' : '0') : localStorage.setItem(STORE, muted ? '1' : '0'); } catch (e) { /* ignore */ }
      unlock(); if (master) master.gain.setTargetAtTime(muted ? 0 : 0.85, ctx.currentTime, 0.05);
      paintButton();
    },
    adMute(on) { adMuted = !!on; if (ctx && master) master.gain.setTargetAtTime(adMuted || muted ? 0 : 0.85, ctx.currentTime, 0.03); },   // CrazyGames: silence during ads
    scene(n) { scene_(n); },
    ui() { tone(520, 0.07, 'square', 0.05, 0, 800); },
    count(go) { go ? tone(880, 0.45, 'square', 0.09) : tone(440, 0.15, 'square', 0.08); },
    chime() { tone(660, 0.12, 'triangle', 0.1); tone(990, 0.22, 'triangle', 0.1, 0.1); },
    whoosh() { noiseBurst(0.45, 2500, 0.18, 'bandpass'); },
    pace,
    crash(v) {
      if (!ctx) return; const n = performance.now(); if (n - crashAt < 140) return; crashAt = n;
      const k = clamp(v / 14, 0.15, 1);
      noiseBurst(0.35, 1400, 0.55 * k, 'lowpass'); tone(130, 0.28, 'sine', 0.5 * k, 0, 38);
    },
    finish(good) {
      if (good) [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.3, 'triangle', 0.12, i * 0.11));
      else { tone(392, 0.28, 'triangle', 0.1); tone(311, 0.45, 'triangle', 0.1, 0.22); }
    },
  };

  // ---------------- music: A minor rally-funk loop, scheduled a little ahead of time (unchanged) ----------------
  const BASS = [55, 43.65, 65.41, 49], ARP = [[220, 261.6, 329.6], [174.6, 220, 261.6], [261.6, 329.6, 392], [196, 246.9, 293.7]];
  function note(freq, t, dur, type, vol, lp) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    if (lp) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = lp; o.connect(f); f.connect(g); } else o.connect(g);
    g.connect(music); o.start(t); o.stop(t + dur + 0.05);
  }
  function hat(t) {
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noiseBuf; f.type = 'highpass'; f.frequency.value = 7000;
    g.gain.setValueAtTime(0.05, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
    s.connect(f); f.connect(g); g.connect(music); s.start(t, Math.random()); s.stop(t + 0.07);
  }
  function startMusic() {
    nextT = ctx.currentTime + 0.1; step = 0;
    const spb = 60 / 124 / 4;                                  // one 16th note
    musicTimer = setInterval(() => {
      if (!ctx || ctx.state !== 'running') { nextT = Math.max(nextT, ctx ? ctx.currentTime : 0); return; }
      while (nextT < ctx.currentTime + 0.35) {
        const bar = Math.floor(step / 16) % 4, st = step % 16, t = nextT;
        if (st % 4 === 0) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.14);
          g.gain.setValueAtTime(0.28, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18); o.connect(g); g.connect(music); o.start(t); o.stop(t + 0.2); }
        if (st % 4 === 2) hat(t);
        if ([0, 3, 6, 8, 10, 12, 14].includes(st)) note(BASS[bar] * (st === 6 || st === 14 ? 2 : 1), t, 0.16, 'square', 0.07, 420);
        if (st % 2 === 0) note(ARP[bar][(st / 2) % 3] * 2, t, 0.14, 'triangle', 0.06);
        nextT += spb; step++;
      }
    }, 90);
  }
  function scene_(n) {
    scene = n; if (!ctx) return;
    const v = { menu: 0.7, garage: 0.7, paused: 0.45, finished: 0.55, countdown: 0.3, racing: 0.26 }[n];
    music.gain.setTargetAtTime(v === undefined ? 0.5 : v, ctx.currentTime, 0.4);
  }

  // ---------------- wiring ----------------
  for (const ev of ['pointerdown', 'touchend', 'keydown', 'click']) addEventListener(ev, unlock, { passive: true });
  addEventListener('keydown', (e) => { if (e.code === 'KeyM' && !e.repeat) api.toggleMute(); });
  document.addEventListener('click', (e) => {                  // blip on every menu button (not on the driving controls)
    const b = e.target.closest && e.target.closest('button'); if (!b || b.closest('#touch') || b.id === 'btnSound') return;
    api.ui();
  });
  document.addEventListener('visibilitychange', () => { if (!ctx) return; if (document.hidden) ctx.suspend(); else ctx.resume(); });
  const wireUI = () => { paintButton(); const b = document.getElementById('btnSound'); if (b) b.addEventListener('click', () => api.toggleMute()); };
  if (document.readyState === 'loading') addEventListener('DOMContentLoaded', wireUI); else wireUI();     // this file may load after DOMContentLoaded (SDK init first)
  return api;
})();
