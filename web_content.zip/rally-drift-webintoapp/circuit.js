/* CircuitTrack: a closed, procedurally generated loop for the Circuit mode.
   It extends Track, so it reuses the exact same visuals (dirt road, ruts, verge, embankments, terrain tiles,
   trees, rocks, spectators, hay bales, stakes, chevron boards, start gate) - only the road generation differs.

   Indexing: sample indices are "unrolled" - they keep counting up lap after lap (lap 2 = N..2N-1 ...).
   s(i) wraps them with modulo, so car.hint / game.js can simply compare indices to count laps.
   Needs track.js to be loaded first. */
class CircuitTrack extends Track {
  // seed: same seed + same loop length = the same circuit. km: length of ONE lap.
  reset(seed, km) {
    for (const g of this.chunks.values()) this.disposeChunk(g);
    for (const t of this.tiles.values()) { this.scene.remove(t); t.geometry.dispose(); }
    this.chunks.clear(); this.tiles.clear();
    this.seed = this.seed0 = seed || Math.floor(Math.random() * 2147483000) + 1;
    this.loopLen = (km || 1.7) * 1000;
    this.nz = [0, 0, 0, 0].map(() => this.random() * 6.28);
    this.base = 0; this.offDist = 0;
    this.generateLoop();
    const st = this.s(this.startIdx);
    this.refY = st.y;
    this._px = undefined; this._tx = undefined;
    this.update(this.startIdx, true, st.x, st.z);
  }

  s(i) { const N = this.N; return this.S[((i % N) + N) % N]; }

  // ---------------- loop generation ----------------
  // Star-shaped closed curve r(theta) = 1 + sum of random harmonics -> can never cross itself.
  // Then: scale to ~1.5-2 km, resample evenly, reject too-tight corners / too-close road, add a closed elevation profile.
  generateLoop() {
    const R = () => this.random(), TAU = Math.PI * 2, CH = this.CH, M = 2400;
    const ang = (a, b) => ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI;
    let result = null;

    for (let attempt = 0; attempt < 200 && !result; attempt++) {
      const damp = Math.max(0.3, 1 - attempt * 0.008);
      const A = [0, 0, 0.15 + R() * 0.23, 0.06 + R() * 0.16, 0.04 + R() * 0.10, 0.02 + R() * 0.07, 0.015 + R() * 0.045, R() * 0.04];
      const ph = A.map(() => R() * TAU);
      const sum = A.reduce((a, b) => a + b, 0), f = Math.min(1, 0.7 / sum) * damp;

      // dense polyline of the unit-size curve
      const P = []; let L1 = 0;
      for (let j = 0; j < M; j++) {
        const th = j / M * TAU; let r = 1;
        for (let k = 2; k <= 7; k++) r += A[k] * f * Math.cos(k * th + ph[k]);
        P.push({ x: r * Math.cos(th), z: r * Math.sin(th) });
      }
      for (let j = 0; j < M; j++) { const a = P[j], b = P[(j + 1) % M]; L1 += Math.hypot(b.x - a.x, b.z - a.z); }
      const scale = this.loopLen * (0.93 + R() * 0.14) / L1;
      for (const p of P) { p.x *= scale; p.z *= scale; }

      // arc length + even resampling (N is a multiple of the chunk size so chunks tile the loop exactly)
      const cum = [0];
      for (let j = 1; j <= M; j++) { const a = P[j - 1], b = P[j % M]; cum.push(cum[j - 1] + Math.hypot(b.x - a.x, b.z - a.z)); }
      const L = cum[M], N = Math.max(CH * 8, Math.round(L / 2.4 / CH) * CH), ds = L / N;
      const Q = []; let seg = 0;
      for (let i = 0; i < N; i++) {
        const t = i * ds; while (cum[seg + 1] < t) seg++;
        const u = (t - cum[seg]) / (cum[seg + 1] - cum[seg]), a = P[seg], b = P[(seg + 1) % M];
        Q.push({ x: a.x + (b.x - a.x) * u, z: a.z + (b.z - a.z) * u });
      }
      if (R() < 0.5) Q.reverse();                       // random driving direction

      // headings + curvature (rad/m, positive = same sign convention as Track)
      const gh = Q.map((p, i) => { const a = Q[(i - 1 + N) % N], b = Q[(i + 1) % N]; return Math.atan2(b.x - a.x, b.z - a.z); });
      const k = gh.map((g, i) => ang(gh[(i - 1 + N) % N], gh[(i + 1) % N]) / (2 * ds));
      let maxK = 0; for (const v of k) maxK = Math.max(maxK, Math.abs(v));
      const last = attempt === 199;
      if (!last && (maxK > 1 / 17 || maxK < 1 / 80)) continue;      // corners must be drivable, but not boring

      // road must keep its distance from non-adjacent road
      let ok = true;
      for (let i = 0; i < N && ok && !last; i += 3) for (let j = i + 1; j < N; j += 3) {
        const dj = Math.min(j - i, N - (j - i)); if (dj < 70) continue;
        const dx = Q[i].x - Q[j].x, dz = Q[i].z - Q[j].z;
        if (dx * dx + dz * dz < 55 * 55) { ok = false; break; }
      }
      if (!ok) continue;
      result = { Q, gh, k, N, ds };
    }

    const { Q, gh, k, N, ds } = result;

    // start/finish on the straightest stretch
    let s0 = 0, bestCost = 1e9;
    for (let i = 0; i < N; i++) {
      let c = 0; for (let j = -40; j <= 20; j++) c += Math.abs(k[(i + j + N) % N]);
      if (c < bestCost) { bestCost = c; s0 = i; }
    }

    // closed elevation profile (integer frequencies -> start and end meet), slope-limited
    const E = [[1, 5 + R() * 9, R() * TAU], [2, 1.5 + R() * 4.5, R() * TAU], [3, R() * 3, R() * TAU]];
    const y = []; for (let i = 0; i < N; i++) { let v = 0; for (const [fr, am, p] of E) v += am * Math.sin(TAU * fr * i / N + p); y.push(v); }
    let maxSl = 0; for (let i = 0; i < N; i++) maxSl = Math.max(maxSl, Math.abs(y[(i + 1) % N] - y[i]) / ds);
    const ys = maxSl > 0.1 ? 0.1 / maxSl : 1;

    const S = [];
    for (let i = 0; i < N; i++) {
      const src = (i + s0) % N, p = Q[src], g = gh[src], tx = Math.sin(g), tz = Math.cos(g);
      S.push({ x: p.x, y: y[i] * ys, z: p.z, tx, tz, rx: -tz, rz: tx, k: k[src] });
    }
    this.S = S; this.N = N; this.ds = ds; this.nChunks = N / CH; this.startIdx = -14;
    this.hash = new Map();
    S.forEach((s, i) => { const key = this.key(s.x, s.z); let a = this.hash.get(key); if (!a) { a = []; this.hash.set(key, a); } a.push(i); });
  }

  // ---------------- queries (all wrap around the loop) ----------------
  query(p, hint) {
    const N = this.N, S = this.S, m = (i) => ((i % N) + N) % N;
    let bi = hint, best = 1e18;
    for (let i = hint - 25; i <= hint + 25; i++) { const s = S[m(i)], dx = p.x - s.x, dz = p.z - s.z, d = dx * dx + dz * dz; if (d < best) { best = d; bi = i; } }
    if (best > 900) {                                // far from the road: full scan, but never jump across the whole loop
      let fb = 1e18, fi = 0;
      for (let i = 0; i < N; i++) { const s = S[i], dx = p.x - s.x, dz = p.z - s.z, d = dx * dx + dz * dz; if (d < fb) { fb = d; fi = i; } }
      if (fb < best) { const cand = fi + Math.round((hint - fi) / N) * N; if (Math.abs(cand - hint) < 160) { best = fb; bi = cand; } }
    }
    const s = S[m(bi)];
    this.offDist = Math.sqrt(best);
    return { index: bi, lat: (p.x - s.x) * s.rx + (p.z - s.z) * s.rz, dist: this.offDist, s };
  }

  sAt(i) { return this.s(i); }                     // wraps around the loop (terrainY / smoothY live in Track)

  obstacleLists(ci) {
    const nC = this.nChunks, c = Math.floor(ci / this.CH), out = [];
    for (let k = c - 1; k <= c + 1; k++) { const g = this.chunks.get(((k % nC) + nC) % nC); if (g) out.push(g.userData.obst); }
    return out;
  }

  // ---------------- streaming: the whole loop is built once, far chunks are hidden, terrain tiles stream around the car ----------------
  update(ci, all, px, pz) {
    const CH = this.CH, cur = this.s(ci);
    this.refY = cur.y;
    if (px === undefined) { px = cur.x; pz = cur.z; }
    const jump = this.detectJump(px, pz);

    if (this.chunks.size < this.nChunks) {
      for (let c = 0; c < this.nChunks; c++) {
        if (this.chunks.has(c)) continue;
        this.build(c);
        const g = this.chunks.get(c), mid = this.s(c * CH + CH / 2);
        g.userData.mx = mid.x; g.userData.mz = mid.z;
      }
    }
    for (const g of this.chunks.values()) g.visible = Math.hypot(g.userData.mx - px, g.userData.mz - pz) < 440;

    this.streamTiles(px, pz, all, jump);
  }

  // start/finish gate sits on sample 0 (the lap counter in game.js counts a lap whenever index N*k is passed)
  buildStart(g) {
    const cv = document.createElement('canvas'); cv.width = 128; cv.height = 16;
    const x = cv.getContext('2d');
    for (let i = 0; i < 16; i++) for (let j = 0; j < 2; j++) { x.fillStyle = (i + j) % 2 ? '#fff' : '#111'; x.fillRect(i * 8, j * 8, 8, 8); }
    const tex = new THREE.CanvasTexture(cv); tex.magFilter = THREE.NearestFilter;
    const s = this.s(0), ry = Math.atan2(s.tx, s.tz);
    const line = new THREE.Mesh(new THREE.PlaneGeometry(this.hw * 2, 2), new THREE.MeshBasicMaterial({ map: tex }));
    line.rotation.x = -Math.PI / 2;
    const holder = new THREE.Group(); holder.add(line); holder.position.set(s.x, s.y + 0.14, s.z); holder.rotation.y = ry; g.add(holder);
    const mat = new THREE.MeshLambertMaterial({ color: 0xff7a1a, flatShading: true });
    for (const d of [-1, 1]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.7, 7, 0.7), mat);
      post.position.set(s.x + s.rx * d * (this.hw + 1.2), s.y + 3.5, s.z + s.rz * d * (this.hw + 1.2)); post.castShadow = true; g.add(post);
    }
    const beam = new THREE.Mesh(new THREE.BoxGeometry((this.hw + 1.2) * 2, 1.2, 0.8), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    beam.position.set(s.x, s.y + 7, s.z); beam.rotation.y = ry; beam.castShadow = true; g.add(beam);
  }
}
