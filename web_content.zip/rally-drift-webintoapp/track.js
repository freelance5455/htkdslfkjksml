/* Stelvio-style rally road (Stage mode: reset(seed, km) = finite stage of km with a finish gate, reset(seed) = endless;
   the same seed always gives the same road, hills and scenery).
   - The road is a stream of samples built from "units": hairpin switchbacks, twisty bends and fast sweepers,
     with a rolling elevation profile (climbs, descents, crests).
   - Every new unit is tested against the existing road and re-rolled if it would run into it.
   - Terrain is a height-field around the road (tiles), so hills and mountains rise beside it.
   - No barriers: you can leave the road (grass is slow) and hit trees / rocks. */
const _d = new THREE.Object3D(), _col = new THREE.Color();
const sm = (a, b, v) => { const t = Math.max(0, Math.min(1, (v - a) / (b - a))); return t * t * (3 - 2 * t); };

class InstSet {
  constructor(geo, mat, shadow) { this.geo = geo; this.mat = mat; this.sh = shadow; this.m = []; this.c = []; }
  add(x, y, z, ry, sx, sy, sz, color) {
    _d.position.set(x, y, z); _d.rotation.set(0, ry, 0); _d.scale.set(sx, sy, sz); _d.updateMatrix();
    this.m.push(_d.matrix.clone());
    if (color !== undefined) this.c.push(color);
  }
  build(group) {
    if (!this.m.length) return;
    const im = new THREE.InstancedMesh(this.geo, this.mat, this.m.length);
    this.m.forEach((m, i) => { im.setMatrixAt(i, m); if (this.c.length) im.setColorAt(i, _col.setHex(this.c[i])); });
    im.castShadow = this.sh; im.receiveShadow = true; im.frustumCulled = false;
    group.add(im);
  }
}

class Track {
  constructor(scene) {
    this.scene = scene;
    this.hw = 7; this.limit = this.hw + 2.2; this.ds = 2.4; this.CH = 40;
    const L = (c) => new THREE.MeshLambertMaterial({ color: c, side: THREE.DoubleSide });
    const F = (c) => new THREE.MeshLambertMaterial({ color: c, flatShading: true });
    this.roadHalf = this.hw + 1.8;
    this.mat = { verge: L(0x74d257), bank: L(0x5cb847), road: new THREE.MeshLambertMaterial({ map: this.makeRoadTex(), alphaTest: 0.5, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }) };
    this.M = { white: F(0xffffff), trunk: F(0x7a4a2a), legs: F(0x2a2d3a), hay: F(0xd4b43a), cone: F(0xffb020), dark: F(0x2a2d3a), board: F(0xff7a1a), wood: F(0x8b6a45) };
    this.G = {
      trunk: new THREE.CylinderGeometry(0.35, 0.55, 2.4, 6), c1: new THREE.ConeGeometry(2.4, 4.2, 7), c2: new THREE.ConeGeometry(1.9, 3.6, 7), c3: new THREE.ConeGeometry(1.3, 3.2, 7),
      rock: new THREE.IcosahedronGeometry(1, 0), body: new THREE.BoxGeometry(0.7, 1.1, 0.5), head: new THREE.BoxGeometry(0.45, 0.45, 0.45),
      legs: new THREE.BoxGeometry(0.6, 0.4, 0.4), hay: new THREE.BoxGeometry(1.6, 1, 1.2), cone: new THREE.ConeGeometry(0.35, 0.8, 6),
      pole: new THREE.BoxGeometry(0.18, 1.4, 0.18), post: new THREE.BoxGeometry(0.15, 1.9, 0.15),
      board: new THREE.BoxGeometry(2.2, 1.1, 0.12), stripe: new THREE.BoxGeometry(0.5, 1.1, 0.2),
      flower: new THREE.BoxGeometry(0.2, 0.2, 0.2), fpost: new THREE.BoxGeometry(0.16, 1.2, 0.16), rail: new THREE.BoxGeometry(0.1, 0.12, 1),
      log: new THREE.CylinderGeometry(0.35, 0.35, 2.6, 6).rotateZ(Math.PI / 2)
    };
    this.tileMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, side: THREE.DoubleSide });   // double sided: the camera can never see "through" a hillside
    this.cols = { g1: new THREE.Color(0x62c956), g2: new THREE.Color(0x4cb34a), light: new THREE.Color(0x8fdc5c), verge: new THREE.Color(0x74d257),
      rockD: new THREE.Color(0x40454f), rockL: new THREE.Color(0x6a7080), high: new THREE.Color(0x8d93a2), snow: new THREE.Color(0xe8eef6) };
    this.chunks = new Map(); this.tiles = new Map();
    this.reset();
  }

  random() { this.seed = (this.seed * 16807) % 2147483647; return (this.seed - 1) / 2147483646; }
  s(i) { return this.S[i - this.base]; }
  // Deterministic RNG per chunk: scenery depends only on (seed, chunk), never on build order -> a replay is identical.
  chunkRng(c) {
    let s = ((this.seed0 + c * 104729) % 2147483646) + 1;
    const next = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    next(); next(); next();
    return next;
  }
  key(x, z) { return (Math.floor(x / 32) + 30000) * 60000 + (Math.floor(z / 32) + 30000); }

  // seed: same seed (+ same km) = exactly the same stage. km: stage length, 0 / undefined = endless.
  reset(seed, km) {
    for (const g of this.chunks.values()) this.disposeChunk(g);
    for (const t of this.tiles.values()) { this.scene.remove(t); t.geometry.dispose(); }
    this.chunks.clear(); this.tiles.clear();
    this.seed = this.seed0 = seed || Math.floor(Math.random() * 2147483000) + 1;
    this.km = km || 0; this.endless = !km; this.finishIdx = undefined;
    this.hash = new Map(); this.S = []; this.base = 0; this.hist = []; this.minKeep = 0;
    this.gx = 0; this.gz = 0; this.gh = 0; this.y = 0; this.slope = 0; this.elevLeft = 70; this.tSlope = 0;
    this.zone = 'sweep'; this.zoneLeft = 2; this.lastSign = 1; this.switchDir = 1; this.refY = 0;
    this.nz = [this.random() * 6.28, this.random() * 6.28, this.random() * 6.28, this.random() * 6.28];
    if (!this.endless) this.generateStage();
    this._px = undefined; this._tx = undefined;
    this.update(12, true);
  }

  // finite stage: the whole road is generated up front (deterministic) and the finish is known
  generateStage() {
    this.minKeep = 0;
    this.finishIdx = 25 + Math.round(this.km * 1000 / this.ds);
    let guard = 0;
    while (this.base + this.S.length <= this.finishIdx + 40 && guard++ < 50000) this.genUnit();
    this.runOut();                                       // run-out behind the finish line (steered away from older road)
    this.hist.length = 0;
  }

  // run-out after the finish: a straight, or a gentle bend if the straight would run into older road
  runOut() {
    const keys = ['gx', 'gz', 'gh', 'y', 'slope', 'elevLeft', 'tSlope'], st = {}; keys.forEach(k => st[k] = this[k]);
    const n0 = this.S.length;
    for (const [k, n] of [[0, 130], [0.004, 130], [-0.004, 130], [0.009, 110], [-0.009, 110], [0, 60]]) {
      for (let j = 0; j < n; j++) this.emit(k);
      if (!this.conflicts(n0)) return;
      this.popTo(n0); keys.forEach(q => this[q] = st[q]);
    }
    this.straight(40);
  }

  // ---------------- road generation ----------------
  emit(kk) {
    if (this.elevLeft-- <= 0) this.newElev();
    this.slope += Math.max(-0.0012, Math.min(0.0012, this.tSlope - this.slope));
    const sh = Math.sin(this.gh), ch = Math.cos(this.gh), idx = this.base + this.S.length;
    const s = { x: this.gx, y: this.y, z: this.gz, tx: sh, tz: ch, rx: -ch, rz: sh, k: kk };
    this.S.push(s);
    const key = this.key(s.x, s.z); let a = this.hash.get(key); if (!a) { a = []; this.hash.set(key, a); } a.push(idx);
    this.gh += kk * this.ds; this.gx += Math.sin(this.gh) * this.ds; this.gz += Math.cos(this.gh) * this.ds; this.y += this.slope * this.ds;
  }

  newElev() {
    const R = () => this.random();
    this.elevLeft = 35 + Math.floor(R() * 90);
    const sw = this.zone === 'switch';
    let m = sw ? 0.07 + R() * 0.05 : R() * 0.13, sg = sw ? this.switchDir : (R() < 0.5 ? -1 : 1);
    if (!sw && R() < 0.2) m = 0;
    if (this.y > 110) sg = -1; else if (this.y < -25) sg = 1;
    this.tSlope = sg * m;
  }

  straight(n) { for (let j = 0; j < n; j++) this.emit(0); }

  curve(k, angle) {                           // clothoid-like: ramp in, hold, ramp out
    const a = Math.abs(k), ramp = Math.max(4, Math.min(10, Math.round(a / 0.0075)));
    const hold = Math.max(0, Math.round(angle / (a * this.ds) - ramp));
    for (let r = 1; r <= ramp; r++) this.emit(k * r / ramp);
    for (let j = 0; j < hold; j++) this.emit(k);
    for (let r = ramp - 1; r >= 0; r--) this.emit(k * r / ramp);
  }

  makeUnit() {
    const R = () => this.random(), D = Math.PI / 180, i = this.base + this.S.length;
    if (i < 60) { this.straight(60 - i); return; }
    if (this.zoneLeft <= 0) {
      const r = R(), km = i * this.ds / 1000;
      this.zone = r < 0.30 + Math.min(0.1, km * 0.02) ? 'switch' : r < 0.70 ? 'twisty' : 'sweep';
      this.zoneLeft = 3 + Math.floor(R() * 6); this.switchDir = R() < 0.5 ? -1 : 1;
    }
    this.zoneLeft--;
    let sign = R() < 0.75 ? -this.lastSign : this.lastSign;
    if (this.zone === 'switch') {              // hairpin switchbacks
      sign = -this.lastSign;
      this.curve(sign / (17 + R() * 6), (150 + R() * 35) * D);
      this.straight(4 + Math.floor(R() * 13));
    } else if (this.zone === 'twisty') {       // tight bends
      this.curve(sign / (24 + R() * 28), (45 + R() * 70) * D);
      if (R() < 0.6) this.straight(3 + Math.floor(R() * 12));
    } else {                                   // fast sweepers + straights
      this.straight(15 + Math.floor(R() * 45));
      this.curve(sign / (70 + R() * 90), (25 + R() * 50) * D);
    }
    this.lastSign = sign;
  }

  popTo(n) {
    while (this.S.length > n) {
      const s = this.S.pop(), a = this.hash.get(this.key(s.x, s.z));
      if (a) a.pop();
    }
  }

  conflicts(n0) {                              // new road too close to older, non-adjacent road?
    const b = this.base;
    for (let j = n0; j < this.S.length; j += 2) {
      const s = this.S[j], idx = b + j, cx = Math.floor(s.x / 32), cz = Math.floor(s.z / 32);
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const a = this.hash.get((cx + dx + 30000) * 60000 + (cz + dz + 30000)); if (!a) continue;
        for (const i2 of a) {
          if (i2 < b || i2 > idx - 60) continue;
          const o = this.S[i2 - b], ex = s.x - o.x, ez = s.z - o.z;
          if (ex * ex + ez * ez < 1296) return true;
        }
      }
    }
    return false;
  }

  genUnit() {
    const keys = ['gx', 'gz', 'gh', 'y', 'slope', 'elevLeft', 'tSlope', 'zone', 'zoneLeft', 'lastSign', 'switchDir'];
    const st = {}; keys.forEach(k => st[k] = this[k]);
    const n0 = this.S.length;
    for (let t = 0; t < 14; t++) {
      this.makeUnit();
      if (!this.conflicts(n0)) { this.hist.push({ st, n0: this.base + n0 }); if (this.hist.length > 16) this.hist.shift(); return; }
      this.popTo(n0); keys.forEach(k => this[k] = st[k]);
    }
    // dead end (boxed in by older road): back up a few units and try a different way
    let e = null, n = 0;
    while (n < 3 && this.hist.length && this.hist[this.hist.length - 1].n0 >= this.minKeep) { e = this.hist.pop(); n++; }
    if (e) { keys.forEach(k => this[k] = e.st[k]); this.popTo(e.n0 - this.base); return; }
    this.makeUnit();
  }

  // ---------------- queries ----------------
  query(p, hint) {
    const S = this.S, b = this.base, n = S.length;
    let bi = Math.min(Math.max(hint, b), b + n - 1), best = 1e18;
    const lo = Math.max(b, bi - 25), hi = Math.min(b + n - 1, bi + 25);
    for (let i = lo; i <= hi; i++) { const dx = p.x - S[i - b].x, dz = p.z - S[i - b].z, d = dx*dx + dz*dz; if (d < best) { best = d; bi = i; } }
    if (best > 900) for (let i = Math.max(b, hint - 300), e = Math.min(b + n - 1, hint + 300); i <= e; i++) { const dx = p.x - S[i - b].x, dz = p.z - S[i - b].z, d = dx*dx + dz*dz; if (d < best) { best = d; bi = i; } }
    const s = S[bi - b];
    return { index: bi, lat: (p.x - s.x) * s.rx + (p.z - s.z) * s.rz, dist: Math.sqrt(best), s };
  }

  nearestIdx(x, z) {                           // spatial-hash ring search
    const cs = 32, cx = Math.floor(x / cs), cz = Math.floor(z / cs), S = this.S, b = this.base;
    let best = 1e18, bi = -1;
    for (let k = 0; k <= 14; k++) {
      for (let dx = -k; dx <= k; dx++) {
        const edge = Math.abs(dx) === k;
        for (let dz = -k; dz <= k; dz += (edge || k === 0) ? 1 : 2 * k) {
          const a = this.hash.get((cx + dx + 30000) * 60000 + (cz + dz + 30000)); if (!a) continue;
          for (const i of a) { if (i < b) continue; const s = S[i - b], ex = x - s.x, ez = z - s.z, d = ex*ex + ez*ez; if (d < best) { best = d; bi = i; } }
        }
      }
      if (bi >= 0 && best <= (k * cs) * (k * cs)) break;
    }
    this._best = best; return bi;
  }

  // ---------------- pace notes: curvature look-ahead ----------------
  // Scans the road ahead of sample `idx`, out to a distance that grows with speed (never under 140 m), and returns the NEXT real turn (or null).
  // Curvature is measured as the signed angle between two tangents W samples apart (cross / dot product), divided by the arc length:
  //   sin(b - a) = tz_a * tx_b - tx_a * tz_b      > 0  ->  the road bends LEFT (same sign convention as sample.k)
  // A turn opens when |curvature| exceeds KT and closes when it falls under KE (or flips sign). A turn the car is already inside is skipped,
  // so the result is always something still ahead. The turn after it is reported too, so the caller can spot chicanes.
  // Works for Track (finite / endless) and CircuitTrack (s() wraps, indices are unrolled, so a turn id is unique across laps).
  paceScan(idx, speed) {
    const W = 6, ds = this.ds, KT = 0.0075, KE = 0.0045, MIN_ANG = 0.2;
    const look = Math.max(140, Math.min(320, 100 + speed * 4.2)), n = Math.ceil(look / ds);
    const turn = (i0, i1) => {
      const a = this.s(i0), b = this.s(i1); if (!a || !b) return null;
      return Math.atan2(a.tz * b.tx - a.tx * b.tz, a.tx * b.tx + a.tz * b.tz) / ((i1 - i0) * ds);
    };
    const kb = turn(idx - W, idx);
    let skip = kb !== null && Math.abs(kb) > KT ? Math.sign(kb) : 0;        // already inside a turn: let it finish first
    const turns = []; let cur = null;
    const open = (i, ak, sg) => { cur = { start: i + W / 2, sg, k: ak, ang: ak * ds }; };
    const close = (i) => { if (cur.ang >= MIN_ANG) turns.push({ start: cur.start, end: i, sg: cur.sg, k: cur.k, ang: cur.ang }); cur = null; };

    for (let j = 1; j <= n + 70; j++) {
      if (j > n && !cur) break;                                              // past the look-ahead: only finish a turn that is already open
      const i = idx + j, k = turn(i, i + W); if (k === null) break;
      const ak = Math.abs(k), sg = Math.sign(k);
      if (skip) {
        if (ak < KE) skip = 0;
        else if (ak > KT && sg !== skip) skip = 0;                           // flipped straight into the opposite turn: open it below
        else continue;
      }
      if (cur) {
        if (ak < KE) close(i);
        else if (ak > KT && sg !== cur.sg) { close(i); open(i, ak, sg); }
        else { cur.ang += ak * ds; if (ak > cur.k) cur.k = ak; }
      } else if (ak > KT) open(i, ak, sg);
      if (turns.length >= 2) break;
    }
    if (cur) close(idx + n + 70);
    if (!turns.length) return null;
    const a = turns[0], b = turns[1];
    return {
      id: a.start, dist: Math.max(0, (a.start - idx) * ds), dir: a.sg, k: a.k, angle: a.ang, len: (a.end - a.start) * ds,
      nextId: b ? b.start : -1, gap: b ? (b.start - a.end) * ds : Infinity, nextDir: b ? b.sg : 0, nextK: b ? b.k : 0, nextAngle: b ? b.ang : 0,
    };
  }

  // ---------------- seeded value noise (smooth, detailed, deterministic per seed) ----------------
  hash2(ix, iz) {
    let h = Math.imul(ix, 374761393) ^ Math.imul(iz, 668265263) ^ Math.imul(this.seed0 | 0, 1274126177);
    h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }
  vn(x, z) {
    const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz, u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
    const a = this.hash2(ix, iz), b = this.hash2(ix + 1, iz), c = this.hash2(ix, iz + 1), d = this.hash2(ix + 1, iz + 1);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  fbm(x, z, o) { let s = 0, a = 0.5, n = 0; for (let i = 0; i < o; i++) { s += a * this.vn(x, z); n += a; x = x * 2.03 + 17.1; z = z * 2.03 + 9.7; a *= 0.5; } return s / n; }
  noise(x, z) { return this.fbm(x * 0.008, z * 0.008, 3) * 2 - 1; }

  // Dirt road texture, tiles along the road (35 m per repeat). Ragged transparent edges, 4 wheel ruts, pebbles, mud, grass blotches on the rim.
  makeRoadTex() {
    const W = 256, H = 512, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const x = cv.getContext('2d'); let s = 4242;
    const r = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    const E = 8.8, px = (lat) => (lat + E) / (2 * E) * W, TAU = Math.PI * 2;
    const ph = [r() * TAU, r() * TAU, r() * TAU, r() * TAU];
    const edge = (y, side) => 7.3 + 0.35 * Math.sin(TAU * 3 * y / H + ph[side ? 0 : 1]) + 0.25 * Math.sin(TAU * 7 * y / H + ph[side ? 2 : 3]) + 0.12 * Math.sin(TAU * 17 * y / H + ph[side ? 1 : 0]);
    const wrap = (fn) => { for (const o of [-H, 0, H]) fn(o); };
    // base dirt
    x.beginPath(); for (let y = 0; y <= H; y += 4) x.lineTo(px(-edge(y, 0)), y); for (let y = H; y >= 0; y -= 4) x.lineTo(px(edge(y, 1)), y); x.closePath();
    const gr = x.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, '#9d6a43'); gr.addColorStop(0.3, '#b27a4d'); gr.addColorStop(0.5, '#c08a58'); gr.addColorStop(0.7, '#b27a4d'); gr.addColorStop(1, '#9d6a43');
    x.fillStyle = gr; x.fill();
    // mud + light dust patches
    for (let n = 0; n < 60; n++) { const cx = r() * W, cy = r() * H, rad = 10 + r() * 30; x.fillStyle = r() < 0.5 ? 'rgba(90,56,32,0.10)' : 'rgba(225,180,120,0.10)'; wrap((o) => { x.beginPath(); x.arc(cx, cy + o, rad, 0, TAU); x.fill(); }); }
    // wheel ruts: two lanes of two ruts, soft edge + dark core, slight wobble
    for (const lat of [-3.7, -2.2, 2.2, 3.7]) {
      const wob = r() * TAU;
      for (const [w, col] of [[16, 'rgba(95,60,34,0.28)'], [8, 'rgba(78,48,27,0.55)'], [3, 'rgba(60,36,20,0.55)']]) {
        x.strokeStyle = col; x.lineWidth = w; x.lineCap = 'round'; x.beginPath();
        for (let y = -8; y <= H + 8; y += 8) { const l = lat + 0.22 * Math.sin(TAU * 2 * y / H + wob); y < 0 ? x.moveTo(px(l), y) : x.lineTo(px(l), y); }
        x.stroke();
      }
    }
    // light crown in the middle
    x.strokeStyle = 'rgba(232,190,135,0.35)'; x.lineWidth = 22; x.beginPath(); x.moveTo(px(0), 0); x.lineTo(px(0), H); x.stroke();
    // pebbles + specks
    for (let n = 0; n < 900; n++) { const cx = r() * W, cy = r() * H, d = r() < 0.6; if (Math.abs(cx - W / 2) > px(7) - W / 2) continue; x.fillStyle = d ? 'rgba(70,42,24,0.45)' : 'rgba(235,205,160,0.40)'; const sz = 1 + r() * 3; wrap((o) => x.fillRect(cx, cy + o, sz, sz * (0.6 + r() * 0.6))); }
    // grass blotches creeping onto the rim (same green as the verge, so the road melts into the ground)
    for (let n = 0; n < 150; n++) {
      const sd = r() < 0.5, y = r() * H, l = (sd ? 1 : -1) * (edge(y, sd) - 0.2 + r() * 1.3), rad = 3 + r() * 9;
      x.fillStyle = r() < 0.7 ? '#74d257' : '#62c956';
      wrap((o) => { x.beginPath(); x.ellipse(px(l), y + o, rad, rad * (0.5 + r() * 0.6), r() * 3, 0, TAU); x.fill(); });
    }
    const tex = new THREE.CanvasTexture(cv); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.anisotropy = 8; tex.needsUpdate = true;
    return tex;
  }
  // road sample by (unrolled) index; undefined if it is not stored. CircuitTrack overrides this to wrap around the loop.
  sAt(i) { return this.S[i - this.base]; }

  // Smooth height of the surrounding roads (weighted average). Used away from the road so the terrain never
  // "snaps" between two road branches lying at different heights (hairpins) - that snapping made grass cut through the road.
  smoothY(x, z, fallback) {
    const cs = 32, cx = Math.floor(x / cs), cz = Math.floor(z / cs), R2 = 70 * 70, S = this.S, b = this.base;
    let sw = 0, sy = 0;
    for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) {
      const a = this.hash.get((cx + dx + 30000) * 60000 + (cz + dz + 30000)); if (!a) continue;
      for (const i of a) {
        if (i < b || i % 3) continue;
        const s = S[i - b]; if (!s) continue;
        const ex = x - s.x, ez = z - s.z, d2 = ex * ex + ez * ez;
        if (d2 < R2) { const w = 1 - d2 / R2, w2 = w * w; sw += w2; sy += w2 * s.y; }
      }
    }
    return sw > 1e-6 ? sy / sw : fallback;
  }

  // terrain height-field: a flat, sunken bed hidden under the road ribs, a soft graded shoulder, then rolling hills that grow into
  // rocky ridges and mountains with distance. Pure function of (x,z) + the road -> neighbouring tiles always meet without cracks.
  terrainY(x, z) {
    const bi = this.nearestIdx(x, z); let y0, d;
    if (bi < 0) { y0 = this.refY; d = 600; }
    else {
      const s = this.sAt(bi), ex = x - s.x, ez = z - s.z, t = (ex * s.tx + ez * s.tz) / this.ds;
      const sj = this.sAt(bi + (t > 0 ? 1 : -1));
      y0 = sj ? s.y + Math.min(1, Math.abs(t)) * (sj.y - s.y) : s.y; d = Math.sqrt(this._best);
      if (d > 14) y0 += (this.smoothY(x, z, y0) - y0) * sm(14, 30, d);
    }
    this.hy = y0; this.hd = d;
    const near = sm(14, 54, d), far = sm(45, 230, d);
    const big = this.fbm(x * 0.0055, z * 0.0055, 3);
    const rg = 1 - Math.abs(2 * this.fbm(x * 0.010 + 200, z * 0.010 - 80, 3) - 1);       // ridged noise -> crests and cliffs
    const mid = this.fbm(x * 0.03 + 40, z * 0.03 + 11, 2);
    const H = big * 0.75 + rg * rg * 0.55 - 0.28;
    const rel = near * (9 + 125 * far) * H + near * (1 - far * 0.7) * (mid - 0.5) * 7;
    this.hrel = rel;
    // ends exactly at the embankment skirt (y0 - 1.5 at d = 14.7), so skirt and terrain meet without a step
    return y0 - 1.5 * (1 - sm(14.7, 30, d)) - 3.2 * (1 - sm(11, 14.7, d)) + rel;
  }

  // height of whatever a car / object stands on (road surface, embankment or terrain)
  groundY(x, z) {
    const t = this.terrainY(x, z), d = this.hd, y0 = this.hy, L = this.limit + 1.5;
    if (d < L + 4) return Math.max(t, d <= L ? y0 + 0.08 : y0 + 0.02 - 1.5 * ((d - L) / 4));
    return t;
  }

  clear(x, z, minD) {
    const cs = 32, r = Math.ceil(minD / cs), cx = Math.floor(x / cs), cz = Math.floor(z / cs), m2 = minD * minD, b = this.base;
    for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
      const a = this.hash.get((cx + dx + 30000) * 60000 + (cz + dz + 30000)); if (!a) continue;
      for (const i of a) { if (i < b) continue; const s = this.S[i - b], ex = x - s.x, ez = z - s.z; if (ex*ex + ez*ez < m2) return false; }
    }
    return true;
  }

  obstacleLists(ci) {
    const c = Math.floor(ci / this.CH), out = [];
    for (let k = c - 1; k <= c + 1; k++) { const g = this.chunks.get(k); if (g) out.push(g.userData.obst); }
    return out;
  }

  // ---------------- streaming ----------------
  // car teleported (respawn / restart)? then everything nearby must be built right now, not 1-2 pieces per frame
  detectJump(px, pz) {
    const j = this._px !== undefined && Math.hypot(px - this._px, pz - this._pz) > 60;
    this._px = px; this._pz = pz; return j;
  }

  // terrain tiles (64 m) around the car, nearest first, with a time budget per frame instead of a fixed count
  streamTiles(px, pz, all, jump) {
    const T = 64, BUILD = 380, KEEP = 480, tx0 = Math.floor(px / T), tz0 = Math.floor(pz / T);
    // nothing to do while the car stays in the same tile and everything around it is already built
    if (!all && !jump && !this._pend && tx0 === this._tx && tz0 === this._tz) return;
    this._tx = tx0; this._tz = tz0;
    const need = [];
    for (let dx = -7; dx <= 7; dx++) for (let dz = -7; dz <= 7; dz++) {
      const tx = tx0 + dx, tz = tz0 + dz, k = tx + ',' + tz;
      if (this.tiles.has(k)) continue;
      const d = Math.hypot((tx + 0.5) * T - px, (tz + 0.5) * T - pz);
      if (d < BUILD) need.push({ tx, tz, k, d });
    }
    need.sort((a, b) => a.d - b.d);
    const t0 = performance.now(); let n = 0;
    for (; n < need.length; n++) {
      const q = need[n];
      if (!(all || (jump && q.d < 300) || n < 1 || performance.now() - t0 < 4)) break;
      this.buildTile(q.tx, q.tz, q.k);
    }
    this._pend = n < need.length;
    for (const [k, t] of this.tiles) if (Math.hypot(t.userData.cx - px, t.userData.cz - pz) > KEEP) { this.scene.remove(t); t.geometry.dispose(); this.tiles.delete(k); }
  }

  update(ci, all, px, pz) {
    const CH = this.CH;
    if (this.endless) { this.minKeep = ci + 330; while (this.base + this.S.length <= ci + 560) this.genUnit(); }
    const cur = this.s(Math.min(Math.max(ci, this.base), this.base + this.S.length - 1)); this.refY = cur.y;
    if (px === undefined) { px = cur.x; pz = cur.z; }
    const jump = this.detectJump(px, pz);

    const maxC = Math.floor((this.base + this.S.length - 1) / CH) - 1;      // last chunk whose samples all exist
    const first = Math.max(0, Math.floor((ci - 150) / CH)), last = Math.min(maxC, Math.floor((ci + 280) / CH));
    let built = 0;
    for (let c = first; c <= last; c++) {
      if (this.chunks.has(c) || c * CH < this.base) continue;
      this.build(c);
      if (!all && !jump && ++built >= 1) break;
    }
    for (const [c, g] of this.chunks) if (c < first - 1 || c > last + 1) { this.disposeChunk(g); this.chunks.delete(c); }

    this.streamTiles(px, pz, all, jump);

    const cut = Math.max(this.base, first * CH - 230) - this.base;          // endless only: forget road far behind the car
    if (this.endless && cut > 200) {
      const removed = this.S.splice(0, cut), nb = this.base + cut;
      for (const s of removed) {
        const k = this.key(s.x, s.z), a = this.hash.get(k);
        if (a) { const f = a.filter(i => i >= nb); f.length ? this.hash.set(k, f) : this.hash.delete(k); }
      }
      this.base = nb;
    }
  }

  disposeChunk(g) {
    this.scene.remove(g);
    g.traverse(o => { if (o.userData.own) o.geometry.dispose(); if (o.isInstancedMesh && o.dispose) o.dispose(); });
  }

  buildTile(tx, tz, key) {
    const N = (window.RallyTouch && window.RallyTouch.enabled) ? 8 : 12, cs = 64 / N, B = N + 3, hs = new Float32Array(B * B), dd = new Float32Array(B * B), rl = new Float32Array(B * B);
    const pos = [], col = [], idx = [], C = this.cols, c = new THREE.Color(), c2 = new THREE.Color();
    // heights incl. a 1-vertex border so slopes (-> cliff colouring) are identical on both sides of a tile edge
    for (let iz = -1; iz <= N + 1; iz++) for (let ix = -1; ix <= N + 1; ix++) {
      const k = (iz + 1) * B + ix + 1; hs[k] = this.terrainY(tx * 64 + ix * cs, tz * 64 + iz * cs); dd[k] = this.hd; rl[k] = this.hrel;
    }
    for (let iz = 0; iz <= N; iz++) for (let ix = 0; ix <= N; ix++) {
      const k = (iz + 1) * B + ix + 1, x = tx * 64 + ix * cs, z = tz * 64 + iz * cs, y = hs[k], d = dd[k], rel = rl[k];
      const gx = (hs[k + 1] - hs[k - 1]) / (2 * cs), gz = (hs[k + B] - hs[k - B]) / (2 * cs), sl = Math.hypot(gx, gz);
      c.copy(C.g1).lerp(C.g2, this.vn(x * 0.035, z * 0.035));
      c.lerp(C.light, 0.55 * sm(0.55, 0.8, this.vn(x * 0.012 + 9, z * 0.012 - 4)));
      c.lerp(C.verge, 0.8 * (1 - sm(10, 34, d)));
      const rockAmt = sm(0.5, 0.95, sl) * sm(16, 36, d);                        // steep faces turn into rock, never next to the road
      c2.copy(C.rockD).lerp(C.rockL, this.vn(x * 0.07 + 3, z * 0.07));
      c.lerp(c2, rockAmt);
      c.lerp(C.high, sm(85, 135, rel) * (1 - rockAmt));
      c.lerp(C.snow, sm(112, 160, rel));
      pos.push(x, y, z); col.push(c.r, c.g, c.b);
    }
    for (let iz = 0; iz < N; iz++) for (let ix = 0; ix < N; ix++) {
      const a = iz * (N + 1) + ix, b = a + 1, cc = a + N + 1, d = cc + 1;
      if ((ix + iz) & 1) idx.push(a, cc, d, a, d, b); else idx.push(a, cc, b, b, cc, d);       // alternating diagonals: no directional streaks
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(idx); g.computeVertexNormals();
    const m = new THREE.Mesh(g, this.tileMat); m.receiveShadow = true;
    m.userData.cx = (tx + 0.5) * 64; m.userData.cz = (tz + 0.5) * 64;
    this.scene.add(m); this.tiles.set(key, m);
  }

  pt(i, side, lat, al) { const s = this.s(i); return { x: s.x + s.rx * side * lat + s.tx * al, z: s.z + s.rz * side * lat + s.tz * al, s }; }

  build(c) {
    const CH = this.CH, i0 = c * CH, g = new THREE.Group(), R = this.chunkRng(c), M = this.M, G = this.G, hw = this.hw;
    const obst = g.userData.obst = [];
    const v0 = (i0 * this.ds / 35.2) % 1;                  // texture v restarts per chunk with the same fractional phase -> seamless, no float drift
    const rib = (a, b, ya, yb, mat, uv) => {
      const pos = [], idx = [], uvs = [];
      for (let i = 0; i <= CH; i++) {
        const s = this.s(i0 + i); pos.push(s.x + s.rx*a, s.y + ya, s.z + s.rz*a, s.x + s.rx*b, s.y + yb, s.z + s.rz*b);
        if (uv) { const v = v0 + i * this.ds / 35.2; uvs.push(0, v, 1, v); }
      }
      for (let i = 0; i < CH; i++) { const j = i * 2; idx.push(j, j+1, j+2, j+1, j+3, j+2); }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      if (uv) geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
      geo.setIndex(idx); geo.computeVertexNormals();
      const m = new THREE.Mesh(geo, mat); m.receiveShadow = true; m.userData.own = true; g.add(m);
    };
    const L = this.limit + 1.5, E = this.roadHalf;
    rib(L, L + 4, 0.02, -1.5, this.mat.bank); rib(-(L + 4), -L, -1.5, 0.02, this.mat.bank);   // embankment skirts
    rib(-L, L, 0.02, 0.02, this.mat.verge);                                                    // grass under the road
    rib(-E, E, 0.08, 0.08, this.mat.road, true);                                               // textured dirt road with ragged edges

    const mk = (geo, mat, sh) => new InstSet(geo, mat, sh);
    const trunk = mk(G.trunk, M.trunk, true), t1 = mk(G.c1, M.white, true), t2 = mk(G.c2, M.white, true), t3 = mk(G.c3, M.white, true),
      rock = mk(G.rock, M.white, true), body = mk(G.body, M.white, true), head = mk(G.head, M.white, true),
      legs = mk(G.legs, M.legs, true), hay = mk(G.hay, M.hay, true), cone = mk(G.cone, M.cone, false),
      pole = mk(G.pole, M.white, true), post = mk(G.post, M.dark, true),
      board = mk(G.board, M.board, true), stripe = mk(G.stripe, M.dark, false),
      flower = mk(G.flower, M.white, false), fpost = mk(G.fpost, M.wood, true), rail = mk(G.rail, M.wood, true), log = mk(G.log, M.wood, true);

    const pick = () => i0 + Math.floor(R() * CH), side = () => R() < 0.5 ? -1 : 1;
    const pines = [[0x2f8f45, 0x3fa650, 0x57bd5f], [0x3b9d4a, 0x4cb457, 0x66c96a], [0x2c8a4a, 0x3a9e55, 0x4fb865], [0x45a845, 0x58bd55, 0x76d06b]];
    const bushes = [0x2fbf4a, 0x45d65e, 0x3aa84a, 0x58c24f], greys = [0x8c909c, 0x7b7f8c, 0xa0a4b0, 0x6e7482];

    for (let n = 0; n < 56; n++) {                    // pines: tiered, varied, never right at the road and never on a cliff face
      const sd = side(), p = this.pt(pick(), sd, hw + 8 + R() * R() * 62, (R() - 0.5) * 10);
      if (!this.clear(p.x, p.z, hw + 7)) continue;
      const sc = 0.75 + R() * 0.8 + (R() < 0.12 ? 0.5 : 0), gy = this.groundY(p.x, p.z);
      if (Math.abs(this.terrainY(p.x + 3, p.z) - gy) > 2.4 || Math.abs(this.terrainY(p.x, p.z + 3) - gy) > 2.4) continue;
      const pal = pines[Math.floor(R() * pines.length)], ry = R() * 6, wd = 0.9 + R() * 0.25;
      trunk.add(p.x, gy + 1.2 * sc, p.z, ry, sc, sc, sc);
      t1.add(p.x, gy + 3.7 * sc, p.z, ry, sc * wd, sc, sc * wd, pal[0]);
      t2.add(p.x, gy + 5.6 * sc, p.z, ry, sc * wd, sc, sc * wd, pal[1]);
      t3.add(p.x, gy + 7.6 * sc, p.z, ry, sc * wd, sc, sc * wd, pal[2]);
      obst.push([p.x, p.z, 0.55 * sc]);
    }
    for (let n = 0; n < 30; n++) {                    // rocks + boulders
      const big = R() < 0.2, p = this.pt(pick(), side(), hw + 3 + (big ? 6 : 0) + R() * 35, (R() - 0.5) * 8);
      if (!this.clear(p.x, p.z, hw + (big ? 5 : 3))) continue;
      const sc = big ? 3 + R() * 2.6 : 0.7 + R() * 1.6, gy = this.groundY(p.x, p.z);
      rock.add(p.x, gy + sc * 0.3, p.z, R() * 6, sc, sc * (0.55 + R() * 0.35), sc * 1.2, greys[Math.floor(R() * greys.length)]);
      obst.push([p.x, p.z, sc * 0.95]);
    }
    for (let n = 0; n < 26; n++) {                    // bushes
      const p = this.pt(pick(), side(), hw + 2.5 + R() * 30, (R() - 0.5) * 8);
      if (!this.clear(p.x, p.z, hw + 2.5)) continue;
      const sc = 0.6 + R() * 1.0, gy = this.groundY(p.x, p.z);
      rock.add(p.x, gy + sc * 0.55, p.z, R() * 6, sc * 1.3, sc, sc * 1.3, bushes[Math.floor(R() * bushes.length)]);
    }
    const fcol = [0xffffff, 0xffd23f, 0xff8fb1, 0xb48cff, 0xff7a1a];
    for (let n = 0; n < 14; n++) {                    // wild flower clusters
      const b = this.pt(pick(), side(), hw + 3.5 + R() * 14, (R() - 0.5) * 14);
      if (!this.clear(b.x, b.z, hw + 4)) continue;
      const fc = fcol[Math.floor(R() * fcol.length)], cnt = 5 + Math.floor(R() * 6);
      for (let j = 0; j < cnt; j++) { const fx = b.x + (R() - 0.5) * 3.2, fz = b.z + (R() - 0.5) * 3.2; flower.add(fx, this.groundY(fx, fz) + 0.16, fz, R() * 6, 1, 1, 1, R() < 0.2 ? 0xffffff : fc); }
    }
    for (let n = 0; n < 3; n++) {                     // wooden fence runs beside the road
      if (R() > 0.55) continue;
      const sd = side(), len = 4 + Math.floor(R() * 5), st = i0 + Math.floor(R() * (CH - 2 * len - 2)); let prev = null;
      for (let j = 0; j <= len; j++) {
        const p = this.pt(st + j * 2, sd, hw + 3.4, 0);
        if (!this.clear(p.x, p.z, hw + 2.6)) { prev = null; continue; }
        const gy = this.groundY(p.x, p.z); fpost.add(p.x, gy + 0.6, p.z, 0, 1, 1, 1);
        if (prev) {
          const dx = p.x - prev.x, dz = p.z - prev.z, l = Math.hypot(dx, dz), ry = Math.atan2(dx, dz), my = (gy + prev.gy) / 2;
          rail.add((p.x + prev.x) / 2, my + 0.45, (p.z + prev.z) / 2, ry, 1, 1, l); rail.add((p.x + prev.x) / 2, my + 0.85, (p.z + prev.z) / 2, ry, 1, 1, l);
        }
        prev = { x: p.x, z: p.z, gy };
      }
    }
    if (R() < 0.35) {                                 // fallen log
      const p = this.pt(pick(), side(), hw + 5 + R() * 20, 0);
      if (this.clear(p.x, p.z, hw + 4)) log.add(p.x, this.groundY(p.x, p.z) + 0.3, p.z, R() * 6, 1, 1, 1);
    }
    const shirt = [0xff7a1a, 0xffd23f, 0x2ec4b6, 0xe8e8e8, 0xd7263d, 0x3a86ff, 0x9b5de5], skin = [0xf2c9a0, 0xc68642, 0x8d5524, 0xffdbac];
    for (let n = 0; n < 16; n++) {                    // spectator crowds
      const i = pick(), sd = side(), cnt = 4 + Math.floor(R() * 6), al0 = (R() - 0.5) * 20;
      for (let j = 0; j < cnt; j++) {
        const p = this.pt(i, sd, hw + 3.5 + R() * 4, al0 + (R() - 0.5) * 7);
        if (!this.clear(p.x, p.z, hw + 2.8)) continue;
        const ry = Math.atan2(-sd * p.s.rx, -sd * p.s.rz), gy = this.groundY(p.x, p.z);
        body.add(p.x, gy + 0.95, p.z, ry, 1, 1, 1, shirt[Math.floor(R() * shirt.length)]);
        head.add(p.x, gy + 1.78, p.z, ry, 1, 1, 1, skin[Math.floor(R() * skin.length)]);
        legs.add(p.x, gy + 0.2, p.z, ry, 1, 1, 1);
      }
    }
    for (let n = 0; n < 6; n++) {                     // hay bales
      const i = pick(), p = this.pt(i, side(), hw + 2.8, 0), gy = this.groundY(p.x, p.z);
      hay.add(p.x, gy + 0.5, p.z, Math.atan2(p.s.tx, p.s.tz), 1, 1, 1); obst.push([p.x, p.z, 0.9]);
    }
    for (let i = i0; i < i0 + CH; i++) {
      const s = this.s(i);
      if (i % 5 === 0) for (const sd of [-1, 1]) {    // red/white roadside stakes
        const p = this.pt(i, sd, hw + 1.3, 0);
        pole.add(p.x, s.y + 0.8, p.z, 0, 1, 1, 1, (i / 5) % 2 ? 0xe03a3a : 0xffffff);
      }
      if (i % 9 === 0 && R() < 0.6) { const p = this.pt(i, side(), hw + 0.9, 0); cone.add(p.x, s.y + 0.5, p.z, 0, 1, 1, 1); }
      if (Math.abs(s.k) > 0.035 && i % 4 === 0) {     // chevron boards on the outside of tight bends
        const p = this.pt(i, Math.sign(s.k), hw + 2.2, 0), ry = Math.atan2(-s.tx, -s.tz), gy = s.y + 0.08;
        post.add(p.x, gy + 0.95, p.z, ry, 1, 1, 1); board.add(p.x, gy + 2.1, p.z, ry, 1, 1, 1); stripe.add(p.x, gy + 2.1, p.z, ry, 1, 1, 1);
      }
    }
    [trunk, t1, t2, t3, rock, body, head, legs, hay, cone, pole, post, board, stripe, flower, fpost, rail, log].forEach(s => s.build(g));
    if (c === 0) this.buildStart(g);
    if (this.finishIdx !== undefined && c === Math.floor(this.finishIdx / CH)) this.buildGate(g, this.finishIdx);
    this.scene.add(g); this.chunks.set(c, g);
  }

  buildStart(g) { this.buildGate(g, 25); }

  // checkered line + gate on road sample idx (start and finish of a stage)
  buildGate(g, idx) {
    const cv = document.createElement('canvas'); cv.width = 128; cv.height = 16;
    const x = cv.getContext('2d');
    for (let i = 0; i < 16; i++) for (let j = 0; j < 2; j++) { x.fillStyle = (i + j) % 2 ? '#fff' : '#111'; x.fillRect(i * 8, j * 8, 8, 8); }
    const tex = new THREE.CanvasTexture(cv); tex.magFilter = THREE.NearestFilter;
    const s = this.s(idx), ry = Math.atan2(s.tx, s.tz);
    const line = new THREE.Mesh(new THREE.PlaneGeometry(this.hw * 2, 2), new THREE.MeshBasicMaterial({ map: tex }));
    line.rotation.x = -Math.PI / 2;
    const holder = new THREE.Group(); holder.add(line); holder.position.set(s.x, s.y + 0.14, s.z); holder.rotation.y = ry; g.add(holder);
    const mat = new THREE.MeshLambertMaterial({ color: 0xff7a1a, flatShading: true });
    for (const d of [-1, 1]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.7, 7, 0.7), mat);
      post.position.set(s.x + s.rx * d * (this.hw + 1.2), s.y + 3.5, s.z + s.rz * d * (this.hw + 1.2)); post.castShadow = true; g.add(post);
    }
    const beam = new THREE.Mesh(new THREE.BoxGeometry((this.hw + 1.2) * 2, 1.2, 0.8), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    beam.position.set(s.x, s.y + 7, s.z); beam.rotation.y = ry; beam.castShadow = true; g.add(beam);
  }
}
