/* Touch controls: created on touch devices (phone / tablet), either right at start or on the very first touch.
   Desktop players with a mouse + keyboard never see them.
   Pressed buttons are shared with game.js through window.RallyTouch.keys (same key codes as the keyboard).
   Every finger is tracked on its own: gas + steer + drift at the same time works, and you can slide a thumb
   from LEFT to RIGHT without lifting it. */
(() => {
  const mq = (q) => !!(window.matchMedia && matchMedia(q).matches);
  const api = window.RallyTouch = { enabled: false, built: false, keys: {}, show() {}, onPause() {}, onReset() {} };   // enabled = real touch device (lighter renderer, rotate hint); built = on-screen buttons exist (always, on every device)
  const CODES = ['KeyA', 'KeyD', 'KeyW', 'KeyS', 'Space'];

  function markTouch() {                 // real touch device detected
    api.enabled = true;
    document.body.classList.add('touch');
  }
  function build() {
    if (api.built) return;
    api.built = true;
    document.body.classList.add('touch-ui');
    const arrow = (dir) => `<svg viewBox="0 0 40 40" width="40" height="40" aria-hidden="true"><polygon fill="currentColor" points="${dir < 0 ? '28,6 10,20 28,34' : '12,6 30,20 12,34'}"/></svg>`;
    const root = document.createElement('div');
    root.id = 'touch'; root.className = 'hidden';
    root.innerHTML = `
      <div class="t-left"><button class="tbtn t-steer" data-k="KeyA" aria-label="Steer left">${arrow(-1)}</button><button class="tbtn t-steer" data-k="KeyD" aria-label="Steer right">${arrow(1)}</button></div>
      <div class="t-right"><button class="tbtn t-drift" data-k="Space">DRIFT</button><button class="tbtn t-brake" data-k="KeyS">BRAKE</button><button class="tbtn t-gas" data-k="KeyW">GAS</button></div>
      <button class="tbtn t-small t-pause" id="tPause" aria-label="Pause"><svg viewBox="0 0 24 24" width="22" height="22"><rect x="6" y="5" width="4" height="14" fill="currentColor"/><rect x="14" y="5" width="4" height="14" fill="currentColor"/></svg></button>
      <button class="tbtn t-small t-reset" id="tReset" aria-label="Back on road"><svg viewBox="0 0 24 24" width="22" height="22"><path fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" d="M5 12a7 7 0 1 0 2.2-5.1M5 4v4h4"/></svg></button>`;
    document.body.appendChild(root);

    // pointerId -> key code it currently presses (null = finger is on no button)
    const active = new Map();
    const buttons = root.querySelectorAll('[data-k]');
    const refresh = () => {
      const on = new Set(active.values());
      for (const c of CODES) api.keys[c] = on.has(c);
      buttons.forEach((b) => b.classList.toggle('on', on.has(b.dataset.k)));
    };
    const keyAt = (x, y) => { const el = document.elementFromPoint(x, y), b = el && el.closest ? el.closest('#touch [data-k]') : null; return b ? b.dataset.k : null; };
    const end = (e) => { if (active.delete(e.pointerId)) refresh(); };

    root.addEventListener('pointerdown', (e) => {
      const b = e.target.closest && e.target.closest('[data-k]'); if (!b) return;
      e.preventDefault();
      try { b.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
      active.set(e.pointerId, b.dataset.k); refresh();
    });
    root.addEventListener('pointermove', (e) => {
      if (!active.has(e.pointerId)) return;
      const k = keyAt(e.clientX, e.clientY);
      if (active.get(e.pointerId) !== k) { active.set(e.pointerId, k); refresh(); }
    });
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) root.addEventListener(ev, end);

    const tap = (id, fn) => document.getElementById(id).addEventListener('pointerdown', (e) => { e.preventDefault(); fn(); });
    tap('tPause', () => api.onPause()); tap('tReset', () => api.onReset());

    // no scrolling, pinch-zoom or long-press menus while driving (menus / result panels may still scroll)
    document.addEventListener('touchmove', (e) => {
      if (document.body.classList.contains('playing') && !(e.target.closest && e.target.closest('.panel'))) e.preventDefault();
    }, { passive: false });
    for (const ev of ['gesturestart', 'gesturechange']) document.addEventListener(ev, (e) => e.preventDefault(), { passive: false });
    document.addEventListener('contextmenu', (e) => { if (e.target.closest && e.target.closest('#touch, #hud, canvas')) e.preventDefault(); });

    const hint = document.createElement('div'); hint.id = 'rotate';
    hint.innerHTML = '<div>Rotate your phone<small>Rally Drift plays best in landscape</small></div>'; document.body.appendChild(hint);

    api.show = (on) => {
      root.classList.toggle('hidden', !on);
      if (!on) { active.clear(); refresh(); }
    };
  }

  const likelyTouch = mq('(pointer: coarse)') || mq('(hover: none)');
  const hasTouch = navigator.maxTouchPoints > 0 || 'ontouchstart' in window;
  const start = () => {
    build();                                              // buttons are visible on EVERY device (mouse works on them too)
    if (likelyTouch && hasTouch) markTouch();
    else addEventListener('touchstart', markTouch, { once: true, passive: true });   // hybrid devices: touch mode on first real touch
  };
  if (document.body) start(); else addEventListener('DOMContentLoaded', start);
})();
