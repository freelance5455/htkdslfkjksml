/* Rally Drift service worker: caches the game so it starts instantly and works offline after the first visit.
   Bump VERSION whenever you change any game file. */
const VERSION = 'rally-drift-v1';
const CORE = ['./', 'index.html', 'style.css', 'cg.js', 'track.js', 'circuit.js', 'car.js', 'touch.js', 'mobile.js', 'audio.js', 'game.js',
  'rally_drift_loadingscreen.webp', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => Promise.all(CORE.map((u) => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET') return;
  // never cache the CrazyGames SDK / ads
  if (url.hostname.includes('crazygames')) return;
  const sameOrigin = url.origin === location.origin, threeCdn = url.hostname === 'cdnjs.cloudflare.com' || url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
  if (!sameOrigin && !threeCdn) return;
  // stale-while-revalidate: instant from cache, refreshed in the background
  e.respondWith(caches.open(VERSION).then((cache) => cache.match(req, { ignoreSearch: true }).then((hit) => {
    const net = fetch(req).then((res) => { if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone()); return res; }).catch(() => hit);
    return hit || net;
  })));
});
