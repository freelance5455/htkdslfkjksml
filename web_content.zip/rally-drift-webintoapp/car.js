/* Car: catalog (11 cars, each modelled on a real-world car type), paint colors, arcade physics, mesh, collisions, dust.
   cfg: maxSpeed (m/s), accel, brake, steer (turn rate), grip (sideways grip: lower = more drift), driftGrip (grip while holding Space).

   BODY MODELS: every car is a "lofted" body. A side silhouette (deck line + roof line) is written as a few rows and smoothed with
   Catmull-Rom, then lofted into a lower body (painted), a greenhouse (glass + pillars + painted roof) and a livery stripe.
   Wheel arches, flares, lamps, mirrors, bumpers, decals, wings, racks ... are added on top (see Car.setModel).

   body: { L, W, clr, wr, wz, num, stripe, light, low, cab, extras }
     L / W   length / width (m)          clr  ground clearance (m)          wr  wheel radius        wz  wheelbase / 2
     low     rows [z, deckHeight, widthFraction]  rear (-z) -> front (+z)  : hood, shoulders, trunk
     cab     rows [z, roofHeight | null, widthFraction]                    : windshield base -> roof -> rear window base (null = deck height)
     stripe  'center' | 'twin' | 'none'        light  'round' | 'rect'        num  race number on the doors
     extras  'wingBig' 'wingSmall' 'duck' 'bar' 'pods' 'scoop' 'roofScoop' 'rack' 'spots' 'spare' 'snorkel' 'bed' 'rollbar' 'splitter' 'pipes' 'mudflaps' 'bumperChrome' */
const CAR_COLORS = [
  { name: 'Snow', hex: 0xf4f4f4 }, { name: 'Flame', hex: 0xff7a1a }, { name: 'Racing Red', hex: 0xd7263d }, { name: 'Cobalt', hex: 0x3a86ff },
  { name: 'Lagoon', hex: 0x2ec4b6 }, { name: 'Sunny', hex: 0xffd23f }, { name: 'Violet', hex: 0x9b5de5 }, { name: 'Coal', hex: 0x2b2f3a },
];

// index 0 is the default car. (Names are original on purpose: no real brand / model names -> no trademark problems.)
const CAR_MODELS = [
  { name: 'Group Rally', tag: 'Boxy 80s rally monster, balanced all-rounder', accent: 0xffb020,
    cfg: { maxSpeed: 48, accel: 28, brake: 55, reverseMax: 12, steer: 2.5, grip: 3.4, driftGrip: 0.4 },
    body: { L: 4.2, W: 1.94, clr: 0.30, wr: 0.40, wz: 1.30, num: 1, stripe: 'center', light: 'round', extras: ['wingBig', 'pods', 'mudflaps'],
      low: [[-2.1, .80, .84], [-2.0, .98, .95], [-1.8, 1.06, 1], [-1.0, 1.04, 1], [0.2, 1.02, 1], [1.1, 1.0, 1], [1.8, .88, .96], [2.1, .74, .88]],
      cab: [[-1.45, null, .86], [-1.05, 1.55, .80], [-0.3, 1.62, .78], [0.2, 1.60, .78], [1.0, null, .86]] } },
  { name: 'Sprint Hatch', tag: 'Light hot hatch, explodes off the line', accent: 0xffffff,
    cfg: { maxSpeed: 42, accel: 36, brake: 60, reverseMax: 12, steer: 2.9, grip: 3.9, driftGrip: 0.5 },
    body: { L: 3.7, W: 1.78, clr: 0.28, wr: 0.36, wz: 1.15, num: 7, stripe: 'twin', light: 'rect', extras: ['duck', 'mudflaps'],
      low: [[-1.85, .78, .86], [-1.75, .94, .95], [-1.5, 1.0, 1], [-0.4, .98, 1], [0.5, .96, 1], [1.3, .90, .98], [1.75, .80, .92], [1.85, .70, .86]],
      cab: [[-1.6, null, .86], [-1.35, 1.45, .82], [-0.4, 1.50, .80], [0.4, 1.48, .80], [1.1, null, .88]] } },
  { name: 'Thunder GT', tag: 'Long-nose grand tourer, monster top speed', accent: 0xd7263d,
    cfg: { maxSpeed: 56, accel: 25, brake: 52, reverseMax: 12, steer: 2.2, grip: 3.0, driftGrip: 0.35 },
    body: { L: 4.7, W: 1.96, clr: 0.26, wr: 0.42, wz: 1.45, num: 3, stripe: 'center', light: 'rect', extras: ['wingBig', 'splitter', 'pipes'],
      low: [[-2.35, .82, .86], [-2.25, .98, .95], [-2.0, 1.04, 1], [-1.2, 1.02, 1], [0.0, 1.00, 1], [1.2, .94, 1], [2.0, .82, .95], [2.35, .64, .86]],
      cab: [[-1.7, null, .84], [-1.1, 1.36, .80], [-0.5, 1.46, .78], [0.1, 1.42, .78], [0.95, null, .88]] } },
  { name: 'Mud Pup', tag: 'Compact 4x4, grip for days on the dirt', accent: 0xffd23f,
    cfg: { maxSpeed: 44, accel: 30, brake: 58, reverseMax: 12, steer: 2.6, grip: 4.5, driftGrip: 0.6 },
    body: { L: 3.8, W: 1.9, clr: 0.46, wr: 0.50, wz: 1.2, num: 4, stripe: 'none', light: 'round', extras: ['bar', 'spare', 'snorkel', 'mudflaps'],
      low: [[-1.9, .98, .88], [-1.8, 1.16, .96], [-1.6, 1.22, 1], [-0.6, 1.20, 1], [0.6, 1.18, 1], [1.3, 1.12, 1], [1.75, 1.04, .96], [1.9, .92, .92]],
      cab: [[-1.7, null, .90], [-1.6, 1.88, .86], [-0.2, 1.92, .85], [0.55, 1.90, .85], [0.95, null, .90]] } },
  { name: 'Drift King', tag: 'Rear-drive coupe, born sideways', accent: 0x9b5de5,
    cfg: { maxSpeed: 47, accel: 27, brake: 50, reverseMax: 12, steer: 3.0, grip: 2.5, driftGrip: 0.25 },
    body: { L: 4.45, W: 1.86, clr: 0.26, wr: 0.40, wz: 1.35, num: 86, stripe: 'twin', light: 'rect', extras: ['wingBig', 'pipes', 'splitter'],
      low: [[-2.22, .84, .86], [-2.15, .98, .95], [-1.9, 1.04, 1], [-1.2, 1.03, 1], [0, 1.0, 1], [1.2, .96, 1], [2.0, .86, .96], [2.22, .72, .88]],
      cab: [[-1.2, null, .86], [-0.7, 1.36, .80], [-0.1, 1.42, .78], [0.4, 1.38, .78], [1.1, null, .88]] } },
  { name: 'Hill Hammer', tag: 'Heavy pickup, stable and hard to stop', accent: 0x3a86ff,
    cfg: { maxSpeed: 52, accel: 22, brake: 62, reverseMax: 12, steer: 2.0, grip: 3.7, driftGrip: 0.5 },
    body: { L: 5.0, W: 2.0, clr: 0.46, wr: 0.50, wz: 1.5, num: 9, stripe: 'none', light: 'rect', extras: ['bar', 'bed', 'rollbar', 'mudflaps'],
      low: [[-2.5, 1.0, .90], [-2.4, 1.2, .97], [-2.2, 1.26, 1], [-0.8, 1.26, 1], [0.3, 1.22, 1], [1.4, 1.20, 1], [2.2, 1.10, .96], [2.5, .96, .90]],
      cab: [[-0.7, null, .88], [-0.55, 1.88, .84], [0.1, 1.94, .83], [0.5, 1.90, .83], [1.1, null, .88]] } },
  { name: 'Pocket Rocket', tag: 'Tiny city car, turns on a coin', accent: 0x2ec4b6,
    cfg: { maxSpeed: 40, accel: 34, brake: 56, reverseMax: 12, steer: 3.1, grip: 3.3, driftGrip: 0.42 },
    body: { L: 3.2, W: 1.7, clr: 0.28, wr: 0.34, wz: 1.0, num: 5, stripe: 'twin', light: 'round', extras: ['splitter', 'mudflaps'],
      low: [[-1.6, .78, .86], [-1.5, .96, .95], [-1.3, 1.02, 1], [-0.4, 1.0, 1], [0.4, .98, 1], [1.1, .92, .98], [1.5, .84, .94], [1.6, .74, .88]],
      cab: [[-1.4, null, .88], [-1.2, 1.50, .84], [-0.3, 1.56, .82], [0.3, 1.54, .82], [0.85, null, .90]] } },
  { name: 'Desert Viper', tag: 'Low, wide supercar, venomous in fast sweeps', accent: 0xffd23f,
    cfg: { maxSpeed: 54, accel: 27, brake: 54, reverseMax: 12, steer: 2.4, grip: 3.2, driftGrip: 0.38 },
    body: { L: 4.5, W: 2.06, clr: 0.20, wr: 0.40, wz: 1.4, num: 11, stripe: 'center', light: 'rect', extras: ['wingSmall', 'splitter', 'scoop', 'pipes'],
      low: [[-2.25, .70, .86], [-2.15, .88, .96], [-1.8, .98, 1], [-0.8, .98, 1], [0.4, .92, 1], [1.4, .86, .98], [2.0, .70, .94], [2.25, .54, .88]],
      cab: [[-1.4, null, .84], [-0.9, 1.20, .78], [-0.2, 1.30, .74], [0.4, 1.22, .76], [1.1, null, .86]] } },
  { name: 'Ridge Runner', tag: 'Tall overlander, laughs at rough roads', accent: 0xff7a1a,
    cfg: { maxSpeed: 46, accel: 29, brake: 58, reverseMax: 12, steer: 2.5, grip: 4.2, driftGrip: 0.55 },
    body: { L: 4.4, W: 2.0, clr: 0.52, wr: 0.55, wz: 1.35, num: 6, stripe: 'none', light: 'round', extras: ['rack', 'spots', 'snorkel', 'spare', 'mudflaps'],
      low: [[-2.2, 1.04, .90], [-2.1, 1.22, .97], [-1.9, 1.30, 1], [-0.9, 1.28, 1], [0.4, 1.26, 1], [1.4, 1.22, 1], [2.0, 1.12, .96], [2.2, 1.0, .90]],
      cab: [[-2.05, null, .90], [-1.95, 2.0, .86], [-0.6, 2.08, .85], [0.4, 2.04, .85], [1.05, null, .90]] } },
  { name: 'Nitro Wedge', tag: 'Wedge-shaped rocket, needs a long runway', accent: 0x00e5ff,
    cfg: { maxSpeed: 58, accel: 20, brake: 48, reverseMax: 12, steer: 1.9, grip: 3.3, driftGrip: 0.4 },
    body: { L: 5.0, W: 2.0, clr: 0.22, wr: 0.38, wz: 1.55, num: 2, stripe: 'twin', light: 'rect', extras: ['wingBig', 'splitter', 'pipes'],
      low: [[-2.5, .80, .86], [-2.4, .98, .95], [-2.0, 1.06, 1], [-0.6, .98, 1], [0.8, .92, 1], [1.7, .84, .98], [2.1, .64, .94], [2.5, .46, .86]],
      cab: [[-1.3, null, .84], [-0.8, 1.30, .80], [-0.1, 1.34, .76], [0.7, 1.16, .76], [1.5, null, .88]] } },
  { name: 'Bumble Bug', tag: 'Retro round-nose, grippy and friendly', accent: 0xffffff,
    cfg: { maxSpeed: 40, accel: 31, brake: 60, reverseMax: 12, steer: 2.4, grip: 4.5, driftGrip: 0.6 },
    body: { L: 3.6, W: 1.8, clr: 0.30, wr: 0.38, wz: 1.15, num: 53, stripe: 'twin', light: 'round', extras: ['bumperChrome', 'mudflaps'],
      low: [[-1.8, .74, .80], [-1.7, .92, .92], [-1.45, 1.02, .98], [-0.6, 1.04, 1], [0.4, .98, 1], [1.2, .92, .98], [1.65, .82, .90], [1.8, .70, .82]],
      cab: [[-1.4, null, .86], [-1.0, 1.38, .80], [-0.3, 1.56, .78], [0.3, 1.50, .78], [0.95, null, .88]] } },
];

// ---------------- geometry helpers ----------------
const _cr = (p0, p1, p2, p3, t) => 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);
// Catmull-Rom resample of table rows (every column is smoothed the same way)
function sampleRows(rows, n) {
  const m = rows.length, out = [];
  for (let i = 0; i < n; i++) {
    const u = i / (n - 1) * (m - 1), k = Math.min(m - 2, Math.floor(u)), t = u - k, r = [];
    for (let c = 0; c < rows[0].length; c++) { const g = (j) => rows[Math.max(0, Math.min(m - 1, j))][c]; r.push(_cr(g(k - 1), g(k), g(k + 1), g(k + 2), t)); }
    out.push(r);
  }
  return out;
}
// linear lookup of column c at position z in rows sorted by z
function rowAt(rows, z, c) {
  if (z <= rows[0][0]) return rows[0][c];
  for (let i = 1; i < rows.length; i++) if (z <= rows[i][0]) { const a = rows[i - 1], b = rows[i], t = (z - a[0]) / ((b[0] - a[0]) || 1); return a[c] + (b[c] - a[c]) * t; }
  return rows[rows.length - 1][c];
}
// Loft: rings (arrays of [x,y,z]) -> quads between consecutive rings. edges: [[a,b],...] ring edges to skin. matOf(slice,a,b) -> material index.
// capMat: material index for flat end caps (or null). Returns a BufferGeometry with one draw group per material index.
function loft(rings, edges, matOf, capMat) {
  const buckets = [];
  const tri = (m, a, b, c) => { (buckets[m] = buckets[m] || []).push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]); };
  for (let s = 0; s < rings.length - 1; s++) for (const [a, b] of edges) {
    const m = matOf(s, a, b), p00 = rings[s][a], p01 = rings[s][b], p10 = rings[s + 1][a], p11 = rings[s + 1][b];
    tri(m, p00, p01, p10); tri(m, p01, p11, p10);
  }
  if (capMat !== null && capMat !== undefined) for (const r of [rings[0], rings[rings.length - 1]]) {
    const c = [0, 0, 0]; for (const p of r) { c[0] += p[0] / r.length; c[1] += p[1] / r.length; c[2] += p[2] / r.length; }
    for (let i = 0; i < r.length; i++) tri(capMat, c, r[i], r[(i + 1) % r.length]);
  }
  const pos = [], g = new THREE.BufferGeometry();
  buckets.forEach((arr, m) => { if (!arr) return; g.addGroup(pos.length / 3, arr.length / 3, m); for (const v of arr) pos.push(v); });
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.computeVertexNormals();
  return g;
}

class Car {
  constructor(scene) {
    this.cfg = Object.assign({}, CAR_MODELS[0].cfg);
    this.x = 0; this.z = 0; this.h = 0; this.vx = 0; this.vz = 0; this.yawRate = 0;
    this.hint = 0; this.y = 0; this.lat = 0; this.slope = 0; this.track = null; this.onRoad = true; this.vF = 0; this.vR = 0; this.speed = 0; this.steerVis = 0;
    this.aF = 0; this.braking = false; this.pitch = 0;
    this.model = 0; this.wheelR = 0.42; this.wheels = []; this.body = null; this.accentMat = null; this.own = [];

    this.group = new THREE.Group(); this.group.rotation.order = 'YXZ';
    const M = (c) => new THREE.MeshLambertMaterial({ color: c, flatShading: true });
    const D = (c) => { const m = M(c); m.side = THREE.DoubleSide; return m; };
    // polygon offset pulls overlay layers (decals, stripes, flares, splitters, wheel wells) toward the camera -> no z-fighting flicker against the body
    const O = (m) => { m.polygonOffset = true; m.polygonOffsetFactor = -2; m.polygonOffsetUnits = -2; return m; };
    this.O = O;
    const G = () => new THREE.MeshLambertMaterial({ color: 0x2a4560, flatShading: true, transparent: true, opacity: 0.42, side: THREE.DoubleSide, depthWrite: false });
    this.paint = D(CAR_COLORS[0].hex);
    this.paintOff = O(D(CAR_COLORS[0].hex));
    this.mat = {
      dark: M(0x15171f), black: M(0x0a0b0f), rubber: M(0x111319), rim: M(0xc9ccd6), glass: G(), yellow: M(0xffd23f), chrome: M(0xd9dce6),
      lamp: new THREE.MeshBasicMaterial({ color: 0xfff6cc }), tail: new THREE.MeshBasicMaterial({ color: 0x9c1020 }),
      disc: M(0x8f939e), caliper: M(0xd7263d), housing: M(0x0b0c11), interior: M(0x1c1e27), seat: M(0x343947),
      pipeIn: D(0x050507), blackOff: O(M(0x0a0b0f)), rubberD: D(0x111319), rimD: D(0xc9ccd6), chromeD: D(0xd9dce6),
      cover: new THREE.MeshLambertMaterial({ color: 0xdff0ff, transparent: true, opacity: 0.24, depthWrite: false }),
      tailHouse: M(0x1a0609), amber: new THREE.MeshBasicMaterial({ color: 0xff9a1a }),
    };
    this.M = M; this.D = D;
    this.setModel(0, CAR_COLORS[0].hex);
  }

  // Static helper for the garage UI: displayed numbers + 0..1 bars for one catalog car.
  static stats(index) {
    const c = CAR_MODELS[index].cfg, n = (v, a, b) => Math.max(0.06, Math.min(1, (v - a) / (b - a)));
    const v100 = 100 / 3.6;
    return {
      topKmh: Math.round(c.maxSpeed * 3.6),
      t100: -c.maxSpeed / c.accel * Math.log(1 - v100 / c.maxSpeed),
      bars: [
        ['Top speed', n(c.maxSpeed, 38, 58)],
        ['Acceleration', n(c.accel, 18, 38)],
        ['Handling', 0.5 * n(c.steer, 1.7, 3.2) + 0.5 * n(c.grip, 2.4, 4.6)],
        ['Braking', n(c.brake, 46, 64)],
        ['Drift', n(4.8 - c.grip, 0.2, 2.6)],
      ],
    };
  }

  disposeOwn() {
    for (const o of this.own) if (o && o.dispose) o.dispose();
    this.own = [];
  }

  // race-number roundel texture for the doors
  numberTexture(n) {
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const g = cv.getContext('2d');
    g.fillStyle = '#ffffff'; g.beginPath(); g.arc(64, 64, 60, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#15171f'; g.font = 'bold 70px Arial, Helvetica, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(n), 64, 68);
    const t = new THREE.CanvasTexture(cv); this.own.push(t); return t;
  }

  // Switch car model + paint: replaces physics values and rebuilds the body/wheel meshes.
  setModel(index, color) {
    const d = CAR_MODELS[index], s = d.body, mat = this.mat, accent = d.accent;
    this.model = index; this.color = color;
    this.cfg = Object.assign({}, d.cfg);
    this.paint.color.setHex(color); this.paintOff.color.setHex(color);

    for (const o of [this.body, ...this.wheels.map((w) => w.pivot)]) {
      if (!o) continue;
      this.group.remove(o); o.traverse((m) => { if (m.isMesh && m.geometry) m.geometry.dispose(); });
    }
    this.disposeOwn();
    const accentMat = this.accentMat = this.O(this.D(accent)); this.own.push(accentMat);

    const body = this.body = new THREE.Group();
    const add = (geo, m, x, y, z, parent) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = true; (parent || body).add(o); this.own.push(geo); return o; };
    const B = (w, h, l) => new THREE.BoxGeometry(w, h, l);
    const W2 = s.W / 2, L2 = s.L / 2, wr = s.wr;

    // ---------- lower body: tub, hood, fenders, trunk ----------
    const low = sampleRows(s.low, 32);
    const deckAt = (z) => rowAt(low, z, 1), hwAt = (z) => W2 * rowAt(low, z, 2);
    const botAt = (z, dk) => { const dd = L2 - Math.abs(z), lift = dd < 0.5 ? (0.5 - dd) / 0.5 * 0.2 : 0; return Math.min(s.clr + lift, dk - 0.2); };
    const shAt = (z) => { const dk = deckAt(z); return dk - 0.10; };
    const lowRings = low.map(([z, dk, hf]) => {
      const hw = W2 * hf, hb = hw * 0.965, hT = hw * 0.92, yb = botAt(z, dk), ys = dk - 0.10;
      return [[-hb, yb, z], [hb, yb, z], [hw, ys, z], [hT, dk, z], [-hT, dk, z], [-hw, ys, z]];
    });
    const tubGeo = loft(lowRings, [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0]], () => 0, 0);
    const tub = new THREE.Mesh(tubGeo, [this.paint]); tub.castShadow = true; body.add(tub); this.own.push(tubGeo);

    // ---------- greenhouse: glass, pillars, painted roof ----------
    const cabRows = s.cab.map((r) => [r[0], r[1] === null ? deckAt(r[0]) : r[1], r[2]]);
    const cab = sampleRows(cabRows, 26);
    const cabRings = cab.map(([z, top, hf]) => {
      const dk = deckAt(z), t = Math.max(top, dk), wa = hwAt(z) * 0.92 * 0.97, w1 = Math.min(W2 * hf, wa);
      return [[-wa, dk - 0.03, z], [wa, dk - 0.03, z], [w1, t, z], [-w1, t, z]];
    });
    const slope = (i) => Math.abs(cab[i + 1][1] - cab[i][1]) / ((cab[i + 1][0] - cab[i][0]) || 1);
    let flatMin = 1e9, flatMax = -1e9; for (let i = 0; i < cab.length - 1; i++) if (slope(i) < 0.5) { flatMin = Math.min(flatMin, i); flatMax = Math.max(flatMax, i); }
    const midSlice = Math.round((flatMin + flatMax) / 2), midZ = (cab[0][0] + cab[cab.length - 1][0]) / 2;
    const glassGeo = loft(cabRings, [[1, 2], [2, 3], [3, 0]], (i, a, b) => {
      const steep = slope(i) >= 0.5, rear = cab[i][0] < midZ;
      if (a === 2) return steep ? 0 : 1;                       // roof edge: rear / front window = glass, flat part = painted roof
      if (steep && rear) return 1;                             // solid C-pillar / rear quarter
      return i === midSlice ? 1 : 0;                           // B-pillar, the rest of the side is window
    }, null);
    const gh = new THREE.Mesh(glassGeo, [mat.glass, this.paint]); gh.castShadow = true; body.add(gh); this.own.push(glassGeo);

    // ---------- interior silhouettes behind the translucent glass: sloped dashboard, steering wheel, two seats ----------
    {
      const zf = cab[cab.length - 1][0], zr0 = cab[0][0], hx = hwAt(zf) * 0.8;
      const topAt = (z) => rowAt(cab, z, 1), room = (z) => Math.max(0.1, topAt(z) - deckAt(z));
      const I = (g, m, x, y, z) => { const o = add(g, m, x, y, z); o.castShadow = false; return o; };
      const zD = zf - 0.42, dH = Math.min(0.2, room(zD) * 0.4);
      I(B(hx * 1.9, dH, 0.36), mat.interior, 0, deckAt(zD) + dH * 0.5, zD).rotation.x = -0.3;          // dashboard, rising toward the windshield
      I(B(0.42, 0.09, 0.2), mat.interior, hx * 0.5, deckAt(zD) + dH + 0.05, zD - 0.1);                  // instrument hood
      const zw = Math.max(zr0 + 0.3, zf - 0.78), yw = deckAt(zw) + Math.min(0.34, Math.max(0.16, room(zw) - 0.22));
      const wg = new THREE.TorusGeometry(0.15, 0.022, 6, 16); I(wg, mat.black, hx * 0.5, yw, zw).rotation.x = 0.35;   // steering wheel
      const zs = Math.max(zr0 + 0.35, zf - 1.15), sh = Math.max(0.18, Math.min(0.55, room(zs) - 0.12));
      for (const x of [-1, 1]) {                                                                           // front seats
        I(B(0.42, 0.1, 0.5), mat.seat, x * hx * 0.5, deckAt(zs) + 0.05, zs);
        I(B(0.42, sh, 0.1), mat.seat, x * hx * 0.5, deckAt(zs) + 0.05 + sh / 2, zs - 0.22);
        I(B(0.22, 0.12, 0.08), mat.seat, x * hx * 0.5, deckAt(zs) + 0.05 + sh + 0.04, zs - 0.22);
      }
    }

    // ---------- livery stripes (hood, roof, trunk) ----------
    if (s.stripe !== 'none') {
      const offs = s.stripe === 'twin' ? [-0.22 * W2, 0.22 * W2] : [0], sw = s.stripe === 'twin' ? 0.07 : 0.15;
      const cz0 = cab[0][0], cz1 = cab[cab.length - 1][0];
      for (const o of offs) {
        for (const part of [low.filter(([z]) => z >= cz1 - 0.1), low.filter(([z]) => z <= cz0 + 0.1)]) {
          if (part.length < 2) continue;
          const rg = part.map(([z, dk]) => [[o - sw, dk + 0.008, z], [o + sw, dk + 0.008, z]]);
          const gg = loft(rg, [[0, 1]], () => 0, null); const m = new THREE.Mesh(gg, [accentMat]); body.add(m); this.own.push(gg);
        }
        const flat = []; for (let i = flatMin; i <= flatMax + 1; i++) flat.push([[o - sw, cabRings[i][2][1] + 0.008, cab[i][0]], [o + sw, cabRings[i][2][1] + 0.008, cab[i][0]]]);
        if (flat.length > 1) { const gg = loft(flat, [[0, 1]], () => 0, null); const m = new THREE.Mesh(gg, [accentMat]); body.add(m); this.own.push(gg); }
      }
    }

    // ---------- common details ----------
    const zF = L2 - 0.04, zR = -L2 + 0.04, dkF = deckAt(zF), dkR = deckAt(zR), hwF = hwAt(zF), hwR = hwAt(zR);
    const yF = botAt(zF, dkF);
    add(B(hwF * 1.9, 0.26, 0.2), mat.dark, 0, yF + 0.06, L2 - 0.08);                       // front bumper
    add(B(hwR * 1.9, 0.26, 0.2), mat.dark, 0, botAt(zR, dkR) + 0.06, -L2 + 0.08);          // rear bumper
    add(B(hwF * 1.05, 0.13, 0.08), mat.black, 0, dkF - 0.13, L2 - 0.02);                   // grille
    // headlights: dark housing, three recessed circular lenses, clear outer cover
    const hlRound = s.light === 'round', hlW = hlRound ? 0.34 : 0.42, hlH = hlRound ? 0.26 : 0.17;
    const hlX = hwF * 0.7, hlY = Math.min(Math.max(dkF - 0.10, yF + 0.3), dkF + 0.01 - hlH / 2), hlZ = L2 - 0.02;
    const lenses = hlRound ? [[0, 0, 0.085], [-0.115, 0, 0.04], [0.115, 0, 0.04]] : [[-0.13, 0, 0.05], [0, 0, 0.05], [0.13, 0, 0.05]];
    for (const x of [-1, 1]) {
      add(B(hlW, hlH, 0.12), mat.housing, x * hlX, hlY, hlZ);
      for (const [dx, dy, r] of lenses) {
        const g = new THREE.CylinderGeometry(r, r, 0.06, 14); g.rotateX(Math.PI / 2);
        add(g, mat.lamp, x * hlX + dx, hlY + dy, hlZ + 0.01).castShadow = false;
      }
      add(B(hlW + 0.02, hlH + 0.02, 0.02), mat.cover, x * hlX, hlY, hlZ + 0.07).castShadow = false;
    }
    // recessed bumper intakes (dark panels) + front air splitter
    add(B(hwF * 0.9, 0.09, 0.012), mat.blackOff, 0, yF + 0.07, L2 + 0.026).castShadow = false;
    for (const x of [-1, 1]) add(B(0.18, 0.1, 0.012), mat.blackOff, x * hwF * 0.78, yF + 0.07, L2 + 0.026).castShadow = false;
    const bigSplit = (s.extras || []).includes('splitter');
    add(B(hwF * (bigSplit ? 2.1 : 1.8), bigSplit ? 0.05 : 0.035, bigSplit ? 0.42 : 0.26), mat.blackOff, 0, yF - 0.085, L2 + (bigSplit ? 0.05 : 0.0));

    // tail lights: full-width bar, outer housings, inner red lenses, amber indicators
    this.tailMeshes = [];
    const tY = dkR - 0.12, tZ = -L2;
    add(B(hwR * 1.7, 0.1, 0.06), mat.tailHouse, 0, tY, tZ).castShadow = false;
    this.tailMeshes.push(add(B(hwR * 1.3, 0.035, 0.02), mat.tail, 0, tY, tZ - 0.035));
    for (const x of [-1, 1]) {
      add(B(0.46, 0.2, 0.08), mat.tailHouse, x * hwR * 0.72, tY, tZ - 0.005).castShadow = false;
      const t = add(B(0.28, 0.13, 0.02), mat.tail, x * hwR * 0.72, tY, tZ - 0.055); this.tailMeshes.push(t); t.castShadow = false;
      add(B(0.08, 0.13, 0.022), mat.amber, x * (hwR * 0.72 + 0.19), tY, tZ - 0.058).castShadow = false;
    }

    // rear diffuser + dual exhaust: open-ended (hollow) chrome tips with a dark recessed bore
    {
      const bigPipes = (s.extras || []).includes('pipes'), pr = bigPipes ? 0.095 : 0.075, yR = botAt(zR, dkR);
      const px = hwR * ((s.extras || []).includes('spare') ? 0.72 : 0.42);
      add(B(hwR * 1.5, 0.06, 0.36), mat.blackOff, 0, yR - 0.075, -L2);
      for (const x of [-1, 1]) {
        const pg = new THREE.CylinderGeometry(pr, pr, 0.3, 14, 1, true); pg.rotateX(Math.PI / 2); add(pg, mat.chromeD, x * px, yR - 0.02, -L2 - 0.05);
        const ig = new THREE.CylinderGeometry(pr * 0.78, pr * 0.78, 0.28, 12, 1, true); ig.rotateX(Math.PI / 2); add(ig, mat.pipeIn, x * px, yR - 0.02, -L2 - 0.05).castShadow = false;
        const cg0 = new THREE.CircleGeometry(pr * 0.78, 12); cg0.rotateY(Math.PI); add(cg0, mat.pipeIn, x * px, yR - 0.02, -L2 - 0.04).castShadow = false;
      }
    }
    // side skirts between the wheels + a beltline crease along the doors
    {
      const z0 = -s.wz + wr + 0.12, z1 = s.wz - wr - 0.12, zc = (z0 + z1) / 2, len = z1 - z0;
      if (len > 0.4) for (const x of [-1, 1]) {
        const hw = hwAt(zc), yb = botAt(zc, deckAt(zc));
        add(B(0.09, 0.13, len), mat.dark, x * (hw * 0.965 + 0.02), yb + 0.07, zc);
        add(B(0.012, 0.022, len), mat.blackOff, x * (hw * 0.99 + 0.012), deckAt(zc) - 0.2, zc).castShadow = false;
      }
    }
    const plateMat = this.M(0xf3f3f0); this.own.push(plateMat);
    add(B(0.5, 0.14, 0.03), plateMat, 0, botAt(zR, dkR) + 0.38, -L2 - 0.01);                // number plate
    const zm = cab[cab.length - 1][0], zb = cab[0][0];
    const zMirror = Math.max(zm, zb) - 0.22 ;
    for (const x of [-1, 1]) {                                                             // side mirrors
      const dk = deckAt(zMirror);
      add(B(0.18, 0.12, 0.1), this.paint, x * (hwAt(zMirror) * 0.93 + 0.1), dk + 0.2, zMirror);
      add(B(0.06, 0.06, 0.06), mat.dark, x * (hwAt(zMirror) * 0.93 + 0.03), dk + 0.12, zMirror);
    }
    // door lines + handles + number roundels
    const doorFront = Math.min(zm - 0.45, s.wz - wr * 1.2 - 0.05), doorBack = Math.max(cab[0][0] + 0.35, -s.wz + wr * 1.2 + 0.05), texN = this.numberTexture(s.num);
    const decal = this.O(new THREE.MeshLambertMaterial({ map: texN, transparent: true, depthWrite: false })); this.own.push(decal);
    for (const x of [-1, 1]) {
      const zc = (doorFront + doorBack) / 2, hw = hwAt(zc), yb = botAt(zc, deckAt(zc)), top = deckAt(zc) - 0.08;
      for (const z of [doorFront, doorBack]) add(B(0.012, top - yb - 0.1, 0.018), mat.black, x * (hw + 0.004), (top + yb) / 2 + 0.02, z);
      add(B(0.02, 0.04, 0.16), mat.dark, x * (hw + 0.012), top - 0.08, doorBack + 0.18);
      const dg = new THREE.PlaneGeometry(0.58, 0.58); dg.rotateY(x * Math.PI / 2);
      const dm = new THREE.Mesh(dg, decal); dm.position.set(x * (hw + 0.012), (top + yb) / 2 + 0.02, zc + 0.05); body.add(dm); this.own.push(dg);
    }
    // roof number plate
    { const flatZ = cab[Math.round((flatMin + flatMax) / 2)][0], rg = new THREE.PlaneGeometry(0.62, 0.62); rg.rotateX(-Math.PI / 2);
      const rm = new THREE.Mesh(rg, decal); rm.position.set(0, cabRings[Math.round((flatMin + flatMax) / 2)][2][1] + 0.014, flatZ); body.add(rm); this.own.push(rg); }

    // ---------- extras ----------
    const roofY = Math.max(...cabRings.map((r) => r[2][1])), flatZ0 = cab[flatMin][0], flatZ1 = cab[flatMax + 1][0], flatMid = (flatZ0 + flatZ1) / 2;
    for (const ex of s.extras || []) {
      if (ex === 'wingBig') {
        const wz = -L2 + 0.2, wy = deckAt(wz) + 0.52;
        add(B(W2 * 1.9, 0.06, 0.55), mat.dark, 0, wy, wz);
        for (const x of [-1, 1]) { add(B(0.06, 0.34, 0.7), this.paint, x * W2 * 0.95, wy - 0.02, wz); add(B(0.08, 0.5, 0.14), mat.dark, x * W2 * 0.42, wy - 0.27, wz + 0.02); }
      } else if (ex === 'wingSmall') {
        const wz = -L2 + 0.3, wy = deckAt(wz) + 0.2;
        add(B(W2 * 1.7, 0.05, 0.4), mat.dark, 0, wy, wz);
        for (const x of [-1, 1]) add(B(0.07, 0.2, 0.18), mat.dark, x * W2 * 0.4, wy - 0.1, wz);
      } else if (ex === 'duck') {
        const z = cab[0][0] + 0.05, y = cabRings[0][2][1] + 0.0;
        add(B(W2 * 1.5, 0.05, 0.3), mat.dark, 0, deckAt(z) + 0.62, z - 0.1).rotation.x = 0.15;
      } else if (ex === 'bar') {
        const z = flatZ1 - 0.15; add(B(W2 * 1.4, 0.1, 0.16), mat.dark, 0, roofY + 0.1, z);
        for (const x of [-0.6, -0.2, 0.2, 0.6]) add(B(0.2, 0.12, 0.1), mat.lamp, x * W2 * 0.95, roofY + 0.12, z + 0.1);
      } else if (ex === 'pods') {
        for (const x of [-0.55, -0.2, 0.2, 0.55]) { const g = new THREE.CylinderGeometry(0.12, 0.12, 0.1, 12); g.rotateX(Math.PI / 2); add(g, mat.lamp, x * hwF, dkF + 0.02, L2 - 0.5); }
        add(B(hwF * 1.7, 0.06, 0.08), mat.dark, 0, dkF - 0.02, L2 - 0.58);
      } else if (ex === 'scoop') {
        add(B(W2 * 0.34, 0.14, 0.7), mat.black, 0, deckAt(0.9 * L2 * 0.55) + 0.07, 0.9 * L2 * 0.5);
      } else if (ex === 'roofScoop') {
        add(B(W2 * 0.3, 0.16, 0.3), this.paint, 0, roofY + 0.08, flatMid);
      } else if (ex === 'rack') {
        add(B(W2 * 1.5, 0.05, flatZ1 - flatZ0 + 0.2), mat.dark, 0, roofY + 0.12, flatMid);
        for (const x of [-1, 1]) for (const z of [flatZ0, flatZ1]) add(B(0.05, 0.12, 0.05), mat.dark, x * W2 * 0.72, roofY + 0.06, z);
        add(B(W2 * 0.9, 0.3, 0.5), accentMat, 0, roofY + 0.3, flatMid - 0.15);
      } else if (ex === 'spots') {
        for (const x of [-0.5, -0.17, 0.17, 0.5]) { const g = new THREE.CylinderGeometry(0.1, 0.1, 0.1, 10); g.rotateX(Math.PI / 2); add(g, mat.lamp, x * W2 * 1.1, roofY + 0.12, flatZ1 + 0.02); }
      } else if (ex === 'spare') {
        const g = new THREE.CylinderGeometry(0.36, 0.36, 0.24, 14); g.rotateX(Math.PI / 2);
        add(g, mat.rubber, 0.0, Math.min(deckAt(-L2 + 0.1) - 0.15, 1.0) + 0.1, -L2 - 0.14);
        const g2 = new THREE.CylinderGeometry(0.2, 0.2, 0.26, 10); g2.rotateX(Math.PI / 2);
        add(g2, accentMat, 0, Math.min(deckAt(-L2 + 0.1) - 0.15, 1.0) + 0.1, -L2 - 0.14);
      } else if (ex === 'snorkel') {
        add(B(0.09, 0.9, 0.09), mat.dark, W2 * 0.96, deckAt(zm) + 0.4, zm + 0.1);
        add(B(0.16, 0.12, 0.16), mat.dark, W2 * 0.96, roofY * 0.98 + 0.05, zm + 0.1);
      } else if (ex === 'bed') {
        const z0 = cab[0][0] - 0.1, z1 = -L2 + 0.18, zc = (z0 + z1) / 2;
        add(B(W2 * 1.62, 0.03, z0 - z1), mat.black, 0, deckAt(zc) + 0.015, zc);
        add(B(W2 * 1.62, 0.1, 0.06), mat.dark, 0, deckAt(zc) + 0.07, z0);
      } else if (ex === 'rollbar') {
        const z = cab[0][0] - 0.3;
        add(B(W2 * 1.4, 0.07, 0.07), mat.chrome, 0, roofY * 0.95, z);
        for (const x of [-1, 1]) add(B(0.07, roofY * 0.95 - deckAt(z), 0.07), mat.chrome, x * W2 * 0.7, (roofY * 0.95 + deckAt(z)) / 2, z);
      } else if (ex === 'splitter') {
        for (const x of [-1, 1]) add(B(0.04, 0.11, 0.3), mat.black, x * hwF * 1.02, yF - 0.04, L2 + 0.02);      // splitter canards
      } else if (ex === 'pipes') {
        /* bigger dual tips: handled with the default exhaust above */
      } else if (ex === 'mudflaps') {
        for (const x of [-1, 1]) for (const z of [-s.wz - wr - 0.04, s.wz - wr - 0.04]) {
          if (z < -L2 + 0.1) continue;
          add(B(0.03, 0.24, 0.2), mat.black, x * (hwAt(z) + 0.04), wr * 0.45, z);
        }
      } else if (ex === 'bumperChrome') {
        add(B(hwF * 1.95, 0.08, 0.12), mat.chrome, 0, yF + 0.2, L2 - 0.02);
        add(B(hwR * 1.95, 0.08, 0.12), mat.chrome, 0, botAt(zR, dkR) + 0.2, -L2 + 0.02);
      }
    }
    this.group.add(body);

    // ---------- wheels: arch (dark well + flare), pivot (steering, rotation.y) -> tire group (spin, rotation.x) ----------
    this.wheelR = wr; this.wheels = [];
    const tg = new THREE.CylinderGeometry(wr, wr, 0.34, 22, 1, true); tg.rotateZ(Math.PI / 2); this.own.push(tg);                  // tread: open ended, the wheel face is hollow so the brakes show
    const swG = new THREE.RingGeometry(wr * 0.68, wr, 22); swG.rotateY(Math.PI / 2); this.own.push(swG);                           // sidewall
    const rg = new THREE.CylinderGeometry(wr * 0.68, wr * 0.68, 0.3, 18, 1, true); rg.rotateZ(Math.PI / 2); this.own.push(rg);      // rim barrel
    const lipG = new THREE.RingGeometry(wr * 0.6, wr * 0.69, 22); lipG.rotateY(Math.PI / 2); this.own.push(lipG);                   // rim lip
    const hg = new THREE.CylinderGeometry(wr * 0.18, wr * 0.18, 0.4, 8); hg.rotateZ(Math.PI / 2); this.own.push(hg);
    const sg = new THREE.BoxGeometry(0.04, wr * 1.28, 0.07); this.own.push(sg);
    const bg = new THREE.CylinderGeometry(wr * 0.52, wr * 0.52, 0.03, 24); bg.rotateZ(Math.PI / 2); this.own.push(bg);              // brake disc
    const cg = new THREE.BoxGeometry(0.09, wr * 0.34, wr * 0.3); this.own.push(cg);                                                  // caliper
    for (const [sx, z, front] of [[-1, s.wz, true], [1, s.wz, true], [-1, -s.wz, false], [1, -s.wz, false]]) {
      const hw = hwAt(z), pivot = new THREE.Group(); pivot.position.set(sx * (hw - 0.09), wr, z);
      const tire = new THREE.Group();                                                      // spins (rotation.x)
      const tm = new THREE.Mesh(tg, mat.rubberD); tm.castShadow = true; tire.add(tm);
      for (const e of [-1, 1]) { const sw = new THREE.Mesh(swG, mat.rubberD); sw.position.x = e * 0.17; tire.add(sw); }
      tire.add(new THREE.Mesh(rg, mat.rimD));
      const lip = new THREE.Mesh(lipG, mat.rimD); lip.position.x = sx * 0.176; tire.add(lip);
      tire.add(new THREE.Mesh(hg, mat.dark));
      const disc = new THREE.Mesh(bg, mat.disc); disc.position.x = sx * 0.13; tire.add(disc);
      for (let k = 0; k < 3; k++) { const sp = new THREE.Mesh(sg, mat.dark); sp.position.x = sx * 0.19; sp.rotation.x = k * Math.PI / 3; tire.add(sp); }
      // caliper hangs on the pivot (steering spindle), NOT on the spinning tire group: it stays put while the wheel turns
      const cal = new THREE.Mesh(cg, mat.caliper); cal.position.set(sx * 0.13, wr * 0.34, wr * 0.22); pivot.add(cal);
      pivot.add(tire); this.group.add(pivot);
      this.wheels.push({ pivot, tire, front });
      // wheel well (dark disc on the flank) + painted fender flare, both offset against z-fighting; flare top stays under the shoulder line
      const r = Math.max(wr * 1.04, Math.min(wr * 1.16, shAt(z) - wr - 0.02));
      const dg = new THREE.CircleGeometry(r, 20); dg.rotateY(sx * Math.PI / 2); this.own.push(dg);
      const dm = new THREE.Mesh(dg, mat.blackOff); dm.position.set(sx * (hw * 0.99), wr, z); body.add(dm);
      const fg = new THREE.TorusGeometry(r, 0.05, 5, 16, Math.PI); fg.rotateY(sx * Math.PI / 2); this.own.push(fg);
      const fm = new THREE.Mesh(fg, this.paintOff); fm.position.set(sx * (hw + 0.012), wr, z); fm.castShadow = true; body.add(fm);
    }
    // arch clearance: how far the body may tilt (roll / pitch) before a tire top reaches the fender / hood, and how far the front wheels may turn
    let clr = 9, lock = 0.55;
    for (const z of [s.wz, -s.wz]) for (const k of [-0.7, -0.35, 0, 0.35, 0.7]) {
      const dz = k * wr; clr = Math.min(clr, (deckAt(z + dz) - 0.08) - (wr + Math.sqrt(wr * wr - dz * dz)));
    }
    this.archClr = Math.max(0.015, clr); this.halfW = W2; this.halfWB = s.wz;
    while (lock > 0.15 && s.wz + Math.hypot(wr * Math.cos(lock), 0.17 * Math.sin(lock)) > L2 - 0.1) lock -= 0.05;
    this.maxLock = lock;
  }

  place(track, index) {
    const s = track.s(index);
    this.track = track; this.x = s.x; this.z = s.z; this.h = Math.atan2(s.tx, s.tz);
    this.y = track.groundY(this.x, this.z);
    this.vx = this.vz = this.yawRate = 0; this.hint = index; this.steerVis = 0; this.aF = 0; this.pitch = 0;
    this.group.rotation.set(0, 0, 0);
    this.updateMesh(0);
  }

  step(dt, input, track) {
    const c = this.cfg, sh = Math.sin(this.h), ch = Math.cos(this.h);
    const fx = sh, fz = ch, rx = -ch, rz = sh;
    let vF = this.vx * fx + this.vz * fz, vR = this.vx * rx + this.vz * rz;
    const vF0 = vF;

    const q = track.query(this, this.hint);
    this.hint = q.index; this.lat = q.lat; this.onRoad = Math.abs(q.lat) <= track.hw + 0.3;
    const max = c.maxSpeed * (this.onRoad ? 1 : 0.55);

    if (input.throttle > 0) {
      vF += c.accel * input.throttle * Math.max(0, 1 - Math.max(vF, 0) / max) * (this.onRoad ? 1 : 0.7) * dt;
    } else if (input.throttle < 0) {
      if (vF > 1) vF -= c.brake * dt;
      else vF = Math.max(vF - c.accel * 0.5 * dt, -c.reverseMax);
    } else {
      vF -= Math.sign(vF) * Math.min(Math.abs(vF), 3 * dt);
    }
    this.braking = (input.throttle < 0 && vF0 > 1) || (!!input.handbrake && Math.abs(vF0) > 2);
    if (vF > max) vF -= (vF - max) * Math.min(1, 2 * dt);
    vF *= Math.exp(-(this.onRoad ? 0.03 : 0.9) * dt);
    if (input.handbrake) vF *= Math.exp(-0.3 * dt);
    // hills: gravity along the slope (downhill speeds you up, uphill slows you)
    const hF = track.groundY(this.x + fx * 2, this.z + fz * 2), hB = track.groundY(this.x - fx * 2, this.z - fz * 2);
    this.slope = (hF - hB) / 4; vF -= this.slope * 14 * dt;

    // tire grip: steering at speed strongly reduces it -> the rear slides out
    const speedF = Math.min(1, Math.abs(vF) / 22);
    let grip = c.grip * (1 - 0.72 * Math.abs(input.steer) * speedF);
    if (input.handbrake) grip = c.driftGrip;
    if (!this.onRoad) grip *= 0.7;
    vR *= Math.exp(-grip * dt);

    // rebuild world velocity with the OLD heading so the car keeps sliding
    this.vx = fx * vF + rx * vR; this.vz = fz * vF + rz * vR;

    const sp = Math.min(1, Math.abs(vF) / 6), dir = vF >= 0 ? 1 : -1;
    let rate = c.steer * (1 - 0.25 * Math.min(1, Math.abs(vF) / max));
    if (input.handbrake) rate *= 1.5;
    const target = -input.steer * rate * sp * dir;
    this.yawRate += (target - this.yawRate) * Math.min(1, 7 * dt);
    this.h += this.yawRate * dt;

    this.x += this.vx * dt; this.z += this.vz * dt;
    this.y += (track.groundY(this.x, this.z) - this.y) * Math.min(1, 30 * dt);
    this.vF = vF; this.vR = vR; this.speed = Math.hypot(this.vx, this.vz);
    this.aF += ((vF - vF0) / dt - this.aF) * Math.min(1, 8 * dt);
    this.steerVis += (input.steer * 0.5 - this.steerVis) * Math.min(1, 12 * dt);
  }

  // no barriers: only trees, rocks and hay bales block the car
  collide(track) {
    let hit = 0;
    const sh = Math.sin(this.h), ch = Math.cos(this.h);
    for (const arr of track.obstacleLists(this.hint)) for (const o of arr) {
      for (const off of [1.3, -1.3]) {
        const dx = this.x + sh * off - o[0], dz = this.z + ch * off - o[1], r = o[2] + 1.0, d2 = dx * dx + dz * dz;
        if (d2 < r * r && d2 > 1e-6) {
          const d = Math.sqrt(d2), nx = dx / d, nz = dz / d;
          this.x += nx * (r - d); this.z += nz * (r - d);
          const vo = this.vx * nx + this.vz * nz;
          if (vo < 0) {
            this.vx -= nx * vo * 1.35; this.vz -= nz * vo * 1.35;
            this.vx *= 0.82; this.vz *= 0.82;
            this.yawRate += (Math.random() - 0.5) * 1.5 * Math.min(1, -vo / 10);
            hit = Math.max(hit, -vo);
          }
        }
      }
    }
    return hit;
  }

  updateMesh(dt) {
    this.group.position.set(this.x, this.y, this.z);
    this.group.rotation.y = this.h;
    const tr = this.track;
    if (tr) {                                   // tilt the car to the slope
      const sh = Math.sin(this.h), ch = Math.cos(this.h);
      const hF = tr.groundY(this.x + sh * 2, this.z + ch * 2), hB = tr.groundY(this.x - sh * 2, this.z - ch * 2);
      const hL = tr.groundY(this.x + ch * 1.2, this.z - sh * 1.2), hR = tr.groundY(this.x - ch * 1.2, this.z + sh * 1.2);
      const k = dt > 0 ? Math.min(1, 10 * dt) : 1;
      this.group.rotation.x += (-Math.atan2(hF - hB, 4) - this.group.rotation.x) * k;
      this.group.rotation.z += (Math.atan2(hL - hR, 2.4) - this.group.rotation.z) * k;
    }
    const k2 = dt > 0 ? Math.min(1, 10 * dt) : 1;
    let roll = Math.max(-0.12, Math.min(0.12, this.vR * 0.012));
    // weight transfer: nose dips under braking, squats under acceleration
    let pitch = Math.max(-0.05, Math.min(0.05, -this.aF * 0.0035));
    const drop = Math.abs(roll) * this.halfW + Math.abs(pitch) * this.halfWB;        // how far the body sinks onto the tires at the worst corner
    if (drop > this.archClr) { const f = this.archClr / drop; roll *= f; pitch *= f; }  // never deeper than the arch clearance -> tires cannot poke through panels
    this.body.rotation.z += (roll - this.body.rotation.z) * k2;
    this.body.rotation.x += (pitch - this.body.rotation.x) * k2;
    this.mat.tail.color.setHex(this.braking ? 0xff3b3b : 0x9c1020);          // brake lights
    for (const w of this.wheels) {
      if (w.front) w.pivot.rotation.y = -Math.max(-this.maxLock, Math.min(this.maxLock, this.steerVis * 1.1));
      w.tire.rotation.x += this.vF * dt / this.wheelR;
    }
  }
}

/* Dust: pooled low-poly puffs. Solid, flat-shaded beige chunks (no transparency) that pop in small, swell, tumble and shrink away,
   so a slide leaves a trail of chunky rock-like clouds behind the rear wheels. */
class Dust {
  constructor(scene) {
    this.p = []; this.i = 0;
    const g = new THREE.IcosahedronGeometry(0.5, 0);
    for (let k = 0; k < 110; k++) {
      const m = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ color: 0xd9c3a0, flatShading: true }));
      m.visible = false; scene.add(m);
      this.p.push({ m, life: 0, max: 1, vx: 0, vy: 0, vz: 0, size: 1, spin: 0 });
    }
  }
  emit(x, y, z, vx, vz, color) {
    const p = this.p[this.i++ % this.p.length];
    p.m.position.set(x + (Math.random() - 0.5) * 0.5, y, z + (Math.random() - 0.5) * 0.5);
    p.vx = vx * 0.12 + (Math.random() - 0.5) * 1.6; p.vz = vz * 0.12 + (Math.random() - 0.5) * 1.6;
    p.vy = 0.5 + Math.random() * 1.0; p.life = p.max = 0.7 + Math.random() * 0.5;
    p.size = 0.9 + Math.random() * 0.9; p.spin = (Math.random() - 0.5) * 3;
    p.m.material.color.setHex(color).multiplyScalar(0.88 + Math.random() * 0.2);      // slight colour variety between chunks
    p.m.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
    p.m.visible = true; p.m.scale.setScalar(0.01);
  }
  update(dt) {
    for (const p of this.p) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.m.visible = false; continue; }
      const t = 1 - p.life / p.max, drag = Math.exp(-2.2 * dt);
      p.vx *= drag; p.vz *= drag; p.vy *= Math.exp(-1.5 * dt);
      p.m.position.x += p.vx * dt; p.m.position.y += p.vy * dt; p.m.position.z += p.vz * dt;
      p.m.rotation.y += p.spin * dt; p.m.rotation.x += p.spin * 0.6 * dt;
      const grow = Math.min(1, t / 0.25), shrink = t > 0.55 ? 1 - (t - 0.55) / 0.45 : 1;      // swell fast, hold, then shrink to nothing
      p.m.scale.setScalar(Math.max(0.01, p.size * grow * (0.4 + 0.6 * shrink)) * shrink);
    }
  }
}
