/* CrazyGames SDK v3 wrapper. Safe everywhere: if the SDK is missing / blocked (local testing, other sites) every call is a no-op
   and the game simply continues.  Exposes:
     CG.ready               Promise that always resolves (SDK initialised, or gave up after 4 s)
     CG.gameplay(true|false)  gameplayStart / gameplayStop (idempotent)
     CG.loadingStop()       call once the main menu is visible
     CG.ad(cb)              show a midgame ad (muted + paused by the game), then call cb()
     CG.happy()             happytime() for a new personal best
     RallyStore.get / set   save data through the SDK (cloud / cross-domain) with localStorage as fallback */
(() => {
  const sdk = () => (window.CrazyGames && window.CrazyGames.SDK) || null;
  const api = window.CG = { on: false, playing: false, adBusy: false };
  let stopped = false;

  api.ready = new Promise((resolve) => {
    const t = setTimeout(resolve, 4000);                       // never block the game on a slow / missing SDK
    (async () => {
      const s = sdk();
      if (s) {
        try { await s.init(); api.on = (s.environment || 'crazygames') !== 'disabled'; if (api.on) s.game.loadingStart(); } catch (e) { api.on = false; }
      }
      clearTimeout(t); resolve();
    })();
  });

  api.loadingStop = () => { if (stopped) return; stopped = true; try { if (api.on) sdk().game.loadingStop(); } catch (e) { /* ignore */ } };
  api.gameplay = (on) => {
    on = !!on; if (api.playing === on) return; api.playing = on;
    try { if (api.on) on ? sdk().game.gameplayStart() : sdk().game.gameplayStop(); } catch (e) { /* ignore */ }
  };
  api.happy = () => { try { if (api.on) sdk().game.happytime(); } catch (e) { /* ignore */ } };
  api.ad = (cb) => {
    let done = false; const fin = () => { if (done) return; done = true; api.adBusy = false; if (typeof Sound !== 'undefined' && Sound.adMute) Sound.adMute(false); cb(); };
    if (!api.on || api.adBusy) { cb(); return; }
    api.adBusy = true; api.gameplay(false);
    try {
      sdk().ad.requestAd('midgame', {
        adStarted: () => { if (typeof Sound !== 'undefined' && Sound.adMute) Sound.adMute(true); },
        adFinished: fin, adError: fin,
      });
    } catch (e) { fin(); }
  };

  window.RallyStore = {
    get(k) {
      try { if (api.on) { const v = sdk().data.getItem(k); if (v !== null && v !== undefined) return v; } } catch (e) { /* ignore */ }
      try { return localStorage.getItem(k); } catch (e) { return null; }
    },
    set(k, v) {
      try { if (api.on) sdk().data.setItem(k, v); } catch (e) { /* ignore */ }
      try { localStorage.setItem(k, v); } catch (e) { /* ignore */ }
    },
  };
})();
