/* Phone helpers: fullscreen + landscape lock when you tap Play, keep the screen awake while driving,
   "Add to Home Screen" hint on iPhone, and offline caching. Does nothing on desktop. */
(() => {
  const coarse = matchMedia('(pointer: coarse)').matches || matchMedia('(hover: none)').matches;
  const standalone = matchMedia('(display-mode: fullscreen), (display-mode: standalone)').matches || navigator.standalone === true;
  const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
  }
  if (!coarse) return;

  // ---- fullscreen + landscape lock (Android Chrome etc.; iPhone Safari has no fullscreen API, so it relies on Add to Home Screen) ----
  const root = document.documentElement;
  const fsEnabled = () => !!(root.requestFullscreen || root.webkitRequestFullscreen);
  async function goFull() {
    try {
      if (!document.fullscreenElement && !document.webkitFullscreenElement && fsEnabled()) {
        await (root.requestFullscreen ? root.requestFullscreen({ navigationUI: 'hide' }) : root.webkitRequestFullscreen());
      }
    } catch (e) { /* user or browser said no: fine */ }
    try { if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape'); } catch (e) { /* not supported / not allowed */ }
  }
  // any real tap on a start / resume button counts as the user gesture
  document.addEventListener('click', (e) => {
    if (e.target.closest && e.target.closest('#btnPlay, #btnResume, #btnAgain, #btnNew')) goFull();
  }, true);

  // ---- keep the screen on while racing ----
  let lock = null;
  async function wake() {
    if (!('wakeLock' in navigator) || lock || document.hidden) return;
    try { lock = await navigator.wakeLock.request('screen'); lock.addEventListener('release', () => { lock = null; }); } catch (e) { lock = null; }
  }
  const sync = () => { if (document.body.classList.contains('playing')) wake(); else if (lock) { lock.release().catch(() => {}); lock = null; } };
  new MutationObserver(sync).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });

  // ---- iPhone: one-time "Add to Home Screen" tip (Safari tabs can't hide the toolbar) ----
  if (isIOS && !standalone) {
    let seen = false; try { seen = localStorage.getItem('rd_a2hs') === '1'; } catch (e) { /* ignore */ }
    if (!seen) {
      const tip = document.createElement('div'); tip.id = 'a2hs';
      tip.innerHTML = '<b>Play fullscreen</b> Tap <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 3v12M8 7l4-4 4 4M5 11v9h14v-9"/></svg> then &ldquo;Add to Home Screen&rdquo;<button type="button" aria-label="Dismiss">&times;</button>';
      tip.querySelector('button').addEventListener('click', () => { tip.remove(); try { localStorage.setItem('rd_a2hs', '1'); } catch (e) { /* ignore */ } });
      addEventListener('load', () => setTimeout(() => document.body.appendChild(tip), 3000));
      setTimeout(() => { if (tip.parentNode) tip.remove(); }, 18000);
    }
  }
})();
