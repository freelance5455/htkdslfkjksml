import React, { useState, useEffect, useMemo } from 'react';
import {
  ShoppingCart,
  Package,
  BookOpen,
  Search,
  Plus,
  Minus,
  Trash2,
  Printer,
  CheckCircle,
  AlertTriangle,
  QrCode,
  TrendingUp,
  Share2,
  Phone,
  Store,
  X,
  CreditCard,
  Clock,
  Sparkles,
  BarChart3,
  IndianRupee,
  Receipt,
  ScanBarcode,
  ArrowRight,
  Send,
  ChevronRight,
  Filter,
  Flame,
  Check,
  Settings,
  Edit3
} from 'lucide-react';

// --- INITIAL SEED DATA ---
const DEFAULT_PRODUCTS = [
  {
    id: 'prod-1',
    name: 'Aashirvaad Shudh Chakki Atta 5kg',
    category: 'Atta & Dal',
    unit: 'bag',
    costPrice: 220,
    price: 255,
    stock: 14,
    reorderLevel: 5,
    barcode: '890103001'
  },
  {
    id: 'prod-2',
    name: 'Tata Salt Vaccum 1kg',
    category: 'Daily Needs',
    unit: 'pkt',
    costPrice: 22,
    price: 28,
    stock: 35,
    reorderLevel: 10,
    barcode: '890103002'
  },
  {
    id: 'prod-3',
    name: 'Fortune Sunflower Oil 1L',
    category: 'Oil & Ghee',
    unit: 'pouch',
    costPrice: 118,
    price: 135,
    stock: 4,
    reorderLevel: 6,
    barcode: '890103003'
  },
  {
    id: 'prod-4',
    name: 'Amul Butter 100g',
    category: 'Dairy',
    unit: 'pc',
    costPrice: 50,
    price: 58,
    stock: 18,
    reorderLevel: 5,
    barcode: '890103004'
  },
  {
    id: 'prod-5',
    name: 'Maggi 2-Min Masala Noodles',
    category: 'Snacks',
    unit: 'pack',
    costPrice: 11.5,
    price: 14,
    stock: 65,
    reorderLevel: 15,
    barcode: '890103005'
  },
  {
    id: 'prod-6',
    name: 'Toor Dal Desi 1kg',
    category: 'Atta & Dal',
    unit: 'kg',
    costPrice: 130,
    price: 160,
    stock: 3,
    reorderLevel: 8,
    barcode: '890103006'
  },
  {
    id: 'prod-7',
    name: 'Good Day Butter Biscuit 120g',
    category: 'Snacks',
    unit: 'pack',
    costPrice: 24,
    price: 30,
    stock: 26,
    reorderLevel: 8,
    barcode: '890103007'
  },
  {
    id: 'prod-8',
    name: 'Dettol Soap 75g (3+1)',
    category: 'Daily Needs',
    unit: 'pack',
    costPrice: 110,
    price: 138,
    stock: 12,
    reorderLevel: 4,
    barcode: '890103008'
  },
  {
    id: 'prod-9',
    name: 'Catch Super Garam Masala 100g',
    category: 'Daily Needs',
    unit: 'box',
    costPrice: 68,
    price: 85,
    stock: 9,
    reorderLevel: 3,
    barcode: '890103009'
  },
  {
    id: 'prod-10',
    name: 'Tata Tea Gold 500g',
    category: 'Daily Needs',
    unit: 'pack',
    costPrice: 280,
    price: 330,
    stock: 2,
    reorderLevel: 5,
    barcode: '890103010'
  }
];

const CATEGORIES = ['All', 'Atta & Dal', 'Oil & Ghee', 'Dairy', 'Snacks', 'Daily Needs'];

export default function App() {
  // Navigation State: 'billing' | 'aaj-bikri' | 'stock' | 'khata'
  const [activeTab, setActiveTab] = useState('billing');

  // Store Profile Info State
  const [storeInfo, setStoreInfo] = useState(() => {
    const saved = localStorage.getItem('kirana_m_store_info');
    return saved
      ? JSON.parse(saved)
      : {
          name: 'Krishna Agency',
          tagline: 'Wholesale & Retail Groceries',
          phone: '9876543210',
          address: 'Main Market Road',
          gstin: '07AAAAA0000A1Z5',
          upiId: 'krishnaagency@upi'
        };
  });
  const [isStoreSettingsOpen, setIsStoreSettingsOpen] = useState(false);
  const [editStoreForm, setEditStoreForm] = useState(storeInfo);

  // Persistent States
  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('kirana_m_products');
    return saved ? JSON.parse(saved) : DEFAULT_PRODUCTS;
  });

  const [sales, setSales] = useState(() => {
    const saved = localStorage.getItem('kirana_m_sales');
    if (saved) return JSON.parse(saved);
    const now = Date.now();
    return [
      {
        id: 'INV-101',
        timestamp: new Date(now - 1000 * 60 * 35).toISOString(),
        customerName: 'Ramesh Sharma',
        customerPhone: '9876543210',
        paymentMode: 'UPI',
        items: [
          { id: 'prod-1', name: 'Aashirvaad Shudh Chakki Atta 5kg', price: 255, qty: 1, unit: 'bag' },
          { id: 'prod-2', name: 'Tata Salt Vaccum 1kg', price: 28, qty: 2, unit: 'pkt' }
        ],
        subtotal: 311,
        discount: 0,
        total: 311
      },
      {
        id: 'INV-102',
        timestamp: new Date(now - 1000 * 60 * 110).toISOString(),
        customerName: 'Pooja Verma',
        customerPhone: '9811223344',
        paymentMode: 'Cash',
        items: [
          { id: 'prod-4', name: 'Amul Butter 100g', price: 58, qty: 2, unit: 'pc' },
          { id: 'prod-5', name: 'Maggi 2-Min Masala Noodles', price: 14, qty: 4, unit: 'pack' }
        ],
        subtotal: 172,
        discount: 0,
        total: 172
      },
      {
        id: 'INV-103',
        timestamp: new Date(now - 1000 * 60 * 220).toISOString(),
        customerName: 'Sunita Di',
        customerPhone: '9899123456',
        paymentMode: 'Khata',
        items: [
          { id: 'prod-3', name: 'Fortune Sunflower Oil 1L', price: 135, qty: 1, unit: 'pouch' },
          { id: 'prod-7', name: 'Good Day Butter Biscuit 120g', price: 30, qty: 2, unit: 'pack' }
        ],
        subtotal: 195,
        discount: 5,
        total: 190
      }
    ];
  });

  const [khataCustomers, setKhataCustomers] = useState(() => {
    const saved = localStorage.getItem('kirana_m_khata');
    return saved ? JSON.parse(saved) : [
      {
        id: 'k-1',
        name: 'Sunita Di (Flat 402)',
        phone: '9899123456',
        balance: 640,
        lastUpdated: new Date().toISOString()
      },
      {
        id: 'k-2',
        name: 'Gupta Ji Teacher',
        phone: '9811223344',
        balance: 1120,
        lastUpdated: new Date(Date.now() - 86400000).toISOString()
      },
      {
        id: 'k-3',
        name: 'Deepak Electrician',
        phone: '9711554422',
        balance: 380,
        lastUpdated: new Date(Date.now() - 172800000).toISOString()
      }
    ];
  });

  // Local Storage Save
  useEffect(() => {
    localStorage.setItem('kirana_m_products', JSON.stringify(products));
  }, [products]);
  useEffect(() => {
    localStorage.setItem('kirana_m_sales', JSON.stringify(sales));
  }, [sales]);
  useEffect(() => {
    localStorage.setItem('kirana_m_khata', JSON.stringify(khataCustomers));
  }, [khataCustomers]);
  useEffect(() => {
    localStorage.setItem('kirana_m_store_info', JSON.stringify(storeInfo));
  }, [storeInfo]);

  // Cart & POS states
  const [cart, setCart] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');
  const [isCheckoutDrawerOpen, setIsCheckoutDrawerOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMode, setPaymentMode] = useState('Cash'); // 'Cash' | 'UPI' | 'Khata'
  const [discount, setDiscount] = useState(0);

  // Modals & Sheets
  const [receiptModalBill, setReceiptModalBill] = useState(null);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [isNewItemDrawerOpen, setIsNewItemDrawerOpen] = useState(false);
  const [khataSettleTarget, setKhataSettleTarget] = useState(null);
  const [settleAmount, setSettleAmount] = useState('');
  const [toast, setToast] = useState(null);

  // New Item Form
  const [newItemForm, setNewItemForm] = useState({
    name: '',
    category: 'Atta & Dal',
    unit: 'pkt',
    price: '',
    stock: '15',
    reorderLevel: '5'
  });

  const triggerToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  // Cart Calculations
  const cartItemCount = useMemo(() => cart.reduce((acc, it) => acc + it.qty, 0), [cart]);
  const cartSubtotal = useMemo(() => cart.reduce((acc, it) => acc + it.price * it.qty, 0), [cart]);
  const cartTotal = useMemo(() => Math.max(0, cartSubtotal - Number(discount || 0)), [cartSubtotal, discount]);

  // Cart Handlers
  const handleAddToCart = (product) => {
    if (product.stock <= 0) {
      triggerToast('Stock khatam hai!');
      return;
    }
    setCart((prev) => {
      const exists = prev.find((i) => i.id === product.id);
      if (exists) {
        if (exists.qty + 1 > product.stock) {
          triggerToast(`Sirf ${product.stock} pieces bache hain!`);
          return prev;
        }
        return prev.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const handleUpdateQty = (productId, delta) => {
    const prod = products.find((p) => p.id === productId);
    setCart((prev) =>
      prev
        .map((it) => {
          if (it.id === productId) {
            const next = it.qty + delta;
            if (next <= 0) return null;
            if (prod && next > prod.stock) {
              triggerToast(`Stock limit: ${prod.stock}`);
              return it;
            }
            return { ...it, qty: next };
          }
          return it;
        })
        .filter(Boolean)
    );
  };

  // Complete Sale
  const handleCompleteSale = () => {
    if (cart.length === 0) return;
    if (paymentMode === 'Khata' && !customerName.trim()) {
      triggerToast('Khata ke liye Grahak ka naam likhein!');
      return;
    }

    // Deduct Stock
    setProducts((prev) =>
      prev.map((p) => {
        const inCart = cart.find((c) => c.id === p.id);
        if (inCart) {
          return { ...p, stock: Math.max(0, p.stock - inCart.qty) };
        }
        return p;
      })
    );

    const invoice = {
      id: `INV-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      storeName: storeInfo.name,
      customerName: customerName.trim() || 'Cash Customer',
      customerPhone: customerPhone.trim() || '—',
      paymentMode: paymentMode,
      items: [...cart],
      subtotal: cartSubtotal,
      discount: Number(discount || 0),
      total: cartTotal
    };

    setSales((prev) => [invoice, ...prev]);

    // Handle Khata Book addition
    if (paymentMode === 'Khata') {
      const cleanName = customerName.trim();
      const existing = khataCustomers.find(
        (k) => k.name.toLowerCase() === cleanName.toLowerCase() || (customerPhone && k.phone === customerPhone)
      );
      if (existing) {
        setKhataCustomers((prev) =>
          prev.map((k) =>
            k.id === existing.id
              ? { ...k, balance: k.balance + cartTotal, lastUpdated: new Date().toISOString() }
              : k
          )
        );
      } else {
        setKhataCustomers((prev) => [
          ...prev,
          {
            id: `k-${Date.now()}`,
            name: cleanName,
            phone: customerPhone || 'No Phone',
            balance: cartTotal,
            lastUpdated: new Date().toISOString()
          }
        ]);
      }
    }

    setReceiptModalBill(invoice);
    setCart([]);
    setDiscount(0);
    setCustomerName('');
    setCustomerPhone('');
    setIsCheckoutDrawerOpen(false);
    triggerToast(`₹${cartTotal} Bill Saved!`);
  };

  // Quick Restock
  const handleRestock = (productId, amount) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: p.stock + amount } : p))
    );
    triggerToast(`+${amount} Stock added!`);
  };

  // Settle Khata
  const handleSettleKhataSubmit = (e) => {
    e.preventDefault();
    const amt = Number(settleAmount);
    if (!amt || amt <= 0) return;

    setKhataCustomers((prev) =>
      prev.map((k) =>
        k.id === khataSettleTarget.id
          ? { ...k, balance: Math.max(0, k.balance - amt), lastUpdated: new Date().toISOString() }
          : k
      )
    );

    // Record as cash entry
    const entry = {
      id: `KHATA-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      customerName: khataSettleTarget.name,
      customerPhone: khataSettleTarget.phone,
      paymentMode: 'Cash',
      items: [{ id: 'k-pay', name: 'Khata Wapas (जमा)', price: amt, qty: 1, unit: 'rupees' }],
      subtotal: amt,
      discount: 0,
      total: amt
    };
    setSales((prev) => [entry, ...prev]);

    triggerToast(`₹${amt} Jama kiya gaya!`);
    setKhataSettleTarget(null);
    setSettleAmount('');
  };

  // Save new product
  const handleSaveNewProduct = (e) => {
    e.preventDefault();
    if (!newItemForm.name || !newItemForm.price) return;
    const newItem = {
      id: `prod-${Date.now()}`,
      name: newItemForm.name,
      category: newItemForm.category,
      unit: newItemForm.unit,
      costPrice: Math.round(Number(newItemForm.price) * 0.85),
      price: Number(newItemForm.price),
      stock: Number(newItemForm.stock || 10),
      reorderLevel: Number(newItemForm.reorderLevel || 5),
      barcode: `890${Math.floor(100000 + Math.random() * 900000)}`
    };
    setProducts((prev) => [newItem, ...prev]);
    setIsNewItemDrawerOpen(false);
    setNewItemForm({ name: '', category: 'Atta & Dal', unit: 'pkt', price: '', stock: '15', reorderLevel: '5' });
    triggerToast('Naya Saman Add Ho Gaya!');
  };

  // Today Sales Analytics
  const todayStr = new Date().toDateString();
  const todaySales = useMemo(() => {
    return sales.filter((s) => new Date(s.timestamp).toDateString() === todayStr);
  }, [sales, todayStr]);

  const todayTotal = useMemo(() => todaySales.reduce((a, b) => a + b.total, 0), [todaySales]);
  const todayCash = useMemo(
    () => todaySales.filter((s) => s.paymentMode === 'Cash').reduce((a, b) => a + b.total, 0),
    [todaySales]
  );
  const todayUpi = useMemo(
    () => todaySales.filter((s) => s.paymentMode === 'UPI').reduce((a, b) => a + b.total, 0),
    [todaySales]
  );
  const todayKhata = useMemo(
    () => todaySales.filter((s) => s.paymentMode === 'Khata').reduce((a, b) => a + b.total, 0),
    [todaySales]
  );

  const topSellingToday = useMemo(() => {
    const counter = {};
    todaySales.forEach((s) => {
      s.items.forEach((it) => {
        counter[it.name] = (counter[it.name] || 0) + it.qty;
      });
    });
    return Object.entries(counter)
      .map(([name, qty]) => ({ name, qty }))
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 4);
  }, [todaySales]);

  // Low stock counter
  const lowStockCount = useMemo(() => products.filter((p) => p.stock <= p.reorderLevel).length, [products]);
  const totalUdharDue = useMemo(() => khataCustomers.reduce((a, b) => a + b.balance, 0), [khataCustomers]);

  // Filtered Products for POS
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCat === 'All' || p.category === selectedCat;
      return matchSearch && matchCat;
    });
  }, [products, searchQuery, selectedCat]);

  return (
    <div className="bg-slate-900 min-h-screen flex justify-center items-start sm:p-4 select-none">
      {/* Toast */}
      {toast && (
        <div className="fixed top-5 z-50 bg-slate-900/95 text-white border border-emerald-500/40 px-4 py-2 rounded-full text-xs font-semibold shadow-2xl flex items-center gap-2 animate-bounce backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>{toast}</span>
        </div>
      )}

      {/* MOBILE DEVICE CONTAINER */}
      <div className="w-full max-w-md bg-slate-50 min-h-screen sm:min-h-[844px] sm:max-h-[880px] sm:rounded-[36px] shadow-2xl flex flex-col overflow-hidden relative border-0 sm:border-8 sm:border-slate-800">
        
        {/* APP TOP STATUS BAR & HEADER */}
        <header className="bg-emerald-800 text-white pt-2.5 pb-3 px-4 shadow-md shrink-0">
          <div className="flex items-center justify-between">
            <div 
              onClick={() => {
                setEditStoreForm(storeInfo);
                setIsStoreSettingsOpen(true);
              }}
              className="flex items-center space-x-2 cursor-pointer active:opacity-80 transition"
              title="Click to edit shop details"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-700 border border-emerald-600 flex items-center justify-center relative">
                <Store className="w-4 h-4 text-amber-300" />
                <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-amber-400 rounded-full flex items-center justify-center">
                  <Edit3 className="w-2 h-2 text-slate-900" />
                </span>
              </div>
              <div>
                <h1 className="text-sm font-black tracking-tight leading-tight flex items-center gap-1.5">
                  {storeInfo.name}
                </h1>
                <p className="text-[10px] text-emerald-200 font-medium">{storeInfo.tagline}</p>
              </div>
            </div>

            {/* Quick Aaj Ka Galla Badge */}
            <div 
              onClick={() => setActiveTab('aaj-bikri')}
              className="bg-emerald-950/80 border border-emerald-600/70 px-2.5 py-1 rounded-xl text-right cursor-pointer active:scale-95 transition"
            >
              <div className="text-[9px] text-amber-300 font-bold uppercase tracking-wider leading-none">आज का गल्ला</div>
              <div className="text-xs font-black text-white mt-0.5">₹{todayTotal.toLocaleString()}</div>
            </div>
          </div>
        </header>

        {/* ============================================================== */}
        {/* SCREEN 1: POS BILLING COUNTER (Phone Optimized) */}
        {/* ============================================================== */}
        {activeTab === 'billing' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Search and Category Pills Bar */}
            <div className="p-3 bg-white border-b border-slate-200 shrink-0 space-y-2">
              <div className="relative flex items-center">
                <Search className="w-4 h-4 absolute left-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Saman khojein (Atta, Maggi, Tel)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-9 py-2 bg-slate-100 rounded-xl text-xs font-medium placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                {searchQuery ? (
                  <button onClick={() => setSearchQuery('')} className="absolute right-3 text-slate-400">
                    <X className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <div className="absolute right-3 text-slate-400" title="Barcode Ready">
                    <ScanBarcode className="w-4 h-4 text-emerald-700" />
                  </div>
                )}
              </div>

              {/* Category Pills (Horizontal Scroll) */}
              <div className="flex space-x-1.5 overflow-x-auto no-scrollbar py-0.5">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCat(cat)}
                    className={`px-3 py-1 rounded-full text-[11px] font-bold whitespace-nowrap transition ${
                      selectedCat === cat
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 active:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Products List (Compact Touch Items) */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2 pb-24">
              {filteredProducts.map((p) => {
                const cartEntry = cart.find((i) => i.id === p.id);
                const isOutOfStock = p.stock <= 0;
                const isLow = p.stock <= p.reorderLevel;

                return (
                  <div
                    key={p.id}
                    className={`bg-white p-3 rounded-2xl border transition flex items-center justify-between shadow-xs ${
                      isOutOfStock ? 'opacity-50 border-slate-200 bg-slate-50' : 'border-slate-200 active:border-emerald-500'
                    }`}
                  >
                    <div className="flex-1 pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                          {p.category}
                        </span>
                        {isLow && !isOutOfStock && (
                          <span className="text-[9px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            <AlertTriangle className="w-2.5 h-2.5" /> Low ({p.stock})
                          </span>
                        )}
                        {isOutOfStock && (
                          <span className="text-[9px] font-bold text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded">
                            Khatam
                          </span>
                        )}
                      </div>
                      <h3 className="text-xs font-bold text-slate-900 mt-1 line-clamp-1">{p.name}</h3>
                      <div className="text-xs font-extrabold text-emerald-800 mt-0.5">
                        ₹{p.price} <span className="text-[10px] font-normal text-slate-400">/{p.unit}</span>
                      </div>
                    </div>

                    {/* Stepper / Add button */}
                    <div>
                      {cartEntry ? (
                        <div className="flex items-center bg-emerald-50 border border-emerald-600 rounded-xl overflow-hidden p-0.5">
                          <button
                            onClick={() => handleUpdateQty(p.id, -1)}
                            className="w-7 h-7 flex items-center justify-center bg-white text-emerald-900 rounded-lg shadow-xs active:scale-95"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-7 text-center text-xs font-black text-emerald-950">
                            {cartEntry.qty}
                          </span>
                          <button
                            onClick={() => handleUpdateQty(p.id, 1)}
                            className="w-7 h-7 flex items-center justify-center bg-emerald-700 text-white rounded-lg shadow-xs active:scale-95"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          disabled={isOutOfStock}
                          onClick={() => handleAddToCart(p)}
                          className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1 transition ${
                            isOutOfStock
                              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              : 'bg-emerald-700 text-white active:bg-emerald-800 shadow-sm'
                          }`}
                        >
                          <Plus className="w-3.5 h-3.5" /> ADD
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Floating Bill Summary Bar */}
            {cart.length > 0 && (
              <div className="absolute bottom-16 left-3 right-3 bg-slate-950 text-white p-3 rounded-2xl shadow-2xl flex items-center justify-between border border-slate-800 animate-slide-up z-20">
                <div>
                  <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                    {cartItemCount} Items added
                  </div>
                  <div className="text-base font-black text-white">₹{cartSubtotal}</div>
                </div>

                <button
                  onClick={() => setIsCheckoutDrawerOpen(true)}
                  className="bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-lg active:scale-95 transition"
                >
                  Create Bill <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ============================================================== */}
        {/* SCREEN 2: AAJ KI BIKRI (Today's Sales Dashboard) */}
        {/* ============================================================== */}
        {activeTab === 'aaj-bikri' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
            {/* Header Badge */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-black text-slate-900 flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-amber-500" /> आज की कुल बिक्री
                </h2>
                <p className="text-[11px] text-slate-500">Live Today's Business & Galla</p>
              </div>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                {new Date().toLocaleDateString('hi-IN', { day: 'numeric', month: 'short' })}
              </span>
            </div>

            {/* Today's Galla Main Card */}
            <div className="bg-gradient-to-br from-emerald-800 to-emerald-950 text-white p-4 rounded-2xl shadow-md border border-emerald-700">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                Total Today's Sale (कुल गल्ला)
              </span>
              <div className="text-3xl font-black mt-1 text-white">₹{todayTotal.toLocaleString()}</div>
              
              <div className="mt-3 pt-3 border-t border-emerald-700/60 flex items-center justify-between text-xs text-emerald-200">
                <span>{todaySales.length} Parchi (Bills) Kat chuke hain</span>
                <span className="bg-amber-400 text-emerald-950 px-2 py-0.5 rounded-full text-[10px] font-black">
                  LIVE
                </span>
              </div>
            </div>

            {/* Payment Mode Grid */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
                <span className="text-[10px] font-bold text-slate-500 block">💵 Cash In Hand</span>
                <span className="text-sm font-black text-slate-900 mt-1 block">₹{todayCash}</span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
                <span className="text-[10px] font-bold text-indigo-600 block">📱 UPI / QR</span>
                <span className="text-sm font-black text-indigo-900 mt-1 block">₹{todayUpi}</span>
              </div>
              <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
                <span className="text-[10px] font-bold text-amber-600 block">📕 Udhar (Khata)</span>
                <span className="text-sm font-black text-amber-900 mt-1 block">₹{todayKhata}</span>
              </div>
            </div>

            {/* Top Selling Items Today */}
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-black text-slate-800 mb-2 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-700" /> Aaj Sabse Zyada Bika (Top Items)
              </h3>
              {topSellingToday.length === 0 ? (
                <p className="text-[11px] text-slate-400 py-2 text-center">Aaj abhi tak koi sale nahi hui</p>
              ) : (
                <div className="divide-y divide-slate-100">
                  {topSellingToday.map((it, idx) => (
                    <div key={it.name} className="py-2 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center text-[10px] font-bold">
                          {idx + 1}
                        </span>
                        <span className="font-semibold text-slate-800 line-clamp-1">{it.name}</span>
                      </div>
                      <span className="font-black text-slate-900 shrink-0">{it.qty} pcs</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Today's Bills Log List */}
            <div className="space-y-2">
              <h3 className="text-xs font-black text-slate-800 flex items-center justify-between">
                <span>Aaj Ki Parchi (Bills Log)</span>
                <span className="text-[10px] text-slate-400 font-normal">{todaySales.length} Invoices</span>
              </h3>

              {todaySales.length === 0 ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                  Abhi tak aaj koi bill nahi kata gaya hai.
                </div>
              ) : (
                todaySales.map((sale) => (
                  <div
                    key={sale.id}
                    onClick={() => setReceiptModalBill(sale)}
                    className="bg-white p-3 rounded-2xl border border-slate-200 flex items-center justify-between active:bg-slate-50 transition cursor-pointer shadow-xs"
                  >
                    <div className="flex-1 pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-bold text-slate-400">{sale.id}</span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                            sale.paymentMode === 'UPI'
                              ? 'bg-indigo-100 text-indigo-700'
                              : sale.paymentMode === 'Khata'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {sale.paymentMode}
                        </span>
                        <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-slate-900 mt-1">{sale.customerName}</div>
                      <div className="text-[10px] text-slate-500 line-clamp-1">
                        {sale.items.map((i) => `${i.name} (x${i.qty})`).join(', ')}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-sm font-black text-emerald-800">₹{sale.total}</div>
                      <span className="text-[10px] text-slate-400 flex items-center justify-end gap-0.5 mt-0.5">
                        Bill <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* SCREEN 3: STOCK & INVENTORY (Mobile Card View) */}
        {/* ============================================================== */}
        {activeTab === 'stock' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3 pb-24">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-black text-slate-900">Dukan Ka Saman & Stock</h2>
                <p className="text-[11px] text-slate-500">{products.length} Products in store</p>
              </div>

              <button
                onClick={() => setIsNewItemDrawerOpen(true)}
                className="bg-emerald-700 text-white px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1 shadow-sm active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" /> Naya Saman
              </button>
            </div>

            {/* Low Stock Warning Banner */}
            {lowStockCount > 0 && (
              <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-2xl flex items-center justify-between text-xs text-amber-900">
                <span className="flex items-center gap-1.5 font-bold">
                  <AlertTriangle className="w-4 h-4 text-amber-600" /> {lowStockCount} saman kam pad rahe hain!
                </span>
                <span className="text-[10px] bg-amber-200 px-2 py-0.5 rounded-full font-bold">Reorder</span>
              </div>
            )}

            {/* Inventory Mobile List */}
            <div className="space-y-2">
              {products.map((p) => {
                const isLow = p.stock <= p.reorderLevel;
                const isOut = p.stock <= 0;

                return (
                  <div key={p.id} className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            {p.category}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">#{p.barcode}</span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-900 mt-1">{p.name}</h4>
                        <div className="text-xs text-slate-500 mt-0.5">
                          Khareed: <span className="font-semibold">₹{p.costPrice}</span> • Bikri MRP:{' '}
                          <span className="font-bold text-emerald-800">₹{p.price}</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span
                          className={`text-xs font-black px-2 py-0.5 rounded-lg inline-block ${
                            isOut
                              ? 'bg-rose-100 text-rose-800'
                              : isLow
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {p.stock} {p.unit}
                        </span>
                        <div className="text-[9px] text-slate-400 mt-1">Alert: {p.reorderLevel}</div>
                      </div>
                    </div>

                    {/* Quick Restock Buttons (+5, +10) */}
                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400">Quick Restock:</span>
                      <div className="flex space-x-1.5">
                        <button
                          onClick={() => handleRestock(p.id, 5)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 rounded-lg text-xs font-bold transition"
                        >
                          +5
                        </button>
                        <button
                          onClick={() => handleRestock(p.id, 10)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 rounded-lg text-xs font-bold transition"
                        >
                          +10
                        </button>
                        <button
                          onClick={() => handleRestock(p.id, 25)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 rounded-lg text-xs font-bold transition"
                        >
                          +25
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* SCREEN 4: UDHAR / KHATA BOOK (Mobile Ledger) */}
        {/* ============================================================== */}
        {activeTab === 'khata' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
            {/* Total Udhar Banner */}
            <div className="bg-amber-500 text-amber-950 p-4 rounded-2xl shadow-sm border border-amber-400 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-900">
                  Total Udhar Due (मार्केट बकाया)
                </span>
                <div className="text-2xl font-black mt-0.5">₹{totalUdharDue.toLocaleString()}</div>
                <div className="text-[11px] text-amber-900 mt-1 font-semibold">{khataCustomers.length} Customers</div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-amber-400/80 flex items-center justify-center text-amber-900">
                <BookOpen className="w-6 h-6" />
              </div>
            </div>

            {/* Customers Contacts List */}
            <div className="space-y-2">
              <h3 className="text-xs font-black text-slate-800">Grahak Udhar Suchi (Customer Khata)</h3>

              {khataCustomers.map((cust) => (
                <div key={cust.id} className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-black text-slate-900">{cust.name}</h4>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Phone className="w-2.5 h-2.5" /> {cust.phone}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-rose-500 font-bold block">Baki Rupaye</span>
                      <span className="text-base font-black text-rose-600">₹{cust.balance}</span>
                    </div>
                  </div>

                  {/* Actions: Settle Payment or Send WhatsApp */}
                  <div className="flex space-x-2 pt-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setKhataSettleTarget(cust);
                        setSettleAmount(cust.balance.toString());
                      }}
                      className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" /> Jama Kiya
                    </button>

                    <button
                      onClick={() => {
                        const text = `Namaste ${cust.name} ji, ${storeInfo.name} par aapka kul ₹${cust.balance} baaki hai. Kripya samay par jama karwayein. Dhanyawad!`;
                        window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                      }}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-200 flex items-center gap-1"
                      title="WhatsApp Reminder"
                    >
                      <Share2 className="w-3.5 h-3.5" /> Reminder
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* FIXED BOTTOM MOBILE NAVIGATION BAR */}
        {/* ============================================================== */}
        <nav className="absolute bottom-0 left-0 right-0 bg-white border-t border-slate-200 py-1.5 px-3 flex justify-around items-center z-30 shadow-lg">
          {[
            { id: 'billing', label: 'Billing POS', hindi: 'बिल बनाएं', icon: ShoppingCart },
            { id: 'aaj-bikri', label: 'Aaj Bikri', hindi: 'आज की बिक्री', icon: BarChart3, highlight: true },
            { id: 'stock', label: 'Stock', hindi: 'सामान स्टॉक', icon: Package, badge: lowStockCount },
            { id: 'khata', label: 'Khata Book', hindi: 'उधार खाता', icon: BookOpen }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition ${
                  isActive ? 'text-emerald-800 font-black' : 'text-slate-400 font-medium'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-emerald-700 stroke-[2.5]' : 'text-slate-400'}`} />
                  {tab.badge && tab.badge > 0 ? (
                    <span className="absolute -top-1 -right-2 bg-amber-500 text-white rounded-full text-[9px] w-3.5 h-3.5 flex items-center justify-center font-bold">
                      {tab.badge}
                    </span>
                  ) : null}
                </div>
                <span className="text-[10px] mt-0.5 leading-none">{tab.label}</span>
                <span className="text-[8px] opacity-75">{tab.hindi}</span>
              </button>
            );
          })}
        </nav>

        {/* ============================================================== */}
        {/* SLIDE-UP DRAWER: QUICK CHECKOUT & BILL GENERATION */}
        {/* ============================================================== */}
        {isCheckoutDrawerOpen && (
          <div className="absolute inset-0 z-40 bg-black/60 backdrop-blur-xs flex flex-col justify-end">
            <div className="bg-white rounded-t-3xl p-5 space-y-4 max-h-[85%] flex flex-col animate-slide-up shadow-2xl">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-black text-slate-900">Grahak Bill & Payment</h3>
                  <p className="text-xs text-slate-500">{cartItemCount} saman cart mein</p>
                </div>
                <button
                  onClick={() => setIsCheckoutDrawerOpen(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Quick Customer Inputs */}
              <div className="space-y-2 text-xs">
                <input
                  type="text"
                  placeholder="Grahak Ka Naam (Name) *"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-600 font-medium"
                />
                <input
                  type="text"
                  placeholder="Mobile Number (Optional)"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-600 font-medium"
                />
              </div>

              {/* Payment Mode Selector */}
              <div>
                <label className="text-[11px] font-bold text-slate-500 block mb-1.5">Payment Kaise Liya?</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'Cash', label: '💵 Cash' },
                    { id: 'UPI', label: '📱 UPI QR' },
                    { id: 'Khata', label: '📕 Udhar' }
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMode(m.id)}
                      className={`py-2 rounded-xl text-xs font-black border transition ${
                        paymentMode === m.id
                          ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              {paymentMode === 'UPI' && (
                <button
                  type="button"
                  onClick={() => setIsQrModalOpen(true)}
                  className="w-full py-2 bg-indigo-50 border border-indigo-200 text-indigo-700 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5"
                >
                  <QrCode className="w-4 h-4" /> Grahak Ko QR Code Dikhayein (₹{cartTotal})
                </button>
              )}

              {/* Discount and Summary */}
              <div className="bg-slate-50 p-3 rounded-2xl space-y-1.5 border border-slate-200 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Subtotal:</span>
                  <span className="font-bold text-slate-800">₹{cartSubtotal}</span>
                </div>
                <div className="flex justify-between items-center text-slate-500">
                  <span>Discount Chhoot (₹):</span>
                  <input
                    type="number"
                    value={discount || ''}
                    placeholder="0"
                    onChange={(e) => setDiscount(e.target.value)}
                    className="w-16 px-1.5 py-0.5 border rounded text-right text-xs bg-white font-bold"
                  />
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
                  <span className="text-xs font-black uppercase text-slate-600">Kul Bill (Net):</span>
                  <span className="text-xl font-black text-emerald-800">₹{cartTotal}</span>
                </div>
              </div>

              {/* Complete Action Button */}
              <button
                type="button"
                onClick={handleCompleteSale}
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg active:scale-95 transition"
              >
                <CheckCircle className="w-4 h-4" /> Parchi Kat Karein (Save Bill)
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* MODAL: MOBILE THERMAL RECEIPT & WHATSAPP SHARE */}
        {/* ============================================================== */}
        {receiptModalBill && (
          <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white w-full rounded-3xl p-5 shadow-2xl space-y-4 max-h-[90%] overflow-y-auto font-mono text-xs">
              <div className="text-center pb-2 border-b border-dashed border-slate-300">
                <h3 className="font-black text-sm uppercase text-slate-900">{storeInfo.name}</h3>
                <p className="text-[10px] text-slate-500">{storeInfo.address}, Ph: {storeInfo.phone}</p>
                <p className="text-[9px] text-slate-400 mt-0.5">GSTIN: {storeInfo.gstin}</p>
              </div>

              <div className="space-y-1 text-[11px] pb-2 border-b border-dashed border-slate-300">
                <div className="flex justify-between">
                  <span>Bill #{receiptModalBill.id}</span>
                  <span>{new Date(receiptModalBill.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <div className="flex justify-between">
                  <span>Grahak: {receiptModalBill.customerName}</span>
                  <span className="font-bold">{receiptModalBill.paymentMode}</span>
                </div>
              </div>

              <div className="space-y-1.5 pb-2 border-b border-dashed border-slate-300">
                {receiptModalBill.items.map((it, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span className="line-clamp-1 max-w-[140px]">{it.name}</span>
                    <span>
                      {it.qty}x{it.price} = ₹{it.qty * it.price}
                    </span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-[11px] font-bold">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>₹{receiptModalBill.subtotal}</span>
                </div>
                {receiptModalBill.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount:</span>
                    <span>-₹{receiptModalBill.discount}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-black text-slate-900 pt-1 border-t border-slate-300">
                  <span>TOTAL:</span>
                  <span>₹{receiptModalBill.total}</span>
                </div>
              </div>

              <div className="text-center text-[10px] text-slate-400">
                🙏 धन्यवाद! फिर पधारें 🙏
              </div>

              {/* Receipt Control Buttons */}
              <div className="space-y-2 pt-2 border-t border-slate-100 font-sans">
                <button
                  type="button"
                  onClick={() => {
                    const text = `*${storeInfo.name} Receipt*\nBill: ${receiptModalBill.id}\nTotal: ₹${receiptModalBill.total}\nDhanyawad!`;
                    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                  }}
                  className="w-full py-2.5 bg-emerald-600 text-white rounded-xl font-black text-xs flex items-center justify-center gap-1.5 shadow"
                >
                  <Share2 className="w-3.5 h-3.5" /> WhatsApp Par Bhejein
                </button>

                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs flex items-center justify-center gap-1"
                  >
                    <Printer className="w-3.5 h-3.5" /> Print
                  </button>
                  <button
                    type="button"
                    onClick={() => setReceiptModalBill(null)}
                    className="flex-1 py-2 bg-slate-900 text-white rounded-xl font-bold text-xs"
                  >
                    Band Karein
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* MODAL: UPI QR SCANNER SIMULATOR */}
        {/* ============================================================== */}
        {isQrModalOpen && (
          <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white w-full rounded-3xl p-6 text-center shadow-2xl border border-slate-200 space-y-3">
              <h3 className="text-sm font-black text-slate-900">GPay / PhonePe / Paytm</h3>
              <p className="text-[11px] text-slate-500">Scan karke ₹{cartTotal} ada karein</p>

              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 inline-block">
                <svg className="w-40 h-40 mx-auto" viewBox="0 0 100 100" fill="none">
                  <rect width="100" height="100" fill="white" />
                  <rect x="10" y="10" width="25" height="25" rx="3" stroke="#065f46" strokeWidth="4" />
                  <rect x="16" y="16" width="13" height="13" fill="#065f46" />
                  <rect x="65" y="10" width="25" height="25" rx="3" stroke="#065f46" strokeWidth="4" />
                  <rect x="71" y="16" width="13" height="13" fill="#065f46" />
                  <rect x="10" y="65" width="25" height="25" rx="3" stroke="#065f46" strokeWidth="4" />
                  <rect x="16" y="71" width="13" height="13" fill="#065f46" />
                  <rect x="42" y="15" width="8" height="8" fill="#1e293b" />
                  <rect x="45" y="30" width="14" height="6" fill="#1e293b" />
                  <rect x="25" y="42" width="10" height="10" fill="#1e293b" />
                  <rect x="42" y="42" width="16" height="16" fill="#059669" />
                  <rect x="65" y="45" width="8" height="12" fill="#1e293b" />
                  <rect x="45" y="65" width="12" height="8" fill="#1e293b" />
                  <rect x="65" y="70" width="18" height="18" fill="#1e293b" />
                </svg>
              </div>

              <div className="text-xl font-black text-emerald-800">₹{cartTotal}</div>
              <p className="text-[10px] text-slate-400 font-mono">UPI ID: {storeInfo.upiId}</p>

              <button
                onClick={() => setIsQrModalOpen(false)}
                className="w-full py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold mt-2"
              >
                Payment Mil Gaya (Back)
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* DRAWER: EDIT STORE DETAILS */}
        {/* ============================================================== */}
        {isStoreSettingsOpen && (
          <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end">
            <div className="bg-white rounded-t-3xl p-5 space-y-3 max-h-[90%] flex flex-col animate-slide-up shadow-2xl">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                    <Store className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900">Dukan Ki Jankari (Store Details)</h3>
                    <p className="text-[10px] text-slate-400">Bill aur Header par yahi naam aayega</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsStoreSettingsOpen(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setStoreInfo(editStoreForm);
                  setIsStoreSettingsOpen(false);
                  triggerToast('Store Profile Update Ho Gaya!');
                }}
                className="space-y-3 text-xs"
              >
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Dukan / Agency Ka Naam *</label>
                  <input
                    type="text"
                    required
                    value={editStoreForm.name}
                    onChange={(e) => setEditStoreForm({ ...editStoreForm, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tagline / Subtitle</label>
                  <input
                    type="text"
                    value={editStoreForm.tagline}
                    onChange={(e) => setEditStoreForm({ ...editStoreForm, tagline: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={editStoreForm.phone}
                      onChange={(e) => setEditStoreForm({ ...editStoreForm, phone: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">UPI ID</label>
                    <input
                      type="text"
                      value={editStoreForm.upiId}
                      onChange={(e) => setEditStoreForm({ ...editStoreForm, upiId: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Pata / Address</label>
                  <input
                    type="text"
                    value={editStoreForm.address}
                    onChange={(e) => setEditStoreForm({ ...editStoreForm, address: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-700 text-white rounded-2xl font-black text-xs mt-2 active:scale-95 transition shadow-lg"
                >
                  Save Store Details
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* DRAWER: ADD NEW PRODUCT */}
        {/* ============================================================== */}
        {isNewItemDrawerOpen && (
          <div className="absolute inset-0 z-40 bg-black/60 backdrop-blur-xs flex flex-col justify-end">
            <div className="bg-white rounded-t-3xl p-5 space-y-3 max-h-[85%] flex flex-col animate-slide-up shadow-2xl">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h3 className="text-base font-black text-slate-900">Naya Saman Jodein</h3>
                <button
                  onClick={() => setIsNewItemDrawerOpen(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveNewProduct} className="space-y-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Saman Ka Naam *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Parle-G 250g"
                    value={newItemForm.name}
                    onChange={(e) => setNewItemForm({ ...newItemForm, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Category</label>
                    <select
                      value={newItemForm.category}
                      onChange={(e) => setNewItemForm({ ...newItemForm, category: e.target.value })}
                      className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    >
                      {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Bikri MRP (₹) *</label>
                    <input
                      type="number"
                      required
                      placeholder="0"
                      value={newItemForm.price}
                      onChange={(e) => setNewItemForm({ ...newItemForm, price: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Shuruati Stock</label>
                    <input
                      type="number"
                      value={newItemForm.stock}
                      onChange={(e) => setNewItemForm({ ...newItemForm, stock: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Low Stock Alert</label>
                    <input
                      type="number"
                      value={newItemForm.reorderLevel}
                      onChange={(e) => setNewItemForm({ ...newItemForm, reorderLevel: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-700 text-white rounded-2xl font-black text-xs mt-2"
                >
                  Save Saman
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* MODAL: KHATA PAYMENT SETTLEMENT */}
        {/* ============================================================== */}
        {khataSettleTarget && (
          <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white w-full rounded-3xl p-5 shadow-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-slate-900">Udhar Jama Karein</h3>
                  <p className="text-xs text-slate-500">{khataSettleTarget.name}</p>
                </div>
                <button
                  onClick={() => setKhataSettleTarget(null)}
                  className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-center">
                <span className="text-[10px] text-amber-900 font-bold block">Kul Baaki (Pending):</span>
                <span className="text-xl font-black text-rose-600">₹{khataSettleTarget.balance}</span>
              </div>

              <form onSubmit={handleSettleKhataSubmit} className="space-y-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Jama Kiya Rupaye (₹)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max={khataSettleTarget.balance}
                    value={settleAmount}
                    onChange={(e) => setSettleAmount(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl font-bold text-base bg-slate-50"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-700 text-white rounded-xl font-black text-xs shadow"
                >
                  Payment Entry Save Karein
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}