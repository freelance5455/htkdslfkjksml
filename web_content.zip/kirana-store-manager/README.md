# Kirana Store Manager

A mobile-first React + Vite Progressive Web App based on the supplied Kirana Store Manager source.

## Included
- POS billing and invoice view
- Today's sales dashboard
- Product inventory and quick restock
- Customer Udhar / Khata book and settlement
- Store profile settings
- Browser localStorage persistence
- Installable PWA manifest and service worker for offline app-shell access

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run: `npm install`
3. Run: `npm run dev`
4. Open the local URL shown by Vite.

## Install on an Android phone
1. Build and host the app over HTTPS: `npm run build` then publish the `dist` folder to an HTTPS static host.
2. Open that HTTPS address in Chrome on Android.
3. Open Chrome menu (⋮) and choose **Install app** or **Add to Home screen**.
4. Launch it from the new home-screen icon.

This package is a PWA project, not a signed APK. A directly installable APK needs an Android build/signing step (for example, using Android Studio/Capacitor).

## Important setup notes
- The app stores data in the browser on that device. It does not automatically sync or back up to another phone.
- The initial products, bills, customer balances, store name, phone, GSTIN and UPI ID are sample/demo values from the supplied source. Update store details and replace sample records before real business use.
- The QR screen in the supplied source is a visual simulator, not a verified payment QR. Do not use it to collect payments. Configure a real UPI QR separately.
- The supplied source does not include authentication, cloud backup, GST-compliant accounting, or multi-device synchronization.
