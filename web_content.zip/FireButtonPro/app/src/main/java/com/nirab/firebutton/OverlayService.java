package com.nirab.firebutton;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;

/**
 * Foreground service that draws the FIRE button over other apps.
 * It runs with a persistent notification (with a STOP action) until STOP is pressed.
 * The button only displays a shape. It sends no touches and reads no screen.
 */
public class OverlayService extends Service {

    public static final String ACTION_START  = "com.nirab.firebutton.START";
    public static final String ACTION_UPDATE = "com.nirab.firebutton.UPDATE";
    public static final String ACTION_LOCK   = "com.nirab.firebutton.LOCK";
    public static final String ACTION_HIDE   = "com.nirab.firebutton.HIDE";
    public static final String ACTION_STOP   = "com.nirab.firebutton.STOP";

    public static final String EXTRA_SIZE     = "size";
    public static final String EXTRA_COLOR    = "color";
    public static final String EXTRA_OPACITY  = "opacity";
    public static final String EXTRA_LOCKED   = "locked";
    public static final String EXTRA_STYLE    = "style";      // "default" | "trace" | "clean" | "crossed"
    public static final String EXTRA_CONTRAST = "contrast";

    private static final String CHANNEL_ID = "fire_overlay_channel";
    private static final int NOTIFICATION_ID = 4242;
    private static final String DEFAULT_COLOR = "#ff1744";

    private static volatile boolean running = false;

    public static boolean isRunning() {
        return running;
    }

    private WindowManager windowManager;
    private FireButtonView fireView;
    private WindowManager.LayoutParams layoutParams;
    private boolean overlayShown = false;

    private int sizeValue = 50;          // 1..100, same as the HTML slider
    private String colorHex = DEFAULT_COLOR;
    private int opacityPct = 100;        // 1..100
    private boolean locked = false;
    private int styleId = FireButtonView.STYLE_DEFAULT;
    private boolean contrast = false;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = (intent != null && intent.getAction() != null)
                ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {        // STOP button in the notification
            stopSelf();
            return START_NOT_STICKY;
        }

        // Must be called promptly after startForegroundService(), so do it first.
        startAsForeground("Floating fire button is active");
        running = true;
        readExtras(intent);

        switch (action) {
            case ACTION_HIDE:
                hideOverlay();
                updateNotification("Overlay hidden. Open the app and press START to show it again.");
                break;
            case ACTION_LOCK:
            case ACTION_UPDATE:
                applyStyle();
                break;
            default:                              // ACTION_START
                showOverlay();
                break;
        }
        return START_NOT_STICKY;
    }

    private void readExtras(Intent i) {
        if (i == null) return;
        if (i.hasExtra(EXTRA_SIZE)) sizeValue = clamp(parseInt(i.getStringExtra(EXTRA_SIZE), sizeValue), 1, 100);
        if (i.hasExtra(EXTRA_COLOR)) colorHex = i.getStringExtra(EXTRA_COLOR);
        if (i.hasExtra(EXTRA_OPACITY)) opacityPct = clamp(parseInt(i.getStringExtra(EXTRA_OPACITY), opacityPct), 1, 100);
        if (i.hasExtra(EXTRA_LOCKED)) locked = i.getBooleanExtra(EXTRA_LOCKED, locked);
        if (i.hasExtra(EXTRA_STYLE)) styleId = styleFromName(i.getStringExtra(EXTRA_STYLE));
        if (i.hasExtra(EXTRA_CONTRAST)) contrast = i.getBooleanExtra(EXTRA_CONTRAST, contrast);
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();                           // permission removed: stop cleanly
            return;
        }
        if (overlayShown) {
            applyStyle();
            return;
        }
        if (fireView == null) {
            buildView();
        }
        windowManager.addView(fireView, layoutParams);
        overlayShown = true;
        applyStyle();
        updateNotification("Floating fire button is active");
    }

    private void buildView() {
        fireView = new FireButtonView(this);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;

        // Start near bottom-right, like the HTML (right 25px, bottom 100px).
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int approx = dp(30 + sizeValue * 0.8f);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.contains(KEY_X) && prefs.contains(KEY_Y)) {
            // Restore the last position, kept on screen in case the display changed.
            layoutParams.x = clamp(prefs.getInt(KEY_X, 0), 0, Math.max(0, dm.widthPixels - dp(40)));
            layoutParams.y = clamp(prefs.getInt(KEY_Y, 0), 0, Math.max(0, dm.heightPixels - dp(40)));
        } else {
            layoutParams.x = Math.max(0, dm.widthPixels - approx - dp(25));
            layoutParams.y = Math.max(0, dm.heightPixels - approx - dp(100));
        }

        fireView.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downRawX, downRawY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (locked) return false;         // LOCKED: cannot be dragged
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = layoutParams.x;
                        startY = layoutParams.y;
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        layoutParams.x = Math.max(0, startX + (int) (e.getRawX() - downRawX));
                        layoutParams.y = Math.max(0, startY + (int) (e.getRawY() - downRawY));
                        windowManager.updateViewLayout(fireView, layoutParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        savePosition();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void applyStyle() {
        if (fireView == null || layoutParams == null) return;
        int px = dp(30 + sizeValue * 0.8f);      // same formula as the HTML

        fireView.configure(parseColor(colorHex), styleId, contrast, locked);
        fireView.setAlpha(opacityPct / 100f);

        // Size goes on the window layout params. setWidth/setHeight alone is overridden
        // by WRAP_CONTENT when the window is laid out.
        layoutParams.width = px;
        layoutParams.height = px;

        if (overlayShown) {
            windowManager.updateViewLayout(fireView, layoutParams);
        }
    }

    private void hideOverlay() {
        if (overlayShown && fireView != null) {
            try {
                windowManager.removeView(fireView);
            } catch (IllegalArgumentException ignored) {
                // already removed
            }
        }
        overlayShown = false;
    }

    private void startAsForeground(String text) {
        Notification n = buildNotification(text);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private Notification buildNotification(String text) {
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);

        PendingIntent stopPi = PendingIntent.getService(this, 0,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP), piFlags);
        PendingIntent openPi = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class), piFlags);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_fire)
                .setContentTitle("FIRE BUTTON PRO")
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .addAction(0, "STOP", stopPi)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Fire button overlay", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Shows while the floating fire button is running");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Override
    public void onDestroy() {
        savePosition();
        hideOverlay();
        running = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---- helpers ----

    private static final String PREFS = "fire_prefs";
    private static final String KEY_X = "x";
    private static final String KEY_Y = "y";

    private void savePosition() {
        if (layoutParams == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_X, layoutParams.x)
                .putInt(KEY_Y, layoutParams.y)
                .apply();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static int styleFromName(String name) {
        if ("trace".equals(name)) return FireButtonView.STYLE_TRACE;
        if ("clean".equals(name)) return FireButtonView.STYLE_CLEAN;
        if ("crossed".equals(name)) return FireButtonView.STYLE_CROSSED;
        return FireButtonView.STYLE_DEFAULT;
    }

    private static int parseInt(String s, int fallback) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int parseColor(String hex) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return Color.parseColor(DEFAULT_COLOR);
        }
    }
}
