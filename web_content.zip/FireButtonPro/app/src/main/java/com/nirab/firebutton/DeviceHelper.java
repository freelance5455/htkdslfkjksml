package com.nirab.firebutton;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

/**
 * Opens the system / MIUI / HyperOS settings screens the user needs.
 * Xiaomi's autostart screen is not a public API, so if it is missing we fall back
 * to the app info page and show instructions. Nothing here changes system settings itself.
 */
public final class DeviceHelper {

    private DeviceHelper() {}

    public static boolean isXiaomiFamily() {
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();
        String b = Build.BRAND == null ? "" : Build.BRAND.toLowerCase();
        return m.contains("xiaomi") || b.contains("redmi") || b.contains("xiaomi") || b.contains("poco");
    }

    public static void openOverlayPermission(Context c) {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + c.getPackageName()));
        if (!tryStart(c, i)) openAppDetails(c);
    }

    public static void openBatterySettings(Context c) {
        // Choose "No restrictions" for FIRE BUTTON PRO on this screen.
        if (!tryStart(c, new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) {
            openAppDetails(c);
        }
    }

    public static void openAutostart(Context c) {
        Intent miui = new Intent().setComponent(new ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"));
        if (tryStart(c, miui)) return;

        Toast.makeText(c,
                "Autostart screen not found. Open Security app > Permissions > Autostart and enable FIRE BUTTON PRO.",
                Toast.LENGTH_LONG).show();
        openAppDetails(c);
    }

    public static void openAppDetails(Context c) {
        tryStart(c, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + c.getPackageName())));
    }

    private static boolean tryStart(Context c, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            return false;
        }
    }
}
