package com.nirab.firebutton;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Shows the ORIGINAL FIRE BUTTON PRO HTML UI (assets/index.html) inside a WebView.
 * The HTML's START / STOP / HIDE / LOCK buttons are forwarded to native code
 * (NativeBridge), which runs the real floating overlay in OverlayService.
 * Settings (size, colour, transparency) are saved by the page's own localStorage,
 * which survives closing and reopening the app.
 */
public class MainActivity extends Activity {

    private static final int REQ_NOTIFICATIONS = 101;
    private static final int MENU_SETUP = 1;

    private WebView webView;
    private NativeBridge bridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // localStorage -> saved settings
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);

        bridge = new NativeBridge(this, webView);
        webView.addJavascriptInterface(bridge, "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(NativeBridge.BRIDGE_JS, null);
                bridge.syncStatusToPage();
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
        askNotificationPermission();
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_SETUP, 0, "Permissions & setup");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == MENU_SETUP) {
            showSetupDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showSetupDialog() {
        String[] items = {
                "1. Display over other apps (required)",
                "2. Battery: set to 'No restrictions'",
                "3. Autostart (Xiaomi / Redmi / HyperOS)",
                "4. App info / other permissions"
        };
        String title = DeviceHelper.isXiaomiFamily()
                ? "Setup for Redmi / Xiaomi"
                : "Setup";
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0: DeviceHelper.openOverlayPermission(this); break;
                        case 1: DeviceHelper.openBatterySettings(this); break;
                        case 2: DeviceHelper.openAutostart(this); break;
                        default: DeviceHelper.openAppDetails(this); break;
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        // Closing the app does NOT stop the overlay service; use STOP in the app or the notification.
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
