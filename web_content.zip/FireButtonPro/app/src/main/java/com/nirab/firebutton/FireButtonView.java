package com.nirab.firebutton;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.view.View;

/**
 * Draws the floating button in one of four styles, matching the HTML preview:
 *  DEFAULT : filled circle with white ring and "FIRE" label
 *  TRACE   : dashed ring with a centre dot
 *  CLEAN   : solid dot only
 *  CROSSED : ring with a crosshair
 * Optional CONTRAST draws a dark disc behind the button so it stays visible on bright scenes.
 * LOCKED shows a cyan ring, same as the HTML's .locked border.
 */
public class FireButtonView extends View {

    public static final int STYLE_DEFAULT = 0;
    public static final int STYLE_TRACE = 1;
    public static final int STYLE_CLEAN = 2;
    public static final int STYLE_CROSSED = 3;

    private static final int CYAN = 0xFF00D9FF;

    private final float density;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int color = Color.parseColor("#ff1744");
    private int style = STYLE_DEFAULT;
    private boolean contrast = false;
    private boolean locked = false;

    public FireButtonView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        label.setColor(Color.WHITE);
        label.setTextAlign(Paint.Align.CENTER);
        label.setFakeBoldText(true);
    }

    public void configure(int color, int style, boolean contrast, boolean locked) {
        this.color = color;
        this.style = style;
        this.contrast = contrast;
        this.locked = locked;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f - 3 * density;
        if (r <= 0) return;

        if (contrast) {
            fill.setColor(0xB3000000);                       // 70% black disc
            c.drawCircle(cx, cy, r + 2 * density, fill);
        }

        switch (style) {
            case STYLE_TRACE:
                stroke.setColor(locked ? CYAN : color);
                stroke.setStrokeWidth(2 * density);
                stroke.setPathEffect(new DashPathEffect(
                        new float[]{6 * density, 5 * density}, 0));
                c.drawCircle(cx, cy, r, stroke);
                stroke.setPathEffect(null);
                fill.setColor(color);
                c.drawCircle(cx, cy, 3 * density, fill);
                break;

            case STYLE_CLEAN:
                fill.setColor(color);
                c.drawCircle(cx, cy, r * 0.4f, fill);
                if (locked) {
                    stroke.setColor(CYAN);
                    stroke.setStrokeWidth(2 * density);
                    c.drawCircle(cx, cy, r, stroke);
                }
                break;

            case STYLE_CROSSED:
                stroke.setColor(locked ? CYAN : color);
                stroke.setStrokeWidth(2 * density);
                stroke.setPathEffect(null);
                c.drawCircle(cx, cy, r, stroke);
                c.drawLine(cx, cy - r, cx, cy + r, stroke);
                c.drawLine(cx - r, cy, cx + r, cy, stroke);
                fill.setColor(color);
                c.drawCircle(cx, cy, 2.5f * density, fill);
                break;

            default: // STYLE_DEFAULT
                fill.setColor(color);
                c.drawCircle(cx, cy, r, fill);
                float ring = 3 * density;
                stroke.setColor(locked ? CYAN : Color.WHITE);
                stroke.setStrokeWidth(ring);
                c.drawCircle(cx, cy, r - ring / 2f, stroke);
                label.setTextSize(r * 0.5f);
                float baseline = cy - (label.descent() + label.ascent()) / 2f;
                c.drawText("FIRE", cx, baseline, label);
                break;
        }
    }
}
