package com.nirab.firebutton;

import android.app.Activity;
import android.content.Intent;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/**
 * JavaScript <-> native bridge exposed to index.html as window.AndroidBridge.
 * The HTML is not rewritten: BRIDGE_JS only listens to the buttons and controls that
 * already exist on the page and forwards their values.
 */
public class NativeBridge {

    /** Injected after index.html loads. Adds listeners; it does not replace the page's own handlers. */
    public static final String BRIDGE_JS = """
        (function () {
          if (window.__fireNativeBridge) return;
          window.__fireNativeBridge = true;

          // The in-page floating preview is replaced by the real overlay outside the app.
          var style = document.createElement('style');
          style.textContent = '#floating,#controls{display:none !important}';
          document.head.appendChild(style);

          function $(id) { return document.getElementById(id); }
          function current() {
            return {
              size: $('size').value,
              color: $('color').value,
              opacity: $('opacity').value,
              style: $('style').value,
              contrast: $('contrast').checked,
              locked: $('lock').textContent.indexOf('LOCKED') !== -1
            };
          }

          // Listeners are added AFTER the page's own handlers, so the page's text/status updates still run first.
          $('start').addEventListener('click', function () {
            var s = current();
            AndroidBridge.start(s.size, s.color, s.opacity, s.locked, s.style, s.contrast);
          });
          $('stop').addEventListener('click', function () { AndroidBridge.stop(); });
          $('hide').addEventListener('click', function () { AndroidBridge.hide(); });
          $('lock').addEventListener('click', function () { AndroidBridge.setLocked(current().locked); });
          ['size', 'color', 'opacity', 'style', 'contrast'].forEach(function (id) {
            $(id).addEventListener('input', function () {
              var s = current();
              AndroidBridge.update(s.size, s.color, s.opacity, s.style, s.contrast);
            });
          });
        })();
        """;

    private final Activity activity;
    private final WebView webView;

    public NativeBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @JavascriptInterface
    public void start(String size, String color, String opacity, boolean locked,
                      String style, boolean contrast) {
        activity.runOnUiThread(() -> {
            if (!Settings.canDrawOverlays(activity)) {
                Toast.makeText(activity,
                        "Turn on 'Display over other apps' for FIRE BUTTON PRO",
                        Toast.LENGTH_LONG).show();
                DeviceHelper.openOverlayPermission(activity);
                setPageStatus("NEEDS PERMISSION");
                return;
            }
            Intent i = new Intent(activity, OverlayService.class)
                    .setAction(OverlayService.ACTION_START)
                    .putExtra(OverlayService.EXTRA_SIZE, size)
                    .putExtra(OverlayService.EXTRA_COLOR, color)
                    .putExtra(OverlayService.EXTRA_OPACITY, opacity)
                    .putExtra(OverlayService.EXTRA_LOCKED, locked)
                    .putExtra(OverlayService.EXTRA_STYLE, style)
                    .putExtra(OverlayService.EXTRA_CONTRAST, contrast);
            ContextCompat.startForegroundService(activity, i);
            setPageStatus("RUNNING");
        });
    }

    @JavascriptInterface
    public void update(String size, String color, String opacity, String style, boolean contrast) {
        activity.runOnUiThread(() -> {
            if (!OverlayService.isRunning()) return;
            activity.startService(new Intent(activity, OverlayService.class)
                    .setAction(OverlayService.ACTION_UPDATE)
                    .putExtra(OverlayService.EXTRA_SIZE, size)
                    .putExtra(OverlayService.EXTRA_COLOR, color)
                    .putExtra(OverlayService.EXTRA_OPACITY, opacity)
                    .putExtra(OverlayService.EXTRA_STYLE, style)
                    .putExtra(OverlayService.EXTRA_CONTRAST, contrast));
        });
    }

    @JavascriptInterface
    public void setLocked(boolean locked) {
        activity.runOnUiThread(() -> {
            if (!OverlayService.isRunning()) return;
            activity.startService(new Intent(activity, OverlayService.class)
                    .setAction(OverlayService.ACTION_LOCK)
                    .putExtra(OverlayService.EXTRA_LOCKED, locked));
        });
    }

    @JavascriptInterface
    public void hide() {
        activity.runOnUiThread(() -> {
            if (OverlayService.isRunning()) {
                activity.startService(new Intent(activity, OverlayService.class)
                        .setAction(OverlayService.ACTION_HIDE));
            }
        });
    }

    @JavascriptInterface
    public void stop() {
        activity.runOnUiThread(() -> {
            // Stops the foreground service completely: overlay removed, notification removed.
            activity.stopService(new Intent(activity, OverlayService.class));
            setPageStatus("STOPPED");
        });
    }

    /** Called after the page loads so the status matches a service that is still running. */
    public void syncStatusToPage() {
        setPageStatus(OverlayService.isRunning() ? "RUNNING" : "STOPPED");
    }

    private void setPageStatus(String text) {
        webView.evaluateJavascript(
                "(function(){var e=document.getElementById('status');if(e)e.textContent='" + text + "';})();",
                null);
    }
}
