# FIRE BUTTON PRO – Android project

## Status (read this first)

- The project source is complete: Gradle files, manifest, `MainActivity`, `NativeBridge`, `OverlayService`, `DeviceHelper`, and the original `index.html`, copied unchanged into `app/src/main/assets/`.
- **It has not been compiled into an APK yet.** The build environment used to create it had no Android SDK and could not reach Google Maven or Maven Central.
- **It has not been tested on a real device.** Overlay, foreground service, LOCK and STOP behaviour on Redmi / Xiaomi / HyperOS still needs testing on your phone.
- Build it with Android Studio (steps below). If the build or the device test fails, send me the error or the logcat output.

## What is preserved

The HTML, CSS, JavaScript, colours, slider, preview, LOCK / HIDE buttons and the saved settings are all the same. The page's own `localStorage` keeps size, colour and transparency after the app is closed and reopened. The only additions are native hooks: START, STOP, HIDE and LOCK also drive the real overlay, and the in-page floating preview is hidden while the app is running.

## Project layout

```
FireButtonPro/
├── settings.gradle
├── build.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/index.html                 (original HTML, unchanged)
        ├── java/com/nirab/firebutton/
        │   ├── MainActivity.java             (WebView host, setup menu)
        │   ├── NativeBridge.java             (JS <-> native bridge, injected listeners)
        │   ├── OverlayService.java           (foreground service + floating overlay)
        │   └── DeviceHelper.java             (permission, battery, MIUI autostart screens)
        └── res/
            ├── drawable/ic_fire.xml
            └── values/strings.xml
```

## Features mapped to requirements

| # | Requirement | Where |
|---|---|---|
| 1 | Real APK, not just a WebView | Native services and overlay in `OverlayService`; WebView only shows the UI |
| 2 | Native floating overlay | `OverlayService` with `TYPE_APPLICATION_OVERLAY` |
| 3 | Foreground service + notification | `startForeground` with a STOP action, type `specialUse` on Android 14+ |
| 4 | Display over other apps | `SYSTEM_ALERT_WINDOW`, checked in `NativeBridge.start`, opened via `DeviceHelper` |
| 5 | Visible over other apps / games | Overlay window; some games or secure screens may block it (see limits) |
| 6 | LOCK / UNLOCK | Page LOCK button → `setLocked` → cyan border and no dragging |
| 7 | STOP stops the service | `stopService` from START/STOP, or the notification STOP action |
| 8 | Redmi / Xiaomi / MIUI / HyperOS | `DeviceHelper.openAutostart` and setup menu |
| 9 | Battery / autostart settings | Setup menu (⋮ → Permissions & setup) |
| 10 | Settings saved | `localStorage` in the WebView |
| 11 | Responsive | Viewport and `supports-screens`; overlay size is in dp |
| 12 | Safe permissions | Only overlay and notification permission; no accessibility service |
| 13 | No shooting / touch automation | The overlay only displays a button. It sends no touch input and changes no game files |

## Build with Android Studio

1. Install Android Studio (Hedgehog or newer) with the Android SDK, platform 34 and build-tools.
2. Open the `FireButtonPro` folder. Let Gradle sync. Android Studio creates the Gradle wrapper if it is missing.
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is `app/build/outputs/apk/debug/app-debug.apk`.
4. For a signed release build, use **Build > Generate Signed App Bundle / APK**.

Command line (after a wrapper exists): `./gradlew assembleDebug`

## Install and test on a Redmi / Xiaomi / HyperOS phone

1. Settings > About phone > tap **HyperOS / MIUI version** 7 times to enable Developer options.
2. Developer options > enable **USB debugging** and **Install via USB** (if shown).
3. Copy `app-debug.apk` to the phone and install it. Allow "Install unknown apps" for your file manager when asked.
4. Open **FIRE BUTTON PRO**. Allow **notifications** when asked.
5. Tap ⋮ > **Permissions & setup** and do the following:
   - **Display over other apps**: turn it ON for FIRE BUTTON PRO.
   - **Battery**: set to **No restrictions**.
   - **Autostart**: turn it ON.
   - **App info**: under other permissions, allow **Display pop-up windows while running in the background** and **Show notifications**.
6. Set the size, colour and transparency, then press **▶ START**. The fire button should appear above other apps.
7. Open a different app or a game and check that the button stays visible.
8. Test LOCK (the button shows LOCKED and can't be dragged), HIDE, and **■ STOP**. STOP must remove both the button and the notification.
9. Close the app with the back button. The notification should stay, and the overlay should still work. Then reopen the app and check that the size, colour and transparency values were kept.
10. Reboot, then check whether the app needs to be started again. HyperOS may need Autostart enabled before this works.

If it fails, capture the logs with `adb logcat -s FireButton:* OverlayService:* AndroidRuntime:E` (or filter by package name) and send them to me.

## Known limits

- Overlays are not guaranteed in every game. Games or apps that set FLAG_SECURE, or that hide overlays, will cover the button or hide it.
- MIUI / HyperOS can use its own game-mode or floating-window rules. If the button disappears in a game, check the "Display pop-up windows" and battery settings above.
- The app cannot control or read the screen, and it does not send taps or shots to any game.
- Android may stop the service after a force-stop or a reboot. Open the app and press START again.
- Google Play requires an accessibility-service-free design. This project uses none.
