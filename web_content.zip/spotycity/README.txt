SPOTYCITY JBL - vRPex - v1.2.1

INSTALACAO
1. Coloque a pasta spotycity em resources/[local]/.
2. Baixe o recurso xsound (Xogy/xsound) e coloque-o como pasta separada resources/[local]/xsound/.
3. No server.cfg, use nesta ordem:
   ensure xsound
   ensure spotycity

IMPORTANTE SOBRE YOUTUBE
- O painel aceita links youtube.com e youtu.be.
- O recurso envia links do YouTube ao xsound para tentar reproduzir. Alguns vídeos podem bloquear a reprodução incorporada; por isso, nem todos os links são garantidos.
- Este pacote NÃO inclui os arquivos do xsound; ele é uma dependência separada.

COMANDOS
/som       abre o painel
/som on    liga o audio local
/som off   silencia o audio local
/som 1-100 ajusta o volume local
J          abre o painel
G          coloca a caixa no chao
Y          abre o painel em modo automotivo dentro do veiculo

PROP JBL
Arquivos mantidos em stream/PROP JBL/. O fxmanifest registra o YTYP. O client usa o nome `rojo_jblboombox`, inferido pelo nome dos arquivos; confirme o archetype interno com CodeWalker/no jogo. Se for diferente, ajuste MODELO_CAIXA no client.lua.

COMPORTAMENTO PLANEJADO
Quando a JBL estiver na mao, entrar no veiculo remove o objeto visual enquanto estiver dentro; ao sair, tenta recriar a JBL na mao. A caixa colocada no chao nao e removida por essa rotina.

TESTES
CORRECOES DESTA VERSAO
- O controle de volume do som 3D usa setVolumeMax.
- Iniciar música no modo automotivo não marca automaticamente a caixa portátil como desejada, evitando que ela reapareça na mão ao sair do veículo quando não foi criada.

LIMITACAO DE VALIDACAO
Os arquivos e chamadas foram revisados, mas este pacote não foi executado num servidor FiveM nesta sessão. Portanto, ainda é necessário testar a reprodução de áudio e confirmar o archetype do prop no servidor.
