local uiAberto = false
local caixa = nil
local caixaNoChao = false
local caixaDesejada = false
local estavaNoVeiculo = false
local somAtivo = false
local somId = nil
local meuVolume = 0.5
local meuSomLigado = true
local modoCarro = false
local ultimoUrl = nil
local distanciaSom = 25.0

local MODELO_CAIXA = `rojo_jblboombox` -- Nome do modelo configurado para o prop incluído.

local function aviso(msg)
    TriggerEvent('chat:addMessage', { args = { '^3[SpotyCity]^7', msg } })
end

local function xsoundDisponivel()
    if GetResourceState('xsound') ~= 'started' then
        aviso('O recurso xsound não está iniciado. Inicie-o antes do SpotyCity.')
        return false
    end
    return true
end

local function carregarModelo(model)
    if not IsModelInCdimage(model) or not IsModelValid(model) then return false end
    RequestModel(model)
    local limite = GetGameTimer() + 5000
    while not HasModelLoaded(model) and GetGameTimer() < limite do Wait(10) end
    return HasModelLoaded(model)
end

local function criarCaixaNaMao()
    caixaDesejada = true
    if DoesEntityExist(caixa) then
        if caixaNoChao then
            DeleteEntity(caixa)
        else
            return true
        end
    end
    if not carregarModelo(MODELO_CAIXA) then
        aviso('Não foi possível carregar o modelo da caixa.')
        return false
    end
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    caixa = CreateObject(MODELO_CAIXA, coords.x, coords.y, coords.z, true, true, false)
    if not DoesEntityExist(caixa) then return false end
    AttachEntityToEntity(caixa, ped, GetPedBoneIndex(ped, 57005),
        0.18, 0.02, -0.02, -90.0, 0.0, 0.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(MODELO_CAIXA)
    caixaNoChao = false
    return true
end

local function colocarNoChao()
    if not DoesEntityExist(caixa) then
        aviso('Você não está com a caixa. Inicie a música para criar uma.')
        return
    end
    DetachEntity(caixa, true, true)
    local ped = PlayerPedId()
    local coords = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.8, -1.0)
    SetEntityCoords(caixa, coords.x, coords.y, coords.z, false, false, false, true)
    PlaceObjectOnGroundProperly(caixa)
    FreezeEntityPosition(caixa, true)
    caixaNoChao = true
    caixaDesejada = false
    if somAtivo and somId then
        TriggerServerEvent('spotycity:atualizarPosicao', somId, GetEntityCoords(caixa))
    end
    aviso('Caixa colocada no chão.')
end

local function fecharPainel()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    uiAberto = false
end

local function abrirPainel()
    if uiAberto then fecharPainel(); return end
    uiAberto = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open' })
end

RegisterCommand('som', function(args)
    local sub = string.lower(args[1] or '')
    if sub == 'on' then
        meuSomLigado = true
        if somAtivo and somId then TriggerServerEvent('spotycity:pedirEstado', somId) end
        aviso('Seu áudio está ligado.')
    elseif sub == 'off' then
        meuSomLigado = false
        if somId then exports.xsound:Destroy(somId) end
        aviso('Seu áudio foi silenciado somente para você.')
    elseif tonumber(sub) then
        meuVolume = math.max(0.01, math.min(1.0, tonumber(sub) / 100.0))
        if somId and exports.xsound:soundExists(somId) then
            exports.xsound:setVolumeMax(somId, meuVolume)
        end
        aviso(('Seu volume está em %d%%.'):format(math.floor(meuVolume * 100)))
    else
        abrirPainel()
    end
end, false)

RegisterKeyMapping('som', 'Abrir painel SpotyCity', 'keyboard', 'J')
RegisterCommand('spotycity_caixa_chao', colocarNoChao, false)
RegisterKeyMapping('spotycity_caixa_chao', 'Colocar caixa de som no chão', 'keyboard', 'G')

RegisterCommand('spotycity_carro', function()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then
        aviso('Entre em um veículo para usar o modo automotivo.')
        return
    end
    modoCarro = true
    abrirPainel()
end, false)
RegisterKeyMapping('spotycity_carro', 'Abrir modo de som automotivo', 'keyboard', 'Y')

RegisterNUICallback('playMusic', function(data, cb)
    if not xsoundDisponivel() then cb({ ok = false, error = 'xsound_offline' }); return end
    local url = tostring(data.url or '')
    local ehYoutube = url:match('^https?://([%w%-]+%.)?youtube%.com/') or url:match('^https?://youtu%.be/')
    if url == '' or not ehYoutube then
        aviso('Cole um link válido do YouTube (youtube.com ou youtu.be).')
        cb({ ok = false })
        return
    end

    local ped = PlayerPedId()
    local coords
    local vehicle = 0
    if modoCarro and IsPedInAnyVehicle(ped, false) then
        vehicle = GetVehiclePedIsIn(ped, false)
        coords = GetEntityCoords(vehicle)
    else
        if not criarCaixaNaMao() then
            aviso('Não foi possível criar a caixa.')
            cb({ ok = false })
            return
        end
        coords = GetEntityCoords(ped)
    end

    ultimoUrl = url
    somAtivo = true
    somId = ('spotycity_%s'):format(GetPlayerServerId(PlayerId()))
    TriggerServerEvent('spotycity:solicitarSom', somId, url, { x = coords.x, y = coords.y, z = coords.z }, modoCarro, NetworkGetNetworkIdFromEntity(vehicle))
    fecharPainel()
    modoCarro = false
    cb({ ok = true })
end)

RegisterNUICallback('stopMusic', function(_, cb)
    if somId then TriggerServerEvent('spotycity:pararSom', somId) end
    somAtivo = false
    ultimoUrl = nil
    cb({ ok = true })
end)

RegisterNUICallback('close', function(_, cb)
    fecharPainel()
    cb({ ok = true })
end)

RegisterNetEvent('spotycity:iniciarSom', function(id, url, coords, isCar, vehicleNetId)
    if not xsoundDisponivel() or not meuSomLigado then return end
    if exports.xsound:soundExists(id) then exports.xsound:Destroy(id) end
    local pos = vector3(coords.x + 0.0, coords.y + 0.0, coords.z + 0.0)
    exports.xsound:PlayUrlPos(id, url, meuVolume, pos, true)
    exports.xsound:Distance(id, distanciaSom)
    if id == somId then
        somAtivo = true
        ultimoUrl = url
    end
end)

RegisterNetEvent('spotycity:pararSom', function(id)
    if GetResourceState('xsound') == 'started' and exports.xsound:soundExists(id) then exports.xsound:Destroy(id) end
    if id == somId then somAtivo = false end
end)

RegisterNetEvent('spotycity:posicaoSom', function(id, coords)
    if GetResourceState('xsound') == 'started' and exports.xsound:soundExists(id) then
        exports.xsound:Position(id, vector3(coords.x + 0.0, coords.y + 0.0, coords.z + 0.0))
    end
end)

-- Esconde a JBL dentro do veículo e volta a anexá-la à mão ao sair.
CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local dentro = IsPedInAnyVehicle(ped, false)
        if dentro then
            estavaNoVeiculo = true
            if DoesEntityExist(caixa) and not caixaNoChao then
                DeleteEntity(caixa)
                caixa = nil
            end
        elseif estavaNoVeiculo then
            estavaNoVeiculo = false
            if caixaDesejada and not caixaNoChao then
                caixa = nil
                criarCaixaNaMao()
            end
        elseif caixaDesejada and not caixaNoChao and not DoesEntityExist(caixa) then
            criarCaixaNaMao()
        end
    end
end)

-- Mantém a posição do som da caixa e atualiza periodicamente o servidor.
CreateThread(function()
    while true do
        Wait(1000)
        if somAtivo and somId then
            local coords = nil
            if DoesEntityExist(caixa) then
                coords = GetEntityCoords(caixa)
            else
                local ped = PlayerPedId()
                if IsPedInAnyVehicle(ped, false) then
                    coords = GetEntityCoords(GetVehiclePedIsIn(ped, false))
                else
                    coords = GetEntityCoords(ped)
                end
            end
            TriggerServerEvent('spotycity:atualizarPosicao', somId, { x = coords.x, y = coords.y, z = coords.z })
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        SetNuiFocus(false, false)
        if DoesEntityExist(caixa) then DeleteEntity(caixa) end
    end
end)
