local sons = {}

RegisterNetEvent('spotycity:solicitarSom', function(id, url, coords, modoCarro, vehicleNetId)
    local src = source
    if type(id) ~= 'string' or type(url) ~= 'string' or type(coords) ~= 'table' then return end
    if #url > 500 or not url:match('^https?://') then return end
    -- Cada cliente controla o próprio volume localmente.
    sons[id] = {
        url = url,
        coords = { x = tonumber(coords.x) or 0, y = tonumber(coords.y) or 0, z = tonumber(coords.z) or 0 },
        owner = src,
        modoCarro = modoCarro == true,
        vehicleNetId = tonumber(vehicleNetId) or 0
    }
    TriggerClientEvent('spotycity:iniciarSom', -1, id, url, sons[id].coords, sons[id].modoCarro, sons[id].vehicleNetId)
end)

RegisterNetEvent('spotycity:atualizarPosicao', function(id, coords)
    local src = source
    if type(id) ~= 'string' or type(coords) ~= 'table' then return end
    local som = sons[id]
    if not som or som.owner ~= src then return end
    som.coords = { x = tonumber(coords.x) or 0, y = tonumber(coords.y) or 0, z = tonumber(coords.z) or 0 }
    TriggerClientEvent('spotycity:posicaoSom', -1, id, som.coords)
end)

RegisterNetEvent('spotycity:pedirEstado', function(id)
    local som = sons[id]
    if som then
        TriggerClientEvent('spotycity:iniciarSom', source, id, som.url, som.coords, som.modoCarro, som.vehicleNetId)
    end
end)

RegisterNetEvent('spotycity:pararSom', function(id)
    local src = source
    local som = sons[id]
    if som and som.owner == src then
        sons[id] = nil
        TriggerClientEvent('spotycity:pararSom', -1, id)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    for id, som in pairs(sons) do
        if som.owner == src then
            sons[id] = nil
            TriggerClientEvent('spotycity:pararSom', -1, id)
        end
    end
end)
