fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'SpotyCity'
description 'SpotyCity JBL - vRPex compatible, som portátil e automotivo'
version '1.2.1'

-- O recurso de áudio precisa estar instalado com o nome exato 'xsound'.
dependency 'xsound'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'stream/PROP JBL/rojo_jblboombox.ytyp',
    'stream/PROP JBL/rojo_jblboombox.ydr',
    'stream/PROP JBL/rojo_jblboombox.ytd',
    'stream/PROP JBL/rojo_jblboombox.ycd'
}

data_file 'DLC_ITYP_REQUEST' 'stream/PROP JBL/rojo_jblboombox.ytyp'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}
