from pathlib import Path
p=Path('/mnt/data/realistic_work/app/src/main/assets/index.html')
s=p.read_text()
old="""function background(){ctx.fillStyle='#080c23';ctx.fillRect(0,0,W,H);for(let s of stars){s.y+=.0007*s.s*(1+stage*.12);if(s.y>1)s.y=0;ctx.globalAlpha=.35+.65*Math.abs(Math.sin(frame*.025+s.a));circle(s.x*W,s.y*H,s.s,'#dce8ff')}ctx.globalAlpha=1;
ctx.fillStyle='rgba(99,80,180,.08)';ctx.beginPath();ctx.ellipse(W*.5,H*.52,W*.48,H*.18,0,0,Math.PI*2);ctx.fill();}
"""
new="""function background(){
 // Deep-space base with layered nebula haze
 const base=ctx.createLinearGradient(0,0,0,H);base.addColorStop(0,'#050916');base.addColorStop(.52,'#10172d');base.addColorStop(1,'#070b19');ctx.fillStyle=base;ctx.fillRect(0,0,W,H);
 const nebula=ctx.createRadialGradient(W*.22,H*.34,2,W*.22,H*.34,Math.max(W,H)*.72);nebula.addColorStop(0,'rgba(76,75,151,.24)');nebula.addColorStop(.42,'rgba(42,63,115,.12)');nebula.addColorStop(1,'rgba(5,9,22,0)');ctx.fillStyle=nebula;ctx.fillRect(0,0,W,H);
 const haze=ctx.createRadialGradient(W*.82,H*.62,0,W*.82,H*.62,Math.max(W,H)*.48);haze.addColorStop(0,'rgba(20,116,143,.12)');haze.addColorStop(1,'rgba(5,9,22,0)');ctx.fillStyle=haze;ctx.fillRect(0,0,W,H);
 // Distant ringed planet, kept subtle behind combat
 const px=W*.82,py=H*.23,pr=Math.min(W,H)*.105;
 ctx.save();ctx.translate(px,py);ctx.rotate(-.24);ctx.strokeStyle='rgba(132,174,211,.22)';ctx.lineWidth=Math.max(3,pr*.13);ctx.beginPath();ctx.ellipse(0,0,pr*1.85,pr*.48,0,Math.PI,Math.PI*2);ctx.stroke();
 const pg=ctx.createRadialGradient(-pr*.38,-pr*.42,pr*.05,0,0,pr*1.2);pg.addColorStop(0,'#91a9b8');pg.addColorStop(.32,'#526d88');pg.addColorStop(.72,'#263d5c');pg.addColorStop(1,'#101a31');ctx.fillStyle=pg;ctx.beginPath();ctx.arc(0,0,pr,0,Math.PI*2);ctx.fill();ctx.save();ctx.beginPath();ctx.arc(0,0,pr,0,Math.PI*2);ctx.clip();ctx.globalAlpha=.2;for(let k=0;k<7;k++){ctx.fillStyle=k%2?'#b7c6c9':'#172d4b';ctx.beginPath();ctx.ellipse(-pr*.2,(-.75+k*.25)*pr,pr*(.8-k*.045),pr*.08,0,0,Math.PI*2);ctx.fill();}ctx.restore();ctx.globalAlpha=1;ctx.strokeStyle='rgba(169,211,235,.25)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,0,pr*1.85,pr*.48,0,0,Math.PI);ctx.stroke();ctx.restore();
 // Three depth layers of stars
 for(let s of stars){s.y+=.00045*s.s*(1+stage*.12);if(s.y>1)s.y=0;const tw=.35+.65*Math.abs(Math.sin(frame*.018+s.a));ctx.globalAlpha=tw*(s.s>1.7?.9:.55);circle(s.x*W,s.y*H,s.s,s.s>1.7?'#ffffff':'#b9d5f5');if(s.s>1.85&&tw>.92){ctx.strokeStyle='rgba(205,231,255,.45)';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(s.x*W-3,s.y*H);ctx.lineTo(s.x*W+3,s.y*H);ctx.moveTo(s.x*W,s.y*H-3);ctx.lineTo(s.x*W,s.y*H+3);ctx.stroke();}}
 ctx.globalAlpha=1;
 // faint atmospheric light at the bottom edge
 const rim=ctx.createLinearGradient(0,H*.78,0,H);rim.addColorStop(0,'rgba(20,55,90,0)');rim.addColorStop(1,'rgba(26,79,115,.12)');ctx.fillStyle=rim;ctx.fillRect(0,H*.78,W,H*.22);
}
"""
if old not in s: raise SystemExit('background block not found')
s=s.replace(old,new)
# replace weapon shot drawing loop with glowing energy bolts
old="""for(let i=shots.length-1;i>=0;i--){let b=shots[i];b.x+=b.vx;b.y+=b.vy;ctx.fillStyle=b.color;ctx.fillRect(b.x-3,b.y-11,6,17);if(b.y<-20||b.x<0||b.x>W)shots.splice(i,1);} """
new="""for(let i=shots.length-1;i>=0;i--){let b=shots[i];b.x+=b.vx;b.y+=b.vy;ctx.save();ctx.shadowBlur=13;ctx.shadowColor=b.color;const beam=ctx.createLinearGradient(b.x,b.y-18,b.x,b.y+5);beam.addColorStop(0,'rgba(255,255,255,0)');beam.addColorStop(.35,b.color);beam.addColorStop(1,'#ffffff');ctx.fillStyle=beam;ctx.beginPath();ctx.moveTo(b.x-2.4,b.y+5);ctx.lineTo(b.x-1.2,b.y-17);ctx.quadraticCurveTo(b.x,b.y-21,b.x+1.2,b.y-17);ctx.lineTo(b.x+2.4,b.y+5);ctx.closePath();ctx.fill();ctx.restore();if(b.y<-24||b.x<0||b.x>W)shots.splice(i,1);} """
if old not in s:
 old=old.rstrip()
 new=new.rstrip()
s=s.replace(old,new)
# enemy projectiles as hot plasma orbs
s=s.replace("circle(b.x,b.y,5,'#ff6b9b');if(Math.hypot(b.x-player.x,b.y-player.y)<player.r+6)","ctx.save();ctx.shadowBlur=12;ctx.shadowColor='#ff5577';const eg=ctx.createRadialGradient(b.x-1,b.y-2,1,b.x,b.y,7);eg.addColorStop(0,'#fff4f6');eg.addColorStop(.35,'#ff9aab');eg.addColorStop(1,'#b51f54');ctx.fillStyle=eg;ctx.beginPath();ctx.arc(b.x,b.y,6,0,Math.PI*2);ctx.fill();ctx.strokeStyle='rgba(255,112,145,.45)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.x,b.y-5);ctx.lineTo(b.x-b.vx*2,b.y-b.vy*2);ctx.stroke();ctx.restore();if(Math.hypot(b.x-player.x,b.y-player.y)<player.r+6)")
# richer explosion particles with varied size
s=s.replace("function burst(x,y,color,n=12){for(let i=0;i<n;i++)particles.push({x,y,vx:(Math.random()-.5)*6,vy:(Math.random()-.5)*6,life:22+Math.random()*15,color});}","function burst(x,y,color,n=12){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,sp=1+Math.random()*6;particles.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:18+Math.random()*24,max:42,size:1.2+Math.random()*3.4,color});}particles.push({x,y,vx:0,vy:0,life:9,max:9,size:8,color:'#fff4cf'});}")
s=s.replace("ctx.globalAlpha=Math.max(0,p.life/35);circle(p.x,p.y,3,p.color);ctx.globalAlpha=1;", "ctx.globalAlpha=Math.max(0,p.life/(p.max||35));ctx.shadowBlur=8;ctx.shadowColor=p.color;circle(p.x,p.y,p.size||3,p.color);ctx.shadowBlur=0;ctx.globalAlpha=1;")
# subtle hull details on player ship
s=s.replace("// wing armor panels and illuminated trim\n ctx.strokeStyle='#70eaff';", "// segmented armor plating and engraved panel seams\n ctx.fillStyle='rgba(17,35,57,.62)';ctx.beginPath();ctx.moveTo(-31,8);ctx.lineTo(-18,4);ctx.lineTo(-11,10);ctx.lineTo(-27,14);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(31,8);ctx.lineTo(18,4);ctx.lineTo(11,10);ctx.lineTo(27,14);ctx.closePath();ctx.fill();\n ctx.strokeStyle='rgba(255,255,255,.48)';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-34,5);ctx.lineTo(-22,1);ctx.moveTo(34,5);ctx.lineTo(22,1);ctx.stroke();\n // wing armor panels and illuminated trim\n ctx.strokeStyle='#70eaff';")
s=s.replace("<title>MONSTORR PRESENTS · SHOOTING STAR 2.0</title>","<title>MONSTORR PRESENTS · SHOOTING STAR 2.5 REAL SPACE</title>")
s=s.replace("<b>GALACTIC EDITION 2.0</b> · Defend the galaxy!", "<b>REAL SPACE EDITION 2.5</b> · Defend the galaxy!")
s=s.replace("15 stages · Titan-class warships · 5 weapons · Ship upgrades · Daily rewards", "15 stages · cinematic space visuals · warships · 5 weapons · upgrades")
s=s.replace("15 stages · armored enemy fleets · titan-class dreadnought bosses · 5 weapons", "15 stages · cinematic nebula & planet backdrop · armored fleets · dreadnought bosses · 5 weapons")
p.write_text(s)
