GAME TURBO — Prototype
======================

Contents
- index.html: responsive, landscape-oriented multi-page gaming dashboard prototype.

Included
- Home dashboard and Turbo UI toggle
- Game library selection
- Performance preference page
- Tools page with session timer and notes
- Settings page with theme and persistent preferences
- About page
- Local state persistence via localStorage
- Navigation between pages without reloading the app

Important limitations
- This is a functional web UI prototype, not a native Android performance service.
- The Turbo button toggles the app's own game-mode UI state; it does not overclock CPU/GPU, force FPS, cool the device, block system notifications, or launch other apps.
- Real device stats and Android system integrations require native Android code, appropriate permissions, and testing on the target device.
- For a full-screen landscape APK, wrap this interface in an Android WebView project and set requestedOrientation to landscape in the Activity/manifest. Ensure local storage is enabled for the WebView.
- Browsers and WebViews can clear local data if app data is cleared or storage is disabled.
