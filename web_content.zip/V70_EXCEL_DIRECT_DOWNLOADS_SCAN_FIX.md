# V70 — Excel direct Downloads scan fix

Built from V69. The Android Excel import flow no longer queries MediaStore.Downloads, which could hang on some TECNO/Android builds. It requests READ_EXTERNAL_STORAGE and scans the public Downloads directory directly, showing an in-app file list. Version 2.36 / versionCode 40.
