const COUNTIES = [
  {
    "county": "Beaver",
    "provider": "Southwest Behavioral Health",
    "phone": "435-387-2671",
    "url": "https://sbhc.us/"
  },
  {
    "county": "Box Elder",
    "provider": "Bear River Mental Health",
    "phone": "435-752-0750",
    "url": "https://www.brmh.com/"
  },
  {
    "county": "Cache",
    "provider": "Bear River Mental Health",
    "phone": "435-752-0750",
    "url": "https://www.brmh.com/"
  },
  {
    "county": "Carbon",
    "provider": "Four Corners Community Behavioral Health",
    "phone": "435-637-7200",
    "url": "https://www.fourcorners.ws/"
  },
  {
    "county": "Daggett",
    "provider": "Northeastern Counseling Center",
    "phone": "435-789-6300",
    "url": "https://www.nccutah.org/"
  },
  {
    "county": "Davis",
    "provider": "Davis Behavioral Health",
    "phone": "801-773-7060",
    "url": "https://www.dbhutah.org/"
  },
  {
    "county": "Duchesne",
    "provider": "Northeastern Counseling Center",
    "phone": "435-789-6300",
    "url": "https://www.nccutah.org/"
  },
  {
    "county": "Emery",
    "provider": "Four Corners Community Behavioral Health",
    "phone": "435-637-7200",
    "url": "https://www.fourcorners.ws/"
  },
  {
    "county": "Garfield",
    "provider": "Southwest Behavioral Health",
    "phone": "435-387-2671",
    "url": "https://sbhc.us/"
  },
  {
    "county": "Grand",
    "provider": "Four Corners Community Behavioral Health",
    "phone": "435-637-7200",
    "url": "https://www.fourcorners.ws/"
  },
  {
    "county": "Iron",
    "provider": "Southwest Behavioral Health",
    "phone": "435-634-5600",
    "url": "https://sbhc.us/"
  },
  {
    "county": "Juab",
    "provider": "Central Utah Counseling Center",
    "phone": "435-283-8400",
    "url": "https://www.cucc.us/"
  },
  {
    "county": "Kane",
    "provider": "Southwest Behavioral Health",
    "phone": "435-387-2671",
    "url": "https://sbhc.us/"
  },
  {
    "county": "Millard",
    "provider": "Central Utah Counseling Center",
    "phone": "435-283-8400",
    "url": "https://www.cucc.us/"
  },
  {
    "county": "Morgan",
    "provider": "Weber Human Services",
    "phone": "801-625-3700",
    "url": "https://www.weberhs.net/"
  },
  {
    "county": "Piute",
    "provider": "Central Utah Counseling Center",
    "phone": "435-283-8400",
    "url": "https://www.cucc.us/"
  },
  {
    "county": "Rich",
    "provider": "Bear River Mental Health",
    "phone": "435-752-0750",
    "url": "https://www.brmh.com/"
  },
  {
    "county": "Salt Lake",
    "provider": "Salt Lake County Behavioral Health Services",
    "phone": "385-468-4707",
    "url": "https://www.slco.org/behavioral-health/"
  },
  {
    "county": "San Juan",
    "provider": "San Juan Counseling Center",
    "phone": "435-678-2992",
    "url": "https://www.sanjuancc.org/"
  },
  {
    "county": "Sanpete",
    "provider": "Central Utah Counseling Center",
    "phone": "435-283-8400",
    "url": "https://www.cucc.us/"
  },
  {
    "county": "Sevier",
    "provider": "Central Utah Counseling Center",
    "phone": "435-283-8400",
    "url": "https://www.cucc.us/"
  },
  {
    "county": "Summit",
    "provider": "UNI Park City Clinic",
    "phone": "435-658-5461",
    "url": "https://healthcare.utah.edu/uni"
  },
  {
    "county": "Tooele",
    "provider": "Optum Tooele County",
    "phone": "800-640-5349",
    "url": "https://tooele.optum.com/"
  },
  {
    "county": "Uintah",
    "provider": "Northeastern Counseling Center",
    "phone": "435-789-6300",
    "url": "https://www.nccutah.org/"
  },
  {
    "county": "Utah",
    "provider": "Wasatch Behavioral Health",
    "phone": "801-373-4760",
    "url": "https://www.wasatch.org/"
  },
  {
    "county": "Wasatch",
    "provider": "Wasatch County Family Clinic / Wasatch Behavioral Health",
    "phone": "435-654-3003",
    "url": "https://www.wasatch.org/"
  },
  {
    "county": "Washington",
    "provider": "Southwest Behavioral Health",
    "phone": "435-634-5600",
    "url": "https://sbhc.us/"
  },
  {
    "county": "Wayne",
    "provider": "Central Utah Counseling Center",
    "phone": "435-283-8400",
    "url": "https://www.cucc.us/"
  },
  {
    "county": "Weber",
    "provider": "Weber Human Services",
    "phone": "801-625-3700",
    "url": "https://www.weberhs.net/"
  }
];
