# Utah Peer Support Toolkit — Version 2.0

## Install
1. Download and unzip `utah-peer-support-toolkit-v2.zip`.
2. In Google Chrome, visit `chrome://extensions`.
3. Turn on Developer mode.
4. Choose **Load unpacked**.
5. Select the unzipped `utah-peer-support-toolkit-v2` folder (the folder containing `manifest.json`).
6. Click the extension icon. Version 2.0 opens in Chrome's side panel.

If Chrome reports that Side Panel is unavailable, update Chrome to a current version. The extension uses Manifest V3 and the Chrome Side Panel API.

## Features
- County directory for all 29 Utah counties, with local mental health authority, published phone number and provider website.
- Searchable statewide directory: crisis, housing, food, employment, treatment, naloxone and professional resources.
- Mental health and substance-use recovery peer support guides.
- Suicide/crisis response quick reference and Utah 988 / MCOT links.
- Naloxone and overdose response education linked to Utah DHHS.
- Person-led recovery goal, wellness plan and strengths worksheets; print or save to PDF.
- Blank session documentation template with copy/clear controls.
- Self-care and burnout reflection worksheet.
- Spanish-language crisis, 211, CPSS ethics and naloxone links and starter phrases.

## Privacy by design
- No client account, analytics, remote database, form submission or local persistence.
- Worksheet fields exist only in the open page. Closing/reloading the panel clears them.
- Documentation template is copied to the clipboard only when the user clicks Copy. It is not stored by the extension.
- Do not type client identifiers or confidential records into this tool. Actual documentation belongs in your employer's approved system.

## Safety / scope
This is a quick-reference and worksheet aid, not clinical guidance, a suicide risk assessment, treatment plan, medical instruction, legal advice or substitute for CPSS training, supervision, emergency services or agency protocols. In immediate danger or a medical emergency call 911. For Utah crisis support call/text 988. For suspected overdose call 911 and follow dispatcher instructions, product directions and current naloxone training.

## Sources / review notes
County authority names and numbers are transcribed from Utah DHHS's Local Mental Health Authority Location Map. Crisis, Spanish, 211, naloxone and CPSS resources link to Utah DHHS, Utah 988, Utah 211 and SAMHSA sources. Verify phone numbers, service hours, county coverage, eligibility and links before use and periodically thereafter. Resource lists change. Have Utah CPSS supervisors and practicing specialists review all wording and referral workflows before agency-wide distribution. This extension is not endorsed by Utah DHHS.

Resource review date in this build: November 23, 2026.
