const $=s=>document.querySelector(s);
let currentFilter="All";
function safeLink(url,label){return `<a href="${url}" target="_blank" rel="noopener noreferrer">${label} ↗</a>`;}
function initCounties(){
 const sel=$("#countySelect");
 COUNTIES.forEach(c=>{let o=document.createElement("option");o.value=c.county;o.textContent=c.county+" County";sel.appendChild(o);});
 sel.addEventListener("change",renderCounty);renderCounty();
}
function renderCounty(){
 const c=COUNTIES.find(x=>x.county===$("#countySelect").value)||COUNTIES[0];
 $("#countyCard").innerHTML=`<div class="eyebrow" style="color:#648291">${c.county.toUpperCase()} COUNTY</div><h3>${c.provider}</h3><div class="big-phone">${c.phone}</div><p>Local mental health authority / county provider listing. Ask about eligibility, access, peer services, crisis options and substance-use treatment.</p><div class="button-row"><a class="btn" href="tel:${c.phone.replace(/[^0-9]/g,'')}">Call provider</a>${safeLink(c.url,"Provider website")}</div>`;
}
function initResources(){
 const groups=["All",...new Set(RESOURCES.map(r=>r.group))];
 const f=$("#resourceFilters");
 groups.forEach(g=>{const b=document.createElement("button");b.className="chip"+(g==="All"?" active":"");b.textContent=g;b.onclick=()=>{currentFilter=g;[...f.children].forEach(x=>x.classList.toggle("active",x.textContent===g));renderResources();};f.appendChild(b);});
 $("#resourceSearch").addEventListener("input",renderResources);renderResources();
}
function renderResources(){
 const q=$("#resourceSearch").value.toLowerCase().trim();
 const items=RESOURCES.filter(r=>(currentFilter==="All"||r.group===currentFilter)&&(`${r.name} ${r.detail} ${r.group}`).toLowerCase().includes(q));
 $("#resourceList").innerHTML=items.length?items.map(r=>`<article class="resource"><div class="group">${r.group}</div><h3>${r.name}</h3><p>${r.detail}</p>${safeLink(r.url,"Open resource")}${r.phone?`<a class="phone" href="tel:${r.phone.replace(/[^0-9+]/g,'')}">Call ${r.phone}</a>`:""}</article>`).join(""):'<p class="note">No results. Try a different search term or choose All.</p>';
}
document.querySelectorAll(".navbtn").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".navbtn").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".view").forEach(x=>x.classList.toggle("active",x.id===b.dataset.view));}));
function printSheet(which){
 const titles={goal:"My recovery goal & next steps",plan:"My wellness & support plan",strengths:"Strengths & progress reflection",burnout:"Peer specialist self-care reflection"};
 const ids={goal:["w_matters","w_goal","w_step","w_support","w_barrier","w_checkin","w_success"],plan:["p_ground","p_people","p_signs","p_steps","p_crisis","p_know"],strengths:["s_handled","s_strength","s_support","s_forward"],burnout:["b_energy","b_boundary","b_consult","b_action"]};
 const labels={w_matters:"What matters to me right now?",w_goal:"My goal (in my words)",w_step:"One small step I want to try",w_support:"Who or what could support me?",w_barrier:"What might get in the way, and what could help?",w_checkin:"When would I like to check in on this?",w_success:"How will I know this step helped?",p_ground:"Things that help me feel grounded",p_people:"People, places or supports I choose to contact",p_signs:"Early signs I may need extra support",p_steps:"Steps I want to take when things feel harder",p_crisis:"Professional / crisis supports",p_know:"What I want supporters to know",s_handled:"Something I handled, even if difficult",s_strength:"Strengths I used",s_support:"Support or connection that mattered",s_forward:"What I want to carry forward",b_energy:"What is taking the most energy from me?",b_boundary:"What boundary or support could help?",b_consult:"Who can I consult or connect with?",b_action:"One small action I will take for myself"};
 const vals=ids[which].map(id=>({label:labels[id],value:$("#"+id).value}));
 const w=window.open("","_blank","width=800,height=900"); if(!w){alert("Please allow pop-ups to print the worksheet.");return;}
 w.document.write(`<html><head><title>${titles[which]}</title><style>body{font:14px Arial;padding:35px;color:#111}h1{font-size:22px}p{color:#555;font-size:12px}.field{margin:18px 0}.label{font-weight:bold;margin-bottom:5px}.line{min-height:55px;border-bottom:1px solid #aaa;white-space:pre-wrap;padding:5px 0}@media print{button{display:none}}</style></head><body><h1>${titles[which]}</h1><p>Utah Peer Support Toolkit • Person-led worksheet • Complete only if the person chooses.</p>${vals.map(v=>`<div class="field"><div class="label">${v.label}</div><div class="line">${escapeHtml(v.value)||"&nbsp;"}</div></div>`).join("")}<p>Keep completed worksheets only as agreed with the person and in accordance with agency policy. Do not leave identifying information unsecured.</p><button onclick="window.print()">Print / Save as PDF</button></body></html>`);w.document.close();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function copyTemplate(){
 const ids=["n_date","n_focus","n_support","n_response","n_next","n_follow"];
 const labels=["Session date","Person's stated focus / goal","Peer support provided","Person's response / strengths / choices","Next step chosen by the person","Consultation / follow-up per agency policy"];
 const txt=ids.map((id,i)=>labels[i]+":\n"+$("#"+id).value).join("\n\n");
 navigator.clipboard.writeText(txt).then(()=>alert("Template copied to clipboard. It was not saved in this extension.")).catch(()=>alert("Clipboard access was blocked. Select and copy the fields manually."));
}
function clearTemplate(){["n_date","n_focus","n_support","n_response","n_next","n_follow"].forEach(id=>$("#"+id).value="");}
initCounties();initResources();