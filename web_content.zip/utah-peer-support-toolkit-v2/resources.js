const RESOURCES = [
  {
    "group": "Crisis & safety",
    "name": "Utah 988 Crisis Line",
    "detail": "Free, confidential, 24/7 support for mental health, suicide, emotional distress and substance-use crises. Call or text 988.",
    "phone": "988",
    "url": "https://988.utah.gov/"
  },
  {
    "group": "Crisis & safety",
    "name": "Spanish-language suicide & crisis line",
    "detail": "Utah DHHS lists a Spanish-language crisis line. Call 1-888-628-9454. 988 also has interpreter access.",
    "phone": "1-888-628-9454",
    "url": "https://dhhs.utah.gov/contacts/"
  },
  {
    "group": "Crisis & safety",
    "name": "Emergency medical response",
    "detail": "For immediate danger, life-threatening injury, suspected overdose or urgent medical emergency, call 911.",
    "phone": "911",
    "url": "https://988.utah.gov/help-for-me/"
  },
  {
    "group": "Crisis & safety",
    "name": "Mobile Crisis Outreach Teams (MCOT)",
    "detail": "Free face-to-face crisis response teams are available statewide. Call 988 to request a team; teams can meet in any Utah county. Interpreter access is available.",
    "phone": "988",
    "url": "https://988.utah.gov/help-for-me/"
  },
  {
    "group": "Crisis & safety",
    "name": "Youth Stabilization & Mobile Response",
    "detail": "For children, youth and families. Utah DHHS lists the SafeUT / SAFE-FAM pathway; confirm current eligibility and service details on the official page.",
    "phone": "1-833-723-3326",
    "url": "https://sumh.utah.gov/services/treatment/child-mental-health/"
  },
  {
    "group": "Crisis & safety",
    "name": "Utah Warm Line",
    "detail": "Peer support from certified peer support specialists for people navigating personal struggles. Confirm current hours before sharing.",
    "phone": "1-833-773-2588",
    "url": "https://dhhs.utah.gov/contacts/"
  },
  {
    "group": "Basic needs",
    "name": "Utah 211",
    "detail": "Free, confidential statewide navigation for housing, food, utilities, employment, transportation, health and community supports. Phone, text, chat and online search options.",
    "phone": "211 or 888-826-9790",
    "url": "https://211utah.org/"
  },
  {
    "group": "Basic needs",
    "name": "Utah 211 housing assistance",
    "detail": "Search emergency shelter, transitional housing, rental and utility assistance, and supportive housing options.",
    "url": "https://211utah.org/resources/housing-resources/"
  },
  {
    "group": "Basic needs",
    "name": "Utah 211 county printable resource lists",
    "detail": "Current county-specific resource lists, including Spanish-language lists for many counties. Lists are updated; use the live database or call 211 for the most current information.",
    "url": "https://211utah.org/printable-resource-lists/"
  },
  {
    "group": "Basic needs",
    "name": "Utah Department of Workforce Services",
    "detail": "Employment services, job search, training, unemployment and related support.",
    "url": "https://jobs.utah.gov/"
  },
  {
    "group": "Treatment & recovery",
    "name": "Utah county behavioral health authorities",
    "detail": "Official county map and contact information for local mental health and substance-use treatment authorities. Services vary by county and eligibility.",
    "url": "https://sumh.utah.gov/contact/location-map/"
  },
  {
    "group": "Treatment & recovery",
    "name": "SAMHSA FindTreatment.gov",
    "detail": "Search for mental health and substance-use treatment providers across the United States.",
    "url": "https://findtreatment.gov/"
  },
  {
    "group": "Treatment & recovery",
    "name": "Utah CPSS certification, ethics & training",
    "detail": "Official Utah DHHS information on CPSS role, certification, Code of Ethics, training and professional guidance. Includes a Spanish Code of Ethics link.",
    "url": "https://sumh.utah.gov/education/certification/peersupportspecialists/"
  },
  {
    "group": "Treatment & recovery",
    "name": "Utah Association of Peer Support Specialists",
    "detail": "Professional development and peer workforce support.",
    "url": "https://www.uapss.org/"
  },
  {
    "group": "Overdose prevention",
    "name": "Utah Naloxone / Stop the Opidemic",
    "detail": "Utah DHHS naloxone information, access options and overdose-response education. Call a pharmacy before visiting to confirm stock.",
    "url": "https://opidemic.utah.gov/naloxone/"
  },
  {
    "group": "Overdose prevention",
    "name": "Utah naloxone support and training",
    "detail": "Information about naloxone access and community support. Naloxone is available from Utah pharmacies without a prescription; cost and stock vary.",
    "url": "https://opidemic.utah.gov/naloxone/naloxone-support/"
  },
  {
    "group": "Overdose prevention",
    "name": "Utah overdose response resources (English & Spanish)",
    "detail": "Official overdose education resources, including Spanish-language naloxone materials.",
    "url": "https://opidemic.utah.gov/resources/"
  },
  {
    "group": "Spanish-language support",
    "name": "Utah 211 — servicios en español",
    "detail": "Utah 211 is available in multiple languages. Use the website, call 211, or ask for a Spanish-speaking navigator / interpreter.",
    "phone": "211",
    "url": "https://211utah.org/"
  },
  {
    "group": "Spanish-language support",
    "name": "Utah CPSS Código de Ética",
    "detail": "Utah DHHS CPSS page includes the Spanish-language peer support Code of Ethics. Open the page and select the Spanish document.",
    "url": "https://sumh.utah.gov/education/certification/peersupportspecialists/"
  },
  {
    "group": "Spanish-language support",
    "name": "988 — ayuda en español",
    "detail": "Llame al 1-888-628-9454 para la línea de crisis en español indicada por Utah DHHS. También puede llamar o enviar un mensaje de texto al 988 y pedir un intérprete.",
    "phone": "1-888-628-9454",
    "url": "https://dhhs.utah.gov/contacts/"
  },
  {
    "group": "Spanish-language support",
    "name": "Naloxona — materiales en español",
    "detail": "Materiales oficiales de Utah sobre cómo reconocer una sobredosis y responder con naloxona en español.",
    "url": "https://opidemic.utah.gov/resources/"
  }
];
