AIM LOCK SIMULATOR — PROYEK ANDROID WEB LOKAL

Isi:
- index.html: simulator target bergerak, pengaturan, statistik, ekspor/impor JSON.
- config.json: konfigurasi awal contoh.

Menjalankan dari HP Android:
1. Unduh ZIP lalu ekstrak dengan aplikasi File Saya/pengelola arsip.
2. Buka index.html memakai Chrome atau browser yang mendukung file HTML lokal.
3. Jika tidak bisa dibuka, gunakan editor HTML Android dengan fitur Preview.
4. Tekan MULAI LATIHAN 60 DETIK.
5. Ubah sensitivitas, kecepatan target, bantuan bidikan, dan ukuran kepala.
6. Gunakan EKSPOR DATA JSON untuk menyimpan pengaturan atau IMPOR DATA JSON untuk memuatnya.

Catatan: Ini aplikasi web lokal, bukan APK native. Proyek kecil ini tidak memerlukan OBB.
Tidak membaca, mengubah, atau mengendalikan Free Fire.
