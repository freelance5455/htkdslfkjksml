# WBS WhatsApp Agendador 2.0

Painel web em português: contatos, agendamentos únicos/diários/semanais, chatbot por palavra-chave, histórico e integração com a WhatsApp Cloud API oficial.

## Requisitos
- Windows/macOS/Linux e Python 3.10+
- Conta Meta Business, aplicativo Meta e número habilitado na WhatsApp Cloud API
- Token de acesso com permissão de mensagens e Phone Number ID
- Para receber mensagens: hospedagem com URL HTTPS pública para `/webhook`, token de verificação e App Secret

## Instalação no Windows
1. Instale Python 3.10+ de https://www.python.org/downloads/ (marque Add Python to PATH).
2. Extraia o ZIP e abra o Prompt de Comando nessa pasta.
3. Execute:
   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   copy .env.example .env
   ```
4. Edite `.env` e informe `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_VERIFY_TOKEN`, `META_APP_SECRET` e uma chave secreta.
5. Execute `python app.py` e abra http://127.0.0.1:5000.

## macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edite .env e então:
python app.py
```

## Configurar a Meta
- Obtenha o token e o ID do número no painel WhatsApp da Meta.
- Configure callback `https://SEU-DOMINIO/webhook`; informe o mesmo `WHATSAPP_VERIFY_TOKEN`; assine os eventos de mensagens e status.
- O localhost não recebe webhooks da Meta: o chatbot requer servidor público HTTPS.
- Consulte a documentação oficial: https://developers.facebook.com/docs/whatsapp/cloud-api/overview/

## Limites e segurança
- O servidor deve permanecer ligado para executar agendamentos.
- A API oficial não automatiza uma sessão do WhatsApp Web; envia pela Cloud API.
- Fora da janela de atendimento de 24 horas, mensagens iniciadas pela empresa exigem modelo aprovado. O agendador suporta modelos sem variáveis dinâmicas e texto livre.
- O bot responde por palavra-chave; não é IA. O botão “parar” de exemplo não cria uma lista de bloqueio persistente, portanto implemente opt-out antes de produção.
- A resposta aceita pela Meta não garante entrega; os status chegam por webhook.
- Antes de publicar na internet, acrescente autenticação do painel, proteção CSRF, HTTPS, limitação de requisições, backups e gestão segura de segredos.
