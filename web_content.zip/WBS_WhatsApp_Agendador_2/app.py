import os, json, sqlite3, hmac, hashlib
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from flask import Flask, request, render_template, redirect, url_for, flash, jsonify
import requests
from dotenv import load_dotenv
from apscheduler.schedulers.background import BackgroundScheduler

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "troque-esta-chave")
DB = os.getenv("DATABASE_PATH", "wbs_whatsapp.db")
TZ = ZoneInfo(os.getenv("APP_TIMEZONE", "America/Sao_Paulo"))
VERSION = os.getenv("WHATSAPP_GRAPH_VERSION", "v23.0")
TOKEN = os.getenv("WHATSAPP_TOKEN", "").strip()
PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "").strip()
VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "troque-token-webhook")
APP_SECRET = os.getenv("META_APP_SECRET", "").strip()

def now(): return datetime.now(TZ)
def conn():
    c = sqlite3.connect(DB, timeout=20); c.row_factory = sqlite3.Row; return c
def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT UNIQUE NOT NULL,opted_in INTEGER NOT NULL DEFAULT 0,notes TEXT DEFAULT '',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS schedules(id INTEGER PRIMARY KEY,contact_id INTEGER NOT NULL,message TEXT DEFAULT '',send_at TEXT NOT NULL,recurrence TEXT NOT NULL DEFAULT 'once',template_name TEXT DEFAULT '',template_language TEXT DEFAULT 'pt_BR',status TEXT NOT NULL DEFAULT 'scheduled',last_error TEXT DEFAULT '',created_at TEXT NOT NULL,last_sent_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY,phone TEXT NOT NULL,direction TEXT NOT NULL,body TEXT DEFAULT '',status TEXT NOT NULL,wamid TEXT DEFAULT '',details TEXT DEFAULT '',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS bot_rules(id INTEGER PRIMARY KEY,keyword TEXT NOT NULL,reply TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
        """)
        if c.execute("SELECT COUNT(*) FROM bot_rules").fetchone()[0] == 0:
            c.executemany("INSERT INTO bot_rules(keyword,reply) VALUES(?,?)", [
                ("oi","Olá! Como podemos ajudar?"),("preço","Obrigado pelo interesse! Qual produto ou serviço procura?"),
                ("horário","Nosso atendimento funciona em horário comercial."),("parar","Entendido. Respeitaremos seu pedido.")
            ])
def log(phone,direction,body,status,wamid="",details=""):
    with conn() as c:
        c.execute("INSERT INTO history(phone,direction,body,status,wamid,details,created_at) VALUES(?,?,?,?,?,?,?)",
                  (phone,direction,body,status,wamid,details,now().isoformat()))
def api_send(phone, message=None, template=None, language="pt_BR"):
    if not TOKEN or not PHONE_ID: raise RuntimeError("Configure WHATSAPP_TOKEN e WHATSAPP_PHONE_NUMBER_ID no .env.")
    payload={"messaging_product":"whatsapp","to":phone}
    if template: payload.update(type="template",template={"name":template,"language":{"code":language or "pt_BR"}})
    else: payload.update(type="text",text={"preview_url":False,"body":message})
    r=requests.post(f"https://graph.facebook.com/{VERSION}/{PHONE_ID}/messages",
        headers={"Authorization":f"Bearer {TOKEN}","Content-Type":"application/json"},json=payload,timeout=25)
    data=r.json() if r.content else {}
    if not r.ok: raise RuntimeError(data.get("error",{}).get("message",f"Erro HTTP {r.status_code}"))
    mid=(data.get("messages") or [{}])[0].get("id","")
    log(phone,"outbound",message or f"[Modelo aprovado: {template}]","accepted_by_meta",mid,json.dumps(data,ensure_ascii=False))
def worker():
    with conn() as c:
        rows=c.execute("SELECT s.*,c.phone,c.opted_in FROM schedules s JOIN contacts c ON c.id=s.contact_id WHERE s.status='scheduled' AND s.send_at<=? ORDER BY s.send_at LIMIT 30",(now().isoformat(),)).fetchall()
    for s in rows:
        try:
            if not s["opted_in"]: raise RuntimeError("Contato sem consentimento registrado.")
            api_send(s["phone"],s["message"],s["template_name"],s["template_language"])
            with conn() as c:
                if s["recurrence"] in ("daily","weekly"):
                    dt=datetime.fromisoformat(s["send_at"])+timedelta(days=1 if s["recurrence"]=="daily" else 7)
                    c.execute("UPDATE schedules SET send_at=?,last_sent_at=?,last_error='' WHERE id=?",(dt.isoformat(),now().isoformat(),s["id"]))
                else: c.execute("UPDATE schedules SET status='sent',last_sent_at=?,last_error='' WHERE id=?",(now().isoformat(),s["id"]))
        except Exception as e:
            log(s["phone"],"outbound",s["message"] or s["template_name"],"failed","",str(e))
            with conn() as c: c.execute("UPDATE schedules SET status='error',last_error=? WHERE id=?",(str(e)[:800],s["id"]))
@app.get("/")
def home():
    with conn() as c:
        contacts=c.execute("SELECT * FROM contacts ORDER BY name").fetchall()
        schedules=c.execute("SELECT s.*,c.name,c.phone FROM schedules s JOIN contacts c ON c.id=s.contact_id ORDER BY s.send_at DESC LIMIT 100").fetchall()
        history=c.execute("SELECT * FROM history ORDER BY id DESC LIMIT 100").fetchall()
        rules=c.execute("SELECT * FROM bot_rules ORDER BY id DESC").fetchall()
    return render_template("index.html",contacts=contacts,schedules=schedules,history=history,rules=rules,configured=bool(TOKEN and PHONE_ID),timezone=str(TZ))
@app.post("/contacts")
def contact_add():
    name=request.form.get("name","").strip(); phone="".join(x for x in request.form.get("phone","") if x.isdigit())
    try:
        if not name or not 10<=len(phone)<=15: raise ValueError("Informe nome e telefone com código do país (10 a 15 dígitos).")
        with conn() as c: c.execute("INSERT INTO contacts(name,phone,opted_in,notes,created_at) VALUES(?,?,?,?,?)",(name,phone,int(request.form.get("opted_in")=="on"),request.form.get("notes","").strip(),now().isoformat()))
        flash("Contato salvo.","success")
    except Exception as e: flash(str(e) if "UNIQUE" not in str(e) else "Telefone já cadastrado.","error")
    return redirect(url_for("home"))
@app.post("/contacts/<int:cid>/delete")
def contact_delete(cid):
    with conn() as c: c.execute("DELETE FROM schedules WHERE contact_id=?",(cid,)); c.execute("DELETE FROM contacts WHERE id=?",(cid,))
    flash("Contato excluído.","success"); return redirect(url_for("home"))
@app.post("/schedules")
def schedule_add():
    try:
        cid=int(request.form["contact_id"]); dt=datetime.fromisoformat(request.form["send_at"])
        if dt.tzinfo is None: dt=dt.replace(tzinfo=TZ)
        dt=dt.astimezone(TZ); rec=request.form.get("recurrence","once")
        if rec not in ("once","daily","weekly"): rec="once"
        msg=request.form.get("message","").strip(); tpl=request.form.get("template_name","").strip(); lang=request.form.get("template_language","pt_BR").strip() or "pt_BR"
        if dt<=now(): raise ValueError("Escolha data e hora futuras.")
        if not msg and not tpl: raise ValueError("Informe uma mensagem ou o nome de um modelo aprovado.")
        with conn() as c:
            ct=c.execute("SELECT * FROM contacts WHERE id=?",(cid,)).fetchone()
            if not ct: raise ValueError("Contato não encontrado.")
            if not ct["opted_in"]: raise ValueError("Registre o consentimento do contato antes de agendar.")
            c.execute("INSERT INTO schedules(contact_id,message,send_at,recurrence,template_name,template_language,status,created_at) VALUES(?,?,?,?,?,?,?,?)",(cid,msg,dt.isoformat(),rec,tpl,lang,"scheduled",now().isoformat()))
        flash("Agendamento salvo. O servidor precisa ficar ligado.","success")
    except Exception as e: flash(str(e),"error")
    return redirect(url_for("home"))
@app.post("/schedules/<int:sid>/cancel")
def schedule_cancel(sid):
    with conn() as c: c.execute("UPDATE schedules SET status='cancelled' WHERE id=? AND status='scheduled'",(sid,))
    flash("Agendamento cancelado se ainda estava pendente.","success"); return redirect(url_for("home"))
@app.post("/rules")
def rule_add():
    k=request.form.get("keyword","").strip().lower(); reply=request.form.get("reply","").strip()
    if k and reply:
        with conn() as c: c.execute("INSERT INTO bot_rules(keyword,reply,enabled) VALUES(?,?,1)",(k,reply))
        flash("Regra adicionada.","success")
    else: flash("Preencha palavra-chave e resposta.","error")
    return redirect(url_for("home"))
@app.post("/rules/<int:rid>/toggle")
def rule_toggle(rid):
    with conn() as c: c.execute("UPDATE bot_rules SET enabled=1-enabled WHERE id=?",(rid,))
    return redirect(url_for("home"))
def signature_ok(raw):
    if not APP_SECRET: return True
    sig=request.headers.get("X-Hub-Signature-256","")
    expected="sha256="+hmac.new(APP_SECRET.encode(),raw,hashlib.sha256).hexdigest()
    return hmac.compare_digest(sig,expected)
@app.get("/webhook")
def webhook_get():
    if request.args.get("hub.mode")=="subscribe" and request.args.get("hub.verify_token")==VERIFY_TOKEN: return request.args.get("hub.challenge",""),200
    return "Verificação inválida",403
@app.post("/webhook")
def webhook_post():
    raw=request.get_data()
    if not signature_ok(raw): return "Assinatura inválida",403
    data=request.get_json(silent=True) or {}
    try:
        for entry in data.get("entry",[]):
          for change in entry.get("changes",[]):
            val=change.get("value",{})
            for m in val.get("messages",[]):
                phone=m.get("from",""); typ=m.get("type",""); body=m.get("text",{}).get("body","") if typ=="text" else ""
                if not phone: continue
                log(phone,"inbound",body or f"[Mensagem tipo {typ}]","received",m.get("id",""))
                if body:
                    with conn() as c: rules=c.execute("SELECT keyword,reply FROM bot_rules WHERE enabled=1 ORDER BY LENGTH(keyword) DESC").fetchall()
                    reply=next((r["reply"] for r in rules if r["keyword"].lower() in body.lower()),None)
                    if reply:
                        try: api_send(phone,reply)
                        except Exception as e: log(phone,"outbound",reply,"failed","",str(e))
            for st in val.get("statuses",[]):
                with conn() as c: c.execute("UPDATE history SET status=?,details=? WHERE wamid=?",(st.get("status","unknown"),json.dumps(st.get("errors",[]),ensure_ascii=False),st.get("id","")))
    except Exception: app.logger.exception("Erro ao processar webhook")
    return jsonify(ok=True)
@app.get("/health")
def health(): return jsonify(ok=True,configured=bool(TOKEN and PHONE_ID),timezone=str(TZ))
init_db()
scheduler=BackgroundScheduler(timezone=TZ)
scheduler.add_job(worker,"interval",seconds=15,id="send_due",max_instances=1,coalesce=True)
scheduler.start()
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")),debug=False)
