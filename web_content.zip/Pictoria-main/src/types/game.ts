export type GameMode = 'word_puzzle' | 'sliding_tiles' | 'mystery_scratch';

export type Language = 'ar' | 'en' | 'fr';

export interface PuzzleLevel {
  id: number;
  mode: GameMode;
  imageUrl: string;
  category: {
    ar: string;
    en: string;
    fr: string;
  };
  // For word guess mode:
  answer: {
    ar: string;
    en: string;
    fr: string;
  };
  clue: {
    ar: string;
    en: string;
    fr: string;
  };
  difficulty: 'easy' | 'medium' | 'hard';
  gridSize?: number; // for sliding tiles, e.g. 3 for 3x3
  isPremium?: boolean; // True for VIP expansion levels (101-200)
}

export interface UserProgress {
  coins: number;
  hintsRemaining: number;
  unlockedLevel: number;
  levelScores: Record<number, { stars: number; bestTime: number; completedAt: string }>;
  streakDays: number;
  lastDailyClaim: string | null;
  unlockedAchievements: string[];
  googlePlayId: string;
  gamerTag: string;
  isPremiumUnlocked?: boolean; // Set to true when the $2.50 Google Play IAP is purchased
}

export interface Achievement {
  id: string;
  title: { ar: string; en: string; fr: string };
  desc: { ar: string; en: string; fr: string };
  icon: string;
  xp: number;
  targetCount: number;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar: string;
  score: number;
  level: number;
  isCurrentUser?: boolean;
}

export interface InAppProduct {
  productId: string;
  title: { ar: string; en: string; fr: string };
  description: { ar: string; en: string; fr: string };
  priceFormatted: string;
  priceAmountMicros: number;
  priceCurrencyCode: string;
  levelsCount: number;
  icon: string;
}
