import React from 'react';
import { Volume2, VolumeX, Maximize2, Minimize2, ArrowRight, ArrowLeft, Coins, Lightbulb, Globe, Grid } from 'lucide-react';
import { Language, PuzzleLevel } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface GameHUDProps {
  currentLevel: PuzzleLevel;
  totalLevels: number;
  score: number;
  coins: number;
  hintsRemaining: number;
  language: Language;
  onSetLanguage: (lang: Language) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onBackToMenu: () => void;
  onOpenLevelModal: () => void;
  onOpenHintModal: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  elapsedTime: number;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  currentLevel,
  totalLevels,
  score,
  coins,
  hintsRemaining,
  language,
  onSetLanguage,
  isMuted,
  onToggleMute,
  onBackToMenu,
  onOpenLevelModal,
  onOpenHintModal,
  isFullscreen,
  onToggleFullscreen,
  elapsedTime,
}) => {
  const t = TRANSLATIONS[language];
  const isRtl = language === 'ar';

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getDifficultyLabel = () => {
    if (currentLevel.difficulty === 'easy') return t.difficultyEasy;
    if (currentLevel.difficulty === 'medium') return t.difficultyMedium;
    return t.difficultyHard;
  };

  const getLevelDisplayText = () => {
    if (language === 'ar') {
      return `${t.levelSingle} ${currentLevel.id} ${t.of} ${totalLevels}`;
    }
    if (language === 'fr') {
      return `${t.levelSingle} ${currentLevel.id} ${t.of} ${totalLevels}`;
    }
    return `${t.levelSingle} ${currentLevel.id} ${t.of} ${totalLevels}`;
  };

  return (
    <header className="w-full h-14 bg-slate-900/90 border-b border-slate-800/80 px-4 flex items-center justify-between text-sm select-none z-30 shrink-0">
      {/* Left: Back button & Clickable Level Metadata */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={() => {
            sound.playClick();
            onBackToMenu();
          }}
          className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-750 text-slate-300 hover:text-white transition-colors"
          title={t.backToMenu}
          aria-label={t.backToMenu}
        >
          {isRtl ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
        </button>

        {/* Interactive Level button that opens Level Selection */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenLevelModal();
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-white font-bold text-xs tracking-wide border border-slate-700/80 hover:border-amber-400/50 transition-all active:scale-95 group"
          title={t.levels}
        >
          <Grid className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
          <span>{getLevelDisplayText()}</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-slate-400 hidden sm:flex">
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-amber-400/90 font-medium">{currentLevel.category[language]}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-500 font-mono">{getDifficultyLabel()}</span>
        </div>
      </div>

      {/* Center: Live Timer and Score in Tabular Numbers */}
      <div className="flex items-center gap-4 text-xs font-mono">
        <div className="flex items-center gap-1.5 text-slate-300">
          <span className="text-slate-500 font-sans">{t.time}:</span>
          <span className="tabular-nums font-bold text-slate-200">{formatTime(elapsedTime)}</span>
        </div>
        <span aria-hidden="true" className="text-slate-700">·</span>
        <div className="flex items-center gap-1.5 text-slate-300">
          <span className="text-slate-500 font-sans">{t.score}:</span>
          <span className="tabular-nums font-bold text-emerald-400">{score.toLocaleString()}</span>
        </div>
      </div>

      {/* Right: Coins, Hints, Audio, Fullscreen, Language */}
      <div className="flex items-center gap-2">
        {/* Coins indicator */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-mono font-bold">
          <Coins className="w-3.5 h-3.5 text-amber-400" />
          <span className="tabular-nums">{coins}</span>
        </div>

        {/* Hint button */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenHintModal();
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20 text-xs font-medium transition-all active:scale-95"
          title={t.useHint}
        >
          <Lightbulb className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">{t.hints}</span>
          <span className="font-mono tabular-nums text-cyan-200">({hintsRemaining})</span>
        </button>

        {/* Language selector toggle */}
        <div className="relative group">
          <button
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex items-center gap-1 text-xs"
            title="Language"
            aria-label="Language selection"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span className="uppercase font-mono text-[11px] font-bold">{language}</span>
          </button>
          <div className="absolute right-0 mt-1 w-24 bg-slate-900 border border-slate-700 rounded-lg shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity z-50 flex flex-col py-1">
            <button
              onClick={() => onSetLanguage('ar')}
              className={`px-3 py-1.5 text-xs text-right hover:bg-slate-800 transition-colors ${language === 'ar' ? 'text-amber-400 font-bold' : 'text-slate-300'}`}
            >
              العربية
            </button>
            <button
              onClick={() => onSetLanguage('en')}
              className={`px-3 py-1.5 text-xs text-left hover:bg-slate-800 transition-colors ${language === 'en' ? 'text-amber-400 font-bold' : 'text-slate-300'}`}
            >
              English
            </button>
            <button
              onClick={() => onSetLanguage('fr')}
              className={`px-3 py-1.5 text-xs text-left hover:bg-slate-800 transition-colors ${language === 'fr' ? 'text-amber-400 font-bold' : 'text-slate-300'}`}
            >
              Français
            </button>
          </div>
        </div>

        {/* Audio Mute button */}
        <button
          onClick={onToggleMute}
          className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          title={isMuted ? t.unmute : t.mute}
          aria-label={isMuted ? t.unmute : t.mute}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
        </button>

        {/* Fullscreen button */}
        <button
          onClick={onToggleFullscreen}
          className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors hidden md:flex"
          title={isFullscreen ? t.exitFullscreen : t.fullscreen}
          aria-label={isFullscreen ? t.exitFullscreen : t.fullscreen}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};
