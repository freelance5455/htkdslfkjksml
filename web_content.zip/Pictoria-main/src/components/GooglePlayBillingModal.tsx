import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, CheckCircle2, CreditCard, RefreshCw, Code2 } from 'lucide-react';
import { Language } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface GooglePlayBillingModalProps {
  language: Language;
  userEmail?: string;
  onSuccess: () => void;
  onOpenDevGuide: () => void;
  onClose: () => void;
}

export const GooglePlayBillingModal: React.FC<GooglePlayBillingModalProps> = ({
  language,
  userEmail = 'idrissjaune04@gmail.com',
  onSuccess,
  onOpenDevGuide,
  onClose,
}) => {
  const t = TRANSLATIONS[language];
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [purchaseSuccess, setPurchaseSuccess] = useState<boolean>(false);
  const [selectedPayment, setSelectedPayment] = useState<'card' | 'gpay'>('gpay');

  // Register native Android callbacks if running inside native Android WebView
  useEffect(() => {
    (window as unknown as { onGooglePlayPurchaseSuccess: (orderId: string) => void }).onGooglePlayPurchaseSuccess = () => {
      setIsProcessing(false);
      setPurchaseSuccess(true);
      sound.playVictory();
      setTimeout(() => {
        onSuccess();
      }, 1200);
    };

    (window as unknown as { onGooglePlayPurchaseFailed: (err: string) => void }).onGooglePlayPurchaseFailed = () => {
      setIsProcessing(false);
      sound.playError();
    };

    return () => {
      delete (window as unknown as { onGooglePlayPurchaseSuccess?: unknown }).onGooglePlayPurchaseSuccess;
      delete (window as unknown as { onGooglePlayPurchaseFailed?: unknown }).onGooglePlayPurchaseFailed;
    };
  }, [onSuccess]);

  const handleBuy = () => {
    sound.playClick();
    setIsProcessing(true);

    // If running inside Android WebView with native Google Play Billing interface
    const win = window as unknown as { AndroidBilling?: { purchasePremium: (id: string) => void } };
    if (win.AndroidBilling) {
      win.AndroidBilling.purchasePremium('pictora_premium_100_levels');
      return;
    }

    // Otherwise run real-time Google Play InAppBillingService flow simulation
    setTimeout(() => {
      setIsProcessing(false);
      setPurchaseSuccess(true);
      sound.playVictory();

      setTimeout(() => {
        onSuccess();
      }, 1400);
    }, 1500);
  };

  const handleRestore = () => {
    sound.playClick();
    setIsProcessing(true);

    const win = window as unknown as { AndroidBilling?: { restorePurchases: () => void } };
    if (win.AndroidBilling) {
      win.AndroidBilling.restorePurchases();
      return;
    }

    setTimeout(() => {
      setIsProcessing(false);
      setPurchaseSuccess(true);
      sound.playVictory();
      setTimeout(() => {
        onSuccess();
      }, 1000);
    }, 1000);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl overflow-hidden shadow-2xl flex flex-col text-slate-100"
      >
        {/* Google Play Billing Brand Header */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {/* Google Play Tri-color Logo */}
            <svg width="24" height="24" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7 5.5L25 20L7 34.5V5.5Z" fill="#00C3FF" />
              <path d="M25 20L31 15L7 5.5L25 20Z" fill="#00E676" />
              <path d="M7 34.5L31 25L25 20L7 34.5Z" fill="#FF3D00" />
              <path d="M31 15L35.5 17.5C37.5 18.5 37.5 21.5 35.5 22.5L31 25L25 20L31 15Z" fill="#FFD600" />
            </svg>
            <div>
              <h4 className="text-sm font-bold text-white tracking-wide">
                Google Play Store
              </h4>
              <p className="text-[11px] text-slate-400">
                In-App Billing v7 · {userEmail}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Developer Guide Button */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenDevGuide();
              }}
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-amber-400 hover:text-amber-300 transition-colors flex items-center gap-1 text-[11px] font-bold"
              title="كود الأندرويد وPlay Console"
            >
              <Code2 className="w-4 h-4" />
              <span className="hidden sm:inline">الكود وخطوات الدمج</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              disabled={isProcessing}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Product Details Card */}
        <div className="p-5 flex flex-col gap-4">
          <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/15 via-slate-850 to-slate-900 border border-amber-500/40 flex items-start justify-between gap-3 shadow-lg">
            <div>
              <span className="inline-block px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400 font-mono text-[10px] font-bold mb-1 border border-amber-500/30">
                {t.premiumBadge} · Non-Consumable
              </span>
              <h3 className="text-base font-bold text-white mb-1">
                {t.premiumTitle} (100 Levels)
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
                {t.premiumDesc}
              </p>
            </div>

            <div className="text-right shrink-0">
              <span className="block text-xl font-black text-amber-400 font-mono">
                $2.50
              </span>
              <span className="text-[10px] text-slate-400">
                {language === 'ar' ? 'دفعة واحدة لمدى الحياة' : 'One-time purchase'}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              {t.paymentMethod}
            </label>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={() => setSelectedPayment('gpay')}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                  selectedPayment === 'gpay'
                    ? 'bg-slate-800/90 border-emerald-500/80 text-white shadow-md'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-xs font-mono">
                    GPay
                  </div>
                  <div className="text-left rtl:text-right">
                    <p className="text-xs font-bold text-slate-200">Google Pay Balance</p>
                    <p className="text-[10px] text-slate-400">Available: $45.00 · {userEmail}</p>
                  </div>
                </div>
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedPayment === 'gpay' ? 'border-emerald-500 bg-emerald-500' : 'border-slate-600'}`}>
                  {selectedPayment === 'gpay' && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPayment('card')}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                  selectedPayment === 'card'
                    ? 'bg-slate-800/90 border-emerald-500/80 text-white shadow-md'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <div className="text-left rtl:text-right">
                    <p className="text-xs font-bold text-slate-200">Mastercard •••• 4821</p>
                    <p className="text-[10px] text-slate-400">Expires 09/28</p>
                  </div>
                </div>
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedPayment === 'card' ? 'border-emerald-500 bg-emerald-500' : 'border-slate-600'}`}>
                  {selectedPayment === 'card' && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                </div>
              </button>
            </div>
          </div>

          {/* Success Notification */}
          {purchaseSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2.5 animate-fadeIn">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{t.purchasedSuccess}</span>
            </div>
          )}

          {/* Actions: 1-Tap Buy & Restore */}
          <div className="flex flex-col gap-2.5 pt-2">
            <button
              onClick={handleBuy}
              disabled={isProcessing || purchaseSuccess}
              className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer ${
                purchaseSuccess
                  ? 'bg-emerald-600 text-white'
                  : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:brightness-110 text-slate-950 font-black shadow-emerald-500/20 active:scale-98'
              }`}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Google Play Processing...</span>
                </>
              ) : purchaseSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>{t.premiumUnlocked}</span>
                </>
              ) : (
                <>
                  <span>{t.buyWithGooglePlay} ($2.50)</span>
                </>
              )}
            </button>

            <button
              onClick={handleRestore}
              disabled={isProcessing}
              className="py-2 text-xs text-slate-400 hover:text-white transition-colors underline text-center"
            >
              {t.restorePurchases}
            </button>
          </div>

          {/* Google Play Protect Footnote */}
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 font-mono pt-1 border-t border-slate-800/80">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Secured & Verified by Google Play Protect</span>
          </div>
        </div>
      </div>
    </div>
  );
};
