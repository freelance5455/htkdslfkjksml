import React, { useState, useEffect } from 'react';
import { Smartphone, Maximize2 } from 'lucide-react';
import { Language } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface LandscapeNoticeProps {
  language: Language;
}

export const LandscapeNotice: React.FC<LandscapeNoticeProps> = ({ language }) => {
  const [isPortrait, setIsPortrait] = useState<boolean>(false);
  const t = TRANSLATIONS[language];

  useEffect(() => {
    const checkOrientation = () => {
      const isMobileSize = window.innerWidth < 850;
      const isTaller = window.innerHeight > window.innerWidth;
      setIsPortrait(isMobileSize && isTaller);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  const handleFullscreen = () => {
    sound.playClick();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    }
  };

  if (!isPortrait) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
      <div className="relative mb-6">
        <div className="w-20 h-20 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <Smartphone className="w-10 h-10 animate-bounce transform rotate-90" />
        </div>
      </div>

      <h3 className="text-xl font-bold text-white mb-2">
        {t.rotateScreen}
      </h3>
      <p className="text-sm text-slate-400 max-w-sm mb-6 leading-relaxed">
        {t.landscapeTip}
      </p>

      <button
        onClick={handleFullscreen}
        className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-amber-500/20"
      >
        <Maximize2 className="w-4 h-4" />
        <span>{t.fullscreen}</span>
      </button>
    </div>
  );
};
