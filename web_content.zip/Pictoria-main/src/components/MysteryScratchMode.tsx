import React, { useState } from 'react';
import { Eye, HelpCircle, CheckCircle2 } from 'lucide-react';
import { Language, PuzzleLevel } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface MysteryScratchModeProps {
  level: PuzzleLevel;
  language: Language;
  onSolve: () => void;
}

export const MysteryScratchMode: React.FC<MysteryScratchModeProps> = ({
  level,
  language,
  onSolve,
}) => {
  const t = TRANSLATIONS[language];
  const totalTiles = 16; // 4x4 grid
  const [revealedTiles, setRevealedTiles] = useState<number[]>([]);
  const [selectedGuess, setSelectedGuess] = useState<string | null>(null);
  const [isWrong, setIsWrong] = useState<boolean>(false);
  const [isSolved, setIsSolved] = useState<boolean>(false);

  // Generate 4 candidate choices: correct answer + 3 decoys
  const choices = React.useMemo(() => {
    const correct = level.answer[language];
    const decoysMap: Record<Language, string[]> = {
      ar: ['صحراء', 'سفينة', 'قصر', 'تاج', 'كوكب', 'شمس'],
      en: ['DESERT', 'CASTLE', 'PALACE', 'CROWN', 'STAR', 'MOON'],
      fr: ['DESERT', 'CHATEAU', 'PALAIS', 'COURONNE', 'ETOILE', 'LUNE'],
    };
    const list = decoysMap[language].filter((d) => d !== correct).slice(0, 3);
    const combined = [correct, ...list];
    // Shuffle
    return combined.sort(() => 0.5 - Math.random());
  }, [level, language]);

  const handleTileClick = (index: number) => {
    if (revealedTiles.includes(index) || isSolved) return;
    sound.playLetterTap();
    setRevealedTiles((prev) => [...prev, index]);
  };

  const handleRevealAll = () => {
    sound.playHint();
    setRevealedTiles(Array.from({ length: totalTiles }, (_, i) => i));
  };

  const handleGuess = (choice: string) => {
    setSelectedGuess(choice);
    if (choice === level.answer[language]) {
      setIsSolved(true);
      sound.playVictory();
      setTimeout(() => {
        onSolve();
      }, 700);
    } else {
      sound.playError();
      setIsWrong(true);
      setTimeout(() => {
        setIsWrong(false);
        setSelectedGuess(null);
      }, 600);
    }
  };

  return (
    <div className="w-full h-full flex flex-col md:flex-row items-center justify-center gap-6 p-3 md:p-6 max-w-5xl mx-auto overflow-hidden">
      {/* 4x4 Mystery Scratch Grid */}
      <div className="relative flex flex-col items-center">
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 md:w-80 md:h-80 bg-slate-900 border-4 border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
          {/* Base photo */}
          <img
            src={level.imageUrl}
            alt={level.category[language]}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />

          {/* 16 scratchable overlay tiles */}
          <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 gap-0.5 p-0.5">
            {Array.from({ length: totalTiles }).map((_, index) => {
              const isRevealed = revealedTiles.includes(index);
              return (
                <button
                  key={index}
                  onClick={() => handleTileClick(index)}
                  disabled={isRevealed || isSolved}
                  className={`w-full h-full transition-all duration-300 flex items-center justify-center ${
                    isRevealed
                      ? 'opacity-0 pointer-events-none'
                      : 'bg-gradient-to-br from-slate-800 to-slate-950 border border-slate-700/60 hover:from-amber-950/40 hover:to-slate-900 active:scale-95'
                  }`}
                >
                  {!isRevealed && (
                    <HelpCircle className="w-4 h-4 text-slate-500 opacity-60" />
                  )}
                </button>
              );
            })}
          </div>

          {isSolved && (
            <div className="absolute inset-0 bg-emerald-950/80 backdrop-blur-sm flex flex-col items-center justify-center text-emerald-300 animate-fadeIn z-20">
              <CheckCircle2 className="w-16 h-16 text-emerald-400 mb-2 animate-bounce" />
              <p className="font-bold text-lg">{t.congratulations}</p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 mt-3 text-xs text-slate-400 font-mono">
          <span>{t.tilesRevealed}:</span>
          <span className="text-amber-400 font-bold tabular-nums">
            {revealedTiles.length}/{totalTiles}
          </span>
        </div>
      </div>

      {/* Right: Guess & Choices */}
      <div className="flex flex-col items-center md:items-start gap-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl max-w-sm w-full">
        <div>
          <h3 className="font-bold text-white text-base mb-1">{level.category[language]}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{t.tapToReveal}</p>
        </div>

        {/* 4 Choices */}
        <div className="w-full flex flex-col gap-2">
          {choices.map((choice, i) => {
            const isSelected = selectedGuess === choice;
            return (
              <button
                key={i}
                onClick={() => handleGuess(choice)}
                disabled={isSolved}
                className={`w-full py-2.5 px-4 rounded-xl font-bold text-sm transition-all flex items-center justify-between border ${
                  isSelected && isSolved
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-lg'
                    : isSelected && isWrong
                    ? 'bg-rose-700 border-rose-500 text-white animate-shake'
                    : 'bg-slate-800/90 border-slate-700/80 hover:bg-slate-700/90 text-slate-200 active:scale-98'
                }`}
              >
                <span>{choice}</span>
                <span className="text-xs text-slate-500 font-mono">#{i + 1}</span>
              </button>
            );
          })}
        </div>

        {/* Reveal all tiles button */}
        <button
          onClick={handleRevealAll}
          className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-medium transition-colors"
        >
          <Eye className="w-3.5 h-3.5 text-cyan-400" />
          <span>{t.tapToReveal}</span>
        </button>
      </div>
    </div>
  );
};
