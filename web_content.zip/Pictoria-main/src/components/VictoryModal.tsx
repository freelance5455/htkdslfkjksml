import React, { useEffect } from 'react';
import { Trophy, Star, ArrowRight, ArrowLeft, RotateCcw, Home, Coins, Clock, Grid } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, PuzzleLevel } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface VictoryModalProps {
  level: PuzzleLevel;
  stars: number;
  score: number;
  coinsEarned: number;
  timeSpent: number;
  hasNextLevel: boolean;
  language: Language;
  onNextLevel: () => void;
  onRetry: () => void;
  onBackToMenu: () => void;
  onOpenLevelModal: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  level,
  stars,
  score,
  coinsEarned,
  timeSpent,
  hasNextLevel,
  language,
  onNextLevel,
  onRetry,
  onBackToMenu,
  onOpenLevelModal,
}) => {
  const t = TRANSLATIONS[language];
  const isRtl = language === 'ar';

  useEffect(() => {
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 },
      colors: ['#F59E0B', '#10B981', '#38BDF8', '#EC4899', '#EAB308'],
    });
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl flex flex-col items-center text-center">
        {/* Victory Trophy Icon */}
        <div className="relative mb-3">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-xl shadow-amber-500/20">
            <Trophy className="w-8 h-8 text-amber-400 animate-bounce" />
          </div>
        </div>

        <h3 className="text-xl font-bold text-white mb-1">{t.congratulations}</h3>
        <p className="text-xs text-slate-400 mb-4">{t.levelCompleted}</p>

        {/* Solved image preview */}
        <div className="w-24 h-24 rounded-xl overflow-hidden border-2 border-amber-500/50 shadow-lg mb-4">
          <img
            src={level.imageUrl}
            alt="Solved preview"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Stars calculation */}
        <div className="flex items-center gap-2 mb-4">
          {[1, 2, 3].map((s) => (
            <Star
              key={s}
              className={`w-7 h-7 transform transition-transform ${
                s <= stars
                  ? 'text-amber-400 fill-amber-400 scale-110 drop-shadow-md'
                  : 'text-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Stat badges */}
        <div className="w-full grid grid-cols-3 gap-2 py-3 px-2 rounded-xl bg-slate-950/70 border border-slate-800 text-xs font-mono mb-6">
          <div className="flex flex-col items-center">
            <span className="text-[11px] text-slate-500 font-sans">{t.score}</span>
            <span className="text-amber-400 font-bold tabular-nums">+{score}</span>
          </div>

          <div className="flex flex-col items-center border-x border-slate-800">
            <span className="text-[11px] text-slate-500 font-sans flex items-center gap-1">
              <Coins className="w-3 h-3 text-amber-400" />
              <span>{t.coins}</span>
            </span>
            <span className="text-emerald-400 font-bold tabular-nums">+{coinsEarned}</span>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-[11px] text-slate-500 font-sans flex items-center gap-1">
              <Clock className="w-3 h-3 text-cyan-400" />
              <span>{t.time}</span>
            </span>
            <span className="text-slate-300 font-bold tabular-nums">{formatTime(timeSpent)}</span>
          </div>
        </div>

        {/* Navigation Action Buttons */}
        <div className="w-full flex items-center justify-center gap-2.5">
          <button
            onClick={() => {
              sound.playClick();
              onBackToMenu();
            }}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title={t.backToMenu}
          >
            <Home className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenLevelModal();
            }}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 transition-colors"
            title={t.levels}
          >
            <Grid className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRetry();
            }}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title={t.retryLevel}
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          {hasNextLevel && (
            <button
              onClick={() => {
                sound.playClick();
                onNextLevel();
              }}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <span>{t.nextLevel}</span>
              {isRtl ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
