import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Delete, Shuffle, ZoomIn, X, Key } from 'lucide-react';
import { Language, PuzzleLevel } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface WordPuzzleModeProps {
  level: PuzzleLevel;
  language: Language;
  onSolve: () => void;
  removedBankIndices: number[];
  revealedPositions: Record<number, string>;
}

// Arabic alphabet pool for decoys
const ARABIC_ALPHABET = 'ابتثجحخدذرزسشصضطظعغفقكلمنهويأإؤئة'.split('');
const LATIN_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export const WordPuzzleMode: React.FC<WordPuzzleModeProps> = ({
  level,
  language,
  onSolve,
  removedBankIndices,
  revealedPositions,
}) => {
  const t = TRANSLATIONS[language];
  const targetWord = useMemo(() => {
    return level.answer[language].toUpperCase().replace(/\s+/g, '');
  }, [level, language]);

  const [currentSlots, setCurrentSlots] = useState<string[]>([]);
  const [bankLetters, setBankLetters] = useState<{ id: number; char: string }[]>([]);
  const [usedBankIds, setUsedBankIds] = useState<number[]>([]);
  const [slotBankMap, setSlotBankMap] = useState<Record<number, number>>({});
  const [isZoomed, setIsZoomed] = useState<boolean>(false);
  const [isShaking, setIsShaking] = useState<boolean>(false);

  // Initialize slots and letter bank whenever the target word changes
  useEffect(() => {
    const slots = Array(targetWord.length).fill('');
    // Apply revealed letters
    Object.entries(revealedPositions).forEach(([idxStr, char]) => {
      const idx = parseInt(idxStr, 10);
      if (idx < slots.length) {
        slots[idx] = char;
      }
    });
    setCurrentSlots(slots);

    // Create bank letters: target letters + random decoys
    const isArabic = language === 'ar';
    const pool = isArabic ? ARABIC_ALPHABET : LATIN_ALPHABET;
    const requiredChars = targetWord.split('');

    // Add 4-6 decoys to make total length 12 or 14
    const totalBankSize = Math.max(12, requiredChars.length + 4);
    const decoyCount = totalBankSize - requiredChars.length;
    const decoys: string[] = [];
    for (let i = 0; i < decoyCount; i++) {
      const randomChar = pool[Math.floor(Math.random() * pool.length)];
      decoys.push(randomChar);
    }

    const allChars = [...requiredChars, ...decoys];
    // Fisher-Yates shuffle
    for (let i = allChars.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allChars[i], allChars[j]] = [allChars[j], allChars[i]];
    }

    setBankLetters(allChars.map((char, id) => ({ id, char })));
    setUsedBankIds([]);
    setSlotBankMap({});
  }, [targetWord, language, revealedPositions]);

  // Check victory condition
  const checkAnswer = useCallback((slots: string[]) => {
    const currentWord = slots.join('');
    if (currentWord.length === targetWord.length) {
      if (currentWord === targetWord) {
        sound.playVictory();
        onSolve();
      } else {
        sound.playError();
        setIsShaking(true);
        setTimeout(() => setIsShaking(false), 500);
      }
    }
  }, [targetWord, onSolve]);

  const handleSelectBankLetter = (bankId: number, char: string) => {
    if (usedBankIds.includes(bankId)) return;
    if (removedBankIndices.includes(bankId)) return;

    // Find first empty slot
    const emptyIndex = currentSlots.findIndex((s) => s === '');
    if (emptyIndex === -1) return;

    sound.playLetterTap();
    const newSlots = [...currentSlots];
    newSlots[emptyIndex] = char;
    setCurrentSlots(newSlots);

    setUsedBankIds((prev) => [...prev, bankId]);
    setSlotBankMap((prev) => ({ ...prev, [emptyIndex]: bankId }));

    checkAnswer(newSlots);
  };

  const handleRemoveSlotLetter = (slotIndex: number) => {
    // If it's locked by hint reveal, do not remove
    if (revealedPositions[slotIndex]) return;

    const char = currentSlots[slotIndex];
    if (!char) return;

    sound.playLetterRemove();
    const bankId = slotBankMap[slotIndex];

    const newSlots = [...currentSlots];
    newSlots[slotIndex] = '';
    setCurrentSlots(newSlots);

    if (bankId !== undefined) {
      setUsedBankIds((prev) => prev.filter((id) => id !== bankId));
      setSlotBankMap((prev) => {
        const copy = { ...prev };
        delete copy[slotIndex];
        return copy;
      });
    }
  };

  const handleBackspace = () => {
    // Find last filled non-locked slot
    for (let i = currentSlots.length - 1; i >= 0; i--) {
      if (currentSlots[i] !== '' && !revealedPositions[i]) {
        handleRemoveSlotLetter(i);
        break;
      }
    }
  };

  const handleShuffle = () => {
    sound.playClick();
    setBankLetters((prev) => {
      const copy = [...prev];
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
      }
      return copy;
    });
  };

  return (
    <div className="w-full h-full flex flex-col md:flex-row items-center justify-between gap-4 p-3 md:p-6 max-w-6xl mx-auto overflow-hidden">
      {/* Left / Top: Interactive Photo Display */}
      <div className="relative w-full md:w-1/2 flex flex-col items-center justify-center">
        <div className="relative group w-48 h-48 sm:w-60 sm:h-60 md:w-80 md:h-80 rounded-2xl overflow-hidden border-2 border-slate-700/80 shadow-2xl bg-slate-900">
          <img
            src={level.imageUrl}
            alt={level.category[language]}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none" />

          {/* Clue banner */}
          <div className="absolute bottom-2 inset-x-2 text-center p-2 rounded-lg bg-slate-900/90 backdrop-blur-sm border border-slate-800 text-xs text-slate-300 font-medium">
            <span className="text-amber-400 font-bold ml-1 mr-1">💡</span>
            {level.clue[language]}
          </div>

          {/* Zoom button */}
          <button
            onClick={() => {
              sound.playClick();
              setIsZoomed(true);
            }}
            className="absolute top-3 right-3 p-2 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-700/80 text-white hover:bg-slate-800 transition-all opacity-80 hover:opacity-100"
            title={t.zoomImage}
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Right / Bottom: Puzzle Interactive Solver */}
      <div className="w-full md:w-1/2 flex flex-col items-center justify-center gap-4">
        {/* Letter slots placeholder */}
        <div
          className={`flex items-center justify-center gap-2 flex-wrap py-2 transition-transform ${
            isShaking ? 'translate-x-1 animate-pulse' : ''
          }`}
        >
          {currentSlots.map((letter, idx) => {
            const isRevealed = Boolean(revealedPositions[idx]);
            const isFilled = letter !== '';

            return (
              <button
                key={idx}
                onClick={() => handleRemoveSlotLetter(idx)}
                disabled={isRevealed || !isFilled}
                className={`w-10 h-11 sm:w-12 sm:h-13 rounded-xl flex items-center justify-center font-bold text-lg sm:text-xl transition-all shadow-md active:scale-95 ${
                  isFilled
                    ? isRevealed
                      ? 'bg-gradient-to-b from-amber-400 to-amber-600 text-slate-950 border border-amber-300 shadow-amber-500/20'
                      : 'bg-gradient-to-b from-slate-700 to-slate-800 text-amber-300 border border-amber-500/50 shadow-slate-900/60'
                    : 'bg-slate-900/70 border-2 border-dashed border-slate-700/80 text-slate-500'
                }`}
              >
                {letter}
                {isRevealed && (
                  <Key className="w-2.5 h-2.5 text-amber-950 absolute -top-1 -right-1" />
                )}
              </button>
            );
          })}
        </div>

        {/* Bank of letters & action keys */}
        <div className="w-full max-w-md bg-slate-900/80 border border-slate-800/90 rounded-2xl p-3 shadow-xl backdrop-blur-sm">
          <div className="grid grid-cols-6 sm:grid-cols-7 gap-1.5 sm:gap-2 mb-3">
            {bankLetters.map(({ id, char }) => {
              const isUsed = usedBankIds.includes(id);
              const isRemoved = removedBankIndices.includes(id);

              if (isRemoved) {
                return (
                  <div
                    key={id}
                    className="w-full aspect-square rounded-lg bg-slate-950/40 border border-slate-900/40 opacity-20 pointer-events-none"
                  />
                );
              }

              return (
                <button
                  key={id}
                  onClick={() => handleSelectBankLetter(id, char)}
                  disabled={isUsed}
                  className={`w-full aspect-square rounded-xl font-bold text-base sm:text-lg flex items-center justify-center transition-all ${
                    isUsed
                      ? 'bg-slate-950/60 text-slate-600 border border-slate-900/60 cursor-not-allowed opacity-30'
                      : 'bg-gradient-to-b from-slate-800 to-slate-850 hover:from-slate-700 hover:to-slate-800 text-slate-100 border border-slate-700/80 shadow-md active:scale-90 hover:border-amber-400/50'
                  }`}
                >
                  {char}
                </button>
              );
            })}
          </div>

          {/* Bottom helper controls: Shuffle & Backspace */}
          <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
            <button
              onClick={handleShuffle}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-xs text-slate-300 font-medium transition-colors"
            >
              <Shuffle className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.shuffle}</span>
            </button>

            <button
              onClick={handleBackspace}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-rose-950/50 hover:text-rose-300 text-xs text-slate-300 font-medium transition-colors"
            >
              <Delete className="w-3.5 h-3.5" />
              <span>{t.clearLetter}</span>
            </button>
          </div>
        </div>
      </div>

      {/* High-res Image Zoom Modal */}
      {isZoomed && (
        <div
          onClick={() => setIsZoomed(false)}
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="relative max-w-2xl max-h-[85vh] rounded-2xl overflow-hidden border border-slate-700 shadow-2xl">
            <img
              src={level.imageUrl}
              alt={level.category[language]}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
            <button
              onClick={() => setIsZoomed(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-950/80 text-white border border-slate-700 hover:bg-slate-900 transition-colors"
              title={t.close}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
