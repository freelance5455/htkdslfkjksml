import React, { useState, useEffect, useCallback } from 'react';
import { Eye, RotateCcw, CheckCircle2 } from 'lucide-react';
import { Language, PuzzleLevel } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface JigsawPuzzleModeProps {
  level: PuzzleLevel;
  language: Language;
  onSolve: () => void;
  onRequestHintSolve?: boolean;
}

export const JigsawPuzzleMode: React.FC<JigsawPuzzleModeProps> = ({
  level,
  language,
  onSolve,
}) => {
  const t = TRANSLATIONS[language];
  const size = 3; // 3x3 grid
  const totalTiles = size * size;

  // Board state: array of 9 indices (0..7 are image slice indices, 8 is empty slot)
  const [board, setBoard] = useState<number[]>([]);
  const [moves, setMoves] = useState<number>(0);
  const [showPreview, setShowPreview] = useState<boolean>(false);
  const [isWon, setIsWon] = useState<boolean>(false);

  // Initialize board by making random valid moves from solved state to guarantee solvability
  const resetBoard = useCallback(() => {
    let current = Array.from({ length: totalTiles }, (_, i) => i);
    let emptyIdx = totalTiles - 1; // 8 is empty

    // Perform 40 random legal swaps
    for (let step = 0; step < 40; step++) {
      const row = Math.floor(emptyIdx / size);
      const col = emptyIdx % size;
      const neighbors: number[] = [];

      if (row > 0) neighbors.push(emptyIdx - size); // top
      if (row < size - 1) neighbors.push(emptyIdx + size); // bottom
      if (col > 0) neighbors.push(emptyIdx - 1); // left
      if (col < size - 1) neighbors.push(emptyIdx + 1); // right

      const swapIdx = neighbors[Math.floor(Math.random() * neighbors.length)];
      [current[emptyIdx], current[swapIdx]] = [current[swapIdx], current[emptyIdx]];
      emptyIdx = swapIdx;
    }

    setBoard(current);
    setMoves(0);
    setIsWon(false);
  }, [size, totalTiles]);

  useEffect(() => {
    resetBoard();
  }, [resetBoard, level.id]);

  // Check if board is in solved state
  const checkVictory = (currentBoard: number[]) => {
    const isSolved = currentBoard.every((val, idx) => val === idx);
    if (isSolved && !isWon) {
      setIsWon(true);
      sound.playVictory();
      setTimeout(() => {
        onSolve();
      }, 700);
    }
  };

  const handleTileClick = (index: number) => {
    if (isWon) return;
    const emptyIdx = board.indexOf(totalTiles - 1);
    if (emptyIdx === -1) return;

    const row = Math.floor(index / size);
    const col = index % size;
    const emptyRow = Math.floor(emptyIdx / size);
    const emptyCol = emptyIdx % size;

    // Check adjacency
    const isAdjacent =
      (Math.abs(row - emptyRow) === 1 && col === emptyCol) ||
      (Math.abs(col - emptyCol) === 1 && row === emptyRow);

    if (isAdjacent) {
      sound.playLetterTap();
      const newBoard = [...board];
      [newBoard[index], newBoard[emptyIdx]] = [newBoard[emptyIdx], newBoard[index]];
      setBoard(newBoard);
      setMoves((m) => m + 1);
      checkVictory(newBoard);
    } else {
      sound.playError();
    }
  };

  return (
    <div className="w-full h-full flex flex-col md:flex-row items-center justify-center gap-6 p-3 md:p-6 max-w-5xl mx-auto overflow-hidden">
      {/* Board Display */}
      <div className="relative flex flex-col items-center">
        <div
          className="relative w-64 h-64 sm:w-72 sm:h-72 md:w-80 md:h-80 bg-slate-900 border-4 border-slate-800 rounded-2xl overflow-hidden shadow-2xl p-1"
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${size}, 1fr)`,
            gridTemplateRows: `repeat(${size}, 1fr)`,
            gap: '4px',
          }}
        >
          {board.map((tileIndex, slotIndex) => {
            const isEmpty = tileIndex === totalTiles - 1 && !isWon;
            if (isEmpty) {
              return (
                <div
                  key={slotIndex}
                  className="w-full h-full bg-slate-950/70 border border-slate-800/50 rounded-lg flex items-center justify-center text-slate-700 text-xs font-mono"
                >
                  ·
                </div>
              );
            }

            // Calculate background position
            const tileRow = Math.floor(tileIndex / size);
            const tileCol = tileIndex % size;
            const posX = (tileCol / (size - 1)) * 100;
            const posY = (tileRow / (size - 1)) * 100;

            return (
              <button
                key={slotIndex}
                onClick={() => handleTileClick(slotIndex)}
                className="relative w-full h-full rounded-lg overflow-hidden border border-slate-700/60 shadow-md transition-transform active:scale-95 group focus:outline-none"
                style={{
                  backgroundImage: `url(${level.imageUrl})`,
                  backgroundSize: `${size * 100}% ${size * 100}%`,
                  backgroundPosition: `${posX}% ${posY}%`,
                }}
              >
                {/* Tile index number watermark */}
                <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-slate-950/70 text-[10px] font-mono text-slate-300 font-bold group-hover:bg-amber-500/80 group-hover:text-slate-950 transition-colors">
                  {tileIndex + 1}
                </span>
              </button>
            );
          })}

          {isWon && (
            <div className="absolute inset-0 bg-emerald-950/80 backdrop-blur-sm flex flex-col items-center justify-center text-emerald-300 animate-fadeIn">
              <CheckCircle2 className="w-16 h-16 text-emerald-400 mb-2 animate-bounce" />
              <p className="font-bold text-lg">{t.congratulations}</p>
            </div>
          )}
        </div>
      </div>

      {/* Side HUD & Controls */}
      <div className="flex flex-col items-center md:items-start gap-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl max-w-sm w-full">
        <div>
          <h3 className="font-bold text-white text-base mb-1">{level.category[language]}</h3>
          <p className="text-xs text-slate-400 leading-relaxed">{level.clue[language]}</p>
        </div>

        <div className="w-full flex items-center justify-around py-3 px-4 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs font-mono">
          <div className="flex flex-col items-center">
            <span className="text-slate-500">{t.moves}</span>
            <span className="text-amber-400 font-bold text-base tabular-nums">{moves}</span>
          </div>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <div className="flex flex-col items-center">
            <span className="text-slate-500">{t.stars}</span>
            <span className="text-emerald-400 font-bold text-base">★★★</span>
          </div>
        </div>

        {/* Action buttons */}
        <div className="w-full flex items-center gap-2">
          <button
            onClick={() => {
              sound.playClick();
              setShowPreview(!showPreview);
            }}
            className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
          >
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span>{showPreview ? t.close : t.originalImage}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              resetBoard();
            }}
            className="flex items-center justify-center p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title={t.retryLevel}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Thumbnail Preview Modal / Box */}
        {showPreview && (
          <div className="w-full rounded-xl overflow-hidden border border-slate-700 aspect-square max-w-[180px] mx-auto animate-fadeIn shadow-lg">
            <img
              src={level.imageUrl}
              alt="Preview"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        )}
      </div>
    </div>
  );
};
