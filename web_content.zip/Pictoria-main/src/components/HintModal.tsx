import React from 'react';
import { X, Lightbulb, Trash2, CheckCircle2, Coins, AlertCircle, Key } from 'lucide-react';
import { Language } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface HintModalProps {
  language: Language;
  coins: number;
  hintsRemaining: number;
  onClose: () => void;
  onRevealLetter: () => void;
  onRemoveDecoys: () => void;
  onAutoSolve: () => void;
}

export const HintModal: React.FC<HintModalProps> = ({
  language,
  coins,
  hintsRemaining,
  onClose,
  onRevealLetter,
  onRemoveDecoys,
  onAutoSolve,
}) => {
  const t = TRANSLATIONS[language];
  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);

  const handleAction = (cost: number, action: () => void) => {
    if (hintsRemaining > 0) {
      sound.playHint();
      action();
      onClose();
      return;
    }

    if (coins >= cost) {
      sound.playHint();
      action();
      onClose();
    } else {
      sound.playError();
      setErrorMessage(t.notEnoughCoins);
      setTimeout(() => setErrorMessage(null), 2500);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-slate-100"
      >
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title={t.close}
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-amber-400" />
          <span>{t.useHint}</span>
        </h3>
        <p className="text-xs text-slate-400 mb-6">
          {hintsRemaining > 0
            ? `${t.hints}: ${hintsRemaining} (${t.claimReward})`
            : `${t.coins}: ${coins}`}
        </p>

        {errorMessage && (
          <div className="mb-4 p-2.5 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {/* Hint 1: Reveal Letter */}
          <button
            onClick={() => handleAction(50, onRevealLetter)}
            className="w-full p-3.5 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/50 flex items-center justify-between text-left transition-all active:scale-98 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:bg-amber-500/20">
                <Key className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-200">{t.revealLetter}</p>
                <p className="text-[11px] text-slate-400">
                  {language === 'ar' ? 'يكشف حرفًا صحيحًا في مكانه' : 'Reveals one correct letter in place'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 font-mono text-xs font-bold text-amber-400">
              <Coins className="w-3.5 h-3.5" />
              <span>50</span>
            </div>
          </button>

          {/* Hint 2: Remove Decoys */}
          <button
            onClick={() => handleAction(30, onRemoveDecoys)}
            className="w-full p-3.5 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 flex items-center justify-between text-left transition-all active:scale-98 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-500/20">
                <Trash2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-200">{t.removeWrong}</p>
                <p className="text-[11px] text-slate-400">
                  {language === 'ar' ? 'يحذف 3 أحرف غير مستخدمة' : 'Removes 3 unused decoy letters'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 font-mono text-xs font-bold text-amber-400">
              <Coins className="w-3.5 h-3.5" />
              <span>30</span>
            </div>
          </button>

          {/* Hint 3: Auto Solve */}
          <button
            onClick={() => handleAction(100, onAutoSolve)}
            className="w-full p-3.5 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 flex items-center justify-between text-left transition-all active:scale-98 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500/20">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-200">{t.solvePuzzle}</p>
                <p className="text-[11px] text-slate-400">
                  {language === 'ar' ? 'حل اللغز بالكامل والانتقال للتالي' : 'Instantly complete this level'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 font-mono text-xs font-bold text-amber-400">
              <Coins className="w-3.5 h-3.5" />
              <span>100</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
