import React, { useState } from 'react';
import { X, Lock, Star, Play, Sparkles, ShoppingBag } from 'lucide-react';
import { Language, PuzzleLevel, UserProgress } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface LevelSelectModalProps {
  levels: PuzzleLevel[];
  progress: UserProgress;
  currentLevelId?: number;
  language: Language;
  onSelectLevel: (levelId: number) => void;
  onOpenPremiumModal: () => void;
  onClose: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  levels,
  progress,
  currentLevelId,
  language,
  onSelectLevel,
  onOpenPremiumModal,
  onClose,
}) => {
  const t = TRANSLATIONS[language];
  const [packFilter, setPackFilter] = useState<'free' | 'premium' | 'all'>('free');
  const [selectedSubRange, setSelectedSubRange] = useState<string>('1-25');

  const isPremiumActive = Boolean(progress.isPremiumUnlocked);

  const getModeLabel = (mode: string) => {
    if (mode === 'word_puzzle') return t.modeWord;
    if (mode === 'sliding_tiles') return t.modeSlider;
    return t.modeMystery;
  };

  // Filter levels by pack and range
  const filteredLevels = levels.filter((lvl) => {
    if (packFilter === 'free' && lvl.isPremium) return false;
    if (packFilter === 'premium' && !lvl.isPremium) return false;

    // Apply sub-ranges if selected
    if (selectedSubRange === '1-25') return lvl.id >= 1 && lvl.id <= 25;
    if (selectedSubRange === '26-50') return lvl.id >= 26 && lvl.id <= 50;
    if (selectedSubRange === '51-75') return lvl.id >= 51 && lvl.id <= 75;
    if (selectedSubRange === '76-100') return lvl.id >= 76 && lvl.id <= 100;
    if (selectedSubRange === '101-125') return lvl.id >= 101 && lvl.id <= 125;
    if (selectedSubRange === '126-150') return lvl.id >= 126 && lvl.id <= 150;
    if (selectedSubRange === '151-175') return lvl.id >= 151 && lvl.id <= 175;
    if (selectedSubRange === '176-200') return lvl.id >= 176 && lvl.id <= 200;
    return true;
  });

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-6 shadow-2xl flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
              <span>{t.levels}</span>
              <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-400">
                200 {language === 'ar' ? 'مستوى (100 مجاني + 100 بريميوم)' : 'Stages (100 Free + 100 VIP)'}
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'ar'
                ? 'اختر أي مستوى تم فتحه لمواصلة رحلتك وحصد النجوم'
                : 'Select any unlocked stage to continue your quest'}
            </p>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Major Pack Selector Tabs: Free (100) vs Premium (100) vs All (200) */}
        <div className="flex items-center justify-between gap-2 pt-3 pb-2 border-b border-slate-800/80 flex-wrap">
          <div className="flex items-center gap-1.5 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => {
                sound.playClick();
                setPackFilter('free');
                setSelectedSubRange('1-25');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                packFilter === 'free'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {t.standardLevelsTab}
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setPackFilter('premium');
                setSelectedSubRange('101-125');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                packFilter === 'premium'
                  ? 'bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 shadow-sm font-black'
                  : 'text-amber-400 hover:text-amber-300'
              }`}
            >
              <span>{t.premiumLevelsTab}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-950/80 text-amber-300 font-mono">
                $2.50
              </span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setPackFilter('all');
                setSelectedSubRange('all');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                packFilter === 'all'
                  ? 'bg-slate-700 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.allLevelsTab}
            </button>
          </div>

          {/* Unlock Premium CTA Banner if not purchased yet */}
          {!isPremiumActive && (
            <button
              onClick={() => {
                sound.playClick();
                onOpenPremiumModal();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:brightness-110 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{t.unlockPremium}</span>
            </button>
          )}

          {isPremiumActive && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold font-mono">
              <span>VIP Active ✓</span>
            </div>
          )}
        </div>

        {/* Sub-range Filters */}
        <div className="flex items-center gap-1.5 py-2 overflow-x-auto text-xs shrink-0">
          {packFilter === 'free' && (
            <>
              <button
                onClick={() => setSelectedSubRange('1-25')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '1-25' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                1 - 25
              </button>
              <button
                onClick={() => setSelectedSubRange('26-50')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '26-50' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                26 - 50
              </button>
              <button
                onClick={() => setSelectedSubRange('51-75')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '51-75' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                51 - 75
              </button>
              <button
                onClick={() => setSelectedSubRange('76-100')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '76-100' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                76 - 100
              </button>
            </>
          )}

          {packFilter === 'premium' && (
            <>
              <button
                onClick={() => setSelectedSubRange('101-125')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '101-125' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                101 - 125
              </button>
              <button
                onClick={() => setSelectedSubRange('126-150')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '126-150' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                126 - 150
              </button>
              <button
                onClick={() => setSelectedSubRange('151-175')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '151-175' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                151 - 175
              </button>
              <button
                onClick={() => setSelectedSubRange('176-200')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
                  selectedSubRange === '176-200' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}
              >
                176 - 200
              </button>
            </>
          )}

          <button
            onClick={() => setSelectedSubRange('all')}
            className={`px-2.5 py-1 rounded-md font-bold transition-all whitespace-nowrap ${
              selectedSubRange === 'all' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
            }`}
          >
            {language === 'ar' ? 'عرض الكل' : 'Show All'}
          </button>
        </div>

        {/* Level Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 py-3 overflow-y-auto pr-1">
          {filteredLevels.map((lvl) => {
            const isPremiumLvl = Boolean(lvl.isPremium);
            const isUnlocked = isPremiumLvl
              ? isPremiumActive
              : lvl.id <= progress.unlockedLevel;
            const scoreData = progress.levelScores[lvl.id];
            const stars = scoreData?.stars || 0;
            const isCurrent = currentLevelId === lvl.id;

            return (
              <button
                key={lvl.id}
                onClick={() => {
                  if (isPremiumLvl && !isPremiumActive) {
                    sound.playError();
                    onOpenPremiumModal();
                    return;
                  }

                  if (isUnlocked) {
                    sound.playClick();
                    onSelectLevel(lvl.id);
                    onClose();
                  } else {
                    sound.playError();
                  }
                }}
                className={`relative group rounded-xl p-2.5 flex flex-col items-center justify-between text-center transition-all border ${
                  isCurrent
                    ? 'bg-amber-500/15 border-amber-400 ring-2 ring-amber-400/30 shadow-lg'
                    : isPremiumLvl && !isPremiumActive
                    ? 'bg-slate-950/80 border-amber-500/40 hover:border-amber-400/80 shadow-md cursor-pointer'
                    : isUnlocked
                    ? 'bg-slate-800/80 hover:bg-slate-750 border-slate-700/80 hover:border-amber-400/50 shadow-md active:scale-95'
                    : 'bg-slate-950/60 border-slate-900 text-slate-600 cursor-not-allowed opacity-50'
                }`}
              >
                {/* Level Title and Mode */}
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`font-bold text-xs ${isCurrent ? 'text-amber-300' : isPremiumLvl ? 'text-amber-400' : 'text-slate-200'}`}>
                    {t.levelSingle} {lvl.id}
                  </span>
                  <span className="text-[10px] text-slate-400 font-sans">
                    {isPremiumLvl ? 'VIP' : getModeLabel(lvl.mode)}
                  </span>
                </div>

                {/* Level Image Thumbnail or Lock */}
                <div className="w-14 h-14 rounded-lg overflow-hidden border border-slate-700/60 bg-slate-950 mb-1.5 relative">
                  {isUnlocked ? (
                    <>
                      <img
                        src={lvl.imageUrl}
                        alt={lvl.category[language]}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                      />
                      {isCurrent && (
                        <div className="absolute inset-0 bg-amber-500/20 flex items-center justify-center">
                          <Play className="w-4 h-4 text-amber-300 fill-amber-300" />
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950">
                      <Lock className={`w-4 h-4 ${isPremiumLvl ? 'text-amber-400' : 'text-slate-600'}`} />
                      {isPremiumLvl && (
                        <span className="text-[8px] font-mono text-amber-400 mt-0.5">$2.50</span>
                      )}
                    </div>
                  )}
                </div>

                <p className="text-xs font-bold text-slate-200 truncate w-full mb-1">
                  {lvl.category[language]}
                </p>

                {/* Stars or Premium Buy prompt */}
                {isPremiumLvl && !isPremiumActive ? (
                  <span className="text-[10px] text-amber-400 font-bold group-hover:underline">
                    {language === 'ar' ? 'فتح بـ $2.50' : 'Unlock $2.50'}
                  </span>
                ) : (
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3].map((s) => (
                      <Star
                        key={s}
                        className={`w-3 h-3 ${
                          s <= stars
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
