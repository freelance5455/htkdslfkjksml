import React from 'react';
import { X, Gift, Check, Flame, Coins } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, UserProgress } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { sound } from '../utils/audio';

interface DailyRewardModalProps {
  progress: UserProgress;
  language: Language;
  onClaim: (coinsToAdd: number, hintsToAdd: number) => void;
  onClose: () => void;
}

const REWARDS_SCHEDULE = [
  { day: 1, coins: 50, hints: 0, label: '50 Coins' },
  { day: 2, coins: 100, hints: 0, label: '100 Coins' },
  { day: 3, coins: 120, hints: 1, label: '120 Coins + 1 Hint' },
  { day: 4, coins: 180, hints: 0, label: '180 Coins' },
  { day: 5, coins: 250, hints: 1, label: '250 Coins + 1 Hint' },
  { day: 6, coins: 350, hints: 1, label: '350 Coins + 1 Hint' },
  { day: 7, coins: 600, hints: 3, label: '600 Coins + 3 Hints (Grand Chest)' },
];

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  progress,
  language,
  onClaim,
  onClose,
}) => {
  const t = TRANSLATIONS[language];

  // Check if today was already claimed
  const todayStr = new Date().toISOString().slice(0, 10);
  const isClaimedToday = progress.lastDailyClaim === todayStr;

  const currentStreakIndex = (progress.streakDays - 1) % 7;
  const targetDay = (isClaimedToday ? currentStreakIndex : progress.streakDays % 7);
  const rewardForToday = REWARDS_SCHEDULE[targetDay] || REWARDS_SCHEDULE[0];

  const handleClaimReward = () => {
    if (isClaimedToday) return;

    sound.playDailyReward();
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#F59E0B', '#10B981', '#38BDF8', '#F43F5E'],
    });

    onClaim(rewardForToday.coins, rewardForToday.hints);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl flex flex-col"
      >
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title={t.close}
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Flame className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">{t.dailyReward}</h3>
            <p className="text-xs text-slate-400">
              {t.streak}: <span className="text-amber-400 font-bold font-mono">{progress.streakDays}</span> {t.day}
            </p>
          </div>
        </div>

        {/* 7-Day Rewards Calendar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2 my-6">
          {REWARDS_SCHEDULE.map((item, idx) => {
            const isCompleted = isClaimedToday ? idx <= currentStreakIndex : idx < (progress.streakDays % 7);
            const isCurrent = !isClaimedToday && idx === (progress.streakDays % 7);
            const isGrand = idx === 6;

            return (
              <div
                key={item.day}
                className={`relative rounded-xl p-3 flex flex-col items-center text-center transition-all border ${
                  isCurrent
                    ? 'bg-amber-500/10 border-amber-500 shadow-lg shadow-amber-500/10 scale-105'
                    : isCompleted
                    ? 'bg-slate-800/60 border-emerald-500/40 text-slate-400'
                    : 'bg-slate-950/60 border-slate-800/80 text-slate-500'
                }`}
              >
                <span className="text-[11px] font-mono font-bold mb-1">
                  {t.day} {item.day}
                </span>

                <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-700/60 flex items-center justify-center my-1">
                  {isCompleted ? (
                    <Check className="w-5 h-5 text-emerald-400" />
                  ) : isGrand ? (
                    <Gift className="w-5 h-5 text-amber-400 animate-bounce" />
                  ) : (
                    <Coins className="w-4 h-4 text-amber-400" />
                  )}
                </div>

                <span className="text-xs font-mono font-bold text-slate-200 mt-1">
                  +{item.coins}
                </span>
                {item.hints > 0 && (
                  <span className="text-[10px] text-cyan-400 font-mono mt-0.5">
                    +{item.hints} 💡
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Claim Action */}
        <div className="flex flex-col items-center justify-center gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={handleClaimReward}
            disabled={isClaimedToday}
            className={`w-full max-w-sm py-3 px-6 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
              isClaimedToday
                ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 active:scale-95'
            }`}
          >
            {isClaimedToday ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{t.claimedToday}</span>
              </>
            ) : (
              <>
                <Gift className="w-4 h-4" />
                <span>
                  {t.claimReward} (+{rewardForToday.coins} {t.coins}
                  {rewardForToday.hints > 0 ? ` +${rewardForToday.hints} ${t.hints}` : ''})
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
