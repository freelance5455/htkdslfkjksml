import React, { useState } from 'react';
import { X, Copy, Check, Code2, Terminal, ShieldCheck, ShoppingBag, BookOpen } from 'lucide-react';
import { Language } from '../types/game';
import { sound } from '../utils/audio';

interface BillingDeveloperGuideModalProps {
  language: Language;
  onClose: () => void;
}

const GRADLE_SNIPPET = `// build.gradle (Module: app)
dependencies {
    // Google Play Billing Library (v7.0.0 or v6.2.1)
    implementation("com.android.billingclient:billing-ktx:7.0.0")
    
    // Coroutines for asynchronous queries
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}

// AndroidManifest.xml
<manifest ...>
    <!-- Billing permission is automatically merged, but can be added explicitly -->
    <uses-permission android:name="com.android.vending.BILLING" />
</manifest>`;

const KOTLIN_BILLING_MANAGER = `// BillingManager.kt - Complete Non-Consumable IAP Implementation
package com.pictora.game.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BillingManager(
    private val activity: Activity,
    private val onPurchaseSuccess: (String) -> Unit,
    private val onPurchaseFailed: (String) -> Unit
) : PurchasesUpdatedListener {

    private val billingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases()
        .build()

    companion object {
        const val PRODUCT_ID_PREMIUM = "pictora_premium_100_levels" // $2.50 Non-Consumable
    }

    init {
        startBillingConnection()
    }

    private fun startBillingConnection() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    // Check if already purchased on app start (Restore purchases)
                    queryPurchases()
                }
            }

            override fun onBillingServiceDisconnected() {
                // Retry connection logic
            }
        })
    }

    // 1. Query Product Details ($2.50 Non-Consumable) & Launch Purchase
    fun launchPurchaseFlow(productId: String = PRODUCT_ID_PREMIUM) {
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.INAPP) // INAPP for Non-Consumable
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && productDetailsList.isNotEmpty()) {
                val productDetails = productDetailsList[0]

                val billingFlowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(
                        listOf(
                            BillingFlowParams.ProductDetailsParams.newBuilder()
                                .setProductDetails(productDetails)
                                .build()
                        )
                    )
                    .build()

                billingClient.launchBillingFlow(activity, billingFlowParams)
            } else {
                onPurchaseFailed("Failed to retrieve product details: " + billingResult.debugMessage)
            }
        }
    }

    // 2. Handle Purchases & Acknowledge (Mandatory for Non-Consumable)
    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            onPurchaseFailed("User canceled purchase")
        } else {
            onPurchaseFailed("Purchase error: " + billingResult.debugMessage)
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            // Acknowledge the purchase (Google will refund after 3 days if not acknowledged)
            if (!purchase.isAcknowledged) {
                val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()

                billingClient.acknowledgePurchase(acknowledgePurchaseParams) { billingResult ->
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        // Grant user the 100 Premium stages
                        onPurchaseSuccess(purchase.orderId ?: "")
                    }
                }
            } else {
                onPurchaseSuccess(purchase.orderId ?: "")
            }
        }
    }

    // 3. Restore Purchases (Query Active Purchases)
    fun queryPurchases() {
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()

        billingClient.queryPurchasesAsync(params) { billingResult, purchasesList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                for (purchase in purchasesList) {
                    if (purchase.products.contains(PRODUCT_ID_PREMIUM) &&
                        purchase.purchaseState == Purchase.PurchaseState.PURCHASED
                    ) {
                        onPurchaseSuccess(purchase.orderId ?: "")
                    }
                }
            }
        }
    }
}`;

const WEB_BRIDGE_SNIPPET = `// WebAppInterface.kt - Bridge between Web and Android Google Play Billing
package com.pictora.game

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.pictora.game.billing.BillingManager

class WebAppInterface(private val activity: MainActivity, private val webView: WebView) {

    private val billingManager = BillingManager(
        activity,
        onPurchaseSuccess = { orderId ->
            activity.runOnUiThread {
                // Call JavaScript function in the web game
                webView.evaluateJavascript("window.onGooglePlayPurchaseSuccess('\$orderId');", null)
            }
        },
        onPurchaseFailed = { errorMsg ->
            activity.runOnUiThread {
                webView.evaluateJavascript("window.onGooglePlayPurchaseFailed('\$errorMsg');", null)
            }
        }
    )

    @JavascriptInterface
    fun purchasePremium(productId: String) {
        activity.runOnUiThread {
            billingManager.launchPurchaseFlow(productId)
        }
    }

    @JavascriptInterface
    fun restorePurchases() {
        activity.runOnUiThread {
            billingManager.queryPurchases()
        }
    }
}

// In MainActivity.kt WebView setup:
// webView.addJavascriptInterface(WebAppInterface(this, webView), "AndroidBilling")`;

export const BillingDeveloperGuideModal: React.FC<BillingDeveloperGuideModalProps> = ({
  language,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'steps' | 'kotlin' | 'gradle' | 'bridge'>('steps');
  const [copied, setCopied] = useState<boolean>(false);

  const getCode = () => {
    if (activeTab === 'kotlin') return KOTLIN_BILLING_MANAGER;
    if (activeTab === 'gradle') return GRADLE_SNIPPET;
    if (activeTab === 'bridge') return WEB_BRIDGE_SNIPPET;
    return '';
  };

  const handleCopy = () => {
    sound.playClick();
    const code = getCode();
    if (code) {
      navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] text-slate-100"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                {language === 'ar'
                  ? 'دليل دمج Google Play Billing (IAP) - منتج غير قابل للاستهلاك ($2.50)'
                  : 'Google Play Billing Integration Guide - Non-Consumable ($2.50)'}
              </h3>
              <p className="text-xs text-slate-400">
                Product ID: <code className="text-amber-400 font-mono">pictora_premium_100_levels</code> · Type: Non-Consumable (In-App)
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 pt-3 pb-2 border-b border-slate-800 text-xs overflow-x-auto shrink-0">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('steps');
            }}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'steps' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'خطوات Google Play Console' : 'Play Console Steps'}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('kotlin');
            }}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'kotlin' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>BillingManager.kt</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('gradle');
            }}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'gradle' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>build.gradle</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('bridge');
            }}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'bridge' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>WebAppInterface.kt</span>
          </button>
        </div>

        {/* Tab 1: Step-by-Step Console Guide */}
        {activeTab === 'steps' && (
          <div className="overflow-y-auto py-4 flex flex-col gap-4 text-xs text-slate-300 pr-1">
            <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700">
              <h4 className="text-sm font-bold text-amber-400 mb-1 flex items-center gap-2">
                <span>1. إنشاء المنتج في Google Play Console</span>
              </h4>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-300 leading-relaxed">
                <li>سجل الدخول إلى <strong className="text-white">Google Play Console</strong> واختر تطبيق اللعبة.</li>
                <li>من القائمة الجانبية توجه إلى: <strong className="text-white">Monetize (تحقيق الدخل)</strong> → <strong className="text-white">In-app products (المنتجات داخل التطبيق)</strong>.</li>
                <li>انقر على زر <strong className="text-emerald-400">Create product (إنشاء منتج)</strong>.</li>
                <li>أدخل معرف المنتج (<strong className="text-white">Product ID</strong>): <code className="bg-slate-950 px-1 py-0.5 rounded text-amber-300 font-mono">pictora_premium_100_levels</code></li>
                <li>أدخل اسم المنتج: <strong className="text-white">باقة 100 مستوى مميز (100 Premium VIP Levels)</strong>.</li>
                <li>الوصف: <strong>فتح كامل لـ 100 مرحلة إضافية وتحديات بصرية حصرية للأبد</strong>.</li>
              </ol>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700">
              <h4 className="text-sm font-bold text-emerald-400 mb-1 flex items-center gap-2">
                <span>2. تحديد السعر وخاصية عدم الاستهلاك (Non-Consumable)</span>
              </h4>
              <p className="leading-relaxed text-slate-300 mb-2">
                في قسم السعر:
                <br />• حدد السعر الأساسي: <strong className="text-amber-300 font-bold font-mono">$2.50 USD</strong> وسيقوم غوغل بلاي تلقائيًا بتحويله لجميع عملات العالم بناءً على سعر الصرف والضرائب المحلية.
                <br />• تأكد من تفعيل المنتج: انقر على <strong className="text-white">Activate</strong>.
                <br />• <strong>هام جداً (Non-Consumable):</strong> المنتجات غير القابلة للاستهلاك يتم ربطها بحساب اللاعب عبر التأكيد (<code className="text-amber-300">acknowledgePurchase</code>) <strong>دون استهلاكها</strong> (<code className="text-rose-300">do not call consumeAsync</code>)، وبالتالي إذا حذف اللاعب اللعبة أو بدّل هاتفه يمكنه النقر على "استعادة المشتريات" وفتح المستويات فوراً!
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700">
              <h4 className="text-sm font-bold text-cyan-400 mb-1 flex items-center gap-2">
                <span>3. اختبار الدفع برخصة الاختبار (License Testing) مجانًا</span>
              </h4>
              <p className="leading-relaxed text-slate-300">
                لتجربة الدفع والشراء دون خصم أموال حقيقية:
                <br />• توجه إلى: <strong className="text-white">Setup → License Testing</strong>.
                <br />• أضف بريدك الإلكتروني كـ مختبر مرخص: <code className="bg-slate-950 px-1.5 py-0.5 rounded text-cyan-300 font-mono">idrissjaune04@gmail.com</code>.
                <br />• عند تجربة الشراء على هاتفك، ستظهر بطاقة Google Play الاختبارية (<strong className="text-white">Test Card, always approves</strong>).
              </p>
            </div>
          </div>
        )}

        {/* Tab 2, 3, 4: Code Viewer */}
        {activeTab !== 'steps' && (
          <div className="flex-1 flex flex-col rounded-xl border border-slate-800 bg-slate-950 overflow-hidden my-3">
            <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-xs">
              <span className="font-mono text-slate-400">
                {activeTab === 'kotlin' ? 'BillingManager.kt' : activeTab === 'gradle' ? 'build.gradle' : 'WebAppInterface.kt'}
              </span>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-200 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
              </button>
            </div>

            <pre className="p-4 text-[11px] font-mono text-emerald-300 overflow-auto flex-1 leading-relaxed whitespace-pre selection:bg-amber-500/30">
              {getCode()}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
