import React, { useState } from 'react';
import { X, Trophy, Medal, Cloud, Check } from 'lucide-react';
import { Language, UserProgress } from '../types/game';
import { TRANSLATIONS } from '../utils/translations';
import { ACHIEVEMENTS, INITIAL_LEADERBOARD } from '../data/googlePlayData';
import { sound } from '../utils/audio';

interface GooglePlayModalProps {
  progress: UserProgress;
  language: Language;
  onClose: () => void;
  onUpdateGamerTag: (newTag: string) => void;
}

export const GooglePlayModal: React.FC<GooglePlayModalProps> = ({
  progress,
  language,
  onClose,
  onUpdateGamerTag,
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'achievements' | 'leaderboard'>('achievements');
  const [isEditingTag, setIsEditingTag] = useState<boolean>(false);
  const [tempTag, setTempTag] = useState<string>(progress.gamerTag);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncedSuccess, setSyncedSuccess] = useState<boolean>(false);

  const handleSyncCloud = () => {
    sound.playClick();
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncedSuccess(true);
      setTimeout(() => setSyncedSuccess(false), 3000);
    }, 1200);
  };

  const handleSaveTag = () => {
    if (tempTag.trim()) {
      onUpdateGamerTag(tempTag.trim());
      setIsEditingTag(false);
      sound.playClick();
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[88vh]"
      >
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title={t.close}
        >
          <X className="w-5 h-5" />
        </button>

        {/* Google Play Profile Card */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shadow-emerald-500/20">
              🎮
            </div>
            <div>
              <div className="flex items-center gap-2">
                {isEditingTag ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={tempTag}
                      onChange={(e) => setTempTag(e.target.value)}
                      className="bg-slate-800 border border-slate-600 rounded px-2 py-0.5 text-xs text-white"
                      maxLength={18}
                    />
                    <button
                      onClick={handleSaveTag}
                      className="px-2 py-0.5 bg-emerald-600 text-xs text-white rounded font-bold"
                    >
                      OK
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 className="text-base font-bold text-white">{progress.gamerTag}</h3>
                    <button
                      onClick={() => setIsEditingTag(true)}
                      className="text-[11px] text-slate-500 hover:text-amber-400 transition-colors underline"
                    >
                      (تعديل)
                    </button>
                  </>
                )}
              </div>
              <p className="text-xs text-emerald-400 flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>{t.connected}</span>
              </p>
            </div>
          </div>

          {/* Cloud Save Sync Button */}
          <button
            onClick={handleSyncCloud}
            disabled={isSyncing}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-medium text-slate-300 hover:text-white border border-slate-700 transition-all"
          >
            <Cloud className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-400' : 'text-cyan-400'}`} />
            <span>{syncedSuccess ? 'Cloud Saved ✓' : isSyncing ? 'Syncing...' : t.syncCloud}</span>
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 mt-4 mb-3 border-b border-slate-800 pb-2">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('achievements');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'achievements'
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>{t.achievements}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('leaderboard');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'leaderboard'
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Medal className="w-3.5 h-3.5" />
            <span>{t.leaderboard}</span>
          </button>
        </div>

        {/* Tab 1: Achievements */}
        {activeTab === 'achievements' && (
          <div className="flex flex-col gap-2.5 overflow-y-auto pr-1">
            {ACHIEVEMENTS.map((ach) => {
              const isUnlocked = progress.unlockedAchievements.includes(ach.id);
              return (
                <div
                  key={ach.id}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                    isUnlocked
                      ? 'bg-slate-800/80 border-amber-500/30 text-white'
                      : 'bg-slate-950/50 border-slate-800 text-slate-500 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg ${
                        isUnlocked
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                          : 'bg-slate-900 border border-slate-800 text-slate-600'
                      }`}
                    >
                      {isUnlocked ? <Medal className="w-5 h-5 text-amber-400" /> : <Trophy className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-200">{ach.title[language]}</h4>
                      <p className="text-xs text-slate-400">{ach.desc[language]}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-amber-400 font-bold">
                      +{ach.xp} XP
                    </span>
                    {isUnlocked && <Check className="w-4 h-4 text-emerald-400" />}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 2: Leaderboard */}
        {activeTab === 'leaderboard' && (
          <div className="flex flex-col gap-2 overflow-y-auto pr-1">
            {INITIAL_LEADERBOARD.map((entry) => {
              const isUser = entry.isCurrentUser;
              return (
                <div
                  key={entry.rank}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs font-mono transition-all ${
                    isUser
                      ? 'bg-amber-500/10 border-amber-500/50 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`w-6 text-center font-bold ${
                        entry.rank === 1
                          ? 'text-amber-400'
                          : entry.rank === 2
                          ? 'text-slate-300'
                          : entry.rank === 3
                          ? 'text-amber-600'
                          : 'text-slate-500'
                      }`}
                    >
                      #{entry.rank}
                    </span>
                    <span className="text-base">{entry.avatar}</span>
                    <span className="font-sans font-bold text-slate-200">
                      {isUser ? progress.gamerTag : entry.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="text-slate-500 font-sans">
                      {t.levels} {entry.level}
                    </span>
                    <span className="font-bold text-emerald-400 tabular-nums">
                      {entry.score.toLocaleString()} {t.pts}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
