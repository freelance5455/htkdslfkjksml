/**
 * Generates thematic high-definition vector scenes and data URIs for all 60 puzzle levels.
 * Guarantees zero network latency, zero broken images, and crisp rendering at any resolution.
 */

interface SceneConfig {
  bgGradient: [string, string];
  accentColor: string;
  iconSvg: string;
  title: string;
}

export function createThemedVectorImage(
  title: string,
  gradientStart: string,
  gradientEnd: string,
  accentColor: string,
  symbolPath: string,
  detailPaths: string = ''
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" width="500" height="500">
    <defs>
      <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${gradientStart}" />
        <stop offset="100%" stop-color="${gradientEnd}" />
      </linearGradient>
      <radialGradient id="glowGrad" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="${accentColor}" stop-opacity="0.3" />
        <stop offset="100%" stop-color="${accentColor}" stop-opacity="0" />
      </radialGradient>
      <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000000" flood-opacity="0.5"/>
      </filter>
    </defs>
    <!-- Background Canvas -->
    <rect width="500" height="500" rx="24" fill="url(#bgGrad)" />
    <!-- Ambient Glow Centerpiece -->
    <circle cx="250" cy="240" r="180" fill="url(#glowGrad)" />
    <!-- Geometric frame accents -->
    <rect x="25" y="25" width="450" height="450" rx="18" fill="none" stroke="${accentColor}" stroke-opacity="0.15" stroke-width="2" />
    <circle cx="250" cy="240" r="140" fill="none" stroke="${accentColor}" stroke-opacity="0.2" stroke-width="1.5" stroke-dasharray="8 6"/>
    <!-- Thematic Details -->
    <g filter="url(#softShadow)">
      ${detailPaths}
    </g>
    <!-- Core Icon / Symbol Graphic -->
    <g transform="translate(150, 140) scale(4.16)" filter="url(#softShadow)">
      ${symbolPath}
    </g>
    <!-- Card Watermark Title -->
    <text x="250" y="440" font-family="'Cairo', 'Outfit', sans-serif" font-size="20" font-weight="bold" fill="#ffffff" fill-opacity="0.9" text-anchor="middle" letter-spacing="2">
      ${title}
    </text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
