import { Achievement, LeaderboardEntry } from '../types/game';

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_solve',
    title: { ar: 'المستكشف الأول', en: 'First Discovery', fr: 'Première Découverte' },
    desc: { ar: 'حل أول لغز صور بنجاح', en: 'Solve your very first photo puzzle', fr: 'Résolvez votre tout premier puzzle photo' },
    icon: 'Trophy',
    xp: 500,
    targetCount: 1,
  },
  {
    id: 'streak_3',
    title: { ar: 'المواظب المتألق', en: 'Daily Challenger', fr: 'Challenger Assidu' },
    desc: { ar: 'تسجيل دخول متواصل لمدة 3 أيام', en: 'Maintain a 3-day daily streak', fr: 'Maintenez une série de 3 jours consécutifs' },
    icon: 'Flame',
    xp: 1000,
    targetCount: 3,
  },
  {
    id: 'slider_master',
    title: { ar: 'خبير الترتيب', en: 'Slider Virtuoso', fr: 'Maître du Glissement' },
    desc: { ar: 'إكمال لغز بازل الشرائح بمهارة', en: 'Complete an image sliding tile challenge', fr: 'Complétez un défi de puzzle à glissière' },
    icon: 'Grid',
    xp: 1500,
    targetCount: 1,
  },
  {
    id: 'hintless_pro',
    title: { ar: 'العبقري المستقل', en: 'Pure Mind', fr: 'Esprit Pur' },
    desc: { ar: 'حل 3 مستويات دون استخدام أي تلميح', en: 'Solve 3 levels without using hints', fr: 'Résolvez 3 niveaux sans aucun indice' },
    icon: 'Brain',
    xp: 2000,
    targetCount: 3,
  },
  {
    id: 'star_collector',
    title: { ar: 'جامع النجوم الفلكي', en: 'Star Champion', fr: 'Champion des Étoiles' },
    desc: { ar: 'جمع 15 نجمة ذهبية عبر المستويات', en: 'Collect 15 gold stars across levels', fr: 'Collectez 15 étoiles d’or dans les niveaux' },
    icon: 'Star',
    xp: 3000,
    targetCount: 15,
  },
];

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, name: 'Tarek_Sultan', avatar: '👑', score: 14850, level: 10 },
  { rank: 2, name: 'Elena_Vortex', avatar: '⚡', score: 13200, level: 9 },
  { rank: 3, name: 'Karim_Playz', avatar: '🎮', score: 11900, level: 8 },
  { rank: 4, name: 'You (Player)', avatar: '🚀', score: 8500, level: 5, isCurrentUser: true },
  { rank: 5, name: 'Sophie_L', avatar: '🌸', score: 7920, level: 5 },
  { rank: 6, name: 'Alex_Gamer', avatar: '🎯', score: 6400, level: 4 },
  { rank: 7, name: 'Nour_Egypt', avatar: '🏛️', score: 5300, level: 3 },
  { rank: 8, name: 'Marco_Dev', avatar: '💻', score: 4100, level: 3 },
];
