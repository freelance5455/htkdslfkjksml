import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Play, Grid, Flame, Trophy, Volume2, VolumeX, Globe, ShoppingBag, Sparkles } from 'lucide-react';
import { Language, UserProgress } from './types/game';
import { PUZZLE_LEVELS, FREE_LEVELS_COUNT, PREMIUM_LEVELS_COUNT, TOTAL_LEVELS_COUNT } from './data/puzzles';
import { TRANSLATIONS } from './utils/translations';
import { sound } from './utils/audio';
import { GameHUD } from './components/GameHUD';
import { WordPuzzleMode } from './components/WordPuzzleMode';
import { JigsawPuzzleMode } from './components/JigsawPuzzleMode';
import { MysteryScratchMode } from './components/MysteryScratchMode';
import { HintModal } from './components/HintModal';
import { LevelSelectModal } from './components/LevelSelectModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { GooglePlayModal } from './components/GooglePlayModal';
import { GooglePlayBillingModal } from './components/GooglePlayBillingModal';
import { BillingDeveloperGuideModal } from './components/BillingDeveloperGuideModal';
import { VictoryModal } from './components/VictoryModal';
import { LandscapeNotice } from './components/LandscapeNotice';

type ScreenState = 'TITLE' | 'PLAYING';

const DEFAULT_PROGRESS: UserProgress = {
  coins: 300,
  hintsRemaining: 3,
  unlockedLevel: 1,
  levelScores: {},
  streakDays: 1,
  lastDailyClaim: null,
  unlockedAchievements: ['first_solve'],
  googlePlayId: 'player_id_9921',
  gamerTag: 'Alex_Gamer',
  isPremiumUnlocked: false,
};

export default function App() {
  const [screen, setScreen] = useState<ScreenState>('TITLE');
  const [language, setLanguage] = useState<Language>('ar');
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Active level state
  const [currentLevelId, setCurrentLevelId] = useState<number>(1);
  const [levelStartTime, setLevelStartTime] = useState<number>(Date.now());
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [score, setScore] = useState<number>(0);

  // User persistent progress
  const [progress, setProgress] = useState<UserProgress>(() => {
    try {
      const saved = localStorage.getItem('pictora_user_progress_v3');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return DEFAULT_PROGRESS;
  });

  // Modals state
  const [showHintModal, setShowHintModal] = useState<boolean>(false);
  const [showLevelModal, setShowLevelModal] = useState<boolean>(false);
  const [showDailyModal, setShowDailyModal] = useState<boolean>(false);
  const [showGooglePlayModal, setShowGooglePlayModal] = useState<boolean>(false);
  const [showBillingModal, setShowBillingModal] = useState<boolean>(false);
  const [showDevGuideModal, setShowDevGuideModal] = useState<boolean>(false);
  const [showVictoryModal, setShowVictoryModal] = useState<boolean>(false);

  // In-level hint modifications
  const [removedBankIndices, setRemovedBankIndices] = useState<number[]>([]);
  const [revealedPositions, setRevealedPositions] = useState<Record<number, string>>({});
  const [victoryStats, setVictoryStats] = useState<{
    stars: number;
    scoreEarned: number;
    coinsEarned: number;
    timeSpent: number;
  }>({ stars: 3, scoreEarned: 500, coinsEarned: 50, timeSpent: 20 });

  const t = TRANSLATIONS[language];
  const isRtl = language === 'ar';

  // Save progress on change
  useEffect(() => {
    localStorage.setItem('pictora_user_progress_v3', JSON.stringify(progress));
  }, [progress]);

  // Sync document title and direction
  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language, isRtl]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Timer loop when playing
  useEffect(() => {
    if (screen !== 'PLAYING' || showVictoryModal) return;

    const timer = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - levelStartTime) / 1000));
    }, 1000);

    return () => clearInterval(timer);
  }, [screen, levelStartTime, showVictoryModal]);

  // Global Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (screen === 'TITLE') {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          startPlayLevel(progress.unlockedLevel);
        } else if (e.key === 'l' || e.key === 'L') {
          setShowLevelModal(true);
        } else if (e.key === 'g' || e.key === 'G') {
          setShowGooglePlayModal(true);
        } else if (e.key === 'p' || e.key === 'P') {
          setShowBillingModal(true);
        }
      } else if (e.key === 'Escape') {
        if (showHintModal) setShowHintModal(false);
        else if (showVictoryModal) setShowVictoryModal(false);
        else if (showBillingModal) setShowBillingModal(false);
        else setScreen('TITLE');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screen, showHintModal, showVictoryModal, showBillingModal, progress.unlockedLevel]);

  const currentLevel = useMemo(() => {
    return PUZZLE_LEVELS.find((l) => l.id === currentLevelId) || PUZZLE_LEVELS[0];
  }, [currentLevelId]);

  const startPlayLevel = (lvlId: number) => {
    const targetLvl = PUZZLE_LEVELS.find((l) => l.id === lvlId) || PUZZLE_LEVELS[0];

    // If level is in the 100 Premium expansion and user hasn't bought it yet
    if (targetLvl.isPremium && !progress.isPremiumUnlocked) {
      sound.playError();
      setShowBillingModal(true);
      return;
    }

    sound.playClick();
    setCurrentLevelId(lvlId);
    setLevelStartTime(Date.now());
    setElapsedTime(0);
    setRemovedBankIndices([]);
    setRevealedPositions({});
    setShowVictoryModal(false);
    setScreen('PLAYING');
  };

  const handleToggleMute = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  const handleToggleFullscreen = () => {
    sound.playClick();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleLevelSolved = useCallback(() => {
    const timeSpent = Math.max(1, Math.floor((Date.now() - levelStartTime) / 1000));
    let starsEarned = 3;
    if (timeSpent > 50 || Object.keys(revealedPositions).length > 2) {
      starsEarned = 2;
    }
    if (timeSpent > 100) {
      starsEarned = 1;
    }

    const coinsEarned = 50 + starsEarned * 10;
    const scoreEarned = Math.max(100, 1000 - timeSpent * 10 + starsEarned * 200);

    setScore((s) => s + scoreEarned);
    setVictoryStats({
      stars: starsEarned,
      scoreEarned,
      coinsEarned,
      timeSpent,
    });

    // Update progress
    setProgress((prev) => {
      // Don't auto-unlock beyond free limit (100) if premium isn't bought
      let nextUnlocked = prev.unlockedLevel;
      if (currentLevelId === prev.unlockedLevel) {
        if (currentLevelId < FREE_LEVELS_COUNT) {
          nextUnlocked = currentLevelId + 1;
        } else if (currentLevelId >= FREE_LEVELS_COUNT && prev.isPremiumUnlocked) {
          nextUnlocked = Math.min(TOTAL_LEVELS_COUNT, currentLevelId + 1);
        }
      }

      const currentLevelScore = prev.levelScores[currentLevelId];
      const bestStars = currentLevelScore ? Math.max(currentLevelScore.stars, starsEarned) : starsEarned;
      const bestTime = currentLevelScore ? Math.min(currentLevelScore.bestTime, timeSpent) : timeSpent;

      const newScores = {
        ...prev.levelScores,
        [currentLevelId]: {
          stars: bestStars,
          bestTime,
          completedAt: new Date().toISOString(),
        },
      };

      // Check achievements
      const newAchievements = [...prev.unlockedAchievements];
      if (!newAchievements.includes('first_solve')) newAchievements.push('first_solve');
      if (currentLevel.mode === 'sliding_tiles' && !newAchievements.includes('slider_master')) {
        newAchievements.push('slider_master');
      }

      const totalStars = Object.values(newScores).reduce((acc, val) => acc + val.stars, 0);
      if (totalStars >= 15 && !newAchievements.includes('star_collector')) {
        newAchievements.push('star_collector');
      }

      return {
        ...prev,
        coins: prev.coins + coinsEarned,
        unlockedLevel: nextUnlocked,
        levelScores: newScores,
        unlockedAchievements: newAchievements,
      };
    });

    setShowVictoryModal(true);
  }, [currentLevelId, currentLevel.mode, levelStartTime, revealedPositions]);

  // Hint handlers
  const handleRevealLetter = () => {
    const target = currentLevel.answer[language].toUpperCase().replace(/\s+/g, '');
    for (let i = 0; i < target.length; i++) {
      if (!revealedPositions[i]) {
        setRevealedPositions((prev) => ({ ...prev, [i]: target[i] }));
        setProgress((prev) => ({
          ...prev,
          hintsRemaining: prev.hintsRemaining > 0 ? prev.hintsRemaining - 1 : prev.hintsRemaining,
          coins: prev.hintsRemaining > 0 ? prev.coins : Math.max(0, prev.coins - 50),
        }));
        break;
      }
    }
  };

  const handleRemoveDecoys = () => {
    setRemovedBankIndices([0, 1, 2]);
    setProgress((prev) => ({
      ...prev,
      hintsRemaining: prev.hintsRemaining > 0 ? prev.hintsRemaining - 1 : prev.hintsRemaining,
      coins: prev.hintsRemaining > 0 ? prev.coins : Math.max(0, prev.coins - 30),
    }));
  };

  const handleAutoSolve = () => {
    setProgress((prev) => ({
      ...prev,
      coins: Math.max(0, prev.coins - 100),
    }));
    handleLevelSolved();
  };

  const handleClaimDaily = (coinsToAdd: number, hintsToAdd: number) => {
    const todayStr = new Date().toISOString().slice(0, 10);
    setProgress((prev) => ({
      ...prev,
      coins: prev.coins + coinsToAdd,
      hintsRemaining: prev.hintsRemaining + hintsToAdd,
      streakDays: prev.streakDays + 1,
      lastDailyClaim: todayStr,
      unlockedAchievements:
        prev.streakDays + 1 >= 3 && !prev.unlockedAchievements.includes('streak_3')
          ? [...prev.unlockedAchievements, 'streak_3']
          : prev.unlockedAchievements,
    }));
  };

  const handleUnlockPremiumSuccess = () => {
    setProgress((prev) => ({
      ...prev,
      isPremiumUnlocked: true,
      coins: prev.coins + 500, // VIP bonus coins!
      hintsRemaining: prev.hintsRemaining + 5,
    }));
    setShowBillingModal(false);
  };

  const todayStr = new Date().toISOString().slice(0, 10);
  const isDailyClaimed = progress.lastDailyClaim === todayStr;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 text-slate-100 flex flex-col select-none">
      {/* Mobile Landscape Orientation Notice */}
      <LandscapeNotice language={language} />

      {/* ================= TITLE SCREEN ================= */}
      {screen === 'TITLE' && (
        <main className="relative w-full h-full flex flex-col justify-between p-4 sm:p-6 overflow-hidden">
          {/* Visual backdrop */}
          <div className="absolute inset-0 z-0">
            <div
              className="w-full h-full bg-cover bg-center filter brightness-45 blur-[1px] transition-transform duration-1000 scale-105"
              style={{
                backgroundImage: `url('/src/assets/images/puzzle_astronaut_1793564534097.jpg')`,
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/40" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(245,158,11,0.08)_0%,rgba(15,23,42,0.8)_80%)]" />
          </div>

          {/* Top Bar on Title Screen: Stats, Level Quick-Link, Premium IAP button & Toggles */}
          <div className="relative z-10 w-full flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-700/80 backdrop-blur-md flex items-center gap-2 text-xs font-mono">
                <span className="text-amber-400 font-bold">🪙 {progress.coins}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-cyan-400">💡 {progress.hintsRemaining}</span>
              </div>

              {/* Clickable Level Quick-Link */}
              <button
                onClick={() => {
                  sound.playClick();
                  setShowLevelModal(true);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-400/50 backdrop-blur-md flex items-center gap-1.5 text-xs text-emerald-400 font-bold transition-all active:scale-95 cursor-pointer"
                title={t.levels}
              >
                <Grid className="w-3.5 h-3.5" />
                <span>
                  {language === 'ar'
                    ? `${t.levelSingle} ${progress.unlockedLevel} ${t.of} 100`
                    : `${t.levelSingle} ${progress.unlockedLevel} ${t.of} 100`}
                </span>
              </button>

              {/* Google Play Premium Pack Status Button */}
              <button
                onClick={() => {
                  sound.playClick();
                  setShowBillingModal(true);
                }}
                className={`px-3 py-1.5 rounded-xl border backdrop-blur-md flex items-center gap-1.5 text-xs font-bold transition-all active:scale-95 cursor-pointer ${
                  progress.isPremiumUnlocked
                    ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                    : 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border-amber-500/50 text-amber-300 hover:brightness-125'
                }`}
                title="Google Play Billing"
              >
                <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {progress.isPremiumUnlocked ? 'VIP Active ✓' : 'Premium $2.50'}
                </span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              {/* Language Selector: Arabic, English, French */}
              <div className="flex items-center bg-slate-900/80 border border-slate-700/80 rounded-xl p-0.5 backdrop-blur-md">
                <button
                  onClick={() => {
                    sound.playClick();
                    setLanguage('ar');
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    language === 'ar' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  عربي
                </button>
                <button
                  onClick={() => {
                    sound.playClick();
                    setLanguage('en');
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    language === 'en' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  EN
                </button>
                <button
                  onClick={() => {
                    sound.playClick();
                    setLanguage('fr');
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    language === 'fr' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  FR
                </button>
              </div>

              {/* Mute Audio Toggle */}
              <button
                onClick={handleToggleMute}
                className="p-2 rounded-xl bg-slate-900/80 border border-slate-700/80 backdrop-blur-md text-slate-300 hover:text-white transition-colors"
                title={isMuted ? t.unmute : t.mute}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>
          </div>

          {/* Center Stage: Title Lockup & Action CTAs */}
          <div className="relative z-10 flex flex-col items-center justify-center text-center my-auto">
            {/* Inline SVG Title Lockup */}
            <div className="relative mb-2 sm:mb-3 flex items-center justify-center">
              <svg width="60" height="60" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-[0_0_25px_rgba(245,158,11,0.5)]">
                <rect x="8" y="8" width="48" height="48" rx="14" stroke="#F59E0B" strokeWidth="2.5" fill="rgba(15,23,42,0.9)" />
                <path d="M18 36L26 26L36 38L42 31L46 36" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="25" cy="22" r="3.5" fill="#F59E0B" />
                <circle cx="45" cy="18" r="2" fill="#10B981" />
              </svg>
            </div>

            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 tracking-tight drop-shadow-md mb-1 sm:mb-2">
              {t.gameTitle}
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mb-4 sm:mb-6 leading-relaxed font-medium">
              {t.tagline}
            </p>

            {/* Main Action Buttons: Play Now + Select Level + Premium Pack */}
            <div className="flex items-center gap-3 sm:gap-4 flex-wrap justify-center">
              {/* Primary Start Play Button */}
              <button
                onClick={() => startPlayLevel(progress.unlockedLevel)}
                className="group relative px-6 sm:px-8 py-3 sm:py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 text-slate-950 font-black text-sm sm:text-base md:text-lg flex items-center gap-2.5 shadow-2xl shadow-amber-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-slate-950 flex items-center justify-center text-amber-400 group-hover:translate-x-0.5 transition-transform">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
                <span>{t.play}</span>
              </button>

              {/* Levels Button (200 Stages) */}
              <button
                onClick={() => {
                  sound.playClick();
                  setShowLevelModal(true);
                }}
                className="px-5 sm:px-6 py-3 sm:py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-400/50 text-slate-200 font-bold text-sm sm:text-base flex items-center gap-2 shadow-xl hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                <Grid className="w-4 h-4 text-cyan-400" />
                <span>{t.levels} (200)</span>
              </button>

              {/* 100 Premium VIP Button */}
              <button
                onClick={() => {
                  sound.playClick();
                  setShowBillingModal(true);
                }}
                className="px-4 sm:px-5 py-3 sm:py-3.5 rounded-2xl bg-gradient-to-r from-amber-950/80 to-slate-900 border border-amber-500/60 hover:border-amber-400 text-amber-300 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-xl hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4 text-amber-400" />
                <span>
                  {progress.isPremiumUnlocked
                    ? (language === 'ar' ? 'باقة VIP مفعلة' : 'VIP Unlocked')
                    : (language === 'ar' ? '100 مرحلة VIP بـ $2.50' : '100 VIP ($2.50)')}
                </span>
              </button>
            </div>

            {/* Flat control-hint line */}
            <p className="text-[10px] sm:text-[11px] text-slate-400 font-mono mt-3 sm:mt-4">
              Enter / Space to Play · L Levels · P Premium $2.50 · G Hall of Fame
            </p>
          </div>

          {/* Bottom Bar: Quick Features (Daily Reward, Hall of Fame) */}
          <div className="relative z-10 w-full flex items-center justify-center gap-3 flex-wrap">
            {/* Daily Reward Button with Streak Flame */}
            <button
              onClick={() => {
                sound.playClick();
                setShowDailyModal(true);
              }}
              className="relative flex items-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-xs font-bold text-slate-200 transition-all hover:border-amber-400/50"
            >
              <Flame className="w-4 h-4 text-amber-400" />
              <span>{t.dailyReward}</span>
              {!isDailyClaimed && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping absolute -top-1 -right-1" />
              )}
            </button>

            {/* Hall of Fame / Leaderboard & Achievements */}
            <button
              onClick={() => {
                sound.playClick();
                setShowGooglePlayModal(true);
              }}
              className="flex items-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-xs font-bold text-slate-200 transition-all hover:border-emerald-400/50"
            >
              <Trophy className="w-4 h-4 text-emerald-400" />
              <span>{t.googlePlay}</span>
            </button>
          </div>
        </main>
      )}

      {/* ================= ACTIVE PLAYING SCREEN ================= */}
      {screen === 'PLAYING' && (
        <main className="relative w-full h-full flex flex-col justify-between overflow-hidden">
          {/* Top HUD with interactive Level button */}
          <GameHUD
            currentLevel={currentLevel}
            totalLevels={currentLevel.isPremium ? TOTAL_LEVELS_COUNT : FREE_LEVELS_COUNT}
            score={score}
            coins={progress.coins}
            hintsRemaining={progress.hintsRemaining}
            language={language}
            onSetLanguage={setLanguage}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onBackToMenu={() => {
              sound.playClick();
              setScreen('TITLE');
            }}
            onOpenLevelModal={() => setShowLevelModal(true)}
            onOpenHintModal={() => setShowHintModal(true)}
            isFullscreen={isFullscreen}
            onToggleFullscreen={handleToggleFullscreen}
            elapsedTime={elapsedTime}
          />

          {/* Active Mode Gameplay Container */}
          <div className="relative flex-1 w-full h-full overflow-hidden flex items-center justify-center p-2">
            {currentLevel.mode === 'word_puzzle' && (
              <WordPuzzleMode
                level={currentLevel}
                language={language}
                onSolve={handleLevelSolved}
                removedBankIndices={removedBankIndices}
                revealedPositions={revealedPositions}
              />
            )}

            {currentLevel.mode === 'sliding_tiles' && (
              <JigsawPuzzleMode
                level={currentLevel}
                language={language}
                onSolve={handleLevelSolved}
              />
            )}

            {currentLevel.mode === 'mystery_scratch' && (
              <MysteryScratchMode
                level={currentLevel}
                language={language}
                onSolve={handleLevelSolved}
              />
            )}
          </div>
        </main>
      )}

      {/* ================= MODALS ================= */}
      {showHintModal && (
        <HintModal
          language={language}
          coins={progress.coins}
          hintsRemaining={progress.hintsRemaining}
          onClose={() => setShowHintModal(false)}
          onRevealLetter={handleRevealLetter}
          onRemoveDecoys={handleRemoveDecoys}
          onAutoSolve={handleAutoSolve}
        />
      )}

      {showLevelModal && (
        <LevelSelectModal
          levels={PUZZLE_LEVELS}
          progress={progress}
          currentLevelId={currentLevelId}
          language={language}
          onSelectLevel={(lvlId) => {
            setShowLevelModal(false);
            startPlayLevel(lvlId);
          }}
          onOpenPremiumModal={() => {
            setShowLevelModal(false);
            setShowBillingModal(true);
          }}
          onClose={() => setShowLevelModal(false)}
        />
      )}

      {showBillingModal && (
        <GooglePlayBillingModal
          language={language}
          userEmail="idrissjaune04@gmail.com"
          onSuccess={handleUnlockPremiumSuccess}
          onOpenDevGuide={() => setShowDevGuideModal(true)}
          onClose={() => setShowBillingModal(false)}
        />
      )}

      {showDevGuideModal && (
        <BillingDeveloperGuideModal
          language={language}
          onClose={() => setShowDevGuideModal(false)}
        />
      )}

      {showDailyModal && (
        <DailyRewardModal
          progress={progress}
          language={language}
          onClaim={handleClaimDaily}
          onClose={() => setShowDailyModal(false)}
        />
      )}

      {showGooglePlayModal && (
        <GooglePlayModal
          progress={progress}
          language={language}
          onClose={() => setShowGooglePlayModal(false)}
          onUpdateGamerTag={(newTag) => {
            setProgress((p) => ({ ...p, gamerTag: newTag }));
          }}
        />
      )}

      {showVictoryModal && (
        <VictoryModal
          level={currentLevel}
          stars={victoryStats.stars}
          score={victoryStats.scoreEarned}
          coinsEarned={victoryStats.coinsEarned}
          timeSpent={victoryStats.timeSpent}
          hasNextLevel={currentLevelId < TOTAL_LEVELS_COUNT}
          language={language}
          onNextLevel={() => {
            const nextId = currentLevelId + 1;
            const nextLvl = PUZZLE_LEVELS.find((l) => l.id === nextId);
            if (nextLvl && nextLvl.isPremium && !progress.isPremiumUnlocked) {
              setShowVictoryModal(false);
              setShowBillingModal(true);
            } else if (nextId <= TOTAL_LEVELS_COUNT) {
              startPlayLevel(nextId);
            }
          }}
          onRetry={() => {
            startPlayLevel(currentLevelId);
          }}
          onBackToMenu={() => {
            setShowVictoryModal(false);
            setScreen('TITLE');
          }}
          onOpenLevelModal={() => {
            setShowVictoryModal(false);
            setShowLevelModal(true);
          }}
        />
      )}
    </div>
  );
}
