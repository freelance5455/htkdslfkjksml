TRUVORA WEB APP
===============

Open index.html in a modern browser or host the files over HTTPS.
This package includes a local account gate. The account is only stored on this device.
The Android Studio source is provided separately in the release candidate ZIP.
It is not a compiled APK yet.
