plugins { id("com.android.application") }

android {
    namespace = "com.truvora.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.truvora.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}


dependencies {
    implementation("com.google.android.gms:play-services-ads:24.6.0")
}
