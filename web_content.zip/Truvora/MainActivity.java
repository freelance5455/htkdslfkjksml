package com.truvora.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;

public class MainActivity extends Activity {
    private WebView webView;
    private AppOpenAd appOpenAd;
    private boolean adShowing = false;
    private boolean attemptedAdThisLaunch = false;
    // Google-provided TEST app-open ad unit. Replace with your own approved unit before release.
    private static final String APP_OPEN_AD_UNIT = "ca-app-pub-3940256099942544/9257395921";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl("file:///android_asset/index.html");
        MobileAds.initialize(this, status -> { });
        loadAppOpenAd();
    }

    private void loadAppOpenAd() {
        if (attemptedAdThisLaunch) return;
        attemptedAdThisLaunch = true;
        AppOpenAd.load(this, APP_OPEN_AD_UNIT, new AdRequest.Builder().build(),
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            new AppOpenAd.AppOpenAdLoadCallback() {
                @Override public void onAdLoaded(AppOpenAd ad) {
                    appOpenAd = ad;
                    // Do not force an interstitial over account creation. Show only after activity is ready.
                    if (!isFinishing() && !adShowing) showAppOpenAd();
                }
                @Override public void onAdFailedToLoad(LoadAdError error) { appOpenAd = null; }
            });
    }

    private void showAppOpenAd() {
        if (appOpenAd == null || adShowing || isFinishing()) return;
        adShowing = true;
        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                adShowing = false;
                appOpenAd = null;
            }
            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                adShowing = false;
                appOpenAd = null;
            }
        });
        appOpenAd.show(this);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
