TRUVORA ANDROID PROJECT — BUILD CANDIDATE
=========================================

This is Android Studio source code, not a compiled APK/AAB.

Features included:
- Updated black-and-white Truvora UI with larger cards and motion effects.
- Local device account creation and sign-in. Passwords are PBKDF2/SHA-256 hashed locally.
- App-open ad integration using Google's official TEST ad unit only.
- Existing finance tracker and notes remain local to this device.

IMPORTANT:
- The account is local-only; it does not sync to another phone and is not a cloud identity system.
- Back up your data before clearing app storage or uninstalling.
- Ads currently use Google's TEST IDs. Replace with your own AdMob app ID and ad unit only after creating an AdMob account and completing consent/privacy setup. Never publish using test ad IDs.
- This project requests internet permission for ad loading. Finance records are not intentionally sent to an ad service.
- Do not force two consecutive full-screen ads on app launch. This project includes one app-open ad opportunity per launch; ad loading may fail or the ad may not show. Follow current AdMob policies and provide a suitable privacy policy/consent flow before release.
- The project has not been built or device-tested in this environment. Open it in Android Studio, sync Gradle, build a debug APK, test on devices, then create a signed AAB for Play Store.
- Before public release, review privacy, account security, target SDK requirements, app content, ads disclosure, and Play Console rules.
