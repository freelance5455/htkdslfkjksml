const works = [
  {id:1,title:"ظلّ القمر",type:"مانغا",status:"مستمر",genres:["فانتازيا","مغامرة"],rating:"9.2",symbol:"月",colors:["#48236c","#111020"],description:"رحلة خيالية لشابة تكتشف أن ظلال المدينة تخفي بوابة إلى عالم منسي. هذا العمل تجريبي أصلي صُمّم لعرض واجهة التطبيق."},
  {id:2,title:"صعود الصيّاد",type:"مانهوا",status:"مستمر",genres:["أكشن","خيال"],rating:"9.5",symbol:"狩",colors:["#6c234e","#160c1d"],description:"في عالم تتفتح فيه بوابات غامضة، يبدأ صياد مبتدئ رحلته لاكتشاف قوته الحقيقية. هذا العمل تجريبي أصلي."},
  {id:3,title:"حديقة النجوم",type:"مانغا",status:"مكتمل",genres:["شريحة من الحياة","دراما"],rating:"8.8",symbol:"星",colors:["#24566b","#0d1726"],description:"قصة هادئة عن صداقة تنمو تحت سماء مرصعة بالنجوم. هذا العمل تجريبي أصلي."},
  {id:4,title:"آخر تنين",type:"مانهوا",status:"مستمر",genres:["أكشن","فانتازيا"],rating:"9.1",symbol:"竜",colors:["#753d25","#190d17"],description:"شاب يحمل سرّ آخر تنين حي ويحاول حماية مملكته من حرب قديمة. هذا العمل تجريبي أصلي."},
  {id:5,title:"رسائل الربيع",type:"مانغا",status:"مكتمل",genres:["رومانسي","دراما"],rating:"8.6",symbol:"春",colors:["#8d416f","#241126"],description:"رسائل مجهولة تغيّر حياة طالبتين وتفتح بابًا لبداية جديدة. هذا العمل تجريبي أصلي."},
  {id:6,title:"متاهة الصفر",type:"مانهوا",status:"مستمر",genres:["غموض","خيال علمي"],rating:"9.0",symbol:"零",colors:["#3b4381","#0c1023"],description:"يستيقظ البطل داخل متاهة رقمية لا تتبع قوانين الواقع. هذا العمل تجريبي أصلي."}
];
const $ = id => document.getElementById(id);
let filter = "all", query = "", selectedWork = null, readerPage = 1;
let favorites = new Set();
try { favorites = new Set(JSON.parse(localStorage.getItem("mw-favorites") || "[]")); } catch(e) {}
const escapeHTML = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function saveFavorites(){localStorage.setItem("mw-favorites",JSON.stringify([...favorites]));}
function coverStyle(w){return `background:radial-gradient(ellipse at 50% 30%,${w.colors[0]},${w.colors[1]} 76%);`;}
function render(){
  const list = works.filter(w => {
    const matchesFilter = filter==="all" || (filter==="مفضلة" ? favorites.has(w.id) : w.type===filter);
    const hay = (w.title+" "+w.type+" "+w.genres.join(" ")).toLowerCase();
    return matchesFilter && hay.includes(query.toLowerCase().trim());
  });
  $("catalog").innerHTML = list.map(w => `<article class="manga-card">
    <button class="favorite-btn ${favorites.has(w.id)?"fav":""}" data-fav="${w.id}" aria-label="المفضلة">${favorites.has(w.id)?"♥":"♡"}</button>
    <button class="cover" data-open="${w.id}" style="${coverStyle(w)}" aria-label="تفاصيل ${escapeHTML(w.title)}">
      <span class="cover-symbol">${escapeHTML(w.symbol)}</span><span class="cover-no">MW · ${String(w.id).padStart(2,"0")}</span>
      <span class="cover-label">${escapeHTML(w.type)}</span><span class="cover-title">${escapeHTML(w.title)}</span>
    </button>
    <div class="card-info"><h3>${escapeHTML(w.title)}</h3><div class="card-sub"><span class="status">${escapeHTML(w.status)}</span><span class="rating">★ ${w.rating}</span></div></div>
  </article>`).join("");
  $("resultCount").textContent = `${list.length} أعمال`;
  $("emptyState").classList.toggle("hidden",list.length>0);
  $("catalog").classList.toggle("hidden",list.length===0);
  $("favCount").textContent = favorites.size;
  $("sectionTitle").textContent = filter==="مفضلة"?"أعمالك المفضلة":filter==="all"?"اكتشف الأعمال":filter;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===filter));
}
function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2200);}
function toggleFavorite(id){id=Number(id);if(favorites.has(id)){favorites.delete(id);toast("أُزيل العمل من المفضلة");}else{favorites.add(id);toast("أُضيف العمل إلى المفضلة");}saveFavorites();render();if(selectedWork&&selectedWork.id===id)updateDetailFav();}
function updateDetailFav(){if(!selectedWork)return;$("detailFavBtn").textContent=favorites.has(selectedWork.id)?"♥ أُضيف إلى المفضلة — اضغط للإزالة":"♡ أضف إلى المفضلة";}
function openDetail(id){selectedWork=works.find(w=>w.id===Number(id));if(!selectedWork)return;const w=selectedWork;$("detailTitle").textContent=w.title;$("detailType").textContent=w.type;$("detailStatus").textContent=w.status;$("detailDescription").textContent=w.description;$("detailTags").innerHTML=w.genres.map(g=>`<span class="tag">${escapeHTML(g)}</span>`).join("");$("detailCover").style.background=`radial-gradient(ellipse at 50% 30%,${w.colors[0]},${w.colors[1]} 80%)`;$("detailCoverText").textContent=w.symbol;updateDetailFav();$("detailModal").classList.remove("hidden");}
function closeDetail(){$("detailModal").classList.add("hidden");}
function openReader(){if(!selectedWork)return;$("readerTitle").textContent=selectedWork.title;$("readerView").classList.remove("hidden");readerPage=1;renderPage();}
function renderPage(){$("pageLabel").textContent=`${readerPage} / 3`;const lines=[["تبدأ الحكاية","من الصفحة الأولى..."],["كل طريق","يخفي سرًا جديدًا."],["وهنا تبدأ","المغامرة الحقيقية!"]][readerPage-1];$("readerPage").innerHTML=`<div class="page-art"><span class="page-kanji">${escapeHTML(selectedWork?.symbol||"漫")}</span><p>${lines.map(escapeHTML).join("<br>")}</p></div>`;$("prevPage").disabled=readerPage===1;$("nextPage").disabled=readerPage===3;}
document.addEventListener("click",e=>{
  const fav=e.target.closest("[data-fav]");if(fav){toggleFavorite(fav.dataset.fav);return;}
  const open=e.target.closest("[data-open]");if(open){openDetail(open.dataset.open);return;}
  if(e.target.dataset.close==="true")closeDetail();
  const f=e.target.closest("[data-filter]");if(f){filter=f.dataset.filter;render();}
  const tab=e.target.closest("[data-tab]");if(tab){document.querySelectorAll(".bottom-item").forEach(b=>b.classList.toggle("selected",b===tab));if(tab.dataset.tab==="favorites"){filter="مفضلة";render();$("library").scrollIntoView({behavior:"smooth"});}else if(tab.dataset.tab==="search"){$("searchInput").focus();window.scrollTo({top:0,behavior:"smooth"});}else if(tab.dataset.tab==="about"){document.querySelector(".legal-note").scrollIntoView({behavior:"smooth"});}else{filter="all";query="";$("searchInput").value="";render();window.scrollTo({top:0,behavior:"smooth"});}}
});
$("searchInput").addEventListener("input",e=>{query=e.target.value;render();});
$("clearSearch").addEventListener("click",()=>{$("searchInput").value="";query="";render();});
$("exploreBtn").addEventListener("click",()=>$("library").scrollIntoView({behavior:"smooth"}));
$("detailFavBtn").addEventListener("click",()=>selectedWork&&toggleFavorite(selectedWork.id));
$("readBtn").addEventListener("click",()=>{closeDetail();openReader();});
$("backToLibrary").addEventListener("click",()=>$("readerView").classList.add("hidden"));
$("prevPage").addEventListener("click",()=>{if(readerPage>1){readerPage--;renderPage();}});
$("nextPage").addEventListener("click",()=>{if(readerPage<3){readerPage++;renderPage();}});
$("readerSettings").addEventListener("click",()=>toast("إعدادات القراءة ستُضاف في تحديث لاحق"));
$("menuBtn").addEventListener("click",()=>toast("أهلًا بك في Manga World"));
$("profileBtn").addEventListener("click",()=>toast("الحساب الشخصي ميزة مستقبلية"));
render();
