package com.secure.leave;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.webkit.*;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.net.Uri;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> fileCallback;
 private static final int FILE_REQUEST=41;
 @Override public void onCreate(Bundle state){super.onCreate(state);
 web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);
 web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);
 web.getSettings().setAllowFileAccessFromFileURLs(true);
 web.addJavascriptInterface(new PrintBridge(),"AndroidPrint");
 web.setWebViewClient(new WebViewClient());
 web.setWebChromeClient(new WebChromeClient(){
 @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
 if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
 try{Intent intent=params.createIntent();startActivityForResult(intent,FILE_REQUEST);return true;}
 catch(Exception e){fileCallback=null;Toast.makeText(MainActivity.this,"Cannot open image picker",Toast.LENGTH_SHORT).show();return false;}
 }});
 web.loadUrl("file:///android_asset/index.html");}
 public class PrintBridge { @JavascriptInterface public void printPage(){runOnUiThread(()->{
 PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);
 PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
 manager.print("Secure Leave Application",web.createPrintDocumentAdapter("Secure Leave Application"),attrs);
 });}}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
 if(request==FILE_REQUEST&&fileCallback!=null){Uri[] value=null;if(result==RESULT_OK&&data!=null){Uri uri=data.getData();if(uri!=null)value=new Uri[]{uri};}fileCallback.onReceiveValue(value);fileCallback=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
