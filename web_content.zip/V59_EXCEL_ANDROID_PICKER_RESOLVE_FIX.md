# V59 Excel Android picker resolve fix

Fixes the V58 picker launch failure by removing the pre-launch `resolveActivity()` gate, which can return null on Android 11+ because of package-visibility rules even when `startActivityForResult()` can launch the system picker.

The importer now tries:
1. ACTION_OPEN_DOCUMENT with `*/*`
2. ACTION_GET_CONTENT with `*/*` if the first launch actually throws
3. ACTION_PICK as a final fallback

Also removes unnecessary MIME-array and prefix-URI flags from the native import path.

Version 2.25 / versionCode 29.
