@echo off
title JUZISOUND ETHNO PRO - KORG Pa600
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
