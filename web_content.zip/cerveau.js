/* ====================================================================================
   TRADING COMMERCE - CERVEAU.JS (MOTEUR LOGIQUE GLOBAL ET AVANCÉ)
   ==================================================================================== */

(function (window) {
    'use strict';

    // 1. DICTIONNAIRE GLOBAL DE TRADUCTION ET DES LIBELLÉS DE L'APPLICATION
    const TRADUCTIONS_APP = {
        fr: {
            appTitle: "Trading Commerce",
            menuTitle: "Menu Principal",
            langLbl: "🌐 Langue / Language :",
            mHome: "Accueil",
            mClients: "Profils Clients",
            mCalc: "Calculatrices & Devises",
            mProfil: "Mon Profil",
            mSettings: "Paramètres & Style",
            mSync: "Synchronisation QR",
            mClose: "Fermer le menu",
            online: "● En ligne",
            formTitle: "Enregistrer un mouvement",
            namePh: "Nom du client *",
            waPh: "Numéro WhatsApp (optionnel)",
            optCredit: "📥 Il a pris crédit (+)",
            optRepay: "📤 Il a remboursé (-)",
            optAdvance: "💵 Il a donné un peu d'avance (-)",
            optFinish: "✅ Règlement total (0)",
            amtPh: "Montant *",
            btnSave: "Enregistrer & Voir Profil",
            navAcc: "Accueil",
            navCli: "Clients",
            navCal: "Calc",
            navShare: "Partager",
            alertMsg: "Attention : Mets le nom et un montant correct !",
            errCalc: "Erreur de calcul",
            convTitle: "🌍 TOUT L'ARGENT DU MONDE ENTIER"
        },
        en: {
            appTitle: "Trading Commerce",
            menuTitle: "Main Menu",
            langLbl: "🌐 Language / Langue :",
            mHome: "Home",
            mClients: "Client Profiles",
            mCalc: "Calculators & Currencies",
            mProfil: "My Profile",
            mSettings: "Settings & Style",
            mSync: "QR Sync",
            mClose: "Close Menu",
            online: "● Online",
            formTitle: "Record a Movement",
            namePh: "Client Name *",
            waPh: "WhatsApp Number (optional)",
            optCredit: "📥 Took Credit (+)",
            optRepay: "📤 Repaid (-)",
            optAdvance: "💵 Advanced Payment (-)",
            optFinish: "✅ Full Payment (0)",
            amtPh: "Amount *",
            btnSave: "Save & View Profile",
            navAcc: "Home",
            navCli: "Clients",
            navCal: "Calc",
            navShare: "Share",
            alertMsg: "Warning: Please enter the name and a valid amount!",
            errCalc: "Calculation Error",
            convTitle: "🌍 ALL THE MONEY IN THE WORLD"
        },
        ar: {
            appTitle: "تجارة التداول",
            menuTitle: "القائمة الرئيسية",
            langLbl: "🌐 اللغة / Language:",
            mHome: "الرئيسية",
            mClients: "ملفات العملاء",
            mCalc: "الآلات الحاسبة والعملات",
            mProfil: "ملفي الشخصي",
            mSettings: "الإعدادات والنمط",
            mSync: "مزامنة QR",
            mClose: "إغلاق القائمة",
            online: "● متصل",
            formTitle: "تسجيل حركة",
            namePh: "اسم العميل *",
            waPh: "رقم واتساب (اختياري)",
            optCredit: "📥 أخذ كريدي/دين (+)",
            optRepay: "📤 سداد (-)",
            optAdvance: "💵 دفعة مقدمة (-)",
            optFinish: "✅ تسوية كاملة (0)",
            amtPh: "المبلغ *",
            btnSave: "حفظ وعرض الملف",
            navAcc: "الرئيسية",
            navCli: "العملاء",
            navCal: "حاسبة",
            navShare: "مشاركة",
            alertMsg: "تنبيه: أدخل الاسم والمبلغ بشكل صحيح!",
            errCalc: "خطأ في الحساب",
            convTitle: "🌍 كل أموال العالم"
        },
        zh: {
            appTitle: "贸易商业",
            menuTitle: "主菜单",
            langLbl: "🌐 语言 / Language:",
            mHome: "首页",
            mClients: "客户档案",
            mCalc: "计算器与货币",
            mProfil: "个人资料",
            mSettings: "设置与样式",
            mSync: "二维码同步",
            mClose: "关闭菜单",
            online: "● 在线",
            formTitle: "记录交易",
            namePh: "客户姓名 *",
            waPh: "WhatsApp 号码（可选）",
            optCredit: "📦 记账欠款 (+)",
            optRepay: "💵 还款 (-)",
            optAdvance: "💵 预付款 (-)",
            optFinish: "✅ 结清 (0)",
            amtPh: "金额 *",
            btnSave: "保存并查看资料",
            navAcc: "首页",
            navCli: "客户",
            navCal: "计算",
            navShare: "分享",
            alertMsg: "警告：请输入姓名和正确的金额！",
            errCalc: "计算错误",
            convTitle: "🌍 全世界的货币"
        }
    };

    // 2. TABLEAU DE TAUX DE CHANGE DE TOUTES LES MONNAIES DU MONDE (BASÉ SUR LE DOLLAR US)
    const TAUX_CHANGE_MONDE = {
        'USD': 1.0, 'EUR': 0.92, 'GBP': 0.79, 'CHF': 0.90, 'CAD': 1.36, 'AUD': 1.50, 'NZD': 1.63,
        'CNY': 7.20, 'JPY': 155.0, 'INR': 83.0, 'KRW': 1350.0, 'SGD': 1.35, 'HKD': 7.82,
        'THB': 36.5, 'IDR': 16000.0, 'MYR': 4.70, 'PHP': 56.0, 'VND': 25400.0, 'PKR': 278.0, 'BDT': 117.0,
        'XOF': 605.0, 'XAF': 605.0, 'GNF': 8600.0, 'NGN': 1450.0, 'GHS': 15.0, 'ZAR': 18.5,
        'KES': 130.0, 'MAD': 10.0, 'DZD': 134.0, 'TND': 3.12, 'EGP': 47.5, 'AOA': 835.0,
        'ETB': 57.0, 'UGX': 3800.0, 'RWF': 1300.0, 'BRL': 5.15, 'MXN': 17.0, 'ARS': 880.0,
        'COP': 3900.0, 'CLP': 950.0, 'PEN': 3.70, 'AED': 3.67, 'SAR': 3.75, 'QAR': 3.64, 'ILS': 3.70,
        'SEK': 10.8, 'NOK': 10.6, 'DKK': 6.88, 'PLN': 4.0, 'RUB': 91.0, 'UAH': 40.0, 'TRY': 32.2
    };

    // 3. OBJET CENTRAL DU CERVEAU (LOGIQUE AVANCÉE)
    window.CerveauApp = {

        // Initialisation du système au démarrage de chaque page
        init: function () {
            let langueActuelle = localStorage.getItem('tc_langue') || 'fr';
            this.appliquerDirectionLangue(langueActuelle);
            this.verifierIntegriteStockage();
            console.log("Cerveau.js - Moteur chargé et optimisé sans latence.");
        },

        // Gestion automatique de l'affichage de droite à gauche (RTL) pour l'arabe
        appliquerDirectionLangue: function (lang) {
            if (lang === 'ar') {
                document.dir = 'rtl';
            } else {
                document.dir = 'ltr';
            }
        },

        // Transformation automatique des chiffres occidentaux en chiffres arabes orientaux (٠, ١, ٢, ٣...)
        formaterChiffresArabe: function (texte) {
            let lang = localStorage.getItem('tc_langue') || 'fr';
            if (lang !== 'ar') return texte;
            const mapChiffres = {'0':'٠','1':'١','2':'٢','3':'٣','4':'٤','5':'٥','6':'٦','7':'٧','8':'٨','9':'٩'};
            return texte.toString().replace(/[0-9]/g, match => mapChiffres[match]);
        },

        // Vérification et initialisation des données locales
        verifierIntegriteStockage: function () {
            if (!localStorage.getItem('tc_clients')) {
                localStorage.setItem('tc_clients', JSON.stringify([]));
            }
            if (!localStorage.getItem('tc_boutique')) {
                localStorage.setItem('tc_boutique', 'Trading Commerce');
            }
        },

        // Récupérer la liste complète des clients de manière sécurisée
        recupererClients: function () {
            try {
                return JSON.parse(localStorage.getItem('tc_clients')) || [];
            } catch (e) {
                console.error("Erreur de lecture des clients :", e);
                return [];
            }
        },

        // Enregistrer un mouvement de crédit ou de remboursement avec mise à jour du solde
        enregistrerMouvementClient: function (nomClient, numeroWhatsapp, typeOperation, montantValeur, codeDevise) {
            if (!nomClient || isNaN(montantValeur) || montantValeur <= 0) {
                return { succes: false, message: "Nom ou montant invalide." };
            }

            let clients = this.recupererClients();
            let clientExistant = clients.find(c => c.nom.toLowerCase() === nomClient.toLowerCase());
            
            let maintenant = new Date();
            let dateExacte = maintenant.toLocaleDateString() + " à " + maintenant.toLocaleTimeString();

            let nouveauMouvement = {
                action: typeOperation,
                montant: montantValeur,
                date: dateExacte
            };

            if (clientExistant) {
                let ancienSolde = parseFloat(clientExistant.solde || 0);

                if (typeOperation.includes("crédit") || typeOperation.includes("pris")) {
                    clientExistant.solde = ancienSolde + montantValeur;
                } else if (typeOperation.includes("remboursé") || typeOperation.includes("avance")) {
                    clientExistant.solde = ancienSolde - montantValeur;
                    if (clientExistant.solde < 0) clientExistant.solde = 0;
                } else if (typeOperation.includes("fini") || typeOperation.includes("total")) {
                    clientExistant.solde = 0;
                }

                if (!clientExistant.mouvements) clientExistant.mouvements = [];
                clientExistant.mouvements.push(nouveauMouvement);
                clientExistant.devise = codeDevise;
                if (numeroWhatsapp) clientExistant.whatsapp = numeroWhatsapp;

            } else {
                let soldeInitial = (typeOperation.includes("crédit") || typeOperation.includes("pris")) ? montantValeur : 0;
                clients.push({
                    nom: nomClient,
                    whatsapp: numeroWhatsapp || "Pas de numéro",
                    solde: soldeInitial,
                    devise: codeDevise,
                    mouvements: [nouveauMouvement]
                });
            }

            localStorage.setItem('tc_clients', JSON.stringify(clients));
            return { succes: true, message: "Mouvement enregistré avec succès !" };
        },

        // Convertisseur lourd multi-devises mondial
        convertirMonnaieMondiale: function (montant, deviseSource, deviseCible) {
            let montantNum = parseFloat(montant);
            if (isNaN(montantNum)) return 0;

            let tauxSrc = TAUX_CHANGE_MONDE[deviseSource] || 1.0;
            let tauxCib = TAUX_CHANGE_MONDE[deviseCible] || 1.0;

            let montantEnUSD = montantNum / tauxSrc;
            let resultatConverti = montantEnUSD * tauxCib;
            return resultatConverti.toFixed(2);
        },

        // Moteur de recherche global à travers toute l'application et les clients
        rechercherDansApplication: function (termeRecherche) {
            let query = termeRecherche.toLowerCase().trim();
            if (!query) return [];

            let resultatsFiltres = [];
            let pagesDisponibles = [
                { nom: "Profils Clients", url: "client.html", mots: ["client", "profil", "dette", "credit"] },
                { nom: "Calculatrices & Devises", url: "calculatrices.html", mots: ["calc", "calculatrice", "monnaie", "argent"] },
                { nom: "Paramètres & Style", url: "settings.html", mots: ["parametre", "reglages", "style"] },
                { nom: "Mon Profil", url: "modul2.html", mots: ["profil", "nom"] },
                { nom: "Synchronisation QR", url: "QRCode.html", mots: ["qr", "sync", "partager"] }
            ];

            pagesDisponibles.forEach(p => {
                if (p.nom.toLowerCase().includes(query) || p.mots.some(m => m.includes(query))) {
                    resultatsFiltres.push({ texte: `⚙️ Aller vers : ${p.nom}`, url: p.url });
                }
            });

            let clients = this.recupererClients();
            clients.forEach(c => {
                if (c.nom.toLowerCase().includes(query) || (c.whatsapp && c.whatsapp.includes(query))) {
                    resultatsFiltres.push({ texte: `👤 Client : ${c.nom} (${c.solde} ${c.devise})`, url: "client.html" });
                }
            });

            return resultatsFiltres;
        }

    };

    // Lancement automatique et instantané du cerveau dès que le document HTML est prêt
    document.addEventListener('DOMContentLoaded', function () {
        window.CerveauApp.init();
    });

})(window);
