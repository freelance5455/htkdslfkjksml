package com.liferpg.core

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.liferpg.bridge.AndroidBridge

/**
 * Única pantalla nativa: aloja la interfaz web (assets/web/index.html).
 * Solo se permite cargar contenido propio empaquetado en la app.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0B0A0C"))
            overScrollMode = WebView.OVER_SCROLL_NEVER
        }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage (solo demo; la Etapa 5 usa Room)
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            setSupportZoom(false)
        }

        webView.webViewClient = object : WebViewClient() {
            // Bloquea cualquier navegación fuera de los assets propios.
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = !request.url.toString().startsWith("file:///android_asset/web/")
        }

        // Puente WebView <-> Kotlin: expuesto en JS como window.Android
        webView.addJavascriptInterface(AndroidBridge(applicationContext), "Android")

        setContentView(webView)
        webView.loadUrl("file:///android_asset/web/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
