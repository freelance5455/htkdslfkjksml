package com.liferpg.bridge

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * Puente controlado WebView -> Kotlin.
 * Regla: solo se exponen métodos con @JavascriptInterface y NUNCA se confía en
 * datos de la web para conceder XP (la validación de XP será nativa, Etapa 7).
 */
class AndroidBridge(@Suppress("unused") private val context: Context) {

    /** Versión de la app, para comprobar que el puente funciona. */
    @JavascriptInterface
    fun version(): String = "0.1.0"

    /** Prueba de vida del puente (Etapa 3). */
    @JavascriptInterface
    fun ping(): String = "pong"
}
