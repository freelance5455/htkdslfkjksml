plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.liferpg"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.liferpg"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // La interfaz vive en LIFE-RPG/web y se copia a assets/web al compilar.
    sourceSets.getByName("main").assets.srcDir(layout.buildDirectory.dir("generated/webAssets"))
}

val copyWeb by tasks.registering(Copy::class) {
    from(rootProject.file("../web"))
    into(layout.buildDirectory.dir("generated/webAssets/web"))
}

tasks.named("preBuild") {
    dependsOn(copyWeb)
}

// Sin dependencias externas a propósito (regla 17 del documento maestro).
dependencies {
}
