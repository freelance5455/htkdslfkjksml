# LIFE RPG

App Android (APK) de mejoramiento personal con estética Dark Gothic Fantasy.
Gratuita, sin conexión, datos locales. Sin dependencias externas.

## Estado actual: Etapas 2, 3 y 4 completadas (sin compilar aún)

| Etapa | Contenido | Estado |
|---|---|---|
| 1 | Entorno | Hecha (el entorno de Claude no tiene Android SDK; compilas tú) |
| 2 | Proyecto Android (Gradle, Kotlin, 0 dependencias) | Escrita, pendiente de compilar en tu PC |
| 3 | WebView + puente `window.Android` | Escrita, pendiente de compilar en tu PC |
| 4 | Diseño gótico (Personaje, Misiones, STRICT, Crónica) | Probada en navegador móvil simulado |
| 5-16 | Base de datos, XP, misiones, STRICT real... | Pendientes |

Las pantallas usan datos de ejemplo. Misiones, XP y bloqueo reales se activan en etapas posteriores.

## Cómo compilar (Android Studio)

1. Instala Android Studio (incluye JDK 17 y Android SDK 34).
2. `File > Open` y elige la carpeta `LIFE-RPG/android`.
3. Espera el *Gradle Sync* (la primera vez descarga el plugin de Android; necesita internet).
   Android Studio crea el *gradle wrapper* por sí mismo si falta.
4. Conecta tu teléfono con depuración USB, o usa un emulador, y pulsa **Run ▶**.
5. APK de depuración: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

La carpeta `web/` es la fuente de la interfaz. Gradle la copia a `assets/web/` al compilar
(tarea `copyWeb`), así que edita siempre `web/` y nunca la copia generada.

## Verificación de la Etapa 3

Abre la app: abajo de la hoja de personaje debe decir **"Núcleo nativo v0.1.0"**.
Si dice "Modo navegador", el puente no está conectado.

## Probar solo la interfaz sin Android

Abre `web/index.html` en Chrome (mejor con el modo móvil de las herramientas de desarrollo).

## Personalización

- **Avatar:** reemplaza `web/assets/avatar.svg` (o cambia la ruta en `web/js/screens/character.js`).
- **Fuente gótica:** copia un `.ttf` libre a `web/assets/fonts/` y descomenta `@font-face` en `web/css/gothic.css`.

## Posibles errores

- *Gradle sync falla por versión de JDK:* en Settings > Build Tools > Gradle usa JDK 17.
- *"SDK location not found":* abre SDK Manager e instala Android SDK Platform 34.
- *Pantalla en blanco:* revisa que `web/index.html` exista; la tarea `copyWeb` lo copia al compilar.
