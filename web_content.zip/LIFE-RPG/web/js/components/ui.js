/* Utilidades de interfaz reutilizables. */
(function () {
  var LR = (window.LR = window.LR || {});
  var toastTimer = null;

  LR.ui = {
    toast: function (msg) {
      var t = document.getElementById("toast");
      t.textContent = msg;
      t.classList.add("show");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2400);
    },
    // Escapa texto antes de insertarlo como HTML.
    esc: function (s) {
      return String(s).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
      });
    },
    // Anima las barras después de pintar la pantalla.
    animateBars: function (root) {
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          root.querySelectorAll(".bar > i[data-w]").forEach(function (el) {
            el.style.width = el.getAttribute("data-w") + "%";
          });
        });
      });
    },
  };
})();
