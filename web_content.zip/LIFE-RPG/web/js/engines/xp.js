/* Motor de XP — fórmula del documento maestro:
   XP necesaria para subir desde el nivel n = 100 + 50 × (n - 1)
   (Etapa 4: solo cálculo. La concesión verificada llega en la Etapa 7.) */
(function () {
  var LR = (window.LR = window.LR || {});

  LR.xp = {
    needed: function (level) {
      return 100 + 50 * (level - 1);
    },
    // Dado XP total acumulada, devuelve nivel y progreso dentro del nivel.
    fromTotal: function (total) {
      var level = 1;
      var left = total;
      while (left >= this.needed(level)) {
        left -= this.needed(level);
        level += 1;
      }
      return { level: level, into: left, needed: this.needed(level) };
    },
  };
})();
