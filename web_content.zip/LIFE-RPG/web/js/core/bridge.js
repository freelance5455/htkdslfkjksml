/* Puente con Kotlin (Etapa 3). window.Android solo existe dentro de la APK. */
(function () {
  var LR = (window.LR = window.LR || {});

  LR.bridge = {
    available: function () {
      return typeof window.Android !== "undefined";
    },
    status: function () {
      if (!this.available()) return { ok: false, text: "Modo navegador (sin núcleo nativo)" };
      try {
        var pong = window.Android.ping();
        return { ok: pong === "pong", text: "Núcleo nativo v" + window.Android.version() };
      } catch (e) {
        return { ok: false, text: "Error del puente: " + e.message };
      }
    },
  };
})();
