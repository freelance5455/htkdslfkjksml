/* Arranque y navegación. */
(function () {
  var LR = window.LR;
  var screen = document.getElementById("screen");

  function refreshTopbar() {
    var prog = LR.xp.fromTotal(LR.state.player.xp);
    document.getElementById("chip-level").textContent = "Nv " + prog.level;
    document.getElementById("chip-coins").textContent = "◈ " + LR.state.player.coins;
  }

  function show(name) {
    document.querySelectorAll(".tab").forEach(function (t) {
      t.classList.toggle("active", t.getAttribute("data-screen") === name);
    });
    screen.scrollTop = 0;
    screen.style.animation = "none";
    void screen.offsetWidth; // reinicia la animación de entrada
    screen.style.animation = "";
    LR.screens[name](screen);
  }

  document.querySelectorAll(".tab").forEach(function (t) {
    t.addEventListener("click", function () { show(t.getAttribute("data-screen")); });
  });

  refreshTopbar();
  show("character");
})();
