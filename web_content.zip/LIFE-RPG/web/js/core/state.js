/* Estado DEMO de la interfaz (Etapa 4).
   Son datos de ejemplo: la persistencia real (Room) llega en la Etapa 5
   y la concesión de XP será validada por el código nativo en la Etapa 7. */
(function () {
  var LR = (window.LR = window.LR || {});

  LR.state = {
    player: { name: "Jugador", title: "Aspirante", level: 1, xp: 0, coins: 0 },
    attributes: [
      { id: "disciplina", name: "Disciplina", hint: "Constancia y hábitos", value: 1 },
      { id: "inteligencia", name: "Inteligencia", hint: "Estudio y aprendizaje", value: 1 },
      { id: "fisico", name: "Físico", hint: "Ejercicio y salud", value: 1 },
      { id: "creatividad", name: "Creatividad", hint: "Crear y explorar", value: 1 },
      { id: "social", name: "Social", hint: "Relaciones y comunicación", value: 1 },
      { id: "resistencia", name: "Resistencia", hint: "Foco y aguante", value: 1 },
    ],
    quests: {
      daily: [
        { name: "Hora de estudio", desc: "Estudia 60 minutos sin distracciones.", cat: "Inteligencia", verify: "Temporizador", xp: 40, coins: 10 },
        { name: "Cuerpo en movimiento", desc: "30 minutos de ejercicio.", cat: "Físico", verify: "Temporizador", xp: 35, coins: 8 },
        { name: "Orden del santuario", desc: "Ordena tu espacio de trabajo.", cat: "Disciplina", verify: "Confirmación", xp: 20, coins: 5 },
      ],
      weekly: [
        { name: "Obra del mes", desc: "Avanza en un proyecto creativo 3 veces.", cat: "Creatividad", verify: "Registro", xp: 90, coins: 25 },
        { name: "Un pacto social", desc: "Llama o visita a alguien importante.", cat: "Social", verify: "Confirmación", xp: 60, coins: 15 },
      ],
    },
    // Reglas de STRICT (la lógica real llega en las Etapas 10-11).
    strict: {
      active: false,
      schedule: "Lun–Vie · 08:00 – 17:00",
      // Siempre disponibles: nunca se bloquean.
      alwaysAllowed: [
        { name: "Spotify", note: "Tu música nunca se bloquea" },
        { name: "Teléfono y emergencias", note: "Siempre disponible" },
        { name: "Ajustes de seguridad", note: "Siempre disponible" },
      ],
      // Todas las demás apps instaladas se listarán desde Android (Etapa 10).
      sampleBlocked: ["Instagram", "TikTok", "YouTube", "Juegos"],
    },
  };
})();
