/* Pantalla: STRICT SCHEDULED (maqueta; el bloqueo real llega en las Etapas 10-11). */
(function () {
  var LR = (window.LR = window.LR || {});

  LR.screens = LR.screens || {};
  LR.screens.strict = function (root) {
    var s = LR.state.strict, e = LR.ui.esc;

    var allowed = s.alwaysAllowed.map(function (a) {
      return '<div class="app-row"><div class="nm">' + e(a.name) + '<small>' + e(a.note) + '</small></div>' +
             '<span class="badge">Siempre libre</span></div>';
    }).join("");

    var blocked = s.sampleBlocked.map(function (n) {
      return '<div class="app-row"><div class="nm">' + e(n) + '</div><span class="badge lock">Bloqueada</span></div>';
    }).join("");

    root.innerHTML =
      '<div class="section-title">Modo STRICT</div>' +
      '<section class="panel">' +
        '<div class="status"><span class="dot' + (s.active ? " on" : "") + '"></span>' +
          '<div><div style="color:#ecebe8">' + (s.active ? "Vigilia activa" : "Vigilia inactiva") + '</div>' +
          '<div class="note" style="margin:0">' + e(s.schedule) + '</div></div></div>' +
        '<button class="btn" id="strict-toggle">Activar vigilia</button>' +
      '</section>' +
      '<section class="panel"><h2>Siempre permitidas</h2>' + allowed + '</section>' +
      '<section class="panel"><h2>Se bloquean en horario</h2>' + blocked +
        '<p class="note">Por defecto se bloquearán todas las demás aplicaciones instaladas, salvo las permitidas. ' +
        'Android no permite un bloqueo absoluto: podrás salir de STRICT voluntariamente.</p>' +
      '</section>';

    document.getElementById("strict-toggle").onclick = function () {
      LR.ui.toast("El bloqueo real se activa en la Etapa 10.");
    };
  };
})();
