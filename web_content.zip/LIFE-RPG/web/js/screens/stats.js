/* Pantalla: Crónica / estadísticas (maqueta). */
(function () {
  var LR = (window.LR = window.LR || {});

  LR.screens = LR.screens || {};
  LR.screens.stats = function (root) {
    root.innerHTML =
      '<div class="section-title">Crónica</div>' +
      '<section class="panel"><h2>Esta semana</h2>' +
        '<div class="kv">' +
          '<div><b>0</b><span>Misiones</span></div>' +
          '<div><b>0</b><span>XP</span></div>' +
          '<div><b>0h</b><span>Foco</span></div>' +
        '</div>' +
        '<div class="empty">Aún no hay crónicas.<br>Completa tu primera misión para escribirla.</div>' +
      '</section>';
  };
})();
