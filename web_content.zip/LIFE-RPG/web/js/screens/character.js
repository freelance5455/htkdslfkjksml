/* Pantalla: Personaje (hoja de personaje). El personaje es Claude. */
(function () {
  var LR = (window.LR = window.LR || {});

  LR.screens = LR.screens || {};
  LR.screens.character = function (root) {
    var s = LR.state, e = LR.ui.esc;
    var prog = LR.xp.fromTotal(s.player.xp);
    var pct = Math.round((prog.into / prog.needed) * 100);

    var attrs = s.attributes.map(function (a) {
      var w = Math.min(100, a.value * 10);
      return '<div class="sheet-row">' +
        '<div class="k">' + e(a.name) + '<small>' + e(a.hint) + '</small></div>' +
        '<div class="v">' + a.value + '</div>' +
        '<div class="bar"><i data-w="' + w + '"></i></div></div>';
    }).join("");

    root.innerHTML =
      '<div class="portrait-wrap"><div class="portrait">' +
        '<img src="assets/avatar.svg" alt="Retrato del personaje">' +
      '</div></div>' +
      '<div class="nameplate">' +
        '<h2 class="name gothic">' + e(s.player.name) + '</h2>' +
        '<div class="title">' + e(s.player.title) + ' · Nivel ' + prog.level + '</div>' +
      '</div>' +
      '<section class="panel">' +
        '<div class="bar-label"><span>Experiencia</span><span>' + prog.into + ' / ' + prog.needed + ' XP</span></div>' +
        '<div class="bar"><i data-w="' + pct + '"></i></div>' +
        '<div class="kv" style="margin-top:12px">' +
          '<div><b>' + prog.level + '</b><span>Nivel</span></div>' +
          '<div><b>' + s.player.xp + '</b><span>XP total</span></div>' +
          '<div><b>' + s.player.coins + '</b><span>Monedas</span></div>' +
        '</div>' +
      '</section>' +
      '<section class="panel"><h2>Atributos</h2>' + attrs + '</section>' +
      '<p class="note" style="text-align:center">' + e(LR.bridge.status().text) + '</p>';

    LR.ui.animateBars(root);
  };
})();
