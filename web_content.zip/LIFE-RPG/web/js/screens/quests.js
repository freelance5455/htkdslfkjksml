/* Pantalla: Misiones (maqueta; el motor real llega en la Etapa 8). */
(function () {
  var LR = (window.LR = window.LR || {});
  var current = "daily";

  LR.screens = LR.screens || {};
  LR.screens.quests = function (root) {
    var e = LR.ui.esc;

    function render() {
      var list = LR.state.quests[current].map(function (q, i) {
        return '<article class="quest" data-i="' + i + '">' +
          '<h3>' + e(q.name) + '</h3>' +
          '<div class="rw">+' + q.xp + ' XP<br>◈ ' + q.coins + '</div>' +
          '<p>' + e(q.desc) + '</p>' +
          '<div class="tags"><span class="tag red">' + e(q.cat) + '</span><span class="tag">' + e(q.verify) + '</span></div>' +
        '</article>';
      }).join("");

      root.innerHTML =
        '<div class="section-title">Tablón de misiones</div>' +
        '<div class="seg">' +
          '<button data-k="daily" class="' + (current === "daily" ? "on" : "") + '">Diarias</button>' +
          '<button data-k="weekly" class="' + (current === "weekly" ? "on" : "") + '">Semanales</button>' +
        '</div>' + list +
        '<p class="note" style="text-align:center">Vista previa de diseño. Las misiones reales y la XP verificada llegan en las Etapas 7 y 8.</p>';

      root.querySelectorAll(".seg button").forEach(function (b) {
        b.onclick = function () { current = b.getAttribute("data-k"); render(); };
      });
      root.querySelectorAll(".quest").forEach(function (q) {
        q.onclick = function () { LR.ui.toast("Iniciar misiones se activa en la Etapa 8."); };
      });
    }
    render();
  };
})();
