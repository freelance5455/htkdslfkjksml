'use strict';

const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)]
  .map(match => match[1])
  .filter(source => source.trim());

if (scripts.length === 0) {
  throw new Error('No executable inline script was found in index.html.');
}

scripts.forEach((source, index) => {
  new vm.Script(source, { filename: 'index.html:inline-script-' + (index + 1) });
});

const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
if (packageJson.version !== '1.8.0' || packageJson.dependencies) {
  throw new Error('KORA X 1.8.0 should not include unused external npm dependencies.');
}
for (const route of ['/api/health', '/api/fixtures', '/api/news', '/api/auth/register', '/api/auth/login', '/api/predictions']) {
  if (!server.includes(route)) throw new Error('Missing core server route: ' + route);
}
if (!server.includes('sportScoreFixtures') || !server.includes('Powered by SportScore') || /paymob|google-auth-library|GOOGLE_CLIENT_ID/i.test(server)) {
  throw new Error('The public match fallback or its attribution is missing, or an unused integration remains.');
}
if (!html.includes('languagePicker') || !html.includes('const UI_EN=')) {
  throw new Error('Arabic/English language selector or translation dictionary is missing.');
}
const dockerfile = fs.readFileSync(path.join(root, 'Dockerfile'), 'utf8');
const dockerignore = fs.readFileSync(path.join(root, '.dockerignore'), 'utf8');
if (!dockerfile.includes('npm install --omit=dev')) {
  throw new Error('Dockerfile must install production dependencies before running the server.');
}
if (!dockerfile.includes('EXPOSE 3000') || !dockerfile.includes('CMD ["node", "server.js"]')) {
  throw new Error('Dockerfile must expose port 3000 and start server.js.');
}
if (!dockerignore.includes('.env') || !dockerignore.includes('data/')) {
  throw new Error('Docker build context must exclude environment secrets and local data.');
}
if (!manifest.name || !Array.isArray(manifest.icons) || manifest.icons.length === 0) {
  throw new Error('PWA manifest is missing its name or icons.');
}

if (!server.includes("mode:'web-only-no-keys'") || !server.includes('googleNewsRss')) {
  throw new Error('The no-key web-only source mode is missing.');
}
if (server.includes('process.env.API_FOOTBALL_KEY') || server.includes('process.env.NEWSDATA_API_KEY')) {
  throw new Error('This build must not read external provider API keys.');
}
if (!html.includes('KORA X · الإصدار 1.8.0') || html.includes('href="${esc(url||') ) {
  throw new Error('The UI version or source-link removal check failed.');
}
console.log('KORA X 1.8.0 project checks passed.');
console.log('Inline scripts checked: ' + scripts.length);
