'use strict';
// KORA X v1.8.0 — web-only, no-provider-key build.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);
const ROOT = __dirname;

function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const s = line.trim(); if (!s || s.startsWith('#')) continue;
    const i = s.indexOf('='); if (i < 1) continue;
    const k = s.slice(0, i).trim(); let v = s.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[k] === undefined) process.env[k] = v;
  }
}
loadDotEnv();

const PORT = Number(process.env.PORT || 3000);
// This release deliberately uses public web sources only; no provider API keys are read.
const FOOTBALL_KEY = '';
const NEWS_KEY = '';
const CAIRO_YEAR = Number(new Intl.DateTimeFormat('en-US', { timeZone:'Africa/Cairo', year:'numeric' }).format(new Date()));
const CONFIGURED_FOOTBALL_SEASON = Number.parseInt(process.env.FOOTBALL_DEFAULT_SEASON || String(CAIRO_YEAR), 10) || CAIRO_YEAR;
// Ignore stale deployment values (for example 2024 in a 2026 deployment).
const FOOTBALL_DEFAULT_SEASON = CONFIGURED_FOOTBALL_SEASON >= CAIRO_YEAR - 1 && CONFIGURED_FOOTBALL_SEASON <= CAIRO_YEAR + 1 ? CONFIGURED_FOOTBALL_SEASON : CAIRO_YEAR;
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'same-origin';
const CACHE = new Map();
const footballMinute = [];
const ipBuckets = new Map();
const DATA_DIR = process.env.KORA_DATA_DIR || path.join(ROOT, 'data');
const commentFile = path.join(DATA_DIR, 'comments.json');
const userFile = path.join(DATA_DIR, 'users.json');
const predictionsFile = path.join(DATA_DIR, 'predictions.json');
const sessionFile = path.join(DATA_DIR, 'sessions.json');
const sessions = new Map();
const sessionCookie = 'kora_x_session';
let footballDaily = { day: new Date().toISOString().slice(0, 10), count: 0 };
const SOURCE_STATE = { footballConnected:false, newsConnected:false, sportscoreConnected:false, footballLastSuccess:null, newsLastSuccess:null, sportscoreLastSuccess:null, footballLastError:null, newsLastError:null, sportscoreLastError:null };

function cacheGet(key) { const x = CACHE.get(key); if (!x || x.exp < Date.now()) { CACHE.delete(key); return null; } return x.value; }
function cacheSet(key, value, ms) { CACHE.set(key, { value, exp: Date.now() + ms }); }
function ttl(endpoint, q) {
  if (endpoint === 'fixtures' && q.live === 'all') return 60_000;
  if (endpoint === 'fixtures' && q.ids) return 90_000;
  if (endpoint === 'fixtures' && q.id) return 90_000;
  if (endpoint === 'fixtures') return 3 * 60_000;
  if (endpoint.startsWith('fixtures/')) return 2 * 60_000;
  if (endpoint === 'injuries') return 4 * 60 * 60_000;
  if (endpoint === 'leagues' || endpoint === 'teams' || endpoint.startsWith('players/') || endpoint === 'coachs') return 12 * 60 * 60_000;
  return 30 * 60_000;
}
function qsOf(q) { const p = new URLSearchParams(); for (const [k,v] of Object.entries(q || {})) if (v !== undefined && v !== null && String(v).trim() !== '') p.set(k, String(v).trim()); return p.toString(); }
function httpError(status, message) { const e = new Error(message); e.status = status; return e; }
function dayStamp() { return new Date().toISOString().slice(0, 10); }
function localDateCairo() {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone:'Africa/Cairo', year:'numeric', month:'2-digit', day:'2-digit' }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}
async function takeFootballSlot() {
  const now = Date.now();
  if (footballDaily.day !== dayStamp()) footballDaily = { day: dayStamp(), count: 0 };
  while (footballMinute.length && now - footballMinute[0] >= 60_000) footballMinute.shift();
  // A conservative ceiling below the advertised free quota protects room for user-initiated actions.
  const configuredLimit = Number(process.env.FOOTBALL_DAILY_LIMIT || 92);
  const providerRemaining = Number(process.env.FOOTBALL_PROVIDER_REMAINING);
  if (footballDaily.count >= configuredLimit || (Number.isFinite(providerRemaining) && providerRemaining <= 2)) {
    SOURCE_STATE.footballConnected = false;
    SOURCE_STATE.footballLastError = 'تم بلوغ حد الطلبات اليومي الآمن.';
    throw httpError(429, 'وصل التطبيق إلى الحد اليومي الآمن لطلبات بيانات المباريات. ستعود البيانات بعد تجديد الحصة.');
  }
  if (footballMinute.length >= 8) {
    SOURCE_STATE.footballConnected = false;
    SOURCE_STATE.footballLastError = 'تم بلوغ حد الطلبات في الدقيقة.';
    throw httpError(429, 'طلبات المباريات كثيرة في هذه اللحظة. انتظر قليلًا ثم أعد المحاولة.');
  }
  footballMinute.push(now); footballDaily.count++;
}
async function footballGet(endpoint, params = {}) {
  if (!FOOTBALL_KEY) throw httpError(503, 'مصدر بيانات المباريات غير مضبوط على الخادم.');
  const query = qsOf(params); const key = `football:${endpoint}?${query}`;
  const cached = cacheGet(key); if (cached) return cached;
  await takeFootballSlot();
  const url = `https://v3.football.api-sports.io/${endpoint}${query ? `?${query}` : ''}`;
  let response; try { response = await fetch(url, { headers: { 'x-apisports-key': FOOTBALL_KEY, Accept: 'application/json' }, signal: AbortSignal.timeout(20_000) }); } catch (err) { SOURCE_STATE.footballConnected=false; SOURCE_STATE.footballLastError=err?.cause?.code || err?.message || 'network'; throw httpError(502, 'تعذر الوصول إلى مزود بيانات المباريات من الخادم. تحقق من اتصال الاستضافة بالإنترنت ثم أعد المحاولة.'); }
  const body = await response.json().catch(() => null);
  if (!response.ok) {
    SOURCE_STATE.footballConnected = false;
    SOURCE_STATE.footballLastError = body?.errors ? JSON.stringify(body.errors) : `HTTP ${response.status}`;
    throw httpError(response.status, body?.errors ? JSON.stringify(body.errors) : `تعذر جلب بيانات المباريات (${response.status}).`);
  }
  if (!body || !Array.isArray(body.response)) throw httpError(502, 'استجابة مصدر المباريات غير مكتملة.');
  if (body.errors && Object.keys(body.errors).length) { SOURCE_STATE.footballConnected=false; SOURCE_STATE.footballLastError=JSON.stringify(body.errors); throw httpError(502, JSON.stringify(body.errors)); }
  SOURCE_STATE.footballConnected=true; SOURCE_STATE.footballLastSuccess=new Date().toISOString(); SOURCE_STATE.footballLastError=null;
  const providerRemaining = Number(response.headers.get('x-ratelimit-requests-remaining'));
  if (Number.isFinite(providerRemaining) && providerRemaining >= 0) { process.env.FOOTBALL_PROVIDER_REMAINING = String(providerRemaining); }
  cacheSet(key, body, ttl(endpoint, params)); return body;
}
async function newsGet(params = {}) {
  if (!NEWS_KEY) throw httpError(503, 'مصدر الأخبار غير مضبوط على الخادم.');
  const p = new URLSearchParams({ apikey: NEWS_KEY, language: 'ar', category: 'sports', size: '10', removeduplicate: '1', ...params });
  const key = `news:${p.toString().replace(NEWS_KEY, 'hidden')}`; const cached = cacheGet(key); if (cached) return cached;
  let response; try { response = await fetch(`https://newsdata.io/api/1/latest?${p}`, { signal: AbortSignal.timeout(20_000) }); } catch (err) { SOURCE_STATE.newsConnected=false; SOURCE_STATE.newsLastError=err?.cause?.code || err?.message || 'network'; throw httpError(502, 'تعذر الوصول إلى مزود الأخبار من الخادم. تحقق من اتصال الاستضافة بالإنترنت ثم أعد المحاولة.'); }
  const body = await response.json().catch(() => null);
  if (!response.ok || body?.status === 'error') { SOURCE_STATE.newsConnected=false; SOURCE_STATE.newsLastError=body?.results?.message || body?.message || `HTTP ${response.status}`; throw httpError(response.status || 502, SOURCE_STATE.newsLastError || 'تعذر جلب الأخبار من المصدر.'); }
  SOURCE_STATE.newsConnected=true; SOURCE_STATE.newsLastSuccess=new Date().toISOString(); SOURCE_STATE.newsLastError=null;
  const seen = new Set();
  const results = (Array.isArray(body?.results) ? body.results : []).filter(a => {
    if (!a || a.duplicate === true || !a.title || !a.link) return false;
    const id = String(a.article_id || a.link || a.title).toLowerCase();
    if (seen.has(id)) return false; seen.add(id); return true;
  }).map(a => ({
    id: a.article_id || a.link, title: a.title, description: a.description || '', content: a.content || '',
    image: a.image_url || '', source: a.source_name || a.source_id || 'مصدر إخباري', sourceIcon: a.source_icon || '',
    sourceUrl: a.source_url || '', date: a.pubDate || '', url: a.link, language: a.language || 'ar',
    category: Array.isArray(a.category) ? a.category : [], country: Array.isArray(a.country) ? a.country : [],
    video: a.video_url || '', duplicate: false
  }));
  const normalized = { status: body?.status || 'success', totalResults: results.length, nextPage: body?.nextPage || null, results };
  cacheSet(key, normalized, 45 * 60_000); return normalized;
}


// Keyless public fallback for fixtures. SportScore requires visible attribution.
const SPORTSCORE_BASE = process.env.SPORTSCORE_BASE_URL || 'https://sportscore.com';
const SPORTSCORE_COMPETITIONS = {
  '39':'premier-league','140':'la-liga','135':'serie-a','78':'bundesliga',
  '61':'ligue-1','2':'uefa-champions-league','3':'uefa-europa-league',
  '848':'uefa-europa-conference-league','307':'saudi-pro-league'
};
function firstValue(...values) { return values.find(v => v !== undefined && v !== null && v !== ''); }
function rowsFromSportScore(body) {
  const candidates = [body?.matches, body?.fixtures, body?.results, body?.events, body?.items,
    body?.data?.matches, body?.data?.fixtures, body?.data?.results, body?.data?.events,
    body?.data?.items, body?.response, body?.data];
  return candidates.find(Array.isArray) || [];
}
async function sportScoreGet(endpoint, params = {}) {
  const query = qsOf(params);
  const key = `sportscore:${endpoint}?${query}`;
  const cached = cacheGet(key); if (cached) return cached;
  const url = `${SPORTSCORE_BASE}${endpoint}${query ? `?${query}` : ''}`;
  let response;
  try {
    response = await fetch(url, { headers:{Accept:'application/json','User-Agent':'KORA-X/1.8.0'}, signal:AbortSignal.timeout(15_000) });
  } catch (err) {
    SOURCE_STATE.sportscoreConnected = false;
    SOURCE_STATE.sportscoreLastError = err?.cause?.code || err?.message || 'network';
    throw httpError(502, 'تعذر الوصول إلى مصدر المباريات البديل SportScore.');
  }
  const body = await response.json().catch(() => null);
  if (!response.ok || !body || body.status === 'error' || body.error) {
    SOURCE_STATE.sportscoreConnected = false;
    SOURCE_STATE.sportscoreLastError = body?.message || body?.error || `HTTP ${response.status}`;
    throw httpError(response.status >= 400 ? response.status : 502, 'مصدر SportScore لم يرجع بيانات صالحة.');
  }
  SOURCE_STATE.sportscoreConnected = true;
  SOURCE_STATE.sportscoreLastSuccess = new Date().toISOString();
  SOURCE_STATE.sportscoreLastError = null;
  cacheSet(key, body, 60_000);
  return body;
}
function sportScoreTeam(value, fallbackName, fallbackLogo, fallbackId) {
  const x = value && typeof value === 'object' ? value : {name:value};
  return { id:firstValue(x.id,x.team_id,x.slug,fallbackId,null),
    name:firstValue(x.name,x.title,x.team_name,fallbackName,'—'),
    logo:firstValue(x.logo,x.image,x.crest,x.badge,fallbackLogo,'') };
}
function sportScoreStatus(value, statusText, elapsedValue) {
  const raw = String(value?.short || value?.code || value?.type || value || statusText || '').toLowerCase();
  const text = String(value?.long || value?.text || statusText || value || 'غير محدد');
  const elapsed = Number(firstValue(value?.elapsed,value?.minute,elapsedValue));
  if (/\b(ft|aet|pen|finished|finish|ended|full time|complete)\b/i.test(raw)) return {short:'FT',long:text || 'انتهت',elapsed:Number.isFinite(elapsed)?elapsed:null};
  if (/\b(ht|half.?time)\b/i.test(raw)) return {short:'HT',long:text || 'استراحة',elapsed:Number.isFinite(elapsed)?elapsed:null};
  if (/\b(live|playing|in.?play|1h|2h|et|extra.?time|penalty)\b/i.test(raw)) return {short:/\b(2h|et)\b/i.test(raw)?'2H':'1H',long:text || 'مباشر',elapsed:Number.isFinite(elapsed)?elapsed:null};
  if (/\b(ns|scheduled|upcoming|not.?started|fixture|tbd)\b/i.test(raw)) return {short:'NS',long:text || 'لم تبدأ',elapsed:null};
  return {short:raw.toUpperCase() || 'NS',long:text,elapsed:Number.isFinite(elapsed)?elapsed:null};
}
function normalizeSportScoreFixture(raw) {
  if (raw?.fixture && raw?.teams) return raw;
  const m = raw?.match || raw?.fixture_data || raw?.event || raw || {};
  const home = sportScoreTeam(firstValue(m.home_team,m.homeTeam,m.home,m.teams?.home,m.participants?.home,{}),m.home_name,m.home_logo,m.home_id);
  const away = sportScoreTeam(firstValue(m.away_team,m.awayTeam,m.away,m.teams?.away,m.participants?.away,{}),m.away_name,m.away_logo,m.away_id);
  const cr = firstValue(m.competition,m.league,m.tournament,m.competition_info,{});
  const competition = cr && typeof cr === 'object' ? cr : {name:cr};
  const score = firstValue(m.score,m.scores,m.goals,{}) || {};
  const homeGoals = firstValue(m.home_score,m.homeScore,m.score_home,score.home,score.home_score,score.full_time?.home,null);
  const awayGoals = firstValue(m.away_score,m.awayScore,m.score_away,score.away,score.away_score,score.full_time?.away,null);
  const date = firstValue(m.time,m.date,m.datetime,m.kickoff,m.start_time,m.utcDate,'');
  const slug = firstValue(m.slug,m.match_slug,m.url_slug,m.urlSlug,m.id,m.match_id,m.fixture_id,
    `${String(home.name).toLowerCase().replace(/[^a-z0-9]+/g,'-')}-vs-${String(away.name).toLowerCase().replace(/[^a-z0-9]+/g,'-')}-${String(date).slice(0,10)}`);
  const status = sportScoreStatus(m.status,m.status_text||m.statusText,m.minute||m.elapsed);
  return {
    source:'SportScore',
    fixture:{id:'ss-'+String(slug).replace(/^ss-/,'') ,slug:String(slug),date,timestamp:m.timestamp || (date ? Math.floor(Date.parse(date)/1000) : null),
      venue:{name:firstValue(m.venue?.name,m.stadium?.name,m.venue,'')},status,referee:m.referee||''},
    league:{id:firstValue(competition.id,competition.league_id,competition.slug,m.competition_slug,m.league_slug,''),
      name:firstValue(competition.name,competition.title,m.competition_name,m.league_name,m.tournament_name,'مباريات كرة القدم'),
      country:firstValue(competition.country?.name,competition.country,m.country,''),
      logo:firstValue(competition.logo,competition.image,competition.crest,m.competition_logo,m.league_logo,''),
      season:firstValue(competition.season,m.season,null),round:firstValue(m.round,competition.round,'')},
    teams:{home,away},goals:{home:homeGoals,away:awayGoals},score,_sportscoreSlug:String(slug)
  };
}
async function sportScoreFixtures(date, liveOnly = false) {
  const params = {sport:'football',date,limit:200,src:'KORA-X'};
  if (liveOnly) params.status = 'live';
  let body;
  try { body = await sportScoreGet('/api/v1/fixtures/',params); }
  catch (firstError) {
    // The widget endpoint is a secondary live/recent fallback if the date endpoint is unavailable.
    if (!liveOnly) throw firstError;
    body = await sportScoreGet('/api/widget/matches/',{sport:'football',limit:50,src:'KORA-X'});
  }
  let rows = rowsFromSportScore(body).map(normalizeSportScoreFixture);
  if (liveOnly) rows = rows.filter(x => ['1H','2H','HT','ET','P'].includes(x.fixture?.status?.short));
  return {get:[],parameters:params,errors:[],results:rows.length,response:rows,source:'SportScore',attribution:'Powered by SportScore'};
}
function normalizeSportScoreEvents(rows) {
  return (Array.isArray(rows)?rows:[]).map(e=>({
    time:{elapsed:firstValue(e.time?.elapsed,e.minute,e.elapsed,e.time,''),extra:firstValue(e.time?.extra,e.added_time,e.extra_time,null)},
    type:firstValue(e.type,e.event,e.kind,e.card,'حدث'),detail:firstValue(e.detail,e.description,e.text,e.result,''),
    team:sportScoreTeam(e.team||e.participant||{},'','',null),player:{name:firstValue(e.player?.name,e.player_name,e.player,'')},
    assist:{name:firstValue(e.assist?.name,e.assist_name,'')}
  }));
}
function normalizeSportScoreLineups(value) {
  if (!value) return [];
  const source = Array.isArray(value) ? value : [
    value.home?{...value.home,team:value.home.team||value.home_team||'الفريق الأول'}:null,
    value.away?{...value.away,team:value.away.team||value.away_team||'الفريق الثاني'}:null
  ].filter(Boolean);
  return source.map((x,index)=>{
    if (Array.isArray(x.startXI)) return x;
    const starters=firstValue(x.starting_xi,x.startingXI,x.starters,x.starting,x.players?.starting,[]);
    const subs=firstValue(x.substitutes,x.bench,x.players?.substitutes,[]);
    const makePlayer=p=>({player:{id:firstValue(p.player?.id,p.id,p.player_id,null),name:firstValue(p.player?.name,p.name,p.player_name,'لاعب'),
      number:firstValue(p.player?.number,p.number,p.shirt_number,null),pos:firstValue(p.player?.pos,p.position,p.pos,''),
      grid:firstValue(p.player?.grid,p.grid,null),photo:firstValue(p.player?.photo,p.photo,p.image,p.avatar,'')}});
    return {team:sportScoreTeam(x.team||x.participant||{},x.team_name||(index?'الفريق الثاني':'الفريق الأول'),x.logo,null),
      formation:firstValue(x.formation,x.shape,''),coach:x.coach||{},
      startXI:(Array.isArray(starters)?starters:[]).map(makePlayer),substitutes:(Array.isArray(subs)?subs:[]).map(makePlayer)};
  });
}
function normalizeSportScoreDetail(body) {
  const root=body?.data&&typeof body.data==='object'?body.data:body;
  const rawMatch=firstValue(root?.match,root?.fixture,root?.event,root?.game,root);
  const match=normalizeSportScoreFixture(rawMatch);
  const eventRows=firstValue(root?.events,root?.timeline,root?.incidents,rawMatch?.events,rawMatch?.timeline,[]);
  const lineupRows=firstValue(root?.lineups,root?.lineup,rawMatch?.lineups,[]);
  const statRows=firstValue(root?.statistics,root?.stats,rawMatch?.statistics,[]);
  const statistics=Array.isArray(statRows)?statRows.map((entry,index)=>{
    if(Array.isArray(entry.statistics))return entry;
    const pairs=entry.stats||entry.values||entry.statistics||[];
    return {team:sportScoreTeam(entry.team||entry.participant||{},index?match.teams.away.name:match.teams.home.name,'',null),
      statistics:Array.isArray(pairs)?pairs.map(x=>({type:firstValue(x.type,x.name,x.label,'إحصائية'),value:firstValue(x.value,x.total,x.count,'—')})):[]};
  }):[];
  return {details:[match],events:normalizeSportScoreEvents(eventRows),lineups:normalizeSportScoreLineups(lineupRows),statistics,
    players:Array.isArray(root?.players)?root.players:[],source:'SportScore',attribution:'Powered by SportScore'};
}
function sportScoreSlugForLeague(id) { return SPORTSCORE_COMPETITIONS[String(id)] || null; }
function normalizeSportScoreStandings(body) {
  const root=body?.data&&typeof body.data==='object'?body.data:body;
  const raw=firstValue(root?.standings,root?.table,root?.rows,root?.groups,root?.items,[]);
  const groups=Array.isArray(raw)?raw:(raw&&typeof raw==='object'?Object.values(raw):[]);
  const rows=groups.flatMap(g=>Array.isArray(g)?g:(Array.isArray(g?.table)?g.table:Array.isArray(g?.rows)?g.rows:(g?.team||g?.club||g?.participant)?[g]:[]));
  const normalized=rows.map((r,i)=>({rank:firstValue(r.rank,r.position,r.place,i+1),team:sportScoreTeam(r.team||r.club||r.participant||{},r.team_name||r.name,r.team_logo||r.logo,r.team_id),
    all:{played:firstValue(r.played,r.played_matches,r.matches_played,r.all?.played,'—'),win:firstValue(r.won,r.wins,r.win,r.all?.win,'—'),draw:firstValue(r.drawn,r.draws,r.draw,r.all?.draw,'—'),lose:firstValue(r.lost,r.losses,r.lose,r.all?.lose,'—')},
    goalsDiff:firstValue(r.goal_difference,r.goals_diff,r.goalsDiff,'—'),points:firstValue(r.points,r.pts,'—')}));
  return {response:[{league:{standings:normalized.length?[normalized]:[]}}],source:'SportScore',attribution:'Powered by SportScore'};
}
function normalizeSportScoreScorers(body,kind) {
  const root=body?.data&&typeof body.data==='object'?body.data:body;
  const rows=firstValue(root?.scorers,root?.players,root?.topscorers,root?.items,[]);
  return {response:(Array.isArray(rows)?rows:[]).map((r,i)=>{const p=r.player||r.person||r;const goals=firstValue(r.goals,r.goal_count,r.total_goals,r.count,p.goals,0);const assists=firstValue(r.assists,r.assist_count,p.assists,0);
    return {player:{id:firstValue(p.id,p.slug,i),name:firstValue(p.name,p.full_name,'لاعب'),photo:firstValue(p.photo,p.image,p.avatar,''),nationality:p.nationality||''},
      statistics:[{team:sportScoreTeam(r.team||r.club||{},r.team_name,r.team_logo,null),games:{appearences:firstValue(r.appearances,r.apps,'—')},goals:{total:kind==='goals'?goals:0,assists:kind==='assists'?assists:0}}]};}),source:'SportScore',attribution:'Powered by SportScore'};
}

function decodeXml(value) {
  return String(value||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]+>/g,' ')
    .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'")
    .replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16))).replace(/\s+/g,' ').trim();
}
function xmlTag(block,tag){const match=block.match(new RegExp('<'+tag+'\\b[^>]*>([\\s\\S]*?)</'+tag+'>','i'));return match?decodeXml(match[1]):'';}
async function googleNewsRss(scope,target='') {
  const qmap={all:'كرة القدم OR الدوري الإنجليزي OR الدوري المصري OR دوري أبطال أوروبا',world:'كرة القدم OR دوري أبطال أوروبا OR الدوري الإنجليزي OR كأس العالم',egypt:'الأهلي OR الزمالك OR منتخب مصر OR الدوري المصري',arab:'كرة القدم السعودية OR كرة القدم المصرية OR الدوري الإماراتي OR المنتخبات العربية',transfers:'انتقالات كرة القدم OR صفقة انتقال OR تجديد عقد OR إعارة',leagues:'الدوري الإنجليزي OR الدوري الإسباني OR الدوري الإيطالي OR الدوري المصري',competitions:'بطولة كرة القدم OR دوري أبطال أوروبا OR كأس أمم إفريقيا OR كأس العالم',clubs:'ريال مدريد OR برشلونة OR الأهلي OR الزمالك OR ليفربول',national:'منتخب مصر OR المنتخبات العربية OR تصفيات كأس العالم',league:target?target+' كرة القدم':'الدوري كرة القدم',club:target?target+' كرة القدم':'نادي كرة القدم'};
  const query=(qmap[scope]||qmap.all)+' when:7d';
  const key='google-news-rss:'+scope+':'+target;
  const cached=cacheGet(key);if(cached)return cached;
  const url='https://news.google.com/rss/search?q='+encodeURIComponent(query)+'&hl=ar&gl=EG&ceid=EG:ar';
  const response=await fetch(url,{headers:{Accept:'application/rss+xml, application/xml, text/xml','User-Agent':'KORA-X/1.8.0 (+web-only football news reader)'},signal:AbortSignal.timeout(12_000)});
  if(!response.ok)throw httpError(502,'تعذر الوصول إلى موجز الأخبار العربي.');
  const xml=await response.text();
  const results=[...xml.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi)].map(match=>{
    const block=match[1],title=xmlTag(block,'title'),link=xmlTag(block,'link'),pubDate=xmlTag(block,'pubDate'),sourceMatch=block.match(/<source\b[^>]*>([\s\S]*?)<\/source>/i),source=sourceMatch?decodeXml(sourceMatch[1]):'Google News';
    if(!title||!link)return null;
    const mediaMatch=block.match(/<(?:media:content|media:thumbnail|enclosure)\b[^>]*url=[\"']([^\"']+)[\"'][^>]*>/i);
    const desc=xmlTag(block,'description');
    const descImage=desc.match(/<img\b[^>]*src=[\"']([^\"']+)[\"']/i);
    const image=mediaMatch?decodeXml(mediaMatch[1]):(descImage?decodeXml(descImage[1]):'');
    return {id:'google-news:'+link,title,description:'',content:'',image,source,sourceIcon:'',sourceUrl:link,date:pubDate,url:link,language:'ar',category:['sports'],country:['eg'],video:'',duplicate:false};
  }).filter(Boolean).slice(0,30);
  const data={status:'success',totalResults:results.length,nextPage:null,results};
  SOURCE_STATE.newsConnected=true; SOURCE_STATE.newsLastSuccess=new Date().toISOString(); SOURCE_STATE.newsLastError=null;
  cacheSet(key,data,15*60_000);return data;
}

function safeCommentFile() {
  try { fs.mkdirSync(path.dirname(commentFile), { recursive: true }); if (!fs.existsSync(commentFile)) fs.writeFileSync(commentFile, '{}'); return JSON.parse(fs.readFileSync(commentFile, 'utf8') || '{}'); }
  catch { return {}; }
}
function writeComments(data) { fs.mkdirSync(path.dirname(commentFile), { recursive: true }); fs.writeFileSync(commentFile, JSON.stringify(data, null, 2), 'utf8'); }
function rateLimit(req, key, max, windowMs) {
  const ip = req.socket.remoteAddress || 'unknown'; const id = `${key}:${ip}`; const now = Date.now();
  const items = (ipBuckets.get(id) || []).filter(t => now - t < windowMs);
  if (items.length >= max) throw httpError(429, 'تجاوزت حد الطلبات المسموح. حاول بعد قليل.');
  items.push(now); ipBuckets.set(id, items);
}
async function readJson(req, max = 8192) {
  let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > max) throw httpError(413, 'حجم الطلب أكبر من المسموح.'); }
  try { return JSON.parse(raw || '{}'); } catch { throw httpError(400, 'صيغة البيانات غير صحيحة.'); }
}
function send(res, status, body) { const data = JSON.stringify(body); res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(data); }
function intParam(q, key, fallback) { const n = Number(q.get(key)); return Number.isInteger(n) && n > 0 ? n : fallback; }


function readDb(file, fallback) {
  try { fs.mkdirSync(path.dirname(file), { recursive:true }); if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2)); return JSON.parse(fs.readFileSync(file,'utf8') || JSON.stringify(fallback)); }
  catch { return structuredClone(fallback); }
}
function writeDb(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive:true });
  const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode:0o600 }); fs.renameSync(tmp,file);
}
function persistSessionStore() { writeDb(sessionFile, Object.fromEntries(sessions)); }
function loadSessionStore() {
  const saved = readDb(sessionFile, {});
  for (const [token, session] of Object.entries(saved || {})) {
    if (session && typeof session.userId === 'string' && Number(session.expires) > Date.now()) sessions.set(token, session);
  }
  persistSessionStore();
}
loadSessionStore();
function cookieValue(req, name) {
  const raw = String(req.headers.cookie || '');
  for (const part of raw.split(';')) { const i=part.indexOf('='); if(i<0) continue; if(part.slice(0,i).trim()===name) return decodeURIComponent(part.slice(i+1).trim()); }
  return '';
}
function currentUser(req) {
  const token=cookieValue(req,sessionCookie), session=sessions.get(token);
  if(!session || session.expires<Date.now()){ if(token&&sessions.delete(token))persistSessionStore(); return null; }
  const db=readDb(userFile,{users:[]}); const user=db.users.find(x=>x.id===session.userId);
  return user ? {id:user.id,email:user.email,displayName:user.displayName,createdAt:user.createdAt} : null;
}
function setSession(req,res,userId) {
  const token=crypto.randomBytes(32).toString('base64url');
  sessions.set(token,{userId,expires:Date.now()+14*24*60*60*1000});
  persistSessionStore();
  const secure=Boolean(req.socket.encrypted || req.headers['x-forwarded-proto']==='https');
  res.setHeader('Set-Cookie',`${sessionCookie}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=1209600${secure?'; Secure':''}`);
}
function clearSession(req,res) {
  const token=cookieValue(req,sessionCookie); if(token&&sessions.delete(token))persistSessionStore();
  const secure=Boolean(req.socket.encrypted || req.headers['x-forwarded-proto']==='https');
  res.setHeader('Set-Cookie',`${sessionCookie}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure?'; Secure':''}`);
}
async function handleApi(req, url, res) {
  const p = url.pathname, q = url.searchParams;
  if (p === '/api/auth/me' && req.method === 'GET') return send(res,200,{user:currentUser(req)});
  if (p === '/api/auth/register' && req.method === 'POST') {
    rateLimit(req,'auth-register',8,60*60_000); const body=await readJson(req);
    const displayName=String(body.displayName||'').trim().slice(0,32), email=String(body.email||'').trim().toLowerCase(), password=String(body.password||'');
    if(displayName.length<2)throw httpError(400,'اكتب اسمًا من حرفين على الأقل.');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw httpError(400,'أدخل بريدًا إلكترونيًا صحيحًا.');
    if(password.length<8 || password.length>128)throw httpError(400,'كلمة المرور يجب أن تكون 8 أحرف على الأقل.');
    const db=readDb(userFile,{users:[]}); if(db.users.some(x=>x.email===email))throw httpError(409,'هذا البريد مسجل بالفعل. سجّل الدخول بدلًا من إنشاء حساب جديد.');
    const salt=crypto.randomBytes(16).toString('hex'); const hash=(await scrypt(password,salt,64)).toString('hex');
    const user={id:crypto.randomUUID(),email,displayName,salt,hash,createdAt:new Date().toISOString()}; db.users.push(user); writeDb(userFile,db); setSession(req,res,user.id);
    return send(res,201,{user:{id:user.id,email:user.email,displayName:user.displayName,createdAt:user.createdAt}});
  }
  if (p === '/api/auth/login' && req.method === 'POST') {
    rateLimit(req,'auth-login',12,15*60_000); const body=await readJson(req); const email=String(body.email||'').trim().toLowerCase(), password=String(body.password||'');
    const db=readDb(userFile,{users:[]}); const user=db.users.find(x=>x.email===email);
    if(!user || !user.salt || !user.hash)throw httpError(401,'البريد أو كلمة المرور غير صحيحة.');
    const hash=await scrypt(password,user.salt,64); const expected=Buffer.from(user.hash,'hex');
    if(expected.length!==hash.length || !crypto.timingSafeEqual(expected,hash))throw httpError(401,'البريد أو كلمة المرور غير صحيحة.');
    setSession(req,res,user.id); return send(res,200,{user:{id:user.id,email:user.email,displayName:user.displayName,createdAt:user.createdAt}});
  }
  if (p === '/api/auth/logout' && req.method === 'POST') { clearSession(req,res); return send(res,200,{ok:true}); }
  if (p === '/api/predictions/my' && req.method === 'GET') {
    const user = currentUser(req);
    if (!user) throw httpError(401, 'سجّل الدخول أولًا لحفظ توقعاتك.');
    const db = readDb(predictionsFile, { predictions: [] });
    const rows = (db.predictions || []).filter(x => x.userId === user.id)
      .sort((a,b) => Date.parse(b.updatedAt || b.createdAt) - Date.parse(a.updatedAt || a.createdAt));
    return send(res, 200, { predictions: rows, user });
  }
  if (p === '/api/predictions' && req.method === 'POST') {
    rateLimit(req, 'match-prediction', 30, 60 * 60_000);
    const user = currentUser(req);
    if (!user) throw httpError(401, 'سجّل الدخول أولًا لحفظ توقعك.');
    const body = await readJson(req);
    const fixtureId = String(body.fixtureId || '');
    const hg = Number(body.homeGoals), ag = Number(body.awayGoals);
    if (!/^\d{1,12}$/.test(fixtureId) || !Number.isInteger(hg) || !Number.isInteger(ag) || hg < 0 || ag < 0 || hg > 20 || ag > 20) {
      throw httpError(400, 'أدخل نتيجة صحيحة من 0 إلى 20.');
    }
    const fixtureBody = await footballGet('fixtures', { id: fixtureId, timezone: 'Africa/Cairo' });
    const f = fixtureBody.response?.[0];
    if (!f?.fixture?.id) throw httpError(404, 'لم نعثر على المباراة في مصدر النتائج.');
    if (!['NS','TBD','PST'].includes(f.fixture.status?.short) || Date.parse(f.fixture.date || '') <= Date.now()) {
      throw httpError(409, 'بدأت المباراة أو لم تعد متاحة للتوقع.');
    }
    const db = readDb(predictionsFile, { predictions: [] });
    const existing = db.predictions.find(x => x.userId === user.id && String(x.fixtureId) === fixtureId);
    const record = {
      id: existing?.id || crypto.randomUUID(), userId: user.id, displayName: user.displayName,
      fixtureId, kickoff: f.fixture.date,
      fixtureLabel: `${f.teams?.home?.name || 'الفريق الأول'} × ${f.teams?.away?.name || 'الفريق الثاني'}`,
      homeTeam: f.teams?.home?.name || '', awayTeam: f.teams?.away?.name || '',
      homeLogo: f.teams?.home?.logo || '', awayLogo: f.teams?.away?.logo || '',
      league: f.league?.name || '', homeGoals: hg, awayGoals: ag,
      createdAt: existing?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    if (existing) Object.assign(existing, record); else db.predictions.push(record);
    writeDb(predictionsFile, db);
    return send(res, 201, { prediction: record, message: existing ? 'تم تحديث توقعك.' : 'تم حفظ توقعك للمباراة.' });
  }
  if (req.method === 'GET' && p === '/api/health') return send(res, 200, { ok:true, appVersion:'1.8.0', mode:'web-only-no-keys', dataProvider:'Public web sources + SportScore', footballConfigured:false, newsConfigured:false, newsRssAvailable:true, newsProvider:'Google News RSS', sportscoreRequiresApiKey:false, sportscoreAttributionRequired:true, attributionVisible:true, supportedCompetitions:Object.keys(SPORTSCORE_COMPETITIONS).length, persistentStorageConfigured:Boolean(process.env.KORA_DATA_DIR), sources:SOURCE_STATE, now:new Date().toISOString() });
  if (req.method === 'GET' && p === '/api/fixtures') {
    const date = q.get('date') || localDateCairo();
    const wantsLive = q.get('live') === 'all';
    const wantsHistoricalRange = q.has('last') || q.has('next') || q.has('from') || q.has('to');
    // One canonical provider for daily and live fixtures. Do not force a calendar-year
    // season onto a global date query: leagues can be in different season years.
    const params = { timezone:'Africa/Cairo' };
    if (wantsLive) params.live = 'all';
    else if (q.has('date') || !wantsHistoricalRange) params.date = date;
    for (const k of ['league','team','status','last','next','from','to','round','venue']) if (q.has(k)) params[k] = q.get(k);
    if (q.has('season')) params.season = q.get('season');
    else if (!wantsLive && (q.has('league') || q.has('team') || wantsHistoricalRange)) params.season = String(FOOTBALL_DEFAULT_SEASON);
    if (FOOTBALL_KEY) {
      try {
        const primary = await footballGet('fixtures',params);
        if (Array.isArray(primary.response) && primary.response.length) return send(res,200,primary);
      } catch (primaryError) {
        // Continue to the no-key public data source for daily/live fixtures.
        SOURCE_STATE.footballLastError = primaryError.message;
      }
    }
    if (wantsHistoricalRange || q.has('team') || q.has('league')) {
      const slug = q.get('league') ? sportScoreSlugForLeague(q.get('league')) : null;
      if (!slug) throw httpError(503,'هذا النوع من البحث غير متاح ضمن مصادر الويب العامة الحالية لهذه البطولة.');
      const fallback = await sportScoreGet('/api/v1/fixtures/',{sport:'football',date,competition:slug,limit:200,src:'KORA-X'});
      const rows = rowsFromSportScore(fallback).map(normalizeSportScoreFixture);
      return send(res,200,{response:rows,results:rows.length,source:'SportScore',attribution:'Powered by SportScore'});
    }
    const fallback = await sportScoreFixtures(date,wantsLive);
    return send(res,200,fallback);
  }

  if (req.method === 'GET' && p === '/api/leagues') {
    const catalog = [
      ['39','الدوري الإنجليزي الممتاز','England','premier-league'],
      ['140','الدوري الإسباني','Spain','la-liga'],
      ['135','الدوري الإيطالي','Italy','serie-a'],
      ['78','الدوري الألماني','Germany','bundesliga'],
      ['61','الدوري الفرنسي','France','ligue-1'],
      ['2','دوري أبطال أوروبا','Europe','uefa-champions-league'],
      ['3','الدوري الأوروبي','Europe','uefa-europa-league'],
      ['848','دوري المؤتمر الأوروبي','Europe','uefa-europa-conference-league'],
      ['307','الدوري السعودي للمحترفين','Saudi Arabia','saudi-pro-league']
    ].map(([id,name,country,slug])=>({league:{id:Number(id),name,type:'League',logo:''},country:{name:country},seasons:[{year:FOOTBALL_DEFAULT_SEASON,current:true}],_sportscoreSlug:slug}));
    const term=(q.get('search')||'').toLowerCase();
    const rows=catalog.filter(x=>!term||x.league.name.toLowerCase().includes(term)||x.country.name.toLowerCase().includes(term));
    return send(res,200,{get:[],parameters:{},errors:[],results:rows.length,response:rows,source:'KORA-X public web catalog'});
  }
  if (req.method === 'GET' && p === '/api/standings') {
    if (!q.get('league') || !q.get('season')) throw httpError(400,'حدد البطولة والموسم.');
    if (FOOTBALL_KEY) { try { return send(res,200,await footballGet('standings',{league:q.get('league'),season:q.get('season'),team:q.get('team')})); } catch (e) { SOURCE_STATE.footballLastError=e.message; } }
    const slug=sportScoreSlugForLeague(q.get('league'));
    if (!slug) throw httpError(503,'ترتيب هذه البطولة غير متاح من مصدر الويب الحالي.');
    return send(res,200,normalizeSportScoreStandings(await sportScoreGet('/api/widget/standings/',{sport:'football',slug,src:'KORA-X'})));
  }
  if (req.method === 'GET' && p === '/api/teams') {
    const params = {}; for (const k of ['search','id','country','league','season','code','venue']) if (q.has(k)) params[k] = q.get(k);
    if (!Object.keys(params).length) throw httpError(400, 'أدخل اسم الفريق للبحث.'); return send(res, 200, await footballGet('teams', params));
  }
  if (req.method === 'GET' && p === '/api/teams/seasons') { if (!q.get('team')) throw httpError(400, 'حدد الفريق.'); return send(res, 200, await footballGet('teams/seasons', { team:q.get('team') })); }
  if (req.method === 'GET' && p === '/api/squad') { if (!q.get('team')) throw httpError(400, 'حدد الفريق.'); return send(res, 200, await footballGet('players/squads', { team:q.get('team') })); }
  if (req.method === 'GET' && p === '/api/team-stats') { for (const k of ['team','league','season']) if (!q.get(k)) throw httpError(400, 'بيانات إحصائيات الفريق غير مكتملة.'); return send(res, 200, await footballGet('teams/statistics', { team:q.get('team'), league:q.get('league'), season:q.get('season') })); }
  if (req.method === 'GET' && p === '/api/coaches') { if (!q.get('team') && !q.get('search')) throw httpError(400, 'حدد الفريق أو اسم المدرب.'); return send(res, 200, await footballGet('coachs', { team:q.get('team'), search:q.get('search'), id:q.get('id') })); }
  if (req.method === 'GET' && p === '/api/players') {
    const params = {}; for (const k of ['search','id','team','league','season','page']) if (q.has(k)) params[k] = q.get(k);
    if (!params.search && !params.id && !params.team) throw httpError(400, 'أدخل اسم اللاعب أو الفريق.');
    if (params.search && params.search.length < 4) throw httpError(400, 'اكتب أربعة أحرف على الأقل للبحث عن اللاعب.');
    params.season = params.season || FOOTBALL_DEFAULT_SEASON; return send(res, 200, await footballGet('players', params));
  }
  if (req.method === 'GET' && p === '/api/player-teams') { if (!q.get('player')) throw httpError(400, 'حدد اللاعب.'); return send(res, 200, await footballGet('players/teams', { player:q.get('player') })); }
  if (req.method === 'GET' && p === '/api/topscorers') {
    if (!q.get('league') || !q.get('season')) throw httpError(400,'حدد البطولة والموسم.');
    if (FOOTBALL_KEY) { try { return send(res,200,await footballGet('players/topscorers',{league:q.get('league'),season:q.get('season')})); } catch (e) { SOURCE_STATE.footballLastError=e.message; } }
    const slug=sportScoreSlugForLeague(q.get('league')); if(!slug) throw httpError(503,'الهدافون غير متاحين لهذه البطولة من المصدر البديل.');
    return send(res,200,normalizeSportScoreScorers(await sportScoreGet('/api/widget/topscorers/',{sport:'football',slug,limit:50,stat:'goals',src:'KORA-X'}),'goals'));
  }
  if (req.method === 'GET' && p === '/api/topassists') {
    if (!q.get('league') || !q.get('season')) throw httpError(400,'حدد البطولة والموسم.');
    if (FOOTBALL_KEY) { try { return send(res,200,await footballGet('players/topassists',{league:q.get('league'),season:q.get('season')})); } catch (e) { SOURCE_STATE.footballLastError=e.message; } }
    const slug=sportScoreSlugForLeague(q.get('league')); if(!slug) throw httpError(503,'صانعي الأهداف غير متاحين لهذه البطولة من المصدر البديل.');
    return send(res,200,normalizeSportScoreScorers(await sportScoreGet('/api/widget/topscorers/',{sport:'football',slug,limit:50,stat:'assists',src:'KORA-X'}),'assists'));
  }
  if (req.method === 'GET' && p === '/api/topcards') { if (!q.get('league') || !q.get('season')) throw httpError(400, 'حدد البطولة والموسم.'); return send(res, 200, await footballGet('players/topyellowcards', { league:q.get('league'), season:q.get('season') })); }
  if (req.method === 'GET' && p === '/api/transfers') { if (!q.get('team') && !q.get('player')) throw httpError(400, 'حدد الفريق أو اللاعب.'); return send(res, 200, await footballGet('transfers', { team:q.get('team'), player:q.get('player') })); }
  if (req.method === 'GET' && p === '/api/injuries') { const params={}; for (const k of ['league','season','team','player','fixture','date','ids']) if(q.has(k)) params[k]=q.get(k); if(!Object.keys(params).length) throw httpError(400,'حدد نطاق الإصابات.'); return send(res,200,await footballGet('injuries',params)); }
  if (req.method === 'GET' && p === '/api/predictions') { if (!q.get('fixture')) throw httpError(400,'حدد المباراة.'); return send(res,200,await footballGet('predictions',{fixture:q.get('fixture')})); }
  if (req.method === 'GET' && p === '/api/h2h') { if (!q.get('teams')) throw httpError(400,'حدد الفريقين.'); return send(res,200,await footballGet('fixtures/headtohead',{h2h:q.get('teams'),last:q.get('last')||10,timezone:'Africa/Cairo'})); }
  if (req.method === 'GET' && p === '/api/rounds') { if (!q.get('league') || !q.get('season')) throw httpError(400,'حدد البطولة والموسم.'); return send(res,200,await footballGet('fixtures/rounds',{league:q.get('league'),season:q.get('season'),current:q.get('current')||'true',dates:'true'})); }
  if (req.method === 'GET' && p === '/api/trophies') { if (!q.get('player') && !q.get('coach')) throw httpError(400,'حدد اللاعب أو المدرب.'); return send(res,200,await footballGet('trophies',{player:q.get('player'),coach:q.get('coach')})); }
  if (req.method === 'GET' && p === '/api/sidelined') { if (!q.get('player') && !q.get('coach')) throw httpError(400,'حدد اللاعب أو المدرب.'); return send(res,200,await footballGet('sidelined',{player:q.get('player'),coach:q.get('coach')})); }
  if (req.method === 'GET' && p === '/api/fixture-data') {
    const fixture = String(q.get('fixture') || '');
    const type = String(q.get('type') || '');
    const endpoint = ({events:'fixtures/events',lineups:'fixtures/lineups',statistics:'fixtures/statistics'})[type];
    if (!/^(?:\d+|ss-[A-Za-z0-9._~-]+)$/.test(fixture) || !endpoint) throw httpError(400,'طلب تفاصيل المباراة غير صحيح.');
    if (fixture.startsWith('ss-')) {
      const detail=normalizeSportScoreDetail(await sportScoreGet('/api/widget/match/',{sport:'football',slug:fixture.slice(3),src:'KORA-X'}));
      return send(res,200,{type,[type]:Array.isArray(detail[type])?detail[type]:[],source:'SportScore',attribution:'Powered by SportScore'});
    }
    const data = await footballGet(endpoint,{fixture});
    return send(res,200,{type,[type]:Array.isArray(data.response)?data.response:[]});
  }
  const fixtureMatch = p.match(/^\/api\/fixture\/([A-Za-z0-9._~-]+)$/);
  if (req.method === 'GET' && fixtureMatch) {
    const requested = decodeURIComponent(fixtureMatch[1]);
    if (requested.startsWith('ss-')) {
      const detail=normalizeSportScoreDetail(await sportScoreGet('/api/widget/match/',{sport:'football',slug:requested.slice(3),src:'KORA-X'}));
      return send(res,200,detail);
    }
    if (!/^\d+$/.test(requested)) throw httpError(400,'معرّف المباراة غير صالح.');
    const details = await footballGet('fixtures',{id:requested,timezone:'Africa/Cairo'});
    const row = details.response?.[0];
    if (!row) throw httpError(404,'لم يتم العثور على المباراة في مصدر البيانات.');
    return send(res,200,{details:[row],events:[],lineups:[],statistics:[],players:[],source:'KORA-X public web source'});
  }

  if (req.method === 'GET' && p === '/api/news') {
    const scope = q.get('scope') || 'all';
    const next = q.get('page');
    const name = (q.get('name') || '').trim().slice(0,80);
    const params = {};
    if (next) params.page = next;
    if (scope==='egypt') { params.country='eg'; params.q='كرة القدم OR الأهلي OR الزمالك OR منتخب مصر'; }
    else if (scope==='arab') params.q='كرة القدم OR الدوري OR المنتخب';
    else if (scope==='transfers') params.q='انتقالات OR انتقال OR صفقة OR إعارة OR تجديد عقد OR transfer';
    else if (scope==='leagues') params.q='الدوريات OR الدوري OR ترتيب الدوري OR جدول الدوري OR league';
    else if (scope==='competitions') params.q='بطولة OR كأس OR دوري أبطال أوروبا OR كأس العالم OR tournament';
    else if (scope==='clubs') params.q='نادي OR أندية OR ريال مدريد OR برشلونة OR الأهلي OR الزمالك OR ليفربول';
    else if (scope==='national') params.q='منتخب OR المنتخبات OR تصفيات OR كأس أمم إفريقيا';
    else if (scope==='league' || scope==='club') { if(!name) throw httpError(400,'حدد الاسم المطلوب للبحث.'); params.q=name+' OR كرة القدم '+name; }
    else if (scope==='world') params.q='كرة القدم OR دوري أبطال أوروبا OR ريال مدريد OR برشلونة OR كأس العالم';
    else params.q='كرة القدم OR الدوري OR انتقالات OR دوري أبطال أوروبا OR منتخب';
    // Public RSS search is the only news transport in this release; no API keys or paid news accounts.
    let primary = [];
    const nextPage = null;
    let primaryError = null;
    let rss = [];
    try {
      const data = await googleNewsRss(scope,name);
      rss = data.results || [];
    } catch (error) { primaryError = error; }
    const seen = new Set();
    const merged = [...primary,...rss].filter(item=>{
      const title = String(item.title||'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
      const key = String(item.url||item.link||item.id||title).toLowerCase();
      if (!title || seen.has(key) || seen.has(title)) return false;
      seen.add(key); seen.add(title); return true;
    }).sort((a,b)=>Date.parse(b.date||0)-Date.parse(a.date||0)).slice(0,30);
    if (!merged.length && primaryError) throw httpError(primaryError.status || 502, 'تعذر جلب الأخبار من الويب الآن. حاول مرة أخرى لاحقًا.');
    return send(res,200,{status:'success',totalResults:merged.length,nextPage,results:merged});
  }
  
  const commentsMatch=p.match(/^\/api\/articles\/([A-Za-z0-9_:%.-]+)\/comments$/);
  if (commentsMatch && req.method==='GET') { const id=decodeURIComponent(commentsMatch[1]); const db=safeCommentFile(); return send(res,200,{comments:Array.isArray(db[id])?db[id]:[]}); }
  if (commentsMatch && req.method==='POST') {
    rateLimit(req,'comments',4,60_000); const id=decodeURIComponent(commentsMatch[1]); const body=await readJson(req);
    const name=String(body.name||'مشجع KORA X').trim().slice(0,28); const text=String(body.text||'').trim();
    if(!text || text.length>500) throw httpError(400,'اكتب تعليقًا من حرف واحد إلى 500 حرف.');
    const db=safeCommentFile(); const rows=Array.isArray(db[id])?db[id]:[];
    const comment={id:require('node:crypto').randomUUID(),name,text,createdAt:new Date().toISOString()}; rows.push(comment); db[id]=rows.slice(-200); writeComments(db);
    return send(res,201,{comment});
  }
  return send(res,404,{error:'المسار غير موجود.'});
}

const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json','.png':'image/png','.ico':'image/x-icon'};
const STATIC=new Set(['/','/index.html','/manifest.webmanifest','/icon.svg','/icon-192.png','/icon-512.png','/sw.js']);
function serveStatic(url,res){const p=url.pathname==='/'?'/index.html':url.pathname;if(!STATIC.has(p))return send(res,404,{error:'الملف غير موجود.'});const file=path.join(ROOT,p==='/'?'index.html':p.slice(1));fs.readFile(file,(err,data)=>{if(err)return send(res,404,{error:'الملف غير موجود.'});res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','Cache-Control':p==='/index.html'?'no-cache':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});res.end(data);});}
const server=http.createServer(async(req,res)=>{
  if(CORS_ORIGIN!=='same-origin'){res.setHeader('Access-Control-Allow-Origin',CORS_ORIGIN);res.setHeader('Vary','Origin');}
  res.setHeader('X-Frame-Options','DENY'); res.setHeader('X-Content-Type-Options','nosniff');
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Accept'});return res.end();}
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try{if(url.pathname.startsWith('/api/'))return await handleApi(req,url,res);if(req.method!=='GET')return send(res,405,{error:'الطريقة غير مدعومة.'});serveStatic(url,res);}
  catch(e){send(res,Number(e.status)||500,{error:e.message||'حدث خطأ غير متوقع.'});}
});
server.listen(PORT,()=>{console.log(`KORA X v1.8.0 listening on port ${PORT}`);console.log('Mode: public web sources; no provider API keys');});
