# ShadowNex — Android starter app

This is a functional Android Studio starter for the ShadowNex concept.

Included:
- Home dashboard
- Search UI
- Horror / Comics / History / E-Books categories
- Videos page
- Social page
- Free Marketing page
- Profile page
- Dark mobile UI
- Bottom navigation

Important:
- Content shown in this starter is demo content.
- Search is local/demo only.
- No real login, database, news API, video hosting, payments, moderation, or cloud storage is connected yet.
- Before Play Store release, add a real backend, privacy policy, content moderation, copyright/licensing controls, app icon, screenshots, and production testing.

Open the `ShadowNex` folder in Android Studio and let Gradle sync/download dependencies. Then run it on an Android phone/emulator.

Package name: com.shadownex.app
Version: 1.0
