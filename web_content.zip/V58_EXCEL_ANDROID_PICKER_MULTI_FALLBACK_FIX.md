# V58 Excel Android picker multi-fallback fix

Adds three direct Android picker routes with activity resolution and automatic fallback: ACTION_OPEN_DOCUMENT, ACTION_GET_CONTENT, and ACTION_PICK.

Version 2.24 / versionCode 28.
