# Painting History — جاهز للبناء أونلاين

هذا الملف عبارة عن مشروع Android/Gradle جاهز للرفع إلى خدمة بناء Android تدعم ZIP.

## الإعدادات
- اسم التطبيق: Painting History
- applicationId: com.uvinkbook.app
- compileSdk: 35
- minSdk: 23
- targetSdk: 35
- Gradle: 8.7
- Android Gradle Plugin: 8.5.2

## البناء
اختر APK في خدمة البناء ثم ارفع ملف ZIP هذا كمشروع Android.

إذا كنت تبني محليًا:
`./gradlew :app:assembleDebug`

الناتج:
`app/build/outputs/apk/debug/app-debug.apk`
