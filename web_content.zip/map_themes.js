(function () {
  var STORAGE_KEY = "brawl_uz_map_theme_v1";

  var THEMES = [
    {
      id: "sunny",
      name: "Quyoshli Arena",
      tint: "rgba(255, 211, 42, 0.14)",
      border: "#ffd32a",
      grid: "rgba(255, 255, 255, 0.12)",
      vignette: "rgba(0, 0, 0, 0.12)"
    },
    {
      id: "neon",
      name: "Neon Tun",
      tint: "rgba(15, 23, 66, 0.42)",
      border: "#00f2fe",
      grid: "rgba(0, 242, 254, 0.18)",
      vignette: "rgba(76, 29, 149, 0.28)"
    },
    {
      id: "emerald",
      name: "Zumrad Voha",
      tint: "rgba(16, 185, 129, 0.22)",
      border: "#2ed573",
      grid: "rgba(255, 255, 255, 0.14)",
      vignette: "rgba(6, 78, 59, 0.25)"
    }
  ];

  var currentIndex = 0;
  try {
    var saved = localStorage.getItem(STORAGE_KEY);
    if (saved !== null) {
      var idx = parseInt(saved, 10);
      if (!isNaN(idx) && idx >= 0 && idx < THEMES.length) {
        currentIndex = idx;
      }
    }
  } catch (e) {}

  function getTheme() {
    return THEMES[currentIndex] || THEMES[0];
  }

  function saveThemeIndex(idx) {
    if (idx < 0 || idx >= THEMES.length) return;
    currentIndex = idx;
    try {
      localStorage.setItem(STORAGE_KEY, String(currentIndex));
    } catch (e) {}
    refreshMapTriggerLabels();
  }

  function isMenuOpen() {
    var menu = document.getElementById("menu");
    var welcome = document.getElementById("welcomeScreen");
    var mOpen = menu && getComputedStyle(menu).display !== "none";
    var wOpen = welcome && getComputedStyle(welcome).display !== "none";
    return Boolean(mOpen || wOpen);
  }

  function findMapElementsInMenu() {
    var result = [];
    var containers = [document.getElementById("menu"), document.getElementById("welcomeScreen")];
    for (var c = 0; c < containers.length; c++) {
      var root = containers[c];
      if (!root) continue;
      var nodes = root.querySelectorAll("button, div, span, label, a, select");
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (el.id && (el.id.indexOf("mapPicker") !== -1 || el.id.indexOf("menuMap") !== -1)) continue;
        var txt = (el.textContent || "").trim().toLowerCase();
        var idAttr = (el.id || "").toLowerCase();
        var clsAttr = (typeof el.className === "string" ? el.className : "").toLowerCase();
        if (
          txt.indexOf("xarita") !== -1 ||
          txt.indexOf("map") !== -1 ||
          idAttr.indexOf("map") !== -1 ||
          clsAttr.indexOf("map") !== -1
        ) {
          // Juda katta konteynerni emas, aniq tugma yoki kichik elementni olamiz
          if (txt.length > 0 && txt.length < 60 && el.children.length <= 2) {
            result.push(el);
          }
        }
      }
    }
    return result;
  }

  function refreshMapTriggerLabels() {
    var els = findMapElementsInMenu();
    var th = getTheme();
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (!el._origMapText) {
        el._origMapText = (el.textContent || "").trim();
      }
      if (el.tagName !== "SELECT") {
        var base = el._origMapText.replace(/\s*\(.*?\)\s*$/, "");
        el.textContent = base + " (" + (currentIndex + 1) + ". " + th.name + ")";
      }
      if (!el._mapClickBound) {
        el._mapClickBound = true;
        el.addEventListener("click", function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          openMapSelectModal();
        }, true);
      }
    }
  }

  function openMapSelectModal() {
    var modal = document.getElementById("mapPickerModal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "mapPickerModal";
      modal.style.cssText =
        "position:fixed;inset:0;z-index:80;background:rgba(0,0,0,0.8);" +
        "display:flex;align-items:center;justify-content:center;padding:14px;";
      document.body.appendChild(modal);
    }

    var listHtml = "";
    for (var i = 0; i < THEMES.length; i++) {
      var t = THEMES[i];
      var isSel = i === currentIndex;
      listHtml +=
        '<button data-idx="' +
        i +
        '" class="mapChoiceItemBtn" style="width:100%;text-align:left;padding:11px 13px;margin-bottom:8px;border-radius:11px;cursor:pointer;border:2px solid ' +
        (isSel ? "#ffd32a" : t.border) +
        ";background:" +
        (isSel ? "#1e272e" : "rgba(255,255,255,0.06)") +
        ';color:#fff;display:flex;justify-content:space-between;align-items:center;">' +
        '<span style="font-size:12px;font-weight:900;">' +
        (i + 1) +
        ". " +
        t.name +
        "</span>" +
        '<span style="font-size:10px;font-weight:900;padding:4px 9px;border-radius:7px;background:' +
        (isSel ? "#2ed573" : "#3742fa") +
        ";color:" +
        (isSel ? "#111" : "#fff") +
        ';">' +
        (isSel ? "TANLANGAN ✓" : "TANLASH") +
        "</span></button>";
    }

    modal.innerHTML =
      '<div style="width:100%;max-width:340px;background:#141829;border:2px solid #ffd32a;border-radius:16px;padding:14px;color:#fff;font-family:sans-serif;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
      '<div style="font-size:13px;font-weight:900;color:#ffd32a;">XARITA KO‘RINISHINI TANLANG</div>' +
      '<button id="doneMapPickBtn" style="background:#2ed573;color:#111;border:none;border-radius:8px;padding:5px 11px;font-weight:900;cursor:pointer;">TAYYOR</button>' +
      "</div>" +
      listHtml +
      "</div>";

    modal.style.display = "flex";

    document.getElementById("doneMapPickBtn").onclick = function () {
      modal.style.display = "none";
    };

    var choiceBtns = modal.querySelectorAll(".mapChoiceItemBtn");
    for (var j = 0; j < choiceBtns.length; j++) {
      choiceBtns[j].onclick = function () {
        var idx = parseInt(this.getAttribute("data-idx"), 10);
        saveThemeIndex(idx);
        modal.style.display = "none";
      };
    }
  }

  function renderMapThemeOverlay() {
    var canvas = document.querySelector("canvas");
    if (!canvas) return;
    var ctx = canvas.getContext("2d");
    if (!ctx) return;

    var th = getTheme();
    var w = canvas.width;
    var h = canvas.height;
    if (!w || !h) return;

    ctx.save();
    ctx.fillStyle = th.tint;
    ctx.fillRect(0, 0, w, h);

    var step = 64;
    ctx.strokeStyle = th.grid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (var x = 0; x <= w; x += step) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    for (var y = 0; y <= h; y += step) {
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();

    var grad = ctx.createRadialGradient(
      w * 0.5,
      h * 0.5,
      Math.min(w, h) * 0.25,
      w * 0.5,
      h * 0.5,
      Math.max(w, h) * 0.72
    );
    grad.addColorStop(0, "rgba(0,0,0,0)");
    grad.addColorStop(1, th.vignette);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  window.addEventListener("load", function () {
    // Avvalgi alohida burchak tugmasi bo'lsa yashiramiz
    var oldFloat = document.getElementById("mapThemeBtn");
    if (oldFloat) oldFloat.style.display = "none";
    var oldMenuMap = document.getElementById("menuMapBtn");
    if (oldMenuMap) oldMenuMap.style.display = "none";

    refreshMapTriggerLabels();
    setInterval(function () {
      var of = document.getElementById("mapThemeBtn");
      if (of) of.style.display = "none";
      var om = document.getElementById("menuMapBtn");
      if (om) om.style.display = "none";

      if (isMenuOpen()) {
        refreshMapTriggerLabels();
      } else {
        var m = document.getElementById("mapPickerModal");
        if (m) m.style.display = "none";
      }
      renderMapThemeOverlay();
    }, 80);
  });
})();
