MAMANG ANTER — PROYEK ANDROID

Fitur:
- Catat order pelanggan, nomor WhatsApp, layanan, alamat jemput/tujuan, ongkos, status dan catatan.
- Tombol WhatsApp untuk mengirim ringkasan order kepada pelanggan.
- Ringkasan pendapatan harian/bulanan dan catatan biaya operasional.
- Ekspor CSV dan cadangan/pemulihan JSON.
- Data disimpan lokal di perangkat.

CARA MEMBUAT APK:
1. Instal Android Studio di komputer/laptop.
2. Ekstrak folder MamangAnterAndroid.zip.
3. Android Studio > Open > pilih folder MamangAnterAndroid.
4. Tunggu Gradle Sync selesai. Pastikan Android SDK Platform 35 terpasang.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
- Ini adalah proyek sumber Android yang siap dibuka di Android Studio, bukan file APK hasil kompilasi.
- APK belum bisa dikompilasi di lingkungan ini karena Android SDK/Gradle build tools tidak tersedia.
- Data order disimpan pada perangkat dan tidak otomatis tersinkron ke perangkat lain.
- Tombol WhatsApp membutuhkan internet dan WhatsApp/browser yang sesuai.
