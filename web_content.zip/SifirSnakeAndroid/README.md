# Sifir Snake Android project

This is the Android Studio source project for an offline WebView wrapper around the Sifir Snake game.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

This ZIP is source code, not a precompiled APK. It requires Android SDK/Gradle build tools to compile.
