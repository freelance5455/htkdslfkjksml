# PancalokaTunggalPrana 184 — HTML to APK starter

Folder `www/` berisi UI HTML/CSS/JS statis. Agar menjadi APK Android, bungkus dengan Android WebView atau Capacitor.

## Opsi A — Android Studio WebView (native wrapper)
1. Buat project Android baru (Empty Views Activity, Kotlin).
2. Salin `www/index.html` ke `app/src/main/assets/index.html`.
3. Tambahkan WebView ke layout dan load:
   `webView.loadUrl("file:///android_asset/index.html")`
4. Aktifkan JavaScript hanya jika diperlukan (demo ini memerlukannya):
   `webView.settings.javaScriptEnabled = true`
5. Jangan aktifkan akses file universal atau mixed content. Jangan tambahkan permission internet jika aplikasi offline.
6. Build: `./gradlew assembleDebug`; APK ada di `app/build/outputs/apk/debug/`.

## Opsi B — Capacitor (CLI)
Persyaratan: Node.js dan Android Studio.
```bash
npm create @capacitor/app
# pilih nama PancalokaTunggalPrana184
# salin isi folder www ini ke folder web app project (webDir yang dikonfigurasi)
npx cap add android
npx cap sync android
npx cap open android
```
Lalu di Android Studio: Build > Build APK(s). Untuk release, configure signing securely.

## Keamanan
- HTML ini adalah UI/demo lokal, bukan AI model atau firewall keamanan sebenarnya.
- Status demo selalu TAHAN; tidak berpura-pura meloloskan audit 920.
- Jangan menyimpan secret/API key di HTML atau APK. Backend harus mengelola credential.
- Sebelum rilis: uji WebView, aksesibilitas, input, dependency, signing, dan security.

## Struktur
- `www/index.html` — aplikasi web satu file
- `android-notes/` — catatan wrapper/build
