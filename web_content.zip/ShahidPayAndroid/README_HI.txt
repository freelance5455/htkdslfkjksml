SHAHID PAY DEMO — Android project

यह एक ऑफलाइन Demo ऐप का Android Studio project है।
इसमें कोई असली UPI, बैंक, QR भुगतान या साउंड-बॉक्स भुगतान सूचना नहीं है।
सभी रकम और रसीदें काल्पनिक हैं और स्क्रीन पर DEMO पहचान रहती है।

APK बनाने के लिए:
1. इस ZIP को Android Studio या AndroidIDE में extract/open करें।
2. Gradle sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. बनने वाली APK को अपने फोन में install करें।

यह ZIP APK नहीं है; यह APK बनाने का project source है।
