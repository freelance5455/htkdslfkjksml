> **New here? Read START-HERE.md first (simple steps, no coding).**

# RND Miner

Static web app (`www/`) in a Capacitor Android wrapper. Backend: Firebase Authentication (email/password + Firebase verification and reset emails; no custom OTP) for login, and a **Cloudflare Worker + D1 database** (`worker/`, free plans, no Blaze needed) as the trusted mining/balance/withdrawal server. The old Cloud Functions code is archived in `legacy/firebase-functions/` (they cannot be deployed on the Spark plan). **No demo mode**: without Firebase the app shows a connection error with Retry.

- **Deploy the server: `docs/CLOUDFLARE_SETUP.md`** (also explains the "server did not answer" cause). Firebase Auth setup: `docs/FIREBASE_SETUP.md` (ignore its Cloud Functions/Blaze parts)
- **Deploying the Admin Panel update to the existing production Worker: `docs/DEPLOY-ADMIN-PANEL.md`** (backup, migration, dashboard paste, rollback, verification)
- **Admin Panel: `https://<your-worker>/admin`** (dashboard, users, balance adjustments, all withdrawal statuses). Guide, security model and token rotation: `docs/ADMIN_PANEL.md`
- Honest status of what works and what is untested: `docs/STATUS.md`
- Server rules: base 0.00016668 RENDER per mining hour, ceiling 0.000947, 1-hour sessions, verified ad boost = 2x for 10 min (max 10/day), minimum withdrawal 0.07 RENDER (fixed, enforced by the Worker; withdrawals stay locked until the server-verified balance reaches it; the live price is only used to record the PKR value), Binance + EasyPaisa, payouts Saturday/Sunday. Daily reward removed.
- Local checks: `npm test` = worker tests (real SQLite) + error-message tests + browser tests (needs Python + Playwright; fake Firebase SDK, local database: NOT live Firebase/Cloudflare). Live check: `node scripts/diagnose-mining.mjs`, `npm run check:config`
- Preview (computer and phone): `npm run preview`, see `docs/PREVIEW.md`. One-file build: `npm run build:single`.
- Android: `npm install && npx cap add android && npx cap sync android`, then build in Android Studio or `./gradlew assembleDebug` in `android/`.
- `legacy/supabase/` is archived reference only; nothing there was deleted.

## Build, test, deploy (exact commands)
```
npm run build:worker        # regenerates worker/dist/worker-single.js AND DEPLOY-FILES/ from worker/src (never edit those by hand)
npm run check:syntax        # node --check on the Worker sources and the generated bundle (the project has no linter or type checker)
npm run test:worker         # 77 Worker tests (incl. migration/config safety checks) (real SQL on node:sqlite standing in for D1); also rebuilds and checks the bundle
npm run test:errors         # app error-message tests
npm run test:ui             # browser tests (Python 3 + Playwright + Chromium)
python3 test-ui/admin-panel.test.py   # Admin Panel in a real browser, phone-size viewport
npm run test:legacy-functions         # archived Cloud Functions tests (not part of the live system)
# Existing production Worker: do NOT run `wrangler deploy`; paste DEPLOY-FILES/1-worker-code.js in the dashboard (docs/DEPLOY-ADMIN-PANEL.md)
# NOT TO BE RUN until the backup is verified (docs/DEPLOY-ADMIN-PANEL.md):
cd worker && npx wrangler d1 execute rnd-miner-db --remote --file=./migrations/0001_admin_panel.sql   # one-time, non-destructive, indexes only
cd worker && npx wrangler secret put ADMIN_TOKEN     # 32+ random characters; never put it in a file
```
Without a command line: paste `DEPLOY-FILES/1-worker-code.js` into the Worker's code editor (Deploy) and (first install only) run `DEPLOY-FILES/2-database-tables.sql` in the D1 console, as in START-HERE.md. For the existing production database use only `DEPLOY-FILES/3-migration-0001-admin-panel.sql`, after the backup.
Secrets live only in Cloudflare (`ADMIN_TOKEN`). `worker/.dev.vars.example` is a placeholder template for local `wrangler dev`.
**The Android app does not need rebuilding for the Admin Panel**: nothing under `www/` changed; the panel is part of the Worker.
