# RND Miner

Static web app (`www/`) in a Capacitor Android wrapper. Backend: Firebase Authentication + Cloud Functions + Firestore (`functions/`, `firestore.rules`). **No demo mode**: without Firebase the app shows a connection error with Retry.

- Setup, costs and tests: `docs/FIREBASE_SETUP.md`
- Honest status of what works and what is untested: `docs/STATUS.md`
- Server rules: base 0.00016668 RENDER per mining hour, ceiling 0.000947, 1-hour sessions, verified ad boost = 2x for 10 min (max 10/day), minimum withdrawal PKR 40 from a live server-side price, Binance + EasyPaisa, payouts Saturday/Sunday. Daily reward removed.
- Local checks: `npm run test:functions`, `npm run check:config`
- Preview (computer and phone): `npm run preview`, see `docs/PREVIEW.md`. One-file build: `npm run build:single`.
- Android: `npm install && npx cap add android && npx cap sync android`, then build in Android Studio or `./gradlew assembleDebug` in `android/`.
- `legacy/supabase/` is archived reference only; nothing there was deleted.
