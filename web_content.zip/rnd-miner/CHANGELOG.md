# Changelog

## 3.1.3 - Withdrawals no longer depend on RENDER->PKR conversion

### Changed
- `requestWithdrawal` (worker/src/index.js) no longer calls `fetchPrice`/CoinGecko. It validates in RENDER only: fixed 0.07 minimum, server-side available balance, destination, idempotent requestId, one open request, rate limit, auth - all unchanged.
- New withdrawal rows store `amount_pkr = 0`, `render_pkr_at_request = 0`, `price_source_updated_at = 0` (= "no PKR recorded"; the legacy columns are NOT NULL, so no DB migration is needed). Existing rows are untouched.
- User history and admin API report `amountPkr` / `renderPkrAtRequest` as `null` for such rows; legacy rows still show their original PKR snapshot. Response of `requestWithdrawal` no longer contains `amountPkr`.
- `price_unavailable` message in the app now refers only to the optional estimate.
- Kept separately and optional: the informational CONVERSION screen / `getPrice` endpoint. It cannot affect withdrawals.
- Tests: price-down tests now assert success; added unreachable-price, duplicate/open/balance/auth-with-price-down, and legacy-history tests (84 worker tests).

## 3.1.2 - Minimum withdrawal is 0.07 RENDER

### Changed
- **Minimum withdrawal = 0.07 RENDER** (7,000,000 units, fixed). It replaces the old "PKR 40 at the live price" rule. The minimum no longer moves with the exchange rate.
- **Worker (`requestWithdrawal`)**: refuses any amount below 0.07 (`below_minimum:0.07`) *before* the price lookup, so it also works when the price service is down. Inside the same atomic database step, after mining is settled, it refuses with `withdrawal_locked:0.07` unless the server-verified balance is at least 0.07 RENDER. 0.07 exactly is allowed (`>=`). The request id / duplicate protection, one-open-request rule, rate limit, ledger hold and audit entries are unchanged.
- **Worker (`getState`)**: now also returns `minWithdrawUnits` and `withdrawUnlocked` (informational only; the Worker re-checks on every request). `getPrice` returns `minRender: 0.07` and no longer returns `minPkr`.
- **App (`www/index.html`)**: both withdraw buttons (Binance, EasyPaisa) stay disabled and the screen says "locked" until the *server-confirmed* balance (not the animated mining counter) is at least 0.07 RENDER. All "PKR 40" texts replaced by "0.07 RENDER". New messages for `below_minimum` / `withdrawal_locked`.
- Tests: updated `withdraw.test.js`, `admin.test.js`, `srverror.test.mjs`; added 4 Worker tests and `test-ui/withdraw-lock.test.mjs`. `npm run test:errors` now runs both UI-logic tests.
- Rebuilt `worker/dist/worker-single.js`, `DEPLOY-FILES/1-worker-code.js`, `dist/RND-Miner-single.html`. Version 3.1.2-cloudflare.

### Not changed
Firebase authentication, balances, ledger, withdrawal history, Binance and EasyPaisa destinations and validation, admin panel, mining rates, ad rules, payout days (Sat/Sun), D1 schema.

### Database
**No migration is needed.** `schema.sql` and `migrations/0001_admin_panel.sql` are unchanged. Nothing touches existing rows.

### Withdrawal error: NOT fixed, cause NOT verified
The exact error text you see was not given and could not be reproduced here (no access to your live Worker, D1 or CoinGecko). Nothing was changed on a guess. What is known from the code:
- A request is still refused with `price_unavailable` if CoinGecko cannot be reached or its price is older than 10 minutes. The price is still needed to store the PKR value of the request. This is the most likely live cause, but it is **unverified**.
- Other possible causes the app already reports separately: `backend_schema_outdated`, `backend_database_missing`, `auth_keys_unreachable`, `email_not_verified`, `withdrawal_already_open`.
- To find the real cause: open `https://<your-worker>/api/health`, then try a withdrawal and send me the exact message including the `[ ... ]` code, or run `wrangler tail` while trying.

### Known side effect
`amountPkr` shown for a 0.07 RENDER request is simply 0.07 x the live price. The old PKR floor no longer applies.
