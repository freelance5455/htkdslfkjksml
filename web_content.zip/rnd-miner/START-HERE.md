# START HERE: connect the mining server (free, no coding, no command line)

**Status:** the app says "mining server address is not set" because the server has not been put online yet. I could not put it online for you: it must be created inside YOUR free Cloudflare account, which I cannot log in to. The files are ready. This takes about 15 minutes. Nothing here costs money and no card is needed.

Your login system is not touched. Everything below is only the server.

You need two files from the folder **DEPLOY-FILES**:
- `1-worker-code.js` (the server program)
- `2-database-tables.sql` (the list of tables for the database)

Open them with Notepad (Windows) or any text editor. To "copy all": click inside, press Ctrl+A, then Ctrl+C.

## Step 1. Make a free Cloudflare account
1. Go to https://dash.cloudflare.com/sign-up
2. Sign up with your email and a password. Confirm the email. No card, no payment.

## Step 2. Make the database
1. In the left menu click **Storage & databases**, then **D1 SQL database** (older name: "D1").
2. Click **Create database**. Name: `rnd-miner-db` (this is the name your live database already has: do NOT create another one; skip this step if you already deployed). Click **Create**.
3. Open the new database, click the **Console** tab.
4. Open `2-database-tables.sql`, copy all, paste it into the console box, click **Execute**.
5. You should see a success message. If it complains about several statements at once, paste the file in smaller pieces (each block that starts with CREATE) one at a time. It is safe to run twice.

## Step 3. Make the server
1. Left menu: **Compute** (or **Workers & Pages**), then **Create** > **Workers** > **Create Worker** (start from "Hello World").
2. Name it `rnd-miner-api`. Click **Deploy**.
3. Click **Edit code**. Click in the code box, press Ctrl+A, press Delete (the box must be empty).
4. Open `1-worker-code.js`, copy all, paste into the box. Click **Deploy** (top right).

## Step 4. Connect the server to the database
1. Open the worker, click **Settings**, then **Bindings** > **Add** > **D1 database**.
2. Variable name: type exactly `DB` (capital letters). Database: choose `rnd-miner-db`. Save / Deploy.

## Step 5. Tell the server which Firebase project to trust
1. Worker > **Settings** > **Variables and secrets** > **Add**.
2. Type: **Text**. Name `FIREBASE_PROJECT_ID`, value `render-minning-88b6c`. Save.
3. Add another: Type **Text**, name `ALLOWED_ORIGINS`, value `*`. Save and **Deploy**.

## Step 6. Check that it is alive
1. On the worker page copy its address. It looks like `https://rnd-miner-api.YOURNAME.workers.dev`.
2. In your phone or computer browser open that address followed by `/api/health`, for example
   `https://rnd-miner-api.YOURNAME.workers.dev/api/health`
3. You must see text containing **"ok":true** and **"database":"ok"**.
   - `"database":"missing_binding"` = repeat Step 4 (the name must be exactly `DB`).
   - `"database":"schema_not_applied"` = repeat Step 2.
   - Page not found / error = the code was not pasted completely: repeat Step 3.

## Step 7. Put the address into the app
**(Already done for https://rnd-miner-api.afridiallahdad3.workers.dev in this ZIP.)** Original instruction: send me the address from Step 6 (only after you see "database":"ok"). I will put it in the app, test it, and give you a new ZIP.

Or yourself: open `www/firebase-config.js`, find the line `API_BASE: "",` and put the address between the quotes, with no slash at the end:
`API_BASE: "https://rnd-miner-api.YOURNAME.workers.dev",`
Then build the app again as before.

## Step 8. Real test in the app
Log in, press START MINING. It must say mining started and show a countdown. Close the app, open it again, log in: the balance and countdown must still be there. If you see an error, send me the text in square brackets at the end of the message, for example `[backend_database_missing]`.

## Admin Panel (new)
After you set `ADMIN_TOKEN` (below), open `https://rnd-miner-api.YOURNAME.workers.dev/admin` on your phone and type the token. See `docs/ADMIN_PANEL.md`. **Updating the existing live Worker to v3.1: follow `docs/DEPLOY-ADMIN-PANEL.md` (backup first, then migration, then paste the code).**

## Later (not needed now)
- **Withdrawals:** requests are saved. Nothing is paid automatically; you pay by hand. To approve or mark paid you need an admin password: Worker > Settings > Variables and secrets > Add > Type **Secret**, name `ADMIN_TOKEN`, value = a long random text (32+ characters). Keep a copy somewhere private. See `docs/CLOUDFLARE_SETUP.md` section 5.
- **Rewarded ads:** not live yet (the app has no ad SDK). Watch Ad stays disabled.
- Cloudflare menu names change from time to time. If a name differs, look for the closest one.
