// Builds dist/RND-Miner-single.html: index.html with its two script files inlined, so it is ONE file you can open or share.
// Run: npm run build:single
import fs from "node:fs";
let html = fs.readFileSync("www/index.html", "utf8");
let n = 0;
html = html.replace(/<script src="(firebase-config\.js|js\/rnd-backend\.js)"[^>]*><\/script>/g, (_, f) => { n++; return "<script>\n" + fs.readFileSync("www/" + f, "utf8") + "\n</script>"; });
if (n !== 2) { console.error("Expected to inline 2 scripts, found " + n); process.exit(1); }
fs.mkdirSync("dist", { recursive: true });
fs.writeFileSync("dist/RND-Miner-single.html", html);
console.log("Wrote dist/RND-Miner-single.html (" + Math.round(html.length / 1024) + " KB)");
