// Diagnoses the REAL mining server (your Cloudflare Worker) step by step and says which step fails. Run on your own computer:
//   node scripts/diagnose-mining.mjs                                  (no login needed: checks address, HTTPS, CORS, database, settings, token check)
//   RND_EMAIL=you@gmail.com RND_PASSWORD='...' node scripts/diagnose-mining.mjs          (also signs in to Firebase and calls getState)
//   ... --start                                                       (also calls startMining: REALLY starts a 1-hour session, same as the button)
// Needs Node 18+. The password is used only to sign in to Firebase Auth from your computer; the ID token is never printed or saved.
import fs from "node:fs";
const cfg = fs.readFileSync(new URL("../www/firebase-config.js", import.meta.url), "utf8");
const val = (k) => (cfg.match(new RegExp(k + '\\s*:\\s*"([^"]*)"')) || [])[1] || "";
const API = (process.env.RND_API_BASE || val("API_BASE")).replace(/\/+$/, ""), KEY = val("apiKey");
const IDENTITY = process.env.RND_IDENTITY_URL || "https://identitytoolkit.googleapis.com";
let bad = 0;
const say = (ok, step, detail = "") => { console.log((ok ? "PASS  " : "FAIL  ") + step + (detail ? "\n        " + detail : "")); if (!ok) bad++; return ok; };
async function req(path, { method = "GET", token, body, origin } = {}) {
  try {
    const r = await fetch(API + path, { method, headers: { ...(token ? { authorization: "Bearer " + token } : {}), ...(body ? { "content-type": "application/json" } : {}), ...(origin ? { origin } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch {}
    return { status: r.status, headers: r.headers, text, json };
  } catch (e) { return { networkError: String(e && (e.cause && e.cause.code || e.message)) }; }
}
export function explain(r) {   // pure: what an answer means
  if (r.networkError) return `NO HTTP ANSWER (${r.networkError}). This computer cannot reach ${API}: wrong address, Worker not deployed to that name, or DNS/TLS blocked.`;
  if (!r.json || typeof r.json.ok !== "boolean") return `HTTP ${r.status} but the body is not an RND Miner API answer. The address is wrong or points at another site. First 120 chars: ${r.text.slice(0, 120).replace(/\s+/g, " ")}`;
  if (r.json.ok) return "OK";
  const m = r.json.error.message;
  if (/backend_not_configured/.test(m)) return `WORKER SETTINGS MISSING (${m}): the D1 binding "DB" or FIREBASE_PROJECT_ID is not set in wrangler.toml. Redeploy after fixing it.`;
  if (/backend_database_missing|schema_not_applied/.test(m)) return "DATABASE TABLES MISSING: run  npm run db:schema  in worker/ (it never deletes data).";
  if (/backend_schema_outdated/.test(m)) return "DATABASE SCHEMA OUTDATED: run  npm run db:schema  again.";
  if (/auth_keys_unreachable/.test(m)) return "The Worker could not download Google's public keys to check the login token (temporary Google outage?). Retry.";
  if (/sign_in_required/.test(m)) return "TOKEN REJECTED by the Worker (missing, expired, wrong project, or bad signature). Check FIREBASE_PROJECT_ID equals your Firebase project id.";
  if (/email_not_verified/.test(m)) return "EMAIL NOT VERIFIED: the token is genuine but email_verified is false.";
  if (/session_already_active/.test(m)) return "OK (expected): a session is already running; the server refused a second one.";
  if (/backend_quota/.test(m)) return "CLOUDFLARE FREE LIMIT reached for today (D1 or Workers). Resets daily.";
  if (/backend_unavailable/.test(m)) return "DATABASE UNAVAILABLE (D1 error). Retry; check the Cloudflare dashboard status.";
  return `SERVER ANSWER: ${r.json.error.code} / ${m}`;
}
async function main() {
  console.log("API_BASE = " + (API || "(empty)"));
  if (!say(!!API, "1. API_BASE is set in www/firebase-config.js", API ? "" : "Empty: the app cannot reach any server. Deploy the Worker (docs/CLOUDFLARE_SETUP.md) and paste its address.")) return;
  let r = await req("/api/health");
  if (!say(!r.networkError, "2. Server address answers over HTTPS", explain(r))) return;
  say(r.json && r.json.service === "rnd-miner-api", "3. It is the RND Miner API (not another site)", r.json && r.json.service === "rnd-miner-api" ? "" : explain(r));
  if (r.json && r.json.service === "rnd-miner-api") {
    say(r.json.database === "ok", "4. Database (D1) connected and tables present", r.json.database === "ok" ? "" : "database = " + r.json.database + (r.json.database === "schema_not_applied" ? "  -> run: npm run db:schema" : r.json.database === "missing_binding" ? "  -> D1 binding missing in wrangler.toml" : ""));
    say(r.json.firebaseProjectId, "5. FIREBASE_PROJECT_ID is configured");
    console.log("INFO  admin token configured: " + r.json.adminConfigured + " | AdMob ad unit configured: " + r.json.adUnitConfigured + " (only needed for withdrawals admin / ad boosts)");
  }
  r = await req("/api/startMining", { method: "OPTIONS", origin: "https://localhost" });
  say(r.status === 204 && !!r.headers.get("access-control-allow-origin"), "6. CORS preflight from the app origin (https://localhost) is allowed", `status ${r.status}`);
  r = await req("/api/getState", { method: "POST", body: {} });
  say(r.status === 401 && r.json && r.json.error && r.json.error.message === "sign_in_required", "7. A request WITHOUT a login token is refused (proves requests are authenticated)", `status ${r.status}`);
  const email = process.env.RND_EMAIL, pw = process.env.RND_PASSWORD;
  if (!email || !pw) { console.log("\nSkipping the login steps: set RND_EMAIL and RND_PASSWORD to test with a real account."); return; }
  let s; try { const x = await fetch(`${IDENTITY}/v1/accounts:signInWithPassword?key=${KEY}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email, password: pw, returnSecureToken: true }) }); s = await x.json(); } catch (e) { s = { error: { message: String(e.message) } }; }
  if (!say(!!s.idToken, "8. Firebase sign-in with email/password", s.idToken ? "" : "Firebase said: " + (s.error && s.error.message))) return;
  r = await req("/api/getState", { method: "POST", token: s.idToken, body: {} });
  say(explain(r) === "OK" || r.json && r.json.ok, "9. getState with your real token", explain(r));
  if (process.argv.includes("--start")) { r = await req("/api/startMining", { method: "POST", token: s.idToken, body: {} }); say(explain(r) === "OK" || /^OK/.test(explain(r)), "10. startMining (REAL)", explain(r)); }
  else console.log("INFO  add --start to also run startMining for real.");
}
if (import.meta.url === new URL(process.argv[1], "file:").href) main().then(() => { console.log(bad ? `\n${bad} step(s) failed. Fix the first FAIL, then run again.` : "\nAll steps passed."); process.exit(bad ? 1 : 0); });
