// Run: npm run check:config   Confirms www/firebase-config.js is filled in for project render-minning-88b6c.
import fs from "node:fs";
const t = fs.readFileSync("www/firebase-config.js", "utf8");
const val = (k) => (t.match(new RegExp(k + '\\s*:\\s*"([^"]*)"')) || [])[1] || "";
let bad = 0;
const check = (ok, m) => { console.log((ok ? "PASS  " : "FAIL  ") + m); if (!ok) bad++; };
check(val("projectId") === "render-minning-88b6c", "projectId is render-minning-88b6c");
check(/^AIza[0-9A-Za-z_-]{30,}$/.test(val("apiKey")), "apiKey is filled in (starts with AIza)");
check(/^1:\d+:web:[0-9a-f]+$/.test(val("appId")), "appId is a WEB app id (1:<number>:web:<id>), not the Android one");
check(/^\d+$/.test(val("messagingSenderId")), "messagingSenderId is filled in");
console.log(bad ? `\n${bad} check(s) failed: the app will show "Firebase is not configured".` : "\nConfig looks complete. This does not prove login works: test with a real account.");
process.exit(bad ? 1 : 0);
