// Local preview server for www/. No packages needed (Node 18+).   Run: npm run preview
// Then open the printed address on this computer, or on a phone on the SAME Wi-Fi.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
const root = path.resolve("www"), port = Number(process.env.PORT) || 8080;
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon" };
http.createServer((req, res) => {
  let p = decodeURIComponent((req.url || "/").split("?")[0]); if (p.endsWith("/")) p += "index.html";
  const f = path.resolve(path.join(root, p));
  if (!f.startsWith(root + path.sep) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end("Not found"); }
  res.writeHead(200, { "content-type": types[path.extname(f)] || "application/octet-stream", "cache-control": "no-store" });
  fs.createReadStream(f).pipe(res);
}).listen(port, "0.0.0.0", () => {
  console.log("RND Miner preview is running. Press Ctrl+C to stop.\n  On this computer:  http://localhost:" + port);
  for (const list of Object.values(os.networkInterfaces())) for (const i of list || []) if (i.family === "IPv4" && !i.internal) console.log("  On your phone (same Wi-Fi):  http://" + i.address + ":" + port);
});
