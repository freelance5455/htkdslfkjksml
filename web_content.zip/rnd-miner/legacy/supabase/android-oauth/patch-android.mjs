// Adds the Google sign-in return link (com.rndminer.app://auth-callback) to the generated Android manifest.
// Safe to run repeatedly. Run after `npx cap add android`.
import fs from "node:fs";
const f = process.argv[2] || "android/app/src/main/AndroidManifest.xml";
if (!fs.existsSync(f)) { console.error("Not found: " + f + " (run `npx cap add android` first)"); process.exit(1); }
let x = fs.readFileSync(f, "utf8");
if (x.includes('android:scheme="com.rndminer.app"')) { console.log("Manifest already has the auth-callback link; nothing to do."); process.exit(0); }
const filter = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="com.rndminer.app" android:host="auth-callback" />
            </intent-filter>
        `;
const re = /(<activity\b[^>]*MainActivity[\s\S]*?)(<\/activity>)/;
if (!re.test(x)) { console.error("Could not find MainActivity in the manifest; add the intent-filter by hand (see README)."); process.exit(1); }
x = x.replace(re, (_, a, b) => a + filter + b);
if (!/android\.permission\.INTERNET/.test(x)) x = x.replace("</manifest>", '    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>');
fs.writeFileSync(f, x);
console.log("Patched " + f);
