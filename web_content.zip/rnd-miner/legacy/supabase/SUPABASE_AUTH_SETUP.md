# RND Miner: Supabase email-code (OTP) setup, test steps, Google and Android

The app verifies email with a **6-digit code**, never with a link. The app side is already built for that:
signup sends no redirect address, the code is checked with `verifyOtp({type:"signup"})`, "Resend code" uses `resend({type:"signup"})`.
If your signup email shows a "Confirm email address" link, the **Supabase email template** still has the default link text. Fix it in the Dashboard (A below).

## A. Supabase Dashboard (project taygbniewqgmsatuebrf). Menu names can differ slightly between versions.

1. **Authentication > Sign In / Providers > Email**: Enabled. **Confirm email: ON**. **Email OTP length: 6** (the app only accepts 6 digits). **Email OTP expiration: 600** seconds. **Minimum password length: 8**.
   If Confirm email is OFF, accounts are confirmed without a code. The app refuses such a signup, but the account already exists, so check this first.
2. **Authentication > Emails > Templates > "Confirm signup"** (not "Magic link", not "Invite"). Replace the WHOLE body and the subject, then press Save.
   Subject: `Your RND Miner verification code`
   The body must contain `{{ .Token }}` and must NOT contain `{{ .ConfirmationURL }}` or any link or button:
```html
<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;background:#0b0b10;color:#fff;padding:28px;border-radius:16px">
  <h2 style="margin:0 0 4px;color:#ff4b4f">RND Miner</h2>
  <p style="color:#9aa3b8;margin:0 0 20px">Render Mining</p>
  <h3 style="margin:0 0 8px">Verify your email</h3>
  <p style="margin:0 0 12px">Enter this 6-digit code in the app:</p>
  <p style="font-size:36px;letter-spacing:10px;font-weight:bold;margin:12px 0;text-align:center">{{ .Token }}</p>
  <p style="margin:12px 0 0">The code expires in 10 minutes.</p>
  <p style="color:#ff9a9c;margin:12px 0 0">Never share this code with anyone. If you did not create an account, ignore this email.</p>
</div>
```
3. **Same page > "Reset Password"** template (the app resets passwords with a code too, type `recovery`). Subject `Your RND Miner password reset code`; same body, but change the heading to "Reset your password" and the first line to "Enter this 6-digit code in the app to choose a new password:". Keep `{{ .Token }}`, no link.
4. **Authentication > URL Configuration**: set **Site URL** to the real address where the app is hosted (`https://...`, no typo, no trailing path). Old email links that ended in a "303" error were being redirected to a wrong or unreachable Site URL. Once the email contains a code, the link is not used at all, but Google login and the Android build still need these addresses (see D and E). Add every address you test from under **Redirect URLs**.
5. **Authentication > Emails > SMTP Settings > custom SMTP** is required for real users. Supabase's built-in sender only delivers to your own team members and is heavily limited. Use Resend / SendGrid / Amazon SES / Postmark and add the SPF, DKIM and DMARC records they give you.
6. **Authentication > Rate Limits**: Supabase refuses a second email to the same user within about 60 seconds, matching the app's 60-second Resend cooldown.
7. Recommended: CAPTCHA under Attack Protection (not wired into the app yet).

## B. Why the Claude preview cannot test this
The preview sandbox blocks requests to other sites, so it can never reach Supabase or receive your email. Test on a real HTTPS address (Netlify Drop, your own host) or in the Android build.

## C. Real test (needs a real inbox you control)
Use a NEW email address, or first delete the earlier test user in **Authentication > Users** (a link-click may already have confirmed it). An already-confirmed account will not receive a new signup email.
1. Open the app > Create Account > enter email + password (8+ characters) > **CREATE ACCOUNT**. The "Verify your email" screen appears.
2. The email arrives with a large 6-digit number and no link. If it still shows a link, the template in A2 was not saved or was edited in the wrong template.
3. Type the code > **VERIFY**. The app opens. In **Authentication > Users** the user shows a confirmed time.
4. Log out, log in again with the same email + password.
5. Resend Code: tap it on the verify screen; it shows "Resend code in 60s" and a new email arrives; only the newest code works.
6. Forgot password: enter the email > SEND CODE > code arrives (no link) > enter code + new password > log in with the new password.
Optional automated check with two real inboxes: `node tools/auth-e2e.mjs --email you+a@gmail.com --email2 you+b@gmail.com --password 'Abcdef123!'` (writes `auth-test-report.json`). `node tools/auth-preflight.mjs` is a read-only check of the URL, key and Confirm email setting.

## D. Google login (separate test)
1. Supabase > Authentication > Sign In / Providers > Google: enable, paste Client ID + Secret from Google Cloud.
2. Google Cloud Console > APIs & Services > Credentials > OAuth client, type **Web application**. Authorized redirect URI: `https://taygbniewqgmsatuebrf.supabase.co/auth/v1/callback` (only this). Configure the consent screen; add yourself as a test user while in Testing mode.
3. Supabase > URL Configuration > Redirect URLs: add the exact address you open the web app from.
4. Test in Chrome or Safari on a real HTTPS address. Google refuses to run inside the Claude preview and inside in-app/embedded browsers; the app says so instead of failing silently.

## E. Android app (Capacitor)
Google login in the app uses the phone's system browser and returns through the link `com.rndminer.app://auth-callback`.
1. Supabase > URL Configuration > Redirect URLs: add exactly `com.rndminer.app://auth-callback`.
2. No Android SHA-1 is needed for this flow (Google talks to Supabase's web callback).
3. See README.md for building the APK.

## F. Create ONE real test account without sending any email (fastest way to test the app)
This is done by you, in your own Supabase Dashboard. No service-role key is ever typed into the app or sent to anyone. Do not share the password.
1. On the phone, open supabase.com/dashboard and sign in. If the page looks cramped, switch the browser to "Desktop site". Open project `taygbniewqgmsatuebrf`.
2. **Authentication > Users > Add user > Create new user**.
3. Email: an address you control. Password: a strong password only you know (12+ characters, not used anywhere else; keep it in a password manager). Tick **Auto Confirm User**. Press Create.
4. The new row should show as confirmed. If it does not, delete that user and create it again with Auto Confirm ticked.
5. Open the app on its real HTTPS address (or the Android build), tap LOGIN with that email + password. No email is involved, so the email limits below do not apply.
6. To change the password later without email: Users > the row > Update password. ("Send password reset" sends an email, which counts toward the limit.)
After login, mining/wallet features also need `supabase/001_schema.sql` applied and the Edge Functions `activity`, `wallet`, `withdraw`, `prices` deployed. Neither is part of this package, and applying them changes your production database, so that is your decision.

## G. Why you saw "try again after one minute"
Supabase has two separate limits on auth emails (signup, resend, password reset all count):
- **Per user:** about one email per 60 seconds. Supabase answers with a message like "you can only request this after N seconds". The app now shows that exact text and counts down the same number of seconds.
- **Per project, per hour:** the built-in email sender allows only a few emails per hour for the whole project (public documentation says about 2). Supabase answers "email rate limit exceeded". Waiting a minute does not clear this; it can take up to an hour. Check the real number under **Authentication > Rate Limits**. The lasting fix is custom SMTP (A5).
The app used to make this worse: logging in with an unverified account silently sent a new email every time. That is fixed: login never sends email now. Only Create Account, Resend code and Forgot password do, and the 60-second cooldown now survives a page reload.
The app shows Supabase's own message and status after every auth error while `SHOW_ERROR_DETAILS` is `true` near the top of the auth code in `www/index.html`; set it to `false` before a public release.
