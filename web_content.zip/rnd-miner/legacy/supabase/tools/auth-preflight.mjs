// RND Miner — Supabase auth preflight (READ-ONLY: it changes nothing and creates no accounts).
//   node tools/auth-preflight.mjs
// Uses only the public URL + publishable key. Run it on your own computer (it needs internet).
const URL_ = (process.env.SUPABASE_URL || "https://taygbniewqgmsatuebrf.supabase.co").replace(/\/$/, "");
const KEY = process.env.SUPABASE_KEY || "sb_publishable_WkkAG3iv2QvpZtdx8I-JWA_RXjE1eQw";
const out = [];
const add = (status, name, detail = "") => { out.push({ status, name, detail }); console.log(`${status.padEnd(6)} ${name}${detail ? " — " + detail : ""}`); };

async function get(path, headers) {
  try { const r = await fetch(URL_ + path, { headers }); let j = null; try { j = await r.json(); } catch {} return { status: r.status, json: j }; }
  catch (e) { return { status: 0, error: String(e.message || e) }; }
}

const a = await get("/auth/v1/settings", { apikey: KEY });
if (a.status === 0) { add("FAIL", "Project reachable", a.error); process.exit(1); }
if (a.status !== 200) { add("FAIL", "Settings endpoint", `HTTP ${a.status} ${JSON.stringify(a.json)} (wrong URL/key, or project paused?)`); process.exit(1); }
add("PASS", "Project URL + publishable key accepted by the Auth API");

// supabase-js also sends the key as a Bearer token; make sure the gateway accepts that too.
const b = await get("/auth/v1/settings", { apikey: KEY, Authorization: "Bearer " + KEY });
b.status === 200 ? add("PASS", "Key accepted in the same way supabase-js sends it") : add("FAIL", "supabase-js style request", `HTTP ${b.status} ${JSON.stringify(b.json)} — the browser app would fail; tell Claude`);

const s = a.json || {};
s.external && s.external.email === true ? add("PASS", "Email sign-in provider enabled") : add("FAIL", "Email sign-in provider enabled", "enable it in Authentication > Sign In / Providers");
s.disable_signup === true ? add("FAIL", "New signups allowed", "signups are disabled in the project") : add("PASS", "New signups allowed");
s.mailer_autoconfirm === true
  ? add("FAIL", "Confirm email is ON", "mailer_autoconfirm is TRUE: accounts are confirmed WITHOUT a code. Turn Confirm email ON.")
  : add("PASS", "Confirm email is ON (accounts need a code)");
add(s.external && s.external.google ? "INFO" : "INFO", "Google provider", s.external && s.external.google ? "enabled" : "not enabled (the Google button will fail until you enable it)");
add("MANUAL", "Email OTP length = 6, expiry, templates, SMTP", "not visible through the public API — run tools/auth-e2e.mjs with a real inbox to prove them");
const fails = out.filter(o => o.status === "FAIL").length;
console.log(`\n${fails ? fails + " problem(s) found" : "No blocking problems found by this check"} (this does NOT prove email delivery works).`);
process.exit(fails ? 2 : 0);
