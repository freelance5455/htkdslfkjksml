// RND Miner — REAL end-to-end auth test against YOUR Supabase project, using real inboxes.
//   node tools/auth-e2e.mjs --email you+a@gmail.com --email2 you+b@gmail.com --password 'Abcdef123!'
// You need two inboxes you control (plus-addresses such as you+a@gmail.com work). It creates two TEST accounts;
// delete them afterwards in Authentication > Users (this script cannot delete users — it has no secret key, on purpose).
// Test-only option: --codes-file codes.json  (reads codes from a file instead of asking you; used only for the self-test with a stand-in server).
import readline from "node:readline/promises";
import fs from "node:fs";

const arg = (k, d) => { const i = process.argv.indexOf("--" + k); return i > 0 ? process.argv[i + 1] : d; };
const URL_ = (process.env.SUPABASE_URL || arg("url", "https://taygbniewqgmsatuebrf.supabase.co")).replace(/\/$/, "");
const KEY = process.env.SUPABASE_KEY || "sb_publishable_WkkAG3iv2QvpZtdx8I-JWA_RXjE1eQw";
const email1 = arg("email"), email2 = arg("email2"), pw = arg("password"), codesFile = arg("codes-file");
if (!email1 || !email2 || !pw) { console.log("usage: node auth-e2e.mjs --email a@x.com --email2 b@x.com --password 'Abcdef123!'"); process.exit(1); }
const newPw = pw + "-new";
const results = [];
const rec = (status, name, detail = "") => { results.push({ status, name, detail }); console.log(`${status.padEnd(6)} ${name}${detail ? " — " + detail : ""}`); };
const rl = codesFile ? null : readline.createInterface({ input: process.stdin, output: process.stdout });

async function api(method, path, body, token) {
  try {
    const r = await fetch(URL_ + path, { method, headers: { apikey: KEY, "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    let j = null; try { j = await r.json(); } catch {}
    return { status: r.status, json: j || {} };
  } catch (e) { return { status: 0, json: { msg: String(e.message || e) } }; }
}
const code = (j) => (j && (j.error_code || j.code)) || "";
async function askCode(email, type) {
  if (codesFile) { await new Promise(r => setTimeout(r, 300)); const m = JSON.parse(fs.readFileSync(codesFile, "utf8")); return m[type + ":" + email.toLowerCase()]; }
  return (await rl.question(`\nOpen the inbox of ${email}. Type the 6-digit ${type} code (or press Enter if no email arrived): `)).trim();
}
async function yn(q) { if (codesFile) return null; return /^y/i.test((await rl.question(q + " (y/n): ")).trim()); }

// 0. settings
const st = await api("GET", "/auth/v1/settings");
if (st.status !== 200) { rec("FAIL", "Reach Supabase Auth", `HTTP ${st.status} ${JSON.stringify(st.json)}`); process.exit(1); }
st.json.mailer_autoconfirm === true ? rec("FAIL", "Confirm email is ON", "autoconfirm is on: accounts skip verification") : rec("PASS", "Confirm email is ON");

// 1. signup must NOT return a session
const su = await api("POST", "/auth/v1/signup", { email: email1, password: pw });
if (su.status === 200 && !su.json.access_token) rec("PASS", "Signup creates an unverified account with no session");
else rec("FAIL", "Signup creates an unverified account with no session", `HTTP ${su.status} ${JSON.stringify(su.json).slice(0, 200)}`);

// 2. unverified login is blocked
const ul = await api("POST", "/auth/v1/token?grant_type=password", { email: email1, password: pw });
ul.status === 400 && code(ul.json) === "email_not_confirmed" ? rec("PASS", "Login before verification is refused (email_not_confirmed)") : rec("FAIL", "Login before verification is refused", `HTTP ${ul.status} ${code(ul.json)}`);

// 3. resend cooldown
const rs = await api("POST", "/auth/v1/resend", { type: "signup", email: email1 });
rs.status === 429 ? rec("PASS", "Immediate resend is rate-limited by Supabase", code(rs.json)) : rec("WARN", "Immediate resend was NOT rate-limited", `HTTP ${rs.status}: check Authentication > Rate Limits`);

// 4. real email delivery (needs you)
const arrived = await yn(`Did the verification email for ${email1} arrive within about a minute?`);
if (arrived === true) {
  rec("PASS", "Verification email arrived (reported by you)");
  (await yn("Does it show a 6-digit CODE (not only a link) and your branding?")) ? rec("PASS", "Template contains the 6-digit code (reported by you)") : rec("FAIL", "Template contains {{ .Token }}", "edit the 'Confirm signup' template");
  (await yn("Is the sender your own verified domain (not supabase's default sender)?")) ? rec("PASS", "Sender is your domain (reported by you)") : rec("FAIL", "Custom SMTP / sender domain", "set custom SMTP");
} else if (arrived === false) rec("FAIL", "Verification email arrived", "no email: check SMTP settings, spam folder, and Auth logs");
else rec("MANUAL", "Email delivery questions skipped (--codes-file mode)");

// 5. wrong code, then the real code
const bad = await api("POST", "/auth/v1/verify", { type: "signup", email: email1, token: "000000" });
bad.status >= 400 && bad.status < 500 ? rec("PASS", "Wrong code is rejected", code(bad.json)) : rec("FAIL", "Wrong code is rejected", `HTTP ${bad.status}`);
const c1 = await askCode(email1, "signup");
if (!/^\d{6}$/.test(c1 || "")) rec("FAIL", "Received a 6-digit code", `got '${c1}' — if your code is longer, set Email OTP Length to 6`);
else {
  const ok = await api("POST", "/auth/v1/verify", { type: "signup", email: email1, token: c1 });
  ok.status === 200 && ok.json.access_token && ok.json.user && ok.json.user.email_confirmed_at ? rec("PASS", "Correct code verifies the account and returns a session") : rec("FAIL", "Correct code verifies the account", `HTTP ${ok.status} ${JSON.stringify(ok.json).slice(0, 160)}`);
  const re = await api("POST", "/auth/v1/verify", { type: "signup", email: email1, token: c1 });
  re.status >= 400 ? rec("PASS", "The same code cannot be used twice") : rec("FAIL", "The same code cannot be used twice", `HTTP ${re.status}`);
}

// 6. login
const lg = await api("POST", "/auth/v1/token?grant_type=password", { email: email1, password: pw });
lg.status === 200 && lg.json.access_token ? rec("PASS", "Verified user can log in") : rec("FAIL", "Verified user can log in", `HTTP ${lg.status} ${code(lg.json)}`);
const wp = await api("POST", "/auth/v1/token?grant_type=password", { email: email1, password: pw + "x" });
wp.status === 400 && code(wp.json) === "invalid_credentials" ? rec("PASS", "Wrong password is rejected") : rec("FAIL", "Wrong password is rejected", `HTTP ${wp.status} ${code(wp.json)}`);

// 7. duplicate signup must not leak or create a second account
const dup = await api("POST", "/auth/v1/signup", { email: email1, password: pw });
dup.status === 200 && !dup.json.access_token ? rec("PASS", "Signing up again with a verified email gives no session and no error (no account leak)") : rec("FAIL", "Duplicate signup behaviour", `HTTP ${dup.status} ${JSON.stringify(dup.json).slice(0, 120)}`);

// 8. second account stays unverified
await api("POST", "/auth/v1/signup", { email: email2, password: pw });
const u2 = await api("POST", "/auth/v1/token?grant_type=password", { email: email2, password: pw });
u2.status === 400 && code(u2.json) === "email_not_confirmed" ? rec("PASS", "A second, unverified account cannot log in") : rec("FAIL", "Second unverified account cannot log in", `HTTP ${u2.status} ${code(u2.json)}`);

// 9. password reset
const unk = await api("POST", "/auth/v1/recover", { email: "nobody-" + Date.now() + "@example.com" });
unk.status === 200 ? rec("PASS", "Reset for an unknown email gives the same answer (no account leak)") : rec("WARN", "Reset for unknown email", `HTTP ${unk.status}`);
const rc = await api("POST", "/auth/v1/recover", { email: email1 });
if (rc.status !== 200) rec("FAIL", "Password reset request", `HTTP ${rc.status} ${JSON.stringify(rc.json).slice(0, 160)}`);
else {
  const c2 = await askCode(email1, "recovery");
  if (!/^\d{6}$/.test(c2 || "")) rec("FAIL", "Reset email contains a 6-digit code", "edit the 'Reset password' template to include {{ .Token }}");
  else {
    const v = await api("POST", "/auth/v1/verify", { type: "recovery", email: email1, token: c2 });
    if (!(v.status === 200 && v.json.access_token)) rec("FAIL", "Reset code accepted", `HTTP ${v.status} ${code(v.json)}`);
    else {
      const up = await api("PUT", "/auth/v1/user", { password: newPw }, v.json.access_token);
      up.status === 200 ? rec("PASS", "New password can be set with the reset code") : rec("FAIL", "New password can be set", `HTTP ${up.status} ${code(up.json)}`);
      const o = await api("POST", "/auth/v1/token?grant_type=password", { email: email1, password: pw });
      const n = await api("POST", "/auth/v1/token?grant_type=password", { email: email1, password: newPw });
      o.status === 400 && n.status === 200 ? rec("PASS", "After reset: old password fails, new password works") : rec("FAIL", "After reset: old fails, new works", `old HTTP ${o.status}, new HTTP ${n.status}`);
    }
  }
}
rec("MANUAL", "Cleanup", `delete ${email1} and ${email2} in Authentication > Users`);
const f = results.filter(r => r.status === "FAIL").length, w = results.filter(r => r.status === "WARN").length;
console.log(`\nSUMMARY: ${results.filter(r => r.status === "PASS").length} passed, ${f} failed, ${w} warnings, ${results.filter(r => r.status === "MANUAL").length} manual`);
fs.writeFileSync("auth-test-report.json", JSON.stringify({ at: new Date().toISOString(), url: URL_, results }, null, 2));
console.log("report: auth-test-report.json (send it to Claude)");
if (rl) rl.close();
process.exit(f ? 2 : 0);
