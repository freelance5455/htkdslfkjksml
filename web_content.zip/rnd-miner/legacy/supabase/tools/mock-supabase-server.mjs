// SELF-TEST ONLY. A stand-in HTTP server that imitates the Supabase Auth endpoints, so the e2e script's own logic can be checked offline.
// It proves nothing about your real Supabase project, SMTP or email delivery.
import http from "node:http"; import fs from "node:fs";
const users = {}, codes = {}, last = {}; const port = Number(process.argv[2] || 54321), codesFile = process.argv[3] || "codes.json";
const save = () => fs.writeFileSync(codesFile, JSON.stringify(codes));
const gen = () => String(Math.floor(Math.random() * 1e6)).padStart(6, "0");
http.createServer(async (req, res) => {
  let body = ""; for await (const c of req) body += c; const j = body ? JSON.parse(body) : {};
  const send = (s, o) => { res.writeHead(s, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
  if (!req.headers.apikey) return send(401, { message: "No API key found in request" });
  const p = req.url.split("?")[0], em = String(j.email || "").toLowerCase();
  const sendCode = (type) => { const k = type + ":" + em, n = Date.now(); if (last[k] && n - last[k] < 60000) return false; last[k] = n; codes[k] = gen(); save(); return true; };
  const sess = (u) => ({ access_token: "tok_" + u.email, user: { email: u.email, email_confirmed_at: new Date().toISOString() } });
  if (p === "/auth/v1/settings") return send(200, { external: { email: true, google: false }, disable_signup: false, mailer_autoconfirm: false });
  if (p === "/auth/v1/signup") { const u = users[em]; if (u && u.ok) return send(200, { id: "x", email: em, identities: [] }); users[em] = u || { email: em, pw: j.password, ok: false }; sendCode("signup"); return send(200, { id: "id_" + em, email: em }); }
  if (p === "/auth/v1/resend") { return sendCode("signup") ? send(200, {}) : send(429, { error_code: "over_email_send_rate_limit", msg: "slow down" }); }
  if (p === "/auth/v1/verify") { const k = j.type + ":" + em; if (!codes[k] || codes[k] !== j.token) return send(403, { error_code: "otp_expired", msg: "Token has expired or is invalid" }); delete codes[k]; save(); const u = users[em]; u.ok = true; return send(200, sess(u)); }
  if (p === "/auth/v1/token") { const u = users[em]; if (!u || u.pw !== j.password) return send(400, { error_code: "invalid_credentials", msg: "Invalid login credentials" }); if (!u.ok) return send(400, { error_code: "email_not_confirmed", msg: "Email not confirmed" }); return send(200, sess(u)); }
  if (p === "/auth/v1/recover") { if (users[em]) sendCode("recovery"); return send(200, {}); }
  if (p === "/auth/v1/user" && req.method === "PUT") { const t = (req.headers.authorization || "").replace("Bearer tok_", ""); if (!users[t]) return send(401, { msg: "no session" }); users[t].pw = j.password; return send(200, { email: t }); }
  send(404, { msg: "not found" });
}).listen(port, () => console.log("mock listening", port));
