# LEGACY / REFERENCE ONLY: archived Supabase material

Nothing in this folder is used by the app, the Android build, or any script. It is kept only for reference or a future migration.
The app in `../../www/index.html` no longer contains any Supabase code and makes no Supabase requests.

| File | What it is |
|---|---|
| `index.supabase-version.html` | The last app version that used Supabase (login, email-code screens, wallet, Edge Function calls). Kept so the old login/OTP/reset screen designs can be reused later. Do not deploy it. |
| `001_schema.sql` | The old Postgres schema (tables, policies). Reference for how balances, withdrawals and the activity ledger were modelled. Never applied by anything here. |
| `SUPABASE_AUTH_SETUP.md` | Old setup notes for email-code templates and Google login. |
| `tools/` | Old read-only checks and an offline stand-in server for tests. |
| `android-oauth/`, `vendor/` | Old helper scripts for the Google sign-in return link and for bundling the Supabase library. |

These files mention the old Supabase project address and its publishable (public) key. You can delete this whole folder at any time without affecting the app.
