#!/usr/bin/env node
"use strict";
/**
 * Owner-only withdrawal admin, run on YOUR computer with a service-account key (never put that key in the app or repo):
 *   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json   (Firebase Console > Project settings > Service accounts)
 *   cd functions && npm install
 *   node tools/admin.js list
 *   node tools/admin.js approve  <uid> <requestId> [note]
 *   node tools/admin.js reject   <uid> <requestId> [note]        (returns the held RENDER to the user)
 *   node tools/admin.js markpaid <uid> <requestId> <payoutReference>   (only allowed Saturday/Sunday, Pakistan time)
 * Statuses stay distinct: requested -> approved -> paid (paid is ONLY set here, after you really sent the money).
 */
const admin = require("firebase-admin");
const W = require("../lib/withdraw");
const C = require("../lib/constants");
admin.initializeApp({ projectId: "render-minning-88b6c" });
const db = admin.firestore();
const [cmd, uid, requestId, ...rest] = process.argv.slice(2);

async function list() {
  const q = await db.collectionGroup("withdrawals").where("status", "in", ["requested", "approved"]).get();
  if (q.empty) return console.log("No open withdrawals.");
  q.docs.forEach((d) => { const w = d.data(); console.log(`${w.status.padEnd(9)} uid=${w.uid} requestId=${w.requestId} ${w.method} ${(w.amountUnits / C.UNITS_PER_RENDER).toFixed(8)} RENDER (~PKR ${w.amountPkr}) to ${JSON.stringify(w.destination)} requested ${new Date(w.requestedAt).toISOString()}`); });
}
async function act(to) {
  const now = Date.now();
  if (to === "paid") {
    if (!W.isPayoutDay(now)) throw new Error("Payouts are only marked on Saturday/Sunday (Pakistan time).");
    if (!rest[0] || rest[0].length < 3) throw new Error("A payout reference is required.");
  }
  const ref = db.doc(`users/${uid}/withdrawals/${requestId}`), uref = db.doc(`users/${uid}`);
  await db.runTransaction(async (tx) => {
    const ws = await tx.get(ref); if (!ws.exists) throw new Error("No such withdrawal.");
    const w = ws.data(); if (!W.canTransition(w.status, to)) throw new Error(`Cannot go from ${w.status} to ${to}.`);
    const us = to === "rejected" ? await tx.get(uref) : null;
    const key = { approved: "approvedAt", rejected: "rejectedAt", paid: "paidAt" }[to];
    const upd = { status: to, [key]: now, lastActionBy: "owner-cli", note: String((to === "paid" ? "" : rest.join(" ")) || "").slice(0, 300) };
    if (to === "paid") upd.payoutRef = rest[0].slice(0, 120);
    tx.update(ref, upd);
    if (to === "rejected") {
      const after = us.data().balanceUnits + w.amountUnits;
      tx.update(uref, { balanceUnits: after });
      tx.set(uref.collection("ledger").doc(), { at: now, type: "withdrawal_refund", requestId, units: w.amountUnits, balanceAfterUnits: after });
    }
    tx.set(db.collection("audit").doc(), { uid, type: `withdrawal_${to}`, at: now, requestId, by: "owner-cli" });
  });
  console.log(`OK: ${requestId} is now ${to}.`);
}
(async () => {
  if (cmd === "list") return list();
  const to = { approve: "approved", reject: "rejected", markpaid: "paid" }[cmd];
  if (!to || !uid || !requestId) { console.log("Usage: see the header of this file."); process.exit(1); }
  return act(to);
})().catch((e) => { console.error("ERROR:", e.message); process.exit(1); });
