#!/usr/bin/env node
"use strict";
/**
 * One-time, OPTIONAL cleanup of leftovers from the removed custom login-code (OTP) system. Run on YOUR computer:
 *   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
 *   cd functions && npm install
 *   node tools/cleanup-otp.js            (DRY RUN: only prints what it would do; changes nothing)
 *   node tools/cleanup-otp.js --apply    (does it)
 * It touches ONLY:
 *   1) the Firestore collection  loginCodes/*   (hashed one-time codes: no balances, no profiles, no money)
 *   2) the custom auth claim     otpFor         (other claims are kept)
 * It NEVER touches users/*, ledger, sessions, withdrawals, rateLimits or audit records, and never deletes an account.
 * Nothing needs this to run: the app and server simply ignore the leftovers.
 */
const admin = require("firebase-admin");
admin.initializeApp({ projectId: "render-minning-88b6c" });
const apply = process.argv.includes("--apply");

async function main() {
  console.log(apply ? "APPLY mode" : "DRY RUN (add --apply to make changes)");
  const db = admin.firestore();
  const codes = await db.collection("loginCodes").get();
  console.log(`loginCodes documents: ${codes.size}`);
  if (apply) { let batch = db.batch(), n = 0; for (const d of codes.docs) { batch.delete(d.ref); if (++n % 400 === 0) { await batch.commit(); batch = db.batch(); } } await batch.commit(); }

  let token, seen = 0, withClaim = 0;
  do {
    const page = await admin.auth().listUsers(1000, token);
    for (const u of page.users) {
      seen++;
      const cc = u.customClaims || {};
      if (!("otpFor" in cc)) continue;
      withClaim++;
      if (apply) { const { otpFor, ...rest } = cc; await admin.auth().setCustomUserClaims(u.uid, Object.keys(rest).length ? rest : null); }
    }
    token = page.pageToken;
  } while (token);
  console.log(`accounts checked: ${seen}; accounts with an old otpFor claim: ${withClaim}${apply ? " (claim removed)" : ""}`);
  console.log(apply ? "Done." : "Nothing was changed.");
}
main().catch((e) => { console.error(e); process.exit(1); });
