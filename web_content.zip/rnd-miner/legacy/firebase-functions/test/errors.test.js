"use strict";
const test = require("node:test");
const assert = require("node:assert");
const { classify, safeCallable } = require("../lib/errors");

class HttpsError extends Error { constructor(code, message) { super(message); this.code = code; } }

test("Firestore gRPC errors map to distinct backend codes (not a generic network error)", () => {
  assert.deepStrictEqual(classify({ code: 5, message: "5 NOT_FOUND: " }), { code: "failed-precondition", message: "backend_database_missing" });
  assert.deepStrictEqual(classify({ code: 7, message: "7 PERMISSION_DENIED" }), { code: "failed-precondition", message: "backend_permission_denied" });
  assert.deepStrictEqual(classify({ code: 14, message: "14 UNAVAILABLE" }), { code: "unavailable", message: "backend_unavailable" });
  assert.deepStrictEqual(classify({ code: 4, message: "4 DEADLINE_EXCEEDED" }), { code: "deadline-exceeded", message: "backend_timeout" });
  assert.deepStrictEqual(classify({ code: 8, message: "8 RESOURCE_EXHAUSTED" }), { code: "resource-exhausted", message: "backend_quota" });
  assert.strictEqual(classify({ code: 9, message: "9 FAILED_PRECONDITION: The query requires an index" }).message, "backend_index_missing");
  assert.strictEqual(classify({ code: 9, message: "9 FAILED_PRECONDITION: other" }).message, "backend_precondition");
  assert.strictEqual(classify({ code: 10, message: "ABORTED" }).message, "backend_busy");
});

test("unknown errors become backend_error and never leak the original message", () => {
  const c = classify(new Error("secret path /srv/x and document data"));
  assert.deepStrictEqual(c, { code: "internal", message: "backend_error" });
  assert.deepStrictEqual(classify(undefined), { code: "internal", message: "backend_error" });
});

test("safeCallable: HttpsError passes through unchanged (our own checks keep their exact codes)", async () => {
  const logs = [];
  const f = safeCallable("startMining", HttpsError, (...a) => logs.push(a), async () => { throw new HttpsError("already-exists", "session_already_active"); });
  await assert.rejects(f({}), (e) => e instanceof HttpsError && e.code === "already-exists" && e.message === "session_already_active");
  assert.strictEqual(logs.length, 0);
});

test("safeCallable: other errors are logged in full on the server and returned as a classified HttpsError", async () => {
  const logs = [];
  const boom = Object.assign(new Error("5 NOT_FOUND: "), { code: 5 });
  const f = safeCallable("startMining", HttpsError, (...a) => logs.push(a), async () => { throw boom; });
  await assert.rejects(f({}), (e) => e instanceof HttpsError && e.code === "failed-precondition" && e.message === "backend_database_missing");
  assert.strictEqual(logs.length, 1);
  assert.match(String(logs[0][0]), /startMining failed/);
});

test("safeCallable: success value is returned untouched (mining logic is not altered)", async () => {
  const f = safeCallable("getState", HttpsError, () => {}, async (r) => ({ ok: r.x }));
  assert.deepStrictEqual(await f({ x: 7 }), { ok: 7 });
});
