"use strict";
// Unit tests for the PURE server logic (no Firebase, no network). These prove the rules and math,
// NOT that Firestore, Cloud Functions or email delivery work: that needs the real project.
const test = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const C = require("../lib/constants");
const M = require("../lib/mining");
const W = require("../lib/withdraw");
const { verifySsv } = require("../lib/ssv");

const T0 = Date.UTC(2026, 9, 12, 10, 0, 0);

test("rates match the owner's rules and respect the ceiling", () => {
  assert.equal(C.BASE_UNITS_PER_HOUR / C.UNITS_PER_RENDER, 0.00016668);
  assert.equal(C.MAX_UNITS_PER_HOUR / C.UNITS_PER_RENDER, 0.000947);
  assert.ok(M.BOOST_UNITS_PER_HOUR <= C.MAX_UNITS_PER_HOUR);
  assert.equal(M.BOOST_UNITS_PER_HOUR, 2 * M.BASE_UNITS_PER_HOUR);
});

test("one full unboosted hour earns exactly the base hourly rate", () => {
  const s = { startedAt: T0, endsAt: T0 + C.SESSION_MS };
  assert.equal(M.entitledUnits(s, T0 + C.SESSION_MS, []), 16668);
});

test("earnings stop at session end (no credit for time after it)", () => {
  const s = { startedAt: T0, endsAt: T0 + C.SESSION_MS };
  assert.equal(M.entitledUnits(s, T0 + 10 * C.SESSION_MS, []), 16668);
  assert.equal(M.entitledUnits(s, T0 - 1000, []), 0);
});

test("a 10-minute boost doubles the rate for those 10 minutes only", () => {
  const s = { startedAt: T0, endsAt: T0 + C.SESSION_MS };
  const seg = [{ from: T0, to: T0 + C.BOOST_MS }];
  // 10 min at 2x + 50 min at 1x = (20+50)/60 of an hour at base
  assert.equal(M.entitledUnits(s, T0 + C.SESSION_MS, seg), Math.floor(16668 * 70 / 60));
});

test("settling twice at the same time never double-credits (replay-safe)", () => {
  const m = { status: "active", startedAt: T0, endsAt: T0 + C.SESSION_MS, creditedUnits: 0 };
  const a = M.settle(m, [], T0 + 30 * 60000);
  const b = M.settle(a.mining, [], T0 + 30 * 60000);
  assert.equal(b.creditUnits, 0);
  assert.equal(a.creditUnits, 8334);
});

test("many partial settlements add up to exactly one full session", () => {
  let m = { status: "active", startedAt: T0, endsAt: T0 + C.SESSION_MS, creditedUnits: 0 }, total = 0;
  for (let t = 1; t <= 120; t++) { const r = M.settle(m, [], T0 + t * 37000); m = r.mining; total += r.creditUnits; }
  const r = M.settle(m, [], T0 + C.SESSION_MS + 5000); total += r.creditUnits;
  assert.equal(total, 16668);
  assert.equal(r.mining.status, "finished");
});

test("idle or finished sessions credit nothing", () => {
  assert.equal(M.settle({ status: "idle" }, [], T0).creditUnits, 0);
  assert.equal(M.settle({ status: "finished", startedAt: T0, endsAt: T0 + 1, creditedUnits: 5 }, [], T0 + 999999).creditUnits, 0);
});

test("max 10 boosts per Karachi day, 11th is refused, next day resets", () => {
  let boost; let now = T0;
  for (let i = 1; i <= 10; i++) {
    const g = M.grantBoost(boost, now);
    assert.equal(g.granted, true);
    boost = { endsAt: g.boostEndsAt, day: g.day, count: g.count, segments: [g.segment] };
    now += 1000;
  }
  assert.equal(M.grantBoost(boost, now).granted, false);
  assert.equal(M.grantBoost(boost, now).reason, "daily_cap");
  assert.equal(M.grantBoost(boost, now + 24 * 3600 * 1000).granted, true);
});

test("a boost while another is active continues after it (segments never overlap)", () => {
  const g1 = M.grantBoost(undefined, T0);
  const g2 = M.grantBoost({ endsAt: g1.boostEndsAt, day: g1.day, count: 1 }, T0 + 60000);
  assert.equal(g2.segment.from, g1.segment.to);
  assert.equal(g2.segment.to - g2.segment.from, C.BOOST_MS);
});

test("price: fresh accepted; stale, missing and future-dated rejected", () => {
  const now = T0, unix = (ms) => Math.floor(ms / 1000);
  assert.equal(W.parsePrice({ "render-token": { pkr: 500, last_updated_at: unix(now - 60000) } }, now).ok, true);
  assert.equal(W.parsePrice({ "render-token": { pkr: 500, last_updated_at: unix(now - 3600000) } }, now).reason, "price_stale");
  assert.equal(W.parsePrice({}, now).reason, "price_unavailable");
  assert.equal(W.parsePrice({ "render-token": { pkr: 0, last_updated_at: unix(now) } }, now).reason, "price_unavailable");
  assert.equal(W.parsePrice({ "render-token": { pkr: 500, last_updated_at: unix(now + 3600000) } }, now).reason, "price_unavailable");
});

test("minimum PKR 40 converts to a RENDER amount rounded up", () => {
  const u = W.minUnitsFor(500);                       // 40/500 = 0.08 RENDER
  assert.equal(u, 8000000);
  assert.ok(W.pkrValue(u, 500) >= 40);
  assert.ok(W.pkrValue(u - 1, 500) < 40);
  assert.ok(W.minUnitsFor(333) * 333 / C.UNITS_PER_RENDER >= 40);
});

test("withdraw amounts: junk rejected", () => {
  for (const bad of [0, -1, NaN, "abc", Infinity, null, undefined, 1e-12]) assert.equal(W.toUnits(bad), null, String(bad));
  assert.equal(W.toUnits("0.08"), 8000000);
});

test("destinations validated like the app (Binance UID, EasyPaisa 03xxxxxxxxx)", () => {
  assert.equal(W.validateDestination({ method: "Binance", binanceUID: "123456789" }).ok, true);
  assert.equal(W.validateDestination({ method: "Binance", binanceUID: "12ab" }).ok, false);
  assert.equal(W.validateDestination({ method: "EasyPaisa", accountName: "Ali", accountNumber: "0312 3456789" }).destination.accountNumber, "03123456789");
  assert.equal(W.validateDestination({ method: "EasyPaisa", accountName: "Ali", accountNumber: "123" }).ok, false);
  assert.equal(W.validateDestination({ method: "PayPal" }).ok, false);
});

test("withdrawal statuses stay distinct: only approved can become paid", () => {
  assert.equal(W.canTransition("requested", "paid"), false);
  assert.equal(W.canTransition("requested", "approved"), true);
  assert.equal(W.canTransition("approved", "paid"), true);
  assert.equal(W.canTransition("paid", "rejected"), false);
  assert.equal(W.canTransition("rejected", "approved"), false);
});

test("payout days are Saturday and Sunday in Pakistan time", () => {
  assert.equal(W.isPayoutDay(Date.UTC(2026, 9, 17, 12)), true);    // Sat 17 Oct 2026
  assert.equal(W.isPayoutDay(Date.UTC(2026, 9, 18, 12)), true);    // Sun
  assert.equal(W.isPayoutDay(Date.UTC(2026, 9, 19, 12)), false);   // Mon
  assert.equal(W.isPayoutDay(Date.UTC(2026, 9, 16, 20)), true);    // Fri 20:00 UTC = Sat 01:00 PKT
});

test("AdMob SSV: genuine signature accepted; tampered, unknown key, stale and unsigned rejected", () => {
  // Uses a locally generated key pair to exercise the verification code. It does NOT prove AdMob's real signatures verify.
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  const keys = { keys: [{ keyId: 42, pem: publicKey.export({ type: "spki", format: "pem" }) }] };
  const now = T0;
  const msg = `ad_network=1&ad_unit=2&reward_amount=1&reward_item=boost&timestamp=${now - 1000}&transaction_id=abc&user_id=u1`;
  const sig = crypto.sign("sha256", Buffer.from(msg), { key: privateKey, dsaEncoding: "der" }).toString("base64url");
  const q = `${msg}&signature=${sig}&key_id=42`;
  const r = verifySsv(q, keys, now);
  assert.equal(r.ok, true);
  assert.equal(r.params.userId, "u1");
  assert.equal(verifySsv(q.replace("user_id=u1", "user_id=u2"), keys, now).reason, "bad_signature");
  assert.equal(verifySsv(q.replace("key_id=42", "key_id=7"), keys, now).reason, "unknown_key");
  assert.equal(verifySsv(q, keys, now + 3600000).reason, "stale_event");
  assert.equal(verifySsv(msg, keys, now).reason, "no_signature");
});
