"use strict";
// Pure-logic tests for the hardening changes. They prove the decision rules, NOT that deployed Firebase enforces them
// (App Check enforcement, Firestore transactions, rate-limit documents and the HTTP endpoint need the real project or emulator).
const test = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const C = require("../lib/constants");
const M = require("../lib/mining");
const { checkAdUnit, normalizeAdUnit, verifySsv } = require("../lib/ssv");
const RL = require("../lib/ratelimit");
const G = require("../lib/guards");

const T0 = Date.UTC(2026, 9, 14, 10, 0, 0);

/* ---------- ad unit validation ---------- */
test("ad unit: empty or missing configuration refuses everything", () => {
  for (const cfg of ["", "   ", undefined, null]) {
    const r = checkAdUnit(cfg, "1234567890");
    assert.equal(r.ok, false); assert.equal(r.reason, "ad_unit_not_configured");
  }
});
test("ad unit: only OUR unit passes (short or full form), others are refused", () => {
  assert.equal(checkAdUnit("1234567890", "1234567890").ok, true);
  assert.equal(checkAdUnit("ca-app-pub-111~222/1234567890", "1234567890").ok, true);
  assert.equal(checkAdUnit("1234567890", "ca-app-pub-111/1234567890").ok, true);
  assert.equal(checkAdUnit("1234567890", "9999999999").reason, "wrong_ad_unit");
  assert.equal(checkAdUnit("1234567890", "").reason, "wrong_ad_unit");
  assert.equal(normalizeAdUnit(" a/b/c "), "c");
});
test("ad unit: a validly SIGNED callback for someone else's ad unit is still refused", () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  const keys = { keys: [{ keyId: 1, pem: publicKey.export({ type: "spki", format: "pem" }) }] };
  const msg = `ad_network=1&ad_unit=5555555555&timestamp=${T0}&transaction_id=t1&user_id=u1`;
  const sig = crypto.sign("sha256", Buffer.from(msg), { key: privateKey, dsaEncoding: "der" }).toString("base64url");
  const v = verifySsv(`${msg}&signature=${sig}&key_id=1`, keys, T0);
  assert.equal(v.ok, true);                                       // signature is genuine...
  assert.equal(checkAdUnit("1234567890", v.params.adUnit).ok, false);   // ...but not our ad unit
  assert.equal(checkAdUnit("", v.params.adUnit).ok, false);             // ...and nothing is granted with no config
});

/* ---------- ad event decision (replay / cap / grant) ---------- */
test("ad event: grant only for a new transaction of an existing user under the cap", () => {
  const d = M.decideAdEvent({ eventExists: false, userExists: true, boost: undefined, now: T0 });
  assert.equal(d.kind, "grant"); assert.equal(d.grant.segment.to - d.grant.segment.from, C.BOOST_MS);
});
test("ad event: a replayed transaction never grants again, even if under the cap", () => {
  assert.equal(M.decideAdEvent({ eventExists: true, userExists: true, boost: undefined, now: T0 }).kind, "ignore");
});
test("ad event: unknown user and the 11th boost of the day are rejected, not granted", () => {
  assert.equal(M.decideAdEvent({ eventExists: false, userExists: false, now: T0 }).status, "rejected_no_user");
  const full = { endsAt: 0, day: M.pktDay(T0), count: 10, segments: [] };
  const d = M.decideAdEvent({ eventExists: false, userExists: true, boost: full, now: T0 });
  assert.equal(d.kind, "reject"); assert.equal(d.status, "rejected_daily_cap");
});

/* ---------- read-only sync keeps rewards exact ---------- */
const session = (start) => ({ status: "active", sessionId: "s", startedAt: start, endsAt: start + C.SESSION_MS, creditedUnits: 0 });
const user = (over = {}) => ({ balanceUnits: 1000, totalEarnedUnits: 1000, mining: session(T0), boost: { endsAt: 0, day: "", count: 0, segments: [] }, ...over });

test("sync: mid-session getState needs NO write and shows the exact accrued balance", () => {
  const u = user();
  const p = M.planState(u, T0 + 30 * 60000);
  assert.equal(p.needsWrite, false);
  assert.equal(p.view.balanceUnits, 1000 + 8334);
  assert.equal(u.balanceUnits, 1000);                       // input untouched: nothing was persisted
});
test("sync: 100 read-only syncs then one finalise credits exactly one session (no loss, no double credit)", () => {
  let u = user(), reads = 0;
  for (let i = 1; i <= 100; i++) { const p = M.planState(u, T0 + i * 30000); assert.equal(p.needsWrite, false); reads++; }
  const end = M.planState(u, T0 + C.SESSION_MS + 5000);
  assert.equal(end.needsWrite, true);                       // exactly one write needed, at the end
  assert.equal(end.view.balanceUnits, 1000 + 16668);
  const again = M.settle(end.view.mining, [], T0 + C.SESSION_MS + 9000);   // finalising twice credits nothing more
  assert.equal(again.creditUnits, 0);
});
test("sync: read-only result equals the old write-every-time result at any moment", () => {
  const seg = [{ from: T0 + 600000, to: T0 + 1200000 }];
  let old = { ...session(T0) }, oldBal = 1000;
  for (let t = 1; t <= 59; t++) { const r = M.settle(old, seg, T0 + t * 60000); old = r.mining; oldBal += r.creditUnits; }
  const lazy = M.planState(user({ boost: { endsAt: T0 + 1200000, day: M.pktDay(T0), count: 1, segments: seg } }), T0 + 59 * 60000);
  assert.equal(lazy.view.balanceUnits, oldBal);
});
test("sync: idle user and brand-new profile", () => {
  assert.equal(M.planState(user({ mining: { status: "idle" } }), T0).needsWrite, false);
  assert.equal(M.planState(null, T0).needsWrite, true);
});
test("rates unchanged: base 0.00016668/h, ceiling 0.000947/h, boosted rate under ceiling", () => {
  assert.equal(M.BASE_UNITS_PER_HOUR, 16668); assert.equal(C.MAX_UNITS_PER_HOUR, 94700);
  assert.ok(M.BOOST_UNITS_PER_HOUR <= C.MAX_UNITS_PER_HOUR); assert.equal(C.SESSION_MS, 3600000);
  assert.equal(M.entitledUnits(session(T0), T0 + C.SESSION_MS, []), 16668);
});
test("segments of an unfinalised session survive pruning, so late finalisation is not under-credited", () => {
  const seg = [{ from: T0, to: T0 + C.BOOST_MS }];
  const later = T0 + 5 * C.HOUR_MS;                            // user comes back 5 h after the session ended
  const naive = (seg || []).filter((s) => s.to > later - 2 * C.HOUR_MS);   // what the old rule would keep
  assert.equal(naive.length, 0);
  const kept = M.pruneSegments(seg, later, T0);
  assert.equal(kept.length, 1);
  const withBoost = M.entitledUnits(session(T0), later, kept), without = M.entitledUnits(session(T0), later, []);
  assert.ok(withBoost > without);
  assert.equal(M.pruneSegments(seg, later, undefined).length, 0);   // no active session: old segments are dropped
});

/* ---------- rate limits ---------- */
test("rate limit: allows up to the limit in a window, then refuses with a retry time", () => {
  let rec;
  for (let i = 1; i <= 5; i++) { const r = RL.checkWindow(rec, T0 + i, 5, 3600000); assert.equal(r.ok, true); rec = r.next; }
  const r6 = RL.checkWindow(rec, T0 + 10, 5, 3600000);
  assert.equal(r6.ok, false); assert.ok(r6.retryInMs > 0 && r6.retryInMs <= 3600000);
  assert.equal(RL.checkWindow(rec, T0 + 3600001, 5, 3600000).ok, true);    // new window
});
test("rate limit: refused calls do not extend the window or the count", () => {
  let rec = RL.checkWindow(undefined, T0, 1, 1000).next;
  const bad = RL.checkWindow(rec, T0 + 10, 1, 1000);
  assert.equal(bad.ok, false); assert.deepEqual(bad.next, rec);
});
test("rate limit: memory limiter is per key and bounded", () => {
  const hit = RL.memoryLimiter(10);
  assert.equal(hit("u1:a", 1, 1000, T0).ok, true);
  assert.equal(hit("u1:a", 1, 1000, T0 + 1).ok, false);
  assert.equal(hit("u2:a", 1, 1000, T0 + 1).ok, true);                     // other user unaffected
  for (let i = 0; i < 50; i++) hit("k" + i, 5, 10, T0 + 5000 + i);          // many keys, old windows expire
  assert.equal(hit("u1:a", 1, 1000, T0 + 5000).ok, true);
});

/* ---------- App Check guard ---------- */
test("app check: not enforced = everyone passes; enforced = only verified tokens pass", () => {
  assert.equal(G.appCheckOk(false, false), true);
  assert.equal(G.appCheckOk(false, true), true);
  assert.equal(G.appCheckOk(true, false), false);
  assert.equal(G.appCheckOk(true, undefined), false);
  assert.equal(G.appCheckOk(true, true), true);
});

/* ---- authentication gate (Firebase Auth only; no custom login code) ---- */
test("authGate: no session -> unauthenticated", () => {
  const r = G.authGate({ auth: null, hasAppCheck: false }, false);
  assert.deepEqual([r.ok, r.code, r.message], [false, "unauthenticated", "sign_in_required"]);
  assert.equal(G.authGate({ auth: undefined }, false).code, "unauthenticated");
  assert.equal(G.authGate({ auth: {} }, false).code, "unauthenticated");   // no uid
});
test("authGate: signed in but email NOT verified -> refused with email_not_verified", () => {
  for (const claim of [false, undefined, null, "true", 1]) {
    const r = G.authGate({ auth: { uid: "u1", token: { email_verified: claim } } }, false);
    assert.deepEqual([r.ok, r.code, r.message], [false, "failed-precondition", "email_not_verified"], String(claim));
  }
  assert.equal(G.authGate({ auth: { uid: "u1" } }, false).message, "email_not_verified");   // token missing entirely
});
test("authGate: verified email alone is enough; old otpFor claim neither helps nor hurts", () => {
  assert.equal(G.authGate({ auth: { uid: "u1", token: { email_verified: true } } }, false).ok, true);
  assert.equal(G.authGate({ auth: { uid: "u1", token: { email_verified: true, otpFor: 123, auth_time: 456 } } }, false).ok, true);
  assert.equal(G.authGate({ auth: { uid: "u1", token: { email_verified: false, otpFor: 456, auth_time: 456 } } }, false).ok, false);
});
test("authGate: App Check is still enforced first when switched on", () => {
  const a = { uid: "u1", token: { email_verified: true } };
  assert.equal(G.authGate({ auth: a, hasAppCheck: false }, true).message, "app_check_required");
  assert.equal(G.authGate({ auth: a, hasAppCheck: true }, true).ok, true);
});
test("backend contains no OTP / SMTP code any more", () => {
  const fs = require("node:fs"), path = require("node:path");
  const src = fs.readFileSync(path.join(__dirname, "..", "index.js"), "utf8");
  for (const word of ["requestLoginCode", "verifyLoginCode", "nodemailer", "SMTP_URL", "OTP_PEPPER", "otpFor", "loginCodes"]) assert.ok(!src.includes(word), word);
  assert.ok(!fs.existsSync(path.join(__dirname, "..", "lib", "otp.js")));
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "package.json"), "utf8"));
  assert.ok(!("nodemailer" in pkg.dependencies));
});
