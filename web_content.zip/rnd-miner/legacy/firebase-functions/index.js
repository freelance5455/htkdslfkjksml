"use strict";
/**
 * RND Miner trusted backend (Firebase Cloud Functions v2, Node 22).
 * The app can NOT write to Firestore at all (see firestore.rules). Every balance change, boost and withdrawal
 * is decided here, using SERVER time. Requires the Blaze plan to deploy.
 *
 * Callable functions (all need a genuine Firebase Authentication session whose ID token has email_verified === true):
 *   getState, startMining, getPrice, requestWithdrawal
 * There is no custom login code / OTP and no SMTP: Firebase Authentication sends the verification and password-reset emails.
 * Withdrawal approval/payment is done by the owner with functions/tools/admin.js (Admin SDK, your own computer), never from the app.
 * HTTPS endpoint: adReward (AdMob server-side verification callback; signature-checked).
 */
const { onCall, onRequest, HttpsError } = require("firebase-functions/v2/https");
const { setGlobalOptions } = require("firebase-functions/v2");
const { defineString, defineBoolean } = require("firebase-functions/params");
const admin = require("firebase-admin");

const C = require("./lib/constants");
const M = require("./lib/mining");
const W = require("./lib/withdraw");
const { verifySsv, checkAdUnit } = require("./lib/ssv");
const RL = require("./lib/ratelimit");
const G = require("./lib/guards");
const { safeCallable } = require("./lib/errors");

admin.initializeApp();
const db = admin.firestore();
setGlobalOptions({ region: "us-central1", maxInstances: 10 });

const AD_UNIT_ID = defineString("ADMOB_REWARDED_AD_UNIT_ID", { default: "" });   // REQUIRED for ad boosts: empty = every ad callback is refused
// Deploy with ENFORCE_APP_CHECK=true only AFTER the app sends valid App Check tokens (see docs/FIREBASE_SETUP.md section 9).
const ENFORCE_APP_CHECK = defineBoolean("ENFORCE_APP_CHECK", { default: false });

const userRef = (uid) => db.collection("users").doc(uid);
const fail = (code, msg) => new HttpsError(code, msg);
/* Every callable body goes through this: a Firestore/runtime failure becomes a distinct backend_* code (and is logged in full)
   instead of the runtime's anonymous "INTERNAL". HttpsErrors thrown by our own checks pass through unchanged. */
const safe = (name, fn) => safeCallable(name, HttpsError, console.error, fn);

/* ---------- rate limits (per signed-in user) ---------- */
const mem = RL.memoryLimiter();
/** Free, best-effort limit kept in this instance's memory (each instance counts separately). For cheap read paths. */
function limitMem(uid, name, limit, windowMs) {
  const r = mem(`${uid}:${name}`, limit, windowMs, Date.now());
  if (!r.ok) throw fail("resource-exhausted", `rate_limited:${Math.ceil(r.retryInMs / 1000)}`);
}
/** Exact limit stored in Firestore (one small write per call). Used only for rare, sensitive actions. */
async function limitDb(uid, name, limit, windowMs) {
  const ref = db.collection("rateLimits").doc(`${uid}_${name}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const r = RL.checkWindow(snap.exists ? snap.data() : undefined, Date.now(), limit, windowMs);
    if (!r.ok) throw fail("resource-exhausted", `rate_limited:${Math.ceil(r.retryInMs / 1000)}`);
    tx.set(ref, r.next);
  });
}

/* ---------- auth gate ---------- */
/** Signed in with a genuine Firebase session (token verified by Firebase) AND email verified. See lib/guards.js. */
function requireVerifiedEmail(request) {
  const g = G.authGate({ auth: request.auth, hasAppCheck: !!request.app }, ENFORCE_APP_CHECK.value());
  if (!g.ok) throw fail(g.code, g.message);
  return request.auth;
}

function newProfile(uid, token, now) {
  return {
    schema: 1, uid, email: token.email || "", displayName: token.name || (token.email ? token.email.split("@")[0] : "Miner"),
    createdAt: now, balanceUnits: 0, totalEarnedUnits: 0,
    mining: { status: "idle" },
    boost: { endsAt: 0, day: "", count: 0, segments: [] },
  };
}

function audit(tx, uid, type, data, now) {
  tx.set(db.collection("audit").doc(), { uid, type, at: now, ...data });
}
function ledger(tx, uid, entry, now) {
  tx.set(userRef(uid).collection("ledger").doc(), { at: now, ...entry });
}

/** Settle mining inside a transaction: credits balance, finalises finished sessions. Mutates and returns `u`. */
function applySettlement(tx, uid, u, now) {
  const segs = M.pruneSegments(u.boost && u.boost.segments, now, M.activeStart(u.mining));
  const r = M.settle(u.mining, segs, now);
  if (r.creditUnits > 0) { u.balanceUnits += r.creditUnits; u.totalEarnedUnits += r.creditUnits; }
  u.mining = r.mining;
  u.boost = { ...(u.boost || {}), segments: segs };
  if (r.finished && u.mining.sessionId) {
    const sid = u.mining.sessionId;
    tx.set(userRef(uid).collection("sessions").doc(sid), { startedAt: u.mining.startedAt, endsAt: u.mining.endsAt, status: "finished", creditedUnits: u.mining.creditedUnits, finishedAt: now }, { merge: true });
    ledger(tx, uid, { type: "mining_session", sessionId: sid, units: u.mining.creditedUnits, balanceAfterUnits: u.balanceUnits }, now);
    u.mining = { status: "idle", lastSessionId: sid };
  }
  return u;
}

async function loadOrCreate(tx, uid, token, now) {
  const snap = await tx.get(userRef(uid));
  return snap.exists ? snap.data() : newProfile(uid, token, now);
}

function publicState(u, now, withdrawals) {
  return {
    serverNow: now,
    profile: { uid: u.uid, email: u.email, displayName: u.displayName },
    balanceUnits: u.balanceUnits, totalEarnedUnits: u.totalEarnedUnits,
    mining: u.mining && u.mining.status === "active" ? { status: "active", startedAt: u.mining.startedAt, endsAt: u.mining.endsAt, creditedUnits: u.mining.creditedUnits || 0 } : { status: "idle" },
    boost: { endsAt: (u.boost && u.boost.endsAt) || 0, count: u.boost && u.boost.day === M.pktDay(now) ? u.boost.count : 0, max: C.MAX_BOOSTS_PER_DAY, segments: (u.boost && u.boost.segments) || [] },
    withdrawals: withdrawals || undefined,
  };
}

async function recentWithdrawals(uid) {
  const q = await userRef(uid).collection("withdrawals").orderBy("requestedAt", "desc").limit(50).get();
  return q.docs.map((d) => {
    const w = d.data();
    return { requestId: w.requestId, method: w.method, amountRender: w.amountUnits / C.UNITS_PER_RENDER, amountPkr: w.amountPkr, status: w.status, requestedAt: w.requestedAt, approvedAt: w.approvedAt || null, paidAt: w.paidAt || null, rejectedAt: w.rejectedAt || null };
  });
}

/* =================== STATE + MINING =================== */
exports.getState = onCall(safe("getState", async (request) => {
  const a = requireVerifiedEmail(request), uid = a.uid, now = Date.now();
  limitMem(uid, "getState", 30, 10 * 60 * 1000);
  const wantHistory = !!(request.data && request.data.withdrawals);
  // Normal path = ONE document read and NO write: the balance is settled in memory (credit is cumulative, so no accuracy is lost).
  const snap = await userRef(uid).get();
  const plan = M.planState(snap.exists ? snap.data() : null, now);
  let u = plan.view;
  if (plan.needsWrite) {   // only for a brand-new profile or a session that has just finished
    u = await db.runTransaction(async (tx) => {
      const s2 = await tx.get(userRef(uid));
      const x = applySettlement(tx, uid, s2.exists ? s2.data() : newProfile(uid, a.token, now), now);
      tx.set(userRef(uid), x);
      return x;
    });
  }
  return publicState(u, now, wantHistory ? await recentWithdrawals(uid) : undefined);
}));

exports.startMining = onCall(safe("startMining", async (request) => {
  const a = requireVerifiedEmail(request), uid = a.uid;
  await limitDb(uid, "startMining", 10, 60 * 60 * 1000);
  const now = Date.now();
  const u = await db.runTransaction(async (tx) => {
    const snap = await tx.get(userRef(uid));
    const u = applySettlement(tx, uid, snap.exists ? snap.data() : newProfile(uid, a.token, now), now);
    if (u.mining.status === "active") throw fail("already-exists", "session_already_active");   // no overlapping sessions
    const sessionId = db.collection("_").doc().id;
    u.mining = { status: "active", sessionId, startedAt: now, endsAt: now + C.SESSION_MS, creditedUnits: 0, lastSettledAt: now };
    tx.set(userRef(uid), u);
    tx.set(userRef(uid).collection("sessions").doc(sessionId), { startedAt: now, endsAt: now + C.SESSION_MS, status: "active", creditedUnits: 0 });
    audit(tx, uid, "mining_started", { sessionId }, now);
    return u;
  });
  return publicState(u, now);
}));

/* =================== PRICE + WITHDRAWALS =================== */
async function fetchPrice(now) {
  const ref = db.collection("system").doc("price");
  const cached = (await ref.get()).data();
  if (cached && now - cached.fetchedAt < C.PRICE_CACHE_MS && now - cached.sourceUpdatedAt <= C.PRICE_MAX_AGE_MS) return cached;
  try {
    const res = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=render-token&vs_currencies=pkr&include_last_updated_at=true", { signal: AbortSignal.timeout(8000), headers: { accept: "application/json" } });
    if (!res.ok) throw new Error("http " + res.status);
    const p = W.parsePrice(await res.json(), now);
    if (!p.ok) throw new Error(p.reason);
    const doc = { renderPkr: p.renderPkr, sourceUpdatedAt: p.sourceUpdatedAt, fetchedAt: now, source: "coingecko:render-token/pkr" };
    await ref.set(doc);
    return doc;
  } catch (e) {
    console.error("price fetch failed", e && e.message);
    // fall back to the stored price ONLY if the exchange rate itself is still recent
    if (cached && now - cached.sourceUpdatedAt <= C.PRICE_MAX_AGE_MS) return cached;
    throw fail("unavailable", "price_unavailable");
  }
}

exports.getPrice = onCall(safe("getPrice", async (request) => {
  const a = requireVerifiedEmail(request);
  limitMem(a.uid, "getPrice", 30, 10 * 60 * 1000);
  const now = Date.now(), p = await fetchPrice(now);
  return { renderPkr: p.renderPkr, minRender: W.minUnitsFor(p.renderPkr) / C.UNITS_PER_RENDER, minPkr: C.MIN_WITHDRAW_PKR, asOf: p.sourceUpdatedAt, serverNow: now };
}));

exports.requestWithdrawal = onCall(safe("requestWithdrawal", async (request) => {
  const a = requireVerifiedEmail(request), uid = a.uid, d = request.data || {};
  const requestId = String(d.requestId || "");
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(requestId)) throw fail("invalid-argument", "invalid_request_id");
  const dest = W.validateDestination(d);
  if (!dest.ok) throw fail("invalid-argument", dest.error);
  const units = W.toUnits(d.amount);
  if (!units) throw fail("invalid-argument", "invalid_amount");

  await limitDb(uid, "requestWithdrawal", 5, 60 * 60 * 1000);
  const priceNow = Date.now();
  const price = await fetchPrice(priceNow);            // throws if unavailable or stale: the request is refused
  const minUnits = W.minUnitsFor(price.renderPkr);
  if (units < minUnits) throw fail("failed-precondition", `below_minimum:${minUnits / C.UNITS_PER_RENDER}`);

  const now = Date.now();
  const wRef = userRef(uid).collection("withdrawals").doc(requestId);
  const out = await db.runTransaction(async (tx) => {
    const existing = await tx.get(wRef);
    if (existing.exists) return { duplicate: true, w: existing.data() };      // same requestId again: no second deduction
    const open = await tx.get(userRef(uid).collection("withdrawals").where("status", "in", ["requested", "approved"]).limit(1));
    if (!open.empty) throw fail("failed-precondition", "withdrawal_already_open");
    const snap = await tx.get(userRef(uid));
    const u = applySettlement(tx, uid, snap.exists ? snap.data() : newProfile(uid, a.token, now), now);
    if (units > u.balanceUnits) throw fail("failed-precondition", "insufficient_balance");
    u.balanceUnits -= units;
    const w = {
      requestId, uid, method: d.method, destination: dest.destination, amountUnits: units,
      amountPkr: W.pkrValue(units, price.renderPkr), renderPkrAtRequest: price.renderPkr, priceSourceUpdatedAt: price.sourceUpdatedAt,
      status: "requested", requestedAt: now,
    };
    tx.set(userRef(uid), u);
    tx.set(wRef, w);
    ledger(tx, uid, { type: "withdrawal_hold", requestId, units: -units, balanceAfterUnits: u.balanceUnits }, now);
    audit(tx, uid, "withdrawal_requested", { requestId, units, method: d.method }, now);
    return { duplicate: false, w, balanceUnits: u.balanceUnits };
  });
  return { requestId, status: out.w.status, duplicate: out.duplicate, amountRender: out.w.amountUnits / C.UNITS_PER_RENDER, amountPkr: out.w.amountPkr };
}));

/* =================== REWARDED-AD VERIFICATION (AdMob SSV) =================== */
let keyCache = { at: 0, keys: null };
async function ssvKeys(now) {
  if (keyCache.keys && now - keyCache.at < 60 * 60 * 1000) return keyCache.keys;
  const res = await fetch("https://www.gstatic.com/admob/reward/verifier-keys.json", { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error("keys http " + res.status);
  keyCache = { at: now, keys: await res.json() };
  return keyCache.keys;
}

/** AdMob calls this URL (GET) after a user finishes a rewarded ad. Only a valid Google signature can grant a boost. */
exports.adReward = onRequest(async (req, res) => {
  const now = Date.now();
  try {
    const rawQuery = (req.url.split("?")[1]) || "";
    const v = verifySsv(rawQuery, await ssvKeys(now), now);
    if (!v.ok) { res.status(400).send(v.reason); return; }
    // Signature alone is not enough: it must be OUR ad unit, and if none is configured nothing is ever granted.
    const unit = checkAdUnit(AD_UNIT_ID.value(), v.params.adUnit);
    if (!unit.ok) { res.status(400).send(unit.reason); return; }
    const uid = v.params.userId, evRef = userRef(uid).collection("adEvents").doc(v.params.transactionId.replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 100));
    await db.runTransaction(async (tx) => {
      const [ev, us] = await Promise.all([tx.get(evRef), tx.get(userRef(uid))]);
      const u = us.exists ? us.data() : null;
      const d = M.decideAdEvent({ eventExists: ev.exists, userExists: us.exists, boost: u && u.boost, now });
      if (d.kind === "ignore") return;                              // replayed callback: nothing changes
      if (d.kind === "reject") { tx.set(evRef, { at: now, status: d.status, adUnit: v.params.adUnit }); return; }
      const g = d.grant;
      const segs = [...M.pruneSegments(u.boost && u.boost.segments, now, M.activeStart(u.mining)), g.segment];
      tx.update(userRef(uid), { boost: { endsAt: g.boostEndsAt, day: g.day, count: g.count, segments: segs } });
      tx.set(evRef, { at: now, status: "granted", adUnit: v.params.adUnit, boostFrom: g.segment.from, boostTo: g.segment.to });
      audit(tx, uid, "ad_boost_granted", { transactionId: v.params.transactionId, count: g.count }, now);
    });
    res.status(200).send("ok");
  } catch (e) {
    console.error("adReward error", e && e.message);
    res.status(500).send("error");
  }
});
