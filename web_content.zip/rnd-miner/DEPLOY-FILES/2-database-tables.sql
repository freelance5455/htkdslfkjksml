-- RND Miner D1 schema. Idempotent: safe to run again; it never drops or empties a table.
-- Money is stored as INTEGER "units": 1 RENDER = 100,000,000 units (no floating-point drift).

CREATE TABLE IF NOT EXISTS users (
  uid                 TEXT PRIMARY KEY,           -- Firebase Auth uid (taken ONLY from the verified ID token)
  email               TEXT NOT NULL DEFAULT '',
  display_name        TEXT NOT NULL DEFAULT '',
  created_at          INTEGER NOT NULL,
  balance_units       INTEGER NOT NULL DEFAULT 0 CHECK (balance_units >= 0),
  total_earned_units  INTEGER NOT NULL DEFAULT 0,
  mining_status       TEXT NOT NULL DEFAULT 'idle',   -- idle | active
  session_id          TEXT,
  started_at          INTEGER,
  ends_at             INTEGER,
  credited_units      INTEGER NOT NULL DEFAULT 0,
  last_settled_at     INTEGER,
  boost_ends_at       INTEGER NOT NULL DEFAULT 0,
  boost_day           TEXT NOT NULL DEFAULT '',
  boost_count         INTEGER NOT NULL DEFAULT 0,
  boost_segments      TEXT NOT NULL DEFAULT '[]',     -- JSON [{from,to}] verified boost windows
  version             INTEGER NOT NULL DEFAULT 1,     -- optimistic-concurrency counter: every write is "if version is still N"
  token               TEXT NOT NULL DEFAULT ''        -- random nonce of the last successful write (guards the batch's other statements)
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, started_at INTEGER NOT NULL, ends_at INTEGER NOT NULL,
  status TEXT NOT NULL, credited_units INTEGER NOT NULL DEFAULT 0, finished_at INTEGER
);
CREATE INDEX IF NOT EXISTS sessions_uid ON sessions(uid, started_at);

CREATE TABLE IF NOT EXISTS ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL, at INTEGER NOT NULL, type TEXT NOT NULL,
  units INTEGER NOT NULL, balance_after_units INTEGER NOT NULL, session_id TEXT, request_id TEXT
);
CREATE INDEX IF NOT EXISTS ledger_uid ON ledger(uid, at);

CREATE TABLE IF NOT EXISTS withdrawals (
  uid TEXT NOT NULL, request_id TEXT NOT NULL,           -- request_id = client-generated idempotency key = the request's reference
  method TEXT NOT NULL, destination TEXT NOT NULL,       -- destination = JSON payment details
  currency TEXT NOT NULL DEFAULT 'RENDER',
  amount_units INTEGER NOT NULL CHECK (amount_units > 0),
  amount_pkr REAL NOT NULL DEFAULT 0, render_pkr_at_request REAL NOT NULL DEFAULT 0, price_source_updated_at INTEGER NOT NULL DEFAULT 0,   -- legacy PKR snapshot; 0 = none recorded (new requests are RENDER-only)
  status TEXT NOT NULL,                                   -- requested | approved | paid | rejected
  requested_at INTEGER NOT NULL, approved_at INTEGER, paid_at INTEGER, rejected_at INTEGER,
  payout_ref TEXT,                                        -- the real payment's transaction reference, set only by the owner when paid
  note TEXT, action_token TEXT,
  PRIMARY KEY (uid, request_id)
);
CREATE INDEX IF NOT EXISTS withdrawals_status ON withdrawals(status, requested_at);

CREATE TABLE IF NOT EXISTS ad_events (
  transaction_id TEXT PRIMARY KEY,                        -- AdMob transaction_id: PRIMARY KEY = replay protection
  uid TEXT NOT NULL, at INTEGER NOT NULL, status TEXT NOT NULL, ad_unit TEXT, boost_from INTEGER, boost_to INTEGER
);

CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT, type TEXT NOT NULL, at INTEGER NOT NULL, data TEXT
);

CREATE TABLE IF NOT EXISTS rate_limits (key TEXT PRIMARY KEY, window_start INTEGER NOT NULL, count INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS system (key TEXT PRIMARY KEY, value TEXT NOT NULL);

-- Admin Panel support (added in v3.1). Non-destructive and idempotent: indexes only, no data is touched.
CREATE INDEX IF NOT EXISTS users_created ON users(created_at);
CREATE INDEX IF NOT EXISTS audit_type ON audit(type, id);
CREATE INDEX IF NOT EXISTS audit_uid_type ON audit(uid, type);
-- Database-level guard: one admin balance adjustment per request id (a repeated request can never be applied twice).
CREATE UNIQUE INDEX IF NOT EXISTS ledger_admin_adjustment_once ON ledger(request_id) WHERE type = 'admin_adjustment';
