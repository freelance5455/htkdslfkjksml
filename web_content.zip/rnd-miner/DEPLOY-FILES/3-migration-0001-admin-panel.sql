-- Migration 0001: Admin Panel support. Run ONCE (safe to re-run). Only creates indexes; never changes or deletes data.
-- NOT TO BE RUN until the D1 backup is verified (docs/DEPLOY-ADMIN-PANEL.md, section 2). Target: database rnd-miner-db (ID 78bec0c3-4ec9-4ab9-b9c1-b5489c6492d3).
-- Command line:  cd worker && npx wrangler d1 execute rnd-miner-db --remote --file=./migrations/0001_admin_panel.sql
-- Dashboard:     Storage & databases > D1 > rnd-miner-db > Console > paste this file > Execute.
-- Admin Panel support (added in v3.1). Non-destructive and idempotent: indexes only, no data is touched.
CREATE INDEX IF NOT EXISTS users_created ON users(created_at);
CREATE INDEX IF NOT EXISTS audit_type ON audit(type, id);
CREATE INDEX IF NOT EXISTS audit_uid_type ON audit(uid, type);
-- Database-level guard: one admin balance adjustment per request id (a repeated request can never be applied twice).
CREATE UNIQUE INDEX IF NOT EXISTS ledger_admin_adjustment_once ON ledger(request_id) WHERE type = 'admin_adjustment';
