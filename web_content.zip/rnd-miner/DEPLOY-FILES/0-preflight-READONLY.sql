-- READ-ONLY PREFLIGHT for the live D1 database rnd-miner-db. Every statement is a SELECT or PRAGMA: nothing is created, changed or deleted.
-- Run it in the Cloudflare D1 Console (Storage & databases > D1 > rnd-miner-db > Console) BEFORE the backup and migration.
-- If the console shows only the last result, paste ONE statement at a time. Save the outputs somewhere private.

-- 1. Which tables exist (expected: ad_events, audit, ledger, rate_limits, sessions, system, users, withdrawals)
SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name;

-- 2. Columns the migration needs (it references users.created_at, audit.type/id/uid, ledger.request_id/type)
PRAGMA table_info(users);
PRAGMA table_info(ledger);
PRAGMA table_info(audit);

-- 3. Indexes that already exist (the migration only adds the 4 missing ones, and skips any that exist)
SELECT name, tbl_name FROM sqlite_master WHERE type = 'index' ORDER BY name;

-- 4. Row counts BEFORE (write them down; the same counts must appear AFTER the migration, except normal app activity)
SELECT COUNT(*) AS users FROM users;
SELECT COUNT(*) AS withdrawals FROM withdrawals;
SELECT COUNT(*) AS sessions FROM sessions;
SELECT COUNT(*) AS ledger_rows, COALESCE(SUM(type = 'admin_adjustment'), 0) AS admin_adjustment_rows FROM ledger;
SELECT COUNT(*) AS audit_rows FROM audit;

-- 5. Would the unique guard fail? Must return NO rows.
SELECT request_id, COUNT(*) AS n FROM ledger WHERE type = 'admin_adjustment' GROUP BY request_id HAVING COUNT(*) > 1;

-- 6. Settled balances before (two users expected)
SELECT uid, email, balance_units, mining_status FROM users ORDER BY created_at;
