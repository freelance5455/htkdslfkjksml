// Migration / deployment-config safety checks. LOCAL ONLY: real SQLite (node:sqlite) standing in for D1. These do NOT touch Cloudflare.
// They prove: the migration only adds indexes, is idempotent, rewrites no rows, references only columns that exist, and the
// repo's wrangler.toml / docs / sources carry the confirmed database and no admin secret.
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const W = new URL("../", import.meta.url).pathname, ROOT = new URL("../../", import.meta.url).pathname;
const read = (p) => fs.readFileSync(p, "utf8");
const schema = read(W + "schema.sql"), migration = read(W + "migrations/0001_admin_panel.sql"), preflight = read(W + "tools/preflight-readonly.sql");
const V31_MARK = "-- Admin Panel support (added in v3.1)";
const stripComments = (sql) => sql.split("\n").filter((l) => !l.trim().startsWith("--") && !l.trim().startsWith("#")).join("\n");
const statements = (sql) => stripComments(sql).split(";").map((s) => s.trim()).filter(Boolean);

/** A database in the pre-v3.1 (live-like) state: all tables, none of the v3.1 indexes, with sample rows incl. NULL request_ids. */
function liveLikeDb() {
  const db = new DatabaseSync(":memory:");
  db.exec(schema.split(V31_MARK)[0]);
  db.exec(`
    INSERT INTO users (uid,email,display_name,created_at,balance_units,total_earned_units) VALUES ('u1','a@example.com','A',1000,500000000,500000000),('u2','b@example.com','B',2000,0,0);
    INSERT INTO sessions (id,uid,started_at,ends_at,status,credited_units,finished_at) VALUES ('s1','u1',1000,4600000,'finished',500000000,4600000);
    INSERT INTO ledger (uid,at,type,units,balance_after_units,session_id,request_id) VALUES ('u1',4600000,'mining_session',500000000,500000000,'s1',NULL);
    INSERT INTO audit (uid,type,at,data) VALUES ('u1','mining_started',1000,'{}');
    INSERT INTO rate_limits (key,window_start,count) VALUES ('k',1,1);
    INSERT INTO system (key,value) VALUES ('render_price','{"pkr":1}');`);
  return db;
}
const tables = (db) => db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map((r) => r.name);
const snapshot = (db) => JSON.stringify(tables(db).map((t) => [t, db.prepare(`SELECT * FROM ${t} ORDER BY rowid`).all()]));
const indexNames = (db) => db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map((r) => r.name);
const cols = (db, t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);

test("migration: every column it references exists (checked against the owner's reported live ledger/audit columns too)", () => {
  const db = liveLikeDb();
  // The owner reported these exact live columns from read-only SQL:
  assert.deepEqual(cols(db, "ledger"), ["id", "uid", "at", "type", "units", "balance_after_units", "session_id", "request_id"]);
  assert.deepEqual(cols(db, "audit"), ["id", "uid", "type", "at", "data"]);
  for (const s of statements(migration)) {
    const m = /ON\s+(\w+)\s*\(([^)]*)\)/i.exec(s); assert.ok(m, "cannot parse: " + s);
    for (const c of m[2].split(",").map((x) => x.trim().split(/\s+/)[0])) assert.ok(cols(db, m[1]).includes(c), `${m[1]}.${c} missing`);
    const w = /WHERE\s+(\w+)\s*=/i.exec(s); if (w) assert.ok(cols(db, m[1]).includes(w[1]), `${m[1]}.${w[1]} (WHERE) missing`);
  }
});
test("migration: only CREATE [UNIQUE] INDEX IF NOT EXISTS statements; nothing that deletes, updates, inserts or alters", () => {
  const sts = statements(migration); assert.equal(sts.length, 4);
  for (const s of sts) assert.match(s, /^CREATE (UNIQUE )?INDEX IF NOT EXISTS /i);
  assert.doesNotMatch(stripComments(migration), /\b(DROP|DELETE|UPDATE|INSERT|ALTER|TRUNCATE|REPLACE|PRAGMA|ATTACH|VACUUM)\b/i);
});
test("migration: rewrites no rows, adds exactly the 4 indexes, and is idempotent (run twice)", () => {
  const db = liveLikeDb(), before = snapshot(db), idxBefore = indexNames(db);
  db.exec(migration); const once = snapshot(db), idxOnce = indexNames(db);
  db.exec(migration); const twice = snapshot(db), idxTwice = indexNames(db);
  assert.equal(once, before, "table data changed after migration"); assert.equal(twice, before, "table data changed after second run");
  assert.deepEqual(idxOnce.filter((n) => !idxBefore.includes(n)), ["audit_type", "audit_uid_type", "ledger_admin_adjustment_once", "users_created"]);
  assert.deepEqual(idxTwice, idxOnce);
  assert.deepEqual(tables(db), tables(liveLikeDb()), "tables must be unchanged");
});
test("migration: a migrated live-like database ends up with the same indexes as a fresh install from schema.sql", () => {
  const live = liveLikeDb(); live.exec(migration);
  const fresh = new DatabaseSync(":memory:"); fresh.exec(schema);
  assert.deepEqual(indexNames(live), indexNames(fresh));
  for (const s of statements(migration)) assert.ok(statements(schema.slice(schema.indexOf(V31_MARK))).includes(s), "schema.sql lacks: " + s);
});
test("migration: the unique guard blocks a repeated admin adjustment id but not withdrawal hold/refund rows that share a request id", () => {
  const db = liveLikeDb(); db.exec(migration);
  const ins = db.prepare("INSERT INTO ledger (uid,at,type,units,balance_after_units,request_id) VALUES (?,?,?,?,?,?)");
  ins.run("u1", 1, "admin_adjustment", 5, 5, "req-0001");
  assert.throws(() => ins.run("u2", 2, "admin_adjustment", 5, 5, "req-0001"), /UNIQUE/);
  ins.run("u1", 3, "withdrawal_hold", -5, 0, "wd-0001"); ins.run("u1", 4, "withdrawal_refund", 5, 5, "wd-0001");   // same id, other types: allowed
});
test("migration: the admin adjustment endpoint works on the migrated live-like database (ledger + audit written, balance exact)", async () => {
  const { adjustBalance } = await import("../src/admin.js");
  const db = liveLikeDb(); db.exec(migration);
  const wrap = (sql, params = []) => ({ bind: (...p) => wrap(sql, p), async first() { return db.prepare(sql).get(...params) ?? null; }, async all() { return { results: db.prepare(sql).all(...params) }; },
    async run() { const r = db.prepare(sql).run(...params); return { meta: { changes: Number(r.changes) } }; }, _exec() { const r = db.prepare(sql).run(...params); return { meta: { changes: Number(r.changes) } }; } });
  const D1 = { prepare: (s) => wrap(s), async batch(st) { db.exec("BEGIN"); try { const o = st.map((s) => s._exec()); db.exec("COMMIT"); return o; } catch (e) { db.exec("ROLLBACK"); throw e; } } };
  const r = await adjustBalance({ DB: D1 }, 5000000, { mode: "add", uid: "u2", amountRender: "1.5", reason: "migration compatibility test", requestId: "mig-test-0001" });
  assert.equal(r.balanceAfterUnits, 150000000);
  const again = await adjustBalance({ DB: D1 }, 5000001, { mode: "add", uid: "u2", amountRender: "1.5", reason: "migration compatibility test", requestId: "mig-test-0001" });
  assert.equal(again.duplicate, true);
  assert.equal(db.prepare("SELECT balance_units AS b FROM users WHERE uid='u2'").get().b, 150000000);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM ledger WHERE type='admin_adjustment'").get().n, 1);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM audit WHERE type='admin_balance_adjustment'").get().n, 1);
});
test("preflight SQL: only SELECT/PRAGMA, valid on the live-like schema, and changes nothing", () => {
  const db = liveLikeDb(), before = snapshot(db), idx = indexNames(db);
  for (const s of statements(preflight)) { assert.match(s, /^(SELECT|PRAGMA)\b/i, "not read-only: " + s); db.prepare(s).all(); }
  assert.equal(snapshot(db), before); assert.deepEqual(indexNames(db), idx);
});
test("wrangler.toml: confirmed database name + ID, binding DB, no placeholder", () => {
  const t = read(W + "wrangler.toml");
  assert.match(t, /^binding = "DB"$/m); assert.match(t, /^database_name = "rnd-miner-db"$/m); assert.match(t, /^database_id = "78bec0c3-4ec9-4ab9-b9c1-b5489c6492d3"$/m);
  assert.doesNotMatch(stripComments(t), /PASTE|REPLACE|YOUR/i); assert.equal((t.match(/\[\[d1_databases\]\]/g) || []).length, 1);
  assert.match(t, /^name = "rnd-miner-api"$/m);
  assert.match(t, /Do NOT run `wrangler deploy`/);
});
test("no command, script or doc still targets the old database name 'rnd-miner' (outside legacy/)", () => {
  const bad = [];
  (function walk(d) { for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    if (["node_modules", "legacy", ".git"].includes(f.name)) continue; const p = path.join(d, f.name);
    if (f.isDirectory()) walk(p); else if (/\.(md|toml|json|sql|mjs|js|yml|py)$/.test(f.name) && !p.endsWith("rnd-miner-v3_1-admin-panel.zip")) {
      read(p).split("\n").forEach((l, i) => { if (/rnd-miner(?![-\w.])/.test(l) && !/migration\.test\.js$/.test(p) && !/"name": "rnd-miner"/.test(l)) bad.push(`${path.relative(ROOT, p)}:${i + 1}`); }); } } })(ROOT);
  assert.deepEqual(bad, []);
});
test("secrets: no admin token value or .dev.vars in sources, web app, bundles or docs; DEPLOY-FILES carry the right files", () => {
  const files = [];
  (function walk(d) { for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    if (["node_modules", ".git"].includes(f.name)) continue; const p = path.join(d, f.name);
    if (f.isDirectory()) walk(p); else files.push(p); } })(ROOT);
  assert.ok(!files.some((p) => /\.dev\.vars$|(^|\/)\.env$/.test(p)));
  for (const p of files.filter((p) => /\.(js|mjs|html|md|toml|json|sql|py|yml)$/.test(p))) {
    const t = read(p);
    assert.doesNotMatch(t, /ADMIN_TOKEN\s*[:=]\s*["'`][A-Za-z0-9+\/=_-]{20,}["'`]/, "hardcoded admin token in " + p);
    assert.doesNotMatch(t, /RND_ADMIN_TOKEN\s*=\s*[A-Za-z0-9+\/=_-]{20,}/, "hardcoded admin token in " + p);
  }
  for (const f of ["www/index.html", "www/js/rnd-backend.js", "worker/src/lib/adminpage.js", "dist/RND-Miner-single.html"]) assert.doesNotMatch(read(ROOT + f), /ADMIN_TOKEN\s*[:=]\s*["'`][^"'`\s]{8,}/, f);
  const df = ROOT + "DEPLOY-FILES/";
  assert.equal(read(df + "1-worker-code.js"), read(W + "dist/worker-single.js"));
  assert.equal(read(df + "3-migration-0001-admin-panel.sql"), migration); assert.equal(read(df + "0-preflight-READONLY.sql"), preflight);
});
