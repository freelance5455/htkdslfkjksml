import test from "node:test"; import assert from "node:assert/strict";
import { world } from "./helpers.js";

test("health: reports database and settings, no secrets", async () => {
  const w = await world(); const r = await w.get("/api/health"); const b = await r.json();
  assert.equal(r.status, 200); assert.equal(b.database, "ok"); assert.equal(b.adminConfigured, true); assert.ok(!JSON.stringify(b).includes("aaaa"));
});
test("health: schema not applied is reported precisely", async () => {
  const w = await world(); w.db.raw.exec("DROP TABLE users"); const b = await (await w.get("/api/health")).json();
  assert.equal(b.database, "schema_not_applied"); assert.equal(b.ok, false);
});
test("no token / garbage token -> sign_in_required (401)", async () => {
  const w = await world();
  let r = await w.req("/api/getState", {}); assert.equal(r.status, 401); assert.equal((await r.json()).error.message, "sign_in_required");
  r = await w.req("/api/getState", { token: "abc.def.ghi" }); assert.equal(r.status, 401);
});
test("token signed by a different key, wrong audience, wrong issuer, expired, unknown kid are all refused", async () => {
  const w = await world();
  const other = await crypto.subtle.generateKey({ name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["sign"]);
  const bad = [
    await w.fb.token({}, w.now, { key: other.privateKey }),
    await w.fb.token({ aud: "other-project" }, w.now),
    await w.fb.token({ iss: "https://securetoken.google.com/other" }, w.now),
    await w.fb.token({ exp: Math.floor(w.now / 1000) - 5 }, w.now),
    await w.fb.token({}, w.now, { kid: "nope" }),
    await w.fb.token({ sub: "" }, w.now),
  ];
  for (const t of bad) { const r = await w.req("/api/getState", { token: t }); assert.equal(r.status, 401, "should be refused"); }
});
test("tampered payload (uid swapped) fails the signature", async () => {
  const w = await world(); const t = (await w.fb.token({}, w.now)).split(".");
  const p = JSON.parse(Buffer.from(t[1], "base64url")); p.sub = "uid_victim";
  const forged = [t[0], Buffer.from(JSON.stringify(p)).toString("base64url"), t[2]].join(".");
  assert.equal((await w.req("/api/getState", { token: forged })).status, 401);
});
test("unverified email is refused with email_not_verified", async () => {
  const w = await world(); const r = await w.call("getState", {}, { email_verified: false });
  assert.equal(r.status, 412); assert.equal(r.error.message, "email_not_verified");
});
test("backend not configured: precise code, not a fake success", async () => {
  const w = await world({ env: { FIREBASE_PROJECT_ID: "" } }); const r = await w.call("getState", {});
  assert.match(r.error.message, /backend_not_configured/);
  const w2 = await world(); w2.env.DB = undefined; const r2 = await w2.call("startMining", {}); assert.match(r2.error.message, /backend_not_configured:database_binding_missing/);
});
test("database tables missing -> backend_database_missing", async () => {
  const w = await world(); w.db.raw.exec("DROP TABLE users"); const r = await w.call("startMining", {});
  assert.equal(r.error.message, "backend_database_missing");
});
test("CORS preflight answered; unknown route 404", async () => {
  const w = await world(); const r = await w.req("/api/startMining", { method: "OPTIONS" });
  assert.equal(r.status, 204); assert.equal(r.headers.get("access-control-allow-origin"), "*");
  assert.equal((await w.req("/api/nope", { token: await w.fb.token() })).status, 404);
});
