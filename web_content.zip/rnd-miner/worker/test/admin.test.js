// Admin Panel tests. LOCAL tests: real Worker code, real SQL on node:sqlite standing in for D1, self-signed Firebase tokens.
// They use isolated in-memory databases only; no production data and no network.
import test from "node:test"; import assert from "node:assert/strict";
import { world } from "./helpers.js";
import { parseRender, ADJUST_MAX_UNITS } from "../src/admin.js";
import * as C from "../src/lib/constants.js";

const eps = { method: "EasyPaisa", accountName: "Ali Khan", accountNumber: "03001234567" };
const SAT = Date.UTC(2026, 9, 17, 8, 0, 0);       // Saturday 17 Oct 2026, 13:00 PKT
const bob = { sub: "uid_bob", email: "bob@example.com" };
const A = "/admin/";
async function two() {   // alice (5000 RENDER) and bob (10 RENDER) exist; balances set directly = test fixture only
  const w = await world();
  await w.call("getState", {}); await w.call("getState", {}, bob);
  w.db.raw.prepare("UPDATE users SET balance_units=? WHERE uid='uid_alice'").run(5e11);
  w.db.raw.prepare("UPDATE users SET balance_units=? WHERE uid='uid_bob'").run(10e8);
  w.db.raw.exec("DELETE FROM ledger"); w.db.raw.exec("INSERT INTO ledger (uid,at,type,units,balance_after_units) VALUES ('uid_alice',1,'seed',500000000000,500000000000),('uid_bob',1,'seed',1000000000,1000000000)");
  return w;
}
const bal = (w, uid = "uid_alice") => w.rows("SELECT balance_units b FROM users WHERE uid=?", uid)[0].b;
const adj = (w, body) => w.admin(A + "balance/adjust", { requestId: "req-" + Math.random().toString(36).slice(2, 12), reason: "test reason", ...body });
const snapshot = (w) => JSON.stringify(["users", "ledger", "withdrawals", "sessions", "audit", "ad_events"].map((t) => w.rows(`SELECT * FROM ${t} ORDER BY 1,2`)));

/* ---------- page + transport security ---------- */
test("GET /admin serves the page: no secret, no browser storage, no external origins, strict CSP, no CORS", async () => {
  const w = await world(), r = await w.get("/admin"), html = await r.text();
  assert.equal(r.status, 200); assert.match(r.headers.get("content-type"), /text\/html/);
  assert.ok(!html.includes(w.env.ADMIN_TOKEN)); assert.ok(!html.includes("__NONCE__"));
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie/.test(html), "token must stay in memory only");
  assert.ok(!/https?:\/\//.test(html), "page must not reference any other origin");
  const csp = r.headers.get("content-security-policy"); assert.match(csp, /default-src 'none'/); assert.match(csp, /connect-src 'self'/); assert.match(csp, /frame-ancestors 'none'/);
  const nonce = /nonce-([A-Za-z0-9]+)/.exec(csp)[1]; assert.ok(html.includes(`nonce="${nonce}"`));
  assert.equal(r.headers.get("access-control-allow-origin"), null); assert.equal(r.headers.get("cache-control"), "no-store");
  assert.ok(!/\sstyle="|\son[a-z]+="/.test(html), "no inline style attributes or inline handlers (CSP)");
  assert.equal((await w.get("/admin/")).status, 200);
});
test("admin API answers never carry CORS headers, and preflight is not granted", async () => {
  const w = await world(), r = await w.req(A + "stats", { token: w.env.ADMIN_TOKEN, headers: { origin: "https://evil.example" } });
  assert.equal(r.status, 200); assert.equal(r.headers.get("access-control-allow-origin"), null);
  const bad = await w.req(A + "stats", { token: "x", headers: { origin: "https://evil.example" } }); assert.equal(bad.headers.get("access-control-allow-origin"), null);
  const pre = await w.req(A + "stats", { method: "OPTIONS", headers: { origin: "https://evil.example" } }); assert.equal(pre.status, 204); assert.equal(pre.headers.get("access-control-allow-origin"), null);
  const user = await w.req("/api/getPrice", { method: "OPTIONS", headers: { origin: "https://a.b" } }); assert.equal(user.headers.get("access-control-allow-origin"), "*");   // user API unchanged
});

/* ---------- authorization ---------- */
test("every admin endpoint refuses: no token, wrong token, and a valid Firebase login (login is not admin)", async () => {
  const w = await world(); const fbToken = await w.fb.token({}, w.now); let n = 0;
  const hit = async (p, token) => { const r = await w.req(A + p, { token, headers: { "cf-connecting-ip": "10.0.0." + (++n) } }); return r.status; };   // a new IP each call: this test is about authorization, lockout has its own test
  for (const p of ["stats", "users/list", "users/get", "balance/adjust", "adjustments/list", "withdrawals/list", "withdrawals/search", "withdrawals/act", "consistency"]) {
    assert.equal(await hit(p, undefined), 403, p + " no token");
    assert.equal(await hit(p, "wrong-token"), 403, p + " wrong token");
    assert.equal(await hit(p, fbToken), 403, p + " firebase token");
  }
  assert.equal((await w.admin(A + "stats", {})).status, 200);
  assert.equal((await w.get(A + "stats")).status, 404);    // GET is not an admin API method
});
test("admin disabled when ADMIN_TOKEN is missing or shorter than 32 characters", async () => {
  for (const t of [undefined, "short"]) { const w = await world({ env: { ADMIN_TOKEN: t } }); const r = await w.admin(A + "stats", {}, "short"); assert.equal(r.status, 412); assert.equal(r.error.message, "admin_disabled"); }
});
test("wrong-token lockout: 5 failures lock that IP for 15 minutes even for the right token; other IPs and later time are fine", async () => {
  const w = await world(), ip = (x) => ({ "cf-connecting-ip": x });
  const call = async (token, ipAddr = "1.1.1.1") => { const r = await w.req(A + "stats", { token, headers: ip(ipAddr) }); return { status: r.status, ...(await r.json()) }; };
  for (let i = 0; i < 5; i++) assert.equal((await call("nope" + i)).status, 403);
  const locked = await call("nope6"); assert.equal(locked.status, 429); assert.match(locked.error.message, /^admin_locked:\d+$/);
  assert.equal((await call(w.env.ADMIN_TOKEN)).status, 429, "right token is refused while locked");
  assert.equal((await call(w.env.ADMIN_TOKEN, "2.2.2.2")).status, 200, "another IP is not locked");
  w.now += 16 * 60 * 1000; assert.equal((await call(w.env.ADMIN_TOKEN)).status, 200, "lock expires");
  for (let i = 0; i < 4; i++) await call("bad" + i); assert.equal((await call(w.env.ADMIN_TOKEN)).status, 200); // success resets the counter
  for (let i = 0; i < 4; i++) assert.equal((await call("again" + i)).status, 403);
});
test("admin request rate limit: more than 120 requests a minute from one IP are refused", async () => {
  const w = await world(); let last;
  for (let i = 0; i < 121; i++) last = await w.admin(A + "stats", {});
  assert.equal(last.status, 429); assert.match(last.error.message, /^rate_limited:/);
  w.now += 61000; assert.equal((await w.admin(A + "stats", {})).status, 200);
});

/* ---------- dashboard ---------- */
test("stats: real counts, settled balances only (a running session's unsettled reward is not counted), all four withdrawal statuses", async () => {
  const w = await two(); await w.call("startMining", {}); w.now += 30 * 60 * 1000;
  const live = (await w.call("getState", {})).data;    // in-memory view includes accrued reward
  assert.equal(live.balanceUnits, 5e11 + 8334);
  for (const [i, st] of ["requested", "approved", "paid", "rejected"].entries())
    w.db.raw.prepare("INSERT INTO withdrawals (uid,request_id,method,destination,amount_units,amount_pkr,render_pkr_at_request,price_source_updated_at,status,requested_at) VALUES ('uid_bob',?,?,?,?,?,3,1,?,?)").run("wd-status-" + i, "EasyPaisa", JSON.stringify(eps), 1e9, 30, st, w.now - i);
  const s = (await w.admin(A + "stats", {})).data;
  assert.equal(s.users.total, 2); assert.equal(s.users.miningNow, 1); assert.equal(s.users.finishedAwaitingSettlement, 0);
  assert.equal(s.settledBalanceUnits, 5e11 + 10e8, "unsettled 8334 units are NOT in the settled total");
  for (const st of ["requested", "approved", "paid", "rejected"]) assert.equal(s.withdrawals[st].count, 1);
  assert.equal(s.payoutDay, false); assert.equal(s.config.adjustMaxRender, 1000);
  w.now += 40 * 60 * 1000; assert.equal((await w.admin(A + "stats", {})).data.users.finishedAwaitingSettlement, 1);
});

/* ---------- users ---------- */
test("user list: paginated (max 100), newest first, search by email / UID / name, wildcards are literal", async () => {
  const w = await world();
  for (let i = 0; i < 7; i++) { w.now += 1000; await w.call("getState", {}, { sub: "uid_u" + i, email: `user${i}@example.com`, name: "Miner " + i }); }
  const p1 = (await w.admin(A + "users/list", { limit: 3 })).data; assert.equal(p1.total, 7); assert.equal(p1.items.length, 3); assert.equal(p1.hasMore, true); assert.equal(p1.items[0].uid, "uid_u6");
  const p3 = (await w.admin(A + "users/list", { limit: 3, offset: 6 })).data; assert.equal(p3.items.length, 1); assert.equal(p3.hasMore, false);
  const all = new Set(); for (const off of [0, 3, 6]) (await w.admin(A + "users/list", { limit: 3, offset: off })).data.items.forEach((u) => all.add(u.uid)); assert.equal(all.size, 7);
  assert.equal((await w.admin(A + "users/list", { limit: 100000 })).data.limit, 100);
  const byMail = (await w.admin(A + "users/list", { q: "user3@example" })).data; assert.equal(byMail.total, 1); assert.equal(byMail.items[0].email, "user3@example.com"); assert.equal(byMail.items[0].displayName, "Miner 3");
  assert.equal((await w.admin(A + "users/list", { q: "uid_u5" })).data.items[0].uid, "uid_u5");
  assert.equal((await w.admin(A + "users/list", { q: "%" })).data.total, 0); assert.equal((await w.admin(A + "users/list", { q: "_" })).data.total, 7);   // "_" appears in every uid, but only as a literal
  assert.equal((await w.admin(A + "users/list", { q: "' OR 1=1 --" })).data.total, 0);
  const u = byMail.items[0]; assert.ok(["balanceUnits", "totalEarnedUnits", "miningStatus", "createdAt"].every((k) => k in u)); assert.ok(!("token" in u));
});
test("user detail: settled balance and unsettled running-session reward are shown separately", async () => {
  const w = await two(); await w.call("startMining", {}); w.now += 30 * 60 * 1000;
  const d = (await w.admin(A + "users/get", { uid: "uid_alice" })).data;
  assert.equal(d.user.balanceUnits, 5e11); assert.equal(d.unsettledRewardUnits, 8334); assert.equal(d.user.miningStatus, "mining");
  assert.equal((await w.admin(A + "users/get", { uid: "nobody" })).error.message, "no_such_user");
});

/* ---------- balance adjustments ---------- */
test("add / subtract / set: exact balances, ledger + audit rows, before/after returned, total_earned untouched", async () => {
  const w = await two(); const earned0 = w.rows("SELECT total_earned_units t FROM users WHERE uid='uid_bob'")[0].t;
  let r = await adj(w, { uid: "uid_bob", mode: "add", amountRender: "5.12345678", reason: "support credit" });
  assert.equal(r.ok, true); assert.equal(r.data.balanceBeforeUnits, 10e8); assert.equal(r.data.balanceAfterUnits, 10e8 + 512345678); assert.equal(bal(w, "uid_bob"), 10e8 + 512345678);
  r = await adj(w, { uid: "uid_bob", mode: "subtract", amountRender: "1", reason: "reverse mistake" }); assert.equal(r.data.deltaUnits, -1e8); assert.equal(bal(w, "uid_bob"), 10e8 + 412345678);
  r = await adj(w, { uid: "uid_bob", mode: "set", amountRender: "2.5", reason: "correct to agreed value" }); assert.equal(r.data.balanceAfterUnits, 250000000); assert.equal(r.data.deltaUnits, 250000000 - (10e8 + 412345678)); assert.equal(bal(w, "uid_bob"), 250000000);
  const led = w.rows("SELECT type,units,balance_after_units FROM ledger WHERE uid='uid_bob' AND type='admin_adjustment' ORDER BY id");
  assert.equal(led.length, 3); assert.deepEqual(led.map((l) => l.balance_after_units), [10e8 + 512345678, 10e8 + 412345678, 250000000]);
  const sum = w.rows("SELECT SUM(units) s FROM ledger WHERE uid='uid_bob'")[0].s; assert.equal(sum, bal(w, "uid_bob"), "ledger sums to the balance");
  const au = w.rows("SELECT * FROM audit WHERE type='admin_balance_adjustment' ORDER BY id"); assert.equal(au.length, 3);
  const a0 = JSON.parse(au[0].data); assert.equal(a0.reason, "support credit"); assert.equal(a0.beforeUnits, 10e8); assert.equal(a0.afterUnits, 10e8 + 512345678); assert.equal(a0.by, "owner-admin");
  assert.equal(w.rows("SELECT total_earned_units t FROM users WHERE uid='uid_bob'")[0].t, earned0);
  assert.equal(bal(w), 5e11, "other users untouched");
  const h = (await w.admin(A + "adjustments/list", { uid: "uid_bob" })).data; assert.equal(h.total, 3); assert.equal(h.items[0].data.mode, "set"); assert.equal(h.items[2].data.reason, "support credit");
});
test("validation: reason mandatory, cap 1000 RENDER, no negative balance, bad mode/amount/user refused; nothing is written", async () => {
  const w = await two(), before = snapshot(w);
  const e = async (body) => (await adj(w, body)).error.message;
  assert.equal(await e({ uid: "uid_bob", mode: "add", amountRender: "1", reason: "" }), "reason_required");
  assert.equal(await e({ uid: "uid_bob", mode: "add", amountRender: "1", reason: "  ab " }), "reason_required");
  assert.equal(await e({ uid: "uid_bob", mode: "add", amountRender: "1000.00000001" }), "above_adjustment_cap:1000");
  assert.equal(await e({ uid: "uid_alice", mode: "set", amountRender: "0" }), "above_adjustment_cap:1000", "set is capped by its resulting change too");
  assert.equal(await e({ uid: "uid_bob", mode: "subtract", amountRender: "10.00000001" }), "insufficient_balance");
  assert.equal(await e({ uid: "uid_bob", mode: "set", amountRender: "10" }), "no_change");
  for (const a of ["-1", "abc", "", "1e3", "0", "1.123456789", "NaN", "Infinity", null, "0x10"]) assert.equal(await e({ uid: "uid_bob", mode: "add", amountRender: a }), "invalid_amount", String(a));
  assert.equal(await e({ uid: "uid_bob", mode: "multiply", amountRender: "1" }), "bad_admin_request");
  assert.equal(await e({ uid: "ghost", mode: "add", amountRender: "1" }), "no_such_user");
  assert.equal((await w.admin(A + "balance/adjust", { uid: "uid_bob", mode: "add", amountRender: "1", reason: "valid reason" })).error.message, "invalid_request_id");
  assert.equal(snapshot(w).replace(/"admin:[^"]*"/g, ""), before.replace(/"admin:[^"]*"/g, ""), "no row changed (a never-seen uid is not created either)");
  assert.equal(w.rows("SELECT COUNT(*) n FROM users WHERE uid='ghost'")[0].n, 0);
  assert.equal((await adj(w, { uid: "uid_bob", mode: "add", amountRender: "1000", reason: "max allowed" })).ok, true);   // exactly the cap is allowed
  assert.equal(ADJUST_MAX_UNITS, 1000 * 1e8);
});
test("duplicate submissions cannot apply twice (sequential, parallel, and DB-level)", async () => {
  const w = await two(), body = { uid: "uid_bob", mode: "add", amountRender: "3", reason: "double tap", requestId: "dup-request-0001" };
  const a = await w.admin(A + "balance/adjust", body), b = await w.admin(A + "balance/adjust", body);
  assert.equal(a.data.duplicate, false); assert.equal(b.data.duplicate, true); assert.equal(b.data.balanceAfterUnits, a.data.balanceAfterUnits); assert.equal(bal(w, "uid_bob"), 10e8 + 3e8);
  const p = await Promise.all([1, 2, 3].map(() => w.admin(A + "balance/adjust", { ...body, requestId: "dup-request-0002" })));
  assert.equal(p.filter((x) => x.ok && !x.data.duplicate).length, 1); assert.equal(bal(w, "uid_bob"), 10e8 + 6e8);
  assert.equal(w.rows("SELECT COUNT(*) n FROM ledger WHERE type='admin_adjustment'")[0].n, 2); assert.equal(w.rows("SELECT COUNT(*) n FROM audit WHERE type='admin_balance_adjustment'")[0].n, 2);
  assert.equal((await w.admin(A + "balance/adjust", { ...body, uid: "uid_alice" })).error.message, "request_id_reused");
  assert.throws(() => w.db.raw.prepare("INSERT INTO ledger (uid,at,type,units,balance_after_units,request_id) VALUES ('uid_bob',1,'admin_adjustment',1,1,'dup-request-0001')").run(), /UNIQUE/);   // the database itself refuses a second row
});
test("parallel different adjustments on one user are all applied exactly once (no lost update)", async () => {
  const w = await two();
  const rs = await Promise.all([1, 2, 3, 4].map((i) => adj(w, { uid: "uid_bob", mode: "add", amountRender: String(i), reason: "parallel " + i })));
  assert.ok(rs.every((r) => r.ok)); assert.equal(bal(w, "uid_bob"), 10e8 + 10e8); assert.equal(w.rows("SELECT SUM(units) s FROM ledger WHERE uid='uid_bob'")[0].s, bal(w, "uid_bob"));
});
test("adjusting a user with a running session: mining state kept, reward credited once, not counted twice", async () => {
  const w = await two(); await w.call("startMining", {}); w.now += 30 * 60 * 1000;
  const sess = w.rows("SELECT session_id,started_at,ends_at,credited_units FROM users WHERE uid='uid_alice'")[0];
  await adj(w, { uid: "uid_alice", mode: "add", amountRender: "5", reason: "bonus" });
  assert.deepEqual(w.rows("SELECT session_id,started_at,ends_at,credited_units FROM users WHERE uid='uid_alice'")[0], sess);
  assert.equal((await w.call("getState", {})).data.balanceUnits, 5e11 + 5e8 + 8334);
  w.now += 31 * 60 * 1000; const fin = (await w.call("getState", {})).data;   // session over: finalised exactly once
  assert.equal(fin.balanceUnits, 5e11 + 5e8 + C.BASE_UNITS_PER_HOUR); assert.equal(fin.balanceUnits, bal(w));
  assert.equal((await w.call("getState", {})).data.balanceUnits, fin.balanceUnits);
  assert.equal(w.rows("SELECT COUNT(*) n FROM ledger WHERE type='mining_session'")[0].n, 1);
  assert.equal((await w.admin(A + "consistency", {})).data.ok, true);
});
test("the user app sees an adjustment in balance and history", async () => {
  const w = await two(); await adj(w, { uid: "uid_bob", mode: "add", amountRender: "7", reason: "visible to user" });
  const s = (await w.call("getState", { withdrawals: true }, bob)).data; assert.equal(s.balanceUnits, 10e8 + 7e8); assert.equal(s.history[0].type, "admin_adjustment"); assert.equal(s.history[0].amountRender, 7);
});

/* ---------- withdrawals ---------- */
async function withWithdrawals() {
  const w = await two();   // bob gets 30 RENDER (fixture) so a 20 RENDER request clears the 0.07 RENDER minimum
  w.db.raw.exec("UPDATE users SET balance_units=3000000000 WHERE uid='uid_bob'; UPDATE ledger SET units=3000000000, balance_after_units=3000000000 WHERE uid='uid_bob'");
  for (const [claims, id] of [[undefined, "req-alice-0001"], [bob, "req-bob-00001"]]) { const r = await w.call("requestWithdrawal", { requestId: id, amount: 20, ...eps }, claims); assert.equal(r.ok, true, JSON.stringify(r)); }
  return w;
}
test("withdrawal search lists all four statuses, filters, searches and paginates; legacy list is still the open array", async () => {
  const w = await withWithdrawals(); const s = (st) => w.admin(A + "withdrawals/search", { status: st });
  w.db.raw.prepare("UPDATE withdrawals SET status='paid', payout_ref='TX123456', paid_at=? WHERE request_id='req-alice-0001'").run(w.now);
  w.db.raw.prepare("INSERT INTO withdrawals (uid,request_id,method,destination,amount_units,amount_pkr,render_pkr_at_request,price_source_updated_at,status,requested_at,rejected_at,note) VALUES ('uid_bob','old-rejected-1','Binance','{\"binanceUID\":\"123456\"}',1000000000,30,3,1,'rejected',5,6,'bad uid')").run();
  assert.equal((await s("all")).data.total, 3); assert.equal((await s("paid")).data.items[0].payoutRef, "TX123456"); assert.equal((await s("rejected")).data.items[0].note, "bad uid");
  assert.equal((await s("requested")).data.items[0].email, "bob@example.com"); assert.equal((await s("approved")).data.total, 0);
  assert.equal((await s("open")).data.total, 1); assert.equal((await w.admin(A + "withdrawals/search", {})).data.status, "open");
  assert.equal((await s("bogus")).error.message, "bad_admin_request");
  assert.equal((await w.admin(A + "withdrawals/search", { status: "all", q: "bob@" })).data.total, 2);
  assert.equal((await w.admin(A + "withdrawals/search", { status: "all", limit: 2 })).data.hasMore, true); assert.equal((await w.admin(A + "withdrawals/search", { status: "all", limit: 2, offset: 2 })).data.items.length, 1);
  const legacy = (await w.admin(A + "withdrawals/list", {})); assert.ok(Array.isArray(legacy.data)); assert.equal(legacy.data.length, 1); assert.equal(legacy.data[0].requestId, "req-bob-00001"); assert.equal(legacy.data[0].amountRender, 20);
  const it = (await s("requested")).data.items[0]; for (const k of ["requestId", "uid", "amountUnits", "amountPkr", "method", "destination", "requestedAt", "status", "payoutRef"]) assert.ok(k in it, k);
});
test("approve -> (weekday refused) -> paid on Saturday with a reference; funds untouched; user history shows each status", async () => {
  const w = await withWithdrawals(), act = (body) => w.admin(A + "withdrawals/act", { uid: "uid_alice", requestId: "req-alice-0001", ...body });
  const held = bal(w); assert.equal(held, 5e11 - 20e8);
  assert.equal((await act({ action: "approve", note: "ok" })).data.status, "approved"); assert.equal(bal(w), held, "approval must not deduct again");
  assert.equal((await w.call("getState", { withdrawals: true })).data.withdrawals[0].status, "approved");
  assert.equal((await act({ action: "markpaid", payoutRef: "TX-1" })).error.message, "payouts_only_sat_sun_pkt");
  w.now = SAT;
  assert.equal((await act({ action: "markpaid" })).error.message, "payout_reference_required"); assert.equal((await act({ action: "markpaid", payoutRef: "  " })).error.message, "payout_reference_required");
  const paid = await act({ action: "markpaid", payoutRef: "  EP-998877 " }); assert.equal(paid.data.status, "paid"); assert.equal(bal(w), held, "paying moves no balance");
  assert.equal(w.rows("SELECT payout_ref r FROM withdrawals WHERE request_id='req-alice-0001'")[0].r, "EP-998877");
  const h = (await w.call("getState", { withdrawals: true })).data.withdrawals[0]; assert.equal(h.status, "paid"); assert.equal(h.payoutRef, "EP-998877"); assert.ok(h.paidAt);
  for (const a of ["approve", "reject", "markpaid"]) assert.match((await act({ action: a, payoutRef: "EP-998877" })).error.message, /^cannot_go_paid_to_/);
  assert.equal(bal(w), held); assert.equal(w.rows("SELECT COUNT(*) n FROM ledger WHERE type='withdrawal_refund'")[0].n, 0);
  const kinds = w.rows("SELECT type FROM audit WHERE type LIKE 'withdrawal_%' AND uid='uid_alice' ORDER BY id").map((r) => r.type); assert.deepEqual(kinds, ["withdrawal_requested", "withdrawal_approved", "withdrawal_paid"]);
  assert.equal(JSON.parse(w.rows("SELECT data FROM audit WHERE type='withdrawal_paid'")[0].data).payoutRef, "EP-998877");
});
test("reject refunds exactly once (from requested or approved), keeps the record, shows as rejected to the user; never refunded or deducted twice", async () => {
  const w = await withWithdrawals(), held = bal(w, "uid_bob");   // 10 RENDER left after the 20 RENDER hold
  const rej = (uid, id) => w.admin(A + "withdrawals/act", { action: "reject", uid, requestId: id, note: "wrong details" });
  assert.equal((await rej("uid_bob", "req-bob-00001")).data.status, "rejected"); assert.equal(bal(w, "uid_bob"), held + 20e8);
  assert.match((await rej("uid_bob", "req-bob-00001")).error.message, /^cannot_go_rejected_to_rejected$/);
  const both = await Promise.all([1, 2].map(() => w.admin(A + "withdrawals/act", { action: "reject", uid: "uid_alice", requestId: "req-alice-0001" })));
  assert.equal(both.filter((x) => x.ok).length, 1); assert.equal(bal(w), 5e11);
  assert.equal(w.rows("SELECT COUNT(*) n FROM ledger WHERE type='withdrawal_refund'")[0].n, 2);
  assert.match((await w.admin(A + "withdrawals/act", { action: "approve", uid: "uid_bob", requestId: "req-bob-00001" })).error.message, /^cannot_go_rejected_to_approved$/);
  assert.match((await w.admin(A + "withdrawals/act", { action: "markpaid", uid: "uid_bob", requestId: "req-bob-00001", payoutRef: "TX-9" })).error.message, /payouts_only|cannot_go/);
  assert.equal(bal(w, "uid_bob"), held + 20e8);
  const hist = (await w.call("getState", { withdrawals: true }, bob)).data; assert.equal(hist.withdrawals[0].status, "rejected"); assert.ok(hist.withdrawals[0].rejectedAt);
  assert.equal(w.rows("SELECT COUNT(*) n FROM withdrawals")[0].n, 2, "no financial record is ever deleted");
  assert.equal((await w.admin(A + "withdrawals/search", { status: "rejected" })).data.total, 2);
  assert.equal((await w.admin(A + "consistency", {})).data.ok, true);
  w.now += 1; assert.equal((await w.call("requestWithdrawal", { requestId: "req-bob-00002", amount: 20, ...eps }, bob)).ok, true); assert.equal(bal(w, "uid_bob"), held, "the refunded funds are spent once, not twice");
});
test("reject after approval refunds once; the requested->paid shortcut and unknown requests are refused", async () => {
  const w = await withWithdrawals(), act = (body) => w.admin(A + "withdrawals/act", { uid: "uid_alice", requestId: "req-alice-0001", ...body });
  w.now = SAT; assert.match((await act({ action: "markpaid", payoutRef: "TX-1" })).error.message, /cannot_go_requested_to_paid/);
  await act({ action: "approve" }); await act({ action: "reject" }); assert.equal(bal(w), 5e11);
  assert.equal((await w.admin(A + "withdrawals/act", { action: "approve", uid: "uid_alice", requestId: "nope" })).error.message, "no_such_withdrawal");
  assert.equal((await act({ action: "explode" })).error.message, "bad_admin_request");
});

/* ---------- consistency, units, data preservation ---------- */
test("consistency report is clean on real flows and reports tampering without changing anything", async () => {
  const w = await withWithdrawals(); assert.equal((await w.admin(A + "consistency", {})).data.ok, true);
  w.db.raw.prepare("UPDATE users SET balance_units = balance_units + 5 WHERE uid='uid_bob'").run(); w.db.raw.exec("DELETE FROM ledger WHERE type='withdrawal_hold' AND uid='uid_alice'");
  const snap = snapshot(w), c = (await w.admin(A + "consistency", {})).data;
  assert.equal(c.ok, false); assert.equal(c.balanceMismatches.find((m) => m.uid === "uid_bob").differenceUnits, 5); assert.equal(c.withdrawalMismatches[0].requestId, "req-alice-0001");
  assert.equal(snapshot(w), snap);
});
test("read-only admin calls never change existing data", async () => {
  const w = await withWithdrawals(); await w.call("startMining", {}); const snap = snapshot(w);
  for (const [p, b] of [["stats", {}], ["users/list", {}], ["users/get", { uid: "uid_alice" }], ["adjustments/list", {}], ["withdrawals/list", {}], ["withdrawals/search", { status: "all" }], ["consistency", {}]]) assert.equal((await w.admin(A + p, b)).ok, true, p);
  assert.equal(snapshot(w), snap);
});
test("unit conversions: 1 RENDER = 1e8 units, exact decimal parsing, rates and ceiling unchanged", () => {
  assert.equal(C.UNITS_PER_RENDER, 1e8); assert.equal(C.BASE_UNITS_PER_HOUR / C.UNITS_PER_RENDER, 0.00016668); assert.equal(C.MAX_UNITS_PER_HOUR / C.UNITS_PER_RENDER, 0.000947);
  assert.equal(C.SESSION_MS, 3600000); assert.equal(C.BOOST_MS, 600000); assert.equal(C.BOOST_MULTIPLIER, 2); assert.equal(C.MAX_BOOSTS_PER_DAY, 10); assert.equal(C.MIN_WITHDRAW_UNITS, 7000000); assert.equal(C.MIN_WITHDRAW_PKR, undefined);
  assert.equal(parseRender("0.00016668"), 16668); assert.equal(parseRender("1"), 1e8); assert.equal(parseRender("0.1"), 1e7); assert.equal(parseRender("0.29"), 29000000); assert.equal(parseRender("1000"), 1e11);
  assert.equal(parseRender("0"), null); assert.equal(parseRender("0", true), 0); assert.equal(parseRender("0.000000001"), null); assert.equal(parseRender(0.1), 1e7); assert.equal(parseRender("999999999999999"), null);
});
