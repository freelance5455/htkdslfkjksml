import test from "node:test"; import assert from "node:assert/strict";
import { world } from "./helpers.js";
const MIN = 60e3;

test("start mining: session + audit saved on the server, state returned from the server", async () => {
  const w = await world(); const r = await w.call("startMining", {});
  assert.equal(r.ok, true); assert.equal(r.data.mining.status, "active");
  assert.equal(r.data.mining.endsAt - r.data.mining.startedAt, 60 * MIN); assert.equal(r.data.mining.startedAt, w.now);
  const s = w.rows("SELECT * FROM sessions"); assert.equal(s.length, 1); assert.equal(s[0].uid, "uid_alice"); assert.equal(s[0].status, "active");
  assert.equal(w.rows("SELECT * FROM users")[0].mining_status, "active");
});
test("second start while active is refused (no overlapping sessions)", async () => {
  const w = await world(); await w.call("startMining", {}); w.now += 5 * MIN;
  const r = await w.call("startMining", {}); assert.equal(r.status, 409); assert.equal(r.error.message, "session_already_active");
  assert.equal(w.rows("SELECT * FROM sessions").length, 1);
});
test("two PARALLEL start requests create exactly one session", async () => {
  const w = await world(); const [a, b] = await Promise.all([w.call("startMining", {}), w.call("startMining", {})]);
  assert.equal([a, b].filter((x) => x.ok).length, 1); assert.equal([a, b].filter((x) => x.error && x.error.message === "session_already_active").length, 1);
  assert.equal(w.rows("SELECT * FROM sessions").length, 1);
});
test("reward is credited from SERVER time: base rate 0.00016668/h, exact and never double-counted", async () => {
  const w = await world(); await w.call("startMining", {});
  w.now += 30 * MIN; let s = (await w.call("getState", {})).data;
  assert.equal(s.balanceUnits, 8334);                      // half an hour of 16668 units/h
  s = (await w.call("getState", {})).data; assert.equal(s.balanceUnits, 8334);   // asking again changes nothing
  w.now += 31 * MIN; s = (await w.call("getState", {})).data;
  assert.equal(s.balanceUnits, 16668); assert.equal(s.mining.status, "idle");     // session ends at 1 h; no credit beyond its end
  w.now += 5 * 3600e3; s = (await w.call("getState", {})).data; assert.equal(s.balanceUnits, 16668);
  const u = w.rows("SELECT * FROM users")[0]; assert.equal(u.balance_units, 16668); assert.equal(u.total_earned_units, 16668);
  const sess = w.rows("SELECT * FROM sessions")[0]; assert.equal(sess.status, "finished"); assert.equal(sess.credited_units, 16668);
  const led = w.rows("SELECT * FROM ledger"); assert.equal(led.length, 1); assert.equal(led[0].type, "mining_session"); assert.equal(led[0].units, 16668);
});
test("balance/history persist across 'logout, new device': a fresh token for the same uid sees the same data", async () => {
  const w = await world(); await w.call("startMining", {}); w.now += 61 * MIN; await w.call("getState", {});
  const again = await w.call("getState", { withdrawals: true }, { jti: "another-device" });
  assert.equal(again.data.balanceUnits, 16668); assert.equal(again.data.history.length, 1);
});
test("client-supplied uid, balance, time and 'completed' flags are ignored", async () => {
  const w = await world(); const real = w.now;
  const r = await w.call("startMining", { uid: "uid_victim", balanceUnits: 9e12, now: real + 10 * 3600e3, startedAt: real - 10 * 3600e3, completed: true });
  assert.equal(r.data.profile.uid, "uid_alice"); assert.equal(r.data.balanceUnits, 0); assert.equal(r.data.mining.startedAt, real);
  assert.equal(w.rows("SELECT uid FROM users").length, 1); assert.equal(w.rows("SELECT uid FROM users")[0].uid, "uid_alice");
  const s = (await w.call("getState", { balanceUnits: 5, completed: true })).data; assert.equal(s.balanceUnits, 0);   // no instant credit
});
test("a rewind of the server clock can never credit more than was earned", async () => {
  const w = await world(); await w.call("startMining", {}); w.now += 30 * MIN; await w.call("getState", {});
  w.now -= 20 * MIN; const s = (await w.call("getState", {})).data; assert.equal(s.balanceUnits, 8334 - 0 > 8334 ? 0 : s.balanceUnits); assert.ok(s.balanceUnits <= 8334);
});
test("database rate limiter: atomic, shared, window resets (limit 3 per hour)", async () => {
  const { limitDb } = await import("../src/db.js"); const w = await world(); const t = w.now;
  for (let i = 0; i < 3; i++) await limitDb(w.db, "k", 3, 3600e3, t + i);
  await assert.rejects(() => limitDb(w.db, "k", 3, 3600e3, t + 10), (e) => /^rate_limited:\d+$/.test(e.msg));
  await limitDb(w.db, "k", 3, 3600e3, t + 3600e3 + 1);   // new window
  await Promise.all([1, 2, 3, 4, 5].map((i) => limitDb(w.db, "p", 100, 3600e3, t + i))); assert.equal(w.rows("SELECT count c FROM rate_limits WHERE key='p'")[0].c, 5);
});
test("users are isolated: bob cannot see or touch alice's balance", async () => {
  const w = await world(); await w.call("startMining", {}); w.now += 61 * MIN; await w.call("getState", {});
  const bob = await w.call("getState", {}, { sub: "uid_bob", email: "bob@example.com" }); assert.equal(bob.data.balanceUnits, 0); assert.equal(bob.data.profile.uid, "uid_bob");
});
test("a database failure mid-request never reports success", async () => {
  const w = await world(); w.db.raw.exec("DROP TABLE sessions");
  const r = await w.call("startMining", {}); assert.equal(r.ok, false); assert.equal(r.error.message, "backend_database_missing");
  assert.equal(w.rows("SELECT mining_status FROM users").length === 0 || w.rows("SELECT mining_status FROM users")[0].mining_status === "idle", true);   // atomic: user row NOT left 'active'
});
