// Smoke test of the SINGLE-FILE build (worker/dist/worker-single.js) that gets pasted into the Cloudflare dashboard.
// Local only: real bundle code, SQLite standing in for D1. Full behaviour is covered by the other tests on src/.
import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { makeD1 } from "./helpers.js";
execFileSync(process.execPath, [new URL("../../scripts/build-worker-single.mjs", import.meta.url).pathname]);
const worker = (await import("../dist/worker-single.js?" + Date.now())).default;
const env = () => ({ DB: makeD1(), FIREBASE_PROJECT_ID: "p", ALLOWED_ORIGINS: "*" });
const call = (path, o = {}, e = env()) => worker.fetch(new Request("https://x.test" + path, { method: "POST", headers: { "content-type": "application/json", ...(o.headers || {}) }, body: "{}", ...o }), e);

test("bundle: health says database ok", async () => {
  const r = await worker.fetch(new Request("https://x.test/api/health"), env());
  const j = await r.json(); assert.equal(r.status, 200); assert.equal(j.database, "ok"); assert.equal(j.service, "rnd-miner-api");
});
test("bundle: health reports missing database binding", async () => {
  const r = await worker.fetch(new Request("https://x.test/api/health"), { FIREBASE_PROJECT_ID: "p" });
  assert.equal(r.status, 503); assert.equal((await r.json()).database, "missing_binding");
});
test("bundle: health reports schema not applied", async () => {
  const e = env(); e.DB.raw.exec("DROP TABLE users");
  const r = await worker.fetch(new Request("https://x.test/api/health"), e);
  assert.equal(r.status, 503); assert.equal((await r.json()).database, "schema_not_applied");
});
test("bundle: startMining without or with a forged token is refused", async () => {
  for (const headers of [{}, { authorization: "Bearer not.a.token" }]) {
    const r = await call("/api/startMining", { headers }); assert.ok(r.status === 401 || r.status === 403, "status " + r.status);
  }
});
test("bundle: CORS preflight answers", async () => {
  const r = await worker.fetch(new Request("https://x.test/api/startMining", { method: "OPTIONS", headers: { origin: "https://a.b" } }), env());
  assert.equal(r.status, 204);
});

// ---- Admin Panel inside the generated single-file Worker (the file that is pasted into Cloudflare) ----
const adminEnv = () => ({ ...env(), ADMIN_TOKEN: "t".repeat(40) });
const adminCall = (path, body, e, token = "t".repeat(40)) => worker.fetch(new Request("https://x.test" + path, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + token }, body: JSON.stringify(body || {}) }), e);
test("bundle: GET /admin serves the page, with CSP and without CORS or any secret", async () => {
  const e = adminEnv(), r = await worker.fetch(new Request("https://x.test/admin"), e), html = await r.text();
  assert.equal(r.status, 200); assert.match(r.headers.get("content-security-policy"), /connect-src 'self'/); assert.equal(r.headers.get("access-control-allow-origin"), null);
  assert.ok(html.includes("RND Miner") && !html.includes(e.ADMIN_TOKEN) && !html.includes("__NONCE__"));
});
test("bundle: admin API works end to end (auth, stats, adjust, duplicate-safe, withdrawals search)", async () => {
  const e = adminEnv(); e.DB.raw.prepare("INSERT INTO users (uid,email,display_name,created_at,balance_units) VALUES ('u1','a@b.c','A',1,500000000)").run();
  e.DB.raw.prepare("INSERT INTO ledger (uid,at,type,units,balance_after_units) VALUES ('u1',1,'seed',500000000,500000000)").run();   // fixture: balance backed by a ledger row, as in real data
  assert.equal((await adminCall("/admin/stats", {}, e, "wrong")).status, 403);
  const s = await (await adminCall("/admin/stats", {}, e)).json(); assert.equal(s.data.users.total, 1); assert.equal(s.data.settledBalanceUnits, 5e8);
  const body = { uid: "u1", mode: "add", amountRender: "2", reason: "bundle test", requestId: "bundle-req-0001" };
  const a = await (await adminCall("/admin/balance/adjust", body, e)).json(), b = await (await adminCall("/admin/balance/adjust", body, e)).json();
  assert.equal(a.data.balanceAfterUnits, 7e8); assert.equal(b.data.duplicate, true); assert.equal(e.DB.raw.prepare("SELECT balance_units b FROM users").get().b, 7e8);
  const w = await (await adminCall("/admin/withdrawals/search", { status: "all" }, e)).json(); assert.equal(w.data.total, 0);
  assert.equal((await (await adminCall("/admin/consistency", {}, e)).json()).data.ok, true);
  assert.equal((await adminCall("/admin/nothing", {}, e)).status, 404);
});

import fs from "node:fs";
test("generated Worker matches the source: DEPLOY-FILES copies equal the fresh build and schema, and every source module is inside it", () => {
  const dist = fs.readFileSync(new URL("../dist/worker-single.js", import.meta.url), "utf8");
  assert.equal(fs.readFileSync(new URL("../../DEPLOY-FILES/1-worker-code.js", import.meta.url), "utf8"), dist);
  assert.equal(fs.readFileSync(new URL("../../DEPLOY-FILES/2-database-tables.sql", import.meta.url), "utf8"), fs.readFileSync(new URL("../schema.sql", import.meta.url), "utf8"));
  for (const marker of ["adjustBalance", "withdrawalAct", "ADMIN_HTML", "mutateUser", "decideAdEvent", "parsePrice"]) assert.ok(dist.includes(marker), marker);
  const before = dist; execFileSync(process.execPath, [new URL("../../scripts/build-worker-single.mjs", import.meta.url).pathname]);
  assert.equal(fs.readFileSync(new URL("../dist/worker-single.js", import.meta.url), "utf8"), before, "build is deterministic");
});
