import test from "node:test"; import assert from "node:assert/strict";
import { world } from "./helpers.js";
const MIN = 60e3;
const hit = async (w, params, t = w.now) => { const r = await w.req((await w.ad.url(params, t)).replace("https://api.test", ""), { method: "GET" }); return { status: r.status, body: await r.text() }; };

test("genuine signed callback grants one 10-minute boost; mining uses the doubled rate only inside it", async () => {
  const w = await world(); await w.call("startMining", {});
  const r = await hit(w, { transaction_id: "T1", user_id: "uid_alice" }); assert.equal(r.status, 200);
  let s = (await w.call("getState", {})).data; assert.equal(s.boost.count, 1);
  w.now += 70 * MIN; s = (await w.call("getState", {})).data;
  assert.equal(s.balanceUnits, 16668 + Math.floor((10 * MIN * 16668) / 3600e3));   // 1 h base + 10 extra minutes at base = doubled for 10 min
  assert.equal(w.rows("SELECT status FROM ad_events")[0].status, "granted");
});
test("replayed callback (same transaction_id) never grants a second boost", async () => {
  const w = await world(); await w.call("startMining", {});
  await hit(w, { transaction_id: "T1", user_id: "uid_alice" }); await hit(w, { transaction_id: "T1", user_id: "uid_alice" });
  assert.equal((await w.call("getState", {})).data.boost.count, 1); assert.equal(w.rows("SELECT * FROM ad_events").length, 1);
});
test("parallel duplicate callbacks grant exactly one boost", async () => {
  const w = await world(); await w.call("startMining", {});
  const url = (await w.ad.url({ transaction_id: "T9", user_id: "uid_alice" }, w.now)).replace("https://api.test", "");
  await Promise.all([w.req(url, { method: "GET" }), w.req(url, { method: "GET" }), w.req(url, { method: "GET" })]);
  assert.equal((await w.call("getState", {})).data.boost.count, 1);
});
test("maximum 10 verified boosts per day; the 11th is recorded as rejected", async () => {
  const w = await world(); await w.call("startMining", {});
  for (let i = 0; i < 11; i++) await hit(w, { transaction_id: "C" + i, user_id: "uid_alice" });
  assert.equal((await w.call("getState", {})).data.boost.count, 10);
  assert.equal(w.rows("SELECT * FROM ad_events WHERE status='rejected_daily_cap'").length, 1);
});
test("forged / unsigned / wrong-unit / stale / unknown-user callbacks grant nothing", async () => {
  const w = await world(); await w.call("startMining", {});
  const good = (await w.ad.url({ transaction_id: "F1", user_id: "uid_alice" }, w.now)).replace("https://api.test", "");
  assert.equal((await w.req(good.replace("user_id=uid_alice", "user_id=uid_other"), { method: "GET" })).status, 400);   // tampered after signing
  assert.equal((await w.req("/adReward?user_id=uid_alice&transaction_id=F2", { method: "GET" })).status, 400);           // unsigned
  assert.equal((await hit(w, { transaction_id: "F3", user_id: "uid_alice", ad_unit: "123" })).status, 400);              // someone else's ad unit
  assert.equal((await hit(w, { transaction_id: "F4", user_id: "uid_alice" }, w.now - 20 * MIN)).status, 400);            // stale
  await hit(w, { transaction_id: "F5", user_id: "uid_ghost" });                                                           // no such user
  assert.equal((await w.call("getState", {})).data.boost.count, 0);
  assert.equal(w.rows("SELECT * FROM ad_events WHERE status='granted'").length, 0);
});
test("with no ad unit configured every callback is refused", async () => {
  const w = await world({ env: { ADMOB_REWARDED_AD_UNIT_ID: "" } }); await w.call("startMining", {});
  assert.equal((await hit(w, { transaction_id: "N1", user_id: "uid_alice" })).status, 400);
  assert.equal((await w.call("getState", {})).data.boost.count, 0);
});
test("the rate never exceeds the 0.000947/h ceiling, boosted or not", async () => {
  const { BOOST_UNITS_PER_HOUR } = await import("../src/lib/mining.js"); assert.ok(BOOST_UNITS_PER_HOUR <= 94700); assert.equal(BOOST_UNITS_PER_HOUR, 33336);
});
