// LOCAL end-to-end server for the browser test: the REAL Worker code (src/index.js) on node:sqlite, with a fake Firebase signer.
// Not Cloudflare, not Firebase. Prints the port and the public JWK-signed token endpoint used by the fake Firebase SDK in the test page.
import http from "node:http";
import { world } from "./helpers.js";
const w = await world(); w.now = Date.now();
const srv = http.createServer(async (req, res) => {
  const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "*", "access-control-allow-methods": "*" };
  if (req.method === "OPTIONS") { res.writeHead(204, cors); return res.end(); }
  const u = new URL(req.url, "http://x");
  if (u.pathname === "/__token") { const claims = JSON.parse(u.searchParams.get("claims") || "{}"); res.writeHead(200, cors); return res.end(await w.fb.token(claims, w.now)); }
  if (u.pathname === "/__control") {   // test-only knobs: move the server clock, make rows, kill the DB
    const c = JSON.parse(u.searchParams.get("c")); if (c.advance) w.now += c.advance; if (c.dropTable) w.db.raw.exec("DROP TABLE " + c.dropTable);
    if (c.sql) w.db.raw.exec(c.sql); res.writeHead(200, cors); return res.end(JSON.stringify({ now: w.now, rows: c.query ? w.rows(c.query) : [] }));
  }
  const body = await new Promise((r) => { const a = []; req.on("data", (d) => a.push(d)); req.on("end", () => r(Buffer.concat(a))); });
  const r = await w.req(u.pathname + u.search, { method: req.method, token: (req.headers.authorization || "").replace(/^Bearer /, ""), body: body.length ? JSON.parse(body) : {}, headers: {} });
  res.writeHead(r.status, { ...Object.fromEntries(r.headers), ...cors }); res.end(await r.text());
});
srv.listen(0, "127.0.0.1", () => console.log("PORT " + srv.address().port));
