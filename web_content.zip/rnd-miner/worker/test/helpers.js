// Test helpers: a D1-compatible database over node:sqlite (real SQLite engine and real schema.sql), a fake Firebase signer
// (self-generated RSA key, NOT Google's), and a fake AdMob signer. These are LOCAL tests, not tests against Cloudflare or Firebase.
import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import { handle } from "../src/index.js";
import { _resetJwksCache } from "../src/lib/auth.js";
import { _resetAdKeys } from "../src/index.js";

const tick = () => new Promise((r) => setImmediate(r));
export function makeD1() {
  const db = new DatabaseSync(":memory:");
  db.exec(fs.readFileSync(new URL("../schema.sql", import.meta.url), "utf8"));
  const wrap = (sql, params = []) => ({
    bind: (...p) => wrap(sql, p),
    async first() { await tick(); return db.prepare(sql).get(...params) ?? null; },
    async all() { await tick(); return { results: db.prepare(sql).all(...params) }; },
    async run() { await tick(); const r = db.prepare(sql).run(...params); return { meta: { changes: Number(r.changes) } }; },
    _exec() { const r = db.prepare(sql).run(...params); return { meta: { changes: Number(r.changes) } }; },
  });
  return {
    raw: db,
    prepare: (sql) => wrap(sql),
    async batch(stmts) {   // D1 semantics: one transaction, all or nothing
      await tick();
      db.exec("BEGIN");
      try { const out = stmts.map((s) => s._exec()); db.exec("COMMIT"); return out; }
      catch (e) { db.exec("ROLLBACK"); throw e; }
    },
  };
}

const b64u = (b) => Buffer.from(b).toString("base64url");
export async function makeFirebase(projectId = "test-project") {
  const kp = await crypto.subtle.generateKey({ name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["sign", "verify"]);
  const jwk = { ...(await crypto.subtle.exportKey("jwk", kp.publicKey)), kid: "k1", alg: "RS256", use: "sig" };
  return {
    projectId, jwk,
    async token(claims = {}, now = Date.now(), opts = {}) {
      const s = Math.floor(now / 1000);
      const payload = { iss: "https://securetoken.google.com/" + projectId, aud: projectId, sub: "uid_alice", auth_time: s - 10, iat: s - 10, exp: s + 3600, email: "alice@example.com", email_verified: true, ...claims };
      const h = b64u(JSON.stringify({ alg: "RS256", kid: opts.kid || "k1", typ: "JWT" })), p = b64u(JSON.stringify(payload));
      const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", opts.key || kp.privateKey, new TextEncoder().encode(h + "." + p));
      return h + "." + p + "." + b64u(sig);
    },
    privateKey: kp.privateKey,
  };
}

export function rawToDer(raw) {
  const enc = (x) => { let i = 0; while (i < x.length - 1 && x[i] === 0) i++; x = x.slice(i); if (x[0] & 0x80) x = Uint8Array.from([0, ...x]); return Uint8Array.from([0x02, x.length, ...x]); };
  const r = enc(raw.slice(0, 32)), s = enc(raw.slice(32));
  return Uint8Array.from([0x30, r.length + s.length, ...r, ...s]);
}
export async function makeAdmob() {
  const kp = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
  const spki = Buffer.from(await crypto.subtle.exportKey("spki", kp.publicKey)).toString("base64");
  const keys = { keys: [{ keyId: 4242, pem: "-----BEGIN PUBLIC KEY-----\n" + spki.match(/.{1,64}/g).join("\n") + "\n-----END PUBLIC KEY-----", base64: spki }] };
  return {
    keys,
    async url(params, now) {
      const q = new URLSearchParams({ ad_network: "1", ad_unit: "999", reward_amount: "1", reward_item: "boost", timestamp: String(now), ...params }).toString();
      const raw = new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, kp.privateKey, new TextEncoder().encode(q)));
      return "https://api.test/adReward?" + q + "&signature=" + b64u(rawToDer(raw)) + "&key_id=4242";
    },
  };
}

/** Whole fake world: D1 + Firebase signer + controllable clock + fake Google/CoinGecko fetch. */
export async function world(opts = {}) {
  _resetJwksCache(); _resetAdKeys();
  const fb = await makeFirebase(), ad = await makeAdmob(), db = makeD1();
  const w = {
    db, fb, ad, now: Date.UTC(2026, 9, 14, 8, 0, 0),   // Wed 14 Oct 2026 08:00 UTC
    price: { pkr: 3, updated: null }, fetchLog: [],
    env: { DB: db, FIREBASE_PROJECT_ID: fb.projectId, ADMOB_REWARDED_AD_UNIT_ID: "999", ADMIN_TOKEN: "a".repeat(40), ALLOWED_ORIGINS: "*", ...opts.env },
  };
  w.fetch = async (url) => {
    url = String(url); w.fetchLog.push(url);
    if (url.includes("securetoken@system.gserviceaccount.com")) return new Response(JSON.stringify({ keys: [fb.jwk] }), { headers: { "cache-control": "max-age=3600" } });
    if (url.includes("verifier-keys.json")) return new Response(JSON.stringify(ad.keys));
    if (url.includes("coingecko")) { if (w.price.down) return new Response("no", { status: 500 }); return new Response(JSON.stringify({ "render-token": { pkr: w.price.pkr, last_updated_at: Math.floor((w.price.updated ?? w.now) / 1000) } })); }
    throw new Error("unexpected fetch " + url);
  };
  w.req = (path, { token, body, method = "POST", headers = {} } = {}) => handle(new Request("https://api.test" + path, { method, headers: { "content-type": "application/json", ...(token ? { authorization: "Bearer " + token } : {}), ...headers }, body: method === "GET" ? undefined : JSON.stringify(body || {}) }), w.env, { now: () => w.now, fetch: w.fetch });
  w.call = async (name, body, claims) => { const r = await w.req("/api/" + name, { token: await fb.token(claims, w.now), body }); return { status: r.status, ...(await r.json()) }; };
  w.get = (path) => w.req(path, { method: "GET" });
  w.admin = async (path, body, token = w.env.ADMIN_TOKEN) => { const r = await w.req(path, { token, body }); return { status: r.status, ...(await r.json()) }; };
  w.rows = (sql, ...p) => db.raw.prepare(sql).all(...p);
  return w;
}
