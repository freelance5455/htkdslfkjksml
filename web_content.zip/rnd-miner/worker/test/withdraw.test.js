import test from "node:test"; import assert from "node:assert/strict";
import { world } from "./helpers.js";
const eps = { method: "EasyPaisa", accountName: "Ali Khan", accountNumber: "03001234567" };
async function funded(units = 5e9) { const w = await world(); await w.call("getState", {}); w.db.raw.prepare("UPDATE users SET balance_units=? WHERE uid='uid_alice'").run(units); return w; }   // test setup only: mining alone would take years to reach the 0.07 RENDER minimum
const req = (w, id, amount, extra = eps) => w.call("requestWithdrawal", { requestId: id, amount, ...extra });

test("withdrawal is stored with user, amount, currency, destination, time, status, reference and the balance is held", async () => {
  const w = await funded(); const r = await req(w, "req-0000001", 20);
  assert.equal(r.ok, true); assert.equal(r.data.status, "requested"); assert.equal(r.data.amountPkr, undefined); assert.equal(w.fetchLog.filter((u) => u.includes("coingecko")).length, 0);   // no price lookup at all
  const row = w.rows("SELECT * FROM withdrawals")[0];
  assert.equal(row.uid, "uid_alice"); assert.equal(row.currency, "RENDER"); assert.equal(row.amount_units, 20e8); assert.equal(row.status, "requested");
  assert.equal(row.request_id, "req-0000001"); assert.equal(row.requested_at, w.now); assert.deepEqual(JSON.parse(row.destination), { accountName: "Ali Khan", accountNumber: "03001234567" }); assert.equal(row.payout_ref, null);
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9 - 20e8);
  const st = (await w.call("getState", { withdrawals: true })).data; assert.equal(st.withdrawals.length, 1); assert.equal(st.withdrawals[0].status, "requested");
});
test("same requestId twice = one deduction (idempotent)", async () => {
  const w = await funded(); await req(w, "req-0000002", 20); const r = await req(w, "req-0000002", 20);
  assert.equal(r.data.duplicate, true); assert.equal(w.rows("SELECT * FROM withdrawals").length, 1); assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9 - 20e8);
});
test("parallel requests with different ids: only one opens, balance deducted once", async () => {
  const w = await funded(); const [a, b] = await Promise.all([req(w, "req-par-0001", 20), req(w, "req-par-0002", 20)]);
  assert.equal([a, b].filter((x) => x.ok).length, 1); assert.equal(w.rows("SELECT * FROM withdrawals").length, 1); assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9 - 20e8);
});
test("insufficient balance, below minimum, bad destination, bad id are all refused with clear codes", async () => {
  const w = await funded(1e8);
  assert.equal((await req(w, "req-0000003", 20)).error.message, "insufficient_balance");
  assert.match((await req(w, "req-0000004", 0.06)).error.message, /below_minimum:0.07/);
  assert.equal((await req(w, "req-0000005", 1, { method: "EasyPaisa", accountName: "A", accountNumber: "123" })).error.message, "invalid_easypaisa_number");
  assert.equal((await req(w, "req-0000006", 1, { method: "Binance", binanceUID: "abc" })).error.message, "invalid_binance_uid");
  assert.equal((await req(w, "x", 1)).error.message, "invalid_request_id");
  assert.equal(w.rows("SELECT * FROM withdrawals").length, 0); assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 1e8);
});
test("negative / NaN / absurd amounts cannot mint balance", async () => {
  const w = await funded(); for (const a of [-5, "-1", "abc", null, 1e30, Infinity]) { const r = await req(w, "req-neg-" + String(a).length + Math.abs(Number(a) || 0), a); assert.equal(r.ok, false); }
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9);
});
test("price service DOWN (HTTP 500) does not block a valid withdrawal; no CoinGecko call is made", async () => {
  const w = await funded(); w.price.down = true; const r = await req(w, "req-0000007", 20);
  assert.equal(r.ok, true); assert.equal(r.data.status, "requested");
  assert.equal(w.fetchLog.filter((u) => u.includes("coingecko")).length, 0);
  const row = w.rows("SELECT * FROM withdrawals")[0]; assert.equal(row.amount_units, 20e8); assert.equal(row.render_pkr_at_request, 0);
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9 - 20e8); assert.equal(w.rows("SELECT * FROM ledger WHERE type='withdrawal_hold'").length, 1);
});
test("price service completely unreachable (network error / stale price) does not block Binance or EasyPaisa", async () => {
  for (const extra of [eps, { method: "Binance", binanceUID: "123456789" }]) {
    const w = await funded(); const f = w.fetch; w.fetch = async (u) => { if (String(u).includes("coingecko")) throw new Error("network down"); return f(u); };
    // rebuild request path with the broken fetch
    const r = await w.req("/api/requestWithdrawal", { token: await w.fb.token({}, w.now), body: { requestId: "req-net-" + extra.method, amount: 0.07, ...extra } }); const j = await r.json();
    assert.equal(j.ok, true, JSON.stringify(j)); assert.equal(w.rows("SELECT * FROM withdrawals").length, 1);
  }
});
test("with the price service down, all other checks still apply (duplicate, open request, balance, minimum)", async () => {
  const w = await funded(1e9); w.price.down = true;
  assert.equal((await req(w, "req-dn-000001", 5)).ok, true);
  assert.equal((await req(w, "req-dn-000001", 5)).data.duplicate, true);                              // same id: no second deduction
  assert.equal((await req(w, "req-dn-000002", 5)).error.message, "withdrawal_already_open");           // one open request at a time
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 1e9 - 5e8);
  const w2 = await funded(1e8); w2.price.down = true;
  assert.equal((await req(w2, "req-dn-000003", 20)).error.message, "insufficient_balance");
  assert.match((await req(w2, "req-dn-000004", 0.06)).error.message, /below_minimum:0.07/);
  assert.equal((await w2.req("/api/requestWithdrawal", { body: { requestId: "req-dn-000005", amount: 1, ...eps } })).status, 401);   // auth still required
  assert.equal(w2.rows("SELECT * FROM withdrawals").length, 0);
});
test("history: legacy rows keep their PKR snapshot; new RENDER-only rows report none", async () => {
  const w = await funded(); await w.call("getState", {});
  w.db.raw.prepare("INSERT INTO withdrawals (uid,request_id,method,destination,amount_units,amount_pkr,render_pkr_at_request,price_source_updated_at,status,requested_at) VALUES ('uid_alice','legacy-0001','Binance','{}',1000000000,30,3,1,'paid',1)").run();
  await req(w, "req-new-00001", 0.07);
  const h = (await w.call("getState", { withdrawals: true })).data.withdrawals;
  assert.equal(h.find((x) => x.requestId === "legacy-0001").amountPkr, 30); assert.equal(h.find((x) => x.requestId === "req-new-00001").amountPkr, null);
});
test("Binance destination accepted", async () => { const w = await funded(); const r = await req(w, "req-0000008", 20, { method: "Binance", binanceUID: "123456789" }); assert.equal(r.ok, true); });

test("admin: needs the owner token; disabled when unset", async () => {
  const w = await funded(); await req(w, "req-0000009", 20);
  assert.equal((await w.admin("/admin/withdrawals/list", {}, "wrong".repeat(10))).status, 403);
  assert.equal((await w.req("/admin/withdrawals/list", { token: await w.fb.token(), body: {} })).status, 403);   // a normal user's Firebase token is NOT admin
  const w2 = await world({ env: { ADMIN_TOKEN: "" } }); assert.equal((await w2.admin("/admin/withdrawals/list", {}, "x".repeat(40))).error.message, "admin_disabled");
  const l = await w.admin("/admin/withdrawals/list", {}); assert.equal(l.data.length, 1); assert.equal(l.data[0].destination.accountNumber, "03001234567");
});
test("a user cannot mark their own withdrawal paid; paid only via admin, with a reference, on Sat/Sun PKT", async () => {
  const w = await funded(); await req(w, "req-0000010", 20);
  assert.equal((await w.call("markpaid", { requestId: "req-0000010" })).error.code, "not-found");
  const act = (action, extra = {}) => w.admin("/admin/withdrawals/act", { action, uid: "uid_alice", requestId: "req-0000010", ...extra });
  assert.equal((await act("approve")).data.status, "approved");
  assert.equal((await act("markpaid", { payoutRef: "TX123456" })).error.message, "payouts_only_sat_sun_pkt");        // Wednesday
  w.now = Date.UTC(2026, 9, 17, 8, 0, 0);                                                                              // Saturday
  assert.equal((await act("markpaid", { payoutRef: "" })).error.message, "payout_reference_required");
  assert.equal((await act("markpaid", { payoutRef: "TX123456" })).data.status, "paid");
  const row = w.rows("SELECT * FROM withdrawals")[0]; assert.equal(row.status, "paid"); assert.equal(row.payout_ref, "TX123456"); assert.equal(row.paid_at, w.now);
  assert.equal((await act("approve")).error.message, "cannot_go_paid_to_approved");
  assert.equal((await act("reject")).error.message, "cannot_go_paid_to_rejected");                                      // paid is final
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9 - 20e8);                                           // no refund after payment
});
test("reject refunds the held amount exactly once, even if clicked twice at the same time", async () => {
  const w = await funded(); await req(w, "req-0000011", 20);
  const act = () => w.admin("/admin/withdrawals/act", { action: "reject", uid: "uid_alice", requestId: "req-0000011", note: "wrong account" });
  const [a, b] = await Promise.all([act(), act()]);
  assert.equal([a, b].filter((x) => x.ok).length, 1);
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9);
  assert.equal(w.rows("SELECT * FROM ledger WHERE type='withdrawal_refund'").length, 1);
  assert.equal(w.rows("SELECT status FROM withdrawals")[0].status, "rejected");
  assert.equal((await req(w, "req-0000012", 20)).ok, true);   // a new request is possible after rejection
});
test("a requested (not yet approved) withdrawal cannot jump straight to paid", async () => {
  const w = await funded(); await req(w, "req-0000013", 20); w.now = Date.UTC(2026, 9, 17, 8, 0, 0);
  assert.equal((await w.admin("/admin/withdrawals/act", { action: "markpaid", uid: "uid_alice", requestId: "req-0000013", payoutRef: "TX999999" })).error.message, "cannot_go_requested_to_paid");
});

/* ---- minimum withdrawal = 0.07 RENDER, locked until the server-verified balance reaches it ---- */
test("minimum is a fixed 0.07 RENDER and does not depend on the PKR price", async () => {
  for (const pkr of [0.5, 3, 900]) {
    const w = await funded(); w.price.pkr = pkr;
    assert.equal((await w.call("getPrice", {})).data.minRender, 0.07);
    assert.match((await req(w, "req-min-below1", 0.0699)).error.message, /^below_minimum:0\.07$/);
    assert.equal((await req(w, "req-min-exact1", 0.07)).ok, true);
    assert.equal(w.rows("SELECT amount_units a FROM withdrawals")[0].a, 7000000);
    assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 5e9 - 7000000);
  }
});
test("0.069999 RENDER balance is locked; 0.07 unlocks; getState reports it from the server", async () => {
  const w = await funded(6999999);
  const s1 = (await w.call("getState", {})).data; assert.equal(s1.withdrawUnlocked, false); assert.equal(s1.minWithdrawUnits, 7000000);
  assert.equal((await req(w, "req-lock-0001", 0.07)).error.message, "withdrawal_locked:0.07");
  assert.equal(w.rows("SELECT * FROM withdrawals").length, 0); assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 6999999);
  w.db.raw.prepare("UPDATE users SET balance_units=7000000 WHERE uid='uid_alice'").run();
  assert.equal((await w.call("getState", {})).data.withdrawUnlocked, true);
  const r = await req(w, "req-lock-0002", 0.07); assert.equal(r.ok, true);
  assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 0);
});
test("the minimum is enforced by the Worker itself (a forged client cannot skip it), for Binance and EasyPaisa", async () => {
  const w = await funded(1e8);
  for (const extra of [eps, { method: "Binance", binanceUID: "123456789" }]) {
    assert.match((await req(w, "req-forge-" + extra.method, 0.00000001, extra)).error.message, /below_minimum:/);
    assert.match((await req(w, "req-forge2-" + extra.method, 0.05, extra)).error.message, /below_minimum:/);
  }
  assert.equal(w.rows("SELECT * FROM withdrawals").length, 0); assert.equal(w.rows("SELECT balance_units b FROM users")[0].b, 1e8);
});
test("below the minimum is refused even when the price service is down (no price needed for the lock)", async () => {
  const w = await funded(); w.price.down = true;
  assert.match((await req(w, "req-down-0001", 0.01)).error.message, /below_minimum:/);
});
