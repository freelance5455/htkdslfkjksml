// Data layer over Cloudflare D1. Every balance-changing write is an ATOMIC batch that only takes effect if the user row is still
// at the version we read (optimistic concurrency). A concurrent request makes the guard fail and we re-read and re-decide, so two
// parallel requests can never both spend, credit or start the same thing. All times are server time passed in by the caller.
import * as C from "./lib/constants.js";
import * as M from "./lib/mining.js";

export class ApiError extends Error { constructor(code, message) { super(message); this.code = code; this.msg = message; } }
export const fail = (code, message) => new ApiError(code, message);

const nonce = () => { const b = new Uint8Array(12); crypto.getRandomValues(b); return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join(""); };
export const newId = () => { const b = new Uint8Array(15); crypto.getRandomValues(b); return Array.from(b, (x) => x.toString(36).padStart(2, "0")).join("").slice(0, 20); };

export function newProfile(uid, user, now) {
  return {
    isNew: true, version: 0, uid, email: user.email || "", displayName: user.name || (user.email ? user.email.split("@")[0] : "Miner"),
    createdAt: now, balanceUnits: 0, totalEarnedUnits: 0, mining: { status: "idle" }, boost: { endsAt: 0, day: "", count: 0, segments: [] },
  };
}
export function rowToUser(r) {
  let segs = []; try { segs = JSON.parse(r.boost_segments || "[]"); } catch { segs = []; }
  return {
    isNew: false, version: r.version, uid: r.uid, email: r.email, displayName: r.display_name, createdAt: r.created_at,
    balanceUnits: r.balance_units, totalEarnedUnits: r.total_earned_units,
    mining: r.mining_status === "active"
      ? { status: "active", sessionId: r.session_id, startedAt: r.started_at, endsAt: r.ends_at, creditedUnits: r.credited_units, lastSettledAt: r.last_settled_at }
      : { status: "idle" },
    boost: { endsAt: r.boost_ends_at, day: r.boost_day, count: r.boost_count, segments: segs },
  };
}
const mcols = (u) => {
  const m = u.mining && u.mining.status === "active" ? u.mining : null;
  return [m ? "active" : "idle", m ? m.sessionId : null, m ? m.startedAt : null, m ? m.endsAt : null, m ? m.creditedUnits : 0, m ? m.lastSettledAt : null];
};

export const st = (db, sql, ...p) => db.prepare(sql).bind(...p);

/** Settle mining in memory and queue the DB rows for a finished session. Mutates and returns u. */
export function applySettlement(u, g, now) {
  const segs = M.pruneSegments(u.boost && u.boost.segments, now, M.activeStart(u.mining));
  const r = M.settle(u.mining, segs, now);
  if (r.creditUnits > 0) { u.balanceUnits += r.creditUnits; u.totalEarnedUnits += r.creditUnits; }
  u.mining = r.mining;
  u.boost = { ...(u.boost || {}), segments: segs };
  if (r.finished && u.mining.sessionId) {
    const sid = u.mining.sessionId;
    g.run("UPDATE sessions SET status='finished', credited_units=?, finished_at=? WHERE id=? AND uid=? AND @G", [u.mining.creditedUnits, now, sid, u.uid]);
    g.insert("ledger", { uid: u.uid, at: now, type: "mining_session", units: u.mining.creditedUnits, balance_after_units: u.balanceUnits, session_id: sid });
    u.mining = { status: "idle" };
  }
  return u;
}

/**
 * Read the user (or a new profile), let `fn(u, g)` decide + queue extra statements, then commit atomically.
 * `g.insert(table,row)` / `g.run(sqlWithAtG, params)` add statements that run ONLY if this write wins the version check.
 * fn may throw ApiError: nothing is written. Returns whatever fn returns.
 */
export async function mutateUser(db, user, now, fn) {
  for (let attempt = 0; attempt < 6; attempt++) {
    const row = await db.prepare("SELECT * FROM users WHERE uid = ?").bind(user.uid).first();
    const u = row ? rowToUser(row) : newProfile(user.uid, user, now);
    const tok = nonce(), extras = [];
    const guardSql = "EXISTS (SELECT 1 FROM users WHERE uid = ? AND token = ?)";
    const g = {
      insert(table, rowObj) {
        const cols = Object.keys(rowObj);
        extras.push(st(db, `INSERT INTO ${table} (${cols.join(",")}) SELECT ${cols.map(() => "?").join(",")} WHERE ${guardSql}`, ...cols.map((c) => rowObj[c]), u.uid, tok));
      },
      run(sql, params) { extras.push(st(db, sql.replace("@G", guardSql), ...params, u.uid, tok)); },
    };
    const out = await fn(u, g);
    const mc = mcols(u), seg = JSON.stringify((u.boost && u.boost.segments) || []);
    const main = u.isNew
      ? st(db, `INSERT INTO users (uid,email,display_name,created_at,balance_units,total_earned_units,mining_status,session_id,started_at,ends_at,credited_units,last_settled_at,boost_ends_at,boost_day,boost_count,boost_segments,version,token)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?) ON CONFLICT(uid) DO NOTHING`,
          u.uid, u.email, u.displayName, u.createdAt, u.balanceUnits, u.totalEarnedUnits, ...mc, u.boost.endsAt || 0, u.boost.day || "", u.boost.count || 0, seg, tok)
      : st(db, `UPDATE users SET email=?, display_name=?, balance_units=?, total_earned_units=?, mining_status=?, session_id=?, started_at=?, ends_at=?, credited_units=?, last_settled_at=?,
                boost_ends_at=?, boost_day=?, boost_count=?, boost_segments=?, version=version+1, token=? WHERE uid=? AND version=?`,
          u.email, u.displayName, u.balanceUnits, u.totalEarnedUnits, ...mc, u.boost.endsAt || 0, u.boost.day || "", u.boost.count || 0, seg, tok, u.uid, u.version);
    const res = await db.batch([main, ...extras]);   // atomic: all statements apply, or none (a constraint error rolls everything back)
    if (res[0].meta.changes === 1) return out;
    // someone else changed this user between our read and write: nothing of ours was applied. Re-read and decide again.
  }
  throw fail("aborted", "backend_busy");
}

/** One-statement fixed-window limiter in the database (atomic, shared by every Worker instance). */
export async function limitDb(db, key, limit, windowMs, now) {
  const r = await db.prepare(
    `INSERT INTO rate_limits (key, window_start, count) VALUES (?1, ?2, 1)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN ?2 - window_start >= ?3 THEN 1 ELSE count + 1 END,
       window_start = CASE WHEN ?2 - window_start >= ?3 THEN ?2 ELSE window_start END
     RETURNING count, window_start`).bind(key, now, windowMs).first();
  if (r.count > limit) throw fail("resource-exhausted", `rate_limited:${Math.ceil((windowMs - (now - r.window_start)) / 1000)}`);
}

const memBuckets = new Map();
/** Best-effort per-instance limiter for cheap read paths (no database writes). */
export function limitMem(key, limit, windowMs, now) {
  const r = memBuckets.get(key);
  const live = r && now - r.at < windowMs;
  const next = { at: live ? r.at : now, n: (live ? r.n : 0) + 1 };
  if (next.n > limit) throw fail("resource-exhausted", `rate_limited:${Math.ceil((windowMs - (now - next.at)) / 1000)}`);
  memBuckets.set(key, next);
  if (memBuckets.size > 5000) for (const [k, v] of memBuckets) { if (now - v.at > windowMs) memBuckets.delete(k); }
}

export function publicState(u, now, extra) {
  return {
    serverNow: now,
    profile: { uid: u.uid, email: u.email, displayName: u.displayName },
    balanceUnits: u.balanceUnits, totalEarnedUnits: u.totalEarnedUnits,
    minWithdrawUnits: C.MIN_WITHDRAW_UNITS, withdrawUnlocked: u.balanceUnits >= C.MIN_WITHDRAW_UNITS,   // informational; requestWithdrawal re-checks on the server
    mining: u.mining && u.mining.status === "active" ? { status: "active", startedAt: u.mining.startedAt, endsAt: u.mining.endsAt, creditedUnits: u.mining.creditedUnits || 0 } : { status: "idle" },
    boost: { endsAt: (u.boost && u.boost.endsAt) || 0, count: u.boost && u.boost.day === M.pktDay(now) ? u.boost.count : 0, max: C.MAX_BOOSTS_PER_DAY, segments: (u.boost && u.boost.segments) || [] },
    ...extra,
  };
}

export async function recentWithdrawals(db, uid) {
  const { results } = await db.prepare("SELECT * FROM withdrawals WHERE uid = ? ORDER BY requested_at DESC LIMIT 50").bind(uid).all();
  return results.map((w) => ({
    requestId: w.request_id, method: w.method, currency: w.currency, amountRender: w.amount_units / C.UNITS_PER_RENDER, amountPkr: w.render_pkr_at_request > 0 ? w.amount_pkr : null, status: w.status,
    requestedAt: w.requested_at, approvedAt: w.approved_at || null, paidAt: w.paid_at || null, rejectedAt: w.rejected_at || null, payoutRef: w.payout_ref || null,
  }));
}
export async function recentLedger(db, uid) {
  const { results } = await db.prepare("SELECT at,type,units,balance_after_units,session_id,request_id FROM ledger WHERE uid = ? ORDER BY id DESC LIMIT 50").bind(uid).all();
  return results.map((l) => ({ at: l.at, type: l.type, amountRender: l.units / C.UNITS_PER_RENDER, balanceAfterRender: l.balance_after_units / C.UNITS_PER_RENDER, sessionId: l.session_id, requestId: l.request_id }));
}
