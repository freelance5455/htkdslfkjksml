// RND Miner trusted backend: Cloudflare Worker + D1. Replaces the Firebase Cloud Functions (which need the paid Blaze plan).
// Firebase Authentication stays: the app sends its Firebase ID token; the uid ALWAYS comes from the verified token, never from the body.
// POST /api/getState | /api/startMining | /api/getPrice | /api/requestWithdrawal     (Authorization: Bearer <Firebase ID token>)
// GET  /api/health      (no secrets; says whether the database and settings are in place)
// GET  /adReward        (AdMob server-side verification callback; Google-signature checked)
// GET  /admin           (the private Admin Panel page: static, contains no secret)
// POST /admin/stats | users/list | users/get | balance/adjust | adjustments/list | withdrawals/list | withdrawals/search | withdrawals/act | consistency
//                       (Authorization: Bearer <ADMIN_TOKEN>, owner only; never sends CORS headers)
import * as C from "./lib/constants.js";
import * as M from "./lib/mining.js";
import * as W from "./lib/withdraw.js";
import { verifyIdToken, requireVerified, AuthError } from "./lib/auth.js";
import { verifySsv, checkAdUnit } from "./lib/ssv.js";
import * as A from "./admin.js";
import { ApiError, fail, st, newId, mutateUser, applySettlement, limitDb, limitMem, publicState, recentWithdrawals, recentLedger, rowToUser } from "./db.js";

const HTTP = { "invalid-argument": 400, unauthenticated: 401, "permission-denied": 403, "not-found": 404, "already-exists": 409, aborted: 409, "failed-precondition": 412, "resource-exhausted": 429, unavailable: 503, internal: 500 };

function corsHeaders(request, env) {
  const allowed = String((env && env.ALLOWED_ORIGINS) || "*").split(",").map((s) => s.trim());
  const origin = request.headers.get("origin") || "";
  const allow = allowed.includes("*") ? "*" : (allowed.includes(origin) ? origin : "");
  const h = { "access-control-allow-methods": "GET,POST,OPTIONS", "access-control-allow-headers": "authorization,content-type", "access-control-max-age": "86400", vary: "origin" };
  if (allow) h["access-control-allow-origin"] = allow;
  return h;
}
const isAdminPath = (request) => /^\/admin(\/|$)/.test(new URL(request.url).pathname);
// Admin responses never carry CORS headers: only the same-origin admin page can read them.
const json = (request, env, status, body) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", "cache-control": "no-store", "x-content-type-options": "nosniff", ...(isAdminPath(request) ? {} : corsHeaders(request, env)) } });
const ok = (request, env, data) => json(request, env, 200, { ok: true, data });
const errorResponse = (request, env, code, message) => json(request, env, HTTP[code] || 500, { ok: false, error: { code, message } });

/** Any error -> a small, safe, DISTINCT code (the app shows which part failed). Full detail is logged, never sent. */
export function classify(e) {
  if (e instanceof ApiError) return { code: e.code, message: e.msg };
  if (e instanceof AuthError) return { code: e.code === "auth_keys_unreachable" ? "unavailable" : e.code, message: e.message };
  const t = String((e && e.message) || "");
  if (/no such table/i.test(t)) return { code: "failed-precondition", message: "backend_database_missing" };
  if (/no such column|has no column/i.test(t)) return { code: "failed-precondition", message: "backend_schema_outdated" };
  if (/quota|limit exceeded|too many requests|exceeded/i.test(t)) return { code: "resource-exhausted", message: "backend_quota" };
  if (/D1_ERROR|SQLITE|database/i.test(t)) return { code: "unavailable", message: "backend_unavailable" };
  return { code: "internal", message: "backend_error" };
}

function configCheck(env) {
  if (!env || !env.DB) throw fail("failed-precondition", "backend_not_configured:database_binding_missing");
  if (!env.FIREBASE_PROJECT_ID) throw fail("failed-precondition", "backend_not_configured:firebase_project_id_missing");
}
async function authenticate(request, env, now, deps) {
  const m = /^Bearer (.+)$/.exec(request.headers.get("authorization") || "");
  if (!m) throw fail("unauthenticated", "sign_in_required");
  return requireVerified(await verifyIdToken(m[1], env.FIREBASE_PROJECT_ID, now, deps.fetch));
}

/* ---------------- price ---------------- */
async function fetchPrice(env, now, deps) {
  const row = await st(env.DB, "SELECT value FROM system WHERE key='price'").first();
  const cached = row ? JSON.parse(row.value) : null;
  if (cached && now - cached.fetchedAt < C.PRICE_CACHE_MS && now - cached.sourceUpdatedAt <= C.PRICE_MAX_AGE_MS) return cached;
  try {
    const res = await (deps.fetch || fetch)("https://api.coingecko.com/api/v3/simple/price?ids=render-token&vs_currencies=pkr&include_last_updated_at=true", { signal: AbortSignal.timeout(8000), headers: { accept: "application/json" } });
    if (!res.ok) throw new Error("http " + res.status);
    const p = W.parsePrice(await res.json(), now);
    if (!p.ok) throw new Error(p.reason);
    const doc = { renderPkr: p.renderPkr, sourceUpdatedAt: p.sourceUpdatedAt, fetchedAt: now, source: "coingecko:render-token/pkr" };
    await st(env.DB, "INSERT INTO system (key,value) VALUES ('price',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", JSON.stringify(doc)).run();
    return doc;
  } catch (e) {
    console.error("price fetch failed", e && e.message);
    if (cached && now - cached.sourceUpdatedAt <= C.PRICE_MAX_AGE_MS) return cached;   // only while the exchange rate itself is still recent
    throw fail("unavailable", "price_unavailable");
  }
}

/* ---------------- actions ---------------- */
const actions = {
  async getState(ctx) {
    const { env, user, now, data } = ctx;
    limitMem(user.uid + ":getState", 30, 10 * 60 * 1000, now);
    const row = await st(env.DB, "SELECT * FROM users WHERE uid = ?", user.uid).first();
    let u = row ? rowToUser(row) : null;
    // Normal path = ONE read, no write: the balance is settled in memory (credit is cumulative so nothing is lost).
    // A write happens only for a brand-new profile or a session that has just finished.
    let needsWrite = !u;
    if (u) {
      const segs = M.pruneSegments(u.boost.segments, now, M.activeStart(u.mining));
      const r = M.settle(u.mining, segs, now);
      needsWrite = r.finished;
      u = { ...u, mining: r.mining, balanceUnits: u.balanceUnits + r.creditUnits, totalEarnedUnits: u.totalEarnedUnits + r.creditUnits };
      if (r.finished) u.mining = { status: "idle" };
    }
    if (needsWrite) u = await mutateUser(env.DB, user, now, (x, g) => applySettlement(x, g, now));
    const extra = {};
    if (data && data.withdrawals) { extra.withdrawals = await recentWithdrawals(env.DB, user.uid); extra.history = await recentLedger(env.DB, user.uid); }
    return publicState(u, now, extra);
  },

  async startMining(ctx) {
    const { env, user, now } = ctx;
    await limitDb(env.DB, user.uid + ":startMining", 10, 60 * 60 * 1000, now);
    const u = await mutateUser(env.DB, user, now, (x, g) => {
      applySettlement(x, g, now);
      if (x.mining.status === "active") throw fail("already-exists", "session_already_active");   // no overlapping sessions
      const sid = newId();
      x.mining = { status: "active", sessionId: sid, startedAt: now, endsAt: now + C.SESSION_MS, creditedUnits: 0, lastSettledAt: now };
      g.insert("sessions", { id: sid, uid: x.uid, started_at: now, ends_at: now + C.SESSION_MS, status: "active", credited_units: 0 });
      g.insert("audit", { uid: x.uid, type: "mining_started", at: now, data: JSON.stringify({ sessionId: sid }) });
      return x;
    });
    return publicState(u, now);
  },

  async getPrice(ctx) {
    const { env, user, now, deps } = ctx;
    limitMem(user.uid + ":getPrice", 30, 10 * 60 * 1000, now);
    const p = await fetchPrice(env, now, deps);
    return { renderPkr: p.renderPkr, minRender: W.minWithdrawUnits() / C.UNITS_PER_RENDER, asOf: p.sourceUpdatedAt, serverNow: now };
  },

  async requestWithdrawal(ctx) {
    const { env, user, data: d, deps, now: t0 } = ctx;
    const requestId = String(d.requestId || "");
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(requestId)) throw fail("invalid-argument", "invalid_request_id");
    const dest = W.validateDestination(d);
    if (!dest.ok) throw fail("invalid-argument", dest.error);
    const units = W.toUnits(d.amount);
    if (!units) throw fail("invalid-argument", "invalid_amount");
    const minUnits = W.minWithdrawUnits();             // fixed 0.07 RENDER, checked before anything else (no price needed)
    if (units < minUnits) throw fail("failed-precondition", `below_minimum:${minUnits / C.UNITS_PER_RENDER}`);
    await limitDb(env.DB, user.uid + ":requestWithdrawal", 5, 60 * 60 * 1000, t0);
    // No price lookup: a withdrawal is validated in RENDER only. (getPrice below is a separate, optional display feature.)
    const now = t0;
    const out = await mutateUser(env.DB, user, now, async (u, g) => {
      const existing = await st(env.DB, "SELECT * FROM withdrawals WHERE uid=? AND request_id=?", u.uid, requestId).first();
      if (existing) return { duplicate: true, units: existing.amount_units, status: existing.status };   // same requestId again: no second deduction
      const open = await st(env.DB, "SELECT 1 AS x FROM withdrawals WHERE uid=? AND status IN ('requested','approved') LIMIT 1", u.uid).first();
      if (open) throw fail("failed-precondition", "withdrawal_already_open");
      applySettlement(u, g, now);
      // Withdrawals stay locked until the server-verified available balance itself reaches the minimum.
      if (u.balanceUnits < minUnits) throw fail("failed-precondition", `withdrawal_locked:${minUnits / C.UNITS_PER_RENDER}`);
      if (units > u.balanceUnits) throw fail("failed-precondition", "insufficient_balance");
      u.balanceUnits -= units;
      g.insert("withdrawals", { uid: u.uid, request_id: requestId, method: d.method, destination: JSON.stringify(dest.destination), currency: "RENDER", amount_units: units, amount_pkr: 0, render_pkr_at_request: 0, price_source_updated_at: 0, status: "requested", requested_at: now });
      g.insert("ledger", { uid: u.uid, at: now, type: "withdrawal_hold", units: -units, balance_after_units: u.balanceUnits, request_id: requestId });
      g.insert("audit", { uid: u.uid, type: "withdrawal_requested", at: now, data: JSON.stringify({ requestId, units, method: d.method }) });
      return { duplicate: false, units, status: "requested" };
    });
    return { requestId, status: out.status, duplicate: out.duplicate, amountRender: out.units / C.UNITS_PER_RENDER };
  },
};

/* ---------------- AdMob SSV ---------------- */
let adKeyCache = { at: 0, keys: null };
async function adKeys(now, deps) {
  if (adKeyCache.keys && now - adKeyCache.at < 3600e3) return adKeyCache.keys;
  const res = await (deps.fetch || fetch)("https://www.gstatic.com/admob/reward/verifier-keys.json", { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error("keys http " + res.status);
  adKeyCache = { at: now, keys: await res.json() };
  return adKeyCache.keys;
}
export function _resetAdKeys() { adKeyCache = { at: 0, keys: null }; }

async function adReward(request, env, now, deps) {
  const text = (status, body) => new Response(body, { status, headers: { "content-type": "text/plain" } });
  try {
    configCheck(env);
    const v = await verifySsv(new URL(request.url).search, await adKeys(now, deps), now);
    if (!v.ok) return text(400, v.reason);
    const unit = checkAdUnit(env.ADMOB_REWARDED_AD_UNIT_ID, v.params.adUnit);
    if (!unit.ok) return text(400, unit.reason);   // not configured / not OUR ad unit: nothing is granted
    const uid = v.params.userId, txId = v.params.transactionId.replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 100);
    if (await st(env.DB, "SELECT uid FROM ad_events WHERE transaction_id = ?", txId).first()) return text(200, "ok");   // replayed callback
    const urow = await st(env.DB, "SELECT * FROM users WHERE uid = ?", uid).first();
    if (!urow) { await st(env.DB, "INSERT OR IGNORE INTO ad_events (transaction_id,uid,at,status,ad_unit) VALUES (?,?,?,?,?)", txId, uid, now, "rejected_no_user", v.params.adUnit).run(); return text(200, "ok"); }
    try {
      await mutateUser(env.DB, { uid, email: urow.email, name: urow.display_name }, now, (u, g) => {
        const d = M.decideAdEvent({ eventExists: false, userExists: true, boost: u.boost, now });
        if (d.kind !== "grant") { g.insert("ad_events", { transaction_id: txId, uid, at: now, status: d.status, ad_unit: v.params.adUnit }); return u; }
        const gr = d.grant;
        u.boost = { endsAt: gr.boostEndsAt, day: gr.day, count: gr.count, segments: [...M.pruneSegments(u.boost.segments, now, M.activeStart(u.mining)), gr.segment] };
        // PRIMARY KEY on transaction_id: a concurrent duplicate callback makes this insert fail and the whole boost is rolled back.
        g.insert("ad_events", { transaction_id: txId, uid, at: now, status: "granted", ad_unit: v.params.adUnit, boost_from: gr.segment.from, boost_to: gr.segment.to });
        g.insert("audit", { uid, type: "ad_boost_granted", at: now, data: JSON.stringify({ transactionId: txId, count: gr.count }) });
        return u;
      });
    } catch (e) { if (!/UNIQUE|constraint/i.test(String(e && e.message))) throw e; }   // duplicate = replay
    return text(200, "ok");
  } catch (e) { console.error("adReward error", e && e.message); return text(500, "error"); }
}

/* ---------------- router ---------------- */
export async function handle(request, env, deps = {}) {
  const clock = deps.now || (() => Date.now());
  const url = new URL(request.url), path = url.pathname.replace(/\/+$/, "") || "/";
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: isAdminPath(request) ? {} : corsHeaders(request, env) });
  try {
    if (path === "/api/health" && request.method === "GET") {
      const out = { ok: true, service: "rnd-miner-api", serverNow: clock(), firebaseProjectId: !!(env && env.FIREBASE_PROJECT_ID), database: "missing_binding", adUnitConfigured: !!(env && env.ADMOB_REWARDED_AD_UNIT_ID), adminConfigured: !!(env && env.ADMIN_TOKEN && env.ADMIN_TOKEN.length >= 32) };
      if (env && env.DB) { try { await st(env.DB, "SELECT 1 FROM users LIMIT 1").first(); out.database = "ok"; } catch (e) { out.database = /no such table/i.test(String(e.message)) ? "schema_not_applied" : "error"; out.ok = false; } }
      else out.ok = false;
      return json(request, env, out.ok ? 200 : 503, out);
    }
    if (path === "/adReward" && request.method === "GET") return adReward(request, env, clock(), deps);
    if (path === "/admin" && request.method === "GET") return A.pageResponse();
    if (path.startsWith("/admin/") && request.method === "POST") {
      configCheck(env);
      const now = clock();
      await A.adminAuth(request, env, now);
      const body = await request.json().catch(() => ({})) || {};
      const routes = {
        "/admin/stats": () => A.stats(env, now),
        "/admin/users/list": () => A.listUsers(env, now, body),
        "/admin/users/get": () => A.getUser(env, now, body),
        "/admin/balance/adjust": () => A.adjustBalance(env, now, body),
        "/admin/adjustments/list": () => A.listAdjustments(env, body),
        "/admin/withdrawals/list": () => A.listOpenWithdrawals(env),
        "/admin/withdrawals/search": () => A.searchWithdrawals(env, body),
        "/admin/withdrawals/act": () => A.withdrawalAct(env, now, body),
        "/admin/consistency": () => A.consistency(env),
      };
      if (!Object.prototype.hasOwnProperty.call(routes, path)) return errorResponse(request, env, "not-found", "not_found");
      return ok(request, env, await routes[path]());
    }
    const m = /^\/api\/(getState|startMining|getPrice|requestWithdrawal)$/.exec(path);
    if (m && request.method === "POST") {
      configCheck(env);
      const now = clock();                                                // SERVER time: the client never supplies a time
      const user = await authenticate(request, env, now, deps);           // uid comes ONLY from the verified token
      let data = {}; try { data = (await request.json()) || {}; } catch { data = {}; }
      return ok(request, env, await actions[m[1]]({ env, user, now, data, deps }));
    }
    return errorResponse(request, env, "not-found", "not_found");
  } catch (e) {
    const c = classify(e);
    if (!(e instanceof ApiError) && !(e instanceof AuthError)) console.error("request failed:", path, e && e.message, e && e.stack);
    return errorResponse(request, env, c.code, c.message);
  }
}

export default { fetch: (request, env) => handle(request, env) };
