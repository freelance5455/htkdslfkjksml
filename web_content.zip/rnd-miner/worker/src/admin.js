// Owner admin: dashboard, user list/search, balance adjustments, withdrawal management, consistency report.
// Everything here runs on the SERVER. Authorised ONLY by the ADMIN_TOKEN secret (a Firebase login never grants admin).
// All money is integer units (1 RENDER = 1e8 units). Responses carry raw integer `*Units` fields (exact) next to `*Render` numbers.
import * as C from "./lib/constants.js";
import * as M from "./lib/mining.js";
import * as W from "./lib/withdraw.js";
import { ADMIN_HTML } from "./lib/adminpage.js";
import { fail, st, newId, mutateUser, limitDb, rowToUser } from "./db.js";

export const ADJUST_MAX_UNITS = 1000 * C.UNITS_PER_RENDER;      // default safety limit: 1,000 RENDER per adjustment
export const ADMIN_LOCK_FAILS = 5;                              // wrong tokens from one IP ...
export const ADMIN_LOCK_MS = 15 * 60 * 1000;                    // ... lock that IP out for 15 minutes (even with the right token)

/* ---------------- page ---------------- */
/** The admin page: static HTML, no secrets inside. A per-request nonce lets the CSP allow only this page's own script/style. */
export function pageResponse() {
  const b = new Uint8Array(16); crypto.getRandomValues(b);
  const nonce = btoa(String.fromCharCode(...b)).replace(/[^A-Za-z0-9]/g, "");
  return new Response(ADMIN_HTML.split("__NONCE__").join(nonce), {
    status: 200,
    headers: {
      "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff", "x-frame-options": "DENY",
      "referrer-policy": "no-referrer", "cross-origin-opener-policy": "same-origin", "cross-origin-resource-policy": "same-origin",
      "content-security-policy": `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'nonce-${nonce}'; connect-src 'self'; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'`,
    },
  });
}

/* ---------------- authentication ---------------- */
async function constantTimeEqual(a, b) {
  const enc = new TextEncoder(), [x, y] = await Promise.all([crypto.subtle.digest("SHA-256", enc.encode(a)), crypto.subtle.digest("SHA-256", enc.encode(b))]);
  const A = new Uint8Array(x), B = new Uint8Array(y); let r = 0; for (let i = 0; i < A.length; i++) r |= A[i] ^ B[i]; return r === 0;
}
/** Bearer ADMIN_TOKEN, compared in constant time. Per-IP request limit + per-IP lockout after repeated wrong tokens (stored in D1, shared by all Worker instances). */
export async function adminAuth(request, env, now) {
  if (!env.ADMIN_TOKEN || env.ADMIN_TOKEN.length < 32) throw fail("failed-precondition", "admin_disabled");
  const ip = String(request.headers.get("cf-connecting-ip") || "unknown").slice(0, 64);
  await limitDb(env.DB, "admin:req:" + ip, 120, 60 * 1000, now);
  const fkey = "admin:fail:" + ip;
  const row = await st(env.DB, "SELECT window_start, count FROM rate_limits WHERE key = ?", fkey).first();
  if (row && row.count >= ADMIN_LOCK_FAILS && now - row.window_start < ADMIN_LOCK_MS)
    throw fail("resource-exhausted", "admin_locked:" + Math.ceil((ADMIN_LOCK_MS - (now - row.window_start)) / 1000));
  const m = /^Bearer (.+)$/.exec(request.headers.get("authorization") || "");
  if (!m || !(await constantTimeEqual(m[1], env.ADMIN_TOKEN))) {
    await limitDb(env.DB, fkey, 1e9, ADMIN_LOCK_MS, now);        // count the failure (never throws here)
    throw fail("permission-denied", "admin_forbidden");
  }
  if (row) await st(env.DB, "DELETE FROM rate_limits WHERE key = ?", fkey).run();
}

/* ---------------- helpers ---------------- */
const clampInt = (v, def, lo, hi) => { const n = Math.floor(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : def; };
const likeEsc = (s) => s.replace(/[\\%_]/g, "\\$&");
const parseJson = (s, fallback) => { try { return JSON.parse(s); } catch { return fallback; } };
const R = (units) => units / C.UNITS_PER_RENDER;

/** Exact decimal RENDER string -> integer units (no floating point). Max 8 decimals. Returns null when invalid. */
export function parseRender(v, allowZero) {
  const m = /^(\d{1,12})(?:\.(\d{1,8}))?$/.exec(String(v == null ? "" : v).trim());
  if (!m) return null;
  const units = Number(m[1]) * C.UNITS_PER_RENDER + Number((m[2] || "").padEnd(8, "0"));
  if (!Number.isSafeInteger(units) || (units === 0 && !allowZero)) return null;
  return units;
}

function userItem(r, now) {
  const active = r.mining_status === "active";
  return {
    uid: r.uid, email: r.email, displayName: r.display_name, createdAt: r.created_at,
    balanceUnits: r.balance_units, balanceRender: R(r.balance_units), totalEarnedUnits: r.total_earned_units, totalEarnedRender: R(r.total_earned_units),
    miningStatus: active ? (r.ends_at > now ? "mining" : "finished_unsettled") : "idle",   // "finished_unsettled": session over, credit not yet written to the balance
    startedAt: active ? r.started_at : null, endsAt: active ? r.ends_at : null, lastSettledAt: r.last_settled_at || null,
    boostEndsAt: r.boost_ends_at > now ? r.boost_ends_at : 0, boostCountToday: r.boost_day === M.pktDay(now) ? r.boost_count : 0,
  };
}
function wItem(w) {
  return {
    uid: w.uid, email: w.email || "", displayName: w.display_name || "", requestId: w.request_id, status: w.status, method: w.method, currency: w.currency,
    amountUnits: w.amount_units, amountRender: R(w.amount_units), amountPkr: w.render_pkr_at_request > 0 ? w.amount_pkr : null, renderPkrAtRequest: w.render_pkr_at_request > 0 ? w.render_pkr_at_request : null,
    destination: parseJson(w.destination, {}), requestedAt: w.requested_at, approvedAt: w.approved_at || null, paidAt: w.paid_at || null, rejectedAt: w.rejected_at || null,
    payoutRef: w.payout_ref || null, note: w.note || "",
  };
}
const WSEL = "SELECT w.*, u.email AS email, u.display_name AS display_name FROM withdrawals w LEFT JOIN users u ON u.uid = w.uid";
const auditItem = (a) => ({ id: a.id, uid: a.uid, type: a.type, at: a.at, data: parseJson(a.data, {}) });
const ADMIN_AUDIT_TYPES = "('withdrawal_approved','withdrawal_rejected','withdrawal_paid','admin_balance_adjustment')";

/* ---------------- dashboard ---------------- */
export async function stats(env, now) {
  const u = await st(env.DB, `SELECT COUNT(*) AS n, COALESCE(SUM(balance_units),0) AS bal, COALESCE(SUM(total_earned_units),0) AS earned,
      COALESCE(SUM(CASE WHEN mining_status='active' AND ends_at > ?1 THEN 1 ELSE 0 END),0) AS running,
      COALESCE(SUM(CASE WHEN mining_status='active' AND ends_at <= ?1 THEN 1 ELSE 0 END),0) AS unsettled FROM users`, now).first();
  const { results: wr } = await st(env.DB, "SELECT status, COUNT(*) AS n, COALESCE(SUM(amount_units),0) AS units, COALESCE(SUM(amount_pkr),0) AS pkr FROM withdrawals GROUP BY status").all();
  const withdrawals = {};
  for (const s of ["requested", "approved", "paid", "rejected"]) { const r = wr.find((x) => x.status === s); withdrawals[s] = { count: r ? r.n : 0, units: r ? r.units : 0, render: R(r ? r.units : 0), pkr: r ? r.pkr : 0 }; }
  const { results: ar } = await st(env.DB, `SELECT id, uid, type, at, data FROM audit WHERE type IN ${ADMIN_AUDIT_TYPES} ORDER BY id DESC LIMIT 20`).all();
  return {
    serverNow: now, payoutDay: W.isPayoutDay(now),
    users: { total: u.n, miningNow: u.running, finishedAwaitingSettlement: u.unsettled },
    // SETTLED balances only (users.balance_units). Rewards of running sessions that are not written yet are NOT included.
    settledBalanceUnits: u.bal, settledBalanceRender: R(u.bal), totalEarnedUnits: u.earned, totalEarnedRender: R(u.earned),
    withdrawals, recentActions: ar.map(auditItem),
    config: { adUnitConfigured: !!env.ADMOB_REWARDED_AD_UNIT_ID, adjustMaxRender: ADJUST_MAX_UNITS / C.UNITS_PER_RENDER },
  };
}

/* ---------------- users ---------------- */
export async function listUsers(env, now, d) {
  const limit = clampInt(d.limit, 25, 1, 100), offset = clampInt(d.offset, 0, 0, 100000), q = String(d.q || "").trim().slice(0, 100);
  const where = q ? "WHERE uid LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\' OR display_name LIKE ? ESCAPE '\\'" : "";
  const p = q ? Array(3).fill("%" + likeEsc(q) + "%") : [];
  const total = (await st(env.DB, `SELECT COUNT(*) AS n FROM users ${where}`, ...p).first()).n;
  const { results } = await st(env.DB,
    `SELECT uid,email,display_name,created_at,balance_units,total_earned_units,mining_status,started_at,ends_at,last_settled_at,boost_ends_at,boost_day,boost_count FROM users ${where} ORDER BY created_at DESC, uid LIMIT ? OFFSET ?`, ...p, limit, offset).all();
  return { items: results.map((r) => userItem(r, now)), total, limit, offset, hasMore: offset + results.length < total };
}

export async function getUser(env, now, d) {
  const uid = String(d.uid || "").slice(0, 128);
  if (!uid) throw fail("invalid-argument", "bad_admin_request");
  const row = await st(env.DB, "SELECT * FROM users WHERE uid = ?", uid).first();
  if (!row) throw fail("not-found", "no_such_user");
  const u = rowToUser(row), segs = M.pruneSegments(u.boost.segments, now, M.activeStart(u.mining));
  const accrued = M.settle(u.mining, segs, now).creditUnits;      // earned by the running/just-finished session but NOT yet in balance_units
  const { results: led } = await st(env.DB, "SELECT id,at,type,units,balance_after_units,session_id,request_id FROM ledger WHERE uid = ? ORDER BY id DESC LIMIT 50", uid).all();
  const { results: wd } = await st(env.DB, `${WSEL} WHERE w.uid = ? ORDER BY w.requested_at DESC LIMIT 20`, uid).all();
  const { results: adj } = await st(env.DB, "SELECT id, uid, type, at, data FROM audit WHERE uid = ? AND type = 'admin_balance_adjustment' ORDER BY id DESC LIMIT 20", uid).all();
  return {
    serverNow: now, user: userItem(row, now),
    unsettledRewardUnits: accrued, unsettledRewardRender: R(accrued),     // shown separately; the real balance becomes settled + this when settlement runs
    ledger: led.map((l) => ({ id: l.id, at: l.at, type: l.type, units: l.units, render: R(l.units), balanceAfterUnits: l.balance_after_units, balanceAfterRender: R(l.balance_after_units), sessionId: l.session_id, requestId: l.request_id })),
    withdrawals: wd.map(wItem), adjustments: adj.map(auditItem),
  };
}

/* ---------------- balance adjustments ---------------- */
/**
 * add | subtract | set. Computed on the server against the CURRENT settled balance inside the optimistic-concurrency write
 * (mutateUser), so it can never race with mining settlement, withdrawals or another adjustment. The change is one ledger row
 * (type admin_adjustment, signed delta) + one audit row (reason, before, after). `requestId` makes a re-sent request a no-op.
 * Mining state is left untouched; total_earned_units is not changed (an adjustment is not mining income).
 */
export async function adjustBalance(env, now, d) {
  const mode = String(d.mode || ""), uid = String(d.uid || ""), requestId = String(d.requestId || "");
  if (!["add", "subtract", "set"].includes(mode) || !uid || uid.length > 128) throw fail("invalid-argument", "bad_admin_request");
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(requestId)) throw fail("invalid-argument", "invalid_request_id");
  const reason = String(d.reason == null ? "" : d.reason).trim();
  if (reason.length < 3 || reason.length > 300) throw fail("invalid-argument", "reason_required");
  const amt = parseRender(d.amountRender, mode === "set");
  if (amt === null) throw fail("invalid-argument", "invalid_amount");
  if (mode !== "set" && amt > ADJUST_MAX_UNITS) throw fail("invalid-argument", "above_adjustment_cap:" + ADJUST_MAX_UNITS / C.UNITS_PER_RENDER);
  await limitDb(env.DB, "admin:adjust", 60, 10 * 60 * 1000, now);
  const out = await mutateUser(env.DB, { uid }, now, async (u, g) => {
    if (u.isNew) throw fail("not-found", "no_such_user");
    const dup = await st(env.DB, "SELECT uid, units, balance_after_units, at FROM ledger WHERE type='admin_adjustment' AND request_id = ?", requestId).first();
    if (dup) {
      if (dup.uid !== u.uid) throw fail("already-exists", "request_id_reused");
      return { duplicate: true, deltaUnits: dup.units, beforeUnits: dup.balance_after_units - dup.units, afterUnits: dup.balance_after_units };
    }
    const before = u.balanceUnits, delta = mode === "add" ? amt : mode === "subtract" ? -amt : amt - before;
    if (delta === 0) throw fail("failed-precondition", "no_change");
    if (Math.abs(delta) > ADJUST_MAX_UNITS) throw fail("invalid-argument", "above_adjustment_cap:" + ADJUST_MAX_UNITS / C.UNITS_PER_RENDER);
    const after = before + delta;
    if (after < 0) throw fail("failed-precondition", "insufficient_balance");
    u.balanceUnits = after;
    g.insert("ledger", { uid: u.uid, at: now, type: "admin_adjustment", units: delta, balance_after_units: after, request_id: requestId });
    g.insert("audit", { uid: u.uid, type: "admin_balance_adjustment", at: now, data: JSON.stringify({ requestId, mode, deltaUnits: delta, beforeUnits: before, afterUnits: after, reason, by: "owner-admin" }) });
    return { duplicate: false, deltaUnits: delta, beforeUnits: before, afterUnits: after };
  });
  return { requestId, uid, mode, duplicate: out.duplicate, deltaUnits: out.deltaUnits, deltaRender: R(out.deltaUnits), balanceBeforeUnits: out.beforeUnits, balanceBeforeRender: R(out.beforeUnits), balanceAfterUnits: out.afterUnits, balanceAfterRender: R(out.afterUnits) };
}

export async function listAdjustments(env, d) {
  const limit = clampInt(d.limit, 25, 1, 100), offset = clampInt(d.offset, 0, 0, 100000), uid = String(d.uid || "").trim().slice(0, 128);
  const where = "WHERE a.type = 'admin_balance_adjustment'" + (uid ? " AND a.uid = ?" : ""), p = uid ? [uid] : [];
  const total = (await st(env.DB, `SELECT COUNT(*) AS n FROM audit a ${where}`, ...p).first()).n;
  const { results } = await st(env.DB, `SELECT a.id, a.uid, a.type, a.at, a.data, u.email AS email FROM audit a LEFT JOIN users u ON u.uid = a.uid ${where} ORDER BY a.id DESC LIMIT ? OFFSET ?`, ...p, limit, offset).all();
  return { items: results.map((a) => ({ ...auditItem(a), email: a.email || "" })), total, limit, offset, hasMore: offset + results.length < total };
}

/* ---------------- withdrawals ---------------- */
/** status: open (requested+approved, oldest first) | all | requested | approved | paid | rejected (newest first). Optional q = uid / request id / email part. */
export async function searchWithdrawals(env, d) {
  const status = d.status == null ? "open" : String(d.status);
  if (!["open", "all", "requested", "approved", "paid", "rejected"].includes(status)) throw fail("invalid-argument", "bad_admin_request");
  const limit = clampInt(d.limit, 25, 1, 200), offset = clampInt(d.offset, 0, 0, 100000), q = String(d.q || "").trim().slice(0, 100);
  const where = [], p = [];
  if (status === "open") where.push("w.status IN ('requested','approved')"); else if (status !== "all") { where.push("w.status = ?"); p.push(status); }
  if (q) { where.push("(w.uid LIKE ? ESCAPE '\\' OR w.request_id LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\')"); p.push(...Array(3).fill("%" + likeEsc(q) + "%")); }
  const W_ = where.length ? "WHERE " + where.join(" AND ") : "";
  const total = (await st(env.DB, `SELECT COUNT(*) AS n FROM withdrawals w LEFT JOIN users u ON u.uid = w.uid ${W_}`, ...p).first()).n;
  const { results } = await st(env.DB, `${WSEL} ${W_} ORDER BY w.requested_at ${status === "open" ? "ASC" : "DESC"} LIMIT ? OFFSET ?`, ...p, limit, offset).all();
  return { items: results.map(wItem), total, limit, offset, hasMore: offset + results.length < total, status };
}
/** Legacy command-line shape: a plain array of open (requested + approved) withdrawals. */
export async function listOpenWithdrawals(env) { return (await searchWithdrawals(env, { status: "open", limit: 200 })).items; }

/** requested -> approved -> paid, or requested/approved -> rejected (refunds the held RENDER once). "paid" needs a real payout reference and is Sat/Sun (Pakistan time) only. Marking paid moves NO money. */
export async function withdrawalAct(env, now, d) {
  const to = { approve: "approved", reject: "rejected", markpaid: "paid" }[d.action];
  const uid = String(d.uid || ""), requestId = String(d.requestId || "");
  if (!to || !uid || !requestId) throw fail("invalid-argument", "bad_admin_request");
  const payoutRef = String(d.payoutRef == null ? "" : d.payoutRef).trim();
  if (to === "paid") {
    if (!W.isPayoutDay(now)) throw fail("failed-precondition", "payouts_only_sat_sun_pkt");
    if (payoutRef.length < 3) throw fail("invalid-argument", "payout_reference_required");
  }
  const w = await st(env.DB, "SELECT * FROM withdrawals WHERE uid=? AND request_id=?", uid, requestId).first();
  if (!w) throw fail("not-found", "no_such_withdrawal");
  if (!W.canTransition(w.status, to)) throw fail("failed-precondition", `cannot_go_${w.status}_to_${to}`);
  const tok = newId() + newId(), col = { approved: "approved_at", rejected: "rejected_at", paid: "paid_at" }[to];
  const note = to === "paid" ? "" : String(d.note || "").slice(0, 300);
  const stmts = [st(env.DB, `UPDATE withdrawals SET status=?, ${col}=?, note=?, payout_ref=COALESCE(?, payout_ref), action_token=? WHERE uid=? AND request_id=? AND status=?`,
    to, now, note, to === "paid" ? payoutRef.slice(0, 120) : null, tok, uid, requestId, w.status)];
  const won = "EXISTS (SELECT 1 FROM withdrawals WHERE uid=? AND request_id=? AND action_token=?)";
  if (to === "rejected") {
    stmts.push(st(env.DB, `UPDATE users SET balance_units = balance_units + ?, version = version + 1 WHERE uid = ? AND ${won}`, w.amount_units, uid, uid, requestId, tok));
    stmts.push(st(env.DB, `INSERT INTO ledger (uid,at,type,units,balance_after_units,request_id) SELECT ?,?,?,?,(SELECT balance_units FROM users WHERE uid=?),? WHERE ${won}`, uid, now, "withdrawal_refund", w.amount_units, uid, requestId, uid, requestId, tok));
  }
  const info = { requestId, by: "owner-admin", ...(note ? { note } : {}), ...(to === "paid" ? { payoutRef: payoutRef.slice(0, 120) } : {}) };
  stmts.push(st(env.DB, `INSERT INTO audit (uid,type,at,data) SELECT ?,?,?,? WHERE ${won}`, uid, "withdrawal_" + to, now, JSON.stringify(info), uid, requestId, tok));
  const res = await env.DB.batch(stmts);
  if (res[0].meta.changes !== 1) throw fail("aborted", "withdrawal_changed_meanwhile");
  return { requestId, status: to };
}

/* ---------------- read-only consistency report ---------------- */
/**
 * Invariants (all read-only; capped at 50 rows each):
 *  1. balance_units = SUM(ledger.units) + (credited_units of a still-active session, which is already in the balance but not yet in the ledger)
 *  2. every withdrawal has exactly one correct withdrawal_hold ledger row
 *  3. a rejected withdrawal has exactly one withdrawal_refund; any other status has none
 */
export async function consistency(env) {
  const exp = "COALESCE(l.s,0) + CASE WHEN u.mining_status='active' THEN u.credited_units ELSE 0 END";
  const { results: bal } = await st(env.DB, `SELECT u.uid, u.email, u.balance_units AS balance, ${exp} AS expected FROM users u LEFT JOIN (SELECT uid, SUM(units) AS s FROM ledger GROUP BY uid) l ON l.uid = u.uid WHERE u.balance_units != ${exp} LIMIT 50`).all();
  const { results: wd } = await st(env.DB, `SELECT * FROM (SELECT w.uid, w.request_id, w.status,
      (SELECT COUNT(*) FROM ledger l WHERE l.uid=w.uid AND l.request_id=w.request_id AND l.type='withdrawal_hold' AND l.units = -w.amount_units) AS holds,
      (SELECT COUNT(*) FROM ledger l WHERE l.uid=w.uid AND l.request_id=w.request_id AND l.type='withdrawal_refund' AND l.units = w.amount_units) AS refunds FROM withdrawals w)
      WHERE holds != 1 OR (status = 'rejected' AND refunds != 1) OR (status != 'rejected' AND refunds != 0) LIMIT 50`).all();
  return {
    ok: bal.length === 0 && wd.length === 0,
    balanceMismatches: bal.map((r) => ({ uid: r.uid, email: r.email, balanceUnits: r.balance, expectedUnits: r.expected, differenceUnits: r.balance - r.expected })),
    withdrawalMismatches: wd.map((r) => ({ uid: r.uid, requestId: r.request_id, status: r.status, holdRows: r.holds, refundRows: r.refunds })),
  };
}
