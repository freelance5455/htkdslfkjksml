#!/usr/bin/env node
// Owner-only admin command line. Talks to YOUR Worker; needs the ADMIN_TOKEN you set with `wrangler secret put ADMIN_TOKEN`.
// (The Admin Panel page at <your worker>/admin does the same in a browser; this is the same API.)
//   export RND_API_BASE=https://rnd-miner-api.<you>.workers.dev
//   export RND_ADMIN_TOKEN=<the same token>          (keep it on your computer only; never in the app or the repo)
//   node worker/tools/admin.mjs stats
//   node worker/tools/admin.mjs list [open|all|requested|approved|paid|rejected]      (default: open = requested + approved)
//   node worker/tools/admin.mjs approve  <uid> <requestId> [note]
//   node worker/tools/admin.mjs reject   <uid> <requestId> [note]            (returns the held RENDER to the user, once)
//   node worker/tools/admin.mjs markpaid <uid> <requestId> <payoutReference>  (ONLY after you really sent the money; Sat/Sun Pakistan time)
const API = (process.env.RND_API_BASE || "").replace(/\/+$/, ""), TOKEN = process.env.RND_ADMIN_TOKEN || "";
const [cmd, uid, requestId, ...rest] = process.argv.slice(2);
if (!API || !TOKEN) { console.error("Set RND_API_BASE and RND_ADMIN_TOKEN first (see the header of this file)."); process.exit(1); }
async function post(path, body) {
  const r = await fetch(API + path, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + TOKEN }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => null); if (!j || !j.ok) throw new Error(j ? j.error.message : "HTTP " + r.status); return j.data;
}
const R = (u) => (u / 1e8).toFixed(8);
(async () => {
  if (cmd === "stats") { const s = await post("/admin/stats", {}); console.log(`users=${s.users.total} mining_now=${s.users.miningNow} settled_balances=${R(s.settledBalanceUnits)} RENDER`); for (const k of ["requested", "approved", "paid", "rejected"]) console.log(`${k.padEnd(9)} ${s.withdrawals[k].count} (${R(s.withdrawals[k].units)} RENDER)`); return; }
  if (cmd === "list") {
    const status = uid || "open"; let offset = 0, total = 0, shown = 0;
    do { const d = await post("/admin/withdrawals/search", { status, limit: 100, offset }); total = d.total; for (const w of d.items) { shown++; console.log(`${w.status.padEnd(9)} uid=${w.uid} requestId=${w.requestId} ${w.method} ${R(w.amountUnits)} ${w.currency} (~PKR ${w.amountPkr}) to ${JSON.stringify(w.destination)} requested ${new Date(w.requestedAt).toISOString()}${w.payoutRef ? " ref=" + w.payoutRef : ""}`); } offset += d.items.length; if (!d.items.length) break; } while (offset < total);
    if (!shown) console.log("No withdrawals with status: " + status); return;
  }
  if (!["approve", "reject", "markpaid"].includes(cmd) || !uid || !requestId) { console.log("Usage: see the header of this file."); process.exit(1); }
  const d = await post("/admin/withdrawals/act", { action: cmd, uid, requestId, ...(cmd === "markpaid" ? { payoutRef: rest[0] } : { note: rest.join(" ") }) });
  console.log(`OK: ${d.requestId} is now ${d.status}.`);
})().catch((e) => { console.error("ERROR:", e.message); process.exit(1); });
