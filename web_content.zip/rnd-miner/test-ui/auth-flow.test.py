"""Browser test of the sign-in UI against a STUB backend (a small in-page imitation of Firebase Auth rules).
It tests RND Miner's screens and routing. It is NOT a test of real Firebase, real emails or the APK."""
import json, sys, threading, http.server, socketserver, functools, os
from playwright.sync_api import sync_playwright

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "www")
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
H = functools.partial(Q, directory=ROOT)
srv = socketserver.TCPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

# Stub of window.RNDBackend. Mirrors Firebase behaviour: register signs in an UNVERIFIED user; emailVerified only flips when the
# "link was clicked" (test hook) AND the app reloads the user + force-refreshes the token; sessions persist in localStorage.
STUB = r"""
(function(){
const LS=window.localStorage, KEY="stub_db", SES="stub_session";
const db=()=>JSON.parse(LS.getItem(KEY)||"{}"), save=d=>LS.setItem(KEY,JSON.stringify(d));
const log=window.__calls=[];
const E=(code,m)=>Object.assign(new Error(m||code),{code});
window.__clickEmailLink=(email)=>{const d=db();d[email].verified=true;save(d)};   // what the person does in Gmail
window.RNDBackend={createBackend:async()=>{
 let tokenVerified=null;
 const cur=()=>{const s=LS.getItem(SES);if(!s)return null;const d=db()[s];if(!d)return null;return {uid:d.uid,email:s,displayName:s.split("@")[0],emailVerified:d.userVerified===true}};
 const B={UNITS:1e8,auth:{
  current:cur,
  async register(email,pw){const d=db();if(d[email])throw E("auth/email-already-in-use");d[email]={uid:"u_"+email,pw,verified:false,userVerified:false,tokenVerified:false};save(d);LS.setItem(SES,email);log.push("register");log.push("sendVerification");return cur()},
  async signIn(email,pw){const d=db();if(!d[email]||d[email].pw!==pw)throw E("auth/invalid-credential");LS.setItem(SES,email);log.push("signIn");
    // a fresh sign-in returns the CURRENT server truth
    d[email].userVerified=d[email].verified;d[email].tokenVerified=d[email].verified;save(d);return cur()},
  async signOut(){LS.removeItem(SES);log.push("signOut")},
  async sendVerification(){if(!cur())throw E("no_session");log.push("sendVerification")},
  async sendReset(email){log.push("sendReset:"+email)},
  async refresh(){const s=LS.getItem(SES);if(!s)throw E("no_session");const d=db();d[s].userVerified=d[s].verified;d[s].tokenVerified=d[s].verified;save(d);log.push("refresh");return cur()},
  async hasVerifiedSession(){const s=LS.getItem(SES);if(!s)return false;const d=db();if(!d[s].tokenVerified){d[s].userVerified=d[s].verified;d[s].tokenVerified=d[s].verified;save(d)}return d[s].tokenVerified===true}
 },
 async getState(){log.push("getState");const s=LS.getItem(SES),d=db()[s];if(!d||!d.tokenVerified)throw E("failed-precondition","email_not_verified");return {serverNow:Date.now(),profile:{uid:d.uid,email:s,displayName:s.split("@")[0]},balanceUnits:0,totalEarnedUnits:0,mining:{status:"idle"},boost:{endsAt:0,count:0,max:10,segments:[]}}},
 async startMining(){log.push("startMining");const s=LS.getItem(SES),d=db()[s];if(!d||!d.tokenVerified)throw E("failed-precondition","email_not_verified");throw E("x")},async getPrice(){throw E("x")},async requestWithdrawal(){throw E("x")}};
 return B}};
})();
"""
results=[]
def check(name, cond, extra=""):
    results.append((name, bool(cond))); print(("PASS  " if cond else "FAIL  ")+name+(("  -> "+str(extra)) if (extra and not cond) else ""))

def vis(page, id_):
    return page.evaluate("id=>{const e=document.getElementById(id);return !!e&&getComputedStyle(e).display!=='none'&&e.offsetParent!==null||(!!e&&getComputedStyle(e).display!=='none')}", id_)
def app_visible(page): return page.evaluate("getComputedStyle(document.getElementById('mainApp')).display!=='none'")

with sync_playwright() as p:
    br = p.chromium.launch()
    ctx = br.new_context()
    page = ctx.new_page()
    errs=[]; page.on("pageerror", lambda e: errs.append(str(e)))
    # Replace the real backend script with the stub; keep firebase-config.js as is.
    page.route("**/js/rnd-backend.js", lambda r: r.fulfill(body=STUB, content_type="application/javascript"))
    url=f"http://127.0.0.1:{port}/index.html"
    page.goto(url); page.wait_for_selector("#authLogin", state="visible", timeout=15000)

    check("no OTP screen or code input exists in the page", page.evaluate("!document.getElementById('authCode')&&!document.getElementById('loginCode')&&!/6-digit|login code/i.test(document.body.innerText)"))

    # --- register
    page.click("text=Sign up"); page.fill("#signupEmail","ali@example.com"); page.fill("#signupPass","password123"); page.fill("#signupPass2","password123"); page.click("#signupBtn")
    page.wait_for_selector("#authVerify", state="visible", timeout=8000)
    calls=page.evaluate("window.__calls")
    check("registration sends Firebase verification (no code step) and shows verify screen", calls==["register","sendVerification"] and vis(page,"authVerify"), calls)
    check("main app is hidden and getState never called while unverified", (not app_visible(page)) and "getState" not in calls)
    check("verify screen mentions Gmail steps + 'I HAVE VERIFIED' button", "I HAVE VERIFIED" in page.inner_text("#checkBtn"))

    # --- tap before verifying
    page.click("#checkBtn"); page.wait_for_function("document.getElementById('verifyMsg').textContent.includes('not verified')", timeout=5000)
    check("tapping 'I have verified' before clicking the link shows a clear message and stays locked", vis(page,"authVerify") and not app_visible(page))
    page.click("#checkBtn"); page.wait_for_timeout(300)
    check("retry is allowed (button enabled again)", page.evaluate("!document.getElementById('checkBtn').disabled"))

    # --- app killed + reopened while unverified: session persists, still locked
    page.reload(); page.wait_for_selector("#authVerify", state="visible", timeout=15000)
    check("persistent session: reopen while unverified -> verify screen, app still locked", vis(page,"authVerify") and not app_visible(page))

    # --- click link in Gmail (other app), return, tap button
    page.evaluate("window.__clickEmailLink('ali@example.com')")
    page.click("#checkBtn"); page.wait_for_function("getComputedStyle(document.getElementById('mainApp')).display!=='none'", timeout=8000)
    calls=page.evaluate("window.__calls")
    check("after link + 'I have verified': user reloaded, signed in session used, app opens directly", app_visible(page) and "refresh" in calls and "getState" in calls and not vis(page,"authCode") if False else app_visible(page) and "refresh" in calls and "getState" in calls)
    check("no code screen appears at any point", page.evaluate("!document.getElementById('authCode')"))

    # --- persistent login: reopen -> straight into app
    page.reload(); page.wait_for_function("getComputedStyle(document.getElementById('mainApp')).display!=='none'", timeout=15000)
    check("persistent login: reopen app -> opens directly, no login/verify/code screen", app_visible(page))

    # --- logout
    page.evaluate("doLogout()"); page.wait_for_selector("#authLogin", state="visible", timeout=15000)
    check("logout returns to login and clears the session", vis(page,"authLogin") and not app_visible(page) and page.evaluate("localStorage.getItem('stub_session')===null"))
    page.reload(); page.wait_for_selector("#authLogin", state="visible", timeout=15000)
    check("after logout + reopen the app stays on login (no auto sign-in)", not app_visible(page))

    # --- login verified account
    page.fill("#loginEmail","ali@example.com"); page.fill("#loginPass","wrongpass"); page.click("#loginBtn")
    page.wait_for_function("document.getElementById('loginMsg').textContent.includes('Wrong email or password')", timeout=5000)
    check("wrong password -> clear error, no app", not app_visible(page))
    page.fill("#loginPass","password123"); page.click("#loginBtn")
    page.wait_for_function("getComputedStyle(document.getElementById('mainApp')).display!=='none'", timeout=8000)
    check("login with verified account opens the app directly (no OTP)", app_visible(page) and "requestLoginCode" not in str(page.evaluate("window.__calls")))

    # --- login with unverified account
    page.evaluate("doLogout()"); page.wait_for_selector("#authLogin", state="visible", timeout=15000)
    page.click("text=Sign up"); page.fill("#signupEmail","sara@example.com"); page.fill("#signupPass","password123"); page.fill("#signupPass2","password123"); page.click("#signupBtn")
    page.wait_for_selector("#authVerify", state="visible", timeout=8000)
    page.evaluate("doLogout()"); page.wait_for_selector("#authLogin", state="visible", timeout=15000)
    page.fill("#loginEmail","sara@example.com"); page.fill("#loginPass","password123"); page.click("#loginBtn")
    page.wait_for_selector("#authVerify", state="visible", timeout=8000)
    page.wait_for_function("document.getElementById('verifyMsg').textContent.includes('not verified')", timeout=5000)
    check("login with unverified email -> prompted to verify, app locked", vis(page,"authVerify") and not app_visible(page))
    n0=page.evaluate("window.__calls.filter(c=>c==='sendVerification').length")
    page.evaluate("resendUntil=0"); page.click("#resendBtn"); page.wait_for_timeout(400)
    n1=page.evaluate("window.__calls.filter(c=>c==='sendVerification').length")
    check("resend verification email works from the verify screen", n1==n0+1)

    # --- lost session on verify screen
    page.evaluate("localStorage.removeItem('stub_session')"); page.click("#checkBtn")
    page.wait_for_selector("#authLogin", state="visible", timeout=5000)
    check("'I have verified' with no Firebase session -> asks to log in (never opens app)", vis(page,"authLogin") and not app_visible(page) and "log in" in page.inner_text("#loginMsg").lower())

    # --- server refuses (unverified) while app open -> app re-locks
    page.fill("#loginEmail","ali@example.com"); page.fill("#loginPass","password123"); page.click("#loginBtn")
    page.wait_for_function("getComputedStyle(document.getElementById('mainApp')).display!=='none'", timeout=8000)
    page.evaluate("(()=>{const d=JSON.parse(localStorage.getItem('stub_db'));d['ali@example.com'].verified=false;d['ali@example.com'].tokenVerified=false;d['ali@example.com'].userVerified=false;localStorage.setItem('stub_db',JSON.stringify(d))})()")
    page.evaluate("startMining()"); page.wait_for_selector("#authVerify", state="visible", timeout=8000)
    check("if the server later refuses (email_not_verified) the app re-locks to the verify screen", vis(page,"authVerify") and not app_visible(page))

    # --- password reset
    page.evaluate("doLogout()"); page.wait_for_selector("#authLogin", state="visible", timeout=15000)
    page.click("text=Forgot password?"); page.fill("#resetEmail","ali@example.com"); page.click("#resetBtn")
    page.wait_for_function("document.getElementById('resetMsg').textContent.includes('reset link')", timeout=5000)
    calls=page.evaluate("window.__calls")
    check("password reset uses Firebase reset-link email only (sendReset), no code", "sendReset:ali@example.com" in calls and not any("ode" in c and "Verification" not in c and "verif" not in c.lower() for c in calls if c not in ("sendVerification",)))

    check("no uncaught page errors", not errs, errs)
    br.close()
srv.shutdown()
bad=[n for n,ok in results if not ok]
print(f"\n{len(results)-len(bad)}/{len(results)} passed"); sys.exit(1 if bad else 0)
