"""LOCAL browser test of the Admin Panel page (GET /admin): real page JavaScript in Chromium (phone-size viewport) -> real worker/src code on node:sqlite.
Not Cloudflare, not production. Uses an isolated in-memory database with test rows only."""
import faulthandler; faulthandler.dump_traceback_later(110, exit=True)
import sys, os, subprocess, json, re, urllib.request, urllib.parse
from playwright.sync_api import sync_playwright
HERE = os.path.dirname(os.path.abspath(__file__))
api = subprocess.Popen(["node", "--no-warnings", os.path.join(HERE, "..", "worker", "test", "e2e-server.mjs")], stdout=subprocess.PIPE, text=True)
API = "http://127.0.0.1:" + re.search(r"PORT (\d+)", api.stdout.readline()).group(1)
TOKEN = "a" * 40   # the test world's ADMIN_TOKEN (test fixture only)
def control(**c): return json.load(urllib.request.urlopen(API + "/__control?c=" + urllib.parse.quote(json.dumps(c))))
R = []
def check(n, c, x=""): R.append(bool(c)); print(("PASS  " if c else "FAIL  ") + n + ((" -> " + str(x)) if (x and not c) else ""))

now = control()["now"]
seed = ["INSERT INTO users (uid,email,display_name,created_at,balance_units) VALUES ('uid_%02d','miner%02d@example.com','Miner %02d',%d,%d)" % (i, i, i, now - i * 1000, i * 10**8) for i in range(30)]
seed += ["INSERT INTO ledger (uid,at,type,units,balance_after_units) VALUES ('uid_%02d',1,'seed',%d,%d)" % (i, i * 10**8, i * 10**8) for i in range(1, 30)]
for u, rid, st in [("uid_05", "wd-requested-01", "requested"), ("uid_06", "wd-requested-02", "requested"), ("uid_07", "wd-paidold-001", "paid")]:
    seed.append("INSERT INTO withdrawals (uid,request_id,method,destination,amount_units,amount_pkr,render_pkr_at_request,price_source_updated_at,status,requested_at,payout_ref) VALUES ('%s','%s','EasyPaisa','{\"accountName\":\"<b>Ali</b>\",\"accountNumber\":\"03001234567\"}',2000000000,60,3,1,'%s',%d,%s)" % (u, rid, st, now - 5000, "'OLD-REF-1'" if st == "paid" else "NULL"))
    seed.append("INSERT INTO ledger (uid,at,type,units,balance_after_units,request_id) VALUES ('%s',2,'withdrawal_hold',-2000000000,0,'%s')" % (u, rid))
control(sql=";".join(seed))

with sync_playwright() as pw:
    b = pw.chromium.launch()
    ctx = b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True)
    p = ctx.new_page(); errs = []; csp = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.on("console", lambda m: csp.append(m.text) if "Content Security Policy" in m.text or "Refused" in m.text else None)
    reqs = []; p.on("request", lambda r: reqs.append(r.url))
    p.goto(API + "/admin")
    check("page loads with the unlock screen, app hidden", p.is_visible("#tok") and not p.is_visible("#app"))
    check("no horizontal scroll on a phone-size screen (login)", p.evaluate("document.documentElement.scrollWidth<=window.innerWidth"))
    p.fill("#tok", "not-the-token"); p.click("#go"); p.wait_for_selector("#lerr:has-text('Wrong admin token')")
    check("wrong token -> clear message, still locked", p.is_visible("#tok") and not p.is_visible("#app"))
    p.fill("#tok", TOKEN); p.click("#go"); p.wait_for_selector("text=Overview")
    check("correct token opens the dashboard", p.is_visible("#app") and p.is_visible("text=Total users"))
    check("dashboard shows real user count (30)", p.locator(".stat", has_text="Total users").inner_text().split("\n")[1] == "30")
    check("dashboard says balances are settled-only", "SETTLED" in p.inner_text("#view"))
    check("dashboard lists 2 requested, 1 paid", p.locator(".stat", has_text="requested").inner_text().count("2") >= 1 and "1" in p.locator(".stat", has_text="paid").inner_text())
    st = p.evaluate("({l:localStorage.length,s:sessionStorage.length,c:document.cookie,t:document.body.innerHTML.includes('%s'),u:location.href})" % TOKEN)
    check("token is in memory only: no localStorage, sessionStorage, cookie, page text or URL", st["l"] == 0 and st["s"] == 0 and st["c"] == "" and not st["t"] and TOKEN not in st["u"], st)
    check("every request went to the same origin", all(u.startswith(API) for u in reqs), [u for u in reqs if not u.startswith(API)])
    check("input cleared after unlock", p.input_value("#tok") == "")

    # ---- users: pagination + search ----
    p.click("button[data-tab=users]"); p.wait_for_selector("text=Search")
    check("users: 20 of 30 on page 1, newest first", p.locator("#view .card").count() == 20 and "uid_00" in p.locator("#view .card").first.inner_text())
    p.click("button[data-pg='u:1']"); p.wait_for_selector("text=21\u201330 of 30")
    check("users: page 2 shows the other 10", p.locator("#view .card").count() == 10)
    p.fill("#uq", "miner17@"); p.click("#usr"); p.wait_for_selector("text=1\u20131 of 1")
    check("users: search by email finds exactly one", p.locator("#view .card").count() == 1 and "miner17@example.com" in p.inner_text("#view"))
    p.fill("#uq", "uid_23"); p.click("#usr"); p.wait_for_selector("text=1\u20131 of 1")
    check("users: search by UID", "uid_23" in p.inner_text("#view"))
    check("users: no horizontal scroll on phone", p.evaluate("document.documentElement.scrollWidth<=window.innerWidth"))

    # ---- adjust balance (double tap) ----
    p.fill("#uq", "uid_10"); p.click("#usr"); p.wait_for_selector("text=1\u20131 of 1")
    p.click("button[data-user=uid_10]"); p.wait_for_selector("text=Settled balance")
    check("user dialog separates settled balance from unsettled reward", "Unsettled session reward" in p.inner_text("#box"))
    p.click("button[data-adjust=uid_10]"); p.wait_for_selector("#am")
    p.click("#asub"); p.wait_for_selector("#aout:has-text('reason')", timeout=5000)
    check("empty form refused: reason is mandatory", "reason" in p.inner_text("#aout"))
    p.fill("#ar", "UI test credit"); p.fill("#aa", "abc"); p.click("#asub"); p.wait_for_selector("#aout:has-text('valid amount')", timeout=5000)
    check("junk amount refused", "valid amount" in p.inner_text("#aout"))
    p.fill("#ar", "UI test credit"); p.fill("#aa", "1000.5"); p.click("#asub"); p.wait_for_selector("#aout:has-text('limit')")
    check("over the 1000 RENDER limit refused", "1000" in p.inner_text("#aout"))
    p.fill("#aa", "5.5"); p.dblclick("#asub"); p.wait_for_selector("#aout:has-text('Before')")
    out = p.inner_text("#aout")
    check("success shows before and after (10.00000000 -> 15.50000000)", "10.00000000" in out and "15.50000000" in out, out)
    rows = control(query="SELECT units,balance_after_units,type FROM ledger WHERE uid='uid_10' AND type='admin_adjustment'")["rows"]
    check("double tap applied exactly once in the ledger", len(rows) == 1 and rows[0]["units"] == 550000000 and rows[0]["balance_after_units"] == 1550000000, rows)
    bal = control(query="SELECT balance_units b FROM users WHERE uid='uid_10'")["rows"][0]["b"]
    check("balance in the database is 15.5 RENDER", bal == 1550000000, bal)
    p.click("button[data-close]"); p.click("button[data-tab=adj]"); p.wait_for_selector("text=UI test credit")
    check("adjustment history shows the reason and before/after", "UI test credit" in p.inner_text("#view") and "15.50000000" in p.inner_text("#view"))

    # ---- withdrawals ----
    p.click("button[data-tab=wd]"); p.wait_for_selector("text=wd-requested-01")
    check("withdrawals: open view shows 2 requested, escaped destination text (no HTML injection)", p.locator("#view .card[data-rid]").count() == 2 and "<b>Ali</b>" in p.inner_text("#view") and p.locator("#view b", has_text="Ali").count() == 0)
    p.select_option("#ws", "all"); p.wait_for_selector("text=wd-paidold-001")
    check("withdrawals: 'all' includes the paid one with its payout reference", p.locator("#view .card[data-rid]").count() == 3 and "OLD-REF-1" in p.inner_text("#view"))
    p.select_option("#ws", "paid"); p.wait_for_selector("text=1\u20131 of 1")
    check("withdrawals: paid filter", p.locator("#view .card[data-rid]").count() == 1)
    p.select_option("#ws", "open"); p.wait_for_selector("text=wd-requested-01")
    card = p.locator("#view .card[data-rid='wd-requested-01']")
    card.locator("button[data-act=approve]").click(); p.wait_for_selector("#box h3:has-text('Approve')"); p.click("#asub"); p.wait_for_selector("#view .card[data-rid='wd-requested-01'] .t-approved")
    check("approve -> approved, balance untouched", control(query="SELECT status FROM withdrawals WHERE request_id='wd-requested-01'")["rows"][0]["status"] == "approved" and control(query="SELECT balance_units b FROM users WHERE uid='uid_05'")["rows"][0]["b"] == 5 * 10**8)
    p.locator("#view .card[data-rid='wd-requested-01'] button[data-act=markpaid]").click(); p.fill("#pr", "EP-TEST-778899"); p.click("#asub")
    p.wait_for_selector("#toast:has-text('Saturday')")
    check("mark paid on a weekday is refused with the Saturday/Sunday rule", control(query="SELECT status FROM withdrawals WHERE request_id='wd-requested-01'")["rows"][0]["status"] == "approved")
    p.click("button[data-close]")
    control(advance=2 * 24 * 3600 * 1000)   # Thursday -> Saturday (server clock; test knob)
    p.locator("#view .card[data-rid='wd-requested-01'] button[data-act=markpaid]").click(); p.click("#asub")
    p.wait_for_selector("#toast:has-text('reference')")
    check("mark paid without a payout reference is refused", control(query="SELECT status FROM withdrawals WHERE request_id='wd-requested-01'")["rows"][0]["status"] == "approved")
    p.fill("#pr", "EP-TEST-778899"); p.click("#asub"); p.wait_for_selector("#toast:has-text('now paid')")
    row = control(query="SELECT status,payout_ref,paid_at FROM withdrawals WHERE request_id='wd-requested-01'")["rows"][0]
    check("mark paid on Saturday with a reference -> paid, reference stored", row["status"] == "paid" and row["payout_ref"] == "EP-TEST-778899" and row["paid_at"], row)
    p.locator("#view .card[data-rid='wd-requested-02'] button[data-act=reject]").click(); p.wait_for_selector("#box h3:has-text('Reject')")
    check("reject dialog states the refund", "returned to the user" in p.inner_text("#box"))
    p.fill("#pn", "Wrong account"); p.click("#asub"); p.wait_for_selector("#toast:has-text('rejected')")
    r2 = control(query="SELECT balance_units b FROM users WHERE uid='uid_06'")["rows"][0]["b"]
    check("reject refunds 20 RENDER exactly once (6 -> 26)", r2 == 26 * 10**8 and control(query="SELECT COUNT(*) n FROM ledger WHERE type='withdrawal_refund'")["rows"][0]["n"] == 1, r2)
    p.select_option("#ws", "rejected"); p.wait_for_selector("text=Wrong account")
    check("rejected request stays visible with its note", "wd-requested-02" in p.inner_text("#view"))

    # ---- dashboard recap + consistency + lock ----
    p.click("button[data-tab=dash]"); p.wait_for_selector("text=Recent administrative actions")
    check("dashboard lists recent admin actions (adjustment, approve, paid, reject)", all(k in p.inner_text("#view") for k in ["Balance add", "Withdrawal approved", "Withdrawal paid", "Withdrawal rejected"]))
    check("dashboard on a payout day says Mark paid is allowed", "payout day" in p.inner_text("#view"))
    p.click("#chk"); p.wait_for_selector("#chkout .note")
    check("consistency check runs from the page", p.locator("#chkout .note").count() >= 1)
    p.screenshot(path="/tmp/admin-dash.png", full_page=False)
    p.click("#lock")
    check("Lock forgets the token and shows the unlock screen", p.is_visible("#tok") and not p.is_visible("#app") and p.inner_text("#view") == "")
    p.reload(); check("reload requires the token again", p.is_visible("#tok") and not p.is_visible("#app"))
    p.fill("#tok", TOKEN); p.click("#go"); p.wait_for_selector("text=Overview"); p.click("button[data-tab=wd]"); p.wait_for_selector("text=Withdrawals"); p.screenshot(path="/tmp/admin-wd.png")
    check("no CSP violations or blocked resources", not csp, csp)
    check("no uncaught page errors", not errs, errs)
    b.close()
api.kill()
print("\n%d/%d passed" % (sum(R), len(R))); sys.exit(0 if all(R) else 1)
