"""Runs the REAL www/js/rnd-backend.js in headless Chromium against a FAKE Firebase SDK (served in place of the gstatic CDN files).
Checks that our code calls the SDK correctly (reload + force-refresh token, claim check, no OTP functions). NOT real Firebase."""
import sys, threading, http.server, socketserver, functools, os
from playwright.sync_api import sync_playwright
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","www")
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(("127.0.0.1",0),functools.partial(Q,directory=ROOT)); port=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
APP="export const initializeApp=(c)=>({cfg:c});"
AUTH="""
const S=window.__fb=window.__fb||{log:[],server:{verified:false},tokenVerified:false,user:null,persisted:false};
function mk(){return {uid:"u1",email:"a@b.co",emailVerified:S.tokenVerified,
  async reload(){S.log.push("reload");this.emailVerified=S.server.verified},
  async getIdToken(f){S.log.push("getIdToken:"+!!f);if(f)S.tokenVerified=S.server.verified;return "tok"},
  async getIdTokenResult(f){S.log.push("getIdTokenResult:"+!!f);if(f)S.tokenVerified=S.server.verified;return {claims:{email_verified:S.tokenVerified}}}}}
const auth={get currentUser(){return S.user},async authStateReady(){}};
export const getAuth=()=>auth;
export const createUserWithEmailAndPassword=async()=>{S.log.push("create");S.user=mk()};
export const signInWithEmailAndPassword=async()=>{S.log.push("signIn");S.tokenVerified=S.server.verified;S.user=mk();S.user.emailVerified=S.server.verified};
export const sendEmailVerification=async(u)=>{S.log.push("sendEmailVerification:"+(u===S.user))};
export const sendPasswordResetEmail=async(a,e)=>{S.log.push("reset:"+e)};
export const signOut=async()=>{S.log.push("signOut");S.user=null};
"""
results=[]
def check(n,c,x=""): results.append(c); print(("PASS  " if c else "FAIL  ")+n+((" -> "+str(x)) if (x and not c) else ""))
with sync_playwright() as p:
    br=p.chromium.launch(); page=br.new_page(); errs=[]; page.on("pageerror",lambda e:errs.append(str(e)))
    page.route("**/firebase-app.js",lambda r:r.fulfill(body=APP,content_type="application/javascript"))
    page.route("**/firebase-auth.js",lambda r:r.fulfill(body=AUTH,content_type="application/javascript"))
    calls=[]
    def api(route):
        req=route.request; calls.append((req.url,req.headers.get("authorization"),req.post_data))
        if req.url.endswith("/api/getState"): route.fulfill(status=200,content_type="application/json",headers={"access-control-allow-origin":"*"},body='{"ok":true,"data":{"balanceUnits":5}}')
        elif req.url.endswith("/api/startMining"): route.fulfill(status=409,content_type="application/json",headers={"access-control-allow-origin":"*"},body='{"ok":false,"error":{"code":"already-exists","message":"session_already_active"}}')
        elif req.url.endswith("/api/getPrice"): route.fulfill(status=200,content_type="text/html",headers={"access-control-allow-origin":"*"},body="<html>nope</html>")
        else: route.abort()
    page.route("https://api.example.test/**",api)
    page.route("**/index.html",lambda r:r.fulfill(body="<html><body><script src='firebase-config.js'></script><script src='js/rnd-backend.js'></script></body></html>",content_type="text/html"))
    page.goto(f"http://127.0.0.1:{port}/index.html")
    page.evaluate("window.__fb={log:[],server:{verified:false},tokenVerified:false,user:null}")
    r=page.evaluate("""async()=>{
      const out={}; const B=await window.RNDBackend.createBackend(); const S=window.__fb;
      out.keys=Object.keys(B.auth).sort(); out.top=Object.keys(B).sort();
      await B.auth.register("a@b.co","password123"); out.afterRegister=[...S.log]; S.log.length=0;
      out.verifiedBefore=await B.auth.hasVerifiedSession(); out.logBefore=[...S.log]; S.log.length=0;
      S.server.verified=true;                              // person clicked the Gmail link
      const u=await B.auth.refresh(); out.refreshUser=u; out.refreshLog=[...S.log]; S.log.length=0;
      out.verifiedAfter=await B.auth.hasVerifiedSession(); S.log.length=0;
      // stale-token case: user verified in another place; token still says false, hasVerifiedSession must self-heal
      S.tokenVerified=false; out.stale=await B.auth.hasVerifiedSession(); out.staleLog=[...S.log]; S.log.length=0;
      await B.auth.sendReset("a@b.co"); out.resetLog=[...S.log]; S.log.length=0;
      await B.auth.signOut(); 
      try{await B.auth.refresh(); out.noSession="no error"}catch(e){out.noSession=e.code}
      try{await B.auth.sendVerification(); out.noSessionSend="no error"}catch(e){out.noSessionSend=e.code}
      out.noSessionVerified=await B.auth.hasVerifiedSession();
      S.server.verified=false; await B.auth.signIn("a@b.co","password123"); out.signInUser=B.auth.current(); out.signInVerified=await B.auth.hasVerifiedSession();
      return out}""")
    page.evaluate("window.RND_CONFIG.API_BASE='https://api.example.test/'")
    api_r=page.evaluate("""async()=>{
      window.__fb.server.verified=true; window.__fb.tokenVerified=true; const B=await window.RNDBackend.createBackend(); const o={};
      await B.auth.signIn("a@b.co","password123");
      o.state=await B.getState({withdrawals:true});
      try{await B.startMining()}catch(e){o.startCode=e.code;o.startMsg=e.message}
      try{await B.getPrice()}catch(e){o.priceCode=e.code}
      try{await B.requestWithdrawal({requestId:"x"})}catch(e){o.wdCode=e.code}
      await B.auth.signOut(); try{await B.getState()}catch(e){o.noSession=e.code}
      window.RND_CONFIG.API_BASE=""; const B2=await window.RNDBackend.createBackend(); await B2.auth.signIn("a@b.co","password123"); try{await B2.getState()}catch(e){o.noBase=e.code}
      return o}""")
    check("no OTP functions exposed on the client backend", not any(k in r["keys"] for k in ("requestLoginCode","verifyLoginCode","hasLoginCode")), r["keys"])
    check("registration creates the user, then sends Firebase's verification email to that same user", r["afterRegister"]==["create","sendEmailVerification:true"], r["afterRegister"])
    check("before the link is clicked the session is NOT treated as verified", r["verifiedBefore"] is False)
    check("'I have verified' = reload user + force-refresh ID token, then emailVerified is true", r["refreshLog"]==["reload","getIdToken:true"] and r["refreshUser"]["emailVerified"] is True, r["refreshLog"])
    check("verified session accepted only via ID-token claim", r["verifiedAfter"] is True)
    check("stale token self-heals (reload + fresh token) instead of locking the user out", r["stale"] is True and "reload" in r["staleLog"] and "getIdTokenResult:true" in r["staleLog"], r["staleLog"])
    check("password reset calls Firebase sendPasswordResetEmail only", r["resetLog"]==["reset:a@b.co"], r["resetLog"])
    check("refresh / resend with no Firebase session fail with no_session (no fake sign-in)", r["noSession"]=="no_session" and r["noSessionSend"]=="no_session" and r["noSessionVerified"] is False, (r["noSession"],r["noSessionSend"]))
    check("signing in as an unverified account is NOT treated as verified", r["signInUser"]["emailVerified"] is False and r["signInVerified"] is False)
    check("API call sends POST with Bearer ID token and only the data given (no uid/time added by the client)", calls and calls[0][0]=="https://api.example.test/api/getState" and calls[0][1]=="Bearer tok" and calls[0][2]=='{"withdrawals":true}', calls[:1])
    check("success answer returns data", api_r["state"]=={"balanceUnits":5}, api_r)
    check("server refusal keeps its code and reason (api/<code> + message)", api_r["startCode"]=="api/already-exists" and api_r["startMsg"]=="session_already_active", api_r)
    check("an answer that is not the RND API -> api_bad_response", api_r["priceCode"]=="api_bad_response", api_r)
    check("no HTTP answer at all -> api_unreachable (request never reached a server)", api_r["wdCode"]=="api_unreachable", api_r)
    check("no Firebase session -> no_session, request not even sent", api_r["noSession"]=="no_session", api_r)
    check("empty API_BASE -> api_not_configured", api_r["noBase"]=="api_not_configured", api_r)
    check("no uncaught page errors", not errs, errs)
    br.close()
srv.shutdown(); print(f"\n{sum(results)}/{len(results)} passed"); sys.exit(0 if all(results) else 1)
