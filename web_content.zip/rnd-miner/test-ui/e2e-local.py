"""LOCAL end-to-end browser test: real www/index.html + real www/js/rnd-backend.js -> real worker/src/index.js (on SQLite via node:sqlite).
import faulthandler; faulthandler.dump_traceback_later(45, exit=True)
Only two things are fake: the Firebase SDK (a stand-in that signs in a verified user and returns an ID token signed by a local test key)
and the database engine (SQLite instead of D1). This is NOT a test of live Firebase or live Cloudflare."""
import sys, os, subprocess, threading, http.server, socketserver, functools, json, re, urllib.request, urllib.parse
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.join(HERE,"..","www")
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.ThreadingTCPServer.daemon_threads=True
srv=socketserver.ThreadingTCPServer(("127.0.0.1",0),functools.partial(Q,directory=ROOT)); port=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
api=subprocess.Popen(["node","--no-warnings",os.path.join(HERE,"..","worker","test","e2e-server.mjs")],stdout=subprocess.PIPE,text=True)
API="http://127.0.0.1:"+re.search(r"PORT (\d+)",api.stdout.readline()).group(1)
def control(**c): return json.load(urllib.request.urlopen(API+"/__control?c="+urllib.parse.quote(json.dumps(c))))
APP="export const initializeApp=(c)=>({cfg:c});"
AUTH="""
const LS=window.localStorage, K='fake_fb_user';
const mk=(email)=>({uid:'uid_alice',email,emailVerified:true,
  async reload(){}, async getIdToken(){const r=await fetch(window.RND_CONFIG.API_BASE+'/__token?claims='+encodeURIComponent(JSON.stringify({email})));return r.text()},
  async getIdTokenResult(){return {claims:{email_verified:true}}}});
const auth={get currentUser(){const e=LS.getItem(K);return e?mk(e):null},async authStateReady(){}};
export const getAuth=()=>auth;
export const createUserWithEmailAndPassword=async(a,e)=>{LS.setItem(K,e)};
export const signInWithEmailAndPassword=async(a,e,p)=>{if(p!=='password123'){const x=new Error('bad');x.code='auth/invalid-credential';throw x}LS.setItem(K,e)};
export const sendEmailVerification=async()=>{};export const sendPasswordResetEmail=async()=>{};export const signOut=async()=>{LS.removeItem(K)};
"""
R=[]
def check(n,c,x=""): R.append(bool(c)); print(("PASS  " if c else "FAIL  ")+n+((" -> "+str(x)) if (x and not c) else ""))
def app_visible(p): return p.evaluate("getComputedStyle(document.getElementById('mainApp')).display!=='none'")
def login(page):
    page.wait_for_selector("#authLogin",state="visible",timeout=15000)
    page.fill("#loginEmail","alice@example.com"); page.fill("#loginPass","password123"); page.click("#loginBtn")
    page.wait_for_function("getComputedStyle(document.getElementById('mainApp')).display!=='none'",timeout=10000)
def ensure_app(page):
    """After a reload: wait for the app to settle on either the main app or the login screen, then log in only if needed."""
    page.wait_for_function("getComputedStyle(document.getElementById('mainApp')).display!=='none'||getComputedStyle(document.getElementById('authLogin')).display!=='none'",timeout=15000)
    if not app_visible(page): login(page)
with sync_playwright() as p:
    br=p.chromium.launch(); ctx=br.new_context(); page=ctx.new_page(); page.set_default_timeout(15000); errs=[]; page.route(re.compile(r"fonts\.(googleapis|gstatic)\.com"),lambda r:r.abort()); page.on("pageerror",lambda e:errs.append(str(e))); page.on("console",lambda m:print("   [console]",m.text[:160]) if m.type in("error",) else None)
    page.route("**/firebase-app.js",lambda r:r.fulfill(body=APP,content_type="application/javascript"))
    page.route("**/firebase-auth.js",lambda r:r.fulfill(body=AUTH,content_type="application/javascript"))
    def cfg(r):
        t=open(os.path.join(ROOT,"firebase-config.js")).read()
        import re
        r.fulfill(body=re.sub(r'API_BASE: "[^"]*"','API_BASE: "'+cfg.base+'"',t),content_type="application/javascript")
    cfg.base=API; page.route("**/firebase-config.js",cfg)
    page.goto(f"http://127.0.0.1:{port}/index.html"); login(page)
    check("1. login (verified Firebase user) opens the app and loads state from the Worker", page.inner_text("#balance").startswith("0.0000"))
    page.click("#miningButton"); page.wait_for_function("document.getElementById('status').textContent.toLowerCase().includes('mining active')",timeout=10000)
    check("2. START MINING works: UI shows active, server created the session", True)
    rows=control(query="SELECT status,uid FROM sessions")["rows"]; check("3. session saved server-side", rows==[{"status":"active","uid":"uid_alice"}],rows)
    control(advance=30*60*1000); page.reload()
    ensure_app(page)
    page.wait_for_function("document.getElementById('status').textContent.toLowerCase().includes('mining active')",timeout=10000)
    ui=float(page.inner_text("#balance"))
    check("4. after 30 server-minutes the UI shows the server-credited balance (~0.00008 RENDER)", 0.00007<=ui<=0.00009, ui)
    check("5. reload/restart: the running session is restored from the server (not lost, not restarted)", control(query="SELECT count(*) c FROM sessions")["rows"][0]["c"]==1)
    control(advance=40*60*1000); page.reload()
    ensure_app(page)
    page.wait_for_function("parseFloat(document.getElementById('balance').textContent)>0.0001",timeout=10000)
    st=control(query="SELECT balance_units b, mining_status m FROM users")["rows"][0]
    check("6. session finished: balance 16668 units persisted, status idle", st=={"b":16668,"m":"idle"},st)
    page.evaluate("doLogout()"); page.wait_for_selector("#authLogin",state="visible",timeout=15000); login(page)
    page.wait_for_function("parseFloat(document.getElementById('balance').textContent)>0.0001",timeout=10000)
    check("7. logout -> login: balance still there (0.00017 shown = 0.00016668 RENDER)", float(page.inner_text("#balance"))>0.0001,page.inner_text("#balance"))
    # error honesty: backend down -> clear error, mining NOT shown as started
    control(dropTable="sessions"); page.reload(); 
    ensure_app(page)
    page.click("#miningButton"); page.wait_for_timeout(1500)
    txt=page.inner_text("#status"); check("8. database failure shows a clear backend message and does NOT claim mining started", "not started" in txt.lower() or "database" in txt.lower() or "server" in txt.lower(), txt)
    check("8b. ...and the button state is not 'active'", "mining active" not in txt.lower(), txt)
    # wrong server address
    cfg.base="http://127.0.0.1:9"; page.reload()
    page.wait_for_timeout(2500)
    body=page.inner_text("body").lower(); check("9. unreachable server address -> says the server could not be reached (not 'your internet')", "could not reach" in body or "[api_unreachable]" in body or "server" in body)
    check("no uncaught page errors", not errs, errs)
    br.close()
api.terminate(); srv.shutdown(); print(f"\n{sum(R)}/{len(R)} passed"); sys.exit(0 if all(R) else 1)
