// Extracts the REAL lock logic from www/index.html and checks the 0.07 RENDER unlock boundary.
// Run: node test-ui/withdraw-lock.test.mjs
import fs from "node:fs";
import assert from "node:assert";
const html = fs.readFileSync("www/index.html", "utf8");
const a = html.indexOf("const MIN_WD_UNITS="), b = html.indexOf("let wdBusy", a);
const c = html.indexOf("function wdUnlocked(){"), d = html.indexOf("function updateBalance(){", c);
assert(a > 0 && b > a && c > 0 && d > c, "lock code not found");
const make = (srv) => new Function("srv", html.slice(a, b) + "\n" + html.slice(c, d) + "\nreturn { wdUnlocked, MIN_WD_UNITS };")(srv);
let n = 0; const ok = (c, m) => { assert(c, m); n++; console.log("PASS  " + m); };
ok(make(null).wdUnlocked() === false, "no server state yet -> locked");
ok(make({ balanceUnits: 0 }).wdUnlocked() === false, "0 RENDER -> locked");
ok(make({ balanceUnits: 6999999 }).wdUnlocked() === false, "0.06999999 RENDER -> locked");
ok(make({ balanceUnits: 7000000 }).wdUnlocked() === true, "0.07 RENDER -> unlocked");
ok(make({ balanceUnits: 7000001 }).wdUnlocked() === true, "0.07000001 RENDER -> unlocked");
ok(make({ balanceUnits: 5e9 }).MIN_WD_UNITS === 7000000, "UI minimum constant is 7,000,000 units (0.07 RENDER)");
ok(!/PKR 40|MIN_WD_PKR/.test(html), "no PKR 40 minimum text left in the UI");
console.log("\n" + n + " checks passed");
