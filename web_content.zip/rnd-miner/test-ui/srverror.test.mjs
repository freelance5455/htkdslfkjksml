// Extracts the REAL srvError() from www/index.html and checks that each failure kind gets its own accurate message.
// Run: node test-ui/srverror.test.mjs
import fs from "node:fs";
import assert from "node:assert";
const html = fs.readFileSync("www/index.html", "utf8");
const start = html.indexOf("function srvError(e){"), end = html.indexOf("window.showConversion=", start);
assert(start > 0 && end > start, "srvError not found");
const make = (online) => new Function("navigator", html.slice(start, end) + "\nreturn srvError;")({ onLine: online });
const s = make(true), off = make(false);
const E = (code, message) => Object.assign(new Error(message), { code });
let n = 0; const ok = (c, m) => { assert(c, m); n++; console.log("PASS  " + m); };
const A = (code, message) => s(E("api/" + code, message));

ok(/address is not set/i.test(s(E("api_not_configured", "x"))) && /NOT started/.test(s(E("api_not_configured", "x"))), "API_BASE empty -> 'address not set', says mining was NOT started");
ok(/Could not reach the mining server/.test(s(E("api_unreachable", "x"))) && /NOT started/.test(s(E("api_unreachable", "x"))) && !/Your internet is working/.test(s(E("api_unreachable", "x"))), "no HTTP answer while online -> 'could not reach server', no blaming of the person's internet");
ok(/No internet connection/i.test(off(E("api_unreachable", "x"))), "no HTTP answer while the device is offline -> offline message");
ok(/wrong or old URL/.test(s(E("api_bad_response", "x"))), "answer that is not our API -> wrong URL message");
ok(/not fully set up/.test(A("failed-precondition", "backend_not_configured:database_binding_missing")), "Worker missing DB binding -> setup message with the exact missing piece");
ok(/database is not set up yet/i.test(A("failed-precondition", "backend_database_missing")), "database schema missing -> its own message");
ok(/out of date/i.test(A("failed-precondition", "backend_schema_outdated")), "schema outdated -> its own message");
ok(/could not check your login/i.test(A("unavailable", "auth_keys_unreachable")), "Google key fetch failed -> login-check message");
ok(/log in again/i.test(A("unauthenticated", "sign_in_required")), "unauthenticated -> log in again");
ok(/verify your email/i.test(A("failed-precondition", "email_not_verified")), "email not verified -> verify your email");
ok(/already running/i.test(A("already-exists", "session_already_active")), "session already active -> already running");
ok(/temporarily unavailable/i.test(A("unavailable", "backend_unavailable")), "database unavailable -> temporary outage");
ok(/usage limit/i.test(A("resource-exhausted", "backend_quota")), "quota -> usage limit message");
ok(/Too many attempts/.test(A("resource-exhausted", "rate_limited:120")), "rate limit -> 'Too many attempts'");
ok(/tap again/i.test(A("aborted", "backend_busy")), "write contention -> tap again");
ok(/server hit an error/i.test(A("internal", "backend_error")) && /Nothing was changed/.test(A("internal", "backend_error")), "unknown server error -> 'server error, nothing changed'");
ok(/not found/i.test(A("not-found", "not_found")) && /API_BASE/.test(A("not-found", "not_found")), "404 from the address -> check API_BASE");
ok(/does not affect withdrawals/i.test(A("unavailable", "price_unavailable")), "price unavailable -> only the optional estimate, never blocks withdrawals");
ok(/Insufficient balance/.test(A("failed-precondition", "insufficient_balance")) && /not finished/.test(A("failed-precondition", "withdrawal_already_open")), "withdrawal refusals keep their messages");
ok(!/Cannot reach the server/.test(html.slice(start, end)), "old catch-all 'Cannot reach the server' mapping is gone");
ok(/at least 0\.07 RENDER/.test(A("failed-precondition", "below_minimum:0.07")) && !/PKR/.test(A("failed-precondition", "below_minimum:0.07")), "below minimum -> says 0.07 RENDER, no PKR minimum");
ok(/locked until your confirmed balance reaches 0\.07 RENDER/.test(A("failed-precondition", "withdrawal_locked:0.07")), "withdrawal_locked -> explains the 0.07 RENDER lock");
console.log("\n" + n + " checks passed");
