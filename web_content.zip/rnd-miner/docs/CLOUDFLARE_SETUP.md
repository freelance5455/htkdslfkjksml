# Free backend setup (Cloudflare Workers + D1) — no paid plan, no card

## 0. Why the mining server "did not answer" (diagnosis)
The old app called a Firebase **Cloud Function** (`startMining`, region `us-central1`). **Cloud Functions cannot be deployed on the Spark (free) plan; Firebase requires Blaze.** On Spark the deploy is refused, so the URL
`https://us-central1-render-minning-88b6c.cloudfunctions.net/startMining` has nothing behind it. The Firebase SDK reports "no readable answer" as `functions/internal`, and the old app turned that into "The server did not answer… probably not deployed or is blocked".
That matches the code and the plan, but **I could not probe your live URL** (this workspace blocks Firebase hosts), so the "not deployed" conclusion is reasoned from the plan limits and the code, **not a measured fact**. You can measure it yourself in 10 seconds: `curl -i -X POST -H "content-type: application/json" -d "{\"data\":{}}" https://us-central1-render-minning-88b6c.cloudfunctions.net/startMining` — a 404 "Error: Page not found" = not deployed.
Your internet was never the problem.

## 1. What changed (architecture)
| Part | Before | Now |
|---|---|---|
| Login, verification email, reset email | Firebase Auth | **Firebase Auth (unchanged)** |
| Trusted server | Firebase Cloud Functions (Blaze) | **Cloudflare Worker** `worker/` (free plan) |
| Database | Firestore | **Cloudflare D1** (SQLite, free plan) |
| Who is the user | callable `request.auth` | Worker verifies the **Firebase ID token** (RS256, Google's public keys, audience, issuer, expiry); uid comes only from it |

Free limits (Cloudflare, check current numbers on their pricing page): Workers 100,000 requests/day; D1 5 million rows read/day, 100,000 rows written/day, 5 GB. The app syncs every 5 min and writes only on start/finish/withdraw, so a few thousand active users fit. Hitting the limit returns a clear `backend_quota` error; nothing is billed on the free plan.

## 2. Deploy (about 15 minutes, on your computer)
1. Create a free account at https://dash.cloudflare.com (no card).
2. Install Node 18+. In the project: `cd worker && npm install` then `npx wrangler login`.
3. `npm run db:create` → copy the printed `database_id` into `worker/wrangler.toml` (`database_id = "..."`).
4. `npm run db:schema` (creates tables; safe to re-run; never deletes data).
5. Admin secret (for withdrawals): `npx wrangler secret put ADMIN_TOKEN` and paste 32+ random characters (e.g. `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`). Keep a copy; never put it in the app.
6. `npm run deploy` → it prints your address, like `https://rnd-miner-api.<you>.workers.dev`.
7. Paste that address into `www/firebase-config.js` as `API_BASE: "https://rnd-miner-api.<you>.workers.dev"` (no trailing slash). Rebuild the APK / re-publish the web build.
8. Check it: `node scripts/diagnose-mining.mjs` (add `RND_EMAIL=... RND_PASSWORD=...` and `--start` for a real login + start). It prints PASS/FAIL per step and says which step is broken.
9. Firebase Console → Authentication → Sign-in method: Email/Password must be enabled (already needed before).
`FIREBASE_PROJECT_ID` is already set to `render-minning-88b6c` in `wrangler.toml`. No Firebase service-account key and no secret is in the app or the Worker's public settings.

## 3. Security model
- The app sends only `Authorization: Bearer <ID token>` and tiny bodies. It never sends a user id, balance, or time; any such fields are ignored (tested).
- Every request needs a valid token **and** `email_verified === true`.
- All times are server time. Rewards = (server time inside the session) × rate, computed cumulatively, so repeating a request can never credit twice and changing the phone clock changes nothing.
- Every balance change is one atomic D1 batch guarded by a per-user version counter: two parallel requests cannot both succeed (tested with parallel start / withdraw / reject).
- Rates: base 0.00016668 RENDER/h, hard ceiling 0.000947/h (unchanged). Sessions stay 1 hour. No 60/40 split, no auto scaling, no Daily Reward.
- Rate limits: start mining 10/hour, withdrawals 5/hour (stored in D1), state/price in memory.

## 4. Rewarded ads (not live yet)
Boosts exist only on the server and only from Google's **signed AdMob server-side-verification callback** `GET /adReward`: signature checked with Google's published keys, must be **your** ad unit (`ADMOB_REWARDED_AD_UNIT_ID` in `wrangler.toml`; empty = refuse everything), `transaction_id` is a primary key (replay-proof), max 10/day (Pakistan calendar day), each boost = 2× for 10 min, no cash reward for watching.
The Android app has **no ad SDK yet**, so the Watch Ad button stays disabled and honest. To finish: add the AdMob rewarded ad to the APK with `userId = Firebase uid` in the SSV options, set the ad unit id, set the SSV callback URL in AdMob to `https://<your-worker>/adReward`, then set `ADS_CONFIGURED: true`. Provider = AdMob (the existing integration in the code); I did not assume another.

## 5. Withdrawals: what is real and what is manual
**New in v3.1: use the Admin Panel at `/admin` (see `docs/ADMIN_PANEL.md`) instead of the command line.** The command-line tool below still works and now also lists paid and rejected requests (`node worker/tools/admin.mjs list all`).

The app stores each request in D1 (`withdrawals`): user, amount, currency (RENDER), PKR value at request, destination (Binance UID or EasyPaisa account), request time, status, request id (= reference), and later the payout reference. The RENDER is held (deducted) at request time; one open request per user; duplicate request ids never deduct twice.
**Nothing is paid automatically. There is no payment integration.** Statuses: `requested → approved → paid`, or `rejected` (refunds the hold, once). Only you can change a status, with your admin token:
```
export RND_API_BASE=https://rnd-miner-api.<you>.workers.dev
export RND_ADMIN_TOKEN=<your ADMIN_TOKEN>
node worker/tools/admin.mjs list            # open requests; or: list all | paid | rejected | approved | requested
node worker/tools/admin.mjs approve  <uid> <requestId>
# now send the money yourself (Binance transfer / EasyPaisa) from YOUR account with enough funds, then:
node worker/tools/admin.mjs markpaid <uid> <requestId> <the real transaction id>      # Saturday/Sunday PKT only
node worker/tools/admin.mjs reject   <uid> <requestId> "reason"                        # refunds the user
```
"paid" requires a payout reference and is refused otherwise. To automate payouts later you would need a provider API with credentials and a funded account (e.g. Binance Pay/withdraw API with a restricted key); not built, not promised.
Reality check: the 0.07 RENDER minimum versus 0.00016668 RENDER/h earned means reaching the minimum can take a long time; the app shows the live minimum.

## 6. Existing data
Nothing was deleted or reset. The old Firebase functions were never deployable on Spark, so no balances existed in Firestore to migrate. If you do have documents in Firestore `users/*` from an earlier test, tell me and I will write an import script; the Firestore data is untouched. The old functions code is kept in `legacy/firebase-functions/` (not deployed).

## 7. Operating notes / limits
- A Firebase ID token stays valid up to 1 hour; a user disabled in Firebase can act until their token expires.
- App Check is not enforced (needs Play Integrity in the APK).
- Rank/level display is still device-only (cosmetic), as before.
- D1 free-limit exhaustion → `backend_quota` message until the daily reset.

## 8. Withdrawal minimum vs. earning speed (flagged, NOT changed)
The minimum is 0.07 RENDER (v3.1.2; it was PKR 40 before). Earning is 0.00016668 RENDER per mining hour; a verified ad boost doubles it to 0.00033336 for 10 minutes (the 0.000947 ceiling is never reached by a 2x boost). Hours of mining needed to reach PKR 40 = 40 / (RENDER price in PKR x 0.00016668). Illustration only (not live prices): at PKR 500 per RENDER about 480 hours, at PKR 1,000 about 240 hours, at PKR 2,000 about 120 hours. Sessions last 1 hour and must be restarted. If this is not what you intend, tell me which number to change (the minimum or the rate); I will not change financial rules on my own.

## 9. Live test checklist (only you can do these; they need your real accounts)
1. Open `https://rnd-miner-api.afridiallahdad3.workers.dev/api/health`: must show "ok":true and "database":"ok" (DONE by you on 2026-10-15).
2. Rebuild the APK (or open the web build) so it contains the new `API_BASE`.
3. Log in with a verified account, press START MINING: countdown must start. In Cloudflare > D1 > rnd-miner-db > Console run `SELECT uid, mining_status, balance_units FROM users;` and `SELECT * FROM sessions;`: one row each.
4. Close the app, reopen, log in again: the countdown/balance is still there. Log in on a second device: same balance.
5. Open Convert/price: shows a PKR price (needs the server to reach CoinGecko). If it says unavailable, withdrawals are refused on purpose.
6. Withdrawal: only a real small request with your own account; check `SELECT * FROM withdrawals;`. It stays "requested" until YOU approve and pay it by hand.
7. Any error text ends with a code in [brackets]; send it to me.
