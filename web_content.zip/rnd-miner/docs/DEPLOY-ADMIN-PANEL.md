# Deploy the Admin Panel update (v3.1.1) to the EXISTING production Worker

**Prepared and tested locally only. Nothing in this ZIP was deployed, and no production SQL was run.** Read `Section 9` for what is still unverified.

Confirmed production resources (from the owner's Cloudflare dashboard):

| Item | Value |
|---|---|
| Worker | `rnd-miner-api` (`https://rnd-miner-api.afridiallahdad3.workers.dev`) |
| D1 database name | `rnd-miner-db` |
| D1 database ID | `78bec0c3-4ec9-4ab9-b9c1-b5489c6492d3` |
| Binding variable | `DB` (type: D1 database) |
| Live data when checked by the owner | 2 users, 0 withdrawals |

The older database name without the `-db` ending (used in earlier instructions) is **not** your database. No step below creates a database or changes the binding.

`worker/wrangler.toml` now carries the name and ID above, but it is **preparation only**. Do **not** run `wrangler deploy`. Deploy by pasting code into the existing Worker (Section 5): that changes only the code and keeps the Worker's bindings, variables and secrets.

Files you need (all in `DEPLOY-FILES/`): `0-preflight-READONLY.sql`, `3-migration-0001-admin-panel.sql`, `1-worker-code.js`. (`2-database-tables.sql` is for a brand-new empty database only: do not use it now.)

## 1. Read-only checks (changes nothing)
1. Cloudflare dashboard > **Workers & Pages** > `rnd-miner-api` > **Settings** > **Bindings**. The row `DB` must say `rnd-miner-db`. If it says anything else, **stop** and tell me.
2. **Storage & databases** > **D1** > `rnd-miner-db`: the ID shown must be `78bec0c3-4ec9-4ab9-b9c1-b5489c6492d3`.
3. Open the **Console** tab of `rnd-miner-db`, paste `0-preflight-READONLY.sql` (one statement at a time if only the last result shows). Every line is a SELECT or PRAGMA. Check: tables listed; `users` has `created_at`; `ledger` has `type` and `request_id`; `audit` has `id`, `uid`, `type`; the duplicate query returns no rows; counts are 2 users, 0 withdrawals. Save the outputs in a private note.

## 2. Backup (do this BEFORE any change)
You need a backup you have checked, not just a command that ran.
- **Automatic safety net:** D1 keeps point-in-time history (7 days on the Workers Free plan, 30 days on Paid). Record the current restore point: `npx wrangler d1 time-travel info rnd-miner-db` and copy the bookmark it prints into your private note.
- **Download a full export** (needs a computer with Node.js; run in the `worker/` folder):
  ```
  npx wrangler login
  npx wrangler d1 export rnd-miner-db --remote --output=rnd-miner-db-backup-2026-10-15.sql
  ```
  Do it at a quiet time: an export can pause database writes for a moment.
- **Verify the file:** it exists, is not empty, opens in a text editor, contains `CREATE TABLE` for users, ledger, audit, sessions, withdrawals, ad_events, rate_limits, system, and `INSERT` lines for your 2 users. Keep a copy off the computer.
- **No command line?** In the D1 Console run `SELECT * FROM users;`, `SELECT * FROM ledger;`, `SELECT * FROM audit;`, `SELECT * FROM sessions;` and copy each result into a text file. With 2 users this is small. It is a record, not a restorable dump; the Time Travel bookmark above is the real restore path.

**Do not continue until the backup is verified.**

## 3. Set or rotate `ADMIN_TOKEN` safely
Your earlier health check showed `adminConfigured:false`, so this may be the first time it is set; the steps are the same for a rotation.
1. Generate 32+ random characters in a password manager (or `openssl rand -hex 32`). **Do not paste it into this chat, a file, a screenshot or a URL.**
2. Dashboard: `rnd-miner-api` > **Settings** > **Variables and secrets** > add or edit `ADMIN_TOKEN`, type **Secret**, paste, **Deploy**. (Command line: `npx wrangler secret put ADMIN_TOKEN`, paste at the hidden prompt.)
3. Save it in the password manager. The old token stops working immediately.
4. After deploying the new code (Section 5): unlock `/admin` with the new token. If you want to confirm the old token is dead, try it **once**: 5 wrong tokens lock your IP out for 15 minutes.

## 4. Migration (NOT TO BE RUN until Section 2 is verified)
Target: **`rnd-miner-db`, ID `78bec0c3-4ec9-4ab9-b9c1-b5489c6492d3`** only.
- It runs 4 `CREATE ... INDEX IF NOT EXISTS` statements. It cannot delete, reset or rewrite users, balances, sessions, ledger or withdrawals, and it is safe to run twice. Locally (SQLite stand-in) it was run twice on a pre-v3.1 schema with sample rows: all table data identical afterwards, exactly 4 indexes added.
- **Dashboard:** D1 > `rnd-miner-db` > **Console** > paste all of `3-migration-0001-admin-panel.sql` > **Execute** (paste statement by statement if it complains).
- **Command line (alternative):** `cd worker && npx wrangler d1 execute rnd-miner-db --remote --file=./migrations/0001_admin_panel.sql`
- **Check:** re-run the preflight index query: `audit_type`, `audit_uid_type`, `ledger_admin_adjustment_once`, `users_created` now appear. Counts are still 2 users, 0 withdrawals.

## 5. Deploy the Worker code (dashboard paste)
1. Dashboard > `rnd-miner-api` > **Edit code**. **Before changing anything:** select all the current code, copy it, and save it as `previous-worker-code-2026-10-15.js` (this is your rollback).
2. In the code box press Ctrl+A, Delete. Open `DEPLOY-FILES/1-worker-code.js` (same file as `worker/dist/worker-single.js`), copy all, paste, **Deploy**.
3. Do **not** touch Settings, Bindings, Variables or the secret. Afterwards check **Settings** again: `DB` still points to `rnd-miner-db`, `FIREBASE_PROJECT_ID` and `ALLOWED_ORIGINS` still exist, and `ADMIN_TOKEN` is listed as a secret.

## 6. Verify
1. Open `https://rnd-miner-api.afridiallahdad3.workers.dev/api/health`. Expected: `"ok":true`, `"service":"rnd-miner-api"`, `"database":"ok"`, `"firebaseProjectId":true`, `"adminConfigured":true`, `"adUnitConfigured":false`. If `database` is not `ok`, roll back (Section 8).
2. Open `.../admin`: the unlock screen appears. Enter the token. Dashboard shows 2 users, withdrawals all 0.
3. Press the consistency check. It is read-only. If it reports a mismatch, **do not fix it with SQL**: send me the screen.
4. In the normal app: log in, check your balance and mining countdown look the same as before.

## 7. Test with YOUR OWN test account only (no real user funds)
Never adjust the other user. Never change a balance with SQL.
1. `/admin` > **Users** > search your test account by email, name or UID. Note its settled balance (write it down). Prefer a moment when it is **not** mining.
2. **Adjust balance** > Add `1` RENDER, reason `TEST admin panel`. The result must show before and after. Open the user: the ledger has one `admin_adjustment` row; **Adjustments** shows the reason.
3. Open the app: the balance shows the +1. Tap the same adjustment dialog's button twice: only one change is applied.
4. Subtract `1` (reason `TEST undo`), or use **Set to** with the exact balance you wrote down. Dashboard and the consistency check must be clean.
5. Withdrawal approve/reject/mark-paid is not needed for this goal and there are 0 real withdrawals. Mark paid is Saturday/Sunday Pakistan time only.

## 8. Rollback
- **Code:** Edit code > select all > paste `previous-worker-code-2026-10-15.js` > Deploy. The 4 indexes are harmless to the old code, so leave them. (The Worker's Deployments/Versions page may also offer a rollback; the pasted file is the sure path.)
- **Admin token:** nothing to roll back; set a new secret if you think it leaked.
- **Database:** only if data was damaged. `npx wrangler d1 time-travel restore rnd-miner-db --bookmark=<the bookmark from Section 2>` returns the **whole** database to that moment, so any user activity after it is lost; use it only with care. Do not import the export file into the live database without checking with me first.
- Optional, only if ever required: `DROP INDEX IF EXISTS users_created;` (same for the other 3 names). Not needed for a rollback.

## 9. Not verified (needs you, live)
Everything above was tested **locally** (SQLite stand-in for D1, self-signed fake Firebase tokens, headless Chromium). Not tested: the live Worker, the live D1 (its real `users` columns: `created_at` is only checked by the preflight), real Wrangler runs, real Firebase login, the Android app, the dashboard menus (names change), AdMob.
