# Deploy v3.1.3 (withdrawals without PKR conversion)

Tested locally only (SQLite stand-in for D1, fake tokens, headless Chromium). Not deployed or live-verified. **No database migration, no new secrets, no setting changes.**

1. Backup: `npx wrangler d1 time-travel info rnd-miner-db` and/or `npx wrangler d1 export rnd-miner-db --remote --output=backup.sql` (check it is not empty).
2. Save the current Worker code (Dashboard > Workers & Pages > rnd-miner-api > Edit code > copy to previous-worker-code.js) for rollback.
3. Replace the Worker code with all of `DEPLOY-FILES/1-worker-code.js` and Deploy. Leave Bindings/Variables/Secrets alone.
4. Open `/api/health`: `"ok":true`, `"database":"ok"`.
5. Publish the updated app (`www/` or `dist/RND-Miner-single.html`; Android: `npm run android:sync`, rebuild APK). Old app builds also work: the Worker no longer needs a price.
6. Verify with your own test account: balance >= 0.07, request 0.07 via EasyPaisa and Binance -> accepted, balance drops by 0.07, appears in history and ledger (`withdrawal_hold`). 0.069 -> `below_minimum:0.07`. Same requestId again -> no second deduction.
7. Optional: confirm the fix holds when CoinGecko is unreachable (it is never called now: Worker logs show no `price fetch failed` on withdrawals).

Rollback: paste `previous-worker-code.js` back. No data was changed by this release.

Note: the text "Conversion cannot be completed" does not exist anywhere in this project's source. If you still see it after deploying, the live Worker/app is a different build than this ZIP - check that the deployed code matches `DEPLOY-FILES/1-worker-code.js`.
