# Previewing RND Miner

## Why the screen used to be blank
The first Firebase version loaded its own files with ES-module `import`. Browsers block that when `index.html` is opened straight from a file (`file://...`), so the main script never started and every screen stayed hidden: only the black background showed. This is fixed: the app now loads with ordinary scripts, and a safety screen always shows either "Loading", a Retry button, or the reason it could not start.

## Best way: a local web server (works on computer and phone)
1. Install Node.js (version 18 or newer) from nodejs.org if you do not have it.
2. Unzip the project. Keep all folders together (`www/`, `www/js/`, ...).
3. Open a terminal in the project folder (the one containing `package.json`) and run:
   `npm run preview`
   (If npm is not available: `node scripts/serve.mjs`, or `python3 -m http.server 8080 --directory www`.)
4. It prints two addresses. On the computer open `http://localhost:8080`.
5. **On your phone:** connect the phone to the SAME Wi-Fi as the computer and open the second address it printed, for example `http://192.168.1.20:8080`. If it does not load, allow Node through the computer's firewall (Windows asks the first time) and check that the Wi-Fi does not isolate devices (guest networks often do).
6. Stop with Ctrl+C.

## One-file option
`npm run build:single` creates `dist/RND-Miner-single.html`, a single file you can send to a phone and open. The screen will load. Whether Firebase sign-in works from a file address is **not verified**; use the server method above for real testing.

## What the preview shows
- The phone needs internet: the app loads the Firebase library from Google and talks to your Firebase project.
- Until the backend (Cloud Functions) is deployed, sign-up, verification email, login and password reset work (Firebase Authentication, free Spark plan), but the balance, mining and withdrawals need the deployed backend (Blaze plan, see FIREBASE_SETUP.md).
- If you see "Could not connect to Firebase", check the phone's internet and tap Retry.

## Installed Android app
The APK built with Capacitor serves the same files from `https://localhost` inside the app, which also works.
