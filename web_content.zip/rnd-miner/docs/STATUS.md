# Status (honest report) — updated 2026-10-14

**The project is NOT complete.** The code is written, but it has never run against your real Firebase project and no APK was built, because the environment I worked in blocks Firebase, npm, Maven and Google downloads.

## 1. What genuinely works (verified here)
- Demo mode is gone: no demo backend, fake user, demo balance or demo labels remain. With Firebase missing or unreachable the app shows an error and a Retry button (tested in a browser).
- The page logic: login screen, emailed-code screen, locked app until code accepted, server-driven balance and mining countdown, withdrawal error/success handling, logout button (tested in headless Chromium against a **stub** backend — this is NOT a Firebase test).
- Server logic as pure code, 19 unit tests passing (`npm run test:functions`): mining math and rates (0.00016668 base, 0.000947 ceiling), no double-crediting on repeated settlement, boost 2x for 10 min, 10/day cap, code expiry / single use / attempt limit / resend limits, price staleness rejection, PKR 40 minimum rounded up, destination validation, distinct withdrawal statuses, Saturday/Sunday payout days, AdMob signature check (with a locally generated key, not Google's).

## 2. Written but NOT run against real services
- Cloud Functions (`functions/index.js`): login code by email, mining start/settle with server time, price lookup (CoinGecko), withdrawals with idempotent requestId, ledger and audit records, AdMob callback endpoint. Only syntax-checked.
- `firestore.rules` (deny all client access), `firebase.json`, owner admin tool `functions/tools/admin.js`.
- Email/password registration, verification link, login, reset, persistent session, logout via the Firebase JS SDK (`www/js/rnd-backend.js`). Not run.

## 3. Not implemented
- Rewarded ads: no ad SDK in the app; Watch Ad is disabled and says so. Server endpoint exists but is untested and unconnected.
- Rank/level progress is still stored only on the device (cosmetic layer).
- App Check, Supabase data migration (nothing was migrated or deleted), admin screen (CLI only).
- Emulator tests for rules/functions (need the Firebase CLI and Java).

## 4. APK
Not built. Android SDK and Gradle downloads are blocked here.

## 5. Real-service tests done
None. Registration, verification, login, logout, password reset and Firestore saves/reads are all **untested**.

## 6. Manual steps left
See `docs/FIREBASE_SETUP.md`: add the Web app and paste its config into `www/firebase-config.js`; enable Email/Password; create Firestore; upgrade to Blaze (your approval, costs explained there); set secrets; deploy; run the real tests.

## 7. Decisions you may want to change
- Mining time is credited by the server for the whole 1-hour session even if the app is closed (old demo only counted time with the screen open).
- Boost day = Pakistan calendar day. Payouts can only be marked paid on Saturday/Sunday Pakistan time.
- Price source: CoinGecko `render-token` in PKR, refused if older than 10 minutes. Withdrawal amount is still typed in RENDER; the server enforces the PKR 40 minimum.
- The client cannot read Firestore at all; it asks the server for state.
- Both the email link (once) and the emailed 6-digit code (every login) are required.

## Update 2026-10-14: hardening
- Ad callbacks are refused unless the ad unit matches `ADMOB_REWARDED_AD_UNIT_ID`; empty = refuse all. Replays and the daily cap are decided by one tested function.
- `getState` no longer writes on every call (one read, no write mid-session); client syncs every 5 min instead of every 60 s; withdrawal history only on request.
- Rate limits on login codes, mining start, withdrawals, state and price. App Check: client key and server switch prepared, **off by default and untested**; Android Play Integrity provider **not implemented**.
- Fixed: boost segments of an unfinalised session are no longer pruned early (would have under-credited late finalisation).
- Tests: 35 pure-logic tests pass. No live Firebase, emulator, deployment or APK test was run.

## Update 2026-10-14 (b): blank black screen fixed
- Cause (reproduced): opening `www/index.html` from a file (`file://`) made the browser block the ES-module `import` of `js/rnd-backend.js` and `firebase-config.js` (CORS, origin "null"). The main script never ran and all screens start hidden, so only the black background showed.
- Fix: those two files are now ordinary scripts (`window.RND_CONFIG`, `window.RNDBackend`); no ES-module imports remain. A safety screen (plain HTML) shows "Loading", a readable error, or a Retry/Reload button for: missing files, hung or failed Firebase connection (20 s timeout), script errors, or a main script that never starts (8 s watchdog).
- Verified in headless Chromium (browser tests only, NOT Firebase): file:// and http:// both show the screens; five injected failure modes each show readable text. Whether Firebase sign-in works from a file address is unverified; use `npm run preview` (docs/PREVIEW.md).
