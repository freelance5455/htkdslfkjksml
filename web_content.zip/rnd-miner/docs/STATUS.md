# Status update (v3.1.2): minimum withdrawal changed to 0.07 RENDER (tested locally; NOT deployed, NOT live-tested)
- See CHANGELOG.md and docs/DEPLOY-MIN-WITHDRAWAL.md. No database migration. Balances, history, auth, Binance/EasyPaisa unchanged.
- The reported withdrawal error was NOT reproduced and no cause was verified, so nothing was "fixed" for it (details in CHANGELOG.md).

# Status update 2026-10-15 (v3.1.1): deployment preparation for the existing production Worker (NOT deployed, NOT live-tested)
- Owner-confirmed production database: `rnd-miner-db`, ID `78bec0c3-4ec9-4ab9-b9c1-b5489c6492d3`, binding `DB` on Worker `rnd-miner-api` (2 users, 0 withdrawals at the time). `worker/wrangler.toml` now carries them (preparation only: do not `wrangler deploy`; paste the code in the dashboard). The older name without the `-db` ending was removed from every command and doc.
- Added: `docs/DEPLOY-ADMIN-PANEL.md` (backup, token, migration, dashboard paste, verify, test-account procedure, rollback), `worker/tools/preflight-readonly.sql` (SELECT/PRAGMA only), `DEPLOY-FILES/0-preflight-READONLY.sql` and `3-migration-0001-admin-panel.sql`, `worker/test/migration.test.js` (10 checks: migration references only existing columns, only indexes, idempotent, rewrites no row, same indexes as a fresh install, adjustment endpoint works on a migrated live-like DB, wrangler.toml pinned, no old DB name, no hardcoded admin token).
- Admin Panel code, mining rules, withdrawal rules and the app are unchanged in this update.
- Unverified live: the real `users` columns (only `ledger`/`audit` columns were reported by the owner), Cloudflare/Wrangler behaviour, the deployed Worker, Firebase login, Android.

# Status update 2026-10-15 (v3.1): Admin Panel added (tested locally; NOT yet verified on your live Worker)
- Added `/admin` (dashboard, users, balance adjustments, all four withdrawal statuses), admin lockout + rate limiting, no-CORS admin API, read-only consistency check, `worker/migrations/0001_admin_panel.sql`. Details: `docs/ADMIN_PANEL.md`.
- Mining rules, rates, 1e8 units, withdrawal minimum, Sat/Sun payout rule, ad rules: **unchanged** (constants verified by test).
- Rewarded ads: still NOT working and still correctly refused: `ADMOB_REWARDED_AD_UNIT_ID` is empty and the app contains no ad SDK (`ADS_CONFIGURED:false`). Needed: an AdMob rewarded ad unit, the AdMob SDK in the Android app with server-side verification pointing at `<worker>/adReward`, then the ad unit id set as a Worker variable and a REAL ad watched on a test device. Until then no boost can be granted.
- Local tests only so far (SQLite + self-signed tokens + Chromium). Live checks are listed in README / the hand-over message.

# Status update 2026-10-15: Worker deployed by the owner, app connected (NOT yet live-tested end to end)
- Owner deployed the Worker + D1 and reported `GET https://rnd-miner-api.afridiallahdad3.workers.dev/api/health` = {"ok":true,"database":"ok","firebaseProjectId":true,"adUnitConfigured":false,"adminConfigured":false}. (Reported by the owner; my workspace cannot reach workers.dev, so I could not repeat it.)
- Changed: `www/firebase-config.js` API_BASE = that URL; `test-ui/e2e-local.py` now overrides API_BASE with a regex (it used to match only an empty value); `dist/RND-Miner-single.html` rebuilt.
- Client/Worker contract reviewed line by line (rnd-backend.js + index.html vs worker/src/index.js, db.js publicState): endpoints getState / startMining / getPrice / requestWithdrawal, `Authorization: Bearer <Firebase ID token>`, bodies (requestId, method, binanceUID | accountName + accountNumber, amount) and response fields (serverNow, balanceUnits, mining{status,startedAt,endsAt,creditedUnits}, boost{endsAt,count,segments}, renderPkr, minRender, minPkr, withdrawals[]) all match. No mismatch found, no code change needed. No demo/mock mining or fake success path exists; ads: Watch Ad stays disabled (ADS_CONFIGURED=false) and never grants anything.
- Withdrawal minimum (0.07 RENDER since v3.1.2; was PKR 40) and rates (0.00016668 base, 0.000947 ceiling, 10 boosts/day, 2x for 10 min) are identical in the original project, the UI texts and the Worker. No conflict, nothing changed. See docs/CLOUDFLARE_SETUP.md section 8 for the practical consequence.
- Local tests (SQLite + fake Firebase, NOT the live service): worker 42/42, error-messages 20/20, sign-in screens 20/20, client SDK 17/17, browser end-to-end 11/11.
- LIVE tests: none from my side (workers.dev and Firebase are blocked in my workspace). The owner's /api/health result is the only live evidence. A real login + START MINING on the deployed Worker is still to be done by the owner (docs/CLOUDFLARE_SETUP.md section 9).

# Status update 2026-10-14 (f): no-command-line deployment
- API_BASE is still EMPTY on purpose: the Worker URL only exists after it is created in the owner's Cloudflare account. Not deployed, not live-tested (Cloudflare is unreachable from my workspace).
- Added: START-HERE.md (dashboard-only steps), DEPLOY-FILES/ (single-file Worker + SQL), scripts/build-worker-single.mjs, worker/test/bundle.test.js (5 local smoke tests of the single-file build; worker suite now 42 pass).
- Mining is NOT confirmed fixed until /api/health shows database ok and a real login + START MINING works.

# Status (honest report) — updated 2026-10-14 (e): free backend on Cloudflare

## Cause of the mining error and what was done
- **Cause (reasoned from code + plan, NOT measured live):** `startMining` was a Firebase Cloud Function; Cloud Functions need the Blaze plan, so on Spark it could not be deployed and the app got no answer. The live URL could not be probed from my workspace (Firebase hosts are blocked there). You can confirm with the `curl` in `docs/CLOUDFLARE_SETUP.md` section 0.
- **Fix:** new trusted backend `worker/` (Cloudflare Worker + D1, free plan) keeping Firebase Auth. `www/js/rnd-backend.js` now calls it with the Firebase ID token. Old functions archived in `legacy/firebase-functions/`.
- **Bug I introduced and fixed during this work:** a quote character in a new error string broke the page script (caught by the browser test).

## Test results, by kind
- **Local unit/integration (real SQLite engine, real schema, real Worker code, fake Firebase signing key, fake Google/CoinGecko responses): 37 tests pass** (`npm run test:worker`): token forgery/expiry/wrong project/unverified email; client-sent uid/balance/time ignored; start mining once even with parallel requests; server-time crediting without double credit; persistence across new tokens; boost grant/replay/cap/forged callbacks; withdrawal persistence, duplicates, parallel requests, insufficient/negative amounts, stale price; admin auth, paid rules, refund exactly once; precise errors for missing DB/binding/schema.
- **Local browser end-to-end (real index.html + rnd-backend.js + Worker code; fake Firebase SDK; SQLite): 11/11 pass** (`python3 test-ui/e2e-local.py`): login, start mining, session saved, 30-min balance, restart restores session, finished session credited, logout/login keeps balance, DB failure shows a clear error and does not claim mining started, unreachable server address message.
- Other local: 20 sign-in screen tests (stub), 17 client-SDK tests, 20 error-message tests, legacy functions logic tests.
- **LIVE tests (real Firebase Auth, real Cloudflare Worker/D1, real emails, APK): NONE.** My workspace cannot reach Firebase, Cloudflare, npm or Google. Wrangler was never run, so `wrangler.toml`/deployment is unverified; D1 behaviour is assumed to match SQLite for the SQL used (batch = one transaction, `RETURNING`, `meta.changes`). Run `node scripts/diagnose-mining.mjs` after deploying.
- Not built: rewarded-ad SDK in the APK, automatic payouts, APK.

## Earlier history (before the Cloudflare move; Firebase Functions parts are superseded)

**The project is NOT complete.** The code is written, but it has never run against your real Firebase project and no APK was built, because the environment I worked in blocks Firebase, npm, Maven and Google downloads.

## 1. What genuinely works (verified here)
- Demo mode is gone: no demo backend, fake user, demo balance or demo labels remain. With Firebase missing or unreachable the app shows an error and a Retry button (tested in a browser).
- The page logic: login screen, emailed-code screen, locked app until code accepted, server-driven balance and mining countdown, withdrawal error/success handling, logout button (tested in headless Chromium against a **stub** backend — this is NOT a Firebase test).
- Server logic as pure code, 19 unit tests passing (`npm run test:functions`): mining math and rates (0.00016668 base, 0.000947 ceiling), no double-crediting on repeated settlement, boost 2x for 10 min, 10/day cap, code expiry / single use / attempt limit / resend limits, price staleness rejection, PKR 40 minimum rounded up, destination validation, distinct withdrawal statuses, Saturday/Sunday payout days, AdMob signature check (with a locally generated key, not Google's).

## 2. Written but NOT run against real services
- Cloud Functions (`functions/index.js`): mining start/settle with server time, price lookup (CoinGecko), withdrawals with idempotent requestId, ledger and audit records, AdMob callback endpoint. Only syntax-checked.
- `firestore.rules` (deny all client access), `firebase.json`, owner admin tool `functions/tools/admin.js`.
- Email/password registration, verification link, login, reset, persistent session, logout via the Firebase JS SDK (`www/js/rnd-backend.js`). Not run.

## 3. Not implemented
- Rewarded ads: no ad SDK in the app; Watch Ad is disabled and says so. Server endpoint exists but is untested and unconnected.
- Rank/level progress is still stored only on the device (cosmetic layer).
- App Check, Supabase data migration (nothing was migrated or deleted), admin screen (CLI only).
- Emulator tests for rules/functions (need the Firebase CLI and Java).

## 4. APK
Not built. Android SDK and Gradle downloads are blocked here.

## 5. Real-service tests done
None. Registration, verification, login, logout, password reset and Firestore saves/reads are all **untested**.

## 6. Manual steps left
See `docs/FIREBASE_SETUP.md`: add the Web app and paste its config into `www/firebase-config.js`; enable Email/Password; create Firestore; upgrade to Blaze (your approval, costs explained there); set secrets; deploy; run the real tests.

## 7. Decisions you may want to change
- Mining time is credited by the server for the whole 1-hour session even if the app is closed (old demo only counted time with the screen open).
- Boost day = Pakistan calendar day. Payouts can only be marked paid on Saturday/Sunday Pakistan time.
- Price source: CoinGecko `render-token` in PKR, refused if older than 10 minutes. Withdrawal amount is still typed in RENDER; the server enforces the 0.07 RENDER minimum (v3.1.2).
- The client cannot read Firestore at all; it asks the server for state.
- Access requires only a genuine Firebase session with a verified email (verification link). The custom emailed 6-digit code was removed (2026-10-14 (c)).

## Update 2026-10-14: hardening
- Ad callbacks are refused unless the ad unit matches `ADMOB_REWARDED_AD_UNIT_ID`; empty = refuse all. Replays and the daily cap are decided by one tested function.
- `getState` no longer writes on every call (one read, no write mid-session); client syncs every 5 min instead of every 60 s; withdrawal history only on request.
- Rate limits on mining start, withdrawals, state and price. App Check: client key and server switch prepared, **off by default and untested**; Android Play Integrity provider **not implemented**.
- Fixed: boost segments of an unfinalised session are no longer pruned early (would have under-credited late finalisation).
- Tests: 35 pure-logic tests pass. No live Firebase, emulator, deployment or APK test was run.

## Update 2026-10-14 (b): blank black screen fixed
- Cause (reproduced): opening `www/index.html` from a file (`file://`) made the browser block the ES-module `import` of `js/rnd-backend.js` and `firebase-config.js` (CORS, origin "null"). The main script never ran and all screens start hidden, so only the black background showed.
- Fix: those two files are now ordinary scripts (`window.RND_CONFIG`, `window.RNDBackend`); no ES-module imports remain. A safety screen (plain HTML) shows "Loading", a readable error, or a Retry/Reload button for: missing files, hung or failed Firebase connection (20 s timeout), script errors, or a main script that never starts (8 s watchdog).
- Verified in headless Chromium (browser tests only, NOT Firebase): file:// and http:// both show the screens; five injected failure modes each show readable text. Whether Firebase sign-in works from a file address is unverified; use `npm run preview` (docs/PREVIEW.md).

## Update 2026-10-14 (c): custom OTP removed, Firebase Authentication only
**Changed:** `requestLoginCode`, `verifyLoginCode`, the OTP screen/state/handlers, `functions/lib/otp.js`, OTP constants and tests, `nodemailer`, `SMTP_URL`, `OTP_PEPPER`, `MAIL_FROM` are gone. Every callable now uses one gate (`functions/lib/guards.js authGate`): signed-in Firebase ID token + `email_verified === true`. Client: register -> Firebase verification email -> "I HAVE VERIFIED" does `reload()` + `getIdToken(true)` -> app opens only if the new token says verified; login/unverified -> verify screen; reset = Firebase reset email; logout and persistent session unchanged. No Dynamic Links, no custom action URL, no deep link.
**Kept:** accounts, mining logic, balances, rewards, withdrawals, Firestore data and rules (nothing deleted; `functions/tools/cleanup-otp.js` is optional, dry-run by default, touches only `loginCodes` and the `otpFor` claim).

**Verified here (no real Firebase):**
- 37 server-logic unit tests pass (`npm run test:functions`), including 5 new tests for the auth gate (no session, unverified, verified, old `otpFor` claim ignored, App Check order) and a check that no OTP/SMTP code remains in the backend.
- 20 browser checks of the screens and routing against a STUB backend, and 10 checks of the real `rnd-backend.js` against a FAKE Firebase SDK (`npm run test:ui`): register, verify-before-click message, retry, verify, persistent login, logout, wrong password, unverified login, resend, lost session, server re-lock, reset email.
- Syntax checks of `functions/index.js`, `rnd-backend.js`, `cleanup-otp.js` and the page script.

**NOT verified (could not be, from my environment):** real Firebase sign-up, real verification/reset emails arriving in Gmail, the real ID-token claim after clicking the link, the installed Android APK (not built), returning from Gmail on a phone, deployed functions. Follow the test list in `docs/FIREBASE_SETUP.md` section 6 before calling this done.
**Spark plan:** Authentication works on Spark; mining/balance/withdrawal functions still need Blaze (unchanged).
**Known limits:** the app does not auto-detect the verification; the person returns to the app and taps the button. Android App Check (Play Integrity) is still not implemented.

## Update 2026-10-14 (d): START MINING "Cannot reach the server" — diagnosis tooling and accurate errors
**What was wrong in the code (verified by reading + tests):** `srvError()` in `www/index.html` mapped `unavailable|network|deadline|internal|failed to fetch` to "Cannot reach the server. Check your internet connection". The Firebase SDK reports a callable that gets NO readable HTTP response (function not deployed / blocked, browser CORS block of Google's 404 page) as `functions/internal` with message `internal`, and the Functions runtime hides every non-HttpsError (e.g. any Firestore failure) behind `INTERNAL`. So not-deployed, Firestore-missing, Firestore-permission and real network loss all showed the same wrong message.
**Changed:** `www/index.html` (srvError by Firebase code; sync/boot paths show the real reason), `www/js/rnd-backend.js` (console log of the failing callable name + code), `functions/lib/errors.js` (NEW: classify Firestore/runtime errors into backend_* codes), `functions/index.js` (callables wrapped by `safe()`; mining/rate-limit/balance logic untouched), `scripts/diagnose-mining.mjs` (NEW: real request, prints HTTP status/CORS/body/diagnosis), tests, package scripts.
**NOT verified:** the live request. The sandbox has no network and no access to the Firebase project. Run `npm run diagnose` on your computer (docs/FIREBASE_SETUP.md section 12) to see the real status.
