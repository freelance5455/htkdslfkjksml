# Deploy v3.1.2 (minimum withdrawal 0.07 RENDER) safely

Tested locally only (SQLite stand-in for D1, fake Firebase tokens, headless Chromium). Not deployed, not live-tested. **No database migration, no new secrets, no setting changes.**

1. **Backup first.** Record the D1 restore point (`npx wrangler d1 time-travel info rnd-miner-db`) and/or export (`npx wrangler d1 export rnd-miner-db --remote --output=backup.sql`). Check the file is not empty.
2. **Save the current Worker code.** Dashboard > Workers & Pages > `rnd-miner-api` > Edit code > select all > copy into `previous-worker-code.js`.
3. **Deploy the Worker.** In the code box select all, delete, paste all of `DEPLOY-FILES/1-worker-code.js`, **Deploy**. Do not touch Bindings, Variables or Secrets (`DB`, `FIREBASE_PROJECT_ID`, `ADMIN_TOKEN` stay as they are). Do not run `wrangler deploy`.
4. **Check health.** Open `/api/health`: `"ok":true`, `"database":"ok"`.
5. **Publish the app.** Serve/build the updated `www/` (or `dist/RND-Miner-single.html`). For Android: `npm run android:sync` and rebuild the APK. Old app versions still show "PKR 40" text, but the Worker enforces 0.07 either way.
6. **Verify with your own test account only.**
   - Balance below 0.07: buttons disabled, text says locked; a forged request returns `withdrawal_locked:0.07`.
   - Balance at or above 0.07: buttons enabled; a request of 0.07 is accepted; 0.069 is refused.
   - Existing balance and Withdrawal History look the same as before.
7. **Rollback.** Paste `previous-worker-code.js` back and Deploy. No data was changed, so nothing else is needed.

Order matters little, but deploy the Worker (step 3) before or together with the app (step 5).
