> **UPDATE (2026-10-14): the Cloud Functions / Firestore / Blaze parts of this file are OBSOLETE.** The trusted server is now a free Cloudflare Worker + D1 database: follow `docs/CLOUDFLARE_SETUP.md`. Only the Firebase *Authentication* parts below still apply (Web app config, Email/Password, verification emails).

# Firebase setup (project `render-minning-88b6c`, package `com.app.renderminning`)

Nothing below has been run against your real Firebase project by me: the environment I worked in cannot reach Firebase, npm, Maven or Google. Follow these steps, then run the tests in section 6.

## 1. Web app config (needed by the app)
The app uses the Firebase JS SDK 12.6.0 (loaded from Google's CDN) inside the Capacitor WebView.
1. Console > Project settings > General > Your apps > **Add app > Web (</>)**. Nickname "RND Miner Web". Skip hosting.
2. Copy the `firebaseConfig` values into `www/firebase-config.js` (`apiKey`, `messagingSenderId`, `appId`). The `appId` must be the **web** one (`1:...:web:...`).
3. `npm run check:config` must print PASS for every line. Until then the app shows "Firebase is not configured".
Why not the Android `google-services.json`? Its API key is restricted to the Android app, and the JS SDK runs in a WebView, so it needs a web config. `google-services.json` is not required by this build.

## 2. Authentication (Firebase Console settings required)
Authentication itself (email/password sign-up, the verification-link email, the password-reset email) works on the **free Spark plan**. There is no custom code, SMTP server or Dynamic Link involved.
1. Build > Authentication > Get started > Sign-in method > **Email/Password: enable**. Leave **"Email link (passwordless sign-in)" OFF**.
2. Authentication > **Templates** tab: open "Email address verification" and "Password reset". Keep the **default action URL** (`https://render-minning-88b6c.firebaseapp.com/__/auth/action`, hosted by Firebase). Do **not** change it to a `page.link` / Dynamic Link address (Firebase Dynamic Links are shut down). You may edit the sender name and subject.
3. Authentication > Settings > **Authorized domains**: `localhost` and `render-minning-88b6c.firebaseapp.com` are there by default; nothing to add. (The app sends no `continueUrl`, so no extra domain or deep link is needed.)
4. Google Cloud Console > APIs & Services > Credentials > the browser API key used in `www/firebase-config.js`: if you added restrictions, it must still allow `identitytoolkit.googleapis.com` and `securetoken.googleapis.com`, and it must NOT be limited to an Android package (the app runs in a WebView and sends no package header). Unrestricted/"Browser key (auto created by Firebase)" is fine.
5. Authentication > Settings > User actions: leave "Email enumeration protection" on (default). The app shows the same neutral message whether or not a reset email exists.
## 3. Firestore
Build > Firestore Database > Create database (production mode). Then `firebase deploy --only firestore:rules`. The rules deny every client read and write on purpose; only the Cloud Functions (Admin SDK) touch data.

## 4. Backend: needs the Blaze plan (pay-as-you-go) — your approval required
Cloud Functions and calls to outside APIs (price source, AdMob keys) need Blaze. Authentication alone does not. I have **not** enabled anything. Blaze has a free monthly allowance (about 2 million function invocations, plus free Firestore reads/writes up to daily quotas), so a small app usually costs very little, but you must add a billing account and you are responsible for charges. Set a budget alert in Google Cloud Billing before deploying. 
Deploy steps (on your computer):
```
npm i -g firebase-tools && firebase login
cd functions && npm install && cd ..
cp functions/.env.example functions/.env.render-minning-88b6c   # set ADMOB_REWARDED_AD_UNIT_ID when ads exist
firebase deploy --only functions,firestore:rules
```
No SMTP account and no OTP secrets are needed any more.

**Spark vs Blaze, honestly:** sign-up, verification email, login, reset and logout need only Spark. The mining, balance and withdrawal functions are Cloud Functions, which Firebase only deploys on Blaze. On Spark the app can sign you in and verify your email but cannot load a balance or mine.

**Removing the old OTP resources (only if you ever deployed the previous version; nothing was deployed by me):**
```
firebase deploy --only functions            # answer YES when it offers to delete requestLoginCode and verifyLoginCode
# or explicitly:
firebase functions:delete requestLoginCode verifyLoginCode --region us-central1
firebase functions:secrets:destroy SMTP_URL
firebase functions:secrets:destroy OTP_PEPPER
cd functions && node tools/cleanup-otp.js            # dry run: lists leftover loginCodes docs and otpFor claims
cd functions && node tools/cleanup-otp.js --apply    # optional: removes ONLY those two leftovers
```
User accounts, balances, ledgers, sessions and withdrawals are not touched by any of this. Leaving the leftovers in place is also safe: nothing reads them.

## 5. How login works (Firebase Authentication only)
1. **Sign up**: the app calls Firebase `createUserWithEmailAndPassword`, which creates the account AND a genuine signed-in Firebase session (unverified), then `sendEmailVerification` emails Firebase's verification link. The app shows "Verify your email".
2. The person opens the email (Gmail), taps the link (a Firebase page says the email is verified), then comes back to RND Miner and taps **I HAVE VERIFIED**. No deep link back into the app is used; the person just returns to it.
3. The app calls `user.reload()` and `getIdToken(true)`. The new ID token carries `email_verified: true` (set by Firebase, not by the app). Only then does the app open and call the server.
4. **Every server function** re-checks the same token claim (`functions/lib/guards.js`: signed in + `email_verified === true`). An unverified or signed-out caller gets `email_not_verified` / `sign_in_required` and no data, whatever the app shows.
5. **Login**: email + password (`signInWithEmailAndPassword`). Unverified account -> verify screen with Resend. Verified -> app opens.
6. **Persistent login**: Firebase keeps the session on the device; reopening the app goes straight in. **Logout** signs out and reloads the app to the login screen.
7. **Forgot password**: Firebase's standard reset-link email. The person sets the new password on Firebase's page, returns to the app and logs in.
There is no 6-digit code anywhere.

## 6. Tests to run once deployed (real services)
1. Sign up with a real Gmail inbox -> verification email arrives (check Spam); the app shows the verify screen; mining stays locked.
2. Tap **I HAVE VERIFIED** BEFORE clicking the link -> clear "not verified" message, still locked. Click the link in Gmail, return to the app, tap the button -> the app opens directly.
3. Close/reopen the app: still signed in and opens directly. Log out -> login screen; reopening stays on login. Log in again -> opens directly, no code.
4. Sign up a second address and log in WITHOUT verifying -> verify screen appears; Resend works.
5. Forgot password -> reset email arrives, link sets a new password, the old one stops working, the new one logs in.
6. On the installed APK (not just the browser): repeat 1-5, including switching to Gmail and back with the app in the background.
7. Security check: call `getState` from a signed-in but UNVERIFIED account (emulator or a test script) -> must be refused with `email_not_verified`.
8. Start mining -> Console > Firestore shows `users/<uid>` with `mining.status = active`. Close the app, reopen after 1 hour: balance is credited.
9. Request a withdrawal below the minimum (refused), then a valid one: balance drops, `users/<uid>/withdrawals/<id>` shows `requested`.
10. Owner tool: `GOOGLE_APPLICATION_CREDENTIALS=key.json node functions/tools/admin.js list`, then approve/markpaid (Sat/Sun only).
11. Emulator tests for rules/functions: `firebase emulators:start` (needs Java and the Firebase CLI).

## 7. Rewarded ads (not connected)
`adReward` accepts only Google-signed AdMob server-side-verification callbacks AND only for **your** ad unit. **You must set `ADMOB_REWARDED_AD_UNIT_ID`** (the numeric ad unit id, or the full `ca-app-pub-.../...` form) in `functions/.env.render-minning-88b6c`. If it is empty, every callback is refused ("ad_unit_not_configured") and no boost is ever granted. Why: the Google signature only proves Google sent the callback for *some* ad unit; anyone can make an AdMob ad unit and point its callback at your URL, so the ad unit must be checked too. Replays (same transaction id) change nothing; the 10-per-Pakistan-day cap is enforced on the server.
To finish ads: create an AdMob app + rewarded ad unit, add an AdMob Capacitor plugin that sets `userId` = the Firebase uid, set the callback URL to the deployed `adReward` URL in AdMob, set `ADS_CONFIGURED = true`, and wire `watchAd()` to show the ad. The Android app has no ad SDK today, so Watch Ad stays disabled.

## 8. Admin / security notes
- Never put a service-account key in the app or repo.
- App Check (Play Integrity) is not set up; add it before launch to limit abuse of the callable functions.
- Supabase data in `legacy/supabase/` was not touched or migrated. Migrating balances needs an export, an email-to-uid mapping, and an Admin-SDK import that you approve; existing users must create Firebase accounts (passwords cannot be moved).

## 9. App Check (prepared, NOT enabled)
App Check makes the server refuse calls that do not come from your genuine app. Two switches, both off by default so nothing breaks:
- **Client** (`www/firebase-config.js`): `APP_CHECK_SITE_KEY`. Setting a reCAPTCHA v3 key enables App Check for the web/browser build. reCAPTCHA is not reliable inside the Android WebView, so for the **APK** the intended provider is **Play Integrity** (Console > App Check > register the Android app `com.app.renderminning` with Play Integrity, add the SHA-256 of your signing key). Using it needs a native App Check plugin feeding tokens to the web SDK through a custom provider. **That Android piece is not written or tested.**
- **Server**: deploy parameter `ENFORCE_APP_CHECK` (default `false`). When `true`, every callable refuses requests without a verified App Check token ("app_check_required"). Turn it on only after the app is shipping valid tokens, otherwise every user is locked out. Order: register providers in the Console, ship the app that sends tokens, watch the App Check metrics in the Console, then redeploy with `ENFORCE_APP_CHECK=true`.
Not covered: the `adReward` endpoint (called by Google, protected by its signature).

## 10. Server-side rate limits (per signed-in user)
- Sign-in, verification-email and reset-email sending is rate-limited by Firebase itself (the app shows "Too many attempts" and the Resend button waits 60 s).
- Start mining: 10 per hour (exact, stored in Firestore). Withdrawal requests: 5 per hour (exact).
- State refresh: 30 per 10 min and price lookups: 30 per 10 min (best-effort: counted per function instance in memory, free of database cost, so a user spread over several instances could exceed it).
Limits protect cost and abuse; they are not a replacement for App Check.

## 11. Sync frequency and what it costs (estimates, not measured)
Mining progress is computed on the phone between syncs and checked by the server only: once when the app opens, every 5 minutes while mining (read-only), once when the session ends, and when you open the withdraw screen. `getState` now does **one document read and no write** during a session; writes happen only at start, finish, withdrawal and ad boosts. Withdrawal history (up to 50 reads) is fetched only on the withdraw screen. Reward amounts are unchanged: credit is cumulative, so skipping intermediate saves loses nothing.
Per user, per continuously mined hour (my counting from the code): before about 60 function calls and 60-65 Firestore writes; now about 12 calls and about 7 writes (start 4 incl. rate limit and audit, finish 3).
Illustration with 1,000 users mining around the clock (24 sessions/day each), using Firestore Blaze prices as I remember them (about US$0.18 per 100k writes, US$0.06 per 100k reads, 20k writes and 50k reads free per day; functions about US$0.40 per million calls after 2 million free per month): before roughly US$80/month in writes and US$15/month in calls; now roughly US$8/month and US$3/month, plus small compute and reads. **I could not check current prices; confirm on Google Cloud's pricing pages and set a budget alert.** Small user counts stay inside the free allowances.

## 12. Diagnose START MINING against the real project
```
RND_EMAIL=you@gmail.com RND_PASSWORD='your password' npm run diagnose            # read-only (signs in, calls getState)
RND_EMAIL=... RND_PASSWORD=... npm run diagnose -- --start                       # also calls startMining (really starts a 1-hour session)
firebase functions:list --project render-minning-88b6c                          # which functions exist, region, runtime
firebase functions:log --only startMining --project render-minning-88b6c        # the server's own error for each call
```
`diagnose` prints: sign-in result, the token's project and `email_verified`, the CORS preflight, then for each function the HTTP status, body and a plain-language cause (not deployed / not public / token rejected / email not verified / Firestore missing / Firestore permission / App Check / crash / network).
App error texts now name the real cause: "[functions/not-found]" = not deployed or wrong region; "[functions/internal]" while online = no HTTP answer (usually not deployed or blocked); "[backend_database_missing]" = Firestore database not created; "[backend_permission_denied]" = server cannot use Firestore.
Deploying Cloud Functions needs the Blaze plan (Spark cannot deploy them). Nothing here changes your plan.
