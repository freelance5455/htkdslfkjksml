# Firebase setup (project `render-minning-88b6c`, package `com.app.renderminning`)

Nothing below has been run against your real Firebase project by me: the environment I worked in cannot reach Firebase, npm, Maven or Google. Follow these steps, then run the tests in section 6.

## 1. Web app config (needed by the app)
The app uses the Firebase JS SDK 12.6.0 (loaded from Google's CDN) inside the Capacitor WebView.
1. Console > Project settings > General > Your apps > **Add app > Web (</>)**. Nickname "RND Miner Web". Skip hosting.
2. Copy the `firebaseConfig` values into `www/firebase-config.js` (`apiKey`, `messagingSenderId`, `appId`). The `appId` must be the **web** one (`1:...:web:...`).
3. `npm run check:config` must print PASS for every line. Until then the app shows "Firebase is not configured".
Why not the Android `google-services.json`? Its API key is restricted to the Android app, and the JS SDK runs in a WebView, so it needs a web config. `google-services.json` is not required by this build.

## 2. Authentication
Build > Authentication > Get started > Sign-in method > **Email/Password: enable** (leave "Email link" off). Templates tab: check "Email address verification" and "Password reset". Settings > Authorized domains: `localhost` and `render-minning-88b6c.firebaseapp.com` are there by default.

## 3. Firestore
Build > Firestore Database > Create database (production mode). Then `firebase deploy --only firestore:rules`. The rules deny every client read and write on purpose; only the Cloud Functions (Admin SDK) touch data.

## 4. Backend: needs the Blaze plan (pay-as-you-go) — your approval required
Cloud Functions, Secret Manager and calls to outside APIs (price source, AdMob keys, email) need Blaze. I have **not** enabled anything. Blaze has a free monthly allowance (about 2 million function invocations, plus free Firestore reads/writes up to daily quotas), so a small app usually costs very little, but you must add a billing account and you are responsible for charges. Set a budget alert in Google Cloud Billing before deploying. Secret Manager has a small per-secret fee (cents per month).
Deploy steps (on your computer):
```
npm i -g firebase-tools && firebase login
cd functions && npm install && cd ..
firebase functions:secrets:set SMTP_URL      # e.g. smtps://you%40gmail.com:APP_PASSWORD@smtp.gmail.com:465
firebase functions:secrets:set OTP_PEPPER    # long random string: openssl rand -hex 32
cp functions/.env.example functions/.env.render-minning-88b6c   # then edit MAIL_FROM
firebase deploy --only functions,firestore:rules
```
Email delivery: any SMTP service works. A Gmail account with an **App Password** (needs 2-step verification) is free but limited (~500 mails/day) and Gmail may mark bulk login codes as spam; a transactional provider (Brevo, Resend, SendGrid, Mailgun) is more reliable for real users.

## 5. How login works
1. Sign up (email + password, Firebase Auth) -> Firebase emails a **verification link**.
2. After the link is opened: tap "I'VE VERIFIED".
3. On **every fresh login** the server emails a **6-digit code** (10 min expiry, single use, 5 attempts, 60 s resend wait, 3 codes per 15 min). Only a keyed hash is stored. A correct code makes the server stamp your sign-in on your account (`otpFor = auth_time`); every function checks it. Staying logged in (closing and reopening the app) keeps working; logging in again needs a new code.
4. Mining, balance and withdrawals are refused by the server without steps 2 and 3.

## 6. Tests to run once deployed (real services)
1. Sign up with a real inbox -> verification email arrives; mining stays locked.
2. Verify -> log out -> log in -> login-code email arrives -> wrong code rejected, right code opens the app.
3. Close/reopen the app: still signed in. Log out works. Forgot password email arrives.
4. Start mining -> Console > Firestore shows `users/<uid>` with `mining.status = active`. Close the app, reopen after 1 hour: balance is credited.
5. Request a withdrawal below the minimum (refused), then a valid one: balance drops, `users/<uid>/withdrawals/<id>` shows `requested`.
6. Owner tool: `GOOGLE_APPLICATION_CREDENTIALS=key.json node functions/tools/admin.js list`, then approve/markpaid (Sat/Sun only).
7. Emulator tests for rules/functions: `firebase emulators:start` (needs Java and the Firebase CLI).

## 7. Rewarded ads (not connected)
`adReward` accepts only Google-signed AdMob server-side-verification callbacks AND only for **your** ad unit. **You must set `ADMOB_REWARDED_AD_UNIT_ID`** (the numeric ad unit id, or the full `ca-app-pub-.../...` form) in `functions/.env.render-minning-88b6c`. If it is empty, every callback is refused ("ad_unit_not_configured") and no boost is ever granted. Why: the Google signature only proves Google sent the callback for *some* ad unit; anyone can make an AdMob ad unit and point its callback at your URL, so the ad unit must be checked too. Replays (same transaction id) change nothing; the 10-per-Pakistan-day cap is enforced on the server.
To finish ads: create an AdMob app + rewarded ad unit, add an AdMob Capacitor plugin that sets `userId` = the Firebase uid, set the callback URL to the deployed `adReward` URL in AdMob, set `ADS_CONFIGURED = true`, and wire `watchAd()` to show the ad. The Android app has no ad SDK today, so Watch Ad stays disabled.

## 8. Admin / security notes
- Never put a service-account key, SMTP password or pepper in the app or repo.
- App Check (Play Integrity) is not set up; add it before launch to limit abuse of the callable functions.
- Supabase data in `legacy/supabase/` was not touched or migrated. Migrating balances needs an export, an email-to-uid mapping, and an Admin-SDK import that you approve; existing users must create Firebase accounts (passwords cannot be moved).

## 9. App Check (prepared, NOT enabled)
App Check makes the server refuse calls that do not come from your genuine app. Two switches, both off by default so nothing breaks:
- **Client** (`www/firebase-config.js`): `APP_CHECK_SITE_KEY`. Setting a reCAPTCHA v3 key enables App Check for the web/browser build. reCAPTCHA is not reliable inside the Android WebView, so for the **APK** the intended provider is **Play Integrity** (Console > App Check > register the Android app `com.app.renderminning` with Play Integrity, add the SHA-256 of your signing key). Using it needs a native App Check plugin feeding tokens to the web SDK through a custom provider. **That Android piece is not written or tested.**
- **Server**: deploy parameter `ENFORCE_APP_CHECK` (default `false`). When `true`, every callable refuses requests without a verified App Check token ("app_check_required"). Turn it on only after the app is shipping valid tokens, otherwise every user is locked out. Order: register providers in the Console, ship the app that sends tokens, watch the App Check metrics in the Console, then redeploy with `ENFORCE_APP_CHECK=true`.
Not covered: the `adReward` endpoint (called by Google, protected by its signature).

## 10. Server-side rate limits (per signed-in user)
- Login code: 60 s between sends, 3 per 15 min, 5 wrong attempts per code (existing).
- Start mining: 10 per hour (exact, stored in Firestore). Withdrawal requests: 5 per hour (exact).
- State refresh: 30 per 10 min and price lookups: 30 per 10 min (best-effort: counted per function instance in memory, free of database cost, so a user spread over several instances could exceed it).
Limits protect cost and abuse; they are not a replacement for App Check.

## 11. Sync frequency and what it costs (estimates, not measured)
Mining progress is computed on the phone between syncs and checked by the server only: once when the app opens, every 5 minutes while mining (read-only), once when the session ends, and when you open the withdraw screen. `getState` now does **one document read and no write** during a session; writes happen only at start, finish, withdrawal and ad boosts. Withdrawal history (up to 50 reads) is fetched only on the withdraw screen. Reward amounts are unchanged: credit is cumulative, so skipping intermediate saves loses nothing.
Per user, per continuously mined hour (my counting from the code): before about 60 function calls and 60-65 Firestore writes; now about 12 calls and about 7 writes (start 4 incl. rate limit and audit, finish 3).
Illustration with 1,000 users mining around the clock (24 sessions/day each), using Firestore Blaze prices as I remember them (about US$0.18 per 100k writes, US$0.06 per 100k reads, 20k writes and 50k reads free per day; functions about US$0.40 per million calls after 2 million free per month): before roughly US$80/month in writes and US$15/month in calls; now roughly US$8/month and US$3/month, plus small compute and reads. **I could not check current prices; confirm on Google Cloud's pricing pages and set a budget alert.** Small user counts stay inside the free allowances.
