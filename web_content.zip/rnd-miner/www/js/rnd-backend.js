(function () {
/* (Classic script: exposes window.RNDBackend. Not an ES module, so it also works when opened from file://.)
   RND Miner backend client: Firebase Authentication + Cloud Functions (the trusted server).
   There is NO demo or offline fallback. If Firebase is not configured or unreachable, createBackend() throws
   an Error whose .code is "not_configured" or "sdk_unreachable" and the app shows an error with a Retry button.
   The app never writes balances: it can only ask the server to act, and display what the server returns. */

const SDK = "12.6.0";
const CDN = "https://www.gstatic.com/firebasejs/" + SDK + "/";
const E = (code, message) => Object.assign(new Error(message), { code });
const UNITS = 1e8;

const mapUser = (u) => u ? { uid: u.uid, email: u.email || "", displayName: u.displayName || (u.email ? u.email.split("@")[0] : "Miner"), emailVerified: u.emailVerified === true } : null;

async function createBackend() {
  const CFG = window.RND_CONFIG;
  if (!CFG || !CFG.firebaseConfig) throw E("files_missing", "firebase-config.js did not load.");
  const firebaseConfig = CFG.firebaseConfig, FUNCTIONS_REGION = CFG.FUNCTIONS_REGION, APP_CHECK_SITE_KEY = CFG.APP_CHECK_SITE_KEY;
  if (!firebaseConfig.apiKey || !firebaseConfig.appId) throw E("not_configured", "Firebase is not configured: apiKey and appId are missing in firebase-config.js.");
  let appM, authM, fnM;
  try { [appM, authM, fnM] = await Promise.all([import(CDN + "firebase-app.js"), import(CDN + "firebase-auth.js"), import(CDN + "firebase-functions.js")]); }
  catch (e) { throw E("sdk_unreachable", "Could not load the Firebase SDK. Check your internet connection."); }
  const app = appM.initializeApp(firebaseConfig);
  if (APP_CHECK_SITE_KEY) {   // must run before any Auth/Functions call so every request carries an App Check token
    try { const ac = await import(CDN + "firebase-app-check.js"); ac.initializeAppCheck(app, { provider: new ac.ReCaptchaV3Provider(APP_CHECK_SITE_KEY), isTokenAutoRefreshEnabled: true }); }
    catch (e) { throw E("sdk_unreachable", "Could not start App Check. Check your internet connection."); }
  }
  const auth = authM.getAuth(app);
  const fns = fnM.getFunctions(app, FUNCTIONS_REGION);
  const call = (name) => async (data) => { const r = await fnM.httpsCallable(fns, name)(data || {}); return r.data; };
  await auth.authStateReady();   // wait until a saved session (if any) has been restored

  const B = {
    auth: {
      current: () => mapUser(auth.currentUser),
      async register(email, password) { await authM.createUserWithEmailAndPassword(auth, email, password); await authM.sendEmailVerification(auth.currentUser); return B.auth.current(); },
      async signIn(email, password) { await authM.signInWithEmailAndPassword(auth, email, password); return B.auth.current(); },
      async signOut() { await authM.signOut(auth); },
      async sendVerification() { await authM.sendEmailVerification(auth.currentUser); },
      async sendReset(email) { await authM.sendPasswordResetEmail(auth, email); },
      /* re-read the account so emailVerified is the real current value */
      async refresh() { await auth.currentUser.reload(); await auth.currentUser.getIdToken(true); return B.auth.current(); },
      /* UI routing only: the SERVER enforces the same rule on every call. Full access = verified email + login code entered for THIS sign-in. */
      async hasLoginCode() { const t = await auth.currentUser.getIdTokenResult(); return t.claims.email_verified === true && !!t.claims.otpFor && t.claims.otpFor === t.claims.auth_time; },
      requestLoginCode: call("requestLoginCode"),
      async verifyLoginCode(code) { await call("verifyLoginCode")({ code }); await auth.currentUser.getIdToken(true); }
    },
    getState: call("getState"),
    startMining: call("startMining"),
    getPrice: call("getPrice"),
    requestWithdrawal: call("requestWithdrawal"),
    UNITS
  };
  return B;
}

window.RNDBackend = { createBackend };
})();
