(function () {
/* (Classic script: exposes window.RNDBackend. Not an ES module, so it also works when opened from file://.)
   RND Miner backend client: Firebase Authentication (login) + the RND Miner API on Cloudflare Workers (the trusted server).
   Every call sends the user's Firebase ID token; the server verifies it and takes the user id from it. The app never sends a user id, balance or time.
   There is NO demo or offline fallback. If Firebase is not configured or unreachable, createBackend() throws
   an Error whose .code is "not_configured" or "sdk_unreachable" and the app shows an error with a Retry button.
   The app never writes balances: it can only ask the server to act, and display what the server returns. */

const SDK = "12.6.0";
const CDN = "https://www.gstatic.com/firebasejs/" + SDK + "/";
const E = (code, message) => Object.assign(new Error(message), { code });
const UNITS = 1e8;

const mapUser = (u) => u ? { uid: u.uid, email: u.email || "", displayName: u.displayName || (u.email ? u.email.split("@")[0] : "Miner"), emailVerified: u.emailVerified === true } : null;

async function createBackend() {
  const CFG = window.RND_CONFIG;
  if (!CFG || !CFG.firebaseConfig) throw E("files_missing", "firebase-config.js did not load.");
  const firebaseConfig = CFG.firebaseConfig, APP_CHECK_SITE_KEY = CFG.APP_CHECK_SITE_KEY;
  const API_BASE = String(CFG.API_BASE || "").replace(/\/+$/, "");
  if (!firebaseConfig.apiKey || !firebaseConfig.appId) throw E("not_configured", "Firebase is not configured: apiKey and appId are missing in firebase-config.js.");
  let appM, authM;
  try { [appM, authM] = await Promise.all([import(CDN + "firebase-app.js"), import(CDN + "firebase-auth.js")]); }
  catch (e) { throw E("sdk_unreachable", "Could not load the Firebase SDK. Check your internet connection."); }
  const app = appM.initializeApp(firebaseConfig);
  if (APP_CHECK_SITE_KEY) {   // must run before any Auth/Functions call so every request carries an App Check token
    try { const ac = await import(CDN + "firebase-app-check.js"); ac.initializeAppCheck(app, { provider: new ac.ReCaptchaV3Provider(APP_CHECK_SITE_KEY), isTokenAutoRefreshEnabled: true }); }
    catch (e) { throw E("sdk_unreachable", "Could not start App Check. Check your internet connection."); }
  }
  const auth = authM.getAuth(app);
  /* One authenticated POST to the API. Errors keep a precise code so the page says WHICH step failed:
       api_not_configured  = API_BASE empty in firebase-config.js      api_unreachable = the request never got an HTTP answer
       api_bad_response    = answered, but not by our API (wrong URL)   api/<code>      = our server answered with an error (message = reason) */
  const call = (name) => async (data) => {
    if (!API_BASE) throw E("api_not_configured", "API_BASE is empty in firebase-config.js: the mining server address has not been set.");
    if (!auth.currentUser) throw E("no_session", "no_session");
    let token;
    try { token = await auth.currentUser.getIdToken(); }
    catch (e) { console.error("[RND] could not get an ID token:", e && e.code, e && e.message); throw e; }
    let res, text;
    try {
      res = await fetch(API_BASE + "/api/" + name, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + token }, body: JSON.stringify(data || {}), cache: "no-store" });
      text = await res.text();
    } catch (e) { console.error("[RND] " + name + ": no HTTP answer from " + API_BASE + " (" + (e && e.message) + ")"); throw E("api_unreachable", "The server could not be reached."); }
    let body = null; try { body = JSON.parse(text); } catch (e) { /* not JSON */ }
    if (!body || typeof body.ok !== "boolean") { console.error("[RND] " + name + ": HTTP " + res.status + " but not an RND API answer: " + String(text).slice(0, 120)); throw E("api_bad_response", "HTTP " + res.status + " from the server address, but it is not the RND Miner API."); }
    if (!body.ok) { console.error("[RND] " + name + " refused: code=" + body.error.code + " message=" + body.error.message); throw E("api/" + body.error.code, body.error.message); }
    return body.data;
  };
  await auth.authStateReady();   // wait until a saved session (if any) has been restored

  const B = {
    auth: {
      current: () => mapUser(auth.currentUser),
      async register(email, password) { await authM.createUserWithEmailAndPassword(auth, email, password); await authM.sendEmailVerification(auth.currentUser); return B.auth.current(); },
      async signIn(email, password) { await authM.signInWithEmailAndPassword(auth, email, password); return B.auth.current(); },
      async signOut() { await authM.signOut(auth); },
      async sendVerification() { if (!auth.currentUser) throw E("no_session", "no_session"); await authM.sendEmailVerification(auth.currentUser); },
      async sendReset(email) { await authM.sendPasswordResetEmail(auth, email); },
      /* "I have verified": re-read the account FROM FIREBASE, then force a new ID token so its email_verified claim is current.
         Needs a live Firebase session. If the saved session is gone (cleared storage, signed out elsewhere) the person must log in again:
         we never fake or skip the sign-in. */
      async refresh() {
        const u = auth.currentUser;
        if (!u) throw E("no_session", "no_session");
        await u.reload();
        await u.getIdToken(true);
        return B.auth.current();
      },
      /* True only when the ID token Firebase issued says email_verified === true. If the token is stale (the link was opened after
         it was issued) it reloads the user and fetches one fresh token. UI routing only: the SERVER checks the same claim on every call. */
      async hasVerifiedSession() {
        if (!auth.currentUser) return false;
        let t = await auth.currentUser.getIdTokenResult();
        if (t.claims.email_verified !== true) { await auth.currentUser.reload(); t = await auth.currentUser.getIdTokenResult(true); }
        return t.claims.email_verified === true;
      },
    },
    getState: call("getState"),
    startMining: call("startMining"),
    getPrice: call("getPrice"),
    requestWithdrawal: call("requestWithdrawal"),
    UNITS
  };
  return B;
}

window.RNDBackend = { createBackend };
})();
