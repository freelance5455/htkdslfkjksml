/* Firebase WEB app configuration for project render-minning-88b6c.
   These values are NOT secrets (Firebase web config is public by design; security comes from Auth + the server).
   Where they come from: Firebase Console > Project settings > General > Your apps > Web app (</>) > SDK setup and configuration.
   This is a classic script (not an ES module) on purpose: ES-module imports are blocked when index.html is opened
   straight from a file (file://), which used to leave a blank black screen.
   If apiKey or appId were empty, the app would show "Firebase is not configured" and could not be used. */
window.RND_CONFIG = {
  firebaseConfig: {
    apiKey: "AIzaSyAmv7nO6UZlNa-kSCn2EiN5lU820Nqz3W0",
    authDomain: "render-minning-88b6c.firebaseapp.com",
    projectId: "render-minning-88b6c",
    storageBucket: "render-minning-88b6c.firebasestorage.app",
    messagingSenderId: "37841806259",
    appId: "1:37841806259:web:cb33a392dc92a60488e1c6"
  },
  /* Address of YOUR deployed RND Miner API (Cloudflare Worker, free plan). Printed by "wrangler deploy", looks like
     https://rnd-miner-api.<your-subdomain>.workers.dev   (no trailing slash). Empty = the app shows "server address not set".
     It is public by design: every call is authorised by the user's Firebase ID token, which the Worker verifies. */
  API_BASE: "https://rnd-miner-api.afridiallahdad3.workers.dev",
  /* Rewarded ads need an ad network SDK inside the Android app plus the adReward function. Keep false until both exist. */
  ADS_CONFIGURED: false,
  /* App Check (blocks requests that do not come from your genuine app). Paste a reCAPTCHA v3 site key to turn it on for the
     web/preview build. For the Android APK the recommended provider is Play Integrity; see docs/FIREBASE_SETUP.md section 9.
     Empty = App Check is not used by the client (the server only enforces it if ENFORCE_APP_CHECK=true is deployed). */
  APP_CHECK_SITE_KEY: ""
};
