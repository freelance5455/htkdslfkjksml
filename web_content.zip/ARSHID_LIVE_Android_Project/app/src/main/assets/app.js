const pages = document.querySelectorAll('.page');
const navs = document.querySelectorAll('.nav');
function showPage(id){
  pages.forEach(p=>p.classList.toggle('active',p.id===id));
  navs.forEach(n=>n.classList.toggle('active',n.dataset.page===id));
  window.scrollTo({top:0,behavior:'smooth'});
}
navs.forEach(n=>n.addEventListener('click',()=>showPage(n.dataset.page)));
document.querySelectorAll('.live-card').forEach(b=>b.addEventListener('click',()=>openLive(b.dataset.live)));
function openLive(name){
  document.getElementById('liveName').textContent=name;
  document.getElementById('modal').classList.remove('hidden');
}
document.getElementById('startLive').addEventListener('click',()=>openLive('Your LIVE'));
document.getElementById('closeModal').addEventListener('click',()=>document.getElementById('modal').classList.add('hidden'));
document.getElementById('modal').addEventListener('click',e=>{if(e.target.id==='modal')e.currentTarget.classList.add('hidden')});
document.querySelectorAll('.like').forEach(b=>b.addEventListener('click',()=>{b.textContent=b.textContent.includes('♥')?'♡ Like':'♥ Liked';}));
document.querySelectorAll('.follow').forEach(b=>b.addEventListener('click',()=>{b.textContent=b.textContent==='Follow'?'Following':'Follow';}));
document.getElementById('postBtn').addEventListener('click',()=>{
  const caption=document.getElementById('caption').value.trim();
  alert(caption ? `Post preview ready: ${caption}` : 'Add a caption first.');
});
document.getElementById('refresh').addEventListener('click',()=>alert('You are viewing the sample feed.'));
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
