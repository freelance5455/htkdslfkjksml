NASH UNIVERSE - MEDIA FIXED

This build keeps the backup version's proven media storage method: compressed images/video/audio are stored as data URLs in Firebase Realtime Database. Firebase Storage is NOT required for chat media.

Firebase project:
our-universe-96cb1
Database:
https://our-universe-96cb1-default-rtdb.firebaseio.com/

Realtime Database rules for testing:
{
  "rules": {
    ".read": false,
    ".write": false,
    "worlds": {
      "nash-svit-kotusyk-kvitka": {
        ".read": true,
        ".write": true
      },
      "chats": { ".read": true, ".write": true },
      "chat": { ".read": true, ".write": true },
      "gallery": { ".read": true, ".write": true },
      "galleryArt": { ".read": true, ".write": true },
      "moods": { ".read": true, ".write": true },
      "mood": { ".read": true, ".write": true },
      "events": { ".read": true, ".write": true },
      "pushInbox": { ".read": true, ".write": true },
      "notes": { ".read": true, ".write": true },
      "calendar": { ".read": true, ".write": true }
    }
  }
}

IMPORTANT: the exact database paths used by the backup are top-level (chat, gallery, galleryArt, notes, calendar, mood, events, etc.). If your current rules block them, media/messages will fail. For initial testing you can temporarily use:
{
  "rules": { ".read": true, ".write": true }
}
Then secure the rules after testing.

The final media handlers are at the end of index.html and override previous conflicting file handlers.
