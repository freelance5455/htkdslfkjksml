# LangTrack — English Journey

A personal, offline-first English learning tracker. It includes:
- Dashboard with daily progress, skill targets, weekly chart, streak and challenge countdown
- Study timer and manual session logging
- Reports, monthly chart, CSV export and weekly review
- Calendar heatmap and daily details
- Editable goals and achievement milestones
- Vocabulary bank
- Local backup and restore (JSON)
- Installable PWA support and offline cache

## Important
This starter version stores data in the browser on the current device. It does not include cloud sync. To move data from phone to computer, use Settings & Backup > Download full backup on one device, then Import backup on the other.

## Install/use
1. Extract the ZIP.
2. For a quick test, open `index.html` in a modern browser. Most features work, but install/offline PWA features require serving the folder from HTTPS or localhost.
3. For installable PWA behavior on Android and desktop, host the folder on a trusted HTTPS static host (or run a local development server). Open the HTTPS URL in Chrome/Edge and choose “Install app” or “Add to Home screen”.
4. Keep `index.html`, `manifest.json`, and `sw.js` together in the same folder.

This package is a PWA source bundle, not a signed Android APK or Windows EXE. Creating native packages requires a separate build/signing step.
