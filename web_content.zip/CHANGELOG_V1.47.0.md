# v1.47.0 — Série C sincronizada em Ligas > Brasil

- Corrigida a origem dos dados mostrados em **Ligas > Brasil > Série C**. Quando uma transferência deixava `otherLeague` apontando para a Série C antiga, essa tabela congelada podia esconder a classificação que a simulação continuava atualizando.
- A visualização da Série C agora prioriza o snapshot próprio `thirdLeague` quando a carreira está em outra divisão.
- Ao sair da Série C, a classificação/calendário ativos são sincronizados ao snapshot próprio antes da troca de divisão. Ao entrar na Série C, usa-se o snapshot da Série C.
- As Séries A e B mantêm sua seleção e suas rotinas atuais; esta correção é restrita à resolução/sincronização da Série C.
- Atualizado o nome do cache do service worker para garantir que o navegador receba o código novo.
- Sintaxe JavaScript validada.
