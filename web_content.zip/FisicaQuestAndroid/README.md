# Física Quest — projeto Android

O jogo HTML original está incluído no aplicativo em `app/src/main/assets/index.html`. O app abre esse arquivo localmente por meio de uma WebView, sem depender de internet para carregar o jogo. O armazenamento local da WebView permite que o progresso salvo pelo HTML permaneça no dispositivo.

## Opção A — gerar APK de teste no Android Studio

1. Instale o Android Studio em um computador.
2. Abra a pasta `FisicaQuestAndroid` em **File > Open**.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 se o Android Studio solicitar.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira esse APK para o celular Android e permita a instalação de aplicativos dessa origem quando o sistema solicitar.

## Opção B — compilar pelo GitHub Actions

O projeto inclui `.github/workflows/build-apk.yml`. Se você enviar a pasta do projeto para um repositório GitHub, a ação poderá compilar o APK de teste automaticamente:

1. Crie um repositório no GitHub e envie os arquivos desta pasta.
2. Abra a aba **Actions** e selecione **Build Física Quest APK**.
3. Clique em **Run workflow** (ou envie um commit para `main`/`master`).
4. Quando a execução terminar, abra a execução e baixe o artefato `fisica-quest-apk-debug`.

## Importante

- Este projeto não contém um APK já compilado.
- O APK `debug` serve para testes e compartilhamento informal; não é a versão assinada de lançamento para publicação em loja.
- Para publicar uma versão de lançamento, gere uma chave de assinatura própria e configure a assinatura no processo de build. Não compartilhe a chave privada nem sua senha.
- Se atualizar o jogo, substitua `app/src/main/assets/index.html` pelo HTML novo e compile novamente.
