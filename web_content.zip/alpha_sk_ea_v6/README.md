# ALPHA SK EA V6 — starter project

## Included
- `mt5/Alpha_SK_EA_V6.mq5`: editable MetaTrader 5 Expert Advisor source.
- `web_app/index.html`: mobile-friendly companion dashboard and risk calculator.
- `web_app/manifest.webmanifest` and `web_app/sw.js`: basic Progressive Web App support.
- `INSTALLATION.md`: setup and testing instructions.

## Honest status
This is a starter implementation of a rule-based EMA/RSI scalping EA, not a proven profitable system. It has not been compiled in MetaEditor or backtested in this environment. Compile and test it yourself before any live use. No profit is guaranteed.

The companion website is NOT connected to a broker or MT5 and does not execute trades. The EA runs inside desktop MetaTrader 5 (or MT5 on a compatible Windows VPS); the Android MT5 app does not run custom EAs directly. Packaging the companion website as an APK only packages the dashboard, not the trading engine.

## Before live trading
1. Compile the `.mq5` source in MetaEditor and resolve any compiler errors.
2. Backtest with realistic spread, commission and slippage.
3. Forward-test on a demo account for several weeks.
4. Check broker min lot, tick size/value, stop distance and spread conventions for your symbol.
5. Inspect drawdown and losing streaks. A small account may not support the broker's minimum volume at the configured risk level; in that case the EA skips the trade.

Do not use money needed for essentials. Automated trading can lose money rapidly. Past results do not predict future performance.
