# Install and test Alpha SK EA V6

## MT5 EA on Windows
1. Install MetaTrader 5 from your broker or MetaQuotes.
2. Open MT5 and press **F4** to open MetaEditor.
3. Open `mt5/Alpha_SK_EA_V6.mq5` in MetaEditor.
4. Press **F7** to compile. This source has not been compiled in this environment; review all compiler messages and do not assume it is production-ready.
5. In MT5, open **View → Strategy Tester** (usually Ctrl+R), select Alpha SK EA V6, and backtest the intended symbol/timeframe with realistic costs.
6. Attach it to a demo chart and enable Algo Trading for demo testing only. Review Experts and Journal tabs.

## Default logic and settings
- Entry: EMA 9/21 crossover confirmed by RSI 14 on closed candles.
- SL: 1.5 × ATR(14), adjusted for broker minimum stop distance.
- TP: 1.2 × stop distance.
- Risk input: 0.25% of equity per trade.
- Max positions: 1 for this symbol and magic number.
- Spread filter: 30 broker points (must be tuned for the symbol and broker).
- Optional broker-server trading hours and optional close-on-opposite-signal.

Risk calculation is approximate because broker contract specifications can vary. Check every order and the actual volume/risk. A small calculated position below the broker's minimum lot is skipped rather than rounded up.

## Android / web app
Open `web_app/index.html` in a browser to use the companion dashboard. For PWA installability, host the folder on an HTTPS website, then open it in a compatible browser and choose its install/add-to-home-screen option. A PWA-to-APK wrapper can package the dashboard, but it cannot make the Android app execute this EA. For automated trading, MT5 must run on a computer or compatible VPS.
