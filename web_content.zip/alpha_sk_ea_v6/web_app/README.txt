ALPHA SK EA V6 companion web app
Open index.html in a browser to use the risk calculator and setup checklist.
For installable PWA behaviour, host these files on HTTPS and open the site in a compatible browser.
This is NOT connected to MetaTrader 5 and does not place trades.
The MT5 EA is separate, located at ../mt5/Alpha_SK_EA_V6.mq5.
