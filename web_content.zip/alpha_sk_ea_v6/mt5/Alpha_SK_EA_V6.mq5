//+------------------------------------------------------------------+
//|                                           Alpha_SK_EA_V6.mq5     |
//| EMA + RSI scalping starter EA for MetaTrader 5                   |
//| Demo-test first. No strategy guarantees profit.                  |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "Alpha SK EA V6 - EMA/RSI scalping starter EA"
#include <Trade/Trade.mqh>
CTrade trade;

input int      FastEMA_Period        = 9;
input int      SlowEMA_Period        = 21;
input int      RSI_Period            = 14;
input double   RSI_Buy_Min           = 52.0;
input double   RSI_Sell_Max          = 48.0;
input int      ATR_Period            = 14;
input double   SL_ATR_Multiplier     = 1.5;
input double   TP_Risk_Reward        = 1.2;
input bool     UseRiskPercent        = true;
input double   RiskPercent           = 0.25; // equity percentage per trade
input double   FixedLot              = 0.01; // used if UseRiskPercent=false
input int      MaxSpreadPoints       = 30;   // broker points; tune per symbol
input int      MaxPositions          = 1;
input ulong    MagicNumber           = 781806;
input int      SlippagePoints        = 10;
input bool     AllowBuy              = true;
input bool     AllowSell             = true;
input bool     UseTradingHours       = false;
input int      TradingHourStart      = 7;    // broker/server time
input int      TradingHourEnd        = 20;   // broker/server time
input bool     CloseOnOppositeSignal = false;

int hFast=INVALID_HANDLE, hSlow=INVALID_HANDLE, hRSI=INVALID_HANDLE, hATR=INVALID_HANDLE;
datetime lastBarTime=0;

int OnInit()
{
   if(FastEMA_Period<1 || SlowEMA_Period<2 || FastEMA_Period>=SlowEMA_Period ||
      RSI_Period<2 || ATR_Period<2 || RiskPercent<=0 || FixedLot<=0 ||
      SL_ATR_Multiplier<=0 || TP_Risk_Reward<=0 || MaxPositions<1)
      return INIT_PARAMETERS_INCORRECT;

   hFast=iMA(_Symbol,_Period,FastEMA_Period,0,MODE_EMA,PRICE_CLOSE);
   hSlow=iMA(_Symbol,_Period,SlowEMA_Period,0,MODE_EMA,PRICE_CLOSE);
   hRSI=iRSI(_Symbol,_Period,RSI_Period,PRICE_CLOSE);
   hATR=iATR(_Symbol,_Period,ATR_Period);
   if(hFast==INVALID_HANDLE || hSlow==INVALID_HANDLE || hRSI==INVALID_HANDLE || hATR==INVALID_HANDLE)
      return INIT_FAILED;

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   Print("Alpha SK EA V6 initialized on ",_Symbol," / ",EnumToString(_Period),". Demo-test first.");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hFast!=INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow!=INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hRSI!=INVALID_HANDLE) IndicatorRelease(hRSI);
   if(hATR!=INVALID_HANDLE) IndicatorRelease(hATR);
}

void OnTick()
{
   ManageOppositeSignal();
   datetime bt=iTime(_Symbol,_Period,0);
   if(bt==0 || bt==lastBarTime) return;
   lastBarTime=bt;
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)) return;
   if(UseTradingHours && !IsWithinTradingHours()) return;
   if(CurrentSpreadPoints()>MaxSpreadPoints) return;
   if(CountMyPositions()>=MaxPositions) return;

   double fast[3],slow[3],rsi[3],atr[3];
   ArraySetAsSeries(fast,true); ArraySetAsSeries(slow,true); ArraySetAsSeries(rsi,true); ArraySetAsSeries(atr,true);
   if(CopyBuffer(hFast,0,0,3,fast)<3 || CopyBuffer(hSlow,0,0,3,slow)<3 ||
      CopyBuffer(hRSI,0,0,3,rsi)<3 || CopyBuffer(hATR,0,0,3,atr)<3) return;
   // Signal uses closed candles (bars 2 and 1), not the forming candle.
   bool bull=(fast[2]<=slow[2] && fast[1]>slow[1]);
   bool bear=(fast[2]>=slow[2] && fast[1]<slow[1]);
   if(atr[1]<=0) return;
   if(AllowBuy && bull && rsi[1]>=RSI_Buy_Min) OpenPosition(ORDER_TYPE_BUY,atr[1]);
   else if(AllowSell && bear && rsi[1]<=RSI_Sell_Max) OpenPosition(ORDER_TYPE_SELL,atr[1]);
}

void OpenPosition(const ENUM_ORDER_TYPE side,const double atrValue)
{
   MqlTick tick; if(!SymbolInfoTick(_Symbol,tick)) return;
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double minStop=(double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*point;
   double slDist=MathMax(atrValue*SL_ATR_Multiplier,minStop+2.0*point);
   double tpDist=slDist*TP_Risk_Reward;
   double entry=(side==ORDER_TYPE_BUY)?tick.ask:tick.bid;
   double sl=(side==ORDER_TYPE_BUY)?entry-slDist:entry+slDist;
   double tp=(side==ORDER_TYPE_BUY)?entry+tpDist:entry-tpDist;
   sl=NormalizeDouble(sl,digits); tp=NormalizeDouble(tp,digits);
   double volume=UseRiskPercent?CalculateRiskLot(slDist):NormalizeVolume(FixedLot);
   if(volume<=0) { Print("Alpha SK EA V6: invalid volume; order skipped."); return; }
   bool ok=(side==ORDER_TYPE_BUY)?trade.Buy(volume,_Symbol,0.0,sl,tp,"Alpha SK EA V6 BUY"):
                                   trade.Sell(volume,_Symbol,0.0,sl,tp,"Alpha SK EA V6 SELL");
   if(!ok) Print("Order failed: ",trade.ResultRetcode()," / ",trade.ResultRetcodeDescription());
   else Print("Order sent. Side=",EnumToString(side)," volume=",DoubleToString(volume,3),
              " SL=",DoubleToString(sl,digits)," TP=",DoubleToString(tp,digits));
}

double CalculateRiskLot(const double stopDistance)
{
   double riskMoney=AccountInfoDouble(ACCOUNT_EQUITY)*RiskPercent/100.0;
   double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   double tickValue=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   if(stopDistance<=0 || tickSize<=0 || tickValue<=0) return 0.0;
   double lossPerLot=(stopDistance/tickSize)*tickValue;
   if(lossPerLot<=0) return 0.0;
   double raw=riskMoney/lossPerLot;
   // Never round a calculated risk lot upward: if below broker minimum, skip the trade.
   double minVol=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   if(raw<minVol) { Print("Calculated lot below broker minimum; trade skipped to avoid exceeding risk input."); return 0.0; }
   return NormalizeVolume(raw);
}

double NormalizeVolume(double volume)
{
   double minVol=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN), maxVol=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(step<=0 || volume<minVol) return 0.0;
   volume=MathMin(maxVol,MathFloor(volume/step)*step);
   int decimals=(step>=1.0)?0:(step>=0.1)?1:(step>=0.01)?2:(step>=0.001)?3:4;
   return NormalizeDouble(volume,decimals);
}

int CountMyPositions()
{
   int n=0;
   for(int i=PositionsTotal()-1;i>=0;--i)
   {
      ulong ticket=PositionGetTicket(i); if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)==_Symbol && (ulong)PositionGetInteger(POSITION_MAGIC)==MagicNumber) n++;
   }
   return n;
}

double CurrentSpreadPoints()
{
   MqlTick t; if(!SymbolInfoTick(_Symbol,t)) return 1e9;
   double p=SymbolInfoDouble(_Symbol,SYMBOL_POINT); if(p<=0) return 1e9;
   return (t.ask-t.bid)/p;
}

bool IsWithinTradingHours()
{
   MqlDateTime now; TimeToStruct(TimeCurrent(),now);
   if(TradingHourStart==TradingHourEnd) return true;
   if(TradingHourStart<TradingHourEnd) return now.hour>=TradingHourStart && now.hour<TradingHourEnd;
   return now.hour>=TradingHourStart || now.hour<TradingHourEnd; // overnight session
}

void ManageOppositeSignal()
{
   if(!CloseOnOppositeSignal || Bars(_Symbol,_Period)<SlowEMA_Period+5) return;
   double fast[3],slow[3]; ArraySetAsSeries(fast,true); ArraySetAsSeries(slow,true);
   if(CopyBuffer(hFast,0,0,3,fast)<3 || CopyBuffer(hSlow,0,0,3,slow)<3) return;
   bool bull=(fast[2]<=slow[2] && fast[1]>slow[1]);
   bool bear=(fast[2]>=slow[2] && fast[1]<slow[1]);
   for(int i=PositionsTotal()-1;i>=0;--i)
   {
      ulong ticket=PositionGetTicket(i); if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol || (ulong)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;
      ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      if((type==POSITION_TYPE_BUY && bear) || (type==POSITION_TYPE_SELL && bull))
         if(!trade.PositionClose(ticket)) Print("Close failed for ",ticket,": ",trade.ResultRetcodeDescription());
   }
}
//+------------------------------------------------------------------+
