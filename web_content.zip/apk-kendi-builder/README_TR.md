# Cep APK Builder — 0.1 prototip

Bu proje, ZIP içindeki bir HTML/CSS/JS web uygulamasını Cordova + Android WebView kullanarak **debug APK** haline getiren küçük bir web arayüzü ve Node.js sunucusudur.

## Önemli sınır
Bu uygulama kendi kendine, yalnızca Android telefonda APK derleyemez. APK üretimi için sunucuda/bilgisayarda Node.js, Java JDK 17+ ve Android SDK/build-tools gerekir. Telefon arayüzü kullanabilir; ağır derleme işi sunucuda çalışır. APK Forge veya başka bir dönüştürücüye ihtiyaç duymaz; fakat bir derleme makinesi gerekir.

## ZIP formatı
ZIP'in kökünde `index.html` olmalı. Veya ZIP'in içinde tek bir proje klasörü bulunabilir ve onun içinde `index.html` olmalı. CSS, JS, görseller ve diğer dosyalar göreli yollarıyla birlikte tutulur.

## Sunucu kurulumu (Linux)
1. Node.js 18+ / 20+, Java JDK 17+ ve Android SDK kur.
2. Android SDK için `ANDROID_HOME` veya `ANDROID_SDK_ROOT` ortam değişkenini ayarla.
3. SDK Manager ile `platform-tools`, en az bir `platforms;android-XX` ve `build-tools;XX` kur; lisansları kabul et.
4. Bu klasörde `npm install` çalıştır.
5. `npm start` çalıştır.
6. Tarayıcıdan `http://SUNUCU_IP:3000` adresini aç.
7. ZIP seç, uygulama/paket adını gir ve APK OLUŞTUR'a bas.

## Güvenlik
- Bu prototipi internete açık, herkese açık bir sunucuya koyma. Kimlik doğrulama, kota, kötüye kullanım koruması ve HTTPS eklenmeden yalnızca güvendiğin yerel ağda kullan.
- Yalnızca güvendiğin ZIP dosyalarını derle. Proje dosyaları derleme sırasında işlenir.
- Üretilen APK debug imzalıdır; Play Store yayını için ayrıca release imzalama gerekir.

## Şu anki özellikler
- ZIP yükleme (40 MB sınırı)
- ZIP içinde index.html kontrolü
- Uygulama adı ve paket kimliği
- Cordova ile Android WebView APK derlemesi
- APK dosyasını tarayıcıya indirme

Bu ilk prototiptir; telefonda tamamen çevrimdışı APK derleme özelliği içermez.
