const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const upload = multer({ dest: path.join(os.tmpdir(), 'cep-apk-uploads'), limits: { fileSize: 40 * 1024 * 1024 } });
app.use(express.static(path.join(ROOT, 'public')));
app.use(express.json({ limit: '1mb' }));

function safeName(s, fallback) {
  return String(s || fallback).normalize('NFKD').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 35) || fallback;
}
function run(command, args, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, env: process.env });
    let out = '', err = '';
    child.stdout.on('data', d => out += d.toString());
    child.stderr.on('data', d => err += d.toString());
    child.on('error', reject);
    child.on('close', code => code === 0 ? resolve(out + err) : reject(new Error((out + err).slice(-5000))));
  });
}
app.post('/api/build', upload.single('project'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'ZIP dosyası seçilmedi.' });
  const appName = String(req.body.appName || 'BenimUygulamam').replace(/[<>"']/g, '').slice(0, 40);
  const pkg = safeName(req.body.packageId, 'com.example.benimuygulamam').toLowerCase();
  const packageId = pkg.includes('.') ? pkg : `com.example.${pkg}`;
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'cep-apk-build-'));
  try {
    const zip = new AdmZip(req.file.path);
    const entries = zip.getEntries();
    let total = 0;
    for (const e of entries) {
      if (e.isDirectory) continue;
      total += e.header.size || 0;
      const normalized = path.posix.normalize(e.entryName.replace(/\\/g, '/'));
      if (normalized.startsWith('../') || path.isAbsolute(normalized)) throw new Error('ZIP içinde güvenli olmayan dosya yolu bulundu.');
      if (total > 100 * 1024 * 1024) throw new Error('ZIP açıldığında 100 MB sınırını aşıyor.');
    }
    const extracted = path.join(work, 'input');
    fs.mkdirSync(extracted);
    zip.extractAllTo(extracted, true);
    let webRoot = extracted;
    if (!fs.existsSync(path.join(webRoot, 'index.html'))) {
      const dirs = fs.readdirSync(extracted, { withFileTypes: true }).filter(d => d.isDirectory());
      const match = dirs.find(d => fs.existsSync(path.join(extracted, d.name, 'index.html')));
      if (match) webRoot = path.join(extracted, match.name);
    }
    if (!fs.existsSync(path.join(webRoot, 'index.html'))) throw new Error('index.html bulunamadı. ZIP kökünde veya tek bir alt klasörde bulunmalı.');

    const project = path.join(work, 'cordova-app');
    await run('npx', ['--yes', 'cordova', 'create', project, packageId, safeName(appName, 'BenimUygulamam')]);
    const www = path.join(project, 'www');
    fs.rmSync(www, { recursive: true, force: true });
    fs.cpSync(webRoot, www, { recursive: true });
    await run('npx', ['--yes', 'cordova', 'platform', 'add', 'android'], project);
    await run('npx', ['--yes', 'cordova', 'build', 'android', '--debug'], project);
    const apk = path.join(project, 'platforms', 'android', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
    if (!fs.existsSync(apk)) throw new Error('Derleme tamamlandı ancak APK dosyası beklenen konumda bulunamadı.');
    res.download(apk, `${safeName(appName, 'uygulama')}-debug.apk`);
  } catch (e) {
    res.status(500).json({ error: e.message, hint: 'Sunucuda Node.js, Java JDK 17+, Android SDK ve Android build-tools kurulu olmalı.' });
  } finally {
    try { fs.rmSync(req.file.path, { force: true }); } catch {}
    // Keep build directory only until the response is prepared; remove on process exit.
    setTimeout(() => { try { fs.rmSync(work, { recursive: true, force: true }); } catch {} }, 60000).unref();
  }
});
app.listen(PORT, '0.0.0.0', () => console.log(`Cep APK Builder hazır: http://localhost:${PORT}`));
