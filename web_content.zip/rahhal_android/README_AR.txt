مشروع أندرويد — رحّالة العالم

هذا مشروع Android Studio يضم لعبة HTML محلية داخل WebView، ويمكن فتحه في Android Studio ثم بناء APK من:
Build > Build Bundle(s) / APK(s) > Build APK(s)

المتطلبات:
- Android Studio حديث
- JDK مناسب لإصدار Android Gradle Plugin
- اتصال أول مرة لتنزيل مكونات Gradle/Android SDK المطلوبة

الحزمة هنا هي مصدر مشروع قابل للبناء وليست APK جاهزًا. لم يتم تضمين Gradle Wrapper أو Android SDK في هذه الحزمة، كما أن بيئة الإنشاء الحالية لا تحتوي على أدوات بناء أندرويد لتوليد APK مباشرة.
