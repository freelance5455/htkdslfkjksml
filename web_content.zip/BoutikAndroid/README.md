# Boutik Android wrapper

Android Studio project wrapper for the Boutik HTML app. The app loads the HTML from assets and needs internet access for Supabase and the Supabase JS CDN.

## Build
1. Install Android Studio and Android SDK 35.
2. Open this folder (`BoutikAndroid`) in Android Studio.
3. Allow Gradle sync and install missing SDK components.
4. Run on a device, or Build > Build APK(s).

No Supabase service-role key is included. The HTML uses the publishable/anon key.
