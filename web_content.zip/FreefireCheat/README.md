# FreefireCheat — olliE bench

## Estrutura
```
FreefireCheat/
├── app/src/main/
│   ├── assets/index.html          ← painel WebView
│   ├── cpp/
│   │   ├── cheat.cpp              ← core ESP+Aimbot+NoRecoil
│   │   ├── CMakeLists.txt
│   │   └── include/dobby.h        ← COLOCAR AQUI
│   ├── jniLibs/arm64-v8a/
│   │   └── libdobby.a             ← COLOCAR AQUI
│   └── java/com/ollie/ff/
│       ├── MainActivity.kt        ← WebView loader
│       └── CheatBridge.kt         ← bridge JS→JNI
```

## Setup

1. Baixar Dobby prebuilt arm64:
   https://github.com/jmpews/Dobby/releases
   → `libdobby.a` em `jniLibs/arm64-v8a/`
   → `dobby.h`    em `cpp/include/`

2. Gerar gradlew:
   ```bash
   gradle wrapper --gradle-version 8.6
   ```

3. Substituir offsets em `cheat.cpp`:
   ```bash
   # Extrai APK → il2cppdumper libil2cpp.so global-metadata.dat ./dump
   # Grep dump.cs por: GameManager, PlayerEntity, TouchInput
   # RVA + BASE = endereço → cola nos OFF_*
   ```

4. Build:
   ```bash
   ./gradlew assembleRelease
   # APK em app/build/outputs/apk/release/
   ```

## Tabela de falhas
| Sintoma | Causa | Fix |
|---|---|---|
| Crash no load | OFF_GAME_UPDATE errado | Re-dump, verificar com IDA |
| ESP fora da tela | ViewMatrix offset errado | Transpor m[] |
| Aimbot sem efeito | TouchInput addr errado | Frida Memory.scan |
| Painel sem bridge | APK não injetado no FF | Usar Zygisk loader |
