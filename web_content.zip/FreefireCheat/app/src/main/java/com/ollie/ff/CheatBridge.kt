package com.ollie.ff

import android.webkit.JavascriptInterface

/**
 * Bridge JS → JNI → cheat.cpp
 * Exposto no WebView como window.Android
 */
class CheatBridge {

    companion object {
        init { System.loadLibrary("cheat") }
    }

    // ── Calls nativos ─────────────────────────────────────────────────────
    external fun nativeSetEsp(on: Boolean)
    external fun nativeSetHp(on: Boolean)
    external fun nativeSetSkeleton(on: Boolean)
    external fun nativeSetAimbot(on: Boolean)
    external fun nativeSetFov(px: Int)
    external fun nativeSetSmooth(scale: Float)
    external fun nativeSetNoRecoil(on: Boolean)
    external fun nativeGetStatus(): String

    // ── Interface JS ──────────────────────────────────────────────────────
    @JavascriptInterface fun setEsp(on: Boolean)      = nativeSetEsp(on)
    @JavascriptInterface fun setHp(on: Boolean)       = nativeSetHp(on)
    @JavascriptInterface fun setSkeleton(on: Boolean) = nativeSetSkeleton(on)
    @JavascriptInterface fun setAimbot(on: Boolean)   = nativeSetAimbot(on)
    @JavascriptInterface fun setFov(px: Int)          = nativeSetFov(px)
    @JavascriptInterface fun setSmooth(scale: Float)  = nativeSetSmooth(scale)
    @JavascriptInterface fun setNoRecoil(on: Boolean) = nativeSetNoRecoil(on)
    @JavascriptInterface fun getStatus(): String      = nativeGetStatus()
}
