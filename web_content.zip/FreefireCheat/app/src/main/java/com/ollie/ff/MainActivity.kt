package com.ollie.ff

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled        = true
            domStorageEnabled        = true
            allowFileAccess          = true
            allowContentAccess       = true
            cacheMode                = WebSettings.LOAD_NO_CACHE
            useWideViewPort          = true
            loadWithOverviewMode     = true
            builtInZoomControls      = false
            displayZoomControls      = false
        }

        // Injeta a bridge como window.Android
        webView.addJavascriptInterface(CheatBridge(), "Android")
        webView.webViewClient = WebViewClient()

        // Carrega o painel local
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
