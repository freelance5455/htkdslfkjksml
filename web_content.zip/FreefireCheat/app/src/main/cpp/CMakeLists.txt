cmake_minimum_required(VERSION 3.22.1)
project("cheat")

add_library(cheat SHARED cheat.cpp)

add_library(dobby STATIC IMPORTED)
set_target_properties(dobby PROPERTIES
    IMPORTED_LOCATION
    ${CMAKE_SOURCE_DIR}/../jniLibs/arm64-v8a/libdobby.a
)

target_include_directories(cheat PRIVATE ${CMAKE_SOURCE_DIR}/include)
target_link_libraries(cheat dobby log android)
