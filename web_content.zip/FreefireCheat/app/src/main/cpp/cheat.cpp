// cheat.cpp — Free Fire Android · arm64-v8a · NDK r25c
// Dobby: https://github.com/jmpews/Dobby — libdobby.a em jniLibs/arm64-v8a/
// dobby.h em cpp/include/

#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <cstring>
#include <vector>
#include <pthread.h>
#include <atomic>
#include "dobby.h"

#define TAG  "olliE_ff"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define BASE get_module_base("libil2cpp.so")

// ─── OFFSETS — substituir após dump com il2cppdumper ─────────────────────────
static uintptr_t OFF_ENTITY_LIST  = 0xDEAD0001; // GameManager.EntityList
static uintptr_t OFF_BONE_HEAD    = 0xDEAD0002; // PlayerEntity.BoneHead   Vec3
static uintptr_t OFF_BONE_CHEST   = 0xDEAD0003; // PlayerEntity.BoneChest  Vec3
static uintptr_t OFF_HEALTH       = 0xDEAD0004; // PlayerEntity.Health     float
static uintptr_t OFF_TEAM         = 0xDEAD0005; // PlayerEntity.Team       int
static uintptr_t OFF_VIEWMATRIX   = 0xDEAD0006; // GameCamera.ViewMatrix   float[16]
static uintptr_t OFF_PITCH_YAW    = 0xDEAD0007; // TouchInput.PitchYaw     Vec2
static uintptr_t OFF_RECOIL_DELTA = 0xDEAD0009; // TouchInput.RecoilDelta  Vec2
static uintptr_t OFF_GAME_UPDATE  = 0xDEAD0008; // GameManager::Update RVA

// ─── FLAGS controladas pelo painel ───────────────────────────────────────────
static std::atomic<bool> g_esp      {false};
static std::atomic<bool> g_hp       {true};
static std::atomic<bool> g_skeleton {false};
static std::atomic<bool> g_aimbot   {false};
static std::atomic<bool> g_noRecoil {false};
static std::atomic<int>  g_fov      {150};
static std::atomic<float>g_smooth   {0.08f};
static std::atomic<bool> g_hooked   {false};

static float SCR_W = 1080.f;
static float SCR_H = 1920.f;

struct Vec2 { float x, y; };
struct Vec3 { float x, y, z; };
struct Matrix4 { float m[16]; };

struct PlayerEntity {
    Vec3  bone_head;
    Vec3  bone_chest;
    float health;
    int   team;
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
uintptr_t get_module_base(const char* name) {
    char line[512]; uintptr_t base = 0;
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    while (fgets(line, sizeof(line), f))
        if (strstr(line, name)) { base = (uintptr_t)strtoul(line, nullptr, 16); break; }
    fclose(f);
    return base;
}

template<typename T> T    Read (uintptr_t a) { T v{}; memcpy(&v,(void*)a,sizeof(T)); return v; }
template<typename T> void Write(uintptr_t a, T v) { memcpy((void*)a,&v,sizeof(T)); }

bool WorldToScreen(const Vec3& w, Vec2& s, const Matrix4& vp) {
    const float* m = vp.m;
    float cx = m[0]*w.x+m[4]*w.y+m[8]*w.z+m[12];
    float cy = m[1]*w.x+m[5]*w.y+m[9]*w.z+m[13];
    float cW = m[3]*w.x+m[7]*w.y+m[11]*w.z+m[15];
    if (cW < 0.1f) return false;
    s.x = ((cx/cW)+1.f)*0.5f*SCR_W;
    s.y = (1.f-((cy/cW)+1.f)*0.5f)*SCR_H;
    return true;
}

// ─── Overlay stubs — conectar ao teu SurfaceView / ImGui ─────────────────────
extern "C" __attribute__((weak))
void overlay_draw_box (float,float,float,float,uint32_t){}
extern "C" __attribute__((weak))
void overlay_draw_text(float,float,const char*,uint32_t){}
extern "C" __attribute__((weak))
void overlay_draw_line(float,float,float,float,uint32_t){}

static void draw_esp(const std::vector<PlayerEntity>& pl, const Matrix4& vm) {
    if (!g_esp) return;
    for (const auto& p : pl) {
        if (p.health <= 0.f || p.team == 0) continue;
        Vec2 head{}, chest{};
        if (!WorldToScreen(p.bone_head,  head,  vm)) continue;
        if (!WorldToScreen(p.bone_chest, chest, vm)) continue;
        float h = chest.y - head.y;
        float w = h * 0.5f;
        float x = head.x - w*0.5f;
        overlay_draw_box(x, head.y, w, h, 0xFF00FFFF);
        if (g_hp) {
            char buf[16]; snprintf(buf,sizeof(buf),"%.0f",p.health);
            overlay_draw_text(x, head.y-14.f, buf, 0xFF00FF00);
        }
        if (g_skeleton) {
            // neck estimate — midpoint head/chest
            Vec2 neck{ (head.x+chest.x)*0.5f, (head.y+chest.y)*0.5f };
            overlay_draw_line(head.x,head.y,neck.x,neck.y,0xFFFFFFFF);
            overlay_draw_line(neck.x,neck.y,chest.x,chest.y,0xFFFFFFFF);
        }
    }
}

static void do_aimbot(const std::vector<PlayerEntity>& pl,
                      const Matrix4& vm, uintptr_t touch) {
    if (!g_aimbot) return;
    float best = 1e9f;
    Vec2  best_s{};
    bool  found = false;
    Vec2  ctr{ SCR_W*0.5f, SCR_H*0.5f };
    float fov = (float)g_fov.load();
    for (const auto& p : pl) {
        if (p.health <= 0.f || p.team == 0) continue;
        Vec2 s{};
        if (!WorldToScreen(p.bone_head, s, vm)) continue;
        float dx=s.x-ctr.x, dy=s.y-ctr.y;
        float d=sqrtf(dx*dx+dy*dy);
        if (d < fov && d < best) { best=d; best_s=s; found=true; }
    }
    if (!found) return;
    float sc = g_smooth.load();
    Vec2 delta{ (best_s.x-ctr.x)*sc, (best_s.y-ctr.y)*sc };
    Write<Vec2>(touch + OFF_PITCH_YAW, delta);
}

static void do_no_recoil(uintptr_t touch) {
    if (!g_noRecoil) return;
    Vec2 zero{0.f,0.f};
    Write<Vec2>(touch + OFF_RECOIL_DELTA, zero);
}

static std::vector<PlayerEntity> harvest(uintptr_t base) {
    std::vector<PlayerEntity> out;
    uintptr_t lp = Read<uintptr_t>(base + OFF_ENTITY_LIST);
    if (!lp) return out;
    int cnt = Read<int>(lp + 0x18);
    uintptr_t arr = Read<uintptr_t>(lp + 0x10);
    if (!arr || cnt<=0 || cnt>128) return out;
    for (int i=0;i<cnt;i++) {
        uintptr_t e = Read<uintptr_t>(arr + 0x20 + i*0x8);
        if (!e) continue;
        PlayerEntity p{};
        p.bone_head  = Read<Vec3>  (e+OFF_BONE_HEAD);
        p.bone_chest = Read<Vec3>  (e+OFF_BONE_CHEST);
        p.health     = Read<float> (e+OFF_HEALTH);
        p.team       = Read<int>   (e+OFF_TEAM);
        out.push_back(p);
    }
    return out;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────
using GameUpdate_t = void(*)(void*);
static GameUpdate_t orig = nullptr;

static void hk_GameUpdate(void* thiz) {
    orig(thiz);
    uintptr_t base = BASE;
    if (!base) return;
    Matrix4 vm = Read<Matrix4>(base + OFF_VIEWMATRIX);
    auto pl = harvest(base);
    draw_esp(pl, vm);
    do_aimbot(pl, vm, base);
    do_no_recoil(base);
}

static void* cheat_thread(void*) {
    LOGI("olliE — aguardando libil2cpp.so");
    uintptr_t base = 0;
    for (int i=0;i<120;i++) {
        base = BASE;
        if (base) break;
        usleep(500000); // 0.5s
    }
    if (!base) { LOGI("base nao encontrada"); return nullptr; }
    LOGI("base: 0x%lx", (unsigned long)base);
    DobbyHook(
        (void*)(base + OFF_GAME_UPDATE),
        (void*)hk_GameUpdate,
        (void**)&orig
    );
    g_hooked = true;
    LOGI("hook plantado — absolute olliE");
    return nullptr;
}

JNIEXPORT jint JNI_OnLoad(JavaVM*, void*) {
    pthread_t t;
    pthread_create(&t, nullptr, cheat_thread, nullptr);
    pthread_detach(t);
    return JNI_VERSION_1_6;
}

// ─── JNI exports para CheatBridge.kt ─────────────────────────────────────────
extern "C" {
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetEsp     (JNIEnv*,jobject,jboolean v){ g_esp=v; }
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetHp      (JNIEnv*,jobject,jboolean v){ g_hp=v; }
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetSkeleton(JNIEnv*,jobject,jboolean v){ g_skeleton=v; }
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetAimbot  (JNIEnv*,jobject,jboolean v){ g_aimbot=v; }
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetFov     (JNIEnv*,jobject,jint     v){ g_fov=v; }
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetSmooth  (JNIEnv*,jobject,jfloat   v){ g_smooth=v; }
JNIEXPORT void JNICALL Java_com_ollie_ff_CheatBridge_nativeSetNoRecoil(JNIEnv*,jobject,jboolean v){ g_noRecoil=v; }
JNIEXPORT jstring JNICALL Java_com_ollie_ff_CheatBridge_nativeGetStatus(JNIEnv* env, jobject) {
    const char* s = g_hooked.load() ? "hooked — bench running" : "aguardando hook...";
    return env->NewStringUTF(s);
}
}
