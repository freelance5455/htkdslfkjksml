SELAM PHARMACY HYBRID APP v3 — STARTER PACK

This package preserves the existing Version 2 offline HTML interface and adds an initial cloud database schema for the next development stage.

IMPORTANT: This package is NOT YET a live synchronized application. The HTML app still works locally. The SQL schema must be installed in a Supabase project, and the interface must then be connected to Supabase with a tested offline queue. Do not use it for real multi-device stock control until that integration is complete and tested.

WHAT IS INCLUDED
- index.html: current Selam Pharmacy offline app (Version 2), unchanged.
- database_setup.sql: initial tables, authenticated-user policies, and atomic stock movement function.
- README_Selam_Pharmacy_Hybrid_v3.txt: this file.

NO COMPUTER SOFTWARE INSTALLATION REQUIRED FOR THE DATABASE SETUP
You do not need to install Node.js or Android Studio to create the cloud database. Use a web browser:
1. Open https://supabase.com and create/sign in to an account.
2. Create a new project named Selam Pharmacy. Keep the database password private.
3. In the project, open SQL Editor, create a new query, paste all of database_setup.sql, and run it.
4. In Authentication / Users, create the shared login account. Do not put the password inside the HTML file.
5. Keep the project URL and publishable/anon key available for the later app connection step. Never use or share the service_role/secret key in the app.

OFFLINE AND SYNC DESIGN
- Each device must save transactions locally before showing success.
- Each queued transaction needs a stable unique client transaction ID.
- When online, retry unsynchronized transactions using that same ID; the server function is designed to recognize duplicate retries.
- Stock movement must be processed atomically on the server to protect against simultaneous changes.
- Offline devices cannot know about transactions recorded on other devices until they reconnect. The UI should clearly show pending sync and server rejections.

CURRENT LIMITATION
The existing Version 2 interface stores data locally in the browser. The database schema is the first step only; it does not automatically connect the current HTML interface to the cloud. That requires the next code integration and testing step.

PRIVACY / SAFETY
Use a strong shared password, restrict access to trusted staff, and back up data. Because all staff share one login, the system cannot reliably identify which individual staff member performed an action. Individual accounts are safer for accountability, even if the initial version uses a shared login.
