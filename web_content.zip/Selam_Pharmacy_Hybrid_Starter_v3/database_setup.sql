-- Selam Pharmacy Hybrid App v3 — initial Supabase schema
-- Run this in Supabase Dashboard > SQL Editor. Do NOT put a service-role key in the HTML app.
-- This starter uses one shared Supabase Auth login; all signed-in users have the same access.

create extension if not exists pgcrypto;

create table if not exists public.pharmacy_settings (
  id uuid primary key default gen_random_uuid(),
  pharmacy_name text not null default 'Selam Pharmacy',
  clinic_name text not null default 'Selam Medium Clinic',
  phone text,
  currency_code text not null default 'ETB',
  created_at timestamptz not null default now()
);

create table if not exists public.medicines (
  id uuid primary key default gen_random_uuid(),
  local_id text unique, -- optional ID from the existing offline app
  name text not null,
  generic_name text,
  strength text,
  dosage_form text,
  unit text not null default 'unit',
  barcode text,
  reorder_level numeric(14,3) not null default 0 check (reorder_level >= 0),
  purchase_price numeric(14,2) not null default 0 check (purchase_price >= 0),
  selling_price numeric(14,2) not null default 0 check (selling_price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stock_batches (
  id uuid primary key default gen_random_uuid(),
  medicine_id uuid not null references public.medicines(id),
  batch_number text not null default '',
  expiry_date date,
  store_qty numeric(14,3) not null default 0 check (store_qty >= 0),
  dispensary_qty numeric(14,3) not null default 0 check (dispensary_qty >= 0),
  unit_cost numeric(14,2) not null default 0 check (unit_cost >= 0),
  selling_price numeric(14,2) not null default 0 check (selling_price >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (medicine_id, batch_number, expiry_date)
);

create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  client_tx_id uuid not null unique, -- idempotency key from the device; prevents duplicate sync
  medicine_id uuid not null references public.medicines(id),
  batch_id uuid references public.stock_batches(id),
  movement_type text not null check (movement_type in
    ('opening_stock','purchase','sale','dispensary_issue','clinic_issue','return_in','return_out','adjustment')),
  from_location text check (from_location in ('store','dispensary','external')),
  to_location text check (to_location in ('store','dispensary','external')),
  quantity numeric(14,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null default 0 check (unit_price >= 0),
  reference_no text,
  note text,
  device_id text,
  client_recorded_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  client_tx_id uuid not null unique,
  supplier_id uuid references public.suppliers(id),
  invoice_number text,
  purchase_date date not null default current_date,
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  note text,
  device_id text,
  client_recorded_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  client_tx_id uuid not null unique,
  receipt_number text,
  sale_date timestamptz not null default now(),
  payment_method text not null default 'cash' check (payment_method in ('cash','credit','mobile_money','other')),
  total_amount numeric(14,2) not null default 0 check (total_amount >= 0),
  note text,
  device_id text,
  client_recorded_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.transaction_lines (
  id uuid primary key default gen_random_uuid(),
  transaction_type text not null check (transaction_type in ('purchase','sale','dispensary_issue','clinic_issue','return')),
  transaction_id uuid not null,
  medicine_id uuid not null references public.medicines(id),
  batch_id uuid references public.stock_batches(id),
  quantity numeric(14,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null default 0 check (unit_price >= 0),
  line_total numeric(14,2) generated always as (round(quantity * unit_price, 2)) stored
);

create index if not exists stock_batches_medicine_idx on public.stock_batches(medicine_id);
create index if not exists stock_batches_expiry_idx on public.stock_batches(expiry_date);
create index if not exists stock_movements_created_idx on public.stock_movements(created_at desc);
create index if not exists stock_movements_medicine_idx on public.stock_movements(medicine_id, created_at desc);
create index if not exists sales_date_idx on public.sales(sale_date desc);

-- All devices use the same shared Auth account in the selected configuration.
-- RLS prevents unauthenticated access. Signed-in users have broad access, but stock quantities
-- and movement history are read-only directly and must be changed through the atomic RPC.
alter table public.pharmacy_settings enable row level security;
alter table public.medicines enable row level security;
alter table public.stock_batches enable row level security;
alter table public.suppliers enable row level security;
alter table public.stock_movements enable row level security;
alter table public.purchases enable row level security;
alter table public.sales enable row level security;
alter table public.transaction_lines enable row level security;

do $$
declare t text;
begin
  foreach t in array array['pharmacy_settings','medicines','suppliers','purchases','sales','transaction_lines'] loop
    execute format('drop policy if exists "authenticated full access" on public.%I', t);
    execute format('create policy "authenticated full access" on public.%I for all to authenticated using (true) with check (true)', t);
  end loop;
  drop policy if exists "authenticated read stock batches" on public.stock_batches;
  create policy "authenticated read stock batches" on public.stock_batches for select to authenticated using (true);
  drop policy if exists "authenticated read stock movements" on public.stock_movements;
  create policy "authenticated read stock movements" on public.stock_movements for select to authenticated using (true);
  -- Stock quantities and movement history are changed only through the atomic RPC.
  revoke all on public.stock_batches from anon, authenticated;
  grant select on public.stock_batches to authenticated;
  revoke all on public.stock_movements from anon, authenticated;
  grant select on public.stock_movements to authenticated;
end $$;

-- Atomic stock movement RPC. Call this instead of directly changing quantities.
-- A queued offline transaction should retry with the SAME client_tx_id after reconnection.
create or replace function public.apply_stock_movement(
  p_client_tx_id uuid,
  p_medicine_id uuid,
  p_batch_id uuid,
  p_movement_type text,
  p_from_location text,
  p_to_location text,
  p_quantity numeric,
  p_unit_price numeric default 0,
  p_reference_no text default null,
  p_note text default null,
  p_device_id text default null,
  p_client_recorded_at timestamptz default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare b public.stock_batches%rowtype;
        existing_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'Quantity must be greater than zero';
  end if;
  if p_movement_type not in ('opening_stock','purchase','sale','dispensary_issue','clinic_issue','return_in','return_out','adjustment') then
    raise exception 'Unsupported movement type';
  end if;

  select id into existing_id from public.stock_movements where client_tx_id = p_client_tx_id;
  if existing_id is not null then
    return jsonb_build_object('ok', true, 'duplicate', true, 'movement_id', existing_id);
  end if;

  select * into b from public.stock_batches where id = p_batch_id for update;
  if not found or b.medicine_id <> p_medicine_id then
    raise exception 'Stock batch not found for this medicine';
  end if;

  -- Apply quantity changes under a row lock to prevent concurrent overselling.
  if p_from_location = 'store' then
    if b.store_qty < p_quantity then raise exception 'Insufficient store-room stock'; end if;
    update public.stock_batches set store_qty = store_qty - p_quantity, updated_at = now() where id = p_batch_id;
  elsif p_from_location = 'dispensary' then
    if b.dispensary_qty < p_quantity then raise exception 'Insufficient dispensary stock'; end if;
    update public.stock_batches set dispensary_qty = dispensary_qty - p_quantity, updated_at = now() where id = p_batch_id;
  end if;

  if p_to_location = 'store' then
    update public.stock_batches set store_qty = store_qty + p_quantity, updated_at = now() where id = p_batch_id;
  elsif p_to_location = 'dispensary' then
    update public.stock_batches set dispensary_qty = dispensary_qty + p_quantity, updated_at = now() where id = p_batch_id;
  end if;

  insert into public.stock_movements (
    client_tx_id, medicine_id, batch_id, movement_type, from_location, to_location,
    quantity, unit_price, reference_no, note, device_id, client_recorded_at, created_by
  ) values (
    p_client_tx_id, p_medicine_id, p_batch_id, p_movement_type, p_from_location, p_to_location,
    p_quantity, coalesce(p_unit_price,0), p_reference_no, p_note, p_device_id, p_client_recorded_at, auth.uid()
  ) returning id into existing_id;

  return jsonb_build_object('ok', true, 'duplicate', false, 'movement_id', existing_id);
end;
$$;

grant execute on function public.apply_stock_movement(uuid,uuid,uuid,text,text,text,numeric,numeric,text,text,text,timestamptz) to authenticated;

-- Security notes:
-- 1) Create the shared user in Supabase Auth; do not hard-code its password in the app.
-- 2) Use only the Supabase project URL and anon/publishable key in the browser app.
-- 3) NEVER expose a service_role/secret key in HTML, ZIP files, or APKs.
-- 4) This schema is a starting point; test with sample stock before using real pharmacy data.
-- 5) Offline queue must store unique client_tx_id values and retry safely after reconnecting.
-- 6) Batch creation/stock receiving should be implemented through controlled app workflows/RPCs;
--    do not grant direct client updates to stock quantities or movement history.
