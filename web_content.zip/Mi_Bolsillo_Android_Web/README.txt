MI BOLSILLO — PROYECTO WEB OFFLINE PARA CONVERTIR A APK
========================================================

Incluye:
- Interfaz responsive con tema negro y rojo.
- Saldo separado en banco y efectivo; el total es la suma de ambos.
- Retiro del banco a efectivo y transferencias entre ambas cuentas.
- Registro de sueldo e ingresos adicionales.
- Al registrar un nuevo sueldo, el saldo anterior disponible se mueve a Ahorros; el sueldo nuevo se añade al destino elegido.
- Gastos con selección de banco o efectivo.
- Deudas con pagos parciales o totales descontados de la cuenta elegida.
- Registro y seguimiento de préstamos.
- Presupuestos de transporte, universidad y gastos fijos.
- Ahorros manuales, historial, reportes y exportación CSV.
- Datos guardados localmente en el navegador mediante localStorage.

IMPORTANTE SOBRE LA REGLA DE SUELDO
La aplicación implementa la regla acordada: cuando confirmas un nuevo sueldo, todo el saldo disponible que quede entre banco y efectivo pasa a Ahorros y el sueldo/bonos nuevos se agregan al banco o al efectivo según el destino seleccionado. Comprueba que esta sea la regla que deseas antes de usarla con dinero real.

SALDO INICIAL
La demo inicia con Banco Bs 600 y Efectivo Bs 290, total Bs 890. Son importes ilustrativos editables desde el archivo app.js (objeto defaults).

CÓMO PROBAR
1. Extrae el ZIP.
2. Abre index.html en un navegador moderno.
3. Los datos se guardan localmente en ese navegador/dispositivo.

CÓMO CONVERTIR A APK
Opción sencilla: usa un creador de APK que permita empaquetar una web local/offline en una aplicación Android WebView. Carga index.html junto con style.css y app.js, y configura el inicio en index.html.
Opción Android Studio: crea un proyecto Android con WebView y copia los tres archivos a app/src/main/assets/. Configura la WebView para abrir file:///android_asset/index.html y habilita JavaScript y DOM storage. Para exportar el APK, compila desde Android Studio.

LIMITACIONES Y SEGURIDAD
- Esta es una aplicación local de demostración, no está conectada a bancos ni verifica transacciones reales.
- Los datos se almacenan en el dispositivo/navegador. Borrar sus datos puede borrar los movimientos.
- No es una aplicación bancaria certificada; haz copias de seguridad y verifica los saldos.
- Los préstamos registrados no ingresan ni descuentan dinero automáticamente al crearlos, para evitar movimientos duplicados. Las devoluciones se registran aparte.
