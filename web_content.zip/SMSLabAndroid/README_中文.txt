短信助手 Android 项目（真实短信应用交接版）

功能：填写一个收件人号码和短信正文，点“打开短信应用”后，系统打开手机默认短信应用并预填号码和内容。你需要在短信应用中核对并再次点发送。

安全与限制：
- 本应用本身不直接发送短信，也不申请 SEND_SMS 权限；使用 Android ACTION_SENDTO 将发送动作交给系统短信应用。
- 是否能发送取决于手机短信应用、SIM 卡、运营商服务及资费。
- 本应用不会自动批量发送，也不能保证短信送达；短信应用里的发送状态才是准确信息。

手机构建 APK（GitHub Actions）：
1. 登录 github.com，新建一个空仓库。
2. 在手机浏览器中打开仓库，把本项目文件上传（需要解压后上传文件，保留 .github/workflows/build-apk.yml 路径）。
3. 上传到 main 分支后，仓库 Actions 会自动运行 Build Android APK。
4. 打开成功的运行记录，在 Artifacts 下载 SMSLab-debug-apk.zip，解压得到 app-debug.apk。
5. 将 APK 下载到安卓手机，点击安装；如系统提示，允许该安装来源安装未知应用。

这是未签名的 debug APK，适合个人测试，不是 Play 商店发布包。
