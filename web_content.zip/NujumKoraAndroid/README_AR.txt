نجوم الكرة 3D - مشروع Android

هذا مشروع Android Studio جاهز يحتوي لعبة HTML داخل تطبيق Android (WebView).
هذه الملفات ليست APK جاهزاً؛ يلزم بناء المشروع عبر Android Studio.

طريقة إخراج APK:
1) فك ضغط NujumKoraAndroid.zip.
2) افتح مجلد NujumKoraAndroid في Android Studio.
3) انتظر اكتمال Gradle Sync.
4) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5) سيظهر ملف APK داخل app/build/outputs/apk/debug/app-debug.apk.

ملاحظة: أول بناء قد يحتاج إنترنت لتنزيل أدوات Android Gradle المطلوبة.
