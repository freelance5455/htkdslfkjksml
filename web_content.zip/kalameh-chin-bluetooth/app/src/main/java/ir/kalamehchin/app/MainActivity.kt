package ir.kalamehchin.app

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import org.json.JSONObject
import java.io.*
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pool = Executors.newCachedThreadPool()
    private val uuid: UUID = UUID.fromString("8f2f8d4a-6a5b-4b5e-9a0d-4c414c414d45")
    private val adapter: BluetoothAdapter? get() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var writer: BufferedWriter? = null
    @Volatile private var server: BluetoothServerSocket? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidBT")
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        requestBtPermissions()
    }

    private fun requestBtPermissions() {
        val p = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 77)
    }

    inner class Bridge {
        @JavascriptInterface fun status(): String = if (socket?.isConnected == true) "متصل" else "قطع"
        @JavascriptInterface fun pairedDevices(): String {
            if (!hasConnectPermission()) return "[]"
            val arr = org.json.JSONArray()
            try { adapter?.bondedDevices?.forEach { d -> arr.put(JSONObject().put("name", d.name ?: "دستگاه").put("address", d.address)) } } catch (_: Exception) {}
            return arr.toString()
        }
        @JavascriptInterface fun host() {
            if (!hasConnectPermission()) { ui("onBtStatus('مجوز بلوتوث لازم است')"); return }
            pool.execute {
                try {
                    server = adapter?.listenUsingRfcommWithServiceRecord("KalamehChin", uuid)
                    ui("onBtStatus('منتظر اتصال دوستت هستم…')")
                    val s = server?.accept() ?: throw IOException("Bluetooth unavailable")
                    attach(s)
                    ui("onBtStatus('دوستت وصل شد')")
                } catch (e: Exception) { ui("onBtStatus(${JSONObject.quote(e.message ?: "خطا در ایجاد اتاق")})") }
            }
        }
        @JavascriptInterface fun connect(address: String) {
            if (!hasConnectPermission()) { ui("onBtStatus('مجوز بلوتوث لازم است')"); return }
            pool.execute {
                try {
                    adapter?.cancelDiscovery()
                    val device = adapter?.getRemoteDevice(address) ?: throw IOException("دستگاه پیدا نشد")
                    val s = device.createRfcommSocketToServiceRecord(uuid)
                    s.connect(); attach(s)
                    ui("onBtStatus('اتصال برقرار شد')")
                } catch (e: Exception) { ui("onBtStatus(${JSONObject.quote(e.message ?: "اتصال ناموفق")})") }
            }
        }
        @JavascriptInterface fun send(message: String) {
            pool.execute { try { synchronized(this@MainActivity) { writer?.apply { write(message); newLine(); flush() } } } catch (_: Exception) { ui("onBtStatus('ارسال ناموفق')") } }
        }
    }

    private fun hasConnectPermission() = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun attach(s: BluetoothSocket) {
        socket?.close(); socket = s
        val input = BufferedReader(InputStreamReader(s.inputStream))
        writer = BufferedWriter(OutputStreamWriter(s.outputStream))
        pool.execute {
            try { while (s.isConnected) { val line = input.readLine() ?: break; ui("onBtMessage(${JSONObject.quote(line)})") } }
            catch (_: Exception) { }
            ui("onBtStatus('ارتباط قطع شد')")
        }
    }
    private fun ui(js: String) { runOnUiThread { web.evaluateJavascript("(function(){ $js })()", null) } }

    override fun onDestroy() {
        try { server?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        pool.shutdownNow(); super.onDestroy()
    }
}
