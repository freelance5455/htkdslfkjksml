# Nexus – instalacja na telefonie

## Wariant A: APK na Androida (Capacitor)
Wymagane: Node.js 18+, Android Studio.
1. npm install
2. npx cap add android
3. npx cap sync
4. npx cap open android  -> w Android Studio: Build > Build APK(s)
5. Plik APK znajdziesz w android/app/build/outputs/apk/debug/ – skopiuj na telefon i zainstaluj.

## Wariant B: PWA (Android i iPhone, bez Android Studio)
1. Wrzuć zawartość folderu www/ na dowolny hosting HTTPS (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Otwórz adres w telefonie: Chrome > menu > Zainstaluj aplikację; Safari > Udostępnij > Dodaj do ekranu początkowego.
3. Aplikacja działa potem w trybie pełnoekranowym i offline.

## iOS (App Store / TestFlight)
npm i @capacitor/ios, npx cap add ios, npx cap open ios (wymaga Maca i Xcode).
