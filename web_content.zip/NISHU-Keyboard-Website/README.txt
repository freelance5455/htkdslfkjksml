NISHU Keyboard Website
Open index.html in a browser.
Features: animated live wallpaper, English/Sinhala demo keyboard, chat UI, prompt UI, themes and settings.
The AI prompt is a frontend demo; a real AI API/backend must be connected for real AI responses.
