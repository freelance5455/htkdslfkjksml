// City Quest service worker: works offline after the first load.
const VER = 'cityquest-v1';
const CORE = ['./', './index.html', './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png', './icons/apple-touch-icon.png'];
// Third-party sign-in SDKs must always hit the network, never the cache.
const SKIP = /accounts\.google\.com|connect\.facebook\.net|appleid\.cdn-apple\.com/;

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VER).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== VER).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET' || SKIP.test(r.url)) return;
  if (r.mode === 'navigate') {            // network-first so updates arrive, cache fallback offline
    e.respondWith(fetch(r).then(res => {
      const copy = res.clone(); caches.open(VER).then(c => c.put('./index.html', copy)); return res;
    }).catch(() => caches.match('./index.html')));
    return;
  }
  e.respondWith(caches.match(r).then(hit => hit || fetch(r).then(res => {   // cache-first (fonts, icons)
    if (res.ok || res.type === 'opaque') { const copy = res.clone(); caches.open(VER).then(c => c.put(r, copy)); }
    return res;
  })));
});
