'use strict';

/* ===========================================================
   SPOOL — local folder cassette-deck music player
   Sab kuch local hai: koi file kabhi kahin upload nahi hoti.
   =========================================================== */

const AUDIO_EXT = ['mp3','wav','ogg','oga','m4a','flac','aac','webm','opus','wma'];

const els = {
  audio: document.getElementById('audio'),
  powerLed: document.getElementById('powerLed'),
  powerLabel: document.getElementById('powerLabel'),
  ledDot: document.querySelector('.led-dot'),
  reelLeft: document.getElementById('reelLeft'),
  reelRight: document.getElementById('reelRight'),
  tapeFill: document.getElementById('tapeFill'),
  lcdTitle: document.getElementById('lcdTitle'),
  lcdMarquee: document.getElementById('lcdMarquee'),
  lcdTime: document.getElementById('lcdTime'),
  lcdDuration: document.getElementById('lcdDuration'),
  lcdTrackNo: document.getElementById('lcdTrackNo'),
  seekBar: document.getElementById('seekBar'),
  volumeBar: document.getElementById('volumeBar'),
  btnPlay: document.getElementById('btnPlay'),
  iconPlay: document.getElementById('iconPlay'),
  iconPause: document.getElementById('iconPause'),
  btnPrev: document.getElementById('btnPrev'),
  btnNext: document.getElementById('btnNext'),
  btnShuffle: document.getElementById('btnShuffle'),
  btnRepeat: document.getElementById('btnRepeat'),
  btnPickFolder: document.getElementById('btnPickFolder'),
  fileInputFallback: document.getElementById('fileInputFallback'),
  loadHint: document.getElementById('loadHint'),
  trackList: document.getElementById('trackList'),
  trackEmpty: document.getElementById('trackEmpty'),
  trackCount: document.getElementById('trackCount'),
  vuLeft: document.getElementById('vuLeft'),
  vuRight: document.getElementById('vuRight'),
  installBtn: document.getElementById('installBtn'),
};

let playlist = [];        // { name, handleOrFile, url, duration }
let currentIndex = -1;
let shuffleOn = false;
let repeatMode = 0;       // 0 off, 1 repeat-all, 2 repeat-one
let shuffleOrder = [];
let objectUrl = null;

/* ---------- IndexedDB: remember the picked folder handle ---------- */
const DB_NAME = 'spool-db';
const STORE = 'handles';

function idbOpen(){
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbSet(key, val){
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(val, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function idbGet(key){
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/* ---------- Folder scanning (File System Access API) ---------- */
function isAudioFile(filename){
  const ext = filename.split('.').pop().toLowerCase();
  return AUDIO_EXT.includes(ext);
}

async function scanDirectory(dirHandle, path = ''){
  const found = [];
  for await (const [name, handle] of dirHandle.entries()){
    if (handle.kind === 'file'){
      if (isAudioFile(name)){
        found.push({ name, handle, path: path + name });
      }
    } else if (handle.kind === 'directory'){
      // ek level sub-folder tak dekh lo (Downloads me kabhi kabhi sub-folders hote hain)
      const sub = await scanDirectory(handle, path + name + '/');
      found.push(...sub);
    }
  }
  return found;
}

async function pickFolder(){
  if (!window.showDirectoryPicker){
    setHint('Ye browser folder-picker support nahi karta. Neeche "Files chuno" button use karo.', true);
    return;
  }
  try{
    const dirHandle = await window.showDirectoryPicker({ id: 'spool-downloads', startIn: 'downloads' });
    await idbSet('lastDir', dirHandle);
    await loadFromDirectoryHandle(dirHandle);
  }catch(err){
    if (err.name !== 'AbortError') console.error(err);
  }
}

async function loadFromDirectoryHandle(dirHandle){
  setHint('Folder scan ho raha hai…');
  const perm = await verifyPermission(dirHandle);
  if (!perm){
    setHint('Folder access permission nahi mili.', true);
    return;
  }
  const files = await scanDirectory(dirHandle);
  files.sort((a,b) => a.name.localeCompare(b.name, 'hi'));
  playlist = files.map(f => ({
    name: stripExt(f.name),
    fileHandle: f.handle,
    file: null,
    url: null,
  }));
  finishLoad(dirHandle.name);
}

async function verifyPermission(handle){
  const opts = { mode: 'read' };
  if ((await handle.queryPermission(opts)) === 'granted') return true;
  if ((await handle.requestPermission(opts)) === 'granted') return true;
  return false;
}

/* ---------- Fallback: plain <input type=file multiple> ---------- */
els.fileInputFallback.addEventListener('change', (e) => {
  const files = Array.from(e.target.files).filter(f => isAudioFile(f.name));
  if (!files.length) return;
  files.sort((a,b) => a.name.localeCompare(b.name, 'hi'));
  playlist = files.map(f => ({
    name: stripExt(f.name),
    fileHandle: null,
    file: f,
    url: null,
  }));
  finishLoad('local selection');
});

function stripExt(name){
  return name.replace(/\.[^/.]+$/, '');
}

function finishLoad(sourceLabel){
  currentIndex = -1;
  buildShuffleOrder();
  renderTrackList();
  setHint(`Loaded from "${sourceLabel}" — ${playlist.length} track mile.`);
  setPower(true, false);
  if (playlist.length){
    loadTrack(0, false);
  }
}

function setHint(text, isWarning){
  els.loadHint.textContent = text;
  els.loadHint.style.color = isWarning ? 'var(--red)' : 'var(--muted)';
}

/* ---------- Rendering playlist ---------- */
function renderTrackList(){
  els.trackList.innerHTML = '';
  els.trackCount.textContent = `${playlist.length} track${playlist.length===1?'':'s'}`;
  if (!playlist.length){
    const li = document.createElement('li');
    li.className = 'track-empty';
    li.id = 'trackEmpty';
    li.textContent = 'Koi track load nahi hui — upar se apna Downloads folder chuno.';
    els.trackList.appendChild(li);
    return;
  }
  playlist.forEach((track, i) => {
    const li = document.createElement('li');
    li.className = 'track-item' + (i === currentIndex ? ' active' : '');
    li.dataset.index = i;
    li.innerHTML = `
      <span class="track-num">${String(i+1).padStart(2,'0')}</span>
      <span class="track-name">${escapeHtml(track.name)}</span>
      <span class="track-dur">${track.durationLabel || ''}</span>
    `;
    li.addEventListener('click', () => loadTrack(i, true));
    els.trackList.appendChild(li);
  });
}

function escapeHtml(str){
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

function updateActiveRow(){
  document.querySelectorAll('.track-item').forEach(li => {
    li.classList.toggle('active', Number(li.dataset.index) === currentIndex);
  });
  const activeLi = document.querySelector('.track-item.active');
  if (activeLi) activeLi.scrollIntoView({ block: 'nearest' });
}

/* ---------- Playback ---------- */
async function loadTrack(index, autoplay){
  if (index < 0 || index >= playlist.length) return;
  currentIndex = index;
  const track = playlist[index];

  if (objectUrl){ URL.revokeObjectURL(objectUrl); objectUrl = null; }

  let file = track.file;
  if (!file && track.fileHandle){
    file = await track.fileHandle.getFile();
  }
  if (!file) return;

  objectUrl = URL.createObjectURL(file);
  els.audio.src = objectUrl;

  els.lcdTitle.textContent = track.name;
  els.lcdTrackNo.textContent = `${index+1}/${playlist.length}`;
  requestAnimationFrame(setupMarquee);

  updateActiveRow();
  ensureAudioGraph();

  if (autoplay){
    try{ await els.audio.play(); }catch(e){ /* user gesture might be needed */ }
  }
}

let wasPlaying = false;

function setupMarquee(){
  const wrap = els.lcdMarquee.parentElement;
  const needsScroll = els.lcdMarquee.scrollWidth > wrap.clientWidth + 4;
  els.lcdMarquee.classList.toggle('scroll', needsScroll);
}

function togglePlay(){
  if (!els.audio.src){
    if (playlist.length) loadTrack(0, true);
    return;
  }
  if (els.audio.paused){
    els.audio.play().catch(()=>{});
  } else {
    els.audio.pause();
  }
}

function playNext(userTriggered){
  if (!playlist.length) return;
  if (shuffleOn){
    const pos = shuffleOrder.indexOf(currentIndex);
    const nextPos = (pos + 1) % shuffleOrder.length;
    if (nextPos === 0 && !userTriggered && repeatMode !== 1){
      pauseAtEnd();
      return;
    }
    loadTrack(shuffleOrder[nextPos], true);
  } else {
    let next = currentIndex + 1;
    if (next >= playlist.length){
      if (repeatMode === 1 || userTriggered) next = 0;
      else { pauseAtEnd(); return; }
    }
    loadTrack(next, true);
  }
}

function playPrev(){
  if (!playlist.length) return;
  if (els.audio.currentTime > 3){
    els.audio.currentTime = 0;
    return;
  }
  if (shuffleOn){
    const pos = shuffleOrder.indexOf(currentIndex);
    const prevPos = (pos - 1 + shuffleOrder.length) % shuffleOrder.length;
    loadTrack(shuffleOrder[prevPos], true);
  } else {
    let prev = currentIndex - 1;
    if (prev < 0) prev = playlist.length - 1;
    loadTrack(prev, true);
  }
}

function pauseAtEnd(){
  els.audio.pause();
  els.audio.currentTime = 0;
  setPlayingVisual(false);
}

function buildShuffleOrder(){
  shuffleOrder = playlist.map((_, i) => i);
  for (let i = shuffleOrder.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i + 1));
    [shuffleOrder[i], shuffleOrder[j]] = [shuffleOrder[j], shuffleOrder[i]];
  }
}

/* ---------- Transport UI wiring ---------- */
els.btnPlay.addEventListener('click', togglePlay);
els.btnNext.addEventListener('click', () => playNext(true));
els.btnPrev.addEventListener('click', playPrev);
els.btnShuffle.addEventListener('click', () => {
  shuffleOn = !shuffleOn;
  els.btnShuffle.setAttribute('aria-pressed', String(shuffleOn));
  if (shuffleOn) buildShuffleOrder();
});
els.btnRepeat.addEventListener('click', () => {
  repeatMode = (repeatMode + 1) % 3;
  els.btnRepeat.setAttribute('aria-pressed', String(repeatMode !== 0));
  els.btnRepeat.style.color = repeatMode === 2 ? 'var(--green)' : (repeatMode === 1 ? 'var(--amber)' : '');
});
els.btnPickFolder.addEventListener('click', pickFolder);

els.audio.addEventListener('play', () => setPlayingVisual(true));
els.audio.addEventListener('pause', () => setPlayingVisual(false));
els.audio.addEventListener('timeupdate', onTimeUpdate);
els.audio.addEventListener('loadedmetadata', onLoadedMetadata);
els.audio.addEventListener('ended', () => {
  if (repeatMode === 2){
    els.audio.currentTime = 0;
    els.audio.play();
  } else {
    playNext(false);
  }
});

function setPlayingVisual(isPlaying){
  els.iconPlay.hidden = isPlaying;
  els.iconPause.hidden = !isPlaying;
  els.reelLeft.classList.toggle('spin', isPlaying);
  els.reelRight.classList.toggle('spin', isPlaying);
  els.ledDot.classList.toggle('playing', isPlaying);
  wasPlaying = isPlaying;
  if (isPlaying) resumeAudioContext();
}

function onLoadedMetadata(){
  els.lcdDuration.textContent = formatTime(els.audio.duration);
  if (currentIndex >= 0 && playlist[currentIndex]){
    playlist[currentIndex].durationLabel = formatTime(els.audio.duration);
    const li = document.querySelector(`.track-item[data-index="${currentIndex}"] .track-dur`);
    if (li) li.textContent = playlist[currentIndex].durationLabel;
  }
}

function onTimeUpdate(){
  const { currentTime, duration } = els.audio;
  els.lcdTime.textContent = formatTime(currentTime);
  if (duration){
    const pct = (currentTime / duration) * 100;
    els.seekBar.value = Math.round(pct * 10);
    els.seekBar.style.setProperty('--val', pct + '%');
    els.tapeFill.style.width = pct + '%';
    const shrink = 64 - (pct/100)*30;
    const grow = 34 + (pct/100)*30;
    els.reelLeft.style.width = els.reelLeft.style.height = shrink + 'px';
    els.reelRight.style.width = els.reelRight.style.height = grow + 'px';
  }
}

function formatTime(sec){
  if (!isFinite(sec) || sec < 0) return '00:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

els.seekBar.addEventListener('input', () => {
  const pct = els.seekBar.value / 10;
  els.seekBar.style.setProperty('--val', pct + '%');
  if (els.audio.duration){
    els.audio.currentTime = (pct/100) * els.audio.duration;
  }
});

els.volumeBar.addEventListener('input', () => {
  els.audio.volume = els.volumeBar.value / 100;
  els.volumeBar.style.setProperty('--val', els.volumeBar.value + '%');
});
els.audio.volume = els.volumeBar.value / 100;
els.volumeBar.style.setProperty('--val', els.volumeBar.value + '%');

/* ---------- Power LED ---------- */
function setPower(on, playing){
  els.ledDot.classList.toggle('on', on);
  els.ledDot.classList.toggle('playing', playing);
  els.powerLabel.textContent = on ? 'tape loaded' : 'no tape loaded';
}

/* ---------- Keyboard shortcuts ---------- */
window.addEventListener('keydown', (e) => {
  if (['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) return;
  if (e.code === 'Space'){ e.preventDefault(); togglePlay(); }
  else if (e.code === 'ArrowRight'){ els.audio.currentTime = Math.min(els.audio.duration||0, els.audio.currentTime + 5); }
  else if (e.code === 'ArrowLeft'){ els.audio.currentTime = Math.max(0, els.audio.currentTime - 5); }
  else if (e.code === 'ArrowUp'){ e.preventDefault(); els.volumeBar.value = Math.min(100, +els.volumeBar.value + 5); els.volumeBar.dispatchEvent(new Event('input')); }
  else if (e.code === 'ArrowDown'){ e.preventDefault(); els.volumeBar.value = Math.max(0, +els.volumeBar.value - 5); els.volumeBar.dispatchEvent(new Event('input')); }
  else if (e.code === 'KeyN'){ playNext(true); }
  else if (e.code === 'KeyP'){ playPrev(); }
});

/* ---------- VU meters via Web Audio API ---------- */
let audioCtx = null, analyserL = null, analyserR = null, splitter = null, sourceNode = null;

function ensureAudioGraph(){
  if (audioCtx) return;
  try{
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    sourceNode = audioCtx.createMediaElementSource(els.audio);
    splitter = audioCtx.createChannelSplitter(2);
    analyserL = audioCtx.createAnalyser();
    analyserR = audioCtx.createAnalyser();
    analyserL.fftSize = 256;
    analyserR.fftSize = 256;
    sourceNode.connect(splitter);
    splitter.connect(analyserL, 0);
    splitter.connect(analyserR, 1);
    sourceNode.connect(audioCtx.destination);
    drawVU();
  }catch(e){
    console.warn('AudioContext setup failed', e);
  }
}

function resumeAudioContext(){
  if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
}

function drawVU(){
  requestAnimationFrame(drawVU);
  if (!analyserL || !analyserR) return;
  drawChannel(els.vuLeft, analyserL);
  drawChannel(els.vuRight, analyserR);
}

function drawChannel(canvas, analyser){
  const ctx = canvas.getContext('2d');
  const buf = new Uint8Array(analyser.frequencyBinCount);
  analyser.getByteFrequencyData(buf);
  let sum = 0;
  for (let i=0;i<buf.length;i++) sum += buf[i];
  const level = Math.min(1, (sum / buf.length) / 130);

  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0,0,w,h);
  const segCount = 24;
  const gap = 3;
  const segW = (w - gap*(segCount-1)) / segCount;
  const litSegs = Math.round(level * segCount);
  for (let i=0;i<segCount;i++){
    const x = i * (segW + gap);
    let color = '#3a3940';
    if (i < litSegs){
      const frac = i / segCount;
      color = frac < 0.65 ? '#8fd694' : (frac < 0.85 ? '#ffb454' : '#e2574c');
    }
    ctx.fillStyle = color;
    roundRect(ctx, x, 0, segW, h, 2);
    ctx.fill();
  }
}

function roundRect(ctx, x, y, w, h, r){
  ctx.beginPath();
  ctx.moveTo(x+r, y);
  ctx.arcTo(x+w, y, x+w, y+h, r);
  ctx.arcTo(x+w, y+h, x, y+h, r);
  ctx.arcTo(x, y+h, x, y, r);
  ctx.arcTo(x, y, x+w, y, r);
  ctx.closePath();
}

/* draw idle (silent) VU bars at start so panel doesn't look broken */
(function drawIdle(){
  [els.vuLeft, els.vuRight].forEach(canvas => {
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const segCount = 24, gap = 3;
    const segW = (w - gap*(segCount-1)) / segCount;
    for (let i=0;i<segCount;i++){
      ctx.fillStyle = '#3a3940';
      roundRect(ctx, i*(segW+gap), 0, segW, h, 2);
      ctx.fill();
    }
  });
})();

/* ---------- Restore last folder on load ---------- */
(async function restoreLastFolder(){
  if (!window.showDirectoryPicker) {
    setHint('Ye browser folder-picker support nahi karta. "Files chuno" use karo.');
    return;
  }
  try{
    const dirHandle = await idbGet('lastDir');
    if (dirHandle){
      const perm = await dirHandle.queryPermission({ mode: 'read' });
      if (perm === 'granted'){
        await loadFromDirectoryHandle(dirHandle);
      } else {
        setHint(`Pichli baar "${dirHandle.name}" load kiya tha — dubara access dene ke liye button dabao.`);
      }
    }
  }catch(e){ /* ignore */ }
})();

/* ---------- PWA install prompt ---------- */
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  els.installBtn.hidden = false;
});
els.installBtn.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  els.installBtn.hidden = true;
});

/* ---------- Service worker ---------- */
if ('serviceWorker' in navigator){
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(()=>{});
  });
}

/* initial LCD marquee check on resize */
window.addEventListener('resize', setupMarquee);
