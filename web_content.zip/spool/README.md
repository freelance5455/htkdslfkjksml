# SPOOL — Download Folder Tape Deck 🎛️

Ek chhota, 100% local music player PWA jo aapke computer/phone ke
**Downloads folder** (ya kisi bhi folder) se audio files utha kar
ek cassette-deck jaisi UI me bajata hai. Koi bhi file kabhi kisi
server par upload nahi hoti — sab kuch sirf aapke browser ke andar
chalta hai.

## Chalu kaise karein

Browsers security ke wajah se `file://` folder se seedha kaam nahi
karte, isliye ise ek chhote local server se open karna padega
(bilkul free, koi internet chahiye nahi):

1. Is zip ko kisi bhi folder me extract karo.
2. Terminal me us folder me jaake ye chalao (Python already hota hai
   zyada tar systems me):
   ```
   python3 -m http.server 8080
   ```
   (Node hai to: `npx serve .`)
3. Browser me kholo: `http://localhost:8080`
4. **"Downloads folder load karo"** button dabao aur apna Downloads
   folder select karo (Chrome / Edge / Brave / Opera me best kaam
   karta hai).
5. Agar aapka browser folder-picker support nahi karta (jaise
   Firefox/Safari), to **"Files chuno (fallback)"** se seedhe apni
   audio files multi-select kar sakte ho.

## Features

- 🎧 Downloads folder (ya koi bhi folder, sub-folders sahit) se
  saari `.mp3 .wav .ogg .m4a .flac .aac .webm .opus .wma` files
  playlist me aa jaati hain.
- ▶️ Play / pause / next / previous / shuffle / repeat-all /
  repeat-one, seek bar, volume.
- 📼 Cassette reels asli playback progress ke hisaab se ghoomti aur
  size badalti hain (left reel chhoti hoti jaati hai, jaise tape
  fizically move ho rahi ho).
- 📊 Live L/R VU meters — asli audio se Web Audio API ke through.
- 💾 Ek baar folder allow karne ke baad, agli baar wapas aane par
  browser permission yaad rakhta hai (IndexedDB me handle save hota
  hai) — bas ek click me phir se load ho jaata hai.
- 📱 **Installable PWA** — "Install app" button ya browser ke
  install-icon se home screen / desktop par app jaisa install ho
  sakta hai, aur app-shell offline cache ho jaata hai.
- 🔒 Privacy-first: koi network call nahi audio ke liye, koi
  analytics nahi, koi tracking nahi.

## Files

```
index.html      → structure
style.css       → cassette-deck / rack-mount visual design
app.js          → folder access, playback, VU meters, PWA logic
manifest.json   → PWA manifest
sw.js           → offline app-shell caching service worker
icons/          → app icons (svg + png)
```

## Browser support note

`showDirectoryPicker` (seedha folder pick karne wala) sirf Chromium
based browsers (Chrome, Edge, Brave, Opera, Chrome Android) me hai.
Firefox aur Safari me "Files chuno" fallback use karo — usme aap
apni Downloads folder khol kar sab audio files ek saath select kar
sakte ho, wahi kaam ho jaata hai.

Enjoy! 🎶
