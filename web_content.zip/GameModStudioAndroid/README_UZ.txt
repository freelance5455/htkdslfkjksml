GAME MOD STUDIO — ANDROID STUDIO LOYIHASI

Ushbu loyiha CheatDroid uslubidagi qorong‘i interfeysga ega APK tanlash va statik tuzilma tahlili vositasini ham o‘z ichiga oladi.

Imkoniyatlar:
- O‘yinlar ro‘yxati va mahalliy profil sozlamalari.
- JSON konfiguratsiyasidagi mavjud maydonlarni tekshirish va patch nusxasini saqlash.
- APK faylini Android fayl tanlagichidan tanlash.
- APK ZIP arxivi, AndroidManifest.xml, classes.dex, resources.arsc, native kutubxonalar va ichki fayl nomlarini ko‘rish.
- Zaxira olish va tiklash.

MUHIM CHEKLOVLAR:
- APK tahlili statik va asosiy darajada; bu antivirus yoki to‘liq dekompilyator emas.
- APK ichidagi kodni o‘zgartirmaydi, imzo/litsenziya/anti-cheat himoyasini chetlab o‘tmaydi.
- DLS 26 kabi onlayn o‘yinlarning serverda saqlanadigan coin/gem balansini o‘zgartirmaydi.
- JSON patch faqat o‘yin shu konfiguratsiya faylini o‘qisa ta’sir qiladi.

APK yaratish:
1. Android Studio o‘rnating.
2. ZIPni oching va Android Studio -> Open orqali GameModStudioAndroid papkasini tanlang.
3. Gradle Sync tugashini kuting.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s) ni bosing.
5. APK odatda app/build/outputs/apk/debug/app-debug.apk manzilida paydo bo‘ladi.

Bu ish muhiti Android SDK/Gradle kompilyatsiya vositalariga ega bo‘lmagani uchun tayyor APK binarini shu yerda yaratib bo‘lmadi; ZIP Android Studio orqali kompilyatsiya qilish uchun loyiha manbalarini beradi.
