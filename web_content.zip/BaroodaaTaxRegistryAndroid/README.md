# Bulchiinsa Magaalaa Baroodaa – Android project

This is an offline Android WebView app generated from the approved Excel workbook.

## Imported data
- Source workbook: `baaxii gorroo 2018 zoni hunda.xlsx`
- Included sheets: Sheet1–Sheet5
- Excluded: Sheet6 (overlapping Z1 list)
- Imported rows: 2052
- Zone counts: {"Z1": 277, "Z2": 633, "Z3": 425, "Z4": 415, "GF": 81, "Z5": 221}
- Source values for area, tariff, kiraa, gibira and total are retained as supplied.
- The workbook does not provide a separate taxpayer registration number. The app displays a reference made from the sheet zone and original row serial (for example, Z1/001); this is an app reference, not a new official number.

## Build APK in Android Studio
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder (`BaroodaaTaxRegistry`) in Android Studio.
3. Allow Gradle sync and install any prompted Android build components.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to the Android phone and install it. If prompted, allow installation from that file manager.

## Features
- Offline database bundled in `app/src/main/assets/data.js`
- Search by name, serial reference, zone and service
- Zone and service filters, sorting and pagination
- Detail view, copy record, totals dashboard
- CSV export through Android's Save As dialog
- Android print / Save as PDF

## Notes
- The APK is not prebuilt in this environment because Android SDK/Gradle build tools are not installed here. This is a complete Android Studio source project ready to build.
- Review and verify the source workbook before official municipal use. The app does not invent or recalculate the supplied tax amounts.
