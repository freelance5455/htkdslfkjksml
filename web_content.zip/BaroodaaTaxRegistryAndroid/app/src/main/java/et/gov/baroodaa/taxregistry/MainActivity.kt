package et.gov.baroodaa.taxregistry

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStreamWriter

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingCsv: String = ""
    private var pendingFileName: String = "Kafaltoota_Baroodaa.csv"
    private val createCsvRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AppBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")

    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "if(document.getElementById('detail').classList.contains('show')){closeDetail();}else{Android.confirmExit();}",
            null
        )
    }

    inner class AppBridge {
        @JavascriptInterface
        fun saveCsv(csv: String, filename: String) {
            pendingCsv = csv
            pendingFileName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_")
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/csv"
                    putExtra(Intent.EXTRA_TITLE, pendingFileName)
                }
                startActivityForResult(intent, createCsvRequest)
            }
        }

        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = webView.createPrintDocumentAdapter("Baroodaa_Taxpayer_Report")
                printManager.print(
                    "Baroodaa Taxpayer Report",
                    adapter,
                    PrintAttributes.Builder().build()
                )
            }
        }

        @JavascriptInterface
        fun copyText(value: String) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Taxpayer record", value))
            runOnUiThread { Toast.makeText(this@MainActivity, "Galmeen copy ta'eera", Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface
        fun confirmExit() {
            runOnUiThread { finish() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createCsvRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.openOutputStream(uri)?.use { stream ->
                OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(pendingCsv) }
            }
            Toast.makeText(this, "CSV galmaa'eera", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
