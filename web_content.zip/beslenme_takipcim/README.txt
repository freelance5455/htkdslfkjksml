BESLENME TAKİPÇİM — WEB UYGULAMASI KAYNAK DOSYALARI

İÇERİK
- index.html: uygulama ekranı
- style.css: görünüm
- app.js: menü, su/öğün/takviye takibi ve bildirimler
- manifest.json, sw.js: PWA temel dosyaları

NASIL AÇILIR?
1. ZIP dosyasını çıkarın.
2. index.html dosyasını tarayıcıda açarak temel özellikleri deneyin.
3. Ana ekrana yüklenebilir PWA olarak kurulum ve bildirimlerin daha güvenilir çalışması için dosyaları HTTPS destekli bir web sunucusunda yayımlamak gerekir. Dosyayı doğrudan açmak tüm PWA özelliklerini desteklemeyebilir.

ANDROID APK NOTU
Bu ZIP, hazır APK değildir; web uygulamasının kaynak dosyalarıdır. APK üretmek için Android Studio/Capacitor gibi bir araçla paketleme veya bir PWA paketleme hizmeti gerekir. Bu dosyalar tek başına APK kurmaz.

SAĞLIK GÜVENLİĞİ
Menü genel örnektir; kişisel tıbbi diyet değildir. Tüp mide sonrası tolerans kişiden kişiye değişir. Rahatsızlık, bulantı veya ağrı olduğunda yemeyi bırakın ve bariatrik ekibinizin önerisini izleyin. İlaç ve takviyelerin doz/saatlerini doktor veya eczacı talimatına göre girin; uygulama doz önermez. Daha önce bildirilen düşük ferritin ve halsizlik için sağlık profesyoneliyle takip önemlidir.
