/* =====================================================
   NINJA KING
   SIDE VIEW + MOVING WORLD + TRAIN
   ADVANCED BOSS FIGHT EDITION
===================================================== */


/* =====================================================
   CANVAS
===================================================== */

const canvas =
    document.getElementById("gameCanvas");

const ctx =
    canvas.getContext("2d");


let W = window.innerWidth;
let H = window.innerHeight;


function resizeCanvas() {

    W = window.innerWidth;
    H = window.innerHeight;

    canvas.width = W;
    canvas.height = H;
}


window.addEventListener(
    "resize",
    resizeCanvas
);

resizeCanvas();


/* =====================================================
   SETTINGS
===================================================== */

const MAX_LEVEL = 50;

const ENEMIES_PER_LEVEL = 20;


/* =====================================================
   GAME STATE
===================================================== */

let currentLevel = 1;

let selectedLevel = 1;

let currentScreen = "main";

let gameRunning = false;

let gamePaused = false;

let score = 0;

let coins = 0;

let enemyKills = 0;

let enemySpawnTimer = 0;

let enemySpawnDelay = 90;

let shake = 0;

let lastTime = 0;

let volumeOn = true;

/* =====================================================
   TAPCHALLANGE SOUND ENGINE
   Horror atmosphere: rain, thunder, sharper sword sweeps, heavy impacts.
===================================================== */
let gameAudioContext = null;
let soundMasterGain = null;
let backgroundMusic = null;

function getGameAudioContext() {
    if (!gameAudioContext) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return null;
        gameAudioContext = new AudioContextClass();
        soundMasterGain = gameAudioContext.createGain();
        soundMasterGain.gain.value = 0.42;
        soundMasterGain.connect(gameAudioContext.destination);
    }
    if (gameAudioContext.state === "suspended") gameAudioContext.resume().catch(() => {});
    return gameAudioContext;
}

function startBackgroundMusic() {
    if (!volumeOn || currentScreen !== "game") return;
    try {
        if (!backgroundMusic) {
            backgroundMusic = new Audio("sounds/background-music.wav");
            backgroundMusic.loop = true;
            backgroundMusic.volume = 0.28;
            backgroundMusic.preload = "auto";
        }
        const playPromise = backgroundMusic.play();
        if (playPromise && playPromise.catch) playPromise.catch(() => {});
    } catch (e) {}
}

function stopBackgroundMusic() {
    if (backgroundMusic) backgroundMusic.pause();
}

function playGameSound(type) {
    if (!volumeOn) return;
    const ctx = getGameAudioContext();
    if (!ctx || !soundMasterGain) return;
    const now = ctx.currentTime;

    function tone(startFreq, endFreq, duration, wave, peak, delay = 0) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = wave || "sine";
        osc.frequency.setValueAtTime(Math.max(1, startFreq), now + delay);
        osc.frequency.exponentialRampToValueAtTime(Math.max(1, endFreq), now + delay + duration);
        gain.gain.setValueAtTime(0.0001, now + delay);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak * 0.48), now + delay + 0.018);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + duration);
        osc.connect(gain);
        gain.connect(soundMasterGain);
        osc.start(now + delay);
        osc.stop(now + delay + duration + 0.025);
    }

    function noise(duration, peak, filterType, frequency, delay = 0) {
        const length = Math.max(1, Math.floor(ctx.sampleRate * duration));
        const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
        const source = ctx.createBufferSource();
        const filter = ctx.createBiquadFilter();
        const gain = ctx.createGain();
        source.buffer = buffer;
        filter.type = filterType || "lowpass";
        filter.frequency.setValueAtTime(frequency || 1000, now + delay);
        gain.gain.setValueAtTime(Math.max(0.0001, peak * 0.32), now + delay);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + duration);
        source.connect(filter);
        filter.connect(gain);
        gain.connect(soundMasterGain);
        source.start(now + delay);
        source.stop(now + delay + duration + 0.02);
    }

    switch (type) {
        case "jump": tone(240, 430, 0.15, "sine", 0.075); break;
        case "punch":
            noise(0.12, 0.18, "lowpass", 520);
            tone(155, 48, 0.16, "sawtooth", 0.12);
            tone(78, 42, 0.13, "sine", 0.10, 0.025);
            break;
        case "sword":
            noise(0.23, 0.16, "highpass", 2400);
            tone(950, 180, 0.22, "sawtooth", 0.055);
            tone(1450, 720, 0.18, "triangle", 0.035, 0.015);
            break;
        case "hit":
            noise(0.12, 0.18, "bandpass", 900);
            tone(180, 48, 0.16, "sawtooth", 0.13);
            break;
        case "playerHit":
            noise(0.14, 0.16, "lowpass", 520);
            tone(130, 52, 0.20, "triangle", 0.11);
            tone(420, 290, 0.24, "sawtooth", 0.025, 0.025);
            break;
        case "deathGrunt":
            // A short, breathy, two-part "hoo... hoo" hero defeat vocal made locally.
            for (const part of [{d:0, len:0.34, f:155},{d:0.39, len:0.42, f:118}]) {
                const osc = ctx.createOscillator();
                const formant = ctx.createBiquadFilter();
                const voiceGain = ctx.createGain();
                const breath = ctx.createBufferSource();
                const breathFilter = ctx.createBiquadFilter();
                const breathGain = ctx.createGain();
                const n = Math.floor(ctx.sampleRate * part.len);
                const buf = ctx.createBuffer(1, n, ctx.sampleRate);
                const arr = buf.getChannelData(0);
                for (let i = 0; i < n; i++) arr[i] = (Math.random() * 2 - 1) * (1 - i / n);
                osc.type = "sawtooth";
                osc.frequency.setValueAtTime(part.f, now + part.d);
                osc.frequency.exponentialRampToValueAtTime(part.f * 0.72, now + part.d + part.len);
                formant.type = "bandpass"; formant.frequency.setValueAtTime(560, now + part.d); formant.Q.value = 1.4;
                voiceGain.gain.setValueAtTime(0.0001, now + part.d);
                voiceGain.gain.exponentialRampToValueAtTime(0.035, now + part.d + 0.045);
                voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + part.d + part.len);
                osc.connect(formant); formant.connect(voiceGain); voiceGain.connect(soundMasterGain);
                osc.start(now + part.d); osc.stop(now + part.d + part.len + 0.02);
                breath.buffer = buf; breathFilter.type = "bandpass"; breathFilter.frequency.value = 850; breathFilter.Q.value = 0.7;
                breathGain.gain.setValueAtTime(0.012, now + part.d);
                breathGain.gain.exponentialRampToValueAtTime(0.0001, now + part.d + part.len);
                breath.connect(breathFilter); breathFilter.connect(breathGain); breathGain.connect(soundMasterGain);
                breath.start(now + part.d); breath.stop(now + part.d + part.len + 0.02);
            }
            break;
        case "enemyDefeat": tone(250, 120, 0.20, "sine", 0.08); break;
        case "star": tone(740, 520, 0.16, "sine", 0.07); tone(880, 660, 0.12, "sine", 0.035, 0.04); break;
        case "bossHit": noise(0.18, 0.19, "lowpass", 360); tone(118, 38, 0.25, "sawtooth", 0.14); break;
        case "bossAttack": noise(0.24, 0.15, "lowpass", 650); tone(240, 52, 0.28, "sawtooth", 0.10); break;
        case "bossDefeat": tone(260, 110, 0.42, "triangle", 0.09); tone(392, 196, 0.38, "sine", 0.055, 0.08); break;
        case "gameOver": tone(330, 220, 0.25, "sine", 0.07); tone(220, 110, 0.38, "sine", 0.065, 0.23); break;
        case "victory": tone(523, 659, 0.18, "sine", 0.07); tone(659, 784, 0.20, "sine", 0.07, 0.16); tone(784, 1047, 0.30, "sine", 0.07, 0.34); break;
        case "levelStart": tone(392, 494, 0.12, "sine", 0.05); tone(494, 659, 0.16, "sine", 0.055, 0.12); break;
        case "click": tone(520, 440, 0.045, "sine", 0.025); break;
    }
}


/* =====================================================
   BACKGROUND
===================================================== */

let backgroundOffset = 0;

let backgroundSpeed = 1.8;

let sceneTimer = 0;

const SCENE_DURATION = 35;

let currentScene = 0;


/* =====================================================
   PLAYER
===================================================== */

const player = {

    x: 180,

    y: 0,

    vx: 0,

    vy: 0,

    speed: 4.3,

    jumpPower: 13,

    gravity: .58,

    maxHp: 100,

    hp: 100,

    facing: 1,

    walkTime: 0,

    punchTimer: 0,

    swordTimer: 0,

    hitTimer: 0,

    invincibleTimer: 0,

    attackCooldown: 0,

    blockTimer: 0,

    parryTimer: 0,

    counterTimer: 0

};


/* =====================================================
   STAR PROJECTILE SYSTEM
===================================================== */

let starCooldown = 0;

const STAR_DAMAGE = 3;

let starProjectiles = [];


/* =====================================================
   OBJECTS
===================================================== */

let enemies = [];

let particles = [];

let floatingTexts = [];


/* =====================================================
   INPUT
===================================================== */

const keys = {

    left: false,

    right: false

};


/* =====================================================
   UI
===================================================== */

const playerHpBar =
    document.getElementById(
        "playerHpBar"
    );

const playerHpText =
    document.getElementById(
        "playerHpText"
    );

const levelText =
    document.getElementById(
        "levelText"
    );

const enemyCount =
    document.getElementById(
        "enemyCount"
    );

const coinText =
    document.getElementById(
        "coinText"
    );

const bossHud =
    document.getElementById(
        "bossHud"
    );

const bossName =
    document.getElementById(
        "bossName"
    );

const bossHpBar =
    document.getElementById(
        "bossHpBar"
    );


/* =====================================================
   HELPERS
===================================================== */

function groundY() {

    return H -
        Math.max(
            105,
            H * .16
        );
}


function clamp(
    value,
    min,
    max
) {

    return Math.max(
        min,
        Math.min(
            max,
            value
        )
    );
}


function random(
    min,
    max
) {

    return Math.random() *
        (max - min) +
        min;
}


/* =====================================================
   SCREENS
===================================================== */

const screens = [

    "mainMenu",
    "levelSelect",
    "pauseMenu",
    "gameOver",
    "victory",
    "exitScreen"

];


function hideAllScreens() {

    screens.forEach(
        id => {

            document
                .getElementById(id)
                .classList.add(
                    "hidden"
                );

        }
    );

}


function hideStar() {

    const starBtn =
        document.getElementById(
            "starBtn"
        );

    if (starBtn) {

        starBtn.style.display =
            "none";

    }

}


function showMainMenu() {

    gameRunning = false;

    gamePaused = false;

    currentScreen = "main";

    stopBackgroundMusic();

    hideAllScreens();

    document
        .getElementById(
            "mainMenu"
        )
        .classList.remove(
            "hidden"
        );

    bossHud.style.display =
        "none";

    hideStar();

    updateHUD();

}


function showLevelSelect() {

    gameRunning = false;

    gamePaused = false;

    currentScreen = "levels";

    stopBackgroundMusic();

    hideAllScreens();

    document
        .getElementById(
            "levelSelect"
        )
        .classList.remove(
            "hidden"
        );

    buildLevelGrid();

    hideStar();

}


function showPauseMenu() {

    if (!gameRunning) {

        return;

    }

    gamePaused = true;

    stopBackgroundMusic();

    currentScreen = "pause";

    hideAllScreens();

    document
        .getElementById(
            "pauseMenu"
        )
        .classList.remove(
            "hidden"
        );

}


/* =====================================================
   LEVEL GRID
===================================================== */

function buildLevelGrid() {

    const grid =
        document.getElementById(
            "levelsGrid"
        );

    grid.innerHTML = "";


    let unlocked =
        parseInt(
            localStorage.getItem(
                "ninjaKingUnlocked"
            )
        ) || 1;


    unlocked =
        clamp(
            unlocked,
            1,
            MAX_LEVEL
        );


    for (
        let i = 1;
        i <= MAX_LEVEL;
        i++
    ) {

        const button =
            document.createElement(
                "button"
            );


        button.className =
            "levelButton";


        if (i <= unlocked) {

            button.classList.add(
                "unlocked"
            );

            button.textContent =
                i;


            button.addEventListener(
                "click",
                () => {

                    selectedLevel =
                        i;

                    startLevel(i);

                }
            );

        } else {

            button.classList.add(
                "locked"
            );

            button.textContent =
                "🔒";

        }


        grid.appendChild(
            button
        );

    }

}


/* =====================================================
   RESET COMBAT
===================================================== */

function resetPlayerCombat() {

    player.punchTimer = 0;

    player.swordTimer = 0;

    player.hitTimer = 0;

    player.invincibleTimer = 0;

    player.attackCooldown = 0;

    player.blockTimer = 0;

    player.parryTimer = 0;

    player.counterTimer = 0;

    starCooldown = 0;

    starProjectiles = [];

}


/* =====================================================
   START LEVEL
===================================================== */

function startLevel(level) {

    playGameSound("levelStart");

    currentLevel =
        clamp(
            level,
            1,
            MAX_LEVEL
        );


    selectedLevel =
        currentLevel;


    enemies = [];

    particles = [];

    floatingTexts = [];

    starProjectiles = [];


    enemyKills = 0;

    enemySpawnTimer = 0;


    player.x =
        W * .25;

    player.y = 0;

    player.vx = 0;

    player.vy = 0;

    player.hp =
        player.maxHp;


    resetPlayerCombat();


    currentScene =
        (currentLevel - 1) % 6;


    sceneTimer = 0;

    backgroundOffset = 0;


    gameRunning = true;

    gamePaused = false;

    currentScreen = "game";

    startBackgroundMusic();

    hideAllScreens();


    bossHud.style.display =
        "none";


    hideStar();


    updateHUD();

}


/* =====================================================
   PLAYER UPDATE
===================================================== */

function updatePlayer(dt) {

    let moving = false;


    if (keys.left) {

        player.vx =
            -player.speed;

        player.facing =
            -1;

        moving = true;

    }


    if (keys.right) {

        player.vx =
            player.speed;

        player.facing =
            1;

        moving = true;

    }


    if (
        !keys.left &&
        !keys.right
    ) {

        player.vx *= .75;

    }


    player.x +=
        player.vx;


    player.x =
        clamp(
            player.x,
            40,
            W - 40
        );


    if (
        moving &&
        Math.abs(player.y) < 1
    ) {

        player.walkTime +=
            dt * .22;

    }


    /* =================================================
       FIXED JUMP PHYSICS

       Positive Y = height above ground
       Ground = 0

       UP   = positive velocity
       DOWN = gravity decreases velocity
    ================================================= */

    player.y +=
        player.vy;

    player.vy -=
        player.gravity;


    if (
        player.y <= 0
    ) {

        player.y = 0;

        player.vy = 0;

    }


    if (
        player.punchTimer > 0
    ) {

        player.punchTimer -=
            dt;

    }


    if (
        player.swordTimer > 0
    ) {

        player.swordTimer -=
            dt;

    }


    if (
        player.hitTimer > 0
    ) {

        player.hitTimer -=
            dt;

    }


    if (
        player.invincibleTimer > 0
    ) {

        player.invincibleTimer -=
            dt;

    }


    if (
        player.attackCooldown > 0
    ) {

        player.attackCooldown -=
            dt;

    }


    if (
        player.blockTimer > 0
    ) {

        player.blockTimer -=
            dt;

    }


    if (
        player.parryTimer > 0
    ) {

        player.parryTimer -=
            dt;

    }


    if (
        player.counterTimer > 0
    ) {

        player.counterTimer -=
            dt;

    }

}


/* =====================================================
   JUMP
===================================================== */

function jump() {

    if (
        !gameRunning ||
        gamePaused
    ) {

        return;

    }


    if (
        Math.abs(player.y) < .5
    ) {

        /* FIXED: jump upward */

        playGameSound("jump");

        player.vy =
            player.jumpPower;

    }

}


/* =====================================================
   PUNCH
===================================================== */

function punch() {

    if (
        !gameRunning ||
        gamePaused
    ) {

        return;

    }


    if (
        player.attackCooldown > 0
    ) {

        return;

    }


    playGameSound("punch");

    player.punchTimer = 15;

    player.attackCooldown = 18;


    for (
        const enemy of enemies
    ) {

        if (
            enemy.dead ||
            enemy.boss
        ) {

            continue;

        }


        const distance =
            Math.abs(
                enemy.x -
                player.x
            );


        if (
            distance < 95
        ) {

            const damage =
                enemy.maxHp <= 25
                    ? 18
                    : 10;


            playGameSound("hit");

            enemy.hp -=
                damage;


            enemy.hitTimer =
                12;


            enemy.x +=
                player.facing *
                25;


            spawnHitParticles(
                enemy.x,
                groundY() -
                enemy.y -
                70,
                false
            );


            addFloatingText(
                enemy.x,
                groundY() -
                enemy.y -
                105,
                "-" + damage
            );


            shake = 3;


            if (
                enemy.hp <= 0
            ) {

                killEnemy(
                    enemy
                );

            }

        }

    }

}


/* =====================================================
   SWORD ATTACK
===================================================== */

function swordAttack() {

    if (
        !gameRunning ||
        gamePaused
    ) {

        return;

    }


    if (
        player.attackCooldown > 0
    ) {

        return;

    }


    playGameSound("sword");

    player.swordTimer = 20;

    player.attackCooldown = 24;

    player.blockTimer = 25;


    for (
        const enemy of enemies
    ) {

        if (
            enemy.dead
        ) {

            continue;

        }


        const distance =
            Math.abs(
                enemy.x -
                player.x
            );


        if (
            distance < 125
        ) {

            const damage =
                enemy.boss
                    ? 8
                    : 22;


            playGameSound("hit");

            enemy.hp -=
                damage;


            enemy.hitTimer =
                15;


            enemy.x +=
                player.facing *
                35;


            spawnHitParticles(
                enemy.x,
                groundY() -
                enemy.y -
                75,
                true
            );


            addFloatingText(
                enemy.x,
                groundY() -
                enemy.y -
                115,
                "-" + damage
            );


            shake = 5;


            if (
                enemy.hp <= 0
            ) {

                if (
                    enemy.boss
                ) {

                    defeatBoss(
                        enemy
                    );

                } else {

                    killEnemy(
                        enemy
                    );

                }

            }

        }

    }

}


/* =====================================================
   PARRY
===================================================== */

function performParry() {

    player.blockTimer =
        35;

    player.parryTimer =
        20;

    player.counterTimer =
        30;


    for (
        const enemy of enemies
    ) {

        if (
            enemy.dead
        ) {

            continue;

        }


        if (
            Math.abs(
                enemy.x -
                player.x
            ) < 130
        ) {

            if (
                enemy.attackTimer > 0
            ) {

                enemy.attackTimer =
                    0;

                enemy.stunned =
                    45;

                enemy.jumpAttack =
                    false;


                addFloatingText(
                    enemy.x,
                    groundY() -
                    enemy.y -
                    130,
                    "PARRY!"
                );


                spawnHitParticles(
                    enemy.x,
                    groundY() -
                    enemy.y -
                    85,
                    true
                );

            }

        }

    }

}


/* =====================================================
   SPAWN ENEMY
===================================================== */

function spawnEnemy() {

    if (
        enemyKills >=
        ENEMIES_PER_LEVEL
    ) {

        return;

    }


    const fromRight =
        Math.random() > .5;


    const strength =
        1 +
        Math.floor(
            currentLevel / 5
        );


    const hp =
        25 +
        currentLevel * 3 +
        strength * 4;


    const enemy = {

        x:
            fromRight
                ? W + 80
                : -80,

        y: 0,

        vx: 0,

        hp: hp,

        maxHp: hp,

        speed:
            1.1 +
            currentLevel * .035,

        damage:
            5 +
            Math.floor(
                currentLevel / 4
            ),

        facing:
            fromRight
                ? -1
                : 1,

        attackTimer: 0,

        attackCooldown:
            random(
                50,
                120
            ),

        hitTimer: 0,

        stunned: 0,

        dead: false,

        boss: false,

        color:
            Math.random() > .5
                ? "#b72828"
                : "#4c3ca8"

    };


    enemies.push(
        enemy
    );

}


/* =====================================================
   ENEMY UPDATE
===================================================== */

function updateEnemy(
    enemy,
    dt
) {

    if (
        enemy.dead
    ) {

        return;

    }


    if (
        enemy.hitTimer > 0
    ) {

        enemy.hitTimer -=
            dt;

    }


    if (
        enemy.stunned > 0
    ) {

        enemy.stunned -=
            dt;

        return;

    }


    const distance =
        player.x -
        enemy.x;


    enemy.facing =
        distance >= 0
            ? 1
            : -1;


    if (
        Math.abs(distance) > 70
    ) {

        enemy.x +=
            enemy.facing *
            enemy.speed;

    } else {

        enemy.attackCooldown -=
            dt;


        if (
            enemy.attackCooldown <= 0
        ) {

            enemyStrike(
                enemy
            );


            enemy.attackCooldown =
                random(
                    70,
                    125
                );

        }

    }

}


/* =====================================================
   ENEMY ATTACK
===================================================== */

function enemyStrike(
    enemy
) {

    enemy.attackTimer =
        22;


    if (
        Math.abs(
            enemy.x -
            player.x
        ) > 100
    ) {

        return;

    }


    if (
        player.blockTimer > 0
    ) {

        if (
            player.parryTimer > 0
        ) {

            performParry();

            return;

        }


        addFloatingText(
            player.x,
            groundY() - 125,
            "BLOCK"
        );

        return;

    }


    damagePlayer(
        enemy.damage
    );

}


/* =====================================================
   PLAYER DAMAGE
===================================================== */

function damagePlayer(
    amount
) {

    if (
        player.invincibleTimer > 0
    ) {

        return;

    }


    if (
        player.blockTimer > 0
    ) {

        amount =
            Math.ceil(
                amount * .25
            );

    }


    playGameSound("playerHit");

    player.hp -=
        amount;


    player.hp =
        Math.max(
            0,
            player.hp
        );


    player.hitTimer =
        15;

    player.invincibleTimer =
        35;


    shake = 7;


    addFloatingText(
        player.x,
        groundY() - 125,
        "-" + amount
    );


    if (
        player.hp <= 0
    ) {

        loseGame();

    }

}


/* =====================================================
   KILL ENEMY
===================================================== */

function killEnemy(
    enemy
) {

    if (
        enemy.dead
    ) {

        return;

    }


    enemy.dead = true;

    playGameSound("enemyDefeat");

    enemyKills++;


    score +=
        100 +
        currentLevel * 10;


    coins +=
        2 +
        Math.floor(
            currentLevel / 5
        );


    spawnHitParticles(
        enemy.x,
        groundY() -
        enemy.y -
        75,
        true
    );


    addFloatingText(
        enemy.x,
        groundY() -
        enemy.y -
        120,
        "+100"
    );


    checkBossSpawn();

}


/* =====================================================
   CHECK BOSS
===================================================== */

function checkBossSpawn() {

    if (
        enemyKills >=
        ENEMIES_PER_LEVEL
    ) {

        const bossExists =
            enemies.some(
                e =>
                    e.boss &&
                    !e.dead
            );


        if (!bossExists) {

            spawnBoss();

        }

    }

}


/* =====================================================
   SPAWN BOSS
===================================================== */

function spawnBoss() {

    const bossHp =
        240 +
        currentLevel * 45;


    const boss = {

        x:
            W + 180,

        y: 0,

        vx: 0,

        hp: bossHp,

        maxHp: bossHp,

        speed:
            1.25 +
            currentLevel * .03,

        damage:
            12 +
            currentLevel,

        facing: -1,

        attackTimer: 0,

        attackCooldown:
            80,

        hitTimer: 0,

        stunned: 0,

        dead: false,

        boss: true,

        name:
            "SHADOW WARLORD",


        /* ================= BOSS JUMP SYSTEM ================= */

        jumping: false,

        jumpVy: 0,

        jumpAttack: false,

        jumpAttackTimer: 0,

        jumpCooldown:
            170,

        landingTimer: 0,

        warningTimer: 0,

        comboTimer: 0,

        comboCount: 0

    };


    enemies.push(
        boss
    );


    bossHud.style.display =
        "block";


    bossName.textContent =
        boss.name +
        " • BOSS LV." +
        currentLevel;


    bossHpBar.style.width =
        "100%";


    const starBtn =
        document.getElementById(
            "starBtn"
        );


    if (starBtn) {

        starBtn.style.display =
            "flex";

    }


    addFloatingText(
        W * .5,
        H * .32,
        "⚠ SHADOW WARLORD HAS ARRIVED!"
    );

}


/* =====================================================
   BOSS UPDATE
===================================================== */

function updateBoss(
    boss,
    dt
) {

    if (
        boss.dead
    ) {

        return;

    }


    if (
        boss.hitTimer > 0
    ) {

        boss.hitTimer -=
            dt;

    }


    if (
        boss.stunned > 0
    ) {

        boss.stunned -=
            dt;

        return;

    }


    /*
       Warning timer
    */

    if (
        boss.warningTimer > 0
    ) {

        boss.warningTimer -=
            dt;

    }


    /*
       ============================
       BOSS IS JUMPING
       ============================
    */

    if (
        boss.jumping
    ) {

        /* FIXED: boss now moves upward */

        boss.y +=
            boss.jumpVy;

        boss.jumpVy -=
            .48;


        /*
           During jump attack
           boss moves toward player.
        */

        if (
            boss.jumpAttack
        ) {

            const direction =
                player.x -
                boss.x;


            boss.facing =
                direction >= 0
                    ? 1
                    : -1;


            /*
               Air movement is fast
               but controllable.
            */

            boss.x +=
                boss.facing *
                (
                    2.3 +
                    currentLevel * .025
                );


            boss.jumpAttackTimer -=
                dt;


            /*
               Sword attack while airborne
            */

            if (
                boss.jumpAttackTimer <= 0
            ) {

                bossAirStrike(
                    boss
                );

                boss.jumpAttack =
                    false;

            }

        }


        /*
           Landing
        */

        if (
            boss.y <= 0
        ) {

            boss.y = 0;

            boss.jumpVy = 0;

            boss.jumping = false;

            boss.jumpAttack = false;

            boss.landingTimer = 18;

            boss.jumpCooldown =
                random(
                    125,
                    200
                );


            spawnHitParticles(
                boss.x,
                groundY() - 8,
                true
            );


            shake = 5;


            addFloatingText(
                boss.x,
                groundY() - 205,
                "⚔ LANDING!"
            );

        }


        return;

    }


    /*
       Landing recovery
    */

    if (
        boss.landingTimer > 0
    ) {

        boss.landingTimer -=
            dt;

        return;

    }


    /*
       ============================
       JUMP COOLDOWN
       ============================
    */

    boss.jumpCooldown -=
        dt;


    const distance =
        player.x -
        boss.x;


    boss.facing =
        distance >= 0
            ? 1
            : -1;


    /*
       Boss decides whether
       to perform jump attack.
    */

    if (
        boss.jumpCooldown <= 0 &&
        Math.abs(distance) < 520 &&
        Math.abs(distance) > 120
    ) {

        startBossJump(
            boss
        );

        return;

    }


    /*
       ============================
       NORMAL BOSS MOVEMENT
       ============================
    */

    if (
        Math.abs(distance) > 145
    ) {

        boss.x +=
            boss.facing *
            boss.speed;

    } else {

        boss.attackCooldown -=
            dt;


        /*
           Normal sword combo
        */

        if (
            boss.attackCooldown <= 0
        ) {

            bossStrike(
                boss
            );


            boss.attackCooldown =
                random(
                    55,
                    90
                );

        }

    }


    /*
       Boss combo timer
    */

    if (
        boss.comboTimer > 0
    ) {

        boss.comboTimer -=
            dt;

    }

}


/* =====================================================
   START BOSS JUMP
===================================================== */

function startBossJump(
    boss
) {

    if (
        boss.jumping ||
        boss.dead
    ) {

        return;

    }


    boss.jumping = true;

    boss.jumpAttack = true;


    /* FIXED: positive velocity = UP */

    boss.jumpVy =
        13.5 +
        Math.min(
            currentLevel * .05,
            2.5
        );


    boss.jumpAttackTimer =
        random(
            18,
            28
        );


    boss.warningTimer =
        38;


    /*
       Face player before jump.
    */

    boss.facing =
        player.x >= boss.x
            ? 1
            : -1;


    addFloatingText(
        boss.x,
        groundY() - 235,
        "⚠ JUMP ATTACK!"
    );


    /*
       Red warning particles
    */

    for (
        let i = 0;
        i < 10;
        i++
    ) {

        particles.push({

            x:
                boss.x +
                random(
                    -30,
                    30
                ),

            y:
                groundY() -
                15,

            vx:
                random(
                    -2,
                    2
                ),

            vy:
                random(
                    -4,
                    -1
                ),

            life:
                28,

            maxLife:
                28,

            size:
                random(
                    3,
                    6
                )

        });

    }

}


/* =====================================================
   BOSS AIR SWORD ATTACK
===================================================== */

function bossAirStrike(
    boss
) {

    playGameSound("bossAttack");

    boss.attackTimer =
        28;


    const distance =
        Math.abs(
            boss.x -
            player.x
        );


    /*
       Player can escape by
       moving backward/sideways
       or jumping.
    */

    if (
        distance > 145
    ) {

        addFloatingText(
            boss.x,
            groundY() -
            boss.y -
            130,
            "MISS!"
        );

        return;

    }


    /*
       If player is airborne,
       jump attack can miss.
    */

    /* FIXED: positive Y means player is in air */

    if (
        player.y > 65
    ) {

        addFloatingText(
            player.x,
            groundY() -
            player.y -
            145,
            "DODGE!"
        );

        return;

    }


    /*
       Block / parry
    */

    if (
        player.blockTimer > 0
    ) {

        if (
            player.parryTimer > 0
        ) {

            boss.stunned =
                65;

            boss.attackTimer =
                0;


            addFloatingText(
                boss.x,
                groundY() -
                boss.y -
                180,
                "⚔ PERFECT PARRY!"
            );


            spawnHitParticles(
                boss.x,
                groundY() -
                boss.y -
                100,
                true
            );


            shake = 8;


            return;

        }


        /*
           Strong jump attack
           partially blocked.
        */

        damagePlayer(
            Math.ceil(
                boss.damage * .35
            )
        );


        addFloatingText(
            player.x,
            groundY() - 145,
            "BLOCK!"
        );


        return;

    }


    /*
       Full damage
    */

    damagePlayer(
        boss.damage +
        5
    );


    shake = 10;


    spawnHitParticles(
        player.x,
        groundY() -
        player.y -
        90,
        true
    );

}


/* =====================================================
   BOSS NORMAL ATTACK
===================================================== */

function bossStrike(
    boss
) {

    playGameSound("bossAttack");

    boss.attackTimer =
        30;


    const distance =
        Math.abs(
            boss.x -
            player.x
        );


    if (
        distance > 160
    ) {

        return;

    }


    /*
       Combo system
    */

    boss.comboCount++;


    if (
        boss.comboCount >= 3
    ) {

        boss.comboCount = 0;

        boss.comboTimer = 20;

    }


    /*
       Player parry
    */

    if (
        player.blockTimer > 0
    ) {

        if (
            player.parryTimer > 0
        ) {

            boss.attackTimer =
                0;

            boss.stunned =
                50;


            addFloatingText(
                boss.x,
                groundY() - 180,
                "⚔ PARRY!"
            );


            spawnHitParticles(
                boss.x,
                groundY() - 100,
                true
            );


            shake = 7;


            return;

        }


        damagePlayer(
            Math.ceil(
                boss.damage * .25
            )
        );


        addFloatingText(
            player.x,
            groundY() - 135,
            "BLOCK"
        );


        return;

    }


    /*
       Normal boss sword damage
    */

    damagePlayer(
        boss.damage
    );


    spawnHitParticles(
        player.x,
        groundY() -
        player.y -
        80,
        true
    );


    shake = 7;

}


/* =====================================================
   STAR ATTACK
   STAR NOW FLIES THROUGH AIR
===================================================== */

function starAttack() {

    if (
        !gameRunning ||
        gamePaused
    ) {

        return;

    }


    const boss =
        enemies.find(
            enemy =>
                enemy.boss &&
                !enemy.dead
        );


    if (!boss) {

        return;

    }


    if (
        starCooldown > 0
    ) {

        return;

    }


    /*
       Create projectile
    */

    const startX =
        player.x +
        player.facing * 35;


    const startY =
        groundY() -
        player.y -
        90;


    const targetX =
        boss.x;


    const targetY =
        groundY() -
        boss.y -
        120;


    const dx =
        targetX -
        startX;


    const dy =
        targetY -
        startY;


    const distance =
        Math.sqrt(
            dx * dx +
            dy * dy
        );


    const speed = 11;


    starProjectiles.push({

        x: startX,

        y: startY,

        vx:
            dx /
            distance *
            speed,

        vy:
            dy /
            distance *
            speed,

        rotation: 0,

        life: 100,

        target: boss

    });


    /*
       Short cooldown prevents
       unlimited instant spam.
    */

    starCooldown =
        30;


    addFloatingText(
        player.x,
        startY - 20,
        "⭐"
    );

}


/* =====================================================
   UPDATE STAR PROJECTILES
===================================================== */

function updateStarProjectiles(
    dt
) {

    for (
        const star of starProjectiles
    ) {

        if (
            !star.target ||
            star.target.dead
        ) {

            star.life = 0;

            continue;

        }


        /*
           Home toward boss
        */

        const targetX =
            star.target.x;


        const targetY =
            groundY() -
            star.target.y -
            120;


        const dx =
            targetX -
            star.x;


        const dy =
            targetY -
            star.y;


        const distance =
            Math.sqrt(
                dx * dx +
                dy * dy
            );


        /*
           Slight homing effect
           makes star feel magical.
        */

        if (
            distance > 1
        ) {

            const speed =
                11;


            star.vx +=
                (
                    dx /
                    distance *
                    speed -
                    star.vx
                ) * .08;


            star.vy +=
                (
                    dy /
                    distance *
                    speed -
                    star.vy
                ) * .08;

        }


        star.x +=
            star.vx;


        star.y +=
            star.vy;


        star.rotation +=
            .35 * dt;


        star.life -=
            dt;


        /*
           HIT BOSS
        */

        if (
            distance < 35
        ) {

            hitBossWithStar(
                star.target
            );


            star.life = 0;

        }

    }


    playGameSound("star");

    starProjectiles =
        starProjectiles.filter(
            star =>
                star.life > 0
        );

}


/* =====================================================
   STAR HITS BOSS
===================================================== */

function hitBossWithStar(
    boss
) {

    if (
        !boss ||
        boss.dead
    ) {

        return;

    }


    /*
       EXACTLY 3 DAMAGE
    */

    playGameSound("bossHit");

    boss.hp -=
        STAR_DAMAGE;


    boss.hp =
        Math.max(
            0,
            boss.hp
        );


    boss.hitTimer =
        14;


    bossHpBar.style.width =
        clamp(
            boss.hp /
            boss.maxHp *
            100,
            0,
            100
        ) + "%";


    /*
       Star explosion
    */

    for (
        let i = 0;
        i < 18;
        i++
    ) {

        particles.push({

            x:
                boss.x +
                random(
                    -10,
                    10
                ),

            y:
                groundY() -
                boss.y -
                120 +
                random(
                    -10,
                    10
                ),

            vx:
                random(
                    -5,
                    5
                ),

            vy:
                random(
                    -5,
                    1
                ),

            life:
                random(
                    18,
                    35
                ),

            maxLife:
                35,

            size:
                random(
                    2,
                    6
                )

        });

    }


    addFloatingText(
        boss.x,
        groundY() -
        boss.y -
        165,
        "⭐ -3"
    );


    shake = 4;


    /*
       Boss reacts to star
    */

    boss.x +=
        player.facing *
        12;


    if (
        boss.hp <= 0
    ) {

        defeatBoss(
            boss
        );

    }

}


/* =====================================================
   DEFEAT BOSS
===================================================== */

function defeatBoss(
    boss
) {

    if (
        boss.dead
    ) {

        return;

    }


    boss.dead = true;

    playGameSound("bossDefeat");

    boss.jumping = false;

    boss.jumpAttack = false;


    bossHud.style.display =
        "none";


    hideStar();


    starProjectiles = [];


    score +=
        1000 +
        currentLevel * 100;


    coins +=
        25 +
        currentLevel;


    spawnHitParticles(
        boss.x,
        groundY() - 110,
        true
    );


    addFloatingText(
        boss.x,
        groundY() - 190,
        "BOSS DEFEATED!"
    );


    setTimeout(
        () => {

            const nextLevel =
                currentLevel + 1;


            if (
                currentLevel >=
                MAX_LEVEL
            ) {

                victory();

                return;

            }


            let unlocked =
                parseInt(
                    localStorage.getItem(
                        "ninjaKingUnlocked"
                    )
                ) || 1;


            if (
                nextLevel >
                unlocked
            ) {

                localStorage.setItem(
                    "ninjaKingUnlocked",
                    nextLevel
                );

            }


            startLevel(
                nextLevel
            );

        },
        1400
    );

}


/* =====================================================
   GAME OVER
===================================================== */

function loseGame() {

    playGameSound("deathGrunt");
    playGameSound("gameOver");

    gameRunning = false;

    gamePaused = false;


    bossHud.style.display =
        "none";


    hideStar();


    starProjectiles = [];


    stopBackgroundMusic();

    currentScreen =
        "gameover";


    hideAllScreens();


    document
        .getElementById(
            "gameOver"
        )
        .classList.remove(
            "hidden"
        );


    document
        .getElementById(
            "gameOverText"
        )
        .textContent =
        "You were defeated on Level " +
        currentLevel +
        ".";

}


/* =====================================================
   VICTORY
===================================================== */

function victory() {

    playGameSound("victory");

    gameRunning = false;

    gamePaused = false;


    bossHud.style.display =
        "none";


    hideStar();


    starProjectiles = [];


    stopBackgroundMusic();

    currentScreen =
        "victory";


    hideAllScreens();


    document
        .getElementById(
            "victory"
        )
        .classList.remove(
            "hidden"
        );

}


/* =====================================================
   EXIT
===================================================== */

function exitGame() {

    gameRunning = false;

    gamePaused = false;


    bossHud.style.display =
        "none";


    hideStar();


    starProjectiles = [];


    stopBackgroundMusic();

    currentScreen =
        "exit";


    hideAllScreens();


    document
        .getElementById(
            "exitScreen"
        )
        .classList.remove(
            "hidden"
        );

}


/* =====================================================
   UPDATE
===================================================== */

function update(dt) {

    if (
        !gameRunning ||
        gamePaused
    ) {

        return;

    }


    updatePlayer(dt);


    /*
       Background
    */

    backgroundOffset +=
        backgroundSpeed * dt;


    sceneTimer +=
        dt / 60;


    if (
        sceneTimer >=
        SCENE_DURATION
    ) {

        sceneTimer = 0;

        currentScene =
            (
                currentScene + 1
            ) % 6;

    }


    /*
       Star cooldown
    */

    if (
        starCooldown > 0
    ) {

        starCooldown -=
            dt;


        if (
            starCooldown < 0
        ) {

            starCooldown = 0;

        }

    }


    /*
       Star projectiles
    */

    updateStarProjectiles(dt);


    /*
       Spawn normal enemies
    */

    if (
        enemyKills <
        ENEMIES_PER_LEVEL
    ) {

        enemySpawnTimer -=
            dt;


        if (
            enemySpawnTimer <= 0
        ) {

            spawnEnemy();

            enemySpawnTimer =
                enemySpawnDelay;

        }

    }


    /*
       Update enemies
    */

    for (
        const enemy of enemies
    ) {

        if (
            enemy.boss
        ) {

            updateBoss(
                enemy,
                dt
            );

        } else {

            updateEnemy(
                enemy,
                dt
            );

        }

    }


    enemies =
        enemies.filter(
            enemy =>
                !enemy.dead
        );


    updateParticles(dt);

    updateFloatingTexts(dt);


    if (
        shake > 0
    ) {

        shake -=
            dt;


        if (
            shake < 0
        ) {

            shake = 0;

        }

    }


    updateHUD();

}


/* =====================================================
   HUD
===================================================== */

function updateHUD() {

    playerHpBar.style.width =
        clamp(
            player.hp /
            player.maxHp *
            100,
            0,
            100
        ) + "%";


    playerHpText.textContent =
        Math.ceil(player.hp) +
        " / " +
        player.maxHp;


    levelText.textContent =
        "LEVEL " +
        currentLevel;


    enemyCount.textContent =
        "ENEMIES " +
        enemyKills +
        " / " +
        ENEMIES_PER_LEVEL;


    coinText.textContent =
        "🪙 " +
        coins;


    const boss =
        enemies.find(
            enemy =>
                enemy.boss &&
                !enemy.dead
        );


    if (boss) {

        bossHpBar.style.width =
            clamp(
                boss.hp /
                boss.maxHp *
                100,
                0,
                100
            ) + "%";

    }

}


/* =====================================================
   BACKGROUND
===================================================== */

function drawBackground() {

    if (
        currentScene === 0
    ) {

        drawNightCity();

    }

    else if (
        currentScene === 1
    ) {

        drawForest();

    }

    else if (
        currentScene === 2
    ) {

        drawMountains();

    }

    else if (
        currentScene === 3
    ) {

        drawNinjaVillage();

    }

    else if (
        currentScene === 4
    ) {

        drawRainCity();

    }

    else {

        drawDesert();

    }


    drawGround();


    if (
        currentScene === 0 ||
        currentScene === 2 ||
        currentScene === 4
    ) {

        drawMovingTrain();

    }


    if (
        currentScene === 4
    ) {

        drawRain();

    }

}


/* =====================================================
   NIGHT CITY
===================================================== */

function drawNightCity() {

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    gradient.addColorStop(
        0,
        "#040817"
    );

    gradient.addColorStop(
        .55,
        "#111d35"
    );

    gradient.addColorStop(
        1,
        "#172333"
    );


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    ctx.beginPath();

    ctx.arc(
        W * .78,
        H * .18,
        Math.min(W,H) * .065,
        0,
        Math.PI * 2
    );


    ctx.fillStyle =
        "rgba(235,242,255,.9)";


    ctx.shadowBlur =
        30;

    ctx.shadowColor =
        "rgba(180,210,255,.5)";


    ctx.fill();

    ctx.shadowBlur = 0;


    const spacing = 110;

    const shift =
        backgroundOffset *
        .22 %
        spacing;


    for (
        let i = -2;
        i < W / spacing + 3;
        i++
    ) {

        const x =
            i * spacing -
            shift;


        const height =
            90 +
            (
                Math.abs(
                    Math.sin(i * 4.7)
                ) * 150
            );


        ctx.fillStyle =
            i % 2 === 0
                ? "#0b1320"
                : "#101b29";


        ctx.fillRect(
            x,
            groundY() -
            height -
            45,
            85,
            height + 45
        );


        for (
            let wy =
                groundY() -
                height;

            wy <
                groundY() -
                55;

            wy += 25
        ) {

            ctx.fillStyle =
                "rgba(255,205,80,.35)";


            ctx.fillRect(
                x + 15,
                wy,
                8,
                5
            );


            ctx.fillRect(
                x + 43,
                wy + 5,
                8,
                5
            );

        }

    }

}


/* =====================================================
   FOREST
===================================================== */

function drawForest() {

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    gradient.addColorStop(
        0,
        "#07141b"
    );

    gradient.addColorStop(
        .55,
        "#102d29"
    );

    gradient.addColorStop(
        1,
        "#12231c"
    );


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    const spacing = 90;

    const shift =
        backgroundOffset *
        .35 %
        spacing;


    for (
        let i = -3;
        i < W / spacing + 4;
        i++
    ) {

        const x =
            i * spacing -
            shift;


        drawTree(
            x,
            groundY() - 45,
            1
        );

    }


    const nearSpacing = 150;

    const nearShift =
        backgroundOffset *
        .75 %
        nearSpacing;


    for (
        let i = -2;
        i < W / nearSpacing + 3;
        i++
    ) {

        const x =
            i * nearSpacing -
            nearShift;


        drawTree(
            x,
            groundY() - 25,
            1.35
        );

    }

}


/* =====================================================
   TREE
===================================================== */

function drawTree(
    x,
    y,
    scale
) {

    ctx.save();

    ctx.translate(
        x,
        y
    );

    ctx.scale(
        scale,
        scale
    );


    ctx.fillStyle =
        "#332217";


    ctx.fillRect(
        -8,
        -75,
        16,
        75
    );


    ctx.fillStyle =
        "#0a211b";


    ctx.beginPath();

    ctx.arc(
        0,
        -95,
        42,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        -28,
        -70,
        30,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        28,
        -70,
        30,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.restore();

}


/* =====================================================
   MOUNTAINS
===================================================== */

function drawMountains() {

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    gradient.addColorStop(
        0,
        "#091321"
    );

    gradient.addColorStop(
        .5,
        "#1a3042"
    );

    gradient.addColorStop(
        1,
        "#111b23"
    );


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    ctx.beginPath();

    ctx.arc(
        W * .75,
        H * .18,
        38,
        0,
        Math.PI * 2
    );

    ctx.fillStyle =
        "#dbe7f3";

    ctx.fill();


    drawMountainLayer(
        .18,
        "#172a3b"
    );


    drawMountainLayer(
        .38,
        "#0d1b28"
    );

}


/* =====================================================
   MOUNTAIN LAYER
===================================================== */

function drawMountainLayer(
    speed,
    color
) {

    const width = 360;

    const shift =
        backgroundOffset *
        speed %
        width;


    ctx.fillStyle =
        color;


    ctx.beginPath();

    ctx.moveTo(
        -width,
        groundY()
    );


    for (
        let x = -width;
        x < W + width;
        x += width
    ) {

        const actualX =
            x - shift;


        ctx.lineTo(
            actualX,
            groundY() - 220
        );


        ctx.lineTo(
            actualX + 130,
            groundY() - 80
        );


        ctx.lineTo(
            actualX + 240,
            groundY() - 270
        );


        ctx.lineTo(
            actualX + width,
            groundY()
        );

    }


    ctx.lineTo(
        W,
        groundY()
    );


    ctx.closePath();

    ctx.fill();

}


/* =====================================================
   NINJA VILLAGE
===================================================== */

function drawNinjaVillage() {

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    gradient.addColorStop(
        0,
        "#070811"
    );

    gradient.addColorStop(
        .6,
        "#1d1824"
    );

    gradient.addColorStop(
        1,
        "#241a19"
    );


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    ctx.beginPath();

    ctx.arc(
        W * .78,
        H * .2,
        42,
        0,
        Math.PI * 2
    );

    ctx.fillStyle =
        "#eee4c8";

    ctx.fill();


    const spacing = 180;

    const shift =
        backgroundOffset *
        .45 %
        spacing;


    for (
        let i = -2;
        i < W / spacing + 3;
        i++
    ) {

        const x =
            i * spacing -
            shift;


        drawVillageHouse(
            x,
            groundY()
        );

    }

}


/* =====================================================
   VILLAGE HOUSE
===================================================== */

function drawVillageHouse(
    x,
    y
) {

    ctx.fillStyle =
        "#20161a";


    ctx.fillRect(
        x,
        y - 125,
        135,
        125
    );


    ctx.fillStyle =
        "#080b12";


    ctx.beginPath();

    ctx.moveTo(
        x - 20,
        y - 125
    );

    ctx.lineTo(
        x + 68,
        y - 185
    );

    ctx.lineTo(
        x + 155,
        y - 125
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#080a0e";


    ctx.fillRect(
        x + 52,
        y - 75,
        32,
        75
    );


    ctx.fillStyle =
        "#ff9d2e";


    ctx.shadowBlur =
        12;

    ctx.shadowColor =
        "#ff8a20";


    ctx.fillRect(
        x + 105,
        y - 95,
        10,
        18
    );


    ctx.shadowBlur = 0;

}


/* =====================================================
   RAIN CITY
===================================================== */

function drawRainCity() {

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    gradient.addColorStop(
        0,
        "#030711"
    );

    gradient.addColorStop(
        .55,
        "#14202d"
    );

    gradient.addColorStop(
        1,
        "#11171e"
    );


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    const spacing = 125;

    const shift =
        backgroundOffset *
        .25 %
        spacing;


    for (
        let i = -2;
        i < W / spacing + 3;
        i++
    ) {

        const x =
            i * spacing -
            shift;


        const height =
            130 +
            Math.abs(
                Math.sin(i * 3)
            ) * 130;


        ctx.fillStyle =
            "#0a1119";


        ctx.fillRect(
            x,
            groundY() -
            height -
            30,
            95,
            height + 30
        );


        for (
            let y =
                groundY() -
                height +
                20;

            y <
                groundY() -
                45;

            y += 30
        ) {

            ctx.fillStyle =
                "rgba(50,170,255,.35)";


            ctx.fillRect(
                x + 15,
                y,
                10,
                5
            );


            ctx.fillStyle =
                "rgba(255,80,80,.3)";


            ctx.fillRect(
                x + 50,
                y + 10,
                10,
                5
            );

        }

    }

}


/* =====================================================
   DESERT
===================================================== */

function drawDesert() {

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    gradient.addColorStop(
        0,
        "#24131a"
    );

    gradient.addColorStop(
        .55,
        "#7b4730"
    );

    gradient.addColorStop(
        1,
        "#b06b3e"
    );


    ctx.fillStyle =
        gradient;


    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    ctx.beginPath();

    ctx.arc(
        W * .75,
        H * .2,
        45,
        0,
        Math.PI * 2
    );

    ctx.fillStyle =
        "#ffd37a";

    ctx.fill();


    const shift =
        backgroundOffset *
        .25 %
        450;


    ctx.fillStyle =
        "#8c5136";


    ctx.beginPath();

    ctx.moveTo(
        -500 - shift,
        groundY()
    );


    for (
        let x = -500 - shift;
        x < W + 700;
        x += 220
    ) {

        ctx.quadraticCurveTo(
            x + 110,
            groundY() - 80,
            x + 220,
            groundY()
        );

    }


    ctx.lineTo(
        W,
        H
    );

    ctx.lineTo(
        0,
        H
    );

    ctx.closePath();

    ctx.fill();

}


/* =====================================================
   MOVING TRAIN
===================================================== */

function drawMovingTrain() {

    const trainWidth = 230;

    const trainY =
        groundY() - 145;


    const travel =
        (
            backgroundOffset * 2.2
        ) %
        (
            W +
            trainWidth * 2
        );


    const trainX =
        W +
        trainWidth -
        travel;


    for (
        let i = 0;
        i < 4;
        i++
    ) {

        const x =
            trainX +
            i *
            (
                trainWidth +
                8
            );


        drawTrainCar(
            x,
            trainY
        );

    }

}


/* =====================================================
   TRAIN CAR
===================================================== */

function drawTrainCar(
    x,
    y
) {

    ctx.fillStyle =
        "#18212b";


    ctx.fillRect(
        x,
        y,
        215,
        88
    );


    ctx.fillStyle =
        "#a32e34";


    ctx.fillRect(
        x,
        y + 8,
        215,
        9
    );


    for (
        let i = 0;
        i < 5;
        i++
    ) {

        const wx =
            x +
            18 +
            i * 39;


        ctx.fillStyle =
            "rgba(255,220,105,.75)";


        ctx.fillRect(
            wx,
            y + 27,
            25,
            28
        );


        ctx.fillStyle =
            "rgba(255,255,255,.22)";


        ctx.fillRect(
            wx + 3,
            y + 30,
            7,
            20
        );

    }


    ctx.fillStyle =
        "#0c1219";


    ctx.fillRect(
        x,
        y + 60,
        215,
        28
    );


    ctx.fillStyle =
        "#080a0d";


    ctx.beginPath();

    ctx.arc(
        x + 42,
        y + 91,
        15,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        x + 173,
        y + 91,
        15,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle =
        "#6d747a";


    ctx.beginPath();

    ctx.arc(
        x + 42,
        y + 91,
        5,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.arc(
        x + 173,
        y + 91,
        5,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* =====================================================
   GROUND
===================================================== */

function drawGround() {

    const gy =
        groundY();


    ctx.fillStyle =
        "#111820";


    ctx.fillRect(
        0,
        gy,
        W,
        H - gy
    );


    ctx.fillStyle =
        "#242c32";


    ctx.fillRect(
        0,
        gy + 15,
        W,
        6
    );


    ctx.fillRect(
        0,
        gy + 43,
        W,
        6
    );


    const sleeperSpacing = 55;


    const shift =
        backgroundOffset *
        1.8 %
        sleeperSpacing;


    ctx.fillStyle =
        "#493a2c";


    for (
        let x = -100;
        x < W + 100;
        x += sleeperSpacing
    ) {

        ctx.fillRect(
            x - shift,
            gy + 5,
            18,
            52
        );

    }


    ctx.fillStyle =
        "#263442";


    ctx.fillRect(
        0,
        gy,
        W,
        4
    );


    ctx.strokeStyle =
        "rgba(255,255,255,.035)";


    ctx.lineWidth = 1;


    const lineShift =
        backgroundOffset %
        55;


    for (
        let x = -60;
        x < W + 60;
        x += 55
    ) {

        ctx.beginPath();

        ctx.moveTo(
            x - lineShift,
            gy + 60
        );

        ctx.lineTo(
            x + 35 - lineShift,
            H
        );

        ctx.stroke();

    }

}


/* =====================================================
   RAIN
===================================================== */

function drawRain() {

    ctx.strokeStyle =
        "rgba(150,200,255,.28)";

    ctx.lineWidth = 1;


    for (
        let i = 0;
        i < 110;
        i++
    ) {

        const x =
            (
                i * 97 +
                backgroundOffset * 3
            ) % W;


        const y =
            (
                i * 53 +
                backgroundOffset * 2.5
            ) % H;


        ctx.beginPath();

        ctx.moveTo(
            x,
            y
        );

        ctx.lineTo(
            x - 5,
            y + 16
        );

        ctx.stroke();

    }

}


/* =====================================================
   PLAYER DRAW
===================================================== */

function drawPlayer() {

    const x =
        player.x;

    const y =
        groundY() -
        player.y;


    ctx.save();


    ctx.translate(
        x,
        y
    );


    ctx.scale(
        player.facing,
        1
    );


    if (
        player.invincibleTimer > 0 &&
        Math.floor(
            player.invincibleTimer / 4
        ) % 2 === 0
    ) {

        ctx.globalAlpha =
            .45;

    }


    ctx.fillStyle =
        "rgba(0,0,0,.42)";


    ctx.beginPath();

    ctx.ellipse(
        0,
        3,
        35,
        7,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();


    let walk = 0;


    if (
        Math.abs(player.vx) > .3 &&
        Math.abs(player.y) < 1
    ) {

        walk =
            Math.sin(
                player.walkTime
            );

    }


    const frontLeg =
        walk * 18;

    const backLeg =
        -walk * 18;


    ctx.strokeStyle =
        "#10151d";

    ctx.lineWidth = 9;

    ctx.lineCap =
        "round";


    ctx.beginPath();

    ctx.moveTo(
        -7,
        -43
    );

    ctx.lineTo(
        -13 + backLeg,
        -8
    );

    ctx.lineTo(
        -20 + backLeg,
        -2
    );

    ctx.stroke();


    ctx.beginPath();

    ctx.moveTo(
        8,
        -43
    );

    ctx.lineTo(
        13 + frontLeg,
        -8
    );

    ctx.lineTo(
        22 + frontLeg,
        -2
    );

    ctx.stroke();


    ctx.lineWidth = 8;


    ctx.beginPath();

    ctx.moveTo(
        -20 + backLeg,
        -2
    );

    ctx.lineTo(
        -5 + backLeg,
        -2
    );

    ctx.stroke();


    ctx.beginPath();

    ctx.moveTo(
        22 + frontLeg,
        -2
    );

    ctx.lineTo(
        37 + frontLeg,
        -2
    );

    ctx.stroke();


    ctx.fillStyle =
        "#101722";


    ctx.beginPath();

    ctx.roundRect(
        -17,
        -100,
        34,
        58,
        8
    );

    ctx.fill();


    ctx.strokeStyle =
        "#3d5268";

    ctx.lineWidth = 2.5;

    ctx.stroke();


    ctx.fillStyle =
        "#a87b25";


    ctx.fillRect(
        -18,
        -58,
        36,
        5
    );


    const armSwing =
        walk * 10;


    ctx.strokeStyle =
        "#111720";

    ctx.lineWidth = 9;


    ctx.beginPath();

    ctx.moveTo(
        -13,
        -82
    );

    ctx.lineTo(
        -27 - armSwing,
        -55
    );

    ctx.stroke();


    ctx.fillStyle =
        "#b57d5e";


    ctx.beginPath();

    ctx.arc(
        2,
        -119,
        21,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.moveTo(
        18,
        -123
    );

    ctx.lineTo(
        29,
        -118
    );

    ctx.lineTo(
        18,
        -114
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#080b10";


    ctx.beginPath();

    ctx.moveTo(
        -17,
        -128
    );

    ctx.lineTo(
        -8,
        -145
    );

    ctx.lineTo(
        8,
        -138
    );

    ctx.lineTo(
        22,
        -133
    );

    ctx.lineTo(
        12,
        -128
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#080d14";


    ctx.beginPath();

    ctx.roundRect(
        -8,
        -126,
        28,
        16,
        5
    );

    ctx.fill();


    ctx.fillStyle =
        "#f4f4f4";


    ctx.fillRect(
        10,
        -121,
        8,
        3
    );


    ctx.strokeStyle =
        "#b82d35";

    ctx.lineWidth = 4;


    ctx.beginPath();

    ctx.moveTo(
        -13,
        -136
    );

    ctx.lineTo(
        22,
        -132
    );

    ctx.stroke();


    if (
        player.punchTimer > 0
    ) {

        ctx.strokeStyle =
            "#111720";

        ctx.lineWidth = 10;


        ctx.beginPath();

        ctx.moveTo(
            13,
            -83
        );

        ctx.lineTo(
            48,
            -84
        );

        ctx.stroke();


        ctx.fillStyle =
            "#b57d5e";


        ctx.beginPath();

        ctx.arc(
            52,
            -84,
            7,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

    else if (
        player.swordTimer > 0
    ) {

        ctx.strokeStyle =
            "#111720";

        ctx.lineWidth = 10;


        ctx.beginPath();

        ctx.moveTo(
            12,
            -82
        );

        ctx.lineTo(
            37,
            -67
        );

        ctx.stroke();


        drawSword(
            38,
            -68
        );

    }

    else {

        ctx.strokeStyle =
            "#111720";

        ctx.lineWidth = 9;


        ctx.beginPath();

        ctx.moveTo(
            13,
            -82
        );

        ctx.lineTo(
            27 + armSwing,
            -54
        );

        ctx.stroke();

    }


    if (
        player.blockTimer > 0 &&
        player.swordTimer <= 0
    ) {

        drawSword(
            34,
            -76
        );

    }


    ctx.restore();

}


/* =====================================================
   SWORD
===================================================== */

function drawSword(
    x,
    y
) {

    ctx.save();


    ctx.translate(
        x,
        y
    );


    ctx.rotate(
        -.7
    );


    ctx.fillStyle =
        "#dce8f5";


    ctx.beginPath();

    ctx.moveTo(
        0,
        -65
    );

    ctx.lineTo(
        7,
        -10
    );

    ctx.lineTo(
        0,
        4
    );

    ctx.lineTo(
        -7,
        -10
    );

    ctx.closePath();

    ctx.fill();


    ctx.strokeStyle =
        "#8ea4bb";

    ctx.lineWidth = 2;

    ctx.stroke();


    ctx.fillStyle =
        "#c28b2d";


    ctx.fillRect(
        -16,
        3,
        32,
        5
    );


    ctx.fillStyle =
        "#3b2514";


    ctx.fillRect(
        -3,
        8,
        6,
        22
    );


    ctx.restore();

}


/* =====================================================
   ENEMY DRAW
===================================================== */

function drawEnemy(
    enemy
) {

    const x =
        enemy.x;

    const y =
        groundY() -
        enemy.y;


    ctx.save();


    ctx.translate(
        x,
        y
    );


    ctx.scale(
        enemy.facing,
        1
    );


    if (
        enemy.hitTimer > 0
    ) {

        ctx.globalAlpha =
            .65;

    }


    if (
        enemy.boss
    ) {

        drawBossCharacter(
            enemy
        );

    } else {

        drawNormalEnemy(
            enemy
        );

    }


    ctx.restore();

}


/* =====================================================
   NORMAL ENEMY DRAW
===================================================== */

function drawNormalEnemy(
    enemy
) {

    const walk =
        Math.sin(
            performance.now() * .012
        );


    const frontLeg =
        walk * 15;

    const backLeg =
        -walk * 15;


    ctx.fillStyle =
        "rgba(0,0,0,.42)";


    ctx.beginPath();

    ctx.ellipse(
        0,
        3,
        34,
        7,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.strokeStyle =
        "#12161d";

    ctx.lineWidth = 9;

    ctx.lineCap =
        "round";


    ctx.beginPath();

    ctx.moveTo(
        -7,
        -43
    );

    ctx.lineTo(
        -13 + backLeg,
        -8
    );

    ctx.lineTo(
        -21 + backLeg,
        -2
    );

    ctx.stroke();


    ctx.beginPath();

    ctx.moveTo(
        7,
        -43
    );

    ctx.lineTo(
        13 + frontLeg,
        -8
    );

    ctx.lineTo(
        22 + frontLeg,
        -2
    );

    ctx.stroke();


    ctx.lineWidth = 8;


    ctx.beginPath();

    ctx.moveTo(
        -21 + backLeg,
        -2
    );

    ctx.lineTo(
        -5 + backLeg,
        -2
    );

    ctx.stroke();


    ctx.beginPath();

    ctx.moveTo(
        22 + frontLeg,
        -2
    );

    ctx.lineTo(
        37 + frontLeg,
        -2
    );

    ctx.stroke();


    ctx.fillStyle =
        enemy.color;


    ctx.beginPath();

    ctx.roundRect(
        -18,
        -92,
        36,
        50,
        8
    );

    ctx.fill();


    ctx.strokeStyle =
        "rgba(255,255,255,.15)";

    ctx.lineWidth = 2;

    ctx.stroke();


    ctx.fillStyle =
        "#9b7227";


    ctx.fillRect(
        -19,
        -58,
        38,
        5
    );


    const arm =
        walk * 8;


    ctx.strokeStyle =
        "#12161d";

    ctx.lineWidth = 9;


    ctx.beginPath();

    ctx.moveTo(
        -14,
        -74
    );

    ctx.lineTo(
        -28 - arm,
        -50
    );

    ctx.stroke();


    ctx.fillStyle =
        "#986852";


    ctx.beginPath();

    ctx.arc(
        2,
        -108,
        20,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.beginPath();

    ctx.moveTo(
        17,
        -112
    );

    ctx.lineTo(
        28,
        -107
    );

    ctx.lineTo(
        17,
        -103
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#090b10";


    ctx.beginPath();

    ctx.moveTo(
        -17,
        -117
    );

    ctx.lineTo(
        -10,
        -134
    );

    ctx.lineTo(
        7,
        -128
    );

    ctx.lineTo(
        22,
        -124
    );

    ctx.lineTo(
        12,
        -117
    );

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "#0b0d12";


    ctx.beginPath();

    ctx.roundRect(
        -8,
        -115,
        29,
        15,
        4
    );

    ctx.fill();


    ctx.fillStyle =
        "#ff4a4a";


    ctx.fillRect(
        10,
        -110,
        8,
        3
    );


    ctx.strokeStyle =
        "#12161d";

    ctx.lineWidth = 10;


    ctx.beginPath();

    ctx.moveTo(
        13,
        -74
    );

    ctx.lineTo(
        35,
        -52
    );

    ctx.stroke();


    ctx.strokeStyle =
        "#d6e0e8";

    ctx.lineWidth = 5;


    ctx.beginPath();

    ctx.moveTo(
        34,
        -50
    );

    ctx.lineTo(
        68,
        -92
    );

    ctx.stroke();


    ctx.fillStyle =
        "#260808";


    ctx.fillRect(
        -25,
        -143,
        50,
        6
    );


    ctx.fillStyle =
        "#ff3030";


    ctx.fillRect(
        -25,
        -143,
        50 *
        clamp(
            enemy.hp /
            enemy.maxHp,
            0,
            1
        ),
        6
    );

}


/* =====================================================
   BOSS DRAW
===================================================== */

function drawBossCharacter(
    boss
) {

    /*
       Shadow
    */

    ctx.fillStyle =
        "rgba(0,0,0,.55)";


    ctx.beginPath();

    ctx.ellipse(
        0,
        5,
        62,
        12,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();


    /*
       Jump animation
    */

    const bossWalk =
        boss.jumping
            ? 0
            : Math.sin(
                performance.now() *
                .009
            ) * 12;


    /*
       Warning glow
    */

    if (
        boss.warningTimer > 0
    ) {

        ctx.strokeStyle =
            "rgba(255,40,40,.8)";

        ctx.lineWidth = 5;

        ctx.beginPath();

        ctx.arc(
            0,
            -115,
            105 +
            Math.sin(
                performance.now() *
                .02
            ) * 8,
            0,
            Math.PI * 2
        );

        ctx.stroke();

    }


    /*
       Back leg
    */

    ctx.strokeStyle =
        "#080a0e";

    ctx.lineWidth = 17;

    ctx.lineCap =
        "round";


    ctx.beginPath();

    ctx.moveTo(
        -17,
        -72
    );

    ctx.lineTo(
        -23 - bossWalk,
        -8
    );

    ctx.stroke();


    /*
       Front leg
    */

    ctx.beginPath();

    ctx.moveTo(
        17,
        -72
    );

    ctx.lineTo(
        24 + bossWalk,
        -8
    );

    ctx.stroke();


    /*
       Feet
    */

    ctx.lineWidth = 10;


    ctx.beginPath();

    ctx.moveTo(
        -23 - bossWalk,
        -8
    );

    ctx.lineTo(
        -5 - bossWalk,
        -5
    );

    ctx.stroke();


    ctx.beginPath();

    ctx.moveTo(
        24 + bossWalk,
        -8
    );

    ctx.lineTo(
        43 + bossWalk,
        -5
    );

    ctx.stroke();


    /*
       Huge body
    */

    ctx.fillStyle =
        "#151821";


    ctx.beginPath();

    ctx.roundRect(
        -42,
        -150,
        84,
        86,
        15
    );

    ctx.fill();


    ctx.strokeStyle =
        "#672a34";

    ctx.lineWidth = 5;

    ctx.stroke();


    /*
       Back arm
    */

    ctx.strokeStyle =
        "#10131a";

    ctx.lineWidth = 23;


    ctx.beginPath();

    ctx.moveTo(
        -31,
        -128
    );

    ctx.lineTo(
        -65,
        -78
    );

    ctx.stroke();


    /*
       Head
    */

    ctx.fillStyle =
        "#754b3e";


    ctx.beginPath();

    ctx.arc(
        3,
        -173,
        36,
        0,
        Math.PI * 2
    );

    ctx.fill();


    /*
       Nose
    */

    ctx.beginPath();

    ctx.moveTo(
        31,
        -180
    );

    ctx.lineTo(
        49,
        -172
    );

    ctx.lineTo(
        31,
        -165
    );

    ctx.closePath();

    ctx.fill();


    /*
       Hair
    */

    ctx.fillStyle =
        "#05070a";


    ctx.beginPath();

    ctx.moveTo(
        -33,
        -190
    );

    ctx.lineTo(
        -52,
        -216
    );

    ctx.lineTo(
        -21,
        -204
    );

    ctx.lineTo(
        2,
        -224
    );

    ctx.lineTo(
        26,
        -204
    );

    ctx.lineTo(
        50,
        -216
    );

    ctx.lineTo(
        36,
        -185
    );

    ctx.closePath();

    ctx.fill();


    /*
       Mask
    */

    ctx.fillStyle =
        "#07090d";


    ctx.beginPath();

    ctx.roundRect(
        -8,
        -184,
        43,
        23,
        5
    );

    ctx.fill();


    /*
       Eye
    */

    ctx.fillStyle =
        "#ff2020";

    ctx.shadowBlur =
        12;

    ctx.shadowColor =
        "#ff2020";


    ctx.fillRect(
        20,
        -176,
        12,
        5
    );


    ctx.shadowBlur = 0;


    /*
       Front arm
    */

    ctx.strokeStyle =
        "#10131a";

    ctx.lineWidth = 24;


    ctx.beginPath();

    ctx.moveTo(
        32,
        -128
    );

    if (
        boss.jumping &&
        boss.jumpAttack
    ) {

        ctx.lineTo(
            72,
            -150
        );

    } else {

        ctx.lineTo(
            68,
            -80
        );

    }

    ctx.stroke();


    /*
       Huge sword
    */

    ctx.strokeStyle =
        "#dce7ef";

    ctx.lineWidth = 11;


    ctx.beginPath();

    if (
        boss.jumping &&
        boss.jumpAttack
    ) {

        ctx.moveTo(
            70,
            -148
        );

        ctx.lineTo(
            150,
            -100
        );

    } else {

        ctx.moveTo(
            65,
            -77
        );

        ctx.lineTo(
            135,
            -210
        );

    }

    ctx.stroke();


    ctx.strokeStyle =
        "#8293a3";

    ctx.lineWidth = 3;


    ctx.beginPath();

    if (
        boss.jumping &&
        boss.jumpAttack
    ) {

        ctx.moveTo(
            70,
            -148
        );

        ctx.lineTo(
            150,
            -100
        );

    } else {

        ctx.moveTo(
            68,
            -80
        );

        ctx.lineTo(
            135,
            -210
        );

    }

    ctx.stroke();


    /*
       Handle
    */

    ctx.strokeStyle =
        "#c09237";

    ctx.lineWidth = 9;


    ctx.beginPath();

    ctx.moveTo(
        50,
        -68
    );

    ctx.lineTo(
        88,
        -91
    );

    ctx.stroke();


    /*
       Boss attack warning
    */

    if (
        boss.warningTimer > 0
    ) {

        ctx.fillStyle =
            "#ff3030";

        ctx.font =
            "bold 22px Arial";

        ctx.textAlign =
            "center";

        ctx.fillText(
            "⚠",
            0,
            -235
        );

    }

}


/* =====================================================
   STAR PROJECTILE DRAW
===================================================== */

function drawStarProjectiles() {

    for (
        const star of starProjectiles
    ) {

        ctx.save();


        ctx.translate(
            star.x,
            star.y
        );


        ctx.rotate(
            star.rotation
        );


        /*
           Glow
        */

        ctx.shadowBlur =
            22;

        ctx.shadowColor =
            "#ffd43b";


        ctx.fillStyle =
            "#ffd43b";


        /*
           Five-point star
        */

        ctx.beginPath();


        for (
            let i = 0;
            i < 10;
            i++
        ) {

            const angle =
                -Math.PI / 2 +
                i *
                Math.PI / 5;


            const radius =
                i % 2 === 0
                    ? 18
                    : 8;


            const x =
                Math.cos(angle) *
                radius;


            const y =
                Math.sin(angle) *
                radius;


            if (
                i === 0
            ) {

                ctx.moveTo(
                    x,
                    y
                );

            } else {

                ctx.lineTo(
                    x,
                    y
                );

            }

        }


        ctx.closePath();

        ctx.fill();


        ctx.shadowBlur = 0;


        ctx.restore();

    }

}


/* =====================================================
   PARTICLES
===================================================== */

function spawnHitParticles(
    x,
    y,
    sword
) {

    const amount =
        sword
            ? 14
            : 8;


    for (
        let i = 0;
        i < amount;
        i++
    ) {

        particles.push({

            x: x,

            y: y,

            vx:
                random(
                    -4,
                    4
                ),

            vy:
                random(
                    -5,
                    -1
                ),

            life:
                random(
                    15,
                    30
                ),

            maxLife:
                30,

            size:
                random(
                    2,
                    sword ? 5 : 4
                )

        });

    }

}


function updateParticles(
    dt
) {

    for (
        const p of particles
    ) {

        p.x +=
            p.vx;

        p.y +=
            p.vy;

        p.vy +=
            .18;

        p.life -=
            dt;

    }


    particles =
        particles.filter(
            p =>
                p.life > 0
        );

}


function drawParticles() {

    for (
        const p of particles
    ) {

        ctx.globalAlpha =
            clamp(
                p.life /
                p.maxLife,
                0,
                1
            );


        ctx.fillStyle =
            "#ffd45c";


        ctx.beginPath();

        ctx.arc(
            p.x,
            p.y,
            p.size,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }


    ctx.globalAlpha = 1;

}


/* =====================================================
   FLOATING TEXT
===================================================== */

function addFloatingText(
    x,
    y,
    text
) {

    floatingTexts.push({

        x: x,

        y: y,

        text: text,

        life: 55,

        maxLife: 55

    });

}


function updateFloatingTexts(
    dt
) {

    for (
        const f of floatingTexts
    ) {

        f.y -=
            .7 * dt;

        f.life -=
            dt;

    }


    floatingTexts =
        floatingTexts.filter(
            f =>
                f.life > 0
        );

}


function drawFloatingTexts() {

    ctx.textAlign =
        "center";

    ctx.font =
        "bold 17px Arial";


    for (
        const f of floatingTexts
    ) {

        ctx.globalAlpha =
            clamp(
                f.life /
                f.maxLife,
                0,
                1
            );


        ctx.fillStyle =
            "#fff";


        ctx.strokeStyle =
            "#000";

        ctx.lineWidth = 4;


        ctx.strokeText(
            f.text,
            f.x,
            f.y
        );


        ctx.fillText(
            f.text,
            f.x,
            f.y
        );

    }


    ctx.globalAlpha = 1;

}


/* =====================================================
   DRAW
===================================================== */

function draw() {

    ctx.save();


    if (
        shake > 0
    ) {

        ctx.translate(
            random(
                -shake,
                shake
            ),
            random(
                -shake,
                shake
            )
        );

    }


    drawBackground();


    /*
       Enemies behind player
    */

    for (
        const enemy of enemies
    ) {

        drawEnemy(
            enemy
        );

    }


    /*
       Player
    */

    drawPlayer();


    /*
       Star must appear
       above characters
    */

    drawStarProjectiles();


    drawParticles();

    drawFloatingTexts();


    ctx.restore();

}


/* =====================================================
   BUTTONS
===================================================== */

document
    .getElementById(
        "menuBtn"
    )
    .addEventListener(
        "click",
        () => {

            showPauseMenu();

        }
    );


document
    .getElementById(
        "playBtn"
    )
    .addEventListener(
        "click",
        () => {

            showLevelSelect();

        }
    );


document
    .getElementById(
        "levelBackBtn"
    )
    .addEventListener(
        "click",
        () => {

            showMainMenu();

        }
    );


document
    .getElementById(
        "resumeBtn"
    )
    .addEventListener(
        "click",
        () => {

            gamePaused = false;

            currentScreen =
                "game";

            startBackgroundMusic();

            hideAllScreens();

        }
    );


document
    .getElementById(
        "pauseLevelBtn"
    )
    .addEventListener(
        "click",
        () => {

            showLevelSelect();

        }
    );


document
    .getElementById(
        "pauseExitBtn"
    )
    .addEventListener(
        "click",
        () => {

            exitGame();

        }
    );


document
    .getElementById(
        "mainExitBtn"
    )
    .addEventListener(
        "click",
        () => {

            exitGame();

        }
    );


/* =====================================================
   GAME OVER
===================================================== */

document
    .getElementById(
        "retryBtn"
    )
    .addEventListener(
        "click",
        () => {

            startLevel(
                currentLevel
            );

        }
    );


document
    .getElementById(
        "gameOverLevelBtn"
    )
    .addEventListener(
        "click",
        () => {

            showLevelSelect();

        }
    );


document
    .getElementById(
        "gameOverMenuBtn"
    )
    .addEventListener(
        "click",
        () => {

            showMainMenu();

        }
    );


/* =====================================================
   VICTORY
===================================================== */

document
    .getElementById(
        "victoryLevelBtn"
    )
    .addEventListener(
        "click",
        () => {

            showLevelSelect();

        }
    );


document
    .getElementById(
        "victoryMenuBtn"
    )
    .addEventListener(
        "click",
        () => {

            showMainMenu();

        }
    );


/* =====================================================
   EXIT
===================================================== */

document
    .getElementById(
        "returnBtn"
    )
    .addEventListener(
        "click",
        () => {

            showMainMenu();

        }
    );


/* =====================================================
   VOLUME
===================================================== */

function toggleVolume() {

    volumeOn =
        !volumeOn;

    if (volumeOn) {
        playGameSound("click");
        if (currentScreen === "game") startBackgroundMusic();
    } else {
        stopBackgroundMusic();
    }


    const text =
        volumeOn
            ? "🔊 VOLUME ON"
            : "🔇 VOLUME OFF";


    document
        .getElementById(
            "mainVolumeBtn"
        )
        .textContent =
        text;


    document
        .getElementById(
            "pauseVolumeBtn"
        )
        .textContent =
        text;

}


document
    .getElementById(
        "mainVolumeBtn"
    )
    .addEventListener(
        "click",
        toggleVolume
    );


document
    .getElementById(
        "pauseVolumeBtn"
    )
    .addEventListener(
        "click",
        toggleVolume
    );


/* =====================================================
   KEYBOARD
===================================================== */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key ===
            "ArrowLeft"
        ) {

            keys.left = true;

        }


        if (
            event.key ===
            "ArrowRight"
        ) {

            keys.right = true;

        }


        if (
            event.code ===
            "Space"
        ) {

            event.preventDefault();

            jump();

        }


        if (
            event.key.toLowerCase() ===
            "z"
        ) {

            punch();

        }


        if (
            event.key.toLowerCase() ===
            "x"
        ) {

            swordAttack();

        }


        if (
            event.key ===
            "Escape"
        ) {

            if (
                gameRunning &&
                !gamePaused
            ) {

                showPauseMenu();

            }

        }

    }
);


document.addEventListener(
    "keyup",
    event => {

        if (
            event.key ===
            "ArrowLeft"
        ) {

            keys.left = false;

        }


        if (
            event.key ===
            "ArrowRight"
        ) {

            keys.right = false;

        }

    }
);


/* =====================================================
   MOBILE CONTROLS
===================================================== */

function holdButton(
    element,
    direction
) {

    element.addEventListener(
        "pointerdown",
        event => {

            event.preventDefault();

            keys[direction] =
                true;

        }
    );


    element.addEventListener(
        "pointerup",
        event => {

            event.preventDefault();

            keys[direction] =
                false;

        }
    );


    element.addEventListener(
        "pointercancel",
        () => {

            keys[direction] =
                false;

        }
    );


    element.addEventListener(
        "pointerleave",
        () => {

            keys[direction] =
                false;

        }
    );

}


holdButton(
    document.getElementById(
        "leftBtn"
    ),
    "left"
);


holdButton(
    document.getElementById(
        "rightBtn"
    ),
    "right"
);


/* ================= JUMP ================= */

document
    .getElementById(
        "jumpBtn"
    )
    .addEventListener(
        "pointerdown",
        event => {

            event.preventDefault();

            jump();

        }
    );


/* ================= PUNCH ================= */

document
    .getElementById(
        "punchBtn"
    )
    .addEventListener(
        "pointerdown",
        event => {

            event.preventDefault();

            punch();

        }
    );


/* ================= SWORD ================= */

document
    .getElementById(
        "swordBtn"
    )
    .addEventListener(
        "pointerdown",
        event => {

            event.preventDefault();

            swordAttack();

        }
    );


/* ================= STAR ================= */

document
    .getElementById(
        "starBtn"
    )
    .addEventListener(
        "pointerdown",
        event => {

            event.preventDefault();

            starAttack();

        }
    );


/* =====================================================
   CONTEXT MENU
===================================================== */

document.addEventListener(
    "contextmenu",
    event => {

        event.preventDefault();

    }
);


/* =====================================================
   GAME LOOP
===================================================== */

function gameLoop(
    timestamp
) {

    if (!lastTime) {

        lastTime =
            timestamp;

    }


    let dt =
        (
            timestamp -
            lastTime
        ) / 16.67;


    dt =
        clamp(
            dt,
            0,
            2
        );


    lastTime =
        timestamp;


    update(dt);

    draw();


    requestAnimationFrame(
        gameLoop
    );

}


/* =====================================================
   START
===================================================== */

showMainMenu();


requestAnimationFrame(
    gameLoop
);