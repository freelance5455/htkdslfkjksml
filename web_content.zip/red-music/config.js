// Вставь сюда URL проекта Supabase и publishable/anon key.
// Этот ключ предназначен для клиентского приложения. service_role сюда добавлять НЕЛЬЗЯ.
window.RED_MUSIC_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT_ID.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
