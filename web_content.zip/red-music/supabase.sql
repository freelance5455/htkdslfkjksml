-- RED MUSIC — Supabase SQL setup
-- Вставь весь файл в Supabase Dashboard → SQL Editor → New query → Run.
-- В клиентском config.js используй только publishable/anon key. service_role key не используй.

create extension if not exists pgcrypto;

-- 1) Профили пользователей
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Слушатель',
  avatar_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Автоматически создаём профиль после регистрации через Supabase Auth.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), split_part(new.email, '@', 1), 'Слушатель')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_red_music on auth.users;
create trigger on_auth_user_created_red_music
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at_red_music on public.profiles;
create trigger profiles_updated_at_red_music
before update on public.profiles
for each row execute procedure public.set_updated_at();

-- 2) Треки: один ряд = одна песня. Альбомных таблиц/разделов нет.
create table if not exists public.tracks (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 180),
  artist text not null default 'Неизвестный исполнитель' check (char_length(artist) <= 180),
  duration integer check (duration is null or duration >= 0),
  storage_path text not null unique,
  cover_path text,
  mime_type text not null default 'audio/mpeg',
  file_size bigint check (file_size is null or file_size >= 0),
  visibility text not null default 'private' check (visibility in ('private','public')),
  created_at timestamptz not null default now()
);

-- 3) Плейлисты пользователя
create table if not exists public.playlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 60),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, name)
);

drop trigger if exists playlists_updated_at_red_music on public.playlists;
create trigger playlists_updated_at_red_music
before update on public.playlists
for each row execute procedure public.set_updated_at();

create table if not exists public.playlist_tracks (
  id uuid primary key default gen_random_uuid(),
  playlist_id uuid not null references public.playlists(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  position integer not null default 0,
  added_at timestamptz not null default now(),
  unique (playlist_id, track_id)
);

-- 4) Избранное
create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

-- 5) История воспроизведения — нужна для «Недавно слушал»
create table if not exists public.recent_plays (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  played_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

-- 6) Индексы
create index if not exists tracks_owner_created_idx on public.tracks (owner_id, created_at desc);
create index if not exists tracks_visibility_created_idx on public.tracks (visibility, created_at desc);
create index if not exists playlist_user_created_idx on public.playlists (user_id, created_at desc);
create index if not exists playlist_tracks_playlist_position_idx on public.playlist_tracks (playlist_id, position);
create index if not exists playlist_tracks_track_idx on public.playlist_tracks (track_id);
create index if not exists favorites_user_created_idx on public.favorites (user_id, created_at desc);
create index if not exists recent_plays_user_played_idx on public.recent_plays (user_id, played_at desc);

-- 7) Включаем RLS на всех пользовательских таблицах
alter table public.profiles enable row level security;
alter table public.tracks enable row level security;
alter table public.playlists enable row level security;
alter table public.playlist_tracks enable row level security;
alter table public.favorites enable row level security;
alter table public.recent_plays enable row level security;

-- Profiles: пользователь читает/изменяет только свой профиль.
drop policy if exists "Profiles read own" on public.profiles;
create policy "Profiles read own" on public.profiles
for select to authenticated using (id = (select auth.uid()));
drop policy if exists "Profiles insert own" on public.profiles;
create policy "Profiles insert own" on public.profiles
for insert to authenticated with check (id = (select auth.uid()));
drop policy if exists "Profiles update own" on public.profiles;
create policy "Profiles update own" on public.profiles
for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- Tracks: публичные песни доступны всем, приватные — только владельцу.
drop policy if exists "Tracks read public or own" on public.tracks;
create policy "Tracks read public or own" on public.tracks
for select to anon, authenticated
using (visibility = 'public' or owner_id = (select auth.uid()));
drop policy if exists "Tracks insert own" on public.tracks;
create policy "Tracks insert own" on public.tracks
for insert to authenticated with check (
  owner_id = (select auth.uid())
  and split_part(storage_path, '/', 1) = (select auth.uid())::text
  and (cover_path is null or split_part(cover_path, '/', 1) = (select auth.uid())::text)
);
drop policy if exists "Tracks update own" on public.tracks;
create policy "Tracks update own" on public.tracks
for update to authenticated
using (owner_id = (select auth.uid()))
with check (
  owner_id = (select auth.uid())
  and split_part(storage_path, '/', 1) = (select auth.uid())::text
  and (cover_path is null or split_part(cover_path, '/', 1) = (select auth.uid())::text)
);
drop policy if exists "Tracks delete own" on public.tracks;
create policy "Tracks delete own" on public.tracks
for delete to authenticated using (owner_id = (select auth.uid()));

-- Playlists: только владелец плейлиста.
drop policy if exists "Playlists read own" on public.playlists;
create policy "Playlists read own" on public.playlists
for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Playlists insert own" on public.playlists;
create policy "Playlists insert own" on public.playlists
for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "Playlists update own" on public.playlists;
create policy "Playlists update own" on public.playlists
for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists "Playlists delete own" on public.playlists;
create policy "Playlists delete own" on public.playlists
for delete to authenticated using (user_id = (select auth.uid()));

-- Playlist tracks: добавлять можно только в собственный плейлист и только трек,
-- который доступен пользователю (свой приватный либо публичный).
drop policy if exists "Playlist tracks read own playlists" on public.playlist_tracks;
create policy "Playlist tracks read own playlists" on public.playlist_tracks
for select to authenticated using (
  exists (select 1 from public.playlists p where p.id = playlist_id and p.user_id = (select auth.uid()))
);
drop policy if exists "Playlist tracks insert own playlists" on public.playlist_tracks;
create policy "Playlist tracks insert own playlists" on public.playlist_tracks
for insert to authenticated with check (
  exists (select 1 from public.playlists p where p.id = playlist_id and p.user_id = (select auth.uid()))
  and exists (select 1 from public.tracks t where t.id = track_id and (t.owner_id = (select auth.uid()) or t.visibility = 'public'))
);
drop policy if exists "Playlist tracks delete own playlists" on public.playlist_tracks;
create policy "Playlist tracks delete own playlists" on public.playlist_tracks
for delete to authenticated using (
  exists (select 1 from public.playlists p where p.id = playlist_id and p.user_id = (select auth.uid()))
);

-- Favorites: пользователь управляет только своим списком и может добавить доступный ему трек.
drop policy if exists "Favorites read own" on public.favorites;
create policy "Favorites read own" on public.favorites
for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Favorites insert own" on public.favorites;
create policy "Favorites insert own" on public.favorites
for insert to authenticated with check (
  user_id = (select auth.uid())
  and exists (select 1 from public.tracks t where t.id = track_id and (t.owner_id = (select auth.uid()) or t.visibility = 'public'))
);
drop policy if exists "Favorites delete own" on public.favorites;
create policy "Favorites delete own" on public.favorites
for delete to authenticated using (user_id = (select auth.uid()));

-- Recent plays: каждая запись принадлежит текущему пользователю.
drop policy if exists "Recent plays read own" on public.recent_plays;
create policy "Recent plays read own" on public.recent_plays
for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Recent plays insert own" on public.recent_plays;
create policy "Recent plays insert own" on public.recent_plays
for insert to authenticated with check (
  user_id = (select auth.uid())
  and exists (select 1 from public.tracks t where t.id = track_id and (t.owner_id = (select auth.uid()) or t.visibility = 'public'))
);
drop policy if exists "Recent plays update own" on public.recent_plays;
create policy "Recent plays update own" on public.recent_plays
for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- 8) Private Storage bucket. Публичные песни тоже остаются в private bucket,
-- но их можно прочитать через RLS-политику ниже и временные signed URLs.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'music-files', 'music-files', false, 104857600,
  array[
    'audio/mpeg','audio/mp3','audio/wav','audio/x-wav','audio/wave','audio/mp4',
    'audio/aac','audio/ogg','audio/opus','audio/flac','audio/webm','audio/x-m4a',
    'image/jpeg','image/png','image/webp'
  ]
)
on conflict (id) do update set
  public = false,
  file_size_limit = 104857600,
  allowed_mime_types = excluded.allowed_mime_types;

-- Storage SELECT: владелец читает свои объекты; любой посетитель может читать
-- только файлы, путь которых связан с публичным треком.
drop policy if exists "RED MUSIC read own or public audio" on storage.objects;
create policy "RED MUSIC read own or public audio" on storage.objects
for select to anon, authenticated
using (
  bucket_id = 'music-files'
  and (
    (select auth.uid())::text = (storage.foldername(name))[1]
    or exists (
      select 1 from public.tracks t
      where (t.storage_path = name or t.cover_path = name)
        and t.visibility = 'public'
        and split_part(name, '/', 1) = t.owner_id::text
    )
  )
);

-- Upload: объект кладётся в папку с UUID текущего пользователя.
drop policy if exists "RED MUSIC upload own files" on storage.objects;
create policy "RED MUSIC upload own files" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'music-files'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "RED MUSIC update own files" on storage.objects;
create policy "RED MUSIC update own files" on storage.objects
for update to authenticated
using (
  bucket_id = 'music-files'
  and (storage.foldername(name))[1] = (select auth.uid())::text
)
with check (
  bucket_id = 'music-files'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "RED MUSIC delete own files" on storage.objects;
create policy "RED MUSIC delete own files" on storage.objects
for delete to authenticated
using (
  bucket_id = 'music-files'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

-- 9) Явные права Data API для клиентских ролей.
-- RLS остаётся главным ограничителем строк; GRANT задаёт только доступные операции.
grant usage on schema public to anon, authenticated;
grant select on public.tracks to anon;
grant select, insert, update, delete on public.profiles to authenticated;
grant select, insert, update, delete on public.tracks to authenticated;
grant select, insert, update, delete on public.playlists to authenticated;
grant select, insert, update, delete on public.playlist_tracks to authenticated;
grant select, insert, delete on public.favorites to authenticated;
grant select, insert, update on public.recent_plays to authenticated;

-- Готово. После запуска SQL проверь, что в Storage появился bucket music-files.
