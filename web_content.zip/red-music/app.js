const CONFIG = window.RED_MUSIC_CONFIG || {};
const BUCKET = 'music-files';
const MAX_AUDIO_BYTES = 100 * 1024 * 1024;
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  db: null, supabase: null, user: null, profile: null,
  tab: 'home', authMode: 'login', search: '', libraryFilter: 'all',
  cloudTracks: [], localTracks: [], favorites: new Set(), localFavorites: new Set(),
  playlists: [], playlistRows: [], recentCloud: [], recentLocal: [],
  selectedPlaylist: null, loadingCloud: false,
  currentTrackId: null, queue: [], queueIndex: -1, shuffle: false, repeat: 'off',
  isPlaying: false, installPrompt: null, activeObjectUrl: null, authSubscription: null
};

const audio = $('#audio');
const screen = $('#screen');

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function fmtTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const s = Math.floor(seconds);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
function titleFromFilename(name = '') {
  return name.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Без названия';
}
function toast(message, type = 'info') {
  const root = $('#toast-root');
  const node = document.createElement('div');
  node.className = `toast ${type === 'error' ? 'error' : ''}`;
  node.textContent = message;
  root.append(node);
  setTimeout(() => node.remove(), 3600);
}
function setBusy(button, busy, label = 'Подождите…') {
  if (!button) return;
  if (busy) {
    button.dataset.oldLabel = button.textContent;
    button.textContent = label;
    button.disabled = true;
    button.classList.add('is-busy');
  } else {
    button.textContent = button.dataset.oldLabel || button.textContent;
    button.disabled = false;
    button.classList.remove('is-busy');
  }
}
function isConfigured() {
  return Boolean(CONFIG.SUPABASE_URL && CONFIG.SUPABASE_ANON_KEY && !CONFIG.SUPABASE_URL.includes('YOUR_PROJECT') && !CONFIG.SUPABASE_ANON_KEY.includes('YOUR_SUPABASE'));
}
function online() { return navigator.onLine; }
function getAllTracks() { return [...state.cloudTracks, ...state.localTracks]; }
function getTrack(id) { return getAllTracks().find((track) => track.id === id) || null; }
function isLocal(track) { return Boolean(track?.is_local); }
function isFavorite(track) { return isLocal(track) ? state.localFavorites.has(track.id) : state.favorites.has(track.id); }
function trackArt(track, className = 'track-art') {
  const cover = track?.cover_url || track?.coverUrl || '';
  const fallback = `<span>${escapeHtml((track?.title || 'R').trim().charAt(0).toUpperCase())}</span>`;
  return `<span class="${className}">${cover ? `<img src="${escapeHtml(cover)}" alt="Обложка ${escapeHtml(track?.title || 'трека')}" loading="lazy">` : fallback}</span>`;
}
function trackTags(track) {
  const tags = [];
  if (isLocal(track)) tags.push('<span class="tag local">НА ТЕЛЕФОНЕ</span>');
  else if (track.visibility === 'private') tags.push('<span class="tag private">ЛИЧНЫЙ</span>');
  if (track.offline) tags.push('<span class="tag local">ОФЛАЙН</span>');
  return tags.join('');
}

// IndexedDB: постоянное хранилище локальных песен и офлайн-копий облачных треков.
function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('red-music-device', 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('local_tracks')) db.createObjectStore('local_tracks', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('offline_audio')) db.createObjectStore('offline_audio', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Не удалось открыть память телефона'));
  });
}
function idbRequest(storeName, mode, operation) {
  return new Promise((resolve, reject) => {
    const tx = state.db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    const req = operation(store);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
const localGetAll = () => idbRequest('local_tracks', 'readonly', (s) => s.getAll());
const localPut = (record) => idbRequest('local_tracks', 'readwrite', (s) => s.put(record));
const localDelete = (id) => idbRequest('local_tracks', 'readwrite', (s) => s.delete(id));
const offlineGet = (id) => idbRequest('offline_audio', 'readonly', (s) => s.get(id));
const offlinePut = (record) => idbRequest('offline_audio', 'readwrite', (s) => s.put(record));
const offlineDelete = (id) => idbRequest('offline_audio', 'readwrite', (s) => s.delete(id));
const metaGet = (key) => idbRequest('meta', 'readonly', (s) => s.get(key));
const metaPut = (key, value) => idbRequest('meta', 'readwrite', (s) => s.put({ key, value }));

function updateConnection() {
  const pill = $('#connection-pill');
  if (online()) {
    pill.classList.remove('offline');
    pill.querySelector('span').textContent = state.user ? 'Облако подключено' : 'Есть интернет';
  } else {
    pill.classList.add('offline');
    pill.querySelector('span').textContent = 'Офлайн-режим';
  }
}

async function initSupabase() {
  if (!isConfigured()) return;
  if (!window.supabase?.createClient) {
    toast('Не загрузилась библиотека Supabase. Открой приложение с интернетом и обнови страницу.', 'error');
    return;
  }
  state.supabase = window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
  });
  const { data, error } = await state.supabase.auth.getSession();
  if (error) console.warn('Session read:', error.message);
  state.user = data?.session?.user || null;
  state.authSubscription = state.supabase.auth.onAuthStateChange((_event, session) => {
    // Не выполняем запросы Supabase прямо внутри auth callback.
    queueMicrotask(async () => {
      state.user = session?.user || null;
      if (!state.user) {
        state.profile = null;
        state.favorites.clear();
        state.playlists = [];
        state.playlistRows = [];
      }
      if (online() && state.supabase) await loadCloudData();
      updateConnection();
      render();
    });
  });
}

async function storageSignedUrl(path, expiresIn = 3600) {
  if (!state.supabase || !path) return null;
  const { data, error } = await state.supabase.storage.from(BUCKET).createSignedUrl(path, expiresIn);
  if (error) throw error;
  return data.signedUrl;
}

async function loadCachedCloudData() {
  if (!state.db) return;
  const key = `cloud_snapshot:${state.user?.id || 'public'}`;
  const snapshot = await metaGet(key);
  if (!snapshot?.value) return;
  const cached = snapshot.value;
  if ((cached.user_id || null) !== (state.user?.id || null)) return;
  state.cloudTracks = (cached.tracks || []).map((track) => ({ ...track, is_local: false, cover_url: null, offline: false }));
  await Promise.all(state.cloudTracks.map(async (track) => { track.offline = Boolean(await offlineGet(track.id)); }));
  state.favorites = new Set(cached.favorites || []);
  state.playlists = cached.playlists || [];
  state.playlistRows = cached.playlistRows || [];
  state.recentCloud = cached.recentCloud || [];
}

async function saveCloudSnapshot() {
  const key = `cloud_snapshot:${state.user?.id || 'public'}`;
  const tracks = state.cloudTracks.map(({ cover_url, coverUrl, offline, ...track }) => track);
  await metaPut(key, {
    user_id: state.user?.id || null,
    tracks,
    favorites: [...state.favorites],
    playlists: state.playlists,
    playlistRows: state.playlistRows,
    recentCloud: state.recentCloud
  });
}

async function loadCloudData() {
  if (!state.supabase || !online()) return;
  state.loadingCloud = true;
  render();
  try {
    const [tracksRes, favoritesRes, playlistsRes, playlistRowsRes, recentRes, profileRes] = await Promise.all([
      state.supabase.from('tracks').select('*').order('created_at', { ascending: false }),
      state.user ? state.supabase.from('favorites').select('track_id') : Promise.resolve({ data: [], error: null }),
      state.user ? state.supabase.from('playlists').select('*').order('created_at', { ascending: false }) : Promise.resolve({ data: [], error: null }),
      state.user ? state.supabase.from('playlist_tracks').select('playlist_id,track_id,position').order('position') : Promise.resolve({ data: [], error: null }),
      state.user ? state.supabase.from('recent_plays').select('track_id,played_at').order('played_at', { ascending: false }).limit(20) : Promise.resolve({ data: [], error: null }),
      state.user ? state.supabase.from('profiles').select('display_name,avatar_path').eq('id', state.user.id).maybeSingle() : Promise.resolve({ data: null, error: null })
    ]);
    if (tracksRes.error) throw tracksRes.error;
    if (favoritesRes.error) throw favoritesRes.error;
    if (playlistsRes.error) throw playlistsRes.error;
    if (playlistRowsRes.error) throw playlistRowsRes.error;
    if (recentRes.error) throw recentRes.error;
    if (profileRes.error && profileRes.error.code !== 'PGRST116') throw profileRes.error;

    state.cloudTracks = (tracksRes.data || []).map((track) => ({ ...track, is_local: false, offline: false }));
    state.favorites = new Set((favoritesRes.data || []).map((row) => row.track_id));
    state.playlists = playlistsRes.data || [];
    state.playlistRows = playlistRowsRes.data || [];
    state.recentCloud = recentRes.data || [];
    state.profile = profileRes.data || null;

    // Получаем доступные подписанные ссылки на обложки. Сам аудиофайл открывается только при запуске/скачивании.
    await Promise.all(state.cloudTracks.map(async (track) => {
      if (track.cover_path) {
        try { track.cover_url = await storageSignedUrl(track.cover_path, 3600); }
        catch (error) { console.warn('Cover URL:', error.message); }
      }
      try { track.offline = Boolean(await offlineGet(track.id)); }
      catch { track.offline = false; }
    }));
    await saveCloudSnapshot();
  } catch (error) {
    console.error(error);
    toast(`Не удалось обновить облако: ${error.message || 'ошибка сети'}`, 'error');
  } finally {
    state.loadingCloud = false;
    updateConnection();
    render();
  }
}

async function loadDeviceData() {
  const records = await localGetAll();
  state.localTracks = records.map((row) => ({ ...row, is_local: true, offline: true }));
  const favorites = await metaGet('local_favorites');
  state.localFavorites = new Set(favorites?.value || []);
  const recents = await metaGet('local_recent');
  state.recentLocal = recents?.value || [];
}

function navTo(tab) {
  state.tab = tab;
  state.selectedPlaylist = null;
  $$('.nav-item').forEach((button) => button.classList.toggle('active', button.dataset.tab === tab));
  render();
  screen.scrollTop = 0;
}
function render() {
  updateConnection();
  $$('.nav-item').forEach((button) => button.classList.toggle('active', button.dataset.tab === state.tab));
  const renderers = { home: renderHome, search: renderSearch, library: renderLibrary, playlists: renderPlaylists, profile: renderProfile };
  screen.innerHTML = (renderers[state.tab] || renderHome)();
  updateMiniPlayer();
}

function renderTrackList(tracks, options = {}) {
  if (!tracks.length) return `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-music"/></svg></div><h3>${escapeHtml(options.emptyTitle || 'Пока нет треков')}</h3><p>${escapeHtml(options.emptyText || 'Добавь музыку с телефона или подключи облачную библиотеку.')}</p>${options.button || ''}</div>`;
  return `<div class="track-list">${tracks.map((track) => {
    const current = track.id === state.currentTrackId;
    return `<div class="track-row ${current ? 'now-playing' : ''}" data-track-row="${escapeHtml(track.id)}">
      ${trackArt(track)}
      <div class="track-info"><strong>${escapeHtml(track.title)}</strong><small>${escapeHtml(track.artist || 'Неизвестный исполнитель')} ${trackTags(track)}</small></div>
      <span class="track-duration">${fmtTime(track.duration)}</span>
      <div class="track-actions">
        <button class="track-action ${isFavorite(track) ? 'active' : ''}" data-action="favorite" data-id="${escapeHtml(track.id)}" aria-label="Избранное"><svg><use href="#i-heart"/></svg></button>
        <button class="track-action ${track.offline ? 'active' : ''}" data-action="offline" data-id="${escapeHtml(track.id)}" aria-label="Сохранить офлайн"><svg><use href="#i-download"/></svg></button>
        <button class="track-action" data-action="track-more" data-id="${escapeHtml(track.id)}" aria-label="Действия"><svg><use href="#i-more"/></svg></button>
        <button class="track-action" data-action="play" data-id="${escapeHtml(track.id)}" aria-label="Слушать"><svg><use href="#i-play"/></svg></button>
      </div>
    </div>`;
  }).join('')}</div>`;
}

function renderHome() {
  const all = getAllTracks();
  const favorites = all.filter(isFavorite);
  const recentIds = [...state.recentLocal, ...state.recentCloud.map((row) => row.track_id)];
  const recent = [...new Set(recentIds)].map(getTrack).filter(Boolean).slice(0, 5);
  const featured = all.slice(0, 5);
  return `<section class="welcome-block"><div class="eyebrow">ТВОЙ ЗВУК · ТВОИ ПРАВИЛА</div><h1>Музыка всегда<br><span>с тобой.</span></h1><p>Твоя личная библиотека — онлайн и офлайн.<br>Без альбомных разделов. Только любимые треки.</p></section>
    <section class="hero-card"><div class="hero-copy"><small>RED MUSIC PLAYER</small><h2>Нажми play.<br>Остальное подождёт.</h2><p>${all.length ? `${all.length} треков в твоей библиотеке` : 'Добавь первую песню и собери свою библиотеку'}</p><button class="primary-button" data-tab="library"><svg><use href="#i-music"/></svg> Моя музыка</button></div></section>
    <div class="quick-grid">
      <button class="quick-card" data-action="open-favorites"><span class="quick-icon"><svg><use href="#i-heart"/></svg></span><span><strong>Избранное</strong><small>${favorites.length} треков</small></span></button>
      <button class="quick-card" data-action="open-offline"><span class="quick-icon"><svg><use href="#i-download"/></svg></span><span><strong>Офлайн</strong><small>${state.localTracks.length + state.cloudTracks.filter(t=>t.offline).length} сохранено</small></span></button>
    </div>
    <div class="section-heading"><h2>Недавно слушал</h2><button data-tab="library">Все треки</button></div>
    ${recent.length ? renderTrackList(recent) : `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-music"/></svg></div><h3>Здесь появится твоя история</h3><p>Запусти любую песню — мы покажем её здесь.</p></div>`}
    <div class="section-heading"><h2>Твоя музыка</h2><button data-tab="library">Открыть</button></div>
    ${state.loadingCloud && !featured.length ? '<div class="skeleton-row"><div class="skeleton-art"></div><div class="loading-line" style="width:58%"></div></div>'.repeat(3) : renderTrackList(featured, { emptyTitle: 'Пока пусто', emptyText: 'Импортируй песни с устройства. Они останутся доступными без интернета.', button: '<button class="primary-button" data-action="import-local">Добавить музыку</button>' })}`;
}

function renderSearch() {
  const q = state.search.trim().toLowerCase();
  const all = getAllTracks();
  const results = q ? all.filter((track) => `${track.title} ${track.artist || ''}`.toLowerCase().includes(q)) : [];
  return `<div class="eyebrow">НАЙДИ СВОЙ ЗВУК</div><h1 class="page-title">Поиск</h1><p class="page-subtitle">По названию трека или исполнителю.</p>
    <label class="search-box"><svg><use href="#i-search"/></svg><input id="search-input" type="search" value="${escapeHtml(state.search)}" placeholder="Какую песню включим?" autocomplete="off"></label>
    <div id="search-results">${q ? `<div class="section-heading"><h2>Результаты</h2><span class="muted-line">${results.length}</span></div>${renderTrackList(results, {emptyTitle:'Ничего не найдено',emptyText:'Попробуй другое название или проверь написание.'})}` : `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-search"/></svg></div><h3>Ищи среди своих треков</h3><p>Сначала добавь музыку с телефона или загрузи песни в облачную библиотеку.</p><button class="secondary-button" data-tab="library">Открыть мою музыку</button></div>`}</div>`;
}

function renderLibrary() {
  const filters = [ ['all','Все'], ['favorites','Избранное'], ['offline','Офлайн'], ['cloud','Облако'], ['local','На телефоне'] ];
  let tracks = getAllTracks();
  if (state.libraryFilter === 'favorites') tracks = tracks.filter(isFavorite);
  if (state.libraryFilter === 'offline') tracks = tracks.filter((t) => isLocal(t) || t.offline);
  if (state.libraryFilter === 'cloud') tracks = tracks.filter((t) => !isLocal(t));
  if (state.libraryFilter === 'local') tracks = tracks.filter(isLocal);
  return `<div class="eyebrow">ТВОЯ КОЛЛЕКЦИЯ</div><h1 class="page-title">Моя музыка</h1><p class="page-subtitle">Простой список песен. Никаких альбомных разделов.</p>
    <div class="page-tools"><button class="primary-button" data-action="import-local"><svg><use href="#i-plus"/></svg> С телефона</button><button class="secondary-button" data-action="upload-cloud"><svg><use href="#i-cloud"/></svg> В облако</button></div>
    <div class="filter-chips">${filters.map(([id,label])=>`<button class="chip ${state.libraryFilter===id?'active':''}" data-filter="${id}">${label}</button>`).join('')}</div>
    <div class="section-heading"><h2>${filters.find(([id])=>id===state.libraryFilter)?.[1] || 'Все треки'}</h2><span class="muted-line">${tracks.length} треков</span></div>
    ${state.loadingCloud && !state.localTracks.length ? '<div class="skeleton-row"><div class="skeleton-art"></div><div class="loading-line" style="width:62%"></div></div>'.repeat(3) : renderTrackList(tracks,{emptyTitle:'Здесь пока нет песен',emptyText:'Добавь MP3, WAV, M4A и другие аудиофайлы. Для офлайн-прослушивания импортируй их с телефона.',button:'<button class="primary-button" data-action="import-local">Добавить первый трек</button>'})}`;
}

function renderPlaylists() {
  if (state.selectedPlaylist) return renderPlaylistDetail();
  const cards = state.playlists.map((playlist) => {
    const count = state.playlistRows.filter((row) => row.playlist_id === playlist.id).length;
    return `<div class="playlist-card"><button class="playlist-art" data-action="open-playlist" data-id="${playlist.id}" aria-label="Открыть плейлист"><svg><use href="#i-list"/></svg></button><button class="playlist-copy" data-action="open-playlist" data-id="${playlist.id}" style="text-align:left;background:none"><strong>${escapeHtml(playlist.name)}</strong><small>${count} треков</small></button><button class="track-action" data-action="rename-playlist" data-id="${playlist.id}" aria-label="Переименовать"><svg><use href="#i-more"/></svg></button><button class="track-action" data-action="delete-playlist" data-id="${playlist.id}" aria-label="Удалить"><svg><use href="#i-trash"/></svg></button></div>`;
  }).join('');
  return `<div class="eyebrow">СОБЕРИ СВОЁ</div><h1 class="page-title">Плейлисты</h1><p class="page-subtitle">Собирай треки по настроению и включай одним нажатием.</p>
    <div class="page-tools"><button class="primary-button" data-action="create-playlist"><svg><use href="#i-plus"/></svg> Новый плейлист</button></div>
    ${state.user ? (cards || `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-list"/></svg></div><h3>Плейлистов пока нет</h3><p>Создай первый и добавляй в него любимые песни.</p></div>`) : `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-user"/></svg></div><h3>Войди, чтобы сохранять плейлисты</h3><p>Плейлисты синхронизируются с твоим аккаунтом Supabase.</p><button class="primary-button" data-tab="profile">Войти в аккаунт</button></div>`}`;
}

function renderPlaylistDetail() {
  const playlist = state.playlists.find((item) => item.id === state.selectedPlaylist);
  if (!playlist) { state.selectedPlaylist = null; return renderPlaylists(); }
  const ids = state.playlistRows.filter((row) => row.playlist_id === playlist.id).sort((a,b)=>(a.position||0)-(b.position||0)).map((row) => row.track_id);
  const tracks = ids.map(getTrack).filter(Boolean);
  return `<button class="text-link" data-action="back-playlists"><svg style="width:14px;height:14px;vertical-align:middle"><use href="#i-back"/></svg> Все плейлисты</button><div class="eyebrow">ТВОЙ ПЛЕЙЛИСТ</div><h1 class="page-title">${escapeHtml(playlist.name)}</h1><p class="page-subtitle">${tracks.length} треков</p><div class="page-tools"><button class="primary-button" data-action="play-playlist" data-id="${playlist.id}"><svg><use href="#i-play"/></svg> Слушать всё</button><button class="secondary-button" data-action="add-track-playlist" data-id="${playlist.id}"><svg><use href="#i-plus"/></svg> Добавить треки</button></div>${renderTrackList(tracks,{emptyTitle:'Плейлист пуст',emptyText:'Добавь в него песни из своей библиотеки.'})}`;
}

function renderProfile() {
  const configured = isConfigured();
  const user = state.user;
  const title = state.profile?.display_name || user?.user_metadata?.display_name || user?.email?.split('@')[0] || 'Мой профиль';
  return `<div class="eyebrow">RED MUSIC ACCOUNT</div><h1 class="page-title">Профиль</h1><p class="page-subtitle">Аккаунт, облачная библиотека и настройки приложения.</p>
    ${user ? `<div class="profile-card"><div class="profile-avatar">${escapeHtml(title.slice(0,2).toUpperCase())}</div><div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(user.email || '')}</p></div><span class="status-badge">Подключён</span></div><div class="notice"><strong>Облако подключено.</strong> Приватные песни видны только тебе. Публичные треки доступны другим пользователям согласно настройке доступа.</div><div class="account-actions"><button class="secondary-button" data-action="refresh-cloud">Обновить библиотеку</button><button class="danger-button" data-action="signout">Выйти</button></div>` : `<div class="auth-card"><div class="auth-tabs"><button class="${state.authMode==='login'?'active':''}" data-action="auth-mode" data-mode="login">Вход</button><button class="${state.authMode==='signup'?'active':''}" data-action="auth-mode" data-mode="signup">Регистрация</button></div>${configured ? `<form id="auth-form"><div class="field"><label for="auth-email">Электронная почта</label><input id="auth-email" name="email" type="email" autocomplete="email" placeholder="name@example.com" required></div><div class="field"><label for="auth-password">Пароль</label><input id="auth-password" name="password" type="password" minlength="6" autocomplete="${state.authMode==='login'?'current-password':'new-password'}" placeholder="Минимум 6 символов" required></div><button class="primary-button full-width" type="submit">${state.authMode==='login'?'Войти в RED MUSIC':'Создать аккаунт'}</button></form><p class="form-note">${state.authMode==='signup'?'После регистрации Supabase может отправить письмо для подтверждения почты.':'Сессия сохраняется на этом устройстве.'}</p>` : `<div class="notice"><strong>Осталось подключить Supabase.</strong><br>В файле config.js укажи URL проекта и publishable/anon key. Подробные шаги есть в README.</div>`}</div>`}
    <div class="section-heading"><h2>Работа без интернета</h2></div><div class="notice"><strong>Локальная музыка доступна офлайн.</strong> Импортированные файлы и сохранённые кнопкой «Офлайн» треки хранятся в памяти браузера на телефоне. Регистрация, синхронизация, загрузка в облако и получение новых песен требуют интернета.</div>
    <div class="section-heading"><h2>Приложение</h2></div><div class="playlist-card"><span class="playlist-art"><svg><use href="#i-download"/></svg></span><span class="playlist-copy"><strong>Установить RED MUSIC</strong><small>Добавить значок на главный экран Android</small></span><button class="secondary-button" data-action="install-app">Установить</button></div><p class="muted-line">RED MUSIC · PWA · Supabase JS v2</p>`;
}

function updateMiniPlayer() {
  const mini = $('#mini-player');
  const track = getTrack(state.currentTrackId);
  if (!track) { mini.classList.add('hidden'); return; }
  mini.classList.remove('hidden');
  $('#mini-title').textContent = track.title;
  $('#mini-artist').textContent = track.artist || 'Неизвестный исполнитель';
  $('#mini-art').innerHTML = track.cover_url || track.coverUrl ? `<img src="${escapeHtml(track.cover_url || track.coverUrl)}" alt="">` : escapeHtml(track.title.trim().charAt(0).toUpperCase());
  $('#mini-play').innerHTML = `<svg><use href="#i-${state.isPlaying ? 'pause' : 'play'}"/></svg>`;
  const nowPlayingRow = $('[data-track-row].now-playing');
  if (nowPlayingRow) nowPlayingRow.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

function showPlayer() {
  if (!state.currentTrackId) { toast('Сначала выбери песню.'); return; }
  $('#player-overlay').classList.remove('hidden');
  $('#player-overlay').setAttribute('aria-hidden', 'false');
  updatePlayerUI();
}
function hidePlayer() {
  $('#player-overlay').classList.add('hidden');
  $('#player-overlay').setAttribute('aria-hidden', 'true');
}
function updatePlayerUI() {
  const track = getTrack(state.currentTrackId);
  if (!track) return;
  $('#player-title').textContent = track.title;
  $('#player-artist').textContent = track.artist || 'Неизвестный исполнитель';
  $('#player-art').innerHTML = track.cover_url || track.coverUrl ? `<img src="${escapeHtml(track.cover_url || track.coverUrl)}" alt="Обложка">` : '<span class="art-eq"><i></i><i></i><i></i><i></i><i></i></span>';
  $('#player-favorite').classList.toggle('active', isFavorite(track));
  $('#main-play').innerHTML = `<svg><use href="#i-${state.isPlaying ? 'pause' : 'play'}"/></svg>`;
  $('#seek').value = audio.duration ? Math.round((audio.currentTime / audio.duration) * 1000) : 0;
  $('#current-time').textContent = fmtTime(audio.currentTime);
  $('#total-time').textContent = fmtTime(audio.duration || track.duration);
  $('#shuffle').classList.toggle('active', state.shuffle);
  $('#repeat').classList.toggle('active', state.repeat !== 'off');
  $('#repeat-label').textContent = state.repeat === 'one' ? '1' : '';
  $('#player-status').textContent = isLocal(track) ? 'Файл хранится на этом устройстве' : track.offline ? 'Сохранено для офлайн-прослушивания' : (online() ? 'Облачный трек' : 'Нет офлайн-копии');
}

async function getPlayableSource(track) {
  if (isLocal(track)) return URL.createObjectURL(track.blob);
  const cached = await offlineGet(track.id);
  if (cached?.blob) return URL.createObjectURL(cached.blob);
  if (!online()) throw new Error('Эта песня не сохранена офлайн. Подключись к интернету и нажми «Офлайн».');
  if (!track.storage_path) throw new Error('У трека отсутствует путь к аудиофайлу.');
  return await storageSignedUrl(track.storage_path, 3600);
}

async function playTrack(trackOrId, queueTracks = null) {
  const track = typeof trackOrId === 'string' ? getTrack(trackOrId) : trackOrId;
  if (!track) { toast('Трек не найден.', 'error'); return; }
  try {
    if (queueTracks) {
      state.queue = queueTracks.map((item) => item.id);
      state.queueIndex = state.queue.indexOf(track.id);
    } else if (!state.queue.length || !state.queue.includes(track.id)) {
      state.queue = getAllTracks().map((item) => item.id);
      state.queueIndex = state.queue.indexOf(track.id);
    } else {
      state.queueIndex = state.queue.indexOf(track.id);
    }
    const src = await getPlayableSource(track);
    if (state.activeObjectUrl) URL.revokeObjectURL(state.activeObjectUrl);
    state.activeObjectUrl = src.startsWith('blob:') ? src : null;
    audio.src = src;
    state.currentTrackId = track.id;
    updatePlayerUI(); updateMiniPlayer();
    await audio.play();
    state.isPlaying = true;
    recordRecent(track);
    updatePlayerUI(); updateMiniPlayer(); updateMediaSession(track);
    render();
  } catch (error) {
    console.error(error);
    toast(error.message || 'Не удалось запустить воспроизведение.', 'error');
  }
}

async function recordRecent(track) {
  if (isLocal(track)) {
    state.recentLocal = [track.id, ...state.recentLocal.filter((id) => id !== track.id)].slice(0, 20);
    await metaPut('local_recent', state.recentLocal);
  } else if (state.user && online() && state.supabase) {
    const { error } = await state.supabase.from('recent_plays').upsert({ user_id: state.user.id, track_id: track.id, played_at: new Date().toISOString() }, { onConflict: 'user_id,track_id' });
    if (error) console.warn('Recent play:', error.message);
  }
}

async function togglePlay() {
  if (!state.currentTrackId) {
    const first = getAllTracks()[0];
    if (first) await playTrack(first);
    else toast('Добавь музыку, чтобы начать слушать.');
    return;
  }
  if (audio.paused) {
    try { await audio.play(); state.isPlaying = true; }
    catch (error) { toast(error.message || 'Не удалось продолжить воспроизведение.', 'error'); }
  } else { audio.pause(); state.isPlaying = false; }
  updatePlayerUI(); updateMiniPlayer();
}
async function playNext() {
  if (!state.queue.length) state.queue = getAllTracks().map((track) => track.id);
  if (!state.queue.length) return;
  let nextIndex = state.queueIndex + 1;
  if (nextIndex >= state.queue.length) {
    if (state.repeat === 'all') nextIndex = 0;
    else { audio.pause(); state.isPlaying = false; updatePlayerUI(); updateMiniPlayer(); return; }
  }
  state.queueIndex = nextIndex;
  const track = getTrack(state.queue[nextIndex]);
  if (track) await playTrack(track, state.queue.map(getTrack).filter(Boolean));
}
function toggleShuffle() {
  const currentId = state.currentTrackId;
  state.shuffle = !state.shuffle;
  if (state.shuffle) {
    const remaining = state.queue.filter((id) => id !== currentId).sort(() => Math.random() - 0.5);
    state.queue = currentId ? [currentId, ...remaining] : remaining;
    state.queueIndex = currentId ? 0 : -1;
  } else {
    state.queue = getAllTracks().map((track) => track.id);
    state.queueIndex = state.queue.indexOf(currentId);
  }
  updatePlayerUI();
  toast(state.shuffle ? 'Перемешивание включено' : 'Перемешивание выключено');
}
async function playPrevious() {
  if (audio.currentTime > 3) { audio.currentTime = 0; return; }
  if (!state.queue.length) return;
  let index = state.queueIndex - 1;
  if (index < 0) index = state.repeat === 'all' ? state.queue.length - 1 : 0;
  state.queueIndex = index;
  const track = getTrack(state.queue[index]);
  if (track) await playTrack(track, state.queue.map(getTrack).filter(Boolean));
}

function updateMediaSession(track) {
  if (!('mediaSession' in navigator)) return;
  try {
    if ('MediaMetadata' in window) navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist || 'RED MUSIC',
      album: 'RED MUSIC',
      artwork: track.cover_url ? [{ src: track.cover_url, sizes: '512x512', type: 'image/jpeg' }] : []
    });
    navigator.mediaSession.setActionHandler('play', () => { if (audio.paused) togglePlay(); });
    navigator.mediaSession.setActionHandler('pause', () => { if (!audio.paused) togglePlay(); });
    navigator.mediaSession.setActionHandler('previoustrack', playPrevious);
    navigator.mediaSession.setActionHandler('nexttrack', playNext);
    navigator.mediaSession.setActionHandler('seekto', (details) => { if (Number.isFinite(details.seekTime)) audio.currentTime = details.seekTime; });
    navigator.mediaSession.playbackState = state.isPlaying ? 'playing' : 'paused';
  } catch (error) { console.warn('Media Session:', error); }
}

async function saveOffline(track) {
  if (!track) return;
  if (isLocal(track)) { toast('Эта песня уже хранится на телефоне.'); return; }
  const cached = await offlineGet(track.id);
  if (cached?.blob) { toast('Трек уже сохранён офлайн.'); track.offline = true; render(); return; }
  if (!online()) { toast('Нужен интернет, чтобы скачать трек для офлайн-прослушивания.', 'error'); return; }
  try {
    toast('Сохраняю песню на устройство…');
    const url = await storageSignedUrl(track.storage_path, 3600);
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Ошибка загрузки аудио: ${response.status}`);
    let blob;
    if (response.body?.getReader) {
      const reader = response.body.getReader();
      const chunks = [];
      let loaded = 0;
      const total = Number(response.headers.get('content-length')) || 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value); loaded += value.byteLength;
        if (total) $('#player-status').textContent = `Сохранение… ${Math.round(loaded / total * 100)}%`;
      }
      blob = new Blob(chunks, { type: track.mime_type || response.headers.get('content-type') || 'audio/mpeg' });
    } else blob = await response.blob();
    await offlinePut({ id: track.id, blob, mime: blob.type, saved_at: new Date().toISOString() });
    track.offline = true;
    toast('Готово! Песня доступна без интернета.');
    updatePlayerUI(); render();
  } catch (error) {
    console.error(error);
    toast(error.message || 'Не удалось сохранить песню офлайн.', 'error');
  }
}

async function toggleFavorite(track) {
  if (!track) return;
  if (isLocal(track)) {
    if (state.localFavorites.has(track.id)) state.localFavorites.delete(track.id);
    else state.localFavorites.add(track.id);
    await metaPut('local_favorites', [...state.localFavorites]);
  } else {
    if (!state.user || !state.supabase) { toast('Войди в аккаунт, чтобы синхронизировать избранное.'); return; }
    if (!online()) { toast('Для изменения облачного избранного нужен интернет.', 'error'); return; }
    if (state.favorites.has(track.id)) {
      const { error } = await state.supabase.from('favorites').delete().eq('track_id', track.id);
      if (error) { toast(error.message, 'error'); return; }
      state.favorites.delete(track.id);
    } else {
      const { error } = await state.supabase.from('favorites').insert({ user_id: state.user.id, track_id: track.id });
      if (error) { toast(error.message, 'error'); return; }
      state.favorites.add(track.id);
    }
  }
  if (!isLocal(track) && state.supabase) await saveCloudSnapshot();
  updatePlayerUI(); render();
}

function openModal(content) {
  $('#modal-root').innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="modal-card" role="dialog" aria-modal="true">${content}</section></div>`;
}
function closeModal() { $('#modal-root').innerHTML = ''; }
function modalHeader(title) { return `<div class="modal-top"><h2>${escapeHtml(title)}</h2><button class="modal-close" data-action="close-modal" aria-label="Закрыть"><svg><use href="#i-close"/></svg></button></div>`; }

function openLocalImport() {
  openModal(`${modalHeader('Добавить музыку')}<p class="muted-line">Выбери аудиофайлы в памяти Android. Они сохранятся в RED MUSIC на этом устройстве и будут доступны без интернета.</p><form id="local-import-form"><label class="file-drop"><strong>Выбрать песни</strong><small>MP3 · WAV · M4A · AAC · OGG · FLAC и другие форматы браузера</small><input id="local-files" type="file" accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus,.webm" multiple required></label><p id="local-file-count" class="form-note">Файлы не отправляются в облако.</p><button class="primary-button full-width" type="submit">Сохранить на телефоне</button></form>`);
  $('#local-files').addEventListener('change', (event) => {
    $('#local-file-count').textContent = `${event.target.files.length} файл(ов) выбрано. Будут сохранены локально.`;
  });
}

function openCloudUpload() {
  if (!state.user || !state.supabase) { toast('Сначала войди в аккаунт Supabase.'); navTo('profile'); return; }
  if (!online()) { toast('Загрузка в облако требует интернета.', 'error'); return; }
  openModal(`${modalHeader('Загрузить в облако')}<form id="cloud-upload-form">
    <label class="file-drop"><strong>Аудиофайл</strong><small>До 100 МБ · MP3, WAV, M4A и другие форматы</small><input id="cloud-audio-file" name="audio" type="file" accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus,.webm" required></label>
    <div class="field"><label for="cloud-title">Название песни</label><input id="cloud-title" name="title" placeholder="Например, Моя песня" required></div>
    <div class="field"><label for="cloud-artist">Исполнитель</label><input id="cloud-artist" name="artist" placeholder="Неизвестный исполнитель"></div>
    <div class="field"><label for="cloud-cover">Обложка (необязательно)</label><input id="cloud-cover" name="cover" type="file" accept="image/jpeg,image/png,image/webp"></div>
    <div class="field"><label for="cloud-visibility">Доступ</label><select id="cloud-visibility" name="visibility"><option value="private">Личный — только я</option><option value="public">Публичный — доступен всем пользователям RED MUSIC</option></select></div>
    <div class="progress-wrap hidden" id="upload-progress-wrap"><div class="progress-bar" id="upload-progress"></div></div><div class="progress-caption"><span id="upload-status">Файл ещё не загружен</span><span id="upload-percent">0%</span></div>
    <button class="primary-button full-width" id="upload-submit" type="submit" style="margin-top:14px">Загрузить песню</button>
  </form><p class="form-note">Публичность относится к конкретному треку. Чужие приватные загрузки не будут видны.</p>`);
  $('#cloud-audio-file').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file && !$('#cloud-title').value) $('#cloud-title').value = titleFromFilename(file.name);
  });
}

function openCreatePlaylist() {
  if (!state.user) { toast('Войди, чтобы создавать облачные плейлисты.'); navTo('profile'); return; }
  if (!online()) { toast('Создание облачного плейлиста требует интернета.', 'error'); return; }
  openModal(`${modalHeader('Новый плейлист')}<form id="playlist-create-form"><div class="field"><label for="playlist-name">Название</label><input id="playlist-name" name="name" maxlength="60" placeholder="Например, Любимые треки" required></div><button class="primary-button full-width" type="submit">Создать плейлист</button></form>`);
}
function openRenamePlaylist(id) {
  const playlist = state.playlists.find((p) => p.id === id);
  if (!playlist) return;
  openModal(`${modalHeader('Переименовать плейлист')}<form id="playlist-rename-form" data-id="${id}"><div class="field"><label for="playlist-new-name">Новое название</label><input id="playlist-new-name" name="name" maxlength="60" value="${escapeHtml(playlist.name)}" required></div><button class="primary-button full-width" type="submit">Сохранить</button></form>`);
}
function openAddToPlaylist(trackId) {
  if (!state.user) { toast('Войди, чтобы добавлять треки в облачные плейлисты.'); return; }
  const cloudTrack = state.cloudTracks.find((track) => track.id === trackId);
  if (!cloudTrack) { toast('В облачные плейлисты можно добавлять облачные треки.'); return; }
  if (!state.playlists.length) { toast('Сначала создай плейлист.'); return; }
  openModal(`${modalHeader('Добавить в плейлист')}<div class="queue-list">${state.playlists.map((p) => `<button class="playlist-card" data-action="confirm-add-playlist" data-playlist-id="${p.id}" data-track-id="${trackId}"><span class="playlist-art"><svg><use href="#i-list"/></svg></span><span class="playlist-copy"><strong>${escapeHtml(p.name)}</strong><small>Добавить песню</small></span><span>＋</span></button>`).join('')}</div>`);
}
function openQueue() {
  const queue = state.queue.map(getTrack).filter(Boolean);
  openModal(`${modalHeader('Очередь воспроизведения')}<p class="muted-line">${queue.length} песен в очереди</p><div class="queue-list">${queue.map((track,index)=>`<div class="queue-row ${index===state.queueIndex?'current':''}"><span>${index+1}</span><strong>${escapeHtml(track.title)}</strong><small>${escapeHtml(track.artist || '')}</small></div>`).join('') || '<p class="muted-line">Очередь пуста</p>'}</div>`);
}

function validateAudioFile(file) {
  if (!file) throw new Error('Выбери аудиофайл.');
  if (file.size > MAX_AUDIO_BYTES) throw new Error('Файл больше 100 МБ. Уменьши размер и попробуй снова.');
  const ext = file.name.split('.').pop().toLowerCase();
  const allowed = ['mp3','wav','m4a','aac','ogg','oga','flac','opus','webm','mp4'];
  if (!file.type.startsWith('audio/') && !allowed.includes(ext)) throw new Error('Похоже, это не аудиофайл.');
  return ext;
}
function mimeForExtension(ext) {
  return ({ mp3:'audio/mpeg', wav:'audio/wav', m4a:'audio/mp4', mp4:'audio/mp4', aac:'audio/aac', ogg:'audio/ogg', oga:'audio/ogg', flac:'audio/flac', opus:'audio/opus', webm:'audio/webm' })[ext] || 'audio/mpeg';
}
function readDuration(file) {
  return new Promise((resolve) => {
    const tempUrl = URL.createObjectURL(file);
    const probe = new Audio();
    probe.preload = 'metadata';
    probe.onloadedmetadata = () => { const d = Number.isFinite(probe.duration) ? Math.round(probe.duration) : null; URL.revokeObjectURL(tempUrl); resolve(d); };
    probe.onerror = () => { URL.revokeObjectURL(tempUrl); resolve(null); };
    probe.src = tempUrl;
  });
}

async function importLocalFiles(files) {
  let count = 0;
  for (const file of files) {
    validateAudioFile(file);
    const id = `local:${crypto.randomUUID()}`;
    const duration = await readDuration(file);
    const record = {
      id, title: titleFromFilename(file.name), artist: 'Неизвестный исполнитель',
      duration, file_name: file.name, mime_type: file.type || mimeForExtension(file.name.split('.').pop().toLowerCase()),
      size: file.size, blob: file, cover_url: null, is_local: true,
      created_at: new Date().toISOString()
    };
    await localPut(record);
    state.localTracks.unshift({ ...record, offline: true });
    count++;
  }
  closeModal(); render(); toast(`Добавлено на устройство: ${count} песен.`);
}

function xhrStorageUpload(file, path, onProgress, contentTypeOverride = null) {
  return new Promise(async (resolve, reject) => {
    try {
      const { data, error } = await state.supabase.auth.getSession();
      if (error) throw error;
      const token = data.session?.access_token;
      if (!token) throw new Error('Сессия истекла. Войди в аккаунт ещё раз.');
      const encodedPath = path.split('/').map(encodeURIComponent).join('/');
      const url = `${CONFIG.SUPABASE_URL.replace(/\/$/, '')}/storage/v1/object/${BUCKET}/${encodedPath}`;
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.setRequestHeader('apikey', CONFIG.SUPABASE_ANON_KEY);
      xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.setRequestHeader('Content-Type', contentTypeOverride || file.type || 'application/octet-stream');
      xhr.setRequestHeader('x-upsert', 'false');
      xhr.upload.onprogress = (event) => { if (event.lengthComputable) onProgress(Math.round(event.loaded / event.total * 100)); };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) resolve(JSON.parse(xhr.responseText || '{}'));
        else {
          let message = `Storage вернул ${xhr.status}`;
          try { message = JSON.parse(xhr.responseText).message || JSON.parse(xhr.responseText).error || message; } catch {}
          reject(new Error(message));
        }
      };
      xhr.onerror = () => reject(new Error('Сетевая ошибка во время загрузки файла.'));
      xhr.onabort = () => reject(new Error('Загрузка отменена.'));
      xhr.send(file);
    } catch (error) { reject(error); }
  });
}

async function cloudUpload(form) {
  if (!state.user || !online()) throw new Error('Для облачной загрузки нужен вход и интернет.');
  const audioFile = $('#cloud-audio-file').files[0];
  const coverFile = $('#cloud-cover').files[0] || null;
  const title = $('#cloud-title').value.trim();
  const artist = $('#cloud-artist').value.trim() || 'Неизвестный исполнитель';
  const visibility = $('#cloud-visibility').value;
  const ext = validateAudioFile(audioFile);
  if (!title) throw new Error('Укажи название песни.');
  if (coverFile && !['image/jpeg','image/png','image/webp'].includes(coverFile.type)) throw new Error('Обложка должна быть JPG, PNG или WEBP.');
  if (coverFile && coverFile.size > 5 * 1024 * 1024) throw new Error('Обложка больше 5 МБ.');
  const userId = state.user.id;
  const tokenPart = crypto.randomUUID();
  const audioPath = `${userId}/${tokenPart}.${ext}`;
  const duration = await readDuration(audioFile);
  const audioMime = audioFile.type || mimeForExtension(ext);
  let coverPath = null;
  const progressWrap = $('#upload-progress-wrap');
  progressWrap.classList.remove('hidden');
  const submit = $('#upload-submit'); setBusy(submit, true, 'Загружаю…');
  try {
    $('#upload-status').textContent = 'Загружаю аудио…';
    await xhrStorageUpload(audioFile, audioPath, (percent) => {
      $('#upload-progress').style.width = `${percent}%`;
      $('#upload-percent').textContent = `${percent}%`;
    }, audioMime);
    if (coverFile) {
      $('#upload-status').textContent = 'Загружаю обложку…';
      $('#upload-progress').style.width = '0%'; $('#upload-percent').textContent = '0%';
      const coverExt = coverFile.type === 'image/png' ? 'png' : coverFile.type === 'image/webp' ? 'webp' : 'jpg';
      coverPath = `${userId}/covers/${tokenPart}.${coverExt}`;
      await xhrStorageUpload(coverFile, coverPath, (percent) => {
        $('#upload-progress').style.width = `${percent}%`;
        $('#upload-percent').textContent = `${percent}%`;
      }, coverFile.type);
    }
    $('#upload-status').textContent = 'Сохраняю информацию о песне…';
    const { error } = await state.supabase.from('tracks').insert({
      owner_id: userId, title, artist, duration, storage_path: audioPath,
      cover_path: coverPath, mime_type: audioMime,
      file_size: audioFile.size, visibility
    });
    if (error) throw error;
    closeModal();
    toast('Песня загружена в RED MUSIC.');
    await loadCloudData();
  } catch (error) {
    // Если запись метаданных не создалась, удаляем уже загруженные файлы.
    try { await state.supabase.storage.from(BUCKET).remove([audioPath, ...(coverPath ? [coverPath] : [])]); } catch {}
    throw error;
  } finally { setBusy(submit, false); }
}

async function createPlaylist(name) {
  const { data, error } = await state.supabase.from('playlists').insert({ user_id: state.user.id, name }).select().single();
  if (error) throw error;
  state.playlists.unshift(data); closeModal(); render(); toast('Плейлист создан.');
}
async function addTrackToPlaylist(playlistId, trackId) {
  const { error } = await state.supabase.from('playlist_tracks').insert({ playlist_id: playlistId, track_id: trackId, position: state.playlistRows.filter((r) => r.playlist_id === playlistId).length });
  if (error && error.code !== '23505') throw error;
  await loadCloudData(); closeModal(); toast(error ? 'Этот трек уже есть в плейлисте.' : 'Трек добавлен в плейлист.');
}
async function deleteTrack(track) {
  if (!confirm(`Удалить «${track.title}»?`)) return;
  if (isLocal(track)) {
    await localDelete(track.id);
    state.localTracks = state.localTracks.filter((item) => item.id !== track.id);
    state.localFavorites.delete(track.id);
    await metaPut('local_favorites', [...state.localFavorites]);
    state.recentLocal = state.recentLocal.filter((id) => id !== track.id);
    await metaPut('local_recent', state.recentLocal);
  } else {
    if (track.owner_id !== state.user?.id) { toast('Удалить можно только свою песню.', 'error'); return; }
    const { error } = await state.supabase.from('tracks').delete().eq('id', track.id);
    if (error) { toast(error.message, 'error'); return; }
    const paths = [track.storage_path, track.cover_path].filter(Boolean);
    if (paths.length) await state.supabase.storage.from(BUCKET).remove(paths);
    state.cloudTracks = state.cloudTracks.filter((item) => item.id !== track.id);
    state.favorites.delete(track.id);
    await offlineDelete(track.id);
  }
  if (state.currentTrackId === track.id) { audio.pause(); audio.removeAttribute('src'); state.currentTrackId = null; state.isPlaying = false; }
  toast('Песня удалена.'); render();
}

function openTrackMenu(track) {
  const options = [
    `<button class="secondary-button full-width" data-action="add-to-playlist" data-id="${escapeHtml(track.id)}">Добавить в плейлист</button>`,
    track.owner_id === state.user?.id || isLocal(track) ? `<button class="danger-button full-width" data-action="delete-track" data-id="${escapeHtml(track.id)}">Удалить песню</button>` : ''
  ].join('');
  openModal(`${modalHeader('Действия с треком')}<div class="profile-card">${trackArt(track,'track-art')}<div><strong>${escapeHtml(track.title)}</strong><p>${escapeHtml(track.artist || '')}</p></div></div><div class="account-actions">${options}</div>`);
}

// Навигация и клики по элементам списка.
document.addEventListener('click', async (event) => {
  const tabButton = event.target.closest('[data-tab]');
  if (tabButton) { navTo(tabButton.dataset.tab); return; }
  const filterButton = event.target.closest('[data-filter]');
  if (filterButton) { state.libraryFilter = filterButton.dataset.filter; render(); return; }
  const actionButton = event.target.closest('[data-action]');
  if (!actionButton) return;
  const { action, id } = actionButton.dataset;
  try {
    if (action === 'play') await playTrack(id);
    else if (action === 'favorite') await toggleFavorite(getTrack(id));
    else if (action === 'offline') await saveOffline(getTrack(id));
    else if (action === 'import-local') openLocalImport();
    else if (action === 'upload-cloud') openCloudUpload();
    else if (action === 'create-playlist') openCreatePlaylist();
    else if (action === 'open-favorites') { state.tab='library'; state.libraryFilter='favorites'; render(); }
    else if (action === 'open-offline') { state.tab='library'; state.libraryFilter='offline'; render(); }
    else if (action === 'open-playlist') { state.selectedPlaylist=id; render(); }
    else if (action === 'back-playlists') { state.selectedPlaylist=null; render(); }
    else if (action === 'rename-playlist') openRenamePlaylist(id);
    else if (action === 'delete-playlist') {
      if (!confirm('Удалить этот плейлист? Песни в библиотеке останутся.')) return;
      const { error } = await state.supabase.from('playlists').delete().eq('id', id);
      if (error) throw error;
      state.playlists = state.playlists.filter((p)=>p.id!==id);
      state.playlistRows = state.playlistRows.filter((r)=>r.playlist_id!==id);
      render(); toast('Плейлист удалён.');
    }
    else if (action === 'play-playlist') {
      const rows = state.playlistRows.filter((r)=>r.playlist_id===id).sort((a,b)=>(a.position||0)-(b.position||0));
      const tracks = rows.map((r)=>getTrack(r.track_id)).filter(Boolean);
      if (tracks.length) await playTrack(tracks[0], tracks); else toast('В этом плейлисте пока нет доступных треков.');
    }
    else if (action === 'add-track-playlist') {
      const available = state.cloudTracks.filter((t)=>t.owner_id===state.user?.id || t.visibility==='public');
      if (!available.length) { toast('Сначала добавь облачные песни.'); return; }
      openModal(`${modalHeader('Добавить песни')}<p class="muted-line">Нажми на песню, чтобы добавить её в плейлист.</p><div class="queue-list">${available.map((t)=>`<button class="playlist-card" data-action="confirm-add-playlist" data-playlist-id="${id}" data-track-id="${t.id}">${trackArt(t,'track-art')}<span class="playlist-copy"><strong>${escapeHtml(t.title)}</strong><small>${escapeHtml(t.artist||'')}</small></span><span>＋</span></button>`).join('')}</div>`);
    }
    else if (action === 'confirm-add-playlist') await addTrackToPlaylist(actionButton.dataset.playlistId, actionButton.dataset.trackId);
    else if (action === 'add-to-playlist') openAddToPlaylist(id);
    else if (action === 'delete-track') { closeModal(); await deleteTrack(getTrack(id)); }
    else if (action === 'track-more') openTrackMenu(getTrack(id));
    else if (action === 'auth-mode') { state.authMode=actionButton.dataset.mode; render(); }
    else if (action === 'close-modal') { if (event.target === actionButton || actionButton.classList.contains('modal-close')) closeModal(); }
    else if (action === 'refresh-cloud') await loadCloudData();
    else if (action === 'signout') {
      if (state.supabase) { const { error } = await state.supabase.auth.signOut(); if (error) throw error; }
      state.user=null; state.cloudTracks=[]; state.favorites.clear(); state.playlists=[]; state.playlistRows=[]; render(); toast('Ты вышел из аккаунта.');
    }
    else if (action === 'install-app') {
      if (state.installPrompt) { state.installPrompt.prompt(); await state.installPrompt.userChoice; state.installPrompt=null; }
      else toast('В Chrome нажми ⋮ → «Установить приложение» или «Добавить на главный экран».');
    }
  } catch (error) { console.error(error); toast(error.message || 'Что-то пошло не так.', 'error'); }
});

screen.addEventListener('input', (event) => {
  if (event.target.id === 'search-input') {
    state.search = event.target.value;
    const q = state.search.trim().toLowerCase();
    const results = q ? getAllTracks().filter((track)=>`${track.title} ${track.artist||''}`.toLowerCase().includes(q)) : [];
    $('#search-results').innerHTML = q
      ? `<div class="section-heading"><h2>Результаты</h2><span class="muted-line">${results.length}</span></div>${renderTrackList(results,{emptyTitle:'Ничего не найдено',emptyText:'Попробуй другое название.'})}`
      : `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-search"/></svg></div><h3>Ищи среди своих треков</h3><p>Сначала добавь музыку с телефона или загрузи песни в облачную библиотеку.</p><button class="secondary-button" data-tab="library">Открыть мою музыку</button></div>`;
  }
});

document.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.target;
  const submit = $('button[type="submit"]', form);
  try {
    if (form.id === 'auth-form') {
      const email = $('#auth-email').value.trim();
      const password = $('#auth-password').value;
      setBusy(submit, true);
      const result = state.authMode === 'login'
        ? await state.supabase.auth.signInWithPassword({ email, password })
        : await state.supabase.auth.signUp({ email, password, options: { data: { display_name: email.split('@')[0] }, emailRedirectTo: `${location.origin}${location.pathname}` } });
      if (result.error) throw result.error;
      if (state.authMode === 'signup' && !result.data.session) toast('Аккаунт создан. Подтверди почту по ссылке из письма, затем войди.');
      else toast(state.authMode === 'login' ? 'Вход выполнен.' : 'Аккаунт создан.');
      state.user = result.data.session?.user || null;
      if (state.supabase && online()) await loadCloudData();
      render();
    } else if (form.id === 'local-import-form') {
      const files = [...$('#local-files').files];
      if (!files.length) throw new Error('Выбери хотя бы один файл.');
      setBusy(submit, true, 'Сохраняю…');
      await importLocalFiles(files);
    } else if (form.id === 'cloud-upload-form') {
      await cloudUpload(form);
    } else if (form.id === 'playlist-create-form') {
      const name = $('#playlist-name').value.trim();
      if (!name) throw new Error('Укажи название плейлиста.');
      setBusy(submit,true,'Создаю…'); await createPlaylist(name);
    } else if (form.id === 'playlist-rename-form') {
      const name = $('#playlist-new-name').value.trim();
      if (!name) throw new Error('Укажи название.');
      setBusy(submit,true,'Сохраняю…');
      const { data, error } = await state.supabase.from('playlists').update({name}).eq('id',form.dataset.id).select().single();
      if (error) throw error;
      state.playlists = state.playlists.map((p)=>p.id===data.id?data:p); closeModal(); render(); toast('Название обновлено.');
    }
  } catch (error) { console.error(error); toast(error.message || 'Ошибка. Проверь подключение и настройки.', 'error'); }
  finally { if (submit && document.body.contains(submit)) setBusy(submit,false); }
});

// Плеер.
$('#mini-open').addEventListener('click', showPlayer);
$('#mini-play').addEventListener('click', togglePlay);
$('#mini-prev').addEventListener('click', playPrevious);
$('#mini-next').addEventListener('click', playNext);
$('#avatar-button').addEventListener('click', () => navTo('profile'));
$('#player-close').addEventListener('click', hidePlayer);
$('#player-queue').addEventListener('click', openQueue);
$('#main-play').addEventListener('click', togglePlay);
$('#previous').addEventListener('click', playPrevious);
$('#next').addEventListener('click', playNext);
$('#shuffle').addEventListener('click', toggleShuffle);
$('#repeat').addEventListener('click', () => { state.repeat = state.repeat==='off'?'all':state.repeat==='all'?'one':'off'; updatePlayerUI(); toast(state.repeat==='off'?'Повтор выключен':state.repeat==='all'?'Повтор всей очереди':'Повтор одного трека'); });
$('#player-favorite').addEventListener('click', () => toggleFavorite(getTrack(state.currentTrackId)));
$('#save-offline').addEventListener('click', () => saveOffline(getTrack(state.currentTrackId)));
$('#seek').addEventListener('input', (event) => { if (audio.duration) audio.currentTime = (Number(event.target.value)/1000)*audio.duration; });
$('#volume').addEventListener('input', (event) => { audio.volume = Number(event.target.value); });
audio.volume = 0.85;
audio.addEventListener('timeupdate', () => {
  if (audio.duration) $('#seek').value = Math.round((audio.currentTime/audio.duration)*1000);
  $('#current-time').textContent = fmtTime(audio.currentTime);
  if ('mediaSession' in navigator && audio.duration && navigator.mediaSession.setPositionState) {
    try { navigator.mediaSession.setPositionState({ duration: audio.duration, playbackRate: audio.playbackRate, position: audio.currentTime }); } catch {}
  }
});
audio.addEventListener('loadedmetadata', async () => {
  const track = getTrack(state.currentTrackId);
  if (track && !track.duration && Number.isFinite(audio.duration)) {
    track.duration = Math.round(audio.duration);
    if (!isLocal(track) && state.user && track.owner_id===state.user.id && online()) {
      await state.supabase.from('tracks').update({duration:track.duration}).eq('id',track.id);
    }
  }
  updatePlayerUI();
});
audio.addEventListener('play', () => { state.isPlaying=true; updatePlayerUI(); updateMiniPlayer(); if ('mediaSession' in navigator) navigator.mediaSession.playbackState='playing'; });
audio.addEventListener('pause', () => { state.isPlaying=false; updatePlayerUI(); updateMiniPlayer(); if ('mediaSession' in navigator) navigator.mediaSession.playbackState='paused'; });
audio.addEventListener('ended', async () => {
  if (state.repeat === 'one') { audio.currentTime=0; audio.play(); }
  else await playNext();
});
audio.addEventListener('error', () => {
  if (state.currentTrackId) toast('Не удалось воспроизвести файл. Возможно, формат или кодек не поддерживается браузером.', 'error');
});
$('#player-overlay').addEventListener('click', (event) => { if (event.target === $('#player-overlay')) hidePlayer(); });
document.addEventListener('keydown', (event) => { if (event.key==='Escape') { hidePlayer(); closeModal(); } });

window.addEventListener('online', async () => { updateConnection(); toast('Интернет подключён.'); if (state.user) await loadCloudData(); });
window.addEventListener('offline', () => { updateConnection(); toast('Ты офлайн. Доступны локальные и заранее сохранённые песни.'); });
window.addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); state.installPrompt=event; });

async function start() {
  try {
    state.db = await openDatabase();
    await loadDeviceData();
    await initSupabase();
    if (state.supabase && online()) await loadCloudData();
    else if (state.supabase) await loadCachedCloudData();
  } catch (error) {
    console.error(error);
    toast(error.message || 'Не удалось запустить локальную библиотеку.', 'error');
  }
  updateConnection();
  render();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('./sw.js').then(async (registration) => {
      const ready = await navigator.serviceWorker.ready;
      (ready.active || registration.active)?.postMessage({
        type: 'CACHE_SDK',
        url: 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2'
      });
    }).catch((error) => console.warn('Service worker:', error));
  }
}
start();
