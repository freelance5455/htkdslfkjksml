class ChatMessageData {
  ChatMessageData({required this.role, required this.text, required this.createdAt});

  final String role;
  final String text;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'createdAt': createdAt.toIso8601String(),
      };

  factory ChatMessageData.fromJson(Map<String, dynamic> json) => ChatMessageData(
        role: json['role'] as String? ?? 'user',
        text: json['text'] as String? ?? '',
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      );
}

class ChatThread {
  ChatThread({
    required this.id,
    required this.title,
    required this.messages,
    required this.updatedAt,
    this.saved = false,
  });

  final String id;
  String title;
  final List<ChatMessageData> messages;
  DateTime updatedAt;
  bool saved;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'saved': saved,
        'updatedAt': updatedAt.toIso8601String(),
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  factory ChatThread.fromJson(Map<String, dynamic> json) => ChatThread(
        id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: json['title'] as String? ?? 'New conversation',
        saved: json['saved'] as bool? ?? false,
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
        messages: ((json['messages'] as List?) ?? [])
            .whereType<Map>()
            .map((m) => ChatMessageData.fromJson(Map<String, dynamic>.from(m)))
            .toList(),
      );
}
