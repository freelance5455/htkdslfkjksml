CONFIG_KEYS="AUTO_RENDER GAME_RENDERER NORMAL_RENDERER"

is_config_key() {
    case " $CONFIG_KEYS " in
        *" $1 "*) return 0 ;;
    esac
    return 1
}

PROPS='
debug.hwui.render_thread|true|hilo de render dedicado de hwui|true,false
debug.skia.threaded|true|ejecuta skia en varios hilos|true,false
debug.cpurend.disable|1|desactiva el render por cpu|1,0
debug.hwui.vulkan.use_pipeline_cache|true|cachea los pipelines compilados|true,false
debug.hwui.vulkan.enable_shared_image|true|comparte imagenes entre gpu y cpu|true,false
debug.hwui.use_vulkan_texture_filtering|true|filtrado de texturas via vulkan|true,false
debug.hwui.fbpipeline|true|pipeline de framebuffer optimizado|true,false
debug.hwui.use_gpu_pixel_buffers|true|buffers de pixel reservados en gpu|true,false
debug.hwui.skip_empty_damage|true|salta regiones de pantalla sin cambios|true,false
debug.hwui.use_buffer_age|true|reutiliza el buffer de edad|true,false
debug.hwui.webview_overlays_enabled|true|acelera los overlays de webview con gpu|true,false
sys.use_fifo_ui|true|scheduler fifo para la ui|true,false
renderthread.skia.reduceopstasksplitting|true|parte menos tareas en skia|true,false
debug.vulkan.frame.pacing|1|sincronizacion de frames de vulkan|1,0
debug.vulkan.force_disable_validation_layers|true|evita las capas de validacion|true,false
vulkan.pipeline_cache.enabled|true|cache global de pipelines de vulkan|true,false
debug.perf.vulkan.use_gpu_memcpy|1|copias de memoria aceleradas por gpu|1,0
debug.perf.vulkan.enable_robustness|0|desactiva la robustez de vulkan|1,0
debug.renderengine.vulkan.disable_vblank_wait|true|no espera al vblank (menos latencia)|true,false
debug.composition.type|gpu|compone la pantalla por gpu|gpu,dyn,mdp
persist.sys.composition.type|gpu|composicion por gpu persistente|gpu,dyn,mdp
debug.renderengine.backend|skiavk|backend del compositor (renderengine)|skiavk,skiagl,skiaglthreaded,skiavkthreaded,threaded
debug.hwui.initialize_gl_always|false|inicializa opengl aunque hwui use vulkan|true,false
debug.egl.hw|1|fuerza el render egl por hardware|1,0
persist.sys.force_sw_gles|0|fuerza opengl es por software|0,1
debug.sf.latch_unsignaled|1|entrega frames sin esperar la senal|1,0
debug.hwui.use_hint_manager|true|hints de memoria para el planificador de cpu|true,false
debug.hwui.skia_tracing_enabled|false|tracing de skia (solo depuracion)|true,false
ro.hwui.texture_cache_size|88|cache de texturas de hwui (mb)|8,16,24,32,40,48,56,64,72,80,88,96
ro.hwui.layer_cache_size|64|cache de capas de hwui (mb)|8,16,24,32,40,48,56,64
ro.hwui.r_buffer_cache_size|40|cache de buffers de render (mb)|8,16,24,32,40,48
ro.hwui.path_cache_size|42|cache de recorridos / paths (mb)|8,16,24,32,40,48
ro.hwui.font_cache_size|16|cache de fuentes de hwui (mb)|2,4,8,12,16,24
ro.hwui.gradient_cache_size|8|cache de degradados (mb)|1,2,4,8,16
ro.hwui.drop_shadow_cache_size|8|cache de sombras (mb)|1,2,4,8,16
debug.renderengine.blur_algorithm|none|algoritmo de blur entre ventanas (none = sin blur)|none,gaussian,kawase,kawase_dual_filterer
debug.sf.set_idle_timer_ms|0|ms antes de bajar el refresco en reposo (0 = nunca)|0,1000,2000,4000,6000
debug.sf.early_phase_offset_ns|0|fase de wakeup de surfaceflinger vs vsync (ns)|-2000000,-1000000,0,1000000,2000000
debug.sf.early_app_phase_offset_ns|0|fase de wakeup de las apps vs vsync (ns)|-2000000,-1000000,0,1000000,2000000
debug.gr.swapinterval|0|intervalo de swap de gralloc (0 = desbloquea el fps)|0,1
debug.hwui.use_partial_updates|true|redibujado parcial de la superficie|true,false
debug.hwui.target_cpu_time_percent|90|% del tiempo de frame dedicado a cpu (el resto a gpu)|70,80,90,100
debug.hwui.8bit_hdr_headroom|0|headroom hdr en pantallas de 8 bits (0 = apagado)|0,50,100,200,400
ro.surface_flinger.supports_background_blur|0|blur de fondo del sistema (0 = apagado)|0,1
'

RESETPROP=""
if command -v resetprop >/dev/null 2>&1; then
    RESETPROP="resetprop"
elif [ -x /data/adb/magisk/resetprop ]; then
    RESETPROP="/data/adb/magisk/resetprop"
elif [ -x /data/adb/ksu/bin/resetprop ]; then
    RESETPROP="/data/adb/ksu/bin/resetprop"
fi

GP=""
if command -v getprop >/dev/null 2>&1; then
    GP="getprop"
elif [ -x /system/bin/getprop ]; then
    GP="/system/bin/getprop"
elif [ -x /system/bin/toybox ]; then
    GP="/system/bin/toybox getprop"
elif [ -x /system/xbin/toybox ]; then
    GP="/system/xbin/toybox getprop"
fi

get_prop() {
    if [ -z "$GP" ] || [ -z "$1" ]; then
        return 0
    fi
    $GP "$1" 2>/dev/null
}

PROP_BACKUP="$MODDIR/props_backup"

backup_prop() {
    local name="$1" cur=""
    [ -z "$name" ] && return 0
    [ -f "$PROP_BACKUP" ] || : > "$PROP_BACKUP" 2>/dev/null
    grep -q "^$name=" "$PROP_BACKUP" 2>/dev/null && return 0
    cur=$(get_prop "$name")
    echo "$name=$cur" >> "$PROP_BACKUP" 2>/dev/null
}

set_prop() {
    [ -z "$1" ] && return 1
    backup_prop "$1"
    if [ -n "$RESETPROP" ]; then
        "$RESETPROP" "$1" "$2" 2>/dev/null
    else
        setprop "$1" "$2" 2>/dev/null
    fi
}

clear_prop() {
    [ -z "$1" ] && return 1
    if [ -n "$RESETPROP" ]; then
        "$RESETPROP" --delete "$1" 2>/dev/null || "$RESETPROP" -d "$1" 2>/dev/null
    fi
}

cfg_value() {
    local line=""
    line=$(grep -E "^$1=" "$CONFIG" 2>/dev/null | tail -n 1)
    [ -z "$line" ] && return 0
    echo "${line#*=}"
}

set_key() {
    local key="$1" value="$2" ln="" got="" found=0
    local tmp="$CONFIG.tmp"
    : > "$tmp" || { echo "FALLO escribiendo $key=$value: no se puede escribir (solo lectura?)"; return 1; }
    while IFS= read -r ln; do
        case "$ln" in
            "$key"=*)
                if [ "$value" != "-" ]; then
                    echo "$key=$value" >> "$tmp"
                fi
                found=1
                ;;
            *)
                echo "$ln" >> "$tmp"
                ;;
        esac
    done < "$CONFIG" 2>/dev/null
    if [ "$found" = "0" ] && [ "$value" != "-" ]; then
        echo "$key=$value" >> "$tmp"
    fi
    if mv "$tmp" "$CONFIG" 2>/dev/null; then
        :
    else
        rm -f "$tmp" 2>/dev/null
        echo "FALLO escribiendo $key=$value: no se pudo reemplazar $CONFIG"
        return 1
    fi
    got=$(grep -E "^$key=" "$CONFIG" 2>/dev/null | tail -n 1)
    if [ "$value" = "-" ]; then
        if [ -z "$got" ]; then
            echo "OK: $key=- (eliminada)"
        else
            echo "FALLO eliminando $key -> [$got]"
        fi
    elif [ "$got" = "$key=$value" ]; then
        echo "OK: $key=$value"
    else
        echo "FALLO escribiendo $key=$value -> [$got]"
    fi
}

apply_single() {
    local key="$1" value="$2"
    if is_config_key "$key"; then
        return 0
    fi
    case "$value" in
        -) clear_prop "$key" ;;
        "") : ;;
        *) set_prop "$key" "$value" ;;
    esac
}

apply_all() {
    local name="" val="" n=0
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        name="${line%%|*}"
        val=$(cfg_value "$name")
        [ -z "$val" ] && continue
        if [ "$val" = "-" ]; then
            clear_prop "$name"
        else
            set_prop "$name" "$val"
        fi
        n=$((n+1))
    done <<EOF
$PROPS
EOF
    APPLIED_N="$n"
}

apply_render_mode() {
    local mode="$1" sel=""
    if [ "$mode" = "game" ]; then
        sel=$(cfg_value GAME_RENDERER)
        [ -z "$sel" ] && sel=vulkanskia
        case "$sel" in
            vulkan)
                set_prop debug.hwui.renderer vulkan
                set_prop ro.hwui.use_vulkan true
                ;;
            *)
                set_prop debug.hwui.renderer skiavk
                set_prop ro.hwui.use_vulkan true
                ;;
        esac
    else
        sel=$(cfg_value NORMAL_RENDERER)
        [ -z "$sel" ] && sel=skiagl
        case "$sel" in
            opengl)
                set_prop debug.hwui.renderer opengl
                set_prop ro.hwui.use_vulkan false
                ;;
            *)
                set_prop debug.hwui.renderer skiagl
                set_prop ro.hwui.use_vulkan false
                ;;
        esac
    fi
}

prop_state() {
    local name="$1" val="" src="unset"
    val=$(get_prop "$name")
    if [ -n "$val" ]; then
        case "$name" in
            persist.*) src="persist" ;;
            *) src="runtime" ;;
        esac
    fi
    echo "$val|$src"
}

current_package() {
    local pkg="" line=""
    line=$(dumpsys window 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -n 1)
    if [ -n "$line" ]; then
        pkg=$(echo "$line" | grep -oE '[a-zA-Z][a-zA-Z0-9_.]+/[a-zA-Z0-9_.]+' | head -n 1 | cut -d'/' -f1)
    fi
    case "$pkg" in
        ""|null|com.android.systemui|com.android.settings|com.android.phone)
            pkg=""
            ;;
        *launcher*|*systemui*|*screenrecorder*|*recorder*)
            pkg=""
            ;;
    esac
    echo "$pkg"
}

is_game() {
    local pkg="$1" g=""
    while IFS= read -r g; do
        [ -z "$g" ] && continue
        case "$g" in \#*) continue ;; esac
        [ "$pkg" = "$g" ] && return 0
    done < "$MODDIR/games.conf" 2>/dev/null
    return 1
}
