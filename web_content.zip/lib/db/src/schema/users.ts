import { pgEnum, pgTable, text, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userRoleEnum = pgEnum("user_role", [
  "PATIENT",
  "DOCTOR",
  "NURSE",
  "SPECIALIST",
  "ADMIN",
]);

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  role: userRoleEnum("role").notNull().default("PATIENT"),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  preferredLanguage: text("preferred_language").notNull().default("fr"),
  birthDate: date("birth_date", { mode: "string" }),
  gender: text("gender"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertUserSchema = createInsertSchema(usersTable);
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
