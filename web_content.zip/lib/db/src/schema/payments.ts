import {
  numeric,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { appointmentsTable } from "./appointments";

export const paymentsTable = pgTable("payments", {
  id: uuid("id").defaultRandom().primaryKey(),
  appointmentId: uuid("appointment_id")
    .notNull()
    .unique()
    .references(() => appointmentsTable.id, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 10, scale: 2, mode: "number" })
    .notNull()
    .default(0),
  currency: text("currency").notNull().default("DZD"),
  status: text("status").notNull().default("PENDING"),
  provider: text("provider").notNull().default("MOCK"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertPaymentSchema = createInsertSchema(paymentsTable);
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type PaymentRecord = typeof paymentsTable.$inferSelect;
