import { relations } from "drizzle-orm";
import {
  boolean,
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  clerkUserId: text("clerk_user_id").notNull().unique(),
  email: text("email"),
  displayName: text("display_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const eventsTable = pgTable("events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  venue: text("venue").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull().default("Kingston"),
  country: text("country").notNull().default("Jamaica"),
  eventDate: timestamp("event_date", { withTimezone: true }).notNull(),
  endDate: timestamp("end_date", { withTimezone: true }).notNull(),
  basePriceJmd: integer("base_price_jmd").notNull(),
  serviceFeeJmd: integer("service_fee_jmd").notNull().default(0),
  doorChargeJmd: integer("door_charge_jmd").notNull().default(0),
  vibeTags: text("vibe_tags").array().notNull().default([]),
  crowdLevel: text("crowd_level").notNull().default("Chill"),
  crowdLabel: text("crowd_label").notNull().default("0–10 people here"),
  rating: real("rating").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  accent: text("accent").notNull().default("#a96cff"),
  mark: text("mark").notNull().default("LIVE"),
  description: text("description").notNull(),
  posterPath: text("poster_path"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  isPublished: boolean("is_published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const savedEventsTable = pgTable(
  "saved_events",
  {
    userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    eventId: integer("event_id").notNull().references(() => eventsTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [unique("saved_events_user_event_unique").on(table.userId, table.eventId)],
);

export const checkinsTable = pgTable(
  "checkins",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    eventId: integer("event_id").notNull().references(() => eventsTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [unique("checkins_user_event_unique").on(table.userId, table.eventId)],
);

export const reviewsTable = pgTable("reviews", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  eventId: integer("event_id").notNull().references(() => eventsTable.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  tag: text("tag"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [unique("reviews_user_event_unique").on(table.userId, table.eventId)]);

export const eventSuggestionsTable = pgTable("event_suggestions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  venue: text("venue").notNull(),
  eventDate: timestamp("event_date", { withTimezone: true }),
  notes: text("notes").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const usersRelations = relations(usersTable, ({ many }) => ({
  savedEvents: many(savedEventsTable),
  checkins: many(checkinsTable),
  reviews: many(reviewsTable),
  eventSuggestions: many(eventSuggestionsTable),
}));

export const eventsRelations = relations(eventsTable, ({ many }) => ({
  savedEvents: many(savedEventsTable),
  checkins: many(checkinsTable),
  reviews: many(reviewsTable),
}));

export const savedEventsRelations = relations(savedEventsTable, ({ one }) => ({
  user: one(usersTable, { fields: [savedEventsTable.userId], references: [usersTable.id] }),
  event: one(eventsTable, { fields: [savedEventsTable.eventId], references: [eventsTable.id] }),
}));

export const checkinsRelations = relations(checkinsTable, ({ one }) => ({
  user: one(usersTable, { fields: [checkinsTable.userId], references: [usersTable.id] }),
  event: one(eventsTable, { fields: [checkinsTable.eventId], references: [eventsTable.id] }),
}));

export const reviewsRelations = relations(reviewsTable, ({ one }) => ({
  user: one(usersTable, { fields: [reviewsTable.userId], references: [usersTable.id] }),
  event: one(eventsTable, { fields: [reviewsTable.eventId], references: [eventsTable.id] }),
}));

export const eventSuggestionsRelations = relations(eventSuggestionsTable, ({ one }) => ({
  user: one(usersTable, { fields: [eventSuggestionsTable.userId], references: [usersTable.id] }),
}));

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertEventSchema = createInsertSchema(eventsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertReviewSchema = createInsertSchema(reviewsTable).omit({ id: true, createdAt: true });
export const insertEventSuggestionSchema = createInsertSchema(eventSuggestionsTable).omit({ id: true, userId: true, createdAt: true });

export type User = typeof usersTable.$inferSelect;
export type Event = typeof eventsTable.$inferSelect;
export type Review = typeof reviewsTable.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type InsertEventSuggestion = z.infer<typeof insertEventSuggestionSchema>;