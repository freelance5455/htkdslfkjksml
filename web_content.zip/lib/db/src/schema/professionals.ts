import { sql } from "drizzle-orm";
import {
  integer,
  numeric,
  pgEnum,
  pgTable,
  text,
  time,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const professionalStatusEnum = pgEnum("professional_status", [
  "PENDING",
  "APPROVED",
  "REJECTED",
]);

export const professionalsTable = pgTable("professionals", {
  userId: text("user_id")
    .primaryKey()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  specialty: text("specialty").notNull(),
  licenseNumber: text("license_number").notNull(),
  experienceYears: integer("experience_years").notNull().default(0),
  languages: text("languages")
    .array()
    .notNull()
    .default(sql`ARRAY[]::text[]`),
  bio: text("bio").notNull().default(""),
  education: text("education")
    .array()
    .notNull()
    .default(sql`ARRAY[]::text[]`),
  certifications: text("certifications")
    .array()
    .notNull()
    .default(sql`ARRAY[]::text[]`),
  consultationPrice: numeric("consultation_price", {
    precision: 10,
    scale: 2,
    mode: "number",
  })
    .notNull()
    .default(0),
  currency: text("currency").notNull().default("DZD"),
  rating: numeric("rating", { precision: 3, scale: 2, mode: "number" })
    .notNull()
    .default(0),
  reviewCount: integer("review_count").notNull().default(0),
  imageUrl: text("image_url"),
  verificationStatus: professionalStatusEnum("verification_status")
    .notNull()
    .default("PENDING"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const availabilityTable = pgTable("availability", {
  id: text("id").primaryKey(),
  professionalId: text("professional_id")
    .notNull()
    .references(() => professionalsTable.userId, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  slotMinutes: integer("slot_minutes").notNull().default(30),
});

export const insertProfessionalSchema = createInsertSchema(professionalsTable);
export type InsertProfessional = z.infer<typeof insertProfessionalSchema>;
export type Professional = typeof professionalsTable.$inferSelect;
export type Availability = typeof availabilityTable.$inferSelect;
