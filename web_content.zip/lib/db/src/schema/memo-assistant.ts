import { boolean, integer, numeric, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const botsTable = pgTable("memo_bots", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  image: text("image"),
  language: text("language").notNull(),
  personality: text("personality").notNull(),
  style: text("style").notNull(),
  platform: text("platform").notNull(),
  status: text("status").notNull().default("draft"),
  messages: integer("messages").notNull().default(0),
  replyRate: numeric("reply_rate").notNull().default("0"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const rulesTable = pgTable("memo_rules", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  botId: text("bot_id").notNull(),
  trigger: text("trigger").notNull(),
  response: text("response").notNull(),
  matches: integer("matches").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const knowledgeTable = pgTable("memo_knowledge", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  botId: text("bot_id").notNull(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const conversationsTable = pgTable("memo_conversations", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  botId: text("bot_id").notNull(),
  platform: text("platform").notNull(),
  preview: text("preview").notNull(),
  status: text("status").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const activityTable = pgTable("memo_activity", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  detail: text("detail").notNull(),
  time: timestamp("time", { withTimezone: true }).notNull().defaultNow(),
  status: text("status").notNull(),
});

export const platformConnectionsTable = pgTable("memo_platform_connections", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  platformId: text("platform_id").notNull(),
  status: text("status").notNull(),
  connectedAt: timestamp("connected_at", { withTimezone: true }),
});

export const settingsTable = pgTable("memo_settings", {
  ownerId: text("owner_id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  language: text("language").notNull().default("ar"),
  emailNotifications: boolean("email_notifications").notNull().default(true),
  securityAlerts: boolean("security_alerts").notNull().default(true),
  aiModel: text("ai_model").notNull().default("memo-smart"),
  retentionDays: integer("retention_days").notNull().default(30),
});

export const insertBotSchema = createInsertSchema(botsTable);
export const insertRuleSchema = createInsertSchema(rulesTable);
export const insertKnowledgeSchema = createInsertSchema(knowledgeTable);
export type Bot = typeof botsTable.$inferSelect;
export type Rule = typeof rulesTable.$inferSelect;
export type KnowledgeEntry = typeof knowledgeTable.$inferSelect;