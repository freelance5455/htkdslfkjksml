import {
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const medicalRecordsTable = pgTable("medical_records", {
  patientId: text("patient_id")
    .primaryKey()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  allergies: text("allergies").notNull().default(""),
  medicalHistory: text("medical_history").notNull().default(""),
  medications: text("medications").notNull().default(""),
  notes: text("notes").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const medicalDocumentsTable = pgTable("medical_documents", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: text("patient_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  objectPath: text("object_path").notNull().unique(),
  name: text("name").notNull(),
  size: integer("size").notNull(),
  contentType: text("content_type").notNull(),
  documentType: text("document_type").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const documentUploadsTable = pgTable("document_uploads", {
  objectPath: text("object_path").primaryKey(),
  ownerId: text("owner_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  size: integer("size").notNull(),
  contentType: text("content_type").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const insertMedicalRecordSchema = createInsertSchema(medicalRecordsTable);
export const insertMedicalDocumentSchema =
  createInsertSchema(medicalDocumentsTable);
export type InsertMedicalRecord = z.infer<typeof insertMedicalRecordSchema>;
export type MedicalRecord = typeof medicalRecordsTable.$inferSelect;
export type MedicalDocument = typeof medicalDocumentsTable.$inferSelect;
export type DocumentUpload = typeof documentUploadsTable.$inferSelect;
