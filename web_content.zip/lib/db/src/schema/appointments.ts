import {
  integer,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { professionalsTable } from "./professionals";
import { usersTable } from "./users";

export const appointmentStatusEnum = pgEnum("appointment_status", [
  "PENDING",
  "CONFIRMED",
  "COMPLETED",
  "CANCELLED",
]);
export const consultationTypeEnum = pgEnum("consultation_type", [
  "VIDEO",
  "AUDIO",
  "CHAT",
]);
export const paymentStatusEnum = pgEnum("payment_status", [
  "PENDING",
  "PAID",
  "REFUNDED",
  "DEMO_PAID",
]);

export const appointmentsTable = pgTable(
  "appointments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    appointmentId: text("appointment_id").notNull().unique(),
    patientId: text("patient_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    professionalId: text("professional_id")
      .notNull()
      .references(() => professionalsTable.userId, { onDelete: "cascade" }),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    durationMinutes: integer("duration_minutes").notNull(),
    consultationType: consultationTypeEnum("consultation_type").notNull(),
    status: appointmentStatusEnum("status").notNull().default("PENDING"),
    amount: numeric("amount", { precision: 10, scale: 2, mode: "number" })
      .notNull()
      .default(0),
    currency: text("currency").notNull().default("DZD"),
    paymentStatus: paymentStatusEnum("payment_status")
      .notNull()
      .default("PENDING"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    appointmentNumberIdx: uniqueIndex("appointments_appointment_id_idx").on(
      table.appointmentId,
    ),
  }),
);

export const insertAppointmentSchema = createInsertSchema(appointmentsTable);
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointmentsTable.$inferSelect;
