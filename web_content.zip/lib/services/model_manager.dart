import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

class ModelManager {
  static const modelName = 'qwen2.5-0.5b-instruct-q4_k_m.gguf';
  static const modelUrl =
      'https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf';
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(minutes: 0),
    followRedirects: true,
    headers: {'User-Agent': 'MindMate-Local/1.0'},
  ));
  CancelToken? _cancelToken;

  Future<String> modelPath() async {
    final dir = await getApplicationSupportDirectory();
    return '${dir.path}/models/$modelName';
  }

  Future<bool> isDownloaded() async {
    final file = File(await modelPath());
    if (!await file.exists()) return false;
    // Reject interrupted/empty downloads. The selected Q4_K_M artifact is ~491 MB.
    return await file.length() > 100 * 1024 * 1024;
  }

  Future<void> ensureModel({
    required void Function(int received, int total) onProgress,
  }) async {
    if (await isDownloaded()) return;
    final path = await modelPath();
    final file = File(path);
    await file.parent.create(recursive: true);
    final partial = File('$path.part');
    _cancelToken = CancelToken();
    try {
      await _dio.download(
        modelUrl,
        partial.path,
        cancelToken: _cancelToken,
        deleteOnError: true,
        onReceiveProgress: onProgress,
        options: Options(responseType: ResponseType.stream),
      );
      if (!await partial.exists() || await partial.length() < 100 * 1024 * 1024) {
        throw Exception('Downloaded model file is incomplete. Please retry.');
      }
      if (await file.exists()) await file.delete();
      await partial.rename(path);
    } catch (_) {
      if (await partial.exists()) await partial.delete();
      rethrow;
    } finally {
      _cancelToken = null;
    }
  }

  void cancelDownload() => _cancelToken?.cancel('Download cancelled');
}
