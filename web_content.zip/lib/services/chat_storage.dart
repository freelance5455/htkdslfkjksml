import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/chat.dart';

class ChatStorage {
  static const _key = 'mindmate_local_chats_v1';

  Future<List<ChatThread>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List;
      return list.whereType<Map>().map((e) => ChatThread.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> save(List<ChatThread> chats) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(chats.map((c) => c.toJson()).toList()));
  }

  Future<String> exportJson(List<ChatThread> chats) async =>
      const JsonEncoder.withIndent('  ').convert({
        'format': 'mindmate-local-backup',
        'version': 1,
        'exportedAt': DateTime.now().toIso8601String(),
        'chats': chats.map((c) => c.toJson()).toList(),
      });

  Future<List<ChatThread>> parseImport(String jsonText) async {
    final decoded = jsonDecode(jsonText);
    final rawChats = decoded is List ? decoded : (decoded as Map<String, dynamic>)['chats'];
    if (rawChats is! List) throw const FormatException('Backup does not contain a chats list.');
    return rawChats.whereType<Map>()
        .map((e) => ChatThread.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }
}
