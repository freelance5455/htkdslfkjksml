#!/system/bin/sh
MODDIR="${MODDIR:-${0%/*}/..}"
STATE_DIR="/data/local/tmp/TM_Otimizacoes"
STATE_FILE="$STATE_DIR/backup.settings"
mkdir -p "$STATE_DIR" 2>/dev/null || true

backup_setting() {
  table="$1"; key="$2"
  [ -f "$STATE_FILE" ] || : > "$STATE_FILE"
  grep -Fq "^S|$table|$key|" "$STATE_FILE" 2>/dev/null && return 0
  val="$(settings get "$table" "$key" 2>/dev/null)"
  printf 'S|%s|%s|%s\n' "$table" "$key" "$val" >> "$STATE_FILE"
}

set_setting() {
  table="$1"; key="$2"; val="$3"
  backup_setting "$table" "$key"
  settings put "$table" "$key" "$val" >/dev/null 2>&1
}

backup_prop() {
  key="$1"
  [ -f "$STATE_FILE" ] || : > "$STATE_FILE"
  grep -Fq "^P|$key|" "$STATE_FILE" 2>/dev/null && return 0
  val="$(getprop "$key" 2>/dev/null)"
  printf 'P|%s|%s\n' "$key" "$val" >> "$STATE_FILE"
}

set_prop() {
  key="$1"; val="$2"
  backup_prop "$key"
  setprop "$key" "$val" >/dev/null 2>&1
}

restore_settings() {
  [ -f "$STATE_FILE" ] || return 0
  while IFS='|' read -r kind a b c; do
    case "$kind" in
      S)
        table="$a"; key="$b"; val="$c"
        case "$val" in
          null|undefined|"") settings delete "$table" "$key" >/dev/null 2>&1 ;;
          *) settings put "$table" "$key" "$val" >/dev/null 2>&1 ;;
        esac
        ;;
      P)
        key="$a"; val="$b"
        [ -z "$val" ] && val=" "
        setprop "$key" "$val" >/dev/null 2>&1
        ;;
    esac
  done < "$STATE_FILE"
}
