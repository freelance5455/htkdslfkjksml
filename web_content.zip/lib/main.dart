import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:llama_flutter_android/llama_flutter_android.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';

import 'models/chat.dart';
import 'services/chat_storage.dart';
import 'services/model_manager.dart';

void main() => runApp(const MindMateApp());

const _purple = Color(0xFFA78BFA);
const _bg = Color(0xFF11101B);
const _panel = Color(0xFF191827);

class MindMateApp extends StatefulWidget {
  const MindMateApp({super.key});
  @override
  State<MindMateApp> createState() => _MindMateAppState();
}

class _MindMateAppState extends State<MindMateApp> {
  ThemeMode _themeMode = ThemeMode.dark;
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MindMate AI',
        themeMode: _themeMode,
        theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: _purple, brightness: Brightness.light), useMaterial3: true),
        darkTheme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: _bg,
          colorScheme: ColorScheme.fromSeed(seedColor: _purple, brightness: Brightness.dark, surface: _panel),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(backgroundColor: _bg, surfaceTintColor: Colors.transparent),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: _panel,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        home: MindMateHome(
          onThemeChanged: (mode) => setState(() => _themeMode = mode),
          themeMode: _themeMode,
        ),
      );
}

class MindMateHome extends StatefulWidget {
  const MindMateHome({super.key, required this.onThemeChanged, required this.themeMode});
  final ValueChanged<ThemeMode> onThemeChanged;
  final ThemeMode themeMode;
  @override
  State<MindMateHome> createState() => _MindMateHomeState();
}

class _MindMateHomeState extends State<MindMateHome> {
  final _storage = ChatStorage();
  final _model = ModelManager();
  final _controller = LlamaController();
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final _uuid = const Uuid();

  List<ChatThread> _chats = [];
  String? _activeId;
  String _view = 'all';
  bool _busy = false;
  bool _modelReady = false;
  bool _modelLoading = false;
  bool _downloading = false;
  double _downloadProgress = 0;
  String? _modelError;
  bool _showSidebar = false;
  StreamSubscription<String>? _generation;
  String _draftAnswer = '';

  ChatThread? get _active {
    for (final c in _chats) {
      if (c.id == _activeId) return c;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final chats = await _storage.load();
    if (!mounted) return;
    setState(() {
      _chats = chats;
      _activeId = chats.isNotEmpty ? chats.last.id : null;
    });
    if (await _model.isDownloaded()) {
      await _loadModel();
    } else {
      // First-run setup: fetch the model automatically. The welcome screen
      // displays download progress and the user can retry from Settings.
      await _downloadModel();
    }
  }

  Future<void> _persist() => _storage.save(_chats);

  Future<void> _downloadModel() async {
    setState(() { _downloading = true; _modelError = null; _downloadProgress = 0; });
    try {
      await _model.ensureModel(onProgress: (received, total) {
        if (!mounted) return;
        setState(() => _downloadProgress = total > 0 ? received / total : 0);
      });
      if (!mounted) return;
      setState(() => _downloading = false);
      await _loadModel();
    } catch (e) {
      if (!mounted) return;
      setState(() { _downloading = false; _modelError = e.toString(); });
    }
  }

  Future<void> _loadModel() async {
    if (_modelLoading || _modelReady) return;
    setState(() { _modelLoading = true; _modelError = null; });
    try {
      final path = await _model.modelPath();
      await _controller.loadModel(modelPath: path, threads: 4, contextSize: 4096);
      if (!mounted) return;
      setState(() { _modelReady = true; _modelLoading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _modelLoading = false; _modelError = 'Could not load the local model: $e'; });
    }
  }

  void _newChat() {
    final c = ChatThread(id: _uuid.v4(), title: 'New conversation', messages: [], updatedAt: DateTime.now());
    setState(() { _chats.add(c); _activeId = c.id; _view = 'all'; _showSidebar = false; });
    _persist();
  }

  Future<void> _send([String? suggested]) async {
    final text = (suggested ?? _input.text).trim();
    if (text.isEmpty || _busy) return;
    if (!_modelReady) {
      _snack('Download and load the Qwen model before chatting.');
      return;
    }
    if (_active == null) _newChat();
    final chat = _active!;
    setState(() {
      chat.messages.add(ChatMessageData(role: 'user', text: text, createdAt: DateTime.now()));
      if (chat.messages.length == 1) chat.title = text.length > 42 ? '${text.substring(0, 42)}…' : text;
      chat.updatedAt = DateTime.now();
      _busy = true;
      _draftAnswer = '';
    });
    _input.clear();
    await _persist();
    _scrollToBottom();
    final messages = <ChatMessage>[
      ChatMessage(role: 'system', content: 'You are MindMate, a helpful, clear, friendly assistant. Be accurate, concise, and explain difficult topics simply.'),
      ...chat.messages.take(chat.messages.length - 1).where((m) => m.role == 'user' || m.role == 'assistant')
          .map((m) => ChatMessage(role: m.role, content: m.text)),
      ChatMessage(role: 'user', content: text),
    ];
    try {
      final stream = _controller.generateChat(
        messages: messages,
        template: 'chatml',
        temperature: 0.7,
        maxTokens: 768,
      );
      await for (final token in stream) {
        if (!mounted) break;
        setState(() => _draftAnswer += token);
        _scrollToBottom();
      }
      if (_draftAnswer.trim().isNotEmpty) {
        chat.messages.add(ChatMessageData(role: 'assistant', text: _draftAnswer.trim(), createdAt: DateTime.now()));
        chat.updatedAt = DateTime.now();
        await _persist();
      }
    } catch (e) {
      _snack('Local model error: $e');
    } finally {
      if (mounted) setState(() { _busy = false; _draftAnswer = ''; });
      await _persist();
    }
  }

  Future<void> _stop() async {
    await _controller.stop();
    if (mounted) setState(() => _busy = false);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent + 180,
          duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
    });
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  List<ChatThread> get _visibleChats {
    final list = _chats.where((c) => _view == 'saved' ? c.saved : _view == 'unsaved' ? !c.saved : true).toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  Future<void> _chatActions(ChatThread chat) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _panel,
      builder: (context) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Rename'), onTap: () => Navigator.pop(context, 'rename')),
        ListTile(leading: Icon(chat.saved ? Icons.bookmark_remove_outlined : Icons.bookmark_add_outlined), title: Text(chat.saved ? 'Unsave chat' : 'Save chat'), onTap: () => Navigator.pop(context, 'save')),
        ListTile(leading: const Icon(Icons.delete_outline, color: Colors.redAccent), title: const Text('Delete', style: TextStyle(color: Colors.redAccent)), onTap: () => Navigator.pop(context, 'delete')),
      ])),
    );
    if (action == 'rename' && mounted) {
      final ctl = TextEditingController(text: chat.title);
      final title = await showDialog<String>(context: context, builder: (context) => AlertDialog(
        title: const Text('Rename conversation'),
        content: TextField(controller: ctl, autofocus: true, decoration: const InputDecoration(hintText: 'Conversation name')),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, ctl.text.trim()), child: const Text('Save'))],
      ));
      if (title != null && title.isNotEmpty) setState(() => chat.title = title);
    } else if (action == 'save') {
      setState(() => chat.saved = !chat.saved);
    } else if (action == 'delete') {
      setState(() { _chats.removeWhere((c) => c.id == chat.id); if (_activeId == chat.id) _activeId = _chats.isEmpty ? null : _chats.first.id; });
    }
    await _persist();
  }

  Future<void> _exportChats() async {
    final json = await _storage.exportJson(_chats);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/mindmate-backup.json');
    await file.writeAsString(json);
    await Share.shareXFiles([XFile(file.path)], text: 'MindMate chat backup');
  }

  Future<void> _importChats() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
    if (result == null) return;
    try {
      final bytes = result.files.single.bytes ?? await File(result.files.single.path!).readAsBytes();
      final chats = await _storage.parseImport(utf8.decode(bytes));
      setState(() { _chats = chats; _activeId = chats.isNotEmpty ? chats.first.id : null; });
      await _persist();
      _snack('Backup imported.');
    } catch (e) {
      _snack('Could not import backup: $e');
    }
  }

  Future<void> _clearChats() async {
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Delete all chats?'),
      content: const Text('This permanently removes locally stored conversations.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete all'))],
    ));
    if (ok == true) {
      setState(() { _chats.clear(); _activeId = null; });
      await _persist();
    }
  }

  Future<void> _settings() async {
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true, backgroundColor: _panel,
      builder: (context) => StatefulBuilder(builder: (context, setSheet) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
          child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Expanded(child: Text('Settings', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800))),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close))]),
            const SizedBox(height: 16),
            const Text('GENERAL', style: TextStyle(color: _purple, letterSpacing: 1.4, fontSize: 11, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ListTile(contentPadding: EdgeInsets.zero, title: const Text('Appearance'), subtitle: const Text('Choose dark, light or system theme'),
              trailing: DropdownButton<ThemeMode>(value: widget.themeMode, items: const [
                DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark')),
                DropdownMenuItem(value: ThemeMode.light, child: Text('Light')),
                DropdownMenuItem(value: ThemeMode.system, child: Text('System')),
              ], onChanged: (v) { if (v != null) widget.onThemeChanged(v); setSheet(() {}); })),
            const Divider(),
            const Text('LOCAL AI MODEL', style: TextStyle(color: _purple, letterSpacing: 1.4, fontSize: 11, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const ListTile(contentPadding: EdgeInsets.zero, title: Text('Qwen2.5-0.5B-Instruct'), subtitle: Text('GGUF · Q4_K_M · Download once, use offline')),
            Row(children: [
              Icon(_modelReady ? Icons.check_circle : Icons.memory, color: _modelReady ? Colors.greenAccent : _purple),
              const SizedBox(width: 8),
              Expanded(child: Text(_modelReady ? 'Model loaded and ready' : _downloading ? 'Downloading model…' : _modelLoading ? 'Loading model…' : 'Model not installed')),
            ]),
            if (_downloading) ...[
              const SizedBox(height: 12),
              LinearProgressIndicator(value: _downloadProgress > 0 ? _downloadProgress : null),
              const SizedBox(height: 5),
              Text('${(_downloadProgress * 100).toStringAsFixed(1)}%', style: const TextStyle(color: Colors.white70)),
              TextButton(onPressed: () { _model.cancelDownload(); setState(() { _downloading = false; }); }, child: const Text('Cancel download')),
            ],
            if (_modelError != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_modelError!, style: const TextStyle(color: Colors.redAccent))),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: (_modelReady || _downloading || _modelLoading) ? null : () async { await _downloadModel(); setSheet(() {}); },
              icon: const Icon(Icons.download), label: Text(_modelReady ? 'Model ready' : _downloading ? 'Downloading…' : _modelLoading ? 'Loading…' : 'Download model'),
            )),
            const SizedBox(height: 5),
            const Text('Initial download requires Wi-Fi or mobile data (about 491 MB). After installation, chat inference runs on this device without an AI API.', style: TextStyle(color: Colors.white60, fontSize: 12)),
            const Divider(height: 28),
            const Text('DATA', style: TextStyle(color: _purple, letterSpacing: 1.4, fontSize: 11, fontWeight: FontWeight.bold)),
            ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.file_upload_outlined), title: const Text('Import chats'), onTap: () { Navigator.pop(context); _importChats(); }),
            ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.file_download_outlined), title: const Text('Export chats'), onTap: () { Navigator.pop(context); _exportChats(); }),
            ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.delete_sweep_outlined), title: const Text('Delete all chats'), onTap: () { Navigator.pop(context); _clearChats(); }),
          ])),
        ),
      )),
    );
  }

  @override
  void dispose() {
    _generation?.cancel();
    _controller.dispose();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 800;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        titleSpacing: 16,
        title: Row(children: [
          if (!wide) IconButton(onPressed: () => setState(() => _showSidebar = !_showSidebar), icon: const Icon(Icons.menu)),
          const Text('Workspace', style: TextStyle(fontSize: 13, color: Colors.white60)),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('/')),
          Expanded(child: Text(_active?.title ?? 'New conversation', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
        ]),
        actions: [
          Container(margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
            decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white10)),
            child: Row(children: [Icon(Icons.circle, size: 7, color: _modelReady ? Colors.greenAccent : Colors.orangeAccent), const SizedBox(width: 6),
              const Text('Qwen 2.5 0.5B', style: TextStyle(fontSize: 10))])),
          IconButton(onPressed: () => widget.onThemeChanged(widget.themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark), icon: const Icon(Icons.contrast)),
          IconButton(onPressed: _settings, icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      body: Row(children: [
        if (wide || _showSidebar) SizedBox(width: wide ? 270 : 280, child: _sidebar()),
        Expanded(child: Column(children: [
          Expanded(child: _conversation()),
          _composer(),
        ])),
      ]),
    );
  }

  Widget _sidebar() => Container(
    color: const Color(0xFF151421), padding: const EdgeInsets.fromLTRB(15, 20, 15, 12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Row(children: [CircleAvatar(backgroundColor: _purple, child: Text('✦', style: TextStyle(color: _bg, fontSize: 22))),
        SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('MindMate', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)), Text('AI workspace', style: TextStyle(color: Colors.white54, fontSize: 11))])]),
      const SizedBox(height: 24),
      FilledButton.icon(onPressed: _newChat, icon: const Icon(Icons.add), label: const Text('New chat')),
      const SizedBox(height: 22),
      const Text('WORKSPACE', style: TextStyle(color: Colors.white38, letterSpacing: 1.4, fontSize: 10, fontWeight: FontWeight.bold)),
      _nav('All chats', Icons.grid_view_outlined, 'all'),
      _nav('Saved chats', Icons.bookmark_border, 'saved', count: _chats.where((c) => c.saved).length),
      _nav('Unsaved chats', Icons.history, 'unsaved'),
      const Padding(padding: EdgeInsets.only(top: 20, bottom: 8), child: Text('RECENT', style: TextStyle(color: Colors.white38, letterSpacing: 1.4, fontSize: 10, fontWeight: FontWeight.bold))),
      Expanded(child: ListView(children: _visibleChats.map((c) => ListTile(
        dense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 8),
        selected: c.id == _activeId, selectedTileColor: Colors.white10,
        leading: const Icon(Icons.chat_bubble_outline, size: 16),
        title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
        trailing: IconButton(icon: const Icon(Icons.more_horiz, size: 18), onPressed: () => _chatActions(c)),
        onTap: () => setState(() { _activeId = c.id; _showSidebar = false; }),
      )).toList())),
      const Divider(color: Colors.white12),
      ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings', style: TextStyle(fontSize: 13)), onTap: _settings),
      const ListTile(leading: CircleAvatar(radius: 15, backgroundColor: Color(0xFF39314F), child: Text('M')), title: Text('MindMate User', style: TextStyle(fontSize: 12)), subtitle: Text('Personal workspace', style: TextStyle(fontSize: 10))),
    ]),
  );

  Widget _nav(String label, IconData icon, String view, {int? count}) => ListTile(
    dense: true, selected: _view == view, selectedTileColor: _purple.withOpacity(.12),
    leading: Icon(icon, size: 18), title: Text(label, style: const TextStyle(fontSize: 13)),
    trailing: count == null ? null : Text('$count', style: const TextStyle(color: Colors.white54, fontSize: 11)),
    onTap: () => setState(() => _view = view),
  );

  Widget _conversation() {
    final chat = _active;
    if (chat == null || chat.messages.isEmpty) return _welcome();
    return ListView(
      controller: _scroll, padding: const EdgeInsets.fromLTRB(18, 24, 18, 24),
      children: [
        ...chat.messages.map(_messageBubble),
        if (_busy && _draftAnswer.isEmpty) _assistantBubble(const Text('MindMate is thinking…', style: TextStyle(color: Colors.white60))),
        if (_draftAnswer.isNotEmpty) _assistantBubble(SelectableText(_draftAnswer)),
      ],
    );
  }

  Widget _welcome() => Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 62, height: 62, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFC4B5FD), Color(0xFF7653D9)]), borderRadius: BorderRadius.circular(20)), child: const Icon(Icons.auto_awesome, color: _bg, size: 30)),
    const SizedBox(height: 22),
    const Text('YOUR THOUGHT PARTNER', style: TextStyle(color: _purple, letterSpacing: 2, fontSize: 10, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    const Text('Think clearly.\nCreate freely.', textAlign: TextAlign.center, style: TextStyle(fontSize: 38, height: 1.1, fontWeight: FontWeight.w800)),
    const SizedBox(height: 12),
    const Text('What would you like to work on today?', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 26),
    Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
      _prompt('Learn something', 'Break down a difficult topic', 'Explain a difficult topic in simple steps.'),
      _prompt('Explore ideas', 'Brainstorm something new', 'Help me brainstorm creative ideas for a project.'),
      _prompt('Make a plan', 'Organize your next steps', 'Help me make a clear plan for my tasks.'),
      _prompt('Improve writing', 'Polish words and drafts', 'Review this writing and suggest improvements: '),
    ]),
    if (!_modelReady) Padding(padding: const EdgeInsets.only(top: 22), child: SizedBox(
      width: 360,
      child: Card(color: _panel, child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
        Row(children: [const Icon(Icons.memory, color: _purple), const SizedBox(width: 9),
          Expanded(child: Text(_downloading ? 'Downloading Qwen model…' : _modelLoading ? 'Loading local model…' : 'Local model setup', style: const TextStyle(fontWeight: FontWeight.w600))),
          if (_downloading) Text('${(_downloadProgress * 100).toStringAsFixed(0)}%'),
        ]),
        if (_downloading) ...[const SizedBox(height: 10), LinearProgressIndicator(value: _downloadProgress > 0 ? _downloadProgress : null)],
        if (_modelError != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_modelError!, style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
        if (!_downloading && !_modelLoading) Align(alignment: Alignment.centerRight, child: TextButton.icon(
          onPressed: _downloadModel, icon: const Icon(Icons.download), label: Text(_modelError == null ? 'Download model' : 'Retry download'))),
        const SizedBox(height: 4),
        const Text('One-time download · about 491 MB · works offline afterward', style: TextStyle(color: Colors.white54, fontSize: 11)),
      ]))),
    )),
  ])));

  Widget _prompt(String title, String subtitle, String prompt) => SizedBox(width: 260, child: Card(color: _panel, child: InkWell(
    borderRadius: BorderRadius.circular(14), onTap: () { _input.text = prompt; FocusScope.of(context).requestFocus(FocusNode()); },
    child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.auto_awesome, color: _purple), const SizedBox(height: 8),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
      const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
    ])),
  )));

  Widget _messageBubble(ChatMessageData m) {
    final user = m.role == 'user';
    return Align(alignment: user ? Alignment.centerRight : Alignment.centerLeft, child: Container(
      constraints: const BoxConstraints(maxWidth: 720),
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      decoration: BoxDecoration(color: user ? const Color(0xFF493B70) : _panel, borderRadius: BorderRadius.circular(16)),
      child: SelectableText(m.text, style: const TextStyle(fontSize: 14, height: 1.5)),
    ));
  }

  Widget _assistantBubble(Widget child) => Align(alignment: Alignment.centerLeft, child: Container(
    constraints: const BoxConstraints(maxWidth: 720), margin: const EdgeInsets.only(bottom: 15),
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
    decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16)), child: child,
  ));

  Widget _composer() => SafeArea(child: Padding(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
    child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 850), child: Column(children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Expanded(child: TextField(controller: _input, minLines: 1, maxLines: 5, textCapitalization: TextCapitalization.sentences,
          onSubmitted: (_) => _busy ? null : _send(),
          decoration: const InputDecoration(hintText: 'Message MindMate...', contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14)))),
        const SizedBox(width: 9),
        SizedBox(height: 50, width: 50, child: FilledButton(
          onPressed: _busy ? _stop : () => _send(),
          style: FilledButton.styleFrom(padding: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Icon(_busy ? Icons.stop : Icons.arrow_upward),
        )),
      ]),
      const SizedBox(height: 7),
      const Text('AI can make mistakes. Check important information.  •  Runs locally on your device', style: TextStyle(color: Colors.white38, fontSize: 10)),
    ])),
  ));
}
