import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async { WidgetsFlutterBinding.ensureInitialized(); runApp(App(store: await Store.load())); }
String uid()=>DateTime.now().microsecondsSinceEpoch.toString();
const shades={'Clean White':Color(0xFFF8F8F5),'Sky Blue':Color(0xFFDCEEFF),'Soft Red':Color(0xFFF7DDDF),'Sage Green':Color(0xFFDDEBDD),'Heavenly Pink':Color(0xFFF8E1EE)};
class Store extends ChangeNotifier{
 Store(this.p); final SharedPreferences p;
 List<Map<String,dynamic>> tasks=[],books=[],quotes=[],lists=[]; String theme='Dreamy';
 static Future<Store> load() async {
  final p=await SharedPreferences.getInstance(),s=Store(p);
  List<dynamic> get(String k){try{return jsonDecode(p.getString(k)??'[]');}catch(_){return [];}}
  s.tasks=get('tasks').map<Map<String,dynamic>>((x)=>{'id':x['id']??uid(),'title':x['title']??'','done':x['done']==true}).toList();
  s.books=get('books').map<Map<String,dynamic>>((b)=>{'id':b['id']??uid(),'title':b['title']??'Notebook','color':b['color']??'Clean White','entries':(b['entries'] as List? ?? []).map((e)=>{'id':e['id']??uid(),'title':e['title']??'','body':e['body']??'','date':e['date']??''}).toList()}).toList();
  s.quotes=get('quotes').map<Map<String,dynamic>>((q)=>q is String?{'id':uid(),'text':q}:{'id':q['id']??uid(),'text':q['text']??''}).toList();
  s.lists=get('lists').map<Map<String,dynamic>>((l)=>{'id':l['id']??uid(),'title':l['title']??'List','items':(l['items'] as List? ?? []).map((x)=>x is String?{'id':uid(),'text':x}:{'id':x['id']??uid(),'text':x['text']??''}).toList()}).toList();
  s.theme=p.getString('theme')??'Dreamy'; return s;
 }
 Future<void> save() async {for(final e in {'tasks':tasks,'books':books,'quotes':quotes,'lists':lists}.entries){await p.setString(e.key,jsonEncode(e.value));}await p.setString('theme',theme);notifyListeners();}
}
class App extends StatelessWidget{
 const App({super.key,required this.store});final Store store;
 @override Widget build(BuildContext c)=>AnimatedBuilder(animation:store,builder:(c,_){
  final dark=store.theme=='Dark',seed=store.theme=='Light'?const Color(0xff83bfe2):dark?const Color(0xffa99ac4):const Color(0xff92c7e8);
  return MaterialApp(debugShowCheckedModeBanner:false,title:'Morrow',theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:seed,brightness:dark?Brightness.dark:Brightness.light),scaffoldBackgroundColor:dark?const Color(0xff292532):store.theme=='Light'?const Color(0xffdff2ff):const Color(0xffeaf5fc)),home:Home(store:store));
 });
}
class Home extends StatefulWidget{const Home({super.key,required this.store});final Store store;@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{
 int tab=0; Store get s=>widget.store;
 Future<bool> del(String what)async=>await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text('Delete $what?'),content:const Text('This cannot be undone.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Delete'))]))??false;
 Future<List<String>?> editor(String title,List<String> labels,List<String> values,{List<bool>? multi})async{
  final cs=List.generate(labels.length,(i)=>TextEditingController(text:values[i]));final key=GlobalKey<FormState>();
  final result=await showDialog<List<String>>(context:context,builder:(c)=>AlertDialog(title:Text(title),content:Form(key:key,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[for(int i=0;i<labels.length;i++)TextFormField(controller:cs[i],maxLines:(multi?[...multi!][i]?4:1),decoration:InputDecoration(labelText:labels[i]),validator:(v)=>v==null||v.trim().isEmpty&&i==0?'Required':null)]))),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),FilledButton(onPressed:(){if(key.currentState!.validate())Navigator.pop(c,cs.map((x)=>x.text.trim()).toList());},child:const Text('Save'))]));
  for(final x in cs){x.dispose();}return result;
 }
 Widget heading(String t,String sub)=>Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:Theme.of(context).textTheme.headlineSmall),Text(sub)]));
 void taskEdit([int? i])async{final v=await editor(i==null?'New task':'Edit task',['Task'],[i==null?'':s.tasks[i]['title']]);if(v==null)return;if(i==null)s.tasks.add({'id':uid(),'title':v[0],'done':false});else s.tasks[i]['title']=v[0];s.save();}
 Widget tasks()=>Column(children:[heading('Tasks','Small steps count.'),Expanded(child:ListView(children:[for(int i=0;i<s.tasks.length;i++)Card(child:ListTile(leading:Checkbox(value:s.tasks[i]['done'],onChanged:(v){s.tasks[i]['done']=v;s.save();if(v==true)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('You did it! 🎉')));}),title:AnimatedDefaultTextStyle(duration:const Duration(milliseconds:250),style:TextStyle(decoration:s.tasks[i]['done']?TextDecoration.lineThrough:null,color:s.tasks[i]['done']?Colors.grey:null),child:Text(s.tasks[i]['title'])),trailing:PopupMenuButton(onSelected:(v)async{if(v=='e')taskEdit(i);if(v=='d'&&await del('task')){s.tasks.removeAt(i);s.save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'e',child:Text('Edit')),PopupMenuItem(value:'d',child:Text('Delete'))])))]))]);
 Future<void> bookEdit([int? i])async{
  final b=i==null?{'title':'','color':'Clean White'}:s.books[i];final name=TextEditingController(text:b['title']);String color=b['color'];
  await showDialog(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:Text(i==null?'New notebook':'Edit notebook'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Notebook name')),const SizedBox(height:12),const Text('Choose a notebook shade'),Wrap(spacing:6,children:[for(final e in shades.entries)ChoiceChip(label:Text(e.key),selected:color==e.key,backgroundColor:e.value, onSelected:(_)=>setD(()=>color=e.key))])]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),FilledButton(onPressed:(){if(name.text.trim().isEmpty)return;if(i==null)s.books.add({'id':uid(),'title':name.text.trim(),'color':color,'entries':[]});else{s.books[i]['title']=name.text.trim();s.books[i]['color']=color;}s.save();Navigator.pop(c);},child:const Text('Save'))])));
  name.dispose();
 }
 Future<void> entryEdit(int bi,[int? ei])async{final entries=s.books[bi]['entries'] as List;final old=ei==null?{'title':'','body':''}:entries[ei];final v=await editor(ei==null?'New journal entry':'Edit journal entry',['Entry title','Your thoughts'],[old['title'],old['body']],multi:[false,true]);if(v==null)return;final e={'id':ei==null?uid():old['id'],'title':v[0],'body':v[1],'date':DateTime.now().toString().substring(0,16)};if(ei==null)entries.insert(0,e);else entries[ei]=e;s.save();}
 Widget journal()=>ListView(children:[heading('Your notebooks','Choose a shade that feels like yours.'),Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Align(alignment:Alignment.centerLeft,child:FilledButton.icon(onPressed:()=>bookEdit(),icon:const Icon(Icons.add),label:const Text('＋ New notebook')))),for(int i=0;i<s.books.length;i++)Card(color:shades[s.books[i]['color']]??shades['Clean White'],child:ExpansionTile(title:Text(s.books[i]['title'],style:const TextStyle(color:Color(0xff34465b))),trailing:PopupMenuButton(onSelected:(v)async{if(v=='e')bookEdit(i);if(v=='d'&&await del('notebook')){s.books.removeAt(i);s.save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'e',child:Text('Edit')),PopupMenuItem(value:'d',child:Text('Delete'))]),children:[TextButton.icon(onPressed:()=>entryEdit(i),icon:const Icon(Icons.add),label:const Text('＋ Add entry')),for(int j=0;j<(s.books[i]['entries'] as List).length;j++)ListTile(title:Text(s.books[i]['entries'][j]['title'],style:const TextStyle(color:Color(0xff34465b))),subtitle:Text(s.books[i]['entries'][j]['body'],maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Color(0xff526477))),trailing:PopupMenuButton(onSelected:(v)async{if(v=='e')entryEdit(i,j);if(v=='d'&&await del('entry')){(s.books[i]['entries'] as List).removeAt(j);s.save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'e',child:Text('Edit')),PopupMenuItem(value:'d',child:Text('Delete'))]))]))]);
 Future<void> quoteEdit([int? i])async{final v=await editor(i==null?'New quote':'Edit quote',['Quote'],[i==null?'':s.quotes[i]['text']],multi:[true]);if(v==null)return;if(i==null)s.quotes.insert(0,{'id':uid(),'text':v[0]});else s.quotes[i]['text']=v[0];s.save();}
 Widget quotes()=>ListView(children:[heading('Quotes','Keep the words you want to carry with you.'),for(int i=0;i<s.quotes.length;i++)Card(child:ListTile(title:Text('❝ ${s.quotes[i]['text']}'),trailing:PopupMenuButton(onSelected:(v)async{if(v=='e')quoteEdit(i);if(v=='d'&&await del('quote')){s.quotes.removeAt(i);s.save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'e',child:Text('Edit')),PopupMenuItem(value:'d',child:Text('Delete'))])))]);
 Future<void> listEdit([int? i])async{final v=await editor(i==null?'New list':'Edit list',['List name'],[i==null?'':s.lists[i]['title']]);if(v==null)return;if(i==null)s.lists.add({'id':uid(),'title':v[0],'items':[]});else s.lists[i]['title']=v[0];s.save();}
 Future<void> itemEdit(int li,[int? ii])async{final items=s.lists[li]['items'] as List;final v=await editor('List item',['Item'],[ii==null?'':items[ii]['text']]);if(v==null)return;if(ii==null)items.add({'id':uid(),'text':v[0]});else items[ii]['text']=v[0];s.save();}
 Widget lists()=>ListView(children:[heading('Create a List','Keep track of anything you want.'),Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Align(alignment:Alignment.centerLeft,child:FilledButton.icon(onPressed:()=>listEdit(),icon:const Icon(Icons.add),label:const Text('＋ Create list')))),for(int i=0;i<s.lists.length;i++)Card(child:ExpansionTile(title:Text(s.lists[i]['title']),trailing:PopupMenuButton(onSelected:(v)async{if(v=='e')listEdit(i);if(v=='d'&&await del('list')){s.lists.removeAt(i);s.save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'e',child:Text('Edit')),PopupMenuItem(value:'d',child:Text('Delete'))]),children:[TextButton.icon(onPressed:()=>itemEdit(i),icon:const Icon(Icons.add),label:const Text('＋ Add item')),for(int j=0;j<(s.lists[i]['items'] as List).length;j++)ListTile(title:Text(s.lists[i]['items'][j]['text']),trailing:PopupMenuButton(onSelected:(v)async{if(v=='e')itemEdit(i,j);if(v=='d'&&await del('item')){(s.lists[i]['items'] as List).removeAt(j);s.save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'e',child:Text('Edit')),PopupMenuItem(value:'d',child:Text('Delete'))]))])]);
 Widget home(){
  final total=s.tasks.length;
  final done=s.tasks.where((x)=>x['done']==true).length;
  final pending=total-done;
  final pct=total==0?0.0:done/total;
  return ListView(children:[
   heading('A fresh little beginning 🌱','You don’t have to do everything. Just begin.'),
   Card(margin:const EdgeInsets.all(16),child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[
    SizedBox(width:116,height:116,child:Stack(alignment:Alignment.center,children:[
     SizedBox.expand(child:CircularProgressIndicator(value:total==0?0:pct,strokeWidth:10,backgroundColor:Theme.of(context).colorScheme.surfaceContainerHighest)),
     Column(mainAxisSize:MainAxisSize.min,children:[Text(total==0?'—':'${(pct*100).round()}%',style:const TextStyle(fontSize:27,fontWeight:FontWeight.bold)),const Text('today',style:TextStyle(fontSize:12))])
    ])),
    const SizedBox(width:20),
    Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
     const Text('Today’s progress',style:TextStyle(fontSize:18,fontWeight:FontWeight.w600)),
     Text('$done completed',style:const TextStyle(fontSize:16)),
     Text('$pending remaining'),
     if(total==0) const Text('Add a task to begin your day.',style:TextStyle(fontSize:12))
    ]))
   ]))),
   heading('Activity overview','A quick look at what you have planned.'),
   Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Row(children:[
    Expanded(child:_statCard('Tasks', '$total', Icons.check_circle_outline)),
    const SizedBox(width:10),
    Expanded(child:_statCard('Completed', '$done', Icons.task_alt)),
    const SizedBox(width:10),
    Expanded(child:_statCard('Pending', '$pending', Icons.hourglass_empty))
   ])),
   heading('Your space','A few calm places to keep life organised.'),
   for(final e in [('Tasks',1,Icons.check_circle_outline),('Journal',2,Icons.menu_book),('Quotes',3,Icons.format_quote),('Create a List',4,Icons.list_alt)])
    Card(child:ListTile(title:Text(e.$1),leading:Icon(e.$3),trailing:const Icon(Icons.chevron_right),onTap:()=>setState(()=>tab=e.$2)))
  ]);
 }
 Widget _statCard(String label,String value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.symmetric(vertical:14,horizontal:8),child:Column(children:[Icon(icon),const SizedBox(height:5),Text(value,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Text(label,style:const TextStyle(fontSize:12))])));
 Widget settings()=>ListView(children:[heading('Settings','Make Morrow feel like your space.'),Card(child:Padding(padding:const EdgeInsets.all(16),child:DropdownButton<String>(value:s.theme,isExpanded:true,items:['Dreamy','Light','Dark'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v){if(v!=null){s.theme=v;s.save();}}))),const Padding(padding:EdgeInsets.all(16),child:Text('Data is stored locally on this device. Cloud sync is not included yet.'))]);
 @override Widget build(BuildContext c){final pages=[home(),tasks(),journal(),quotes(),lists(),settings()];return Scaffold(appBar:AppBar(title:const Text('🌱 Morrow')),drawer:Drawer(child:ListView(children:[const DrawerHeader(child:Text('Morrow\nA little better, everyday.',style:TextStyle(fontSize:23))),for(int i=0;i<6;i++)ListTile(title:Text(['Home','Tasks','Journal','Quotes','Create a List','Settings'][i]),onTap:(){setState(()=>tab=i);Navigator.pop(c);})])),body:SafeArea(child:pages[tab]),bottomNavigationBar:NavigationBar(selectedIndex:tab<4?tab:0,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[NavigationDestination(icon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.check),label:'Tasks'),NavigationDestination(icon:Icon(Icons.book),label:'Journal'),NavigationDestination(icon:Icon(Icons.format_quote),label:'Quotes')]),floatingActionButton:tab==1?FloatingActionButton(onPressed:()=>taskEdit(),child:const Icon(Icons.add)):tab==2?FloatingActionButton(onPressed:()=>bookEdit(),child:const Icon(Icons.add)):tab==3?FloatingActionButton(onPressed:()=>quoteEdit(),child:const Icon(Icons.add)):tab==4?FloatingActionButton(onPressed:()=>listEdit(),child:const Icon(Icons.add)):null);}
}
