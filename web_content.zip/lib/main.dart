import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Configure Firebase using `flutterfire configure` before enabling cloud requests.
  // The app falls back to local-only mode if Firebase has not been configured.
  try {
    await Firebase.initializeApp();
  } catch (_) {}
  runApp(const NaslanWorldApp());
}

const navy = Color(0xFF102D50);
const gold = Color(0xFFE7C777);

class NaslanWorldApp extends StatefulWidget {
  const NaslanWorldApp({super.key});
  @override
  State<NaslanWorldApp> createState() => _NaslanWorldAppState();
}

class _NaslanWorldAppState extends State<NaslanWorldApp> {
  bool tamil = true;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NASLAN WORLD ONLINE',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: navy, primary: navy),
      scaffoldBackgroundColor: const Color(0xFFF5F7FA),
      useMaterial3: true,
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    home: HomePage(tamil: tamil, onLanguageChanged: (v) => setState(() => tamil = v)),
  );
}

class HomePage extends StatefulWidget {
  final bool tamil;
  final ValueChanged<bool> onLanguageChanged;
  const HomePage({super.key, required this.tamil, required this.onLanguageChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final List<Map<String, dynamic>> localRequests = [];
  String tr(String ta, String en) => widget.tamil ? ta : en;

  @override
  Widget build(BuildContext context) {
    final labels = [tr('முகப்பு','Home'), tr('கோரிக்கைகள்','Requests'), tr('தொடர்பு','Contact')];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy, foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('NASLAN WORLD ONLINE', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text('YOUR JOURNEY, OUR PRIORITY', style: TextStyle(fontSize: 9, letterSpacing: 1.1, color: gold)),
        ]),
        actions: [PopupMenuButton<bool>(
          onSelected: widget.onLanguageChanged,
          itemBuilder: (_) => const [
            PopupMenuItem(value: true, child: Text('தமிழ்')),
            PopupMenuItem(value: false, child: Text('English')),
          ],
          child: Padding(padding: const EdgeInsets.all(14), child: Text(widget.tamil ? 'தமிழ் ▾' : 'EN ▾')),
        )],
      ),
      body: IndexedStack(index: tab, children: [_home(), _requests(), _contact()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.explore_outlined), label: labels[0]),
          NavigationDestination(icon: const Icon(Icons.receipt_long_outlined), label: labels[1]),
          NavigationDestination(icon: const Icon(Icons.support_agent), label: labels[2]),
        ],
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(colors: [navy, Color(0xFF24537A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.public, color: gold, size: 38),
        const SizedBox(height: 14),
        Text(tr('உலகத்தை எளிதாகச் சுற்றிப் பாருங்கள்','Explore the world with ease'),
          style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(tr('Flight, Hotel, Taxi — ஒரே இடத்தில்','Flights, hotels and taxis in one place'),
          style: const TextStyle(color: Color(0xFFE1EAF2))),
        const SizedBox(height: 16),
        const Wrap(spacing: 8, children: [
          _Pill(icon: Icons.flight, label: 'Flights'),
          _Pill(icon: Icons.hotel, label: 'Hotels'),
          _Pill(icon: Icons.local_taxi, label: 'Taxi'),
        ]),
      ]),
    ),
    const SizedBox(height: 22),
    Text(tr('எதை முன்பதிவு செய்ய விரும்புகிறீர்கள்?','What would you like to book?'),
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    _service(Icons.flight_takeoff, tr('விமான முன்பதிவு','Flight booking'),
      tr('டிக்கெட் கோரிக்கை அனுப்புங்கள்','Send a flight request'), const Color(0xFFE8F1FC), 'Flight'),
    _service(Icons.hotel, tr('ஹோட்டல் முன்பதிவு','Hotel booking'),
      tr('ஹோட்டல் மற்றும் அறை விவரங்கள்','Ask for hotel and room options'), const Color(0xFFE8F6EF), 'Hotel'),
    _service(Icons.local_taxi, tr('Taxi / Airport Transfer','Taxi / Airport Transfer'),
      tr('Airport pickup, drop அல்லது நகரப் பயணம்','Airport pickup, drop or city transfer'), const Color(0xFFFFF3DD), 'Taxi'),
    const SizedBox(height: 8),
    Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFFFFF8E7), borderRadius: BorderRadius.circular(16)),
      child: Text(tr(
        'கவனம்: இது Booking கோரிக்கை மட்டுமே. உங்கள் கோரிக்கை Firebase இணைக்கப்பட்டதும் சேவையகத்தில் சேமிக்கப்படும். உறுதிப்படுத்தல் தனியாக தேவை.',
        'Note: this is a booking request, not a confirmed reservation. Requests are saved to the cloud only after Firebase is configured. Confirmation is handled separately.'),
        style: const TextStyle(fontSize: 12, height: 1.45)),
    ),
  ]);

  Widget _service(IconData icon, String title, String subtitle, Color color, String type) => Card(
    elevation: 0, color: Colors.white, margin: const EdgeInsets.only(bottom: 10),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE5EAF0))),
    child: ListTile(
      contentPadding: const EdgeInsets.all(12),
      leading: Container(width: 52, height: 52, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(15)),
        child: Icon(icon, color: navy, size: 28)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingPage(
        type: type, tamil: widget.tamil, onSave: (request) async {
          setState(() => localRequests.insert(0, request));
          try {
            await FirebaseFirestore.instance.collection('bookingRequests').add({
              ...request,
              'createdAt': FieldValue.serverTimestamp(),
              'status': 'new',
              'source': 'android',
            });
          } catch (_) {
            // Local list still works in demo mode; cloud persistence requires Firebase setup.
          }
        },
      ))),
    ),
  );

  Widget _requests() {
    if (localRequests.isEmpty) return Center(child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.receipt_long_outlined, size: 56, color: Color(0xFF9AA8B8)),
        const SizedBox(height: 12),
        Text(tr('இன்னும் கோரிக்கைகள் இல்லை','No requests yet'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(tr('Flight, Hotel அல்லது Taxi தேர்வு செய்து தொடங்குங்கள்.','Choose Flights, Hotels or Taxi to get started.'), textAlign: TextAlign.center),
      ]),
    ));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(tr('இந்தச் சாதனத்தில் அனுப்பிய கோரிக்கைகள்','Requests from this session'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ...localRequests.map((r) => Card(
        color: Colors.white, elevation: 0,
        child: ListTile(
          leading: const Icon(Icons.receipt_long, color: navy),
          title: Text('${r['type']}: ${r['from']} → ${r['to']}'),
          subtitle: Text('${r['date']} • ${r['name']} • ${tr('கோரிக்கை மட்டும்','Request only')}'),
        ),
      )),
      Padding(padding: const EdgeInsets.all(8), child: Text(tr(
        'இந்தப் பட்டியல் தற்போதைய செயலி அமர்வுக்கானது. Firebase இணைக்கப்பட்டால் கோரிக்கைகள் மேகத்தில் சேமிக்கப்படும்.',
        'This list is for the current app session. Cloud storage requires Firebase setup.'),
        style: const TextStyle(fontSize: 12, color: Colors.black54))),
    ]);
  }

  Widget _contact() => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 16),
    const CircleAvatar(radius: 38, backgroundColor: navy, child: Icon(Icons.support_agent, color: gold, size: 42)),
    const SizedBox(height: 16),
    const Center(child: Text('NASLAN WORLD ONLINE', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
    const SizedBox(height: 8),
    Center(child: Text(tr('உங்கள் பயண உதவி மையம்','Your travel assistance desk'))),
    const SizedBox(height: 24),
    _contactTile(Icons.language, tr('சேவைப் பகுதிகள்','Service regions'), tr('இலங்கை • UAE • சர்வதேசம்','Sri Lanka • UAE • Worldwide')),
    _contactTile(Icons.email_outlined, tr('மின்னஞ்சல்','Email'), tr('உங்கள் வணிக மின்னஞ்சலை சேர்க்கவும்','Add your business email')),
    _contactTile(Icons.phone_outlined, tr('தொலைபேசி','Phone'), tr('உங்கள் வணிக தொலைபேசி எண்ணை சேர்க்கவும்','Add your business phone')),
    const SizedBox(height: 12),
    const Text('Before public release, add verified contact details and a Privacy Policy.', style: TextStyle(fontSize: 12, color: Colors.black54)),
  ]);

  Widget _contactTile(IconData icon, String title, String subtitle) => Card(
    elevation: 0, color: Colors.white,
    child: ListTile(leading: Icon(icon, color: navy), title: Text(title), subtitle: Text(subtitle)),
  );
}

class _Pill extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Pill({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
    decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white24)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: gold, size: 16), const SizedBox(width: 6),
      Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
    ]),
  );
}

class BookingPage extends StatefulWidget {
  final String type;
  final bool tamil;
  final Future<void> Function(Map<String, dynamic>) onSave;
  const BookingPage({super.key, required this.type, required this.tamil, required this.onSave});
  @override
  State<BookingPage> createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  final keyForm = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final from = TextEditingController();
  final to = TextEditingController();
  final date = TextEditingController();
  final details = TextEditingController();
  bool sending = false;
  String tr(String ta, String en) => widget.tamil ? ta : en;

  @override
  void dispose() {
    for (final c in [name, phone, from, to, date, details]) { c.dispose(); }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${widget.type} ${tr('கோரிக்கை','Request')}'), backgroundColor: navy, foregroundColor: Colors.white),
    body: Form(key: keyForm, child: ListView(padding: const EdgeInsets.all(18), children: [
      Text(tr('பயண விவரங்களை நிரப்பவும்','Enter your travel details'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text(tr('இது கோரிக்கை மட்டுமே; உடனடி Booking உறுதி செய்யப்படாது.','This is a request only; no booking is confirmed instantly.'), style: const TextStyle(color: Colors.black54, fontSize: 13)),
      const SizedBox(height: 18),
      _field(name, tr('முழுப் பெயர்','Full name'), Icons.person_outline),
      const SizedBox(height: 12),
      _field(phone, tr('தொலைபேசி / WhatsApp எண்','Phone / WhatsApp number'), Icons.phone_outlined, keyboard: TextInputType.phone),
      const SizedBox(height: 12),
      _field(from, widget.type == 'Hotel' ? tr('நகரம் / பகுதி','City / area') : tr('புறப்படும் இடம்','From / pickup location'), Icons.trip_origin),
      const SizedBox(height: 12),
      _field(to, widget.type == 'Hotel' ? tr('ஹோட்டல் / இலக்கு பகுதி','Hotel / destination area') : tr('செல்லும் இடம்','To / destination'), Icons.place_outlined),
      const SizedBox(height: 12),
      TextFormField(
        controller: date, readOnly: true,
        decoration: InputDecoration(labelText: tr('தேதி','Date'), prefixIcon: const Icon(Icons.calendar_month)),
        validator: (v) => v == null || v.isEmpty ? tr('தேதியைத் தேர்வு செய்யவும்','Select a date') : null,
        onTap: () async {
          final picked = await showDatePicker(context: context,
            initialDate: DateTime.now().add(const Duration(days: 1)),
            firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 730)));
          if (picked != null) date.text = '${picked.day.toString().padLeft(2,'0')}/${picked.month.toString().padLeft(2,'0')}/${picked.year}';
        },
      ),
      const SizedBox(height: 12),
      TextFormField(controller: details, maxLines: 3, decoration: InputDecoration(
        alignLabelWithHint: true,
        labelText: widget.type == 'Hotel' ? tr('விருந்தினர் / அறை விவரங்கள்','Guests / room details') :
          widget.type == 'Flight' ? tr('பயணிகள் / திரும்பும் தேதி','Passengers / return date') :
          tr('பயணிகள் / சுமைகள் / கூடுதல் விவரங்கள்','Passengers / luggage / extra details'))),
      const SizedBox(height: 20),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 16)),
        onPressed: sending ? null : () async {
          if (!keyForm.currentState!.validate()) return;
          setState(() => sending = true);
          final req = <String, dynamic>{
            'type': widget.type, 'name': name.text.trim(), 'phone': phone.text.trim(),
            'from': from.text.trim(), 'to': to.text.trim(), 'date': date.text.trim(),
            'details': details.text.trim(), 'status': 'new',
          };
          await widget.onSave(req);
          if (!mounted) return;
          setState(() => sending = false);
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr(
            'கோரிக்கை பதிவு செய்யப்பட்டது. உண்மையான Booking இன்னும் உறுதி செய்யப்படவில்லை.',
            'Request submitted in demo mode. A real booking is not confirmed.'))));
        },
        icon: const Icon(Icons.send),
        label: Text(sending ? tr('சேமிக்கிறது...','Saving...') : tr('கோரிக்கையை அனுப்பவும்','Submit request')),
      ),
      const SizedBox(height: 12),
      Text(tr(
        'Firebase அமைக்கப்படாதிருந்தால் கோரிக்கை இந்தச் சாதனத்தில் மட்டும் இருக்கும். Firebase அமைத்தால் Firestore-ல் சேமிக்கப்படும். வெளியீட்டிற்கு முன் பாதுகாப்பு விதிகள் கட்டாயம்.',
        'Without Firebase configuration, requests remain local to this session. With Firebase configured, requests are saved to Firestore. Secure database rules are mandatory before release.'),
        style: const TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
    ])),
  );

  Widget _field(TextEditingController c, String label, IconData icon, {TextInputType keyboard = TextInputType.text}) =>
    TextFormField(controller: c, keyboardType: keyboard,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
      validator: (v) => v == null || v.trim().isEmpty ? tr('இந்த விவரத்தை நிரப்பவும்','This field is required') : null);
}
