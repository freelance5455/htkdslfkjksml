import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:math';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: BlockBlast()));
}

class BlockBlast extends StatefulWidget {
  @override
  State<BlockBlast> createState() => _BlockBlastState();
}

class _BlockBlastState extends State<BlockBlast> {
  // YOUR REAL ADMOB IDs
  final bannerId = 'ca-app-pub-8958880890825501/4208049689';
  final interstitialId = 'ca-app-pub-8958880890825501/4897569969';
  final rewardedId = 'ca-app-pub-8958880890825501/5325690237';

  BannerAd? banner;
  InterstitialAd? interstitial;
  RewardedAd? rewarded;
  int score = 0;
  int gameCount = 0;
  List<List<int>> board = List.generate(10, (_) => List.filled(10, 0));

  @override
  void initState() {
    super.initState();
    banner = BannerAd(adUnitId: bannerId, size: AdSize.banner, request: AdRequest(), listener: BannerAdListener())..load();
    InterstitialAd.load(adUnitId: interstitialId, request: AdRequest(), adLoadCallback: InterstitialAdLoadCallback(onAdLoaded: (ad)=> interstitial=ad, onAdFailedToLoad: (_){}));
    RewardedAd.load(adUnitId: rewardedId, request: AdRequest(), rewardedAdLoadCallback: RewardedAdLoadCallback(onAdLoaded: (ad)=> rewarded=ad, onAdFailedToLoad: (_){}));
  }

  void placeRandom() {
    setState(() {
      board[Random().nextInt(10)][Random().nextInt(10)] = 1;
      score += 10;
      // check clear logic
      for(int i=0;i<10;i++){
        if(board[i].every((e)=> e==1)){ board[i]=List.filled(10,0); score+=100; }
        if(List.generate(10, (r)=> board[r][i]).every((e)=> e==1)){ for(int r=0;r<10;r++) board[r][i]=0; score+=100; }
      }
    });
  }

  void onGameOver() {
    gameCount++;
    if(gameCount%2==0){ interstitial?.show(); InterstitialAd.load(adUnitId: interstitialId, request: AdRequest(), adLoadCallback: InterstitialAdLoadCallback(onAdLoaded: (ad)=> interstitial=ad, onAdFailedToLoad: (_){})); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1a1a2e),
      appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Block Blast • $score', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      bottomNavigationBar: banner!=null? Container(height: 50, color: Colors.black, child: AdWidget(ad: banner!)) : null,
      body: Column(
        children: [
          SizedBox(height: 10),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(8),
              child: GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 10, crossAxisSpacing: 2, mainAxisSpacing: 2), itemCount: 100, itemBuilder: (_,i){
                int r=i~/10,c=i%10; return Container(decoration: BoxDecoration(color: board[r][c]==1? Colors.cyanAccent : Colors.white10, borderRadius: BorderRadius.circular(4)));
              }),
            ),
          ),
          Padding(padding: EdgeInsets.all(20), child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            ElevatedButton(onPressed: placeRandom, child: Text('Place Block')),
            ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.orange), onPressed: (){ rewarded?.show(onUserEarnedReward: (a,r){ setState(()=> score+=100); }); }, child: Text('Continue +100')),
            ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.red), onPressed: (){ onGameOver(); setState(()=> board=List.generate(10, (_)=> List.filled(10,0))); }, child: Text('Game Over')),
          ])),
        ],
      ),
    );
  }
}