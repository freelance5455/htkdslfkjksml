import 'package:flutter/material.dart';

void main() {
  runApp(const ObedyMovieApp());
}

class ObedyMovieApp extends StatelessWidget {
  const ObedyMovieApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Colors.amber,
      ),
      home: const SplashScreen(),
    );
  }
}

// ================= UKURASA WA KWANZA (SPLASH SCREEN) =================
class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.movie_filter, size: 100, color: Colors.amber),
            const SizedBox(height: 20),
            const Text(
              'OBEDY WORLD MOVIE BANK',
              style: TextStyle(
                fontSize: 24, 
                fontWeight: FontWeight.bold, 
                color: Colors.amber,
                letterSpacing: 1.2,
              ),
            ),
            const Text(
              'Quality Entertainment Services',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 50),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: () {
                // Amri ya kufungua Ukurasa wa Nyumbani
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                );
              },
              child: const Text(
                'ANZA', 
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================= UKURASA WA NYUMBANI (HOME SCREEN) =================
class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Mfano wa data za filamu zitakazoonekana kwenye App yako
    final List<Map<String, String>> movies = [
      {"title": "The Equalizer 3", "category": "Action", "year": "2023"},
      {"title": "Extraction 2", "category": "Action / Thriller", "year": "2023"},
      {"title": "John Wick 4", "category": "Action", "year": "2023"},
      {"title": "Avatar: Way of Water", "category": "Sci-Fi", "year": "2022"},
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'OBEDY MOVIE BANK',
          style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.person, color: Colors.amber),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. SEHEMU YA KUTAFUTA (SEARCH BAR)
              TextField(
                decoration: InputDecoration(
                  hintText: 'Tafuta movie unayoitaka...',
                  hintStyle: const TextStyle(color: Colors.grey),
                  prefixIcon: const Icon(Icons.search, color: Colors.amber),
                  filled: true,
                  fillColor: Colors.grey[900],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // 2. BANGO LA MOVIE KUBWA (FEATURED BANNER)
              Container(
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  color: Colors.amber.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.amber, width: 1),
                ),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.local_fire_department, color: Colors.amber, size: 40),
                      SizedBox(height: 10),
                      Text(
                        'MOVIE MPYA KILA SIKU!',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.amber),
                      ),
                      Text('Streaming & Delivery ya Uhakika', style: TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // 3. KATEGORIA (CATEGORIES)
              const Text(
                'Kategoria',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.amber),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: ['Zote', 'Action', 'Bongo Movie', 'Drama', 'Series'].map((cat) {
                    return Container(
                      margin: const EdgeInsets.only(right: 10),
                      child: Chip(
                        backgroundColor: cat == 'Zote' ? Colors.amber : Colors.grey[900],
                        label: Text(cat, style: TextStyle(color: cat == 'Zote' ? Colors.black : Colors.white)),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 25),

              // 4. LIST YA FILAMU (MOVIES LIST)
              const Text(
                'Filamu Zinazovuma',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.amber),
              ),
              const SizedBox(height: 15),
              
              // Hapa tunatengeneza muonekano wa gridi (picha mbili mbili)
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: movies.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                ),
                itemBuilder: (context, index) {
                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Sehemu ya kuweka picha ya Movie baadaye
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.1),
                              borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
                            ),
                            child: const Center(
                              child: Icon(Icons.image, color: Colors.grey, size: 50),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                movies[index]["title"]!,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "${movies[index]["category"]} • ${movies[index]["year"]}",
                                style: const TextStyle(color: Colors.grey, fontSize: 11),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
