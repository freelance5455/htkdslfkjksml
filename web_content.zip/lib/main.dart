import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: AppGatekeeper(),
    ));

class AppGatekeeper extends StatefulWidget {
  @override
  _AppGatekeeperState createState() => _AppGatekeeperState();
}

class _AppGatekeeperState extends State<AppGatekeeper> {
  @override
  void initState() {
    super.initState();
    checkLoginStatus();
  }

  void checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('tomtom_token');
    if (token != null) {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => MainMapScreen(token: token)));
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;

  void login() async {
    if (emailController.text.isEmpty || passwordController.text.isEmpty) {
      showError('⚠️ Παρακαλώ συμπληρώστε όλα τα πεδία.');
      return;
    }
    setState(() => isLoading = true);
    final url = Uri.parse('https://tomtom.com');
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "username": emailController.text.trim(),
          "password": passwordController.text.trim(),
        }),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String token = data['accessToken'] ?? '';
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('tomtom_token', token);
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => MainMapScreen(token: token)));
      } else {
        showError('❌ Λάθος στοιχεία σύνδεσης. Δοκιμάστε ξανά.');
      }
    } catch (e) {
      showError('❌ Αποτυχία σύνδεσης στο δίκτυο.');
    } finally {
      setState(() => isLoading = false);
    }
  }

  void showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("TomTom Truck Bridge Login")),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.local_shipping, size: 80, color: Colors.blue),
            SizedBox(height: 20),
            TextField(
                controller: emailController,
                decoration: InputDecoration(
                    labelText: "Email (TomTom Account)",
                    border: OutlineInputBorder())),
            SizedBox(height: 15),
            TextField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                    labelText: "Password", border: OutlineInputBorder())),
            SizedBox(height: 25),
            isLoading
                ? CircularProgressIndicator()
                : SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue),
                      onPressed: login,
                      child: Text("ΣΥΝΔΕΣΗ & ΑΠΟΘΗΚΕΥΣΗ",
                          style: TextStyle(fontSize: 16, color: Colors.white)),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

class MainMapScreen extends StatefulWidget {
  final String token;
  MainMapScreen({required this.token});
  @override
  _MainMapScreenState createState() => _MainMapScreenState();
}

class _MainMapScreenState extends State<MainMapScreen> {
  final MapController mapController = MapController();
  final TextEditingController searchController = TextEditingController();
  List<Marker> markers = [];
  final String apiKey = "oYzLVSIHDMGju0dkyl7W40106vxfnF8l";

  @override
  void initState() {
    super.initState();
    loadTomTomFavorites();
  }

  void loadTomTomFavorites() async {
    final url = Uri.parse('https://tomtom.com');
    try {
      final response = await http
          .get(url, headers: {"Authorization": "Bearer ${widget.token}"});
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List places = data['results'] ?? [];
        setState(() {
          markers = places.map((place) {
            LatLng pos =
                LatLng(place['position']['lat'], place['position']['lon']);
            return Marker(
              point: pos,
              width: 40,
              height: 40,
              child: IconButton(
                icon: Icon(Icons.star, color: Colors.amber, size: 30),
                onPressed: () =>
                    showConfirmDialog(pos, place['name'] ?? "Αγαπημένο"),
              ),
            );
          }).toList();
        });
      }
    } catch (e) {
      print("Error loading favorites: $e");
    }
  }

  void searchAddress() async {
    if (searchController.text.isEmpty) return;
    final url = Uri.parse(
        'https://tomtom.com{Uri.encodeComponent(searchController.text)}.json?key=$apiKey');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null && data['results'].isNotEmpty) {
          final firstResult = data['results'];
          LatLng newPos = LatLng(
              firstResult['position']['lat'], firstResult['position']['lon']);
          mapController.move(newPos, 14.0);
          setState(() {
            markers.add(Marker(
              point: newPos,
              width: 40,
              height: 40,
              child: Icon(Icons.location_on, color: Colors.red, size: 35),
            ));
          });
          showConfirmDialog(newPos,
              firstResult['address']['freeformAddress'] ?? "Προορισμός");
        }
      }
    } catch (e) {
      print("Search error: $e");
    }
  }

  void sendToDevice(LatLng point, String locationName) async {
    final url = Uri.parse('https://tomtom.com');
    try {
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${widget.token}"
        },
        body: jsonEncode({
          "destination": {
            "latitude": point.latitude,
            "longitude": point.longitude,
            "name": locationName
          }
        }),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            backgroundColor: Colors.green,
            content: Text('✅ Στάλθηκε επιτυχώς στο TomTom Truck 5000!')));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            backgroundColor: Colors.red,
            content: Text('❌ Αποτυχία αποστολής στη συσκευή.')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor: Colors.red, content: Text('❌ Σφάλμα δικτύου.')));
    }
  }

  void showConfirmDialog(LatLng point, String title) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text("Θέλετε να στείλετε αυτόν τον προορισμό στο φορτηγό;"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: Text("ΑΚΥΡΩΣΗ")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            onPressed: () {
              Navigator.pop(context);
              sendToDevice(point, title);
            },
            child: Text("ΑΠΟΣΤΟΛΗ", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          FlutterMap(
            mapController: mapController,
            options: MapOptions(
              initialCenter: LatLng(37.9838, 23.7275),
              initialZoom: 12.0,
              onLongPress: (tapPosition, point) =>
                  showConfirmDialog(point, "Επιλεγμένο σημείο χάρτη"),
            ),
            children: [
              TileLayer(
                  urlTemplate: 'https://openstreetmap.org{z}/{x}/{y}.png'),
              MarkerLayer(markers: markers),
            ],
          ),
          Positioned(
            top: 50,
            left: 15,
            right: 15,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: searchController,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                          hintText: "Εισαγωγή διεύθυνσης...",
                          hintStyle: TextStyle(color: Colors.white54),
                          border: InputBorder.none),
                      onSubmitted: (_) => searchAddress(),
                    ),
                  ),
                  IconButton(
                      icon: Icon(Icons.search, color: Colors.blue),
                      onPressed: searchAddress),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
