// PromptVerse — اپ Flutter با WebView + SDK رسمی Adivery
// رابط کاربری همان index.html است (assets/web). تبلیغ از طریق پل جاوااسکریپت اجرا می‌شود.

import 'dart:convert';

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// کلید اپلیکیشن Adivery (com.aniya.prompt)
const String kAdiveryAppId = 'f05ab4a7-8e2d-456b-b638-ce7bd79c1feb';

/// شناسه جایگاه تبلیغ پاداشی (Rewarded) از پنل Adivery.
/// ⚠️ تا وقتی خالی است، تبلیغی نمایش داده نمی‌شود و طبق سیاست ads.js عمل می‌شود.
const String kRewardedPlacementId = '';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PromptVerseApp());
}

class PromptVerseApp extends StatelessWidget {
  const PromptVerseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PromptVerseHome(),
    );
  }
}

class PromptVerseHome extends StatefulWidget {
  const PromptVerseHome({super.key});

  @override
  State<PromptVerseHome> createState() => _PromptVerseHomeState();
}

class _PromptVerseHomeState extends State<PromptVerseHome> {
  late final WebViewController _controller;
  bool _showing = false;

  @override
  void initState() {
    super.initState();
    _initAds();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0F0B1E))
      ..addJavaScriptChannel('AdBridge', onMessageReceived: _onAdMessage)
      ..addJavaScriptChannel('NativeCopy', onMessageReceived: (msg) {
        Clipboard.setData(ClipboardData(text: msg.message));
      })
      ..loadFlutterAsset('assets/web/index.html');
  }

  /// آماده‌سازی SDK و تبلیغ پاداشی
  void _initAds() {
    try {
      AdiveryPlugin.initialize(kAdiveryAppId);
      if (kRewardedPlacementId.isNotEmpty) {
        AdiveryPlugin.prepareRewardedAd(kRewardedPlacementId);
      }
      AdiveryPlugin.addListener(
        onError: (String placement, String error) {
          if (_showing) {
            _showing = false;
            _sendResult('error');
          }
        },
        onRewardedLoaded: (String placement) {},
        onRewardedClosed: (String placement, bool isRewarded) {
          _showing = false;
          _sendResult(isRewarded ? 'completed' : 'dismissed');
        },
      );
    } catch (_) {
      // خطای SDK نباید برنامه را از کار بیندازد
    }
  }

  /// پیام‌های صفحه HTML (ads.js)
  Future<void> _onAdMessage(JavaScriptMessage msg) async {
    try {
      final data = jsonDecode(msg.message) as Map<String, dynamic>;
      if (data['type'] != 'showRewarded') return;

      if (_showing) {
        _sendResult('error');
        return;
      }
      if (kRewardedPlacementId.isEmpty) {
        _sendResult('unavailable');
        return;
      }

      final loaded = await AdiveryPlugin.isLoaded(kRewardedPlacementId);
      if (loaded == true) {
        _showing = true;
        AdiveryPlugin.show(kRewardedPlacementId);
      } else {
        AdiveryPlugin.prepareRewardedAd(kRewardedPlacementId);
        _sendResult('unavailable');
      }
    } catch (_) {
      _showing = false;
      _sendResult('error');
    }
  }

  /// ارسال نتیجه به ads.js
  void _sendResult(String status) {
    _controller.runJavaScript(
        'window.PromptAds && window.PromptAds._nativeResult(${jsonEncode(status)});');
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        if (await _controller.canGoBack()) {
          _controller.goBack();
        } else {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0F0B1E),
        body: SafeArea(child: WebViewWidget(controller: _controller)),
      ),
    );
  }
}
