from playwright.sync_api import sync_playwright
import json, time
from pathlib import Path
base=(Path(__file__).resolve().parent/'WEB_FILES'/'index.html').as_uri()
results=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for mode in ['home','manager','department']:
        page=browser.new_page(viewport={'width':412,'height':915}, device_scale_factor=1)
        errors=[]; failed=[]
        page.on('pageerror',lambda e: errors.append(str(e)))
        page.on('requestfailed',lambda r: failed.append({'url':r.url,'error':r.failure}))
        response=page.goto(base+'?mode='+mode,wait_until='networkidle',timeout=30000)
        page.wait_for_timeout(500)
        results.append({
          'mode':mode,
          'http_status':response.status if response else None,
          'title':page.title(),
          'body_mode':page.locator('body').get_attribute('data-mode'),
          'css_loaded':page.evaluate("Array.from(document.styleSheets).some(s => (s.href||'').includes('style.css'))"),
          'script_loaded':page.evaluate("Array.from(document.scripts).some(s => (s.src||'').includes('script.js'))"),
          'body_text_length':len(page.locator('body').inner_text()),
          'page_errors':errors,
          'request_failures':failed,
        })
        page.close()
    browser.close()
print(json.dumps(results,ensure_ascii=False,indent=2))
assert all(r['http_status']==200 and r['css_loaded'] and r['script_loaded'] and not r['page_errors'] and not r['request_failures'] for r in results)
