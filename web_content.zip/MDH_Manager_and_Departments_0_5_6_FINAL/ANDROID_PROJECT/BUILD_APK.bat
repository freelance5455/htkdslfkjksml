@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%
if not exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo ERROR: APK file was not created.
  exit /b 2
)
echo APK created: %CD%\app\build\outputs\apk\debug\app-debug.apk
endlocal
