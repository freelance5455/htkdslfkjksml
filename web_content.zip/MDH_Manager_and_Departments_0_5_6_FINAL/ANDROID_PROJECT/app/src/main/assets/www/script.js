(function(){
  'use strict';
  var requested = new URLSearchParams(window.location.search).get('mode') || 'home';
  var mode = ['home','department','manager'].includes(requested) ? requested : 'home';
  document.body.dataset.mode = mode;
  var template = document.getElementById('mdh-' + mode);
  if (!template) throw new Error('واجهة التشغيل المطلوبة غير موجودة داخل ملف البرنامج.');
  document.body.appendChild(template.content.cloneNode(true));
  document.title = mode === 'department'
    ? 'تسجيل القسم | مستشفى الضالع الحديث'
    : mode === 'manager'
      ? 'لوحة المدير | مستشفى الضالع الحديث'
      : 'نظام مستشفى الضالع الحديث';
})();


/* ---- Original script block 2 ---- */


(function () {
    if (!window.MDHAndroid || window.__mdhAndroidBridgeReady) return;
    window.__mdhAndroidBridgeReady = true;

    const nativeCreateObjectURL = URL.createObjectURL.bind(URL);
    const nativeRevokeObjectURL = URL.revokeObjectURL.bind(URL);
    const blobUrls = new Map();

    URL.createObjectURL = function (blob) {
        const url = nativeCreateObjectURL(blob);
        blobUrls.set(url, blob);
        return url;
    };

    URL.revokeObjectURL = function (url) {
        blobUrls.delete(url);
        return nativeRevokeObjectURL(url);
    };

    function blobToBase64(blob) {
        return new Promise(function (resolve, reject) {
            const reader = new FileReader();
            reader.onload = function () {
                try {
                    resolve(String(reader.result).split(",")[1] || "");
                } catch (error) {
                    reject(error);
                }
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    const nativeAnchorClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
        const blob = blobUrls.get(this.href) || blobUrls.get(this.getAttribute("href"));
        if (this.download && blob) {
            const filename = this.download || "MDH_file";
            const mimeType = blob.type || "application/octet-stream";
            blobToBase64(blob)
                .then(function (base64) {
                    window.MDHAndroid.saveFile(filename, mimeType, base64);
                })
                .catch(function () {
                    alert("تعذر تجهيز الملف للحفظ على الهاتف.");
                });
            return;
        }
        return nativeAnchorClick.call(this);
    };

    function canShareFiles(data) {
        return !!(data && data.files && data.files.length === 1 && window.MDHAndroid);
    }

    async function shareFiles(data) {
        if (!canShareFiles(data)) {
            throw new TypeError("لا يوجد ملف صالح للمشاركة");
        }
        const file = data.files[0];
        const base64 = await blobToBase64(file);
        window.MDHAndroid.shareFile(
            file.name || "MDH_report.json",
            file.type || "application/octet-stream",
            base64
        );
    }

    try {
        Object.defineProperty(navigator, "canShare", {
            configurable: true,
            value: canShareFiles
        });
    } catch (error) {
        try { navigator.canShare = canShareFiles; } catch (ignored) { }
    }

    try {
        Object.defineProperty(navigator, "share", {
            configurable: true,
            value: shareFiles
        });
    } catch (error) {
        try { navigator.share = shareFiles; } catch (ignored) { }
    }

    window.print = function () {
        window.MDHAndroid.printPage();
    };
})();



/* ---- Original script block 3 ---- */


(function(root){'use strict';
  const collections=['cases','activity','assessments','finance','issues','feedback','departmentStats','attachments'];
  const labels={cases:'الحالات',activity:'مؤشرات العمل',assessments:'تقييم الإجراءات',finance:'حركات الصناديق',issues:'المشكلات والاحتياجات',feedback:'الشكاوى والمقترحات',departmentStats:'الإحصاءات التخصصية',attachments:'المرفقات والوثائق'};
  const num=v=>Number.isFinite(Number(v))?Number(v):0;
  const uid=()=>root.crypto?.randomUUID?root.crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);
  function validDate(s){return /^\d{4}-\d{2}-\d{2}$/.test(String(s||''))&&!Number.isNaN(Date.parse(s))}
  function validateDailyReport(p){
    if(!p||!['MDH-DAY-1','MDH-DAY-2'].includes(p.schema)||p.kind!=='department-daily-report'||!p.meta?.department||!validDate(p.meta?.date)||!p.records||typeof p.records!=='object')throw new Error('صيغة الملف غير معتمدة أو بيانات القسم والتاريخ ناقصة.');
    for(const k of collections){if(p.records[k]!==undefined&&!Array.isArray(p.records[k]))throw new Error('قسم البيانات '+labels[k]+' غير صالح.');}
    if(!p.exportId||String(p.exportId).length>160)throw new Error('معرّف ملف التقرير مفقود أو غير صالح.');
    return true;
  }
  function emptyMaster(){return {schema:'MDH-MASTER-2',imports:[],reports:[],cases:[],activity:[],assessments:[],finance:[],issues:[],feedback:[],departmentStats:[],attachments:[]}}
  function openFileDB(dbName){
    if(!root.indexedDB) return Promise.reject(new Error('تخزين الملفات غير مدعوم في هذا الجهاز أو WebView.'));
    return new Promise((resolve,reject)=>{const req=root.indexedDB.open(dbName,1);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('files'))db.createObjectStore('files',{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('تعذر فتح مخزن الملفات.'));});
  }
  async function putFile(dbName,id,blob,meta={}){const db=await openFileDB(dbName);return new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').put({id:String(id),blob,name:meta.name||'',type:meta.type||blob.type||'application/octet-stream',size:meta.size??blob.size??0});tx.oncomplete=()=>{db.close();resolve(true)};tx.onerror=()=>{const e=tx.error;db.close();reject(e||new Error('تعذر حفظ الملف.'))};tx.onabort=()=>{const e=tx.error;db.close();reject(e||new Error('تم إلغاء حفظ الملف.'))};});}
  async function getFile(dbName,id){const db=await openFileDB(dbName);return new Promise((resolve,reject)=>{const tx=db.transaction('files','readonly'),req=tx.objectStore('files').get(String(id));req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error||new Error('تعذر قراءة الملف.'));tx.oncomplete=()=>db.close();tx.onerror=()=>{const e=tx.error;db.close();reject(e||new Error('تعذر قراءة مخزن الملفات.'))};});}
  async function deleteFile(dbName,id){const db=await openFileDB(dbName);return new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').delete(String(id));tx.oncomplete=()=>{db.close();resolve(true)};tx.onerror=()=>{const e=tx.error;db.close();reject(e||new Error('تعذر حذف الملف.'))};});}
  function blobToDataUrl(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(reader.error||new Error('تعذر تجهيز الملف للنقل.'));reader.readAsDataURL(blob)});}
  function dataUrlToBlob(dataUrl){const m=String(dataUrl||'').match(/^data:([^;,]+)?(;base64)?,(.*)$/s);if(!m)throw new Error('بيانات المرفق غير صالحة.');const mime=m[1]||'application/octet-stream';if(m[2]){const raw=atob(m[3]);const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return new Blob([bytes],{type:mime})}return new Blob([decodeURIComponent(m[3])],{type:mime});}
  function importReport(db,p){
    validateDailyReport(p);
    if(db.imports.some(x=>x.exportId===p.exportId))return {duplicate:true,dept:p.meta.department};
    const reportId=p.exportId,dept=p.meta.department,date=p.meta.date,counts={},duplicates={};
    for(const k of collections){let added=0,dups=0;for(const row of (p.records[k]||[])){const id=String(row?.id||'');if(!id){dups++;continue;}if(!db[k].some(x=>x.id===id)){const clean={...row};if(k==='attachments'){delete clean.dataUrl;delete clean.base64;delete clean.fileData;}db[k].push({...clean,sourceReport:reportId,sourceDepartment:dept,reportDate:date});added++;}else dups++;}counts[k]=added;duplicates[k]=dups;}
    const rec={exportId:reportId,department:dept,date,officer:p.meta.officer||'',shift:p.meta.shift||'اليومي',branchId:p.meta.branchId||'main',branchName:p.meta.branchName||'الفرع الرئيسي',importedAt:new Date().toISOString(),counts,duplicates,departmentProfile:p.departmentProfile||null,departmentProcedures:p.summary?.departmentProcedures||null,dailySummary:p.records?.departmentSummary||p.dailySummary||null,departmentOperations:p.records?.departmentOperations||null,reviewStatus:'قيد المراجعة',managerDecisionNote:'',managerDecisionAt:null};
    db.imports.push(rec);db.reports.push({...rec});
    return {duplicate:false,dept,counts,duplicates};
  }
  function runningBalances(rows){
    const sorted=[...(rows||[])].sort((a,b)=>String(a.date||a.reportDate||'').localeCompare(String(b.date||b.reportDate||''))||String(a.createdAt||'').localeCompare(String(b.createdAt||'')));
    const running={};
    return sorted.map(r=>{const key=(r.box||'بدون اسم')+'||'+(r.currency||'غير محدد');running[key]=(running[key]||0)+num(r.debit)-num(r.credit);return {...r,runningBalance:running[key]};});
  }
  function summarizeFinance(rows){
    const groups={};for(const r of rows||[]){const key=(r.box||'بدون اسم')+'||'+(r.currency||'غير محدد');groups[key]??={box:r.box||'بدون اسم',currency:r.currency||'غير محدد',debit:0,credit:0,net:0};groups[key].debit+=num(r.debit);groups[key].credit+=num(r.credit);groups[key].net=groups[key].debit-groups[key].credit;}return Object.values(groups);
  }
  root.MDHTransferCore={collections,labels,emptyMaster,validDate,validateDailyReport,importReport,runningBalances,summarizeFinance,putFile,getFile,deleteFile,blobToDataUrl,dataUrlToBlob};
})(typeof window!=='undefined'?window:globalThis);



/* ---- Original script block 4 ---- */


(()=>{'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
function mdhConfirm(message,title='تأكيد الإجراء'){
 const modal=$('#mdhConfirmModal');if(!modal)return Promise.resolve(window.confirm(message));
 $('#mdhConfirmTitle').textContent=title;$('#mdhConfirmMessage').textContent=message;modal.hidden=false;
 return new Promise(resolve=>{const yes=$('#mdhConfirmYes'),no=$('#mdhConfirmNo');const finish=value=>{modal.hidden=true;yes.onclick=null;no.onclick=null;modal.removeEventListener('click',backdrop);resolve(value)};const backdrop=e=>{if(e.target===modal)finish(false)};yes.onclick=()=>finish(true);no.onclick=()=>finish(false);modal.addEventListener('click',backdrop);no.focus()});
}
window.MDHConfirm=mdhConfirm;
const today=()=>new Date().toISOString().slice(0,10);
const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const read=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const write=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const formObj=f=>Object.fromEntries(new FormData(f).entries());
const num=v=>Number.isFinite(Number(v))?Number(v):0;
const dateName=d=>String(d||today()).replaceAll('-','');
const DEPTS=['الطوارئ','الرقود','العيادات الخارجية','المختبر','الأشعة','الصيدلية','العمليات','العناية المركزة','المناظير','التمريض','الاستقبال والملفات','الموارد البشرية','النظافة والتعقيم','الصيانة','الأمن','المخازن والمشتريات','الحسابات والصناديق','الإدارة والخدمات','الصندوق','الاستعلامات','المحاسب'];
const DEPT_PROFILES={
'الطوارئ':['تسجيل وفرز الحالات الواردة','توثيق الحالات والإجراءات المنفذة','متابعة الإحالات والتحويلات','تنظيم تسليم واستلام النوبات','متابعة جاهزية التجهيزات والمستلزمات','توثيق المعوقات والبلاغات اليومية'],
'الرقود':['تحديث حركة دخول وخروج المرضى','متابعة إشغال الأسرة وتوفرها','توثيق تسليم واستلام النوبات','متابعة طلبات الخدمات والمستلزمات','متابعة النظافة وتجهيز الغرف','توثيق التحويلات والملاحظات اليومية'],
'العيادات الخارجية':['تنظيم التسجيل والمواعيد','متابعة تشغيل العيادات حسب الجدول','توثيق أعداد المراجعين والخدمات','متابعة الإحالات والمواعيد المؤجلة','متابعة احتياجات العيادات','تسجيل ملاحظات وشكاوى المراجعين'],
'المختبر':['تسجيل واستلام العينات','مطابقة بيانات العينة وطلب الفحص','توثيق الفحوصات المنفذة','مراجعة واعتماد وتسليم النتائج وفق الصلاحيات','متابعة سجلات ضبط الجودة المعتمدة','متابعة جاهزية الأجهزة والمواد والكواشف'],
'الأشعة':['تسجيل طلبات الفحوصات','التحقق من بيانات الطلب والمراجع','توثيق الفحوصات المنفذة','تسليم التقارير والنتائج للجهة المعنية','متابعة جاهزية أجهزة التصوير','متابعة تطبيق تعليمات السلامة المعتمدة'],
'الصيدلية':['تسجيل استلام وصرف الأدوية','متابعة أرصدة الأصناف','مراجعة تواريخ الصلاحية','تحديد الأصناف الناقصة والاحتياج','توثيق المرتجعات والتالف','متابعة ظروف الحفظ حسب سياسة المستشفى'],
'العمليات':['تنظيم جدول العمليات','متابعة جاهزية غرفة العمليات','توثيق العمليات والإجراءات المنفذة','متابعة قوائم التحقق المعتمدة','متابعة تجهيز وتعقيم الأدوات','توثيق احتياجات وملاحظات التشغيل'],
'العناية المركزة':['تحديث إشغال الأسرة والحالات','متابعة جاهزية أجهزة المراقبة والدعم','توثيق الخدمات والإجراءات اليومية','متابعة توفر المستلزمات','تنظيم تسليم واستلام النوبات','توثيق الأعطال والاحتياجات'],
'المناظير':['تنظيم مواعيد وإجراءات المناظير','تسجيل الإجراءات المنفذة','متابعة جاهزية وحدات وأجهزة المناظير','توثيق تسليم النتائج والتقارير','متابعة التنظيف وإعادة المعالجة حسب السياسة','متابعة المستلزمات والاحتياجات'],
'التمريض':['متابعة توزيع الكادر والورديات','توثيق تسليم واستلام النوبات','متابعة سجلات التمريض','متابعة طلبات المستلزمات','توثيق البلاغات والملاحظات','متابعة تطبيق سياسات مكافحة العدوى المعتمدة'],
'الاستقبال والملفات':['تسجيل المراجعين وفتح الملفات','تحديث بيانات الملفات','تنظيم حركة الملفات والأرشفة','توثيق الإحالات والتحويلات','متابعة سرية وحفظ الملفات','إعداد إحصاء المراجعين اليومي'],
'الموارد البشرية':['تحديث الحضور والانصراف','متابعة تغطية المناوبات والغياب','توثيق الإجازات والتكليفات','تحديث ملفات الموظفين','متابعة طلبات واحتياجات الأقسام','إعداد الملاحظات والتقارير الإدارية'],
'النظافة والتعقيم':['متابعة جدول النظافة اليومي','توثيق تنفيذ جولات النظافة','متابعة جمع وفرز النفايات حسب السياسة','متابعة تشغيل منطقة التعقيم','توثيق سجلات دورات التعقيم المعتمدة','متابعة توفر مواد النظافة والتعقيم'],
'الصيانة':['تسجيل طلبات الصيانة الواردة','تصنيف الأعطال وتحديد الأولوية','توثيق أعمال الإصلاح المنفذة','فحص التشغيل بعد الإصلاح','تحديث سجل الأجهزة والأصول','متابعة قطع الغيار والاحتياجات'],
'الأمن':['متابعة سجل الدخول والخروج','تنظيم دخول الزوار والموردين','متابعة جولات الحراسة','توثيق الحوادث والبلاغات','متابعة جاهزية وسائل الأمن','رفع الملاحظات والإجراءات المتخذة'],
'المخازن والمشتريات':['تسجيل استلام الأصناف','توثيق صرف الأصناف للأقسام','تحديث أرصدة المخزون','متابعة الجرد والفروقات','متابعة طلبات الشراء والتوريد','تحديد الأصناف الحرجة والناقصة'],
'الحسابات والصناديق':['مطابقة رصيد الصندوق','تسجيل الإيرادات والمقبوضات','تسجيل المصروفات والمدفوعات','مراجعة السندات والمستندات','توثيق الإيداعات والتسويات','إعداد ملخص الحركة والرصيد اليومي'],
'الإدارة والخدمات':['متابعة استلام تقارير الأقسام','متابعة تنفيذ التكليفات','توثيق الاجتماعات والقرارات','متابعة خدمات التشغيل والمرافق','متابعة معالجة المعوقات','مراجعة مؤشرات الأداء والاحتياجات'],
'الصندوق':['مطابقة الرصيد الافتتاحي والختامي','تسجيل المقبوضات والصرفيات','توثيق المرتجعات والمشتريات','مراجعة السندات والمستندات','إقفال الصندوق وجرد النقد','توثيق فروقات الصندوق'],
'الاستعلامات':['استقبال الاستفسارات وتوجيه المراجعين','تسجيل معاملات الرسوم والإيصالات','متابعة الطلبات المحالة','توثيق المقبوضات والصرفيات المرتبطة بالخدمة','متابعة المعاملات المعلقة','إقفال وتسليم سجل النوبة'],
'المحاسب':['مراجعة المستندات والسندات','تسجيل المقبوضات والصرفيات','مطابقة المدين والدائن','مراجعة المرتجعات والمشتريات','مطابقة أرصدة الصناديق','إعداد ملخص الحساب اليومي'],
};
const DEPT_DAILY_FIELDS={"الطوارئ":[["triageCount","عدد حالات الفرز","number"],["criticalCount","الحالات الحرجة","number"],["transferredCount","الإحالات والتحويلات","number"],["shiftDoctor","دكتور النوبة","text"],["shiftNurse","ممرض النوبة","text"],["handoverNotes","ملاحظات الاستلام والتسليم","textarea"]],"العيادات الخارجية":[["clinicCount","عدد المراجعين","number"],["clinicsOperating","العيادات العاملة","text"],["delayedAppointments","المواعيد المؤجلة","number"],["shiftDoctor","الطبيب المناوب / مسؤول العيادات","text"],["nurse","الممرض المسؤول","text"],["notes","ملاحظات التشغيل","textarea"]],"الرقود":[["occupiedBeds","الأسرة المشغولة","number"],["admissions","حالات الدخول","number"],["discharges","حالات الخروج","number"],["transfers","التحويلات","number"],["shiftDoctor","دكتور النوبة","text"],["shiftNurse","ممرض النوبة","text"],["handoverNotes","ملاحظات الاستلام والتسليم","textarea"]],"العمليات":[["plannedOperations","العمليات المجدولة","number"],["completedOperations","العمليات المنفذة","number"],["cancelledOperations","العمليات المؤجلة / الملغاة","number"],["operatingRoomsReady","غرف العمليات الجاهزة","number"],["shiftDoctor","جرّاح / دكتور النوبة","text"],["nurse","ممرض العمليات المسؤول","text"],["handoverNotes","ملاحظات الاستلام والتسليم","textarea"]],"المناظير":[["plannedProcedures","إجراءات المناظير المجدولة","number"],["completedProcedures","إجراءات المناظير المنفذة","number"],["cancelledProcedures","الإجراءات المؤجلة","number"],["equipmentReady","جاهزية الأجهزة","text"],["shiftDoctor","دكتور النوبة","text"],["nurse","ممرض المناظير","text"],["handoverNotes","ملاحظات الاستلام والتسليم","textarea"]],"المختبر":[["cashCases","عدد الحالات النقدية","number"],["creditCases","عدد الحالات الآجلة","number"],["insuranceCases","عدد حالات التأمين","number"],["cleanlinessNotes","ملاحظات النظافة","textarea"],["organizationNotes","ملاحظات النظام والترتيب","textarea"],["shiftResponsible","مسؤول النوبة","text"]],"الأشعة":[["requests","طلبات الفحوصات","number"],["completed","الفحوصات المنفذة","number"],["urgent","الفحوصات العاجلة","number"],["reportsDelivered","التقارير المسلمة","number"],["equipmentStatus","حالة الأجهزة","text"],["shiftResponsible","مسؤول النوبة","text"],["notes","ملاحظات السلامة والتشغيل","textarea"]],"الصيدلية":[["prescriptions","الوصفات المستلمة","number"],["dispensed","الوصفات المصروفة","number"],["shortages","الأصناف غير المتوفرة","textarea"],["nearExpiry","أصناف قريبة الانتهاء","textarea"],["returns","المرتجعات / التالف","textarea"],["shiftResponsible","مسؤول النوبة","text"]],"العناية المركزة":[["bedsAvailable","الأسرة المتاحة","number"],["bedsOccupied","الأسرة المشغولة","number"],["admissions","حالات الدخول","number"],["discharges","حالات الخروج","number"],["equipmentStatus","جاهزية أجهزة المراقبة","text"],["shiftDoctor","دكتور النوبة","text"],["shiftNurse","ممرض النوبة","text"],["handoverNotes","ملاحظات الاستلام والتسليم","textarea"]],"التمريض":[["nursesOnDuty","عدد الممرضين المناوبين","number"],["wardsCovered","الأقسام المغطاة","text"],["handoverCompleted","تسليم واستلام النوبات","text"],["shortages","نقص الكادر / المستلزمات","textarea"],["supervisor","مشرف التمريض","text"],["notes","ملاحظات النوبة","textarea"]],"الاستقبال والملفات":[["newFiles","الملفات الجديدة","number"],["visitors","المراجعون المسجلون","number"],["referrals","الإحالات","number"],["missingFiles","الملفات المطلوب استكمالها","number"],["responsible","مسؤول الاستقبال","text"],["notes","ملاحظات الملفات والاستقبال","textarea"]],"الاستعلامات":[["inquiries","عدد الاستعلامات","number"],["directions","حالات الإرشاد والتوجيه","number"],["complaints","الاستفسارات / الشكاوى المحالة","number"],["pending","استعلامات قيد المتابعة","number"],["responsible","موظف الاستعلامات المناوب","text"],["notes","ملاحظات","textarea"]],"الموارد البشرية":[["present","الموظفون الحاضرون","number"],["absent","الغياب","number"],["leave","الإجازات","number"],["coverage","تغطية المناوبات","text"],["responsible","مسؤول الموارد البشرية","text"],["notes","ملاحظات الدوام","textarea"]],"النظافة والتعقيم":[["rounds","جولات النظافة","number"],["completedTasks","المهام المنفذة","number"],["sterilizationCycles","دورات التعقيم المسجلة","number"],["rejectedCycles","الدورات غير المطابقة","number"],["supplies","حالة مواد النظافة والتعقيم","text"],["supervisor","مشرف النوبة","text"],["notes","الملاحظات","textarea"]],"الصيانة":[["requests","طلبات الصيانة","number"],["completed","الأعطال المعالجة","number"],["pending","الأعطال المتبقية","number"],["urgent","الأعطال العاجلة","number"],["technician","الفني المناوب","text"],["notes","تفاصيل الأعمال والملاحظات","textarea"]],"الأمن":[["visitors","الزوار المسجلون","number"],["incidents","الحوادث والبلاغات","number"],["patrols","الجولات الأمنية","number"],["accessIssues","ملاحظات الدخول والخروج","textarea"],["officer","مسؤول النوبة","text"],["notes","ملاحظات","textarea"]],"المخازن والمشتريات":[["received","عمليات الاستلام","number"],["issued","عمليات الصرف","number"],["stockouts","الأصناف المنقطعة","textarea"],["purchaseOrders","طلبات الشراء","number"],["supplier","الشركات / الموردون","text"],["responsible","أمين المخزن المناوب","text"],["notes","ملاحظات","textarea"]],"الإدارة والخدمات":[["reportsReceived","تقارير الأقسام المستلمة","number"],["tasksAssigned","التكليفات الجديدة","number"],["tasksCompleted","التكليفات المنجزة","number"],["pending","التكليفات المتبقية","number"],["responsible","المسؤول المناوب","text"],["notes","ملاحظات الإدارة والخدمات","textarea"]],"الحسابات والصناديق":[["openingBalance","الرصيد الافتتاحي المعتمد","number"],["closingBalance","الرصيد الختامي الفعلي","number"],["reconciliation","حالة المطابقة","text"],["receipts","المقبوضات","number"],["payments","الصرفيات","number"],["accountant","المحاسب المسؤول","text"],["notes","ملاحظات مالية","textarea"]],"الصندوق":[["openingBalance","الرصيد الافتتاحي","number"],["closingBalance","الرصيد الختامي","number"],["cashCount","النقد الفعلي عند الإقفال","number"],["cashDifference","فرق الجرد","number"],["cashier","أمين الصندوق","text"],["notes","ملاحظات الصندوق","textarea"]],"المحاسب":[["openingBalance","الرصيد الافتتاحي","number"],["closingBalance","الرصيد الختامي","number"],["reconciliation","مطابقة الحسابات","text"],["receipts","إجمالي المقبوضات","number"],["payments","إجمالي الصرفيات","number"],["accountant","اسم المحاسب","text"],["notes","ملاحظات المحاسبة","textarea"]]};
const FINANCIAL_DEPARTMENTS=new Set(["الصندوق", "الاستعلامات", "المحاسب", "الحسابات والصناديق"]);
const CLINICAL_REPORT_DEPTS=new Set(["الطوارئ", "العيادات الخارجية", "الرقود", "العمليات", "المناظير"]);
const DAILY_FIELD_LABELS=Object.fromEntries(Object.values(DEPT_DAILY_FIELDS).flat().map(([key,label])=>[key,label]));
const PATIENT_DEPARTMENTS=new Set(['الطوارئ','الرقود','العيادات الخارجية','المختبر','الأشعة','الصيدلية','العمليات','العناية المركزة','المناظير','التمريض','الاستقبال والملفات']);
const CORE=window.MDHTransferCore;
const COLLECTIONS=CORE.collections;
const LABELS=CORE.labels;
function download(name,blob){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000)}
function jsonBlob(v){return new Blob([JSON.stringify(v,null,2)],{type:'application/json;charset=utf-8'})}
function csvDownload(name,rows){const csv='\ufeff'+rows.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n');download(name,new Blob([csv],{type:'text/csv;charset=utf-8'}))}
function emptyData(){return Object.fromEntries(COLLECTIONS.map(k=>[k,[]]))}
function deptKey(dept){return 'mdh_dept_'+(dept||'unit')}
function textOrDash(v){return v==null||v===''?'—':v}
if(document.body.dataset.mode==='department') department();

function department(){
 let currentDept='';
 const OP_WORKFLOWS={
 'الطوارئ':{fields:[['shiftNurse','ممرض النوبة'],['shiftDoctor','دكتور النوبة']],tables:[
  {key:'devices',title:'تسليم واستلام الأجهزة',cols:[['device','اسم الجهاز'],['status','الحالة','select',['شغال','غير شغال','يحتاج صيانة','غير موجود']],['notes','ملاحظات']]},
  {key:'patients',title:'سجل المرضى والإجراءات',cols:[['patientName','اسم المريض'],['gender','الجنس','select',['ذكر','أنثى']],['age','العمر'],['village','القرية'],['diagnosis','التشخيص'],['procedure','الإجراء']]}
 ],notes:[['shortages','ملاحظات النقص'],['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'الرقود':{fields:[['shiftNurse','ممرض النوبة'],['shiftDoctor','دكتور النوبة']],tables:[
  {key:'devices',title:'تسليم واستلام الأجهزة',cols:[['device','اسم الجهاز'],['status','الحالة','select',['شغال','غير شغال','يحتاج صيانة','غير موجود']],['notes','ملاحظات']]},
  {key:'patients',title:'سجل المرضى المنومين',cols:[['patientName','اسم المريض'],['doctor','الدكتور المعالج'],['gender','الجنس','select',['ذكر','أنثى']],['age','العمر'],['village','القرية'],['diagnosis','التشخيص'],['procedure','الإجراء']]}
 ],notes:[['shortages','النقص'],['problems','المشاكل والحلول'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'العيادات الخارجية':{fields:[['shiftNurse','ممرض النوبة'],['shiftDoctor','دكتور / استشاري النوبة']],tables:[
  {key:'devices',title:'تسليم واستلام الأجهزة',cols:[['device','اسم الجهاز'],['status','الحالة','select',['شغال','غير شغال','يحتاج صيانة','غير موجود']],['notes','ملاحظات']]},
  {key:'patients',title:'سجل مراجعي العيادات (يمكن تسجيل عدة عيادات)',cols:[['clinic','اسم العيادة'],['patientName','اسم المريض'],['gender','الجنس','select',['ذكر','أنثى']],['age','العمر'],['village','القرية'],['diagnosis','التشخيص'],['procedure','الإجراء']]}
 ],notes:[['shortages','النقص'],['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'الاستعلامات':{fields:[],tables:[
  {key:'attendance',title:'الموظفون والحضور والانصراف',cols:[['employee','اسم الموظف'],['arrival','وقت الحضور','time'],['departure','وقت الانصراف','time']]},
  {key:'cashboxes',title:'صناديق الموظفين وحركتها',cols:[['employee','اسم الموظف'],['opening','الرصيد الافتتاحي'],['receipts','المقبوضات'],['expenses','المصروفات'],['closing','الرصيد الختامي'],['notes','ملاحظات']]},
  {key:'visits',title:'الزيارات والمعاملات والخصومات',cols:[['description','الزيارة / المعاملة'],['discount','الخصم'],['amount','المبلغ'],['notes','ملاحظات']]},
  {key:'expenses',title:'المصروفات',cols:[['statement','البيان'],['amount','المبلغ'],['employee','الموظف'],['notes','ملاحظات']]}
 ],notes:[['shortages','النواقص'],['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'المختبر':{fields:[['labManager','مدير / مسؤول المختبر'],['internalCash','عدد مرضى المختبر النقدي','number'],['credit','عدد المرضى الآجل','number'],['inpatients','عدد مرضى الرقود','number'],['violations','عدد المخالفات','number']],tables:[
  {key:'attendance',title:'موظفو المختبر والحضور والانصراف',cols:[['employee','اسم الموظف'],['arrival','وقت الحضور','time'],['departure','وقت الانصراف','time']]},
  {key:'expiry',title:'النواقص والأصناف القريبة من الانتهاء والحلول',cols:[['item','الصنف / المادة'],['quantity','الكمية'],['expiry','تاريخ الانتهاء'],['solution','الحل المقترح']]},
  {key:'externalTests',title:'الفحوصات المرسلة خارج المختبر',cols:[['test','اسم الفحص'],['patient','اسم المريض / الرمز'],['destination','الجهة المرسل إليها'],['date','التاريخ','date'],['cost','القيمة'],['notes','ملاحظات']]}
 ],notes:[['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'الصندوق':{fields:[['cashier','أمين الصندوق المسؤول'],['openingBalance','الرصيد الافتتاحي في بداية السنة','number']],tables:[
  {key:'ledger',title:'دفتر حركة الصندوق (مدين / دائن)',cols:[['date','التاريخ','date'],['voucher','رقم السند'],['statement','البيان'],['debit','مدين','number'],['credit','دائن','number'],['balance','الرصيد','number'],['notes','ملاحظات']]}
 ],notes:[['problems','ملاحظات ومشاكل الصندوق']]},
 'الصيدلية':{fields:[['cashier','مسؤول الصندوق'],['openingBalance','الرصيد الافتتاحي للصندوق','number']],tables:[
  {key:'attendance',title:'موظفو النوبات والحضور والانصراف',cols:[['employee','اسم الموظف'],['arrival','وقت الحضور','time'],['departure','وقت الانصراف','time']]},
  {key:'purchases',title:'فواتير الشراء والبونص والموردين',cols:[['supplier','اسم المورد'],['invoice','رقم الفاتورة'],['amount','المبلغ','number'],['bonus','البونص'],['date','التاريخ','date'],['notes','ملاحظات']]},
  {key:'returns',title:'مرتجعات الموردين',cols:[['supplier','اسم المورد'],['item','الصنف'],['quantity','عدد الأصناف'],['amount','المبلغ','number'],['notes','ملاحظات']]},
  {key:'expenses',title:'مصروفات الصيدلية',cols:[['statement','البيان'],['amount','المبلغ','number'],['date','التاريخ','date'],['notes','ملاحظات']]},
  {key:'cash',title:'حركة صندوق الصيدلية',cols:[['date','التاريخ','date'],['statement','البيان'],['debit','مدين','number'],['credit','دائن','number'],['balance','الرصيد','number']]}
 ],notes:[['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'الموارد البشرية':{fields:[],tables:[
  {key:'attendance',title:'سجل الموظفين والحضور والانصراف',cols:[['employee','اسم الموظف'],['arrival','وقت الحضور','time'],['departure','وقت الانصراف','time']]},
  {key:'withdrawals',title:'سحوبات الموظفين',cols:[['employee','اسم الموظف'],['amount','المبلغ','number'],['date','التاريخ','date'],['notes','ملاحظات']]},
  {key:'expiredMedicines',title:'الأدوية منتهية الصلاحية',cols:[['medicine','اسم الدواء'],['quantity','الكمية'],['expiry','تاريخ الانتهاء','date'],['action','الإجراء']]},
  {key:'medicines',title:'الأدوية',cols:[['medicine','اسم الدواء'],['quantity','الكمية'],['employee','الموظف المستلم'],['notes','ملاحظات']]}
 ],notes:[]},
 'المحاسب':{fields:[],tables:[
  {key:'attendance',title:'حضور وانصراف المحاسب / الموظفين',cols:[['employee','اسم الموظف'],['arrival','وقت الحضور','time'],['departure','وقت الانصراف','time']]},
  {key:'creditFollowups',title:'متابعة جميع العمليات الآجلة',cols:[['party','الجهة / المريض'],['reference','رقم المرجع'],['amount','المبلغ','number'],['paid','المسدد','number'],['remaining','المتبقي','number'],['status','حالة المتابعة'],['notes','ملاحظات']]},
  {key:'purchases',title:'المشتريات التشغيلية ومشتريات المختبر',cols:[['type','نوع المشتريات','select',['تشغيلية','مشتريات المختبر']],['supplier','المورد'],['invoice','رقم الفاتورة'],['amount','المبلغ','number'],['date','التاريخ','date'],['notes','ملاحظات']]},
  {key:'evaluations',title:'تقييم العمليات المحاسبية',cols:[['operation','العملية المحاسبية'],['evaluation','التقييم'],['action','الإجراء المتخذ'],['notes','ملاحظات']]}
 ],notes:[['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]},
 'المناظير':{fields:[],tables:[
  {key:'patients',title:'سجل إجراءات المناظير',cols:[['patientName','اسم المريض'],['age','العمر'],['gender','الجنس','select',['ذكر','أنثى']],['village','القرية'],['referringDoctor','الدكتور المحوّل'],['diagnosis','التشخيص'],['nurse','الممرض'],['amount','المبلغ','number'],['sampleValue','قيمة العينة','number'],['scopeType','نوع المنظار','select',['علوي','سفلي','آخر']]]}
 ],notes:[['shortages','النواقص'],['problems','المشاكل'],['requests','الطلبات'],['cleanliness','النظافة'],['security','الأمن']]}
 };
 const OP_DEPT_NAMES=Object.keys(OP_WORKFLOWS);
 let opDraft=null;
 function opDate(){return $('#reportDate')?.value||today()}
 function opSaved(date=opDate()){return (data.departmentOperations||{})[date]||{fields:{},tables:{},notes:{}}}
 function opEscape(v){return esc(v==null?'':String(v))}
 function opFieldMarkup([key,label,type='text'],value=''){return `<label>${esc(label)}<input data-op-field="${esc(key)}" type="${type==='number'?'number':type}" ${type==='number'?'min="0" step="any"':''} value="${opEscape(value)}" /></label>`}
 function opTableMarkup(table,rows=[]){
  const headers=table.cols.map(c=>`<th>${esc(c[1])}</th>`).join('');
  const body=rows.map(row=>`<tr>${table.cols.map(c=>{const [key,label,type,options]=c;let control=type==='select'?`<select data-op-col="${esc(key)}">${(options||[]).map(o=>`<option ${row[key]===o?'selected':''}>${esc(o)}</option>`).join('')}</select>`:`<input data-op-col="${esc(key)}" type="${type==='number'?'number':type==='time'?'time':type==='date'?'date':'text'}" ${type==='number'?'step="any"':''} value="${opEscape(row[key])}"/>`;return `<td>${control}</td>`}).join('')}<td><button type="button" class="btn ghost small" data-op-remove>حذف</button></td></tr>`).join('');
  return `<section class="op-table-block"><div class="op-table-head"><h3>${esc(table.title)}</h3><button type="button" class="btn ghost small" data-op-add="${esc(table.key)}">＋ إضافة صف</button></div><div class="table-wrap"><table class="op-table"><thead><tr>${headers}<th>إجراء</th></tr></thead><tbody data-op-tbody="${esc(table.key)}">${body}</tbody></table></div></section>`;
 }
 function captureOpDraft(){
  if(!opDraft)return;
  const host=$('#operationalWorkflowPanel');if(!host)return;
  host.querySelectorAll('[data-op-field]').forEach(el=>opDraft.fields[el.dataset.opField]=el.value);
  host.querySelectorAll('[data-op-note]').forEach(el=>opDraft.notes[el.dataset.opNote]=el.value);
  host.querySelectorAll('[data-op-tbody]').forEach(tbody=>{
   const key=tbody.dataset.opTbody;
   opDraft.tables[key]=[...tbody.querySelectorAll('tr')].map(tr=>Object.fromEntries([...tr.querySelectorAll('[data-op-col]')].map(el=>[el.dataset.opCol,el.value])));
  });
 }
 function renderOperationalWorkflow(preserveDraft=false){
  const panel=$('#operationalWorkflowPanel');if(!panel)return;
  const schema=OP_WORKFLOWS[currentDept],targeted=!!schema;
  panel.hidden=!targeted;
  const daily=$('#dailySummaryPanel'),tabs=$('.tabs');
  if(daily)daily.hidden=targeted;
  if(tabs){
   tabs.querySelectorAll('.tab').forEach(tab=>{const keep=tab.dataset.tab==='attachments';tab.hidden=targeted&&!keep});
   tabs.hidden=false;
  }
  if(targeted)document.querySelectorAll('.tabpane').forEach(pane=>{pane.hidden=false;pane.classList.toggle('hidden',pane.id!=='pane-attachments')});
  if(!targeted){tabs?.querySelectorAll('.tab').forEach(tab=>tab.hidden=false);document.querySelectorAll('.tabpane').forEach(pane=>pane.hidden=false);$('.tab.active')?.click();opDraft=null;return}
  const saved=opSaved();opDraft=preserveDraft&&opDraft?opDraft:JSON.parse(JSON.stringify(saved));
  panel.innerHTML=`<div class="op-workflow-title"><div><span class="op-kicker">نموذج التشغيل اليومي</span><h2>${esc(currentDept)}</h2><p>التاريخ: ${esc(opDate())} · تُحفظ البيانات محلياً وتُرفق بتقرير المدير اليومي</p></div><span class="op-save-mark">نموذج القسم</span></div>
   ${schema.fields?.length?`<div class="op-fields">${schema.fields.map(f=>opFieldMarkup(f,opDraft.fields?.[f[0]])).join('')}</div>`:''}
   ${(schema.tables||[]).map(t=>opTableMarkup(t,opDraft.tables?.[t.key]||[])).join('')}
   ${schema.notes?.length?`<section class="op-notes"><h3>ملاحظات التشغيل</h3><div class="op-fields">${schema.notes.map(([key,label])=>`<label>${esc(label)}<textarea data-op-note="${esc(key)}" rows="2">${opEscape(opDraft.notes?.[key])}</textarea></label>`).join('')}</div></section>`:''}
   <div class="op-actions"><button type="button" class="btn primary" id="saveOperationalWorkflow">حفظ نموذج التشغيل</button><span id="operationalWorkflowStatus" class="status">${opDraft.updatedAt?'آخر حفظ: '+new Date(opDraft.updatedAt).toLocaleString('ar-YE'):'لم يُحفظ نموذج هذا اليوم بعد.'}</span></div>`;
 }
 function addOpRow(key){
  captureOpDraft();const table=(OP_WORKFLOWS[currentDept]?.tables||[]).find(t=>t.key===key);if(!table)return;
  opDraft.tables[key]??=[];opDraft.tables[key].push(Object.fromEntries(table.cols.map(c=>[c[0],''])));
  renderOperationalWorkflow(true);
 }
 function saveOperationalWorkflow(){
  captureOpDraft();if(!opDraft)return;
  const date=opDate();opDraft.updatedAt=new Date().toISOString();opDraft.department=currentDept;opDraft.tableMeta=Object.fromEntries((OP_WORKFLOWS[currentDept]?.tables||[]).map(t=>[t.key,{title:t.title,cols:t.cols.map(c=>[c[0],c[1]])}]));opDraft.fieldMeta=Object.fromEntries((OP_WORKFLOWS[currentDept]?.fields||[]).map(f=>[f[0],f[1]]));opDraft.noteMeta=Object.fromEntries((OP_WORKFLOWS[currentDept]?.notes||[]).map(n=>[n[0],n[1]]));
  data.departmentOperations??={};data.departmentOperations[date]=opDraft;save();
  const status=$('#operationalWorkflowStatus');if(status)status.textContent='تم حفظ نموذج '+currentDept+' بتاريخ '+date+'.';
 }
 document.addEventListener('change',e=>{if(e.target?.id==='reportDate'&&currentDept&&OP_WORKFLOWS[currentDept])renderOperationalWorkflow()});
 const opPanel=$('#operationalWorkflowPanel');
 if(opPanel){
  opPanel.addEventListener('input',captureOpDraft);
  opPanel.addEventListener('change',captureOpDraft);
  opPanel.addEventListener('click',e=>{
   const add=e.target.closest('[data-op-add]');if(add){addOpRow(add.dataset.opAdd);return}
   const remove=e.target.closest('[data-op-remove]');if(remove){captureOpDraft();const tr=remove.closest('tr'),tbody=tr?.parentElement,index=[...tbody.children].indexOf(tr);if(index>=0)opDraft.tables[tbody.dataset.opTbody].splice(index,1);renderOperationalWorkflow(true);return}
   if(e.target.closest('#saveOperationalWorkflow'))saveOperationalWorkflow();
  });
 }

 const sel=$('#department');
 sel.disabled=false;
 let sectionApproved=false;
 const appMain=$('main.wrap');
 const authGate=$('#departmentAuthGate');
 if(!authGate)throw new Error('واجهة تعيين كلمة السر غير موجودة في ملف البرنامج.');
 appMain.hidden=true;
 const authSelect=authGate.querySelector('#authDepartment');authSelect.innerHTML=sel.innerHTML;authGate.hidden=false;
 const preferredDept=read('mdh_device_department','');
 authSelect.value=DEPTS.includes(preferredDept)?preferredDept:DEPTS[0];
 const AUTH_KEY='mdh_department_credentials_v1';
 const PBKDF2_ITERATIONS=150000;
 const encoder=new TextEncoder();
 let pendingDept=authSelect.value;
 function authRecords(){const v=read(AUTH_KEY,{});return v&&typeof v==='object'&&!Array.isArray(v)?v:{}}
 function bytesToHex(bytes){return [...bytes].map(x=>x.toString(16).padStart(2,'0')).join('')}
 function hexToBytes(hex){if(!/^(?:[0-9a-f]{2})+$/i.test(String(hex||'')))return new Uint8Array();return new Uint8Array(hex.match(/.{2}/g).map(x=>parseInt(x,16)))}
 async function derivePassword(password,saltHex,iterations=PBKDF2_ITERATIONS){
  if(!window.crypto?.subtle||!window.crypto?.getRandomValues)throw new Error('التشفير الآمن غير متاح في هذا المتصفح. افتح التطبيق من نسخة APK المجهزة أو حدّث Chrome / Android System WebView.');
  const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:hexToBytes(saltHex),iterations,hash:'SHA-256'},key,256);
  return bytesToHex(new Uint8Array(bits));
 }
 function constantTimeEqual(a,b){a=String(a||'');b=String(b||'');let diff=a.length^b.length;const n=Math.max(a.length,b.length);for(let i=0;i<n;i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0}
 function credentialFor(dept){return authRecords()[dept]||null}
 const REQUIREMENTS_KEY='MDH_DEPT_REQUIREMENTS_V1';
 const requirementsPanel=$('#requirementsPanel');
 const requirementsAccessForm=$('#requirementsAccessForm');
 const requirementsEditor=$('#requirementsEditor');
 let requirementsTarget='';
 let requirementsMode='verify';
 function defaultDeptRequirements(dept){
  const dailyFields=Object.fromEntries((DEPT_DAILY_FIELDS[dept]||[]).map(([key])=>[key,{enabled:true,required:false}]));
  const procedures=Object.fromEntries((DEPT_PROFILES[dept]||[]).map(name=>[name,{enabled:true,required:false}]));
  return {version:1,dailyFields,procedures,requireAttachment:false,requireCase:false,requireOfficer:false,updatedAt:null};
 }
 function getDeptRequirementConfig(dept){
  const all=read(REQUIREMENTS_KEY,{}),base=defaultDeptRequirements(dept),saved=all?.[dept]||{};
  return {...base,...saved,dailyFields:{...base.dailyFields,...(saved.dailyFields||{})},procedures:{...base.procedures,...(saved.procedures||{})}};
 }
 function showRequirementsPanel(){
  requirementsTarget=authSelect.value;pendingDept=requirementsTarget;requirementsMode=credentialFor(requirementsTarget)?'verify':'create';
  requirementsEditor.hidden=true;requirementsAccessForm.hidden=false;requirementsPanel.hidden=false;
  authGate.querySelector('#authSetupForm').hidden=true;authGate.querySelector('#authLoginForm').hidden=true;
  $('#requirementsAccessPassword').value='';$('#requirementsConfirmPassword').value='';
  $('#requirementsConfirmWrap').hidden=requirementsMode==='verify';
  $('#requirementsAccessPassword').autocomplete=requirementsMode==='verify'?'current-password':'new-password';
  $('#requirementsAccessHint').textContent=requirementsMode==='verify'?'أدخل كلمة سر هذا القسم للتحقق قبل تعديل متطلباته.':'لم تُنشأ كلمة سر لهذا القسم بعد. أنشئها الآن ثم اضبط المتطلبات قبل أول دخول تشغيلي.';
  $('#requirementsAccessSubmit').textContent=requirementsMode==='verify'?'فتح إعدادات القسم':'إنشاء كلمة السر وفتح الإعدادات';
  $('#requirementsAccessStatus').textContent='';$('#requirementsSaveStatus').textContent='';
 }
 function closeRequirementsPanel(){requirementsPanel.hidden=true;requirementsAccessForm.hidden=false;requirementsEditor.hidden=true;updateAuthMode()}
 function renderRequirementRows(host,kind,rows,config){
  host.innerHTML=rows.map(([key,label])=>{const item=config[kind][key]||{enabled:true,required:false};return `<div class="requirement-row"><span class="req-name">${esc(label)}</span><label><input type="checkbox" data-req-enabled="${kind}" data-req-key="${esc(key)}" ${item.enabled!==false?'checked':''}> عرض</label><label><input type="checkbox" data-req-required="${kind}" data-req-key="${esc(key)}" ${item.required?'checked':''} ${item.enabled===false?'disabled':''}> إلزامي</label></div>`}).join('')||'<p class="muted">لا توجد بنود معرفة لهذا القسم.</p>';
  host.querySelectorAll('[data-req-enabled]').forEach(input=>input.addEventListener('change',()=>{const required=host.querySelector(`[data-req-required="${input.dataset.reqEnabled}"][data-req-key="${CSS.escape(input.dataset.reqKey)}"]`);if(required){required.disabled=!input.checked;if(!input.checked)required.checked=false}}));
 }
 function renderRequirementsEditor(){
  const c=getDeptRequirementConfig(requirementsTarget);
  $('#requirementsDailyFields').innerHTML='';$('#requirementsProcedures').innerHTML='';
  renderRequirementRows($('#requirementsDailyFields'),'dailyFields',(DEPT_DAILY_FIELDS[requirementsTarget]||[]).map(x=>[x[0],x[1]]),c);
  renderRequirementRows($('#requirementsProcedures'),'procedures',(DEPT_PROFILES[requirementsTarget]||[]).map(x=>[x,x]),c);
  $('#requireAttachment').checked=!!c.requireAttachment;$('#requireCase').checked=!!c.requireCase;$('#requireOfficer').checked=!!c.requireOfficer;
  $('#requireCaseWrap').hidden=!PATIENT_DEPARTMENTS.has(requirementsTarget);
 }
 requirementsAccessForm.addEventListener('submit',async e=>{
  e.preventDefault();const password=$('#requirementsAccessPassword').value,record=credentialFor(requirementsTarget),status=$('#requirementsAccessStatus');
  try{
   if(requirementsMode==='create'){
    if(password.length<6)throw Error('كلمة السر يجب ألا تقل عن 6 أحرف أو أرقام.');
    if(password!==$('#requirementsConfirmPassword').value)throw Error('تأكيد كلمة السر غير مطابق.');
    const salt=new Uint8Array(16);crypto.getRandomValues(salt);const saltHex=bytesToHex(salt),hash=await derivePassword(password,saltHex);const all=authRecords();all[requirementsTarget]={version:1,algorithm:'PBKDF2-SHA-256',iterations:PBKDF2_ITERATIONS,salt:saltHex,hash,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};write(AUTH_KEY,all);
   }else{
    if(!record)throw Error('لا توجد كلمة سر مسجلة لهذا القسم.');
    const hash=await derivePassword(password,record.salt,Number(record.iterations)||PBKDF2_ITERATIONS);
    if(!constantTimeEqual(hash,record.hash))throw Error('كلمة السر غير صحيحة. لم يتم فتح الإعدادات.');
   }
   requirementsAccessForm.hidden=true;requirementsEditor.hidden=false;renderRequirementsEditor();
  }catch(err){status.textContent=err.message||'تعذر فتح إعدادات القسم.';}
 });
 $('#requirementsOpenBtn').addEventListener('click',showRequirementsPanel);
 $('#requirementsCloseBtn').addEventListener('click',closeRequirementsPanel);
 $('#requirementsCancelBtn').addEventListener('click',closeRequirementsPanel);
 $('#requirementsSaveBtn').addEventListener('click',()=>{
  const c=getDeptRequirementConfig(requirementsTarget);
  for(const kind of ['dailyFields','procedures']){
   const keys=Object.keys(c[kind]);
   keys.forEach(key=>{
    const enabled=$(`[data-req-enabled="${kind}"][data-req-key="${CSS.escape(key)}"]`);
    const required=$(`[data-req-required="${kind}"][data-req-key="${CSS.escape(key)}"]`);
    if(enabled)c[kind][key]={enabled:enabled.checked,required:!!(enabled.checked&&required?.checked)};
   });
  }
  c.requireAttachment=$('#requireAttachment').checked;c.requireCase=PATIENT_DEPARTMENTS.has(requirementsTarget)&&$('#requireCase').checked;c.requireOfficer=$('#requireOfficer').checked;c.updatedAt=new Date().toISOString();
  const all=read(REQUIREMENTS_KEY,{});all[requirementsTarget]=c;write(REQUIREMENTS_KEY,all);
  $('#requirementsSaveStatus').textContent='تم حفظ المتطلبات الخاصة بقسم '+requirementsTarget+'. ستُطبّق على نموذج القسم والتحقق قبل إرسال التقرير.';
  setGateMessage('تم تحديث متطلبات '+requirementsTarget+' بنجاح. يمكنك الآن الدخول إلى القسم.');
 });
 function validateConfiguredRequirements(date){
  const c=getDeptRequirementConfig(currentDept),errors=[],summaryForm=$('#dailySummaryForm'),fields=DEPT_DAILY_FIELDS[currentDept]||[];
  const requiredFields=fields.filter(([key])=>c.dailyFields[key]?.enabled!==false&&c.dailyFields[key]?.required);
  const summaryValues={...(data.departmentSummaries||{})[date]||{}};
  fields.filter(([key])=>c.dailyFields[key]?.enabled!==false).forEach(([key])=>{const el=summaryForm?.elements?.namedItem(key);if(el)summaryValues[key]=el.value.trim()});
  requiredFields.forEach(([key,label])=>{if(!String(summaryValues[key]??'').trim())errors.push('حقل ملخص التشغيل الإلزامي: '+label)});
  const procRows=(DEPT_PROFILES[currentDept]||[]).filter(name=>c.procedures[name]?.enabled!==false);
  procRows.forEach((name,index)=>{if(c.procedures[name]?.required){const select=$(`[data-dept-procedure-status="${index}"]`);if(!select||!select.value||select.value==='لم يقيم')errors.push('يجب تقييم الإجراء: '+name)}});
  if(c.requireAttachment&&!(data.attachments||[]).some(a=>a.reportDate===date))errors.push('يجب إرفاق ملف واحد على الأقل لهذا التقرير.');
  if(c.requireCase&&!(data.cases||[]).some(x=>(x.recordDate||date)===date))errors.push('يجب تسجيل حالة أو مراجع واحد على الأقل.');
  if(c.requireOfficer&&!meta().officer)errors.push('اسم مسؤول القسم إلزامي.');
  if(!errors.length){
   data.departmentSummaries??={};data.departmentSummaries[date]={...summaryValues,department:currentDept,date,updatedAt:new Date().toISOString()};
   procRows.forEach((procedure,index)=>{const select=$(`[data-dept-procedure-status=\"${index}\"]`);if(!select)return;const notes=$(`[data-dept-procedure-note=\"${index}\"]`)?.value.trim()||'';const existingIndex=(data.assessments||[]).findIndex(x=>x.departmentProcedure===true&&x.assessmentDate===date&&x.procedure===procedure);const old=existingIndex>=0?data.assessments[existingIndex]:null;const row={id:old?.id||uid(),recordDate:date,createdAt:old?.createdAt||new Date().toISOString(),area:'إجراءات القسم اليومية',procedure,execution:select.value||'لم يقيم',rating:0,responsible:meta().officer,assessmentDate:date,notes,departmentProcedure:true};if(existingIndex>=0)data.assessments[existingIndex]=row;else data.assessments.push(row)});
   write(deptKey(currentDept),data);
  }
  return {ok:errors.length===0,errors,config:c};
 }
 function setGateMessage(message,isError=false){authGate.querySelector('#authMessage').textContent=message;authGate.querySelector('#authMessage').style.color=isError?'#a3212a':'#176a98'}
 function updateAuthMode(){pendingDept=authSelect.value;const existingData=loadDeptData(pendingDept);const hasDemo=['cases','activity','assessments','finance','issues','feedback','departmentStats','attachments'].some(key=>(existingData[key]||[]).some(row=>String(row.id||'').startsWith('MDH-DEMO-')));$('#clearDemoBtn').hidden=!hasDemo;const record=credentialFor(pendingDept),exists=!!record;authGate.querySelector('#authSetupForm').hidden=exists;authGate.querySelector('#authLoginForm').hidden=!exists;authGate.querySelector('#authForceChangeForm').hidden=true;authGate.querySelector('#authForceNewPassword').value='';authGate.querySelector('#authForceConfirmPassword').value='';authGate.querySelector('#authCancelBtn').hidden=(!currentDept||pendingDept===currentDept);authGate.querySelector('#authNewPassword').value='';authGate.querySelector('#authConfirmPassword').value='';authGate.querySelector('#authLoginPassword').value='';setGateMessage(exists?(record.mustChange?'أدخل كلمة المرور المؤقتة التي أصدرتها الإدارة.':'أدخل كلمة سر '+pendingDept+' للمتابعة.'):'هذا القسم لا يملك كلمة سر بعد. أنشئ كلمة سر خاصة به.');}
 function showAuthGate(dept){if(DEPTS.includes(dept))authSelect.value=dept;updateAuthMode();appMain.hidden=true;authGate.hidden=false;}
 function activateDepartment(dept){
  if(!DEPTS.includes(dept))return;
  currentDept=dept;pendingDept=dept;sel.value=dept;sel.disabled=false;sectionApproved=true;
  write('mdh_device_department',dept);
  data=loadDeptData(dept);loadDeptMeta(dept);
  $$('form').forEach(form=>form.reset());
  const patientFieldsEnabled=PATIENT_DEPARTMENTS.has(dept);
  $$('.clinical-extra').forEach(el=>el.style.display=CLINICAL_REPORT_DEPTS.has(dept)?'block':'none');
  const financeDocsPanel=$('#financeDocsPanel');if(financeDocsPanel)financeDocsPanel.hidden=!FINANCIAL_DEPARTMENTS.has(dept);const financeDocsDate=$('#financeDocsForm [name=date]');if(financeDocsDate)financeDocsDate.value=today();
  const casesTab=$('.tab[data-tab="cases"]'),casesPane=$('#pane-cases');
  if(casesTab)casesTab.hidden=!patientFieldsEnabled;
  if(casesPane)casesPane.hidden=!patientFieldsEnabled;
  ['patientName','caseNo'].forEach(name=>{const field=$(`#assessmentForm [name="${name}"]`);const label=field?.closest('label');if(label)label.hidden=!patientFieldsEnabled;});
  if(!patientFieldsEnabled&&$('.tab.active')?.dataset.tab==='cases')$('.tab[data-tab="activity"]')?.click();
  const financeDate=$('#financeForm [name=date]');if(financeDate)financeDate.value=today();
  appMain.hidden=false;authGate.hidden=true;
  $('#sendStatus').textContent='تم فتح حساب قسم '+dept+' بعد التحقق من كلمة السر.';
  render();renderDepartmentProcedures();renderDailySummary();renderOperationalWorkflow();renderAttachments();
 }
 authSelect.addEventListener('change',()=>{requirementsPanel.hidden=true;requirementsAccessForm.hidden=false;requirementsEditor.hidden=true;updateAuthMode()});
 function seedDepartmentDemo(){
  const dept=authSelect.value,date=today(),demoPrefix='MDH-DEMO-'+date+'-';
  const target=loadDeptData(dept);
  for(const key of ['cases','activity','assessments','finance','issues','feedback','departmentStats'])target[key]=(target[key]||[]).filter(x=>!String(x.id||'').startsWith(demoPrefix));
  target.attachments=(target.attachments||[]).filter(x=>!String(x.id||'').startsWith(demoPrefix));
  const now=new Date().toISOString();
  target.activity.push({id:demoPrefix+'ACTIVITY',recordDate:date,createdAt:now,metric:'مؤشر اختبار تجريبي',value:4,unit:'حالات',notes:'بيانات وهمية لأغراض الاختبار فقط',demoSeed:true});
  target.issues.push({id:demoPrefix+'ISSUE',recordDate:date,createdAt:now,category:'اقتراح تحسين',priority:'عادية',location:'منطقة تجريبية',status:'مفتوحة',details:'ملاحظة اختبارية – لا تمثل عطلًا حقيقياً',action:'اختبار مسار متابعة الملاحظات',demoSeed:true});
  if(PATIENT_DEPARTMENTS.has(dept))target.cases.push({id:demoPrefix+'CASE',recordDate:date,createdAt:now,patientName:'حالة اختبارية غير حقيقية',caseNo:'DEMO-0001',type:'مراجعة',gender:'غير محدد',age:'35',area:'منطقة تجريبية',village:'قرية تجريبية',diagnosis:'بيانات اختبار – ليست تشخيصاً سريرياً',doctor:'طبيب تجريبي',outcome:'استكمال الاختبار',procedure:'إجراء تجريبي',finalProcedure:'لا يوجد إجراء علاجي',shiftDoctor:'طبيب النوبة التجريبي',nurse:'ممرض تجريبي',handoverFrom:'نوبة تجريبية سابقة',handoverTo:'نوبة تجريبية لاحقة',notes:'سجل اصطناعي للاختبار فقط، وليس مريضاً حقيقياً.',demoSeed:true});
  const proc=(DEPT_PROFILES[dept]||[]);
  proc.forEach((name,index)=>target.assessments.push({id:demoPrefix+'PROC-'+index,recordDate:date,createdAt:now,area:'إجراءات القسم اليومية',procedure:name,execution:index%3===0?'تم جزئياً':'تم التنفيذ',rating:4,responsible:'مسؤول تجريبي',assessmentDate:date,notes:'إثبات تجريبي',departmentProcedure:true,demoSeed:true}));
  const summary={department:dept,date,updatedAt:now,_demoSeed:true};
  (DEPT_DAILY_FIELDS[dept]||[]).forEach(([key,label,type],i)=>summary[key]=type==='number'?String(i+1):'قيمة اختبارية – '+label);
  target.departmentSummaries??={};if(!target.departmentSummaries[date])target.departmentSummaries[date]=summary;
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="900" height="560" viewBox="0 0 900 560"><defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#0b3856"/><stop offset="1" stop-color="#0d9a9c"/></linearGradient></defs><rect width="900" height="560" rx="36" fill="#edf5f7"/><rect x="28" y="28" width="844" height="504" rx="28" fill="white" stroke="#cfe1e8" stroke-width="3"/><rect x="28" y="28" width="844" height="110" rx="28" fill="url(#g)"/><text x="450" y="93" text-anchor="middle" font-family="Arial" font-size="34" font-weight="700" fill="white">D.M.H · TEST ATTACHMENT</text><text x="450" y="230" text-anchor="middle" font-family="Arial" font-size="34" font-weight="700" fill="#0b3856">DEMO ONLY</text><text x="450" y="300" text-anchor="middle" font-family="Arial" font-size="24" fill="#456579">${dept.replaceAll('&','&amp;').replaceAll('<','&lt;')}</text><text x="450" y="365" text-anchor="middle" font-family="Arial" font-size="21" fill="#718594">${date}</text><text x="450" y="435" text-anchor="middle" font-family="Arial" font-size="19" fill="#a3212a">ليست وثيقة أو بيانات مريض حقيقية</text></svg>`;
  const toBase64=value=>{const bytes=new TextEncoder().encode(value);let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);return btoa(binary)};
  const imageUrl='data:image/svg+xml;base64,'+toBase64(svg);
  const text='مرفق تجريبي من مستشفى الضالع الحديث\nالقسم: '+dept+'\nالتاريخ: '+date+'\nالغرض: اختبار نقل المرفقات الأصلية مع تقرير القسم.\nتنبيه: لا يحتوي هذا الملف على بيانات مرضى حقيقية.';
  target.attachments.push({id:demoPrefix+'ATTACH-IMAGE',name:'MDH_Demo_Attachment.svg',type:'image/svg+xml',size:new TextEncoder().encode(svg).length,originalSize:new TextEncoder().encode(svg).length,uploadedAt:now,reportDate:date,dataUrl:imageUrl,previewKind:'image',demoSeed:true});
  target.attachments.push({id:demoPrefix+'ATTACH-TEXT',name:'MDH_Demo_Notes.txt',type:'text/plain',size:new TextEncoder().encode(text).length,originalSize:new TextEncoder().encode(text).length,uploadedAt:now,reportDate:date,dataUrl:'data:text/plain;base64,'+toBase64(text),previewText:text,previewKind:'text',demoSeed:true});
  write(deptKey(dept),target);
  $('#clearDemoBtn').hidden=false;
  setGateMessage('تم تجهيز عينة اختبارية لقسم '+dept+' مع سجل تشغيل ومتابعة ومرفق صورة وملف نصي. العينة وهمية ويمكن حذفها قبل الاستخدام الحقيقي.');
 }
 function clearDepartmentDemo(){
  const dept=authSelect.value,date=today(),target=loadDeptData(dept),prefix='MDH-DEMO-';
  for(const key of ['cases','activity','assessments','finance','issues','feedback','departmentStats'])target[key]=(target[key]||[]).filter(x=>!String(x.id||'').startsWith(prefix));
  target.attachments=(target.attachments||[]).filter(x=>!String(x.id||'').startsWith(prefix));
  if(target.departmentSummaries?.[date]?._demoSeed)delete target.departmentSummaries[date];
  write(deptKey(dept),target);$('#clearDemoBtn').hidden=true;
  setGateMessage('تم حذف السجلات والمرفقات التجريبية التي أضيفت بواسطة أداة العينة.');
 }
 $('#seedDemoBtn').addEventListener('click',async()=>{if(await mdhConfirm('سيُضاف إلى القسم المحدد سجل تجريبي ومرفقان (صورة وملف نصي). لن تُستخدم بيانات مريض حقيقي. هل تريد المتابعة؟','تجهيز عينة اختبارية'))seedDepartmentDemo()});
 $('#clearDemoBtn').addEventListener('click',async()=>{if(await mdhConfirm('سيتم حذف العناصر التي أنشأتها أداة العينة فقط من القسم المحدد. هل تريد المتابعة؟','حذف العينة الاختبارية'))clearDepartmentDemo()});

 authGate.querySelector('#authSetupForm').addEventListener('submit',async e=>{e.preventDefault();const password=authGate.querySelector('#authNewPassword').value,confirmPassword=authGate.querySelector('#authConfirmPassword').value;if(password.length<6){setGateMessage('يجب ألا تقل كلمة السر عن 6 أحرف أو أرقام.',true);return}if(password!==confirmPassword){setGateMessage('تأكيد كلمة السر غير مطابق.',true);return}try{const salt=new Uint8Array(16);crypto.getRandomValues(salt);const saltHex=bytesToHex(salt),hash=await derivePassword(password,saltHex);const all=authRecords();all[pendingDept]={version:1,algorithm:'PBKDF2-SHA-256',iterations:PBKDF2_ITERATIONS,salt:saltHex,hash,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};write(AUTH_KEY,all);authGate.querySelector('#authNewPassword').value='';authGate.querySelector('#authConfirmPassword').value='';activateDepartment(pendingDept)}catch(err){setGateMessage(err.message||'تعذر إنشاء كلمة السر.',true)}});
 authGate.querySelector('#authLoginForm').addEventListener('submit',async e=>{e.preventDefault();const password=authGate.querySelector('#authLoginPassword').value,record=credentialFor(pendingDept);if(!record){updateAuthMode();return}try{const hash=await derivePassword(password,record.salt,Number(record.iterations)||PBKDF2_ITERATIONS);if(!constantTimeEqual(hash,record.hash)){setGateMessage('كلمة السر غير صحيحة للقسم المحدد.',true);return}authGate.querySelector('#authLoginPassword').value='';if(record.mustChange){authGate.querySelector('#authLoginForm').hidden=true;authGate.querySelector('#authForceChangeForm').hidden=false;authGate.querySelector('#authForceChangeNotice').textContent='أصدرت الإدارة كلمة مرور مؤقتة لقسم '+pendingDept+'. أنشئ كلمة مرور دائمة جديدة قبل فتح سجلات القسم.';setGateMessage('يلزم تغيير كلمة المرور المؤقتة قبل الدخول.');return}activateDepartment(pendingDept)}catch(err){setGateMessage(err.message||'تعذر التحقق من كلمة السر.',true)}});
 authGate.querySelector('#authForceChangeForm').addEventListener('submit',async e=>{e.preventDefault();const password=$('#authForceNewPassword').value,confirmPassword=$('#authForceConfirmPassword').value;if(password.length<6){setGateMessage('كلمة المرور الدائمة يجب ألا تقل عن 6 محارف.',true);return}if(password!==confirmPassword){setGateMessage('تأكيد كلمة المرور غير مطابق.',true);return}try{const all=authRecords(),record=all[pendingDept];if(!record?.mustChange)throw new Error('لا يوجد طلب تغيير كلمة مرور لهذا القسم.');const salt=new Uint8Array(16);crypto.getRandomValues(salt);const saltHex=bytesToHex(salt),hash=await derivePassword(password,saltHex,PBKDF2_ITERATIONS);all[pendingDept]={...record,algorithm:'PBKDF2-SHA-256',iterations:PBKDF2_ITERATIONS,salt:saltHex,hash,updatedAt:new Date().toISOString(),mustChange:false,temporary:false};delete all[pendingDept].resetAt;write(AUTH_KEY,all);$('#authForceNewPassword').value='';$('#authForceConfirmPassword').value='';activateDepartment(pendingDept)}catch(err){setGateMessage(err.message||'تعذر حفظ كلمة المرور الجديدة.',true)}});
 authGate.querySelector('#authCancelBtn').addEventListener('click',()=>{if(currentDept)showAuthGate(currentDept)});
 showAuthGate(authSelect.value);
 if(new URLSearchParams(window.location.search).get('configure')==='1')showRequirementsPanel();
 if(!window.crypto?.subtle||!window.crypto?.getRandomValues)setGateMessage('تعذر تشغيل التشفير الآمن. حدّث Android System WebView ثم أعد فتح التطبيق.',true);
 function loadDeptData(dept){
  let next=read(deptKey(dept),emptyData());
  if(!next||typeof next!=='object'||Array.isArray(next))next=emptyData();
  for(const k of COLLECTIONS)if(!Array.isArray(next[k]))next[k]=[];
  if(!Array.isArray(next.attachments))next.attachments=[];
  if(!next.departmentSummaries||typeof next.departmentSummaries!=='object')next.departmentSummaries={};
  return next;
 }
 function loadDeptMeta(dept){
  const saved=dept?read('mdh_meta_'+dept,{}):{};
  $('#reportDate').value=saved.date||today();
  $('#officer').value=saved.officer||'';
  $('#shift').value=saved.shift||'اليومي';
 }
 let data=emptyData();
 loadDeptMeta('');
 const dateInput=$('#financeForm [name=date]');if(dateInput)dateInput.value=today();
 function meta(){return {department:currentDept||sel.value,date:$('#reportDate').value||today(),officer:$('#officer').value.trim(),shift:$('#shift').value,deviceId:read('mdh_device_id',null)||(()=>{const x=uid();write('mdh_device_id',x);return x})()}}
 function save(){write(deptKey(currentDept),data);render()}
 function load(){data=loadDeptData(currentDept);render();renderDepartmentProcedures()}
 function renderDailySummary(){
  const form=$('#dailySummaryForm'),host=$('#dailySummaryFields');if(!form||!host)return;
  const cfg=getDeptRequirementConfig(currentDept),allFields=DEPT_DAILY_FIELDS[currentDept]||[],fields=allFields.filter(([key])=>cfg.dailyFields[key]?.enabled!==false);
  $('#dailySummaryTitle').textContent='ملخص التشغيل اليومي – '+(currentDept||'القسم');
  const date=$('#reportDate').value||today(),saved=(data.departmentSummaries||{})[date]||{};
  host.innerHTML=fields.map(([key,label,type])=>{const required=!!cfg.dailyFields[key]?.required;return `<div class="daily-summary-field"><label>${esc(label)}${required?'<span class="required-field">إلزامي *</span>':''}${type==='textarea'?`<textarea name="${esc(key)}" rows="2" placeholder="${esc(label)}" ${required?'required':''}></textarea>`:`<input name="${esc(key)}" type="${type==='number'?'number':'text'}" ${type==='number'?'min="0" step="1"':''} placeholder="${esc(label)}" ${required?'required':''}/>`}</label></div>`}).join('');
  fields.forEach(([key])=>{const el=form.elements.namedItem(key);if(el)el.value=saved[key]??'';});
  $('#dailySummaryStatus').textContent=saved.updatedAt?'آخر حفظ: '+new Date(saved.updatedAt).toLocaleString('ar-YE'):'لم يُحفظ ملخص هذا اليوم بعد.';
 }
 $('#dailySummaryForm').onsubmit=e=>{e.preventDefault();if(!currentDept||!sectionApproved){alert('اعتمد القسم أولاً.');return;}
  const date=$('#reportDate').value||today(),cfg=getDeptRequirementConfig(currentDept),fields=(DEPT_DAILY_FIELDS[currentDept]||[]).filter(([key])=>cfg.dailyFields[key]?.enabled!==false),values={};
  fields.forEach(([key])=>{const el=e.currentTarget.elements.namedItem(key);values[key]=el?.value?.trim()??'';});
  data.departmentSummaries??={};data.departmentSummaries[date]={...(data.departmentSummaries[date]||{}),...values,department:currentDept,date,updatedAt:new Date().toISOString()};
  save();$('#dailySummaryStatus').textContent='تم حفظ ملخص تشغيل '+currentDept+' لتاريخ '+date+'.';
 };
 function renderAttachments(){
  const host=$('#departmentAttachmentList');if(!host)return;
  const date=$('#reportDate').value||today(),rows=(data.attachments||[]).filter(x=>x.reportDate===date);
  host.innerHTML=rows.length?rows.map(a=>`<div class="record"><b>${esc(a.name)}</b><small>${esc(a.type||'ملف')} · ${(Number(a.size)||0).toLocaleString('ar-YE')} بايت · ${new Date(a.uploadedAt).toLocaleString('ar-YE')}</small><button type="button" class="btn ghost" data-attachment-del="${esc(a.id)}">حذف المرفق</button></div>`).join(''):'<p class="muted">لا توجد مرفقات لهذا التاريخ.</p>';
 }

 async function officePreviewText(file){
  const ext=(file.name.split('.').pop()||'').toLowerCase();
  if(!['docx','xlsx'].includes(ext))return '';
  if(typeof DecompressionStream==='undefined')return '';
  const buffer=await file.arrayBuffer(),view=new DataView(buffer),bytes=new Uint8Array(buffer);
  let eocd=-1;
  for(let i=Math.max(0,bytes.length-65557);i<=bytes.length-22;i++){
   if(view.getUint32(i,true)===0x06054b50)eocd=i;
  }
  if(eocd<0)throw new Error('بنية ملف Office غير صحيحة.');
  const count=view.getUint16(eocd+10,true),centralOffset=view.getUint32(eocd+16,true),entries=new Map();
  let pos=centralOffset;
  for(let i=0;i<count;i++){
   if(view.getUint32(pos,true)!==0x02014b50)break;
   const method=view.getUint16(pos+10,true),compressed=view.getUint32(pos+20,true),nameLen=view.getUint16(pos+28,true),extraLen=view.getUint16(pos+30,true),commentLen=view.getUint16(pos+32,true),local=view.getUint32(pos+42,true);
   const name=new TextDecoder().decode(bytes.slice(pos+46,pos+46+nameLen));
   entries.set(name,{method,compressed,local});
   pos+=46+nameLen+extraLen+commentLen;
  }
  async function readEntry(name){
   const e=entries.get(name);if(!e)return '';
   const p=e.local;
   if(view.getUint32(p,true)!==0x04034b50)throw new Error('تعذر قراءة ملف Office.');
   const nl=view.getUint16(p+26,true),el=view.getUint16(p+28,true),start=p+30+nl+el,raw=bytes.slice(start,start+e.compressed);
   if(e.method===0)return new TextDecoder().decode(raw);
   if(e.method!==8)throw new Error('طريقة ضغط Office غير مدعومة.');
   const stream=new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
   return await new Response(stream).text();
  }
  const xmlText=await readEntry(ext==='docx'?'word/document.xml':'xl/worksheets/sheet1.xml');
  if(!xmlText)return '';
  const xml=new DOMParser().parseFromString(xmlText,'application/xml');
  if(xml.querySelector('parsererror'))throw new Error('تعذر قراءة محتوى المستند.');
  if(ext==='docx'){
   const paras=[...xml.getElementsByTagNameNS('*','p')].map(p=>[...p.getElementsByTagNameNS('*','t')].map(t=>t.textContent).join('')).filter(Boolean);
   return paras.join('\n').slice(0,30000);
  }
  let shared=[];
  const sharedXml=await readEntry('xl/sharedStrings.xml');
  if(sharedXml){const sx=new DOMParser().parseFromString(sharedXml,'application/xml');shared=[...sx.getElementsByTagNameNS('*','si')].map(si=>[...si.getElementsByTagNameNS('*','t')].map(t=>t.textContent).join(''));}
  const colIndex=ref=>{const letters=(String(ref||'').match(/^[A-Z]+/i)||['A'])[0].toUpperCase();return [...letters].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;};
  const lines=[...xml.getElementsByTagNameNS('*','row')].map(row=>{
   const cells=[...row.getElementsByTagNameNS('*','c')],values=[];
   for(const c of cells){
    const idx=colIndex(c.getAttribute('r'));let value='';
    const type=c.getAttribute('t'),v=c.getElementsByTagNameNS('*','v')[0];
    if(type==='s'&&v)value=shared[Number(v.textContent)]??v.textContent;
    else if(type==='inlineStr')value=[...c.getElementsByTagNameNS('*','t')].map(t=>t.textContent).join('');
    else value=v?.textContent||'';
    values[idx]=value;
   }
   return values.map(v=>v??'').join(' | ');
  }).filter(Boolean);
  return lines.join('\n').slice(0,30000);
 }

 function readFileData(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=()=>reject(new Error('تعذرت قراءة الملف '+file.name));r.readAsDataURL(file);});}
 async function compressImage(file){
  const extImage=/\.(png|jpe?g|webp|gif)$/i.test(file.name||'');
  const isImage=file.type.startsWith('image/')||extImage;
  const guessedType=file.type||( /\.png$/i.test(file.name)?'image/png':/\.webp$/i.test(file.name)?'image/webp':'image/jpeg');
  if(!isImage)return {dataUrl:await readFileData(file),type:file.type||(/\.pdf$/i.test(file.name)?'application/pdf':/\.csv$/i.test(file.name)?'text/csv':/\.txt$/i.test(file.name)?'text/plain':'application/octet-stream'),size:file.size};
  const src=await readFileData(file);
  return await new Promise(resolve=>{
   const img=new Image();img.onload=()=>{try{const max=1600,scale=Math.min(1,max/Math.max(img.width,img.height)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);const url=canvas.toDataURL('image/jpeg',.76);resolve({dataUrl:url,type:'image/jpeg',size:Math.round(url.length*.75)});}catch(_){resolve({dataUrl:src,type:file.type,size:file.size});}};
   img.onerror=()=>resolve({dataUrl:src,type:guessedType,size:file.size});img.src=src;
  });
 }
 $('#deptAttachmentInput').onchange=async e=>{
  const files=[...e.target.files||[]];if(!files.length)return;
  const date=$('#reportDate').value||today();data.attachments??=[];
  let added=0,errors=[];
  for(const file of files){
   try{
    if(file.size>3*1024*1024)throw Error('حجم الملف أكبر من 3 ميغابايت.');
    const current=(data.attachments||[]).filter(x=>x.reportDate===date);
    if(current.length>=8)throw Error('الحد الأقصى 8 مرفقات لليوم الواحد.');
    const item=await compressImage(file);
    const used=current.reduce((n,x)=>n+String(x.dataUrl||'').length,0);
    if(used+item.dataUrl.length>2600000)throw Error('تجاوزت المرفقات الحد اليومي بعد الضغط (2.5 ميغابايت).');
    const attachment={id:uid(),name:file.name,type:item.type,size:item.size,originalSize:file.size,uploadedAt:new Date().toISOString(),reportDate:date,dataUrl:item.dataUrl};
    const extension=(file.name.split('.').pop()||'').toLowerCase();
    if(file.type==='text/plain'||file.type==='text/csv'||['txt','csv'].includes(extension)){
      try{attachment.previewText=(await file.text()).slice(0,15000);attachment.previewKind='text'}catch(_){}
    }else if(['docx','xlsx'].includes(extension)){
      try{attachment.previewText=await officePreviewText(file);attachment.previewKind=extension;}catch(error){attachment.previewError=error.message||'تعذر استخراج معاينة المستند.';}
    }else if(['doc','xls'].includes(extension)){
      attachment.previewError='صيغة Office القديمة محفوظة كمرفق، لكن لا يمكن استخراج صفحاتها للطباعة دون تحويلها إلى PDF.';
    }
    data.attachments.push(attachment);added++;
   }catch(err){errors.push(file.name+': '+err.message);}
  }
  const beforeSaveCount=data.attachments.length-added;try{save();renderAttachments();}catch(err){data.attachments.splice(beforeSaveCount,added);alert('تعذر حفظ المرفقات في ذاكرة الهاتف. قلل الحجم أو عدد الملفات.');}
  $('#attachmentStatus').textContent=`تم حفظ ${added} مرفق.${errors.length?' تعذر: '+errors.join(' | '):''}`;
  e.target.value='';
 };
 document.addEventListener('click',e=>{const b=e.target.closest('[data-attachment-del]');if(!b)return;if(!confirm('هل تريد حذف هذا المرفق من سجل القسم؟'))return;data.attachments=(data.attachments||[]).filter(x=>x.id!==b.dataset.attachmentDel);save();renderAttachments();});
 $('#reportDate').addEventListener('change',()=>{renderDailySummary();renderAttachments();});
 function attachmentPrintMarkup(a){
  const name=esc(a.name),meta=`<b>${name}</b><small>${esc(a.type)} · ${Math.round((a.size||0)/1024)} KB</small>`;
  if(String(a.type).startsWith('image/'))return `<figure class="attachment-card attachment-page">${meta}<img src="${a.dataUrl}" alt="${name}"/></figure>`;
  if((a.type==='application/pdf'||/\\.pdf$/i.test(a.name||''))&&window.MDHAndroid?.renderPdfPages){
   try{const rendered=JSON.parse(window.MDHAndroid.renderPdfPages(String(a.dataUrl).split(',')[1]||''));const pages=Array.isArray(rendered)?rendered:(rendered.pages||[]),total=Array.isArray(rendered)?pages.length:(rendered.total||pages.length);if(pages.length)return pages.map((src,i)=>`<figure class="attachment-card attachment-page">${meta}<small>صفحة ${i+1}</small><img src="${src}" alt="${name} – صفحة ${i+1}"/></figure>`).join('')+(total>pages.length?`<p class="attachment-card">تم تضمين أول ${pages.length} صفحات من ملف PDF الذي يحتوي على ${total} صفحة.</p>`:'');}catch(_){}
  }
  if(a.previewText){return `<section class="attachment-card attachment-text">${meta}<h4>محتوى المرفق</h4><pre style="white-space:pre-wrap;overflow-wrap:anywhere;font:10px/1.7 Tahoma;max-height:none">${esc(a.previewText)}</pre></section>`;}
  if(a.type==='application/pdf'||/\\.pdf$/i.test(a.name||'')){return `<div class="attachment-card">${meta}<object data="${a.dataUrl}" type="application/pdf" width="100%" height="700"><p>تعذر تحويل صفحات PDF في بيئة الطباعة هذه؛ الملف الأصلي محفوظ ضمن ملف تقرير القسم.</p></object></div>`;}
  return `<div class="attachment-card">${meta}<p>${esc(a.previewError||'الملف الأصلي محفوظ إلكترونياً ضمن تقرير القسم. محتوى هذا النوع غير قابل للعرض المباشر في نسخة PDF، ويمكن فتح الملف من المرفقات الأصلية.')}</p></div>`;
 }

 const PROC_STATUSES=['لم يقيم','تم التنفيذ','تم جزئياً','لم يتم التنفيذ','متوقف','لا ينطبق'];
 function renderDepartmentProcedures(){
  const panel=$('#deptProcedurePanel');if(!panel)return;
  const cfg=getDeptRequirementConfig(currentDept),procedures=(DEPT_PROFILES[currentDept]||[]).filter(name=>cfg.procedures[name]?.enabled!==false),date=$('#reportDate').value||today();
  $('#deptProcedureHeading').textContent='إجراءات '+(currentDept||'القسم')+' اليومية';
  const saved=new Map(data.assessments.filter(x=>x.departmentProcedure===true&&x.assessmentDate===date).map(x=>[x.procedure,x]));
  $('#deptProcedureList').innerHTML=procedures.map((procedure,index)=>{const row=saved.get(procedure)||{},required=!!cfg.procedures[procedure]?.required;return `<div class="record dept-procedure-row"><div class="proc-name">${index+1}. ${esc(procedure)} ${required?'<span class="required-field">تقييم إلزامي</span>':''}</div><div><select data-dept-procedure-status="${index}">${PROC_STATUSES.map(status=>`<option ${String(row.execution||'لم يقيم')===status?'selected':''}>${status}</option>`).join('')}</select><input data-dept-procedure-note="${index}" type="text" value="${esc(row.notes||'')}" placeholder="ملاحظة / رقم أو دليل التنفيذ"></div></div>`}).join('')||'<p class="muted">لم يتم تفعيل إجراءات متابعة لهذا القسم في إعداداته.</p>';
 }
 $('#saveDeptProcedures').onclick=()=>{
  if(!currentDept||!sectionApproved){alert('يجب تسجيل الدخول إلى القسم أولاً.');return}
  const date=$('#reportDate').value||today(),cfg=getDeptRequirementConfig(currentDept),procedures=(DEPT_PROFILES[currentDept]||[]).filter(name=>cfg.procedures[name]?.enabled!==false);
  const missing=procedures.filter((procedure,index)=>cfg.procedures[procedure]?.required&&($(`[data-dept-procedure-status="${index}"]`)?.value||'لم يقيم')==='لم يقيم');
  if(missing.length){$('#deptProcedureStatus').textContent='تعذر الحفظ قبل تقييم الإجراءات الإلزامية: '+missing.join('، ');return}
  procedures.forEach((procedure,index)=>{
   const status=$(`[data-dept-procedure-status="${index}"]`)?.value||'لم يقيم';
   const notes=$(`[data-dept-procedure-note="${index}"]`)?.value.trim()||'';
   const existingIndex=data.assessments.findIndex(x=>x.departmentProcedure===true&&x.assessmentDate===date&&x.procedure===procedure);
   const old=existingIndex>=0?data.assessments[existingIndex]:null;
   const row={id:old?.id||uid(),recordDate:date,createdAt:old?.createdAt||new Date().toISOString(),area:'إجراءات القسم اليومية',procedure,execution:status,rating:0,responsible:meta().officer,assessmentDate:date,notes,departmentProcedure:true};
   if(existingIndex>=0)data.assessments[existingIndex]=row;else data.assessments.push(row);
  });
  save();renderDepartmentProcedures();$('#deptProcedureStatus').textContent='تم حفظ متابعة إجراءات '+currentDept+' لتاريخ '+date+'. ستظهر في تقرير القسم لدى المدير.';
 };
 $('#reportDate').addEventListener('change',renderDepartmentProcedures);
 $('#changeDeptPasswordBtn').onclick=()=>{$('#changeDeptPasswordForm').hidden=!$('#changeDeptPasswordForm').hidden;$('#passwordChangeStatus').textContent='';};
 $('#changeDeptPasswordForm').onsubmit=async e=>{e.preventDefault();const changeForm=e.currentTarget;const current=$('#currentDeptPassword').value,next=$('#newDeptPassword').value,confirmNext=$('#confirmDeptPassword').value;try{if(next.length<6)throw Error('كلمة السر الجديدة يجب ألا تقل عن 6 أحرف أو أرقام.');if(next!==confirmNext)throw Error('تأكيد كلمة السر الجديدة غير مطابق.');const all=authRecords(),record=all[currentDept];if(!record)throw Error('لا توجد كلمة سر مسجلة لهذا القسم.');const oldHash=await derivePassword(current,record.salt,Number(record.iterations)||PBKDF2_ITERATIONS);if(!constantTimeEqual(oldHash,record.hash))throw Error('كلمة السر الحالية غير صحيحة.');const salt=new Uint8Array(16);crypto.getRandomValues(salt);const saltHex=bytesToHex(salt),hash=await derivePassword(next,saltHex);all[currentDept]={...record,salt:saltHex,hash,iterations:PBKDF2_ITERATIONS,updatedAt:new Date().toISOString()};write(AUTH_KEY,all);changeForm.reset();$('#passwordChangeStatus').textContent='تم تغيير كلمة سر قسم '+currentDept+' بنجاح.';}catch(err){$('#passwordChangeStatus').textContent=err.message||'تعذر تغيير كلمة السر.';}};
 $('#lockDeptBtn').onclick=()=>{const dept=currentDept;showAuthGate(dept);}; sel.addEventListener('change',()=>{
  const nextDept=sel.value;
  if(!DEPTS.includes(nextDept)){sel.value=currentDept||DEPTS[0];return;}
  if(nextDept===currentDept){return;}
  if(!confirm('سيتم قفل القسم الحالي وفتح شاشة كلمة سر القسم المختار. ستبقى السجلات المحفوظة لكل قسم مستقلة. هل تريد المتابعة؟')){sel.value=currentDept;return;}
  showAuthGate(nextDept);
 });
 $('#saveMeta').onclick=()=>{
  const selected=sel.value;
  if(!DEPTS.includes(selected)||selected!==currentDept||!sectionApproved){alert('سجّل الدخول إلى القسم الصحيح أولاً.');return;}
  write('mdh_device_department',currentDept);
  const m=meta();write('mdh_meta_'+currentDept,m);sectionApproved=true;
  $('#sendStatus').textContent='تم اعتماد بيانات الدوام لقسم '+currentDept+'.';render();renderDepartmentProcedures();
 };
 function add(form,key,normalize=x=>x){if(!currentDept||!sectionApproved){alert('اختر القسم ثم اضغط «اعتماد القسم وحفظ بيانات الدوام» أولاً.');return}const v=normalize(formObj(form));data[key].push({id:uid(),recordDate:key==='finance'?(v.date||meta().date):meta().date,createdAt:new Date().toISOString(),...v});form.reset();const d=form.querySelector('[name=date]');if(d)d.value=today();save()}
 $('#caseForm').onsubmit=e=>{e.preventDefault();add(e.currentTarget,'cases',v=>({...v,age:v.age===''?'':Math.max(0,Math.min(120,num(v.age)))}))};
 $('#activityForm').onsubmit=e=>{e.preventDefault();add(e.currentTarget,'activity',v=>({...v,value:Math.max(0,num(v.value))}))};
 $('#assessmentForm').onsubmit=e=>{e.preventDefault();add(e.currentTarget,'assessments',v=>({...v,rating:Math.max(0,Math.min(5,num(v.rating))),assessmentDate:v.assessmentDate||meta().date}))};
 $('#financeForm').onsubmit=e=>{e.preventDefault();const form=e.currentTarget,v=formObj(form),d=num(v.debit),c=num(v.credit);if(d<0||c<0||(d>0)===(c>0)){alert('يجب إدخال مبلغ موجب في خانة المدين أو الدائن فقط. لا تملأ الخانتين معاً ولا تتركهما صفراً.');return}if(!String(v.box||'').trim()){alert('اسم الصندوق مطلوب.');return}add(form,'finance',x=>({...x,debit:d,credit:c,date:x.date||meta().date}))};

 const docCategorySelect=$('#financeDocsForm [name="docCategory"]'),cashDirectionSelect=$('#financeDocsForm [name="cashDirection"]');
 if(docCategorySelect&&cashDirectionSelect){docCategorySelect.addEventListener('change',()=>{if(docCategorySelect.value==='مقبوضات')cashDirectionSelect.value='مدين';else if(docCategorySelect.value==='صرفيات'||docCategorySelect.value==='مشتريات')cashDirectionSelect.value='دائن';});}
 $('#financeDocsForm').onsubmit=e=>{e.preventDefault();if(!FINANCIAL_DEPARTMENTS.has(currentDept)){alert('هذا النموذج مخصص للأقسام المالية والاستعلامات.');return;}const f=e.currentTarget,v=formObj(f),amount=num(v.docTotal);if(!(amount>0)){alert('أدخل مجموع مستند موجباً.');return;}const debit=v.cashDirection==='مدين'?amount:0,credit=v.cashDirection==='دائن'?amount:0;add(f,'finance',x=>({...x,recordType:'document',movement:x.docCategory,docCategory:x.docCategory,docTotal:amount,documentType:x.documentType,companyName:x.companyName,documentNo:x.documentNo,cashDirection:x.cashDirection,debit,credit,box:currentDept,date:x.date||meta().date,statement:x.docNotes||''}));renderFinanceDocs();};
 $('#issueForm').onsubmit=e=>{e.preventDefault();add(e.currentTarget,'issues')};
 $('#feedbackForm').onsubmit=e=>{e.preventDefault();add(e.currentTarget,'feedback',v=>({...v,date:v.date||meta().date}))};
 function remove(key,id){if(!sectionApproved){alert('اعتمد القسم أولاً قبل تعديل سجلاته.');return}if(!confirm('هل تريد حذف السجل من هذا الهاتف؟ سيظهر أثر الحذف فقط إذا أُرسل بعد ذلك ضمن ملف جديد.'))return;data[key]=data[key].filter(x=>x.id!==id);save()}
 function list(id,key,fn){$(id).innerHTML=data[key].length?data[key].slice().reverse().map(x=>`<div class="record">${fn(x)}<button class="btn ghost" data-del="${key}" data-id="${esc(x.id)}">حذف من الهاتف</button></div>`).join(''):'<p class="muted">لا توجد سجلات مضافة بعد.</p>'}
 function financeSummary(){const g={};data.finance.forEach(x=>{const k=(x.box||'بدون اسم')+'||'+(x.currency||'غير محدد');g[k]??={box:x.box,currency:x.currency,debit:0,credit:0};g[k].debit+=num(x.debit);g[k].credit+=num(x.credit)});return Object.values(g).map(x=>`<div class="record"><b>${esc(x.box)} – ${esc(x.currency)}</b><small>مدين: ${x.debit.toLocaleString('ar-YE')} | دائن: ${x.credit.toLocaleString('ar-YE')} | صافي الحركة: ${(x.debit-x.credit).toLocaleString('ar-YE')}</small></div>`).join('')||'<p class="muted">لا توجد حركات مالية.</p>'}
 function renderFinanceDocs(){
  const host=$('#financeDocsList');if(!host)return;
  const rows=(data.finance||[]).filter(x=>x.recordType==='document');
  host.innerHTML=rows.length?rows.slice().reverse().map(x=>`<div class="record"><b>${esc(x.docCategory||x.movement)} – ${num(x.docTotal).toLocaleString('ar-YE')} ${esc(x.currency||'')}</b><small>${esc(x.documentType)} | الشركة: ${esc(x.companyName)} | المستند: ${esc(x.documentNo||'—')} | ${esc(x.cashDirection)}</small><button class="btn ghost" data-del="finance" data-id="${esc(x.id)}">حذف المستند</button></div>`).join(''):'<p class="muted">لا توجد مستندات مالية مسجلة.</p>';
 }
 function render(){
  list('#caseList','cases',x=>`<b>${esc(x.patientName||x.patient||x.name||'اسم غير مدخل')}</b> · ${esc(x.type)}<small>رقم الملف: ${esc(x.caseNo||'—')} | ${esc(x.gender)} | العمر: ${esc(x.age||'—')} | القرية: ${esc(x.village||'—')}</small><small>التشخيص: ${esc(x.diagnosis)} | الإجراء: ${esc(x.procedure||x.outcome)} | النهائي: ${esc(x.finalProcedure||'—')}</small><small>دكتور النوبة: ${esc(x.shiftDoctor||'—')} | الممرض: ${esc(x.nurse||'—')} | الاستلام: ${esc(x.handoverFrom||'—')} | التسليم: ${esc(x.handoverTo||'—')}</small>${esc(x.notes)}`);
  list('#activityList','activity',x=>`<b>${esc(x.metric)}: ${esc(x.value)} ${esc(x.unit)}</b><small>${esc(x.notes)}</small>`);
  list('#assessmentList','assessments',x=>`<b>${esc(x.area)} – ${esc(x.procedure)}</b>${x.patientName?`<small>المريض: ${esc(x.patientName)} | رقم الملف: ${esc(x.caseNo||'—')}</small>`:''}<small>${esc(x.execution)} | التقييم: ${esc(x.rating)}/5 | المسؤول: ${esc(x.responsible)}</small>${esc(x.notes)}`);
  list('#financeList','finance',x=>`<b>${esc(x.box)}</b> · ${esc(x.movement)}<small>${esc(x.date)} | ${esc(x.currency)} | مدين: ${num(x.debit).toLocaleString('ar-YE')} | دائن: ${num(x.credit).toLocaleString('ar-YE')} | سند: ${esc(x.voucher)}</small>${esc(x.statement)}`);
  list('#issueList','issues',x=>`<b>${esc(x.category)} – ${esc(x.priority)}</b><small>${esc(x.location)} | ${esc(x.status)}</small>${esc(x.details)}<small>الإجراء المقترح: ${esc(x.action)}</small>`);
  list('#feedbackList','feedback',x=>`<b>${esc(x.type)} – ${esc(x.priority)}</b><small>${esc(x.date)} | القسم المعني: ${esc(x.targetDepartment)} | ${esc(x.status)}</small>${esc(x.details)}<small>الرد: ${esc(x.response)}</small>`);
  const dailySaved=!!(data.departmentSummaries||{})[$('#reportDate').value||today()];
  $('#stats').innerHTML=[['الحالات',data.cases.length],['التقييمات',data.assessments.length],['الحركات المالية',data.finance.length],['المرفقات',(data.attachments||[]).filter(x=>x.reportDate===($('#reportDate').value||today())).length],['ملخص النوبة',dailySaved?'محفوظ':'غير محفوظ'],['الشكاوى والمقترحات',data.feedback.length]].map(x=>`<div class="stat"><b>${x[1]}</b><span>${x[0]}</span></div>`).join('');
  renderFinanceDocs();renderDailySummary();renderAttachments();
 }
 document.addEventListener('click',e=>{const b=e.target.closest('[data-del]');if(b)remove(b.dataset.del,b.dataset.id)});
 $$('.tab').forEach(b=>b.onclick=()=>{$$('.tab').forEach(x=>x.classList.toggle('active',x===b));$$('.tabpane').forEach(x=>x.classList.toggle('hidden',x.id!=='pane-'+b.dataset.tab))});
 function selectedRecords(date){const out={},cfg=getDeptRequirementConfig(currentDept);for(const k of COLLECTIONS){out[k]=data[k].filter(x=>String(k==='finance'?(x.date||x.recordDate):(x.recordDate||date))===date);if(k==='assessments')out[k]=out[k].filter(x=>x.departmentProcedure!==true||cfg.procedures[x.procedure]?.enabled!==false)}out.attachments=(data.attachments||[]).filter(x=>x.reportDate===date);const rawSummary=(data.departmentSummaries||{})[date]||{},visibleFields=new Set((DEPT_DAILY_FIELDS[currentDept]||[]).filter(([key])=>cfg.dailyFields[key]?.enabled!==false).map(([key])=>key));out.departmentSummary=Object.fromEntries(Object.entries(rawSummary).filter(([key])=>['department','date','updatedAt','_demoSeed'].includes(key)||visibleFields.has(key)));out.departmentOperations=(data.departmentOperations||{})[date]||null;return out}
 async function send(backupOnly=false){if(!currentDept||!sectionApproved){alert('سجّل الدخول إلى القسم أولاً قبل إنشاء تقرير نهاية اليوم.');return}const m=meta();if(!backupOnly){const reqCheck=validateConfiguredRequirements(m.date);if(!reqCheck.ok){alert('لا يمكن إرسال التقرير قبل استكمال متطلبات القسم:\n• '+reqCheck.errors.join('\n• '));return}}if(!m.officer){if(!confirm('لم تدخل اسم مسؤول القسم. هل تريد إنشاء الملف دون اسم مسؤول؟'))return}if(!backupOnly){$('#saveDeptProcedures').click();if(OP_WORKFLOWS[currentDept])saveOperationalWorkflow()}const records=backupOnly?data:selectedRecords(m.date);const exportId=uid();const deptProcedureRows=(records.assessments||[]).filter(x=>x.departmentProcedure===true&&x.assessmentDate===m.date);
  const procedureSummary={total:deptProcedureRows.length,completed:deptProcedureRows.filter(x=>x.execution==='تم التنفيذ').length,partial:deptProcedureRows.filter(x=>x.execution==='تم جزئياً').length,notCompleted:deptProcedureRows.filter(x=>x.execution==='لم يتم التنفيذ').length,stopped:deptProcedureRows.filter(x=>x.execution==='متوقف').length,notApplicable:deptProcedureRows.filter(x=>x.execution==='لا ينطبق').length,notAssessed:deptProcedureRows.filter(x=>x.execution==='لم يقيم').length};
  const payload={schema:'MDH-DAY-2',version:2,kind:backupOnly?'department-full-backup':'department-daily-report',exportId,createdAt:new Date().toISOString(),meta:m,departmentProfile:{department:m.department,procedures:(DEPT_PROFILES[m.department]||[]).filter(name=>getDeptRequirementConfig(m.department).procedures[name]?.enabled!==false),requirements:getDeptRequirementConfig(m.department)},records,counts:{...Object.fromEntries(COLLECTIONS.map(k=>[k,(records[k]||[]).length])),attachments:(records.attachments||[]).length},summary:{casesByType:Object.fromEntries([...new Set((records.cases||[]).map(x=>x.type))].map(t=>[t,(records.cases||[]).filter(x=>x.type===t).length])),finance:financeTotals(records.finance||[]),departmentProcedures:procedureSummary,requirementsAudit:{checkedAt:new Date().toISOString(),passed:!backupOnly,requiredAttachmentCount:(records.attachments||[]).length,selectedRequirements:getDeptRequirementConfig(m.department)}}};
  const suffix=backupOnly?'FULL_BACKUP':'DAILY';const fileName=`MDH_${safeName(m.department)}_${dateName(m.date)}_${suffix}.json`;const blob=jsonBlob(payload);download(fileName,blob);
  if(!backupOnly&&navigator.share&&navigator.canShare){try{const file=new File([blob],fileName,{type:'application/json'});if(navigator.canShare({files:[file]})){await navigator.share({title:'تقرير مستشفى الضالع الحديث',text:`تقرير ${m.department} – ${m.date}`,files:[file]});data.sent??=[];data.sent.push({exportId,date:m.date,at:new Date().toISOString()});write(deptKey(currentDept),data);$('#sendStatus').textContent='تم فتح قائمة مشاركة Android. اختر Bluetooth، أو احفظ الملف لإرساله لاحقاً. لم تُحذف أي بيانات.';return}}catch(err){if(err.name==='AbortError'){$('#sendStatus').textContent='أُلغيت المشاركة؛ ملف JSON ما زال محفوظاً في التنزيلات إذا اكتمل التنزيل.';return}}}
  $('#sendStatus').textContent=backupOnly?'تم إنشاء نسخة احتياطية كاملة في التنزيلات.':'تم إنشاء ملف نهاية اليوم. افتح التنزيلات ثم اختر مشاركة > Bluetooth، أو انسخه إلى USB/OTG. لم تُحذف بيانات القسم.'
 }

 function printTable(headers, rows){
  if(!rows.length)return '<p>لا توجد سجلات لهذا التاريخ.</p>';
  return `<table><thead><tr>${headers.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${row.map(v=>`<td>${esc(v==null?'—':v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
 }
 function buildDepartmentPrintReport(){
  const m=meta(),date=m.date||today(),rows=selectedRecords(date);

  const procedureRows=(rows.assessments||[]).filter(x=>x.departmentProcedure===true);
  const applicableRows=procedureRows.filter(x=>x.execution!=='لا ينطبق');
  const assessedRows=applicableRows.filter(x=>x.execution&&x.execution!=='لم يقيم');
  const scorePoints=assessedRows.reduce((sum,x)=>sum+({'تم التنفيذ':1,'تم جزئياً':0.5,'لم يتم التنفيذ':0,'متوقف':0}[x.execution]??0),0);
  const completionScore=assessedRows.length?Math.round(scorePoints/assessedRows.length*100):null;
  const assessmentCoverage=applicableRows.length?Math.round(assessedRows.length/applicableRows.length*100):0;
  const kpi=(value,label)=>`<div class="report-kpi"><b>${value}</b><span>${label}</span></div>`;
  $('#departmentPrintScore').innerHTML=`<div class="report-kpis">${kpi((rows.cases||[]).length,'الحالات المسجلة')}${kpi(procedureRows.length,'إجراءات القسم')}${kpi(assessedRows.length,'إجراءات تم تقييمها')}</div><div class="scoreline"><div class="score-ring" style="--score:${completionScore??0}%"><b>${completionScore===null?'—':completionScore+'%'}</b></div><div class="score-copy"><strong>نسبة إنجاز الإجراءات</strong><br>تم التنفيذ 100%، تم جزئياً 50%، لم يتم التنفيذ أو متوقف 0%.<br><strong>اكتمال التقييم: ${assessmentCoverage}%</strong> (${assessedRows.length} من ${applicableRows.length} إجراء قابل للتقييم). لا ينطبق مستبعد، ولم يقيم لا يمنح نقاطاً.</div></div>`;
  $('#departmentPrintMeta').innerHTML=`القسم: <b>${esc(currentDept)}</b>　|　التاريخ: <b>${esc(date)}</b>　|　مسؤول القسم: ${esc(m.officer||'—')}　|　الدوام: ${esc(m.shift||'اليومي')}`;
  if(CLINICAL_REPORT_DEPTS.has(currentDept)){
   $('#departmentPrintCases').innerHTML=printTable(['م','اسم الحالة / المريض','رقم الملف','الجنس','العمر','القرية','التشخيص','الإجراء','الإجراء النهائي','ملاحظات','الاستلام من','التسليم إلى','دكتور النوبة','الممرض'],(rows.cases||[]).map((x,i)=>[i+1,x.patientName||x.patient||x.name||'اسم غير مدخل',x.caseNo,x.gender,x.age,x.village,x.diagnosis,x.procedure||x.outcome,x.finalProcedure,x.notes,x.handoverFrom,x.handoverTo,x.shiftDoctor||x.doctor,x.nurse]));
  }else{
   $('#departmentPrintCases').innerHTML=printTable(['م','اسم المريض / الحالة','رقم الملف','النوع','الجنس','العمر','القرية','التشخيص','الإجراء / النتيجة','ملاحظات'],(rows.cases||[]).map((x,i)=>[i+1,x.patientName||x.patient||x.name||'اسم غير مدخل',x.caseNo,x.type,x.gender,x.age,x.village||x.area,x.diagnosis,x.procedure||x.outcome,x.notes]));
  }
  const summary=rows.departmentSummary||{},summaryRows=Object.entries(summary).filter(([k,v])=>!['department','date','updatedAt'].includes(k)&&v!==''&&v!=null).map(([k,v])=>[k,v]);
  const fieldLabels=Object.fromEntries((DEPT_DAILY_FIELDS[currentDept]||[]).map(([k,l])=>[k,l]));
  const op=rows.departmentOperations||{},opFields=[...Object.entries(op.fields||{}),...Object.entries(op.notes||{})].filter(([,v])=>v!==''&&v!=null).map(([k,v])=>[op.fieldMeta?.[k]||op.noteMeta?.[k]||k,v]);
  const opTables=Object.entries(op.tables||{}).filter(([,list])=>Array.isArray(list)&&list.length).map(([key,list])=>{const meta=op.tableMeta?.[key]||{title:key,cols:Object.keys(list[0]||{}).map(k=>[k,k])};return `<h3>${esc(meta.title||key)}</h3>${printTable((meta.cols||[]).map(c=>c[1]||c[0]),list.map(row=>(meta.cols||[]).map(c=>row[c[0]])))}`}).join('');
  const opSummary=opFields.length?`<div class="summary-grid">${opFields.map(([k,v])=>`<div class="summary-cell"><b>${esc(k)}</b>${esc(v)}</div>`).join('')}</div>`:'';
  $('#departmentPrintSummary').innerHTML=(summaryRows.length?`<div class="summary-grid">${summaryRows.map(([k,v])=>`<div class="summary-cell"><b>${esc(fieldLabels[k]||k)}</b>${esc(v)}</div>`).join('')}</div>`:'<p>لم يُسجل ملخص تشغيل لهذا اليوم.</p>')+opSummary+opTables;
  const fin=rows.finance||[],cashRows=fin,docRows=fin.filter(x=>x.recordType==='document');
  const sums={debit:cashRows.reduce((a,x)=>a+num(x.debit),0),credit:cashRows.reduce((a,x)=>a+num(x.credit),0)};
  const docSums=['صرفيات','مقبوضات','مرتجعات','مشتريات'].map(cat=>[cat,docRows.filter(x=>x.docCategory===cat).reduce((a,x)=>a+num(x.docTotal),0)]);
  $('#departmentPrintFinance').innerHTML=`<div class="stats"><div class="stat"><b>${sums.debit.toLocaleString('ar-YE')}</b><span>إجمالي المدين</span></div><div class="stat"><b>${sums.credit.toLocaleString('ar-YE')}</b><span>إجمالي الدائن</span></div><div class="stat"><b>${(sums.debit-sums.credit).toLocaleString('ar-YE')}</b><span>صافي الحركة</span></div></div>${printTable(['الصندوق','الحركة','العملة','مدين','دائن','السند','الطرف','البيان'],cashRows.map(x=>[x.box,x.movement,x.currency,x.debit,x.credit,x.voucher,x.party,x.statement]))}<h3>تفاصيل الصرفيات والمقبوضات والمرتجعات والمشتريات</h3>${printTable(['العملية','مجموع المستند','نوع المستند','اسم الشركة','رقم المستند','الاتجاه','العملة','البيان'],docRows.map(x=>[x.docCategory,x.docTotal,x.documentType,x.companyName,x.documentNo,x.cashDirection,x.currency,x.docNotes||x.statement]))}<div class="summary-grid">${docSums.map(([k,v])=>`<div class="summary-cell"><b>${k}</b>${v.toLocaleString('ar-YE')}</div>`).join('')}</div>`;
  $('#departmentPrintAssessment').innerHTML=printTable(['مجال التقييم','الإجراء','اسم المريض','رقم الملف','التنفيذ','التقييم','المسؤول','التاريخ','ملاحظات'],(rows.assessments||[]).map(x=>[x.area,x.procedure,x.patientName,x.caseNo,x.execution,x.rating,x.responsible,x.assessmentDate,x.notes]));
  $('#departmentPrintActivity').innerHTML='';
  $('#departmentPrintIssues').innerHTML='';
  $('#departmentPrintFeedback').innerHTML=printTable(['النوع','التاريخ','القسم المعني','الأولوية','الحالة','التفاصيل','الرد'],(rows.feedback||[]).map(x=>[x.type,x.date,x.targetDepartment,x.priority,x.status,x.details,x.response]));
  const atts=rows.attachments||[];
  $('#departmentPrintAttachments').innerHTML=atts.length?atts.map(attachmentPrintMarkup).join(''):'<p>لا توجد مرفقات لهذا التقرير.</p>';
 }
 $('#printDeptReportBtn').onclick=async()=>{if(!currentDept||!sectionApproved){alert('سجّل الدخول إلى القسم أولاً.');return}if(await mdhConfirm('سيتم فتح تقرير الطباعة للقسم المحدد. هل تريد المتابعة؟','طباعة تقرير القسم')){buildDepartmentPrintReport();window.print()}};
 function safeName(s){return String(s||'قسم').replace(/[^\p{L}\p{N}-]+/gu,'_')}
 function financeTotals(rows){return CORE.summarizeFinance(rows)}
 $('#exportBtn').onclick=async()=>{if(await mdhConfirm('سيتم إنشاء ملف التقرير اليومي لقسم '+currentDept+' مع سجلاته ومرفقاته. هل تريد المتابعة؟','تصدير تقرير القسم'))await send(false)};$('#backupBtn').onclick=async()=>{if(await mdhConfirm('سيتم إنشاء نسخة احتياطية كاملة لبيانات هذا القسم. هل تريد المتابعة؟','نسخة احتياطية للقسم'))await send(true)};
}


function manager(){
 const MANAGER_FILE_DB='MDHManagerFiles_v1';
 const DEPARTMENT_AUTH_KEY='mdh_department_credentials_v1';
 function departmentCredentialRecords(){const r=read(DEPARTMENT_AUTH_KEY,{});return r&&typeof r==='object'&&!Array.isArray(r)?r:{}}
 async function managerDepartmentHash(password,salt,iterations=150000){if(!crypto?.subtle||!crypto?.getRandomValues)throw new Error('التشفير الآمن غير متاح في هذا الجهاز. حدّث Android System WebView.');const key=await crypto.subtle.importKey('raw',managerEncoder.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:managerUnhex(salt),iterations,hash:'SHA-256'},key,256);return managerHex(new Uint8Array(bits))}
 function renderDepartmentPasswordStatus(){const records=departmentCredentialRecords(),configured=DEPTS.filter(d=>!!records[d]),pending=DEPTS.length-configured.length,temp=DEPTS.filter(d=>records[d]?.mustChange).length;$('#managerPasswordSummary').innerHTML=`<span>أقسام مهيأة: <b>${configured.length}</b> / ${DEPTS.length}</span><span>بلا كلمة مرور: <b>${pending}</b></span><span>كلمات مؤقتة بانتظار التغيير: <b>${temp}</b></span>`;$('#departmentPasswordRows').innerHTML=`<table class="manager-password-table"><thead><tr><th>القسم</th><th>الحالة</th><th>آخر تحديث</th><th>إجراء الإدارة</th></tr></thead><tbody>${DEPTS.map(d=>{const r=records[d],status=!r?'غير مهيأ':r.mustChange?'مؤقتة - يلزم تغييرها':'مفعلة',color=!r?'danger':r.mustChange?'warn':'good';return `<tr><td><b>${esc(d)}</b></td><td class="${color}">${status}</td><td>${r?.updatedAt?esc(new Date(r.updatedAt).toLocaleString('ar-YE')):'—'}</td><td><button type="button" class="btn secondary" data-reset-dept-password="${esc(d)}">${r?'إعادة تعيين مؤقت':'إنشاء كلمة مؤقتة'}</button></td></tr>`}).join('')}</tbody></table>`}
 function generateDepartmentTemporaryPassword(){const a=crypto.getRandomValues(new Uint8Array(16));return Array.from(a,x=>x.toString(16).padStart(2,'0')).join('')}
 document.addEventListener('click',async e=>{const b=e.target.closest('[data-reset-dept-password]');if(!b)return;const dept=b.dataset.resetDeptPassword;if(!DEPTS.includes(dept))return;if(!confirm('سيتم إلغاء كلمة المرور الحالية لقسم '+dept+' وإصدار كلمة مؤقتة جديدة. يجب على مسؤول القسم تغييرها قبل فتح السجلات. هل تريد المتابعة؟'))return;try{const temporary=generateDepartmentTemporaryPassword(),salt=managerHex(crypto.getRandomValues(new Uint8Array(16))),hash=await managerDepartmentHash(temporary,salt,150000),all=departmentCredentialRecords();all[dept]={version:1,algorithm:'PBKDF2-SHA-256',iterations:150000,salt,hash,createdAt:all[dept]?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString(),resetAt:new Date().toISOString(),mustChange:true,temporary:true};write(DEPARTMENT_AUTH_KEY,all);$('#managerTempPasswordDept').textContent='القسم: '+dept+' - سلّم الكلمة المؤقتة لمسؤول القسم.';$('#managerTempPasswordValue').value=temporary;$('#managerTempPasswordCard').hidden=false;renderDepartmentPasswordStatus()}catch(err){alert('تعذر إصدار كلمة مرور مؤقتة: '+err.message)}});
 $('#refreshDeptPasswords').onclick=renderDepartmentPasswordStatus;
 $('#closeTempPassword').onclick=()=>{$('#managerTempPasswordValue').value='';$('#managerTempPasswordCard').hidden=true;$('#selectTempPassword').textContent='تحديد كلمة المرور للنسخ'};
 $('#selectTempPassword').onclick=()=>{const f=$('#managerTempPasswordValue');f.focus();f.select();try{document.execCommand('copy');$('#selectTempPassword').textContent='تم النسخ - سلّمها لمسؤول القسم'}catch(_){$('#selectTempPassword').textContent='تم تحديد النص - انسخه يدوياً'}};


 const MANAGER_AUTH_KEY='mdh_manager_credentials_v1';
 const managerAuthGate=$('#managerAuthGate'),managerWorkspace=$('#managerWorkspace');
 const managerSetupForm=$('#managerSetupForm'),managerLoginForm=$('#managerLoginForm');
 const managerAuthStatus=$('#managerAuthStatus');
 const managerEncoder=new TextEncoder();
 const managerIterations=180000;
 const managerHex=bytes=>Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
 const managerUnhex=hex=>new Uint8Array(String(hex||'').match(/.{2}/g)?.map(x=>parseInt(x,16))||[]);
 function managerAuthRecord(){try{const x=JSON.parse(localStorage.getItem(MANAGER_AUTH_KEY)||'null');return x&&x.salt&&x.hash?x:null}catch(_){return null}}
 async function managerHash(pass,salt){if(!crypto?.subtle||!crypto?.getRandomValues)throw new Error('التشفير الآمن غير متاح في هذا الجهاز. حدّث Android System WebView.');const key=await crypto.subtle.importKey('raw',managerEncoder.encode(pass),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:managerUnhex(salt),iterations:managerIterations,hash:'SHA-256'},key,256);return managerHex(new Uint8Array(bits))}
 function managerEqual(a,b){a=String(a||'');b=String(b||'');let diff=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0}
 async function managerSavePassword(pass){const salt=managerHex(crypto.getRandomValues(new Uint8Array(16)));const hash=await managerHash(pass,salt);localStorage.setItem(MANAGER_AUTH_KEY,JSON.stringify({version:1,algorithm:'PBKDF2-SHA256',iterations:managerIterations,salt,hash,updatedAt:new Date().toISOString()}))}
 function managerShowLogin(){$('#managerTempPasswordValue').value='';$('#managerTempPasswordCard').hidden=true;managerWorkspace.hidden=true;managerAuthGate.hidden=false;const has=!!managerAuthRecord();managerSetupForm.hidden=has;managerLoginForm.hidden=!has;managerAuthStatus.textContent=has?'أدخل كلمة مرور الإدارة للمتابعة.':'أنشئ كلمة مرور الإدارة لأول تشغيل. لا توجد كلمة مرور افتراضية.'}
 function managerUnlock(){managerAuthGate.hidden=true;managerWorkspace.hidden=false;managerAuthStatus.textContent='';$('#managerLoginPassword').value='';render();renderDepartmentPasswordStatus()}
 managerSetupForm.addEventListener('submit',async e=>{e.preventDefault();const p=$('#managerSetupPassword').value, c=$('#managerSetupConfirm').value;if(p.length<8||p.length>64){managerAuthStatus.textContent='كلمة المرور يجب أن تكون من 8 إلى 64 محرفاً.';return}if(p!==c){managerAuthStatus.textContent='تأكيد كلمة المرور غير مطابق.';return}try{await managerSavePassword(p);managerUnlock()}catch(err){managerAuthStatus.textContent=err.message}});
 managerLoginForm.addEventListener('submit',async e=>{e.preventDefault();const p=$('#managerLoginPassword').value,record=managerAuthRecord();if(!record){managerShowLogin();return}try{const hash=await managerHash(p,record.salt);if(!managerEqual(hash,record.hash)){managerAuthStatus.textContent='كلمة المرور غير صحيحة.';return}managerUnlock()}catch(err){managerAuthStatus.textContent=err.message}});
 $('#managerLockBtn').onclick=managerShowLogin;
 $('#managerChangePasswordToggle').onclick=()=>{$('#managerChangePasswordForm').hidden=!$('#managerChangePasswordForm').hidden;};
 $('#managerChangePasswordForm').addEventListener('submit',async e=>{e.preventDefault();const old=$('#managerOldPassword').value,p=$('#managerNewPassword').value,c=$('#managerConfirmPassword').value,record=managerAuthRecord(),status=$('#managerChangePasswordStatus');try{if(!record)throw new Error('لم يتم إعداد كلمة مرور الإدارة.');if(!managerEqual(await managerHash(old,record.salt),record.hash))throw new Error('كلمة المرور الحالية غير صحيحة.');if(p.length<8||p.length>64)throw new Error('كلمة المرور الجديدة يجب أن تكون من 8 إلى 64 محرفاً.');if(p!==c)throw new Error('تأكيد كلمة المرور الجديدة غير مطابق.');await managerSavePassword(p);e.target.reset();e.target.hidden=true;status.textContent='تم تغيير كلمة مرور الإدارة بنجاح.';}catch(err){status.textContent=err.message}});
 managerShowLogin();

 async function storeIncomingAttachments(rows){for(const row of rows||[]){if(!row?.id)throw new Error('معرف المرفق مفقود.');if(!row.dataUrl)throw new Error('بيانات الملف المرفق غير موجودة داخل تقرير القسم: '+(row.fileName||row.name||row.id));const blob=CORE.dataUrlToBlob(row.dataUrl);row.fileName=String(row.fileName||row.name||row.filename||row.id);row.mimeType=String(row.mimeType||row.type||blob.type||'application/octet-stream');row.reportedSize=Number(row.size)||Number(row.originalSize)||blob.size;row.size=blob.size;row.description=String(row.description||row.previewKind||'');await CORE.putFile(MANAGER_FILE_DB,row.id,blob,{name:row.fileName,type:row.mimeType,size:blob.size});}}
 async function exportAttachmentsForBackup(rows){const out=[];for(const row of rows||[]){const stored=await CORE.getFile(MANAGER_FILE_DB,row.id);if(!stored?.blob)throw new Error('الملف غير موجود في مخزن المدير: '+(row.fileName||row.id));out.push({...row,dataUrl:await CORE.blobToDataUrl(stored.blob)});}return out;}
 let db=read('mdh_manager_db',{schema:'MDH-MASTER-2',imports:[],reports:[],...emptyData()});for(const k of COLLECTIONS)if(!Array.isArray(db[k]))db[k]=[];db.imports??=[];db.reports??=[];
 $('#filterDate').value=today();$('#periodFrom').value=today().slice(0,8)+'01';$('#periodTo').value=today();
 function persist(){write('mdh_manager_db',db);render()}
 function mergeUnique(target,rows,reportId,dept,date){let added=0,duplicates=0;for(const r of rows||[]){const rid=String(r.id||'');if(!rid){duplicates++;continue}if(!target.some(x=>x.id===rid)){target.push({...r,sourceReport:reportId,sourceDepartment:dept,reportDate:date});added++}else duplicates++}return {added,duplicates}}
 function validDate(s){return /^\d{4}-\d{2}-\d{2}$/.test(String(s||''))&&!Number.isNaN(Date.parse(s))}
 function importOne(p){return CORE.importReport(db,p)}
 async function processIncomingFiles(files){
  const list=[...files];if(!list.length)return;
  let ok=0,dups=0,errors=[],totals=Object.fromEntries(COLLECTIONS.map(k=>[k,0])),log=[];
  $('#importStatus').textContent='جارٍ فحص ودمج '+list.length+' ملف...';
  for(const file of list){
   try{
    if(file.size>10*1024*1024)throw Error('حجم الملف يتجاوز 10 ميغابايت.');
    if(!/\\.json$/i.test(file.name)&&file.type!=='application/json')throw Error('امتداد الملف ليس JSON.');
    const p=JSON.parse(await file.text());CORE.validateDailyReport(p);
    if(db.imports.some(x=>x.exportId===p.exportId)){dups++;log.push({name:file.name,msg:'مكرر – لم تتم إعادة إضافته',ok:false});continue}
    await storeIncomingAttachments(p.records?.attachments||[]);
    const res=importOne(p);
    if(res.duplicate){dups++;log.push({name:file.name,msg:'مكرر – لم تتم إعادة إضافته',ok:false})}
    else{ok++;for(const k of COLLECTIONS)totals[k]+=res.counts[k]||0;log.push({name:file.name,msg:'تم الاستقبال: '+res.dept+' – '+p.meta.date,ok:true})}
   }catch(err){errors.push(file.name+': '+err.message);log.push({name:file.name,msg:'فشل: '+err.message,ok:false})}
  }
  persist();
  $('#importStatus').innerHTML=`<b>اكتمل الاستقبال.</b> ملفات جديدة: ${ok} · مكررة: ${dups} · أخطاء: ${errors.length}<br>السجلات المضافة: ${COLLECTIONS.map(k=>LABELS[k]+': '+totals[k]).join(' | ')}${errors.length?'<br><span class="danger">'+errors.map(esc).join('<br>')+'</span>':''}`;
  $('#receiverLog').innerHTML=log.slice(-12).reverse().map(x=>`<div><b>${esc(x.name)}</b><br><span class="${x.ok?'good':'danger'}">${esc(x.msg)}</span></div>`).join('');
  $('#importFiles').value='';
 }
 $('#importFiles').onchange=async e=>{if(!(await mdhConfirm('سيتم فحص ملفات JSON المحددة، ثم دمج التقارير الجديدة وحفظ المرفقات الأصلية. الملفات المكررة لن تُضاف مرة أخرى. هل تتابع؟','استيراد تقارير الأقسام'))){e.target.value='';return}await processIncomingFiles(e.target.files)};
 const drop=$('#reportDropZone');
 if(drop){
  ['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('dragover')}));
  ['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('dragover')}));
  drop.addEventListener('drop',async e=>{const files=e.dataTransfer.files;if(await mdhConfirm('سيتم فحص الملفات المسقطة ودمج التقارير الجديدة مع حفظ المرفقات الأصلية. هل تتابع؟','استيراد تقارير الأقسام'))await processIncomingFiles(files)});
  drop.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('#importFiles').click()}});
 }
 function dateReports(){const d=$('#filterDate').value;return db.reports.filter(x=>x.date===d)}
 function filtered(key){return db[key].filter(x=>x.reportDate===$('#filterDate').value)}
 function financeBalanceData(){return CORE.runningBalances(db.finance)}
 function financeSummary(rows){return CORE.summarizeFinance(rows)}
 function escRows(head,rows,vals){return rows.length?`<div style="overflow:auto"><table class="table"><thead><tr>${head.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${vals(r).map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`:'<p class="muted">لا توجد بيانات لهذا التاريخ.</p>'}

 function managerReportTable(headers,rows){if(!rows.length)return '<p class="manager-report-muted">لا توجد سجلات في هذا البند خلال اليوم المحدد.</p>';return `<table class="manager-report-table"><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${row.map(v=>`<td>${esc(v==null||v===''?'—':String(v))}</td>`).join('')}</tr>`).join('')}</tbody></table>`}
 function managerReportSectionContent(id,title,html,hasData){const section=$(id);if(section)section.hidden=!hasData;return html}
 function renderManagerDailyPrintReport(d,reports,cases,finance,issues,assessments,feedback,activity){
  const attachments=filtered('attachments'),deptStats=filtered('departmentStats');
  const received=new Set(reports.map(x=>x.department));
  const procRows=assessments.filter(x=>x.departmentProcedure===true);
  const applicable=procRows.filter(x=>x.execution!=='لا ينطبق');
  const evaluated=applicable.filter(x=>x.execution&&x.execution!=='لم يقيم');
  const scoreValues={'تم التنفيذ':1,'تم جزئياً':.5,'لم يتم التنفيذ':0,'متوقف':0};
  const executionPercent=evaluated.length?Math.round(evaluated.reduce((sum,x)=>sum+(scoreValues[x.execution]??0),0)/evaluated.length*100):0;
  const coveragePercent=applicable.length?Math.round(evaluated.length/applicable.length*100):0;
  const missing=DEPTS.filter(dep=>!received.has(dep));
  $('#managerPrintLogo').src=document.querySelector('#managerWorkspace header.top img')?.src||'';
  $('#managerPrintDailyMeta').innerHTML=`<span><b>التاريخ:</b> ${esc(d)}</span><span><b>عدد الأقسام المستلمة:</b> ${received.size} من ${DEPTS.length}</span><span><b>حالة التغطية:</b> ${received.size===DEPTS.length?'مكتمل':'جزئي'}</span><span><b>وقت الإصدار:</b> ${esc(new Date().toLocaleString('ar-YE'))}</span><span><b>رقم التقرير:</b> MDH-MGR-${dateName(d)}</span>`;
  const kpis=[['الأقسام المستلمة',received.size+'/'+DEPTS.length],['الحالات / المراجعين',cases.length],['مؤشرات النشاط',activity.length],['الإجراءات المقيمة',evaluated.length+'/'+applicable.length],['الحركات المالية',finance.length],['المرفقات',attachments.length]];
  $('#managerPrintDailyKpis').innerHTML=kpis.map(x=>`<div class="manager-report-kpi"><b>${esc(x[1])}</b><span>${esc(x[0])}</span></div>`).join('');
  const pendingFeedback=feedback.filter(x=>!['مغلق','تم الحل','منجز','معتمد'].includes(String(x.status||''))).length;
  const executive=[
   ['استلام الأقسام',`${received.size} / ${DEPTS.length}`,missing.length?`متبقي ${missing.length} أقسام`:'اكتمل الاستلام',missing.length?'warn':'good'],
   ['النشاط والخدمات',`${cases.length} حالة · ${activity.length} مؤشر`,`${assessments.length} تقييم إجراء مسجل`,'info'],
   ['جودة التنفيذ',applicable.length?`${executionPercent}%`:'—',applicable.length?`تغطية التقييم ${coveragePercent}%`:'لا توجد إجراءات قابلة للتقييم','info'],
   ['المتابعة الإدارية والمالية',`${issues.length} مشكلة · ${feedback.length} مراسلة`,`${pendingFeedback} بند متابعة مفتوح · ${finance.length} حركة مالية`,'warn']
  ];
  $('#managerPrintExecutiveSummary').innerHTML=executive.map((x,i)=>`<article class="manager-exec-card tone-${x[3]}"><span class="manager-exec-index">0${i+1}</span><small>${esc(x[0])}</small><b>${esc(x[1])}</b><span>${esc(x[2])}</span></article>`).join('');
  const dailyLabels={shiftNote:'ملخص المناوبة',triageCount:'عدد حالات الفرز',criticalCount:'الحالات الحرجة',transferredCount:'الإحالات والتحويلات',transfers:'التحويلات',admissions:'حالات الدخول',discharges:'حالات الخروج',shiftDoctor:'طبيب النوبة',shiftNurse:'ممرض النوبة',handoverNotes:'ملاحظات الاستلام والتسليم',notes:'ملاحظات التشغيل',nurse:'الممرض المسؤول',responsible:'المسؤول المناوب',shiftResponsible:'مسؤول النوبة',cashCases:'الحالات النقدية',creditCases:'الحالات الآجلة'};
  const byDept=DEPTS.map(dep=>({dep,items:reports.filter(r=>r.department===dep)}));
  const deptCards=byDept.flatMap(({dep,items})=>{
   if(!items.length)return [`<article class="manager-dept-card is-pending"><div class="manager-dept-card-top"><b>${esc(dep)}</b><span class="manager-status-pill pending">بانتظار الاستلام</span></div><div class="manager-dept-card-foot"><span>لم يرد تقرير لهذا اليوم</span><span>—</span></div></article>`];
   return items.map(r=>{const countFor=k=>db[k].filter(x=>x.sourceReport===r.exportId).length;return `<article class="manager-dept-card is-received"><div class="manager-dept-card-top"><b>${esc(dep)}${r.branchName?' · '+esc(r.branchName):''}</b><span class="manager-status-pill received">تم الاستلام</span></div><div class="manager-dept-meta"><span>المسؤول: <b>${esc(r.officer||'—')}</b></span><span>الوردية: <b>${esc(r.shift||'اليومي')}</b></span></div><div class="manager-dept-metrics"><span><b>${countFor('cases')}</b><small>حالات</small></span><span><b>${countFor('activity')}</b><small>مؤشرات</small></span><span><b>${countFor('assessments')}</b><small>تقييمات</small></span><span><b>${countFor('finance')}</b><small>حركات مالية</small></span></div></article>`});
  });
  $('#managerPrintDepartments').innerHTML=deptCards.join('');
  $('#managerPrintDepartmentNotes').innerHTML=missing.length?`<div class="manager-report-note manager-missing-note"><b>متابعة مطلوبة:</b> لم تصل تقارير ${missing.length} أقسام: ${esc(missing.join('، '))}</div>`:`<div class="manager-report-note manager-success-note"><b>اكتمال الاستلام:</b> تم استلام تقارير جميع الأقسام المدرجة في النظام لهذا التاريخ.</div>`;
  const opCards=reports.map(r=>{
   const summary=r.dailySummary||{};
   const entries=Object.entries(summary).filter(([k,v])=>!['department','date','updatedAt','branchName'].includes(k)&&v!==''&&v!=null);
   const defs=DEPT_DAILY_FIELDS[r.department]||[];
   const defMap=Object.fromEntries(defs.map(([key,label,type])=>[key,{label,type}]));
   const fields=entries.map(([key,value])=>{const def=defMap[key]||{};const label=def.label||dailyLabels[key]||key.replace(/([A-Z])/g,' $1');const long=(def.type==='textarea'||/notes|handover|shortages|stockouts|supplies|fired|shortage/i.test(key)||String(value).length>54);return `<div class="manager-op-field ${long?'is-long':''}"><span>${esc(label)}</span><b>${esc(value)}</b></div>`}).join('');
   const operational=r.departmentOperations||{},opFieldRows=[...Object.entries(operational.fields||{}),...Object.entries(operational.notes||{})].filter(([,v])=>v!==''&&v!=null).map(([k,v])=>`<div class="manager-op-field ${String(v).length>50?'is-long':''}"><span>${esc(operational.fieldMeta?.[k]||operational.noteMeta?.[k]||k)}</span><b>${esc(v)}</b></div>`).join('');
   const opTables=Object.entries(operational.tables||{}).filter(([,rows])=>Array.isArray(rows)&&rows.length).map(([key,rows])=>{const meta=operational.tableMeta?.[key]||{title:key,cols:Object.keys(rows[0]||{}).map(k=>[k,k])};const cols=meta.cols||[];return `<section class="manager-op-table"><h4>${esc(meta.title||key)}</h4><div class="table-wrap"><table><thead><tr>${cols.map(c=>`<th>${esc(c[1]||c[0])}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${cols.map(c=>`<td>${esc(row[c[0]]??'—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div></section>`}).join('');
   const operationalHtml=(opFieldRows||opTables)?`<div class="manager-op-extra">${opFieldRows?`<div class="manager-op-fields">${opFieldRows}</div>`:''}${opTables}</div>`:'';
   return `<article class="manager-op-card"><header><div><b>${esc(r.department)}</b>${r.branchName?`<span>${esc(r.branchName)}</span>`:''}</div><small>${esc(r.shift||'اليومي')} · ${esc(r.officer||'—')}</small></header><div class="manager-op-fields">${fields||'<div class="manager-op-empty">لم تُسجل حقول تشغيل إضافية في هذا التقرير.</div>'}</div>${operationalHtml}</article>`;
  });
  $('#managerPrintOperationalSummaries').innerHTML=opCards.join('')||'<p class="manager-report-muted">لم ترد تقارير تشغيلية من الأقسام لهذا اليوم.</p>';
  const caseData=cases.map((x,i)=>[i+1,x.sourceDepartment,(x.patientName||x.patient||x.name||'غير مدخل')+' / '+(x.caseNo||'—'),x.type||'—',(x.gender||'—')+' / '+(x.age||'—'),[x.area,x.village,x.phone].filter(Boolean).join(' · ')||'—',x.diagnosis||'—',[x.emergencyAction||x.procedure||x.finalProcedure,x.outcome].filter(Boolean).join(' / ')||'—',[x.doctor||'—',x.notes||''].filter(Boolean).join(' · ')]);
  $('#managerPrintCases').innerHTML=managerReportTable(['م','القسم','المراجع / رقم الملف','نوع الحالة','الجنس / العمر','المنطقة / القرية / التواصل','التشخيص','الإجراء / المآل','الطبيب / الملاحظات'],caseData);
  managerReportSectionContent('#managerPrintCaseSection','', '',cases.length>0);
  const activityData=activity.map((x,i)=>[i+1,x.sourceDepartment,x.metric||'—',x.value??'—',x.unit||'—',x.notes||'—']);
  $('#managerPrintActivity').innerHTML=managerReportTable(['م','القسم','مؤشر النشاط','القيمة','الوحدة','الملاحظات'],activityData);
  $('#managerPrintActivitySection').hidden=!activity.length;
  const assessData=assessments.map((x,i)=>[i+1,x.sourceDepartment,x.patientName||'—',x.area||'—',x.procedure||'—',x.execution||'—',x.rating==null?'—':x.rating+'/5',x.responsible||'—',x.notes||'—']);
  $('#managerPrintAssessments').innerHTML=managerReportTable(['م','القسم','المريض إن وجد','مجال التقييم','الإجراء','حالة التنفيذ','الدرجة','المسؤول','ملاحظات'],assessData);
  $('#managerPrintAssessmentSection').hidden=!assessments.length;
  const financeGroups=[...new Set(db.finance.filter(x=>String(x.date||x.reportDate||'')<=d).map(x=>(x.box||'بدون اسم')+'||'+(x.currency||'غير محدد')))];
  const financeSums=financeGroups.map(key=>{const [box,currency]=key.split('||'),before=db.finance.filter(x=>(x.box||'بدون اسم')+'||'+(x.currency||'غير محدد')===key&&String(x.date||x.reportDate||'')<d),todayRows=finance.filter(x=>(x.box||'بدون اسم')+'||'+(x.currency||'غير محدد')===key);const opening=before.reduce((sum,x)=>sum+num(x.debit)-num(x.credit),0),debit=todayRows.reduce((sum,x)=>sum+num(x.debit),0),credit=todayRows.reduce((sum,x)=>sum+num(x.credit),0),net=debit-credit;return {box,currency,opening,debit,credit,net,closing:opening+net};});
  $('#managerPrintFinanceSummary').innerHTML=finance.length?managerReportTable(['الصندوق','العملة','رصيد أول اليوم المحسوب','مدين اليوم','دائن اليوم','صافي الحركة','الرصيد الختامي المحسوب'],financeSums.map(x=>[x.box,x.currency,...[x.opening,x.debit,x.credit,x.net,x.closing].map(v=>num(v).toLocaleString('ar-YE'))])):'<p class="manager-report-muted">لا توجد حركات مالية لهذا اليوم.</p>';
  const financeData=finance.map(x=>[x.sourceDepartment,x.box||'—',(x.date||d)+' / '+(x.voucher||'—'),x.movement||'—',x.party||'—',x.currency||'—',num(x.debit).toLocaleString('ar-YE'),num(x.credit).toLocaleString('ar-YE'),x.statement||'—']);
  $('#managerPrintFinanceDetails').innerHTML=financeData.length?'<h4 class="manager-report-subheading">تفاصيل السندات والحركات</h4>'+managerReportTable(['القسم','الصندوق','التاريخ / السند','الحركة','الطرف','العملة','مدين','دائن','البيان'],financeData):'';
  $('#managerPrintFinanceSection').hidden=!finance.length&&!financeGroups.length;
  const issueData=issues.map((x,i)=>[i+1,x.sourceDepartment,x.category||'—',x.priority||'—',x.status||'—',x.location||'—',x.details||'—',x.action||'—']);
  $('#managerPrintIssues').innerHTML=managerReportTable(['م','القسم','التصنيف','الأولوية','الحالة','الموقع','التفاصيل','الإجراء / المعالجة'],issueData);
  $('#managerPrintIssuesSection').hidden=!issues.length;
  const feedbackData=feedback.map((x,i)=>[i+1,x.sourceDepartment,x.targetDepartment||'—',x.date||d,x.type||'—',x.priority||'—',x.status||'—',x.details||'—',x.response||'—']);
  $('#managerPrintFeedback').innerHTML=managerReportTable(['م','القسم المرسل','الجهة المستهدفة','التاريخ','النوع','الأولوية','الحالة','التفاصيل','الرد / الإجراء'],feedbackData);
  $('#managerPrintFeedbackSection').hidden=!feedback.length;
  const statLabels={cashCases:'نقدي',deferredCases:'آجل',creditCases:'آجل',insuranceCases:'تأمين',totalCases:'الإجمالي',count:'العدد',value:'القيمة',notes:'ملاحظات',metric:'المؤشر',unit:'الوحدة',paymentType:'طريقة الدفع'};
  const statTypeLabels={'laboratory-payment-counts':'إحصاءات معاملات المختبر','laboratory-tests':'إحصاءات الفحوصات المخبرية','imaging-counts':'إحصاءات خدمات الأشعة','pharmacy-dispensing':'إحصاءات صرف الأدوية'};
  const statsData=deptStats.map((x,i)=>[i+1,x.sourceDepartment,statTypeLabels[x.statType||x.type]||x.statType||x.type||'إحصاء تخصصي',Object.entries(x).filter(([k,v])=>!['id','sourceReport','sourceDepartment','reportDate','createdAt','statType','type'].includes(k)&&v!==''&&v!=null).map(([k,v])=>(statLabels[k]||k.replace(/([A-Z])/g,' $1'))+': '+v).join(' | ')||'—']);
  $('#managerPrintStats').innerHTML=managerReportTable(['م','القسم','نوع الإحصاء','التفاصيل والقيم المسجلة'],statsData);
  $('#managerPrintStatsSection').hidden=!deptStats.length;
  const attachmentData=attachments.map((x,i)=>[i+1,x.sourceDepartment,x.fileName||'ملف مرفق',x.description||'—',x.mimeType||'—',(Number(x.size)||0).toLocaleString('ar-YE')+' بايت']);
  $('#managerPrintAttachments').innerHTML=managerReportTable(['م','القسم','اسم الملف','الوصف','نوع الملف','الحجم'],attachmentData);
  $('#managerPrintAttachmentsSection').hidden=!attachments.length;
  const missingText=missing.length?'يتطلب استكمال تقارير الأقسام التالية: '+missing.join('، ')+'.':'تم استلام تقارير جميع الأقسام.';
  const review=reports.filter(r=>r.reviewStatus).reduce((o,r)=>{const k=r.reviewStatus;o[k]=(o[k]||0)+1;return o},{ });
  const reviewText=Object.entries(review).map(([k,v])=>k+': '+v).join('، ');
  const closingItems=[['استكمال التقارير',missingText],['مؤشر جودة التنفيذ',applicable.length?`بلغ معدل التنفيذ ${executionPercent}%، مع تغطية تقييم ${coveragePercent}%.`:'لم تُسجل إجراءات قابلة للتقييم خلال اليوم المحدد.'],['مراجعة واعتماد الأقسام',reviewText?'حالات المراجعة المسجلة: '+reviewText+'.':'لا توجد قرارات مراجعة مسجلة للتقارير الواردة.'],['الإقفال المالي',`عدد الحركات المالية المسجلة: ${finance.length}. تُطابق السندات والنقد الفعلي قبل اعتماد الإقفال.`]];
  $('#managerPrintClosing').innerHTML=`<div class="manager-closing-grid">${closingItems.map((x,i)=>`<article class="manager-closing-card"><span>0${i+1}</span><b>${esc(x[0])}</b><p>${esc(x[1])}</p></article>`).join('')}</div><p class="manager-report-note">أُعد هذا التقرير من بيانات التقارير المستوردة والسجلات التشغيلية والمالية المسجلة في النظام للتاريخ المحدد. وهو أداة متابعة إدارية، ولا يُغني عن مراجعة المستندات الأصلية واعتماد المسؤولين المختصين.</p>`;
  $('#managerPrintFooterDate').textContent='تاريخ الطباعة: '+new Date().toLocaleDateString('ar-YE');
 }

 function render(){const d=$('#filterDate').value,reports=dateReports(),received=new Set(reports.map(x=>x.department)),cases=filtered('cases'),finance=filtered('finance'),issues=filtered('issues'),assessments=filtered('assessments'),feedback=filtered('feedback'),activity=filtered('activity');
  $('#managerStats').innerHTML=[['الأقسام المستلمة',received.size],['الحالات',cases.length],['حركات الصناديق',finance.length],['المشكلات والاحتياجات',issues.length],['تقييمات الإجراءات',assessments.length],['الشكاوى والمقترحات',feedback.length]].map(x=>`<div class="stat"><b>${x[1]}</b><span>${x[0]}</span></div>`).join('');
  $('#departmentStatus').innerHTML=DEPTS.map(dep=>{const r=reports.filter(x=>x.department===dep);return `<div class="record"><b>${esc(dep)}</b><small>${r.length?`تم استلام ${r.length} تقرير/تقارير`:'لم يصل تقرير لهذا التاريخ'}</small><span class="${r.length?'good':'danger'}">${r.length?'مستلم':'بانتظار الاستلام'}</span></div>`}).join('');
  $('#metricTable').innerHTML=reports.length?reports.map(r=>{const procs=db.assessments.filter(x=>x.sourceReport===r.exportId&&x.departmentProcedure===true);const ps=r.departmentProcedures||{};const applicable=procs.filter(x=>x.execution!=='لا ينطبق'),assessed=applicable.filter(x=>x.execution&&x.execution!=='لم يقيم'),score=assessed.length?Math.round(assessed.reduce((a,x)=>a+({'تم التنفيذ':1,'تم جزئياً':.5,'لم يتم التنفيذ':0,'متوقف':0}[x.execution]??0),0)/assessed.length*100):null,coverage=applicable.length?Math.round(assessed.length/applicable.length*100):0;const procDetails=procs.length?`<div class="scoreline"><div class="score-ring" style="--score:${score??0}%"><b>${score===null?'—':score+'%'}</b></div><div class="score-copy"><strong>إنجاز الإجراءات</strong><br>اكتمال التقييم: ${coverage}% · المقيم ${assessed.length} من ${applicable.length}</div></div><details><summary>عرض إجراءات ${esc(r.department)} (${procs.length})</summary>${escRows(['الإجراء','حالة التنفيذ','الملاحظات'],procs,x=>[x.procedure,x.execution,x.notes])}</details>`:'<small>لم يتضمن التقرير متابعة إجراءات القسم التفصيلية.</small>';const deptCases=db.cases.filter(x=>x.sourceReport===r.exportId);const deptStats=db.departmentStats.filter(x=>x.sourceReport===r.exportId);const deptFiles=db.attachments.filter(x=>x.sourceReport===r.exportId);const deptActivity=db.activity.filter(x=>x.sourceReport===r.exportId);let specific='';if(r.department==='الطوارئ'){const actions={},diagnoses={};deptCases.forEach(x=>{const a=x.emergencyAction||x.outcome||'غير محدد';actions[a]=(actions[a]||0)+1;const d=String(x.diagnosis||'غير محدد').trim()||'غير محدد';diagnoses[d]=(diagnoses[d]||0)+1});specific=`<div class="procedure-summary"><span>الحالات: ${deptCases.length}</span><span>ذكور: ${deptCases.filter(x=>x.gender==='ذكر').length}</span><span>إناث: ${deptCases.filter(x=>x.gender==='أنثى').length}</span>${Object.entries(actions).map(([a,n])=>`<span>${esc(a)}: ${n}</span>`).join('')}</div><details><summary>توزيع الحالات حسب التشخيص</summary>${escRows(['التشخيص','عدد الحالات'],Object.entries(diagnoses),x=>x)}</details><details><summary>بيانات حالات الطوارئ التفصيلية</summary>${escRows(['المريض','العمر','الجنس','الهاتف','القرية','التشخيص','الإجراء'],deptCases,x=>[x.patientName||x.name,x.age,x.gender,x.phone,x.village,x.diagnosis,x.emergencyAction||x.outcome])}</details>`}else if(r.department==='المختبر'){const st=deptStats.filter(x=>x.statType==='laboratory-payment-counts').reduce((a,x)=>({cash:a.cash+num(x.cashCases),deferred:a.deferred+num(x.deferredCases),insurance:a.insurance+num(x.insuranceCases)}),{cash:0,deferred:0,insurance:0});specific=`<div class="procedure-summary"><span>نقدي: ${st.cash}</span><span>آجل: ${st.deferred}</span><span>تأمين: ${st.insurance}</span><span>الإجمالي: ${st.cash+st.deferred+st.insurance}</span></div>`}if(deptActivity.length){const cards=deptActivity.map(x=>`<div class="stat"><b>${esc(x.value??0)}</b><span>${esc(x.metric)}${x.unit?' · '+esc(x.unit):''}</span></div>`).join('');specific+=`<div class="special-summary">${cards}</div><details><summary>تفاصيل المؤشرات التشغيلية لقسم ${esc(r.department)} (${deptActivity.length})</summary>${escRows(['المؤشر','العدد','الوحدة','ملاحظات'],deptActivity,x=>[x.metric,x.value,x.unit,x.notes])}</details>`;}if(deptFiles.length)specific+=`<details open><summary>المرفقات المستلمة (${deptFiles.length})</summary>${deptFiles.map(f=>`<div>${esc(f.fileName)} · ${Math.round((Number(f.size)||0)/1024)} ك.ب</div>`).join('')}</details>`;const daily=r.dailySummary||{};const dailyEntries=Object.entries(daily).filter(([k,v])=>!['department','date','updatedAt'].includes(k)&&v!==''&&v!=null);if(dailyEntries.length){const labelMap=Object.fromEntries((DEPT_DAILY_FIELDS[r.department]||[]).map(([k,l])=>[k,l]));specific+=`<div class="special-summary">${dailyEntries.map(([k,v])=>`<div class="stat"><b>${esc(v)}</b><span>${esc(labelMap[k]||k)}</span></div>`).join('')}</div>`;}const reviewStatus=r.reviewStatus||'قيد المراجعة';const reviewButtons=`<div class="report-review-actions"><span class="review-status">حالة المراجعة: <b>${esc(reviewStatus)}</b></span><button class="btn secondary" type="button" data-manager-review="approved" data-report-id="${esc(r.exportId)}">اعتماد التقرير</button><button class="btn ghost" type="button" data-manager-review="returned" data-report-id="${esc(r.exportId)}">إرجاع للاستكمال</button></div>${r.managerDecisionNote?`<small>ملاحظة المدير: ${esc(r.managerDecisionNote)}</small>`:''}`;return `<div class="record"><b>${esc(r.department)}</b> · ${esc(r.shift)}<small>المسؤول: ${esc(r.officer||'—')} | ${COLLECTIONS.map(k=>LABELS[k]+': '+(r.counts?.[k]??0)).join(' | ')}</small>${reviewButtons}<div class="procedure-summary"><span>إجمالي الإجراءات: ${Number(ps.total)||procs.length}</span><span>مكتملة: ${Number(ps.completed)||0}</span><span>جزئية: ${Number(ps.partial)||0}</span><span>لم تنفذ: ${Number(ps.notCompleted)||0}</span><span>متوقفة: ${Number(ps.stopped)||0}</span><span>لا ينطبق: ${Number(ps.notApplicable)||0}</span><span>لم تقيم: ${Number(ps.notAssessed)||0}</span></div>${specific}${procDetails}<small>وقت الاستيراد: ${new Date(r.importedAt).toLocaleString('ar')}</small></div>`}).join(''):'<p class="muted">لم تُستورد تقارير لهذا التاريخ بعد.</p>';
  $('#allCases').innerHTML=escRows(['القسم','اسم المريض','رقم الملف','النوع','الجنس','العمر','الهاتف','القرية','المديرية','التشخيص','الطبيب','الإجراء'],cases,x=>[x.sourceDepartment,x.patientName||x.patient||x.name||'غير مدخل',x.caseNo||'—',x.type,x.gender,x.age,x.phone,x.village,x.area,x.diagnosis,x.doctor,x.emergencyAction||x.outcome]);
  const patientReportRows=[...cases.map(x=>({...x,patientRecordType:'حالة'})),...assessments.filter(x=>String(x.patientName||'').trim()).map(x=>({...x,patientRecordType:'إجراء مرتبط بمريض'}))];
  const attachments=filtered('attachments');
  $('#managerPrintPatientMeta').innerHTML=`التاريخ: <b>${esc(d)}</b>　|　عدد السجلات المرتبطة بمرضى: <b>${patientReportRows.length}</b>　|　الأقسام: ${esc([...new Set(patientReportRows.map(x=>x.sourceDepartment))].join('، ')||'—')}`;
  $('#managerPrintPatientTable').innerHTML=escRows(['م','القسم','نوع السجل','اسم المريض','رقم الملف','نوع الحالة / الإجراء','الجنس','العمر','الهاتف','القرية','التشخيص / المجال','الطبيب / المسؤول'],patientReportRows,(x)=>[patientReportRows.indexOf(x)+1,x.sourceDepartment,x.patientRecordType,x.patientName||x.patient||x.name||'غير مدخل',x.caseNo||'—',x.type||x.procedure||'—',x.gender,x.age,x.phone,x.village,x.diagnosis||x.area||'—',x.doctor||x.responsible||'—']);
  $('#managerPrintAttachmentMeta').textContent=`المرفقات الأصلية المستلمة: ${attachments.length} ملف. الملفات الأصلية متاحة للتنزيل، وتُضمّن كاملة في حزمة التقرير الموحد.`;
  $('#managerPrintAttachmentTable').innerHTML=escRows(['القسم','اسم الملف','الوصف','النوع','الحجم','وقت الاستلام'],attachments,x=>[x.sourceDepartment,x.fileName,x.description||'—',x.mimeType||'—',`${Math.round((Number(x.size)||0)/1024)} كيلوبايت`,x.uploadedAt||'—']);
  renderManagerDailyPrintReport(d,reports,cases,finance,issues,assessments,feedback,activity);
  const balances=financeBalanceData().filter(x=>x.reportDate===d);$('#allFinance').innerHTML=finance.length?`<div class="stats">${financeSummary(finance).map(x=>`<div class="stat"><b>${(x.debit-x.credit).toLocaleString('ar-YE')}</b><span>${esc(x.box)} · ${esc(x.currency)} (مدين − دائن)</span></div>`).join('')}</div>`+escRows(['القسم','الصندوق','التاريخ','العملة','مدين','دائن','الرصيد المتحرك','البيان'],balances,x=>[x.sourceDepartment,x.box,x.date,x.currency,num(x.debit),num(x.credit),x.runningBalance,x.statement]):'<p class="muted">لا توجد حركات مالية لهذا التاريخ.</p>';
  $('#allIssues').innerHTML=escRows(['القسم','التصنيف','الأولوية','الحالة','الموقع','التفاصيل','الإجراء'],issues,x=>[x.sourceDepartment,x.category,x.priority,x.status,x.location,x.details,x.action]);
  $('#allAssessments').innerHTML=escRows(['القسم','اسم المريض','رقم الملف','مجال التقييم','الإجراء','التنفيذ','الدرجة','المسؤول','الملاحظات'],assessments,x=>[x.sourceDepartment,x.patientName||'—',x.caseNo||'—',x.area,x.procedure,x.execution,x.rating,x.responsible,x.notes]);
  $('#allFeedback').innerHTML=escRows(['القسم','النوع','التاريخ','الأولوية','الحالة','التفاصيل','الرد'],feedback,x=>[x.sourceDepartment,x.type,x.date,x.priority,x.status,x.details,x.response]);
  $('#allAttachments').innerHTML=attachments.length?attachments.map(x=>`<div class="attachment-card"><div class="file-meta"><b>${esc(x.fileName)}</b><small>${esc(x.sourceDepartment)} · ${esc(x.description||'مرفق')} · ${Math.round((Number(x.size)||0)/1024)} كيلوبايت</small></div><button class="btn secondary" type="button" data-manager-attachment="${esc(x.id)}">تنزيل الملف</button></div>`).join(''):'<p class="muted">لا توجد مرفقات مستلمة لهذا التاريخ.</p>';
 }
 $('#filterDate').onchange=render;
 document.addEventListener('click',async e=>{const b=e.target.closest('[data-manager-attachment]');if(!b)return;try{const stored=await CORE.getFile(MANAGER_FILE_DB,b.dataset.managerAttachment);if(!stored?.blob)throw Error('الملف غير موجود في مخزن المدير.');download(stored.name||'MDH_attachment',stored.blob)}catch(err){alert(err.message||'تعذر تنزيل المرفق.')}});
 document.addEventListener('click',e=>{const b=e.target.closest('[data-manager-review]');if(!b)return;const reportId=b.dataset.reportId;const report=db.reports.find(x=>x.exportId===reportId);if(!report)return;const action=b.dataset.managerReview;const promptText=action==='approved'?'ملاحظات الاعتماد (اختياري):':'سبب الإعادة لاستكمال البيانات:';const note=prompt(promptText,report.managerDecisionNote||'');if(note===null)return;if(action==='returned'&&!note.trim()){alert('اكتب سبب الإعادة حتى تتمكن الإدارة من متابعة الاستكمال.');return;}report.reviewStatus=action==='approved'?'معتمد':'يحتاج استكمال';report.managerDecisionNote=note.trim();report.managerDecisionAt=new Date().toISOString();const imported=db.imports.find(x=>x.exportId===reportId);if(imported){imported.reviewStatus=report.reviewStatus;imported.managerDecisionNote=report.managerDecisionNote;imported.managerDecisionAt=report.managerDecisionAt;}persist();});
 $('#periodBuild').onclick=()=>{const from=$('#periodFrom').value,to=$('#periodTo').value;if(!from||!to||from>to){alert('تحقق من تاريخ بداية الفترة ونهايتها.');return}const reports=db.reports.filter(r=>r.date>=from&&r.date<=to);const byDept=DEPTS.map(dept=>{const rr=reports.filter(r=>r.department===dept);const sum={};for(const k of COLLECTIONS)sum[k]=rr.reduce((a,r)=>a+(Number(r.counts?.[k])||0),0);return {dept,reports:rr.length,sum}}).filter(x=>x.reports);const periodRows={};for(const k of COLLECTIONS)periodRows[k]=db[k].filter(x=>x.reportDate>=from&&x.reportDate<=to);const fin=CORE.summarizeFinance(periodRows.finance);const total=Object.fromEntries(COLLECTIONS.map(k=>[k,periodRows[k].length]));$('#periodOutput').innerHTML=`<div class="record"><b>الفترة: ${esc(from)} إلى ${esc(to)}</b><small>${reports.length} ملف/تقرير مستلم من ${byDept.length} قسم</small><div class="stats">${COLLECTIONS.map(k=>`<div class="stat"><b>${total[k]}</b><span>${LABELS[k]}</span></div>`).join('')}</div></div><h3>ملخص الأقسام</h3>${escRows(['القسم','عدد الملفات',...COLLECTIONS.map(k=>LABELS[k])],byDept,x=>[x.dept,x.reports,...COLLECTIONS.map(k=>x.sum[k])])}<h3>ملخص حركة الصناديق</h3>${escRows(['الصندوق','العملة','إجمالي المدين','إجمالي الدائن','صافي الحركة'],fin,x=>[x.box,x.currency,x.debit,x.credit,x.net])}`};
 $$('.tab').forEach(b=>b.onclick=()=>{$$('.tab').forEach(x=>x.classList.toggle('active',x===b));$$('.tabpane').forEach(x=>x.classList.toggle('hidden',x.id!=='pane-'+b.dataset.tab))});
 $('#managerExportBundle').onclick=async()=>{if(!(await mdhConfirm('سيتم تجهيز التقرير الإداري الموحد للتاريخ المحدد مع المرفقات الأصلية. هل تريد المتابعة؟','تصدير التقرير الموحد')))return;try{const d=$('#filterDate').value;const dayReports=db.reports.filter(x=>x.date===d);const dayRecords={};for(const k of COLLECTIONS)dayRecords[k]=db[k].filter(x=>(x.reportDate||x.date||'')===d);const dayFiles=(db.attachments||[]).filter(x=>x.reportDate===d);const embeddedFiles=await exportAttachmentsForBackup(dayFiles);const bundle={schema:'MDH-MANAGER-DAY-2',kind:'manager-unified-daily-report',createdAt:new Date().toISOString(),date:d,summary:{reports:dayReports.length,departments:[...new Set(dayReports.map(x=>x.department))],recordCounts:Object.fromEntries(COLLECTIONS.map(k=>[k,dayRecords[k].length])),attachments:embeddedFiles.length},reports:dayReports,records:dayRecords,attachments:embeddedFiles};const blob=jsonBlob(bundle);if(blob.size>30*1024*1024&&!confirm(`حجم حزمة التقرير ${(blob.size/1024/1024).toFixed(1)} ميغابايت. هل تريد المتابعة؟`))return;download(`MDH_MANAGER_UNIFIED_${dateName(d)}_WITH_ATTACHMENTS.json`,blob);alert(`تم إنشاء حزمة التقرير الموحد مع ${embeddedFiles.length} مرفقاً أصلياً.`);}catch(err){alert('تعذر إنشاء حزمة التقرير الموحد: '+err.message)}};
 $('#managerBackup').onclick=async()=>{if(!(await mdhConfirm('سيتم إنشاء نسخة احتياطية كاملة لقاعدة المدير ومرفقاتها. احفظها في مكان آمن. هل تريد المتابعة؟','نسخ قاعدة المدير احتياطياً')))return;try{const backup={...db,attachments:await exportAttachmentsForBackup(db.attachments||[]),backupCreatedAt:new Date().toISOString()};download(`MDH_MASTER_BACKUP_${dateName(today())}.json`,jsonBlob(backup))}catch(err){alert('تعذر تضمين المرفقات في النسخة الاحتياطية: '+err.message)}};
 $('#restoreBackup').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{if(f.size>50*1024*1024)throw Error('حجم النسخة كبير جداً.');const p=JSON.parse(await f.text());if(!p||!Array.isArray(p.imports)||!p.schema?.startsWith('MDH-MASTER'))throw Error('ملف النسخة المركزية غير صالح.');if(!(await mdhConfirm('ستُستبدل قاعدة بيانات المدير الحالية بمحتويات النسخة الاحتياطية. تأكد من وجود نسخة أمان حديثة قبل المتابعة. هل تريد الاستمرار؟','استعادة النسخة الاحتياطية')))return;await storeIncomingAttachments(p.attachments||[]);db={...p};db.attachments=(p.attachments||[]).map(x=>{const clean={...x};delete clean.dataUrl;delete clean.base64;delete clean.fileData;return clean});for(const k of COLLECTIONS)if(!Array.isArray(db[k]))db[k]=[];persist();alert('تمت استعادة نسخة المدير بنجاح.')}catch(err){alert('تعذرت الاستعادة: '+err.message)}e.target.value=''};
 $('#csvBtn').onclick=async()=>{if(!(await mdhConfirm('سيتم تصدير ملخص أداء الأقسام بالتاريخ المحدد بصيغة CSV. هل تريد المتابعة؟','تصدير ملخص الأقسام')))return;const rows=[['التاريخ','القسم','المسؤول','الدوام',...COLLECTIONS.map(k=>LABELS[k])],...dateReports().map(r=>[r.date,r.department,r.officer,r.shift,...COLLECTIONS.map(k=>r.counts?.[k]||0)])];csvDownload(`MDH_Daily_Summary_${dateName($('#filterDate').value)}.csv`,rows)};
 $('#dataCsvBtn').onclick=async()=>{if(!(await mdhConfirm('سيتم تصدير تفاصيل السجلات التشغيلية والمالية في ملف CSV. قد يتضمن الملف بيانات حساسة؛ احفظه في مكان آمن. هل تريد المتابعة؟','تصدير البيانات التفصيلية')))return;const d=$('#filterDate').value,rows=[['نوع السجل','القسم','التاريخ','اسم المريض','رقم الملف','المعرف','البيانات'],...COLLECTIONS.flatMap(k=>filtered(k).map(r=>[LABELS[k],r.sourceDepartment,r.reportDate,(['cases','assessments'].includes(k)?(r.patientName||r.patient||r.name||''):'', ['cases','assessments'].includes(k)?(r.caseNo||''):''),r.id,JSON.stringify(r)]))];csvDownload(`MDH_Daily_Detail_${dateName(d)}.csv`,rows)};
 $('#printBtn').onclick=async()=>{if(await mdhConfirm('سيتم إنشاء التقرير الإداري والمحاسبي المستقل للتاريخ المحدد. لن تظهر واجهة البرنامج في المطبوع. هل تريد المتابعة؟','طباعة التقرير الإداري')){render();const oldTitle=document.title;document.title='التقرير الإداري والمحاسبي اليومي الموحد - '+($('#filterDate').value||today());const restore=()=>{document.title=oldTitle;window.removeEventListener('afterprint',restore)};window.addEventListener('afterprint',restore,{once:true});window.print();setTimeout(()=>{if(document.title!==oldTitle)restore()},120000)}};render();
}

if(document.body.dataset.mode==='manager')manager();
})();
