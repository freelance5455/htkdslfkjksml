package com.mdh.sectionsmanager;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private static final String START_URL = "https://appassets.androidplatform.net/assets/www/index.html?mode=home";
    private static final long MAX_FILE_BYTES = 50L * 1024L * 1024L;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;
    private final ExecutorService fileIo = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(10, 53, 89));
        getWindow().setNavigationBarColor(Color.rgb(10, 53, 89));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(242, 246, 248));
        webView.setOverScrollMode(WebView.OVER_SCROLL_IF_CONTENT_SCROLLS);
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setTextZoom(100);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setBlockNetworkLoads(true);

        webView.addJavascriptInterface(new AndroidBridge(), "MDHAndroid");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;

                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    // The HTML file input controls accepted types; allow all attachment formats here.
intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                            fileChooserParams != null
                                    && fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception error) {
                    pendingFileCallback = null;
                    filePathCallback.onReceiveValue(null);
                    showToast("تعذر فتح مستعرض الملفات على هذا الهاتف.");
                    return true;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme())
                        && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())) {
                    return interceptBundledAsset(uri);
                }
                // Every app resource must be bundled locally. Do not fetch remote pages or scripts.
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equalsIgnoreCase(uri.getScheme())
                        && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost()));
            }

        });

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(242, 246, 248));
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (savedInstanceState != null) {
            WebViewTransportState.restore(webView, savedInstanceState, START_URL);
        } else {
            webView.loadUrl(START_URL);
        }
    }

    /** Serves only APK-bundled files through the app's stable HTTPS origin. */
    private WebResourceResponse interceptBundledAsset(Uri uri) {
        List<String> parts = uri.getPathSegments();
        if (parts.size() < 3 || !"assets".equals(parts.get(0)) || !"www".equals(parts.get(1))) {
            return notFoundResponse();
        }
        StringBuilder assetPath = new StringBuilder("www");
        for (int i = 2; i < parts.size(); i++) {
            String part = parts.get(i);
            if (part == null || part.isEmpty() || part.equals(".") || part.equals("..")
                    || !part.matches("[A-Za-z0-9._-]+")) {
                return notFoundResponse();
            }
            assetPath.append('/').append(part);
        }
        String assetName = assetPath.toString();
        String mime = mimeForAsset(assetName);
        String encoding = (mime.startsWith("text/") || mime.contains("javascript")
                || mime.contains("json")) ? "UTF-8" : null;
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        headers.put("X-Content-Type-Options", "nosniff");
        try {
            InputStream input = getAssets().open(assetName);
            return new WebResourceResponse(mime, encoding, 200, "OK", headers, input);
        } catch (Exception error) {
            return notFoundResponse();
        }
    }

    private static String mimeForAsset(String path) {
        String lower = path.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    private static WebResourceResponse notFoundResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (pendingFileCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    results = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) {
                        results[i] = clip.getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            pendingFileCallback.onReceiveValue(results);
            pendingFileCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        fileIo.shutdown();
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("MDHAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void saveIntoDownloads(String fileName, String mimeType, byte[] bytes) {
        try {
            String safeName = safeFileName(fileName);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, safeMime(mimeType));
                values.put(MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/MDH");
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (item == null) throw new IllegalStateException("لم يتمكن Android من إنشاء ملف التنزيل.");
                try (OutputStream output = getContentResolver().openOutputStream(item, "w")) {
                    if (output == null) throw new IllegalStateException("تعذر فتح ملف التنزيل للكتابة.");
                    output.write(bytes);
                    output.flush();
                } catch (Exception e) {
                    getContentResolver().delete(item, null, null);
                    throw e;
                }
                ContentValues publish = new ContentValues();
                publish.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(item, publish, null, null);
                showToast("تم حفظ الملف في التنزيلات/MDH: " + safeName);
            } else {
                File folder = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (folder == null) throw new IllegalStateException("مجلد التنزيلات غير متاح.");
                File mdhFolder = new File(folder, "MDH");
                if (!mdhFolder.exists() && !mdhFolder.mkdirs()) {
                    throw new IllegalStateException("تعذر إنشاء مجلد MDH.");
                }
                File outputFile = new File(mdhFolder, safeName);
                try (FileOutputStream output = new FileOutputStream(outputFile)) {
                    output.write(bytes);
                    output.flush();
                }
                showToast("تم حفظ الملف في مساحة التطبيق: " + safeName);
            }
        } catch (Exception error) {
            showToast("تعذر حفظ الملف: " + error.getMessage());
        }
    }

    private Uri prepareShareFile(String fileName, byte[] bytes) throws Exception {
        String safeName = safeFileName(fileName);
        File folder = new File(getCacheDir(), "share");
        if (!folder.exists() && !folder.mkdirs()) {
            throw new IllegalStateException("تعذر تجهيز مجلد المشاركة.");
        }
        File sharedFile = new File(folder, safeName);
        try (FileOutputStream output = new FileOutputStream(sharedFile)) {
            output.write(bytes);
            output.flush();
        }
        return new Uri.Builder()
                .scheme("content")
                .authority(getPackageName() + ".files")
                .appendPath("share")
                .appendPath(safeName)
                .build();
    }

    private void launchShareSheet(String fileName, String mimeType, Uri uri) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(safeMime(mimeType));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, safeFileName(fileName));
            send.setClipData(ClipData.newUri(getContentResolver(), safeFileName(fileName), uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "إرسال ملف مستشفى الضالع الحديث"));
        } catch (Exception error) {
            showToast("تعذرت مشاركة الملف: " + error.getMessage());
        }
    }

    private void startPrintJob() {
        try {
            if (webView == null) return;
            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
            if (printManager == null) throw new IllegalStateException("خدمة الطباعة غير متاحة.");
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("MDH_Report");
            PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("mdh300", "MDH 300 DPI", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
            printManager.print("تقرير مستشفى الضالع الحديث", adapter, attributes);
        } catch (Exception error) {
            showToast("تعذرت تهيئة الطباعة: " + error.getMessage());
        }
    }

    private static String safeFileName(String name) {
        String value = name == null ? "MDH_file" : name;
        value = value.replace('\\', '_').replace('/', '_');
        value = value.replaceAll("[\\\\:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (value.isEmpty() || value.equals(".") || value.equals("..")) value = "MDH_file";
        if (value.length() > 150) value = value.substring(0, 150);
        return value;
    }

    private static String safeMime(String mime) {
        if (mime == null) return "application/octet-stream";
        String base = mime.split(";", 2)[0].trim().toLowerCase(java.util.Locale.ROOT);
        if (!base.matches("[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+")) {
            return "application/octet-stream";
        }
        return base;
    }

    private static byte[] decodeBase64(String value) {
        if (value == null || value.length() > (MAX_FILE_BYTES * 4L / 3L) + 16L) {
            throw new IllegalArgumentException("حجم الملف يتجاوز الحد المسموح.");
        }
        byte[] bytes = android.util.Base64.decode(value, android.util.Base64.DEFAULT);
        if (bytes.length > MAX_FILE_BYTES) {
            throw new IllegalArgumentException("حجم الملف يتجاوز 50 ميغابايت.");
        }
        return bytes;
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show());
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String name, String mimeType, String base64) {
            try {
                byte[] bytes = decodeBase64(base64);
                fileIo.execute(() -> saveIntoDownloads(name, mimeType, bytes));
            } catch (Exception error) {
                showToast("تعذر تجهيز الملف للحفظ: " + error.getMessage());
            }
        }

        @JavascriptInterface
        public void shareFile(String name, String mimeType, String base64) {
            try {
                byte[] bytes = decodeBase64(base64);
                fileIo.execute(() -> {
                    try {
                        Uri uri = prepareShareFile(name, bytes);
                        runOnUiThread(() -> launchShareSheet(name, mimeType, uri));
                    } catch (Exception error) {
                        showToast("تعذرت مشاركة الملف: " + error.getMessage());
                    }
                });
            } catch (Exception error) {
                showToast("تعذر تجهيز الملف للمشاركة: " + error.getMessage());
            }
        }

        @JavascriptInterface
        public String renderPdfPages(String base64) {
            File tempPdf = null;
            try {
                if (base64 == null || base64.length() > 5_500_000) return "[]";
                byte[] pdfBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                if (pdfBytes.length == 0 || pdfBytes.length > 4 * 1024 * 1024) return "[]";
                tempPdf = new File(getCacheDir(), "mdh_attachment_" + System.nanoTime() + ".pdf");
                try (FileOutputStream output = new FileOutputStream(tempPdf)) {
                    output.write(pdfBytes);
                    output.flush();
                }
                JSONArray result = new JSONArray();
                int totalPages = 0;
                try (ParcelFileDescriptor descriptor =
                             ParcelFileDescriptor.open(tempPdf, ParcelFileDescriptor.MODE_READ_ONLY)) {
                    PdfRenderer renderer = new PdfRenderer(descriptor);
                    try {
                        totalPages = renderer.getPageCount();
                        int pages = Math.min(totalPages, 12);
                        for (int i = 0; i < pages; i++) {
                            PdfRenderer.Page page = renderer.openPage(i);
                            Bitmap bitmap = null;
                            try {
                                float scale = Math.min(1400f / page.getWidth(), 1800f / page.getHeight());
                                int width = Math.max(1, Math.round(page.getWidth() * scale));
                                int height = Math.max(1, Math.round(page.getHeight() * scale));
                                bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                                bitmap.eraseColor(android.graphics.Color.WHITE);
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                                ByteArrayOutputStream imageBytes = new ByteArrayOutputStream();
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 78, imageBytes);
                                result.put("data:image/jpeg;base64," +
                                        android.util.Base64.encodeToString(imageBytes.toByteArray(),
                                                android.util.Base64.NO_WRAP));
                            } finally {
                                if (bitmap != null) bitmap.recycle();
                                page.close();
                            }
                        }
                    } finally {
                        renderer.close();
                    }
                }
                JSONObject response = new JSONObject();
                response.put("total", totalPages);
                response.put("pages", result);
                return response.toString();
            } catch (Exception error) {
                return "[]";
            } finally {
                if (tempPdf != null && tempPdf.exists()) tempPdf.delete();
            }
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(MainActivity.this::startPrintJob);
        }
    }

    /** Keeps WebView's restored history only when it belongs to this bundled application origin. */
    private static final class WebViewTransportState {
        static void restore(WebView view, Bundle state, String fallbackUrl) {
            if (view.restoreState(state) == null || view.getUrl() == null
                    || !view.getUrl().startsWith("https://appassets.androidplatform.net/assets/www/")) {
                view.loadUrl(fallbackUrl);
            }
        }
    }
}
