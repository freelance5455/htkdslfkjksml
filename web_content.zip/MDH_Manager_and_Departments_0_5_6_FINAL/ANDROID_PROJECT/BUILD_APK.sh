#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
chmod +x ./gradlew
./gradlew :app:assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -s "$APK" ]]; then
  echo "ERROR: build finished but APK was not found at $APK" >&2
  exit 2
fi
echo "APK created: $(pwd)/$APK"
