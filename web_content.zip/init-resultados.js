createCatalog('4', DATA_NOC, {
  unit: 'resultado(s)',
  unitCap: 'Resultados',
  sourceLabel: 'NOC — Nursing Outcomes Classification'
});
