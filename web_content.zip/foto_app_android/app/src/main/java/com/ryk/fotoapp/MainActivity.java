package com.ryk.fotoapp;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); WebView web = new WebView(this); web.setBackgroundColor(0xFF000000); web.getSettings().setJavaScriptEnabled(false); web.loadUrl("file:///android_asset/index.html"); setContentView(web); }
}
