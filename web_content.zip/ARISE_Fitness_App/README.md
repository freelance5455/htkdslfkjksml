# ARISE Fitness — Hunter System

**Version 1.0.0 · Offline-first HTML/CSS/JavaScript app**

A mobile-first bodyweight fitness tracker with a Solo Leveling-inspired progression system. It can be hosted as a static website/PWA and packaged by a compatible HTML-to-APK/WebView service.

## Included working features

- Six navigation areas: Home, Train, Progress, Calendar, Recovery and Profile
- Five guided sessions: full body, strength, low-impact cardio, mobility/recovery and walk/run
- Exercise-by-exercise countdown timer with pause, skip, previous and next controls
- Workout logging, XP, levels, ranks, daily quests and achievements
- Flexible weekly availability and activity calendar
- Weight and waist check-ins with history
- Sleep, energy, soreness, stress, pain and illness recovery check-in
- Water intake counter
- Seven-day training minutes chart, session totals, distance and streaks
- Local browser storage plus JSON export/import and reset
- PWA manifest and service worker for offline app shell

## Run locally

Open `index.html` for basic use. For PWA installation and offline caching, serve the folder from HTTPS or localhost. For example, with Python installed:

```bash
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Android packaging

1. Upload the project folder as a ZIP to a reputable HTML-to-APK/WebView builder.
2. Set `index.html` as the start page.
3. Enable JavaScript, local storage, DOM storage and file input/download support.
4. Set app name to ARISE and package ID to a unique reverse-domain identifier.
5. Build a test APK, install it on your device, and test all flows before distributing it.

A WebView wrapper is not automatically a fully native Android app. Notification scheduling in this version is best-effort while the app is active; Android background delivery is not guaranteed. For reliable scheduled notifications, native Android integration or a push-notification backend is required.

## Data and privacy

This build stores profile, training, recovery and measurement records locally in the browser/WebView storage. It does not send data to a server. Export a JSON backup before clearing app data, reinstalling, or moving devices.

## Limitations / next integrations

- No Google Drive cloud sync or account login (requires OAuth consent and Google API configuration).
- No hosted video library; exercise guidance is text-based.
- No medical diagnosis or personalized clinical advice.
- No native APK binary is included; this repository contains the web app source ready for packaging.
- The external Google Fonts import is decorative; the app remains usable with system fonts if offline.

## Safety

Start at a comfortable level. Do not train through sharp or worsening pain. Stop and seek urgent medical care for chest pain, fainting, severe breathlessness or other alarming symptoms. Recovery days are part of training.
