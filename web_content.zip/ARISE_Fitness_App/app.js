/* ARISE Fitness System — local-first app logic */
"use strict";
const STORE="arise_hunter_system_v1";
const $=s=>document.querySelector(s);
const today=()=>new Date().toLocaleDateString("en-CA");
const dateObj=s=>new Date(s+"T12:00:00");
const iso=d=>d.toLocaleDateString("en-CA");
const dayNames=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const defaultState=()=>({profile:{name:"Hunter",age:"",height:165,weight:75,experience:"beginner",goal:"fitness",sessionLength:20},xp:0,sessions:[],measurements:[],recovery:[],quests:{},availability:[1,2,3,4,5,6,0],water:{},reminder:{enabled:false,time:"18:00"},created:today()});
let state=loadState(),selectedDate=today(),calendarMonth=new Date(),activeWorkout=null,timerHandle=null,secondsLeft=30,timerRunning=false,exerciseIndex=0;
function loadState(){try{return {...defaultState(),...JSON.parse(localStorage.getItem(STORE)||"{}")}}catch(e){return defaultState()}}
function persist(){localStorage.setItem(STORE,JSON.stringify(state));renderAll()}
function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){let t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function daySessions(date){return state.sessions.filter(s=>s.date===date)}
function currentStreak(){let n=0,d=dateObj(today());while(daySessions(iso(d)).length){n++;d.setDate(d.getDate()-1)}return n}
function bestStreak(){let dates=[...new Set(state.sessions.map(s=>s.date))].sort();let best=0,run=0,last=null;for(const x of dates){let d=dateObj(x);if(last&&Math.round((d-last)/86400000)===1)run++;else run=1;best=Math.max(best,run);last=d}return best}
function levelData(){let level=Math.floor(state.xp/100)+1;return {level,into:state.xp%100,rank:level>=30?"S":level>=20?"A":level>=12?"B":level>=7?"C":level>=3?"D":"E"}}
function lastRecovery(){return state.recovery.filter(x=>x.date===today()).at(-1)}
function recoveryAdvice(r){if(!r)return "Complete your check-in to receive a training suggestion.";if(r.pain||r.sick)return "Recovery priority: skip strenuous training today. Rest, hydrate and seek appropriate medical advice if symptoms are concerning or persist.";if(r.sleep<5||r.energy<=2||r.soreness>=4||r.stress>=5)return "Keep today light: an easy walk, gentle mobility or full rest. Reduce intensity and reassess tomorrow.";return "Your check-in looks reasonable for a planned session. Warm up, use controlled form and stop if pain or unusual symptoms appear."}
const workouts=[
{id:"full",name:"Full-body foundation",icon:"⚔",focus:"FULL BODY",duration:"15–25 MIN",desc:"A balanced beginner-friendly session covering legs, pushing, core and gentle movement.",xp:30,exercises:[
["March in place",45,"Walk on the spot, lift knees comfortably and swing arms naturally.","Keep your torso tall; use a slower pace if needed."],
["Chair squat",10,"Sit hips back as if reaching for a chair, then stand.","Use a real chair behind you for confidence. Keep knees tracking over feet."],
["Wall push-up",10,"Place hands on a wall at chest height, bend elbows and press away.","Keep body in a straight line. Move feet farther from wall to increase difficulty."],
["Glute bridge",12,"Lie on your back, knees bent, feet flat. Lift hips, squeeze glutes, lower slowly.","Do not over-arch your lower back."],
["Bird dog",8,"On hands and knees, extend opposite arm and leg, pause, then switch.","Move slowly and keep hips level."],
["Easy cooldown",60,"Walk slowly and breathe comfortably.","Finish feeling like you could do a little more."]
]},
{id:"strength",name:"Strength basics",icon:"✦",focus:"STRENGTH",duration:"15–25 MIN",desc:"Controlled bodyweight movements to build a foundation of strength.",xp:30,exercises:[
["Gentle warm-up",60,"March in place and roll shoulders.","Start easy."],
["Chair squat",12,"Sit hips back toward a chair and stand with control.","Use the chair as a target; don't rush."],
["Wall push-up",10,"Push against a wall with a straight body line.","Keep elbows at a comfortable angle."],
["Glute bridge",12,"Lift hips by squeezing glutes, then lower slowly.","Avoid pushing through lower-back pain."],
["Standing calf raise",12,"Rise onto toes, pause, lower slowly.","Hold a wall for balance."],
["Bird dog",8,"Extend opposite arm and leg from hands-and-knees position.","Keep trunk steady."]
]},
{id:"cardio",name:"Low-impact cardio",icon:"➤",focus:"ENDURANCE",duration:"10–20 MIN",desc:"A low-impact way to build stamina without jumping.",xp:25,exercises:[
["Easy march",60,"March in place at a comfortable pace.","You should still be able to speak."],
["Side steps",45,"Step right and left, adding gentle arm swings.","Keep steps controlled."],
["Step-back taps",45,"Step one foot back, tap the toe, return and alternate.","Keep the range comfortable."],
["Standing knee lifts",40,"Lift alternating knees at a steady pace.","Do not pull your knees up with your hands."],
["Slow march cooldown",60,"Slow down and breathe steadily.","Stop if dizzy or unusually breathless."]
]},
{id:"mobility",name:"Mobility & recovery",icon:"✧",focus:"RECOVERY",duration:"8–12 MIN",desc:"Gentle mobility for days when you need to move without pushing hard.",xp:15,exercises:[
["Slow breathing",60,"Breathe calmly and let your shoulders relax.","Do not force deep breaths."],
["Shoulder circles",30,"Make slow, comfortable circles with both shoulders.","Avoid painful ranges."],
["Standing chest opener",30,"Gently bring arms back and open the chest.","No forcing or bouncing."],
["Cat-cow",8,"On hands and knees, gently round and extend the back.","Use a small pain-free range."],
["Ankle circles",30,"Circle each ankle slowly in both directions.","Hold support if needed."],
["Easy walk",90,"Walk slowly around your room or outdoors.","Skip if you feel unwell."]
]},
{id:"walk",name:"Walk / run session",icon:"⌁",focus:"CARDIO LOG",duration:"YOUR PACE",desc:"Record a walk or run. Build distance gradually and choose a pace you can sustain.",xp:20,exercises:[
["Warm-up walk",120,"Walk gently for two minutes.","Start slower than your planned pace."],
["Main walk / jog",600,"Continue at a comfortable pace. Walking is a valid session.","You should be able to speak in short sentences. Walk rather than run if needed."],
["Cool down",120,"Slow down gradually and finish with easy walking.","Stop for pain, chest discomfort, faintness or unusual breathlessness."]
]}
];
const questDefs=[{id:"move",name:"Move your body",desc:"Complete a workout or a walk",xp:20},{id:"water",name:"Hydration check",desc:"Log at least 4 cups of water",xp:10},{id:"recover",name:"Recovery check",desc:"Complete today's recovery check-in",xp:10},{id:"learn",name:"Know your form",desc:"Read an exercise tip before training",xp:5}];
function addXP(n){state.xp=Math.max(0,state.xp+n)}
function completeQuest(id){state.quests[today()]??={};if(state.quests[today()][id])return;let q=questDefs.find(q=>q.id===id);state.quests[today()][id]=true;addXP(q.xp);toast(q.name+" · +"+q.xp+" XP");persist()}
function renderHome(){
 let l=levelData(),p=state.profile;$("#homeName").textContent=p.name||"Hunter";$("#homeLevel").textContent=l.level;$("#rankChip").textContent=l.rank+"-RANK";$("#xpLabel").textContent=l.into+" / 100 XP";$("#xpFill").style.width=l.into+"%";$("#statWorkouts").textContent=state.sessions.length;$("#statStreak").textContent=currentStreak()+" days";$("#statXP").textContent=state.xp;$("#todayDate").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"});
 let recent=state.sessions.filter(s=>{let d=(dateObj(today())-dateObj(s.date))/86400000;return d>=0&&d<7}).length;
 let r=lastRecovery(),plan=(r&&(r.pain||r.sick||r.sleep<5||r.energy<=2||r.soreness>=4))?workouts[3]:(recent>=4?workouts[3]:workouts[0]);
 $("#planTitle").textContent=plan.name;$("#planDescription").textContent=plan.desc;$("#planDuration").textContent=plan.duration;$("#planFocus").textContent=plan.focus;$("#startPlan").dataset.workout=plan.id;
 let q=state.quests[today()]||{};$("#questList").innerHTML=questDefs.map(x=>`<div class="quest ${q[x.id]?"done":""}"><button class="quest-check" data-quest="${x.id}">${q[x.id]?"✓":""}</button><div class="quest-copy"><b>${x.name}</b><small>${x.desc}</small></div><span class="quest-xp">+${x.xp} XP</span></div>`).join("");
 $("#questList").querySelectorAll("[data-quest]").forEach(b=>b.onclick=()=>{let id=b.dataset.quest;if(id==="water"&&(state.water[today()]||0)<4){toast("Log 4 cups of water first.");return}if(id==="recover"&&!lastRecovery()){toast("Complete the recovery check-in first.");return}completeQuest(id)});
 let start=new Date();start.setDate(start.getDate()-((start.getDay()+6)%7));$("#weekGrid").innerHTML=Array.from({length:7},(_,i)=>{let d=new Date(start);d.setDate(d.getDate()+i);let key=iso(d),n=daySessions(key).length;return `<div class="week-day ${n?"active":""}"><small>${dayNames[i]}</small><b>${d.getDate()}</b><i></i></div>`}).join("");
}
function renderTraining(){$("#trainingCards").innerHTML=workouts.map(w=>`<article class="training-card"><div class="card-icon">${w.icon}</div><h3>${w.name}</h3><p>${w.desc}</p><button data-start="${w.id}">VIEW SESSION · ${w.exercises.length} STEPS</button></article>`).join("");$("#trainingCards").querySelectorAll("[data-start]").forEach(b=>b.onclick=()=>startWorkout(b.dataset.start))}
function renderProgress(){
 let total=state.sessions.reduce((a,s)=>a+(+s.duration||0),0),dist=state.sessions.reduce((a,s)=>a+(+s.distance||0),0);
 $("#progressSessions").textContent=state.sessions.length;$("#progressMinutes").textContent=total;$("#progressDistance").textContent=dist.toFixed(1)+" km";$("#progressStreak").textContent=bestStreak();
 let days=Array.from({length:7},(_,i)=>{let d=new Date();d.setDate(d.getDate()-(6-i));let k=iso(d);return {label:d.toLocaleDateString(undefined,{weekday:"short"}),min:state.sessions.filter(s=>s.date===k).reduce((a,s)=>a+(+s.duration||0),0)}}),max=Math.max(20,...days.map(x=>x.min));
 $("#minutesChart").innerHTML=days.map(x=>`<div class="bar-column"><i style="height:${Math.max(3,x.min/max*100)}%"></i><small>${x.label}</small></div>`).join("");
 let m=state.measurements.slice(-5).reverse();$("#measurementHistory").innerHTML=m.length?m.map(x=>`<div class="history-item"><div><b>${x.date}</b><small>${x.weight?x.weight+" kg":""}${x.weight&&x.waist?" · ":""}${x.waist?x.waist+" cm waist":""}</small></div></div>`).join(""):'<p class="muted">No measurements saved yet.</p>';
 let ss=state.sessions.slice(-8).reverse();$("#sessionHistory").innerHTML=ss.length?ss.map(s=>`<div class="history-item"><div><b>${escapeHTML(s.name||s.type)}</b><small>${s.date} · ${s.duration} min${s.distance?" · "+s.distance+" km":""}${s.effort?" · "+s.effort:""}</small></div><b>+${s.xp||0} XP</b></div>`).join(""):'<p class="muted">Your training sessions will appear here.</p>';
 let achievements=[["First steps",state.sessions.length>=1,"⚔","Log your first session"],["Getting consistent",state.sessions.length>=5,"✦","Complete 5 sessions"],["Ten quests",Object.values(state.quests).reduce((a,x)=>a+Object.values(x).filter(Boolean).length,0)>=10,"♛","Complete 10 daily quests"],["Seven-day streak",bestStreak()>=7,"🔥","Train on 7 consecutive days"],["Level 5",levelData().level>=5,"⬆","Reach level 5"],["Check-in habit",state.measurements.length>=3,"◎","Save 3 measurements"]];
 $("#achievements").innerHTML=achievements.map(a=>`<div class="achievement ${a[1]?"":"locked"}"><span>${a[2]}</span><div><b>${a[0]}</b><small>${a[1]?"UNLOCKED":a[3]}</small></div></div>`).join("");
}
function renderCalendar(){
 let y=calendarMonth.getFullYear(),m=calendarMonth.getMonth();$("#monthLabel").textContent=calendarMonth.toLocaleDateString(undefined,{month:"long",year:"numeric"});
 let first=new Date(y,m,1),offset=(first.getDay()+6)%7,count=new Date(y,m+1,0).getDate(),html="";
 for(let i=0;i<offset;i++)html+='<div class="calendar-day empty"></div>';
 for(let d=1;d<=count;d++){let key=iso(new Date(y,m,d)),classes=["calendar-day"];if(key===today())classes.push("today");if(key===selectedDate)classes.push("selected");if(daySessions(key).length)classes.push("has-workout");html+=`<button class="${classes.join(" ")}" data-date="${key}">${d}</button>`}
 $("#calendarGrid").innerHTML=html;$("#calendarGrid").querySelectorAll("[data-date]").forEach(b=>b.onclick=()=>{selectedDate=b.dataset.date;renderCalendar()});
 $("#selectedDateLabel").textContent=dateObj(selectedDate).toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"});
 let ss=daySessions(selectedDate);$("#selectedDayDetails").innerHTML=ss.length?ss.map(s=>`<div class="history-item"><div><b>${escapeHTML(s.name||s.type)}</b><small>${s.duration} minutes${s.distance?" · "+s.distance+" km":""}</small></div><b>+${s.xp} XP</b></div>`).join(""):"No training logged on this day.";
 $("#availabilityToggles").innerHTML=dayNames.map((d,i)=>`<button class="day-toggle ${state.availability.includes(i===6?0:i+1)?"on":""}" data-day="${i===6?0:i+1}">${d}</button>`).join("");
 $("#availabilityToggles").querySelectorAll("[data-day]").forEach(b=>b.onclick=()=>b.classList.toggle("on"));
}
function renderRecovery(){
 let w=state.water[today()]||0;$("#waterCount").textContent=w;$("#waterFill").style.width=Math.min(100,w/8*100)+"%";$("#recoveryAdvice").textContent=recoveryAdvice(lastRecovery());
}
function renderProfile(){
 let p=state.profile;$("#profileName").value=p.name||"";$("#profileAge").value=p.age||"";$("#profileHeight").value=p.height||"";$("#profileWeight").value=p.weight||"";$("#experience").value=p.experience||"beginner";$("#goal").value=p.goal||"fitness";$("#sessionLength").value=p.sessionLength||20;$("#reminderEnabled").checked=state.reminder.enabled;$("#reminderTime").value=state.reminder.time||"18:00";
 $("#notificationStatus").textContent=("Notification" in window)?"Browser notifications are supported; delivery may depend on app and device settings.":"This browser does not expose the Notifications API.";
}
function renderAll(){renderHome();renderTraining();renderProgress();renderCalendar();renderRecovery();renderProfile()}
function showTab(tab){document.querySelectorAll(".screen").forEach(x=>x.classList.toggle("active",x.id==="screen-"+tab));document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.tab===tab));window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("[data-tab]").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));
$("#changePlan").onclick=()=>showTab("train");$("#startPlan").onclick=()=>startWorkout($("#startPlan").dataset.workout||"full");
function startWorkout(id){activeWorkout=workouts.find(w=>w.id===id)||workouts[0];exerciseIndex=0;secondsLeft=activeWorkout.exercises[0][1];timerRunning=false;clearInterval(timerHandle);renderExercise();$("#workoutModal").classList.remove("hidden")}
function renderExercise(){let ex=activeWorkout.exercises[exerciseIndex];$("#workoutEyebrow").textContent=activeWorkout.focus+" · "+activeWorkout.duration;$("#workoutTitle").textContent=activeWorkout.name;$("#workoutIntro").textContent=activeWorkout.desc;$("#exerciseCounter").textContent=`STEP ${exerciseIndex+1} OF ${activeWorkout.exercises.length}`;$("#exerciseName").textContent=ex[0];$("#exerciseDetails").textContent=ex[2];$("#exerciseTip").textContent=ex[3];$("#timerValue").textContent=secondsLeft;$("#exerciseTimer").textContent=fmt(secondsLeft);$("#timerToggle").textContent=timerRunning?"PAUSE":"START";$("#previousExercise").disabled=exerciseIndex===0}
function fmt(n){return String(Math.floor(n/60)).padStart(2,"0")+":"+String(n%60).padStart(2,"0")}
function pauseTimer(){clearInterval(timerHandle);timerRunning=false}
function nextExercise(){pauseTimer();if(exerciseIndex<activeWorkout.exercises.length-1){exerciseIndex++;secondsLeft=activeWorkout.exercises[exerciseIndex][1];renderExercise()}else finishWorkout()}
function finishWorkout(){pauseTimer();let total=activeWorkout.exercises.reduce((a,x)=>a+x[1],0),mins=Math.max(1,Math.round(total/60));let isWalk=activeWorkout.id==="walk";let distance=isWalk?Number(prompt("Distance covered in km (optional; enter 0 if unknown):","0")||0):0;if(!Number.isFinite(distance)||distance<0)distance=0;let s={date:today(),type:activeWorkout.id,name:activeWorkout.name,duration:mins,distance,xp:activeWorkout.xp,effort:"Completed"};state.sessions.push(s);addXP(s.xp);state.quests[today()]??={};state.quests[today()].move=true;$("#workoutModal").classList.add("hidden");$("#finishSummary").textContent=`${activeWorkout.name} · ${mins} minutes${distance?" · "+distance+" km":""} recorded.`;$("#finishModal").classList.remove("hidden");persist()}
$("#timerToggle").onclick=()=>{if(timerRunning){pauseTimer();renderExercise();return}timerRunning=true;$("#timerToggle").textContent="PAUSE";timerHandle=setInterval(()=>{secondsLeft--;$("#timerValue").textContent=secondsLeft;$("#exerciseTimer").textContent=fmt(secondsLeft);if(secondsLeft<=0){pauseTimer();toast("Time complete — move to the next step.");$("#timerToggle").textContent="NEXT";$("#timerToggle").onclick=nextExercise}},1000)};
$("#nextExercise").onclick=nextExercise;$("#skipExercise").onclick=nextExercise;$("#previousExercise").onclick=()=>{pauseTimer();if(exerciseIndex>0){exerciseIndex--;secondsLeft=activeWorkout.exercises[exerciseIndex][1];renderExercise()}};
$("#closeWorkout").onclick=()=>{pauseTimer();$("#workoutModal").classList.add("hidden")};$("#finishDone").onclick=()=>{$("#finishModal").classList.add("hidden");showTab("progress")};
$("#prevMonth").onclick=()=>{calendarMonth.setMonth(calendarMonth.getMonth()-1);renderCalendar()};$("#nextMonth").onclick=()=>{calendarMonth.setMonth(calendarMonth.getMonth()+1);renderCalendar()};
$("#saveAvailability").onclick=()=>{state.availability=[...$("#availabilityToggles").querySelectorAll(".on")].map(b=>Number(b.dataset.day));persist();toast("Availability saved")};
$("#saveMeasurements").onclick=()=>{let weight=$("#weightField").value,waist=$("#waistField").value;if(!weight&&!waist){toast("Enter weight or waist first.");return}state.measurements.push({date:today(),weight:weight?Number(weight):null,waist:waist?Number(waist):null});if(weight)state.profile.weight=Number(weight);persist();toast("Measurements saved")};
["sleep","energy","soreness","stress"].forEach(id=>$("#"+id+"Range").oninput=e=>{$("#"+id+"Out").textContent=id==="sleep"?e.target.value+" hours":e.target.value+" / 5"});
$("#saveRecovery").onclick=()=>{let r={date:today(),sleep:Number($("#sleepRange").value),energy:Number($("#energyRange").value),soreness:Number($("#sorenessRange").value),stress:Number($("#stressRange").value),pain:$("#painCheck").checked,sick:$("#sickCheck").checked,notes:$("#recoveryNotes").value.trim()};state.recovery.push(r);state.quests[today()]??={};state.quests[today()].recover=true;$("#recoveryAdvice").textContent=recoveryAdvice(r);persist();toast("Recovery check-in saved")};
$("#waterPlus").onclick=()=>{state.water[today()]=Math.min(20,(state.water[today()]||0)+1);if(state.water[today()]>=4)completeQuest("water");else persist()};$("#waterMinus").onclick=()=>{state.water[today()]=Math.max(0,(state.water[today()]||0)-1);persist()};
$("#saveProfile").onclick=()=>{let p={name:$("#profileName").value.trim()||"Hunter",age:$("#profileAge").value,height:Number($("#profileHeight").value)||"",weight:Number($("#profileWeight").value)||"",experience:$("#experience").value,goal:$("#goal").value,sessionLength:Number($("#sessionLength").value)};state.profile={...state.profile,...p};persist();toast("Hunter profile updated")};
$("#saveReminder").onclick=async()=>{state.reminder={enabled:$("#reminderEnabled").checked,time:$("#reminderTime").value};if(state.reminder.enabled&&"Notification"in window&&Notification.permission==="default"){try{let p=await Notification.requestPermission();$("#notificationStatus").textContent="Notification permission: "+p}catch(e){}}persist();toast("Reminder preference saved")};
function checkReminder(){if(!state.reminder.enabled||!("Notification"in window)||Notification.permission!=="granted")return;let now=new Date(),time=state.reminder.time.split(":");if(now.getHours()===Number(time[0])&&now.getMinutes()===Number(time[1])){let key="arise-reminder-"+today();if(localStorage.getItem(key)!=="1"){new Notification("ARISE — Hunter System",{body:"Your training reminder is here. Check your energy and choose a manageable quest."});localStorage.setItem(key,"1")}}}
$("#quickReminder").onclick=()=>{showTab("profile");$("#reminderEnabled").scrollIntoView({behavior:"smooth",block:"center"});toast("Manage your training reminder")};
$("#exportData").onclick=exportBackup;function exportBackup(){let blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="ARISE-backup-"+today()+".json";a.click();URL.revokeObjectURL(url);toast("Backup exported")}
$("#importData").onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let d=JSON.parse(await f.text());if(!d.profile||!Array.isArray(d.sessions)||typeof d.xp!=="number")throw Error();state={...defaultState(),...d};persist();toast("Backup restored")}catch{toast("That backup file is invalid.")}e.target.value=""};
$("#resetData").onclick=()=>{if(confirm("This permanently deletes all ARISE data stored in this browser. Export a backup first. Continue?")){state=defaultState();persist();toast("App data reset.")}};
function checkProfile(){if(!localStorage.getItem(STORE))setTimeout(()=>{if(confirm("Welcome to ARISE. Set up your Hunter profile now?"))showTab("profile")},500)}
if("serviceWorker"in navigator&&location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
window.addEventListener("online",()=>$("#onlineDot").classList.remove("offline"));window.addEventListener("offline",()=>$("#onlineDot").classList.add("offline"));
if(!navigator.onLine)$("#onlineDot").classList.add("offline");
renderAll();checkProfile();setInterval(checkReminder,30000);
