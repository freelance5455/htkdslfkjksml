
let objects = [];
let generated = false;

const themes = {
    blue: "#268cff",
    red: "#ff4242",
    green: "#35dd77",
    purple: "#aa55ff",
    dark: "#555577"
};

function makeObject(id, x, y) {
    return { id, x, y };
}

function generateLevel() {
    const length = Math.max(
        10,
        Math.min(200, Number(document.getElementById("length").value) || 40)
    );

    objects = [];

    // Ground blocks
    for (let i = 0; i < length; i++) {
        objects.push(makeObject(1, i * 30, 0));
    }

    // Generate obstacles
    for (let i = 4; i < length - 2; i += 5) {
        objects.push(makeObject(8, i * 30, 30));
    }

    generated = true;

    drawPreview();

    document.getElementById("status").textContent =
        "Level generated! Objects: " + objects.length;
}

function drawPreview() {
    const canvas = document.getElementById("preview");
    const ctx = canvas.getContext("2d");

    const theme = localStorage.getItem("gdTheme") || "blue";
    const color = themes[theme] || themes.blue;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#151525";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const scale = 30;
    const camera = 0;

    for (const obj of objects) {
        const x = (obj.x - camera) / scale * 15;
        const y = 170 - obj.y / scale * 15;

        ctx.fillStyle = color;

        if (obj.id === 1) {
            ctx.fillRect(x, y - 15, 15, 15);
        } else if (obj.id === 8) {
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + 15, y);
            ctx.lineTo(x + 7.5, y - 18);
            ctx.closePath();
            ctx.fill();
        }
    }
}

function xmlEscape(value) {
    return String(value).replace(/[<>&'"]/g, char => ({
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;",
        "'": "&apos;",
        '"': "&quot;"
    })[char]);
}

function base64(text) {
    const bytes = new TextEncoder().encode(text);
    let binary = "";

    for (const byte of bytes) {
        binary += String.fromCharCode(byte);
    }

    return btoa(binary);
}

async function exportLevel() {
    if (!generated) {
        alert("Generate your level first!");
        return;
    }

    if (!("CompressionStream" in window)) {
        alert("Your browser does not support Gzip export. Try an updated Chrome browser.");
        return;
    }

    const name = document.getElementById("levelName").value || "Generated Level";
    const description = document.getElementById("description").value || "";
    const difficulty = Number(document.getElementById("difficulty").value);

    // Geometry Dash object data
    const levelString = objects.map(obj =>
        `1,${obj.id},2,${obj.x},3,${obj.y}`
    ).join(";") + ";";

    const xml =
`<?xml version="1.0"?>
<plist version="1.0">
<dict>
<k>k2</k><s>${xmlEscape(name)}</s>
<k>k3</k><s>${base64(description)}</s>
<k>k4</k><s>${xmlEscape(levelString)}</s>
<k>k5</k><s>GD Level Generator</s>
<k>k7</k><i>${difficulty}</i>
<k>k8</k><i>0</i>
<k>k13</k><t/>
<k>k16</k><i>1</i>
<k>k17</k><i>40</i>
<k>k21</k><i>2</i>
<k>k23</k><i>3</i>
<k>k39</k><i>${levelString.length}</i>
<k>k47</k><t/>
<k>k48</k><i>${objects.length}</i>
</dict>
</plist>`;

    try {
        const input = new Blob([xml]).stream();

        const compressed = input.pipeThrough(
            new CompressionStream("gzip")
        );

        const compressedBlob = await new Response(compressed).blob();

        const buffer = await compressedBlob.arrayBuffer();
        const bytes = new Uint8Array(buffer);

        let binary = "";
        const chunkSize = 8192;

        for (let i = 0; i < bytes.length; i += chunkSize) {
            binary += String.fromCharCode(
                ...bytes.subarray(i, i + chunkSize)
            );
        }

        const encoded = btoa(binary);

        const file = new Blob(
            [encoded],
            { type: "application/octet-stream" }
        );

        const url = URL.createObjectURL(file);
        const link = document.createElement("a");

        link.href = url;
        link.download = name.replace(/[^a-z0-9_-]/gi, "_") + ".gdlvl";

        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(() => URL.revokeObjectURL(url), 1000);

        document.getElementById("status").textContent =
            "Export created! Check your Downloads folder.";

    } catch (error) {
        console.error(error);
        alert("Export failed: " + error.message);
    }
}
