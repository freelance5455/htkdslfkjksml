PEMBELIAN OBAT — VERSI APK ANDROID
=================================

Perubahan utama:
1. Semua export Excel, PDF, PNG, dan JSON melewati bridge Android.
2. Pada APK, file otomatis disimpan ke:
   Download/Pembelian Obat/
3. Folder tersebut dapat dibuka melalui File Manager Android.
4. Database aplikasi juga dibuat salinan JSON otomatis:
   Download/Pembelian Obat/pembelian_obat_db_v3.json
5. Import Excel/PDF/JSON tetap menggunakan file chooser Android.
6. Jika HTML dijalankan sebagai web biasa, fallback penyimpanan browser tetap tersedia.

CATATAN:
- Proyek ini adalah source project Android Studio yang siap di-build menjadi APK.
- Build dilakukan di Android Studio/Gradle karena environment pembuatan file ini tidak menyediakan Android SDK.
- HTML asli dipertahankan; perubahan difokuskan pada integrasi penyimpanan Android.
- Dependensi JavaScript pada HTML masih menggunakan CDN yang sudah ada pada file sumber.
  Jika ingin 100% offline tanpa internet, library CDN perlu dibundel ke assets APK pada tahap berikutnya.

CARA BUILD:
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Build > Build APK(s).
4. Install APK hasil build.

LOKASI FILE:
Android 10+:
Download/Pembelian Obat/

Android lama:
Download/Pembelian Obat/
