// Remplace les valeurs ci-dessous par la configuration Web de TON projet Firebase.
// Ces paramètres se trouvent dans Firebase Console > Paramètres du projet > Tes applications > Application Web.
export const firebaseConfig = {
  apiKey: "REMPLACE_PAR_TON_API_KEY",
  authDomain: "REMPLACE_PAR_TON_PROJET.firebaseapp.com",
  databaseURL: "https://REMPLACE_PAR_TON_PROJET-default-rtdb.REGION.firebasedatabase.app",
  projectId: "REMPLACE_PAR_TON_PROJET",
  storageBucket: "REMPLACE_PAR_TON_PROJET.firebasestorage.app",
  messagingSenderId: "REMPLACE_PAR_TON_SENDER_ID",
  appId: "REMPLACE_PAR_TON_APP_ID"
};
