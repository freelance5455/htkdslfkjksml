JUSTICE 3D — PROJET ANDROID (VERSION DE TEST)

CE QUE CONTIENT CE ZIP
- Un projet Android natif minimal qui ouvre l'interface Justice 3D dans une WebView sécurisée.
- Les fichiers de l'application web multijoueur sont inclus dans app/src/main/assets/www/.
- Un workflow GitHub Actions qui peut compiler un APK de test dans le cloud.

IMPORTANT : CE ZIP N'EST PAS ENCORE UN APK ET L'APPLICATION N'EST PAS PRÊTE POUR LE PUBLIC.
Il faut d'abord configurer Firebase dans le fichier :
app/src/main/assets/www/firebase-config.js

CONFIGURATION FIREBASE
1. Créer un projet Firebase et une application Web.
2. Activer Authentication > Anonymous.
3. Créer Realtime Database et publier les règles de database.rules.json.
4. Dans Authentication > Settings > Authorized domains, ajouter :
   appassets.androidplatform.net
5. Remplacer les valeurs REMPLACE_... dans firebase-config.js par les valeurs du projet Firebase.
6. Ne jamais publier de mots de passe, clés privées ou codes de validation.

COMPILATION DANS LE CLOUD (À FAIRE SUR TÉLÉPHONE)
1. Décompresser ce ZIP sur le téléphone.
2. Dans GitHub, créer un dépôt (repository) vide nommé Justice3D.
3. Envoyer tous les fichiers et dossiers de ce projet dans le dépôt, en conservant les dossiers cachés comme .github.
4. Ouvrir l'onglet Actions du dépôt.
5. Choisir « Construire Justice 3D APK », puis « Run workflow ».
6. Attendre la fin du travail. Si le résultat est vert, ouvrir le travail terminé et télécharger l'artefact « Justice3D-APK-test ».
7. Décompresser l'artefact téléchargé : il contient app-debug.apk.

L'APK généré par ce workflow est une version de TEST signée en mode debug, pas une version officielle destinée à Google Play. GitHub conserve l'artefact 14 jours.

LIMITES ET SÉCURITÉ
- La voix en direct n'est pas incluse.
- Le multijoueur ne fonctionnera pas avant la configuration Firebase.
- Les rôles sont librement sélectionnables dans ce prototype : un participant peut se donner le rôle Juge. Le verdict n'a donc aucune autorité et le système n'est pas sécurisé pour un usage public.
- Avant une diffusion publique, il faudra renforcer les règles côté serveur, contrôler les rôles, ajouter modération, signalements traités et limites anti-spam.
- N'utilise que des scénarios judiciaires fictifs. Ne publie pas de vrais noms, accusations ou informations privées.
- Si GitHub ou Firebase demande une validation d'âge, une autorisation parentale ou un paiement, demande l'aide d'un parent/tuteur. Ne contourne pas ces demandes et n'ajoute pas de moyen de paiement.
