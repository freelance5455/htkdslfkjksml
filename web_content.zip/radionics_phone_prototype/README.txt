RADIONICS WORKBENCH — PHONE PROTOTYPE

Files:
- index.html: the app
- manifest.webmanifest and sw.js: support install/offline behavior when hosted

Quick test:
1. Unzip the folder.
2. Open index.html in a modern browser to test the interface.
3. Data is saved in that browser's local storage. Use Export backup regularly.

Android home-screen installation:
For the installable PWA experience, these files need to be served from an HTTPS website (for example, a private/static hosting location). Open that HTTPS page in Chrome on Android, then use the browser menu > Install app or Add to Home screen. Opening index.html directly from a file manager is useful for testing but usually will not enable PWA installation/offline caching.

Current features:
- 3, 6, 9, 12, or custom 1–24 numbered digit dials
- Each dial is a digit 0–9; leading zeroes are preserved
- Direct numerical entry
- Save/load/delete rate records
- Witness name/description and intention fields
- Add multiple rate sequences to one session
- Session timer and saved session history
- Frequency value notebook only (no audible or electromagnetic output)
- JSON export/import backup

Important:
This is an organizational/experimentation tool. It does not measure, diagnose, treat, or transmit radionics effects. No scientific evidence establishes radionics rates as effective treatments. Witness image selection is not uploaded and is not retained in this first prototype.
