import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mayonin.chronicles',
  appName: 'Mayonin Chronicles',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
