# Mayonin Chronicles — No-Termux Android route

## Recommended browser builder
WebIntoApp can turn a live website URL into an Android APK/AAB.

## Project preparation
This ZIP contains the source project plus the fighter power/voice manifest. It is a Vite/React source project, so the browser builder should receive the **published web URL**, not this source ZIP.

## App settings
- App name: Mayonin Chronicles
- Package: com.mayonin.chronicles
- Orientation: Landscape
- Target API: confirm the builder supports API 36 before a Google Play release.

## Fighter power rule
Every fighter has a distinct Special power name and a distinct activation voice line in `src/game/data/characters.ts`. The runtime displays the line during the power cinematic and plays the fighter's voice asset.
