# V4 Peak

Added: Red Blood Demon special, five Blood Slaves, two-fight cooldown, Episode 34 unlock, mentor boon field note, global episode SFX hooks, in-world dialogue walk-in presentation, and retained the Episode 35 finale cinematic.
