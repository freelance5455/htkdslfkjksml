# Mayonin Chronicles — Android 16 Build Configuration

This project is prepared for an Android 16 / API 36 Play Store target.

Required Android build settings:
- compileSdk = 36
- targetSdk = 36
- minSdk = 23
- Application ID: com.mayonin.chronicles
- App name: Mayonin Chronicles
- Orientation: landscape

The web output directory is `dist`.

For a native Android/Capacitor builder, use the project as the source and generate/sync the Android platform from this Capacitor configuration. The generated Android module must use compileSdk/targetSdk 36.

Important:
- `targetSdk 36` means the app targets Android 16 behavior; it does NOT mean Android 16 is the minimum supported OS.
- The final APK/AAB must be signed before Play Store upload.
- Google Play currently requires new apps/updates to target API 36 or higher (as of Aug. 31, 2026).

This ZIP contains source/configuration for the builder. It is not itself an APK.
