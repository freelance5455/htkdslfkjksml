import fs from "node:fs";
const src = fs.readFileSync("src/game/data/characters.ts", "utf8");
const fighters = [...src.matchAll(/id: "([^"]+)",\n    name: "([^"]+)"[\s\S]*?power: \{\n      id: "([^"]+)",\n      name: "([^"]+)",\n      voice: "([^"]+)"/g)];
const seenPowers = new Set();
const seenVoices = new Set();
let ok = true;
for (const [, id, name, powerId, powerName, voice] of fighters) {
  if (seenPowers.has(powerName)) { console.error(`Duplicate power name: ${powerName}`); ok=false; }
  if (seenVoices.has(voice)) { console.error(`Duplicate power voice line: ${voice}`); ok=false; }
  seenPowers.add(powerName); seenVoices.add(voice);
  console.log(`${name}: ${powerName} — “${voice}”`);
}
if (!fighters.length) { console.error("No fighters found"); process.exit(1); }
if (!ok) process.exit(1);
console.log(`PASS: ${fighters.length} fighter power/voice entries are unique.`);
