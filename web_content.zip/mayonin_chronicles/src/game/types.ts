export type Emotion =
  | "calm"
  | "happy"
  | "worried"
  | "sad"
  | "angry"
  | "fearful"
  | "shocked"
  | "determined"
  | "confused";

export type Role =
  | "commander"
  | "mentor"
  | "vanguard"
  | "ranged"
  | "heavy"
  | "debuffer"
  | "support"
  | "duelist"
  | "risk"
  | "controller"
  | "defender"
  | "assassin";

export type Formation = "front" | "middle" | "rear";
export type Rank = "normal" | "elite" | "color-fixer" | "arbiter" | "beyond" | "unmeasurable";
export type VariantKind =
  | "standard"
  | "elite"
  | "corrupted"
  | "ancient"
  | "aberrant"
  | "armored"
  | "ravager"
  | "guardian"
  | "support"
  | "hunter"
  | "temporal"
  | "boss";
export type AnomalyWeather =
  | "none"
  | "red-storm"
  | "time-distortion"
  | "silent-rain"
  | "gravity-shift"
  | "ashfall"
  | "eclipse";
export type EpisodeKind =
  | "story"
  | "battle"
  | "discovery"
  | "recruitment"
  | "character"
  | "exploration"
  | "supernatural"
  | "encounter"
  | "boss"
  | "lore"
  | "mystery";
export type ScreenId =
  | "boot"
  | "menu"
  | "episodes"
  | "squad"
  | "archive"
  | "settings"
  | "play"
  | "combat"
  | "rewards";
export type StatusId =
  | "shock"
  | "mark"
  | "overload"
  | "frost"
  | "impact"
  | "shatter"
  | "toxin"
  | "wither"
  | "guard"
  | "vulnerable"
  | "fatigue"
  | "armor-lock"
  | "blood-rush"
  | "delay";

export type TargetRule = "enemy" | "ally" | "self" | "all-enemies" | "all-allies" | "lowest-ally";

export interface AbilityDef {
  id: string;
  name: string;
  desc: string;
  target: TargetRule;
  power: number;
  clash: number;
  break: number;
  damage: number;
  heal?: number;
  shield?: number;
  status?: { id: StatusId; duration: number; stacks?: number };
  interrupt?: boolean;
  guardWindow?: boolean;
  finisher?: boolean;
  tags: string[];
}

export interface PowerDef {
  id: string;
  name: string;
  voice: string;
  desc: string;
  damage: number;
  break: number;
  clash: number;
  cinematic: "strike" | "volley" | "slam" | "bloom" | "pulse" | "star" | "chain" | "wall" | "reversal" | "imperial";
}

export interface CharacterDef {
  id: string;
  name: string;
  role: Role;
  weapon: string;
  rank: Rank;
  personality: string;
  lore: string;
  color: string;
  mark: string;
  abilities: AbilityDef[];
  power: PowerDef;
  battleLines: string[];
  victory: string;
  defeat: string;
  instincts: string;
  recruitEpisode: number;
  playable: boolean;
  maxHp: number;
  speed: number;
  defense: number;
  clashBonus: number;
  overloadDrawback: string;
  startingTrust: number;
}

export interface EnemyDef {
  id: string;
  name: string;
  family: "ruin-stalker" | "anomaly-beast" | "mayonin-sentinel" | "aberrant" | "named";
  classification: string;
  lore: string;
  color: string;
  mark: string;
  maxHp: number;
  speed: number;
  defense: number;
  clashBonus: number;
  breakMax: number;
  abilities: AbilityDef[];
  behavior: string;
  weakness: string;
  resistance: string;
  firstEpisode: number;
}

export interface VariantDef {
  id: VariantKind;
  label: string;
  hp: number;
  dmg: number;
  def: number;
  clash: number;
  break: number;
  speed: number;
  extraAbility?: AbilityDef;
  passive?: string;
  lore: string;
}

export interface DialogueLine {
  speaker: string;
  emotion: Emotion;
  text: string;
  flag?: string;
  minTrust?: { id: string; value: number };
}

export interface ExploreNode {
  id: string;
  label: string;
  hint: string;
  result: "dialogue" | "item" | "discovery" | "battle" | "lore" | "nothing";
  payload?: string;
  text: string;
}

export interface BattleSpec {
  enemies: { base: string; variant: VariantKind; elite?: boolean }[];
  objects?: { id: string; name: string; desc: string; effect: string }[];
  weather?: AnomalyWeather;
  anomalyStart?: number;
  deploy?: string[];
  ardenFights?: boolean;
  bossPhases?: number;
  title: string;
}

export interface RewardSpec {
  xp: number;
  currency: number;
  managerXp: number;
  items?: { id: string; name: string; qty: number }[];
  discovery?: string;
  ally?: string;
  special?: string;
}

export interface CinematicSpec {
  sceneId: "father-finale";
  title: string;
  background: "vault" | "hall" | "outpost";
}

export type Stage =
  | { type: "dialogue"; lines: DialogueLine[] }
  | { type: "cinematic"; cinematic: CinematicSpec }
  | { type: "choice"; prompt: string; options: { id: string; label: string; text: string; flag?: string; trust?: { id: string; delta: number } }[] }
  | { type: "explore"; location: string; intro: string; nodes: ExploreNode[] }
  | { type: "battle"; battle: BattleSpec }
  | { type: "discovery"; discoveryId: string; text: string }
  | { type: "recruit"; characterId: string; text: string }
  | { type: "reward"; reward: RewardSpec };

export interface EpisodeDef {
  id: number;
  title: string;
  kind: EpisodeKind;
  summary: string;
  location: string;
  bg: "hall" | "outpost" | "vault";
  stages: Stage[];
}

export interface DiscoveryDef {
  id: string;
  name: string;
  category:
    | "characters"
    | "allies"
    | "enemies"
    | "weapons"
    | "abilities"
    | "powers"
    | "supernatural"
    | "artifacts"
    | "locations"
    | "events"
    | "mayonin";
  lore: string;
  effects: string;
  episode: number;
  hidden: boolean;
}

export interface ItemDef {
  id: string;
  name: string;
  slot: "weapon" | "artifact" | "utility" | "defensive" | "material";
  desc: string;
  effect: string;
  stat?: Partial<{ hp: number; damage: number; clash: number; defense: number }>;
}

export interface FighterSave {
  id: string;
  level: number;
  xp: number;
  hp: number;
  trust: number;
  fatigue: boolean;
  equipment: { weapon?: string; artifact?: string; utility?: string; defensive?: string };
  formation: Formation;
  unlockedAbilities: string[];
}

export interface StatusInst {
  id: StatusId;
  duration: number;
  stacks: number;
}

export interface Combatant {
  uid: string;
  defId: string;
  name: string;
  side: "ally" | "enemy";
  hp: number;
  maxHp: number;
  break: number;
  breakMax: number;
  powerMeter: number;
  formation: Formation;
  level: number;
  speed: number;
  defense: number;
  clashBonus: number;
  statuses: StatusInst[];
  variant?: VariantKind;
  elite?: boolean;
  hiddenClash?: boolean;
  acting?: PlannedAction | null;
  color: string;
  mark: string;
  role?: Role;
  temporary?: "red-demon" | "blood-slave";
}

export interface PlannedAction {
  actorUid: string;
  abilityId: string;
  targetUid: string;
  power: number;
  clash: number;
  damage: number;
  name: string;
  isPower?: boolean;
  isSpecial?: boolean;
}

export interface ClashRound {
  n: number;
  a: number;
  b: number;
  winner: "a" | "b" | "tie";
}

export interface ClashResult {
  aName: string;
  bName: string;
  rounds: ClashRound[];
  winner: "a" | "b" | "tie";
  aHidden?: boolean;
  bHidden?: boolean;
}

export interface DamagePop {
  id: string;
  uid: string;
  text: string;
  kind: "hit" | "crit" | "break" | "power" | "heal" | "miss" | "total";
}

export interface CombatLogLine {
  id: string;
  text: string;
  tone: "neutral" | "good" | "bad" | "clash" | "power";
}

export interface SettingsState {
  master: number;
  sfx: number;
  lowMemory: boolean;
  shake: boolean;
  reducedMotion: boolean;
}

export interface SaveData {
  version: number;
  createdAt: number;
  updatedAt: number;
  hasSave: boolean;
  currentEpisode: number;
  unlockedEpisode: number;
  completed: number[];
  fighters: Record<string, FighterSave>;
  recruited: string[];
  managerLevel: number;
  managerXp: number;
  currency: number;
  inventory: { id: string; qty: number }[];
  ardenSpecials: string[];
  archive: string[];
  discoveries: string[];
  enemyVariants: string[];
  flags: Record<string, boolean>;
  world: { anomaly: number; weather: AnomalyWeather };
  rngSeed: number;
  rngCount: number;
  settings: SettingsState;
  redBloodDemonCooldown: number;
}

export type CombatPhase =
  | "brief"
  | "plan"
  | "guard"
  | "clash"
  | "resolve"
  | "power"
  | "special"
  | "victory"
  | "defeat";
