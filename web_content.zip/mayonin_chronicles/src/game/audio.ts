let ctx: AudioContext | null = null;
let master = 0.8;
let sfx = 0.8;

export function unlockAudio() {
  try {
    if (!ctx) ctx = new AudioContext();
    if (ctx.state === "suspended") void ctx.resume();
  } catch {
    /* ignore */
  }
}

export function setAudioLevels(m: number, s: number) {
  master = m;
  sfx = s;
}

function beep(freq: number, dur = 0.08, type: OscillatorType = "square", gain = 0.05) {
  if (!ctx || master <= 0 || sfx <= 0) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.value = gain * master * sfx;
  o.connect(g);
  g.connect(ctx.destination);
  const t = ctx.currentTime;
  g.gain.setValueAtTime(g.gain.value, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export const sfxLib = {
  tap: () => beep(420, 0.05, "square", 0.03),
  confirm: () => beep(620, 0.07, "triangle", 0.04),
  dialogue: () => beep(330, 0.055, "sine", 0.025),
  step: () => beep(105, 0.055, "square", 0.018),
  discovery: () => { beep(760, 0.09, "triangle", 0.03); setTimeout(() => beep(1040, 0.14, "sine", 0.025), 70); },
  danger: () => { beep(95, 0.16, "sawtooth", 0.035); setTimeout(() => beep(70, 0.18, "sine", 0.025), 100); },
  recruit: () => { beep(440, 0.08, "triangle", 0.03); setTimeout(() => beep(660, 0.16, "triangle", 0.03), 90); },
  clash: () => {
    beep(180, 0.12, "sawtooth", 0.05);
    setTimeout(() => beep(240, 0.1, "square", 0.04), 80);
  },
  hit: () => beep(140, 0.08, "sawtooth", 0.05),
  heal: () => beep(520, 0.1, "sine", 0.04),
  power: () => {
    beep(90, 0.2, "sawtooth", 0.06);
    setTimeout(() => beep(300, 0.16, "triangle", 0.05), 120);
  },
  win: () => {
    beep(440, 0.1, "triangle", 0.04);
    setTimeout(() => beep(660, 0.14, "triangle", 0.04), 100);
  },
  lose: () => beep(90, 0.28, "sine", 0.05),
  discover: () => beep(880, 0.12, "triangle", 0.035),
  spark: () => {
    beep(980, 0.045, "square", 0.045);
    setTimeout(() => beep(1320, 0.035, "triangle", 0.03), 35);
  },
  slash: () => {
    beep(1200, 0.08, "sawtooth", 0.055);
    setTimeout(() => beep(520, 0.16, "sine", 0.04), 55);
  },
  chain: () => {
    beep(170, 0.11, "square", 0.05);
    setTimeout(() => beep(260, 0.08, "square", 0.04), 70);
    setTimeout(() => beep(110, 0.16, "sawtooth", 0.035), 130);
  },
  blackout: () => beep(55, 0.32, "sine", 0.045),
  resolve: () => {
    beep(220, 0.22, "sine", 0.03);
    setTimeout(() => beep(440, 0.28, "triangle", 0.035), 170);
    setTimeout(() => beep(660, 0.34, "sine", 0.025), 360);
  },
};

/** Voice packs (CC0 samples from OpenGameArt – no Web Speech) */
const VOICE_MAP: Record<string, string[]> = {
  arden: ["male_deep_1.ogg", "male_deep_2.ogg", "male_deep_3.ogg", "male_deep_4.ogg"],
  seraphine: ["female_standard_1.ogg", "female_standard_2.ogg", "female_standard_3.ogg", "female_standard_4.ogg"],
  rook: ["male_standard_1.ogg", "male_standard_2.ogg", "male_standard_3.ogg", "male_standard_4.ogg"],
  mira: ["female_light_1.ogg", "female_light_2.ogg", "female_light_3.ogg", "female_light_4.ogg"],
  vale: ["male_deep_1.ogg", "male_deep_3.ogg", "male_standard_2.ogg"],
  nyx: ["whisper_1.ogg", "whisper_2.ogg", "whisper_3.ogg", "whisper_4.ogg"],
  sera: ["female_standard_2.ogg", "female_light_1.ogg", "female_standard_4.ogg"],
  kade: ["male_standard_3.ogg", "quick_1.ogg", "male_standard_1.ogg"],
  astra: ["female_light_3.ogg", "female_standard_1.ogg", "female_light_4.ogg"],
  orin: ["male_standard_2.ogg", "robot_1.ogg", "male_standard_4.ogg"],
  lena: ["female_standard_3.ogg", "female_light_2.ogg", "female_standard_1.ogg"],
  cael: ["quick_2.ogg", "quick_3.ogg", "male_standard_4.ogg"],
  demon: ["demon_1.ogg", "demon_2.ogg", "demon_3.ogg", "demon_4.ogg", "demon_howl.mp3"],
  father: ["male_deep_2.ogg", "male_deep_4.ogg", "demon_3.ogg"],
  default: ["male_standard_1.ogg", "male_standard_2.ogg"],
};

let lastVoice: HTMLAudioElement | null = null;

/** Play a short character voice clip (real audio files, no Web Speech) */
export function playVoice(characterId: string) {
  if (master <= 0 || sfx <= 0) return;
  const list = VOICE_MAP[characterId] || VOICE_MAP.default;
  const file = list[Math.floor(Math.random() * list.length)];
  try {
    if (lastVoice) {
      lastVoice.pause();
      lastVoice = null;
    }
    const a = new Audio(`/game/voice/${file}`);
    a.volume = Math.min(1, 0.7 * master * sfx);
    lastVoice = a;
    void a.play().catch(() => {});
  } catch {
    /* ignore missing files */
  }
}

export function stopSpeak() {
  try {
    if (lastVoice) {
      lastVoice.pause();
      lastVoice = null;
    }
  } catch {
    /* ignore */
  }
}

/** Keep speak() as alias so existing calls still work (now uses real audio) */
export function speak(_text: string, _opts?: { rate?: number; pitch?: number; volume?: number }) {
  // No Web Speech – intentionally empty. Use playVoice(characterId) instead.
}
