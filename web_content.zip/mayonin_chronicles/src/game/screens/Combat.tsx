import { CHAR_BY_ID } from "../data/characters";
import { Portrait } from "../components/Portrait";
import { BoneBtn, GhostBtn, Label, Shell } from "../components/Shell";
import { useGame } from "../store";
import { cn } from "@/lib/utils";
import { useEffect, useRef, useState, type ReactNode, type PointerEvent as ReactPointerEvent } from "react";
import { ARDEN_SPECIALS } from "../data/specials";
import type { Combatant, PlannedAction } from "../types";

export function Combat() {
  const combat = useGame((s) => s.combat);
  const save = useGame((s) => s.save);
  const selectAbility = useGame((s) => s.selectAbility);
  const assignTarget = useGame((s) => s.assignTarget);
  const commit = useGame((s) => s.commit);
  const dismissClash = useGame((s) => s.dismissClash);
  const firePower = useGame((s) => s.firePower);
  const dismissPower = useGame((s) => s.dismissPower);
  const toggleSpecial = useGame((s) => s.toggleSpecial);
  const fireSpecial = useGame((s) => s.fireSpecial);
  const go = useGame((s) => s.go);
  const [line, setLine] = useState<{ x1: number; y1: number; x2: number; y2: number } | null>(null);
  const drag = useRef<{ uid: string; abilityId: string } | null>(null);
  const shake = save.settings.shake && !save.settings.lowMemory && combat && (combat.phase === "clash" || combat.phase === "power");

  useEffect(() => {
    if (combat?.phase === "victory" && combat.enemies.some((e) => e.defId === "father")) {
      const t = window.setTimeout(() => dismissClash(), 900);
      return () => window.clearTimeout(t);
    }
    if (combat?.phase === "clash") {
      const t = window.setTimeout(() => dismissClash(), 1600);
      return () => window.clearTimeout(t);
    }
    if (combat?.phase === "power" && combat.powerCinematic) {
      const t = window.setTimeout(() => dismissPower(), 2200);
      return () => window.clearTimeout(t);
    }
  }, [combat?.phase, combat?.powerCinematic, dismissClash, dismissPower]);

  if (!combat) return null;
  const rt = combat;

  function onAbilityDown(e: ReactPointerEvent, uid: string, abilityId: string) {
    if (rt.phase !== "plan") return;
    drag.current = { uid, abilityId };
    selectAbility(uid, abilityId);
    setLine({ x1: e.clientX, y1: e.clientY, x2: e.clientX, y2: e.clientY });
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }

  function onMove(e: ReactPointerEvent) {
    if (!drag.current || !line) return;
    setLine({ ...line, x2: e.clientX, y2: e.clientY });
  }

  function onUp(e: ReactPointerEvent) {
    if (!drag.current) return;
    const el = document.elementFromPoint(e.clientX, e.clientY) as HTMLElement | null;
    const target = el?.closest("[data-uid]") as HTMLElement | null;
    if (target?.dataset.uid) assignTarget(target.dataset.uid);
    drag.current = null;
    setLine(null);
  }

  const overlay = combat.phase === "clash" || combat.phase === "power" || combat.phase === "victory" || combat.phase === "defeat" || combat.specialMenu;

  return (
    <Shell bg={combat.enemies.some((e) => e.defId === "father") ? "vault" : "outpost"}>
      <div
        className={cn("flex min-h-0 flex-1 flex-col", shake && "animate-pulse")}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        style={{ touchAction: "none" }}
      >
        <header className="flex items-center justify-between gap-2 border-b border-line px-3 py-2">
          <div className="min-w-0">
            <Label>
              Round {combat.round} · {combat.weather === "none" ? "Clear" : combat.weather.replace("-", " ")}
            </Label>
            <h1 className="truncate font-display text-xl font-semibold">{combat.title}</h1>
          </div>
          <div className="flex items-center gap-2">
            <GhostBtn onClick={toggleSpecial} className="min-w-28 border-bone/70 text-bone">SPECIAL</GhostBtn>
            <GhostBtn onClick={() => go("menu")}>Menu</GhostBtn>
          </div>
        </header>

        <div className="flex items-center justify-between gap-3 px-3 py-2 text-[11px] uppercase tracking-[0.14em] text-muted">
          <span className="tabular">
            Anomaly {combat.anomaly}%
          </span>
          <span className="tabular">Momentum {combat.momentum}</span>
          {combat.bossPhases > 1 && <span>Phase {combat.bossPhase}/{combat.bossPhases}</span>}
        </div>

        <section className="flex gap-2 overflow-x-auto px-3 pb-2">
          {combat.enemies.map((u) => (
            <UnitCard
              key={u.uid}
              u={u}
              plan={combat.enemyPlans[u.uid]}
              selectable
              onPick={assignTarget}
            />
          ))}
        </section>

        <div className="relative min-h-16 flex-1 px-3">
          {combat.pops.length > 0 && (
            <div className="pointer-events-none absolute inset-x-0 top-1 z-20 flex flex-wrap justify-center gap-2">
              {combat.pops.slice(-6).map((pop) => (
                <span key={pop.id} className={cn(
                  "animate-pulse border px-2 py-1 font-display text-xl tabular",
                  pop.kind === "power" ? "border-bone text-bone" : pop.kind === "heal" ? "border-line text-fg" : "border-line text-iron",
                )}>
                  {pop.text}
                </span>
              ))}
            </div>
          )}
          {combat.banner && (
            <p className="text-center font-display text-2xl text-bone">{combat.banner}</p>
          )}
          {combat.voice && <p className="mt-1 text-center text-sm italic text-muted">“{combat.voice}”</p>}
          <div className="mt-2 max-h-20 overflow-hidden text-center text-xs text-subtle">
            {combat.log.slice(-3).map((l) => (
              <p key={l.id}>{l.text}</p>
            ))}
          </div>
          {combat.objects?.length ? (
            <p className="mt-2 text-center text-[11px] text-muted">
              Field: {combat.objects.map((o) => o.name).join(" · ")}
            </p>
          ) : null}
        </div>

        <section className="border-t border-line bg-surface/80 px-2 py-2">
          <div className="flex gap-2 overflow-x-auto">
            {combat.allies.map((u) => {
              const def = CHAR_BY_ID[u.defId];
              return (
                <div
                  key={u.uid}
                  className="min-w-[220px] flex-1 border border-line bg-elevated/80 p-2"
                  style={{ borderRadius: 8 }}
                  data-uid={u.uid}
                  onClick={() => assignTarget(u.uid)}
                >
                  <div className="flex items-center gap-2">
                    <Portrait name={u.name} mark={u.mark} color={u.color} size="sm" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{u.name}</p>
                      <div className="hp-bar mt-1"><span style={{ width: `${(u.hp / u.maxHp) * 100}%` }} /></div>
                      <p className="tabular text-[10px] text-muted">
                        HP {u.hp}/{u.maxHp} · {u.formation} · Pwr {u.powerMeter}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={u.powerMeter < 100 || combat.usedPower[u.uid]}
                      onClick={(ev) => {
                        ev.stopPropagation();
                        firePower(u.uid);
                      }}
                      className="h-10 border border-line px-2 text-[10px] uppercase tracking-wider disabled:opacity-30"
                    >
                      Power
                    </button>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-1">
                    {(def?.abilities ?? []).map((ab) => (
                      <button
                        key={ab.id}
                        type="button"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          onAbilityDown(e, u.uid, ab.id);
                        }}
                        onClick={(e) => e.stopPropagation()}
                        className={cn(
                          "min-h-11 border border-line px-2 py-1 text-left text-[11px] leading-tight",
                          combat.plans[u.uid]?.abilityId === ab.id && "border-bone bg-bone/10",
                          combat.selected?.uid === u.uid && combat.selected.abilityId === ab.id && "border-bone",
                        )}
                      >
                        <span className="block font-medium">{ab.name}</span>
                        <span className="text-subtle">C{ab.clash} D{ab.damage}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-2 flex justify-end px-1">
            <BoneBtn onClick={commit} disabled={combat.phase !== "plan" || Object.keys(combat.plans).length === 0}>
              Commit
            </BoneBtn>
          </div>
        </section>
      </div>

      {line && (
        <svg className="drag-line">
          <line x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2} stroke="#d8d3c8" strokeWidth="2" />
        </svg>
      )}

      {overlay && combat.specialMenu && (
        <Modal onClose={toggleSpecial} title="ARDEN / SPECIAL">
          <div className="grid gap-2">
            {ARDEN_SPECIALS.map((s) => {
              const unlocked = save.ardenSpecials.includes(s.id);
              return (
                <button
                  key={s.id}
                  type="button"
                  disabled={!unlocked}
                  onClick={() => fireSpecial(s.id)}
                  className="border border-line bg-elevated/80 p-3 text-left transition-colors hover:border-line-strong disabled:opacity-35"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-display text-lg text-fg">{unlocked ? s.name : "[ UNKNOWN ]"}</span>
                    <span className="text-[9px] uppercase tracking-[0.16em] text-muted">{unlocked ? (s.id === "red-blood-demon" && save.redBloodDemonCooldown > 0 ? `COOLDOWN ${save.redBloodDemonCooldown}` : "READY") : "LOCKED"}</span>
                  </div>
                  {unlocked && (
                    <>
                      <p className="mt-1 text-[10px] uppercase tracking-[0.16em] text-iron">{s.subtitle}</p>
                      <p className="mt-2 text-xs leading-relaxed text-muted">{s.description}</p>
                      <p className="mt-2 text-[10px] text-subtle">{s.requirement}</p>
                    </>
                  )}
                </button>
              );
            })}
          </div>
        </Modal>
      )}

      {combat.phase === "clash" && combat.clash && (
        <Modal title="Clash" onClose={dismissClash}>
          <p className="font-display text-3xl">
            {combat.clash.aName} vs {combat.clash.bName}
          </p>
          <ul className="mt-3 space-y-1 text-sm tabular">
            {combat.clash.rounds.map((r) => (
              <li key={r.n}>
                Round {r.n}: {combat.clash?.aHidden ? "???" : r.a} vs {combat.clash?.bHidden ? "???" : r.b} — {r.winner === "tie" ? "tie" : r.winner === "a" ? "win" : "loss"}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-sm uppercase tracking-[0.16em] text-bone">
            {combat.clash.winner === "a" ? "Clash won" : combat.clash.winner === "b" ? "Clash lost" : "Tied"}
          </p>
        </Modal>
      )}

      {combat.phase === "power" && combat.powerCinematic && (
        <Modal title={combat.powerCinematic.name} onClose={dismissPower}>
          <p className="text-sm italic text-bone">“{combat.powerCinematic.voice}”</p>
          <ul className="mt-4 space-y-2 font-display text-xl tabular">
            {combat.powerCinematic.steps.map((s, i) => (
              <li key={`${s}-${i}`} className="border-l border-line pl-3">{s}</li>
            ))}
          </ul>
          <p className="mt-4 text-[10px] uppercase tracking-[0.18em] text-subtle">Tap outside or wait for the sequence to resolve</p>
        </Modal>
      )}

      {(combat.phase === "victory" || combat.phase === "defeat") && (
        <Modal title={combat.phase === "victory" ? "Field held" : "Line broken"} onClose={dismissClash}>
          <p className="text-sm text-muted">
            {combat.phase === "victory" ? "The engagement is over. Record the after-action." : "Retry from the briefing. Progress is saved."}
          </p>
          <BoneBtn className="mt-4" onClick={dismissClash}>
            {combat.phase === "victory" ? "Continue" : "Fall back"}
          </BoneBtn>
        </Modal>
      )}
    </Shell>
  );
}

function UnitCard({
  u,
  plan,
  selectable,
  onPick,
}: {
  u: Combatant;
  plan?: PlannedAction;
  selectable?: boolean;
  onPick?: (uid: string) => void;
}) {
  return (
    <div
      data-uid={u.uid}
      onClick={() => onPick?.(u.uid)}
      className={cn(
        "min-w-[160px] flex-1 border border-line bg-surface/85 p-2",
        u.defId === "father" && "border-red-900/80 bg-red-950/20",
        u.hp <= 0 && "opacity-40",
        selectable && "cursor-pointer",
      )}
      style={{ borderRadius: 8 }}
    >
      <div className="flex items-center gap-2">
        <Portrait name={u.name} mark={u.mark} color={u.color} size="sm" />
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{u.name}</p>
          {u.elite && <p className="text-[10px] uppercase tracking-wider text-iron">Elite</p>}
          {u.defId === "father" && <p className="text-[10px] uppercase tracking-wider text-red-300/80">Mayonin Sword · Red Horizon</p>}
          {u.hiddenClash && <p className="text-[10px] uppercase tracking-wider text-iron">Clash ???</p>}
        </div>
      </div>
      <div className="hp-bar mt-2"><span style={{ width: `${Math.max(0, (u.hp / u.maxHp) * 100)}%` }} /></div>
      {u.breakMax > 0 && (
        <div className="hp-bar break-bar mt-1 h-1"><span style={{ width: `${(u.break / u.breakMax) * 100}%` }} /></div>
      )}
      <p className="mt-1 tabular text-[10px] text-muted">
        HP {u.hp}/{u.maxHp}
        {u.breakMax > 0 ? ` · BR ${u.break}` : ""}
      </p>
      {plan && selectable && (
        <p className="mt-1 text-[11px] text-bone">
          {plan.name} → {plan.targetUid.startsWith("a-") ? "squad" : "target"}
        </p>
      )}
      {u.statuses.length > 0 && (
        <p className="mt-1 text-[10px] uppercase tracking-wider text-subtle">
          {u.statuses.map((s) => s.id).join(" · ")}
        </p>
      )}
    </div>
  );
}

function Modal({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink/70 p-4" onClick={onClose} role="presentation">
      <div
        className="w-full max-w-md border border-line bg-surface p-5"
        style={{ borderRadius: 14 }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
      >
        <Label>{title}</Label>
        <div className="mt-2">{children}</div>
      </div>
    </div>
  );
}
