//+------------------------------------------------------------------+
//| RSI Scalper Risk-Controlled EA - MT4                             |
//| Based on the supplied RSI scalping template                      |
//| Educational/testing software. No profit guarantee.               |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"

input double LotSize              = 0.01;
input double LotIncrement         = 0.01;   // added after each profitable trade
input double MaxLotSize           = 0.50;   // hard ceiling
input int    RSIPeriod            = 14;
input double BuyLevel             = 30.0;
input double SellLevel            = 70.0;
input int    StopLossPoints       = 100;
input int    TakeProfitPoints     = 150;
input int    MaxOpenTrades        = 1;
input int    MaxTradesPerMinute   = 30;
input int    CooldownSeconds      = 1;
input int    MaxSpreadPoints      = 30;
input double MaxRiskPerTradePct   = 1.0;
input double MaxDailyLossPct      = 3.0;
input double MaxDrawdownPct       = 10.0;
input int    MaxConsecutiveLosses = 3;
input bool   ResetLotAfterLoss    = true;
input bool   StopOnRiskLimit      = true;
input int    SlippagePoints       = 10;
input int    MagicNumber          = 26091701;

datetime lastTradeTime = 0;
datetime lastProcessedClose = 0;
double   nextLot = 0.01;
double   dayStartBalance = 0.0;
bool     tradingEnabled = true;
int      consecutiveLosses = 0;
datetime minuteBucket = 0;
int      tradesThisMinute = 0;

//--- normalize a lot to broker constraints
double NormalizeLot(double lots)
{
   double minLot = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   double step   = MarketInfo(Symbol(), MODE_LOTSTEP);
   double cap    = MathMin(maxLot, MaxLotSize);

   lots = MathMax(minLot, MathMin(lots, cap));
   if(step > 0)
      lots = MathFloor(lots / step + 1e-9) * step;

   return NormalizeDouble(lots, 2);
}

//--- count this EA's open trades on this symbol
int CountOpenTrades()
{
   int count = 0;
   for(int i=OrdersTotal()-1; i>=0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != MagicNumber) continue;
      if(OrderSymbol() != Symbol()) continue;
      if(OrderType()==OP_BUY || OrderType()==OP_SELL) count++;
   }
   return count;
}

//--- today's closed P/L for this EA/symbol
double TodayClosedProfit()
{
   double p = 0.0;
   datetime start = StrToTime(TimeToString(TimeCurrent(), TIME_DATE));
   for(int i=OrdersHistoryTotal()-1; i>=0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      if(OrderMagicNumber()!=MagicNumber || OrderSymbol()!=Symbol()) continue;
      if(OrderCloseTime() < start) continue;
      p += OrderProfit() + OrderSwap() + OrderCommission();
   }
   return p;
}

//--- peak-to-current drawdown based on current balance/equity snapshot
double CurrentDrawdownPct()
{
   double bal = AccountBalance();
   if(bal <= 0) return 0;
   double eq = AccountEquity();
   return MathMax(0.0, (bal-eq)/bal*100.0);
}

//--- update nextLot from the most recently closed trade
void UpdateLotFromHistory()
{
   datetime newest = lastProcessedClose;
   int newestTicket = -1;
   double newestNet = 0.0;

   for(int i=OrdersHistoryTotal()-1; i>=0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      if(OrderMagicNumber()!=MagicNumber || OrderSymbol()!=Symbol()) continue;
      if(OrderType()!=OP_BUY && OrderType()!=OP_SELL) continue;
      if(OrderCloseTime() <= newest) continue;

      newest = OrderCloseTime();
      newestTicket = OrderTicket();
      newestNet = OrderProfit()+OrderSwap()+OrderCommission();
   }

   if(newestTicket < 0) return;

   lastProcessedClose = newest;

   if(newestNet > 0.0)
      nextLot = NormalizeLot(nextLot + LotIncrement);
   else if(newestNet < 0.0)
   {
      consecutiveLosses++;
      if(ResetLotAfterLoss) nextLot = NormalizeLot(LotSize);
   }
   else
      consecutiveLosses = 0;

   if(newestNet > 0.0)
      consecutiveLosses = 0;

   if(consecutiveLosses >= MaxConsecutiveLosses && StopOnRiskLimit)
      tradingEnabled = false;
}

//--- hard risk checks
bool RiskOK()
{
   if(!tradingEnabled) return false;

   double spread = (Ask-Bid)/Point;
   if(spread > MaxSpreadPoints) return false;

   double daily = TodayClosedProfit();
   if(dayStartBalance > 0 && daily < 0)
   {
      double lossPct = (-daily/dayStartBalance)*100.0;
      if(lossPct >= MaxDailyLossPct)
      {
         tradingEnabled = false;
         return false;
      }
   }

   if(CurrentDrawdownPct() >= MaxDrawdownPct)
   {
      tradingEnabled = false;
      return false;
   }

   if(MaxOpenTrades > 0 && CountOpenTrades() >= MaxOpenTrades) return false;

   datetime now = TimeCurrent();
   if(now - minuteBucket >= 60)
   {
      minuteBucket = now;
      tradesThisMinute = 0;
   }
   if(tradesThisMinute >= MaxTradesPerMinute) return false;

   if(now - lastTradeTime < CooldownSeconds) return false;

   // Basic margin/risk estimate: never allow a lot above broker maximum.
   nextLot = NormalizeLot(nextLot);
   if(AccountFreeMarginCheck(Symbol(), OP_BUY, nextLot) <= 0) return false;

   return true;
}

//--- open a market trade
bool OpenTrade(int type)
{
   if(!RiskOK()) return false;

   double lots = NormalizeLot(nextLot);
   RefreshRates();

   double price = (type==OP_BUY ? Ask : Bid);
   double sl = 0, tp = 0;

   if(StopLossPoints > 0)
      sl = (type==OP_BUY ? price-StopLossPoints*Point : price+StopLossPoints*Point);
   if(TakeProfitPoints > 0)
      tp = (type==OP_BUY ? price+TakeProfitPoints*Point : price-TakeProfitPoints*Point);

   sl = NormalizeDouble(sl, Digits);
   tp = NormalizeDouble(tp, Digits);

   string comment = "RSI-RISK";
   int ticket = OrderSend(Symbol(), type, lots, price, SlippagePoints, sl, tp,
                          comment, MagicNumber, 0, clrNONE);

   if(ticket < 0)
   {
      Print("OrderSend failed. Error=", GetLastError());
      return false;
   }

   lastTradeTime = TimeCurrent();
   tradesThisMinute++;
   return true;
}

int OnInit()
{
   dayStartBalance = AccountBalance();
   nextLot = NormalizeLot(LotSize);
   minuteBucket = TimeCurrent();
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   UpdateLotFromHistory();

   if(!tradingEnabled) return;
   if(CountOpenTrades() >= MaxOpenTrades) return;
   if(!RiskOK()) return;

   double rsi = iRSI(Symbol(), PERIOD_CURRENT, RSIPeriod, PRICE_CLOSE, 0);

   // Buy when RSI is at/below BuyLevel.
   if(rsi <= BuyLevel)
   {
      OpenTrade(OP_BUY);
      return;
   }

   // Sell when RSI is at/above SellLevel.
   if(rsi >= SellLevel)
   {
      OpenTrade(OP_SELL);
      return;
   }
}
