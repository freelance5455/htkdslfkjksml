blure PHP Playground v0.6.9

Upload all files from this ZIP into InfinityFree htdocs, replacing existing files.
Open https://blure.rf.gd/php-playground.php and choose Interactive input from the examples.

PHP supports input.var, input.num, input.yesno and input.password.
Multiple prompts separated by > are processed left-to-right.
The browser displays each prompt and submits answers to PHP.
Each submission replays the source with previous answers, using the PHP session virtual filesystem as its starting state. Virtual filesystem changes are committed only after successful completion. Avoid relying on external side effects in code while inputs are pending.
Maximum 100 input answers per run, 10,000 characters each.

The previous InfinityFree service-worker MIME issue is not addressed by this PHP feature update.
