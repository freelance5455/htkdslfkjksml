/* Shadow Strike Voxel — offline cache. Game files: network first (so updates arrive), cache fallback (so it works offline). */
const CACHE = 'ssvoxel-v3e';
const FILES = ['./', './index.html', './manifest.json', './js/world.js', './js/room.js', './js/atlas.js', './js/mesher.js', './js/renderer.js', './js/net.js', './js/audio.js', './js/fx.js', './js/weapon-model.js', './js/game.js', './js/hud.js', './js/mesh-worker.js', './icons/icon-192.png', './icons/icon-512.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/ws') || url.pathname.startsWith('/api/')) return;
  e.respondWith(fetch(req).then((res) => { if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); } return res; }).catch(() => caches.match(req).then((hit) => hit || caches.match('./index.html'))));
});
