#!/bin/sh
# Shadow Strike Voxel — start the multiplayer server (needs Node.js 18 or newer, nothing else).
cd "$(dirname "$0")"
exec node server/server.js
