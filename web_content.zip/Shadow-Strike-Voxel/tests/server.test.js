// Integration tests: real HTTP + WebSocket server on a random port, real clients (Node's WebSocket).
const assert = require('node:assert');
const test = require('node:test');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ssv-'));
process.env.DATA_DIR = tmp; process.env.MODE = 'creative'; process.env.SEED = '4242'; process.env.PORT = '0';
const srv = require('../server/server.js');
let port;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const allSockets = [];
test.after(() => { allSockets.forEach((w) => { try { w.close(); } catch (e) { /* */ } }); try { srv.shutdown(); } catch (e) { /* */ } });
/** A free air cell within reach of the player, so the test does not depend on the terrain. */
function airCell(roomName, w) {
  const world = srv.rooms.get(roomName).world;
  for (let dy = 3; dy >= 0; dy--) for (let dx = -3; dx <= 3; dx++) {
    const x = Math.floor(w.x) + dx, y = Math.floor(w.y) + dy, z = Math.floor(w.z) + 2;
    if (world.get(x, y, z) === 0) return { x, y, z };
  }
  throw new Error('no air cell');
}
const get = (p) => new Promise((res, rej) => http.get({ port, path: p, host: '127.0.0.1' }, (r) => { let b = ''; r.on('data', (d) => (b += d)); r.on('end', () => res({ status: r.statusCode, body: b, headers: r.headers })); }).on('error', rej));
function open(room, name) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws?room=${room}`), msgs = [];
    ws.onmessage = (e) => msgs.push(JSON.parse(e.data));
    ws.onerror = reject; allSockets.push(ws);
    ws.onopen = () => { ws.send(JSON.stringify({ t: 'join', name })); resolve({ ws, msgs, last: (t) => [...msgs].reverse().find((m) => m.t === t), all: (t) => msgs.filter((m) => m.t === t), send: (o) => ws.send(JSON.stringify(o)) }); };
  });
}
test('server starts', async () => { await new Promise((r) => srv.server.listen(0, '127.0.0.1', r)); port = srv.server.address().port; assert.ok(port > 0); });
test('serves the game page but never server code, tests or world saves', async () => {
  assert.strictEqual((await get('/')).status, 200);
  assert.ok((await get('/index.html')).headers['content-type'].startsWith('text/html'));
  for (const p of ['/server/server.js', '/tests/room.test.js', '/worlds/x.json', '/..%2fserver%2fserver.js', '/js/../server/server.js', '/%2e%2e/etc/passwd', '/package.json']) assert.strictEqual((await get(p)).status, 404, p);
});
test('/api/info lists rooms', async () => { const r = await get('/api/info'); assert.strictEqual(r.status, 200); assert.ok(Array.isArray(JSON.parse(r.body).rooms)); });
test('websocket: welcome uses the server seed and mode', async () => {
  const a = await open('t1', 'Ali'); await sleep(200);
  const w = a.last('welcome'); assert.ok(w && w.seed === 4242 && w.mode === 'creative' && w.id === 1 && w.room === 't1');
  a.ws.close();
});
test('two players see each other, edits, chat and snapshots', async () => {
  const a = await open('t2', 'Ali'), b = await open('t2', 'Sara'); await sleep(250);
  const wa = a.last('welcome');
  assert.ok(a.last('join') && a.last('join').name === 'Sara');
  a.send({ t: 's', x: wa.x, y: wa.y, z: wa.z, yaw: 1, pitch: 0, f: 0 });
  const c = airCell('t2', wa);
  a.send({ t: 'block', x: c.x, y: c.y, z: c.z, id: 9 });
  a.send({ t: 'chat', text: 'سلام سارا' });
  await sleep(300);
  assert.ok(b.last('block') && b.last('block').id === 9, 'block reached the other player');
  assert.strictEqual(b.last('chat').text, 'سلام سارا');
  const snap = b.last('snap'); assert.ok(snap && snap.p.length === 2, 'snapshot lists both players');
  assert.ok(snap.p.some((p) => p[0] === 1 && Math.abs(p[1] - wa.x) < 0.02), 'positions are relayed');
  a.ws.close(); b.ws.close(); await sleep(100);
});
test('the world is saved to disk and restored after a restart', async () => {
  const a = await open('t3', 'Ali'); await sleep(200);
  const w = a.last('welcome'); a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 });
  const c3 = airCell('t3', w);
  a.send({ t: 'block', x: c3.x, y: c3.y, z: c3.z, id: 15 });
  await sleep(150); a.ws.close(); await sleep(300);
  const f = path.join(tmp, 't3.json'); assert.ok(fs.existsSync(f), 'save file written when the last player left');
  const save = JSON.parse(fs.readFileSync(f, 'utf8')); assert.deepStrictEqual(save.edits.slice(0, 4), [c3.x, c3.y, c3.z, 15]);
  srv.rooms.delete('t3');
  const b = await open('t3', 'Ali'); await sleep(250);
  assert.deepStrictEqual(b.last('edits').a.slice(0, 4), save.edits.slice(0, 4), 'restored edit sent to a fresh join');
  b.ws.close();
});
test('large and hostile messages: 100KB chat is ignored, binary/garbage does not kill the server, oversize closes', async () => {
  const a = await open('t4', 'Ali'); await sleep(150);
  a.ws.send('x'.repeat(100000)); a.ws.send('not json'); a.ws.send(new Uint8Array([1, 2, 3]));
  a.send({ t: 'ping', c: 5 }); await sleep(250);
  assert.ok(a.last('pong') && a.last('pong').c === 5, 'still alive after garbage');
  const closed = new Promise((r) => { a.ws.onclose = () => r(true); });
  a.ws.send('y'.repeat(400000));
  assert.ok(await Promise.race([closed, sleep(1500).then(() => false)]), 'connection with an oversized frame is dropped');
});
test('connections per IP are limited and non-/ws upgrade is refused', async () => {
  allSockets.forEach((w) => { try { w.close(); } catch (e) { /* */ } }); await sleep(400);
  const socks = [];
  for (let i = 0; i < 8; i++) socks.push(await open('t5', 'P' + i));
  const extra = await new Promise((r) => { const w = new WebSocket(`ws://127.0.0.1:${port}/ws?room=t5`); allSockets.push(w); w.onopen = () => r('open'); w.onerror = () => r('refused'); w.onclose = () => r('refused'); });
  assert.strictEqual(extra, 'refused');
  const bad = await new Promise((r) => { const w = new WebSocket(`ws://127.0.0.1:${port}/nope`); w.onopen = () => r('open'); w.onerror = () => r('refused'); });
  assert.strictEqual(bad, 'refused');
  socks.forEach((s) => s.ws.close()); await sleep(200);
});
test('room names are sanitised', async () => {
  const a = await open('../../evil name!', 'A'); await sleep(150);
  assert.ok(Array.from(srv.rooms.keys()).every((k) => /^[\w-]+$/.test(k)), Array.from(srv.rooms.keys()).join());
  a.ws.close();
});
test('shutdown saves and exits cleanly', async () => {
  const a = await open('t6', 'A'); await sleep(150);
  const w = a.last('welcome'); a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 });
  const c6 = airCell('t6', w);
  a.send({ t: 'block', x: c6.x, y: c6.y, z: c6.z, id: 3 });
  await sleep(150);
  srv.rooms.forEach((r) => { r.dirty = true; });
  const origExit = process.exit; let exited = false; process.exit = () => { exited = true; };
  srv.shutdown(); await sleep(400); process.exit = origExit;
  assert.ok(exited && fs.existsSync(path.join(tmp, 't6.json')));
  try { a.ws.close(); } catch (e) { /* */ }
});
