// Browser tests (Playwright + real Chromium, software WebGL). Drives the real UI and the real server.
// Usage: CHROMIUM_PATH=/path/to/chrome node tests/browser.test.mjs
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const PORT = 3900 + Math.floor(Math.random() * 90);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'ssv-b-'));
let fails = 0, passes = 0;
const ok = (n, c, extra = '') => { if (c) passes++; else fails++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + extra)); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const srv = spawn('node', ['server/server.js'], { env: { ...process.env, PORT: String(PORT), DATA_DIR: DATA, MODE: 'survival', SEED: 'testseed' }, cwd: ROOT });
await sleep(900);
const ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader', '--disable-features=WebRtcHideLocalIpsWithMdns', '--allow-loopback-in-peer-connection', '--autoplay-policy=no-user-gesture-required'];
const errs = [];
let b;
const newPage = async (ctx, name) => {
  const p = await ctx.newPage(); p._name = name;
  p.on('pageerror', (e) => errs.push(name + ' PAGE ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/ERR_UNSAFE_PORT|127\.0\.0\.1:1\//.test(m.text())) errs.push(name + ' CONSOLE ' + m.text()); if (m.type() === 'warning' && /GL_|WebGL/.test(m.text())) errs.push(name + ' GL ' + m.text()); });
  return p;
};
const LIGHT = () => { try { if (!localStorage.getItem('ssv_cfg')) localStorage.setItem('ssv_cfg', JSON.stringify({ fx: 0 })); } catch (e) {} };
const G = (p, fn, arg) => p.evaluate(fn, arg);
async function until(p, fn, ms, arg) { const t0 = Date.now(); while (Date.now() - t0 < (ms || 8000)) { if (await p.evaluate(fn, arg)) return true; await sleep(200); } return false; }
async function waitPlay(p, ms = 30000) { const t = Date.now(); while (Date.now() - t < ms) { if (await G(p, () => window.SSGame.G.screen) === 'play') return true; await sleep(250); } return false; }
async function startSingle(p, mode, seed) {
  await p.click('#b-single'); await p.click(`label:has(input[name=gm][value=${mode}])`); await p.fill('#in-seed', seed || 'hello'); await p.click('#b-new');
  return waitPlay(p);
}
async function stand(p) { await G(p, () => { const g = window.SSGame.G; g.me.vx = g.me.vz = 0; }); await sleep(300); }
const aimAt = (p, x, y, z) => G(p, ([x, y, z]) => { const g = window.SSGame.G, e = window.SSGame.eyePos(), dx = x - e.x, dy = y - e.y, dz = z - e.z; g.me.yaw = Math.atan2(-dx, -dz); g.me.pitch = Math.atan2(dy, Math.hypot(dx, dz)); }, [x, y, z]);

try {
  b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH, args: ARGS });
  const ctx = await b.newContext({ viewport: { width: 960, height: 540 }, permissions: ['clipboard-read', 'clipboard-write'] }); await ctx.addInitScript(LIGHT);
  let p = await newPage(ctx, 'A');
  await p.goto(`http://127.0.0.1:${PORT}/`, { timeout: 90000 }); await sleep(500);

  /* ===== menu + settings ===== */
  ok('menu is shown first with the title and 3 play modes', await p.isVisible('#scr-main') && await p.isVisible('#b-single') && await p.isVisible('#b-online') && await p.isVisible('#b-lan'));
  ok('game HUD is hidden in the menu', await G(p, () => document.getElementById('hud').classList.contains('hide')));
  await p.fill('#in-name', 'Yashar'); await p.click('#b-settings');
  await p.fill('#s-dist', '4'); await p.evaluate(() => document.getElementById('s-dist').dispatchEvent(new Event('input')));
  await p.click('#b-settings-ok');
  ok('settings are saved to storage', await G(p, () => JSON.parse(localStorage.getItem('ssv_cfg')).dist === 4));
  await p.reload(); await sleep(400);
  ok('name and settings survive a reload', (await p.inputValue('#in-name')) === 'Yashar' && await G(p, () => window.SSGame.cfg.dist === 4));

  /* ===== single player, creative: world, physics, building ===== */
  ok('creative world loads', await startSingle(p, 'creative', 'hello'));
  const info = await G(p, () => { const g = window.SSGame.G; return { mode: g.gameMode, hot: g.hotbar.length, meshes: window.SSGame.R.meshes.size, id: g.id }; });
  ok('creative mode, 9 hotbar slots, chunks meshed', info.mode === 'creative' && info.hot === 9 && info.meshes > 5, JSON.stringify(info));
  ok('world uses the same seed text -> deterministic terrain across clients', await G(p, () => window.SSGame.G.world.seed === window.SSWorld.seedFrom('hello')));
  await G(p, () => { const g = window.SSGame.G; g.me.y += 6; g.me.vy = 0; });
  await until(p, () => window.SSGame.G.me.onGround, 25000);
  const land = await G(p, () => { const g = window.SSGame.G; return { y: g.me.y, on: g.me.onGround, below: g.world.get(Math.floor(g.me.x), Math.floor(g.me.y - 0.1), Math.floor(g.me.z)) }; });
  ok('gravity: a player dropped from 6 blocks lands on solid ground', land.on && land.y > 1 && land.y < 63, JSON.stringify(land));
  const y0 = land.y;
  await G(p, () => { window.SSGame.inp.jump = true; }); await until(p, ([y]) => window.SSGame.G.me.y > y + 0.2, 6000, [y0]); const yJ = await G(p, () => window.SSGame.G.me.y); await G(p, () => { window.SSGame.inp.jump = false; });
  ok('jump leaves the ground', yJ > y0 + 0.2, `${y0} -> ${yJ}`);
  await until(p, () => window.SSGame.G.me.onGround, 12000);
  const x0 = await G(p, () => [window.SSGame.G.me.x, window.SSGame.G.me.z]);
  await G(p, () => { window.SSGame.inp.f = 1; window.SSGame.G.me.yaw = 0; }); await until(p, ([z]) => window.SSGame.G.me.z < z - 1.0, 12000, [x0[1]]); await G(p, () => { window.SSGame.inp.f = 0; });
  const x1 = await G(p, () => [window.SSGame.G.me.x, window.SSGame.G.me.z]);
  ok('forward key moves the player along the view direction (-Z)', x1[1] < x0[1] - 1.0, `${x0} -> ${x1}`);
  await stand(p);

  // mine + place: look straight down at the block under the feet
  await G(p, () => { const g = window.SSGame.G; g.me.pitch = -1.4; });
  const tgt = await G(p, () => { const t = window.SSGame.target(false); return t && { x: t.x, y: t.y, z: t.z, id: t.id }; });
  ok('raycast finds the block below', !!tgt && tgt.id !== 0, JSON.stringify(tgt));
  await G(p, ([t]) => window.SSGame.breakBlock(t.x, t.y, t.z), [tgt]); await sleep(150);
  ok('breaking removes the block locally and in the room', await G(p, ([t]) => window.SSGame.G.world.get(t.x, t.y, t.z) === 0 && window.SSGame.G.room.world.get(t.x, t.y, t.z) === 0, [tgt]));
  ok('the chunk is re-meshed right after an edit (no stale geometry)', await until(p, ([t]) => { const c = window.SSGame.G.world.chunks.get((t.x >> 4) + ',' + (t.z >> 4)); return c && !c.dirty; }, 5000, [tgt]));
  await G(p, () => { const g = window.SSGame.G; g.me.vy = 0; });
  await sleep(1200);
  await G(p, () => { const g = window.SSGame.G; g.me.pitch = -0.7; g.me.yaw = 0; window.SSGame.selectSlot(3); });
  const tg2 = await G(p, () => { const t = window.SSGame.target(true); return t && { x: t.x, y: t.y, z: t.z, nx: t.nx, ny: t.ny, nz: t.nz }; });
  const placed = await G(p, () => window.SSGame.placeBlock()); await sleep(200);
  ok('placing a block works and is confirmed by the room', placed === true && await G(p, ([t]) => { const id = window.SSGame.G.room.world.get(t.x + t.nx, t.y + t.ny, t.z + t.nz); return id === window.SSWorld.B.STONE || id === window.SSWorld.B.COBBLE; }, [tg2]), JSON.stringify(tg2));
  ok('cannot place a block inside your own body', await G(p, () => { const g = window.SSGame.G; const me = g.me; return window.SSGame.G.world.solid(Math.floor(me.x), Math.floor(me.y), Math.floor(me.z)) === false; }));
  // creative: flying
  await G(p, () => { const g = window.SSGame.G; g.me.flying = true; window.SSGame.inp.jump = true; }); await until(p, ([y]) => window.SSGame.G.me.y > y + 2, 12000, [land.y]); await G(p, () => { window.SSGame.inp.jump = false; });
  ok('creative flight: holding jump climbs without falling back', await G(p, () => window.SSGame.G.me.y) > land.y + 2);
  await G(p, () => { window.SSGame.G.me.flying = false; });

  /* ===== inventory + hotbar ===== */
  await G(p, () => window.SSGame.selectSlot(6));
  ok('number keys / selectSlot change the held item', await G(p, () => window.SSGame.G.sel === 6));
  await p.keyboard.press('Digit2');
  ok('keyboard 2 selects the pistol', await G(p, () => window.SSGame.G.sel === 1 && window.SSGame.G.hotbar[1].k === 'w'));
  await G(p, () => { window.SSGame.openInventory(); });
  ok('inventory lists every placeable block in creative', await G(p, () => document.getElementById('invgrid').children.length >= 12));
  await G(p, () => document.querySelectorAll('#invgrid .slot')[3].click());
  ok('picking a block puts it in the selected slot', await G(p, () => window.SSGame.G.hotbar[1].k === 'b') && await G(p, () => window.SSGame.G.screen) === 'play');
  await p.screenshot({ path: '/home/claude/t_creative.png' });

  /* ===== persistence: leave and continue ===== */
  const edited = await G(p, ([t]) => ({ x: t.x, y: t.y, z: t.z }), [tgt]);
  await G(p, () => window.SSGame.leave()); await sleep(600);
  await p.waitForSelector('#b-continue', { state: 'attached', timeout: 5000 }).catch(() => {}); await until(p, () => !document.getElementById('b-continue').classList.contains('hide'), 6000);
  ok('leaving returns to the menu with a continue button', await p.isVisible('#scr-main') && await G(p, () => !document.getElementById('b-continue').classList.contains('hide')));
  await p.click('#b-single'); await p.click('#b-continue');
  ok('continue reloads the saved world', await waitPlay(p));
  ok('the edit made before leaving is still there', await G(p, ([t]) => window.SSGame.G.world.get(t.x, t.y, t.z) === 0, [edited]));
  await G(p, () => window.SSGame.leave());
  await sleep(300);

  /* ===== survival: night, shadows, shooting ===== */
  await p.click('#b-single'); await p.click('label:has(input[name=gm][value=survival])'); await p.fill('#in-seed', 'night1'); await p.click('#b-new'); await waitPlay(p);
  ok('survival starts with weapons and no blocks', await G(p, () => { const g = window.SSGame.G; return g.gameMode === 'survival' && g.hotbar[0].k === 'w' && g.hotbar[2] === null; }));
  ok('mesh worker pool is active (chunks are built off the main thread)', await until(p, () => window.SSGame.pool.ok, 10000));
  await G(p, () => { window.SSGame.G.counts[5] = 2; });
  ok('crafting: a log becomes 4 planks', await G(p, () => { const S = window.SSGame; const b = S.G.counts[7] || 0; return S.craft(0) && S.G.counts[7] === b + 4 && S.G.counts[5] === 1; }));
  ok('crafting: sticks, then a wooden pickaxe goes to the hotbar', await G(p, () => { const S = window.SSGame; return S.craft(0) && S.craft(1) && S.craft(2) && S.G.counts[110] === 1 && S.G.hotbar.some((s) => s && s.k === 'i' && s.id === 110); }));
  ok('a pickaxe speeds up stone and stone drops cobble; bare hands are slow and drop nothing', await G(p, () => { const S = window.SSGame, B = window.SSWorld.B; const a = S.mineMult(B.STONE), d = S.dropFor(B.STONE); S.G.counts[110] = 0; const b = S.mineMult(B.STONE), d2 = S.dropFor(B.STONE); S.G.counts[110] = 1; return a === 2.5 && d.id === B.COBBLE && b === 0.35 && d2 === null; }));
  ok('grass drops dirt', await G(p, () => window.SSGame.dropFor(window.SSWorld.B.GRASS).id === window.SSWorld.B.DIRT));
  await G(p, () => { const S = window.SSGame, g = S.G; g.counts[102] = 0; S.giveId(102, 2); g.room.players.get(g.id).hp = 10; g.hp = 10; g.sel = g.hotbar.findIndex((s) => s && s.k === 'i' && s.id === 102); });
  ok('eating meat heals 2 hearts and uses one', await G(p, () => { const S = window.SSGame, g = S.G; return S.eat() && g.counts[102] === 1; }) && await until(p, () => window.SSGame.G.room.players.get(window.SSGame.G.id).hp === 14, 5000));
  await G(p, () => { window.SSGame.openCraft(); });
  ok('the crafting screen lists recipes and closes again', (await p.isVisible('#craft')) && await G(p, () => document.querySelectorAll('#craftlist .rec').length === 11) && await G(p, () => { window.SSGame.setScreen('craft'); document.getElementById('b-craft-close').click(); return window.SSGame.G.screen === 'play'; }));
  await G(p, () => { window.SSGame.G.room.tod = 0.75; });
  let sawEnemy = false;
  for (let i = 0; i < 80 && !sawEnemy; i++) { await sleep(250); sawEnemy = await G(p, () => window.SSGame.G.enemies.size > 0 && Array.from(window.SSGame.G.enemies.values())[0].buf.length > 0); }
  ok('shadows spawn at night', sawEnemy);
  await G(p, () => { const g = window.SSGame.G; g.me.pitch = 0; });
  // teleport one enemy in front of the player and shoot it
  const kill = await G(p, async () => {
    const g = window.SSGame.G, room = g.room, pl = room.players.get(g.id), en = room.enemies.values().next().value;
    if (!en) return { err: 'no enemy' };
    room.mode = 'survival';
    const fx = pl.x + 4, fz = pl.z;
    for (let y = Math.floor(pl.y); y < Math.floor(pl.y) + 4; y++) for (let dx = 1; dx <= 5; dx++) for (let dz = -1; dz <= 1; dz++) { room.world.set(Math.floor(pl.x) + dx, y, Math.floor(pl.z) + dz, 0, true); g.world.set(Math.floor(pl.x) + dx, y, Math.floor(pl.z) + dz, 0); }
    en.x = fx; en.z = fz; en.y = pl.y; en.vx = en.vz = en.vy = 0; en.hp = 1; en.id && 0;
    return { id: en.id };
  });
  ok('an enemy can be placed in the line of fire', !!kill.id, JSON.stringify(kill));
  await sleep(150);
  const ek = await G(p, () => { const e = window.SSGame.G.room.enemies.values().next().value; return e ? [e.x, e.y + 1, e.z] : null; });
  await aimAt(p, ...ek);
  const beforeKills = await G(p, () => window.SSGame.G.kills);
  let killed = false;
  for (let i = 0; i < 12 && !killed; i++) {
    await G(p, () => { const e = window.SSGame.G.room.enemies.values().next().value; if (e) { window.SSGame.G.room.players.get(window.SSGame.G.id).lastShot = [-9, -9]; } });
    const t = await G(p, () => { const e = window.SSGame.G.room.enemies.values().next().value; return e ? [e.x, e.y + 1, e.z] : null; });
    if (!t) break;
    await aimAt(p, ...t); await G(p, () => { window.SSGame.G.lastShot = [-9, -9]; window.SSGame.fire(0); }); await sleep(250);
    killed = (await G(p, () => window.SSGame.G.kills)) > beforeKills;
  }
  ok('shooting a shadow kills it, counts the kill and drops ammo', killed && await G(p, () => window.SSGame.G.ammo[0].res) > 120);
  ok('ammo is consumed per shot and reload refills the magazine', await G(p, async () => { const g = window.SSGame.G, a = g.ammo[0]; const m0 = a.mag; g.lastShot = [-9, -9]; window.SSGame.fire(0); return a.mag === m0 - 1; }));
  // damage and death
  await G(p, () => { const g = window.SSGame.G; g.room.players.get(g.id).hp = 3; });
  await G(p, () => { const g = window.SSGame.G, r = g.room, pl = r.players.get(g.id); r.hurt(pl, 5, 'تست'); });
  await sleep(400);
  ok('death shows the death screen', await G(p, () => window.SSGame.G.screen === 'death') && await p.isVisible('#death'));
  await p.click('#b-respawn'); await sleep(500);
  ok('respawn restores health and play', await G(p, () => window.SSGame.G.alive && window.SSGame.G.hp === 20 && window.SSGame.G.screen === 'play'));
  await p.screenshot({ path: '/home/claude/t_survival.png' });
  await G(p, () => window.SSGame.leave());

  /* ===== online multiplayer through the real server ===== */
  const ctxB = await b.newContext({ viewport: { width: 960, height: 540 } }); await ctxB.addInitScript(LIGHT);
  const pA = await newPage(ctx, 'A2'), pB = await newPage(ctxB, 'B');
  for (const [pg, nm] of [[pA, 'Ali'], [pB, 'Sara']]) {
    await pg.goto(`http://127.0.0.1:${PORT}/`, { timeout: 90000 }); await sleep(300);
    await pg.fill('#in-name', nm); await pg.click('#b-online');
    ok(nm + ': server address is pre-filled from the page URL', (await pg.inputValue('#in-server')) === `127.0.0.1:${PORT}`);
    await pg.fill('#in-room', 'arena'); await pg.click('#b-connect');
  }
  ok('both players join the online world', await waitPlay(pA) && await waitPlay(pB));
  await sleep(1500);
  const idA = await G(pA, () => window.SSGame.G.id), idB = await G(pB, () => window.SSGame.G.id);
  ok('players get different ids and the server seed', idA !== idB && await G(pA, () => window.SSGame.G.world.seed) === await G(pB, () => window.SSGame.G.world.seed));
  ok('each sees the other (remote player + name)', await G(pA, () => window.SSGame.G.remote.size) === 1 && await G(pB, () => Array.from(window.SSGame.G.remote.values())[0].name) === 'Ali');
  await G(pA, () => { const g = window.SSGame.G; g.me.x += 3; g.me.vx = 0; });
  const realX = await G(pA, () => window.SSGame.G.me.x);
  await until(pB, (rx) => { const e = Array.from(window.SSGame.G.remote.values())[0]; return e && e.buf.length && Math.abs(e.buf[e.buf.length - 1].x - rx) < 1.5; }, 15000, realX);
  const seen = await G(pB, () => { const e = Array.from(window.SSGame.G.remote.values())[0]; return e.buf.length ? e.buf[e.buf.length - 1].x : null; });
  const real = await G(pA, () => window.SSGame.G.me.x);
  ok('movement is relayed (B sees A at A\'s position)', seen !== null && Math.abs(seen - real) < 1.5, `${seen} vs ${real}`);
  // build sync
  await G(pA, () => { window.SSGame.G.me.pitch = -1.45; });
  await sleep(300);
  const tA = await G(pA, () => { const t = window.SSGame.target(false); return t && { x: t.x, y: t.y, z: t.z }; });
  await G(pA, ([t]) => window.SSGame.breakBlock(t.x, t.y, t.z), [tA]);
  ok('a block broken by A disappears for B', await until(pB, ([t]) => window.SSGame.G.world.get(t.x, t.y, t.z) === 0, 15000, [tA]));
  // chat
  await pA.keyboard.press('KeyT'); await pA.fill('#chatin', 'سلام سارا'); await pA.keyboard.press('Enter'); 
  ok('chat reaches the other player', await until(pB, () => document.getElementById('chatlog').textContent.includes('سلام سارا'), 15000));
  await pA.screenshot({ path: '/home/claude/t_online_A.png' }); await pB.screenshot({ path: '/home/claude/t_online_B.png' });
  // late joiner receives existing edits
  const pC = await newPage(ctxB, 'C'); await pC.goto(`http://127.0.0.1:${PORT}/`, { timeout: 90000 }); await sleep(300); await pC.fill('#in-name', 'Reza'); await pC.click('#b-online'); await pC.fill('#in-room', 'arena'); await pC.click('#b-connect'); await waitPlay(pC); await sleep(800);
  ok('a late joiner sees the earlier edit', await G(pC, ([t]) => window.SSGame.G.world.get(t.x, t.y, t.z) === 0, [tA]));
  await G(pC, () => window.SSGame.leave()); await sleep(400);
  ok('leaving removes the player for the others', await until(pA, () => window.SSGame.G.remote.size === 1, 8000));
  await G(pB, () => window.SSGame.leave()); await sleep(400);
  await sleep(1500);
  ok('server-side room tracks players', await fetch(`http://127.0.0.1:${PORT}/api/info`).then((r) => r.json()).then((j) => j.rooms.some((r) => r.name === 'arena' && r.players === 1)));
  await G(pA, () => window.SSGame.leave());

  /* ===== wrong server address: friendly failure ===== */
  await pA.click('#b-online'); await pA.fill('#in-server', '127.0.0.1:1'); await pA.click('#b-connect'); await sleep(1500);
  ok('connecting to a dead server shows a clear message and stays in the menu', (await pA.textContent('#online-msg')).includes('اتصال برقرار نشد') && await G(pA, () => window.SSGame.G.screen) === 'menu');

  /* ===== Wi-Fi mode: direct WebRTC pairing, no server ===== */
  const ctxH = await b.newContext({ viewport: { width: 960, height: 540 }, permissions: ["clipboard-read", "clipboard-write"] }), ctxG = await b.newContext({ viewport: { width: 960, height: 540 } }); await ctxH.addInitScript(LIGHT);
  const pH = await newPage(ctxH, 'HOST'), pG = await newPage(ctxG, 'GUEST');
  await pH.goto(`http://127.0.0.1:${PORT}/`, { timeout: 90000 }); await pG.goto(`http://127.0.0.1:${PORT}/`, { timeout: 90000 }); await sleep(400);
  await pH.fill('#in-name', 'Host'); await pH.click('#b-lan'); await pH.click('#b-host');
  ok('host starts a local room (no server connection)', await waitPlay(pH) && await G(pH, () => window.SSGame.G.kind === 'host' && window.SSGame.G.net.kind === 'local'));
  await G(pH, () => window.SSGame.pauseGame()); await pH.click('#b-invite');
  await pH.click('#b-h-make'); await pH.waitForFunction(() => document.getElementById('t-h-offer').value.startsWith('S'), null, { timeout: 15000 });
  const offer = await pH.inputValue('#t-h-offer');
  ok('invite code is short enough to paste into a chat app', offer.length > 100 && offer.length < 2500, String(offer.length));
  await pG.fill('#in-name', 'Guest'); await pG.click('#b-lan'); await pG.click('#b-guest'); await pG.fill('#t-g-offer', offer); await pG.click('#b-g-make');
  await pG.waitForFunction(() => document.getElementById('t-g-answer').value.startsWith('S'), null, { timeout: 15000 });
  const answer = await pG.inputValue('#t-g-answer');
  await pH.fill('#t-h-answer', answer); await pH.click('#b-h-accept');
  ok('the guest joins the host over WebRTC', await waitPlay(pG, 60000));
  await sleep(1500);
  ok('host sees the guest and the guest sees the host', await until(pH, () => window.SSGame.G.remote.size === 1, 10000) && await until(pG, () => window.SSGame.G.remote.size === 1, 10000));
  ok('the guest is on the same world seed', await G(pG, () => window.SSGame.G.world.seed) === await G(pH, () => window.SSGame.G.world.seed));
  await pH.click('#b-h-close'); await G(pH, () => { const g = window.SSGame.G; g.me.pitch = -1.45; }); await sleep(300);
  const tH = await G(pH, () => { const t = window.SSGame.target(false); return t && { x: t.x, y: t.y, z: t.z }; });
  await G(pH, ([t]) => window.SSGame.breakBlock(t.x, t.y, t.z), [tH]); await sleep(700);
  ok('edits sync over the direct link', await G(pG, ([t]) => window.SSGame.G.world.get(t.x, t.y, t.z) === 0, [tH]));
  await G(pG, () => { window.SSGame.G.net.send({ t: 'chat', text: 'hi host' }); }); await sleep(500);
  ok('chat works over the direct link', await G(pH, () => document.getElementById('chatlog').textContent.includes('hi host')));
  await G(pG, () => window.SSGame.leave()); await sleep(500);
  ok('host notices the guest leaving', await G(pH, () => window.SSGame.G.remote.size) === 0);
  await G(pH, () => window.SSGame.leave());

  /* ===== phone layout ===== */
  const ctxM = await b.newContext({ viewport: { width: 740, height: 360 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 }); await ctxM.addInitScript(LIGHT);
  const pM = await newPage(ctxM, 'MOBILE'); await pM.goto(`http://127.0.0.1:${PORT}/`, { timeout: 90000 }); await sleep(400);
  ok('touch devices get on-screen controls', await G(pM, () => document.body.classList.contains('touch')));
  ok('mobile defaults are lighter (render distance 4)', await G(pM, () => window.SSGame.cfg.dist === 4 && window.SSGame.cfg.scale === 80));
  await pM.click('#b-single'); await pM.click('label:has(input[name=gm][value=creative])'); await pM.click('#b-new'); await waitPlay(pM); await sleep(800);
  ok('joystick, look pad and action buttons are visible in game', await pM.isVisible('#joy') && await pM.isVisible('#t-attack') && await pM.isVisible('#t-place') && await pM.isVisible('#t-jump'));
  const box = await pM.locator('#joy').boundingBox();
  await pM.touchscreen.tap(box.x + box.width / 2, box.y + 10); // joystick tap must not crash
  const pos0 = await G(pM, () => [window.SSGame.G.me.x, window.SSGame.G.me.z]);
  await G(pM, () => { window.SSGame.inp.joyY = 1; }); await until(pM, ([x, z]) => Math.hypot(window.SSGame.G.me.x - x, window.SSGame.G.me.z - z) > 1.6, 12000, pos0); await G(pM, () => { window.SSGame.inp.joyY = 0; });
  const pos1 = await G(pM, () => [window.SSGame.G.me.x, window.SSGame.G.me.z]);
  ok('joystick forward moves the player', Math.hypot(pos1[0] - pos0[0], pos1[1] - pos0[1]) > 1.5, `${pos0} -> ${pos1}`);
  const lookBox = await pM.locator('#look').boundingBox();
  const yaw0 = await G(pM, () => window.SSGame.G.me.yaw);
  await pM.evaluate(([x, y]) => { const el = document.getElementById('look'); const mk = (t, cx) => el.dispatchEvent(new PointerEvent(t, { pointerId: 7, clientX: cx, clientY: y, bubbles: true, pointerType: 'touch' })); mk('pointerdown', x); mk('pointermove', x + 60); mk('pointerup', x + 60); }, [lookBox.x + lookBox.width / 2, lookBox.y + lookBox.height / 2]);
  ok('dragging the right side turns the camera', Math.abs((await G(pM, () => window.SSGame.G.me.yaw)) - yaw0) > 0.1);
  await pM.screenshot({ path: '/home/claude/t_mobile.png' });
  await G(pM, () => window.SSGame.leave());
  ok('GL/JS errors during all tests: none', errs.length === 0, errs.slice(0, 5).join(' | '));
} catch (e) {
  fails++; console.log('FAIL exception: ' + (e && e.stack || e));
} finally {
  if (b) await b.close();
  srv.kill();
}
console.log(`PASSES ${passes} FAILS ${fails}`);
process.exit(fails ? 1 : 0);
