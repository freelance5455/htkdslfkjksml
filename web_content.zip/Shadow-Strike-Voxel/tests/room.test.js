// Node unit tests for the shared world + room logic (no browser needed).
const assert = require('node:assert');
const test = require('node:test');
const SS = require('../js/world.js');
const { Room, MOBS } = require('../js/room.js');
const { B, World } = SS;

function client(room, name) {
  const msgs = [];
  const conn = { send: (s) => msgs.push(JSON.parse(s)), close() { this.closed = true; } };
  room.attach(conn);
  room.onMessage(conn, JSON.stringify({ t: 'join', name }));
  const api = { conn, msgs, send: (o) => room.onMessage(conn, JSON.stringify(o)), last: (t) => [...msgs].reverse().find((m) => m.t === t), all: (t) => msgs.filter((m) => m.t === t) };
  api.welcome = api.last('welcome');
  return api;
}
const tickN = (room, n, dt = 0.05) => { for (let i = 0; i < n; i++) room.tick(dt); };

test('world is deterministic and edits round-trip', () => {
  const a = new World('abc'), b = new World('abc');
  for (let i = 0; i < 300; i++) { const x = (i * 53) % 300 - 150, z = (i * 17) % 300 - 150, y = i % 60; assert.strictEqual(a.get(x, y, z), b.get(x, y, z)); }
  a.set(3, 40, 3, B.BRICK); a.set(-20, 41, 17, B.LAMP);
  const c = new World('abc'); c.importEdits(a.exportEdits());
  assert.strictEqual(c.get(3, 40, 3), B.BRICK); assert.strictEqual(c.get(-20, 41, 17), B.LAMP);
});
test('seeds differ and numeric/text seeds are stable', () => {
  assert.notStrictEqual(SS.seedFrom('a'), SS.seedFrom('b'));
  assert.strictEqual(SS.seedFrom('123'), 123);
  assert.strictEqual(SS.seedFrom('پرچم'), SS.seedFrom('پرچم'));
});
test('physics: falling entity lands on the ground and cannot walk through walls', () => {
  const w = new World('phys'), sp = w.spawnPoint();
  const e = { x: sp.x, y: sp.y + 6, z: sp.z, w: 0.6, h: 1.8, vx: 0, vy: 0, vz: 0 };
  let ground = false;
  for (let i = 0; i < 200 && !ground; i++) { e.vy -= 30 * 0.02; ground = SS.moveEntity(w, e, 0, e.vy * 0.02, 0).onGround; }
  assert.ok(ground && Math.abs(e.y - sp.y) < 0.05, 'landed at ' + e.y + ' expected ' + sp.y);
  const gx = Math.floor(e.x) + 3, gy = Math.floor(e.y);
  for (let y = gy; y < gy + 3; y++) for (let z = Math.floor(e.z) - 1; z <= Math.floor(e.z) + 1; z++) w.set(gx, y, z, B.STONE);
  for (let i = 0; i < 100; i++) SS.moveEntity(w, e, 0.2, 0, 0);
  assert.ok(e.x < gx - 0.29, 'stopped by wall at ' + e.x);
});
test('raycast hits the block under the player and reports the face', () => {
  const w = new World('ray'), sp = w.spawnPoint(), r = w.raycast(sp.x, sp.y + 1.6, sp.z, 0, -1, 0, 6);
  assert.ok(r && r.ny === 1 && r.y === Math.floor(sp.y) - 1);
});

test('join: welcome with seed, id, spawn and edits batch; second player is announced', () => {
  const room = new Room({ seed: 7, mode: 'creative' });
  room.world.set(2, 40, 2, B.BRICK);
  const a = client(room, 'Ali');
  assert.ok(a.welcome && a.welcome.seed === 7 && a.welcome.id === 1 && a.welcome.admin === true);
  assert.deepStrictEqual(a.last('edits').a, [2, 40, 2, B.BRICK]);
  const b = client(room, 'Ali');
  assert.strictEqual(b.welcome.name, 'Ali2');
  assert.ok(a.last('join') && a.last('join').name === 'Ali2');
  assert.strictEqual(b.welcome.admin, false);
});
test('room full is refused', () => {
  const room = new Room({ maxPlayers: 1 }); client(room, 'a'); const b = client(room, 'b');
  assert.ok(b.last('full') && b.conn.closed);
});
test('block edits: reach, bedrock, placing inside players and rate limit are enforced', () => {
  const room = new Room({ seed: 3, mode: 'creative' }), a = client(room, 'A'), b = client(room, 'B');
  const w = a.welcome, bx = Math.floor(w.x), by = Math.floor(w.y), bz = Math.floor(w.z);
  a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 });
  a.send({ t: 'block', x: bx + 2, y: by + 1, z: bz, id: B.BRICK });
  assert.strictEqual(room.world.get(bx + 2, by + 1, bz), B.BRICK);
  assert.ok(b.last('block') && b.last('block').id === B.BRICK, 'other player got the edit');
  a.send({ t: 'block', x: bx + 40, y: by, z: bz, id: B.BRICK });
  assert.ok(a.last('reject'), 'far edit rejected');
  a.send({ t: 'block', x: bx, y: 0, z: bz, id: 0 });
  assert.ok(a.all('reject').length >= 2, 'bedrock level rejected');
  a.send({ t: 'block', x: bx, y: by, z: bz, id: B.STONE });
  assert.notStrictEqual(room.world.get(bx, by, bz), B.STONE, 'cannot build inside own body');
  const before = a.all('reject').length;
  for (let i = 0; i < 60; i++) a.send({ t: 'block', x: bx + 2, y: by + 1 + (i % 2), z: bz + 1, id: B.GLASS });
  assert.ok(a.all('reject').length > before + 10, 'burst of edits is rate limited');
  tickN(room, 40);
  a.send({ t: 'block', x: bx + 2, y: by + 1, z: bz, id: 0 });
  assert.strictEqual(room.world.get(bx + 2, by + 1, bz), B.AIR);
});
test('invalid or hostile messages never crash the room', () => {
  const room = new Room({ seed: 3 }), a = client(room, 'A');
  const bad = ['{', 'null', '[]', '{"t":5}', '{"t":"block","x":"a"}', '{"t":"s","x":null}', '{"t":"shoot","d":[1]}', '{"t":"chat","text":{}}', 'x'.repeat(70000), '{"t":"block","x":1.5,"y":2,"z":3,"id":1}', '{"t":"fall","d":"x"}'];
  for (const m of bad) room.onMessage(a.conn, m);
  room.onMessage(a.conn, undefined);
  tickN(room, 3);
  assert.ok(room.players.size === 1);
});
test('teleport cheating is rubber-banded', () => {
  const room = new Room({ seed: 3 }), a = client(room, 'A'), w = a.welcome;
  a.send({ t: 's', x: w.x + 500, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 });
  assert.ok(a.last('tp') && Math.abs(a.last('tp').x - w.x) < 1);
});
test('chat is sanitised and commands need admin', () => {
  const room = new Room({ seed: 1, mode: 'creative' }), a = client(room, 'A'), b = client(room, 'B');
  tickN(room, 20);
  a.send({ t: 'chat', text: '<b>سلام</b>' });
  assert.strictEqual(b.last('chat').text, 'bسلام/b');
  tickN(room, 20); b.send({ t: 'chat', text: '/time night' });
  assert.ok(b.last('chat').text.includes('مدیر'));
  const t0 = room.tod; tickN(room, 20); a.send({ t: 'chat', text: '/time night' });
  assert.ok(Math.abs(room.tod - 0.75) < 0.01 && room.tod !== t0);
});
test('time of day advances and wraps', () => {
  const room = new Room({ seed: 1, dayLen: 10, tod: 0.95 }); tickN(room, 40);
  assert.ok(room.tod < 0.95 && room.tod > 0.1, String(room.tod));
});

test('survival: shadows spawn at night, chase, hurt, and can be shot dead with loot + kill event', () => {
  const room = new Room({ seed: 5, mode: 'survival', tod: 0.75 }), a = client(room, 'A'), w = a.welcome;
  a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 });
  for (let i = 0; i < 400 && room.enemies.size === 0; i++) { room.tick(0.05); a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 }); }
  assert.ok(room.enemies.size > 0, 'enemies spawned at night');
  const snap = a.last('snap'); assert.ok(snap.p.length === 1 && snap.tod > 0);
  let hurt = false;
  for (let i = 0; i < 900 && !hurt; i++) { room.tick(0.05); a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 }); hurt = !!a.last('hp') && a.last('hp').dmg > 0; }
  assert.ok(hurt, 'an enemy reached and hurt the player');
  // kill one with the rifle: aim straight at it
  const e = room.enemies.values().next().value, p = room.players.get(1);
  e.x = p.x + 3; e.z = p.z; e.y = p.y; e.hp = 5; e.vx = e.vz = 0;
  room.world.set(Math.floor(p.x) + 1, Math.floor(p.y) + 1, Math.floor(p.z), 0, true);
  p.lastShot = [-9, -9];
  a.send({ t: 'shoot', w: 0, d: [e.x - p.x, e.y + 1 - (p.y + 1.62), e.z - p.z] });
  assert.ok((a.last('hit') && a.last('hit').k === 'enemy') || a.last('kill'), 'shot registered');
  assert.ok(a.last('loot') && a.last('loot').ammo > 0, 'loot ammo granted');
  assert.ok(a.last('kill') && a.last('kill').by === 1);
});
test('shooting through a wall does not hit', () => {
  const room = new Room({ seed: 5, mode: 'survival' }), a = client(room, 'A'), p = room.players.get(1);
  const e = { id: 99, type: 'shadow', x: p.x + 6, y: p.y, z: p.z, vx: 0, vy: 0, vz: 0, w: .6, h: 1.8, hp: 20, yaw: 0, cool: 0, slow: 0, wander: 0, hurt: -9 };
  room.enemies.set(99, e);
  for (let y = Math.floor(p.y); y < Math.floor(p.y) + 4; y++) for (let z = -2; z <= 2; z++) room.world.set(Math.floor(p.x) + 3, y, Math.floor(p.z) + z, B.STONE, true);
  a.send({ t: 'shoot', w: 0, d: [1, 0.0, 0] });
  assert.ok(!a.last('hit') || a.last('hit').k !== 'enemy');
  assert.strictEqual(room.enemies.get(99).hp, 20);
});
test('death, respawn, fall damage and creative immunity', () => {
  const room = new Room({ seed: 5, mode: 'survival' }), a = client(room, 'A');
  a.send({ t: 'fall', d: 30 });
  assert.ok(a.last('died'), 'died from a long fall'); assert.strictEqual(room.players.get(1).alive, false);
  tickN(room, 5);
  a.send({ t: 'respawn' });
  assert.ok(a.last('respawn') && room.players.get(1).alive && room.players.get(1).hp === 20);
  a.send({ t: 'fall', d: 5 }); assert.strictEqual(room.players.get(1).hp, 18);
  room.mode = 'creative'; a.send({ t: 'fall', d: 40 }); assert.strictEqual(room.players.get(1).hp, 18);
});
test('pvp only when enabled', () => {
  const room = new Room({ seed: 9, mode: 'survival', pvp: false }), a = client(room, 'A'), b = client(room, 'B');
  const pa = room.players.get(1), pb = room.players.get(2); pb.x = pa.x + 4; pb.z = pa.z; pb.y = pa.y;
  for (let z = -1; z <= 1; z++) for (let y = 0; y < 3; y++) for (let x = 1; x < 4; x++) room.world.set(Math.floor(pa.x) + x, Math.floor(pa.y) + y, Math.floor(pa.z) + z, 0, true);
  pa.lastShot = [-9, -9]; a.send({ t: 'shoot', w: 1, d: [pb.x - pa.x, pb.y + 1 - (pa.y + 1.62), 0] });
  assert.strictEqual(pb.hp, 20, 'no damage with pvp off');
  room.pvp = true; pa.lastShot = [-9, -9]; a.send({ t: 'shoot', w: 1, d: [pb.x - pa.x, pb.y + 1 - (pa.y + 1.62), 0] });
  assert.ok(pb.hp < 20, 'damage with pvp on');
});
test('save/load keeps the world, mode, time and player positions', () => {
  const room = new Room({ seed: 11, mode: 'creative', tod: 0.6 }), a = client(room, 'Sara');
  a.send({ t: 's', x: a.welcome.x + 3, y: a.welcome.y, z: a.welcome.z, yaw: 0, pitch: 0, f: 0 });
  room.world.set(5, 45, 5, B.LAMP);
  const save = JSON.parse(JSON.stringify(room.serialize()));
  room.onClose(a.conn);
  const r2 = Room.fromSave(save, {}); assert.strictEqual(r2.world.get(5, 45, 5), B.LAMP); assert.strictEqual(r2.mode, 'creative'); assert.strictEqual(r2.world.seed, 11);
  const b = client(r2, 'Sara'); assert.ok(Math.abs(b.welcome.x - (a.welcome.x + 3)) < 0.01, 'rejoin at saved position');
});
test('disconnect cleans up and passes admin on', () => {
  const room = new Room({ seed: 1 }), a = client(room, 'A'), b = client(room, 'B');
  room.onClose(a.conn);
  assert.strictEqual(room.players.size, 1); assert.strictEqual(room.adminId, 2); assert.ok(b.last('leave'));
});
test('idle connections are dropped', () => {
  const room = new Room({ seed: 1 }), a = client(room, 'A');
  tickN(room, 1000);
  assert.strictEqual(room.players.size, 0); assert.ok(a.conn.closed);
});
test('phase ability slows enemies and has a cooldown', () => {
  const room = new Room({ seed: 1, mode: 'survival' }), a = client(room, 'A'), p = room.players.get(1);
  const e = { id: 5, type: 'shadow', x: p.x + 5, y: p.y, z: p.z, vx: 0, vy: 0, vz: 0, w: .6, h: 1.8, hp: 20, yaw: 0, cool: 0, slow: 0, wander: 0, hurt: -9 };
  room.enemies.set(5, e); tickN(room, 2);
  a.send({ t: 'ab', k: 'phase' }); assert.ok(e.slow > room.clock);
  const n = a.all('fx').length; a.send({ t: 'ab', k: 'phase' }); assert.strictEqual(a.all('fx').length, n, 'cooldown blocks a second use');
});

test('daytime: cows and pigs spawn on grass, can be shot for meat; meat heals', () => {
  const room = new Room({ seed: 12, mode: 'survival', tod: 0.25 }), a = client(room, 'A'), w = a.welcome;
  for (let i = 0; i < 2000 && room.animals.size === 0; i++) { room.tick(0.05); a.send({ t: 's', x: w.x, y: w.y, z: w.z, yaw: 0, pitch: 0, f: 0 }); }
  assert.ok(room.animals.size > 0, 'animals spawned in daylight');
  assert.ok(a.last('snap').e.some((e) => e[1] === 'c' || e[1] === 'p'), 'animals are in snapshots');
  const an = room.animals.values().next().value, p = room.players.get(1);
  for (let y = Math.floor(p.y); y < Math.floor(p.y) + 4; y++) for (let dx = 1; dx <= 5; dx++) for (let dz = -1; dz <= 1; dz++) room.world.set(Math.floor(p.x) + dx, y, Math.floor(p.z) + dz, 0, true);
  an.x = p.x + 3; an.z = p.z; an.y = p.y; an.hp = 1; an.vx = an.vz = 0;
  p.lastShot = [-9, -9]; a.send({ t: 'shoot', w: 0, d: [an.x - p.x, an.y + 0.7 - (p.y + 1.62), 0] });
  const loot = a.last('loot'); assert.ok(loot && loot.item === 102 && loot.n >= 1, 'meat dropped'); assert.strictEqual(room.animals.has(an.id), false);
  assert.strictEqual(p.kills, 0, 'animals do not count as kills');
  p.hp = 10; a.send({ t: 'eat' }); assert.strictEqual(p.hp, 14);
  a.send({ t: 'eat' }); assert.strictEqual(p.hp, 14, 'eating has a cooldown');
});
test('no animals at night or in creative', () => {
  const night = new Room({ seed: 12, mode: 'survival', tod: 0.75 }); client(night, 'A'); tickN(night, 400);
  assert.strictEqual(night.animals.size, 0);
  const cr = new Room({ seed: 12, mode: 'creative', tod: 0.25 }); client(cr, 'A'); tickN(cr, 400);
  assert.strictEqual(cr.animals.size, 0);
});
