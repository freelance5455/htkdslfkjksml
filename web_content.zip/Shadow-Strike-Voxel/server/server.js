#!/usr/bin/env node
/* Shadow Strike Voxel — dedicated server.
   No npm packages needed (Node 18+). It serves the game files AND runs the multiplayer rooms, so
   phones on the same Wi-Fi only need to open  http://<this computer's address>:3000  — no internet.
   Put it on any VPS for online play. Worlds are saved in ./worlds. */
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { Room } = require("../js/room.js");

const ROOT = path.resolve(__dirname, "..");
const CFG = {
  port: Number(process.env.PORT) || 3000,
  host: process.env.HOST || "0.0.0.0",
  dataDir: process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, "worlds"),
  mode: process.env.MODE === "creative" ? "creative" : "survival",
  pvp: process.env.PVP === "1" || process.env.PVP === "true",
  seed: process.env.SEED || null,
  maxPlayers: Math.max(1, Math.min(32, Number(process.env.MAX_PLAYERS) || 12)),
  dayLen: Number(process.env.DAYLEN) || 600,
  maxPerIp: 8,
};
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8" };
const PUBLIC = /^\/(index\.html|manifest\.json|service-worker\.js|js\/[\w.-]+\.js|css\/[\w.-]+\.css|icons\/[\w.-]+\.png)?$/;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

/* ---------- rooms ---------- */
const rooms = new Map();
const cleanRoom = (s) => String(s || "main").replace(/[^\w-]/g, "").slice(0, 24) || "main";
function roomFile(name) { return path.join(CFG.dataDir, name + ".json"); }
function getRoom(name) {
  name = cleanRoom(name);
  let r = rooms.get(name);
  if (r) return r;
  const opts = { name, maxPlayers: CFG.maxPlayers, dayLen: CFG.dayLen, mode: CFG.mode, pvp: CFG.pvp, seed: CFG.seed != null ? CFG.seed : Math.floor(Math.random() * 1e9) };
  try {
    const save = JSON.parse(fs.readFileSync(roomFile(name), "utf8"));
    r = Room.fromSave(save, opts); log("loaded world", name, "edits:", save.edits.length / 4);
  } catch (e) { r = new Room(opts); log("new world", name, "seed", r.world.seed); }
  rooms.set(name, r);
  return r;
}
function saveRoom(r, force) {
  if (!r.dirty && !force) return;
  try {
    fs.mkdirSync(CFG.dataDir, { recursive: true });
    const f = roomFile(r.name), tmp = f + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(r.serialize()));
    fs.renameSync(tmp, f); r.dirty = false;
  } catch (e) { log("save failed", r.name, e.message); }
}

/* ---------- minimal WebSocket (RFC 6455) ---------- */
const GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11", MAXFRAME = 256 * 1024;
function frame(op, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}
class WSConn {
  constructor(socket, ip) {
    this.socket = socket; this.ip = ip; this.buf = Buffer.alloc(0); this.frags = []; this.fragLen = 0; this.closed = false; this.alive = true;
    this.onmessage = null; this.onclose = null;
    socket.setNoDelay(true);
    socket.on("data", (d) => this.onData(d));
    socket.on("close", () => this.finish());
    socket.on("error", () => this.finish());
  }
  send(str) {
    if (this.closed) return;
    if (this.socket.writableLength > 1.5e6) return; // slow client: drop instead of growing memory
    this.socket.write(frame(0x1, Buffer.from(str, "utf8")));
  }
  close() { if (this.closed) return; try { this.socket.write(frame(0x8, Buffer.alloc(0))); this.socket.end(); } catch (e) { /* */ } this.finish(); }
  finish() { if (this.closed) return; this.closed = true; try { this.socket.destroy(); } catch (e) { /* */ } if (this.onclose) this.onclose(); }
  onData(d) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    for (;;) {
      if (this.buf.length < 2) return;
      const b0 = this.buf[0], b1 = this.buf[1], op = b0 & 0x0f, fin = !!(b0 & 0x80), masked = !!(b1 & 0x80);
      let len = b1 & 0x7f, off = 2;
      if (len === 126) { if (this.buf.length < 4) return; len = this.buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (this.buf.length < 10) return; const big = this.buf.readBigUInt64BE(2); if (big > BigInt(MAXFRAME)) return this.close(); len = Number(big); off = 10; }
      if (len > MAXFRAME || !masked) return this.close(); // browsers always mask
      if (this.buf.length < off + 4 + len) return;
      const mask = this.buf.subarray(off, off + 4), payload = Buffer.from(this.buf.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) payload[i] ^= mask[i & 3];
      this.buf = this.buf.subarray(off + 4 + len);
      if (op === 0x8) return this.close();
      if (op === 0x9) { this.socket.write(frame(0xA, payload)); continue; }
      if (op === 0xA) { this.alive = true; continue; }
      if (op === 0x1 || op === 0x0) {
        this.frags.push(payload); this.fragLen += len;
        if (this.fragLen > MAXFRAME) return this.close();
        if (fin) { const text = Buffer.concat(this.frags).toString("utf8"); this.frags = []; this.fragLen = 0; if (this.onmessage) this.onmessage(text); }
      }
    }
  }
}

/* ---------- HTTP ---------- */
const ipCount = new Map();
const server = http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, "http://x"); } catch (e) { res.writeHead(400); return res.end(); }
  let p = decodeURIComponent(url.pathname);
  if (p === "/api/info") {
    const info = { name: "Shadow Strike Voxel", rooms: Array.from(rooms.values()).map((r) => ({ name: r.name, players: r.players.size, max: r.maxPlayers, mode: r.mode })), version: 1 };
    res.writeHead(200, { "content-type": "application/json", "cache-control": "no-store", "access-control-allow-origin": "*" });
    return res.end(JSON.stringify(info));
  }
  if (p === "/") p = "/index.html";
  if (!PUBLIC.test(p) || p.includes("..")) { res.writeHead(404, { "content-type": "text/plain" }); return res.end("not found"); }
  const file = path.join(ROOT, p);
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { "content-type": "text/plain" }); return res.end("not found"); }
    const ext = path.extname(file);
    res.writeHead(200, { "content-type": MIME[ext] || "application/octet-stream", "cache-control": ext === ".png" ? "public, max-age=86400" : "no-cache", "x-content-type-options": "nosniff" });
    res.end(data);
  });
});
server.on("upgrade", (req, socket) => {
  let url;
  try { url = new URL(req.url, "http://x"); } catch (e) { return socket.destroy(); }
  const key = req.headers["sec-websocket-key"];
  if (url.pathname !== "/ws" || !key || String(req.headers.upgrade).toLowerCase() !== "websocket") { socket.write("HTTP/1.1 400 Bad Request\r\n\r\n"); return socket.destroy(); }
  const ip = socket.remoteAddress || "?";
  if ((ipCount.get(ip) || 0) >= CFG.maxPerIp) { socket.write("HTTP/1.1 429 Too Many Requests\r\n\r\n"); return socket.destroy(); }
  const accept = crypto.createHash("sha1").update(key + GUID).digest("base64");
  socket.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n");
  ipCount.set(ip, (ipCount.get(ip) || 0) + 1);
  const room = getRoom(url.searchParams.get("room")), ws = new WSConn(socket, ip);
  room.attach(ws);
  ws.onmessage = (t) => room.onMessage(ws, t);
  ws.onclose = () => { room.onClose(ws); ipCount.set(ip, Math.max(0, (ipCount.get(ip) || 1) - 1)); if (!room.players.size) saveRoom(room); };
});

/* ---------- loops ---------- */
let last = Date.now();
const tickTimer = setInterval(() => {
  const now = Date.now(), dt = Math.min(0.1, (now - last) / 1000); last = now;
  rooms.forEach((r) => { try { r.tick(dt); } catch (e) { log("tick error", r.name, e.stack); } });
}, 50);
const pingTimer = setInterval(() => { rooms.forEach((r) => r.conns.forEach((p, c) => { if (c instanceof WSConn) { if (!c.alive) return c.close(); c.alive = false; try { c.socket.write(frame(0x9, Buffer.alloc(0))); } catch (e) { /* */ } } })); }, 15000);
const saveTimer = setInterval(() => rooms.forEach((r) => saveRoom(r)), 20000);

function shutdown() {
  clearInterval(tickTimer); clearInterval(pingTimer); clearInterval(saveTimer);
  rooms.forEach((r) => saveRoom(r, true));
  server.close(); setTimeout(() => process.exit(0), 200);
}
process.on("SIGINT", shutdown); process.on("SIGTERM", shutdown);

function lanAddresses() {
  const out = [];
  Object.values(os.networkInterfaces()).forEach((l) => (l || []).forEach((i) => { if (i.family === "IPv4" && !i.internal) out.push(i.address); }));
  return out;
}
if (require.main === module) {
  server.listen(CFG.port, CFG.host, () => {
    log("Shadow Strike Voxel server is running");
    log("  this computer:  http://localhost:" + CFG.port);
    lanAddresses().forEach((a) => log("  other devices on the same Wi-Fi:  http://" + a + ":" + CFG.port));
    log("  mode:", CFG.mode, "| pvp:", CFG.pvp, "| max players:", CFG.maxPlayers, "| worlds:", CFG.dataDir);
  });
}
module.exports = { server, rooms, CFG, shutdown, getRoom };
