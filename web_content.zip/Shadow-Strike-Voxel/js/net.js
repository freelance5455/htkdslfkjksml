/* Shadow Strike Voxel — client networking.
   Every transport looks the same to the game: net.send(obj), net.onmessage(obj), net.onclose(), net.close().
   - local:  an in-process Room (single player, or the host of a Wi-Fi game)
   - ws:     WebSocket to the dedicated server (online or LAN with the Node server)
   - rtc:    direct phone-to-phone WebRTC with copy/paste pairing codes (no server, no internet) */
(function (root) {
  "use strict";

  function base() { return { onmessage: null, onclose: null, onopen: null, closed: false, kind: "", send() {}, close() {} }; }

  /* ---------- in-process loopback ---------- */
  function local(room) {
    const net = base(); net.kind = "local";
    const conn = {
      send(s) { queueMicrotask(() => { if (!net.closed && net.onmessage) net.onmessage(JSON.parse(s)); }); },
      close() { net.close(); },
    };
    room.attach(conn);
    net.send = (o) => queueMicrotask(() => { if (!net.closed) room.onMessage(conn, JSON.stringify(o)); });
    net.close = () => { if (net.closed) return; net.closed = true; room.onClose(conn); if (net.onclose) net.onclose("local"); };
    queueMicrotask(() => { if (net.onopen) net.onopen(); });
    return net;
  }

  /* ---------- WebSocket ---------- */
  function ws(url) {
    const net = base(); net.kind = "ws";
    let sock;
    try { sock = new WebSocket(url); } catch (e) { queueMicrotask(() => net.onclose && net.onclose("bad url")); return net; }
    let hb = 0;
    sock.onopen = () => { hb = setInterval(() => net.send({ t: "ping", c: Date.now() % 1e9 }), 4000); if (net.onopen) net.onopen(); };
    sock.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } if (net.onmessage) net.onmessage(m); };
    const done = (why) => { if (net.closed) return; net.closed = true; clearInterval(hb); if (net.onclose) net.onclose(why); };
    sock.onclose = () => done("closed"); sock.onerror = () => done("error");
    net.send = (o) => { if (sock.readyState === 1) sock.send(JSON.stringify(o)); };
    net.close = () => { try { sock.close(); } catch (e) { /* */ } done("closed"); };
    return net;
  }

  /* ---------- pairing codes ---------- */
  const b64 = (u8) => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); };
  const unb64 = (s) => { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  async function pack(obj) {
    const text = JSON.stringify(obj);
    if (typeof CompressionStream !== "undefined") {
      const cs = new CompressionStream("deflate-raw"), w = cs.writable.getWriter();
      w.write(new TextEncoder().encode(text)); w.close();
      return "S1." + b64(new Uint8Array(await new Response(cs.readable).arrayBuffer()));
    }
    return "S0." + b64(new TextEncoder().encode(text));
  }
  async function unpack(code) {
    code = String(code || "").replace(/\s+/g, "");
    const kind = code.slice(0, 3), data = unb64(code.slice(3));
    if (kind === "S1.") { const ds = new DecompressionStream("deflate-raw"), w = ds.writable.getWriter(); w.write(data); w.close(); return JSON.parse(new TextDecoder().decode(await new Response(ds.readable).arrayBuffer())); }
    if (kind === "S0.") return JSON.parse(new TextDecoder().decode(data));
    throw new Error("کد نامعتبر است");
  }
  function iceDone(pc, ms) {
    return new Promise((res) => {
      if (pc.iceGatheringState === "complete") return res();
      const t = setTimeout(res, ms || 3000);
      pc.addEventListener("icegatheringstatechange", () => { if (pc.iceGatheringState === "complete") { clearTimeout(t); res(); } });
    });
  }
  const RTC_CFG = { iceServers: [] }; // same-Wi-Fi only: host candidates are enough and nothing leaves the local network

  /** Host side: any number of guests can be invited; each one is a data channel attached to the room. */
  function rtcHost(room, onGuest) {
    const pending = new Map();
    return {
      async invite() {
        const pc = new RTCPeerConnection(RTC_CFG), dc = pc.createDataChannel("ss", { ordered: true }), id = Math.random().toString(36).slice(2, 7);
        const conn = { send(s) { if (dc.readyState === "open") try { dc.send(s); } catch (e) { /* */ } }, close() { try { dc.close(); pc.close(); } catch (e) { /* */ } } };
        dc.onopen = () => { room.attach(conn); pending.delete(id); if (onGuest) onGuest({ id, state: "connected" }); };
        dc.onmessage = (e) => room.onMessage(conn, e.data);
        dc.onclose = () => { room.onClose(conn); if (onGuest) onGuest({ id, state: "closed" }); };
        pc.onconnectionstatechange = () => { if (pc.connectionState === "failed" && onGuest) onGuest({ id, state: "failed" }); };
        await pc.setLocalDescription(await pc.createOffer());
        await iceDone(pc);
        pending.set(id, pc);
        return { id, code: await pack({ t: "o", sdp: pc.localDescription.sdp }) };
      },
      async accept(id, answerCode) {
        const pc = pending.get(id); if (!pc) throw new Error("این دعوت دیگر معتبر نیست");
        const a = await unpack(answerCode);
        if (a.t !== "a") throw new Error("این کد پاسخ نیست");
        await pc.setRemoteDescription({ type: "answer", sdp: a.sdp });
      },
      close() { pending.forEach((pc) => { try { pc.close(); } catch (e) { /* */ } }); pending.clear(); },
    };
  }

  /** Guest side: paste the host's code, get an answer code to send back; then the net object becomes usable. */
  async function rtcGuest(offerCode) {
    const o = await unpack(offerCode);
    if (o.t !== "o") throw new Error("این کد دعوت نیست");
    const pc = new RTCPeerConnection(RTC_CFG), net = base(); net.kind = "rtc";
    let dc = null;
    pc.ondatachannel = (e) => {
      dc = e.channel;
      dc.onopen = () => { if (net.onopen) net.onopen(); };
      dc.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (x) { return; } if (net.onmessage) net.onmessage(m); };
      dc.onclose = () => done("closed");
    };
    const done = (why) => { if (net.closed) return; net.closed = true; if (net.onclose) net.onclose(why); };
    pc.onconnectionstatechange = () => { if (pc.connectionState === "failed" || pc.connectionState === "disconnected" || pc.connectionState === "closed") done(pc.connectionState); };
    net.send = (m) => { if (dc && dc.readyState === "open") try { dc.send(JSON.stringify(m)); } catch (e) { /* */ } };
    net.close = () => { try { pc.close(); } catch (e) { /* */ } done("closed"); };
    await pc.setRemoteDescription({ type: "offer", sdp: o.sdp });
    await pc.setLocalDescription(await pc.createAnswer());
    await iceDone(pc);
    return { net, answerCode: await pack({ t: "a", sdp: pc.localDescription.sdp }) };
  }

  root.SSNet = { local, ws, rtcHost, rtcGuest, pack, unpack };
})(window);
