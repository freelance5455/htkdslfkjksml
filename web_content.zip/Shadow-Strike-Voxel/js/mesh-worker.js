/* Builds chunk geometry off the main thread so the game stays smooth on phones. */
importScripts("world.js", "mesher.js");
self.onmessage = (e) => {
  const m = e.data;
  if (m.ping) { self.postMessage({ pong: 1 }); return; }
  const r = self.SSMesher.meshFrom(m.cx, m.cz, m.nb), tr = [];
  if (r.opaque) tr.push(r.opaque.v.buffer, r.opaque.i.buffer);
  if (r.water) tr.push(r.water.v.buffer, r.water.i.buffer);
  self.postMessage({ key: m.key, version: m.version, opaque: r.opaque, water: r.water }, tr);
};
