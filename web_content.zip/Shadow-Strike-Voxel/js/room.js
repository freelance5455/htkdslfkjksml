/* Shadow Strike Voxel — the game room (server logic).
   The same class runs: in the browser for single-player and for a Wi-Fi host, and in Node for the
   dedicated online server. A "connection" is anything with send(string) and close(). */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory(require("./world.js"));
  else root.SSRoom = factory(root.SSWorld);
})(typeof self !== "undefined" ? self : this, function (SS) {
  "use strict";
  const { B, DEF, HT, SEA, World, moveEntity, rayBox, daylight } = SS;
  const VERSION = 1, EYE = 1.62, REACH = 9, MAXMSG = 65536;

  const MOBS = {
    shadow: { hp: 20, speed: 3.0, dmg: 3, w: 0.6, h: 1.8, cool: 1.0 },
    runner: { hp: 12, speed: 4.9, dmg: 2, w: 0.5, h: 1.5, cool: 0.8 },
    brute: { hp: 60, speed: 2.2, dmg: 6, w: 0.9, h: 2.4, cool: 1.4 },
  };
  const ANIMALS = { cow: { hp: 10, w: 0.9, h: 1.4, speed: 1.1 }, pig: { hp: 8, w: 0.8, h: 0.9, speed: 1.3 } };
  const WEAPONS = [{ dmg: 7, rate: 0.085 }, { dmg: 14, rate: 0.26 }];

  const r2 = (v) => Math.round(v * 100) / 100;
  const num = (v) => typeof v === "number" && isFinite(v);
  const cleanName = (s) => String(s == null ? "" : s).replace(/[\u0000-\u001f<>&"'`]/g, "").trim().slice(0, 16);
  const cleanText = (s) => String(s == null ? "" : s).replace(/[\u0000-\u001f<>]/g, "").trim().slice(0, 200);

  class Room {
    constructor(o) {
      o = o || {};
      this.world = new World(o.seed != null ? o.seed : Math.floor(Math.random() * 1e9));
      this.mode = o.mode === "creative" ? "creative" : "survival";
      this.pvp = !!o.pvp;
      this.name = o.name || "main";
      this.maxPlayers = o.maxPlayers || 8;
      this.dayLen = o.dayLen || 600;
      this.tod = num(o.tod) ? o.tod : 0.22;
      this.players = new Map(); this.conns = new Map(); this.enemies = new Map(); this.animals = new Map(); this.animalT = 0;
      this.nextId = 1; this.nextEnemy = 1; this.tickN = 0; this.clock = 0; this.dirty = false;
      this.adminId = null; this.saved = new Map(); this.spawnT = 0; this.pruneT = 0;
      this.log = o.log || (() => {});
    }

    /* ---------- connections ---------- */
    attach(conn) { this.conns.set(conn, null); return conn; }
    send(conn, obj) { try { conn.send(JSON.stringify(obj)); } catch (e) { /* closed */ } }
    broadcast(obj, except) {
      const s = JSON.stringify(obj);
      this.conns.forEach((p, c) => { if (p && c !== except) { try { c.send(s); } catch (e) { /* closed */ } } });
    }
    onClose(conn) {
      const p = this.conns.get(conn);
      this.conns.delete(conn);
      if (!p) return;
      this.players.delete(p.id);
      this.saved.set(p.name, { x: p.x, y: p.y, z: p.z });
      if (this.adminId === p.id) this.adminId = this.players.size ? this.players.keys().next().value : null;
      this.broadcast({ t: "leave", id: p.id, name: p.name });
      this.dirty = true;
    }
    onMessage(conn, raw) {
      if (typeof raw !== "string" || raw.length > MAXMSG) return;
      let m;
      try { m = JSON.parse(raw); } catch (e) { return; }
      if (!m || typeof m.t !== "string") return;
      const p = this.conns.get(conn);
      if (m.t === "join") return this.join(conn, m);
      if (m.t === "ping") return this.send(conn, { t: "pong", c: m.c });
      if (!p) return;
      switch (m.t) {
        case "s": return this.onState(p, m);
        case "block": return this.onBlock(p, m);
        case "shoot": return this.onShoot(p, m);
        case "chat": return this.onChat(p, m);
        case "ab": return this.onAbility(p, m);
        case "fall": return this.onFall(p, m);
        case "eat": return this.onEat(p);
        case "respawn": return this.respawn(p);
        default: return;
      }
    }

    /* ---------- joining ---------- */
    join(conn, m) {
      if (this.conns.get(conn)) return;
      if (this.players.size >= this.maxPlayers) { this.send(conn, { t: "full" }); try { conn.close(); } catch (e) { /* */ } return; }
      let name = cleanName(m.name) || "Player";
      const taken = new Set(Array.from(this.players.values()).map((p) => p.name));
      if (taken.has(name)) { let i = 2; while (taken.has(name.slice(0, 13) + i)) i++; name = name.slice(0, 13) + i; }
      const sp = this.saved.get(name) || this.world.spawnPoint();
      const id = this.nextId++;
      const p = { id, name, x: sp.x, y: sp.y, z: sp.z, yaw: 0, pitch: 0, f: 0, hp: 20, maxHp: 20, alive: true, kills: 0, deaths: 0, color: Math.floor(Math.random() * 360), lastShot: [0, 0], lastHurt: -99, tokens: 30, tokenT: this.clock, lastChat: -99, abCd: 0, conn, lastSeen: this.clock, lastStateT: this.clock };
      this.players.set(id, p); this.conns.set(conn, p);
      if (this.adminId == null) this.adminId = id;
      this.send(conn, { t: "welcome", v: VERSION, id, name, seed: this.world.seed, mode: this.mode, pvp: this.pvp, tod: this.tod, admin: this.adminId === id, x: sp.x, y: sp.y, z: sp.z, maxPlayers: this.maxPlayers, room: this.name, players: Array.from(this.players.values()).map((q) => ({ id: q.id, name: q.name, color: q.color, x: q.x, y: q.y, z: q.z, hp: q.hp })) });
      const edits = this.world.exportEdits(), flat = [];
      for (const e of edits) flat.push(e[0], e[1], e[2], e[3]);
      for (let i = 0; i <= flat.length; i += 4000) this.send(conn, { t: "edits", a: flat.slice(i, i + 4000), done: i + 4000 >= flat.length });
      this.broadcast({ t: "join", id, name, color: p.color }, conn);
      this.broadcast({ t: "chat", from: "", text: name + " وارد بازی شد" }, null);
      this.dirty = true;
    }

    /* ---------- player messages ---------- */
    onState(p, m) {
      if (!p.alive) return;
      if (!(num(m.x) && num(m.y) && num(m.z) && num(m.yaw) && num(m.pitch))) return;
      const dt = Math.max(0.05, this.clock - p.lastStateT);
      const dist = Math.hypot(m.x - p.x, m.y - p.y, m.z - p.z);
      if (dist > 14 + 30 * dt) { this.send(p.conn, { t: "tp", x: p.x, y: p.y, z: p.z }); return; }
      p.x = m.x; p.y = Math.max(-10, Math.min(HT + 40, m.y)); p.z = m.z; p.yaw = m.yaw; p.pitch = Math.max(-1.6, Math.min(1.6, m.pitch)); p.f = m.f | 0;
      p.lastStateT = this.clock; p.lastSeen = this.clock;
    }
    refill(p) { p.tokens = Math.min(30, p.tokens + (this.clock - p.tokenT) * 25); p.tokenT = this.clock; }
    onBlock(p, m) {
      if (!p.alive) return;
      const { x, y, z, id } = m;
      if (!(Number.isInteger(x) && Number.isInteger(y) && Number.isInteger(z) && Number.isInteger(id))) return;
      this.refill(p);
      if (p.tokens < 1) return this.reject(p, x, y, z);
      p.tokens -= 1;
      const reject = () => this.reject(p, x, y, z);
      if (y < 1 || y >= HT || Math.abs(x) > 1e7 || Math.abs(z) > 1e7 || !DEF[id] || id === B.BEDROCK || id === B.WATER) return reject();
      if (Math.hypot(x + 0.5 - p.x, y + 0.5 - (p.y + EYE), z + 0.5 - p.z) > REACH) return reject();
      const cur = this.world.get(x, y, z);
      if (id === B.AIR) { if (cur === B.AIR || cur === B.BEDROCK || cur === B.WATER) return reject(); }
      else {
        if (cur !== B.AIR && cur !== B.WATER) return reject();
        if (DEF[id].solid && this.entityInCell(x, y, z)) return reject();
      }
      this.world.set(x, y, z, id);
      this.dirty = true;
      this.broadcast({ t: "block", x, y, z, id, by: p.id });
    }
    reject(p, x, y, z) { if (p.conn) this.send(p.conn, { t: "reject", x, y, z, id: this.world.get(x, y, z) }); }
    entityInCell(x, y, z) {
      const hit = (e, w, h) => e.x + w / 2 > x && e.x - w / 2 < x + 1 && e.y + h > y && e.y < y + 1 && e.z + w / 2 > z && e.z - w / 2 < z + 1;
      for (const q of this.players.values()) if (q.alive && hit(q, 0.6, 1.8)) return true;
      for (const e of this.enemies.values()) { const d = MOBS[e.type]; if (hit(e, d.w, d.h)) return true; }
      for (const e of this.animals.values()) { const d = ANIMALS[e.type]; if (hit(e, d.w, d.h)) return true; }
      return false;
    }
    onShoot(p, m) {
      if (!p.alive || !Array.isArray(m.d) || !m.d.every(num)) return;
      const w = m.w === 1 ? 1 : 0, wp = WEAPONS[w];
      if (this.clock - p.lastShot[w] < wp.rate * 0.8) return;
      p.lastShot[w] = this.clock;
      let [dx, dy, dz] = m.d; const len = Math.hypot(dx, dy, dz);
      if (len < 1e-6) return; dx /= len; dy /= len; dz /= len;
      const ox = p.x, oy = p.y + EYE, oz = p.z, RANGE = 80;
      const wall = this.world.raycast(ox, oy, oz, dx, dy, dz, RANGE), wallD = wall ? wall.dist : RANGE;
      let best = null, bestD = wallD;
      const mobs = [...this.enemies.values(), ...this.animals.values()];
      mobs.forEach((e) => {
        const d = MOBS[e.type] || ANIMALS[e.type], hw = d.w / 2 + 0.05, t = rayBox(ox, oy, oz, dx, dy, dz, e.x - hw, e.y, e.z - hw, e.x + hw, e.y + d.h, e.z + hw);
        if (t >= 0 && t < bestD) { bestD = t; best = { kind: "enemy", e, t }; }
      });
      this.players.forEach((q) => {
        if (q === p || !q.alive) return;
        const t = rayBox(ox, oy, oz, dx, dy, dz, q.x - 0.35, q.y, q.z - 0.35, q.x + 0.35, q.y + 1.8, q.z + 0.35);
        if (t >= 0 && t < bestD) { bestD = t; best = { kind: "player", q, t }; }
      });
      const hx = ox + dx * bestD, hy = oy + dy * bestD, hz = oz + dz * bestD;
      this.broadcast({ t: "fx", k: "shot", id: p.id, w, ex: r2(hx), ey: r2(hy), ez: r2(hz), hit: best ? 1 : 0 }, p.conn);
      if (!best) { if (wall) this.send(p.conn, { t: "hit", k: "wall", x: r2(hx), y: r2(hy), z: r2(hz) }); return; }
      if (best.kind === "enemy") {
        const e = best.e, d = MOBS[e.type] || ANIMALS[e.type], head = hy > e.y + d.h - 0.45, dmg = wp.dmg * (head ? 1.6 : 1), animal = !!ANIMALS[e.type];
        e.hp -= dmg; e.hurt = this.clock;
        const dead = e.hp <= 0;
        this.send(p.conn, { t: "hit", k: "enemy", id: e.id, head: head ? 1 : 0, dead: dead ? 1 : 0, x: r2(hx), y: r2(hy), z: r2(hz) });
        if (dead) {
          this.enemies.delete(e.id); this.animals.delete(e.id); if (!animal) p.kills++;
          this.broadcast({ t: "kill", id: e.id, by: p.id, type: e.type, x: r2(e.x), y: r2(e.y), z: r2(e.z) });
          if (animal) this.send(p.conn, { t: "loot", item: 102, n: 1 + Math.floor(Math.random() * 2) });
          else this.send(p.conn, { t: "loot", ammo: e.type === "brute" ? 40 : 10 });
        }
      } else if (this.pvp && this.mode !== "creative") {
        const q = best.q, head = hy > q.y + 1.35, dmg = (wp.dmg * (head ? 1.5 : 1)) / 3;
        this.send(p.conn, { t: "hit", k: "player", id: q.id, head: head ? 1 : 0, x: r2(hx), y: r2(hy), z: r2(hz) });
        this.hurt(q, dmg, p.name);
      }
    }
    onChat(p, m) {
      const text = cleanText(m.text);
      if (!text || this.clock - p.lastChat < 0.6) return;
      p.lastChat = this.clock;
      if (text[0] === "/") return this.command(p, text);
      this.broadcast({ t: "chat", from: p.name, id: p.id, text });
    }
    onAbility(p, m) {
      if (!p.alive || m.k !== "phase" || this.clock < p.abCd) return;
      p.abCd = this.clock + 20;
      this.enemies.forEach((e) => { if (Math.hypot(e.x - p.x, e.z - p.z) < 30) e.slow = this.clock + 5; });
      this.broadcast({ t: "fx", k: "phase", id: p.id });
    }
    onEat(p) {
      if (!p.alive || p.hp >= p.maxHp || this.clock - (p.lastEat || -9) < 0.8) return;
      p.lastEat = this.clock; p.hp = Math.min(p.maxHp, p.hp + 4);
      this.send(p.conn, { t: "hp", hp: p.hp, dmg: 0 });
    }
    onFall(p, m) {
      if (!p.alive || !num(m.d)) return;
      const dmg = Math.min(20, Math.floor(m.d - 3));
      if (dmg > 0) this.hurt(p, dmg, "سقوط");
    }

    /* ---------- health ---------- */
    hurt(p, amount, src) {
      if (!p.alive || this.mode === "creative") return;
      p.hp = Math.max(0, p.hp - amount); p.lastHurt = this.clock;
      this.send(p.conn, { t: "hp", hp: p.hp, dmg: amount, src });
      if (p.hp <= 0) {
        p.alive = false; p.deaths++;
        this.broadcast({ t: "died", id: p.id, by: src });
        this.broadcast({ t: "chat", from: "", text: p.name + " کشته شد" + (src ? " (" + src + ")" : "") });
      }
    }
    respawn(p) {
      if (p.alive && p.hp > 0) return;
      const sp = this.world.spawnPoint();
      p.alive = true; p.hp = p.maxHp; p.x = sp.x; p.y = sp.y; p.z = sp.z; p.lastStateT = this.clock;
      this.send(p.conn, { t: "respawn", x: sp.x, y: sp.y, z: sp.z, hp: p.hp });
      this.broadcast({ t: "chat", from: "", text: p.name + " دوباره زنده شد" });
    }

    /* ---------- commands ---------- */
    command(p, text) {
      const [cmd, ...a] = text.slice(1).split(/\s+/), say = (s) => this.send(p.conn, { t: "chat", from: "", text: s });
      const admin = p.id === this.adminId;
      switch (cmd.toLowerCase()) {
        case "help": return say("/help /list /seed /tp نام" + (admin ? " /time day|night /mode creative|survival /pvp on|off /clear" : ""));
        case "seed": return say("seed: " + this.world.seed);
        case "list": return say(Array.from(this.players.values()).map((q) => q.name).join("، "));
        case "tp": { const q = Array.from(this.players.values()).find((x) => x.name === a.join(" ")); if (!q) return say("بازیکن پیدا نشد"); p.x = q.x + 1; p.y = q.y; p.z = q.z; this.send(p.conn, { t: "tp", x: p.x, y: p.y, z: p.z }); return; }
        default: break;
      }
      if (!admin) return say("این دستور فقط برای مدیر بازی است");
      switch (cmd.toLowerCase()) {
        case "time": { const v = a[0]; this.tod = v === "day" ? 0.25 : v === "night" ? 0.75 : Math.max(0, Math.min(0.999, Number(v) || 0.25)); return this.broadcast({ t: "chat", from: "", text: "زمان تغییر کرد" }); }
        case "mode": { if (a[0] !== "creative" && a[0] !== "survival") return say("/mode creative|survival"); this.mode = a[0]; if (this.mode === "creative") { this.enemies.clear(); this.animals.clear(); } this.players.forEach((q) => { q.hp = q.maxHp; }); return this.broadcast({ t: "mode", mode: this.mode }); }
        case "pvp": { this.pvp = a[0] === "on"; return this.broadcast({ t: "chat", from: "", text: "PvP " + (this.pvp ? "روشن" : "خاموش") }); }
        case "clear": { this.enemies.clear(); this.animals.clear(); return say("دشمنان پاک شدند"); }
        default: return say("دستور نامعتبر");
      }
    }

    /* ---------- simulation ---------- */
    isNight() { return daylight(this.tod) < 0.28; }
    tick(dt) {
      this.tickN++; this.clock += dt;
      this.tod = (this.tod + dt / this.dayLen) % 1;
      // drop idle connections that never talk (the transport also pings)
      this.conns.forEach((p, c) => { if (p && this.clock - p.lastSeen > 45) { try { c.close(); } catch (e) { /* */ } this.onClose(c); } });
      this.players.forEach((p) => { if (p.alive && p.hp < p.maxHp && this.clock - p.lastHurt > 6 && this.tickN % 80 === 0) p.hp = Math.min(p.maxHp, p.hp + 1), this.send(p.conn, { t: "hp", hp: p.hp, dmg: 0 }); });
      if (this.mode === "survival") { this.spawnEnemies(dt); this.moveEnemies(dt); this.spawnAnimals(dt); this.moveAnimals(dt); }
      this.pruneT += dt;
      if (this.pruneT > 15) { this.pruneT = 0; this.world.pruneFar(Array.from(this.players.values()), 7); }
      this.snapshot();
    }
    spawnEnemies(dt) {
      this.spawnT += dt;
      if (this.spawnT < 1.2) return;
      this.spawnT = 0;
      const night = this.isNight();
      this.players.forEach((p) => {
        if (!p.alive) return;
        let near = 0;
        this.enemies.forEach((e) => { if (Math.hypot(e.x - p.x, e.z - p.z) < 50) near++; });
        const cx = Math.floor(p.x) >> 4, cz = Math.floor(p.z) >> 4, ch = this.world.chunkAt(cx, cz, true);
        const underground = p.y < ch.top[(Math.floor(p.z) & 15) * 16 + (Math.floor(p.x) & 15)] - 8;
        const want = night ? 4 + this.players.size : underground ? 2 : 0;
        if (near >= want) return;
        const a = Math.random() * Math.PI * 2, d = 16 + Math.random() * 12, x = Math.floor(p.x + Math.cos(a) * d), z = Math.floor(p.z + Math.sin(a) * d);
        const gy = underground ? Math.floor(p.y) + 2 : this.world.groundY(x, z, HT - 1);
        let y = underground ? gy : gy + 1;
        if (underground) { while (y > 1 && !DEF[this.world.get(x, y - 1, z)].solid) y--; }
        if (this.world.get(x, y, z) !== B.AIR || this.world.get(x, y + 1, z) !== B.AIR || this.world.get(x, y - 1, z) === B.WATER) return;
        const roll = Math.random(), type = roll < 0.06 ? "brute" : roll < 0.32 ? "runner" : "shadow";
        const def = MOBS[type], id = this.nextEnemy++;
        this.enemies.set(id, { id, type, x: x + 0.5, y, z: z + 0.5, vx: 0, vy: 0, vz: 0, w: def.w, h: def.h, hp: def.hp, yaw: 0, cool: 0, slow: 0, wander: 0, hurt: -9 });
      });
    }
    moveEnemies(dt) {
      const day = daylight(this.tod) > 0.45;
      this.enemies.forEach((e, id) => {
        const def = MOBS[e.type];
        let target = null, td = 40;
        this.players.forEach((p) => { if (!p.alive) return; const d = Math.hypot(p.x - e.x, p.z - e.z); if (d < td) { td = d; target = p; } });
        if (!target) { e.t0 = (e.t0 || 0) + dt; if (e.t0 > 20) { this.enemies.delete(id); return; } } else e.t0 = 0;
        const far = !this.players.size || Array.from(this.players.values()).every((p) => Math.hypot(p.x - e.x, p.z - e.z) > 64);
        if (far) { this.enemies.delete(id); return; }
        const ch = this.world.chunkAt(Math.floor(e.x) >> 4, Math.floor(e.z) >> 4, true);
        if (day && e.y >= ch.top[(Math.floor(e.z) & 15) * 16 + (Math.floor(e.x) & 15)] && this.tickN % 20 === 0) { e.hp -= 3; if (e.hp <= 0) { this.enemies.delete(id); this.broadcast({ t: "kill", id, by: 0, type: e.type, x: r2(e.x), y: r2(e.y), z: r2(e.z) }); return; } }
        const slow = this.clock < e.slow ? 0.3 : 1;
        let vx = 0, vz = 0;
        if (target) {
          const dx = target.x - e.x, dz = target.z - e.z, d = Math.hypot(dx, dz) || 1;
          e.yaw = Math.atan2(dx, dz);
          if (d > 1.1) { vx = (dx / d) * def.speed * slow; vz = (dz / d) * def.speed * slow; }
          e.cool -= dt;
          if (d < 1.4 && Math.abs(target.y - e.y) < 1.8 && e.cool <= 0) { e.cool = def.cool; this.hurt(target, def.dmg, "سایه"); }
        } else {
          e.wander -= dt;
          if (e.wander <= 0) { e.wander = 2 + Math.random() * 3; e.wy = Math.random() * 6.28; e.go = Math.random() < 0.5; }
          if (e.go) { vx = Math.sin(e.wy) * def.speed * 0.3 * slow; vz = Math.cos(e.wy) * def.speed * 0.3 * slow; e.yaw = e.wy; }
        }
        e.vy -= 28 * dt; if (e.vy < -40) e.vy = -40;
        const r = moveEntity(this.world, e, vx * dt, e.vy * dt, vz * dt);
        if (r.onGround) { e.vy = 0; if ((r.hitX || r.hitZ) && (vx || vz)) e.vy = 8.2; }
        if (e.y < -5) this.enemies.delete(id);
      });
    }
    spawnAnimals(dt) {
      this.animalT += dt;
      if (this.animalT < 3 || this.animals.size >= 14 || daylight(this.tod) < 0.5) return;
      this.animalT = 0;
      this.players.forEach((p) => {
        if (!p.alive) return;
        let near = 0; this.animals.forEach((a) => { if (Math.hypot(a.x - p.x, a.z - p.z) < 60) near++; });
        if (near >= 4) return;
        const ang = Math.random() * Math.PI * 2, d = 14 + Math.random() * 18, x = Math.floor(p.x + Math.cos(ang) * d), z = Math.floor(p.z + Math.sin(ang) * d), gy = this.world.groundY(x, z, HT - 1);
        if (this.world.get(x, gy, z) !== B.GRASS || this.world.get(x, gy + 1, z) !== B.AIR || this.world.get(x, gy + 2, z) !== B.AIR) return;
        const type = Math.random() < 0.5 ? "cow" : "pig", def = ANIMALS[type], id = this.nextEnemy++;
        this.animals.set(id, { id, type, x: x + 0.5, y: gy + 1, z: z + 0.5, vx: 0, vy: 0, vz: 0, w: def.w, h: def.h, hp: def.hp, yaw: Math.random() * 6.28, wander: 0, go: false, wy: 0 });
      });
    }
    moveAnimals(dt) {
      this.animals.forEach((a, id) => {
        const def = ANIMALS[a.type];
        if (!this.players.size || Array.from(this.players.values()).every((p) => Math.hypot(p.x - a.x, p.z - a.z) > 70)) { this.animals.delete(id); return; }
        a.wander -= dt;
        if (a.wander <= 0) { a.wander = 2 + Math.random() * 4; a.wy = Math.random() * 6.28; a.go = Math.random() < 0.55; }
        let vx = 0, vz = 0;
        if (a.go) { vx = Math.sin(a.wy) * def.speed; vz = Math.cos(a.wy) * def.speed; a.yaw = a.wy + Math.PI; }
        a.vy -= 28 * dt; if (a.vy < -40) a.vy = -40;
        const r = moveEntity(this.world, a, vx * dt, a.vy * dt, vz * dt);
        if (r.onGround) { a.vy = 0; if ((r.hitX || r.hitZ) && a.go) a.vy = 7.5; }
        if (this.world.get(Math.floor(a.x), Math.floor(a.y), Math.floor(a.z)) === B.WATER || a.y < -5) this.animals.delete(id);
      });
    }
    snapshot() {
      if (!this.players.size) return;
      const p = [], e = [];
      this.players.forEach((q) => p.push([q.id, r2(q.x), r2(q.y), r2(q.z), r2(q.yaw), r2(q.pitch), q.alive ? q.f : 128, q.hp]));
      this.enemies.forEach((m) => e.push([m.id, m.type[0], r2(m.x), r2(m.y), r2(m.z), r2(m.yaw), Math.ceil(m.hp)]));
      this.animals.forEach((m) => e.push([m.id, m.type[0], r2(m.x), r2(m.y), r2(m.z), r2(m.yaw), Math.ceil(m.hp)]));
      this.broadcast({ t: "snap", n: this.tickN, tod: Math.round(this.tod * 10000) / 10000, p, e });
    }

    /* ---------- persistence ---------- */
    serialize() {
      const flat = [];
      for (const e of this.world.exportEdits()) flat.push(e[0], e[1], e[2], e[3]);
      const players = {};
      this.saved.forEach((v, k) => { players[k] = v; });
      this.players.forEach((q) => { players[q.name] = { x: r2(q.x), y: r2(q.y), z: r2(q.z) }; });
      return { v: VERSION, seed: this.world.seed, mode: this.mode, pvp: this.pvp, tod: this.tod, edits: flat, players };
    }
    static fromSave(o, opts) {
      const r = new Room(Object.assign({}, opts, { seed: o.seed, mode: o.mode, pvp: o.pvp, tod: o.tod }));
      const list = [];
      for (let i = 0; i + 3 < (o.edits || []).length; i += 4) list.push([o.edits[i], o.edits[i + 1], o.edits[i + 2], o.edits[i + 3]]);
      r.world.importEdits(list, true);
      Object.keys(o.players || {}).forEach((k) => r.saved.set(k, o.players[k]));
      return r;
    }
  }

  return { Room, MOBS, ANIMALS, WEAPONS, EYE, VERSION };
});
