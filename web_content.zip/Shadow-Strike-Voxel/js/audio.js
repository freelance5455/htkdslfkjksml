/* Shadow Strike Voxel — sound effects generated with WebAudio, so there is nothing to download. */
(function (root) {
  "use strict";
  let ctx = null, master = null, noiseBuf = null, volume = 0.7;

  function ensure() {
    if (ctx) { if (ctx.state === "suspended") ctx.resume(); return ctx; }
    const AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC(); master = ctx.createGain(); master.gain.value = volume; master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return ctx;
  }
  function noise(dur, vol, filterType, f0, f1, rate) {
    const c = ensure(); if (!c) return;
    const src = c.createBufferSource(), g = c.createGain(), f = c.createBiquadFilter(), t = c.currentTime;
    src.buffer = noiseBuf; src.playbackRate.value = rate || 1; src.loop = true;
    f.type = filterType; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(master); src.start(t); src.stop(t + dur + 0.02);
  }
  function tone(freq, dur, vol, type, slide) {
    const c = ensure(); if (!c) return;
    const o = c.createOscillator(), g = c.createGain(), t = c.currentTime;
    o.type = type || "sine"; o.frequency.setValueAtTime(freq, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  const SURF = { grass: [900, 0.9], stone: [1800, 1.2], sand: [700, 0.8], wood: [1100, 1.0], glass: [3500, 1.4], water: [500, 0.8] };
  const SOUNDS = {
    step(kind) { const s = SURF[kind] || SURF.stone; noise(0.07, 0.07, "bandpass", s[0], s[0] * 0.5, s[1]); },
    dig(kind) { const s = SURF[kind] || SURF.stone; noise(0.09, 0.12, "bandpass", s[0] * 1.3, s[0] * 0.6, s[1]); },
    brk(kind) { const s = SURF[kind] || SURF.stone; noise(0.22, 0.22, "lowpass", s[0] * 2, 120, s[1]); tone(110, 0.12, 0.08, "triangle", 60); if (kind === "glass") tone(2200, 0.18, 0.06, "sine", 900); },
    place(kind) { const s = SURF[kind] || SURF.stone; noise(0.08, 0.16, "bandpass", s[0], s[0] * 0.7, s[1]); tone(150, 0.07, 0.07, "square", 90); },
    rifle() { noise(0.05, 0.3, "highpass", 3500, 1800, 1.4); noise(0.16, 0.36, "lowpass", 5200, 240, 1); tone(150, 0.12, 0.26, "sawtooth", 38); tone(62, 0.16, 0.2, "sine", 34); setTimeout(() => noise(0.34, 0.1, "lowpass", 1500, 160, 0.7), 70); },
    pistol() { noise(0.04, 0.34, "highpass", 3800, 1800, 1.4); noise(0.22, 0.44, "lowpass", 4200, 170, 0.8); tone(125, 0.17, 0.3, "sawtooth", 38); tone(55, 0.2, 0.22, "sine", 30); setTimeout(() => noise(0.4, 0.12, "lowpass", 1300, 150, 0.6), 80); },
    boom(d) { const v = Math.max(0.12, 1 - (d || 60) / 150); noise(1.6, 0.9 * v, "lowpass", 900, 40, 0.5); tone(52, 1.3, 0.7 * v, "sine", 22); tone(90, 0.7, 0.3 * v, "sawtooth", 30); setTimeout(() => noise(1.2, 0.35 * v, "lowpass", 500, 60, 0.4), 220); },
    casing() { tone(4200 + Math.random() * 1200, 0.05, 0.035, "triangle", 2800); setTimeout(() => tone(3300 + Math.random() * 900, 0.04, 0.02, "triangle", 2400), 55); },
    reload() { noise(0.05, 0.1, "bandpass", 1600, 800, 1); tone(240, 0.05, 0.1, "square", 160); setTimeout(() => { noise(0.07, 0.16, "bandpass", 900, 500, 0.9); tone(130, 0.06, 0.12, "square", 90); }, 560); setTimeout(() => { tone(1400, 0.03, 0.08, "square", 900); noise(0.06, 0.14, "bandpass", 2200, 1200, 1.2); }, 1180); setTimeout(() => tone(700, 0.05, 0.1, "square", 420), 1450); },
    empty() { tone(300, 0.04, 0.07, "square"); },
    hit() { tone(1500, 0.05, 0.12, "square", 1100); },
    headshot() { tone(2200, 0.09, 0.16, "square", 1500); tone(900, 0.12, 0.1, "triangle", 500); },
    kill() { tone(700, 0.22, 0.16, "sawtooth", 140); },
    hurt() { tone(120, 0.22, 0.3, "sawtooth", 55); noise(0.12, 0.2, "lowpass", 900, 200, 1); },
    thud() { tone(70, 0.2, 0.3, "sine", 40); noise(0.1, 0.18, "lowpass", 400, 80, 1); },
    growl() { tone(75, 0.5, 0.1, "sawtooth", 50); },
    phase() { tone(220, 0.8, 0.18, "sine", 900); tone(330, 0.8, 0.1, "triangle", 1300); },
    scan() { tone(1200, 0.5, 0.12, "sine", 300); },
    click() { tone(1100, 0.03, 0.06, "square"); },
    splash() { noise(0.25, 0.2, "bandpass", 1200, 400, 1); },
    pickup() { tone(880, 0.07, 0.08, "sine", 1300); },
    chat() { tone(1000, 0.06, 0.06, "sine", 1400); },
  };
  root.SSAudio = {
    unlock: ensure,
    setVolume(v) { volume = Math.max(0, Math.min(1, v)); if (master) master.gain.value = volume; },
    play(name, arg) { try { if (SOUNDS[name] && volume > 0) SOUNDS[name](arg); } catch (e) { /* audio is optional */ } },
  };
})(window);
