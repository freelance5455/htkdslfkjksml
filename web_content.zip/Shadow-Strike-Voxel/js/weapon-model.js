/* Shadow Strike Voxel — first-person weapon + arms.
   A detailed M4-style carbine (suppressor, holographic sight, rails, magazine) and a service pistol, built from boxes.
   Includes ADS (aim down sights), recoil, sway, sprint pose and a full reload animation. */
(function (root) {
  "use strict";
  const R = root.SSRenderer, xform = R.xform, xformZ = R.xformZ, mul = R.mulAffine;
  const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a, b) => Math.max(a, Math.min(b, v)), ease = (t) => t * t * (3 - 2 * t);
  const gray = (v) => { v = v * 1.12 + 0.015; return [v, v * 1.01, v * 1.05]; };
  const GLOVE = [0.1, 0.11, 0.1], GLOVE2 = [0.15, 0.16, 0.14], SLEEVE = [0.2, 0.22, 0.15], SLEEVE2 = [0.14, 0.16, 0.11];

  function mk(fn) { const P = []; fn((b, c, l, a, tag) => P.push({ b, c, l: l == null ? 1.1 : l, a: a == null ? 1 : a, tag: tag || "" })); return P; }

  /* ---------------- rifle (muzzle points to -z, +y up, +x right) ---------------- */
  const RIFLE = mk((add) => {
    add([-0.030, -0.030, -0.17, 0.030, 0.046, 0.13], gray(0.2));              // upper receiver
    add([0.030, 0.0, -0.025, 0.036, 0.034, 0.075], gray(0.13));                // ejection port cover
    add([0.030, 0.006, 0.07, 0.041, 0.028, 0.1], gray(0.15));                  // forward assist
    add([-0.029, -0.082, -0.125, 0.029, -0.030, 0.115], gray(0.16));           // lower receiver
    add([-0.025, -0.1, -0.09, 0.025, -0.08, -0.008], gray(0.15));              // magwell
    add([-0.003, -0.1, -0.052, 0.003, -0.082, 0.012], gray(0.1));              // trigger guard bottom
    add([-0.003, -0.095, -0.056, 0.003, -0.07, -0.049], gray(0.1));            // trigger guard front
    add([-0.003, -0.085, -0.02, 0.003, -0.058, -0.012], gray(0.06));           // trigger
    add([0.029, -0.062, 0.03, 0.036, -0.05, 0.05], gray(0.07));                // selector
    add([-0.036, -0.036, -0.60, 0.036, 0.038, -0.17], gray(0.15));             // handguard
    for (let i = 0; i < 9; i++) { const z = -0.585 + i * 0.043; add([0.036, -0.012, z, 0.0375, 0.014, z + 0.025], gray(0.04)); add([-0.0375, -0.012, z, -0.036, 0.014, z + 0.025], gray(0.04)); add([-0.012, -0.0375, z, 0.012, -0.036, z + 0.025], gray(0.04)); }
    add([-0.014, 0.038, -0.60, 0.014, 0.05, 0.13], gray(0.12));                // top rail
    for (let i = 0; i < 24; i++) { const z = -0.595 + i * 0.0302; add([-0.0145, 0.05, z, 0.0145, 0.054, z + 0.015], gray(0.06)); }
    add([-0.014, -0.014, -0.665, 0.014, 0.014, -0.60], gray(0.1));             // barrel
    add([-0.021, -0.004, -0.668, 0.021, 0.03, -0.625], gray(0.14));            // gas block
    add([-0.004, 0.03, -0.652, 0.004, 0.082, -0.644], gray(0.08));             // front sight post
    add([-0.014, 0.03, -0.656, 0.014, 0.048, -0.64], gray(0.1));               // sight base
    add([-0.031, -0.031, -1.02, 0.031, 0.031, -0.665], gray(0.12), 1.05, 1, "sup");  // suppressor (box 1 of 2)
    add([-0.0225, -0.0225, -1.0, 0.0225, 0.0225, -0.69], gray(0.12), 1.05, 1, "sup45"); // suppressor rotated 45 deg
    for (const z of [-0.74, -0.84, -0.94]) add([-0.0335, -0.0335, z, 0.0335, 0.0335, z + 0.02], gray(0.07));
    add([-0.011, -0.011, -1.024, 0.011, 0.011, -1.018], [0.01, 0.01, 0.012], 1);   // bore
    // holographic sight
    add([-0.02, 0.054, -0.06, 0.02, 0.064, 0.075], gray(0.09));
    add([-0.036, 0.064, -0.058, -0.028, 0.118, 0.078], gray(0.11));
    add([0.028, 0.064, -0.058, 0.036, 0.118, 0.078], gray(0.11));
    add([-0.036, 0.112, -0.058, 0.036, 0.122, 0.078], gray(0.1));
    add([-0.036, 0.064, 0.07, 0.036, 0.074, 0.078], gray(0.1));
    add([-0.028, 0.069, -0.06, 0.028, 0.112, -0.056], [0.1, 0.2, 0.3], 1.0, 0.28);   // front glass
    add([-0.0016, 0.0805, -0.032, 0.0016, 0.0835, -0.029], [1, 0.08, 0.04], 3.4);    // reticle dot
    for (let i = 0; i < 12; i++) { const a = i / 12 * 6.2832, rx = Math.cos(a) * 0.0125, ry = Math.sin(a) * 0.0125; add([rx - 0.0007, 0.082 + ry - 0.0007, -0.032, rx + 0.0007, 0.082 + ry + 0.0007, -0.029], [1, 0.08, 0.04], 3.0); }
    // stock
    add([-0.017, -0.034, 0.13, 0.017, 0.002, 0.32], gray(0.12));
    add([-0.031, -0.072, 0.2, 0.031, 0.022, 0.35], gray(0.1));
    add([-0.025, 0.022, 0.215, 0.025, 0.036, 0.34], gray(0.09));
    add([-0.031, -0.078, 0.35, 0.031, 0.026, 0.375], gray(0.05));
    add([-0.008, 0.05, 0.105, 0.008, 0.058, 0.15], gray(0.1), 1.1, 1, "bolt");   // charging handle
    add([-0.016, 0.044, 0.12, 0.016, 0.052, 0.13], gray(0.08), 1.1, 1, "bolt");
    // weapon light on the right rail
    add([0.036, -0.022, -0.5, 0.054, 0.016, -0.41], gray(0.09));
    add([0.054, -0.012, -0.495, 0.0565, 0.006, -0.425], [0.9, 0.95, 1], 2.0);
    add([0.036, -0.006, -0.355, 0.045, 0.01, -0.33], gray(0.06));
    // magazine (30 rd) + base plate
    add([-0.02, -0.215, -0.082, 0.02, -0.08, -0.018], gray(0.14), 1.1, 1, "mag");
    add([-0.021, -0.225, -0.088, 0.021, -0.215, -0.012], gray(0.06), 1.1, 1, "mag");
    for (let i = 0; i < 4; i++) add([0.02, -0.2 + i * 0.03, -0.075, 0.0215, -0.19 + i * 0.03, -0.03], gray(0.07), 1.1, 1, "mag");
  });

  /* ---------------- pistol ---------------- */
  const PISTOL = mk((add) => {
    add([-0.0145, -0.008, -0.2, 0.0145, 0.034, 0.04], gray(0.17));              // slide
    for (let i = 0; i < 6; i++) add([-0.0155, 0.0, 0.0 + i * 0.006, 0.0155, 0.03, 0.0035 + i * 0.006], gray(0.08));
    add([-0.013, -0.036, -0.16, 0.013, -0.008, 0.04], gray(0.12));              // frame
    add([-0.003, -0.07, -0.05, 0.003, -0.036, -0.044], gray(0.09));             // trigger guard
    add([-0.003, -0.07, -0.05, 0.003, -0.064, 0.0], gray(0.09));
    add([-0.003, -0.056, -0.015, 0.003, -0.036, -0.005], gray(0.06));           // trigger
    add([-0.008, 0.006, -0.218, 0.008, 0.026, -0.2], gray(0.07));               // barrel tip
    add([-0.003, 0.034, -0.192, 0.003, 0.044, -0.185], gray(0.06));             // front sight
    add([-0.014, 0.034, 0.025, -0.006, 0.045, 0.036], gray(0.06));              // rear sight
    add([0.006, 0.034, 0.025, 0.014, 0.045, 0.036], gray(0.06));
    add([-0.0008, 0.0385, -0.189, 0.0008, 0.0405, -0.186], [0.5, 1, 0.6], 2.2); // tritium dot
    add([-0.014, -0.12, 0.0, 0.014, -0.034, 0.05], gray(0.1), 1.1, 1, "grip");  // grip (tilted separately)
    add([-0.012, -0.135, 0.0, 0.012, -0.12, 0.052], gray(0.06), 1.1, 1, "grip");
  });

  function box(hand, M, b, c, l, a) { hand.box(M, b[0], b[1], b[2], b[3], b[4], b[5], c[0], c[1], c[2], l, a); }
  function drawParts(hand, M, parts, o) {
    const rot45 = mul(M, xformZ(0, 0, 0, 0.7854));
    for (const p of parts) {
      if (p.tag === "mag" && o.magM) box(hand, o.magM, p.b, p.c, p.l, p.a);
      else if (p.tag === "bolt" && o.boltZ) box(hand, mul(M, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, o.boltZ]), p.b, p.c, p.l, p.a);
      else if (p.tag === "sup45") box(hand, rot45, p.b, p.c, p.l, p.a);
      else if (p.tag === "grip" && o.gripM) box(hand, o.gripM, p.b, p.c, p.l, p.a);
      else box(hand, M, p.b, p.c, p.l, p.a);
    }
  }
  const gl = (hand, M, b, c, l) => box(hand, M, b, c || GLOVE, l || 1.0, 1);

  /** Arm = sleeve with rolled cuff, starting at the wrist (0,0,0) and running along +z (towards the player). */
  function arm(hand, A, watch) {
    box(hand, A, [-0.046, -0.042, 0, 0.046, 0.042, 0.62], SLEEVE, 1.0);
    box(hand, A, [-0.049, -0.045, 0.0, 0.049, 0.045, 0.045], SLEEVE2, 1.0);
    box(hand, A, [-0.03, -0.03, -0.045, 0.03, 0.03, 0.0], GLOVE, 1.0);   // glove cuff
    if (watch) {
      box(hand, A, [-0.049, -0.045, 0.065, 0.049, 0.045, 0.118], [0.05, 0.05, 0.055], 1.0);          // strap
      box(hand, A, [-0.032, 0.045, 0.068, 0.032, 0.056, 0.115], [0.09, 0.1, 0.11], 1.0);               // case
      box(hand, A, [-0.025, 0.056, 0.074, 0.025, 0.0585, 0.109], [0.04, 0.05, 0.06], 1.0);            // dial
      box(hand, A, [-0.0015, 0.0585, 0.078, 0.0015, 0.0605, 0.093], [0.7, 0.95, 0.75], 1.8);          // hands (lume)
      for (const [x, z] of [[0, 0.076], [0, 0.107], [-0.022, 0.0915], [0.022, 0.0915]]) box(hand, A, [x - 0.0015, 0.0585, z - 0.0015, x + 0.0015, 0.0595, z + 0.0015], [0.7, 0.95, 0.75], 1.8);
      box(hand, A, [0.032, 0.05, 0.088, 0.039, 0.054, 0.098], [0.12, 0.12, 0.13], 1.0);               // crown
    }
  }

  /** Draws the weapon in slot `w` (0 rifle, 1 pistol). o: {t, bob, kick, flash, ads, reload (0..1 or -1), sprint, speed, moving, crouch} */
  function drawWeapon(hand, w, o) {
    const rifle = w === 0, k = ease(o.ads), sp = o.sprint * (1 - k);
    const hip = rifle ? [0.2, -0.225, -0.6] : [0.14, -0.16, -0.42], ads = rifle ? [0.0, -0.0818, -0.46] : [0.0, -0.0415, -0.32];
    const sway = Math.sin(o.t * 1.25) * 0.0016 * (1 - k * 0.7), sway2 = Math.cos(o.t * 0.9) * 0.0012;
    let x = lerp(hip[0], ads[0], k) + o.bx * (1 - k * 0.8) + sway, y = lerp(hip[1], ads[1], k) + o.by * (1 - k * 0.8) + sway2, z = lerp(hip[2], ads[2], k);
    let yaw = lerp(rifle ? 0.075 : 0.05, 0, k), pitch = 0, roll = 0;
    z += o.kick * (rifle ? 0.04 : 0.05) * (1 - k * 0.45); pitch += o.kick * (rifle ? 0.05 : 0.09) * (1 - k * 0.4); roll += o.kick * 0.012 * Math.sin(o.t * 90);
    x += sp * -0.06; y += sp * -0.085; z += sp * 0.03; yaw += sp * -0.85; roll += sp * 0.42; pitch += sp * 0.12;
    const rl = o.reload; let magDrop = 0, magIn = 0, lhK = 0, bolt = 0;
    if (rl >= 0) {
      const tilt = rl < 0.15 ? ease(rl / 0.15) : rl > 0.88 ? 1 - ease((rl - 0.88) / 0.12) : 1;
      pitch += -0.22 * tilt; roll += -0.4 * tilt; x += -0.03 * tilt; y += 0.01 * tilt; yaw += 0.08 * tilt;
      if (rl > 0.17 && rl < 0.34) magDrop = ease((rl - 0.17) / 0.17);
      else if (rl >= 0.34 && rl < 0.5) magDrop = 1;
      else if (rl >= 0.5 && rl < 0.7) magDrop = 1 - ease((rl - 0.5) / 0.2);
      lhK = rl < 0.15 ? ease(rl / 0.15) : rl < 0.78 ? 1 : 1 - ease((rl - 0.78) / 0.14); if (rl > 0.92) lhK = 0;
      if (rl > 0.78 && rl < 0.92) bolt = Math.sin((rl - 0.78) / 0.14 * Math.PI) * 0.05;
    }
    const M = mul(xform(x, y, z, yaw, pitch), xformZ(0, 0, 0, roll));
    const opt = {};
    if (rifle) {
      const mv = (rl >= 0 && rl >= 0.5 && rl < 0.7) ? -(1 - magDrop) * 0 : 0; void mv;
      opt.magM = mul(M, xform(0, -0.28 * magDrop, 0.0 + 0.0, 0, 0.0)); opt.boltZ = bolt;
      if (rl >= 0 && rl > 0.34 && rl < 0.5) opt.magM = null;     // magazine is out: only the empty well is visible
      if (opt.magM === null) opt.magM = mul(M, xform(0, -0.9, 0, 0, 0));
    } else opt.gripM = mul(M, xform(0, -0.034, 0.0, 0, 0.16));
    drawParts(hand, M, rifle ? RIFLE : PISTOL, opt);
    if (o.flash > 0) {      // muzzle flash: crossed glowing blades + core
      const fz = rifle ? -1.04 : -0.225, s = 0.6 + Math.random() * 0.8, r = Math.random() * 3.14;
      const F = mul(M, xformZ(0, 0, fz, r));
      hand.box(F, -0.07 * s, -0.006, -0.1 * s, 0.07 * s, 0.006, 0.01, 1, 0.72, 0.28, 3.6); hand.box(F, -0.006, -0.07 * s, -0.1 * s, 0.006, 0.07 * s, 0.01, 1, 0.72, 0.28, 3.6);
      hand.box(F, -0.016 * s, -0.016 * s, -0.16 * s, 0.016 * s, 0.016 * s, 0.01, 1, 0.92, 0.6, 4.0);
    }
    /* ---- hands ---- */
    if (rifle) {
      // left (support) hand on the handguard, reaching to the magazine while reloading
      const lz = lerp(-0.32, -0.05, lhK), ly = lerp(-0.0, -0.19 - (rl >= 0 ? -0.28 * magDrop : 0), lhK), lx = lerp(0, -0.015, lhK);
      const H = mul(M, [1, 0, 0, lx, 0, 1, 0, ly, 0, 0, 1, lz + 0.32]);
      gl(hand, H, [-0.038, -0.082, -0.43, 0.038, -0.036, -0.27], GLOVE);
      for (let i = 0; i < 4; i++) { const zz = -0.43 + i * 0.037; gl(hand, H, [0.034, -0.078, zz, 0.052, 0.006, zz + 0.033], i % 2 ? GLOVE : GLOVE2); }
      gl(hand, H, [-0.052, -0.034, -0.4, -0.034, 0.016, -0.31], GLOVE2);
      gl(hand, H, [-0.034, -0.082, -0.27, 0.034, -0.03, -0.22], GLOVE);
      const LA = mul(H, mul(xform(-0.0, -0.058, -0.22, -0.46, 0.5), [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0]));
      arm(hand, LA, true);
      // right hand on the pistol grip, finger on the trigger
      const G = mul(M, xform(0, 0, 0, 0, 0));
      gl(hand, G, [-0.032, -0.15, 0.062, 0.03, -0.074, 0.118], GLOVE);
      for (let i = 0; i < 3; i++) gl(hand, G, [-0.028, -0.152 + i * 0.027, 0.0, 0.03, -0.13 + i * 0.027, 0.066], i === 1 ? GLOVE2 : GLOVE);
      gl(hand, G, [-0.006, -0.094, -0.036, 0.006, -0.078, 0.018], GLOVE2);
      gl(hand, G, [-0.048, -0.118, 0.052, -0.03, -0.088, 0.112], GLOVE2);
      gl(hand, G, [-0.03, -0.1, 0.1, 0.03, -0.06, 0.15], GLOVE);
      const RA = mul(G, xform(0.0, -0.105, 0.14, 0.34, 0.72));
      arm(hand, RA, false);
    } else {
      const G = mul(M, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0]);
      gl(hand, G, [-0.022, -0.125, 0.022, 0.024, -0.042, 0.075], GLOVE);
      for (let i = 0; i < 3; i++) gl(hand, G, [-0.02, -0.122 + i * 0.026, -0.012, 0.022, -0.1 + i * 0.026, 0.03], GLOVE2);
      gl(hand, G, [-0.005, -0.075, -0.045, 0.005, -0.06, 0.0], GLOVE2);
      gl(hand, G, [-0.036, -0.09, 0.025, -0.022, -0.056, 0.07], GLOVE2);
      arm(hand, mul(G, xform(0, -0.08, 0.1, 0.32, 0.7)), false);
      // left hand cupping the grip from below
      gl(hand, G, [-0.05, -0.135, -0.03, 0.0, -0.1, 0.05], GLOVE); gl(hand, G, [-0.04, -0.12, -0.07, -0.01, -0.07, -0.02], GLOVE2);
      arm(hand, mul(G, xform(-0.05, -0.13, 0.04, -0.5, 0.65)), true);
    }
  }

  /** Bare/block-holding right arm (used for tools, blocks and food). */
  function drawArm(hand, o) {
    const M = xform(0.22 + o.bx, -0.2 + o.by - o.swing * 0.04, -0.5 - o.swing * 0.1, -0.1 - o.swing * 0.2, -0.1 - o.swing * 0.55);
    box(hand, M, [-0.04, -0.04, -0.08, 0.04, 0.04, 0.02], GLOVE, 1);
    for (let i = 0; i < 4; i++) box(hand, M, [-0.036 + i * 0.019, -0.03, -0.12, -0.02 + i * 0.019, 0.03, -0.075], i % 2 ? GLOVE : GLOVE2, 1);
    arm(hand, mul(M, xform(0, 0, 0.02, 0, 0)), false);
    return M;
  }

  root.SSWeapon = { drawWeapon, drawArm, box };
})(window);
