/* Shadow Strike Voxel — tactical HUD: rotating minimap, compass strip, ammo panel, score/rank bar, hit markers, dynamic crosshair. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const SG = window.SSGame, G = SG.G, SS = window.SSWorld, { B, DEF } = SS, inp = SG.inp;
  const N = 72, RAD = 30, SCALE = 2, SPB = (RAD * 2) / N;
  const mm = $("mm"), mmx = mm.getContext("2d"), buf = document.createElement("canvas"); buf.width = buf.height = N;
  const bx = buf.getContext("2d"), img = bx.createImageData(N, N);
  const cmp = $("cmp"), cx = cmp.getContext("2d");
  let colTab = null, mmT = 0, cmpT = 0, lastAmmo = "", lastScore = -1, hitT = 0;
  const fmt = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

  function colors() {
    colTab = new Array(256).fill(null);
    for (let id = 1; id < DEF.length; id++) { if (!DEF[id]) continue; const c = SG.blockColor(id); colTab[id] = [c[0] * 255, c[1] * 255, c[2] * 255]; }
    colTab[B.WATER] = [40, 90, 150]; colTab[B.LEAVES] = [40, 92, 36];
  }

  function drawMinimap() {
    const me = G.me, w = G.world; if (!me || !w) return;
    if (!colTab) colors();
    const sy = Math.sin(me.yaw), cy = Math.cos(me.yaw), d = img.data;
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const dx = (i + 0.5 - N / 2) * SPB, dy = (j + 0.5 - N / 2) * SPB, o = (j * N + i) * 4;
      if (dx * dx + dy * dy > RAD * RAD) { d[o + 3] = 0; continue; }
      const wx = me.x + cy * dx + sy * dy, wz = me.z - sy * dx + cy * dy, ix = Math.floor(wx), iz = Math.floor(wz);
      const ch = w.chunks.get((ix >> 4) + "," + (iz >> 4));
      if (!ch) { d[o] = 18; d[o + 1] = 22; d[o + 2] = 28; d[o + 3] = 255; continue; }
      const lx = ix & 15, lz = iz & 15, ty = ch.top[lz * 16 + lx], id = ch.data[(ty * 16 + lz) * 16 + lx], c = colTab[id] || [90, 90, 90];
      const sh = Math.max(0.5, Math.min(1.25, 0.82 + (ty - me.y) * 0.03));
      d[o] = c[0] * sh * 0.85; d[o + 1] = c[1] * sh * 0.9; d[o + 2] = c[2] * sh * 0.85 + 6; d[o + 3] = 255;
    }
    bx.putImageData(img, 0, 0);
    mmx.clearRect(0, 0, N * SCALE, N * SCALE); mmx.imageSmoothingEnabled = false; mmx.drawImage(buf, 0, 0, N * SCALE, N * SCALE);
    const half = N * SCALE / 2, toPx = (wx, wz) => { const ox = wx - me.x, oz = wz - me.z; return [half + (ox * cy - oz * sy) / SPB * SCALE, half + (ox * sy + oz * cy) / SPB * SCALE]; };
    const dot = (p, col, r) => { if (Math.hypot(p[0] - half, p[1] - half) > half - 4) return; mmx.fillStyle = col; mmx.fillRect(p[0] - r, p[1] - r, r * 2, r * 2); };
    G.remote.forEach((e) => { if (e.px != null) dot(toPx(e.px, e.pz), "#4fd3ff", 3); });
    G.enemies.forEach((e) => { if (e.type === "cow" || e.type === "pig" || !e.buf.length) return; const b = e.buf[e.buf.length - 1]; if (Math.hypot(b.x - me.x, b.z - me.z) < 26 || G.abil.scanOn > 0) dot(toPx(b.x, b.z), "#ff3b3b", 3); });
    // view cone + player arrow
    mmx.save(); mmx.translate(half, half);
    const g = mmx.createRadialGradient(0, 0, 0, 0, 0, half); g.addColorStop(0, "rgba(255,255,255,.28)"); g.addColorStop(1, "rgba(255,255,255,0)");
    mmx.fillStyle = g; mmx.beginPath(); mmx.moveTo(0, 0); mmx.arc(0, 0, half, -Math.PI / 2 - 0.62, -Math.PI / 2 + 0.62); mmx.closePath(); mmx.fill();
    mmx.fillStyle = "#ffd23d"; mmx.strokeStyle = "#000"; mmx.lineWidth = 1.5; mmx.beginPath(); mmx.moveTo(0, -8); mmx.lineTo(6, 7); mmx.lineTo(0, 3); mmx.lineTo(-6, 7); mmx.closePath(); mmx.stroke(); mmx.fill();
    // north marker
    const nx = Math.sin(me.yaw) * (half - 9), ny = -Math.cos(me.yaw) * (half - 9);
    mmx.fillStyle = "rgba(0,0,0,.6)"; mmx.beginPath(); mmx.arc(nx, ny, 8, 0, 6.3); mmx.fill(); mmx.fillStyle = "#ff5a4a"; mmx.font = "bold 12px Arial"; mmx.textAlign = "center"; mmx.textBaseline = "middle"; mmx.fillText("N", nx, ny + 1);
    mmx.restore();
    $("mm-label").textContent = "XZ " + Math.round(me.x) + " · " + Math.round(me.z);
  }

  function drawCompass() {
    const me = G.me; if (!me) return;
    const W = cmp.width, H = cmp.height, hd = ((-me.yaw * 180 / Math.PI) % 360 + 360) % 360, ppd = W / 110;
    cx.clearRect(0, 0, W, H); cx.textAlign = "center"; cx.textBaseline = "alphabetic";
    const names = { 0: "N", 45: "NE", 90: "E", 135: "SE", 180: "S", 225: "SW", 270: "W", 315: "NW" };
    for (let a = -60; a <= 60; a++) {
      let ang = Math.round(hd) + a; const real = ((ang % 360) + 360) % 360, x = W / 2 + (ang - hd) * ppd;
      if (real % 5) continue;
      const major = real % 15 === 0, fade = 1 - Math.abs(x - W / 2) / (W / 2);
      cx.strokeStyle = "rgba(255,255,255," + (0.75 * fade) + ")"; cx.lineWidth = major ? 2 : 1; cx.beginPath(); cx.moveTo(x, H - 4); cx.lineTo(x, H - (major ? 15 : 9)); cx.stroke();
      if (real % 45 === 0) { cx.fillStyle = real === 0 ? "rgba(255,90,70," + fade + ")" : "rgba(255,255,255," + fade + ")"; cx.font = "bold 15px Arial"; cx.fillText(names[real], x, H - 19); }
      else if (real % 15 === 0) { cx.fillStyle = "rgba(200,215,230," + fade * 0.8 + ")"; cx.font = "11px Arial"; cx.fillText(String(real), x, H - 19); }
    }
    cx.fillStyle = "#ffd23d"; cx.beginPath(); cx.moveTo(W / 2 - 6, 2); cx.lineTo(W / 2 + 6, 2); cx.lineTo(W / 2, 11); cx.fill();
  }

  function updateAmmo() {
    const it = G.hotbar[G.sel], el = $("ammo"); let html = "";
    if (it && it.k === "w") {
      const a = G.ammo[it.w], name = it.w === 0 ? "M4A1 · SD" : "P-9", mode = it.w === 0 ? "AUTO" : "SEMI", cap = a.cap, reloading = G.reload > 0;
      let pips = ""; for (let i = 0; i < cap; i++) pips += '<i class="' + (i < a.mag && !reloading ? "on" : "") + '"></i>';
      html = '<div class="an">' + name + '<b>' + mode + "</b></div><div class=\"am\"><span class=\"" + (a.mag <= Math.ceil(cap * 0.25) ? "low" : "") + '">' + (reloading ? "--" : a.mag) + '</span><em>/</em><span class="rs">' + (G.gameMode === "creative" ? "∞" : a.res) + '</span></div><div class="ap">' + pips + "</div>" + (reloading ? '<div class="ar">RELOADING</div>' : (a.mag === 0 && a.res === 0 && G.gameMode !== "creative" ? '<div class="ar">NO AMMO</div>' : ""));
    }
    if (html !== lastAmmo) { el.innerHTML = html; lastAmmo = html; }
  }

  function updateScore() {
    if (G.score === lastScore) return; lastScore = G.score;
    const rank = Math.min(20, 1 + Math.floor(G.score / 1500)), into = rank >= 20 ? 1 : (G.score % 1500) / 1500;
    $("sc-num").textContent = fmt(G.score); $("sc-rank").textContent = rank; $("sc-next").textContent = Math.min(20, rank + 1); $("sc-fill").style.width = Math.round(into * 100) + "%";
  }

  function pop(text, cls) {
    const d = document.createElement("div"); d.className = "pop " + (cls || ""); d.textContent = text; $("pops").appendChild(d); setTimeout(() => d.remove(), 1100);
    while ($("pops").children.length > 5) $("pops").firstChild.remove();
  }
  function addScore(n, label) { G.score = (G.score || 0) + n; pop("+" + n + (label ? "  " + label : ""), label ? "gold" : ""); }
  function hitmarker(kill, head) { const h = $("hitm"); h.className = "show" + (kill ? " kill" : "") + (head ? " head" : ""); hitT = kill ? 0.3 : 0.16; }

  function update(dt) {
    if (!G.me) return;
    const playing = G.screen === "play", it = G.hotbar[G.sel], gun = it && it.k === "w";
    if (playing) {
      mmT -= dt; if (mmT <= 0) { mmT = 0.13; drawMinimap(); }
      cmpT -= dt; if (cmpT <= 0) { cmpT = 0.05; drawCompass(); }
      updateAmmo(); updateScore();
    }
    // crosshair
    const c = $("cross"), ads = G.ads > 0.5;
    c.classList.toggle("gun", !!gun); c.classList.toggle("off", !!gun && ads);
    if (gun) { const spread = 5 + (G.me.moving ? 6 : 0) + (G.hand.kick * 10) + (inp.sprint ? 4 : 0); c.style.setProperty("--gap", spread * (1 - G.ads * 0.7) + "px"); }
    if (hitT > 0) { hitT -= dt; if (hitT <= 0) $("hitm").className = ""; }
    $("hud").classList.toggle("low", G.alive && G.hp <= 6 && G.gameMode !== "creative");
    const pl = $("t-place"); if (pl) { const t = gun ? "هدف" : "بلوک"; if (pl.textContent !== t) pl.textContent = t; }
  }

  window.SSHud = { update, addScore, pop, hitmarker, drawMinimap };
})();
