/* Shadow Strike Voxel — block textures drawn by code, so the game has no image downloads and works offline. */
(function (root) {
  "use strict";
  const TILE = 16, COLS = 8, ROWS = 4;

  function rng(seed) { let a = seed | 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /** Each painter gets (put(x,y,r,g,b,a), rand) for a 16x16 tile. */
  const clamp = (v) => Math.max(0, Math.min(255, v | 0));
  function noisy(put, rand, c, amp) { for (let y = 0; y < TILE; y++) for (let x = 0; x < TILE; x++) { const n = (rand() - 0.5) * amp; put(x, y, c[0] + n, c[1] + n, c[2] + n, 255); } }
  const painters = {
    0(put, r) { noisy(put, r, [92, 156, 58], 36); for (let i = 0; i < 18; i++) put((r() * 16) | 0, (r() * 16) | 0, 70, 130, 45, 255); },
    1(put, r) { noisy(put, r, [134, 96, 67], 30); for (let x = 0; x < 16; x++) { const d = 3 + ((r() * 3) | 0); for (let y = 0; y < d; y++) { const n = (r() - 0.5) * 30; put(x, y, 92 + n, 156 + n, 58 + n, 255); } } },
    2(put, r) { noisy(put, r, [134, 96, 67], 34); for (let i = 0; i < 14; i++) put((r() * 16) | 0, (r() * 16) | 0, 110, 76, 52, 255); },
    3(put, r) { noisy(put, r, [126, 126, 128], 28); for (let i = 0; i < 10; i++) put((r() * 16) | 0, (r() * 16) | 0, 104, 104, 106, 255); },
    4(put, r) { noisy(put, r, [221, 208, 160], 20); },
    5(put, r) { for (let x = 0; x < 16; x++) { const s = (r() - 0.5) * 40; for (let y = 0; y < 16; y++) { const n = (r() - 0.5) * 14 + s; put(x, y, 104 + n, 82 + n, 52 + n, 255); } } },
    6(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const d = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5)), ring = (d | 0) % 3 === 0 ? -22 : 0, n = (r() - 0.5) * 12; const edge = d > 6.5; put(x, y, (edge ? 104 : 178) + n + ring, (edge ? 82 : 142) + n + ring, (edge ? 52 : 88) + n + ring, 255); } },
    7(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const hole = r() < 0.17, n = (r() - 0.5) * 50; put(x, y, 48 + n * 0.5, 120 + n, 38 + n * 0.5, hole ? 0 : 255); } },
    8(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const line = y % 4 === 3 ? -34 : 0, n = (r() - 0.5) * 14; put(x, y, 172 + n + line, 136 + n + line, 86 + n + line, 255); } },
    9(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const edge = x === 0 || y === 0 || x === 15 || y === 15, hi = (x + y === 5 || x + y === 6 || x + y === 11 || x + y === 12) && x > 1 && y > 1 && x < 8 && y < 8; put(x, y, 200, 235, 245, edge || hi ? 255 : 0); } },
    10(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const row = (y / 4) | 0, off = row % 2 ? 4 : 0, mort = y % 4 === 3 || (x + off) % 8 === 7, n = (r() - 0.5) * 22; mort ? put(x, y, 170, 168, 160, 255) : put(x, y, 152 + n, 66 + n * 0.5, 52 + n * 0.5, 255); } },
    11(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const n = (r() - 0.5) * 24; put(x, y, 48 + n * 0.4, 106 + n * 0.7, 210 + n, 190); } },
    12(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const blob = Math.sin(x * 1.3 + (y >> 2) * 2.1) * Math.cos(y * 1.1 + (x >> 2)) > 0.25 ? -26 : 0, n = (r() - 0.5) * 22; put(x, y, 122 + n + blob, 122 + n + blob, 124 + n + blob, 255); } },
    13(put, r) { noisy(put, r, [243, 247, 250], 12); },
    14(put, r) { noisy(put, r, [134, 96, 67], 28); for (let x = 0; x < 16; x++) { const d = 4 + ((r() * 2) | 0); for (let y = 0; y < d; y++) { const n = (r() - 0.5) * 10; put(x, y, 243 + n, 247 + n, 250, 255); } } },
    15(put, r) { noisy(put, r, [54, 54, 58], 40); },
    16(put, r) { noisy(put, r, [126, 126, 128], 26); for (let b = 0; b < 5; b++) { const cx = 2 + ((r() * 12) | 0), cy = 2 + ((r() * 12) | 0); for (let dy = 0; dy < 3; dy++) for (let dx = 0; dx < 3; dx++) if (r() < 0.8) put(cx + dx - 1, cy + dy - 1, 28, 28, 30, 255); } },
    17(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const grid = x % 8 === 0 || y % 8 === 0, n = (r() - 0.5) * 16; grid ? put(x, y, 150, 110, 50, 255) : put(x, y, 255 + n, 226 + n, 140 + n, 255); } },
    18(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const band = y % 5 === 4 ? -22 : 0, n = (r() - 0.5) * 12; put(x, y, 214 + n + band, 196 + n + band, 148 + n + band, 255); } },
    19(put, r) { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const peb = ((x * 7 + y * 13) % 5 === 0) ? -34 : (r() - 0.5) * 30; put(x, y, 132 + peb, 128 + peb, 124 + peb, 255); } },
  };

  function build() {
    const c = document.createElement("canvas");
    c.width = COLS * TILE; c.height = ROWS * TILE;
    const g = c.getContext("2d", { willReadFrequently: true }), img = g.createImageData(c.width, c.height);
    Object.keys(painters).forEach((k) => {
      const idx = Number(k), tx = idx % COLS, ty = (idx / COLS) | 0, r = rng(1000 + idx * 977);
      painters[idx]((x, y, R, G, Bc, A) => { const o = ((ty * TILE + y) * c.width + tx * TILE + x) * 4; img.data[o] = clamp(R); img.data[o + 1] = clamp(G); img.data[o + 2] = clamp(Bc); img.data[o + 3] = clamp(A); }, r);
    });
    g.putImageData(img, 0, 0);
    return c;
  }

  /** Average colour of a tile, used for particles and the held block. */
  function tileColor(canvas, idx) {
    const g = canvas.getContext("2d"), tx = idx % COLS, ty = (idx / COLS) | 0, d = g.getImageData(tx * TILE, ty * TILE, TILE, TILE).data;
    let r = 0, gg = 0, b = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 128) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; n++; }
    return n ? [r / n / 255, gg / n / 255, b / n / 255] : [0.8, 0.9, 1];
  }

  /** Isometric cube icon for the hotbar / inventory. */
  function icon(canvas, tiles, size) {
    const out = document.createElement("canvas"); out.width = out.height = size;
    const g = out.getContext("2d"); g.imageSmoothingEnabled = false;
    const S = size, top = [S * 0.5, S * 0.06], right = [S * 0.93, S * 0.28], left = [S * 0.07, S * 0.28], bottom = [S * 0.5, S * 0.5], h = S * 0.44;
    const draw = (tile, ox, oy, ux, uy, vx, vy, dark) => {
      const tx = (tile % COLS) * TILE, ty = ((tile / COLS) | 0) * TILE;
      g.save(); g.setTransform(ux / TILE, uy / TILE, vx / TILE, vy / TILE, ox, oy);
      g.drawImage(canvas, tx, ty, TILE, TILE, 0, 0, TILE, TILE);
      if (dark) { g.fillStyle = "rgba(0,0,0," + dark + ")"; g.fillRect(0, 0, TILE, TILE); }
      g.restore();
    };
    draw(tiles[0], top[0], top[1], right[0] - top[0], right[1] - top[1], left[0] - top[0], left[1] - top[1], 0);
    draw(tiles[2], left[0], left[1], bottom[0] - left[0], bottom[1] - left[1], 0, h, 0.28);
    draw(tiles[2], bottom[0], bottom[1], right[0] - bottom[0], right[1] - bottom[1], 0, h, 0.5);
    return out;
  }

  root.SSAtlas = { TILE, COLS, ROWS, build, tileColor, icon };
})(window);
