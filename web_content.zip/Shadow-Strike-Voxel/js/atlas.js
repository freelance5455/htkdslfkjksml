/* Shadow Strike Voxel — block textures drawn by code (32x32 per block), so the game has no image downloads and works offline. */
(function (root) {
  "use strict";
  const TILE = 32, COLS = 8, ROWS = 4;

  function rng(seed) { let a = seed | 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const clamp = (v) => Math.max(0, Math.min(255, v | 0));
  const lerp = (a, b, t) => a + (b - a) * t;
  const sm = (t) => t * t * (3 - 2 * t);

  /** Tileable value noise: `cells` lattice cells across the tile. Returns f(x,y) in 0..1 for x,y in 0..TILE. */
  function grid(r, cells) {
    const g = new Float32Array(cells * cells); for (let i = 0; i < g.length; i++) g[i] = r();
    return (x, y) => {
      const fx = (x / TILE) * cells, fy = (y / TILE) * cells, x0 = Math.floor(fx), y0 = Math.floor(fy), tx = sm(fx - x0), ty = sm(fy - y0);
      const a = g[(y0 % cells) * cells + (x0 % cells)], b = g[(y0 % cells) * cells + ((x0 + 1) % cells)], c = g[(((y0 + 1) % cells) * cells) + (x0 % cells)], d = g[(((y0 + 1) % cells) * cells) + ((x0 + 1) % cells)];
      return lerp(lerp(a, b, tx), lerp(c, d, tx), ty);
    };
  }
  /** Fractal noise made of 3 octaves of tileable noise. */
  function fbm(r) { const a = grid(r, 4), b = grid(r, 8), c = grid(r, 16); return (x, y) => a(x, y) * 0.5 + b(x, y) * 0.3 + c(x, y) * 0.2; }
  /** Tileable voronoi: returns {d1,d2,id} for a point. */
  function voronoi(r, n) {
    const pts = []; for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) pts.push([(i + 0.15 + r() * 0.7) * TILE / n, (j + 0.15 + r() * 0.7) * TILE / n, r()]);
    return (x, y) => {
      let d1 = 1e9, d2 = 1e9, id = 0;
      for (let k = 0; k < pts.length; k++) for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
        const px = pts[k][0] + ox * TILE, py = pts[k][1] + oy * TILE, d = Math.hypot(x - px, y - py);
        if (d < d1) { d2 = d1; d1 = d; id = pts[k][2]; } else if (d < d2) d2 = d;
      }
      return { d1, d2, id };
    };
  }
  const each = (f) => { for (let y = 0; y < TILE; y++) for (let x = 0; x < TILE; x++) f(x, y); };

  const painters = {
    0(put, r) { const n = fbm(r), n2 = grid(r, 16); each((x, y) => { const v = n(x, y), b = n2(x, y); put(x, y, 70 + v * 55 + b * 20, 118 + v * 70 + b * 26, 40 + v * 30, 255); }); for (let i = 0; i < 70; i++) { const x = (r() * TILE) | 0, y = (r() * TILE) | 0, l = 1 + ((r() * 3) | 0), lt = r() < 0.5; for (let k = 0; k < l; k++) put(x, (y + k) % TILE, lt ? 130 : 52, lt ? 178 : 96, lt ? 62 : 32, 255); } },
    1(put, r) { const n = fbm(r), n2 = fbm(r); each((x, y) => { const v = n(x, y); put(x, y, 112 + v * 50, 80 + v * 38, 52 + v * 26, 255); }); for (let i = 0; i < 18; i++) put((r() * TILE) | 0, (r() * TILE) | 0, 84, 60, 40, 255); for (let x = 0; x < TILE; x++) { const d = 7 + Math.floor(n2(x, 0) * 7); for (let y = 0; y < d; y++) { const v = n2(x, y * 2); put(x, y, 66 + v * 60, 118 + v * 66, 38 + v * 28, 255); } } },
    2(put, r) { const n = fbm(r); each((x, y) => { const v = n(x, y); put(x, y, 108 + v * 56, 76 + v * 40, 50 + v * 28, 255); }); for (let i = 0; i < 26; i++) { const x = (r() * TILE) | 0, y = (r() * TILE) | 0, c = r() < 0.5 ? 78 : 150; put(x, y, c, c * 0.82, c * 0.65, 255); put((x + 1) % TILE, y, c, c * 0.82, c * 0.65, 255); } },
    3(put, r) { const n = fbm(r), v = voronoi(r, 3); each((x, y) => { const q = v(x, y), e = q.d2 - q.d1, g = 118 + n(x, y) * 44 + q.id * 10; put(x, y, g, g, g + 3, 255); if (e < 0.9) put(x, y, 74, 74, 78, 255); }); },
    4(put, r) { const n = fbm(r), n2 = grid(r, 16); each((x, y) => { const v = n(x, y), g = n2(x, y); put(x, y, 196 + v * 36 + g * 14, 182 + v * 34 + g * 12, 134 + v * 28 + g * 8, 255); }); },
    5(put, r) { const n = grid(r, 8), n2 = grid(r, 16); each((x, y) => { const s = n(x * 0.25, y * 2.2), v = n2(x, y * 0.5); put(x, y, 82 + s * 52 + v * 14, 60 + s * 38 + v * 10, 38 + s * 26, 255); if (((x * 5 + ((r() * 3) | 0)) % 9) === 0) put(x, y, 46, 32, 20, 255); }); },
    6(put, r) { const n = grid(r, 8); each((x, y) => { const dx = x - 15.5, dy = y - 15.5, d = Math.max(Math.abs(dx), Math.abs(dy)), edge = d > 13.5, ring = Math.sin(Math.hypot(dx, dy) * 1.45 + n(x, y) * 3) * 0.5 + 0.5; put(x, y, edge ? 78 + ring * 20 : 170 + ring * 30, edge ? 58 + ring * 14 : 134 + ring * 24, edge ? 36 : 84 + ring * 14, 255); }); },
    7(put, r) { const n = fbm(r); each((x, y) => { const v = n(x, y), hole = r() < 0.2 || (v > 0.72 && r() < 0.5); put(x, y, 36 + v * 40, 96 + v * 80, 28 + v * 24, hole ? 0 : 255); }); },
    8(put, r) { each((x, y) => { const row = (y / 8) | 0, bo = (row * 11) % 32, g = grid(r, 4); void g; const line = y % 8 === 0 || y % 8 === 7 ? 1 : 0, grain = Math.sin((x + bo) * 0.5 + Math.sin(y * 0.8) * 1.4) * 0.5 + 0.5, k = 0.8 + grain * 0.2 + (r() - 0.5) * 0.06; put(x, y, (line ? 118 : 176) * k, (line ? 90 : 138) * k, (line ? 54 : 86) * k, 255); }); for (let row = 0; row < 4; row++) for (const nx of [3, 28]) put(nx, row * 8 + 3, 70, 66, 62, 255); },
    9(put, r) { each((x, y) => { const edge = x < 2 || y < 2 || x > 29 || y > 29, hi = (((x + y) % 14) < 2 && x > 3 && y > 3 && x < 17 && y < 17) || ((x + y) % 14 === 8 && x > 18 && x < 28 && y > 18 && y < 28); put(x, y, edge ? 168 : 214, edge ? 206 : 240, edge ? 226 : 250, edge || hi ? 255 : 0); }); },
    10(put, r) { const n = fbm(r); each((x, y) => { const row = (y / 8) | 0, off = row % 2 ? 8 : 0, bx = (x + off) % 16, mort = y % 8 === 7 || bx === 15, v = n(x, y), k = 0.78 + r() * 0.2; if (mort) put(x, y, 166 + v * 20, 162 + v * 20, 152 + v * 16, 255); else { const t = ((row * 7 + Math.floor((x + off) / 16) * 13) % 5) * 0.045; put(x, y, (150 + v * 44) * (k + t), (66 + v * 24) * (k + t * 0.6), (50 + v * 18) * (k + t * 0.5), 255); } }); },
    11(put, r) { const n = fbm(r), n2 = grid(r, 8); each((x, y) => { const v = n(x, y), w = Math.abs(n2(x, y) - 0.5); put(x, y, 34 + v * 30 + (w < 0.05 ? 40 : 0), 92 + v * 56 + (w < 0.05 ? 50 : 0), 168 + v * 50 + (w < 0.05 ? 40 : 0), 196); }); },
    12(put, r) { const v = voronoi(r, 4), n = fbm(r); each((x, y) => { const q = v(x, y), e = q.d2 - q.d1; let g = 104 + q.id * 40 + n(x, y) * 26 - Math.max(0, 3 - q.d1) * 0; if (e < 1.6) g = 58 + e * 12; put(x, y, g, g, g + 2, 255); }); },
    13(put, r) { const n = fbm(r); each((x, y) => { const v = n(x, y); put(x, y, 232 + v * 20, 238 + v * 16, 244 + v * 10, 255); }); },
    14(put, r) { const n = fbm(r), n2 = fbm(r); each((x, y) => { const v = n(x, y); put(x, y, 112 + v * 46, 80 + v * 34, 52 + v * 24, 255); }); for (let x = 0; x < TILE; x++) { const d = 8 + Math.floor(n2(x, 0) * 5); for (let y = 0; y < d; y++) { const v = n2(x, y); put(x, y, 232 + v * 20, 238 + v * 14, 246, 255); } } },
    15(put, r) { const n = fbm(r); each((x, y) => { const v = n(x, y), g = 30 + v * 40 + (r() < 0.1 ? 14 : 0); put(x, y, g, g, g + 4, 255); }); },
    16(put, r) { const n = fbm(r), v = voronoi(r, 3); each((x, y) => { const q = v(x, y), g = 116 + n(x, y) * 44 + q.id * 10; put(x, y, g, g, g + 3, 255); if (q.d2 - q.d1 < 0.9) put(x, y, 74, 74, 78, 255); }); for (let b = 0; b < 6; b++) { const cx = 4 + ((r() * 24) | 0), cy = 4 + ((r() * 24) | 0), rr = 2 + r() * 2.4; for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) if (Math.hypot(dx, dy) < rr) { const k = 18 + r() * 14; put((cx + dx + 32) % 32, (cy + dy + 32) % 32, k, k, k + 3, 255); } } },
    17(put, r) { each((x, y) => { const cx = x - 15.5, cy = y - 15.5, d = Math.hypot(cx, cy), frame = x % 16 < 2 || y % 16 < 2 || x % 16 > 13 || y % 16 > 13, core = Math.max(0, 1 - d / 15); if (frame) put(x, y, 150, 104, 40, 255); else put(x, y, 255, 214 + core * 40, 120 + core * 100 + (r() - 0.5) * 14, 255); }); },
    18(put, r) { const n = fbm(r); each((x, y) => { const band = Math.sin(y * 0.55 + n(x, y) * 5) * 0.5 + 0.5, v = n(x, y); put(x, y, 198 + band * 18 + v * 14, 178 + band * 16 + v * 14, 128 + band * 12 + v * 10, 255); }); },
    19(put, r) { const v = voronoi(r, 5), n = fbm(r); each((x, y) => { const q = v(x, y), g = 96 + q.id * 70 + n(x, y) * 22, e = q.d2 - q.d1; put(x, y, e < 1.2 ? 62 : g, e < 1.2 ? 60 : g - 3, e < 1.2 ? 58 : g - 8, 255); }); },
    /* ----- war-torn city set ----- */
    20(put, r) { const n = fbm(r), s = grid(r, 16), st = grid(r, 3); each((x, y) => { const v = n(x, y), g = 138 + v * 38 + (s(x, y) - 0.5) * 22 - Math.max(0, st(x, y) - 0.62) * 70; put(x, y, g, g - 1, g - 6, 255); if (r() < 0.04) put(x, y, g - 38, g - 38, g - 40, 255); }); },
    21(put, r) { const n = fbm(r), s = grid(r, 16), st = grid(r, 3); each((x, y) => { const v = n(x, y), g = 128 + v * 34 + (s(x, y) - 0.5) * 20 - Math.max(0, st(x, y) - 0.55) * 90; put(x, y, g, g - 1, g - 6, 255); }); for (let c = 0; c < 4; c++) { let x = r() * TILE, y = r() * TILE, a = r() * 6.28; for (let k = 0; k < 18; k++) { put(Math.floor(x + TILE) % TILE, Math.floor(y + TILE) % TILE, 36, 34, 34, 255); a += (r() - 0.5) * 1.1; x += Math.cos(a); y += Math.sin(a); } } for (let b = 0; b < 1; b++) { const x = (r() * 28) | 0, y = (r() * 28) | 0; for (let d = 0; d < 4; d++) for (let e = 0; e < 3; e++) put(x + d, y + e, 96 + r() * 30, 58 + r() * 14, 40, 255); } },
    22(put, r) { const n = fbm(r); each((x, y) => { const v = n(x, y), g = 52 + v * 22 + (r() < 0.12 ? 22 : 0) - (r() < 0.05 ? 18 : 0); put(x, y, g, g, g + 2, 255); }); },
    23(put, r) { const n = fbm(r); each((x, y) => { const v = n(x, y), g = 52 + v * 22 + (r() < 0.12 ? 22 : 0); const line = x >= 14 && x <= 17 && (y % 16) < 10; if (line) put(x, y, 222 + v * 14 - (r() < 0.2 ? 40 : 0), 186 + v * 12 - (r() < 0.2 ? 40 : 0), 52, 255); else put(x, y, g, g, g + 2, 255); }); },
    24(put, r) { const v = voronoi(r, 4), n = fbm(r); each((x, y) => { const q = v(x, y), e = q.d2 - q.d1, t = q.id; let c; if (t < 0.28) c = [118 + n(x, y) * 34, 74 + n(x, y) * 18, 62]; else if (t < 0.7) c = [128 + n(x, y) * 36, 126 + n(x, y) * 34, 120 + n(x, y) * 30]; else c = [84 + n(x, y) * 28, 80 + n(x, y) * 26, 76 + n(x, y) * 24]; const k = e < 1.4 ? 0.3 : 1; put(x, y, c[0] * k, c[1] * k, c[2] * k, 255); }); },
    25(put, r) { const n = fbm(r); each((x, y) => { const row = (y / 8) | 0, bx = (x + (row % 2 ? 8 : 0)) % 16, seam = y % 8 === 0 || bx === 0, bulge = Math.sin((y % 8) / 8 * 3.14) * 0.5 + 0.5, weave = ((x + y) % 3 === 0 ? 6 : 0), v = n(x, y); const k = seam ? 0.55 : 0.82 + bulge * 0.22; put(x, y, (176 + v * 30 + weave) * k, (156 + v * 28 + weave) * k, (108 + v * 22) * k, 255); }); },
    26(put, r) { const n = grid(r, 8); each((x, y) => { const frame = x < 3 || y < 3 || x > 28 || y > 28, brace = Math.abs(x - y) < 2 || Math.abs(x + y - 31) < 2, g = Math.sin(x * 0.7 + n(x, y) * 4) * 0.5 + 0.5; if (frame || brace) put(x, y, 70 + g * 18, 82 + g * 20, 52 + g * 12, 255); else put(x, y, 84 + g * 22, 100 + g * 26, 62 + g * 16, 255); }); for (const [x, y] of [[4, 4], [27, 4], [4, 27], [27, 27]]) put(x, y, 30, 30, 28, 255); for (let i = 8; i < 22; i++) put(i, 15, 210, 210, 190, 255); },
    27(put, r) { each((x, y) => { const cx = x - 15.5, cy = y - 15.5, d = Math.hypot(cx, cy) / 15, flick = r() * 0.25; if (d > 1) put(x, y, 40, 40, 44, 255); else if (d > 0.82) put(x, y, 150, 70, 30, 255); else put(x, y, 255, 120 + (1 - d) * 140 + flick * 40, 20 + (1 - d) * 130, 255); }); },
    28(put, r) { const n = grid(r, 8); each((x, y) => { const rib = y % 10 < 2 || y > 29 || y < 2, v = n(x, y * 0.5), rust = v > 0.62 ? 1 : 0; const base = rib ? 78 : 112; if (rust) put(x, y, 124 + v * 40, 62 + v * 24, 34, 255); else put(x, y, base + v * 24, base * 0.45 + v * 14 + 14, base * 0.32 + 12, 255); }); },
    29(put, r) { const n = grid(r, 16); each((x, y) => { const v = n(x * 3, y * 0.5), g = 86 + v * 34; let c = [g * 0.92, g * 0.98, g * 1.08]; if (x % 16 < 1 || y % 16 < 1) c = [38, 42, 48]; put(x, y, c[0], c[1], c[2], 255); }); for (const [x, y] of [[3, 3], [12, 3], [19, 3], [28, 3], [3, 19], [12, 19], [19, 19], [28, 19]]) { put(x, y, 150, 156, 164, 255); put(x + 1, y, 40, 40, 44, 255); } },
    30(put, r) { const n = fbm(r), s = grid(r, 8); each((x, y) => { const v = n(x, y), g = 40 + v * 34; put(x, y, g, g * 0.94, g * 0.88, 255); if (s(x, y) > 0.8 && r() < 0.12) put(x, y, 70 + r() * 30, 34, 22, 255); }); },
    31(put, r) { const n = fbm(r), s = grid(r, 16); each((x, y) => { const joint = x % 16 === 0 || y % 16 === 0, v = n(x, y), g = (joint ? 100 : 170) + v * 30 + (s(x, y) - 0.5) * 12; put(x, y, g, g - 2, g - 8, 255); }); },
  };

  function build() {
    const c = document.createElement("canvas");
    c.width = COLS * TILE; c.height = ROWS * TILE;
    const g = c.getContext("2d", { willReadFrequently: true }), img = g.createImageData(c.width, c.height);
    Object.keys(painters).forEach((k) => {
      const idx = Number(k), tx = idx % COLS, ty = (idx / COLS) | 0, r = rng(1000 + idx * 977);
      painters[idx]((x, y, R, G, Bc, A) => { const o = ((ty * TILE + y) * c.width + tx * TILE + x) * 4; img.data[o] = clamp(R); img.data[o + 1] = clamp(G); img.data[o + 2] = clamp(Bc); img.data[o + 3] = clamp(A); }, r);
    });
    g.putImageData(img, 0, 0);
    return c;
  }

  /** Average colour of a tile, used for particles and the held block. */
  function tileColor(canvas, idx) {
    const g = canvas.getContext("2d"), tx = idx % COLS, ty = (idx / COLS) | 0, d = g.getImageData(tx * TILE, ty * TILE, TILE, TILE).data;
    let r = 0, gg = 0, b = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 128) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; n++; }
    return n ? [r / n / 255, gg / n / 255, b / n / 255] : [0.8, 0.9, 1];
  }

  /** Isometric cube icon for the hotbar / inventory. */
  function icon(canvas, tiles, size) {
    const out = document.createElement("canvas"); out.width = out.height = size;
    const g = out.getContext("2d"); g.imageSmoothingEnabled = false;
    const S = size, top = [S * 0.5, S * 0.06], right = [S * 0.93, S * 0.28], left = [S * 0.07, S * 0.28], bottom = [S * 0.5, S * 0.5], h = S * 0.44;
    const draw = (tile, ox, oy, ux, uy, vx, vy, dark) => {
      const tx = (tile % COLS) * TILE, ty = ((tile / COLS) | 0) * TILE;
      g.save(); g.setTransform(ux / TILE, uy / TILE, vx / TILE, vy / TILE, ox, oy);
      g.drawImage(canvas, tx, ty, TILE, TILE, 0, 0, TILE, TILE);
      if (dark) { g.fillStyle = "rgba(0,0,0," + dark + ")"; g.fillRect(0, 0, TILE, TILE); }
      g.restore();
    };
    draw(tiles[0], top[0], top[1], right[0] - top[0], right[1] - top[1], left[0] - top[0], left[1] - top[1], 0);
    draw(tiles[2], left[0], left[1], bottom[0] - left[0], bottom[1] - left[1], 0, h, 0.28);
    draw(tiles[2], bottom[0], bottom[1], right[0] - bottom[0], right[1] - bottom[1], 0, h, 0.5);
    return out;
  }

  root.SSAtlas = { TILE, COLS, ROWS, build, tileColor, icon };
})(window);
