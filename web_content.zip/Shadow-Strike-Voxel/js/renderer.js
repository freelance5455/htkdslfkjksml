/* Shadow Strike Voxel — WebGL2 renderer (no external libraries, works offline).
   Everything is drawn camera-relative so far-away coordinates keep full precision. */
(function (root) {
  "use strict";
  const SS = root.SSWorld, { CH, HT } = SS;

  /* ---------- small matrix helpers (column-major) ---------- */
  const M = {
    perspective(fov, asp, n, f) { const t = 1 / Math.tan(fov / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = (2 * f * n) / (n - f); return o; },
    mul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
    /** Rotation-only view matrix looking along yaw/pitch (translation is handled by drawing camera-relative). */
    viewRot(yaw, pitch) {
      const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
      const f = [-sy * cp, sp, -cy * cp], r = [cy, 0, -sy], u = [sy * sp, cp, cy * sp];
      const o = new Float32Array(16);
      o[0] = r[0]; o[4] = r[1]; o[8] = r[2]; o[1] = u[0]; o[5] = u[1]; o[9] = u[2]; o[2] = -f[0]; o[6] = -f[1]; o[10] = -f[2]; o[15] = 1;
      return o;
    },
    invert(m) {
      const a = m, o = new Float32Array(16), t = new Float32Array(16);
      t[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10];
      t[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10];
      t[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9];
      t[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9];
      t[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10];
      t[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10];
      t[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9];
      t[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9];
      t[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6];
      t[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6];
      t[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5];
      t[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5];
      t[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6];
      t[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6];
      t[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5];
      t[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5];
      let det = a[0] * t[0] + a[1] * t[4] + a[2] * t[8] + a[3] * t[12];
      if (!det) return o; det = 1 / det;
      for (let i = 0; i < 16; i++) o[i] = t[i] * det;
      return o;
    },
  };

  /* ---------- shaders ---------- */
  const WORLD_VS = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos; layout(location=1) in vec2 aUV; layout(location=2) in vec3 aLight;
  uniform mat4 uVP; uniform vec3 uOff;
  out vec2 vUV; out vec3 vLight; out float vDist;
  void main(){ vec3 p = aPos + uOff; gl_Position = uVP * vec4(p, 1.0); vUV = aUV; vLight = aLight; vDist = length(p); }`;
  const WORLD_FS = `#version 300 es
  precision highp float;
  in vec2 vUV; in vec3 vLight; in float vDist;
  uniform sampler2D uTex; uniform float uSun; uniform vec3 uSkyCol; uniform vec3 uFog; uniform vec2 uFogRange; uniform float uAlpha; uniform float uMinAmb; uniform float uTime;
  out vec4 outColor;
  void main(){
    vec2 uv = vUV;
    if (uAlpha < 1.0) uv += vec2(sin(uTime * 1.3 + uv.y * 80.0), cos(uTime * 1.1 + uv.x * 80.0)) * 0.0009;
    vec4 t = texture(uTex, uv);
    if (uAlpha >= 1.0 && t.a < 0.5) discard;
    vec3 L = vec3(vLight.x * uSun) * uSkyCol + vec3(vLight.y) * vec3(1.0, 0.86, 0.62);
    L = max(L, vec3(uMinAmb));
    vec3 col = t.rgb * L * vLight.z;
    float f = smoothstep(uFogRange.x, uFogRange.y, vDist);
    col = mix(col, uFog, f);
    outColor = vec4(col, uAlpha < 1.0 ? t.a * uAlpha : 1.0);
  }`;
  const SKY_VS = `#version 300 es
  precision highp float;
  out vec2 vNdc;
  void main(){ vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); vNdc = p * 2.0 - 1.0; gl_Position = vec4(vNdc, 0.9999, 1.0); }`;
  const SKY_FS = `#version 300 es
  precision highp float;
  in vec2 vNdc;
  uniform mat4 uInv; uniform vec3 uSunDir; uniform float uDay; uniform float uTime; uniform vec3 uCam; uniform vec3 uZenith; uniform vec3 uHorizon; uniform float uCloudY;
  out vec4 outColor;
  float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float hash3(vec3 p){ return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
  float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
  float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 4; i++){ s += a * noise(p); p *= 2.03; a *= 0.5; } return s; }
  void main(){
    vec4 p = uInv * vec4(vNdc, 1.0, 1.0); vec3 dir = normalize(p.xyz / p.w);
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(h, 0.55));
    if (dir.y < 0.0) col = mix(uHorizon, uHorizon * 0.75, clamp(-dir.y * 4.0, 0.0, 1.0));
    float sd = max(dot(dir, uSunDir), 0.0);
    float low = clamp(1.0 - abs(uSunDir.y) * 2.2, 0.0, 1.0);
    col += vec3(1.0, 0.55, 0.25) * pow(sd, 6.0) * low * 0.55;
    col += vec3(1.0, 0.93, 0.7) * (pow(sd, 1200.0) * 4.0 + pow(sd, 18.0) * 0.18) * smoothstep(-0.15, 0.1, uSunDir.y);
    float md = max(dot(dir, -uSunDir), 0.0);
    col += vec3(0.82, 0.88, 1.0) * smoothstep(0.9988, 0.9994, md) * (1.0 - uDay) * 1.1;
    if (dir.y > 0.0) { float s = hash3(floor(dir * 190.0)); col += vec3(step(0.9972, s)) * (1.0 - uDay) * smoothstep(0.0, 0.35, dir.y) * (0.6 + 0.4 * hash3(floor(dir * 190.0) + 5.0)); }
    if (dir.y > 0.025) {
      float t = (uCloudY - uCam.y) / dir.y; vec2 xz = uCam.xz + dir.xz * t;
      float n = fbm(xz * 0.011 + vec2(uTime * 0.012, 0.0)); float c = smoothstep(0.5, 0.72, n);
      vec3 cc = mix(vec3(0.12, 0.14, 0.22), vec3(1.0), uDay) * mix(1.0, 0.85, low);
      col = mix(col, cc, c * 0.82 * smoothstep(0.025, 0.16, dir.y));
    }
    outColor = vec4(col, 1.0);
  }`;
  const ENT_VS = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos; layout(location=1) in vec3 aCol; layout(location=2) in float aLight;
  uniform mat4 uVP; out vec3 vCol; out float vDist;
  void main(){ gl_Position = uVP * vec4(aPos, 1.0); vCol = aCol * aLight; vDist = length(aPos); }`;
  const ENT_FS = `#version 300 es
  precision highp float;
  in vec3 vCol; in float vDist; uniform vec3 uFog; uniform vec2 uFogRange; uniform float uAlpha; uniform float uLight;
  out vec4 outColor;
  void main(){ vec3 c = vCol * uLight; c = mix(c, uFog, smoothstep(uFogRange.x, uFogRange.y, vDist)); outColor = vec4(c, uAlpha); }`;

  /* ---------- entity / particle geometry batch ---------- */
  const SHADE = [0.75, 0.75, 1.0, 0.5, 0.88, 0.88]; // +x -x +y -y +z -z
  const CUBE = [
    [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]], [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]],
    [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
    [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]],
  ];
  class Batch {
    constructor(maxVerts) { this.v = new Float32Array(maxVerts * 7); this.n = 0; this.max = maxVerts * 7; }
    clear() { this.n = 0; }
    /** Box from (x0,y0,z0) to (x1,y1,z1) in local space, transformed by the 3x4 matrix m. */
    box(m, x0, y0, z0, x1, y1, z1, r, g, b, light) {
      if (this.n + 36 * 7 > this.max) return;
      const v = this.v; let n = this.n;
      for (let f = 0; f < 6; f++) {
        const c = CUBE[f], sh = SHADE[f] * (light == null ? 1 : light);
        const pts = [];
        for (let k = 0; k < 4; k++) {
          const lx = c[k][0] ? x1 : x0, ly = c[k][1] ? y1 : y0, lz = c[k][2] ? z1 : z0;
          pts.push(m[0] * lx + m[1] * ly + m[2] * lz + m[3], m[4] * lx + m[5] * ly + m[6] * lz + m[7], m[8] * lx + m[9] * ly + m[10] * lz + m[11]);
        }
        for (const k of [0, 1, 2, 0, 2, 3]) { v[n++] = pts[k * 3]; v[n++] = pts[k * 3 + 1]; v[n++] = pts[k * 3 + 2]; v[n++] = r; v[n++] = g; v[n++] = b; v[n++] = sh; }
      }
      this.n = n;
    }
    count() { return this.n / 7; }
  }
  /** 3x4 affine: translate(tx,ty,tz) * rotY(yaw) * rotX(pitch) applied to local coords. */
  function xform(tx, ty, tz, yaw, rx) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cx = Math.cos(rx || 0), sx = Math.sin(rx || 0);
    // rotY * rotX
    return [cy, sy * sx, sy * cx, tx, 0, cx, -sx, ty, -sy, cy * sx, cy * cx, tz];
  }
  function mulAffine(a, b) { // a * b (both 3x4)
    const o = new Array(12);
    for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) o[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c] + (c === 3 ? a[r * 4 + 3] : 0);
    return o;
  }

  /* ---------- renderer ---------- */
  function create(canvas, atlasCanvas) {
    const gl = canvas.getContext("webgl2", { antialias: false, alpha: false, powerPreference: "high-performance", preserveDrawingBuffer: false });
    if (!gl) return null;
    const compile = (vs, fs) => {
      const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
      const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
      const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
      for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
      return { p, u };
    };
    const world = compile(WORLD_VS, WORLD_FS), sky = compile(SKY_VS, SKY_FS), ent = compile(ENT_VS, ENT_FS);
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlasCanvas);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const emptyVao = gl.createVertexArray();

    const meshes = new Map();
    const state = { w: 1, h: 1, scale: 1, fov: 72, dist: 6, vp: null, vpRot: null, cam: { x: 0, y: 0, z: 0 }, planes: null };
    const stats = { chunks: 0, tris: 0, draws: 0 };

    function makeVAO(vbo, ibo) {
      const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
      gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 32, 12);
      gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 32, 20);
      gl.bindVertexArray(null);
      return vao;
    }
    function upload(part) {
      if (!part) return null;
      const vbo = gl.createBuffer(), ibo = gl.createBuffer();
      gl.bindVertexArray(null); // otherwise the index buffer below would be attached to whichever VAO was used last
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo); gl.bufferData(gl.ARRAY_BUFFER, part.v, gl.STATIC_DRAW);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, part.i, gl.STATIC_DRAW);
      return { vao: makeVAO(vbo, ibo), vbo, ibo, count: part.i.length };
    }
    function freePart(p) { if (!p) return; gl.deleteVertexArray(p.vao); gl.deleteBuffer(p.vbo); gl.deleteBuffer(p.ibo); }
    function setChunkMesh(cx, cz, result) {
      const k = cx + "," + cz, old = meshes.get(k);
      if (old) { freePart(old.o); freePart(old.w); }
      if (!result || (!result.opaque && !result.water)) { meshes.delete(k); return; }
      meshes.set(k, { cx, cz, o: upload(result.opaque), w: upload(result.water) });
    }
    function dropChunk(k) { const old = meshes.get(k); if (old) { freePart(old.o); freePart(old.w); meshes.delete(k); } }

    // dynamic buffers for entities / particles / hand
    const dyn = { vbo: gl.createBuffer(), vao: gl.createVertexArray(), cap: 0 };
    gl.bindVertexArray(dyn.vao); gl.bindBuffer(gl.ARRAY_BUFFER, dyn.vbo);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 28, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 28, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, 28, 24);
    gl.bindVertexArray(null);
    function drawBatch(batch, mode) {
      if (!batch.n) return;
      gl.bindVertexArray(dyn.vao); gl.bindBuffer(gl.ARRAY_BUFFER, dyn.vbo);
      if (batch.n * 4 > dyn.cap) { dyn.cap = batch.n * 4 * 2; gl.bufferData(gl.ARRAY_BUFFER, dyn.cap, gl.DYNAMIC_DRAW); }
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, batch.v, 0, batch.n);
      gl.drawArrays(mode || gl.TRIANGLES, 0, batch.n / 7);
      stats.draws++; stats.tris += (batch.n / 7) / 3;
    }

    function resize(cssW, cssH, dpr, scale) {
      state.scale = scale || state.scale;
      const w = Math.max(2, Math.floor(cssW * dpr * state.scale)), h = Math.max(2, Math.floor(cssH * dpr * state.scale));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      state.w = w; state.h = h;
      gl.viewport(0, 0, w, h);
    }

    function extractPlanes(m) {
      const p = [];
      const row = (i) => [m[i], m[4 + i], m[8 + i], m[12 + i]];
      const r0 = row(0), r1 = row(1), r2 = row(2), r3 = row(3);
      for (const [a, s] of [[r0, 1], [r0, -1], [r1, 1], [r1, -1], [r2, 1], [r2, -1]]) { const pl = [r3[0] + s * a[0], r3[1] + s * a[1], r3[2] + s * a[2], r3[3] + s * a[3]]; const l = Math.hypot(pl[0], pl[1], pl[2]) || 1; p.push(pl.map((v) => v / l)); }
      return p;
    }
    function visible(minx, miny, minz, maxx, maxy, maxz) {
      const pl = state.planes;
      for (let i = 0; i < 6; i++) {
        const p = pl[i], x = p[0] > 0 ? maxx : minx, y = p[1] > 0 ? maxy : miny, z = p[2] > 0 ? maxz : minz;
        if (p[0] * x + p[1] * y + p[2] * z + p[3] < 0) return false;
      }
      return true;
    }

    function fogColors(day, sunY) {
      const lerp = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
      const dayH = [0.74, 0.86, 1.0], nightH = [0.035, 0.05, 0.11], dayZ = [0.27, 0.5, 0.92], nightZ = [0.005, 0.01, 0.045], dusk = [1.0, 0.55, 0.32];
      let horizon = lerp(nightH, dayH, day), zenith = lerp(nightZ, dayZ, day);
      const dk = Math.max(0, 1 - Math.abs(sunY) * 4) * (day > 0.02 ? 1 : 0) * 0.7;
      horizon = lerp(horizon, dusk, dk);
      return { horizon, zenith };
    }

    /** One frame. f: {cam:{x,y,z,yaw,pitch}, tod, time, sel, ents:Batch, xray:Batch, parts:Batch, hand:Batch, underwater, dist, handFov} */
    function render(f) {
      stats.chunks = 0; stats.tris = 0; stats.draws = 0;
      const c = f.cam, aspect = state.w / state.h, fovRad = (f.fov || state.fov) * Math.PI / 180;
      const day = SS.daylight(f.tod), sunY = SS.sunElevation(f.tod), th = (f.tod - 0.25) * Math.PI * 2;
      const sunDir = [Math.sin(th), Math.cos(th), 0.28], sl = Math.hypot(sunDir[0], sunDir[1], sunDir[2]); sunDir[0] /= sl; sunDir[1] /= sl; sunDir[2] /= sl;
      const proj = M.perspective(fovRad, aspect, 0.06, 600), view = M.viewRot(c.yaw, c.pitch), vp = M.mul(proj, view);
      state.vp = vp; state.planes = extractPlanes(vp); state.cam = c; state.aspect = aspect; state.fovRad = fovRad;
      const { horizon, zenith } = fogColors(day, sunY);
      const dist = (f.dist || state.dist) * CH, uw = f.underwater;
      let fogC = uw ? [0.08, 0.22, 0.42].map((v) => v * (0.25 + 0.75 * day)) : horizon;
      const fogR = uw ? [0, 22] : [dist * 0.62, dist * 0.97];
      const sun = 0.2 + 0.8 * day, minAmb = 0.05 + 0.02 * day;
      const skyCol = [0.5 + 0.5 * day, 0.58 + 0.42 * day, 1.0];

      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, state.w, state.h);
      gl.clearColor(fogC[0], fogC[1], fogC[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);

      // sky
      gl.disable(gl.DEPTH_TEST); gl.depthMask(false);
      gl.useProgram(sky.p);
      gl.uniformMatrix4fv(sky.u.uInv, false, M.invert(vp));
      gl.uniform3fv(sky.u.uSunDir, sunDir); gl.uniform1f(sky.u.uDay, day); gl.uniform1f(sky.u.uTime, f.time);
      gl.uniform3f(sky.u.uCam, c.x, c.y, c.z); gl.uniform3fv(sky.u.uZenith, uw ? fogC : zenith); gl.uniform3fv(sky.u.uHorizon, uw ? fogC : horizon); gl.uniform1f(sky.u.uCloudY, 92);
      gl.disable(gl.CULL_FACE); gl.bindVertexArray(emptyVao); gl.drawArrays(gl.TRIANGLES, 0, 3); gl.enable(gl.CULL_FACE);
      gl.depthMask(true); gl.enable(gl.DEPTH_TEST);

      // opaque chunks
      gl.useProgram(world.p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(world.u.uTex, 0);
      gl.uniformMatrix4fv(world.u.uVP, false, vp);
      gl.uniform1f(world.u.uSun, sun); gl.uniform3fv(world.u.uSkyCol, skyCol); gl.uniform3fv(world.u.uFog, fogC); gl.uniform2fv(world.u.uFogRange, fogR); gl.uniform1f(world.u.uMinAmb, minAmb); gl.uniform1f(world.u.uTime, f.time); gl.uniform1f(world.u.uAlpha, 1);
      const vis = [];
      meshes.forEach((m) => {
        const ox = m.cx * CH - c.x, oz = m.cz * CH - c.z;
        if (!visible(ox, -c.y, oz, ox + CH, HT - c.y, oz + CH)) return;
        vis.push(m); stats.chunks++;
        if (!m.o) return;
        gl.uniform3f(world.u.uOff, ox, -c.y, oz);
        gl.bindVertexArray(m.o.vao); gl.drawElements(gl.TRIANGLES, m.o.count, gl.UNSIGNED_INT, 0);
        stats.draws++; stats.tris += m.o.count / 3;
      });

      // entities (opaque), then x-ray overlay
      gl.useProgram(ent.p);
      gl.uniformMatrix4fv(ent.u.uVP, false, vp); gl.uniform3fv(ent.u.uFog, fogC); gl.uniform2fv(ent.u.uFogRange, fogR); gl.uniform1f(ent.u.uAlpha, 1); gl.uniform1f(ent.u.uLight, 0.32 + 0.68 * Math.max(day, f.entLight || 0));
      if (f.ents) drawBatch(f.ents);
      if (f.parts) { gl.uniform1f(ent.u.uLight, 1); drawBatch(f.parts); }
      if (f.sel) {
        const s = f.sel, e = 0.003, lines = new Batch(64), p0 = [s.x - c.x - e, s.y - c.y - e, s.z - c.z - e], p1 = [p0[0] + 1 + 2 * e, p0[1] + 1 + 2 * e, p0[2] + 1 + 2 * e];
        const edges = [[0, 0, 0, 1, 0, 0], [0, 1, 0, 1, 1, 0], [0, 0, 1, 1, 0, 1], [0, 1, 1, 1, 1, 1], [0, 0, 0, 0, 1, 0], [1, 0, 0, 1, 1, 0], [0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 1], [0, 0, 0, 0, 0, 1], [1, 0, 0, 1, 0, 1], [0, 1, 0, 0, 1, 1], [1, 1, 0, 1, 1, 1]];
        const lb = []; for (const q of edges) { lb.push(q[0] ? p1[0] : p0[0], q[1] ? p1[1] : p0[1], q[2] ? p1[2] : p0[2], 0, 0, 0, 1, q[3] ? p1[0] : p0[0], q[4] ? p1[1] : p0[1], q[5] ? p1[2] : p0[2], 0, 0, 0, 1); }
        const lbatch = { v: new Float32Array(lb), n: lb.length }; gl.uniform1f(ent.u.uLight, 1);
        gl.disable(gl.CULL_FACE); drawBatch(lbatch, gl.LINES); gl.enable(gl.CULL_FACE);
        if (f.sel.progress > 0) { const pr = f.sel.progress, g = 0.5 - pr * 0.5, cb = new Batch(36); cb.box([1, 0, 0, p0[0] - 0.002, 0, 1, 0, p0[1] - 0.002, 0, 0, 1, p0[2] - 0.002], 0, 0, 0, 1.0 + 0.004, 1.0 + 0.004, 1.0 + 0.004, 0.05, 0.05, 0.05, 1); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.uniform1f(ent.u.uAlpha, 0.15 + pr * 0.45); drawBatch(cb); gl.uniform1f(ent.u.uAlpha, 1); gl.disable(gl.BLEND); }
      }
      if (f.xray && f.xray.n) { gl.disable(gl.DEPTH_TEST); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.uniform1f(ent.u.uAlpha, 0.55); gl.uniform1f(ent.u.uLight, 1.6); drawBatch(f.xray); gl.disable(gl.BLEND); gl.enable(gl.DEPTH_TEST); gl.uniform1f(ent.u.uAlpha, 1); }

      // water (blended, back to front)
      gl.useProgram(world.p);
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.disable(gl.CULL_FACE);
      gl.uniform1f(world.u.uAlpha, 0.72);
      vis.sort((a, b) => Math.hypot((b.cx + 0.5) * CH - c.x, (b.cz + 0.5) * CH - c.z) - Math.hypot((a.cx + 0.5) * CH - c.x, (a.cz + 0.5) * CH - c.z));
      for (const m of vis) {
        if (!m.w) continue;
        gl.uniform3f(world.u.uOff, m.cx * CH - c.x, -c.y, m.cz * CH - c.z);
        gl.bindVertexArray(m.w.vao); gl.drawElements(gl.TRIANGLES, m.w.count, gl.UNSIGNED_INT, 0);
        stats.draws++; stats.tris += m.w.count / 3;
      }
      gl.depthMask(true); gl.disable(gl.BLEND); gl.enable(gl.CULL_FACE);

      // first-person hand / weapon: own projection, depth cleared
      if (f.hand && f.hand.n) {
        gl.clear(gl.DEPTH_BUFFER_BIT);
        const hp = M.perspective(62 * Math.PI / 180, aspect, 0.02, 10);
        gl.useProgram(ent.p); gl.uniformMatrix4fv(ent.u.uVP, false, hp); gl.uniform1f(ent.u.uLight, 0.55 + 0.45 * Math.max(day, f.entLight || 0)); gl.uniform1f(ent.u.uAlpha, 1); gl.uniform2f(ent.u.uFogRange, 1e6, 2e6);
        gl.disable(gl.CULL_FACE); drawBatch(f.hand); gl.enable(gl.CULL_FACE);
      }
      state.day = day;
      return { day, fog: fogC };
    }

    /** World position -> CSS pixel position on screen (or null when behind the camera). */
    function project(x, y, z, cssW, cssH) {
      const c = state.cam, v = state.vp; if (!v) return null;
      const px = x - c.x, py = y - c.y, pz = z - c.z;
      const cx = v[0] * px + v[4] * py + v[8] * pz, cy = v[1] * px + v[5] * py + v[9] * pz, cw = v[3] * px + v[7] * py + v[11] * pz;
      if (cw <= 0.05) return null;
      return { x: (cx / cw * 0.5 + 0.5) * cssW, y: (1 - (cy / cw * 0.5 + 0.5)) * cssH, d: cw };
    }

    const info = (() => { const d = gl.getExtension("WEBGL_debug_renderer_info"); return d ? gl.getParameter(d.UNMASKED_RENDERER_WEBGL) : "webgl2"; })();
    return { gl, resize, render, setChunkMesh, dropChunk, project, stats, state, meshes, Batch, xform, mulAffine, info, meshCount: () => meshes.size };
  }

  root.SSRenderer = { create, Batch, xform, mulAffine, M };
})(window);
