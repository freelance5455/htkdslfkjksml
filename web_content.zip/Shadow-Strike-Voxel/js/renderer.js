/* Shadow Strike Voxel — WebGL2 renderer (no external libraries, works offline).
   Everything is drawn camera-relative so far-away coordinates keep full precision. */
(function (root) {
  "use strict";
  const SS = root.SSWorld, { CH, HT } = SS;

  /* ---------- small matrix helpers (column-major) ---------- */
  const M = {
    perspective(fov, asp, n, f) { const t = 1 / Math.tan(fov / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = (2 * f * n) / (n - f); return o; },
    mul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
    /** Rotation-only view matrix looking along yaw/pitch (translation is handled by drawing camera-relative). */
    viewRot(yaw, pitch) {
      const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
      const f = [-sy * cp, sp, -cy * cp], r = [cy, 0, -sy], u = [sy * sp, cp, cy * sp];
      const o = new Float32Array(16);
      o[0] = r[0]; o[4] = r[1]; o[8] = r[2]; o[1] = u[0]; o[5] = u[1]; o[9] = u[2]; o[2] = -f[0]; o[6] = -f[1]; o[10] = -f[2]; o[15] = 1;
      return o;
    },
    invert(m) {
      const a = m, o = new Float32Array(16), t = new Float32Array(16);
      t[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10];
      t[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10];
      t[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9];
      t[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9];
      t[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10];
      t[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10];
      t[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9];
      t[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9];
      t[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6];
      t[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6];
      t[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5];
      t[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5];
      t[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6];
      t[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6];
      t[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5];
      t[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5];
      let det = a[0] * t[0] + a[1] * t[4] + a[2] * t[8] + a[3] * t[12];
      if (!det) return o; det = 1 / det;
      for (let i = 0; i < 16; i++) o[i] = t[i] * det;
      return o;
    },
  };

  /* ---------- shaders ---------- */
  const WORLD_VS = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos; layout(location=1) in vec2 aUV; layout(location=2) in vec3 aLight;
  uniform mat4 uVP; uniform vec3 uOff;
  out vec2 vUV; out vec3 vLight; out float vDist; out vec3 vRel;
  void main(){ vec3 p = aPos + uOff; gl_Position = uVP * vec4(p, 1.0); vUV = aUV; vLight = aLight; vDist = length(p); vRel = p; }`;
  const WORLD_FS = `#version 300 es
  precision highp float; precision highp sampler2DShadow;
  in vec2 vUV; in vec3 vLight; in float vDist; in vec3 vRel;
  uniform sampler2D uTex; uniform sampler2DShadow uShadow; uniform mat4 uLVP;
  uniform vec3 uSunDir, uSunCol, uAmbSky, uAmbGnd, uFog, uSunFog; uniform vec2 uFogRange; uniform vec4 uFlash;
  uniform float uAlpha, uMinAmb, uTime, uStore, uShadowOn;
  out vec4 outColor;
  const vec3 NRM[6] = vec3[6](vec3(1,0,0), vec3(-1,0,0), vec3(0,1,0), vec3(0,-1,0), vec3(0,0,1), vec3(0,0,-1));
  vec4 tileTap(vec2 uv){
    vec2 tuv = uv * vec2(8.0, 4.0), tile = floor(tuv), loc = tuv - tile, fw = min(fwidth(tuv) * 0.5, vec2(0.5)), lo = vec2(0.5 / 32.0), hi = vec2(1.0 - 0.5 / 32.0);
    vec4 s = texture(uTex, (tile + clamp(loc + fw * vec2(-0.5, -0.5), lo, hi)) / vec2(8.0, 4.0)) + texture(uTex, (tile + clamp(loc + fw * vec2(0.5, -0.5), lo, hi)) / vec2(8.0, 4.0)) + texture(uTex, (tile + clamp(loc + fw * vec2(-0.5, 0.5), lo, hi)) / vec2(8.0, 4.0)) + texture(uTex, (tile + clamp(loc + fw * vec2(0.5, 0.5), lo, hi)) / vec2(8.0, 4.0));
    return s * 0.25;
  }
  void main(){
    vec2 uv = vUV;
    if (uAlpha < 1.0) uv += vec2(sin(uTime * 1.3 + uv.y * 80.0), cos(uTime * 1.1 + uv.x * 80.0)) * 0.0009;
    vec4 t = tileTap(uv);
    if (uAlpha >= 1.0 && t.a < 0.5) discard;
    float fi = floor(vLight.z * 0.5 + 0.001), ao = vLight.z - 2.0 * fi; vec3 N = NRM[int(fi)];
    float sky = vLight.x;
    vec3 amb = mix(uAmbGnd, uAmbSky, N.y * 0.5 + 0.5) * (0.16 + 0.84 * sky);
    float ndl = max(dot(N, uSunDir), 0.0), sh = smoothstep(0.55, 0.95, sky);
    if (uShadowOn > 0.5 && ndl > 0.0 && uAlpha >= 1.0) {
      vec4 lp = uLVP * vec4(vRel + N * 0.05, 1.0); vec3 sc = lp.xyz * 0.5 + 0.5;
      vec2 e = abs(sc.xy - 0.5) * 2.0; float fade = 1.0 - smoothstep(0.8, 0.98, max(e.x, e.y));
      float bias = 0.00045 + 0.0016 * (1.0 - ndl); float z = sc.z - bias; vec2 o = vec2(0.00035);
      float lit = 0.25 * (texture(uShadow, vec3(sc.xy + vec2(-o.x, -o.y), z)) + texture(uShadow, vec3(sc.xy + vec2(o.x, -o.y), z)) + texture(uShadow, vec3(sc.xy + vec2(-o.x, o.y), z)) + texture(uShadow, vec3(sc.xy + vec2(o.x, o.y), z)));
      sh = mix(sh, lit * mix(0.35, 1.0, smoothstep(0.1, 0.6, sky)) + (1.0 - lit) * 0.0, fade);
    }
    vec3 L = (amb + uSunCol * ndl * sh) * ao;
    L += vec3(vLight.y) * vec3(1.0, 0.72, 0.42) * 1.9;
    if (uFlash.w > 0.0) { vec3 d = vRel - uFlash.xyz; float dd = length(d), a = max(0.0, 1.0 - dd / 18.0); L += vec3(1.0, 0.7, 0.36) * uFlash.w * a * a * (0.35 + 0.65 * max(dot(N, -d / max(dd, 0.01)), 0.0)) * 3.0; }
    L = max(L, vec3(uMinAmb));
    vec3 alb = t.rgb * t.rgb;
    vec3 col = alb * L;
    float f = smoothstep(uFogRange.x, uFogRange.y, vDist);
    vec3 vd = vRel / max(vDist, 0.001); float sd = max(dot(vd, uSunDir), 0.0);
    vec3 fogc = uFog + uSunFog * pow(sd, 5.0);
    col = mix(col, fogc, f);
    outColor = vec4(col * uStore, uAlpha < 1.0 ? t.a * uAlpha : 1.0);
  }`;
  const SHADOW_VS = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos; layout(location=1) in vec2 aUV;
  uniform mat4 uLVP; uniform vec3 uOff; out vec2 vUV;
  void main(){ gl_Position = uLVP * vec4(aPos + uOff, 1.0); vUV = aUV; }`;
  const SHADOW_FS = `#version 300 es
  precision highp float; in vec2 vUV; uniform sampler2D uTex; out vec4 o;
  void main(){ if (texture(uTex, vUV).a < 0.5) discard; o = vec4(0.0); }`;
  const SHADOW_ENT_VS = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos; uniform mat4 uLVP;
  void main(){ gl_Position = uLVP * vec4(aPos, 1.0); }`;
  const SHADOW_ENT_FS = `#version 300 es
  precision highp float; out vec4 o; void main(){ o = vec4(0.0); }`;
  const SKY_VS = `#version 300 es
  precision highp float;
  out vec2 vNdc;
  void main(){ vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); vNdc = p * 2.0 - 1.0; gl_Position = vec4(vNdc, 0.9999, 1.0); }`;
  const SKY_FS = `#version 300 es
  precision highp float;
  in vec2 vNdc;
  uniform mat4 uInv; uniform vec3 uSunDir; uniform float uDay; uniform float uTime; uniform vec3 uCam; uniform vec3 uZenith; uniform vec3 uHorizon; uniform float uCloudY; uniform float uStore; uniform vec3 uSunCol; uniform float uSmoke;
  out vec4 outColor;
  float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float hash3(vec3 p){ return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
  float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
  float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++){ s += a * noise(p); p *= 2.03; a *= 0.5; } return s; }
  void main(){
    vec4 p = uInv * vec4(vNdc, 1.0, 1.0); vec3 dir = normalize(p.xyz / p.w);
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(h, 0.5));
    if (dir.y < 0.0) col = mix(uHorizon, uHorizon * 0.7, clamp(-dir.y * 4.0, 0.0, 1.0));
    float sd = max(dot(dir, uSunDir), 0.0);
    float low = clamp(1.0 - abs(uSunDir.y) * 2.0, 0.0, 1.0);
    col += uSunCol * 0.16 * pow(sd, 4.0) * (0.4 + low);
    col += vec3(1.0, 0.5, 0.22) * pow(sd, 10.0) * low * 0.9;
    col += vec3(1.0, 0.93, 0.74) * (pow(sd, 1600.0) * 28.0 + pow(sd, 40.0) * 0.9 + pow(sd, 8.0) * 0.12) * smoothstep(-0.12, 0.08, uSunDir.y);
    float md = max(dot(dir, -uSunDir), 0.0);
    col += vec3(0.82, 0.88, 1.0) * smoothstep(0.9988, 0.9994, md) * (1.0 - uDay) * 1.6;
    if (dir.y > 0.0) { float s = hash3(floor(dir * 190.0)); col += vec3(step(0.9972, s)) * (1.0 - uDay) * smoothstep(0.0, 0.35, dir.y) * (0.6 + 0.4 * hash3(floor(dir * 190.0) + 5.0)); }
    if (dir.y > 0.02) {
      float t = (uCloudY - uCam.y) / dir.y; vec2 xz = uCam.xz + dir.xz * t;
      float n = fbm(xz * 0.0105 + vec2(uTime * 0.012, 0.0)); float c = smoothstep(0.48, 0.74, n);
      float lit = clamp(0.35 + 0.65 * dot(normalize(vec3(dir.x, 0.4, dir.z)), uSunDir), 0.0, 1.0);
      vec3 cc = mix(vec3(0.05, 0.055, 0.09), mix(vec3(0.62, 0.66, 0.74), vec3(1.25, 1.05, 0.9), lit * lit), uDay);
      cc = mix(cc, uSunCol * 0.38 + cc * 0.5, low * 0.55 * uDay);
      col = mix(col, cc, c * 0.86 * smoothstep(0.02, 0.2, dir.y));
    }
    if (uSmoke > 0.0) {
      float ang = atan(dir.z, dir.x);
      float sm = fbm(vec2(ang * 4.0 + uTime * 0.01, dir.y * 9.0 - uTime * 0.02)), band = 1.0 - smoothstep(0.0, 0.34, dir.y);
      float plume = smoothstep(0.52, 0.8, sm) * band, haze = band * (0.2 + 0.3 * sm);
      vec3 sc = mix(vec3(0.03, 0.028, 0.03), vec3(0.2, 0.15, 0.12), pow(sd, 3.0) * uDay + 0.1);
      col = mix(col, sc * (0.4 + uDay), clamp(plume * 0.8 * uSmoke, 0.0, 0.85));
      col = mix(col, uHorizon * 0.8 + uSunCol * 0.04, haze * 0.25 * uSmoke);
    }
    outColor = vec4(col * uStore, 1.0);
  }`;
  const ENT_VS = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos; layout(location=1) in vec3 aCol; layout(location=2) in float aLight; layout(location=3) in float aAlpha;
  uniform mat4 uVP; out vec3 vCol; out float vDist; out float vL; out float vA;
  void main(){ gl_Position = uVP * vec4(aPos, 1.0); vCol = aCol; vL = aLight; vA = aAlpha; vDist = length(aPos); }`;
  const ENT_FS = `#version 300 es
  precision highp float;
  in vec3 vCol; in float vDist; in float vL; in float vA; uniform vec3 uFog; uniform vec2 uFogRange; uniform float uAlpha; uniform vec3 uTint; uniform float uStore, uEmit;
  out vec4 outColor;
  void main(){ vec3 a = vCol * vCol; vec3 c = vL > 1.4 ? a * vL * uEmit : a * vL * uTint; c = mix(c, uFog, smoothstep(uFogRange.x, uFogRange.y, vDist)); outColor = vec4(c * uStore, uAlpha * vA); }`;
  /* ----- post processing ----- */
  const QUAD_VS = `#version 300 es
  precision highp float; out vec2 vUV;
  void main(){ vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); vUV = p; gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }`;
  const BRIGHT_FS = `#version 300 es
  precision highp float; in vec2 vUV; uniform sampler2D uSrc; uniform vec2 uPx; uniform float uThr, uStore; out vec4 o;
  void main(){ vec3 c = (texture(uSrc, vUV + uPx * vec2(-1.0, -1.0)).rgb + texture(uSrc, vUV + uPx * vec2(1.0, -1.0)).rgb + texture(uSrc, vUV + uPx * vec2(-1.0, 1.0)).rgb + texture(uSrc, vUV + uPx * vec2(1.0, 1.0)).rgb) * 0.25 / uStore;
    float b = max(max(c.r, c.g), c.b); c *= max(b - uThr, 0.0) / (b + 0.0001); o = vec4(min(c, vec3(24.0)), 1.0); }`;
  const BLUR_FS = `#version 300 es
  precision highp float; in vec2 vUV; uniform sampler2D uSrc; uniform vec2 uDir; out vec4 o;
  void main(){ vec3 c = texture(uSrc, vUV).rgb * 0.227027; vec2 d1 = uDir * 1.3846, d2 = uDir * 3.2308;
    c += (texture(uSrc, vUV + d1).rgb + texture(uSrc, vUV - d1).rgb) * 0.316216 + (texture(uSrc, vUV + d2).rgb + texture(uSrc, vUV - d2).rgb) * 0.070270; o = vec4(c, 1.0); }`;
  const COMPOSE_FS = `#version 300 es
  precision highp float; in vec2 vUV;
  uniform sampler2D uScene, uDepth, uBloom; uniform vec2 uRes; uniform vec4 uSun; uniform vec3 uSunCol; uniform float uStore, uExposure, uBloomAmt, uRays, uFlare, uChroma, uVig, uHurt, uAspect, uUnder, uFlashI, uSat;
  out vec4 o;
  float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
  vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
  float skyMask(vec2 p){ if (p.x < 0.0 || p.y < 0.0 || p.x > 1.0 || p.y > 1.0) return 0.0; return texture(uDepth, p).r > 0.99999 ? 1.0 : 0.0; }
  void main(){
    vec2 uv = vUV, cen = uv - 0.5; float r2 = dot(cen * vec2(uAspect, 1.0), cen * vec2(uAspect, 1.0));
    vec3 c;
    if (uChroma > 0.0) { vec2 off = cen * (0.0035 + r2 * 0.012) * uChroma; c = vec3(texture(uScene, uv + off).r, texture(uScene, uv).g, texture(uScene, uv - off).b) / uStore; }
    else c = texture(uScene, uv).rgb / uStore;
    c += texture(uBloom, uv).rgb * uBloomAmt;
    if (uSun.z > 0.5) {
      if (uRays > 0.0) {
        vec2 dir = uSun.xy - uv; float dist = length(dir * vec2(uAspect, 1.0)); vec2 stp = dir / 26.0 * 0.95; vec2 p = uv + stp * fract(sin(dot(uv, vec2(12.9898, 78.233))) * 43758.5453); float ill = 0.0, dec = 1.0;
        for (int i = 0; i < 26; i++) { p += stp; ill += skyMask(p) * dec; dec *= 0.955; }
        c += uSunCol * 0.22 * ill / 26.0 * uRays * pow(clamp(1.15 - dist * 0.9, 0.0, 1.0), 2.0);
      }
      if (uFlare > 0.0) {
        float vis = (skyMask(uSun.xy) * 2.0 + skyMask(uSun.xy + vec2(0.012, 0.0)) + skyMask(uSun.xy - vec2(0.012, 0.0)) + skyMask(uSun.xy + vec2(0.0, 0.02)) + skyMask(uSun.xy - vec2(0.0, 0.02))) / 6.0;
        vis *= smoothstep(0.0, 0.25, 1.2 - length((uSun.xy - 0.5) * vec2(uAspect, 1.0)) * 0.9) * uSun.w;
        vec2 q = (uv - uSun.xy) * vec2(uAspect, 1.0); float cs = 0.8191, sn = 0.5736; vec2 qr = vec2(q.x * cs + q.y * sn, -q.x * sn + q.y * cs);
        float streak = exp(-abs(qr.y) * 140.0) * exp(-abs(qr.x) * 2.4);
        float glow = exp(-length(q) * 5.0) * 0.5;
        vec3 fl = uSunCol * (streak * 0.75 + glow * 0.45) * vec3(1.0, 0.8, 0.6);
        for (int i = 1; i < 5; i++) { float k = float(i) * 0.38; vec2 gp = (0.5 - uSun.xy) * k * vec2(uAspect, 1.0) + vec2(0.5 * uAspect, 0.5) ; vec2 g = (uv * vec2(uAspect, 1.0)) - (vec2(uSun.x * uAspect, uSun.y) + (vec2(0.5 * uAspect, 0.5) - vec2(uSun.x * uAspect, uSun.y)) * k * 1.7); float gr = 0.03 + 0.012 * float(i); fl += (smoothstep(gr, gr * 0.6, length(g)) * 0.18) * (i == 2 ? vec3(0.4, 0.8, 1.0) : i == 3 ? vec3(1.0, 0.6, 0.3) : vec3(0.6, 1.0, 0.7)) * uSunCol; }
        c += fl * vis * uFlare;
      }
    }
    c += vec3(1.0, 0.72, 0.4) * uFlashI * 0.05 * (1.0 - r2 * 2.0);
    c *= uExposure;
    vec3 t = aces(c);
    float l = luma(t);
    t = mix(t * vec3(0.92, 1.0, 1.06), t * vec3(1.07, 1.0, 0.88), smoothstep(0.15, 0.7, l));
    t = mix(vec3(luma(t)), t, uSat * (1.0 - uHurt * 0.55));
    t = sqrt(t);
    t = (t - 0.5) * 1.06 + 0.5;
    float vg = 1.0 - smoothstep(0.12, 0.62, r2) * uVig; t *= vg;
    t = mix(t, t * vec3(1.0, 0.32, 0.3), uHurt * smoothstep(0.05, 0.4, r2));
    o = vec4(clamp(t, 0.0, 1.0), 1.0);
  }`;
  const FINAL_FS = `#version 300 es
  precision highp float; in vec2 vUV; uniform sampler2D uSrc; uniform vec2 uRes; uniform float uGrain, uTime, uFxaa; out vec4 o;
  float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
  void main(){
    vec2 px = 1.0 / uRes; vec3 rgbM = texture(uSrc, vUV).rgb, c = rgbM;
    if (uFxaa > 0.5) {
      vec3 nw = texture(uSrc, vUV + vec2(-1.0, -1.0) * px).rgb, ne = texture(uSrc, vUV + vec2(1.0, -1.0) * px).rgb, sw = texture(uSrc, vUV + vec2(-1.0, 1.0) * px).rgb, se = texture(uSrc, vUV + vec2(1.0, 1.0) * px).rgb;
      float lNW = luma(nw), lNE = luma(ne), lSW = luma(sw), lSE = luma(se), lM = luma(rgbM);
      float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE))), lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
      vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));
      float dr = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125), rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + dr);
      dir = clamp(dir * rcp, vec2(-8.0), vec2(8.0)) * px;
      vec3 a = 0.5 * (texture(uSrc, vUV + dir * (1.0 / 3.0 - 0.5)).rgb + texture(uSrc, vUV + dir * (2.0 / 3.0 - 0.5)).rgb);
      vec3 b = a * 0.5 + 0.25 * (texture(uSrc, vUV + dir * -0.5).rgb + texture(uSrc, vUV + dir * 0.5).rgb);
      float lB = luma(b); c = (lB < lMin || lB > lMax) ? a : b;
    }
    float n = fract(sin(dot(vUV * uRes + uTime * 61.0, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
    c += n * (0.012 + uGrain * 0.05 * (1.0 - luma(c) * 0.7));
    o = vec4(c, 1.0);
  }`;

  /* ---------- entity / particle geometry batch ---------- */
  const SHADE = [0.75, 0.75, 1.0, 0.5, 0.88, 0.88]; // +x -x +y -y +z -z
  const CUBE = [
    [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]], [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]],
    [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
    [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]],
  ];
  const STRIDE = 8; // x y z r g b light alpha
  class Batch {
    constructor(maxVerts) { this.v = new Float32Array(maxVerts * STRIDE); this.n = 0; this.max = maxVerts * STRIDE; }
    clear() { this.n = 0; }
    /** Box from (x0,y0,z0) to (x1,y1,z1) in local space, transformed by the 3x4 matrix m. */
    box(m, x0, y0, z0, x1, y1, z1, r, g, b, light, alpha) {
      if (this.n + 36 * STRIDE > this.max) return;
      const v = this.v, al = alpha == null ? 1 : alpha; let n = this.n;
      for (let f = 0; f < 6; f++) {
        const c = CUBE[f], sh = light > 1.4 ? light : SHADE[f] * (light == null ? 1 : light);
        const pts = [];
        for (let k = 0; k < 4; k++) {
          const lx = c[k][0] ? x1 : x0, ly = c[k][1] ? y1 : y0, lz = c[k][2] ? z1 : z0;
          pts.push(m[0] * lx + m[1] * ly + m[2] * lz + m[3], m[4] * lx + m[5] * ly + m[6] * lz + m[7], m[8] * lx + m[9] * ly + m[10] * lz + m[11]);
        }
        for (const k of [0, 1, 2, 0, 2, 3]) { v[n++] = pts[k * 3]; v[n++] = pts[k * 3 + 1]; v[n++] = pts[k * 3 + 2]; v[n++] = r; v[n++] = g; v[n++] = b; v[n++] = sh; v[n++] = al; }
      }
      this.n = n;
    }
    count() { return this.n / STRIDE; }
  }
  /** 3x4 affine: translate(tx,ty,tz) * rotY(yaw) * rotX(pitch) applied to local coords. */
  function xform(tx, ty, tz, yaw, rx) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cx = Math.cos(rx || 0), sx = Math.sin(rx || 0);
    return [cy, sy * sx, sy * cx, tx, 0, cx, -sx, ty, -sy, cy * sx, cy * cx, tz];
  }
  /** 3x4 rotation about the local Z axis (roll). */
  function xformZ(tx, ty, tz, rz) { const c = Math.cos(rz), s = Math.sin(rz); return [c, -s, 0, tx, s, c, 0, ty, 0, 0, 1, tz]; }
  function mulAffine(a, b) { // a * b (both 3x4)
    const o = new Array(12);
    for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) o[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c] + (c === 3 ? a[r * 4 + 3] : 0);
    return o;
  }
  const lerp3 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const ss = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  const sq = (c) => [c[0] * c[0], c[1] * c[1], c[2] * c[2]];

  /* ---------- renderer ---------- */
  function create(canvas, atlasCanvas) {
    const gl = canvas.getContext("webgl2", { antialias: false, alpha: false, powerPreference: "high-performance", preserveDrawingBuffer: false });
    if (!gl) return null;
    const compile = (vs, fs) => {
      const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
      const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
      const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
      for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); u[info.name.replace(/\[0\]$/, "")] = gl.getUniformLocation(p, info.name); }
      return { p, u };
    };
    const world = compile(WORLD_VS, WORLD_FS), sky = compile(SKY_VS, SKY_FS), ent = compile(ENT_VS, ENT_FS);
    const shW = compile(SHADOW_VS, SHADOW_FS), shE = compile(SHADOW_ENT_VS, SHADOW_ENT_FS);
    const pBright = compile(QUAD_VS, BRIGHT_FS), pBlur = compile(QUAD_VS, BLUR_FS), pCompose = compile(QUAD_VS, COMPOSE_FS), pFinal = compile(QUAD_VS, FINAL_FS);
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlasCanvas);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const emptyVao = gl.createVertexArray();

    /* ----- render targets ----- */
    const hdrExt = gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float");
    let hdr = !!hdrExt, store = hdr ? 1 : 0.4;
    const T = { scene: null, ldr: null, a: null, b: null, shadow: null, w: 0, h: 0, shSize: 0 };
    const mkTex = (w, h, ifmt, fmt, type, filter) => { const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t); gl.texImage2D(gl.TEXTURE_2D, 0, ifmt, w, h, 0, fmt, type, null); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); return t; };
    const colorTex = (w, h) => (hdr ? mkTex(w, h, gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT, gl.LINEAR) : mkTex(w, h, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, gl.LINEAR));
    const mkFbo = (color, depth) => { const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f); if (color) gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, color, 0); if (depth) gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depth, 0); return f; };
    const freeT = (o) => { if (!o) return; gl.deleteFramebuffer(o.f); gl.deleteTexture(o.t); if (o.d) gl.deleteTexture(o.d); };
    function buildTargets(w, h) {
      [T.scene, T.ldr, T.a, T.b].forEach(freeT);
      let ct = colorTex(w, h);
      const dt = mkTex(w, h, gl.DEPTH_COMPONENT24, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, gl.NEAREST);
      let f = mkFbo(ct, dt);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE && hdr) { hdr = false; store = 0.4; gl.deleteTexture(ct); ct = colorTex(w, h); gl.deleteFramebuffer(f); f = mkFbo(ct, dt); }
      T.scene = { f, t: ct, d: dt };
      const lt = mkTex(w, h, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, gl.LINEAR); T.ldr = { f: mkFbo(lt, null), t: lt };
      const bw = Math.max(2, w >> 2), bh = Math.max(2, h >> 2);
      const at = colorTex(bw, bh), bt = colorTex(bw, bh); T.a = { f: mkFbo(at, null), t: at, w: bw, h: bh }; T.b = { f: mkFbo(bt, null), t: bt, w: bw, h: bh };
      T.w = w; T.h = h; gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }
    function buildShadow(size) {
      if (T.shadow) { gl.deleteFramebuffer(T.shadow.f); gl.deleteTexture(T.shadow.d); T.shadow = null; }
      T.shSize = size; if (!size) return;
      const d = mkTex(size, size, gl.DEPTH_COMPONENT24, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
      const f = mkFbo(null, d); gl.drawBuffers([gl.NONE]); gl.readBuffer(gl.NONE);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) { gl.deleteFramebuffer(f); gl.deleteTexture(d); T.shSize = 0; gl.bindFramebuffer(gl.FRAMEBUFFER, null); return; }
      T.shadow = { f, d }; gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    const meshes = new Map();
    const state = { w: 1, h: 1, scale: 1, fov: 72, dist: 6, vp: null, vpRot: null, cam: { x: 0, y: 0, z: 0 }, planes: null, fx: 2 };
    const stats = { chunks: 0, tris: 0, draws: 0 };

    function makeVAO(vbo, ibo) {
      const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
      gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 32, 12);
      gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 32, 20);
      gl.bindVertexArray(null);
      return vao;
    }
    function upload(part) {
      if (!part) return null;
      const vbo = gl.createBuffer(), ibo = gl.createBuffer();
      gl.bindVertexArray(null); // otherwise the index buffer below would be attached to whichever VAO was used last
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo); gl.bufferData(gl.ARRAY_BUFFER, part.v, gl.STATIC_DRAW);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, part.i, gl.STATIC_DRAW);
      return { vao: makeVAO(vbo, ibo), vbo, ibo, count: part.i.length };
    }
    function freePart(p) { if (!p) return; gl.deleteVertexArray(p.vao); gl.deleteBuffer(p.vbo); gl.deleteBuffer(p.ibo); }
    function setChunkMesh(cx, cz, result) {
      const k = cx + "," + cz, old = meshes.get(k);
      if (old) { freePart(old.o); freePart(old.w); }
      if (!result || (!result.opaque && !result.water)) { meshes.delete(k); return; }
      meshes.set(k, { cx, cz, o: upload(result.opaque), w: upload(result.water) });
    }
    function dropChunk(k) { const old = meshes.get(k); if (old) { freePart(old.o); freePart(old.w); meshes.delete(k); } }

    // dynamic buffers for entities / particles / hand
    const dyn = { vbo: gl.createBuffer(), vao: gl.createVertexArray(), cap: 0 };
    gl.bindVertexArray(dyn.vao); gl.bindBuffer(gl.ARRAY_BUFFER, dyn.vbo);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 32, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, 32, 24);
    gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 1, gl.FLOAT, false, 32, 28);
    gl.bindVertexArray(null);
    function drawBatch(batch, mode) {
      if (!batch.n) return;
      gl.bindVertexArray(dyn.vao); gl.bindBuffer(gl.ARRAY_BUFFER, dyn.vbo);
      if (batch.n * 4 > dyn.cap) { dyn.cap = batch.n * 4 * 2; gl.bufferData(gl.ARRAY_BUFFER, dyn.cap, gl.DYNAMIC_DRAW); }
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, batch.v, 0, batch.n);
      gl.drawArrays(mode || gl.TRIANGLES, 0, batch.n / STRIDE);
      stats.draws++; stats.tris += (batch.n / STRIDE) / 3;
    }

    function resize(cssW, cssH, dpr, scale) {
      state.scale = scale || state.scale;
      const w = Math.max(2, Math.floor(cssW * dpr * state.scale)), h = Math.max(2, Math.floor(cssH * dpr * state.scale));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      state.w = w; state.h = h;
      if (T.w !== w || T.h !== h) buildTargets(w, h);
    }
    /** fx: 0 = fast (tone-mapping only), 1 = balanced (bloom, FXAA, shadows), 2 = cinematic (big shadows, light shafts, lens effects). */
    function setFx(fx) { state.fx = fx; const want = fx >= 2 ? 2048 : fx >= 1 ? 1024 : 0; if (want !== T.shSize) buildShadow(want); }

    function extractPlanes(m) {
      const p = [];
      const row = (i) => [m[i], m[4 + i], m[8 + i], m[12 + i]];
      const r0 = row(0), r1 = row(1), r2 = row(2), r3 = row(3);
      for (const [a, s] of [[r0, 1], [r0, -1], [r1, 1], [r1, -1], [r2, 1], [r2, -1]]) { const pl = [r3[0] + s * a[0], r3[1] + s * a[1], r3[2] + s * a[2], r3[3] + s * a[3]]; const l = Math.hypot(pl[0], pl[1], pl[2]) || 1; p.push(pl.map((v) => v / l)); }
      return p;
    }
    function visible(minx, miny, minz, maxx, maxy, maxz) {
      const pl = state.planes;
      for (let i = 0; i < 6; i++) {
        const p = pl[i], x = p[0] > 0 ? maxx : minx, y = p[1] > 0 ? maxy : miny, z = p[2] > 0 ? maxz : minz;
        if (p[0] * x + p[1] * y + p[2] * z + p[3] < 0) return false;
      }
      return true;
    }

    function fogColors(day, sunY) {
      const lerp = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
      const dayH = [0.72, 0.8, 0.86], nightH = [0.04, 0.055, 0.1], dayZ = [0.26, 0.45, 0.82], nightZ = [0.006, 0.012, 0.05], dusk = [1.0, 0.5, 0.26];
      let horizon = lerp(nightH, dayH, day), zenith = lerp(nightZ, dayZ, day);
      const dk = Math.max(0, 1 - Math.abs(sunY) * 3.2) * (day > 0.02 ? 1 : 0) * 0.8;
      horizon = lerp(horizon, dusk, dk); zenith = lerp(zenith, [0.2, 0.28, 0.5], dk * 0.5 * day);
      return { horizon, zenith };
    }

    const lightVP = new Float32Array(16);
    /** Builds the camera-relative sun view-projection (snapped to shadow-texels so shadows never shimmer). */
    function buildLightVP(L, c, R) {
      const fwd = [-L[0], -L[1], -L[2]];
      let up0 = Math.abs(fwd[1]) > 0.95 ? [1, 0, 0] : [0, 1, 0];
      let right = [fwd[1] * up0[2] - fwd[2] * up0[1], fwd[2] * up0[0] - fwd[0] * up0[2], fwd[0] * up0[1] - fwd[1] * up0[0]]; const rl = Math.hypot(...right); right = right.map((v) => v / rl);
      const up = [right[1] * fwd[2] - right[2] * fwd[1], right[2] * fwd[0] - right[0] * fwd[2], right[0] * fwd[1] - right[1] * fwd[0]];
      const texel = (2 * R) / T.shSize, cxl = c.x * right[0] + c.y * right[1] + c.z * right[2], cyl = c.x * up[0] + c.y * up[1] + c.z * up[2];
      const sx = Math.floor(cxl / texel) * texel, sy = Math.floor(cyl / texel) * texel, near = -140, far = 140, k = 2 / (far - near);
      const o = lightVP;
      o[0] = right[0] / R; o[1] = up[0] / R; o[2] = fwd[0] * k; o[3] = 0;
      o[4] = right[1] / R; o[5] = up[1] / R; o[6] = fwd[1] * k; o[7] = 0;
      o[8] = right[2] / R; o[9] = up[2] / R; o[10] = fwd[2] * k; o[11] = 0;
      o[12] = (cxl - sx) / R; o[13] = (cyl - sy) / R; o[14] = -(far + near) / (far - near); o[15] = 1;
      return { right, up, R };
    }

    function quad(prog) { gl.useProgram(prog.p); gl.bindVertexArray(emptyVao); gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); }
    const bindTex = (unit, t, loc) => { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t); gl.uniform1i(loc, unit); };

    /** One frame. f: {cam:{x,y,z,yaw,pitch}, tod, time, sel, ents, xray, parts, smoke, hand, underwater, dist, fov, adsK, flash, hurt, smokeSky} */
    function render(f) {
      stats.chunks = 0; stats.tris = 0; stats.draws = 0;
      if (T.w !== state.w || T.h !== state.h) buildTargets(state.w, state.h);
      const fx = state.fx, c = f.cam, aspect = state.w / state.h, fovRad = (f.fov || state.fov) * Math.PI / 180;
      const day = SS.daylight(f.tod), sunY = SS.sunElevation(f.tod), th = (f.tod - 0.25) * Math.PI * 2;
      const sunDir = [Math.sin(th), Math.cos(th), 0.28], sl = Math.hypot(sunDir[0], sunDir[1], sunDir[2]); sunDir[0] /= sl; sunDir[1] /= sl; sunDir[2] /= sl;
      const proj = M.perspective(fovRad, aspect, 0.06, 600), view = M.viewRot(c.yaw, c.pitch), vp = M.mul(proj, view);
      state.vp = vp; state.planes = extractPlanes(vp); state.cam = c; state.aspect = aspect; state.fovRad = fovRad;
      const { horizon, zenith } = fogColors(day, sunY);
      const dist = (f.dist || state.dist) * CH, uw = f.underwater;
      const fogDisp = uw ? [0.08, 0.22, 0.42].map((v) => v * (0.25 + 0.75 * day)) : horizon, fogC = sq(fogDisp);
      const fogR = uw ? [0, 22] : [dist * 0.45, dist * 0.98];
      // lighting (linear space)
      const sunUp = sunDir[1], warm = lerp3([1.0, 0.5, 0.22], [1.0, 0.92, 0.8], ss(0.04, 0.6, sunUp));
      const sunI = 3.0 * day * ss(-0.05, 0.12, sunUp), moonI = 0.34 * (1 - day);
      const L = sunUp > -0.06 || day > 0.04 ? sunDir : [-sunDir[0], -sunDir[1], -sunDir[2]];
      const sunCol = [warm[0] * sunI + 0.28 * moonI * (sunUp > -0.06 ? 0 : 1), warm[1] * sunI + 0.4 * moonI * (sunUp > -0.06 ? 0 : 1), warm[2] * sunI + 0.75 * moonI * (sunUp > -0.06 ? 0 : 1)];
      const dusk = Math.max(0, 1 - Math.abs(sunUp) * 3.2) * day;
      const ambSky = lerp3(lerp3([0.016, 0.026, 0.07], [0.5, 0.62, 0.88], day), [0.58, 0.4, 0.36], dusk * 0.55);
      const ambGnd = lerp3([0.01, 0.01, 0.014], lerp3([0.32, 0.28, 0.22], [0.42, 0.26, 0.16], dusk), day);
      const sunFog = [sunCol[0] * 0.07, sunCol[1] * 0.07, sunCol[2] * 0.07];
      const exposure = (1.08 + 1.5 * (1 - day)) * (f.exposure || 1);
      const useShadow = fx >= 1 && T.shadow && sunCol[0] + sunCol[1] + sunCol[2] > 0.25 && !uw;
      const shR = fx >= 2 ? 60 : 50;

      /* ---- shadow map ---- */
      let lb = null;
      if (useShadow) {
        lb = buildLightVP(L, c, shR);
        gl.bindFramebuffer(gl.FRAMEBUFFER, T.shadow.f); gl.viewport(0, 0, T.shSize, T.shSize);
        gl.clear(gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthMask(true); gl.disable(gl.CULL_FACE); gl.disable(gl.BLEND);
        gl.useProgram(shW.p); gl.uniformMatrix4fv(shW.u.uLVP, false, lightVP); bindTex(0, tex, shW.u.uTex);
        const hx = 8 * Math.abs(lb.right[0]) + 8 * Math.abs(lb.right[2]) + 32 * Math.abs(lb.right[1]), hy = 8 * Math.abs(lb.up[0]) + 8 * Math.abs(lb.up[2]) + 32 * Math.abs(lb.up[1]);
        meshes.forEach((m) => {
          if (!m.o) return;
          const ox = m.cx * CH - c.x, oz = m.cz * CH - c.z, mx = ox + 8, my = HT / 2 - c.y, mz = oz + 8;
          if (Math.abs(mx * lb.right[0] + my * lb.right[1] + mz * lb.right[2] + (c.x * lb.right[0] + c.y * lb.right[1] + c.z * lb.right[2] - Math.floor((c.x * lb.right[0] + c.y * lb.right[1] + c.z * lb.right[2]) / ((2 * shR) / T.shSize)) * ((2 * shR) / T.shSize))) > shR + hx) return;
          if (Math.abs(mx * lb.up[0] + my * lb.up[1] + mz * lb.up[2]) > shR + hy + 8) return;
          gl.uniform3f(shW.u.uOff, ox, -c.y, oz); gl.bindVertexArray(m.o.vao); gl.drawElements(gl.TRIANGLES, m.o.count, gl.UNSIGNED_INT, 0); stats.draws++;
        });
        if (f.ents && f.ents.n) { gl.useProgram(shE.p); gl.uniformMatrix4fv(shE.u.uLVP, false, lightVP); drawBatch(f.ents); }
      }

      /* ---- main scene into the HDR target ---- */
      gl.bindFramebuffer(gl.FRAMEBUFFER, T.scene.f);
      gl.viewport(0, 0, state.w, state.h);
      gl.clearColor(fogC[0] * store, fogC[1] * store, fogC[2] * store, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);

      // sky
      gl.disable(gl.DEPTH_TEST); gl.depthMask(false);
      gl.useProgram(sky.p);
      gl.uniformMatrix4fv(sky.u.uInv, false, M.invert(vp));
      gl.uniform3fv(sky.u.uSunDir, sunDir); gl.uniform1f(sky.u.uDay, day); gl.uniform1f(sky.u.uTime, f.time); gl.uniform1f(sky.u.uStore, store);
      gl.uniform3f(sky.u.uCam, c.x, c.y, c.z); gl.uniform3fv(sky.u.uZenith, sq(uw ? fogDisp : zenith)); gl.uniform3fv(sky.u.uHorizon, sq(uw ? fogDisp : horizon)); gl.uniform1f(sky.u.uCloudY, 92);
      gl.uniform3fv(sky.u.uSunCol, [warm[0] * day, warm[1] * day, warm[2] * day]); gl.uniform1f(sky.u.uSmoke, uw ? 0 : (f.smokeSky == null ? 1 : f.smokeSky));
      gl.disable(gl.CULL_FACE); gl.bindVertexArray(emptyVao); gl.drawArrays(gl.TRIANGLES, 0, 3); gl.enable(gl.CULL_FACE);
      gl.depthMask(true); gl.enable(gl.DEPTH_TEST);

      // opaque chunks
      gl.useProgram(world.p);
      bindTex(0, tex, world.u.uTex);
      if (useShadow) bindTex(1, T.shadow.d, world.u.uShadow); else { gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, T.shadow ? T.shadow.d : tex); gl.uniform1i(world.u.uShadow, 1); }
      gl.uniformMatrix4fv(world.u.uVP, false, vp); gl.uniformMatrix4fv(world.u.uLVP, false, lightVP);
      gl.uniform3fv(world.u.uSunDir, L); gl.uniform3fv(world.u.uSunCol, sunCol); gl.uniform3fv(world.u.uAmbSky, ambSky); gl.uniform3fv(world.u.uAmbGnd, ambGnd);
      gl.uniform3fv(world.u.uFog, fogC); gl.uniform3fv(world.u.uSunFog, sunFog); gl.uniform2fv(world.u.uFogRange, fogR);
      const fl = f.flash; gl.uniform4f(world.u.uFlash, fl ? fl.x : 0, fl ? fl.y : 0, fl ? fl.z : 0, fl ? fl.i : 0);
      gl.uniform1f(world.u.uMinAmb, 0.004 + 0.006 * day); gl.uniform1f(world.u.uTime, f.time); gl.uniform1f(world.u.uAlpha, 1); gl.uniform1f(world.u.uStore, store); gl.uniform1f(world.u.uShadowOn, useShadow ? 1 : 0);
      const vis = [];
      meshes.forEach((m) => {
        const ox = m.cx * CH - c.x, oz = m.cz * CH - c.z;
        if (!visible(ox, -c.y, oz, ox + CH, HT - c.y, oz + CH)) return;
        vis.push(m); stats.chunks++;
        if (!m.o) return;
        gl.uniform3f(world.u.uOff, ox, -c.y, oz);
        gl.bindVertexArray(m.o.vao); gl.drawElements(gl.TRIANGLES, m.o.count, gl.UNSIGNED_INT, 0);
        stats.draws++; stats.tris += m.o.count / 3;
      });

      // entities (opaque), particles, selection box, x-ray overlay
      const tint = [ambSky[0] * 0.8 + sunCol[0] * 0.5, ambSky[1] * 0.8 + sunCol[1] * 0.5, ambSky[2] * 0.8 + sunCol[2] * 0.5].map((v) => Math.max(0.05, Math.min(2.4, v)));
      gl.useProgram(ent.p);
      gl.uniformMatrix4fv(ent.u.uVP, false, vp); gl.uniform3fv(ent.u.uFog, fogC); gl.uniform2fv(ent.u.uFogRange, fogR); gl.uniform1f(ent.u.uAlpha, 1); gl.uniform3fv(ent.u.uTint, tint); gl.uniform1f(ent.u.uStore, store); gl.uniform1f(ent.u.uEmit, 1.0);
      if (f.ents) drawBatch(f.ents);
      if (f.parts) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); drawBatch(f.parts); gl.disable(gl.BLEND); }
      if (f.sel) {
        const s = f.sel, e = 0.003, p0 = [s.x - c.x - e, s.y - c.y - e, s.z - c.z - e], p1 = [p0[0] + 1 + 2 * e, p0[1] + 1 + 2 * e, p0[2] + 1 + 2 * e];
        const edges = [[0, 0, 0, 1, 0, 0], [0, 1, 0, 1, 1, 0], [0, 0, 1, 1, 0, 1], [0, 1, 1, 1, 1, 1], [0, 0, 0, 0, 1, 0], [1, 0, 0, 1, 1, 0], [0, 0, 1, 0, 1, 1], [1, 0, 1, 1, 1, 1], [0, 0, 0, 0, 0, 1], [1, 0, 0, 1, 0, 1], [0, 1, 0, 0, 1, 1], [1, 1, 0, 1, 1, 1]];
        const lb2 = []; for (const q of edges) { lb2.push(q[0] ? p1[0] : p0[0], q[1] ? p1[1] : p0[1], q[2] ? p1[2] : p0[2], 0, 0, 0, 1, 1, q[3] ? p1[0] : p0[0], q[4] ? p1[1] : p0[1], q[5] ? p1[2] : p0[2], 0, 0, 0, 1, 1); }
        const lbatch = { v: new Float32Array(lb2), n: lb2.length };
        gl.disable(gl.CULL_FACE); drawBatch(lbatch, gl.LINES); gl.enable(gl.CULL_FACE);
        if (f.sel.progress > 0) { const pr = f.sel.progress, cb = new Batch(36); cb.box([1, 0, 0, p0[0] - 0.002, 0, 1, 0, p0[1] - 0.002, 0, 0, 1, p0[2] - 0.002], 0, 0, 0, 1.0 + 0.004, 1.0 + 0.004, 1.0 + 0.004, 0.05, 0.05, 0.05, 1); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.uniform1f(ent.u.uAlpha, 0.15 + pr * 0.45); drawBatch(cb); gl.uniform1f(ent.u.uAlpha, 1); gl.disable(gl.BLEND); }
      }
      if (f.xray && f.xray.n) { gl.disable(gl.DEPTH_TEST); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.uniform1f(ent.u.uAlpha, 0.55); gl.uniform3f(ent.u.uTint, 1.6, 1.6, 1.6); drawBatch(f.xray); gl.disable(gl.BLEND); gl.enable(gl.DEPTH_TEST); gl.uniform1f(ent.u.uAlpha, 1); gl.uniform3fv(ent.u.uTint, tint); }

      // water (blended, back to front)
      gl.useProgram(world.p);
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.disable(gl.CULL_FACE);
      gl.uniform1f(world.u.uAlpha, 0.72);
      vis.sort((a, b) => Math.hypot((b.cx + 0.5) * CH - c.x, (b.cz + 0.5) * CH - c.z) - Math.hypot((a.cx + 0.5) * CH - c.x, (a.cz + 0.5) * CH - c.z));
      for (const m of vis) {
        if (!m.w) continue;
        gl.uniform3f(world.u.uOff, m.cx * CH - c.x, -c.y, m.cz * CH - c.z);
        gl.bindVertexArray(m.w.vao); gl.drawElements(gl.TRIANGLES, m.w.count, gl.UNSIGNED_INT, 0);
        stats.draws++; stats.tris += m.w.count / 3;
      }
      // smoke / dust (translucent voxels)
      if (f.smoke && f.smoke.n) { gl.useProgram(ent.p); gl.uniform2f(ent.u.uFogRange, fogR[0] * 2.2, fogR[1] * 2.2); gl.uniform1f(ent.u.uAlpha, 1); gl.uniform3fv(ent.u.uTint, tint); gl.uniform1f(ent.u.uEmit, 1.0); drawBatch(f.smoke); }
      gl.depthMask(true); gl.disable(gl.BLEND); gl.enable(gl.CULL_FACE);

      // first-person hand / weapon: own projection, depth cleared
      if (f.hand && f.hand.n) {
        gl.clear(gl.DEPTH_BUFFER_BIT);
        const hp = M.perspective((f.handFov || 62) * Math.PI / 180, aspect, 0.02, 10);
        const hl = [0.34 + ambSky[0] * 0.9 + sunCol[0] * 0.22, 0.34 + ambSky[1] * 0.9 + sunCol[1] * 0.22, 0.34 + ambSky[2] * 0.9 + sunCol[2] * 0.22].map((v) => Math.max(0.12, Math.min(1.6, v)));
        gl.useProgram(ent.p); gl.uniformMatrix4fv(ent.u.uVP, false, hp); gl.uniform3fv(ent.u.uTint, hl); gl.uniform1f(ent.u.uAlpha, 1); gl.uniform2f(ent.u.uFogRange, 1e6, 2e6); gl.uniform1f(ent.u.uEmit, 1.0);
        gl.disable(gl.CULL_FACE); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); drawBatch(f.hand); gl.disable(gl.BLEND); gl.enable(gl.CULL_FACE);
      }

      /* ---- post processing ---- */
      gl.disable(gl.DEPTH_TEST); gl.depthMask(false);
      let bloomOn = fx >= 1;
      if (bloomOn) {
        quad(pBright); bindTex(0, T.scene.t, pBright.u.uSrc); gl.uniform2f(pBright.u.uPx, 1 / state.w, 1 / state.h); gl.uniform1f(pBright.u.uThr, 1.05); gl.uniform1f(pBright.u.uStore, store);
        gl.bindFramebuffer(gl.FRAMEBUFFER, T.a.f); gl.viewport(0, 0, T.a.w, T.a.h); gl.drawArrays(gl.TRIANGLES, 0, 3);
        quad(pBlur);
        for (let i = 0; i < 2; i++) {
          gl.bindFramebuffer(gl.FRAMEBUFFER, T.b.f); bindTex(0, T.a.t, pBlur.u.uSrc); gl.uniform2f(pBlur.u.uDir, (1.6 + i) / T.a.w, 0); gl.drawArrays(gl.TRIANGLES, 0, 3);
          gl.bindFramebuffer(gl.FRAMEBUFFER, T.a.f); bindTex(0, T.b.t, pBlur.u.uSrc); gl.uniform2f(pBlur.u.uDir, 0, (1.6 + i) / T.a.h); gl.drawArrays(gl.TRIANGLES, 0, 3);
        }
      }
      // sun position on screen
      const sc = [vp[0] * sunDir[0] + vp[4] * sunDir[1] + vp[8] * sunDir[2], vp[1] * sunDir[0] + vp[5] * sunDir[1] + vp[9] * sunDir[2], vp[3] * sunDir[0] + vp[7] * sunDir[1] + vp[11] * sunDir[2]];
      const sunVis = sc[2] > 0.05 && sunUp > -0.02 && !uw ? 1 : 0, sunFade = ss(-0.02, 0.1, sunUp);
      quad(pCompose);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fx >= 1 ? T.ldr.f : null); gl.viewport(0, 0, state.w, state.h);
      bindTex(0, T.scene.t, pCompose.u.uScene); bindTex(1, T.scene.d, pCompose.u.uDepth); bindTex(2, bloomOn ? T.a.t : T.scene.t, pCompose.u.uBloom);
      gl.uniform2f(pCompose.u.uRes, state.w, state.h);
      gl.uniform4f(pCompose.u.uSun, sc[0] / (sc[2] || 1) * 0.5 + 0.5, sc[1] / (sc[2] || 1) * 0.5 + 0.5, sunVis, sunFade);
      gl.uniform3f(pCompose.u.uSunCol, warm[0] * day * 1.4, warm[1] * day * 1.4, warm[2] * day * 1.4);
      gl.uniform1f(pCompose.u.uStore, store); gl.uniform1f(pCompose.u.uExposure, exposure); gl.uniform1f(pCompose.u.uBloomAmt, bloomOn ? (uw ? 0.25 : 0.34) : 0);
      gl.uniform1f(pCompose.u.uRays, fx >= 2 ? 1 : 0); gl.uniform1f(pCompose.u.uFlare, fx >= 2 ? 1 : 0); gl.uniform1f(pCompose.u.uChroma, fx >= 2 ? 0.3 : 0);
      gl.uniform1f(pCompose.u.uVig, 0.42); gl.uniform1f(pCompose.u.uHurt, f.hurt || 0); gl.uniform1f(pCompose.u.uAspect, aspect); gl.uniform1f(pCompose.u.uUnder, uw ? 1 : 0);
      gl.uniform1f(pCompose.u.uFlashI, fl ? fl.i : 0); gl.uniform1f(pCompose.u.uSat, 0.98);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      if (fx >= 1) {
        quad(pFinal); gl.bindFramebuffer(gl.FRAMEBUFFER, null); bindTex(0, T.ldr.t, pFinal.u.uSrc);
        gl.uniform2f(pFinal.u.uRes, state.w, state.h); gl.uniform1f(pFinal.u.uGrain, fx >= 2 ? 1 : 0.4); gl.uniform1f(pFinal.u.uTime, f.time % 10); gl.uniform1f(pFinal.u.uFxaa, 1);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
      gl.depthMask(true); gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE);
      state.day = day; state.sunDir = sunDir; state.sunCol = sunCol; state.ambSky = ambSky;
      return { day, fog: fogDisp, sunDir, sunCol, ambSky, hdr };
    }

    /** World position -> CSS pixel position on screen (or null when behind the camera). */
    function project(x, y, z, cssW, cssH) {
      const c = state.cam, v = state.vp; if (!v) return null;
      const px = x - c.x, py = y - c.y, pz = z - c.z;
      const cx = v[0] * px + v[4] * py + v[8] * pz, cy = v[1] * px + v[5] * py + v[9] * pz, cw = v[3] * px + v[7] * py + v[11] * pz;
      if (cw <= 0.05) return null;
      return { x: (cx / cw * 0.5 + 0.5) * cssW, y: (1 - (cy / cw * 0.5 + 0.5)) * cssH, d: cw };
    }

    const info = (() => { const d = gl.getExtension("WEBGL_debug_renderer_info"); return d ? gl.getParameter(d.UNMASKED_RENDERER_WEBGL) : "webgl2"; })();
    buildTargets(2, 2); setFx(2);
    return { gl, resize, render, setChunkMesh, dropChunk, project, setFx, stats, state, meshes, Batch, xform, xformZ, mulAffine, info, meshCount: () => meshes.size, isHdr: () => hdr };
  }

  root.SSRenderer = { create, Batch, xform, xformZ, mulAffine, M };
})(window);
