/* Shadow Strike Voxel — battlefield effects: smoke, fire, brass casings, dust, distant explosions.
   Everything is drawn with the same cube batches as the rest of the game (no extra assets). */
(function (root) {
  "use strict";
  const SS = root.SSWorld, { B } = SS, xform = () => root.SSRenderer.xform;
  const rnd = Math.random, lerp = (a, b, t) => a + (b - a) * t;
  const FX = { puffs: [], casings: [], motes: [], fires: [], sources: [], fireT: 0, boomT: 40, onBoom: null };

  FX.reset = function () { FX.puffs.length = 0; FX.casings.length = 0; FX.motes.length = 0; FX.fires.length = 0; FX.sources.length = 0; FX.fireT = 0; FX.boomT = 35 + rnd() * 25; };

  /** Translucent (or glowing when l > 1.4) voxel puff that grows and fades. */
  FX.puff = function (x, y, z, o) {
    if (FX.puffs.length > 420) FX.puffs.shift();
    FX.puffs.push({ x, y, z, vx: o.vx || 0, vy: o.vy || 0, vz: o.vz || 0, life: o.life, max: o.life, s0: o.s0, s1: o.s1, c: o.c, a: o.a == null ? 0.5 : o.a, l: o.l || 1.45, r: rnd() * 6.28, drag: o.drag == null ? 0.7 : o.drag, rise: o.rise || 0 });
  };
  FX.smoke = function (x, y, z, n, dark) {
    for (let i = 0; i < n; i++) { const g = dark ? 0.06 + rnd() * 0.05 : 0.5 + rnd() * 0.2; FX.puff(x + (rnd() - 0.5) * 0.3, y + rnd() * 0.2, z + (rnd() - 0.5) * 0.3, { vx: (rnd() - 0.5) * 0.8 + 0.3, vy: 0.5 + rnd() * 1.2, vz: (rnd() - 0.5) * 0.8, life: 2.5 + rnd() * 2.5, s0: 0.12, s1: 0.9 + rnd() * 0.7, c: [g, g * 0.97, g * 0.95], a: dark ? 0.55 : 0.32, drag: 0.5 }); }
  };
  /** A burst of dust where a bullet hits a wall. */
  FX.impact = function (x, y, z, c) {
    for (let i = 0; i < 3; i++) FX.puff(x, y, z, { vx: (rnd() - 0.5) * 1.2, vy: 0.4 + rnd() * 0.8, vz: (rnd() - 0.5) * 1.2, life: 0.6 + rnd() * 0.4, s0: 0.05, s1: 0.2 + rnd() * 0.12, c: [c[0] * 0.8 + 0.12, c[1] * 0.8 + 0.12, c[2] * 0.8 + 0.12], a: 0.3 });
    for (let i = 0; i < 5; i++) FX.puff(x, y, z, { vx: (rnd() - 0.5) * 7, vy: rnd() * 5, vz: (rnd() - 0.5) * 7, life: 0.2 + rnd() * 0.18, s0: 0.03, s1: 0.012, c: [1, 0.78, 0.35], a: 1, l: 3, drag: 0.2 });
  };
  FX.muzzleSmoke = function (x, y, z, dx, dy, dz) { FX.puff(x, y, z, { vx: dx * 1.5 + (rnd() - 0.5) * 0.4, vy: dy * 1.5 + 0.35, vz: dz * 1.5 + (rnd() - 0.5) * 0.4, life: 0.9, s0: 0.03, s1: 0.28, c: [0.62, 0.6, 0.58], a: 0.28, drag: 1.6 }); };

  /** Ejected brass: tumbles, bounces and then stays on the ground. */
  FX.casing = function (x, y, z, vx, vy, vz) { if (FX.casings.length > 130) FX.casings.shift(); FX.casings.push({ x, y, z, vx, vy, vz, a: rnd() * 6.28, b: rnd() * 6.28, sa: (rnd() - 0.5) * 30, sb: 12 + rnd() * 18, rest: false, age: 0 }); };

  FX.explode = function (cam, world) {
    const ang = rnd() * 6.2832, d = 62 + rnd() * 38, x = cam.x + Math.cos(ang) * d, z = cam.z + Math.sin(ang) * d, y = world.heightAt(Math.floor(x), Math.floor(z)) + 1;
    for (let i = 0; i < 22; i++) FX.puff(x + (rnd() - 0.5) * 5, y + rnd() * 3, z + (rnd() - 0.5) * 5, { vx: (rnd() - 0.5) * 9, vy: 5 + rnd() * 13, vz: (rnd() - 0.5) * 9, life: 0.7 + rnd() * 0.9, s0: 1.6, s1: 6 + rnd() * 4, c: [1, 0.5 + rnd() * 0.25, 0.1], a: 0.95, l: 2.6, drag: 0.4 });
    for (let i = 0; i < 60; i++) FX.puff(x + (rnd() - 0.5) * 6, y + 1 + rnd() * 4, z + (rnd() - 0.5) * 6, { vx: (rnd() - 0.5) * 6, vy: 3 + rnd() * 7, vz: (rnd() - 0.5) * 6, life: 7 + rnd() * 5, s0: 0.6, s1: 1.2 + rnd() * 1.1, c: [0.13, 0.12, 0.11], a: 0.3, drag: 0.35 });
    for (let i = 0; i < 30; i++) FX.puff(x, y + 1, z, { vx: (rnd() - 0.5) * 36, vy: 6 + rnd() * 26, vz: (rnd() - 0.5) * 36, life: 0.6 + rnd() * 0.8, s0: 0.35, s1: 0.1, c: [1, 0.6, 0.2], a: 1, l: 3, drag: 0.1 });
    FX.sources.push({ x, y, z, t: 16 });
    if (FX.onBoom) FX.onBoom(d);
  };

  function scanFires(world, cam) {
    FX.fires.length = 0; const pcx = Math.floor(cam.x) >> 4, pcz = Math.floor(cam.z) >> 4;
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      const c = world.chunks.get((pcx + dx) + "," + (pcz + dz)); if (!c) continue;
      for (const l of c.lamps) { if (world.peek(Math.floor(l[0]), Math.floor(l[1]), Math.floor(l[2])) === B.FIRE) { const d = Math.hypot(l[0] - cam.x, l[2] - cam.z); if (d < 46) FX.fires.push([l[0], l[1], l[2], d]); } }
    }
    FX.fires.sort((a, b) => a[3] - b[3]); if (FX.fires.length > 12) FX.fires.length = 12;
  }

  FX.update = function (dt, world, cam, day) {
    // brass
    for (let i = FX.casings.length - 1; i >= 0; i--) {
      const c = FX.casings[i]; c.age += dt;
      if (c.age > 50) { FX.casings.splice(i, 1); continue; }
      if (c.rest) continue;
      c.vy -= 9.8 * dt; c.x += c.vx * dt; c.y += c.vy * dt; c.z += c.vz * dt; c.a += c.sa * dt; c.b += c.sb * dt;
      if (world.solid(Math.floor(c.x), Math.floor(c.y - 0.012), Math.floor(c.z))) {
        c.y = Math.floor(c.y - 0.012) + 1.012;
        if (c.vy < -0.8) { c.vy = -c.vy * 0.32; c.vx *= 0.5; c.vz *= 0.5; c.sa *= 0.5; c.sb *= 0.4; if (Math.hypot(c.x - cam.x, c.z - cam.z) < 12 && rnd() < 0.7) root.SSAudio.play("casing"); }
        else { c.rest = true; c.b = 0; c.vy = 0; }
      }
    }
    // puffs
    for (let i = FX.puffs.length - 1; i >= 0; i--) {
      const p = FX.puffs[i]; p.life -= dt; if (p.life <= 0) { FX.puffs.splice(i, 1); continue; }
      const k = Math.exp(-p.drag * dt); p.vx *= k; p.vy *= k; p.vz *= k; p.vy += p.rise * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    }
    // emitters: burning barrels + explosion columns
    FX.fireT -= dt; if (FX.fireT <= 0) { FX.fireT = 1; scanFires(world, cam); }
    if (FX.puffs.length < 330) for (const f of FX.fires) {
      if (rnd() < dt * 16) FX.puff(f[0] + (rnd() - 0.5) * 0.5, f[1] + 0.35, f[2] + (rnd() - 0.5) * 0.5, { vx: (rnd() - 0.5) * 0.4, vy: 1.4 + rnd() * 1.2, vz: (rnd() - 0.5) * 0.4, life: 0.45 + rnd() * 0.35, s0: 0.2, s1: 0.04, c: [1, 0.45 + rnd() * 0.3, 0.08], a: 0.9, l: 2.4, drag: 0.5 });
      if (rnd() < dt * 6) FX.puff(f[0] + (rnd() - 0.5) * 0.3, f[1] + 0.9, f[2] + (rnd() - 0.5) * 0.3, { vx: 0.5 + rnd() * 0.5, vy: 1.3 + rnd(), vz: (rnd() - 0.5) * 0.4, life: 3.5 + rnd() * 2, s0: 0.08, s1: 0.4 + rnd() * 0.3, c: [0.15, 0.145, 0.14], a: 0.3, drag: 0.3 });
      if (rnd() < dt * 3.5) FX.puff(f[0] + (rnd() - 0.5) * 0.4, f[1] + 0.6, f[2] + (rnd() - 0.5) * 0.4, { vx: (rnd() - 0.5) * 1.2 + 0.5, vy: 2 + rnd() * 2, vz: (rnd() - 0.5) * 1.2, life: 1.2 + rnd(), s0: 0.025, s1: 0.012, c: [1, 0.6, 0.2], a: 1, l: 3, drag: 0.15 });
    }
    for (let i = FX.sources.length - 1; i >= 0; i--) {
      const s = FX.sources[i]; s.t -= dt; if (s.t <= 0) { FX.sources.splice(i, 1); continue; }
      if (rnd() < dt * 14) FX.puff(s.x + (rnd() - 0.5) * 3, s.y + 1, s.z + (rnd() - 0.5) * 3, { vx: 0.7, vy: 4 + rnd() * 3, vz: 0.2, life: 7 + rnd() * 3, s0: 0.5, s1: 1.0 + rnd() * 0.9, c: [0.13, 0.12, 0.11], a: 0.3, drag: 0.3 });
      if (rnd() < dt * 6) FX.puff(s.x + (rnd() - 0.5) * 2.5, s.y + rnd() * 2, s.z + (rnd() - 0.5) * 2.5, { vx: (rnd() - 0.5), vy: 2 + rnd() * 2, vz: (rnd() - 0.5), life: 0.8 + rnd() * 0.6, s0: 0.7, s1: 0.15, c: [1, 0.45, 0.1], a: 0.9, l: 2.5, drag: 0.4 });
    }
    // drifting dust motes in the light
    if (day > 0.25) {
      while (FX.motes.length < 44) FX.motes.push({ x: cam.x + (rnd() - 0.5) * 16, y: cam.y + (rnd() - 0.5) * 6, z: cam.z + (rnd() - 0.5) * 16, vx: 0, vy: 0, vz: 0, ph: rnd() * 6 });
      for (const m of FX.motes) { m.ph += dt; m.x += (0.18 + Math.sin(m.ph * 0.7) * 0.12) * dt; m.y += Math.sin(m.ph * 0.9) * 0.08 * dt - 0.015 * dt; m.z += Math.cos(m.ph * 0.5) * 0.1 * dt; if (Math.hypot(m.x - cam.x, m.y - cam.y, m.z - cam.z) > 9) { m.x = cam.x + (rnd() - 0.5) * 14; m.y = cam.y + (rnd() - 0.5) * 5; m.z = cam.z + (rnd() - 0.5) * 14; } }
    } else FX.motes.length = 0;
    // far-away artillery: purely atmospheric
    FX.boomT -= dt; if (FX.boomT <= 0) { FX.boomT = 28 + rnd() * 40; FX.explode(cam, world); }
  };

  /** Appends casings, dust and puffs to the particle batches (camera-relative). */
  FX.build = function (cam, parts, smoke) {
    const X = xform();
    for (const c of FX.casings) parts.box(X(c.x - cam.x, c.y - cam.y, c.z - cam.z, c.a, c.rest ? 0 : c.b), -0.0065, -0.0065, -0.02, 0.0065, 0.0065, 0.02, 0.86, 0.6, 0.2, 1.1);
    for (const m of FX.motes) parts.box([1, 0, 0, m.x - cam.x, 0, 1, 0, m.y - cam.y, 0, 0, 1, m.z - cam.z], -0.01, -0.01, -0.01, 0.01, 0.01, 0.01, 1, 0.9, 0.72, 1.5, 0.55);
    for (const p of FX.puffs) {
      const u = 1 - p.life / p.max, s = lerp(p.s0, p.s1, Math.sqrt(u)), al = p.a * Math.min(1, u * 6) * Math.min(1, p.life / (p.max * 0.55));
      if (al < 0.01) continue;
      smoke.box(X(p.x - cam.x, p.y - cam.y, p.z - cam.z, p.r + u, 0), -s, -s, -s, s, s, s, p.c[0], p.c[1], p.c[2], p.l, al);
    }
  };

  root.SSFx = FX;
})(window);
