/* Shadow Strike Voxel — turns a chunk of blocks into GPU-ready triangles.
   Per vertex: x,y,z (chunk-local), u,v, sky light, block light, shade (face direction x ambient occlusion). */
(function (root) {
  "use strict";
  const SS = root.SSWorld, { CH, HT, B, DEF } = SS;
  const COLS = 8, ROWS = 4, FLOATS = 8, WATER_H = 0.88;
  const AO = [0.52, 0.68, 0.84, 1.0];

  /* ---------- face table ---------- */
  const FACES = [];
  [[0, 1, 2, 1], [0, -1, 2, 1], [1, 1, 0, 2], [1, -1, 0, 2], [2, 1, 0, 1], [2, -1, 0, 1]].forEach(([a, s, ua, va], f) => {
    const corners = [[0, 0], [1, 0], [1, 1], [0, 1]];
    const pos = (c) => { const p = [0, 0, 0]; p[a] = s > 0 ? 1 : 0; p[ua] = c[0]; p[va] = c[1]; return p; };
    const p0 = pos(corners[0]), p1 = pos(corners[1]), p2 = pos(corners[2]);
    const e1 = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]], e2 = [p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]];
    const n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
    const flip = n[a] * s < 0;
    FACES.push({ a, s, ua, va, order: flip ? [0, 3, 2, 1] : [0, 1, 2, 3], corners, shade: a === 1 ? (s > 0 ? 1 : 0.5) : a === 0 ? 0.72 : 0.86, side: a !== 1, tileSel: a === 1 ? (s > 0 ? 0 : 1) : 2 });
  });

  /* ---------- growable output buffers ---------- */
  function Builder() { this.v = new Float32Array(1 << 18); this.i = new Uint32Array(1 << 17); this.vn = 0; this.in = 0; this.base = 0; }
  Builder.prototype.reset = function () { this.vn = 0; this.in = 0; this.base = 0; };
  Builder.prototype.ensure = function () {
    if (this.vn + 4 * FLOATS > this.v.length) { const n = new Float32Array(this.v.length * 2); n.set(this.v); this.v = n; }
    if (this.in + 6 > this.i.length) { const n = new Uint32Array(this.i.length * 2); n.set(this.i); this.i = n; }
  };
  const OP = new Builder(), WT = new Builder();

  const gOp = new Uint8Array(9), gSky = new Float32Array(9), gBlk = new Float32Array(9), O = [0, 0, 0];
  const vSky = [0, 0, 0, 0], vBlk = [0, 0, 0, 0], vShade = [0, 0, 0, 0];

  function meshChunk(world, ch) {
    const nb = new Array(9);
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) nb[(dz + 1) * 3 + dx + 1] = world.chunks.get((ch.cx + dx) + "," + (ch.cz + dz)) || null;
    return meshFrom(ch.cx, ch.cz, nb);
  }
  /** nb: 9 chunk-likes ({data, top, lamps} or null), row-major around the chunk at index 4. Also runs inside a Web Worker. */
  function meshFrom(cx, cz, nb) {
    const nbD = new Array(9), nbT = new Array(9), lamps = [];
    for (let k = 0; k < 9; k++) { const c = nb[k]; nbD[k] = c ? c.data : null; nbT[k] = c ? c.top : null; if (c) for (const l of c.lamps) lamps.push(l); }
    const bl = (x, y, z) => {
      if (y < 0) return B.BEDROCK;
      if (y >= HT) return B.AIR;
      const a = nbD[((z < 0 ? 0 : z >= CH ? 2 : 1) * 3) + (x < 0 ? 0 : x >= CH ? 2 : 1)];
      return a ? a[(y * CH + (z & 15)) * CH + (x & 15)] : B.STONE; // unloaded neighbour: pretend solid so no border faces are drawn
    };
    const topAt = (x, z) => { const t = nbT[((z < 0 ? 0 : z >= CH ? 2 : 1) * 3) + (x < 0 ? 0 : x >= CH ? 2 : 1)]; return t ? t[(z & 15) * CH + (x & 15)] : 0; };
    const sky = (x, y, z) => { const t = topAt(x, z); return y > t ? 1 : Math.max(0.025, 0.82 - (t - y) * 0.19); };
    const wx0 = cx * CH + 0.5, wz0 = cz * CH + 0.5, hasLamps = lamps.length > 0;
    const blk = (x, y, z) => {
      let best = 0;
      for (let i = 0; i < lamps.length; i++) { const l = lamps[i], d = Math.hypot(wx0 + x - l[0] - 0.0, y + 0.5 - l[1], wz0 + z - l[2]); if (d < 11) { const v = 1 - d / 11; if (v > best) best = v; } }
      return Math.min(1, best * 1.25);
    };
    OP.reset(); WT.reset();
    const data = nb[4].data, chTop = nb[4].top;
    let maxY = 0; for (let i = 0; i < 256; i++) if (chTop[i] > maxY) maxY = chTop[i];
    maxY = Math.min(HT - 1, maxY + 1);

    for (let y = 0; y <= maxY; y++) for (let z = 0; z < CH; z++) for (let x = 0; x < CH; x++) {
      const id = data[(y * CH + z) * CH + x];
      if (id === B.AIR) continue;
      const d = DEF[id], isWater = id === B.WATER;
      for (let f = 0; f < 6; f++) {
        const F = FACES[f];
        O[0] = x; O[1] = y; O[2] = z; O[F.a] += F.s;
        const nid = bl(O[0], O[1], O[2]);
        if (isWater) { if ((F.a === 1 && F.s < 0) || nid === B.WATER || DEF[nid].opaque) continue; }
        else {
          if (DEF[nid].opaque) continue;
          if (nid === id && (id === B.GLASS || id === B.LEAVES)) continue;
        }
        // light + occlusion samples for the 3x3 cells in the layer in front of the face
        const a = F.a, ua = F.ua, va = F.va;
        for (let kv = -1; kv <= 1; kv++) for (let ku = -1; ku <= 1; ku++) {
          const gi = (kv + 1) * 3 + ku + 1;
          O[0] = x; O[1] = y; O[2] = z; O[a] += F.s; O[ua] += ku; O[va] += kv;
          const oid = bl(O[0], O[1], O[2]), op = DEF[oid].opaque ? 1 : 0;
          gOp[gi] = op;
          if (op) { gSky[gi] = 0; gBlk[gi] = 0; } else { gSky[gi] = sky(O[0], O[1], O[2]); gBlk[gi] = hasLamps ? blk(O[0], O[1], O[2]) : 0; }
        }
        const emit = d.light ? 1 : 0;
        for (let k = 0; k < 4; k++) {
          const c = F.corners[k], su = c[0] ? 1 : -1, sv = c[1] ? 1 : -1;
          const i1 = 3 + su + 1, i2 = (sv + 1) * 3 + 1, ic = (sv + 1) * 3 + su + 1, in_ = 4;
          const ao = (gOp[i1] && gOp[i2]) ? 0 : 3 - (gOp[i1] + gOp[i2] + gOp[ic]);
          let s = 0, b = 0, n = 0;
          if (!gOp[in_]) { s += gSky[in_]; b += gBlk[in_]; n++; }
          if (!gOp[i1]) { s += gSky[i1]; b += gBlk[i1]; n++; }
          if (!gOp[i2]) { s += gSky[i2]; b += gBlk[i2]; n++; }
          if (!gOp[ic]) { s += gSky[ic]; b += gBlk[ic]; n++; }
          vSky[k] = n ? s / n : 0; vBlk[k] = emit ? 1 : (n ? b / n : 0);
          vShade[k] = isWater ? (F.a === 1 ? 1 : 0.9) : F.shade * (emit ? 1 : AO[ao]);
        }
        const tile = d.tiles[F.tileSel], tx = tile % COLS, ty = (tile / COLS) | 0, bld = isWater ? WT : OP;
        bld.ensure();
        const v = bld.v;
        let vn = bld.vn;
        for (let k = 0; k < 4; k++) {
          const c = F.corners[k], p = O; // reuse O for position
          p[0] = x; p[1] = y; p[2] = z;
          p[F.a] += F.s > 0 ? 1 : 0; p[F.ua] += c[0]; p[F.va] += c[1];
          let py = p[1];
          if (isWater) { if (F.a === 1) py = y + WATER_H; else if (c[1]) py = y + WATER_H; }
          v[vn++] = p[0]; v[vn++] = py; v[vn++] = p[2];
          v[vn++] = (tx + (c[0] ? 0.999 : 0.001)) / COLS;
          v[vn++] = (ty + (F.side ? (c[1] ? 0.001 : 0.999) : (c[1] ? 0.999 : 0.001))) / ROWS;
          v[vn++] = vSky[k]; v[vn++] = vBlk[k]; v[vn++] = vShade[k];
        }
        bld.vn = vn;
        // quads are split along the brighter diagonal so ambient occlusion stays smooth
        const o = F.order, base = bld.base, a0 = base + o[0], a1 = base + o[1], a2 = base + o[2], a3 = base + o[3];
        const sw = (vShade[o[0]] + vShade[o[2]]) < (vShade[o[1]] + vShade[o[3]]);
        const ib = bld.i; let ip = bld.in;
        if (sw) { ib[ip++] = a1; ib[ip++] = a2; ib[ip++] = a3; ib[ip++] = a1; ib[ip++] = a3; ib[ip++] = a0; }
        else { ib[ip++] = a0; ib[ip++] = a1; ib[ip++] = a2; ib[ip++] = a0; ib[ip++] = a2; ib[ip++] = a3; }
        bld.in = ip; bld.base = base + 4;
      }
    }
    return { opaque: pack(OP), water: pack(WT) };
  }
  /** Copies a builder into tight typed arrays. */
  function pack(bld) {
    if (!bld.in) return null;
    return { v: bld.v.slice(0, bld.vn), i: bld.i.slice(0, bld.in) };
  }

  root.SSMesher = { meshChunk, meshFrom, FLOATS, FACES };
})(typeof window !== "undefined" ? window : self);
