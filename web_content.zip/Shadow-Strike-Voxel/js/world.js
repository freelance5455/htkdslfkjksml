/* Shadow Strike Voxel — shared world code.
   Runs unchanged in the browser (client + host-in-browser) and in Node (dedicated server), so every
   player sees exactly the same terrain from the same seed. Only player edits travel over the network. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.SSWorld = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const CH = 16, HT = 64, SEA = 22, CSIZE = CH * CH * HT;

  /* ---------- blocks ---------- */
  const B = { AIR: 0, GRASS: 1, DIRT: 2, STONE: 3, SAND: 4, LOG: 5, LEAVES: 6, PLANKS: 7, GLASS: 8, BRICK: 9, WATER: 10, COBBLE: 11, SNOW: 12, BEDROCK: 13, COAL: 14, LAMP: 15, SANDSTONE: 16, GRAVEL: 17 };
  // tiles = [top, bottom, side] indices in the generated texture atlas
  const DEF = [];
  function def(id, o) { DEF[id] = Object.assign({ id, solid: true, opaque: true, light: 0, hard: 1, tiles: [0, 0, 0], snd: "stone", name: "" }, o); }
  def(B.AIR, { name: "هوا", solid: false, opaque: false, hard: 0 });
  def(B.GRASS, { name: "چمن", tiles: [0, 2, 1], hard: 0.7, snd: "grass" });
  def(B.DIRT, { name: "خاک", tiles: [2, 2, 2], hard: 0.6, snd: "grass" });
  def(B.STONE, { name: "سنگ", tiles: [3, 3, 3], hard: 1.8, snd: "stone" });
  def(B.SAND, { name: "ماسه", tiles: [4, 4, 4], hard: 0.5, snd: "sand" });
  def(B.LOG, { name: "تنه درخت", tiles: [6, 6, 5], hard: 1.6, snd: "wood" });
  def(B.LEAVES, { name: "برگ", tiles: [7, 7, 7], opaque: false, hard: 0.25, snd: "grass" });
  def(B.PLANKS, { name: "تخته", tiles: [8, 8, 8], hard: 1.3, snd: "wood" });
  def(B.GLASS, { name: "شیشه", tiles: [9, 9, 9], opaque: false, hard: 0.4, snd: "glass" });
  def(B.BRICK, { name: "آجر", tiles: [10, 10, 10], hard: 2.0, snd: "stone" });
  def(B.WATER, { name: "آب", tiles: [11, 11, 11], solid: false, opaque: false, hard: 0, snd: "water" });
  def(B.COBBLE, { name: "قلوه‌سنگ", tiles: [12, 12, 12], hard: 1.8, snd: "stone" });
  def(B.SNOW, { name: "برف", tiles: [13, 2, 14], hard: 0.35, snd: "sand" });
  def(B.BEDROCK, { name: "سنگ بنیادی", tiles: [15, 15, 15], hard: 999, snd: "stone" });
  def(B.COAL, { name: "سنگ زغال", tiles: [16, 16, 16], hard: 2.2, snd: "stone" });
  def(B.LAMP, { name: "چراغ", tiles: [17, 17, 17], light: 1, hard: 0.5, snd: "glass" });
  def(B.SANDSTONE, { name: "ماسه‌سنگ", tiles: [18, 18, 18], hard: 1.2, snd: "stone" });
  def(B.GRAVEL, { name: "شن", tiles: [19, 19, 19], hard: 0.6, snd: "sand" });
  const PLACEABLE = [B.GRASS, B.DIRT, B.STONE, B.COBBLE, B.SAND, B.GRAVEL, B.LOG, B.PLANKS, B.BRICK, B.GLASS, B.SANDSTONE, B.SNOW, B.LAMP, B.LEAVES, B.COAL];

  /* ---------- noise ---------- */
  function hash2(x, z, s) {
    let h = (Math.imul(x, 374761393) + Math.imul(z, 668265263) + Math.imul(s, 1442695041)) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  function hash3(x, y, z, s) {
    let h = (Math.imul(x, 374761393) + Math.imul(y, 1103515245) + Math.imul(z, 668265263) + Math.imul(s, 1442695041)) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  const sm = (t) => t * t * (3 - 2 * t);
  function noise2(x, z, s) {
    const x0 = Math.floor(x), z0 = Math.floor(z), fx = sm(x - x0), fz = sm(z - z0);
    const a = hash2(x0, z0, s), b = hash2(x0 + 1, z0, s), c = hash2(x0, z0 + 1, s), d = hash2(x0 + 1, z0 + 1, s);
    return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
  }
  function noise3(x, y, z, s) {
    const x0 = Math.floor(x), y0 = Math.floor(y), z0 = Math.floor(z), fx = sm(x - x0), fy = sm(y - y0), fz = sm(z - z0);
    const l = (a, b, t) => a + (b - a) * t;
    const c00 = l(hash3(x0, y0, z0, s), hash3(x0 + 1, y0, z0, s), fx), c10 = l(hash3(x0, y0 + 1, z0, s), hash3(x0 + 1, y0 + 1, z0, s), fx);
    const c01 = l(hash3(x0, y0, z0 + 1, s), hash3(x0 + 1, y0, z0 + 1, s), fx), c11 = l(hash3(x0, y0 + 1, z0 + 1, s), hash3(x0 + 1, y0 + 1, z0 + 1, s), fx);
    return l(l(c00, c10, fy), l(c01, c11, fy), fz);
  }
  function fbm2(x, z, s, oct) {
    let a = 0, amp = 0.5, f = 1, n = 0;
    for (let i = 0; i < oct; i++) { a += amp * noise2(x * f, z * f, s + i * 31); n += amp; amp *= 0.5; f *= 2; }
    return a / n;
  }
  function seedFrom(v) {
    if (typeof v === "number" && isFinite(v)) return v | 0;
    const str = String(v == null ? "" : v);
    if (/^-?\d+$/.test(str)) return parseInt(str, 10) | 0;
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h | 0;
  }

  const BIOME = { PLAINS: 0, FOREST: 1, DESERT: 2, SNOW: 3 };

  class Chunk {
    constructor(cx, cz) {
      this.cx = cx; this.cz = cz;
      this.data = new Uint8Array(CSIZE);
      this.top = new Uint8Array(CH * CH); // highest light-blocking block per column
      this.lamps = [];
      this.mesh = null; this.dirty = true; this.version = 0;
    }
  }

  class World {
    constructor(seed) {
      this.seed = seedFrom(seed);
      this.chunks = new Map();
      this.editsByChunk = new Map(); // "cx,cz" -> Map(index -> id)
      this.editCount = 0;
      this.onChange = null; // (x,y,z,id) -> void, used by the renderer to remesh
      this.onChunk = null;  // (chunk) -> void, new chunk generated
    }

    /* ----- terrain ----- */
    heightAt(x, z) {
      const s = this.seed;
      const base = fbm2(x * 0.0065, z * 0.0065, s + 1, 4);
      const hills = fbm2(x * 0.022, z * 0.022, s + 2, 3);
      const mount = Math.max(0, fbm2(x * 0.0045 + 50, z * 0.0045 - 50, s + 3, 3) - 0.56) * 3;
      const detail = fbm2(x * 0.07, z * 0.07, s + 8, 2);
      const h = 4.5 + base * 31 + hills * 9 + detail * 4 + mount * 30;
      return Math.max(3, Math.min(HT - 9, Math.floor(h)));
    }
    biomeAt(x, z) {
      const s = this.seed;
      const t = fbm2(x * 0.0035 + 300, z * 0.0035 + 300, s + 4, 3), m = fbm2(x * 0.004 - 300, z * 0.004, s + 5, 3);
      if (t > 0.65 && m < 0.5) return BIOME.DESERT;
      if (t < 0.35) return BIOME.SNOW;
      if (m > 0.58) return BIOME.FOREST;
      return BIOME.PLAINS;
    }
    isCave(x, y, z) {
      const s = this.seed;
      const a = noise3(x * 0.045, y * 0.07, z * 0.045, s + 6), b = noise3(x * 0.045 + 97, y * 0.07 + 31, z * 0.045 - 53, s + 7);
      return Math.abs(a - 0.5) < 0.065 && Math.abs(b - 0.5) < 0.065;
    }
    /** Tree whose trunk stands on column (x,z), or null. */
    treeAt(x, z) {
      const bio = this.biomeAt(x, z), p = bio === BIOME.FOREST ? 0.045 : bio === BIOME.PLAINS ? 0.007 : bio === BIOME.SNOW ? 0.01 : 0;
      if (!p || hash2(x, z, this.seed + 11) >= p) return null;
      const h = this.heightAt(x, z);
      if (h <= SEA + 1 || h > 44) return null;
      return { y: h + 1, th: 4 + Math.floor(hash2(x, z, this.seed + 12) * 3) };
    }

    generate(cx, cz) {
      const ch = new Chunk(cx, cz), d = ch.data, x0 = cx * CH, z0 = cz * CH;
      for (let lz = 0; lz < CH; lz++) for (let lx = 0; lx < CH; lx++) {
        const x = x0 + lx, z = z0 + lz, h = this.heightAt(x, z), bio = this.biomeAt(x, z);
        let top = B.GRASS, sub = B.DIRT, subDepth = 3;
        if (bio === BIOME.DESERT) { top = B.SAND; sub = B.SANDSTONE; subDepth = 4; }
        else if (bio === BIOME.SNOW) top = B.SNOW;
        if (h > 50) { top = B.SNOW; sub = B.STONE; } else if (h > 42) { top = B.STONE; sub = B.STONE; }
        if (h <= SEA + 1 && bio !== BIOME.DESERT) { top = B.SAND; sub = B.SAND; subDepth = 2; }
        if (h <= SEA - 3) { top = B.GRAVEL; sub = B.GRAVEL; subDepth = 2; }
        for (let y = 0; y <= h; y++) {
          let id;
          if (y === 0) id = B.BEDROCK;
          else if (y === h) id = top;
          else if (y >= h - subDepth) id = sub;
          else id = hash3(x, y, z, this.seed + 9) < 0.012 && y < h - 3 ? B.COAL : B.STONE;
          if (id === B.STONE || id === B.COAL) { if (y > 3 && y < h - 1 && this.isCave(x, y, z)) id = B.AIR; }
          d[(y * CH + lz) * CH + lx] = id;
        }
        for (let y = h + 1; y <= SEA; y++) d[(y * CH + lz) * CH + lx] = B.WATER;
      }
      // trees may overhang from neighbouring columns, so look 2 blocks past the chunk border
      for (let z = z0 - 2; z < z0 + CH + 2; z++) for (let x = x0 - 2; x < x0 + CH + 2; x++) {
        const t = this.treeAt(x, z);
        if (!t) continue;
        const put = (px, py, pz, id, onlyAir) => {
          const lx = px - x0, lz = pz - z0;
          if (lx < 0 || lx >= CH || lz < 0 || lz >= CH || py < 0 || py >= HT) return;
          const i = (py * CH + lz) * CH + lx;
          if (onlyAir && d[i] !== B.AIR) return;
          d[i] = id;
        };
        const top = t.y + t.th;
        for (let ly = top - 2; ly <= top + 1; ly++) {
          const r = ly >= top ? 1 : 2;
          for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
            if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
            if (ly === top + 1 && Math.abs(dx) + Math.abs(dz) > 1) continue;
            put(x + dx, ly, z + dz, B.LEAVES, true);
          }
        }
        for (let ly = t.y; ly < top; ly++) put(x, ly, z, B.LOG, false);
      }
      // remembered player edits
      const ed = this.editsByChunk.get(cx + "," + cz);
      if (ed) ed.forEach((id, i) => { d[i] = id; });
      this.computeTops(ch);
      return ch;
    }
    computeTops(ch) {
      const d = ch.data; ch.lamps.length = 0;
      for (let lz = 0; lz < CH; lz++) for (let lx = 0; lx < CH; lx++) {
        let top = 0;
        for (let y = HT - 1; y >= 0; y--) { const id = d[(y * CH + lz) * CH + lx]; if (id !== B.AIR && id !== B.GLASS) { top = y; break; } }
        ch.top[lz * CH + lx] = top;
      }
      for (let i = 0; i < CSIZE; i++) if (d[i] === B.LAMP) { const lx = i % CH, lz = ((i / CH) | 0) % CH, y = (i / (CH * CH)) | 0; ch.lamps.push([ch.cx * CH + lx + 0.5, y + 0.5, ch.cz * CH + lz + 0.5]); }
    }

    /* ----- access ----- */
    chunkAt(cx, cz, create) {
      const k = cx + "," + cz;
      let c = this.chunks.get(k);
      if (!c && create) { c = this.generate(cx, cz); this.chunks.set(k, c); if (this.onChunk) this.onChunk(c); }
      return c || null;
    }
    get(x, y, z) {
      if (y < 0) return B.BEDROCK;
      if (y >= HT) return B.AIR;
      const c = this.chunkAt(x >> 4, z >> 4, true);
      return c.data[(y * CH + (z & 15)) * CH + (x & 15)];
    }
    /** Like get() but never generates: returns -1 for chunks that are not loaded yet. */
    peek(x, y, z) {
      if (y < 0) return B.BEDROCK;
      if (y >= HT) return B.AIR;
      const c = this.chunks.get((x >> 4) + "," + (z >> 4));
      return c ? c.data[(y * CH + (z & 15)) * CH + (x & 15)] : -1;
    }
    set(x, y, z, id, silent) {
      if (y < 1 || y >= HT) return false;
      const cx = x >> 4, cz = z >> 4, c = this.chunkAt(cx, cz, true), lx = x & 15, lz = z & 15, i = (y * CH + lz) * CH + lx;
      if (c.data[i] === id) return false;
      c.data[i] = id;
      const k = cx + "," + cz;
      let ed = this.editsByChunk.get(k);
      if (!ed) { ed = new Map(); this.editsByChunk.set(k, ed); }
      if (!ed.has(i)) this.editCount++;
      ed.set(i, id);
      // column light height + lamp list
      let top = 0;
      for (let yy = HT - 1; yy >= 0; yy--) { const b = c.data[(yy * CH + lz) * CH + lx]; if (b !== B.AIR && b !== B.GLASS) { top = yy; break; } }
      c.top[lz * CH + lx] = top;
      c.lamps = c.lamps.filter((l) => !(l[0] === x + 0.5 && l[1] === y + 0.5 && l[2] === z + 0.5));
      if (id === B.LAMP) c.lamps.push([x + 0.5, y + 0.5, z + 0.5]);
      c.dirty = true; c.version++;
      if (!silent && this.onChange) this.onChange(x, y, z, id);
      return true;
    }
    solid(x, y, z) { const id = this.get(x, y, z); return DEF[id].solid; }

    exportEdits() {
      const out = [];
      this.editsByChunk.forEach((ed, k) => {
        const [cx, cz] = k.split(",").map(Number);
        ed.forEach((id, i) => out.push([cx * CH + (i % CH), (i / (CH * CH)) | 0, cz * CH + (((i / CH) | 0) % CH), id]));
      });
      return out;
    }
    importEdits(list, silent) { for (const e of list) this.set(e[0], e[1], e[2], e[3], silent); }

    spawnPoint() {
      for (let pass = 0; pass < 2; pass++) for (let r = 0; r < 600; r += 4) for (let a = 0; a < 8; a++) {
        const x = Math.round(Math.cos(a * 0.785) * r), z = Math.round(Math.sin(a * 0.785) * r), h = this.heightAt(x, z), bio = this.biomeAt(x, z);
        if (h > SEA + 1 && h < 40 && (pass === 1 || bio === BIOME.PLAINS || bio === BIOME.FOREST)) {
          let y = HT - 1;
          while (y > 1 && this.get(x, y, z) === B.AIR) y--;
          return { x: x + 0.5, y: y + 1.01, z: z + 0.5 };
        }
      }
      return { x: 0.5, y: this.heightAt(0, 0) + 2, z: 0.5 };
    }
    /** Highest solid block under (x,z), used for spawning mobs. */
    groundY(x, z, fromY) {
      let y = Math.min(HT - 1, fromY == null ? HT - 1 : fromY);
      while (y > 0 && !DEF[this.get(x, y, z)].solid) y--;
      return y;
    }

    /** Voxel ray (Amanatides & Woo). Returns the first solid block, or null. */
    raycast(ox, oy, oz, dx, dy, dz, maxDist, opts) {
      const liquids = opts && opts.liquids;
      const len = Math.hypot(dx, dy, dz) || 1; dx /= len; dy /= len; dz /= len;
      let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
      const sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
      const tdx = dx !== 0 ? Math.abs(1 / dx) : Infinity, tdy = dy !== 0 ? Math.abs(1 / dy) : Infinity, tdz = dz !== 0 ? Math.abs(1 / dz) : Infinity;
      let tx = dx !== 0 ? ((dx > 0 ? x + 1 - ox : ox - x)) * tdx : Infinity;
      let ty = dy !== 0 ? ((dy > 0 ? y + 1 - oy : oy - y)) * tdy : Infinity;
      let tz = dz !== 0 ? ((dz > 0 ? z + 1 - oz : oz - z)) * tdz : Infinity;
      let nx = 0, ny = 0, nz = 0, t = 0;
      for (let i = 0; i < 400 && t <= maxDist; i++) {
        const id = this.get(x, y, z);
        if (id !== B.AIR && (DEF[id].solid || (liquids && id === B.WATER))) return { x, y, z, id, nx, ny, nz, dist: t };
        if (tx < ty && tx < tz) { x += sx; t = tx; tx += tdx; nx = -sx; ny = 0; nz = 0; }
        else if (ty < tz) { y += sy; t = ty; ty += tdy; nx = 0; ny = -sy; nz = 0; }
        else { z += sz; t = tz; tz += tdz; nx = 0; ny = 0; nz = -sz; }
      }
      return null;
    }

    pruneFar(points, radiusChunks) {
      const keep = new Set(), r = radiusChunks;
      points.forEach((p) => { const pc = Math.floor(p.x) >> 4, pz = Math.floor(p.z) >> 4; for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) keep.add((pc + dx) + "," + (pz + dz)); });
      let n = 0;
      this.chunks.forEach((c, k) => { if (!keep.has(k)) { this.chunks.delete(k); n++; } });
      return n;
    }
  }

  /* ---------- entity physics (shared by the player, mobs and server) ---------- */
  function boxHits(world, x, y, z, w, h) {
    const hw = w / 2, x0 = Math.floor(x - hw), x1 = Math.floor(x + hw - 1e-6), y0 = Math.floor(y), y1 = Math.floor(y + h - 1e-6), z0 = Math.floor(z - hw), z1 = Math.floor(z + hw - 1e-6);
    for (let yy = y0; yy <= y1; yy++) for (let zz = z0; zz <= z1; zz++) for (let xx = x0; xx <= x1; xx++) if (DEF[world.get(xx, yy, zz)].solid) return true;
    return false;
  }
  /** Moves entity e (feet-centre x,y,z, size w x h) by (dx,dy,dz) with axis-wise collision. */
  function moveEntity(world, e, dx, dy, dz) {
    const r = { onGround: false, hitX: false, hitY: false, hitZ: false }, hw = e.w / 2, EPS = 1e-3;
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz)) / 0.4));
    const sx = dx / steps, sy = dy / steps, sz = dz / steps;
    for (let i = 0; i < steps; i++) {
      if (sy) {
        e.y += sy;
        if (boxHits(world, e.x, e.y, e.z, e.w, e.h)) {
          if (sy < 0) { e.y = Math.floor(e.y) + 1 + EPS; r.onGround = true; } else e.y = Math.floor(e.y + e.h) - e.h - EPS;
          r.hitY = true; e.vy = 0; break;
        }
      }
    }
    for (let i = 0; i < steps; i++) {
      if (sx) {
        e.x += sx;
        if (boxHits(world, e.x, e.y, e.z, e.w, e.h)) { e.x = sx > 0 ? Math.floor(e.x + hw) - hw - EPS : Math.floor(e.x - hw) + 1 + hw + EPS; r.hitX = true; e.vx = 0; break; }
      }
    }
    for (let i = 0; i < steps; i++) {
      if (sz) {
        e.z += sz;
        if (boxHits(world, e.x, e.y, e.z, e.w, e.h)) { e.z = sz > 0 ? Math.floor(e.z + hw) - hw - EPS : Math.floor(e.z - hw) + 1 + hw + EPS; r.hitZ = true; e.vz = 0; break; }
      }
    }
    if (!r.onGround && dy <= 0) r.onGround = boxHits(world, e.x, e.y - 0.02, e.z, e.w, e.h);
    return r;
  }

  /** Ray vs axis-aligned box (slab method). Returns distance or -1. */
  function rayBox(ox, oy, oz, dx, dy, dz, minX, minY, minZ, maxX, maxY, maxZ) {
    let t0 = 0, t1 = Infinity;
    const o = [ox, oy, oz], d = [dx, dy, dz], mn = [minX, minY, minZ], mx = [maxX, maxY, maxZ];
    for (let i = 0; i < 3; i++) {
      if (Math.abs(d[i]) < 1e-9) { if (o[i] < mn[i] || o[i] > mx[i]) return -1; continue; }
      let a = (mn[i] - o[i]) / d[i], b = (mx[i] - o[i]) / d[i];
      if (a > b) { const t = a; a = b; b = t; }
      t0 = Math.max(t0, a); t1 = Math.min(t1, b);
      if (t0 > t1) return -1;
    }
    return t0;
  }

  /** Time of day: t in [0,1); 0.25 = noon, 0.75 = midnight. */
  function sunElevation(t) { return Math.cos((t - 0.25) * Math.PI * 2); }
  function daylight(t) { const v = Math.max(0, Math.min(1, (sunElevation(t) + 0.12) / 0.4)); return v * v * (3 - 2 * v); }

  return { CH, HT, SEA, B, DEF, PLACEABLE, BIOME, World, Chunk, moveEntity, boxHits, rayBox, seedFrom, hash2, hash3, noise2, fbm2, sunElevation, daylight };
});
