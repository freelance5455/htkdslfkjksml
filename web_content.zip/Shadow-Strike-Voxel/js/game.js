/* Shadow Strike Voxel — the game itself. */
(function () {
  "use strict";
  const SS = window.SSWorld, { CH, HT, B, DEF, PLACEABLE } = SS;
  const { Room, MOBS, EYE } = window.SSRoom;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const touch = matchMedia("(pointer:coarse)").matches || "ontouchstart" in window;
  if (touch) document.body.classList.add("touch");
  const fa = (n) => Number(n).toLocaleString("fa-IR", { useGrouping: false });

  /* ---------- settings ---------- */
  const defaults = { name: "", dist: touch ? 4 : 6, scale: touch ? 80 : 100, sens: 100, fov: 75, vol: 70, aj: touch, fx: touch ? 1 : 2, server: "", room: "main" };
  let cfg = Object.assign({}, defaults);
  try { Object.assign(cfg, JSON.parse(localStorage.getItem("ssv_cfg") || "{}")); } catch (e) { /* */ }
  const saveCfg = () => { try { localStorage.setItem("ssv_cfg", JSON.stringify(cfg)); } catch (e) { /* */ } };

  /* ---------- renderer ---------- */
  const canvas = $("gl"), atlas = window.SSAtlas.build();
  let R = null;
  try { R = window.SSRenderer.create(canvas, atlas); } catch (e) { console.error(e); }
  if (!R) { document.body.insertAdjacentHTML("beforeend", '<div class="screen" style="z-index:999"><div class="panel"><h3>مرورگر پشتیبانی نمی‌کند</h3><div class="note">این بازی به WebGL2 نیاز دارد. لطفاً Chrome یا Safari به‌روز استفاده کن.</div></div></div>'); return; }
  const Batch = window.SSRenderer.Batch, xform = window.SSRenderer.xform, mulAffine = window.SSRenderer.mulAffine;
  R.setFx(cfg.fx);
  function resize() { R.resize(window.innerWidth, window.innerHeight, Math.min(window.devicePixelRatio || 1, 2), cfg.scale / 100); }
  window.addEventListener("resize", resize); resize();

  /* ---------- game state ---------- */
  const G = {
    screen: "menu", kind: "", world: null, room: null, roomTimer: 0, net: null, hostHub: null, id: 0, name: "", gameMode: "survival", pvp: false, admin: false, tod: 0.25, loaded: false, welcome: null,
    remote: new Map(), enemies: new Map(), me: null, hotbar: [], sel: 0, lastSel: 0, counts: {}, ammo: [{ mag: 30, res: 120, cap: 30 }, { mag: 12, res: 48, cap: 12 }], reload: 0, reloadW: -1,
    hp: 20, maxHp: 20, alive: true, kills: 0, score: 0, ads: 0, flashI: 0, flashRel: [0, 0, 0], hurtV: 0, sprintK: 0, sprinting: false, particles: [], tracers: [], chat: [], time: 0, rtt: 0, fps: 0, mine: { x: 0, y: 0, z: 0, t: 0, on: false }, hand: { swing: 0, kick: 0, flash: 0, bob: 0 },
    abil: { phase: 0, scan: 0, scanOn: 0, phaseOn: 0 }, shake: 0, lastShot: [0, 0], urgent: [], wanted: [], lastP: "", dmgT: 0, hitT: 0, saveT: 0, loadStart: 0, stateT: 0, stepD: 0, tags: new Map(),
  };
  const inp = { f: 0, b: 0, l: 0, r: 0, jump: false, sprint: false, crouch: false, attack: false, place: false, joyX: 0, joyY: 0, placeT: 0 };
  window.SSGame = { G, inp, cfg, R };

  /* ---------- helpers ---------- */
  function toast(msg, ms) { const t = $("toast"); t.textContent = msg; t.style.opacity = 1; clearTimeout(toast.h); toast.h = setTimeout(() => { t.style.opacity = 0; }, ms || 2200); }
  function hsl(h, s, l) { const f = (n) => { const k = (n + h * 12) % 12, a = s * Math.min(l, 1 - l); return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); }; return [f(0), f(8), f(4)]; }
  const blockColor = (id) => window.SSAtlas.tileColor(atlas, DEF[id].tiles[0]);
  const icons = new Map();
  function iconFor(id) { if (!icons.has(id)) icons.set(id, window.SSAtlas.icon(atlas, DEF[id].tiles, 72)); return icons.get(id); }

  /* ================= ITEMS, TOOLS, DROPS, CRAFTING ================= */
  const ITEMS = {
    100: { name: "چوب‌دستی", e: "🥢", col: [0.55, 0.4, 0.2] }, 101: { name: "زغال", e: "⚫", col: [0.1, 0.1, 0.1] }, 102: { name: "گوشت خام", e: "🥩", col: [0.8, 0.3, 0.3], food: 4 },
    110: { name: "کلنگ چوبی", e: "⛏️", col: [0.62, 0.45, 0.25], tool: "pick", tier: 1 }, 111: { name: "کلنگ سنگی", e: "⛏️", col: [0.5, 0.5, 0.52], tool: "pick", tier: 2 },
    112: { name: "تبر چوبی", e: "🪓", col: [0.62, 0.45, 0.25], tool: "axe", tier: 1 }, 113: { name: "تبر سنگی", e: "🪓", col: [0.5, 0.5, 0.52], tool: "axe", tier: 2 },
    114: { name: "بیل چوبی", e: "🥄", col: [0.62, 0.45, 0.25], tool: "shovel", tier: 1 }, 115: { name: "بیل سنگی", e: "🥄", col: [0.5, 0.5, 0.52], tool: "shovel", tier: 2 },
  };
  const STONEISH = new Set([B.STONE, B.COBBLE, B.COAL, B.BRICK, B.SANDSTONE, B.CONCRETE, B.CRACKED, B.ASPHALT, B.ROADLINE, B.RUBBLE, B.METAL, B.SIDEWALK, B.FIRE]), WOODISH = new Set([B.LOG, B.PLANKS, B.CRATE]), SOFT = new Set([B.DIRT, B.GRASS, B.SAND, B.GRAVEL, B.SNOW, B.SANDBAG, B.SCORCH]);
  const toolKind = (id) => (STONEISH.has(id) ? "pick" : WOODISH.has(id) ? "axe" : SOFT.has(id) ? "shovel" : null);
  function bestTier(kind) { let t = 0; for (const k in ITEMS) { const it = ITEMS[k]; if (it.tool === kind && (G.counts[k] || 0) > 0) t = Math.max(t, it.tier); } return t; }
  /** Mining speed multiplier: the best matching tool in the hotbar is used automatically. */
  function mineMult(id) { if (G.gameMode === "creative") return 1; const k = toolKind(id); if (!k) return 1; const t = bestTier(k); if (t === 0) return k === "pick" ? 0.35 : 1; return t === 1 ? 2.5 : 4; }
  function dropFor(id) {
    if (G.gameMode === "creative") return null;
    if (STONEISH.has(id) && bestTier("pick") === 0) return null;
    if (id === B.GRASS) return { id: B.DIRT, n: 1 }; if (id === B.STONE) return { id: B.COBBLE, n: 1 }; if (id === B.COAL) return { id: 101, n: 1 };
    if (id === B.LEAVES) return Math.random() < 0.3 ? { id: 100, n: 1 } : null;
    return { id, n: 1 };
  }
  function giveId(id, n) {
    G.counts[id] = (G.counts[id] || 0) + n; const kind = id < 100 ? "b" : "i";
    if (!G.hotbar.some((s) => s && s.k === kind && s.id === id)) { const i = G.hotbar.findIndex((s) => !s); if (i >= 0) G.hotbar[i] = { k: kind, id }; }
    renderHotbar();
  }
  function consume(id, n) { G.counts[id] = Math.max(0, (G.counts[id] || 0) - n); if (!G.counts[id]) G.hotbar = G.hotbar.map((s) => (s && s.k !== "w" && s.id === id ? null : s)); renderHotbar(); }
  function collectDrop(id) { const d = dropFor(id); if (d) { giveId(d.id, d.n); window.SSAudio.play("pickup"); } }
  const RECIPES = [
    { out: [B.PLANKS, 4], inp: [[B.LOG, 1]] }, { out: [100, 4], inp: [[B.PLANKS, 2]] },
    { out: [110, 1], inp: [[B.PLANKS, 3], [100, 2]] }, { out: [112, 1], inp: [[B.PLANKS, 3], [100, 2]] }, { out: [114, 1], inp: [[B.PLANKS, 1], [100, 2]] },
    { out: [111, 1], inp: [[B.COBBLE, 3], [100, 2]] }, { out: [113, 1], inp: [[B.COBBLE, 3], [100, 2]] }, { out: [115, 1], inp: [[B.COBBLE, 1], [100, 2]] },
    { out: [B.LAMP, 4], inp: [[101, 1], [100, 1]] }, { out: [B.GLASS, 4], inp: [[B.SAND, 4], [101, 1]] }, { out: [B.BRICK, 2], inp: [[B.COBBLE, 2], [101, 1]] },
  ];
  const nameOf = (id) => (id < 100 ? DEF[id].name : ITEMS[id].name), emojiOf = (id) => (id < 100 ? "🧱" : ITEMS[id].e);
  const canCraft = (r) => r.inp.every(([id, n]) => (G.counts[id] || 0) >= n);
  function craft(i) { const r = RECIPES[i]; if (!r || G.gameMode === "creative" || !canCraft(r)) return false; r.inp.forEach(([id, n]) => consume(id, n)); giveId(r.out[0], r.out[1]); window.SSAudio.play("pickup"); toast("ساخته شد: " + nameOf(r.out[0]) + " ×" + r.out[1]); return true; }
  function openCraft() {
    if (G.screen !== "play") return; document.exitPointerLock && document.exitPointerLock();
    const box = $("craftlist"); box.innerHTML = "";
    if (G.gameMode === "creative") box.innerHTML = '<div class="note">در حالت خلاقانه همه‌ی بلوک‌ها در دسترس‌اند؛ ساخت‌وساز مخصوص حالت بقاست.</div>';
    else RECIPES.forEach((r, i) => { const ok = canCraft(r), d = document.createElement("div"); d.className = "rec" + (ok ? " ok" : ""); d.innerHTML = "<b>" + emojiOf(r.out[0]) + " " + nameOf(r.out[0]) + " ×" + r.out[1] + "</b><span>" + r.inp.map(([id, n]) => nameOf(id) + " ×" + n + " (" + (G.counts[id] || 0) + ")").join(" + ") + "</span>"; d.addEventListener("click", () => { if (craft(i)) openCraft(); }); box.appendChild(d); });
    setScreen("craft");
  }
  function eat() { const it = item(); if (!it || it.k !== "i" || !ITEMS[it.id].food || G.hp >= G.maxHp || (G.counts[it.id] || 0) <= 0) return false; if (G.net) G.net.send({ t: "eat" }); consume(it.id, 1); window.SSAudio.play("pickup"); return true; }

  /* ================= MESH WORKERS (keeps the game smooth on phones) ================= */
  const pool = { ws: [], ok: false, failed: false };
  function initPool() {
    if (typeof Worker === "undefined") { pool.failed = true; return; }
    try {
      const n = Math.max(1, Math.min(3, (navigator.hardwareConcurrency || 2) - 1));
      for (let i = 0; i < n; i++) { const w = new Worker("js/mesh-worker.js"), slot = { w, busy: 0 }; w.onmessage = (e) => onMeshResult(slot, e.data); w.onerror = () => { pool.failed = true; pool.ok = false; }; pool.ws.push(slot); }
      pool.ws[0].w.postMessage({ ping: 1 });
      setTimeout(() => { if (!pool.ok) pool.failed = true; }, 3000);
    } catch (e) { pool.failed = true; }
  }
  function onMeshResult(slot, m) {
    if (m.pong) { pool.ok = true; return; }
    slot.busy = Math.max(0, slot.busy - 1);
    const c = G.world && G.world.chunks.get(m.key);
    if (!c) return;
    if (c.version !== m.version) { c.dirty = true; return; }
    R.setChunkMesh(c.cx, c.cz, { opaque: m.opaque, water: m.water }); c.meshed = true;
  }
  /** true = sent to a worker, false = no worker available (mesh here instead), null = workers busy, try later */
  function submitMesh(c) {
    if (!pool.ok || pool.failed) return false;
    const slot = pool.ws.reduce((a, b) => (a.busy <= b.busy ? a : b)); if (slot.busy >= 3) return null;
    const nb = new Array(9);
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) { const n = G.world.chunks.get((c.cx + dx) + "," + (c.cz + dz)); nb[(dz + 1) * 3 + dx + 1] = n ? { data: n.data.slice(), top: n.top.slice(), lamps: n.lamps } : null; }
    slot.busy++; c.dirty = false; c.job = c.version;
    slot.w.postMessage({ key: c.cx + "," + c.cz, cx: c.cx, cz: c.cz, version: c.version, nb });
    return true;
  }

  /* ================= WORLD STREAMING ================= */
  function setupWorld(seed) {
    G.world = new SS.World(seed);
    G.world.onChunk = (c) => { for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) { const n = G.world.chunks.get((c.cx + dx) + "," + (c.cz + dz)); if (n) { n.dirty = true; n.version++; } } };
    G.world.onChange = (x, y, z) => {
      const lx = x & 15, lz = z & 15, cx = x >> 4, cz = z >> 4, mark = (a, b) => { const c = G.world.chunks.get(a + "," + b); if (c) { c.dirty = true; G.urgent.push(c); } };
      mark(cx, cz); if (lx === 0) mark(cx - 1, cz); if (lx === 15) mark(cx + 1, cz); if (lz === 0) mark(cx, cz - 1); if (lz === 15) mark(cx, cz + 1);
    };
    R.meshes.forEach((m, k) => R.dropChunk(k));
    G.lastP = "";
  }
  function meshOne(c) { R.setChunkMesh(c.cx, c.cz, window.SSMesher.meshChunk(G.world, c)); c.dirty = false; c.meshed = true; c.job = c.version; }
  function neighborsReady(c) { for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (!G.world.chunks.has((c.cx + dx) + "," + (c.cz + dz))) return false; return true; }
  function stream(budget) {
    const w = G.world, me = G.me; if (!w || !me) return;
    const pcx = Math.floor(me.x) >> 4, pcz = Math.floor(me.z) >> 4, key = pcx + "," + pcz + "," + cfg.dist;
    if (key !== G.lastP) {
      G.lastP = key; const r = cfg.dist + 1, list = [];
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) { const d = Math.hypot(dx, dz); if (d <= r + 0.4) list.push({ cx: pcx + dx, cz: pcz + dz, d }); }
      list.sort((a, b) => a.d - b.d); G.wanted = list;
      // unload far chunks
      const far = cfg.dist + 3;
      w.chunks.forEach((c, k) => { if (Math.abs(c.cx - pcx) > far || Math.abs(c.cz - pcz) > far) { w.chunks.delete(k); R.dropChunk(k); } });
    }
    const t0 = performance.now();
    while (G.urgent.length) { const c = G.urgent.pop(); if (c.dirty && w.chunks.get(c.cx + "," + c.cz) === c) meshOne(c); }
    for (const q of G.wanted) { if (performance.now() - t0 > budget * 0.55) break; if (!w.chunks.has(q.cx + "," + q.cz)) w.chunkAt(q.cx, q.cz, true); }
    for (const q of G.wanted) {
      if (performance.now() - t0 > budget) break;
      if (q.d > cfg.dist + 0.4) continue;
      const c = w.chunks.get(q.cx + "," + q.cz);
      if (c && (c.dirty || !c.meshed) && c.job !== c.version && neighborsReady(c)) { const r = submitMesh(c); if (r === false) meshOne(c); else if (r === null) break; }
    }
  }
  function loadProgress() {
    const w = G.world, me = G.me; if (!w || !me) return 0;
    const pcx = Math.floor(me.x) >> 4, pcz = Math.floor(me.z) >> 4; let have = 0, need = 0;
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) { need++; const cc = w.chunks.get((pcx + dx) + "," + (pcz + dz)); if (cc && cc.meshed) have++; }
    return have / need;
  }

  /* ================= INVENTORY ================= */
  function initInventory(creative) {
    G.hotbar = [{ k: "w", w: 0 }, { k: "w", w: 1 }, { k: "b", id: B.GRASS }, { k: "b", id: B.STONE }, { k: "b", id: B.PLANKS }, { k: "b", id: B.GLASS }, { k: "b", id: B.BRICK }, { k: "b", id: B.LAMP }, { k: "b", id: B.LOG }];
    G.counts = {}; if (!creative) G.hotbar.forEach((s, i) => { if (s.k === "b") G.hotbar[i] = null; });
    G.sel = creative ? 2 : 0; renderHotbar();
  }
  const item = () => G.hotbar[G.sel] || null;
  const count = (id) => (G.gameMode === "creative" ? 999 : G.counts[id] || 0);
  function addBlock(id) { if (G.gameMode !== "creative") giveId(id, 1); }
  function renderHotbar() {
    const hb = $("hotbar"); hb.innerHTML = "";
    G.hotbar.forEach((s, i) => {
      const d = document.createElement("div"); d.className = "slot" + (i === G.sel ? " sel" : "");
      d.innerHTML = '<span class="k">' + (i + 1) + "</span>";
      if (s && s.k === "b") { const c = document.createElement("canvas"); c.width = c.height = 72; c.getContext("2d").drawImage(iconFor(s.id), 0, 0); d.appendChild(c); if (G.gameMode !== "creative") d.insertAdjacentHTML("beforeend", '<span class="n">' + (G.counts[s.id] || 0) + "</span>"); }
      else if (s && s.k === "w") d.insertAdjacentHTML("beforeend", '<span style="font-size:22px">' + (s.w === 0 ? "🔫" : "🔸") + "</span>");
      else if (s && s.k === "i") { const IT = ITEMS[s.id]; d.insertAdjacentHTML("beforeend", '<span style="font-size:22px">' + IT.e + "</span>" + (IT.tool ? "" : '<span class="n">' + (G.counts[s.id] || 0) + "</span>")); }
      d.addEventListener("pointerdown", (e) => { e.preventDefault(); e.stopPropagation(); selectSlot(i); });
      hb.appendChild(d);
    });
  }
  function selectSlot(i) { if (i < 0 || i > 8) return; if (i !== G.sel) { G.lastSel = G.sel; G.sel = i; G.reload = 0; G.mine.t = 0; renderHotbar(); window.SSAudio.play("click"); } }
  function openInventory() {
    if (G.screen !== "play") return;
    const grid = $("invgrid"); grid.innerHTML = "";
    PLACEABLE.filter((id) => G.gameMode === "creative" || (G.counts[id] || 0) > 0).forEach((id) => {
      const d = document.createElement("div"); d.className = "slot"; const c = document.createElement("canvas"); c.width = c.height = 72; c.getContext("2d").drawImage(iconFor(id), 0, 0); d.appendChild(c);
      d.title = DEF[id].name; d.insertAdjacentHTML("beforeend", '<span class="n" style="font-size:10px;left:2px;right:auto">' + DEF[id].name + "</span>");
      d.addEventListener("click", () => { G.hotbar[G.sel] = { k: "b", id }; renderHotbar(); closeOverlay(); });
      grid.appendChild(d);
    });
    if (!grid.children.length) grid.innerHTML = '<div class="note">هنوز بلوکی نداری؛ اول چیزی بشکن.</div>';
    setScreen("inv");
  }

  /* ================= PLAYER ================= */
  function newPlayer(x, y, z) { return { x, y, z, vx: 0, vy: 0, vz: 0, w: 0.6, h: 1.8, yaw: 0, pitch: 0, onGround: false, inWater: false, flying: false, crouchT: 0, fallPeak: y, eyeBob: 0, moving: false, speed: 0 }; }
  const eyeH = (me) => EYE - me.crouchT * 0.2;
  function updatePlayer(dt) {
    const me = G.me, w = G.world; if (!me || !G.alive) return;
    dt = Math.min(dt, 0.05);
    const creative = G.gameMode === "creative";
    let mx = inp.r - inp.l + inp.joyX, mz = inp.f - inp.b + inp.joyY; const ml = Math.hypot(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
    const sy = Math.sin(me.yaw), cy = Math.cos(me.yaw), wx = -sy * mz + cy * mx, wz = -cy * mz - sy * mx;
    const feetWater = w.get(Math.floor(me.x), Math.floor(me.y + 0.4), Math.floor(me.z)) === B.WATER, headWater = w.get(Math.floor(me.x), Math.floor(me.y + 1.6), Math.floor(me.z)) === B.WATER;
    me.inWater = feetWater;
    const wantSprint = inp.sprint || (touch && ml > 0.92);
    let speed = me.flying ? (wantSprint ? 17 : 10.5) : (inp.crouch && !me.flying) ? 1.9 : wantSprint && mz > 0.2 ? 5.9 : 4.3;
    if (me.inWater && !me.flying) speed *= 0.6;
    speed *= 1 - G.ads * 0.4; G.sprinting = wantSprint && mz > 0.2 && !inp.crouch;
    const tx = wx * speed, tz = wz * speed, acc = me.onGround || me.flying || me.inWater ? 14 : 4.2;
    me.vx += (tx - me.vx) * Math.min(1, acc * dt); me.vz += (tz - me.vz) * Math.min(1, acc * dt);
    if (me.flying) {
      const up = (inp.jump ? 1 : 0) - (inp.crouch ? 1 : 0), tvy = up * (wantSprint ? 11 : 7.5);
      me.vy += (tvy - me.vy) * Math.min(1, 10 * dt);
    } else if (me.inWater) {
      me.vy -= 9 * dt; if (inp.jump) me.vy += 24 * dt; me.vy = Math.max(-4, Math.min(3.4, me.vy)) * (1 - 2 * dt);
    } else {
      me.vy -= 28 * dt; if (me.vy < -50) me.vy = -50;
      if (inp.jump && me.onGround) { me.vy = 8.6; me.onGround = false; }
    }
    const wasGround = me.onGround, preVy = me.vy;
    const r = SS.moveEntity(w, me, me.vx * dt, me.vy * dt, me.vz * dt);
    me.onGround = r.onGround;
    if (cfg.aj && me.onGround && (r.hitX || r.hitZ) && ml > 0.2 && !me.flying && !inp.crouch) {
      const fx = Math.floor(me.x + Math.sign(wx) * 0.55), fz = Math.floor(me.z + Math.sign(wz) * 0.55), fy = Math.floor(me.y);
      if (!w.solid(fx, fy + 1, fz) && !w.solid(fx, fy + 2, fz) && w.solid(fx, fy, fz)) { me.vy = 8.2; me.onGround = false; }
    }
    if (me.flying && me.onGround && inp.crouch) me.flying = false;
    // fall damage
    if (me.onGround || me.inWater || me.flying) {
      if (!wasGround && me.onGround && !me.inWater && !me.flying) { const d = me.fallPeak - me.y; if (d > 1.6) window.SSAudio.play("thud"); if (d > 3 && !creative && G.net) G.net.send({ t: "fall", d }); }
      me.fallPeak = me.y;
    } else me.fallPeak = Math.max(me.fallPeak, me.y);
    if (me.y < -30) { const sp = w.spawnPoint(); me.x = sp.x; me.y = sp.y; me.z = sp.z; me.vy = 0; }
    me.crouchT += ((inp.crouch && !me.flying ? 1 : 0) - me.crouchT) * Math.min(1, 12 * dt);
    me.speed = Math.hypot(me.vx, me.vz); me.moving = me.speed > 0.6 && me.onGround;
    if (me.moving) { me.eyeBob += me.speed * dt * 1.7; G.stepD += me.speed * dt; if (G.stepD > 2.3) { G.stepD = 0; const id = w.get(Math.floor(me.x), Math.floor(me.y - 0.2), Math.floor(me.z)); window.SSAudio.play("step", DEF[id] ? DEF[id].snd : "stone"); } }
    G.headWater = headWater;
  }
  function eyePos() { const me = G.me; return { x: me.x, y: me.y + eyeH(me) + Math.sin(me.eyeBob) * 0.025 * (me.moving ? 1 : 0), z: me.z }; }
  function lookDir() { const me = G.me, cp = Math.cos(me.pitch); return [-Math.sin(me.yaw) * cp, Math.sin(me.pitch), -Math.cos(me.yaw) * cp]; }

  /* ================= BUILD / MINE ================= */
  const REACH = () => (G.gameMode === "creative" ? 7 : 5.5);
  function overlapsMe(x, y, z) { const me = G.me; return me.x + 0.3 > x && me.x - 0.3 < x + 1 && me.y + 1.8 > y && me.y < y + 1 && me.z + 0.3 > z && me.z - 0.3 < z + 1; }
  function target(liquids) { const e = eyePos(), d = lookDir(); return G.world.raycast(e.x, e.y, e.z, d[0], d[1], d[2], REACH(), { liquids }); }
  function particles(x, y, z, id, n) {
    const c = blockColor(id);
    for (let i = 0; i < n; i++) G.particles.push({ x: x + Math.random(), y: y + Math.random(), z: z + Math.random(), vx: (Math.random() - 0.5) * 4, vy: Math.random() * 4 + 1, vz: (Math.random() - 0.5) * 4, life: 0.5 + Math.random() * 0.4, s: 0.06 + Math.random() * 0.06, c: [c[0] * (0.7 + Math.random() * 0.4), c[1] * (0.7 + Math.random() * 0.4), c[2] * (0.7 + Math.random() * 0.4)] });
  }
  function sendBlock(x, y, z, id) { if (G.net) G.net.send({ t: "block", x, y, z, id }); }
  function breakBlock(x, y, z) {
    const id = G.world.get(x, y, z); if (id === B.AIR || id === B.BEDROCK || id === B.WATER) return;
    G.world.set(x, y, z, B.AIR); particles(x, y, z, id, 12); window.SSAudio.play("brk", DEF[id].snd); collectDrop(id); sendBlock(x, y, z, 0); G.hand.swing = 1;
  }
  function placeBlock() {
    if (eat()) return true;
    const it = item(); if (!it || it.k !== "b" || count(it.id) <= 0) return false;
    const t = target(true); if (!t) return false;
    const x = t.id === B.WATER ? t.x : t.x + t.nx, y = t.id === B.WATER ? t.y : t.y + t.ny, z = t.id === B.WATER ? t.z : t.z + t.nz;
    const cur = G.world.get(x, y, z); if (cur !== B.AIR && cur !== B.WATER) return false;
    if (DEF[it.id].solid && overlapsMe(x, y, z)) return false;
    if (y < 1 || y >= HT) return false;
    for (const e of G.remote.values()) if (Math.abs(e.x - (x + 0.5)) < 0.8 && Math.abs(e.z - (z + 0.5)) < 0.8 && e.y + 1.8 > y && e.y < y + 1) return false;
    G.world.set(x, y, z, it.id); if (G.gameMode !== "creative") { G.counts[it.id]--; if (G.counts[it.id] <= 0) { G.hotbar[G.sel] = null; } renderHotbar(); }
    window.SSAudio.play("place", DEF[it.id].snd); sendBlock(x, y, z, it.id); G.hand.swing = 1;
    return true;
  }
  function updateMining(dt) {
    const it = item(), m = G.mine, isBlockHand = !it || it.k === "b" || it.k === "i";
    if (!inp.attack || !isBlockHand || !G.alive) { m.on = false; m.t = 0; return; }
    const t = target(false);
    if (!t) { m.on = false; m.t = 0; return; }
    if (!m.on || m.x !== t.x || m.y !== t.y || m.z !== t.z) { m.on = true; m.x = t.x; m.y = t.y; m.z = t.z; m.t = 0; }
    const hard = G.gameMode === "creative" ? 0.18 : Math.max(0.08, DEF[t.id].hard / mineMult(t.id));
    m.t += dt / hard; G.hand.swing = Math.max(G.hand.swing, 0.6); m.snd = (m.snd || 0) - dt;
    if (m.snd <= 0 && G.gameMode !== "creative") { m.snd = 0.24; window.SSAudio.play("dig", DEF[t.id].snd); }
    if (m.t >= 1) { m.t = 0; breakBlock(t.x, t.y, t.z); }
  }

  /* ================= WEAPONS ================= */
  function startReload(w) {
    const a = G.ammo[w]; if (G.reload > 0 || a.mag >= a.cap || (a.res <= 0 && G.gameMode !== "creative")) return;
    G.reload = w === 0 ? 1.7 : 1.2; G.reloadW = w; window.SSAudio.play("reload");
  }
  function fire(w) {
    const a = G.ammo[w], rate = w === 0 ? 0.095 : 0.26;
    if (G.reload > 0 || G.time - G.lastShot[w] < rate) return false;
    if (a.mag <= 0) { window.SSAudio.play("empty"); startReload(w); G.lastShot[w] = G.time; return false; }
    G.lastShot[w] = G.time; a.mag--;
    const ads = G.ads, sp = (w === 0 ? 0.012 : 0.004) * (1 - ads * 0.65) * (G.me.moving ? 1.7 : 1);
    const d = lookDir(), dx = d[0] + (Math.random() - 0.5) * sp, dy = d[1] + (Math.random() - 0.5) * sp, dz = d[2] + (Math.random() - 0.5) * sp, e = eyePos();
    const wall = G.world.raycast(e.x, e.y, e.z, dx, dy, dz, 80), dist = wall ? wall.dist : 80;
    const me = G.me, sy = Math.sin(me.yaw), cy = Math.cos(me.yaw), sp2 = Math.sin(me.pitch), cp = Math.cos(me.pitch), rt = [cy, 0, -sy], up = [sy * sp2, cp, cy * sp2];
    const mz = (w === 0 ? 1.0 : 0.3) - ads * 0.1, mx = [e.x + d[0] * mz + rt[0] * 0.13 * (1 - ads) + up[0] * -0.1 * (1 - ads), e.y + d[1] * mz + up[1] * -0.1 * (1 - ads), e.z + d[2] * mz + rt[2] * 0.13 * (1 - ads) + up[2] * -0.1 * (1 - ads)];
    addTracer({ x: mx[0], y: mx[1], z: mx[2] }, [dx, dy, dz], dist, true);
    if (G.net) G.net.send({ t: "shoot", w, d: [dx, dy, dz] });
    window.SSAudio.play(w === 0 ? "rifle" : "pistol");
    const rk = 1 - ads * 0.4;
    G.hand.kick = 1; G.hand.flash = 0.06; G.flashI = 1; G.flashRel = [mx[0] - e.x, mx[1] - e.y, mx[2] - e.z];
    me.pitch = Math.min(1.5, me.pitch + (w === 0 ? 0.0055 + Math.random() * 0.0035 : 0.016) * rk); me.yaw += (Math.random() - 0.5) * (w === 0 ? 0.0055 : 0.003) * rk; G.shake = Math.max(G.shake, (w === 0 ? 0.25 : 0.4) * (1 - ads * 0.4));
    const FXm = window.SSFx;
    FXm.casing(e.x + d[0] * 0.38 + rt[0] * 0.12 + up[0] * -0.07, e.y + d[1] * 0.38 + up[1] * -0.07, e.z + d[2] * 0.38 + rt[2] * 0.12 + up[2] * -0.07, rt[0] * (1.7 + Math.random() * 1.2) + up[0] * (1.1 + Math.random()) - d[0] * (0.2 - Math.random() * 0.5) + me.vx * 0.5, rt[1] * 2 + up[1] * (1.1 + Math.random()) + 0.6, rt[2] * (1.7 + Math.random() * 1.2) + up[2] * (1.1 + Math.random()) - d[2] * (0.2 - Math.random() * 0.5) + me.vz * 0.5);
    FXm.muzzleSmoke(mx[0], mx[1], mx[2], d[0], d[1], d[2]);
    if (a.mag <= 0 && (a.res > 0 || G.gameMode === "creative")) startReload(w);
    return true;
  }
  function addTracer(from, dir, dist, mine) {
    const n = Math.min(44, Math.floor(dist / 1.4));
    for (let i = mine ? 1 : 2; i < n; i++) G.tracers.push({ x: from.x + dir[0] * i * 1.4, y: from.y + dir[1] * i * 1.4 - (mine ? 0.02 : 0), z: from.z + dir[2] * i * 1.4, life: 0.06 + i * 0.0006 });
  }
  function updateWeapons(dt) {
    { const w0 = item(), gun = w0 && w0.k === "w", want = inp.ads && gun && G.alive && G.reload <= 0 && !G.sprinting ? 1 : 0; G.ads += (want - G.ads) * Math.min(1, 14 * dt); G.sprintK += ((G.sprinting && G.me.moving && gun ? 1 : 0) - G.sprintK) * Math.min(1, 9 * dt); G.flashI = Math.max(0, G.flashI - dt * 16); G.hurtV = Math.max(0, G.hurtV - dt * 2.2); }
    if (G.reload > 0) {
      G.reload -= dt;
      if (G.reload <= 0) { const a = G.ammo[G.reloadW], need = a.cap - a.mag, take = G.gameMode === "creative" ? need : Math.min(need, a.res); a.mag += take; if (G.gameMode !== "creative") a.res -= take; G.reloadW = -1; updateAmmo(); }
    }
    const it = item();
    if (it && it.k === "w" && inp.attack && G.alive) { if (it.w === 0) fire(0); else if (!inp.attackHeld) fire(1); }
    inp.attackHeld = inp.attack;
  }

  /* ================= NETWORK ================= */
  function onNet(m) {
    switch (m.t) {
      case "welcome": return onWelcome(m);
      case "edits": for (let i = 0; i + 3 < m.a.length; i += 4) G.world.set(m.a[i], m.a[i + 1], m.a[i + 2], m.a[i + 3]); return;
      case "block": if (m.by !== G.id || G.world.get(m.x, m.y, m.z) !== m.id) { G.world.set(m.x, m.y, m.z, m.id); if (m.by !== G.id) { window.SSAudio.play(m.id ? "place" : "dig", m.id ? DEF[m.id].snd : "stone"); } } return;
      case "reject": G.world.set(m.x, m.y, m.z, m.id); return;
      case "snap": return onSnap(m);
      case "join": addChat("", m.name + " وارد شد", true); return;
      case "leave": G.remote.delete(m.id); removeTag(m.id); return;
      case "chat": addChat(m.from, m.text, !m.from); if (m.from) window.SSAudio.play("chat"); return;
      case "hp": { const lost = G.hp - m.hp; G.hp = m.hp; renderHearts(); if (m.dmg > 0) { G.hurtV = Math.min(1, 0.5 + m.dmg * 0.1); G.dmgT = 0.5; $("dmg").style.opacity = Math.min(1, 0.45 + m.dmg * 0.08); setTimeout(() => { $("dmg").style.opacity = 0; }, 160); window.SSAudio.play("hurt"); G.shake = 0.6; } return void lost; }
      case "died": if (m.id === G.id) { G.alive = false; $("death-by").textContent = m.by ? "به دست: " + m.by : ""; document.exitPointerLock && document.exitPointerLock(); setScreen("death"); } return;
      case "respawn": G.me.x = m.x; G.me.y = m.y; G.me.z = m.z; G.me.vx = G.me.vy = G.me.vz = 0; G.me.fallPeak = m.y; G.hp = m.hp; G.alive = true; renderHearts(); setScreen("play"); lockPointer(); return;
      case "tp": G.me.x = m.x; G.me.y = m.y; G.me.z = m.z; G.me.vy = 0; return;
      case "fx": if (m.k === "shot") { const e = G.remote.get(m.id); if (e) { const from = { x: e.x, y: e.y + 1.5, z: e.z }, dx = m.ex - from.x, dy = m.ey - from.y, dz = m.ez - from.z, l = Math.hypot(dx, dy, dz) || 1; addTracer(from, [dx / l, dy / l, dz / l], l, false); window.SSAudio.play(m.w ? "pistol" : "rifle"); } } else if (m.k === "phase") { if (m.id === G.id) { G.abil.phaseOn = 5; } window.SSAudio.play("phase"); } return;
      case "hit": { const c = $("cross"); c.className = m.k === "wall" ? "" : (m.dead ? "kill" : "hit"); if (m.k !== "wall") { G.hitT = 0.15; window.SSHud.hitmarker(m.dead, m.head); if (m.dead) window.SSHud.addScore(100 + (m.head ? 50 : 0), m.head ? "HEADSHOT" : "KILL"); else window.SSHud.addScore(m.head ? 25 : 10); window.SSAudio.play(m.dead ? "kill" : m.head ? "headshot" : "hit"); for (let i = 0; i < 5; i++) G.particles.push({ x: m.x, y: m.y, z: m.z, vx: (Math.random() - 0.5) * 3, vy: Math.random() * 3, vz: (Math.random() - 0.5) * 3, life: 0.35, s: 0.07, c: [1, 0.3, 0.2] }); } else { const hb = G.world.get(Math.floor(m.x), Math.floor(m.y), Math.floor(m.z)) || B.STONE; particles(Math.floor(m.x), Math.floor(m.y), Math.floor(m.z), hb, 3); window.SSFx.impact(m.x, m.y, m.z, blockColor(hb)); } return; }
      case "kill": { G.enemies.delete(m.id); for (let i = 0; i < 14; i++) G.particles.push({ x: m.x, y: m.y + 0.9, z: m.z, vx: (Math.random() - 0.5) * 5, vy: Math.random() * 4, vz: (Math.random() - 0.5) * 5, life: 0.7, s: 0.1, c: [0.2, 0.9, 1] }); if (m.by === G.id) { G.kills++; $("kills").textContent = "☠ " + G.kills; } return; }
      case "loot": if (m.item) { giveId(m.item, m.n || 1); window.SSAudio.play("pickup"); toast("+" + (m.n || 1) + " " + ITEMS[m.item].name); } else { G.ammo[0].res += m.ammo; G.ammo[1].res += Math.floor(m.ammo / 3); updateAmmo(); window.SSAudio.play("pickup"); toast("+" + m.ammo + " مهمات"); } return;
      case "mode": G.gameMode = m.mode; renderHotbar(); renderHearts(); toast(m.mode === "creative" ? "حالت خلاقانه" : "حالت بقا"); return;
      case "full": toast("اتاق پر است"); leave(); return;
      case "pong": G.rtt = (Date.now() % 1e9) - m.c; return;
      default: return;
    }
  }
  function onWelcome(m) {
    G.id = m.id; G.name = m.name; G.gameMode = m.mode; G.pvp = m.pvp; G.admin = m.admin; G.tod = m.tod; G.welcome = m;
    setupWorld(m.seed);
    G.me = newPlayer(m.x, m.y, m.z); G.alive = true; G.hp = 20; G.kills = 0; G.score = 0; G.ads = 0; window.SSFx.reset(); $("kills").textContent = "";
    if (G.restore) { const r = G.restore; if (r.inv) { G.counts = r.inv.counts || {}; if (r.inv.hotbar) G.hotbar = r.inv.hotbar; } G.score = r.score || 0; G.restore = null; renderHotbar(); }
    else initInventory(G.gameMode === "creative");
    if (G.gameMode === "survival") setTimeout(() => toast("بقا: درخت را بشکن، با کلید B (یا 🛠) تخته و ابزار بساز، شب‌ها از سایه‌ها دور بمان", 5000), 2500);
    G.ammo = [{ mag: 30, res: 120, cap: 30 }, { mag: 12, res: 48, cap: 12 }];
    m.players.forEach((p) => { if (p.id !== G.id) G.remote.set(p.id, { id: p.id, name: p.name, hue: p.color, x: p.x, y: p.y, z: p.z, yaw: 0, pitch: 0, f: 0, hp: p.hp, buf: [] }); });
    G.loadStart = performance.now(); G.loaded = false; G.stateT = 0;
    renderHearts(); updateAmmo(); $("load-text").textContent = "در حال ساخت دنیا…"; setScreen("loading");
  }
  function onSnap(m) {
    const now = performance.now(); G.tod = m.tod;
    const seen = new Set();
    m.p.forEach((a) => {
      if (a[0] === G.id) { G.hp = a[7]; return; }
      seen.add(a[0]);
      let e = G.remote.get(a[0]); if (!e) { e = { id: a[0], name: "…", hue: (a[0] * 67) % 360, buf: [] }; G.remote.set(a[0], e); }
      e.buf.push({ t: now, x: a[1], y: a[2], z: a[3], yaw: a[4], pitch: a[5], f: a[6] }); if (e.buf.length > 8) e.buf.shift(); e.hp = a[7];
    });
    const es = new Set();
    m.e.forEach((a) => {
      es.add(a[0]); let e = G.enemies.get(a[0]);
      if (!e) { e = { id: a[0], type: { s: "shadow", r: "runner", b: "brute", c: "cow", p: "pig" }[a[1]] || "shadow", buf: [] }; G.enemies.set(a[0], e); window.SSAudio.play("growl"); }
      e.buf.push({ t: now, x: a[2], y: a[3], z: a[4], yaw: a[5] }); if (e.buf.length > 8) e.buf.shift(); e.hp = a[6];
    });
    G.enemies.forEach((e, id) => { if (!es.has(id)) G.enemies.delete(id); });
  }
  function sample(e, rt) {
    const b = e.buf; if (!b.length) return null;
    let a = b[0], c = b[b.length - 1];
    if (rt >= c.t) return Object.assign({}, c);
    for (let i = b.length - 1; i > 0; i--) if (b[i - 1].t <= rt) { a = b[i - 1]; c = b[i]; break; }
    const k = c.t === a.t ? 1 : Math.max(0, Math.min(1, (rt - a.t) / (c.t - a.t)));
    let dy = c.yaw - a.yaw; while (dy > Math.PI) dy -= 6.2832; while (dy < -Math.PI) dy += 6.2832;
    return { x: a.x + (c.x - a.x) * k, y: a.y + (c.y - a.y) * k, z: a.z + (c.z - a.z) * k, yaw: a.yaw + dy * k, pitch: (a.pitch || 0) + ((c.pitch || 0) - (a.pitch || 0)) * k, f: c.f };
  }
  function sendState(dt) {
    G.stateT -= dt; if (G.stateT > 0 || !G.net || !G.me || !G.alive) return; G.stateT = 0.05;
    const me = G.me, f = (inp.sprint ? 1 : 0) | (inp.crouch ? 2 : 0) | (me.flying ? 4 : 0) | (G.hand.flash > 0 ? 8 : 0) | (me.inWater ? 16 : 0) | (G.hand.swing > 0.2 ? 32 : 0);
    G.net.send({ t: "s", x: Math.round(me.x * 100) / 100, y: Math.round(me.y * 100) / 100, z: Math.round(me.z * 100) / 100, yaw: Math.round(me.yaw * 100) / 100, pitch: Math.round(me.pitch * 100) / 100, f });
  }

  /* ================= RENDER FRAME ================= */
  const ents = new Batch(9000), parts = new Batch(7000), xray = new Batch(3000), hand = new Batch(14000), smoke = new Batch(12000);
  function drawHuman(batch, cam, e, o) {
    const tx = e.x - cam.x, ty = e.y - cam.y, tz = e.z - cam.z, S = o.scale || 1, swing = Math.sin(o.phase) * Math.min(1, o.speed / 3) * 0.9;
    const bodyM = xform(tx, ty, tz, e.yaw, 0), cr = o.crouch ? 0.18 : 0;
    const sh = o.shirt, pa = o.pants, sk = o.skin, L = o.light;
    const limb = (px, py, pz, ang, w, h, d, c) => batch.box(mulAffine(bodyM, xform(px * S, py * S, pz * S, 0, ang)), -w / 2 * S, -h * S, -d / 2 * S, w / 2 * S, 0, d / 2 * S, c[0], c[1], c[2], L);
    batch.box(bodyM, -0.25 * S, (0.72 - cr) * S, -0.13 * S, 0.25 * S, (1.38 - cr) * S, 0.13 * S, sh[0], sh[1], sh[2], L);
    const hp = xform(0, (1.38 - cr) * S, 0, 0, 0), hm = mulAffine(bodyM, hp), pitch = e.pitch || 0;
    batch.box(mulAffine(hm, xform(0, 0.25 * S, 0, 0, -pitch * 0.7)), -0.25 * S, -0.25 * S, -0.25 * S, 0.25 * S, 0.25 * S, 0.25 * S, sk[0], sk[1], sk[2], L);
    if (o.eyes) { const em = mulAffine(hm, xform(0, 0.25 * S, 0, 0, -pitch * 0.7)); batch.box(em, -0.17 * S, 0.0, -0.265 * S, -0.05 * S, 0.1 * S, -0.24 * S, o.eyes[0], o.eyes[1], o.eyes[2], 3); batch.box(em, 0.05 * S, 0.0, -0.265 * S, 0.17 * S, 0.1 * S, -0.24 * S, o.eyes[0], o.eyes[1], o.eyes[2], 3); }
    limb(-0.37, 1.36 - cr, 0, swing, 0.24, 0.66, 0.24, sk); limb(0.37, 1.36 - cr, 0, -swing, 0.24, 0.66, 0.24, o.armed ? sk : sk);
    limb(-0.13, 0.72 - cr * 0.4, 0, -swing, 0.25, 0.72, 0.25, pa); limb(0.13, 0.72 - cr * 0.4, 0, swing, 0.25, 0.72, 0.25, pa);
  }
  function drawAnimal(batch, cam, s, e) {
    const M = xform(s.x - cam.x, s.y - cam.y, s.z - cam.z, s.yaw, 0), cow = e.type === "cow", c = cow ? [0.42, 0.28, 0.2] : [0.95, 0.66, 0.7], sw = Math.sin(e.phase || 0) * Math.min(1, (e.speed || 0) / 1.5) * 0.7;
    const bl = cow ? 0.7 : 0.55, h0 = cow ? 0.55 : 0.3;
    batch.box(M, -0.32, h0, -bl, 0.32, h0 + (cow ? 0.65 : 0.45), bl, c[0], c[1], c[2], 1.05);
    if (cow) { batch.box(M, -0.2, h0 + 0.2, -bl * 0.2, 0.2, h0 + 0.3, bl * 0.2, 0.95, 0.95, 0.95, 1.05); }
    batch.box(M, -0.22, h0 + 0.18, -bl - 0.38, 0.22, h0 + 0.62, -bl, c[0] * 1.1, c[1] * 1.1, c[2] * 1.1, 1.05);
    batch.box(M, -0.12, h0 + 0.18, -bl - 0.52, 0.12, h0 + 0.34, -bl - 0.38, cow ? 0.8 : 1, cow ? 0.7 : 0.55, cow ? 0.65 : 0.6, 1.05);
    [[-0.22, -bl + 0.12, sw], [0.22, -bl + 0.12, -sw], [-0.22, bl - 0.12, -sw], [0.22, bl - 0.12, sw]].forEach(([lx, lz, a]) => batch.box(mulAffine(M, xform(lx, h0, lz, 0, a)), -0.1, -h0, -0.1, 0.1, 0, 0.1, c[0] * 0.8, c[1] * 0.8, c[2] * 0.8, 1.05));
  }
  function buildEntities(cam, rt) {
    ents.clear(); xray.clear();
    G.remote.forEach((e) => {
      const s = sample(e, rt); if (!s) return;
      e.px = s.x; e.py = s.y; e.pz = s.z; e.pyaw = s.yaw;
      const dx = s.x - (e.lx == null ? s.x : e.lx), dz = s.z - (e.lz == null ? s.z : e.lz); e.lx = s.x; e.lz = s.z;
      e.speed = Math.min(8, Math.hypot(dx, dz) / Math.max(0.016, G.dtLast)); e.phase = (e.phase || 0) + e.speed * G.dtLast * 2.4;
      const col = hsl(e.hue / 360, 0.55, 0.5);
      if (s.f === 128) return;
      drawHuman(ents, cam, { x: s.x, y: s.y, z: s.z, yaw: s.yaw, pitch: s.pitch }, { phase: e.phase, speed: e.speed, crouch: !!(s.f & 2), shirt: col, pants: [0.18, 0.22, 0.45], skin: [0.93, 0.74, 0.58], light: 1 });
      const hm = mulAffine(xform(s.x - cam.x, s.y - cam.y, s.z - cam.z, s.yaw, 0), xform(0.37, 1.1, -0.25, 0, -s.pitch));
      ents.box(hm, -0.04, -0.06, -0.5, 0.04, 0.06, 0.1, 0.18, 0.18, 0.2, 1);
    });
    G.enemies.forEach((e) => {
      const s = sample(e, rt); if (!s) return;
      const dx = s.x - (e.lx == null ? s.x : e.lx), dz = s.z - (e.lz == null ? s.z : e.lz); e.lx = s.x; e.lz = s.z;
      e.speed = Math.min(8, Math.hypot(dx, dz) / Math.max(0.016, G.dtLast)); e.phase = (e.phase || 0) + e.speed * G.dtLast * 2.6;
      if (e.type === "cow" || e.type === "pig") { drawAnimal(ents, cam, s, e); return; }
      const def = MOBS[e.type], big = e.type === "brute" ? 1.35 : e.type === "runner" ? 0.85 : 1, tint = e.type === "brute" ? [0.28, 0.07, 0.08] : e.type === "runner" ? [0.16, 0.08, 0.26] : [0.09, 0.09, 0.13];
      const o = { phase: e.phase, speed: Math.max(e.speed, 1.2), scale: big, shirt: tint, pants: tint.map((v) => v * 0.7), skin: tint.map((v) => v * 1.3), eyes: e.type === "brute" ? [1, 0.3, 0.2] : [0.3, 1, 1], light: 1.5 };
      drawHuman(ents, cam, { x: s.x, y: s.y, z: s.z, yaw: s.yaw, pitch: 0 }, o);
      if (G.abil.scanOn > 0) drawHuman(xray, cam, { x: s.x, y: s.y, z: s.z, yaw: s.yaw, pitch: 0 }, Object.assign({}, o, { shirt: [0.2, 0.9, 1], pants: [0.2, 0.9, 1], skin: [0.3, 1, 1], light: 1 }));
    });
    if (G.abil.scanOn > 0) G.remote.forEach((e) => { if (e.px != null) drawHuman(xray, cam, { x: e.px, y: e.py, z: e.pz, yaw: e.pyaw, pitch: 0 }, { phase: 0, speed: 0, shirt: [1, 0.85, 0.2], pants: [1, 0.85, 0.2], skin: [1, 0.9, 0.4], light: 1 }); });
  }
  function buildParts(cam, dt) {
    parts.clear(); smoke.clear();
    const ps = G.particles;
    for (let i = ps.length - 1; i >= 0; i--) { const p = ps[i]; p.life -= dt; if (p.life <= 0) { ps.splice(i, 1); continue; } p.vy -= (p.g == null ? 14 : p.g) * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; const sz = p.e ? p.s * Math.min(1, p.life * 5) : p.s; parts.box([1, 0, 0, p.x - cam.x, 0, 1, 0, p.y - cam.y, 0, 0, 1, p.z - cam.z], -sz, -sz, -sz, sz, sz, sz, p.c[0], p.c[1], p.c[2], p.e ? 2.8 : 1); }
    const ts = G.tracers;
    for (let i = ts.length - 1; i >= 0; i--) { const t = ts[i]; t.life -= dt; if (t.life <= 0) { ts.splice(i, 1); continue; } parts.box([1, 0, 0, t.x - cam.x, 0, 1, 0, t.y - cam.y, 0, 0, 1, t.z - cam.z], -0.028, -0.028, -0.028, 0.028, 0.028, 0.028, 1, 0.8, 0.36, 3.4); }
    window.SSFx.build(cam, parts, smoke);
  }
  function buildHand(dt) {
    hand.clear(); const h = G.hand, it = item(), me = G.me, W = window.SSWeapon;
    h.swing = Math.max(0, h.swing - dt * 4.5); h.kick = Math.max(0, h.kick - dt * 9); h.flash = Math.max(0, h.flash - dt);
    h.bob += dt * (me.moving ? me.speed * 1.7 : 0);
    const bx = Math.sin(h.bob) * 0.012 * (me.speed > 5 ? 1.6 : 1), by = Math.abs(Math.cos(h.bob)) * -0.012, sw = Math.sin(h.swing * Math.PI);
    if (it && it.k === "w") {
      const total = G.reloadW === 0 ? 1.7 : 1.2;
      W.drawWeapon(hand, it.w, { t: G.time, bx, by, kick: h.kick, flash: h.flash, ads: G.ads, reload: G.reload > 0 ? Math.min(1, 1 - G.reload / total) : -1, sprint: G.sprintK });
    } else {
      const M = W.drawArm(hand, { bx, by, swing: sw });
      if (it && (it.k === "b" || it.k === "i")) {
        const def = it.k === "i" ? ITEMS[it.id] : null;
        if (def && def.tool) {
          const wood = [0.42, 0.3, 0.16], T = mulAffine(M, xform(0, 0.03, -0.1, 0, -0.35)), hc = def.col;
          W.box(hand, T, [-0.012, -0.012, -0.22, 0.012, 0.012, 0.06], wood, 1.0, 1);
          if (def.tool === "pick") { W.box(hand, T, [-0.11, -0.016, -0.25, 0.11, 0.016, -0.2], hc, 1.0, 1); W.box(hand, T, [-0.12, -0.012, -0.24, -0.09, 0.012, -0.19], hc, 1.0, 1); W.box(hand, T, [0.09, -0.012, -0.24, 0.12, 0.012, -0.19], hc, 1.0, 1); }
          else if (def.tool === "axe") { W.box(hand, T, [-0.02, -0.014, -0.26, 0.1, 0.014, -0.16], hc, 1.0, 1); }
          else { W.box(hand, T, [-0.04, -0.01, -0.3, 0.04, 0.01, -0.2], hc, 1.0, 1); }
        } else {
          const c = it.k === "b" ? blockColor(it.id) : def.col, R2 = mulAffine(M, xform(0, 0.02, -0.12, 0.3, -0.2));
          W.box(hand, R2, [-0.065, -0.065, -0.065, 0.065, 0.065, 0.065], c, 1.1, 1);
        }
      }
    }
  }
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.1, (now - (G.lastT || now)) / 1000); G.lastT = now; G.dtLast = dt || 0.016; G.time += dt;
    G.fpsAcc = (G.fpsAcc || 0) + dt; G.fpsN = (G.fpsN || 0) + 1; if (G.fpsAcc > 0.5) { G.fps = Math.round(G.fpsN / G.fpsAcc); G.fpsAcc = 0; G.fpsN = 0; }
    const playing = G.screen === "play" && G.me && G.world;
    if (G.me && G.world) {
      stream(G.loaded ? (G.fps < 30 ? 3 : 6) : 18);
      if (!G.loaded && G.screen === "loading") { const p = loadProgress(); $("load-bar").style.width = Math.round(p * 100) + "%"; if (p >= 0.98 || performance.now() - G.loadStart > 20000) { G.loaded = true; setScreen("play"); lockPointer(); } }
      if (playing) {
        updatePlayer(dt); updateMining(dt); updateWeapons(dt); window.SSFx.update(dt, G.world, eyePos(), SS.daylight(G.tod));
        if (inp.place && G.time - inp.placeT > 0.22) { inp.placeT = G.time; placeBlock(); }
        sendState(dt);
        G.abil.phase = Math.max(0, G.abil.phase - dt); G.abil.scan = Math.max(0, G.abil.scan - dt); G.abil.scanOn = Math.max(0, G.abil.scanOn - dt); G.abil.phaseOn = Math.max(0, G.abil.phaseOn - dt);
      }
      G.hitT = Math.max(0, G.hitT - dt); if (G.hitT <= 0 && $("cross").className) $("cross").className = "";
      G.shake = Math.max(0, G.shake - dt * 3);
      drawFrame(dt);
      updateHud(dt); window.SSHud && window.SSHud.update(dt);
    } else { R.render({ cam: { x: 8, y: 34, z: 8, yaw: G.time * 0.05, pitch: -0.06 }, tod: 0.455 + Math.sin(G.time * 0.05) * 0.01, time: G.time, dist: 3 }); }
  }
  function drawFrame(dt) {
    const me = G.me, e = eyePos(), shake = G.shake * 0.012, rt = performance.now() - 110;
    const cam = { x: e.x, y: e.y, z: e.z, yaw: me.yaw + (Math.random() - 0.5) * shake, pitch: Math.max(-1.55, Math.min(1.55, me.pitch + (Math.random() - 0.5) * shake)) };
    buildEntities(cam, rt); buildParts(cam, dt); buildHand(dt);
    let sel = null; const it = item();
    if (G.screen === "play" && (!it || it.k !== "w") && G.alive) { const t = target(false); if (t) sel = { x: t.x, y: t.y, z: t.z, progress: G.mine.on && G.mine.x === t.x && G.mine.y === t.y && G.mine.z === t.z ? G.mine.t : 0 }; }
    const info = R.render({ cam, tod: G.tod, time: G.time, sel, ents, parts, xray, smoke, flash: G.flashI > 0 ? { x: G.flashRel[0], y: G.flashRel[1], z: G.flashRel[2], i: G.flashI } : null, hurt: Math.min(1, G.hurtV * 0.8 + (G.alive && G.hp <= 6 && G.gameMode !== "creative" ? 0.18 + 0.12 * Math.sin(G.time * 5) : 0)), handFov: 62 - 14 * G.ads, hand: G.screen === "play" ? hand : null, underwater: !!G.headWater && G.world.get(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z)) === B.WATER, dist: cfg.dist, fov: (cfg.fov + (inp.sprint && me.speed > 5 ? 6 : 0)) * (1 - 0.34 * G.ads), entLight: 0 });
    G.cam = cam; G.sun = info.day;
  }

  /* ================= HUD ================= */
  function renderHearts() {
    const h = $("hearts"); h.innerHTML = "";
    if (G.gameMode === "creative") { h.innerHTML = '<span style="font-size:12px;color:#ffd23d;text-shadow:0 0 4px #000">🧱 خلاقانه</span>'; return; }
    for (let i = 0; i < 10; i++) { const v = G.hp - i * 2, d = document.createElement("div"); d.className = "heart" + (v >= 2 ? " full" : v >= 1 ? " half" : ""); h.appendChild(d); }
  }
  function updateAmmo() { /* drawn by hud.js */ }
  let hudT = 0;
  function updateHud(dt) {
    hudT -= dt; updateAmmo();
    const set = (id, a) => { const el = $(id), p = Math.min(1, a.cd / a.max); el.firstElementChild.style.height = (p * 100) + "%"; el.classList.toggle("ready", a.cd <= 0); };
    set("ab-phase", { cd: G.abil.phase, max: 20 }); set("ab-scan", { cd: G.abil.scan, max: 25 });
    $("phz").style.opacity = G.abil.phaseOn > 0 ? 1 : 0; $("wat").style.opacity = G.headWater ? 1 : 0;
    const mine = $("mine"); if (G.mine.on && G.mine.t > 0.02) { mine.style.opacity = 1; mine.style.borderColor = "rgba(255,255,255," + (0.3 + G.mine.t * 0.7) + ")"; mine.style.transform = "scale(" + (1.3 - G.mine.t * 0.5) + ")"; } else mine.style.opacity = 0;
    // name tags
    const w = window.innerWidth, h = window.innerHeight, tags = $("tags");
    G.remote.forEach((e) => {
      let t = G.tags.get(e.id); const p = e.px == null ? null : R.project(e.px, e.py + 2.15, e.pz, w, h);
      if (!p || p.d > 45 || e.hp <= 0 && false) { if (t) t.style.display = "none"; return; }
      if (!t) { t = document.createElement("div"); tags.appendChild(t); G.tags.set(e.id, t); }
      t.textContent = e.name || "…"; t.style.display = "block"; t.style.left = p.x + "px"; t.style.top = p.y + "px"; t.style.opacity = Math.max(0.35, 1 - p.d / 45);
    });
    if (hudT > 0) return; hudT = 0.25;
    const me = G.me, hh = ((G.tod * 24 + 6) % 24), hr = Math.floor(hh), mn = Math.floor((hh - hr) * 60);
    $("clock").textContent = (SS.daylight(G.tod) > 0.3 ? "☀️ " : "🌙 ") + fa(hr).padStart(2, "۰") + ":" + fa(mn).padStart(2, "۰");
    $("top-left").textContent = G.showDebug ? ["FPS " + G.fps + "  RTT " + Math.max(0, G.rtt) + "ms", "XYZ " + me.x.toFixed(1) + " " + me.y.toFixed(1) + " " + me.z.toFixed(1), "chunk " + (Math.floor(me.x) >> 4) + "," + (Math.floor(me.z) >> 4) + "  meshes " + R.meshes.size + "  tris " + Math.round(R.stats.tris / 1000) + "k", "players " + (G.remote.size + 1) + "  enemies " + G.enemies.size + "  " + G.kind, R.info].join("\n") : (G.kind === "ws" || G.kind === "host" || G.kind === "guest" ? "👥 " + (G.remote.size + 1) : "");
    const lg = $("chatlog"); const nowT = G.time; [...lg.children].forEach((c) => { if (nowT - Number(c.dataset.t) > 9 && !G.chatOpen) c.style.opacity = 0; if (nowT - Number(c.dataset.t) > 11 && !G.chatOpen) c.remove(); });
    if (G.screen === "play" && !$("tabs").classList.contains("hide")) renderTabs();
  }
  function addChat(from, text, sys) {
    const d = document.createElement("div"); d.dataset.t = G.time; d.innerHTML = (from ? "<b style='color:#7be0ff'>" + esc(from) + ":</b> " : "<span style='color:#ffd23d'>● </span>") + esc(text); $("chatlog").appendChild(d);
    while ($("chatlog").children.length > 8) $("chatlog").firstChild.remove();
  }
  function renderTabs() {
    const rows = [[G.name + " (تو)", G.kills]]; G.remote.forEach((e) => rows.push([e.name, ""]));
    $("tabs").innerHTML = "<b style='color:#ffd23d'>بازیکنان (" + rows.length + ")</b>" + rows.map((r) => "<div><span>" + esc(r[0]) + "</span><span>" + (r[1] === "" ? "" : "☠ " + r[1]) + "</span></div>").join("");
  }
  function removeTag(id) { const t = G.tags.get(id); if (t) { t.remove(); G.tags.delete(id); } }

  /* ================= SCREENS / MENUS ================= */
  const SCREENS = ["craft", "scr-main", "scr-single", "scr-online", "scr-lan", "scr-guest", "scr-settings", "scr-help", "loading", "pause", "death", "inv", "host"];
  function showOnly(id) { SCREENS.forEach((s) => $(s).classList.toggle("hide", s !== id)); }
  function setScreen(s) {
    G.screen = s;
    const map = { menu: "scr-main", loading: "loading", pause: "pause", death: "death", inv: "inv", host: "host", craft: "craft", play: null };
    if (s === "menu") { showOnly(G.menuPage || "scr-main"); $("hud").classList.add("hide"); }
    else { showOnly(map[s]); $("hud").classList.toggle("hide", s === "loading"); }
    if (s !== "play") { inp.attack = inp.place = inp.jump = inp.ads = false; inp.f = inp.b = inp.l = inp.r = 0; }
  }
  function closeOverlay() { if (G.screen === "inv" || G.screen === "pause" || G.screen === "host" || G.screen === "craft") { setScreen("play"); lockPointer(); } }
  function lockPointer() { if (!touch && canvas.requestPointerLock) { try { canvas.requestPointerLock(); } catch (e) { /* */ } } }
  document.addEventListener("pointerlockchange", () => { if (!touch && !document.pointerLockElement && G.screen === "play") pauseGame(); });
  function pauseGame() { if (G.screen !== "play") return; document.exitPointerLock && document.exitPointerLock(); $("b-invite").classList.toggle("hide", G.kind !== "host"); $("pause-info").textContent = G.kind === "ws" ? "اتاق: " + (G.welcome ? G.welcome.room : "") + " · بازیکنان: " + (G.remote.size + 1) : G.kind === "host" ? "تو میزبان هستی · دوستان: " + G.remote.size : G.kind === "guest" ? "متصل به میزبان" : "بازی تک‌نفره ذخیره می‌شود"; setScreen("pause"); }
  document.querySelectorAll("[data-back]").forEach((b) => b.addEventListener("click", () => { G.menuPage = "scr-main"; showOnly("scr-main"); }));
  const go = (id, page) => { $(id).addEventListener("click", () => { window.SSAudio.unlock(); window.SSAudio.play("click"); G.menuPage = page; showOnly(page); }); };
  go("b-single", "scr-single"); go("b-online", "scr-online"); go("b-lan", "scr-lan"); go("b-help", "scr-help");
  $("b-settings").addEventListener("click", () => { G.settingsFrom = "scr-main"; openSettings(); });
  $("b-pset").addEventListener("click", () => { G.settingsFrom = "pause"; openSettings(); });
  function openSettings() {
    $("s-dist").value = cfg.dist; $("s-scale").value = cfg.scale; $("s-sens").value = cfg.sens; $("s-fov").value = cfg.fov; $("s-vol").value = cfg.vol; $("s-aj").checked = !!cfg.aj; $("s-fx").value = String(cfg.fx); syncSettings(); showOnly("scr-settings");
  }
  function syncSettings() { $("v-dist").textContent = $("s-dist").value + " تکه"; $("v-scale").textContent = $("s-scale").value + "٪"; $("v-sens").textContent = $("s-sens").value + "٪"; $("v-fov").textContent = $("s-fov").value + "°"; $("v-vol").textContent = $("s-vol").value + "٪"; }
  ["s-dist", "s-scale", "s-sens", "s-fov", "s-vol"].forEach((id) => $(id).addEventListener("input", syncSettings));
  $("b-settings-ok").addEventListener("click", () => {
    cfg.dist = +$("s-dist").value; cfg.scale = +$("s-scale").value; cfg.sens = +$("s-sens").value; cfg.fov = +$("s-fov").value; cfg.vol = +$("s-vol").value; cfg.aj = $("s-aj").checked; cfg.fx = +$("s-fx").value; R.setFx(cfg.fx); saveCfg();
    window.SSAudio.setVolume(cfg.vol / 100); resize(); G.lastP = "";
    if (G.settingsFrom === "pause") showOnly("pause"); else showOnly("scr-main");
  });
  $("in-name").addEventListener("input", () => { cfg.name = ($("in-name").value || "").trim(); saveCfg(); });
  $("in-name").value = cfg.name; $("in-server").value = cfg.server || (location.protocol.startsWith("http") ? location.host : ""); $("in-room").value = cfg.room;
  const getName = () => { const n = ($("in-name").value || "").trim().slice(0, 16) || "Player" + Math.floor(Math.random() * 900 + 100); cfg.name = ($("in-name").value || "").trim(); saveCfg(); return n; };

  /* ---------- starting games ---------- */
  function connect(net, kind, extra) {
    if (G.net) { try { G.net.close(); } catch (e) { /* */ } }
    G.net = net; G.kind = kind; G.remote.clear(); G.enemies.clear(); $("tags").innerHTML = ""; G.tags.clear(); $("chatlog").innerHTML = "";
    net.onmessage = onNet; net.onclose = (why) => { if (G.net === net && G.screen !== "menu") { toast("اتصال قطع شد"); leave(); } };
    const hello = () => net.send({ t: "join", name: G.joinName });
    if (net.kind === "local") queueMicrotask(hello); else net.onopen = hello;
    setScreen("loading"); $("load-text").textContent = "در حال اتصال…"; $("load-bar").style.width = "5%";
    window.SSAudio.unlock();
  }
  function startRoom(opts, save) {
    stopRoom();
    G.room = save ? Room.fromSave(save.room, { maxPlayers: opts.maxPlayers || 1 }) : new Room({ seed: opts.seed, mode: opts.mode, pvp: false, maxPlayers: opts.maxPlayers || 1 });
    G.room.maxPlayers = opts.maxPlayers || 1; let last = performance.now();
    G.roomTimer = setInterval(() => { const n = performance.now(), dt = Math.min(0.1, (n - last) / 1000); last = n; try { G.room.tick(dt); } catch (e) { console.error(e); } }, 50);
  }
  function stopRoom() { if (G.roomTimer) clearInterval(G.roomTimer); G.roomTimer = 0; G.room = null; if (G.hostHub) { G.hostHub.close(); G.hostHub = null; } }
  function startSingle(fresh) {
    window.SSAudio.unlock(); G.joinName = getName();
    const mode = document.querySelector("input[name=gm]:checked").value;
    const go2 = (save) => { startRoom({ seed: ($("in-seed").value || "").trim() || Math.floor(Math.random() * 1e9), mode, maxPlayers: 1 }, save); if (save && save.inv) G.restore = { inv: save.inv, score: save.score }; connect(SSNet.local(G.room), "single"); };
    if (fresh) return go2(null);
    idbGet("single").then((save) => go2(save)).catch(() => go2(null));
  }
  $("b-new").addEventListener("click", () => startSingle(true));
  $("b-continue").addEventListener("click", () => startSingle(false));
  $("b-connect").addEventListener("click", () => {
    window.SSAudio.unlock(); let addr = ($("in-server").value || "").trim().replace(/^(https?|wss?):\/\//, "").replace(/\/.*$/, ""), room = ($("in-room").value || "main").trim() || "main";
    if (!addr) { $("online-msg").textContent = "آدرس سرور را وارد کن."; return; }
    cfg.server = addr; cfg.room = room; saveCfg(); G.joinName = getName(); $("online-msg").textContent = "";
    const secure = location.protocol === "https:"; const net = SSNet.ws((secure ? "wss://" : "ws://") + addr + "/ws?room=" + encodeURIComponent(room));
    let opened = false; const origOpen = () => { opened = true; };
    connect(net, "ws"); const prev = net.onopen; net.onopen = () => { origOpen(); if (prev) prev(); };
    const fail = net.onclose; net.onclose = (why) => { if (!opened) { showOnly("scr-online"); G.screen = "menu"; $("hud").classList.add("hide"); $("online-msg").textContent = "اتصال برقرار نشد. آدرس و اجرای سرور را بررسی کن."; G.net = null; return; } fail && fail(why); };
  });
  // ---- Wi-Fi host ----
  $("b-host").addEventListener("click", () => {
    window.SSAudio.unlock(); G.joinName = getName(); const mode = document.querySelector("input[name=gm2]:checked").value;
    startRoom({ seed: Math.floor(Math.random() * 1e9), mode, maxPlayers: 6 }, null);
    G.hostHub = SSNet.rtcHost(G.room, (g) => { renderGuests(g); });
    connect(SSNet.local(G.room), "host");
  });
  const guests = new Map();
  function renderGuests(g) { if (g) guests.set(g.id, g.state); $("guests").innerHTML = Array.from(guests.entries()).map(([id, s]) => "<div>" + (s === "connected" ? "✅ دوست متصل شد" : s === "failed" ? "❌ اتصال ناموفق" : s === "closed" ? "⚪ قطع شد" : "…") + "</div>").join(""); }
  function openHostPanel() { guests.clear(); renderGuests(); $("t-h-offer").value = ""; $("t-h-answer").value = ""; $("host-msg").textContent = ""; document.exitPointerLock && document.exitPointerLock(); setScreen("host"); }
  $("b-invite").addEventListener("click", openHostPanel);
  $("b-h-close").addEventListener("click", () => { setScreen("play"); lockPointer(); });
  $("b-h-make").addEventListener("click", async () => {
    $("host-msg").textContent = "در حال ساخت کد…";
    try { const inv = await G.hostHub.invite(); G.curInvite = inv.id; $("t-h-offer").value = inv.code; $("host-msg").textContent = "کد را برای دوستت بفرست (مثلاً در تلگرام) و کد پاسخ او را بگیر."; } catch (e) { $("host-msg").textContent = "خطا: " + e.message; }
  });
  $("b-h-accept").addEventListener("click", async () => {
    try { await G.hostHub.accept(G.curInvite, $("t-h-answer").value); $("host-msg").textContent = "در حال اتصال…"; } catch (e) { $("host-msg").textContent = "خطا: " + e.message; }
  });
  const copyText = async (ta, btn) => { try { await navigator.clipboard.writeText(ta.value); toast("کپی شد"); } catch (e) { ta.removeAttribute("readonly"); ta.select(); document.execCommand("copy"); toast("کپی شد"); } };
  $("b-h-copy").addEventListener("click", () => copyText($("t-h-offer")));
  $("b-g-copy").addEventListener("click", () => copyText($("t-g-answer")));
  // ---- Wi-Fi guest ----
  $("b-guest").addEventListener("click", () => { $("t-g-offer").value = ""; $("t-g-answer").value = ""; $("guest-msg").textContent = ""; G.menuPage = "scr-guest"; showOnly("scr-guest"); });
  $("b-g-make").addEventListener("click", async () => {
    window.SSAudio.unlock(); G.joinName = getName(); $("guest-msg").textContent = "در حال ساخت پاسخ…";
    try {
      const r = await SSNet.rtcGuest($("t-g-offer").value); $("t-g-answer").value = r.answerCode; $("guest-msg").textContent = "این کد پاسخ را برای میزبان بفرست؛ بعد از اتصال او، بازی خودکار شروع می‌شود.";
      const net = r.net; net.onmessage = onNet; net.onclose = () => { if (G.net === net && G.screen !== "menu") { toast("اتصال قطع شد"); leave(); } };
      net.onopen = () => { connect(net, "guest"); net.onmessage = onNet; net.send({ t: "join", name: G.joinName }); };
    } catch (e) { $("guest-msg").textContent = "خطا: " + e.message; }
  });
  function leave() {
    saveSingle(); if (G.net) { try { G.net.close(); } catch (e) { /* */ } } G.net = null; stopRoom(); G.world = null; G.me = null; G.loaded = false; window.SSFx.reset(); R.meshes.forEach((m, k) => R.dropChunk(k));
    document.exitPointerLock && document.exitPointerLock(); G.menuPage = "scr-main"; setScreen("menu"); refreshMain();
  }
  $("b-leave").addEventListener("click", leave);
  $("b-resume").addEventListener("click", () => { setScreen("play"); lockPointer(); });
  $("b-respawn").addEventListener("click", () => { if (G.net) G.net.send({ t: "respawn" }); });
  $("b-inv-close").addEventListener("click", closeOverlay); $("b-craft-close").addEventListener("click", closeOverlay);

  /* ---------- single-player save (IndexedDB) ---------- */
  function idb() { return new Promise((res, rej) => { const r = indexedDB.open("ssv", 1); r.onupgradeneeded = () => r.result.createObjectStore("w"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
  const idbGet = (k) => idb().then((db) => new Promise((res, rej) => { const q = db.transaction("w").objectStore("w").get(k); q.onsuccess = () => res(q.result || null); q.onerror = () => rej(q.error); }));
  const idbSet = (k, v) => idb().then((db) => new Promise((res, rej) => { const t = db.transaction("w", "readwrite"); t.objectStore("w").put(v, k); t.oncomplete = () => res(); t.onerror = () => rej(t.error); }));
  function saveSingle() {
    if (G.kind !== "single" || !G.room || !G.me) return;
    const save = { v: 1, room: G.room.serialize(), inv: { counts: G.counts, hotbar: G.hotbar }, score: G.score, at: Date.now() };
    save.room.players = { [G.name]: { x: G.me.x, y: G.me.y, z: G.me.z } };
    idbSet("single", save).catch(() => {});
  }
  function refreshMain() {
    idbGet("single").then((s) => { $("b-continue").classList.toggle("hide", !s); $("main-note").textContent = s ? "ذخیره‌ی قبلی: " + new Date(s.at).toLocaleString("fa-IR") : ""; }).catch(() => $("b-continue").classList.add("hide"));
  }
  setInterval(() => { if (G.screen === "play" || G.screen === "pause") saveSingle(); }, 15000);
  document.addEventListener("visibilitychange", () => { if (document.hidden) { saveSingle(); if (G.screen === "play" && touch) pauseGame(); } });

  /* ================= INPUT ================= */
  const keyMap = { KeyW: "f", KeyS: "b", KeyA: "l", KeyD: "r", ArrowUp: "f", ArrowDown: "b", ArrowLeft: "l", ArrowRight: "r" };
  window.addEventListener("keydown", (e) => {
    if (G.chatOpen) { if (e.key === "Enter") { const t = $("chatin").value.trim(); if (t && G.net) G.net.send({ t: "chat", text: t }); closeChat(); e.preventDefault(); } else if (e.key === "Escape") { closeChat(); e.preventDefault(); } return; }
    if (G.screen !== "play") { if (e.key === "Escape" && (G.screen === "inv" || G.screen === "host" || G.screen === "craft")) closeOverlay(); else if (e.code === "KeyB" && G.screen === "craft") closeOverlay(); else if (e.code === "KeyE" && G.screen === "inv") closeOverlay(); return; }
    const k = keyMap[e.code];
    if (k) { inp[k] = 1; e.preventDefault(); return; }
    if (e.code === "Space") { e.preventDefault(); if (!e.repeat) { const t = performance.now(); if (G.gameMode === "creative" && t - (G.lastSpace || 0) < 280) { G.me.flying = !G.me.flying; G.me.vy = 0; } G.lastSpace = t; } inp.jump = true; return; }
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") { inp.sprint = true; return; }
    if (e.code === "ControlLeft" || e.code === "KeyC") { inp.crouch = true; e.preventDefault(); return; }
    if (/^Digit[1-9]$/.test(e.code)) { selectSlot(+e.code.slice(5) - 1); return; }
    switch (e.code) {
      case "KeyB": openCraft(); break;
      case "KeyE": document.exitPointerLock && document.exitPointerLock(); G.screen = "play"; openInventory(); break;
      case "KeyR": { const it = item(); if (it && it.k === "w") startReload(it.w); break; }
      case "KeyF": useAbility("phase"); break;
      case "KeyG": useAbility("scan"); break;
      case "KeyQ": selectSlot(G.lastSel); break;
      case "KeyT": case "Enter": e.preventDefault(); openChat(); break;
      case "Tab": e.preventDefault(); $("tabs").classList.remove("hide"); renderTabs(); break;
      case "F3": e.preventDefault(); G.showDebug = !G.showDebug; break;
      default: break;
    }
  });
  window.addEventListener("keyup", (e) => {
    const k = keyMap[e.code]; if (k) inp[k] = 0;
    if (e.code === "Space") inp.jump = false; if (e.code === "ShiftLeft" || e.code === "ShiftRight") inp.sprint = false; if (e.code === "ControlLeft" || e.code === "KeyC") inp.crouch = false;
    if (e.code === "Tab") $("tabs").classList.add("hide");
  });
  window.addEventListener("blur", () => { inp.f = inp.b = inp.l = inp.r = 0; inp.jump = inp.sprint = inp.crouch = inp.attack = inp.place = inp.ads = false; });
  canvas.addEventListener("mousedown", (e) => { if (G.screen !== "play") return; if (!document.pointerLockElement && !touch) { lockPointer(); return; } if (e.button === 0) inp.attack = true; else if (e.button === 2) { const w0 = item(); if (w0 && w0.k === "w") inp.ads = true; else { inp.place = true; inp.placeT = 0; } } });
  window.addEventListener("mouseup", (e) => { if (e.button === 0) inp.attack = false; else if (e.button === 2) { inp.place = false; inp.ads = false; } });
  canvas.addEventListener("contextmenu", (e) => e.preventDefault());
  window.addEventListener("mousemove", (e) => { if (G.screen !== "play" || !document.pointerLockElement || !G.me) return; const s = 0.0022 * cfg.sens / 100 * (1 - G.ads * 0.5); G.me.yaw -= e.movementX * s; G.me.pitch = Math.max(-1.55, Math.min(1.55, G.me.pitch - e.movementY * s)); });
  window.addEventListener("wheel", (e) => { if (G.screen !== "play") return; selectSlot((G.sel + (e.deltaY > 0 ? 1 : 8)) % 9); }, { passive: true });
  function useAbility(k) {
    if (!G.alive || G.screen !== "play") return;
    if (k === "phase" && G.abil.phase <= 0) { G.abil.phase = 20; if (G.net) G.net.send({ t: "ab", k: "phase" }); }
    else if (k === "scan" && G.abil.scan <= 0) { G.abil.scan = 25; G.abil.scanOn = 6; window.SSAudio.play("scan"); toast("اسکن شکاف: دشمنان نمایان شدند"); }
  }
  function openChat() { if (G.screen !== "play") return; G.chatOpen = true; document.exitPointerLock && document.exitPointerLock(); $("chatrow").classList.remove("hide"); $("chatin").value = ""; $("chatin").focus(); [...$("chatlog").children].forEach((c) => { c.style.opacity = 1; }); }
  function closeChat() { G.chatOpen = false; $("chatrow").classList.add("hide"); $("chatin").blur(); lockPointer(); }
  // ---- touch ----
  const bindHold = (id, on, off) => { const el = $(id); el.addEventListener("pointerdown", (e) => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (x) { /* synthetic or finished pointer */ } el.classList.add("on"); on(); }); const up = (e) => { el.classList.remove("on"); off && off(); }; el.addEventListener("pointerup", up); el.addEventListener("pointercancel", up); };
  bindHold("t-attack", () => { inp.attack = true; }, () => { inp.attack = false; });
  bindHold("t-place", () => { const w0 = item(); if (w0 && w0.k === "w") inp.ads = true; else { inp.place = true; inp.placeT = 0; } }, () => { inp.place = false; inp.ads = false; });
  bindHold("t-jump", () => { const t = performance.now(); if (G.me && G.gameMode === "creative" && t - (G.lastSpace || 0) < 300) { G.me.flying = !G.me.flying; G.me.vy = 0; } G.lastSpace = t; inp.jump = true; }, () => { inp.jump = false; });
  bindHold("t-down", () => { inp.crouch = true; }, () => { inp.crouch = false; });
  bindHold("t-reload", () => { const it = item(); if (it && it.k === "w") startReload(it.w); });
  bindHold("t-phase", () => useAbility("phase")); bindHold("t-scan", () => useAbility("scan"));
  bindHold("t-craft", () => openCraft()); bindHold("t-menu", () => pauseGame()); bindHold("t-chat", () => { openChat(); }); bindHold("t-inv", () => openInventory()); bindHold("t-list", () => { const t = $("tabs"); t.classList.toggle("hide"); renderTabs(); });
  (function () {
    const joy = $("joy"), knob = $("knob"); let id = null;
    const move = (e) => { const r = joy.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2; let dx = (e.clientX - cx) / (r.width / 2), dy = (e.clientY - cy) / (r.height / 2); const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; } inp.joyX = dx; inp.joyY = -dy; knob.style.transform = "translate(" + dx * 38 + "px," + dy * 38 + "px)"; };
    joy.addEventListener("pointerdown", (e) => { e.preventDefault(); id = e.pointerId; try { joy.setPointerCapture(id); } catch (x) { /* */ } move(e); });
    joy.addEventListener("pointermove", (e) => { if (e.pointerId === id) move(e); });
    const end = (e) => { if (e.pointerId !== id) return; id = null; inp.joyX = inp.joyY = 0; knob.style.transform = ""; };
    joy.addEventListener("pointerup", end); joy.addEventListener("pointercancel", end);
    const look = $("look"); let lid = null, lx = 0, ly = 0, lt = 0, moved = 0;
    look.addEventListener("pointerdown", (e) => { e.preventDefault(); lid = e.pointerId; try { look.setPointerCapture(lid); } catch (x) { /* */ } lx = e.clientX; ly = e.clientY; lt = performance.now(); moved = 0; });
    look.addEventListener("pointermove", (e) => { if (e.pointerId !== lid || !G.me || G.screen !== "play") return; const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY; moved += Math.abs(dx) + Math.abs(dy); const s = 0.0042 * cfg.sens / 100 * (1 - G.ads * 0.5); G.me.yaw -= dx * s; G.me.pitch = Math.max(-1.55, Math.min(1.55, G.me.pitch - dy * s)); });
    const lend = (e) => { if (e.pointerId !== lid) return; lid = null; if (moved < 8 && performance.now() - lt < 220 && G.screen === "play") { inp.place = false; placeBlock(); } };
    look.addEventListener("pointerup", lend); look.addEventListener("pointercancel", () => { lid = null; });
  })();

  /* ---------- boot ---------- */
  window.SSFx.onBoom = (d) => { setTimeout(() => { window.SSAudio.play("boom", d); G.shake = Math.max(G.shake, 0.55 * Math.max(0.2, 1 - d / 140)); }, d / 343 * 1000); };
  initPool(); setScreen("menu"); refreshMain(); window.SSAudio.setVolume(cfg.vol / 100);
  requestAnimationFrame(frame);
  if ("serviceWorker" in navigator && location.protocol.startsWith("http") && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) navigator.serviceWorker.register("service-worker.js").catch(() => {});
  Object.assign(window.SSGame, { atlas, blockColor, pool, craft, canCraft, dropFor, mineMult, eat, RECIPES, ITEMS, giveId, openCraft, startSingle, selectSlot, breakBlock, placeBlock, target, eyePos, lookDir, setScreen, leave, addBlock, fire, useAbility, pauseGame, openInventory, stream, meshOne, loadProgress, initInventory, buildEntities });
})();
