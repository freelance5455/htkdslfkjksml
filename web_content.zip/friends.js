(function () {
  var A = window.App, $ = A.$, esc = A.esc;
  if (!A.init({ nav: 'friends' })) return;
  var query = '';

  function row(f) {
    return '<div class="flex items-center gap-3 p-3 rounded-2xl bg-card border border-border" data-id="' + esc(f.id) + '">' +
      '<a href="chat.html?id=' + encodeURIComponent(f.id) + '" class="flex items-center gap-3 min-w-0 flex-1">' +
      '<div class="relative shrink-0"><img src="' + A.avatar(f) + '" class="size-12 rounded-full object-cover" alt="" /><span class="absolute right-0 bottom-0 size-3.5 rounded-full border-2 border-card ' + (f.online ? 'bg-accent' : 'bg-muted-foreground') + '"></span></div>' +
      '<div class="min-w-0"><p class="font-heading font-extrabold truncate">' + esc(f.name) + '</p><p class="text-[11px] text-muted-foreground font-semibold truncate">@' + esc(f.username) + ' • ' + esc(f.status) + '</p></div></a>' +
      '<button type="button" data-act="best" class="size-9 rounded-full border border-border flex items-center justify-center ' + (f.best ? 'bg-primary text-primary-foreground' : 'bg-input text-muted-foreground') + '" aria-label="' + (f.best ? 'En iyi arkadaşlıktan çıkar' : 'En iyi arkadaş yap') + '"><iconify-icon icon="solar:heart-bold" width="18" height="18"></iconify-icon></button>' +
      '<button type="button" data-act="remove" class="size-9 rounded-full bg-input border border-border flex items-center justify-center text-destructive" aria-label="Arkadaşı kaldır"><iconify-icon icon="solar:trash-bin-trash-bold" width="18" height="18"></iconify-icon></button></div>';
  }
  function section(title, list) {
    return list.length ? '<section><div class="flex items-center justify-between mb-2"><h2 class="font-heading text-base font-extrabold">' + title + '</h2><span class="text-xs font-bold text-muted-foreground">' + list.length + '</span></div><div class="space-y-2">' + list.map(row).join('') + '</div></section>' : '';
  }
  function render() {
    var all = A.friends(), q = query.trim().toLocaleLowerCase('tr-TR');
    var list = all.filter(function (f) { return !q || (f.name + ' ' + f.username).toLocaleLowerCase('tr-TR').indexOf(q) >= 0; })
      .sort(function (a, b) { return a.name.localeCompare(b.name, 'tr'); });
    $('#count').textContent = all.length + ' arkadaş • ' + all.filter(function (f) { return f.online; }).length + ' çevrimiçi';
    var box = $('#list');
    if (!all.length) {
      box.innerHTML = '<div class="text-center py-10 px-6 rounded-2xl bg-card border border-dashed border-border"><div class="size-14 rounded-full bg-primary/15 text-primary mx-auto flex items-center justify-center mb-3"><iconify-icon icon="solar:user-plus-bold" width="28" height="28"></iconify-icon></div><p class="font-heading font-extrabold">Arkadaş listen boş</p><p class="text-xs text-muted-foreground font-semibold mt-1 mb-4">Kullanıcı adıyla arkadaş ekleyebilirsin.</p><button type="button" id="empty-add" class="h-11 px-5 rounded-2xl bg-primary text-primary-foreground text-sm font-extrabold">Arkadaş ekle</button></div>';
      $('#empty-add').addEventListener('click', function () { A.openAddFriend(); });
      return;
    }
    if (!list.length) { box.innerHTML = '<p class="text-center text-sm font-semibold text-muted-foreground py-8">Eşleşen arkadaş yok.</p>'; return; }
    box.innerHTML = section('En iyi arkadaşlar', list.filter(function (f) { return f.best; })) + section('Tüm arkadaşlar', list.filter(function (f) { return !f.best; }));
  }

  $('#list').addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]'); if (!b) return;
    var id = b.closest('[data-id]').getAttribute('data-id'), f = A.friendById(id);
    if (!f) return;
    if (b.getAttribute('data-act') === 'best') {
      A.toggleBest(id); A.toast(f.best ? f.name + ' en iyi arkadaşlardan çıkarıldı' : f.name + ' en iyi arkadaş oldu ♥');
    } else {
      A.confirm('Arkadaşı kaldır', f.name + ' arkadaş listenden ve sohbet geçmişinden silinecek.', 'Kaldır', true).then(function (ok) {
        if (ok) { A.removeFriend(id); A.toast(f.name + ' kaldırıldı'); }
      });
    }
  });
  $('#search').addEventListener('input', function (e) { query = e.target.value; render(); });
  $('#add-btn').addEventListener('click', function () { A.openAddFriend(); });
  $('#back-btn').addEventListener('click', function () { location.href = 'home.html'; });
  A.onChange(render);
  render();
})();
