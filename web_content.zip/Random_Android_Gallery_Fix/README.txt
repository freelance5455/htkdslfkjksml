Random Android - Gallery/WebView Fix

This project runs Random_Final_v12.html inside Android WebView.
The native WebChromeClient.onShowFileChooser() implementation opens the Android image picker when the HTML file input is triggered.

Open this folder in Android Studio and Build > Build APK(s).
No broad storage permission is required; ACTION_OPEN_DOCUMENT is used.
