# Socle 2.6 — Identité visuelle des clubs et galaxies

## Objectif
Donner à chaque club et à chaque galaxie une identité visuelle propre, éditable et persistante, sans toucher aux moteurs des huit compétitions.

## Catalogues
- 25 motifs de maillot.
- 25 motifs d'emblème.
- 25 motifs de drapeau.
- 30 palettes de couleurs coordonnées.
- Numéro visuel de maillot et symbole d'emblème.

Chaque club et chacune des 24 galaxies reçoit une combinaison initiale distincte pour son maillot, son emblème et son drapeau. Le validateur compare les signatures sur l'ensemble des clubs et galaxies, et refuse les doublons. L'éditeur permet de choisir une entité, un motif et les couleurs de chaque élément. Les changements sont enregistrés dans la sauvegarde locale de carrière.

## Présentation visuelle
Le damier reçoit un premier traitement de profondeur CSS : perspective légère, bordure métallique, cases texturées et pions ombrés. Les aperçus de maillot, d'emblème et de drapeau affichent des motifs distincts.

## Limite technique explicite
Ce socle n'est pas encore un moteur de match 3D photoréaliste. Il ne contient pas encore de scène WebGL, de modèles 3D animés, de caméra dynamique, de public 3D, de motion capture ni de rendu de stade. Ces éléments nécessitent une tranche graphique dédiée, avec moteur 3D, modèles, matériaux, éclairage, animation et tests de performance sur mobile. La perspective CSS actuelle est une amélioration de présentation, pas une simulation 3D complète.

## Préservation
Aucun fichier moteur de compétition n'a été modifié : Coupe Galactique, Coupe des Clubs, Champions League, Intergalactique des Clubs, Coupe Intergalactique des galaxies, Coupe Lunaire, Dame d'Or et Coupe Fédéral restent séparées et intactes.

## Vérifications
- 157 tests automatisés réussis.
- 36 clubs initiaux et 24 galaxies reçoivent 60 identités distinctes.
- Au moins 20 motifs vérifiés dans chacune des trois catégories.
- Modifications, validation des motifs et validation des couleurs testées.
- Syntaxe JavaScript et intégrité ZIP vérifiées.
- Le navigateur headless n'a pas fourni de capture DOM exploitable ; validation visuelle complète à refaire dans un navigateur interactif.
