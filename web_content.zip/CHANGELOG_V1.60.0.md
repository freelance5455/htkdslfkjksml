# Carreira de Craque v1.60.0 — Cronologia real das partidas

- Corrigido o agendamento da primeira fase da Copa do Brasil: jogos passam para o dia 18, entre a 2ª rodada do Brasileirão (dia 14) e a 3ª rodada (dia 21).
- O calendário de partidas usa datas explícitas por rodada do Brasileirão (7, 14, 21, 28...) e ordena os jogos da Copa pela data real gravada no confronto.
- A navegação de partidas agora escolhe o próximo compromisso cronologicamente: Brasileirão ou Copa do Brasil, o que vier primeiro.
- Depois de uma partida do Brasileirão, o avanço considera a data exata da próxima rodada e antecipa para uma partida da Copa se ela acontecer antes.
- A partida da Copa não faz o calendário voltar para uma rodada anterior do Brasileirão.
- A versão do calendário da Copa foi atualizada para gerar os novos dias corretamente.
- Mantidos os 64 participantes, os quatro clubes exclusivos da Copa, o chaveamento, as regras e o destaque azul no calendário.
