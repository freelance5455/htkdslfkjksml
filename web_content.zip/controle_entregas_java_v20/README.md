# Controle de Entregas — Java v20: teste de backup e restauração

Esta versão mantém o histórico local da v19 e corrige a ponte entre a interface HTML e o Android para backups externos.

## Mudanças
- Exportar backup e Baixar arquivo abrem o seletor nativo do Android (Salvar como).
- Importar backup abre o seletor de arquivos do Android.
- O conteúdo selecionado é lido pelo Android e entregue à interface para validação/restauração.
- A interface só informa que o arquivo foi salvo depois de o Android confirmar a escrita.
- A restauração valida o JSON e pede confirmação antes de substituir os dados.

## Testar com cuidado
1. Preserve a versão atualmente instalada até garantir que seus dados estejam seguros.
2. Compile este projeto como APK.
3. Abra Backups > Exportar backup; escolha Downloads ou outra pasta e salve.
4. Confirme que o arquivo JSON existe no aplicativo Arquivos.
5. Toque em Importar backup e selecione o JSON recém-criado.
6. Confirme a restauração. Faça isso primeiro com dados de teste, pois restaurar substitui os dados atuais.

## Compilação
Abra esta pasta no Android Studio com JDK 17 e Android SDK 35. Sincronize Gradle e use Build > Build APK(s).

## Limitação importante
Não foi possível executar uma compilação Android neste ambiente; é necessário validar no Android Studio. Antes de instalar sobre a versão atual, confira assinatura/versão e preserve os dados. A interface e as regras de negócio continuam em HTML/JavaScript dentro do app; o seletor de arquivos e o armazenamento externo são implementados em Java.


## Ajuste de abertura (v21)
Esta compilação tenta corrigir o caminho `/web/index.html` mostrado na tela de erro, servindo os assets também por `/web/`. A ponte de backup/restauração foi mantida. Ainda precisa ser compilada e testada em Android; não é um APK pronto.
