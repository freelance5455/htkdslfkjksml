# Controle de Entregas — v24 (configuração e backups)

## Alterações
- Janela de confirmação de configuração redesenhada como modal visual, com confirmação clara.
- Frequência padrão de backup automático alterada para 15 minutos.
- Cada backup manual/automático é enviado também para um arquivo JSON separado no armazenamento interno privado do app, sem política de apagar os anteriores.
- Mantém os três backups recentes na interface e a restauração local já testada.
- Mantém seleção nativa Android para exportar e importar arquivos JSON, com mensagens de erro se o seletor não puder ser aberto.

## Compilar e testar
Abra a pasta `controle_entregas_java_v20` no Android Studio (JDK 17, SDK 35), sincronize Gradle e use Build > Build APK(s).
1. Não desinstale a versão com os dados atuais.
2. Teste salvar configuração e ver o novo modal.
3. Verifique que a frequência inicial é 15 minutos.
4. Teste Exportar backup e confirme que o seletor do Android aparece e que o JSON fica em Downloads.
5. Teste Importar backup com um arquivo de teste.
6. Confirme que backups automáticos são registrados.

## Limite importante
Nenhum aplicativo consegue garantir que dados nunca serão perdidos em absolutamente todas as circunstâncias. Arquivos no armazenamento interno privado podem ser apagados se os dados do app forem limpos, o app for desinstalado, ou o aparelho for perdido/danificado. Para proteção contra esses casos, é necessário exportar periodicamente arquivos JSON para uma pasta externa ou nuvem. Este projeto ainda precisa ser compilado e validado no aparelho; não é um APK pronto.
