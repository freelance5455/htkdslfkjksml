# Controle de Entregas — v24 (configuração e backups)

## Alterações
- Janela de confirmação de configuração redesenhada como modal visual, com confirmação clara.
- Frequência padrão de backup automático alterada para 15 minutos.
- Cada backup manual/automático é enviado também para um arquivo JSON separado no armazenamento interno privado do app, sem política de apagar os anteriores.
- Mantém os três backups recentes na interface e a restauração local já testada.
- Mantém seleção nativa Android para exportar e importar arquivos JSON, com mensagens de erro se o seletor não puder ser aberto.

## Compilar e testar
Abra a pasta `controle_entregas_java_v20` no Android Studio (JDK 17, SDK 35), sincronize Gradle e use Build > Build APK(s).
1. Não desinstale a versão com os dados atuais.
2. Teste salvar configuração e ver o novo modal.
3. Verifique que a frequência inicial é 15 minutos.
4. Teste Exportar backup e confirme que o seletor do Android aparece e que o JSON fica em Downloads.
5. Teste Importar backup com um arquivo de teste.
6. Confirme que backups automáticos são registrados.

## Limite importante
Nenhum aplicativo consegue garantir que dados nunca serão perdidos em absolutamente todas as circunstâncias. Arquivos no armazenamento interno privado podem ser apagados se os dados do app forem limpos, o app for desinstalado, ou o aparelho for perdido/danificado. Para proteção contra esses casos, é necessário exportar periodicamente arquivos JSON para uma pasta externa ou nuvem. Este projeto ainda precisa ser compilado e validado no aparelho; não é um APK pronto.


## v25 — recursos semanais e edição da origem
- Adiciona cartão de progresso de alvo semanal com barras para cada nível.
- Remove a meta semanal de dentro das barras de alvos diários.
- O formulário de edição de entrega deixa explícita a edição de origem/plataforma.
- Adiciona aba Histórico semanal com bruto, líquido estimado, gasolina, fundos variáveis, contagem e totais por plataforma.
- O indicador de dias trabalhados da semana usa meta padrão de 6 dias.

A fonte precisa ser compilada e testada no Android Studio. Não é APK pronto. A soma semanal de gasolina e fundos usa os dados disponíveis no app; quando não existe gasolina real registrada num fechamento, é apresentada a estimativa calculada.

## Recuperação da v25
Esta é a lógica funcional da v25, recompacotada com versão Android 1.9/versionCode 10 apenas para permitir instalar como atualização sobre builds de teste posteriores sem exigir desinstalação. O carregamento inicial lê `assets/index.html` diretamente de dentro do APK e usa `loadDataWithBaseURL` com origem HTTPS estável em `/assets/`; não navega para `/web/index.html`.
**Instalação:** compile e instale por cima da versão atual, sem desinstalar e sem limpar os dados. Faça backup antes. Se o Android recusar instalação, não desinstale: informe a mensagem exata.

## v26 — ajustes solicitados para testes
- Mantida a base funcional da v25 recuperada.
- Edição de entrega agora permite alterar horário, plataforma e valor.
- Histórico diário e semanal reunidos em uma única aba, com subabas internas.
- Gráfico semanal passa a exibir barra do líquido e bruto em texto complementar; diário/mensal mantêm comparação anterior.
- Histórico semanal redesenhado em cartões com indicadores, total de fundos e detalhamento de cada fundo variável e plataforma.
- WebChromeClient implementa alertas, confirmações e prompts Android com título próprio "Controle de Entregas", sem o cabeçalho "A página em...".
- Compile e teste antes de substituir; instale por cima sem desinstalar e sem limpar dados.

## v27 — correções após teste da v26
- Exclusão de entrega e histórico diário migrada para modal HTML próprio com botões explicitamente conectados; evita depender de `confirm()` nativo.
- Alvo semanal agora usa o líquido como progresso principal e exibe o bruto realizado e a meta bruta em texto complementar.
- Composição dos fundos e ganhos por plataforma usam botões claros "Ocultar valores" / "Exibir valores", com indicação explícita.
