# Controle de Entregas — v23 (correção do carregamento inicial)

A v23 carrega o `assets/index.html` diretamente por `AssetManager` e o entrega ao WebView com `loadDataWithBaseURL()` usando uma origem HTTPS estável. Isso evita depender do caminho `/web/index.html` que apareceu no erro das versões anteriores.

A ponte Java para exportar/importar arquivos JSON foi mantida.

## Teste
- Compile este projeto no Android Studio com JDK 17 e SDK 35.
- Preserve a v19 e seus dados.
- Instale e abra a v23; a tela principal deve aparecer.
- Só depois teste Exportar backup e Importar backup.

Esta fonte ainda não foi compilada nem validada em aparelho neste ambiente. Não é um APK pronto. Se o erro persistir, envie a tela e o `MainActivity.java` do projeto realmente compilado para verificar se o Android Studio está usando a pasta certa.
