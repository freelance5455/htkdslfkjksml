# Controle de Entregas — v24 (configuração e backups)

## Alterações
- Janela de confirmação de configuração redesenhada como modal visual, com confirmação clara.
- Frequência padrão de backup automático alterada para 15 minutos.
- Cada backup manual/automático é enviado também para um arquivo JSON separado no armazenamento interno privado do app, sem política de apagar os anteriores.
- Mantém os três backups recentes na interface e a restauração local já testada.
- Mantém seleção nativa Android para exportar e importar arquivos JSON, com mensagens de erro se o seletor não puder ser aberto.

## Compilar e testar
Abra a pasta `controle_entregas_java_v20` no Android Studio (JDK 17, SDK 35), sincronize Gradle e use Build > Build APK(s).
1. Não desinstale a versão com os dados atuais.
2. Teste salvar configuração e ver o novo modal.
3. Verifique que a frequência inicial é 15 minutos.
4. Teste Exportar backup e confirme que o seletor do Android aparece e que o JSON fica em Downloads.
5. Teste Importar backup com um arquivo de teste.
6. Confirme que backups automáticos são registrados.

## Limite importante
Nenhum aplicativo consegue garantir que dados nunca serão perdidos em absolutamente todas as circunstâncias. Arquivos no armazenamento interno privado podem ser apagados se os dados do app forem limpos, o app for desinstalado, ou o aparelho for perdido/danificado. Para proteção contra esses casos, é necessário exportar periodicamente arquivos JSON para uma pasta externa ou nuvem. Este projeto ainda precisa ser compilado e validado no aparelho; não é um APK pronto.


## v25 — recursos semanais e edição da origem
- Adiciona cartão de progresso de alvo semanal com barras para cada nível.
- Remove a meta semanal de dentro das barras de alvos diários.
- O formulário de edição de entrega deixa explícita a edição de origem/plataforma.
- Adiciona aba Histórico semanal com bruto, líquido estimado, gasolina, fundos variáveis, contagem e totais por plataforma.
- O indicador de dias trabalhados da semana usa meta padrão de 6 dias.

A fonte precisa ser compilada e testada no Android Studio. Não é APK pronto. A soma semanal de gasolina e fundos usa os dados disponíveis no app; quando não existe gasolina real registrada num fechamento, é apresentada a estimativa calculada.


## Alterações da v26
- Histórico diário e semanal reunidos em uma única aba Histórico.
- Edição de entrega agora permite alterar horário, plataforma e valor.
- Seções do histórico podem ser recolhidas e reexibidas com os botões Ocultar/Exibir.
- Projeto-fonte; compile e teste no Android Studio antes de substituir a versão instalada.

Sanity checks gerados para v26: unified_history_nav=OK, editable_hour_field=OK, hour_saved=OK, collapsible_sections=OK, weekly_history_in_history_tab=OK

## Alterações da v27 (correções após testes)
- Corrigido o acionamento dos botões Ocultar/Exibir por delegação de eventos e alternância explícita de display.
- Ao salvar edição de entrega, a janela fecha e aparece confirmação de alteração.
- Campo de hora da nova entrega mantém a hora atual como padrão e tem contraste explícito para os menus de seleção.
- Gráfico de alvo semanal realocado para o painel detalhado.
- Som de registro preservado com tentativa de retomar o AudioContext em dispositivos móveis.
- Exclusão de entrega e de histórico diário usa janela de confirmação interna estilizada, sem o texto nativo da página.
- Salvamento local continua em cada alteração; backup automático respeita a frequência configurada. Testar no dispositivo, pois o armazenamento interno Android depende da ponte nativa.
