package br.com.controleentregas.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_SAVE_BACKUP = 5101;
    private static final int REQUEST_OPEN_BACKUP = 5102;
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private String pendingBackupPayload = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/web/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF4F7FB);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackupBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/web/index.html");
    }

    private class BackupBridge {
        @JavascriptInterface
        public void saveBackupFile(String payload, String filename) {
            runOnUiThread(() -> {
                pendingBackupPayload = payload;
                String safeName = (filename == null ? "backup-controle-entregas.json" : filename)
                        .replaceAll("[^a-zA-Z0-9._-]", "-");
                if (!safeName.toLowerCase().endsWith(".json")) safeName += ".json";
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                startActivityForResult(intent, REQUEST_SAVE_BACKUP);
            });
        }

        @JavascriptInterface
        public void pickBackupFile() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
                startActivityForResult(intent, REQUEST_OPEN_BACKUP);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQUEST_SAVE_BACKUP) {
                pendingBackupPayload = null;
                callJs("document.getElementById('backupMsg').textContent='Salvamento cancelado. Nenhum arquivo foi criado.';");
            } else if (requestCode == REQUEST_OPEN_BACKUP) {
                callJs("document.getElementById('backupMsg').textContent='Importação cancelada. Nenhum dado foi alterado.';");
            }
            return;
        }

        Uri uri = data.getData();
        if (requestCode == REQUEST_SAVE_BACKUP) {
            try {
                if (pendingBackupPayload == null) throw new IllegalStateException("Não há conteúdo para salvar.");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new IllegalStateException("O Android não abriu o destino do arquivo.");
                    out.write(pendingBackupPayload.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingBackupPayload = null;
                callJs("document.getElementById('backupMsg').textContent='Arquivo JSON salvo com sucesso no local escolhido.';");
                Toast.makeText(this, "Backup salvo", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                pendingBackupPayload = null;
                callJs("document.getElementById('backupMsg').textContent='Falha ao salvar o arquivo: ' + " + JSONObject.quote(String.valueOf(e.getMessage())) + ";");
                Toast.makeText(this, "Falha ao salvar backup", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_OPEN_BACKUP) {
            try {
                String payload = readText(uri);
                callJs("receiveBackupFileContents(" + JSONObject.quote(payload) + ");");
            } catch (Exception e) {
                callJs("document.getElementById('backupMsg').textContent='Falha ao ler o arquivo selecionado: ' + " + JSONObject.quote(String.valueOf(e.getMessage())) + ";");
            }
        }
    }

    private String readText(Uri uri) throws Exception {
        StringBuilder result = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        return result.toString();
    }

    private void callJs(String script) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
