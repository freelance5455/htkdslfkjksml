package br.com.controleentregas.app;

import android.app.*;
import android.content.*;
import android.os.*;
import androidx.annotation.Nullable;

public class GpsForegroundService extends Service {
  private static final String CHANNEL="gps_tracking";
  @Override public void onCreate(){super.onCreate(); if(Build.VERSION.SDK_INT>=26){
    NotificationChannel c=new NotificationChannel(CHANNEL,"Rastreamento GPS",NotificationManager.IMPORTANCE_LOW);
    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
  }}
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    Notification n=new Notification.Builder(this,CHANNEL)
      .setContentTitle("Controle de Entregas")
      .setContentText("Rastreamento de percurso em andamento")
      .setSmallIcon(android.R.drawable.ic_menu_mylocation)
      .setOngoing(true).build();
    startForeground(321,n);
    if(intent!=null && "STOP".equals(intent.getAction())){stopForeground(true);stopSelf();return START_NOT_STICKY;}
    return START_STICKY;
  }
  @Nullable @Override public android.os.IBinder onBind(Intent i){return null;}
}
