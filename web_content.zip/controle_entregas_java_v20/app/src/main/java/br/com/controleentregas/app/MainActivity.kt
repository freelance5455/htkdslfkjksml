package br.com.controleentregas.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle\nimport android.Manifest\nimport android.content.pm.PackageManager\nimport android.os.Build\nimport android.provider.Settings
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.*

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pendingBackupPayload: String? = null
    private val saveRequest = 5101
    private val openRequest = 5102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(16,20,29))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            setSupportZoom(false)
        }
        webView.addJavascriptInterface(BackupBridge(), "AndroidBackupBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?) =
                request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            override fun shouldInterceptRequest(view: WebView?, url: String?) =
                url?.let { assetLoader.shouldInterceptRequest(Uri.parse(it)) }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                styledDialog(message ?: "", false) { result.confirm() }.also { d ->
                    d.setOnCancelListener { result.cancel() }
                    d.show()
                }
                return true
            }
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                styledDialog(message ?: "", true, { result.confirm() }, { result.cancel() }).also { d ->
                    d.setOnCancelListener { result.cancel() }
                    d.show()
                }
                return true
            }
            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity).apply {
                    setSingleLine(true); setText(defaultValue ?: "")
                    setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
                    setPadding(28, 22, 28, 22)
                    background = rounded(Color.rgb(28,37,51), 22)
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                }
                val d = AlertDialog.Builder(this@MainActivity)
                    .setTitle("Controle de Entregas").setMessage(message)
                    .setView(input)
                    .setNegativeButton("CANCELAR") { _, _ -> result.cancel() }
                    .setPositiveButton("CONFIRMAR") { _, _ -> result.confirm(input.text.toString()) }
                    .create()
                d.setOnShowListener { styleDialogButtons(d) }
                d.show()
                return true
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun styledDialog(message: String, confirm: Boolean,
                             yes: (() -> Unit)? = null, no: (() -> Unit)? = null): AlertDialog {
        val d = AlertDialog.Builder(this)
            .setTitle("Controle de Entregas")
            .setMessage(message)
            .setPositiveButton(if (confirm) "CONFIRMAR" else "ENTENDI") { _, _ -> yes?.invoke() }
            .apply { if (confirm) setNegativeButton("CANCELAR") { _, _ -> no?.invoke() } }
            .create()
        d.setOnShowListener { styleDialogButtons(d) }
        return d
    }

    private fun styleDialogButtons(d: AlertDialog) {
        d.window?.setBackgroundDrawable(rounded(Color.rgb(26,34,48), 28))
        d.findViewById<TextView>(android.R.id.alertTitle)?.setTextColor(Color.WHITE)
        d.findViewById<TextView>(android.R.id.message)?.setTextColor(Color.rgb(220,226,236))
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
            setTextColor(Color.rgb(101,214,162)); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        }
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            setTextColor(Color.rgb(169,180,197)); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        }
    }

    inner class BackupBridge {
        @JavascriptInterface fun requestLocationPermissions() {
            runOnUiThread {
                val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!fine && !coarse) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 7301)
                else if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    AlertDialog.Builder(this@MainActivity).setTitle("Permitir localização o tempo todo")
                        .setMessage("Para manter o traçado com o app minimizado, toque em Continuar e escolha “Permitir o tempo todo” nas permissões de localização.")
                        .setPositiveButton("CONTINUAR") { _, _ ->
                            if (Build.VERSION.SDK_INT >= 30) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
                            else requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 7302)
                        }.setNegativeButton("AGORA NÃO", null).create().also { d -> d.setOnShowListener { styleDialogButtons(d) }; d.show() }
                }
            }
        }
        @JavascriptInterface fun startGpsService() {
            val i = Intent(this@MainActivity, GpsForegroundService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        @JavascriptInterface fun stopGpsService() {
            val i = Intent(this@MainActivity, GpsForegroundService::class.java).setAction("STOP")
            startService(i)
        }
        @JavascriptInterface fun saveBackupFile(payload: String, filename: String?) {
            runOnUiThread {
                pendingBackupPayload = payload
                val name = (filename ?: "backup-controle-entregas.json").replace(Regex("[^a-zA-Z0-9._-]"), "-")
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, if (name.endsWith(".json")) name else "$name.json")
                startActivityForResult(intent, saveRequest)
            }
        }
        @JavascriptInterface fun saveLocalBackup(payload: String, kind: String, timestamp: String) {
            try {
                val dir = File(filesDir, "backups").apply { mkdirs() }
                File(dir, "backup-${timestamp.replace(Regex("[^0-9]"), "")}.json").writeText(payload)
                dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(3)?.forEach { it.delete() }
            } catch (_: Exception) {}
        }
        @JavascriptInterface fun pickBackupFile() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                startActivityForResult(i, openRequest)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode == saveRequest && resultCode == RESULT_OK) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write((pendingBackupPayload ?: "").toByteArray(Charsets.UTF_8)) }
                pendingBackupPayload = null
                callJs("document.getElementById('backupMsg').textContent='Arquivo JSON salvo com sucesso.';")
            } catch (_: Exception) {}
        } else if (requestCode == openRequest && resultCode == RESULT_OK) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                callJs("receiveBackupFileContents(${JSONObject.quote(text)});")
            } catch (_: Exception) {}
        }
    }
    private fun callJs(script: String) { runOnUiThread { webView.evaluateJavascript(script, null) } }
    override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}
