i-Roso Android WebView Project
=============================

This project packages the supplied i-Roso HTML app as an Android application.

The HTML is stored at:
app/src/main/assets/index.html

BUILD WITH ANDROIDIDE
---------------------
1. Open this folder in AndroidIDE.
2. Let Gradle sync/download dependencies.
3. Use the Build menu and choose "Assemble Debug" (or the equivalent APK build action).
4. The APK will be generated under:
   app/build/outputs/apk/debug/

The app works offline because index.html is bundled inside the APK.
User data is stored by the HTML app in WebView localStorage.

IMPORTANT
---------
This is a WebView wrapper around the supplied HTML. It does not create a cloud database
or online synchronization. Data remains local to each device.
