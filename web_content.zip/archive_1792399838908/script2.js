
/* =========================================================
   FASOTOK 🇧🇫 — SCRIPT PRINCIPAL
   Navigation, assistant, langue, authentification,
   publication et chargement des vidéos
   ========================================================= */

// --- 1. CONFIGURATION SUPABASE ---
const SUPABASE_URL = "https://vloshskfgaqcdxaktdvy.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_I5sAXEonuAJ2TvRNuvUNPA_o5wIONOm";

if (!window.supabase) {
  console.error("FasoTok : la bibliothèque Supabase est introuvable.");
} else {
  window.supabaseClient = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
    {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    }
  );
}

const supabaseClient = window.supabaseClient;


// --- 2. NAVIGATION, ASSISTANT ET PARAMÈTRES ---
document.addEventListener("DOMContentLoaded", () => {
  const navButtons = document.querySelectorAll(".nav-item[data-page]");
  const pageSections = document.querySelectorAll(".page-section");
  const openSettingsBtn = document.getElementById("open-settings-btn");
  const backHomeBtn = document.getElementById("back-home-btn");

  function switchPage(pageId) {
    pageSections.forEach(section => {
      section.hidden = true;
    });

    const targetPage = document.getElementById(`${pageId}-page`);

    if (targetPage) {
      targetPage.hidden = false;
    }

    navButtons.forEach(btn => {
      btn.classList.toggle(
        "active-nav",
        btn.getAttribute("data-page") === pageId
      );
    });
  }

  navButtons.forEach(button => {
    button.addEventListener("click", () => {
      switchPage(button.getAttribute("data-page"));
    });
  });

  if (openSettingsBtn) {
    openSettingsBtn.addEventListener("click", () => {
      switchPage("parametres");
    });
  }

  if (backHomeBtn) {
    backHomeBtn.addEventListener("click", () => {
      switchPage("home");
    });
  }

  // Assistant IA : simulation conservée
  const assistantForm = document.getElementById("assistant-form");
  const assistantQuestion = document.getElementById("assistant-question");
  const assistantReponses = document.getElementById("assistant-reponses");

  if (assistantForm && assistantQuestion && assistantReponses) {
    assistantForm.addEventListener("submit", event => {
      event.preventDefault();

      const question = assistantQuestion.value.trim();
      if (!question) return;

      const message = document.createElement("p");
      message.textContent = "Moi : " + question;
      assistantReponses.appendChild(message);

      const reponse = document.createElement("p");
      reponse.textContent = "🤖 L'assistant réfléchit...";
      assistantReponses.appendChild(reponse);

      assistantQuestion.value = "";

      setTimeout(() => {
        reponse.textContent =
          "🤖 L'assistant est en mode démonstration. " +
          "Une connexion à un service d'intelligence artificielle " +
          "sera nécessaire pour obtenir de vraies réponses.";
      }, 1500);
    });
  }

  // Sélection de la langue
  const langueSelect = document.getElementById("fasotok-langue");
  const langueMessage = document.getElementById("langue-message");

  if (langueSelect) {
    langueSelect.addEventListener("change", event => {
      const option = event.target.options[event.target.selectedIndex];

      if (langueMessage && option) {
        langueMessage.textContent =
          "Langue sélectionnée : " + option.text;
      }
    });
  }
});


// --- 3. AUTHENTIFICATION ET RESTAURATION DE SESSION ---
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const authOverlay = document.getElementById("auth-overlay");
  const deconnexionBtn = document.getElementById("deconnexion-fasotok");

  if (!supabaseClient) {
    alert("Erreur : Supabase n'est pas initialisé.");
    return;
  }

  function afficherUtilisateur(user) {
    if (!user) return;

    const username = user.user_metadata?.username || "Utilisateur";

    document.querySelectorAll(
      ".profile-username, .profile-header h2"
    ).forEach(element => {
      element.textContent = "@" + username;
    });

    if (authOverlay) {
      authOverlay.style.display = "none";
    }
  }

  // Restaurer la session existante
  (async () => {
    try {
      const { data, error } = await supabaseClient.auth.getSession();

      if (error) throw error;

      if (data.session?.user) {
        afficherUtilisateur(data.session.user);
      }
    } catch (error) {
      console.error("Erreur de restauration de session :", error.message);
    }
  })();

  // INSCRIPTION
  if (registerForm) {
    registerForm.addEventListener("submit", async event => {
      event.preventDefault();

      const username =
        document.getElementById("register-username").value.trim();

      const codeSecret =
        document.getElementById("register-password").value;

      const confirmation =
        document.getElementById("register-confirm-password").value;

      if (!/^[a-zA-Z0-9._-]{3,30}$/.test(username)) {
        alert("Choisis un pseudo de 3 à 30 caractères : lettres, chiffres, point, tiret ou soulignement.");
        return;
      }

      if (codeSecret !== confirmation) {
        alert("Les codes secrets ne correspondent pas.");
        return;
      }

      if (codeSecret.length < 6) {
        alert("Choisis un code secret d'au moins 6 caractères.");
        return;
      }

      const fauxEmail = username.toLowerCase() + "@fasotok.bf";

      try {
        const { data, error } = await supabaseClient.auth.signUp({
          email: fauxEmail,
          password: codeSecret,
          options: {
            data: { username: username }
          }
        });

        if (error) throw error;

        if (data.session?.user) {
          afficherUtilisateur(data.session.user);
          alert("Compte créé avec succès ! Bienvenue sur FasoTok 🇧🇫");
        } else {
          alert(
            "Inscription reçue. Vérifie la configuration de confirmation " +
            "des inscriptions dans Supabase avant de te connecter."
          );
        }
      } catch (error) {
        console.error("Erreur d'inscription :", error);
        alert("Échec de l'inscription : " + error.message);
      }
    });
  }

  // CONNEXION : même domaine que lors de l'inscription
  if (loginForm) {
    loginForm.addEventListener("submit", async event => {
      event.preventDefault();

      const username =
        document.getElementById("login-username").value.trim();

      const codeSecret =
        document.getElementById("login-password").value;

      if (!username || !codeSecret) {
        alert("Entre ton pseudo et ton code secret.");
        return;
      }

      const fauxEmail = username.toLowerCase() + "@fasotok.bf";

      try {
        const { data, error } =
          await supabaseClient.auth.signInWithPassword({
            email: fauxEmail,
            password: codeSecret
          });

        if (error) throw error;

        afficherUtilisateur(data.user);

        alert("Content de te revoir, @" + username + " !");
      } catch (error) {
        console.error("Erreur de connexion :", error);
        alert("Connexion impossible : " + error.message);
      }
    });
  }

  // DÉCONNEXION réelle
  if (deconnexionBtn) {
    deconnexionBtn.addEventListener("click", async () => {
      try {
        const { error } = await supabaseClient.auth.signOut();

        if (error) throw error;

        if (authOverlay) {
          authOverlay.style.display = "flex";
        }

        alert("Tu es déconnecté de FasoTok.");
      } catch (error) {
        console.error("Erreur de déconnexion :", error);
        alert("Échec de déconnexion : " + error.message);
      }
    });
  }
});


// --- 4. PUBLICATION DE VIDÉOS ---
document.addEventListener("DOMContentLoaded", () => {
  const boutonPublier = document.getElementById("publish-btn");
  const selecteur = document.getElementById("fasotok-selecteur");

  if (!boutonPublier || !selecteur) {
    console.error("FasoTok : bouton Publier ou sélecteur introuvable.");
    return;
  }

  boutonPublier.addEventListener("click", () => {
    selecteur.click();
  });

  selecteur.addEventListener("change", async () => {
    const fichier = selecteur.files?.[0];

    if (!fichier) return;

    if (!fichier.type.startsWith("video/")) {
      alert("Choisis un fichier vidéo pour continuer.");
      selecteur.value = "";
      return;
    }

    if (!supabaseClient) {
      alert("Supabase n'est pas initialisé.");
      return;
    }

    let cheminFichier = null;
    let fichierEnvoye = false;

    try {
      boutonPublier.disabled = true;
      boutonPublier.textContent = "Publication en cours...";

      // Vérifier la session réelle
      const { data: sessionData, error: sessionError } =
        await supabaseClient.auth.getSession();

      if (sessionError) throw sessionError;

      const utilisateur = sessionData.session?.user;

      if (!utilisateur) {
        throw new Error(
          "Aucune session Supabase active. Connecte-toi avant de publier."
        );
      }

      console.log("Publication par l'utilisateur :", utilisateur.id);

      // Nom de fichier unique dans le dossier de l'utilisateur
      const extension = fichier.name.includes(".")
        ? fichier.name.split(".").pop().toLowerCase()
        : "mp4";

      cheminFichier =
        utilisateur.id + "/" + Date.now() + "." + extension;

      // ENVOI DU FICHIER DANS STORAGE
      const { data: uploadData, error: uploadError } =
        await supabaseClient.storage
          .from("videos")
          .upload(cheminFichier, fichier, {
            contentType: fichier.type || "video/mp4",
            upsert: false
          });

      if (uploadError) {
        console.error("Erreur Storage :", uploadError);
        throw new Error("ÉCHEC STORAGE : " + uploadError.message);
      }

      fichierEnvoye = true;

      // Récupérer l'URL publique du fichier
      const { data: urlData } = supabaseClient.storage
        .from("videos")
        .getPublicUrl(uploadData.path);

      const urlVideo = urlData.publicUrl;

      if (!urlVideo) {
        throw new Error("Impossible de récupérer l'adresse de la vidéo.");
      }

      const username =
        utilisateur.user_metadata?.username || "Utilisateur";

      // ENREGISTRER LES INFORMATIONS DANS LA TABLE videos
      const { error: insertionError } = await supabaseClient
        .from("videos")
        .insert({
          user_id: utilisateur.id,
          username: username,
          video_url: urlVideo,
          caption: ""
        });

      if (insertionError) {
        console.error("Erreur table videos :", insertionError);

        // Nettoyage du fichier si l'insertion échoue
        const { error: nettoyageError } = await supabaseClient.storage
          .from("videos")
          .remove([cheminFichier]);

        if (nettoyageError) {
          console.error("Erreur de nettoyage Storage :", nettoyageError);
        }

        fichierEnvoye = false;

        throw new Error(
          "ÉCHEC TABLE VIDEOS : " + insertionError.message
        );
      }

      
      // AFFICHER LA VIDÉO PUBLIÉE DANS LE FIL FASOTOK
      const fil = document.getElementById("video-feed");

      if (fil) {
        const carte = document.createElement("div");
        carte.className = "video-card";

        const video = document.createElement("video");
        video.src = urlVideo;
        video.autoplay = true;
        video.muted = true;
        video.loop = true;
        video.playsInline = true;
        video.preload = "metadata";

        const pied = document.createElement("div");
        pied.className = "video-footer";

        const pseudo = document.createElement("h3");
        pseudo.textContent = "@" + username;

        const description = document.createElement("p");
        description.textContent = "";

        pied.appendChild(pseudo);
        pied.appendChild(description);

        carte.appendChild(video);
        carte.appendChild(pied);

        fil.prepend(carte);

        video.play().catch(() => {
          console.log("La lecture démarrera après une action.");
        });
      }


      alert("Vidéo publiée avec succès sur FasoTok ! 🇧🇫");

    } catch (error) {
      console.error("Erreur de publication FasoTok :", error);

      alert(
        "Échec de publication : " +
        (error.message || "Erreur inconnue")
      );
    } finally {
      boutonPublier.disabled = false;
      boutonPublier.textContent = "Publier";
      selecteur.value = "";
    }
  });
});
// --- 5. RECHARGER LES VIDÉOS DEPUIS SUPABASE ---
document.addEventListener("DOMContentLoaded", async () => {
  const fil = document.getElementById("video-feed");

  if (!fil || !supabaseClient) return;

  try {
    const { data: videos, error } = await supabaseClient
      .from("videos")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) throw error;

    fil.innerHTML = "";

    videos.forEach(item => {
      const carte = document.createElement("div");
      carte.className = "video-card";

      const video = document.createElement("video");
      video.src = item.video_url;
      video.autoplay = true;
      video.muted = true;
      video.loop = true;
      video.playsInline = true;
      video.preload = "metadata";

      const pied = document.createElement("div");
      pied.className = "video-footer";

      const pseudo = document.createElement("h3");
      pseudo.textContent = "@" + (item.username || "Utilisateur");

      const description = document.createElement("p");
      description.textContent = item.caption || "";

      pied.appendChild(pseudo);
      pied.appendChild(description);
      carte.appendChild(video);
      carte.appendChild(pied);
      fil.appendChild(carte);
    });

    console.log("FasoTok : vidéos rechargées :", videos.length);
  } catch (error) {
    console.error("Erreur de chargement des vidéos :", error);
  }
});