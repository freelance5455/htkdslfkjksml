import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(client), model: process.env.OPENAI_MODEL || "gpt-4.1-mini" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({
        error: "AI zatím není připojená. Vytvoř soubor .env podle .env.example a vlož do něj svůj OPENAI_API_KEY."
      });
    }

    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map(m => ({ role: m.role, content: m.content.slice(0, 8000) }));

    if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
      return res.status(400).json({ error: "Pošli zprávu, na kterou mám odpovědět." });
    }

    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      messages: [
        {
          role: "system",
          content: "Jsi Jáchym Ai, přátelský, užitečný AI asistent. Odpovídej česky, pokud uživatel nepíše jiným jazykem. Buď přesný, přiznej nejistotu a nikdy netvrď, že máš aktuální informace z internetu, pokud je nemáš."
        },
        ...safeMessages
      ],
      temperature: 0.7
    });

    res.json({ reply: response.choices?.[0]?.message?.content || "Promiň, nepodařilo se mi vytvořit odpověď." });
  } catch (err) {
    console.error("Chat API error:", err?.message || err);
    res.status(500).json({ error: "Odpověď se nepodařilo získat. Zkontroluj API klíč a nastavení modelu." });
  }
});

// Demo premium endpoint. Real billing needs Stripe Checkout + verified webhooks.
// Do not mark users as paid based only on browser-side state.
app.post("/api/premium/checkout", (_req, res) => {
  res.status(501).json({
    error: "Platby zatím nejsou zapnuté. Pro skutečné předplatné nastav Stripe Checkout, cenu a ověřování webhooků na serveru.",
    price: "49.99",
    currency: "USD"
  });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => {
  console.log(`Jáchym Ai běží na http://localhost:${port}`);
});
