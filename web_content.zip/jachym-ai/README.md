# Jáchym Ai

Responsive AI chat web app with a PWA install experience, chat history, daily Jáchym Streak, loading screen, and a Premium page.

## What works now
- Real AI responses through the OpenAI API (server-side key only).
- Responsive UI for desktop and mobile.
- Installable PWA on supported browsers, with app icon and standalone display.
- Chat history stored locally in the current browser.
- Daily streak tracked locally on this device.
- Premium offer UI at **$49.99/month**.

## Important before launch
- The Premium checkout is deliberately disabled until a payment provider is configured. Do not charge users based only on a client-side flag.
- `Powered by OpenAI` is used on the loading screen. Only change this to “Powered by ChatGPT” if your actual integration and branding use meet OpenAI's current requirements.
- This project is a PWA (installable web app), not yet a native App Store / Google Play package.
- Chat history is local to this browser/device; it is not synced across devices.
- Never expose `OPENAI_API_KEY` in `public/` or commit `.env`.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Add your API key to `.env`:
   `OPENAI_API_KEY=...`
4. In this folder, run:
   ```bash
   npm install
   npm start
   ```
5. Open `http://localhost:3000`.

The chat requires an active OpenAI API account and API billing. The model can be changed with `OPENAI_MODEL`.

## Make it available online
Deploy the Node app to a Node-compatible host. Set `OPENAI_API_KEY`, `OPENAI_MODEL`, and `PORT` as environment variables in the host dashboard. Use HTTPS for PWA installation and production use.

## Add real Premium payments
Implement Stripe Checkout on the server, create a $49.99 recurring USD price, verify Stripe webhooks, and tie the subscription to authenticated user accounts before enabling paid features. The current `/api/premium/checkout` endpoint intentionally returns a “not configured” response.

## Next production steps
- Add authentication and server-side chat storage if history should sync between devices.
- Add rate limiting, usage limits, logging/monitoring, abuse protection, and a privacy policy.
- Review OpenAI's current API docs and branding guidelines before publishing.
