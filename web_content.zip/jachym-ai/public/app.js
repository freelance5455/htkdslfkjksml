const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "jachym-ai-state-v1";
const defaultState = { chats: [], activeChatId: null, streak: { count: 0, lastDate: null, days: [] } };
let state = loadState();
let isSending = false;
let deferredInstallPrompt = null;
let toastTimer;

function loadState() {
  try { return { ...defaultState, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") }; }
  catch { return structuredClone(defaultState); }
}
function saveState() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function id() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`; }
function dateKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
}
function dayDiff(a,b) {
  const [ay,am,ad]=a.split("-").map(Number), [by,bm,bd]=b.split("-").map(Number);
  return Math.round((Date.UTC(by,bm-1,bd)-Date.UTC(ay,am-1,ad))/86400000);
}
function recordVisit() {
  const today = dateKey(), streak = state.streak || (state.streak = {count:0,lastDate:null,days:[]});
  if (streak.lastDate !== today) {
    if (!streak.lastDate) streak.count = 1;
    else if (dayDiff(streak.lastDate,today) === 1) streak.count = (streak.count || 0) + 1;
    else streak.count = 1;
    streak.lastDate = today;
    streak.days = [...new Set([...(streak.days || []),today])].slice(-90);
    saveState();
  }
  renderStreak();
}
function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 3500);
}
function newChat() {
  const chat = { id: id(), title: "Nový chat", messages: [], updatedAt: Date.now() };
  state.chats.unshift(chat); state.activeChatId = chat.id; saveState();
  renderAll(); showView("chat-view"); $("prompt").focus();
}
function activeChat() { return state.chats.find(c => c.id === state.activeChatId); }
function ensureChat() { if (!activeChat()) newChat(); return activeChat(); }
function renderHistory() {
  const root = $("history-list"); root.innerHTML = "";
  if (!state.chats.length) {
    const empty = document.createElement("div"); empty.className = "side-foot"; empty.textContent = "Zatím tu nejsou žádné chaty."; root.append(empty); return;
  }
  state.chats.forEach(chat => {
    const b = document.createElement("button"); b.className = "history-item" + (chat.id === state.activeChatId ? " active" : "");
    const icon = document.createElement("span"); icon.textContent = "◌";
    const title = document.createElement("span"); title.textContent = chat.title || "Nový chat";
    b.append(icon,title); b.title = title.textContent;
    b.addEventListener("click", () => { state.activeChatId = chat.id; saveState(); renderAll(); showView("chat-view"); closeSidebar(); });
    root.append(b);
  });
}
function addMessage(role, content, options={}) {
  const node = document.createElement("article"); node.className = `message ${role}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "user" ? "J" : "♛";
  const bubble = document.createElement("div"); bubble.className = "bubble";
  if (options.typing) { bubble.classList.add("typing"); bubble.textContent = "Jáchym Ai přemýšlí"; node.dataset.typing = "true"; }
  else bubble.textContent = content;
  node.append(avatar,bubble); $("messages").append(node); return node;
}
function renderMessages() {
  const chat = activeChat(), messages = chat?.messages || [];
  $("messages").innerHTML = "";
  const hasMessages = messages.length > 0;
  $("welcome").classList.toggle("hidden", hasMessages);
  $("messages").classList.toggle("hidden", !hasMessages);
  messages.forEach(m => addMessage(m.role, m.content));
  $("messages").scrollTop = $("messages").scrollHeight;
}
function renderAll() { renderHistory(); renderMessages(); renderStreak(); }
function renderStreak() {
  const s = state.streak || {count:0,lastDate:null,days:[]};
  $("streak-side").textContent = `${s.count || 0} ${s.count === 1 ? "den" : "dní"} v řadě`;
  $("streak-count").textContent = s.count || 0;
  const root = $("week-days"); root.innerHTML = "";
  const names = ["Po","Út","St","Čt","Pá","So","Ne"], today = new Date();
  const mondayOffset = (today.getDay()+6)%7;
  const monday = new Date(today); monday.setDate(today.getDate()-mondayOffset);
  for(let i=0;i<7;i++){
    const d = new Date(monday); d.setDate(monday.getDate()+i); const key=dateKey(d);
    const item=document.createElement("div"); item.className="day"+((s.days||[]).includes(key)?" done":"")+(key===dateKey()?" today":"");
    const label=document.createElement("span"); label.textContent=names[i];
    const dot=document.createElement("span"); dot.className="dot"; dot.textContent=(s.days||[]).includes(key)?"✓":String(d.getDate());
    item.append(label,dot); root.append(item);
  }
}
function showView(viewId) {
  document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===viewId));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===viewId));
  if(viewId==="chat-view") $("prompt").focus({preventScroll:true});
}
async function checkHealth() {
  try {
    const r=await fetch("/api/health"); const data=await r.json();
    $("api-status").className="status"+(data.configured?" ready":" error");
    $("api-status").textContent=data.configured?`AI připojena · ${data.model}`:"AI není nastavená";
  } catch {
    $("api-status").className="status error"; $("api-status").textContent="Server není dostupný";
  }
}
async function sendMessage(text) {
  const content=text.trim(); if(!content || isSending) return;
  const chat=ensureChat();
  chat.messages.push({role:"user",content});
  if(chat.messages.length===1) chat.title=content.slice(0,42)+(content.length>42?"…":"");
  chat.updatedAt=Date.now(); state.chats.sort((a,b)=>b.updatedAt-a.updatedAt);
  recordVisit(); saveState(); renderAll(); showView("chat-view");
  const input=$("prompt"); input.value=""; input.style.height="auto";
  const send=$("send-button"); send.disabled=true; isSending=true;
  const typing=addMessage("assistant","",{typing:true}); $("messages").classList.remove("hidden"); $("welcome").classList.add("hidden");
  $("messages").scrollTop=$("messages").scrollHeight;
  try {
    const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:chat.messages})});
    const data=await response.json();
    if(!response.ok) throw new Error(data.error || "Požadavek se nezdařil.");
    typing.remove(); chat.messages.push({role:"assistant",content:data.reply}); chat.updatedAt=Date.now(); saveState();
    addMessage("assistant",data.reply); $("messages").scrollTop=$("messages").scrollHeight; renderHistory();
  } catch(err) {
    typing.remove();
    const message=err.message || "Něco se pokazilo.";
    addMessage("assistant",`Promiň, teď se mi nepodařilo odpovědět.\n\n${message}`);
    toast(message);
  } finally { isSending=false; send.disabled=false; input.focus(); }
}
function closeSidebar() { document.querySelector(".sidebar").classList.remove("open"); }

$("chat-form").addEventListener("submit",e=>{e.preventDefault();sendMessage($("prompt").value);});
$("prompt").addEventListener("input",e=>{e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,180)+"px";});
$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("chat-form").requestSubmit();}});
$("new-chat").addEventListener("click",()=>{newChat();closeSidebar();});
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("streak-nav").addEventListener("click",()=>{showView("streak-view");closeSidebar();});
$("premium-nav").addEventListener("click",()=>{showView("premium-view");closeSidebar();});
$("menu-toggle").addEventListener("click",()=>document.querySelector(".sidebar").classList.toggle("open"));
$("premium-buy").addEventListener("click",async()=>{
  try {
    const r=await fetch("/api/premium/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
    const data=await r.json(); toast(data.error || "Platby zatím nejsou aktivní.");
  } catch { toast("Platební služba není dostupná."); }
});
$("clear-history").addEventListener("click",()=>{
  if(!confirm("Opravdu chceš smazat všechny chaty uložené v tomto prohlížeči?")) return;
  state.chats=[];state.activeChatId=null;saveState();renderAll();toast("Historie byla smazána.");
});
$("install-settings").addEventListener("click",installApp);
$("install-button").addEventListener("click",installApp);
async function installApp() {
  if(deferredInstallPrompt){deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$("install-button").classList.add("hidden");}
  else toast("V prohlížeči otevři menu a zvol „Přidat na plochu“ nebo „Instalovat aplikaci“.");
}
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstallPrompt=e;$("install-button").classList.remove("hidden");});
window.addEventListener("appinstalled",()=>toast("Jáchym Ai je nainstalovaný!"));
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
if(!state.chats.length) { const c={id:id(),title:"Nový chat",messages:[],updatedAt:Date.now()};state.chats.push(c);state.activeChatId=c.id;saveState(); }
renderAll();checkHealth();
setTimeout(()=>$("splash").classList.add("done"),1100);
