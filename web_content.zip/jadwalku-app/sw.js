// Jadwalku service worker: works offline from a versioned cache of the app files.
const VERSION = 'jadwalku-99f7211a9cfd';
const CORE = ["./","index.html","app.js","manifest.webmanifest","vendor/react.production.min.js","vendor/react-dom.production.min.js","fonts/fonts.css","fonts/bricolage-grotesque-latin-ext-opsz-normal.woff2","fonts/bricolage-grotesque-latin-opsz-normal.woff2","fonts/plus-jakarta-sans-latin-ext-wght-normal.woff2","fonts/plus-jakarta-sans-latin-wght-normal.woff2","icons/apple-touch-icon.png","icons/favicon-64.png","icons/icon-192.png","icons/icon-512.png","icons/maskable-512.png"];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('jadwalku-') && k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    e.respondWith(caches.match('index.html').then((hit) => hit || fetch(req)));
    return;
  }
  e.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => hit || fetch(req)));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const key = e.notification.data && e.notification.data.key;
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    for (const c of list) { if (key) c.postMessage({ type: 'open-event', key }); return c.focus(); }
    return self.clients.openWindow('./');
  }));
});
