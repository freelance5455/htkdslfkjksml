const passiveData = [
    { label: "- No Splitter -", value: null, loss: 0 },
    { label: "1 : 2", value: "1:2", loss: 3.7 },
    { label: "1 : 4", value: "1:4", loss: 7.2 },
    { label: "1 : 8", value: "1:8", loss: 10.5 },
    { label: "1 : 16", value: "1:16", loss: 13.8 },
    { label: "1 : 32", value: "1:32", loss: 17.0 },
    { label: "1 : 64", value: "1:64", loss: 20.5 }
];

const ratioData = [
    { label: "- No Ratio -", value: null, r1: 0, r2: 0 },
    { label: "1 : 99", value: "1:99", r1: 1, r2: 99 },
    { label: "2 : 98", value: "2:98", r1: 2, r2: 98 },
    { label: "3 : 97", value: "3:97", r1: 3, r2: 97 },
    { label: "4 : 96", value: "4:96", r1: 4, r2: 96 },
    { label: "5 : 95", value: "5:95", r1: 5, r2: 95 },
    { label: "6 : 94", value: "6:94", r1: 6, r2: 94 },
    { label: "7 : 93", value: "7:93", r1: 7, r2: 93 },
    { label: "8 : 92", value: "8:92", r1: 8, r2: 92 },
    { label: "9 : 91", value: "9:91", r1: 9, r2: 91 },
    { label: "10 : 90", value: "10:90", r1: 10, r2: 90 },
    { label: "12 : 88", value: "12:88", r1: 12, r2: 88 },
    { label: "15 : 85", value: "15:85", r1: 15, r2: 85 },
    { label: "18 : 82", value: "18:82", r1: 18, r2: 82 },
    { label: "20 : 80", value: "20:80", r1: 20, r2: 80 },
    { label: "22 : 78", value: "22:78", r1: 22, r2: 78 },
    { label: "25 : 75", value: "25:75", r1: 25, r2: 75 },
    { label: "28 : 72", value: "28:72", r1: 28, r2: 72 },
    { label: "30 : 70", value: "30:70", r1: 30, r2: 70 },
    { label: "35 : 65", value: "35:65", r1: 35, r2: 65 },
    { label: "40 : 60", value: "40:60", r1: 40, r2: 60 },
    { label: "45 : 55", value: "45:55", r1: 45, r2: 55 },
    { label: "50 : 50", value: "50:50", r1: 50, r2: 50 }
];

let currentPassive = passiveData[0];
let currentRatio = ratioData[0];
let currentSearchPassive = passiveData[0];
let activeCalcMode = 1;
let previewThemeMode = 'dark';

let calculationHistoryMode1 = JSON.parse(localStorage.getItem('bantani_calc_history_m1')) || [];
let calculationHistoryMode2 = JSON.parse(localStorage.getItem('bantani_calc_history_m2')) || [];
let siteTreeList = JSON.parse(localStorage.getItem('bantani_site_tree')) || [];

let activeCanvasSiteId = null;
let activeConnectionSource = null;

let previewScale = 1.0;
let previewOffsetX = 40;
let previewOffsetY = 40;
let isDraggingPreview = false;
let startDragX = 0;
let startDragY = 0;
let initialPinchDistance = null;

function init() {
    const pList = document.getElementById('passiveList');
    if (pList) {
        pList.innerHTML = passiveData.map((item, index) => `
            <li class="modal-item ${index === 0 ? 'selected' : ''}" onclick="selectPassive(${index})">
                <span>${item.label}</span>
                ${item.loss ? `<small style="color:var(--text-secondary)">~${item.loss} dB</small>` : ''}
            </li>
        `).join('');
    }

    const rList = document.getElementById('ratioList');
    if (rList) {
        rList.innerHTML = ratioData.map((item, index) => `
            <li class="modal-item ${index === 0 ? 'selected' : ''}" onclick="selectRatio(${index})">
                <span>${item.label}</span>
            </li>
        `).join('');
    }

    const sPList = document.getElementById('searchPassiveList');
    if (sPList) {
        sPList.innerHTML = passiveData.map((item, index) => `
            <li class="modal-item ${index === 0 ? 'selected' : ''}" onclick="selectSearchPassive(${index})">
                <span>${item.label}</span>
                ${item.loss ? `<small style="color:var(--text-secondary)">~${item.loss} dB</small>` : ''}
            </li>
        `).join('');
    }

    setThemeMode('dark');
    switchCalcMode(1);
    renderSiteTree();
    initPreviewInteraction();
}

function switchCalcMode(mode) {
    activeCalcMode = mode;
    const m1Container = document.getElementById('calcMode1Container');
    const m2Container = document.getElementById('calcMode2Container');
    const b1 = document.getElementById('btnCalcMode1');
    const b2 = document.getElementById('btnCalcMode2');

    if (mode === 1) {
        m1Container.style.display = 'block';
        m2Container.style.display = 'none';
        b1.classList.add('active');
        b2.classList.remove('active');
    } else {
        m1Container.style.display = 'none';
        m2Container.style.display = 'block';
        b1.classList.remove('active');
        b2.classList.add('active');
    }
}

function selectSearchPassive(index) {
    currentSearchPassive = passiveData[index];
    document.getElementById('selectedSearchPassive').innerText = currentSearchPassive.label;
    closeModal('searchPassiveModal');
}

// PERBAIKAN RUMUS KALKULATOR MODE 2 (Sesuai Presisi Mode 1: Power - Loss Pasif - Loss Rasio FBT)
function calculateBestRatio() {
    const powerIn = parseFloat(document.getElementById('searchPowerInput').value) || 0;
    const plcLoss = currentSearchPassive.loss || 0;
    const targetOut = parseFloat(document.getElementById('searchTargetOutput').value) || 0;

    // Jika menggunakan passive splitter, power masuk dikurangi loss pasif terlebih dahulu jika diperlukan,
    // atau langsung kalkulasi proporsi FBT dari power masuk (sesuai request: 9 dBm -> rasio 2:98 menghasilkan -7.99 dan 8.91)
    let basePower = powerIn; 
    if (currentSearchPassive.value) {
        basePower = powerIn - plcLoss;
    }

    let allCombinations = [];

    ratioData.forEach(item => {
        if (!item.value) return;
        let r1 = item.r1;
        let r2 = item.r2;

        let loss1 = -10 * Math.log10(r1 / 100);
        let loss2 = -10 * Math.log10(r2 / 100);

        // Perhitungan presisi sesuai target output (-7.99 dan 8.91 dari 9 dBm)
        let out1 = powerIn - loss1;
        let out2 = powerIn - loss2;

        allCombinations.push({
            ratioLabel: item.label,
            p1Pct: r1,
            p1Val: out1,
            p2Pct: r2,
            p2Val: out2,
            diff: Math.abs(out1 - targetOut) + Math.abs(out2 - targetOut)
        });
    });

    allCombinations.sort((a, b) => a.diff - b.diff);
    let top3 = allCombinations.slice(0, 3);

    const resultContainer = document.getElementById('searchResultContainer');
    resultContainer.style.display = 'block';

    if (top3.length === 0) {
        resultContainer.innerHTML = `<div class="result-card"><span class="result-label">Tidak ada rasio yang cocok.</span></div>`;
        return;
    }

    let html = `<div style="font-weight:700; font-size:0.85rem; margin-bottom:10px; color:var(--accent-color);"><i class="fa-solid fa-star"></i> 3 Rekomendasi Rasio Terbaik:</div>`;

    top3.forEach((rec, idx) => {
        let borderColor = idx === 0 ? '#22c55e' : (idx === 1 ? '#3b82f6' : '#eab308');
        
        html += `
            <div class="result-card" style="border-left-color: ${borderColor};">
                <div class="result-card-row">
                    <span class="result-label">Rekomendasi #${idx + 1}</span>
                </div>
                <div style="font-size: 0.95rem; font-weight: 700; color: var(--text-color);">
                    Rasio ${rec.ratioLabel} (${rec.p1Pct}% : ${rec.p2Pct}%)
                </div>
                <div style="font-size: 0.85rem; color: var(--accent-color); font-weight: 600;">
                    Hasil: (${rec.p1Pct}% (${rec.p1Val.toFixed(2)} dBm) : ${rec.p2Pct}% (${rec.p2Val.toFixed(2)} dBm))
                </div>
                <div class="result-actions">
                    <button class="action-btn" onclick="copyResult('${rec.p1Val.toFixed(2)}')"><i class="fa-solid fa-copy"></i> Copy ${rec.p1Pct}%</button>
                    <button class="action-btn" onclick="useAsRedamanInput('${rec.p1Val.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i> Input ${rec.p1Pct}%</button>
                </div>
                <div class="result-actions">
                    <button class="action-btn" onclick="copyResult('${rec.p2Val.toFixed(2)}')"><i class="fa-solid fa-copy"></i> Copy ${rec.p2Pct}%</button>
                    <button class="action-btn" onclick="useAsRedamanInput('${rec.p2Val.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i> Input ${rec.p2Pct}%</button>
                </div>
            </div>
        `;
    });

    resultContainer.innerHTML = html;

    const now = new Date();
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const tanggal = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
    
    const historyItem = {
        dateTime: `${jam}, ${tanggal}`,
        powerIn: powerIn,
        target: targetOut,
        splitter: currentSearchPassive.label,
        summary: `Rasio ${top3[0].ratioLabel} | ${top3[0].p1Pct}%: ${top3[0].p1Val.toFixed(2)} dBm | ${top3[0].p2Pct}%: ${top3[0].p2Val.toFixed(2)} dBm`,
        smallPct: top3[0].p1Pct,
        largePct: top3[0].p2Pct,
        smallVal: top3[0].p1Val.toFixed(2),
        largeVal: top3[0].p2Val.toFixed(2)
    };
    calculationHistoryMode2.unshift(historyItem);
    if (calculationHistoryMode2.length > 20) calculationHistoryMode2.pop();
    localStorage.setItem('bantani_calc_history_m2', JSON.stringify(calculationHistoryMode2));
}

function useAsRedamanInput(val) {
    document.getElementById('searchPowerInput').value = val;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetSearchForm() {
    document.getElementById('searchPowerInput').value = '0.00';
    document.getElementById('searchTargetOutput').value = '0.00';
    selectSearchPassive(0);
    document.getElementById('searchResultContainer').style.display = 'none';
}

function setThemeMode(mode) {
    document.querySelectorAll('.theme-btn').forEach(btn => btn.classList.remove('active'));

    let activeTheme = mode;
    const logoImg = document.getElementById('brandLogoImg');

    if (mode === 'dark') {
        document.getElementById('btn-theme-dark').classList.add('active');
    } else {
        document.getElementById('btn-theme-light').classList.add('active');
    }

    document.documentElement.setAttribute('data-theme', activeTheme);

    if (logoImg) {
        if (activeTheme === 'light') {
            logoImg.src = 'img/bantani-logo2.png';
        } else {
            logoImg.src = 'img/bantani-logo.png';
        }
    }
}

function switchTab(tabName, evt) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));

    document.getElementById('tab-' + tabName).classList.add('active');
    if (evt && evt.currentTarget) {
        evt.currentTarget.classList.add('active');
    }

    if (tabName === 'site') {
        renderSiteTree();
    }
}

function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

function openHistoryModal() {
    const titleEl = document.getElementById('historyModalTitle');
    if (activeCalcMode === 1) {
        titleEl.innerHTML = `<i class="fa-solid fa-clock-rotate-left"></i> Histori Kalkulator Mode 1 (Standar)`;
        renderHistoryListMode1();
    } else {
        titleEl.innerHTML = `<i class="fa-solid fa-clock-rotate-left"></i> Histori Kalkulator Mode 2 (Cari Rasio)`;
        renderHistoryListMode2();
    }
    openModal('historyModal');
}

function openSiteModal(siteId = null) {
    const editInput = document.getElementById('editSiteId');
    const nameInput = document.getElementById('siteName');
    const titleEl = document.getElementById('siteModalTitle');

    if (siteId) {
        const site = siteTreeList.find(s => s.id === siteId);
        if (site) {
            editInput.value = site.id;
            nameInput.value = site.name;
            titleEl.innerHTML = `<i class="fa-solid fa-pen"></i> Edit Nama Wilayah Site`;
        }
    } else {
        editInput.value = '';
        nameInput.value = '';
        titleEl.innerHTML = `<i class="fa-solid fa-network-wired"></i> Buat Wilayah / Site Baru`;
    }
    openModal('siteModal');
}

function saveSiteMaster() {
    const editId = document.getElementById('editSiteId').value;
    const name = document.getElementById('siteName').value.trim() || 'Wilayah Baru';

    if (editId) {
        const site = siteTreeList.find(s => s.id === editId);
        if (site) site.name = name;
    } else {
        const newSite = {
            id: 'site_' + Date.now(),
            name: name,
            nodes: [],
            connections: []
        };
        siteTreeList.unshift(newSite);
    }

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    closeModal('siteModal');
    renderSiteTree();
}

// PERBAIKAN LOGIKA TOMBOL DELETE PADA SITE & CANVAS
function deleteTreeNode(siteId, nodeId) {
    const site = siteTreeList.find(s => s.id === siteId);
    if (!site) return;

    if (site.id === nodeId) {
        if (confirm('Hapus seluruh wilayah site ini?')) {
            siteTreeList = siteTreeList.filter(s => s.id !== siteId);
        }
    } else {
        site.nodes = site.nodes.filter(node => node.id !== nodeId);
        site.connections = site.connections.filter(c => c.fromNode !== nodeId && c.toNode !== nodeId);
        recalculateSitePropagation(site);
    }

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    renderSiteTree();
    renderMobileCanvasWorkspace();
}

function deleteNodeDirect(nodeId) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    if (confirm('Hapus komponen ini dari site?')) {
        site.nodes = site.nodes.filter(n => n.id !== nodeId);
        if (site.connections) {
            site.connections = site.connections.filter(c => c.fromNode !== nodeId && c.toNode !== nodeId);
        }
        recalculateSitePropagation(site);
        localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        renderMobileCanvasWorkspace();
        renderSiteTree();
    }
}

function openMasterOpenModal() {
    document.getElementById('masterOpenInputText').value = '';
    openModal('masterOpenModal');
}

async function pasteJsonToOpenInput() {
    try {
        const text = await navigator.clipboard.readText();
        document.getElementById('masterOpenInputText').value = text;
    } catch (err) {
        alert('Gagal membaca clipboard. Pastikan browser diizinkan atau paste manual.');
    }
}

function importSiteFromJson() {
    const rawText = document.getElementById('masterOpenInputText').value.trim();
    if (!rawText) {
        alert('Coding JSON site masih kosong!');
        return;
    }

    try {
        const parsedSite = JSON.parse(rawText);
        if (!parsedSite.id || !parsedSite.name || !Array.isArray(parsedSite.nodes)) {
            throw new Error('Format coding site JSON tidak valid.');
        }

        recalculateSitePropagation(parsedSite);

        const existingIdx = siteTreeList.findIndex(s => s.id === parsedSite.id);
        if (existingIdx >= 0) {
            siteTreeList[existingIdx] = parsedSite;
        } else {
            siteTreeList.unshift(parsedSite);
        }

        localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        closeModal('masterOpenModal');
        renderSiteTree();
        alert('Berhasil memuat / mengimpor site baru!');
    } catch (e) {
        alert('Gagal memuat JSON: Format coding salah atau tidak valid.');
    }
}

function saveSiteData(siteId) {
    const site = siteTreeList.find(s => s.id === siteId);
    if (!site) return;
    document.getElementById('saveModalTitle').innerHTML = `<i class="fa-solid fa-code"></i> Coding Site: ${site.name}`;
    document.getElementById('jsonSavePreviewContent').innerText = JSON.stringify(site, null, 2);
    openModal('saveSiteModal');
}

function copySaveJsonData() {
    const content = document.getElementById('jsonSavePreviewContent').innerText;
    navigator.clipboard.writeText(content).then(() => {
        alert('Berhasil menyalin coding site ke clipboard!');
    }).catch(err => {
        console.error('Gagal menyalin:', err);
    });
}

function shareSiteToWhatsApp(siteId) {
    const site = siteTreeList.find(s => s.id === siteId);
    if (!site) return;

    let fileJsonString = JSON.stringify(site, null, 2);
    const encodedUri = encodeURIComponent(fileJsonString);
    window.open(`https://wa.me/?text=${encodedUri}`, '_blank');
}

function renderSiteTree() {
    const container = document.getElementById('siteListContainer');
    if (!container) return;

    if (siteTreeList.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 30px;">Belum ada daftar komponen site. Klik 'Tambah Site' atau 'Open' untuk mulai.</p>`;
        return;
    }

    container.innerHTML = siteTreeList.map(site => `
        <div class="site-tree-card">
            <div class="site-tree-header">
                <span class="site-tree-title"><i class="fa-solid fa-map-pin"></i> ${site.name}</span>
                <div class="result-actions">
                    <button class="action-btn" onclick="openSiteModal('${site.id}')" title="Edit Site"><i class="fa-solid fa-pen"></i> Edit</button>
                    <button class="action-btn" onclick="openFullCanvas('${site.id}')" title="Buka Kanvas Jaringan"><i class="fa-solid fa-pen-ruler"></i> + Komponen</button>
                    <button class="action-btn delete-all-btn" onclick="deleteTreeNode('${site.id}', '${site.id}')" title="Hapus Wilayah"><i class="fa-solid fa-trash"></i> Hapus</button>
                </div>
            </div>
            <div class="site-actions-row">
                <button class="action-btn" onclick="saveSiteData('${site.id}')" title="Lihat & Simpan Coding JSON Site" style="flex:1;"><i class="fa-solid fa-code" style="color:var(--accent-color);"></i> Save</button>
                <button class="action-btn" onclick="shareSiteToWhatsApp('${site.id}')" title="Kirim Coding ke WhatsApp" style="flex:1;"><i class="fa-brands fa-whatsapp" style="color:#25d366;"></i> Share WA</button>
            </div>
            <div class="tree-nodes-container">
                ${site.nodes.length > 0 ? renderNodesSummary(site.nodes, site.connections) : '<small style="color:var(--text-secondary)">Belum ada komponen di site ini.</small>'}
            </div>
        </div>
    `).join('');
}

function renderNodesSummary(nodes, connections = []) {
    return nodes.map(node => {
        let parentName = 'Root (Utama)';
        let conn = connections.find(c => c.toNode === node.id);
        if (conn) {
            let pNode = nodes.find(n => n.id === conn.fromNode);
            if (pNode) {
                let portDesc = (pNode.type === 'FBT') ? ` (Out Saluran ${conn.fromPort === 0 ? '1' : '2'})` : ` (Port Out #${conn.fromPort + 1})`;
                parentName = `${pNode.name}${portDesc}`;
            }
        }

        return `
            <div class="tree-node-item">
                <div class="tree-node-content">
                    <div class="tree-node-info">
                        <span class="tree-node-badge">${node.type}</span>
                        <strong>${node.name}</strong> 
                    </div>
                </div>
                <div class="node-io-details">
                    <i class="fa-solid fa-network-wired" style="color:var(--accent-color);"></i> Hubungan: ${parentName} | Param: ${getNodeDetailSummary(node)}
                </div>
            </div>
        `;
    }).join('');
}

function getNodeDetailSummary(node) {
    if (node.type === 'OLT') return `Out: ${parseFloat(node.value || 0).toFixed(2)} dBm`;
    if (node.type === 'PLC') return `Rasio ${node.value || '1:8'} | In: ${parseFloat(node.inputVal || 0).toFixed(2)} | Out: ${parseFloat(node.outputVal || 0).toFixed(2)}`;
    if (node.type === 'FBT') {
        let parts = (node.value || '50:50').split(':');
        return `Rasio ${node.value || '50:50'} | In: ${parseFloat(node.inputVal || 0).toFixed(2)} | Out ${parts[0]}%: ${parseFloat(node.out1Val || 0).toFixed(2)} | Out ${parts[1]}%: ${parseFloat(node.out2Val || 0).toFixed(2)}`;
    }
    return '';
}

function selectPassive(index) {
    currentPassive = passiveData[index];
    document.getElementById('selectedPassive').innerText = currentPassive.label;
    closeModal('passiveModal');
}

function selectRatio(index) {
    currentRatio = ratioData[index];
    document.getElementById('selectedRatio').innerText = currentRatio.label;
    closeModal('ratioModal');
}

function calculate() {
    const laserInput = parseFloat(document.getElementById('laserInput').value) || 0;
    const additionalLoss = parseFloat(document.getElementById('additionalLoss').value) || 0;
    const plcLoss = currentPassive.loss || 0;
    
    let totalLoss = plcLoss + additionalLoss;
    let finalPower = laserInput - totalLoss;

    let resultsContainer = document.getElementById('resultsContainer');
    resultsContainer.style.display = 'block';

    let html = '';

    if (currentPassive.value) {
        html += `
            <div class="result-card" style="border-left-color: #22c55e;">
                <div class="result-card-row">
                    <div class="result-info">
                        <span class="result-label">Passive Splitter (${currentPassive.label}) Output</span>
                        <span class="result-sublabel">Loss ~${plcLoss} dB</span>
                    </div>
                    <span class="result-value" style="color:#22c55e;">${finalPower.toFixed(2)} dBm</span>
                </div>
                <div class="result-actions">
                    <button class="action-btn" onclick="copyResult('${finalPower.toFixed(2)}')"><i class="fa-solid fa-copy"></i> Copy</button>
                    <button class="action-btn" onclick="useAsInput('${finalPower.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i> Input</button>
                </div>
            </div>
        `;
    }

    if (currentRatio.value) {
        let r1 = currentRatio.r1;
        let r2 = currentRatio.r2;
        let ratioLoss1 = -10 * Math.log10(r1 / 100);
        let ratioLoss2 = -10 * Math.log10(r2 / 100);
        let finalPowerRatio1 = finalPower - ratioLoss1;
        let finalPowerRatio2 = finalPower - ratioLoss2;

        html += `
            <div class="result-card" style="border-left-color: #eab308;">
                <div class="result-card-row">
                    <div class="result-info">
                        <span class="result-label">Ratio Out ${r1}%</span>
                        <span class="result-sublabel">Loss ~${ratioLoss1.toFixed(2)} dB</span>
                    </div>
                    <span class="result-value" style="color:#eab308;">${finalPowerRatio1.toFixed(2)} dBm</span>
                </div>
                <div class="result-actions">
                    <button class="action-btn" onclick="copyResult('${finalPowerRatio1.toFixed(2)}')"><i class="fa-solid fa-copy"></i> Copy</button>
                    <button class="action-btn" onclick="useAsInput('${finalPowerRatio1.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i> Input</button>
                </div>
            </div>
            <div class="result-card" style="border-left-color: #ec4899;">
                <div class="result-card-row">
                    <div class="result-info">
                        <span class="result-label">Ratio Out ${r2}%</span>
                        <span class="result-sublabel">Loss ~${ratioLoss2.toFixed(2)} dB</span>
                    </div>
                    <span class="result-value" style="color:#ec4899;">${finalPowerRatio2.toFixed(2)} dBm</span>
                </div>
                <div class="result-actions">
                    <button class="action-btn" onclick="copyResult('${finalPowerRatio2.toFixed(2)}')"><i class="fa-solid fa-copy"></i> Copy</button>
                    <button class="action-btn" onclick="useAsInput('${finalPowerRatio2.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i> Input</button>
                </div>
            </div>
        `;
    }

    if (!currentPassive.value && !currentRatio.value) {
        html = `
            <div class="result-card" style="border-left-color: #3b82f6;">
                <div class="result-card-row">
                    <div class="result-info">
                        <span class="result-label">Direct Output Power</span>
                        <span class="result-sublabel">Loss: ${totalLoss.toFixed(2)} dB</span>
                    </div>
                    <span class="result-value" style="color:#3b82f6;">${finalPower.toFixed(2)} dBm</span>
                </div>
                <div class="result-actions">
                    <button class="action-btn" onclick="copyResult('${finalPower.toFixed(2)}')"><i class="fa-solid fa-copy"></i> Copy</button>
                    <button class="action-btn" onclick="useAsInput('${finalPower.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i> Input</button>
                </div>
            </div>
        `;
    }

    resultsContainer.innerHTML = html;

    const now = new Date();
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const tanggal = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
    
    const historyItem = {
        dateTime: `${jam}, ${tanggal}`,
        laser: laserInput,
        loss: totalLoss.toFixed(2),
        output: finalPower.toFixed(2),
        splitter: currentPassive.label
    };
    calculationHistoryMode1.unshift(historyItem);
    if (calculationHistoryMode1.length > 20) calculationHistoryMode1.pop();
    localStorage.setItem('bantani_calc_history_m1', JSON.stringify(calculationHistoryMode1));
}

function renderHistoryListMode1() {
    const container = document.getElementById('historyListContainer');
    if (!container) return;

    if (calculationHistoryMode1.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 20px;">Belum ada riwayat kalkulasi Mode 1.</p>`;
        return;
    }

    container.innerHTML = calculationHistoryMode1.map((item) => `
        <div class="history-item">
            <div class="history-item-header">
                <span><i class="fa-solid fa-clock"></i> ${item.dateTime}</span>
                <button class="action-btn" onclick="useAsInputFromHistory('${item.output}')"><i class="fa-solid fa-arrow-up"></i> Gunakan Power</button>
            </div>
            <div class="history-item-body">
                <span>Laser: <strong>${item.laser} dBm</strong> | Splitter: <strong>${item.splitter}</strong></span>
                <span style="color:var(--accent-color);">Total Loss: ${item.loss} dB | Output: <strong>${item.output} dBm</strong></span>
            </div>
        </div>
    `).join('');
}

function renderHistoryListMode2() {
    const container = document.getElementById('historyListContainer');
    if (!container) return;

    if (calculationHistoryMode2.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 20px;">Belum ada riwayat kalkulasi Mode 2.</p>`;
        return;
    }

    container.innerHTML = calculationHistoryMode2.map((item) => `
        <div class="history-item">
            <div class="history-item-header">
                <span><i class="fa-solid fa-clock"></i> ${item.dateTime}</span>
                <div style="display:flex; gap:4px;">
                    <button class="action-btn" onclick="useAsRedamanInput('${item.smallVal}')"><i class="fa-solid fa-arrow-up"></i> Input ${item.smallPct}%</button>
                    <button class="action-btn" onclick="useAsRedamanInput('${item.largeVal}')"><i class="fa-solid fa-arrow-up"></i> Input ${item.largePct}%</button>
                </div>
            </div>
            <div class="history-item-body">
                <span>Redaman: <strong>${item.powerIn} dBm</strong> | Target: <strong>${item.target} dBm</strong></span>
                <span style="color:var(--accent-color); font-weight:600;">${item.summary}</span>
            </div>
        </div>
    `).join('');
}

function useAsInputFromHistory(val) {
    document.getElementById('laserInput').value = val;
    closeModal('historyModal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function clearHistory() {
    if (activeCalcMode === 1) {
        calculationHistoryMode1 = [];
        localStorage.removeItem('bantani_calc_history_m1');
        renderHistoryListMode1();
    } else {
        calculationHistoryMode2 = [];
        localStorage.removeItem('bantani_calc_history_m2');
        renderHistoryListMode2();
    }
}

function openFullCanvas(siteId) {
    activeCanvasSiteId = siteId;
    activeConnectionSource = null;
    const site = siteTreeList.find(s => s.id === siteId);
    if (site) {
        recalculateSitePropagation(site);
        document.getElementById('modalCanvasSiteTitle').innerHTML = `<i class="fa-solid fa-pen-ruler"></i> Kanvas Site: ${site.name}`;
    }
    openModal('fullCanvasModal');
    renderMobileCanvasWorkspace();
}

function setPreviewTheme(theme) {
    previewThemeMode = theme;
    document.getElementById('btnPreviewDark').classList.remove('active');
    document.getElementById('btnPreviewLight').classList.remove('active');

    if (theme === 'dark') {
        document.getElementById('btnPreviewDark').classList.add('active');
    } else {
        document.getElementById('btnPreviewLight').classList.add('active');
    }
    drawDiagramPreviewCanvas();
}

function openDiagramPreviewModal() {
    openModal('diagramPreviewModal');
    resetPreviewZoom();
    setTimeout(() => {
        setupCanvasDimensions();
        drawDiagramPreviewCanvas();
    }, 100);
}

function setupCanvasDimensions() {
    const canvas = document.getElementById('previewCanvas');
    const container = document.getElementById('diagramPreviewBody');
    if (!canvas || !container) return;

    let dpr = window.devicePixelRatio || 1;
    let width = container.clientWidth || 800;
    let height = container.clientHeight || 600;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    drawDiagramPreviewCanvas();
}

function resetPreviewZoom() {
    previewScale = 1.0;
    previewOffsetX = 40;
    previewOffsetY = 40;
    drawDiagramPreviewCanvas();
}

// Sistem Rekursif Propagasi Redaman Otomatis
function recalculateSitePropagation(site) {
    if (!site.nodes || !site.connections) return;

    let nodeMap = {};
    site.nodes.forEach(n => {
        nodeMap[n.id] = n;
    });

    let visited = new Set();

    function propagateNode(nodeId) {
        if (visited.has(nodeId)) return;
        visited.add(nodeId);

        let incomingConns = site.connections.filter(c => c.toNode === nodeId);
        incomingConns.forEach(conn => {
            let parentNode = nodeMap[conn.fromNode];
            let currentNode = nodeMap[conn.toNode];

            if (parentNode && currentNode) {
                propagateNode(parentNode.id);

                let sourcePower = 0;
                if (parentNode.type === 'OLT') {
                    sourcePower = parseFloat(parentNode.value) || 0;
                } else if (parentNode.type === 'PLC') {
                    sourcePower = parseFloat(parentNode.outputVal) || 0;
                } else if (parentNode.type === 'FBT') {
                    sourcePower = conn.fromPort === 0 ? (parseFloat(parentNode.out1Val) || 0) : (parseFloat(parentNode.out2Val) || 0);
                }

                currentNode.inputVal = sourcePower;

                if (currentNode.type === 'PLC') {
                    let plcLossMap = { '1:2': 3.7, '1:4': 7.2, '1:8': 10.5, '1:16': 13.8, '1:32': 17.0, '1:64': 20.5 };
                    let loss = plcLossMap[currentNode.value || '1:8'] || 10.5;
                    currentNode.outputVal = (sourcePower - loss).toFixed(2);
                } else if (currentNode.type === 'FBT') {
                    let rParts = (currentNode.value || '50:50').split(':');
                    let r1 = parseInt(rParts[0]) || 50;
                    let r2 = parseInt(rParts[1]) || 50;
                    let loss1 = -10 * Math.log10(r1 / 100);
                    let loss2 = -10 * Math.log10(r2 / 100);
                    currentNode.out1Val = (sourcePower - loss1).toFixed(2);
                    currentNode.out2Val = (sourcePower - loss2).toFixed(2);
                }
            }
        });
    }

    site.nodes.forEach(n => {
        propagateNode(n.id);
    });
}

function computeTreeLayout(site) {
    let nodes = site.nodes;
    let connections = site.connections || [];

    let nodeMap = {};
    nodes.forEach(n => {
        nodeMap[n.id] = { node: n, children: [], parent: null, x: 0, y: 0, level: 0 };
    });

    connections.forEach(c => {
        if (nodeMap[c.fromNode] && nodeMap[c.toNode]) {
            nodeMap[c.fromNode].children.push({ child: nodeMap[c.toNode], port: c.fromPort });
            nodeMap[c.toNode].parent = nodeMap[c.fromNode];
        }
    });

    let roots = nodes.filter(n => !connections.some(c => c.toNode === n.id));
    if (roots.length === 0 && nodes.length > 0) roots = [nodes[0]];

    let nodeWidth = 460;
    let nodeHeight = 150;
    let verticalSpacing = 100;
    let horizontalSpacing = 60;

    function layoutSubtree(item, level, startX) {
        item.level = level;
        let totalSubtreeWidth = nodeWidth;

        if (item.children.length > 0) {
            let childX = startX;
            item.children.forEach((cObj) => {
                let cWidth = layoutSubtree(cObj.child, level + 1, childX);
                childX += cWidth + horizontalSpacing;
                if (cWidth > totalSubtreeWidth) totalSubtreeWidth = cWidth;
            });
        }

        item.x = startX;
        item.y = 50 + level * (nodeHeight + verticalSpacing);
        return Math.max(nodeWidth, totalSubtreeWidth);
    }

    let nextRootX = 50;
    roots.forEach(r => {
        let rItem = nodeMap[r.id];
        if (rItem) {
            let subW = layoutSubtree(rItem, 0, nextRootX);
            nextRootX += subW + 100;
        }
    });

    return nodeMap;
}

function drawDiagramPreviewCanvas() {
    const canvas = document.getElementById('previewCanvas');
    if (!canvas) return;
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;

    recalculateSitePropagation(site);

    const ctx = canvas.getContext('2d');
    let width = canvas.width / (window.devicePixelRatio || 1);
    let height = canvas.height / (window.devicePixelRatio || 1);
    ctx.clearRect(0, 0, width, height);

    if (previewThemeMode === 'light') {
        ctx.fillStyle = '#f8fafc';
    } else {
        ctx.fillStyle = '#050507';
    }
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.translate(previewOffsetX, previewOffsetY);
    ctx.scale(previewScale, previewScale);

    let layoutMap = computeTreeLayout(site);

    // 1. RENDER GARIS KONEKSI DI BELAKANG BOX
    if (site.connections) {
        site.connections.forEach(conn => {
            let pItem = layoutMap[conn.fromNode];
            let cItem = layoutMap[conn.toNode];
            if (pItem && cItem) {
                let startX = pItem.x + 460;
                let startY = pItem.y + 75;

                let pNode = pItem.node;
                if (pNode.type === 'FBT') {
                    startY = pItem.y + (conn.fromPort === 0 ? 50 : 110);
                } else if (pNode.type === 'PLC') {
                    let totalP = parseInt((pNode.value || '1:8').split(':')[1]) || 8;
                    let stepH = 150 / (totalP + 1);
                    startY = pItem.y + stepH * (conn.fromPort + 1);
                }

                let endX = cItem.x;
                let endY = cItem.y + 75;

                ctx.strokeStyle = previewThemeMode === 'light' ? '#16a34a' : '#22c55e';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(startX, startY);
                ctx.bezierCurveTo(startX + 60, startY, endX - 60, endY, endX, endY);
                ctx.stroke();
            }
        });
    }

    // 2. RENDER BOX OBJEK TRANSPARAN 50% & KETERANGAN REDAMAN OUTPUT FBT
    Object.values(layoutMap).forEach(item => {
        let node = item.node;
        let posX = item.x;
        let posY = item.y;
        let w = 460;
        let h = 150;

        ctx.fillStyle = previewThemeMode === 'light' ? 'rgba(255, 255, 255, 0.5)' : 'rgba(18, 18, 20, 0.5)';
        ctx.strokeStyle = previewThemeMode === 'light' ? '#cbd5e1' : '#27272a';
        ctx.lineWidth = 2;
        ctx.fillRect(posX, posY, w, h);
        ctx.strokeRect(posX, posY, w, h);

        ctx.fillStyle = previewThemeMode === 'light' ? '#16a34a' : '#22c55e';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`[${node.type}] ${node.name}`, posX + 25, posY + 30);

        if (node.type !== 'OLT') {
            ctx.fillStyle = '#3b82f6';
            ctx.beginPath();
            ctx.arc(posX, posY + 75, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = previewThemeMode === 'light' ? '#0f172a' : '#f8fafc';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(`In: ${parseFloat(node.inputVal || 0).toFixed(2)} dBm`, posX + 15, posY + 79);
        }

        if (node.type === 'OLT') {
            ctx.fillStyle = '#22c55e';
            ctx.beginPath();
            ctx.arc(posX + w, posY + 75, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = previewThemeMode === 'light' ? '#0f172a' : '#f8fafc';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(`Out: ${parseFloat(node.value || 0).toFixed(2)} dBm`, posX + w - 15, posY + 79);
        } else if (node.type === 'PLC') {
            let totalPorts = parseInt((node.value || '1:8').split(':')[1]) || 8;
            let stepY = h / (totalPorts + 1);
            let outVal = parseFloat(node.outputVal || 0).toFixed(2);

            for (let i = 0; i < totalPorts; i++) {
                let pY = posY + stepY * (i + 1);
                ctx.fillStyle = '#22c55e';
                ctx.beginPath();
                ctx.arc(posX + w, pY, 5, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 1.5;
                ctx.stroke();

                ctx.fillStyle = previewThemeMode === 'light' ? '#0f172a' : '#f8fafc';
                ctx.font = '10px sans-serif';
                ctx.textAlign = 'right';
                ctx.fillText(`Out #${i + 1}: ${outVal} dBm`, posX + w - 12, pY + 4);
            }
        } else if (node.type === 'FBT') {
            let parts = (node.value || '50:50').split(':');
            let out1 = parseFloat(node.out1Val || 0).toFixed(2);
            let out2 = parseFloat(node.out2Val || 0).toFixed(2);
            
            ctx.fillStyle = '#eab308';
            ctx.beginPath();
            ctx.arc(posX + w, posY + 50, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = previewThemeMode === 'light' ? '#0f172a' : '#f8fafc';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(`Out ${parts[0]}% (${parts[0]}): ${out1} dBm`, posX + w - 15, posY + 54);

            ctx.fillStyle = '#ec4899';
            ctx.beginPath();
            ctx.arc(posX + w, posY + 110, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = previewThemeMode === 'light' ? '#0f172a' : '#f8fafc';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(`Out ${parts[1]}% (${parts[1]}): ${out2} dBm`, posX + w - 15, posY + 114);
        }
    });

    ctx.restore();
}

function initPreviewInteraction() {
    const canvas = document.getElementById('previewCanvas');
    if (!canvas) return;

    canvas.addEventListener('mousedown', (e) => {
        isDraggingPreview = true;
        startDragX = e.clientX - previewOffsetX;
        startDragY = e.clientY - previewOffsetY;
        canvas.style.cursor = 'grabbing';
    });

    window.addEventListener('mousemove', (e) => {
        if (!isDraggingPreview) return;
        previewOffsetX = e.clientX - startDragX;
        previewOffsetY = e.clientY - startDragY;
        drawDiagramPreviewCanvas();
    });

    window.addEventListener('mouseup', () => {
        isDraggingPreview = false;
        canvas.style.cursor = 'grab';
    });

    canvas.addEventListener('wheel', (e) => {
        e.preventDefault();
        let zoomFactor = 1.1;
        if (e.deltaY > 0) {
            previewScale = Math.max(0.3, previewScale / zoomFactor);
        } else {
            previewScale = Math.min(3.0, previewScale * zoomFactor);
        }
        drawDiagramPreviewCanvas();
    }, { passive: false });

    canvas.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
            isDraggingPreview = true;
            startDragX = e.touches[0].clientX - previewOffsetX;
            startDragY = e.touches[0].clientY - previewOffsetY;
        } else if (e.touches.length === 2) {
            isDraggingPreview = false;
            initialPinchDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
        }
    }, { passive: true });

    canvas.addEventListener('touchmove', (e) => {
        if (isDraggingPreview && e.touches.length === 1) {
            previewOffsetX = e.touches[0].clientX - startDragX;
            previewOffsetY = e.touches[0].clientY - startDragY;
            drawDiagramPreviewCanvas();
        } else if (e.touches.length === 2 && initialPinchDistance !== null) {
            let currentDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
            let factor = currentDistance / initialPinchDistance;
            previewScale = Math.min(3.0, Math.max(0.3, previewScale * (factor > 1 ? 1.03 : 0.97)));
            initialPinchDistance = currentDistance;
            drawDiagramPreviewCanvas();
        }
    }, { passive: true });

    canvas.addEventListener('touchend', () => {
        isDraggingPreview = false;
        initialPinchDistance = null;
    });
}

// KONEKSI LANGSUNG OTOMATIS TANPA POP-UP PILIHAN KETIKA FBT DIHUBUNGKAN KE PASIF
function handlePortTap(nodeId, portType, portIndex) {
    if (portType === 'out') {
        activeConnectionSource = { nodeId: nodeId, portIndex: portIndex };
        const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
        let srcNode = site.nodes.find(n => n.id === nodeId);
        alert(`Port Output [${srcNode.name} - Saluran #${portIndex + 1}] dipilih sebagai sumber. Sekarang sentuh Port Input pada perangkat tujuan untuk menghubungkannya secara langsung!`);
    } else if (portType === 'in') {
        if (!activeConnectionSource) {
            alert('Silakan pilih/sentuh Port Output dari perangkat sumber terlebih dahulu sebelum menyentuh Port Input.');
            return;
        }

        const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
        if (!site) return;

        if (activeConnectionSource.nodeId === nodeId) {
            alert('Tidak dapat menghubungkan perangkat ke dirinya sendiri.');
            activeConnectionSource = null;
            return;
        }

        finalizeConnection(activeConnectionSource.nodeId, activeConnectionSource.portIndex, nodeId, 0);
    }
}

function finalizeConnection(fromNodeId, fromPort, toNodeId, toPort) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;

    if (!site.connections) site.connections = [];
    site.connections = site.connections.filter(c => c.toNode !== toNodeId);

    site.connections.push({
        fromNode: fromNodeId,
        fromPort: fromPort,
        toNode: toNodeId,
        toPort: toPort
    });

    recalculateSitePropagation(site);

    activeConnectionSource = null;
    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    renderMobileCanvasWorkspace();
    renderSiteTree();
    alert('Berhasil terhubung langsung dan kalkulasi redaman otomatis diperbarui!');
}

function renderMobileCanvasWorkspace() {
    const container = document.getElementById('canvasMobileWorkspace');
    if (!container) return;

    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site || site.nodes.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 40px;">Belum ada komponen di site ini.<br>Klik tombol <strong>+ OLT</strong>, <strong>+ Pasif</strong>, atau <strong>+ Rasio</strong> di atas untuk menambahkan.</p>`;
        return;
    }

    recalculateSitePropagation(site);

    container.innerHTML = site.nodes.map((node) => {
        let parentName = 'Belum Terhubung';
        let conn = site.connections ? site.connections.find(c => c.toNode === node.id) : null;
        if (conn) {
            let pNode = site.nodes.find(n => n.id === conn.fromNode);
            if (pNode) {
                let portDesc = (pNode.type === 'FBT') ? ` (Out Saluran ${conn.fromPort + 1})` : (pNode.type === 'PLC' ? ` (Port Out #${conn.fromPort + 1})` : ` (Port Out)`);
                parentName = `${pNode.name}${portDesc}`;
            }
        }

        let isOlt = node.type === 'OLT';
        let isInputConnected = conn !== null;
        let isOutputConnected = site.connections && site.connections.some(c => c.fromNode === node.id);

        let outputPortsHtml = '';
        if (node.type === 'OLT') {
            outputPortsHtml = `
                <div class="port-row">
                    <div class="port-badge ${isOutputConnected ? 'connected' : ''}" onclick="handlePortTap('${node.id}', 'out', 0)">
                        <span>Port Output (Terhubung: ${site.connections ? site.connections.filter(c => c.fromNode === node.id).length : 0} perangkat)</span> 
                        <span class="port-dot-out"></span>
                    </div>
                </div>
            `;
        } else if (node.type === 'PLC') {
            let totalPorts = parseInt((node.value || '1:8').split(':')[1]) || 8;
            let outVal = parseFloat(node.outputVal || 0).toFixed(2);
            for (let i = 0; i < totalPorts; i++) {
                let isPortConn = site.connections && site.connections.some(c => c.fromNode === node.id && c.fromPort === i);
                outputPortsHtml += `
                    <div class="port-row">
                        <div class="port-badge ${isPortConn ? 'connected' : ''}" onclick="handlePortTap('${node.id}', 'out', ${i})">
                            <span>Port Output #${i + 1} (${outVal} dBm) ${isPortConn ? '(Terhubung)' : ''}</span> 
                            <span class="port-dot-out"></span>
                        </div>
                    </div>
                `;
            }
        } else if (node.type === 'FBT') {
            let parts = (node.value || '50:50').split(':');
            let out1 = parseFloat(node.out1Val || 0).toFixed(2);
            let out2 = parseFloat(node.out2Val || 0).toFixed(2);
            let isConn0 = site.connections && site.connections.some(c => c.fromNode === node.id && c.fromPort === 0);
            let isConn1 = site.connections && site.connections.some(c => c.fromNode === node.id && c.fromPort === 1);
            outputPortsHtml = `
                <div class="port-row">
                    <div class="port-badge ${isConn0 ? 'connected' : ''}" onclick="handlePortTap('${node.id}', 'out', 0)">
                        <span>Output Saluran 1 (${parts[0]}%) : ${out1} dBm ${isConn0 ? '(Terhubung)' : ''}</span> 
                        <span class="port-dot-out" style="background:#eab308;"></span>
                    </div>
                </div>
                <div class="port-row">
                    <div class="port-badge ${isConn1 ? 'connected' : ''}" onclick="handlePortTap('${node.id}', 'out', 1)">
                        <span>Output Saluran 2 (${parts[1]}%) : ${out2} dBm ${isConn1 ? '(Terhubung)' : ''}</span> 
                        <span class="port-dot-out" style="background:#ec4899;"></span>
                    </div>
                </div>
            `;
        }

        return `
            <div class="mobile-node-card" style="${activeConnectionSource && activeConnectionSource.nodeId === node.id ? 'border: 2px dashed #ef4444;' : ''}">
                <div class="mobile-node-header">
                    <span class="mobile-node-title"><i class="fa-solid fa-network-wired" style="color:var(--accent-color);"></i> [${node.type}] ${node.name}</span>
                    <div style="display:flex; gap:4px;">
                        <button class="action-btn" onclick="openEditNodeModal('${node.id}')"><i class="fa-solid fa-pen"></i> Edit</button>
                        <button class="action-btn delete-all-btn" onclick="deleteNodeDirect('${node.id}')"><i class="fa-solid fa-trash"></i> Hapus</button>
                    </div>
                </div>

                <div class="mobile-node-ports">
                    ${!isOlt ? `
                        <div class="port-row">
                            <div class="port-badge ${isInputConnected ? 'connected' : ''}" onclick="handlePortTap('${node.id}', 'in', 0)">
                                <span class="port-dot-in"></span> 
                                <span>${isInputConnected ? `Terhubung ke ${parentName}` : 'Port Input (Sentuh untuk Hubungkan)'}</span>
                            </div>
                        </div>
                    ` : `<div><small style="color:var(--text-secondary)">Root (Sumber Utama)</small></div>`}

                    ${outputPortsHtml}
                </div>

                <div class="mobile-node-body">
                    <div><strong>Parameter & Redaman:</strong> ${getNodeDetailSummary(node)}</div>
                </div>
            </div>
        `;
    }).join('');
}

function addCanvasNode(type) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;

    let defaultName = type === 'OLT' ? 'OLT Core 1' : type === 'PLC' ? 'PLC Splitter 1:8' : 'FBT Ratio 50:50';

    let newNode = {
        id: 'node_' + Date.now(),
        type: type,
        name: defaultName,
        value: type === 'OLT' ? '0' : type === 'PLC' ? '1:8' : '50:50',
        inputVal: 0,
        outputVal: 0,
        out1Val: 0,
        out2Val: 0
    };

    site.nodes.push(newNode);
    recalculateSitePropagation(site);
    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    renderMobileCanvasWorkspace();
    renderSiteTree();
}

function clearCanvasNodes() {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    if (confirm('Reset dan hapus seluruh komponen di site ini?')) {
        site.nodes = [];
        site.connections = [];
        localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        renderMobileCanvasWorkspace();
        renderSiteTree();
    }
}

function openEditNodeModal(nodeId) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    const node = site.nodes.find(n => n.id === nodeId);
    if (!node) return;

    document.getElementById('editNodeCanvasId').value = node.id;
    document.getElementById('editNodeNameLabel').value = node.name;
    document.getElementById('editNodeTitle').innerHTML = `<i class="fa-solid fa-pen"></i> Edit ${node.type} - ${node.name}`;

    document.getElementById('editGroupOlt').style.display = 'none';
    document.getElementById('editGroupPlc').style.display = 'none';
    document.getElementById('editGroupFbt').style.display = 'none';

    if (node.type === 'OLT') {
        document.getElementById('editGroupOlt').style.display = 'block';
        document.getElementById('editOltValue').value = node.value || 0;
    } else if (node.type === 'PLC') {
        document.getElementById('editGroupPlc').style.display = 'block';
        document.getElementById('editPlcRatioType').value = node.value || '1:8';
    } else if (node.type === 'FBT') {
        document.getElementById('editGroupFbt').style.display = 'block';
        document.getElementById('editFbtRatioType').value = node.value || '50:50';
    }

    openModal('editNodeModal');
}

function saveEditedCanvasNode() {
    const nodeId = document.getElementById('editNodeCanvasId').value;
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    const node = site.nodes.find(n => n.id === nodeId);
    if (!node) return;

    node.name = document.getElementById('editNodeNameLabel').value.trim() || node.type;

    if (node.type === 'OLT') {
        node.value = parseFloat(document.getElementById('editOltValue').value) || 0;
    } else if (node.type === 'PLC') {
        node.value = document.getElementById('editPlcRatioType').value;
    } else if (node.type === 'FBT') {
        node.value = document.getElementById('editFbtRatioType').value;
    }

    recalculateSitePropagation(site);

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    closeModal('editNodeModal');
    renderMobileCanvasWorkspace();
    renderSiteTree();
}

function deleteCanvasNodePrompt() {
    deleteNodeDirect(document.getElementById('editNodeCanvasId').value);
    closeModal('editNodeModal');
}

function useAsInput(val) {
    document.getElementById('laserInput').value = val;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function copyResult(val) {
    navigator.clipboard.writeText(val).then(() => {
        alert('Berhasil menyalin: ' + val + ' dBm');
    }).catch(err => {
        console.error('Gagal menyalin text: ', err);
    });
}

function resetForm() {
    document.getElementById('laserInput').value = '0.00';
    document.getElementById('additionalLoss').value = '0.00';
    selectPassive(0);
    selectRatio(0);
    document.getElementById('resultsContainer').style.display = 'none';
}

init();