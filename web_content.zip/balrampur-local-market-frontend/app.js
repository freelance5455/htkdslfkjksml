const stores=[
 {id:1,name:"शिव किराना स्टोर",cat:"किराना",icon:"🏪",desc:"किराना एवं घरेलू सामान",rating:"4.5",products:[
  {id:"aata",name:"आटा (10kg)",price:450,emoji:"🌾"},{id:"chawal",name:"चावल (10kg)",price:520,emoji:"🍚"},{id:"oil",name:"रिफाइंड तेल (1L)",price:130,emoji:"🫗"}]},
 {id:2,name:"युवा जनरल स्टोर",cat:"किराना",icon:"🛍️",desc:"किराना, ब्यूटी, दैनिक उपयोग",rating:"4.2",products:[
  {id:"soap",name:"नहाने का साबुन",price:55,emoji:"🧼"},{id:"shampoo",name:"शैम्पू",price:120,emoji:"🧴"}]},
 {id:3,name:"गुप्ता मोबाइल हाउस",cat:"मोबाइल",icon:"📱",desc:"मोबाइल एवं इलेक्ट्रॉनिक्स",rating:"4.7",products:[
  {id:"phone",name:"स्मार्टफोन",price:8999,emoji:"📱"},{id:"charger",name:"फास्ट चार्जर",price:699,emoji:"🔌"}]},
 {id:4,name:"शर्मा वस्त्रालय",cat:"फैशन",icon:"👕",desc:"कपड़े एवं फैशन",rating:"4.3",products:[
  {id:"shirt",name:"कॉटन शर्ट",price:799,emoji:"👕"},{id:"dress",name:"कुर्ती",price:999,emoji:"👗"}]}
];
let cart=JSON.parse(localStorage.getItem("blm-cart")||"[]"),orders=JSON.parse(localStorage.getItem("blm-orders")||"[]");
let currentProduct=null,currentQty=1,lastScreen="home";

function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));document.getElementById(id).classList.add("active");lastScreen=id; if(id==="home")renderStores();if(id==="stores")renderAllStores();if(id==="cart")renderCart();if(id==="orders")renderOrders();if(id==="profile"){} updateCount();window.scrollTo(0,0)}
function historyBack(){show(lastScreen==="product"?"store":"home")}
function renderStores(){document.getElementById("storeCards").innerHTML=stores.slice(0,3).map(storeCard).join("")}
function renderAllStores(){document.getElementById("allStores").innerHTML=stores.map(storeCard).join("")}
function storeCard(s){return `<button class="store-card" onclick="openStore(${s.id})"><div class="store-pic">${s.icon}</div><div><h4>${s.name}</h4><p>${s.desc}</p><small>⭐ ${s.rating}　📍 बलरामपुर</small></div></button>`}
function openStore(id){const s=stores.find(x=>x.id===id);document.getElementById("storeTitle").textContent=s.name;document.getElementById("storeName").textContent=s.name;document.getElementById("storeProducts").innerHTML=s.products.map(productRow).join("");lastScreen="store";show("store")}
function productRow(p){return `<div class="product-row"><div class="product-thumb">${p.emoji}</div><div class="grow"><h4>${p.name}</h4><b>₹${p.price.toLocaleString("en-IN")}</b></div><button class="add" onclick='openProduct(${JSON.stringify(p).replace(/'/g,"&#39;")})'>कार्ट में डालें</button></div>`}
function openProduct(p){currentProduct=p;currentQty=1;document.getElementById("productName").textContent=p.name;document.getElementById("productEmoji").textContent=p.emoji;document.getElementById("productPrice").textContent="₹"+p.price.toLocaleString("en-IN");document.getElementById("qty").textContent=1;show("product")}
function changeQty(n){currentQty=Math.max(1,currentQty+n);document.getElementById("qty").textContent=currentQty}
function addCurrent(){for(let i=0;i<currentQty;i++)cart.push(currentProduct);save();show("cart")}
function addOne(p){cart.push(p);save();renderCart()}
function save(){localStorage.setItem("blm-cart",JSON.stringify(cart));updateCount()}
function updateCount(){document.getElementById("cartCount").textContent=cart.length}
function renderCart(){const el=document.getElementById("cartItems");if(!cart.length){el.innerHTML='<div class="input-card" style="text-align:center;padding:35px">🛒<br><b>आपका कार्ट खाली है</b><br><small>दुकान से सामान जोड़ें</small></div>';document.getElementById("subtotal").textContent="₹0";document.getElementById("total").textContent="₹0";return}el.innerHTML=cart.map((p,i)=>`<div class="cart-row"><div class="product-thumb">${p.emoji}</div><div class="grow"><b>${p.name}</b><div>₹${p.price.toLocaleString("en-IN")}</div></div><button onclick="removeCart(${i})">🗑️</button></div>`).join("");let sub=cart.reduce((a,p)=>a+p.price,0);document.getElementById("subtotal").textContent="₹"+sub.toLocaleString("en-IN");document.getElementById("total").textContent="₹"+(sub+40).toLocaleString("en-IN")}
function removeCart(i){cart.splice(i,1);save();renderCart()}
function placeOrder(){if(!cart.length)return alert("पहले कार्ट में सामान जोड़ें");let total=cart.reduce((a,p)=>a+p.price,0)+40;orders.unshift({id:"BLM"+Math.floor(100000+Math.random()*899999),date:new Date().toLocaleDateString("hi-IN"),total,items:cart.length,status:"ऑर्डर कन्फर्म"});cart=[];save();localStorage.setItem("blm-orders",JSON.stringify(orders));show("orders")}
function renderOrders(){const el=document.getElementById("ordersList");if(!orders.length){el.innerHTML='<div class="input-card" style="text-align:center;padding:35px">📦<br><b>अभी कोई ऑर्डर नहीं</b></div>';return}el.innerHTML=orders.map(o=>`<div class="order-card"><b>#${o.id}</b><p>${o.date}　•　${o.items} आइटम</p><div class="order-status">● ${o.status}</div><hr><b>कुल: ₹${o.total.toLocaleString("en-IN")}</b></div>`).join("")}
function filterCat(cat){document.getElementById("search").value=cat;show("home");renderProducts()}
function renderProducts(){const q=document.getElementById("search").value.trim().toLowerCase();const filtered=stores.filter(s=>!q||s.name.toLowerCase().includes(q)||s.cat.toLowerCase().includes(q)||s.desc.toLowerCase().includes(q));document.getElementById("storeCards").innerHTML=(filtered.length?filtered:stores.slice(0,3)).map(storeCard).join("")}
function focusSearch(){document.getElementById("search").focus()}
function sellerDashboard(){alert("डेमो लॉगिन सफल — दुकानदार डैशबोर्ड आगे जोड़ा जा सकता है।")}
renderStores();updateCount();
