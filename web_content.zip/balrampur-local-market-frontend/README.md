# Balrampur Local Market — APK-ready Frontend

यह एक responsive, Hindi-first frontend prototype है जो दिए गए reference design के मुख्य customer flow को तैयार करता है:
- Splash / Home
- Search + categories
- Local store list
- Store detail + products
- Product detail
- Cart
- Checkout
- Order tracking/list
- Customer profile
- Demo Seller Login
- Demo Admin Panel

## सबसे आसान APK तरीका — Capacitor

1. Node.js 18+ इंस्टॉल करें.
2. इस folder में terminal खोलें.
3. चलाएँ:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio में **Build > Generate App Bundles or APKs > Generate APKs** चुनें.

> यह prototype backend/API के बिना local demo है. `localStorage` से cart और orders demo रूप में सेव होते हैं.

## बिना build के
`index.html` को सीधे browser में खोलकर भी UI देखा जा सकता है.

## आगे backend जोड़ने के points
- Login/OTP
- दुकानदार registration
- Product CRUD
- Admin authentication
- Real payment gateway
- Delivery status
- Firebase/Supabase/REST API
- Push notifications
