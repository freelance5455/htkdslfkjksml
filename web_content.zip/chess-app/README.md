# Chess (single-file web app)

- `index.html` – the whole game (Pass & Play + vs AI, undo, sounds, autosave).
- `icon.svg`   – app icon (export to 512x512 / 1024x1024 PNG for stores).

## Run
Open `index.html` in any modern browser, or host it on any static host
(GitHub Pages, Netlify, Cloudflare Pages). It needs an internet connection
because chessboard.js libraries load from the jsDelivr CDN.

## Turn it into an app
1. **Installable web app (easiest):** host the folder over HTTPS, then use
   https://www.pwabuilder.com to generate a manifest, service worker and
   Android/iOS/Windows packages.
2. **Native wrapper:** use Capacitor (https://capacitorjs.com):
   `npm init -y && npm i @capacitor/core @capacitor/cli`,
   `npx cap init Chess com.example.chess --web-dir=.`,
   `npx cap add android` (and/or `ios`), then `npx cap open android`.
3. For a fully offline app, download cm-chessboard and chess.js and the
   chessboard assets (pieces SVG + CSS) into the folder and point the
   CDN URLs in `index.html` at the local copies.
