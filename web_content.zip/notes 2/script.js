'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,5);
const deb=(f,t)=>{let h;return(...a)=>{clearTimeout(h);h=setTimeout(()=>f(...a),t)}};
const K='studynest.v1';
const TH={dark:['Midnight','#7c83ff'],amoled:['AMOLED','#00e5a8'],light:['Light','#5b5bf0'],ocean:['Ocean','#22d3ee'],sunset:['Sunset','#ff7a59'],forest:['Forest','#4ade80']};
const EM='📚 📝 📖 ✏️ 🧠 💡 🔬 🧪 📐 🧮 🌍 🏛️ 💻 ⚛️ 🧬 🎯 ⭐ 🔥 📌 🗂️ 🎨 🎵 ⚖️ 💬 📊 🔭 🩺 📜 🏆 🚀 🌱 ⏰ ❓ ✅ 🔑'.split(' ');
const CL=['#6c8cff','#34d399','#f59e0b','#f43f5e','#a855f7','#06b6d4'];
const PC=['#ef4444','#f97316','#eab308','#22c55e','#06b6d4','#3b82f6','#a855f7','#ec4899','#ffffff','#111827'];
const HL=['rgba(250,204,21,.5)','rgba(74,222,128,.45)','rgba(56,189,248,.45)','rgba(244,114,182,.5)','rgba(251,146,60,.5)','rgba(167,139,250,.5)'];
const SZ=[12,14,16,18,20,24,28,32,40,48];
const FX=[['glow','✨ Glow'],['box','🔲 Box'],['wavy','〰 Wavy'],['shd','🌫 Shadow'],['grad','🌈 Gradient'],['hide','🙈 Hide']];
const FN=['sans','serif','mono','hand'];
const SC={
  ows:{n:'One Word Substitute',ic:'🔤',f:['Expression / Meaning','One word','Example (optional)']},
  idm:{n:'Idiom / Phrase',ic:'💬',f:['Idiom / Phrase','Meaning','Example (optional)']},
  syn:{n:'Synonym / Antonym',ic:'🔁',f:['Word','Synonyms','Antonyms']}
};

let S={notes:[],bundles:[{id:'b1',n:'Maths',ic:'📐',c:CL[0]},{id:'b2',n:'Science',ic:'🧪',c:CL[1]}],theme:'dark'};
let cur=null,bf=null,icCb=null,sel='',F={b:'all',tag:'',q:''};
try{Object.assign(S,JSON.parse(localStorage.getItem(K)))}catch(e){}
if(!S.seen){S.seen=1;S.notes.push({id:uid(),k:'note',t:'Welcome 👋',h:'<h2>StudyNest me swagat hai</h2><div>Text select karo, floating bar se <mark class="hl" style="--h:rgba(250,204,21,.5)">highlight</mark>, size ya <span class="fx glow">effects</span> lagao.</div>',p:'StudyNest me swagat hai',ic:'👋',b:'',tags:['start'],pin:1,ts:Date.now(),font:'sans'})}
S.notes.forEach(n=>{n.k=n.k||'note';n.rows=n.rows||[];n.pin=n.pin||0;n.tags=n.tags||[]});

const save=deb(()=>{try{localStorage.setItem(K,JSON.stringify(S))}catch(e){toast('Storage full ⚠️ Backup le lo')}},300);
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),2400)}
function setTheme(k){S.theme=k;document.documentElement.dataset.theme=k;$('meta[name=theme-color]').content=getComputedStyle(document.documentElement).getPropertyValue('--bg').trim();save()}
function dl(name,obj){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}
const gsel=()=>S.notes.find(n=>n.id===sel);

/* ---------- list ---------- */
function vis(){
  const s=F.q.toLowerCase();
  return S.notes.filter(n=>(F.b==='all'||(F.b==='pin'?n.pin:n.b===F.b))&&(!F.tag||n.tags.includes(F.tag))&&(!s||(n.t+' '+n.p+' '+n.tags.join(' ')+' '+n.rows.map(r=>r.v.join(' ')).join(' ')).toLowerCase().includes(s))).sort((a,b)=>b.pin-a.pin||b.ts-a.ts);
}
const card=(n,i)=>{
  const b=S.bundles.find(x=>x.id===n.b);
  return`<article class="card" style="--d:${Math.min(i,10)*30}ms;${b?'--bc:'+b.c:''}" data-a="open" data-v="${n.id}"><div class="ci">${n.ic}</div><div class="cb"><h3>${esc(n.t||'Untitled')}${n.pin?' 📌':''}</h3><p>${esc((n.p||'').slice(0,110))}</p><div class="meta">${n.k!=='note'?`<span class="bd k">${SC[n.k].n}</span>`:''}${b?`<span class="bd">${b.ic} ${esc(b.n)}</span>`:''}${n.tags.slice(0,3).map(t=>`<span class="tg">#${esc(t)}</span>`).join('')}</div></div><button class="ib sm cm" data-a="nmenu" data-v="${n.id}">⋮</button></article>`;
};
function render(){
  const b=S.bundles.find(x=>x.id===F.b);
  $('#title').textContent=F.b==='all'?'All Notes':F.b==='pin'?'📌 Pinned':b?b.ic+' '+b.n:'Notes';
  const tags=[...new Set(S.notes.flatMap(n=>n.tags))];
  $('#chips').innerHTML=tags.map(t=>`<button class="chip${F.tag===t?' on':''}" data-a="tag" data-v="${esc(t)}">#${esc(t)}</button>`).join('');
  const l=vis();
  $('#list').innerHTML=l.length?l.map(card).join(''):'<p class="empty">Yaha abhi koi note nahi hai.<br>＋ dabake pehla note banao ✨</p>';
  const c=id=>S.notes.filter(n=>id==='pin'?n.pin:n.b===id).length;
  const row=(id,ic,n,k,ed)=>`<div class="dr${F.b===id?' on':''}" data-a="bun" data-v="${id}"><span>${ic}</span><b>${esc(n)}</b><i>${k}</i>${ed?`<button class="ib sm" data-a="editB" data-v="${id}">✎</button>`:''}</div>`;
  $('#bl').innerHTML=row('all','🗂️','All Notes',S.notes.length)+row('pin','📌','Pinned',c('pin'))+S.bundles.map(b=>row(b.id,b.ic,b.n,c(b.id),1)).join('');
}

/* ---------- sheets ---------- */
const sheet=h=>{$('#sh').innerHTML='<div class="grab"></div>'+h;document.body.classList.add('sho')};
const closeSheet=()=>document.body.classList.remove('sho');
const closeDrawer=()=>document.body.classList.remove('dro');
const pick=cb=>{icCb=cb;sheet('<h2>Icon chuno</h2><div class="eg">'+EM.map(e=>`<button data-a="ic" data-v="${e}">${e}</button>`).join('')+'</div>')};
function bsheet(o){
  bf=o;
  sheet(`<h2>${bf.id?'Edit':'New'} Bundle</h2><div class="row"><button class="ib big" data-a="bpick">${bf.ic}</button><input id="bn" placeholder="Bundle name" value="${esc(bf.n)}"></div><div class="cls">${CL.map(c=>`<i class="cl${c===bf.c?' on':''}" data-a="bcl" data-v="${c}" style="background:${c}"></i>`).join('')}</div><div class="row"><button class="btn" data-a="bsave">Save</button>${bf.id?'<button class="btn dng" data-a="bdel">Delete</button>':''}</div>`);
}

/* ---------- editor ---------- */
function edit(n){
  cur=n;
  const st=n.k!=='note';
  $('#ti').value=n.t;$('#eic').textContent=n.ic;$('#pn').classList.toggle('on',!!n.pin);
  $('#bs').innerHTML='<option value="">📂 No bundle</option>'+S.bundles.map(b=>`<option value="${b.id}"${b.id===n.b?' selected':''}>${b.ic} ${esc(b.n)}</option>`).join('');
  $('#editor').classList.toggle('st',st);
  if(st){const x=$('#sx');x.className='';x.dataset.k=n.k;$$('.sbar .chip').forEach(c=>c.classList.remove('on'));rowsUI()}
  else{$('#body').innerHTML=n.h;$('#body').className='body f-'+n.font}
  tagsUI();$('#st').textContent='';
  document.execCommand('styleWithCSS',false,true);
  $('#editor').classList.add('open');history.pushState(1,'');
}
function sv(){
  if(!cur)return;
  cur.t=$('#ti').value;cur.ts=Date.now();
  if(cur.k==='note'){
    const b=$('#body'),t=b.textContent.trim();
    cur.h=b.innerHTML;cur.p=t.slice(0,300);
    $('#st').textContent=(t?t.split(/\s+/).length:0)+' words · auto-saved';
  }else{
    cur.p=cur.rows.filter(r=>r.v[0]).map(r=>r.v[0]+(r.v[1]?' → '+r.v[1]:'')).join(' · ').slice(0,300);
    $('#st').textContent=cur.rows.length+' entries · ⭐ '+cur.rows.filter(r=>r.s).length+' important';
  }
  save();
}
const svd=deb(sv,350);
function closeEd(){
  if(!cur)return;
  sv();
  if(!cur.t.trim()&&!cur.p&&!/<img|class="ck/.test(cur.h||''))S.notes=S.notes.filter(x=>x!==cur);
  cur=null;$('#editor').classList.remove('open');$('#fl').classList.remove('on');save();render();
}
onpopstate=closeEd;
const tagsUI=()=>{$('#etags').innerHTML=cur.tags.map(t=>`<span class="tg x" data-a="rt" data-v="${esc(t)}">#${esc(t)} ✕</span>`).join('')};
function addTag(){
  const i=$('#ta'),t=i.value.trim().replace(/^#/,'').replace(/[,\s]+$/,'').toLowerCase();
  i.value='';
  if(t&&cur&&!cur.tags.includes(t)){cur.tags.push(t);tagsUI();save()}
}

/* structured notes (one word substitute / idioms / synonym-antonym) */
const grow=t=>{t.style.height='auto';t.style.height=t.scrollHeight+'px'};
function rowsUI(){
  const f=SC[cur.k].f;
  $('#rows').innerHTML=cur.rows.map((r,i)=>`<div class="rw${r.s?' star':''}" data-i="${i}"><div class="rt"><button class="stb" data-a="star" data-v="${i}">${r.s?'★':'☆'}</button><button class="stb" data-a="sdel" data-v="${i}">✕</button></div>${f.map((l,j)=>`<label class="fb f${j}"><small>${l}</small><textarea rows="1" data-f="${j}">${esc(r.v[j]||'')}</textarea></label>`).join('')}</div>`).join('');
  $$('#rows textarea').forEach(grow);
}

/* selection-based formatting */
function selHTML(){
  const s=getSelection();if(!s.rangeCount||s.isCollapsed)return null;
  const d=document.createElement('div');d.appendChild(s.getRangeAt(0).cloneContents());return d.innerHTML;
}
function wrap(open,close){
  const h=selHTML();
  if(h===null)return toast('Pehle text select karo');
  document.execCommand('insertHTML',false,open+h+close);svd();
}
function unwrap(q){
  const s=getSelection();if(!s.rangeCount)return;
  const r=s.getRangeAt(0);
  $$(q.split(',').map(x=>'#body '+x).join(',')).forEach(e=>{if(r.intersectsNode(e))e.replaceWith(...e.childNodes)});
  svd();
}
function curSize(){
  const n=getSelection().anchorNode,e=n&&n.nodeType===3?n.parentNode:n;
  return e?parseFloat(getComputedStyle(e).fontSize)||17:17;
}
function setSize(px){
  px=Math.max(8,Math.min(96,Math.round(px)));
  document.execCommand('styleWithCSS',false,false);
  document.execCommand('fontSize',false,7);
  document.execCommand('styleWithCSS',false,true);
  $$('#body font[size="7"]').forEach(f=>{f.removeAttribute('size');f.style.fontSize=px+'px'});
  svd();
}
function palette(m){
  const p=$('#pal');
  if(p.dataset.m===m&&p.classList.contains('on')){p.classList.remove('on');return posFl()}
  p.dataset.m=m;
  const sw=(a,v)=>`<i class="cl" data-a="${a}" data-v="${v}" style="background:${v}"></i>`;
  const ch=(a,v,l)=>`<button class="chip" data-a="${a}" data-v="${v}">${l}</button>`;
  p.innerHTML=m==='fx'?FX.map(([c,l])=>ch('fx',c,l)).join(''):
    m==='fore'?PC.map(c=>sw('fc',c)).join(''):
    m==='hl'?HL.map(c=>sw('hl',c)).join('')+ch('hl','x','✕ Clear'):
    ch('sz','-2','A−')+ch('sz','2','A+')+SZ.map(n=>ch('sz','='+n,n)).join('');
  p.classList.add('on');posFl();
}
/* floating toolbar: always clamped inside the visible screen */
function posFl(){
  const f=$('#fl'),s=getSelection();
  if(!f.classList.contains('on')||!s.rangeCount)return;
  const vv=window.visualViewport,T=vv?vv.offsetTop:0,L=vv?vv.offsetLeft:0,W=vv?vv.width:innerWidth,H=vv?vv.height:innerHeight;
  f.style.maxWidth=(W-16)+'px';
  const r=s.getRangeAt(0).getBoundingClientRect(),w=f.offsetWidth,h=f.offsetHeight;
  let x=r.left+r.width/2-w/2;x=Math.max(L+8,Math.min(x,L+W-w-8));
  let y=r.bottom+34;if(y+h>T+H-8)y=r.top-h-14;
  y=Math.max(T+8,Math.min(y,T+H-h-8));
  f.style.left=x+'px';f.style.top=y+'px';
}
function updFl(){
  const f=$('#fl'),s=getSelection(),b=$('#body');
  if(cur&&cur.k==='note'&&s.rangeCount&&!s.isCollapsed&&b.contains(s.anchorNode)&&b.contains(s.focusNode)){f.classList.add('on');posFl()}
  else{f.classList.remove('on');$('#pal').classList.remove('on')}
}
/* Enter: heading/format must not carry to the next line */
function afterEnter(){
  const s=getSelection();if(!s.rangeCount)return;
  let n=s.anchorNode;if(n.nodeType===3)n=n.parentNode;
  const body=$('#body'),b=n.closest('h1,h2,blockquote,li,div,p');
  if(!b||b===body||!body.contains(b)||b.tagName==='LI')return;
  if(b.textContent.replace(/\u200b/g,'').trim()||b.querySelector('img'))return;
  let nb=b;
  if(b.classList.contains('ck'))b.classList.remove('on');
  else if(/^(H1|H2|BLOCKQUOTE)$/.test(b.tagName)){nb=document.createElement('div');nb.style.textAlign=b.style.textAlign;b.replaceWith(nb)}
  nb.innerHTML='<br>';
  const r=document.createRange();r.selectNodeContents(nb);r.collapse(true);s.removeAllRanges();s.addRange(r);
}

/* ---------- print / PDF ---------- */
function noteHTML(n){
  const bn=S.bundles.find(b=>b.id===n.b);
  const head=`<div class="ph"><h1>${n.ic} ${esc(n.t||'Untitled')}</h1><div class="pm">${[bn?esc(bn.ic+' '+bn.n):'',n.k!=='note'?SC[n.k].n:'',n.tags.map(t=>'#'+esc(t)).join(' '),new Date(n.ts).toLocaleDateString()].filter(Boolean).join('  •  ')}</div></div>`;
  if(n.k==='note')return head+`<div class="f-${n.font}">${n.h}</div>`;
  const f=SC[n.k].f;
  return head+`<table><thead><tr><th></th>${f.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${n.rows.filter(r=>r.v.some(Boolean)).map(r=>`<tr class="${r.s?'s':''}"><td>${r.s?'★':''}</td>${r.v.map(v=>`<td>${esc(v||'')}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}
function printNotes(items,name){
  $('#pr').innerHTML=items.map(n=>`<div class="pn">${noteHTML(n)}</div>`).join('');
  $$('#pr [style]').forEach(e=>{if(/255,\s*255,\s*255|white|#fff/i.test(e.style.color))e.style.color=''});
  document.title=name||'StudyNest';
  toast('Print screen me "Save as PDF" chuno');
  setTimeout(()=>window.print(),500);
}

/* ---------- actions ---------- */
const A={
  open:a=>edit(S.notes.find(n=>n.id===a.dataset.v)),
  new:()=>sheet('<h2>Naya kya banana hai?</h2><div class="acts"><button class="act" data-a="mk" data-v="note"><span>📝</span>Free note</button>'+Object.entries(SC).map(([k,v])=>`<button class="act" data-a="mk" data-v="${k}"><span>${v.ic}</span>${v.n}</button>`).join('')+'</div>'),
  mk:a=>{
    closeSheet();
    const k=a.dataset.v,n={id:uid(),k,t:'',h:'',p:'',rows:k==='note'?[]:[{v:['','',''],s:0}],ic:k==='note'?'📝':SC[k].ic,b:['all','pin'].includes(F.b)?'':F.b,tags:F.tag?[F.tag]:[],pin:0,ts:Date.now(),font:'sans'};
    S.notes.unshift(n);edit(n);setTimeout(()=>$('#ti').focus(),400);
  },
  tag:a=>{F.tag=F.tag===a.dataset.v?'':a.dataset.v;render()},
  bun:a=>{F.b=a.dataset.v;F.tag='';render();closeDrawer()},
  menu:()=>document.body.classList.add('dro'),
  scrim:()=>{closeDrawer();closeSheet()},
  themes:()=>sheet('<h2>Theme chuno</h2><div class="tgrid">'+Object.entries(TH).map(([k,[n,c]])=>`<button class="sw${S.theme===k?' on':''}" data-a="th" data-v="${k}" style="--s:${c}"><i></i>${n}</button>`).join('')+'</div>'),
  th:a=>{setTheme(a.dataset.v);closeSheet()},
  newB:()=>{closeDrawer();bsheet({id:'',n:'',ic:'📁',c:CL[0]})},
  editB:a=>{closeDrawer();bsheet({...S.bundles.find(b=>b.id===a.dataset.v)})},
  bpick:()=>{bf.n=$('#bn').value;pick(v=>{bf.ic=v;bsheet(bf)})},
  bcl:a=>{bf.n=$('#bn').value;bf.c=a.dataset.v;bsheet(bf)},
  bsave:()=>{
    bf.n=$('#bn').value.trim()||'Bundle';
    if(bf.id)Object.assign(S.bundles.find(b=>b.id===bf.id),bf);else{bf.id=uid();S.bundles.push(bf)}
    save();closeSheet();render();
  },
  bdel:()=>{
    if(!confirm('Bundle delete karein? Notes safe rahenge.'))return;
    S.bundles=S.bundles.filter(b=>b.id!==bf.id);
    S.notes.forEach(n=>{if(n.b===bf.id)n.b=''});
    if(F.b===bf.id)F.b='all';
    save();closeSheet();render();
  },
  ic:a=>icCb(a.dataset.v),
  eicon:()=>pick(v=>{cur.ic=v;$('#eic').textContent=v;save();closeSheet()}),
  back:()=>history.back(),
  pin:()=>{cur.pin=cur.pin?0:1;$('#pn').classList.toggle('on',!!cur.pin);save()},
  rt:a=>{cur.tags=cur.tags.filter(t=>t!==a.dataset.v);tagsUI();save()},
  /* per-note menu: PDF / JSON / pin / delete */
  nmenu:a=>{
    if(cur)sv();
    sel=a.dataset.v==='cur'?cur.id:a.dataset.v;
    const n=gsel();
    sheet(`<h2>${n.ic} ${esc(n.t||'Untitled')}</h2><div class="acts"><button class="act" data-a="npdf"><span>📄</span>Export PDF</button><button class="act" data-a="njson"><span>🧾</span>Export JSON</button><button class="act" data-a="npin"><span>📌</span>${n.pin?'Unpin':'Pin'}</button><button class="act" data-a="ndel"><span>🗑️</span>Delete</button></div>`);
  },
  npdf:()=>{const n=gsel();closeSheet();printNotes([n],n.t)},
  njson:()=>{
    const n=gsel(),b=S.bundles.find(x=>x.id===n.b);
    dl((n.t||'note').replace(/[^\w\u0900-\u097F]+/g,'_')+'.json',{app:'studynest',type:'note',v:1,note:n,bundle:b?{n:b.n,ic:b.ic,c:b.c}:null});
    closeSheet();toast('JSON file save ho gayi');
  },
  npin:()=>{const n=gsel();n.pin=n.pin?0:1;if(cur&&cur.id===n.id)$('#pn').classList.toggle('on',!!n.pin);save();closeSheet();render()},
  ndel:()=>{
    if(!confirm('Ye note delete karein?'))return;
    S.notes=S.notes.filter(x=>x.id!==sel);save();closeSheet();
    if(cur&&cur.id===sel)history.back();else render();
  },
  pdfAll:()=>{closeDrawer();const l=vis();if(!l.length)return toast('Export ke liye notes nahi hain');printNotes(l,$('#title').textContent)},
  bak:()=>dl('studynest-backup.json',S),
  /* formatting */
  cmd:a=>{
    const[c,v]=a.dataset.v.split(':');
    document.execCommand(c,false,c==='formatBlock'?'<'+v+'>':null);
    if(c==='removeFormat')unwrap('.fx,.hl');
    svd();
  },
  pal:a=>palette(a.dataset.v),
  fc:a=>{document.execCommand('foreColor',false,a.dataset.v);svd()},
  hl:a=>a.dataset.v==='x'?unwrap('.hl'):wrap(`<mark class="hl" style="--h:${a.dataset.v}">`,'</mark>'),
  fx:a=>wrap(`<span class="fx ${a.dataset.v}">`,'</span>'),
  sz:a=>{const v=a.dataset.v;setSize(v[0]==='='?+v.slice(1):curSize()+ +v)},
  chk:()=>{document.execCommand('insertHTML',false,'<div class="ck"><br></div>');svd()},
  font:()=>{cur.font=FN[(FN.indexOf(cur.font)+1)%FN.length];$('#body').className='body f-'+cur.font;toast('Font: '+cur.font);save()},
  /* structured notes */
  sadd:()=>{
    cur.rows.push({v:['','',''],s:0});rowsUI();sv();
    const t=$$('#rows textarea[data-f="0"]').pop();t.focus();t.scrollIntoView({block:'center',behavior:'smooth'});
  },
  star:a=>{const r=cur.rows[+a.dataset.v];r.s=r.s?0:1;a.textContent=r.s?'★':'☆';a.closest('.rw').classList.toggle('star',!!r.s);sv()},
  sdel:a=>{if(confirm('Ye entry delete karein?')){cur.rows.splice(+a.dataset.v,1);rowsUI();sv()}},
  sfil:a=>{$('#sx').classList.toggle('sfil');a.classList.toggle('on')},
  sq:a=>{$('#sx').classList.toggle('quiz');a.classList.toggle('on')}
};

/* ---------- events ---------- */
document.addEventListener('click',e=>{const a=e.target.closest('[data-a]');if(a&&A[a.dataset.a])A[a.dataset.a](a)});
document.addEventListener('mousedown',e=>{if(e.target.closest('#fl,.tb'))e.preventDefault()});
document.addEventListener('selectionchange',deb(updFl,120));
const rp=deb(posFl,50);
$('#body').addEventListener('scroll',rp,{passive:true});
if(window.visualViewport)visualViewport.addEventListener('resize',rp);
$('#body').addEventListener('input',e=>{
  if(/^insert(Paragraph|LineBreak)$/.test(e.inputType))afterEnter();
  svd();
});
$('#body').addEventListener('click',e=>{
  const t=e.target;
  if(t.classList.contains('ck')&&e.offsetX<34){t.classList.toggle('on');svd()}
  else{const h=t.closest('.hide');if(h)h.classList.toggle('show')}
});
$('#rows').addEventListener('input',e=>{
  const t=e.target;if(!t.dataset.f)return;
  cur.rows[+t.closest('.rw').dataset.i].v[+t.dataset.f]=t.value;grow(t);svd();
});
$('#ti').addEventListener('input',svd);
$('#bs').onchange=e=>{cur.b=e.target.value;save()};
$('#ta').addEventListener('input',e=>{if(/[,\s]$/.test(e.target.value))addTag()});
$('#ta').addEventListener('keydown',e=>{if(e.key==='Enter')addTag()});
$('#ta').addEventListener('blur',addTag);
$('#q').oninput=deb(e=>{F.q=e.target.value.trim();render()},150);
$('#list').addEventListener('scroll',e=>$('.top').classList.toggle('sc',e.target.scrollTop>4),{passive:true});
$('#imp').onchange=e=>{
  const f=e.target.files[0];if(!f)return;
  f.text().then(t=>{
    try{
      const d=JSON.parse(t);
      if(d.type==='note'&&d.note){
        const n={...d.note,id:uid(),ts:Date.now(),b:''};
        n.k=n.k||'note';n.rows=n.rows||[];n.tags=n.tags||[];
        if(d.bundle){let b=S.bundles.find(x=>x.n===d.bundle.n);if(!b){b={id:uid(),...d.bundle};S.bundles.push(b)}n.b=b.id}
        S.notes.unshift(n);save();render();closeDrawer();toast('Note import ho gaya ✅');
      }else if(Array.isArray(d.notes)){
        S=Object.assign(S,d);F={b:'all',tag:'',q:''};
        S.notes.forEach(n=>{n.k=n.k||'note';n.rows=n.rows||[];n.tags=n.tags||[]});
        setTheme(S.theme);save();render();closeDrawer();toast('Backup restore ho gaya ✅');
      }else throw 0;
    }catch(x){toast('Galat file')}
    e.target.value='';
  });
};

setTheme(S.theme);render();
