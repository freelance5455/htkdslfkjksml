# DoorDash Journal – Châteauguay (V2.8)

Application Android locale (hors ligne) pour consigner les offres et les livraisons. Aucune permission Android n'est demandée : pas de GPS, pas de localisation, pas de réseau.

## Fonctionnalités
- Accueil guidé : démarrage d'un dash en un toucher, temps écoulé, gains, livraisons, $/h, $/km A/R et km A/R estimés en direct.
- Ajout rapide d'une observation (livraison terminée, offre acceptée, offre refusée, attente sans offre) avec aperçu du retour estimé et du $/km.
- Journal des observations (recherche, filtres, regroupement par jour, modification, suppression avec annulation) et des dashs (modification, suppression).
- Analyses sur « Tout », 30 jours ou 7 jours : classement des magasins, zones A à D, tranches de 3 heures, jours de la semaine, dashs.
- Coût du véhicule facultatif au kilomètre et estimation du net.
- Sauvegarde et restauration JSON, export CSV, effacement des données (menu « Données »).

## Distances et $/km (comportement V2.3)
La distance est saisie à la main pour chaque observation (« Distance affichée »). Le retour est estimé à 2 × cette distance. Les gains, le $/km et les classements n'utilisent que les livraisons terminées.

## Construire l'APK
1. Ouvrir ce dossier dans Android Studio (JDK 17).
2. Laisser Gradle synchroniser le projet (`gradle/wrapper/gradle-wrapper.properties` demande Gradle 8.9).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. L'APK debug sera dans `app/build/outputs/apk/debug/app-debug.apk`.

Configuration : Android Gradle Plugin 8.7.3, compileSdk 35, targetSdk 34, minSdk 23. Version 2.8 (`versionCode 7`).

## Données
- Stockage local au WebView, mêmes clés que les versions précédentes : `ddj_chateauguay_v1` (observations), `ddj_chateauguay_dashes_v1` (dashs), `ddj_chateauguay_cost_per_km_v23` (coût/km). Une mise à jour par-dessus la V2.3 à V2.7 conserve les données.
- Les anciens champs de localisation (V2.4 à V2.7) sont conservés tels quels dans les données et les sauvegardes, mais ne sont plus utilisés. Une observation créée alors sans distance saisie affiche « — » comme $/km.
- Faites régulièrement une sauvegarde JSON et conservez-la hors du téléphone.

## Historique
- 2.1 : Résumé limité au dash actif, historique des dashs.
- 2.2 : quatre onglets, démarrage et fin de dash depuis le Résumé.
- 2.3 : date de fin de dash, statistiques enrichies, coût véhicule, sauvegarde JSON.
- 2.4 à 2.7 : essais de suivi par localisation (retirés en 2.8).
- 2.8 : retrait complet de la localisation, retour au calcul de la V2.3, nouvelle interface, correction des erreurs (voir `CORRECTIONS_V2_8.md`).
