package ca.journal.doordash;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private static final int REQ_SAVE_FILE = 4103;
  private static final int REQ_PICK_FILE = 4104;
  private static final int BACKGROUND = 0xFF0B1220;
  private static final int NAV_BACKGROUND = 0xFF0E1726;

  private WebView web;
  private String pendingSaveText;
  private ValueCallback<Uri[]> fileCallback;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    getWindow().setBackgroundDrawable(new ColorDrawable(BACKGROUND));
    getWindow().setStatusBarColor(BACKGROUND);
    getWindow().setNavigationBarColor(NAV_BACKGROUND);

    web = new WebView(this);
    web.setBackgroundColor(BACKGROUND);
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    web.setWebChromeClient(new WebChromeClient() {
      // Sans ce rappel, le champ « Restaurer une sauvegarde » n'ouvre aucun sélecteur de fichier dans la WebView.
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = callback;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(Intent.createChooser(i, "Choisir une sauvegarde"), REQ_PICK_FILE); }
        catch (RuntimeException e) { fileCallback = null; return false; }
        return true;
      }
    });
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new AppBridge(), "AndroidApp");
    setContentView(web);
    // Ne pas modifier cette URL : le stockage local (localStorage) est rattaché à cette origine.
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQ_SAVE_FILE) {
      String text = pendingSaveText;
      pendingSaveText = null;
      if (resultCode != RESULT_OK || data == null || data.getData() == null || text == null) return;
      try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
        if (os == null) throw new IOException("flux indisponible");
        os.write(text.getBytes(StandardCharsets.UTF_8));
        Toast.makeText(this, "Fichier enregistré.", Toast.LENGTH_SHORT).show();
      } catch (Exception e) {
        Toast.makeText(this, "Impossible d’enregistrer le fichier.", Toast.LENGTH_LONG).show();
      }
    } else if (requestCode == REQ_PICK_FILE) {
      if (fileCallback != null) {
        fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
        fileCallback = null;
      }
    }
  }

  private class AppBridge {
    // Les téléchargements par lien « blob: » ne fonctionnent pas dans une WebView : l'enregistrement passe par le sélecteur Android.
    @JavascriptInterface public void saveFile(String name, String mime, String text) {
      runOnUiThread(() -> {
        pendingSaveText = text;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        try { startActivityForResult(i, REQ_SAVE_FILE); }
        catch (RuntimeException e) {
          pendingSaveText = null;
          Toast.makeText(MainActivity.this, "Impossible d’ouvrir le sélecteur de fichiers.", Toast.LENGTH_LONG).show();
        }
      });
    }
  }

  // Le bouton Retour ferme d'abord une fenêtre ouverte, puis revient à l'accueil, et ne quitte l'application qu'ensuite.
  @Override public void onBackPressed() {
    if (web == null) { super.onBackPressed(); return; }
    web.evaluateJavascript("(function(){try{return !!(window.__onBack&&window.__onBack())}catch(e){return false}})()", value -> {
      if (!"true".equals(value)) MainActivity.super.onBackPressed();
    });
  }

  @Override protected void onDestroy() {
    if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
    if (web != null) { web.removeJavascriptInterface("AndroidApp"); web.destroy(); web = null; }
    super.onDestroy();
  }
}
