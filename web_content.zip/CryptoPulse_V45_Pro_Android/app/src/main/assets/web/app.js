const coins=[['BTC','Bitcoin','67420.20','+2.84%','38.4B'],['ETH','Ethereum','2516.70','+1.91%','21.7B'],['SOL','Solana','142.18','-0.72%','6.2B'],['BNB','BNB','612.40','+0.44%','3.8B'],['XRP','XRP','2.31','+3.18%','2.9B'],['ADA','Cardano','0.74','-1.02%','1.4B'],['DOGE','Dogecoin','0.18','+1.22%','1.1B'],['AVAX','Avalanche','29.44','-0.38%','0.8B'],['LINK','Chainlink','22.08','+2.06%','0.7B']];
const nav=[['index.html','⌂','خانه'],['markets.html','◈','بازار'],['spot.html','⇄','معامله'],['futures.html','⇅','Futures'],['assets.html','◫','دارایی'],['profile.html','◉','پروفایل']];
const moreNav=[['analysis.html','⌁','تحلیل'],['strategies.html','◎','استراتژی'],['settings.html','⚙','تنظیمات']];
const state=()=>{try{const d=JSON.parse(localStorage.getItem('cp_state'))||{};return {balance:+(d.balance??10000),history:Array.isArray(d.history)?d.history:[],open:d.open||null,spot:Array.isArray(d.spot)?d.spot:[],holdings:d.holdings&&typeof d.holdings==='object'?d.holdings:{}}}catch(e){return{balance:10000,history:[],open:null,spot:[],holdings:{}}}};
function saveState(s){localStorage.setItem('cp_state',JSON.stringify(s))}
function navHTML(active){const items=nav.map(x=>`<a class="${x[0]===active?'active':''}" href="${x[0]}"><span>${x[1]}</span>${x[2]}</a>`).join('');const moreActive=moreNav.some(x=>x[0]===active);return `<nav class="nav">${items}<button class="nav-more ${moreActive?'active':''}" onclick="toggleMoreNav()"><span>•••</span>بیشتر</button></nav><div id="moreNavSheet" class="more-sheet"><div class="more-sheet-card"><div class="section-head"><b>دسترسی بیشتر</b><button class="btn" onclick="toggleMoreNav()">بستن</button></div>${moreNav.map(x=>`<a href="${x[0]}"><span>${x[1]}</span><b>${x[2]}</b></a>`).join('')}</div></div>`}
function toggleMoreNav(){document.getElementById('moreNavSheet')?.classList.toggle('show')}
function lockHTML(){return `<div id="lockScreen" class="lock-screen"><div class="lock-card"><div class="lock-logo">CP</div><div class="eyebrow">CRYPTOPULSE LOCK</div><h2>برنامه قفل است</h2><p class="muted">برای ورود، رمز محلی برنامه را وارد کن.</p><input id="unlockPass" class="lock-input" type="password" placeholder="رمز ورود" autocomplete="current-password" onkeydown="if(event.key==='Enter')unlockApp()"><button class="btn primary wide" onclick="unlockApp()">باز کردن برنامه</button><div id="lockMsg" class="footer-note"></div></div></div>`}
function lockApp(){sessionStorage.removeItem('cp_unlocked');document.getElementById('lockScreen')?.classList.add('show');setTimeout(()=>document.getElementById('unlockPass')?.focus(),50)}
function unlockApp(){const prefs=JSON.parse(localStorage.getItem('cp_settings')||'{}');const input=document.getElementById('unlockPass');const msg=document.getElementById('lockMsg');if(!prefs.pass){sessionStorage.setItem('cp_unlocked','1');document.getElementById('lockScreen')?.classList.remove('show');return}if(input?.value===prefs.pass){sessionStorage.setItem('cp_unlocked','1');document.getElementById('lockScreen')?.classList.remove('show');if(msg)msg.textContent=''}else if(msg){msg.textContent='رمز ورود صحیح نیست.'}}
function applyAppLock(){const prefs=JSON.parse(localStorage.getItem('cp_settings')||'{}');if(prefs.pass && sessionStorage.getItem('cp_unlocked')!=='1'){document.body.insertAdjacentHTML('beforeend',lockHTML());setTimeout(()=>document.getElementById('unlockPass')?.focus(),60)}}
function layout(title,subtitle,body,active){document.body.classList.add('mobile-app');const prefs=JSON.parse(localStorage.getItem('cp_settings')||'{}');document.documentElement.dataset.theme=prefs.theme||'Dark Pro';document.body.innerHTML=`<div class="app"><header class="top"><div class="brand"><div class="logo">CP</div><div><b>CryptoPulse</b><small>${subtitle}</small></div></div><div class="top-actions"><span id="dataStatus" class="live">● CONNECTING</span><span class="pill">PAPER TRADING</span><span class="pill version-pill">V45 PRO MOBILE</span>${prefs.pass?'<button class="btn" onclick="lockApp()">قفل</button>':''}</div></header>${body}<div id="toast" class="toast"></div></div>${navHTML(active)}`;applyAppLock()}

document.addEventListener('touchstart',()=>{}, {passive:true});
window.addEventListener('pageshow',()=>{document.documentElement.style.setProperty('--vh',`${window.innerHeight*0.01}px`)});
function toast(t){const e=document.getElementById('toast');if(!e)return;e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1800)}
function setDataStatus(ok){const e=document.getElementById('dataStatus');if(!e)return;e.textContent=ok?'● LIVE DATA':'● DEMO DATA';e.className=ok?'live':'pill'}
function coinCards(list=coins){return list.map(c=>`<a href="asset.html?symbol=${c[0]}" class="coin" style="text-decoration:none;color:inherit"><div class="coin-left"><div class="coin-icon">${c[0][0]}</div><div><b>${c[0]}</b><div class="muted">${c[1]}</div></div></div><div class="coin-price"><b>${c[2]}</b><div class="${c[3][0]=='+'?'up':'down'}" style="font-size:11px">${c[3]}</div></div></a>`).join('')}
function getCoin(sym){return coins.find(c=>c[0]===sym)||coins[0]}
function money(n){return Number(n).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}
function chartSVG(seed=1){let pts=[];for(let i=0;i<48;i++){let y=150-Math.sin(i*.48+seed)*30-i*1.2+Math.sin(i*1.8)*8;pts.push(`${i*(800/47)},${y}`)}return `<svg viewBox="0 0 800 260" preserveAspectRatio="none"><defs><linearGradient id="g" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#20dfbf"/><stop offset="1" stop-color="#20dfbf" stop-opacity="0"/></linearGradient></defs><g>${[40,90,140,190,240].map(y=>`<line class="chart-grid" x1="0" y1="${y}" x2="800" y2="${y}"/>`).join('')}</g><polyline class="chart-line" points="${pts.join(' ')}"/><polygon class="chart-fill" points="${pts.join(' ')} 800,260 0,260"/></svg>`}
async function api(path){const r=await fetch('https://api.binance.com'+path,{cache:'no-store'});if(!r.ok)throw new Error('api');return r.json()}
async function ticker(sym){try{const d=await api('/api/v3/ticker/24hr?symbol='+sym+'USDT');setDataStatus(true);return {price:+d.lastPrice,change:+d.priceChangePercent,volume:+d.quoteVolume}}catch(e){setDataStatus(false);const c=getCoin(sym);return {price:+c[2],change:parseFloat(c[3]),volume:parseFloat(c[4])}}}
async function candles(sym,interval='1h',limit=80){return api(`/api/v3/klines?symbol=${sym}USDT&interval=${interval}&limit=${limit}`)}
async function depth(sym,limit=10){return api(`/api/v3/depth?symbol=${sym}USDT&limit=${limit}`)}
async function livePrice(sym){return (await ticker(sym)).price}
function initLivePrice(sym,id){const update=()=>livePrice(sym).then(p=>{const e=document.getElementById(id);if(e)e.textContent=money(p)}).catch(()=>{});update();setInterval(update,10000)}
function formatCompact(n){if(n>=1e9)return (n/1e9).toFixed(2)+'B';if(n>=1e6)return (n/1e6).toFixed(2)+'M';if(n>=1e3)return (n/1e3).toFixed(2)+'K';return Number(n||0).toFixed(2)}
function favorites(){try{return JSON.parse(localStorage.getItem('cp_favorites')||'[]')}catch{return[]}}
function toggleFavorite(sym){let a=favorites();a=a.includes(sym)?a.filter(x=>x!==sym):[...a,sym];localStorage.setItem('cp_favorites',JSON.stringify(a));return a}
function isFavorite(sym){return favorites().includes(sym)}
function saveAlert(sym,target,dir='above'){let a=[];try{a=JSON.parse(localStorage.getItem('cp_alerts')||'[]')}catch{};a.push({id:Date.now(),sym,target:+target,dir,active:true});localStorage.setItem('cp_alerts',JSON.stringify(a));return a}
function checkAlerts(sym,price){let a=[];try{a=JSON.parse(localStorage.getItem('cp_alerts')||'[]')}catch{};let changed=false;a=a.map(x=>{if(x.active&&x.sym===sym&&((x.dir==='above'&&price>=x.target)||(x.dir==='below'&&price<=x.target))){x.active=false;changed=true;toast(`هشدار ${sym}: قیمت به ${money(x.target)} رسید`)}return x});if(changed)localStorage.setItem('cp_alerts',JSON.stringify(a))}


function profileState(){try{const d=JSON.parse(localStorage.getItem('cp_profile')||'{}');return {name:d.name||'CryptoPulse User',email:d.email||'',ref:d.ref||'',joined:d.joined||new Date().toLocaleDateString('fa-IR'),referrals:+(d.referrals||0),reward:+(d.reward||0),tier:d.tier||'Starter'}}catch(e){return {name:'CryptoPulse User',email:'',ref:'',joined:new Date().toLocaleDateString('fa-IR'),referrals:0,reward:0,tier:'Starter'}}}
function saveProfile(p){localStorage.setItem('cp_profile',JSON.stringify(p))}
function makeReferral(){const p=profileState();if(!p.ref)p.ref='CP'+Math.random().toString(36).slice(2,8).toUpperCase();saveProfile(p);return p.ref}
function copyText(t){navigator.clipboard?.writeText(t).then(()=>toast('کپی شد')).catch(()=>toast('کپی خودکار در دسترس نیست'))}
function profileStats(){const p=profileState(),s=state();return {trades:(s.history||[]).length+(s.spot||[]).length, pnl:(s.history||[]).reduce((a,x)=>a+(+x.pnl||0),0),referrals:p.referrals,reward:p.reward}}


function portfolioSummary(){
  const s=state(), holdings=s.holdings||{}; let total=0, assets=0;
  Object.entries(holdings).forEach(([sym,v])=>{const qty=+(v||0); if(qty>0){assets++; total+=qty*(getCoin(sym)?.[2]||0)}});
  return {cash:+s.balance||0,assets,total,history:(s.history||[]).length+(s.spot||[]).length};
}
function renderHomeSnapshot(){
  const el=document.getElementById('homeSnapshot'); if(!el)return;
  const p=portfolioSummary();
  el.innerHTML=`<div class="snapshot-card"><span>Paper Balance</span><b>${money(p.cash)} USDT</b><small>${p.history} معامله ثبت‌شده</small></div><div class="snapshot-card"><span>دارایی‌ها</span><b>${p.assets}</b><small>دارایی دارای موجودی</small></div><div class="snapshot-card"><span>ارزش تقریبی</span><b>${money(p.cash+p.total)} USDT</b><small>بر پایه قیمت‌های نمایشی</small></div>`;
}
function initDashboard(){
  const render=async()=>{
    const d=await ticker('BTC');
    const price=document.getElementById('btcPrice'); if(price)price.textContent=money(d.price);
    const ch=document.getElementById('btcChange'); if(ch){ch.textContent=(d.change>=0?'+':'')+d.change.toFixed(2)+'%';ch.className=d.change>=0?'up':'down'}
    const cc=document.getElementById('btcChangeCard'); if(cc){cc.textContent=(d.change>=0?'+':'')+d.change.toFixed(2)+'% امروز';cc.className=d.change>=0?'up':'down'}
    const vol=document.getElementById('btcVolume'); if(vol)vol.textContent=formatCompact(d.volume);
    const st=document.getElementById('syncTime'); if(st)st.textContent=new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    checkAlerts('BTC',d.price);
  };
  render(); setInterval(render,10000);
  renderWatchlist();
  renderHomeSnapshot();
}
function renderWatchlist(){
  const box=document.getElementById('watchlist'), empty=document.getElementById('watchEmpty'); if(!box)return;
  const fav=favorites(); const list=coins.filter(c=>fav.includes(c[0]));
  box.innerHTML=list.length?coinCards(list.slice(0,6)) : ''; if(empty)empty.style.display=list.length?'none':'block';
}

function calcRSI(values, period=14){if(values.length<=period)return 50;let gains=0,losses=0;for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>=0)gains+=d;else losses-=d}let avgG=gains/period,avgL=losses/period;for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];avgG=((avgG*(period-1))+Math.max(d,0))/period;avgL=((avgL*(period-1))+Math.max(-d,0))/period}if(avgL===0)return 100;return 100-(100/(1+avgG/avgL))}
function calcEMA(values,period){const k=2/(period+1);let ema=values[0];for(let i=1;i<values.length;i++)ema=values[i]*k+ema*(1-k);return ema}
function calcMACD(values){const fast=calcEMA(values.slice(-60),12),slow=calcEMA(values.slice(-60),26);const macd=fast-slow;return {value:macd,signal:macd*0.88}}
function volatility(values){if(values.length<2)return 0;const r=[];for(let i=1;i<values.length;i++)r.push(Math.log(values[i]/values[i-1]));const avg=r.reduce((a,b)=>a+b,0)/r.length;return Math.sqrt(r.reduce((a,b)=>a+(b-avg)**2,0)/r.length)*100}
