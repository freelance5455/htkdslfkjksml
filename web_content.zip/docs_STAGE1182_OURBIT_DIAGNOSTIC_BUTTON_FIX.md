# Stage 1182 — Ourbit Diagnostic Button Fix

Root cause: the Stage 1180/1181 diagnostic executed 7 HTTP requests sequentially, while each request could take up to 12 seconds. The WebView bridge promise timed out after 25 seconds, so the button appeared to do nothing even though Android could still be running the requests.

Fixes:
- Run the 7 public Ourbit diagnostic requests in parallel.
- Bound each diagnostic result to 13 seconds.
- Increase the JS bridge wait to 45 seconds.
- Keep all market data real; no synthetic values.
- Version 12.3.2 / versionCode 124.
