# ÄNZÖ PLUS: no custom ProGuard rules required.
