ÄNZÖ PLUS — Projeto Android corrigido

O index.html principal está também na raiz deste ZIP para ferramentas que procuram o arquivo diretamente na raiz.

Para Android Studio, o arquivo usado pelo aplicativo está em:
app/src/main/assets/index.html

O MainActivity carrega o conteúdo local usando WebViewAssetLoader.

Nome do app: ÄNZÖ PLUS
Pacote: com.anzo.plus
Compatível com Android 10+
