package com.sisterai.appai;

// Splash Activity placeholder