# Divine Earn App — Android Studio Project

This project wraps the current Divine Earn web prototype in a native Android WebView so it can be opened and built in Android Studio.

## Open and build
1. Install Android Studio.
2. Open this folder: `DivineEarnAndroid`.
3. Let Android Studio download/sync the Gradle and Android SDK components it requests.
4. Select the `app` run configuration and an emulator or connected Android phone.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will normally be under `app/build/outputs/apk/debug/`.

## Included prototype features
- Home dashboard
- Tap Challenge
- Quiz Challenge
- Demo rewarded-ad button
- Local coin balance and transaction history
- Wallet screen
- Withdrawal placeholder
- Profile screen
- Admin demo

## Important production work
The current ad reward and withdrawal flows are simulations. Before publishing, add a secure backend, authentication, server-side reward validation, anti-fraud controls, an approved rewarded-ad SDK, a verified payout provider, privacy/terms documents, and store-compliant disclosures.
