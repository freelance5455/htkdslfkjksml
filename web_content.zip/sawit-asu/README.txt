sawit asu.io
============
Cara main: buka index.html di browser (Chrome/Firefox/Edge). Tidak perlu internet.

Kontrol
- Mouse / sentuh layar : arahkan cacing
- Tahan klik kiri / spasi / tombol SPRINT : sprint (skor TIDAK berkurang)
- Makan titik warna untuk tumbuh. Tabrakkan kepala musuh ke badanmu agar mereka kalah.
- Menabrak badan cacing lain atau dinding merah = kalah.

Bot saling bunuh: bot memotong jalan di depan kepala lawan, sprint saat mengejar,
menghindari badan & dinding, dan menjatuhkan makanan saat kalah.
