package com.posmovil.android;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.*;

public class MainActivity extends Activity {
    WebView web;
    ExecutorService printerExecutor = Executors.newSingleThreadExecutor();
    SharedPreferences prefs;
    static final int REQ_BT=20, CREATE_BACKUP=30, OPEN_BACKUP=31;
    String pendingRestoreCallback="";

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("pos",MODE_PRIVATE); setupWeb(); }
    void setupWeb(){
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"Android");
        web.loadUrl("file:///android_asset/index.html");
    }
    void btPermission(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT);
    }
    class Bridge {
        @JavascriptInterface public void choosePrinter(){ runOnUiThread(()->showPrinters()); }
        @JavascriptInterface public String getPrinterName(){ return prefs.getString("printer_name",""); }
        @JavascriptInterface public void backup(String json){ runOnUiThread(()->createBackup(json)); }
        @JavascriptInterface public void restore(){ runOnUiThread(()->openBackup()); }
        @JavascriptInterface public void printTicket(String json){ print(json); }
    }
    void showPrinters(){
        btPermission();
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){ toast("Concede permiso de Bluetooth y vuelve a intentar."); return; }
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter(); if(a==null){toast("Este teléfono no tiene Bluetooth.");return;}
        if(!a.isEnabled()){ startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return; }
        Set<BluetoothDevice> devices=a.getBondedDevices(); final ArrayList<BluetoothDevice> list=new ArrayList<>(devices);
        if(list.isEmpty()){toast("Primero vincula la impresora en Ajustes > Bluetooth.");return;}
        String[] names=new String[list.size()]; for(int i=0;i<list.size();i++) names[i]=list.get(i).getName()+"\n"+list.get(i).getAddress();
        new AlertDialog.Builder(this).setTitle("Seleccionar impresora").setItems(names,(d,w)->{BluetoothDevice dev=list.get(w);prefs.edit().putString("printer_addr",dev.getAddress()).putString("printer_name",dev.getName()).apply(); web.evaluateJavascript("window.onPrinterSelected && window.onPrinterSelected('"+js(dev.getName())+"')",null); toast("Impresora seleccionada: "+dev.getName());}).setNegativeButton("Cancelar",null).show();
    }
    void createBackup(String json){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE,"POS_backup_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".json"); pendingJson=json; startActivityForResult(i,CREATE_BACKUP);
    }
    String pendingJson="";
    void openBackup(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,OPEN_BACKUP); }
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data); if(c!=RESULT_OK||data==null)return; try{
        Uri u=data.getData(); if(r==CREATE_BACKUP){try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(pendingJson.getBytes(StandardCharsets.UTF_8));} toast("Copia guardada correctamente.");}
        else if(r==OPEN_BACKUP){String json;try(InputStream in=getContentResolver().openInputStream(u)){json=new String(in.readAllBytes(),StandardCharsets.UTF_8);} final String safe=JSONObject.quote(json); new AlertDialog.Builder(this).setTitle("Restaurar copia").setMessage("Se reemplazarán los datos actuales por los de esta copia. ¿Continuar?").setPositiveButton("Restaurar",(d,w)->web.evaluateJavascript("window.restoreFromAndroid && window.restoreFromAndroid("+safe+")",null)).setNegativeButton("Cancelar",null).show();}
    }catch(Exception e){toast("No se pudo completar la operación: "+e.getMessage());}}
    void print(String json){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){runOnUiThread(()->toast("Concede permiso de Bluetooth."));return;}
        String addr=prefs.getString("printer_addr",""); if(addr.isEmpty()){runOnUiThread(()->showPrinters());return;}
        printerExecutor.execute(()->{try{
            BluetoothDevice dev=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr); BluetoothSocket sock=dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")); sock.connect(); OutputStream out=sock.getOutputStream();
            JSONObject root=new JSONObject(json); JSONObject sale=root.getJSONObject("sale"); JSONObject cfg=root.optJSONObject("config"); String text=receipt(sale,cfg); out.write(new byte[]{0x1B,0x40}); out.write(text.getBytes(StandardCharsets.UTF_8)); out.write(new byte[]{0x0A,0x0A,0x0A,0x1D,0x56,0x00}); out.flush(); sock.close(); runOnUiThread(()->toast("Ticket enviado a la impresora."));
        }catch(Exception e){runOnUiThread(()->toast("Error de impresión. Verifica que la impresora esté vinculada y encendida."));}}
        );
    }
    String receipt(JSONObject sale,JSONObject cfg)throws Exception{
        int width=(cfg!=null&&cfg.optInt("paperWidth",58)==80)?48:32; StringBuilder s=new StringBuilder(); String biz=cfg!=null?cfg.optString("businessName",""):"POS Móvil Android"; String foot=cfg!=null?cfg.optString("footerMsg",""):"Gracias por su compra";
        s.append(center(biz,width)).append("\n"); s.append("--------------------------------\n"); s.append("Fecha: ").append(sale.optString("date","")).append("\n"); if(!sale.optString("customer","").isEmpty())s.append("Cliente: ").append(sale.optString("customer","")).append("\n"); s.append("--------------------------------\n"); JSONArray items=sale.getJSONArray("items"); for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i); String name=it.optString("name",""); double qty=it.optDouble("qty",0), price=it.optDouble("price",0); s.append(name).append("\n"); s.append(String.format(Locale.US,"  %.2f x $%.2f = $%.2f\n",qty,price,qty*price));} s.append("--------------------------------\n"); s.append(String.format(Locale.US,"TOTAL: $%.2f\n",sale.optDouble("total",0))); s.append("Pago: ").append(sale.optString("paymentMethod","")).append("\n"); if(sale.has("change"))s.append(String.format(Locale.US,"Cambio: $%.2f\n",sale.optDouble("change",0))); s.append("\n").append(center(foot,width)).append("\n"); return s.toString();
    }
    String center(String x,int w){if(x==null)x="";if(x.length()>=w)return x;int n=(w-x.length())/2;return " ".repeat(Math.max(0,n))+x;}
    String js(String x){return x.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");}
    void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){printerExecutor.shutdownNow();super.onDestroy();}
}
