VR KAMERA – VYTVORENIE APK CEZ GITHUB ACTIONS

Tento projekt obsahuje Android aplikáciu, ktorá zobrazuje VR Kameru vo WebView
a vyžiada si povolenie na používanie kamery.

POSTUP – BEZ ANDROID STUDIA A BEZ GRADLE NA TVOJOM MACU

1. Rozbaľ tento ZIP.
2. Prihlás sa na https://github.com/ a vytvor nové repository (napr. vr-kamera).
   Pri vytváraní môže zostať prázdne – nepridávaj README ani .gitignore.
3. V repository klikni Add file → Upload files.
4. Nahraj VŠETOK OBSAH rozbaleného priečinka priamo do hlavného priečinka
   repository. Dôležité: nahraj aj skrytý priečinok .github.
   Na Macu zobrazíš skryté súbory vo Finderi skratkou Cmd + Shift + bodka.
5. Klikni Commit changes.
6. Otvor kartu Actions. Vyber „Build APK“.
7. Klikni Run workflow → Run workflow (ak sa build nespustil automaticky).
8. Počkaj, kým bude zostavenie označené zelenou fajkou.
9. Otvor dokončený beh a v časti Artifacts stiahni „vr-kamera-apk“.
10. Stiahnutý Artifact je ZIP. Rozbaľ ho – vo vnútri je app-debug.apk.
11. Pošli APK do Android telefónu, otvor ho a povoľ inštaláciu z daného zdroja,
    ak sa na to Android opýta. Pri prvom spustení povoľ prístup ku kamere.

ČO JE POTREBNÉ NA GITHUBE

- Repository musí obsahovať priečinok .github/workflows/build.yml.
- Súbor build.yml automaticky nastaví Java 17, Android SDK a Gradle 8.7.
- Tvoj Mac nemusí mať Android Studio ani Android SDK.

POZNÁMKY

- Vytvára sa debug APK na testovanie a ručnú inštaláciu, nie na Google Play.
- Minimálna verzia Androidu je Android 7.0 (API 24).
- Kamera funguje po udelení povolenia Androidom.
- APK je určené pre Android; nie je to iOS aplikácia.
