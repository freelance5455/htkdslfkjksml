/* native-shell: no pull-to-refresh, Android Back support, offline/update/install notices. Plain ES5, no dependencies.
   Optional config before load: window.NATIVE_CFG = { wrapGo:'go', home:'home', navButtons:'#nav button[data-view]', homeButton:'[data-view=home]', activeAttr:'data-view' } */
(function () {
  'use strict';
  var doc = document, root = doc.documentElement, cfg = window.NATIVE_CFG || {};
  var fa = /^fa|^ar|^ur/i.test(root.lang || '');
  var STR = fa ? { off: 'اینترنت قطع است؛ برنامه همچنان کار می‌کند.', on: 'دوباره آنلاین شدید', upd: 'نسخه‌ی جدید آماده است', reload: 'بارگذاری', inst: 'نصب برنامه روی دستگاه', yes: 'نصب', no: 'بعداً' }
                 : { off: 'You are offline — the app keeps working.', on: 'Back online', upd: 'A new version is ready', reload: 'Reload', inst: 'Install this app on your device', yes: 'Install', no: 'Later' };
  var ua = navigator.userAgent || '';
  if (/Android/i.test(ua)) root.classList.add('nsh-android');
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { } return null; }

  /* ---------- toasts ---------- */
  var box;
  function toast(msg, o) {
    o = o || {};
    if (!box) { box = doc.createElement('div'); box.className = 'nsh-toasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); doc.body.appendChild(box); }
    var el = doc.createElement('div'); el.className = 'nsh-toast';
    var s = doc.createElement('span'); s.textContent = msg; el.appendChild(s);
    (o.actions || []).forEach(function (a) { var b = doc.createElement('button'); b.type = 'button'; b.textContent = a.label; b.onclick = function () { el.remove(); a.fn && a.fn(); }; el.appendChild(b); });
    box.appendChild(el);
    if (o.ms !== 0) setTimeout(function () { el.remove(); }, o.ms || 3200);
    return el;
  }
  window.nshToast = toast;

  /* ---------- pull-to-refresh guard ---------- */
  var sy = 0, multi = false;
  doc.addEventListener('touchstart', function (e) { multi = e.touches.length > 1; if (e.touches.length === 1) sy = e.touches[0].clientY; }, { passive: true });
  doc.addEventListener('touchmove', function (e) {
    if (multi || e.touches.length !== 1) return;
    var dy = e.touches[0].clientY - sy; if (dy <= 0) return;
    var t = e.target, tag = t && t.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    for (var el = t; el && el !== doc.body && el !== root; el = el.parentElement) {
      if (el.scrollTop > 0) return;                         // something inside can still scroll up -> let it
    }
    var se = doc.scrollingElement || root; if (se.scrollTop > 0) return;
    if (e.cancelable) e.preventDefault();
  }, { passive: false });
  if (root.classList.contains('nsh-android')) {
    var nudge = function () { var se = doc.scrollingElement || root; if (se.scrollTop < 1 && se.scrollHeight > window.innerHeight + 1) window.scrollTo(0, 1); };
    window.addEventListener('scroll', function () { if ((window.pageYOffset || 0) < 1) nudge(); }, { passive: true });
    window.addEventListener('load', function () { setTimeout(nudge, 60); }); window.addEventListener('resize', nudge);
  }
  // pinch / double-tap zoom stays available for accessibility; only the iOS gesture* events are stopped inside canvases
  doc.addEventListener('contextmenu', function (e) { if (e.target && /^(IMG|CANVAS|VIDEO)$/.test(e.target.tagName) && 'ontouchstart' in window) e.preventDefault(); });

  /* ---------- Android Back / browser history ---------- */
  var stack = [], popping = false, ready = false, current = null;
  function startHistory() {
    try { history.replaceState({ nsh: 'base' }, ''); history.pushState({ nsh: 1 }, ''); ready = true; } catch (e) { return; }
    window.addEventListener('popstate', function (e) {
      var st = e.state || {};
      var m = doc.querySelector('.modal.show,.modal.open,dialog[open],[role=dialog]:not([hidden])');
      if (m && cfg.closeModal) { try { cfg.closeModal(m); } catch (x) { } try { history.pushState({ nsh: 1 }, ''); } catch (x) { } return; }
      if (st.nsh === 'base') { if (stack.length) { try { history.pushState({ nsh: 1 }, ''); } catch (x) { } goBack(); } else { try { history.back(); } catch (x) { } } return; }
      goBack();
    });
  }
  function goBack() {
    if (!stack.length) return;
    stack.pop(); var prev = stack.length ? stack[stack.length - 1] : (cfg.home || null);
    popping = true; try { cfg.navTo && cfg.navTo(prev); } finally { if (cfg.wrapGo) popping = false; }
    current = prev;
  }
  function visit(id) {
    if (popping || !ready || id == null || id === current) { current = popping ? current : id; return; }
    if (id === (cfg.home || null)) { stack = []; } else { stack.push(id); }
    current = id;
    try { history.pushState({ nsh: 1 }, ''); } catch (e) { }
  }
  function initNav() {
    if (cfg.wrapGo && typeof window[cfg.wrapGo] === 'function') {
      var orig = window[cfg.wrapGo];
      cfg.navTo = function (id) { orig.call(window, id || cfg.home); };
      window[cfg.wrapGo] = function (id) { var r = orig.apply(this, arguments); try { visit(id); } catch (e) { } return r; };
      current = cfg.home || null; startHistory();
    } else if (cfg.navButtons) {
      var btns = doc.querySelectorAll(cfg.navButtons); if (!btns.length) return;
      var key = function (b) { return b.id || b.getAttribute(cfg.activeAttr || 'data-view') || ('i' + [].indexOf.call(btns, b)); };
      var isOn = function (b) { return b.getAttribute('aria-current') === 'page' || b.classList.contains('active'); };
      cfg.navTo = function (id) {
        var bb = cfg.backButton && doc.querySelector(cfg.backButton);
        if (bb) { bb.click(); } else { var t = null; [].forEach.call(btns, function (b) { if (key(b) === (id || cfg.home)) t = b; }); if (t) t.click(); }
        setTimeout(function () { popping = false; }, 60);
      };
      var mo = new MutationObserver(function () { [].forEach.call(btns, function (b) { if (isOn(b)) visit(key(b)); }); });
      [].forEach.call(btns, function (b) { mo.observe(b, { attributes: true, attributeFilter: ['aria-current', 'class'] }); });
      [].forEach.call(btns, function (b) { if (isOn(b)) current = key(b); }); if (!current) current = cfg.home || key(btns[0]);
      startHistory();
    }
  }

  /* ---------- connectivity, updates, install ---------- */
  var off;
  function setOff(v, quiet) {
    if (!off) { off = doc.createElement('div'); off.className = 'nsh-off'; off.setAttribute('role', 'status'); doc.body.appendChild(off); }
    off.textContent = STR.off; off.classList.toggle('show', v);
    if (!v && !quiet) toast(STR.on, { ms: 2000 });
  }
  window.addEventListener('offline', function () { setOff(true); });
  window.addEventListener('online', function () { setOff(false); });
  if (navigator.onLine === false) setOff(true, true);

  if ('serviceWorker' in navigator) {
    var had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!had) { had = true; return; }
      toast(STR.upd, { ms: 0, actions: [{ label: STR.reload, fn: function () { location.reload(); } }] });
    });
  }
  var standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault(); if (standalone) return;
    var last = Number(ls('nsh_inst') || 0); if (Date.now() - last < 14 * 864e5) return;
    setTimeout(function () {
      toast(STR.inst, { ms: 12000, actions: [{ label: STR.yes, fn: function () { try { e.prompt(); } catch (x) { } } }, { label: STR.no, fn: function () { ls('nsh_inst', String(Date.now())); } }] });
    }, 6000);
  });

  function init() { initNav(); }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', function () { setTimeout(init, 0); }); else setTimeout(init, 0);
})();
