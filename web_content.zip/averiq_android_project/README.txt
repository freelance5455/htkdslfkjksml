averiq Android app project

This is an Android Studio project wrapping the existing Personal Wardrobe app in an Android WebView. The launcher/app name is averiq.

IMPORTANT:
- This ZIP is Android source code, NOT a compiled APK.
- It has not been built or tested on a device in this environment.
- To build an APK, open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).
- Android Studio will produce the APK under app/build/outputs/apk/debug/app-debug.apk.
- The wardrobe uses browser storage inside the app. Do not clear app storage if you want to retain data; use the app's Backup screen regularly.

No network permission or remote service is required.
