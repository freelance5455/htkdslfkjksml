
const KEY='mathscore14_complete_v3';
let store=JSON.parse(localStorage.getItem(KEY)||'null')||{activeId:'c1',classes:[{id:'c1',name:'JHS 2A',subject:'Mathematics',year:'2026/2027',term:'First Term',max:10,students:[]}]};
let editingId=null;
function save(){localStorage.setItem(KEY,JSON.stringify(store))}
function active(){return store.classes.find(c=>c.id===store.activeId)||store.classes[0]}
function ensureWeekMaxes(c){
 if(!c)return;
 const fallback=Math.max(1,Number(c.max)||10);
 if(!Array.isArray(c.weekMaxes))c.weekMaxes=Array(14).fill(fallback);
 for(let i=0;i<14;i++)c.weekMaxes[i]=Math.max(1,Number(c.weekMaxes[i])||fallback);
}
function getWeekMax(c,w){ensureWeekMaxes(c);return c.weekMaxes[w-1]}
function setWeekMax(value){
 const c=active(),w=Number(document.getElementById('weekSelect').value||1),n=Number(value);
 if(!c||!isFinite(n)||n<=0){renderScores();return}
 ensureWeekMaxes(c);c.weekMaxes[w-1]=n;save();render();
}
function show(id){document.querySelectorAll('main section').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('active'));document.getElementById('n-'+id).classList.add('active');render()}
function openClassModal(id=null){
 editingId=id;const c=id?store.classes.find(x=>x.id===id):null;
 document.getElementById('modalTitle').textContent=id?'Edit Class':'Add Class';
 document.getElementById('newClass').value=c?c.name:'';
 document.getElementById('newSubject').value=c?c.subject:'';
 document.getElementById('newYear').value=c?c.year:(active()?.year||'2026/2027');
 document.getElementById('newTerm').value=c?c.term:'First Term';
 document.getElementById('newMax').value=c?c.max:(active()?.max||10);
 document.getElementById('modal').classList.remove('hidden');document.getElementById('modal').style.display='flex';
 setTimeout(()=>document.getElementById('newClass').focus(),100);
}
function closeModal(){const m=document.getElementById('modal');m.classList.add('hidden');m.style.display='none';editingId=null}
function saveClass(){
 const name=document.getElementById('newClass').value.trim(),subject=document.getElementById('newSubject').value.trim();
 if(!name||!subject){alert('Enter both class and subject.');return}
 if(editingId){
  const c=store.classes.find(x=>x.id===editingId);c.name=name;c.subject=subject;c.year=document.getElementById('newYear').value.trim()||'2026/2027';c.term=document.getElementById('newTerm').value;c.max=Math.max(1,Number(document.getElementById('newMax').value)||10);ensureWeekMaxes(c);
 }else{
  const c={id:'c'+Date.now(),name,subject,year:document.getElementById('newYear').value.trim()||'2026/2027',term:document.getElementById('newTerm').value,max:Math.max(1,Number(document.getElementById('newMax').value)||10),weekMaxes:Array(14).fill(Math.max(1,Number(document.getElementById('newMax').value)||10)),students:[]};
  store.classes.push(c);store.activeId=c.id;
 }
 save();closeModal();show('home');
}
function switchClass(id){store.activeId=id;save();render()}
function deleteClass(id){if(store.classes.length===1){alert('You must keep at least one class.');return}const c=store.classes.find(x=>x.id===id);if(confirm('Delete '+c.name+' · '+c.subject+' and all its records?')){store.classes=store.classes.filter(x=>x.id!==id);if(store.activeId===id)store.activeId=store.classes[0].id;save();render()}}
function renderClassList(){let h='';store.classes.forEach(c=>{let badge=(c.name.match(/\d+/)||['C'])[0];h+='<div class="class-item '+(c.id===store.activeId?'active':'')+'"><div class="class-info"><div class="mini">'+esc(badge)+'</div><div><div class="class-name">'+esc(c.name)+' · '+esc(c.subject)+'</div><div class="small">'+c.students.length+' students · '+esc(c.year)+' · '+esc(c.term)+'</div></div></div><div style="display:flex;gap:6px"><button class="secondary" onclick="switchClass(\''+c.id+'\')">'+(c.id===store.activeId?'Selected':'Open')+'</button><button class="secondary" onclick="openClassModal(\''+c.id+'\')">Edit</button><button class="danger" onclick="deleteClass(\''+c.id+'\')">×</button></div></div>'});document.getElementById('classList').innerHTML=h}
function pct(s,c){
 ensureWeekMaxes(c);
 let t=0,p=0;
 for(let w=1;w<=14;w++)if(typeof s.scores[w]==='number'){t+=s.scores[w];p+=getWeekMax(c,w)}
 return p?t/p*100:0
}
function render(){
 const c=active();ensureWeekMaxes(c);save();document.getElementById('classTitle').textContent=c.name+' · '+c.subject;document.getElementById('classSub').textContent=c.students.length+' students';document.getElementById('classBadge').textContent=(c.name.match(/\d+/)||['C'])[0];document.getElementById('headerTerm').textContent=c.year+' · '+c.term;document.getElementById('studentCount').textContent=c.students.length;
 let weeks=0;for(let w=1;w<=14;w++)if(c.students.some(s=>s.scores[w]!==undefined))weeks++;document.getElementById('weeksDone').textContent=weeks+'/14';
 let av=c.students.length?c.students.reduce((x,s)=>x+pct(s,c),0)/c.students.length:0;document.getElementById('classAvg').textContent=av.toFixed(1)+'%';
 let leader=c.students.slice().sort((x,y)=>pct(y,c)-pct(x,c))[0];document.getElementById('leader').innerHTML=leader&&pct(leader,c)>0?'<b>'+esc(leader.name)+'</b><br><span class="small">'+pct(leader,c).toFixed(1)+'% current average</span>':'No scores yet<br><span class="small">Highest current percentage —</span>';
 renderClassList();renderStudents();renderScores();renderResults();renderProgress();
}
function addStudent(){let c=active(),n=document.getElementById('studentName').value.trim(),i=document.getElementById('studentIndex').value.trim();if(!n)return alert('Enter the student name.');c.students.push({id:'s'+Date.now()+Math.random(),name:n,index:i,scores:{}});save();document.getElementById('studentName').value='';document.getElementById('studentIndex').value='';render()}
function delStudent(id){let c=active();if(confirm('Delete this student and all recorded scores?')){c.students=c.students.filter(s=>s.id!==id);save();render()}}
function renderStudents(){let c=active(),h='<table><tr><th>Name</th><th>Index</th><th>Actions</th></tr>';c.students.forEach(s=>{h+='<tr><td><input class="edit-input" value="'+escAttr(s.name)+'" onchange="editStudent(\''+s.id+'\',\'name\',this.value)"></td><td><input class="edit-input" value="'+escAttr(s.index)+'" onchange="editStudent(\''+s.id+'\',\'index\',this.value)"></td><td><div class="student-actions"><button class="secondary" onclick="editStudent(\''+s.id+'\',\'save\')">Save</button><button class="danger" onclick="delStudent(\''+s.id+'\')">Delete</button></div></td></tr>'});document.getElementById('studentTable').innerHTML=h+'</table>'}
function editStudent(id,field,value){let c=active(),s=c.students.find(x=>x.id===id);if(!s)return;if(field==='name'){s.name=String(value||'').trim()||s.name}else if(field==='index'){s.index=String(value||'').trim()}save();if(field==='save'){render()}}
function renderScores(){
 const c=active(),sel=document.getElementById('weekSelect');if(!sel)return;
 ensureWeekMaxes(c);
 let old=sel.value||'1';sel.innerHTML='';
 for(let w=1;w<=14;w++)sel.innerHTML+='<option value="'+w+'">Week '+w+'</option>';
 sel.value=old;
 let w=Number(sel.value),mx=getWeekMax(c,w);
 const wm=document.getElementById('weekMaxInput');if(wm)wm.value=mx;
 const hint=document.getElementById('scoreHint');if(hint)hint.textContent='out of '+mx;
 let h='<table><tr><th>Student</th><th>Score / '+mx+'</th></tr>';
 c.students.forEach((s,i)=>{
   let v=s.scores[w]??'';
   h+='<tr><td>'+esc(s.name)+'<br><span class="small">'+esc(s.index)+'</span></td><td><input class="scoreInput" data-row="'+i+'" type="number" min="0" max="'+mx+'" value="'+v+'" inputmode="decimal" onclick="this.select()" onchange="setScore(\''+s.id+'\','+w+',this.value)" onkeydown="scoreKey(event,this,'+w+')"></td></tr>'
 });
 document.getElementById('scoreTable').innerHTML=h+'</table>'
}
function setScore(id,w,v,rerender=true){
 let c=active(),s=c.students.find(x=>x.id===id),n=Number(v);if(!s)return;
 const mx=getWeekMax(c,w);
 if(v===''||isNaN(n))delete s.scores[w];else s.scores[w]=Math.max(0,Math.min(mx,n));
 save();if(rerender)render()
}
function scoreKey(event,input,w){if(event.key==='Enter'){event.preventDefault();setScore(cIdFromInput(input),w,input.value,false);let inputs=[...document.querySelectorAll('.scoreInput')],i=inputs.indexOf(input);if(i>=0&&i<inputs.length-1){inputs[i+1].focus();inputs[i+1].select()}else{input.blur();render()} }else if(event.key==='Tab'){setScore(cIdFromInput(input),w,input.value,false)}}
function cIdFromInput(input){let c=active(),row=Number(input.getAttribute('data-row'));return c.students[row]?.id}
function renderResults(){let c=active(),h='<table><tr><th>Student</th><th>Weeks</th><th>Total</th><th>%</th></tr>';c.students.forEach(s=>{let vals=Object.values(s.scores),t=vals.reduce((a,b)=>a+b,0);h+='<tr><td>'+esc(s.name)+'</td><td>'+vals.length+'/14</td><td>'+t.toFixed(1)+'</td><td>'+pct(s,c).toFixed(1)+'%</td></tr>'});document.getElementById('resultTable').innerHTML=h+'</table>'}
function renderProgress(){
 let c=active();ensureWeekMaxes(c);
 let h='<table><tr><th>Student</th>'+Array.from({length:14},(_,i)=>'<th>W'+(i+1)+'<br><span class="small">/'+getWeekMax(c,i+1)+'</span></th>').join('')+'</tr>';
 c.students.forEach(s=>{h+='<tr><td>'+esc(s.name)+'</td>'+Array.from({length:14},(_,i)=>'<td>'+(s.scores[i+1]!==undefined?s.scores[i+1]+'/'+getWeekMax(c,i+1):'—')+'</td>').join('')+'</tr>'});
 document.getElementById('progressTable').innerHTML=h+'</table>'
}
function csvCell(v){v=v==null?'':String(v);return '"'+v.replace(/"/g,'""')+'"'}
function csvText(rows){return rows.map(r=>r.map(csvCell).join(',')).join('\r\n')}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1000)}
function crc32(bytes){let table=crc32.table;if(!table){table=crc32.table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);table[n]=c>>>0}}let c=0xffffffff;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0}
function u16(a,o){return a[o]|(a[o+1]<<8)} function u32(a,o){return (a[o]|(a[o+1]<<8)|(a[o+2]<<16)|(a[o+3]<<24))>>>0}
function put16(a,v){a.push(v&255,(v>>>8)&255)} function put32(a,v){a.push(v&255,(v>>>8)&255,(v>>>16)&255,(v>>>24)&255)}
function zipStore(files){const enc=new TextEncoder(),out=[],central=[];let offset=0;for(const f of files){const name=enc.encode(f.name),data=typeof f.data==='string'?enc.encode(f.data):f.data,crc=crc32(data);let lh=[0x50,0x4b,0x03,0x04,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];lh=[];put32(lh,0x04034b50);put16(lh,20);put16(lh,0);put16(lh,0);put16(lh,0);put16(lh,0);put32(lh,crc);put32(lh,data.length);put32(lh,data.length);put16(lh,name.length);put16(lh,0);out.push(...lh,...name,...data);let ch=[];put32(ch,0x02014b50);put16(ch,20);put16(ch,20);put16(ch,0);put16(ch,0);put16(ch,0);put16(ch,0);put32(ch,crc);put32(ch,data.length);put32(ch,data.length);put16(ch,name.length);put16(ch,0);put16(ch,0);put16(ch,0);put16(ch,0);put32(ch,0);put32(ch,offset);central.push(...ch,...name);offset=out.length}const cdOffset=out.length;out.push(...central);const cdSize=central.length;let e=[];put32(e,0x06054b50);put16(e,0);put16(e,0);put16(e,files.length);put16(e,files.length);put32(e,cdSize);put32(e,cdOffset);put16(e,0);out.push(...e);return new Uint8Array(out)}
function xmlEsc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;')}
function sheetXml(rows){let s='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';for(let r=0;r<rows.length;r++){s+='<row r="'+(r+1)+'">';for(let c=0;c<rows[r].length;c++){let v=rows[r][c],ref='',n=c+1;while(n){let rem=(n-1)%26;ref=String.fromCharCode(65+rem)+ref;n=Math.floor((n-1)/26)}ref+=(r+1);s+='<c r="'+ref+'" t="inlineStr"><is><t>'+xmlEsc(v)+'</t></is></c>'}s+='</row>'}return s+'</sheetData></worksheet>'}
function makeXlsx(classes,students,scores){const files=[];const types='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
files.push({name:'[Content_Types].xml',data:types});files.push({name:'_rels/.rels',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'});files.push({name:'xl/workbook.xml',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Classes" sheetId="1" r:id="rId1"/><sheet name="Students" sheetId="2" r:id="rId2"/><sheet name="Scores" sheetId="3" r:id="rId3"/></sheets></workbook>'});files.push({name:'xl/_rels/workbook.xml.rels',data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/></Relationships>'});files.push({name:'xl/worksheets/sheet1.xml',data:sheetXml(classes)});files.push({name:'xl/worksheets/sheet2.xml',data:sheetXml(students)});files.push({name:'xl/worksheets/sheet3.xml',data:sheetXml(scores)});return zipStore(files)}
function parseCsv(text){let rows=[],row=[],cell='',q=false;for(let i=0;i<text.length;i++){let ch=text[i];if(q){if(ch==='"'&&text[i+1]==='"'){cell+='"';i++}else if(ch==='"')q=false;else cell+=ch}else{if(ch==='"')q=true;else if(ch===','){row.push(cell);cell=''}else if(ch==='\n'){row.push(cell);rows.push(row);row=[];cell=''}else if(ch!=='\r')cell+=ch}}row.push(cell);if(row.length>1||row[0]!=='')rows.push(row);return rows}
function rowsToObjects(rows){if(!rows.length)return[];const heads=rows[0].map(x=>String(x).trim());return rows.slice(1).map(r=>{const o={};heads.forEach((h,i)=>o[h]=r[i]??'');return o}).filter(o=>Object.values(o).some(v=>String(v).trim()!==''))}
async function unzipEntries(buf){const a=new Uint8Array(buf),dec=new TextDecoder();let eocd=-1;for(let i=a.length-22;i>=Math.max(0,a.length-66000);i--){if(u32(a,i)===0x06054b50){eocd=i;break}}if(eocd<0)throw new Error('Not a ZIP/XLSX file');const count=u16(a,eocd+10),off=u32(a,eocd+16),entries={};let p=off;for(let i=0;i<count;i++){if(u32(a,p)!==0x02014b50)break;const flags=u16(a,p+8),method=u16(a,p+10),cs=u32(a,p+20),us=u32(a,p+24),nl=u16(a,p+28),xl=u16(a,p+30),cl=u16(a,p+32),local=u32(a,p+42);const name=dec.decode(a.slice(p+46,p+46+nl));const lhName=u16(a,local+26),lhExtra=u16(a,local+28),dataStart=local+30+lhName+lhExtra,raw=a.slice(dataStart,dataStart+cs);let data;if(method===0)data=raw;else if(method===8){if(typeof DecompressionStream==='undefined')throw new Error('This Android WebView cannot unpack compressed Excel files. Please use the Exported MathScore Excel file or CSV.');const ds=new DecompressionStream('deflate-raw');data=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(ds)).arrayBuffer())}else throw new Error('Unsupported Excel compression');entries[name]=data;p+=46+nl+xl+cl}return entries}
function xmlRows(bytes){const doc=new DOMParser().parseFromString(new TextDecoder().decode(bytes),'application/xml');if(doc.querySelector('parsererror'))throw new Error('Invalid Excel sheet');const out=[];doc.querySelectorAll('sheetData>row').forEach(r=>{const vals=[];r.querySelectorAll(':scope>c').forEach(c=>{const ref=c.getAttribute('r')||'';let n=0;const letters=(ref.match(/^[A-Z]+/)||['A'])[0];for(const ch of letters)n=n*26+ch.charCodeAt(0)-64;n--;const t=c.getAttribute('t'),is=c.querySelector('is t'),v=c.querySelector('v');let val=is?is.textContent:(v?v.textContent:'');while(vals.length<n)vals.push('');vals[n]=val||''});out.push(vals)});return out}
async function importXlsxFile(file){const entries=await unzipEntries(await file.arrayBuffer());const sheetNames=['xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml','xl/worksheets/sheet3.xml'];const sheets=sheetNames.filter(n=>entries[n]).map(n=>xmlRows(entries[n]));if(!sheets.length)throw new Error('No worksheets found');return sheets}
async function importExcel(input){const file=input.files[0];if(!file)return;try{const name=file.name.toLowerCase();if(name.endsWith('.csv')||file.type==='text/csv'){const rows=parseCsv(await file.text()),objs=rowsToObjects(rows),c=active();let added=0;objs.forEach(r=>{const keys=Object.keys(r),nk=keys.find(k=>/^(name|student name|student)$/i.test(k.trim()))||keys.find(k=>/name/i.test(k)),ik=keys.find(k=>/^(index|index number|student id|id)$/i.test(k.trim()))||keys.find(k=>/index/i.test(k));const n=nk?String(r[nk]).trim():'';const idx=ik?String(r[ik]).trim():'';if(n){c.students.push({id:'s'+Date.now()+Math.random(),name:n,index:idx,scores:{}});added++}});save();render();alert(added+' student(s) imported into '+c.name+'.');input.value='';return}const sheets=await importXlsxFile(file);const first=rowsToObjects(sheets[0]);const c=active();if(sheets.length>=3){const classes=rowsToObjects(sheets[0]),students=rowsToObjects(sheets[1]),scores=rowsToObjects(sheets[2]);if(classes.some(r=>r.Class)&&students.some(r=>r.Name)){if(!confirm('This is a MathScore backup. Import all classes and replace current data?')){input.value='';return}const map={},imported=[];classes.forEach(r=>{const old=String(r.ClassId||'');const id='c'+Date.now()+Math.random();map[old]=id;const fallbackMax=Math.max(1,Number(r.DefaultMaximumMark||r.MaximumMark)||10);
const weekMaxes=Array.from({length:14},(_,i)=>Math.max(1,Number(r['Week'+(i+1)+'Maximum'])||fallbackMax));
imported.push({id,name:String(r.Class||'Unnamed Class'),subject:String(r.Subject||''),year:String(r.AcademicYear||'2026/2027'),term:String(r.Term||'First Term'),max:fallbackMax,weekMaxes,students:[]})});students.forEach(r=>{const cc=imported.find(x=>x.id===map[String(r.ClassId||'')]);if(!cc)return;const s={id:'s'+Date.now()+Math.random(),name:String(r.Name||'').trim(),index:String(r.Index||'').trim(),scores:{}};if(s.name)cc.students.push(s)});scores.forEach(r=>{const cc=imported.find(x=>x.id===map[String(r.ClassId||'')]);if(!cc)return;const s=cc.students.find(x=>x.index===String(r.Index||'').trim()||x.name===String(r.Name||'').trim()),w=Number(r.Week),sc=Number(r.Score);const mx=cc.weekMaxes&&cc.weekMaxes[w-1]?cc.weekMaxes[w-1]:cc.max;if(s&&w>=1&&w<=14&&!isNaN(sc))s.scores[w]=Math.max(0,Math.min(mx,sc))});store.classes=imported;store.activeId=imported[0]?.id||store.activeId;save();render();alert(imported.length+' class(es) imported successfully.');input.value='';return}}const objs=first;let added=0;objs.forEach(r=>{const keys=Object.keys(r),nk=keys.find(k=>/^(name|student name|student)$/i.test(k.trim()))||keys.find(k=>/name/i.test(k)),ik=keys.find(k=>/^(index|index number|student id|id)$/i.test(k.trim()))||keys.find(k=>/index/i.test(k));const n=nk?String(r[nk]).trim():'';const idx=ik?String(r[ik]).trim():'';if(n){c.students.push({id:'s'+Date.now()+Math.random(),name:n,index:idx,scores:{}});added++}});save();render();alert(added+' student(s) imported into '+c.name+'.')}catch(e){console.error(e);alert('Excel import failed: '+(e.message||'Please use .xlsx or .csv.'))}input.value=''}
function exportExcel(){
 try{
  const classes=[['ClassId','Class','Subject','AcademicYear','Term','DefaultMaximumMark',...Array.from({length:14},(_,i)=>'Week'+(i+1)+'Maximum')]],
        students=[['ClassId','Class','Subject','StudentId','Name','Index']],
        scores=[['ClassId','Class','StudentId','Name','Index','Week','MaximumMark','Score']];
  store.classes.forEach(c=>{
   ensureWeekMaxes(c);
   classes.push([c.id,c.name,c.subject,c.year,c.term,c.max,...c.weekMaxes]);
   c.students.forEach(s=>{
    students.push([c.id,c.name,c.subject,s.id,s.name,s.index]);
    for(let w=1;w<=14;w++)if(s.scores[w]!==undefined)scores.push([c.id,c.name,s.id,s.name,s.index,w,getWeekMax(c,w),s.scores[w]])
   })
  });
  const xlsx=makeXlsx(classes,students,scores),stamp=new Date().toISOString().slice(0,10);
  downloadBlob(new Blob([xlsx],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),'MathScore14_Backup_'+stamp+'.xlsx');
  alert('Excel backup exported successfully.');
 }catch(e){console.error(e);alert('Excel export failed: '+(e.message||'Please try again.'))}
}
function esc(x){return String(x).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function escAttr(x){return esc(x).replace(/`/g,'&#96;')}
show('home');
