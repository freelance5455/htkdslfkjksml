# MathScore 14 — Per-Week Maximum Marks Update

This version adds a separate maximum mark for each of the 14 weeks.

## How it works
- Open **Scores**.
- Select **Week 1**, enter its maximum mark (for example 10).
- Select **Week 2**, enter its maximum mark (for example 15).
- Continue through Week 14. Each week remembers its own maximum.
- Scores are prevented from exceeding that week's maximum.
- Student and class percentages use the maximum marks for the weeks that have scores.
- Progress shows each week's score as `score/max`.
- Excel export includes Week 1 Maximum through Week 14 Maximum.
- Excel import restores those week maximums.
- Older MathScore backups that only have one MaximumMark are still supported; that value becomes the default for all 14 weeks.

All previous features are retained, including multiple classes, academic years, Edit Class, student editing, Enter-to-next-student score entry, and offline Excel import/export.
