package com.shadowchat.app
import android.app.Service
import android.content.*
import android.os.IBinder

/** Required stubs for the default-SMS role. MMS is NOT implemented: incoming MMS is ignored. */
class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondViaMessageService : Service() { override fun onBind(i: Intent?): IBinder? = null }
