package com.shadowchat.app

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.*
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.activity.result.ActivityResult
import com.getcapacitor.*
import com.getcapacitor.annotation.*
import org.json.JSONObject

@CapacitorPlugin(name = "ShadowSms", permissions = [
    Permission(strings = [Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS], alias = "sms"),
    Permission(strings = [Manifest.permission.READ_CONTACTS], alias = "contacts"),
    Permission(strings = [Manifest.permission.READ_PHONE_STATE], alias = "phone"),
    Permission(strings = [Manifest.permission.POST_NOTIFICATIONS], alias = "notifications")])
class ShadowSmsPlugin : Plugin() {
    companion object {
        const val ACTION_SENT = "com.shadowchat.SMS_SENT"
        const val ACTION_DELIVERED = "com.shadowchat.SMS_DELIVERED"
        var instance: ShadowSmsPlugin? = null
    }
    private val statusRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra("id", -1)
            val status = if (i.action == ACTION_DELIVERED) (if (resultCode == Activity.RESULT_OK) "delivered" else "failed")
                         else if (resultCode == Activity.RESULT_OK) "sent" else "failed"
            // Update provider row type so the thread survives restarts
            if (status == "failed") try {
                c.contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_FAILED) }, "_id=?", arrayOf("$id"))
            } catch (_: Exception) {}
            notifyListeners("smsStatus", JSObject().put("id", id).put("status", status))
        }
    }
    override fun load() {
        instance = this
        val f = IntentFilter().apply { addAction(ACTION_SENT); addAction(ACTION_DELIVERED) }
        if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(statusRx, f, Context.RECEIVER_NOT_EXPORTED) else context.registerReceiver(statusRx, f)
    }
    fun onIncoming(address: String) { notifyListeners("smsReceived", JSObject().put("address", address)) }

    @PluginMethod fun requestPermissions(call: PluginCall) {
        if (getPermissionState("sms") != PermissionState.GRANTED || getPermissionState("contacts") != PermissionState.GRANTED)
            requestAllPermissions(call, "permCb") else permCb(call)
    }
    @PermissionCallback private fun permCb(call: PluginCall) =
        call.resolve(JSObject().put("sms", getPermissionState("sms").toString().lowercase()))

    @PluginMethod fun requestDefaultSms(call: PluginCall) {
        val rm = context.getSystemService(RoleManager::class.java)
        if (Build.VERSION.SDK_INT < 29 || !rm.isRoleAvailable(RoleManager.ROLE_SMS)) return call.reject("Default SMS role not available")
        if (rm.isRoleHeld(RoleManager.ROLE_SMS)) return call.resolve(JSObject().put("isDefault", true))
        startActivityForResult(call, rm.createRequestRoleIntent(RoleManager.ROLE_SMS), "roleCb")
    }
    @ActivityCallback private fun roleCb(call: PluginCall, r: ActivityResult) =
        call.resolve(JSObject().put("isDefault", r.resultCode == Activity.RESULT_OK))

    @PluginMethod fun getSims(call: PluginCall) {
        val arr = JSArray()
        if (getPermissionState("phone") == PermissionState.GRANTED || context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == 0)
            try { context.getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList?.forEach {
                arr.put(JSObject().put("subId", it.subscriptionId).put("label", "SIM ${it.simSlotIndex + 1} · ${it.carrierName}")) } } catch (_: SecurityException) {}
        call.resolve(JSObject().put("sims", arr))
    }

    @PluginMethod fun getContacts(call: PluginCall) {
        val arr = JSArray()
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == 0)
            context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf("display_name", "data1"), null, null, "display_name")?.use {
                while (it.moveToNext()) arr.put(JSObject().put("name", it.getString(0) ?: "").put("number", it.getString(1) ?: "")) }
        call.resolve(JSObject().put("contacts", arr))
    }

    @PluginMethod fun getThreads(call: PluginCall) {
        val arr = JSArray(); val seen = HashSet<String>()
        context.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body", "date", "read", "type"), null, null, "date DESC")?.use {
            val unread = HashMap<String, Int>(); val rows = ArrayList<JSObject>()
            while (it.moveToNext()) {
                val a = it.getString(0) ?: continue
                if (it.getInt(3) == 0 && it.getInt(4) == 1) unread[a] = (unread[a] ?: 0) + 1
                if (seen.add(a)) rows.add(JSObject().put("address", a).put("name", "").put("snippet", it.getString(1)).put("date", it.getLong(2)))
            }
            rows.forEach { r -> arr.put(r.put("unread", unread[r.getString("address")] ?: 0)) }
        }
        call.resolve(JSObject().put("threads", arr))
    }

    @PluginMethod fun getMessages(call: PluginCall) {
        val a = call.getString("address") ?: return call.reject("address required")
        val arr = JSArray()
        context.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "body", "date", "type"), "address=?", arrayOf(a), "date ASC")?.use {
            while (it.moveToNext()) { val t = it.getInt(3)
                arr.put(JSObject().put("id", it.getLong(0)).put("body", it.getString(1)).put("date", it.getLong(2)).put("out", t != 1)
                    .put("status", when (t) { 1 -> "received"; 5 -> "failed"; 4 -> "sending"; else -> "sent" })) } }
        call.resolve(JSObject().put("messages", arr))
    }

    @PluginMethod fun markRead(call: PluginCall) {
        try { context.contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put("read", 1) }, "address=? AND read=0", arrayOf(call.getString("address"))) } catch (_: Exception) {}
        call.resolve()
    }

    @PluginMethod fun setNotifPrefs(call: PluginCall) {
        context.getSharedPreferences("sc", Context.MODE_PRIVATE).edit()
            .putBoolean("notif", call.getBoolean("enabled", true)!!).putBoolean("hide", call.getBoolean("hide", false)!!).apply()
        call.resolve()
    }

    @PluginMethod fun send(call: PluginCall) {
        val to = call.getString("to")?.trim() ?: return call.reject("Missing number")
        val body = call.getString("body") ?: return call.reject("Empty message")
        if (!Regex("^\\+?[0-9]{3,15}$").matches(to)) return call.reject("Invalid phone number")
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS) != 0) return call.reject("SEND_SMS permission denied")
        if (android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1) return call.reject("Airplane mode is on")
        val tm = context.getSystemService(android.telephony.TelephonyManager::class.java)
        if (tm.simState != android.telephony.TelephonyManager.SIM_STATE_READY) return call.reject("No usable SIM card")
        val subId = call.getInt("subId")
        val sm: SmsManager = if (subId != null) context.getSystemService(SmsManager::class.java).createForSubscriptionId(subId) else context.getSystemService(SmsManager::class.java)
        // Store as outbox (only succeeds when we are the default SMS app)
        var id = System.currentTimeMillis()
        try { context.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
            put("address", to); put("body", body); put("date", System.currentTimeMillis()); put("read", 1); put("type", 4) })?.lastPathSegment?.toLong()?.let { id = it } } catch (_: Exception) {}
        val parts = sm.divideMessage(body)
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        fun pi(action: String, code: Int) = PendingIntent.getBroadcast(context, (id % 100000).toInt() * 2 + code,
            Intent(action).setPackage(context.packageName).putExtra("id", id), fl or PendingIntent.FLAG_MUTABLE.takeIf { Build.VERSION.SDK_INT >= 31 && false }.let { 0 })
        try {
            val sent = ArrayList<PendingIntent>(parts.map { pi(ACTION_SENT, 0) })
            val dlv = ArrayList<PendingIntent>(parts.map { pi(ACTION_DELIVERED, 1) })
            sm.sendMultipartTextMessage(to, null, parts, sent, dlv)
            call.resolve(JSObject().put("id", id).put("parts", parts.size))
        } catch (e: Exception) { call.reject("Send failed: ${e.javaClass.simpleName}") }
    }
}
