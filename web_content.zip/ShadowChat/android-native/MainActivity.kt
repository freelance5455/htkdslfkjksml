package com.shadowchat.app
import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(ShadowSmsPlugin::class.java) // must run before super.onCreate
        super.onCreate(savedInstanceState)
    }
}
