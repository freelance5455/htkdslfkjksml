package com.shadowchat.app

import android.app.*
import android.content.*
import android.provider.Telephony
import androidx.core.app.*

/** Receives SMS_DELIVER (only delivered to the default SMS app), stores it, and notifies. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val addr = msgs.first().originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
            put("address", addr); put("body", body); put("date", System.currentTimeMillis()); put("read", 0); put("type", 1) })
        ShadowSmsPlugin.instance?.onIncoming(addr)
        val p = c.getSharedPreferences("sc", Context.MODE_PRIVATE)
        if (!p.getBoolean("notif", true)) return
        val ch = "msgs"; val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Messages", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, addr.hashCode(), Intent(c, MainActivity::class.java).putExtra("address", addr), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val text = if (p.getBoolean("hide", false)) "New message" else body.take(120)
        val n = NotificationCompat.Builder(c, ch).setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(addr)
            .setContentText(text).setContentIntent(open).setAutoCancel(true)
            .setVisibility(if (p.getBoolean("hide", false)) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_PUBLIC).build()
        try { NotificationManagerCompat.from(c).notify(addr.hashCode(), n) } catch (_: SecurityException) {}
    }
}
