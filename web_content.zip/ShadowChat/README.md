# ShadowChat

Offline SMS app: web UI (`www/`) + Capacitor Android plugin (`android-native/`). No servers, no internet messaging.

## Browser vs Android
| Feature | Browser | Android app |
|---|---|---|
| UI, theme, accent, font size, search, tabs, favorites | Works | Works |
| Character / SMS segment counter | Works | Works |
| Send / receive SMS, read threads | **Not possible** (shows a clear error, never a fake "sent") | Works |
| Contacts, SIM selection, default-SMS role, notifications | **Not available** | Works |
| Reply action in notifications, contact photos, MMS/attachments | Not implemented | Not implemented (MMS is not supported) |

## Run the web prototype
    cd www && python3 -m http.server 8080     # open http://localhost:8080
The UI loads with a red "Browser preview" banner and no conversations.

## Build the APK
Needs Node 18+, JDK 17, Android Studio (SDK 34).
    npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
    npx cap init ShadowChat com.shadowchat.app --web-dir=www
    npx cap add android
    cp android-native/*.kt android/app/src/main/java/com/shadowchat/app/   # replace the generated MainActivity.kt
    # merge android-native/ManifestAdditions.xml into android/app/src/main/AndroidManifest.xml
    npx cap sync android && npx cap open android
In Android Studio: Build > Build APK(s). Debug APK: `android/app/build/outputs/apk/debug/`.

## Test with real SMS (physical phone with a SIM; emulators can't use a carrier)
1. Install the APK; allow SMS, Contacts, Phone and Notification permissions.
2. Settings > "Set ShadowChat as default" and accept the system dialog (required to receive and store messages).
3. New message > type a number or pick a contact > send to a second phone. Status goes Sending > Sent > Delivered (delivery reports depend on carrier).
4. Reply from the other phone: the message appears live and a notification fires.
5. Failure checks: airplane mode, no SIM, a long (>160 chars) message to see multipart, an invalid number.

## Known limits
- Contacts are matched to threads by number suffix; thread names show the number until contacts load.
- Notification reply action, contact photos, MMS, and Play Store default-SMS policy declaration are not implemented.
- Local message data lives in Android's system SMS provider, protected by the app sandbox and device encryption.
