'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const Sms=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.ShadowSms; // native bridge
const native=!!Sms;
const S={threads:[],contacts:[],sims:[],msgs:[],cur:null,tab:'all',simId:null};
const pref=JSON.parse(localStorage.getItem('sc-pref')||'{}'); // UI prefs only
const savePref=()=>localStorage.setItem('sc-pref',JSON.stringify(pref));
const fav=new Set(pref.fav||[]);
const esc=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=ts=>{const d=new Date(ts),n=new Date();return d.toDateString()===n.toDateString()?d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString([],{month:'short',day:'numeric'})};
const toast=m=>{const b=$('#banner');b.textContent=m;b.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>b.hidden=true,4000)};

function applyPref(){
  document.documentElement.style.setProperty('--acc',pref.accent||'#8B5CF6');
  document.documentElement.style.setProperty('--fs',(pref.font||16)+'px');
  $('#notif').checked=pref.notif!==false;$('#hide').checked=!!pref.hide;
}
function show(id){$$('.view').forEach(v=>v.classList.toggle('active',v.id==='v-'+id));
  if(id==='list')renderList();if(id==='new'){$('#to').value='';renderContacts();}}
$$('[data-go]').forEach(b=>b.onclick=()=>show(b.dataset.go));

async function call(m,a){ if(!native)throw new Error('SMS needs the Android app'); return Sms[m](a||{}); }

async function loadThreads(){
  if(!native){S.threads=[];return;}
  try{S.threads=(await call('getThreads')).threads}catch(e){toast('Cannot read messages: '+e.message)}
}
function renderList(){
  const q=$('#q').value.toLowerCase();
  const rows=S.threads.filter(t=>(S.tab==='all'||(S.tab==='unread'&&t.unread>0)||(S.tab==='fav'&&fav.has(t.address)))&&(t.name+t.address+t.snippet).toLowerCase().includes(q));
  $('#threads').innerHTML=rows.map(t=>`<li class="t" data-a="${esc(t.address)}"><div class="av">${esc((t.name||'#')[0].toUpperCase())}</div><div class="mid"><b>${esc(t.name||t.address)}</b><small>${esc(t.snippet)}</small></div><div><small>${fmt(t.date)}</small>${t.unread?`<br><span class="badge">${t.unread}</span>`:''}</div></li>`).join('');
  $('#empty').hidden=rows.length>0;
  $$('#threads li').forEach(li=>li.onclick=()=>openChat(li.dataset.a));
}
$('#q').oninput=renderList;
$$('.tabs button').forEach(b=>b.onclick=()=>{S.tab=b.dataset.tab;$$('.tabs button').forEach(x=>x.classList.toggle('on',x===b));renderList()});

const nameOf=a=>(S.contacts.find(c=>c.number.replace(/\D/g,'').slice(-9)===a.replace(/\D/g,'').slice(-9))||{}).name||a;
async function openChat(addr){
  S.cur=addr;$('#c-name').textContent=nameOf(addr);$('#c-num').textContent=addr;
  $('#c-av').textContent=nameOf(addr)[0].toUpperCase();$('#c-fav').textContent=fav.has(addr)?'★':'☆';
  S.msgs=[];show('chat');
  if(native){try{S.msgs=(await call('getMessages',{address:addr})).messages;await call('markRead',{address:addr})}catch(e){toast(e.message)}}
  renderMsgs();updateCount();
}
const ST={sending:'Sending…',sent:'Sent',delivered:'Delivered',failed:'Failed – tap to retry',received:''};
function renderMsgs(){
  const box=$('#msgs');
  box.innerHTML=S.msgs.map((m,i)=>`<div class="m ${m.out?'out':''} ${m.status==='failed'?'failed':''}" data-i="${i}">${esc(m.body)}<small>${fmt(m.date)}${m.out?' · '+ST[m.status]:''}</small></div>`).join('')||'<div class="empty">No messages</div>';
  box.scrollTop=box.scrollHeight;
  $$('.m.failed').forEach(el=>el.onclick=()=>{const m=S.msgs[el.dataset.i];S.msgs.splice(el.dataset.i,1);doSend(S.cur,m.body)});
}
$('#c-fav').onclick=()=>{fav.has(S.cur)?fav.delete(S.cur):fav.add(S.cur);pref.fav=[...fav];savePref();$('#c-fav').textContent=fav.has(S.cur)?'★':'☆'};
$('#attach').onclick=()=>toast('Attachments need MMS, which ShadowChat does not support yet.');

function segs(t){ // approximate: GSM-7 vs UCS-2
  const u=/[^\u0020-\u007e\n£¥èéùìòÇØøÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ¤¡ÄÖÑÜ§¿äöñüà€]/.test(t),n=t.length;
  const [one,multi]=u?[70,67]:[160,153];return{u,n,s:n===0?0:n<=one?1:Math.ceil(n/multi)};
}
function updateCount(){
  const c=segs($('#body').value);
  $('#count').textContent=`${c.n} chars · ${c.s} SMS${c.s>1?' (long message, may be billed per segment)':''}${c.u?' · unicode':''}`;
  $('#send').disabled=!$('#body').value.trim();
  const b=$('#body');b.style.height='auto';b.style.height=Math.min(b.scrollHeight,120)+'px';
}
$('#body').oninput=updateCount;
$('#send').onclick=()=>{const t=$('#body').value.trim();if(!t)return;doSend(S.cur,t);$('#body').value='';updateCount()};
async function doSend(to,body){
  if(!native){toast('Browser preview: SMS can only be sent from the Android app.');$('#body').value=body;updateCount();return}
  const m={out:true,body,date:Date.now(),status:'sending',id:null};S.msgs.push(m);renderMsgs();
  try{const r=await call('send',{to,body,subId:S.simId?+S.simId:undefined});m.id=r.id;m.status='sent'}
  catch(e){m.status='failed';toast('Send failed: '+e.message)}
  renderMsgs();
}

function renderContacts(){
  const q=$('#to').value.trim(),ql=q.toLowerCase(),digits=q.replace(/[^\d+]/g,'');
  const valid=/^\+?\d{3,15}$/.test(digits)&&digits.length>=3;
  const mb=$('#manual');mb.hidden=!valid;mb.textContent='Message '+digits;mb.onclick=()=>openChat(digits);
  const list=S.contacts.filter(c=>(c.name+c.number).toLowerCase().includes(ql)).slice(0,100);
  $('#contacts').innerHTML=list.length?list.map((c,i)=>`<li class="row" data-n="${esc(c.number)}"><div class="av">${esc(c.name[0]||'#')}</div><div class="mid"><b>${esc(c.name)}</b><small>${esc(c.number)}</small></div></li>`).join(''):`<li class="note">${native?'No matching contacts. Enter a full number above.':'Contacts need the Android app.'}</li>`;
  $$('#contacts li[data-n]').forEach(li=>li.onclick=()=>openChat(li.dataset.n));
}
$('#to').oninput=renderContacts;$('#fab').onclick=()=>show('new');
$('#sim').onchange=e=>S.simId=e.target.value;

$$('[data-accent]').forEach(b=>b.onclick=()=>{pref.accent=b.dataset.accent;savePref();applyPref()});
$$('[data-font]').forEach(b=>b.onclick=()=>{pref.font=+b.dataset.font;savePref();applyPref()});
$('#notif').onchange=e=>{pref.notif=e.target.checked;savePref();Sms&&Sms.setNotifPrefs({enabled:pref.notif,hide:!!pref.hide})};
$('#hide').onchange=e=>{pref.hide=e.target.checked;savePref();Sms&&Sms.setNotifPrefs({enabled:pref.notif!==false,hide:pref.hide})};
$('#defsim').onchange=e=>{pref.defSim=e.target.value;S.simId=e.target.value;$('#sim').value=e.target.value;savePref()};
$('#role').onclick=async()=>{try{const r=await call('requestDefaultSms');toast(r.isDefault?'ShadowChat is now the default SMS app.':'Not set as default.')}catch(e){toast(e.message)}};

async function boot(){
  applyPref();
  if(!native){$('#banner').hidden=false;$('#banner').textContent='Browser preview – real SMS needs the Android app';}
  else{
    try{
      const p=await Sms.requestPermissions();if(p.sms!=='granted')toast('SMS permission denied: messaging is unavailable.');
      S.sims=(await call('getSims')).sims;
      S.contacts=(await call('getContacts')).contacts.map(c=>c);
    }catch(e){toast(e.message)}
    for(const s of S.sims){for(const sel of ['#sim','#defsim'])$(sel).add(new Option(s.label,s.subId))}
    $('#sim-row').hidden=S.sims.length<2;S.simId=pref.defSim||null;
    Sms.addListener('smsReceived',async m=>{await loadThreads();if(S.cur&&m.address===S.cur)openChat(S.cur);else renderList()});
    Sms.addListener('smsStatus',({id,status})=>{const m=S.msgs.find(x=>x.id===id);if(m){m.status=status;renderMsgs()}});
    await loadThreads();
  }
  renderList();
  setTimeout(()=>{$('#splash').classList.add('off');$('#v-list').classList.add('active')},1400);
}
boot();
