# Sahil Video — Admin Console Edition

This ZIP contains the Sahil Video web app plus a Supabase-backed admin console.

## Included
- User email/password signup and login (Supabase Auth)
- Video uploads, thumbnails, public playback, categories and Shorts
- Likes/dislikes, comments, subscriptions and notifications
- Search, creator profile, recommendations and dark mode
- Admin dashboard with user/video/comment counts
- Admin video moderation (delete videos) and comment moderation
- Admin user list
- Supabase SQL schema, RLS policies, storage buckets and admin role protection
- User reports table for moderation workflows

## Setup the backend (required)
This project uses **Supabase as its hosted backend**; it is not a separately deployed private server. You must create/connect your own Supabase project.

1. Create a project at https://supabase.com/.
2. Open Supabase → SQL Editor and run the complete `supabase/schema.sql`.
3. Open Project Settings → API. Copy the Project URL and anon/public key.
4. Paste both into `app.js` AND `admin.js`, replacing `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`.
5. In Supabase → Authentication → URL Configuration, add your app's deployed URL to Site URL / Redirect URLs.
6. Serve the folder from a web server or deploy it to a static host (Netlify, Cloudflare Pages, Vercel). Do not open index.html directly as a file.

## Grant your own account admin access
1. First sign up normally through `index.html`.
2. In Supabase → SQL Editor, run this statement after replacing the email:
   ```sql
   update public.profiles
   set role='admin'
   where id=(select id from auth.users where email='YOUR_ADMIN_EMAIL');
   ```
3. Open `admin.html`, sign in with that same account. Non-admin accounts are rejected by the database check.

## Security notes
- Browser code contains only the Supabase anon/public key. Never paste a `service_role` key into this project.
- Admin permissions are enforced by database Row Level Security and the `is_admin()` function, not by hiding buttons.
- User role changes are blocked through normal authenticated API updates. Grant/revoke admin from trusted Supabase SQL Editor access only.
- The admin console lists users and allows deleting videos/comments. It does not delete Auth identities; use Supabase Auth admin tooling for account bans/deletion.
- Reports are stored in `reports`; a report-review screen and push notifications are not yet implemented.
- Configure storage quotas, rate limits, abuse reporting review, copyright process, backups and monitoring before public launch.
- Video HD playback uses the uploaded source file; adaptive bitrate transcoding/HLS and resumable uploads are not included.
- This ZIP does not contain your Supabase credentials and cannot create a cloud project or deploy it without your account and explicit access.

## Run locally
```bash
python -m http.server 8080
```
Then open `http://localhost:8080` for the app and `http://localhost:8080/admin.html` for the admin console.
