Place optional app icons and brand artwork in this folder.
