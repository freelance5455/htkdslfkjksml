-- Sahil Video database schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Creator',
  avatar_url text,
  bio text default '',
  created_at timestamptz not null default now()
);
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text default '',
  category text default 'General',
  video_url text not null,
  thumbnail_url text,
  is_short boolean not null default false,
  views bigint not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.video_reactions (
  user_id uuid references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete cascade,
  reaction text not null check (reaction in ('like','dislike')),
  created_at timestamptz not null default now(),
  primary key(user_id,video_id)
);
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create table if not exists public.subscriptions (
  subscriber_id uuid references public.profiles(id) on delete cascade,
  channel_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(subscriber_id,channel_id),
  check (subscriber_id <> channel_id)
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- Create a profile automatically for each new account.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,display_name)
  values(new.id,coalesce(new.raw_user_meta_data->>'display_name',split_part(new.email,'@',1)));
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.video_reactions enable row level security;
alter table public.comments enable row level security;
alter table public.subscriptions enable row level security;
alter table public.notifications enable row level security;

create policy "Profiles are public" on public.profiles for select using (true);
create policy "Users update own profile" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);
create policy "Videos are public" on public.videos for select using (true);
create policy "Authenticated users upload videos" on public.videos for insert to authenticated with check (auth.uid()=user_id);
create policy "Owners update videos" on public.videos for update using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "Owners delete videos" on public.videos for delete using (auth.uid()=user_id);
create policy "Reactions are readable" on public.video_reactions for select using (true);
create policy "Users react as themselves" on public.video_reactions for insert to authenticated with check (auth.uid()=user_id);
create policy "Users change own reaction" on public.video_reactions for update using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "Users remove own reaction" on public.video_reactions for delete using (auth.uid()=user_id);
create policy "Comments are readable" on public.comments for select using (true);
create policy "Authenticated users comment" on public.comments for insert to authenticated with check (auth.uid()=user_id);
create policy "Users delete own comments" on public.comments for delete using (auth.uid()=user_id);
create policy "Subscriptions readable" on public.subscriptions for select using (true);
create policy "Users subscribe as themselves" on public.subscriptions for insert to authenticated with check (auth.uid()=subscriber_id);
create policy "Users unsubscribe themselves" on public.subscriptions for delete using (auth.uid()=subscriber_id);
create policy "Users read own notifications" on public.notifications for select using (auth.uid()=user_id);
create policy "Users update own notifications" on public.notifications for update using (auth.uid()=user_id) with check (auth.uid()=user_id);

-- Storage buckets. Video and thumbnail files are public for playback.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('videos','videos',true,1073741824,array['video/mp4','video/webm','video/quicktime','video/x-m4v'])
on conflict(id) do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('thumbnails','thumbnails',true,10485760,array['image/jpeg','image/png','image/webp'])
on conflict(id) do nothing;
create policy "Public can view video files" on storage.objects for select using (bucket_id in ('videos','thumbnails'));
create policy "Users upload own video files" on storage.objects for insert to authenticated
with check (bucket_id in ('videos','thumbnails') and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Users update own files" on storage.objects for update to authenticated
using ((storage.foldername(name))[1]=auth.uid()::text) with check ((storage.foldername(name))[1]=auth.uid()::text);
create policy "Users delete own files" on storage.objects for delete to authenticated
using ((storage.foldername(name))[1]=auth.uid()::text);

-- Optional: trigger a notification when a creator receives a new subscriber.
create or replace function public.notify_channel_subscription()
returns trigger language plpgsql security definer set search_path=public as $$
declare subscriber_name text;
begin
  select display_name into subscriber_name from public.profiles where id=new.subscriber_id;
  insert into public.notifications(user_id,message)
  values(new.channel_id,coalesce(subscriber_name,'Someone') || ' subscribed to your channel.');
  return new;
end; $$;
drop trigger if exists on_new_subscription on public.subscriptions;
create trigger on_new_subscription after insert on public.subscriptions
for each row execute procedure public.notify_channel_subscription();


-- ---------------------------------------------------------------------------
-- Admin console / moderation additions
-- IMPORTANT: grant admin roles manually from the Supabase SQL Editor only.
-- Never expose the service_role key in app.js or admin.js.
-- ---------------------------------------------------------------------------
alter table public.profiles add column if not exists role text not null default 'user'
  check (role in ('user','admin'));

-- Prevent a signed-in user from promoting their own account through the API.
create or replace function public.prevent_client_role_change()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and new.role is distinct from old.role then
    raise exception 'Only a trusted database administrator can change account roles';
  end if;
  return new;
end; $$;
drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role before update on public.profiles
for each row execute procedure public.prevent_client_role_change();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Admin-only read access and moderation actions.
drop policy if exists "Admins manage videos" on public.videos;
create policy "Admins manage videos" on public.videos
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Admins manage comments" on public.comments;
create policy "Admins manage comments" on public.comments
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Admins view all profiles" on public.profiles;
create policy "Admins view all profiles" on public.profiles
  for select to authenticated using (public.is_admin());

-- User reports for future moderation workflows.
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete cascade,
  comment_id uuid references public.comments(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open' check (status in ('open','reviewed','dismissed')),
  created_at timestamptz not null default now(),
  check ((video_id is not null)::int + (comment_id is not null)::int = 1)
);
alter table public.reports enable row level security;
drop policy if exists "Users submit own reports" on public.reports;
create policy "Users submit own reports" on public.reports
  for insert to authenticated with check (auth.uid()=reporter_id);
drop policy if exists "Users read own reports" on public.reports;
create policy "Users read own reports" on public.reports
  for select to authenticated using (auth.uid()=reporter_id);
drop policy if exists "Admins manage reports" on public.reports;
create policy "Admins manage reports" on public.reports
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Example: after creating your account, replace the email below and run this
-- statement manually in Supabase SQL Editor to grant administrator access:
-- update public.profiles
-- set role='admin'
-- where id=(select id from auth.users where email='YOUR_ADMIN_EMAIL');
