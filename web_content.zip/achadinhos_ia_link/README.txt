ACHADINHOS IA — PACOTE COM LINK DO SITE

URL configurada:
https://fancy-marigold-5d64f0.netlify.app/

Nome do app: Achadinhos IA
Cor principal: #D99A00

Envie este ZIP ao conversor de site/HTML para APK. Se o conversor tiver campo URL do site, use diretamente a URL acima.
Este ZIP não é o APK compilado; é o pacote para o conversor gerar o APK.
