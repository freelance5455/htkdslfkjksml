PRIDE 005 – Landscape AndroidIDE build

این نسخه برای مانیتور افقی خودرو اصلاح شده است.

تغییرات:
- قفل واقعی صفحه روی Landscape در Android
- تمام‌صفحه و مخفی شدن نوارهای سیستم
- Preview عمودی نیز با CSS به یک بوم Landscape تبدیل می‌شود
- تصویر پراید بزرگ‌تر و مرکزچین شده
- چشم، ابرو، دهان و حالت‌های Normal/Happy/Angry/Sad/Sleepy/Surprised روی شیشه جلو
- پلک‌زدن خودکار
- انتخاب و پخش فایل موسیقی از حافظه دستگاه با کنترل قبلی/پخش/بعدی
- GPS speed و ساعت
- Navigation
- Normal / Sport / Music / Night
- Voice command از طریق SpeechRecognizer اندروید

Build:
AndroidIDE → Open Project → همین پوشه → Sync → Build > Assemble Debug

نکته: AndroidIDE Preview ممکن است محیطی متفاوت از APK واقعی داشته باشد، اما Activity در APK به‌صورت اجباری Landscape اجرا می‌شود.
