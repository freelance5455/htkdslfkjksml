LOONIE ACADEMY v8 — PERSONAL UNIVERSITY (PHASE 2)
15 November 2026 | Offline-first PWA | No account, API or internet required for core learning

IMPORTANT: THIS IS A COMPLETE APP, NOT A PATCH.
Keep all application files together in the same folder. Do not upload index.html by itself.

CONTENTS OF THIS VERSION
- All original v7 educational content: 384 lessons in 37 subjects, 2,022 original lesson quiz questions, intact.
- New Personal University home screen accessible from Learn and the transcript accessible from Me.
- Four pathways: Accounting & Business, Skilled Trades (pick a trade specialization),
  Technology & Data, and Independent Studies (choose any existing subject).
- Four ordered semesters per pathway with a curated, non-overlapping sequence of actual lessons.
- Weekly study-time goal, suggested weekly schedule, estimated workload, editable semester target dates.
- Explicit prerequisites: previous semester must pass for the next semester to unlock;
  required lesson quizzes must be completed before the assignment; assignment must be passed
  before the mixed exam; exam must be passed before the applied project.
- Graded applied assignments with six questions (two newly authored case questions plus
  four questions grounded in the actual semester's lessons), plus saved written reflection.
- Mixed 14-question semester exams selected across actual semester lessons; new shuffled
  question/answer mix per attempt, explanations, drafts that save across navigation/reloads.
- Sixteen original applied semester project specifications (one per pathway x semester),
  with four distinct evidence-writing milestones each, four knowledge checks and a guided rubric.
- Practice gradebook with attempt history, best marks and weighted term marks.
- Downloadable unofficial transcript CSV and full practice-record JSON.
- All university drafts/results and written evidence are saved with the existing Academy state,
  so they are included in the existing full backup/export and restored with it.
- Existing v7 curriculum, lessons, IDs, quizzes, XP, saved notes, quests, original games,
  knowledge library, achievements and backup system are preserved.
- Service worker precaches the new JS and CSS, and supports offline navigation fallback.

HOW TO UPDATE WITHOUT LOSING PROGRESS
1. In your CURRENT installed Academy, open Me -> Backup & Restore -> Download backup file.
   Save it outside the app (for example Downloads or Drive) before changing anything.
2. Keep the original v7 ZIP as a fallback. Do not uninstall your existing PWA to upgrade.
3. If you host the PWA, replace/upload ALL app files from this ZIP in the SAME HTTPS directory.
   The app's existing storage origin MUST remain the same for browser progress to carry forward.
4. Open while ONLINE and refresh. Reopen/refresh the installed app again if it displays
   the older cached version. Verify the Personal University card appears on Learn.
5. Check that previous lesson completions/notes are still visible. Test a lesson, an
   assignment draft, the gradebook and offline reopening in airplane mode.
6. If progress is missing, use the Academy's Backup & Restore feature to restore your exported data.

NEW USERS / LOCAL TESTING
- Upload the whole folder to HTTPS hosting or use a localhost web server (developer mode).
- The index.html page can also be opened locally in a desktop browser, but a true installable PWA
  and the service worker require a supported secure origin (HTTPS/localhost).
- Internet may be required by old optional features (e.g. Python runtime) and Google fonts.
  New Personal University and core lessons do not require those external services.

PERSONAL UNIVERSITY GRADING
- Semester passing standard: 70% or higher on EACH assignment, exam and project.
- Weighted term mark: 25% assignment + 50% mixed exam + 25% applied project.
- Project self-score: 60% from knowledge checks, 40% from YOUR OWN rubric ratings.
- Written reflections and evidence are saved but the app CANNOT judge their academic quality.
  Self-rated marks are NOT independent instructor assessment, even if a student selects 4/4.
- Retakes are allowed. Best assessment score determines semester progress; attempt history remains.
- Completing a program does not create official credit, a credential, trade qualification or degree.

TESTING AND LIMITATIONS
- Phase 2 browser QA completed: 4 full semesters finished end-to-end through live UI
  interaction, negative/failing result, prerequisite locks, drafts/resume, retakes,
  program/focus change, downloads, reload persistence and existing-state preservation.
- Static curriculum validation confirmed 384 lessons / 37 subjects / 2,022 original quiz questions,
  plus valid non-overlapping plans across 37 subject choices and trade specializations.
- Service worker syntax, pre-cache manifest and OFFLINE FALLBACK LOGIC were simulated and passed.
- A REAL Android install, network-off PWA reopen on a device, every legacy simulator and
  long-term usage were NOT physically verified by this environment. Test them on your phone.
- Technical, regulated, financial and safety lessons are for education/simulation only.
  Verify current official rules and use qualified supervision for real high-risk work.

This ZIP preserves the original v6/v7 curriculum files. The separately uploaded v7 ZIP remains unchanged.

NEXT MAJOR ROADMAP STAGE
Phase 3 — Interactive Learning: investigations, richer laboratories and Teach Lou experiences.
