# Glow Collections — Slay on a Budget

A responsive, mobile-friendly unisex fashion catalogue / advert website.

## Included
- `index.html` — complete app (HTML, CSS and JavaScript in one file).
- Admin modal with starter demo credentials: username `admin`, password `admin`.
- Add stock items with photos, descriptions and categories; remove items.
- No prices are displayed. Each item has a WhatsApp enquiry link.
- Editable shop location and Instagram, Facebook, TikTok and website links.
- Contact numbers: 09035610035 and 0706 599 7306.

## Run
Open `index.html` in a modern browser, or upload the files to a static web host (HTTPS recommended).

## Important: data and live updates
This ZIP is a front-end starter/demo. It saves stock, images, admin credentials and shop details in the current browser's `localStorage`. That means it works on the device/browser where the admin enters the data, but it does **not** yet sync changes to customers' phones or other devices. True live updates require a shared online database and image storage (for example Firebase or Supabase), plus secure admin authentication and hosting. Configure that backend before publishing as a real multi-user store.

## Important: admin security
The requested `admin` / `admin` login is included for initial local testing. It is not secure for a public production app because browser code and local storage can be inspected or changed. Do not use valuable or private data with this demo. Before launch, replace it with server-side authentication, hashed passwords, access rules and protected image uploads. The change-login screen currently changes the credentials only in that browser.

## Branding
Glow Collections — **Slay on a Budget**
Unisex clothing and fashion advert catalogue. Prices are intentionally omitted.
