WSC Editor — Datapack Mundo 2017 (projeto Android)

Este pacote é o PROJETO-FONTE de um app Android, ainda não é um APK instalado.
Inclui uma cópia das tabelas CSV do pro_datapack_v86.zip enviado pelo usuário.

Funções da versão:
- carregar as tabelas CSV incluídas no datapack enviado;
- pesquisar e editar células, adicionar/excluir linhas e adicionar colunas;
- importar CSVs externos pelo seletor do Android;
- exportar a tabela editada como CSV.

Limitação importante:
O datapack fornecido contém principalmente IDs e nomes. Criar colunas de overall/nacionalidade ou alterar divisões/regras não garante que o jogo as leia. Essas funções dependem de localizar e compreender os arquivos de dados internos corretos.

Como compilar APK (requer computador com Android Studio e SDK Android):
1. Extraia a pasta WSCEditorAndroid.zip.
2. Abra a pasta WSCEditorAndroid no Android Studio.
3. Aguarde a sincronização do Gradle e instale o SDK 35 se solicitado.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste normalmente fica em app/build/outputs/apk/debug/app-debug.apk.

Faça backup dos arquivos originais do jogo. O app edita/exporta CSVs; não modifica automaticamente o jogo instalado.
