import { Router, type IRouter } from "express";
import { ExportMiniAppBody, GenerateMiniAppBody } from "@workspace/api-zod";
import { randomUUID } from "node:crypto";

const router: IRouter = Router();

const MODEL_IDS = {
  flash: "gemini-3-flash-preview",
  pro: "gemini-3.1-pro-preview",
  "flash-lite": "gemini-2.5-flash-lite",
  extended: "gemini-3.1-pro-preview",
} as const;

const STABLE_MODEL_IDS = {
  flash: "gemini-2.5-flash",
  pro: "gemini-2.5-pro",
  "flash-lite": "gemini-2.5-flash",
  extended: "gemini-2.5-pro",
} as const;

type ModelKey = keyof typeof MODEL_IDS;
type GeneratedFile = { path: string; content: string; language: string };

const generationInstruction = `
You are Halo App Maker, an expert mini-app generator. Return ONLY valid JSON, with no markdown fences and no commentary.
Generate a small but genuinely functional browser app from the user's request. Keep it self-contained and dependency-free.
The JSON shape must be:
{
  "title": "short project title",
  "summary": "one sentence describing what was built",
  "files": [
    {"path":"index.html","language":"html","content":"..."},
    {"path":"styles.css","language":"css","content":"..."},
    {"path":"app.js","language":"javascript","content":"..."}
  ]
}
Always include an index.html, styles.css, and app.js. Make the HTML reference the CSS and JS files with relative paths.
Make interactions work without a build step. Prefer semantic HTML, keyboard support, and a polished visual hierarchy.
`;

function cleanJsonFence(value: string): string {
  return value
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

function languageForPath(path: string): string {
  if (path.endsWith(".html")) return "html";
  if (path.endsWith(".css")) return "css";
  if (path.endsWith(".js")) return "javascript";
  if (path.endsWith(".json")) return "json";
  return "text";
}

function safePath(path: string): string {
  const normalized = path.replaceAll("\\", "/").replace(/^\/+/, "");
  if (!normalized || normalized.includes("..")) return "untitled.txt";
  return normalized;
}

function buildPreview(files: GeneratedFile[]): string {
  const htmlFile = files.find((file) => file.path === "index.html") ?? files.find((file) => file.language === "html");
  const css = files.filter((file) => file.language === "css").map((file) => file.content).join("\n");
  const js = files.filter((file) => file.language === "javascript" || file.language === "js").map((file) => file.content).join("\n");

  let html = htmlFile?.content ?? `<!doctype html><html><body><main id="app"></main></body></html>`;
  if (css) {
    html = html.includes("</head>") ? html.replace("</head>", `<style>${css}</style></head>`) : `<style>${css}</style>${html}`;
  }
  if (js) {
    html = html.includes("</body>") ? html.replace("</body>", `<script>${js}</script></body>`) : `${html}<script>${js}</script>`;
  }
  return html;
}

function parseFallbackFiles(text: string): GeneratedFile[] {
  const matches = [...text.matchAll(/```([a-zA-Z0-9+#-]*)\s*([\s\S]*?)```/g)];
  return matches.map((match, index) => {
    const language = match[1].toLowerCase() || "text";
    const extension = language === "html" ? "html" : language === "css" ? "css" : "js";
    return {
      path: index === 0 && extension === "html" ? "index.html" : `file-${index + 1}.${extension}`,
      language: extension === "js" ? "javascript" : extension,
      content: match[2].trim(),
    };
  });
}

function crc32(input: Buffer): number {
  let crc = 0xffffffff;
  for (const byte of input) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makeZip(entries: Array<{ name: string; content: Buffer }>): Buffer {
  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const name = Buffer.from(entry.name, "utf8");
    const checksum = crc32(entry.content);
    const local = Buffer.alloc(30 + name.length + entry.content.length);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(0, 12);
    local.writeUInt32LE(checksum, 14);
    local.writeUInt32LE(entry.content.length, 18);
    local.writeUInt32LE(entry.content.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    name.copy(local, 30);
    entry.content.copy(local, 30 + name.length);
    localParts.push(local);

    const central = Buffer.alloc(46 + name.length);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(0, 12);
    central.writeUInt16LE(0, 14);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(entry.content.length, 20);
    central.writeUInt32LE(entry.content.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    name.copy(central, 46);
    centralParts.push(central);
    offset += local.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const footer = Buffer.alloc(22);
  footer.writeUInt32LE(0x06054b50, 0);
  footer.writeUInt16LE(0, 4);
  footer.writeUInt16LE(0, 6);
  footer.writeUInt16LE(entries.length, 8);
  footer.writeUInt16LE(entries.length, 10);
  footer.writeUInt32LE(centralDirectory.length, 12);
  footer.writeUInt32LE(offset, 16);
  footer.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, centralDirectory, footer]);
}

router.post("/gemini/generate", async (req, res) => {
  const parsed = GenerateMiniAppBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Prompt, model, and reasoning are required." });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "Gemini is not configured on the server yet." });
    return;
  }

  const { prompt, model, reasoning, attachments } = parsed.data as {
    prompt: string;
    model: ModelKey;
    reasoning: "off" | "balanced" | "deep";
    attachments?: Array<{ name: string; mimeType: string; data: string }>;
  };

  const parts: Array<Record<string, unknown>> = [
    { text: `${generationInstruction}\n\nUser request:\n${prompt}` },
  ];
  for (const attachment of attachments ?? []) {
    if (attachment.data.length <= 8_000_000) {
      parts.push({ inlineData: { mimeType: attachment.mimeType, data: attachment.data } });
    }
  }

  try {
    const generationBody = JSON.stringify({
      contents: [{ role: "user", parts }],
      generationConfig: {
        responseMimeType: "application/json",
        maxOutputTokens: 8192,
        temperature: 0.65,
        ...(reasoning !== "off"
          ? {
              thinkingConfig: {
                thinkingBudget: reasoning === "deep" ? 24576 : 8192,
              },
            }
          : {}),
      },
    });
    const requestModel = async (modelId: string) => {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=${encodeURIComponent(apiKey)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: generationBody,
        },
      );
      const payload = (await response.json()) as {
        candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
        error?: { message?: string };
      };
      return { response, payload };
    };

    let { response, payload } = await requestModel(MODEL_IDS[model]);
    if (!response.ok && (response.status === 429 || response.status === 500 || response.status === 503)) {
      const fallbackId = STABLE_MODEL_IDS[model];
      if (fallbackId !== MODEL_IDS[model]) {
        req.log.warn({ model, fallbackId }, "Gemini preview model unavailable; using stable fallback");
        ({ response, payload } = await requestModel(fallbackId));
      }
    }
    if (!response.ok) {
      req.log.error({ status: response.status, message: payload.error?.message }, "Gemini request failed");
      res.status(502).json({ error: payload.error?.message ?? "Gemini could not generate this app." });
      return;
    }

    const text = payload.candidates?.[0]?.content?.parts?.map((part) => part.text ?? "").join("") ?? "";
    let result: { title?: string; summary?: string; files?: Array<{ path?: string; content?: string; language?: string }> } = {};
    try {
      result = JSON.parse(cleanJsonFence(text)) as typeof result;
    } catch {
      req.log.warn("Gemini returned non-JSON output; extracting fenced code blocks");
    }

    const files = (result.files?.length ? result.files : parseFallbackFiles(text))
      .map((file) => ({
        path: safePath(file.path ?? "untitled.txt"),
        content: file.content ?? "",
        language: file.language ?? languageForPath(file.path ?? ""),
      }))
      .filter((file) => file.content.length > 0);

    if (!files.length) {
      res.status(502).json({ error: "Gemini returned an empty app. Try a more specific prompt." });
      return;
    }

    const responseData = {
      id: randomUUID(),
      title: result.title?.trim() || "Untitled Halo app",
      summary: result.summary?.trim() || "A functional mini-app generated from your prompt.",
      model,
      files,
      previewHtml: buildPreview(files),
      createdAt: new Date().toISOString(),
    };
    res.json(responseData);
  } catch (error) {
    req.log.error({ err: error }, "Gemini generation threw an error");
    res.status(502).json({ error: "The Gemini request failed. Check your key and try again." });
  }
});

router.post("/gemini/export", (req, res) => {
  const parsed = ExportMiniAppBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "A project name and at least one file are required." });
    return;
  }

  const { projectName, files } = parsed.data;
  const entries = [
    ...files.map((file) => ({
      name: safePath(file.path),
      content: Buffer.from(file.content, "utf8"),
    })),
    {
      name: "halo.json",
      content: Buffer.from(JSON.stringify({ name: projectName, generatedBy: "Halo App Maker" }, null, 2), "utf8"),
    },
  ];
  const archive = makeZip(entries);
  const filename = `${projectName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "halo-app"}.zip`;
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send(archive);
});

export default router;