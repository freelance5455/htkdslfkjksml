<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/credits.php';

try {
    api_guard(['POST']);
    $currentUser = api_require_user();
    $currentUserId = (int)$currentUser['id'];
    $data = json_input();
    $action = (string)($data['action'] ?? '');
    $pdo = db();

    if ($action === 'create') {
        $realtimeRate = billing_price('realtime') ?? 10;
        if (voice_wallet_balance($currentUserId) < $realtimeRate) json_response(['ok'=>false,'error'=>'Your wallet needs at least '.$realtimeRate.' credits before starting a realtime session.'],402);
        if (!decart_ready()) json_response(['ok' => false, 'error' => 'Decart is not configured yet. Add your permanent API key to config.local.php.'], 503);
        if (!empty($_SESSION['remote_sessions'])) json_response(['ok' => false, 'error' => 'This browser already has a realtime session. Stop it or refresh the workspace to clean up an interrupted session.'], 409);
        $lastCreate = (int)($_SESSION['last_session_create'] ?? 0);
        if ($lastCreate > 0 && (time() - $lastCreate) < 3) json_response(['ok' => false, 'error' => 'Please wait a moment before starting another session.'], 429);
        $_SESSION['last_session_create'] = time();
        $model = (string)($data['model'] ?? '');
        if (!in_array($model, DEFAULT_MODELS, true)) json_response(['ok' => false, 'error' => 'Choose Lucy 2.5 or Lucy 2.6.'], 422);
        if (!platform_model_enabled($model)) json_response(['ok'=>false,'error'=>$model.' is currently disabled by the administrator.'],403);
        $sdp = $data['sdp'] ?? null;
        if (!is_array($sdp) || ($sdp['type'] ?? '') !== 'offer' || !is_string($sdp['sdp'] ?? null) || strlen($sdp['sdp']) < 30) {
            json_response(['ok' => false, 'error' => 'A valid WebRTC SDP offer is required.'], 422);
        }
        $prompt = trim((string)($data['prompt'] ?? ''));
        if (app_text_length($prompt) > (int)app_config()['max_prompt_length']) json_response(['ok' => false, 'error' => 'Prompt is too long.'], 422);
        $enhance = (bool)($data['enhance_prompt'] ?? true);
        $payload = ['model' => $model, 'sdp' => ['type' => 'offer', 'sdp' => $sdp['sdp']], 'prompt' => $prompt, 'enhance_prompt' => $enhance];
        $reference = active_reference();
        if ($reference) {
            $payload['image_data'] = reference_base64((string)$reference['id']);
        }
        $result = decart_request('POST', '/realtime/sessions', $payload);
        if (!in_array($result['status'], [200, 201], true)) json_response(['ok' => false, 'error' => decart_error_message($result), 'providerStatus' => $result['status']], $result['status'] >= 400 && $result['status'] < 500 ? $result['status'] : 502);
        $body = $result['body'];
        $remoteId = (string)($body['session_id'] ?? '');
        if (!preg_match('/^rs_[A-Za-z0-9_-]{4,120}$/', $remoteId) || !is_array($body['sdp'] ?? null) || !is_array($body['ice_servers'] ?? null) || !is_array($body['events'] ?? null)) {
            json_response(['ok' => false, 'error' => 'Decart returned an incomplete session response. Check server logs and the Decart API status.'], 502);
        }
        $etag = (string)($result['headers']['etag'] ?? '');
        $_SESSION['remote_sessions'][$remoteId] = ['etag' => $etag, 'model' => $model, 'created_at' => time()];
        $stmt = $pdo->prepare('INSERT INTO realtime_sessions (remote_id, owner_key, model, prompt, status, started_at) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$remoteId, owner_key(), $model, $prompt, 'starting', now_sql()]);
        preference_set('model', $model);
        preference_set('prompt', $prompt);
        preference_set('enhance_prompt', $enhance);
        json_response([
            'ok' => true,
            'session_id' => $remoteId,
            'sdp' => $body['sdp'],
            'ice_servers' => $body['ice_servers'],
            'events' => $body['events'],
            'etag' => $etag,
            'expires_at' => $body['expires_at'] ?? null,
            'reference_attached' => (bool)$reference,
        ]);
    }

    $remoteId = (string)($data['session_id'] ?? '');
    if ($action === 'reconcile') {
        if (!preg_match('/^rs_[A-Za-z0-9_-]{4,120}$/', $remoteId)) json_response(['ok'=>false,'error'=>'Invalid realtime session ID.'],422);
        $q=$pdo->prepare("SELECT billed_seconds FROM realtime_sessions WHERE remote_id=? AND owner_key=? AND status='ended' LIMIT 1");
        $q->execute([$remoteId,owner_key()]); $seconds=$q->fetchColumn();
        if ($seconds === false) json_response(['ok'=>false,'error'=>'Ended realtime session not found.'],404);
        if ($seconds === null) {
            $usage=decart_request('GET','/realtime/sessions/'.rawurlencode($remoteId));
            if ($usage['status']>=200 && $usage['status']<300 && isset($usage['body']['billed_seconds']) && is_numeric($usage['body']['billed_seconds'])) {
                $seconds=max(0,(int)$usage['body']['billed_seconds']);
                $pdo->prepare('UPDATE realtime_sessions SET billed_seconds=? WHERE remote_id=? AND owner_key=?')->execute([$seconds,$remoteId,owner_key()]);
            }
        }
        if ($seconds === null) json_response(['ok'=>false,'error'=>'Decart has not returned provider-measured billed_seconds yet. No estimated charge was applied.'],409);
        $billing=realtime_settle_measured_seconds($remoteId,$currentUserId,(int)$seconds);
        json_response(['ok'=>true,'billing'=>$billing]);
    }
    if ($action === 'end' && !isset($_SESSION['remote_sessions'][$remoteId])) {
        $q=$pdo->prepare("SELECT status,billed_seconds FROM realtime_sessions WHERE remote_id=? AND owner_key=? LIMIT 1");
        $q->execute([$remoteId,owner_key()]); $prior=$q->fetch();
        if ($prior && $prior['status']==='ended') {
            $billing=null;
            if ($prior['billed_seconds']!==null) $billing=realtime_settle_measured_seconds($remoteId,$currentUserId,(int)$prior['billed_seconds']);
            json_response(['ok'=>true,'already_ended'=>true,'billing'=>$billing]);
        }
    }
    $sessionEntry = owned_remote_session($remoteId);
    $sessionPath = '/realtime/sessions/' . rawurlencode($remoteId);

    if ($action === 'ice') {
        $patch = [];
        if (array_key_exists('candidates', $data)) {
            if (!is_array($data['candidates']) || count($data['candidates']) > 20) json_response(['ok' => false, 'error' => 'Invalid ICE candidate batch.'], 422);
            $patch['candidates'] = $data['candidates'];
        }
        if (isset($data['sdp']) && is_array($data['sdp'])) $patch['sdp'] = $data['sdp'];
        if (!$patch) json_response(['ok' => false, 'error' => 'ICE candidates or a restart SDP offer are required.'], 422);
        $ifMatch = isset($patch['sdp']) ? '*' : (string)($sessionEntry['etag'] ?? '');
        if ($ifMatch === '') {
            $current = decart_request('GET', $sessionPath);
            if ($current['status'] >= 400) json_response(['ok' => false, 'error' => decart_error_message($current)], 502);
            $ifMatch = (string)($current['headers']['etag'] ?? '');
        }
        $result = decart_request('PATCH', $sessionPath, $patch, ['If-Match: ' . ($ifMatch !== '' ? $ifMatch : '*')]);
        if ($result['status'] === 412) {
            $current = decart_request('GET', $sessionPath);
            $freshEtag = (string)($current['headers']['etag'] ?? '');
            if ($freshEtag !== '') {
                $result = decart_request('PATCH', $sessionPath, $patch, ['If-Match: ' . $freshEtag]);
            }
        }
        if (!in_array($result['status'], [200, 204], true)) json_response(['ok' => false, 'error' => decart_error_message($result), 'providerStatus' => $result['status']], 502);
        $newEtag = (string)($result['headers']['etag'] ?? $sessionEntry['etag'] ?? '');
        update_remote_session_state($remoteId, ['etag' => $newEtag]);
        json_response(['ok' => true, 'etag' => $newEtag, 'sdp' => $result['body']['sdp'] ?? null]);
    }

    if ($action === 'prompt') {
        $prompt = trim((string)($data['prompt'] ?? ''));
        if ($prompt === '' || app_text_length($prompt) > (int)app_config()['max_prompt_length']) json_response(['ok' => false, 'error' => 'Enter a prompt within the allowed length.'], 422);
        $enhance = (bool)($data['enhance_prompt'] ?? true);
        $result = decart_request('POST', $sessionPath . '/prompt', ['prompt' => $prompt, 'enhance_prompt' => $enhance]);
        if ($result['status'] < 200 || $result['status'] >= 300) json_response(['ok' => false, 'error' => decart_error_message($result), 'providerStatus' => $result['status']], 502);
        $pdo->prepare('UPDATE realtime_sessions SET prompt = ?, status = ? WHERE remote_id = ? AND owner_key = ?')->execute([$prompt, 'active', $remoteId, owner_key()]);
        preference_set('prompt', $prompt);
        preference_set('enhance_prompt', $enhance);
        json_response(['ok' => true, 'prompt' => $prompt]);
    }

    if ($action === 'image') {
        $prompt = trim((string)($data['prompt'] ?? ''));
        if (app_text_length($prompt) > (int)app_config()['max_prompt_length']) json_response(['ok' => false, 'error' => 'Prompt is too long.'], 422);
        $referenceId = (string)($data['reference_id'] ?? '');
        if ($referenceId === '') json_response(['ok' => false, 'error' => 'Upload a reference image first.'], 422);
        $imageData = reference_base64($referenceId);
        $result = decart_request('POST', $sessionPath . '/image', [
            'image_data' => $imageData,
            'prompt' => $prompt,
            'enhance_prompt' => (bool)($data['enhance_prompt'] ?? true),
        ]);
        if ($result['status'] < 200 || $result['status'] >= 300) json_response(['ok' => false, 'error' => decart_error_message($result), 'providerStatus' => $result['status']], 502);
        $pdo->prepare('UPDATE realtime_sessions SET prompt = ?, status = ? WHERE remote_id = ? AND owner_key = ?')->execute([$prompt, 'active', $remoteId, owner_key()]);
        json_response(['ok' => true, 'message' => 'Reference image sent to Decart.']);
    }

    if ($action === 'status') {
        $result = decart_request('GET', $sessionPath);
        if ($result['status'] < 200 || $result['status'] >= 300) json_response(['ok' => false, 'error' => decart_error_message($result)], 502);
        $etag = (string)($result['headers']['etag'] ?? $sessionEntry['etag'] ?? '');
        update_remote_session_state($remoteId, ['etag' => $etag]);
        json_response(['ok' => true, 'session' => $result['body'], 'etag' => $etag]);
    }

    if ($action === 'end') {
        $result = decart_request('DELETE', $sessionPath);
        if ($result['status'] >= 400 && $result['status'] !== 404 && $result['status'] !== 410) {
            json_response(['ok' => false, 'error' => decart_error_message($result), 'providerStatus' => $result['status']], 502);
        }
        $summary = $result['body'];
        if (!isset($summary['billed_seconds']) && $result['status'] >= 200 && $result['status'] < 300) {
            try { $usage=decart_request('GET',$sessionPath); if($usage['status']>=200 && $usage['status']<300 && isset($usage['body']['billed_seconds'])) $summary=$usage['body']; } catch(Throwable $ignored) {}
        }
        $billed = isset($summary['billed_seconds']) && is_numeric($summary['billed_seconds']) ? max(0,(int)$summary['billed_seconds']) : null;
        $pdo->prepare('UPDATE realtime_sessions SET status = ?, ended_at = ?, billed_seconds = ? WHERE remote_id = ? AND owner_key = ?')->execute(['ended', now_sql(), $billed, $remoteId, owner_key()]);
        unset($_SESSION['remote_sessions'][$remoteId]);
        $billing = null;
        if ($billed !== null) $billing = realtime_settle_measured_seconds($remoteId,$currentUserId,$billed);
        json_response(['ok' => true, 'summary' => $summary, 'billing' => $billing]);
    }

    json_response(['ok' => false, 'error' => 'Unknown session action.'], 400);
} catch (Throwable $e) {
    error_log('api/sessions.php failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Realtime session operation failed.'], 500);
}
