const { handle } = require('../lib/proxy');
module.exports = async (req, res) => {
  const r = await handle('verify', req.query || {});
  res.status(r.code).json(r.body);
};
