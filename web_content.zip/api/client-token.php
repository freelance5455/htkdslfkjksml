<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/auth.php';

try {
    api_guard(['POST']);
    api_require_user();
    // SDK retries/reconnects request a fresh short-lived token on every dial.
    app_rate_limit('decart_client_token', 30, 600);
    if (!decart_ready()) json_response(['ok' => false, 'error' => 'Decart is not configured. Add the permanent API key on the server first.'], 503);
    $data = json_input();
    $model = (string)($data['model'] ?? '');
    if (!in_array($model, DEFAULT_MODELS, true)) json_response(['ok' => false, 'error' => 'Choose Lucy 2.5 or Lucy 2.6 for the scoped client token.'], 422);
    if (!platform_model_enabled($model)) json_response(['ok'=>false,'error'=>'This model is currently disabled by the administrator.'],403);
    $payload = ['expiresIn' => 300, 'allowedModels' => [$model]];
    $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin !== '') {
        $scheme = strtolower((string)parse_url($origin, PHP_URL_SCHEME));
        $host = (string)parse_url($origin, PHP_URL_HOST);
        $port = parse_url($origin, PHP_URL_PORT);
        if (!in_array($scheme, ['http', 'https'], true) || $host === '') json_response(['ok' => false, 'error' => 'Invalid browser origin.'], 400);
        $requestHost = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
        if (strtolower($host) !== $requestHost) json_response(['ok'=>false,'error'=>'Browser origin does not match this application.'],403);
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443') || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
        if ($isHttps && $scheme !== 'https') json_response(['ok'=>false,'error'=>'HTTPS origin required.'],403);
        $canonicalOrigin = $scheme . '://' . strtolower($host) . ($port ? ':' . $port : '');
        $payload['allowedOrigins'] = [$canonicalOrigin];
    }
    $result = decart_request('POST', '/client/tokens', $payload);
    if ($result['status'] < 200 || $result['status'] >= 300) json_response(['ok' => false, 'error' => decart_error_message($result), 'providerStatus' => $result['status']], 502);
    if (!is_string($result['body']['apiKey'] ?? null) || $result['body']['apiKey'] === '') json_response(['ok' => false, 'error' => 'Decart returned an incomplete client-token response.'], 502);
    // This is intentionally a short-lived, model-scoped credential. The permanent key stays in PHP.
    json_response(['ok' => true, 'apiKey' => $result['body']['apiKey'], 'expiresAt' => $result['body']['expiresAt'] ?? null, 'model' => $model]);
} catch (Throwable $e) {
    error_log('Decart client-token failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Unable to issue a scoped client token. Please retry.'], 500);
}
