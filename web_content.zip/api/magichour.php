<?php
declare(strict_types=1);
require_once __DIR__.'/../app/magichour.php';
require_once __DIR__.'/../app/auth.php';
try{
    if (function_exists('set_time_limit')) { @set_time_limit(0); }
    @ini_set('max_input_time', '0');
    $method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
    if($method==='POST'){
        api_guard(['POST']);$user=api_require_user();
        if(!mh_ready())json_response(['ok'=>false,'error'=>'Magic Hour Lip Sync is not enabled.'],503);
        if(empty($_FILES['video'])||empty($_FILES['audio'])){
            $postMax=mh_ini_bytes((string)ini_get('post_max_size'));$contentLength=(int)($_SERVER['CONTENT_LENGTH']??0);
            if($postMax>0&&$contentLength>$postMax)json_response(['ok'=>false,'error'=>'The combined upload exceeds this host PHP post_max_size of '.ini_get('post_max_size').'. Reduce file sizes or ask the hosting provider to raise the limit.'],413);
            json_response(['ok'=>false,'error'=>'Choose both a source video and replacement audio. Check the host upload limits.'],422);
        }
        $video=mh_validate_upload($_FILES['video'],'video');$audio=mh_validate_upload($_FILES['audio'],'audio');
        $settings=['name'=>trim((string)($_POST['name']??'')),'mode'=>(string)($_POST['mode']??''),'start'=>(float)($_POST['start_seconds']??0),'end'=>(float)($_POST['end_seconds']??5),'fps'=>(float)($_POST['fps']??12)];
        $result=mh_create_job($video,$audio,$settings,(int)$user['id'],(string)($_POST['request_key']??''));
        json_response(['ok'=>true,'jobId'=>$result['jobId'],'status'=>'submitted','creditsCharged'=>$result['creditsCharged'],'duplicate'=>(bool)($result['duplicate']??false)]);
    }
    if($method==='GET'){
        api_guard(['GET']);api_require_user();
        if((string)($_GET['limits']??'')==='1'){
            $cfg=app_config();
            $upload=mh_ini_bytes((string)ini_get('upload_max_filesize'));
            $post=mh_ini_bytes((string)ini_get('post_max_size'));
            $video=(int)($cfg['max_video_bytes']??104857600);
            $audio=(int)($cfg['max_audio_bytes']??31457280);
            if($upload>0){$video=min($video,$upload);$audio=min($audio,$upload);}
            if($post>0){$video=min($video,max(0,$post-1048576));$audio=min($audio,max(0,$post-1048576));}
            json_response(['ok'=>true,'videoMaxBytes'=>$video,'audioMaxBytes'=>$audio,'postMaxBytes'=>$post,'uploadMaxBytes'=>$upload]);
        }
        $id=(string)($_GET['id']??'');if(!preg_match('/^[a-f0-9]{32}$/',$id))json_response(['ok'=>false,'error'=>'Invalid Lip Sync job ID.'],400);
        $job=mh_sync_job($id);
        $meta=json_decode((string)$job['metadata'],true);if(!is_array($meta))$meta=[];
        json_response(['ok'=>true,'jobId'=>$id,'status'=>$job['status'],'providerStatus'=>$meta['provider_status']??null,'error'=>$job['error_message'],'outputUrl'=>$job['status']==='completed'?'api/media.php?id='.rawurlencode($id).'&kind=output':null]);
    }
    json_response(['ok'=>false,'error'=>'Method not allowed.'],405);
}catch(InvalidArgumentException $e){json_response(['ok'=>false,'error'=>$e->getMessage()],422);}
catch(Throwable $e){error_log('Magic Hour API failure: '.get_class($e).' '.$e->getMessage());json_response(['ok'=>false,'error'=>$e->getMessage()],502);}
