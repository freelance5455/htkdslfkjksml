<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/platform.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/credits.php';
$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
$input=null; $ref=null; $jobId=null; $reserved=false; $providerAttempted=false; $safeRefund=true; $dirs=null;
try {
    if($method==='POST'){
        api_guard(['POST']);
        $user=api_require_user();
        app_rate_limit('video_generation', 5, 600);
        if(!decart_ready()) throw new RuntimeException('Decart API key is not configured. Add it to private config.local.php.');
        if(!extension_loaded('curl')) throw new RuntimeException('PHP cURL extension is required for Decart requests.');
        if(!isset($_FILES['data'])) json_response(['ok'=>false,'error'=>'Upload a source video first.'],422);
        $price=billing_price('video');
        if($price===null) json_response(['ok'=>false,'error'=>'Video generation pricing has not been configured by an administrator.'],503);
        $model=(string)($_POST['model']??'lucy-2.5');
        if(!in_array($model,['lucy-2.5','lucy-2.6'],true)) json_response(['ok'=>false,'error'=>'Unsupported video model.'],422);
        if(!platform_model_enabled($model)) json_response(['ok'=>false,'error'=>$model.' is currently disabled by the administrator.'],403);
        $prompt=trim((string)($_POST['prompt']??''));
        if($prompt==='' || (function_exists('mb_strlen')?mb_strlen($prompt):strlen($prompt))>2000) json_response(['ok'=>false,'error'=>'Enter a prompt of 1–2000 characters.'],422);
        $resolution=(string)($_POST['resolution']??'720p');
        if($resolution!=='720p') json_response(['ok'=>false,'error'=>'The configured Lucy batch-video workflow currently exposes 720p only.'],422);
        $input=platform_upload($_FILES['data'],'video'); $dirs=platform_dirs(); $ref=null;
        if(isset($_FILES['reference_image']) && (int)($_FILES['reference_image']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){
            $ref=platform_upload($_FILES['reference_image'],'image');
            $from=$dirs['inputs'].'/'.$ref['disk']; $to=bin2hex(random_bytes(18)).'.'.$ref['disk'];
            if(!rename($from,$dirs['references'].'/'.$to)) throw new RuntimeException('Could not store reference image.');
            $ref['disk']=$to;
        }
        $seed=trim((string)($_POST['seed']??''));
        if($seed!==''&&(!ctype_digit($seed)||(int)$seed>4294967295)) throw new InvalidArgumentException('Seed must be between 0 and 4294967295.');
        $jobId=bin2hex(random_bytes(16));
        billing_reserve((int)$user['id'],'video',$jobId,$price); $reserved=true;
        platform_store_job(['id'=>$jobId,'workspace'=>'video','model'=>$model,'prompt'=>$prompt,'status'=>'submitted','input_disk'=>$input['disk'],'reference_disk'=>$ref['disk']??null,'resolution'=>$resolution,'metadata'=>['billing_state'=>'reserved','credits'=>$price,'submission_state'=>'pending']]);
        $fields=['data'=>new CURLFile($dirs['inputs'].'/'.$input['disk'],$input['mime'],'source.'.$input['disk']),'prompt'=>$prompt,'resolution'=>$resolution,'enhance_prompt'=>filter_var($_POST['enhance_prompt']??'true',FILTER_VALIDATE_BOOLEAN)?'true':'false'];
        if($ref)$fields['reference_image']=new CURLFile($dirs['references'].'/'.$ref['disk'],$ref['mime'],'reference.'.$ref['disk']);
        if($seed!=='')$fields['seed']=(string)(int)$seed;
        if(isset($_POST['self_anchor']))$fields['self_anchor']=filter_var($_POST['self_anchor'],FILTER_VALIDATE_BOOLEAN)?'true':'false';
        $cfg=app_config(); $base=rtrim((string)$cfg['decart_api_base'],'/');
        $providerAttempted=true; $safeRefund=false;
        $res=decart_platform_curl('POST',$base.'/jobs/'.$model,['Accept: application/json'],$fields,180);
        if($res['status']<200||$res['status']>=300){
            $safeRefund=$res['status']>=400&&$res['status']<500;
            $message=$safeRefund?platform_provider_error($res):'Provider submission outcome is uncertain (HTTP '.(int)$res['status'].'). Credits remain reserved; do not submit a duplicate until the original request is reconciled.';
            if($safeRefund){
                billing_refund($jobId,'Video generation provider rejection refund');
                db()->prepare("UPDATE platform_jobs SET status='failed',error_message=?,input_disk='',reference_disk=NULL,updated_at=? WHERE id=? AND owner_key=?")->execute([$message,now_sql(),$jobId,owner_key()]);
                @unlink($dirs['inputs'].'/'.$input['disk']); if($ref)@unlink($dirs['references'].'/'.$ref['disk']);
            } else {
                db()->prepare('UPDATE platform_jobs SET error_message=?,updated_at=? WHERE id=? AND owner_key=?')->execute([$message,now_sql(),$jobId,owner_key()]);
            }
            json_response(['ok'=>false,'jobId'=>$jobId,'status'=>$safeRefund?'failed':'submitted','error'=>$message,'creditsReserved'=>$price],$safeRefund?502:504);
        }
        $body=json_decode($res['body'],true); $providerId=is_array($body)?(string)($body['job_id']??$body['id']??''):'';
        if($providerId===''||!preg_match('/^[A-Za-z0-9._:-]{1,120}$/',$providerId)){
            $message='Decart accepted a response without a recognizable job ID. Credits remain reserved for manual reconciliation; do not resubmit this job.';
            db()->prepare('UPDATE platform_jobs SET error_message=?,updated_at=? WHERE id=? AND owner_key=?')->execute([$message,now_sql(),$jobId,owner_key()]);
            json_response(['ok'=>false,'jobId'=>$jobId,'status'=>'submitted','error'=>$message,'creditsReserved'=>$price],502);
        }
        db()->prepare('UPDATE platform_jobs SET provider_job_id=?,metadata=?,updated_at=? WHERE id=? AND owner_key=?')
            ->execute([$providerId,json_encode(['provider_status'=>$body['status']??'pending','credits'=>$price,'billing_state'=>'reserved']),now_sql(),$jobId,owner_key()]);
        json_response(['ok'=>true,'jobId'=>$jobId,'status'=>'submitted','providerStatus'=>$body['status']??'pending','creditsReserved'=>$price]);
    }
    if($method==='GET'){
        api_guard(['GET']); api_require_user();
        $id=(string)($_GET['id']??''); $job=platform_owned_job($id);
        if($job['workspace']!=='video') json_response(['ok'=>false,'error'=>'This is not a video job.'],400);
        if(in_array($job['status'],['submitted','processing'],true) && !empty($job['provider_job_id'])){
            $created=strtotime((string)($job['created_at']??''))?:time();
            $timeout=max(600,(int)(app_config()['video_job_timeout_seconds']??7200));
            if(time()-$created>$timeout){
                db()->prepare("UPDATE platform_jobs SET status='expired',error_message=?,updated_at=? WHERE id=? AND owner_key=? AND status IN ('submitted','processing')")->execute(['Provider job exceeded the configured processing timeout. Credit reservation retained pending reconciliation.',now_sql(),$id,owner_key()]);
                $job=platform_owned_job($id);
            } else {
                $cfg=app_config(); $base=rtrim((string)$cfg['decart_api_base'],'/');
                $statusRes=decart_platform_curl('GET',$base.'/jobs/'.rawurlencode((string)$job['provider_job_id']),['Accept: application/json'],null,45);
                if($statusRes['status']>=200&&$statusRes['status']<300){
                    $data=json_decode($statusRes['body'],true); $st=strtolower((string)($data['status']??''));
                    if(in_array($st,['pending','queued','submitted'],true)) $new='submitted';
                    elseif(in_array($st,['processing','running'],true)) $new='processing';
                    elseif(in_array($st,['failed','error','cancelled','canceled'],true)){
                        billing_refund($id,'Video generation confirmed provider failure refund');
                        $new='failed';
                        $dirs=platform_dirs();
                        if(!empty($job['input_disk'])) @unlink($dirs['inputs'].'/'.basename((string)$job['input_disk']));
                        if(!empty($job['reference_disk'])) @unlink($dirs['references'].'/'.basename((string)$job['reference_disk']));
                        db()->prepare('UPDATE platform_jobs SET input_disk=\'\',reference_disk=NULL,status=?,error_message=?,updated_at=? WHERE id=? AND owner_key=?')->execute([$new,substr((string)($data['error']??$data['message']??'Provider reported job failure.'),0,500),now_sql(),$id,owner_key()]);
                    } elseif($st==='completed'){
                        $content=decart_platform_curl('GET',$base.'/jobs/'.rawurlencode((string)$job['provider_job_id']).'/content',['Accept: video/mp4, video/webm, application/octet-stream'],null,180);
                        if($content['status']>=200&&$content['status']<300&&(str_starts_with($content['content_type'],'video/')||str_starts_with($content['content_type'],'application/octet-stream'))&&(str_starts_with($content['body'],"\x1A\x45\xDF\xA3")||(strlen($content['body'])>8&&substr($content['body'],4,4)==='ftyp'))){
                            $isWebm=str_starts_with($content['body'],"\x1A\x45\xDF\xA3"); $ext=$isWebm?'webm':'mp4'; $disk=$id.'.'.$ext; $path=platform_dirs()['outputs'].'/'.$disk;
                            if(!str_starts_with($content['content_type'],'video/')) $content['content_type']=$isWebm?'video/webm':'video/mp4';
                            $outputBytes=strlen($content['body']); $quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));
                            if(platform_storage_used_bytes(owner_key())+$outputBytes>$quota){
                                billing_refund($id,'Video output storage failure refund');
                                $new='failed'; $err='Provider completed the job, but output exceeded your account storage quota. Reserved credits were refunded.';
                                $dirs=platform_dirs(); if(!empty($job['input_disk']))@unlink($dirs['inputs'].'/'.basename((string)$job['input_disk'])); if(!empty($job['reference_disk']))@unlink($dirs['references'].'/'.basename((string)$job['reference_disk']));
                                db()->prepare("UPDATE platform_jobs SET status='failed',input_disk='',reference_disk=NULL,output_disk=NULL,output_mime=NULL,output_bytes=NULL,error_message=?,updated_at=? WHERE id=? AND owner_key=?")->execute([$err,now_sql(),$id,owner_key()]);
                            } elseif(file_put_contents($path,$content['body'],LOCK_EX)!==false){
                                try {
                                    platform_save_asset($id,$disk,$content['content_type'],'video','Lucy video output.'.$ext);
                                    db()->prepare("UPDATE platform_jobs SET status='completed',output_disk=?,output_mime=?,output_bytes=?,updated_at=? WHERE id=? AND owner_key=?")->execute([$disk,$content['content_type'],$outputBytes,now_sql(),$id,owner_key()]);
                                    billing_settle($id);
                                    $new='completed';
                                } catch(Throwable $persistError) {
                                    db()->prepare('DELETE FROM platform_assets WHERE job_id=? AND owner_key=?')->execute([$id,owner_key()]);
                                    @unlink($path);
                                    billing_refund($id,'Video output persistence failure refund');
                                    $new='failed'; $err='Video output could not be committed to your history. Reserved credits were refunded.';
                                    db()->prepare("UPDATE platform_jobs SET status='failed',input_disk='',reference_disk=NULL,output_disk=NULL,output_mime=NULL,output_bytes=NULL,error_message=?,updated_at=? WHERE id=? AND owner_key=?")->execute([$err,now_sql(),$id,owner_key()]);
                                    $dirs=platform_dirs(); if(!empty($job['input_disk']))@unlink($dirs['inputs'].'/'.basename((string)$job['input_disk'])); if(!empty($job['reference_disk']))@unlink($dirs['references'].'/'.basename((string)$job['reference_disk']));
                                }
                            } else $new='processing';
                        } else {
                            billing_refund($id,'Invalid completed video output refund');
                            $new='failed'; $err='Provider completed the job but returned invalid or unavailable video content. Reserved credits were refunded.';
                            db()->prepare("UPDATE platform_jobs SET status='failed',input_disk='',reference_disk=NULL,output_disk=NULL,output_mime=NULL,output_bytes=NULL,error_message=?,updated_at=? WHERE id=? AND owner_key=?")->execute([$err,now_sql(),$id,owner_key()]);
                            $dirs=platform_dirs(); if(!empty($job['input_disk']))@unlink($dirs['inputs'].'/'.basename((string)$job['input_disk'])); if(!empty($job['reference_disk']))@unlink($dirs['references'].'/'.basename((string)$job['reference_disk']));
                        }
                    } else $new=$job['status'];
                    if($new!=='completed' && $new!=='failed' && $new!=='expired'){
                        db()->prepare('UPDATE platform_jobs SET status=?,error_message=NULL,updated_at=? WHERE id=? AND owner_key=?')->execute([$new,now_sql(),$id,owner_key()]);
                    }
                } elseif($statusRes['status']>=400&&$statusRes['status']<500) {
                    // A status endpoint 4xx is not proof that the billable job failed; retain the reservation.
                    db()->prepare('UPDATE platform_jobs SET error_message=?,updated_at=? WHERE id=? AND owner_key=?')->execute(['Provider status lookup returned HTTP '.$statusRes['status'].'. Credit reservation retained.',now_sql(),$id,owner_key()]);
                }
                $job=platform_owned_job($id);
            }
        }
        $op=billing_operation($id);
        json_response(['ok'=>true,'jobId'=>$id,'status'=>$job['status'],'error'=>$job['error_message'],'creditsState'=>$op['state']??null,'outputUrl'=>$job['status']==='completed'?'api/media.php?id='.$id.'&kind=output':null]);
    }
    api_guard(['GET']); json_response(['ok'=>false,'error'=>'Method not allowed.'],405);
} catch(Throwable $e){
    if($method==='POST' && $reserved && $safeRefund && $jobId!==null){
        try{billing_refund($jobId,'Video generation failure refund');}catch(Throwable $re){error_log('Video refund failure '.$jobId.': '.get_class($re));}
        if($dirs && $input){@unlink($dirs['inputs'].'/'.$input['disk']);}
        if($dirs && $ref){@unlink($dirs['references'].'/'.$ref['disk']);}
        try{db()->prepare("UPDATE platform_jobs SET status='failed',input_disk='',reference_disk=NULL,output_disk=NULL,output_mime=NULL,output_bytes=NULL,error_message=?,updated_at=? WHERE id=? AND owner_key=?")->execute(['Video submission failed; reserved credits refunded where eligible.',now_sql(),$jobId,owner_key()]);}catch(Throwable $ignored){}
    } elseif($method==='POST' && $reserved && $jobId!==null){
        try{db()->prepare('UPDATE platform_jobs SET error_message=?,updated_at=? WHERE id=? AND owner_key=?')->execute(['Provider outcome uncertain; credits remain reserved for reconciliation.',now_sql(),$jobId,owner_key()]);}catch(Throwable $ignored){}
    }
    error_log('Video jobs endpoint failure: '.get_class($e).' '.substr($e->getMessage(),0,300));
    json_response(['ok'=>false,'jobId'=>$jobId,'error'=>'Video job request failed. '.($reserved&&!$safeRefund?'The provider outcome is uncertain; credits remain reserved.':'Please retry after checking your job history.')],$e instanceof InvalidArgumentException?422:500);
}
