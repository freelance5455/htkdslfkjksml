<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
require_once __DIR__.'/../backend/store.php';
function out($data,int $status=200): never { http_response_code($status); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function input(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:[]; }
function needUser(): array { if(empty($_SESSION['user_id'])) out(['ok'=>false,'error'=>'Faça login novamente.'],401); $s=storeRead(); foreach($s['users'] as $u)if($u['id']===$_SESSION['user_id'])return $u; session_destroy();out(['ok'=>false,'error'=>'Sessão inválida.'],401); }
function safeUser($u): array { return ['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email']]; }
$action=$_GET['action']??'';
if($_SERVER['REQUEST_METHOD']==='POST' && !in_array($action,['login','register','logout','send'],true)) out(['ok'=>false,'error'=>'Método não permitido'],405);
if($action==='register'){
 $d=input();$name=trim((string)($d['name']??''));$email=strtolower(trim((string)($d['email']??'')));$pass=(string)($d['password']??'');
 if(mb_strlen($name)<2||mb_strlen($name)>40||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<8||strlen($pass)>200)out(['ok'=>false,'error'=>'Informe nome, e-mail válido e senha de 8 a 200 caracteres.'],422);
 $s=storeRead();foreach($s['users'] as $u)if($u['email']===$email)out(['ok'=>false,'error'=>'Este e-mail já está cadastrado.'],409);
 $u=['id'=>bin2hex(random_bytes(8)),'name'=>$name,'email'=>$email,'password_hash'=>password_hash($pass,PASSWORD_DEFAULT),'created_at'=>time()];$s['users'][]=$u;storeWrite($s);session_regenerate_id(true);$_SESSION['user_id']=$u['id'];out(['ok'=>true,'user'=>safeUser($u)]);
}
if($action==='login'){
 $d=input();$email=strtolower(trim((string)($d['email']??'')));$pass=(string)($d['password']??'');$s=storeRead();
 foreach($s['users'] as $u)if($u['email']===$email&&password_verify($pass,$u['password_hash'])){session_regenerate_id(true);$_SESSION['user_id']=$u['id'];out(['ok'=>true,'user'=>safeUser($u)]);}
 out(['ok'=>false,'error'=>'E-mail ou senha incorretos.'],401);
}
if($action==='logout'){$_SESSION=[];if(ini_get('session.use_cookies')){ $p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);}session_destroy();out(['ok'=>true]);}
$me=needUser();$s=storeRead();
if($action==='me')out(['ok'=>true,'user'=>safeUser($me)]);
if($action==='contacts'){
 $out=[];foreach($s['users'] as $u){if($u['id']===$me['id'])continue;$last=null;foreach($s['messages'] as $m)if(($m['sender_id']===$me['id']&&$m['recipient_id']===$u['id'])||($m['sender_id']===$u['id']&&$m['recipient_id']===$me['id']))if(!$last||$m['created_at']>$last['created_at'])$last=$m;$out[]=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'last_message'=>$last?mb_strimwidth($last['text'],0,45,'…'):'Comece uma conversa'];}
 usort($out,fn($a,$b)=>strcmp($a['name'],$b['name']));out(['ok'=>true,'users'=>$out]);
}
if($action==='messages'){
 $other=(string)($_GET['with']??'');if(!$other||$other===$me['id'])out(['ok'=>false,'error'=>'Contato inválido.'],422);
 $exists=false;foreach($s['users'] as $u)if($u['id']===$other)$exists=true;if(!$exists)out(['ok'=>false,'error'=>'Contato não encontrado.'],404);
 $out=array_values(array_filter($s['messages'],fn($m)=>($m['sender_id']===$me['id']&&$m['recipient_id']===$other)||($m['sender_id']===$other&&$m['recipient_id']===$me['id'])));
 usort($out,fn($a,$b)=>$a['created_at']<=>$b['created_at']);out(['ok'=>true,'messages'=>$out]);
}
if($action==='send'){
 $d=input();$to=(string)($d['to']??'');$text=trim((string)($d['text']??''));if(!$to||$to===$me['id']||$text===''||mb_strlen($text)>4000)out(['ok'=>false,'error'=>'Mensagem ou destinatário inválido (máximo 4000 caracteres).'],422);
 $valid=false;foreach($s['users'] as $u)if($u['id']===$to)$valid=true;if(!$valid)out(['ok'=>false,'error'=>'Destinatário não encontrado.'],404);
 $m=['id'=>bin2hex(random_bytes(10)),'sender_id'=>$me['id'],'recipient_id'=>$to,'text'=>$text,'created_at'=>time()];$s['messages'][]=$m;storeWrite($s);out(['ok'=>true,'message'=>$m],201);
}
out(['ok'=>false,'error'=>'Endpoint não encontrado.'],404);
