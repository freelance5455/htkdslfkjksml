<?php
declare(strict_types=1);
require_once __DIR__.'/../app/auth.php';
require_once __DIR__.'/../app/payments.php';
try {
    $method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
    if($method==='POST'){
        api_guard(['POST']);$user=api_require_user();$data=json_input();$packageId=(int)($data['package_id']??0);
        $result=payment_create_order((int)$user['id'],$packageId);json_response(['ok'=>true]+$result);
    }
    if($method==='GET'){
        api_guard(['GET']);$user=api_require_user();$ref=(string)($_GET['tx_ref']??'');$tx=(string)($_GET['transaction_id']??'');
        if($ref===''||$tx==='')json_response(['ok'=>false,'error'=>'Payment verification details are missing.'],422);
        $result=payment_verify_and_credit($ref,$tx,(int)$user['id']);json_response($result);
    }
    json_response(['ok'=>false,'error'=>'Method not allowed.'],405);
} catch(InvalidArgumentException $e){json_response(['ok'=>false,'error'=>$e->getMessage()],422);}
catch(Throwable $e){error_log('Payment API: '.get_class($e).' '.$e->getMessage());json_response(['ok'=>false,'error'=>$e->getMessage()],502);}
