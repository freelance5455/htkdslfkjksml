/**
 * RAYNOX AI — Serverless Chat Endpoint (/api/chat)
 * Delegates directly to the main server.js request handler.
 */
const requestHandler = require("../server.js");

module.exports = async function handler(req, res) {
  req.url = "/api/chat";
  return requestHandler(req, res);
};
