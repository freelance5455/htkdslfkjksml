const OpenAI = require("openai");

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

module.exports = async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });
  }

  try {
    const body = req.body || {};
    const message = String(body.message || "").trim();

    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const studyMode = Boolean(body.study_mode);
    const webSearch = Boolean(body.web_search);

    let instructions =
      "You are Genius Bharat AI, a helpful AI assistant for users in India. " +
      "Answer clearly and accurately. You can reply in Hindi, English, or Hinglish based on the user's language.";

    if (studyMode) {
      instructions += " Study mode is enabled: explain step-by-step, at an appropriate student level, and show working for academic questions.";
    }

    if (webSearch) {
      instructions += " The user requested web search, but this basic backend does not perform live web browsing. Do not claim that you searched the web.";
    }

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      instructions,
      input: message,
    });

    return res.status(200).json({
      reply: response.output_text || "I couldn't generate a response.",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error: "AI request failed.",
      details: error && error.message ? error.message : String(error),
    });
  }
};
