<?php
declare(strict_types=1);
require_once __DIR__.'/../app/payments.php';
try {
    if(strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'))!=='POST'){http_response_code(405);exit;}
    $cfg=payment_gateway_config();$provided=(string)($_SERVER['HTTP_VERIF_HASH']??'');
    if($cfg['webhook_hash']===''||$provided===''||!hash_equals($cfg['webhook_hash'],$provided)){http_response_code(401);exit('Invalid signature');}
    $body=json_decode((string)file_get_contents('php://input'),true);
    if(!is_array($body)){http_response_code(400);exit('Invalid payload');}
    $data=$body['data']??[];$reference=(string)($data['tx_ref']??'');$tx=(string)($data['id']??'');
    if($reference===''||$tx===''){http_response_code(200);exit('Ignored');}
    payment_verify_and_credit($reference,$tx,null);
    http_response_code(200);echo 'OK';
} catch(Throwable $e){error_log('Flutterwave webhook: '.get_class($e).' '.$e->getMessage());http_response_code(500);echo 'Retry';}
