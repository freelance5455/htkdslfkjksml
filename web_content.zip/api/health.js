/**
 * RAYNOX AI — Serverless Health Endpoint (/api/health)
 * Delegates directly to the main server.js request handler.
 */
const requestHandler = require("../server.js");

module.exports = async function handler(req, res) {
  req.url = req.url && req.url.startsWith("/api/") ? req.url : `/api/health${req.url && req.url.includes("?") ? req.url.slice(req.url.indexOf("?")) : ""}`;
  return requestHandler(req, res);
};
