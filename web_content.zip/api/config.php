<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/auth.php';
api_guard(['GET']);
api_require_user();
try {
    $prefs = [
        'model' => preference_get('model', 'lucy-2.6'),
        'prompt' => preference_get('prompt', ''),
        'enhance_prompt' => preference_get('enhance_prompt', true),
    ];
    $models = array_values(array_filter([
        platform_model_enabled('lucy-2.5') ? ['id'=>'lucy-2.5','label'=>'Lucy 2.5','description'=>'Pinned realtime editing model'] : null,
        platform_model_enabled('lucy-2.6') ? ['id'=>'lucy-2.6','label'=>'Lucy 2.6','description'=>'Latest realtime editing model'] : null,
    ]));
    $transport = 'http-signaling'; // Server-signaled sessions are required for trusted billed_seconds reconciliation.
    json_response([
        'ok' => true,
        'configured' => decart_ready(),
        'models' => $models,
        'defaultModel' => $models[0]['id'] ?? null,
        'preferences' => $prefs,
        'reference' => active_reference(),
        'csrfToken' => csrf_token(),
        'transport' => $transport,
        'apiMode' => $transport === 'http-signaling' ? 'HTTP Signaling (private preview) + direct WebRTC media' : 'Decart SDK Direct + browser WebRTC',
        'activeSessions' => array_map(static fn($id, $entry) => ['id' => $id, 'model' => $entry['model'] ?? ''], array_keys($_SESSION['remote_sessions']), array_values($_SESSION['remote_sessions'])),
    ]);
} catch (Throwable $e) {
    error_log('api/config.php failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Configuration could not be loaded.'], 500);
}
