<?php
declare(strict_types=1);
session_start();
const DB_HOST='localhost';
const DB_NAME='crime_russia';
const DB_USER='YOUR_MYSQL_USER';
const DB_PASS='YOUR_MYSQL_PASSWORD';
function db():PDO{
 static $p;
 if($p instanceof PDO)return $p;
 $p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 return $p;
}
function auth():void{if(empty($_SESSION['admin_id'])){http_response_code(401);exit(json_encode(['error'=>'unauthorized']));}}
function json_out($x):void{header('Content-Type: application/json; charset=utf-8');echo json_encode($x,JSON_UNESCAPED_UNICODE);}
