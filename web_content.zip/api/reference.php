<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/platform.php';
require_once __DIR__ . '/../app/auth.php';

try {
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $action = (string)($_GET['action'] ?? ($method === 'POST' ? 'upload' : 'current'));

    if ($method === 'GET' && $action === 'preview') {
        api_require_user();
        $id = (string)($_GET['id'] ?? '');
        [, $path] = owned_reference_file($id);
        $stmt = db()->prepare('SELECT mime_type FROM reference_uploads WHERE id = ? AND owner_key = ?');
        $stmt->execute([$id, owner_key()]);
        $mime = (string)$stmt->fetchColumn();
        header('Content-Type: ' . $mime);
        header('Cache-Control: private, max-age=300');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    api_guard(['GET', 'POST', 'DELETE']);
    api_require_user();
    if ($method === 'GET' && $action === 'current') json_response(['ok' => true, 'reference' => active_reference()]);

    if ($method === 'POST' && $action === 'upload') {
        if (!isset($_FILES['reference_image']) || !is_array($_FILES['reference_image'])) json_response(['ok' => false, 'error' => 'Choose an image to upload.'], 422);
        $file = $_FILES['reference_image'];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) json_response(['ok' => false, 'error' => 'The image upload failed (code ' . (int)$file['error'] . ').'], 422);
        $max = (int)app_config()['max_reference_bytes'];
        if ((int)$file['size'] < 1 || (int)$file['size'] > $max) json_response(['ok' => false, 'error' => 'Reference images must be no larger than ' . round($max / 1024 / 1024) . ' MB.'], 413);
        $tmp = (string)$file['tmp_name'];
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($tmp) ?: '';
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($allowed[$mime])) json_response(['ok' => false, 'error' => 'Only JPEG, PNG, and WebP images are supported.'], 415);
        $imageInfo = @getimagesize($tmp);
        if (!$imageInfo || (int)$imageInfo[0] < 1 || (int)$imageInfo[1] < 1) json_response(['ok' => false, 'error' => 'The uploaded file is not a valid image.'], 422);
        $width = (int)$imageInfo[0];
        $height = (int)$imageInfo[1];
        if ($width > 12000 || $height > 12000 || ($width * $height) > 60000000) json_response(['ok' => false, 'error' => 'Image dimensions are too large. Resize the image and try again.'], 422);

        // Replacing the single current reference must not count the old file twice.
        $existing = db()->prepare('SELECT disk_name FROM reference_uploads WHERE owner_key = ?');
        $existing->execute([owner_key()]);
        $oldReferenceBytes = 0;
        foreach ($existing->fetchAll(PDO::FETCH_COLUMN) as $oldDisk) {
            $oldPath = APP_ROOT . '/storage/references/' . basename((string)$oldDisk);
            if (is_file($oldPath) && !is_link($oldPath)) $oldReferenceBytes += (int)filesize($oldPath);
        }
        $quota = max(1, (int)(app_config()['max_storage_per_user_bytes'] ?? 1073741824));
        $usedWithoutOldReference = max(0, platform_storage_used_bytes(owner_key()) - $oldReferenceBytes);
        if ($usedWithoutOldReference + (int)$file['size'] > $quota) {
            json_response(['ok' => false, 'error' => 'Your account storage quota has been reached. Delete older assets before uploading another reference.'], 413);
        }

        $dir = APP_ROOT . '/storage/references';
        if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Cannot create the private reference-image directory.');
        $id = bin2hex(random_bytes(16));
        $diskName = $id . '.' . $allowed[$mime];
        if (!move_uploaded_file($tmp, $dir . '/' . $diskName)) throw new RuntimeException('Could not save the uploaded reference image. Check storage permissions.');
        $oldFiles = db()->prepare('SELECT disk_name FROM reference_uploads WHERE owner_key = ?');
        $oldFiles->execute([owner_key()]);
        foreach ($oldFiles->fetchAll(PDO::FETCH_COLUMN) as $oldName) @unlink($dir . '/' . basename((string)$oldName));
        db()->prepare('DELETE FROM reference_uploads WHERE owner_key = ?')->execute([owner_key()]);
        $stmt = db()->prepare('INSERT INTO reference_uploads (id, owner_key, disk_name, original_name, mime_type, file_size, width, height, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)');
        $stmt->execute([$id, owner_key(), $diskName, secure_filename((string)$file['name']), $mime, (int)$file['size'], $width, $height, now_sql()]);
        preference_set('active_reference_id', $id);
        $reference = active_reference();
        json_response(['ok' => true, 'reference' => $reference, 'warning' => ($width < 512 || $height < 512) ? 'For best results Decart recommends a reference image of at least 512 × 512 pixels.' : null]);
    }

    if (($method === 'POST' || $method === 'DELETE') && $action === 'delete') {
        $stmt = db()->prepare('SELECT disk_name FROM reference_uploads WHERE owner_key = ?');
        $stmt->execute([owner_key()]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $diskName) @unlink(APP_ROOT . '/storage/references/' . basename((string)$diskName));
        db()->prepare('DELETE FROM reference_uploads WHERE owner_key = ?')->execute([owner_key()]);
        preference_set('active_reference_id', null);
        json_response(['ok' => true, 'message' => 'Reference image removed.']);
    }
    json_response(['ok' => false, 'error' => 'Unknown reference-image action.'], 400);
} catch (Throwable $e) {
    error_log('Reference endpoint failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Reference image operation failed. Please retry.'], 500);
}
