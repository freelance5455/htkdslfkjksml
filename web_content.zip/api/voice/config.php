<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/voice.php';
api_guard(['GET']);
api_require_user();
json_response(['ok'=>true,'configured'=>fish_audio_ready(),'model'=>'s2.1-pro-free','defaultVoice'=>voice_setting('default_voice'),'preferredVoice'=>(string)(preference_get('voice_selected_reference_id','')??''),'defaultSpeed'=>max(0.7,min(1.3,(float)voice_setting('default_speed','1'))),'csrfToken'=>csrf_token(),'maxCharacters'=>5000,'voiceLibraryEndpoint'=>'api/voice/voices.php','voiceLibraryPageSize'=>100,'creditsBalance'=>voice_wallet_balance((int)auth_user()['id']),'creditsPer100Chars'=>max(0,(int)voice_setting('credits_per_100_chars','1')),'creditsPerClone'=>max(0,(int)voice_setting('credits_per_voice_clone','100'))]);
