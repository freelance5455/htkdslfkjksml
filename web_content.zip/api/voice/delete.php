<?php
declare(strict_types=1);
require_once __DIR__.'/../../app/voice.php';
api_guard(['POST']); $user=api_require_user(); $data=json_input();
try { fish_audio_delete_private_voice((int)$user['id'],trim((string)($data['voice_id']??''))); json_response(['ok'=>true,'message'=>'Private voice deleted.']); }
catch(InvalidArgumentException $e) { json_response(['ok'=>false,'error'=>$e->getMessage()],422); }
catch(Throwable $e) { error_log('Fish Audio voice delete failed: '.get_class($e)); json_response(['ok'=>false,'error'=>$e->getMessage()],502); }
