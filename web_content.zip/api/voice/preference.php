<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/voice.php';
api_guard(['POST']);
api_require_user();
$data=json_input();
$voice=trim((string)($data['voice_id']??''));
if($voice!=='' && (strlen($voice)>120 || !preg_match('/^[A-Za-z0-9_-]{6,120}$/',$voice))) {
    json_response(['ok'=>false,'error'=>'The selected Fish Audio voice ID is invalid.'],422);
}
preference_set('voice_selected_reference_id',$voice);
json_response(['ok'=>true,'voice_id'=>$voice]);
