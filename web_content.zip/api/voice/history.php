<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/voice.php';
api_guard(['GET']);$user=api_require_user();
$limit=max(1,min(50,(int)($_GET['limit']??20)));
$s=db()->prepare('SELECT id,script,voice_id,model,audio_bytes,credits_charged,created_at FROM voice_generations WHERE user_id=? ORDER BY created_at DESC LIMIT '.$limit);$s->execute([(int)$user['id']]);
json_response(['ok'=>true,'items'=>$s->fetchAll(),'credits_balance'=>voice_wallet_balance((int)$user['id'])]);
