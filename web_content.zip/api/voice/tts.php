<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/voice.php';
api_guard(['POST']);
$user=api_require_user();
$data=json_input();
$text=trim((string)($data['text']??''));
$reference=trim((string)($data['reference_id']??voice_setting('default_voice')));
if($text==='') json_response(['ok'=>false,'error'=>'Enter some text to generate speech.'],422);
$characters=app_text_length($text);
if($characters>5000) json_response(['ok'=>false,'error'=>'Text is too long. Maximum 5,000 characters per request.'],413);
if(strlen($reference)>120 || ($reference!=='' && !preg_match('/^[A-Za-z0-9_-]+$/',$reference))) json_response(['ok'=>false,'error'=>'The voice reference ID is invalid.'],422);
try { if($reference!=='') fish_audio_user_can_use_voice((int)$user['id'],$reference); } catch(InvalidArgumentException $e) { json_response(['ok'=>false,'error'=>$e->getMessage()],422); } catch(Throwable $e) { json_response(['ok'=>false,'error'=>$e->getMessage()],403); }
$userId=(int)$user['id'];
// Account-level limit: 20 generation attempts in any rolling ten-minute window.
$rate=db()->prepare("SELECT COUNT(*) FROM voice_usage WHERE user_id=? AND created_at>=?");
$cutoff=date('Y-m-d H:i:s',time()-600);$rate->execute([$userId,$cutoff]);
if((int)$rate->fetchColumn()>=20) json_response(['ok'=>false,'error'=>'Voice generation limit reached. You can make up to 20 attempts every 10 minutes.'],429);
$cost=voice_credit_cost($characters);
$idempotency=(string)($_SERVER['HTTP_IDEMPOTENCY_KEY']??'');
if($idempotency==='' || !preg_match('/^[A-Za-z0-9_-]{12,100}$/',$idempotency)) json_response(['ok'=>false,'error'=>'A valid Idempotency-Key header is required. Refresh the page and try again.'],422);
$referenceTxn=$idempotency;$charged=false;
try {
    if($cost>0){$balance=voice_charge_credits($userId,$cost,$referenceTxn);$charged=true;}else{$balance=voice_wallet_balance($userId);}
    $result=fish_audio_tts($text,$reference,'mp3');
    $historyId=voice_history_store($userId,$text,$reference,$result,$cost);
    db()->prepare('INSERT INTO voice_usage(owner_key,user_id,characters,model,status,error_code,created_at) VALUES(?,?,?,?,?,?,?)')->execute([owner_key(),$userId,$characters,$result['model'],'success',null,now_sql()]);
    header('Content-Type: audio/mpeg');header('X-Content-Type-Options: nosniff');header('Content-Length: '.strlen($result['audio']));header('Cache-Control: no-store, no-cache, must-revalidate, private');header('X-Voice-Model: '.$result['model']);header('X-Voice-History-Id: '.$historyId);header('X-Voice-Credits-Charged: '.$cost);header('X-Voice-Credits-Balance: '.voice_wallet_balance($userId));echo $result['audio'];exit;
} catch(Throwable $e) {
    if($charged){try{voice_refund_credits($userId,$cost,$referenceTxn);}catch(Throwable $refundError){error_log('Voice credit refund failed for user '.$userId.': '.$refundError->getMessage());}}
    try{db()->prepare('INSERT INTO voice_usage(owner_key,user_id,characters,model,status,error_code,created_at) VALUES(?,?,?,?,?,?,?)')->execute([owner_key(),$userId,$characters,'s2.1-pro-free','failed',0,now_sql()]);}catch(Throwable $ignored){}
    $safeProviderError = $e instanceof RuntimeException && (str_starts_with($e->getMessage(),'Fish Audio') || str_starts_with($e->getMessage(),'Could not connect to Fish Audio') || str_starts_with($e->getMessage(),'PHP cURL'));
    $message = ($e instanceof InvalidArgumentException || $safeProviderError) ? $e->getMessage() : 'Voice generation failed. Any reserved credits have been refunded where possible. Check Voice History before retrying.';
    $status=str_contains(strtolower($e->getMessage()),'insufficient voice credits')?402:(str_contains(strtolower($e->getMessage()),'already been charged')?409:502);
    error_log('Voice synthesis failure for user '.$userId.': '.get_class($e));
    json_response(['ok'=>false,'error'=>$message,'credits_balance'=>voice_wallet_balance($userId)],$status);
}
