<?php
declare(strict_types=1);
require_once __DIR__.'/../../app/voice.php';
api_guard(['GET']); $user=api_require_user();
try { json_response(['ok'=>true,'voices'=>voice_owned_profiles((int)$user['id'])]); }
catch(Throwable $e) { error_log('Owned voice list failed: '.get_class($e)); json_response(['ok'=>false,'error'=>'Your private voice library is temporarily unavailable.'],500); }
