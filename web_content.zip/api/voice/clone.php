<?php
declare(strict_types=1);
require_once __DIR__.'/../../app/voice.php';
api_guard(['POST']); $user=api_require_user();
$userId=(int)$user['id']; $requestKey=(string)($_SERVER['HTTP_IDEMPOTENCY_KEY']??'');
if($requestKey==='' || !preg_match('/^[A-Za-z0-9_-]{12,100}$/',$requestKey)) json_response(['ok'=>false,'error'=>'A valid Idempotency-Key header is required. Refresh and try again.'],422);
voice_clone_schema();
$existing=db()->prepare('SELECT status,provider_voice_id,credits_charged FROM voice_clone_requests WHERE user_id=? AND request_key=? LIMIT 1');$existing->execute([$userId,$requestKey]);$prior=$existing->fetch();
if($prior){
    if($prior['status']==='success'){$q=db()->prepare('SELECT provider_voice_id AS id,voice_name AS name,provider_state AS state,visibility FROM voice_profiles WHERE user_id=? AND provider_voice_id=? LIMIT 1');$q->execute([$userId,$prior['provider_voice_id']]);$voice=$q->fetch();if($voice)json_response(['ok'=>true,'voice'=>$voice,'credits_charged'=>(int)$prior['credits_charged'],'message'=>'This voice creation request was already completed.']);}
    json_response(['ok'=>false,'error'=>'This voice creation request was already attempted or is still being reconciled. Check My Private Voices before submitting a new request.'],409);
}
try { db()->prepare('INSERT INTO voice_clone_requests(user_id,request_key,status,created_at,updated_at) VALUES(?,?,?,?,?)')->execute([$userId,$requestKey,'pending',now_sql(),now_sql()]); }
catch(Throwable $e){json_response(['ok'=>false,'error'=>'This voice request is already being processed. Check My Private Voices before retrying.'],409);}
$cost=max(0,(int)voice_setting('credits_per_voice_clone','100'));
$charged=0;
try {
    // Charge before contacting the provider so an unpaid clone is never created.
    if($cost>0){
        voice_charge_credits($userId,$cost,$requestKey,'Voice cloning');
        $charged=$cost;
        db()->prepare("UPDATE voice_clone_requests SET credits_charged=?,updated_at=? WHERE user_id=? AND request_key=?")
            ->execute([$charged,now_sql(),$userId,$requestKey]);
    }
    $name=trim((string)($_POST['voice_name']??'')); $description=trim((string)($_POST['description']??''));
    $consent=isset($_POST['consent']) && (string)$_POST['consent']==='1';
    $voice=fish_audio_create_private_voice($userId,$name,$description,$_FILES['sample']??[],$consent);
    db()->prepare("UPDATE voice_clone_requests SET status='success',provider_voice_id=?,credits_charged=?,updated_at=? WHERE user_id=? AND request_key=?")
        ->execute([$voice['id'],$charged,now_sql(),$userId,$requestKey]);
    json_response(['ok'=>true,'voice'=>$voice,'credits_charged'=>$charged,'credits_balance'=>voice_wallet_balance($userId),'message'=>'Your private voice model was created.']);
} catch(InvalidArgumentException $e) {
    if($charged>0){try{voice_refund_credits($userId,$charged,$requestKey,'Voice cloning refund');}catch(Throwable $refundError){error_log('Voice clone validation refund requires review.');}}
    db()->prepare("UPDATE voice_clone_requests SET status='failed',credits_charged=0,updated_at=? WHERE user_id=? AND request_key=?")->execute([now_sql(),$userId,$requestKey]);
    json_response(['ok'=>false,'error'=>$e->getMessage(),'credits_balance'=>voice_wallet_balance($userId)],422);
} catch(PDOException $e) {
    // Provider creation may have succeeded even if local persistence failed; retain
    // the debit and mark uncertain rather than risk a free provider-side clone.
    error_log('Fish Audio voice clone storage failure: PDOException');
    db()->prepare("UPDATE voice_clone_requests SET status='uncertain',credits_charged=?,updated_at=? WHERE user_id=? AND request_key=?")->execute([$charged,now_sql(),$userId,$requestKey]);
    json_response(['ok'=>false,'error'=>'The provider result could not be confirmed in the local library. Check My Private Voices before retrying.','credits_charged'=>$charged],500);
} catch(RuntimeException $e) {
    $message=strtolower($e->getMessage());
    $uncertain=str_contains($message,'could not connect to fish audio')||str_contains($message,'temporarily unavailable')||str_contains($message,'incomplete voice model response')||str_contains($message,'provider result could not')||str_contains($message,'cleanup could not be confirmed');
    if($charged>0 && !$uncertain){try{voice_refund_credits($userId,$charged,$requestKey,'Voice cloning refund');$charged=0;}catch(Throwable $refundError){$uncertain=true;error_log('Voice clone refund requires reconciliation.');}}
    $status=str_contains($message,'insufficient')?402:502;
    db()->prepare("UPDATE voice_clone_requests SET status=?,credits_charged=?,updated_at=? WHERE user_id=? AND request_key=?")
        ->execute([$uncertain?'uncertain':'failed',$charged,now_sql(),$userId,$requestKey]);
    $safeMessage=$uncertain?'Fish Audio did not confirm the final result. Check My Private Voices before retrying.':$e->getMessage();
    json_response(['ok'=>false,'error'=>$safeMessage,'credits_charged'=>$charged,'credits_balance'=>voice_wallet_balance($userId)],$status);
} catch(Throwable $e) {
    error_log('Fish Audio voice clone failed: '.get_class($e));
    db()->prepare("UPDATE voice_clone_requests SET status='uncertain',credits_charged=?,updated_at=? WHERE user_id=? AND request_key=?")->execute([$charged,now_sql(),$userId,$requestKey]);
    json_response(['ok'=>false,'error'=>'Voice cloning result is uncertain. Check My Private Voices before retrying.','credits_charged'=>$charged],500);
}
