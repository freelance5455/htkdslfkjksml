<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/voice.php';
api_guard(['GET']);
api_require_user();
try {
    $page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
    $pageSize = filter_var($_GET['page_size'] ?? 60, FILTER_VALIDATE_INT);
    $result = fish_audio_list_voices(max(1, (int)$page), max(1, min(100, (int)$pageSize)));
    $uid=(int)$user['id'];
    $result['voices']=array_values(array_filter($result['voices']??[],static function(array $voice) use($uid): bool {
        if(($voice['visibility']??'')!=='private') return true;
        voice_clone_schema();$q=db()->prepare('SELECT user_id FROM voice_profiles WHERE provider_voice_id=? LIMIT 1');$q->execute([(string)($voice['id']??'')]);$owner=$q->fetchColumn();return $owner!==false&&(int)$owner===$uid;
    }));
    json_response(['ok' => true] + $result);
} catch (Throwable $e) {
    error_log('api/voice/voices.php failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Voice library is temporarily unavailable.'], 502);
}
