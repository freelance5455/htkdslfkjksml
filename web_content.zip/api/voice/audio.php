<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/voice.php';
api_guard(['GET']);$user=api_require_user();
$id=(string)($_GET['id']??'');if(!preg_match('/^[a-f0-9]{32}$/',$id)){http_response_code(404);exit;}
$s=db()->prepare('SELECT audio_file FROM voice_generations WHERE id=? AND user_id=? LIMIT 1');$s->execute([$id,(int)$user['id']]);$file=$s->fetchColumn();
if(!is_string($file)||!preg_match('/^[a-f0-9]{32}\.mp3$/',$file)){http_response_code(404);exit;}
$path=APP_ROOT.'/storage/voice-audio/'.$file;if(!is_file($path)||is_link($path)){http_response_code(404);exit;}
header('Content-Type: audio/mpeg');header('X-Content-Type-Options: nosniff');header('Cache-Control: private, no-store');header('Content-Length: '.filesize($path));readfile($path);exit;
