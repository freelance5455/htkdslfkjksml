<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/auth.php';

try {
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    api_guard(['GET', 'POST']);
    api_require_user();
    $pdo = db();
    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT id, title, description, prompt, category, is_custom FROM prompt_library WHERE is_custom = 0 OR owner_key = ? ORDER BY is_custom ASC, category ASC, title ASC');
        $stmt->execute([owner_key()]);
        $items = $stmt->fetchAll();
        foreach ($items as &$item) { $item['id'] = (int)$item['id']; $item['is_custom'] = (bool)$item['is_custom']; }
        unset($item);
        json_response(['ok' => true, 'prompts' => $items]);
    }

    $data = json_input();
    $action = (string)($data['action'] ?? '');
    $title = trim((string)($data['title'] ?? ''));
    $description = trim((string)($data['description'] ?? ''));
    $prompt = trim((string)($data['prompt'] ?? ''));
    $category = trim((string)($data['category'] ?? 'Creative Effects'));
    if (app_text_length($title) > 180 || app_text_length($description) > 500 || app_text_length($prompt) > (int)app_config()['max_prompt_length'] || app_text_length($category) > 80) {
        json_response(['ok' => false, 'error' => 'One or more prompt fields exceed the allowed length.'], 422);
    }

    if ($action === 'create') {
        if ($title === '' || $prompt === '') json_response(['ok' => false, 'error' => 'A title and prompt are required.'], 422);
        $now = now_sql();
        $stmt = $pdo->prepare('INSERT INTO prompt_library (title, description, prompt, category, is_custom, owner_key, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?)');
        $stmt->execute([$title, $description, $prompt, $category, owner_key(), $now, $now]);
        json_response(['ok' => true, 'id' => (int)$pdo->lastInsertId(), 'message' => 'Custom prompt saved.']);
    }

    $id = (int)($data['id'] ?? 0);
    if ($id < 1) json_response(['ok' => false, 'error' => 'A valid prompt ID is required.'], 422);
    $check = $pdo->prepare('SELECT id, title, description, prompt, category FROM prompt_library WHERE id = ? AND is_custom = 1 AND owner_key = ?');
    $check->execute([$id, owner_key()]);
    $existing = $check->fetch();
    if (!$existing) json_response(['ok' => false, 'error' => 'Only your own custom prompts can be changed.'], 404);

    if ($action === 'update') {
        if ($title === '' || $prompt === '') json_response(['ok' => false, 'error' => 'A title and prompt are required.'], 422);
        $stmt = $pdo->prepare('UPDATE prompt_library SET title = ?, description = ?, prompt = ?, category = ?, updated_at = ? WHERE id = ? AND owner_key = ? AND is_custom = 1');
        $stmt->execute([$title, $description, $prompt, $category, now_sql(), $id, owner_key()]);
        json_response(['ok' => true, 'message' => 'Custom prompt updated.']);
    }
    if ($action === 'duplicate') {
        $copyTitle = $title !== '' ? $title : ((string)$existing['title'] . ' Copy');
        $now = now_sql();
        $stmt = $pdo->prepare('INSERT INTO prompt_library (title, description, prompt, category, is_custom, owner_key, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?)');
        $stmt->execute([$copyTitle, $description !== '' ? $description : $existing['description'], $prompt !== '' ? $prompt : $existing['prompt'], $category !== '' ? $category : $existing['category'], owner_key(), $now, $now]);
        json_response(['ok' => true, 'id' => (int)$pdo->lastInsertId(), 'message' => 'Prompt duplicated.']);
    }
    if ($action === 'delete') {
        $pdo->prepare('DELETE FROM prompt_library WHERE id = ? AND owner_key = ? AND is_custom = 1')->execute([$id, owner_key()]);
        json_response(['ok' => true, 'message' => 'Custom prompt deleted.']);
    }
    json_response(['ok' => false, 'error' => 'Unknown prompt action.'], 400);
} catch (Throwable $e) {
    error_log('api/prompts.php failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Prompt library operation failed.'], 500);
}
