<?php require 'config.php'; auth();
$q=trim($_GET['q']??'');
if($q===''){json_out(['data'=>[]]);exit;}
$s=db()->prepare('SELECT * FROM players WHERE nickname LIKE ? OR id=? ORDER BY id DESC LIMIT 50');
$s->execute(['%'.$q.'%',ctype_digit($q)?(int)$q:0]);json_out(['data'=>$s->fetchAll()]);
