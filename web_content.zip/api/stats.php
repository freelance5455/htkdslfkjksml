<?php require 'config.php'; auth();
json_out(['players'=>(int)db()->query('SELECT COUNT(*) FROM players')->fetchColumn(),'logs'=>(int)db()->query('SELECT COUNT(*) FROM action_logs')->fetchColumn(),'admins'=>(int)db()->query('SELECT COUNT(*) FROM admins WHERE active=1')->fetchColumn()]);
