const express=require("express");
const cors=require("cors");
const fs=require("fs");
const path=require("path");
const app=express();
app.use(cors());
app.use(express.json({limit:"15mb"}));
const DB=path.join(__dirname,"sunset-data.json");
function read(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return {stores:{}}}}
function write(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
app.get("/health",(req,res)=>res.json({ok:true,service:"Sunset API"}));
app.post("/sync",(req,res)=>{
  const {storeId,outbox=[]}=req.body||{};
  if(!storeId)return res.status(400).json({error:"storeId obrigatório"});
  const db=read(); db.stores[storeId]??={events:[]};
  const known=new Set(db.stores[storeId].events.map(e=>e.id));
  for(const e of outbox){if(e?.id&&!known.has(e.id))db.stores[storeId].events.push(e)}
  write(db);
  res.json({ok:true,ackIds:outbox.map(e=>e.id),state:{}});
});
app.listen(process.env.PORT||3000,()=>console.log("Sunset API on port "+(process.env.PORT||3000)));
