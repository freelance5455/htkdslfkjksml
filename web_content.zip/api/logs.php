<?php require 'config.php'; auth();
$s=db()->query('SELECT l.*,a.login,p.nickname FROM action_logs l LEFT JOIN admins a ON a.id=l.admin_id LEFT JOIN players p ON p.id=l.player_id ORDER BY l.id DESC LIMIT 300');
json_out(['data'=>$s->fetchAll()]);
