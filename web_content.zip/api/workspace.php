<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/auth.php';

try {
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    api_guard(['GET', 'POST']);
    api_require_user();
    if ($method === 'GET') {
        json_response(['ok' => true, 'preferences' => [
            'model' => preference_get('model', 'lucy-2.6'),
            'prompt' => preference_get('prompt', ''),
            'enhance_prompt' => preference_get('enhance_prompt', true),
        ], 'reference' => active_reference()]);
    }
    $data = json_input();
    if (isset($data['model'])) {
        $model = (string)$data['model'];
        if (!in_array($model, DEFAULT_MODELS, true)) json_response(['ok' => false, 'error' => 'Unsupported model selection.'], 422);
        if (!platform_model_enabled($model)) json_response(['ok'=>false,'error'=>'This model is currently disabled by the administrator.'],403);
        preference_set('model', $model);
    }
    if (isset($data['prompt'])) {
        $prompt = trim((string)$data['prompt']);
        if (app_text_length($prompt) > (int)app_config()['max_prompt_length']) json_response(['ok' => false, 'error' => 'Prompt is too long.'], 422);
        preference_set('prompt', $prompt);
    }
    if (isset($data['enhance_prompt'])) preference_set('enhance_prompt', (bool)$data['enhance_prompt']);
    json_response(['ok' => true, 'message' => 'Workspace preferences saved.']);
} catch (Throwable $e) {
    error_log('Workspace endpoint failure: '.get_class($e));
    json_response(['ok' => false, 'error' => 'Workspace operation failed. Please retry.'], 500);
}
