<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/platform.php';
require_once __DIR__ . '/../app/auth.php';
try {
    api_require_user();
    $id=(string)($_GET['id']??'');
    $kind=(string)($_GET['kind']??'output');
    $job=platform_owned_job($id);
    if($kind!=='output'||$job['status']!=='completed'||empty($job['output_disk'])) { http_response_code(404); exit('Not found'); }
    $path=platform_dirs()['outputs'].'/'.basename((string)$job['output_disk']);
    if(!is_file($path)||is_link($path)) { http_response_code(404); exit('Not found'); }
    $mime=(string)$job['output_mime'];
    if(!preg_match('#^(video/(mp4|webm)|image/(png|jpeg|webp|gif))$#',$mime)) { http_response_code(404); exit('Not found'); }
    $size=(int)filesize($path);
    $download=($_GET['download']??'')==='1';
    $filename='anonymoux-studio-result.'.($mime==='video/webm'?'webm':($mime==='image/png'?'png':($mime==='image/jpeg'?'jpg':($mime==='image/webp'?'webp':($mime==='image/gif'?'gif':'mp4')))));
    header('Content-Type: '.$mime);
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    header('Accept-Ranges: bytes');
    header('Content-Disposition: '.($download?'attachment':'inline').'; filename="'.$filename.'"');
    $start=0; $end=max(0,$size-1); $range=(string)($_SERVER['HTTP_RANGE']??'');
    if(!$download && $range!=='' && preg_match('/^bytes=(\d*)-(\d*)$/',$range,$m)) {
        if($m[1]==='' && $m[2]!=='') { $suffix=(int)$m[2]; if($suffix>0)$start=max(0,$size-$suffix); }
        else { $start=(int)$m[1]; if($m[2]!=='')$end=min($end,(int)$m[2]); }
        if($start>$end||$start>=$size) { http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
        http_response_code(206);
        header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
    }
    $length=$size>0?$end-$start+1:0;
    header('Content-Length: '.$length);
    $fp=fopen($path,'rb');
    if(!$fp) { http_response_code(404); exit('Not found'); }
    if($start>0)fseek($fp,$start);
    $remaining=$length;
    while($remaining>0&&!feof($fp)) {
        $chunk=fread($fp,min(1024*1024,$remaining));
        if($chunk===false||$chunk==='')break;
        echo $chunk;
        $remaining-=strlen($chunk);
        if(connection_aborted())break;
    }
    fclose($fp);
    exit;
} catch(Throwable $e) {
    http_response_code(404);
    exit('Not found');
}
