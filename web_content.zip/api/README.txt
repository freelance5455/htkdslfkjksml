SUNSET API — endpoint de sincronização
1. Instale Node.js 20+.
2. npm install
3. node server.js
4. Configure no app a URL base, por exemplo https://seu-dominio.com
5. O app chama POST https://seu-dominio.com/sync com:
   { storeId, outbox:[...] }
6. O servidor responde:
   { ok:true, ackIds:[...], state:{} }

Este servidor de referência usa JSON para demonstração. Para produção, troque o armazenamento por PostgreSQL/Supabase e coloque HTTPS, autenticação, backup e controle de conflitos.
