<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/platform.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/credits.php';
api_guard(['POST']);
$user=api_require_user();
$input=null; $ref=null; $outputPath=null; $jobId=null;
$reserved=false; $providerAttempted=false; $safeRefund=true; $dirs=null;
try {
    app_rate_limit('image_generation', 8, 600);
    if (!platform_model_enabled('lucy-image-2')) json_response(['ok'=>false,'error'=>'Lucy Image 2 is currently disabled by the administrator.'],403);
    if (!decart_ready()) throw new RuntimeException('Decart API key is not configured. Add it to private config.local.php.');
    if (!extension_loaded('curl')) throw new RuntimeException('PHP cURL extension is required for Decart requests.');
    if (!isset($_FILES['data'])) json_response(['ok'=>false,'error'=>'Upload a source image first.'],422);
    $price=billing_price('image');
    if($price===null) json_response(['ok'=>false,'error'=>'Image generation pricing has not been configured by an administrator.'],503);
    $prompt=trim((string)($_POST['prompt']??''));
    if ($prompt==='' || (function_exists('mb_strlen')?mb_strlen($prompt):strlen($prompt))>2000) json_response(['ok'=>false,'error'=>'Enter a prompt of 1–2000 characters.'],422);
    $resolution=(string)($_POST['resolution']??'720p');
    if (!in_array($resolution,['480p','720p'],true)) json_response(['ok'=>false,'error'=>'Unsupported image resolution.'],422);
    $input=platform_upload($_FILES['data'],'image');
    $dirs=platform_dirs(); $ref=null;
    if (isset($_FILES['reference_image']) && (int)($_FILES['reference_image']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE) {
        $ref=platform_upload($_FILES['reference_image'],'image');
        $refPath=$dirs['inputs'].'/'.$ref['disk'];
        $refNew=bin2hex(random_bytes(18)).'.'.$ref['disk'];
        if (!rename($refPath,$dirs['references'].'/'.$refNew)) throw new RuntimeException('Could not store reference image.');
        $ref['disk']=$refNew;
    }
    $seed=trim((string)($_POST['seed']??''));
    if ($seed!=='' && (!ctype_digit($seed) || (int)$seed>4294967295)) throw new InvalidArgumentException('Seed must be an integer between 0 and 4294967295.');
    $jobId=bin2hex(random_bytes(16));
    billing_reserve((int)$user['id'],'image',$jobId,$price); $reserved=true;
    platform_store_job(['id'=>$jobId,'workspace'=>'image','model'=>'lucy-image-2','prompt'=>$prompt,'status'=>'processing','input_disk'=>$input['disk'],'reference_disk'=>$ref['disk']??null,'resolution'=>$resolution,'metadata'=>['billing_state'=>'reserved','credits'=>$price]]);
    $fields=[
        'data'=>new CURLFile($dirs['inputs'].'/'.$input['disk'],$input['mime'],'source.'.$input['disk']),
        'prompt'=>$prompt,'resolution'=>$resolution,
        'enhance_prompt'=>filter_var($_POST['enhance_prompt']??'true',FILTER_VALIDATE_BOOLEAN)?'true':'false',
    ];
    if($ref)$fields['reference_image']=new CURLFile($dirs['references'].'/'.$ref['disk'],$ref['mime'],'reference.'.$ref['disk']);
    if($seed!=='')$fields['seed']=(string)(int)$seed;
    $cfg=app_config(); $base=rtrim((string)$cfg['decart_api_base'],'/');
    $providerAttempted=true; $safeRefund=false;
    $result=decart_platform_curl('POST',$base.'/generate/lucy-image-2',['Accept: image/png, application/json'],$fields,240);
    if($result['status']<200 || $result['status']>=300) {
        $safeRefund=$result['status']>=400 && $result['status']<500;
        $message=$safeRefund?platform_provider_error($result):'Provider outcome is uncertain (HTTP '.(int)$result['status'].'). The reserved credits and job have been retained to prevent duplicate paid submissions.';
        if($safeRefund){
            billing_refund($jobId,'Image generation provider rejection refund');
            db()->prepare("UPDATE platform_jobs SET status='failed',error_message=?,input_disk='',reference_disk=NULL,output_disk=NULL,output_mime=NULL,output_bytes=NULL,updated_at=? WHERE id=? AND owner_key=?")->execute([$message,now_sql(),$jobId,owner_key()]);
            @unlink($dirs['inputs'].'/'.$input['disk']); if($ref)@unlink($dirs['references'].'/'.$ref['disk']);
        } else {
            db()->prepare("UPDATE platform_jobs SET error_message=?,updated_at=? WHERE id=? AND owner_key=?")->execute([$message,now_sql(),$jobId,owner_key()]);
        }
        json_response(['ok'=>false,'jobId'=>$jobId,'status'=>$safeRefund?'failed':'processing','error'=>$message,'creditsReserved'=>$price],$safeRefund?502:504);
    }
    $safeRefund=true;
    $imageInfo=@getimagesizefromstring($result['body']);
    $outputMime=is_array($imageInfo)?(string)($imageInfo['mime']??''):'';
    $imageExtensions=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];
    if(!$imageInfo || !isset($imageExtensions[$outputMime])) throw new RuntimeException('Decart returned an unsupported or invalid image. The reservation will be refunded.');
    $outputBytes=strlen($result['body']);
    $quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));
    if(platform_storage_used_bytes(owner_key())+$outputBytes>$quota) throw new RuntimeException('Provider output could not be saved because the account storage quota would be exceeded.');
    $output=$jobId.'.'.$imageExtensions[$outputMime]; $outputPath=$dirs['outputs'].'/'.$output;
    if(file_put_contents($outputPath,$result['body'],LOCK_EX)===false) throw new RuntimeException('Could not save generated image.');
    db()->prepare("UPDATE platform_jobs SET status='completed',output_disk=?,output_mime=?,output_bytes=?,metadata=?,updated_at=? WHERE id=? AND owner_key=?")
        ->execute([$output,$outputMime,$outputBytes,json_encode(['width'=>$imageInfo[0],'height'=>$imageInfo[1],'provider'=>'Decart','credits'=>$price,'billing_state'=>'settled']),now_sql(),$jobId,owner_key()]);
    platform_save_asset($jobId,$output,$outputMime,'image','Lucy Image 2 output.'.$imageExtensions[$outputMime]);
    billing_settle($jobId); $reserved=false;
    json_response(['ok'=>true,'jobId'=>$jobId,'status'=>'completed','outputUrl'=>'api/media.php?id='.$jobId.'&kind=output','width'=>$imageInfo[0],'height'=>$imageInfo[1],'creditsCharged'=>$price]);
} catch(Throwable $e) {
    if($reserved && $safeRefund && $jobId!==null) {
        try { billing_refund($jobId,'Image generation failure refund'); } catch(Throwable $refundError) { error_log('Image refund failure for '.$jobId.': '.get_class($refundError)); }
    }
    if($jobId!==null && $reserved) {
        try {
            if($safeRefund) db()->prepare('DELETE FROM platform_assets WHERE job_id=? AND owner_key=?')->execute([$jobId,owner_key()]);
            if($safeRefund) db()->prepare("UPDATE platform_jobs SET status='failed',error_message=?,input_disk='',reference_disk=NULL,output_disk=NULL,output_mime=NULL,output_bytes=NULL,updated_at=? WHERE id=? AND owner_key=?")->execute(['Generation failed; credits were refunded where eligible.',now_sql(),$jobId,owner_key()]);
            else db()->prepare('UPDATE platform_jobs SET error_message=?,updated_at=? WHERE id=? AND owner_key=?')->execute(['Provider outcome is uncertain. Reservation retained for reconciliation.',now_sql(),$jobId,owner_key()]);
        } catch(Throwable $ignored) {}
    }
    if($safeRefund) {
        if(isset($input['disk'])) @unlink(APP_ROOT.'/storage/platform/inputs/'.$input['disk']);
        if(isset($ref['disk'])) @unlink(APP_ROOT.'/storage/platform/references/'.$ref['disk']);
        if(isset($outputPath)&&is_string($outputPath)) @unlink($outputPath);
    }
    $code=$e instanceof InvalidArgumentException?422:($e instanceof RuntimeException && (str_contains($e->getMessage(),'not configured')||str_contains($e->getMessage(),'required')||str_contains($e->getMessage(),'unavailable'))?503:500);
    error_log('Image generation failure: '.get_class($e).' '.substr($e->getMessage(),0,300));
    json_response(['ok'=>false,'jobId'=>$jobId,'error'=>$e instanceof InvalidArgumentException?$e->getMessage():'Image generation failed. '.($safeRefund?'The reserved credits have been refunded where applicable.':'The provider outcome is uncertain; credits remain reserved to prevent duplicate charging.')],$code);
}
