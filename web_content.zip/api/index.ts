/**
 * Vercel Serverless Function (Node runtime).
 *
 * Vercel's /api directory does not support catch-all filenames such as
 * `[...route].ts` for non-Next projects — only single-level dynamic segments —
 * so every /api/* request is rewritten to this one function instead (see
 * vercel.json). Vercel hands it the original path, so Hono routes normally.
 *
 * Keep this file checked in: functions are detected before the build runs.
 */
import handler from '../server/vercel';

export default handler;
