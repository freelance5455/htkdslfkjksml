import type { Request, Response } from 'express';
import app from '../server.ts';

export default function handler(req: Request, res: Response) {
  // In Vercel rewrites, determine the actual intended API route
  let targetUrl = req.url || '/';
  try {
    const parsed = new URL(targetUrl, 'http://localhost');
    const queryPath = parsed.searchParams.get('__path') || parsed.searchParams.get('path');
    const matchedPath = (req.headers['x-matched-path'] || req.headers['x-forwarded-uri']) as string | undefined;

    if (queryPath) {
      parsed.searchParams.delete('__path');
      parsed.searchParams.delete('path');
      const search = parsed.searchParams.toString();
      targetUrl = '/api/' + queryPath.replace(/^\/+/, '') + (search ? '?' + search : '');
    } else if (matchedPath && matchedPath.startsWith('/api') && !matchedPath.startsWith('/api/index')) {
      targetUrl = matchedPath;
    } else if (!targetUrl.startsWith('/api')) {
      targetUrl = '/api' + (targetUrl.startsWith('/') ? targetUrl : '/' + targetUrl);
    }
  } catch (_) {
    if (!targetUrl.startsWith('/api')) {
      targetUrl = '/api' + (targetUrl.startsWith('/') ? targetUrl : '/' + targetUrl);
    }
  }

  req.url = targetUrl;
  return app(req, res);
}
