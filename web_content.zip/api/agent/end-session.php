<?php
declare(strict_types=1);
require_once __DIR__.'/../../app/agent.php';
api_guard(['POST']);
$u=api_require_user();
$d=json_input();
$id=(int)($d['session_id']??0);
if($id<1) json_response(['ok'=>false,'error'=>'Invalid session ID.'],422);
try {
    $q=db()->prepare('SELECT id,provider_session_id FROM agent_sessions WHERE id=? AND user_id=? LIMIT 1');
    $q->execute([$id,(int)$u['id']]);
    $sessionRow=$q->fetch();if(!$sessionRow) json_response(['ok'=>false,'error'=>'Session not found.'],404);
    $providerId=trim((string)$sessionRow['provider_session_id']);if($providerId!==''){try{anx_fish_request('POST','/v1/agent/sessions/'.rawurlencode($providerId).'/end',null);}catch(Throwable $providerEndError){error_log('Fish Audio session end deferred for local session '.$id.': '.$providerEndError->getMessage());}}
    db()->prepare("UPDATE agent_sessions SET session_status='ended',ended_at=COALESCE(ended_at,?) WHERE id=? AND user_id=?")->execute([now_sql(),$id,(int)$u['id']]);
    try {
        $usage=agent_reconcile_provider_usage($id,(int)$u['id']);
        json_response(['ok'=>true,'usage'=>$usage]);
    } catch(Throwable $providerError) {
        error_log('Agent usage reconciliation deferred for local session '.$id.': '.$providerError->getMessage());
        json_response(['ok'=>true,'usage'=>['status'=>'pending','message'=>'Session ended locally. Provider usage reconciliation will need another attempt.']]);
    }
} catch(Throwable $e) {
    error_log('Agent session close failed: '.$e->getMessage());
    json_response(['ok'=>false,'error'=>'Could not close the agent session.'],500);
}
