<?php
declare(strict_types=1);
require_once __DIR__.'/../../app/agent.php';
api_guard(['POST']);
$u=api_require_user();
$d=json_input();
$id=(int)($d['session_id']??0);
if($id<1) json_response(['ok'=>false,'error'=>'Invalid session ID.'],422);
try {
    $q=db()->prepare("SELECT id FROM agent_sessions WHERE id=? AND user_id=? AND session_status='ended' LIMIT 1");
    $q->execute([$id,(int)$u['id']]);
    if(!$q->fetchColumn()) json_response(['ok'=>false,'error'=>'Closed session not found.'],404);
    json_response(['ok'=>true,'usage'=>agent_reconcile_provider_usage($id,(int)$u['id'])]);
} catch(Throwable $e) {
    error_log('Agent usage retry failed for session '.$id.': '.$e->getMessage());
    json_response(['ok'=>false,'error'=>'Provider usage is not available yet. Retry later.'],502);
}
