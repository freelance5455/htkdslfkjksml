<?php
require_once __DIR__.'/../../app/agent.php';api_guard(['GET','POST','DELETE']);$u=api_require_user();agent_schema();
try{
 if($_SERVER['REQUEST_METHOD']==='GET'){$s=db()->prepare('SELECT * FROM knowledge_sources WHERE user_id=? ORDER BY created_at DESC');$s->execute([(int)$u['id']]);json_response(['ok'=>true,'sources'=>$s->fetchAll()]);}
 if($_SERVER['REQUEST_METHOD']==='POST'){
  if(empty($_FILES['source'])||$_FILES['source']['error']!==UPLOAD_ERR_OK)throw new InvalidArgumentException('Choose a TXT or Markdown file.');
  $f=$_FILES['source'];if($f['size']<1||$f['size']>1048576)throw new InvalidArgumentException('Fish Audio accepts UTF-8 TXT/Markdown files up to 1 MB.');
  $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));if(!in_array($ext,['txt','md'],true))throw new InvalidArgumentException('The provider Knowledge Base API currently accepts only .txt and .md files. Convert PDF/DOCX/CSV to UTF-8 text first.');
  $tmp=file_get_contents($f['tmp_name']);if(!is_string($tmp)||!preg_match('//u',$tmp))throw new InvalidArgumentException('The uploaded file must be valid UTF-8 text.');
  $mime=$ext==='md'?'text/markdown':'text/plain';$c=new CURLFile($f['tmp_name'],$mime,basename($f['name']));
  $r=anx_fish_request('POST','/v1/agent/knowledge-sources',null,['source'=>$c,'name'=>basename($f['name'])]);$pd=$r['data'];$pid=(string)($pd['source_id']??$pd['id']??'');if($pid==='')throw new RuntimeException('Provider did not return a knowledge source ID.');
  db()->prepare('INSERT INTO knowledge_sources(user_id,provider_source_id,source_name,source_type,original_filename,mime_type,file_size,processing_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([(int)$u['id'],$pid,basename($f['name']),$ext,basename($f['name']),$mime,(int)$f['size'],'ready',now_sql(),now_sql()]);
  json_response(['ok'=>true,'message'=>'Knowledge source uploaded and accepted by Fish Audio.','source_id'=>(int)db()->lastInsertId()]);
 }
 $id=(int)($_POST['id']??$_GET['id']??0);$s=db()->prepare('SELECT * FROM knowledge_sources WHERE id=? AND user_id=?');$s->execute([$id,(int)$u['id']]);$src=$s->fetch();if(!$src)throw new RuntimeException('Knowledge source not found.');
 if($_SERVER['REQUEST_METHOD']==='DELETE') {anx_fish_request('DELETE','/v1/agent/knowledge-sources/'.rawurlencode($src['provider_source_id']));db()->prepare('DELETE FROM agent_knowledge WHERE knowledge_source_id=? AND user_id=?')->execute([$id,(int)$u['id']]);db()->prepare('DELETE FROM knowledge_sources WHERE id=? AND user_id=?')->execute([$id,(int)$u['id']]);json_response(['ok'=>true]);}
}catch(Throwable $e){json_response(['ok'=>false,'error'=>$e->getMessage()],422);}
