<?php
require_once __DIR__.'/../../app/agent.php';api_guard(['POST']);$u=api_require_user();$d=json_input();$id=(int)($d['id']??0);$channel=($d['channel']??'chat')==='voice'?'voice':'chat';
try{$a=agent_owned($id,(int)$u['id']);if($a['publication_state']!=='published')throw new RuntimeException('Publish this agent before starting a live session.');
$bal=voice_wallet_balance((int)$u['id']);$agentRate=max(0.0,(float)voice_setting('agent_credits_per_usd',(string)(app_config()['agent_credits_per_usd']??0)));if($agentRate>0&&$bal<1)json_response(['ok'=>false,'error'=>'Insufficient ANON credits. Top up before starting a chargeable session.'],402);
$sessionPayload=['agent_id'=>$a['fish_agent_id']];
$config=agent_config_array($a);$overrides=[];
$savedVoice=trim((string)($config['voice']['voice_id']??''));
if($savedVoice!==''){fish_audio_user_can_use_voice((int)$u['id'],$savedVoice);$overrides['voice_id']=$savedVoice;}
$savedPrompt=trim((string)($config['prompt']['system_prompt']??''));
if($savedPrompt!=='')$overrides['system_prompt']=$savedPrompt;
$greeting=trim((string)($config['prompt']['first_message']??$config['conversation']['first_message']??''));
if($greeting!=='')$overrides['first_message']=$greeting;
if($overrides)$sessionPayload['overrides']=$overrides;
$r=anx_fish_request('POST','/v1/agent/sessions',$sessionPayload);
$providerId=(string)($r['data']['session_id']??$r['data']['id']??'');if(!$r['data']||$providerId===''||!preg_match('/^[A-Za-z0-9_-]{6,160}$/',$providerId))throw new RuntimeException('Fish Audio returned an incomplete session response. Please retry after checking the provider status.');db()->prepare('INSERT INTO agent_sessions(user_id,agent_id,provider_session_id,channel,session_status,started_at) VALUES(?,?,?,?,?,?)')->execute([(int)$u['id'],$id,$providerId,$channel,'created',now_sql()]);
json_response(['ok'=>true,'session'=>$r['data'],'provider_session_id'=>$providerId,'local_session_id'=>(int)db()->lastInsertId()]);
}catch(Throwable $e){json_response(['ok'=>false,'error'=>$e->getMessage()],502);}
