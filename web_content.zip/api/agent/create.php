<?php
require_once __DIR__.'/../../app/agent.php'; api_guard(['POST']);$u=api_require_user();$d=json_input();
$name=trim((string)($d['name']??''));$desc=trim((string)($d['description']??''));$prompt=trim((string)($d['system_prompt']??''));$voice=trim((string)($d['voice_id']??''));
if($voice!==''&&!preg_match('/^[A-Za-z0-9_-]{6,120}$/',$voice))json_response(['ok'=>false,'error'=>'The Fish Audio voice ID is invalid.'],422);
try { if($voice!=='') fish_audio_user_can_use_voice((int)$u['id'],$voice); } catch(InvalidArgumentException $e) { json_response(['ok'=>false,'error'=>$e->getMessage()],422); } catch(Throwable $e) { json_response(['ok'=>false,'error'=>$e->getMessage()],403); }
if($name===''||app_text_length($name)>100)json_response(['ok'=>false,'error'=>'Agent name is required (maximum 100 characters).'],422);
if(app_text_length($desc)>1000||app_text_length($prompt)>12000)json_response(['ok'=>false,'error'=>'Description or instructions exceed the allowed length.'],422);
$greeting=trim((string)($d['greeting']??''));$language=strtolower(trim((string)($d['speaking_language']??'en')));$allowedLanguages=['en','da','ja','no','zh','fi','ko','et','es','lv','fr','lt','de','ca','pt','he','it','fa','nl','ur','ar','kk','hi','ka','id','hy','tr','bn','ru','ta','bg','te','sr','kn','hr','mr','cs','gu','sk','pa','pl','ne','uk','th','ro','vi','hu','ms','el','tl','sv','af'];if(!in_array($language,$allowedLanguages,true))json_response(['ok'=>false,'error'=>'Choose a supported Fish Audio speaking language.'],422);$ttsModel=(string)($d['tts_model']??'drama-3');if(!in_array($ttsModel,['drama-3','s2.1-pro'],true))json_response(['ok'=>false,'error'=>'Choose a supported Fish Audio speech model.'],422);$speed=max(0.5,min(2.0,(float)($d['speed']??1)));$config=['prompt'=>['system_prompt'=>$prompt,'first_message_mode'=>$greeting!==''?'fixed':'off','first_message'=>$greeting], 'voice'=>['engine'=>'fish_tts','tts_model'=>$ttsModel,'speaking_language'=>$language,'speed'=>$speed,'expressive'=>filter_var($d['expressive']??false, FILTER_VALIDATE_BOOLEAN)]];
if($voice!=='')$config['voice']['voice_id']=$voice;
try {
 $r=anx_fish_request('POST','/v1/agent/agents',['name'=>$name,'config'=>$config]);
 $localConfig=$config;if($voice!=='')$localConfig['voice']['provider']='fish_audio';
 try{$aid=agent_local_store((int)$u['id'],$r['data'],$name,$desc,$localConfig);}catch(Throwable $localError){$fid=(string)($r['data']['agent_id']??$r['data']['id']??'');if($fid!==''){try{anx_fish_request('DELETE','/v1/agent/agents/'.rawurlencode($fid));}catch(Throwable $cleanupError){error_log('Fish orphan agent cleanup failed: '.$cleanupError->getMessage());}}throw $localError;}agent_audit((int)$u['id'],$aid,'created',['fish_agent_id'=>$r['data']['agent_id']??$r['data']['id']??'']);
 json_response(['ok'=>true,'agent_id'=>$aid,'message'=>'Agent created as a draft.']);
} catch(Throwable $e){error_log('Agent create failed: '.$e->getMessage());json_response(['ok'=>false,'error'=>$e->getMessage()],502);}
