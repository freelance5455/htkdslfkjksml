<?php
declare(strict_types=1);
require_once __DIR__.'/../../app/agent.php';
api_guard(['GET']);
$u=api_require_user();
$agentId=(int)($_GET['agent_id']??0);
$sessionId=(int)($_GET['session_id']??0);
try {
    $agent=agent_owned($agentId,(int)$u['id']);
    if($sessionId>0){
        $q=db()->prepare('SELECT id,channel,session_status,started_at,ended_at FROM agent_sessions WHERE id=? AND agent_id=? AND user_id=? LIMIT 1');
        $q->execute([$sessionId,$agentId,(int)$u['id']]);
        $session=$q->fetch(PDO::FETCH_ASSOC);
        if(!$session) json_response(['ok'=>false,'error'=>'Conversation not found.'],404);
        $m=db()->prepare('SELECT sender,message,created_at FROM agent_messages WHERE session_id=? ORDER BY id ASC LIMIT 500');
        $m->execute([$sessionId]);
        json_response(['ok'=>true,'session'=>$session,'messages'=>$m->fetchAll(PDO::FETCH_ASSOC)]);
    }
    $q=db()->prepare("SELECT s.id,s.channel,s.session_status,s.started_at,s.ended_at,(SELECT message FROM agent_messages m WHERE m.session_id=s.id ORDER BY m.id DESC LIMIT 1) last_message,(SELECT COUNT(*) FROM agent_messages m WHERE m.session_id=s.id) message_count FROM agent_sessions s WHERE s.agent_id=? AND s.user_id=? ORDER BY s.id DESC LIMIT 40");
    $q->execute([$agentId,(int)$u['id']]);
    json_response(['ok'=>true,'sessions'=>$q->fetchAll(PDO::FETCH_ASSOC)]);
} catch(Throwable $e) {
    error_log('Agent conversation history failed: '.get_class($e));
    json_response(['ok'=>false,'error'=>'Conversation history is temporarily unavailable.'],500);
}
