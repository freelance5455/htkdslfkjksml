<?php
require_once __DIR__.'/../../app/agent.php';api_guard(['POST']);$u=api_require_user();$d=json_input();$id=(int)($d['id']??0);
try{$a=agent_owned($id,(int)$u['id']);$r=anx_fish_request('POST','/v1/agent/agents/'.rawurlencode($a['fish_agent_id']).'/publish',null);
db()->prepare("UPDATE agents SET status='published',publication_state='published',updated_at=? WHERE id=? AND user_id=?")->execute([now_sql(),$id,(int)$u['id']]);agent_audit((int)$u['id'],$id,'published',$r['data']);json_response(['ok'=>true,'provider'=>$r['data'],'message'=>'Agent published.']);}
catch(Throwable $e){json_response(['ok'=>false,'error'=>$e->getMessage()],502);}
