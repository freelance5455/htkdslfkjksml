<?php
require_once __DIR__.'/../../app/agent.php'; api_guard(['GET']); $u=api_require_user(); agent_schema();
$s=db()->prepare("SELECT a.*, (SELECT COUNT(*) FROM agent_knowledge k WHERE k.agent_id=a.id) knowledge_count,(SELECT COUNT(*) FROM agent_sessions x WHERE x.agent_id=a.id) sessions_count FROM agents a WHERE a.user_id=? ORDER BY a.updated_at DESC");$s->execute([(int)$u['id']]);
json_response(['ok'=>true,'agents'=>$s->fetchAll(),'wallet'=>voice_wallet_balance((int)$u['id'])]);
