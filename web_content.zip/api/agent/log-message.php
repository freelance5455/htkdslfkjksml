<?php
require_once __DIR__.'/../../app/agent.php';api_guard(['POST']);$u=api_require_user();$d=json_input();$sid=(int)($d['session_id']??0);$sender=(string)($d['sender']??'');$message=trim((string)($d['message']??''));
if(!in_array($sender,['user','agent'],true)||$message===''||app_text_length($message)>12000)json_response(['ok'=>false,'error'=>'Invalid message.'],422);
$q=db()->prepare('SELECT id FROM agent_sessions WHERE id=? AND user_id=?');$q->execute([$sid,(int)$u['id']]);if(!$q->fetchColumn())json_response(['ok'=>false,'error'=>'Session not found.'],404);
db()->prepare('INSERT INTO agent_messages(session_id,sender,message,created_at) VALUES(?,?,?,?)')->execute([$sid,$sender,$message,now_sql()]);json_response(['ok'=>true]);
