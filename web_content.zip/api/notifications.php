<?php
declare(strict_types=1);
require_once __DIR__.'/../app/resources.php';
try {
    $method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
    api_guard(['GET','POST']);$user=api_require_user();$userId=(int)$user['id'];
    if($method==='GET'){
        $s=db()->prepare('SELECT id,title,message,notification_type,link_url,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 30');$s->execute([$userId]);
        json_response(['ok'=>true,'notifications'=>$s->fetchAll()]);
    }
    $input=json_input();$id=(int)($input['id']??0);$action=(string)($input['action']??'read');
    if($action==='read_all'){db()->prepare('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL')->execute([now_sql(),$userId]);json_response(['ok'=>true]);}
    if($action!=='read'||$id<1)json_response(['ok'=>false,'error'=>'Invalid notification action.'],422);
    $s=db()->prepare('UPDATE notifications SET read_at=? WHERE id=? AND user_id=?');$s->execute([now_sql(),$id,$userId]);
    json_response(['ok'=>true,'updated'=>$s->rowCount()]);
}catch(Throwable $e){error_log('Notification endpoint failure: '.get_class($e));json_response(['ok'=>false,'error'=>'Could not update notifications.'],500);}
