(()=>{'use strict';
const DB='sdtravel_db', STORE='bookings';let db, bookings=[], deferredInstall=null;
const $=id=>document.getElementById(id), val=id=>$(id).value.trim(), num=id=>Number($(id).value||0);
function openDB(){return new Promise((resolve,reject)=>{let r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{let d=r.result;if(!d.objectStoreNames.contains(STORE)){let s=d.createObjectStore(STORE,{keyPath:'id',autoIncrement:true});s.createIndex('code','code',{unique:true});s.createIndex('customer','customer');s.createIndex('travelDate','travelDate')}};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function tx(mode,fn){return new Promise((resolve,reject)=>{let t=db.transaction(STORE,mode),s=t.objectStore(STORE),out;try{out=fn(s)}catch(e){reject(e);return}t.oncomplete=()=>resolve(out);t.onerror=()=>reject(t.error)})}
async function all(){bookings=await new Promise((res,rej)=>{let r=db.transaction(STORE).objectStore(STORE).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});bookings.sort((a,b)=>(b.id||0)-(a.id||0));render()}
const money=n=>(Number(n)||0).toLocaleString('ar-EG')+' ج.م';
function remaining(b){return Math.max(0,(+b.total||0)-(+b.paid||0))}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){let total=bookings.reduce((a,b)=>a+(+b.total||0),0),paid=bookings.reduce((a,b)=>a+(+b.paid||0),0);
$('stats').innerHTML=stat('عدد الحجوزات',bookings.length)+stat('إجمالي المبيعات',money(total))+stat('إجمالي المدفوع',money(paid))+stat('إجمالي المتبقي',money(total-paid));
$('recent').innerHTML=bookings.slice(0,5).map(card).join('')||'<div class="empty">لا توجد حجوزات حتى الآن</div>';
drawList();$('reportStats').innerHTML=$('stats').innerHTML;$('finance').innerHTML=`<p>إجمالي قيمة الحجوزات: <b>${money(total)}</b></p><p>إجمالي المحصل: <b>${money(paid)}</b></p><p>إجمالي المبالغ المتبقية: <b>${money(total-paid)}</b></p><p>عدد الحجوزات المؤكدة: <b>${bookings.filter(b=>b.status==='مؤكد').length}</b></p><p>عدد الحجوزات الملغاة: <b>${bookings.filter(b=>b.status==='ملغي').length}</b></p>`}
function stat(k,v){return `<div class="stat"><small>${k}</small><strong>${v}</strong></div>`}
function card(b){return `<article class="booking"><div><h3>${esc(b.customer)} <span class="muted">(${esc(b.code)})</span></h3><p>السفر: ${esc(b.travelDate||'—')} • ${esc(b.count||1)} فرد • ${esc(b.status||'—')}</p><p>الإجمالي ${money(b.total)} | المدفوع ${money(b.paid)} | المتبقي <b class="money">${money(remaining(b))}</b></p></div><div class="btns"><button class="smallbtn" data-view="${b.id}">عرض</button><button class="smallbtn" data-edit="${b.id}">تعديل</button><button class="smallbtn danger" data-del="${b.id}">حذف</button></div></article>`}
function drawList(){let q=$('search').value.toLowerCase().trim(),arr=bookings.filter(b=>[b.customer,b.code,b.whatsapp,b.phone,b.travelDate].some(x=>String(x||'').toLowerCase().includes(q)));$('bookingList').innerHTML=arr.map(card).join('')||'<div class="empty">لا توجد نتائج</div>'}
function page(p){document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id===p));document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.page===p));if(p==='bookings')drawList();window.scrollTo(0,0)}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>page(b.dataset.page));
$('search').oninput=drawList;$('clearSearch').onclick=()=>{$('search').value='';drawList()};
function companionRow(c={}){let d=document.createElement('div');d.className='companion';d.innerHTML=`<input placeholder="اسم المرافق" value="${esc(c.name||'')}"><select><option ${c.type==='بالغ'?'selected':''}>بالغ</option><option ${c.type==='طفل'?'selected':''}>طفل</option><option ${c.type==='رضيع'?'selected':''}>رضيع</option></select><input type="number" placeholder="السعر" value="${esc(c.price??'')}"><button type="button" class="smallbtn danger">×</button>`;d.querySelector('button').onclick=()=>d.remove();$('companions').appendChild(d)}
$('addCompanion').onclick=()=>companionRow();function companions(){return [...$('companions').children].map(d=>({name:d.children[0].value.trim(),type:d.children[1].value,price:Number(d.children[2].value||0)})).filter(x=>x.name)}
const ids=['code','customer','whatsapp','phone','branch','employee','bookingDate','travelDate','duration','count','hotel','hotelM','hotelD','airline','flightTime','flight','nights','room','tripIncludes','returnPlace','paymentDate','collectionDate','pricePerPerson','remainingInput','bookingEmployee','receptionEmployee','cashReceiver','status','total','paid','paymentMethod','notes','flightDetails','tripDetails'];
function readForm(){let b={};ids.forEach(id=>b[id]=id==='total'||id==='paid'||id==='count'?num(id):val(id));b.companions=companions();return b}
function toDateInput(v){if(!v)return '';let s=String(v).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;let m=s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);if(m)return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;return ''}
function fill(b){ids.forEach(id=>$(id).value=(id==='paymentDate'||id==='collectionDate'||id==='bookingDate'||id==='travelDate')?toDateInput(b[id]):(b[id]??(id==='count'?1:'')));$('companions').innerHTML='';(b.companions||[]).forEach(companionRow);$('editId').value=b.id||'';$('formTitle').textContent=b.id?'تعديل الحجز':'إضافة حجز جديد';$('formMsg').textContent=''}
function reset(){ $('bookingForm').reset();$('editId').value='';$('companions').innerHTML='';$('count').value=1;$('formTitle').textContent='إضافة حجز جديد';$('formMsg').textContent=''}
$('resetForm').onclick=reset;
$('bookingForm').onsubmit=async e=>{e.preventDefault();let b=readForm(),id=$('editId').value;if(!b.code||!b.customer)return;let duplicate=bookings.find(x=>x.code.toLowerCase()===b.code.toLowerCase()&&String(x.id)!==String(id));if(duplicate){$('formMsg').textContent='هذا الكود مستخدم بالفعل. اختر كوداً مختلفاً.';return}
if(id){b.id=Number(id);await tx('readwrite',s=>s.put(b));$('formMsg').textContent='تم تحديث الحجز بنجاح'}else{delete b.id;await tx('readwrite',s=>s.add(b));$('formMsg').textContent='تم حفظ الحجز بنجاح'}await all();setTimeout(()=>{reset();page('bookings')},500)};
document.addEventListener('click',async e=>{let t=e.target;if(t.dataset.edit){let b=bookings.find(x=>x.id==t.dataset.edit);fill(b);page('add')}if(t.dataset.del){let b=bookings.find(x=>x.id==t.dataset.del);if(confirm('هل تريد حذف حجز '+b.customer+'؟')){await tx('readwrite',s=>s.delete(b.id));await all()}}if(t.dataset.view){let b=bookings.find(x=>x.id==t.dataset.view);$('modalBody').innerHTML=`<h2>${esc(b.customer)}</h2><p>الكود: ${esc(b.code)}</p><p>الواتساب: ${esc(b.whatsapp||'—')}</p><p>السفر: ${esc(b.travelDate||'—')} • ${esc(b.duration||'')}</p><p>الفندق: ${esc(b.hotel||'—')} | مكة: ${esc(b.hotelM||'—')} | المدينة: ${esc(b.hotelD||'—')}</p><p>الطيران: ${esc(b.airline||'—')} | الميعاد: ${esc(b.flightTime||'—')} | الرحلة: ${esc(b.flight||'')}</p><p>الأفراد: ${esc(b.count)} | الحالة: ${esc(b.status)}</p><p>الإجمالي: ${money(b.total)} | المدفوع: ${money(b.paid)} | المتبقي: ${money(remaining(b))}</p><p>المرافقون: ${(b.companions||[]).map(c=>esc(c.name)+' ('+esc(c.type)+')').join('، ')||'—'}</p><p>ملاحظات: ${esc(b.notes||'—')}</p>`;$('modal').hidden=false}});
$('closeModal').onclick=()=> $('modal').hidden=true;$('modal').onclick=e=>{if(e.target===$('modal'))$('modal').hidden=true};
function normalize(s){return s.toLowerCase().replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/[ـ]/g,'').replace(/\s+/g,' ').trim()}
function parseWhatsApp(text){
 let lines=text.split(/\r?\n/),out={count:1,status:'مؤكد'}, companionName='';
 const map={
  code:['كود العميل','الكود','كود','رقم الحجز'],
  customer:['اسم العميل','الاسم'],
  hotel:['اسم الفندق'],
  whatsapp:['رقم الواتس','رقم الواتساب','الواتساب','واتساب','whatsapp'],
  phone:['رقم للطوارئ','رقم الطوارئ','رقم الهاتف للطوارئ','الهاتف','تليفون'],
  count:['عدد الافرد','عدد الافراد','عدد الأفراد','الافراد','الأفراد','العدد'],
  airline:['نوع الطيران','شركة الطيران','الطيران'],
  flightTime:['معاد الرحله','ميعاد الرحلة','موعد الرحلة','ميعاد الرحله'],
  duration:['عدد الليالي','مدة الرحلة','المدة'],
  nights:['عدد الليالي'],
  room:['نوع الغرفه','نوع الغرفة','الغرفة'],
  tripIncludes:['رحله تشمل','رحلة تشمل','الرحله تشمل','البرنامج يشمل'],
  returnPlace:['مكان العوده','مكان العودة'],
  paymentDate:['تاريخ الدفع'],
  total:['الاجمالى','الاجمالي','الإجمالي','اجمالي السعر','السعر الاجمالي'],
  paid:['المدفوع','المبلغ المدفوع'],
  remainingInput:['الباقى','الباقي','المتبقي'],
  collectionDate:['تاريخ باقي التحصيل','تاريخ باقى التحصيل','تاريخ تحصيل الباقي'],
  pricePerPerson:['سعر الفرد'],
  bookingEmployee:['موظف الحجز'],
  receptionEmployee:['موظف استقبال','موظف الاستقبال'],
  paymentMethod:['طريقه دفع','طريقة دفع','طريقة الدفع'],
  cashReceiver:['موظف استلام الفلوس','موظف استلام الأموال'],
  branch:['فرع الشركه','فرع الشركة','الفرع']
 };
 const cleanLabel=s=>normalize(s.replace(/^[\s▪︎•●*_\-]+/g,'').replace(/[*_]+$/g,''));
 for(let line of lines){
   let m=line.match(/^\s*([^:：=]{2,60})\s*[:：=]\s*(.*?)\s*$/);
   if(!m)continue;
   let label=cleanLabel(m[1]), value=m[2].trim();
   if(!value)continue;
   if(label===normalize('اسم المرافق الاول')||label===normalize('اسم المرافق الأول')||label===normalize('اسم المرافق')){
      companionName=value; continue;
   }
   for(let [field,aliases] of Object.entries(map)){
     if(aliases.some(a=>normalize(a)===label)){
       if(['count','total','paid','remainingInput','pricePerPerson'].includes(field)){
         let digits=value.replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[^\d.]/g,'');
         out[field]=Number(digits)||0;
       } else if(field==='paymentDate'||field==='collectionDate'){
         // Preserve the source date text if it is not ISO; user can review/edit it.
         out[field]=value;
       } else out[field]=value;
       break;
     }
   }
 }
 if(companionName)out.companions=[{name:companionName,type:'بالغ',price:0}];
 return out;
}
$('parseWA').onclick=()=>{let t=$('waText').value;if(!t.trim()){alert('الصق رسالة واتساب أولاً');return}let b=parseWhatsApp(t);fill(b);page('add');$('formMsg').textContent='راجع البيانات المستخرجة وأكمل الناقص ثم اضغط حفظ الحجز.'};
$('export').onclick=()=>{let blob=new Blob([JSON.stringify({app:'SD TRAVEL',version:1,exportedAt:new Date().toISOString(),bookings},null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='SD_TRAVEL_backup_'+new Date().toISOString().slice(0,10)+'.json';a.click();URL.revokeObjectURL(a.href)};
$('restore').onclick=async()=>{let f=$('restoreFile').files[0];if(!f){$('backupMsg').textContent='اختر ملف النسخة الاحتياطية أولاً';return}try{let data=JSON.parse(await f.text()),arr=Array.isArray(data)?data:data.bookings;if(!Array.isArray(arr))throw Error('invalid');if($('restoreMode').value==='replace')await tx('readwrite',s=>s.clear());for(let b of arr){if(!b.code||!b.customer)continue;let exists=bookings.some(x=>x.code===b.code);if(!exists)await tx('readwrite',s=>s.add({...b,id:undefined}));}await all();$('backupMsg').textContent='تمت الاستعادة بنجاح.'}catch(e){$('backupMsg').textContent='الملف غير صالح أو تعذر استعادته.'}};
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;$('installBtn').hidden=false});$('installBtn').onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null}};
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
(async()=>{try{db=await openDB();await all()}catch(e){alert('تعذر فتح قاعدة البيانات المحلية. تأكد من فتح التطبيق من متصفح حديث.')}})();
})();