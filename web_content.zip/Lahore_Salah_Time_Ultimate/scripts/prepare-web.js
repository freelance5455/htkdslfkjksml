const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const f of ['index.html', 'manifest.webmanifest', 'sw.js', 'icon.svg']) {
  fs.copyFileSync(path.join(root, f), path.join(out, f));
}
console.log('Web assets copied to www/');
