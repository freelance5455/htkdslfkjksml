LAHORE SALAH TIME — ULTIMATE ANDROID SOURCE PACKAGE
Version 3.0 | Languages: English, Urdu, Arabic

WHAT IS INCLUDED
- index.html: responsive Islamic app UI and app logic
- manifest.webmanifest, sw.js, icon.svg: installable PWA shell
- Capacitor configuration and npm dependencies
- Native local-notification integration using @capacitor/local-notifications
- GitHub Actions workflow to build a debug APK in the cloud

FEATURES IN THIS BUILD
1. Lahore prayer times from AlAdhan API, city Lahore, Pakistan, calculation method 1 (Karachi)
2. Next-prayer countdown and daily time refresh
3. English / Urdu / Arabic interface labels
4. Qibla bearing calculation using device location (not a sensor-calibrated compass needle)
5. Hijri date using the browser Islamic calendar (moon-sighting may differ)
6. Quran Arabic text plus Urdu translation when Urdu is selected, otherwise English Sahih translation; fetched online from AlQuran Cloud
7. Small starter dua collection
8. Native Android daily local notification scheduling when running inside Capacitor with the plugin installed

IMPORTANT HONEST LIMITATIONS
- This ZIP is source code, NOT a precompiled APK and NOT signed for Play Store release.
- Prayer times require internet to refresh. Verify the Karachi calculation method against a trusted local Lahore mosque timetable.
- Native notifications require building the Capacitor Android project. Browser/Acode preview does not provide reliable closed-app notifications.
- Android exact-alarm and notification permissions may need to be granted in system settings. OEM battery restrictions can affect delivery.
- Notification schedules are refreshed when the app is opened and times load; reopen the app after daily prayer-time refresh to update the next schedule.
- Qibla currently calculates a bearing from GPS location, but does not use the phone's magnetic heading sensor to rotate the compass automatically.
- Quran and translations are online; a complete offline Quran database, recitation audio, tafsir, bookmarks and downloads are not included.
- The dua list is a small starter list, not a comprehensive authenticated adhkar library.

BUILD APK — CLOUD BUILD FROM A PHONE (RECOMMENDED)
1. Extract this ZIP on your phone.
2. Create/sign in to a GitHub account and create a new empty repository.
3. Upload all files and folders from this ZIP to the repository root (including the hidden .github folder; enable hidden files if needed).
4. Open the repository on GitHub in Chrome. Go to Actions → “Build Android APK” → Run workflow.
5. Wait for the workflow to finish successfully. Open the completed run and download the artifact named “Lahore-Salah-Time-debug-apk”.
6. Extract the artifact ZIP and install app-debug.apk. Android may ask you to allow installs from that browser/file manager.

ALTERNATIVE LOCAL BUILD
Requires Node.js 20, Java 17, Android SDK and Gradle/Android build tools:
  npm install
  npm run prepare:web
  npx cap add android
  npx cap sync android
  cd android && ./gradlew assembleDebug
APK output: android/app/build/outputs/apk/debug/app-debug.apk

AFTER INSTALLATION
- Open the app and allow notifications and location when prompted.
- Tap Enable on Prayer reminders.
- For exact-time alerts, allow Alarms & reminders / exact alarms if Android offers that setting.
- Test with a near-future test schedule before relying on reminders.

DATA SOURCES
Prayer times: AlAdhan API (method 1)
Quran text/translations: AlQuran Cloud API

This is a practical starter app project, not a certified religious authority. Confirm prayer calculations and translations with trusted local sources.
