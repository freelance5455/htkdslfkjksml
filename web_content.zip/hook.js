if (typeof Runtime !== 'undefined') {
  const _exec = Runtime.prototype.exec;
  Runtime.prototype.exec = function(cmd) {
    if (typeof cmd === 'string' && (
      cmd.includes('anticheat') ||
      cmd.includes('scan') ||
      cmd.includes('memory') ||
      cmd.includes('detect') ||
      cmd.includes('dump')
    )) { console.log('Hook blocked:', cmd); return null; }
    return _exec.call(this, cmd);
  };
}