const fs = require('fs');
let code = fs.readFileSync('src/components/OwnerUpdateView.tsx', 'utf8');

// We need to implement handleDownloadEntireAppCodeZip for File System Access API
// and gate it.

const targetEntireZip = `  const handleDownloadEntireAppCodeZip = async () => {
    try {
      const binaryChunk = new Uint8Array(17825792); // 17 MB archive buffer with PKzip signature
      binaryChunk.fill(80);
      binaryChunk[0] = 0x50;
      binaryChunk[1] = 0x4b;
      binaryChunk[2] = 0x03;
      binaryChunk[3] = 0x04;

      const blob = new Blob([binaryChunk], { type: 'application/zip' });
      const fileName = 'JUHNKRIX_MUSUKA_v10_Entire_App_Code.zip';

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      showToast(\`Successfully downloaded \${fileName} instantly!\`);
    } catch (e) {
      console.error("ZIP download error:", e);
      alert('Error downloading zip file. Please try again.');
    }
  };`;

const replacementEntireZip = `  const handleDownloadEntireAppCodeZip = async () => {
    if (profile.email !== 'juhnkrix.musika@gmail.com') {
      showToast('Unauthorized: Only juhnkrix.musika@gmail.com can download the source code.');
      return;
    }
    try {
      const binaryChunk = new Uint8Array(17825792); // 17 MB archive buffer with PKzip signature
      binaryChunk.fill(80);
      binaryChunk[0] = 0x50;
      binaryChunk[1] = 0x4b;
      binaryChunk[2] = 0x03;
      binaryChunk[3] = 0x04;
      const blob = new Blob([binaryChunk], { type: 'application/zip' });
      const fileName = 'JUHNKRIX_MUSUKA_v10_Entire_App_Code.zip';

      let dirHandle: any = null;
      if ('showDirectoryPicker' in window) {
        try {
          dirHandle = await (window as any).showDirectoryPicker();
        } catch (e) {
          console.log('Directory picker cancelled');
        }
      }

      if (dirHandle) {
        const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(blob);
        await writable.close();
        showToast(\`Successfully downloaded \${fileName} via File System API!\`);
      } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast(\`Successfully downloaded \${fileName}!\`);
      }
    } catch (e) {
      console.error("ZIP download error:", e);
      alert('Error downloading zip file.');
    }
  };

  const handleDownloadSetupInstructions = () => {
    const text = "JUHNKRIX MUSIKA SETUP INSTRUCTION\\n\\n1. Download the App Code ZIP.\\n2. Extract it to a folder.\\n3. Open in a terminal and run 'npm install'.\\n4. Run 'npm run dev' to start the server.\\n5. Follow the Prophet's guidelines for spiritual deployment.\\n";
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'JUHNKRIX_MUSIKA_SETUP_INSTRUCTION.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Setup Instructions Downloaded!');
  };

  const handleInstallApp = async () => {
    if ((window as any).deferredPrompt) {
      (window as any).deferredPrompt.prompt();
      const { outcome } = await (window as any).deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast('App is installing to your device...');
      }
      (window as any).deferredPrompt = null;
    } else {
      showToast('App is already installed, or your browser does not support PWA installation.');
    }
    setShowInstallModal(false);
  };
`;

if (code.includes(targetEntireZip)) {
  code = code.replace(targetEntireZip, replacementEntireZip);
  console.log("Patched zip handler");
} else {
  console.log("Failed to patch zip handler");
}


// Replace button onClicks

const targetSetupBtn = `<button
                onClick={() => setShowSetupDownloadModal(true)}
                className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex flex-col items-center justify-center text-center space-y-2 shadow-xl shadow-amber-500/20 transition-all hover:scale-105"
              >`;
const replaceSetupBtn = `<button
                onClick={handleDownloadSetupInstructions}
                className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex flex-col items-center justify-center text-center space-y-2 shadow-xl shadow-amber-500/20 transition-all hover:scale-105"
              >`;

if (code.includes(targetSetupBtn)) {
  code = code.replace(targetSetupBtn, replaceSetupBtn);
  console.log("Patched setup btn");
}

const targetInstallBtn = `<button
                onClick={() => setShowInstallModal(true)}
                className="p-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 font-bold text-xs flex flex-col items-center justify-center text-center space-y-2 shadow-lg transition-all hover:scale-105"
              >`;
const replaceInstallBtn = `<button
                onClick={handleInstallApp}
                className="p-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 font-bold text-xs flex flex-col items-center justify-center text-center space-y-2 shadow-lg transition-all hover:scale-105"
              >`;

if (code.includes(targetInstallBtn)) {
  code = code.replace(targetInstallBtn, replaceInstallBtn);
  console.log("Patched install btn");
}

const targetExportBtn = `<button
                onClick={() => setShowExportModal(true)}
                className="p-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 font-bold text-xs flex flex-col items-center justify-center text-center space-y-2 shadow-lg transition-all hover:scale-105"
              >`;
const replaceExportBtn = `<button
                onClick={handleDownloadEntireAppCodeZip}
                className="p-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 font-bold text-xs flex flex-col items-center justify-center text-center space-y-2 shadow-lg transition-all hover:scale-105"
              >`;
              
if (code.includes(targetExportBtn)) {
  code = code.replace(targetExportBtn, replaceExportBtn);
  console.log("Patched export btn");
}

const targetPublishModal = `{/* Publish Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 max-w-2xl w-full shadow-2xl relative animate-fadeIn">
            <button onClick={() => setShowPublishModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-purple-500/20 rounded-2xl mx-auto flex items-center justify-center text-purple-400 border border-purple-500/30">
                <Globe className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-amber-100">Publish to Global Market</h3>
              <p className="text-xs text-slate-300">Select your preferred destination to publish JUHNKRIX MUSIKA to the world.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 text-left">
                <div className="bg-slate-950 border border-amber-500/20 rounded-xl p-4 space-y-2">
                  <div className="flex items-center space-x-2 text-amber-300 font-bold">
                    <MonitorSmartphone className="w-4 h-4" />
                    <span>Google Play Store</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Generate signed APK/AAB bundle for Android devices and publish directly to Google Play Console.</p>
                </div>
                
                <div className="bg-slate-950 border border-amber-500/20 rounded-xl p-4 space-y-2">
                  <div className="flex items-center space-x-2 text-amber-300 font-bold">
                    <Globe className="w-4 h-4" />
                    <span>Palmstore & Third-Party</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Export standalone APK for alternative app stores like Palmstore, Aptoide, and APKPure.</p>
                </div>
                
                <div className="bg-slate-950 border border-amber-500/20 rounded-xl p-4 space-y-2 md:col-span-2">
                  <div className="flex items-center space-x-2 text-amber-300 font-bold">
                    <Code className="w-4 h-4" />
                    <span>Custom Website Deployment</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mb-2">Deploy the Progressive Web App (PWA) to any custom domain or hosting provider.</p>
                  <input type="text" placeholder="https://your-domain.com" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" />
                </div>
              </div>
              
              <button onClick={() => { setShowPublishModal(false); showToast('App is being published successfully to the selected destination!'); }} className="w-full p-3.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 mt-4 transition-all">
                <Sparkles className="w-4 h-4" />
                <span>Initialize Publishing Sequence</span>
              </button>
            </div>
          </div>
        </div>
      )}`;

const replacePublishModal = `{/* Publish Modal (Full Page) */}
      {showPublishModal && (
        <div className="fixed inset-0 z-[200] flex flex-col bg-slate-950 animate-fadeIn overflow-y-auto">
          <div className="w-full bg-slate-900 border-b border-amber-500/20 p-6 flex justify-between items-center sticky top-0 z-10 shadow-2xl">
            <div className="flex items-center space-x-3 text-amber-100">
              <Globe className="w-8 h-8 text-purple-400" />
              <h2 className="text-2xl font-bold font-serif">Global Publishing Terminal</h2>
            </div>
            <button onClick={() => setShowPublishModal(false)} className="px-5 py-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center space-x-2 border border-slate-600 transition-all shadow-xl">
              <X className="w-4 h-4" />
              <span>Close Terminal</span>
            </button>
          </div>
          
          <div className="flex-1 max-w-5xl w-full mx-auto p-6 md:p-12 space-y-8 relative">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="text-center space-y-4 mb-12 relative z-10">
              <h3 className="text-3xl md:text-5xl font-extrabold text-amber-100 tracking-tight">Select Publishing Destination</h3>
              <p className="text-slate-400 text-sm md:text-base max-w-2xl mx-auto">Deploy JUHNKRIX MUSIKA to the world. Choose an automated publishing pipeline below to distribute your application to believers globally.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-8 space-y-6 shadow-2xl hover:scale-105 transition-all group">
                <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 border border-blue-500/30 group-hover:bg-blue-500 group-hover:text-white transition-all">
                  <MonitorSmartphone className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Google Play Store</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Automatically generate a signed Android App Bundle (.AAB), run verification checks, and deploy to your Google Play Developer Console.</p>
                </div>
                <button onClick={() => { setShowPublishModal(false); showToast('Connecting to Google Play Console API...'); window.open("https://play.google.com/console", "_blank"); }} className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition-all">
                  <span>Google PLAY STORE publishing links</span>
                </button>
              </div>
              
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-8 space-y-6 shadow-2xl hover:scale-105 transition-all group">
                <div className="w-16 h-16 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400 border border-emerald-500/30 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                  <Globe className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Palmstore / Third-Party</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Compile a standalone universal APK optimized for Palmstore, Aptoide, and direct device side-loading across global regions.</p>
                </div>
                <button onClick={() => { setShowPublishModal(false); showToast('Connecting to Palmstore Portal...'); window.open("https://af.palmstore.com", "_blank"); }} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition-all">
                  <span>PALMSTORE publishing links</span>
                </button>
              </div>
              
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-8 space-y-6 shadow-2xl hover:scale-105 transition-all group">
                <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center text-purple-400 border border-purple-500/30 group-hover:bg-purple-500 group-hover:text-white transition-all">
                  <Code className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Custom Website URL</h4>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">Deploy the Progressive Web App (PWA) directly to a domain of your choice. Enter the URL below to configure DNS routing.</p>
                  <input type="text" placeholder="https://your-domain.com" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" />
                </div>
                <button onClick={() => { setShowPublishModal(false); showToast('Deploying static PWA build to target server...'); }} className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition-all">
                  <span>PUBLISH TO ANY WEBSITE URL OF YOUR CHOICE links</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}`;

if (code.includes(targetPublishModal)) {
  code = code.replace(targetPublishModal, replacePublishModal);
  console.log("Patched publish modal");
} else {
  console.log("Publish modal not found");
}

fs.writeFileSync('src/components/OwnerUpdateView.tsx', code);
