#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "Installation des dépendances Termux pour APKForge..."
pkg update -y
pkg install -y nodejs openjdk-17 wget unzip aapt apksigner dx ecj

if [ ! -f "android.jar" ]; then
  echo "Téléchargement de android.jar (API 33)..."
  wget -O android.jar https://github.com/Sable/android-platforms/raw/master/android-33/android.jar
fi

npm install
echo "Installation terminée ! Lancez : npm start"
