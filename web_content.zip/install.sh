#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "تجهيز BOT VODEKA..."
pkg update -y
pkg install python -y
echo
echo "تم تثبيت Python."
echo "تأكد أن monitor.py و index.html في المجلد الحالي."
