# CPLS V2 — Stage 1118

## هدف
کاهش فشار روی LBank Futures و جلوگیری از OFFLINE کاذب ناشی از rate-limit یا درخواست‌های تکراری.

## تغییرات
- برای Futures Order Book کش کوتاه حدود ۱.۲ ثانیه اضافه شد.
- خطاهای Futures باعث backoff تطبیقی می‌شوند: حدود ۱.۵، ۳، ۶، ۱۲، ۲۴ و حداکثر ۳۰ ثانیه.
- بعد از دریافت موفق Market، شمارنده خطا و backoff همان نماد پاک می‌شود.
- پیام وضعیت خطا اکنون زمان retry بعدی را هم نگه می‌دارد.
- داده‌های موفق همچنان در کش باقی می‌مانند تا هنگام یک خطای لحظه‌ای صفحه بلافاصله خالی نشود.
- هیچ subscription حدسی برای Futures WebSocket اضافه نشده است؛ endpoint رسمی Futures WebSocket همچنان `wss://lbkperpws.lbank.com/ws` است، اما فرمت subscription عمومی آن در مستند فعلی به‌صورت قابل اتکا ارائه نشده است.

## نتیجه
Feed Futures همچنان Native و persistent است، اما در برابر rate-limit و نوسان شبکه مقاوم‌تر شده است.
