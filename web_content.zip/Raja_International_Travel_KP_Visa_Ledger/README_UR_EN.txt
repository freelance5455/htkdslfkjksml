RAJA INTERNATIONAL TRAVEL KP VISA LEDGER — SETUP GUIDE
====================================

یہ ZIP ایک آف لائن استعمال کے قابل ویب ایپ (PWA) ہے۔ اس میں کلائنٹ/ویزا فائل، طے شدہ سروس چارجز، وصولیاں، بقایا، اندازاً منافع، اخراجات، رسید پرنٹ، WhatsApp شیئر اور دستی JSON بیک اپ شامل ہیں۔

IMPORTANT / ضروری:
- ڈیٹا اسی براؤزر اور ڈیوائس میں IndexedDB کے اندر محفوظ ہوتا ہے۔
- یہ کلاؤڈ ایپ نہیں ہے؛ موبائل اور لیپ ٹاپ کے درمیان ڈیٹا خود بخود sync نہیں ہوگا۔
- بیک اپ فائل باقاعدگی سے ڈاؤن لوڈ کرکے محفوظ جگہ پر رکھیں۔
- اس میں ویزا کی منظوری کی کوئی ضمانت نہیں؛ فیصلے متعلقہ سفارت خانہ/اتھارٹی کرتی ہے۔
- یہ ابتدائی کاروباری ریکارڈ ایپ ہے، باقاعدہ اکاؤنٹنگ یا قانونی مشورے کا متبادل نہیں۔

RUN ON A LAPTOP
1. ZIP extract کریں۔
2. index.html کو modern browser میں کھول کر بنیادی فیچرز آزما سکتے ہیں۔
3. PWA install اور service-worker offline caching کے لیے folder کو localhost/HTTPS پر چلائیں۔
   اگر Python نصب ہے تو folder میں terminal کھول کر:
       python -m http.server 8000
   پھر browser میں کھولیں:
       http://localhost:8000
4. پہلی مرتبہ page load ہونے کے بعد app cache ہو سکتی ہے اور اسی browser profile میں offline کھل سکتی ہے۔

RUN ON ANDROID
1. ZIP extract کرنے کے لیے Files app یا ZIP extractor استعمال کریں۔
2. PWA کی بہترین offline/install سہولت کے لیے folder کو HTTPS hosting پر اپ لوڈ کریں، یا Android پر localhost server app کے ذریعے serve کریں۔
3. URL کو Chrome میں کھولیں، پہلی بار مکمل load ہونے دیں، پھر browser menu میں “Install app” یا “Add to Home screen” منتخب کریں۔
4. صرف index.html کو file:// سے کھولنے پر IndexedDB چل سکتا ہے، مگر service worker/PWA installation عموماً کام نہیں کرتے۔

FEATURES
- Client name, mobile, passport, country, visa type, file status, submission date, charges and file cost
- Statuses: Pending, Processing, Documents Required, Appointment Booked, Submitted, Approved, Rejected, Closed
- Payments, payment method and printable receipt
- Client bill print and WhatsApp message sharing
- Expense ledger and estimated profit dashboard
- JSON export and restore
- English / Urdu language selection

PROFIT NOTE
Dashboard estimated net profit = recorded client payments minus recorded client direct/file costs minus recorded business expenses. It does not automatically include any unrecorded costs or taxes. “Agreed charges” and “received” are tracked separately.

BACKUP / RESTORE
Backup tab > Download Backup File. To restore, choose a JSON backup and click Restore. Restore replaces all current records, so make a backup first.

TROUBLESHOOTING
- If the app cannot save, use a modern browser such as current Chrome/Edge.
- Avoid clearing browser site data; this may delete local records.
- WhatsApp share opens WhatsApp Web/app and requires the user to choose a chat and send manually.
- Receipt printing uses the browser print dialog; allow pop-ups if blocked.


UPDATED CLIENT FIELDS
- File date and time
- Aqad Amal / عقدِ عمل (employment contract) status
- Visa process details
- Total agreed payment, received amount (calculated from payment records), remaining amount (calculated)
- Each payment has its own received-payment date
