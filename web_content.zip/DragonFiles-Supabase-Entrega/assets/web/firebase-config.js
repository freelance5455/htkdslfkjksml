// Firebase Web config - projeto DragonFiles
export const firebaseConfig = {
  apiKey: "AIzaSyCjoRc082-8I5Ilbf_0oJICh4RpYST4BFk",
  authDomain: "dragonfiles-c1625.firebaseapp.com",
  projectId: "dragonfiles-c1625",
  storageBucket: "dragonfiles-c1625.firebasestorage.app",
  messagingSenderId: "31421858675",
  appId: "1:31421858675:web:98691a9ed0884da1363b06",
  measurementId: "G-2LQQPSS495"
};
