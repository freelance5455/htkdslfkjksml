// DragonFiles: Firebase Authentication + Supabase Storage/Database via Edge Function.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const API = "https://nyouhhnzuqqfczlbvkpm.supabase.co/functions/v1/dragonfiles-api";
const QUOTA = 5 * 1024 * 1024 * 1024;
const $ = id => document.getElementById(id);
let currentUser = null;
let fileCache = [];

function message(id, text, error=false){ const el=$(id); el.textContent=text; el.style.color=error?"#ff9cba":"#d8baff"; }
function formatBytes(n){ if(!n)return "0 B"; const units=["B","KB","MB","GB"]; const i=Math.min(Math.floor(Math.log(n)/Math.log(1024)),3); return `${(n/Math.pow(1024,i)).toFixed(i===0?0:2)} ${units[i]}`; }
function showAuth(){ $("authView").classList.remove("hidden"); $("appView").classList.add("hidden"); $("logoutBtn").classList.add("hidden"); }
function showApp(user){ $("authView").classList.add("hidden"); $("appView").classList.remove("hidden"); $("logoutBtn").classList.remove("hidden"); $("accountLabel").textContent=user.email||"Conta DragonFiles"; }
async function api(action, {file, id}={}) {
  if (!currentUser) throw new Error("Entre novamente na sua conta.");
  const token = await currentUser.getIdToken(true);
  const headers = { Authorization: `Bearer ${token}`, "x-action": action };
  let body;
  if (file) { body = new FormData(); body.append("file", file, file.name); }
  else if (id) { headers["Content-Type"] = "application/json"; body = JSON.stringify({id}); }
  const response = await fetch(API, { method: "POST", headers, body });
  const result = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(result.error || `Falha no servidor (${response.status}).`);
  return result;
}

$("loginBtn").addEventListener("click", async()=>{ try{ message("authMessage","Entrando..."); await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value); }catch(e){message("authMessage",friendly(e),true);} });
$("registerBtn").addEventListener("click", async()=>{ try{ if($("password").value.length<6) throw new Error("A senha precisa ter pelo menos 6 caracteres."); message("authMessage","Criando conta..."); await createUserWithEmailAndPassword(auth,$("email").value.trim(),$("password").value); }catch(e){message("authMessage",friendly(e),true);} });
$("logoutBtn").addEventListener("click",()=>signOut(auth));
$("fileInput").addEventListener("change",async e=>{ const file=e.target.files?.[0]; if(file) await uploadFile(file); e.target.value=""; });
onAuthStateChanged(auth, async user=>{ currentUser=user; if(!user){showAuth();return;} showApp(user); await refreshFiles(); });

async function uploadFile(file){
  message("appMessage",`Enviando ${file.name}...`);
  try { await api("upload", {file}); message("appMessage","Arquivo enviado com sucesso!"); await refreshFiles(); }
  catch(e){ message("appMessage",friendly(e),true); }
}
async function refreshFiles(){
  if(!currentUser)return;
  try {
    const result=await api("list"); fileCache=result.files||[]; const used=Number(result.usedBytes||0);
    $("storageText").textContent=`${formatBytes(used)} de 5 GB`;
    $("storageBar").style.width=`${Math.min(100,used/QUOTA*100)}%`;
    $("storageHint").textContent=`${Math.max(0,100-used/QUOTA*100).toFixed(1)}% disponível`;
    const list=$("fileList"); list.replaceChildren(); $("emptyState").classList.toggle("hidden",fileCache.length!==0);
    for(const f of fileCache){
      const card=document.createElement("article"); card.className="file-card";
      const icon=document.createElement("div"); icon.className="file-icon"; icon.textContent="▤";
      const info=document.createElement("div"); info.className="file-info";
      const name=document.createElement("div"); name.className="file-name"; name.textContent=f.name||"Arquivo";
      const meta=document.createElement("div"); meta.className="file-meta"; meta.textContent=formatBytes(f.size_bytes||0);
      info.append(name,meta);
      const actions=document.createElement("div"); actions.className="file-actions";
      const down=document.createElement("button"); down.textContent="Baixar"; down.addEventListener("click",()=>downloadFile(f));
      const del=document.createElement("button"); del.textContent="Excluir"; del.className="delete"; del.addEventListener("click",()=>removeFile(f));
      actions.append(down,del); card.append(icon,info,actions); list.append(card);
    }
  } catch(e){message("appMessage",friendly(e),true);}
}
async function downloadFile(file){
  try { const result=await api("download",{id:file.id}); const a=document.createElement("a"); a.href=result.url; a.download=file.name||"arquivo"; a.target="_blank"; document.body.append(a); a.click(); a.remove(); }
  catch(e){message("appMessage",friendly(e),true);}
}
async function removeFile(file){
  if(!confirm(`Excluir "${file.name}"?`))return;
  try { await api("delete",{id:file.id}); message("appMessage","Arquivo excluído."); await refreshFiles(); }
  catch(e){message("appMessage",friendly(e),true);}
}
function friendly(e){ const code=e.code||""; if(code.includes("auth/invalid-credential"))return "E-mail ou senha incorretos."; if(code.includes("auth/email-already-in-use"))return "Este e-mail já possui uma conta."; if(code.includes("auth/invalid-email"))return "E-mail inválido."; return e.message||"Ocorreu um erro inesperado."; }
