// DragonFiles: Firebase Web SDK. Preencha firebaseConfig no arquivo firebase-config.js.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, getDocs, deleteDoc, runTransaction, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app), db = getFirestore(app), storage = getStorage(app);
const QUOTA = 5 * 1024 * 1024 * 1024;
const $ = id => document.getElementById(id);
let currentUser = null;

function message(id, text, error=false){ const el=$(id); el.textContent=text; el.style.color=error?"#ff9cba":"#d8baff"; }
function formatBytes(n){ if(!n)return "0 B"; const units=["B","KB","MB","GB"]; const i=Math.min(Math.floor(Math.log(n)/Math.log(1024)),3); return `${(n/Math.pow(1024,i)).toFixed(i===0?0:2)} ${units[i]}`; }
function showAuth(){ $("authView").classList.remove("hidden"); $("appView").classList.add("hidden"); $("logoutBtn").classList.add("hidden"); }
function showApp(user){ $("authView").classList.add("hidden"); $("appView").classList.remove("hidden"); $("logoutBtn").classList.remove("hidden"); $("accountLabel").textContent=user.email||"Conta DragonFiles"; }

$("loginBtn").addEventListener("click", async()=>{ try{ message("authMessage","Entrando..."); await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value); }catch(e){message("authMessage",friendly(e),true);} });
$("registerBtn").addEventListener("click", async()=>{ try{ if($("password").value.length<6) throw new Error("A senha precisa ter pelo menos 6 caracteres."); message("authMessage","Criando conta..."); const cred=await createUserWithEmailAndPassword(auth,$("email").value.trim(),$("password").value); await setDoc(doc(db,"users",cred.user.uid),{usedBytes:0,createdAt:serverTimestamp()},{merge:true}); }catch(e){message("authMessage",friendly(e),true);} });
$("logoutBtn").addEventListener("click",()=>signOut(auth));
$("fileInput").addEventListener("change",async e=>{ const file=e.target.files?.[0]; if(file) await uploadFile(file); e.target.value=""; });

onAuthStateChanged(auth, async user=>{ currentUser=user; if(!user){showAuth();return;} showApp(user); await refreshFiles(); });

async function getUsage(){ const snap=await getDoc(doc(db,"users",currentUser.uid)); return Number(snap.data()?.usedBytes||0); }
async function uploadFile(file){
  const input=$("fileInput"); message("appMessage","Verificando espaço disponível...");
  try{
    const used=await getUsage();
    if(file.size+used>QUOTA) throw new Error("Este envio ultrapassa o limite de 5 GB da conta.");
    const safeName=file.name.replace(/[\\/#?]/g,"_");
    const path=`users/${currentUser.uid}/${crypto.randomUUID()}_${safeName}`;
    message("appMessage",`Enviando ${file.name}...`);
    const fileRef=ref(storage,path);
    await uploadBytes(fileRef,file,{contentType:file.type||"application/octet-stream"});
    try{
      await runTransaction(db,async tx=>{
        const userRef=doc(db,"users",currentUser.uid), snap=await tx.get(userRef);
        const latest=Number(snap.data()?.usedBytes||0);
        if(latest+file.size>QUOTA) throw new Error("Limite de 5 GB atingido durante o envio.");
        tx.set(userRef,{usedBytes:latest+file.size},{merge:true});
      });
      await addDoc(collection(db,"users",currentUser.uid,"files"),{name:file.name,path,size:file.size,type:file.type||"application/octet-stream",createdAt:serverTimestamp()});
    }catch(err){ await deleteObject(fileRef).catch(()=>{}); throw err; }
    message("appMessage","Arquivo enviado com sucesso!"); await refreshFiles();
  }catch(e){message("appMessage",friendly(e),true);}
}
async function refreshFiles(){
  if(!currentUser)return;
  try{
    const used=await getUsage(); $("storageText").textContent=`${formatBytes(used)} de 5 GB`;
    $("storageBar").style.width=`${Math.min(100,used/QUOTA*100)}%`;
    $("storageHint").textContent=`${Math.max(0,100-used/QUOTA*100).toFixed(1)}% disponível`;
    const snap=await getDocs(collection(db,"users",currentUser.uid,"files"));
    const list=$("fileList"); list.replaceChildren(); $("emptyState").classList.toggle("hidden",!snap.empty);
    snap.forEach(d=>{
      const f=d.data(), card=document.createElement("article"); card.className="file-card";
      const icon=document.createElement("div"); icon.className="file-icon"; icon.textContent="▤";
      const info=document.createElement("div"); info.className="file-info";
      const name=document.createElement("div"); name.className="file-name"; name.textContent=f.name||"Arquivo";
      const meta=document.createElement("div"); meta.className="file-meta"; meta.textContent=formatBytes(f.size||0);
      info.append(name,meta);
      const actions=document.createElement("div"); actions.className="file-actions";
      const down=document.createElement("button"); down.textContent="Baixar"; down.addEventListener("click",()=>downloadFile(f.path,f.name));
      const del=document.createElement("button"); del.textContent="Excluir"; del.className="delete"; del.addEventListener("click",()=>removeFile(d.id,f));
      actions.append(down,del); card.append(icon,info,actions); list.append(card);
    });
  }catch(e){message("appMessage",friendly(e),true);}
}
async function downloadFile(path,name){ try{ const url=await getDownloadURL(ref(storage,path)); const a=document.createElement("a"); a.href=url; a.download=name||"arquivo"; a.target="_blank"; document.body.append(a); a.click(); a.remove(); }catch(e){message("appMessage",friendly(e),true);} }
async function removeFile(id,file){
  if(!confirm(`Excluir "${file.name}"?`))return;
  try{
    await deleteObject(ref(storage,file.path));
    await deleteDoc(doc(db,"users",currentUser.uid,"files",id));
    await runTransaction(db,async tx=>{const r=doc(db,"users",currentUser.uid),s=await tx.get(r);tx.set(r,{usedBytes:Math.max(0,Number(s.data()?.usedBytes||0)-Number(file.size||0))},{merge:true});});
    message("appMessage","Arquivo excluído."); await refreshFiles();
  }catch(e){message("appMessage",friendly(e),true);}
}
function friendly(e){ const code=e.code||""; if(code.includes("auth/invalid-credential"))return "E-mail ou senha incorretos."; if(code.includes("auth/email-already-in-use"))return "Este e-mail já possui uma conta."; if(code.includes("auth/invalid-email"))return "E-mail inválido."; if(code.includes("permission-denied"))return "Acesso negado. Confira as regras do Firebase."; if(code.includes("storage/unauthorized"))return "O Firebase Storage não autorizou esta operação."; return e.message||"Ocorreu um erro inesperado."; }
