import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { cert, initializeApp, getApps } from "npm:firebase-admin@12/app";
import { getAuth } from "npm:firebase-admin@12/auth";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, "Content-Type": "application/json" },
});

const projectId = Deno.env.get("FIREBASE_PROJECT_ID")!;
const serviceAccountRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON")!;
if (!serviceAccountRaw) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON não configurado.");
const serviceAccount = JSON.parse(serviceAccountRaw);
if (!getApps().length) initializeApp({ credential: cert(serviceAccount), projectId });
const adminAuth = getAuth();
const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false, autoRefreshToken: false },
});
const BUCKET = "dragonfiles";
const QUOTA = 5 * 1024 * 1024 * 1024;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  try {
    const bearer = req.headers.get("Authorization") || "";
    const token = bearer.startsWith("Bearer ") ? bearer.slice(7) : "";
    if (!token) return json({ error: "Sessão ausente." }, 401);
    const decoded = await adminAuth.verifyIdToken(token, true);
    const uid = decoded.uid;
    const action = req.headers.get("x-action") || "";

    if (action === "list") {
      const { data, error } = await supabase.from("files").select("id,name,storage_path,size_bytes,content_type,created_at").eq("owner_uid", uid).order("created_at", { ascending: false });
      if (error) throw error;
      return json({ files: data || [], usedBytes: (data || []).reduce((n, f) => n + Number(f.size_bytes || 0), 0) });
    }
    if (action === "upload") {
      const form = await req.formData();
      const file = form.get("file");
      if (!(file instanceof File)) return json({ error: "Arquivo ausente." }, 400);
      const { data: existing, error: listError } = await supabase.from("files").select("size_bytes").eq("owner_uid", uid);
      if (listError) throw listError;
      const used = (existing || []).reduce((n, f) => n + Number(f.size_bytes || 0), 0);
      if (used + file.size > QUOTA) return json({ error: "Limite de 5 GB atingido." }, 413);
      const safe = file.name.replace(/[\\/#?]/g, "_").slice(0, 180) || "arquivo";
      const path = `${uid}/${crypto.randomUUID()}_${safe}`;
      const bytes = new Uint8Array(await file.arrayBuffer());
      const { error: uploadError } = await supabase.storage.from(BUCKET).upload(path, bytes, {
        contentType: file.type || "application/octet-stream", upsert: false,
      });
      if (uploadError) throw uploadError;
      const { data, error: insertError } = await supabase.from("files").insert({
        owner_uid: uid, name: file.name, storage_path: path, size_bytes: file.size,
        content_type: file.type || "application/octet-stream",
      }).select("id,name,storage_path,size_bytes,content_type,created_at").single();
      if (insertError) {
        await supabase.storage.from(BUCKET).remove([path]);
        throw insertError;
      }
      return json({ file: data });
    }
    const body = await req.json();
    const id = String(body.id || "");
    const { data: record, error: getError } = await supabase.from("files").select("*").eq("id", id).eq("owner_uid", uid).maybeSingle();
    if (getError) throw getError;
    if (!record) return json({ error: "Arquivo não encontrado." }, 404);
    if (action === "download") {
      const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(record.storage_path, 60);
      if (error) throw error;
      return json({ url: data.signedUrl });
    }
    if (action === "delete") {
      const { error: storageError } = await supabase.storage.from(BUCKET).remove([record.storage_path]);
      if (storageError) throw storageError;
      const { error: deleteError } = await supabase.from("files").delete().eq("id", id).eq("owner_uid", uid);
      if (deleteError) throw deleteError;
      return json({ ok: true });
    }
    return json({ error: "Ação inválida." }, 400);
  } catch (e) {
    console.error(e);
    return json({ error: e instanceof Error ? e.message : "Erro interno." }, 500);
  }
});
