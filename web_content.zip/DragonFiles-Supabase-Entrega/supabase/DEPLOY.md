# Publicação da integração

A publicação precisa ser feita no projeto Supabase proprietário, autenticado pela CLI:

```bash
supabase login
supabase link --project-ref nyouhhnzuqqfczlbvkpm
supabase secrets set SUPABASE_URL=https://nyouhhnzuqqfczlbvkpm.supabase.co
supabase secrets set SUPABASE_SERVICE_ROLE_KEY='SUA_SERVICE_ROLE_KEY'
supabase secrets set FIREBASE_PROJECT_ID=dragonfiles-c1625
supabase secrets set FIREBASE_SERVICE_ACCOUNT_JSON='JSON_COMPLETO_DA_SERVICE_ACCOUNT'
supabase functions deploy dragonfiles-api
```

Execute `schema.sql` no SQL Editor antes de publicar. Não compartilhe a service role nem o JSON da service account.

Depois, coloque `assets/web/app.js` e os demais arquivos de `assets/web/` no projeto Android/empacotador. O APK final só pode ser montado no projeto Android original ou após reconstrução dele, com Gradle/SDK e chave de assinatura.
