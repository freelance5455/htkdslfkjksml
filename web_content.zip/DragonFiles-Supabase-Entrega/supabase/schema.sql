-- DragonFiles: completar a tabela existente sem apagar linhas.
-- Execute no SQL Editor do projeto correto após conferir o schema atual.
create extension if not exists pgcrypto;

create table if not exists public.files (
  id uuid primary key default gen_random_uuid(),
  owner_uid text not null,
  name text not null,
  storage_path text not null unique,
  size_bytes bigint not null default 0,
  content_type text not null default 'application/octet-stream',
  created_at timestamptz not null default now()
);

-- Complementa tabela preexistente; não remove nem recria dados.
alter table public.files add column if not exists owner_uid text;
alter table public.files add column if not exists name text;
alter table public.files add column if not exists storage_path text;
alter table public.files add column if not exists size_bytes bigint not null default 0;
alter table public.files add column if not exists content_type text not null default 'application/octet-stream';
alter table public.files add column if not exists created_at timestamptz not null default now();

create index if not exists files_owner_uid_created_idx on public.files(owner_uid, created_at desc);

-- O app usa Firebase Authentication, não Supabase Auth. Portanto, clientes
-- anon não recebem acesso direto à tabela. A Edge Function usa service_role
-- após validar o Firebase ID token no servidor.
alter table public.files enable row level security;
drop policy if exists "DragonFiles deny anon direct access" on public.files;
create policy "DragonFiles deny anon direct access" on public.files
  for all to anon using (false) with check (false);

grant select, insert, update, delete on public.files to service_role;

insert into storage.buckets (id, name, public)
values ('dragonfiles', 'dragonfiles', false)
on conflict (id) do update set public = false;

-- Não criar políticas para anon: somente a Edge Function com service_role
-- poderá acessar o bucket privado.
