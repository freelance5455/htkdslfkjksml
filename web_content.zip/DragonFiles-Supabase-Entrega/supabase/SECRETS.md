# Secrets necessários para a Edge Function

Configure no projeto Supabase (não no APK):

- `SUPABASE_URL`: https://nyouhhnzuqqfczlbvkpm.supabase.co
- `SUPABASE_SERVICE_ROLE_KEY`: chave service_role do projeto (secreta).
- `FIREBASE_PROJECT_ID`: dragonfiles-c1625

A chave service_role jamais deve ser enviada no chat, incluída no ZIP público ou embutida no aplicativo.

- `FIREBASE_SERVICE_ACCOUNT_JSON`: JSON completo da service account do Firebase Admin SDK, armazenado como secret. Nunca colocar no cliente.
