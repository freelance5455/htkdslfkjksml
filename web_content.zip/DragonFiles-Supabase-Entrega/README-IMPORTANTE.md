# DragonFiles - pacote de integração Supabase

Este pacote é uma entrega de código-fonte/integração, NÃO um APK compilado.

## O que foi preparado
- Mantém Firebase Authentication para login/cadastro e UID existente.
- Transfere operações de arquivos para uma Edge Function Supabase.
- Edge Function valida o Firebase ID token no servidor antes de operar.
- Storage privado `dragonfiles`; metadados em `public.files`.
- Migração SQL idempotente para completar a tabela sem apagar registros.
- Cópia do `app.js` Firebase original preservada como `app.firebase-original.js`.

## Antes de usar
1. Confira `supabase/schema.sql` no SQL Editor do projeto Supabase.
2. Configure secrets da Edge Function conforme `supabase/SECRETS.md`.
3. Publique a função `dragonfiles-api`.
4. Substitua `assets/web/app.js` no projeto Android/Web original.
5. Recompile e assine pelo projeto Android original.

## Limitações honestas
Não foi possível gerar um APK instalável nesta execução: os arquivos fornecidos são APKs compilados e conteúdo extraído, sem `settings.gradle`, `build.gradle`, fontes Kotlin/Java ou keystore. O pacote não altera os APKs existentes. Também não foi possível testar uma chamada real ao Supabase sem acesso autenticado ao projeto e seus secrets.

A chave `service_role` nunca deve ser colocada no app. Ela fica somente nos secrets da Edge Function.
