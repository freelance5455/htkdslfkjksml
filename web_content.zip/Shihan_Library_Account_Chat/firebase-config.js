// Firebase Console > Project settings > Your apps > Web app থেকে মানগুলো বসাও।
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_APP_ID"
};
// প্রথম অ্যাকাউন্ট তৈরি হওয়ার পর Firebase Authentication থেকে UID নিয়ে এখানে বসাবে।
// একই UID firestore.rules ও storage.rules-এর ADMIN_UID_HERE জায়গাতেও বসাতে হবে।
export const SUPER_ADMIN_UID = "PASTE_FIRST_ADMIN_UID_HERE";
