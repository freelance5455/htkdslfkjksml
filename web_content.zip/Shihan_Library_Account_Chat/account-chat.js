import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, sendEmailVerification, RecaptchaVerifier, signInWithPhoneNumber
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  getFirestore, doc, setDoc, getDoc, collection, addDoc, query, where,
  onSnapshot, orderBy, serverTimestamp, getDocs, updateDoc
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js';
import { firebaseConfig, SUPER_ADMIN_UID } from './firebase-config.js';

const configured = firebaseConfig.apiKey && !firebaseConfig.apiKey.includes('PASTE_') && firebaseConfig.projectId && !firebaseConfig.projectId.includes('PASTE_');
let auth, db, storage, currentUser=null, confirmation=null, verifier=null, stopChats=null, stopMessages=null, activeChat=null;
const $ = id => document.getElementById(id);
const safe = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const notify = t => { if(window.toast) window.toast(t); else alert(t); };
function showGate(message='') {
  $('accountGate').classList.remove('hidden');
  $('gateMessage').textContent = message;
  $('gateSetup').classList.toggle('hidden', configured);
  $('gateForms').classList.toggle('hidden', !configured);
}
function hideGate(){ $('accountGate').classList.add('hidden'); }
function updateCollegeHeader(collegeName=''){ const el=$('collegeHeaderName'); if(el) el.textContent=collegeName?.trim()||'কলেজের নাম'; }
function normalizePhone(v){ let n=v.replace(/[\s()-]/g,''); if(n.startsWith('01')&&n.length===11)n='+88'+n; if(n.startsWith('8801'))n='+'+n; return n; }
function profileName(){return $('authName').value.trim();}
function registrationDetails(){
 const role=$('accountRole')?.value||'student', birthday=$('birthday')?.value||'';
 if(!profileName())throw Error('তোমার নাম লিখুন।');
 if(!birthday)throw Error('জন্মতারিখ নির্বাচন করুন।');
 if(role==='teacher'){const subject=$('teacherSubject').value.trim();if(!subject)throw Error('তোমার বিষয় লিখুন।');return {role:'teacher',birthday,subject,studentId:'',collegeName:'',eduLevel:'',hscYear:'',hscGroup:'',department:'',session:''};}
 const level=$('eduLevel').value, studentId=$('studentId').value.trim(), collegeName=$('collegeName').value.trim();
 if(!studentId)throw Error('Student ID অথবা Class Roll লিখুন।');
 if(!collegeName)throw Error('College-এর নাম লিখুন।');
 if(!['hsc','honours'].includes(level))throw Error('HSC অথবা Honours নির্বাচন করুন।');
 if(level==='hsc'){const year=$('hscYear').value,group=$('hscGroup').value;if(!year)throw Error('HSC বর্ষ নির্বাচন করুন।');if(!group)throw Error('HSC গ্রুপ নির্বাচন করুন।');return {role:'student',birthday,studentId,collegeName,eduLevel:level,hscYear:year,hscGroup:group,department:'',session:''};}
 const department=$('honoursDepartment').value.trim(),session=$('eduSession').value.trim();
 if(!department)throw Error('Honours Department লিখুন।');if(!session)throw Error('Honours Session লিখুন।');
 return {role:'student',birthday,studentId,collegeName,eduLevel:level,hscYear:'',hscGroup:'',department,session};
}
window.updateEducationFields=()=>{const level=$('eduLevel').value;$('hscFields').classList.toggle('hidden',level!=='hsc');$('honoursFields').classList.toggle('hidden',level!=='honours');};
window.updateRoleFields=()=>{const teacher=$('accountRole').value==='teacher';$('teacherFields').classList.toggle('hidden',!teacher);$('studentFields').classList.toggle('hidden',teacher);};
let pendingRegistration={};
function profileBadge(p){const initials=(p.displayName||'U').trim().slice(0,1);return p.photoURL?`<img class="user-avatar" src="${safe(p.photoURL)}" alt="">`:`<span class="user-avatar avatar-fallback">${safe(initials)}</span>`;}
async function saveNewProfile(user,name,details){
 const photo=$('profilePhoto')?.files?.[0];
 if(photo){if(photo.size>5*1024*1024)throw Error('প্রোফাইল ছবি ৫ MB-এর মধ্যে রাখুন।');const path=`profilePics/${user.uid}/avatar_${Date.now()}`;const r=ref(storage,path);await uploadBytes(r,photo);details.photoURL=await getDownloadURL(r);}
 return ensureProfile(user,name,details);
}
function studentTag(p){const v=p.role==='teacher'?(p.subject||'Teacher'):(p.studentId||p.classRoll||'');return v?`<small class="student-tag">${safe(v)}</small>`:'';}
function educationLine(p){if(p.eduLevel==='hsc')return `HSC · ${p.hscYear||''} · ${p.hscGroup||''}`;if(p.eduLevel==='honours')return `Honours · ${p.department||''} · ${p.session||''}`;return 'Digital Library সদস্য';}

async function ensureProfile(user, name='', extra={}) {
  const uref=doc(db,'users',user.uid), pref=doc(db,'publicProfiles',user.uid);
  const old=await getDoc(uref);
  const displayName=name || old.data()?.displayName || user.displayName || user.email?.split('@')[0] || user.phoneNumber || 'ব্যবহারকারী';
  const username=(old.data()?.username || displayName.toLowerCase().replace(/[^a-z0-9\u0980-\u09ff]+/g,'').slice(0,24) || ('user'+user.uid.slice(0,6)));
  const data={uid:user.uid,displayName,username,role:extra.role||old.data()?.role||'student',birthday:extra.birthday||old.data()?.birthday||'',subject:extra.subject||old.data()?.subject||'',email:user.email||old.data()?.email||'',phoneNumber:user.phoneNumber||old.data()?.phoneNumber||'',studentId:extra.studentId||old.data()?.studentId||'',collegeName:extra.collegeName||old.data()?.collegeName||'',eduLevel:extra.eduLevel||old.data()?.eduLevel||'',eduClass:'',hscYear:extra.hscYear||old.data()?.hscYear||'',hscGroup:extra.hscGroup||old.data()?.hscGroup||'',department:extra.department||old.data()?.department||'',session:extra.session||old.data()?.session||'',photoURL:old.data()?.photoURL||'',disabled:old.data()?.disabled===true,createdAt:old.data()?.createdAt||serverTimestamp(),updatedAt:serverTimestamp()};
  await setDoc(uref,data,{merge:true});
  await setDoc(pref,{uid:user.uid,displayName,username,role:data.role,subject:data.subject,birthday:data.birthday,studentId:data.studentId,collegeName:data.collegeName,eduLevel:data.eduLevel,hscYear:data.hscYear,hscGroup:data.hscGroup,department:data.department,session:data.session,photoURL:data.photoURL,updatedAt:serverTimestamp()},{merge:true});
  return data;
}
function setAuthMode(mode){ $('authMode').value=mode; $('authNameWrap').classList.toggle('hidden',mode!=='signup'); $('authSubmit').textContent=mode==='signup'?'অ্যাকাউন্ট তৈরি করুন':'লগইন করুন'; $('authSwitch').textContent=mode==='signup'?'আগে অ্যাকাউন্ট আছে? লগইন':'নতুন অ্যাকাউন্ট খুলুন'; }
window.switchAuthMode=()=>setAuthMode($('authMode').value==='signup'?'login':'signup');
window.chooseAuthMethod=method=>{ $('authMethod').value=method; $('emailFields').classList.toggle('hidden',method!=='email'); $('phoneFields').classList.toggle('hidden',method!=='phone'); $('emailTab').classList.toggle('active',method==='email'); $('phoneTab').classList.toggle('active',method==='phone'); };
window.submitAuth=async()=>{
  if(!configured)return;
  const mode=$('authMode').value, method=$('authMethod').value;
  try{
    $('authSubmit').disabled=true; $('authSubmit').textContent='অপেক্ষা করুন…';
    if(method==='email'){
      const email=$('authEmail').value.trim(), pass=$('authPassword').value;
      if(!email||pass.length<6)throw Error('সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।');
      let cred;
      if(mode==='signup'){
        pendingRegistration=registrationDetails();
        cred=await createUserWithEmailAndPassword(auth,email,pass);
        await saveNewProfile(cred.user,profileName(),pendingRegistration);
        try{await sendEmailVerification(cred.user);}catch{}
        notify('অ্যাকাউন্ট তৈরি হয়েছে। ইমেইল যাচাই করে নাও।');
      } else { cred=await signInWithEmailAndPassword(auth,email,pass); }
    } else {
      const phone=normalizePhone($('authPhone').value);
      if(!/^\+\d{10,15}$/.test(phone))throw Error('দেশের কোডসহ সঠিক নম্বর দিন। বাংলাদেশে উদাহরণ: +8801XXXXXXXXX');
      if(mode==='signup')pendingRegistration=registrationDetails();
      if(!verifier)verifier=new RecaptchaVerifier(auth,'recaptcha-container',{size:'invisible'});
      confirmation=await signInWithPhoneNumber(auth,phone,verifier);
      window.pendingPhoneName=mode==='signup'?profileName():'';
      $('otpWrap').classList.remove('hidden'); $('authSubmit').classList.add('hidden');
      notify('SMS-এ পাঠানো OTP লিখুন।');
    }
  }catch(e){notify(e.message||'অ্যাকাউন্টে সমস্যা হয়েছে।'); if(verifier){try{verifier.clear()}catch{} verifier=null;}}
  finally{$('authSubmit').disabled=false;if(!$('otpWrap').classList.contains('hidden'))return;$('authSubmit').textContent=$('authMode').value==='signup'?'অ্যাকাউন্ট তৈরি করুন':'লগইন করুন';}
};
window.verifyOtp=async()=>{try{const result=await confirmation.confirm($('authOtp').value.trim());await saveNewProfile(result.user,window.pendingPhoneName||'',pendingRegistration);$('otpWrap').classList.add('hidden');$('authSubmit').classList.remove('hidden');notify('মোবাইল নম্বর যাচাই হয়েছে।');}catch(e){notify('OTP সঠিক নয় বা মেয়াদ শেষ হয়েছে। আবার চেষ্টা করো।');}};
window.resendOtp=()=>{if(verifier){try{verifier.clear()}catch{} verifier=null;}window.submitAuth();};
window.logoutApp=async()=>{await signOut(auth);};
function openChatModal(html){window.modal(html);}
window.openChatHub=async()=>{
  if(!currentUser)return showGate('চ্যাট ব্যবহার করতে আগে অ্যাকাউন্টে লগইন করো।');
  const mySnap=await getDoc(doc(db,'users',currentUser.uid)),myData=mySnap.data()||{};const canNotice=currentUser.uid===SUPER_ADMIN_UID||myData.noticePublisher===true;
  openChatModal(`<div class="hub-hero"><div><div class="hub-kicker">SHIHAN CONNECT</div><h2 class="chat-title">তোমার সহপাঠীরা এখানে</h2><p class="chat-subtitle">নাম, Student ID বা Class Roll দিয়ে খুঁজে নাও</p></div><div class="hub-orb">✦</div></div><div class="directory-search"><span>⌕</span><input id="directorySearch" placeholder="ব্যবহারকারীর নাম বা ID খুঁজুন…" oninput="filterDirectory()"></div><div class="chat-tabs"><button class="primary" onclick="loadUserDirectory()">সব ব্যবহারকারী</button><button class="secondary" onclick="showMyChats()">আমার চ্যাট</button>${currentUser.uid===SUPER_ADMIN_UID?'<button class="secondary" onclick="openAdminPanel()">Super Admin</button>':''}${canNotice?'<button class="secondary" onclick="openNoticePublisher()">নোটিশ প্রকাশ</button>':''}</div><div id="chatArea"><p class="small">ব্যবহারকারী লোড হচ্ছে…</p></div><div class="actions"><button class="secondary" onclick="logoutApp()">লগআউট</button><button class="secondary" onclick="closeModal()">বন্ধ</button></div>`);
  loadUserDirectory();
};
let directoryProfiles=[];
window.loadUserDirectory=async()=>{
 const area=$('chatArea');if(!area)return;area.innerHTML='<p class="small">ব্যবহারকারী লোড হচ্ছে…</p>';
 try{const snap=await getDocs(collection(db,'publicProfiles'));directoryProfiles=snap.docs.map(d=>d.data()).filter(p=>p.uid!==currentUser.uid);renderDirectory(directoryProfiles);}
 catch(e){area.textContent='ব্যবহারকারী লোড হয়নি: '+e.message;}
};
function renderDirectory(rows){const area=$('chatArea');if(!area)return;area.innerHTML=rows.length?`<div class="directory-caption">${rows.length} জন ব্যবহারকারী</div>`+rows.map(p=>`<button class="chat-user directory-user" onclick="startConversation('${p.uid}','${safe(p.displayName)}')">${profileBadge(p)}<span class="user-meta"><b>${safe(p.displayName||'ব্যবহারকারী')} ${studentTag(p)}</b><small>${safe(educationLine(p)||'Digital Library সদস্য')}</small></span><span class="user-arrow">›</span></button>`).join(''):'<p class="small">এখনো অন্য কোনো ব্যবহারকারী নিবন্ধন করেনি।</p>';}
window.filterDirectory=()=>{const term=($('directorySearch')?.value||'').toLowerCase().trim();renderDirectory(directoryProfiles.filter(p=>[p.displayName,p.studentId,p.classRoll,p.username,p.hscYear,p.hscGroup,p.department,p.session].join(' ').toLowerCase().includes(term)));};
window.showMyChats=()=>{
  const area=$('chatArea'); if(!area)return;
  if(stopChats)stopChats();
  const q=query(collection(db,'chats'),where('participants','array-contains',currentUser.uid));
  stopChats=onSnapshot(q,async snap=>{
    const rows=[];
    for(const d of snap.docs){const c=d.data(), other=(c.participants||[]).find(x=>x!==currentUser.uid);let p={displayName:'ব্যবহারকারী'};if(other){const ps=await getDoc(doc(db,'publicProfiles',other));if(ps.exists())p=ps.data();}rows.push({id:d.id,other,...p,last:c.lastMessage||'',updatedAt:c.updatedAt});}
    rows.sort((a,b)=>(b.updatedAt?.seconds||0)-(a.updatedAt?.seconds||0));
    if(!$('chatArea'))return;
    $('chatArea').innerHTML=`<div class="chat-title" style="font-size:17px;margin:12px 2px">আপনার কথোপকথন</div>`+(rows.length?rows.map(x=>`<button class="chat-user directory-user" onclick="openConversation('${x.id}','${safe(x.displayName)}')">${profileBadge(x)}<span class="user-meta"><b>${safe(x.displayName)} ${studentTag(x)}</b><small>${safe(x.last||'কথোপকথন শুরু করুন')}</small></span><span class="user-arrow">›</span></button>`).join(''):'<p class="small">এখনো কোনো চ্যাট নেই। “নতুন চ্যাট” চাপুন।</p>');
  },e=>{if($('chatArea'))$('chatArea').textContent='চ্যাট লোড হয়নি: '+e.message;});
};
window.findChatUsers=async()=>{
  const area=$('chatArea');if(!area)return;
  area.innerHTML=`<h3>ব্যবহারকারী খুঁজুন</h3><input id="userSearch" placeholder="নাম বা username লিখুন"><button class="primary" onclick="runUserSearch()">খুঁজুন</button><div id="userResults"></div>`;
  $('userSearch').focus();
};
window.runUserSearch=async()=>{
  const term=$('userSearch').value.trim();if(term.length<2)return notify('কমপক্ষে ২টি অক্ষর লিখুন।');
  const out=$('userResults');out.textContent='খোঁজা হচ্ছে…';
  try{
    const profiles=await getDocs(collection(db,'publicProfiles'));
    const found=profiles.docs.map(d=>d.data()).filter(p=>p.uid!==currentUser.uid&&((p.displayName||'').toLowerCase().includes(term.toLowerCase())||(p.username||'').toLowerCase().includes(term.toLowerCase()))).slice(0,30);
    out.innerHTML=found.length?found.map(p=>`<button class="chat-user directory-user" onclick="startConversation('${p.uid}','${safe(p.displayName)}')">${profileBadge(p)}<span class="user-meta"><b>${safe(p.displayName)} ${studentTag(p)}</b><small>${safe(educationLine(p)||'সদস্য')}</small></span></button>`).join(''):'<p class="small">কোনো ব্যবহারকারী পাওয়া যায়নি।';
  }catch(e){out.textContent='খোঁজা যায়নি: '+e.message;}
};
async function chatIdFor(uid){return [currentUser.uid,uid].sort().join('_');}
window.startConversation=async(uid,name)=>{const id=await chatIdFor(uid);await setDoc(doc(db,'chats',id),{participants:[currentUser.uid,uid].sort(),updatedAt:serverTimestamp(),lastMessage:''},{merge:true});window.openConversation(id,name);};
let voiceRecorder=null, voiceChunks=[], voiceBlob=null, voicePreviewUrl=null;
window.openConversation=(chatId,name)=>{
  activeChat=chatId;if(stopMessages)stopMessages();
  $('chatArea').innerHTML=`<div class="conversation-head"><button class="secondary" onclick="showMyChats()">←</button><div style="min-width:0"><b>${safe(name)}</b><div style="font-size:11px;opacity:.85">● ব্যক্তিগত কথোপকথন</div></div></div><div id="messageList" class="message-list"></div><div id="voicePreview" class="voice-preview hidden"></div><div class="send-row"><label class="filepick" title="ফাইল পাঠান">＋<input id="chatFile" type="file" hidden onchange="sendChatFile(this)"></label><input id="messageText" placeholder="একটি মেসেজ লিখুন…" onkeydown="if(event.key==='Enter')sendChatMessage()"><button class="send-btn" onclick="sendChatMessage()" title="পাঠান">➤</button><button id="voiceBtn" class="voice-btn" onclick="toggleVoiceRecording()" title="ভয়েস মেসেজ">🎙</button></div><p class="small" style="text-align:center">＋ ফাইল • 🎙 ভয়েস মেসেজ • নিরাপদ ব্যক্তিগত চ্যাট</p>`;
  const q=query(collection(db,'chats',chatId,'messages'),orderBy('createdAt','asc'));
  stopMessages=onSnapshot(q,snap=>{const list=$('messageList');if(!list)return;list.innerHTML=snap.docs.map(d=>{const m=d.data(),mine=m.senderId===currentUser.uid;let body=safe(m.text||'');if(m.audioUrl)body=`<div style="min-width:190px"><div style="font-weight:750;font-size:12px;margin-bottom:5px">🎙 ভয়েস মেসেজ</div><audio controls preload="none" src="${safe(m.audioUrl)}"></audio></div>`;if(m.fileUrl)body+=`<p><a href="${safe(m.fileUrl)}" target="_blank" rel="noopener">📎 ${safe(m.fileName||'ফাইল খুলুন')}</a></p>`;return `<div class="message ${mine?'mine':''}"><div>${body}</div><small>${mine?'তুমি':'অন্যজন'}${m.createdAt?.toDate?' · '+m.createdAt.toDate().toLocaleTimeString('bn-BD',{hour:'2-digit',minute:'2-digit'}):''}</small></div>`}).join('');list.scrollTop=list.scrollHeight;},e=>{if($('messageList'))$('messageList').textContent='মেসেজ লোড হয়নি: '+e.message;});
};
window.toggleVoiceRecording=async()=>{
 const btn=$('voiceBtn');if(!btn)return;
 if(voiceRecorder&&voiceRecorder.state==='recording'){voiceRecorder.stop();btn.classList.remove('recording');btn.textContent='🎙';return;}
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)return notify('এই WebView-তে ভয়েস রেকর্ডিং সমর্থিত নয়। Chrome বা আপডেটেড APK ব্যবহার করুন।');
 try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});voiceChunks=[];voiceRecorder=new MediaRecorder(stream);voiceRecorder.ondataavailable=e=>{if(e.data.size)voiceChunks.push(e.data)};voiceRecorder.onstop=()=>{stream.getTracks().forEach(t=>t.stop());voiceBlob=new Blob(voiceChunks,{type:voiceRecorder.mimeType||'audio/webm'});if(voicePreviewUrl)URL.revokeObjectURL(voicePreviewUrl);voicePreviewUrl=URL.createObjectURL(voiceBlob);const box=$('voicePreview');box.classList.remove('hidden');box.innerHTML=`<audio controls src="${voicePreviewUrl}"></audio><button onclick="sendVoiceMessage()">পাঠান</button><button style="background:#fce8eb;color:#a33" onclick="discardVoiceMessage()">মুছুন</button>`;};voiceRecorder.start();btn.classList.add('recording');btn.textContent='■';notify('রেকর্ড হচ্ছে… শেষ হলে আবার মাইক্রোফোন চাপুন।');}catch(e){notify('মাইক্রোফোন অনুমতি পাওয়া যায়নি: '+e.message);}
};
window.discardVoiceMessage=()=>{voiceBlob=null;const box=$('voicePreview');if(box){box.classList.add('hidden');box.innerHTML='';}if(voicePreviewUrl){URL.revokeObjectURL(voicePreviewUrl);voicePreviewUrl=null;}};
window.sendVoiceMessage=async()=>{if(!voiceBlob||!activeChat)return;try{const ext=voiceBlob.type.includes('mp4')?'m4a':'webm';const path=`chatFiles/${activeChat}/${Date.now()}_voice.${ext}`;const fileRef=ref(storage,path);await uploadBytes(fileRef,voiceBlob,{contentType:voiceBlob.type||'audio/webm'});const url=await getDownloadURL(fileRef);await addDoc(collection(db,'chats',activeChat,'messages'),{senderId:currentUser.uid,text:'',audioUrl:url,audioPath:path,messageType:'voice',createdAt:serverTimestamp()});await updateDoc(doc(db,'chats',activeChat),{lastMessage:'🎙 ভয়েস মেসেজ',updatedAt:serverTimestamp()});discardVoiceMessage();notify('ভয়েস মেসেজ পাঠানো হয়েছে।');}catch(e){notify('ভয়েস মেসেজ পাঠানো যায়নি: '+e.message);}};
window.sendChatMessage=async()=>{const input=$('messageText'),text=input.value.trim();if(!text||!activeChat)return;input.value='';await addDoc(collection(db,'chats',activeChat,'messages'),{senderId:currentUser.uid,text,createdAt:serverTimestamp()});await updateDoc(doc(db,'chats',activeChat),{lastMessage:text,updatedAt:serverTimestamp()});};
window.sendChatFile=async input=>{const f=input.files?.[0];if(!f||!activeChat)return;if(f.size>20*1024*1024){notify('২০ MB-এর বেশি ফাইল পাঠানো যাবে না।');input.value='';return;}try{const safeName=f.name.replace(/[^\w.\-\u0980-\u09ff]/g,'_');const path=`chatFiles/${activeChat}/${Date.now()}_${safeName}`;const fileRef=ref(storage,path);await uploadBytes(fileRef,f);const url=await getDownloadURL(fileRef);await addDoc(collection(db,'chats',activeChat,'messages'),{senderId:currentUser.uid,text:'',fileName:f.name,fileUrl:url,filePath:path,createdAt:serverTimestamp()});await updateDoc(doc(db,'chats',activeChat),{lastMessage:'📎 '+f.name,updatedAt:serverTimestamp()});notify('ফাইল পাঠানো হয়েছে।');}catch(e){notify('ফাইল পাঠানো যায়নি: '+e.message);}finally{input.value='';}};
function slug(v){return encodeURIComponent(String(v||'').trim().toLowerCase()).replace(/%/g,'_').replace(/[^a-z0-9_\u0980-\u09ff-]/g,'_').slice(0,90);}
function syllabusKey(level,year,group,department,college,session=''){
 const c=slug(college);if(level==='hsc')return `hsc_${c}_${year}_${group}`;
 return `honours_${c}_${slug(department)}_${slug(session)}`;
}
window.openAssignedSyllabus=async()=>{
 if(!currentUser)return showGate('সিলেবাস দেখতে আগে অ্যাকাউন্টে লগইন করো।');
 const p=await getDoc(doc(db,'users',currentUser.uid));if(!p.exists())return notify('প্রোফাইল পাওয়া যায়নি।');
 const u=p.data();let key='';
 if(!u.collegeName)return notify('প্রোফাইলে College-এর নাম নেই। Admin-এর সঙ্গে যোগাযোগ করো।');
 if(u.eduLevel==='hsc'&&u.hscYear&&u.hscGroup)key=syllabusKey('hsc',u.hscYear,u.hscGroup,'',u.collegeName);
 else if(u.eduLevel==='honours'&&u.department)key=syllabusKey('honours','','',u.department,u.collegeName,u.session||'');
 else return notify('তোমার শিক্ষাগত তথ্য অসম্পূর্ণ। নতুন অ্যাকাউন্টে সঠিক তথ্য দিয়ে নিবন্ধন করো।');
 try{const snap=await getDoc(doc(db,'syllabi',key));if(!snap.exists())return notify('তোমার বর্ষ/গ্রুপ/Department-এর সিলেবাস Admin এখনো আপলোড করেনি।');const data=snap.data();const response=await fetch(data.downloadURL);if(!response.ok)throw Error('PDF ডাউনলোড হয়নি');const blob=await response.blob();if(window.openPdfBlob)await window.openPdfBlob(blob,data.title||'সিলেবাস');else window.open(data.downloadURL,'_blank');}
 catch(e){notify('সিলেবাস খোলা যায়নি: '+e.message);}
};
window.openSyllabusAdmin=async()=>{
 if(currentUser?.uid!==SUPER_ADMIN_UID)return notify('শুধু Super Admin সিলেবাস পরিবর্তন করতে পারবে।');
 $('chatArea').innerHTML=`<h3>সিলেবাস পরিচালনা</h3><p class="small">College + বর্ষ/গ্রুপ বা Department অনুযায়ী PDF আপলোড করো। একই বিভাগের নতুন PDF দিলে আগেরটি বদলে যাবে।</p><label>College-এর নাম</label><input id="syllCollege" placeholder="শিক্ষার্থীর প্রোফাইলের সঙ্গে হুবহু মিলতে হবে"><label>শিক্ষার স্তর</label><select id="syllLevel" onchange="updateSyllabusAdminFields()"><option value="hsc">HSC</option><option value="honours">Honours</option></select><div id="syllHsc"><label>বর্ষ</label><select id="syllYear"><option value="1st">১ম বর্ষ</option><option value="2nd">২য় বর্ষ</option></select><label>গ্রুপ</label><select id="syllGroup"><option value="science">Science</option><option value="commerce">Commerce</option><option value="arts">Arts (মানবিক)</option></select></div><div id="syllHonours" class="hidden"><label>Department</label><input id="syllDepartment" placeholder="যেমন: বাংলা, ইংরেজি, হিসাববিজ্ঞান"><label>Session</label><input id="syllSession" placeholder="যেমন: ২০২৪–২০২৫"></div><label>PDF ফাইল</label><input id="syllPdf" type="file" accept="application/pdf,.pdf"><button class="primary" onclick="uploadManagedSyllabus()">PDF আপলোড / পরিবর্তন</button><button class="secondary" onclick="openAdminPanel()">ব্যবহারকারী নিয়ন্ত্রণে ফিরুন</button><div id="syllabusList" class="small">লোড হচ্ছে…</div>`;
 updateSyllabusAdminFields();try{const snap=await getDocs(collection(db,'syllabi'));$('syllabusList').innerHTML='<h4>আপলোড করা সিলেবাস</h4>'+ (snap.empty?'এখনো কোনো PDF আপলোড হয়নি।':snap.docs.map(d=>`<div class="bookrow"><span>${safe(d.data().title||d.id)}</span><a href="${safe(d.data().downloadURL||'#')}" target="_blank">দেখুন</a></div>`).join(''));}catch(e){$('syllabusList').textContent='তালিকা লোড হয়নি: '+e.message;}
};
window.updateSyllabusAdminFields=()=>{const h=$('syllLevel')?.value==='hsc';$('syllHsc')?.classList.toggle('hidden',!h);$('syllHonours')?.classList.toggle('hidden',h);};
window.uploadManagedSyllabus=async()=>{
 if(currentUser?.uid!==SUPER_ADMIN_UID)return notify('শুধু Super Admin আপলোড করতে পারবে।');
 const level=$('syllLevel').value,file=$('syllPdf').files?.[0];if(!file)return notify('একটি PDF ফাইল নির্বাচন করো।');if(file.type!=='application/pdf'&&!file.name.toLowerCase().endsWith('.pdf'))return notify('শুধু PDF ফাইল আপলোড করা যাবে।');if(file.size>25*1024*1024)return notify('PDF সর্বোচ্চ ২৫ MB হতে পারবে।');
 let year='',group='',department='',session='';const college=$('syllCollege').value.trim();if(!college)return notify('College-এর নাম লিখো।');if(level==='hsc'){year=$('syllYear').value;group=$('syllGroup').value;}else{department=$('syllDepartment').value.trim();session=$('syllSession').value.trim();if(!department)return notify('Department-এর নাম লিখো।');if(!session)return notify('Session লিখো।');}
 const key=syllabusKey(level,year,group,department,college,session),path=`syllabi/${key}.pdf`;
 try{const fileRef=ref(storage,path);await uploadBytes(fileRef,file,{contentType:'application/pdf'});const downloadURL=await getDownloadURL(fileRef);const title=level==='hsc'?`${college} · HSC ${year==='1st'?'১ম':'২য়'} বর্ষ · ${group==='science'?'Science':group==='commerce'?'Commerce':'Arts'}`:`${college} · Honours · ${department} · ${session}`;await setDoc(doc(db,'syllabi',key),{key,level,year,group,department,session,collegeName:college,title,filePath:path,downloadURL,updatedAt:serverTimestamp(),updatedBy:currentUser.uid},{merge:true});notify('সিলেবাস আপলোড/পরিবর্তন হয়েছে।');window.openSyllabusAdmin();}catch(e){notify('আপলোড ব্যর্থ: '+e.message);}
};
window.openNoticeBoard=async()=>{
 if(!currentUser)return showGate('নোটিশ দেখতে আগে লগইন করো।');
 const me=await getDoc(doc(db,'users',currentUser.uid));if(!me.exists())return notify('প্রোফাইল পাওয়া যায়নি।');
 const u=me.data(),college=u.collegeName||'';if(!college)return notify('প্রোফাইলে College-এর নাম নেই।');
 $('noticeBoardTitle')?.remove();
 openChatModal(`<h2>📢 নোটিশ বোর্ড</h2><p class="small">${safe(college)}-এর নোটিশ</p><div id="noticeItems">নোটিশ লোড হচ্ছে…</div><div class="actions"><button class="secondary" onclick="closeModal()">বন্ধ</button></div>`);
 try{const snap=await getDocs(query(collection(db,'notices'),where('collegeKey','==',slug(college))));const rows=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));$('noticeItems').innerHTML=rows.length?rows.map(n=>`<article class="panel"><h3>${safe(n.title||'নোটিশ')}</h3><p>${safe(n.body||'').replace(/\n/g,'<br>')}</p>${n.fileURL?`<a href="${safe(n.fileURL)}" target="_blank">📎 সংযুক্তি খুলুন</a>`:''}<p class="small">${safe(n.createdByName||'Admin')}</p></article>`).join(''):'এখনো কোনো নোটিশ প্রকাশ করা হয়নি।';}catch(e){$('noticeItems').textContent='নোটিশ লোড হয়নি: '+e.message;}
};
window.publishNotice=async()=>{
 const title=$('noticeTitle').value.trim(),body=$('noticeBody').value.trim(),file=$('noticeFile').files?.[0];if(!title||!body)return notify('নোটিশের শিরোনাম ও বিবরণ লিখো।');
 try{const me=await getDoc(doc(db,'users',currentUser.uid)),u=me.data()||{};if(currentUser.uid!==SUPER_ADMIN_UID&&u.noticePublisher!==true)throw Error('নোটিশ প্রকাশের অনুমতি নেই।');if(!u.collegeName)throw Error('College-এর নাম পাওয়া যায়নি।');let fileURL='';if(file){if(file.size>15*1024*1024)return notify('সংযুক্তি সর্বোচ্চ ১৫ MB হতে পারবে।');const path=`notices/${slug(u.collegeName)}/${Date.now()}_${file.name.replace(/[^\w.\-]/g,'_')}`;const rr=ref(storage,path);await uploadBytes(rr,file);fileURL=await getDownloadURL(rr);}await addDoc(collection(db,'notices'),{title,body,fileURL,collegeName:u.collegeName,collegeKey:slug(u.collegeName),createdBy:currentUser.uid,createdByName:u.displayName||'ব্যবহারকারী',createdAt:serverTimestamp()});notify('নোটিশ প্রকাশ হয়েছে।');openNoticeBoard();}catch(e){notify('নোটিশ প্রকাশ করা যায়নি: '+e.message);}
};
window.openNoticePublisher=async()=>{
 const me=await getDoc(doc(db,'users',currentUser.uid)),u=me.data()||{};if(currentUser.uid!==SUPER_ADMIN_UID&&u.noticePublisher!==true)return notify('তোমাকে নোটিশ প্রকাশের দায়িত্ব দেওয়া হয়নি।');if(!u.collegeName)return notify('তোমার College-এর নাম প্রোফাইলে নেই।');
 $('chatArea').innerHTML=`<h3>📢 নোটিশ প্রকাশ</h3><p class="small">শুধু তোমার কলেজের নোটিশ প্রকাশ হবে: ${safe(u.collegeName||'')}</p><label>নোটিশের শিরোনাম</label><input id="noticeTitle" placeholder="যেমন: পরীক্ষার সময়সূচি"><label>বিস্তারিত</label><textarea id="noticeBody" rows="5" style="width:100%;padding:12px;border:1px solid #b7d8e0;border-radius:12px"></textarea><label>PDF / ছবি সংযুক্তি (ঐচ্ছিক)</label><input id="noticeFile" type="file" accept=".pdf,image/*"><button class="primary" onclick="publishNotice()">নোটিশ প্রকাশ করো</button><button class="secondary" onclick="openAdminPanel()">ফিরে যাও</button>`;
};
window.openAnnouncementAdmin=()=>{if(currentUser?.uid!==SUPER_ADMIN_UID)return; $('chatArea').innerHTML=`<h3>📣 সবার জন্য ঘোষণা</h3><label>বার্তা</label><textarea id="announcementText" rows="4" style="width:100%"></textarea><button class="primary" onclick="publishAnnouncement()">সবার কাছে প্রকাশ</button><button class="secondary" onclick="openAdminPanel()">ফিরে যাও</button>`;};
window.publishAnnouncement=async()=>{if(currentUser?.uid!==SUPER_ADMIN_UID)return;const body=$('announcementText').value.trim();if(!body)return notify('বার্তা লিখুন।');try{await addDoc(collection(db,'announcements'),{body,createdBy:currentUser.uid,createdAt:serverTimestamp(),active:true});notify('ঘোষণা প্রকাশ হয়েছে।');openAdminPanel();}catch(e){notify('প্রকাশ করা যায়নি: '+e.message);}};
window.openAppUpdateAdmin=()=>{if(currentUser?.uid!==SUPER_ADMIN_UID)return;$('chatArea').innerHTML=`<h3>🚀 App Update</h3><label>Version</label><input id="updateVersion" placeholder="যেমন 1.1.0"><label>বিবরণ</label><textarea id="updateNotes" rows="3"></textarea><label>APK Download HTTPS URL</label><input id="updateUrl" type="url" placeholder="https://..."><button class="primary" onclick="publishAppUpdate()">Update প্রকাশ</button><button class="secondary" onclick="openAdminPanel()">ফিরে যাও</button><p class="small">APK ফাইল আগে HTTPS hosting-এ আপলোড করতে হবে।</p>`;};
window.publishAppUpdate=async()=>{if(currentUser?.uid!==SUPER_ADMIN_UID)return;const version=$('updateVersion').value.trim(),notes=$('updateNotes').value.trim(),url=$('updateUrl').value.trim();if(!version||!/^https:\/\//i.test(url))return notify('Version ও HTTPS APK link দিন।');try{await setDoc(doc(db,'appUpdates','latest'),{version,notes,url,createdBy:currentUser.uid,updatedAt:serverTimestamp()});notify('App Update প্রকাশ হয়েছে।');openAdminPanel();}catch(e){notify('Update প্রকাশ করা যায়নি: '+e.message);}};
async function loadHomeAdminContent(){const a=$('homeAnnouncements'),u=$('homeAppUpdate');if(!a||!u||!currentUser)return;try{const snap=await getDocs(query(collection(db,'announcements'),where('active','==',true)));const rows=snap.docs.map(d=>d.data()).sort((x,y)=>(y.createdAt?.seconds||0)-(x.createdAt?.seconds||0)).slice(0,5);a.innerHTML=rows.length?rows.map(x=>`<article class="panel">${safe(x.body)}<p class="small">${x.createdAt?.toDate?x.createdAt.toDate().toLocaleString('bn-BD'):''}</p></article>`).join(''):'এখনো কোনো ঘোষণা নেই।';const up=await getDoc(doc(db,'appUpdates','latest'));if(up.exists()){const x=up.data();u.innerHTML=`<b>My College v${safe(x.version)}</b><p>${safe(x.notes||'')}</p><a href="${safe(x.url)}" target="_blank" rel="noopener">APK Download</a>`;}else u.textContent='নতুন আপডেট নেই।';}catch(e){a.textContent='ঘোষণা লোড হয়নি।';u.textContent='আপডেট লোড হয়নি।';}}
window.toggleNoticePublisher=async uid=>{if(currentUser?.uid!==SUPER_ADMIN_UID)return;const r=doc(db,'users',uid),s=await getDoc(r);if(!s.exists())return;const next=s.data().noticePublisher!==true;await updateDoc(r,{noticePublisher:next});notify(next?'নোটিশ প্রকাশের দায়িত্ব দেওয়া হয়েছে।':'নোটিশ প্রকাশের দায়িত্ব বাতিল হয়েছে।');openAdminPanel();};
window.openAdminPanel=async()=>{
  if(currentUser?.uid!==SUPER_ADMIN_UID)return notify('শুধু Super Admin এই অংশ ব্যবহার করতে পারবে।');
  const s=await getDocs(collection(db,'publicProfiles'));
  const rows=await Promise.all(s.docs.map(async d=>{const p=d.data(),u=await getDoc(doc(db,'users',p.uid));return {...p,noticePublisher:u.exists()&&u.data().noticePublisher===true};}));
  $('chatArea').innerHTML=`<h3>Super Admin — ব্যবহারকারী নিয়ন্ত্রণ</h3><button class=\"primary\" onclick=\"openSyllabusAdmin()\">📚 সিলেবাস পরিচালনা</button><button class=\"secondary\" onclick=\"openNoticePublisher()\">📢 নিজের College-এর নোটিশ প্রকাশ</button><button class=\"secondary\" onclick=\"openAnnouncementAdmin()\">📣 সবার জন্য ঘোষণা</button><button class=\"secondary\" onclick=\"openAppUpdateAdmin()\">🚀 App Update প্রকাশ</button><p class=\"small\">যে ব্যবহারকারীকে দায়িত্ব দেবে, সে নিজের College-এর নোটিশ প্রকাশ করতে পারবে।</p>`+rows.map(p=>`<div class=\"chat-user\"><b>${safe(p.displayName)}</b><small>${safe(p.collegeName||'College নেই')} · @${safe(p.username||'')}</small><button class=\"secondary\" onclick=\"toggleNoticePublisher('${p.uid}')\">${p.noticePublisher?'নোটিশ দায়িত্ব বাতিল':'নোটিশ প্রকাশের দায়িত্ব দাও'}</button><button class=\"secondary\" onclick=\"toggleUserBlock('${p.uid}')\">অ্যাকাউন্ট নিয়ন্ত্রণ</button></div>`).join('');
};
window.toggleUserBlock=async uid=>{if(currentUser?.uid!==SUPER_ADMIN_UID)return;const r=doc(db,'users',uid),s=await getDoc(r);if(!s.exists())return;const next=s.data().disabled!==true;await updateDoc(r,{disabled:next});notify(next?'অ্যাকাউন্ট নিষ্ক্রিয় করা হয়েছে।':'অ্যাকাউন্ট আবার চালু করা হয়েছে।');};

if(configured){
  const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);storage=getStorage(app);
  onAuthStateChanged(auth,async user=>{
    currentUser=user;
    if(!user){updateCollegeHeader('');showGate();return;}
    try{let profile=await ensureProfile(user);if(profile.disabled){await signOut(auth);showGate('এই অ্যাকাউন্টটি প্রশাসক দ্বারা নিষ্ক্রিয় করা হয়েছে।');return;}if(!profile.collegeName){const college=window.prompt('তোমার College-এর পূর্ণ নাম লিখে প্রোফাইল আপডেট করো:');if(college&&college.trim()){await updateDoc(doc(db,'users',user.uid),{collegeName:college.trim()});await setDoc(doc(db,'publicProfiles',user.uid),{collegeName:college.trim()},{merge:true});profile.collegeName=college.trim();}}updateCollegeHeader(profile.collegeName);hideGate();loadHomeAdminContent();}
    catch(e){showGate('প্রোফাইল লোড করা যায়নি: '+e.message);}
  });
} else {showGate('অ্যাকাউন্ট ও Chat চালু করতে Firebase সেটআপ প্রয়োজন।');}
