Abdur Rahman Shihan Digital Library — Account & Chat starter
===========================================================

এই সংস্করণে যোগ করা হয়েছে:
- ইমেইল/পাসওয়ার্ড দিয়ে অ্যাকাউন্ট তৈরি ও লগইন
- মোবাইল নম্বর + SMS OTP দিয়ে অ্যাকাউন্ট/লগইন
- ব্যবহারকারী খোঁজা এবং ১-টু-১ ব্যক্তিগত চ্যাট
- ইন্টারনেট দিয়ে ছবি/PDF/ডকুমেন্ট পাঠানো (সর্বোচ্চ ২০ MB)
- Super Admin-এর মাধ্যমে অ্যাকাউন্ট নিষ্ক্রিয়/সক্রিয় করার প্রাথমিক নিয়ন্ত্রণ
- আগের লাইব্রেরি, বিষয়, PDF reader এবং syllabus.pdf রাখা হয়েছে

গুরুত্বপূর্ণ:
এই ZIP-এ অ্যাপের কোড তৈরি আছে, কিন্তু এটি এখনো লাইভ Chat সার্ভিস নয়।
Firebase Project ও তোমার Firebase Web App config না বসালে Signup/Chat কাজ করবে না।
কোনো Service Account private key এই অ্যাপে বসাবে না।

Firebase সেটআপ (একবার করতে হবে)
--------------------------------
1) https://console.firebase.google.com/ খুলে Google account দিয়ে sign in করো।
2) Add project চাপো; নাম দাও: shihan-digital-library (অথবা নিজের পছন্দের নাম)।
3) Project তৈরি হলে Project Overview > Web (</>) চাপো। App nickname দাও: Shihan Library। Register app করো।
4) Firebase যে firebaseConfig দেখাবে, এই ফোল্ডারের firebase-config.js ফাইলে apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId-এর জায়গায় বসাও।
5) Authentication > Get started > Sign-in method-এ Email/Password এবং Phone চালু করো।
6) Phone OTP-এর জন্য Authentication Settings-এ প্রয়োজনীয় SMS অঞ্চল/নীতিমালা ঠিক করো। Testing-এর সময় Firebase test phone number ব্যবহার করতে পারো।
7) Firestore Database তৈরি করো। Rules অংশে firestore.rules-এর সম্পূর্ণ লেখা paste করে Publish করো।
8) Storage চালু করো। Rules অংশে storage.rules-এর সম্পূর্ণ লেখা paste করে Publish করো।
9) Firebase Hosting চালু করে এই ফোল্ডারের ফাইলগুলো Hosting-এ deploy করো। Firebase Auth-এর Authorized domains-এ Hosting domain যোগ আছে কি না দেখো। ES module/CDN ব্যবহার হওয়ায় HTTPS Hosting-এ চালানো সবচেয়ে নির্ভরযোগ্য; সরাসরি file:// দিয়ে চালালে কিছু Android WebView-তে module/CORS সমস্যা হতে পারে।

Super Admin সেটআপ
-----------------
1) Firebase সংযোগ বসিয়ে Hosting-এ অ্যাপ চালাও।
2) নিজের ইমেইল বা ফোন দিয়ে প্রথম অ্যাকাউন্ট তৈরি করো।
3) Firebase Console > Authentication > Users থেকে নিজের User UID কপি করো।
4) firebase-config.js-এ SUPER_ADMIN_UID-এর জায়গায় ওই UID বসাও।
5) firestore.rules ও storage.rules-এ ADMIN_UID_HERE-এর জায়গায় একই UID বসিয়ে Rules Publish করো।
6) Hosting আবার deploy করো। এরপর Chat-এ Super Admin বোতাম দেখা যাবে।

ফাইল/নিরাপত্তা সীমা
------------------
- Chat file upload সর্বোচ্চ ২০ MB।
- কেবল chat-এর দুই অংশগ্রহণকারী ঐ chat-এর ফাইল/মেসেজ দেখতে পারবে—Rules দিয়ে সীমাবদ্ধ।
- প্রথম সংস্করণে ১-টু-১ chat আছে; group chat, voice/video call নেই।
- Super Admin-এর disable ফ্ল্যাগ অ্যাপের Firestore access বন্ধ করে; সম্পূর্ণ Firebase Auth account deletion/disable করার জন্য পরবর্তীতে নিরাপদ Cloud Function/Admin SDK লাগবে।
- Firebase-এর free quota অতিক্রম করলে খরচ হতে পারে। SMS OTP-তে Firebase-এর billing/দেশভিত্তিক সীমা প্রযোজ্য হতে পারে।

APK নোট
-------
প্রথমে Firebase Hosting-এ ওয়েব অ্যাপ চালু করে পরীক্ষা করো। এরপর Android Studio-তে HTTPS Hosting URL লোড করা WebView APK বানাও। WebView-তে JavaScript, DOM storage, file chooser এবং internet permission চালু থাকতে হবে।

নতুন Chat ডিজাইন ও Voice Message
--------------------------------
- Chat page-এ Shihan Connect আধুনিক UI, conversation list, message bubble এবং ফাইল পাঠানোর সুবিধা রয়েছে।
- ভয়েস মেসেজের জন্য Chat screen-এ 🎙 বাটন চাপুন; রেকর্ডিং বন্ধ করতে আবার চাপুন। এরপর Preview শুনে পাঠান অথবা মুছে দিন।
- Voice upload চালাতে Firebase Storage Rules-এ audio/* MIME type অনুমতি থাকতে হবে। এই ZIP-এর storage.rules-এ সেটি যোগ করা আছে। Firebase Console > Storage > Rules-এ ফাইলের নিয়ম প্রকাশ করুন।
- Android WebView/APK Builder-এ মাইক্রোফোন ব্যবহার করতে AndroidManifest-এ RECORD_AUDIO permission এবং WebChromeClient-এর onPermissionRequest অনুমতি লাগতে পারে। Builder-এ Microphone/Audio recording permission চালু করুন।
- ভয়েস রেকর্ডিং Chrome/সমর্থিত WebView-এ MediaRecorder API ব্যবহার করে। HTTPS secure context ও ব্যবহারকারীর microphone permission প্রয়োজন।
- এই ZIP হলো সোর্স প্রজেক্ট; Firebase config না বসানো এবং Firebase Rules প্রকাশ না করা পর্যন্ত অনলাইন Chat/Upload লাইভ হবে না।


নতুন Student Profile ও Chat Directory
--------------------------------------
- Signup-এ নাম, Student ID/Class Roll, ঐচ্ছিক প্রোফাইল ছবি, Email অথবা Phone OTP দিতে হবে।
- Education Level: School, HSC অথবা Honours। School হলে Class; HSC/Honours হলে Session দিতে হবে।
- Chat খুললে প্রথমে ব্যবহারকারীদের নাম ও প্রোফাইল ছবি/অক্ষর-অবতারসহ তালিকা আসবে। কাউকে নির্বাচন করলে তার ব্যক্তিগত Chat খুলবে।
- Firebase Storage Rules-এ profilePics ও chatFiles-এর নতুন নিয়ম প্রকাশ করতে হবে।
- আগের Firebase configuration ও Admin UID সেটআপ ধাপগুলো এখনও প্রয়োজন।


নতুন শিক্ষার্থী নিবন্ধন ও সিলেবাস ব্যবস্থা (আপডেট):
- School অপশন বাদ। শুধু HSC অথবা Honours নির্বাচন করা যাবে।
- HSC: ১ম/২য় বর্ষ এবং Science/Commerce/Arts গ্রুপ দিতে হবে।
- Honours: Department-এর নাম ও Session দিতে হবে।
- Super Admin > সিলেবাস পরিচালনা থেকে HSC বর্ষ+গ্রুপ অথবা Honours Department অনুযায়ী PDF আপলোড/পরিবর্তন করা যাবে।
- শিক্ষার্থী সিলেবাস বাটনে চাপলে তার নিজের HSC বর্ষ/গ্রুপ বা Honours Department-এর PDF খুলবে।
- Firebase Firestore Rules ও Storage Rules নতুন সংস্করণ দিয়ে Deploy করতে হবে। Firebase Storage চালু থাকা আবশ্যক।
- Admin শনাক্তকরণের জন্য firebase-config.js-এর SUPER_ADMIN_UID এবং দুই Rules ফাইলের ADMIN_UID_HERE-এ একই Admin UID বসাতে হবে।
- একই HSC বর্ষ/গ্রুপ বা Honours Department-এর PDF আবার আপলোড করলে সেটি প্রতিস্থাপিত হবে।


নতুন আপডেট: College ভিত্তিক Syllabus ও Notice
1. নতুন অ্যাকাউন্টে College-এর পূর্ণ নাম বাধ্যতামূলক। শিক্ষার্থীদের College-এর নাম একই বানানে লিখতে বলবে।
2. HSC সিলেবাসের key: College + HSC বর্ষ + Group। Honours সিলেবাসের key: College + Department + Session। Super Admin একই key-তে নতুন PDF আপলোড করলে আগের PDF প্রতিস্থাপিত হবে।
3. Home-এ Syllabus ও AI Tutor-এর ঠিক নিচে Notice বোতাম আছে। শিক্ষার্থী শুধু নিজের College-এর Notice দেখবে।
4. Super Admin → ব্যবহারকারী তালিকা → “নোটিশ প্রকাশের দায়িত্ব দাও” দিয়ে নির্দিষ্ট ব্যবহারকারীকে তার College-এর Notice প্রকাশের অনুমতি দিতে পারবে। আবার “নোটিশ দায়িত্ব বাতিল” দিয়ে অনুমতি বন্ধ করা যাবে। Super Admin নিজেও Notice প্রকাশ করতে পারবে।
5. Firebase Console-এ Firestore Rules এবং Storage Rules—দুটিই এই ZIP-এর নতুন rules ফাইল দিয়ে Publish করতে হবে। Rules-এর ADMIN_UID_HERE জায়গায় Super Admin-এর Firebase Auth UID বসাতে হবে। Firebase Storage চালু থাকতে হবে।
6. আগে তৈরি করা অ্যাকাউন্টে College Name নেই; তাদের প্রোফাইল ডেটায় College Name যোগ না করলে College ভিত্তিক Syllabus ও Notice কাজ করবে না।
