MY COLLEGE — প্রস্তুতকৃত ওয়েব অ্যাপ সোর্স
======================================

Firebase Web App Config এবং Super Admin UID বসানো হয়েছে।
Project ID: my-college-98ee2
Super Admin UID: HJf60F7a78RFgsBwWJw81gLUXx83

Signup:
- Name, Email, Birthday, Account Type
- Teacher হলে Subject
- Student হলে Student ID/Roll, College, HSC/Honours তথ্য
- Profile directory-তে Teacher-এর Subject এবং Student-এর ID দেখানো হয়

Home:
- Subject-category grid সরানো হয়েছে; সব PDF বই এক জায়গায় যোগ/দেখার entry রাখা হয়েছে
- Newspaper link, সাধারণ জ্ঞান resource link, Government job/BPSC link
- Admin Announcement এবং App Update section

Firebase সেটআপ:
1. Firebase Console > Firestore Database > Rules-এ এই ZIP-এর firestore.rules সম্পূর্ণ paste করে Publish করুন।
2. Authentication > Sign-in method-এ Email/Password Enabled রাখুন। Phone OTP ব্যবহার করবেন না; এটি Free plan-এর জন্য উপযুক্ত নয়।
3. Authentication > Settings > Authorized domains-এ আপনার HTTPS hosting domain যোগ করুন।
4. Firebase Hosting বা অন্য HTTPS static hosting-এ এই ফোল্ডারের সব ফাইল upload/deploy করুন। HTML file-কে সরাসরি file:// থেকে চালাবেন না।
5. Super Admin account-টি Authentication-এ আগে থেকেই থাকতে হবে এবং UID উপরের UID-এর সঙ্গে মিলতে হবে।

Free-plan সীমাবদ্ধতা:
- এই Firebase project-এর Cloud Storage ব্যবহার করা হয়নি; নতুন Firebase Storage bucket-এর জন্য Blaze লাগতে পারে।
- তাই profile photo upload, chat attachment/audio, remote syllabus PDF upload এবং notice attachment বর্তমানে চালু/পরীক্ষিত নয়।
- Books-এর PDF স্থানীয় ডিভাইসের IndexedDB-তে থাকে; অন্য ব্যবহারকারীর ফোনে স্বয়ংক্রিয়ভাবে sync হয় না।
- Newspaper/Job links বহিঃসাইট খুলে। General Knowledge আপাতত একটি reference link; built-in প্রশ্নোত্তর ডেটাবেস এখনো যোগ হয়নি।
- Admin announcement ও update publishing Firestore rules publish এবং hosting-এ deploy করার পরই কাজ করবে। APK download URL-টি HTTPS হতে হবে।
- App update link থেকে APK download হবে; Android-এর version/signature একই না হলে update-এর বদলে আলাদা app হিসেবে install হতে পারে।

APK:
প্রথমে HTTPS hosting URL browser-এ পরীক্ষা করুন। এরপর HTML to APK Builder-এর ZIP import ব্যবহার করুন। JavaScript, DOM storage, file chooser, internet এবং প্রয়োজন হলে microphone permission চালু করুন।

এটি source build; বাস্তব Firebase account-এ end-to-end signup/chat/admin/update পরীক্ষা করা হয়নি। প্রকাশের আগে দুইটি test account (Student ও Teacher) দিয়ে পরীক্ষা আবশ্যক।

ভাষা (Language): অ্যাপ প্রথমবার English ভাষায় খুলবে। উপরের বাংলা/English বাটনে চাপ দিয়ে English ও বাংলা বদলানো যাবে। পছন্দটি একই ডিভাইসের Local Storage-এ সেভ থাকে। অ্যাপের কিছু Firebase থেকে আসা বা ব্যবহারকারীর লেখা কনটেন্ট অনুবাদ হয় না।
