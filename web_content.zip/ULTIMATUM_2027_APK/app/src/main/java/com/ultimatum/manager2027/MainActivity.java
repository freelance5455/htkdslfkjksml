package com.ultimatum.manager2027;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 protected void onCreate(Bundle b){ super.onCreate(b); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/ULTIMATUM_2027.html"); setContentView(w); }
}
