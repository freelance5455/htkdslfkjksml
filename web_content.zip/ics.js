// Minimaler iCalendar-Export/Import (RFC 5545) für Termine - ohne externe Bibliothek,
// deckt die gängigen Felder ab, die auch Google/Apple/Outlook-Kalender exportieren,
// inklusive Erinnerungen (VALARM), damit beim Export/Re-Import keine Daten verloren gehen.

const pad = (value) => String(value).padStart(2, '0');

function icsDateTime(dateKey, timeValue) {
  const [y, m, d] = dateKey.split('-');
  if (!timeValue) return `${y}${m}${d}`;
  const [hh, mm] = timeValue.split(':');
  return `${y}${m}${d}T${hh}${mm}00`;
}

function addMinutesToTime(dateKey, timeValue, minutes) {
  const [y, m, d] = dateKey.split('-').map(Number);
  const [hh, mm] = timeValue.split(':').map(Number);
  const date = new Date(y, m - 1, d, hh, mm + minutes);
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}T${pad(date.getHours())}${pad(date.getMinutes())}00`;
}

const escapeText = (value) => String(value || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');

function foldLine(line) {
  if (line.length <= 74) return line;
  let result = '';
  let rest = line;
  while (rest.length > 74) { result += `${rest.slice(0, 74)}\r\n `; rest = rest.slice(74); }
  return result + rest;
}

export function appointmentsToICS(appointments) {
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Tagklar//Termine//DE', 'CALSCALE:GREGORIAN'];
  (appointments || []).forEach((appointment) => {
    if (!appointment.date) return;
    lines.push('BEGIN:VEVENT');
    lines.push(foldLine(`UID:${appointment.id}@tagklar`));
    lines.push(foldLine(`SUMMARY:${escapeText(appointment.title)}`));
    if (appointment.time) {
      lines.push(`DTSTART:${icsDateTime(appointment.date, appointment.time)}`);
      const duration = Number(appointment.duration) || 0;
      if (appointment.endTime) lines.push(`DTEND:${icsDateTime(appointment.date, appointment.endTime)}`);
      else if (duration > 0) lines.push(`DTEND:${addMinutesToTime(appointment.date, appointment.time, duration)}`);
    } else {
      lines.push(`DTSTART;VALUE=DATE:${appointment.date.replace(/-/g, '')}`);
    }
    if (appointment.location) lines.push(foldLine(`LOCATION:${escapeText(appointment.location)}`));
    if (appointment.notes) lines.push(foldLine(`DESCRIPTION:${escapeText(appointment.notes)}`));
    // Erinnerungen als VALARM mitschreiben, damit sie beim Re-Import erhalten bleiben
    // und Kalender-Apps (Google/Apple/Outlook) sie ebenfalls anzeigen können.
    const reminders = appointment.reminders && typeof appointment.reminders === 'object' ? appointment.reminders : { mode: 'default', minutes: [] };
    if (reminders.mode === 'off') {
      lines.push('X-TAGKLAR-REMINDERS-OFF:TRUE');
    } else if (reminders.mode === 'custom' && reminders.minutes.length && appointment.time) {
      reminders.minutes.forEach((minutes) => {
        lines.push('BEGIN:VALARM');
        lines.push('ACTION:DISPLAY');
        lines.push(foldLine(`DESCRIPTION:${escapeText(appointment.title)}`));
        lines.push(`TRIGGER:-PT${Math.max(0, Math.round(minutes))}M`);
        lines.push('END:VALARM');
      });
    }
    lines.push('END:VEVENT');
  });
  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

export function downloadICS(appointments) {
  const blob = new Blob([appointmentsToICS(appointments)], { type: 'text/calendar;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `tagklar-termine-${new Date().toISOString().slice(0, 10)}.ics`;
  link.click();
  URL.revokeObjectURL(link.href);
}

const unfoldLines = (text) => text.replace(/\r\n/g, '\n').replace(/\n[ \t]/g, '').split('\n');
const unescapeText = (value) => String(value || '').replace(/\\n/gi, '\n').replace(/\\,/g, ',').replace(/\\;/g, ';').replace(/\\\\/g, '\\');

function parseICSDate(value) {
  const match = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?Z?)?$/.exec(value || '');
  if (!match) return null;
  const [, y, m, d, hh, mm] = match;
  return { date: `${y}-${m}-${d}`, time: hh !== undefined ? `${hh}:${mm}` : '' };
}

// Wandelt einen VALARM-TRIGGER-Wert (z. B. "-PT15M", "-PT2H", "-P1D") in Minuten um.
function triggerToMinutes(value) {
  const match = /^-P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?)?$/.exec(String(value || '').trim().toUpperCase());
  if (!match) return null;
  const days = Number(match[1] || 0);
  const hours = Number(match[2] || 0);
  const minutes = Number(match[3] || 0);
  const total = days * 1440 + hours * 60 + minutes;
  return total >= 0 && (match[1] || match[2] || match[3]) ? total : null;
}

// Liefert ein Array bereits auf Tagklar-Feldnamen gemappter Termine (title/date/time/...),
// inklusive erkannter Erinnerungen (reminders) und - falls der Termin ursprünglich aus
// Tagklar stammt - der ursprünglichen id (sourceId), damit ein Re-Import aktualisiert statt dupliziert.
export function parseICS(text) {
  const lines = unfoldLines(text);
  const events = [];
  let current = null;
  let inAlarm = false;
  let alarmMinutes = null;
  lines.forEach((rawLine) => {
    const line = rawLine.trim();
    if (line === 'BEGIN:VEVENT') { current = { alarms: [] }; return; }
    if (line === 'END:VEVENT') { if (current) events.push(current); current = null; return; }
    if (!current) return;
    if (line === 'BEGIN:VALARM') { inAlarm = true; alarmMinutes = null; return; }
    if (line === 'END:VALARM') { if (inAlarm && alarmMinutes !== null) current.alarms.push(alarmMinutes); inAlarm = false; return; }
    const separatorIndex = line.indexOf(':');
    if (separatorIndex === -1) return;
    const key = line.slice(0, separatorIndex).split(';')[0].toUpperCase();
    const value = line.slice(separatorIndex + 1);
    if (inAlarm) { if (key === 'TRIGGER') alarmMinutes = triggerToMinutes(value); return; }
    if (key === 'SUMMARY') current.title = unescapeText(value);
    else if (key === 'LOCATION') current.location = unescapeText(value);
    else if (key === 'DESCRIPTION') current.notes = unescapeText(value);
    else if (key === 'DTSTART') current.start = parseICSDate(value);
    else if (key === 'DTEND') current.end = parseICSDate(value);
    else if (key === 'UID') current.uid = value;
    else if (key === 'X-TAGKLAR-REMINDERS-OFF') current.remindersOff = value.toUpperCase() === 'TRUE';
  });
  return events.filter((event) => event.start?.date).map((event) => {
    const startMinutes = event.start.time ? Number(event.start.time.split(':')[0]) * 60 + Number(event.start.time.split(':')[1]) : null;
    const endMinutes = event.end?.time ? Number(event.end.time.split(':')[0]) * 60 + Number(event.end.time.split(':')[1]) : null;
    const duration = startMinutes !== null && endMinutes !== null && endMinutes > startMinutes ? endMinutes - startMinutes : (event.start.time ? 60 : 0);
    const uidMatch = /^(.+)@tagklar$/.exec(event.uid || '');
    const reminders = event.remindersOff ? { mode: 'off', minutes: [] } : (event.alarms.length ? { mode: 'custom', minutes: event.alarms.slice(0, 3) } : { mode: 'default', minutes: [] });
    return {
      title: event.title || '',
      date: event.start.date,
      time: event.start.time || '',
      duration: String(duration),
      endTime: event.start.time && event.end?.time ? event.end.time : '',
      location: event.location || '',
      notes: event.notes || '',
      reminders,
      sourceId: uidMatch ? uidMatch[1] : null,
    };
  }).filter((appointment) => appointment.title && appointment.date);
}
