'use strict';
/* =========================================================================
   VELO — app.js  (v1.6 — real Firebase backend)
   Loaded as <script type="module"> so Firebase's ES-module SDK can be
   imported directly here. Keep EVERYTHING in this one module script —
   splitting Firebase init across multiple type="module" blocks breaks
   variable scope (learned the hard way on the other KS projects).

   REAL (backed by Firebase, synced between users):
   - Auth: email/password sign up, log in, log out, session persistence
   - User profiles + Velo ID / username lookup ("Add contact by Velo ID")
   - 1:1 chats and group chats, participants, messages, unread counts
   - Read receipts (sent → read) and a live typing indicator

   STILL LOCAL / MOCK — flagged inline with "FIREBASE:" where relevant:
   - Photo & voice-note message CONTENT (the message itself sends, but the
     image/audio payload stays on your device until Storage is wired up)
   - Reactions, star, pin, mute, archive — per-device only for now
   - Channels, Calls and Status tabs — UI-only, not synced
   - The desktop QR/OTP device-link handshake — needs its own signalling
   ========================================================================= */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import {
  getAuth, signOut, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, reauthenticateWithPopup, deleteUser,
} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";
import {
  getFirestore, doc, setDoc, getDoc, deleteDoc, updateDoc, deleteField, runTransaction,
  collection, addDoc, query, where, limit, orderBy, onSnapshot, getDocs,
  serverTimestamp, increment, writeBatch, limitToLast, Timestamp, arrayUnion, arrayRemove,
} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDkZREvbKNN9fK0XiTG43N1nILPzYNTd60",
  authDomain: "ksstudai-ksdev.firebaseapp.com",
  projectId: "ksstudai-ksdev",
  storageBucket: "ksstudai-ksdev.firebasestorage.app",
  messagingSenderId: "34014837965",
  appId: "1:34014837965:web:caca5212913b03b5ea7d84",
  measurementId: "G-N15SCHBFDC",
};
const fbApp = initializeApp(firebaseConfig);
const auth = getAuth(fbApp);
const db = getFirestore(fbApp);
const googleProvider = new GoogleAuthProvider();
// Always show Google's own account chooser — never silently continue with
// whatever Google session happens to be cached in the browser, so "Edit"
// (and every fresh sign-in) genuinely lets the person pick a new email.
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Separate provider, only used for the Google Drive backup feature —
// keeps the ordinary sign-in popup from ever asking for Drive access.
// drive.file scope = the app can only see/manage files IT created, never
// the rest of the person's Drive.
const driveProvider = new GoogleAuthProvider();
driveProvider.addScope('https://www.googleapis.com/auth/drive.file');
driveProvider.setCustomParameters({ prompt: 'select_account' });
let driveAccessToken = null;
let driveTokenExpiresAt = 0;
// Firestore layout used below (create these two collections, no manual
// index needed — single-field equality queries are indexed automatically):
//   veloUsers/{uid}      → { name, email, phone, username, veloId, createdAt }
//   chats/{chatId}        → { participants:[uid,...], isGroup, name,
//                              lastMessage:{text,ts,from}, unreadBy:{uid:n} }
//   chats/{chatId}/messages/{id} → { from, text, ts, status, replyTo?, forwarded? }
//   chats/{chatId}/typing/{uid}  → { typing:bool, ts }
// Remember to set Firestore security rules restricting reads/writes to
// signed-in participants before this goes live.

// ---------------------------------------------------------------------
// tiny DOM helpers
// ---------------------------------------------------------------------
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const byId = (id) => document.getElementById(id);

function escapeHTML(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
// *bold*  -italic-  /highlight/ — always escaped FIRST so typed HTML stays inert.
// The opening mark must start a word and the closing mark must end one, so URLs
// (https://x.com/a/), dates (12/03/2026), "well-known" and "- bullet" are left alone.
function formatMessageHTML(text) {
  let s = escapeHTML(text || '');
  const wrap = (mark, tag) => {
    const m = mark.replace(/[.*+?^${}()|[\]\\\/-]/g, '\\$&');
    const re = new RegExp(`(^|[\\s(])${m}(\\S(?:[^${m}\\n]*?\\S)?)${m}(?=$|[\\s).,!?:;])`, 'g');
    s = s.replace(re, `$1<${tag}>$2</${tag}>`);
  };
  wrap('*', 'b');
  wrap('-', 'i');
  wrap('/', 'mark');
  return s;
}
function safeMediaSrc(u, kind) {
  const s = String(u || '');
  const ok = kind === 'video' ? /^data:video\//i : /^data:image\//i;
  return ok.test(s) ? escapeHTML(s) : '';
}
function initials(name) {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || name[0].toUpperCase();
}
const AV_CLASSES = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];
function avatarClass(id) {
  id = String(id || '');
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return AV_CLASSES[h % AV_CLASSES.length];
}
function photoById(id) {
  if (!state || !state.me) return '';
  if (id === 'me' || id === state.me.uid) return state.me.photo || '';
  if (contacts[id]) return contacts[id].photo || '';
  const ch = chats[id];
  if (ch && !ch.isGroup) { const o = otherParticipant(ch); return (o && o.photo) || ''; }
  return '';
}
function avatarHTML(id, name, size = 'av-sm') {
  if (chats[id] && chats[id].isNote) return `<div class="avatar ${size} c4"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9Z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg></div>`;
  const src = safeMediaSrc(photoById(id), 'image');
  if (src) return `<div class="avatar ${size} ${avatarClass(id)} has-photo"><img src="${src}" alt=""></div>`;
  return `<div class="avatar ${size} ${avatarClass(id)}">${escapeHTML(initials(name))}</div>`;
}
function setAvatar(el, id, name, size = 'av-sm') {
  if (!el) return;
  if (chats[id] && chats[id].isNote) { el.className = `avatar ${size} c4`; el.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9Z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg>'; return; }
  const src = safeMediaSrc(photoById(id), 'image');
  el.className = `avatar ${size} ${avatarClass(id)}${src ? ' has-photo' : ''}`;
  if (src) el.innerHTML = `<img src="${src}" alt="">`; else el.textContent = initials(name);
}
function tsMillis(ts) {
  return (ts && typeof ts.toMillis === 'function') ? ts.toMillis() : Date.now();
}
function timeLabel(ts) {
  const d = new Date(ts), now = new Date();
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  const yest = new Date(now); yest.setDate(now.getDate() - 1);
  if (d.toDateString() === yest.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}
function bubbleTime(ts) {
  return new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}
let msgSeq = 1;
function nextId() { return 'm' + (msgSeq++); }
function previewText(m) {
  if (!m) return '';
  if (m.kind === 'image') return '📷 Photo' + (m.text ? ': ' + m.text : '');
  if (m.kind === 'voice') return '🎤 Voice message';
  if (m.kind === 'poll') return '📊 ' + (m.question || 'Poll');
  return m.text || '';
}
function setBtnLoading(btn, loading) {
  if (!btn) return;
  btn.classList.toggle('loading', loading);
  btn.disabled = loading;
}
function friendlyAuthError(err) {
  const map = {
    'auth/too-many-requests': 'Too many attempts — please wait a moment and try again.',
    'auth/network-request-failed': 'Network error — check your connection.',
    'auth/popup-blocked': 'Your browser blocked the Google sign-in popup — allow popups and try again.',
    'auth/account-exists-with-different-credential': 'That email is already registered with a different sign-in method.',
    'auth/unauthorized-domain': "This website's domain isn't authorised in Firebase → Authentication → Settings.",
  };
  return map[err?.code] || err?.message || 'Something went wrong. Please try again.';
}

// ---------------------------------------------------------------------
// toast
// ---------------------------------------------------------------------
function toast(msg) {
  const wrap = byId('toastWrap');
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  wrap.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 250);
  }, 2600);
}

// ---------------------------------------------------------------------
// generic confirm modal (replaces window.confirm — unreliable in WebViews)
// ---------------------------------------------------------------------
let pendingConfirm = null;
function confirmAction(title, text, onConfirm, okLabel = 'Delete') {
  byId('confirmTitle').textContent = title;
  byId('confirmText').textContent = text;
  byId('confirmOkBtn').textContent = okLabel;
  pendingConfirm = onConfirm;
  showModal('confirmModal');
}
byId('confirmCancelBtn').addEventListener('click', () => { pendingConfirm = null; hideModal('confirmModal'); });
byId('confirmOkBtn').addEventListener('click', () => {
  const fn = pendingConfirm; pendingConfirm = null;
  hideModal('confirmModal');
  if (fn) fn();
});

// ---------------------------------------------------------------------
// long-press / tap helper (used for chat rows and message bubbles)
// ---------------------------------------------------------------------
function bindLongPress(el, onLongPress, onTap) {
  let timer = null, moved = false, sx = 0, sy = 0;
  el.addEventListener('pointerdown', (e) => {
    moved = false; sx = e.clientX; sy = e.clientY;
    timer = setTimeout(() => { timer = null; if (navigator.vibrate) navigator.vibrate(12); onLongPress(); }, 420);
  });
  el.addEventListener('pointermove', (e) => {
    if (Math.abs(e.clientX - sx) > 10 || Math.abs(e.clientY - sy) > 10) {
      moved = true;
      if (timer) { clearTimeout(timer); timer = null; }
    }
  });
  el.addEventListener('pointerup', () => {
    if (timer) { clearTimeout(timer); timer = null; if (!moved && onTap) onTap(); }
  });
  el.addEventListener('pointerleave', () => { if (timer) { clearTimeout(timer); timer = null; } });
}

// ---------------------------------------------------------------------
// local caches, populated entirely from Firestore — no seed/demo data
// ---------------------------------------------------------------------
const contacts = {};   // { [uid]: {id, name, username, phone, veloId} }
const chats = {};      // { [chatId]: {id, participants, isGroup, name, messages, unreadBy, lastMessage, pinned, muted, archived} }
const channels = {};   // local-only for now — see file header
let callLog = [];      // local-only for now — see file header

function chatIdFor(uidA, uidB) { return [uidA, uidB].sort().join('_'); }
function otherParticipant(chat) {
  if (!chat || chat.isGroup) return null;
  const uid = (chat.participants || []).find(p => p !== state.me?.uid);
  return uid ? contacts[uid] : null;
}
function chatDisplayName(chat) {
  if (!chat) return '';
  if (chat.isGroup) return chat.name || 'Group';
  const other = otherParticipant(chat);
  if (!other) return 'Unknown user';
  return contactNicknames[other.id] || other.name || 'Unknown user';
}

// ---------------------------------------------------------------------
// app state
// ---------------------------------------------------------------------
const state = {
  me: null,
  pendingGoogleUser: null, // { uid, email, name, photoURL } — set once Google returns an account, cleared once a Velo session actually starts
  currentChatId: null,
  currentProfileId: null,
  currentChannelId: null,
  profileReturnScreen: 'screen-main',
  replyTarget: null,
  longPressChatId: null,
  longPressMsg: null,
  forwardMessage: null,
  recording: false,
  callSeconds: 0,
  callInterval: null,
  callTimerHandle: null,
  unseenInThread: 0,
  peerTyping: {},
  renderedIds: {},
  editing: null,
};
let unsubChats = null, unsubMessages = null, unsubTyping = null;
const contactUnsubs = {};
function watchContact(uid) {
  if (!uid || contactUnsubs[uid]) return;
  contactUnsubs[uid] = onSnapshot(doc(db, 'veloUsers', uid), (snap) => {
    if (!snap.exists()) return;
    const prev = contacts[uid] || {}, next = Object.assign({ id: uid }, snap.data());
    contacts[uid] = next;
    const visual = prev.photo !== next.photo || prev.name !== next.name || prev.bio !== next.bio;
    if (visual) renderChatList(byId('chatSearch').value);
    const cur = chats[state.currentChatId];
    if (cur && !cur.isGroup && (cur.participants || []).includes(uid)) refreshChatHeader(cur.id);
    const prof = chats[state.currentProfileId];
    if (prof && !prof.isGroup && (prof.participants || []).includes(uid) && byId('screen-profile').classList.contains('active')) {
      if (visual) openProfile(prof.id, state.profileReturnScreen); else paintProfileStatus(prof);
    }
  }, () => {});
}
function detachAllListeners() {
  stopPresence();
  if (unsubCalls) { unsubCalls(); unsubCalls = null; }
  if (callSt.id || callSt.role) finishCall();
  Object.keys(contactUnsubs).forEach(k => { try { contactUnsubs[k](); } catch (e) {} delete contactUnsubs[k]; });
  if (unsubChats) { unsubChats(); unsubChats = null; }
  if (unsubMessages) { unsubMessages(); unsubMessages = null; }
  if (unsubTyping) { unsubTyping(); unsubTyping = null; }
  Object.keys(chats).forEach(k => delete chats[k]);
  Object.keys(contacts).forEach(k => delete contacts[k]);
}

// ---------------------------------------------------------------------
// screen navigation (with slide animation + bottom-nav indicator)
// ---------------------------------------------------------------------
const FRIENDLY_NAME = {};
const SCREEN_PRERENDER = {
  'screen-archived': () => renderArchivedList(),
  'screen-channels': () => renderChannelsList(),
  'screen-starred':  () => renderStarredList(),
};
const mqDesktop = window.matchMedia('(min-width: 980px)');
function isDesktop() { return mqDesktop.matches; }
const AUTH_SCREENS = new Set(['screen-welcome', 'screen-login', 'screen-register', 'screen-success']);
const RIGHT_PANE = new Set(['screen-chat', 'screen-profile', 'screen-channel-feed', 'screen-empty']);
let focusScreenId = 'screen-welcome';
function showScreen(id, opts = {}) {
  const target = byId(id);
  if (!target || !target.classList.contains('screen')) {
    toast((FRIENDLY_NAME[id] || 'That screen') + ' — coming soon');
    return;
  }
  if (SCREEN_PRERENDER[id]) SCREEN_PRERENDER[id]();
  const direction = opts.direction === 'back' ? 'nav-back' : 'nav-forward';
  const isAuth = AUTH_SCREENS.has(id);
  const clear = (el) => el.classList.remove('active', 'nav-forward', 'nav-back');
  document.body.classList.toggle('in-app', !isAuth);
  focusScreenId = id;
  const dual = isDesktop() && !isAuth;
  const isRight = RIGHT_PANE.has(id);
  if (dual) {
    $$('.screen').forEach(el => {
      el.classList.toggle('pane-right', RIGHT_PANE.has(el.id));
      if (AUTH_SCREENS.has(el.id) || RIGHT_PANE.has(el.id) === isRight) clear(el);
    });
    target.classList.add('active', direction);
    const actives = $$('.screen.active');
    if (!actives.some(el => !RIGHT_PANE.has(el.id))) byId('screen-main').classList.add('active');
    if (!actives.some(el => RIGHT_PANE.has(el.id))) byId('screen-empty').classList.add('active');
  } else {
    $$('.screen').forEach(clear);
    target.classList.add('active', direction);
  }
  target.scrollTop = 0;
  if (!dual || !isRight) {
    $$('.nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === id));
    $$('.drawer-item').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === id));
  }
  $$('.screen.active').forEach(syncNavIndicator);
}
function applyLayoutMode() {
  document.body.classList.toggle('desk', isDesktop());
  if (state && state.me) showScreen(focusScreenId);
}
mqDesktop.addEventListener('change', applyLayoutMode);
function goBack(id) { showScreen(id, { direction: 'back' }); }
function syncNavIndicator(screenEl) {
  const nav = screenEl.querySelector('.bottom-nav');
  if (!nav) return;
  const active = nav.querySelector('.nav-btn.active');
  const indicator = nav.querySelector('.nav-indicator');
  if (!active || !indicator) return;
  indicator.style.width = (active.offsetWidth * 0.5) + 'px';
  indicator.style.transform = `translateX(${active.offsetLeft + active.offsetWidth * 0.25}px)`;
}
window.addEventListener('resize', () => {
  const active = $('.screen.active');
  if (active) syncNavIndicator(active);
});

// ---------------------------------------------------------------------
// drawer
// ---------------------------------------------------------------------
function openDrawer() {
  byId('drawer').classList.add('show');
  byId('drawerOverlay').classList.add('show');
}
function closeDrawer() {
  byId('drawer').classList.remove('show');
  byId('drawerOverlay').classList.remove('show');
}
byId('openDrawerBtn').addEventListener('click', openDrawer);
byId('drawerOverlay').addEventListener('click', closeDrawer);
$$('.drawer-item').forEach(item => {
  item.addEventListener('click', () => { closeDrawer(); showScreen(item.dataset.tab); });
});
byId('drawerUserRow').addEventListener('click', () => { closeDrawer(); showScreen('screen-account'); });

// ---------------------------------------------------------------------
// generic sheet manager (new-chat / attach / message actions / chat actions)
// ---------------------------------------------------------------------
let openSheetEl = null;
function openSheetById(id) {
  if (openSheetEl) openSheetEl.classList.remove('show');
  openSheetEl = byId(id);
  openSheetEl.classList.add('show');
  byId('sheetOverlay').classList.add('show');
}
function closeOpenSheet() {
  if (openSheetEl) openSheetEl.classList.remove('show');
  openSheetEl = null;
  byId('sheetOverlay').classList.remove('show');
}
byId('sheetOverlay').addEventListener('click', closeOpenSheet);

byId('openNewChatSheet').addEventListener('click', () => openSheetById('newChatSheet'));
byId('sheetNewChat').addEventListener('click', () => { closeOpenSheet(); openAddContact(); });
byId('sheetNewGroup').addEventListener('click', () => { closeOpenSheet(); openGroupModal(); });
byId('sheetNewChannel').addEventListener('click', () => { closeOpenSheet(); createChannel(); });
byId('sheetNewStatus').addEventListener('click', () => { closeOpenSheet(); showScreen('screen-status'); byId('statusFileInput').click(); });
byId('sheetImportWa').addEventListener('click', () => { closeOpenSheet(); openImportModal(null); });
byId('openMoreMain').addEventListener('click', () => openSheetById('newChatSheet'));
byId('openCameraTip').addEventListener('click', () => toast('Camera — coming soon'));

byId('openAttachSheet').addEventListener('click', () => openSheetById('attachSheet'));
byId('attachPhoto').addEventListener('click', () => { closeOpenSheet(); byId('imageFileInput').click(); });
byId('attachImportWa').addEventListener('click', () => { closeOpenSheet(); openImportModal(state.currentChatId); });

// ---------------------------------------------------------------------
// generic modal show/hide
// ---------------------------------------------------------------------
function showModal(id) { byId(id).classList.add('show'); }
function hideModal(id) { byId(id).classList.remove('show'); }

// ---------------------------------------------------------------------
// add a contact by Velo ID / username, and the shared "forward" picker
// ---------------------------------------------------------------------
let modalMode = 'newchat';
function openNewChatModal(mode) {
  modalMode = mode || 'newchat';
  byId('newChatModalTitle').textContent = modalMode === 'forward' ? 'Forward to…' : 'New Chat';
  byId('newChatModalSub').textContent = modalMode === 'forward'
    ? 'Enter their Velo ID, phone number, or @username to forward this message.'
    : 'Enter their Velo ID, phone number, or @username.';
  byId('newChatNameField').classList.toggle('hidden', modalMode === 'forward');
  byId('newChatNameInput').value = '';
  byId('newChatSearchInput').value = '';
  byId('newChatResults').innerHTML = '';
  showModal('newChatModal');
  setTimeout(() => byId('newChatSearchInput').focus(), 50);
}
async function findUserByVeloId(id) {
  const q = query(collection(db, 'veloUsers'), where('veloId', '==', id), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  const d = snap.docs[0];
  return Object.assign({ id: d.id }, d.data());
}
async function findUserByUsername(u) {
  const q = query(collection(db, 'veloUsers'), where('username', '==', u), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  const d = snap.docs[0];
  return Object.assign({ id: d.id }, d.data());
}
async function findUserByPhone(p) {
  const q = query(collection(db, 'veloUsers'), where('phone', '==', p), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  const d = snap.docs[0];
  return Object.assign({ id: d.id }, d.data());
}
const contactNicknames = (() => { try { return JSON.parse(localStorage.getItem('velo:nicknames') || '{}'); } catch { return {}; } })();
function setContactNickname(uid, name) {
  if (name) contactNicknames[uid] = name; else delete contactNicknames[uid];
  localStorage.setItem('velo:nicknames', JSON.stringify(contactNicknames));
  if (state.me && state.me.uid) {
    updateDoc(doc(db, 'veloUsers', state.me.uid), { ['contactNames.' + uid]: name ? name : deleteField() }).catch(() => {});
  }
}
let searchBusy = false;
async function performVeloSearch() {
  const raw = byId('newChatSearchInput').value.trim();
  if (!raw) { toast('Enter a Velo ID, phone number, or username'); return; }
  if (searchBusy) return;
  searchBusy = true;
  byId('newChatResults').innerHTML = `<div class="search-hint">Searching…</div>`;
  try {
    let user;
    if (raw.startsWith('@')) user = await findUserByUsername(raw.slice(1));
    else if (/^\d{5}$/.test(raw)) user = await findUserByVeloId(raw);
    else if (/[\d+][\d\s()-]{5,}$/.test(raw)) user = await findUserByPhone(raw.replace(/\s+/g, ' ').trim());
    else user = await findUserByUsername(raw);
    if (!user) { byId('newChatResults').innerHTML = `<div class="search-hint">No Velo user found. Double-check the ID, phone number, or username.</div>`; return; }
    if (user.id === state.me.uid) { byId('newChatResults').innerHTML = `<div class="search-hint">That's you!</div>`; return; }
    contacts[user.id] = user;
    byId('newChatResults').innerHTML = `
      <div class="search-result" id="searchResultRow" style="cursor:pointer;">
        ${avatarHTML(user.id, user.name, 'av-sm')}
        <div class="mid"><div class="name">${escapeHTML(user.name)}</div><div class="sub">@${escapeHTML(user.username)} · Velo ID ${escapeHTML(user.veloId)}</div></div>
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg>
      </div>`;
    byId('searchResultRow').addEventListener('click', () => {
      const nickname = byId('newChatNameInput').value.trim();
      if (nickname && modalMode !== 'forward') setContactNickname(user.id, nickname);
      handleFoundUser(user.id);
    });
  } catch (err) {
    console.error(err);
    byId('newChatResults').innerHTML = `<div class="search-hint">Search failed — check your connection.</div>`;
  } finally {
    searchBusy = false;
  }
}
async function handleFoundUser(otherUid) {
  hideModal('newChatModal');
  const chat = await getOrCreateChat1to1(otherUid);
  if (modalMode === 'forward' && state.forwardMessage) {
    const orig = state.forwardMessage;
    try {
      await addDoc(collection(db, 'chats', chat.id, 'messages'), {
        from: state.me.uid, text: orig.text || '', ts: serverTimestamp(), status: 'sent', forwarded: true,
      });
      await updateDoc(doc(db, 'chats', chat.id), {
        lastMessage: { text: orig.text || '', ts: serverTimestamp(), from: state.me.uid },
        ['unreadBy.' + otherUid]: increment(1),
      });
      toast('Forwarded');
    } catch (err) { console.error(err); toast('Could not forward — check your connection.'); }
    state.forwardMessage = null;
  }
  openChat(chat.id);
}
byId('newChatSearchBtn').addEventListener('click', performVeloSearch);
byId('newChatSearchInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') performVeloSearch(); });
byId('closeNewChatModal').addEventListener('click', () => hideModal('newChatModal'));

async function getOrCreateChat1to1(otherUid) {
  const chatId = chatIdFor(state.me.uid, otherUid);
  if (!contacts[otherUid]) { const p = await getDoc(doc(db, 'veloUsers', otherUid)); if (p.exists()) contacts[otherUid] = Object.assign({ id: otherUid }, p.data()); }
  if (!chats[chatId]) {
    const ref = doc(db, 'chats', chatId);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, { participants: [state.me.uid, otherUid], isGroup: false, createdAt: serverTimestamp(), lastMessage: null });
    }
    chats[chatId] = Object.assign({ id: chatId, participants: [state.me.uid, otherUid], isGroup: false, messages: [],
      pinned: false, muted: false, archived: false, unreadBy: {} }, snap.exists() ? snap.data() : {});
  }
  return chats[chatId];
}

// ---------------------------------------------------------------------
// new group modal
// ---------------------------------------------------------------------
let groupSelected = new Set();
function openGroupModal(preselectId) {
  groupSelected = new Set(preselectId ? [preselectId] : []);
  byId('groupNameInput').value = '';
  byId('groupSearchInput').value = '';
  renderGroupContacts('');
  showModal('groupModal');
}
function renderGroupContacts(query) {
  const q = query.trim().toLowerCase();
  const list = Object.values(contacts).filter(c => !q || c.name.toLowerCase().includes(q));
  byId('groupContactList').innerHTML = list.length ? list.map(c => `
    <button class="chat-row" data-pick="${c.id}">
      ${avatarHTML(c.id, c.name, 'av-sm')}
      <div class="mid"><div class="top-line"><span class="name">${escapeHTML(c.name)}</span></div></div>
      <span style="color:var(--accent-1); font-weight:800; width:18px; text-align:center;">${groupSelected.has(c.id) ? '✓' : ''}</span>
    </button>`).join('') : `<div class="search-hint">Start a chat with someone by Velo ID first — you can add them to a group after.</div>`;
  $$('#groupContactList [data-pick]').forEach(btn => btn.addEventListener('click', () => {
    const id = btn.dataset.pick;
    groupSelected.has(id) ? groupSelected.delete(id) : groupSelected.add(id);
    renderGroupContacts(byId('groupSearchInput').value);
  }));
}
byId('groupSearchInput').addEventListener('input', (e) => renderGroupContacts(e.target.value));
byId('closeGroupModal').addEventListener('click', () => hideModal('groupModal'));
byId('createGroupBtn').addEventListener('click', async () => {
  const name = byId('groupNameInput').value.trim();
  if (!name || groupSelected.size === 0) { toast('Add a group name and at least one member'); return; }
  setBtnLoading(byId('createGroupBtn'), true);
  try {
    const participants = [state.me.uid, ...Array.from(groupSelected)];
    const introText = `${state.me.name} created the group "${name}"`;
    const ref = await addDoc(collection(db, 'chats'), {
      participants, isGroup: true, name, createdAt: serverTimestamp(),
      lastMessage: { text: introText, ts: serverTimestamp(), from: state.me.uid },
    });
    await addDoc(collection(db, 'chats', ref.id, 'messages'), { system: true, text: introText, ts: serverTimestamp() });
    chats[ref.id] = { id: ref.id, participants, isGroup: true, name, messages: [{ id: nextId(), system: true, text: introText, ts: Date.now() }],
      pinned: false, muted: false, archived: false, unreadBy: {} };
    hideModal('groupModal');
    toast('Group created');
    openChat(ref.id);
  } catch (err) {
    console.error(err);
    toast('Could not create the group — check your connection.');
  } finally {
    setBtnLoading(byId('createGroupBtn'), false);
  }
});

// ---------------------------------------------------------------------
// password show/hide (login + register)
// ---------------------------------------------------------------------
$$('[data-toggle-pw]').forEach(eye => {
  eye.addEventListener('click', () => {
    const input = byId(eye.dataset.togglePw);
    input.type = input.type === 'password' ? 'text' : 'password';
  });
});

// ---------------------------------------------------------------------
// pin-style boxes (Velo ID login field + desktop OTP) — auto-advance
// ---------------------------------------------------------------------
function wirePinRow(row) {
  const inputs = $$('input', row);
  inputs.forEach((inp, i) => {
    inp.addEventListener('input', () => {
      inp.value = inp.value.replace(/[^0-9]/g, '').slice(0, 1);
      if (inp.value && inputs[i + 1]) inputs[i + 1].focus();
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !inp.value && inputs[i - 1]) inputs[i - 1].focus();
    });
  });
}
wirePinRow(byId('loginVeloId'));
function readPin(row) { return $$('input', row).map(i => i.value).join(''); }

// ---------------------------------------------------------------------
// Region — picked once on the Welcome screen; the phone fields on
// Login/Sign Up just display the matching code, they don't re-ask.
// ---------------------------------------------------------------------
const COUNTRIES = [
  { iso: 'LK', n: 'Sri Lanka', c: '+94', min: 9, max: 9 },
  { iso: 'DE', n: 'Germany', c: '+49', min: 10, max: 11 },
  { iso: 'US', n: 'USA', c: '+1', min: 10, max: 10 },
  { iso: 'FR', n: 'France', c: '+33', min: 9, max: 9 },
  { iso: 'GB', n: 'UK', c: '+44', min: 10, max: 10 },
  { iso: 'JP', n: 'Japan', c: '+81', min: 9, max: 10 },
  { iso: 'IN', n: 'India', c: '+91', min: 10, max: 10 },
  { iso: 'AU', n: 'Australia', c: '+61', min: 9, max: 9 },
  { iso: 'AE', n: 'UAE', c: '+971', min: 9, max: 9 },
  { iso: 'SG', n: 'Singapore', c: '+65', min: 8, max: 8 },
  { iso: 'MY', n: 'Malaysia', c: '+60', min: 9, max: 10 },
  { iso: 'PK', n: 'Pakistan', c: '+92', min: 10, max: 10 },
  { iso: 'BD', n: 'Bangladesh', c: '+880', min: 10, max: 10 },
  { iso: 'NP', n: 'Nepal', c: '+977', min: 10, max: 10 },
  { iso: 'MV', n: 'Maldives', c: '+960', min: 7, max: 7 },
  { iso: 'SA', n: 'Saudi Arabia', c: '+966', min: 9, max: 9 },
  { iso: 'QA', n: 'Qatar', c: '+974', min: 8, max: 8 },
];
function ccInfo(code) { return COUNTRIES.find(c => c.c === code) || { iso: '', n: '', c: code, min: 6, max: 14 }; }
// digits only, never starts with 0, capped to the country's real length
function cleanPhone(raw, info) { return String(raw || '').replace(/\D/g, '').replace(/^0+/, '').slice(0, info.max); }
function phoneLenText(info) { return info.min === info.max ? String(info.max) : info.min + '–' + info.max; }
// "+94 0771234567" and "+94 771234567" are the same number
function canonPhone(str) {
  const t = String(str || '').trim();
  const m = t.match(/^(\+\d{1,3})\s+(.*)$/);
  if (!m) return t.replace(/[^\d+]/g, '');
  return m[1] + m[2].replace(/\D/g, '').replace(/^0+/, '');
}
function buildCountrySelect(sel) {
  sel.innerHTML = COUNTRIES.map(c => `<option value="${c.c}" title="${c.n}">${c.iso} ${c.c}</option>`).join('');
}
['loginCc', 'regCc', 'acCc'].forEach(id => { const el = byId(id); if (el) buildCountrySelect(el); });
function bindPhoneField(inputId, selectId, onChange) {
  const inp = byId(inputId), sel = byId(selectId);
  const apply = () => {
    const info = ccInfo(sel.value);
    const cleaned = cleanPhone(inp.value, info);
    if (cleaned !== inp.value) inp.value = cleaned;
    inp.placeholder = phoneLenText(info) + ' digits';
  };
  inp.addEventListener('input', () => { apply(); if (onChange) onChange(); });
  sel.addEventListener('change', () => { apply(); if (onChange) onChange(); });
  apply();
}
function applyRegionCode(code) {
  ['loginCc', 'regCc', 'acCc'].forEach(id => {
    const el = byId(id);
    if (el && Array.from(el.options).some(o => o.value === code)) el.value = code;
    el.dispatchEvent(new Event('change'));
  });
}
bindPhoneField('loginPhone', 'loginCc');
bindPhoneField('regPhone', 'regCc');
byId('regionSelect').addEventListener('change', () => {
  const opt = byId('regionSelect').selectedOptions[0];
  localStorage.setItem('velo:region', JSON.stringify({ code: opt.value, country: opt.dataset.country }));
  applyRegionCode(opt.value);
});
(function restoreRegion() {
  try {
    const saved = JSON.parse(localStorage.getItem('velo:region') || 'null');
    if (saved) {
      byId('regionSelect').value = saved.code;
      applyRegionCode(saved.code);
    } else {
      applyRegionCode(byId('regionSelect').value);
    }
  } catch { applyRegionCode(byId('regionSelect').value); }
})();

// ---------------------------------------------------------------------
// auth — Continue With Google (real identity verification for both
// pages). Login also accepts a Velo ID or phone number as a shortcut
// to find the account, but Google is still what actually proves it's
// yours — typing an ID never logs anyone in on its own.
// ---------------------------------------------------------------------
// Sequential Velo IDs: 00000 for the first account ever created, 00001 for
// the next, and so on — tracked by one small counter doc, claimed atomically
// via a transaction so two people signing up at the same instant can never
// be handed the same ID.
async function generateUniqueVeloId() {
  const counterRef = doc(db, 'veloMeta', 'idCounter');
  const n = await runTransaction(db, async (tx) => {
    const snap = await tx.get(counterRef);
    const current = snap.exists() ? (snap.data().next || 0) : 0;
    tx.set(counterRef, { next: current + 1 }, { merge: true });
    return current;
  });
  return String(n).padStart(5, '0');
}
async function createProfileFromGoogle({ uid, email, phone, first, last, username }) {
  const name = [first, last].filter(Boolean).join(' ') || 'New User';
  const veloId = await generateUniqueVeloId();
  let uname = username || (name.toLowerCase().replace(/[^a-z0-9._]/g, '') || 'user');
  if (!username && await findUserByUsername(uname)) uname = uname + veloId;
  const profile = {
    uid, name, email, phone,
    username: uname,
    veloId, createdAt: serverTimestamp(),
  };
  await setDoc(doc(db, 'veloUsers', uid), profile);
  state.me = profile;
  return profile;
}
async function logoutAccount() {
  if (state.me && state.me.uid) localStorage.removeItem('velo:verified:' + state.me.uid);
  await signOut(auth);
  state.me = null;
  state.pendingGoogleUser = null;
  paintGoogleUI('');
  paintGoogleUI('Reg');
  hideRegisterFields();
  detachAllListeners();
}

async function googleSignIn(withDrive = false) {
  if (withDrive) driveProvider.setCustomParameters({ prompt: 'select_account' });
  const cred = await signInWithPopup(auth, withDrive ? driveProvider : googleProvider);
  if (withDrive) {
    // The one-time Drive consent happens here, during sign-up. Keep the token for this session's first backup.
    const gc = GoogleAuthProvider.credentialFromResult(cred);
    if (gc && gc.accessToken) { driveAccessToken = gc.accessToken; driveTokenExpiresAt = Date.now() + 50 * 60 * 1000; }
  }
  const u = cred.user;
  state.pendingGoogleUser = { uid: u.uid, email: u.email, name: u.displayName || '', photoURL: u.photoURL || '' };
  paintGoogleUI('');
  paintGoogleUI('Reg');
}
// suffix '' = Login page's elements, 'Reg' = Sign Up page's elements —
// both mirror the same state.pendingGoogleUser so either page shows the
// verified email as soon as it's picked, whichever page triggered it.
function paintGoogleUI(suffix) {
  const btn = byId('googleSignInBtn' + suffix);
  const panel = byId('googleConfirmPanel' + suffix);
  const g = state.pendingGoogleUser;
  if (!g) { btn.classList.remove('hidden'); panel.classList.add('hidden'); return; }
  byId('googleConfirmEmail' + suffix).textContent = g.email;
  const av = byId('googleConfirmAvatar' + suffix);
  if (g.photoURL) { av.src = g.photoURL; av.style.display = ''; } else { av.style.display = 'none'; }
  btn.classList.add('hidden');
  panel.classList.remove('hidden');
}
let googleAttempt = 0;
function wireGoogleButtons(suffix, onVerified) {
  const run = async (btn) => {
    const attempt = ++googleAttempt;
    setBtnLoading(btn, true);
    // open Google's pop-up first (must happen inside the tap), then show Velo's own card over the page
    const pending = googleSignIn(suffix === 'Reg');
    byId('gwaitSub').textContent = suffix === 'Reg'
      ? 'Choose your Google account in the pop-up. Google will also ask once for Google Drive access (for chat backups).'
      : "Choose your Google account in the Google pop-up window. This screen updates by itself when you're done.";
    showModal('googleWaitModal');
    try {
      await pending;
      if (attempt !== googleAttempt) { signOut(auth).catch(() => {}); state.pendingGoogleUser = null; return; }   // cancelled while open
      if (onVerified) await onVerified(state.pendingGoogleUser);
    } catch (err) {
      if (attempt !== googleAttempt) return;
      if (err?.code === 'auth/popup-blocked') toast('Your browser blocked the Google pop-up — allow pop-ups for this site, then tap again.');
      else if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') toast(friendlyAuthError(err));
    } finally {
      if (attempt === googleAttempt) hideModal('googleWaitModal');
      setBtnLoading(btn, false);
    }
  };
  byId('googleSignInBtn' + suffix).addEventListener('click', () => run(byId('googleSignInBtn' + suffix)));
  byId('googleEditBtn' + suffix).addEventListener('click', () => run(byId('googleEditBtn' + suffix)));
}

// ---------------------------------------------------------------------
// Sign Up — Google only verifies the Gmail is real; it can't create an
// account by itself. If that Google account already has a Velo profile
// we just continue straight into the app; otherwise we reveal the rest
// of the sign-up form so they can finish creating one.
// ---------------------------------------------------------------------
function revealRegisterFields(g) {
  byId('regDetailsFields').classList.remove('hidden');
  byId('regSubmit').classList.remove('hidden');
  const parts = (g.name || '').trim().split(/\s+/);
  if (!byId('regFirst').value) byId('regFirst').value = parts[0] || '';
  if (!byId('regLast').value) byId('regLast').value = parts.slice(1).join(' ') || '';
}
function hideRegisterFields() {
  byId('regDetailsFields').classList.add('hidden');
  byId('regSubmit').classList.add('hidden');
}
async function handleGoogleVerifiedForSignup(g) {
  const snap = await getDoc(doc(db, 'veloUsers', g.uid));
  if (snap.exists()) {
    // already a real Velo account — nothing left to "sign up" for
    toast('You already have a Velo account — please log in with your Velo ID and phone.');
    showScreen('screen-login');
  } else {
    revealRegisterFields(g);
  }
}

wireGoogleButtons('');
wireGoogleButtons('Reg', handleGoogleVerifiedForSignup);

byId('welcomeContinue').addEventListener('click', () => showScreen('screen-login'));
byId('loginBack').addEventListener('click', () => goBack('screen-welcome'));
byId('loginToRegister').addEventListener('click', () => showScreen('screen-register'));
byId('regToLogin').addEventListener('click', () => showScreen('screen-login'));

byId('loginSubmit').addEventListener('click', async () => {
  const veloId = readPin(byId('loginVeloId'));
  const info = ccInfo(byId('loginCc').value);
  const digits = cleanPhone(byId('loginPhone').value, info);
  if (veloId.length !== 5) { toast('Step 1: enter your 5-digit Velo ID'); return; }
  if (digits.length < info.min) { toast(`Step 2: enter your full phone number (${phoneLenText(info)} digits)`); return; }
  if (!auth.currentUser || !state.pendingGoogleUser) { toast('Step 3: verify your email with Continue With Google'); return; }
  const phone = info.c + ' ' + digits;

  setBtnLoading(byId('loginSubmit'), true);
  try {
    const g = state.pendingGoogleUser;
    const snap = await getDocs(query(collection(db, 'veloUsers'), where('veloId', '==', veloId), limit(1)));
    if (snap.empty) { toast('No Velo account found for that Velo ID.'); return; }
    const account = snap.docs[0];
    if (canonPhone(account.data().phone) !== canonPhone(phone)) { toast("That phone number doesn't match this Velo ID."); return; }
    if (g.uid !== account.id) { toast("That Google account doesn't match your Velo ID / phone number."); return; }

    state.me = Object.assign({ uid: g.uid }, account.data());
    requirePasswordGate('Enter your password to finish logging in.', () => enterApp());
  } catch (err) {
    if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') toast(friendlyAuthError(err));
  } finally {
    setBtnLoading(byId('loginSubmit'), false);
  }
});

byId('regSubmit').addEventListener('click', async () => {
  const g = state.pendingGoogleUser;
  const info = ccInfo(byId('regCc').value);
  const digits = cleanPhone(byId('regPhone').value, info);
  const first = byId('regFirst').value.trim();
  const last = byId('regLast').value.trim();
  const username = byId('regUsername').value.trim().replace(/^@/, '').toLowerCase();
  if (!g || !auth.currentUser) { toast('Verify with Google first, then fill in your details.'); return; }
  if (digits.length < info.min) { toast(`Enter your full phone number (${phoneLenText(info)} digits, no leading 0)`); return; }
  if (!first) { toast('Please enter your first name'); return; }
  if (username && !/^[a-z0-9._]{3,24}$/.test(username)) { toast('Usernames use 3–24 letters, numbers, . or _'); return; }
  const phone = info.c + ' ' + digits;
  setBtnLoading(byId('regSubmit'), true);
  try {
    const existing = await getDoc(doc(db, 'veloUsers', g.uid));
    if (existing.exists()) { toast('That Google account already has a Velo account — please log in.'); showScreen('screen-login'); return; }
    if (await findUserByPhone(phone)) { toast('That phone number is already registered with Velo.'); return; }
    if (username && await findUserByUsername(username)) { toast('That username is taken — try another.'); return; }
    const acc = await createProfileFromGoogle({ uid: g.uid, email: g.email, phone, first, last, username });
    byId('successVeloId').textContent = acc.veloId;
    byId('successName').textContent = acc.name;
    byId('successEmail').textContent = acc.email;
    showScreen('screen-success');
  } catch (err) {
    toast(friendlyAuthError(err));
  } finally {
    setBtnLoading(byId('regSubmit'), false);
  }
});

byId('successContinue').addEventListener('click', () => enterApp());


function renderChatSkeleton() {
  byId('chatListBody').innerHTML = Array.from({ length: 3 }).map(() => `
    <div class="skeleton-row">
      <div class="skel avatar"></div>
      <div style="flex:1;">
        <div class="skel line" style="width:55%;"></div>
        <div class="skel line" style="width:80%; height:10px; margin-bottom:0;"></div>
      </div>
    </div>`).join('');
}
function enterApp(opts = {}) {
  if (state.me && state.me.uid) {
    localStorage.setItem('velo:verified:' + state.me.uid, '1');
    Object.assign(contactNicknames, state.me.contactNames || {});
  }
  loadChannels();
  loadCallLog();
  renderAccountScreen();
  renderChatSkeleton();
  renderCallsList();
  renderStatusList();
  renderChannelsList();
  attachChatsListener(opts.onFirstLoad);
  startPresence();
  attachCallsListener();
  cleanupMyStatuses();
  setTimeout(checkScheduled, 2500);
  refreshPasswordUI();
  showScreen('screen-main');
  maybeShowOpenGate();
}

// ---------------------------------------------------------------------
// real-time chat list (+ "n out of N" progress for the splash screen)
// ---------------------------------------------------------------------
function maybeNotify(chat) {
  const lm = chat.lastMessage;
  if (!lm || !state.me || lm.from === state.me.uid || lm.imported) return;
  if (chat.muted || isBlocked(lm.from)) return;
  const other = chat.isGroup ? null : otherParticipant(chat);
  if (localStorage.getItem('velo:toggleMuteMessages') === '1' && other && !contactNicknames[other.id]) return;
  const viewing = !document.hidden && state.currentChatId === chat.id && byId('screen-chat').classList.contains('active');
  if (viewing) return;
  const name = chatDisplayName(chat);
  const text = lm.text || 'New message';
  if (document.hidden && localStorage.getItem('velo:browserNotifs') === '1' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const n = new Notification(name, { body: text, icon: 'mainimg.png', tag: chat.id });
      n.onclick = () => { window.focus(); openChat(chat.id); n.close(); };
    } catch (e) {}
  } else if (!document.hidden) {
    toast(name + ': ' + (text.length > 60 ? text.slice(0, 60) + '…' : text));
  }
}
function markNoteDismissed(chat) {
  if (!chat || !chat.isNote || !state.me) return;
  localStorage.setItem('velo:noteDismissed:' + state.me.uid, '1');
  state.me.noteDismissed = true;
  updateDoc(doc(db, 'veloUsers', state.me.uid), { noteDismissed: true }).catch(() => {});
}
// every account gets a private "My Note" chat once; deleting it keeps it deleted
async function ensureMyNote() {
  const me = state.me;
  if (!me || me.noteDismissed || localStorage.getItem('velo:noteDismissed:' + me.uid) === '1') return;
  if (Object.values(chats).some(c => c.isNote)) return;
  const intro = 'Only you can see this chat — save notes, links and reminders here.';
  try {
    const ref = doc(db, 'chats', 'note_' + me.uid);
    await setDoc(ref, { participants: [me.uid], isGroup: true, isNote: true, name: 'My Note', createdAt: serverTimestamp(), lastMessage: { text: intro, ts: serverTimestamp(), from: me.uid }, unreadBy: {} });
    await addDoc(collection(db, 'chats', ref.id, 'messages'), { system: true, text: intro, ts: serverTimestamp() });
  } catch (err) { console.error('My Note:', err); }
}
function attachChatsListener(onFirstLoad) {
  if (unsubChats) unsubChats();
  let first = true;
  const q = query(collection(db, 'chats'), where('participants', 'array-contains', state.me.uid));
  unsubChats = onSnapshot(q, async (snap) => {
    const changes = snap.docChanges();
    const total = changes.length;
    let done = 0;
    if (first) splashProgress(0, total);
    const run = async (change) => {
      const chatId = change.doc.id;
      if (change.type === 'removed') {
        delete chats[chatId];
      } else {
        const data = change.doc.data();
        const existing = chats[chatId] || { messages: [], pinned: false, muted: false, archived: false };
        const prevTs = existing.lastMessage ? tsMillis(existing.lastMessage.ts) : 0;
        const deliveredChanged = JSON.stringify(existing.deliveredAt || {}) !== JSON.stringify(data.deliveredAt || {});
        chats[chatId] = Object.assign(existing, {
          id: chatId, participants: data.participants || [], isGroup: !!data.isGroup, name: data.name || null,
          lastMessage: data.lastMessage || null, unreadBy: data.unreadBy || {}, disappearMs: data.disappearMs || 0, isNote: !!data.isNote,
          deliveredAt: data.deliveredAt || {},
        });
        if (!data.isGroup) {
          const otherUid = (data.participants || []).find(p => p !== state.me.uid);
          if (otherUid && !contacts[otherUid]) {
            try { const p = await getDoc(doc(db, 'veloUsers', otherUid)); if (p.exists()) contacts[otherUid] = Object.assign({ id: otherUid }, p.data()); } catch (e) {}
          }
          if (otherUid) watchContact(otherUid);
        }
        if (!chats[chatId]._preloaded) await preloadMessages(chatId);   // so the chat opens with its messages already there
        markDelivered(chatId, data);
        if (!first && change.type === 'modified' && data.lastMessage && data.lastMessage.ts && tsMillis(data.lastMessage.ts) > prevTs) maybeNotify(chats[chatId]);
        if (state.currentChatId === chatId) { refreshChatHeader(chatId); if (deliveredChanged) renderThread(); }
      }
      done++;
      if (first) splashProgress(done, total);
    };
    const queue = changes.slice();
    await Promise.all(Array.from({ length: Math.min(6, queue.length) }, async () => { while (queue.length) await run(queue.shift()); }));
    renderChatList(byId('chatSearch').value);
    if (first) { first = false; if (onFirstLoad) onFirstLoad(); ensureMyNote(); }
  }, (err) => { console.error(err); toast('Lost connection to your chats — retrying…'); if (first) { first = false; if (onFirstLoad) onFirstLoad(); } });
}
function lastMessage(chat) {
  if (!chat.lastMessage) return null;
  return { text: chat.lastMessage.text, ts: tsMillis(chat.lastMessage.ts), from: chat.lastMessage.from };
}
function unreadCount(chat) { return (chat.unreadBy && state.me) ? (chat.unreadBy[state.me.uid] || 0) : 0; }

let chatFilter = 'all';
function renderChatList(filter = '') {
  const q = filter.trim().toLowerCase();
  const rows = Object.values(chats)
    .filter(chat => !chat.archived)
    .filter(chat => chatFilter === 'all' || (chatFilter === 'unread' ? unreadCount(chat) > 0 : !!chat.isGroup))
    .filter(chat => !q || chatDisplayName(chat).toLowerCase().includes(q))
    .sort((a, b) => {
      if (!!b.pinned !== !!a.pinned) return (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0);
      return (lastMessage(b)?.ts || 0) - (lastMessage(a)?.ts || 0);
    });

  if (!rows.length && chatFilter !== 'all') {
    byId('chatListBody').innerHTML = `<div class="empty-state"><h3>${chatFilter === 'unread' ? 'No unread chats' : 'No groups yet'}</h3><div>${chatFilter === 'unread' ? "You're all caught up." : 'Groups you join will show up here.'}</div></div>`;
    return;
  }
  if (!rows.length) {
    byId('chatListBody').innerHTML = `
      <div class="empty-state">
        <span class="ic"><svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z"/></svg></span>
        <h3>No chats yet</h3>
        <div>Add a friend by Velo ID, phone number or user name.</div>
        <button class="btn btn-primary btn-sm" id="emptyAddBtn" style="margin-top:14px;">Add Contact</button>
      </div>`;
    return;
  }
  byId('chatListBody').innerHTML = rows.map(chat => {
    const name = chatDisplayName(chat);
    const lm = lastMessage(chat);
    const unread = unreadCount(chat);
    const icons = `${chat.pinned ? '<svg class="pin-ic" width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17v5M8 3h8l-1 6 3 3v2H6v-2l3-3-1-6Z"/></svg>' : ''}${chat.muted ? '<svg class="mute-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M23 9l-6 6M17 9l6 6"/></svg>' : ''}`;
    return `
      <button class="chat-row ${chat.pinned ? 'pinned' : ''}" data-chat="${chat.id}">
        ${avatarHTML(chat.id, name, 'av-sm')}
        <div class="mid">
          <div class="top-line">
            <span class="name">${escapeHTML(name)}</span>
            <span class="row-icons">${icons}<span class="time ${unread && !chat.muted ? 'unread' : ''}">${lm ? timeLabel(lm.ts) : ''}</span></span>
          </div>
          <div class="bottom-line">
            <span class="msg">${lm ? escapeHTML(lm.from === state.me.uid ? 'You: ' + lm.text : lm.text) : 'Say hi 👋'}</span>
            ${unread ? `<span class="badge" style="${chat.muted ? 'background:var(--text-3)' : ''}">${unread}</span>` : ''}
          </div>
        </div>
      </button>`;
  }).join('');
  $$('#chatListBody [data-chat]').forEach(btn => {
    bindLongPress(btn, () => openChatActionSheet(btn.dataset.chat), () => openChat(btn.dataset.chat));
  });
}
byId('chatSearch').addEventListener('input', (e) => renderChatList(e.target.value));
$$('#chatFilters .fchip').forEach(b => b.addEventListener('click', () => {
  chatFilter = b.dataset.f;
  $$('#chatFilters .fchip').forEach(x => x.classList.toggle('active', x === b));
  renderChatList(byId('chatSearch').value);
}));
byId('fabNewChat').addEventListener('click', () => openAddContact());
$$('.nav-btn[data-tab]').forEach(btn => btn.addEventListener('click', () => showScreen(btn.dataset.tab)));

// ---------------------------------------------------------------------
// per-chat action sheet: pin / mute / archive / delete (local prefs,
// except delete which removes the shared Firestore chat doc for everyone)
// ---------------------------------------------------------------------
function openChatActionSheet(chatId) {
  state.longPressChatId = chatId;
  const chat = chats[chatId];
  byId('chatActionSheetTitle').textContent = chatDisplayName(chat);
  byId('actPinLabel').textContent = chat.pinned ? 'Unpin chat' : 'Pin chat';
  byId('actMuteLabel').textContent = chat.muted ? 'Unmute chat' : 'Mute chat';
  byId('actArchiveLabel').textContent = chat.archived ? 'Unarchive' : 'Archive';
  openSheetById('chatActionSheet');
}
byId('actPin').addEventListener('click', () => {
  const chat = chats[state.longPressChatId]; if (!chat) return; chat.pinned = !chat.pinned;
  closeOpenSheet(); renderChatList(); toast(chat.pinned ? 'Chat pinned' : 'Chat unpinned');
});
byId('actMute').addEventListener('click', () => {
  const chat = chats[state.longPressChatId]; if (!chat) return; chat.muted = !chat.muted;
  closeOpenSheet(); renderChatList(); toast(chat.muted ? 'Notifications muted' : 'Notifications unmuted');
});
byId('actArchive').addEventListener('click', () => {
  const chat = chats[state.longPressChatId]; if (!chat) return; chat.archived = !chat.archived;
  closeOpenSheet(); renderChatList(); renderArchivedList();
  toast(chat.archived ? 'Chat archived' : 'Chat unarchived');
});
byId('actDeleteChat').addEventListener('click', () => {
  const id = state.longPressChatId;
  const name = chatDisplayName(chats[id]);
  closeOpenSheet();
  confirmAction(chats[id] && chats[id].isNote ? 'Delete My Note?' : 'Delete this chat?', chats[id] && chats[id].isNote ? 'Your saved notes will be removed. You can still start a new note by creating a group.' : `This deletes your conversation with ${name} for both of you.`, async () => {
    try { markNoteDismissed(chats[id]); await deleteDoc(doc(db, 'chats', id)); delete chats[id]; if (state.currentChatId === id) { state.currentChatId = null; if (isDesktop()) showScreen('screen-empty'); } renderChatList(); renderArchivedList(); toast('Chat deleted'); }
    catch (err) { console.error(err); toast('Could not delete — check your connection.'); }
  });
});

function renderArchivedList() {
  const rows = Object.values(chats).filter(c => c.archived);
  const body = byId('archivedListBody');
  if (!body) return;
  if (!rows.length) { body.innerHTML = `<div class="empty-state"><div class="ic"><svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8"/><rect x="1" y="3" width="22" height="5" rx="1"/><path d="M10 12h4"/></svg></div><h3>No archived chats</h3><div>Chats you archive from the list will show up here.</div></div>`; return; }
  body.innerHTML = rows.map(chat => {
    const name = chatDisplayName(chat);
    const lm = lastMessage(chat);
    return `
      <button class="chat-row" data-chat="${chat.id}">
        ${avatarHTML(chat.id, name, 'av-sm')}
        <div class="mid">
          <div class="top-line"><span class="name">${escapeHTML(name)}</span><span class="time">${lm ? timeLabel(lm.ts) : ''}</span></div>
          <div class="bottom-line"><span class="msg">${lm ? escapeHTML(lm.text) : ''}</span></div>
        </div>
      </button>`;
  }).join('');
  $$('#archivedListBody [data-chat]').forEach(btn => {
    bindLongPress(btn, () => openChatActionSheet(btn.dataset.chat), () => openChat(btn.dataset.chat));
  });
}
byId('archivedBack').addEventListener('click', () => goBack('screen-main'));

// ---------------------------------------------------------------------
// starred messages (local-only — see file header)
// ---------------------------------------------------------------------
function renderStarredList() {
  const body = byId('starredListBody');
  if (!body) return;
  const rows = [];
  Object.values(chats).forEach(chat => {
    chat.messages.filter(m => m.starred).forEach(m => rows.push({ chatId: chat.id, msg: m }));
  });
  rows.sort((a, b) => b.msg.ts - a.msg.ts);
  if (!rows.length) { body.innerHTML = `<div class="empty-state"><div class="ic"><svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2 2.9 6.6L22 9.3l-5 4.8 1.3 7-6.3-3.6L5.7 21l1.3-7-5-4.8 7.1-.7Z"/></svg></div><h3>No starred messages</h3><div>Long-press any message to star it.</div></div>`; return; }
  body.innerHTML = rows.map(r => {
    const name = chatDisplayName(chats[r.chatId]);
    return `
      <button class="starred-row" data-chat="${r.chatId}">
        <div class="tx">
          <div class="chatnm">${escapeHTML(name)}</div>
          <div class="snip"><span class="who">${r.msg.from === state.me.uid ? 'You: ' : ''}</span>${escapeHTML(previewText(r.msg))}</div>
        </div>
      </button>`;
  }).join('');
  $$('#starredListBody [data-chat]').forEach(b => b.addEventListener('click', () => openChat(b.dataset.chat)));
}
byId('starredBack').addEventListener('click', () => goBack('screen-main'));

// ---------------------------------------------------------------------
// calls / status tabs — local-only for now (see file header)
// ---------------------------------------------------------------------
function renderCallsList() {
  if (!callLog.length) { byId('callsListBody').innerHTML = `<div class="empty-state"><h3>No calls yet</h3></div>`; return; }
  byId('callsListBody').innerHTML = callLog.map(call => {
    const c = contacts[call.contactId];
    if (!c) return '';
    return `
      <div class="call-row" data-call="${c.id}">
        ${avatarHTML(c.id, c.name, 'av-sm')}
        <div class="tx">
          <div class="nm">${escapeHTML(c.name)}</div>
          <div class="meta ${call.type === 'missed' ? 'missed' : ''}">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${call.type === 'outgoing' ? '<path d="M7 17 17 7M9 7h8v8"/>' : call.type === 'missed' ? '<path d="M17 7 7 17M9 17H7v-2"/>' : '<path d="M17 7 7 17M15 17h2v-2"/>'}</svg>
            ${call.type[0].toUpperCase() + call.type.slice(1)}${call.kind === 'video' ? ' video' : ''} · ${timeLabel(call.ts)}
          </div>
        </div>
        <span class="ic-call" data-callbtn="${c.id}"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2Z"/></svg></span>
      </div>`;
  }).join('');
  $$('#callsListBody [data-callbtn]').forEach(el => el.addEventListener('click', () => startCall(el.dataset.callbtn)));
}

let storyTimer = null;
const STATUS_EXPIRY_MS = 2 * 24 * 60 * 60 * 1000;   // statuses disappear after 2 days
const STATUS_SECONDS = 6.7;                          // every status plays for 6.7 seconds, then moves on / closes
const MAX_VIDEO_STATUS_SEC = STATUS_SECONDS;
const MAX_VIDEO_BYTES = 700 * 1024; // leaves headroom under Firestore's 1MiB/doc cap once base64-encoded (~33% larger)
async function fetchLatestStatus(uid) {
  const snap = await getDocs(query(collection(db, 'statuses', uid, 'items'), orderBy('createdAt', 'desc'), limit(1)));
  if (snap.empty) return null;
  const d = snap.docs[0];
  const data = d.data();
  if (Date.now() - tsMillis(data.createdAt) > STATUS_EXPIRY_MS) return null;
  return Object.assign({ id: d.id }, data);
}
async function loadBitmap(file) {
  if (window.createImageBitmap) { try { return await createImageBitmap(file); } catch (e) { /* fall through to <img> decoding */ } }
  const url = URL.createObjectURL(file);
  try {
    return await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('decode')); im.src = url; });
  } finally { setTimeout(() => URL.revokeObjectURL(url), 5000); }
}
async function compressImageToDataURL(file, maxDim = 900, quality = 0.72) {
  const bitmap = await loadBitmap(file);
  let width = bitmap.width || bitmap.naturalWidth, height = bitmap.height || bitmap.naturalHeight;
  if (!width || !height) throw new Error('decode');
  if (width > maxDim || height > maxDim) {
    const scale = maxDim / Math.max(width, height);
    width = Math.round(width * scale); height = Math.round(height * scale);
  }
  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  canvas.getContext('2d').drawImage(bitmap, 0, 0, width, height);
  return canvas.toDataURL('image/jpeg', quality);
}
function fileToDataURL(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}
function videoDuration(file) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.preload = 'metadata';
    v.onloadedmetadata = () => { URL.revokeObjectURL(v.src); resolve(v.duration || 0); };
    v.onerror = () => resolve(0);
    v.src = URL.createObjectURL(file);
  });
}
function statusErrorMessage(err) {
  const code = (err && err.code) || '';
  if (code === 'permission-denied') return 'Firebase is blocking statuses — publish the latest firestore.rules (Firestore → Rules → Publish), then try again.';
  if (code === 'unavailable' || code === 'deadline-exceeded' || code === 'unauthenticated') return code === 'unauthenticated' ? 'You were signed out — log in again and retry.' : 'No connection — check your internet and try again.';
  if (code === 'invalid-argument' || code === 'resource-exhausted') return 'That file is too big to post — try a smaller photo or a shorter clip.';
  if (err && err.message === 'decode') return "Couldn't read that file — try a JPG or PNG photo.";
  return 'Could not post that status' + (code ? ' (' + code + ')' : '') + ' — try again.';
}
async function postStatus(file, caption = '') {
  const isVideo = file.type.startsWith('video/');
  try {
    let dataUrl, durationSec, kind;
    if (isVideo) {
      if (file.size > MAX_VIDEO_BYTES) {
        toast(`That video's too large — keep clips under about ${Math.round(MAX_VIDEO_BYTES / 1024)}KB. Try shorter or lower-res.`);
        return false;
      }
      const dur = await videoDuration(file);
      durationSec = Math.max(1, Math.min(MAX_VIDEO_STATUS_SEC, dur || MAX_VIDEO_STATUS_SEC));
      dataUrl = await fileToDataURL(file);
      kind = 'video';
    } else {
      dataUrl = await compressImageToDataURL(file, 960, 0.7);
      if (dataUrl.length > 850 * 1024) dataUrl = await compressImageToDataURL(file, 720, 0.55);   // second, smaller pass
      if (dataUrl.length > 900 * 1024) { toast('That image is still too large after compression — try a smaller photo.'); return false; }
      durationSec = STATUS_SECONDS;
      kind = 'image';
    }
    const item = { kind, dataUrl, durationSec, createdAt: serverTimestamp(), reactions: {} };
    if (caption) item.caption = caption;
    await addDoc(collection(db, 'statuses', state.me.uid, 'items'), item);
    toast('Status posted');
    renderStatusList();
    return true;
  } catch (err) {
    console.error(err);
    toast(statusErrorMessage(err));
    return false;
  }
}
// pick -> preview + optional title -> post
let scFile = null, scUrl = null;
function openStatusCompose(file) {
  if (!/^(image|video)\//.test(file.type)) { toast('Please choose a photo or a video'); return; }
  scFile = file;
  if (scUrl) URL.revokeObjectURL(scUrl);
  scUrl = URL.createObjectURL(file);
  byId('scPreview').innerHTML = file.type.startsWith('video/') ? `<video src="${scUrl}" muted playsinline controls></video>` : `<img src="${scUrl}" alt="">`;
  byId('scCaption').value = '';
  byId('scCount').textContent = '0/80';
  showModal('statusComposeModal');
}
function closeStatusCompose() { hideModal('statusComposeModal'); if (scUrl) { URL.revokeObjectURL(scUrl); scUrl = null; } scFile = null; byId('scPreview').innerHTML = ''; }
byId('scCaption').addEventListener('input', (e) => { byId('scCount').textContent = e.target.value.length + '/80'; });
byId('scCaption').addEventListener('keydown', (e) => { if (e.key === 'Enter') byId('scPost').click(); });
byId('scCancel').addEventListener('click', closeStatusCompose);
byId('scPost').addEventListener('click', async () => {
  if (!scFile) return;
  setBtnLoading(byId('scPost'), true);
  const ok = await postStatus(scFile, byId('scCaption').value.trim());
  setBtnLoading(byId('scPost'), false);
  if (ok) closeStatusCompose();
});
byId('statusFileInput').addEventListener('change', () => {
  const file = byId('statusFileInput').files[0];
  byId('statusFileInput').value = '';
  if (file) openStatusCompose(file);
});
byId('openStatusCam').addEventListener('click', () => byId('statusFileInput').click());

async function renderStatusList() {
  if (!state.me) return;
  const myLatest = await fetchLatestStatus(state.me.uid);
  const contactList = Object.values(contacts).slice(0, 12);
  const results = await Promise.all(contactList.map(async c => ({ contact: c, latest: await fetchLatestStatus(c.id) })));
  const others = results.filter(r => r.latest);
  const recentHTML = others.length ? `
    <div class="section-label">Recent updates</div>
    ${others.map(o => `
      <div class="status-row" data-story="${o.contact.id}">
        <div class="status-ring"><div class="inner">${avatarHTML(o.contact.id, o.contact.name, 'av-sm')}</div></div>
        <div class="tx"><div class="nm">${escapeHTML(contactNicknames[o.contact.id] || o.contact.name)}</div><div class="meta muted">${timeLabel(o.latest.createdAt)}</div></div>
      </div>`).join('')}
  ` : `<div class="muted" style="text-align:center; padding:24px 0;">Add contacts by Velo ID to see their status updates here.</div>`;
  byId('statusListBody').innerHTML = `
    <div class="status-row" id="myStatusRow">
      <div class="status-ring ${myLatest ? '' : 'seen'}"><div class="inner">${avatarHTML('me', state.me?.name || 'Me', 'av-sm')}</div></div>
      <div class="tx"><div class="nm">My Status</div><div class="meta muted">${myLatest ? 'Tap to view · tap camera to add another' : 'Tap to add a status update'}</div></div>
    </div>
    ${recentHTML}
  `;
  byId('myStatusRow').addEventListener('click', () => {
    if (myLatest) openStoryViewer(state.me.uid, true);
    else byId('statusFileInput').click();
  });
  $$('#statusListBody [data-story]').forEach(row => row.addEventListener('click', () => openStoryViewer(row.dataset.story, false)));
}

let storyItems = [];
let storyIdx = 0;
let storyOwnerUid = null;
let storyIsMine = false;
async function openStoryViewer(uid, isMine) {
  let snap;
  try { snap = await getDocs(query(collection(db, 'statuses', uid, 'items'), orderBy('createdAt', 'asc'))); }
  catch (err) { toast('Could not load that status'); return; }
  const now = Date.now();
  storyItems = snap.docs.map(d => Object.assign({ id: d.id }, d.data())).filter(it => now - tsMillis(it.createdAt) < STATUS_EXPIRY_MS);
  if (isMine) snap.docs.forEach(d => { if (now - tsMillis(d.data().createdAt) >= STATUS_EXPIRY_MS) deleteDoc(d.ref).catch(() => {}); });
  if (!storyItems.length) { toast('No active status'); return; }
  storyOwnerUid = uid;
  storyIsMine = isMine;
  storyIdx = 0;
  byId('storyDeleteBtn').classList.toggle('hidden', !isMine);
  byId('storyReactBtn').classList.toggle('hidden', isMine);
  byId('storyViewer').classList.remove('hidden');
  playStorySlide();
}
function refreshReactUI(item) {
  const mine = !!(item.reactions && item.reactions[state.me?.uid]);
  byId('storyReactBtn').classList.toggle('reacted', mine);
  const count = item.reactions ? Object.keys(item.reactions).length : 0;
  byId('storyReactCount').textContent = count ? String(count) : '';
}
function playStorySlide() {
  clearTimeout(storyTimer);
  const item = storyItems[storyIdx];
  if (!item) { closeStoryViewer(); return; }
  const person = storyIsMine ? state.me : contacts[storyOwnerUid];
  setAvatar(byId('storyAvatar'), storyOwnerUid, person?.name || 'Me', 'av-sm');
  byId('storyName').textContent = storyIsMine ? 'My Status' : (contactNicknames[storyOwnerUid] || person?.name || 'Unknown');
  byId('storyTime').textContent = timeLabel(item.createdAt);
  byId('storyBody').innerHTML =
    (item.kind === 'video' ? `<video src="${safeMediaSrc(item.dataUrl, 'video')}" autoplay muted playsinline></video>` : `<img src="${safeMediaSrc(item.dataUrl, 'image')}" alt="">`)
    + '<div class="cap" id="storyCap"></div>';
  byId('storyCap').textContent = item.caption || '';
  byId('storyProgress').innerHTML = storyItems.map((s, i) =>
    `<div class="seg ${i < storyIdx ? 'done' : i === storyIdx ? 'active' : ''}"><i></i></div>`).join('');
  const activeI = $('#storyProgress .seg.active i');
  const durationMs = STATUS_SECONDS * 1000;
  if (activeI) requestAnimationFrame(() => { activeI.style.transitionDuration = durationMs + 'ms'; activeI.style.width = '100%'; });
  refreshReactUI(item);
  storyTimer = setTimeout(nextStorySlide, durationMs);
}
function nextStorySlide() {
  if (storyIdx < storyItems.length - 1) { storyIdx++; playStorySlide(); }
  else closeStoryViewer();
}
function prevStorySlide() {
  if (storyIdx > 0) { storyIdx--; playStorySlide(); }
  else playStorySlide();
}
function closeStoryViewer() { clearTimeout(storyTimer); byId('storyViewer').classList.add('hidden'); renderStatusList(); }
byId('storyTapNext').addEventListener('click', nextStorySlide);
byId('storyTapPrev').addEventListener('click', prevStorySlide);
byId('closeStory').addEventListener('click', closeStoryViewer);
byId('storyReactBtn').addEventListener('click', async () => {
  const item = storyItems[storyIdx];
  if (!item || storyIsMine) return;
  const mine = !!(item.reactions && item.reactions[state.me.uid]);
  const ref = doc(db, 'statuses', storyOwnerUid, 'items', item.id);
  try {
    if (mine) {
      delete item.reactions[state.me.uid];
      await updateDoc(ref, { [`reactions.${state.me.uid}`]: deleteField() });
    } else {
      item.reactions = item.reactions || {};
      item.reactions[state.me.uid] = true;
      await updateDoc(ref, { [`reactions.${state.me.uid}`]: true });
    }
    refreshReactUI(item);
  } catch (err) { toast('Could not react right now'); }
});
byId('storyDeleteBtn').addEventListener('click', () => {
  const item = storyItems[storyIdx];
  if (!item) return;
  confirmAction('Delete this status?', 'This removes it for everyone.', async () => {
    await deleteDoc(doc(db, 'statuses', state.me.uid, 'items', item.id));
    storyItems.splice(storyIdx, 1);
    if (!storyItems.length) closeStoryViewer();
    else { if (storyIdx >= storyItems.length) storyIdx = storyItems.length - 1; playStorySlide(); }
  }, 'Delete');
});

// ---------------------------------------------------------------------
// CALLS — LiveKit carries the audio/video, Firestore (calls/{id}) does the ringing.
// Needs the /api/livekit-token function + its 3 environment variables (see SETUP.md).
// ---------------------------------------------------------------------
const LK_SRC = 'https://cdn.jsdelivr.net/npm/livekit-client@2/dist/livekit-client.umd.min.js';
let lkPromise = null, unsubCalls = null;
function loadLiveKit() {
  if (window.LivekitClient) return Promise.resolve(window.LivekitClient);
  if (lkPromise) return lkPromise;
  lkPromise = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = LK_SRC; s.async = true;
    s.onload = () => (window.LivekitClient ? res(window.LivekitClient) : rej(new Error('lk')));
    s.onerror = () => { lkPromise = null; rej(new Error('load')); };
    document.head.appendChild(s);
  });
  return lkPromise;
}
const callSt = { id: null, peerId: null, kind: 'voice', role: null, room: null, unsub: null, startedAt: 0, timer: null, ring: null, ringTimeout: null, connected: false, muted: false, camOn: false, ended: false, accepted: false, chatId: null };
const CALL_DONE = ['ended', 'declined', 'missed', 'busy', 'cancelled'];
const callLogKey = () => 'velo:calls:' + (state.me ? state.me.uid : '');
function loadCallLog() {
  callLog.length = 0;
  try { callLog.push(...JSON.parse(localStorage.getItem(callLogKey()) || '[]')); } catch (e) {}
}
function addCallLog(entry) {
  callLog.unshift(entry); if (callLog.length > 60) callLog.length = 60;
  try { localStorage.setItem(callLogKey(), JSON.stringify(callLog)); } catch (e) {}
  renderCallsList();
}
function ringStart(kind) {
  ringStop();
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx(), gain = ctx.createGain();
    gain.gain.value = 0.06; gain.connect(ctx.destination);
    const beep = () => { const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = kind === 'in' ? 880 : 440; o.connect(gain); o.start(); o.stop(ctx.currentTime + 0.35); };
    beep();
    const iv = setInterval(() => { beep(); if (kind === 'in' && navigator.vibrate) navigator.vibrate([300, 150, 300]); }, 1800);
    callSt.ring = { ctx, iv };
  } catch (e) {}
}
function ringStop() { if (callSt.ring) { clearInterval(callSt.ring.iv); try { callSt.ring.ctx.close(); } catch (e) {} callSt.ring = null; } }
function paintCallPeer(peer) {
  const nm = contactNicknames[peer.id] || peer.name || 'Unknown';
  setAvatar(byId('callAvatar'), peer.id, peer.name || 'Unknown', 'av-lg');
  byId('callName').textContent = nm;
  byId('callNameSmall').textContent = nm;
}
function setCallUI(mode) {
  byId('callScreen').classList.remove('hidden');
  byId('callAcceptBtn').classList.toggle('hidden', mode !== 'incoming');
  byId('callMuteBtn').classList.toggle('hidden', mode === 'incoming');
  byId('callCamBtn').classList.toggle('hidden', mode === 'incoming');
  byId('callStatus').textContent = { outgoing: 'Calling…', incoming: 'Incoming ' + callSt.kind + ' call', connecting: 'Connecting…', live: callSt.kind === 'video' ? 'Video call' : 'Voice call' }[mode];
  byId('callTimer').classList.toggle('hidden', mode !== 'live');
  byId('callMuteBtn').classList.toggle('active', callSt.muted);
  byId('callCamBtn').classList.toggle('active', callSt.camOn);
}
function updateCallLayout() {
  const rem = byId('callRemote');
  const hasRemote = !!rem.querySelector('video');
  rem.classList.toggle('hidden', !hasRemote);
  byId('callScreen').classList.toggle('has-video', hasRemote);
  byId('callNameLine').classList.toggle('hidden', !(hasRemote && callSt.connected));
  byId('callLocal').classList.toggle('hidden', !callSt.camOn);
}
function markLive() {
  if (callSt.connected || callSt.ended) return;
  callSt.connected = true;
  ringStop(); clearTimeout(callSt.ringTimeout);
  callSt.startedAt = Date.now();
  setCallUI('live');
  const tick = () => { const t = fmtDur((Date.now() - callSt.startedAt) / 1000); byId('callTimer').textContent = t; byId('callTimerSmall').textContent = t; };
  tick(); callSt.timer = setInterval(tick, 1000);
  updateCallLayout();
}
function attachRemote(track) {
  if (track.kind === 'audio') {
    const el = track.attach(); byId('callAudio').appendChild(el);
    if (callSt.room && callSt.room.startAudio) callSt.room.startAudio().catch(() => {});
  } else if (track.kind === 'video') {
    const el = track.attach(); el.playsInline = true;
    byId('callRemote').innerHTML = ''; byId('callRemote').appendChild(el);
  }
  updateCallLayout();
}
async function setCam(on) {
  const room = callSt.room; if (!room) return;
  const lk = window.LivekitClient;
  await room.localParticipant.setCameraEnabled(on);
  callSt.camOn = on;
  if (on) { const pub = room.localParticipant.getTrackPublication(lk.Track.Source.Camera); if (pub && pub.track) pub.track.attach(byId('callLocal')); }
  byId('callCamBtn').classList.toggle('active', on);
  updateCallLayout();
}
async function joinRoom() {
  const lk = await loadLiveKit().catch(() => { throw new Error('Could not load the calling library — check your connection.'); });
  const idToken = await auth.currentUser.getIdToken();
  let res;
  try { res = await fetch('/api/livekit-token', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + idToken }, body: JSON.stringify({ callId: callSt.id, name: state.me.name }) }); }
  catch (e) { throw new Error("Can't reach the call server."); }
  if (!res.ok) { let msg = ''; try { msg = (await res.json()).error; } catch (e) {} throw new Error(msg || 'Call server error (' + res.status + ').'); }
  const { token, url } = await res.json();
  if (callSt.ended || !callSt.id) return;
  const room = new lk.Room({ adaptiveStream: true, dynacast: true, audioCaptureDefaults: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  callSt.room = room;
  room.on(lk.RoomEvent.TrackSubscribed, (track) => attachRemote(track));
  room.on(lk.RoomEvent.TrackUnsubscribed, (track) => { track.detach().forEach(el => el.remove()); updateCallLayout(); });
  room.on(lk.RoomEvent.ParticipantConnected, () => markLive());
  room.on(lk.RoomEvent.ParticipantDisconnected, () => { if (!callSt.ended) endCall('peer'); });
  room.on(lk.RoomEvent.Disconnected, () => { if (!callSt.ended && callSt.connected) endCall('lost'); });
  await room.connect(url, token);
  await room.localParticipant.setMicrophoneEnabled(true);
  if (callSt.kind === 'video') await setCam(true);
  if (room.remoteParticipants && room.remoteParticipants.size) markLive();
}
function handleCallError(err) {
  console.error('call:', err);
  const denied = err && (err.name === 'NotAllowedError' || /permission|denied/i.test(err.message || ''));
  toast(denied ? 'Allow microphone' + (callSt.kind === 'video' ? ' and camera' : '') + ' access to make calls.' : ((err && err.message) || 'The call could not connect.'));
  endCall('error');
}
function watchCallDoc(id) {
  if (callSt.unsub) callSt.unsub();
  callSt.unsub = onSnapshot(doc(db, 'calls', id), (snap) => {
    if (callSt.id !== id || callSt.ended) return;
    if (!snap.exists()) { endCall('remote', true); return; }
    const d = snap.data();
    if (d.status === 'active' && callSt.role === 'caller' && !callSt.connected) { ringStop(); clearTimeout(callSt.ringTimeout); setCallUI('connecting'); }
    if (CALL_DONE.includes(d.status)) {
      if (callSt.role === 'caller' && !callSt.connected) toast(d.status === 'busy' ? 'They are on another call' : d.status === 'declined' ? 'Call declined' : 'No answer');
      endCall('remote', true, d.status);
    }
  }, () => {});
}
async function startCall(contactId, kind = 'voice') {
  if (callSt.id || callSt.role) { toast('You are already in a call'); return; }
  const peer = contacts[contactId];
  if (!peer) { toast('Add this person as a contact first'); return; }
  if (isBlocked(contactId)) { toast('Unblock this contact to call them'); return; }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { toast("Calls aren't supported in this browser."); return; }
  const chat = Object.values(chats).find(c => !c.isGroup && (c.participants || []).includes(contactId));
  Object.assign(callSt, { id: null, peerId: contactId, kind, role: 'caller', room: null, connected: false, ended: false, muted: false, camOn: false, accepted: false, chatId: chat ? chat.id : null });
  paintCallPeer(peer); setCallUI('outgoing'); ringStart('out');
  let ref;
  try { ref = await addDoc(collection(db, 'calls'), { from: state.me.uid, fromName: state.me.name, to: contactId, participants: [state.me.uid, contactId], chatId: callSt.chatId, kind, status: 'ringing', createdAt: serverTimestamp() }); }
  catch (e) { console.error(e); toast('Could not start the call — check your connection.'); finishCall(); return; }
  callSt.id = ref.id;
  watchCallDoc(ref.id);
  callSt.ringTimeout = setTimeout(() => { if (!callSt.connected) { toast('No answer'); endCall('missed'); } }, 45000);
  joinRoom().catch(handleCallError);
}
function incomingCall(id, d) {
  if (isBlocked(d.from)) { updateDoc(doc(db, 'calls', id), { status: 'declined' }).catch(() => {}); return; }
  if (callSt.id || callSt.role) { updateDoc(doc(db, 'calls', id), { status: 'busy' }).catch(() => {}); return; }
  Object.assign(callSt, { id, peerId: d.from, kind: d.kind === 'video' ? 'video' : 'voice', role: 'callee', room: null, connected: false, ended: false, muted: false, camOn: false, accepted: false, chatId: d.chatId || null });
  const show = (peer) => {
    if (callSt.id !== id) return;
    paintCallPeer(peer); setCallUI('incoming'); ringStart('in');
    watchCallDoc(id);
    callSt.ringTimeout = setTimeout(() => { if (!callSt.accepted) endCall('missed', true); }, 45000);
    if (document.hidden && 'Notification' in window && Notification.permission === 'granted') { try { new Notification('Incoming ' + callSt.kind + ' call', { body: contactNicknames[peer.id] || peer.name, icon: 'mainimg.png', tag: 'velo-call' }); } catch (e) {} }
  };
  if (contacts[d.from]) show(contacts[d.from]);
  else getDoc(doc(db, 'veloUsers', d.from)).then(s => { const p = Object.assign({ id: d.from }, s.exists() ? s.data() : { name: d.fromName || 'Unknown' }); contacts[d.from] = p; show(p); }).catch(() => show({ id: d.from, name: d.fromName || 'Unknown' }));
}
function attachCallsListener() {
  if (unsubCalls) unsubCalls();
  unsubCalls = onSnapshot(query(collection(db, 'calls'), where('to', '==', state.me.uid)), (snap) => {
    snap.docChanges().forEach(ch => {
      if (ch.type !== 'added') return;
      const d = ch.doc.data();
      if (d.status === 'ringing' && Date.now() - tsMillis(d.createdAt) < 60000) incomingCall(ch.doc.id, d);
    });
  }, () => {});
}
byId('callAcceptBtn').addEventListener('click', async () => {
  if (callSt.role !== 'callee' || callSt.accepted) return;
  callSt.accepted = true;
  ringStop(); clearTimeout(callSt.ringTimeout);
  setCallUI('connecting');
  try { await updateDoc(doc(db, 'calls', callSt.id), { status: 'active', answeredAt: serverTimestamp() }); await joinRoom(); }
  catch (e) { handleCallError(e); }
});
function finishCall() {
  clearInterval(callSt.timer); clearTimeout(callSt.ringTimeout); ringStop();
  if (callSt.unsub) { callSt.unsub(); callSt.unsub = null; }
  const room = callSt.room;
  if (room) { try { room.disconnect(); } catch (e) {} }
  byId('callRemote').innerHTML = ''; byId('callAudio').innerHTML = '';
  const lv = byId('callLocal'); lv.srcObject = null;
  byId('callScreen').classList.add('hidden');
  byId('callScreen').classList.remove('has-video');
  Object.assign(callSt, { id: null, peerId: null, role: null, room: null, timer: null, ring: null, ringTimeout: null, connected: false, muted: false, camOn: false, ended: false, accepted: false, chatId: null, startedAt: 0 });
  byId('callMuteBtn').classList.remove('active'); byId('callCamBtn').classList.remove('active');
}
function endCall(reason, remote = false, remoteStatus = '') {
  if (callSt.ended) return;
  callSt.ended = true;
  const { id, role, peerId, kind, connected, accepted, chatId } = callSt;
  const secs = connected ? Math.round((Date.now() - callSt.startedAt) / 1000) : 0;
  let status = remoteStatus || 'ended';
  if (!remote) {
    if (reason === 'missed') status = 'missed';
    else if (role === 'callee' && !accepted) status = 'declined';
    else if (role === 'caller' && !connected) status = 'cancelled';
    if (id) updateDoc(doc(db, 'calls', id), { status }).catch(() => {});
  }
  if (peerId) {
    const type = role === 'caller' ? 'outgoing' : (accepted ? 'incoming' : 'missed');
    addCallLog({ contactId: peerId, type, kind, ts: Date.now(), duration: secs });
  }
  if (role === 'caller' && chatId && chats[chatId]) {
    const label = connected ? '📞 ' + (kind === 'video' ? 'Video' : 'Voice') + ' call · ' + fmtDur(secs)
      : (status === 'declined' ? 'Call declined' : status === 'busy' ? 'Call not answered (busy)' : 'Missed ' + kind + ' call');
    addDoc(collection(db, 'chats', chatId, 'messages'), { system: true, text: label, ts: serverTimestamp() }).catch(() => {});
  }
  if (connected) toast('Call ended · ' + fmtDur(secs));
  finishCall();
  if (role === 'caller' && id) setTimeout(() => deleteDoc(doc(db, 'calls', id)).catch(() => {}), 6000);   // tidy up once the other side has seen it
}
byId('callEndBtn').addEventListener('click', () => endCall('user'));
byId('callMuteBtn').addEventListener('click', async () => {
  const room = callSt.room; if (!room) return;
  callSt.muted = !callSt.muted;
  try { await room.localParticipant.setMicrophoneEnabled(!callSt.muted); } catch (e) { callSt.muted = !callSt.muted; }
  byId('callMuteBtn').classList.toggle('active', callSt.muted);
});
byId('callCamBtn').addEventListener('click', async () => {
  if (!callSt.room) return;
  try { await setCam(!callSt.camOn); } catch (e) { toast('Allow camera access to use video.'); }
});

// ---------------------------------------------------------------------
// channels — local-only for now (see file header)
// ---------------------------------------------------------------------
function renderChannelsList() {
  const body = byId('channelsListBody');
  if (!body) return;
  const rows = Object.values(channels);
  body.innerHTML = rows.length ? rows.map(ch => {
    const last = ch.posts[ch.posts.length - 1];
    return `
      <button class="channel-row" data-ch="${ch.id}">
        ${avatarHTML(ch.id, ch.name, 'av-sm')}
        <div class="mid">
          <div class="top-line"><span class="name">${escapeHTML(ch.name)}</span><span class="time">${last ? timeLabel(last.ts) : ''}</span></div>
          <div class="subs">${escapeHTML([ch.category, ch.isPublic === false ? 'Private' : (ch.category ? 'Public' : ''), ch.subs + ' subscriber' + (ch.subs === '1' ? '' : 's')].filter(Boolean).join(' · '))}</div>
        </div>
      </button>`;
  }).join('') : `<div class="empty-state"><div class="ic"><svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11a9 9 0 0 1 9-9"/><path d="M4 5a15 15 0 0 1 15 15"/><circle cx="5" cy="19" r="2"/></svg></div><h3>No channels yet</h3><div>Tap + to start your own, or search to follow one.</div></div>`;
  $$('#channelsListBody [data-ch]').forEach(b => b.addEventListener('click', () => openChannel(b.dataset.ch)));
}
function openChannel(id) {
  const ch = channels[id];
  if (!ch) return;
  state.currentChannelId = id;
  setAvatar(byId('channelFeedAvatar'), ch.id, ch.name, 'av-sm');
  byId('channelFeedName').textContent = ch.name;
  byId('channelFeedSubs').textContent = [ch.category, ch.category ? (ch.isPublic === false ? 'Private' : 'Public') : '', ch.subs + ' subscriber' + (ch.subs === '1' ? '' : 's')].filter(Boolean).join(' · ');
  byId('channelComposer').classList.toggle('hidden', !ch.owner);
  byId('channelReadOnlyNote').classList.toggle('hidden', !!ch.owner);
  renderChannelFeed();
  showScreen('screen-channel-feed');
}
function renderChannelFeed() {
  const ch = channels[state.currentChannelId];
  byId('channelFeedBody').innerHTML = ch.posts.length
    ? ch.posts.slice().reverse().map(p => `<div class="channel-post">${escapeHTML(p.text)}<div class="ptime">${timeLabel(p.ts)}</div></div>`).join('')
    : `<div class="empty-state"><h3>No posts yet</h3>${ch.about ? `<div>${escapeHTML(ch.about)}</div>` : ''}</div>`;
}
function saveChannels() {
  if (!state.me) return;
  try { localStorage.setItem('velo:channels:' + state.me.uid, JSON.stringify(channels)); } catch (e) {}
}
function loadChannels() {
  Object.keys(channels).forEach(k => delete channels[k]);
  if (!state.me) return;
  try { Object.assign(channels, JSON.parse(localStorage.getItem('velo:channels:' + state.me.uid) || '{}')); } catch (e) {}
}
const CH_CATEGORIES = ['News', 'Education', 'Entertainment', 'Technology', 'Sports', 'Business', 'Music', 'Lifestyle', 'Other'];
const CH_STEPS = [
  { key: 'name', q: 'What is your channel called?', hint: 'Pick a name people will remember (3–40 characters).', type: 'text', max: 40, placeholder: 'e.g. KS Tech Updates',
    valid: v => v.length >= 3 || 'Give your channel a name with at least 3 characters.' },
  { key: 'about', q: 'What is it about?', hint: 'One or two sentences so people know what to expect.', type: 'area', max: 200, placeholder: 'Daily tips, news and updates about…',
    valid: v => v.length >= 5 || 'Tell us a little about it (at least 5 characters).' },
  { key: 'category', q: 'Which category fits best?', hint: 'This helps people find your channel.', type: 'chips',
    valid: v => !!v || 'Pick a category.' },
  { key: 'visibility', q: 'Who can find your channel?', hint: 'You can post either way — this decides who can discover it.', type: 'cards',
    options: [{ v: 'public', t: 'Public', d: 'Anyone on Velo can find and follow it' }, { v: 'private', t: 'Private', d: 'Only people you invite can follow it' }],
    valid: v => !!v || 'Choose who can find it.' },
];
const cw = { step: 0, data: {} };
function renderCwStep() {
  const s = CH_STEPS[cw.step];
  byId('cwStep').textContent = 'Step ' + (cw.step + 1) + ' of ' + CH_STEPS.length;
  byId('cwBar').style.width = Math.round((cw.step + 1) / CH_STEPS.length * 100) + '%';
  byId('cwBack').textContent = cw.step === 0 ? 'Cancel' : 'Back';
  byId('cwNext').textContent = cw.step === CH_STEPS.length - 1 ? 'Create channel' : 'Next';
  let input = '';
  const cur = cw.data[s.key] || '';
  if (s.type === 'text') input = `<div class="field"><input id="cwInput" maxlength="${s.max}" placeholder="${escapeHTML(s.placeholder)}" value="${escapeHTML(cur)}" autocomplete="off"><span class="ac-count" id="cwCount">${cur.length}/${s.max}</span></div>`;
  else if (s.type === 'area') input = `<textarea class="cw-text" id="cwInput" maxlength="${s.max}" rows="4" placeholder="${escapeHTML(s.placeholder)}">${escapeHTML(cur)}</textarea><div class="cw-count" id="cwCount">${cur.length}/${s.max}</div>`;
  else if (s.type === 'chips') input = `<div class="cw-chips">${CH_CATEGORIES.map(x => `<button type="button" class="cw-chip ${cur === x ? 'on' : ''}" data-v="${x}">${x}</button>`).join('')}</div>`;
  else input = `<div class="cw-cards">${s.options.map(o => `<button type="button" class="cw-card ${cur === o.v ? 'on' : ''}" data-v="${o.v}"><b>${o.t}</b><span>${o.d}</span></button>`).join('')}</div>`;
  byId('cwBody').innerHTML = `<div class="cw-q">${s.q}</div><div class="cw-hint">${s.hint}</div>${input}<div class="cw-err" id="cwErr"></div>`;
  const inp = byId('cwInput');
  if (inp) {
    inp.addEventListener('input', () => { cw.data[s.key] = inp.value; byId('cwCount').textContent = inp.value.length + '/' + s.max; byId('cwErr').textContent = ''; });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter' && s.type === 'text') byId('cwNext').click(); });
    setTimeout(() => inp.focus(), 80);
  }
  $$('#cwBody [data-v]').forEach(b => b.addEventListener('click', () => {
    cw.data[s.key] = b.dataset.v;
    $$('#cwBody [data-v]').forEach(x => x.classList.toggle('on', x === b));
    byId('cwErr').textContent = '';
  }));
}
function openChannelWizard() { cw.step = 0; cw.data = {}; renderCwStep(); showModal('channelWizard'); }
byId('cwBack').addEventListener('click', () => { if (cw.step === 0) hideModal('channelWizard'); else { cw.step--; renderCwStep(); } });
byId('cwNext').addEventListener('click', () => {
  const s = CH_STEPS[cw.step];
  const val = String(cw.data[s.key] || '').trim();
  const res = s.valid(val);
  if (res !== true) { const e = byId('cwErr'); e.textContent = res; e.classList.remove('shake'); void e.offsetWidth; e.classList.add('shake'); return; }
  cw.data[s.key] = val;
  if (cw.step < CH_STEPS.length - 1) { cw.step++; renderCwStep(); return; }
  const id = 'ch-' + Date.now();
  channels[id] = { id, name: cw.data.name, about: cw.data.about, category: cw.data.category, isPublic: cw.data.visibility === 'public', subs: '1', owner: true, posts: [], createdAt: Date.now() };
  saveChannels();
  hideModal('channelWizard');
  renderChannelsList();
  toast('Channel created — you can post updates now');
  openChannel(id);
});
function createChannel() { openChannelWizard(); }
byId('createChannelBtn').addEventListener('click', createChannel);
byId('channelSendBtn').addEventListener('click', () => {
  const text = byId('channelMsgInput').value.trim();
  if (!text) return;
  channels[state.currentChannelId].posts.push({ text, ts: Date.now() });
  saveChannels();
  byId('channelMsgInput').value = '';
  renderChannelFeed();
  renderChannelsList();
});
byId('channelFeedBack').addEventListener('click', () => goBack('screen-channels'));
byId('channelsBack').addEventListener('click', () => goBack('screen-main'));

// ---------------------------------------------------------------------
// chat conversation — real-time messages via Firestore
// ---------------------------------------------------------------------
function findMsg(chatId, msgId) { return chats[chatId]?.messages.find(m => m.id === msgId); }
function ticksHTML(st, animate) {
  const one = '<svg viewBox="3 4 18 16" aria-label="Sent"><path class="t1" d="m5 12 5 5L18 6"/></svg>';
  const two = '<svg viewBox="1 4 24 16" aria-label="' + (st === 'read' ? 'Seen' : 'Delivered') + '"><path class="t1" d="m2 12 5 5L13 6"/><path class="t2" d="m8 12 5 5L24 6"/></svg>';
  return '<span class="ticks ' + st + (animate ? ' pop' : '') + '">' + (st === 'sent' ? one : two) + '</span>';
}
function waveformBars(seedLen) {
  let out = '';
  for (let i = 0; i < 24; i++) {
    const h = 4 + Math.round(Math.abs(Math.sin(i * (seedLen || 7))) * 14);
    out += `<span style="height:${h}px"></span>`;
  }
  return out;
}
function bubbleRowHTML(m) {
  if (m.system) return `<div class="bubble system">${escapeHTML(m.text)}</div>`;
  const out = m.from === state.me.uid;
  const quoteHTML = m.replyTo
    ? `<div class="quote"><div class="qn">${escapeHTML(m.replyTo.sender)}</div><div class="qt">${escapeHTML(m.replyTo.text)}</div></div>` : '';
  let bodyHTML, bubbleClass = 'bubble';
  if (m.kind === 'image') {
    bubbleClass += ' img-bubble';
    bodyHTML = `<img src="${safeMediaSrc(m.imgSrc, 'image')}" alt="photo">${m.text ? `<div class="cap">${formatMessageHTML(m.text)}</div>` : ''}`;
  } else if (m.kind === 'poll') {
    bubbleClass += ' poll-bubble';
    bodyHTML = pollHTML(m);
  } else if (m.kind === 'voice') {
    bubbleClass += ' voice-b';
    bodyHTML = voiceHTML(m);
  } else {
    bodyHTML = formatMessageHTML(m.text || '');
  }
  let tk = '';
  if (out) {
    const st = tickState(chats[state.currentChatId], m);
    const prev = tickPrev[m.id];
    if (prev !== st) { tickPrev[m.id] = st; if (prev || Date.now() - m.ts < 5000) tickAnimUntil[m.id] = Date.now() + 900; }
    tk = ticksHTML(st, (tickAnimUntil[m.id] || 0) > Date.now());
  }
  const meta = `<div class="meta">${m.imported ? 'Imported · ' : ''}${m.forwarded ? 'Forwarded · ' : ''}${m.edited ? 'Edited · ' : ''}${bubbleTime(m.ts)} ${tk}</div>`;
  const reaction = m.reaction ? `<div class="reaction-chip" data-msg="${m.id}">${m.reaction}</div>` : '';
  return `<div class="bubble-row ${out ? 'out' : 'in'}${m._fresh ? ' fresh' : ''}${m._first ? ' first' : ''}${m._i != null ? ' imp-in' : ''}" data-msg="${m.id}"${m._i != null ? ` style="--i:${m._i}"` : ''}>
      <div class="bubble-wrap"><div class="${bubbleClass}">${quoteHTML}${bodyHTML}${meta}</div>${reaction}</div>
    </div>`;
}
function isNearBottom() {
  const body = byId('threadBody');
  if (!body || !body.scrollHeight) return true;
  return body.scrollHeight - body.scrollTop - body.clientHeight < 160;
}
function updateScrollFab() {
  byId('scrollFab').classList.toggle('show', !isNearBottom());
  const n = byId('scrollFabN');
  if (state.unseenInThread > 0) { n.textContent = state.unseenInThread; n.classList.remove('hidden'); }
  else n.classList.add('hidden');
}
byId('threadBody').addEventListener('scroll', () => {
  updateScrollFab();
  if (isNearBottom()) { state.unseenInThread = 0; byId('scrollFabN').classList.add('hidden'); }
});
byId('scrollFab').addEventListener('click', () => {
  const body = byId('threadBody');
  body.scrollTop = body.scrollHeight;
  state.unseenInThread = 0;
  updateScrollFab();
});
function bindBubbleInteractions() {
  $$('#threadBody .bubble-row[data-msg]').forEach(row => {
    bindLongPress(row, () => openMsgActionSheet(state.currentChatId, row.dataset.msg), null);
  });
  $$('#threadBody .reaction-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const msg = findMsg(state.currentChatId, chip.dataset.msg);
      if (msg) { msg.reaction = null; renderThread(); }
    });
  });
  $$('#threadBody .poll-opt').forEach(btn => btn.addEventListener('click', () => votePoll(btn.dataset.poll, Number(btn.dataset.opt))));
  bindThreadExtras();
  const lock = byId('e2eNotice');
  if (lock) lock.addEventListener('click', () => toast('Velo uses end-to-end encryption, so only you and the recipient can read messages.'));
}
function dayLabel(ts) {
  const d = new Date(ts), now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
}
function threadBodyHTML(chat) {
  const anim = state.impAnim && Date.now() < state.impAnim.until ? state.impAnim.ids : null;
  let lastDay = '', out = '', n = 0, prevFrom = null;
  const seen = state.renderedIds[chat.id] || (state.renderedIds[chat.id] = new Set());
  const firstRender = seen.size === 0;
  for (const m of chat.messages) {
    if (!m.system && isBlocked(m.from)) continue;
    const day = new Date(m.ts).toDateString();
    if (day !== lastDay) { lastDay = day; prevFrom = null; out += `<div class="day-sep">${dayLabel(m.ts)}</div>`; }
    m._i = (anim && anim.has(m.id)) ? n++ : null;
    m._fresh = !firstRender && !seen.has(m.id) && !m.system;
    m._first = !m.system && m.from !== prevFrom;
    prevFrom = m.system ? null : m.from;
    seen.add(m.id);
    out += bubbleRowHTML(m);
  }
  return out;
}
function pollHTML(m) {
  const opts = m.options || [], votes = m.votes || {};
  const total = Object.keys(votes).length, mine = votes[state.me.uid];
  return `<div class="poll"><div class="poll-q">📊 ${escapeHTML(m.question || '')}</div>` + opts.map((o, i) => {
    const c = Object.values(votes).filter(v => v === i).length;
    const pct = total ? Math.round(c * 100 / total) : 0;
    return `<button class="poll-opt ${mine === i ? 'mine' : ''}" data-poll="${m.id}" data-opt="${i}"><span class="fill" style="width:${pct}%"></span><span class="lbl">${escapeHTML(o)}</span><span class="pct">${c}</span></button>`;
  }).join('') + `<div class="poll-foot">${total} vote${total === 1 ? '' : 's'}</div></div>`;
}
async function votePoll(msgId, idx) {
  const chatId = state.currentChatId, msg = findMsg(chatId, msgId);
  if (!msg) return;
  const mine = msg.votes && msg.votes[state.me.uid];
  try {
    await updateDoc(doc(db, 'chats', chatId, 'messages', msgId), { ['votes.' + state.me.uid]: mine === idx ? deleteField() : idx });
  } catch (err) { console.error(err); toast('Could not register your vote.'); }
}
function renderThread(opts = {}) {
  const { showTyping = !!state.peerTyping[state.currentChatId], forceScroll = false } = opts;
  const chat = chats[state.currentChatId];
  const body = byId('threadBody');
  if (!chat) { body.innerHTML = ''; return; }
  const wasNearBottom = isNearBottom();
  let html = `<div class="bubble system lock" id="e2eNotice"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M7 10V7a5 5 0 0 1 10 0v3"/></svg>Messages here are end-to-end encrypted. Tap to learn more.</div>`;
  if (!chat.messages.length) html += `<div class="bubble system">No messages yet — say hello 👋</div>`;
  else html += threadBodyHTML(chat);
  if (showTyping) html += `<div class="bubble-row in"><div class="bubble-wrap"><div class="bubble typing"><div class="typing-dots"><span></span><span></span><span></span></div></div></div></div>`;
  body.innerHTML = html;
  if (forceScroll || wasNearBottom) body.scrollTop = body.scrollHeight;
  bindBubbleInteractions();
  updateScrollFab();
}
function refreshChatHeader(chatId) {
  const chat = chats[chatId];
  if (!chat) return;
  const name = chatDisplayName(chat);
  setAvatar(byId('chatHeaderAvatar'), chatId, name, 'av-sm');
  byId('chatHeaderName').textContent = name;
  setHeaderStatus(chat);
}
async function markIncomingAsRead(chatId) {
  const chat = chats[chatId];
  if (!chat || !state.me) return;
  const unread = chat.messages.filter(m => !m.system && m.from !== state.me.uid && m.status !== 'read');
  for (const m of unread) {
    try { await updateDoc(doc(db, 'chats', chatId, 'messages', m.id), { status: 'read' }); } catch (e) {}
  }
  if (unreadCount(chat) > 0) {
    updateDoc(doc(db, 'chats', chatId), { ['unreadBy.' + state.me.uid]: 0 }).catch(() => {});
    chat.unreadBy = Object.assign({}, chat.unreadBy, { [state.me.uid]: 0 });
  }
}
function attachMessagesListener(chatId) {
  if (unsubMessages) unsubMessages();
  let firstSnap = true;
  const q = query(collection(db, 'chats', chatId, 'messages'), orderBy('ts', 'asc'), limitToLast(1500));
  unsubMessages = onSnapshot(q, (snap) => {
    const chat = chats[chatId];
    if (!chat) return;
    let msgs = snap.docs.map(d => Object.assign({ id: d.id }, d.data(), { ts: tsMillis(d.data().ts) }));
    if (chat.disappearMs) {
      const cutoff = Date.now() - chat.disappearMs;
      msgs.filter(m => !m.system && m.ts < cutoff).slice(0, 40).forEach(m => deleteDoc(doc(db, 'chats', chatId, 'messages', m.id)).catch(() => {}));
      msgs = msgs.filter(m => m.system || m.ts >= cutoff);
    }
    chat.messages = msgs;
    chat._preloaded = true;
    if (state.currentChatId === chatId) {
      renderThread({ forceScroll: firstSnap });
      markIncomingAsRead(chatId);
    }
    firstSnap = false;
    renderChatList(byId('chatSearch').value);
  }, (err) => console.error(err));
}
let typingDebounce = null;
function setTypingState(chatId, isTyping) {
  if (!chatId || !state.me) return;
  setDoc(doc(db, 'chats', chatId, 'typing', state.me.uid), { typing: isTyping, ts: serverTimestamp() }, { merge: true }).catch(() => {});
}
let typingClear = null;
function attachTypingListener(chatId) {
  if (unsubTyping) unsubTyping();
  unsubTyping = onSnapshot(collection(db, 'chats', chatId, 'typing'), (snap) => {
    if (state.currentChatId !== chatId) return;
    const now = Date.now();
    const typing = snap.docs.some(d => d.id !== state.me.uid && d.data().typing && now - tsOrZero(d.data().ts || now) < 8000);
    const was = !!state.peerTyping[chatId];
    state.peerTyping[chatId] = typing;
    clearTimeout(typingClear);
    if (typing) typingClear = setTimeout(() => { state.peerTyping[chatId] = false; if (state.currentChatId === chatId) { setHeaderStatus(chats[chatId]); renderThread(); } }, 8000);
    if (chats[chatId]) setHeaderStatus(chats[chatId]);
    if (typing !== was) renderThread({ showTyping: typing });
  }, () => {});
}
function openChat(chatId) {
  if (!chatId) return;
  let chat = chats[chatId];
  if (!chat) chat = chats[chatId] = { id: chatId, participants: [], isGroup: false, messages: [], pinned: false, muted: false, archived: false, unreadBy: {} };
  state.currentChatId = chatId;
  state.unseenInThread = 0;
  state.renderedIds[chatId] = new Set();
  if (state.editing && state.editing.chatId !== chatId) cancelEdit();
  applyWallpaper(chatId);
  paintSchedBar();
  refreshChatHeader(chatId);
  state.replyTarget = null;
  byId('replyPreview').classList.add('hidden');
  updateSendButton();
  renderThread({ forceScroll: true });
  attachMessagesListener(chatId);
  attachTypingListener(chatId);
  markIncomingAsRead(chatId);
  renderChatList(byId('chatSearch').value);
  showScreen('screen-chat');
}
byId('chatBack').addEventListener('click', () => goBack('screen-main'));
byId('chatHeaderInfo').addEventListener('click', () => openProfile(state.currentChatId, 'screen-chat'));
byId('chatHeaderAvatar').addEventListener('click', () => openProfile(state.currentChatId, 'screen-chat'));
byId('openChatMenu').addEventListener('click', () => openProfile(state.currentChatId, 'screen-chat'));
function callFromChat(kind) {
  const chat = chats[state.currentChatId];
  const other = chat ? otherParticipant(chat) : null;
  if (other) startCall(other.id, kind); else toast('Calls work in one-to-one chats');
}
byId('startVoiceCall').addEventListener('click', () => callFromChat('voice'));
byId('startVideoCall').addEventListener('click', () => callFromChat('video'));

async function sendMessage() {
  const input = byId('msgInput');
  const text = input.value.trim();
  const chatId = state.currentChatId;
  if (!text || !chatId) return;
  if (state.editing) { await saveEdit(text); return; }
  const chat = chats[chatId];
  const peer = chat && !chat.isGroup ? otherParticipant(chat) : null;
  if (peer && isBlocked(peer.id)) { toast('Unblock this contact to send messages'); return; }
  input.value = '';
  updateSendButton();
  const sb = byId('sendMsgBtn'); sb.classList.remove('fly'); void sb.offsetWidth; sb.classList.add('fly'); setTimeout(() => sb.classList.remove('fly'), 600);
  const msgData = { from: state.me.uid, text, ts: serverTimestamp(), status: 'sent' };
  if (state.replyTarget) { msgData.replyTo = state.replyTarget; state.replyTarget = null; byId('replyPreview').classList.add('hidden'); }
  try {
    await addDoc(collection(db, 'chats', chatId, 'messages'), msgData);
    const updates = { lastMessage: { text, ts: serverTimestamp(), from: state.me.uid } };
    (chat.participants || []).filter(p => p !== state.me.uid).forEach(uid => { updates['unreadBy.' + uid] = increment(1); });
    await updateDoc(doc(db, 'chats', chatId), updates);
  } catch (err) {
    console.error(err);
    toast('Message failed to send — check your connection.');
  }
  setTypingState(chatId, false);
}
function updateSendButton() {
  const hasText = byId('msgInput').value.trim().length > 0;
  byId('sendMsgBtn').classList.toggle('mic-btn', !hasText);
  byId('sendBtnIcon').innerHTML = hasText
    ? '<path d="m22 2-11 11M22 2l-7 20-4-9-9-4Z"/>'
    : '<path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Z"/><path d="M19 11a7 7 0 0 1-14 0M12 18v3"/>';
}
byId('msgInput').addEventListener('input', () => {
  updateSendButton();
  if (!state.currentChatId) return;
  setTypingState(state.currentChatId, true);
  clearTimeout(typingDebounce);
  typingDebounce = setTimeout(() => setTypingState(state.currentChatId, false), 2500);
});
byId('msgInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMessage(); });


async function sendRichMessage(fields, preview) {
  const chatId = state.currentChatId, chat = chats[chatId];
  if (!chat) return false;
  const peer = !chat.isGroup ? otherParticipant(chat) : null;
  if (peer && isBlocked(peer.id)) { toast('Unblock this contact to send messages'); return false; }
  try {
    await addDoc(collection(db, 'chats', chatId, 'messages'), Object.assign({ from: state.me.uid, ts: serverTimestamp(), status: 'sent' }, fields));
    const updates = { lastMessage: { text: preview, ts: serverTimestamp(), from: state.me.uid } };
    (chat.participants || []).filter(p => p !== state.me.uid).forEach(uid => { updates['unreadBy.' + uid] = increment(1); });
    await updateDoc(doc(db, 'chats', chatId), updates);
    return true;
  } catch (err) { console.error(err); toast('Could not send — check your connection.'); return false; }
}
byId('imageFileInput').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file || !state.currentChatId) return;
  try {
    const dataUrl = await compressImageToDataURL(file, 1100, 0.7);
    if (dataUrl.length > 900 * 1024) { toast('That photo is still too large after compression — try a smaller one.'); return; }
    if (await sendRichMessage({ kind: 'image', imgSrc: dataUrl, text: '' }, '📷 Photo')) toast('Photo sent');
  } catch (err) { console.error(err); toast('Could not read that photo.'); }
});

// ---------------------------------------------------------------------
// message action sheet: reply / forward / copy / star / react / delete
// ---------------------------------------------------------------------
function openMsgActionSheet(chatId, msgId) {
  state.longPressMsg = { chatId, msgId };
  const msg = findMsg(chatId, msgId);
  if (!msg || msg.system) return;
  byId('actStarLabel').textContent = msg.starred ? 'Unstar' : 'Star';
  byId('actEdit').classList.toggle('hidden', !(msg.from === state.me.uid && !msg.kind));
  openSheetById('msgActionSheet');
}
$$('#reactRow button').forEach(b => b.addEventListener('click', () => {
  if (!state.longPressMsg) return;
  const { chatId, msgId } = state.longPressMsg;
  const msg = findMsg(chatId, msgId);
  if (msg) msg.reaction = (msg.reaction === b.dataset.emoji) ? null : b.dataset.emoji;
  closeOpenSheet();
  renderThread();
}));
byId('actReply').addEventListener('click', () => {
  if (!state.longPressMsg) return;
  const { chatId, msgId } = state.longPressMsg;
  const msg = findMsg(chatId, msgId);
  const senderName = msg.from === state.me.uid ? (state.me?.name || 'You') : chatDisplayName(chats[chatId]);
  state.replyTarget = { sender: senderName, text: previewText(msg) };
  byId('replyPreviewName').textContent = 'Replying to ' + state.replyTarget.sender;
  byId('replyPreviewText').textContent = state.replyTarget.text;
  byId('replyPreview').classList.remove('hidden');
  closeOpenSheet();
  byId('msgInput').focus();
});
byId('cancelReply').addEventListener('click', () => { state.replyTarget = null; byId('replyPreview').classList.add('hidden'); });
byId('actForward').addEventListener('click', () => {
  if (!state.longPressMsg) return;
  const { chatId, msgId } = state.longPressMsg;
  state.forwardMessage = findMsg(chatId, msgId);
  closeOpenSheet();
  openNewChatModal('forward');
});
byId('actCopy').addEventListener('click', () => {
  if (!state.longPressMsg) return;
  const { chatId, msgId } = state.longPressMsg;
  const msg = findMsg(chatId, msgId);
  if (navigator.clipboard?.writeText) navigator.clipboard.writeText(msg.text || '').catch(() => {});
  closeOpenSheet();
  toast('Copied');
});
byId('actStar').addEventListener('click', () => {
  if (!state.longPressMsg) return;
  const { chatId, msgId } = state.longPressMsg;
  const msg = findMsg(chatId, msgId);
  msg.starred = !msg.starred;
  closeOpenSheet();
  renderThread();
  toast(msg.starred ? 'Added to Starred Messages' : 'Removed from Starred Messages');
});
byId('actDelete').addEventListener('click', () => {
  if (!state.longPressMsg) return;
  const { chatId, msgId } = state.longPressMsg;
  closeOpenSheet();
  confirmAction('Delete message?', 'This removes it for everyone in the chat.', async () => {
    try { await deleteDoc(doc(db, 'chats', chatId, 'messages', msgId)); }
    catch (err) { console.error(err); toast('Could not delete — check your connection.'); }
  });
});

// ---------------------------------------------------------------------
// friend profile
// ---------------------------------------------------------------------
function openProfile(chatId, returnScreen) {
  if (!chatId) return;
  const chat = chats[chatId];
  if (!chat) return;
  const c = otherParticipant(chat);
  state.currentProfileId = chatId;
  state.profileReturnScreen = returnScreen || 'screen-main';
  const name = chatDisplayName(chat);
  setAvatar(byId('profileAvatar'), chatId, name, 'av-lg');
  byId('profileName').textContent = name;
  byId('profileUsername').textContent = (c && c.username) ? '@' + c.username : '';
  const unRow = byId('profileUsername').closest('.info-row'); if (unRow) unRow.classList.toggle('hidden', !(c && c.username));
  byId('profilePhone').textContent = c ? c.veloId : '';
  const bioRow = byId('profileBioRow');
  bioRow.classList.toggle('hidden', !(c && c.bio));
  byId('profileBio').textContent = (c && c.bio) || '';
  byId('profileNameRow').classList.toggle('editable', !chat.isGroup);
  paintProfileStatus(chat);
  byId('profileGroupName').textContent = name;
  syncProfileExtras(chat);
  showScreen('screen-profile');
}
byId('profileBack').addEventListener('click', () => goBack(state.profileReturnScreen));
byId('profileCreateGroup').addEventListener('click', () => {
  const other = otherParticipant(chats[state.currentProfileId]);
  openGroupModal(other?.id);
});
function callFromProfile(kind) {
  const chat = chats[state.currentProfileId], other = chat && otherParticipant(chat);
  if (other) startCall(other.id, kind); else toast('Calls work in one-to-one chats');
}
byId('profileVoiceCall').addEventListener('click', () => callFromProfile('voice'));
byId('profileVideoCall').addEventListener('click', () => callFromProfile('video'));
byId('profileOpenChat').addEventListener('click', () => openChat(state.currentProfileId));
byId('profileDelete').addEventListener('click', () => {
  const chatId = state.currentProfileId;
  const name = chatDisplayName(chats[chatId]);
  confirmAction(chats[chatId] && chats[chatId].isNote ? 'Delete My Note?' : 'Delete this chat?', chats[chatId] && chats[chatId].isNote ? 'Your saved notes will be removed.' : `This removes "${name}" and your conversation for both of you.`, async () => {
    try { markNoteDismissed(chats[chatId]); await deleteDoc(doc(db, 'chats', chatId)); delete chats[chatId]; if (state.currentChatId === chatId) state.currentChatId = null; toast('Chat deleted'); renderChatList(); showScreen(isDesktop() ? 'screen-empty' : 'screen-main'); }
    catch (err) { console.error(err); toast('Could not delete — check your connection.'); }
  });
});

// ---------------------------------------------------------------------
// edit modal (bio, friend's name) + profile photo
// ---------------------------------------------------------------------
let editCfg = null;
function openEditModal(cfg) {
  editCfg = cfg;
  byId('editTitle').textContent = cfg.title;
  byId('editHint').textContent = cfg.hint || '';
  const inp = byId('editInput');
  inp.value = cfg.value || ''; inp.placeholder = cfg.placeholder || ''; inp.maxLength = cfg.max || 60;
  byId('editCount').textContent = inp.value.length + '/' + inp.maxLength;
  byId('editReset').classList.toggle('hidden', !cfg.resetLabel);
  if (cfg.resetLabel) byId('editReset').textContent = cfg.resetLabel;
  showModal('editModal');
  setTimeout(() => { inp.focus(); inp.select(); }, 80);
}
byId('editInput').addEventListener('input', (e) => { byId('editCount').textContent = e.target.value.length + '/' + e.target.maxLength; });
byId('editInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') byId('editSave').click(); });
byId('editCancel').addEventListener('click', () => hideModal('editModal'));
byId('editReset').addEventListener('click', async () => { const cfg = editCfg; hideModal('editModal'); if (cfg && cfg.onReset) await cfg.onReset(); });
byId('editSave').addEventListener('click', async () => {
  const cfg = editCfg; if (!cfg) return;
  const v = byId('editInput').value.trim();
  if (!v && !cfg.allowEmpty) { toast('Please type something first'); return; }
  setBtnLoading(byId('editSave'), true);
  try { await cfg.onSave(v); hideModal('editModal'); }
  catch (err) { console.error(err); toast('Could not save — check your connection.'); }
  finally { setBtnLoading(byId('editSave'), false); }
});

// friend's name (only you see it)
function editFriendName() {
  const chat = chats[state.currentProfileId], peer = chat && otherParticipant(chat);
  if (!peer) { toast('Group names can be changed from the group settings'); return; }
  const refresh = () => {
    renderChatList(byId('chatSearch').value);
    openProfile(chat.id, state.profileReturnScreen);
    if (state.currentChatId === chat.id) refreshChatHeader(chat.id);
  };
  openEditModal({
    title: 'Edit name', value: chatDisplayName(chat), max: 40, placeholder: 'First and last name',
    hint: "Only you see this name. Their own Velo name stays ‘" + (peer.name || 'Unknown') + "’.",
    resetLabel: contactNicknames[peer.id] ? 'Use their Velo name' : '',
    onSave: async (v) => { setContactNickname(peer.id, v); refresh(); toast('Name updated'); },
    onReset: async () => { setContactNickname(peer.id, ''); refresh(); toast('Name reset'); },
  });
}
byId('profileNameRow').addEventListener('click', editFriendName);

// my bio
function paintMyBio() {
  const el = byId('acctBio'); if (!el || !state.me) return;
  el.textContent = state.me.bio || 'Add a short bio';
  el.classList.toggle('empty', !state.me.bio);
}
byId('acctBio').addEventListener('click', () => openEditModal({
  title: 'About / Bio', value: state.me.bio || '', max: 140, allowEmpty: true, placeholder: 'Tell your friends about you',
  hint: 'Your friends see this on your profile.',
  onSave: async (v) => { await updateDoc(doc(db, 'veloUsers', state.me.uid), { bio: v }); state.me.bio = v; paintMyBio(); toast('Bio saved'); },
}));

// my photo: centre-crop to a small square so it fits in the user document
async function squarePhoto(file, size = 256, quality = 0.8) {
  const bmp = await loadBitmap(file);
  const bw = bmp.width || bmp.naturalWidth, bh = bmp.height || bmp.naturalHeight;
  const side = Math.min(bw, bh);
  const cv = document.createElement('canvas'); cv.width = cv.height = size;
  cv.getContext('2d').drawImage(bmp, (bw - side) / 2, (bh - side) / 2, side, side, 0, 0, size, size);
  return cv.toDataURL('image/jpeg', quality);
}
async function saveMyPhoto(dataUrl) {
  await updateDoc(doc(db, 'veloUsers', state.me.uid), dataUrl ? { photo: dataUrl } : { photo: deleteField() });
  if (dataUrl) state.me.photo = dataUrl; else delete state.me.photo;
  renderAccountScreen(); renderChatList(byId('chatSearch').value); renderStatusList();
}
byId('acctAvatarWrap').addEventListener('click', () => byId('photoFileInput').click());
byId('photoFileInput').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  if (!/^image\//.test(f.type)) { toast('Please choose an image'); return; }
  const url = await openCropper(f, { aspect: 1, outW: 320, outH: 320, circle: true, quality: 0.82, title: 'Crop profile photo' });
  if (!url) return;
  try { await saveMyPhoto(url); toast('Profile photo updated'); }
  catch (err) { console.error(err); toast('Could not use that photo — try another.'); }
});
byId('acctPhotoRemove').addEventListener('click', async () => {
  try { await saveMyPhoto(''); toast('Profile photo removed'); } catch (err) { console.error(err); toast('Could not remove the photo.'); }
});

// =====================================================================
// v3 FEATURES — presence, ticks, typing, edit, schedule, voice notes,
// wallpapers, crop & adjust, image viewer, swipe-to-reply
// =====================================================================
const tsOrZero = (t) => (t && typeof t.toMillis === 'function') ? t.toMillis() : (typeof t === 'number' ? t : 0);
const mapMsgDoc = (d) => Object.assign({ id: d.id }, d.data(), { ts: tsMillis(d.data().ts) });
const fmtDur = (s) => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

// ---------- messages are loaded while the splash screen shows ----------
async function preloadMessages(chatId) {
  const chat = chats[chatId];
  if (!chat) return;
  try {
    const snap = await getDocs(query(collection(db, 'chats', chatId, 'messages'), orderBy('ts', 'asc'), limitToLast(60)));
    let msgs = snap.docs.map(mapMsgDoc);
    if (chat.disappearMs) { const cutoff = Date.now() - chat.disappearMs; msgs = msgs.filter(m => m.system || m.ts >= cutoff); }
    chat.messages = msgs;
    chat._preloaded = true;
  } catch (e) { console.error('preload', e); }
}

// ---------- delivered receipts: the receiver's app stamps the chat when it has the message ----------
const deliverMarked = {};
function markDelivered(chatId, data) {
  const lm = data.lastMessage;
  if (!lm || !state.me || lm.from === state.me.uid) return;
  if (!((data.unreadBy || {})[state.me.uid] > 0)) return;
  const lmTs = tsOrZero(lm.ts);
  if (!lmTs || deliverMarked[chatId] === lmTs) return;
  if (tsOrZero((data.deliveredAt || {})[state.me.uid]) >= lmTs) return;
  deliverMarked[chatId] = lmTs;
  updateDoc(doc(db, 'chats', chatId), { ['deliveredAt.' + state.me.uid]: serverTimestamp() }).catch(() => {});
}
const tickPrev = {}, tickAnimUntil = {};
function tickState(chat, m) {
  if (m.status === 'read') return 'read';
  if (!chat) return 'sent';
  const others = (chat.participants || []).filter(p => p !== state.me.uid);
  if (!others.length) return 'delivered';
  const da = chat.deliveredAt || {};
  return others.every(p => tsOrZero(da[p]) >= m.ts) ? 'delivered' : 'sent';
}

// ---------- online / last seen ----------
let presenceTimer = null;
function seenHidden() { return localStorage.getItem('velo:toggleLastSeen') === '0'; }
function presenceWrite(online) {
  if (!state.me || !state.me.uid) return;
  const data = seenHidden() ? { online: false, hideSeen: true } : { online, lastSeen: serverTimestamp(), hideSeen: false };
  updateDoc(doc(db, 'veloUsers', state.me.uid), data).catch(() => {});
}
function stopPresence() { clearInterval(presenceTimer); presenceTimer = null; }
function startPresence() {
  stopPresence();
  presenceWrite(!document.hidden);
  presenceTimer = setInterval(() => { if (!document.hidden) presenceWrite(true); }, 45000);
}
document.addEventListener('visibilitychange', () => {
  if (!state.me || !presenceTimer) return;
  presenceWrite(!document.hidden);
  if (!document.hidden) checkScheduled();
});
window.addEventListener('pagehide', () => { if (state.me && presenceTimer) presenceWrite(false); });
function presenceInfo(c) {
  if (!c || c.hideSeen || !c.lastSeen) return null;
  const ls = tsOrZero(c.lastSeen) || Date.now();
  if (c.online && Date.now() - ls < 110000) return { online: true, text: 'online' };
  const d = new Date(ls), now = new Date();
  const t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (d.toDateString() === now.toDateString()) return { online: false, text: 'last seen today at ' + t };
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return { online: false, text: 'last seen yesterday at ' + t };
  return { online: false, text: 'last seen ' + d.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ' at ' + t };
}
function setHeaderStatus(chat) {
  const el = byId('chatHeaderStatus');
  el.classList.remove('typing', 'online');
  if (chat.isGroup) { el.textContent = chat.isNote ? 'Only you' : ((chat.participants || []).length + ' members'); return; }
  if (state.peerTyping[chat.id]) { el.innerHTML = 'typing<span class="tdots"><i></i><i></i><i></i></span>'; el.classList.add('typing'); return; }
  const o = otherParticipant(chat), p = presenceInfo(o);
  if (p) { el.textContent = p.text; if (p.online) el.classList.add('online'); }
  else el.textContent = 'Velo ID ' + ((o && o.veloId) || '');
}
function paintProfileStatus(chat) {
  const el = byId('profileLastSeen');
  el.classList.remove('online');
  if (chat.isGroup) { el.textContent = chat.isNote ? 'Only you can see this chat' : (chat.participants.length + ' members'); return; }
  const p = presenceInfo(otherParticipant(chat));
  if (p) { el.textContent = p.online ? 'Online' : p.text.charAt(0).toUpperCase() + p.text.slice(1); if (p.online) el.classList.add('online'); }
  else el.textContent = 'End-to-end encrypted';
}
setInterval(() => {
  const ch = chats[state.currentChatId];
  if (ch && byId('screen-chat').classList.contains('active')) setHeaderStatus(ch);
}, 30000);

// ---------- status clean-up (they disappear after 2 days) ----------
async function cleanupMyStatuses() {
  try {
    const snap = await getDocs(collection(db, 'statuses', state.me.uid, 'items'));
    const now = Date.now();
    snap.docs.forEach(d => { if (now - tsMillis(d.data().createdAt) >= STATUS_EXPIRY_MS) deleteDoc(d.ref).catch(() => {}); });
  } catch (e) {}
}

// ---------- posting to any chat (used by the scheduler) ----------
async function postMessageTo(chatId, fields, preview) {
  const chat = chats[chatId];
  if (!chat || !state.me) return false;
  const peer = !chat.isGroup ? otherParticipant(chat) : null;
  if (peer && isBlocked(peer.id)) return false;
  try {
    await addDoc(collection(db, 'chats', chatId, 'messages'), Object.assign({ from: state.me.uid, ts: serverTimestamp(), status: 'sent' }, fields));
    const updates = { lastMessage: { text: preview, ts: serverTimestamp(), from: state.me.uid } };
    (chat.participants || []).filter(p => p !== state.me.uid).forEach(uid => { updates['unreadBy.' + uid] = increment(1); });
    await updateDoc(doc(db, 'chats', chatId), updates);
    return true;
  } catch (e) { console.error(e); return false; }
}

// ---------- editing sent messages ----------
function startEdit(chatId, msgId) {
  const m = findMsg(chatId, msgId);
  if (!m || m.from !== state.me.uid || m.kind) return;
  state.editing = { chatId, msgId, orig: m.text || '' };
  byId('editBannerText').textContent = m.text || '';
  byId('editBanner').classList.remove('hidden');
  const input = byId('msgInput');
  input.value = m.text || '';
  updateSendButton();
  input.focus();
}
function cancelEdit() {
  state.editing = null;
  byId('editBanner').classList.add('hidden');
  byId('msgInput').value = '';
  updateSendButton();
}
async function saveEdit(text) {
  const e = state.editing;
  if (!e) return;
  if (text === e.orig) { cancelEdit(); return; }
  try {
    await updateDoc(doc(db, 'chats', e.chatId, 'messages', e.msgId), { text, edited: true, editedAt: serverTimestamp() });
    const chat = chats[e.chatId];
    const last = chat && chat.messages[chat.messages.length - 1];
    if (last && last.id === e.msgId) updateDoc(doc(db, 'chats', e.chatId), { 'lastMessage.text': text }).catch(() => {});
    cancelEdit();
    toast('Message edited');
  } catch (err) { console.error(err); toast('Could not edit that message.'); }
}
byId('cancelEdit').addEventListener('click', cancelEdit);
byId('msgInput').addEventListener('keydown', (e) => { if (e.key === 'Escape' && state.editing) cancelEdit(); });
byId('actEdit').addEventListener('click', () => { if (!state.longPressMsg) return; const { chatId, msgId } = state.longPressMsg; closeOpenSheet(); startEdit(chatId, msgId); });

// ---------- reply (button + swipe) ----------
function replyToMessage(chatId, msgId) {
  const msg = findMsg(chatId, msgId);
  if (!msg || msg.system) return;
  const senderName = msg.from === state.me.uid ? (state.me.name || 'You') : chatDisplayName(chats[chatId]);
  state.replyTarget = { sender: senderName, text: previewText(msg) };
  byId('replyPreviewName').textContent = 'Replying to ' + senderName;
  byId('replyPreviewText').textContent = state.replyTarget.text;
  byId('replyPreview').classList.remove('hidden');
  byId('msgInput').focus();
}
function bindSwipeReply(row) {
  const wrap = row.querySelector('.bubble-wrap');
  if (!wrap) return;
  let sx = 0, sy = 0, dx = 0, on = false, lock = false;
  const reset = () => { wrap.style.transform = ''; row.style.setProperty('--swp', 0); row.classList.remove('swiping'); };
  row.addEventListener('pointerdown', (e) => {
    if (e.target.closest && e.target.closest('.vwave, .poll-opt, button')) return;
    on = true; lock = false; dx = 0; sx = e.clientX; sy = e.clientY;
  });
  row.addEventListener('pointermove', (e) => {
    if (!on) return;
    const mx = e.clientX - sx, my = e.clientY - sy;
    if (!lock) {
      if (Math.abs(my) > 12 && Math.abs(my) > Math.abs(mx)) { on = false; return; }
      if (mx > 14 && mx > Math.abs(my) * 1.5) { lock = true; row.classList.add('swiping'); try { row.setPointerCapture(e.pointerId); } catch (x) {} }
      else return;
    }
    dx = Math.max(0, Math.min(96, mx));
    wrap.style.transform = 'translateX(' + dx + 'px)';
    row.style.setProperty('--swp', Math.min(1, dx / 64));
  });
  const end = () => {
    if (!on) return;
    on = false;
    const hit = lock && dx >= 64;
    lock = false;
    reset();
    if (hit) { if (navigator.vibrate) navigator.vibrate(10); replyToMessage(state.currentChatId, row.dataset.msg); }
  };
  row.addEventListener('pointerup', end);
  row.addEventListener('pointercancel', end);
}

// ---------- scheduled messages (stored on this device, up to 1 month ahead) ----------
const SCHED_MAX_MS = 30 * 24 * 3600 * 1000;
let schedEditId = null, schedChatId = null, schedFromComposer = false, schedBusy = false, schedSuppress = false, schedPress = null;
const schedKey = () => 'velo:sched:' + (state.me ? state.me.uid : '');
function schedLoad() { try { return JSON.parse(localStorage.getItem(schedKey()) || '[]'); } catch (e) { return []; } }
function schedStore(list) { try { localStorage.setItem(schedKey(), JSON.stringify(list)); } catch (e) {} paintSchedBar(); }
function toLocalInput(ms) { const d = new Date(ms); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); }
function fmtWhen(ms) { return new Date(ms).toLocaleString([], { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); }
function paintSchedBar() {
  const bar = byId('schedBar');
  if (!state.me || !state.currentChatId) { bar.classList.add('hidden'); return; }
  const n = schedLoad().filter(x => x.chatId === state.currentChatId).length;
  bar.classList.toggle('hidden', !n);
  byId('schedCount').textContent = n + ' scheduled message' + (n === 1 ? '' : 's');
}
function openSchedule(prefill, editId, fromComposer) {
  const item = editId ? schedLoad().find(x => x.id === editId) : null;
  const chatId = item ? item.chatId : state.currentChatId;
  if (!chatId) { toast('Open a chat first'); return; }
  schedChatId = chatId; schedEditId = editId || null; schedFromComposer = !!fromComposer;
  byId('schedTitle').textContent = item ? 'Edit scheduled message' : 'Schedule message';
  byId('schedText').value = item ? item.text : (prefill || '');
  const now = Date.now(), w = byId('schedWhen');
  w.min = toLocalInput(now); w.max = toLocalInput(now + SCHED_MAX_MS);
  w.value = toLocalInput(item ? item.sendAt : now + 3600000);
  byId('schedErr').textContent = '';
  byId('schedSave').textContent = item ? 'Save changes' : 'Schedule';
  showModal('schedModal');
  setTimeout(() => byId('schedText').focus(), 80);
}
$$('#schedQuick [data-q]').forEach(b => b.addEventListener('click', () => {
  const now = new Date(); let t;
  if (b.dataset.q === 'hour') t = now.getTime() + 3600000;
  else if (b.dataset.q === 'week') t = now.getTime() + 7 * 86400000;
  else {
    const d = new Date(now); d.setSeconds(0, 0);
    if (b.dataset.q === 'tonight') { d.setHours(20, 0); if (d <= now) d.setDate(d.getDate() + 1); }
    else { d.setDate(d.getDate() + 1); d.setHours(9, 0); }
    t = d.getTime();
  }
  byId('schedWhen').value = toLocalInput(t);
  $$('#schedQuick .cw-chip').forEach(x => x.classList.toggle('on', x === b));
}));
byId('schedCancel').addEventListener('click', () => hideModal('schedModal'));
byId('schedSave').addEventListener('click', () => {
  const text = byId('schedText').value.trim();
  const when = new Date(byId('schedWhen').value).getTime();
  const err = (m) => { const e = byId('schedErr'); e.textContent = m; e.classList.remove('shake'); void e.offsetWidth; e.classList.add('shake'); };
  if (!text) return err('Type the message to send.');
  if (!isFinite(when)) return err('Pick a date and time.');
  if (when < Date.now() + 20000) return err('Pick a time in the future.');
  if (when > Date.now() + SCHED_MAX_MS + 60000) return err('You can schedule up to 1 month ahead.');
  const list = schedLoad();
  if (schedEditId) { const it = list.find(x => x.id === schedEditId); if (it) { it.text = text; it.sendAt = when; } }
  else list.push({ id: 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), chatId: schedChatId, text, sendAt: when });
  schedStore(list);
  if (schedFromComposer && !schedEditId) { byId('msgInput').value = ''; updateSendButton(); }
  hideModal('schedModal');
  toast('Scheduled for ' + fmtWhen(when));
});
function renderSchedList() {
  const items = schedLoad().filter(x => x.chatId === state.currentChatId).sort((a, b) => a.sendAt - b.sendAt);
  byId('schedListBody').innerHTML = items.length ? items.map(x => `
    <div class="sched-item" data-id="${x.id}">
      <div class="when">${escapeHTML(fmtWhen(x.sendAt))}</div>
      <div class="txt">${escapeHTML(x.text)}</div>
      <div class="acts"><button data-a="edit">Edit</button><button data-a="now">Send now</button><button data-a="del" class="danger">Delete</button></div>
    </div>`).join('') : '<div class="empty-state"><h3>Nothing scheduled</h3></div>';
}
byId('schedView').addEventListener('click', () => { renderSchedList(); showModal('schedListModal'); });
byId('schedListClose').addEventListener('click', () => hideModal('schedListModal'));
byId('schedListBody').addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-a]');
  if (!btn) return;
  const id = btn.closest('.sched-item').dataset.id;
  const list = schedLoad(), it = list.find(x => x.id === id);
  if (!it) return;
  if (btn.dataset.a === 'del') { schedStore(list.filter(x => x.id !== id)); renderSchedList(); toast('Scheduled message deleted'); }
  else if (btn.dataset.a === 'edit') { hideModal('schedListModal'); openSchedule('', id, false); }
  else if (btn.dataset.a === 'now') {
    const ok = await postMessageTo(it.chatId, { text: it.text }, it.text);
    if (ok) { schedStore(schedLoad().filter(x => x.id !== id)); renderSchedList(); toast('Sent'); } else toast('Could not send — check your connection.');
  }
});
async function checkScheduled() {
  if (!state.me || schedBusy) return;
  const due = schedLoad().filter(x => x.sendAt <= Date.now());
  if (!due.length) return;
  schedBusy = true;
  try {
    for (const it of due) {
      if (!chats[it.chatId]) { schedStore(schedLoad().filter(x => x.id !== it.id)); continue; }
      if (await postMessageTo(it.chatId, { text: it.text }, it.text)) schedStore(schedLoad().filter(x => x.id !== it.id));
    }
  } finally { schedBusy = false; }
}
setInterval(checkScheduled, 15000);
byId('attachSchedule').addEventListener('click', () => { closeOpenSheet(); openSchedule(byId('msgInput').value.trim(), null, true); });

// long-press the send button to schedule; hold the mic button to record
byId('sendMsgBtn').addEventListener('click', () => {
  if (schedSuppress) { schedSuppress = false; return; }
  if (byId('msgInput').value.trim()) sendMessage();
});
const cancelSchedPress = () => { clearTimeout(schedPress); schedPress = null; };
byId('sendMsgBtn').addEventListener('pointerdown', (e) => {
  if (byId('msgInput').value.trim()) {
    if (state.editing) return;
    cancelSchedPress();
    schedPress = setTimeout(() => { schedPress = null; schedSuppress = true; if (navigator.vibrate) navigator.vibrate(15); openSchedule(byId('msgInput').value.trim(), null, true); }, 520);
    return;
  }
  e.preventDefault();
  startRecording();
});
byId('sendMsgBtn').addEventListener('pointerup', () => { cancelSchedPress(); setTimeout(() => { schedSuppress = false; }, 450); stopRecording(true); });
byId('sendMsgBtn').addEventListener('pointerleave', () => { cancelSchedPress(); stopRecording(false); });
byId('sendMsgBtn').addEventListener('pointercancel', () => { cancelSchedPress(); stopRecording(false); });

// ---------- voice notes: recorded here, stored as a base64 string in the message ----------
const REC_MAX_SEC = 120;
let rec = null, recInterval = null, recSeconds = 0;
function pickMime() {
  if (!window.MediaRecorder) return '';
  return ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'].find(t => MediaRecorder.isTypeSupported(t)) || '';
}
function showRecUI(on) {
  byId('sendMsgBtn').classList.toggle('armed', on);
  byId('cinputWrap').classList.toggle('recording', on);
  byId('recIndicator').classList.toggle('hidden', !on);
  if (on) byId('recTime').textContent = '0:00';
}
function condensePeaks(peaks, n) {
  if (!peaks || peaks.length < 3) return Array.from({ length: n }, (_, i) => 28 + Math.round(46 * Math.abs(Math.sin(i * 1.7 + 0.6))));
  const out = [], step = peaks.length / n;
  for (let i = 0; i < n; i++) { let m = 0; for (let k = Math.floor(i * step); k < Math.max(Math.floor(i * step) + 1, Math.floor((i + 1) * step)); k++) m = Math.max(m, peaks[k] || 0); out.push(m); }
  const top = Math.max(...out, 1);
  return out.map(v => Math.max(14, Math.round(v / top * 100)));
}
async function startRecording() {
  if (state.recording || !state.currentChatId) return;
  if (!navigator.mediaDevices || !window.MediaRecorder) { toast("Voice notes aren't supported in this browser."); return; }
  state.recording = true; recSeconds = 0;
  showRecUI(true);
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
  catch (e) { state.recording = false; showRecUI(false); toast('Allow microphone access to record voice notes.'); return; }
  if (!state.recording) { stream.getTracks().forEach(t => t.stop()); showRecUI(false); return; }   // let go before the mic was ready
  const mime = pickMime();
  const recorder = new MediaRecorder(stream, Object.assign({ audioBitsPerSecond: 24000 }, mime ? { mimeType: mime } : {}));
  const r = rec = { stream, recorder, chunks: [], mime: recorder.mimeType || mime || 'audio/webm', start: Date.now(), peaks: [], send: false, chatId: state.currentChatId };
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) r.chunks.push(e.data); };
  recorder.onstop = () => finishRecording(r);
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const an = ctx.createAnalyser(); an.fftSize = 256;
    ctx.createMediaStreamSource(stream).connect(an);
    r.ctx = ctx;
    const buf = new Uint8Array(an.frequencyBinCount);
    r.meter = setInterval(() => { an.getByteTimeDomainData(buf); let m = 0; for (let i = 0; i < buf.length; i++) m = Math.max(m, Math.abs(buf[i] - 128)); r.peaks.push(Math.min(100, Math.round(m / 128 * 150))); }, 100);
  } catch (e) {}
  recorder.start(250);
  recInterval = setInterval(() => {
    recSeconds = Math.round((Date.now() - r.start) / 1000);
    byId('recTime').textContent = fmtDur(recSeconds);
    if (recSeconds >= REC_MAX_SEC) { toast('Maximum length reached — sending.'); stopRecording(true); }
  }, 250);
}
function stopRecording(send) {
  if (!state.recording) return;
  state.recording = false;
  clearInterval(recInterval);
  showRecUI(false);
  const r = rec;
  if (!r) return;   // microphone permission still pending
  rec = null;
  r.send = !!send && (Date.now() - r.start) >= 700;
  if (send && !r.send) toast('Hold the mic button to record');
  try { if (r.recorder.state !== 'inactive') r.recorder.stop(); } catch (e) {}
  r.stream.getTracks().forEach(t => t.stop());
  clearInterval(r.meter);
  try { if (r.ctx) r.ctx.close(); } catch (e) {}
}
function finishRecording(r) {
  if (!r.send || !r.chunks.length) return;
  const blob = new Blob(r.chunks, { type: r.mime });
  const dur = Math.max(1, Math.round((Date.now() - r.start) / 1000));
  if (blob.size > 640 * 1024) { toast('That voice note is too long — keep it under about 2 minutes.'); return; }
  const fr = new FileReader();
  fr.onload = async () => {
    if (state.currentChatId !== r.chatId) return;
    await sendRichMessage({ kind: 'voice', audio: fr.result, mime: r.mime, duration: dur, wave: condensePeaks(r.peaks, 36), text: '' }, '🎤 Voice message (' + fmtDur(dur) + ')');
  };
  fr.readAsDataURL(blob);
}
let vplay = null, vSpeed = 1;
function voiceHTML(m) {
  const wave = (Array.isArray(m.wave) && m.wave.length) ? m.wave : condensePeaks([], 36);
  const bars = wave.map(v => `<i style="height:${Math.max(14, Math.min(100, Number(v) || 14))}%"></i>`).join('');
  return `<div class="vmsg${m.audio ? '' : ' nodata'}" data-vm="${m.id}" data-dur="${Number(m.duration) || 0}"><button class="vp" aria-label="Play voice message"><svg class="pl" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7Z"/></svg><svg class="pa" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h3.6v14H7zM13.4 5H17v14h-3.6z"/></svg></button><div class="vwave">${bars}</div><div class="vside"><span class="vtime">${fmtDur(m.duration || 0)}</span><button class="vspd" aria-label="Playback speed">1x</button></div></div>`;
}
function paintVoice() {
  $$('#threadBody .vmsg').forEach(el => {
    const mine = vplay && vplay.id === el.dataset.vm;
    const dur = Number(el.dataset.dur) || 1;
    const pos = mine ? vplay.audio.currentTime : 0;
    const frac = mine ? Math.min(1, pos / dur) : 0;
    const bars = el.querySelectorAll('.vwave i'), k = Math.floor(frac * bars.length);
    el.classList.toggle('playing', !!(mine && !vplay.audio.paused));
    bars.forEach((b, i) => { b.classList.toggle('on', i < k); b.classList.toggle('cur', !!mine && i === k); });
    el.querySelector('.vtime').textContent = (mine && pos > 0.2) ? fmtDur(pos) : fmtDur(Number(el.dataset.dur) || 0);
    el.querySelector('.vspd').textContent = vSpeed + 'x';
  });
}
function toggleVoice(id, seekFrac) {
  const chat = chats[state.currentChatId], msg = chat && chat.messages.find(x => x.id === id);
  if (!msg || !msg.audio || !/^data:audio\//i.test(msg.audio)) { toast('This voice note has no audio.'); return; }
  if (vplay && vplay.id === id) {
    if (seekFrac != null) vplay.audio.currentTime = seekFrac * (Number(msg.duration) || 1);
    else if (vplay.audio.paused) vplay.audio.play().catch(() => {}); else vplay.audio.pause();
    paintVoice(); return;
  }
  if (vplay) vplay.audio.pause();
  const a = new Audio(msg.audio);
  a.playbackRate = vSpeed;
  vplay = { id, audio: a };
  a.addEventListener('timeupdate', paintVoice);
  a.addEventListener('play', paintVoice);
  a.addEventListener('pause', paintVoice);
  a.addEventListener('ended', () => { vplay = null; paintVoice(); });
  if (seekFrac != null) a.addEventListener('loadedmetadata', () => { a.currentTime = seekFrac * (Number(msg.duration) || 1); }, { once: true });
  a.play().catch(() => toast("Couldn't play that voice note."));
  paintVoice();
}

// ---------- full-screen photo viewer (zoom + save) ----------
const iv = { s: 1, x: 0, y: 0, pts: new Map(), d0: 0, s0: 1, drag: null, lastTap: 0 };
const ivApply = () => { byId('ivImg').style.transform = 'translate(' + iv.x + 'px,' + iv.y + 'px) scale(' + iv.s + ')'; };
function openImgViewer(src, title) {
  if (!/^(data:image\/|blob:)/i.test(src || '')) return;
  iv.s = 1; iv.x = iv.y = 0; iv.pts.clear();
  byId('ivImg').src = src;
  byId('ivTitle').textContent = title || 'Photo';
  ivApply();
  byId('imgViewer').classList.remove('hidden');
}
function closeImgViewer() { byId('imgViewer').classList.add('hidden'); byId('ivImg').removeAttribute('src'); }
async function ivBlob() { const src = byId('ivImg').getAttribute('src'); if (!src) throw new Error('no image'); const r = await fetch(src); return r.blob(); }
byId('ivClose').addEventListener('click', closeImgViewer);
byId('ivSave').addEventListener('click', async () => {
  try {
    const blob = await ivBlob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'velo-' + Date.now() + '.' + (/png/.test(blob.type) ? 'png' : 'jpg');
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Photo saved — check your Downloads / Gallery');
  } catch (e) { console.error(e); toast('Could not save that photo.'); }
});
byId('ivShare').addEventListener('click', async () => {
  try {
    const blob = await ivBlob();
    const file = new File([blob], 'velo-' + Date.now() + '.' + (/png/.test(blob.type) ? 'png' : 'jpg'), { type: blob.type });
    if (navigator.canShare && navigator.canShare({ files: [file] })) await navigator.share({ files: [file] });
    else toast('Sharing is not supported here — use Save.');
  } catch (e) { if (e && e.name !== 'AbortError') toast('Could not share that photo.'); }
});
(function bindViewerGestures() {
  const st = byId('ivStage');
  st.addEventListener('pointerdown', (e) => {
    st.setPointerCapture && st.setPointerCapture(e.pointerId);
    iv.pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (iv.pts.size === 1) {
      iv.drag = { x: e.clientX, y: e.clientY, ox: iv.x, oy: iv.y };
      const now = Date.now();
      if (now - iv.lastTap < 280) { iv.s = iv.s > 1.2 ? 1 : 2.5; if (iv.s === 1) iv.x = iv.y = 0; ivApply(); }
      iv.lastTap = now;
    } else if (iv.pts.size === 2) {
      const [p, q] = [...iv.pts.values()]; iv.d0 = Math.hypot(p.x - q.x, p.y - q.y) || 1; iv.s0 = iv.s;
    }
  });
  st.addEventListener('pointermove', (e) => {
    if (!iv.pts.has(e.pointerId)) return;
    iv.pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (iv.pts.size === 2) {
      const [p, q] = [...iv.pts.values()];
      iv.s = Math.max(1, Math.min(6, iv.s0 * Math.hypot(p.x - q.x, p.y - q.y) / iv.d0)); ivApply();
    } else if (iv.drag && iv.s > 1) {
      iv.x = iv.drag.ox + (e.clientX - iv.drag.x); iv.y = iv.drag.oy + (e.clientY - iv.drag.y); ivApply();
    }
  });
  const up = (e) => { iv.pts.delete(e.pointerId); if (iv.pts.size === 0) { iv.drag = null; if (iv.s <= 1.02) { iv.s = 1; iv.x = iv.y = 0; ivApply(); } } };
  st.addEventListener('pointerup', up); st.addEventListener('pointercancel', up);
  st.addEventListener('wheel', (e) => { e.preventDefault(); iv.s = Math.max(1, Math.min(6, iv.s * (e.deltaY < 0 ? 1.15 : 0.87))); if (iv.s === 1) iv.x = iv.y = 0; ivApply(); }, { passive: false });
})();
byId('profileAvatar').addEventListener('click', () => { const img = byId('profileAvatar').querySelector('img'); if (img) openImgViewer(img.src, byId('profileName').textContent); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !byId('imgViewer').classList.contains('hidden')) closeImgViewer(); });

// thread hooks (called after every render)
function bindThreadExtras() {
  $$('#threadBody .bubble-row[data-msg]').forEach(bindSwipeReply);
  $$('#threadBody .img-bubble img').forEach(img => img.addEventListener('click', () => openImgViewer(img.src, 'Photo')));
  $$('#threadBody .vmsg').forEach(el => {
    el.querySelector('.vp').addEventListener('click', (e) => { e.stopPropagation(); toggleVoice(el.dataset.vm); });
    el.querySelector('.vspd').addEventListener('click', (e) => { e.stopPropagation(); vSpeed = vSpeed === 1 ? 1.5 : (vSpeed === 1.5 ? 2 : 1); if (vplay) vplay.audio.playbackRate = vSpeed; paintVoice(); });
    const w = el.querySelector('.vwave');
    w.addEventListener('pointerdown', (e) => { e.stopPropagation(); const r = w.getBoundingClientRect(); toggleVoice(el.dataset.vm, Math.max(0, Math.min(1, (e.clientX - r.left) / r.width))); });
  });
  paintVoice();
}

// ---------- chat wallpapers ----------
const WALLS = [{ k: 'aurora', n: 'Aurora' }, { k: 'stars', n: 'Night sky' }, { k: 'waves', n: 'Waves' }, { k: 'bubbles', n: 'Bubbles' }, { k: 'plain', n: 'Plain' }];
const WALL_NAMES = { aurora: 'Aurora (default)', stars: 'Night sky', waves: 'Waves', bubbles: 'Bubbles', plain: 'Plain', custom: 'Custom photo' };
function wallLayers(k) {
  if (k === 'aurora' || k === 'waves') return '<i></i><i></i><i></i>';
  if (k === 'stars') {
    let s = '';
    for (let i = 0; i < 30; i++) s += `<i class="s" style="left:${(i * 37 + 11) % 100}%;top:${(i * 53 + 7) % 100}%;--s:${1 + ((i * 7) % 3)}px;animation-delay:${(i % 9) * 0.35}s;animation-duration:${(2.4 + (i % 5) * 0.6).toFixed(1)}s"></i>`;
    return s + '<i class="sh"></i>';
  }
  if (k === 'bubbles') {
    let s = '';
    for (let i = 0; i < 14; i++) s += `<i class="b" style="left:${(i * 29 + 6) % 96}%;--sz:${14 + ((i * 11) % 26)}px;--d:${9 + ((i * 5) % 9)}s;--dl:-${(i * 3) % 10}s;--dx:${(i % 2 ? 1 : -1) * (12 + (i * 7) % 30)}px"></i>`;
    return s;
  }
  return '';
}
const wallAll = () => localStorage.getItem('velo:wall:all') || 'aurora';
const wallFor = (chatId) => (chatId && localStorage.getItem('velo:wall:chat:' + chatId)) || wallAll();
const wallImg = (scope) => { const v = localStorage.getItem('velo:wallImg:' + scope) || ''; return /^data:image\//.test(v) ? v : ''; };
function paintWall(el, key, img) {
  el.dataset.wall = key;
  el.innerHTML = wallLayers(key);
  el.style.backgroundImage = (key === 'custom' && img) ? 'url("' + img + '")' : '';
}
function applyWallpaper(chatId) {
  const key = wallFor(chatId), el = byId('chatWall');
  if (key === 'custom') {
    const own = chatId && localStorage.getItem('velo:wall:chat:' + chatId) === 'custom';
    const img = own ? wallImg('chat:' + chatId) : wallImg('all');
    if (!img) { paintWall(el, 'aurora'); return; }
    paintWall(el, 'custom', img); return;
  }
  paintWall(el, key);
}
const wm = { scope: 'all', chatId: null };
const wmScopeKey = () => (wm.scope === 'chat' && wm.chatId) ? 'chat:' + wm.chatId : 'all';
const wmCurrent = () => (wm.scope === 'chat' && wm.chatId) ? wallFor(wm.chatId) : wallAll();
function renderWallGrid() {
  const cur = wmCurrent();
  const tiles = WALLS.map(w => ({ k: w.k, n: w.n }));
  if (wallImg(wmScopeKey())) tiles.push({ k: 'custom', n: 'My photo' });
  const check = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L19 7"/></svg>';
  byId('wallGrid').innerHTML = tiles.map(t => `<button class="wall-tile ${cur === t.k ? 'on' : ''}" data-k="${t.k}"><div class="chat-wall" data-wall="${t.k}"${t.k === 'custom' ? ` style="background-image:url('${wallImg(wmScopeKey())}')"` : ''}>${wallLayers(t.k)}</div><span class="lbl">${t.n}</span><span class="tick">${check}</span></button>`).join('');
  $$('#wallGrid .wall-tile').forEach(b => b.addEventListener('click', () => setWall(b.dataset.k)));
  byId('wallUseDefault').classList.toggle('hidden', !(wm.scope === 'chat' && wm.chatId && localStorage.getItem('velo:wall:chat:' + wm.chatId)));
}
function setWall(k) {
  if (wm.scope === 'chat' && wm.chatId) localStorage.setItem('velo:wall:chat:' + wm.chatId, k); else localStorage.setItem('velo:wall:all', k);
  applyWallpaper(state.currentChatId);
  renderWallGrid();
  byId('wallCurrent').textContent = WALL_NAMES[wallAll()] || 'Aurora (default)';
}
function openWallModal(chatId) {
  wm.chatId = chatId || null;
  wm.scope = (chatId && localStorage.getItem('velo:wall:chat:' + chatId)) ? 'chat' : 'all';
  byId('wallScope').classList.toggle('hidden', !chatId);
  $$('#wallScope button').forEach(b => b.classList.toggle('active', b.dataset.scope === wm.scope));
  renderWallGrid();
  showModal('wallModal');
}
$$('#wallScope button').forEach(b => b.addEventListener('click', () => {
  wm.scope = b.dataset.scope;
  $$('#wallScope button').forEach(x => x.classList.toggle('active', x === b));
  renderWallGrid();
}));
byId('openWallpaper').addEventListener('click', () => openWallModal(null));
byId('profileWallpaper').addEventListener('click', () => openWallModal(state.currentProfileId));
byId('wallClose').addEventListener('click', () => hideModal('wallModal'));
byId('wallUseDefault').addEventListener('click', () => { localStorage.removeItem('velo:wall:chat:' + wm.chatId); wm.scope = 'all'; $$('#wallScope button').forEach(b => b.classList.toggle('active', b.dataset.scope === 'all')); applyWallpaper(state.currentChatId); renderWallGrid(); toast('This chat now uses your default wallpaper'); });
byId('wallGallery').addEventListener('click', () => byId('wallFileInput').click());
byId('wallFileInput').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  if (!/^image\//.test(f.type)) { toast('Please choose an image'); return; }
  const url = await openCropper(f, { aspect: 9 / 16, outW: 720, outH: 1280, circle: false, quality: 0.8, title: 'Crop wallpaper' });
  if (!url) return;
  try { localStorage.setItem('velo:wallImg:' + wmScopeKey(), url); }
  catch (err) { toast("That image is too big to store on this device — try a smaller one."); return; }
  setWall('custom');
  toast('Wallpaper set');
});
byId('wallCurrent').textContent = WALL_NAMES[wallAll()] || 'Aurora (default)';

// ---------- crop & adjust ----------
const cr = { img: null, rot: 0, zoom: 1, ox: 0, oy: 0, W: 300, H: 300, opts: null, resolve: null, pts: new Map(), drag: null, d0: 1, z0: 1 };
function crDims() { return (cr.rot % 180) ? { rw: cr.img.h, rh: cr.img.w } : { rw: cr.img.w, rh: cr.img.h }; }
function crBase() { const { rw, rh } = crDims(); return Math.max(cr.W / rw, cr.H / rh); }
function crClamp() {
  const { rw, rh } = crDims(), s = crBase() * cr.zoom;
  const mx = Math.max(0, (rw * s - cr.W) / 2), my = Math.max(0, (rh * s - cr.H) / 2);
  cr.ox = Math.max(-mx, Math.min(mx, cr.ox)); cr.oy = Math.max(-my, Math.min(my, cr.oy));
}
function crDraw(ctx, W, H, k) {
  ctx.save();
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  const s = crBase() * cr.zoom * k;
  ctx.translate(W / 2 + cr.ox * k, H / 2 + cr.oy * k);
  ctx.rotate(cr.rot * Math.PI / 180);
  ctx.scale(s, s);
  ctx.drawImage(cr.img.el, -cr.img.w / 2, -cr.img.h / 2);
  ctx.restore();
}
function crRender() {
  if (!cr.img) return;
  crClamp();
  const cv = byId('cropCanvas');
  crDraw(cv.getContext('2d'), cv.width, cv.height, 1);
  cv.style.filter = 'brightness(' + (1 + Number(byId('cropBright').value) / 100) + ') contrast(' + (1 + Number(byId('cropContrast').value) / 100) + ')';
}
function crExport() {
  const o = cr.opts, cv = document.createElement('canvas');
  cv.width = o.outW; cv.height = o.outH;
  const ctx = cv.getContext('2d');
  crDraw(ctx, o.outW, o.outH, o.outW / cr.W);
  const b = 1 + Number(byId('cropBright').value) / 100, c = 1 + Number(byId('cropContrast').value) / 100;
  if (b !== 1 || c !== 1) {
    const im = ctx.getImageData(0, 0, o.outW, o.outH), d = im.data;
    for (let i = 0; i < d.length; i += 4) for (let j = 0; j < 3; j++) { let v = (d[i + j] * b - 128) * c + 128; d[i + j] = v < 0 ? 0 : (v > 255 ? 255 : v); }
    ctx.putImageData(im, 0, 0);
  }
  return cv.toDataURL('image/jpeg', o.quality || 0.82);
}
async function openCropper(file, opts) {
  let img;
  try { const bmp = await loadBitmap(file); img = { el: bmp, w: bmp.width || bmp.naturalWidth, h: bmp.height || bmp.naturalHeight }; if (!img.w || !img.h) throw new Error('decode'); }
  catch (e) { toast("Couldn't read that image — try a JPG or PNG."); return null; }
  return new Promise((resolve) => {
    cr.img = img; cr.rot = 0; cr.zoom = 1; cr.ox = cr.oy = 0; cr.opts = opts; cr.resolve = resolve; cr.pts.clear();
    const maxW = Math.min(300, window.innerWidth - 90), maxH = Math.min(360, window.innerHeight * 0.42);
    let W = maxW, H = W / opts.aspect;
    if (H > maxH) { H = maxH; W = H * opts.aspect; }
    cr.W = Math.round(W); cr.H = Math.round(H);
    const stage = byId('cropStage'), cv = byId('cropCanvas');
    stage.style.width = cr.W + 'px'; stage.style.height = cr.H + 'px'; cv.width = cr.W; cv.height = cr.H;
    byId('cropMask').className = 'crop-mask ' + (opts.circle ? 'circle' : 'grid');
    byId('cropTitle').textContent = opts.title || 'Crop photo';
    byId('cropZoom').value = 1; byId('cropBright').value = 0; byId('cropContrast').value = 0;
    showModal('cropModal');
    crRender();
  });
}
function crClose(result) { hideModal('cropModal'); const r = cr.resolve; cr.resolve = null; cr.img = null; if (r) r(result); }
byId('cropZoom').addEventListener('input', (e) => { cr.zoom = Number(e.target.value); crRender(); });
byId('cropBright').addEventListener('input', crRender);
byId('cropContrast').addEventListener('input', crRender);
byId('cropRotate').addEventListener('click', () => { cr.rot = (cr.rot + 90) % 360; cr.ox = cr.oy = 0; crRender(); });
byId('cropReset').addEventListener('click', () => { cr.rot = 0; cr.zoom = 1; cr.ox = cr.oy = 0; byId('cropZoom').value = 1; byId('cropBright').value = 0; byId('cropContrast').value = 0; crRender(); });
byId('cropCancel').addEventListener('click', () => crClose(null));
byId('cropDone').addEventListener('click', () => { try { crClose(crExport()); } catch (e) { console.error(e); toast('Could not crop that image.'); crClose(null); } });
(function bindCropGestures() {
  const st = byId('cropStage');
  st.addEventListener('pointerdown', (e) => {
    try { st.setPointerCapture(e.pointerId); } catch (x) {}
    cr.pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (cr.pts.size === 1) cr.drag = { x: e.clientX, y: e.clientY, ox: cr.ox, oy: cr.oy };
    else if (cr.pts.size === 2) { const [p, q] = [...cr.pts.values()]; cr.d0 = Math.hypot(p.x - q.x, p.y - q.y) || 1; cr.z0 = cr.zoom; }
  });
  st.addEventListener('pointermove', (e) => {
    if (!cr.pts.has(e.pointerId) || !cr.img) return;
    cr.pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (cr.pts.size === 2) {
      const [p, q] = [...cr.pts.values()];
      cr.zoom = Math.max(1, Math.min(4, cr.z0 * Math.hypot(p.x - q.x, p.y - q.y) / cr.d0)); byId('cropZoom').value = cr.zoom;
    } else if (cr.drag) { cr.ox = cr.drag.ox + (e.clientX - cr.drag.x); cr.oy = cr.drag.oy + (e.clientY - cr.drag.y); }
    crRender();
  });
  const up = (e) => { cr.pts.delete(e.pointerId); if (!cr.pts.size) cr.drag = null; };
  st.addEventListener('pointerup', up); st.addEventListener('pointercancel', up);
  st.addEventListener('wheel', (e) => { e.preventDefault(); cr.zoom = Math.max(1, Math.min(4, cr.zoom * (e.deltaY < 0 ? 1.08 : 0.93))); byId('cropZoom').value = cr.zoom; crRender(); }, { passive: false });
})();


// ---------------------------------------------------------------------
// account + settings
// ---------------------------------------------------------------------
function renderAccountScreen() {
  if (!state.me) return;
  setAvatar(byId('acctAvatar'), 'me', state.me.name, 'av-lg');
  byId('acctName').textContent = state.me.name;
  byId('acctEmail').textContent = state.me.email;
  byId('acctPhone').textContent = state.me.phone;
  paintMyBio();
  byId('acctPhotoRemove').classList.toggle('hidden', !state.me.photo);
  byId('acctVeloId').textContent = state.me.veloId;
  setAvatar(byId('drawerAvatar'), 'me', state.me.name, 'av-sm');
  byId('drawerUserName').textContent = state.me.username ? '@' + state.me.username : state.me.name;
  byId('drawerUserSub').textContent = 'Velo ID: ' + state.me.veloId;
}
byId('accountBack').addEventListener('click', () => goBack('screen-main'));
byId('openBackups').addEventListener('click', () => showScreen('screen-privacy'));
byId('openPrivacy').addEventListener('click', () => showScreen('screen-privacy'));
byId('openSettingsDetail').addEventListener('click', () => showScreen('screen-settings'));
byId('settingsBack').addEventListener('click', () => goBack('screen-account'));
byId('openAppearanceSettings').addEventListener('click', () => showScreen('screen-appearance'));
byId('appearanceBack').addEventListener('click', () => goBack('screen-settings'));
byId('openPrivacySettings').addEventListener('click', () => showScreen('screen-privacy'));
byId('privacyBack').addEventListener('click', () => goBack('screen-settings'));
byId('openNotifSettings').addEventListener('click', () => showScreen('screen-notifications'));
byId('notifBack').addEventListener('click', () => goBack('screen-settings'));
byId('openUpcomingSettings').addEventListener('click', () => showScreen('screen-upcoming'));
byId('upcomingBack').addEventListener('click', () => goBack('screen-settings'));
byId('openHelpSettings').addEventListener('click', () => showScreen('screen-help'));
byId('helpBack').addEventListener('click', () => goBack('screen-settings'));

function effectiveTheme(mode) {
  return mode === 'system' ? (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : mode;
}
function setTheme(mode) {
  document.body.setAttribute('data-theme', mode);
  document.body.setAttribute('data-eff', effectiveTheme(mode));
  const meta = byId('metaTheme'); if (meta) meta.setAttribute('content', effectiveTheme(mode) === 'light' ? '#f3f5fb' : '#050914');
  localStorage.setItem('velo:theme', mode);
  $$('#modeSeg button').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  byId('toggleThemeQuick').innerHTML = effectiveTheme(mode) === 'light'
    ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>'
    : '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>';
}
$$('#modeSeg button').forEach(b => b.addEventListener('click', () => setTheme(b.dataset.mode)));
byId('toggleThemeQuick').addEventListener('click', () => {
  setTheme(document.body.getAttribute('data-eff') === 'light' ? 'dark' : 'light');
});
$$('#backupSeg button').forEach(b => b.addEventListener('click', () => {
  $$('#backupSeg button').forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  localStorage.setItem('velo:backup', b.dataset.backup);
  refreshBackupStatus();
}));

// ---------------------------------------------------------------------
// Google Drive backup — exports this account's chats, messages and any
// locally-attached images as one JSON file into a "Velo Backups" folder
// in the person's own Drive. Uses the drive.file scope, so Velo can only
// see the files it creates there, never the rest of their Drive.
// ---------------------------------------------------------------------
async function ensureDriveAccessToken() {
  if (driveAccessToken && Date.now() < driveTokenExpiresAt) return driveAccessToken;
  // Consent was already given at sign-up, so hinting the account means no chooser/consent screen — it just opens and closes.
  driveProvider.setCustomParameters({ login_hint: (auth.currentUser && auth.currentUser.email) || '' });
  const result = await reauthenticateWithPopup(auth.currentUser, driveProvider);
  const cred = GoogleAuthProvider.credentialFromResult(result);
  driveAccessToken = cred.accessToken;
  driveTokenExpiresAt = Date.now() + 50 * 60 * 1000; // Google access tokens run ~1hr; refresh a bit early
  return driveAccessToken;
}
async function findOrCreateDriveFolder(token) {
  const q = encodeURIComponent("name='Velo Backups' and mimeType='application/vnd.google-apps.folder' and trashed=false");
  const res = await fetch(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name)`, {
    headers: { Authorization: 'Bearer ' + token },
  });
  const data = await res.json();
  if (data.files && data.files.length) return data.files[0].id;
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files?fields=id', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Velo Backups', mimeType: 'application/vnd.google-apps.folder' }),
  });
  const created = await createRes.json();
  return created.id;
}
async function uploadJSONToDrive(token, folderId, filename, jsonObj) {
  const boundary = 'velo-' + Date.now();
  const metadata = { name: filename, parents: [folderId], mimeType: 'application/json' };
  const body =
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\nContent-Type: application/json\r\n\r\n${JSON.stringify(jsonObj)}\r\n` +
    `--${boundary}--`;
  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': `multipart/related; boundary=${boundary}` },
    body,
  });
  if (!res.ok) throw new Error('drive-upload-failed');
  return res.json();
}
async function gatherBackupChats() {
  const chatsSnap = await getDocs(query(collection(db, 'chats'), where('participants', 'array-contains', state.me.uid)));
  const result = [];
  for (const chatDoc of chatsSnap.docs) {
    const chatId = chatDoc.id;
    const msgsSnap = await getDocs(query(collection(db, 'chats', chatId, 'messages'), orderBy('ts', 'asc')));
    const fsMessages = msgsSnap.docs.map(m => ({ id: m.id, ...m.data() }));
    // images never leave this device yet (see the FIREBASE note by the photo-attach
    // handler), so pull any of those in from the local session and merge them in.
    const fsIds = new Set(fsMessages.map(m => m.id));
    const localImages = ((chats[chatId] && chats[chatId].messages) || []).filter(m => m.kind === 'image' && !fsIds.has(m.id));
    const cd = chatDoc.data();
    result.push({
      id: chatId,
      name: cd.name || null,
      isGroup: !!cd.isGroup,
      participants: cd.participants || [],
      messages: [...fsMessages, ...localImages].sort((a, b) => tsMillis(a.ts) - tsMillis(b.ts)),
    });
  }
  return result;
}
function refreshBackupStatus() {
  const el = byId('driveBackupStatus');
  if (!el) return;
  const lastAt = Number(localStorage.getItem('velo:lastBackupAt') || 0);
  if (!lastAt) { el.textContent = 'Chats, messages & images — never backed up yet'; return; }
  const days = Math.floor((Date.now() - lastAt) / 86400000);
  const when = days <= 0 ? 'today' : days === 1 ? '1 day ago' : `${days} days ago`;
  const schedule = localStorage.getItem('velo:backup') || 'daily';
  const dueDays = schedule === 'weekly' ? 7 : schedule === 'manual' ? Infinity : 1;
  el.textContent = days >= dueDays
    ? `Last backed up ${when} — due for another one`
    : `Last backed up ${when}`;
}
async function backupToGoogleDrive() {
  if (!state.me) return;
  const btn = byId('driveBackupBtn');
  const statusEl = byId('driveBackupStatus');
  setBtnLoading(btn, true);
  statusEl.textContent = 'Backing up to Google Drive…';
  try {
    const token = await ensureDriveAccessToken();
    const folderId = await findOrCreateDriveFolder(token);
    const chatsData = await gatherBackupChats();
    const backup = {
      exportedAt: new Date().toISOString(),
      account: { uid: state.me.uid, name: state.me.name, email: state.me.email, veloId: state.me.veloId },
      chats: chatsData,
    };
    const filename = `Velo Backup - ${new Date().toISOString().slice(0, 10)}.json`;
    await uploadJSONToDrive(token, folderId, filename, backup);
    localStorage.setItem('velo:lastBackupAt', String(Date.now()));
    refreshBackupStatus();
    toast(`Backed up ${chatsData.length} chat${chatsData.length === 1 ? '' : 's'} to Google Drive`);
  } catch (err) {
    statusEl.textContent = 'Backup failed — tap to try again';
    if (err?.code === 'auth/user-mismatch') toast("Please pick the same Google account you're signed in with.");
    else if (err?.code) toast(friendlyAuthError(err));
    else toast('Backup failed — check your connection and try again.');
  } finally {
    setBtnLoading(btn, false);
  }
}
byId('driveBackupBtn').addEventListener('click', backupToGoogleDrive);
refreshBackupStatus();

['toggleLastSeen', 'toggleProfileDetails', 'toggleMuteCalls', 'toggleMuteMessages'].forEach(id => {
  const el = byId(id);
  const saved = localStorage.getItem('velo:' + id);
  if (saved !== null) el.checked = saved === '1';
  el.addEventListener('change', () => localStorage.setItem('velo:' + id, el.checked ? '1' : '0'));
});
byId('toggleBrowserNotifs').addEventListener('change', async (e) => {
  if (e.target.checked && Notification.permission !== 'granted') {
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') { e.target.checked = false; toast('Notifications were blocked in the browser'); return; }
  }
  localStorage.setItem('velo:browserNotifs', e.target.checked ? '1' : '0');
});
byId('toggleBrowserNotifs').checked = localStorage.getItem('velo:browserNotifs') === '1';

// ---------------------------------------------------------------------
// App password — a device-local lock layered on top of the real
// Google sign-in. Never sent anywhere; stored (as a salted hash) only
// in this browser's localStorage, per Velo account.
// ---------------------------------------------------------------------
// crypto.subtle only exists on https:// pages, so a plain-JS SHA-256 (same output) keeps the lock working everywhere
function sha256Hex(text) {
  const bytes = Array.from(new TextEncoder().encode(text));
  const K = [], H = [];
  for (let n = 2, c = 0; c < 64; n++) {
    let prime = true; for (let i = 2; i * i <= n; i++) if (n % i === 0) { prime = false; break; }
    if (!prime) continue;
    if (c < 8) H[c] = (Math.pow(n, 1 / 2) % 1 * 4294967296) | 0;
    K[c++] = (Math.pow(n, 1 / 3) % 1 * 4294967296) | 0;
  }
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? 0 : (bitLen >>> (i * 8)) & 255);
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  for (let off = 0; off < bytes.length; off += 64) {
    const w = new Array(64);
    for (let i = 0; i < 16; i++) w[i] = (bytes[off + i * 4] << 24) | (bytes[off + i * 4 + 1] << 16) | (bytes[off + i * 4 + 2] << 8) | bytes[off + i * 4 + 3];
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  }
  return H.map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
}
async function hashPassword(pw) {
  const input = 'velo-lock:' + pw;
  if (window.crypto && window.crypto.subtle) {
    const buf = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  return sha256Hex(input);
}
function pwKey() { return 'velo:pwhash:' + (state.me?.uid || ''); }
function askKey() { return 'velo:askAlways:' + (state.me?.uid || ''); }
function hasPassword() { return !!localStorage.getItem(pwKey()); }
function refreshPasswordUI() {
  const set = hasPassword();
  byId('passwordRowTitle').textContent = set ? 'Change Password' : 'Set A Password';
  byId('passwordRowSub').textContent = set ? 'Update or remove your device lock' : 'Adds an extra lock just for this device';
  byId('askPasswordRow').classList.toggle('hidden', !set);
  byId('removePasswordBtn').classList.toggle('hidden', !set);
  byId('toggleAskPassword').checked = set && localStorage.getItem(askKey()) === '1';
}
let gateOnSuccess = null;
function requirePasswordGate(subtitle, onSuccess, { allowLogoutEscape = false } = {}) {
  if (!hasPassword()) { onSuccess(); return; }
  byId('passwordGateSub').textContent = subtitle;
  byId('passwordGateInput').value = '';
  byId('passwordGateLogout').classList.toggle('hidden', !allowLogoutEscape);
  gateOnSuccess = onSuccess;
  showModal('passwordGateModal');
  setTimeout(() => byId('passwordGateInput').focus(), 50);
}
function maybeShowOpenGate() {
  if (hasPassword() && localStorage.getItem(askKey()) === '1') {
    requirePasswordGate('Enter your password to open Velo.', () => {}, { allowLogoutEscape: true });
  }
}
byId('passwordGateSubmit').addEventListener('click', async () => {
  const entered = await hashPassword(byId('passwordGateInput').value);
  if (entered !== localStorage.getItem(pwKey())) { toast('Incorrect password'); return; }
  hideModal('passwordGateModal');
  const cb = gateOnSuccess; gateOnSuccess = null;
  if (cb) cb();
});
byId('passwordGateCancel').addEventListener('click', () => { hideModal('passwordGateModal'); gateOnSuccess = null; });
byId('passwordGateLogout').addEventListener('click', async () => {
  hideModal('passwordGateModal'); gateOnSuccess = null;
  await logoutAccount();
  showScreen('screen-welcome');
});
byId('passwordSettingBtn').addEventListener('click', () => {
  requirePasswordGate('Enter your current password to change it.', () => {
    byId('passwordSetTitle').textContent = hasPassword() ? 'Change Password' : 'Set A Password';
    byId('passwordSetInput').value = '';
    byId('passwordSetConfirm').value = '';
    showModal('passwordSetModal');
  });
});
byId('closePasswordSetModal').addEventListener('click', () => hideModal('passwordSetModal'));
byId('savePasswordBtn').addEventListener('click', async () => {
  const pw = byId('passwordSetInput').value;
  const confirm = byId('passwordSetConfirm').value;
  if (pw.length < 4) { toast('Use at least 4 characters'); return; }
  if (pw !== confirm) { toast("Passwords don't match"); return; }
  localStorage.setItem(pwKey(), await hashPassword(pw));
  hideModal('passwordSetModal');
  refreshPasswordUI();
  toast('Password saved');
});
byId('removePasswordBtn').addEventListener('click', () => {
  requirePasswordGate('Enter your password to remove it.', () => {
    localStorage.removeItem(pwKey());
    localStorage.removeItem(askKey());
    refreshPasswordUI();
    toast('Password removed');
  });
});
byId('toggleAskPassword').addEventListener('change', (e) => {
  const wantOn = e.target.checked;
  e.target.checked = !wantOn; // revert until the gate confirms; refreshPasswordUI() below sets the real state
  requirePasswordGate(wantOn ? 'Enter your password to turn this on.' : 'Enter your password to turn this off.', () => {
    localStorage.setItem(askKey(), wantOn ? '1' : '0');
    refreshPasswordUI();
  });
});
byId('reportBugsBtn').addEventListener('click', () => toast('Thanks — this would open a bug report form'));
byId('helpBtn').addEventListener('click', () => toast('Help center — coming soon'));
byId('logoutBtn').addEventListener('click', () => {
  confirmAction('Log out of Velo?', 'You can log back in anytime with your Velo ID, phone number, or Google account.', async () => {
    await logoutAccount();
    showScreen('screen-welcome');
    toast('Logged out');
  }, 'Log Out');
});
byId('deleteAccountBtn').addEventListener('click', () => {
  requirePasswordGate('Enter your password to delete your account.', () => {
    confirmAction('Delete your Velo account?', 'This permanently deletes your Velo profile (name, Velo ID, phone, username) and signs you out for good. This can\'t be undone.', async () => {
      try {
        // Google logins can go "stale" for sensitive actions, so re-prove
        // it's really them right before actually deleting anything.
        await reauthenticateWithPopup(auth.currentUser, googleProvider);
        const uid = auth.currentUser.uid;
        await deleteDoc(doc(db, 'veloUsers', uid));
        await deleteUser(auth.currentUser);
        localStorage.removeItem(pwKey());
        localStorage.removeItem(askKey());
        state.me = null;
        state.pendingGoogleUser = null;
        detachAllListeners();
        showScreen('screen-welcome');
        toast('Your Velo account has been deleted.');
      } catch (err) {
        if (err?.code === 'auth/popup-closed-by-user' || err?.code === 'auth/cancelled-popup-request') return;
        toast(friendlyAuthError(err));
      }
    }, 'Delete Forever');
  });
});

// ---------------------------------------------------------------------
// WhatsApp chat .zip import — imports locally into the open chat
// ---------------------------------------------------------------------
// =====================================================================
// SPLASH SCREEN — "Loading...." while the saved session is checked; if the
// device was logged in before it becomes "Loading Your Chats" + "n out of N".
// =====================================================================
const splashEl = byId('splash');
const splashStartedAt = Date.now();
const splashGuard = setTimeout(() => hideSplash(), 14000);   // never leave someone staring at the splash if the network is slow
function splashLoggedIn() {
  if (!splashEl.isConnected) return;
  byId('splashStatus').textContent = 'Loading Your Chats';
  byId('splashStatus').classList.add('steady');
  byId('splashProgress').classList.remove('hidden');
  splashProgress(0, 0);
}
function splashProgress(done, total) {
  if (!splashEl.isConnected) return;
  byId('splashCount').textContent = done + ' out of ' + total;
  byId('splashBar').style.width = (total ? Math.round(done / total * 100) : 100) + '%';
}
function hideSplash() {
  if (!splashEl.isConnected) return;
  clearTimeout(splashGuard);
  const wait = Math.max(0, 1200 - (Date.now() - splashStartedAt));
  setTimeout(() => {
    splashEl.classList.add('out');
    setTimeout(() => splashEl.remove(), 650);
  }, wait);
}

// =====================================================================
// ADD CONTACT — name, then find them by Velo ID / phone / @username with
// a live "Velo User ✓ / Not A Velo User ✗" check.
// =====================================================================
const ac = { mode: 'velo', found: null, seq: 0, timer: null };
const TICK_SVG = '<svg class="v-ico ok" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10" class="ring"/><path d="m7.5 12.5 3 3 6-7" class="mark"/></svg>';
const CROSS_SVG = '<svg class="v-ico bad" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10" class="ring"/><path d="m8.5 8.5 7 7M15.5 8.5l-7 7" class="mark"/></svg>';
function acQuery() {
  if (ac.mode === 'velo') {
    const v = byId('acVeloId').value;
    return v.length === 5 ? { mode: 'velo', value: v } : null;
  }
  if (ac.mode === 'phone') {
    const info = ccInfo(byId('acCc').value);
    const d = cleanPhone(byId('acPhone').value, info);
    return d.length >= info.min ? { mode: 'phone', value: info.c + ' ' + d } : null;
  }
  const u = byId('acUser').value.trim();
  return u.length >= 3 ? { mode: 'user', value: u.toLowerCase(), raw: u } : null;
}
function renderAcVerify(kind) {
  const el = byId('acVerify');
  const hints = {
    velo: 'Enter their 5-digit Velo ID.',
    phone: 'Enter their number without the leading 0 (' + phoneLenText(ccInfo(byId('acCc').value)) + ' digits).',
    user: 'Enter their user name.',
  };
  if (kind === 'idle') el.innerHTML = '<span class="v-hint">' + hints[ac.mode] + '</span>';
  else if (kind === 'checking') el.innerHTML = '<span class="v-spin"></span><span class="v-hint">Checking…</span>';
  else if (kind === 'ok') el.innerHTML = '<span class="v-ok">' + TICK_SVG + 'Velo User</span>';
  else if (kind === 'none') el.innerHTML = '<span class="v-bad">' + CROSS_SVG + 'Not A Velo User</span>';
  else if (kind === 'self') el.innerHTML = '<span class="v-bad">' + CROSS_SVG + "That's your own account</span>";
  else el.innerHTML = '<span class="v-bad">' + CROSS_SVG + "Couldn't check — connection problem</span>";
}
function updateAcButton() {
  const btn = byId('acAddBtn');
  btn.disabled = !ac.found;
  const exists = ac.found && chats[chatIdFor(state.me.uid, ac.found.id)];
  byId('acAddLabel').textContent = exists ? 'Open Chat' : 'Add Friend';
}
async function runAcLookup(q) {
  const seq = ++ac.seq;
  let user = null;
  try {
    if (q.mode === 'velo') user = await findUserByVeloId(q.value);
    else if (q.mode === 'phone') user = await findUserByPhone(q.value);
    else { user = await findUserByUsername(q.value); if (!user && q.raw !== q.value) user = await findUserByUsername(q.raw); }
  } catch (err) { console.error(err); if (seq === ac.seq) renderAcVerify('error'); return; }
  if (seq !== ac.seq) return;
  if (!user) { ac.found = null; renderAcVerify('none'); }
  else if (user.id === state.me.uid) { ac.found = null; renderAcVerify('self'); }
  else { ac.found = user; contacts[user.id] = user; renderAcVerify('ok'); }
  updateAcButton();
}
function scheduleAcLookup() {
  clearTimeout(ac.timer);
  ac.seq++; ac.found = null;
  const q = acQuery();
  updateAcButton();
  if (!q) { renderAcVerify('idle'); return; }
  renderAcVerify('checking');
  ac.timer = setTimeout(() => runAcLookup(q), 350);
}
function setAcMode(mode, focus = true) {
  ac.mode = mode;
  $$('#acSeg button').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  byId('acVeloWrap').classList.toggle('hidden', mode !== 'velo');
  byId('acPhoneWrap').classList.toggle('hidden', mode !== 'phone');
  byId('acUserWrap').classList.toggle('hidden', mode !== 'user');
  scheduleAcLookup();
  if (!focus) return;
  const focusId = mode === 'velo' ? 'acVeloId' : mode === 'phone' ? 'acPhone' : 'acUser';
  setTimeout(() => byId(focusId).focus(), 60);
}
function openAddContact() {
  ['acFirst', 'acLast', 'acVeloId', 'acPhone', 'acUser'].forEach(id => { byId(id).value = ''; });
  byId('acVeloCount').textContent = '0/5';
  try { const r = JSON.parse(localStorage.getItem('velo:region') || 'null'); if (r) byId('acCc').value = r.code; } catch (e) {}
  byId('acCc').dispatchEvent(new Event('change'));
  showScreen('screen-addcontact');
  setAcMode('velo', false);
  setTimeout(() => byId('acFirst').focus(), 120);
}
$$('#acSeg button').forEach(b => b.addEventListener('click', () => setAcMode(b.dataset.mode)));
byId('acVeloId').addEventListener('input', (e) => {
  e.target.value = e.target.value.replace(/\D/g, '').slice(0, 5);
  byId('acVeloCount').textContent = e.target.value.length + '/5';
  scheduleAcLookup();
});
byId('acUser').addEventListener('input', (e) => {
  e.target.value = e.target.value.replace(/^@+/, '').replace(/[^a-zA-Z0-9._]/g, '').slice(0, 24);
  scheduleAcLookup();
});
bindPhoneField('acPhone', 'acCc', scheduleAcLookup);
byId('addContactBack').addEventListener('click', () => goBack('screen-main'));
byId('chatListBody').addEventListener('click', (e) => { if (e.target.closest('#emptyAddBtn')) openAddContact(); });
byId('acAddBtn').addEventListener('click', async () => {
  const user = ac.found;
  if (!user) return;
  const first = byId('acFirst').value.trim(), last = byId('acLast').value.trim();
  if (!first) {
    const f = byId('acFirst').parentElement;
    f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake');
    byId('acFirst').focus(); toast("Enter your friend's first name");
    return;
  }
  const full = [first, last].filter(Boolean).join(' ');
  setBtnLoading(byId('acAddBtn'), true);
  try {
    contacts[user.id] = user;
    setContactNickname(user.id, full);
    const chat = await getOrCreateChat1to1(user.id);
    renderChatList(byId('chatSearch').value);
    toast(first + ' is ready to chat');
    openChat(chat.id);
  } catch (err) {
    console.error(err);
    toast('Could not add that friend — check your connection.');
  } finally { setBtnLoading(byId('acAddBtn'), false); }
});

// =====================================================================
// WhatsApp .zip import — asks "Who is <name>?" (Me / Friend) unless the
// friend is already saved under the same name, then writes the messages
// into the shared Firestore chat so BOTH people see them.
// =====================================================================
const imp = { file: null, chatId: null, parsed: null, names: [], roles: [] };
function openImportModal(targetChatId) {
  imp.chatId = targetChatId || null;
  imp.file = null;
  byId('importFileInput').value = '';
  byId('importDropLabel').textContent = 'Tap to choose a WhatsApp export .zip';
  byId('importDrop').classList.remove('has-file');
  showModal('importModal');
}
byId('closeImportModal').addEventListener('click', () => hideModal('importModal'));
byId('importFileInput').addEventListener('change', (e) => {
  imp.file = e.target.files[0] || null;
  if (imp.file) { byId('importDropLabel').textContent = imp.file.name; byId('importDrop').classList.add('has-file'); }
});
const WA_DT = String.raw`\[?(\d{1,4}[./-]\d{1,2}[./-]\d{1,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:\s?[AaPp]\.?\s?[Mm]\.?)?)\]?`;
const WA_FULL = new RegExp('^' + WA_DT + '\\s*[-\\u2013]?\\s*([^:]{1,60}?):\\s([\\s\\S]*)$');
const WA_DATE_ONLY = new RegExp('^' + WA_DT);
function parseWAStamp(dateStr, timeStr, order) {
  const p = dateStr.split(/[./-]/).map(n => parseInt(n, 10));
  let day, month, year;
  if (String(dateStr).split(/[./-]/)[0].length === 4) { [year, month, day] = p; }
  else if (order === 'mdy') { [month, day, year] = p; }
  else { [day, month, year] = p; }
  if (year < 100) year += 2000;
  const tm = String(timeStr || '').replace(/\./g, '').trim().match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp][Mm])?/);
  if (!tm) return NaN;
  let hour = parseInt(tm[1], 10);
  const min = parseInt(tm[2], 10), sec = parseInt(tm[3] || '0', 10);
  const ap = tm[4] ? tm[4].toLowerCase() : null;
  if (ap === 'pm' && hour < 12) hour += 12;
  if (ap === 'am' && hour === 12) hour = 0;
  const d = new Date(year, month - 1, day, hour, min, sec);
  return isNaN(d.getTime()) ? NaN : d.getTime();
}
// DD/MM vs MM/DD can't be read from one line, but across the whole file a value >12 settles it.
function detectDateOrder(lines) {
  let dmy = false, mdy = false;
  for (const l of lines) {
    const parts = l.date.split(/[./-]/);
    if (parts[0].length === 4) continue;
    const a = parseInt(parts[0], 10), b = parseInt(parts[1], 10);
    if (a > 12) dmy = true;
    if (b > 12) mdy = true;
  }
  return (mdy && !dmy) ? 'mdy' : 'dmy';
}
function parseWhatsAppExport(raw) {
  const text = raw.replace(/[\u200e\u200f\u202a-\u202e]/g, '').replace(/[\u202f\u00a0]/g, ' ');
  const out = [];
  let cur = null;
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(WA_FULL);
    if (m) { cur = { date: m[1], time: m[2], sender: m[3].trim(), text: m[4].trim() }; out.push(cur); }
    else if (WA_DATE_ONLY.test(line)) { cur = null; }            // system line ("Messages are encrypted…", "X added Y")
    else if (cur && line.trim()) cur.text += '\n' + line.trim();
  }
  const order = detectDateOrder(out);
  return out.map(m => Object.assign(m, { ms: parseWAStamp(m.date, m.time, order) })).filter(m => !isNaN(m.ms));
}
function waText(t) {
  if (/^<?media omitted>?$/i.test(t) || /^<attached:.*>$/i.test(t) || /\(file attached\)\s*$/i.test(t)) return '📎 Media (not included in the import)';
  return t;
}
const normName = (x) => String(x || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const sameName = (a, b) => { const x = normName(a), y = normName(b); return !!x && !!y && x === y; };
function friendNamesOf(chat) {
  const o = otherParticipant(chat);
  return [chatDisplayName(chat), o && o.name, o && contactNicknames[o.id], o && o.username].filter(Boolean);
}
function oneToOneChats() { return Object.values(chats).filter(c => !c.isGroup && otherParticipant(c)); }
byId('importConfirmBtn').addEventListener('click', async () => {
  if (!imp.file) { toast('Choose a .zip file first'); return; }
  if (typeof JSZip === 'undefined') { toast('Import library failed to load — check your connection'); return; }
  setBtnLoading(byId('importConfirmBtn'), true);
  try {
    const zip = await JSZip.loadAsync(imp.file);
    const entry = Object.values(zip.files).find(f => !f.dir && /\.txt$/i.test(f.name) && !/__MACOSX/.test(f.name));
    if (!entry) { toast('No chat .txt file found in that zip'); return; }
    const parsed = parseWhatsAppExport(await entry.async('string'));
    if (!parsed.length) { toast('Could not read any messages from that file'); return; }
    const counts = {};
    parsed.forEach(m => { counts[m.sender] = (counts[m.sender] || 0) + 1; });
    imp.names = Object.keys(counts).sort((x, y) => counts[y] - counts[x]).slice(0, 2);
    imp.parsed = parsed.filter(m => imp.names.includes(m.sender));
    imp.skipped = parsed.length - imp.parsed.length;
    hideModal('importModal');
    decideImportRoles();
  } catch (err) {
    console.error(err);
    toast('Could not read that zip file');
  } finally { setBtnLoading(byId('importConfirmBtn'), false); }
});
function decideImportRoles() {
  const names = imp.names;
  const pool = imp.chatId ? [chats[imp.chatId]].filter(Boolean) : oneToOneChats();
  if (!pool.length) { toast('Add your friend as a contact first, then import the chat.'); openAddContact(); return; }
  // friend already saved under the same name as in the zip -> no questions asked
  const hits = [];
  names.forEach((n, i) => pool.forEach(c => { if (friendNamesOf(c).some(x => sameName(x, n))) hits.push({ i, chat: c }); }));
  const hitIdx = [...new Set(hits.map(h => h.i))];
  let friendIdx = -1, chosen = null;
  if (names.length === 2 && hitIdx.length === 1 && (imp.chatId || hits.length === 1)) { friendIdx = hitIdx[0]; chosen = hits[0].chat; }
  else if (names.length === 2 && imp.chatId) {
    const meIdx = names.findIndex(n => sameName(n, state.me.name));
    if (meIdx > -1) { friendIdx = 1 - meIdx; chosen = pool[0]; }
  }
  if (friendIdx > -1) { imp.roles = names.map((_, i) => i === friendIdx ? 'friend' : 'me'); runImport(chosen.id); return; }
  openWhoModal(pool);
}
function openWhoModal(pool) {
  const names = imp.names;
  imp.roles = names.map(n => sameName(n, state.me.name) ? 'me' : null);
  if (names.length === 2 && imp.roles[0] === 'me') imp.roles[1] = 'friend';
  else if (names.length === 2 && imp.roles[1] === 'me') imp.roles[0] = 'friend';
  byId('importWhoSub').textContent = imp.skipped > 0
    ? 'This export has more than two people — Velo imports the two who wrote the most and skips ' + imp.skipped + ' other messages.'
    : 'Tell Velo which name is you and which is your friend.';
  byId('importWhoRows').innerHTML = names.map((n, i) => `
    <div class="who-row" data-i="${i}">
      <div class="who-q">Who is <b>${escapeHTML(n)}</b>?</div>
      <div class="seg who-seg"><button data-role="me">Me</button><button data-role="friend">Friend</button></div>
    </div>`).join('');
  const sel = byId('importTargetSelect');
  byId('importTargetWrap').classList.toggle('hidden', !!imp.chatId);
  sel.innerHTML = pool.map(c => `<option value="${c.id}">${escapeHTML(chatDisplayName(c))}</option>`).join('');
  if (imp.chatId) sel.value = imp.chatId;
  const paint = () => {
    $$('#importWhoRows .who-row').forEach(row => {
      const i = Number(row.dataset.i);
      $$('button', row).forEach(b => b.classList.toggle('active', b.dataset.role === imp.roles[i]));
    });
    byId('importWhoGo').disabled = names.length === 2 ? (imp.roles.includes(null) || !imp.roles.includes('me') || !imp.roles.includes('friend')) : !imp.roles[0];
  };
  $$('#importWhoRows .who-row').forEach(row => {
    const i = Number(row.dataset.i);
    $$('button', row).forEach(b => b.addEventListener('click', () => {
      imp.roles[i] = b.dataset.role;
      if (names.length === 2) imp.roles[1 - i] = b.dataset.role === 'me' ? 'friend' : 'me';
      paint();
    }));
  });
  paint();
  showModal('importWhoModal');
}
byId('importWhoCancel').addEventListener('click', () => hideModal('importWhoModal'));
byId('importWhoGo').addEventListener('click', () => {
  if (!imp.parsed) return;
  const chatId = imp.chatId || byId('importTargetSelect').value;
  hideModal('importWhoModal');
  runImport(chatId);
});
function fnv(str) { let h = 0x811c9dc5; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(36); }
async function runImport(chatId) {
  const chat = chats[chatId], other = chat && otherParticipant(chat);
  if (!chat || !other) { toast('Pick a one-to-one chat to import into.'); return; }
  const meName = imp.names[imp.roles.indexOf('me')];
  const msgs = imp.parsed.slice().sort((a, b) => a.ms - b.ms);
  const total = msgs.length;
  byId('importBar').style.width = '0%';
  byId('importCount').textContent = '0 / ' + total;
  showModal('importProgressModal');
  const seen = {}; let lastMs = -1, k = 0;
  const ids = [];
  let lastDoc = null;
  try {
    for (let i = 0; i < total; i += 400) {
      const batch = writeBatch(db);
      for (const m of msgs.slice(i, i + 400)) {
        k = (m.ms === lastMs) ? Math.min(k + 1, 999) : 0; lastMs = m.ms;
        const text = waText(m.text);
        const key = m.ms + '|' + m.sender + '|' + text;
        seen[key] = (seen[key] || 0) + 1;
        const id = 'wa_' + fnv(key + '|' + seen[key]) + fnv(seen[key] + '|' + text.length + '|' + m.sender);
        const from = (imp.roles.length && m.sender === meName) ? state.me.uid : other.id;
        batch.set(doc(db, 'chats', chatId, 'messages', id), {
          from, text, ts: Timestamp.fromMillis(m.ms + k), status: 'read',
          imported: true, importedBy: state.me.uid, importedName: m.sender,
        });
        ids.push(id);
        lastDoc = { from, text, ms: m.ms + k };
      }
      await batch.commit();
      const done = Math.min(i + 400, total);
      byId('importBar').style.width = Math.round(done / total * 100) + '%';
      byId('importCount').textContent = done + ' / ' + total;
    }
    const curTs = chat.lastMessage ? tsMillis(chat.lastMessage.ts) : 0;
    if (lastDoc && lastDoc.ms > curTs) {
      await updateDoc(doc(db, 'chats', chatId), { lastMessage: { text: lastDoc.text, ts: Timestamp.fromMillis(lastDoc.ms), from: lastDoc.from, imported: true } });
    }
    hideModal('importProgressModal');
    state.impAnim = { ids: new Set(ids.slice(-40)), until: Date.now() + 8000 };
    toast('Imported ' + total.toLocaleString() + ' messages — you and ' + (contactNicknames[other.id] || other.name).split(' ')[0] + ' can both see them');
    openChat(chatId);
  } catch (err) {
    console.error(err);
    hideModal('importProgressModal');
    toast(err && err.code === 'permission-denied' ? 'Firestore rules block imported messages — publish the updated firestore.rules.' : 'Import stopped — check your connection and try again.');
  }
}

// =====================================================================
// Search inside a chat
// =====================================================================
const csearch = { ids: [], idx: -1 };
function openInChatSearch() {
  byId('chatSearchBar').classList.remove('hidden');
  byId('inChatSearch').focus();
}
function closeInChatSearch() {
  byId('chatSearchBar').classList.add('hidden');
  byId('inChatSearch').value = '';
  byId('inChatSearchCount').textContent = '';
  csearch.ids = []; csearch.idx = -1;
  $$('#threadBody .flash').forEach(el => el.classList.remove('flash'));
}
function gotoSearchMatch() {
  const n = csearch.ids.length;
  byId('inChatSearchCount').textContent = n ? (csearch.idx + 1) + ' of ' + n : (byId('inChatSearch').value.trim() ? 'No results' : '');
  if (!n) return;
  $$('#threadBody .flash').forEach(el => el.classList.remove('flash'));
  const el = byId('threadBody').querySelector('[data-msg="' + csearch.ids[csearch.idx] + '"]');
  if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('flash'); }
}
function runInChatSearch() {
  const q = byId('inChatSearch').value.trim().toLowerCase();
  const chat = chats[state.currentChatId];
  if (!q || !chat) { csearch.ids = []; csearch.idx = -1; gotoSearchMatch(); return; }
  csearch.ids = chat.messages.filter(m => !m.system && previewText(m).toLowerCase().includes(q)).map(m => m.id);
  csearch.idx = csearch.ids.length - 1;
  gotoSearchMatch();
}
byId('openChatSearch').addEventListener('click', () => (byId('chatSearchBar').classList.contains('hidden') ? openInChatSearch() : closeInChatSearch()));
byId('inChatClose').addEventListener('click', closeInChatSearch);
byId('inChatSearch').addEventListener('input', runInChatSearch);
byId('inChatSearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') byId('inChatPrev').click(); });
byId('inChatPrev').addEventListener('click', () => { if (csearch.ids.length) { csearch.idx = (csearch.idx - 1 + csearch.ids.length) % csearch.ids.length; gotoSearchMatch(); } });
byId('inChatNext').addEventListener('click', () => { if (csearch.ids.length) { csearch.idx = (csearch.idx + 1) % csearch.ids.length; gotoSearchMatch(); } });

// =====================================================================
// Block / report / disappearing messages (profile screen)
// =====================================================================
function isBlocked(uid) { return !!(state.me && Array.isArray(state.me.blocked) && state.me.blocked.includes(uid)); }
function syncComposerBlocked(chat) {
  const peer = chat && !chat.isGroup ? otherParticipant(chat) : null;
  const blocked = !!(peer && isBlocked(peer.id));
  byId('msgInput').disabled = blocked;
  byId('msgInput').placeholder = blocked ? 'You blocked this contact' : 'Write a text....';
}
function syncProfileExtras(chat) {
  const peer = chat.isGroup ? null : otherParticipant(chat);
  byId('profileBlock').classList.toggle('hidden', !peer);
  byId('profileReport').classList.toggle('hidden', !peer);
  if (peer) byId('profileBlockLabel').textContent = isBlocked(peer.id) ? 'Unblock' : 'Block';
  const ms = chat.disappearMs || 0;
  byId('disappearSelect').value = String(ms);
  byId('disappearSub').textContent = ms ? 'New messages vanish after ' + (ms === 86400000 ? '24 hours' : ms === 604800000 ? '7 days' : '90 days') : 'Off';
}
byId('disappearSelect').addEventListener('change', async (e) => {
  const chatId = state.currentProfileId, chat = chats[chatId];
  if (!chat) return;
  const ms = Number(e.target.value);
  try {
    await updateDoc(doc(db, 'chats', chatId), { disappearMs: ms });
    chat.disappearMs = ms;
    await addDoc(collection(db, 'chats', chatId, 'messages'), { system: true, text: ms ? state.me.name + ' turned on disappearing messages' : state.me.name + ' turned off disappearing messages', ts: serverTimestamp() });
    syncProfileExtras(chat);
    toast(ms ? 'Disappearing messages on' : 'Disappearing messages off');
  } catch (err) { console.error(err); toast('Could not change that setting.'); syncProfileExtras(chat); }
});
setInterval(() => {   // keep expired messages from lingering while a chat is open
  const chat = chats[state.currentChatId];
  if (!chat || !chat.disappearMs) return;
  const cutoff = Date.now() - chat.disappearMs;
  const before = chat.messages.length;
  chat.messages = chat.messages.filter(m => m.system || m.ts >= cutoff);
  if (chat.messages.length !== before) renderThread();
}, 60000);
byId('profileBlock').addEventListener('click', () => {
  const chat = chats[state.currentProfileId], peer = chat && otherParticipant(chat);
  if (!peer) return;
  const blocked = isBlocked(peer.id), name = chatDisplayName(chat);
  confirmAction(blocked ? 'Unblock ' + name + '?' : 'Block ' + name + '?',
    blocked ? 'You will be able to message each other again.' : "You won't see their messages or get notifications, and you can't message them until you unblock.",
    async () => {
      try {
        await updateDoc(doc(db, 'veloUsers', state.me.uid), { blocked: blocked ? arrayRemove(peer.id) : arrayUnion(peer.id) });
        const list = (state.me.blocked || []).filter(x => x !== peer.id);
        state.me.blocked = blocked ? list : [...list, peer.id];
        syncProfileExtras(chat); syncComposerBlocked(chat); renderThread();
        toast(blocked ? name + ' unblocked' : name + ' blocked');
      } catch (err) { console.error(err); toast('Could not update the block list.'); }
    }, blocked ? 'Unblock' : 'Block');
});
byId('profileReport').addEventListener('click', () => showModal('reportModal'));
byId('reportCancel').addEventListener('click', () => hideModal('reportModal'));
byId('reportSend').addEventListener('click', async () => {
  const chat = chats[state.currentProfileId], peer = chat && otherParticipant(chat);
  if (!peer) return;
  setBtnLoading(byId('reportSend'), true);
  try {
    await addDoc(collection(db, 'reports'), { uid: state.me.uid, status: 'open', type: 'velo-user', reportedUid: peer.id, reportedVeloId: peer.veloId || '', chatId: chat.id, reason: byId('reportReason').value, createdAt: serverTimestamp() });
    hideModal('reportModal');
    toast('Report sent — thank you');
  } catch (err) { console.error(err); toast('Could not send the report.'); }
  finally { setBtnLoading(byId('reportSend'), false); }
});

// =====================================================================
// Polls
// =====================================================================
function addPollOptionField(value = '') {
  if ($$('#pollOptions input').length >= 5) { toast('Up to 5 options'); return; }
  const wrap = document.createElement('div');
  wrap.className = 'field'; wrap.style.marginBottom = '8px';
  wrap.innerHTML = '<input placeholder="Option" maxlength="60">';
  wrap.querySelector('input').value = value;
  byId('pollOptions').appendChild(wrap);
}
byId('attachPoll').addEventListener('click', () => {
  closeOpenSheet();
  byId('pollQuestion').value = '';
  byId('pollOptions').innerHTML = '';
  addPollOptionField(); addPollOptionField();
  showModal('pollModal');
});
byId('pollAddOpt').addEventListener('click', () => addPollOptionField());
byId('pollCancel').addEventListener('click', () => hideModal('pollModal'));
byId('pollSend').addEventListener('click', async () => {
  const question = byId('pollQuestion').value.trim();
  const options = $$('#pollOptions input').map(i => i.value.trim()).filter(Boolean);
  if (!question || options.length < 2) { toast('Add a question and at least 2 options'); return; }
  setBtnLoading(byId('pollSend'), true);
  const ok = await sendRichMessage({ kind: 'poll', question, options, votes: {} }, '📊 ' + question);
  setBtnLoading(byId('pollSend'), false);
  if (ok) hideModal('pollModal');
});

// header refresh must also respect blocked contacts + clear any open search
const _refreshChatHeader = refreshChatHeader;
refreshChatHeader = function (chatId) { _refreshChatHeader(chatId); syncComposerBlocked(chats[chatId]); };

// ---------------------------------------------------------------------
// boot — verify whether this device was logged in before.
//   no saved session  -> splash says "Loading....", then Welcome
//   saved session     -> splash says "Loading Your Chats  n out of N", then Chats
// ---------------------------------------------------------------------
let authReady = false;
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    detachAllListeners();
    state.me = null;
    if (!authReady) { authReady = true; hideSplash(); }
    return;
  }
  let snap = null, failed = false;
  try { snap = await getDoc(doc(db, 'veloUsers', user.uid)); } catch (e) { console.error(e); failed = true; }
  const hasProfile = !!(snap && snap.exists());
  if (hasProfile) state.me = Object.assign({ uid: user.uid }, snap.data());
  if (authReady) return;
  authReady = true;
  const verified = localStorage.getItem('velo:verified:' + user.uid) === '1';
  if (hasProfile && verified) {
    splashLoggedIn();
    enterApp({ onFirstLoad: hideSplash });
    return;
  }
  // Signed in with Google but never finished Velo sign-up/login (all steps + SMS code are required) -> start clean.
  state.me = null;
  if (failed) toast('Could not reach Velo — check your connection.');
  else signOut(auth).catch(() => {});
  hideSplash();
});

// Real viewport height, kept in sync with what's actually visible — the
// `dvh` CSS unit alone isn't reliably updated by every mobile browser on
// first paint (especially with body scrolling locked), so this is the
// belt-and-suspenders fix that makes the bottom nav sit flush every time.
function setRealVH() {
  document.documentElement.style.setProperty('--vh', (window.innerHeight * 0.01) + 'px');
}
setRealVH();
window.addEventListener('resize', setRealVH);
window.addEventListener('orientationchange', () => setTimeout(setRealVH, 60));

(function boot() {
  const savedTheme = localStorage.getItem('velo:theme') || 'dark';
  setTheme(savedTheme);
  const savedBackup = localStorage.getItem('velo:backup') || 'daily';
  $$('#backupSeg button').forEach(b => b.classList.toggle('active', b.dataset.backup === savedBackup));
})();

(function bootLayout() {
  document.body.classList.toggle('desk', isDesktop());
  const mqScheme = window.matchMedia('(prefers-color-scheme: light)');
  const onScheme = () => { if (document.body.getAttribute('data-theme') === 'system') setTheme('system'); };
  if (mqScheme.addEventListener) mqScheme.addEventListener('change', onScheme);
})();

byId('gwaitCancel').addEventListener('click', () => { googleAttempt++; hideModal('googleWaitModal'); $$('#googleSignInBtn, #googleSignInBtnReg, #googleEditBtn, #googleEditBtnReg').forEach(b => setBtnLoading(b, false)); });
byId('toggleLastSeen').addEventListener('change', () => presenceWrite(!document.hidden));
if (byId('profileEditRow')) byId('profileEditRow').addEventListener('click', editFriendName);
