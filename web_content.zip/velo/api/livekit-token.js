// Vercel serverless function — mints a LiveKit access token for a Velo call.
//
// Needs 3 environment variables (Vercel → Project → Settings → Environment Variables):
//   LIVEKIT_URL         wss://your-project.livekit.cloud
//   LIVEKIT_API_KEY     from the LiveKit dashboard
//   LIVEKIT_API_SECRET  from the LiveKit dashboard
// Optional: FIREBASE_PROJECT_ID (defaults to ksstudai-ksdev), ALLOWED_ORIGIN (defaults to any *.vercel.app / localhost)
//
// How it stays safe: the browser sends its Firebase sign-in token. This function asks
// Firestore — AS THAT USER — to read calls/{callId}. Your firestore.rules only let the
// two people in the call read it, so nobody can get a token for a room they aren't in.
// No npm packages are needed.

const crypto = require('crypto');

const b64u = (x) => Buffer.from(typeof x === 'string' ? x : JSON.stringify(x)).toString('base64url');

function makeLiveKitToken({ apiKey, apiSecret, identity, name, room, ttlSec }) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'HS256', typ: 'JWT' };
  const payload = {
    iss: apiKey,
    sub: identity,
    name: name || identity,
    nbf: now - 10,
    exp: now + (ttlSec || 7200),
    video: { room, roomJoin: true, canPublish: true, canSubscribe: true, canPublishData: true },
  };
  const body = b64u(header) + '.' + b64u(payload);
  const sig = crypto.createHmac('sha256', apiSecret).update(body).digest('base64url');
  return body + '.' + sig;
}

function allowOrigin(origin) {
  if (!origin) return '';
  if (process.env.ALLOWED_ORIGIN) return process.env.ALLOWED_ORIGIN.split(',').map(s => s.trim()).includes(origin) ? origin : '';
  return /^https:\/\/([a-z0-9-]+\.)*vercel\.app$/i.test(origin) || /^http:\/\/localhost(:\d+)?$/i.test(origin) ? origin : '';
}

module.exports = async function handler(req, res) {
  const origin = allowOrigin(req.headers.origin);
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });

  const { LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET } = process.env;
  if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET) {
    return res.status(500).json({ error: 'LiveKit is not set up on the server yet (missing LIVEKIT_URL / LIVEKIT_API_KEY / LIVEKIT_API_SECRET).' });
  }

  const idToken = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch (e) { body = {}; } }
  const callId = body && typeof body.callId === 'string' ? body.callId : '';
  if (!idToken || !/^[A-Za-z0-9_-]{6,64}$/.test(callId)) return res.status(400).json({ error: 'Missing sign-in token or call id.' });

  let uid = '';
  try {
    const claims = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64url').toString('utf8'));
    uid = String(claims.user_id || claims.sub || '');
  } catch (e) { return res.status(401).json({ error: 'Bad sign-in token.' }); }
  if (!uid) return res.status(401).json({ error: 'Bad sign-in token.' });

  // Firestore checks the token + your rules; a 200 means this user really is in this call.
  const project = process.env.FIREBASE_PROJECT_ID || 'ksstudai-ksdev';
  let doc;
  try {
    const r = await fetch('https://firestore.googleapis.com/v1/projects/' + project + '/databases/(default)/documents/calls/' + encodeURIComponent(callId), {
      headers: { Authorization: 'Bearer ' + idToken },
    });
    if (r.status === 401 || r.status === 403 || r.status === 404) return res.status(403).json({ error: "You're not part of this call." });
    if (!r.ok) return res.status(502).json({ error: 'Could not check the call (' + r.status + ').' });
    doc = await r.json();
  } catch (e) { return res.status(502).json({ error: 'Could not reach Firestore.' }); }

  const f = (doc && doc.fields) || {};
  const people = ((f.participants && f.participants.arrayValue && f.participants.arrayValue.values) || []).map(v => v.stringValue);
  const status = f.status && f.status.stringValue;
  if (!people.includes(uid)) return res.status(403).json({ error: "You're not part of this call." });
  if (['ended', 'declined', 'missed', 'busy', 'cancelled'].includes(status)) return res.status(410).json({ error: 'This call has already finished.' });

  const token = makeLiveKitToken({ apiKey: LIVEKIT_API_KEY, apiSecret: LIVEKIT_API_SECRET, identity: uid, name: (body.name || '').toString().slice(0, 60), room: callId });
  return res.status(200).json({ token, url: LIVEKIT_URL });
};
module.exports.makeLiveKitToken = makeLiveKitToken;
