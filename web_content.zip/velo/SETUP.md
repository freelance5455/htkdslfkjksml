# Velo — setup (everything in one folder)

Files:  index.html · app.js · style.css · firestore.rules · mainimg.png · icons/ · api/livekit-token.js
All screens live inside **index.html** (single page, nothing split into separate pages).

## 1) Upload
Put the whole folder in your Vercel project (keep the `api/` and `icons/` folders as they are).

## 2) Firebase — publish the rules
Firebase console → Firestore Database → Rules → paste `firestore.rules` → Publish.
(This now includes the `calls` rules that voice/video calling needs.)

## 3) LiveKit — voice & video calls
1. Make a free project at https://cloud.livekit.io
2. Settings → Keys → copy the **URL** (wss://…livekit.cloud), **API Key**, **API Secret**
3. Vercel → your project → Settings → Environment Variables → add:
   - `LIVEKIT_URL`         = wss://your-project.livekit.cloud
   - `LIVEKIT_API_KEY`     = (your key)
   - `LIVEKIT_API_SECRET`  = (your secret)
4. Redeploy once so the function picks them up.

The secret stays on the server. The browser only receives a short-lived token, and
`api/livekit-token.js` only issues one to the two people inside that call.

## 4) Try it
Open Velo on two devices with two accounts → open a chat → tap the phone or camera icon at the top.
