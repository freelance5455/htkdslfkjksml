(() => {
  'use strict';

  /* ---------- Ayarlar ---------- */
  const PASS_OK = '1221';
  const PASS_TRAP = '2012';
  const LOCK_MS = 60 * 1000;
  const SPEAK_MS = 11 * 1000;
  const LOCK_KEY = 'jarvis_lock_until';
  const TRAP_TEXT = 'Doğru şifrə. Amma Bu giriş üz simasından "Zorlama ilə giriş" kimi qiymətləndirildi, və kameraya baxdığımda yaxında bu mesajlara baxmaq istəyən şəxslər görürəm, giriş 1 dəqiqəliyinə əngəlləndi!';

  const $ = (id) => document.getElementById(id);
  const el = {
    title: $('title'), reactor: $('reactor'), form: $('form'), pass: $('pass'),
    go: $('go'), msg: $('msg'), lockBox: $('lockBox'), count: $('count'),
    users: document.querySelectorAll('.user'),
  };
  let user = null;
  let timer = null;

  /* ---------- Başlıq: daktilo + glitch ---------- */
  const TITLE = 'Kimsiz?';
  el.title.dataset.text = TITLE;
  let n = 0;
  (function type() {
    el.title.textContent = TITLE.slice(0, ++n);
    if (n < TITLE.length) setTimeout(type, 150);
    else el.title.classList.add('glitch');
  })();

  /* ---------- Səs + reaktor animasiyası ---------- */
  const audio = new Audio('Sounds/PrivateMesseageGIRIS.mp3');
  audio.preload = 'auto';
  let speakTimer;
  const speak = (on) => el.reactor.classList.toggle('speaking', on);

  audio.addEventListener('playing', () => {
    speak(true);
    clearTimeout(speakTimer);
    speakTimer = setTimeout(() => speak(false), SPEAK_MS); // ilk 11 saniyə
  });
  ['ended', 'pause', 'error'].forEach((ev) => audio.addEventListener(ev, () => speak(false)));

  // Brauzer avtomatik səsi əngəlləsə, ilk toxunuşda başlat (Android WebView-da
  // setMediaPlaybackRequiresUserGesture(false) verilsə birbaşa işləyəcək).
  const unlockAudio = () => {
    ['pointerdown', 'keydown'].forEach((e) => removeEventListener(e, unlockAudio));
    audio.play().catch(() => {});
  };
  audio.play().catch(() => {
    ['pointerdown', 'keydown'].forEach((e) => addEventListener(e, unlockAudio));
  });

  /* ---------- Yardımçılar ---------- */
  const say = (text, type) => { el.msg.textContent = text; el.msg.className = 'msg ' + (type || ''); };
  const getUntil = () => { try { return +localStorage.getItem(LOCK_KEY) || 0; } catch (e) { return 0; } };
  const setUntil = (t) => { try { localStorage.setItem(LOCK_KEY, String(t)); } catch (e) {} };
  const setDisabled = (off) => {
    el.go.disabled = el.pass.disabled = off;
    el.users.forEach((b) => (b.disabled = off));
  };

  /* ---------- Kilid (60 saniyə) ---------- */
  function startLock(until) {
    document.body.classList.add('alert');
    setDisabled(true);
    say(TRAP_TEXT, 'trap');
    el.lockBox.hidden = false;
    clearInterval(timer);
    const tick = () => {
      const s = Math.ceil((until - Date.now()) / 1000);
      if (s <= 0) return endLock();
      el.count.textContent = s;
    };
    tick();
    timer = setInterval(tick, 250);
  }

  function endLock() {
    clearInterval(timer);
    setUntil(0);
    document.body.classList.remove('alert');
    el.lockBox.hidden = true;
    setDisabled(false);
    say('Giriş paneli yenidən aktivdir.', 'ok');
    el.pass.focus();
  }

  /* ---------- Nəticələr ---------- */
  function success() {
    document.body.classList.add('ok');
    setDisabled(true);
    say('Giriş təsdiqləndi. Xoş gəldiniz, ' + user + '.', 'ok');
    try { sessionStorage.setItem('jarvis_user', user); } catch (e) {}
    setTimeout(() => { window.location.href = 'message.html'; }, 1600);
  }

  function trap() {
    const until = Date.now() + LOCK_MS;
    setUntil(until);
    startLock(until);
  }

  function fail() {
    say('Səhv şifrə! Keçid rədd edildi.', 'err');
    el.form.classList.remove('shake');
    void el.form.offsetWidth; // animasiyanı yenidən başlat
    el.form.classList.add('shake');
    el.pass.focus();
  }

  /* ---------- Hadisələr ---------- */
  el.users.forEach((b) => b.addEventListener('click', () => {
    user = b.dataset.user;
    el.users.forEach((x) => {
      x.classList.toggle('active', x === b);
      x.setAttribute('aria-checked', String(x === b));
    });
    el.pass.focus();
  }));

  el.form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (Date.now() < getUntil()) return;               // kilidli
    if (!user) return say('Əvvəlcə istifadəçini seçin!', 'err');
    const v = el.pass.value.trim();
    el.pass.value = '';
    if (v === PASS_OK) success();
    else if (v === PASS_TRAP) trap();
    else fail();
  });

  // Səhifə yenilənsə belə kilid davam etsin
  const pending = getUntil();
  if (pending > Date.now()) startLock(pending);
})();
