# Project State — SSC PYQ Bank

- **Current version:** 1.7.8
- **Product label:** SSC PYQ Bank
- **Project type:** Android-friendly Progressive Web App (PWA) source project
- **Master baseline:** V1.7.0 is an incremental modification of the V1.6.0 project. V1.0.0 was consulted only for the one-click Display Mode toggle interaction and sun/moon icon pattern; V1.0.0 was not used as the codebase or edited.
- **Version continuity:** Existing navigation, search, themes, palettes, local preferences, assets, and offline PWA behavior are retained.

## V1.7.0 original dashboard design (historical; revised in V1.7.6)

1. **The original Home design had ten tiles** grouped into three sections:
   - Subjects: Mathematics, English, Reasoning, General Studies.
   - Performance Overview: Attempted Questions, Correct Questions, Incorrect Questions, Bookmarked Questions.
   - More: Achievements, Progress Report.
2. **Viewport fit:** The original ten-tile Home layout used the available viewport height below the top bar. This layout was superseded in V1.7.6.
3. **Subject composition:** The four subjects use enlarged, sharp-corner rectangular strips in a 2-column × 2-row layout, with names on the left and theme-adaptive icons on the right.
4. **Performance Overview composition:** Each icon is top-right, the number alone is vertically centred at left, and the designation is bottom-left.
5. **More tile composition:** Each symbol is top-right and its label is bottom-left.
6. **Display Mode:** Moved to Settings → Appearance. A single click toggles the current Light/Dark setting, updates the app and browser colour scheme, updates the sun/moon icon state, and persists the existing `ssc-theme` preference. This adopts only the one-click toggle mechanism from V1.0.0.
7. **Theme:** The five existing colour palettes remain in Appearance, in their existing list style with the left colour swatch and right selected-state indicator.
8. **Navigation and versioning:** Achievements and Progress Report have dynamic titles and individual placeholder destinations. About shows Version 1.7.8. Service-worker cache key is `ssc-personal-practice-v1.7.8`.
9. **Regression checks:** Tests cover the four Home Subject strips, removal of the Performance Overview and More sections from Home, Settings → Appearance hierarchy, one-click theme switching and persistence, all five palettes, navigation, search and voice fallback, retained placeholder routes, legacy bookmark routing, and V1.7.8 PWA cache metadata.

## V1.7.4 visual refinement (retained)

- Kept the slim strip styling introduced in V1.7.2, but arranged the four Subject strips in a two-column by two-row grid.
- Each strip remains 42px high (40px on screens 360px wide or narrower), with the same compact padding, 27px icon container, left-aligned subject name, and right-aligned theme-adaptive icon.
- The Subjects section now sizes to the two compact rows; strips do not stretch vertically into large cards.
- Performance Overview, More, themes, navigation, and all other app behavior remain unchanged.

## V1.7.8 Home typography and spacing refinement

- Increased subject-name text from 15px to 16px on standard screens and from 13.5px to 14.5px on narrow screens.
- Increased the gap between subject strips from 10px to 13px on standard screens and from 9px to 11px on narrow screens.
- Strip dimensions, section position, icons, navigation, drawer, search, settings, themes, and functionality remain unchanged.
- About version and service-worker cache key updated to V1.7.8.

## V1.7.7 Home spacing refinement

- Shifted the complete Subjects section down by 8px, moving its heading and all four strips together.
- Increased the grid gap between strips from 8px to 10px (9px on screens 360px wide or narrower).
- No other layout, navigation, drawer, search, settings, themes, or functionality changed.
- About version and service-worker cache key updated to V1.7.7.

## V1.7.6 Home dashboard refinement

- Home now displays only the Subjects section; Performance Overview and More are removed from the Home dashboard.
- Subject strips remain in a 2-column × 2-row grid, with sharp square corners, equal spacing, left-aligned names, and theme-adaptive icons on the right.
- Increased strip height from 42px to 50px (48px on screens 360px wide or narrower), with slightly larger text and icons.
- Preserved the top navigation bar, hamburger menu, every drawer option, search, Settings, themes, and all other app screens and behavior.
- Kept the existing Performance Overview, Achievements, and Progress Report placeholder destinations in the code for compatibility, but they are no longer displayed on Home.

## V1.7.5 visual refinement

- Changed only the four Subject controls on Home from rounded tiles to slim, sharp rectangular strips.
- Retained the compact 2-column × 2-row layout, 42px height (40px on screens 360px wide or narrower), compact padding, left-aligned names, and right-aligned theme-adaptive icons.
- Removed corner curves and shadows from the Subject strips; the subject icons no longer have a rounded background badge.
- Performance Overview and More remain unchanged, as do the top navigation bar, hamburger menu and all drawer options, search controls, settings, themes, and all other screens and behavior.

## Display structure

| Section | Items | Content arrangement |
|---|---:|---|
| Subjects | 4 strips | Enlarged sharp rectangular strips; name left, symbol right |
| Performance Overview | Removed from Home | Legacy placeholder destinations retained |
| More | Removed from Home | Legacy placeholder destinations retained |

## Preserved functionality

- Dynamic top-bar page titles; Home hamburger drawer; back arrow on inner screens.
- Drawer entries: Home, Settings, About.
- Five palettes: Red, Blue, Purple, Green, Amber.
- Theme and Display Mode settings are stored locally; palette selection and display mode remain independent.
- Chapter search replaces the top bar and includes a Back arrow, text input, and voice dictation when supported.
- PWA manifest, launcher icons, and offline service-worker shell.
- Legacy `#bookmarkedQuestions` links still resolve to Bookmarked Questions.

## Scope limits

- Performance Overview counters are static zeros; question database, attempt tracking, and bookmark storage are not implemented.
- Achievements and Progress Report are placeholder screens only. Their rules, calculations, data views, and visual reports are future work.
- Chapter-name search requires a chapter/topic catalogue to become functional.
- Voice dictation depends on browser support and microphone permission.
- The deliverable is a PWA project, not a signed native APK or Android Studio project.
- Physical Android-device testing has not been performed in this build session.

## Validation

- `node --check app.js`
- `node tests/smoke-test.js`
- ZIP archive integrity checked before delivery.

## Next-version continuity rule

Use V1.7.8 as the single master baseline. For later versions, inspect and modify this project rather than rebuilding. Preserve finished functionality and local preference keys, change only what is requested, update the service-worker cache version, and revise this state file and tests.
