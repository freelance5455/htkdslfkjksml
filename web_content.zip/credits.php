<?php
declare(strict_types=1);
require_once __DIR__.'/app/auth.php';
require_once __DIR__.'/app/payments.php';
$user=auth_require_user();payments_schema();
$packages=db()->query("SELECT id,name,description,price_minor,credits,currency,promo_badge,bonus_credits FROM credit_packages WHERE is_active=1 ORDER BY sort_order ASC,price_minor ASC")->fetchAll();
$wallet=voice_wallet_balance((int)$user['id']);$orders=db()->prepare('SELECT reference,amount_minor,currency,credits,status,created_at FROM payment_orders WHERE user_id=? ORDER BY id DESC LIMIT 15');$orders->execute([(int)$user['id']]);$orders=$orders->fetchAll();
$cfg=payment_gateway_config();$base=rtrim(str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/'))),'/');if($base==='.')$base='';
$pageTitle='Buy credits';
require __DIR__.'/app/platform_header.php';
$e=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
?>
<section class="page-hero"><div><span class="page-kicker">CREDIT WALLET</span><h1>Buy credits</h1><p>Choose a package. Credits are added only after server-side Flutterwave verification.</p></div></section>
<section class="data-panel"><div class="data-panel-head"><h2>Available balance</h2><strong><?=number_format($wallet)?> credits</strong></div><p id="paymentNotice" class="muted-copy" role="status"></p>
<?php if(isset($_GET['status'])&&isset($_GET['tx_ref'])): ?><p class="muted-copy">Confirming your payment securely…</p><?php endif; ?>
<?php if(!$cfg['enabled']): ?><p class="muted-copy">Credit purchases are not currently enabled. Please contact support.</p><?php elseif(!$packages): ?><p class="muted-copy">No credit packages are currently available.</p><?php else: ?><div class="dashboard-quick-grid"><?php foreach($packages as $pk): ?><article class="data-panel"><span class="page-kicker"><?=number_format((int)$pk['credits'])?> CREDITS</span><h2><?=$e($pk['name'])?></h2><?php if(!empty($pk['promo_badge'])): ?><span class="page-kicker"><?=$e($pk['promo_badge'])?></span><?php endif; ?><p><?=$e($pk['description'])?></p><p><?=number_format((int)$pk['credits'])?> credits · ₦<?=number_format(((int)$pk['price_minor']/100)/max(1,(int)$pk['credits']+(int)$pk['bonus_credits']),2)?> per credit<?php if((int)$pk['bonus_credits']>0): ?> · +<?=number_format((int)$pk['bonus_credits'])?> bonus<?php endif; ?></p><strong><?= $e($pk['currency']) ?> <?=number_format((int)$pk['price_minor']/100,2)?></strong><button type="button" class="admin-button primary buy-credit" data-package="<?=$e($pk['id'])?>">Continue to payment</button></article><?php endforeach; ?></div><?php endif; ?></section>
<section class="data-panel"><div class="data-panel-head"><h2>Recent purchases</h2><span>Latest 15</span></div><div class="table-wrap"><table class="studio-table"><thead><tr><th>Reference</th><th>Amount</th><th>Credits</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($orders as $o): ?><tr><td><?=$e($o['reference'])?></td><td><?=$e($o['currency'])?> <?=number_format((int)$o['amount_minor']/100,2)?></td><td><?=number_format((int)$o['credits'])?></td><td><?=$e($o['status'])?></td><td><?=$e($o['created_at'])?></td></tr><?php endforeach; ?></tbody></table></div></section>
<script>
(()=>{const api=<?=json_encode(($base===''?'':$base).'/api/payments.php')?>;const csrf=<?=json_encode(csrf_token())?>;const notice=document.getElementById('paymentNotice');const set=(m)=>{if(notice)notice.textContent=m;};
document.querySelectorAll('.buy-credit').forEach(btn=>btn.addEventListener('click',async()=>{btn.disabled=true;set('Preparing secure checkout…');try{const r=await fetch(api,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({package_id:Number(btn.dataset.package)})});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Could not start payment.');location.href=d.checkout_url;}catch(e){set(e.message);btn.disabled=false;}}));
const params=new URLSearchParams(location.search);const ref=params.get('tx_ref'),tx=params.get('transaction_id');if(ref&&tx){set('Verifying your Flutterwave transaction…');fetch(api+'?tx_ref='+encodeURIComponent(ref)+'&transaction_id='+encodeURIComponent(tx),{credentials:'same-origin'}).then(r=>r.json().then(d=>({ok:r.ok,d}))).then(({ok,d})=>{if(!ok||!d.ok)throw new Error(d.error||'Payment verification failed.');set(d.credited?'Payment verified. '+d.credits+' credits have been added.':'Payment already verified. Your wallet is up to date.');}).catch(e=>set(e.message));}
})();
</script>
<?php require __DIR__.'/app/platform_footer.php'; ?>
