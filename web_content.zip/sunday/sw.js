/* Sunday Challengers — Service Worker
   - Offline app shell cache
   - Firebase Cloud Messaging (background push) */

const CACHE_VERSION = 'sc-v1';
const SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192x192.png',
  './icon-512x512.png',
  './apple-touch-icon-180.png',
  './favicon-32x32.png'
];

/* ---------- Firebase background push ---------- */
try {
  importScripts('https://www.gstatic.com/firebasejs/12.11.0/firebase-app-compat.js');
  importScripts('https://www.gstatic.com/firebasejs/12.11.0/firebase-messaging-compat.js');
  firebase.initializeApp({
    apiKey: "AIzaSyCnaTU1UXgOJI7MEiXQ1kPR4ryhBiRvDwE",
    authDomain: "sunday-challengers-ce171.firebaseapp.com",
    databaseURL: "https://sunday-challengers-ce171-default-rtdb.firebaseio.com",
    projectId: "sunday-challengers-ce171",
    storageBucket: "sunday-challengers-ce171.firebasestorage.app",
    messagingSenderId: "117767095608",
    appId: "1:117767095608:web:f833a48296c5c2317f2dcd"
  });
  firebase.messaging(); // FCM shows notification-payload messages automatically
} catch (e) {
  console.warn('FCM init skipped in SW:', e);
}

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) {
        if ('focus' in c) return c.focus();
      }
      return self.clients.openWindow('./');
    })
  );
});

/* ---------- Install / activate ---------- */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then((cache) => Promise.all(SHELL.map((u) => cache.add(u).catch(() => {}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* ---------- Fetch ---------- */
const STATIC_CDN = ['cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com', 'www.gstatic.com'];

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Page navigations: network first, fall back to cached shell (offline)
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((c) => c.put('./index.html', copy));
          return res;
        })
        .catch(() => caches.match('./index.html').then((r) => r || caches.match('./')))
    );
    return;
  }

  // Same-origin static files: cache first, refresh in background
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const net = fetch(req).then((res) => {
          if (res && res.ok) {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
          }
          return res;
        }).catch(() => cached);
        return cached || net;
      })
    );
    return;
  }

  // Static CDN assets (fonts, icons, firebase SDK): stale-while-revalidate
  if (STATIC_CDN.includes(url.hostname)) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const net = fetch(req).then((res) => {
          if (res && (res.ok || res.type === 'opaque')) {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
          }
          return res;
        }).catch(() => cached);
        return cached || net;
      })
    );
  }
  // Everything else (Firebase Realtime DB etc.) goes straight to network
});
