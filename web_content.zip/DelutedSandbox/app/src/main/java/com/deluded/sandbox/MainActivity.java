package com.deluded.sandbox;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Deluded Sandbox Android shell.
 * Hosts a LAN game server (WebSocket relay on port 27015) and broadcasts the
 * server over UDP (port 27016) so other phones on the same Wi-Fi or hotspot
 * can see it in the LAN server list. Works with no internet.
 */
public class MainActivity extends Activity {
    static final int GAME_PORT = 27015;
    static final int ANNOUNCE_PORT = 27016;

    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Socket> clients = new CopyOnWriteArrayList<>();
    private volatile ServerSocket serverSock;
    private volatile boolean hosting, listening;
    private volatile String sName = "Server", sMap = "city", sMode = "sandbox";
    private volatile DatagramSocket listenSock;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Methods the web page can call as window.Android.* */
    public class Bridge {
        @JavascriptInterface public void quit() { ui.post(MainActivity.this::finish); }
        @JavascriptInterface public String hostStart(String name, String map, String mode) { return startHost(name, map, mode); }
        @JavascriptInterface public void hostStop() { stopHost(); }
        @JavascriptInterface public void discover(boolean on) { if (on) startListening(); else stopListening(); }
        @JavascriptInterface public String localIp() { return lanIp(); }
    }

    // ---------------- host ----------------
    String startHost(String name, String map, String mode) {
        if (hosting) return lanIp();
        String ip = lanIp();
        if (ip == null) return "";
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress("0.0.0.0", GAME_PORT));
            serverSock = ss;
            sName = name; sMap = map; sMode = mode;
            hosting = true;
            new Thread(this::acceptLoop, "ds-accept").start();
            new Thread(this::announceLoop, "ds-announce").start();
            return ip;
        } catch (IOException e) {
            return "";
        }
    }

    void stopHost() {
        hosting = false;
        try { if (serverSock != null) serverSock.close(); } catch (IOException ignored) {}
        for (Socket c : clients) { try { c.close(); } catch (IOException ignored) {} }
        clients.clear();
    }

    void acceptLoop() {
        while (hosting) {
            try {
                Socket c = serverSock.accept();
                new Thread(() -> serveClient(c), "ds-client").start();
            } catch (IOException e) {
                break;
            }
        }
    }

    void serveClient(Socket c) {
        try {
            c.setTcpNoDelay(true);
            InputStream in = c.getInputStream();
            OutputStream out = c.getOutputStream();

            // WebSocket handshake
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            byte[] end = {'\r', '\n', '\r', '\n'};
            int matched = 0;
            while (matched < 4) {
                int x = u8(in);
                hb.write(x);
                matched = (x == end[matched]) ? matched + 1 : (x == end[0] ? 1 : 0);
            }
            String req = new String(hb.toByteArray(), StandardCharsets.UTF_8);
            String key = null;
            for (String line : req.split("\r\n")) {
                if (line.toLowerCase().startsWith("sec-websocket-key:")) key = line.substring(18).trim();
            }
            if (key == null) { c.close(); return; }
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            String accept = android.util.Base64.encodeToString(
                md.digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.UTF_8)),
                android.util.Base64.NO_WRAP);
            out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            out.flush();

            clients.add(c);
            sendText(c, helloJson());

            // frame loop
            while (true) {
                int b0 = u8(in), b1 = u8(in);
                int op = b0 & 0x0F;
                boolean masked = (b1 & 0x80) != 0;
                long len = b1 & 0x7F;
                if (len == 126) {
                    len = (u8(in) << 8) | u8(in);
                } else if (len == 127) {
                    len = 0;
                    for (int i = 0; i < 8; i++) len = (len << 8) | u8(in);
                }
                byte[] mask = new byte[4];
                if (masked) readFully(in, mask);
                byte[] data = new byte[(int) len];
                readFully(in, data);
                if (masked) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
                if (op == 0x8) break;                        // close
                if (op == 0x9) send(c, 0xA, data);           // ping -> pong
                else if (op == 0x1) broadcast(c, new String(data, StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
        } finally {
            clients.remove(c);
            try { c.close(); } catch (IOException ignored) {}
        }
    }

    String helloJson() {
        try {
            return new JSONObject().put("t", "hello").put("name", sName).put("map", sMap).put("mode", sMode).toString();
        } catch (Exception e) { return "{\"t\":\"hello\"}"; }
    }

    void broadcast(Socket from, String msg) {
        byte[] d = msg.getBytes(StandardCharsets.UTF_8);
        for (Socket c : clients) {
            if (c == from) continue;
            try { send(c, 1, d); } catch (IOException e) { clients.remove(c); }
        }
    }

    // ---------------- server list (UDP broadcast) ----------------
    void announceLoop() {
        try (DatagramSocket ds = new DatagramSocket()) {
            ds.setBroadcast(true);
            while (hosting) {
                String msg = announceJson();
                if (msg != null) {
                    byte[] d = msg.getBytes(StandardCharsets.UTF_8);
                    for (InetAddress a : broadcastAddrs()) {
                        try { ds.send(new DatagramPacket(d, d.length, a, ANNOUNCE_PORT)); } catch (IOException ignored) {}
                    }
                }
                Thread.sleep(1000);
            }
        } catch (Exception ignored) {}
    }

    String announceJson() {
        try {
            return new JSONObject()
                .put("name", sName).put("ip", lanIp()).put("port", GAME_PORT)
                .put("map", sMap).put("mode", sMode)
                .put("n", Math.max(0, clients.size() - 1)).toString();
        } catch (Exception e) { return null; }
    }

    List<InetAddress> broadcastAddrs() {
        List<InetAddress> out = new ArrayList<>();
        try { out.add(InetAddress.getByName("255.255.255.255")); } catch (Exception ignored) {}
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getBroadcast() != null) out.add(ia.getBroadcast());
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    void startListening() {
        if (listening) return;
        listening = true;
        new Thread(() -> {
            try {
                DatagramSocket ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.bind(new InetSocketAddress(ANNOUNCE_PORT));
                listenSock = ds;
                byte[] buf = new byte[1024];
                while (listening) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    ds.receive(p);
                    String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                    final String js = "if(window.onLanServer)window.onLanServer(" + JSONObject.quote(msg) + ")";
                    ui.post(() -> web.evaluateJavascript(js, null));
                }
            } catch (Exception ignored) {}
        }, "ds-listen").start();
    }

    void stopListening() {
        listening = false;
        DatagramSocket ds = listenSock;
        if (ds != null) ds.close();
        listenSock = null;
    }

    // ---------------- helpers ----------------
    /** Best IPv4 address on Wi-Fi or hotspot (private range). Null if none. */
    String lanIp() {
        String best = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName();
                if (n.startsWith("rmnet") || n.startsWith("tun") || n.startsWith("ccmni")) continue;
                boolean pref = n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap");
                for (java.net.InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof java.net.Inet4Address) || a.isLoopbackAddress() || !a.isSiteLocalAddress()) continue;
                    if (best == null || pref) best = a.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return best;
    }

    static int u8(InputStream in) throws IOException {
        int x = in.read();
        if (x < 0) throw new EOFException();
        return x;
    }

    static void readFully(InputStream in, byte[] b) throws IOException {
        int o = 0;
        while (o < b.length) {
            int r = in.read(b, o, b.length - o);
            if (r < 0) throw new EOFException();
            o += r;
        }
    }

    static void send(Socket c, int op, byte[] d) throws IOException {
        ByteArrayOutputStream h = new ByteArrayOutputStream();
        h.write(0x80 | op);
        if (d.length < 126) {
            h.write(d.length);
        } else if (d.length < 65536) {
            h.write(126); h.write(d.length >> 8); h.write(d.length & 255);
        } else {
            h.write(127);
            for (int i = 7; i >= 0; i--) h.write((int) (((long) d.length >>> (8 * i)) & 255));
        }
        synchronized (c) {
            OutputStream o = c.getOutputStream();
            o.write(h.toByteArray());
            o.write(d);
            o.flush();
        }
    }

    static void sendText(Socket c, String s) throws IOException {
        send(c, 1, s.getBytes(StandardCharsets.UTF_8));
    }

    // ---------------- Activity lifecycle ----------------
    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { stopHost(); stopListening(); super.onDestroy(); }
}
