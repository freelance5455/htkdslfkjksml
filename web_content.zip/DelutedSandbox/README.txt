DELUDED SANDBOX - Android Studio project (fully offline, LAN multiplayer)

three.js is embedded in app/src/main/assets/index.html. No download needed.

BUILD
1. Open this folder in Android Studio (Hedgehog or newer) and let Gradle sync.
2. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
3. Install on your phone (allow "install unknown apps").

LAN MULTIPLAYER (no internet needed)
- HOST: turn on Wi-Fi or a phone hotspot. Menu > Play > Multiplayer > Host Game.
  Pick a name, map and gamemode, then Start Hosting. The IP shows in Settings.
- JOIN: other phones on the SAME Wi-Fi or hotspot open Multiplayer > Join Game.
  The server appears in the list. If it doesn't, type the host's IP and tap Add IP.
- Hotspot: the host's hotspot IP is usually 192.168.43.1 (shown in Settings).

NOTE: Converter-made APKs (HTML-to-APK apps) can JOIN servers by IP, but cannot
HOST, because they don't include this native server code. Hosting needs this build.
