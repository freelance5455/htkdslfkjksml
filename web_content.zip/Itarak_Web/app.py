from flask import Flask, render_template, request, redirect
import json
from pathlib import Path
from datetime import datetime
app=Flask(__name__)
DATA=Path(__file__).with_name("itarak_web_data.json")
def load():
    if not DATA.exists(): save({"products":[],"customers":[],"sales":[],"orders":[],"cash":[],"employees":[]})
    try: return json.loads(DATA.read_text(encoding="utf-8"))
    except: return {"products":[],"customers":[],"sales":[],"orders":[],"cash":[],"employees":[]}
def save(d): DATA.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8")
@app.route("/")
def home(): return render_template("index.html",d=load())
@app.route("/add/<kind>",methods=["POST"])
def add(kind):
    d=load(); x=dict(request.form); x["created_at"]=datetime.now().strftime("%Y-%m-%d %H:%M")
    if kind=="sale":
        q=float(x.get("qty") or 0); p=float(x.get("price") or 0); disc=float(x.get("discount") or 0)
        x["total"]=round(q*p*(1-disc/100),2)
    if kind in d: d[kind].append(x)
    save(d); return redirect("/")
@app.route("/delete_sales",methods=["POST"])
def delete_sales():
    d=load(); d["sales"]=[]; save(d); return redirect("/")
if __name__=="__main__": app.run(host="0.0.0.0",port=5000)
