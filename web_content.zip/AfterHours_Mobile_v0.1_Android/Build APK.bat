@echo off
setlocal EnableExtensions
cd /d "%~dp0"
color 0B
cls
echo ==================================================
echo     AFTERHOURS MOBILE 0.1 - BUILD DEBUG APK
 echo ==================================================
echo.
echo Requires Android Studio SDK / Build Tools installed.
echo Internet required the first time for Gradle dependencies.
echo.
where java >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Java not found. Install Android Studio with its bundled JDK.
  pause
  exit /b 1
)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT (
  if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT (
  echo [ERROR] Android SDK not found. Install Android Studio and its SDK first.
  pause
  exit /b 1
)
set "GRADLE_BASE=%LOCALAPPDATA%\AfterHoursMobileBuild"
set "GRADLE_HOME=%GRADLE_BASE%\gradle-8.9"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo [1/3] Downloading the official Gradle 8.9 distribution...
  if not exist "%GRADLE_BASE%" mkdir "%GRADLE_BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '%GRADLE_BASE%\gradle-8.9.zip'; Expand-Archive '%GRADLE_BASE%\gradle-8.9.zip' -DestinationPath '%GRADLE_BASE%' -Force"
  if errorlevel 1 (
    echo [ERROR] Could not download Gradle. Check your connection.
    pause
    exit /b 1
  )
)
echo [2/3] Compiling AfterHours Mobile...
call "%GRADLE_HOME%\bin\gradle.bat" assembleDebug --no-daemon
if errorlevel 1 (
  echo [ERROR] Build failed. Review errors above; ensure Android SDK API 35 is installed.
  pause
  exit /b 1
)
echo [3/3] Done! APK:
echo %~dp0app\build\outputs\apk\debug\app-debug.apk
echo.
echo Copy the APK to your Android phone and install it manually.
pause
