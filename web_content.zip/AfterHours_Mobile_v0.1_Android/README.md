# AFTERHOURS MOBILE — v0.1 (Android starter)

This is a **real Android project**, separate from the Windows desktop app. It is a *first test build*, not a compiled APK, production release, or proven streaming integration. It uses a small native Java WebView shell with a bundled HTML/CSS/JS UI. No cloud account, backend server, or Twitch developer key is required to open the app.

## The first version contains

- Three compact portrait-oriented POV slots (switchable to two).
- Official Kick iframe players using `https://player.kick.com/<channel>` (tap play per player).
- Chat station at the bottom using KickCX's `https://chat.kick.cx/embed/<channel>`; select the chat tab corresponding to a stream.
- Twitch channel slots with **open externally** playback/chat fallback, rather than a misleading non-working tiny embed.
- Tap `⤢` to focus a stream; tap `◱` to go back to all streams. Hiding/focusing a tile does not deliberately rebuild its iframe, but Android may pause small or hidden players.
- Persistent channels, two/three-slot preference, chat channel selection, and chat visibility, all stored on the phone. No desktop sync yet.
- The app does not capture logins or credentials; external channel links open via another app/browser.

## Build it on Windows

1. **Install Android Studio** (free) from https://developer.android.com/studio . On its first start, allow it to install the Android SDK and **Android SDK Platform 35** (Android 15), if not already installed. Use the current supported Android SDK Build Tools.
2. Install **JDK 17+** if `java` is not already on your PATH. Java bundled with Android Studio is fine if added to PATH.
3. Extract this project folder somewhere, such as Desktop.
4. Double-click **`Build APK.bat`**. The script downloads official Gradle 8.9 on first run, then executes `assembleDebug`. It needs internet to resolve Google/Gradle Maven plugins. Android SDK must be installed already.
5. On success, the file will be `app\build\outputs\apk\debug\app-debug.apk`. Transfer this debug APK to your Samsung and open it to install (Android may ask permission to install from that source).

### Alternative: Android Studio

Open the extracted folder as a Gradle Android project in Android Studio. The project uses Android Gradle Plugin 8.7.3 / Gradle 8.9 and compileSdk 35. If Android Studio asks for a Gradle distribution, select Gradle 8.9. Build the **debug** APK. This zip deliberately omits large SDK and Gradle binaries; it is a source project, not a pre-built installation file.

## Preview the mobile interface before compiling

On a computer, open `previews/AfterHours-Mobile-v0.1.html` in Chrome. You can add/remove channels and try the compact layout. Online embeds may not function when this preview is opened through `file://`; test the actual streaming inside the installed Android app. The preview is *not* an APK.

## Known limits (important)

- **Twitch** official embedded players require minimum 400 x 300 CSS pixels and a verified SSL host with the right `parent` parameter. Three tiny Twitch video panels on a phone cannot meet this, so this starter only opens Twitch externally. https://dev.twitch.tv/docs/embed/video-and-clips/
- **Kick** official player supports iframe embeddeding with `autoplay=false` and `muted=true` as of May 2026. On Android, one may need to tap Play on each video; device WebView restrictions or Kick changes could still block/stop some streams. https://help.kick.com/en/articles/8010826-how-to-embed-your-kick-livestream
- **KickCX chat** is third-party, not officially part of Kick. It supports an embed, but embedded Google/Kick account sign-in may not work in Android WebView. Use **Open ↗** to open Kick in your normal browser for chat, if needed. https://chat.kick.cx/
- All Kick videos initially load muted to avoid simultaneous sound; change volume using the Kick player controls. A reliable instant single-audio-source switch without player reload has **not** been implemented yet.
- No Android APK is included here because this environment doesn't have the Android SDK or Gradle compiler. The project has not been run on a physical phone yet; playback is unverified.
- No desktop-to-mobile account sync, streaming background audio service, automatic follow import, or multi-account chat authorization. Those require later iterations.

## Folder map

`app/src/main/assets/index.html` — complete phone UI + local save state; edit this first for visual changes.

`app/src/main/java/com/afterhours/mobile/MainActivity.java` — native Android WebView host with audio, full-screen, and external browser handling.

`app/src/main/AndroidManifest.xml` — Android package and internet permission.

`Build APK.bat` — one-click Windows build helper once Android Studio SDK is installed.

## Project safety

The app runs JavaScript only from its locally bundled UI and uses third-party Kick/KickCX iframes. Android native wrapper does not expose a JavaScript-to-native bridge. Main-frame navigation is restricted to original Kick/Twitch site links which open outside this app. Local room settings only are stored via Android WebView storage. No user credentials or tokens are held by AfterHours itself.
