package com.afterhours.mobile;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * AfterHours Mobile v0.1: a lightweight native Android shell around a
 * bundled, offline-available UI. The streamed media and chat need internet.
 *
 * No credentials or app-specific tokens are collected by AfterHours.
 */
public class MainActivity extends Activity {
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net/";
    private FrameLayout root;
    private WebView webView;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 13, 18));
        getWindow().setNavigationBarColor(Color.rgb(11, 13, 18));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 13, 18));
        setContentView(root);

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true); // Mobile: tap to play.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        webView.setBackgroundColor(Color.rgb(11, 13, 18));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri uri = request.getUrl();
                if (APP_ORIGIN.equals(uri.toString())) return false;
                // For security, avoid making AfterHours a general-purpose web browser.
                if ("https".equalsIgnoreCase(uri.getScheme()) &&
                        isApprovedHost(uri.getHost())) {
                    openExternal(uri);
                    return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullScreenView != null) { callback.onCustomViewHidden(); return; }
                fullScreenView = view;
                fullScreenCallback = callback;
                webView.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
            }
            @Override
            public void onHideCustomView() { dismissFullScreen(); }
        });

        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[8192];
            int count;
            while ((count = input.read(chunk)) != -1) bytes.write(chunk, 0, count);
            String html = bytes.toString(StandardCharsets.UTF_8.name());
            // Gives localStorage a stable HTTPS origin without deploying a server.
            // Twitch official player is intentionally NOT embedded in three tiny tiles.
            webView.loadDataWithBaseURL(APP_ORIGIN, html, "text/html", "UTF-8", null);
        } catch (Exception exception) {
            Toast.makeText(this, "AfterHours UI could not load", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isApprovedHost(String host) {
        if (host == null) return false;
        switch (host.toLowerCase(Locale.ROOT)) {
            case "kick.com":
            case "www.kick.com":
            case "twitch.tv":
            case "www.twitch.tv":
                return true;
            default:
                return false;
        }
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "No browser can open this channel", Toast.LENGTH_LONG).show();
        }
    }

    private void dismissFullScreen() {
        if (fullScreenView == null) return;
        root.removeView(fullScreenView);
        fullScreenView = null;
        webView.setVisibility(View.VISIBLE);
        if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden();
        fullScreenCallback = null;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (fullScreenView != null) { dismissFullScreen(); return; }
        webView.evaluateJavascript("window.AFTERHOURS_BACK ? window.AFTERHOURS_BACK() : false", result -> {
            if (!"true".equals(result)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) { super.onConfigurationChanged(newConfig); }
    @Override
    protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
    @Override
    protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
    @Override
    protected void onDestroy() {
        if (fullScreenView != null) dismissFullScreen();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
