# Password recovery setup (v11)

This version uses Supabase's token-hash email flow. The reset email template must link to the public password-reset Edge Function with the token hash and recovery type.

## 1. Deploy the Edge Function

Function name:
`password-reset`

Use:
`supabase/functions/password-reset/index.ts`

Disable JWT verification for this function:
`supabase/config.toml`

```
[functions.password-reset]
verify_jwt = false
```

## 2. Configure Auth Redirect URLs

Keep this URL in Authentication -> URL Configuration -> Redirect URLs:

`https://iflqwjnyfgxkhfmsrqlq.supabase.co/functions/v1/password-reset`

The app deep link is:

`dpm://reset-password`

## 3. IMPORTANT: Update the Reset Password email template

Go to Authentication -> Email Templates -> Reset Password.

Replace the reset-password link with:

```html
<a href="{{ .RedirectTo }}?token_hash={{ .TokenHash }}&type=recovery">
  Reset your password
</a>
```

This is intentional. The Edge Function needs the token hash in the query string; URL fragments are not sent to the server.

## 4. Test

Login -> Forgot password -> enter email -> open the new email -> tap Reset your password.

The browser should hand the `dpm://reset-password?...` redirect to the Android app, which will verify the token hash and show the New Password screen.
