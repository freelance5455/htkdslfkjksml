import { osirisModule } from "../osiris/module.js";
import { antiTifanwoModule } from "../anti-tifanwo/module.js";
import { emitIntegrationEvent, onIntegrationEvent } from "../integration/bridge.js";

const view = document.querySelector("#view");
const bridgeMessage = document.querySelector("#bridge-message");
const modules = { osiris: osirisModule, anti: antiTifanwoModule };

function card(title, description, index) {
  return `<article class="card"><span class="number">MODULE ${String(index+1).padStart(2,"0")}</span><h3>${title}</h3><p>${description}</p><button class="action" data-open="${title}">Open workspace</button></article>`;
}
function show(which="home") {
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===which));
  if(which==="home"){
    view.innerHTML = `<div class="cards">${card("OSIRIS CODE AI","Rogue AI assistant, science, observatory, music/media, video, games, mobility and evolution console.",0)}${card("ANTI-TIFANWO","Cyberpunk city, MINXX style controls, privacy architecture and project connection.",1)}</div>`;
  } else {
    const mod = modules[which];
    view.innerHTML = `<p class="kicker">${mod.id.toUpperCase()} WORKSPACE</p><h2>${mod.title}</h2><div class="cards">${mod.sections.map((s,i)=>card(s[0],s[1],i)).join("")}</div>`;
  }
}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>show(b.dataset.view)));
view.addEventListener("click",e=>{
  const btn=e.target.closest("[data-open]");
  if(!btn)return;
  const project=btn.dataset.open;
  emitIntegrationEvent("workspace-opened",{project});
});
onIntegrationEvent("workspace-opened",e=>{
  bridgeMessage.textContent = `${e.detail.project} workspace selected in this demo.`;
});
show();
