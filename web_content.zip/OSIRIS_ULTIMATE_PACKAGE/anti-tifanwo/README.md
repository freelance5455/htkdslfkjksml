# ANTI-TIFANWO

This folder remains a separate project. Its demo sections cover the cyberpunk city concept, MINXX style controls, privacy architecture and integration status.
