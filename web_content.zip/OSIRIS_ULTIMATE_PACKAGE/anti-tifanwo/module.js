export const antiTifanwoModule = {
  id: "anti-tifanwo",
  title: "ANTI-TIFANWO",
  sections: [
    ["Cyberpunk City", "Concept workspace for districts, places and world-building."],
    ["MINXX Style Controls", "Demo controls for visual themes and interface styling."],
    ["Privacy Architecture", "Privacy-by-design notes and security checklist."],
    ["OSIRIS Connection", "Integration placeholder; projects remain separately maintained."]
  ]
};
