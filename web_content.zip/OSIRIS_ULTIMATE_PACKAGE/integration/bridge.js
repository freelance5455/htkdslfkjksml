export function emitIntegrationEvent(name, detail = {}) {
  window.dispatchEvent(new CustomEvent(`project:${name}`, { detail }));
}
export function onIntegrationEvent(name, callback) {
  const eventName = `project:${name}`;
  window.addEventListener(eventName, callback);
  return () => window.removeEventListener(eventName, callback);
}
