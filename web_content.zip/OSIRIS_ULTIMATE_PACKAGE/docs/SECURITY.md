# Security checklist before public launch

- Keep AI provider keys and private credentials on a server, never in browser source.
- Add authentication and authorization before storing personal data.
- Use HTTPS for all hosted deployments.
- Validate and rate-limit server requests.
- Provide clear privacy, data-retention and account-deletion information.
- Do not claim that a prototype provides unhackable, invisible, or unrestricted access.
