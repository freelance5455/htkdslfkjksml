# App-maker import guide

- Use **Import Project**, **Upload ZIP**, or **Import from GitHub**.
- If the builder asks for a folder, extract the ZIP first and upload the project root.
- If it asks for a web entry point, use `web/index.html`.
- If it asks for a build command, this static starter does not require one.
- If it requires a framework-specific project, this plain HTML/JS starter may need adaptation.

A PWA is a website that can be installed from a compatible browser; it is not an APK. An APK requires a separate Android packaging/build step.
