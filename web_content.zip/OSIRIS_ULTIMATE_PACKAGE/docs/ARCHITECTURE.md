# Architecture

OSIRIS and ANTI-TIFANWO are intentionally independent modules. The integration bridge sends named browser events; neither project owns the other's internal state.

## OSIRIS module
- Rogue AI assistant interface placeholder
- Science and observatory workspace
- Music and media workspace
- Video workspace
- Games hub
- Mobility workspace
- Evolution console roadmap

## ANTI-TIFANWO module
- Cyberpunk city workspace
- MINXX style controls
- Privacy and security information
- Integration status placeholder

## Integration
Use `integration/bridge.js` to publish and subscribe to cross-project events. Replace demo event handlers with authenticated backend APIs when adding real accounts or shared data.
