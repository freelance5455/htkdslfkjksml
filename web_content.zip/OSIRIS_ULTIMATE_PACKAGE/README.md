# OSIRIS CODE AI + ANTI-TIFANWO — Ultimate Starter Package

**Package type:** modular web/PWA starter source  
**Version:** 1.1.0

This is a newly reconstructed starter package based on the project direction available in the conversation. It is not a byte-for-byte recovery of earlier ZIPs or a completed production AI service.

## What is included
- `web/`: responsive dashboard, navigation, local demo interactions, installable PWA manifest and offline cache
- `osiris/`: separate OSIRIS CODE AI module with sections for Rogue AI assistant, science/observatory, music/media, video, games, mobility and an evolution console roadmap
- `anti-tifanwo/`: separate ANTI-TIFANWO module with cyberpunk city, MINXX style controls, privacy architecture notes and a connection placeholder
- `integration/`: event-based bridge. The projects remain separate and communicate through this integration layer.
- `docs/`: architecture, app-maker import guide and security notes

## Run
For a quick preview, open `web/index.html`. For PWA install and service-worker caching, serve the `web` directory over HTTPS or localhost.

## Import
1. Download and extract this ZIP.
2. In your app maker, choose **Import ZIP / Upload project** if supported.
3. If the app maker only imports GitHub, create a repository and upload the extracted folder contents.
4. Set the app's entry point to `web/index.html` or configure the app maker to serve the `web` directory.

## Important
The AI assistant is a UI/demo placeholder. To make it answer with an AI model, connect a backend endpoint and keep API keys on the server. Do not place secret keys in client-side JavaScript. Features such as live chat, accounts, cloud sync, payments, messaging, or real-time data need their own backend and provider setup.
