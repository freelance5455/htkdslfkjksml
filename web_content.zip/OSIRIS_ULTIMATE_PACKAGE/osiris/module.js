export const osirisModule = {
  id: "osiris",
  title: "OSIRIS CODE AI",
  sections: [
    ["Rogue AI", "Assistant interface demo. Connect a secure server-side AI endpoint to enable model responses."],
    ["Science & Observatory", "Workspace for notes, discoveries and sky/space learning tools."],
    ["Music & Media", "Organize original projects and media links."],
    ["Video Studio", "Creative video planning workspace; connect a video provider separately."],
    ["Games Hub", "A home for game concepts and supported game links."],
    ["Mobility", "Planning area for mobility and transport concepts."],
    ["Evolution Console", "Project progress, milestones and version notes."]
  ]
};
