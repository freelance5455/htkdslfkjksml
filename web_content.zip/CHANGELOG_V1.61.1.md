# v1.61.1 — Respostas de imprensa e coletivas de clássicos

- Cada pergunta agora apresenta cinco respostas selecionáveis: humilde, confiante, provocadora, sincera e profissional.
- As respostas sinceras consideram o resultado e o peso de clássico quando aplicável.
- Respostas provocadoras geram repercussão específica na imprensa e entre as torcidas.
- Efeitos das respostas passam a influenciar reputação, moral, confiança, aprovação da torcida e confiança do treinador.
- Coletivas de clássicos priorizam perguntas próprias para vitória, empate ou derrota.
- Em clássicos, as perguntas também consideram se o atleta atuou e seus gols, assistências, cartões e nota.
- Jogador que não entrou em campo recebe perguntas sobre o banco, preparação e disputa por espaço; não recebe perguntas sobre desempenho individual.
- Mantido o fluxo de coletiva pós-jogo e a escolha manual do jogador.

## Validação
- Sintaxe JavaScript validada com `node --check`.
- Teste isolado da geração de coletiva: três perguntas e cinco respostas por pergunta, em clássico e jogo comum.
- Testes gerais existentes apresentam falhas anteriores/independentes nesta base (marcador do motor, dados de elenco e validação de temporada); não foram alterados por esta entrega.
