# A10 Smart Desktop (launcher para o projetor A10)

Launcher Android: a interface é a página `app/src/main/assets/index.html` (WebView)
e o código Kotlin entrega a ela os **apps reais instalados** no aparelho.
Sem bibliotecas externas. Funciona em Android 13 de 32 bits.

## Gerar o APK
1. Instale o Android Studio e abra esta pasta (File > Open). Aguarde o Gradle Sync.
2. Build > Build APK(s). O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.
3. Passe para o projetor (pendrive/ADB) e instale.

## Usar
- Aperte **Home** no controle e escolha A10 Smart Desktop > Sempre.
- Menu Iniciar: lista todos os apps instalados (inclusive de Android TV), com busca.
- Tecla **Menu** do controle: abre o Iniciar; sobre um ícone, abre as opções
  (fixar na área de trabalho/barra, informações, desinstalar). No toque: segurar o ícone.
- **Instalar APK**: no menu Iniciar. Na primeira vez o Android pede para permitir
  "instalar apps desconhecidos" para o A10.
- Personalizar: papel de parede, cor, tamanho dos ícones, relógio. Notas e Calculadora em janelas.
- Voltar ao launcher original: Configurações > Apps > Apps padrão > Aplicativo de tela inicial.

## Editar depois
- Visual e funções: `app/src/main/assets/index.html`.
- Ponte com o Android (abrir apps, instalar, desinstalar): `HomeActivity.kt`.
