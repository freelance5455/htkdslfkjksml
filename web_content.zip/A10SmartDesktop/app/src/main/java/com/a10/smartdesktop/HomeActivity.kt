package com.a10.smartdesktop

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Launcher: a interface é a página assets/index.html (WebView) e esta classe
 * entrega a ela os apps REAIS instalados e sabe abri-los, instalar APKs, etc.
 */
class HomeActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var repo: AppRepo
    private val reqApk = 51

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            sendApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = AppRepo(this)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportZoom(false)
        web.addJavascriptInterface(Bridge(), "A10")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return true
                if (u.startsWith("file:///android_asset/")) return false
                openExternal(u)
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        val filter = IntentFilter()
        filter.addAction(Intent.ACTION_PACKAGE_ADDED)
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED)
        filter.addAction(Intent.ACTION_PACKAGE_REPLACED)
        filter.addDataScheme("package")
        registerReceiver(pkgReceiver, filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        web.destroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        web.evaluateJavascript("window.onBack&&window.onBack()", null)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Launcher não fecha com Voltar: só fecha menus.
        web.evaluateJavascript("window.onBack&&window.onBack()", null)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqApk && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) installUri(uri)
        }
    }

    // ------------------------------------------------------------ ponte JS <-> Android

    private inner class Bridge {
        @JavascriptInterface
        fun requestApps() {
            sendApps()
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            runOnUiThread {
                val a = repo.find(pkg)
                if (a == null) {
                    toast("App não encontrado")
                } else {
                    try {
                        startActivity(a.launch)
                    } catch (e: Exception) {
                        toast("Não foi possível abrir ${a.label}")
                    }
                }
            }
        }

        @JavascriptInterface
        fun info(pkg: String) {
            ext(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        }

        @JavascriptInterface
        fun uninstall(pkg: String) {
            ext(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            openExternal(url)
        }

        @JavascriptInterface
        fun installApk() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(i, reqApk)
                } catch (e: Exception) {
                    toast("Nenhum seletor de arquivos encontrado")
                }
            }
        }
    }

    private fun sendApps() {
        Thread {
            try {
                repo.load()
                val arr = JSONArray()
                for (a in repo.apps) {
                    val o = JSONObject()
                    o.put("p", a.pkg)
                    o.put("n", a.label)
                    o.put("i", iconData(a.icon))
                    arr.put(o)
                }
                val js = "window.onApps(" + arr.toString() + ")"
                runOnUiThread {
                    if (!isDestroyed) web.evaluateJavascript(js, null)
                }
            } catch (e: Throwable) {
            }
        }.start()
    }

    private fun iconData(d: Drawable): String {
        val size = 64
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, size, size)
        d.draw(Canvas(bmp))
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun installUri(uri: Uri) {
        if (!packageManager.canRequestPackageInstalls()) {
            toast("Permita instalar apps desconhecidos para o A10 e tente de novo")
            ext(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ext(i)
    }

    private fun openExternal(url: String) {
        ext(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun ext(i: Intent) {
        runOnUiThread {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
                toast("Este aparelho não tem um app para essa ação")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
