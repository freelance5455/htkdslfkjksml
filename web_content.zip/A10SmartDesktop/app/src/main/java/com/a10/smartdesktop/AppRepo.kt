package com.a10.smartdesktop

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

class AppEntry(val pkg: String, val label: String, val icon: Drawable, val launch: Intent)

/** Lista os apps instalados (celular/tablet e também apps de Android TV). */
class AppRepo(private val context: Context) {

    @Volatile
    var apps: List<AppEntry> = emptyList()
        private set

    fun load() {
        val pm = context.packageManager
        val out = LinkedHashMap<String, AppEntry>()
        val categories = arrayOf(Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER)
        for (cat in categories) {
            val query = Intent(Intent.ACTION_MAIN)
            query.addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName || out.containsKey(pkg)) continue
                val launch = Intent(Intent.ACTION_MAIN)
                launch.addCategory(cat)
                launch.setClassName(pkg, ri.activityInfo.name)
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                out[pkg] = AppEntry(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), launch)
            }
        }
        apps = out.values.sortedBy { it.label.lowercase() }
    }

    fun find(pkg: String): AppEntry? = apps.firstOrNull { it.pkg == pkg }
}
