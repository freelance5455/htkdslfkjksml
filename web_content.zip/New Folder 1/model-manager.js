// Provedores online (API compatível com OpenAI) e modelo local.
// Pollinations atual: https://gen.pollinations.ai/v1/chat/completions
export const PRESETS = {
  pollinations: {
    url: 'https://gen.pollinations.ai/v1/chat/completions',
    model: 'openai/gpt-5.4-nano'
  },
  huggingface: {
    url: 'https://router.huggingface.co/v1/chat/completions',
    model: 'Qwen/Qwen2.5-7B-Instruct'
  },
  custom: { url: '', model: '' }
};

const CDN = 'https://cdn.jsdelivr.net/npm/@wllama/wllama@2.3.1/esm/';
let W;
export const localReady = () => !!W;

export async function loadLocal(onp) {
  if (W) return;
  const { Wllama } = await import(CDN + 'index.js');
  const w = new Wllama({
    'single-thread/wllama.wasm': CDN + 'single-thread/wllama.wasm',
    'multi-thread/wllama.wasm': CDN + 'multi-thread/wllama.wasm'
  });
  await w.loadModelFromHF(
    'Qwen/Qwen2.5-0.5B-Instruct-GGUF',
    'qwen2.5-0.5b-instruct-q4_k_m.gguf',
    { n_ctx: 2048, progressCallback: ({ loaded, total }) => onp && onp(total ? loaded / total : 0) }
  );
  W = w;
}

function extractDelta(payload) {
  const delta = payload?.choices?.[0]?.delta?.content;
  if (typeof delta === 'string') return delta;
  if (Array.isArray(delta)) {
    return delta.map(part => typeof part === 'string' ? part : (part?.text || '')).join('');
  }
  return '';
}

export async function chat(cfg, msgs, onText, signal) {
  if (cfg.mode === 'offline') {
    if (!W) throw new Error('O modelo offline ainda não foi carregado.');
    return W.createChatCompletion(msgs, {
      nPredict: 400,
      sampling: { temp: 0.6 },
      abortSignal: signal,
      onNewToken: (token, piece, fullText) => onText(fullText)
    });
  }

  if (!cfg.url) throw new Error('Configure a URL do provedor nas configurações.');
  if (cfg.preset === 'pollinations' && !cfg.key) {
    throw new Error('A Pollinations exige uma chave de API. Abra Configurações e informe sua chave pessoal.');
  }

  const headers = { 'Content-Type': 'application/json', 'Accept': 'text/event-stream' };
  if (cfg.key) headers.Authorization = 'Bearer ' + cfg.key;

  const body = {
    model: cfg.model || PRESETS.pollinations.model,
    messages: msgs,
    stream: true,
    max_tokens: 400
  };

  const response = await fetch(cfg.url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal,
    cache: 'no-store'
  });

  if (!response.ok) {
    let detail = '';
    try {
      const data = await response.json();
      detail = data?.error?.message || data?.message || JSON.stringify(data);
    } catch {
      try { detail = await response.text(); } catch {}
    }
    if (response.status === 401) throw new Error('Chave da Pollinations ausente ou inválida. Confira a chave nas configurações.');
    if (response.status === 402) throw new Error('A chave foi reconhecida, mas não há saldo/orçamento disponível para essa solicitação.');
    if (response.status === 429) throw new Error('O provedor recebeu muitas solicitações. Aguarde um pouco e tente novamente.');
    throw new Error(`Erro HTTP ${response.status}${detail ? ': ' + detail.slice(0, 240) : ''}`);
  }

  if (!response.body) throw new Error('Este navegador não disponibilizou o fluxo de resposta. Tente uma versão atualizada do Chrome.');

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let output = '';
  let finished = false;

  const processEvent = eventText => {
    const data = eventText.split('\n')
      .filter(line => line.startsWith('data:'))
      .map(line => line.slice(5).trim())
      .join('\n');
    if (!data || data === '[DONE]') {
      if (data === '[DONE]') finished = true;
      return;
    }
    try {
      const payload = JSON.parse(data);
      const delta = extractDelta(payload);
      if (delta) {
        output += delta;
        onText(output);
      }
      if (payload?.choices?.[0]?.finish_reason) finished = true;
    } catch {
      // Ignora eventos SSE de metadados que não sejam JSON de conteúdo.
    }
  };

  try {
    while (!finished) {
      if (signal?.aborted) throw new DOMException('Geração cancelada', 'AbortError');
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
      const events = buffer.split('\n\n');
      buffer = events.pop() || '';
      for (const eventText of events) processEvent(eventText);
    }
    buffer += decoder.decode();
    if (buffer.trim()) processEvent(buffer);
  } finally {
    if (signal?.aborted) reader.cancel().catch(() => {});
    reader.releaseLock();
  }

  if (!output.trim()) throw new Error('O modelo não retornou texto. Verifique o modelo escolhido e tente novamente.');
  return output;
}
