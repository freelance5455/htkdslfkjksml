// Interpretação de intenção, ferramentas (memória, calculadora, data/hora) e montagem do prompt.
import*as M from './memory.js';import{chat}from './model-manager.js';
export const PERSONA='Você é a GabxAI, assistente pessoal do usuário. Responda em português do Brasil, de forma natural e direta. Se não souber algo, diga claramente que não sabe, sem inventar.';
const calc=e=>{if(!/^[\d\s+\-*/().,%^]+$/.test(e))return null;try{const v=Function('"use strict";return('+e.replace(/,/g,'.').replace(/\^/g,'**')+')')();return Number.isFinite(v)?String(v):null}catch{return null}};
export function intent(t){let m;
 if(m=t.match(/^\s*(?:lembre(?:-se)?|memorize|guarde)\s+(?:que\s+)?(.+)/i))return{type:'remember',arg:m[1]};
 if(m=t.match(/^\s*(?:esque[cç]a|apague da mem[oó]ria)\s+(.+)/i))return{type:'forget',arg:m[1]};
 if(m=t.match(/^\s*(?:calcule|quanto [eé])\s+([\d\s+\-*/().,%^]+?)\s*\??\s*$/i)){const r=calc(m[1]);if(r)return{type:'calc',arg:m[1],res:r}}
 return{type:'chat'}}
export async function reply(cfg,history,text,onText,signal){
 const it=intent(text);let note='';
 if(it.type==='remember'){await M.remember(it.arg);note='O usuário pediu para memorizar: "'+it.arg+'". Já foi salvo; confirme em uma frase.'}
 if(it.type==='forget'){const[m]=await M.recall(it.arg,1);if(m){await M.del('mems',m.id);note='Memória apagada: "'+m.text+'". Confirme em uma frase.'}else note='Nenhuma memória correspondente foi encontrada. Informe isso.'}
 if(it.type==='calc')note='Resultado da calculadora: '+it.arg+' = '+it.res+'. Use exatamente esse valor.';
 const useMem=cfg.mode==='offline'||cfg.sendMem;
 const mem=useMem?(await M.recall(text)).map(m=>'- '+m.text).join('\n'):'';
 const sys=[cfg.persona||PERSONA,'Data e hora atuais: '+new Date().toLocaleString('pt-BR'),mem&&'Memórias autorizadas do usuário:\n'+mem,note].filter(Boolean).join('\n\n');
 return chat(cfg,[{role:'system',content:sys},...history.slice(-12),{role:'user',content:text}],onText,signal)}
