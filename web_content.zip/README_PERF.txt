====================================================================
REGNUM / WORLD CONQUEST - V35 ANA MENÜ PERFORMANS VE OPTİMİZASYON RAPORU
====================================================================

1. ANA MENÜDEKİ KASMANIN / DONMANIN KÖK NEDENLERİ VE YAPILAN DÜZELTMELER:
--------------------------------------------------------------------
- [CSS Compositor Darboğazı]:
  Eski menüde tüm ekranı kaplayan (100vw x 100vh) ve her 200 ms'de hareket eden SVG "feTurbulence"
  filtresi ile "mix-blend-mode: overlay" kullanılıyordu. Bu durum, Chromium ve modern tarayıcılarda
  arkadaki 60 FPS WebGL canvas'ı ile birleştiğinde GPU donanım katmanlamasını bozuyor, tarayıcıyı
  yazılımsal birleştirme (software readback) yapmaya zorlayarak FPS'i 10-15'e düşürüyordu.
  -> DÜZELTİLDİ: "mix-blend-mode" ve ağır SVG animasyonu kaldırıldı, hafif ve donanım hızlandırmalı
     statik doku formatına dönüştürüldü.

- [Ağır CSS Filtreleri (filter: drop-shadow ve filter: blur)]:
  Dönen armanın üzerinde sürekli dönen drop-shadow filtresi ve başlık harflerindeki blur filtreleri,
  her karede CPU/GPU üzerinde yeniden piksel rasterizasyonuna yol açıyordu.
  -> DÜZELTİLDİ: Başlıktaki filter yerine doğrudan GPU'nun metin motorunda çalışan text-shadow'a
     geçildi. Harf animasyonlarında blur kaldırıldı, sadece transform/opacity kullanılarak
     tamamen GPU compositor thread'ine devredildi.

- [WebGL Çözünürlük ve DPR Aşırılığı (4K Render Problemi)]:
  Eski kodda renderer pixelRatio 1.8'e kadar çıkıyordu. 1440p, 4K veya Retina/yüksek DPI ekranlarda
  bu durum 3.5 - 7 milyon pikselin MSAA (Antialias) ile işlenmesine neden oluyor ve dahili (Intel/AMD)
  ekran kartlarını tamamen kilitliyordu.
  -> DÜZELTİLDİ: DPR akıllıca max 1.25 (dokunmatik/zayıf cihazlarda 1.0) ile sınırlandı.
     "powerPreference: 'high-performance'" etkinleştirildi.

- [Açılışta Donma (2048x1024 D3 Harita Çizimi)]:
  Menü açıldığı anda 2048x1024 boyutunda iki adet canvas üzerinde D3 precision 0.3 ile yüzlerce ülkenin
  poligonları çiziliyordu. Bu işlem ana iş parçacığını (main thread) 800ms - 2000ms boyunca donduruyordu.
  -> DÜZELTİLDİ: Doku çözünürlüğü 1024x512'ye optimize edildi, D3 hassasiyeti (precision) 1.2 yapıldı.
     Harita oluşturulduktan sonra önbelleğe (cache) alındı; menü her açıldığında tekrar sıfırdan çizilmez.

- [Ağır PBR Gölgelendirici (MeshStandardMaterial)]:
  Küre üzerinde ağır PBR hesaplamaları (roughness, metalness, directional lights) yapan standart materyal
  kullanılıyordu.
  -> DÜZELTİLDİ: Görsel zenginliği koruyan, altın/kızıl ışıltıyı daha canlı yansıtan ama GPU'da 3 kat
     daha az hesaplama yapan "MeshPhongMaterial" gölgelendiricisine geçildi.

- [Fetih Oklarının Her Karede GPU'ya Yeniden Yüklenmesi]:
  9 adet fetih oku için her bir karede JavaScript döngüsüyle 540 adet koordinat tek tek pos.setXYZ ile
  güncelleniyor ve "pos.needsUpdate = true" ile her kare GPU'ya vertex buffer upload ediliyordu.
  -> DÜZELTİLDİ: Ok yayları bir kez hesaplanıp belleğe yüklendi. Her karede çizim mesafesi "setDrawRange(0, cnt)"
     ile ayarlanarak döngü ve buffer upload tamamen SIFIRA indirildi. Ok sayısı 5'e dengelendi.

- [Parçacık Döngüleri (Embers / Stars)]:
  Kıvılcım parçacıkları getter/setter fonksiyon çağrıları (ep.getY / ep.setY) yerine doğrudan
  Float32Array üzerinden (ep.array) hızlandırıldı. Parçacık sayıları performansa göre optimize edildi.

- [60 FPS Kare Hızı Sınırlandırması]:
  120Hz, 144Hz veya 240Hz oyuncu monitörlerinde menü ekran kartını %100 yükte çalıştırıyordu.
  14-16 ms limitör eklenerek sabit 60 FPS hedeflendi, gereksiz pil ve GPU tüketimi engellendi.
  Sekme arka plana alındığında döngü otomatik duraklatılır.

- [Dil Değişiminde (TR/EN) WebGL'in Baştan Başlaması]:
  Eski kodda dil butonuna basıldığında tüm 3D sahne, WebGL context'i ve dokular yok edilip sıfırdan
  kuruluyordu (büyük takılma).
  -> DÜZELTİLDİ: Dil değiştiğinde 3D sahneye dokunulmadan sadece DOM metinleri anında güncellenir.

- [Otomatik Düşük Performans Modu (Dinamik Adaptasyon)]:
  Zayıf donanımlarda FPS 30'un altına düşerse kod bunu ilk 50 karede tespit eder ve kıvılcımları/ağır
  katmanları otomatik kapatıp çözünürlüğü 1.0x yaparak oyunun asla takılmamasını sağlar.

--------------------------------------------------------------------
2. YAPILAMAYANLAR / ÇEVRİMDIŞI KAPSAM DIŞI HUSUSLAR:
--------------------------------------------------------------------
- Çevrimdışı ortamda harici 3B AI üretici API'lerine (Meshy, Tripo vb.) canlı internet bağlantısı
  kurulamaz (window.WC_MENU kancası üzerinden yerel dosya yolu desteği hazırdır).
- 3B küre üzerinde fethedilen ülkelerin poligon sınır çizgilerinin gerçek zamanlı CSG geometrik
  olarak birleştirilmesi (küre üzerinde dinamik Voronoi/Delaunay triangülasyonu gerektirir).
====================================================================
