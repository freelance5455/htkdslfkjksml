SMART KASIR & TOKO - PROYEK ANDROID

PENTING
- ZIP ini adalah SOURCE PROJECT Android, bukan file APK siap instal.
- File aplikasi utama sudah berada di app/src/main/assets/index.html.
- Jangan unggah ZIP ini ke Netlify. Netlify hanya untuk website statis, sedangkan ZIP ini adalah proyek Android Studio/Gradle.
- Data aplikasi disimpan lokal di perangkat (WebView localStorage). Backup dari menu aplikasi secara berkala. Belum ada sinkronisasi cloud antar-HP.

CARA BUILD HANYA DENGAN HP ANDROID (disarankan)
Gunakan Code on the Go (CoGo), IDE Android yang memang mendukung build aplikasi Android langsung di HP.
Situs resmi: https://appdevforall.org/code-on-the-go/

1. Pastikan ruang kosong cukup. Toolchain dan Android SDK dapat membutuhkan beberapa GB.
2. Unduh dan instal Code on the Go hanya dari situs resmi di atas.
3. Buka Code on the Go dan selesaikan setup awal/toolchain sesuai petunjuk aplikasi.
4. Ekstrak ZIP ini menggunakan File Manager. Pastikan folder SmartKasirAndroid terlihat.
5. Di Code on the Go, pilih Open Existing Project / Open Project.
6. Pilih folder SmartKasirAndroid (folder yang berisi settings.gradle dan build.gradle, bukan folder ZIP dan bukan folder app).
7. Tunggu proses Gradle sync/dependency download selesai. Koneksi internet diperlukan pada build pertama.
8. Jalankan task Gradle :app:assembleDebug (bisa melalui panel Gradle/terminal Code on the Go).
9. Jika build berhasil, APK debug berada di app/build/outputs/apk/debug/app-debug.apk.
10. Gunakan tombol Export di Code on the Go untuk menyalin APK ke folder Download, lalu ketuk APK untuk memasang. Izinkan instalasi dari sumber tersebut jika Android memintanya.

JIKA CODE ON THE GO MENANYAKAN GRADLE
Proyek ini memakai Android Gradle Plugin 8.7.3, compileSdk 35, dan dependency dari Google Maven/Maven Central. Pilih toolchain JDK 17 atau 21 dan Gradle 8.9 atau yang kompatibel dengan AGP 8.7.3. Jangan mengubah versi plugin sembarangan.

ALTERNATIF
Bila build di HP tidak berhasil, proyek dapat dibuka di Android Studio pada komputer. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).

FITUR DAN BATASAN
- Aplikasi berjalan offline setelah terpasang.
- Barcode scanner native memakai kamera dan library ZXing; izin kamera diminta ketika fitur scan dipakai.
- Foto produk dipilih melalui pemilih gambar Android.
- Data tersimpan di perangkat yang sama. Pindah ke HP lain tidak otomatis memindahkan data; gunakan Backup lalu Pulihkan.
- APK debug cocok untuk uji coba dan dibagikan secara terbatas. Untuk distribusi publik/Play Store, buat signed release APK/AAB dengan keystore sendiri.
