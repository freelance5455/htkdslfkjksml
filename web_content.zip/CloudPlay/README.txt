# CloudPlay starter app

This is a responsive web-app/PWA starter for Android.

## Run
1. Upload the contents of this folder to a static website host that supports HTTPS.
2. Open the hosted `index.html` on Android Chrome.
3. Use Chrome menu → **Add to Home screen** (or Install app, if offered).

## Important
- CloudPlay is a launcher-style companion, not an Xbox streaming server.
- The Play buttons open the official Xbox Cloud Gaming website: https://www.xbox.com/play
- Internet is required. A Microsoft/Xbox account, supported region, eligible subscription, and supported device/browser may be required. Game availability varies.
- The sample library is illustrative. It does not guarantee that every listed game is currently available to your account.
- This ZIP is source code, not an APK. To publish a native APK, package the hosted site with an Android WebView project and follow Android signing/build steps.
