const XBOX_URL = "https://www.xbox.com/play";
const games = [
  {name:"Halo Infinite",genre:"Action",category:"action",tag:"HALO",c1:"#244c36",c2:"#111d27"},
  {name:"Forza Horizon 5",genre:"Racing",category:"racing",tag:"FORZA",c1:"#155b70",c2:"#c16b28"},
  {name:"Minecraft",genre:"Adventure",category:"adventure",tag:"MINECRAFT",c1:"#3d6a37",c2:"#263f66"},
  {name:"Sea of Thieves",genre:"Adventure",category:"adventure",tag:"SEA OF THIEVES",c1:"#14566a",c2:"#172b48"},
  {name:"Grounded",genre:"Adventure",category:"adventure",tag:"GROUNDED",c1:"#55722c",c2:"#1b4935"},
  {name:"Microsoft Flight Simulator",genre:"Simulation",category:"adventure",tag:"FLIGHT SIM",c1:"#315c83",c2:"#1a2c48"},
  {name:"Age of Empires",genre:"Strategy",category:"action",tag:"AGE OF EMPIRES",c1:"#80613b",c2:"#28231d"},
  {name:"EA SPORTS FC",genre:"Sports",category:"sports",tag:"EA SPORTS FC",c1:"#173d59",c2:"#171c28"}
];
const grid=document.querySelector("#gamesGrid"), search=document.querySelector("#searchInput"), count=document.querySelector("#gameCount");
let active="all";
function render(){
 const q=search.value.trim().toLowerCase();
 const list=games.filter(g=>(active==="all"||g.category===active)&&(g.name.toLowerCase().includes(q)||g.genre.toLowerCase().includes(q)));
 count.textContent=`${list.length} games`;
 grid.innerHTML=list.length?list.map(g=>`<article class="game"><div class="cover" style="--c1:${g.c1};--c2:${g.c2}"><b>${g.tag}</b></div><div class="game-body"><div class="game-title">${g.name}</div><div class="genre">${g.genre}</div><button class="play" data-play="${g.name}">Open on Xbox ↗</button></div></article>`).join(""):`<div class="empty">No games found. Try another search.</div>`;
}
function launchXbox(){window.open(XBOX_URL,"_blank","noopener,noreferrer");}
document.querySelector("#launchXbox").addEventListener("click",launchXbox);
document.querySelector("#cloudNav").addEventListener("click",launchXbox);
document.querySelector("#profileLaunch").addEventListener("click",launchXbox);
document.querySelector("#profileBtn").addEventListener("click",()=>document.querySelector("#profileDialog").showModal());
document.querySelector("#profileNav").addEventListener("click",()=>document.querySelector("#profileDialog").showModal());
document.querySelector(".close-dialog").addEventListener("click",()=>document.querySelector("#profileDialog").close());
grid.addEventListener("click",e=>{if(e.target.matches("[data-play]"))launchXbox();});
search.addEventListener("input",render);
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelector(".filter.active").classList.remove("active");btn.classList.add("active");active=btn.dataset.filter;render();}));
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();
