package com.example.shooting3d;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.Window;
import android.view.WindowManager;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle b){super.onCreate(b);requestWindowFeature(Window.FEATURE_NO_TITLE);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);webView=new WebView(this);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);webView.loadUrl("file:///android_asset/index.html");setContentView(webView);}
 @Override public void onBackPressed(){if(webView!=null)webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack();",null);}
}
