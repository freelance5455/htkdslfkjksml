/* NEW MAP 301 — SEPARATE MAP CODE
   This file is intentionally NOT inserted into the current game ZIP.
   Later, call: buildMap301(scene, THREE)
*/
(function(){
  function box(THREE, w,h,d,color, x,y,z, scene){
    const m=new THREE.Mesh(
      new THREE.BoxGeometry(w,h,d),
      new THREE.MeshStandardMaterial({color:color,roughness:.85})
    );
    m.position.set(x,y,z); m.castShadow=true; m.receiveShadow=true; scene.add(m); return m;
  }
  function cyl(THREE, r,h,color,x,y,z,scene){
    const m=new THREE.Mesh(
      new THREE.CylinderGeometry(r,r,h,12),
      new THREE.MeshStandardMaterial({color:color,roughness:.9})
    );
    m.position.set(x,y,z); m.castShadow=true; m.receiveShadow=true; scene.add(m); return m;
  }
  function house(THREE,x,z,s,scene,colliders){
    const body=box(THREE,3.2*s,2.3*s,2.8*s,0xe8d7bd,x,1.15*s,z,scene);
    const roof=box(THREE,3.65*s,.45*s,3.15*s,0x9d3d32,x,2.55*s,z,scene);
    roof.rotation.z=0;
    box(THREE,.65*s,1.05*s,.08*s,0x56351f,x,0.55*s,z-1.43*s,scene);
    box(THREE,.55*s,.55*s,.08*s,0x8bd2ee,x-1.05*s,1.35*s,z-1.44*s,scene);
    box(THREE,.55*s,.55*s,.08*s,0x8bd2ee,x+1.05*s,1.35*s,z-1.44*s,scene);
    colliders.push({x:x,z:z,w:1.9*s,d:1.7*s});
  }
  function tree(THREE,x,z,s,scene){
    cyl(THREE,.18*s,1.2*s,0x71452b,x,.6*s,z,scene);
    const crown=new THREE.Mesh(
      new THREE.SphereGeometry(.8*s,12,10),
      new THREE.MeshStandardMaterial({color:0x3e9b4f,roughness:1})
    );
    crown.position.set(x,1.45*s,z); crown.castShadow=true; scene.add(crown);
  }
  function buildMap304(scene,THREE){
    const root=new THREE.Group(); root.name='MAP_304_INDUSTRIAL_YARD'; scene.add(root);
    const colliders=[]; box(THREE,46,.18,42,0x70777b,0,-.12,0,scene);
    box(THREE,46,.08,6,0x3f4346,0,.01,0,scene); box(THREE,6,.08,42,0x3f4346,0,.012,0,scene);
    house(THREE,-12,-11,1.25,scene,colliders); house(THREE,12,11,1.25,scene,colliders);
    [[-9,4],[9,4],[-9,-4],[9,-4],[0,13],[0,-13]].forEach(p=>box(THREE,3,1.4,1.8,0x4d6470,p[0],.7,p[1],scene));
    [[-18,-16],[-18,16],[18,-16],[18,16]].forEach(p=>box(THREE,1.5,3,1.5,0x7a5f43,p[0],1.5,p[1],scene));
    [[-5,-5],[5,-5],[-5,5],[5,5]].forEach(p=>box(THREE,2,1,2,0x8b765e,p[0],.5,p[1],scene));
    window.NEW_MAP_304={id:304,name:'INDUSTRIAL YARD',spawn:{x:0,z:8},enemySpawn:{z:-29,spread:20},bounds:23,colliders:colliders,root:root}; return window.NEW_MAP_304;
  }
})();
