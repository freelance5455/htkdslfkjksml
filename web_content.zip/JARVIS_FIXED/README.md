# JARVIS ULTIMATE 3.0  (com.jarvis.ultimate) — FIXED
Native Android (Java) app with a WebView UI (HTML/CSS/JS in app/src/main/assets).

## What was fixed
The white "Webpage not available" error (`net::ERR_HTTP_RESPONSE_CODE_FAILURE` on `appassets.androidplatform.net`) happened because the WebView tried to load local files the wrong way.  
This version uses the official **WebViewAssetLoader** so `index.html`, `app.js` and `style.css` load correctly on all Android versions.

## Build the APK
**Android Studio (easiest):**
1. Install Android Studio (Koala or newer). File > Open > select this folder.
2. Wait for Gradle sync (needs internet the first time — it will download AndroidX WebKit).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

**Command line** (JDK 17 + Android SDK, ANDROID_HOME set):
```
gradle wrapper --gradle-version 8.2
./gradlew assembleDebug
```
Copy the APK to the phone, open it, allow "install unknown apps". Or: `adb install app-debug.apk`.

## Notes
- Mic: first tap asks for permission. Speech recognition uses the phone's Google speech service and usually needs internet.
- Spoken replies use the phone's built-in Text-to-Speech (install a voice in Android settings > Text-to-speech if silent).
- Imported MP3/WAV files are copied into app storage and played with the built-in media player. Star one to play it on startup.
- Flashlight needs no permission on Android 6+. "Open apps" lists apps with launcher icons.
- The globe is drawn on a canvas as dots from simplified continent outlines (no image texture, so it works offline and stays light).
- Sound effects (boot, click, mic on/off, send, reply, error) are synthesized with Web Audio, so no audio files are needed. Toggle in SETUP.
- Chat is a local rule-based command engine, not an AI model: it handles commands, time/date/battery, math and a few phrases.
