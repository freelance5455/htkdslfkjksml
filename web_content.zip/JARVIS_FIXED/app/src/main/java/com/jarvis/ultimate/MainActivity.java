package com.jarvis.ultimate;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 11, REQ_PICK = 12;
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false, torchOn = false, pendingListen = false;
    private SpeechRecognizer sr;
    private MediaPlayer mp;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF000000);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);          // safer when using AssetLoader
        s.setAllowContentAccess(false);

        // Proper local asset loading (fixes the white "Webpage not available" error)
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.addJavascriptInterface(new Bridge(), "Jarvis");
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.getDefault());
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
                ttsReady = true;
            }
        });
        // Load via the special local domain (assets/index.html)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void emit(final String ev, final String data) {
        web.post(() -> web.evaluateJavascript("window.onNative&&window.onNative(" + JSONObject.quote(ev) + "," + JSONObject.quote(data == null ? "" : data) + ")", null));
    }

    private File voiceDir() { File d = new File(getFilesDir(), "voices"); if (!d.exists()) d.mkdirs(); return d; }

    private boolean view(String url) {
        try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
        catch (Exception e) { return false; }
    }

    private String launch(String[] pkgs, String url) {
        PackageManager pm = getPackageManager();
        for (String p : pkgs) {
            Intent i = pm.getLaunchIntentForPackage(p);
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { startActivity(i); return "app"; } catch (Exception ignored) {} }
        }
        return view(url) ? "web" : "fail";
    }

    private String voicesJson() {
        JSONArray a = new JSONArray();
        File[] fs = voiceDir().listFiles();
        if (fs != null) { java.util.Arrays.sort(fs); for (File f : fs) a.put(f.getName()); }
        return a.toString();
    }

    private void startListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { emit("error", "Speech recognition is not available. Install or enable the Google app."); emit("idle", ""); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        if (tts != null) tts.stop();
        if (sr != null) sr.destroy();
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { emit("listening", ""); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] bf) {}
            public void onEndOfSpeech() { emit("idle", ""); }
            public void onError(int c) {
                emit("idle", "");
                if (c == SpeechRecognizer.ERROR_NO_MATCH || c == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) emit("error", "Nothing heard. Tap the mic and try again.");
                else if (c == SpeechRecognizer.ERROR_NETWORK || c == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) emit("error", "Speech recognition needs an internet connection on this device.");
                else if (c == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) emit("error", "Microphone permission denied. Enable it in Android settings.");
                else emit("error", "Speech error code " + c);
            }
            public void onResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (l != null && !l.isEmpty()) emit("heard", l.get(0));
            }
            public void onPartialResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (l != null && !l.isEmpty()) emit("partial", l.get(0));
            }
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        sr.startListening(i);
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        if (rc == REQ_MIC) {
            boolean ok = g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED;
            if (ok && pendingListen) startListen();
            else if (!ok) { emit("error", "Microphone permission denied. Enable it in Android settings."); emit("idle", ""); }
            pendingListen = false;
        }
    }

    @Override protected void onActivityResult(int rc, int res, Intent data) {
        if (rc != REQ_PICK || res != RESULT_OK || data == null) return;
        final List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        new Thread(() -> {
            int n = 0;
            for (Uri u : uris) {
                String name = "voice_" + System.currentTimeMillis() + ".mp3";
                try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) { int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = c.getString(ix); }
                } catch (Exception ignored) {}
                name = name.replaceAll("[^A-Za-z0-9._ -]", "_");
                try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(new File(voiceDir(), name))) {
                    byte[] buf = new byte[16384]; int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                    n++;
                } catch (Exception e) { emit("error", "Could not import " + name); }
            }
            emit("voices", voicesJson());
            emit("info", "Imported " + n + " file(s).");
        }).start();
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (sr != null) sr.destroy();
        if (mp != null) mp.release();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public void speak(String t) { if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j"); }
        @JavascriptInterface public void stopSpeak() { if (tts != null) tts.stop(); }
        @JavascriptInterface public void listen() { runOnUiThread(MainActivity.this::startListen); }
        @JavascriptInterface public void stopListen() { runOnUiThread(() -> { if (sr != null) sr.stopListening(); }); }

        @JavascriptInterface public String openTarget(String k) {
            switch (k) {
                case "youtube": return launch(new String[]{"com.google.android.youtube"}, "https://www.youtube.com");
                case "instagram": return launch(new String[]{"com.instagram.android"}, "https://www.instagram.com");
                case "telegram": return launch(new String[]{"org.telegram.messenger", "org.telegram.messenger.web"}, "https://web.telegram.org");
                case "whatsapp": return launch(new String[]{"com.whatsapp", "com.whatsapp.w4b"}, "https://web.whatsapp.com");
            }
            return "fail";
        }

        @JavascriptInterface public String youtubeSearch(String q) {
            try {
                Intent i = new Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube");
                i.putExtra("query", q); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i); return "app";
            } catch (Exception e) {
                try { return view("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")) ? "web" : "fail"; }
                catch (Exception e2) { return "fail"; }
            }
        }

        @JavascriptInterface public String listApps() {
            PackageManager pm = getPackageManager();
            Intent m = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<String> names = new ArrayList<>();
            for (ResolveInfo r : pm.queryIntentActivities(m, 0)) names.add(r.loadLabel(pm).toString());
            Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
            return new JSONArray(names).toString();
        }

        @JavascriptInterface public String openApp(String name) {
            PackageManager pm = getPackageManager();
            Intent m = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            String n = name.trim().toLowerCase(Locale.ROOT), pkg = null, label = null;
            for (ResolveInfo r : pm.queryIntentActivities(m, 0)) {
                String l = r.loadLabel(pm).toString();
                String ll = l.toLowerCase(Locale.ROOT);
                if (ll.equals(n)) { pkg = r.activityInfo.packageName; label = l; break; }
                if (pkg == null && ll.contains(n)) { pkg = r.activityInfo.packageName; label = l; }
            }
            if (pkg == null) return "";
            Intent i = pm.getLaunchIntentForPackage(pkg);
            if (i == null) return "";
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); return label; } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public String torch(boolean on) {
            try {
                CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                for (String id : cm.getCameraIdList()) {
                    CameraCharacteristics c = cm.getCameraCharacteristics(id);
                    Boolean f = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer face = c.get(CameraCharacteristics.LENS_FACING);
                    if (f != null && f && face != null && face == CameraCharacteristics.LENS_FACING_BACK) {
                        cm.setTorchMode(id, on); torchOn = on; return on ? "on" : "off";
                    }
                }
            } catch (Exception ignored) {}
            return "unavailable";
        }
        @JavascriptInterface public boolean torchState() { return torchOn; }

        @JavascriptInterface public void openSettings() {
            Intent i = new Intent(Settings.ACTION_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); } catch (Exception ignored) {}
        }

        @JavascriptInterface public int battery() {
            try { return ((BatteryManager) getSystemService(Context.BATTERY_SERVICE)).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); }
            catch (Exception e) { return -1; }
        }

        @JavascriptInterface public void importVoice() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/mpeg", "audio/wav", "audio/x-wav", "audio/*"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(i, REQ_PICK);
            });
        }
        @JavascriptInterface public String listVoices() { return voicesJson(); }

        @JavascriptInterface public void playVoice(String name) {
            runOnUiThread(() -> {
                try {
                    if (tts != null) tts.stop();
                    if (mp != null) mp.release();
                    mp = new MediaPlayer();
                    mp.setDataSource(new File(voiceDir(), new File(name).getName()).getAbsolutePath());
                    mp.setOnCompletionListener(p -> { p.release(); if (mp == p) mp = null; });
                    mp.prepare(); mp.start();
                } catch (Exception e) { emit("error", "Cannot play " + name); }
            });
        }
        @JavascriptInterface public void stopVoice() { runOnUiThread(() -> { if (mp != null) { mp.release(); mp = null; } }); }
        @JavascriptInterface public void deleteVoice(String name) {
            new File(voiceDir(), new File(name).getName()).delete();
            emit("voices", voicesJson());
        }
    }
}
