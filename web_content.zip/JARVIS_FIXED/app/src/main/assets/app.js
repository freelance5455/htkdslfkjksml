(function(){
"use strict";
var J=window.Jarvis||null;
var $=function(s){return document.querySelector(s)};
var store={get:function(k,d){try{var v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set:function(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
var cfg=Object.assign({tts:true,sfx:true,rain:true,lite:false,greet:""},store.get("cfg",{}));
var hist=store.get("hist",[]);
var ytMode=false,listening=false;

/* ---------- SFX (synthesized with Web Audio, no files needed) ---------- */
var AC=null;
function ac(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(AC&&AC.state==="suspended")AC.resume();return AC}
function tone(f,d,type,vol,delay,f2){if(!cfg.sfx)return;var a=ac();if(!a)return;var t=a.currentTime+(delay||0),o=a.createOscillator(),g=a.createGain();
  o.type=type||"sine";o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol||.1,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d+.03)}
var SFX={
  click:function(){tone(1400,.04,"square",.04)},
  boot:function(){tone(120,.7,"sawtooth",.07,0,900);tone(1600,.05,"square",.05,.75);tone(1600,.05,"square",.05,.85)},
  ready:function(){tone(700,.12,"triangle",.1);tone(1050,.12,"triangle",.1,.12);tone(1400,.22,"triangle",.1,.24)},
  micOn:function(){tone(500,.14,"sine",.12,0,1000)},
  micOff:function(){tone(1000,.14,"sine",.1,0,450)},
  send:function(){tone(900,.06,"square",.05)},
  reply:function(){tone(800,.07,"triangle",.07);tone(1200,.09,"triangle",.07,.07)},
  err:function(){tone(180,.28,"sawtooth",.08,0,110)}
};
document.addEventListener("touchstart",ac,{once:true});
document.addEventListener("click",function(e){if(e.target.closest&&e.target.closest("button"))SFX.click()},true);

/* ---------- GLOBE (canvas, offline, no textures) ---------- */
var LAND=[
[[-168,66],[-140,70],[-95,72],[-80,68],[-62,58],[-55,50],[-67,44],[-76,35],[-81,25],[-97,26],[-105,22],[-117,32],[-124,40],[-125,49],[-140,60]],
[[-105,22],[-97,18],[-88,15],[-83,9],[-77,8],[-85,14],[-92,17]],
[[-73,78],[-20,82],[-20,70],[-44,60],[-55,68]],
[[-78,8],[-60,10],[-50,0],[-35,-6],[-40,-22],[-58,-38],[-66,-55],[-75,-50],[-72,-30],[-81,-5]],
[[-10,36],[-9,43],[-2,48],[5,52],[10,57],[20,70],[40,68],[70,73],[100,77],[140,72],[170,68],[160,60],[142,52],[130,42],[122,38],[122,30],[110,20],[106,10],[100,5],[98,16],[90,22],[80,15],[77,8],[72,20],[58,25],[50,30],[43,13],[35,30],[27,36],[22,37],[12,44],[3,43]],
[[-17,21],[-6,36],[10,37],[32,31],[43,12],[51,12],[40,-5],[40,-16],[33,-26],[20,-35],[12,-18],[9,4],[-8,4],[-17,14]],
[[114,-22],[130,-12],[142,-11],[153,-26],[146,-39],[135,-34],[115,-34]],
[[-5,50],[2,52],[-3,58],[-6,56]],
[[130,32],[141,36],[145,44],[140,41]],
[[95,5],[105,-6],[120,-8],[140,-8],[132,-1],[110,0]]
];
function inPoly(x,y,p){var c=false;for(var i=0,j=p.length-1;i<p.length;j=i++){var xi=p[i][0],yi=p[i][1],xj=p[j][0],yj=p[j][1];if(((yi>y)!==(yj>y))&&(x<(xj-xi)*(y-yi)/(yj-yi)+xi))c=!c}return c}
var PTS=(function(){var out=[];for(var la=-84;la<=84;la+=3){var step=3/Math.max(Math.cos(la*Math.PI/180),.25);for(var lo=-180;lo<180;lo+=step){var land=la<-72;if(!land)for(var k=0;k<LAND.length;k++){if(inPoly(lo,la,LAND[k])){land=true;break}}
if(land){var f=la*Math.PI/180,l=lo*Math.PI/180;out.push([Math.cos(f)*Math.sin(l),Math.sin(f),Math.cos(f)*Math.cos(l)])}}}return out})();

function makeGlobe(cv){
  var ctx=cv.getContext("2d"),w=0,h=0,dpr=1;
  function size(){dpr=cfg.lite?1:Math.min(window.devicePixelRatio||1,2);var r=cv.getBoundingClientRect();w=r.width||cv.width;h=r.height||cv.height;cv.width=w*dpr;cv.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
  size();
  var TILT=.4,ct=Math.cos(TILT),st=Math.sin(TILT);
  function P(x,y,z,a){var ca=Math.cos(a),sa=Math.sin(a);var x1=x*ca+z*sa,z1=-x*sa+z*ca;return [x1,y*ct-z1*st,y*st+z1*ct]}
  return {size:size,draw:function(a){
    var R=Math.min(w,h)/2-8,cx=w/2,cy=h/2,i,k,p,q;
    ctx.clearRect(0,0,w,h);
    var g=ctx.createRadialGradient(cx,cy,R*.9,cx,cy,R*1.18);g.addColorStop(0,"rgba(0,255,102,.35)");g.addColorStop(1,"rgba(0,255,102,0)");
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,R*1.18,0,6.2832);ctx.fill();
    g=ctx.createRadialGradient(cx-R*.3,cy-R*.3,R*.1,cx,cy,R);g.addColorStop(0,"#052a12");g.addColorStop(1,"#000a04");
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,R,0,6.2832);ctx.fill();
    ctx.strokeStyle="rgba(0,255,102,.9)";ctx.lineWidth=1.5;ctx.stroke();
    ctx.strokeStyle="rgba(0,255,102,.2)";ctx.lineWidth=.6;ctx.beginPath();
    for(var lo=-180;lo<180;lo+=30){var pen=false;for(var la=-90;la<=90;la+=6){var f=la*.01745,l=lo*.01745;q=P(Math.cos(f)*Math.sin(l),Math.sin(f),Math.cos(f)*Math.cos(l),a);
      if(q[2]>0){var X=cx+q[0]*R,Y=cy-q[1]*R;pen?ctx.lineTo(X,Y):ctx.moveTo(X,Y);pen=true}else pen=false}}
    for(var la2=-60;la2<=60;la2+=30){var pen2=false;for(var lo2=-180;lo2<=180;lo2+=6){var f2=la2*.01745,l2=lo2*.01745;q=P(Math.cos(f2)*Math.sin(l2),Math.sin(f2),Math.cos(f2)*Math.cos(l2),a);
      if(q[2]>0){var X2=cx+q[0]*R,Y2=cy-q[1]*R;pen2?ctx.lineTo(X2,Y2):ctx.moveTo(X2,Y2);pen2=true}else pen2=false}}
    ctx.stroke();
    var s=R>60?2.2:1.6;ctx.fillStyle="#00ff66";ctx.beginPath();
    for(i=0;i<PTS.length;i++){p=PTS[i];q=P(p[0],p[1],p[2],a);if(q[2]>.05)ctx.rect(cx+q[0]*R-s/2,cy-q[1]*R-s/2,s,s)}
    ctx.fill();
    var sc=(a*3)%(R*2.4)-R*1.2;ctx.strokeStyle="rgba(0,255,102,.25)";ctx.lineWidth=1;ctx.beginPath();
    var yy=cy+sc,dx=Math.sqrt(Math.max(R*R-sc*sc,0));if(dx>0){ctx.moveTo(cx-dx,yy);ctx.lineTo(cx+dx,yy);ctx.stroke()}
  }};
}

/* ---------- code rain ---------- */
var rain=$("#rain"),rctx=rain.getContext("2d"),cols=[],FS=14,CH="01ABCDEF<>/{}[]#$%&*+=ｱｲｳｴｵｶｷｸｹｺ";
function rainSize(){rain.width=innerWidth;rain.height=innerHeight;cols=[];for(var i=0;i<Math.ceil(innerWidth/FS);i++)cols.push(Math.random()*innerHeight/FS|0)}
function rainStep(){rctx.fillStyle="rgba(0,0,0,.14)";rctx.fillRect(0,0,rain.width,rain.height);rctx.fillStyle="#00ff66";rctx.font=FS+"px monospace";
  for(var i=0;i<cols.length;i++){rctx.fillText(CH.charAt(Math.random()*CH.length|0),i*FS,cols[i]*FS);if(cols[i]*FS>rain.height&&Math.random()>.975)cols[i]=0;cols[i]++}}

/* ---------- main loop ---------- */
var gMain,gBoot,rot=0,last=0,lastRain=0,booting=true;
function loop(t){
  requestAnimationFrame(loop);
  if(document.hidden)return;
  var gap=cfg.lite?50:33;
  if(t-last<gap)return;last=t;rot+=cfg.lite?.03:.02;
  if(booting&&gBoot)gBoot.draw(rot);else if(gMain)gMain.draw(rot);
  if(cfg.rain&&t-lastRain>(cfg.lite?160:90)){lastRain=t;rainStep()}
}

/* ---------- UI helpers ---------- */
function esc(s){var d=document.createElement("div");d.textContent=s;return d.innerHTML}
function add(cls,text){var c=$("#chat"),d=document.createElement("div");d.className="msg "+cls;d.textContent=text;c.appendChild(d);$("#v-chat").scrollTop=1e6;
  while(c.children.length>80)c.removeChild(c.firstChild)}
function say(text){add("jv",text);SFX.reply();if(cfg.tts&&J)J.speak(text);}
function setView(v){document.querySelectorAll(".view").forEach(function(e){e.classList.toggle("on",e.id==="v-"+v)});
  document.querySelectorAll("nav button").forEach(function(b){b.classList.toggle("on",b.dataset.v===v)});
  if(v==="apps")loadApps();if(v==="voice")loadVoices();if(v==="hist")renderHist()}
function status(){$("#sNet").textContent=navigator.onLine?"ONLINE":"OFFLINE";$("#sTts").textContent=cfg.tts?"ON":"OFF";
  $("#sMic").textContent=listening?"LISTEN":"IDLE";$("#mic").classList.toggle("live",listening);$("#sTorch").textContent=J&&J.torchState()?"ON":"OFF";
  $("#ytv").classList.toggle("on",ytMode)}
function clock(){var d=new Date();$("#clock").textContent=("0"+d.getHours()).slice(-2)+":"+("0"+d.getMinutes()).slice(-2);
  var b=J?J.battery():-1;$("#bat").textContent="BAT "+(b>=0?b+"%":"--");status()}

/* ---------- history ---------- */
function pushHist(t){hist.unshift({t:t,d:Date.now()});hist=hist.slice(0,50);store.set("hist",hist)}
function renderHist(){var h=$("#hist");h.innerHTML="";if(!hist.length){h.textContent="No commands yet.";return}
  hist.forEach(function(x){var d=document.createElement("div");d.textContent=new Date(x.d).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})+"  "+x.t;d.onclick=function(){setView("chat");handle(x.t)};h.appendChild(d)})}

/* ---------- apps / voices ---------- */
var appList=null;
function loadApps(){if(!J){$("#apps").textContent="Native bridge unavailable.";return}
  if(!appList)try{appList=JSON.parse(J.listApps())}catch(e){appList=[]}renderApps()}
function renderApps(){var q=$("#appq").value.toLowerCase(),g=$("#apps");g.innerHTML="";
  (appList||[]).filter(function(n){return n.toLowerCase().indexOf(q)>-1}).forEach(function(n){var b=document.createElement("button");b.textContent=n;b.onclick=function(){J.openApp(n)};g.appendChild(b)})}
function loadVoices(){if(!J)return;try{renderVoices(JSON.parse(J.listVoices()))}catch(e){}}
function renderVoices(list){var v=$("#voices");v.innerHTML="";if(!list.length){v.textContent="No voice files yet. Import an MP3 or WAV.";return}
  list.forEach(function(n){var r=document.createElement("div");r.className="vrow";
    var s=document.createElement("span");s.textContent=(cfg.greet===n?"* ":"")+n;r.appendChild(s);
    [["▶",function(){J.playVoice(n)}],["★",function(){cfg.greet=cfg.greet===n?"":n;store.set("cfg",cfg);renderVoices(list)}],["✕",function(){J.deleteVoice(n);if(cfg.greet===n){cfg.greet="";store.set("cfg",cfg)}}]].forEach(function(a){var b=document.createElement("button");b.textContent=a[0];b.onclick=a[1];r.appendChild(b)});
    v.appendChild(r)})}

/* ---------- command engine (local, offline) ---------- */
var JOKES=["I would tell you a UDP joke, but you might not get it.","There are 10 kinds of people: those who read binary and those who don't.","A SQL query walks into a bar, sees two tables and asks: can I join you?","My code works, and I have no idea why. Do not touch it."];
var TARGETS={youtube:"youtube",yt:"youtube",instagram:"instagram",insta:"instagram",ig:"instagram",telegram:"telegram",tg:"telegram",whatsapp:"whatsapp","whats app":"whatsapp",wa:"whatsapp"};
var NAMES={youtube:"YouTube",instagram:"Instagram",telegram:"Telegram",whatsapp:"WhatsApp"};
function nat(){if(!J){return false}return true}
function openTarget(k){if(!nat())return "Native features only work inside the Android app.";var r=J.openTarget(k);
  return r==="app"?"Opening "+NAMES[k]+".":r==="web"?NAMES[k]+" app not found. Opened it in the browser.":"Could not open "+NAMES[k]+"."}
function ytSearch(q){if(!nat())return "Native features only work inside the Android app.";var r=J.youtubeSearch(q);
  return r==="fail"?"Could not open YouTube.":"Searching YouTube for "+q+"."}
function setTorch(on){if(!nat())return "Native features only work inside the Android app.";var r=J.torch(on);status();
  return r==="unavailable"?"No flashlight available on this device.":"Flashlight "+r+"."}
function calc(l){var e=l.replace(/^(calculate|calc|what is|what's|compute)\s+/,"").replace(/x/g,"*").replace(/\^/g,"**").replace(/,/g,".").replace(/\s+/g,"");
  if(/^[\d+\-*\/().%]+$/.test(e)&&/[+\-*\/%]/.test(e)&&/\d/.test(e)){try{var r=Function('"use strict";return ('+e+')')();if(typeof r==="number"&&isFinite(r))return e.replace(/\*\*/g,"^")+" = "+(+r.toFixed(8))}catch(x){}}return null}
function route(l){
  var m;
  if(/^(hi|hello|hey|yo)\b/.test(l))return "Hello. All systems are online. How can I help?";
  if(/how are you/.test(l))return "Fully operational. Thank you for asking.";
  if(/who are you|your name/.test(l))return "I am JARVIS Ultimate 3.0, a local assistant running on this phone.";
  if(/^(thanks|thank you)/.test(l))return "You're welcome.";
  if((m=l.match(/^search (.+?) on youtube$/))||(m=l.match(/^(?:search youtube for|search youtube|youtube search for|youtube search|search for|play|youtube)\s+(.+)$/)))return ytSearch(m[1]);
  if((m=l.match(/^(?:open|launch|start|go to)\s+(.+)$/))||(TARGETS[l]&&(m=[l,l]))){var n=m[1].trim();
    if(TARGETS[n])return openTarget(TARGETS[n]);
    if(/^(android |phone )?settings$/.test(n)){if(!nat())return "Native features only work inside the Android app.";J.openSettings();return "Opening settings."}
    if(!nat())return "Native features only work inside the Android app.";var r=J.openApp(n);return r?"Opening "+r+".":"No installed app matches \""+n+"\"."}
  if(/^(android |phone )?settings$/.test(l)){if(!nat())return "Native features only work inside the Android app.";J.openSettings();return "Opening settings."}
  if(/flash ?light|torch/.test(l))return setTorch(/\b(off|disable|close)\b/.test(l)?false:/\b(on|enable)\b/.test(l)?true:!(J&&J.torchState()));
  if(/\b(time)\b/.test(l))return "It is "+new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})+".";
  if(/\b(date|today|day)\b/.test(l))return "Today is "+new Date().toLocaleDateString([],{weekday:"long",year:"numeric",month:"long",day:"numeric"})+".";
  if(/battery/.test(l)){var b=J?J.battery():-1;return b>=0?"Battery is at "+b+" percent.":"Battery level unavailable."}
  if(/^(stop|quiet|silence|shut up)/.test(l)){if(J){J.stopSpeak();J.stopVoice()}return "Stopped."}
  if(/^(mute|voice off)/.test(l)){cfg.tts=false;store.set("cfg",cfg);$("#cTts").checked=false;return "Spoken responses off."}
  if(/^(unmute|voice on)/.test(l)){cfg.tts=true;store.set("cfg",cfg);$("#cTts").checked=true;return "Spoken responses on."}
  if(/joke/.test(l))return JOKES[Math.random()*JOKES.length|0];
  if(/clear (history|chat)/.test(l)){if(/history/.test(l)){hist=[];store.set("hist",hist)}else $("#chat").innerHTML="";return "Cleared."}
  if((m=l.match(/^play voice (.+)$/))){if(!nat())return "Native features only work inside the Android app.";var vs=JSON.parse(J.listVoices()),q=m[1].trim(),f=/^\d+$/.test(q)?vs[+q-1]:vs.filter(function(v){return v.toLowerCase().indexOf(q)>-1})[0];
    if(!f)return "No imported voice file matches that.";J.playVoice(f);return "Playing "+f+"."}
  if(/^(help|commands|what can you do)/.test(l))return "Try: open YouTube, Instagram, Telegram, WhatsApp. Search YouTube for lo-fi music. Open [any app name]. Flashlight on or off. Settings. Time, date, battery. Calculate 12 x 8. Play voice 1. Joke. Mute.";
  var c=calc(l);if(c)return c;
  return "I have no local answer for that. Say help to see what I can do.";
}
function handle(raw){var t=(raw||"").trim();if(!t)return;add("you",t);pushHist(t);
  if(ytMode){ytMode=false;status();say(ytSearch(t));return}
  say(route(t.toLowerCase()))}

/* ---------- native events ---------- */
window.onNative=function(ev,d){
  if(ev==="heard"){$("#in").value="";handle(d)}
  else if(ev==="partial"){$("#in").value=d}
  else if(ev==="listening"){listening=true;SFX.micOn();status()}
  else if(ev==="idle"){if(listening)SFX.micOff();listening=false;status()}
  else if(ev==="error"){ytMode=false;SFX.err();add("err",d);status()}
  else if(ev==="info"){add("jv",d)}
  else if(ev==="voices"){try{renderVoices(JSON.parse(d))}catch(e){}}
};

/* ---------- wire up ---------- */
$("#send").onclick=function(){SFX.send();var v=$("#in").value;$("#in").value="";handle(v)};
$("#in").addEventListener("keydown",function(e){if(e.key==="Enter")$("#send").click()});
$("#mic").onclick=function(){if(!nat()){add("err","Microphone works only inside the Android app.");return}if(listening)J.stopListen();else J.listen()};
$("#ytv").onclick=function(){if(!nat()){add("err","Voice search works only inside the Android app.");return}ytMode=!ytMode;status();if(ytMode){add("jv","Say what to search on YouTube.");J.listen()}};
$("#torch").onclick=function(){add("you","flashlight");say(setTorch(!(J&&J.torchState())))};
document.querySelectorAll("[data-open]").forEach(function(b){b.onclick=function(){var k=b.dataset.open;pushHist("open "+k);say(openTarget(k))}});
document.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){setView(b.dataset.v)}});
$("#appq").oninput=renderApps;
$("#imp").onclick=function(){if(nat())J.importVoice();else add("err","Import works only inside the Android app.")};
$("#clrH").onclick=function(){hist=[];store.set("hist",hist);renderHist()};
$("#bClr").onclick=function(){$("#chat").innerHTML="";setView("chat")};
$("#bTest").onclick=function(){if(J)J.speak("JARVIS voice check. All systems online.");else add("err","Voice works only inside the Android app.")};
$("#bAndroid").onclick=function(){if(nat())J.openSettings()};
[["#cTts","tts"],["#cSfx","sfx"],["#cRain","rain"],["#cLite","lite"]].forEach(function(p){var e=$(p[0]);e.checked=!!cfg[p[1]];e.onchange=function(){cfg[p[1]]=e.checked;store.set("cfg",cfg);
  if(p[1]==="rain"&&!e.checked)rctx.clearRect(0,0,rain.width,rain.height);if(p[1]==="lite"){gMain.size();gBoot.size()}status()}});
addEventListener("resize",function(){rainSize();gMain.size()});
addEventListener("online",status);addEventListener("offline",status);

/* ---------- boot ---------- */
SFX.boot();gBoot=makeGlobe($("#bootGlobe"));gMain=makeGlobe($("#globe"));rainSize();requestAnimationFrame(loop);
var lines=["> kernel ............ OK","> display ........... OK","> bridge ............ "+(J?"OK":"NOT FOUND"),"> speech engine ..... "+(J?"CHECKED":"N/A"),"> voice library .... READY","> command core ...... ONLINE","> JARVIS ready"];
var bi=0,bt=$("#bootText"),iv=setInterval(function(){if(bi<lines.length){bt.textContent+=lines[bi++]+"\n"}else{clearInterval(iv)}},150);
setTimeout(function(){$("#boot").classList.add("off");booting=false;SFX.ready();gMain.size();clock();setInterval(clock,5000);
  add("jv","Online. Say help for commands.");
  if(J&&cfg.greet){try{if(JSON.parse(J.listVoices()).indexOf(cfg.greet)>-1)J.playVoice(cfg.greet);else if(cfg.tts)J.speak("Welcome back.")}catch(e){}}
  else if(J&&cfg.tts)J.speak("Welcome back.");
  setTimeout(function(){$("#boot").style.display="none"},600)},1400);
})();
