# Ramen Shift — Game Design Brief

Build a first-person 3D psychological-horror ramen-stand game in `./ramen-shift`, in the style of Chilla's Art and "The Boba Teashop". Plain HTML + JavaScript with Three.js (npm install three three-projection-snap, copy three.module.js into a local libs folder, NO CDN, must work fully offline). Mobile-first (Android Chrome/WebView) with desktop fallback.

## Story
The player works night shifts at their big cousin's ramen stand. The routine feels cozy and ordinary, then slowly turns sinister as a dark family secret unfolds across several in-game days.

## Art direction
- PS1 look: low internal resolution scaled up with nearest-neighbor, vertex snapping (three-projection-snap), affine-style texture wobble where cheap, nearest-filtered low-res textures, limited color depth, dark desaturated palette with warm lantern light, heavy fog, subtle film grain and dither.
- Models: load `.glb` files from `./assets` with GLTFLoader and apply the PS1 material to them. If a file is missing, build a simple blocky placeholder from code so the game never breaks. Characters have simple blocky bodies and plain, slightly unsettling faces.

## Step 1 only
1. Save this whole brief as `GAME_DESIGN.md`.
2. Structure: `index.html`, `src/main.js`, `renderer.js`, `player.js`, `world.js`, `ui.js`, `settings.js`, `assets/`, `README.md`. Keep every file small.
3. Scene: a small night ramen stand on a quiet street: counter, stove, pots, stools, hanging lantern, dark empty road, one streetlight.
4. Controls: left virtual joystick, drag-to-look on the right, an Interact button; WASD + mouse on desktop.
5. Menu with a Graphics setting (Low/Medium/High) that changes render scale and effects.
6. Optimization: no real-time shadows, max 3 lights, reuse geometries/materials, merge static meshes, cap at 30 FPS, dispose unused objects.
7. README with run instructions (`npx http-server`).

## Later steps (do not build yet)
2. Cooking loop: boil noodles, pour broth, add toppings, serve.
3. Customers: arrive, order, wait, pay, and leave; horn reminders replace a patience countdown, and wrong station choices count as mistakes.
4. Day system: each day unlocks new ramen (shoyu, miso, tonkotsu, spicy) and toppings, with a day summary screen.
5. Big cousin character, dialogue, and the slow-building family mystery through clues.
6. Horror: strange customers, light flicker, ambient audio, scares, nightmare sequences.
7. Package as `.tar.gz` and `.zip` for APK building.

## Updated direction: seven-night investigation

- Build a cinematic title screen with Play, Settings, and About pages over a gently moving view of the stand. Settings control graphics, sound, and jumpscare intensity.

The original stop-after-step-one instruction is superseded by the user's expanded direction. The gameplay reference is *Is Guilty*: a night-shift service job becomes an investigation through customer stories, license-plate checks, an in-game terminal, and escalating fear. Adapt that rhythm to the ramen stand and the cousin/family mystery; use original characters, clues, and story.

- The campaign lasts seven night shifts. Each shift has one killer among the visitors and a case email with vehicle/job clues.
- Each shift brings four or five customers. The player serves every visitor by taking an order, preparing the recipe at the kitchen stations, and serving it. Waiting customers honk every 14 seconds; there is no patience countdown. Wrong station choices count as mistakes. Successful customers pay in USD and drive away. Four ramen recipes unlock first; salmon nigiri, tuna cucumber maki, and California rolls unlock on Nights 5–7. The computer recipe book lists ingredients and preparation steps. Sales are tallied. A pass-through service window keeps the customer and kitchen stations reachable. CCTV captures every visitor’s plate; the player uses the resident/vehicle database, email, case file, and a persistent Notes app to investigate. Once every customer has been served, the player ends the shift and chooses one suspect. A wrong choice ends the run; a correct choice is confirmed before bedtime.
- A pale white figure watches from the road, then stalks and jumpscares the player during shifts; the haunting escalates across later nights. Solid collision prevents walking through walls, furniture, the counter, or arriving cars. After a correct choice, the player must walk to the bedroom bed and sleep to advance.
- The bedroom contains the bed and the computer terminal. The terminal has email, CCTV, plate lookup, case-file, Notes, and Recipes screens. Include pause/resume and save the current night and notes locally.
- Use original low-volume ambient music and restrained procedural sound effects; keep audio muteable and avoid sudden excessive loudness.
- Keep the original mobile-first, low-resolution rendering and lightweight scene constraints.
