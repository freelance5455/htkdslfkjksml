# PLANT WARS: EVOLUTION — Game Design Blueprint

## Core loop
Collect solar energy → deploy plant defenders → survive lane-based zombie waves → earn rewards → evolve/fuse plants → unlock new worlds.

## Core pillars
- Familiar five-lane tactical defense with original characters and visual identity.
- Colorful, polished 3D presentation with readable combat silhouettes.
- Meaningful unit roles, counters, and resource tradeoffs.
- Expandable world and mission architecture.

## Launch content target
- 10 worlds, each with 10 missions (100 missions).
- 30 base plants, each with 3 evolution tiers.
- 20 fusion recipes at launch, expandable through data-driven recipes.
- 25 regular zombie types and 10 bosses.
- Adventure, Survival, Challenge, Boss Rush, and Garden Lab modes.

## Plant archetypes
Solar / economy, projectile, splash, slow, wall / blocker, trap, support, anti-air, area control, and ultimate.

## Zombie archetypes
Walker, runner, armored, shield bearer, burrower, flyer, healer, spawner, toxic, and boss.

## Custom plant creator
Players unlock editable slots and combine:
- Core archetype (economy, attacker, support, defense, control)
- Element (solar, frost, toxic, electric, thorn, flame)
- Projectile or attack pattern
- Passive trait
- Visual skin and color palette

For balance, custom creations should use a point budget and validated combinations rather than unrestricted stats.

## Expandable world structure
Worlds are data-driven: each world defines environment palette, lane modifiers, enemy roster, plant unlocks, mission sequence, boss, and reward table. New worlds can be added without changing the core battle loop.

## Controls
Tap/click a plant card, then tap/click a tile. Tap collectible solar orbs. Keyboard support and drag-and-drop can be added in the next milestone.

## Technical direction
The prototype uses Babylon.js and procedural meshes. For production, use a modular game architecture:
- Battle simulation and wave director
- Plant/enemy definitions in JSON
- Economy and reward service
- Progression/save system
- Fusion and custom plant validation
- Audio/FX managers
- Platform input abstraction
