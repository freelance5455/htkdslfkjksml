# Ramen Shift — Game Design Brief

Build a first-person 3D psychological-horror ramen-stand game in `./ramen-shift`, in the style of Chilla's Art and "The Boba Teashop". Plain HTML + JavaScript with Three.js (npm install three three-projection-snap, copy three.module.js into a local libs folder, NO CDN, must work fully offline). Mobile-first (Android Chrome/WebView) with desktop fallback.

## Story
The player works night shifts at their big cousin's ramen stand. The routine feels cozy and ordinary, then slowly turns sinister as a dark family secret unfolds across several in-game days.

## Art direction
- PS1 look: low internal resolution scaled up with nearest-neighbor, vertex snapping (three-projection-snap), affine-style texture wobble where cheap, nearest-filtered low-res textures, limited color depth, dark desaturated palette with warm lantern light, heavy fog, subtle film grain and dither.
- Models: load `.glb` files from `./assets` with GLTFLoader and apply the PS1 material to them. If a file is missing, build a simple blocky placeholder from code so the game never breaks. Characters have simple blocky bodies and plain, slightly unsettling faces.

## Step 1 only
1. Save this whole brief as `GAME_DESIGN.md`.
2. Structure: `index.html`, `src/main.js`, `renderer.js`, `player.js`, `world.js`, `ui.js`, `settings.js`, `assets/`, `README.md`. Keep every file small.
3. Scene: a small night ramen stand on a quiet street: counter, stove, pots, stools, hanging lantern, dark empty road, one streetlight.
4. Controls: left virtual joystick, drag-to-look on the right, an Interact button; WASD + mouse on desktop.
5. Menu with a Graphics setting (Low/Medium/High) that changes render scale and effects.
6. Optimization: no real-time shadows, max 3 lights, reuse geometries/materials, merge static meshes, cap at 30 FPS, dispose unused objects.
7. README with run instructions (`npx http-server`).

## Later steps (do not build yet)
2. Cooking loop: boil noodles, pour broth, add toppings, serve.
3. Customers: arrive, order, wait, pay, leave, with patience and mistakes.
4. Day system: each day unlocks new ramen (shoyu, miso, tonkotsu, spicy) and toppings, with a day summary screen.
5. Big cousin character, dialogue, and the slow-building family mystery through clues.
6. Horror: strange customers, light flicker, ambient audio, scares, nightmare sequences.
7. Package as `.tar.gz` and `.zip` for APK building.

## Updated direction: seven-night investigation

The original stop-after-step-one instruction is superseded by the user's expanded direction. The gameplay reference is *Is Guilty*: a night-shift service job becomes an investigation through customer stories, license-plate checks, an in-game terminal, and escalating fear. Adapt that rhythm to the ramen stand and the cousin/family mystery; use original characters, clues, and story.

- The campaign lasts seven night shifts. Each shift has one killer among the visitors and a case email with vehicle/job clues.
- CCTV captures visitor plate numbers. The player looks each plate up in the in-game resident/vehicle database and compares the identity with the case file before accusing someone.
- A ghost stalks and scares the player during shifts. The player returns to the small bedroom and sleeps after closing a solved shift to advance to the next day.
- The bedroom contains the bed and the computer terminal. The terminal has email, CCTV, plate lookup, and case-file screens.
- Keep the original mobile-first, low-resolution rendering and lightweight scene constraints.
