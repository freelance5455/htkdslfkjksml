'use strict';
/*
 * اخبار و ارتباط با تریدرها — کانال/گروه چت داخل برنامه (مثل تلگرام)
 *  GET  /chat/rooms                       فهرست اتاق‌ها
 *  GET  /chat/msgs?room&after&before&kind پیام‌ها (kind=media|links برای تب‌های پروفایل)
 *  GET  /chat/media/<file>                تصویر
 *  POST /chat/join|leave|send|del|seen|profile
 *  POST /chat/admin                       مدیریت (فقط با x-admin-token)
 * هویت کاربر: uid + کلید تصادفی دستگاه (اولین استفاده ثبت می‌شود؛ بعد از آن کس دیگری نمی‌تواند با همان uid پیام بدهد).
 */
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');

const MAX_TEXT = 2000, MAX_IMG = 1_500_000, KEEP = 4000, MAX_USERS = 300000;
const URL_RE = /https?:\/\/[^\s<>"']+/gi;
const IMG_RE = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/;
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F‪-‮⁦-⁩]/g, '').trim().slice(0, n);

async function createChat({ cfg, dataDir, log, sendJson, readBody, httpErr, safeEqual, isAdminReq, baseHeaders }) {
  const dir = path.join(dataDir, 'chat');
  const mediaDir = path.join(dir, 'media');
  await fsp.mkdir(mediaDir, { recursive: true });
  const file = path.join(dir, 'chat.json');
  let raw = {};
  try { raw = JSON.parse(await fsp.readFile(file, 'utf8')); } catch { /* اولین اجرا */ }
  const db = {
    rooms: Array.isArray(raw.rooms) ? raw.rooms : [],
    msgs: raw.msgs || {}, members: raw.members || {}, users: raw.users || {}, seen: raw.seen || {},
  };
  const mkRoom = (o) => ({ id: o.id || crypto.randomBytes(4).toString('hex'), title: clean(o.title, 60) || 'گروه', bio: clean(o.bio, 500), avatar: o.avatar || '', kind: o.kind === 'group' ? 'group' : 'channel', postMode: o.postMode === 'admins' ? 'admins' : 'all', pinned: 0, slow: Math.max(0, Math.min(3600, +o.slow || 0)), noLinks: !!o.noLinks, noImages: !!o.noImages, closed: false, at: Date.now() });
  if (!db.rooms.length) {
    db.rooms.push(mkRoom({ id: 'news', title: 'اخبار ترید یار', kind: 'channel', postMode: 'admins', bio: 'اخبار بازار، آموزش و اطلاعیه‌های رسمی ترید یار' }));
    db.rooms.push(mkRoom({ id: 'traders', title: 'ارتباط با تریدرها', kind: 'group', postMode: 'all', bio: 'گفت‌وگوی آزاد تریدرها؛ تحلیل، ایده و تجربه‌ات را با بقیه به اشتراک بگذار. رعایت ادب الزامی است.' }));
  }
  db.rooms.forEach((r) => { db.msgs[r.id] = db.msgs[r.id] || []; db.members[r.id] = db.members[r.id] || {}; db.seen[r.id] = db.seen[r.id] || {}; });

  let saving = Promise.resolve(), dirty = false, timer = null;
  const saveNow = () => {
    saving = saving.then(async () => {
      const tmp = file + '.tmp';
      await fsp.writeFile(tmp, JSON.stringify(db), { mode: 0o600 });
      await fsp.rename(tmp, file);
    }).catch((e) => log('error', 'chat save', { err: String(e && e.message) }));
    return saving;
  };
  const save = () => { dirty = true; if (!timer) timer = setTimeout(() => { timer = null; if (dirty) { dirty = false; saveNow(); } }, 1500); };
  const flush = async () => { if (timer) { clearTimeout(timer); timer = null; } if (dirty) { dirty = false; await saveNow(); } await saving; };

  const syncOk = (req) => !cfg.syncToken || safeEqual(String(req.headers['x-tradyar-token'] || ''), cfg.syncToken);
  const lastSend = new Map();
  const room = (id) => db.rooms.find((r) => r.id === id);
  const needRoom = (id) => { const r = room(String(id || '')); if (!r) throw httpErr(404, 'no_room'); return r; };

  function auth(req) {
    const uid = String(req.headers['x-chat-uid'] || ''), key = String(req.headers['x-chat-key'] || '');
    if (!/^[\w.-]{3,64}$/.test(uid) || key.length < 16 || key.length > 200) throw httpErr(401, 'bad_identity');
    let u = db.users[uid];
    if (!u) {
      if (Object.keys(db.users).length > MAX_USERS) throw httpErr(503, 'full');
      u = db.users[uid] = { h: sha(key), name: '', at: Date.now() };
      save();
    } else if (!u.h) { u.h = sha(key); save(); } else if (!safeEqual(u.h, sha(key))) throw httpErr(403, 'identity_mismatch');
    return { uid, u };
  }
  const isBanned = (u) => !!u.banned;
  const muted = (u) => u.mutedUntil && u.mutedUntil > Date.now();

  async function saveImage(dataUrl) {
    const m = IMG_RE.exec(String(dataUrl || ''));
    if (!m) throw httpErr(400, 'bad_image');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length < 100 || buf.length > MAX_IMG) throw httpErr(413, 'image_too_large');
    const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
    const magicOk = ext === 'jpg' ? (buf[0] === 0xFF && buf[1] === 0xD8) : ext === 'png' ? (buf.slice(1, 4).toString() === 'PNG') : (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP');
    if (!magicOk) throw httpErr(400, 'bad_image');
    const name = crypto.randomBytes(12).toString('hex') + '.' + ext;
    await fsp.writeFile(path.join(mediaDir, name), buf, { mode: 0o600 });
    return name;
  }

  const pubMsg = (m, uid) => ({ id: m.id, uid: m.admin ? 'admin' : m.uid, name: m.name, text: m.text, img: m.img || '', links: m.links || [], reply: m.reply || null, at: m.at, views: m.views || 0, admin: !!m.admin, mine: m.uid === uid, edited: m.edited || 0 });
  const live = (id) => db.msgs[id].filter((m) => !m.del);
  const pubRoom = (r, uid) => {
    const l = live(r.id), last = l[l.length - 1];
    const pin = r.pinned ? db.msgs[r.id].find((m) => m.id === r.pinned && !m.del) : null;
    return { id: r.id, title: r.title, bio: r.bio, avatar: r.avatar, kind: r.kind, postMode: r.postMode, slow: r.slow, noLinks: r.noLinks, noImages: r.noImages, closed: r.closed, members: Object.keys(db.members[r.id]).length, joined: !!(uid && db.members[r.id][uid]), count: l.length, media: l.filter((m) => m.img).length, links: l.filter((m) => m.links && m.links.length).length, pinned: pin ? pubMsg(pin, uid) : null, last: last ? { text: last.text || (last.img ? 'تصویر' : ''), name: last.name, at: last.at } : null, unread: uid ? Math.max(0, l.filter((m) => m.id > ((db.seen[r.id][uid]) || 0)).length) : 0 };
  };

  async function handle(req, res, url, p) {
    const sub = p.slice(5) || '/';
    if (req.method === 'GET' && sub.startsWith('/media/')) {
      const f = sub.slice(7);
      if (!/^[a-f0-9]{24}\.(jpg|png|webp)$/.test(f)) throw httpErr(404, 'not_found');
      let buf; try { buf = await fsp.readFile(path.join(mediaDir, f)); } catch { throw httpErr(404, 'not_found'); }
      res.writeHead(200, { ...baseHeaders, 'Content-Type': f.endsWith('.png') ? 'image/png' : f.endsWith('.webp') ? 'image/webp' : 'image/jpeg', 'Cache-Control': 'public, max-age=31536000, immutable', 'Cross-Origin-Resource-Policy': 'cross-origin' });
      return res.end(buf);
    }
    if (!syncOk(req)) throw httpErr(401, 'unauthorized');
    if (sub === '/admin') return admin(req, res);
    const { uid, u } = auth(req);
    if (isBanned(u)) throw httpErr(403, 'banned');

    if (req.method === 'GET' && sub === '/rooms') return sendJson(res, 200, { ok: true, rooms: db.rooms.map((r) => pubRoom(r, uid)) });
    if (req.method === 'GET' && sub === '/msgs') {
      const r = needRoom(url.searchParams.get('room'));
      const after = +url.searchParams.get('after') || 0, before = +url.searchParams.get('before') || 0, kind = url.searchParams.get('kind') || '';
      const limit = Math.max(1, Math.min(100, +url.searchParams.get('limit') || 40));
      let l = live(r.id);
      if (kind === 'media') l = l.filter((m) => m.img); else if (kind === 'links') l = l.filter((m) => m.links && m.links.length);
      if (after) l = l.filter((m) => m.id > after); else if (before) l = l.filter((m) => m.id < before).slice(-limit); else l = l.slice(-limit);
      const dels = after ? db.msgs[r.id].filter((m) => m.del && m.id > Math.max(0, after - 200)).map((m) => m.id) : [];
      return sendJson(res, 200, { ok: true, msgs: l.map((m) => pubMsg(m, uid)), deleted: dels, room: pubRoom(r, uid) });
    }
    if (req.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    let body; try { body = JSON.parse(await readBody(req, 2_400_000)); } catch (e) { if (e && e.status) throw e; throw httpErr(400, 'bad_json'); }
    if (body && body.name) u.name = clean(body.name, 40) || u.name;

    if (sub === '/join' || sub === '/leave') {
      const r = needRoom(body.room);
      if (sub === '/join') { if (r.closed) throw httpErr(403, 'closed'); db.members[r.id][uid] = { name: u.name, at: Date.now() }; } else delete db.members[r.id][uid];
      save(); return sendJson(res, 200, { ok: true, room: pubRoom(r, uid) });
    }
    if (sub === '/seen') {
      const r = needRoom(body.room), n = Math.max(0, +body.n || 0), prev = db.seen[r.id][uid] || 0;
      if (n > prev) { let c = 0; for (const m of db.msgs[r.id]) { if (m.id > prev && m.id <= n && !m.del) { m.views = (m.views || 0) + 1; if (++c > 400) break; } } db.seen[r.id][uid] = n; save(); }
      return sendJson(res, 200, { ok: true });
    }
    if (sub === '/del') {
      const r = needRoom(body.room), m = db.msgs[r.id].find((x) => x.id === +body.id);
      if (!m || m.uid !== uid) throw httpErr(403, 'not_yours');
      m.del = 1; m.text = ''; m.img = ''; save(); return sendJson(res, 200, { ok: true });
    }
    if (sub === '/send') {
      const r = needRoom(body.room), asAdmin = !!body.asAdmin && isAdminReq(req);
      if (!asAdmin) {
        if (r.closed) throw httpErr(403, 'closed');
        if (!db.members[r.id][uid]) throw httpErr(403, 'not_member');
        if (r.postMode === 'admins') throw httpErr(403, 'admins_only');
        if (muted(u)) throw httpErr(403, 'muted');
      }
      const text = clean(body.text, MAX_TEXT);
      if (!text && !body.img) throw httpErr(400, 'empty');
      const now = Date.now(), gap = asAdmin ? 0 : Math.max(1200, r.slow * 1000), last = lastSend.get(uid + ':' + r.id) || 0;
      if (now - last < gap) throw Object.assign(httpErr(429, 'slow_mode'), { retryAfter: Math.ceil((gap - (now - last)) / 1000) });
      const links = (text.match(URL_RE) || []).slice(0, 5).map((x) => x.replace(/[.,;:!?)]+$/, ''));
      if (!asAdmin && r.noLinks && links.length) throw httpErr(403, 'links_blocked');
      if (!asAdmin && r.noImages && body.img) throw httpErr(403, 'images_blocked');
      const img = body.img ? await saveImage(body.img) : '';
      lastSend.set(uid + ':' + r.id, now); if (lastSend.size > 50000) lastSend.clear();
      const list = db.msgs[r.id], id = (list.length ? list[list.length - 1].id : 0) + 1;
      let reply = null;
      if (body.replyTo) { const o = list.find((x) => x.id === +body.replyTo && !x.del); if (o) reply = { id: o.id, name: o.name, text: (o.text || (o.img ? 'تصویر' : '')).slice(0, 90) }; }
      const m = { id, uid, name: asAdmin ? (clean(body.adminName, 40) || 'مدیر ترید یار') : (u.name || 'کاربر'), text, img, links, reply, at: now, views: 0, admin: asAdmin };
      list.push(m);
      if (list.length > KEEP) list.splice(0, list.length - KEEP);
      save(); return sendJson(res, 200, { ok: true, msg: pubMsg(m, uid) });
    }
    throw httpErr(404, 'not_found');
  }

  async function admin(req, res) {
    if (!isAdminReq(req)) throw httpErr(403, 'admin_only');
    let body = {};
    if (req.method === 'POST') { try { body = JSON.parse(await readBody(req, 2_400_000)); } catch { throw httpErr(400, 'bad_json'); } }
    const ok = (extra) => sendJson(res, 200, { ok: true, ...extra });
    switch (String(body.op || '')) {
      case 'overview': return ok({ rooms: db.rooms.map((r) => pubRoom(r, '')), users: Object.keys(db.users).length, banned: Object.values(db.users).filter((x) => x.banned).length });
      case 'room.create': { const r = mkRoom(body); if (body.img) r.avatar = await saveImage(body.img); db.rooms.push(r); db.msgs[r.id] = []; db.members[r.id] = {}; db.seen[r.id] = {}; save(); return ok({ room: pubRoom(r, '') }); }
      case 'room.update': {
        const r = needRoom(body.room);
        if (body.title != null) r.title = clean(body.title, 60) || r.title;
        if (body.bio != null) r.bio = clean(body.bio, 500);
        if (body.kind) r.kind = body.kind === 'group' ? 'group' : 'channel';
        if (body.postMode) r.postMode = body.postMode === 'admins' ? 'admins' : 'all';
        if (body.slow != null) r.slow = Math.max(0, Math.min(3600, +body.slow || 0));
        if (body.noLinks != null) r.noLinks = !!body.noLinks;
        if (body.noImages != null) r.noImages = !!body.noImages;
        if (body.closed != null) r.closed = !!body.closed;
        if (body.img) r.avatar = await saveImage(body.img);
        if (body.removeAvatar) r.avatar = '';
        save(); return ok({ room: pubRoom(r, '') });
      }
      case 'room.delete': { const r = needRoom(body.room); db.rooms = db.rooms.filter((x) => x !== r); delete db.msgs[r.id]; delete db.members[r.id]; delete db.seen[r.id]; save(); return ok({}); }
      case 'room.clear': { const r = needRoom(body.room); db.msgs[r.id] = []; r.pinned = 0; save(); return ok({}); }
      case 'msg.delete': { const r = needRoom(body.room), m = db.msgs[r.id].find((x) => x.id === +body.id); if (!m) throw httpErr(404, 'no_msg'); m.del = 1; m.text = ''; m.img = ''; if (r.pinned === m.id) r.pinned = 0; save(); return ok({}); }
      case 'msg.pin': { const r = needRoom(body.room); const id = +body.id || 0; if (id && !db.msgs[r.id].some((x) => x.id === id && !x.del)) throw httpErr(404, 'no_msg'); r.pinned = id; save(); return ok({ room: pubRoom(r, '') }); }
      case 'user.ban': { const x = db.users[String(body.uid)]; if (!x) throw httpErr(404, 'no_user'); x.banned = !!body.on; if (x.banned) Object.values(db.members).forEach((mm) => { delete mm[String(body.uid)]; }); save(); return ok({}); }
      case 'user.reset': { const x = db.users[String(body.uid)]; if (!x) throw httpErr(404, 'no_user'); x.h = ''; save(); return ok({}); }
      case 'user.mute': { const x = db.users[String(body.uid)]; if (!x) throw httpErr(404, 'no_user'); const mins = Math.max(0, Math.min(60 * 24 * 365, +body.minutes || 0)); x.mutedUntil = mins ? Date.now() + mins * 60000 : 0; save(); return ok({}); }
      case 'member.kick': { const r = needRoom(body.room); delete db.members[r.id][String(body.uid)]; save(); return ok({}); }
      case 'members': {
        const r = needRoom(body.room), q = clean(body.q, 40).toLowerCase();
        const l = Object.entries(db.members[r.id]).map(([id, m]) => ({ uid: id, name: (db.users[id] && db.users[id].name) || m.name || '', at: m.at, banned: !!(db.users[id] && db.users[id].banned), muted: !!(db.users[id] && muted(db.users[id])) })).filter((x) => !q || x.name.toLowerCase().includes(q) || x.uid.includes(q));
        return ok({ members: l.slice(0, 300), total: l.length });
      }
      case 'banned': return ok({ users: Object.entries(db.users).filter(([, x]) => x.banned || muted(x)).map(([id, x]) => ({ uid: id, name: x.name, banned: !!x.banned, mutedUntil: x.mutedUntil || 0 })).slice(0, 300) });
      default: throw httpErr(404, 'unknown_op');
    }
  }
  const isChatPath = (p) => p === '/chat' || p.startsWith('/chat/');
  return { handle, isChatPath, flush, _db: db };
}
module.exports = { createChat };
