/**
 * JARVIS Explicit Capability Registry
 * High-dimensional catalog of system capabilities, permissions, schemas, risk levels,
 * failure modes, execution modes, and verification contracts for dynamic task formulation.
 * 
 * Strict Reality Contract:
 * Every capability explicitly reports one of:
 * - REAL
 * - SIMULATED
 * - UNAVAILABLE
 * - BLOCKED_REQUIRES_PERMISSION
 * - FAILED
 * 
 * Never represents SIMULATED or UNAVAILABLE as REAL.
 */

import {
  CapabilityAvailability,
  CapabilityCategory,
  CapabilityDescriptor,
  ExecutionMode,
  PermissionLevel,
  SafetyLevel,
} from '../types.ts';

export type { CapabilityDescriptor };

export class CapabilityRegistry {
  private capabilities: Map<string, CapabilityDescriptor> = new Map();

  constructor() {
    this.registerDefaultCapabilities();
  }

  public register(descriptor: CapabilityDescriptor): void {
    // Ensure both id and capabilityId are present and synchronized
    const id = descriptor.capabilityId || descriptor.id;
    descriptor.id = id;
    descriptor.capabilityId = id;
    this.capabilities.set(id, descriptor);
  }

  public get(id: string): CapabilityDescriptor | undefined {
    return this.capabilities.get(id);
  }

  public getAll(): CapabilityDescriptor[] {
    return Array.from(this.capabilities.values());
  }

  public getByCategory(category: CapabilityCategory): CapabilityDescriptor[] {
    return this.getAll().filter((c) => c.category === category);
  }

  /**
   * Discovers matching capabilities for a given intent or required features
   */
  public discoverCapabilities(features: string[]): CapabilityDescriptor[] {
    const discovered: CapabilityDescriptor[] = [];
    const lowerFeatures = features.map((f) => f.toLowerCase());

    for (const cap of this.capabilities.values()) {
      const match = lowerFeatures.some(
        (f) =>
          cap.id.toLowerCase().includes(f) ||
          cap.name.toLowerCase().includes(f) ||
          cap.category.toLowerCase().includes(f) ||
          cap.description.toLowerCase().includes(f)
      );
      if (match) {
        discovered.push(cap);
      }
    }

    return discovered;
  }

  private registerDefaultCapabilities(): void {
    // 1. General Dialogue
    this.register({
      capabilityId: 'general_dialogue',
      id: 'general_dialogue',
      name: 'General Conversational Dialogue',
      description: 'Engages in natural, adaptive multi-turn conversations, greetings, and contextual explanations.',
      category: 'conversation',
      supportedInputs: { prompt: 'string', conversationHistory: 'string[]' },
      supportedOutputs: { text: 'string' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'model_router',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['all'],
      dependencies: [],
      verificationMethod: 'Semantic completeness and coherence validation',
      failureModes: ['TIMEOUT', 'PROVIDER_ERROR', 'CONTEXT_OVERFLOW'],
    });

    // 2. Structured Educational Explanation
    this.register({
      capabilityId: 'educational_explanation',
      id: 'educational_explanation',
      name: 'Structured Educational Explanation',
      description: 'Deconstructs complex concepts across mathematics, physics, science, and engineering with intuitive analogies, mechanisms, and rigor.',
      category: 'explanation',
      supportedInputs: { topic: 'string', depth: 'string', language: 'string' },
      supportedOutputs: { explanation: 'string', rigorSections: 'object' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'model_router',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['all'],
      dependencies: [],
      verificationMethod: 'Conceptual accuracy and structural cohesion check',
      failureModes: ['TIMEOUT', 'PROVIDER_ERROR'],
    });

    // 3. Multilingual Generation
    this.register({
      capabilityId: 'multilingual_generation',
      id: 'multilingual_generation',
      name: 'Multilingual & Hinglish Generation',
      description: 'Generates fluent responses in English, Hindi, and colloquial Hinglish with technical term preservation.',
      category: 'conversation',
      supportedInputs: { language: 'string', prompt: 'string' },
      supportedOutputs: { text: 'string', detectedLanguage: 'string' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'language_system',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['all'],
      dependencies: [],
      verificationMethod: 'Language marker detection and terminology inspection',
      failureModes: ['TRANSLATION_DRIFT', 'UNKNOWN_LOCALE'],
    });

    // 4. Computation & Math Calculation (REAL)
    this.register({
      capabilityId: 'math_computation',
      id: 'math_computation',
      name: 'Deterministic Math & Computation',
      description: 'Performs verified numerical calculations, arithmetic, and quantitative modeling without code sandboxes.',
      category: 'computation',
      supportedInputs: { expression: 'string', precision: 'number' },
      supportedOutputs: { result: 'number', verification: 'object' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'deterministic_arithmetic_evaluator',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['all'],
      dependencies: ['math_computation'],
      verificationMethod: 'Arithmetic inverse operation check (e.g. product / b == a)',
      failureModes: ['DIV_BY_ZERO', 'INVALID_EXPRESSION', 'PRECISION_OVERFLOW'],
    });

    // 5. Code Generation & Static Analysis (REAL)
    this.register({
      capabilityId: 'code_generation_analysis',
      id: 'code_generation_analysis',
      name: 'Code Generation & Static Analysis',
      description: 'Synthesizes clean, secure, type-safe algorithms and performs static code analysis.',
      category: 'coding',
      supportedInputs: { language: 'string', specification: 'string' },
      supportedOutputs: { code: 'string', syntaxValid: 'boolean', complexity: 'number' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'code_analyzer',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['server'],
      dependencies: ['code_analyzer'],
      verificationMethod: 'AST syntax parsing and zero forbidden globals check',
      failureModes: ['SYNTAX_ERROR', 'FORBIDDEN_GLOBAL', 'TIMEOUT'],
    });

    // 6. Isolated Sandboxed Execution (REAL in isolated VM, SENSITIVE permission)
    this.register({
      capabilityId: 'sandboxed_execution',
      id: 'sandboxed_execution',
      name: 'Isolated Sandboxed Execution',
      description: 'Executes algorithmic code in an isolated runtime without filesystem or network access.',
      category: 'coding',
      supportedInputs: { code: 'string', language: 'string' },
      supportedOutputs: { exitCode: 'number', stdout: 'string', memoryUsageMb: 'number' },
      requiredPermissions: 'SENSITIVE',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'code_sandbox',
      safetyLevel: 'CONTROLLED',
      riskLevel: 'HIGH',
      supportedEnvironments: ['container'],
      dependencies: ['code_sandbox'],
      verificationMethod: 'Process exit code 0 and timeout enforcement',
      failureModes: ['TIMEOUT', 'SECURITY_POLICY_VIOLATION', 'OUT_OF_MEMORY'],
    });

    // 7. Web & Fact Verification Research (Truthful state: SIMULATED offline test index)
    this.register({
      capabilityId: 'web_research',
      id: 'web_research',
      name: 'Web & Fact Verification Research',
      description: 'Retrieves multi-source citations. Reports SIMULATED status when offline index is used rather than live search.',
      category: 'research',
      supportedInputs: { query: 'string', maxResults: 'number' },
      supportedOutputs: { citations: 'array', totalFound: 'number' },
      requiredPermissions: 'READ',
      executionMode: 'SIMULATED',
      availability: 'SIMULATED',
      provider: 'curated_offline_research_index',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['web', 'server'],
      dependencies: ['web_search'],
      verificationMethod: 'Citation existence and URL domain schema validation',
      failureModes: ['EXTERNAL_SEARCH_UNAVAILABLE', 'TIMEOUT', 'NO_RESULTS'],
    });

    // 8. Persistent Memory Retrieval & Storage (REAL)
    this.register({
      capabilityId: 'memory_retrieval_storage',
      id: 'memory_retrieval_storage',
      name: 'Persistent Memory Retrieval & Storage',
      description: 'Stores and retrieves user facts, preferences, session context, and long-term notes in durable SQLite/Postgres storage.',
      category: 'memory',
      supportedInputs: { query: 'string', key: 'string', content: 'string' },
      supportedOutputs: { stored: 'boolean', entries: 'array' },
      requiredPermissions: 'SAFE_WRITE',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'persistent_database_engine',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['database'],
      dependencies: ['memory_persist', 'memory_search'],
      verificationMethod: 'Database query persistence validation and key-value equality check',
      failureModes: ['DATABASE_UNAVAILABLE', 'KEY_NOT_FOUND', 'VALIDATION_ERROR'],
    });

    // 9. System Telemetry & Diagnostics (REAL)
    this.register({
      capabilityId: 'system_telemetry',
      id: 'system_telemetry',
      name: 'System Telemetry & Diagnostics',
      description: 'Inspects host memory, process uptime, database connectivity, and security event logs.',
      category: 'system',
      supportedInputs: { deepScan: 'boolean' },
      supportedOutputs: { osStatus: 'string', uptimeSeconds: 'number', memoryRssMb: 'number' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'system_diagnostics',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['all'],
      dependencies: ['system_diagnostics'],
      verificationMethod: 'JSON schema conformance and positive uptime assertion',
      failureModes: ['METRICS_UNAVAILABLE'],
    });

    // 10. Defensive Cybersecurity Analysis (REAL - Safe defensive analysis)
    this.register({
      capabilityId: 'defensive_cybersecurity',
      id: 'defensive_cybersecurity',
      name: 'Defensive Cybersecurity & Vulnerability Analysis',
      description: 'Analyzes code, configurations, dependencies, and audit logs for vulnerabilities, secret exposure, and misconfigurations without offensive exploits.',
      category: 'cybersecurity',
      supportedInputs: { targetType: 'string', payload: 'string' },
      supportedOutputs: { vulnerabilityCount: 'number', findings: 'array', threatModel: 'object' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'security_audit_analyzer',
      safetyLevel: 'SAFE',
      riskLevel: 'MEDIUM',
      supportedEnvironments: ['server'],
      dependencies: ['security_audit_analyzer'],
      verificationMethod: 'CWE / OWASP rule matching and signature verification',
      failureModes: ['PARSE_ERROR', 'UNAUTHORIZED_TARGET'],
    });

    // 11. Authorized Penetration Testing Foundation (BLOCKED_REQUIRES_PERMISSION)
    this.register({
      capabilityId: 'authorized_penetration_testing',
      id: 'authorized_penetration_testing',
      name: 'Authorized Penetration Testing Workflow',
      description: 'Formal security testing workflow requiring verified AUTHORIZED_SECURITY_TESTING scope and explicit operator clearance. Strictly rejects unauthorized access.',
      category: 'cybersecurity',
      supportedInputs: { targetDomain: 'string', scopeToken: 'string', authorizedBy: 'string' },
      supportedOutputs: { testReceipt: 'string', findingsSummary: 'string' },
      requiredPermissions: 'EXTERNAL_ACTION',
      executionMode: 'BLOCKED_REQUIRES_PERMISSION',
      availability: 'REAL',
      provider: 'authorized_security_framework',
      safetyLevel: 'CRITICAL',
      riskLevel: 'CRITICAL',
      supportedEnvironments: ['server'],
      dependencies: ['security_layer'],
      verificationMethod: 'Operator cryptographic approval token and authorized scope validation',
      failureModes: ['UNAUTHORIZED_ATTEMPT_REJECTED', 'OPERATOR_REJECTED', 'SCOPE_EXCEEDED'],
    });

    // 12. External Action Dispatch (BLOCKED_REQUIRES_PERMISSION)
    this.register({
      capabilityId: 'external_action_dispatch',
      id: 'external_action_dispatch',
      name: 'External Action & Side-Effect Dispatch',
      description: 'Mutates external services, dispatches webhook events, publishes media, or modifies remote state. Strictly pauses for operator authorization.',
      category: 'automation',
      supportedInputs: { targetSystem: 'string', payload: 'object' },
      supportedOutputs: { status: 'string', executionReceipt: 'string' },
      requiredPermissions: 'EXTERNAL_ACTION',
      executionMode: 'BLOCKED_REQUIRES_PERMISSION',
      availability: 'REAL',
      provider: 'automation_action',
      safetyLevel: 'CRITICAL',
      riskLevel: 'CRITICAL',
      supportedEnvironments: ['cloud'],
      dependencies: ['automation_action'],
      verificationMethod: 'Explicit operator authorization challenge resolution',
      failureModes: ['PERMISSION_DENIED', 'OPERATOR_REJECTED', 'DISPATCH_TIMEOUT'],
    });

    // 13. Native Device & App Control (UNAVAILABLE in web environment)
    this.register({
      capabilityId: 'device_app_control',
      id: 'device_app_control',
      name: 'Native Device & App Control (Android/Desktop)',
      description: 'Device actions (OPEN_APP, TYPE_TEXT, TAP_UI_ELEMENT, PRESS_KEY, SCROLL, READ_SCREEN, TAKE_SCREENSHOT). Marked UNAVAILABLE: Web sandbox cannot control native OS devices without native companion.',
      category: 'device_control',
      supportedInputs: { action: 'string', appPackage: 'string', coordinates: 'object' },
      supportedOutputs: { success: 'boolean', message: 'string' },
      requiredPermissions: 'EXTERNAL_ACTION',
      executionMode: 'UNAVAILABLE',
      availability: 'UNAVAILABLE',
      provider: 'unsupported_web_sandbox',
      safetyLevel: 'CRITICAL',
      riskLevel: 'CRITICAL',
      supportedEnvironments: ['android_companion'],
      dependencies: ['device_control_action'],
      verificationMethod: 'Native companion ping response',
      failureModes: ['NO_ANDROID_COMPANION_CONNECTED', 'SANDBOX_RESTRICTION', 'UNAVAILABLE'],
    });

    // 14. Free Resource Discovery (REAL)
    this.register({
      capabilityId: 'free_resource_discovery',
      id: 'free_resource_discovery',
      name: 'Legitimate Free Resource Discovery',
      description: 'Finds verified, legitimate, and copyright-compliant free internet resources across AI tools, courses, streaming, music, dev tools, and open source.',
      category: 'research',
      supportedInputs: { query: 'string', category: 'string', mustBeGenuinelyFree: 'boolean', noPaymentCardRequired: 'boolean' },
      supportedOutputs: { totalFound: 'number', resources: 'array', legalCompliancePassed: 'boolean' },
      requiredPermissions: 'READ',
      executionMode: 'REAL',
      availability: 'REAL',
      provider: 'free_resource_discovery',
      safetyLevel: 'SAFE',
      riskLevel: 'LOW',
      supportedEnvironments: ['server', 'cloud'],
      dependencies: ['free_resource_discovery'],
      verificationMethod: 'Curated registry validation and copyright compliance check',
      failureModes: ['PIRACY_QUERY_BLOCKED', 'NO_MATCHING_RESOURCES'],
    });
  }
}

export const capabilityRegistry = new CapabilityRegistry();
