/**
 * JARVIS Capability Discovery & Awareness System
 * Classifies requested capabilities and operations into precise epistemic categories:
 * - AVAILABLE: Fully operational right now in this environment
 * - REQUIRES_PERMISSION: Operational but guarded by human authorization
 * - REQUIRES_INTEGRATION: Possible in architecture, but requires external credential/service setup
 * - UNAVAILABLE: Hardware or environment bridge is not physically present (e.g., native phone hardware from web container)
 * - NOT_SUPPORTED: Guardrail blocked or prohibited by safety policy
 */

import type { CapabilityAwarenessStatus } from '../types.ts';

export interface CapabilityAssessment {
  operation: string;
  category: string;
  status: CapabilityAwarenessStatus;
  canExecuteNow: boolean;
  isSupported: boolean;
  reason: string;
  remediation?: string;
}

export class CapabilityDiscoverySystem {
  /**
   * Classify user request intent into capability status
   */
  public assessCapability(prompt: string): CapabilityAssessment {
    const p = (prompt || '').toLowerCase().trim();

    // 1. Prohibited / Safety guardrails (NOT_SUPPORTED)
    if (
      /hack|crack|bypass\s+drm|pirate|torrent\s+(?:movie|game)|keygen|malware|steal|exploit|real\s+(?:money|trading|transfer)/i.test(
        p
      )
    ) {
      return {
        operation: 'Security / Guardrail Policy',
        category: 'SAFETY_POLICY',
        status: 'NOT_SUPPORTED',
        canExecuteNow: false,
        isSupported: false,
        reason:
          'JARVIS security and ethics boundary strictly prohibits illicit actions, DRM bypass, and real financial transfers.',
      };
    }

    // 2. Physical device hardware requiring mobile daemon (UNAVAILABLE in web environment)
    if (
      /turn\s+on\s+flashlight|vibrate\s+phone|hardware\s+gpio|screen-off\s+listening|phone\s+call\s+without\s+bridge/i.test(
        p
      )
    ) {
      return {
        operation: 'Device Native Hardware',
        category: 'PHYSICAL_DEVICE',
        status: 'UNAVAILABLE',
        canExecuteNow: false,
        isSupported: false,
        reason:
          'Browser environment does not possess direct hardware access to mobile flashlight, physical vibration motors, or GPIO pins.',
        remediation: 'Requires companion mobile APK daemon or local IoT hardware daemon.',
      };
    }

    // 3. External cloud / account integrations requiring credentials (REQUIRES_INTEGRATION)
    if (
      /send\s+(?:whatsapp|telegram|email|sms)|google\s+drive\s+upload|spotify\s+play/i.test(p) &&
      !/simulation|mock/i.test(p)
    ) {
      return {
        operation: 'Third-Party Service Dispatch',
        category: 'EXTERNAL_INTEGRATION',
        status: 'REQUIRES_INTEGRATION',
        canExecuteNow: false,
        isSupported: false,
        reason:
          'External messaging or cloud synchronization requires OAuth or API service credentials.',
        remediation:
          'Configure service credentials in Settings or use simulated development sandbox mode.',
      };
    }

    // 4. Sensitive internal operations requiring explicit human approval (REQUIRES_PERMISSION)
    if (
      /delete\s+(?:database|all\s+files|system)|drop\s+table|format\s+drive|execute\s+shell\s+command/i.test(
        p
      )
    ) {
      return {
        operation: 'Sensitive System Operation',
        category: 'SYSTEM_ADMIN',
        status: 'REQUIRES_PERMISSION',
        canExecuteNow: false,
        isSupported: false,
        reason:
          'High-privilege operation requires explicit human-in-the-loop security authorization.',
        remediation: 'Review and confirm via the JARVIS Security Permission modal.',
      };
    }

    // 5. Mathematical & Algorithmic Computation (AVAILABLE OFFLINE)
    if (
      /calculate|compute|sqrt|\b\d+\s*[\+\-\*\/\^]\s*\d+\b|sin\(|cos\(|log\(|matrix/i.test(p)
    ) {
      return {
        operation: 'Local Deterministic Math Engine',
        category: 'MATHEMATICAL_CALCULATION',
        status: 'AVAILABLE',
        canExecuteNow: true,
        isSupported: true,
        reason:
          'Mathematical evaluation and numeric expressions are executed deterministically and offline without requiring external APIs.',
      };
    }

    // 6. Native core capabilities that are active and available (AVAILABLE)
    return {
      operation: 'Core JARVIS Engine',
      category: 'ACTIVE_COMPUTE',
      status: 'AVAILABLE',
      canExecuteNow: true,
      isSupported: true,
      reason:
        'Fully supported via local SQLite database, layered memory system, model router, and client execution pipeline.',
    };
  }
}

export const capabilityDiscovery = new CapabilityDiscoverySystem();

export function classifyPromptCapability(
  prompt: string,
  options?: { hasGeminiApiKey?: boolean }
): CapabilityAssessment {
  return capabilityDiscovery.assessCapability(prompt);
}
