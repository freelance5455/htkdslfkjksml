# X Gaming API 3.0

Backend production-ready baseline for the X Gaming Android client.

## Included
- PostgreSQL persistent catalog for games.
- APK / OBB / DATA links per game.
- Persistent complaints.
- Persistent image library (5 MB per image).
- User registration/login with bcrypt + JWT.
- App update endpoint.
- Admin-protected write/delete operations.
- CORS + Helmet.

## Deploy
1. Create a PostgreSQL database.
2. Set the variables from `.env.example` in your hosting provider.
3. Run `npm install` then `npm start`.
4. Point `SERVER_API` in the Android asset `script.js` to the deployed `/api` URL.
5. Set `APP_APK_URL` to the public APK URL when publishing a new app version.

The Android app must use public HTTPS URLs for APK/OBB/DATA. Do not store local phone paths in the catalog.
