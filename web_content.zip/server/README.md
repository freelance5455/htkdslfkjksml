# Contractor Pro Server

Node 20+ (tested on 22). Auth, RBAC, tamper-evident audit log, offline sync with conflict resolution, license check, AI gateway.

```bash
cd server
npm install                 # installs pg
cp .env.example .env        # set JWT_SECRET, DATABASE_URL, ANTHROPIC_API_KEY
npm run migrate             # applies sql/001_schema.sql to PostgreSQL
npm start
npm test                    # 13 tests, uses the in-memory store (no database needed)
```
Without `DATABASE_URL` (development only) the server uses an in-memory store. In production it refuses to start without `DATABASE_URL` and a 32+ char `JWT_SECRET`.

## API (matches the app's V17.5 clients)
`GET /health` · `POST /api/auth/{register,login,request-otp,verify-otp,refresh,logout}` · `GET /api/auth/me` · `POST /api/account/password`
`GET|POST /api/users`, `PATCH /api/users/:id` · `GET /api/audit` · `POST /api/sync/push` · `GET /api/sync/pull` · `POST /api/sync/changes` · `GET /api/sync/records`
`POST /api/license/validate` · `POST /api/billing/create-checkout` (501 until a provider is configured) · `POST /api/ai/copilot`

Not verified in the build environment: the PostgreSQL store (no database available) and the live Anthropic call (no network/key).
