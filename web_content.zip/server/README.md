# X Gaming API deployment note

The Android client uses:
`https://xgaming-api-1scl-production.up.railway.app/api`

For games to survive server restarts/redeploys, the production API must store games in a persistent database (PostgreSQL is recommended) rather than process memory. The current deployed API may still use in-memory game storage, so deploy the API with persistent storage before relying on it as the permanent catalog.

Required API contract:
- GET `/api/health`
- GET `/api/games`
- POST `/api/games` with `Authorization: Bearer <admin-secret>`
- DELETE `/api/games/:id` with admin authorization
- GET `/api/app-update`
- POST/GET `/api/images` as used by the admin panel

For each game, store its public `imageUrl` (or image id), category, version, and public APK/OBB/DATA URLs. Never point these URLs to a local phone file.
