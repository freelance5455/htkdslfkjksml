ZYNKO WebSocket Server

1. Install Node.js.
2. Open this folder in a terminal.
3. Run:
   npm install
   node server.js

The server listens on port 8080.

For production Android use, put it behind HTTPS/TLS and use a secure
WebSocket URL such as wss://your-domain.example/ws (with a reverse proxy).

This starter server provides real-time text chat only. File transfer,
authentication, message encryption, abuse controls, database storage,
push notifications, and user accounts require additional production work.
