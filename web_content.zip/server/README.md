# SKYNET V2 — socle serveur préparatoire

Ce dossier est un **starter backend** destiné à faciliter une future installation sur serveur. Il ne transforme pas automatiquement le HTML en service cloud et n'est pas certifié pour la production.

## Capacités réellement codées dans ce socle
- API FastAPI avec documentation OpenAPI (`/docs`).
- Base PostgreSQL dans Docker Compose (SQLite seulement pour développement local).
- Initialisation contrôlée du premier administrateur via clé de configuration.
- Authentification par jeton Bearer signé, mots de passe hachés Argon2 et expiration courte.
- Cloisonnement des lectures/écritures par organisation à partir de l'organisation du jeton, jamais d'un identifiant fourni par le client.
- Enregistrement d'événements, empreinte SHA-256 facultative des éléments de preuve fournis et journal d'audit.
- Demandes d'approbation et revue par rôle autorisé ; aucune commande distante n'est exécutée.

## Démarrage sur un serveur Linux avec Docker
1. Installer Docker Engine et le plugin Docker Compose.
2. Copier `.env.example` vers `.env` et générer des secrets aléatoires forts. Ne jamais réutiliser les exemples.
3. Configurer `CORS_ORIGINS` avec le domaine exact du futur site.
4. Depuis ce dossier : `docker compose up --build -d`.
5. Placer un reverse proxy HTTPS (Caddy/Nginx) devant l'API ; ne pas exposer le port 8000 directement à Internet.
6. Initialiser le premier administrateur avec `POST /setup/first-admin`, puis supprimer/faire tourner `SKYNET_SETUP_KEY`.
7. Se connecter avec `POST /auth/token` (formulaire OAuth2 : username=email, password=...).

## Endpoints initiaux
- `GET /health`
- `POST /setup/first-admin` (configuration initiale uniquement)
- `POST /auth/token`
- `POST/GET /events`
- `POST/GET /approvals`
- `POST /approvals/{id}/review`
- `GET /audit`

## Contrat d'événement
`source`, `event_type`, `severity`, `asset`, `summary`, `evidence_text` facultatif. L'API calcule SHA-256 de `evidence_text`, mais ne stocke pas son contenu. L'empreinte seule ne prouve pas l'origine ni l'authenticité de la preuve.

## Six chantiers préparés dans cette livraison
1. **Threat intelligence** : contrat d'événement et champs de source ; aucun flux CTI externe n'est encore connecté.
2. **Tests de détection** : la structure est prête à recevoir des règles ; moteur de règles et banc de tests à implémenter.
3. **Preuves cryptographiques** : empreinte SHA-256 au dépôt ; signature, horodatage de confiance et stockage immuable restent à ajouter.
4. **Validation humaine** : workflow d'approbation persistant et contrôlé par rôle ; pas d'exécution automatique.
5. **Sauvegarde/restauration** : volume PostgreSQL persistant ; politique automatisée, chiffrement, tests de restauration et stockage hors site à mettre en place.
6. **Préparation au déploiement** : Docker, configuration par environnement et API documentée ; TLS, durcissement, supervision et audit externe restent requis.

## Avant toute donnée réelle / production
- Ajouter migrations versionnées (Alembic), limitation de débit, rotation/révocation des jetons, MFA, politique de mot de passe et gestion des sessions.
- Ajouter tests automatisés, tests d'isolation multi-tenant, analyse de dépendances et tests d'intrusion indépendants.
- Ajouter gestion de secrets (vault), sauvegardes chiffrées testées, rétention et reprise après sinistre.
- Configurer TLS, pare-feu, alertes d'exploitation, collecte de métriques et procédure de réponse.
- Connecter le site HTML à cette API via un client dédié et une politique CORS stricte ; cette liaison n'est pas encore activée dans le prototype navigateur.
- Faire valider conformité, base légale et traitement des données par les responsables compétents.

**Important :** ce socle n'est ni une plateforme de détection opérationnelle, ni un SIEM/EDR, ni une IA connectée. Il constitue une base d'intégration serveur auditable, à compléter et tester avec un partenaire technique.


## Mise à jour 0.2.0 — capacités locales renforcées

- Registre d'indicateurs dédié et cloisonné par organisation : `POST /indicators`, `GET /indicators`.
- Catalogue de règles locales : `GET /detection-rules`.
- Test de règles locales sur événements synthétiques : `POST /detection-tests`.
- Score opérationnel explicable : `GET /risk/summary`.

Ces fonctions ne connectent pas encore de flux CTI, SIEM, EDR ou fournisseur IA externe. Le score n'est pas une prédiction certifiée. Voir `CHANGELOG_V0.2.0_FR.md` pour les limites et les commandes de test.


## Mise à jour 0.3.0 — durcissement du socle

- Schéma versionné avec Alembic ; les changements de base ne sont plus effectués implicitement par `create_all` au démarrage.
- Révocation des sessions : `POST /auth/logout` invalide les jetons actuellement émis pour l'utilisateur connecté.
- Limitation élémentaire des tentatives sur `/auth/token` et `/setup/first-admin` (compteur en mémoire du processus). Pour un déploiement multi-instance, ajouter un limiteur partagé (Redis ou passerelle).
- Scripts de sauvegarde et de restauration PostgreSQL dans `scripts/`. La restauration remplace les données et demande une confirmation explicite.
- Le conteneur applique les migrations avant de démarrer l'API.

Cette version reste un socle de prototype. Le limiteur en mémoire ne remplace pas une protection distribuée, la MFA n'est pas encore implémentée, et les scripts doivent être testés sur une copie de la base avant toute utilisation réelle.
