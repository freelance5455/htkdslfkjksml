import {DatabaseSync} from 'node:sqlite';
import {randomBytes,createHash,scryptSync,timingSafeEqual,randomUUID} from 'node:crypto';

const uid=()=>randomUUID();
const sha=s=>createHash('sha256').update(s).digest('hex');
const now=()=>Date.now();
const validUser=s=>typeof s==='string'&&/^[a-zA-Z0-9_.]{3,30}$/.test(s);
const clean=(s,max)=>typeof s==='string'?s.trim().slice(0,max):'';
const fail=(status,error)=>{const err=new Error(error);err.status=status;throw err;};
const assert=(condition,status,error)=>{if(!condition)fail(status,error);};
const hashPassword=(password,salt)=>scryptSync(password,Buffer.from(salt,'base64url'),64,{N:16384,r:8,p:1,maxmem:64*1024*1024}).toString('base64url');
const verifyPassword=(password,record)=>{if(typeof password!=='string'||password.length>128)return false;const got=Buffer.from(hashPassword(password,record.salt),'base64url'),expected=Buffer.from(record.password_hash,'base64url');return got.length===expected.length&&timingSafeEqual(got,expected);};
const publicUser=user=>({id:user.id,username:user.username,name:user.name,bio:user.bio||'',private:!!user.private,created:user.created});
const iso=t=>new Date(t).toISOString();

export function createSocial({database=':memory:',clock=now,registrationEnabled=true}={}){
  const db=new DatabaseSync(database);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=3000;
    CREATE TABLE IF NOT EXISTS social_users(id TEXT PRIMARY KEY,username TEXT NOT NULL UNIQUE COLLATE NOCASE,name TEXT NOT NULL,bio TEXT NOT NULL DEFAULT '',private INTEGER NOT NULL DEFAULT 0,salt TEXT NOT NULL,password_hash TEXT NOT NULL,created INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS social_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,expires INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS social_session_expiry ON social_sessions(expires);
    CREATE TABLE IF NOT EXISTS social_follows(follower TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,followed TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,status TEXT NOT NULL CHECK(status IN ('pending','accepted')),created INTEGER NOT NULL,PRIMARY KEY(follower,followed),CHECK(follower!=followed));
    CREATE INDEX IF NOT EXISTS social_followed ON social_follows(followed,status);
    CREATE TABLE IF NOT EXISTS social_posts(id TEXT PRIMARY KEY,author TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,caption TEXT NOT NULL,created INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS social_post_created ON social_posts(created DESC);
    CREATE TABLE IF NOT EXISTS social_media(post_id TEXT PRIMARY KEY REFERENCES social_posts(id) ON DELETE CASCADE,mime TEXT NOT NULL,bytes BLOB NOT NULL);
    CREATE TABLE IF NOT EXISTS social_tags(tag TEXT NOT NULL,post_id TEXT NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,PRIMARY KEY(tag,post_id));
    CREATE INDEX IF NOT EXISTS social_tag_search ON social_tags(tag);
    CREATE TABLE IF NOT EXISTS social_likes(user_id TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,post_id TEXT NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,PRIMARY KEY(user_id,post_id));
    CREATE TABLE IF NOT EXISTS social_bookmarks(user_id TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,post_id TEXT NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,PRIMARY KEY(user_id,post_id));
    CREATE TABLE IF NOT EXISTS social_comments(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,post_id TEXT NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,body TEXT NOT NULL,created INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS social_comments_post ON social_comments(post_id,created);
    CREATE TABLE IF NOT EXISTS social_blocks(blocker TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,blocked TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,PRIMARY KEY(blocker,blocked));
    CREATE TABLE IF NOT EXISTS social_reports(id TEXT PRIMARY KEY,reporter TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,reported TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,reason TEXT NOT NULL,created INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS social_messages(id TEXT PRIMARY KEY,sender TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,recipient TEXT NOT NULL REFERENCES social_users(id) ON DELETE CASCADE,body TEXT NOT NULL,created INTEGER NOT NULL,read_at INTEGER,CHECK(sender!=recipient));
    CREATE INDEX IF NOT EXISTS social_msg_sent ON social_messages(sender,recipient,created);
    CREATE INDEX IF NOT EXISTS social_msg_received ON social_messages(recipient,sender,created);`);
  const stmt={
    userByName:db.prepare('SELECT * FROM social_users WHERE username=? COLLATE NOCASE'),
    userById:db.prepare('SELECT * FROM social_users WHERE id=?'),
    follow:db.prepare('SELECT status FROM social_follows WHERE follower=? AND followed=?'),
    post:db.prepare('SELECT p.*,u.username,u.name,u.private FROM social_posts p JOIN social_users u ON p.author=u.id WHERE p.id=?'),
    counts:db.prepare("SELECT (SELECT count(*) FROM social_follows WHERE followed=? AND status='accepted') followers,(SELECT count(*) FROM social_follows WHERE follower=? AND status='accepted') following,(SELECT count(*) FROM social_posts WHERE author=?) posts"),
    session:db.prepare('SELECT u.* FROM social_sessions s JOIN social_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>?'),
  };
  const buckets=new Map();
  function limit(key,max=120){const minute=Math.floor(clock()/60000);let e=buckets.get(key);if(!e||e.minute!==minute){e={minute,count:0};buckets.set(key,e);}assert(++e.count<=max,429,'Too many requests. Try again shortly.');if(buckets.size>3000)buckets.clear();}
  function session(request){const value=request.headers.get('x-jazzy-session')||'';if(!/^[A-Za-z0-9_-]{43}$/.test(value))fail(401,'Please sign in.');const user=stmt.session.get(sha(value),clock());assert(user,401,'Session expired. Please sign in again.');return user;}
  function blocked(a,b){return !!db.prepare('SELECT 1 FROM social_blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)').get(a,b,b,a);}
  function accessible(viewer,post){return !blocked(viewer.id,post.author)&&(!post.private||post.author===viewer.id||stmt.follow.get(viewer.id,post.author)?.status==='accepted');}
  function profile(viewer,user){const counts=stmt.counts.get(user.id,user.id,user.id);return {...publicUser(user),...counts,followStatus:viewer.id===user.id?'self':stmt.follow.get(viewer.id,user.id)?.status||'none',blocked:!!db.prepare('SELECT 1 FROM social_blocks WHERE blocker=? AND blocked=?').get(viewer.id,user.id)};}
  function formatPost(viewer,p){if(!accessible(viewer,p))return null;const liked=!!db.prepare('SELECT 1 FROM social_likes WHERE post_id=? AND user_id=?').get(p.id,viewer.id),saved=!!db.prepare('SELECT 1 FROM social_bookmarks WHERE post_id=? AND user_id=?').get(p.id,viewer.id),likes=db.prepare('SELECT count(*) n FROM social_likes WHERE post_id=?').get(p.id).n,comments=db.prepare('SELECT count(*) n FROM social_comments WHERE post_id=?').get(p.id).n,hasMedia=!!db.prepare('SELECT 1 FROM social_media WHERE post_id=?').get(p.id);return {id:p.id,author:{id:p.author,username:p.username,name:p.name},caption:p.caption,created:iso(p.created),likes,comments,liked,saved,hasMedia,mediaUrl:hasMedia?'/v3/media/'+p.id:null};}
  function createdSession(user){const key=randomBytes(32).toString('base64url');db.prepare('INSERT INTO social_sessions VALUES(?,?,?)').run(sha(key),user.id,clock()+30*86400000);return {session:key,user:publicUser(user)};}
  function userFor(viewer,username){const user=stmt.userByName.get(username);assert(user&&!blocked(viewer.id,user.id),404,'Account not found.');return user;}
  function postFor(viewer,id){const p=stmt.post.get(id);assert(p&&accessible(viewer,p),404,'Post not found.');return p;}
  function mutual(a,b){return !blocked(a,b)&&stmt.follow.get(a,b)?.status==='accepted'&&stmt.follow.get(b,a)?.status==='accepted';}
  function listPosts(viewer,rows){return rows.map(p=>formatPost(viewer,p)).filter(Boolean);}
  function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});}
  async function parse(request,max=3_200_000){assert((request.headers.get('content-type')||'').split(';')[0]==='application/json',415,'Use JSON.');const len=Number(request.headers.get('content-length')||0);assert(len<=max,413,'Request too large.');const reader=request.body?.getReader();assert(reader,400,'Missing request body.');let total=0;const chunks=[];while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>max){await reader.cancel();fail(413,'Request too large.');}chunks.push(value);}const text=Buffer.concat(chunks).toString('utf8');try{const obj=JSON.parse(text);assert(obj&&typeof obj==='object'&&!Array.isArray(obj),400,'Invalid JSON.');return obj;}catch(e){if(e.status)throw e;fail(400,'Invalid JSON.');}}
  async function handle(request,remoteAddress='local'){
    const origin=request.headers.get('origin');const allowed=origin==='https://appassets.androidplatform.net'||/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin||'');
    const cors={'access-control-allow-headers':'Content-Type, X-Jazzy-Session','access-control-allow-methods':'GET,POST,PATCH,DELETE,OPTIONS','access-control-max-age':'600','vary':'Origin'};if(allowed)cors['access-control-allow-origin']=origin;
    try{
      assert(!origin||allowed,403,'Origin not allowed.');
      if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
      const url=new URL(request.url),path=url.pathname,method=request.method;
      if(path==='/health'&&method==='GET')return finish(json({ok:true,app:'JAZZY SOCIAL',protocol:3,features:['social-v1','profiles','posts','follows','messages']}));
      limit(remoteAddress);let result;
      if(path==='/v3/auth/register'&&method==='POST'){
        limit(remoteAddress+':register',5);assert(registrationEnabled,403,'Registrations are currently closed.');const b=await parse(request,5000);
        assert(validUser(b.username),400,'Username must be 3–30 letters, digits, dots or underscores.');assert(typeof b.password==='string'&&b.password.length>=10&&b.password.length<=128,400,'Use a password of 10–128 characters.');assert(typeof b.name==='string'&&b.name.trim().length>=1&&b.name.trim().length<=50,400,'Enter a display name (up to 50 characters).');
        assert(!stmt.userByName.get(b.username),409,'Username already taken.');const salt=randomBytes(24).toString('base64url'),id=uid();db.prepare('INSERT INTO social_users (id,username,name,salt,password_hash,created) VALUES(?,?,?,?,?,?)').run(id,b.username.toLowerCase(),b.name.trim(),salt,hashPassword(b.password,salt),clock());result=json(createdSession(stmt.userById.get(id)),201);
      }else if(path==='/v3/auth/login'&&method==='POST'){
        limit(remoteAddress+':login',10);const b=await parse(request,5000),account=stmt.userByName.get(String(b.username||''));assert(account&&verifyPassword(b.password,account),401,'Invalid username or password.');result=json(createdSession(account));
      }else if(path==='/v3/auth/logout'&&method==='POST'){
        const v=request.headers.get('x-jazzy-session')||'';session(request);db.prepare('DELETE FROM social_sessions WHERE token_hash=?').run(sha(v));result=json({ok:true});
      }else if(path==='/v3/me'&&method==='GET'){const viewer=session(request);result=json(profile(viewer,viewer));
      }else if(path==='/v3/me'&&method==='PATCH'){
        const viewer=session(request),b=await parse(request,5000),name=clean(b.name,51),bio=clean(b.bio,201);assert(name.length>=1&&name.length<=50&&bio.length<=200,400,'Display name or bio is too long.');db.prepare('UPDATE social_users SET name=?,bio=?,private=? WHERE id=?').run(name,bio,b.private?1:0,viewer.id);result=json(profile(stmt.userById.get(viewer.id),stmt.userById.get(viewer.id)));
      }else if(path==='/v3/me/password'&&method==='POST'){
        const viewer=session(request),b=await parse(request,5000);assert(verifyPassword(b.currentPassword,viewer),401,'Current password is incorrect.');assert(typeof b.newPassword==='string'&&b.newPassword.length>=10&&b.newPassword.length<=128,400,'New password must be 10–128 characters.');const salt=randomBytes(24).toString('base64url');db.prepare('UPDATE social_users SET salt=?,password_hash=? WHERE id=?').run(salt,hashPassword(b.newPassword,salt),viewer.id);db.prepare('DELETE FROM social_sessions WHERE user_id=? AND token_hash!=?').run(viewer.id,sha(request.headers.get('x-jazzy-session')));result=json({ok:true});
      }else if(path==='/v3/me'&&method==='DELETE'){
        const viewer=session(request),b=await parse(request,2000);assert(verifyPassword(b.password,viewer),401,'Incorrect password.');db.prepare('DELETE FROM social_users WHERE id=?').run(viewer.id);result=json({ok:true});
      }else if(path==='/v3/users'&&method==='GET'){
        const viewer=session(request),q=clean(url.searchParams.get('q'),40);assert(q.length>=1,400,'Enter a search term.');const rows=db.prepare('SELECT * FROM social_users WHERE (username LIKE ? OR name LIKE ?) AND id NOT IN (SELECT blocked FROM social_blocks WHERE blocker=?) AND id NOT IN (SELECT blocker FROM social_blocks WHERE blocked=?) ORDER BY username LIMIT 30').all('%'+q.replace(/[%_]/g,'')+'%','%'+q.replace(/[%_]/g,'')+'%',viewer.id,viewer.id);result=json({users:rows.map(u=>profile(viewer,u))});
      }else if(/^\/v3\/users\/[^/]+$/.test(path)&&method==='GET'){
        const viewer=session(request),name=decodeURIComponent(path.split('/')[3]);result=json({user:profile(viewer,userFor(viewer,name))});
      }else if(/^\/v3\/users\/[^/]+\/follow$/.test(path)&&['POST','DELETE'].includes(method)){
        const viewer=session(request),target=userFor(viewer,decodeURIComponent(path.split('/')[3]));assert(viewer.id!==target.id,400,'Cannot follow your own account.');assert(!blocked(viewer.id,target.id),403,'This account is not available.');
        if(method==='DELETE')db.prepare('DELETE FROM social_follows WHERE follower=? AND followed=?').run(viewer.id,target.id);
        else db.prepare("INSERT INTO social_follows(follower,followed,status,created) VALUES(?,?,?,?) ON CONFLICT(follower,followed) DO UPDATE SET status=excluded.status").run(viewer.id,target.id,target.private?'pending':'accepted',clock());result=json({user:profile(viewer,target)});
      }else if(/^\/v3\/users\/[^/]+\/block$/.test(path)&&['POST','DELETE'].includes(method)){
        const viewer=session(request),target=stmt.userByName.get(decodeURIComponent(path.split('/')[3]));assert(target,404,'Account not found.');assert(viewer.id!==target.id,400,'Cannot block yourself.');
        if(method==='POST'){db.prepare('INSERT OR IGNORE INTO social_blocks VALUES(?,?)').run(viewer.id,target.id);db.prepare('DELETE FROM social_follows WHERE (follower=? AND followed=?) OR (follower=? AND followed=?)').run(viewer.id,target.id,target.id,viewer.id);}else db.prepare('DELETE FROM social_blocks WHERE blocker=? AND blocked=?').run(viewer.id,target.id);result=json({user:profile(viewer,target)});
      }else if(path==='/v3/blocked'&&method==='GET'){const viewer=session(request),rows=db.prepare('SELECT u.* FROM social_blocks b JOIN social_users u ON u.id=b.blocked WHERE b.blocker=? ORDER BY u.username').all(viewer.id);result=json({users:rows.map(publicUser)});
      }else if(/^\/v3\/users\/[^/]+\/report$/.test(path)&&method==='POST'){const viewer=session(request),target=userFor(viewer,decodeURIComponent(path.split('/')[3])),b=await parse(request,2000);assert(viewer.id!==target.id,400,'Invalid report.');const reason=clean(b.reason,501);assert(reason.length>=5&&reason.length<=500,400,'Tell us briefly why you are reporting this account.');db.prepare('INSERT INTO social_reports VALUES(?,?,?,?,?)').run(uid(),viewer.id,target.id,reason,clock());result=json({ok:true},201);
      }else if(/^\/v3\/users\/[^/]+\/posts$/.test(path)&&method==='GET'){const viewer=session(request),target=userFor(viewer,decodeURIComponent(path.split('/')[3]));assert(!blocked(viewer.id,target.id),403,'This account is not available.');const rows=db.prepare('SELECT p.*,u.username,u.name,u.private FROM social_posts p JOIN social_users u ON u.id=p.author WHERE p.author=? ORDER BY p.created DESC LIMIT 100').all(target.id);result=json({posts:listPosts(viewer,rows)});
      }else if(path==='/v3/follow-requests'&&method==='GET'){
        const viewer=session(request),requests=db.prepare("SELECT u.* FROM social_follows f JOIN social_users u ON u.id=f.follower WHERE f.followed=? AND f.status='pending' ORDER BY f.created DESC LIMIT 50").all(viewer.id);result=json({users:requests.map(publicUser)});
      }else if(/^\/v3\/follow-requests\/[^/]+$/.test(path)&&['POST','DELETE'].includes(method)){
        const viewer=session(request),follower=path.split('/')[3];if(method==='POST')db.prepare("UPDATE social_follows SET status='accepted' WHERE follower=? AND followed=? AND status='pending'").run(follower,viewer.id);else db.prepare("DELETE FROM social_follows WHERE follower=? AND followed=? AND status='pending'").run(follower,viewer.id);result=json({ok:true});
      }else if(/^\/v3\/users\/[^/]+\/(followers|following)$/.test(path)&&method==='GET'){
        const viewer=session(request),parts=path.split('/'),target=userFor(viewer,decodeURIComponent(parts[3]));assert(!target.private||target.id===viewer.id||stmt.follow.get(viewer.id,target.id)?.status==='accepted',403,'This account is private.');
        const rows=parts[4]==='followers'?db.prepare("SELECT u.* FROM social_follows f JOIN social_users u ON u.id=f.follower WHERE f.followed=? AND f.status='accepted' ORDER BY f.created DESC LIMIT 100").all(target.id):db.prepare("SELECT u.* FROM social_follows f JOIN social_users u ON u.id=f.followed WHERE f.follower=? AND f.status='accepted' ORDER BY f.created DESC LIMIT 100").all(target.id);result=json({users:rows.map(u=>profile(viewer,u))});
      }else if(path==='/v3/feed'&&method==='GET'){
        const viewer=session(request),kind=url.searchParams.get('type')==='following'?'following':'all',before=Math.max(0,Number(url.searchParams.get('before')||clock()+1));assert(Number.isFinite(before),400,'Invalid pagination.');
        const rows=db.prepare(`SELECT p.*,u.username,u.name,u.private FROM social_posts p JOIN social_users u ON u.id=p.author WHERE p.created<? AND (u.private=0 OR p.author=? OR EXISTS (SELECT 1 FROM social_follows f WHERE f.follower=? AND f.followed=p.author AND f.status='accepted')) ${kind==='following'?"AND (p.author=? OR EXISTS (SELECT 1 FROM social_follows f WHERE f.follower=? AND f.followed=p.author AND f.status='accepted'))":''} ORDER BY p.created DESC LIMIT 25`).all(...(kind==='following'?[before,viewer.id,viewer.id,viewer.id,viewer.id]:[before,viewer.id,viewer.id]));result=json({posts:listPosts(viewer,rows),next:rows.length?rows.at(-1).created:null});
      }else if(path==='/v3/posts'&&method==='POST'){
        limit(session(request).id+':post',30);const viewer=session(request),b=await parse(request),caption=clean(b.caption,2001);assert(caption.length<=2000,400,'Caption too long.');assert(caption||b.image,400,'Add a caption or image.');const id=uid(),created=clock();let media=null;
        if(b.image){assert(typeof b.image==='string'&&/^data:image\/(png|jpeg|webp);base64,/.test(b.image),400,'Use JPEG, PNG or WebP.');const [,type,encoded]=b.image.match(/^data:image\/(png|jpeg|webp);base64,(.+)$/s)||[];assert(encoded&&encoded.length<2_900_000,413,'Image exceeds 2 MB.');const bytes=Buffer.from(encoded,'base64');assert(bytes.length>8&&bytes.length<=2*1024*1024,413,'Image exceeds 2 MB.');assert((type==='png'&&bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex')))||(type==='jpeg'&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)||(type==='webp'&&bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP'),400,'Invalid image content.');media={type:'image/'+type,bytes};}
        db.exec('BEGIN');try{db.prepare('INSERT INTO social_posts VALUES(?,?,?,?)').run(id,viewer.id,caption,created);if(media)db.prepare('INSERT INTO social_media VALUES(?,?,?)').run(id,media.type,media.bytes);const tags=[...new Set([...caption.matchAll(/(^|\s)#([a-z0-9_]{2,30})\b/gi)].map(x=>x[2].toLowerCase()))].slice(0,20);for(const tag of tags)db.prepare('INSERT INTO social_tags VALUES(?,?)').run(tag,id);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
        result=json({post:formatPost(viewer,stmt.post.get(id))},201);
      }else if(/^\/v3\/posts\/[^/]+$/.test(path)&&method==='DELETE'){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]);assert(p.author===viewer.id,403,'You can only delete your own posts.');db.prepare('DELETE FROM social_posts WHERE id=?').run(p.id);result=json({ok:true});
      }else if(/^\/v3\/posts\/[^/]+$/.test(path)&&method==='GET'){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]);result=json({post:formatPost(viewer,p)});
      }else if(/^\/v3\/media\/[^/]+$/.test(path)&&method==='GET'){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]),m=db.prepare('SELECT * FROM social_media WHERE post_id=?').get(p.id);assert(m,404,'Image not found.');result=new Response(m.bytes,{status:200,headers:{'content-type':m.mime,'cache-control':'private, no-store','x-content-type-options':'nosniff'}});
      }else if(/^\/v3\/posts\/[^/]+\/like$/.test(path)&&['POST','DELETE'].includes(method)){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]);if(method==='POST')db.prepare('INSERT OR IGNORE INTO social_likes VALUES(?,?)').run(viewer.id,p.id);else db.prepare('DELETE FROM social_likes WHERE user_id=? AND post_id=?').run(viewer.id,p.id);result=json({post:formatPost(viewer,p)});
      }else if(/^\/v3\/posts\/[^/]+\/save$/.test(path)&&['POST','DELETE'].includes(method)){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]);if(method==='POST')db.prepare('INSERT OR IGNORE INTO social_bookmarks VALUES(?,?)').run(viewer.id,p.id);else db.prepare('DELETE FROM social_bookmarks WHERE user_id=? AND post_id=?').run(viewer.id,p.id);result=json({post:formatPost(viewer,p)});
      }else if(path==='/v3/saved'&&method==='GET'){
        const viewer=session(request),rows=db.prepare('SELECT p.*,u.username,u.name,u.private FROM social_bookmarks b JOIN social_posts p ON p.id=b.post_id JOIN social_users u ON u.id=p.author WHERE b.user_id=? ORDER BY p.created DESC LIMIT 80').all(viewer.id);result=json({posts:listPosts(viewer,rows)});
      }else if(/^\/v3\/posts\/[^/]+\/comments$/.test(path)&&method==='GET'){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]),rows=db.prepare('SELECT c.*,u.username,u.name FROM social_comments c JOIN social_users u ON c.user_id=u.id WHERE c.post_id=? ORDER BY c.created ASC LIMIT 200').all(p.id);result=json({comments:rows.map(c=>({id:c.id,author:{id:c.user_id,username:c.username,name:c.name},body:c.body,created:iso(c.created)}))});
      }else if(/^\/v3\/posts\/[^/]+\/comments$/.test(path)&&method==='POST'){
        const viewer=session(request),p=postFor(viewer,path.split('/')[3]),b=await parse(request,4000),body=clean(b.body,501);assert(body.length>0&&body.length<=500,400,'Comment must contain 1–500 characters.');db.prepare('INSERT INTO social_comments VALUES(?,?,?,?,?)').run(uid(),viewer.id,p.id,body,clock());result=json({ok:true},201);
      }else if(/^\/v3\/comments\/[^/]+$/.test(path)&&method==='DELETE'){
        const viewer=session(request),comment=db.prepare('SELECT * FROM social_comments WHERE id=?').get(path.split('/')[3]);assert(comment&&comment.user_id===viewer.id,403,'Cannot delete this comment.');db.prepare('DELETE FROM social_comments WHERE id=?').run(comment.id);result=json({ok:true});
      }else if(path==='/v3/tags'&&method==='GET'){
        const viewer=session(request),q=clean(url.searchParams.get('q')||'',30).replace(/^#/,'');const rows=db.prepare("SELECT t.tag,count(*) n FROM social_tags t JOIN social_posts p ON p.id=t.post_id JOIN social_users u ON u.id=p.author WHERE t.tag LIKE ? AND (u.private=0 OR u.id=? OR EXISTS(SELECT 1 FROM social_follows f WHERE f.follower=? AND f.followed=u.id AND f.status='accepted')) AND NOT EXISTS(SELECT 1 FROM social_blocks b WHERE (b.blocker=? AND b.blocked=u.id) OR (b.blocker=u.id AND b.blocked=?)) GROUP BY t.tag ORDER BY n DESC,t.tag LIMIT 30").all(q+'%',viewer.id,viewer.id,viewer.id,viewer.id);result=json({tags:rows});
      }else if(/^\/v3\/tags\/[a-zA-Z0-9_]+$/.test(path)&&method==='GET'){
        const viewer=session(request),tag=path.split('/')[3].toLowerCase(),rows=db.prepare('SELECT p.*,u.username,u.name,u.private FROM social_tags t JOIN social_posts p ON p.id=t.post_id JOIN social_users u ON u.id=p.author WHERE t.tag=? ORDER BY p.created DESC LIMIT 80').all(tag);result=json({posts:listPosts(viewer,rows)});
      }else if(path==='/v3/inbox'&&method==='GET'){
        const viewer=session(request);const rows=db.prepare('SELECT m.*,u.username,u.name FROM social_messages m JOIN social_users u ON u.id=CASE WHEN m.sender=? THEN m.recipient ELSE m.sender END WHERE m.sender=? OR m.recipient=? ORDER BY m.created DESC LIMIT 500').all(viewer.id,viewer.id,viewer.id);const known=new Set(),conversations=[];for(const m of rows){const id=m.sender===viewer.id?m.recipient:m.sender;if(blocked(viewer.id,id)||known.has(id))continue;known.add(id);conversations.push({user:{id,username:m.username,name:m.name},lastMessage:{body:m.body,created:iso(m.created),fromMe:m.sender===viewer.id},unread:db.prepare('SELECT count(*) n FROM social_messages WHERE sender=? AND recipient=? AND read_at IS NULL').get(id,viewer.id).n});}result=json({conversations});
      }else if(/^\/v3\/messages\/[^/]+$/.test(path)&&method==='GET'){
        const viewer=session(request),other=userFor(viewer,decodeURIComponent(path.split('/')[3]));assert(viewer.id!==other.id,400,'Cannot message yourself.');assert(mutual(viewer.id,other.id),403,'You must follow each other to exchange messages.');db.prepare('UPDATE social_messages SET read_at=? WHERE sender=? AND recipient=? AND read_at IS NULL').run(clock(),other.id,viewer.id);const rows=db.prepare('SELECT * FROM (SELECT * FROM social_messages WHERE (sender=? AND recipient=?) OR (sender=? AND recipient=?) ORDER BY created DESC LIMIT 100) ORDER BY created').all(viewer.id,other.id,other.id,viewer.id);result=json({user:publicUser(other),messages:rows.map(m=>({id:m.id,sender:m.sender,body:m.body,created:iso(m.created),read:!!m.read_at}))});
      }else if(/^\/v3\/messages\/[^/]+$/.test(path)&&method==='POST'){
        const viewer=session(request),other=userFor(viewer,decodeURIComponent(path.split('/')[3]));assert(mutual(viewer.id,other.id),403,'You must follow each other to exchange messages.');limit(viewer.id+':message',45);const b=await parse(request,5000),body=clean(b.body,2001);assert(body.length>0&&body.length<=2000,400,'Message must contain 1–2000 characters.');db.prepare('INSERT INTO social_messages(id,sender,recipient,body,created) VALUES(?,?,?,?,?)').run(uid(),viewer.id,other.id,body,clock());result=json({ok:true},201);
      }else result=json({error:'Not found.'},404);
      return finish(result);
    }catch(err){const status=err.status||500;return finish(json({error:status===500?'Unexpected server error.':err.message},status));}
    function finish(response){if(allowed){for(const [k,v] of Object.entries(cors))response.headers.set(k,v);}return response;}
  }
  return {handle,close:()=>db.close(),db};
}
