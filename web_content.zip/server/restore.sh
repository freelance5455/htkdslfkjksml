#!/usr/bin/env bash
# بازیابی داده‌های همگام‌سازی از یک بکاپ
# فهرست بکاپ‌ها:   ./restore.sh
# بازیابی:         ./restore.sh daily-2026-10-25.json
set -euo pipefail
cd "$(dirname "$0")"

if [[ $# -eq 0 ]]; then
  echo "بکاپ‌های موجود (جدیدترین پایین):"
  docker compose exec -T tradyar sh -c 'ls -1 /data/backups | sort'
  echo
  echo "برای بازیابی:  ./restore.sh <نام-فایل>"
  exit 0
fi

FILE="$1"
if [[ "$FILE" == */* || "$FILE" == *..* ]]; then echo "❌ نام فایل نامعتبر"; exit 1; fi

docker compose exec -T tradyar sh -c "test -f /data/backups/'$FILE'" || { echo "❌ بکاپ پیدا نشد: $FILE"; exit 1; }
echo "▶ نسخهٔ فعلی در /data/sync.before-restore.json نگه‌داری می‌شود ..."
docker compose exec -T tradyar sh -c "cp /data/sync.json /data/sync.before-restore.json 2>/dev/null || true; cp /data/backups/'$FILE' /data/sync.json"
docker compose restart tradyar
echo "✅ بازیابی انجام شد از: $FILE"
