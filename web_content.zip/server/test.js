import test from 'node:test';
import assert from 'node:assert/strict';
import worker from './worker.js';

const kv = () => { const m = new Map(); return { get: async (k) => m.get(k) ?? null, put: async (k, v) => { m.set(k, v); }, delete: async (k) => { m.delete(k); }, _m: m }; };
const env = { DETOX: kv() };
const call = async (method, path, body) => {
  const r = await worker.fetch(new Request('https://relay.test' + path, { method, body: body ? JSON.stringify(body) : undefined, headers: { 'content-type': 'application/json' } }), env);
  const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch {} return { status: r.status, j, text };
};

test('ping and missing KV', async () => {
  assert.equal((await call('GET', '/api/ping')).j.name, 'detox-relay');
  const r = await worker.fetch(new Request('https://relay.test/api/ping'), {});
  assert.equal(r.status, 500);
});

test('register, invite, guardian presses relapse, owner polls once', async () => {
  const reg = (await call('POST', '/api/register', { habit: 'scroll', owner: 'Sam' })).j;
  assert.ok(reg.id && reg.key);
  const inv = await call('POST', '/api/invite', { id: reg.id, key: reg.key, slot: 0, name: 'Alex' });
  assert.equal(inv.status, 200);
  assert.match(inv.j.url, /^https:\/\/relay\.test\/g\/[\w-]+$/);
  const token = inv.j.token;

  const page = await call('GET', '/g/' + token);
  assert.equal(page.status, 200); assert.ok(page.text.includes('<title>Detox guardian</title>'));

  await call('POST', '/api/state', { id: reg.id, key: reg.key, habit: 'scroll', owner: 'Sam', lastAt: 123456, balls: 42, best: 9 });
  const info = (await call('GET', '/api/g/' + token)).j;
  assert.deepEqual([info.owner, info.habit, info.lastAt, info.balls, info.guardian], ['Sam', 'NoScroll', 123456, 42, 'Alex']);

  const ev = await call('POST', '/api/g/' + token + '/event', { kind: 'p' });
  assert.equal(ev.status, 200);
  assert.equal((await call('POST', '/api/g/' + token + '/event', { kind: 'y' })).status, 429);   // rate limit

  const poll = (await call('GET', `/api/poll?id=${reg.id}&key=${reg.key}&after=0`)).j;
  assert.equal(poll.events.length, 1);
  assert.equal(poll.events[0].kind, 'p'); assert.equal(poll.events[0].by, 'Alex');
  const again = (await call('GET', `/api/poll?id=${reg.id}&key=${reg.key}&after=${poll.events[0].seq}`)).j;
  assert.equal(again.events.length, 0);
  assert.equal(poll.guardians[0].name, 'Alex');
});

test('guardians cannot send blue; bad keys are rejected; revoke kills the link', async () => {
  const reg = (await call('POST', '/api/register', { habit: 'fap' })).j;
  const t = (await call('POST', '/api/invite', { id: reg.id, key: reg.key, slot: 1, name: 'Jo' })).j.token;
  assert.equal((await call('POST', '/api/g/' + t + '/event', { kind: 'b' })).status, 400);
  assert.equal((await call('GET', `/api/poll?id=${reg.id}&key=nope&after=0`)).status, 401);
  assert.equal((await call('POST', '/api/invite', { id: reg.id, key: 'nope', slot: 0, name: 'X' })).status, 401);
  assert.equal((await call('POST', '/api/invite', { id: reg.id, key: reg.key, slot: 2, name: 'X' })).status, 400);
  await call('POST', '/api/revoke', { id: reg.id, key: reg.key, slot: 1 });
  assert.equal((await call('GET', '/api/g/' + t)).status, 404);
});

test('re-inviting a slot replaces the old link, names are sanitised', async () => {
  const reg = (await call('POST', '/api/register', { habit: 'booze' })).j;
  const a = (await call('POST', '/api/invite', { id: reg.id, key: reg.key, slot: 0, name: 'One' })).j.token;
  const b = (await call('POST', '/api/invite', { id: reg.id, key: reg.key, slot: 0, name: '<b>Two</b>' })).j.token;
  assert.equal((await call('GET', '/api/g/' + a)).status, 404);
  const info = (await call('GET', '/api/g/' + b)).j;
  assert.equal(info.guardian, 'bTwo/b');
});
