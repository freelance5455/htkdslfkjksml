import jwt from "jsonwebtoken";import bcrypt from "bcryptjs";import {q} from "./db.js";
export async function login(username,password){const r=await q("SELECT * FROM users WHERE username=$1",[username]);const u=r.rows[0];
if(!u||!u.active||!(await bcrypt.compare(password,u.password_hash)))return null;
return jwt.sign({sub:String(u.id),role:u.role,username:u.username,displayName:u.display_name},process.env.JWT_SECRET,{expiresIn:"8h"});}
export function guard(req,res,next){try{req.user=jwt.verify(req.cookies.mazo_session,process.env.JWT_SECRET);next()}catch{res.status(401).json({error:"Unauthorized"})}}
export const adminOnly=(req,res,next)=>req.user.role==="admin"?next():res.status(403).json({error:"Admin only"});
