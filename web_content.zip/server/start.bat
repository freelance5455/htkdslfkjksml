@echo off
chcp 65001 >nul
python tradyar-run.py %*
pause
