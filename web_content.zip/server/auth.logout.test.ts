import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { CSRF_COOKIE, MFA_COOKIE, SESSION_COOKIE } from "./admin-auth";
import type { TrpcContext } from "./_core/context";

type CookieCall = {
  name: string;
  options: Record<string, unknown>;
};

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; clearedCookies: CookieCall[] } {
  const clearedCookies: CookieCall[] = [];

  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    admin: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };

  return { ctx, clearedCookies };
}

describe("auth.logout", () => {
  it("clears the dashboard session, CSRF and MFA cookies", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.logout();

    expect(result).toEqual({ success: true });
    expect(clearedCookies.map(cookie => cookie.name).sort()).toEqual([CSRF_COOKIE, MFA_COOKIE, SESSION_COOKIE].sort());
    expect(clearedCookies.find(cookie => cookie.name === SESSION_COOKIE)?.options).toMatchObject({
      maxAge: 0,
      secure: true,
      sameSite: "none",
      httpOnly: true,
      path: "/",
    });
    expect(clearedCookies.find(cookie => cookie.name === CSRF_COOKIE)?.options).toMatchObject({ httpOnly: false });
  });
});
