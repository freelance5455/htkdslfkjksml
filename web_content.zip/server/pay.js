'use strict';
/*
 * درگاه‌های پرداخت (زرین‌پال، زیبال، آیدی‌پی؛ قابل افزودن) — تأیید پرداخت فقط سمت سرور انجام می‌شود.
 *  - مرچنت‌کد/کلید هر درگاه فقط روی سرور (secrets/pay.json با دسترسی 0600) ذخیره می‌شود و هرگز به کلاینت برنمی‌گردد.
 *  - مسیرها:
 *      GET  /pay/config            (مدیر) فهرست درگاه‌ها
 *      POST /pay/config            (مدیر) {action:'add'|'update'|'delete', ...}
 *      GET  /pay/public            فهرست درگاه‌های فعال (بدون اسرار)
 *      POST /pay/create            { gateway, amount, kind, itemId, userId, tokens }
 *      GET|POST /pay/callback/:gw  بازگشت از درگاه + تأیید
 *      GET  /pay/status            ?authority=…
 *      POST /pay/claim             تحویل یک‌بارمصرف
 */
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');

const MIN_AMOUNT = 1000;          // تومان
const MAX_AMOUNT = 50_000_000;    // تومان
const PENDING_TTL = 3 * 3600 * 1000;

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}


const TYPES = {
  zarinpal: { label: 'زرین‌پال', unit: 'toman', keyLabel: 'مرچنت‌کد (۳۶ کاراکتر)', keyRe: /^[0-9a-fA-F-]{36}$/ },
  zibal: { label: 'زیبال', unit: 'rial', keyLabel: 'مرچنت زیبال', keyRe: /^[A-Za-z0-9_-]{3,64}$/ },
  idpay: { label: 'آیدی‌پی', unit: 'rial', keyLabel: 'API Key', keyRe: /^[0-9a-fA-F-]{20,64}$/ },
};

async function createPay({ cfg, secretsDir, log, sendJson, readBody, httpErr, safeEqual, isAdminReq, fetchImpl }) {
  const doFetch = fetchImpl || ((...a) => fetch(...a));
  const file = path.join(secretsDir, 'pay.json');
  let raw = {};
  try { raw = JSON.parse(await fsp.readFile(file, 'utf8')); } catch { /* اولین اجرا */ }
  const db = { gateways: Array.isArray(raw.gateways) ? raw.gateways : [], payments: raw.payments || {} };
  if (!raw.gateways && raw.merchant) { // مهاجرت از نسخهٔ قبلی (فقط زرین‌پال)
    db.gateways.push({ id: 'g1', type: 'zarinpal', label: 'زرین‌پال', key: raw.merchant, sandbox: !!raw.sandbox, enabled: !!raw.enabled });
  }
  let saving = Promise.resolve();
  const save = () => {
    saving = saving.then(async () => {
      const tmp = file + '.tmp';
      await fsp.writeFile(tmp, JSON.stringify(db, null, 1), { mode: 0o600 });
      await fsp.rename(tmp, file);
    });
    return saving;
  };
  const syncOk = (req) => !cfg.syncToken || safeEqual(String(req.headers['x-tradyar-token'] || ''), cfg.syncToken);
  const findGw = (id) => db.gateways.find((g) => g.id === id);
  const pubGw = (g) => ({ id: g.id, type: g.type, label: g.label, sandbox: !!g.sandbox, enabled: !!g.enabled, keySet: !!g.key });

  function baseUrl(req) {
    if (cfg.publicUrl) return cfg.publicUrl.replace(/\/+$/, '');
    const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
    if (!host) return '';
    const local = /^(localhost|127\.|10\.|192\.168\.|\d{1,3}(\.\d{1,3}){3}(:|$))/i.test(host);
    const proto = String(req.headers['x-forwarded-proto'] || (local ? 'http' : 'https')).split(',')[0].trim();
    return proto + '://' + host;
  }

  function cleanup() {
    const now = Date.now();
    for (const [k, v] of Object.entries(db.payments)) if (v.status === 'pending' && now - v.createdAt > PENDING_TTL) delete db.payments[k];
    const keys = Object.keys(db.payments);
    if (keys.length > 5000) keys.sort((a, b) => db.payments[a].createdAt - db.payments[b].createdAt).slice(0, keys.length - 5000).forEach((k) => delete db.payments[k]);
  }

  async function call(url, body, headers) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await doFetch(url, { method: 'POST', signal: ctl.signal, headers: Object.assign({ 'Content-Type': 'application/json', Accept: 'application/json' }, headers || {}), body: JSON.stringify(body) });
      let j = null; try { j = await r.json(); } catch { /* غیر JSON */ }
      return { status: r.status, json: j };
    } finally { clearTimeout(t); }
  }

  /* ----- آداپتورها: هر درگاه جدید فقط یک آبجکت با create/verify/parseCallback ----- */
  const ADAPTERS = {
    zarinpal: {
      async create(g, { amount, desc, callback }) {
        const api = g.sandbox ? 'https://sandbox.zarinpal.com' : (cfg.zarinpalApi || 'https://payment.zarinpal.com');
        const r = await call(api + '/pg/v4/payment/request.json', { merchant_id: g.key, amount, currency: 'IRT', description: desc, callback_url: callback });
        const d = r.json && r.json.data;
        if (!d || d.code !== 100 || !d.authority) return { error: r.json && r.json.errors && r.json.errors.code };
        return { ref: String(d.authority), url: api + '/pg/StartPay/' + d.authority };
      },
      async verify(g, rec) {
        const api = g.sandbox ? 'https://sandbox.zarinpal.com' : (cfg.zarinpalApi || 'https://payment.zarinpal.com');
        const r = await call(api + '/pg/v4/payment/verify.json', { merchant_id: g.key, amount: rec.amount, authority: rec.ref });
        const d = r.json && r.json.data;
        return d && (d.code === 100 || d.code === 101) ? { refId: String(d.ref_id || '') } : null;
      },
      parse: (q) => ({ ref: q.Authority || '', ok: q.Status === 'OK' }),
    },
    zibal: {
      async create(g, { amount, desc, callback }) {
        const r = await call('https://gateway.zibal.ir/v1/request', { merchant: g.sandbox ? 'zibal' : g.key, amount: amount * 10, callbackUrl: callback, description: desc });
        if (!r.json || r.json.result !== 100 || !r.json.trackId) return { error: r.json && r.json.result };
        return { ref: String(r.json.trackId), url: 'https://gateway.zibal.ir/start/' + r.json.trackId };
      },
      async verify(g, rec) {
        const r = await call('https://gateway.zibal.ir/v1/verify', { merchant: g.sandbox ? 'zibal' : g.key, trackId: Number(rec.ref) });
        return r.json && (r.json.result === 100 || r.json.result === 201) && r.json.amount === rec.amount * 10 ? { refId: String(r.json.refNumber || rec.ref) } : null;
      },
      parse: (q) => ({ ref: q.trackId || '', ok: String(q.success) === '1' }),
    },
    idpay: {
      async create(g, { amount, desc, callback, orderId }) {
        const r = await call('https://api.idpay.ir/v1.1/payment', { order_id: orderId, amount: amount * 10, callback, desc }, { 'X-API-KEY': g.key, 'X-SANDBOX': g.sandbox ? '1' : '0' });
        if (!r.json || !r.json.id || !r.json.link) return { error: r.json && r.json.error_code };
        return { ref: String(r.json.id), url: String(r.json.link) };
      },
      async verify(g, rec) {
        const r = await call('https://api.idpay.ir/v1.1/payment/verify', { id: rec.ref, order_id: rec.orderId }, { 'X-API-KEY': g.key, 'X-SANDBOX': g.sandbox ? '1' : '0' });
        return r.json && (r.json.status === 100 || r.json.status === 101) ? { refId: String(r.json.track_id || rec.ref) } : null;
      },
      parse: (q) => ({ ref: q.id || '', ok: String(q.status) === '10' }),
    },
  };

  function page(title, msg, ok, extra) {
    const color = ok ? '#0f9d58' : '#c62828';
    return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title>
<style>body{font-family:Tahoma,sans-serif;background:#0f1319;color:#e9edf5;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0;padding:16px}
.c{max-width:420px;width:100%;background:#1a2029;border:1px solid #2a323d;border-radius:18px;padding:28px;text-align:center;line-height:2}
h1{color:${color};font-size:1.3rem;margin:0 0 8px}.r{direction:ltr;background:#0f1319;border-radius:10px;padding:8px;margin:10px 0;font-size:.85rem}</style></head>
<body><div class="c"><h1>${esc(title)}</h1><p>${esc(msg)}</p>${extra || ''}<p style="opacity:.7;font-size:.85rem">این صفحه را ببندید و به برنامهٔ ترید یار برگردید؛ سکه/اشتراک شما به‌صورت خودکار فعال می‌شود.</p></div></body></html>`;
  }
  const sendHtml = (res, status, html) => { res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(html); };

  async function verifyOne(rec) {
    const g = findGw(rec.gw);
    if (!g || !g.key) return false;
    const v = await ADAPTERS[g.type].verify(g, rec);
    if (!v) return false;
    rec.status = 'paid'; rec.refId = v.refId; rec.paidAt = Date.now();
    await save();
    log('info', 'payment verified', { amount: rec.amount, kind: rec.kind, gw: g.type });
    return true;
  }

  async function handle(req, res, url, p) {
    cleanup();
    if (p.startsWith('/pay/callback')) {
      const gw = findGw(p.split('/')[3] || '');
      const q = Object.fromEntries(url.searchParams);
      if (req.method === 'POST') {
        try { new URLSearchParams(await readBody(req, 8192)).forEach((v, k) => { if (q[k] === undefined) q[k] = v; }); } catch { /* بدون بدنه */ }
      }
      if (!gw) return sendHtml(res, 404, page('درگاه پیدا نشد', 'این آدرس بازگشت معتبر نیست.', false));
      const { ref, ok: cbOk } = ADAPTERS[gw.type].parse(q);
      const rec = db.payments[gw.id + ':' + ref];
      if (!rec) return sendHtml(res, 404, page('پرداخت پیدا نشد', 'این پرداخت در سرور ثبت نشده یا منقضی شده است.', false));
      if (rec.status === 'paid') return sendHtml(res, 200, page('پرداخت موفق ✓', 'پرداخت شما قبلاً تأیید شده است.', true, `<div class="r">Ref: ${esc(rec.refId)}</div>`));
      if (!cbOk) { rec.status = 'failed'; rec.reason = 'cancelled'; await save(); return sendHtml(res, 200, page('پرداخت انجام نشد', 'پرداخت لغو شد یا ناموفق بود. مبلغی از حساب شما کسر نشده است.', false)); }
      let ok = false;
      try { ok = await verifyOne(rec); } catch (e) { log('error', 'verify failed', { err: String(e && e.message) }); }
      if (ok) return sendHtml(res, 200, page('پرداخت موفق ✓', 'پرداخت با موفقیت تأیید شد.', true, `<div class="r">Ref: ${esc(rec.refId)}</div>`));
      return sendHtml(res, 200, page('تأیید پرداخت ناموفق', 'تأیید پرداخت انجام نشد. اگر مبلغ کسر شده تا چند دقیقه دیگر خودکار تأیید یا به حساب شما برگردانده می‌شود.', false));
    }

    if (p === '/pay/config') {
      if (!isAdminReq(req)) throw httpErr(401, 'unauthorized');
      if (req.method === 'GET') return sendJson(res, 200, { ok: true, gateways: db.gateways.map(pubGw), types: Object.entries(TYPES).map(([k, v]) => ({ type: k, label: v.label, keyLabel: v.keyLabel })) });
      if (req.method === 'POST') {
        let b; try { b = JSON.parse(await readBody(req, 4096)); } catch { throw httpErr(400, 'bad_json'); }
        const action = String(b.action || '');
        if (action === 'add') {
          const T = TYPES[b.type]; if (!T) throw httpErr(400, 'bad_type');
          const key = String(b.key || '').trim(); if (!T.keyRe.test(key)) throw httpErr(400, 'bad_key');
          if (db.gateways.length >= 10) throw httpErr(400, 'too_many');
          const g = { id: 'g' + crypto.randomBytes(4).toString('hex'), type: b.type, label: String(b.label || T.label).slice(0, 40), key, sandbox: !!b.sandbox, enabled: false };
          db.gateways.push(g);
        } else if (action === 'update') {
          const g = findGw(String(b.id || '')); if (!g) throw httpErr(404, 'not_found');
          if (b.label !== undefined) g.label = String(b.label).slice(0, 40) || g.label;
          if (b.key) { const key = String(b.key).trim(); if (!TYPES[g.type].keyRe.test(key)) throw httpErr(400, 'bad_key'); g.key = key; }
          if (b.sandbox !== undefined) g.sandbox = !!b.sandbox;
          if (b.enabled !== undefined) { if (b.enabled && !g.key) throw httpErr(400, 'key_required'); g.enabled = !!b.enabled; }
        } else if (action === 'delete') {
          const i = db.gateways.findIndex((g) => g.id === String(b.id || '')); if (i < 0) throw httpErr(404, 'not_found');
          db.gateways.splice(i, 1);
        } else throw httpErr(400, 'bad_action');
        await save();
        log('info', 'pay config updated', { action, n: db.gateways.length });
        return sendJson(res, 200, { ok: true, gateways: db.gateways.map(pubGw) });
      }
      throw httpErr(405, 'method_not_allowed');
    }

    if (!syncOk(req) && !isAdminReq(req)) throw httpErr(401, 'unauthorized');

    if (p === '/pay/public' && req.method === 'GET') {
      return sendJson(res, 200, { ok: true, gateways: db.gateways.filter((g) => g.enabled && g.key).map((g) => ({ id: g.id, type: g.type, label: g.label })) });
    }

    if (p === '/pay/create' && req.method === 'POST') {
      let b; try { b = JSON.parse(await readBody(req, 4096)); } catch { throw httpErr(400, 'bad_json'); }
      const g = findGw(String(b.gateway || ''));
      if (!g || !g.enabled || !g.key) throw httpErr(503, 'gateway_disabled');
      const base = baseUrl(req); if (!base) throw httpErr(500, 'no_base_url');
      const amount = Math.floor(Number(b.amount));
      if (!Number.isFinite(amount) || amount < MIN_AMOUNT || amount > MAX_AMOUNT) throw httpErr(400, 'bad_amount');
      const kind = b.kind === 'sub' ? 'sub' : 'coins';
      const userId = String(b.userId || '').slice(0, 64); if (!userId) throw httpErr(400, 'bad_user');
      const desc = String(b.desc || (kind === 'sub' ? 'خرید اشتراک ترید یار' : 'خرید سکه ترید یار')).slice(0, 200);
      const orderId = crypto.randomBytes(8).toString('hex');
      const r = await ADAPTERS[g.type].create(g, { amount, desc, orderId, callback: base + '/pay/callback/' + g.id });
      if (!r || !r.ref) { log('error', 'gateway request failed', { gw: g.type, code: r && r.error }); throw httpErr(502, 'gateway_error'); }
      const key = g.id + ':' + r.ref;
      db.payments[key] = { authority: key, ref: r.ref, gw: g.id, orderId, amount, kind, itemId: String(b.itemId || '').slice(0, 64), userId, desc,
        tokens: Math.max(0, Math.floor(Number(b.tokens) || 0)), qty: 1, status: 'pending', createdAt: Date.now(), claimed: false };
      await save();
      return sendJson(res, 200, { ok: true, authority: key, url: r.url });
    }

    if (p === '/pay/status' && req.method === 'GET') {
      const rec = db.payments[String(url.searchParams.get('authority') || '')];
      if (!rec) return sendJson(res, 200, { ok: true, status: 'unknown' });
      if (rec.status === 'pending' && Date.now() - rec.createdAt > 120000) { try { await verifyOne(rec); } catch { /* هنوز پرداخت نشده */ } }
      return sendJson(res, 200, { ok: true, status: rec.status, kind: rec.kind, itemId: rec.itemId, userId: rec.userId, amount: rec.amount, tokens: rec.tokens, refId: rec.refId || '', claimed: !!rec.claimed });
    }

    if (p === '/pay/claim' && req.method === 'POST') {
      let b; try { b = JSON.parse(await readBody(req, 2048)); } catch { throw httpErr(400, 'bad_json'); }
      const rec = db.payments[String(b.authority || '')];
      if (!rec || rec.status !== 'paid') throw httpErr(404, 'not_paid');
      if (String(b.userId || '') !== rec.userId) throw httpErr(403, 'wrong_user');
      if (rec.claimed) return sendJson(res, 200, { ok: true, already: true });
      rec.claimed = true; rec.claimedAt = Date.now();
      await save();
      return sendJson(res, 200, { ok: true, already: false });
    }
    throw httpErr(404, 'not_found');
  }
  return { handle, isGatewayPath: (p) => p === '/pay' || p.startsWith('/pay/') };
}

module.exports = { createPay, TYPES };
