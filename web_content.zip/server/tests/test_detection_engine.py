from app.detection import evaluate_detection_rule


def test_critical_rule_matches_critical_event():
    result = evaluate_detection_rule("critical_security_event", "any.event", "critical")
    assert result["matched"] is True


def test_authentication_rule_matches_known_event():
    result = evaluate_detection_rule("authentication_anomaly", "auth.failed_login", "high")
    assert result["matched"] is True


def test_authentication_rule_rejects_unknown_event():
    result = evaluate_detection_rule("authentication_anomaly", "file.opened", "critical")
    assert result["matched"] is False


def test_malware_rule_requires_minimum_severity():
    result = evaluate_detection_rule("malware_alert", "malware.detected", "medium")
    assert result["matched"] is False
