import { Router, Request, Response } from 'express';
import { db, MarketplaceItem } from '../db.js';

export const marketplaceRouter = Router();

// 1. Get marketplace items
marketplaceRouter.get('/', (req: Request, res: Response) => {
  try {
    const { category, province, q, maxPrice, sellerId } = req.query;
    let items = [...db.get('marketplace')];

    if (sellerId) {
      items = items.filter(i => i.sellerId === sellerId);
    }

    if (category && category !== 'Todas') {
      items = items.filter(i => i.category.toLowerCase() === (category as string).toLowerCase());
    }

    if (province && province !== 'Todas') {
      items = items.filter(i => i.province.toLowerCase() === (province as string).toLowerCase());
    }

    if (q) {
      const queryLower = (q as string).toLowerCase().trim();
      items = items.filter(
        i => i.title.toLowerCase().includes(queryLower) ||
             i.description.toLowerCase().includes(queryLower)
      );
    }

    if (maxPrice && !isNaN(Number(maxPrice))) {
      items = items.filter(i => i.price <= Number(maxPrice));
    }

    // Sort newest first
    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Enrich with seller details
    const users = db.get('users');
    const enriched = items.map(item => ({
      ...item,
      seller: users.find(u => u.id === item.sellerId)
    }));

    return res.json({ items: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao listar artigos: ' + err.message });
  }
});

// 2. Create listing
marketplaceRouter.post('/', (req: Request, res: Response) => {
  try {
    const { sellerId, title, description, price, currency = 'AOA', category, province, images, condition, contactPhone } = req.body;

    if (!sellerId || !title?.trim() || !price || !category) {
      return res.status(400).json({ error: 'Vendedor, título, preço e categoria são obrigatórios.' });
    }

    const newItem: MarketplaceItem = {
      id: 'mkt_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      sellerId,
      title: title.trim(),
      description: description ? description.trim() : '',
      price: Number(price),
      currency: currency === 'USD' ? 'USD' : 'AOA',
      category: category.trim(),
      province: province || 'Luanda',
      images: images && images.length > 0 ? images : ['/src/assets/images/angola_samakaka_fashion_1793388060870.jpg'],
      condition: condition || 'Bom estado',
      contactPhone: contactPhone || '',
      sold: false,
      createdAt: new Date().toISOString()
    };

    const items = db.get('marketplace');
    items.unshift(newItem);
    db.set('marketplace', items);

    return res.status(201).json({ success: true, item: newItem });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao publicar artigo: ' + err.message });
  }
});

// 3. Mark as Sold / Toggle
marketplaceRouter.post('/:id/toggle-sold', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { sellerId } = req.body;

    const items = db.get('marketplace');
    const item = items.find(i => i.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Artigo não encontrado.' });
    }

    if (item.sellerId !== sellerId) {
      return res.status(403).json({ error: 'Apenas o vendedor pode alterar o estado do anúncio.' });
    }

    item.sold = !item.sold;
    db.persist();

    return res.json({ success: true, sold: item.sold });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao alterar estado: ' + err.message });
  }
});

// 4. Delete listing
marketplaceRouter.delete('/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { sellerId, isAdmin } = req.body;

    const items = db.get('marketplace');
    const idx = items.findIndex(i => i.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Artigo não encontrado.' });
    }

    if (items[idx].sellerId !== sellerId && !isAdmin) {
      return res.status(403).json({ error: 'Não tem permissão para eliminar este anúncio.' });
    }

    items.splice(idx, 1);
    db.set('marketplace', items);

    return res.json({ success: true, message: 'Anúncio removido com sucesso.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao eliminar artigo: ' + err.message });
  }
});
