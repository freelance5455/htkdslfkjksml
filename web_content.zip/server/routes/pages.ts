import { Router, Request, Response } from 'express';
import { db, PageProfile } from '../db.js';

export const pagesRouter = Router();

// 1. Get all pages
pagesRouter.get('/', (req: Request, res: Response) => {
  try {
    const { category, userId } = req.query;
    let pages = [...db.get('pages')];

    if (category && category !== 'Todas') {
      pages = pages.filter(p => p.category.toLowerCase() === (category as string).toLowerCase());
    }

    const enriched = pages.map(p => ({
      ...p,
      isFollowing: userId ? p.followers.includes(userId as string) : false,
      followersCount: p.followers.length
    }));

    return res.json({ pages: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao listar páginas: ' + err.message });
  }
});

// 2. Create Page
pagesRouter.post('/', (req: Request, res: Response) => {
  try {
    const { name, handle, category, description, ownerId, avatar, coverImage, contactEmail, contactPhone, province } = req.body;

    if (!name?.trim() || !handle?.trim() || !ownerId) {
      return res.status(400).json({ error: 'Nome, identificador (@handle) e proprietário são necessários.' });
    }

    const cleanHandle = handle.toLowerCase().replace(/[^a-z0-9_]/g, '');
    const pages = db.get('pages');

    if (pages.some(p => p.handle === cleanHandle)) {
      return res.status(409).json({ error: 'Este identificador de página já está em uso.' });
    }

    const newPage: PageProfile = {
      id: 'page_' + Date.now().toString(36),
      name: name.trim(),
      handle: cleanHandle,
      category: category || 'Empresa',
      description: description ? description.trim() : 'Página oficial no Angola Connect.',
      avatar: avatar || '/src/assets/images/angola_samakaka_fashion_1793388060870.jpg',
      coverImage: coverImage || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
      ownerId,
      followers: [ownerId],
      contactEmail: contactEmail || '',
      contactPhone: contactPhone || '',
      province: province || 'Luanda',
      metrics: {
        viewsThisWeek: 120,
        reach: 450,
        engagementRate: '5.2%'
      },
      createdAt: new Date().toISOString()
    };

    pages.unshift(newPage);
    db.set('pages', pages);

    return res.status(201).json({ success: true, page: newPage });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao criar página: ' + err.message });
  }
});

// 3. Follow / Unfollow page
pagesRouter.post('/:id/follow-toggle', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'ID do utilizador é necessário.' });
    }

    const pages = db.get('pages');
    const page = pages.find(p => p.id === id);
    if (!page) {
      return res.status(404).json({ error: 'Página não encontrada.' });
    }

    const isFollowing = page.followers.includes(userId);
    if (isFollowing) {
      page.followers = page.followers.filter(uid => uid !== userId);
    } else {
      page.followers.push(userId);
    }

    db.persist();
    return res.json({
      success: true,
      isFollowing: !isFollowing,
      followersCount: page.followers.length
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao seguir página: ' + err.message });
  }
});
