import { Router, Request, Response } from 'express';
import { db, Story } from '../db.js';

export const storiesRouter = Router();

// 1. Get Active Stories (grouped by author, 24h filter)
storiesRouter.get('/', (req: Request, res: Response) => {
  try {
    const { userId } = req.query;
    const now = Date.now();
    const twentyFourHoursAgo = now - 24 * 60 * 60 * 1000;

    const allStories = db.get('stories');
    // Keep active
    const active = allStories.filter(s => new Date(s.createdAt).getTime() > twentyFourHoursAgo);

    // Group by author
    const authorsMap = new Map<string, Story[]>();
    for (const story of active) {
      if (!authorsMap.has(story.authorId)) {
        authorsMap.set(story.authorId, []);
      }
      authorsMap.get(story.authorId)!.push(story);
    }

    const grouped = Array.from(authorsMap.entries()).map(([authorId, items]) => {
      const user = db.get('users').find(u => u.id === authorId);
      return {
        authorId,
        user,
        stories: items.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()),
        hasUnseen: userId ? items.some(s => !s.views.some(v => v.userId === userId)) : false
      };
    });

    return res.json({ storiesGrouped: grouped, totalCount: active.length });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao obter stories: ' + err.message });
  }
});

// 2. Create Story
storiesRouter.post('/', (req: Request, res: Response) => {
  try {
    const { authorId, mediaUrl, mediaType = 'image', textContent, backgroundGradient, privacy = 'public' } = req.body;

    if (!authorId || (!mediaUrl && !textContent)) {
      return res.status(400).json({ error: 'Autor e conteúdo (imagem/vídeo ou texto) são necessários.' });
    }

    const newStory: Story = {
      id: 'story_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      authorId,
      mediaUrl,
      mediaType,
      textContent,
      backgroundGradient,
      privacy,
      views: [],
      reactions: [],
      createdAt: new Date().toISOString()
    };

    const stories = db.get('stories');
    stories.push(newStory);
    db.set('stories', stories);

    return res.status(201).json({ success: true, story: newStory });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao criar story: ' + err.message });
  }
});

// 3. Mark Story as Viewed
storiesRouter.post('/:id/view', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'ID do utilizador é necessário.' });
    }

    const stories = db.get('stories');
    const story = stories.find(s => s.id === id);
    if (!story) {
      return res.status(404).json({ error: 'Story não encontrado.' });
    }

    if (!story.views.some(v => v.userId === userId)) {
      story.views.push({ userId, viewedAt: new Date().toISOString() });
      db.persist();
    }

    return res.json({ success: true, viewsCount: story.views.length });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao registar visualização: ' + err.message });
  }
});

// 4. React to Story
storiesRouter.post('/:id/react', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, emoji } = req.body;

    const stories = db.get('stories');
    const story = stories.find(s => s.id === id);
    if (!story) {
      return res.status(404).json({ error: 'Story não encontrado.' });
    }

    story.reactions.push({ userId, emoji: emoji || '❤️' });

    // Send notification to author
    if (story.authorId !== userId) {
      const notifs = db.get('notifications');
      notifs.push({
        id: 'notif_' + Date.now(),
        userId: story.authorId,
        fromUserId: userId,
        type: 'like',
        targetId: story.id,
        text: `reagiu ao seu story com ${emoji || '❤️'}.`,
        read: false,
        createdAt: new Date().toISOString()
      });
      db.set('notifications', notifs);
    }

    db.persist();
    return res.json({ success: true, story });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao reagir ao story: ' + err.message });
  }
});

// 5. Delete Story
storiesRouter.delete('/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    const stories = db.get('stories');
    const idx = stories.findIndex(s => s.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Story não encontrado.' });
    }

    if (stories[idx].authorId !== userId) {
      return res.status(403).json({ error: 'Não tem permissão para eliminar este story.' });
    }

    stories.splice(idx, 1);
    db.set('stories', stories);

    return res.json({ success: true, message: 'Story eliminado com sucesso.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao eliminar story: ' + err.message });
  }
});
