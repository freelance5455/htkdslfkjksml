import { Router, Request, Response } from 'express';
import { db } from '../db.js';

export const trendsRouter = Router();

export const ANGOLA_PROVINCES = [
  'Luanda',
  'Benguela',
  'Huambo',
  'Huíla',
  'Cabinda',
  'Cuanza Sul',
  'Cuanza Norte',
  'Uíge',
  'Malanje',
  'Namibe',
  'Bié',
  'Zaire',
  'Cunene',
  'Cuando Cubango',
  'Lunda Norte',
  'Lunda Sul',
  'Moxico',
  'Bengo'
];

trendsRouter.get('/', (req: Request, res: Response) => {
  try {
    const { province } = req.query;
    const posts = db.get('posts');

    // Aggregate hashtags
    const tagCounts = new Map<string, number>();
    for (const p of posts) {
      if (province && province !== 'Todas' && p.province.toLowerCase() !== (province as string).toLowerCase()) {
        continue;
      }
      for (const t of p.hashtags) {
        const clean = t.toLowerCase();
        tagCounts.set(clean, (tagCounts.get(clean) || 0) + 1);
      }
    }

    // Default top hashtags if small DB
    const seedTrends = [
      { tag: 'AngolaConnect', count: 18420, category: 'Comunidade' },
      { tag: 'Luanda2026', count: 14210, category: 'Cidade' },
      { tag: 'PalancasNegras', count: 9800, category: 'Desporto' },
      { tag: 'Kizomba', count: 8530, category: 'Cultura & Música' },
      { tag: 'StartupsAngola', count: 7200, category: 'Tecnologia' },
      { tag: 'BenguelaViva', count: 5400, category: 'Litoral' },
      { tag: 'SamakakaModa', count: 4890, category: 'Moda' },
      { tag: 'Girabola', count: 4120, category: 'Futebol' }
    ];

    const trendingHashtags = seedTrends.map(t => {
      const liveCount = tagCounts.get(t.tag.toLowerCase());
      return {
        ...t,
        count: liveCount ? t.count + liveCount * 5 : t.count
      };
    });

    // Trending news & topics in Angola
    const trendingTopics = [
      {
        id: 'top_1',
        title: 'Crescimento do ecossistema de inovação e startups em Luanda e Benguela',
        source: 'Jornal de Angola',
        category: 'Economia & Tecnologia',
        readers: '32.4k pessoas conectadas',
        timeAgo: 'Há 2 horas',
        province: 'Luanda'
      },
      {
        id: 'top_2',
        title: 'Festival Nacional de Cultura e Dança reúne artistas de todas as 18 províncias',
        source: 'Cultura Viva AO',
        category: 'Música & Tradição',
        readers: '18.9k pessoas conectadas',
        timeAgo: 'Há 4 horas',
        province: 'Huambo'
      },
      {
        id: 'top_3',
        title: 'Palancas Negras preparam estágio decisivo para qualificação continental',
        source: 'Desporto Nacional',
        category: 'Futebol',
        readers: '45.1k pessoas conectadas',
        timeAgo: 'Há 6 horas',
        province: 'Luanda'
      },
      {
        id: 'top_4',
        title: 'Novas rotas turísticas e preservação da Serra da Leba e Deserto do Namibe',
        source: 'Turismo Angola',
        category: 'Ambiente & Viagens',
        readers: '12.8k pessoas conectadas',
        timeAgo: 'Há 8 horas',
        province: 'Namibe'
      }
    ];

    return res.json({
      trendingHashtags,
      trendingTopics: province && province !== 'Todas'
        ? trendingTopics.filter(t => t.province.toLowerCase() === (province as string).toLowerCase())
        : trendingTopics,
      provinces: ANGOLA_PROVINCES
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao carregar tendências: ' + err.message });
  }
});
