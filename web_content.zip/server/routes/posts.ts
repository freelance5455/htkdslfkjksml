import { Router, Request, Response } from 'express';
import { db, Post, NotificationItem, ContentReport } from '../db.js';

export const postsRouter = Router();

// Helper to extract hashtags
function extractHashtags(text: string): string[] {
  const matches = text.match(/#[\w\u00C0-\u017F]+/g);
  if (!matches) return [];
  return Array.from(new Set(matches.map(h => h.slice(1))));
}

// 1. Get Feed
postsRouter.get('/', (req: Request, res: Response) => {
  try {
    const { hashtag, province, authorId, savedByUserId } = req.query;
    let posts = [...db.get('posts')];

    // Filter by author
    if (authorId) {
      posts = posts.filter(p => p.authorId === authorId);
    }

    // Filter by saved
    if (savedByUserId) {
      posts = posts.filter(p => p.savedBy.includes(savedByUserId as string));
    }

    // Filter by hashtag
    if (hashtag) {
      const tagLower = (hashtag as string).toLowerCase().replace('#', '');
      posts = posts.filter(p => p.hashtags.some(h => h.toLowerCase() === tagLower));
    }

    // Filter by province
    if (province && province !== 'Todas') {
      posts = posts.filter(p => p.province.toLowerCase() === (province as string).toLowerCase());
    }

    // Sort newest first
    posts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return res.json({ posts });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao obter publicações: ' + err.message });
  }
});

// 2. Create Post
postsRouter.post('/', (req: Request, res: Response) => {
  try {
    const { authorId, content, mediaUrl, mediaType, province, pageId } = req.body;
    if (!authorId || (!content && !mediaUrl)) {
      return res.status(400).json({ error: 'Autor e conteúdo ou mídia são necessários.' });
    }

    const users = db.get('users');
    const author = users.find(u => u.id === authorId);
    if (!author) {
      return res.status(404).json({ error: 'Autor não encontrado.' });
    }

    const hashtags = extractHashtags(content || '');

    const newPost: Post = {
      id: 'post_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      authorId,
      content: content ? content.trim() : '',
      mediaUrl: mediaUrl || undefined,
      mediaType: mediaType || (mediaUrl ? 'image' : 'none'),
      likes: [],
      comments: [],
      sharesCount: 0,
      savedBy: [],
      hashtags,
      province: province || author.province || 'Luanda',
      pageId: pageId || undefined,
      createdAt: new Date().toISOString()
    };

    const posts = db.get('posts');
    posts.unshift(newPost);
    db.set('posts', posts);

    return res.status(201).json({ success: true, post: newPost });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao criar publicação: ' + err.message });
  }
});

// 3. React / Like Post
postsRouter.post('/:id/react', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, reaction = 'like' } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'ID do utilizador é necessário.' });
    }

    const posts = db.get('posts');
    const post = posts.find(p => p.id === id);
    if (!post) {
      return res.status(404).json({ error: 'Publicação não encontrada.' });
    }

    const existingIndex = post.likes.findIndex(l => l.userId === userId);
    if (existingIndex !== -1) {
      if (post.likes[existingIndex].reaction === reaction) {
        // Toggle off
        post.likes.splice(existingIndex, 1);
      } else {
        // Update reaction
        post.likes[existingIndex].reaction = reaction;
      }
    } else {
      post.likes.push({ userId, reaction });

      // Notify post author if not self
      if (post.authorId !== userId) {
        const notifs = db.get('notifications');
        notifs.push({
          id: 'notif_' + Date.now(),
          userId: post.authorId,
          fromUserId: userId,
          type: 'like',
          targetId: post.id,
          text: 'reagiu à sua publicação no feed.',
          read: false,
          createdAt: new Date().toISOString()
        });
        db.set('notifications', notifs);
      }
    }

    db.persist();
    return res.json({ success: true, post });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao reagir: ' + err.message });
  }
});

// 4. Comment on Post
postsRouter.post('/:id/comments', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { authorId, text, parentCommentId } = req.body;

    if (!authorId || !text?.trim()) {
      return res.status(400).json({ error: 'Autor e texto do comentário são necessários.' });
    }

    const posts = db.get('posts');
    const post = posts.find(p => p.id === id);
    if (!post) {
      return res.status(404).json({ error: 'Publicação não encontrada.' });
    }

    const newComment = {
      id: 'comm_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      authorId,
      text: text.trim(),
      createdAt: new Date().toISOString(),
      replies: []
    };

    if (parentCommentId) {
      const parent = post.comments.find(c => c.id === parentCommentId);
      if (parent) {
        if (!parent.replies) parent.replies = [];
        parent.replies.push({
          id: newComment.id,
          authorId,
          text: newComment.text,
          createdAt: newComment.createdAt
        });
      } else {
        post.comments.push(newComment);
      }
    } else {
      post.comments.push(newComment);
    }

    // Notify author
    if (post.authorId !== authorId) {
      const notifs = db.get('notifications');
      notifs.push({
        id: 'notif_' + Date.now(),
        userId: post.authorId,
        fromUserId: authorId,
        type: 'comment',
        targetId: post.id,
        text: 'comentou na sua publicação: "' + (text.length > 30 ? text.substring(0, 30) + '...' : text) + '"',
        read: false,
        createdAt: new Date().toISOString()
      });
      db.set('notifications', notifs);
    }

    db.persist();
    return res.status(201).json({ success: true, post, comment: newComment });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao comentar: ' + err.message });
  }
});

// 5. Share Post
postsRouter.post('/:id/share', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    const posts = db.get('posts');
    const post = posts.find(p => p.id === id);
    if (!post) {
      return res.status(404).json({ error: 'Publicação não encontrada.' });
    }

    post.sharesCount += 1;

    if (userId && post.authorId !== userId) {
      const notifs = db.get('notifications');
      notifs.push({
        id: 'notif_' + Date.now(),
        userId: post.authorId,
        fromUserId: userId,
        type: 'like',
        targetId: post.id,
        text: 'partilhou a sua publicação.',
        read: false,
        createdAt: new Date().toISOString()
      });
      db.set('notifications', notifs);
    }

    db.persist();
    return res.json({ success: true, sharesCount: post.sharesCount });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao partilhar: ' + err.message });
  }
});

// 6. Save / Unsave Post
postsRouter.post('/:id/save', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'ID do utilizador é necessário.' });
    }

    const posts = db.get('posts');
    const post = posts.find(p => p.id === id);
    if (!post) {
      return res.status(404).json({ error: 'Publicação não encontrada.' });
    }

    const idx = post.savedBy.indexOf(userId);
    let saved = false;
    if (idx !== -1) {
      post.savedBy.splice(idx, 1);
      saved = false;
    } else {
      post.savedBy.push(userId);
      saved = true;
    }

    db.persist();
    return res.json({ success: true, saved, savedBy: post.savedBy });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao salvar publicação: ' + err.message });
  }
});

// 7. Edit Post
postsRouter.put('/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, content } = req.body;

    const posts = db.get('posts');
    const post = posts.find(p => p.id === id);
    if (!post) {
      return res.status(404).json({ error: 'Publicação não encontrada.' });
    }

    if (post.authorId !== userId) {
      return res.status(403).json({ error: 'Não tem permissão para editar esta publicação.' });
    }

    post.content = content ? content.trim() : '';
    post.hashtags = extractHashtags(post.content);
    post.updatedAt = new Date().toISOString();

    db.persist();
    return res.json({ success: true, post });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao atualizar publicação: ' + err.message });
  }
});

// 8. Delete Post
postsRouter.delete('/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, isAdmin } = req.body;

    const posts = db.get('posts');
    const index = posts.findIndex(p => p.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Publicação não encontrada.' });
    }

    const post = posts[index];
    if (post.authorId !== userId && !isAdmin) {
      return res.status(403).json({ error: 'Não tem permissão para eliminar esta publicação.' });
    }

    posts.splice(index, 1);
    db.set('posts', posts);

    return res.json({ success: true, message: 'Publicação eliminada com sucesso.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao eliminar publicação: ' + err.message });
  }
});

// 9. Report Post
postsRouter.post('/:id/report', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reporterId, reason } = req.body;

    if (!reporterId || !reason) {
      return res.status(400).json({ error: 'Motivo e identificação são necessários.' });
    }

    const reports = db.get('reports');
    const newReport: ContentReport = {
      id: 'rep_' + Date.now().toString(36),
      reporterId,
      targetType: 'post',
      targetId: id,
      reason: reason.trim(),
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    reports.push(newReport);
    db.set('reports', reports);

    return res.status(201).json({
      success: true,
      message: 'Denúncia registada. A nossa equipa de moderação irá analisar o conteúdo.'
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao denunciar publicação: ' + err.message });
  }
});
