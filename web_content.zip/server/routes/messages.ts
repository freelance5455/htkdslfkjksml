import { Router, Request, Response } from 'express';
import { db, Message, Conversation } from '../db.js';

export const messagesRouter = Router();

// 1. Get user's conversations
messagesRouter.get('/conversations/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const conversations = db.get('conversations').filter(c => c.participantIds.includes(userId));

    // Enrich with other participants and unread counts
    const users = db.get('users');
    const allMessages = db.get('messages');

    const enriched = conversations.map(c => {
      const otherUserIds = c.participantIds.filter(id => id !== userId);
      const otherUsers = users.filter(u => otherUserIds.includes(u.id));

      // Calculate unread count
      const unreadCount = allMessages.filter(
        m => m.conversationId === c.id &&
             m.senderId !== userId &&
             !m.readBy.includes(userId) &&
             !m.deletedFor.includes(userId)
      ).length;

      return {
        ...c,
        otherUsers,
        unreadCount
      };
    });

    enriched.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

    return res.json({ conversations: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao obter conversas: ' + err.message });
  }
});

// 2. Get or create direct conversation
messagesRouter.post('/conversations/direct', (req: Request, res: Response) => {
  try {
    const { user1Id, user2Id } = req.body;
    if (!user1Id || !user2Id) {
      return res.status(400).json({ error: 'Os dois IDs dos participantes são necessários.' });
    }

    const conversations = db.get('conversations');
    let conv = conversations.find(
      c => c.type === 'direct' &&
           c.participantIds.includes(user1Id) &&
           c.participantIds.includes(user2Id)
    );

    if (!conv) {
      conv = {
        id: 'conv_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
        type: 'direct',
        participantIds: [user1Id, user2Id],
        updatedAt: new Date().toISOString()
      };
      conversations.push(conv);
      db.set('conversations', conversations);
    }

    return res.json({ conversation: conv });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao iniciar conversa: ' + err.message });
  }
});

// 3. Create group conversation
messagesRouter.post('/conversations/group', (req: Request, res: Response) => {
  try {
    const { name, avatar, participantIds, creatorId } = req.body;
    if (!name || !participantIds || participantIds.length < 2 || !creatorId) {
      return res.status(400).json({ error: 'Nome do grupo, criador e pelo menos 2 participantes são necessários.' });
    }

    const fullParticipants = Array.from(new Set([creatorId, ...participantIds]));

    const conv: Conversation = {
      id: 'conv_grp_' + Date.now().toString(36),
      type: 'group',
      name: name.trim(),
      avatar: avatar || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
      participantIds: fullParticipants,
      adminIds: [creatorId],
      updatedAt: new Date().toISOString()
    };

    const conversations = db.get('conversations');
    conversations.push(conv);
    db.set('conversations', conversations);

    return res.status(201).json({ success: true, conversation: conv });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao criar conversa de grupo: ' + err.message });
  }
});

// 4. Get messages in conversation
messagesRouter.get('/:conversationId', (req: Request, res: Response) => {
  try {
    const { conversationId } = req.params;
    const { userId } = req.query;

    const allMessages = db.get('messages');
    const now = Date.now();

    // Filter messages for this conversation, not deleted for this user, and not expired
    const messages = allMessages.filter(m => {
      if (m.conversationId !== conversationId) return false;
      if (userId && m.deletedFor.includes(userId as string)) return false;
      if (m.expiresAt && now > m.expiresAt) return false;
      return true;
    });

    messages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    return res.json({ messages });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao carregar mensagens: ' + err.message });
  }
});

// 5. Send message
messagesRouter.post('/', (req: Request, res: Response) => {
  try {
    const {
      conversationId,
      senderId,
      text,
      type = 'text',
      mediaUrl,
      fileName,
      fileSize,
      audioDurationSeconds,
      location,
      contact,
      replyTo
    } = req.body;

    if (!conversationId || !senderId || (!text?.trim() && !mediaUrl && !location && !contact)) {
      return res.status(400).json({ error: 'Conversa, remetente e conteúdo são necessários.' });
    }

    const conversations = db.get('conversations');
    const conv = conversations.find(c => c.id === conversationId);
    if (!conv) {
      return res.status(404).json({ error: 'Conversa não encontrada.' });
    }

    // Ephemeral expiration check
    let expiresAt: number | undefined;
    if (conv.ephemeralTimerMinutes && conv.ephemeralTimerMinutes > 0) {
      expiresAt = Date.now() + conv.ephemeralTimerMinutes * 60 * 1000;
    }

    const newMsg: Message = {
      id: 'msg_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      conversationId,
      senderId,
      text: text ? text.trim() : '',
      type,
      mediaUrl,
      fileName,
      fileSize,
      audioDurationSeconds,
      location,
      contact,
      replyTo,
      reactions: [],
      status: 'sent',
      deliveredTo: [senderId],
      readBy: [senderId],
      deletedFor: [],
      isDeletedForEveryone: false,
      expiresAt,
      createdAt: new Date().toISOString()
    };

    const messages = db.get('messages');
    messages.push(newMsg);
    db.set('messages', messages);

    // Update conversation preview
    conv.updatedAt = newMsg.createdAt;
    conv.lastMessage = type === 'text' ? (text.length > 50 ? text.substring(0, 50) + '...' : text) : `[${type}]`;
    conv.lastMessageTime = newMsg.createdAt;
    db.persist();

    return res.status(201).json({ success: true, message: newMsg });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao enviar mensagem: ' + err.message });
  }
});

// 6. Mark messages as read
messagesRouter.post('/read', (req: Request, res: Response) => {
  try {
    const { conversationId, userId } = req.body;
    if (!conversationId || !userId) {
      return res.status(400).json({ error: 'ID da conversa e do utilizador necessários.' });
    }

    const messages = db.get('messages');
    let updatedCount = 0;

    for (const msg of messages) {
      if (msg.conversationId === conversationId && msg.senderId !== userId) {
        if (!msg.readBy.includes(userId)) {
          msg.readBy.push(userId);
          msg.status = 'read';
          updatedCount++;
        }
      }
    }

    if (updatedCount > 0) {
      db.persist();
    }

    return res.json({ success: true, updatedCount });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao marcar como lido: ' + err.message });
  }
});

// 7. React to message
messagesRouter.post('/:id/react', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, emoji } = req.body;

    const messages = db.get('messages');
    const msg = messages.find(m => m.id === id);
    if (!msg) {
      return res.status(404).json({ error: 'Mensagem não encontrada.' });
    }

    const existingIndex = msg.reactions.findIndex(r => r.userId === userId);
    if (existingIndex !== -1) {
      if (msg.reactions[existingIndex].emoji === emoji) {
        msg.reactions.splice(existingIndex, 1);
      } else {
        msg.reactions[existingIndex].emoji = emoji;
      }
    } else {
      msg.reactions.push({ userId, emoji });
    }

    db.persist();
    return res.json({ success: true, message: msg });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao reagir à mensagem: ' + err.message });
  }
});

// 8. Delete message
messagesRouter.post('/:id/delete', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, forEveryone } = req.body;

    const messages = db.get('messages');
    const msg = messages.find(m => m.id === id);
    if (!msg) {
      return res.status(404).json({ error: 'Mensagem não encontrada.' });
    }

    if (forEveryone) {
      if (msg.senderId !== userId) {
        return res.status(403).json({ error: 'Apenas quem enviou pode apagar para todos.' });
      }
      msg.isDeletedForEveryone = true;
      msg.text = 'Esta mensagem foi eliminada.';
      msg.mediaUrl = undefined;
    } else {
      if (!msg.deletedFor.includes(userId)) {
        msg.deletedFor.push(userId);
      }
    }

    db.persist();
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao eliminar mensagem: ' + err.message });
  }
});

// 9. Pin message
messagesRouter.post('/:id/pin', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const messages = db.get('messages');
    const msg = messages.find(m => m.id === id);
    if (!msg) {
      return res.status(404).json({ error: 'Mensagem não encontrada.' });
    }

    msg.isPinned = !msg.isPinned;
    db.persist();

    return res.json({ success: true, isPinned: msg.isPinned });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao fixar mensagem: ' + err.message });
  }
});
