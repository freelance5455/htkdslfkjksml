import { Router, Request, Response } from 'express';
import { db } from '../db.js';

export const adminRouter = Router();

// Middleware helper to check admin status
function checkAdmin(req: Request, res: Response, next: () => void) {
  const adminId = (req.headers['x-admin-id'] as string) || req.query.adminId as string || req.body.adminId;
  if (!adminId) {
    return res.status(401).json({ error: 'Autenticação de administrador necessária.' });
  }

  const users = db.get('users');
  const user = users.find(u => u.id === adminId);
  if (!user || !user.isAdmin) {
    return res.status(403).json({ error: 'Acesso restrito a administradores autorizados.' });
  }

  next();
}

// 1. Dashboard stats
adminRouter.get('/stats', checkAdmin, (req: Request, res: Response) => {
  try {
    const users = db.get('users');
    const posts = db.get('posts');
    const messages = db.get('messages');
    const marketplace = db.get('marketplace');
    const stories = db.get('stories');
    const groups = db.get('groups');
    const pages = db.get('pages');
    const reports = db.get('reports');

    const pendingReports = reports.filter(r => r.status === 'pending');

    return res.json({
      stats: {
        totalUsers: users.length,
        verifiedUsers: users.filter(u => u.verified).length,
        suspendedUsers: users.filter(u => u.isSuspended).length,
        totalPosts: posts.length,
        totalMessages: messages.length,
        totalMarketplace: marketplace.length,
        activeStories: stories.length,
        totalGroups: groups.length,
        totalPages: pages.length,
        pendingReportsCount: pendingReports.length
      }
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao carregar estatísticas do admin: ' + err.message });
  }
});

// 2. Get Users for moderation
adminRouter.get('/users', checkAdmin, (req: Request, res: Response) => {
  try {
    const users = db.get('users');
    return res.json({ users });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao listar utilizadores: ' + err.message });
  }
});

// 3. User actions: toggle verify, toggle suspend
adminRouter.post('/users/:id/action', checkAdmin, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { action } = req.body; // 'toggle_verified' | 'toggle_suspend' | 'make_admin'

    const users = db.get('users');
    const user = users.find(u => u.id === id);
    if (!user) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    if (action === 'toggle_verified') {
      user.verified = !user.verified;
    } else if (action === 'toggle_suspend') {
      user.isSuspended = !user.isSuspended;
    } else if (action === 'make_admin') {
      user.isAdmin = !user.isAdmin;
    }

    db.persist();
    return res.json({ success: true, user });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao executar ação no utilizador: ' + err.message });
  }
});

// 4. Reports moderation
adminRouter.get('/reports', checkAdmin, (req: Request, res: Response) => {
  try {
    const reports = db.get('reports');
    const users = db.get('users');

    const enriched = reports.map(r => ({
      ...r,
      reporter: users.find(u => u.id === r.reporterId)
    }));

    return res.json({ reports: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao listar denúncias: ' + err.message });
  }
});

adminRouter.post('/reports/:id/resolve', checkAdmin, (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { action } = req.body; // 'dismiss' | 'remove_content' | 'resolve'

    const reports = db.get('reports');
    const report = reports.find(r => r.id === id);
    if (!report) {
      return res.status(404).json({ error: 'Denúncia não encontrada.' });
    }

    if (action === 'remove_content') {
      if (report.targetType === 'post') {
        const posts = db.get('posts').filter(p => p.id !== report.targetId);
        db.set('posts', posts);
      } else if (report.targetType === 'marketplace') {
        const mkt = db.get('marketplace').filter(m => m.id !== report.targetId);
        db.set('marketplace', mkt);
      }
      report.status = 'resolved';
    } else if (action === 'dismiss') {
      report.status = 'dismissed';
    } else {
      report.status = 'resolved';
    }

    db.persist();
    return res.json({ success: true, report });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao resolver denúncia: ' + err.message });
  }
});
