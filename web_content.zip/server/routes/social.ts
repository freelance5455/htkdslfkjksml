import { Router, Request, Response } from 'express';
import { db, FriendRequest, NotificationItem } from '../db.js';

export const socialRouter = Router();

// 1. Search Users
socialRouter.get('/users', (req: Request, res: Response) => {
  try {
    const { q, province, currentUserId } = req.query;
    let users = [...db.get('users')];

    if (currentUserId) {
      const currentUser = users.find(u => u.id === currentUserId);
      if (currentUser) {
        users = users.filter(u => !currentUser.blockedUsers.includes(u.id));
      }
    }

    if (q) {
      const queryLower = (q as string).toLowerCase().trim();
      users = users.filter(
        u => u.name.toLowerCase().includes(queryLower) ||
             u.username.toLowerCase().includes(queryLower) ||
             u.bio.toLowerCase().includes(queryLower)
      );
    }

    if (province && province !== 'Todas') {
      users = users.filter(u => u.province.toLowerCase() === (province as string).toLowerCase());
    }

    // Strip internal fields for privacy
    const sanitized = users.map(u => ({
      id: u.id,
      name: u.name,
      username: u.username,
      avatar: u.avatar,
      coverImage: u.coverImage,
      bio: u.bio,
      province: u.province,
      verified: u.verified,
      isPrivate: u.isPrivate,
      friendsCount: u.friends.length,
      followersCount: u.followers.length,
      followingCount: u.following.length,
      createdAt: u.createdAt,
      lastSeenAt: u.lastSeenAt
    }));

    return res.json({ users: sanitized });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao pesquisar utilizadores: ' + err.message });
  }
});

// 2. Get User Profile by Username or ID
socialRouter.get('/users/:identifier', (req: Request, res: Response) => {
  try {
    const { identifier } = req.params;
    const users = db.get('users');
    const user = users.find(u => u.id === identifier || u.username.toLowerCase() === identifier.toLowerCase());

    if (!user) {
      return res.status(404).json({ error: 'Perfil não encontrado.' });
    }

    const posts = db.get('posts').filter(p => p.authorId === user.id);
    const photos = posts.filter(p => p.mediaUrl && p.mediaType === 'image');
    const videos = posts.filter(p => p.mediaUrl && p.mediaType === 'video');

    return res.json({
      user: {
        id: user.id,
        name: user.name,
        username: user.username,
        email: user.email,
        phone: user.phone,
        phoneCountryCode: user.phoneCountryCode,
        avatar: user.avatar,
        coverImage: user.coverImage,
        bio: user.bio,
        province: user.province,
        verified: user.verified,
        isPrivate: user.isPrivate,
        isAdmin: user.isAdmin,
        friendsCount: user.friends.length,
        followersCount: user.followers.length,
        followingCount: user.following.length,
        friends: user.friends,
        followers: user.followers,
        following: user.following,
        createdAt: user.createdAt,
        lastSeenAt: user.lastSeenAt
      },
      stats: {
        postsCount: posts.length,
        photosCount: photos.length,
        videosCount: videos.length
      }
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao obter perfil: ' + err.message });
  }
});

// 3. Friend Request: Send
socialRouter.post('/friends/request', (req: Request, res: Response) => {
  try {
    const { fromUserId, toUserId } = req.body;
    if (!fromUserId || !toUserId || fromUserId === toUserId) {
      return res.status(400).json({ error: 'IDs de remetente e destinatário inválidos.' });
    }

    const users = db.get('users');
    const fromUser = users.find(u => u.id === fromUserId);
    const toUser = users.find(u => u.id === toUserId);

    if (!fromUser || !toUser) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    if (fromUser.friends.includes(toUserId)) {
      return res.status(400).json({ error: 'Já são amigos no Angola Connect.' });
    }

    const requests = db.get('friendRequests');
    const existing = requests.find(r => r.fromUserId === fromUserId && r.toUserId === toUserId && r.status === 'pending');
    if (existing) {
      return res.status(400).json({ error: 'Pedido de amizade já enviado e pendente.' });
    }

    const newReq: FriendRequest = {
      id: 'freq_' + Date.now().toString(36),
      fromUserId,
      toUserId,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    requests.push(newReq);
    db.set('friendRequests', requests);

    // Notification
    const notifs = db.get('notifications');
    notifs.push({
      id: 'notif_' + Date.now(),
      userId: toUserId,
      fromUserId,
      type: 'friend_request',
      text: 'enviou-lhe um pedido de amizade.',
      read: false,
      createdAt: new Date().toISOString()
    });
    db.set('notifications', notifs);

    return res.status(201).json({ success: true, request: newReq });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao enviar pedido de amizade: ' + err.message });
  }
});

// 4. Friend Request: Respond (accept / reject)
socialRouter.post('/friends/respond', (req: Request, res: Response) => {
  try {
    const { requestId, action } = req.body; // action: 'accept' | 'reject'
    const requests = db.get('friendRequests');
    const reqItem = requests.find(r => r.id === requestId);

    if (!reqItem || reqItem.status !== 'pending') {
      return res.status(404).json({ error: 'Pedido pendente não encontrado.' });
    }

    reqItem.status = action === 'accept' ? 'accepted' : 'rejected';

    if (action === 'accept') {
      const users = db.get('users');
      const u1 = users.find(u => u.id === reqItem.fromUserId);
      const u2 = users.find(u => u.id === reqItem.toUserId);

      if (u1 && u2) {
        if (!u1.friends.includes(u2.id)) u1.friends.push(u2.id);
        if (!u2.friends.includes(u1.id)) u2.friends.push(u1.id);
        if (!u1.followers.includes(u2.id)) u1.followers.push(u2.id);
        if (!u2.followers.includes(u1.id)) u2.followers.push(u1.id);
      }

      // Notification to requester
      const notifs = db.get('notifications');
      notifs.push({
        id: 'notif_' + Date.now(),
        userId: reqItem.fromUserId,
        fromUserId: reqItem.toUserId,
        type: 'friend_accepted',
        text: 'aceitou o seu pedido de amizade. Agora estão conectados!',
        read: false,
        createdAt: new Date().toISOString()
      });
      db.set('notifications', notifs);
    }

    db.persist();
    return res.json({ success: true, status: reqItem.status });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao responder pedido: ' + err.message });
  }
});

// 5. Remove Friend
socialRouter.post('/friends/remove', (req: Request, res: Response) => {
  try {
    const { userId, friendId } = req.body;
    const users = db.get('users');
    const u1 = users.find(u => u.id === userId);
    const u2 = users.find(u => u.id === friendId);

    if (u1) u1.friends = u1.friends.filter(id => id !== friendId);
    if (u2) u2.friends = u2.friends.filter(id => id !== userId);

    db.persist();
    return res.json({ success: true, message: 'Amizade desfeita.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao desfazer amizade: ' + err.message });
  }
});

// 6. Follow / Unfollow
socialRouter.post('/follow', (req: Request, res: Response) => {
  try {
    const { followerId, targetUserId } = req.body;
    if (followerId === targetUserId) {
      return res.status(400).json({ error: 'Não é possível seguir o próprio perfil.' });
    }

    const users = db.get('users');
    const follower = users.find(u => u.id === followerId);
    const target = users.find(u => u.id === targetUserId);

    if (!follower || !target) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    let isFollowing = false;
    const fIdx = follower.following.indexOf(targetUserId);

    if (fIdx !== -1) {
      follower.following.splice(fIdx, 1);
      target.followers = target.followers.filter(id => id !== followerId);
      isFollowing = false;
    } else {
      follower.following.push(targetUserId);
      if (!target.followers.includes(followerId)) {
        target.followers.push(followerId);
      }
      isFollowing = true;

      const notifs = db.get('notifications');
      notifs.push({
        id: 'notif_' + Date.now(),
        userId: targetUserId,
        fromUserId: followerId,
        type: 'follow',
        text: 'começou a seguir o seu perfil.',
        read: false,
        createdAt: new Date().toISOString()
      });
      db.set('notifications', notifs);
    }

    db.persist();
    return res.json({ success: true, isFollowing, followersCount: target.followers.length });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao seguir/deixar de seguir: ' + err.message });
  }
});

// 7. Block / Unblock
socialRouter.post('/block', (req: Request, res: Response) => {
  try {
    const { blockerId, blockedId } = req.body;
    const users = db.get('users');
    const blocker = users.find(u => u.id === blockerId);

    if (!blocker) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    let isBlocked = false;
    const idx = blocker.blockedUsers.indexOf(blockedId);

    if (idx !== -1) {
      blocker.blockedUsers.splice(idx, 1);
      isBlocked = false;
    } else {
      blocker.blockedUsers.push(blockedId);
      // Remove friendship if any
      blocker.friends = blocker.friends.filter(id => id !== blockedId);
      blocker.following = blocker.following.filter(id => id !== blockedId);
      blocker.followers = blocker.followers.filter(id => id !== blockedId);
      isBlocked = true;
    }

    db.persist();
    return res.json({ success: true, isBlocked });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao bloquear utilizador: ' + err.message });
  }
});

// 8. Notifications
socialRouter.get('/notifications/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const notifs = db.get('notifications').filter(n => n.userId === userId);
    notifs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Enrich with fromUser
    const users = db.get('users');
    const enriched = notifs.map(n => ({
      ...n,
      fromUser: users.find(u => u.id === n.fromUserId)
    }));

    return res.json({ notifications: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao obter notificações: ' + err.message });
  }
});

socialRouter.post('/notifications/read', (req: Request, res: Response) => {
  try {
    const { userId, notificationId } = req.body;
    const notifs = db.get('notifications');

    for (const n of notifs) {
      if (n.userId === userId) {
        if (!notificationId || n.id === notificationId) {
          n.read = true;
        }
      }
    }

    db.persist();
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao atualizar notificações: ' + err.message });
  }
});
