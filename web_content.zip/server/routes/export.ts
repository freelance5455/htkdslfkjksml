import { Router, Request, Response } from 'express';
import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';

export const exportRouter = Router();

// Recursively add directory files to JSZip
function addDirToZip(zip: JSZip, rootDir: string, currentDir: string) {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(currentDir, entry.name);
    const relPath = path.relative(rootDir, fullPath);

    // Skip node_modules, dist, .git, and huge caches
    if (
      entry.name === 'node_modules' ||
      entry.name === 'dist' ||
      entry.name === '.git' ||
      entry.name === '.vite'
    ) {
      continue;
    }

    if (entry.isDirectory()) {
      addDirToZip(zip, rootDir, fullPath);
    } else {
      try {
        const content = fs.readFileSync(fullPath);
        zip.file(relPath, content);
      } catch (err) {
        console.warn(`Could not read file for zip: ${fullPath}`, err);
      }
    }
  }
}

exportRouter.get('/download-zip', async (req: Request, res: Response) => {
  try {
    const zip = new JSZip();
    const projectRoot = process.cwd();

    // 1. Add current codebase files
    addDirToZip(zip, projectRoot, projectRoot);

    // 2. Ensure Android project structure is in the ZIP
    // Capacitor config
    const capacitorConfig = {
      appId: "ao.connect.angolaconnect",
      appName: "Angola Connect",
      webDir: "dist",
      bundledWebRuntime: false,
      plugins: {
        SplashScreen: {
          launchShowDuration: 2000,
          backgroundColor: "#090d16",
          androidSplashResourceName: "splash"
        }
      },
      server: {
        androidScheme: "https"
      }
    };
    zip.file("capacitor.config.json", JSON.stringify(capacitorConfig, null, 2));

    // Android build readme instructions
    const readmeAndroid = `# Guia de Compilação APK — Angola Connect 🇦🇴

Este projeto foi configurado com a estrutura completa para Android (compatível com Android Studio e Apache Cordova / Capacitor).

## Requisitos
- Node.js 18+ e npm
- Android Studio (versão Hedgehog ou superior) ou Android SDK com JDK 17+

## Passos para gerar o APK:
1. Extraia o ficheiro ZIP.
2. No terminal, instale as dependências:
   \`\`\`bash
   npm install
   \`\`\`
3. Compile o build de produção web:
   \`\`\`bash
   npm run build
   \`\`\`
4. Sincronize com o Capacitor:
   \`\`\`bash
   npx cap sync android
   \`\`\`
5. Abra no Android Studio:
   \`\`\`bash
   npx cap open android
   \`\`\`
6. No Android Studio, clique em:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   O ficheiro \`app-debug.apk\` ou \`app-release.apk\` será gerado em \`android/app/build/outputs/apk/\`.

## Informações do Pacote
- **Nome da Aplicação**: Angola Connect
- **Package Name**: ao.connect.angolaconnect
- **Slogan**: Conectando Angola ao mundo
- **Permissões**: Câmera, Microfone, Internet, Armazenamento, Notificações, WebRTC.
`;
    zip.file("README_ANDROID_BUILD.md", readmeAndroid);

    // Generate zip buffer
    const content = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="Angola_Connect_Full_Source_Android_Ready.zip"');
    res.setHeader('Content-Length', content.length);
    return res.end(content);
  } catch (err: any) {
    console.error('Failed to generate export zip:', err);
    return res.status(500).json({ error: 'Erro ao gerar ficheiro ZIP do projecto: ' + err.message });
  }
});
