import { Router, Request, Response } from 'express';
import { db, GroupCommunity } from '../db.js';

export const groupsRouter = Router();

// 1. Get all groups
groupsRouter.get('/', (req: Request, res: Response) => {
  try {
    const { category, userId } = req.query;
    let groups = [...db.get('groups')];

    if (category && category !== 'Todas') {
      groups = groups.filter(g => g.category.toLowerCase() === (category as string).toLowerCase());
    }

    // Add isMember flag if userId passed
    const enriched = groups.map(g => ({
      ...g,
      isMember: userId ? g.memberIds.includes(userId as string) : false,
      isAdmin: userId ? g.adminIds.includes(userId as string) : false,
      membersCount: g.memberIds.length
    }));

    return res.json({ groups: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao listar grupos: ' + err.message });
  }
});

// 2. Create group
groupsRouter.post('/', (req: Request, res: Response) => {
  try {
    const { name, description, category, isPrivate, creatorId, coverImage, avatar, rules, province } = req.body;

    if (!name?.trim() || !creatorId) {
      return res.status(400).json({ error: 'Nome e criador são obrigatórios.' });
    }

    const newGroup: GroupCommunity = {
      id: 'grp_' + Date.now().toString(36),
      name: name.trim(),
      description: description ? description.trim() : 'Comunidade activa no Angola Connect 🇦🇴',
      coverImage: coverImage || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
      avatar: avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg',
      category: category || 'Geral',
      isPrivate: Boolean(isPrivate),
      creatorId,
      adminIds: [creatorId],
      memberIds: [creatorId],
      pendingMemberIds: [],
      rules: rules || ['Respeito entre todos os participantes.'],
      province: province || 'Luanda',
      createdAt: new Date().toISOString()
    };

    const groups = db.get('groups');
    groups.unshift(newGroup);
    db.set('groups', groups);

    return res.status(201).json({ success: true, group: newGroup });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao criar grupo: ' + err.message });
  }
});

// 3. Join / Leave group
groupsRouter.post('/:id/join-toggle', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'ID do utilizador é necessário.' });
    }

    const groups = db.get('groups');
    const group = groups.find(g => g.id === id);
    if (!group) {
      return res.status(404).json({ error: 'Grupo não encontrado.' });
    }

    const isMember = group.memberIds.includes(userId);
    if (isMember) {
      if (group.creatorId === userId) {
        return res.status(400).json({ error: 'O criador não pode abandonar o grupo.' });
      }
      group.memberIds = group.memberIds.filter(mid => mid !== userId);
      group.adminIds = group.adminIds.filter(aid => aid !== userId);
    } else {
      if (group.isPrivate) {
        if (!group.pendingMemberIds.includes(userId)) {
          group.pendingMemberIds.push(userId);
        }
      } else {
        group.memberIds.push(userId);
      }
    }

    db.persist();
    return res.json({
      success: true,
      isMember: !isMember && !group.isPrivate,
      isPending: !isMember && group.isPrivate,
      membersCount: group.memberIds.length
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao alterar adesão: ' + err.message });
  }
});

// 4. Admin action on group
groupsRouter.post('/:id/admin-action', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { adminUserId, targetUserId, action } = req.body;
    // action: 'promote_admin' | 'remove_member' | 'approve_member' | 'reject_member'

    const groups = db.get('groups');
    const group = groups.find(g => g.id === id);
    if (!group) {
      return res.status(404).json({ error: 'Grupo não encontrado.' });
    }

    if (!group.adminIds.includes(adminUserId)) {
      return res.status(403).json({ error: 'Apenas administradores podem gerir membros.' });
    }

    if (action === 'promote_admin' && !group.adminIds.includes(targetUserId)) {
      group.adminIds.push(targetUserId);
    } else if (action === 'remove_member') {
      group.memberIds = group.memberIds.filter(mid => mid !== targetUserId);
      group.adminIds = group.adminIds.filter(aid => aid !== targetUserId);
    } else if (action === 'approve_member') {
      group.pendingMemberIds = group.pendingMemberIds.filter(mid => mid !== targetUserId);
      if (!group.memberIds.includes(targetUserId)) {
        group.memberIds.push(targetUserId);
      }
    } else if (action === 'reject_member') {
      group.pendingMemberIds = group.pendingMemberIds.filter(mid => mid !== targetUserId);
    }

    db.persist();
    return res.json({ success: true, group });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro na acção administrativa: ' + err.message });
  }
});
