import { Router, Request, Response } from 'express';
import { db, User, VerificationCode } from '../db.js';

export const authRouter = Router();

// SMS / Email verification codes store
// Rate limit helper: phone/email -> request timestamps
const requestRateLimits = new Map<string, number[]>();

// 1. Send verification code
authRouter.post('/send-code', (req: Request, res: Response) => {
  try {
    const { phoneOrEmail, method, phoneCountryCode } = req.body;
    if (!phoneOrEmail || typeof phoneOrEmail !== 'string') {
      return res.status(400).json({ error: 'Número de telefone ou e-mail é obrigatório.' });
    }

    const cleanTarget = phoneOrEmail.trim();

    // Check rate limit: max 5 requests per 10 minutes
    const now = Date.now();
    const timestamps = requestRateLimits.get(cleanTarget) || [];
    const recent = timestamps.filter(t => now - t < 10 * 60 * 1000);
    if (recent.length >= 5) {
      return res.status(429).json({
        error: 'Muitas tentativas de envio. Por favor aguarde alguns minutos antes de tentar novamente.'
      });
    }
    recent.push(now);
    requestRateLimits.set(cleanTarget, recent);

    // Invalidate prior codes for this phone or email
    const codes = db.get('verificationCodes').filter(c => c.phoneOrEmail !== cleanTarget);

    // Generate cryptographically suitable 6-digit code
    const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = now + 5 * 60 * 1000; // 5 minutes validity

    const newCodeItem: VerificationCode = {
      phoneOrEmail: cleanTarget,
      code: randomCode,
      expiresAt,
      attempts: 0,
      createdAt: now
    };

    codes.push(newCodeItem);
    db.set('verificationCodes', codes);

    console.log(`[SMS/VERIFY GATEWAY] Código gerado para ${cleanTarget}: ${randomCode} (expira em 5min)`);

    // In development/preview environment, we securely expose the code in debug object for easy testing,
    // while keeping real server generation, validation and expiration.
    return res.json({
      success: true,
      message: `Código de verificação enviado com sucesso para ${cleanTarget}.`,
      expiresInMinutes: 5,
      // For development verification support as requested:
      devDebugCode: process.env.NODE_ENV !== 'production' ? randomCode : undefined,
      phoneCountryCode: phoneCountryCode || '+244'
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro no servidor ao enviar código: ' + err.message });
  }
});

// 2. Verify code
authRouter.post('/verify-code', (req: Request, res: Response) => {
  try {
    const { phoneOrEmail, code } = req.body;
    if (!phoneOrEmail || !code) {
      return res.status(400).json({ error: 'Telefone/e-mail e código são necessários.' });
    }

    const cleanTarget = phoneOrEmail.trim();
    const cleanCode = code.toString().trim();

    const codes = db.get('verificationCodes');
    const entryIndex = codes.findIndex(c => c.phoneOrEmail === cleanTarget);

    if (entryIndex === -1) {
      return res.status(400).json({ error: 'Nenhum código ativo para este contacto. Solicite um novo código.' });
    }

    const entry = codes[entryIndex];
    const now = Date.now();

    // Check expiration
    if (now > entry.expiresAt) {
      codes.splice(entryIndex, 1);
      db.set('verificationCodes', codes);
      return res.status(400).json({ error: 'O código de verificação expirou. Por favor solicite um novo código.' });
    }

    // Check attempts limit
    if (entry.attempts >= 5) {
      codes.splice(entryIndex, 1);
      db.set('verificationCodes', codes);
      return res.status(400).json({ error: 'Limite de tentativas excedido (máximo 5). Solicite um novo código.' });
    }

    if (entry.code !== cleanCode) {
      entry.attempts += 1;
      db.set('verificationCodes', codes);
      return res.status(400).json({
        error: `Código incorreto. Restam ${5 - entry.attempts} tentativa(s).`
      });
    }

    // Code verified! Remove it so it cannot be reused
    codes.splice(entryIndex, 1);
    db.set('verificationCodes', codes);

    // Check if user already exists
    const users = db.get('users');
    const existing = users.find(u => u.phone === cleanTarget || u.email === cleanTarget);

    return res.json({
      success: true,
      verified: true,
      userExists: !!existing,
      user: existing || null
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao verificar código: ' + err.message });
  }
});

// 3. Register user
authRouter.post('/register', (req: Request, res: Response) => {
  try {
    const { name, username, email, phone, phoneCountryCode, password, province, bio, avatar, coverImage } = req.body;

    if (!name || !username) {
      return res.status(400).json({ error: 'Nome e nome de utilizador são obrigatórios.' });
    }

    const cleanUsername = username.toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (cleanUsername.length < 3) {
      return res.status(400).json({ error: 'Nome de utilizador deve ter pelo menos 3 caracteres alfanuméricos.' });
    }

    const users = db.get('users');
    if (users.some(u => u.username.toLowerCase() === cleanUsername)) {
      return res.status(409).json({ error: 'Este nome de utilizador já está a ser utilizado.' });
    }

    if (phone && users.some(u => u.phone === phone)) {
      return res.status(409).json({ error: 'Este número de telefone já está associado a uma conta.' });
    }

    if (email && users.some(u => u.email?.toLowerCase() === email.toLowerCase())) {
      return res.status(409).json({ error: 'Este e-mail já está associado a uma conta.' });
    }

    const newUser: User = {
      id: 'usr_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      name: name.trim(),
      username: cleanUsername,
      email: email?.trim(),
      phone: phone?.trim(),
      phoneCountryCode: phoneCountryCode || '+244',
      avatar: avatar || '/src/assets/images/angola_user_manuel_1793388060300.jpg',
      coverImage: coverImage || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
      bio: bio || 'Orgulhosamente conectado ao Angola Connect 🇦🇴',
      province: province || 'Luanda',
      verified: false,
      isPrivate: false,
      isAdmin: false,
      friends: ['usr_admin'],
      followers: ['usr_admin'],
      following: ['usr_admin'],
      blockedUsers: [],
      createdAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString()
    };

    // Auto-friend with admin for welcome experience
    const admin = users.find(u => u.id === 'usr_admin');
    if (admin && !admin.friends.includes(newUser.id)) {
      admin.friends.push(newUser.id);
      admin.followers.push(newUser.id);
    }

    users.push(newUser);
    db.set('users', users);

    // Create a welcome notification
    const notifications = db.get('notifications');
    notifications.push({
      id: 'notif_' + Date.now(),
      userId: newUser.id,
      fromUserId: 'usr_admin',
      type: 'friend_accepted',
      text: 'Seja bem-vindo ao Angola Connect! Conectando Angola ao mundo.',
      read: false,
      createdAt: new Date().toISOString()
    });
    db.set('notifications', notifications);

    return res.status(201).json({
      success: true,
      user: newUser
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao registar utilizador: ' + err.message });
  }
});

// 4. Quick Login by phone or email or username
authRouter.post('/login', (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier) {
      return res.status(400).json({ error: 'Identificador (telefone, e-mail ou username) obrigatório.' });
    }

    const clean = identifier.trim().toLowerCase();
    const users = db.get('users');
    const user = users.find(u =>
      u.username.toLowerCase() === clean ||
      u.email?.toLowerCase() === clean ||
      u.phone === identifier.trim()
    );

    if (!user) {
      return res.status(404).json({ error: 'Utilizador não encontrado com estes dados.' });
    }

    if (user.isSuspended) {
      return res.status(403).json({ error: 'Esta conta foi suspensa temporariamente pela moderação do Angola Connect.' });
    }

    user.lastSeenAt = new Date().toISOString();
    db.persist();

    return res.json({
      success: true,
      user
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro no login: ' + err.message });
  }
});

// 5. Account Recovery
authRouter.post('/recover', (req: Request, res: Response) => {
  try {
    const { phoneOrEmail, newPassword } = req.body;
    const clean = phoneOrEmail?.trim();
    const users = db.get('users');
    const user = users.find(u => u.phone === clean || u.email?.toLowerCase() === clean.toLowerCase());

    if (!user) {
      return res.status(404).json({ error: 'Conta não localizada para recuperação.' });
    }

    return res.json({
      success: true,
      message: 'Recuperação de conta efetuada com sucesso. Pode agora iniciar sessão com segurança.',
      user
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro na recuperação de conta: ' + err.message });
  }
});

// 6. Update Profile
authRouter.put('/profile/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, bio, province, avatar, coverImage, isPrivate } = req.body;
    const users = db.get('users');
    const user = users.find(u => u.id === id);

    if (!user) {
      return res.status(404).json({ error: 'Utilizador não encontrado.' });
    }

    if (name !== undefined) user.name = name.trim();
    if (bio !== undefined) user.bio = bio.trim();
    if (province !== undefined) user.province = province;
    if (avatar !== undefined) user.avatar = avatar;
    if (coverImage !== undefined) user.coverImage = coverImage;
    if (isPrivate !== undefined) user.isPrivate = Boolean(isPrivate);

    db.persist();

    return res.json({ success: true, user });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao atualizar perfil: ' + err.message });
  }
});
