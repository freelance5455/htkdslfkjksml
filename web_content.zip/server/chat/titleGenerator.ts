/**
 * JARVIS Intelligent Conversation Title Generator
 * Generates concise, topic-accurate 2-5 word titles from user requests.
 * Respects user manual renames and supports English, Hindi, and Hinglish.
 */

import { db } from '../db/database.ts';

const GENERIC_TITLES = new Set([
  'new chat',
  'new session',
  'active conversation',
  'jarvis primary session',
  'general session',
  'untitled conversation',
  'session',
]);

export class TitleGenerator {
  /**
   * Check if a conversation title is generic and eligible for automatic update
   */
  public isGenericTitle(title: string): boolean {
    if (!title || title.trim().length === 0) return true;
    return GENERIC_TITLES.has(title.trim().toLowerCase());
  }

  /**
   * Generates a concise title from the user prompt and context
   */
  public generateTitle(prompt: string): string {
    const raw = (prompt || '').trim();
    if (!raw) return 'General Session';

    // 1. Math / calculation detection
    if (/^[\d\s+\-*/xX÷().%^=]+$/.test(raw) || /^(calculate|compute|solve|math|hisab)\s+/i.test(raw)) {
      return 'Arithmetic Calculation';
    }

    // 2. Founder / developer identity
    if (/founder|developer|creator|aaradhy|who\s+are\s+you|who\s+made\s+you|kisne\s+banaya/i.test(raw)) {
      if (/aaradhy/i.test(raw)) {
        return 'Founder Profile — Aaradhy Parmar';
      }
      return 'Founder & Architect Inquiry';
    }

    // 3. Free resources / tools discovery
    if (/free\s+(ai|tools|video|music|courses|developer|hosting)/i.test(raw)) {
      const match = raw.match(/free\s+([a-zA-Z0-9\s-]+?)(?:\s+(?:tools|resources|software|options|hai|batao|do))?$/i);
      if (/video/i.test(raw)) return 'Free AI Video Tools';
      if (/music/i.test(raw)) return 'Free AI Audio Tools';
      if (/courses/i.test(raw)) return 'Free Online Courses';
      return 'Free AI Tools Discovery';
    }

    // 4. Specific domain heuristic mappings
    if (/quantum\s+gravity/i.test(raw)) {
      if (/hinglish/i.test(raw)) return 'Quantum Gravity — Hinglish Study';
      return 'Quantum Gravity Research';
    }

    if (/android\s+voice\s+assistant/i.test(raw) || (/android/i.test(raw) && /voice/i.test(raw))) {
      return 'Android Voice Assistant';
    }

    if (/snake\s+game/i.test(raw)) {
      return 'Python Snake Game';
    }

    if (/black\s+hole\s+thermodynamics/i.test(raw)) {
      return 'Black Hole Thermodynamics';
    }

    // 5. General cleaning of conversational prefixes in English & Hinglish
    let clean = raw
      .replace(/^[\s,.;:!?]+|[\s,.;:!?]+$/g, '')
      // Remove conversational greetings and triggers
      .replace(/^(hey|hi|hello|namaste|jarvis|bhai|sun)\b[\s,.:;!-]*/i, '')
      // Remove intent request phrases (English & Hinglish)
      .replace(/^(can\s+you\s+(?:please\s+)?(?:explain|tell|show|write|build|create|find|give|help\s+with))\b/i, '')
      .replace(/^(please\s+(?:explain|tell|show|write|build|create|find|give|help\s+with))\b/i, '')
      .replace(/^(could\s+you\s+(?:please\s+)?(?:explain|tell|show|write|build|create|find|give))\b/i, '')
      .replace(/^(explain|describe|tell\s+me\s+about|what\s+is|what\s+are|how\s+to|how\s+does|write\s+a|build\s+a|create\s+a)\b/i, '')
      .replace(/^(mujhe|humko|kya\s+aap|kya\s+tum|batao|samjhao|likho|banao)\b[\s,.:;!-]*/i, '')
      .trim();

    // Remove trailing Hinglish / conversational tags
    clean = clean
      .replace(/\b(in\s+hinglish|in\s+hindi|in\s+english|batao|samjhao|karo|plz|please|kya\s+hai)\b[\s?!.]*$/i, '')
      .trim();

    if (!clean) {
      if (/^(hi|hello|hey|namaste)/i.test(raw)) return 'Greeting Session';
      return 'General Discussion';
    }

    // Split words, take first 4-5 words
    const words = clean
      .split(/\s+/)
      .filter((w) => w.length > 0 && !/^(the|a|an|in|on|at|of|for|with|and|or|ke|ka|ki|ko)$/i.test(w))
      .slice(0, 4);

    if (words.length === 0) {
      return 'General Query';
    }

    // Capitalize each word nicely
    const capitalized = words
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');

    // Truncate to max 35 chars cleanly
    if (capitalized.length > 35) {
      return capitalized.slice(0, 32) + '...';
    }

    return capitalized;
  }

  /**
   * Process conversation after a new user message.
   * Only updates title if conversation has generic title and user has not set a custom title.
   */
  public async maybeAutoUpdateTitle(
    conversationId: string,
    firstPrompt: string
  ): Promise<string | null> {
    try {
      const conv = await db.getConversation(conversationId);
      if (!conv) return null;

      // Never overwrite manual user renames
      if (conv.hasCustomTitle) {
        return null;
      }

      // Only generate if title is still generic
      if (!this.isGenericTitle(conv.title)) {
        return null;
      }

      const newTitle = this.generateTitle(firstPrompt);
      if (newTitle && newTitle !== conv.title) {
        await db.saveConversation({
          ...conv,
          title: newTitle,
          hasCustomTitle: false, // Remains auto-generated
          updatedAt: new Date().toISOString(),
        });
        return newTitle;
      }
    } catch (err) {
      console.warn('Auto title generation skipped due to error:', err);
    }
    return null;
  }
}

export const titleGenerator = new TitleGenerator();

export function generateConversationTitle(prompt: string): string {
  return titleGenerator.generateTitle(prompt);
}
