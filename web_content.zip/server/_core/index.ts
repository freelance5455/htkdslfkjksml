import "dotenv/config";
import express, { type Request, type Response } from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { sdk } from "./sdk";
import { serveStatic, setupVite } from "./vite";
import { getLikeRequestStats, insertLikeRequest } from "../db";

const PROVIDER_URL = "https://vip-like-api-ehd8.onrender.com";
type StoredRequest = { playerId: string; amount: number; createdAt: string; status: "pending" | "confirmed" | "error"; message: string };
const requestLog: StoredRequest[] = [];

async function providerFetch(path: string, init?: RequestInit) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    return await fetch(`${PROVIDER_URL}${path}`, { ...init, signal: controller.signal, headers: { Accept: "application/json", ...(init?.headers || {}) } });
  } finally { clearTimeout(timeout); }
}

async function readJson(response: globalThis.Response) {
  const text = await response.text();
  try { return text ? JSON.parse(text) : {}; } catch { return { raw: text.slice(0, 500) }; }
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "vip-like-generator" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.get("/api/provider-health", async (_req, res) => {
    try {
      const [rootResponse, healthResponse] = await Promise.all([providerFetch("/"), providerFetch("/api/health")]);
      const [rootData, healthData] = await Promise.all([readJson(rootResponse), readJson(healthResponse)]);
      const ok = rootResponse.ok && healthResponse.ok;
      res.status(ok ? 200 : 502).json({ ok, providerStatus: healthResponse.status, detail: ok ? "Raíz y health check respondieron correctamente" : "El proveedor respondió con un estado no saludable", root: rootData, health: healthData });
    } catch (error) {
      res.status(502).json({ ok: false, detail: error instanceof Error && error.name === "AbortError" ? "Tiempo de espera agotado" : "No se pudo alcanzar el proveedor" });
    }
  });
  app.post("/api/likes", async (req, res) => {
    const playerId = typeof req.body?.playerId === "string" ? req.body.playerId.trim() : "";
    if (!/^\d{6,15}$/.test(playerId)) return res.status(400).json({ confirmed: false, message: "playerId debe contener entre 6 y 15 dígitos." });
    try {
      const response = await providerFetch("/api/likes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId }) });
      const data = await readJson(response);
      const confirmed = response.ok && (data.confirmed === true || data.status === "confirmed" || data.status === "delivered");
      const status: StoredRequest["status"] = !response.ok ? "error" : confirmed ? "confirmed" : "pending";
      const message = typeof data.message === "string" ? data.message : confirmed ? "El proveedor confirmó la solicitud." : "Solicitud aceptada; pendiente de proveedor autorizado.";
      requestLog.unshift({ playerId, amount: 200, createdAt: new Date().toISOString(), status, message });
      requestLog.splice(50);
      await insertLikeRequest({ playerId, amount: 200, status, message }).catch(error => console.warn("[Database] Request history unavailable:", error));
      res.status(response.ok ? 200 : 502).json({ confirmed, status, message, providerStatus: response.status, provider: data });
    } catch (error) {
      const message = error instanceof Error && error.name === "AbortError" ? "El proveedor tardó demasiado en responder." : "No se pudo conectar con el proveedor.";
      requestLog.unshift({ playerId, amount: 200, createdAt: new Date().toISOString(), status: "error", message });
      await insertLikeRequest({ playerId, amount: 200, status: "error", message }).catch(dbError => console.warn("[Database] Failed request history unavailable:", dbError));
      res.status(502).json({ confirmed: false, status: "error", message });
    }
  });
  app.get("/api/admin/stats", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (user.role !== "admin") return res.status(403).json({ message: "Admin role required" });
      const uniqueIds = new Set(requestLog.map(item => item.playerId));
      let providerStatus = "unknown";
      try { const providerResponse = await providerFetch("/api/health"); providerStatus = providerResponse.ok ? "online" : "degraded"; } catch { providerStatus = "offline"; }
      const databaseStats = await getLikeRequestStats().catch(() => null);
      res.json({ totalIds: databaseStats?.totalIds ?? uniqueIds.size, totalRequests: databaseStats?.totalRequests ?? requestLog.length, providerStatus, recent: databaseStats?.recent ?? requestLog.slice(0, 20) });
    } catch { res.status(401).json({ message: "Authentication required" }); }
  });
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server); else serveStatic(app);
  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
