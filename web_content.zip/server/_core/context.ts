import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import type { AdminIdentity } from "../admin-auth";
import { authenticateAdmin } from "../admin-auth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  /** Retained only for starter type compatibility; dashboard routes never use Manus identities. */
  user: User | null;
  admin: AdminIdentity | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let admin: AdminIdentity | null = null;
  try { admin = await authenticateAdmin(opts.req); } catch (error) {
    console.error("[Admin auth] Session lookup failed", error instanceof Error ? error.message : "unknown error");
  }
  return { req: opts.req, res: opts.res, user: null, admin };
}
