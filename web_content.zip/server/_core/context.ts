import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { ensureLocalUser, getWorkspaceAccountById } from "../db";
import { localSessionCookieName, readLocalSession } from "../localAuth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  if (!user) {
    const cookies = Object.fromEntries((opts.req.headers.cookie ?? "").split(";").filter(Boolean).map(value => {
      const [key, ...rest] = value.trim().split("=");
      return [key, rest.join("=")];
    }));
    const session = readLocalSession(cookies[localSessionCookieName()]);
    if (session) {
      const account = await getWorkspaceAccountById(session.accountId);
      if (account) user = (await ensureLocalUser(account)) ?? null;
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
