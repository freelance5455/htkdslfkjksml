import { TRPCError, initTRPC } from "@trpc/server";
import superjson from "superjson";
import type { AdminRole } from "../../drizzle/schema";
import type { TrpcContext } from "./context";
import { validCsrf } from "../admin-auth";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
  errorFormatter({ shape }) {
    return { ...shape, data: { ...shape.data, stack: undefined } };
  },
});
export const router = t.router;
export const publicProcedure = t.procedure;

const requireAdmin = t.middleware(({ ctx, next }) => {
  if (!ctx.admin) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in and complete two-factor verification." });
  if (ctx.req.method !== "GET" && !validCsrf(ctx.req)) throw new TRPCError({ code: "FORBIDDEN", message: "Security check failed. Refresh and try again." });
  return next({ ctx: { ...ctx, admin: ctx.admin } });
});

export const adminProcedure = t.procedure.use(requireAdmin);
export const rolesProcedure = (...roles: AdminRole[]) => adminProcedure.use(({ ctx, next }) => {
  if (!roles.includes(ctx.admin.role)) throw new TRPCError({ code: "FORBIDDEN", message: "Your role cannot perform this action." });
  return next({ ctx });
});
