import type { Permission } from "../../shared/types.js";

export function requiresConfirmation(p: Permission): boolean {
  return p === "SENSITIVE" || p === "EXTERNAL_ACTION";
}

export function canExecute(p: Permission, confirmed = false): boolean {
  return p === "READ" || p === "SAFE_WRITE" ||
    (confirmed && requiresConfirmation(p));
}
