/**
 * JARVIS Security Layer
 * Manages authorization, permission level gating (READ, SAFE_WRITE, SENSITIVE, EXTERNAL_ACTION),
 * interactive approval challenges, rate limiting, and immutable audit logging.
 */

import { config } from '../config/index.ts';
import { db } from '../db/database.ts';
import type { AuditLog, PermissionLevel } from '../types.ts';

export interface PendingPermissionRequest {
  id: string;
  taskId: string;
  stepId: string;
  action: string;
  toolName: string;
  permissionLevel: PermissionLevel;
  details: Record<string, unknown>;
  createdAt: string;
}

export class SecurityLayer {
  private pendingRequests: Map<string, PendingPermissionRequest> = new Map();
  private rateLimits: Map<string, { count: number; windowStart: number }> = new Map();

  public requiresApproval(level: PermissionLevel): boolean {
    return level === 'SENSITIVE' || level === 'EXTERNAL_ACTION';
  }

  /**
   * Check whether an action can proceed automatically or requires explicit human approval
   */
  public async evaluatePermission(
    action: string,
    toolName: string,
    level: PermissionLevel,
    context: { taskId: string; stepId: string; details: Record<string, unknown>; approved?: boolean }
  ): Promise<{ allowed: boolean; pendingRequestId?: string; reason?: string }> {
    // 1. Audit log the intent
    const audit: AuditLog = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      action,
      actor: 'JARVIS_AGENT',
      permissionLevel: level,
      details: context.details,
      status: 'ALLOWED',
    };

    // READ: Always allowed
    if (level === 'READ') {
      await db.recordAuditLog(audit);
      return { allowed: true };
    }

    // SAFE_WRITE: Allowed with audit trail
    if (level === 'SAFE_WRITE') {
      await db.recordAuditLog(audit);
      return { allowed: true };
    }

    // SENSITIVE or EXTERNAL_ACTION:
    // If already approved by user in UI challenge, allow
    if (context.approved) {
      audit.status = 'ALLOWED';
      await db.recordAuditLog(audit);
      return { allowed: true };
    }

    // Otherwise, create a pending approval challenge and halt execution until confirmed
    audit.status = 'PENDING_APPROVAL';
    await db.recordAuditLog(audit);

    const reqId = `perm_req_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const pendingReq: PendingPermissionRequest = {
      id: reqId,
      taskId: context.taskId,
      stepId: context.stepId,
      action,
      toolName,
      permissionLevel: level,
      details: context.details,
      createdAt: new Date().toISOString(),
    };

    this.pendingRequests.set(reqId, pendingReq);

    return {
      allowed: false,
      pendingRequestId: reqId,
      reason: `Action requires explicit human permission level: ${level}`,
    };
  }

  public getPendingRequests(): PendingPermissionRequest[] {
    return Array.from(this.pendingRequests.values());
  }

  public getPendingRequest(id: string): PendingPermissionRequest | undefined {
    return this.pendingRequests.get(id);
  }

  public resolveRequest(id: string, approved: boolean): PendingPermissionRequest | null {
    const req = this.pendingRequests.get(id);
    if (!req) return null;
    this.pendingRequests.delete(id);

    db.recordAuditLog({
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
      timestamp: new Date().toISOString(),
      action: approved ? 'PERMISSION_GRANTED_BY_USER' : 'PERMISSION_DENIED_BY_USER',
      actor: 'HUMAN_OPERATOR',
      permissionLevel: req.permissionLevel,
      details: { reqId: id, toolName: req.toolName, taskId: req.taskId },
      status: approved ? 'ALLOWED' : 'DENIED',
    });

    return req;
  }

  /**
   * Rate limiting by client IP or session
   */
  public checkRateLimit(
    key: string,
    maxRequests = config.security.rateLimitMaxRequests,
    windowMs = config.security.rateLimitWindowMs
  ): boolean {
    const now = Date.now();
    const current = this.rateLimits.get(key) || { count: 0, windowStart: now };

    if (now - current.windowStart > windowMs) {
      this.rateLimits.set(key, { count: 1, windowStart: now });
      return true;
    }

    if (current.count >= maxRequests) {
      return false;
    }

    current.count += 1;
    this.rateLimits.set(key, current);
    return true;
  }

  /**
   * Sanitizes user input string against command injection patterns
   */
  public sanitizeInput(input: string): string {
    return input.trim().replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  }
}

export const securityLayer = new SecurityLayer();
