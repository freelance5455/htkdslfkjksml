'use strict';
/**
 * ترید یار — کانکتورهای فیوچرز (USDT-M دائمی): Binance، MEXC، Bybit
 * هر سه با همان رابط کانکتورهای exchanges.js؛ حجم‌ها همیشه به «واحد ارز پایه» هستند.
 * ساخته‌شده با build(H) تا به exchanges.js وابسته (و دایره‌ای) نباشد.
 */
module.exports = function build(H) {
  const { ExchangeError, hmac, num, cleanObj, qs, floorToStep, mkMarket, normInterval, IV_SEC, need } = H;
  const lc = (s) => String(s || '').toLowerCase();
  const tickStr = (v, mk) => floorToStep(v, mk && mk.tickSize > 0 ? mk.tickSize : 0);

  /* ================================ Binance USDT-M ================================ */
  function binance() {
    const base = 'https://fapi.binance.com';
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || (j && typeof j === 'object' && !Array.isArray(j) && j.code !== undefined && Number(j.code) < 0)) {
        throw new ExchangeError((j && j.msg) || 'خطای Binance Futures ' + r.status, { code: j && j.code, status: r.status, raw: j });
      }
      return j;
    };
    const signed = async (ctx, creds, method, path, params = {}) => {
      need(creds, 'apiKey', 'apiSecret');
      const query = qs(cleanObj({ ...params, recvWindow: 10000, timestamp: ctx.now() }));
      const signature = hmac('sha256', creds.apiSecret, query);
      return unwrap(await ctx.http(method, `${base}${path}?${query}&signature=${signature}`, { headers: { 'X-MBX-APIKEY': creds.apiKey } }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
    const isHedge = async (ctx, creds) => !!((await signed(ctx, creds, 'GET', '/fapi/v1/positionSide/dual')) || {}).dualSidePosition;
    const posSideFor = (side, reduce) => ((side === 'buy') !== !!reduce ? 'LONG' : 'SHORT'); // خرید باز = LONG ؛ فروش کاهشی = LONG

    const self = {
      id: 'binance', name: 'Binance Futures', type: 'futures', needsPassphrase: false, hosts: ['fapi.binance.com'],
      async markets(ctx) {
        const r = await pub(ctx, '/fapi/v1/exchangeInfo');
        return ((r && r.symbols) || []).filter((s) => s.contractType === 'PERPETUAL' && s.quoteAsset === 'USDT').map((s) => {
          const f = {}; (s.filters || []).forEach((x) => { f[x.filterType] = x; });
          return mkMarket({
            symbol: s.symbol, base: s.baseAsset, quote: s.quoteAsset, type: 'futures', trading: s.status === 'TRADING',
            tickSize: num(f.PRICE_FILTER && f.PRICE_FILTER.tickSize), stepSize: num(f.LOT_SIZE && f.LOT_SIZE.stepSize),
            minQty: num(f.LOT_SIZE && f.LOT_SIZE.minQty), minNotional: num(f.MIN_NOTIONAL && (f.MIN_NOTIONAL.notional || f.MIN_NOTIONAL.minNotional)),
          });
        });
      },
      async tickers(ctx) {
        const r = await pub(ctx, '/fapi/v1/ticker/24hr');
        return (Array.isArray(r) ? r : []).filter((t) => /USDT$/.test(t.symbol)).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: num(t.priceChangePercent), quoteVol: num(t.quoteVolume), high: num(t.highPrice), low: num(t.lowPrice) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const r = await pub(ctx, '/fapi/v1/klines', { symbol, interval: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1500) });
        return (Array.isArray(r) ? r : []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]);
      },
      async balance(ctx, creds) {
        const a = await signed(ctx, creds, 'GET', '/fapi/v2/account');
        const balances = ((a && a.assets) || []).map((x) => { const w = num(x.walletBalance), f = num(x.availableBalance); return { asset: x.asset, free: f, locked: Math.max(0, w - f), w }; })
          .filter((x) => x.w > 0 || x.free > 0).map(({ asset, free, locked }) => ({ asset, free, locked }));
        return { balances, canTrade: a.canTrade !== false, canWithdraw: !!a.canWithdraw };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) {
          try { await signed(ctx, creds, 'POST', '/fapi/v1/marginType', { symbol, marginType: marginMode === 'cross' ? 'CROSSED' : 'ISOLATED' }); }
          catch (e) { if (Number(e.exCode) !== -4046) throw e; }
        }
        return signed(ctx, creds, 'POST', '/fapi/v1/leverage', { symbol, leverage: Number(leverage) });
      },
      async placeOrder(ctx, creds, o) {
        const sym = o.market.symbol;
        if (o.leverage && !o.test) {
          try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); }
          catch (e) { if (!o.ignoreLeverageError) throw e; }
        }
        const hedge = await isHedge(ctx, creds);
        const side = o.side === 'buy' ? 'BUY' : 'SELL';
        const p = { symbol: sym, side, type: o.type === 'limit' ? 'LIMIT' : 'MARKET', quantity: o.qty, newClientOrderId: o.clientId };
        if (o.type === 'limit') { p.price = o.price; p.timeInForce = 'GTC'; }
        if (hedge) p.positionSide = posSideFor(o.side, o.reduceOnly); else if (o.reduceOnly) p.reduceOnly = 'true';
        const r = await signed(ctx, creds, 'POST', o.test ? '/fapi/v1/order/test' : '/fapi/v1/order', p);
        let native = false;
        if (!o.test && o.type !== 'limit' && !o.reduceOnly && (o.sl > 0 || o.tp > 0)) {
          const opp = o.side === 'buy' ? 'SELL' : 'BUY';
          const algo = (type, price) => signed(ctx, creds, 'POST', '/fapi/v1/algoOrder', cleanObj({
            symbol: sym, side: opp, algoType: 'CONDITIONAL', type, triggerPrice: tickStr(price, o.market), closePosition: 'true', workingType: 'MARK_PRICE', positionSide: hedge ? posSideFor(o.side, false) : undefined,
          }));
          try {
            if (o.sl > 0) await algo('STOP_MARKET', o.sl);
            if (o.tp > 0) await algo('TAKE_PROFIT_MARKET', o.tp);
            native = true;
          } catch (e) {
            // بدون حد ضرر نباید پوزیشن باز بماند → بستن اضطراری
            try { await self.placeOrder(ctx, creds, { market: o.market, side: opp.toLowerCase(), type: 'market', qty: o.qty, reduceOnly: true }); } catch { /* ignore */ }
            throw new ExchangeError('ثبت حد ضرر/سود ناموفق بود و پوزیشن بسته شد: ' + e.message, { code: e.exCode, raw: e.raw });
          }
        }
        return { orderId: String((r && r.orderId) || ''), nativeProtection: native, raw: r };
      },
      async positions(ctx, creds, symbol) {
        const r = await signed(ctx, creds, 'GET', '/fapi/v2/positionRisk', symbol ? { symbol } : {});
        return (Array.isArray(r) ? r : []).filter((x) => num(x.positionAmt) !== 0).map((x) => {
          const amt = num(x.positionAmt), lev = num(x.leverage) || 1;
          const side = x.positionSide === 'LONG' ? 'long' : x.positionSide === 'SHORT' ? 'short' : amt > 0 ? 'long' : 'short';
          const margin = lc(x.marginType) === 'isolated' ? num(x.isolatedMargin) : Math.abs(num(x.notional)) / lev;
          return { positionId: `${x.symbol}|${side}`, symbol: x.symbol, side, qty: Math.abs(amt), entry: num(x.entryPrice), leverage: lev, margin, pnl: num(x.unRealizedProfit), liqPrice: num(x.liquidationPrice) };
        });
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const p = (await self.positions(ctx, creds, symbol)).find((x) => x.symbol === symbol && (!side || x.side === side));
        if (!p) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        return self.placeOrder(ctx, creds, { market: { symbol, tickSize: 0 }, side: p.side === 'long' ? 'sell' : 'buy', type: 'market', qty: String(p.qty), reduceOnly: true });
      },
      async openOrders(ctx, creds, symbol) {
        const r = await signed(ctx, creds, 'GET', '/fapi/v1/openOrders', symbol ? { symbol } : {});
        const out = (Array.isArray(r) ? r : []).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: lc(x.side), type: lc(x.type), price: num(x.price), qty: num(x.origQty), filled: num(x.executedQty), status: x.status }));
        try {
          const a = await signed(ctx, creds, 'GET', '/fapi/v1/openAlgoOrders', symbol ? { symbol } : {});
          (Array.isArray(a) ? a : []).forEach((x) => out.push({ orderId: 'algo:' + x.algoId, symbol: x.symbol, side: lc(x.side), type: lc(x.orderType || x.type), price: num(x.triggerPrice), qty: num(x.quantity), filled: 0, status: x.algoStatus || 'NEW' }));
        } catch { /* ignore */ }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const id = String(orderId);
        if (id.startsWith('algo:')) return { orderId: id, raw: await signed(ctx, creds, 'DELETE', '/fapi/v1/algoOrder', { algoId: id.slice(5) }) };
        return { orderId: id, raw: await signed(ctx, creds, 'DELETE', '/fapi/v1/order', { symbol, orderId: id }) };
      },
    };
    return self;
  }

  /* ================================ MEXC Futures ================================ */
  function mexc() {
    const base = 'https://contract.mexc.com';
    const IVM = { '1m': 'Min1', '5m': 'Min5', '15m': 'Min15', '30m': 'Min30', '1h': 'Min60', '4h': 'Hour4', '1d': 'Day1', '1w': 'Week1' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || j.success === false || (j.code !== undefined && Number(j.code) !== 0 && Number(j.code) !== 200)) {
        throw new ExchangeError((j && (j.message || j.msg)) || 'خطای MEXC Futures ' + r.status, { code: j && j.code, status: r.status, raw: j });
      }
      return j.data;
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(ctx.now());
      let paramStr = '', bodyStr, url = base + path;
      if (method === 'GET') {
        paramStr = Object.keys(cleanObj(params || {})).sort().map((k) => `${k}=${encodeURIComponent(params[k])}`).join('&');
        if (paramStr) url += '?' + paramStr;
      } else { bodyStr = JSON.stringify(body === undefined ? {} : body); paramStr = bodyStr; }
      const headers = { ApiKey: creds.apiKey, 'Request-Time': ts, Signature: hmac('sha256', creds.apiSecret, creds.apiKey + ts + paramStr), 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, url, { headers, body: bodyStr }));
    };
    const spec = new Map();
    const specOf = async (ctx, symbol) => {
      if (spec.has(symbol)) return spec.get(symbol);
      const d = await pub(ctx, '/api/v1/contract/detail', { symbol });
      const s = Array.isArray(d) ? d.find((x) => x.symbol === symbol) : d;
      if (!s) throw new ExchangeError('قرارداد پیدا نشد', { code: 'unknown_symbol' });
      const v = { cs: num(s.contractSize) || 1, vu: num(s.volUnit) || 1 };
      spec.set(symbol, v);
      return v;
    };
    const getMode = async (ctx, creds) => { try { return Number(await call(ctx, creds, 'GET', '/api/v1/private/position/position_mode')) === 1 ? 1 : 2; } catch { return 2; } };
    const SIDE_FA = { 1: 'buy', 2: 'buy', 3: 'sell', 4: 'sell' };

    const self = {
      id: 'mexc', name: 'MEXC Futures', type: 'futures', needsPassphrase: false, hosts: ['contract.mexc.com'],
      async markets(ctx) {
        const d = await pub(ctx, '/api/v1/contract/detail');
        return (Array.isArray(d) ? d : [d]).filter((s) => s && s.quoteCoin === 'USDT' && s.settleCoin === 'USDT').map((s) => {
          const cs = num(s.contractSize) || 1, vu = num(s.volUnit) || 1;
          spec.set(s.symbol, { cs, vu });
          return mkMarket({ symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: Number(s.state) === 0 && s.apiAllowed !== false, tickSize: num(s.priceUnit), stepSize: vu * cs, minQty: num(s.minVol) * cs, maxLeverage: s.maxLeverage });
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v1/contract/ticker');
        return (Array.isArray(d) ? d : [d]).filter((t) => t && /_USDT$/.test(t.symbol)).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: Number((num(t.riseFallRate) * 100).toFixed(6)), quoteVol: num(t.amount24), high: num(t.high24Price), low: num(t.lower24Price) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const iv = normInterval(interval), n = Math.min(limit || 300, 2000), end = Math.floor(ctx.now() / 1000);
        const [d, sp] = await Promise.all([pub(ctx, `/api/v1/contract/kline/${symbol}`, { interval: IVM[iv], start: end - n * IV_SEC[iv], end }), specOf(ctx, symbol)]);
        const t = (d && d.time) || [];
        return t.map((ts, i) => [ts * 1000, num(d.open[i]), num(d.high[i]), num(d.low[i]), num(d.close[i]), num(d.vol[i]) * sp.cs]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/account/assets');
        const balances = (Array.isArray(d) ? d : []).map((a) => ({ asset: a.currency, free: num(a.availableBalance), locked: num(a.frozenBalance) + num(a.positionMargin) })).filter((b) => b.free > 0 || b.locked > 0);
        return { balances, canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const openType = marginMode === 'cross' ? 2 : 1;
        for (const positionType of [1, 2]) await call(ctx, creds, 'POST', '/api/v1/private/position/change_leverage', null, { symbol, leverage: Number(leverage), openType, positionType });
        return true;
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('MEXC حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, sp = await specOf(ctx, sym), mode = await getMode(ctx, creds);
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; }
        }
        const buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const body = {
          symbol: sym, vol: floorToStep(Number(o.qty) / sp.cs, sp.vu), side: reduce ? (buy ? 2 : 4) : (buy ? 1 : 3), type: o.type === 'limit' ? 1 : 5,
          openType: o.marginMode === 'cross' ? 2 : 1, positionMode: mode,
        };
        if (o.type === 'limit') body.price = tickStr(o.price, o.market);
        if (o.leverage && !reduce) body.leverage = Number(o.leverage);
        if (reduce && mode === 2) body.reduceOnly = true;
        if (o.clientId) body.externalOid = o.clientId;
        if (!reduce) {
          if (o.sl > 0) body.stopLossPrice = tickStr(o.sl, o.market);
          if (o.tp > 0) body.takeProfitPrice = tickStr(o.tp, o.market);
        }
        const d = await call(ctx, creds, 'POST', '/api/v1/private/order/submit', null, body);
        return { orderId: String((d && typeof d === 'object' ? d.orderId : d) || ''), nativeProtection: !reduce && !!(o.sl > 0 || o.tp > 0), raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/position/open_positions', symbol ? { symbol } : {});
        const out = [];
        for (const x of (Array.isArray(d) ? d : [])) {
          if (!(num(x.holdVol) > 0)) continue;
          const sp = await specOf(ctx, x.symbol), qty = num(x.holdVol) * sp.cs, long = Number(x.positionType) === 1, entry = num(x.holdAvgPrice);
          let fair = 0;
          try { const t = await pub(ctx, '/api/v1/contract/ticker', { symbol: x.symbol }); const tt = Array.isArray(t) ? t[0] : t; fair = num(tt && (tt.fairPrice || tt.lastPrice)); } catch { /* ignore */ }
          out.push({ positionId: String(x.positionId), symbol: x.symbol, side: long ? 'long' : 'short', qty, entry, leverage: num(x.leverage), margin: num(x.im), pnl: fair > 0 ? (long ? fair - entry : entry - fair) * qty : num(x.realised), liqPrice: num(x.liquidatePrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/position/open_positions', {});
        const x = (Array.isArray(d) ? d : []).find((p) => String(p.positionId) === String(positionId) && num(p.holdVol) > 0);
        if (!x) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        const mode = await getMode(ctx, creds);
        const body = { symbol: x.symbol, vol: String(x.holdVol), side: Number(x.positionType) === 1 ? 4 : 2, type: 5, openType: Number(x.openType) || 1, positionId: Number(x.positionId), positionMode: mode };
        if (mode === 2) body.reduceOnly = true;
        const r = await call(ctx, creds, 'POST', '/api/v1/private/order/submit', null, body);
        return { raw: r };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/order/list/open_orders' + (symbol ? '/' + symbol : ''), { page_num: 1, page_size: 100 });
        const list = Array.isArray(d) ? d : (d && d.resultList) || [];
        const out = [];
        for (const x of list) {
          const sp = await specOf(ctx, x.symbol);
          out.push({ orderId: String(x.orderId), symbol: x.symbol, side: SIDE_FA[x.side] || 'buy', type: Number(x.orderType) === 1 ? 'limit' : 'market', price: num(x.price), qty: num(x.vol) * sp.cs, filled: num(x.dealVol) * sp.cs, status: x.state });
        }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/api/v1/private/order/cancel', null, [Number(orderId)]);
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  /* ================================ Bybit Linear ================================ */
  function bybit() {
    const base = 'https://api.bybit.com';
    const IVM = { '1m': '1', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D', '1w': 'W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || Number(j.retCode) !== 0) throw new ExchangeError((j && j.retMsg) || 'خطای Bybit ' + r.status, { code: j && j.retCode, status: r.status, raw: j });
      return j.result;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(ctx.now()), recv = '10000';
      const query = method === 'GET' ? qs(params || {}) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const sign = hmac('sha256', creds.apiSecret, ts + creds.apiKey + recv + (method === 'GET' ? query : bodyStr));
      const headers = { 'X-BAPI-API-KEY': creds.apiKey, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': sign, 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
    const ignoring = async (fn, ...codes) => { try { return await fn(); } catch (e) { if (codes.includes(Number(e.exCode))) return null; throw e; } };

    const self = {
      id: 'bybit', name: 'Bybit Futures', type: 'futures', needsPassphrase: false, hosts: ['api.bybit.com'],
      async markets(ctx) {
        const out = []; let cursor;
        for (let i = 0; i < 10; i++) {
          const r = await pub(ctx, '/v5/market/instruments-info', { category: 'linear', limit: 1000, cursor });
          (r.list || []).filter((s) => s.contractType === 'LinearPerpetual' && s.quoteCoin === 'USDT').forEach((s) => out.push(mkMarket({
            symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: s.status === 'Trading',
            tickSize: num(s.priceFilter && s.priceFilter.tickSize), stepSize: num(s.lotSizeFilter && s.lotSizeFilter.qtyStep), minQty: num(s.lotSizeFilter && s.lotSizeFilter.minOrderQty),
            minNotional: num(s.lotSizeFilter && s.lotSizeFilter.minNotionalValue), maxLeverage: s.leverageFilter && s.leverageFilter.maxLeverage,
          })));
          cursor = r.nextPageCursor;
          if (!cursor) break;
        }
        return out;
      },
      async tickers(ctx) {
        const r = await pub(ctx, '/v5/market/tickers', { category: 'linear' });
        return (r.list || []).filter((t) => /USDT$/.test(t.symbol)).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: num(t.price24hPcnt) * 100, quoteVol: num(t.turnover24h), high: num(t.highPrice24h), low: num(t.lowPrice24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const r = await pub(ctx, '/v5/market/kline', { category: 'linear', symbol, interval: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
        return (r.list || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).reverse();
      },
      async balance(ctx, creds) {
        const r = await call(ctx, creds, 'GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED' });
        const acc = (r.list && r.list[0]) || {};
        const usdt = (acc.coin || []).find((c) => c.coin === 'USDT');
        const wallet = usdt ? num(usdt.walletBalance) : 0, free = num(acc.totalAvailableBalance);
        let canTrade = true, canWithdraw = false;
        try {
          const k = await call(ctx, creds, 'GET', '/v5/user/query-api');
          const perms = (k && k.permissions) || {};
          canTrade = !Number(k && k.readOnly) && !!(perms.ContractTrade && perms.ContractTrade.length);
          canWithdraw = !!(perms.Wallet && perms.Wallet.indexOf('Withdraw') >= 0);
        } catch { /* ignore */ }
        return { balances: usdt || free > 0 ? [{ asset: 'USDT', free, locked: Math.max(0, wallet - free) }] : [], canTrade, canWithdraw };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const lv = String(Number(leverage));
        if (marginMode) await ignoring(() => call(ctx, creds, 'POST', '/v5/position/switch-isolated', null, { category: 'linear', symbol, tradeMode: marginMode === 'cross' ? 0 : 1, buyLeverage: lv, sellLeverage: lv }), 110026, 100028);
        return ignoring(() => call(ctx, creds, 'POST', '/v5/position/set-leverage', null, { category: 'linear', symbol, buyLeverage: lv, sellLeverage: lv }), 110043);
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Bybit حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol;
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const pl = await call(ctx, creds, 'GET', '/v5/position/list', { category: 'linear', symbol: sym });
        const hedge = (pl.list || []).some((x) => Number(x.positionIdx) === 1 || Number(x.positionIdx) === 2);
        const buy = o.side === 'buy';
        const body = { category: 'linear', symbol: sym, side: buy ? 'Buy' : 'Sell', orderType: o.type === 'limit' ? 'Limit' : 'Market', qty: o.qty, positionIdx: hedge ? ((buy !== !!o.reduceOnly) ? 1 : 2) : 0 };
        if (o.type === 'limit') { body.price = o.price; body.timeInForce = 'GTC'; }
        if (o.clientId) body.orderLinkId = o.clientId;
        let native = false;
        if (o.reduceOnly) body.reduceOnly = true;
        else {
          if (o.sl > 0) { body.stopLoss = tickStr(o.sl, o.market); body.slTriggerBy = 'MarkPrice'; body.slOrderType = 'Market'; native = true; }
          if (o.tp > 0) { body.takeProfit = tickStr(o.tp, o.market); body.tpTriggerBy = 'MarkPrice'; body.tpOrderType = 'Market'; native = true; }
          if (native) body.tpslMode = 'Full';
        }
        const r = await call(ctx, creds, 'POST', '/v5/order/create', null, body);
        return { orderId: String(r.orderId || ''), nativeProtection: native, raw: r };
      },
      async positions(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/v5/position/list', symbol ? { category: 'linear', symbol } : { category: 'linear', settleCoin: 'USDT', limit: 200 });
        return (r.list || []).filter((x) => num(x.size) > 0).map((x) => {
          const side = x.side === 'Sell' ? 'short' : 'long';
          return { positionId: `${x.symbol}|${side}`, symbol: x.symbol, side, qty: num(x.size), entry: num(x.avgPrice), leverage: num(x.leverage), margin: num(x.positionIM), pnl: num(x.unrealisedPnl), liqPrice: num(x.liqPrice) };
        });
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const r = await call(ctx, creds, 'GET', '/v5/position/list', { category: 'linear', symbol });
        const p = (r.list || []).find((x) => x.symbol === symbol && num(x.size) > 0 && (!side || (x.side === 'Sell' ? 'short' : 'long') === side));
        if (!p) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        const d = await call(ctx, creds, 'POST', '/v5/order/create', null, { category: 'linear', symbol, side: p.side === 'Sell' ? 'Buy' : 'Sell', orderType: 'Market', qty: String(p.size), reduceOnly: true, positionIdx: Number(p.positionIdx) || 0 });
        return { raw: d };
      },
      async openOrders(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/v5/order/realtime', symbol ? { category: 'linear', symbol } : { category: 'linear', settleCoin: 'USDT' });
        return (r.list || []).map((x) => ({ orderId: x.orderId, symbol: x.symbol, side: lc(x.side), type: lc(x.orderType), price: num(x.price), qty: num(x.qty), filled: num(x.cumExecQty), status: x.orderStatus }));
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/v5/order/cancel', null, { category: 'linear', symbol, orderId: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  return { binance: binance(), mexc: mexc(), bybit: bybit() };
};
