import { db } from './db.ts';
import {
  generateCode,
  getPaymentMode,
  getWebhookSecret,
  verifyWebhookSignature,
} from './security.ts';

export type PaymentMethod = 'upi' | 'gpay' | 'phonepe' | 'paytm' | 'card_netbanking' | 'wallet';

export interface WebhookEventBody {
  event: 'payment.captured' | 'payment.pending' | 'payment.failed';
  event_id?: string;
  payload: {
    payment: {
      entity: {
        id: string;
        order_id: string;
        amount: number;
        currency: string;
        method?: string;
        error_description?: string;
      };
    };
  };
}

export async function createGatewayOrderRecord(params: {
  amountPaise: number;
  receiptCode: string;
  notes: Record<string, string>;
}): Promise<{ gateway: 'upi_direct' | 'razorpay'; gatewayOrderId: string; keyId?: string }> {
  const mode = getPaymentMode();

  if (mode === 'razorpay') {
    const keyId = process.env.RAZORPAY_KEY_ID || '';
    const keySecret = process.env.RAZORPAY_KEY_SECRET || '';
    const authHeader = Buffer.from(`${keyId}:${keySecret}`).toString('base64');

    const response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${authHeader}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: params.amountPaise,
        currency: 'INR',
        receipt: params.receiptCode,
        notes: params.notes,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Razorpay order creation failed: ${errorText}`);
    }

    const data = (await response.json()) as { id: string };
    return {
      gateway: 'razorpay',
      gatewayOrderId: data.id,
      keyId,
    };
  }

  return {
    gateway: 'upi_direct',
    gatewayOrderId: `sb_ord_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
  };
}

export function processVerifiedWebhookEvent(
  rawBody: string | Buffer,
  signatureHeader: string,
  ipAddress: string,
): { ok: boolean; status: number; message: string; paymentCode?: string; paymentStatus?: string } {
  const webhookSecret = getWebhookSecret();
  const isValidSignature = verifyWebhookSignature(rawBody, signatureHeader, webhookSecret);

  if (!isValidSignature) {
    db.prepare(`
      INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, entity_type, entity_id, ip_address, metadata_json)
      VALUES ('webhook', NULL, 'gateway-webhook', 'webhook.signature_rejected', 'payment', 'unknown', ?, ?)
    `).run(ipAddress, JSON.stringify({ reason: 'invalid_hmac_signature' }));

    return { ok: false, status: 401, message: 'Invalid webhook signature.' };
  }

  let parsed: WebhookEventBody;
  try {
    const rawStr = typeof rawBody === 'string' ? rawBody : rawBody.toString('utf8');
    parsed = JSON.parse(rawStr) as WebhookEventBody;
  } catch {
    return { ok: false, status: 400, message: 'Malformed webhook JSON payload.' };
  }

  const eventType = parsed?.event;
  const entity = parsed?.payload?.payment?.entity;
  if (!eventType || !entity || !entity.order_id || !entity.id) {
    return { ok: false, status: 400, message: 'Missing required payment entity fields.' };
  }

  const paymentRow = db.prepare('SELECT * FROM payments WHERE gateway_order_id = ?').get(entity.order_id) as
    | {
        id: number;
        payment_code: string;
        order_id: number | null;
        user_id: number;
        purpose: 'order_payment' | 'wallet_topup';
        method: string;
        amount_paise: number;
        status: string;
      }
    | undefined;

  if (!paymentRow) {
    return { ok: false, status: 404, message: 'Payment record not found for gateway order.' };
  }

  if (entity.amount !== paymentRow.amount_paise) {
    db.prepare(`
      INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, entity_type, entity_id, ip_address, metadata_json)
      VALUES ('webhook', NULL, 'gateway-webhook', 'webhook.amount_mismatch', 'payment', ?, ?, ?)
    `).run(
      paymentRow.payment_code,
      ipAddress,
      JSON.stringify({ expected: paymentRow.amount_paise, received: entity.amount }),
    );
    return { ok: false, status: 400, message: 'Payment amount mismatch detected.' };
  }

  // Idempotency check if already captured or refunded
  if (paymentRow.status === 'captured' || paymentRow.status === 'refunded') {
    return {
      ok: true,
      status: 200,
      message: 'Payment already settled.',
      paymentCode: paymentRow.payment_code,
      paymentStatus: paymentRow.status,
    };
  }

  const eventId = parsed.event_id || `evt_${Date.now().toString(36)}`;

  const runAtomicUpdate = db.transaction(() => {
    if (eventType === 'payment.captured') {
      const receiptNumber = `RCPT-${paymentRow.payment_code.replace('SB-PAY-', '')}`;

      db.prepare(`
        UPDATE payments
        SET status = 'captured',
            gateway_payment_id = ?,
            webhook_verified = 1,
            webhook_event_id = ?,
            receipt_number = ?,
            failure_reason = NULL,
            verified_at = datetime('now'),
            updated_at = datetime('now')
        WHERE id = ?
      `).run(entity.id, eventId, receiptNumber, paymentRow.id);

      if (paymentRow.purpose === 'order_payment' && paymentRow.order_id) {
        const order = db
          .prepare('SELECT id, order_code FROM orders WHERE id = ?')
          .get(paymentRow.order_id) as { id: number; order_code: string } | undefined;

        db.prepare(`
          UPDATE orders
          SET payment_status = 'paid',
              status = 'queued',
              progress_percent = 15,
              notes = 'Payment verified via gateway webhook. Campaign queued.',
              updated_at = datetime('now')
          WHERE id = ?
        `).run(paymentRow.order_id);

        db.prepare(`
          INSERT INTO transactions (tx_code, user_id, order_id, payment_id, type, direction, amount_paise, status, description)
          VALUES (?, ?, ?, ?, 'order_payment', 'debit', ?, 'completed', ?)
        `).run(
          generateCode('SB-TX'),
          paymentRow.user_id,
          paymentRow.order_id,
          paymentRow.id,
          paymentRow.amount_paise,
          `Verified ${paymentRow.method.toUpperCase()} payment for ${order?.order_code || 'order'}`,
        );
      } else if (paymentRow.purpose === 'wallet_topup') {
        db.prepare(`
          UPDATE users
          SET wallet_balance_paise = wallet_balance_paise + ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(paymentRow.amount_paise, paymentRow.user_id);

        db.prepare(`
          INSERT INTO transactions (tx_code, user_id, order_id, payment_id, type, direction, amount_paise, status, description)
          VALUES (?, ?, NULL, ?, 'wallet_topup', 'credit', ?, 'completed', ?)
        `).run(
          generateCode('SB-TX'),
          paymentRow.user_id,
          paymentRow.id,
          paymentRow.amount_paise,
          `Wallet top-up verified via ${paymentRow.method.toUpperCase()}`,
        );
      }

      db.prepare(`
        INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, entity_type, entity_id, ip_address, metadata_json)
        VALUES ('webhook', paymentRow_uid, 'gateway-webhook', 'payment.captured', 'payment', ?, ?, ?)
      `.replace('paymentRow_uid', String(paymentRow.user_id))).run(
        paymentRow.payment_code,
        ipAddress,
        JSON.stringify({ gatewayPaymentId: entity.id, eventId, amountPaise: paymentRow.amount_paise }),
      );

      return 'captured';
    }

    if (eventType === 'payment.pending') {
      db.prepare(`
        UPDATE payments
        SET status = 'pending',
            gateway_payment_id = ?,
            webhook_verified = 1,
            webhook_event_id = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).run(entity.id, eventId, paymentRow.id);

      if (paymentRow.purpose === 'order_payment' && paymentRow.order_id) {
        db.prepare(`
          UPDATE orders
          SET payment_status = 'pending',
              notes = 'Awaiting bank / UPI confirmation via gateway webhook.',
              updated_at = datetime('now')
          WHERE id = ? AND payment_status != 'paid'
        `).run(paymentRow.order_id);
      }

      db.prepare(`
        INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, entity_type, entity_id, ip_address, metadata_json)
        VALUES ('webhook', ?, 'gateway-webhook', 'payment.pending', 'payment', ?, ?, ?)
      `).run(
        paymentRow.user_id,
        paymentRow.payment_code,
        ipAddress,
        JSON.stringify({ gatewayPaymentId: entity.id, eventId }),
      );

      return 'pending';
    }

    // payment.failed
    const failureReason = entity.error_description || 'Payment declined or expired at UPI/bank gateway.';
    db.prepare(`
      UPDATE payments
      SET status = 'failed',
          gateway_payment_id = ?,
          webhook_verified = 1,
          webhook_event_id = ?,
          failure_reason = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(entity.id, eventId, failureReason, paymentRow.id);

    if (paymentRow.purpose === 'order_payment' && paymentRow.order_id) {
      db.prepare(`
        UPDATE orders
        SET payment_status = 'failed',
            status = 'payment_failed',
            notes = ?,
            updated_at = datetime('now')
        WHERE id = ? AND payment_status != 'paid'
      `).run(failureReason, paymentRow.order_id);
    }

    db.prepare(`
      INSERT INTO transactions (tx_code, user_id, order_id, payment_id, type, direction, amount_paise, status, description)
      VALUES (?, ?, ?, ?, ?, 'debit', ?, 'failed', ?)
    `).run(
      generateCode('SB-TX'),
      paymentRow.user_id,
      paymentRow.order_id,
      paymentRow.id,
      paymentRow.purpose === 'wallet_topup' ? 'wallet_topup' : 'order_payment',
      paymentRow.amount_paise,
      `Failed ${paymentRow.method.toUpperCase()} payment: ${failureReason}`,
    );

    db.prepare(`
      INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, entity_type, entity_id, ip_address, metadata_json)
      VALUES ('webhook', ?, 'gateway-webhook', 'payment.failed', 'payment', ?, ?, ?)
    `).run(
      paymentRow.user_id,
      paymentRow.payment_code,
      ipAddress,
      JSON.stringify({ gatewayPaymentId: entity.id, eventId, failureReason }),
    );

    return 'failed';
  });

  const finalStatus = runAtomicUpdate();
  return {
    ok: true,
    status: 200,
    message: `Webhook verified and payment marked ${finalStatus}.`,
    paymentCode: paymentRow.payment_code,
    paymentStatus: finalStatus,
  };
}
