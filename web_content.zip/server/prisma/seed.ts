import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const grade = await prisma.grade.upsert({
    where: { number: 9 },
    update: {},
    create: { number: 9, titleEn: "Grade 9", titleOm: "Kutaa 9" }
  });
  const subject = await prisma.subject.upsert({
    where: { gradeId_nameEn: { gradeId: grade.id, nameEn: "Biology" } },
    update: {},
    create: { gradeId: grade.id, nameEn: "Biology", nameOm: "Baayoloojii" }
  });
  await prisma.chapter.createMany({
    data: [{ titleEn: "Introduction to Biology", titleOm: "Seensa Baayoloojii", subjectId: subject.id, order: 1 }],
    skipDuplicates: true
  });
  console.log("Seeded starter curriculum. Add lessons and questions from the admin workflow or Prisma.");
}
main().finally(() => prisma.$disconnect());
