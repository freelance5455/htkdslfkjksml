'use strict';
/* تست سرتاسری «صرافی من»: موتور معامله‌ی داخل برنامه (همان باندل داخل HTML) + مدیر مسیر TX
 * با یک Binance Futures شبیه‌سازی‌شده؛ امضای HMAC واقعاً راستی‌آزمایی می‌شود.
 * سناریوها: اینترنت/VPN باز، صرافی بلاک (۴۵۱) با عبور از ریلی سرور، قطع کامل. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const nodeCrypto = require('node:crypto');

const HTML = fs.readFileSync(path.join(__dirname, '..', '..', 'trad-yar-myket-fixed.html'), 'utf8');
const scripts = [...HTML.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
const BUNDLE = scripts.find((s) => s.includes('globalThis.TXL='));
assert.ok(BUNDLE, 'bundle not found');
const TX_SRC = HTML.slice(HTML.indexOf('const TX=(function(){'), HTML.indexOf('function renderExchangePage()'));

const SRV = 'https://srv.example.com';
const SECRET = 'sekret', KEY = 'apikey123';
const R = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });

function klines(n = 300) { const out = []; let p = 60000, t = Date.now() - n * 3600e3; for (let i = 0; i < n; i++) { const o = p, c = p + Math.sin(i / 7) * 120 + 5; out.push([t, String(o), String(Math.max(o, c) + 30), String(Math.min(o, c) - 30), String(c), '120.5', t + 3599999, '7000000', 100, '60', '3000000', '0']); p = c; t += 3600e3; } return out; }

function binanceMock(state) {
  return (u, init) => {
    const q = Object.fromEntries(u.searchParams);
    const p = u.pathname, m = (init && init.method) || 'GET';
    const signedCheck = () => {
      const hd = Object.assign({}, init.headers); const key = hd['X-MBX-APIKEY'] || hd['x-mbx-apikey'];
      if (key !== KEY) return R({ code: -2015, msg: 'Invalid API-key, IP, or permissions for action' }, 401);
      const raw = u.search.slice(1); const i = raw.lastIndexOf('&signature='); const payload = raw.slice(0, i), sig = raw.slice(i + 11);
      const exp = nodeCrypto.createHmac('sha256', SECRET).update(payload).digest('hex');
      if (sig !== exp) return R({ code: -1022, msg: 'Signature for this request is not valid.' }, 400);
      return null;
    };
    if (p === '/fapi/v1/ping') return R({});
    if (p === '/fapi/v1/exchangeInfo') return R({ symbols: [{ symbol: 'BTCUSDT', baseAsset: 'BTC', quoteAsset: 'USDT', contractType: 'PERPETUAL', status: 'TRADING', filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.10' }, { filterType: 'LOT_SIZE', stepSize: '0.001', minQty: '0.001' }, { filterType: 'MIN_NOTIONAL', notional: '5' }] }, { symbol: 'DOGEUSDT', baseAsset: 'DOGE', quoteAsset: 'USDT', contractType: 'PERPETUAL', status: 'TRADING', filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.00001' }, { filterType: 'LOT_SIZE', stepSize: '1', minQty: '1' }, { filterType: 'MIN_NOTIONAL', notional: '5' }] }] });
    if (p === '/fapi/v1/ticker/24hr') return R([{ symbol: 'BTCUSDT', lastPrice: '60000.0', priceChangePercent: '1.5', quoteVolume: '9000000000', highPrice: '61000', lowPrice: '59000' }, { symbol: 'DOGEUSDT', lastPrice: '0.15', priceChangePercent: '-2', quoteVolume: '500000000', highPrice: '0.16', lowPrice: '0.14' }]);
    if (p === '/fapi/v1/klines') return R(klines(Number(q.limit) || 300));
    const bad = signedCheck(); if (bad) return bad;
    state.signedCalls.push(m + ' ' + p + ' ' + JSON.stringify(q));
    if (p === '/fapi/v2/account') return R({ canTrade: true, canWithdraw: false, assets: [{ asset: 'USDT', walletBalance: '1000', availableBalance: '900' }] });
    if (p === '/fapi/v1/positionSide/dual') return R({ dualSidePosition: false });
    if (p === '/fapi/v1/leverage' || p === '/fapi/v1/marginType') return R({ code: 200 });
    if (p === '/fapi/v1/order') return R({ orderId: 424242, status: 'NEW' });
    if (p === '/fapi/v1/algoOrder') return R({ algoId: 1 });
    return R({ code: -1000, msg: 'unknown ' + p }, 404);
  };
}

function boot(scn) {
  const state = { signedCalls: [], relayed: [], thirdParty: [], direct: 0 };
  const ls = new Map();
  const ctx = { console, setTimeout, clearTimeout, setInterval: () => 0, clearInterval() {}, Promise, AbortController, AbortSignal, URL, URLSearchParams, Request, Response, Headers, TextEncoder, TextDecoder, btoa, atob, Uint8Array, JSON, Date, Math, Set, Map, Array, Object, String, Number, Error, isFinite, parseInt, parseFloat, RegExp, Symbol, Reflect };
  ctx.globalThis = ctx; ctx.window = ctx; ctx.self = ctx;
  ctx.document = { hidden: false, addEventListener() {}, activeElement: null, getElementById: () => null };
  ctx.navigator = {}; ctx.crypto = {}; ctx.addEventListener = () => {}; ctx.removeEventListener = () => {};
  ctx.localStorage = { getItem: (k) => (ls.has(k) ? ls.get(k) : null), setItem: (k, v) => ls.set(k, String(v)), removeItem: (k) => ls.delete(k) };
  ctx.sessionStorage = { getItem: () => null, setItem() {}, removeItem() {} };
  ctx.getServerEndpoints = () => [SRV]; ctx.toast = () => {}; ctx.VIEW = 'prices'; ctx.USER = { id: 'u1', role: 'admin' }; ctx.DB = { get: () => ({}) }; ctx.indexedDB = {};
  const bx = binanceMock(state);
  ctx.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    if (init.signal && init.signal.aborted) throw new TypeError('aborted');
    if (u.host === 'srv.example.com') {
      if (u.pathname === '/relay') {
        if (!scn.relay) throw new TypeError('Failed to fetch');
        const target = new URL(u.searchParams.get('u')); state.relayed.push(target.pathname);
        return bx(target, init);
      }
      if (u.pathname.endsWith('/health')) return scn.server ? R({ ok: true, trade: true, version: '1.1.0', exchanges: 10 }) : (() => { throw new TypeError('Failed to fetch'); })();
      if (u.pathname.endsWith('/egress')) return R({ ok: true, ip: null });
      throw new TypeError('Failed to fetch');
    }
    if (/corsproxy|allorigins|codetabs/.test(u.host)) { state.thirdParty.push(String(url)); throw new TypeError('blocked'); }
    if (u.host === 'api.ipify.org') { if (scn.open) return R({ ip: '203.0.113.7' }); throw new TypeError('Failed to fetch'); }
    if (u.host === 'fapi.binance.com') {
      if (scn.geo) return new Response('<html>Service unavailable from a restricted location</html>', { status: 451 });
      if (!scn.open) throw new TypeError('Failed to fetch');
      state.direct++; return bx(u, init);
    }
    throw new TypeError('Failed to fetch ' + u.host);
  };
  vm.createContext(ctx);
  vm.runInContext(BUNDLE, ctx);
  vm.runInContext(TX_SRC + '\n;globalThis.__TX=TX;', ctx);
  return { TX: ctx.__TX._net, state, ctx };
}
const CR = { apiKey: KEY, apiSecret: SECRET };

test('E2E با اینترنت/VPN باز: بازار، تیکر، کندل، موجودی، سفارش با حد ضرر/سود (امضای HMAC درست)', async () => {
  const { TX, state } = boot({ open: true, server: false });
  const ex = await TX.api('exchanges', {}).catch(() => null); void ex;
  const mk = await TX.api('markets', { exchange: 'binance' });
  assert.equal(mk.markets.length, 2); assert.equal(mk.markets[0].symbol, 'BTCUSDT');
  const tk = await TX.api('tickers', { exchange: 'binance' });
  assert.equal(tk.tickers[0].last, 60000);
  const kl = await TX.api('klines', { exchange: 'binance', symbol: 'BTCUSDT', interval: '1h', limit: 250 });
  assert.equal(kl.klines.length, 250); assert.equal(kl.klines[0].length, 6);
  const v = await TX.api('verify', { exchange: 'binance', creds: CR });
  assert.equal(v.balances[0].asset, 'USDT'); assert.equal(v.balances[0].free, 900);
  const o = await TX.api('order', { exchange: 'binance', creds: CR, order: { symbol: 'BTCUSDT', side: 'buy', type: 'market', qty: 0.002, sl: 59000, tp: 62000, leverage: 3, marginMode: 'isolated', clientId: 'ty1' } });
  assert.equal(o.ok, true); assert.equal(o.orderId, '424242'); assert.equal(o.protection.native, true);
  const orderCall = state.signedCalls.find((c) => c.startsWith('POST /fapi/v1/order '));
  assert.ok(orderCall, 'order sent'); const q = JSON.parse(orderCall.slice(orderCall.indexOf('{')));
  assert.equal(q.side, 'BUY'); assert.equal(q.type, 'MARKET'); assert.equal(q.symbol, 'BTCUSDT');
  assert.equal(Number(q.quantity), 0.002);
  assert.ok(state.signedCalls.some((c) => c.includes('/fapi/v1/leverage')) && state.signedCalls.some((c) => c.includes('/fapi/v1/marginType')));
  assert.equal(state.signedCalls.filter((c) => c.includes('/fapi/v1/algoOrder')).length, 2, 'SL + TP');
  assert.equal(state.thirdParty.length, 0);
});

test('E2E کلید/امضای اشتباه: خطای واضح، نه کرش', async () => {
  const { TX } = boot({ open: true, server: false });
  await assert.rejects(() => TX.api('verify', { exchange: 'binance', creds: { apiKey: 'wrong', apiSecret: SECRET } }), (e) => /Invalid API-key/.test(e.message));
});

test('E2E سفارش با حجم/مبلغ زیر حداقل صرافی: قبل از ارسال رد می‌شود', async () => {
  const { TX, state } = boot({ open: true, server: false });
  await assert.rejects(() => TX.api('order', { exchange: 'binance', creds: CR, order: { symbol: 'BTCUSDT', side: 'buy', type: 'market', qty: 0.00001 } }));
  assert.equal(state.signedCalls.filter((c) => c.includes('POST /fapi/v1/order ')).length, 0);
});

test('E2E مستقیم بلاک (۴۵۱) ولی سرورِ ریلی باز: همه‌چیز از ریلی رد می‌شود، سفارش یک‌بار ثبت', async () => {
  const { TX, state } = boot({ open: false, geo: true, server: true, relay: true });
  const mk = await TX.api('markets', { exchange: 'binance' });
  assert.equal(mk.markets.length, 2);
  const o = await TX.api('order', { exchange: 'binance', creds: CR, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', qty: 130, clientId: 'ty2' } });
  assert.equal(o.orderId, '424242');
  assert.equal(state.signedCalls.filter((c) => c.startsWith('POST /fapi/v1/order ')).length, 1);
  assert.ok(state.relayed.includes('/fapi/v1/exchangeInfo'));
});

test('E2E قطع کامل (بدون VPN، بدون سرور): خطای اتصال با پیام فارسی قابل‌فهم', async () => {
  const { TX } = boot({ open: false, server: false, relay: false });
  await assert.rejects(() => TX.api('markets', { exchange: 'binance' }), (e) => e.code === 'network' && /اتصال/.test(e.message));
});

test('E2E درخواست امضاشده هرگز به پروکسی عمومی شخص ثالث نمی‌رود', async () => {
  const { TX, state } = boot({ open: false, geo: false, server: false, relay: false });
  await TX.api('verify', { exchange: 'binance', creds: CR }).catch(() => {});
  assert.equal(state.thirdParty.length, 0);
});

test('E2E وسط کار VPN روشن می‌شود: بدون بستن برنامه از حالت قطع به حالت مستقیم می‌رود', async () => {
  const scn = { open: false, server: false, relay: false };
  const { TX } = boot(scn);
  await assert.rejects(() => TX.api('markets', { exchange: 'binance' }));
  scn.open = true;
  await TX.onNetChange();
  const mk = await TX.api('markets', { exchange: 'binance' });
  assert.equal(mk.markets.length, 2);
});
