'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const build = require('../futures-a.js');

/* helpers copied from exchanges.js (that file exports none of them under these names) */
class ExchangeError extends Error {
  constructor(message, { code, status, raw } = {}) { super(message); this.name = 'ExchangeError'; this.exCode = code; this.exStatus = status; this.raw = raw; }
}
const hmac = (algo, secret, msg, enc = 'hex') => crypto.createHmac(algo, secret).update(msg).digest(enc);
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const sha512 = (s) => crypto.createHash('sha512').update(s).digest('hex');
const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };
const rnd = (len = 32) => crypto.randomBytes(len).toString('hex').slice(0, len);
const cleanObj = (o) => { const r = {}; for (const k of Object.keys(o || {})) if (o[k] !== undefined && o[k] !== null && o[k] !== '') r[k] = o[k]; return r; };
const qs = (o) => Object.entries(cleanObj(o)).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
const qsRaw = (o) => Object.entries(cleanObj(o)).map(([k, v]) => `${k}=${v}`).join('&');
const sortedKeys = (o) => Object.keys(cleanObj(o)).sort();
function decimalsOf(step) {
  const n = Number(step);
  if (!(n > 0)) return 8;
  const s = String(n);
  if (s.includes('e-')) { const [m, e] = s.split('e-'); return parseInt(e, 10) + ((m.split('.')[1] || '').length); }
  const i = s.indexOf('.');
  return i < 0 ? 0 : s.length - i - 1;
}
const stepFromDecimals = (d) => (Number.isInteger(+d) && +d >= 0 ? Number((10 ** -d).toFixed(Math.min(+d, 20))) : 0);
function floorToStep(value, step) {
  const v = Number(value);
  if (!(v > 0)) return '0';
  if (!(step > 0)) return String(v);
  const d = decimalsOf(step);
  const units = Math.floor(v / step + 1e-9);
  return (units * step).toFixed(Math.min(d, 20));
}
const STABLES = new Set(['USDT', 'USDC']);
const normInterval = (iv) => (['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'].includes(iv) ? iv : '1h');
const IV_SEC = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800 };
function mkMarket(o) {
  const m = { symbol: o.symbol, base: String(o.base || '').toUpperCase(), quote: String(o.quote || '').toUpperCase(), tickSize: num(o.tickSize), stepSize: num(o.stepSize), minQty: num(o.minQty), minNotional: num(o.minNotional), trading: o.trading !== false, type: o.type || 'spot' };
  if (o.maxLeverage) m.maxLeverage = num(o.maxLeverage);
  return m;
}
const need = (creds, ...fields) => { for (const f of fields) if (!creds || !creds[f]) throw new ExchangeError('missing ' + f, { code: 'missing_' + f }); };
const bad = (msg, code, raw) => new ExchangeError(msg, { code, raw });
const H = { ExchangeError, hmac, sha256, sha512, md5, num, rnd, cleanObj, qs, qsRaw, sortedKeys, decimalsOf, stepFromDecimals, floorToStep, mkMarket, normInterval, IV_SEC, STABLES, need, bad };
const { binance, mexc, bybit } = build(H);

const CREDS = { apiKey: 'KEY', apiSecret: 'SEC' };
const NOW = 1700000000000;

/* mock ctx: routes = [[matcher(fn(method,url)) , reply|fn]] ; records calls */
function mkCtx(routes) {
  const calls = [];
  const ctx = {
    now: () => NOW,
    async http(method, url, opts = {}) {
      const u = new URL(url);
      const c = { method, url: u, path: u.pathname, headers: opts.headers || {}, body: opts.body, json: opts.body ? JSON.parse(opts.body) : undefined };
      calls.push(c);
      for (const [m, reply] of routes) {
        if (m(c)) { const r = typeof reply === 'function' ? reply(c) : reply; return { status: 200, json: r, text: JSON.stringify(r) }; }
      }
      return { status: 404, json: { code: -1, msg: 'unmatched ' + method + ' ' + u.pathname }, text: '' };
    },
  };
  ctx.calls = calls;
  return ctx;
}
const p = (path, method) => (c) => c.path === path && (!method || c.method === method);

/* ============================== Binance ============================== */

test('binance: markets parse, USDT perps only', async () => {
  const ctx = mkCtx([[p('/fapi/v1/exchangeInfo'), { symbols: [
    { symbol: 'BTCUSDT', contractType: 'PERPETUAL', quoteAsset: 'USDT', baseAsset: 'BTC', status: 'TRADING', filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.10' }, { filterType: 'LOT_SIZE', stepSize: '0.001', minQty: '0.001' }, { filterType: 'MIN_NOTIONAL', notional: '100' }] },
    { symbol: 'BTCUSDT_241227', contractType: 'CURRENT_QUARTER', quoteAsset: 'USDT', baseAsset: 'BTC', status: 'TRADING', filters: [] },
    { symbol: 'ETHUSDC', contractType: 'PERPETUAL', quoteAsset: 'USDC', baseAsset: 'ETH', status: 'TRADING', filters: [] },
    { symbol: 'OLDUSDT', contractType: 'PERPETUAL', quoteAsset: 'USDT', baseAsset: 'OLD', status: 'SETTLING', filters: [] },
  ] }]]);
  const m = await binance.markets(ctx);
  assert.equal(m.length, 2);
  assert.deepEqual(m[0], { symbol: 'BTCUSDT', base: 'BTC', quote: 'USDT', tickSize: 0.1, stepSize: 0.001, minQty: 0.001, minNotional: 100, trading: true, type: 'futures' });
  assert.equal(m[1].trading, false);
  assert.equal(ctx.calls[0].url.host, 'fapi.binance.com');
});

test('binance: signed request has header + valid signature', async () => {
  const ctx = mkCtx([[p('/fapi/v2/account'), { canTrade: true, canWithdraw: false, assets: [{ asset: 'USDT', walletBalance: '100', availableBalance: '60' }, { asset: 'BNB', walletBalance: '0', availableBalance: '0' }] }]]);
  const b = await binance.balance(ctx, CREDS);
  assert.deepEqual(b, { balances: [{ asset: 'USDT', free: 60, locked: 40 }], canTrade: true, canWithdraw: false });
  const c = ctx.calls[0];
  assert.equal(c.headers['X-MBX-APIKEY'], 'KEY');
  const raw = c.url.search.slice(1);
  const idx = raw.lastIndexOf('&signature=');
  assert.equal(raw.slice(idx + 11), hmac('sha256', 'SEC', raw.slice(0, idx)));
  assert.equal(c.url.searchParams.get('timestamp'), String(NOW));
});

test('binance: market order one-way with SL/TP via algo orders', async () => {
  const ctx = mkCtx([
    [p('/fapi/v1/positionSide/dual'), { dualSidePosition: false }],
    [p('/fapi/v1/marginType'), { code: -4046, msg: 'No need to change margin type.' }],
    [p('/fapi/v1/leverage'), { symbol: 'BTCUSDT', leverage: 10 }],
    [p('/fapi/v1/order', 'POST'), { orderId: 12345, status: 'FILLED' }],
    [p('/fapi/v1/algoOrder', 'POST'), { algoId: 1 }],
  ]);
  const mk = (await binance.markets(mkCtx([[p('/fapi/v1/exchangeInfo'), { symbols: [{ symbol: 'BTCUSDT', contractType: 'PERPETUAL', quoteAsset: 'USDT', baseAsset: 'BTC', status: 'TRADING', filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.10' }] }] }]])))[0];
  const r = await binance.placeOrder(ctx, CREDS, { market: mk, side: 'buy', type: 'market', qty: '0.015', sl: 29000.55, tp: 32000, leverage: 10, marginMode: 'isolated', clientId: 'abc' });
  assert.equal(r.orderId, '12345');
  assert.equal(r.nativeProtection, true);
  const order = ctx.calls.find((c) => c.path === '/fapi/v1/order');
  const q = order.url.searchParams;
  assert.equal(q.get('quantity'), '0.015'); assert.equal(q.get('side'), 'BUY'); assert.equal(q.get('type'), 'MARKET'); assert.equal(q.get('newClientOrderId'), 'abc');
  assert.equal(q.get('reduceOnly'), null); assert.equal(q.get('positionSide'), null);
  assert.equal(ctx.calls.find((c) => c.path === '/fapi/v1/marginType').url.searchParams.get('marginType'), 'ISOLATED');
  const algos = ctx.calls.filter((c) => c.path === '/fapi/v1/algoOrder');
  assert.equal(algos.length, 2);
  const sl = algos[0].url.searchParams, tp = algos[1].url.searchParams;
  assert.equal(sl.get('type'), 'STOP_MARKET'); assert.equal(sl.get('side'), 'SELL'); assert.equal(sl.get('triggerPrice'), '29000.5'); assert.equal(sl.get('closePosition'), 'true'); assert.equal(sl.get('algoType'), 'CONDITIONAL');
  assert.equal(tp.get('type'), 'TAKE_PROFIT_MARKET'); assert.equal(tp.get('triggerPrice'), '32000.0');
});

test('binance: hedge mode sends positionSide, reduceOnly omitted; test uses /order/test', async () => {
  const ctx = mkCtx([
    [p('/fapi/v1/positionSide/dual'), { dualSidePosition: true }],
    [p('/fapi/v1/order/test'), {}],
    [p('/fapi/v1/order', 'POST'), { orderId: 7 }],
  ]);
  const mk = { symbol: 'BTCUSDT', tickSize: 0.1 };
  await binance.placeOrder(ctx, CREDS, { market: mk, side: 'sell', type: 'market', qty: '0.01', reduceOnly: true });
  const q = ctx.calls.find((c) => c.path === '/fapi/v1/order').url.searchParams;
  assert.equal(q.get('positionSide'), 'LONG'); assert.equal(q.get('reduceOnly'), null);
  const t = await binance.placeOrder(ctx, CREDS, { market: mk, side: 'buy', type: 'limit', price: '100', qty: '0.01', test: true });
  assert.equal(t.nativeProtection, false);
  assert.ok(ctx.calls.some((c) => c.path === '/fapi/v1/order/test'));
});

test('binance: limit order has no SL/TP attempt; leverage error respects ignoreLeverageError', async () => {
  const ctx = mkCtx([
    [p('/fapi/v1/positionSide/dual'), { dualSidePosition: false }],
    [p('/fapi/v1/leverage'), { code: -4028, msg: 'Leverage 500 is not valid' }],
    [p('/fapi/v1/order', 'POST'), { orderId: 9 }],
  ]);
  const mk = { symbol: 'BTCUSDT', tickSize: 0.1 };
  const o = { market: mk, side: 'buy', type: 'limit', price: '100.0', qty: '1', sl: 90, leverage: 500 };
  await assert.rejects(() => binance.placeOrder(ctx, CREDS, o), (e) => e instanceof ExchangeError && e.exCode === -4028);
  const r = await binance.placeOrder(ctx, CREDS, { ...o, ignoreLeverageError: true });
  assert.equal(r.nativeProtection, false);
  assert.equal(ctx.calls.filter((c) => c.path === '/fapi/v1/algoOrder').length, 0);
  assert.equal(ctx.calls.find((c) => c.path === '/fapi/v1/order').url.searchParams.get('price'), '100.0');
});

test('binance: positions parse and closePosition reduce-only', async () => {
  const ctx = mkCtx([
    [p('/fapi/v2/positionRisk'), [
      { symbol: 'BTCUSDT', positionAmt: '-0.020', entryPrice: '30000', leverage: '10', marginType: 'isolated', isolatedMargin: '61.5', unRealizedProfit: '-3.2', liquidationPrice: '32500', positionSide: 'BOTH', notional: '-610' },
      { symbol: 'ETHUSDT', positionAmt: '0', entryPrice: '0', leverage: '10', marginType: 'cross', positionSide: 'BOTH' },
      { symbol: 'SOLUSDT', positionAmt: '5', entryPrice: '20', leverage: '5', marginType: 'cross', unRealizedProfit: '1', liquidationPrice: '0', positionSide: 'BOTH', notional: '100' },
    ]],
    [p('/fapi/v1/positionSide/dual'), { dualSidePosition: false }],
    [p('/fapi/v1/order', 'POST'), { orderId: 5 }],
  ]);
  const ps = await binance.positions(ctx, CREDS);
  assert.equal(ps.length, 2);
  assert.deepEqual(ps[0], { positionId: 'BTCUSDT|short', symbol: 'BTCUSDT', side: 'short', qty: 0.02, entry: 30000, leverage: 10, margin: 61.5, pnl: -3.2, liqPrice: 32500 });
  assert.equal(ps[1].side, 'long'); assert.equal(ps[1].margin, 20);
  await binance.closePosition(ctx, CREDS, 'BTCUSDT|short');
  const q = ctx.calls.find((c) => c.path === '/fapi/v1/order').url.searchParams;
  assert.equal(q.get('side'), 'BUY'); assert.equal(q.get('quantity'), '0.02'); assert.equal(q.get('reduceOnly'), 'true');
});

test('binance: error wrapping and algo cancel', async () => {
  const ctx = mkCtx([[p('/fapi/v1/algoOrder', 'DELETE'), { algoId: 3 }], [p('/fapi/v2/account'), { code: -2015, msg: 'Invalid API-key' }]]);
  await assert.rejects(() => binance.balance(ctx, CREDS), (e) => e.exCode === -2015 && /Invalid API-key/.test(e.message));
  await binance.cancelOrder(ctx, CREDS, 'BTCUSDT', 'algo:3');
  assert.equal(ctx.calls.at(-1).url.searchParams.get('algoId'), '3');
  await assert.rejects(() => binance.balance(ctx, {}), (e) => e.exCode === 'missing_apiKey');
});

/* ============================== MEXC ============================== */

const MEXC_DETAIL = { success: true, code: 0, data: [
  { symbol: 'BTC_USDT', baseCoin: 'BTC', quoteCoin: 'USDT', settleCoin: 'USDT', contractSize: 0.0001, volUnit: 1, minVol: 1, priceUnit: 0.5, maxLeverage: 200, state: 0, apiAllowed: true },
  { symbol: 'BTC_USD', baseCoin: 'BTC', quoteCoin: 'USD', settleCoin: 'BTC', contractSize: 100, volUnit: 1, minVol: 1, priceUnit: 0.5, maxLeverage: 100, state: 0 },
  { symbol: 'XYZ_USDT', baseCoin: 'XYZ', quoteCoin: 'USDT', settleCoin: 'USDT', contractSize: 10, volUnit: 1, minVol: 1, priceUnit: 0.001, maxLeverage: 50, state: 1 },
] };

test('mexc: markets convert contracts to base units', async () => {
  const ctx = mkCtx([[p('/api/v1/contract/detail'), MEXC_DETAIL]]);
  const m = await mexc.markets(ctx);
  assert.equal(m.length, 2);
  assert.deepEqual(m[0], { symbol: 'BTC_USDT', base: 'BTC', quote: 'USDT', tickSize: 0.5, stepSize: 0.0001, minQty: 0.0001, minNotional: 0, trading: true, type: 'futures', maxLeverage: 200 });
  assert.equal(m[1].trading, false); assert.equal(m[1].stepSize, 10);
});

test('mexc: tickers and klines (base volume, ascending)', async () => {
  const ctx = mkCtx([
    [p('/api/v1/contract/ticker'), { success: true, code: 0, data: [{ symbol: 'BTC_USDT', lastPrice: 30000, riseFallRate: 0.0123, amount24: 5e8, high24Price: 31000, lower24Price: 29000 }] }],
    [(c) => c.path.startsWith('/api/v1/contract/kline/BTC_USDT'), { success: true, code: 0, data: { time: [1700000060, 1700000000], open: [2, 1], high: [3, 2], low: [1, 0.5], close: [2.5, 1.5], vol: [100, 50] } }],
    [p('/api/v1/contract/detail'), { success: true, code: 0, data: MEXC_DETAIL.data[0] }],
  ]);
  const t = await mexc.tickers(ctx);
  assert.equal(t[0].changePct, 1.23); assert.equal(t[0].quoteVol, 5e8);
  const k = await mexc.klines(ctx, 'BTC_USDT', '1m', 10);
  assert.deepEqual(k[0], [1700000000000, 1, 2, 0.5, 1.5, 0.005]);
  assert.equal(k[1][0], 1700000060000);
  const kc = ctx.calls.find((c) => c.path.includes('/kline/'));
  assert.equal(kc.url.searchParams.get('interval'), 'Min1');
});

test('mexc: signing on GET and POST, SL/TP + base->contract conversion', async () => {
  const ctx = mkCtx([
    [p('/api/v1/contract/detail'), { success: true, code: 0, data: MEXC_DETAIL.data[0] }],
    [p('/api/v1/private/position/change_leverage'), { success: true, code: 0, data: {} }],
    [p('/api/v1/private/position/position_mode'), { success: true, code: 0, data: 2 }],
    [p('/api/v1/private/order/submit'), { success: true, code: 0, data: { orderId: '777', ts: 1 } }],
  ]);
  const mk = { symbol: 'BTC_USDT', tickSize: 0.5 };
  const r = await mexc.placeOrder(ctx, CREDS, { market: mk, side: 'buy', type: 'market', qty: '0.0030', sl: 29000.7, tp: 32000, leverage: 20, marginMode: 'isolated', clientId: 'cid1' });
  assert.equal(r.orderId, '777'); assert.equal(r.nativeProtection, true);
  const c = ctx.calls.find((x) => x.path === '/api/v1/private/order/submit');
  assert.equal(c.json.vol, '30'); // 0.003 BTC / 0.0001 per contract
  assert.equal(c.json.side, 1); assert.equal(c.json.type, 5); assert.equal(c.json.openType, 1); assert.equal(c.json.leverage, 20);
  assert.equal(c.json.stopLossPrice, '29000.5'); assert.equal(c.json.takeProfitPrice, '32000.0'); assert.equal(c.json.externalOid, 'cid1');
  assert.equal(c.headers.ApiKey, 'KEY'); assert.equal(c.headers['Request-Time'], String(NOW));
  assert.equal(c.headers.Signature, hmac('sha256', 'SEC', 'KEY' + NOW + c.body));
  const g = ctx.calls.find((x) => x.path === '/api/v1/private/position/position_mode');
  assert.equal(g.headers.Signature, hmac('sha256', 'SEC', 'KEY' + NOW)); // empty param string
});

test('mexc: reduceOnly sides, GET signature with sorted query, cross mode', async () => {
  const ctx = mkCtx([
    [p('/api/v1/contract/detail'), { success: true, code: 0, data: MEXC_DETAIL.data[0] }],
    [p('/api/v1/private/position/position_mode'), { success: true, code: 0, data: 2 }],
    [p('/api/v1/private/order/submit'), { success: true, code: 0, data: '55' }],
    [(c) => c.path.startsWith('/api/v1/private/order/list/open_orders'), { success: true, code: 0, data: [{ orderId: '9', symbol: 'BTC_USDT', side: 3, orderType: 1, price: 31000, vol: 10, dealVol: 2, state: 2 }] }],
  ]);
  const r = await mexc.placeOrder(ctx, CREDS, { market: { symbol: 'BTC_USDT', tickSize: 0.5 }, side: 'sell', type: 'limit', price: '31000', qty: '0.001', reduceOnly: true, sl: 1, marginMode: 'cross' });
  assert.equal(r.orderId, '55'); assert.equal(r.nativeProtection, false);
  const c = ctx.calls.find((x) => x.path === '/api/v1/private/order/submit').json;
  assert.equal(c.side, 4); assert.equal(c.reduceOnly, true); assert.equal(c.vol, '10'); assert.equal(c.type, 1); assert.equal(c.price, '31000.0'); assert.equal(c.openType, 2); assert.equal(c.stopLossPrice, undefined);
  const oo = await mexc.openOrders(ctx, CREDS, 'BTC_USDT');
  assert.deepEqual(oo, [{ orderId: '9', symbol: 'BTC_USDT', side: 'sell', type: 'limit', price: 31000, qty: 0.001, filled: 0.0002, status: 2 }]);
  const g = ctx.calls.find((x) => x.path.startsWith('/api/v1/private/order/list'));
  assert.equal(g.url.search, '?page_num=1&page_size=100');
  assert.equal(g.headers.Signature, hmac('sha256', 'SEC', 'KEY' + NOW + 'page_num=1&page_size=100'));
});

test('mexc: positions parse (base qty, pnl from fair price) and closePosition, test unsupported', async () => {
  const ctx = mkCtx([
    [p('/api/v1/contract/detail'), { success: true, code: 0, data: MEXC_DETAIL.data[0] }],
    [p('/api/v1/private/position/open_positions'), { success: true, code: 0, data: [
      { positionId: 4242, symbol: 'BTC_USDT', positionType: 2, holdVol: 50, holdAvgPrice: 30000, leverage: 10, im: 15, liquidatePrice: 33000 },
      { positionId: 1, symbol: 'BTC_USDT', positionType: 1, holdVol: 0 },
    ] }],
    [(c) => c.path === '/api/v1/contract/ticker', { success: true, code: 0, data: { symbol: 'BTC_USDT', fairPrice: 29900, lastPrice: 29901 } }],
    [p('/api/v1/private/position/position_mode'), { success: true, code: 0, data: 1 }],
    [p('/api/v1/private/order/submit'), { success: true, code: 0, data: { orderId: '8' } }],
  ]);
  const ps = await mexc.positions(ctx, CREDS);
  assert.equal(ps.length, 1);
  assert.equal(ps[0].positionId, '4242'); assert.equal(ps[0].side, 'short'); assert.ok(Math.abs(ps[0].qty - 0.005) < 1e-12);
  assert.ok(Math.abs(ps[0].pnl - 0.5) < 1e-9); assert.equal(ps[0].margin, 15); assert.equal(ps[0].liqPrice, 33000);
  await mexc.closePosition(ctx, CREDS, '4242');
  const b = ctx.calls.find((x) => x.path === '/api/v1/private/order/submit').json;
  assert.equal(b.side, 2); assert.equal(b.vol, '50'); assert.equal(b.positionId, 4242); assert.equal(b.reduceOnly, undefined); assert.equal(b.positionMode, 1);
  await assert.rejects(() => mexc.placeOrder(ctx, CREDS, { test: true, market: {}, side: 'buy', type: 'market', qty: '1' }), (e) => e.exCode === 'test_unsupported');
});

test('mexc: error envelope and cancel', async () => {
  const ctx = mkCtx([[p('/api/v1/private/account/assets'), { success: false, code: 602, message: 'Signature verification failed' }], [p('/api/v1/private/order/cancel'), { success: true, code: 0, data: [{ orderId: 9, errorCode: 0, errorMsg: 'success' }] }]]);
  await assert.rejects(() => mexc.balance(ctx, CREDS), (e) => e.exCode === 602 && /Signature/.test(e.message));
  const r = await mexc.cancelOrder(ctx, CREDS, 'BTC_USDT', '9');
  assert.equal(r.orderId, '9');
  assert.equal(ctx.calls.at(-1).body, '[9]');
});

/* ============================== Bybit ============================== */

test('bybit: markets paginate, linear USDT perps only', async () => {
  let n = 0;
  const ctx = mkCtx([[p('/v5/market/instruments-info'), (c) => {
    n++;
    if (!c.url.searchParams.get('cursor')) return { retCode: 0, result: { nextPageCursor: 'next', list: [{ symbol: 'BTCUSDT', contractType: 'LinearPerpetual', quoteCoin: 'USDT', baseCoin: 'BTC', status: 'Trading', priceFilter: { tickSize: '0.10' }, lotSizeFilter: { qtyStep: '0.001', minOrderQty: '0.001', minNotionalValue: '5' }, leverageFilter: { maxLeverage: '100.00' } }, { symbol: 'BTCPERP', contractType: 'LinearPerpetual', quoteCoin: 'USDC', baseCoin: 'BTC', status: 'Trading' }] } };
    return { retCode: 0, result: { nextPageCursor: '', list: [{ symbol: 'ETHUSDT', contractType: 'LinearPerpetual', quoteCoin: 'USDT', baseCoin: 'ETH', status: 'Closed', priceFilter: { tickSize: '0.01' }, lotSizeFilter: { qtyStep: '0.01', minOrderQty: '0.01' }, leverageFilter: { maxLeverage: '50' } }, { symbol: 'BTC-27DEC24', contractType: 'LinearFutures', quoteCoin: 'USDT', baseCoin: 'BTC', status: 'Trading' }] } };
  }]]);
  const m = await bybit.markets(ctx);
  assert.equal(n, 2);
  assert.deepEqual(m[0], { symbol: 'BTCUSDT', base: 'BTC', quote: 'USDT', tickSize: 0.1, stepSize: 0.001, minQty: 0.001, minNotional: 5, trading: true, type: 'futures', maxLeverage: 100 });
  assert.equal(m.length, 2); assert.equal(m[1].trading, false);
});

test('bybit: klines ascending, tickers', async () => {
  const ctx = mkCtx([
    [p('/v5/market/kline'), { retCode: 0, result: { list: [['1700000060000', '2', '3', '1', '2.5', '10', '25'], ['1700000000000', '1', '2', '0.5', '1.5', '5', '7']] } }],
    [p('/v5/market/tickers'), { retCode: 0, result: { list: [{ symbol: 'BTCUSDT', lastPrice: '30000', price24hPcnt: '0.02', turnover24h: '1e9', highPrice24h: '31000', lowPrice24h: '29000' }, { symbol: 'BTCPERP', lastPrice: '1' }] } }],
  ]);
  const k = await bybit.klines(ctx, 'BTCUSDT', '4h', 5);
  assert.deepEqual(k[0], [1700000000000, 1, 2, 0.5, 1.5, 5]);
  assert.equal(ctx.calls[0].url.searchParams.get('interval'), '240');
  const t = await bybit.tickers(ctx);
  assert.equal(t.length, 1); assert.equal(t[0].changePct, 2); assert.equal(t[0].quoteVol, 1e9);
});

test('bybit: signature headers on GET and POST; create with SL/TP', async () => {
  const ctx = mkCtx([
    [p('/v5/position/switch-isolated'), { retCode: 110026, retMsg: 'Cross/isolated margin mode is not modified' }],
    [p('/v5/position/set-leverage'), { retCode: 110043, retMsg: 'leverage not modified' }],
    [p('/v5/position/list'), { retCode: 0, result: { list: [{ symbol: 'BTCUSDT', size: '0', side: '', positionIdx: 0 }] } }],
    [p('/v5/order/create'), { retCode: 0, result: { orderId: 'ord1', orderLinkId: 'x' } }],
  ]);
  const mk = { symbol: 'BTCUSDT', tickSize: 0.1 };
  const r = await bybit.placeOrder(ctx, CREDS, { market: mk, side: 'buy', type: 'market', qty: '0.015', sl: 29000.55, tp: 32000, leverage: 10, marginMode: 'isolated', clientId: 'cl1' });
  assert.equal(r.orderId, 'ord1'); assert.equal(r.nativeProtection, true);
  const c = ctx.calls.find((x) => x.path === '/v5/order/create');
  assert.deepEqual({ ...c.json, orderLinkId: undefined }, { category: 'linear', symbol: 'BTCUSDT', side: 'Buy', orderType: 'Market', qty: '0.015', positionIdx: 0, orderLinkId: undefined, stopLoss: '29000.5', slTriggerBy: 'MarkPrice', slOrderType: 'Market', takeProfit: '32000.0', tpTriggerBy: 'MarkPrice', tpOrderType: 'Market', tpslMode: 'Full' });
  assert.equal(c.json.orderLinkId, 'cl1');
  assert.equal(c.headers['X-BAPI-API-KEY'], 'KEY'); assert.equal(c.headers['X-BAPI-TIMESTAMP'], String(NOW)); assert.equal(c.headers['X-BAPI-RECV-WINDOW'], '10000');
  assert.equal(c.headers['X-BAPI-SIGN'], hmac('sha256', 'SEC', NOW + 'KEY' + '10000' + c.body));
  const g = ctx.calls.find((x) => x.path === '/v5/position/list');
  assert.equal(g.headers['X-BAPI-SIGN'], hmac('sha256', 'SEC', NOW + 'KEY' + '10000' + g.url.search.slice(1)));
  assert.equal(ctx.calls.find((x) => x.path === '/v5/position/switch-isolated').json.tradeMode, 1);
});

test('bybit: hedge mode positionIdx, reduceOnly drops SL/TP, test unsupported', async () => {
  const ctx = mkCtx([
    [p('/v5/position/list'), { retCode: 0, result: { list: [{ symbol: 'BTCUSDT', size: '0.1', side: 'Buy', positionIdx: 1 }, { symbol: 'BTCUSDT', size: '0', side: '', positionIdx: 2 }] } }],
    [p('/v5/order/create'), { retCode: 0, result: { orderId: 'o2' } }],
  ]);
  const mk = { symbol: 'BTCUSDT', tickSize: 0.1 };
  const r = await bybit.placeOrder(ctx, CREDS, { market: mk, side: 'sell', type: 'limit', price: '31000.0', qty: '0.1', reduceOnly: true, sl: 1, tp: 2 });
  const b = ctx.calls.find((x) => x.path === '/v5/order/create').json;
  assert.equal(b.positionIdx, 1); assert.equal(b.reduceOnly, true); assert.equal(b.stopLoss, undefined); assert.equal(b.price, '31000.0'); assert.equal(b.timeInForce, 'GTC');
  assert.equal(r.nativeProtection, false);
  await assert.rejects(() => bybit.placeOrder(ctx, CREDS, { test: true, market: mk, side: 'buy', type: 'market', qty: '1' }), (e) => e.exCode === 'test_unsupported');
});

test('bybit: positions parse and closePosition via reduce-only market', async () => {
  const list = [{ symbol: 'ETHUSDT', side: 'Sell', size: '2.5', avgPrice: '2000', leverage: '5', positionIM: '1001', unrealisedPnl: '-12.5', liqPrice: '2400', positionIdx: 0 }, { symbol: 'BTCUSDT', side: '', size: '0' }];
  const ctx = mkCtx([[p('/v5/position/list'), { retCode: 0, result: { list } }], [p('/v5/order/create'), { retCode: 0, result: { orderId: 'c1' } }]]);
  const ps = await bybit.positions(ctx, CREDS);
  assert.deepEqual(ps, [{ positionId: 'ETHUSDT|short', symbol: 'ETHUSDT', side: 'short', qty: 2.5, entry: 2000, leverage: 5, margin: 1001, pnl: -12.5, liqPrice: 2400 }]);
  assert.equal(ctx.calls[0].url.searchParams.get('settleCoin'), 'USDT');
  await bybit.closePosition(ctx, CREDS, 'ETHUSDT|short');
  const b = ctx.calls.find((x) => x.path === '/v5/order/create').json;
  assert.equal(b.side, 'Buy'); assert.equal(b.qty, '2.5'); assert.equal(b.reduceOnly, true); assert.equal(b.orderType, 'Market'); assert.equal(b.positionIdx, 0);
  await assert.rejects(() => bybit.closePosition(ctx, CREDS, 'XRPUSDT|long'), (e) => e.exCode === 'position_not_found');
});

test('bybit: balance (unified), errors, cancel, open orders', async () => {
  const ctx = mkCtx([
    [p('/v5/account/wallet-balance'), { retCode: 0, result: { list: [{ totalAvailableBalance: '80', coin: [{ coin: 'USDT', walletBalance: '100', locked: '0' }] }] } }],
    [p('/v5/user/query-api'), { retCode: 0, result: { readOnly: 0, permissions: { ContractTrade: ['Order', 'Position'], Wallet: ['AccountTransfer'] } } }],
    [p('/v5/order/cancel'), { retCode: 0, result: { orderId: 'z' } }],
    [p('/v5/order/realtime'), { retCode: 0, result: { list: [{ orderId: 'a', symbol: 'BTCUSDT', side: 'Buy', orderType: 'Limit', price: '100', qty: '1', cumExecQty: '0.5', orderStatus: 'New' }] } }],
  ]);
  const b = await bybit.balance(ctx, CREDS);
  assert.deepEqual(b, { balances: [{ asset: 'USDT', free: 80, locked: 20 }], canTrade: true, canWithdraw: false });
  assert.deepEqual(await bybit.openOrders(ctx, CREDS, 'BTCUSDT'), [{ orderId: 'a', symbol: 'BTCUSDT', side: 'buy', type: 'limit', price: 100, qty: 1, filled: 0.5, status: 'New' }]);
  await bybit.cancelOrder(ctx, CREDS, 'BTCUSDT', 'a');
  assert.deepEqual(ctx.calls.at(-1).json, { category: 'linear', symbol: 'BTCUSDT', orderId: 'a' });
  const bad = mkCtx([[p('/v5/position/list'), { retCode: 10003, retMsg: 'API key is invalid.' }]]);
  await assert.rejects(() => bybit.positions(bad, CREDS), (e) => e.exCode === 10003 && /invalid/.test(e.message));
});

test('connector metadata', () => {
  for (const [c, host] of [[binance, 'fapi.binance.com'], [mexc, 'contract.mexc.com'], [bybit, 'api.bybit.com']]) {
    assert.equal(c.type, 'futures'); assert.equal(c.needsPassphrase, false); assert.deepEqual(c.hosts, [host]);
    for (const m of ['markets', 'tickers', 'klines', 'balance', 'setLeverage', 'placeOrder', 'positions', 'closePosition', 'openOrders', 'cancelOrder']) assert.equal(typeof c[m], 'function');
  }
});
