'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const os = require('os'); const path = require('path');
const { BotManager } = require('../bot');

function mk() {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ba-'));
  const conn = { id: 'lbank', type: 'spot', balance: async () => ({ balances: [{ asset: 'USDT', free: 100, locked: 0 }] }) };
  const m = new BotManager({ dataDir, botKey: 'k', botMax: 5, botMaxOrderUsd: 50 }, { CONNECTORS: { lbank: conn, xt: { id: 'xt', type: 'spot', balance: conn.balance } }, ctx: {}, log() {}, fetch: async () => { throw new Error('x'); } });
  return { m, dataDir };
}
const creds = (c) => c;

test('مدیر: توقف کلی، مسدودسازی، صرافی غیرفعال، سقف مبلغ و ماندگاری', async () => {
  const { m, dataDir } = mk();
  const r = await m.save({ exchange: 'lbank', creds: { apiKey: 'a', apiSecret: 'b' }, label: 'علی', owner: 'u1' }, creds);
  const id = r.bot.id, tok = r.botToken;
  m.setRunning(id, tok, true);
  assert.equal(m.adminSummary().running, 1);
  assert.equal(m.adminList()[0].owner, 'u1');
  assert.equal(m.adminStopAll().stopped, 1);
  m._applyAdmin({ paused: true, note: 'تعمیرات', maxOrderUsd: 20, disabledExchanges: ['xt'] });
  assert.throws(() => m.setRunning(id, tok, true), /trading_paused|تعمیرات/);
  await assert.rejects(m.save({ exchange: 'xt', creds: { apiKey: 'a', apiSecret: 'b' } }, creds), /exchange_disabled|غیرفعال/);
  m._applyAdmin({ paused: false });
  m.adminBlock(id, true);
  assert.throws(() => m.setRunning(id, tok, true), /bot_blocked|مسدود/);
  m.adminBlock(id, false);
  m.setRunning(id, tok, true);
  assert.equal(m.caps.maxOrderUsd, 20);
  assert.ok(fs.existsSync(path.join(dataDir, 'bot-admin.json')));
  const m2 = new BotManager({ dataDir, botKey: 'k' }, { CONNECTORS: { lbank: {}, xt: {} }, ctx: {}, log() {} });
  assert.equal(m2.caps.maxOrderUsd, 20);
  assert.deepEqual(m2.admin.disabledExchanges, ['xt']);
  m.adminDelete(id); assert.equal(m.adminList().length, 0);
});
