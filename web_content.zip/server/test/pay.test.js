'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createPay } = require('../pay');

const ZM = '12345678-1234-1234-1234-123456789012';
function mk(opts = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pay-'));
  const calls = [];
  const fetchImpl = async (u, o) => {
    const body = JSON.parse(o.body); calls.push({ u, body, h: o.headers });
    let j;
    if (u.includes('zarinpal')) j = u.endsWith('request.json') ? { data: { code: 100, authority: 'AUTH' + calls.length }, errors: [] } : (opts.fail ? { data: [], errors: { code: -50 } } : { data: { code: 100, ref_id: 777 }, errors: [] });
    else if (u.includes('zibal')) j = u.endsWith('/request') ? { result: 100, trackId: 5000 + calls.length } : (opts.fail ? { result: 202 } : { result: 100, refNumber: 'Z1', amount: body.trackId ? 500000 : 0 });
    else j = u.endsWith('/payment') ? { id: 'ID' + calls.length, link: 'https://idpay.ir/p/ws/ID' } : (opts.fail ? { status: 1 } : { status: 100, track_id: 'T9' });
    return { status: 200, json: async () => j };
  };
  const httpErr = (s, c) => Object.assign(new Error(c), { status: s });
  const sendJson = (res, s, o) => { res.status = s; res.body = o; };
  const readBody = async (req) => req.body;
  return createPay({ cfg: { syncToken: 'tok', publicUrl: '' }, secretsDir: dir, log() {}, sendJson, readBody, httpErr, safeEqual: (a, b) => a === b, isAdminReq: (r) => r.headers['x-admin-token'] === 'adm', fetchImpl })
    .then((pay) => ({ pay, calls, dir }));
}
const A = { 'x-admin-token': 'adm' };
const rq = (m, body, h) => ({ method: m, body: body ? JSON.stringify(body) : '', headers: Object.assign({ 'x-tradyar-token': 'tok', host: 'app.example.com' }, h) });
const rs = () => ({ writeHead(s) { this.status = s; }, end(h) { this.html = h; } });
const U = (p) => new URL('http://x' + p);
async function call(pay, m, p, body, h) { const res = rs(); await pay.handle(rq(m, body, h), res, U(p), p.split('?')[0]); return res; }

test('مدیریت درگاه‌ها: فقط مدیر، افزودن/ویرایش/حذف، کلید هرگز برنمی‌گردد', async () => {
  const { pay } = await mk();
  await assert.rejects(call(pay, 'GET', '/pay/config'), /unauthorized/);
  await assert.rejects(call(pay, 'POST', '/pay/config', { action: 'add', type: 'zarinpal', key: 'bad' }, A), /bad_key/);
  await assert.rejects(call(pay, 'POST', '/pay/config', { action: 'add', type: 'nope', key: 'x' }, A), /bad_type/);
  let r = await call(pay, 'POST', '/pay/config', { action: 'add', type: 'zarinpal', key: ZM, label: 'زرین' }, A);
  const id = r.body.gateways[0].id;
  assert.equal(r.body.gateways[0].enabled, false);
  assert.ok(!JSON.stringify(r.body).includes(ZM));
  r = await call(pay, 'POST', '/pay/config', { action: 'update', id, enabled: true }, A);
  assert.equal(r.body.gateways[0].enabled, true);
  r = await call(pay, 'GET', '/pay/public'); assert.equal(r.body.gateways.length, 1);
  assert.ok(!JSON.stringify(r.body).includes(ZM));
  await call(pay, 'POST', '/pay/config', { action: 'delete', id }, A);
  r = await call(pay, 'GET', '/pay/public'); assert.equal(r.body.gateways.length, 0);
});

for (const [type, key, cb] of [
  ['zarinpal', ZM, (a) => `/pay/callback/GW?Authority=${a}&Status=OK`],
  ['zibal', 'zibal_merchant1', (a) => `/pay/callback/GW?trackId=${a}&success=1&status=2`],
  ['idpay', 'abcdef12-3456-7890-abcd-ef1234567890', (a) => `/pay/callback/GW?id=${a}&status=10`],
]) {
  test('پرداخت کامل با ' + type + ': ایجاد، callback، تأیید سرور، claim یک‌بار مصرف', async () => {
    const { pay, calls } = await mk();
    let r = await call(pay, 'POST', '/pay/config', { action: 'add', type, key }, A);
    const id = r.body.gateways[0].id;
    await call(pay, 'POST', '/pay/config', { action: 'update', id, enabled: true }, A);
    await assert.rejects(call(pay, 'POST', '/pay/create', { gateway: id, amount: 10, userId: 'u1' }), /bad_amount/);
    r = await call(pay, 'POST', '/pay/create', { gateway: id, amount: 50000, kind: 'coins', itemId: 'p2', userId: 'u1', tokens: 100 });
    const auth = r.body.authority; const ref = auth.split(':')[1];
    assert.ok(/^https:\/\//.test(r.body.url));
    assert.ok(JSON.stringify(calls[0].body).includes('https://app.example.com/pay/callback/' + id));
    r = await call(pay, 'GET', '/pay/status?authority=' + encodeURIComponent(auth)); assert.equal(r.body.status, 'pending');
    const cr = rs(); await pay.handle({ method: 'GET', headers: {} }, cr, U(cb(ref).replace('GW', id)), '/pay/callback/' + id);
    assert.equal(cr.status, 200); assert.ok(cr.html.includes('پرداخت موفق'));
    r = await call(pay, 'GET', '/pay/status?authority=' + encodeURIComponent(auth));
    assert.equal(r.body.status, 'paid'); assert.equal(r.body.tokens, 100);
    await assert.rejects(call(pay, 'POST', '/pay/claim', { authority: auth, userId: 'u2' }), /wrong_user/);
    r = await call(pay, 'POST', '/pay/claim', { authority: auth, userId: 'u1' }); assert.equal(r.body.already, false);
    r = await call(pay, 'POST', '/pay/claim', { authority: auth, userId: 'u1' }); assert.equal(r.body.already, true);
  });
}

test('تأیید ناموفق یا لغو هرگز paid نمی‌شود', async () => {
  const { pay } = await mk({ fail: true });
  let r = await call(pay, 'POST', '/pay/config', { action: 'add', type: 'zarinpal', key: ZM }, A);
  const id = r.body.gateways[0].id; await call(pay, 'POST', '/pay/config', { action: 'update', id, enabled: true }, A);
  r = await call(pay, 'POST', '/pay/create', { gateway: id, amount: 5000, userId: 'u1' }); const a = r.body.authority;
  await pay.handle({ method: 'GET', headers: {} }, rs(), U(`/pay/callback/${id}?Authority=${a.split(':')[1]}&Status=OK`), '/pay/callback/' + id);
  r = await call(pay, 'GET', '/pay/status?authority=' + encodeURIComponent(a)); assert.notEqual(r.body.status, 'paid');
  await assert.rejects(call(pay, 'POST', '/pay/claim', { authority: a, userId: 'u1' }), /not_paid/);
  r = await call(pay, 'POST', '/pay/create', { gateway: id, amount: 5000, userId: 'u1' }); const b = r.body.authority;
  await pay.handle({ method: 'GET', headers: {} }, rs(), U(`/pay/callback/${id}?Authority=${b.split(':')[1]}&Status=NOK`), '/pay/callback/' + id);
  r = await call(pay, 'GET', '/pay/status?authority=' + encodeURIComponent(b)); assert.equal(r.body.status, 'failed');
});
