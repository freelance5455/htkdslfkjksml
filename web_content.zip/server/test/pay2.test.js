'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'); const os = require('os'); const path = require('path');
const { createPay } = require('../pay');

function mk() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pay2-'));
  const calls = [];
  const fetchImpl = async (u, o) => {
    const isForm = String((o.headers || {})['Content-Type']).includes('urlencoded');
    const body = isForm ? Object.fromEntries(new URLSearchParams(o.body)) : JSON.parse(o.body);
    calls.push({ u, body, h: o.headers });
    let j;
    if (u.includes('nextpay')) j = u.endsWith('/token') ? { code: -1, trans_id: 'NP-TRANS-1' } : { code: 0, Shaparak_Ref_Id: 'NPREF' };
    else if (u.includes('pay.ir')) j = u.endsWith('/send') ? { status: 1, token: 'PIRTOKEN' } : { status: 1, amount: body.amount_check || calls.amountCheck, transId: 'PIRTR' };
    else if (u.includes('vandar')) j = u.endsWith('/send') ? { status: 1, token: 'VANTOKEN' } : { status: 1, amount: calls.amountCheck, transId: 'VANTR' };
    else if (u.includes('payping')) { if (u.endsWith('/pay')) return { status: 200, json: async () => ({ code: 'PPCODE' }) }; return { status: 200, json: async () => ({}) }; }
    return { status: 200, json: async () => j };
  };
  const httpErr = (s, c) => Object.assign(new Error(c), { status: s });
  const sendJson = (res, s, o) => { res.status = s; res.body = o; };
  return createPay({ cfg: { syncToken: 'tok', publicUrl: '' }, secretsDir: dir, log() {}, sendJson, readBody: async (r) => r.body, httpErr, safeEqual: (a, b) => a === b, isAdminReq: (r) => r.headers['x-admin-token'] === 'adm', fetchImpl })
    .then((pay) => ({ pay, calls }));
}
const A = { 'x-admin-token': 'adm' };
const rq = (m, body, h) => ({ method: m, body: body ? JSON.stringify(body) : '', headers: Object.assign({ 'x-tradyar-token': 'tok', host: 'app.example.com' }, h) });
const U = (p) => new URL('http://x' + p);
async function call(pay, m, p, body, h) { const res = { writeHead(s) { this.status = s; }, end(x) { this.html = x; } }; await pay.handle(rq(m, body, h), res, U(p), p.split('?')[0]); return res; }

for (const [type, key, cb, amountRial] of [
  ['nextpay', 'abcdef1234567890', () => `?trans_id=NP-TRANS-1&order_id=x`, false],
  ['payir', 'test', () => `?status=1&token=PIRTOKEN`, true],
  ['vandar', 'vandar.apikey.1234567890', () => `?token=VANTOKEN&payment_status=OK`, true],
  ['payping', 'pp.token.abcdefghij123456', () => `?refid=991122&clientrefid=ORDER`, false],
]) {
  test('درگاه ' + type + ': ایجاد → بازگشت → تأیید سرور → paid', async () => {
    const { pay, calls } = await mk();
    let r = await call(pay, 'POST', '/pay/config', { action: 'add', type, key }, A);
    const id = r.body.gateways[0].id;
    assert.ok(!JSON.stringify(r.body).includes(key));
    await call(pay, 'POST', '/pay/config', { action: 'update', id, enabled: true }, A);
    calls.amountCheck = 50000 * 10;
    r = await call(pay, 'POST', '/pay/create', { gateway: id, amount: 50000, kind: 'coins', userId: 'u1', tokens: 10 });
    assert.ok(/^https:\/\//.test(r.body.url));
    const auth = r.body.authority;
    let q = cb();
    if (type === 'payping') q = `?refid=991122&clientrefid=${calls[0].body.clientRefId}`;
    if (type === 'nextpay') q = `?trans_id=NP-TRANS-1&order_id=${calls[0].body.order_id}`;
    const res = { writeHead(s) { this.status = s; }, end(x) { this.html = x; } };
    await pay.handle({ method: 'GET', headers: {} }, res, U('/pay/callback/' + id + q), '/pay/callback/' + id);
    assert.equal(res.status, 200); assert.ok(res.html.includes('پرداخت موفق'), res.html.slice(0, 400));
    r = await call(pay, 'GET', '/pay/status?authority=' + encodeURIComponent(auth));
    assert.equal(r.body.status, 'paid'); assert.equal(r.body.tokens, 10);
  });
}
