'use strict';
/* تست مدیر مسیر اتصال «صرافی من» (TX) داخل trad-yar-myket-fixed.html
 * بخش TX از خود فایل HTML بیرون کشیده و در محیط شبیه‌سازی‌شده اجرا می‌شود: فیلترشکن روشن/خاموش، بلاک ۴۵۱، قطع سرور، تایم‌اوت و … */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const HTML = fs.readFileSync(path.join(__dirname, '..', '..', 'trad-yar-myket-fixed.html'), 'utf8');
const a = HTML.indexOf('const TX=(function(){');
const b = HTML.indexOf('function renderExchangePage()');
assert.ok(a > 0 && b > a, 'TX block not found');
const TX_SRC = HTML.slice(a, b);

const SRV = 'https://srv.example.com';
const json = (obj, status = 200, headers = {}) => ({ ok: status >= 200 && status < 300, status, headers: { get: (k) => headers[String(k).toLowerCase()] || null }, json: async () => obj, text: async () => JSON.stringify(obj) });

/* env: {direct:boolean, server:boolean, srvExchange:fn, localExchange:fn, dedicatedIp} */
function makeEnv(cfg = {}) {
  const calls = { server: [], local: [], reach: 0 };
  const env = Object.assign({ direct: false, server: true, hasLocal: true, dedicatedIp: null, srvHandler: null, localHandler: null, userServer: '' }, cfg);
  const ls = new Map(); if (env.userServer) ls.set('tyx_srv', env.userServer);
  const listeners = {};
  const win = { addEventListener: (t, f) => { (listeners[t] = listeners[t] || []).push(f); }, crypto: {} };
  const doc = { hidden: false, addEventListener() {}, activeElement: null, getElementById: () => null, querySelector: () => null };
  const reachRe = /fapi\.binance\.com\/fapi\/v1\/ping|api\.bybit\.com\/v5\/market\/time|www\.okx\.com\/api\/v5\/public\/time|api\.gateio\.ws\/api\/v4\/spot\/time/;
  const fetchMock = async (url, init = {}) => {
    url = String(url);
    if (init.signal && init.signal.aborted) throw Object.assign(new Error('aborted'), { name: 'AbortError' });
    if (reachRe.test(url)) { calls.reach++; if (env.direct) return json({}); throw new TypeError('Failed to fetch'); }
    if (url.startsWith('https://api.ipify.org')) { if (env.direct) return json({ ip: '5.6.7.8' }); throw new TypeError('Failed to fetch'); }
    if (url.startsWith(SRV)) {
      if (!env.server) throw new TypeError('Failed to fetch');
      const op = url.replace(SRV + '/trade/v1/', '');
      if (op === 'health') return json({ ok: true, trade: true, version: '1.1.0', exchanges: 10 });
      if (op === 'egress') return json({ ok: true, ip: env.dedicatedIp });
      if (op === 'exchanges') return json({ ok: true, exchanges: [{ id: 'binance', name: 'Binance Futures', type: 'futures', needsPassphrase: false, features: {} }] });
      let body = {}; try { body = JSON.parse(init.body || '{}'); } catch (e) {}
      calls.server.push({ op, body });
      if (env.srvHandler) return env.srvHandler(op, body);
      return json({ ok: true, via: 'server', op });
    }
    throw new TypeError('Failed to fetch ' + url);
  };
  const TXL = env.hasLocal ? { handleTrade: async (req) => {
    const op = new URL(req.url).pathname.replace(/^\/trade\/v1\//, '');
    let body = {}; try { body = JSON.parse(await req.text() || '{}'); } catch (e) {}
    if (op === 'health') return json({ ok: true, trade: true, local: true });
    if (op === 'egress') return json({ ok: true, ip: null });
    if (op === 'exchanges') return json({ ok: true, exchanges: [{ id: 'binance', name: 'Binance Futures', type: 'futures', needsPassphrase: false, features: {} }] });
    calls.local.push({ op, body });
    if (env.localHandler) return env.localHandler(op, body);
    return json({ ok: true, via: 'local', op });
  } } : undefined;
  if (TXL) win.TXL = TXL;
  class Req { constructor(u, i) { this.url = u; this.method = (i && i.method) || 'GET'; this._b = i && i.body; } async text() { return this._b || ''; } }
  const ctx = {
    window: win, document: doc, navigator: {}, console, setTimeout, clearTimeout, setInterval: () => 0, clearInterval() {}, Promise, AbortController, URL, Request: Req, Response: class {},
    localStorage: { getItem: (k) => (ls.has(k) ? ls.get(k) : null), setItem: (k, v) => ls.set(k, String(v)), removeItem: (k) => ls.delete(k) },
    sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} },
    fetch: fetchMock, getServerEndpoints: () => [SRV], toast() {}, TextEncoder, TextDecoder, btoa, atob, Uint8Array, JSON, Date, Math, Set, Map,
    VIEW: 'prices', USER: { id: 'u1', role: 'admin' }, DB: { get: () => ({}) }, indexedDB: {},
  };
  ctx.globalThis = ctx;
  win.fetch = fetchMock;
  vm.createContext(ctx);
  vm.runInContext(TX_SRC + '\n;globalThis.__TX=TX;', ctx);
  win.listeners = listeners;
  return { TX: ctx.__TX, calls, env, win, ctx };
}
const N = (t) => t._net;

test('VPN روشن (صرافی مستقیم باز): مسیر اول = مستقیم از گوشی', async () => {
  const t = makeEnv({ direct: true });
  const r = await N(t.TX).api('markets', { exchange: 'binance' });
  assert.equal(r.via, 'local'); assert.equal(t.calls.server.length, 0);
  assert.equal(N(t.TX).S.base, 'https://local.invalid');
});

test('VPN خاموش و سرور در دسترس: مسیر اول = سرور', async () => {
  const t = makeEnv({ direct: false, server: true });
  const r = await N(t.TX).api('tickers', { exchange: 'binance' });
  assert.equal(r.via, 'server'); assert.equal(t.calls.local.length, 0);
});

test('VPN خاموش و سرور هم قطع: خطای واضح، نه کرش', async () => {
  const t = makeEnv({ direct: false, server: false, localHandler: () => { throw new TypeError('Failed to fetch'); } });
  await assert.rejects(() => N(t.TX).api('markets', { exchange: 'binance' }), (e) => e.code === 'network' && /اتصال/.test(e.message));
});

test('سرور از سمت صرافی بلاک (۴۵۱) ولی VPN روشن: خودکار به مسیر مستقیم می‌رود', async () => {
  const t = makeEnv({ direct: false, server: true, srvHandler: () => json({ ok: false, error: 'exchange_error', message: 'خطای Binance Futures 451', status: 451 }, 422) });
  const first = await N(t.TX).api('tickers', { exchange: 'binance' }).catch((e) => e);
  assert.equal(first.via, 'local', 'باید به local سوییچ شود');
  assert.equal(t.calls.server.length, 1); assert.equal(t.calls.local.length, 1);
});

test('همان حالت: بعد از یک‌بار موفقیت، مسیر ترجیحی به‌خاطر سپرده می‌شود (بدون دوباره‌کاری)', async () => {
  const t = makeEnv({ direct: false, server: true, srvHandler: () => json({ ok: false, error: 'exchange_error', message: 'blocked', status: 403 }, 422) });
  await N(t.TX).api('tickers', { exchange: 'binance' });
  const before = t.calls.server.length;
  await N(t.TX).api('tickers', { exchange: 'binance' });
  assert.equal(t.calls.server.length, before, 'نباید دوباره به سرور بلاک‌شده برود');
});

test('مسیر مستقیم قطع می‌شود (VPN افتاد): به سرور برمی‌گردد', async () => {
  const t = makeEnv({ direct: true, server: true, localHandler: () => { throw new TypeError('Failed to fetch'); } });
  const r = await N(t.TX).api('markets', { exchange: 'binance' });
  assert.equal(r.via, 'server');
});

test('خطای IP/Whitelist از سرور → مسیر مستقیم (آی‌پی کاربر) امتحان می‌شود', async () => {
  const t = makeEnv({ direct: true, server: true, dedicatedIp: null });
  // local-first است؛ برای تست سمت دیگر: اول local خطای IP می‌دهد، سرور موفق است
  t.env.localHandler = () => json({ ok: false, error: 'exchange_error', message: 'Invalid API-key, IP, or permissions for action', code: '-2015', status: 401 }, 422);
  const r = await N(t.TX).api('balance', { exchange: 'binance', creds: { apiKey: 'a', apiSecret: 'b' } });
  assert.equal(r.via, 'server');
});

test('سرور اختصاصی (آی‌پی ثابت): دستورهای امضاشده اول از سرور، حتی با VPN روشن', async () => {
  const t = makeEnv({ direct: true, server: true, dedicatedIp: '9.9.9.9' });
  await N(t.TX).pickBase(); await new Promise((r) => setTimeout(r, 30)); await N(t.TX).probeServers(true); await new Promise((r) => setTimeout(r, 30));
  assert.equal(N(t.TX).S.dedicated, true);
  const r = await N(t.TX).api('balance', { exchange: 'binance', creds: { apiKey: 'a', apiSecret: 'b' } });
  assert.equal(r.via, 'server');
  const m = await N(t.TX).api('markets', { exchange: 'binance' });
  assert.equal(m.via, 'local', 'داده عمومی همچنان مستقیم');
});

test('ثبت سفارش: تایم‌اوت → هرگز روی مسیر دیگر دوباره ارسال نمی‌شود (جلوگیری از سفارش دوبل)', async () => {
  const t = makeEnv({ direct: true, server: true, localHandler: () => new Promise(() => {}) });
  await assert.rejects(() => N(t.TX).api('order', { exchange: 'binance', creds: { apiKey: 'a', apiSecret: 'b' }, order: { symbol: 'BTCUSDT', side: 'buy' } }, { timeout: 80 }), (e) => e.ambiguous === true && /نامشخص/.test(e.message));
  assert.equal(t.calls.server.filter((c) => c.op === 'order').length, 0);
});

test('ثبت سفارش: ردّ قطعی صرافی (IP) → امتحان مسیر دیگر مجاز و سفارش فقط یک‌بار ثبت می‌شود', async () => {
  const t = makeEnv({ direct: true, server: true, localHandler: () => json({ ok: false, error: 'exchange_error', message: 'Invalid API-key, IP, or permissions for action', status: 401 }, 422) });
  const r = await N(t.TX).api('order', { exchange: 'binance', creds: { apiKey: 'a', apiSecret: 'b' }, order: { symbol: 'BTCUSDT', side: 'buy' } });
  assert.equal(r.via, 'server');
  assert.equal(t.calls.local.filter((c) => c.op === 'order').length, 1);
  assert.equal(t.calls.server.filter((c) => c.op === 'order').length, 1);
});

test('خطای عادی صرافی (موجودی ناکافی) → بدون سوییچ مسیر، پیام همان خطا', async () => {
  const t = makeEnv({ direct: true, server: true, localHandler: () => json({ ok: false, error: 'exchange_error', message: 'Margin is insufficient', code: '-2019', status: 400 }, 422) });
  await assert.rejects(() => N(t.TX).api('order', { exchange: 'binance', creds: { apiKey: 'a', apiSecret: 'b' }, order: {} }), (e) => /insufficient/.test(e.message));
  assert.equal(t.calls.server.length, 0);
});

test('سرور قدیمی (۴۰۴) → مسیر مستقیم', async () => {
  const t = makeEnv({ direct: false, server: true, srvHandler: () => json({ error: 'not_found' }, 404) });
  const r = await N(t.TX).api('klines', { exchange: 'binance', symbol: 'BTCUSDT', interval: '1h' });
  assert.equal(r.via, 'local');
});

test('Cloudflare 52x / ۵۰۲ بدون JSON → مسیر مستقیم', async () => {
  const t = makeEnv({ direct: false, server: true, srvHandler: () => ({ ok: false, status: 522, headers: { get: () => null }, json: async () => { throw new Error('html'); } }) });
  const r = await N(t.TX).api('tickers', { exchange: 'binance' });
  assert.equal(r.via, 'local');
});

test('تغییر شبکه (VPN وسط کار روشن شد): بدون بستن برنامه مسیر مستقیم انتخاب می‌شود', async () => {
  const t = makeEnv({ direct: false, server: true });
  assert.equal((await N(t.TX).api('markets', { exchange: 'binance' })).via, 'server');
  t.env.direct = true;
  await N(t.TX).onNetChange();
  assert.equal(N(t.TX).S.net.direct, true);
  assert.equal((await N(t.TX).api('markets', { exchange: 'binance' })).via, 'local');
});

test('تغییر شبکه (VPN خاموش شد): برمی‌گردد به سرور', async () => {
  const t = makeEnv({ direct: true, server: true });
  assert.equal((await N(t.TX).api('markets', { exchange: 'binance' })).via, 'local');
  t.env.direct = false;
  await N(t.TX).onNetChange();
  assert.equal((await N(t.TX).api('markets', { exchange: 'binance' })).via, 'server');
});

test('ربات ۲۴ساعته (bot/*) همیشه اول به سرور می‌رود، حتی وقتی مسیر مستقیم باز است', async () => {
  const t = makeEnv({ direct: true, server: true });
  await N(t.TX).pickBase();
  await N(t.TX).probeServers(true);
  const r = await N(t.TX).api('bot/status', { botId: 'x' });
  assert.equal(r.via, 'server');
});

test('بدون موتور داخلی و بدون سرور: no_server', async () => {
  const t = makeEnv({ direct: false, server: false, hasLocal: false });
  await assert.rejects(() => N(t.TX).pickBase(), (e) => e.code === 'no_server');
});

test('سرور شخصی کاربر تنظیم شده: به آن اولویت داده می‌شود و در صورت بلاک مسیر مستقیم پشتیبان است', async () => {
  const t = makeEnv({ direct: true, server: true, userServer: SRV });
  await N(t.TX).pickBase();
  assert.equal(N(t.TX).S.base, SRV);
});

test('آی‌پی واقعی گوشی (آی‌پی فیلترشکن) برای محدودیت IP خوانده می‌شود', async () => {
  const t = makeEnv({ direct: true });
  assert.equal(await N(t.TX).deviceIp(true), '5.6.7.8');
  const t2 = makeEnv({ direct: false });
  assert.equal(await N(t2.TX).deviceIp(true), null);
});

test('تأخیر: مسیر مستقیم برقرار است → منتظر پروب کند سرورها نمی‌ماند', async () => {
  const t = makeEnv({ direct: true, server: true });
  const t0 = Date.now(); await N(t.TX).pickBase(); assert.ok(Date.now() - t0 < 500);
});

test('۴۲۹ (Rate limit) یک‌بار صبر و تلاش دوباره می‌کند', async () => {
  let n = 0;
  const t = makeEnv({ direct: false, server: true, srvHandler: () => (n++ === 0 ? json({ ok: false, error: 'rate_limited' }, 429, { 'retry-after': '0' }) : json({ ok: true, via: 'server' })) });
  const r = await N(t.TX).api('tickers', { exchange: 'binance' }, {});
  assert.equal(r.ok, true); assert.equal(n, 2);
});
