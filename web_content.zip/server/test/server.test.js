'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp, loadConfig, isPrivateIp } = require('../server.js');

const PUBLIC_DNS = async () => [{ address: '93.184.216.34', family: 4 }];
const ENVELOPE = JSON.stringify({ v: 2, encrypted: true, salt: 'AA', iv: 'BB', ct: 'CC', hmac: 'DD' });

async function boot(env = {}, deps = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tyar-'));
  const cfg = loadConfig({ DATA_DIR: dir, ...env });
  const app = await createApp(cfg, { log: () => {}, lookup: PUBLIC_DNS, ...deps });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  return { app, base, dir, close: () => app.close() };
}

test('health و CORS', async () => {
  const s = await boot();
  const h = await (await fetch(s.base + '/health')).json();
  assert.equal(h.ok, true);
  const pre = await fetch(s.base + '/', { method: 'OPTIONS' });
  assert.equal(pre.status, 204);
  assert.equal(pre.headers.get('access-control-allow-origin'), '*');
  await s.close();
});

test('sync: خالی → ذخیره → خواندن → ماندگاری بعد از ریستارت', async () => {
  const s = await boot();
  assert.deepEqual(await (await fetch(s.base + '/')).json(), { ok: false, reason: 'no_data' });
  const post = await fetch(s.base + '/', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: ENVELOPE });
  assert.equal((await post.json()).ok, true);
  const got = await (await fetch(s.base + '/')).json();
  assert.equal(got.ok, true);
  assert.deepEqual(got.doc, JSON.parse(ENVELOPE));
  await s.close();

  const cfg = loadConfig({ DATA_DIR: s.dir });
  const app2 = await createApp(cfg, { log: () => {}, lookup: PUBLIC_DNS });
  await new Promise((r) => app2.server.listen(0, '127.0.0.1', r));
  const again = await (await fetch(`http://127.0.0.1:${app2.server.address().port}/`)).json();
  assert.deepEqual(again.doc, JSON.parse(ENVELOPE));
  await app2.close();
});

test('sync: gzip وقتی کلاینت بخواهد', async () => {
  const s = await boot();
  const big = JSON.stringify({ v: 1, users: Array.from({ length: 300 }, (_, i) => ({ id: i, name: 'user' + i })) });
  await fetch(s.base + '/', { method: 'POST', body: big });
  const r = await fetch(s.base + '/', { headers: { 'Accept-Encoding': 'gzip' } });
  assert.equal(r.headers.get('content-encoding'), 'gzip');
  const j = await r.json(); // fetch خودش باز می‌کند
  assert.equal(j.ok, true);
  assert.equal(j.doc.users.length, 300);
  const plain = await fetch(s.base + '/', { headers: { 'Accept-Encoding': 'identity' } });
  assert.equal(plain.headers.get('content-encoding'), null);
  assert.equal((await plain.json()).doc.users.length, 300);
  await s.close();
});

test('sync: داده‌های نامعتبر رد می‌شوند و داده قبلی سالم می‌ماند', async () => {
  const s = await boot();
  await fetch(s.base + '/', { method: 'POST', body: ENVELOPE });
  for (const bad of ['garbage', '[]', '{"hello":1}', '']) {
    const r = await fetch(s.base + '/', { method: 'POST', body: bad });
    assert.equal(r.status, 400, 'باید رد شود: ' + bad);
  }
  const got = await (await fetch(s.base + '/')).json();
  assert.deepEqual(got.doc, JSON.parse(ENVELOPE));
  await s.close();
});

test('sync: سقف حجم و بکاپ خودکار', async () => {
  const s = await boot({ MAX_SYNC_BYTES: '500', SNAPSHOT_INTERVAL_MIN: '0' });
  assert.equal((await fetch(s.base + '/', { method: 'POST', body: JSON.stringify({ v: 1, x: 'a'.repeat(900) }) })).status, 413);
  await fetch(s.base + '/', { method: 'POST', body: ENVELOPE });
  await fetch(s.base + '/', { method: 'POST', body: JSON.stringify({ v: 1, second: true }) });
  const files = fs.readdirSync(path.join(s.dir, 'backups'));
  assert.ok(files.some((f) => f.startsWith('sync-')), 'بکاپ لحظه‌ای ساخته نشد');
  assert.ok(files.some((f) => f.startsWith('daily-')), 'بکاپ روزانه ساخته نشد');
  await s.close();
});

test('rate limit', async () => {
  const s = await boot({ SYNC_RATE_PER_MIN: '3' });
  const codes = [];
  for (let i = 0; i < 5; i++) codes.push((await fetch(s.base + '/')).status);
  assert.deepEqual(codes, [200, 200, 200, 429, 429]);
  await s.close();
});

test('relay: ورودی‌های ناامن رد می‌شوند', async () => {
  const s = await boot({}, { fetch: async () => { throw new Error('نباید صدا زده شود'); } });
  const q = (u) => fetch(s.base + '/relay?u=' + encodeURIComponent(u));
  assert.equal((await fetch(s.base + '/relay')).status, 400);
  assert.equal((await q('http://api.binance.com/api/v3/ping')).status, 400);          // http
  assert.equal((await q('https://evil.example.com/x')).status, 403);                    // دامنه غیرمجاز
  assert.equal((await q('https://api.binance.com.evil.com/x')).status, 403);            // جعل پسوند
  assert.equal((await q('https://127.0.0.1/x')).status, 403);                           // IP مستقیم
  assert.equal((await q('https://2130706433/x')).status, 403);                          // IP دسیمال
  assert.equal((await q('https://api.binance.com:8443/x')).status, 403);                // پورت
  assert.equal((await q('https://user:pw@api.binance.com/x')).status, 400);             // credentials
  assert.equal((await q('not a url')).status, 400);
  await s.close();
});

test('relay: دامنهٔ مجاز با DNS خصوصی رد می‌شود (SSRF)', async () => {
  const s = await boot({}, { lookup: async () => [{ address: '10.0.0.5', family: 4 }], fetch: async () => { throw new Error('x'); } });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/api/v3/ping'));
  assert.equal(r.status, 403);
  assert.equal((await r.json()).error, 'private_address');
  await s.close();
});

test('relay: مسیر موفق + کش + ادغام درخواست‌های همزمان', async () => {
  let calls = 0;
  const fakeFetch = async (url) => {
    calls++;
    await new Promise((r) => setTimeout(r, 40));
    return new Response(JSON.stringify({ price: '123', url }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  const s = await boot({ RELAY_CACHE_TTL_MS: '5000' }, { fetch: fakeFetch });
  const u = s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT');
  const burst = await Promise.all(Array.from({ length: 6 }, () => fetch(u)));
  for (const r of burst) {
    assert.equal(r.status, 200);
    assert.equal(r.headers.get('x-tradyar-relay'), '1');
    assert.equal((await r.json()).price, '123');
  }
  assert.equal(calls, 1, 'درخواست‌های همزمان باید یکی شوند');
  const again = await fetch(u);
  assert.equal(again.headers.get('x-relay-cache'), 'HIT');
  assert.equal(calls, 1);
  await s.close();
});

test('relay: POST (هوش مصنوعی) مستقیم عبور می‌کند و کش نمی‌شود', async () => {
  let seen;
  const fakeFetch = async (url, init) => {
    seen = init;
    return new Response('{"choices":[{"message":{"content":"سلام"}}]}', { status: 200, headers: { 'content-type': 'application/json' } });
  };
  const s = await boot({}, { fetch: fakeFetch });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://text.pollinations.ai/openai'), {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"model":"openai"}',
  });
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('x-tradyar-relay'), '1');
  assert.match(await r.text(), /سلام/);
  assert.equal(seen.method, 'POST');
  assert.equal(seen.body, '{"model":"openai"}');
  await s.close();
});

test('relay: ریدایرکت به دامنهٔ غیرمجاز بلاک می‌شود', async () => {
  const fakeFetch = async () => new Response(null, { status: 302, headers: { location: 'https://evil.example.com/steal' } });
  const s = await boot({}, { fetch: fakeFetch });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/x'));
  assert.equal(r.status, 403);
  await s.close();
});

test('relay: خطای 451 مقصد عیناً عبور داده می‌شود و در آمار ثبت می‌شود', async () => {
  const fakeFetch = async () => new Response('{"msg":"restricted"}', { status: 451, headers: { 'content-type': 'application/json' } });
  const s = await boot({ ADMIN_TOKEN: 'secret-token-123' }, { fetch: fakeFetch });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/api/v3/ping'));
  assert.equal(r.status, 451);
  const st = await (await fetch(s.base + '/status', { headers: { Authorization: 'Bearer secret-token-123' } })).json();
  assert.equal(st.stats.hosts['api.binance.com'].s451, 1);
  await s.close();
});

test('status: نیازمند توکن', async () => {
  const s = await boot({ ADMIN_TOKEN: 'secret-token-123' });
  assert.equal((await fetch(s.base + '/status')).status, 401);
  assert.equal((await fetch(s.base + '/status', { headers: { Authorization: 'Bearer wrong' } })).status, 401);
  assert.equal((await fetch(s.base + '/status', { headers: { Authorization: 'Bearer secret-token-123' } })).status, 200);
  await s.close();
  const s2 = await boot(); // بدون توکن → غیرفعال
  assert.equal((await fetch(s2.base + '/status')).status, 404);
  await s2.close();
});

test('مسیر ناشناخته 404 و isPrivateIp', async () => {
  const s = await boot();
  assert.equal((await fetch(s.base + '/etc/passwd')).status, 404);
  await s.close();
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.1.1', '172.16.0.1', '169.254.169.254', '100.64.0.1', '::1', 'fd00::1', '::ffff:7f00:1', '::ffff:10.0.0.1']) {
    assert.equal(isPrivateIp(ip), true, ip);
  }
  for (const ip of ['93.184.216.34', '8.8.8.8', '2606:4700::1111']) assert.equal(isPrivateIp(ip), false, ip);
});

test('vault + /ai: کلید هرگز لو نمی‌رود، سند sync پاک‌سازی می‌شود', async () => {
  let seenAuth = '';
  const mockFetch = async (u, o) => { seenAuth = (o.headers || {}).authorization || ''; return new Response(JSON.stringify({ choices: [{ message: { content: 'سلام' } }] }), { status: 200 }); };
  const s = await boot({ ADMIN_TOKEN: 'adm-token-1234567890', SYNC_TOKEN: 'sync-token-1234567890' }, { fetch: mockFetch });
  const H = { 'x-tradyar-token': 'sync-token-1234567890' };
  // بدون ادمین: ثبت کلید ممنوع
  assert.equal((await fetch(s.base + '/vault', { method: 'PUT', body: '{}' })).status, 401);
  const put = await fetch(s.base + '/vault', { method: 'PUT', headers: { 'x-admin-token': 'adm-token-1234567890' }, body: JSON.stringify({ providers: [{ id: 'p1', name: 'T', base: 'https://api.example.com/v1', model: 'm', key: 'sk-TOPSECRET9999', shared: true }] }) });
  const pj = await put.json();
  assert.equal(pj.providers[0].key, '••••9999');
  // کاربر عادی: چت کار می‌کند ولی کلید را نمی‌بیند
  const ai = await (await fetch(s.base + '/ai', { method: 'POST', headers: H, body: JSON.stringify({ messages: [{ role: 'user', content: 'hi' }] }) })).json();
  assert.equal(ai.text, 'سلام');
  assert.ok(!JSON.stringify(ai).includes('TOPSECRET'));
  assert.equal(seenAuth, 'Bearer sk-TOPSECRET9999');
  assert.equal((await fetch(s.base + '/vault', { headers: H })).status, 401);
  assert.equal((await fetch(s.base + '/ai', { method: 'POST', body: '{}' })).status, 401);
  // sync: aiKeys* پاک می‌شود
  await fetch(s.base + '/', { method: 'POST', headers: H, body: JSON.stringify({ v: 2, aiKeysShared: [{ key: 'LEAK' }], aiKeysAdmin: { k: 'LEAK' }, x: 1 }) });
  const got = await (await fetch(s.base + '/', { headers: H })).text();
  assert.ok(!got.includes('LEAK') && got.includes('"x":1'));
  await s.close();
});

test('servers registry: ثبت دائمی، امضا و ماندگاری بعد از ریستارت', async () => {
  const env = { ADMIN_TOKEN: 'adm-token-1234567890', SYNC_TOKEN: 'sync-token-1234567890', PUBLIC_URL: 'https://api.example.com' };
  const s = await boot(env);
  const H = { 'x-tradyar-token': 'sync-token-1234567890' };
  assert.equal((await fetch(s.base + '/servers')).status, 401);
  const g1 = await (await fetch(s.base + '/servers', { headers: H })).json();
  assert.equal(g1.servers[0].url, 'https://api.example.com');
  assert.equal((await fetch(s.base + '/servers', { method: 'PUT', headers: H, body: '{}' })).status, 401);
  const put = await (await fetch(s.base + '/servers', { method: 'PUT', headers: { 'x-admin-token': env.ADMIN_TOKEN }, body: JSON.stringify({ servers: [{ url: 'https://a.example.com/' }, { url: 'http://1.2.3.4:8787' }, { url: 'javascript:alert(1)' }, { url: 'https://a.example.com' }] }) })).json();
  assert.deepEqual(put.servers.map((x) => x.url), ['https://a.example.com', 'http://1.2.3.4:8787']);
  const crypto = require('node:crypto');
  const exp = crypto.createHash('sha256').update('sync-token-1234567890|https://a.example.com\nhttp://1.2.3.4:8787|sync-token-1234567890').digest('hex');
  assert.equal(put.sig, exp);
  await s.close();
  const app2 = await createApp(loadConfig({ DATA_DIR: s.dir, ...env }), { log: () => {}, lookup: PUBLIC_DNS });
  await new Promise((r) => app2.server.listen(0, '127.0.0.1', r));
  const g2 = await (await fetch(`http://127.0.0.1:${app2.server.address().port}/servers`, { headers: H })).json();
  assert.equal(g2.servers.length, 2);
  await app2.close();
});

test('حذف سرور: آرشیو دائمی + انتقال داده به سرور بعدی', async () => {
  const B = await boot({ ADMIN_TOKEN: 'adm', SYNC_TOKEN: 'tok', VAULT_SECRET: 's' });
  const A = await boot({ ADMIN_TOKEN: 'adm', SYNC_TOKEN: 'tok', VAULT_SECRET: 's' }, {
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    fetch: (u, o) => fetch(String(u).replace(/^https?:\/\/[^/]+/, B.base), o),
  });
  // سرور حذف‌شده «x.example.com» داده دارد؛ سرور بعدی «b.example.com» (همان B)
  await fetch(A.base + '/sync', { method: 'POST', headers: { 'x-tradyar-token': 'tok' }, body: ENVELOPE });
  const put = (list) => fetch(A.base + '/servers', { method: 'PUT', headers: { 'x-admin-token': 'adm', 'content-type': 'application/json' }, body: JSON.stringify({ servers: list }) });
  await put([{ url: 'https://x.example.com' }, { url: 'https://b.example.com' }]);
  const r = await (await put([{ url: 'https://b.example.com' }])).json();
  assert.equal(r.migrations.length, 1);
  assert.equal(r.migrations[0].to, 'https://b.example.com');
  assert.equal(r.migrations[0].ok, true);
  const arch = JSON.parse(fs.readFileSync(path.join(A.dir, 'secrets', 'servers-archive.json'), 'utf8'));
  assert.equal(arch[0].url, 'https://x.example.com');
  assert.ok(fs.readdirSync(path.join(A.dir, 'secrets', 'inherited')).length >= 1);
  assert.ok(fs.readdirSync(path.join(B.dir, 'secrets', 'inherited')).length >= 1);
  const got = await (await fetch(B.base + '/sync', { headers: { 'x-tradyar-token': 'tok' } })).text();
  assert.ok(got.includes('"ct"'));
  await A.close(); await B.close();
});

test('مدیر دستی (AUTO_APPROVE_ADMINS=0): ثبت اولین گوشی، تأیید گوشی بعدی، بدون ADMIN_TOKEN', async () => {
  const s = await boot({ SYNC_TOKEN: 'tok', AUTO_APPROVE_ADMINS: '0' });
  const H = (k) => ({ 'x-tradyar-token': 'tok', 'x-admin-token': k, 'content-type': 'application/json' });
  const K1 = 'A'.repeat(40), K2 = 'B'.repeat(40), K3 = 'C'.repeat(40);
  const claim = (k) => fetch(s.base + '/admin/claim', { method: 'POST', headers: H(k), body: JSON.stringify({ key: k, label: 'p' }) });
  assert.equal((await claim(K1)).status, 200);
  assert.equal((await fetch(s.base + '/vault', { method: 'PUT', headers: H(K1), body: JSON.stringify({ providers: [{ id: 'p1', name: 'x', kind: 'openai', base: 'https://api.openai.com/v1', model: 'm', key: 'sk-secret123456', enabled: true }] }) })).status, 200);
  assert.equal((await claim(K2)).status, 202);
  assert.equal((await fetch(s.base + '/vault', { headers: H(K2) })).status, 401);
  const reqs = await (await fetch(s.base + '/admin/requests', { headers: H(K1) })).json();
  assert.equal(reqs.requests.length, 1);
  await fetch(s.base + '/admin/approve', { method: 'POST', headers: H(K1), body: JSON.stringify({ id: reqs.requests[0].id }) });
  const v = await (await fetch(s.base + '/vault', { headers: H(K2) })).json();
  assert.equal(v.ok, true);
  assert.ok(!JSON.stringify(v).includes('sk-secret123456'));
  assert.equal((await fetch(s.base + '/vault', { headers: H(K3) })).status, 401);
  const mode = fs.statSync(path.join(s.dir, 'secrets')).mode & 0o777;
  assert.equal(mode, 0o700);
  await s.close();
});

test('اسرار: سند همگام‌سازی کلید ندارد و خطای AI برای کاربر جزئیات نمی‌دهد', async () => {
  const s = await boot({ SYNC_TOKEN: 'tok' });
  const doc = JSON.stringify({ v: 1, users: [], settings: { irApiKey: 'sk-LEAK1234567', extraServers: [] }, aiKeys: { x: 1 } });
  await fetch(s.base + '/sync', { method: 'POST', headers: { 'x-tradyar-token': 'tok' }, body: doc });
  const got = await (await fetch(s.base + '/sync', { headers: { 'x-tradyar-token': 'tok' } })).text();
  assert.ok(!got.includes('sk-LEAK1234567') && !got.includes('aiKeys'));
  const r = await fetch(s.base + '/ai', { method: 'POST', headers: { 'x-tradyar-token': 'tok', 'content-type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'hi' }] }) });
  assert.equal(r.status, 503);
  await s.close();
});

test('مدیر خودکار: گوشی دوم بدون تأیید دستی مدیر می‌شود', async () => {
  const s = await boot({ SYNC_TOKEN: 'tok' });
  const H = (k) => ({ 'x-tradyar-token': 'tok', 'x-admin-token': k, 'content-type': 'application/json' });
  const K1 = 'A'.repeat(40), K2 = 'B'.repeat(40);
  const claim = (k) => fetch(s.base + '/admin/claim', { method: 'POST', headers: H(k), body: JSON.stringify({ key: k, label: 'p' }) });
  assert.equal((await claim(K1)).status, 200);
  const r2 = await claim(K2);
  assert.equal(r2.status, 200);
  assert.equal((await r2.json()).status, 'admin');
  assert.equal((await fetch(s.base + '/vault', { headers: H(K2) })).status, 200);
  await s.close();
});

test('ادغام سمت سرور: دو گوشی هم‌زمان؛ تیکت هیچ‌کدام گم نمی‌شود', async () => {
  const s = await boot({ SYNC_TOKEN: 'tok' });
  const H = { 'x-tradyar-token': 'tok', 'content-type': 'text/plain' };
  const post = (doc) => fetch(s.base + '/sync', { method: 'POST', headers: H, body: JSON.stringify(doc) });
  await post({ v: 1, tickets: [{ id: 't1', subject: 'A', updatedAt: 10 }], users: [{ id: 'u1', updatedAt: 1 }] });
  await post({ v: 1, tickets: [{ id: 't2', subject: 'B', updatedAt: 20 }], users: [{ id: 'u2', updatedAt: 2 }] });
  await post({ v: 1, tickets: [{ id: 't1', subject: 'A2', updatedAt: 30 }] });
  const g = (await (await fetch(s.base + '/sync', { headers: { 'x-tradyar-token': 'tok' } })).json()).doc;
  try {
  assert.deepEqual(g.tickets.map((t) => t.id).sort(), ['t1', 't2']);
  assert.equal(g.tickets.find((t) => t.id === 't1').subject, 'A2');
  assert.equal(g.users.length, 2);
  } finally { await s.close(); }
});
