'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp, loadConfig, isPrivateIp } = require('../server.js');

const PUBLIC_DNS = async () => [{ address: '93.184.216.34', family: 4 }];
const ENVELOPE = JSON.stringify({ v: 2, encrypted: true, salt: 'AA', iv: 'BB', ct: 'CC', hmac: 'DD' });

async function boot(env = {}, deps = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tyar-'));
  const cfg = loadConfig({ DATA_DIR: dir, ...env });
  const app = await createApp(cfg, { log: () => {}, lookup: PUBLIC_DNS, ...deps });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  return { app, base, dir, close: () => app.close() };
}

test('health و CORS', async () => {
  const s = await boot();
  const h = await (await fetch(s.base + '/health')).json();
  assert.equal(h.ok, true);
  const pre = await fetch(s.base + '/', { method: 'OPTIONS' });
  assert.equal(pre.status, 204);
  assert.equal(pre.headers.get('access-control-allow-origin'), '*');
  await s.close();
});

test('sync: خالی → ذخیره → خواندن → ماندگاری بعد از ریستارت', async () => {
  const s = await boot();
  assert.deepEqual(await (await fetch(s.base + '/')).json(), { ok: false, reason: 'no_data' });
  const post = await fetch(s.base + '/', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: ENVELOPE });
  assert.equal((await post.json()).ok, true);
  const got = await (await fetch(s.base + '/')).json();
  assert.equal(got.ok, true);
  assert.deepEqual(got.doc, JSON.parse(ENVELOPE));
  await s.close();

  const cfg = loadConfig({ DATA_DIR: s.dir });
  const app2 = await createApp(cfg, { log: () => {}, lookup: PUBLIC_DNS });
  await new Promise((r) => app2.server.listen(0, '127.0.0.1', r));
  const again = await (await fetch(`http://127.0.0.1:${app2.server.address().port}/`)).json();
  assert.deepEqual(again.doc, JSON.parse(ENVELOPE));
  await app2.close();
});

test('sync: gzip وقتی کلاینت بخواهد', async () => {
  const s = await boot();
  const big = JSON.stringify({ v: 1, users: Array.from({ length: 300 }, (_, i) => ({ id: i, name: 'user' + i })) });
  await fetch(s.base + '/', { method: 'POST', body: big });
  const r = await fetch(s.base + '/', { headers: { 'Accept-Encoding': 'gzip' } });
  assert.equal(r.headers.get('content-encoding'), 'gzip');
  const j = await r.json(); // fetch خودش باز می‌کند
  assert.equal(j.ok, true);
  assert.equal(j.doc.users.length, 300);
  const plain = await fetch(s.base + '/', { headers: { 'Accept-Encoding': 'identity' } });
  assert.equal(plain.headers.get('content-encoding'), null);
  assert.equal((await plain.json()).doc.users.length, 300);
  await s.close();
});

test('sync: داده‌های نامعتبر رد می‌شوند و داده قبلی سالم می‌ماند', async () => {
  const s = await boot();
  await fetch(s.base + '/', { method: 'POST', body: ENVELOPE });
  for (const bad of ['garbage', '[]', '{"hello":1}', '']) {
    const r = await fetch(s.base + '/', { method: 'POST', body: bad });
    assert.equal(r.status, 400, 'باید رد شود: ' + bad);
  }
  const got = await (await fetch(s.base + '/')).json();
  assert.deepEqual(got.doc, JSON.parse(ENVELOPE));
  await s.close();
});

test('sync: سقف حجم و بکاپ خودکار', async () => {
  const s = await boot({ MAX_SYNC_BYTES: '500', SNAPSHOT_INTERVAL_MIN: '0' });
  assert.equal((await fetch(s.base + '/', { method: 'POST', body: JSON.stringify({ v: 1, x: 'a'.repeat(900) }) })).status, 413);
  await fetch(s.base + '/', { method: 'POST', body: ENVELOPE });
  await fetch(s.base + '/', { method: 'POST', body: JSON.stringify({ v: 1, second: true }) });
  const files = fs.readdirSync(path.join(s.dir, 'backups'));
  assert.ok(files.some((f) => f.startsWith('sync-')), 'بکاپ لحظه‌ای ساخته نشد');
  assert.ok(files.some((f) => f.startsWith('daily-')), 'بکاپ روزانه ساخته نشد');
  await s.close();
});

test('rate limit', async () => {
  const s = await boot({ SYNC_RATE_PER_MIN: '3' });
  const codes = [];
  for (let i = 0; i < 5; i++) codes.push((await fetch(s.base + '/')).status);
  assert.deepEqual(codes, [200, 200, 200, 429, 429]);
  await s.close();
});

test('relay: ورودی‌های ناامن رد می‌شوند', async () => {
  const s = await boot({}, { fetch: async () => { throw new Error('نباید صدا زده شود'); } });
  const q = (u) => fetch(s.base + '/relay?u=' + encodeURIComponent(u));
  assert.equal((await fetch(s.base + '/relay')).status, 400);
  assert.equal((await q('http://api.binance.com/api/v3/ping')).status, 400);          // http
  assert.equal((await q('https://evil.example.com/x')).status, 403);                    // دامنه غیرمجاز
  assert.equal((await q('https://api.binance.com.evil.com/x')).status, 403);            // جعل پسوند
  assert.equal((await q('https://127.0.0.1/x')).status, 403);                           // IP مستقیم
  assert.equal((await q('https://2130706433/x')).status, 403);                          // IP دسیمال
  assert.equal((await q('https://api.binance.com:8443/x')).status, 403);                // پورت
  assert.equal((await q('https://user:pw@api.binance.com/x')).status, 400);             // credentials
  assert.equal((await q('not a url')).status, 400);
  await s.close();
});

test('relay: دامنهٔ مجاز با DNS خصوصی رد می‌شود (SSRF)', async () => {
  const s = await boot({}, { lookup: async () => [{ address: '10.0.0.5', family: 4 }], fetch: async () => { throw new Error('x'); } });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/api/v3/ping'));
  assert.equal(r.status, 403);
  assert.equal((await r.json()).error, 'private_address');
  await s.close();
});

test('relay: مسیر موفق + کش + ادغام درخواست‌های همزمان', async () => {
  let calls = 0;
  const fakeFetch = async (url) => {
    calls++;
    await new Promise((r) => setTimeout(r, 40));
    return new Response(JSON.stringify({ price: '123', url }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  const s = await boot({ RELAY_CACHE_TTL_MS: '5000' }, { fetch: fakeFetch });
  const u = s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT');
  const burst = await Promise.all(Array.from({ length: 6 }, () => fetch(u)));
  for (const r of burst) {
    assert.equal(r.status, 200);
    assert.equal(r.headers.get('x-tradyar-relay'), '1');
    assert.equal((await r.json()).price, '123');
  }
  assert.equal(calls, 1, 'درخواست‌های همزمان باید یکی شوند');
  const again = await fetch(u);
  assert.equal(again.headers.get('x-relay-cache'), 'HIT');
  assert.equal(calls, 1);
  await s.close();
});

test('relay: POST (هوش مصنوعی) مستقیم عبور می‌کند و کش نمی‌شود', async () => {
  let seen;
  const fakeFetch = async (url, init) => {
    seen = init;
    return new Response('{"choices":[{"message":{"content":"سلام"}}]}', { status: 200, headers: { 'content-type': 'application/json' } });
  };
  const s = await boot({}, { fetch: fakeFetch });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://text.pollinations.ai/openai'), {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"model":"openai"}',
  });
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('x-tradyar-relay'), '1');
  assert.match(await r.text(), /سلام/);
  assert.equal(seen.method, 'POST');
  assert.equal(seen.body, '{"model":"openai"}');
  await s.close();
});

test('relay: ریدایرکت به دامنهٔ غیرمجاز بلاک می‌شود', async () => {
  const fakeFetch = async () => new Response(null, { status: 302, headers: { location: 'https://evil.example.com/steal' } });
  const s = await boot({}, { fetch: fakeFetch });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/x'));
  assert.equal(r.status, 403);
  await s.close();
});

test('relay: خطای 451 مقصد عیناً عبور داده می‌شود و در آمار ثبت می‌شود', async () => {
  const fakeFetch = async () => new Response('{"msg":"restricted"}', { status: 451, headers: { 'content-type': 'application/json' } });
  const s = await boot({ ADMIN_TOKEN: 'secret-token-123' }, { fetch: fakeFetch });
  const r = await fetch(s.base + '/relay?u=' + encodeURIComponent('https://api.binance.com/api/v3/ping'));
  assert.equal(r.status, 451);
  const st = await (await fetch(s.base + '/status', { headers: { Authorization: 'Bearer secret-token-123' } })).json();
  assert.equal(st.stats.hosts['api.binance.com'].s451, 1);
  await s.close();
});

test('status: نیازمند توکن', async () => {
  const s = await boot({ ADMIN_TOKEN: 'secret-token-123' });
  assert.equal((await fetch(s.base + '/status')).status, 401);
  assert.equal((await fetch(s.base + '/status', { headers: { Authorization: 'Bearer wrong' } })).status, 401);
  assert.equal((await fetch(s.base + '/status', { headers: { Authorization: 'Bearer secret-token-123' } })).status, 200);
  await s.close();
  const s2 = await boot(); // بدون توکن → غیرفعال
  assert.equal((await fetch(s2.base + '/status')).status, 404);
  await s2.close();
});

test('مسیر ناشناخته 404 و isPrivateIp', async () => {
  const s = await boot();
  assert.equal((await fetch(s.base + '/etc/passwd')).status, 404);
  await s.close();
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.1.1', '172.16.0.1', '169.254.169.254', '100.64.0.1', '::1', 'fd00::1', '::ffff:7f00:1', '::ffff:10.0.0.1']) {
    assert.equal(isPrivateIp(ip), true, ip);
  }
  for (const ip of ['93.184.216.34', '8.8.8.8', '2606:4700::1111']) assert.equal(isPrivateIp(ip), false, ip);
});
