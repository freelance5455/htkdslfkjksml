'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { createApp, loadConfig } = require('../server.js');
const X = require('../exchanges.js');

const PUBLIC_DNS = async () => [{ address: '93.184.216.34', family: 4 }];
const hm = (a, k, m, e = 'hex') => crypto.createHmac(a, k).update(m).digest(e);
const CREDS = { apiKey: 'KEY123', apiSecret: 'SECRET456', passphrase: 'PASS789' };

/* fetch ساختگی: درخواست‌ها را ضبط و بر اساس آدرس پاسخ می‌دهد */
function mockFetch(routes) {
  const calls = [];
  const fn = async (url, init = {}) => {
    const u = new URL(url);
    calls.push({ url: u, method: init.method || 'GET', headers: init.headers || {}, body: init.body });
    for (const [match, reply] of routes) {
      if (typeof match === 'string' ? (u.host + u.pathname).includes(match) : match(u, init)) {
        const r = typeof reply === 'function' ? reply(u, init) : reply;
        return new Response(JSON.stringify(r), { status: 200, headers: { 'content-type': 'application/json' } });
      }
    }
    return new Response(JSON.stringify({ unmatched: u.host + u.pathname }), { status: 404 });
  };
  fn.calls = calls;
  return fn;
}

async function boot(routes, env = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tyar-trade-'));
  const cfg = loadConfig({ DATA_DIR: dir, ...env });
  const f = mockFetch(routes);
  const app = await createApp(cfg, { log: () => {}, lookup: PUBLIC_DNS, fetch: f, protectDelayMs: 0, now: () => 1700000000000 });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const post = async (op, body, headers = {}) => {
    const r = await fetch(`${base}/trade/v1/${op}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });
    return { status: r.status, json: await r.json() };
  };
  return { app, f, post, base, close: () => app.close() };
}

/* ---------------- ابزارهای عمومی ---------------- */

test('floorToStep / decimalsOf / prepareOrder', () => {
  assert.equal(X.decimalsOf('0.00100000'), 3);
  assert.equal(X.decimalsOf(1e-7), 7);
  assert.equal(X.decimalsOf(1), 0);
  assert.equal(X.floorToStep(0.123456, 0.001), '0.123');
  assert.equal(X.floorToStep(1234.5678, 0.01), '1234.56');
  assert.equal(X.floorToStep(0.3, 0.1), '0.3'); // خطای ممیز شناور نباید 0.2 بدهد
  assert.equal(X.floorToStep(5, 1), '5');
  const mk = { symbol: 'PEPEUSDT', base: 'PEPE', quote: 'USDT', tickSize: 1e-8, stepSize: 1, minQty: 1, minNotional: 5, trading: true, type: 'spot' };
  const o = X.prepareOrder(mk, { side: 'buy', type: 'market', quoteQty: 12.3456 });
  assert.equal(o.quoteQty, '12.34');
  assert.throws(() => X.prepareOrder(mk, { side: 'buy', type: 'market', quoteQty: 2 }), /حداقل/);
  const l = X.prepareOrder(mk, { side: 'buy', type: 'limit', price: 0.00001234567, qty: 1234567.89 });
  assert.equal(l.price, '0.00001234');
  assert.equal(l.qty, '1234567');
  assert.throws(() => X.prepareOrder(null, { side: 'buy' }), /پیدا نشد/);
  assert.throws(() => X.prepareOrder({ ...mk, trading: false }, { side: 'buy', type: 'market', quoteQty: 10 }), /غیرفعال/);
  assert.throws(() => X.prepareOrder(mk, { side: 'hold' }), /side/);
});

test('امضای Binance با بردار تست رسمی مستندات', () => {
  const secret = 'NhqPtmdSJYdKjVHjA7PZj4Mge3R5YNiP1e3UZjInClVN65XAbvqqM6A7H5fATj0j';
  const q = 'symbol=LTCBTC&side=BUY&type=LIMIT&timeInForce=GTC&quantity=1&price=0.1&recvWindow=5000&timestamp=1499827319559';
  assert.equal(X.hmac('sha256', secret, q), 'c8db56825ae71d6d79447849e617115f4a920fa2acdcab2b053c4b2838bd6b71');
});

/* ---------------- مسیرهای بازار (بدون کلید) ---------------- */

test('markets/tickers/klines: LBank — همهٔ جفت‌ارزها و میم‌کوین‌ها', async () => {
  const s = await boot([
    ['lbkex.com/v2/accuracy.do', { result: 'true', data: [{ symbol: 'pepe_usdt', quantityAccuracy: '0', priceAccuracy: '10', minTranQua: '1' }, { symbol: 'btc_usdt', quantityAccuracy: '6', priceAccuracy: '2', minTranQua: '0.0001' }] }],
    ['lbkex.com/v2/ticker/24hr.do', { result: 'true', data: [{ symbol: 'pepe_usdt', ticker: { latest: '0.0000123', change: '5.5', turnover: '900000', high: '0.00002', low: '0.00001' } }] }],
    ['lbkex.com/v2/kline.do', { result: 'true', data: [[1700000000, '1', '2', '0.5', '1.5', '100'], [1700003600, '1.5', '2', '1', '1.8', '80']] }],
  ]);
  const m = await s.post('markets', { exchange: 'lbank' });
  assert.equal(m.json.markets.length, 2);
  assert.deepEqual(m.json.markets.map((x) => x.base), ['PEPE', 'BTC']);
  assert.equal(m.json.markets[0].tickSize, 1e-10);
  const t = await s.post('tickers', { exchange: 'lbank' });
  assert.equal(t.json.tickers[0].quoteVol, 900000);
  const k = await s.post('klines', { exchange: 'lbank', symbol: 'pepe_usdt', interval: '1h', limit: 100 });
  assert.deepEqual(k.json.klines[0], [1700000000000, 1, 2, 0.5, 1.5, 100]);
  const call = s.f.calls.find((c) => c.url.pathname === '/v2/kline.do');
  assert.equal(call.url.searchParams.get('type'), 'hour1');
  assert.equal(call.url.searchParams.get('size'), '100');
  await s.close();
});

test('markets: Binance قوانین فیلتر + MEXC + Bybit + OKX + Gate + Bitget + KuCoin + XT + Bitunix', async () => {
  const s = await boot([
    ['api.binance.com/api/v3/exchangeInfo', { symbols: [{ symbol: 'DOGEUSDT', status: 'TRADING', baseAsset: 'DOGE', quoteAsset: 'USDT', isSpotTradingAllowed: true, filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.00001000' }, { filterType: 'LOT_SIZE', stepSize: '1.00000000', minQty: '1.00000000' }, { filterType: 'NOTIONAL', minNotional: '5.00000000' }] }] }],
    ['api.mexc.com/api/v3/exchangeInfo', { symbols: [{ symbol: 'WIFUSDT', status: '1', baseAsset: 'WIF', quoteAsset: 'USDT', isSpotTradingAllowed: true, quoteAssetPrecision: 4, baseSizePrecision: '0.01', quoteAmountPrecision: '1', filters: [] }] }],
    ['api.bybit.com/v5/market/instruments-info', { retCode: 0, result: { list: [{ symbol: 'BONKUSDT', baseCoin: 'BONK', quoteCoin: 'USDT', status: 'Trading', lotSizeFilter: { basePrecision: '1', minOrderQty: '10', minOrderAmt: '1' }, priceFilter: { tickSize: '0.00000001' } }] } }],
    ['okx.com/api/v5/public/instruments', { code: '0', data: [{ instId: 'SHIB-USDT', baseCcy: 'SHIB', quoteCcy: 'USDT', state: 'live', tickSz: '0.00000001', lotSz: '1', minSz: '1' }] }],
    ['api.gateio.ws/api/v4/spot/currency_pairs', [{ id: 'FLOKI_USDT', base: 'FLOKI', quote: 'USDT', trade_status: 'tradable', precision: 8, amount_precision: 2, min_base_amount: '1', min_quote_amount: '1' }]],
    ['api.bitget.com/api/v2/spot/public/symbols', { code: '00000', data: [{ symbol: 'PEPEUSDT', baseCoin: 'PEPE', quoteCoin: 'USDT', status: 'online', pricePrecision: '10', quantityPrecision: '0', minTradeUSDT: '1' }] }],
    ['api.kucoin.com/api/v2/symbols', { code: '200000', data: [{ symbol: 'TURBO-USDT', baseCurrency: 'TURBO', quoteCurrency: 'USDT', enableTrading: true, priceIncrement: '0.000001', baseIncrement: '0.01', baseMinSize: '1', minFunds: '0.1' }] }],
    ['sapi.xt.com/v4/public/symbol', { rc: 0, result: { symbols: [{ symbol: 'doge_usdt', state: 'ONLINE', tradingEnabled: true, baseCurrency: 'doge', quoteCurrency: 'usdt', pricePrecision: 6, quantityPrecision: 1 }] } }],
    ['fapi.bitunix.com/api/v1/futures/market/trading_pairs', { code: 0, data: [{ symbol: 'PEPEUSDT', base: 'PEPE', quote: 'USDT', minTradeVolume: '1000', basePrecision: 0, quotePrecision: 8, maxLeverage: 50, symbolStatus: 'OPEN' }] }],
  ]);
  const get = async (ex) => (await s.post('markets', { exchange: ex })).json.markets[0];
  const b = await get('binance'); assert.deepEqual([b.symbol, b.tickSize, b.stepSize, b.minNotional, b.trading], ['DOGEUSDT', 0.00001, 1, 5, true]);
  const mx = await get('mexc'); assert.deepEqual([mx.base, mx.tickSize, mx.stepSize, mx.trading], ['WIF', 0.0001, 0.01, true]);
  const by = await get('bybit'); assert.deepEqual([by.symbol, by.stepSize, by.minNotional], ['BONKUSDT', 1, 1]);
  const ok = await get('okx'); assert.deepEqual([ok.symbol, ok.base, ok.quote], ['SHIB-USDT', 'SHIB', 'USDT']);
  const g = await get('gate'); assert.deepEqual([g.tickSize, g.stepSize], [1e-8, 0.01]);
  const bg = await get('bitget'); assert.deepEqual([bg.tickSize, bg.stepSize], [1e-10, 1]);
  const ku = await get('kucoin'); assert.deepEqual([ku.tickSize, ku.stepSize], [0.000001, 0.01]);
  const xt = await get('xt'); assert.deepEqual([xt.symbol, xt.base, xt.quote], ['doge_usdt', 'DOGE', 'USDT']);
  const bx = await get('bitunix'); assert.deepEqual([bx.type, bx.maxLeverage, bx.minQty], ['futures', 50, 1000]);
  await s.close();
});

test('tickers/klines: نرمال‌سازی همهٔ صرافی‌ها', async () => {
  const s = await boot([
    ['api.bybit.com/v5/market/kline', { retCode: 0, result: { list: [['1700003600000', '2', '3', '1', '2.5', '10', '25'], ['1700000000000', '1', '2', '0.5', '2', '9', '18']] } }],
    ['okx.com/api/v5/market/candles', { code: '0', data: [['1700003600000', '2', '3', '1', '2.5', '10', '0', '0', '1'], ['1700000000000', '1', '2', '0.5', '2', '9', '0', '0', '1']] }],
    ['api.kucoin.com/api/v1/market/candles', { code: '200000', data: [['1700003600', '2', '2.5', '3', '1', '10', '25'], ['1700000000', '1', '2', '2', '0.5', '9', '18']] }],
    ['api.gateio.ws/api/v4/spot/candlesticks', [['1700000000', '18', '2', '2', '0.5', '1', '9', 'true']]],
    ['api.bitget.com/api/v2/spot/market/candles', { code: '00000', data: [['1700003600000', '2', '3', '1', '2.5', '10'], ['1700000000000', '1', '2', '0.5', '2', '9']] }],
    ['sapi.xt.com/v4/public/kline', { rc: 0, result: [{ t: 1700003600000, o: '2', c: '2.5', h: '3', l: '1', v: '10', q: '25' }, { t: 1700000000000, o: '1', c: '2', h: '2', l: '0.5', v: '9', q: '18' }] }],
    ['fapi.bitunix.com/api/v1/futures/market/kline', { code: 0, data: [{ open: '2', high: '3', low: '1', close: '2.5', time: 1700003600000, baseVol: '10' }, { open: '1', high: '2', low: '0.5', close: '2', time: 1700000000000, baseVol: '9' }] }],
    ['api.mexc.com/api/v3/klines', [[1700000000000, '1', '2', '0.5', '2', '9', 1700003599999, '18']]],
    ['api.binance.com/api/v3/klines', [[1700000000000, '1', '2', '0.5', '2', '9', 1700003599999, '18']]],
    ['api.bybit.com/v5/market/tickers', { retCode: 0, result: { list: [{ symbol: 'BONKUSDT', lastPrice: '0.00002', price24hPcnt: '0.05', turnover24h: '1000', highPrice24h: '1', lowPrice24h: '0.5' }] } }],
    ['api.kucoin.com/api/v1/market/allTickers', { code: '200000', data: { ticker: [{ symbol: 'A-USDT', last: '2', changeRate: '0.1', volValue: '500', high: '3', low: '1' }] } }],
    ['sapi.xt.com/v4/public/ticker/24h', { rc: 0, result: [{ s: 'doge_usdt', c: '0.1', cr: '0.02', q: '1234', h: '0.2', l: '0.05' }] }],
  ]);
  const want = [1700000000000, 1, 2, 0.5, 2, 9];
  for (const ex of ['bybit', 'okx', 'kucoin', 'bitget', 'xt', 'bitunix']) {
    const r = await s.post('klines', { exchange: ex, symbol: 'AAA', interval: '1h', limit: 50 });
    assert.equal(r.json.ok, true, ex);
    assert.equal(r.json.klines.length, 2, ex);
    assert.equal(r.json.klines[0][0], 1700000000000, ex + ' صعودی نیست');
    assert.ok(r.json.klines[0][0] < r.json.klines[1][0], ex);
    assert.equal(r.json.klines[1][4], 2.5, ex + ' close');
  }
  // کوکوین ترتیب [t,o,c,h,l] را به [t,o,h,l,c] تبدیل می‌کند
  const ku = await s.post('klines', { exchange: 'kucoin', symbol: 'A-USDT', interval: '1h', limit: 50 });
  assert.deepEqual(ku.json.klines[0], want);
  const gt = await s.post('klines', { exchange: 'gate', symbol: 'A_USDT', interval: '1h', limit: 50 });
  assert.deepEqual(gt.json.klines[0], want);
  for (const ex of ['mexc', 'binance']) assert.deepEqual((await s.post('klines', { exchange: ex, symbol: 'AAA', interval: '1h', limit: 50 })).json.klines[0], want);
  assert.equal(s.f.calls.find((c) => c.url.host === 'api.mexc.com').url.searchParams.get('interval'), '60m');
  const t1 = await s.post('tickers', { exchange: 'bybit' }); assert.equal(t1.json.tickers[0].changePct, 5);
  const t2 = await s.post('tickers', { exchange: 'kucoin' }); assert.equal(t2.json.tickers[0].changePct, 10);
  const t3 = await s.post('tickers', { exchange: 'xt' }); assert.equal(t3.json.tickers[0].changePct, 2);
  await s.close();
});

/* ---------------- سفارش‌ها: ساختار درخواست و امضا ---------------- */

const MK = (sym, extra = {}) => ({ symbol: sym, base: 'DOGE', quote: 'USDT', trading: true, ...extra });

test('Binance: خرید مارکت با quoteOrderQty، امضای معتبر، هدر کلید', async () => {
  const s = await boot([
    ['api.binance.com/api/v3/exchangeInfo', { symbols: [{ symbol: 'DOGEUSDT', status: 'TRADING', baseAsset: 'DOGE', quoteAsset: 'USDT', filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.00001' }, { filterType: 'LOT_SIZE', stepSize: '1', minQty: '1' }, { filterType: 'NOTIONAL', minNotional: '5' }] }] }],
    ['api.binance.com/api/v3/order', { orderId: 777, status: 'FILLED', executedQty: '100', cummulativeQuoteQty: '10.5' }],
  ]);
  const r = await s.post('order', { exchange: 'binance', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 10.5 } });
  assert.equal(r.json.ok, true);
  assert.equal(r.json.orderId, '777');
  const c = s.f.calls.find((x) => x.url.pathname === '/api/v3/order');
  assert.equal(c.method, 'POST');
  assert.equal(c.headers['X-MBX-APIKEY'], 'KEY123');
  const sig = c.url.searchParams.get('signature');
  const unsigned = c.url.search.slice(1).replace(/&signature=.*$/, '');
  assert.equal(sig, hm('sha256', 'SECRET456', unsigned));
  assert.equal(c.url.searchParams.get('quoteOrderQty'), '10.50');
  assert.equal(c.url.searchParams.get('side'), 'BUY');
  assert.equal(c.url.searchParams.get('timestamp'), '1700000000000');
  // مبلغ کمتر از حداقل نوتشنال → قبل از رسیدن به صرافی رد می‌شود
  const n = s.f.calls.length;
  const low = await s.post('order', { exchange: 'binance', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 2 } });
  assert.equal(low.status, 422);
  assert.match(low.json.message, /حداقل/);
  assert.equal(s.f.calls.length, n);
  // حالت تست از /order/test
  await s.post('order', { exchange: 'binance', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 10, test: true } });
  assert.ok(s.f.calls.some((x) => x.url.pathname === '/api/v3/order/test'));
  await s.close();
});

test('Binance: خرید مارکت + OCO بومی بعد از پر شدن', async () => {
  const s = await boot([
    ['api.binance.com/api/v3/exchangeInfo', { symbols: [{ symbol: 'DOGEUSDT', status: 'TRADING', baseAsset: 'DOGE', quoteAsset: 'USDT', filters: [{ filterType: 'PRICE_FILTER', tickSize: '0.0001' }, { filterType: 'LOT_SIZE', stepSize: '1', minQty: '1' }] }] }],
    ['api.binance.com/api/v3/orderList/oco', { orderListId: 55 }],
    ['api.binance.com/api/v3/order', { orderId: 1, status: 'FILLED' }],
    ['api.binance.com/api/v3/account', { canTrade: true, balances: [{ asset: 'DOGE', free: '99.7', locked: '0' }, { asset: 'USDT', free: '5', locked: '0' }] }],
  ]);
  const r = await s.post('order', { exchange: 'binance', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 10 }, protect: { sl: 0.09, tp: 0.12, refPrice: 0.1 } });
  assert.equal(r.json.protection.native, true);
  assert.equal(r.json.protection.qty, '99');
  const oco = s.f.calls.find((x) => x.url.pathname === '/api/v3/orderList/oco');
  assert.equal(oco.url.searchParams.get('abovePrice'), '0.1200');
  assert.equal(oco.url.searchParams.get('belowStopPrice'), '0.0900');
  assert.equal(oco.url.searchParams.get('side'), 'SELL');
  // اگر OCO رد شود، سفارش ورود حفظ و دلیل شکست گزارش می‌شود (کلاینت محافظ نرم‌افزاری را فعال می‌کند)
  s.f.calls.length = 0;
  await s.close();
});

test('خرید مارکت: هر صرافی مبلغ quote را درست می‌فرستد', async () => {
  const mkRoutes = (extra) => extra;
  // LBank
  let s = await boot([
    ['lbkex.com/v2/accuracy.do', { result: 'true', data: [{ symbol: 'doge_usdt', quantityAccuracy: '0', priceAccuracy: '5', minTranQua: '1' }] }],
    ['lbkex.com/v2/create_order.do', { result: 'true', data: { order_id: 'L1' } }],
  ]);
  let r = await s.post('order', { exchange: 'lbank', creds: CREDS, order: { symbol: 'doge_usdt', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'L1');
  let c = s.f.calls.find((x) => x.url.pathname === '/v2/create_order.do');
  const form = new URLSearchParams(c.body);
  assert.equal(form.get('type'), 'buy_market');
  assert.equal(form.get('price'), '10.00');
  assert.equal(form.get('api_key'), 'KEY123');
  assert.equal(form.get('signature_method'), 'HmacSHA256');
  assert.ok(form.get('echostr').length >= 30);
  // بازتولید امضا: مرتب‌سازی → MD5 بزرگ → HMAC
  const params = {}; for (const [k, v] of form) if (k !== 'sign') params[k] = v;
  const prepared = Object.keys(params).sort().map((k) => `${k}=${params[k]}`).join('&');
  assert.equal(form.get('sign'), hm('sha256', 'SECRET456', X.md5(prepared).toUpperCase()));
  assert.equal(c.headers['Content-Type'], 'application/x-www-form-urlencoded');
  await s.close();

  // XT
  s = await boot([
    ['sapi.xt.com/v4/public/symbol', { rc: 0, result: { symbols: [{ symbol: 'doge_usdt', state: 'ONLINE', tradingEnabled: true, baseCurrency: 'doge', quoteCurrency: 'usdt', pricePrecision: 5, quantityPrecision: 0 }] } }],
    ['sapi.xt.com/v4/order', { rc: 0, mc: 'SUCCESS', result: { orderId: 'X1' } }],
  ]);
  r = await s.post('order', { exchange: 'xt', creds: CREDS, order: { symbol: 'doge_usdt', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'X1');
  c = s.f.calls.find((x) => x.url.pathname === '/v4/order');
  const b = JSON.parse(c.body);
  assert.deepEqual([b.symbol, b.side, b.type, b.quoteQty, b.bizType], ['doge_usdt', 'BUY', 'MARKET', '10.00', 'SPOT']);
  const hdr = `xt-validate-algorithms=HmacSHA256&xt-validate-appkey=KEY123&xt-validate-recvwindow=10000&xt-validate-timestamp=1700000000000`;
  assert.equal(c.headers['xt-validate-signature'], hm('sha256', 'SECRET456', hdr + '#POST#/v4/order#' + c.body));
  await s.close();

  // OKX
  s = await boot([
    ['okx.com/api/v5/public/instruments', { code: '0', data: [{ instId: 'DOGE-USDT', baseCcy: 'DOGE', quoteCcy: 'USDT', state: 'live', tickSz: '0.00001', lotSz: '1', minSz: '1' }] }],
    ['okx.com/api/v5/trade/order', { code: '0', data: [{ ordId: 'O1', sCode: '0', sMsg: '' }] }],
  ]);
  r = await s.post('order', { exchange: 'okx', creds: CREDS, order: { symbol: 'DOGE-USDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'O1');
  c = s.f.calls.find((x) => x.url.pathname === '/api/v5/trade/order');
  assert.deepEqual(JSON.parse(c.body), { instId: 'DOGE-USDT', tdMode: 'cash', side: 'buy', ordType: 'market', sz: '10.00', tgtCcy: 'quote_ccy' });
  assert.equal(c.headers['OK-ACCESS-TIMESTAMP'], '2023-11-14T22:13:20.000Z');
  assert.equal(c.headers['OK-ACCESS-SIGN'], hm('sha256', 'SECRET456', '2023-11-14T22:13:20.000ZPOST/api/v5/trade/order' + c.body, 'base64'));
  assert.equal(c.headers['OK-ACCESS-PASSPHRASE'], 'PASS789');
  await s.close();

  // OKX: خطای سطح سفارش (sCode≠0) باید خطا شود نه موفقیت
  s = await boot([
    ['okx.com/api/v5/public/instruments', { code: '0', data: [{ instId: 'DOGE-USDT', baseCcy: 'DOGE', quoteCcy: 'USDT', state: 'live', tickSz: '0.00001', lotSz: '1', minSz: '1' }] }],
    ['okx.com/api/v5/trade/order', { code: '1', msg: 'All operations failed', data: [{ sCode: '51008', sMsg: 'Insufficient balance' }] }],
  ]);
  r = await s.post('order', { exchange: 'okx', creds: CREDS, order: { symbol: 'DOGE-USDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.status, 422); assert.equal(r.json.message, 'Insufficient balance'); assert.equal(r.json.code, '51008');
  await s.close();

  // KuCoin
  s = await boot([
    ['api.kucoin.com/api/v2/symbols', { code: '200000', data: [{ symbol: 'DOGE-USDT', baseCurrency: 'DOGE', quoteCurrency: 'USDT', enableTrading: true, priceIncrement: '0.00001', baseIncrement: '1', baseMinSize: '1', minFunds: '1' }] }],
    ['api.kucoin.com/api/v1/orders', { code: '200000', data: { orderId: 'K1' } }],
  ]);
  r = await s.post('order', { exchange: 'kucoin', creds: CREDS, order: { symbol: 'DOGE-USDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'K1');
  c = s.f.calls.find((x) => x.url.pathname === '/api/v1/orders');
  assert.equal(JSON.parse(c.body).funds, '10.00');
  assert.equal(c.headers['KC-API-SIGN'], hm('sha256', 'SECRET456', '1700000000000POST/api/v1/orders' + c.body, 'base64'));
  assert.equal(c.headers['KC-API-PASSPHRASE'], hm('sha256', 'SECRET456', 'PASS789', 'base64'));
  assert.equal(c.headers['KC-API-KEY-VERSION'], '2');
  await s.close();

  // Gate
  s = await boot([
    ['api.gateio.ws/api/v4/spot/currency_pairs', [{ id: 'DOGE_USDT', base: 'DOGE', quote: 'USDT', trade_status: 'tradable', precision: 5, amount_precision: 0, min_base_amount: '1', min_quote_amount: '1' }]],
    ['api.gateio.ws/api/v4/spot/orders', { id: 'G1', status: 'closed' }],
  ]);
  r = await s.post('order', { exchange: 'gate', creds: CREDS, order: { symbol: 'DOGE_USDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'G1');
  c = s.f.calls.find((x) => x.url.pathname === '/api/v4/spot/orders');
  const gb = JSON.parse(c.body);
  assert.deepEqual([gb.type, gb.amount, gb.time_in_force, gb.side], ['market', '10.00', 'ioc', 'buy']);
  const payload = ['POST', '/api/v4/spot/orders', '', crypto.createHash('sha512').update(c.body).digest('hex'), '1700000000'].join('\n');
  assert.equal(c.headers.SIGN, hm('sha512', 'SECRET456', payload));
  assert.equal(c.headers.KEY, 'KEY123');
  await s.close();

  // Bitget
  s = await boot([
    ['api.bitget.com/api/v2/spot/public/symbols', { code: '00000', data: [{ symbol: 'DOGEUSDT', baseCoin: 'DOGE', quoteCoin: 'USDT', status: 'online', pricePrecision: '5', quantityPrecision: '0', minTradeUSDT: '1' }] }],
    ['api.bitget.com/api/v2/spot/trade/place-order', { code: '00000', data: { orderId: 'B1' } }],
  ]);
  r = await s.post('order', { exchange: 'bitget', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'B1');
  c = s.f.calls.find((x) => x.url.pathname === '/api/v2/spot/trade/place-order');
  assert.equal(JSON.parse(c.body).size, '10.00');
  assert.equal(c.headers['ACCESS-SIGN'], hm('sha256', 'SECRET456', '1700000000000POST/api/v2/spot/trade/place-order' + c.body, 'base64'));
  await s.close();

  // Bybit
  s = await boot([
    ['api.bybit.com/v5/market/instruments-info', { retCode: 0, result: { list: [{ symbol: 'DOGEUSDT', baseCoin: 'DOGE', quoteCoin: 'USDT', status: 'Trading', lotSizeFilter: { basePrecision: '0.1', minOrderQty: '1', minOrderAmt: '1' }, priceFilter: { tickSize: '0.00001' } }] } }],
    ['api.bybit.com/v5/order/create', { retCode: 0, result: { orderId: 'Y1' } }],
  ]);
  r = await s.post('order', { exchange: 'bybit', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'Y1');
  c = s.f.calls.find((x) => x.url.pathname === '/v5/order/create');
  const yb = JSON.parse(c.body);
  assert.deepEqual([yb.category, yb.side, yb.orderType, yb.qty, yb.marketUnit], ['spot', 'Buy', 'Market', '10.00', 'quoteCoin']);
  assert.equal(c.headers['X-BAPI-SIGN'], hm('sha256', 'SECRET456', '1700000000000KEY12310000' + c.body));
  await s.close();

  // MEXC
  s = await boot([
    ['api.mexc.com/api/v3/exchangeInfo', { symbols: [{ symbol: 'DOGEUSDT', status: '1', baseAsset: 'DOGE', quoteAsset: 'USDT', isSpotTradingAllowed: true, quoteAssetPrecision: 5, baseSizePrecision: '1', quoteAmountPrecision: '1' }] }],
    ['api.mexc.com/api/v3/order', { symbol: 'DOGEUSDT', orderId: 'M1' }],
  ]);
  r = await s.post('order', { exchange: 'mexc', creds: CREDS, order: { symbol: 'DOGEUSDT', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.json.orderId, 'M1');
  c = s.f.calls.find((x) => x.url.pathname === '/api/v3/order');
  assert.equal(c.headers['X-MEXC-APIKEY'], 'KEY123');
  assert.equal(c.url.searchParams.get('signature'), hm('sha256', 'SECRET456', c.url.search.slice(1).replace(/&signature=.*$/, '')));
  assert.equal(r.json.protection, undefined);
  await s.close();
  void mkRoutes; void MK;
});

test('Bitunix: سفارش فیوچرز با SL/TP همراه، اهرم، و امضای دوبل SHA256', async () => {
  const s = await boot([
    ['fapi.bitunix.com/api/v1/futures/market/trading_pairs', { code: 0, data: [{ symbol: 'PEPEUSDT', base: 'PEPE', quote: 'USDT', minTradeVolume: '1000', basePrecision: 0, quotePrecision: 8, maxLeverage: 50, symbolStatus: 'OPEN' }] }],
    ['fapi.bitunix.com/api/v1/futures/account/change_leverage', { code: 0, data: [] }],
    ['fapi.bitunix.com/api/v1/futures/trade/place_order', { code: 0, data: { orderId: 'U1', clientId: 'c' } }],
  ]);
  const r = await s.post('order', { exchange: 'bitunix', creds: CREDS, order: { symbol: 'PEPEUSDT', side: 'sell', type: 'market', qty: 5000.7, sl: 0.0000123456789, tp: 0.00001, leverage: 5 } });
  assert.equal(r.json.ok, true);
  assert.equal(r.json.protection.native, true);
  const c = s.f.calls.find((x) => x.url.pathname === '/api/v1/futures/trade/place_order');
  const b = JSON.parse(c.body);
  assert.deepEqual([b.symbol, b.side, b.tradeSide, b.orderType, b.qty, b.slPrice, b.tpPrice], ['PEPEUSDT', 'SELL', 'OPEN', 'MARKET', '5000', '0.00001234', '0.00001000']);
  const digest = crypto.createHash('sha256').update(c.headers.nonce + c.headers.timestamp + 'KEY123' + c.body).digest('hex');
  assert.equal(c.headers.sign, crypto.createHash('sha256').update(digest + 'SECRET456').digest('hex'));
  assert.equal(c.headers['api-key'], 'KEY123');
  const lev = s.f.calls.find((x) => x.url.pathname.endsWith('change_leverage'));
  assert.equal(JSON.parse(lev.body).leverage, 5);
  // اهرم بیش از سقف رد می‌شود
  const hi = await s.post('order', { exchange: 'bitunix', creds: CREDS, order: { symbol: 'PEPEUSDT', side: 'buy', type: 'market', qty: 5000, leverage: 125 } });
  assert.equal(hi.status, 422);
  // حجم کمتر از حداقل
  const lo = await s.post('order', { exchange: 'bitunix', creds: CREDS, order: { symbol: 'PEPEUSDT', side: 'buy', type: 'market', qty: 10 } });
  assert.match(lo.json.message, /حداقل/);
  await s.close();
});

test('Bitunix: امضای GET با پارامتر کوئری مرتب‌شده', async () => {
  const s = await boot([['fapi.bitunix.com/api/v1/futures/account', { code: 0, data: { marginCoin: 'USDT', available: '120.5', frozen: '0', margin: '10' } }]]);
  const r = await s.post('balance', { exchange: 'bitunix', creds: CREDS });
  assert.equal(r.json.balances[0].free, 120.5);
  const c = s.f.calls[0];
  const digest = crypto.createHash('sha256').update(c.headers.nonce + c.headers.timestamp + 'KEY123' + 'marginCoinUSDT').digest('hex');
  assert.equal(c.headers.sign, crypto.createHash('sha256').update(digest + 'SECRET456').digest('hex'));
  await s.close();
});

test('balance + verify: LBank/XT/Binance و هشدار دسترسی برداشت', async () => {
  let s = await boot([['lbkex.com/v2/user_info.do', { result: 'true', data: { free: { usdt: '50.5', btc: '0' }, freeze: { usdt: '1' } } }]]);
  let r = await s.post('verify', { exchange: 'lbank', creds: CREDS });
  assert.deepEqual(r.json.balances, [{ asset: 'USDT', free: 50.5, locked: 1 }]);
  await s.close();
  s = await boot([['sapi.xt.com/v4/balances', { rc: 0, result: { assets: [{ currency: 'usdt', availableAmount: '10', frozenAmount: '0' }] } }]]);
  r = await s.post('balance', { exchange: 'xt', creds: CREDS });
  assert.equal(r.json.balances[0].asset, 'USDT');
  const c = s.f.calls[0];
  assert.equal(c.headers['xt-validate-signature'], hm('sha256', 'SECRET456', 'xt-validate-algorithms=HmacSHA256&xt-validate-appkey=KEY123&xt-validate-recvwindow=10000&xt-validate-timestamp=1700000000000#GET#/v4/balances'));
  await s.close();
  s = await boot([['api.binance.com/api/v3/account', { canTrade: true, canWithdraw: true, balances: [{ asset: 'USDT', free: '5', locked: '0' }] }]]);
  r = await s.post('verify', { exchange: 'binance', creds: CREDS });
  assert.equal(r.json.warnings.length, 1);
  assert.match(r.json.warnings[0], /برداشت/);
  await s.close();
});

/* ---------------- امنیت و رفتار سرور ---------------- */

test('خطای صرافی به‌صورت 422 با پیام روشن و بدون درز کلید', async () => {
  const s = await boot([['api.binance.com/api/v3/account', { code: -2015, msg: 'Invalid API-key, IP, or permissions for action.' }]]);
  const r = await s.post('balance', { exchange: 'binance', creds: CREDS });
  assert.equal(r.status, 422);
  assert.equal(r.json.error, 'exchange_error');
  assert.match(r.json.message, /Invalid API-key/);
  assert.ok(!JSON.stringify(r.json).includes('SECRET456'));
  await s.close();
});

test('اعتبارسنجی ورودی: صرافی ناشناس، کلید ناقص، JSON خراب، متد اشتباه', async () => {
  const s = await boot([]);
  assert.equal((await s.post('markets', { exchange: 'nope' })).json.error, 'unknown_exchange');
  assert.equal((await s.post('balance', { exchange: 'binance' })).json.error, 'missing_creds');
  assert.equal((await s.post('balance', { exchange: 'binance', creds: { apiKey: 'a\nb', apiSecret: 'x' } })).json.error, 'bad_creds');
  const bad = await fetch(s.base + '/trade/v1/markets', { method: 'POST', body: '{oops' });
  assert.equal(bad.status, 400); await bad.text();
  const get = await fetch(s.base + '/trade/v1/balance');
  assert.equal(get.status, 405); await get.text();
  const unk = await s.post('hack', { exchange: 'binance' });
  assert.equal(unk.status, 404);
  const h = await (await fetch(s.base + '/trade/v1/health')).json();
  assert.equal(h.ok, true);
  const ex = await (await fetch(s.base + '/trade/v1/exchanges')).json();
  const ids = ex.exchanges.map((e) => e.id);
  for (const id of ['lbank', 'bitunix', 'xt', 'binance', 'mexc', 'okx', 'bybit', 'kucoin', 'gate', 'bitget']) assert.ok(ids.includes(id), id);
  assert.equal(ex.exchanges.find((e) => e.id === 'okx').needsPassphrase, true);
  await s.close();
});

test('TRADE_TOKEN: بدون توکن رد، با توکن قبول؛ TRADE_ENABLED=0 همه را می‌بندد', async () => {
  let s = await boot([['lbkex.com/v2/accuracy.do', { result: 'true', data: [] }]], { TRADE_TOKEN: 'tok-123' });
  assert.equal((await s.post('markets', { exchange: 'lbank' })).status, 401);
  assert.equal((await s.post('markets', { exchange: 'lbank' }, { 'x-tradyar-token': 'wrong' })).status, 401);
  assert.equal((await s.post('markets', { exchange: 'lbank' }, { 'x-tradyar-token': 'tok-123' })).status, 200);
  await s.close();
  s = await boot([], { TRADE_ENABLED: '0' });
  assert.equal((await s.post('markets', { exchange: 'lbank' })).status, 404);
  await s.close();
});

test('SSRF: فقط دامنهٔ کانکتورها؛ آدرس خصوصی بلاک می‌شود', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tyar-trade-'));
  const cfg = loadConfig({ DATA_DIR: dir });
  const f = mockFetch([['lbkex.com', { result: 'true', data: [] }]]);
  const app = await createApp(cfg, { log: () => {}, lookup: async () => [{ address: '10.0.0.5', family: 4 }], fetch: f });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const r = await fetch(`http://127.0.0.1:${app.server.address().port}/trade/v1/markets`, { method: 'POST', body: JSON.stringify({ exchange: 'lbank' }) });
  assert.equal(r.status, 403); await r.text();
  assert.equal(f.calls.length, 0);
  await app.close();
});

test('کش بازارها: دو درخواست پشت‌سرهم فقط یک تماس به صرافی', async () => {
  const s = await boot([['lbkex.com/v2/accuracy.do', { result: 'true', data: [{ symbol: 'a_usdt', quantityAccuracy: '2', priceAccuracy: '2', minTranQua: '1' }] }]]);
  await Promise.all([s.post('markets', { exchange: 'lbank' }), s.post('markets', { exchange: 'lbank' }), s.post('markets', { exchange: 'lbank' })]);
  assert.equal(s.f.calls.filter((c) => c.url.pathname.endsWith('accuracy.do')).length, 1);
  await s.close();
});

test('سفارش روی جفت‌ارز ناشناخته یا غیرفعال: قبل از امضا رد می‌شود', async () => {
  const s = await boot([['lbkex.com/v2/accuracy.do', { result: 'true', data: [{ symbol: 'a_usdt', quantityAccuracy: '2', priceAccuracy: '2', minTranQua: '1' }] }]]);
  const r = await s.post('order', { exchange: 'lbank', creds: CREDS, order: { symbol: 'zzz_usdt', side: 'buy', type: 'market', quoteQty: 10 } });
  assert.equal(r.status, 422);
  assert.match(r.json.message, /پیدا نشد/);
  assert.ok(!s.f.calls.some((c) => c.url.pathname.includes('create_order')));
  await s.close();
});
