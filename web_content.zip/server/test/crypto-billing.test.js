import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';

async function boot(opts = {}) {
  const store = new MemoryStore();
  const aiProvider = { name: 'fake', async complete() { return 'ok'; } };
  const app = createApp({
    store, aiProvider, mailer: { mode: 'console', async send() {} },
    config: {
      jwtSecret: 'x'.repeat(40),
      cryptoAddresses: { btc: 'bc1qtestaddress000000000000000000000', usdt: 'TTestUsdtAddress00000000000000000' },
      planPricesUsd: { pro: 29, business: 79, enterprise: 199 },
      ...opts
    }
  });
  const server = http.createServer(app); await new Promise(r => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, path, body, token) => {
    const r = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, body: await r.json() };
  };
  return { store, call, close: () => server.close() };
}
const PW = 'correct-horse-battery';
async function owner(t) { const r = await t.call('POST', '/api/auth/register', { email: 'o@x.com', password: PW, orgName: 'Acme' }); assert.equal(r.status, 201); return r.body; }
async function member(t, ownerTok, email, role) {
  const c = await t.call('POST', '/api/users', { email, password: PW, role }, ownerTok); assert.equal(c.status, 201, JSON.stringify(c.body));
  const l = await t.call('POST', '/api/auth/login', { email, password: PW }); assert.equal(l.status, 200); return l.body;
}

test('USDT invoice: ~1:1 peg, no live rate call needed', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  const r = await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'usdt' }, o.accessToken);
  assert.equal(r.status, 201);
  assert.equal(r.body.amountCrypto, 29);
  assert.equal(r.body.address, 'TTestUsdtAddress00000000000000000');
  assert.equal(r.body.status, 'pending');
});

test('BTC invoice: uses the injected/live rate correctly', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  const realFetch = global.fetch;
  global.fetch = async (url, opts) => {
    if (String(url).includes('coingecko')) return { ok: true, json: async () => ({ bitcoin: { usd: 58000 } }) };
    return realFetch(url, opts);
  };
  try {
    const r = await t.call('POST', '/api/billing/crypto-invoice', { plan: 'business', currency: 'btc' }, o.accessToken);
    assert.equal(r.status, 201);
    assert.equal(r.body.amountCrypto, Math.round((79 / 58000) * 1e8) / 1e8);
    assert.equal(r.body.currency, 'btc');
  } finally { global.fetch = realFetch; }
});

test('BTC invoice: honest 503 when the rate provider is unreachable (never invents a price)', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  const realFetch = global.fetch;
  global.fetch = async (url, opts) => {
    if (String(url).includes('coingecko')) throw new Error('network down');
    return realFetch(url, opts);
  };
  try {
    const r = await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'btc' }, o.accessToken);
    assert.equal(r.status, 503);
  } finally { global.fetch = realFetch; }
});

test('unknown plan / bad currency / missing address are all rejected cleanly', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  assert.equal((await t.call('POST', '/api/billing/crypto-invoice', { plan: 'nope', currency: 'usdt' }, o.accessToken)).status, 400);
  assert.equal((await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'doge' }, o.accessToken)).status, 400);

  const t2 = await boot({ cryptoAddresses: { btc: '', usdt: '' } }); x.after(t2.close);
  const o2 = await owner(t2);
  const r = await t2.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'usdt' }, o2.accessToken);
  assert.equal(r.status, 501);
});

test('only owner can create/confirm invoices (billing is owner-write-only); accountant can read', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  const acct = await member(t, o.accessToken, 'acct@x.com', 'accountant');
  const worker = await member(t, o.accessToken, 'w@x.com', 'worker');

  assert.equal((await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'usdt' }, acct.accessToken)).status, 403);
  assert.equal((await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'usdt' }, worker.accessToken)).status, 403);

  const inv = await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'usdt' }, o.accessToken);
  assert.equal(inv.status, 201);

  // accountant can read the list (billing: accountant has [R])
  const list = await t.call('GET', '/api/billing/crypto-invoices', null, acct.accessToken);
  assert.equal(list.status, 200);
  assert.equal(list.body.invoices.length, 1);

  // worker cannot even read
  assert.equal((await t.call('GET', '/api/billing/crypto-invoices', null, worker.accessToken)).status, 403);

  // only owner can confirm payment
  assert.equal((await t.call('POST', `/api/billing/crypto-invoice/${inv.body.id}/confirm`, {}, acct.accessToken)).status, 403);
  const conf = await t.call('POST', `/api/billing/crypto-invoice/${inv.body.id}/confirm`, {}, o.accessToken);
  assert.equal(conf.status, 200);

  const list2 = await t.call('GET', '/api/billing/crypto-invoices', null, o.accessToken);
  assert.equal(list2.body.invoices[0].status, 'paid');
  assert.ok(list2.body.invoices[0].confirmedAt);
});

test('confirming an unknown invoice id returns 404', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  const r = await t.call('POST', '/api/billing/crypto-invoice/does-not-exist/confirm', {}, o.accessToken);
  assert.equal(r.status, 404);
});

test('crypto-invoice actions are written to the tamper-evident audit log', async (x) => {
  const t = await boot(); x.after(t.close);
  const o = await owner(t);
  const inv = await t.call('POST', '/api/billing/crypto-invoice', { plan: 'pro', currency: 'usdt' }, o.accessToken);
  await t.call('POST', `/api/billing/crypto-invoice/${inv.body.id}/confirm`, {}, o.accessToken);
  const a = await t.call('GET', '/api/audit', null, o.accessToken);
  assert.equal(a.body.chain.ok, true);
  const actions = a.body.entries.map(e => e.action);
  assert.ok(actions.includes('crypto-invoice-create'));
  assert.ok(actions.includes('crypto-invoice-confirm'));
});
