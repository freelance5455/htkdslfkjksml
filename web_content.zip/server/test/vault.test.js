'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Vault } = require('../vault');

test('vault encrypts at rest, masks keys, keeps old key on masked update', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v-'));
  const v = new Vault(dir, 'secret-1'); await v.init();
  await v.replace([{ id: 'a', name: 'X', base: 'https://api.x.com/v1', model: 'm', key: 'sk-SECRETKEY1234' }]);
  assert.ok(!fs.readFileSync(path.join(dir, 'vault.json'), 'utf8').includes('SECRETKEY'));
  assert.strictEqual(v.masked()[0].key, '••••1234');
  await v.replace([{ id: 'a', name: 'Y', base: 'https://api.x.com/v1', model: 'm', key: '••••1234' }]);
  assert.strictEqual(v.items[0].key, 'sk-SECRETKEY1234');
  const v2 = new Vault(dir, 'secret-1'); await v2.init();
  assert.strictEqual(v2.items[0].name, 'Y');
  const bad = new Vault(dir, 'wrong'); await assert.rejects(() => bad.init());
});
