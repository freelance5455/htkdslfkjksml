'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp, loadConfig } = require('../server.js');
const { analyze } = require('../analysis.js');
const { sanitizeSettings, sizeOrder } = require('../bot.js');

const DNS = async () => [{ address: '93.184.216.34', family: 4 }];
const CREDS = { apiKey: 'KEYabc', apiSecret: 'SECRETxyz' };
const COINS = ['a1', 'a2', 'a3', 'a4', 'a5'];

function gen(n, drift, seed) {
  let s = seed; const r = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  let p = 10; const out = [];
  for (let i = 0; i < n; i++) {
    const o = p; p = p * (1 + drift + (r() - 0.5) * 0.01);
    out.push([1700000000 + i * 3600, o, Math.max(o, p) * (1 + r() * 0.004), Math.min(o, p) * (1 - r() * 0.004), p, 100 + r() * 50 * (i === n - 1 ? 3 : 1)]);
  }
  return out;
}

function world(opts = {}) {
  const w = { holdings: false, orders: [], priceMul: {}, ai: null, aiCalls: 0, clock: { t: 1700000000000 } };
  const R = (o) => new Response(JSON.stringify(o), { status: 200, headers: { 'content-type': 'application/json' } });
  w.fetch = async (url, init = {}) => {
    const u = new URL(url);
    const sym = (u.searchParams.get('symbol') || '').toLowerCase();
    if (u.pathname === '/v2/accuracy.do') return R({ result: 'true', data: COINS.map((c) => ({ symbol: c + '_usdt', quantityAccuracy: '2', priceAccuracy: '4', minTranQua: '0.01' })) });
    if (u.pathname === '/v2/ticker/24hr.do') return R({ result: 'true', data: COINS.map((c, i) => { const k = gen(250, 0.004, i + 3); const last = k[249][4] * (w.priceMul[c + '_usdt'] || 1); return { symbol: c + '_usdt', ticker: { latest: String(last), change: '2', turnover: '2000000', high: String(last * 1.02), low: String(last * 0.98) } }; }) });
    if (u.pathname === '/v2/kline.do') { const i = COINS.indexOf(sym.replace('_usdt', '')); return R({ result: 'true', data: gen(+u.searchParams.get('size'), 0.004, i + 3).map((k) => [k[0], k[1], k[2], k[3], k[4], k[5]]) }); }
    if (u.pathname === '/v2/user_info.do') { const free = { usdt: '500' }; if (w.holdings) COINS.forEach((c) => { free[c] = '1000'; }); return R({ result: 'true', data: { free, freeze: {} } }); }
    if (u.pathname === '/v2/create_order.do') { const b = Object.fromEntries(new URLSearchParams(init.body)); w.orders.push(b); return R({ result: 'true', data: { order_id: 'O' + w.orders.length } }); }
    if (u.hostname === 'api.openai.com') { w.aiCalls++; return R({ choices: [{ message: { content: JSON.stringify(w.ai) } }] }); }
    return new Response('{}', { status: 404 });
  };
  void opts;
  return w;
}

async function boot(w, env = {}, dir) {
  dir = dir || fs.mkdtempSync(path.join(os.tmpdir(), 'tyar-bot-'));
  const cfg = loadConfig({ DATA_DIR: dir, TRADE_TICKERS_TTL_MS: '0', ...env });
  const app = await createApp(cfg, { log: () => {}, lookup: DNS, fetch: w.fetch, now: () => w.clock.t, protectDelayMs: 0, manualBots: true });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const post = async (op, body, headers = {}) => { const r = await fetch(`${base}/trade/v1/${op}`, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) }); return { status: r.status, json: await r.json() }; };
  return { app, post, dir, close: () => app.close() };
}

const SET = { everyMin: 5, scope: 'top50', tf: '1h', minVolUsd: 0, minScore: 55, minRR: 1.5, maxDaily: 5, maxOrderUsd: 20, sizing: { mode: 'fixed', usd: 10 } };

test('analysis: روند صعودی=خرید، نزولی=فروش، دادهٔ کم=null', () => {
  const up = analyze(gen(250, 0.004, 1)), dn = analyze(gen(250, -0.004, 2));
  assert.equal(up.dir, 'buy'); assert.ok(up.sl < up.entry && up.tp1 > up.entry && up.rr1 >= 1.5);
  assert.equal(dn.dir, 'sell'); assert.ok(dn.sl > dn.entry && dn.tp1 < dn.entry);
  assert.equal(analyze(gen(30, 0.01, 1)), null);
});

test('sanitizeSettings و sizeOrder', () => {
  const caps = { maxOrderUsd: 500, minEveryMin: 5 };
  const s = sanitizeSettings({ everyMin: 1, sizing: { usd: 99999, mode: 'weird' }, scope: 'x', tf: '2h', minScore: 10 }, caps);
  assert.equal(s.everyMin, 15); assert.ok(s.sizing.usd <= 500); assert.equal(s.sizing.mode, 'fixed'); assert.equal(s.scope, 'top100'); assert.equal(s.tf, '1h'); assert.equal(s.minScore, 70);
  const z = sizeOrder({ side: 'buy', entry: 100, sl: 95, tp: 110, mode: 'risk', balance: 1000, riskPct: 1, maxOrderUsd: 50, market: { minNotional: 5 } });
  assert.equal(z.notional, 50); assert.equal(z.rr, 2);
  assert.ok(sizeOrder({ side: 'buy', entry: 100, sl: 105, tp: 110, mode: 'fixed', usd: 10, balance: 100, maxOrderUsd: 50 }).errors.length);
  assert.equal(sizeOrder({ side: 'buy', entry: 1, sl: 0.9, tp: 1.2, mode: 'pct', pct: 10, balance: 200, maxOrderUsd: 500 }).notional, 20);
});

test('ربات: ذخیرهٔ رمزنگاری‌شده، توکن، چرخهٔ معامله، نگهبان حد ضرر، پایداری بعد از ریستارت', async () => {
  const w = world();
  let s = await boot(w);
  // ساخت و اعتبارسنجی کلید با صرافی
  const bad = await s.post('bot/save', { exchange: 'lbank', creds: {}, settings: SET });
  assert.equal(bad.status, 400);
  const sv = await s.post('bot/save', { exchange: 'lbank', creds: CREDS, settings: SET, start: true, label: 'test' });
  assert.equal(sv.status, 200);
  const { botId, botToken } = Object.assign({ botId: sv.json.bot.id }, { botToken: sv.json.botToken });
  assert.ok(botToken && botToken.length >= 40);
  assert.equal(sv.json.bot.running, true);
  assert.ok(!JSON.stringify(sv.json).includes('SECRETxyz'));
  // روی دیسک رمزنگاری شده است
  s.app.bots._saveNow();
  const raw = fs.readFileSync(path.join(s.dir, 'bots.json'), 'utf8');
  assert.ok(!raw.includes('SECRETxyz') && !raw.includes('KEYabc') && !raw.includes(botToken));
  assert.equal((fs.statSync(path.join(s.dir, 'bot.key')).mode & 0o077), 0);
  // احراز هویت
  assert.equal((await s.post('bot/status', { botId, botToken: 'nope' })).status, 401);
  assert.equal((await s.post('bot/status', { botId: 'b_x', botToken })).status, 404);
  assert.equal((await s.post('bot/status', { botId, botToken })).status, 200);

  // چرخه: اسکن ۵ ارز ← خرید
  const bot = s.app.bots.bots.get(botId);
  await s.app.bots.runCycle(bot);
  assert.equal(bot.status.phase, 'idle', bot.status.lastError);
  assert.ok(w.orders.length >= 1 && w.orders.length <= 5, 'orders=' + w.orders.length);
  for (const o of w.orders) { assert.equal(o.type, 'buy_market'); assert.equal(o.price, '10.00'); assert.equal(o.api_key, 'KEYabc'); }
  assert.equal(bot.status.opened, w.orders.length);
  assert.equal(bot.guards.filter((g) => g.status === 'open').length, w.orders.length); // LBank OCO بومی ندارد ← نگهبان سرور
  const n1 = w.orders.length;
  // چرخهٔ بعد همان ارزها را دوباره نمی‌خرد
  bot.status.nextAt = 0;
  await s.app.bots.runCycle(bot);
  assert.equal(w.orders.length, n1);

  // نگهبان: قیمت زیر حد ضرر ← فروش مارکت
  const g = bot.guards[0];
  w.priceMul[g.symbol] = (g.sl * 0.95) / (g.sl / 0.97 / 1); // قیمت را به‌طور قطع زیر حد ضرر ببر
  w.priceMul[g.symbol] = 0.5; w.holdings = true;
  await s.app.bots.guardTick();
  const sell = w.orders.find((o) => o.type === 'sell_market');
  assert.ok(sell, 'sell_market ثبت نشد');
  assert.equal(sell.symbol, g.symbol);
  assert.equal(bot.guards.find((x) => x.id === g.id).status, 'sl');

  // ریستارت سرور: ربات با کلید رمزگشایی‌شده ادامه می‌دهد
  await s.close();
  s = await boot(w, {}, s.dir);
  const again = s.app.bots.bots.get(botId);
  assert.ok(again && again.running);
  assert.equal((await s.post('bot/status', { botId, botToken })).json.bot.exchange, 'lbank');
  const before = w.orders.length;
  w.priceMul = {}; w.holdings = false; again.status.nextAt = 0; again.trades = []; again.guards = [];
  await s.app.bots.runCycle(again);
  assert.ok(w.orders.length > before);
  // توقف و حذف
  assert.equal((await s.post('bot/stop', { botId, botToken })).json.bot.running, false);
  assert.equal((await s.post('bot/delete', { botId, botToken })).json.ok, true);
  assert.equal((await s.post('bot/status', { botId, botToken })).status, 404);
  await s.close();
});

test('ربات: سقف معاملهٔ روزانه، انقضای اشتراک، و عدم شروع بعد از انقضا', async () => {
  const w = world();
  const s = await boot(w);
  const sv = await s.post('bot/save', { exchange: 'lbank', creds: CREDS, settings: Object.assign({}, SET, { maxDaily: 2 }), start: true, expiresAt: w.clock.t + 60000 });
  const { botToken } = sv.json; const id = sv.json.bot.id;
  const bot = s.app.bots.bots.get(id);
  await s.app.bots.runCycle(bot);
  assert.equal(w.orders.length, 2);
  assert.match(bot.status.notes.join(' '), /سقف معاملات امروز/);
  // انقضا
  w.clock.t += 120000;
  await s.app.bots.tick();
  assert.equal(bot.running, false);
  assert.equal(bot.status.phase, 'expired');
  const st = await s.post('bot/start', { botId: id, botToken });
  assert.equal(st.status, 402);
  // تمدید اشتراک و شروع دوباره
  assert.equal((await s.post('bot/update', { botId: id, botToken, expiresAt: w.clock.t + 3600000 })).status, 200);
  assert.equal((await s.post('bot/start', { botId: id, botToken })).json.bot.running, true);
  await s.close();
});

test('ربات: تأیید هوش مصنوعی (اختیاری) — موافق=معامله با حد ضرر/سود AI، مخالف=رد', async () => {
  const w = world();
  const s = await boot(w, { AI_API_KEY: 'sk-test' });
  assert.equal((await (await fetch(`http://127.0.0.1:${s.app.server.address().port}/trade/v1/bot/info`)).json()).ai, true);
  const sv = await s.post('bot/save', { exchange: 'lbank', creds: CREDS, settings: Object.assign({}, SET, { useAI: true, aiMax: 2, minScore: 60 }), start: true });
  const bot = s.app.bots.bots.get(sv.json.bot.id);
  w.ai = { direction: 'sell', entry: 10, stop_loss: 11, take_profit_1: 9, confidence: 95 };
  await s.app.bots.runCycle(bot);
  assert.equal(w.orders.length, 0);
  assert.ok(w.aiCalls >= 1 && w.aiCalls <= 2);
  assert.match(bot.status.notes.join(' '), /AI موافق نبود/);
  // موافق: سطوح AI نسبت به قیمت بازار ساخته می‌شود
  w.ai = null; bot.status.nextAt = 0;
  const orig = s.app.bots._ai.bind(s.app.bots);
  s.app.bots._ai = async (c, row) => { const last = row.t ? row.t.last : 0; void last; return orig(c, row, arguments[2], arguments[3]); };
  const calls = [];
  s.app.bots._ai = async (c, row, res) => { calls.push(row.base); return { dir: 'buy', entry: res.entry, sl: res.entry * 0.96, tp1: res.entry * 1.08, tp2: res.entry * 1.15, confidence: 88 }; };
  await s.app.bots.runCycle(bot);
  assert.ok(w.orders.length >= 1 && w.orders.length <= 2);
  assert.ok(bot.trades.every((t) => t.src === 'bot-ai'));
  await s.close();
});

test('ربات: مسیرهای ادمین نیازمند توکن؛ ظرفیت و غیرفعال‌سازی', async () => {
  const w = world();
  let s = await boot(w, { TRADE_ADMIN_TOKEN: 'adm-1', BOT_MAX: '1' });
  const a = await s.post('bot/save', { exchange: 'lbank', creds: CREDS, settings: SET });
  assert.equal(a.status, 200);
  assert.equal((await s.post('bot/save', { exchange: 'lbank', creds: CREDS, settings: SET })).status, 503);
  assert.equal((await s.post('bot/admin/list', {})).status, 401);
  const l = await s.post('bot/admin/list', {}, { 'x-admin-token': 'adm-1' });
  assert.equal(l.json.bots.length, 1);
  assert.ok(!JSON.stringify(l.json).includes('SECRET'));
  await s.post('bot/start', { botId: a.json.bot.id, botToken: a.json.botToken });
  assert.equal((await s.post('bot/admin/stop', { botId: a.json.bot.id }, { 'x-admin-token': 'adm-1' })).json.ok, true);
  assert.equal(s.app.bots.bots.get(a.json.bot.id).running, false);
  await s.close();
  s = await boot(w, { BOT_ENABLED: '0' });
  assert.equal((await s.post('bot/save', { exchange: 'lbank', creds: CREDS })).status, 404);
  await s.close();
});

test('ربات: کلید نامعتبر صرافی هنگام ذخیره رد می‌شود و چیزی ذخیره نمی‌شود', async () => {
  const w = world();
  const orig = w.fetch;
  w.fetch = async (url, init) => { if (new URL(url).pathname === '/v2/user_info.do') return new Response(JSON.stringify({ result: 'false', error_code: 10008 }), { status: 200 }); return orig(url, init); };
  const s = await boot(w);
  const r = await s.post('bot/save', { exchange: 'lbank', creds: CREDS, settings: SET });
  assert.equal(r.status, 422);
  assert.equal(s.app.bots.bots.size, 0);
  await s.close();
});
