'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp, loadConfig } = require('../server.js');

async function boot(env = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tyar-chat-'));
  const cfg = loadConfig({ DATA_DIR: dir, ADMIN_TOKEN: 'a'.repeat(40), ...env });
  const app = await createApp(cfg, { log: () => {} });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  return { app, base: `http://127.0.0.1:${app.server.address().port}`, close: () => app.close() };
}
const H = (uid, key) => ({ 'Content-Type': 'application/json', 'x-chat-uid': uid, 'x-chat-key': key });
const PNG = 'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]), Buffer.alloc(200, 1)]).toString('base64');

test('چت: عضویت، پیام، عکس، لینک، دیده‌شدن، حذف و مدیریت', async () => {
  const s = await boot();
  const ka = 'k'.repeat(24), kb = 'z'.repeat(24);
  const post = (path, uid, key, body, extra) => fetch(s.base + path, { method: 'POST', headers: { ...H(uid, key), ...extra }, body: JSON.stringify(body) }).then(async (r) => ({ st: r.status, j: await r.json() }));
  const get = (path, uid, key) => fetch(s.base + path, { headers: H(uid, key) }).then((r) => r.json());

  const rooms = await get('/chat/rooms', 'user_1', ka);
  assert.equal(rooms.rooms.length, 2);
  // بدون عضویت نمی‌شود نوشت
  assert.equal((await post('/chat/send', 'user_1', ka, { room: 'traders', text: 'سلام', name: 'علی' })).st, 403);
  assert.equal((await post('/chat/join', 'user_1', ka, { room: 'traders', name: 'علی' })).j.room.joined, true);
  const m1 = await post('/chat/send', 'user_1', ka, { room: 'traders', text: 'تحلیل بیت‌کوین https://tradingview.com/x/abc. خوبه', name: 'علی', img: PNG });
  assert.equal(m1.j.ok, true);
  assert.equal(m1.j.msg.links[0], 'https://tradingview.com/x/abc');
  assert.ok(m1.j.msg.img.endsWith('.png'));
  const media = await fetch(s.base + '/chat/media/' + m1.j.msg.img);
  assert.equal(media.status, 200);
  // اسپم سریع
  assert.equal((await post('/chat/send', 'user_1', ka, { room: 'traders', text: 'دوباره' })).st, 429);
  // هویت جعلی
  assert.equal((await fetch(s.base + '/chat/rooms', { headers: H('user_1', kb) })).status, 403);
  // کانال فقط مدیر
  await post('/chat/join', 'user2', kb, { room: 'news', name: 'رضا' });
  assert.equal((await post('/chat/send', 'user2', kb, { room: 'news', text: 'x' })).st, 403);
  const adm = { 'x-admin-token': 'a'.repeat(40) };
  const am = await post('/chat/send', 'user2', kb, { room: 'news', text: 'اطلاعیه', asAdmin: true }, adm);
  assert.equal(am.j.msg.admin, true);
  // دیده‌شدن
  await post('/chat/seen', 'user2', kb, { room: 'traders', n: 1 });
  const l = await get('/chat/msgs?room=traders', 'user2', kb);
  assert.equal(l.msgs[0].views, 1);
  assert.equal((await get('/chat/msgs?room=traders&kind=media', 'user2', kb)).msgs.length, 1);
  // سنجاق و حذف
  assert.equal((await post('/chat/admin', 'adminx', 'y'.repeat(20), { op: 'msg.pin', room: 'traders', id: 1 }, adm)).j.room.pinned.id, 1);
  assert.equal((await post('/chat/admin', 'adminx', 'y'.repeat(20), { op: 'msg.pin', room: 'traders', id: 1 })).st, 403);
  await post('/chat/admin', 'user_1', ka, { op: 'msg.delete', room: 'traders', id: 1 }, adm);
  assert.equal((await get('/chat/msgs?room=traders', 'user2', kb)).msgs.length, 0);
  // بن
  await post('/chat/admin', 'user_1', ka, { op: 'user.ban', uid: 'user2', on: true }, adm);
  assert.equal((await fetch(s.base + '/chat/rooms', { headers: H('user2', kb) })).status, 403);
  await s.close();
});
