# SKYNET V2 — contrôles avant mise en production

Cette archive contient un socle de développement, pas un service certifié ni prêt à exposer directement sur Internet.

## Six chantiers — état honnête

1. **IA** : contrat d'état `/ai/status` et garde-fou de validation humaine. Aucun fournisseur IA n'est connecté ; ajouter un adaptateur après choix du fournisseur, politique de confidentialité et tests.
2. **Serveur et données** : API FastAPI, PostgreSQL via Docker Compose, endpoint `/health` et contrôle DB `/ready`. Exécuter les migrations contrôlées avant toute exploitation ; le prototype utilise encore `create_all`.
3. **Sécurité et multi-entreprises** : JWT, hachage Argon2 via pwdlib, rôles et filtrage par organisation sur les données. À compléter : MFA, limitation de débit, politique de session, gestion/rotation des secrets, migrations, tests d'isolation et revue indépendante.
4. **Sources internationales** : registre d'indicateurs et état des connecteurs STIX/TAXII, SIEM, EDR et ticketing. Aucun flux réel ni connecteur n'est activé ; intégrer uniquement des fournisseurs autorisés et vérifier licences/conditions d'utilisation.
5. **Corrélation et prédiction** : endpoint `/correlations` regroupe les événements par actif. C'est une corrélation déterministe simple, pas un modèle prédictif ni une détection confirmée.
6. **Audit et déploiement** : demandes d'approbation et audit applicatif existants, configuration Docker. À compléter : journal immuable externe/chaîné, sauvegardes chiffrées testées, TLS/reverse proxy, supervision, tests de charge, pentest et audit cryptographique.

## Démarrage de développement

1. Copier `server/.env.example` vers `server/.env`.
2. Générer des secrets aléatoires uniques et forts pour `POSTGRES_PASSWORD`, `SKYNET_JWT_SECRET` (au moins 32 caractères) et `SKYNET_SETUP_KEY` (au moins 20 caractères).
3. Définir `CORS_ORIGINS` sur le domaine exact du front-end HTTPS. Ne pas utiliser `*` avec des identifiants.
4. Depuis le dossier `server`, exécuter `docker compose up --build`.
5. Vérifier `/health`, `/ready` et `/platform/capabilities` depuis un environnement de test.
6. Initialiser le premier administrateur via `/setup/first-admin`, puis supprimer/faire tourner immédiatement la clé d'initialisation et ne jamais la réutiliser.

Ne pas y mettre de données de production. Ne pas publier le port API sans reverse proxy TLS, pare-feu et revue de sécurité. Les indicateurs doivent être traités comme des renseignements non confirmés tant qu'ils n'ont pas été vérifiés.


## Contrôles ajoutés en 0.3.0

- [x] Migration Alembic versionnée pour `users.token_version` (migration tolérante si la colonne est déjà présente).
- [x] Révocation des jetons via `POST /auth/logout`.
- [x] Limitation locale des tentatives de connexion et d'initialisation.
- [x] Sauvegarde PostgreSQL au format custom avec empreinte SHA-256.
- [x] Restauration destructive protégée par confirmation textuelle.
- [ ] Remplacer le limiteur en mémoire par une solution partagée avant déploiement multi-instance.
- [ ] Ajouter MFA, tests d'intégration multi-tenant et test de restauration sur environnement isolé.
- [ ] Effectuer audit indépendant, TLS/reverse proxy, supervision et procédure de gestion des secrets.
