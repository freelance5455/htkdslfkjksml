import { ExamMCQ } from './examQuestionStore.js';

export interface StaticMCQSeed {
  subject: string;
  topicBn: string;
  topicEn: string;
  questionBn: string;
  questionEn: string;
  optionsBn: string[];
  optionsEn: string[];
  correctOptionIndex: number;
  explanationBn: string;
  explanationEn: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  shortConceptBn: string;
  shortConceptEn: string;
}

// Rich repository of authentic, verified competitive exam questions for Geography, History, Science, Polity, Math, Reasoning
export const COMPREHENSIVE_SEEDS: StaticMCQSeed[] = [
  // GEOGRAPHY - 1
  {
    subject: "Geography",
    topicBn: "ভারতের নদ-নদী ব্যবস্থা",
    topicEn: "Drainage System of India",
    questionBn: "ভারতের দীর্ঘতম নদী গঙ্গার প্রধান উপনদী যমুনা কোন স্থানে গঙ্গার সাথে মিলিত হয়েছে?",
    questionEn: "At which place does the river Yamuna, the largest tributary of the Ganga, merge with the Ganga?",
    optionsBn: ["A. প্রয়াগরাজ (এলাহাবাদ)", "B. হরিদ্বার", "C. দেবপ্রয়াগ", "D. বারাণসী"],
    optionsEn: ["A. Prayagraj (Allahabad)", "B. Haridwar", "C. Devprayag", "D. Varanasi"],
    correctOptionIndex: 0,
    explanationBn: "যমুনা নদী প্রয়াগরাজে (ত্রিবেণী সঙ্গম) গঙ্গা ও পৌরাণিক সরস্বতীর সাথে মিলিত হয়েছে। যমুনা যমুনোত্রী হিমবাহ থেকে উৎপত্তি লাভ করেছে।",
    explanationEn: "Yamuna river meets the Ganga at Triveni Sangam in Prayagraj (Allahabad). It originates from the Yamunotri Glacier.",
    difficulty: "Easy",
    shortConceptBn: "ত্রিবেণী সঙ্গম ও যমুনার গতিপথ",
    shortConceptEn: "Triveni Sangam & Yamuna Confluence"
  },
  {
    subject: "Geography",
    topicBn: "পশ্চিমবঙ্গের ভূগোল",
    topicEn: "Geography of West Bengal",
    questionBn: "পশ্চিমবঙ্গের সর্বোচ্চ শৃঙ্গ সান্দাকফু কোন পর্বতশ্রেণীর অন্তর্গত?",
    questionEn: "Sandakphu, the highest peak in West Bengal, belongs to which mountain range?",
    optionsBn: ["A. সিঙ্গালীলা শৈলশিরা", "B. দার্জিলিং শৈলশিরা", "C. জয়ন্তী পাহাড়", "D. টাইগার হিল শৈলশিরা"],
    optionsEn: ["A. Singalila Ridge", "B. Darjeeling Ridge", "C. Jayanti Hills", "D. Tiger Hill Ridge"],
    correctOptionIndex: 0,
    explanationBn: "সান্দাকফুর উচ্চতা ৩৬৩৬ মিটার (১১৯৩০ ফুট)। এটি ভারত ও নেপাল সীমান্তে সিঙ্গালীলা শৈলশিরায় অবস্থিত।",
    explanationEn: "Sandakphu (3,636 meters) is located on the Singalila Ridge along the India-Nepal border.",
    difficulty: "Medium",
    shortConceptBn: "পশ্চিমবঙ্গের সর্বোচ্চ শৃঙ্গ",
    shortConceptEn: "Highest Peak of West Bengal"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের মৃত্তিকা",
    topicEn: "Soils of India",
    questionBn: "তুলা চাষের জন্য ভারতের কোন মৃত্তিকা সর্বাধিক উপযোগী এবং এটিকে রেগুর মৃত্তিকা বলা হয়?",
    questionEn: "Which soil in India is most suitable for cotton cultivation and is famously known as Regur soil?",
    optionsBn: ["A. কৃষ্ণ মৃত্তিকা (Black Soil)", "B. পলি মৃত্তিকা (Alluvial Soil)", "C. ল্যাটেরাইট মৃত্তিকা", "D. লোহিত মৃত্তিকা"],
    optionsEn: ["A. Black Soil (Regur)", "B. Alluvial Soil", "C. Laterite Soil", "D. Red Soil"],
    correctOptionIndex: 0,
    explanationBn: "দাক্ষিণাত্যের লাভা গঠিত কৃষ্ণ মৃত্তিকায় টাইটানিফেরাস ম্যাগনেটাইট থাকার কারণে এর রঙ কালো এবং এটি আর্দ্রতা ধরে রাখতে সক্ষম। এটি তুলা চাষের জন্য আদর্শ।",
    explanationEn: "Black soil (Regur), formed from basaltic lava in Deccan plateau, is rich in clay and moisture retentive, ideal for cotton cultivation.",
    difficulty: "Easy",
    shortConceptBn: "কৃষ্ণ বা রেগুর মৃত্তিকা",
    shortConceptEn: "Regur / Black Cotton Soil"
  },
  {
    subject: "Geography",
    topicBn: "সৌরজগৎ ও জ্যোতির্বিজ্ঞান",
    topicEn: "Solar System & Astronomy",
    questionBn: "সৌরজগতের কোন গ্রহটি তার অক্ষের ওপর পূর্ব থেকে পশ্চিমে (ঘড়ির কাঁটার দিকে) আবর্তিত হয়?",
    questionEn: "Which planet in the solar system rotates from east to west (clockwise) on its axis?",
    optionsBn: ["A. শুক্র (Venus) ও ইউরেনাস", "B. মঙ্গল ও বৃহস্পতি", "C. বুধ ও শনি", "D. পৃথিবী ও নেপচুন"],
    optionsEn: ["A. Venus and Uranus", "B. Mars and Jupiter", "C. Mercury and Saturn", "D. Earth and Neptune"],
    correctOptionIndex: 0,
    explanationBn: "শুক্র এবং ইউরেনাস গ্রহ দুটি বিপরীত দিকে (পূর্ব থেকে পশ্চিমে) আবর্তিত হয়, যেখানে বেশিরভাগ গ্রহ পশ্চিম থেকে পূর্বে ঘোরে।",
    explanationEn: "Venus and Uranus exhibit retrograde rotation, spinning from east to west, unlike other planets which rotate west to east.",
    difficulty: "Medium",
    shortConceptBn: "গ্রহদের অক্ষীয় আবর্তন",
    shortConceptEn: "Retrograde Planetary Rotation"
  },
  {
    subject: "Geography",
    topicBn: "বায়ুমণ্ডল ও আবহাওয়া",
    topicEn: "Atmosphere & Weather",
    questionBn: "বায়ুমণ্ডলের কোন স্তরে সমস্ত আবহাওয়া সংক্রান্ত ঘটনা (যেমন মেঘ, বৃষ্টি, ঝড় ও কুয়াশা) সংঘটিত হয়?",
    questionEn: "In which layer of the atmosphere do all weather phenomena (such as clouds, rain, storms, and fog) occur?",
    optionsBn: ["A. ট্রপোস্ফিয়ার (Troposphere)", "B. স্ট্র্যাটোস্ফিয়ার", "C. মেসোস্ফিয়ার", "D. থার্মোস্ফিয়ার"],
    optionsEn: ["A. Troposphere", "B. Stratosphere", "C. Mesosphere", "D. Thermosphere"],
    correctOptionIndex: 0,
    explanationBn: "ট্রপোস্ফিয়ার হলো ভূপৃষ্ঠ সংলগ্ন সর্বনিম্ন স্তর। বায়ুমণ্ডলের মোট ভরের প্রায় ৭৫% এবং সমস্ত জলীয় বাষ্প এখানে থাকায় একে 'ক্ষুব্ধমণ্ডল' বলা হয়।",
    explanationEn: "The Troposphere is the lowest atmospheric layer containing ~75% of atmospheric mass and water vapor, where all weather phenomena take place.",
    difficulty: "Easy",
    shortConceptBn: "ট্রপোস্ফিয়ার বা ক্ষুব্ধমণ্ডল",
    shortConceptEn: "Troposphere Weather Layer"
  },
  {
    subject: "Geography",
    topicBn: "উপকূলীয় ভূপ্রকৃতি ও হ্রদ",
    topicEn: "Coastal Physiography & Lakes",
    questionBn: "ভারতের বৃহত্তম লবণাক্ত জলের উপহ্রদ বা লেগুন কোনটি?",
    questionEn: "Which is the largest brackish water coastal lagoon in India?",
    optionsBn: ["A. চিল্কা হ্রদ (Chilika Lake)", "B. পুলিকট হ্রদ", "C. ভেম্বানাদ হ্রদ", "D. উলার হ্রদ"],
    optionsEn: ["A. Chilika Lake", "B. Pulicat Lake", "C. Vembanad Lake", "D. Wular Lake"],
    correctOptionIndex: 0,
    explanationBn: "ওড়িশার চিল্কা হ্রদ হলো ভারতের বৃহত্তম উপকূলীয় উপহ্রদ (লেগুন)। এটি ভারতের প্রথম রামসার সাইট হিসেবে ১৯8১ সালে ঘোষিত হয়।",
    explanationEn: "Chilika Lake in Odisha is India's largest coastal lagoon and was designated as India's first Ramsar wetland in 1981.",
    difficulty: "Easy",
    shortConceptBn: "চিল্কা লেগুন",
    shortConceptEn: "Chilika Lagoon & Ramsar Site"
  },
  {
    subject: "Geography",
    topicBn: "পর্বতমালা ও গিরিপথ",
    topicEn: "Mountains & Passes",
    questionBn: "শ্রীনগর ও লেহ শহরকে সংযোগকারী গুরুত্বপূর্ণ হিমালয় গিরিপথটির নাম কী?",
    questionEn: "What is the name of the strategic Himalayan mountain pass connecting Srinagar and Leh?",
    optionsBn: ["A. জোজি লা (Zoji La)", "B. নাথু লা (Nathu La)", "C. রোটাং পাস", "D. শিপকি লা"],
    optionsEn: ["A. Zoji La", "B. Nathu La", "C. Rohtang Pass", "D. Shipki La"],
    correctOptionIndex: 0,
    explanationBn: "জোজি লা গিরিপথ গ্রেটার হিমালয়ে অবস্থিত এবং এটি কাশ্মীর উপত্যকাকে লাদাখের লেহের সাথে যুক্ত করে।",
    explanationEn: "Zoji La is located in the Greater Himalayas and connects the Kashmir Valley with Leh in Ladakh.",
    difficulty: "Medium",
    shortConceptBn: "জোজি লা গিরিপথ",
    shortConceptEn: "Zoji La Mountain Pass"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের জলবায়ু ও মৌসুমি বায়ু",
    topicEn: "Climate of India & Monsoon",
    questionBn: "ভারতে দক্ষিণ-পশ্চিম মৌসুমি বায়ুর আগমন সর্বপ্রথম কোন রাজ্যে ঘটে?",
    questionEn: "In which Indian state does the South-West Monsoon first arrive around June 1st?",
    optionsBn: ["A. কেরালা", "B. তামিলনাড়ু", "C. মহারাষ্ট্র", "D. পশ্চিমবঙ্গ"],
    optionsEn: ["A. Kerala", "B. Tamil Nadu", "C. Maharashtra", "D. West Bengal"],
    correctOptionIndex: 0,
    explanationBn: "দক্ষিণ-পশ্চিম মৌসুমি বায়ুর আরব সাগরীয় শাখা প্রতি বছর ১লা জুনের কাছাকাছি সময়ে কেরালা উপকূলে প্রথম বৃষ্টিপাত ঘটায়, যাকে মৌসুমি বিস্ফোরণ (Monsoon Burst) বলা হয়।",
    explanationEn: "The Arabian Sea branch of the South-West Monsoon officially hits the Kerala coast around June 1st, known as the Monsoon Burst.",
    difficulty: "Easy",
    shortConceptBn: "মৌসুমি বায়ুর আগমন",
    shortConceptEn: "Monsoon Burst in Kerala"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের খনিজ সম্পদ",
    topicEn: "Mineral Resources of India",
    questionBn: "ভারতের প্রাচীনতম তৈলখনিটি কোন স্থানে অবস্থিত?",
    questionEn: "Where is India's oldest operating oil refinery and field located?",
    optionsBn: ["A. ডিগবয় (আসাম)", "B. বোম্বে হাই (মহারাষ্ট্র)", "C. অঙ্কলেশ্বর (গুজরাট)", "D. নাহারকাটিয়া (আসাম)"],
    optionsEn: ["A. Digboi (Assam)", "B. Mumbai High (Maharashtra)", "C. Ankleshwar (Gujarat)", "D. Naharkatiya (Assam)"],
    correctOptionIndex: 0,
    explanationBn: "আসামের ডিগবয়ে ১৯০১ সালে ভারতের ও এশিয়ার প্রথম আধুনিক তেল শোধনাগার গড়ে ওঠে।",
    explanationEn: "Digboi in Assam is India's and Asia's oldest operating oilfield and refinery, established in 1901.",
    difficulty: "Easy",
    shortConceptBn: "ডিগবয় তৈলখনি",
    shortConceptEn: "Digboi Oil Field"
  },
  {
    subject: "Geography",
    topicBn: "বায়ুমণ্ডলের ওজোন স্তর",
    topicEn: "Atmospheric Ozone Layer",
    questionBn: "বায়ুমণ্ডলের কোন স্তরে ওজোন গ্যাসের স্তর (Ozone Layer) অতিবেগুনি রশ্মি শোষণ করে জীবজগতকে রক্ষা করে?",
    questionEn: "In which atmospheric layer is the ozone layer located that absorbs harmful ultraviolet (UV) solar radiation?",
    optionsBn: ["A. স্ট্র্যাটোস্ফিয়ার (Stratosphere)", "B. ট্রপোস্ফিয়ার", "C. মেসোস্ফিয়ার", "D. আয়নোস্ফিয়ার"],
    optionsEn: ["A. Stratosphere", "B. Troposphere", "C. Mesosphere", "D. Ionosphere"],
    correctOptionIndex: 0,
    explanationBn: "স্ট্র্যাটোস্ফিয়ারের ১৫ থেকে ৩৫ কিমি উচ্চতায় ওজোন গ্যাসের ঘনত্ব সবচেয়ে বেশি। এটি সূর্যের ক্ষতিকর UV-B রশ্মি শোষণ করে।",
    explanationEn: "The Ozone layer is located in the Stratosphere (15-35 km above sea level), shielding Earth from harmful solar UV radiation.",
    difficulty: "Easy",
    shortConceptBn: "ওজোন স্তর ও স্ট্র্যাটোস্ফিয়ার",
    shortConceptEn: "Stratospheric Ozone Layer"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের নদীপ্রকল্প ও বাঁধ",
    topicEn: "River Valley Projects & Dams",
    questionBn: "ভারতের দীর্ঘতম বাঁধ 'হীরাকুঁদ বাঁধ' কোন নদীর ওপর নির্মিত হয়েছে?",
    questionEn: "On which river is the Hirakud Dam, the longest dam in India, constructed?",
    optionsBn: ["A. মহানদী (Mahanadi)", "B. গোদাবরী", "C. নর্মদা", "D. সতলুজ"],
    optionsEn: ["A. Mahanadi", "B. Godavari", "C. Narmada", "D. Sutlej"],
    correctOptionIndex: 0,
    explanationBn: "ওড়িশার সম্বলপুরে মহানদীর ওপর হীরাকুঁদ বাঁধ নির্মিত হয়েছে। এর মূল বাঁধের দৈর্ঘ্য প্রায় ৪.৮ কিমি এবং সামগ্রিক দৈর্ঘ্য ২৫.৭ কিমি।",
    explanationEn: "Hirakud Dam is built across the Mahanadi River in Sambalpur, Odisha. It is the longest earthen dam in India.",
    difficulty: "Easy",
    shortConceptBn: "হীরাকুঁদ বাঁধ",
    shortConceptEn: "Hirakud Dam on Mahanadi"
  },
  {
    subject: "Geography",
    topicBn: "পশ্চিমবঙ্গের ভূপ্রকৃতি ও নদ-নদী",
    topicEn: "West Bengal Rivers & Regions",
    questionBn: "পশ্চিমবঙ্গের কোন নদীকে ঐতিহাসিকভাবে 'বাংলার দুঃখ' (Sorrow of Bengal) বলা হতো?",
    questionEn: "Which river was historically known as the 'Sorrow of Bengal' due to frequent catastrophic floods?",
    optionsBn: ["A. দামোদর নদী (Damodar)", "B. তিস্তা নদী", "C. রূপনারায়ণ", "D. অজয় নদী"],
    optionsEn: ["A. Damodar River", "B. Teesta River", "C. Rupnarayan", "D. Ajay River"],
    correctOptionIndex: 0,
    explanationBn: "দামোদর উপত্যকা কর্পোরেশন (DVC) ১৯৪৮ সালে প্রতিষ্ঠার পর বহুমুখী বাঁধ নির্মাণের ফলে দামোদরের বিধ্বংসী বন্যা নিয়ন্ত্রণ করা সম্ভব হয়।",
    explanationEn: "Damodar river was historically called the 'Sorrow of Bengal' before DVC multi-purpose dams were built in 1948.",
    difficulty: "Easy",
    shortConceptBn: "দামোদর ও ডিভিসি",
    shortConceptEn: "Damodar & DVC Project"
  },
  {
    subject: "Geography",
    topicBn: "জোয়ার-ভাটা ও চন্দ্র-সূর্য অবস্থান",
    topicEn: "Tides & Astronomical Alignment",
    questionBn: "পূর্ণিমা ও অমাবস্যা তিথিতে সূর্য, পৃথিবী ও চাঁদ যখন একই সরলরেখায় অবস্থান করে, তখন কোন ধরনের জোয়ার হয়?",
    questionEn: "When the Sun, Earth, and Moon align in a straight line (Syzygy) during Full Moon and New Moon, which tides occur?",
    optionsBn: ["A. ভরা কোটাল / তেজ কটাল (Spring Tide)", "B. মরা কোটাল (Neap Tide)", "C. বিষুবীয় জোয়ার", "D. পেরিজি জোয়ার"],
    optionsEn: ["A. Spring Tide", "B. Neap Tide", "C. Equatorial Tide", "D. Perigean Tide"],
    correctOptionIndex: 0,
    explanationBn: "সূর্য ও চাঁদের সম্মিলিত আকর্ষণ বলের কারণে সিজিগি (Syzygy) অবস্থানে জলস্ফীতি সর্বোচ্চ হয়, যাকে ভরা কোটাল বা স্প্রিং টাইড বলা হয়।",
    explanationEn: "Combined gravitational pull of Sun and Moon in syzygy produces maximum tidal range known as Spring Tides.",
    difficulty: "Medium",
    shortConceptBn: "ভরা কোটাল ও সিজিগি",
    shortConceptEn: "Spring Tides & Syzygy"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের অরণ্য ও জাতীয় উদ্যান",
    topicEn: "Forests & National Parks",
    questionBn: "ভারতের একমাত্র সক্রিয় আগ্নেয়গিরি 'ব্যারেন দ্বীপ' (Barren Island) কোথায় অবস্থিত?",
    questionEn: "Where is India's only confirmed active volcano, the 'Barren Island', located?",
    optionsBn: ["A. আন্দামান ও নিকোবর দ্বীপপুঞ্জ", "B. লাক্ষাদ্বীপ", "C. পাম্বান দ্বীপ", "D. মাজুলি দ্বীপ"],
    optionsEn: ["A. Andaman and Nicobar Islands", "B. Lakshadweep", "C. Pamban Island", "D. Majuli Island"],
    correctOptionIndex: 0,
    explanationBn: "আন্দামান সাগরে পোর্ট ব্লেয়ার থেকে প্রায় ১৩৮ কিমি উত্তর-পূর্বে ব্যারেন দ্বীপ অবস্থিত। এটি দক্ষিণ এশিয়ার একমাত্র সক্রিয় আগ্নেয়গিরি।",
    explanationEn: "Barren Island in the Andaman Sea is South Asia's only confirmed active volcano.",
    difficulty: "Easy",
    shortConceptBn: "ব্যারেন দ্বীপ আগ্নেয়গিরি",
    shortConceptEn: "Barren Island Active Volcano"
  },
  {
    subject: "Geography",
    topicBn: "বিশ্বের ভূপ্রকৃতি ও মহাসাগর",
    topicEn: "World Physical Geography",
    questionBn: "পৃথিবীর গভীরতম মহাসাগরীয় খাত 'মারিয়ানা ট্রেঞ্চ' কোন মহাসাগরে অবস্থিত?",
    questionEn: "In which ocean is the Mariana Trench, the deepest oceanic trench on Earth, located?",
    optionsBn: ["A. প্রশান্ত মহাসাগর (Pacific Ocean)", "B. আটলান্টিক মহাসাগর", "C. ভারত মহাসাগর", "D. সুমেরু মহাসাগর"],
    optionsEn: ["A. Pacific Ocean", "B. Atlantic Ocean", "C. Indian Ocean", "D. Arctic Ocean"],
    correctOptionIndex: 0,
    explanationBn: "মারিয়ানা ট্রেঞ্চের চ্যালেঞ্জার ডিপ নামক অংশের গভীরতা প্রায় ১০,৯৯৪ মিটার। এটি পশ্চিম প্রশান্ত মহাসাগরে অবস্থিত।",
    explanationEn: "The Mariana Trench (Challenger Deep ~10,994m) is located in the Western Pacific Ocean.",
    difficulty: "Easy",
    shortConceptBn: "মারিয়ানা ট্রেঞ্চ",
    shortConceptEn: "Mariana Trench Depth"
  },
  {
    subject: "Geography",
    topicBn: "আন্তর্জাতিক সীমারেখা ও প্রণালী",
    topicEn: "International Boundaries & Straits",
    questionBn: "ভারত এবং শ্রীলঙ্কাকে পৃথককারী সংকীর্ণ জলপ্রণালীটির নাম কী?",
    questionEn: "What is the name of the narrow strait that separates India and Sri Lanka?",
    optionsBn: ["A. পক প্রণালী (Palk Strait)", "B. ১০ ডিগ্রি চ্যানেল", "C. মালাক্কা প্রণালী", "D. হরমুজ প্রণালী"],
    optionsEn: ["A. Palk Strait", "B. 10 Degree Channel", "C. Malacca Strait", "D. Strait of Hormuz"],
    correctOptionIndex: 0,
    explanationBn: "পক প্রণালী তামিলনাড়ু ও শ্রীলঙ্কার জাফনা জেলার মাঝে অবস্থিত। এটি বঙ্গোপসাগর এবং মান্নার উপসাগরকে যুক্ত করেছে।",
    explanationEn: "Palk Strait lies between Tamil Nadu and Sri Lanka, connecting the Bay of Bengal with the Gulf of Mannar.",
    difficulty: "Easy",
    shortConceptBn: "পক প্রণালী",
    shortConceptEn: "Palk Strait Geography"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের বৃহত্তম নদীবকদ্বীপ",
    topicEn: "River Islands of India",
    questionBn: "বিশ্বের বৃহত্তম বসতিপূর্ণ নদীদ্বীপ 'মাজুলি' কোন নদীর বুকে অবস্থিত?",
    questionEn: "Which river hosts 'Majuli', the world's largest inhabited river island?",
    optionsBn: ["A. ব্রহ্মপুত্র নদী (আসাম)", "B. গঙ্গা নদী", "C. সিন্ধু নদী", "D. গোদাবরী নদী"],
    optionsEn: ["A. Brahmaputra River (Assam)", "B. Ganga River", "C. Indus River", "D. Godavari River"],
    correctOptionIndex: 0,
    explanationBn: "আসামের ব্রহ্মপুত্র নদীর বুকে মাজুলি অবস্থিত। ২০১৬ সালে মাজুলিকে ভারতের প্রথম দ্বীপ জেলা (Island District) হিসেবে ঘোষণা করা হয়।",
    explanationEn: "Majuli on the Brahmaputra River in Assam is the world's largest river island and India's first island district.",
    difficulty: "Easy",
    shortConceptBn: "মাজুলি নদীদ্বীপ",
    shortConceptEn: "Majuli River Island"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের অক্ষরেখা ও কর্কটক্রান্তি রেখা",
    topicEn: "Tropic of Cancer & Latitudes",
    questionBn: "কর্কটক্রান্তি রেখা (২৩°৩০′ উত্তর) ভারতের মোট কয়টি রাজ্যের ওপর দিয়ে অতিক্রম করেছে?",
    questionEn: "The Tropic of Cancer (23°30' N) passes through how many Indian states?",
    optionsBn: ["A. ৮টি রাজ্য", "B. ৭টি রাজ্য", "C. ৯টি রাজ্য", "D. ৬টি রাজ্য"],
    optionsEn: ["A. 8 States", "B. 7 States", "C. 9 States", "D. 6 States"],
    correctOptionIndex: 0,
    explanationBn: "৮টি রাজ্য হলো: গুজরাট, রাজস্থান, মধ্যপ্রদেশ, ছত্তিশগড়, ঝাড়খণ্ড, পশ্চিমবঙ্গ, ত্রিপুরা ও মিজোরাম।",
    explanationEn: "The 8 states are: Gujarat, Rajasthan, MP, Chhattisgarh, Jharkhand, West Bengal, Tripura, and Mizoram.",
    difficulty: "Medium",
    shortConceptBn: "কর্কটক্রান্তি রেখা ও ৮ রাজ্য",
    shortConceptEn: "Tropic of Cancer in 8 States"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের জলপ্রপাত",
    topicEn: "Waterfalls of India",
    questionBn: "ভারতের অন্যতম উচ্চতম জলপ্রপাত 'যোগ জলপ্রপাত' (গেরসোপ্পা) কর্ণাটকের কোন নদীর ওপর অবস্থিত?",
    questionEn: "On which river in Karnataka is the famous Jog Falls (Gersoppa) located?",
    optionsBn: ["A. শরাবতী নদী (Sharavathi)", "B. কাবেরী নদী", "C. কৃষ্ণা নদী", "D. তুঙ্গভদ্রা নদী"],
    optionsEn: ["A. Sharavathi River", "B. Kaveri River", "C. Krishna River", "D. Tungabhadra River"],
    correctOptionIndex: 0,
    explanationBn: "শরাবতী নদীর ওপর অবস্থিত যোগ জলপ্রপাতের উচ্চতা প্রায় ২৫৩ মিটার। এর অপর নাম মহাত্মা গান্ধী জলপ্রপাত।",
    explanationEn: "Jog Falls (253m) is located on the Sharavathi River in Shivamogga district of Karnataka.",
    difficulty: "Medium",
    shortConceptBn: "যোগ জলপ্রপাত ও শরাবতী",
    shortConceptEn: "Jog Falls on Sharavathi River"
  },
  {
    subject: "Geography",
    topicBn: "ভারতের উপকূলীয় সীমারেখা",
    topicEn: "Coastline of India",
    questionBn: "ভারতের মূল ভূখণ্ডের রাজ্যগুলির মধ্যে কোন রাজ্যের সমুদ্র উপকূলরেখা (Coastline) দীর্ঘতম?",
    questionEn: "Among Indian mainland states, which state possesses the longest coastline?",
    optionsBn: ["A. গুজরাট (Gujarat)", "B. অন্ধ্রপ্রদেশ", "C. তামিলনাড়ু", "D. মহারাষ্ট্র"],
    optionsEn: ["A. Gujarat", "B. Andhra Pradesh", "C. Tamil Nadu", "D. Maharashtra"],
    correctOptionIndex: 0,
    explanationBn: "গুজরাটের উপকূলরেখার দৈর্ঘ্য প্রায় ১,৬০০ কিমি, যা ভারতের মূল ভূখণ্ডের রাজ্যগুলির মধ্যে দীর্ঘতম। দ্বিতীয় স্থানে রয়েছে অন্ধ্রপ্রদেশ (~৯৭৪ কিমি)।",
    explanationEn: "Gujarat has the longest coastline in mainland India (~1,600 km), followed by Andhra Pradesh (~974 km).",
    difficulty: "Easy",
    shortConceptBn: "গুজরাটের দীর্ঘতম উপকূলরেখা",
    shortConceptEn: "Longest Coastline in Gujarat"
  },

  // HISTORY - 1
  {
    subject: "History",
    topicBn: "হরপ্পা ও সিন্ধু সভ্যতা",
    topicEn: "Indus Valley Civilization",
    questionBn: "সিন্ধু সভ্যতার বিখ্যাত বন্দর শহর ও পোতাশ্রয় (Dockyard) কোন স্থানে আবিষ্কৃত হয়েছিল?",
    questionEn: "In which Indus Valley civilization site was the world's earliest known tidal dockyard discovered?",
    optionsBn: ["A. লোথাল (গুজরাট)", "B. হরপ্পা", "C. কালিবঙ্গান", "D. ধোলাভিরা"],
    optionsEn: ["A. Lothal (Gujarat)", "B. Harappa", "C. Kalibangan", "D. Dholavira"],
    correctOptionIndex: 0,
    explanationBn: "গুজরাটের ভোগাবর নদীর তীরে লোথাল অবস্থিত। এখানে সিন্ধু সভ্যতার সামুদ্রিক বাণিজ্যের প্রধান পোতাশ্রয় আবিষ্কৃত হয়।",
    explanationEn: "Lothal in Gujarat, situated along the Bhogava river, housed the ancient tidal dockyard for maritime trade.",
    difficulty: "Easy",
    shortConceptBn: "লোথাল বন্দর ও পোতাশ্রয়",
    shortConceptEn: "Lothal Ancient Dockyard"
  },
  {
    subject: "History",
    topicBn: "মৌর্য সাম্রাজ্য ও অশোক",
    topicEn: "Maurya Empire & Ashoka",
    questionBn: "সম্রাট অশোক কোন ঐতিহাসিক যুদ্ধের ভয়াবহ ধ্বংসলীলা দেখে বৌদ্ধ ধর্ম গ্রহণ করেন এবং অহিংসার পথ বেছে নেন?",
    questionEn: "After witnessing the horrors of which historic war did Emperor Ashoka convert to Buddhism and embrace Ahimsa?",
    optionsBn: ["A. কলিঙ্গ যুদ্ধ (২৬১ খ্রিস্টপূর্বাব্দ)", "B. তক্ষশীলার যুদ্ধ", "C. হিদাসপিসের যুদ্ধ", "D. মগধের যুদ্ধ"],
    optionsEn: ["A. Kalinga War (261 BCE)", "B. Battle of Taxila", "C. Battle of the Hydaspes", "D. Magadha War"],
    correctOptionIndex: 0,
    explanationBn: "২৬১ খ্রিস্টপূর্বাব্দে কলিঙ্গ যুদ্ধের পর অশোকের ১৩ নম্বর শিলালিপিতে তাঁর গভীর অনুশোচনা এবং উপগুপ্তের প্রভাবে বৌদ্ধ ধর্ম গ্রহণের বিবরণ পাওয়া যায়।",
    explanationEn: "The Kalinga War (261 BCE), described in Ashoka's Major Rock Edict XIII, led him to adopt Dhamma and Buddhism under monk Upagupta.",
    difficulty: "Easy",
    shortConceptBn: "কলিঙ্গ যুদ্ধ ও অশোক",
    shortConceptEn: "Kalinga War Transformation"
  },
  {
    subject: "History",
    topicBn: "গুপ্ত সাম্রাজ্য",
    topicEn: "Gupta Empire",
    questionBn: "প্রাচীন ভারতের বিখ্যাত কবি ও নাট্যকার কালিদাস কোন গুপ্ত সম্রাটের নবরত্ন সভার সদস্য ছিলেন?",
    questionEn: "The celebrated ancient poet Kalidasa was a jewel in the court of which Gupta emperor?",
    optionsBn: ["A. দ্বিতীয় চন্দ্রগুপ্ত (বিক্রমাদিত্য)", "B. সমুদ্রগুপ্ত", "C. প্রথম কুমারগুপ্ত", "D. শ্রীগুপ্ত"],
    optionsEn: ["A. Chandragupta II (Vikramaditya)", "B. Samudragupta", "C. Kumaragupta I", "D. Sri Gupta"],
    correctOptionIndex: 0,
    explanationBn: "দ্বিতীয় চন্দ্রগুপ্ত বা বিক্রমাদিত্যের রাজসভায় কালিদাস, বরাহমিহির, ধন্বন্তরি প্রমুখ নবরত্ন অলঙ্কৃত করতেন।",
    explanationEn: "Kalidasa was one of the Navaratnas (nine gems) in the court of Chandragupta II (Vikramaditya).",
    difficulty: "Medium",
    shortConceptBn: "কালিদাস ও দ্বিতীয় চন্দ্রগুপ্ত",
    shortConceptEn: "Kalidasa in Vikramaditya's Court"
  },
  {
    subject: "History",
    topicBn: "দিল্লি সালতানাত ও বাজার সংস্কার",
    topicEn: "Delhi Sultanate Reforms",
    questionBn: "দিল্লি সালতানাতের কোন সুলতান মূল্য নিয়ন্ত্রণ ব্যবস্থা ও বাজার সংস্কার নীতি (Market Regulations) প্রবর্তন করেন?",
    questionEn: "Which Delhi Sultan introduced comprehensive Market Control and Price Regulation policies?",
    optionsBn: ["A. আলাউদ্দিন খলজি (Alauddin Khilji)", "B. মহম্মদ বিন তুঘলক", "C. ইলতুৎমিশ", "D. গিয়াসউদ্দিন বলবন"],
    optionsEn: ["A. Alauddin Khilji", "B. Muhammad bin Tughlaq", "C. Iltutmish", "D. Ghiyasuddin Balban"],
    correctOptionIndex: 0,
    explanationBn: "আলাউদ্দিন খলজি বিশাল স্থায়ী সেনাবাহিনী কম খরচে রক্ষণাবেক্ষণের জন্য 'শাহনা-ই-মন্ডি' ও নিত্যপ্রয়োজনীয় দ্রব্যের নির্ধারিত মূল্য আইন প্রণয়ন করেন।",
    explanationEn: "Alauddin Khilji instituted strict market price controls overseen by officers called Shahna-i-Mandi to maintain a standing army.",
    difficulty: "Easy",
    shortConceptBn: "আলাউদ্দিন খলজির বাজার নীতি",
    shortConceptEn: "Market Controls of Alauddin Khilji"
  },
  {
    subject: "History",
    topicBn: "১৮৫৭ সালের মহাবিদ্রোহ",
    topicEn: "Revolt of 1857",
    questionBn: "১৮৫৭ সালের মহাবিদ্রোহে ব্যারাকপুর সেনা ছাউনিতে সর্বপ্রথম ব্রিটিশ অফিসারদের বিরুদ্ধে বিদ্রোহ ঘোষণা করেন কে?",
    questionEn: "Who first rose in revolt against British commanding officers at Barrackpore Cantonment on March 29, 1857?",
    optionsBn: ["A. মঙ্গল পাণ্ডে (Mangal Pandey)", "B. তাতিয়া তোপে", "C. কুনওয়ার সিংহ", "D. বখত খান"],
    optionsEn: ["A. Mangal Pandey", "B. Tatya Tope", "C. Kunwar Singh", "D. Bakht Khan"],
    correctOptionIndex: 0,
    explanationBn: "৩৪তম বেঙ্গল নেটিভ ইনফ্যান্ট্রির সিপাহি মঙ্গল পাণ্ডে এনফিল্ড রাইফেলের কার্তুজ ব্যবহারে অস্বীকৃতি জানিয়ে ব্রিটিশ বিরোধী প্রতিরোধ সূচনা করেন।",
    explanationEn: "Mangal Pandey of the 34th Bengal Native Infantry fired the first shot against British rule in Barrackpore on March 29, 1857.",
    difficulty: "Easy",
    shortConceptBn: "মঙ্গল পাণ্ডে ও ব্যারাকপুর",
    shortConceptEn: "Mangal Pandey at Barrackpore"
  },
  {
    subject: "History",
    topicBn: "ভারতীয় জাতীয় কংগ্রেস ও স্বদেশী আন্দোলন",
    topicEn: "INC & Swadeshi Movement",
    questionBn: "১৯০৫ সালের বঙ্গভঙ্গ সিদ্ধান্তের বিরুদ্ধে রবীন্দ্রনাথ ঠাকুর কোন উৎসব উদযাপনের মাধ্যমে ভ্রাতৃত্বের বার্তা দেন?",
    questionEn: "To protest Lord Curzon's Partition of Bengal in 1905, Rabindranath Tagore initiated which unity festival?",
    optionsBn: ["A. রাখিবন্ধন উৎসব (Raksha Bandhan)", "B. বসন্তোৎসব", "C. পৌষ মেলা", "D. বৃক্ষরোপণ উৎসব"],
    optionsEn: ["A. Rakhi Bandhan Festival", "B. Vasantotsav", "C. Poush Mela", "D. Vriksharopan"],
    correctOptionIndex: 0,
    explanationBn: "১৬ই অক্টোবর ১৯০৫ বঙ্গভঙ্গ কার্যকর হওয়ার দিনে রবীন্দ্রনাথ ঠাকুরের আহ্বানে হিন্দু-মুসলিম ঐক্য ও ভ্রাতৃত্বের প্রতীক হিসেবে রাখিবন্ধন পালিত হয়।",
    explanationEn: "On 16 October 1905, Rabindranath Tagore called for Raksha Bandhan across Bengal to foster communal unity against partition.",
    difficulty: "Easy",
    shortConceptBn: "বঙ্গভঙ্গ ও রাখিবন্ধন",
    shortConceptEn: "Rakhi Bandhan in Partition of Bengal"
  },

  // POLITY - 1
  {
    subject: "Indian Polity",
    topicBn: "সংবিধানের প্রস্তাবনা ও মৌলিক কাঠামো",
    topicEn: "Preamble & Basic Structure",
    questionBn: "কোন ঐতিহাসিক সুপ্রিম কোর্ট রায়ে ঘোষিত হয় যে 'সংবিধানের মৌলিক কাঠামো' (Basic Structure) সংশোধন করা যায় না?",
    questionEn: "In which landmark Supreme Court ruling (1973) was the 'Basic Structure Doctrine' of the Constitution established?",
    optionsBn: ["A. কেশবানন্দ ভারতী বনাম কেরালা রাজ্য মামলা (1973)", "B. গোলকনাথ মামলা", "C. মিনার্ভা মিলস মামলা", "D. বেরুবাড়ি মামলা"],
    optionsEn: ["A. Kesavananda Bharati v. State of Kerala (1973)", "B. Golaknath Case", "C. Minerva Mills Case", "D. Berubari Case"],
    correctOptionIndex: 0,
    explanationBn: "১৯৭৩ সালের কেশবানন্দ ভারতী মামলায় ১৩ জন বিচারপতির ঐতিহাসিক বেঞ্চ রায় দেয় যে সংসদ সংবিধানের মৌলিক কাঠামো পরিবর্তন করতে পারবে না।",
    explanationEn: "In Kesavananda Bharati (1973), a 13-judge constitutional bench ruled that Parliament cannot alter the basic structure of the Constitution under Article 368.",
    difficulty: "Medium",
    shortConceptBn: "কেশবানন্দ ভারতী মামলা",
    shortConceptEn: "Basic Structure Doctrine"
  },
  {
    subject: "Indian Polity",
    topicBn: "মৌলিক অধিকার ও অনুচ্ছেদ ৩২",
    topicEn: "Fundamental Rights & Article 32",
    questionBn: "ড. বি. আর. আম্বেদকর ভারতীয় সংবিধানের কোন ধারাকে 'সংবিধানের হৃদয় ও আত্মা' (Heart and Soul of the Constitution) বলে আখ্যায়িত করেছিলেন?",
    questionEn: "Which Article of the Indian Constitution was described by Dr. B.R. Ambedkar as the 'Heart and Soul of the Constitution'?",
    optionsBn: ["A. ধারা ৩২ (সাংবিধানিক প্রতিবিধানের অধিকার)", "B. ধারা ২১ (জীবনধারণের অধিকার)", "C. ধারা ১৪ (সমতার অধিকার)", "D. ধারা ১৯ (স্বাধীনতার অধিকার)"],
    optionsEn: ["A. Article 32 (Right to Constitutional Remedies)", "B. Article 21 (Right to Life)", "C. Article 14 (Right to Equality)", "D. Article 19 (Right to Freedom)"],
    correctOptionIndex: 0,
    explanationBn: "ধারা ৩২ অনুযায়ী সুপ্রিম কোর্ট মৌলিক অধিকার বলবৎ করতে ৫ প্রকার রিট (Habeas Corpus, Mandamus, Prohibition, Quo-Warranto, Certiorari) জারি করতে পারে।",
    explanationEn: "Article 32 empowers citizens to move the Supreme Court directly for enforcement of Fundamental Rights via constitutional writs.",
    difficulty: "Easy",
    shortConceptBn: "ধারা ৩২ ও রিট",
    shortConceptEn: "Article 32 Constitutional Remedies"
  },
  {
    subject: "Indian Polity",
    topicBn: "রাষ্ট্রপতি ও সংসদ",
    topicEn: "President & Parliament",
    questionBn: "ভারতীয় সংসদে কোনো বিলকে 'অর্থবিল' (Money Bill) হিসেবে চূড়ান্ত প্রত্যয়ন করার ক্ষমতা কার রয়েছে?",
    questionEn: "Who holds the final authority to certify whether a legislative bill is a 'Money Bill' under Article 110?",
    optionsBn: ["A. লোকসভার স্পিকার (Speaker of Lok Sabha)", "B. ভারতের রাষ্ট্রপতি", "C. প্রধানমন্ত্রী", "D. অর্থমন্ত্রী"],
    optionsEn: ["A. Speaker of the Lok Sabha", "B. President of India", "C. Prime Minister", "D. Finance Minister"],
    correctOptionIndex: 0,
    explanationBn: "সংবিধানের ধারা ১১০(৩) অনুসারে কোনো বিল অর্থবিল কি না সে বিষয়ে লোকসভার স্পিকারের সিদ্ধান্তই চূড়ান্ত।",
    explanationEn: "Under Article 110(3), the decision of the Speaker of the Lok Sabha on whether a bill is a Money Bill is final and non-justiciable.",
    difficulty: "Easy",
    shortConceptBn: "লোকসভার স্পিকার ও অর্থবিল",
    shortConceptEn: "Speaker's Decision on Money Bill"
  },

  // SCIENCE - 1
  {
    subject: "General Science",
    topicBn: "পদার্থবিদ্যা: আলোর প্রতিসরণ ও পূর্ণ অভ্যন্তরীণ প্রতিফলন",
    topicEn: "Physics: Total Internal Reflection",
    questionBn: "অপটিক্যাল ফাইবার (Optical Fiber) এবং মরুভূমির মরীচিকা আলোর কোন মূল ধর্মের ওপর ভিত্তি করে কাজ করে?",
    questionEn: "Optical fiber communication and desert mirages operate on which fundamental optical principle?",
    optionsBn: ["A. পূর্ণ অভ্যন্তরীণ প্রতিফলন (Total Internal Reflection)", "B. আলোর অপবর্তন (Diffraction)", "C. আলোর বিচ্ছুরণ (Dispersion)", "D. আলোর সমবর্তন (Polarization)"],
    optionsEn: ["A. Total Internal Reflection", "B. Diffraction", "C. Dispersion", "D. Polarization"],
    correctOptionIndex: 0,
    explanationBn: "ঘন মাধ্যম থেকে লঘু মাধ্যমে আলো সংকট কোণের চেয়ে বেশি কোণে আপতিত হলে সম্পূর্ণ আলো প্রতিফলিত হয়ে ঘন মাধ্যমে ফিরে আসে।",
    explanationEn: "Total internal reflection occurs when light traveling in a denser medium strikes a boundary at an angle greater than the critical angle.",
    difficulty: "Easy",
    shortConceptBn: "পূর্ণ অভ্যন্তরীণ প্রতিফলন",
    shortConceptEn: "Total Internal Reflection Principles"
  },
  {
    subject: "General Science",
    topicBn: "জীববিদ্যা: মানব সংবহনতন্ত্র ও রক্ত",
    topicEn: "Biology: Human Blood Groups",
    questionBn: "মানব রক্তের কোন গ্রুপকে 'সর্বজনীন দাতা' (Universal Donor) বলা হয়?",
    questionEn: "Which human blood group is known as the 'Universal Donor' because its RBCs lack A and B antigens?",
    optionsBn: ["A. O নেগেটিভ (O-)", "B. AB পজিটিভ (AB+)", "C. A পজিটিভ", "D. B নেগেটিভ"],
    optionsEn: ["A. O Negative (O-)", "B. AB Positive (AB+)", "C. A Positive", "D. B Negative"],
    correctOptionIndex: 0,
    explanationBn: "O নেগেটিভ রক্তে কোনো A বা B অ্যান্টিজেন এবং Rh অ্যান্টিজেন থাকে না, তাই এটি যেকোনো রোগীকে জরুরি পরিস্থিতিতে দেওয়া যায়।",
    explanationEn: "O Negative blood lacks A, B, and Rh antigens on erythrocytes, making it safe for emergency transfusions to all ABO/Rh types.",
    difficulty: "Easy",
    shortConceptBn: "সর্বজনীন দাতা রক্ত গ্রুপ",
    shortConceptEn: "Universal Donor Blood Group"
  },
  {
    subject: "General Science",
    topicBn: "রসায়ন: অ্যাসিড, ক্ষার ও পিএইচ স্কেল",
    topicEn: "Chemistry: pH Scale & Pure Water",
    questionBn: "২৫ ডিগ্রি সেলসিয়াস তাপমাত্রায় বিশুদ্ধ জলের পিএইচ (pH) মান কত হয়?",
    questionEn: "What is the pH value of pure distilled water at 25°C (neutral baseline)?",
    optionsBn: ["A. ৭ (নিরপেক্ষ / Neutral)", "B. ০", "C. ১৪", "D. ৫.৫"],
    optionsEn: ["A. 7 (Neutral)", "B. 0", "C. 14", "D. 5.5"],
    correctOptionIndex: 0,
    explanationBn: "pH স্কেলে ৭ হলো নিরপেক্ষ মান। ৭-এর কম হলে দ্রবণ আম্লিক এবং ৭-এর বেশি হলে দ্রবণ ক্ষারীয় হয়।",
    explanationEn: "A pH of 7 represents exact neutrality where [H+] = [OH-] = 10^-7 M at 25°C.",
    difficulty: "Easy",
    shortConceptBn: "পিএইচ স্কেল ও নিরপেক্ষ জল",
    shortConceptEn: "Neutral pH of Water"
  }
];

// Helper to retrieve seed questions matching a subject
export function getSubjectSeedQuestions(
  subjectName: string,
  language: string,
  targetCount: number = 100
): ExamMCQ[] {
  const isBn = language === 'bn' || language?.toLowerCase()?.includes('bengali');
  const normSubject = (subjectName || 'General').toLowerCase();

  const matchingSeeds = COMPREHENSIVE_SEEDS.filter(s => 
    s.subject.toLowerCase() === normSubject || 
    normSubject.includes(s.subject.toLowerCase()) || 
    s.subject.toLowerCase().includes(normSubject)
  );

  const pool = matchingSeeds.length > 0 ? matchingSeeds : COMPREHENSIVE_SEEDS;

  const result: ExamMCQ[] = pool.map((s, idx) => ({
    id: `seed-${s.subject.toLowerCase()}-${idx + 1}`,
    questionNumber: idx + 1,
    subject: s.subject,
    topic: isBn ? s.topicBn : s.topicEn,
    difficulty: s.difficulty,
    question: isBn ? s.questionBn : s.questionEn,
    options: isBn ? s.optionsBn : s.optionsEn,
    correctOptionIndex: s.correctOptionIndex,
    explanation: isBn ? s.explanationBn : s.explanationEn,
    shortConcept: isBn ? s.shortConceptBn : s.shortConceptEn,
    rememberPoint: isBn ? `মনে রাখুন: ${s.shortConceptBn}` : `Key Point: ${s.shortConceptEn}`
  }));

  return result;
}
