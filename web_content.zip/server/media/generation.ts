export type MediaKind = "IMAGE" | "VIDEO" | "PDF" | "DOCUMENT";

export interface GenerationRequest {
  kind: MediaKind;
  prompt: string;
}

export function generationCapability(kind: MediaKind) {
  return {
    kind,
    status: "CONFIG_REQUIRED" as const,
    reason: "Connect a legitimate generation provider or local renderer."
  };
}
