const express=require('express');
const cors=require('cors');
const helmet=require('helmet');
const multer=require('multer');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const {Pool}=require('pg');
require('dotenv').config?.();

const app=express();
app.use(helmet({crossOriginResourcePolicy:false}));
app.use(cors());
app.use(express.json({limit:'2mb'}));
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024}});
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?.includes('localhost')?false:{rejectUnauthorized:false}});
const ADMIN=process.env.ADMIN_SECRET||'CHANGE_ME';
const JWT=process.env.JWT_SECRET||'CHANGE_ME_JWT';

async function init(){
 await pool.query(`CREATE EXTENSION IF NOT EXISTS pgcrypto;
 CREATE TABLE IF NOT EXISTS games(id TEXT PRIMARY KEY,name TEXT NOT NULL,version TEXT,cat TEXT,rating INTEGER DEFAULT 0,description TEXT,image_url TEXT,apk TEXT,obb TEXT,data TEXT,size TEXT DEFAULT '',hidden BOOLEAN DEFAULT false,created_at TIMESTAMPTZ DEFAULT now(),updated_at TIMESTAMPTZ DEFAULT now());
 ALTER TABLE games ADD COLUMN IF NOT EXISTS size TEXT DEFAULT ''; ALTER TABLE games ADD COLUMN IF NOT EXISTS hidden BOOLEAN DEFAULT false;
 CREATE TABLE IF NOT EXISTS downloads(id BIGSERIAL PRIMARY KEY,game_id TEXT,game_name TEXT,label TEXT,url TEXT,device_id TEXT,created_at TIMESTAMPTZ DEFAULT now());
 CREATE TABLE IF NOT EXISTS announcements(id BIGSERIAL PRIMARY KEY,title TEXT NOT NULL,message TEXT NOT NULL,created_at TIMESTAMPTZ DEFAULT now());
 CREATE TABLE IF NOT EXISTS complaints(id BIGSERIAL PRIMARY KEY,name TEXT,message TEXT NOT NULL,device_id TEXT,app_version TEXT,created_at TIMESTAMPTZ DEFAULT now());
 CREATE TABLE IF NOT EXISTS images(id TEXT PRIMARY KEY,name TEXT NOT NULL,mime TEXT NOT NULL,data BYTEA NOT NULL,created_at TIMESTAMPTZ DEFAULT now());
 CREATE TABLE IF NOT EXISTS users(id UUID PRIMARY KEY DEFAULT gen_random_uuid(),name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,created_at TIMESTAMPTZ DEFAULT now()); CREATE TABLE IF NOT EXISTS user_messages(id BIGSERIAL PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,title TEXT NOT NULL,message TEXT NOT NULL,created_at TIMESTAMPTZ DEFAULT now());`);
}
function admin(req,res,next){if(req.headers.authorization!==`Bearer ${ADMIN}`)return res.status(401).json({error:'unauthorized'});next()}
function user(req,res,next){try{const h=req.headers.authorization||'';req.user=jwt.verify(h.replace(/^Bearer /,''),JWT);next()}catch{return res.status(401).json({error:'unauthorized'})}}
app.get('/api/health',(req,res)=>res.json({ok:true,version:process.env.APP_VERSION_NAME||'3.0'}));
app.get('/api/games',async(req,res)=>{try{const r=await pool.query('SELECT id,name,version,cat,rating,description AS desc,image_url AS "imageUrl",apk,obb,data,created_at AS "createdAt",updated_at AS "updatedAt" FROM games ORDER BY created_at DESC');res.json(r.rows)}catch(e){res.status(500).json({error:'db'})}});
app.get('/api/admin/games',admin,async(req,res)=>{const r=await pool.query('SELECT * FROM games ORDER BY created_at DESC');res.json(r.rows)});
app.post('/api/games',admin,async(req,res)=>{const g=req.body||{};if(!g.id||!g.name)return res.status(400).json({error:'id/name required'});try{const r=await pool.query(`INSERT INTO games(id,name,version,cat,rating,description,image_url,apk,obb,data,size,hidden) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,version=EXCLUDED.version,cat=EXCLUDED.cat,rating=EXCLUDED.rating,description=EXCLUDED.description,image_url=EXCLUDED.image_url,apk=EXCLUDED.apk,obb=EXCLUDED.obb,data=EXCLUDED.data,size=EXCLUDED.size,hidden=EXCLUDED.hidden,updated_at=now() RETURNING *`,[g.id,g.name,g.version||'1.0',g.cat||g.category||'ألعاب خفيفة',Number(g.rating||0),g.desc||g.description||'',g.imageUrl||'',g.apk||'',g.obb||'',g.data||'',g.size||'',!!g.hidden]);res.json(r.rows[0])}catch(e){res.status(500).json({error:'db'})}});
app.delete('/api/games/:id',admin,async(req,res)=>{await pool.query('DELETE FROM games WHERE id=$1',[req.params.id]);res.json({ok:true})});
app.post('/api/downloads',async(req,res)=>{const {gameId,gameName,label,url,deviceId}=req.body||{}; if(!url)return res.status(400).json({error:'url required'}); await pool.query('INSERT INTO downloads(game_id,game_name,label,url,device_id) VALUES($1,$2,$3,$4,$5)',[String(gameId||''),gameName||'',label||'',url,deviceId||'']); res.json({ok:true})});
app.get('/api/admin/stats',admin,async(req,res)=>{const games=(await pool.query('SELECT COUNT(*)::int count FROM games')).rows[0].count;const downloads=(await pool.query('SELECT COUNT(*)::int count FROM downloads')).rows[0].count;const byGame=await pool.query('SELECT game_id AS id,game_name AS name,COUNT(*)::int downloads FROM downloads GROUP BY game_id,game_name ORDER BY downloads DESC LIMIT 20');res.json({games,downloads,byGame:byGame.rows})});
app.post('/api/admin/notify',admin,async(req,res)=>{const {title,message}=req.body||{}; if(!title||!message)return res.status(400).json({error:'title/message required'}); res.json({ok:true,note:'Android clients poll the catalog and generate notifications locally.'})});
app.get('/api/complaints',admin,async(req,res)=>{const r=await pool.query('SELECT id,name,message,device_id AS "deviceId",app_version AS "appVersion",created_at AS "createdAt" FROM complaints ORDER BY created_at DESC');res.json(r.rows)});
app.post('/api/complaints',async(req,res)=>{const {name,message,deviceId,appVersion}=req.body||{};if(!message)return res.status(400).json({error:'message required'});const r=await pool.query('INSERT INTO complaints(name,message,device_id,app_version) VALUES($1,$2,$3,$4) RETURNING id',[name||'',message,deviceId||'',appVersion||'']);res.json({ok:true,id:r.rows[0].id})});
app.delete('/api/complaints/:id',admin,async(req,res)=>{await pool.query('DELETE FROM complaints WHERE id=$1',[req.params.id]);res.json({ok:true})});
app.post('/api/images',admin,upload.single('image'),async(req,res)=>{if(!req.file)return res.status(400).json({error:'image required'});const id='img_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);await pool.query('INSERT INTO images(id,name,mime,data) VALUES($1,$2,$3,$4)',[id,req.file.originalname,req.file.mimetype,req.file.buffer]);res.json({id,name:req.file.originalname,url:`/api/images/${id}`})});
app.get('/api/images',async(req,res)=>{const r=await pool.query('SELECT id,name,encode(data,\'base64\') AS b64,mime FROM images ORDER BY created_at DESC');res.json(r.rows.map(x=>({id:x.id,name:x.name,url:`data:${x.mime};base64,${x.b64}`})))});
app.get('/api/images/:id',async(req,res)=>{const r=await pool.query('SELECT mime,data FROM images WHERE id=$1',[req.params.id]);if(!r.rowCount)return res.sendStatus(404);res.set('Content-Type',r.rows[0].mime).send(r.rows[0].data)});
app.post('/api/auth/register',async(req,res)=>{const {name,email,password}=req.body||{};if(!name||!email||!password||password.length<6)return res.status(400).json({error:'invalid'});try{const hash=await bcrypt.hash(password,12);const r=await pool.query('INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email',[name,email.toLowerCase(),hash]);const u=r.rows[0];res.json({token:jwt.sign({id:u.id,name:u.name,email:u.email},JWT,{expiresIn:'30d'}),user:u})}catch(e){res.status(409).json({error:'account_exists'})}});
app.post('/api/auth/login',async(req,res)=>{const {login,password}=req.body||{};const r=await pool.query('SELECT id,name,email,password_hash FROM users WHERE lower(email)=lower($1) OR lower(name)=lower($1) LIMIT 1',[login||'']);if(!r.rowCount||!(await bcrypt.compare(password||'',r.rows[0].password_hash)))return res.status(401).json({error:'invalid'});const u=r.rows[0];res.json({token:jwt.sign({id:u.id,name:u.name,email:u.email},JWT,{expiresIn:'30d'}),user:{id:u.id,name:u.name,email:u.email}})});
app.get('/api/auth/me',user,(req,res)=>res.json({user:req.user}));
app.get('/api/messages',user,async(req,res)=>{try{const r=await pool.query('SELECT id,title,message,created_at AS "createdAt" FROM user_messages WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50',[req.user.id]);res.json(r.rows)}catch(e){res.status(500).json({error:'db'})}});
app.get('/api/admin/users',admin,async(req,res)=>{try{const r=await pool.query('SELECT id,name,email,created_at AS "createdAt" FROM users ORDER BY created_at DESC');res.json(r.rows)}catch(e){res.status(500).json({error:'db'})}});
app.post('/api/admin/messages',admin,async(req,res)=>{const {title,message,userId}=req.body||{};if(!title||!message)return res.status(400).json({error:'title/message required'});try{if(userId&&userId!=='all'){const r=await pool.query('INSERT INTO user_messages(user_id,title,message) VALUES($1,$2,$3) RETURNING id',[userId,title,message]);return res.json({ok:true,sent:1,id:r.rows[0].id})}const r=await pool.query('INSERT INTO user_messages(user_id,title,message) SELECT id,$1,$2 FROM users RETURNING id',[title,message]);res.json({ok:true,sent:r.rowCount})}catch(e){res.status(500).json({error:'db'})}});
app.get('/api/app-update',(req,res)=>res.json({versionCode:Number(process.env.APP_VERSION_CODE||30),versionName:process.env.APP_VERSION_NAME||'3.0',apkUrl:process.env.APP_APK_URL||'',notes:process.env.APP_UPDATE_NOTES||'تحسينات وإصلاحات'}));
init().then(()=>app.listen(process.env.PORT||8080,()=>console.log('XGaming API ready'))).catch(e=>{console.error(e);process.exit(1)});
