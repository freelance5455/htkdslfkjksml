import crypto from 'node:crypto';
import { promisify } from 'node:util';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import express from 'express';
import multer from 'multer';
import sharp from 'sharp';
import registerFeatures from './features.js';
const scrypt = promisify(crypto.scrypt);
const app = express();
const production = process.env.NODE_ENV === 'production';
const dataDir = path.resolve(process.env.DATA_DIR || 'data');
const imageDir = path.join(dataDir, 'private-images');
fs.mkdirSync(imageDir, { recursive: true, mode: 0o700 });
const db = new DatabaseSync(path.join(dataDir, 'app.sqlite'));
fs.chmodSync(path.join(dataDir, 'app.sqlite'), 0o600);
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, plan TEXT NOT NULL DEFAULT 'free', role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', timezone TEXT NOT NULL DEFAULT 'Africa/Lagos', notifications INTEGER NOT NULL DEFAULT 1, terms_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS usage (user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, period TEXT NOT NULL, signals INTEGER NOT NULL DEFAULT 0, analyses INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,period));
CREATE TABLE IF NOT EXISTS signals (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS analyses (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, image TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payments (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, provider TEXT NOT NULL, reference TEXT UNIQUE NOT NULL, provider_id TEXT, amount INTEGER NOT NULL, currency TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS errors (id TEXT PRIMARY KEY, code TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS rate_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);`);
for(const [table,column,type] of [['users','subscription_expires','TEXT'],['users','notification_preferences',`TEXT NOT NULL DEFAULT '{"email":false,"telegram":false,"whatsapp":false}'`],['payments','renewal_date','TEXT']]) {
if(!db.prepare(`PRAGMA table_info(${table})`).all().some(row=>row.name===column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
}
db.exec(`CREATE TABLE IF NOT EXISTS password_resets (hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, channel TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);`);
const paystackAmount = () => { const value=process.env.PAYSTACK_AMOUNT_NGN; if(!value || !/^\d+(\.\d{1,2})?$/.test(value)) return null; const amount=Math.round(Number(value)*100); return Number.isSafeInteger(amount) && amount>=100 && amount<=100000000 ? amount : null; };
const defaults = { signalLimit: 5, analysisLimit: 5, timezone: 'Africa/Lagos', announcement: '', pricing: { stripe: { amount: 1999, currency: 'usd' }, paystack: { amount: paystackAmount(), currency: 'NGN' } }, categories: ['forex', 'crypto', 'stocks', 'commodities', 'indices'] };
db.prepare('INSERT OR IGNORE INTO settings VALUES (1,?)').run(JSON.stringify(defaults));
const settings = () => ({...JSON.parse(db.prepare('SELECT value FROM settings WHERE id=1').get().value),timezone:'Africa/Lagos',pricing:defaults.pricing});
db.prepare("UPDATE users SET timezone='Africa/Lagos'").run();
function expireSubscriptions() { db.prepare("UPDATE users SET plan='free' WHERE plan='pro' AND (subscription_expires IS NULL OR subscription_expires<=?)").run(new Date().toISOString()); }
const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const safe = user => user ? Object.fromEntries(['id','name','email','plan','role','created_at','status','timezone','subscription_expires'].map(key => [key,user[key]])) : null;
const fail = (status, message) => Object.assign(new Error(message), { status });
const wrap = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const transaction = fn => { db.exec('BEGIN IMMEDIATE'); try { const result = fn(); db.exec('COMMIT'); return result; } catch (error) { db.exec('ROLLBACK'); throw error; } };
const integrations = () => ({ ai: !!process.env.OPENAI_API_KEY, stripe: !!process.env.STRIPE_SECRET_KEY, paystack: !!process.env.PAYSTACK_SECRET_KEY && paystackAmount()!==null, telegram: false, whatsapp: false });
const publicSettings = () => { const s = settings(); return { signalLimit:s.signalLimit, analysisLimit:s.analysisLimit, timezone:s.timezone, announcement:s.announcement }; };
const period = () => { const parts=new Intl.DateTimeFormat('en-CA',{timeZone:settings().timezone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()); const get=type=>parts.find(part=>part.type===type).value; return `${get('year')}-${get('month')}-${get('day')}`; };
function usage(userId) { const row = db.prepare('SELECT signals,analyses FROM usage WHERE user_id=? AND period=?').get(userId,period()); return row || {signals:0,analyses:0}; }
function reserve(user, kind) { return transaction(() => { const month = period(); db.prepare('INSERT OR IGNORE INTO usage(user_id,period) VALUES (?,?)').run(user.id,month); const count = db.prepare(`SELECT ${kind} AS count FROM usage WHERE user_id=? AND period=?`).get(user.id,month).count; if(user.plan !== 'pro' && count >= settings()[kind === 'signals' ? 'signalLimit' : 'analysisLimit']) throw fail(429,`Daily ${kind === 'signals' ? 'signal' : 'analysis'} limit of ${settings()[kind === 'signals' ? 'signalLimit' : 'analysisLimit']} reached. Resets at midnight Africa/Lagos.`); db.prepare(`UPDATE usage SET ${kind}=${kind}+1 WHERE user_id=? AND period=?`).run(user.id,month); return month; }); }
function refund(userId, month, kind) { db.prepare(`UPDATE usage SET ${kind}=MAX(0,${kind}-1) WHERE user_id=? AND period=?`).run(userId,month); }
function limited(req, prefix, max, milliseconds) { const key = hash(prefix + ':' + req.ip); const time = Date.now(); const blocked = transaction(() => { const row = db.prepare('SELECT * FROM rate_limits WHERE key=?').get(key); if(!row || row.expires <= time) { db.prepare('INSERT OR REPLACE INTO rate_limits VALUES (?,1,?)').run(key,time+milliseconds); return false; } if(row.count >= max) return true; db.prepare('UPDATE rate_limits SET count=count+1 WHERE key=?').run(key); return false; }); if(blocked) throw fail(429,'Too many requests. Please try again later.'); }
app.disable('x-powered-by');
if(process.env.TRUST_PROXY === '1') app.set('trust proxy',1);
app.use((req,res,next) => { res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY'}); next(); });
app.use('/api', (req,res,next) => { res.set('Cache-Control','no-store'); try { limited(req,'api',240,60000); if(!['GET','HEAD','OPTIONS'].includes(req.method)) { let origin; try { origin = new URL(req.headers.origin).origin; } catch { throw fail(403,'A valid same-origin Origin header is required.'); } const expected = process.env.APP_ORIGIN || `${req.protocol}://${req.get('host')}`; if(origin !== new URL(expected).origin || req.headers['sec-fetch-site'] === 'cross-site') throw fail(403,'Cross-origin request rejected.'); } next(); } catch(error) { next(error); } });
app.use('/api', express.json({limit:'32kb'}));
app.use('/api', (req,res,next) => { expireSubscriptions(); const match = (req.headers.cookie || '').split(';').map(x=>x.trim()).find(x=>x.startsWith('session=')); if(match) { const token = match.slice(8); if(/^[a-f0-9]{64}$/.test(token)) { const row = db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.hash=? AND s.expires>?').get(hash(token),Date.now()); if(row && row.status === 'active') req.user=row; req.sessionHash=hash(token); } } next(); });
function auth(req,res,next) { if(!req.user) return next(fail(401,'Authentication required.')); next(); }
function admin(req,res,next) { if(req.user?.role !== 'admin') return next(fail(403,'Administrator access required.')); next(); }
function cookie(res, token, clear=false) { res.cookie('session',token,{httpOnly:true,sameSite:'lax',secure:production,path:'/',maxAge:clear ? 0 : 7*86400000}); }
function newSession(req,res,user) { const token = crypto.randomBytes(32).toString('hex'); transaction(() => { if(req.sessionHash) db.prepare('DELETE FROM sessions WHERE hash=?').run(req.sessionHash); db.prepare('INSERT INTO sessions VALUES (?,?,?)').run(hash(token),user.id,Date.now()+7*86400000); }); cookie(res,token); }
function text(value,min,max,label) { if(typeof value !== 'string' || value.trim().length < min || value.trim().length > max) throw fail(400,`Invalid ${label}.`); return value.trim(); }
function timezone(value) { const v = text(value,1,80,'timezone'); try { new Intl.DateTimeFormat('en',{timeZone:v}).format(); } catch { throw fail(400,'Invalid timezone.'); } return v; }
const signalView = (row,user) => { const value=JSON.parse(row.payload); if(user.plan !== 'pro') { delete value.entry; delete value.stop_loss; delete value.take_profit; delete value.confidence; value.redacted=true; } return value; };
const analysisView = (row,user) => { const value=JSON.parse(row.payload); if(user.plan !== 'pro') { delete value.report; value.redacted=true; } return value; };
const ownSignals = user => db.prepare('SELECT payload FROM signals WHERE user_id=? ORDER BY rowid DESC LIMIT 100').all(user.id).map(row=>signalView(row,user));
const ownAnalyses = user => db.prepare('SELECT payload FROM analyses WHERE user_id=? ORDER BY rowid DESC LIMIT 100').all(user.id).map(row=>analysisView(row,user));
app.get('/api/session',(req,res)=>res.json({user:safe(req.user),settings:publicSettings(),integrations:integrations(),usage:req.user ? usage(req.user.id) : {signals:0,analyses:0},signals:req.user ? ownSignals(req.user) : [],analyses:req.user ? ownAnalyses(req.user) : []}));
app.post('/api/auth/register',wrap(async(req,res)=>{ limited(req,'auth',10,900000); const body=req.body || {}; const name=text(body.name,1,100,'name'); const email=text(body.email,3,254,'email').toLowerCase(); if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw fail(400,'Invalid email.'); if(typeof body.password !== 'string' || body.password.length < 12 || body.password.length > 128) throw fail(400,'Password must contain 12 to 128 characters.'); if(body.password !== body.confirmPassword) throw fail(400,'Passwords do not match.'); if(body.terms !== true) throw fail(400,'You must accept the terms.'); const salt=crypto.randomBytes(16).toString('hex'); const password=`${salt}:${(await scrypt(body.password,salt,64)).toString('hex')}`; const userId=id(); try { db.prepare('INSERT INTO users(id,name,email,password,created_at,terms_at,timezone) VALUES (?,?,?,?,?,?,?)').run(userId,name,email,password,now(),now(),settings().timezone); } catch(error) { if(error.code?.includes('CONSTRAINT')) throw fail(409,'An account with that email already exists.'); throw error; } const user=db.prepare('SELECT * FROM users WHERE id=?').get(userId); newSession(req,res,user); res.status(201).json({user:safe(user)}); }));
app.post('/api/auth/login',wrap(async(req,res)=>{ limited(req,'auth',10,900000); const email=text(req.body?.email,3,254,'email').toLowerCase(); const password=req.body?.password; if(typeof password !== 'string' || password.length>128) throw fail(400,'Invalid password.'); const user=db.prepare('SELECT * FROM users WHERE email=?').get(email); const [salt,stored]=(user?.password || `${'0'.repeat(32)}:${'0'.repeat(128)}`).split(':'); const derived=await scrypt(password,salt,64); if(!crypto.timingSafeEqual(derived,Buffer.from(stored,'hex')) || !user || user.status!=='active') throw fail(401,'Invalid email or password.'); newSession(req,res,user); res.json({user:safe(user)}); }));
app.post('/api/auth/logout',(req,res)=>{ if(req.sessionHash) db.prepare('DELETE FROM sessions WHERE hash=?').run(req.sessionHash); cookie(res,'',true); res.json({ok:true}); });
app.post('/api/auth/forgot-password',wrap(async(req,res)=>{
limited(req,'forgot',5,3600000);
const email=text(req.body?.email,3,254,'email').toLowerCase();
if(!process.env.RESEND_API_KEY || !process.env.MAIL_FROM || !process.env.APP_ORIGIN) throw fail(503,'Password reset email delivery is not configured. No reset email has been sent.');
let base; try { base=new URL(process.env.APP_ORIGIN); if(base.protocol!=='https:' && (production || !['localhost','127.0.0.1'].includes(base.hostname))) throw new Error(); } catch { throw fail(503,'Password reset email delivery is not configured.'); }
const user=db.prepare("SELECT id FROM users WHERE email=? AND status='active'").get(email);
if(user) {
const token=crypto.randomBytes(32).toString('hex'); const digest=hash(token);
transaction(()=>{ db.prepare('DELETE FROM password_resets WHERE user_id=?').run(user.id); db.prepare('INSERT INTO password_resets VALUES (?,?,?)').run(digest,user.id,Date.now()+1800000); });
const link=new URL('/reset-password',base); link.searchParams.set('token',token);
try { const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},signal:AbortSignal.timeout(15000),body:JSON.stringify({from:process.env.MAIL_FROM,to:[email],subject:'Reset your password',text:`Reset your password using this link within 30 minutes: ${link.href}\nIf you did not request this, ignore this email.`})}); if(!response.ok) throw new Error(); const result=await response.json(); if(!result.id) throw new Error(); } catch { db.prepare('DELETE FROM password_resets WHERE hash=?').run(digest); db.prepare('INSERT INTO errors VALUES (?,?,?)').run(id(),'RESET_EMAIL_DELIVERY_FAILED',now()); }
}
res.json({message:'If an eligible account exists, a password reset email will be sent. Check your inbox.'});
}));
app.post('/api/auth/reset-password',wrap(async(req,res)=>{
limited(req,'reset',10,3600000);
const {token,password,confirmPassword}=req.body || {};
if(typeof token!=='string' || !/^[a-f0-9]{64}$/.test(token)) throw fail(400,'Invalid or expired reset token.');
if(typeof password!=='string' || password.length<12 || password.length>128) throw fail(400,'Password must contain 12 to 128 characters.');
if(password!==confirmPassword) throw fail(400,'Passwords do not match.');
const digest=hash(token); if(!db.prepare('SELECT hash FROM password_resets WHERE hash=? AND expires>?').get(digest,Date.now())) throw fail(400,'Invalid or expired reset token.');
const salt=crypto.randomBytes(16).toString('hex'); const encoded=`${salt}:${(await scrypt(password,salt,64)).toString('hex')}`;
transaction(()=>{ const reset=db.prepare('SELECT user_id FROM password_resets WHERE hash=? AND expires>?').get(digest,Date.now()); if(!reset) throw fail(400,'Invalid or expired reset token.'); db.prepare('UPDATE users SET password=? WHERE id=?').run(encoded,reset.user_id); db.prepare('DELETE FROM sessions WHERE user_id=?').run(reset.user_id); db.prepare('DELETE FROM password_resets WHERE user_id=?').run(reset.user_id); });
cookie(res,'',true); res.json({ok:true});
}));
app.post('/api/setup',auth,(req,res,next)=>{ try { limited(req,'setup',5,3600000); const expected=process.env.ADMIN_SETUP_TOKEN; const supplied=req.body?.token; if(!expected || typeof supplied!=='string' || !crypto.timingSafeEqual(Buffer.from(hash(expected),'hex'),Buffer.from(hash(supplied),'hex'))) throw fail(403,'Setup unavailable or token invalid.'); transaction(()=>{ if(db.prepare("SELECT id FROM users WHERE role='admin'").get()) throw fail(409,'An administrator already exists.'); db.prepare("UPDATE users SET role='admin' WHERE id=?").run(req.user.id); }); res.json({user:safe(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id))}); } catch(error) { next(error); } });
app.get('/api/signals',auth,(req,res)=>res.json({signals:ownSignals(req.user),usage:usage(req.user.id)}));
app.post('/api/signals',auth,(req,res,next)=>{ try { const pair=text(req.body?.pair,2,30,'pair').toUpperCase(); if(!/^[A-Z0-9/._:-]+$/.test(pair)) throw fail(400,'Invalid pair.'); const category=text(req.body?.category,1,40,'category').toLowerCase(); if(!settings().categories.includes(category)) throw fail(400,'Unsupported category.'); if(req.user.plan!=='pro' && (category!=='crypto' || !['BTC/USDT','ETH/USDT'].includes(pair))) throw fail(403,'Free signals support only crypto BTC/USDT and ETH/USDT.'); const month=reserve(req.user,'signals'); let value; try { value={id:id(),pair,category,is_simulated:true,action:['BUY','SELL','WAIT'][crypto.randomInt(3)],entry:100,stop_loss:95,take_profit:110,confidence:crypto.randomInt(40,81),status:'demonstration',created_at:now(),disclaimer:'Random simulated demonstration only; not live market data or financial advice.'}; db.prepare('INSERT INTO signals VALUES (?,?,?)').run(value.id,req.user.id,JSON.stringify(value)); } catch(error) { refund(req.user.id,month,'signals'); throw error; } res.status(201).json({signal:signalView({payload:JSON.stringify(value)},req.user),usage:usage(req.user.id)}); } catch(error) { next(error); } });
registerFeatures({app,db,fs,path,imageDir,express,multer,sharp,auth,admin,wrap,fail,text,timezone,settings,publicSettings,integrations,safe,usage,reserve,refund,id,now,transaction,analysisView,ownAnalyses,cookie,production});
const cleanup=setInterval(()=>{ try { db.prepare('DELETE FROM password_resets WHERE expires<?').run(Date.now()); db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now()); db.prepare('DELETE FROM rate_limits WHERE expires<?').run(Date.now()); db.prepare("DELETE FROM errors WHERE created_at < datetime('now','-30 days')").run(); } catch {} },3600000);
cleanup.unref();
export {app,db};
export default app;
export async function start() {
if(production) {
const dist=path.resolve('dist');
app.use(express.static(dist,{dotfiles:'deny',index:false}));
app.use((req,res,next)=>{ if(req.method!=='GET' || !req.accepts('html')) return res.status(404).send('Not found'); res.sendFile(path.join(dist,'index.html'),error=>{if(error) next(error);}); });
} else {
const {createServer}=await import('vite');
const vite=await createServer({server:{middlewareMode:true,fs:{deny:['.env','.env.*','**/*.{crt,pem}','**/.git/**','**/server/**','**/*.sqlite','**/*.sqlite-*','**/private-images/**',dataDir+'/**']}},appType:'spa'});
app.use(vite.middlewares);
}
return app.listen(Number(process.env.PORT || 3000),'0.0.0.0',()=>{ console.log('Application server listening.'); });
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) start().catch(()=>{console.error('Server startup failed. Check dependencies and environment configuration.');process.exitCode=1;});
