import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import os from "os";
import { fileURLToPath } from "url";
import { spawn } from "child_process";
import archiver from "archiver";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const app = express();
const upload = multer({ dest: path.join(os.tmpdir(), "fiqyy-uploads"), limits: { fileSize: 100 * 1024 * 1024 } });
app.use(express.static(path.join(root, "public")));
app.get("/api/health", (_,res)=>res.json({ok:true, service:"HTMLtoAPK FIQYY"}));

/*
  Build endpoint:
  - Accepts one .zip OR one .html file.
  - Requires Android SDK, Java JDK, Gradle, and network access on this server.
  - Uses Capacitor to wrap the uploaded web project into an Android app.
  This endpoint is a starter build runner, not a hosted build service.
*/
app.post("/api/build", upload.single("project"), async (req,res) => {
  if (!req.file) return res.status(400).json({error:"Pilih file HTML atau ZIP terlebih dahulu."});
  const original = req.file.originalname || "project.zip";
  const ext = path.extname(original).toLowerCase();
  if (![".zip",".html",".htm"].includes(ext)) {
    fs.rmSync(req.file.path,{force:true});
    return res.status(400).json({error:"Format yang didukung hanya .zip, .html, atau .htm."});
  }
  // The actual Android build is intentionally not run on an unconfigured public server.
  // Configure a secure isolated worker before exposing this endpoint to users.
  fs.rmSync(req.file.path,{force:true});
  return res.status(501).json({
    error:"Mesin build Android belum dikonfigurasi. Jalankan server build terisolasi dengan Java JDK, Android SDK, Gradle, dan Capacitor. Lihat README.md untuk alur setup."
  });
});

const port = process.env.PORT || 3000;
app.listen(port,()=>console.log(`HTMLtoAPK FIQYY berjalan di http://localhost:${port}`));
