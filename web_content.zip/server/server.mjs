import http from 'node:http';
import {Readable} from 'node:stream';
import {mkdirSync,chmodSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {createSocial} from './social.mjs';
const directory=resolve(process.env.JAZZY_DATA_DIR||'server/data');
mkdirSync(directory,{recursive:true,mode:0o700});
const file=resolve(directory,'jazzy-social.sqlite');
const app=createSocial({database:file,registrationEnabled:process.env.JAZZY_REGISTRATION_ENABLED!=='false'});
if(existsSync(file))chmodSync(file,0o600);
const server=http.createServer(async (req,res)=>{
  const controller=new AbortController();
  try{
    const options={method:req.method,headers:req.headers,signal:controller.signal};
    if(!['GET','HEAD'].includes(req.method)){options.body=Readable.toWeb(req);options.duplex='half';}
    const result=await app.handle(new Request('http://internal'+req.url,options),req.socket.remoteAddress||'unknown');
    res.writeHead(result.status,Object.fromEntries(result.headers));
    res.end(Buffer.from(await result.arrayBuffer()));
  }catch{if(!res.headersSent)res.writeHead(400,{'content-type':'application/json'});res.end('{"error":"Invalid request."}');}
});
server.requestTimeout=60000;
const port=Number(process.env.PORT||8787);
server.listen(port,process.env.HOST||'0.0.0.0',()=>console.log('JAZZY 2.0 social listening on '+port));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{app.close();process.exit(0);}));
