// AccoNova server — zero dependencies (Node 20+).
//  • serves the single-page app with strict security headers
//  • /api/ai          real AI assistant (Anthropic Messages API; the key lives ONLY in the environment)
//  • /api/checkout    Stripe Checkout for Pro / Business subscriptions
//  • /api/portal      Stripe customer portal (manage / cancel)
//  • /api/stripe/webhook   verified Stripe events → subscription state (source of truth for paid features)
//  • /api/entitlement signed (ECDSA P-256) plan token that the app verifies and applies
// Nothing secret is ever sent to the browser. See docs/DEPLOY.md.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const env = (k, d = '') => (process.env[k] ?? d);

export function createServer(opts = {}) {
  const cfg = {
    port: Number(opts.port ?? env('PORT', '8080')),
    appFile: opts.appFile || env('APP_FILE', path.join(HERE, '..', 'index.html')),
    dataDir: opts.dataDir || env('DATA_DIR', path.join(HERE, 'data')),
    publicUrl: (opts.publicUrl || env('PUBLIC_URL', '')).replace(/\/$/, ''),
    anthropicKey: opts.anthropicKey ?? env('ANTHROPIC_API_KEY'),
    anthropicBase: (opts.anthropicBase || env('ANTHROPIC_BASE_URL', 'https://api.anthropic.com')).replace(/\/$/, ''),
    model: opts.model || env('ANTHROPIC_MODEL', 'claude-sonnet-5-5'),
    stripeKey: opts.stripeKey ?? env('STRIPE_SECRET_KEY'),
    stripeBase: (opts.stripeBase || env('STRIPE_API_BASE', 'https://api.stripe.com')).replace(/\/$/, ''),
    stripeWebhookSecret: opts.stripeWebhookSecret ?? env('STRIPE_WEBHOOK_SECRET'),
    priceIds: opts.priceIds || { pro: env('STRIPE_PRICE_PRO'), business: env('STRIPE_PRICE_BUSINESS') },
    allowedOrigins: (opts.allowedOrigins ?? env('ALLOWED_ORIGINS')).split(',').map(s => s.trim()).filter(Boolean),
    aiPerDay: opts.aiPerDay || { free: Number(env('AI_FREE_PER_DAY', '3')), pro: Number(env('AI_PRO_PER_DAY', '40')), business: Number(env('AI_BUSINESS_PER_DAY', '150')) },
    ipAiPerDay: Number(opts.ipAiPerDay ?? env('AI_IP_PER_DAY', '200')),
    trustProxy: (() => { const v = opts.trustProxy ?? env('TRUST_PROXY', '0'); if (v === true) return 1; const n = Number(v); return Number.isInteger(n) && n > 0 ? Math.min(n, 5) : 0; })(),   // number of trusted reverse proxies in front of this server (0 = none)
    now: opts.now || (() => Date.now()),
  };
  fs.mkdirSync(cfg.dataDir, { recursive: true, mode: 0o700 });

  /* ───────── persistent state (tiny JSON files, atomic writes) ───────── */
  const file = n => path.join(cfg.dataDir, n);
  function readJson(n, d) { try { return JSON.parse(fs.readFileSync(file(n), 'utf8')); } catch { return d; } }
  function writeJson(n, v) { const t = file(n) + '.tmp'; fs.writeFileSync(t, JSON.stringify(v), { mode: 0o600 }); fs.renameSync(t, file(n)); }
  const subs = readJson('subs.json', {});          // cid → {plan,status,periodEnd,customer,subscription,updatedAt}
  const seenEvents = readJson('events.json', {});  // stripe event id → ts
  const saveSubs = () => writeJson('subs.json', subs);
  const saveEvents = () => { const keys = Object.keys(seenEvents); if (keys.length > 5000) keys.sort((a, b) => seenEvents[a] - seenEvents[b]).slice(0, keys.length - 5000).forEach(k => delete seenEvents[k]); writeJson('events.json', seenEvents); };

  /* ───────── signing key (ECDSA P-256) ───────── */
  let keys = readJson('signing-key.json', null);
  if (!keys) {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'P-256' });
    keys = { pub: publicKey.export({ format: 'jwk' }), priv: privateKey.export({ format: 'jwk' }) };
    writeJson('signing-key.json', keys);
  }
  const privKey = crypto.createPrivateKey({ key: keys.priv, format: 'jwk' });
  function signEntitlement(cid) {
    const s = subs[cid] || { plan: 'free', status: 'active', periodEnd: null };
    const t = cfg.now();
    const eff = effective(s);
    const payload = { cid, plan: eff.plan, status: eff.status, periodEnd: eff.periodEnd, iat: t, exp: t + 36 * 3600e3 };
    const raw = JSON.stringify(payload);
    const sig = crypto.sign('sha256', Buffer.from(raw), { key: privKey, dsaEncoding: 'ieee-p1363' }).toString('base64');
    return { raw, sig };
  }
  // A subscription whose paid period has ended (plus 3 days of grace) is treated as free.
  function effective(s) {
    if (!s || s.plan === 'free') return { plan: 'free', status: 'active', periodEnd: null };
    const graceEnd = (s.periodEnd || 0) + 3 * 864e5;
    if (s.status === 'canceled' && cfg.now() > (s.periodEnd || 0)) return { plan: 'free', status: 'active', periodEnd: null };
    if (s.periodEnd && cfg.now() > graceEnd) return { plan: 'free', status: 'active', periodEnd: null };
    return { plan: s.plan, status: s.status, periodEnd: s.periodEnd ?? null };
  }
  const planOf = cid => effective(subs[cid]).plan;

  /* ───────── helpers ───────── */
  const CID_RE = /^c_[A-Za-z0-9]{6,64}$/;
  const SECURITY = {
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
    'Strict-Transport-Security': 'max-age=63072000; includeSubDomains', 'Cross-Origin-Opener-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(self)',
  };
  const CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data: blob:; font-src data:; connect-src 'self'; manifest-src 'self'; worker-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'";
  // X-Forwarded-For is appended to by every proxy, so the client-controlled part is on the LEFT. With N trusted proxies the real client is the Nth entry from the RIGHT.
  function ip(req) {
    if (cfg.trustProxy) { const parts = String(req.headers['x-forwarded-for'] || '').split(',').map(x => x.trim()).filter(Boolean); const x = parts[parts.length - cfg.trustProxy]; if (x && x.length <= 64) return x; }
    return req.socket.remoteAddress || '?';
  }
  function send(res, code, body, headers = {}) {
    const isObj = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
    const data = isObj ? JSON.stringify(body) : body;
    res.writeHead(code, { ...SECURITY, 'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
    res.end(data);
  }
  function cors(req, res) {
    const o = req.headers.origin; if (!o) return;
    if (cfg.allowedOrigins.includes(o) || (cfg.publicUrl && o === cfg.publicUrl)) { res.setHeader('Access-Control-Allow-Origin', o); res.setHeader('Vary', 'Origin'); res.setHeader('Access-Control-Allow-Headers', 'content-type'); res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS'); }
  }
  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      const chunks = []; let n = 0, over = false;
      req.on('data', c => { n += c.length; if (over) { if (n > 8 * 1024 * 1024) req.destroy(); return; } if (n > limit) { over = true; chunks.length = 0; } else chunks.push(c); });
      req.on('end', () => over ? reject(Object.assign(new Error('too_large'), { code: 413 })) : resolve(Buffer.concat(chunks))); req.on('error', reject);
    });
  }
  async function json(req, limit = 64 * 1024) {
    const buf = await readBody(req, limit);
    try { const v = JSON.parse(buf.toString('utf8') || '{}'); if (v === null || typeof v !== 'object') throw 0; return v; } catch { throw Object.assign(new Error('bad_json'), { code: 400 }); }
  }

  /* ───────── rate limiting (in memory; put a real limiter / WAF in front for production) ───────── */
  const buckets = new Map();
  function hit(key, max, windowMs) {
    const t = cfg.now(); let b = buckets.get(key);
    if (!b || t - b.start >= windowMs) { b = { start: t, n: 0 }; buckets.set(key, b); }
    b.n++; if (buckets.size > 20000) for (const [k, v] of buckets) if (t - v.start > 864e5) buckets.delete(k);
    return b.n <= max;
  }
  const day = () => new Date(cfg.now()).toISOString().slice(0, 10);
  const usage = readJson('ai-usage.json', { day: day(), cid: {}, ip: {} });
  function bumpUsage(cid, ipAddr, limit) {
    if (usage.day !== day()) { usage.day = day(); usage.cid = {}; usage.ip = {}; }
    if ((usage.cid[cid] || 0) >= limit) return 'quota';
    if ((usage.ip[ipAddr] || 0) >= cfg.ipAiPerDay) return 'ip_quota';
    usage.cid[cid] = (usage.cid[cid] || 0) + 1; usage.ip[ipAddr] = (usage.ip[ipAddr] || 0) + 1; writeJson('ai-usage.json', usage); return null;
  }

  function refundUsage(cid, ipAddr) { if (usage.cid[cid] > 0) usage.cid[cid]--; if (usage.ip[ipAddr] > 0) usage.ip[ipAddr]--; writeJson('ai-usage.json', usage); }

  /* ───────── AI ───────── */
  const LANG_NAME = { fa: 'Persian (Farsi)', en: 'English', ar: 'Arabic', fr: 'French', de: 'German' };
  const SYSTEM = (lang) => [
    'You are the AccoNova accounting assistant inside a small-business accounting app.',
    'You receive an aggregated JSON summary of the user\'s books (amounts are decimal strings in the stated currency) and a question.',
    'Rules: use ONLY the numbers in the summary; if something is not in the summary, say so and tell the user where in the app to look. Never invent figures, customers or transactions.',
    'Be concise and practical: plain sentences, short bullet lists when useful, no markdown headings. Highlight risks (overdue receivables, falling margin, tax due) and one or two concrete next steps.',
    'You are not a licensed accountant, tax adviser or lawyer; for tax filings or legal questions remind the user to confirm with a professional in their country.',
    `Answer in ${LANG_NAME[lang] || 'English'}. Keep numbers exactly as given.`,
  ].join('\n');

  async function handleAi(req, res) {
    if (!cfg.anthropicKey) return send(res, 503, { error: 'ai_not_configured' });
    const addr = ip(req);
    if (!hit('ai:' + addr, 20, 60e3)) return send(res, 429, { error: 'rate_limited' }, { 'Retry-After': '60' });
    const b = await json(req, 48 * 1024);
    const cid = String(b.cid || ''), question = String(b.question || '').trim().slice(0, 1500), lang = LANG_NAME[b.lang] ? b.lang : 'en';
    if (!CID_RE.test(cid) || question.length < 2) return send(res, 400, { error: 'bad_request' });
    let ctx = ''; try { ctx = JSON.stringify(b.context ?? {}); } catch { ctx = '{}'; }
    if (ctx.length > 12000) return send(res, 413, { error: 'context_too_large' });
    const history = Array.isArray(b.history) ? b.history.slice(-6).filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 2000) })) : [];
    const plan = planOf(cid), limit = cfg.aiPerDay[plan] ?? 0;
    const blocked = bumpUsage(cid, addr, limit);
    if (blocked) return send(res, 429, { error: blocked, plan, limit });
    const messages = [...history, { role: 'user', content: `Books summary (JSON):\n${ctx}\n\nQuestion: ${question}` }];
    // the API requires the first message to be from the user
    while (messages.length && messages[0].role !== 'user') messages.shift();
    let r;
    try {
      r = await fetch(cfg.anthropicBase + '/v1/messages', {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': cfg.anthropicKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: cfg.model, max_tokens: 900, system: SYSTEM(lang), messages }),
        signal: AbortSignal.timeout(45e3),
      });
    } catch { refundUsage(cid, addr); return send(res, 502, { error: 'upstream_unreachable' }); }
    if (!r.ok) { refundUsage(cid, addr); return send(res, r.status === 429 ? 503 : 502, { error: 'upstream_error', status: r.status }); }
    const out = await r.json().catch(() => null);
    const text = out && Array.isArray(out.content) ? out.content.filter(c => c.type === 'text').map(c => c.text).join('\n').trim() : '';
    if (!text) { refundUsage(cid, addr); return send(res, 502, { error: 'empty_answer' }); }
    send(res, 200, { answer: text, plan, remaining: Math.max(0, limit - (usage.cid[cid] || 0)) });
  }

  /* ───────── Stripe (no SDK: plain REST) ───────── */
  const form = o => Object.entries(o).map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&');
  async function stripe(pathname, body) {
    const r = await fetch(cfg.stripeBase + pathname, { method: 'POST', headers: { Authorization: 'Bearer ' + cfg.stripeKey, 'content-type': 'application/x-www-form-urlencoded' }, body: form(body), signal: AbortSignal.timeout(20e3) });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error('stripe_error'), { code: 502, detail: j && j.error && j.error.message }); return j;
  }
  const planByPrice = priceId => Object.keys(cfg.priceIds).find(k => cfg.priceIds[k] && cfg.priceIds[k] === priceId);

  async function handleCheckout(req, res) {
    if (!cfg.stripeKey) return send(res, 503, { error: 'billing_not_configured' });
    if (!hit('co:' + ip(req), 10, 60e3)) return send(res, 429, { error: 'rate_limited' });
    const b = await json(req, 4096), cid = String(b.cid || ''), plan = String(b.plan || '');
    if (!CID_RE.test(cid) || !cfg.priceIds[plan]) return send(res, 400, { error: 'bad_request' });
    const base = cfg.publicUrl || `https://${req.headers.host}`;
    const s = await stripe('/v1/checkout/sessions', { mode: 'subscription', 'line_items[0][price]': cfg.priceIds[plan], 'line_items[0][quantity]': '1', client_reference_id: cid, 'metadata[cid]': cid, 'metadata[plan]': plan, 'subscription_data[metadata][cid]': cid, 'subscription_data[metadata][plan]': plan, success_url: base + '/?billing=success', cancel_url: base + '/?billing=cancel', allow_promotion_codes: 'true' });
    send(res, 200, { url: s.url });
  }
  async function handlePortal(req, res) {
    if (!cfg.stripeKey) return send(res, 503, { error: 'billing_not_configured' });
    if (!hit('po:' + ip(req), 10, 60e3)) return send(res, 429, { error: 'rate_limited' });
    const b = await json(req, 4096), cid = String(b.cid || ''); const s = subs[cid];
    if (!CID_RE.test(cid) || !s || !s.customer) return send(res, 404, { error: 'no_subscription' });
    const p = await stripe('/v1/billing_portal/sessions', { customer: s.customer, return_url: cfg.publicUrl || `https://${req.headers.host}` });
    send(res, 200, { url: p.url });
  }

  // Stripe-Signature: t=timestamp,v1=hexhmac[,v1=...]  (HMAC-SHA256 of `${t}.${rawBody}`)
  function verifyStripe(raw, header) {
    if (!cfg.stripeWebhookSecret || !header) return false;
    const parts = Object.fromEntries(String(header).split(',').map(x => x.split('=')).filter(x => x.length === 2));
    const t = Number(parts.t); if (!Number.isFinite(t) || Math.abs(cfg.now() / 1000 - t) > 300) return false;
    const expected = crypto.createHmac('sha256', cfg.stripeWebhookSecret).update(`${parts.t}.`).update(raw).digest('hex');
    return String(header).split(',').filter(x => x.startsWith('v1=')).some(x => { const v = x.slice(3); return v.length === expected.length && crypto.timingSafeEqual(Buffer.from(v), Buffer.from(expected)); });
  }
  function applyStripeEvent(ev) {
    const o = ev.data && ev.data.object || {};
    const cidOf = x => (x.metadata && x.metadata.cid) || x.client_reference_id || '';
    const bySub = id => Object.keys(subs).find(k => subs[k].subscription === id);
    if (ev.type === 'checkout.session.completed') {
      const cid = cidOf(o); if (!CID_RE.test(cid)) return;
      const plan = o.metadata && o.metadata.plan; if (!cfg.priceIds[plan]) return;
      subs[cid] = { ...(subs[cid] || {}), plan, status: 'active', customer: o.customer, subscription: o.subscription, periodEnd: cfg.now() + 32 * 864e5, updatedAt: cfg.now() };
    } else if (ev.type === 'customer.subscription.updated' || ev.type === 'customer.subscription.created') {
      const cid = cidOf(o) || bySub(o.id); if (!cid || !CID_RE.test(cid)) return;
      const price = o.items && o.items.data && o.items.data[0] && o.items.data[0].price && o.items.data[0].price.id;
      const plan = planByPrice(price) || (subs[cid] && subs[cid].plan) || 'free';
      const status = o.status === 'canceled' ? 'canceled' : (o.status === 'past_due' || o.status === 'unpaid') ? 'past_due' : (o.cancel_at_period_end ? 'canceled' : 'active');
      subs[cid] = { ...(subs[cid] || {}), plan, status, customer: o.customer, subscription: o.id, periodEnd: o.current_period_end ? o.current_period_end * 1000 : (subs[cid] || {}).periodEnd, updatedAt: cfg.now() };
    } else if (ev.type === 'customer.subscription.deleted') {
      const cid = cidOf(o) || bySub(o.id); if (!cid || !subs[cid]) return;
      subs[cid] = { ...subs[cid], status: 'canceled', periodEnd: Math.min(subs[cid].periodEnd || 0, cfg.now()), updatedAt: cfg.now() };
    } else if (ev.type === 'invoice.paid' || ev.type === 'invoice.payment_failed') {
      const cid = bySub(o.subscription); if (!cid) return;
      if (ev.type === 'invoice.paid') { const line = o.lines && o.lines.data && o.lines.data[0]; subs[cid] = { ...subs[cid], status: 'active', periodEnd: line && line.period && line.period.end ? line.period.end * 1000 : subs[cid].periodEnd, updatedAt: cfg.now() }; }
      else subs[cid] = { ...subs[cid], status: 'past_due', updatedAt: cfg.now() };
    } else return;
    saveSubs();
  }
  async function handleWebhook(req, res) {
    const raw = await readBody(req, 512 * 1024);
    if (!verifyStripe(raw, req.headers['stripe-signature'])) return send(res, 400, { error: 'bad_signature' });
    let ev; try { ev = JSON.parse(raw.toString('utf8')); } catch { return send(res, 400, { error: 'bad_payload' }); }
    if (!ev || typeof ev.id !== 'string') return send(res, 400, { error: 'bad_payload' });
    if (seenEvents[ev.id]) return send(res, 200, { ok: true, duplicate: true });
    try { applyStripeEvent(ev); } catch (e) { console.error('[webhook]', e && e.message); return send(res, 500, { error: 'apply_failed' }); }
    seenEvents[ev.id] = cfg.now(); saveEvents();
    send(res, 200, { ok: true });
  }

  /* ───────── static app ───────── */
  let appCache = null;
  function appBytes() {
    if (!appCache || appCache.mtime !== fs.statSync(cfg.appFile).mtimeMs) {
      const raw = fs.readFileSync(cfg.appFile);
      appCache = { mtime: fs.statSync(cfg.appFile).mtimeMs, raw, gz: zlib.gzipSync(raw, { level: 9 }), br: zlib.brotliCompressSync(raw), etag: '"' + crypto.createHash('sha256').update(raw).digest('base64url').slice(0, 22) + '"' };
    }
    return appCache;
  }

  /* ───────── public assets: exact allow-list (PWA files + shell) — nothing else is ever served ───────── */
  const PUB_DIR = opts.publicDir || env('PUBLIC_DIR', path.join(HERE, '..', 'public'));
  const PUB_TYPES = { '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.webmanifest': 'application/manifest+json; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.html': 'text/html; charset=utf-8' };
  const PUB_NAMES = new Set(['sw.js', 'manifest.webmanifest', 'robots.txt', '404.html', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-512-maskable.png']);
  const pubCache = new Map();
  function publicAsset(name) {
    if (!PUB_NAMES.has(name)) return null;
    try {
      const f = path.join(PUB_DIR, name), st = fs.statSync(f); let c = pubCache.get(name);
      if (!c || c.mtime !== st.mtimeMs) { const raw = fs.readFileSync(f); c = { mtime: st.mtimeMs, raw, etag: '"' + crypto.createHash('sha256').update(raw).digest('base64url').slice(0, 22) + '"', type: PUB_TYPES[path.extname(name)] || 'application/octet-stream' }; pubCache.set(name, c); }
      return c;
    } catch { return null; }
  }

  /* ───────── router ───────── */
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x'); cors(req, res);
      if (req.method === 'OPTIONS') return send(res, 204, '');
      if (url.pathname === '/healthz') return send(res, 200, { ok: true });
      if (url.pathname === '/api/config' && req.method === 'GET') return send(res, 200, { publicKey: keys.pub, ai: !!cfg.anthropicKey, billing: !!(cfg.stripeKey && cfg.priceIds.pro), plans: cfg.aiPerDay });
      if (url.pathname === '/api/entitlement' && req.method === 'GET') {
        const cid = url.searchParams.get('cid') || ''; if (!CID_RE.test(cid)) return send(res, 400, { error: 'bad_request' });
        if (!hit('en:' + ip(req), 60, 60e3)) return send(res, 429, { error: 'rate_limited' });
        return send(res, 200, signEntitlement(cid));
      }
      if (url.pathname === '/api/ai' && req.method === 'POST') return await handleAi(req, res);
      if (url.pathname === '/api/checkout' && req.method === 'POST') return await handleCheckout(req, res);
      if (url.pathname === '/api/portal' && req.method === 'POST') return await handlePortal(req, res);
      if (url.pathname === '/api/stripe/webhook' && req.method === 'POST') return await handleWebhook(req, res);
      if ((url.pathname === '/' || url.pathname === '/index.html') && (req.method === 'GET' || req.method === 'HEAD')) {
        const a = appBytes(), ae = String(req.headers['accept-encoding'] || '');
        const h = { ...SECURITY, 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': CSP, 'Cache-Control': 'no-cache', ETag: a.etag, Vary: 'Accept-Encoding' };
        if (req.headers['if-none-match'] === a.etag) { res.writeHead(304, h); return res.end(); }
        let body = a.raw; if (/\bbr\b/.test(ae)) { body = a.br; h['Content-Encoding'] = 'br'; } else if (/\bgzip\b/.test(ae)) { body = a.gz; h['Content-Encoding'] = 'gzip'; }
        h['Content-Length'] = body.length; res.writeHead(200, h); return res.end(req.method === 'HEAD' ? undefined : body);
      }
      if (req.method === 'GET' || req.method === 'HEAD') {
        const a = publicAsset(url.pathname.slice(1));
        if (a) {
          const h = { ...SECURITY, 'Content-Type': a.type, ETag: a.etag, 'Content-Security-Policy': "default-src 'self'", 'Cache-Control': url.pathname.startsWith('/icons/') ? 'public, max-age=604800' : 'no-cache' };
          if (req.headers['if-none-match'] === a.etag) { res.writeHead(304, h); return res.end(); }
          h['Content-Length'] = a.raw.length; res.writeHead(200, h); return res.end(req.method === 'HEAD' ? undefined : a.raw);
        }
      }
      send(res, 404, { error: 'not_found' });       // nothing else is ever served: no source, no tests, no docs
    } catch (e) {
      if (!res.headersSent) send(res, e.code && Number.isInteger(e.code) && e.code < 600 ? e.code : 500, { error: e.message === 'too_large' ? 'too_large' : (e.code ? e.message : 'server_error') });
      if (!e.code) console.error('[error]', e && e.message);
    }
  });
  server.headersTimeout = 15e3; server.requestTimeout = 60e3; server.keepAliveTimeout = 65e3; server.maxHeadersCount = 64;
  return { server, cfg, subs, signEntitlement };
}

// run directly: node server/server.mjs
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { server, cfg } = createServer();
  server.listen(cfg.port, () => console.log(`AccoNova listening on :${cfg.port}  ai=${!!cfg.anthropicKey} billing=${!!cfg.stripeKey} trustProxy=${cfg.trustProxy}`));
  const stop = () => { server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 10e3).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
