'use strict';
/**
 * ترید یار — کانکتورهای فیوچرز (USDT-M دائمی): OKX، Bitget، Gate، KuCoin
 * حجم‌ها همیشه به «واحد ارز پایه» هستند؛ تبدیل به قرارداد/لات داخل کانکتور انجام می‌شود.
 * حد ضرر/سود: همراه سفارش (OKX/Bitget) یا بلافاصله بعد از ورود (Gate/KuCoin)؛
 * اگر ثبت حد ضرر شکست بخورد پوزیشن بلافاصله بسته می‌شود تا هیچ‌وقت بدون حد ضرر نماند.
 */
module.exports = function build(H) {
  const { ExchangeError, hmac, sha512, num, rnd, cleanObj, qs, floorToStep, mkMarket, normInterval, IV_SEC, need } = H;
  const lc = (s) => String(s || '').toLowerCase();
  const tickStr = (v, mk) => floorToStep(v, mk && mk.tickSize > 0 ? mk.tickSize : 0);
  const cid = (s, max, re = /[^A-Za-z0-9]/g) => String(s || rnd(20)).replace(re, '').slice(0, max) || rnd(16);
  const hasQuery = (p) => p && Object.keys(cleanObj(p)).length;

  /* ===================================== OKX ===================================== */
  function okx() {
    const base = 'https://www.okx.com';
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '0') {
        const d = j && j.data && j.data[0];
        throw new ExchangeError((d && d.sMsg) || (j && j.msg) || 'خطای OKX ' + r.status, { code: (d && d.sCode) || (j && j.code), status: r.status, raw: j });
      }
      const d = j.data && j.data[0];
      if (d && d.sCode !== undefined && String(d.sCode) !== '0') throw new ExchangeError(d.sMsg || 'سفارش رد شد', { code: d.sCode, raw: j });
      return j.data;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = new Date(ctx.now()).toISOString();
      const reqPath = path + (hasQuery(params) ? '?' + qs(params) : '');
      const bodyStr = body ? JSON.stringify(body) : '';
      const headers = { 'OK-ACCESS-KEY': creds.apiKey, 'OK-ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + reqPath + bodyStr, 'base64'), 'OK-ACCESS-TIMESTAMP': ts, 'OK-ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, base + reqPath, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
    const specs = new Map();
    const loadSpecs = async (ctx) => {
      const d = await pub(ctx, '/api/v5/public/instruments', { instType: 'SWAP' });
      (d || []).forEach((s) => specs.set(s.instId, { ctVal: num(s.ctVal) || 1, lotSz: num(s.lotSz) || 1, minSz: num(s.minSz) || 1, s }));
      return d || [];
    };
    const specOf = async (ctx, instId) => { if (!specs.has(instId)) await loadSpecs(ctx); const v = specs.get(instId); if (!v) throw new ExchangeError('قرارداد پیدا نشد', { code: 'unknown_symbol' }); return v; };
    const posMode = async (ctx, creds) => { try { const d = await call(ctx, creds, 'GET', '/api/v5/account/config'); return d && d[0] && d[0].posMode === 'long_short_mode' ? 'long_short' : 'net'; } catch { return 'net'; } };
    const mgn = (m) => (m === 'cross' ? 'cross' : 'isolated');

    const self = {
      id: 'okx', name: 'OKX Futures', type: 'futures', needsPassphrase: true, hosts: ['www.okx.com'],
      async markets(ctx) {
        const d = await loadSpecs(ctx);
        return d.filter((s) => s.settleCcy === 'USDT' && s.ctType === 'linear').map((s) => {
          const ct = num(s.ctVal) || 1;
          const m = mkMarket({ symbol: s.instId, base: String(s.instId).split('-')[0], quote: 'USDT', type: 'futures', trading: s.state === 'live', tickSize: num(s.tickSz), stepSize: num(s.lotSz) * ct, minQty: num(s.minSz) * ct, maxLeverage: s.lever });
          m.ctVal = ct; m.lotSz = num(s.lotSz) || 1;
          return m;
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v5/market/tickers', { instType: 'SWAP' });
        return (d || []).filter((t) => /-USDT-SWAP$/.test(t.instId)).map((t) => {
          const last = num(t.last), open = num(t.open24h);
          return { symbol: t.instId, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.volCcy24h) * last, high: num(t.high24h), low: num(t.low24h) };
        });
      },
      async klines(ctx, symbol, interval, limit) {
        const [d, sp] = await Promise.all([pub(ctx, '/api/v5/market/candles', { instId: symbol, bar: IVM[normInterval(interval)], limit: Math.min(limit || 300, 300) }), specOf(ctx, symbol)]);
        return (d || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5]) * sp.ctVal]).reverse();
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v5/account/balance', { ccy: 'USDT' });
        const det = (d && d[0] && d[0].details) || [];
        const b = det.find((x) => x.ccy === 'USDT');
        return { balances: b ? [{ asset: 'USDT', free: num(b.availBal), locked: Math.max(0, num(b.eq) - num(b.availBal)) }] : [], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const mm = await posMode(ctx, creds);
        const body = { instId: symbol, lever: String(Number(leverage)), mgnMode: mgn(marginMode) };
        if (mm === 'long_short' && mgn(marginMode) === 'isolated') {
          await call(ctx, creds, 'POST', '/api/v5/account/set-leverage', null, { ...body, posSide: 'long' });
          return call(ctx, creds, 'POST', '/api/v5/account/set-leverage', null, { ...body, posSide: 'short' });
        }
        return call(ctx, creds, 'POST', '/api/v5/account/set-leverage', null, body);
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('OKX حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, sp = await specOf(ctx, sym);
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const mm = await posMode(ctx, creds), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const sz = floorToStep(Number(o.qty) / sp.ctVal, sp.lotSz);
        const body = { instId: sym, tdMode: mgn(o.marginMode), side: buy ? 'buy' : 'sell', ordType: o.type === 'limit' ? 'limit' : 'market', sz, clOrdId: cid(o.clientId, 32) };
        if (o.type === 'limit') body.px = o.price;
        if (mm === 'long_short') body.posSide = (buy !== reduce) ? 'long' : 'short'; else if (reduce) body.reduceOnly = true;
        let native = false;
        if (!reduce && (o.sl > 0 || o.tp > 0)) {
          const a = { };
          if (o.sl > 0) { a.slTriggerPx = tickStr(o.sl, o.market); a.slOrdPx = '-1'; a.slTriggerPxType = 'mark'; }
          if (o.tp > 0) { a.tpTriggerPx = tickStr(o.tp, o.market); a.tpOrdPx = '-1'; a.tpTriggerPxType = 'mark'; }
          body.attachAlgoOrds = [a]; native = true;
        }
        const d = await call(ctx, creds, 'POST', '/api/v5/trade/order', null, body);
        return { orderId: String((d && d[0] && d[0].ordId) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v5/account/positions', cleanObj({ instType: 'SWAP', instId: symbol }));
        const out = [];
        for (const x of d || []) {
          const pos = num(x.pos); if (!pos) continue;
          const sp = await specOf(ctx, x.instId);
          const side = x.posSide === 'long' ? 'long' : x.posSide === 'short' ? 'short' : pos > 0 ? 'long' : 'short';
          out.push({ positionId: `${x.instId}|${x.mgnMode}|${x.posSide}`, symbol: x.instId, side, qty: Math.abs(pos) * sp.ctVal, entry: num(x.avgPx), leverage: num(x.lever), margin: num(x.imr || x.margin), pnl: num(x.upl), liqPrice: num(x.liqPx) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [instId, mgnMode, posSide] = String(positionId).split('|');
        const body = { instId, mgnMode: mgnMode || 'isolated' };
        if (posSide && posSide !== 'net') body.posSide = posSide;
        return { raw: await call(ctx, creds, 'POST', '/api/v5/trade/close-position', null, body) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v5/trade/orders-pending', cleanObj({ instType: 'SWAP', instId: symbol }));
        const out = [];
        for (const x of d || []) { const sp = await specOf(ctx, x.instId); out.push({ orderId: x.ordId, symbol: x.instId, side: x.side, type: x.ordType, price: num(x.px), qty: num(x.sz) * sp.ctVal, filled: num(x.accFillSz) * sp.ctVal, status: x.state }); }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'POST', '/api/v5/trade/cancel-order', null, { instId: symbol, ordId: String(orderId) }) };
      },
    };
    return self;
  }

  /* ==================================== Bitget ==================================== */
  function bitget() {
    const base = 'https://api.bitget.com', PT = 'USDT-FUTURES';
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '00000') throw new ExchangeError((j && j.msg) || 'خطای Bitget ' + r.status, { code: j && j.code, status: r.status, raw: j });
      return j.data;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = String(ctx.now()), query = hasQuery(params) ? qs(params) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const headers = { 'ACCESS-KEY': creds.apiKey, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json', locale: 'en-US', 'ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + path + (query ? '?' + query : '') + bodyStr, 'base64') };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
    const hedgeOf = async (ctx, creds, symbol) => {
      try { const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/account', { symbol, productType: PT, marginCoin: 'USDT' }); return !!d && d.posMode === 'hedge_mode'; } catch { return false; }
    };
    const mm = (m) => (m === 'cross' ? 'crossed' : 'isolated');

    const self = {
      id: 'bitget', name: 'Bitget Futures', type: 'futures', needsPassphrase: true, hosts: ['api.bitget.com'],
      async markets(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/contracts', { productType: PT });
        return (d || []).filter((s) => s.quoteCoin === 'USDT').map((s) => mkMarket({
          symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: s.symbolStatus === 'normal',
          tickSize: num(s.priceEndStep || 1) * 10 ** -num(s.pricePlace), stepSize: num(s.sizeMultiplier) || 10 ** -num(s.volumePlace), minQty: num(s.minTradeNum), minNotional: num(s.minTradeUSDT), maxLeverage: s.maxLever,
        }));
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/tickers', { productType: PT });
        return (d || []).map((t) => ({ symbol: t.symbol, last: num(t.lastPr), changePct: num(t.change24h) * 100, quoteVol: num(t.quoteVolume), high: num(t.high24h), low: num(t.low24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const d = await pub(ctx, '/api/v2/mix/market/candles', { symbol, productType: PT, granularity: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
        return (d || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/accounts', { productType: PT });
        const a = (d || []).find((x) => x.marginCoin === 'USDT');
        return { balances: a ? [{ asset: 'USDT', free: num(a.available), locked: Math.max(0, num(a.accountEquity) - num(a.available)) }] : [], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) { try { await call(ctx, creds, 'POST', '/api/v2/mix/account/set-margin-mode', null, { symbol, productType: PT, marginCoin: 'USDT', marginMode: mm(marginMode) }); } catch { /* با پوزیشن باز ممکن نیست */ } }
        return call(ctx, creds, 'POST', '/api/v2/mix/account/set-leverage', null, { symbol, productType: PT, marginCoin: 'USDT', leverage: String(Number(leverage)) });
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Bitget حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol;
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const hedge = await hedgeOf(ctx, creds, sym), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const body = { symbol: sym, productType: PT, marginMode: mm(o.marginMode), marginCoin: 'USDT', size: o.qty, side: buy ? 'buy' : 'sell', orderType: o.type === 'limit' ? 'limit' : 'market', clientOid: cid(o.clientId, 40, /[^\w-]/g) };
        if (o.type === 'limit') { body.price = o.price; body.force = 'gtc'; }
        if (hedge) body.tradeSide = reduce ? 'close' : 'open'; else if (reduce) body.reduceOnly = 'YES';
        let native = false;
        if (!reduce) {
          if (o.sl > 0) { body.presetStopLossPrice = tickStr(o.sl, o.market); native = true; }
          if (o.tp > 0) { body.presetStopSurplusPrice = tickStr(o.tp, o.market); native = true; }
        }
        const d = await call(ctx, creds, 'POST', '/api/v2/mix/order/place-order', null, body);
        return { orderId: String((d && d.orderId) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
        return (d || []).filter((x) => num(x.total) > 0 && (!symbol || x.symbol === symbol)).map((x) => ({ positionId: `${x.symbol}|${x.holdSide}`, symbol: x.symbol, side: x.holdSide === 'short' ? 'short' : 'long', qty: num(x.total), entry: num(x.openPriceAvg), leverage: num(x.leverage), margin: num(x.marginSize), pnl: num(x.unrealizedPL), liqPrice: num(x.liquidationPrice) }));
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, holdSide] = String(positionId).split('|');
        return { raw: await call(ctx, creds, 'POST', '/api/v2/mix/order/close-positions', null, cleanObj({ symbol, productType: PT, holdSide })) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/order/orders-pending', cleanObj({ productType: PT, symbol }));
        const list = (d && d.entrustedList) || [];
        return list.map((x) => ({ orderId: x.orderId, symbol: x.symbol, side: lc(x.side), type: lc(x.orderType), price: num(x.price), qty: num(x.size), filled: num(x.baseVolume), status: x.status }));
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'POST', '/api/v2/mix/order/cancel-order', null, { symbol, productType: PT, orderId: String(orderId) }) };
      },
    };
    return self;
  }

  /* ===================================== Gate ===================================== */
  function gate() {
    const host = 'https://api.gateio.ws', prefix = '/api/v4', S = '/futures/usdt';
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '7d' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || (j && !Array.isArray(j) && j.label)) throw new ExchangeError((j && (j.message || j.label)) || 'خطای Gate ' + r.status, { code: j && j.label, status: r.status, raw: j });
      return j;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(Math.floor(ctx.now() / 1000)), query = hasQuery(params) ? qs(params) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const payload = [method, prefix + path, query, H.sha512(bodyStr), ts].join('\n');
      const headers = { KEY: creds.apiKey, Timestamp: ts, SIGN: hmac('sha512', creds.apiSecret, payload), 'Content-Type': 'application/json', Accept: 'application/json' };
      return unwrap(await ctx.http(method, `${host}${prefix}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${host}${prefix}${path}${params ? '?' + qs(params) : ''}`, {}));
    const mult = new Map();
    const multOf = async (ctx, c) => { if (!mult.has(c)) { const d = await pub(ctx, `${S}/contracts/${c}`); mult.set(c, num(d.quanto_multiplier) || 1); } return mult.get(c); };

    const self = {
      id: 'gate', name: 'Gate Futures', type: 'futures', needsPassphrase: false, hosts: ['api.gateio.ws'],
      async markets(ctx) {
        const d = await pub(ctx, `${S}/contracts`);
        return (d || []).filter((s) => /_USDT$/.test(s.name) && s.type !== 'inverse').map((s) => {
          const m = num(s.quanto_multiplier) || 1; mult.set(s.name, m);
          const mk = mkMarket({ symbol: s.name, base: s.name.split('_')[0], quote: 'USDT', type: 'futures', trading: !s.in_delisting && s.status !== 'delisting', tickSize: num(s.order_price_round), stepSize: m, minQty: num(s.order_size_min || 1) * m, maxLeverage: s.leverage_max });
          mk.mult = m; return mk;
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, `${S}/tickers`);
        return (d || []).filter((t) => /_USDT$/.test(t.contract)).map((t) => ({ symbol: t.contract, last: num(t.last), changePct: num(t.change_percentage), quoteVol: num(t.volume_24h_quote), high: num(t.high_24h), low: num(t.low_24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const [d, m] = await Promise.all([pub(ctx, `${S}/candlesticks`, { contract: symbol, interval: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1000) }), multOf(ctx, symbol)]);
        return (d || []).map((k) => [num(k.t) * 1000, num(k.o), num(k.h), num(k.l), num(k.c), num(k.v) * m]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const a = await call(ctx, creds, 'GET', `${S}/accounts`);
        return { balances: [{ asset: 'USDT', free: num(a.available), locked: num(a.position_margin) + num(a.order_margin) }], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const p = marginMode === 'cross' ? { leverage: 0, cross_leverage_limit: Number(leverage) } : { leverage: Number(leverage) };
        return call(ctx, creds, 'POST', `${S}/positions/${symbol}/leverage`, p);
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Gate حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, m = await multOf(ctx, sym), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const n = Math.floor(Number(o.qty) / m + 1e-9);
        if (!(n >= 1)) throw new ExchangeError('حجم کمتر از یک قرارداد است', { code: 'below_min_qty' });
        const body = { contract: sym, size: buy ? n : -n, text: 't-' + cid(o.clientId, 26) };
        if (o.type === 'limit') { body.price = o.price; body.tif = 'gtc'; } else { body.price = '0'; body.tif = 'ioc'; }
        if (reduce) body.reduce_only = true;
        const d = await call(ctx, creds, 'POST', `${S}/orders`, null, body);
        let native = false;
        if (!reduce && o.type !== 'limit' && (o.sl > 0 || o.tp > 0)) {
          const plan = (price, rule) => call(ctx, creds, 'POST', `${S}/price_orders`, null, {
            initial: { contract: sym, size: 0, price: '0', tif: 'ioc', reduce_only: true, close: true },
            trigger: { strategy_type: 0, price_type: 1, price: tickStr(price, o.market), rule, expiration: 2592000 },
            order_type: buy ? 'plan-close-long-position' : 'plan-close-short-position',
          });
          try {
            if (o.sl > 0) await plan(o.sl, buy ? 2 : 1);
            if (o.tp > 0) await plan(o.tp, buy ? 1 : 2);
            native = true;
          } catch (e) {
            try { await call(ctx, creds, 'POST', `${S}/orders`, null, { contract: sym, size: buy ? -n : n, price: '0', tif: 'ioc', reduce_only: true }); } catch { /* ignore */ }
            throw new ExchangeError('ثبت حد ضرر/سود ناموفق بود و پوزیشن بسته شد: ' + e.message, { code: e.exCode, raw: e.raw });
          }
        }
        return { orderId: String((d && d.id) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', `${S}/positions`);
        const out = [];
        for (const x of Array.isArray(d) ? d : []) {
          if (!num(x.size) || (symbol && x.contract !== symbol)) continue;
          const m = await multOf(ctx, x.contract), side = num(x.size) > 0 ? 'long' : 'short';
          out.push({ positionId: `${x.contract}|${side}`, symbol: x.contract, side, qty: Math.abs(num(x.size)) * m, entry: num(x.entry_price), leverage: num(x.leverage) || num(x.cross_leverage_limit), margin: num(x.margin), pnl: num(x.unrealised_pnl), liqPrice: num(x.liq_price) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const d = await call(ctx, creds, 'GET', `${S}/positions/${symbol}`);
        const x = Array.isArray(d) ? d.find((p) => num(p.size)) : d;
        if (!x || !num(x.size) || (side && (num(x.size) > 0 ? 'long' : 'short') !== side)) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        return { raw: await call(ctx, creds, 'POST', `${S}/orders`, null, { contract: symbol, size: -num(x.size), price: '0', tif: 'ioc', reduce_only: true }) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', `${S}/orders`, cleanObj({ status: 'open', contract: symbol }));
        const out = [];
        for (const x of Array.isArray(d) ? d : []) { const m = await multOf(ctx, x.contract); out.push({ orderId: String(x.id), symbol: x.contract, side: num(x.size) > 0 ? 'buy' : 'sell', type: num(x.price) ? 'limit' : 'market', price: num(x.price), qty: Math.abs(num(x.size)) * m, filled: Math.abs(num(x.size) - num(x.left)) * m, status: x.status }); }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'DELETE', `${S}/orders/${orderId}`) };
      },
    };
    return self;
  }

  /* ==================================== KuCoin ==================================== */
  function kucoin() {
    const base = 'https://api-futures.kucoin.com';
    const GR = { '1m': 1, '5m': 5, '15m': 15, '30m': 30, '1h': 60, '4h': 240, '1d': 1440, '1w': 10080 };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '200000') throw new ExchangeError((j && j.msg) || 'خطای KuCoin ' + r.status, { code: j && j.code, status: r.status, raw: j });
      return j.data;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = String(ctx.now()), ep = path + (hasQuery(params) ? '?' + qs(params) : ''), bodyStr = body ? JSON.stringify(body) : '';
      const headers = { 'KC-API-KEY': creds.apiKey, 'KC-API-TIMESTAMP': ts, 'KC-API-KEY-VERSION': '2', 'Content-Type': 'application/json', 'KC-API-SIGN': hmac('sha256', creds.apiSecret, ts + method + ep + bodyStr, 'base64'), 'KC-API-PASSPHRASE': hmac('sha256', creds.apiSecret, creds.passphrase, 'base64') };
      return unwrap(await ctx.http(method, base + ep, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const specs = new Map();
    const loadContracts = async (ctx) => { const d = await pub(ctx, '/api/v1/contracts/active'); (d || []).forEach((s) => specs.set(s.symbol, { mult: num(s.multiplier) || 1, lot: num(s.lotSize) || 1 })); return d || []; };
    const specOf = async (ctx, sym) => { if (!specs.has(sym)) await loadContracts(ctx); const v = specs.get(sym); if (!v) throw new ExchangeError('قرارداد پیدا نشد', { code: 'unknown_symbol' }); return v; };
    const baseName = (b) => (b === 'XBT' ? 'BTC' : b);
    const mgn = (m) => (m === 'cross' ? 'CROSS' : 'ISOLATED');

    const self = {
      id: 'kucoin', name: 'KuCoin Futures', type: 'futures', needsPassphrase: true, hosts: ['api-futures.kucoin.com'],
      async markets(ctx) {
        const d = await loadContracts(ctx);
        return d.filter((s) => s.quoteCurrency === 'USDT' && s.settleCurrency === 'USDT' && !s.isInverse && s.type === 'FFWCSX').map((s) => {
          const m = num(s.multiplier) || 1;
          const mk = mkMarket({ symbol: s.symbol, base: baseName(s.baseCurrency), quote: 'USDT', type: 'futures', trading: s.status === 'Open', tickSize: num(s.tickSize), stepSize: num(s.lotSize) * m, minQty: num(s.lotSize) * m, maxLeverage: s.maxLeverage });
          mk.mult = m; return mk;
        });
      },
      async tickers(ctx) {
        const d = await loadContracts(ctx);
        return d.filter((s) => s.quoteCurrency === 'USDT' && !s.isInverse && s.type === 'FFWCSX').map((s) => ({ symbol: s.symbol, last: num(s.lastTradePrice), changePct: num(s.priceChgPct) * 100, quoteVol: num(s.turnoverOf24h), high: num(s.highPrice), low: num(s.lowPrice) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const iv = normInterval(interval), n = Math.min(limit || 300, 500), to = ctx.now();
        const [d, sp] = await Promise.all([pub(ctx, '/api/v1/kline/query', { symbol, granularity: GR[iv], from: to - n * IV_SEC[iv] * 1000, to }), specOf(ctx, symbol)]);
        return (d || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5]) * sp.mult]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const a = await call(ctx, creds, 'GET', '/api/v1/account-overview', { currency: 'USDT' });
        return { balances: [{ asset: 'USDT', free: num(a.availableBalance), locked: num(a.positionMargin) + num(a.orderMargin) }], canTrade: true };
      },
      async setLeverage() { return true; }, // در KuCoin اهرم همراه سفارش ارسال می‌شود
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('KuCoin حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, sp = await specOf(ctx, sym), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const lots = floorToStep(Number(o.qty) / sp.mult, sp.lot);
        if (!(Number(lots) >= 1)) throw new ExchangeError('حجم کمتر از یک قرارداد است', { code: 'below_min_qty' });
        const body = { clientOid: cid(o.clientId, 40, /[^\w-]/g), side: buy ? 'buy' : 'sell', symbol: sym, type: o.type === 'limit' ? 'limit' : 'market', size: Number(lots), marginMode: mgn(o.marginMode) };
        if (o.type === 'limit') { body.price = o.price; body.timeInForce = 'GTC'; }
        if (reduce) body.reduceOnly = true; else body.leverage = String(Math.max(1, Number(o.leverage) || 1));
        const d = await call(ctx, creds, 'POST', '/api/v1/orders', null, body);
        let native = false;
        if (!reduce && o.type !== 'limit' && (o.sl > 0 || o.tp > 0)) {
          const stop = (price, dir) => call(ctx, creds, 'POST', '/api/v1/orders', null, { clientOid: rnd(24), side: buy ? 'sell' : 'buy', symbol: sym, type: 'market', stop: dir, stopPriceType: 'MP', stopPrice: tickStr(price, o.market), closeOrder: true, marginMode: mgn(o.marginMode) });
          try {
            if (o.sl > 0) await stop(o.sl, buy ? 'down' : 'up');
            if (o.tp > 0) await stop(o.tp, buy ? 'up' : 'down');
            native = true;
          } catch (e) {
            try { await call(ctx, creds, 'POST', '/api/v1/orders', null, { clientOid: rnd(24), side: buy ? 'sell' : 'buy', symbol: sym, type: 'market', closeOrder: true, marginMode: mgn(o.marginMode) }); } catch { /* ignore */ }
            throw new ExchangeError('ثبت حد ضرر/سود ناموفق بود و پوزیشن بسته شد: ' + e.message, { code: e.exCode, raw: e.raw });
          }
        }
        return { orderId: String((d && d.orderId) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/positions');
        const out = [];
        for (const x of Array.isArray(d) ? d : []) {
          if (!num(x.currentQty) || (symbol && x.symbol !== symbol)) continue;
          const sp = await specOf(ctx, x.symbol), side = num(x.currentQty) > 0 ? 'long' : 'short';
          out.push({ positionId: `${x.symbol}|${side}`, symbol: x.symbol, side, qty: Math.abs(num(x.currentQty)) * sp.mult, entry: num(x.avgEntryPrice), leverage: num(x.realLeverage), margin: num(x.posMargin || x.posInit), pnl: num(x.unrealisedPnl), liqPrice: num(x.liquidationPrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const p = (await self.positions(ctx, creds, symbol)).find((x) => x.symbol === symbol && (!side || x.side === side));
        if (!p) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        return { raw: await call(ctx, creds, 'POST', '/api/v1/orders', null, { clientOid: rnd(24), side: p.side === 'long' ? 'sell' : 'buy', symbol, type: 'market', closeOrder: true }) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/orders', cleanObj({ status: 'active', symbol }));
        const out = [];
        for (const x of (d && d.items) || []) { const sp = await specOf(ctx, x.symbol); out.push({ orderId: String(x.id), symbol: x.symbol, side: x.side, type: x.type, price: num(x.price), qty: num(x.size) * sp.mult, filled: num(x.dealSize) * sp.mult, status: x.status }); }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'DELETE', `/api/v1/orders/${orderId}`) };
      },
    };
    return self;
  }

  return { okx: okx(), bitget: bitget(), gate: gate(), kucoin: kucoin() };
};
