#!/bin/sh
# À exécuter depuis le dossier server sur le serveur hébergeant Docker Compose.
set -eu
: "${BACKUP_DIR:=./backups}"
mkdir -p "$BACKUP_DIR"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
FILE="$BACKUP_DIR/skynet_${STAMP}.dump"
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$FILE"
chmod 600 "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "Sauvegarde créée : $FILE"
echo "Copiez aussi le fichier hors du serveur et testez périodiquement la restauration."
