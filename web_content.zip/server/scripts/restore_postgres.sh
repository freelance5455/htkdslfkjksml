#!/bin/sh
# RESTAURATION DESTRUCTIVE : remplace le contenu de la base cible.
set -eu
if [ "$#" -ne 1 ] || [ ! -f "$1" ]; then
  echo "Usage : $0 chemin/vers/sauvegarde.dump" >&2
  exit 2
fi
printf '%s\n' "ATTENTION : toutes les données de la base SKYNET cible seront remplacées."
printf '%s' "Tapez RESTAURER pour confirmer : "
read answer
[ "$answer" = "RESTAURER" ] || { echo "Annulé."; exit 1; }
docker compose exec -T db sh -c 'dropdb -U "$POSTGRES_USER" --if-exists "$POSTGRES_DB" && createdb -U "$POSTGRES_USER" "$POSTGRES_DB"'
docker compose exec -T db sh -c 'pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists' < "$1"
echo "Restauration terminée. Vérifiez /ready et les données avant réouverture du service."
