import fs from 'fs';
import path from 'path';
import { sanitizeHexColor, sanitizeXmlText, validateAndroidPackageName } from './security.ts';

export interface ApkProjectConfig {
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  iconPreset: 'nebula' | 'commerce' | 'media' | 'utility' | 'cobalt' | 'aurum' | 'custom';
  customIconPath?: string | null;
  adaptiveIconEnabled?: boolean;
  adaptiveBgColor?: string;
  customForegroundPath?: string | null;
  splashEnabled: boolean;
  splashBgColor: string;
  splashTitle: string;
  splashDurationMs: number;
  orientation: 'unspecified' | 'portrait' | 'landscape';
  fullscreen: boolean;
  statusBarVisible: boolean;
  statusBarColor: string;
  navigationBarVisible: boolean;
  navigationBarColor: string;
  internetPermission: boolean;
  offlineEnabled?: boolean;
  launchAnimation: 'fade' | 'slide' | 'scale' | 'none';
}

export interface GeneratedAndroidProject {
  rootDir: string;
  generatedFiles: string[];
  webFileCount: number;
}

const PRESET_ICON_MAP: Record<string, string> = {
  nebula: 'src/assets/images/icon_preset_nebula_1794842298663.jpg',
  commerce: 'src/assets/images/icon_preset_commerce_1794845236479.jpg',
  media: 'src/assets/images/icon_preset_media_1794845237448.jpg',
  utility: 'src/assets/images/icon_preset_utility_1794845237946.jpg',
  cobalt: 'src/assets/images/icon_preset_cobalt_1794842298794.jpg',
  aurum: 'src/assets/images/icon_preset_aurum_1794842299008.jpg',
};

const MIPMAP_DENSITIES = [
  'mipmap-mdpi',
  'mipmap-hdpi',
  'mipmap-xhdpi',
  'mipmap-xxhdpi',
  'mipmap-xxxhdpi',
] as const;

function copyDirectoryRecursive(srcDir: string, destDir: string, countRef: { count: number }): void {
  fs.mkdirSync(destDir, { recursive: true });
  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.name.startsWith('__studio_meta')) continue;
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDirectoryRecursive(srcPath, destPath, countRef);
    } else if (entry.isFile()) {
      fs.copyFileSync(srcPath, destPath);
      countRef.count += 1;
    }
  }
}

export function resolveIconSourceForDensity(
  projectStorageDir: string,
  config: ApkProjectConfig,
  density: string
): string | null {
  if (config.iconPreset === 'custom') {
    const densityCandidate = path.join(projectStorageDir, '__studio_meta', 'mipmaps', density, 'ic_launcher.png');
    if (fs.existsSync(densityCandidate)) return densityCandidate;
    if (config.customIconPath) {
      const candidate = path.resolve(projectStorageDir, config.customIconPath);
      if (fs.existsSync(candidate)) return candidate;
    }
  }
  if (config.iconPreset && PRESET_ICON_MAP[config.iconPreset]) {
    const presetAbs = path.resolve(process.cwd(), PRESET_ICON_MAP[config.iconPreset]);
    if (fs.existsSync(presetAbs)) return presetAbs;
  }
  const fallbackPreset = path.resolve(process.cwd(), PRESET_ICON_MAP.nebula);
  return fs.existsSync(fallbackPreset) ? fallbackPreset : null;
}

export function resolveForegroundSource(
  projectStorageDir: string,
  config: ApkProjectConfig
): string | null {
  if (config.customForegroundPath) {
    const candidate = path.resolve(projectStorageDir, config.customForegroundPath);
    if (fs.existsSync(candidate)) return candidate;
  }
  return resolveIconSourceForDensity(projectStorageDir, config, 'mipmap-xxxhdpi');
}

export function generateAndroidWebViewProject(params: {
  workDir: string;
  projectStorageDir: string;
  entryFile: string;
  config: ApkProjectConfig;
}): GeneratedAndroidProject {
  const { workDir, projectStorageDir, entryFile, config } = params;

  const pkgCheck = validateAndroidPackageName(config.packageName);
  if (!pkgCheck.valid) {
    throw new Error(pkgCheck.reason || 'Geçersiz Android paket adı.');
  }

  const appNameSafe = sanitizeXmlText((config.appName || 'HTML Uygulamam').trim().slice(0, 60));
  const splashTitleSafe = sanitizeXmlText((config.splashTitle || config.appName || 'Yükleniyor').trim().slice(0, 60));
  const versionNameSafe = (config.versionName || '1.0.0').replace(/[^0-9A-Za-z._-]/g, '').slice(0, 24) || '1.0.0';
  const versionCodeSafe = Math.max(1, Math.min(99999999, Number(config.versionCode) || 1));
  const splashBg = sanitizeHexColor(config.splashBgColor, '#0B1020');
  const statusBarColor = sanitizeHexColor(config.statusBarColor, '#0B1020');
  const navBarColor = sanitizeHexColor(config.navigationBarColor, '#0B1020');
  const adaptiveBgColor = sanitizeHexColor(config.adaptiveBgColor, '#0B1020');
  const splashDuration = Math.max(400, Math.min(5000, Number(config.splashDurationMs) || 1200));
  const adaptiveEnabled = config.adaptiveIconEnabled !== false;
  const offlineEnabled = config.offlineEnabled !== false;

  const entryClean = entryFile.replace(/\\/g, '/').replace(/^\/+/, '') || 'index.html';
  const packagePath = config.packageName.split('.').join('/');

  const generatedFiles: string[] = [];
  const writeRel = (relPath: string, content: string) => {
    const abs = path.join(workDir, relPath);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, 'utf8');
    generatedFiles.push(relPath);
  };

  // 1. Gradle Root & Wrapper Config
  writeRel(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${appNameSafe.replace(/"/g, '')}"
include(":app")
`
  );

  writeRel(
    'build.gradle.kts',
    `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`
  );

  writeRel(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`
  );

  // 2. App Module build.gradle.kts
  writeRel(
    'app/build.gradle.kts',
    `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${config.packageName}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${config.packageName}"
        minSdk = 24
        targetSdk = 34
        versionCode = ${versionCodeSafe}
        versionName = "${versionNameSafe}"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
`
  );

  writeRel(
    'app/proguard-rules.pro',
    `-keepattributes *Annotation*
-dontwarn android.webkit.**
`
  );

  // 3. AndroidManifest.xml
  const orientationAttr =
    config.orientation === 'portrait'
      ? 'android:screenOrientation="portrait"'
      : config.orientation === 'landscape'
      ? 'android:screenOrientation="landscape"'
      : 'android:screenOrientation="unspecified"';

  const internetPerms = config.internetPermission
    ? `    <uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />`
    : `    <!-- İnternet erişimi kullanıcı tarafından devre dışı bırakıldı; yalnızca yerel assets sunulur -->`;

  const mainActivityLauncherBlock = !config.splashEnabled
    ? `            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>`
    : '';

  const splashActivityBlock = config.splashEnabled
    ? `        <activity
            android:name=".SplashActivity"
            android:exported="true"
            ${orientationAttr}
            android:theme="@style/Theme.AppSplash">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>`
    : '';

  writeRel(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

${internetPerms}

    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:networkSecurityConfig="@xml/network_security_config"
        android:theme="@style/Theme.HtmlToApkApp">

${splashActivityBlock}

        <activity
            android:name=".MainActivity"
            android:exported="${config.splashEnabled ? 'false' : 'true'}"
            android:configChanges="orientation|screenSize|keyboardHidden"
            ${orientationAttr}>
${mainActivityLauncherBlock}
        </activity>
    </application>
</manifest>
`
  );

  // 4. Network Security Config
  writeRel(
    'app/src/main/res/xml/network_security_config.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`
  );

  // 5. Resources: strings, colors, styles, animations, layouts
  writeRel(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${appNameSafe}</string>
    <string name="splash_title">${splashTitleSafe}</string>
</resources>
`
  );

  writeRel(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="status_bar_color">${statusBarColor}</color>
    <color name="nav_bar_color">${navBarColor}</color>
    <color name="splash_bg_color">${splashBg}</color>
    <color name="ic_launcher_background">${adaptiveBgColor}</color>
</resources>
`
  );

  writeRel(
    'app/src/main/res/values/styles.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.HtmlToApkApp" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:statusBarColor">@color/status_bar_color</item>
        <item name="android:navigationBarColor">@color/nav_bar_color</item>
        <item name="android:windowFullscreen">${config.fullscreen ? 'true' : 'false'}</item>
    </style>

    <style name="Theme.AppSplash" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:windowBackground">@color/splash_bg_color</item>
        <item name="android:statusBarColor">@color/splash_bg_color</item>
        <item name="android:navigationBarColor">@color/splash_bg_color</item>
        <item name="android:windowFullscreen">true</item>
    </style>
</resources>
`
  );

  writeRel(
    'app/src/main/res/anim/anim_enter_fade.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<alpha xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="320"
    android:fromAlpha="0.0"
    android:toAlpha="1.0" />
`
  );

  writeRel(
    'app/src/main/res/anim/anim_enter_slide.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<translate xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="340"
    android:fromXDelta="100%"
    android:toXDelta="0%" />
`
  );

  writeRel(
    'app/src/main/res/anim/anim_enter_scale.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<scale xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="320"
    android:fromXScale="0.92"
    android:fromYScale="0.92"
    android:pivotX="50%"
    android:pivotY="50%"
    android:toXScale="1.0"
    android:toYScale="1.0" />
`
  );

  writeRel(
    'app/src/main/res/anim/anim_exit_fade.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<alpha xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="260"
    android:fromAlpha="1.0"
    android:toAlpha="0.0" />
`
  );

  writeRel(
    'app/src/main/res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/root_container"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="${statusBarColor}">

    <WebView
        android:id="@+id/app_webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>
`
  );

  writeRel(
    'app/src/main/res/layout/activity_splash.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/splash_bg_color"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="32dp">

    <ImageView
        android:id="@+id/splash_icon"
        android:layout_width="96dp"
        android:layout_height="96dp"
        android:contentDescription="@string/app_name"
        android:src="@mipmap/ic_launcher" />

    <TextView
        android:id="@+id/splash_label"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="@string/splash_title"
        android:textColor="#F8FAFC"
        android:textSize="22sp"
        android:textStyle="bold" />
</LinearLayout>
`
  );

  // 6. App Icon & Adaptive Icon placement across all mipmap densities
  const fgSourceAbs = resolveForegroundSource(projectStorageDir, config);
  for (const density of MIPMAP_DENSITIES) {
    const iconSourceAbs = resolveIconSourceForDensity(projectStorageDir, config, density);
    if (iconSourceAbs) {
      const ext = path.extname(iconSourceAbs).toLowerCase() || '.png';
      const iconRel = `app/src/main/res/${density}/ic_launcher${ext}`;
      const iconDest = path.join(workDir, iconRel);
      fs.mkdirSync(path.dirname(iconDest), { recursive: true });
      fs.copyFileSync(iconSourceAbs, iconDest);
      generatedFiles.push(iconRel);

      const roundRel = `app/src/main/res/${density}/ic_launcher_round${ext}`;
      const roundDest = path.join(workDir, roundRel);
      fs.copyFileSync(iconSourceAbs, roundDest);
      generatedFiles.push(roundRel);
    }

    if (adaptiveEnabled && fgSourceAbs) {
      const fgExt = path.extname(fgSourceAbs).toLowerCase() || '.png';
      const fgRel = `app/src/main/res/${density}/ic_launcher_foreground${fgExt}`;
      const fgDest = path.join(workDir, fgRel);
      fs.mkdirSync(path.dirname(fgDest), { recursive: true });
      fs.copyFileSync(fgSourceAbs, fgDest);
      generatedFiles.push(fgRel);
    }
  }

  if (adaptiveEnabled && fgSourceAbs) {
    const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
`;
    writeRel('app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml', adaptiveXml);
    writeRel('app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml', adaptiveXml);
  }

  // 7. Kotlin MainActivity.kt (Hardened Android WebView)
  const animResEnter =
    config.launchAnimation === 'slide'
      ? 'R.anim.anim_enter_slide'
      : config.launchAnimation === 'scale'
      ? 'R.anim.anim_enter_scale'
      : config.launchAnimation === 'fade'
      ? 'R.anim.anim_enter_fade'
      : '0';

  writeRel(
    `app/src/main/kotlin/${packagePath}/MainActivity.kt`,
    `package ${config.packageName}

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val localAppOrigin = "https://appassets.androidplatform.net"
    private val internetEnabled = ${config.internetPermission ? 'true' : 'false'}
    private val offlineSupportEnabled = ${offlineEnabled ? 'true' : 'false'}

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configureSystemBars()

        webView = findViewById(R.id.app_webview)

        // Yerel HTML/CSS/JS dosyalarını güvenli HTTPS kökeni altında sun
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = false
            displayZoomControls = false

            // Güvenlik sertleştirme: Dosya kökenli çapraz erişimleri kapat
            allowFileAccess = true
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            allowContentAccess = false

            // Çevrimdışı çalışma desteği
            cacheMode = if (internetEnabled && isNetworkAvailable()) {
                WebSettings.LOAD_DEFAULT
            } else if (offlineSupportEnabled) {
                WebSettings.LOAD_CACHE_ELSE_NETWORK
            } else {
                WebSettings.LOAD_NO_CACHE
            }
        }

        // Güvenlik gereği WebView JavaScript Bridge (addJavascriptInterface) kapalıdır.
        WebView.setWebContentsDebuggingEnabled(false)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase() ?: return true

                if (uri.toString().startsWith(localAppOrigin)) {
                    return false
                }

                if (scheme == "tel" || scheme == "mailto" || scheme == "sms") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    return true
                }

                if ((scheme == "http" || scheme == "https") && internetEnabled) {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    return true
                }

                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl("$localAppOrigin/assets/www/${entryClean}")
    }

    private fun configureSystemBars() {
        window.statusBarColor = Color.parseColor("${statusBarColor}")
        window.navigationBarColor = Color.parseColor("${navBarColor}")
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        if (${config.fullscreen ? 'true' : 'false'}) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            if (!${config.statusBarVisible ? 'true' : 'false'}) {
                controller.hide(WindowInsetsCompat.Type.statusBars())
            }
            if (!${config.navigationBarVisible ? 'true' : 'false'}) {
                controller.hide(WindowInsetsCompat.Type.navigationBars())
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
`
  );

  if (config.splashEnabled) {
    writeRel(
      `app/src/main/kotlin/${packagePath}/SplashActivity.kt`,
      `package ${config.packageName}

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@SplashActivity, MainActivity.class.java)
            startActivity(intent)
            ${
              animResEnter !== '0'
                ? `overridePendingTransition(${animResEnter}, R.anim.anim_exit_fade)`
                : ''
            }
            finish()
        }, ${splashDuration}L)
    }
}
`
    );
  }

  // 8. Copy user HTML/CSS/JS/Media files into app/src/main/assets/www/
  const assetsWwwDir = path.join(workDir, 'app/src/main/assets/www');
  const countRef = { count: 0 };
  copyDirectoryRecursive(projectStorageDir, assetsWwwDir, countRef);

  // 9. Include Docker & Build Script inside generated bundle for reproducible APK build
  writeRel(
    'Dockerfile',
    `FROM eclipse-temurin:17-jdk-jammy
ENV ANDROID_SDK_ROOT=/opt/android-sdk
ENV ANDROID_HOME=/opt/android-sdk
ENV GRADLE_VERSION=8.7
ENV PATH="\${PATH}:/opt/gradle/gradle-\${GRADLE_VERSION}/bin:\${ANDROID_SDK_ROOT}/cmdline-tools/latest/bin"

RUN apt-get update && apt-get install -y --no-install-recommends curl unzip ca-certificates \\
    && rm -rf /var/lib/apt/lists/* \\
    && mkdir -p /opt/gradle \\
    && curl -fsSL "https://services.gradle.org/distributions/gradle-\${GRADLE_VERSION}-bin.zip" -o /tmp/gradle.zip \\
    && unzip -q /tmp/gradle.zip -d /opt/gradle && rm /tmp/gradle.zip \\
    && mkdir -p "\${ANDROID_SDK_ROOT}/cmdline-tools" \\
    && curl -fsSL "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o /tmp/cmd.zip \\
    && unzip -q /tmp/cmd.zip -d "\${ANDROID_SDK_ROOT}/cmdline-tools" \\
    && mv "\${ANDROID_SDK_ROOT}/cmdline-tools/cmdline-tools" "\${ANDROID_SDK_ROOT}/cmdline-tools/latest" \\
    && rm /tmp/cmd.zip \\
    && yes | sdkmanager --licenses > /dev/null \\
    && sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

WORKDIR /workspace
COPY . /workspace
RUN gradle --no-daemon assembleDebug
`
  );

  writeRel(
    'build-apk.sh',
    `#!/usr/bin/env bash
set -euo pipefail
echo "HTML to APK Studio — Docker İzole APK Derleyici"
docker build -t html-apk-project .
CID=$(docker create html-apk-project)
mkdir -p out
docker cp "$CID:/workspace/app/build/outputs/apk/debug/app-debug.apk" ./out/app-debug.apk
docker rm "$CID"
echo "APK hazır: ./out/app-debug.apk"
`
  );

  return {
    rootDir: workDir,
    generatedFiles,
    webFileCount: countRef.count,
  };
}
