import { providerRegistry } from "./registry";
import { GeminiTextProvider } from "./providers/geminiTextProvider";
import { ImageEngineProvider } from "./providers/imageEngineProvider";
import { VideoEngineProvider } from "./providers/videoEngineProvider";
import { PixVerseProvider } from "./providers/pixverseProvider";
import { VoiceEngineProvider } from "./providers/voiceEngineProvider";
import { MusicEngineProvider } from "./providers/musicEngineProvider";
import { AvatarEngineProvider } from "./providers/avatarEngineProvider";
import { RenderEngineProvider } from "./providers/renderEngineProvider";
import {
  AiJobRecord,
  AvatarGenerationInput,
  AvatarGenerationOutput,
  ImageGenerationInput,
  ImageGenerationOutput,
  JobStatus,
  MusicGenerationInput,
  MusicGenerationOutput,
  ProviderCategory,
  ProviderHealthStatus,
  RenderTimelineInput,
  RenderTimelineOutput,
  SystemHealthDashboard,
  TextGenerationInput,
  TextGenerationOutput,
  VideoGenerationInput,
  VideoGenerationOutput,
  VoiceGenerationInput,
  VoiceGenerationOutput,
} from "./types";
import { db } from "../db";
import fs from "fs";
import path from "path";
import { EventEmitter } from "events";

class AiEngineOrchestrator extends EventEmitter {
  private jobs: Map<string, AiJobRecord> = new Map();
  private abortControllers: Map<string, AbortController> = new Map();
  private geminiProvider: GeminiTextProvider;
  private imageProvider: ImageEngineProvider;
  private videoProvider: VideoEngineProvider;
  public pixverseProvider: PixVerseProvider;
  private voiceProvider: VoiceEngineProvider;
  private musicProvider: MusicEngineProvider;
  private avatarProvider: AvatarEngineProvider;
  private renderProvider: RenderEngineProvider;
  private initialized = false;

  constructor() {
    super();
    // Allow multiple listeners for SSE streams
    this.setMaxListeners(50);

    // Instantiate core providers
    this.geminiProvider = new GeminiTextProvider();
    this.imageProvider = new ImageEngineProvider();
    this.videoProvider = new VideoEngineProvider();
    this.pixverseProvider = new PixVerseProvider();
    this.voiceProvider = new VoiceEngineProvider();
    this.musicProvider = new MusicEngineProvider();
    this.avatarProvider = new AvatarEngineProvider();
    this.renderProvider = new RenderEngineProvider();

    // Register all providers
    providerRegistry.register(this.geminiProvider);
    providerRegistry.register(this.imageProvider);
    providerRegistry.register(this.pixverseProvider);
    providerRegistry.register(this.videoProvider);
    providerRegistry.register(this.voiceProvider);
    providerRegistry.register(this.musicProvider);
    providerRegistry.register(this.avatarProvider);
    providerRegistry.register(this.renderProvider);

    // Asynchronously load persisted jobs from database
    this.loadPersistedJobs().catch((err) => {
      console.warn("[Orchestrator] Failed to load persisted jobs on startup:", err);
    });
  }

  private async loadPersistedJobs(): Promise<void> {
    try {
      const persistedJobs = await db.getJobs();
      for (const j of persistedJobs) {
        this.jobs.set(j.id, j as unknown as AiJobRecord);
      }
      this.initialized = true;
      console.log(`[Orchestrator] Loaded ${persistedJobs.length} jobs from persistent store.`);
    } catch (err) {
      console.error("[Orchestrator] Error initializing jobs from database:", err);
    }
  }

  // --- ASYNC JOB MANAGEMENT ---
  public async createJob<TInput, TOutput>(
    type: ProviderCategory,
    providerId: string,
    providerName: string,
    model: string,
    input: TInput,
    projectId?: string,
    userId?: string
  ): Promise<AiJobRecord<TInput, TOutput>> {
    const id = `job-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const job: AiJobRecord<TInput, TOutput> = {
      id,
      projectId,
      userId,
      type,
      providerId,
      providerName,
      model,
      status: "queued",
      progress: 0,
      stepLabel: "Job criado e colocado na fila de processamento",
      input,
      createdAt: new Date().toISOString(),
    };
    this.jobs.set(id, job as unknown as AiJobRecord);
    try {
      await db.saveJob(job as unknown as Parameters<typeof db.saveJob>[0]);
    } catch (dbErr) {
      console.warn("[Orchestrator] Failed to persist new job:", dbErr);
    }
    this.emit("job:created", job);
    return job;
  }

  public getJob(jobId: string): AiJobRecord | undefined {
    return this.jobs.get(jobId);
  }

  public listJobs(projectId?: string, status?: string): AiJobRecord[] {
    let list = Array.from(this.jobs.values());
    if (projectId) {
      list = list.filter((j) => j.projectId === projectId);
    }
    if (status) {
      list = list.filter((j) => j.status === status);
    }
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public async updateJobProgress(
    jobId: string,
    progress: number,
    status: JobStatus = "processing",
    stepLabel?: string
  ) {
    const job = this.jobs.get(jobId);
    if (job) {
      job.progress = Math.min(100, Math.max(0, progress));
      job.status = status;
      if (stepLabel) {
        job.stepLabel = stepLabel;
      }
      if (status === "processing" && !job.startedAt) {
        job.startedAt = new Date().toISOString();
      }
      try {
        await db.updateJob(jobId, {
          progress: job.progress,
          status: job.status,
          stepLabel: job.stepLabel,
          startedAt: job.startedAt,
        });
      } catch (dbErr) {
        console.warn("[Orchestrator] Failed to persist job progress:", dbErr);
      }
      this.emit("job:progress", job);
    }
  }

  public async completeJob<TOutput>(jobId: string, output: TOutput, stepLabel = "Processamento concluído com sucesso") {
    const job = this.jobs.get(jobId);
    if (job) {
      job.status = "completed";
      job.progress = 100;
      job.stepLabel = stepLabel;
      job.output = output;
      job.completedAt = new Date().toISOString();
      if (job.startedAt) {
        job.durationMs = new Date(job.completedAt).getTime() - new Date(job.startedAt).getTime();
      }
      try {
        await db.updateJob(jobId, {
          status: job.status,
          progress: 100,
          stepLabel: job.stepLabel,
          output: job.output,
          completedAt: job.completedAt,
          durationMs: job.durationMs,
        });
      } catch (dbErr) {
        console.warn("[Orchestrator] Failed to persist completed job:", dbErr);
      }
      this.abortControllers.delete(jobId);
      this.emit("job:completed", job);
    }
  }

  public async failJob(jobId: string, error: string) {
    const job = this.jobs.get(jobId);
    if (job) {
      job.status = "failed";
      job.error = error;
      job.stepLabel = `Falha: ${error}`;
      job.completedAt = new Date().toISOString();
      if (job.startedAt) {
        job.durationMs = new Date(job.completedAt).getTime() - new Date(job.startedAt).getTime();
      }
      try {
        await db.updateJob(jobId, {
          status: job.status,
          error: job.error,
          stepLabel: job.stepLabel,
          completedAt: job.completedAt,
          durationMs: job.durationMs,
        });
      } catch (dbErr) {
        console.warn("[Orchestrator] Failed to persist failed job:", dbErr);
      }
      this.abortControllers.delete(jobId);
      this.emit("job:failed", job);
    }
  }

  public async cancelJob(jobId: string): Promise<boolean> {
    const job = this.jobs.get(jobId);
    if (!job) return false;
    if (job.status === "completed" || job.status === "failed") {
      return false; // Already finalized
    }

    const controller = this.abortControllers.get(jobId);
    if (controller) {
      controller.abort();
      this.abortControllers.delete(jobId);
    }

    job.status = "cancelled";
    job.stepLabel = "Cancelado pelo usuário";
    job.completedAt = new Date().toISOString();
    if (job.startedAt) {
      job.durationMs = new Date(job.completedAt).getTime() - new Date(job.startedAt).getTime();
    }
    try {
      await db.updateJob(jobId, {
        status: job.status,
        stepLabel: job.stepLabel,
        completedAt: job.completedAt,
        durationMs: job.durationMs,
      });
    } catch (dbErr) {
      console.warn("[Orchestrator] Failed to persist cancelled job:", dbErr);
    }
    this.emit("job:cancelled", job);
    return true;
  }

  public async deleteJob(jobId: string): Promise<boolean> {
    this.abortControllers.get(jobId)?.abort();
    this.abortControllers.delete(jobId);
    this.jobs.delete(jobId);
    try {
      await db.deleteJob(jobId);
    } catch (dbErr) {
      console.warn("[Orchestrator] Failed to delete job from DB:", dbErr);
    }
    this.emit("job:deleted", { id: jobId });
    return true;
  }

  // --- ASYNC QUEUE DISPATCHER ---
  public async enqueueJob<TInput = unknown, TOutput = unknown>(
    type: ProviderCategory,
    input: TInput,
    options: {
      projectId?: string;
      userId?: string;
      providerId?: string;
      model?: string;
    } = {}
  ): Promise<AiJobRecord<TInput, TOutput>> {
    const providers = providerRegistry.getProvidersForCategory(type);
    const chosenProvider = (options.providerId && providerRegistry.get(options.providerId)) || providers[0];
    const providerId = chosenProvider?.id || `${type.toLowerCase()}-engine-default`;
    const providerName = chosenProvider?.name || `${type} Studio Engine`;
    const model = options.model || chosenProvider?.model || "default-v2";

    const job = await this.createJob<TInput, TOutput>(
      type,
      providerId,
      providerName,
      model,
      input,
      options.projectId,
      options.userId
    );

    // Dispatch background execution asynchronously
    const abortController = new AbortController();
    this.abortControllers.set(job.id, abortController);

    setImmediate(() => {
      this.executeJob(job.id, abortController.signal).catch((err) => {
        console.error(`[Orchestrator] Background job execution unhandled error for ${job.id}:`, err);
      });
    });

    return job;
  }

  public async retryJob(jobId: string): Promise<AiJobRecord | null> {
    const job = this.jobs.get(jobId);
    if (!job) return null;

    // Reset job state
    job.status = "queued";
    job.progress = 0;
    job.stepLabel = "Reiniciado na fila de processamento...";
    job.error = undefined;
    job.output = undefined;
    job.startedAt = undefined;
    job.completedAt = undefined;
    job.durationMs = undefined;

    await db.updateJob(jobId, {
      status: "queued",
      progress: 0,
      stepLabel: job.stepLabel,
      error: undefined,
      output: undefined,
      startedAt: undefined,
      completedAt: undefined,
      durationMs: undefined,
    });

    const abortController = new AbortController();
    this.abortControllers.set(jobId, abortController);

    setImmediate(() => {
      this.executeJob(jobId, abortController.signal).catch((err) => {
        console.error(`[Orchestrator] Retry job execution unhandled error for ${jobId}:`, err);
      });
    });

    return job;
  }

  private async executeJob(jobId: string, signal: AbortSignal): Promise<void> {
    const job = this.jobs.get(jobId);
    if (!job || signal.aborted || job.status === "cancelled") return;

    try {
      await this.updateJobProgress(jobId, 15, "processing", "Validando especificações e alocando motor...");
      if (signal.aborted) return;

      let result: unknown;
      switch (job.type) {
        case "IMAGE": {
          await this.updateJobProgress(jobId, 35, "processing", "Renderizando camadas visuais e estética sensorial...");
          result = await this.generateImage(job.input as ImageGenerationInput);
          break;
        }
        case "VIDEO": {
          const videoInput = job.input as VideoGenerationInput;
          const requestedProvider = videoInput.provider?.toUpperCase();
          const usePixVerse = requestedProvider === "PIXVERSE" || (!requestedProvider && this.pixverseProvider.isConfigured);

          if (usePixVerse) {
            await this.updateJobProgress(jobId, 5, "processing", "Submetendo solicitação ao motor PixVerse...");
            result = await this.pixverseProvider.generate(videoInput, {
              jobId,
              onProgress: async (_status, msg) => {
                await this.updateJobProgress(jobId, 0, "processing", msg);
              },
            });
          } else {
            await this.updateJobProgress(jobId, 30, "processing", "Compondo motion e sintetizando cenas...");
            result = await this.generateVideo(videoInput, jobId);
          }
          break;
        }
        case "VOICE": {
          await this.updateJobProgress(jobId, 35, "processing", "Analisando fonética e modulando entonação...");
          await this.updateJobProgress(jobId, 70, "processing", "Sintetizando áudio neural e masterizando MP3...");
          result = await this.generateVoice(job.input as VoiceGenerationInput);
          break;
        }
        case "MUSIC": {
          await this.updateJobProgress(jobId, 35, "processing", "Criando arranjo polifônico e camadas de instrumentos...");
          await this.updateJobProgress(jobId, 75, "processing", "Equalizando ambiência acústica e gravando...");
          result = await this.generateMusic(job.input as MusicGenerationInput);
          break;
        }
        case "AVATAR": {
          await this.updateJobProgress(jobId, 30, "processing", "Gerando modelo do apresentador e expressões faciais...");
          await this.updateJobProgress(jobId, 70, "processing", "Renderizando vídeo do avatar com lower-third...");
          result = await this.generateAvatar(job.input as AvatarGenerationInput);
          break;
        }
        case "RENDER": {
          await this.updateJobProgress(jobId, 25, "processing", "Carregando pistas da timeline e mídias...");
          await this.updateJobProgress(jobId, 65, "processing", "Compondo efeitos, legendas e mixando trilhas...");
          result = await this.renderTimeline(job.input as RenderTimelineInput);
          break;
        }
        case "TEXT": {
          await this.updateJobProgress(jobId, 45, "processing", "Processando inteligência de roteiro multimodal...");
          result = await this.generateText(job.input as TextGenerationInput);
          break;
        }
        default:
          throw new Error(`Tipo de job não suportado: ${job.type}`);
      }

      if (signal.aborted || job.status === "cancelled") return;

      await this.completeJob(jobId, result, "Job finalizado com sucesso e mídia disponível no storage.");
    } catch (err) {
      if (signal.aborted || job.status === "cancelled") return;
      const errorMsg = err instanceof Error ? err.message : "Erro desconhecido durante execução";
      console.error(`[Orchestrator] Error executing job ${jobId}:`, err);
      await this.failJob(jobId, errorMsg);
    }
  }

  // --- HIGH-LEVEL GENERATION PIPELINES WITH REAL FALLBACK ---

  // 1. Text / Script / SEO Generation
  public async generateText(input: TextGenerationInput): Promise<TextGenerationOutput> {
    const providers = providerRegistry.getProvidersForCategory("TEXT");
    const fallbackLog: Array<{ providerId: string; error: string; attemptedAt: string }> = [];

    for (const provider of providers) {
      try {
        const result = (await provider.generate(input)) as TextGenerationOutput;
        return result;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : "Erro desconhecido";
        fallbackLog.push({ providerId: provider.id, error: errorMsg, attemptedAt: new Date().toISOString() });
        console.warn(`[Orchestrator] Provider ${provider.name} failed, checking next in chain...`, errorMsg);
      }
    }

    throw new Error(
      `Todos os provedores de texto falharam. Cadeia de fallback testada: ${fallbackLog.map((f) => `${f.providerId}: ${f.error}`).join("; ")}`
    );
  }

  // 2. Image Generation
  public async generateImage(input: ImageGenerationInput): Promise<ImageGenerationOutput> {
    const providers = providerRegistry.getProvidersForCategory("IMAGE");
    for (const provider of providers) {
      try {
        const result = (await provider.generate(input)) as ImageGenerationOutput;
        return result;
      } catch (err) {
        console.warn(`[Orchestrator] Image provider ${provider.name} failed:`, err);
      }
    }
    // Direct call to default image provider
    return await this.imageProvider.generate(input);
  }

  // 3. Video Generation
  public async generateVideo(input: VideoGenerationInput, jobId?: string): Promise<VideoGenerationOutput> {
    const requestedProvider = input.provider?.toUpperCase();
    if (requestedProvider === "PIXVERSE") {
      return await this.pixverseProvider.generate(input, { jobId });
    }
    if (this.pixverseProvider.isConfigured && (!requestedProvider || requestedProvider === "AUTO")) {
      return await this.pixverseProvider.generate(input, { jobId });
    }
    return await this.videoProvider.generate(input);
  }

  // 4. Voice Generation
  public async generateVoice(input: VoiceGenerationInput): Promise<VoiceGenerationOutput> {
    const providers = providerRegistry.getProvidersForCategory("VOICE");
    for (const provider of providers) {
      try {
        const result = (await provider.generate(input)) as VoiceGenerationOutput;
        return result;
      } catch (err) {
        console.warn(`[Orchestrator] Voice provider ${provider.name} failed:`, err);
      }
    }
    return await this.voiceProvider.generate(input);
  }

  // 5. Music Generation
  public async generateMusic(input: MusicGenerationInput): Promise<MusicGenerationOutput> {
    const providers = providerRegistry.getProvidersForCategory("MUSIC");
    for (const provider of providers) {
      try {
        const result = (await provider.generate(input)) as MusicGenerationOutput;
        return result;
      } catch (err) {
        console.warn(`[Orchestrator] Music provider ${provider.name} failed:`, err);
      }
    }
    return await this.musicProvider.generate(input);
  }

  // 6. Avatar Generation
  public async generateAvatar(input: AvatarGenerationInput): Promise<AvatarGenerationOutput> {
    return await this.avatarProvider.generate(input);
  }

  // 7. Render Timeline Final Video
  public async renderTimeline(input: RenderTimelineInput): Promise<RenderTimelineOutput> {
    return await this.renderProvider.generate(input);
  }

  // --- DASHBOARD DE SAÚDE COMPLETO (Section 27) ---
  public async getSystemHealth(): Promise<SystemHealthDashboard> {
    const details: SystemHealthDashboard["details"] = {};

    // 1. Gemini
    const geminiRes = await this.geminiProvider.validateCredentials();
    const geminiStatus: ProviderHealthStatus = geminiRes.valid ? "OPERATIONAL" : "DEGRADED";
    details.gemini = {
      status: geminiStatus,
      provider: this.geminiProvider.name,
      details: geminiRes.message || "",
      latencyMs: geminiRes.latencyMs,
    };

    // 2. Image Engine
    const imgRes = await this.imageProvider.validateCredentials();
    const imgStatus: ProviderHealthStatus = imgRes.valid ? "OPERATIONAL" : "OFFLINE";
    details.imageEngine = {
      status: imgStatus,
      provider: this.imageProvider.name,
      details: imgRes.message || "",
      latencyMs: imgRes.latencyMs,
    };

    // 3. Video Engine
    const vidRes = await this.videoProvider.validateCredentials();
    const vidStatus: ProviderHealthStatus = vidRes.valid ? "OPERATIONAL" : "OFFLINE";
    details.videoEngine = {
      status: vidStatus,
      provider: this.videoProvider.name,
      details: vidRes.message || "",
      latencyMs: vidRes.latencyMs,
    };

    // 4. Voice Engine
    const voiceRes = await this.voiceProvider.validateCredentials();
    const voiceStatus: ProviderHealthStatus = voiceRes.valid ? "OPERATIONAL" : "OFFLINE";
    details.voiceEngine = {
      status: voiceStatus,
      provider: this.voiceProvider.name,
      details: voiceRes.message || "",
      latencyMs: voiceRes.latencyMs,
    };

    // 5. Music Engine
    const musicRes = await this.musicProvider.validateCredentials();
    const musicStatus: ProviderHealthStatus = musicRes.valid ? "OPERATIONAL" : "OFFLINE";
    details.musicEngine = {
      status: musicStatus,
      provider: this.musicProvider.name,
      details: musicRes.message || "",
      latencyMs: musicRes.latencyMs,
    };

    // 6. Avatar Engine
    const avatarRes = await this.avatarProvider.validateCredentials();
    const avatarStatus: ProviderHealthStatus = avatarRes.valid ? "OPERATIONAL" : "OFFLINE";
    details.avatarEngine = {
      status: avatarStatus,
      provider: this.avatarProvider.name,
      details: avatarRes.message || "",
      latencyMs: avatarRes.latencyMs,
    };

    // 7. Storage (Checks write and read on /data/storage)
    let storageStatus: ProviderHealthStatus = "OPERATIONAL";
    let storageMsg = "Storage local (/data/storage) ativo com permissão de gravação.";
    const storageStart = Date.now();
    try {
      const testFile = path.join(process.cwd(), "data", "storage", ".health_test");
      fs.writeFileSync(testFile, "ok");
      fs.unlinkSync(testFile);
    } catch (e) {
      storageStatus = "OFFLINE";
      storageMsg = `Falha ao gravar no storage: ${e instanceof Error ? e.message : "Erro desconhecido"}`;
    }
    details.storage = {
      status: storageStatus,
      provider: "Local Disk & Cloud Ready Storage",
      details: storageMsg,
      latencyMs: Date.now() - storageStart,
    };

    // 8. Database
    let dbStatus: ProviderHealthStatus = "OPERATIONAL";
    let dbMsg = "Banco de dados JSON atômico persistido e operacional.";
    const dbStart = Date.now();
    try {
      const stats = await db.getStats();
      dbMsg = `Operacional: ${stats.totalProjects} projetos, ${stats.totalAssets} mídias registradas.`;
    } catch (e) {
      dbStatus = "OFFLINE";
      dbMsg = `Erro no banco de dados: ${e instanceof Error ? e.message : "Erro desconhecido"}`;
    }
    details.database = {
      status: dbStatus,
      provider: "Atomic JSON Store with Automatic Backup",
      details: dbMsg,
      latencyMs: Date.now() - dbStart,
    };

    // 9. Render Engine
    const renderRes = await this.renderProvider.validateCredentials();
    const renderStatus: ProviderHealthStatus = renderRes.valid ? "OPERATIONAL" : "OFFLINE";
    details.renderEngine = {
      status: renderStatus,
      provider: this.renderProvider.name,
      details: renderRes.message || "",
      latencyMs: renderRes.latencyMs,
    };

    return {
      gemini: geminiStatus,
      imageEngine: imgStatus,
      videoEngine: vidStatus,
      voiceEngine: voiceStatus,
      musicEngine: musicStatus,
      avatarEngine: avatarStatus,
      storage: storageStatus,
      database: dbStatus,
      renderEngine: renderStatus,
      lastChecked: new Date().toISOString(),
      details,
    };
  }
}

export const aiEngineOrchestrator = new AiEngineOrchestrator();
