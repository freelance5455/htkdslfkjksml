import {
  BaseProvider,
  ProviderCategory,
  ProviderConfigRecord,
  ProviderHealthStatus,
  ProviderValidationResult,
} from "./types";
import { maskApiKey } from "../security";

class ProviderRegistry {
  private providers: Map<string, BaseProvider> = new Map();
  private customConfigs: Map<string, Partial<ProviderConfigRecord>> = new Map();

  // Register an instantiated provider implementation
  public register<TInput, TOutput>(provider: BaseProvider<TInput, TOutput>) {
    this.providers.set(provider.id, provider as unknown as BaseProvider);
  }

  public getProvider<TInput, TOutput>(id: string): BaseProvider<TInput, TOutput> | undefined {
    return this.providers.get(id) as unknown as BaseProvider<TInput, TOutput> | undefined;
  }

  public get<TInput, TOutput>(id: string): BaseProvider<TInput, TOutput> | undefined {
    return this.getProvider<TInput, TOutput>(id);
  }

  // Get fallback chain sorted by priority (lowest number = highest priority)
  public getProvidersForCategory(category: ProviderCategory): BaseProvider[] {
    const list: BaseProvider[] = [];
    for (const provider of this.providers.values()) {
      if (provider.category === category) {
        list.push(provider);
      }
    }
    // Sort by priority ascending (1 is first priority, 2 is second, etc.)
    return list.sort((a, b) => a.priority - b.priority);
  }

  // Return safe configurations for frontend (masks all API keys)
  public listConfigs(category?: ProviderCategory): ProviderConfigRecord[] {
    const records: ProviderConfigRecord[] = [];

    for (const provider of this.providers.values()) {
      if (category && provider.category !== category) continue;

      const custom = this.customConfigs.get(provider.id) || {};
      const apiKey = (custom.apiKey || this.getEnvKeyForProvider(provider.id)) || "";
      const hasKey = provider.isConfigured || !!apiKey;

      records.push({
        id: provider.id,
        name: custom.name || provider.name,
        category: provider.category,
        model: custom.model || provider.model,
        apiEndpoint: custom.apiEndpoint || provider.apiEndpoint,
        hasKey,
        maskedKey: hasKey ? maskApiKey(apiKey) : "",
        status: hasKey ? "OPERATIONAL" : provider.isFallback ? "OPERATIONAL" : "UNCONFIGURED",
        priority: custom.priority ?? provider.priority,
        rateLimitPerMin: custom.rateLimitPerMin ?? 60,
        isFallback: provider.isFallback,
        capabilities: custom.capabilities ?? this.getDefaultCapabilities(provider.id),
        lastTestedAt: custom.lastTestedAt,
        latencyMs: custom.latencyMs,
        notes: custom.notes,
      });
    }

    return records.sort((a, b) => a.priority - b.priority);
  }

  // Save admin updates to a provider
  public updateConfig(
    id: string,
    updates: {
      name?: string;
      model?: string;
      apiEndpoint?: string;
      apiKey?: string;
      priority?: number;
      rateLimitPerMin?: number;
      notes?: string;
    }
  ): ProviderConfigRecord | null {
    const provider = this.providers.get(id);
    if (!provider) return null;

    const existing = this.customConfigs.get(id) || {};
    const updated: Partial<ProviderConfigRecord> = {
      ...existing,
      ...updates,
    };

    if (updates.apiKey && updates.apiKey.trim().length > 0) {
      updated.apiKey = updates.apiKey.trim();
      provider.isConfigured = true;
    }

    if (updates.model) provider.model = updates.model;
    if (updates.priority !== undefined) provider.priority = updates.priority;

    this.customConfigs.set(id, updated);

    const key = updated.apiKey || this.getEnvKeyForProvider(id);
    return {
      id: provider.id,
      name: updated.name || provider.name,
      category: provider.category,
      model: provider.model,
      apiEndpoint: updated.apiEndpoint || provider.apiEndpoint,
      hasKey: !!key || provider.isConfigured,
      maskedKey: maskApiKey(key),
      status: (!!key || provider.isConfigured) ? "OPERATIONAL" : "UNCONFIGURED",
      priority: provider.priority,
      rateLimitPerMin: updated.rateLimitPerMin ?? 60,
      isFallback: provider.isFallback,
      capabilities: this.getDefaultCapabilities(provider.id),
      lastTestedAt: updated.lastTestedAt,
      latencyMs: updated.latencyMs,
      notes: updated.notes,
    };
  }

  // Execute live connection test
  public async testProvider(id: string): Promise<ProviderValidationResult> {
    const provider = this.providers.get(id);
    if (!provider) {
      return {
        valid: false,
        message: `Provider com ID "${id}" não foi encontrado no registro.`,
        testedAt: new Date().toISOString(),
      };
    }

    const start = Date.now();
    try {
      const result = await provider.validateCredentials();
      const latencyMs = Date.now() - start;

      const existing = this.customConfigs.get(id) || {};
      this.customConfigs.set(id, {
        ...existing,
        lastTestedAt: new Date().toISOString(),
        latencyMs,
        status: result.valid ? "OPERATIONAL" : "OFFLINE",
      });

      return {
        ...result,
        latencyMs,
      };
    } catch (err) {
      const latencyMs = Date.now() - start;
      const message = err instanceof Error ? err.message : "Erro desconhecido ao testar conexão com o provedor.";
      return {
        valid: false,
        message,
        latencyMs,
        testedAt: new Date().toISOString(),
      };
    }
  }

  private getEnvKeyForProvider(id: string): string {
    switch (id) {
      case "gemini-text":
      case "gemini-pro":
      case "gemini-core":
        return process.env.GEMINI_API_KEY || "";
      case "openai-gpt":
      case "openai-dalle":
        return process.env.OPENAI_API_KEY || "";
      case "anthropic-claude":
        return process.env.ANTHROPIC_API_KEY || "";
      case "deepseek-v3":
        return process.env.DEEPSEEK_API_KEY || "";
      case "elevenlabs-voice":
        return process.env.ELEVENLABS_API_KEY || "";
      case "pixverse":
      case "pixverse-video":
        return process.env.PIXVERSE_API_KEY || "";
      case "runway-video":
        return process.env.RUNWAY_API_KEY || "";
      case "huggingface-hub":
        return process.env.HUGGINGFACE_API_KEY || process.env.HF_TOKEN || "";
      default:
        return "";
    }
  }

  private getDefaultCapabilities(id: string): string[] {
    const map: Record<string, string[]> = {
      "pixverse": ["Text-to-Video HD/4K", "Image-to-Video", "Motion 3D", "Proporções 9:16 e 16:9", "API Oficial PixVerse"],
      "gemini-text": ["Roteirização Avançada", "Análise Multimodal", "Briefing Criativo", "SEO & Tags", "Tradução"],
      "openai-gpt": ["Roteiro Alternativo", "Punch-up Viral", "Geração de Diálogos"],
      "anthropic-claude": ["Storytelling Profundo", "Roteiro Longo", "Documentários"],
      "deepseek-v3": ["Estruturação Rápida", "Pesquisa Factual", "Curiosidades"],
      "image-engine-studio": ["Geração 4K", "Arte Conceitual", "Cenas em PNG Real", "Consistência de Personagem", "Thumbnails"],
      "video-engine-studio": ["Vídeo 1080p MP4 Real", "Movimentos de Câmera 3D", "Pan & Zoom Cinematográfico", "Renderização por Cenas"],
      "voice-engine-studio": ["Síntese Neural de Voz", "Áudio WAV/MP3 Real", "Controle de Pitch & Velocidade", "Multi-locutores"],
      "elevenlabs-voice": ["Vozes Humanas Ultrarrealistas", "Clonagem Vocal", "Alta Expressividade"],
      "music-engine-studio": ["Trilhas Adaptativas", "Soundscapes Imersivos", "SFX Cinemáticos", "Mixagem Multifaixa"],
      "avatar-engine-studio": ["Apresentador Digital", "Sincronia Labial", "Vídeo MP4 com Transparência/Fundo", "Expressões Faciais"],
      "render-engine-ffmpeg": ["Compilação FFmpeg 1080p/4K", "Auto-Ducking de Áudio", "Sobreposição de Legendas", "Shorts 9:16 Verticais"],
    };
    return map[id] || ["Geração de Mídia Multimodal"];
  }
}

export const providerRegistry = new ProviderRegistry();
