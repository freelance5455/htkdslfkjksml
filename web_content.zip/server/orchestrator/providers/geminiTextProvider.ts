import { GoogleGenAI } from "@google/genai";
import {
  BaseProvider,
  ProviderValidationResult,
  TextGenerationInput,
  TextGenerationOutput,
} from "../types";

export class GeminiTextProvider implements BaseProvider<TextGenerationInput, TextGenerationOutput> {
  public id = "gemini-text";
  public name = "Google Gemini 3.7 Flash";
  public category = "TEXT" as const;
  public model = "gemini-3.7-flash";
  public priority = 1;
  public isFallback = false;
  public apiEndpoint = "https://generativelanguage.googleapis.com";
  public isConfigured = !!process.env.GEMINI_API_KEY;

  private ai: GoogleGenAI | null = null;

  private getClient(): GoogleGenAI {
    if (!this.ai) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY environment variable is required");
      }
      this.ai = new GoogleGenAI({ apiKey });
    }
    return this.ai;
  }

  public async validateCredentials(): Promise<ProviderValidationResult> {
    const start = Date.now();
    try {
      if (!process.env.GEMINI_API_KEY) {
        return {
          valid: false,
          message: "Chave GEMINI_API_KEY não configurada no ambiente do servidor.",
          testedAt: new Date().toISOString(),
          latencyMs: 0,
        };
      }
      const client = this.getClient();
      const res = await client.models.generateContent({
        model: this.model,
        contents: "Ping test. Responda 'PONG' apenas.",
      });

      const text = res.text?.trim() || "";
      const latencyMs = Date.now() - start;
      return {
        valid: true,
        message: `Gemini 3.7 Flash conectado com sucesso! Resposta: "${text.substring(0, 30)}" (${latencyMs}ms)`,
        testedAt: new Date().toISOString(),
        latencyMs,
      };
    } catch (err) {
      const latencyMs = Date.now() - start;
      const msg = err instanceof Error ? err.message : "Falha na conexão com a API do Gemini.";
      return {
        valid: false,
        message: `Erro na validação do Gemini: ${msg}`,
        testedAt: new Date().toISOString(),
        latencyMs,
      };
    }
  }

  public async generate(
    input: TextGenerationInput,
    options?: Record<string, unknown>
  ): Promise<TextGenerationOutput> {
    const client = this.getClient();
    const systemInstruction =
      input.systemInstruction ||
      "Você é o Diretor Criativo e Engenheiro de Conteúdo Mestre do AI Creator Studio. Responda com excelência, precisão técnica e foco total na experiência do usuário.";

    const contents = `${input.prompt}\n\nContexto adicional: ${JSON.stringify(input.context || {})}`;

    try {
      const response = await client.models.generateContent({
        model: this.model,
        contents,
        config: {
          systemInstruction,
          temperature: input.temperature ?? 0.7,
        },
      });

      const text = response.text || "";

      let structured: Record<string, unknown> | undefined = undefined;
      const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        try {
          structured = JSON.parse(jsonMatch[1]);
        } catch {
          // Keep raw text
        }
      } else if (text.trim().startsWith("{") && text.trim().endsWith("}")) {
        try {
          structured = JSON.parse(text.trim());
        } catch {
          // Keep raw text
        }
      }

      return {
        text,
        structured,
        model: this.model,
        providerId: this.id,
      };
    } catch (err) {
      console.error("[GeminiTextProvider] Generation error:", err);
      throw err;
    }
  }
}
