import fs from "fs";
import path from "path";
import crypto from "crypto";
import { exec } from "child_process";
import { promisify } from "util";
import {
  BaseProvider,
  ProviderValidationResult,
  VideoGenerationInput,
  VideoGenerationOutput,
} from "../types";
import { db } from "../../db";

const execAsync = promisify(exec);

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const STORAGE_DIR = process.env.STORAGE_DIR || path.join(DATA_DIR, "storage");
const VIDEOS_DIR = path.join(STORAGE_DIR, "videos");
const THUMBNAILS_DIR = path.join(STORAGE_DIR, "thumbnails");

export interface PixVerseGenerateResponse {
  code?: number;
  ErrCode?: number;
  message?: string;
  ErrMsg?: string;
  Resp?: {
    video_id?: string | number;
  } | null;
  msg?: string;
}

export interface PixVerseResultResponse {
  code?: number;
  ErrCode?: number;
  message?: string;
  ErrMsg?: string;
  Resp?: {
    video_id?: string | number;
    status: number; // 1: completed, 5: generating/processing, other: error/failed
    url?: string;
    duration?: number;
    error_msg?: string;
    aspect_ratio?: string;
    resolution?: string;
  } | null;
}

export class PixVerseProvider implements BaseProvider<VideoGenerationInput, VideoGenerationOutput> {
  public id = "pixverse";
  public name = "PixVerse V3.5 & V2 (AI Cinematic Video)";
  public category = "VIDEO" as const;
  public model = "v3.5";
  public priority = 1; // Primary real video provider
  public isFallback = false;
  public apiEndpoint = "https://app-api.pixverse.ai";

  constructor() {
    this.ensureDirectories();
  }

  private ensureDirectories() {
    for (const dir of [STORAGE_DIR, VIDEOS_DIR, THUMBNAILS_DIR]) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }

  public get isConfigured(): boolean {
    const key = process.env.PIXVERSE_API_KEY;
    return !!key && key.trim().length > 0;
  }

  public get apiKey(): string {
    return process.env.PIXVERSE_API_KEY?.trim() || "";
  }

  /**
   * Validate API credentials against PixVerse official endpoint
   */
  public async validateCredentials(): Promise<ProviderValidationResult> {
    const start = Date.now();
    if (!this.isConfigured) {
      return {
        valid: false,
        message: "Este motor ainda não está configurado. Configure a variável PIXVERSE_API_KEY nas configurações ou secrets do servidor.",
        testedAt: new Date().toISOString(),
        latencyMs: 0,
      };
    }

    try {
      // Test connectivity to PixVerse API result endpoint with dummy ID or health probe
      const traceId = crypto.randomUUID();
      const testRes = await fetch(`${this.apiEndpoint}/openapi/v2/video/result/test-ping`, {
        method: "GET",
        headers: {
          "API-KEY": this.apiKey,
          "Ai-trace-id": traceId,
        },
      });

      const latencyMs = Date.now() - start;
      // If unauthorized (401 / 403 / code invalid key), report clearly
      if (testRes.status === 401 || testRes.status === 403) {
        return {
          valid: false,
          message: `Chave PIXVERSE_API_KEY rejeitada pela API oficial (HTTP ${testRes.status}). Verifique sua chave no console da PixVerse.`,
          testedAt: new Date().toISOString(),
          latencyMs,
        };
      }

      return {
        valid: true,
        message: "PixVerse API conectada e autenticada com sucesso.",
        testedAt: new Date().toISOString(),
        latencyMs,
      };
    } catch (err: unknown) {
      const latencyMs = Date.now() - start;
      const msg = err instanceof Error ? err.message : "Erro de conexão";
      return {
        valid: false,
        message: `Falha de rede ao conectar com PixVerse API: ${msg}`,
        testedAt: new Date().toISOString(),
        latencyMs,
      };
    }
  }

  /**
   * Generate video (Text-to-Video or Image-to-Video) using PixVerse official API
   */
  public async generate(
    input: VideoGenerationInput,
    options?: {
      jobId?: string;
      onProgress?: (status: string, message: string) => Promise<void>;
    }
  ): Promise<VideoGenerationOutput> {
    this.ensureDirectories();

    if (!this.isConfigured) {
      throw new Error(
        "Este motor ainda não está configurado. A variável PIXVERSE_API_KEY não foi encontrada nas variáveis de ambiente do servidor."
      );
    }

    // 1. Map input parameters to PixVerse official format
    // PixVerse standard supported durations: 5 or 8 seconds
    const duration = input.durationSeconds && input.durationSeconds >= 8 ? 8 : 5;
    
    // PixVerse standard aspect ratios: "16:9", "9:16", "1:1", "4:5", "21:9"
    let aspectRatio = "9:16";
    if (input.aspectRatio === "16:9") aspectRatio = "16:9";
    else if (input.aspectRatio === "1:1") aspectRatio = "1:1";
    else if (input.aspectRatio === "4:5") aspectRatio = "4:5";
    else if (input.aspectRatio === "21:9") aspectRatio = "21:9";

    // PixVerse free tier accounts support up to 720p resolution.
    // Default to 720p to ensure compatibility across free/creator tiers.
    let quality = input.resolution === "1080p" ? "1080p" : "720p";
    const model = "v3.5";

    const traceId = crypto.randomUUID();
    const isImageToVideo = !!input.imageUrl && input.imageUrl.trim().length > 0;
    const endpoint = isImageToVideo
      ? `${this.apiEndpoint}/openapi/v2/video/img/generate`
      : `${this.apiEndpoint}/openapi/v2/video/text/generate`;

    const buildPayload = (resQuality: string) => isImageToVideo
      ? {
          prompt: input.prompt,
          img_url: input.imageUrl,
          duration,
          model,
          quality: resQuality,
          ...(input.negativePrompt ? { negative_prompt: input.negativePrompt } : {}),
        }
      : {
          prompt: input.prompt,
          aspect_ratio: aspectRatio,
          duration,
          model,
          quality: resQuality,
          ...(input.negativePrompt ? { negative_prompt: input.negativePrompt } : {}),
          ...(input.seed ? { seed: input.seed } : {}),
        };

    console.log(`[PixVerseProvider] Submitting generation to ${endpoint} with quality: ${quality}`);

    // 2. Submit generation job
    let submitResponse = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "API-KEY": this.apiKey,
        "Ai-trace-id": traceId,
      },
      body: JSON.stringify(buildPayload(quality)),
    });

    if (!submitResponse.ok) {
      const errorText = await submitResponse.text().catch(() => "");
      // If free tier limit (500073), retry with 720p or 540p
      if (errorText.includes("500073") && quality === "1080p") {
        console.log("[PixVerseProvider] Free tier detected (500073), retrying with 720p...");
        quality = "720p";
        submitResponse = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "API-KEY": this.apiKey,
            "Ai-trace-id": crypto.randomUUID(),
          },
          body: JSON.stringify(buildPayload(quality)),
        });
      }

      if (!submitResponse.ok) {
        throw new Error(`PixVerse API retornou erro HTTP ${submitResponse.status}: ${errorText || submitResponse.statusText}`);
      }
    }

    const submitData = (await submitResponse.json()) as PixVerseGenerateResponse;
    const submitErrCode = submitData.ErrCode ?? submitData.code ?? 0;
    const submitErrMsg = submitData.ErrMsg || submitData.message || submitData.msg;

    if (submitErrCode !== 0 || !submitData.Resp?.video_id) {
      if (submitErrCode === 500090) {
        throw new Error("Saldo de créditos insuficiente na sua conta PixVerse (ErrCode 500090). Adicione créditos no painel da PixVerse para gerar novos vídeos.");
      }
      const errorMsg = submitErrMsg || `Código de erro PixVerse: ${submitErrCode}`;
      throw new Error(`Falha ao iniciar geração no PixVerse: ${errorMsg}`);
    }

    const pixverseVideoId = String(submitData.Resp.video_id);
    console.log(`[PixVerseProvider] Job aceito com sucesso pela PixVerse. Video ID: ${pixverseVideoId}`);

    // Update job in database if jobId provided
    if (options?.jobId) {
      await db.updateJob(options.jobId, {
        provider: "PIXVERSE",
        providerJobId: pixverseVideoId,
        status: "processing",
        stepLabel: `Job submetido à PixVerse (ID: ${pixverseVideoId}). Aguardando processamento...`,
      });
      if (options.onProgress) {
        await options.onProgress("processing", `Processando no cluster PixVerse (Job ID: ${pixverseVideoId})...`);
      }
    }

    // 3. Poll PixVerse result endpoint until completed or failed
    // Max wait: 12 minutes (180 attempts with 4s intervals)
    const maxAttempts = 180;
    const pollIntervalMs = 4000;
    let finalVideoUrl = "";

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));

      const pollTraceId = crypto.randomUUID();
      let resultResponse: Response;
      try {
        resultResponse = await fetch(`${this.apiEndpoint}/openapi/v2/video/result/${pixverseVideoId}`, {
          method: "GET",
          headers: {
            "API-KEY": this.apiKey,
            "Ai-trace-id": pollTraceId,
          },
        });
      } catch (pollErr) {
        console.warn(`[PixVerseProvider] Network glitch on poll attempt ${attempt}, retrying...`, pollErr);
        continue;
      }

      if (!resultResponse.ok) {
        console.warn(`[PixVerseProvider] Poll attempt ${attempt} returned HTTP ${resultResponse.status}, retrying...`);
        continue;
      }

      const resultData = (await resultResponse.json()) as PixVerseResultResponse;
      const pollErrCode = resultData.ErrCode ?? resultData.code ?? 0;
      if (pollErrCode !== 0) {
        const pollErrMsg = resultData.ErrMsg || resultData.message || `Código: ${pollErrCode}`;
        console.warn(`[PixVerseProvider] Poll returned non-zero code: ${pollErrCode}, message: ${pollErrMsg}`);
      }

      const resp = resultData.Resp;
      if (!resp) continue;

      // Status 1 = Completed
      if (resp.status === 1 && resp.url) {
        finalVideoUrl = resp.url;
        console.log(`[PixVerseProvider] Vídeo gerado com sucesso pela PixVerse! URL: ${finalVideoUrl}`);
        break;
      }

      // Status 5 = Generating / Processing (no fake percentages)
      if (resp.status === 5) {
        if (options?.jobId && attempt % 3 === 0) {
          const stepMsg = `Renderizando vídeo na PixVerse (Vídeo ID: ${pixverseVideoId}, tentativa ${attempt})...`;
          await db.updateJob(options.jobId, {
            stepLabel: stepMsg,
          });
          if (options?.onProgress) {
            await options.onProgress("processing", stepMsg);
          }
        }
        continue;
      }

      // Status other and not 1 or 5 -> Error or failed
      if (resp.status !== 1 && resp.status !== 5) {
        const errMsg = resp.error_msg || `PixVerse status de erro: ${resp.status}`;
        throw new Error(`Geração cancelada ou com erro no PixVerse: ${errMsg}`);
      }
    }

    if (!finalVideoUrl) {
      throw new Error(`Timeout: PixVerse não concluiu a geração do vídeo ${pixverseVideoId} em 12 minutos.`);
    }

    // 4. Download the real video file to persistent storage
    const assetId = `pixverse-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
    const videoFilename = `${assetId}.mp4`;
    const localVideoPath = path.join(VIDEOS_DIR, videoFilename);
    const publicVideoUrl = `/api/storage/files/videos/${videoFilename}`;

    console.log(`[PixVerseProvider] Baixando arquivo de vídeo real de ${finalVideoUrl} para ${localVideoPath}...`);
    
    if (options?.jobId && options?.onProgress) {
      await options.onProgress("processing", "Download do vídeo concluído da PixVerse para o storage local...");
    }

    await this.downloadFile(finalVideoUrl, localVideoPath);

    const stats = fs.statSync(localVideoPath);
    if (stats.size === 0) {
      throw new Error("Arquivo de vídeo baixado da PixVerse possui tamanho zero.");
    }

    // 5. Generate a real thumbnail using FFmpeg
    const thumbFilename = `${assetId}.jpg`;
    const localThumbPath = path.join(THUMBNAILS_DIR, thumbFilename);
    const publicThumbUrl = `/api/storage/files/thumbnails/${thumbFilename}`;

    let thumbGenerated = false;
    try {
      await execAsync(`ffmpeg -ss 00:00:01 -i "${localVideoPath}" -vframes 1 -q:v 2 "${localThumbPath}" -y`);
      if (fs.existsSync(localThumbPath) && fs.statSync(localThumbPath).size > 0) {
        thumbGenerated = true;
      }
    } catch (ffmpegErr) {
      console.warn("[PixVerseProvider] Falha ao extrair thumbnail com FFmpeg:", ffmpegErr);
    }

    const width = aspectRatio === "9:16" ? 720 : aspectRatio === "16:9" ? 1280 : 1080;
    const height = aspectRatio === "9:16" ? 1280 : aspectRatio === "16:9" ? 720 : 1080;

    // 6. Register MediaAsset in persistent database
    await db.saveMediaAsset({
      id: assetId,
      projectId: input.projectId,
      fileType: "video",
      type: "VIDEO",
      name: `PixVerse: ${input.prompt.slice(0, 50)}`,
      storagePath: localVideoPath,
      url: publicVideoUrl,
      publicUrl: publicVideoUrl,
      mimeType: "video/mp4",
      size: stats.size,
      duration,
      width,
      height,
      provider: "PIXVERSE",
      model,
      prompt: input.prompt,
      thumbnailUrl: thumbGenerated ? publicThumbUrl : undefined,
      status: "COMPLETED",
      createdAt: new Date().toISOString(),
    });

    // 7. Update Job record in persistent database
    if (options?.jobId) {
      await db.updateJob(options.jobId, {
        status: "completed",
        progress: 100,
        stepLabel: "Vídeo gerado e armazenado com sucesso!",
        outputFileUrl: publicVideoUrl,
        providerJobId: pixverseVideoId,
        completedAt: new Date().toISOString(),
        output: {
          assetId,
          url: publicVideoUrl,
          thumbnailUrl: thumbGenerated ? publicThumbUrl : undefined,
          providerJobId: pixverseVideoId,
          size: stats.size,
          duration,
          width,
          height,
        },
      });
    }

    return {
      assetId,
      url: publicVideoUrl,
      storagePath: localVideoPath,
      width,
      height,
      durationSeconds: duration,
      mimeType: "video/mp4",
      sizeBytes: stats.size,
      providerId: this.id,
      model,
      thumbnailUrl: thumbGenerated ? publicThumbUrl : undefined,
      metadata: {
        providerJobId: pixverseVideoId,
        sourceUrl: finalVideoUrl,
        aspectRatio,
        quality,
      },
    };
  }

  /**
   * Helper to safely stream & download remote file to local disk
   */
  private async downloadFile(url: string, destPath: string): Promise<void> {
    const response = await fetch(url);
    if (!response.ok || !response.body) {
      throw new Error(`Falha ao baixar arquivo de ${url}: HTTP ${response.status} ${response.statusText}`);
    }

    const fileStream = fs.createWriteStream(destPath);
    // @ts-expect-error Node.js fetch stream to stream/promises
    const { Readable } = await import("stream");
    // @ts-expect-error readable stream
    const readable = Readable.fromWeb(response.body);

    await new Promise((resolve, reject) => {
      readable.pipe(fileStream);
      fileStream.on("finish", resolve);
      fileStream.on("error", reject);
    });
  }
}
