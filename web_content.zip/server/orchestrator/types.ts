export type ProviderCategory =
  | "TEXT"
  | "IMAGE"
  | "VIDEO"
  | "VOICE"
  | "MUSIC"
  | "AVATAR"
  | "RENDER";

export type ProviderHealthStatus =
  | "OPERATIONAL"   // 🟢 Operacional
  | "DEGRADED"      // 🟡 Limitado
  | "OFFLINE"       // 🔴 Offline
  | "UNCONFIGURED";  // ⚪ Não configurado

export type JobStatus =
  | "queued"
  | "processing"
  | "completed"
  | "failed"
  | "cancelled";

export interface ProviderValidationResult {
  valid: boolean;
  message?: string;
  latencyMs?: number;
  testedAt: string;
}

export interface BaseProvider<TInput = unknown, TOutput = unknown> {
  id: string;
  name: string;
  category: ProviderCategory;
  model: string;
  priority: number;
  isFallback: boolean;
  apiEndpoint?: string;
  isConfigured: boolean;

  validateCredentials(): Promise<ProviderValidationResult>;
  generate(input: TInput, options?: Record<string, unknown>): Promise<TOutput>;
  getStatus?(jobId: string): Promise<{ status: JobStatus; progress: number; error?: string }>;
  getResult?(jobId: string): Promise<TOutput | null>;
  cancel?(jobId: string): Promise<boolean>;
}

export interface ProviderConfigRecord {
  id: string;
  name: string;
  category: ProviderCategory;
  model: string;
  apiEndpoint?: string;
  apiKey?: string; // Stored securely on server only
  hasKey: boolean;
  maskedKey: string;
  status: ProviderHealthStatus;
  priority: number;
  rateLimitPerMin?: number;
  isFallback: boolean;
  capabilities: string[];
  lastTestedAt?: string;
  latencyMs?: number;
  notes?: string;
}

export interface AiJobRecord<TInput = unknown, TOutput = unknown> {
  id: string;
  projectId?: string;
  userId?: string;
  type: ProviderCategory;
  providerId: string;
  providerName: string;
  model: string;
  status: JobStatus;
  progress: number; // 0 - 100
  stepLabel?: string;
  input: TInput;
  output?: TOutput;
  error?: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  durationMs?: number;
  fallbackChain?: Array<{
    providerId: string;
    error: string;
    attemptedAt: string;
  }>;
}

export interface SystemHealthDashboard {
  gemini: ProviderHealthStatus;
  imageEngine: ProviderHealthStatus;
  videoEngine: ProviderHealthStatus;
  voiceEngine: ProviderHealthStatus;
  musicEngine: ProviderHealthStatus;
  avatarEngine: ProviderHealthStatus;
  storage: ProviderHealthStatus;
  database: ProviderHealthStatus;
  renderEngine: ProviderHealthStatus;
  lastChecked: string;
  details: Record<string, {
    status: ProviderHealthStatus;
    provider: string;
    details: string;
    latencyMs?: number;
  }>;
}

// Concrete I/O definitions for each Engine

export interface TextGenerationInput {
  prompt: string;
  taskType?: "SCRIPT" | "STORYBOARD" | "BRIEF" | "SEO" | "HOOKS" | "TRANSLATION" | "GENERAL";
  systemInstruction?: string;
  context?: Record<string, unknown>;
  targetDurationSeconds?: number;
  sceneCount?: number;
  temperature?: number;
}

export interface TextGenerationOutput {
  text: string;
  structured?: Record<string, unknown>;
  model: string;
  tokensUsed?: number;
  providerId: string;
}

export interface ImageGenerationInput {
  prompt: string;
  negativePrompt?: string;
  aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3";
  style?: string;
  projectId?: string;
  sceneNumber?: number;
  titleOverlay?: string;
}

export interface ImageGenerationOutput {
  assetId: string;
  url: string;
  storagePath: string;
  width: number;
  height: number;
  mimeType: string;
  sizeBytes: number;
  prompt: string;
  providerId: string;
  model: string;
}

export interface VideoGenerationInput {
  prompt: string;
  negativePrompt?: string;
  imageUrl?: string;
  durationSeconds: number;
  aspectRatio?: "16:9" | "9:16" | "1:1" | "4:5" | "21:9";
  sceneNumber?: number;
  motionType?: "CINEMATIC_ZOOM" | "PAN_RIGHT" | "DYNAMIC_TILT" | "PARTICLES" | string;
  projectId?: string;
  provider?: "AUTO" | "PIXVERSE" | "RUNWAY" | "LUMA" | "HAILUO" | "KLING" | string;
  resolution?: "720p" | "1080p" | "4k";
  quality?: "standard" | "high" | "ultra";
  seed?: number;
  cameraMovement?: string;
}

export interface VideoGenerationOutput {
  assetId: string;
  url: string;
  storagePath: string;
  width: number;
  height: number;
  durationSeconds: number;
  mimeType: string;
  sizeBytes: number;
  providerId: string;
  model: string;
  thumbnailUrl?: string;
  metadata?: Record<string, unknown>;
}

export interface VoiceGenerationInput {
  text: string;
  voiceName?: string;
  language?: string;
  pitch?: number;
  speed?: number;
  emotion?: string;
  projectId?: string;
}

export interface VoiceGenerationOutput {
  assetId: string;
  url: string;
  storagePath: string;
  durationSeconds: number;
  mimeType: string;
  sizeBytes: number;
  providerId: string;
  model: string;
}

export interface MusicGenerationInput {
  prompt?: string;
  genre?: string;
  mood?: string;
  durationSeconds: number;
  intensity?: "SOFT" | "MEDIUM" | "EPIC";
  projectId?: string;
}

export interface MusicGenerationOutput {
  assetId: string;
  url: string;
  storagePath: string;
  durationSeconds: number;
  genre: string;
  mimeType: string;
  sizeBytes: number;
  providerId: string;
}

export interface AvatarGenerationInput {
  avatarId: string;
  scriptText: string;
  audioUrl?: string;
  backgroundStyle?: "STUDIO_BLUE" | "DARK_CINEMA" | "TRANSPARENT" | "GRADIENT";
  aspectRatio?: "16:9" | "9:16";
  projectId?: string;
}

export interface AvatarGenerationOutput {
  assetId: string;
  url: string;
  storagePath: string;
  durationSeconds: number;
  mimeType: string;
  sizeBytes: number;
  avatarId: string;
  providerId: string;
}

export interface RenderTimelineInput {
  projectId: string;
  outputFormat: "YOUTUBE_1080p" | "SHORTS_1080p" | "INSTAGRAM_PORTRAIT" | "TIKTOK_PORTRAIT";
  scenes: Array<{
    id: string;
    sceneNumber: number;
    videoUrl?: string;
    imageUrl?: string;
    duration: number;
    audioUrl?: string;
    narrationText?: string;
  }>;
  backgroundMusicUrl?: string;
  musicVolume?: number; // 0.0 - 1.0 (auto-ducked)
  voiceVolume?: number; // 0.0 - 1.0
  includeSubtitles?: boolean;
}

export interface RenderTimelineOutput {
  assetId: string;
  url: string;
  storagePath: string;
  width: number;
  height: number;
  durationSeconds: number;
  mimeType: string;
  sizeBytes: number;
  renderTimeMs: number;
}
