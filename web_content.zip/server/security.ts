import crypto from 'crypto';
import type { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import path from 'path';
import { db } from './db.ts';

const RUNTIME_JWT_SECRET =
  process.env.JWT_SECRET && process.env.JWT_SECRET.trim().length >= 16
    ? process.env.JWT_SECRET.trim()
    : crypto.randomBytes(32).toString('hex');

const RUNTIME_WEBHOOK_SECRET =
  process.env.PAYMENT_WEBHOOK_SECRET && process.env.PAYMENT_WEBHOOK_SECRET.trim().length >= 16
    ? process.env.PAYMENT_WEBHOOK_SECRET.trim()
    : crypto.randomBytes(32).toString('hex');

export const SESSION_COOKIE_NAME = 'studio_session';
export const CSRF_COOKIE_NAME = 'studio_csrf';

export const ALLOWED_WEB_EXTENSIONS = new Set([
  '.html',
  '.htm',
  '.css',
  '.js',
  '.mjs',
  '.json',
  '.png',
  '.jpg',
  '.jpeg',
  '.svg',
  '.webp',
  '.woff',
  '.woff2',
  '.ttf',
  '.otf',
  '.ico',
  '.txt',
  '.xml',
  '.webmanifest',
  '.map',
]);

export const ALLOWED_ICON_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp']);

const JAVA_KOTLIN_KEYWORDS = new Set([
  'abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char',
  'class', 'const', 'continue', 'default', 'do', 'double', 'else', 'enum',
  'extends', 'final', 'finally', 'float', 'for', 'goto', 'if', 'implements',
  'import', 'instanceof', 'int', 'interface', 'long', 'native', 'new', 'null',
  'package', 'private', 'protected', 'public', 'return', 'short', 'static',
  'strictfp', 'super', 'switch', 'synchronized', 'this', 'throw', 'throws',
  'transient', 'try', 'void', 'volatile', 'while', 'true', 'false', 'fun',
  'val', 'var', 'object', 'when', 'in', 'is', 'as', 'typealias',
]);

export function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = part.slice(idx + 1).trim();
    if (!key) continue;
    try {
      result[key] = decodeURIComponent(val);
    } catch {
      result[key] = val;
    }
  }
  return result;
}

export function isHttpsRequest(req: Request): boolean {
  const proto = String(req.headers['x-forwarded-proto'] || '').toLowerCase();
  return req.secure || proto.includes('https');
}

export function setAuthCookies(req: Request, res: Response, token: string): string {
  const csrfToken = crypto.randomBytes(24).toString('hex');
  const secure = isHttpsRequest(req);
  const maxAgeMs = 7 * 24 * 60 * 60 * 1000;

  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure,
    sameSite: 'lax',
    path: '/',
    maxAge: maxAgeMs,
  });

  res.cookie(CSRF_COOKIE_NAME, csrfToken, {
    httpOnly: false,
    secure,
    sameSite: 'lax',
    path: '/',
    maxAge: maxAgeMs,
  });

  return csrfToken;
}

export function clearAuthCookies(req: Request, res: Response): void {
  const secure = isHttpsRequest(req);
  res.clearCookie(SESSION_COOKIE_NAME, { path: '/', httpOnly: true, sameSite: 'lax', secure });
  res.clearCookie(CSRF_COOKIE_NAME, { path: '/', httpOnly: false, sameSite: 'lax', secure });
}

export function isValidImageBuffer(buf: Buffer): { valid: boolean; type?: 'png' | 'jpeg' | 'webp' } {
  if (!buf || buf.length < 12) return { valid: false };
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47 &&
    buf[4] === 0x0d &&
    buf[5] === 0x0a &&
    buf[6] === 0x1a &&
    buf[7] === 0x0a
  ) {
    return { valid: true, type: 'png' };
  }
  // JPEG: FF D8 FF
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return { valid: true, type: 'jpeg' };
  }
  // WEBP: RIFF....WEBP
  if (
    buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buf.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return { valid: true, type: 'webp' };
  }
  return { valid: false };
}

export function getPngDimensions(buf: Buffer): { width: number; height: number } | null {
  if (buf.length < 24) return null;
  if (buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) return null;
  const width = buf.readUInt32BE(16);
  const height = buf.readUInt32BE(20);
  return { width, height };
}

export function safeResolveInside(baseDir: string, untrustedRelPath: string): string {
  const normalizedBase = path.resolve(baseDir);
  const cleaned = untrustedRelPath.replace(/\\/g, '/').replace(/^\/+/, '');
  if (!cleaned || cleaned.includes('\0')) {
    throw new Error('Geçersiz dosya yolu tespit edildi.');
  }
  const target = path.resolve(normalizedBase, cleaned);
  if (target !== normalizedBase && !target.startsWith(normalizedBase + path.sep)) {
    throw new Error(`Güvenlik ihlali: Dizin dışına erişim engellendi (${untrustedRelPath}).`);
  }
  return target;
}

export function isAllowedWebFile(filename: string): boolean {
  const ext = path.extname(filename).toLowerCase();
  return ALLOWED_WEB_EXTENSIONS.has(ext);
}

export function validateAndroidPackageName(pkg: string): { valid: boolean; reason?: string } {
  if (typeof pkg !== 'string') {
    return { valid: false, reason: 'Paket adı metin olmalıdır.' };
  }
  const trimmed = pkg.trim();
  if (trimmed.length < 5 || trimmed.length > 120) {
    return { valid: false, reason: 'Paket adı 5 ile 120 karakter arasında olmalıdır.' };
  }
  const regex = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
  if (!regex.test(trimmed)) {
    return {
      valid: false,
      reason:
        'Paket adı küçük harflerle başlamalı, en az iki bölümden oluşmalıdır (ör. com.firma.uygulama).',
    };
  }
  const segments = trimmed.split('.');
  for (const seg of segments) {
    if (JAVA_KOTLIN_KEYWORDS.has(seg)) {
      return {
        valid: false,
        reason: `Paket adında ayrılmış anahtar kelime kullanılamaz: "${seg}".`,
      };
    }
  }
  return { valid: true };
}

export function sanitizeHexColor(color: unknown, fallback = '#0B1020'): string {
  if (typeof color === 'string' && /^#[0-9a-fA-F]{6}$/.test(color.trim())) {
    return color.trim().toUpperCase();
  }
  return fallback;
}

export function sanitizeXmlText(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export interface AuthTokenPayload {
  userId: string;
  email: string;
  role: 'user' | 'admin';
}

export function signAuthToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, RUNTIME_JWT_SECRET, { expiresIn: '7d' });
}

export function verifyAuthToken(token: string): AuthTokenPayload {
  return jwt.verify(token, RUNTIME_JWT_SECRET) as AuthTokenPayload;
}

export function signWebhookPayload(payload: string): string {
  return crypto.createHmac('sha256', RUNTIME_WEBHOOK_SECRET).update(payload).digest('hex');
}

export function verifyWebhookSignature(payload: string, signatureHex: string): boolean {
  const expected = signWebhookPayload(payload);
  const a = Buffer.from(expected, 'hex');
  const b = Buffer.from(signatureHex || '', 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function verifyPaytrCallbackHash(params: {
  merchantOid: string;
  status: string;
  totalAmount: string;
  receivedHash: string;
}): boolean {
  const merchantKey = process.env.PAYTR_MERCHANT_KEY || '';
  const merchantSalt = process.env.PAYTR_MERCHANT_SALT || '';
  if (!merchantKey || !merchantSalt) return false;
  const hashStr = `${params.merchantOid}${merchantSalt}${params.status}${params.totalAmount}`;
  const expected = crypto.createHmac('sha256', merchantKey).update(hashStr).digest('base64');
  const a = Buffer.from(expected);
  const b = Buffer.from(params.receivedHash || '');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function getPaymentProviderStatus(): {
  provider: 'paytr' | 'iyzico' | 'test_demo';
  isLiveConfigured: boolean;
  label: string;
} {
  if (
    process.env.PAYTR_MERCHANT_ID &&
    process.env.PAYTR_MERCHANT_KEY &&
    process.env.PAYTR_MERCHANT_SALT
  ) {
    return { provider: 'paytr', isLiveConfigured: true, label: 'PayTR Güvenli Ödeme' };
  }
  if (process.env.IYZICO_API_KEY && process.env.IYZICO_SECRET_KEY) {
    return { provider: 'iyzico', isLiveConfigured: true, label: 'iyzico Güvenli Ödeme' };
  }
  return {
    provider: 'test_demo',
    isLiveConfigured: false,
    label: 'Test / Demo Ödeme Modu (Sağlayıcı anahtarı yapılandırılmadı)',
  };
}

export function recordAuditLog(params: {
  actorUserId: string | null;
  action: string;
  targetType: string;
  targetId?: string | null;
  details?: Record<string, unknown>;
  ipAddress?: string | null;
}): void {
  db.prepare(`
    INSERT INTO audit_logs (id, actor_user_id, action, target_type, target_id, details_json, ip_address, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    `aud_${crypto.randomUUID().slice(0, 10)}`,
    params.actorUserId,
    params.action,
    params.targetType,
    params.targetId || null,
    JSON.stringify(params.details || {}),
    params.ipAddress || null,
    new Date().toISOString()
  );
}
