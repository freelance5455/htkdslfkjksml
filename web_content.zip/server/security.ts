import { Request, Response, NextFunction } from "express";
import crypto from "crypto";

// In-memory rate limiting tracker
interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const ipRequestMap = new Map<string, RateLimitRecord>();

// Clean up stale rate limit records every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [ip, record] of ipRequestMap.entries()) {
    if (now > record.resetAt) {
      ipRequestMap.delete(ip);
    }
  }
}, 5 * 60 * 1000);

export function apiRateLimiter(options?: { maxRequests?: number; windowMs?: number }) {
  const max = options?.maxRequests || 300; // 300 requests
  const windowMs = options?.windowMs || 60 * 1000; // per 1 minute

  return (req: Request, res: Response, next: NextFunction) => {
    const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "127.0.0.1";
    const now = Date.now();

    const record = ipRequestMap.get(ip);
    if (!record || now > record.resetAt) {
      ipRequestMap.set(ip, { count: 1, resetAt: now + windowMs });
      return next();
    }

    record.count++;
    if (record.count > max) {
      return res.status(429).json({
        error: "Rate Limit Exceeded",
        message: "Muitas requisições em um curto período. Por favor, aguarde alguns instantes.",
        retryAfter: Math.ceil((record.resetAt - now) / 1000),
      });
    }

    next();
  };
}

// Mask secret API keys so they are NEVER returned in clear text to the frontend
export function maskApiKey(key?: string): string {
  if (!key || typeof key !== "string") return "";
  const trimmed = key.trim();
  if (trimmed.length <= 8) return "••••••••";
  return `${trimmed.substring(0, 4)}••••••••${trimmed.substring(trimmed.length - 4)}`;
}

export interface ProviderStatusInfo {
  id: string;
  name: string;
  configured: boolean;
  maskedKey: string;
  category: "VIDEO" | "TEXT" | "IMAGE" | "VOICE" | "MUSIC";
  capabilities: string[];
  statusMessage: string;
}

export function getAiProvidersConfigStatus(): Record<string, ProviderStatusInfo> {
  const pixverseKey = process.env.PIXVERSE_API_KEY;
  const runwayKey = process.env.RUNWAY_API_KEY;
  const lumaKey = process.env.LUMA_API_KEY;
  const hailuoKey = process.env.HAILUO_API_KEY;
  const klingKey = process.env.KLING_API_KEY;
  const geminiKey = process.env.GEMINI_API_KEY;
  const elevenLabsKey = process.env.ELEVENLABS_API_KEY;

  return {
    GEMINI: {
      id: "gemini",
      name: "Google Gemini 2.5 Pro / Flash",
      configured: !!geminiKey && geminiKey.trim().length > 0,
      maskedKey: maskApiKey(geminiKey),
      category: "TEXT",
      capabilities: ["Text-to-Text", "Script Generation", "Scene Decomposition", "SEO Analysis"],
      statusMessage: geminiKey ? "Motor conectado e operacional" : "Este motor ainda não está configurado.",
    },
    PIXVERSE: {
      id: "pixverse",
      name: "PixVerse AI Video v3.5 / v2",
      configured: !!pixverseKey && pixverseKey.trim().length > 0,
      maskedKey: maskApiKey(pixverseKey),
      category: "VIDEO",
      capabilities: ["Text-to-Video", "Image-to-Video", "Aspect Ratios 16:9/9:16/1:1", "Camera Motions"],
      statusMessage: pixverseKey ? "Motor conectado e operacional" : "Este motor ainda não está configurado.",
    },
    RUNWAY: {
      id: "runway",
      name: "RunwayML Gen-3 Alpha / Gen-2",
      configured: !!runwayKey && runwayKey.trim().length > 0,
      maskedKey: maskApiKey(runwayKey),
      category: "VIDEO",
      capabilities: ["Text-to-Video", "Image-to-Video", "Cinematic Quality", "Director Mode"],
      statusMessage: runwayKey ? "Motor conectado e operacional" : "Este motor ainda não está configurado.",
    },
    LUMA: {
      id: "luma",
      name: "Luma Dream Machine Ray",
      configured: !!lumaKey && lumaKey.trim().length > 0,
      maskedKey: maskApiKey(lumaKey),
      category: "VIDEO",
      capabilities: ["Text-to-Video", "Image-to-Video", "Smooth Physics", "Keyframe Control"],
      statusMessage: lumaKey ? "Motor conectado e operacional" : "Este motor ainda não está configurado.",
    },
    HAILUO: {
      id: "hailuo",
      name: "Hailuo / MiniMax Video-01",
      configured: !!hailuoKey && hailuoKey.trim().length > 0,
      maskedKey: maskApiKey(hailuoKey),
      category: "VIDEO",
      capabilities: ["Text-to-Video", "Image-to-Video", "Dynamic Character Motion"],
      statusMessage: hailuoKey ? "Motor conectado e operacional" : "Este motor ainda não está configurado.",
    },
    KLING: {
      id: "kling",
      name: "Kling AI Video v1.5",
      configured: !!klingKey && klingKey.trim().length > 0,
      maskedKey: maskApiKey(klingKey),
      category: "VIDEO",
      capabilities: ["Text-to-Video", "Image-to-Video", "Ultra Realistic Physics", "1080p Generation"],
      statusMessage: klingKey ? "Motor conectado e operacional" : "Kling API não configurada/disponível.",
    },
    ELEVENLABS: {
      id: "elevenlabs",
      name: "ElevenLabs Neural Voice",
      configured: !!elevenLabsKey && elevenLabsKey.trim().length > 0,
      maskedKey: maskApiKey(elevenLabsKey),
      category: "VOICE",
      capabilities: ["Text-to-Speech", "Voice Cloning", "Multi-lingual Emotion"],
      statusMessage: elevenLabsKey ? "Motor conectado e operacional" : "Este motor ainda não está configurado.",
    },
  };
}

// Input sanitizer to prevent prompt injection or script injection
export function sanitizeInput(input: unknown): string {
  if (typeof input !== "string") return "";
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .trim();
}

// Validate file uploads against MIME type and size
export function validateUploadFile(file: { mimetype: string; size: number }): { valid: boolean; error?: string } {
  const allowedMimes = [
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
    "video/mp4",
    "video/webm",
    "video/quicktime",
    "audio/mpeg",
    "audio/wav",
    "audio/ogg",
    "audio/mp3",
    "text/plain",
    "application/json",
  ];

  const maxSizeBytes = 250 * 1024 * 1024; // 250 MB

  if (!allowedMimes.includes(file.mimetype)) {
    return { valid: false, error: `Tipo de arquivo não permitido: ${file.mimetype}` };
  }

  if (file.size > maxSizeBytes) {
    return { valid: false, error: `Arquivo muito grande. Limite máximo: 250 MB.` };
  }

  return { valid: true };
}
