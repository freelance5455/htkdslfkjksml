import crypto from 'node:crypto';

const EPHEMERAL_SESSION_SECRET = crypto.randomBytes(32).toString('hex');
const EPHEMERAL_WEBHOOK_SECRET = crypto.randomBytes(32).toString('hex');

export function getSessionSecret(): string {
  return process.env.SESSION_SECRET || EPHEMERAL_SESSION_SECRET;
}

export function getWebhookSecret(): string {
  return process.env.RAZORPAY_WEBHOOK_SECRET || EPHEMERAL_WEBHOOK_SECRET;
}

export function getPaymentMode(): 'upi_direct' | 'razorpay' {
  const hasLiveKeys = Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
  if (process.env.PAYMENT_MODE === 'razorpay' && hasLiveKeys) {
    return 'razorpay';
  }
  return 'upi_direct';
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) return false;
  try {
    const keyBuf = Buffer.from(keyHex, 'hex');
    const derivedBuf = crypto.scryptSync(password, salt, 64);
    if (keyBuf.length !== derivedBuf.length) return false;
    return crypto.timingSafeEqual(keyBuf, derivedBuf);
  } catch {
    return false;
  }
}

export interface SessionPayload {
  id: number;
  email: string;
  name: string;
  accountType: 'customer' | 'admin';
  role: string;
  exp: number;
}

export function signSessionToken(payload: Omit<SessionPayload, 'exp'>): string {
  const fullPayload: SessionPayload = {
    ...payload,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7, // 7 days
  };
  const encoded = Buffer.from(JSON.stringify(fullPayload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 2) return null;
    const [encoded, sig] = parts;
    if (!encoded || !sig) return null;

    const expectedSig = crypto
      .createHmac('sha256', getSessionSecret())
      .update(encoded)
      .digest('base64url');

    const sigBuf = Buffer.from(sig, 'utf8');
    const expectedBuf = Buffer.from(expectedSig, 'utf8');
    if (sigBuf.length !== expectedBuf.length) return null;
    if (!crypto.timingSafeEqual(sigBuf, expectedBuf)) return null;

    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!parsed || typeof parsed.exp !== 'number' || parsed.exp < Date.now()) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function signWebhookPayload(rawPayload: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(rawPayload).digest('hex');
}

export function verifyWebhookSignature(rawPayload: string | Buffer, signature: string, secret: string): boolean {
  if (!signature || !secret) return false;
  try {
    const expected = crypto.createHmac('sha256', secret).update(rawPayload).digest('hex');
    const sigBuf = Buffer.from(signature, 'utf8');
    const expBuf = Buffer.from(expected, 'utf8');
    if (sigBuf.length !== expBuf.length) return false;
    return crypto.timingSafeEqual(sigBuf, expBuf);
  } catch {
    return false;
  }
}

export function calculateServerPricePaise(
  selectedQuantity: number,
  referenceQuantity: number,
  referencePricePaise: number,
): number {
  if (!Number.isFinite(selectedQuantity) || selectedQuantity <= 0) {
    throw new Error('Quantity must be a positive number.');
  }
  if (!Number.isFinite(referenceQuantity) || referenceQuantity <= 0) {
    throw new Error('Invalid reference quantity.');
  }
  const rawPaise = (selectedQuantity / referenceQuantity) * referencePricePaise;
  return Math.max(100, Math.round(rawPaise)); // Minimum ₹1.00 (100 paise)
}

export function validateCampaignUrl(rawUrl: string): { valid: boolean; normalized?: string; error?: string } {
  const trimmed = rawUrl.trim();
  if (!trimmed || trimmed.length > 500) {
    return { valid: false, error: 'Please enter a valid campaign or post URL.' };
  }
  try {
    const parsed = new URL(trimmed.startsWith('http://') || trimmed.startsWith('https://') ? trimmed : `https://${trimmed}`);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return { valid: false, error: 'URL must use http or https protocol.' };
    }
    if (!parsed.hostname.includes('.')) {
      return { valid: false, error: 'Please enter a complete domain URL (e.g. https://instagram.com/p/...).' };
    }
    return { valid: true, normalized: parsed.toString() };
  } catch {
    return { valid: false, error: 'Invalid URL format. Example: https://www.instagram.com/p/C9xExample/' };
  }
}

export function sanitizeText(value: unknown, maxLen = 300): string {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, maxLen);
}

export function generateCode(prefix: string): string {
  const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randPart = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `${prefix}-${datePart}-${randPart}`;
}
