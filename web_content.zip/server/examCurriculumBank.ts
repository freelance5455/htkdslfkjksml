import { ExamMCQ } from './examQuestionStore.js';

// Comprehensive subject topic taxonomies for Indian Competitive Exams (UPSC, WBCS, RRB NTPC, SSC CGL/CHSL, Police, State PSCs)
export interface SubjectTopicTaxonomy {
  subjectEn: string;
  subjectBn: string;
  subTopics: {
    nameEn: string;
    nameBn: string;
    keyConcepts: string[];
  }[];
}

export const SUBJECT_TAXONOMY: Record<string, SubjectTopicTaxonomy> = {
  Geography: {
    subjectEn: "Geography",
    subjectBn: "ভূগোল",
    subTopics: [
      {
        nameEn: "Solar System, Earth's Movement & Coordinates",
        nameBn: "সৌরজগৎ, পৃথিবীর গতি, অক্ষরেখা ও দ্রাঘিমারেখা",
        keyConcepts: ["International Date Line", "Equinox & Solstice", "Planets & Satellites", "Earth's Rotation & Revolution"]
      },
      {
        nameEn: "Lithosphere, Geomorphology & Landforms",
        nameBn: "অশ্মমণ্ডল, ভূমিরূপ প্রক্রিয়া, ভূমিকম্প ও আগ্নেয়গিরি",
        keyConcepts: ["Plate Tectonics", "Fold & Block Mountains", "Earthquake Epicenter & Waves", "Rock Types & Weathering"]
      },
      {
        nameEn: "Atmosphere, Pressure Belts & Cyclones",
        nameBn: "বায়ুমণ্ডল, বায়ুচাপ বলয়, বায়ুপ্রবাহ ও ঘূর্ণিঝড়",
        keyConcepts: ["Troposphere to Exosphere", "Planetary Winds", "Tropical & Temperate Cyclones", "Jet Streams"]
      },
      {
        nameEn: "Hydrosphere, Ocean Currents & Tides",
        nameBn: "বারিমণ্ডল, সমুদ্রস্রোত ও জোয়ার-ভাটা",
        keyConcepts: ["Gulf Stream & Kuroshio", "Spring & Neap Tides", "Ocean Trenches & Ridges", "Salinity & Density"]
      },
      {
        nameEn: "Physiography of India & Northern Mountains",
        nameBn: "ভারতের ভূপ্রকৃতি, হিমালয় পর্বতমালা ও উত্তর ভারতীয় সমভূমি",
        keyConcepts: ["Greater & Lesser Himalayas", "Mountain Passes (Zoji La, Nathu La)", "Deccan Plateau", "Coastal Plains & Ghats"]
      },
      {
        nameEn: "Drainage System & Major Rivers of India",
        nameBn: "ভারতের নদ-নদী ব্যবস্থা, হ্রদ ও জলপ্রপাত",
        keyConcepts: ["Ganga, Brahmaputra & Indus Systems", "Peninsular Rivers (Godavari, Krishna, Narmada)", "Chilika, Sambhar & Wular Lakes", "Jog & Dhuandhar Waterfalls"]
      },
      {
        nameEn: "Climate of India & Monsoon Mechanisms",
        nameBn: "ভারতের জলবায়ু, মৌসুমি বায়ু ও বৃষ্টিপাত",
        keyConcepts: ["South-West & North-East Monsoon", "El Nino & La Nina", "Western Disturbances", "Rainfall Distribution"]
      },
      {
        nameEn: "Soils of India & Natural Vegetation",
        nameBn: "ভারতের মৃত্তিকা ও স্বাভাবিক উদ্ভিদ / অরণ্য সম্পদ",
        keyConcepts: ["Alluvial, Black (Regur), Red & Laterite Soils", "Tropical Evergreen & Deciduous Forests", "Mangrove of Sundarbans", "Soil Conservation"]
      },
      {
        nameEn: "Indian Agriculture, Crops & Irrigation",
        nameBn: "ভারতের কৃষি, প্রধান ফসল ও বহুমুখী সেচ প্রকল্প",
        keyConcepts: ["Kharif, Rabi & Zaid Crops", "Green Revolution", "Damodar Valley, Bhakra Nangal & Hirakud Dams", "Cash Crops (Tea, Jute, Cotton)"]
      },
      {
        nameEn: "Mineral Resources, Energy & Power Plants",
        nameBn: "ভারতের খনিজ সম্পদ, শক্তি সম্পদ ও তাপ/পারমাণবিক বিদ্যুৎ কেন্দ্র",
        keyConcepts: ["Coal Belts (Jharia, Raniganj)", "Iron Ore (Mayurbhanj, Kudremukh)", "Petroleum (Digboi, Mumbai High)", "Nuclear Plants (Kudankulam, Tarapur)"]
      },
      {
        nameEn: "Indian Industries, Transport & Ports",
        nameBn: "ভারতের শিল্প, রেলপথ, জাতীয় সড়ক ও সমুদ্রবন্দর",
        keyConcepts: ["Iron & Steel (Bhilai, Rourkela)", "Golden Quadrilateral", "Major Ports (Kandla, Paradip, Haldia)", "Inland Waterways (NW-1)"]
      },
      {
        nameEn: "Geography of West Bengal & Indian States",
        nameBn: "পশ্চিমবঙ্গের ভূগোল ও ভারতীয় রাজ্যসমূহের বিশিষ্ট ভূগোল",
        keyConcepts: ["Darjeeling Hills & Sandakphu", "Rarh Region & Terai-Dooars", "Sundarban Delta", "State Boundaries & Demographics"]
      }
    ]
  },
  History: {
    subjectEn: "History",
    subjectBn: "ইতিহাস",
    subTopics: [
      {
        nameEn: "Indus Valley Civilization & Prehistory",
        nameBn: "সিন্ধু সভ্যতা, হরপ্পা-মহেঞ্জোদারো ও প্রাগৈতিহাসিক ভারত",
        keyConcepts: ["Harappa, Mohenjodaro, Lothal, Dholavira", "Great Bath & Granary", "Town Planning & Seals"]
      },
      {
        nameEn: "Vedic Period, Literature & Early Society",
        nameBn: "বৈদিক যুগ, বেদ ও উপনিষদ এবং সমাজ ব্যবস্থা",
        keyConcepts: ["Rigveda, Samaveda, Yajurveda, Atharvaveda", "Sabha & Samiti", "Varna & Ashram System"]
      },
      {
        nameEn: "Buddhism, Jainism & 16 Mahajanapadas",
        nameBn: "বৌদ্ধ ও জৈন ধর্ম এবং ১৬টি মহাজনপদ",
        keyConcepts: ["Gautama Buddha & Eightfold Path", "Vardhamana Mahavira & Triratna", "Magadha & Bimbisara"]
      },
      {
        nameEn: "Maurya Empire & Ashoka's Dhamma",
        nameBn: "মৌর্য সাম্রাজ্য, চন্দ্রগুপ্ত মৌর্য, কৌটিল্য ও অশোকের ধম্ম",
        keyConcepts: ["Chandragupta Maurya & Megasthenes", "Arthashastra", "Kalinga War & Edicts of Ashoka"]
      },
      {
        nameEn: "Gupta Golden Age, Harsha & Post-Gupta Period",
        nameBn: "গুপ্ত স্বর্ণযুগ, সমুদ্রগুপ্ত, দ্বিতীয় চন্দ্রগুপ্ত ও হর্ষবর্ধন",
        keyConcepts: ["Samudragupta & Allahabad Pillar", "Aryabhata, Kalidasa, Varahamihira", "Nalanda University & Hiuen Tsang"]
      },
      {
        nameEn: "Delhi Sultanate: Slave, Khilji, Tughlaq & Lodi Dynasties",
        nameBn: "দিল্লি সালতানাত: দাস, খলজি, তুঘলক ও লোদি বংশ",
        keyConcepts: ["Qutb-ud-din Aibak & Iltutmish", "Alauddin Khilji's Market Reforms", "Muhammad bin Tughlaq's Projects"]
      },
      {
        nameEn: "Mughal Empire: Babur to Aurangzeb & Mansabdari System",
        nameBn: "মুঘল সাম্রাজ্য: বাবর থেকে ঔরঙ্গজেব এবং মনসবদারি ব্যবস্থা",
        keyConcepts: ["First & Second Battle of Panipat", "Akbar's Din-i-Ilahi & Navratnas", "Shah Jahan's Architecture & Taj Mahal"]
      },
      {
        nameEn: "Vijayanagara, Bahmani, Marathas & Shivaji",
        nameBn: "বিজয়নগর, বাহমনি সাম্রাজ্য, মারাঠা শক্তি ও ছত্রপতি শিবাজী",
        keyConcepts: ["Krishnadevaraya & Ashtadiggajas", "Shivaji's Ashtapradhan & Chauth-Sardeshmukhi", "Battle of Talikota"]
      },
      {
        nameEn: "Advent of Europeans, Battle of Plassey & Buxar",
        nameBn: "ভারতে ইউরোপীয়দের আগমন, পলাশী ও বক্সারের যুদ্ধ",
        keyConcepts: ["Portuguese, Dutch, French & British East India Co.", "Battle of Plassey (1757)", "Battle of Buxar & Treaty of Allahabad (1765)"]
      },
      {
        nameEn: "British Colonial Policies & 1857 Great Revolt",
        nameBn: "ব্রিটিশ ভূমি রাজস্ব নীতি ও ১৮৫৭ সালের মহাবিদ্রোহ",
        keyConcepts: ["Permanent Settlement & Doctrine of Lapse", "Mangal Pandey & Meerut Uprising", "Rani Lakshmibai, Bahadur Shah Zafar"]
      },
      {
        nameEn: "Indian National Congress & Socio-Religious Reforms",
        nameBn: "জাতীয় কংগ্রেস প্রতিষ্ঠা ও ১৯ শতকের সমাজ সংস্কার আন্দোলন",
        keyConcepts: ["Raja Ram Mohan Roy & Brahmo Samaj", "Swami Vivekananda & Ramakrishna Mission", "A.O. Hume & INC Foundation (1885)"]
      },
      {
        nameEn: "Swadeshi, Gandhian Movements & Freedom Struggle",
        nameBn: "স্বদেশী আন্দোলন, গান্ধীজির গণআন্দোলন ও ভারতীয় স্বাধীনতা",
        keyConcepts: ["Partition of Bengal (1905)", "Non-Cooperation, Civil Disobedience & Quit India", "Netaji & INA, Mountbatten Plan (1947)"]
      }
    ]
  },
  "Indian Polity": {
    subjectEn: "Indian Polity",
    subjectBn: "ভারতীয় সংবিধান ও শাসনব্যবস্থা",
    subTopics: [
      {
        nameEn: "Constituent Assembly & Framing of Constitution",
        nameBn: "গণপরিষদ ও ভারতীয় সংবিধান রচনা",
        keyConcepts: ["Dr. B.R. Ambedkar & Drafting Committee", "26 November 1949 & 26 January 1950", "Sources Borrowed from World Constitutions"]
      },
      {
        nameEn: "Preamble, Union & Territory, Citizenship",
        nameBn: "প্রস্তাবনা, ভারতীয় ভূখণ্ড ও নাগরিকত্ব",
        keyConcepts: ["Sovereign Socialist Secular Democratic Republic", "Articles 1 to 4", "Citizenship Articles 5 to 11"]
      },
      {
        nameEn: "Fundamental Rights (Articles 12 to 35)",
        nameBn: "মৌলিক অধিকার (১২ থেকে ৩৫ নম্বর ধারা)",
        keyConcepts: ["Right to Equality (14-18)", "Right to Freedom (19-22)", "Right to Constitutional Remedies & Writs (Art 32)"]
      },
      {
        nameEn: "Directive Principles & Fundamental Duties",
        nameBn: "রাষ্ট্র পরিচালনার নির্দেশমূলক নীতি (DPSP) ও মৌলিক কর্তব্য",
        keyConcepts: ["Articles 36 to 51 (Part IV)", "Article 51A & 42nd Amendment (1976)", "Swaran Singh Committee"]
      },
      {
        nameEn: "President, Vice-President & Union Executive",
        nameBn: "ভারতের রাষ্ট্রপতি, উপ-রাষ্ট্রপতি ও কেন্দ্রীয় মন্ত্রিসভা",
        keyConcepts: ["Election & Impeachment of President (Art 52-62)", "Pardoning Power (Art 72) & Ordinance (Art 123)", "Prime Minister & Council of Ministers"]
      },
      {
        nameEn: "Indian Parliament (Lok Sabha & Rajya Sabha)",
        nameBn: "ভারতীয় সংসদ (লোকসভা ও রাজ্যসভা) এবং আইন প্রণয়ন",
        keyConcepts: ["Speaker of Lok Sabha", "Money Bill (Art 110) & Joint Sitting (Art 108)", "Parliamentary Committees (PAC, Estimates)"]
      },
      {
        nameEn: "Supreme Court, High Courts & Subordinate Judiciary",
        nameBn: "সুপ্রিম কোর্ট, হাইকোর্ট ও বিচারবিভাগীয় পর্যালোচনা",
        keyConcepts: ["Original, Appellate & Advisory Jurisdiction (Art 143)", "Judicial Review", "Appointment & Tenure of Judges"]
      },
      {
        nameEn: "Governor, Chief Minister & State Legislature",
        nameBn: "রাজ্যপাল, মুখ্যমন্ত্রী ও রাজ্য বিধানসভা / পরিষদ",
        keyConcepts: ["Governor's Powers (Art 153-161)", "State Legislative Assembly & Council", "Discretionary Powers"]
      },
      {
        nameEn: "Panchayati Raj & Urban Local Bodies",
        nameBn: "পঞ্চায়েতি রাজ ব্যবস্থা ও পৌর প্রশাসন",
        keyConcepts: ["73rd & 74th Constitutional Amendment Acts (1992)", "Balwant Rai Mehta Committee", "3-Tier System (Gram, Panchayat Samiti, Zilla Parishad)"]
      },
      {
        nameEn: "Constitutional & Non-Constitutional Bodies",
        nameBn: "সাংবিধানিক ও অ-সাংবিধানিক সংস্থাসমূহ",
        keyConcepts: ["Election Commission of India (Art 324)", "CAG (Art 148), UPSC (Art 315), Finance Commission (Art 280)", "NITI Aayog & NHRC"]
      },
      {
        nameEn: "Emergency Provisions & Constitutional Amendments",
        nameBn: "জরুরি অবস্থা (ধারা ৩৫২, ৩৫৬, ৩৬০) ও সংবিধান সংশোধন (ধারা ৩৬৮)",
        keyConcepts: ["National Emergency (Art 352)", "President's Rule (Art 356)", "Financial Emergency (Art 360)", "Major Amendments (42nd, 44th, 86th, 101st GST)"]
      }
    ]
  },
  "General Science": {
    subjectEn: "General Science",
    subjectBn: "সাধারণ বিজ্ঞান",
    subTopics: [
      {
        nameEn: "Physics: Units, Motion, Gravitation & Work-Energy",
        nameBn: "পদার্থবিদ্যা: একক ও পরিমাপ, গতিবিদ্যা, মহাকর্ষ ও কার্য-ক্ষমতা-শক্তি",
        keyConcepts: ["Newton's Laws of Motion", "Universal Gravitation (G vs g)", "Kinetic & Potential Energy", "Friction & Momentum"]
      },
      {
        nameEn: "Physics: Light, Optics, Sound & Waves",
        nameBn: "পদার্থবিদ্যা: আলো, প্রতিফলন-প্রতিসরণ, লেন্স, শব্দ ও তরঙ্গ",
        keyConcepts: ["Total Internal Reflection & Mirage", "Convex/Concave Mirror & Lenses", "Speed of Sound in Media", "Electromagnetic Spectrum"]
      },
      {
        nameEn: "Physics: Electricity, Magnetism & Nuclear Physics",
        nameBn: "পদার্থবিদ্যা: বিদ্যুৎ, চুম্বকত্ব ও পারমাণবিক পদার্থবিদ্যা",
        keyConcepts: ["Ohm's Law, Resistance & Power", "Electromagnetic Induction & Fleming's Rules", "Radioactivity (Alpha, Beta, Gamma)", "Nuclear Fission & Fusion"]
      },
      {
        nameEn: "Chemistry: Matter, Atomic Structure & Periodic Table",
        nameBn: "রসায়ন: পদার্থের অবস্থা, পরমাণুর গঠন ও পর্যায় সারণি",
        keyConcepts: ["Proton, Neutron, Electron & Isotopes", "Mendeleev & Modern Periodic Law", "Valency & Chemical Bonding", "Avogadro's Number"]
      },
      {
        nameEn: "Chemistry: Acids, Bases, Salts & Metals/Non-Metals",
        nameBn: "রসায়ন: অ্যাসিড, ক্ষার, লবণ, ধাতু ও অধাতু",
        keyConcepts: ["pH Scale & Indicators", "Baking Soda, Bleaching Powder, Plaster of Paris", "Reactivity Series & Corrosion", "Alloys (Brass, Bronze, Stainless Steel)"]
      },
      {
        nameEn: "Chemistry: Organic Chemistry, Fuels & Daily Chemistry",
        nameBn: "রসায়ন: জৈব রসায়ন, জ্বালানি ও দৈনন্দিন জীবনের রসায়ন",
        keyConcepts: ["Hydrocarbons (Methane, Ethylene)", "LPG, CNG & Bio-gas", "Soaps & Detergents", "Polymers & Fertilizers"]
      },
      {
        nameEn: "Biology: Cell Biology, Genetics & Plant Physiology",
        nameBn: "জীববিদ্যা: কোষ ও কোষীয় অঙ্গাণু, বংশগতি ও উদ্ভিদ শারীরবিদ্যা",
        keyConcepts: ["Mitochondria, Nucleus & Ribosomes", "Mitosis & Meiosis", "Photosynthesis & Transpiration", "Plant Hormones (Auxin, Gibberellin)"]
      },
      {
        nameEn: "Biology: Human Digestive, Circulatory & Respiratory Systems",
        nameBn: "জীববিদ্যা: মানবদেহের পরিপাকতন্ত্র, রক্ত সংবহনতন্ত্র ও শ্বসনতন্ত্র",
        keyConcepts: ["Enzymes (Pepsin, Amylase, Lipase)", "Blood Groups (ABO & Rh), Hemoglobin & Heart Chambers", "Lungs & Alveoli Gas Exchange"]
      },
      {
        nameEn: "Biology: Nervous System, Endocrine Glands & Excretion",
        nameBn: "জীববিদ্যা: স্নায়ুতন্ত্র, অন্তক্ষরা গ্রন্থি, হরমোন ও রেচনতন্ত্র",
        keyConcepts: ["Brain Parts (Cerebrum, Cerebellum, Medulla)", "Thyroid, Pituitary, Insulin & Adrenaline", "Kidney, Nephron & Dialysis"]
      },
      {
        nameEn: "Biology: Vitamins, Deficiency Diseases & Microorganisms",
        nameBn: "জীববিদ্যা: ভিটামিন, পুষ্টি, অভাবজনিত রোগ ও জীবাণু",
        keyConcepts: ["Fat vs Water Soluble Vitamins (A, B, C, D, E, K)", "Bacterial vs Viral vs Protozoan Diseases", "Vaccination & Antibodies"]
      },
      {
        nameEn: "Ecology, Biodiversity & Environmental Pollution",
        nameBn: "বাস্তুতন্ত্র, জীববৈচিত্র্য ও পরিবেশ দূষণ",
        keyConcepts: ["Food Chain & Trophic Levels", "Greenhouse Gases & Global Warming", "Acid Rain & Ozone Layer Depletion", "National Parks & Biosphere Reserves"]
      }
    ]
  },
  Mathematics: {
    subjectEn: "Mathematics",
    subjectBn: "গণিত ও পাটিগণিত",
    subTopics: [
      {
        nameEn: "Number System, Divisibility & Surds",
        nameBn: "সংখ্যা তত্ত্ব, বিভাজ্যতা, লসাগু-গসাগু ও করণী",
        keyConcepts: ["HCF and LCM", "Divisibility Rules", "Rational & Irrational Numbers", "BODMAS & Simplification"]
      },
      {
        nameEn: "Percentages, Fractions & Decimals",
        nameBn: "শতকরা, ভগ্নাংশ ও দশমিক",
        keyConcepts: ["Percentage Increase & Decrease", "Fraction-Percentage Equivalence", "Successive Percentage Changes"]
      },
      {
        nameEn: "Ratio, Proportion, Partnership & Mixtures",
        nameBn: "অনুপাত-সমানুপাত, অংশীদারি কারবার ও মিশ্রণ",
        keyConcepts: ["Direct & Inverse Proportions", "Profit Distribution in Partnership", "Alligation & Mixture Rule"]
      },
      {
        nameEn: "Profit, Loss, Discount & Market Price",
        nameBn: "লাভ-ক্ষতি, ধার্যমূল্য ও ছাড়",
        keyConcepts: ["Cost Price & Selling Price", "Marked Price & Successive Discounts", "Dishonest Dealer Problems"]
      },
      {
        nameEn: "Simple & Compound Interest",
        nameBn: "সরল সুদ ও চক্রবৃদ্ধি সুদ",
        keyConcepts: ["SI Formula (PRT/100)", "CI Annual & Semi-Annual Compounding", "Difference between CI and SI"]
      },
      {
        nameEn: "Time, Work, Pipes & Cisterns",
        nameBn: "সময় ও কার্য, নল ও চৌবাচ্চা",
        keyConcepts: ["Efficiency & Work Rate", "Alternating Days Work", "Inlet & Outlet Pipes filling rate"]
      },
      {
        nameEn: "Time, Speed, Distance, Trains & Boats",
        nameBn: "সময়, গতিবেগ ও দূরত্ব, ট্রেন ও নৌকা-স্রোত",
        keyConcepts: ["Relative Speed", "Train crossing pole vs platform", "Upstream and Downstream Speed"]
      },
      {
        nameEn: "Averages, Ages & Mean-Median",
        nameBn: "গড়, বয়স সংক্রান্ত সমস্যা ও পরিসংখ্যান",
        keyConcepts: ["Weighted Average", "Problems on Ages", "Mean, Median and Mode"]
      },
      {
        nameEn: "Mensuration 2D (Area & Perimeter)",
        nameBn: "দ্বিমাত্রিক পরিমিতি: ত্রিভুজ, চতুর্ভুজ ও বৃত্তের ক্ষেত্রফল",
        keyConcepts: ["Right Triangle & Pythagoras", "Rectangle, Square & Trapezium", "Circle Circumference & Area"]
      },
      {
        nameEn: "Mensuration 3D (Volume & Surface Area)",
        nameBn: "ত্রিমাত্রিক পরিমিতি: ঘনক, চোঙ, শঙ্কু ও গোলক",
        keyConcepts: ["Cube & Cuboid Volume", "Cylinder & Cone Surface Area", "Sphere & Hemisphere Volume"]
      },
      {
        nameEn: "Algebra, Equations & Trigonometry Basics",
        nameBn: "বীজগণিত, দ্বিঘাত সমীকরণ ও ত্রিকোণমিতি",
        keyConcepts: ["Algebraic Identities (a+b)^2 etc.", "Linear & Quadratic Equations", "Sin, Cos, Tan Standard Angles", "Heights and Distances"]
      }
    ]
  },
  Reasoning: {
    subjectEn: "Reasoning",
    subjectBn: "জিআই ও যৌক্তিক রিজনিং",
    subTopics: [
      {
        nameEn: "Analogy, Classification & Odd One Out",
        nameBn: "সাদৃশ্য, শ্রেণীকরণ ও বেমানান নির্বাচন",
        keyConcepts: ["Word Analogy", "Number Classification", "Letter Patterns"]
      },
      {
        nameEn: "Coding-Decoding & Alphabet Series",
        nameBn: "কোডিং-ডিকোডিং ও বর্ণমালা সিরিজ",
        keyConcepts: ["Letter Shifting Code", "Symbol & Number Substitution", "Opposite Letters (A-Z, B-Y)"]
      },
      {
        nameEn: "Number Series & Missing Term Analysis",
        nameBn: "সংখ্যা শ্রেণি ও লুপ্ত সংখ্যা নির্ণয়",
        keyConcepts: ["Difference Series & Squares/Cubes", "Alternating Series", "Matrix Missing Numbers"]
      },
      {
        nameEn: "Blood Relations & Family Tree",
        nameBn: "রক্তের সম্পর্ক ও পারিবারিক চিত্র",
        keyConcepts: ["Paternal & Maternal Relations", "Coded Blood Relations", "Pointing to a Photograph Questions"]
      },
      {
        nameEn: "Direction Sense & Distance Test",
        nameBn: "দিকনির্ণয় ও দূরত্বের সমস্যা",
        keyConcepts: ["8 Cardinal Directions", "Shadows at Sunrise/Sunset", "Pythagoras Distance Calculation"]
      },
      {
        nameEn: "Order, Ranking & Seating Arrangement",
        nameBn: "ক্রমবিন্যাস, র্যাংকিং ও বসার বিন্যাস",
        keyConcepts: ["Linear & Circular Seating", "Left-Right Ranking Formula", "Floor Based Puzzle Basics"]
      },
      {
        nameEn: "Syllogism & Logical Venn Diagrams",
        nameBn: "সিলজিজম ও ভেনচিত্র",
        keyConcepts: ["All, Some, No Statements", "Intersection of Sets", "Logical Conclusion Validity"]
      },
      {
        nameEn: "Clock, Calendar & Time Logic",
        nameBn: "ঘড়ি ও ক্যালেন্ডার সংক্রান্ত সমস্যা",
        keyConcepts: ["Angle between Hour & Minute Hands", "Leap Year & Odd Days Concept", "Day on Specific Date"]
      },
      {
        nameEn: "Non-Verbal Reasoning (Cubes, Dice, Mirror Images)",
        nameBn: "চিত্রভিত্তিক রিজনিং (ঘনক, ছক্কা, দর্পণ ও জলছবি)",
        keyConcepts: ["Opposite Faces of Dice", "Mirror & Water Reflection", "Paper Folding & Cutting", "Embedded Figures"]
      }
    ]
  }
};

// Return topics for a requested subject
export function getSubjectTaxonomy(subjectName: string): SubjectTopicTaxonomy {
  const norm = (subjectName || '').toLowerCase().trim();
  for (const [key, val] of Object.entries(SUBJECT_TAXONOMY)) {
    if (key.toLowerCase() === norm || val.subjectBn.toLowerCase() === norm || norm.includes(key.toLowerCase())) {
      return val;
    }
  }

  // Alias maps
  if (norm.includes('geograph') || norm.includes('ভূগোল')) return SUBJECT_TAXONOMY.Geography;
  if (norm.includes('histor') || norm.includes('ইতিহাস')) return SUBJECT_TAXONOMY.History;
  if (norm.includes('polity') || norm.includes('সংবিধান') || norm.includes('রাষ্ট্র')) return SUBJECT_TAXONOMY["Indian Polity"];
  if (norm.includes('sci') || norm.includes('বিজ্ঞান') || norm.includes('physic') || norm.includes('chem') || norm.includes('bio')) return SUBJECT_TAXONOMY["General Science"];
  if (norm.includes('math') || norm.includes('গণিত') || norm.includes('অঙ্ক')) return SUBJECT_TAXONOMY.Mathematics;
  if (norm.includes('reason') || norm.includes('রিজনিং') || norm.includes('জিআই') || norm.includes('logic')) return SUBJECT_TAXONOMY.Reasoning;

  // Default fallback to Geography/GK
  return SUBJECT_TAXONOMY.Geography;
}
