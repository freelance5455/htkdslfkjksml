'use strict';
/* گاوصندوق کلیدهای API — رمزنگاری‌شده با AES-256-GCM روی دیسک سرور.
   کلیدها هرگز به کلاینت برنمی‌گردند (فقط نسخهٔ ماسک‌شده برای مدیر). */
const crypto = require('crypto');
const fsp = require('fs/promises');
const path = require('path');

const MASK = '••••';
const clean = (s, n) => String(s == null ? '' : s).trim().slice(0, n);

class Vault {
  constructor(dir, secret) {
    this.file = path.join(dir, 'vault.json');
    this.key = secret ? crypto.scryptSync(String(secret), 'tradyar-vault-v1', 32) : null;
    this.items = [];
  }
  get enabled() { return !!this.key; }

  async init() {
    if (!this.key) return;
    let raw;
    try { raw = await fsp.readFile(this.file, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return; throw e; }
    const t = JSON.parse(raw);
    const d = crypto.createDecipheriv('aes-256-gcm', this.key, Buffer.from(t.iv, 'base64'));
    d.setAuthTag(Buffer.from(t.tag, 'base64'));
    const pt = Buffer.concat([d.update(Buffer.from(t.ct, 'base64')), d.final()]).toString('utf8');
    this.items = JSON.parse(pt);
  }

  async save() {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', this.key, iv);
    const ct = Buffer.concat([c.update(JSON.stringify(this.items), 'utf8'), c.final()]);
    const out = JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), ct: ct.toString('base64') });
    const tmp = this.file + '.tmp';
    await fsp.writeFile(tmp, out, { mode: 0o600 });
    await fsp.rename(tmp, this.file);
  }

  masked() {
    return this.items.map((p) => ({ ...p, key: p.key ? MASK + p.key.slice(-4) : '' }));
  }

  /* جایگزینی فهرست؛ کلیدِ خالی/ماسک‌شده = نگه‌داشتن کلید قبلیِ همان id */
  async replace(list) {
    if (!Array.isArray(list) || list.length > 30) throw Object.assign(new Error('bad_list'), { status: 400 });
    const old = new Map(this.items.map((p) => [p.id, p]));
    const next = [];
    for (const p of list) {
      if (!p || typeof p !== 'object') continue;
      const id = clean(p.id, 64) || crypto.randomUUID();
      let key = clean(p.key, 600);
      if (!key || key.startsWith(MASK)) key = (old.get(id) || {}).key || '';
      const kind = ['openai', 'anthropic', 'gemini'].includes(p.kind) ? p.kind : 'openai';
      next.push({
        id, name: clean(p.name, 80) || 'AI', preset: clean(p.preset, 40), kind,
        base: clean(p.base, 300).replace(/\/+$/, ''), model: clean(p.model, 120),
        key, enabled: p.enabled !== false, shared: p.shared !== false,
      });
    }
    this.items = next;
    await this.save();
  }
}

module.exports = { Vault, MASK };
