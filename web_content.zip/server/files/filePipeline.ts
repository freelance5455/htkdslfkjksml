export const supportedFileTypes = [
  "image/*",".pdf",".doc",".docx",".txt",".md",".csv",".json",
  ".zip",".py",".js",".ts",".tsx",".kt"
];

export function classifyFile(name: string): string {
  const n = name.toLowerCase();
  if (n.endsWith(".pdf")) return "PDF";
  if (/\.(png|jpg|jpeg|webp|gif)$/.test(n)) return "IMAGE";
  if (/\.(doc|docx|txt|md)$/.test(n)) return "DOCUMENT";
  if (/\.(csv|json)$/.test(n)) return "DATA";
  return "CODE_OR_PROJECT";
}
