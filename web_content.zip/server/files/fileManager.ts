/**
 * JARVIS Universal File Management System
 * 
 * Provides secure file persistence, validation, extraction, and project/chat association:
 * - Sanitized storage in data/uploads/
 * - Path traversal defense & size boundaries (max 25MB)
 * - Automatic MIME and category classification
 * - Automatic PDF text extraction via pdfEngine
 * - Automatic text/code inspection
 * - Persistent metadata storage in SQLite/PostgreSQL
 */

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

import { db } from '../db/database.ts';
import type { FileAttachmentEntity } from '../types.ts';
import { pdfEngine } from './pdfEngine.ts';

export interface UploadFileInput {
  originalName: string;
  mimeType: string;
  buffer: Buffer;
  conversationId?: string;
  projectId?: string;
  userId?: string;
}

export class FileManager {
  private uploadsDir: string;
  private static readonly MAX_FILE_SIZE = 25 * 1024 * 1024; // 25 MB

  constructor() {
    this.uploadsDir = path.resolve(process.cwd(), 'data', 'uploads');
    if (!fs.existsSync(this.uploadsDir)) {
      fs.mkdirSync(this.uploadsDir, { recursive: true });
    }
  }

  /**
   * Determine file category from MIME type or filename extension
   */
  public categorizeFile(mimeType: string, filename: string): FileAttachmentEntity['fileCategory'] {
    const ext = path.extname(filename).toLowerCase();

    if (mimeType === 'application/pdf' || ext === '.pdf') {
      return 'pdf';
    }
    if (
      ['.txt', '.md', '.markdown', '.rst', '.csv', '.tsv'].includes(ext) ||
      mimeType.startsWith('text/')
    ) {
      return 'text';
    }
    if (
      ['.ts', '.tsx', '.js', '.jsx', '.py', '.java', '.cpp', '.c', '.go', '.rs', '.json', '.html', '.css'].includes(ext) ||
      mimeType === 'application/json' ||
      mimeType.includes('javascript') ||
      mimeType.includes('typescript')
    ) {
      return 'code';
    }
    if (
      ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp'].includes(ext) ||
      mimeType.startsWith('image/')
    ) {
      return 'image';
    }
    if (['.doc', '.docx', '.odt', '.rtf'].includes(ext)) {
      return 'document';
    }
    return 'other';
  }

  /**
   * Save, validate, extract, and index an uploaded file
   */
  public async uploadFile(input: UploadFileInput): Promise<FileAttachmentEntity> {
    const { originalName, mimeType, buffer, conversationId, projectId, userId = 'usr_jarvis_prime' } = input;

    if (buffer.length > FileManager.MAX_FILE_SIZE) {
      throw new Error(`File size ${Math.round(buffer.length / 1024 / 1024)}MB exceeds the maximum allowed limit of 25MB.`);
    }

    // Sanitize filename to prevent directory traversal
    const safeBase = path.basename(originalName).replace(/[^a-zA-Z0-9._-]/g, '_');
    const fileId = `file_${crypto.randomUUID()}`;
    const storageFilename = `${fileId}_${safeBase}`;
    const storagePath = path.join(this.uploadsDir, storageFilename);

    // Write file to disk
    await fs.promises.writeFile(storagePath, buffer);

    const fileCategory = this.categorizeFile(mimeType, safeBase);
    let textContent: string | undefined;
    let summary: string | undefined;
    let isExtracted = false;
    let extractionStatus: FileAttachmentEntity['extractionStatus'] = 'EMPTY';
    let extractionNote: string | undefined;

    // Perform content extraction based on file category
    if (fileCategory === 'pdf') {
      const pdfResult = await pdfEngine.extractText(buffer);
      textContent = pdfResult.extractedText;
      summary = pdfResult.summary;
      isExtracted = pdfResult.extractionStatus === 'EXTRACTED';
      extractionStatus = pdfResult.extractionStatus;
      extractionNote = pdfResult.extractionNote;
    } else if (fileCategory === 'text' || fileCategory === 'code') {
      try {
        const text = buffer.toString('utf-8');
        textContent = text.length > 50000 ? text.slice(0, 50000) + '\n... [Content truncated for context safety]' : text;
        const lineCount = text.split('\n').length;
        summary = `${safeBase}: ${fileCategory.toUpperCase()} file containing ${lineCount} lines and ${text.length} characters.`;
        isExtracted = true;
        extractionStatus = 'EXTRACTED';
      } catch (err) {
        extractionStatus = 'FAILED';
        extractionNote = 'Could not parse text stream from file buffer.';
      }
    } else if (fileCategory === 'image') {
      summary = `Image asset (${safeBase}, ${Math.round(buffer.length / 1024)} KB, ${mimeType}).`;
      isExtracted = false;
      extractionStatus = 'UNSUPPORTED';
      extractionNote = 'Visual media asset. Visual inspection available via multimodal vision models.';
    } else {
      summary = `File ${safeBase} (${Math.round(buffer.length / 1024)} KB).`;
      isExtracted = false;
      extractionStatus = 'UNSUPPORTED';
      extractionNote = 'Binary/proprietary document format.';
    }

    const fileEntity: FileAttachmentEntity = {
      id: fileId,
      conversationId,
      projectId,
      userId,
      filename: storageFilename,
      originalName: safeBase,
      mimeType,
      sizeBytes: buffer.length,
      fileCategory,
      storagePath,
      textContent,
      summary,
      isExtracted,
      extractionStatus,
      extractionNote,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    return db.saveFile(fileEntity);
  }

  /**
   * Retrieve file metadata by ID
   */
  public async getFile(fileId: string): Promise<FileAttachmentEntity | null> {
    return db.getFile(fileId);
  }

  /**
   * Retrieve list of files with optional filtering
   */
  public async getFiles(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<FileAttachmentEntity[]> {
    return db.getFiles(filter);
  }

  /**
   * Read raw file buffer from disk
   */
  public async getFileBuffer(fileId: string): Promise<{ buffer: Buffer; file: FileAttachmentEntity } | null> {
    const file = await db.getFile(fileId);
    if (!file || !fs.existsSync(file.storagePath)) {
      return null;
    }
    const buffer = await fs.promises.readFile(file.storagePath);
    return { buffer, file };
  }

  /**
   * Delete file from database and disk storage
   */
  public async deleteFile(fileId: string): Promise<boolean> {
    const file = await db.getFile(fileId);
    if (file && fs.existsSync(file.storagePath)) {
      try {
        await fs.promises.unlink(file.storagePath);
      } catch (err) {
        console.warn(`[FILE MANAGER] Could not unlink ${file.storagePath}:`, err);
      }
    }
    return db.deleteFile(fileId);
  }
}

export const fileManager = new FileManager();
