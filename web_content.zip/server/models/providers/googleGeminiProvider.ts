/**
 * Real Google Gemini Provider
 * Encapsulates the official @google/genai SDK behind the normalized IModelProvider interface.
 * Strictly enforces server-side API key containment, safe secret redaction, transient retries,
 * deterministic timeouts, and live telemetry tracking.
 */

import { GoogleGenAI } from '@google/genai';
import { config } from '../../config/index.ts';
import {
  IModelProvider,
  ModelDescriptor,
  ModelError,
  ModelHealth,
  ModelRequest,
  ModelResponse,
  ModelUsage,
} from '../types.ts';

// Secret redaction utility
export function redactSecrets(text: string): string {
  if (!text) return '';
  // Redact Gemini API key formats (AIzaSy...)
  let redacted = text.replace(/AIzaSy[A-Za-z0-9_-]{33}/g, 'AIzaSy***[REDACTED]');
  // Redact bearer tokens or generic keys
  redacted = redacted.replace(/bearer\s+[A-Za-z0-9_\-\.]{15,}/gi, 'Bearer ***[REDACTED]');
  // Redact key parameters
  redacted = redacted.replace(/(?:key|token|secret|password)=([A-Za-z0-9_\-\.]{8,})/gi, '$1=***[REDACTED]');
  return redacted;
}

export class GoogleGeminiProvider implements IModelProvider {
  public readonly id = 'google-gemini' as const;
  public readonly name = 'Google Gemini (GenAI SDK)';

  private client: GoogleGenAI | null = null;
  private descriptors: Map<string, ModelDescriptor> = new Map();

  constructor() {
    this.registerDescriptors();
  }

  private registerDescriptors() {
    const defaultModels: ModelDescriptor[] = [
      {
        id: 'gemini-3.8-flash',
        name: 'Gemini 3.8 Flash',
        provider: 'google-gemini',
        category: 'general',
        targetRole: 'PRIMARY_REMOTE_MODEL',
        capabilities: ['text', 'structured_json', 'fast'],
        contextWindow: 1048576,
        inputCostPer1kTokens: 0.0001,
        outputCostPer1kTokens: 0.0004,
        health: {
          status: 'healthy',
          lastChecked: new Date().toISOString(),
          consecutiveFailures: 0,
          isAvailable: true,
        },
        telemetry: {
          requestCount: 0,
          successCount: 0,
          failureCount: 0,
          timeoutCount: 0,
          fallbackCount: 0,
          averageLatencyMs: 0,
          totalTokens: 0,
          estimatedTotalCostUsd: 0,
        },
      },
      {
        id: 'gemini-3.1-pro-preview',
        name: 'Gemini 3.1 Pro Preview',
        provider: 'google-gemini',
        category: 'reasoning',
        targetRole: 'SECONDARY_REMOTE_MODEL',
        capabilities: ['text', 'structured_json', 'reasoning', 'code'],
        contextWindow: 2097152,
        inputCostPer1kTokens: 0.00125,
        outputCostPer1kTokens: 0.005,
        health: {
          status: 'healthy',
          lastChecked: new Date().toISOString(),
          consecutiveFailures: 0,
          isAvailable: true,
        },
        telemetry: {
          requestCount: 0,
          successCount: 0,
          failureCount: 0,
          timeoutCount: 0,
          fallbackCount: 0,
          averageLatencyMs: 0,
          totalTokens: 0,
          estimatedTotalCostUsd: 0,
        },
      },
      {
        id: 'gemini-3.1-flash-lite',
        name: 'Gemini 3.1 Flash Lite',
        provider: 'google-gemini',
        category: 'fast',
        targetRole: 'SECONDARY_REMOTE_MODEL',
        capabilities: ['text', 'fast'],
        contextWindow: 1048576,
        inputCostPer1kTokens: 0.00005,
        outputCostPer1kTokens: 0.0002,
        health: {
          status: 'healthy',
          lastChecked: new Date().toISOString(),
          consecutiveFailures: 0,
          isAvailable: true,
        },
        telemetry: {
          requestCount: 0,
          successCount: 0,
          failureCount: 0,
          timeoutCount: 0,
          fallbackCount: 0,
          averageLatencyMs: 0,
          totalTokens: 0,
          estimatedTotalCostUsd: 0,
        },
      },
    ];

    for (const d of defaultModels) {
      this.descriptors.set(d.id, d);
    }
  }

  public isConfigured(): boolean {
    return Boolean(config.models.hasGeminiApiKey && config.models.geminiApiKey);
  }

  private getClient(): GoogleGenAI {
    if (this.client) return this.client;

    const apiKey = config.models.geminiApiKey;
    if (!apiKey || !config.models.hasGeminiApiKey) {
      throw new ModelError({
        code: 'AUTH_ERROR',
        message: 'Google Gemini API key is unconfigured or invalid',
        provider: this.id,
        modelId: 'gemini-3.8-flash',
        retryable: false,
      });
    }

    this.client = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    return this.client;
  }

  public getModels(): ModelDescriptor[] {
    return Array.from(this.descriptors.values());
  }

  public getModel(modelId: string): ModelDescriptor | undefined {
    return this.descriptors.get(modelId);
  }

  public async checkHealth(modelId: string): Promise<ModelHealth> {
    const desc = this.descriptors.get(modelId);
    if (!desc) {
      return {
        status: 'unavailable',
        lastChecked: new Date().toISOString(),
        consecutiveFailures: 1,
        isAvailable: false,
        lastError: `Unknown model: ${modelId}`,
      };
    }

    if (!this.isConfigured()) {
      desc.health = {
        status: 'unavailable',
        lastChecked: new Date().toISOString(),
        consecutiveFailures: 0,
        isAvailable: false,
        lastError: 'Gemini API key is not configured in environment',
      };
      return desc.health;
    }

    return desc.health;
  }

  /**
   * Generates text through the official Google Gemini SDK with bounded retry & timeout.
   */
  public async generateText(modelId: string, request: ModelRequest): Promise<ModelResponse> {
    const desc = this.descriptors.get(modelId);
    if (!desc) {
      throw new ModelError({
        code: 'INVALID_REQUEST',
        message: `Model ${modelId} is not supported by Google Gemini provider`,
        provider: this.id,
        modelId,
        retryable: false,
      });
    }

    if (!this.isConfigured()) {
      this.recordFailure(modelId, 'AUTH_ERROR', 'Gemini API key not configured');
      throw new ModelError({
        code: 'AUTH_ERROR',
        message: 'Google Gemini API key is missing or unconfigured in server environment',
        provider: this.id,
        modelId,
        retryable: false,
      });
    }

    const client = this.getClient();
    const timeoutMs = request.timeoutMs || config.models.timeoutMs;
    const maxRetries = 2;
    let attempt = 0;
    let lastError: unknown = null;

    while (attempt <= maxRetries) {
      attempt++;
      const startTime = Date.now();

      try {
        const response = await this.executeCallWithTimeout(client, modelId, request, timeoutMs);
        const latencyMs = Date.now() - startTime;

        this.recordSuccess(modelId, latencyMs, response.usage);
        return response;
      } catch (err: any) {
        lastError = err;
        const normalized = this.normalizeError(err, modelId);

        // Record failure in health & telemetry
        this.recordFailure(modelId, normalized.code, normalized.message);

        // Do not retry non-retryable errors
        if (!normalized.retryable || attempt > maxRetries) {
          throw normalized;
        }

        // Exponential backoff before retry (e.g. 300ms, 600ms)
        const backoffMs = Math.min(1000, 300 * Math.pow(2, attempt - 1));
        await new Promise((res) => setTimeout(res, backoffMs));
      }
    }

    throw this.normalizeError(lastError, modelId);
  }

  private async executeCallWithTimeout(
    client: GoogleGenAI,
    modelId: string,
    request: ModelRequest,
    timeoutMs: number
  ): Promise<ModelResponse> {
    const startTime = Date.now();

    const generatePromise = (async (): Promise<ModelResponse> => {
      const promptText = request.systemInstruction
        ? `${request.systemInstruction}\n\nTask:\n${request.prompt}`
        : request.prompt;

      const genConfig: Record<string, unknown> = {
        temperature: request.temperature ?? config.models.temperature,
        maxOutputTokens: request.maxTokens ?? config.models.maxTokens,
      };

      if (request.responseMimeType === 'application/json') {
        genConfig.responseMimeType = 'application/json';
        if (request.responseSchema) {
          genConfig.responseSchema = request.responseSchema;
        }
      }

      if (request.stopSequences && request.stopSequences.length > 0) {
        genConfig.stopSequences = request.stopSequences;
      }

      const res = await client.models.generateContent({
        model: modelId,
        contents: promptText,
        config: genConfig,
      });

      const latencyMs = Date.now() - startTime;
      const text = res.text || '';

      // Compute or estimate token usage
      const promptTokens = Math.ceil(promptText.length / 4);
      const completionTokens = Math.ceil(text.length / 4);
      const totalTokens = promptTokens + completionTokens;

      const desc = this.descriptors.get(modelId);
      const estimatedCostUsd = desc
        ? (promptTokens / 1000) * desc.inputCostPer1kTokens +
          (completionTokens / 1000) * desc.outputCostPer1kTokens
        : 0;

      const usage: ModelUsage = {
        promptTokens,
        completionTokens,
        totalTokens,
        estimatedCostUsd,
      };

      let parsedJson: unknown = undefined;
      if (request.responseMimeType === 'application/json' && text) {
        try {
          parsedJson = JSON.parse(text);
        } catch {
          // JSON parsing handled by structured output layer if needed
        }
      }

      return {
        modelId,
        provider: this.id,
        providerSource: 'REAL_MODEL',
        text,
        parsedJson,
        usage,
        latencyMs,
      };
    })();

    const timeoutPromise = new Promise<never>((_, reject) => {
      const timer = setTimeout(() => {
        reject(
          new ModelError({
            code: 'TIMEOUT',
            message: `Google Gemini request timed out after ${timeoutMs}ms`,
            provider: this.id,
            modelId,
            retryable: true,
          })
        );
      }, timeoutMs);

      // Clean up timer if aborted
      if (request.abortSignal) {
        request.abortSignal.addEventListener('abort', () => {
          clearTimeout(timer);
          reject(
            new ModelError({
              code: 'TIMEOUT',
              message: 'Request aborted by client',
              provider: this.id,
              modelId,
              retryable: false,
            })
          );
        });
      }
    });

    return Promise.race([generatePromise, timeoutPromise]);
  }

  private normalizeError(err: any, modelId: string): ModelError {
    if (err instanceof ModelError) {
      return err;
    }

    const rawMessage = redactSecrets(err?.message || String(err));
    const status = typeof err?.status === 'number' ? err.status : undefined;
    const statusStr = String(err?.status || '');

    // 1. Timeout
    if (rawMessage.toLowerCase().includes('timeout') || err?.code === 'ETIMEDOUT') {
      return new ModelError({
        code: 'TIMEOUT',
        message: rawMessage,
        provider: this.id,
        modelId,
        status: 408,
        retryable: true,
        rawError: err,
      });
    }

    // 2. Authentication / API Key issues
    if (
      status === 401 ||
      status === 403 ||
      rawMessage.toLowerCase().includes('api_key') ||
      rawMessage.toLowerCase().includes('unauthenticated') ||
      rawMessage.toLowerCase().includes('permission_denied')
    ) {
      return new ModelError({
        code: 'AUTH_ERROR',
        message: `Authentication failure on model ${modelId}: ${rawMessage}`,
        provider: this.id,
        modelId,
        status: status || 401,
        retryable: false,
        rawError: err,
      });
    }

    // 3. Rate Limit / Quota Exceeded
    if (
      status === 429 ||
      rawMessage.toLowerCase().includes('resource_exhausted') ||
      rawMessage.toLowerCase().includes('quota') ||
      rawMessage.toLowerCase().includes('rate limit')
    ) {
      return new ModelError({
        code: 'RATE_LIMIT',
        message: `Rate limit / quota exceeded for model ${modelId}: ${rawMessage}`,
        provider: this.id,
        modelId,
        status: 429,
        retryable: true,
        rawError: err,
      });
    }

    // 4. Service Unavailable / High Demand
    if (status === 503 || status === 504 || rawMessage.toLowerCase().includes('unavailable')) {
      return new ModelError({
        code: 'UNAVAILABLE',
        message: `Gemini service unavailable for ${modelId}: ${rawMessage}`,
        provider: this.id,
        modelId,
        status: status || 503,
        retryable: true,
        rawError: err,
      });
    }

    // 5. Invalid Request / Schema
    if (status === 400 || rawMessage.toLowerCase().includes('invalid')) {
      return new ModelError({
        code: 'INVALID_REQUEST',
        message: `Invalid request for ${modelId}: ${rawMessage}`,
        provider: this.id,
        modelId,
        status: 400,
        retryable: false,
        rawError: err,
      });
    }

    return new ModelError({
      code: 'UNKNOWN',
      message: `Google Gemini error: ${rawMessage}`,
      provider: this.id,
      modelId,
      status,
      retryable: true,
      rawError: err,
    });
  }

  private recordSuccess(modelId: string, latencyMs: number, usage: ModelUsage) {
    const desc = this.descriptors.get(modelId);
    if (!desc) return;

    desc.health.status = 'healthy';
    desc.health.lastChecked = new Date().toISOString();
    desc.health.lastSuccess = new Date().toISOString();
    desc.health.consecutiveFailures = 0;
    desc.health.isAvailable = true;

    const tel = desc.telemetry;
    tel.requestCount += 1;
    tel.successCount += 1;
    tel.totalTokens += usage.totalTokens;
    tel.estimatedTotalCostUsd += usage.estimatedCostUsd;
    tel.lastRequestAt = new Date().toISOString();
    tel.lastSuccessAt = new Date().toISOString();

    // Rolling average latency
    tel.averageLatencyMs = tel.averageLatencyMs === 0
      ? latencyMs
      : Math.round((tel.averageLatencyMs * (tel.successCount - 1) + latencyMs) / tel.successCount);
  }

  private recordFailure(modelId: string, code: string, message: string) {
    const desc = this.descriptors.get(modelId);
    if (!desc) return;

    desc.health.lastChecked = new Date().toISOString();
    desc.health.lastError = redactSecrets(message);
    desc.health.consecutiveFailures += 1;

    // Status transition
    if (code === 'AUTH_ERROR') {
      desc.health.status = 'auth_failure';
      desc.health.isAvailable = false;
    } else if (code === 'RATE_LIMIT') {
      desc.health.status = 'rate_limited';
      desc.health.isAvailable = false;
    } else if (code === 'TIMEOUT') {
      desc.health.status = 'timeout';
      desc.health.isAvailable = desc.health.consecutiveFailures < 3;
    } else if (desc.health.consecutiveFailures >= 3) {
      desc.health.status = 'unavailable';
      desc.health.isAvailable = false;
    } else {
      desc.health.status = 'degraded';
    }

    const tel = desc.telemetry;
    tel.requestCount += 1;
    tel.failureCount += 1;
    if (code === 'TIMEOUT') tel.timeoutCount += 1;
    tel.lastRequestAt = new Date().toISOString();
    tel.lastFailureAt = new Date().toISOString();
    tel.lastError = redactSecrets(message);
  }
}
