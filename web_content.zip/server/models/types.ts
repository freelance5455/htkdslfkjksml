/**
 * JARVIS Model Abstraction & Intelligent Router Type Contracts
 * Provider-neutral interfaces for model operations, health states, telemetry, and routing decisions.
 */

export type ModelProviderType = 'google-gemini' | 'local-heuristic' | 'openai-compat' | 'custom-mock';

export type ModelCategory = 'general' | 'reasoning' | 'coding' | 'vision' | 'fast';

export type ModelTargetRole =
  | 'PRIMARY_REMOTE_MODEL'
  | 'SECONDARY_REMOTE_MODEL'
  | 'LOCAL_HEURISTIC_FALLBACK';

export type ModelCapability =
  | 'text'
  | 'structured_json'
  | 'streaming'
  | 'code'
  | 'reasoning'
  | 'fast'
  | 'vision';

export type ModelHealthStatus =
  | 'healthy'
  | 'degraded'
  | 'unavailable'
  | 'timeout'
  | 'auth_failure'
  | 'rate_limited';

export type RoutingDecisionStatus = 'ROUTE_SELECTED' | 'ROUTE_FALLBACK' | 'ROUTE_FAILED';

export interface ModelUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCostUsd: number;
}

export interface ModelTelemetry {
  requestCount: number;
  successCount: number;
  failureCount: number;
  timeoutCount: number;
  fallbackCount: number;
  averageLatencyMs: number;
  totalTokens: number;
  estimatedTotalCostUsd: number;
  lastRequestAt?: string;
  lastSuccessAt?: string;
  lastFailureAt?: string;
  lastError?: string;
}

export interface ModelHealth {
  status: ModelHealthStatus;
  lastChecked: string;
  lastSuccess?: string;
  lastError?: string;
  consecutiveFailures: number;
  isAvailable: boolean;
}

export interface ModelDescriptor {
  id: string;
  name: string;
  provider: ModelProviderType;
  category: ModelCategory;
  capabilities: ModelCapability[];
  contextWindow: number;
  inputCostPer1kTokens: number;
  outputCostPer1kTokens: number;
  health: ModelHealth;
  telemetry: ModelTelemetry;
  isOfflineFallback?: boolean;
  targetRole?: ModelTargetRole;
}

export interface ModelRequest {
  prompt: string;
  systemInstruction?: string;
  temperature?: number;
  maxTokens?: number;
  responseSchema?: Record<string, unknown>;
  responseMimeType?: 'text/plain' | 'application/json';
  stopSequences?: string[];
  timeoutMs?: number;
  abortSignal?: AbortSignal;
  requiredCategory?: ModelCategory;
  requiredCapabilities?: ModelCapability[];
  requestId?: string;
  taskId?: string;
  agentRunId?: string;
  retryBudget?: number;
  fallbackBudget?: number;
  preferredLanguage?: 'en' | 'hi' | 'hinglish';
  startTimestamp?: number;
}

export interface ModelResponse {
  modelId: string;
  provider: ModelProviderType;
  providerSource?: 'REAL_MODEL' | 'LOCAL_HEURISTIC' | 'FALLBACK_MODEL' | 'TOOL_RESULT' | 'MIXED' | 'UNKNOWN';
  text: string;
  parsedJson?: unknown;
  usage: ModelUsage;
  latencyMs: number;
  finishReason?: string;
  routingDecision?: ModelRoutingDecision;
  language?: 'en' | 'hi' | 'hinglish';
  speechEligible?: boolean;
  isOfflineFallback?: boolean;
}

export type ModelErrorCode =
  | 'TIMEOUT'
  | 'RATE_LIMIT'
  | 'AUTH_ERROR'
  | 'INVALID_REQUEST'
  | 'UNAVAILABLE'
  | 'PARSE_ERROR'
  | 'PROMPT_TOO_LARGE'
  | 'CONTEXT_LIMIT'
  | 'CANCELLED'
  | 'UNKNOWN';

export class ModelError extends Error {
  public code: ModelErrorCode;
  public provider: string;
  public modelId: string;
  public status?: number;
  public retryable: boolean;
  public rawError?: unknown;

  constructor(opts: {
    code: ModelErrorCode;
    message: string;
    provider: string;
    modelId: string;
    status?: number;
    retryable?: boolean;
    rawError?: unknown;
  }) {
    super(opts.message);
    this.name = 'ModelError';
    this.code = opts.code;
    this.provider = opts.provider;
    this.modelId = opts.modelId;
    this.status = opts.status;
    this.retryable = opts.retryable ?? false;
    this.rawError = opts.rawError;
  }
}

export interface ModelAttemptRecord {
  modelId: string;
  provider: string;
  status: 'SUCCESS' | 'FAILED';
  latencyMs: number;
  error?: string;
}

export interface ModelRoutingDecision {
  id: string;
  timestamp: string;
  status: RoutingDecisionStatus;
  selectedModelId?: string;
  selectedProvider?: string;
  requiredCategory?: ModelCategory;
  requiredCapabilities?: ModelCapability[];
  fallbackChain: string[];
  attemptedModels: ModelAttemptRecord[];
  reasoning: string;
  totalLatencyMs: number;
}

export interface StructuredOutputValidation<T> {
  valid: boolean;
  data?: T;
  error?: string;
}

export interface IModelProvider {
  readonly id: ModelProviderType;
  readonly name: string;

  isConfigured(): boolean;
  getModels(): ModelDescriptor[];
  getModel(modelId: string): ModelDescriptor | undefined;
  checkHealth(modelId: string): Promise<ModelHealth>;
  generateText(modelId: string, request: ModelRequest): Promise<ModelResponse>;
}
