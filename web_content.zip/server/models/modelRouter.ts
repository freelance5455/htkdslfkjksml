/**
 * JARVIS Intelligent Model Router
 * Deterministic multi-factor model selection, health-aware fallback chains,
 * structured JSON orchestration, secret-safe logging, and complete decision auditing.
 */

import { config } from '../config/index.ts';
import { GoogleGeminiProvider, redactSecrets } from './providers/googleGeminiProvider.ts';
import { LocalHeuristicProvider } from './providers/localHeuristicProvider.ts';
import { executeStructuredWithRepair, SchemaValidator } from './structuredOutput.ts';
import {
  IModelProvider,
  ModelAttemptRecord,
  ModelCapability,
  ModelCategory,
  ModelDescriptor,
  ModelError,
  ModelRequest,
  ModelResponse,
  ModelRoutingDecision,
  ModelTargetRole,
} from './types.ts';

export interface RouteOptions {
  requiredCategory?: ModelCategory;
  requiredCapabilities?: ModelCapability[];
  preferredModelId?: string;
  maxTokens?: number;
  temperature?: number;
  timeoutMs?: number;
  systemInstruction?: string;
}

export class ModelRouter {
  private providers: Map<string, IModelProvider> = new Map();
  private decisionHistory: ModelRoutingDecision[] = [];
  private readonly maxDecisionHistory = 100;

  constructor() {
    this.registerDefaultProviders();
  }

  private registerDefaultProviders() {
    this.registerProvider(new GoogleGeminiProvider());
    this.registerProvider(new LocalHeuristicProvider());
  }

  public registerProvider(provider: IModelProvider) {
    this.providers.set(provider.id, provider);
  }

  public removeProvider(providerId: string) {
    this.providers.delete(providerId);
  }

  public getProvider(providerId: string): IModelProvider | undefined {
    return this.providers.get(providerId);
  }

  /**
   * Retrieves all registered models with backward compatibility properties.
   */
  public getModels(): (ModelDescriptor & {
    isHealthy: boolean;
    averageLatencyMs: number;
    totalTokensUsed: number;
    totalRequests: number;
  })[] {
    const list: (ModelDescriptor & {
      isHealthy: boolean;
      averageLatencyMs: number;
      totalTokensUsed: number;
      totalRequests: number;
    })[] = [];

    for (const p of this.providers.values()) {
      for (const m of p.getModels()) {
        list.push({
          ...m,
          isHealthy: m.health.isAvailable && m.health.status === 'healthy',
          averageLatencyMs: m.telemetry.averageLatencyMs,
          totalTokensUsed: m.telemetry.totalTokens,
          totalRequests: m.telemetry.requestCount,
        });
      }
    }

    return list;
  }

  public getModel(modelId: string): ModelDescriptor | undefined {
    for (const p of this.providers.values()) {
      const found = p.getModel(modelId);
      if (found) return found;
    }
    return undefined;
  }

  public getRoutingDecisions(limit = 20): ModelRoutingDecision[] {
    return this.decisionHistory.slice(-limit).reverse();
  }

  /**
   * Evaluates task requirements and builds a prioritized candidate list.
   * Categorizes models into PRIMARY_REMOTE_MODEL, SECONDARY_REMOTE_MODEL, and LOCAL_HEURISTIC_FALLBACK.
   */
  private buildCandidateChain(options: RouteOptions): { model: ModelDescriptor; provider: IModelProvider }[] {
    const candidates: {
      model: ModelDescriptor;
      provider: IModelProvider;
      score: number;
      role: ModelTargetRole;
    }[] = [];

    const reqCategory = options.requiredCategory || 'general';
    const reqCaps = options.requiredCapabilities || [];

    for (const provider of this.providers.values()) {
      for (const model of provider.getModels()) {
        let score = 0;

        // Determine explicit target role
        const role: ModelTargetRole =
          model.targetRole ||
          (provider.id === 'local-heuristic'
            ? 'LOCAL_HEURISTIC_FALLBACK'
            : model.id === config.models.defaultModelId || provider.id === 'custom-mock' || model.id.includes('primary')
            ? 'PRIMARY_REMOTE_MODEL'
            : 'SECONDARY_REMOTE_MODEL');

        // 1. Provider configuration filter
        if (!provider.isConfigured()) {
          score -= 1000;
        }

        // 2. Health filter
        if (!model.health.isAvailable || model.health.status === 'auth_failure' || model.health.status === 'unavailable') {
          score -= 500;
        } else if (model.health.status === 'degraded' || model.health.status === 'rate_limited') {
          score -= 100;
        } else if (model.health.status === 'healthy') {
          score += 100;
        }

        // 3. Preferred model ID boost & Explicit Role priority
        if (options.preferredModelId && model.id === options.preferredModelId) {
          score += 300;
        } else if (provider.id === 'custom-mock' || model.id.includes('primary')) {
          // Custom / Mock primary registered for testing or custom orchestration
          score += 260;
        } else if (role === 'PRIMARY_REMOTE_MODEL' && provider.isConfigured()) {
          score += 180;
        } else if (role === 'SECONDARY_REMOTE_MODEL' && provider.isConfigured()) {
          score += 120;
        }

        // 4. Category alignment
        if (model.category === reqCategory) {
          score += 60;
        }

        // 5. Capability alignment
        for (const cap of reqCaps) {
          if (model.capabilities.includes(cap)) {
            score += 40;
          } else {
            score -= 80;
          }
        }

        // 6. Cost & Latency preference (slight tiebreaker)
        if (model.telemetry.averageLatencyMs > 0 && model.telemetry.averageLatencyMs < 1000) {
          score += 10;
        }

        // 7. Local heuristic edge engine baseline
        if (role === 'LOCAL_HEURISTIC_FALLBACK') {
          score = provider.isConfigured() ? 20 : 0;
        }

        candidates.push({ model, provider, score, role });
      }
    }

    // Sort descending by score
    candidates.sort((a, b) => b.score - a.score);

    // Filter out completely dead candidates unless nothing else is available
    const available = candidates.filter((c) => c.score > -400);
    const selection = available.length > 0 ? available : candidates;

    if (selection.length === 0) return [];

    const primaryCandidate = selection[0];
    const result: { model: ModelDescriptor; provider: IModelProvider }[] = [
      { model: primaryCandidate.model, provider: primaryCandidate.provider },
    ];
    const seen = new Set<string>([primaryCandidate.model.id]);

    // Build fallback chain according to provider family and configured policy:
    if (primaryCandidate.provider.id === 'google-gemini') {
      // For Gemini primary: secondary remote models first, then local heuristic
      for (const c of selection) {
        if (!seen.has(c.model.id) && c.role === 'SECONDARY_REMOTE_MODEL' && c.provider.id === 'google-gemini') {
          seen.add(c.model.id);
          result.push({ model: c.model, provider: c.provider });
        }
      }
    } else if (primaryCandidate.provider.id === 'custom-mock') {
      // For custom mock: fallback directly to local heuristic offline fallback
    } else {
      // General provider
      for (const c of selection) {
        if (!seen.has(c.model.id) && c.role !== 'LOCAL_HEURISTIC_FALLBACK') {
          seen.add(c.model.id);
          result.push({ model: c.model, provider: c.provider });
        }
      }
    }

    // Always ensure local heuristic is in chain as absolute ultimate offline fallback
    const localProvider = this.providers.get('local-heuristic');
    if (localProvider) {
      const localModel = localProvider.getModel('jarvis-heuristic-engine');
      if (localModel && !seen.has(localModel.id)) {
        result.push({ model: localModel, provider: localProvider });
      }
    }

    return result;
  }

  /**
   * Main route and generate method with automatic fallback and telemetry auditing.
   */
  public async routeAndGenerate(
    req: ModelRequest & { requiredCategory?: ModelCategory }
  ): Promise<ModelResponse> {
    const startTime = Date.now();
    const candidateChain = this.buildCandidateChain({
      requiredCategory: req.requiredCategory,
      requiredCapabilities: req.requiredCapabilities,
      preferredModelId: (req as any).preferredModelId || (
        req.requiredCategory === 'reasoning' || req.requiredCategory === 'coding'
          ? 'gemini-3.1-pro-preview'
          : undefined
      ),
      temperature: req.temperature,
      maxTokens: req.maxTokens,
      timeoutMs: req.timeoutMs,
      systemInstruction: req.systemInstruction,
    });

    const fallbackLimit = req.fallbackBudget !== undefined ? Math.max(1, req.fallbackBudget) : candidateChain.length;
    const activeCandidateChain = candidateChain.slice(0, fallbackLimit);
    const fallbackChainIds = activeCandidateChain.map((c) => c.model.id);
    const attempts: ModelAttemptRecord[] = [];
    let chosenResponse: ModelResponse | null = null;
    let finalDecisionStatus: 'ROUTE_SELECTED' | 'ROUTE_FALLBACK' | 'ROUTE_FAILED' = 'ROUTE_FAILED';
    let selectedCandidate: { model: ModelDescriptor; provider: IModelProvider } | null = null;
    let lastError: unknown = null;

    // Check cancellation before dispatching
    if (req.abortSignal?.aborted) {
      throw new ModelError({
        code: 'CANCELLED',
        message: 'Request was cancelled before model execution commenced.',
        provider: 'model-router',
        modelId: fallbackChainIds[0] || 'unknown',
        retryable: false,
      });
    }

    for (let i = 0; i < activeCandidateChain.length; i++) {
      if (req.abortSignal?.aborted) {
        throw new ModelError({
          code: 'CANCELLED',
          message: 'Request was cancelled during fallback traversal.',
          provider: 'model-router',
          modelId: activeCandidateChain[i].model.id,
          retryable: false,
        });
      }

      const candidate = activeCandidateChain[i];
      let candidateAttempts = 0;
      const retryLimit = req.retryBudget !== undefined ? Math.max(0, req.retryBudget) : 1;

      while (candidateAttempts <= retryLimit) {
        candidateAttempts++;
        const attemptStart = Date.now();

        try {
          const res = await candidate.provider.generateText(candidate.model.id, req);
          const attemptLatency = Date.now() - attemptStart;

          attempts.push({
            modelId: candidate.model.id,
            provider: candidate.provider.id,
            status: 'SUCCESS',
            latencyMs: attemptLatency,
          });

          chosenResponse = res;
          selectedCandidate = candidate;
          finalDecisionStatus = i === 0 ? 'ROUTE_SELECTED' : 'ROUTE_FALLBACK';

          // Increment fallback count if not primary
          if (i > 0) {
            candidate.model.telemetry.fallbackCount += 1;
          }

          break; // Succeeded on this candidate
        } catch (err: any) {
          const attemptLatency = Date.now() - attemptStart;
          lastError = err;
          const errMessage = redactSecrets(err?.message || String(err));

          attempts.push({
            modelId: candidate.model.id,
            provider: candidate.provider.id,
            status: 'FAILED',
            latencyMs: attemptLatency,
            error: errMessage,
          });

          // Only retry if error is flagged retryable and we haven't exhausted retryLimit
          if (!err.retryable || candidateAttempts > retryLimit) {
            break; // Move to next candidate in fallback chain
          }
        }
      }

      if (chosenResponse) {
        break; // Successfully got response
      }
    }

    const totalLatency = Date.now() - startTime;

    const decision: ModelRoutingDecision = {
      id: `mdec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      status: finalDecisionStatus,
      selectedModelId: selectedCandidate?.model.id,
      selectedProvider: selectedCandidate?.provider.id,
      requiredCategory: req.requiredCategory,
      requiredCapabilities: req.requiredCapabilities,
      fallbackChain: fallbackChainIds,
      attemptedModels: attempts,
      reasoning:
        finalDecisionStatus === 'ROUTE_SELECTED'
          ? `Primary model ${selectedCandidate?.model.id} processed request within policy bounds.`
          : finalDecisionStatus === 'ROUTE_FALLBACK'
          ? `Primary model failed or was unconfigured. Smoothly switched to fallback model ${selectedCandidate?.model.id}.`
          : `All models in candidate chain failed to satisfy request.`,
      totalLatencyMs: totalLatency,
    };

    this.recordDecision(decision);

    if (!chosenResponse || !selectedCandidate) {
      throw new ModelError({
        code: 'UNAVAILABLE',
        message: `All models in routing chain failed: ${redactSecrets(String(lastError || 'No available providers'))}`,
        provider: 'model-router',
        modelId: fallbackChainIds[0] || 'unknown',
        retryable: false,
        rawError: lastError,
      });
    }

    // Phase 11 Response Verification: Clean secrets, verify payload
    chosenResponse.text = redactSecrets(chosenResponse.text || '');
    chosenResponse.language = req.preferredLanguage || 'en';
    chosenResponse.speechEligible = true;
    chosenResponse.isOfflineFallback = selectedCandidate.provider.id === 'local-heuristic';
    chosenResponse.providerSource =
      selectedCandidate.provider.id === 'local-heuristic'
        ? 'LOCAL_HEURISTIC'
        : finalDecisionStatus === 'ROUTE_FALLBACK'
        ? 'FALLBACK_MODEL'
        : 'REAL_MODEL';
    chosenResponse.routingDecision = decision;
    return chosenResponse;
  }

  /**
   * Safe Structured Output routing with schema validation and single bounded repair.
   */
  public async routeAndGenerateStructured<T>(
    req: ModelRequest & { requiredCategory?: ModelCategory },
    validator: SchemaValidator<T>,
    schemaDescription?: string
  ): Promise<{ data: T; response: ModelResponse; decision: ModelRoutingDecision }> {
    const startTime = Date.now();
    const candidateChain = this.buildCandidateChain({
      requiredCategory: req.requiredCategory,
      requiredCapabilities: ['structured_json', ...(req.requiredCapabilities || [])],
      timeoutMs: req.timeoutMs,
      systemInstruction: req.systemInstruction,
    });

    const fallbackChainIds = candidateChain.map((c) => c.model.id);
    const attempts: ModelAttemptRecord[] = [];
    let chosenResult: { data: T; response: ModelResponse } | null = null;
    let selectedCandidate: { model: ModelDescriptor; provider: IModelProvider } | null = null;
    let finalDecisionStatus: 'ROUTE_SELECTED' | 'ROUTE_FALLBACK' | 'ROUTE_FAILED' = 'ROUTE_FAILED';
    let lastError: unknown = null;

    for (let i = 0; i < candidateChain.length; i++) {
      const candidate = candidateChain[i];
      const attemptStart = Date.now();

      try {
        const result = await executeStructuredWithRepair<T>(
          candidate.provider,
          candidate.model.id,
          req,
          validator,
          schemaDescription
        );

        const attemptLatency = Date.now() - attemptStart;
        attempts.push({
          modelId: candidate.model.id,
          provider: candidate.provider.id,
          status: 'SUCCESS',
          latencyMs: attemptLatency,
        });

        chosenResult = { data: result.data, response: result.response };
        selectedCandidate = candidate;
        finalDecisionStatus = i === 0 ? 'ROUTE_SELECTED' : 'ROUTE_FALLBACK';

        if (i > 0) {
          candidate.model.telemetry.fallbackCount += 1;
        }

        break;
      } catch (err: any) {
        const attemptLatency = Date.now() - attemptStart;
        lastError = err;
        attempts.push({
          modelId: candidate.model.id,
          provider: candidate.provider.id,
          status: 'FAILED',
          latencyMs: attemptLatency,
          error: redactSecrets(err?.message || String(err)),
        });
      }
    }

    const totalLatency = Date.now() - startTime;
    const decision: ModelRoutingDecision = {
      id: `mdec_struct_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      status: finalDecisionStatus,
      selectedModelId: selectedCandidate?.model.id,
      selectedProvider: selectedCandidate?.provider.id,
      requiredCategory: req.requiredCategory,
      requiredCapabilities: ['structured_json'],
      fallbackChain: fallbackChainIds,
      attemptedModels: attempts,
      reasoning:
        finalDecisionStatus === 'ROUTE_SELECTED'
          ? `Structured output synthesized and validated via primary model ${selectedCandidate?.model.id}.`
          : finalDecisionStatus === 'ROUTE_FALLBACK'
          ? `Primary model structured output failed; safely recovered via fallback ${selectedCandidate?.model.id}.`
          : `All structured candidates failed validation.`,
      totalLatencyMs: totalLatency,
    };

    this.recordDecision(decision);

    if (!chosenResult || !selectedCandidate) {
      throw new ModelError({
        code: 'PARSE_ERROR',
        message: `Failed to produce validated structured output across routing chain: ${redactSecrets(String(lastError))}`,
        provider: 'model-router',
        modelId: fallbackChainIds[0] || 'unknown',
        retryable: false,
        rawError: lastError,
      });
    }

    chosenResult.response.routingDecision = decision;
    return {
      data: chosenResult.data,
      response: chosenResult.response,
      decision,
    };
  }

  private recordDecision(decision: ModelRoutingDecision) {
    this.decisionHistory.push(decision);
    if (this.decisionHistory.length > this.maxDecisionHistory) {
      this.decisionHistory.shift();
    }
  }
}

export const modelRouter = new ModelRouter();
