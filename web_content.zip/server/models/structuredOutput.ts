/**
 * JARVIS Safe Structured Output Engine
 * Robust schema enforcement, malformed JSON recovery, bounded single repair attempt,
 * and normalized error handling for critical core loop and planner outputs.
 */

import {
  IModelProvider,
  ModelError,
  ModelRequest,
  ModelResponse,
  StructuredOutputValidation,
} from './types.ts';

export type SchemaValidator<T> = (data: unknown) => StructuredOutputValidation<T>;

/**
 * Strips markdown code blocks, backticks, and extraneous prefix/suffix text to isolate raw JSON.
 */
export function extractJsonString(raw: string): string {
  if (!raw) return '';
  let cleaned = raw.trim();

  // Strip ```json ... ``` or ``` ... ``` code fences
  const fenceRegex = /```(?:json)?\s*([\s\S]*?)\s*```/i;
  const match = fenceRegex.exec(cleaned);
  if (match && match[1]) {
    cleaned = match[1].trim();
  }

  // If text has leading or trailing non-json characters, find outer braces or brackets
  const firstBrace = cleaned.indexOf('{');
  const firstBracket = cleaned.indexOf('[');
  let startIndex = -1;

  if (firstBrace !== -1 && firstBracket !== -1) {
    startIndex = Math.min(firstBrace, firstBracket);
  } else if (firstBrace !== -1) {
    startIndex = firstBrace;
  } else if (firstBracket !== -1) {
    startIndex = firstBracket;
  }

  if (startIndex > 0) {
    cleaned = cleaned.substring(startIndex);
  }

  const lastBrace = cleaned.lastIndexOf('}');
  const lastBracket = cleaned.lastIndexOf(']');
  let endIndex = -1;

  if (lastBrace !== -1 && lastBracket !== -1) {
    endIndex = Math.max(lastBrace, lastBracket);
  } else if (lastBrace !== -1) {
    endIndex = lastBrace;
  } else if (lastBracket !== -1) {
    endIndex = lastBracket;
  }

  if (endIndex !== -1 && endIndex < cleaned.length - 1) {
    cleaned = cleaned.substring(0, endIndex + 1);
  }

  return cleaned.trim();
}

export function parseJsonSafely(raw: string): { success: boolean; data?: unknown; error?: string } {
  try {
    const jsonStr = extractJsonString(raw);
    if (!jsonStr) {
      return { success: false, error: 'Empty JSON payload extracted from model response' };
    }
    const data = JSON.parse(jsonStr);
    return { success: true, data };
  } catch (err: any) {
    return {
      success: false,
      error: `JSON parse error: ${err?.message || 'Invalid JSON syntax'}`,
    };
  }
}

/**
 * Executes a structured output request with bounded repair.
 * Guarantees exactly at most 1 repair attempt to avoid any potential infinite loops.
 */
export async function executeStructuredWithRepair<T>(
  provider: IModelProvider,
  modelId: string,
  request: ModelRequest,
  validator: SchemaValidator<T>,
  schemaDescription?: string
): Promise<{ data: T; response: ModelResponse; repaired: boolean }> {
  // 1. Prepare initial request
  const systemInstruction = request.systemInstruction
    ? `${request.systemInstruction}\n\nIMPORTANT: You must respond ONLY with a valid JSON object. Do NOT wrap in conversational text. Schema:\n${schemaDescription || 'Valid JSON'}`
    : `Respond ONLY with a valid JSON object conforming to the required specification. Schema:\n${schemaDescription || 'Valid JSON'}`;

  const structuredReq: ModelRequest = {
    ...request,
    systemInstruction,
    responseMimeType: 'application/json',
  };

  // 2. Initial attempt
  const initialResponse = await provider.generateText(modelId, structuredReq);
  const initialParse = parseJsonSafely(initialResponse.text);

  if (initialParse.success) {
    const valResult = validator(initialParse.data);
    if (valResult.valid && valResult.data !== undefined) {
      return {
        data: valResult.data,
        response: initialResponse,
        repaired: false,
      };
    }
  }

  // 3. Bounded single repair attempt
  const initialError = initialParse.error || 'Schema validation failed against required fields';
  const repairPrompt =
    `The previous output was invalid JSON or did not match the expected schema:\n` +
    `Error: ${initialError}\n\n` +
    `Previous Output:\n${initialResponse.text.slice(0, 1500)}\n\n` +
    `Please repair and return ONLY the corrected, valid JSON object now:`;

  const repairReq: ModelRequest = {
    ...request,
    prompt: repairPrompt,
    systemInstruction: `You are a strict JSON repair engine. Output ONLY valid, corrected JSON matching the schema: ${schemaDescription || 'JSON'}. No markdown commentary.`,
    responseMimeType: 'application/json',
    temperature: 0.1, // Low temperature for deterministic formatting
  };

  try {
    const repairResponse = await provider.generateText(modelId, repairReq);
    const repairParse = parseJsonSafely(repairResponse.text);

    if (repairParse.success) {
      const repairVal = validator(repairParse.data);
      if (repairVal.valid && repairVal.data !== undefined) {
        return {
          data: repairVal.data,
          response: repairResponse,
          repaired: true,
        };
      }
      throw new Error(`Repaired output failed schema validation: ${repairVal.error}`);
    }

    throw new Error(`Repaired output was still malformed JSON: ${repairParse.error}`);
  } catch (repairErr: any) {
    throw new ModelError({
      code: 'PARSE_ERROR',
      message: `Failed to produce valid structured output after bounded repair attempt: ${repairErr?.message || initialError}`,
      provider: provider.id,
      modelId,
      retryable: false,
      rawError: repairErr,
    });
  }
}
