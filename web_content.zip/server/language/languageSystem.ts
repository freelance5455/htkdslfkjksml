/**
 * JARVIS Multilingual & Language Preference System
 * Supports English, Hindi, and Hinglish with hierarchical resolution,
 * natural linguistic nuance, and technical terminology preservation.
 */

export type SupportedLanguage = 'en' | 'hi' | 'hinglish';

export interface LanguageDetectionResult {
  detectedLanguage: SupportedLanguage;
  confidence: number;
  isExplicitRequest: boolean;
  reason: string;
}

export class LanguageSystem {
  // Regex patterns for explicit user requests
  private static readonly EXPLICIT_HINGLISH_PATTERNS = [
    /\b(in\s+hinglish|hinglish\s+me(in)?|hinglish\s+bhasha|explain\s+in\s+hinglish)\b/i,
    /\b(hinglish\s+me|hinglish\s+mein|hinglish\s+language)\b/i,
  ];

  private static readonly EXPLICIT_HINDI_PATTERNS = [
    /\b(in\s+hindi|hindi\s+me(in)?|shuddh\s+hindi|hindi\s+mein\s+batao|hindi\s+language)\b/i,
    /[\u0900-\u097F]{4,}/, // Significant Devanagari script presence
  ];

  private static readonly EXPLICIT_ENGLISH_PATTERNS = [
    /\b(in\s+english|english\s+me(in)?|entirely\s+in\s+english|english\s+only|switch\s+to\s+english)\b/i,
  ];

  // Common colloquial Hinglish markers
  private static readonly HINGLISH_MARKERS = [
    /\b(kya\s+hai|kaise\s+hota|samjhao|batao|karo|hota\s+hai|hoti\s+hai|hote\s+hai)\b/i,
    /\b(mujhe|tum|tumhara|aap|mera|meri|karna|hoga|raha\s+hai|rahi\s+hai|kuch|kyun|thoda)\b/i,
    /\b(bhai|yaar|acha|theek\s+hai|chahiye|samajh\s+aaya|samajh\s+nahi)\b/i,
    /\b(mein|me|ko|ke|ki|ka|se|par|aur|bhi|nahi|na|hai|hain|ho)\b/i,
  ];

  /**
   * Resolves the target language following the strict hierarchy:
   * 1. Explicit request in current prompt (Current request wins!)
   * 2. Implicit language markers in current prompt
   * 3. Recent conversation language
   * 4. User preference from profile/memory
   * 5. Default ('en')
   */
  public static resolveLanguage(params: {
    currentPrompt: string;
    conversationHistory?: string[];
    userPreferredLanguage?: string;
  }): SupportedLanguage {
    const { currentPrompt, conversationHistory, userPreferredLanguage } = params;

    // 1. Check for EXPLICIT user language override in current prompt
    const explicit = this.detectExplicitRequest(currentPrompt);
    if (explicit) {
      return explicit;
    }

    // 2. Check for strong linguistic signals in the current prompt (e.g. Devanagari or Hinglish grammar)
    const implicit = this.detectImplicitLanguage(currentPrompt);
    if (implicit && implicit.confidence >= 0.7) {
      return implicit.detectedLanguage;
    }

    // 3. Check recent conversation history for continuity
    if (conversationHistory && conversationHistory.length > 0) {
      const recentTurns = conversationHistory.slice(-3).join(' ');
      const convLanguage = this.detectImplicitLanguage(recentTurns);
      if (convLanguage && convLanguage.confidence >= 0.6) {
        return convLanguage.detectedLanguage;
      }
    }

    // 4. Fallback to user saved preference
    if (userPreferredLanguage) {
      const normalized = userPreferredLanguage.toLowerCase().trim();
      if (normalized === 'hinglish') return 'hinglish';
      if (normalized === 'hi' || normalized === 'hindi') return 'hi';
      if (normalized === 'en' || normalized === 'english') return 'en';
    }

    // 5. Default to English
    return 'en';
  }

  /**
   * Detects if the prompt contains an explicit instruction like "in Hinglish", "in Hindi", or "in English".
   */
  public static detectExplicitRequest(text: string): SupportedLanguage | null {
    for (const pattern of this.EXPLICIT_HINGLISH_PATTERNS) {
      if (pattern.test(text)) return 'hinglish';
    }

    for (const pattern of this.EXPLICIT_HINDI_PATTERNS) {
      if (pattern.test(text)) return 'hi';
    }

    for (const pattern of this.EXPLICIT_ENGLISH_PATTERNS) {
      if (pattern.test(text)) return 'en';
    }

    return null;
  }

  /**
   * Detects implicit language markers in text.
   */
  public static detectImplicitLanguage(text: string): LanguageDetectionResult | null {
    if (!text || text.trim().length === 0) return null;

    // Devanagari script check
    const devanagariMatches = text.match(/[\u0900-\u097F]/g);
    if (devanagariMatches && devanagariMatches.length > 5) {
      return {
        detectedLanguage: 'hi',
        confidence: 0.9,
        isExplicitRequest: false,
        reason: 'Devanagari script detected',
      };
    }

    // Hinglish markers check
    let markerCount = 0;
    for (const marker of this.HINGLISH_MARKERS) {
      if (marker.test(text)) {
        markerCount++;
      }
    }

    if (markerCount >= 2) {
      return {
        detectedLanguage: 'hinglish',
        confidence: 0.85,
        isExplicitRequest: false,
        reason: `Matched ${markerCount} Hinglish grammatical markers`,
      };
    } else if (markerCount === 1) {
      return {
        detectedLanguage: 'hinglish',
        confidence: 0.65,
        isExplicitRequest: false,
        reason: 'Matched single Hinglish marker',
      };
    }

    return null;
  }
}
