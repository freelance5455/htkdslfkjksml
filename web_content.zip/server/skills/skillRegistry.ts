/**
 * JARVIS Dynamic Skill Engine
 * Skill registry providing multi-tool composition, capability discovery,
 * permission declarations, and version tracking.
 */

import type { SkillDefinition } from '../types.ts';

export class SkillRegistry {
  private skills: Map<string, SkillDefinition> = new Map();

  constructor() {
    this.registerDefaultSkills();
  }

  public registerSkill(skill: SkillDefinition): void {
    this.skills.set(skill.id, skill);
  }

  public getSkill(id: string): SkillDefinition | undefined {
    return this.skills.get(id);
  }

  public getAllSkills(): SkillDefinition[] {
    return Array.from(this.skills.values());
  }

  /**
   * Find matching skills based on task keywords or capabilities
   */
  public matchSkills(taskDescription: string): SkillDefinition[] {
    const desc = taskDescription.toLowerCase();
    const matched: SkillDefinition[] = [];

    for (const skill of this.skills.values()) {
      if (skill.status !== 'ACTIVE') continue;

      const nameMatch = desc.includes(skill.name.toLowerCase());
      const capMatch = skill.capabilities.some(
        (c) => desc.includes(c.name.toLowerCase()) || desc.includes(c.description.toLowerCase())
      );
      const toolMatch = skill.requiredTools.some((t) => desc.includes(t.replace('_', ' ')));

      if (nameMatch || capMatch || toolMatch) {
        matched.push(skill);
      }
    }

    return matched;
  }

  private registerDefaultSkills() {
    const defaultSkills: SkillDefinition[] = [
      {
        id: 'skill_deep_research',
        name: 'Autonomous Deep Research & Citation',
        description: 'Multi-stage search, document extraction, fact cross-checking, and citation verification.',
        version: '1.4.0',
        status: 'ACTIVE',
        capabilities: [
          { name: 'Multi-query Search', description: 'Expands complex topics into targeted sub-searches' },
          { name: 'Document Synthesis', description: 'Extracts claims and cross-verifies facts' },
          { name: 'Citation Auditing', description: 'Ensures assertions reference verifiable URLs and dates' },
        ],
        requiredTools: ['web_search', 'web_page_extract'],
        requiredPermissions: ['READ'],
      },
      {
        id: 'skill_code_engineer',
        name: 'Algorithmic Engineering & Test Suite Generation',
        description: 'End-to-end code synthesis, static analysis, unit test generation, and sandboxed test execution.',
        version: '2.1.0',
        status: 'ACTIVE',
        capabilities: [
          { name: 'Static Analysis', description: 'Detects code smell, complexity spikes, and unhandled errors' },
          { name: 'Test Generation', description: 'Generates boundary test matrices' },
          { name: 'Sandboxed Verification', description: 'Runs isolated execution loops with runtime telemetry' },
        ],
        requiredTools: ['code_analyzer', 'code_sandbox'],
        requiredPermissions: ['READ', 'SENSITIVE'],
      },
      {
        id: 'skill_financial_intelligence',
        name: 'Quantitative Finance & Paper Portfolio Modeling',
        description: 'Asset valuation, SIP growth simulation, risk beta estimation, and virtual paper trading.',
        version: '1.2.0',
        status: 'ACTIVE',
        capabilities: [
          { name: 'SIP Compound Projection', description: 'Mathematical wealth modeling across multiple durations' },
          { name: 'Risk/Beta Assessment', description: 'Volatility indexing and asset allocation check' },
          { name: 'Paper Trading Sandbox', description: 'Strictly simulated zero-risk virtual trade orders' },
        ],
        requiredTools: ['finance_analyzer'],
        requiredPermissions: ['READ', 'SAFE_WRITE'],
      },
      {
        id: 'skill_multimodal_vision',
        name: 'Visual Interface & Schematic Analysis',
        description: 'Screen parsing, UI diagram decomposition, and OCR extraction.',
        version: '1.0.2',
        status: 'ACTIVE',
        capabilities: [
          { name: 'UI Element Mapping', description: 'Identifies layout elements and buttons' },
          { name: 'OCR Text Ingestion', description: 'Reads text embedded within imagery' },
        ],
        requiredTools: ['vision_analyzer'],
        requiredPermissions: ['READ'],
      },
      {
        id: 'skill_automation_orchestrator',
        name: 'Gated Automation & External Trigger',
        description: 'Controlled browser action dispatch and external webhook orchestration with user approval gates.',
        version: '1.1.0',
        status: 'ACTIVE',
        capabilities: [
          { name: 'Permission Gating', description: 'Halts execution until explicit human confirmation' },
          { name: 'External Dispatch', description: 'Transmits verified payloads to external systems' },
        ],
        requiredTools: ['automation_action'],
        requiredPermissions: ['EXTERNAL_ACTION'],
      },
    ];

    for (const s of defaultSkills) {
      this.skills.set(s.id, s);
    }
  }
}

export const skillRegistry = new SkillRegistry();
