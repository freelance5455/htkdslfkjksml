import fs from 'fs';
import path from 'path';

export interface StoredQuestionRecord {
  id: string;
  fingerprint: string;
  normalizedText: string;
  subject: string;
  topic?: string;
  seenAt: string;
  examId?: string;
}

export interface UserExamHistory {
  userId: string;
  subject: string;
  totalExamsTaken: number;
  lastExamDate: string;
  seenQuestionFingerprints: string[];
  seenQuestionTexts: string[];
  seenQuestionRecords: StoredQuestionRecord[];
}

export interface ExamMCQ {
  id: string;
  questionNumber?: number;
  subject: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  shortConcept?: string;
  rememberPoint?: string;
}

const DATA_DIR = path.join(process.cwd(), 'server', 'data');
const HISTORY_FILE = path.join(DATA_DIR, 'examQuestionHistory.json');

// In-memory store backed by disk
let userExamHistories: Record<string, UserExamHistory> = {};

// Helper: Normalize question text for strict similarity/duplicate matching
export function normalizeQuestionText(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/[।.,?!:;'"(){}\[\]/\\-_*#@]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Helper: Compute signature hash for duplicate detection
export function computeQuestionFingerprint(questionText: string, options?: string[]): string {
  const normQ = normalizeQuestionText(questionText);
  // Extract key tokens (ignore very short stop words)
  const tokens = normQ.split(' ').filter(w => w.length > 2);
  const sortedSignificant = tokens.slice(0, 10).sort().join('_');
  
  let optStr = '';
  if (options && Array.isArray(options)) {
    optStr = options.map(o => normalizeQuestionText(o).slice(0, 12)).sort().join('|');
  }

  return `${normQ.slice(0, 40)}::${sortedSignificant}::${optStr.slice(0, 30)}`;
}

// Compute word overlap Jaccard similarity
export function computeQuestionSimilarity(text1: string, text2: string): number {
  const words1 = new Set(normalizeQuestionText(text1).split(' ').filter(w => w.length > 2));
  const words2 = new Set(normalizeQuestionText(text2).split(' ').filter(w => w.length > 2));
  
  if (words1.size === 0 || words2.size === 0) return 0;
  
  let intersectionCount = 0;
  words1.forEach(w => {
    if (words2.has(w)) intersectionCount++;
  });

  const unionCount = new Set([...words1, ...words2]).size;
  return unionCount === 0 ? 0 : intersectionCount / unionCount;
}

// Load persisted history from disk
export function initExamQuestionStore(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(HISTORY_FILE)) {
      const raw = fs.readFileSync(HISTORY_FILE, 'utf-8');
      userExamHistories = JSON.parse(raw);
      console.log(`[ExamStore] Loaded ${Object.keys(userExamHistories).length} user exam question histories.`);
    } else {
      userExamHistories = {};
      fs.writeFileSync(HISTORY_FILE, JSON.stringify({}, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('[ExamStore] Error initializing exam question store:', err);
    userExamHistories = {};
  }
}

// Save history to disk
function persistExamHistory(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(userExamHistories, null, 2), 'utf-8');
  } catch (err) {
    console.error('[ExamStore] Error saving exam history:', err);
  }
}

// Get store key for (userId, subject)
function getStoreKey(userId: string, subject: string): string {
  const cleanUser = (userId || 'default_user').trim().toLowerCase();
  const cleanSubj = (subject || 'General').trim().toLowerCase();
  return `${cleanUser}__${cleanSubj}`;
}

// Check if a candidate question is duplicate against user's past history or current set
export function isDuplicateQuestion(
  candidate: ExamMCQ,
  existingList: ExamMCQ[],
  userHistory?: UserExamHistory
): boolean {
  const normCandidate = normalizeQuestionText(candidate.question);
  const candFingerprint = computeQuestionFingerprint(candidate.question, candidate.options);

  if (!normCandidate || normCandidate.length < 5) return true;

  // 1. Check against current exam batch (Intra-exam deduplication)
  for (const existing of existingList) {
    const normExisting = normalizeQuestionText(existing.question);
    if (normCandidate === normExisting) return true;

    // Check high token overlap (> 65% word similarity)
    if (computeQuestionSimilarity(normCandidate, normExisting) > 0.65) {
      return true;
    }

    // Check fingerprint match
    const existingFingerprint = computeQuestionFingerprint(existing.question, existing.options);
    if (candFingerprint === existingFingerprint) return true;
  }

  // 2. Check against User's Historical Exam Questions
  if (userHistory && userHistory.seenQuestionRecords && userHistory.seenQuestionRecords.length > 0) {
    for (const record of userHistory.seenQuestionRecords) {
      if (normCandidate === record.normalizedText) return true;
      if (candFingerprint === record.fingerprint) return true;

      // High similarity check against history
      if (computeQuestionSimilarity(normCandidate, record.normalizedText) > 0.70) {
        return true;
      }
    }
  }

  return false;
}

// Retrieve user's exam question history for a subject
export function getUserExamQuestionHistory(userId: string, subject: string): UserExamHistory {
  const key = getStoreKey(userId, subject);
  if (!userExamHistories[key]) {
    userExamHistories[key] = {
      userId: userId || 'default_user',
      subject: subject || 'General',
      totalExamsTaken: 0,
      lastExamDate: new Date().toISOString(),
      seenQuestionFingerprints: [],
      seenQuestionTexts: [],
      seenQuestionRecords: []
    };
  }
  return userExamHistories[key];
}

// Record 100 generated questions into user's permanent history
export function recordDeliveredExamQuestions(
  userId: string,
  subject: string,
  questions: ExamMCQ[],
  examId?: string
): void {
  const key = getStoreKey(userId, subject);
  const history = getUserExamQuestionHistory(userId, subject);

  history.totalExamsTaken += 1;
  history.lastExamDate = new Date().toISOString();

  questions.forEach(q => {
    const normText = normalizeQuestionText(q.question);
    const fingerprint = computeQuestionFingerprint(q.question, q.options);

    if (!history.seenQuestionFingerprints.includes(fingerprint)) {
      history.seenQuestionFingerprints.push(fingerprint);
    }
    if (!history.seenQuestionTexts.includes(normText)) {
      history.seenQuestionTexts.push(normText);
    }

    history.seenQuestionRecords.push({
      id: q.id,
      fingerprint,
      normalizedText: normText,
      subject: q.subject || subject,
      topic: q.topic,
      seenAt: new Date().toISOString(),
      examId
    });
  });

  // Cap stored records to last 2,000 questions per subject to maintain performance
  if (history.seenQuestionRecords.length > 2000) {
    history.seenQuestionRecords = history.seenQuestionRecords.slice(-2000);
    history.seenQuestionFingerprints = history.seenQuestionFingerprints.slice(-2000);
    history.seenQuestionTexts = history.seenQuestionTexts.slice(-2000);
  }

  userExamHistories[key] = history;
  persistExamHistory();
  console.log(`[ExamStore] Recorded ${questions.length} questions for user: ${userId}, subject: ${subject}. Total historical questions tracked: ${history.seenQuestionRecords.length}`);
}

// Clear user history if needed (e.g. for reset)
export function clearUserSubjectHistory(userId: string, subject: string): void {
  const key = getStoreKey(userId, subject);
  if (userExamHistories[key]) {
    delete userExamHistories[key];
    persistExamHistory();
  }
}
