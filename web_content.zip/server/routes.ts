import AdmZip from 'adm-zip';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import express, { type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import fs from 'fs';
import multer from 'multer';
import os from 'os';
import path from 'path';
import { generateAndroidWebViewProject, type ApkProjectConfig } from './androidGenerator.ts';
import {
  cancelBuildJob,
  detectBuildCapabilities,
  startBuildPipeline,
} from './buildRunner.ts';
import {
  AVATARS_STORAGE_DIR,
  BUILD_ARTIFACTS_DIR,
  createNotification,
  db,
  PROJECTS_STORAGE_DIR,
  seedStarterProject,
  syncProjectFilesIndex,
} from './db.ts';
import { buildStandaloneStudioHtml } from './studioStandaloneHtml.ts';
import {
  checkBuildQuota,
  checkProjectQuota,
  incrementMonthlyBuildUsage,
  requireAdmin,
  requireAuth,
  resolveUserMembership,
  type AuthedRequest,
} from './membership.ts';
import {
  ALLOWED_ICON_EXTENSIONS,
  clearAuthCookies,
  getPaymentProviderStatus,
  getPngDimensions,
  isAllowedWebFile,
  isValidImageBuffer,
  recordAuditLog,
  safeResolveInside,
  sanitizeHexColor,
  setAuthCookies,
  signAuthToken,
  signWebhookPayload,
  validateAndroidPackageName,
  verifyPaytrCallbackHash,
  verifyWebhookSignature,
} from './security.ts';

const uploadMemory = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 60 * 1024 * 1024,
    files: 200,
  },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Çok fazla kimlik doğrulama isteği. Lütfen daha sonra tekrar deneyin.' },
});

const buildLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Derleme hız sınırına ulaşıldı. Lütfen birkaç dakika bekleyin.' },
});

function listProjectFiles(storageDir: string): Array<{ path: string; size: number; isBinary: boolean }> {
  const results: Array<{ path: string; size: number; isBinary: boolean }> = [];
  const binaryExts = new Set(['.png', '.jpg', '.jpeg', '.webp', '.ico', '.woff', '.woff2', '.ttf', '.otf']);

  function walk(dir: string, relPrefix: string) {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name.startsWith('__studio_meta')) continue;
      const full = path.join(dir, entry.name);
      const rel = relPrefix ? `${relPrefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) {
        walk(full, rel);
      } else if (entry.isFile()) {
        const st = fs.statSync(full);
        results.push({
          path: rel,
          size: st.size,
          isBinary: binaryExts.has(path.extname(entry.name).toLowerCase()),
        });
      }
    }
  }

  walk(storageDir, '');
  results.sort((a, b) => a.path.localeCompare(b.path));
  return results;
}

function getDefaultApkConfig(projectName: string): ApkProjectConfig {
  const slug =
    projectName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '')
      .slice(0, 20) || 'uygulama';
  return {
    appName: projectName.slice(0, 40) || 'HTML Uygulamam',
    packageName: `com.htmltoapk.${slug}`,
    versionName: '1.0.0',
    versionCode: 1,
    iconPreset: 'nebula',
    customIconPath: null,
    adaptiveIconEnabled: true,
    adaptiveBgColor: '#0B1020',
    customForegroundPath: null,
    splashEnabled: true,
    splashBgColor: '#0B1020',
    splashTitle: projectName.slice(0, 40) || 'HTML Uygulamam',
    splashDurationMs: 1400,
    orientation: 'unspecified',
    fullscreen: false,
    statusBarVisible: true,
    statusBarColor: '#0B1020',
    navigationBarVisible: true,
    navigationBarColor: '#0B1020',
    internetPermission: true,
    offlineEnabled: true,
    launchAnimation: 'fade',
  };
}

function getMimeType(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase();
  const map: Record<string, string> = {
    '.html': 'text/html; charset=utf-8',
    '.htm': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.mjs': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.otf': 'font/otf',
    '.txt': 'text/plain; charset=utf-8',
    '.xml': 'application/xml; charset=utf-8',
    '.webmanifest': 'application/manifest+json; charset=utf-8',
  };
  return map[ext] || 'application/octet-stream';
}

function collectSafeSourceFiles(): Array<{ path: string; size: number; isBinary: boolean }> {
  const rootDir = process.cwd();
  const rootFiles = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'server.ts',
    'index.html',
    'metadata.json',
    '.env.example',
    'README.md',
  ];
  const items: Array<{ path: string; size: number; isBinary: boolean }> = [];
  const binaryExts = new Set(['.png', '.jpg', '.jpeg', '.webp', '.ico']);

  for (const rel of rootFiles) {
    const abs = path.join(rootDir, rel);
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      items.push({ path: rel, size: fs.statSync(abs).size, isBinary: false });
    }
  }

  const walk = (absDir: string, relPrefix: string) => {
    if (!fs.existsSync(absDir)) return;
    for (const entry of fs.readdirSync(absDir, { withFileTypes: true })) {
      if (
        entry.name === 'node_modules' ||
        entry.name === 'dist' ||
        entry.name === 'data' ||
        entry.name.startsWith('.env') ||
        entry.name.endsWith('.db') ||
        entry.name.endsWith('.p12') ||
        entry.name.endsWith('.keystore')
      ) {
        continue;
      }
      const full = path.join(absDir, entry.name);
      const rel = `${relPrefix}/${entry.name}`;
      if (entry.isDirectory()) {
        walk(full, rel);
      } else if (entry.isFile()) {
        items.push({
          path: rel,
          size: fs.statSync(full).size,
          isBinary: binaryExts.has(path.extname(entry.name).toLowerCase()),
        });
      }
    }
  };

  walk(path.join(rootDir, 'src'), 'src');
  walk(path.join(rootDir, 'server'), 'server');
  walk(path.join(rootDir, 'public'), 'public');
  walk(path.join(rootDir, 'android-build'), 'android-build');
  items.sort((a, b) => a.path.localeCompare(b.path));
  return items;
}

function getSystemSetting(key: string, fallback: string): string {
  const row = db.prepare('SELECT value FROM system_settings WHERE key = ?').get(key) as
    | { value: string }
    | undefined;
  return row ? row.value : fallback;
}

function getUnreadNotificationCount(userId: string): number {
  const row = db
    .prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(userId) as { c: number };
  return row.c;
}

function evaluatePromoCode(
  rawCode: string,
  basePriceTry: number
): {
  valid: boolean;
  reason?: string;
  promoId?: string;
  code?: string;
  discountPercent?: number;
  discountTry?: number;
  finalAmountTry?: number;
} {
  const normalized = rawCode.trim().toUpperCase();
  if (!normalized) {
    return { valid: false, reason: 'Promosyon kodu boş olamaz.' };
  }

  const promo = db
    .prepare('SELECT * FROM promo_codes WHERE UPPER(code) = ?')
    .get(normalized) as
    | {
        id: string;
        code: string;
        discount_percent: number;
        max_uses: number;
        current_uses: number;
        expires_at: string | null;
        is_active: number;
      }
    | undefined;

  if (!promo) {
    return { valid: false, reason: 'Promosyon kodu bulunamadı.' };
  }
  if (!promo.is_active) {
    return { valid: false, reason: 'Bu promosyon kodu devre dışı bırakılmış.' };
  }
  if (promo.expires_at && new Date(promo.expires_at).getTime() <= Date.now()) {
    return { valid: false, reason: 'Bu promosyon kodunun süresi dolmuş.' };
  }
  if (promo.current_uses >= promo.max_uses) {
    return { valid: false, reason: 'Bu promosyon kodu maksimum kullanım sınırına ulaştı.' };
  }

  const discountTry = Math.max(
    1,
    Math.round(((basePriceTry * promo.discount_percent) / 100) * 100) / 100
  );
  const finalAmountTry = Math.max(1, Math.round((basePriceTry - discountTry) * 100) / 100);

  return {
    valid: true,
    promoId: promo.id,
    code: promo.code,
    discountPercent: promo.discount_percent,
    discountTry,
    finalAmountTry,
  };
}

export function createApiRouter(): express.Router {
  const router = express.Router();

  // ========================
  // SYSTEM & CAPABILITIES
  // ========================
  router.get('/system/capabilities', async (_req: Request, res: Response) => {
    const capabilities = await detectBuildCapabilities();
    const paymentProvider = getPaymentProviderStatus();
    res.json({
      capabilities,
      paymentProvider,
      allowRegistration: getSystemSetting('allow_registration', 'true') !== 'false',
      maintenanceMode: getSystemSetting('maintenance_mode', 'false') === 'true',
      smtpConfigured: Boolean(process.env.SMTP_HOST && process.env.SMTP_USER),
    });
  });

  // STRICT ADMIN-ONLY SOURCE ARCHIVE & SOURCE EXPLORER
  router.get('/system/source-archive', requireAuth, requireAdmin, (_req: AuthedRequest, res: Response) => {
    const rootDir = process.cwd();
    const zip = new AdmZip();

    const rootFiles = [
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'server.ts',
      'index.html',
      'metadata.json',
      '.env.example',
      '.gitignore',
      'README.md',
    ];

    for (const rel of rootFiles) {
      const abs = path.join(rootDir, rel);
      if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
        zip.addLocalFile(abs, '', rel);
      }
    }

    const addDirSafe = (absDir: string, zipRelDir: string) => {
      if (!fs.existsSync(absDir)) return;
      for (const entry of fs.readdirSync(absDir, { withFileTypes: true })) {
        if (
          entry.name === 'node_modules' ||
          entry.name === 'dist' ||
          entry.name === 'data' ||
          entry.name.startsWith('.env') ||
          entry.name.endsWith('.db') ||
          entry.name.endsWith('.p12') ||
          entry.name.endsWith('.keystore')
        ) {
          continue;
        }
        const full = path.join(absDir, entry.name);
        if (entry.isDirectory()) {
          addDirSafe(full, `${zipRelDir}/${entry.name}`);
        } else if (entry.isFile()) {
          zip.addLocalFile(full, zipRelDir);
        }
      }
    };

    addDirSafe(path.join(rootDir, 'src'), 'src');
    addDirSafe(path.join(rootDir, 'server'), 'server');
    addDirSafe(path.join(rootDir, 'public'), 'public');
    addDirSafe(path.join(rootDir, 'android-build'), 'android-build');

    const buffer = zip.toBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="html-to-apk-studio-source.zip"');
    res.setHeader('Content-Length', String(buffer.length));
    res.send(buffer);
  });

  router.get('/system/studio-html', requireAuth, requireAdmin, (_req: AuthedRequest, res: Response) => {
    const html = buildStandaloneStudioHtml();
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Disposition', 'attachment; filename="html-to-apk-studio.html"');
    res.send(html);
  });

  router.get('/system/source-files', requireAuth, requireAdmin, (_req: AuthedRequest, res: Response) => {
    res.json({ files: collectSafeSourceFiles() });
  });

  router.get('/system/source-file', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const relPath = String(req.query.path || '').trim();
    const safeList = collectSafeSourceFiles();
    const allowed = safeList.find((f) => f.path === relPath);
    if (!allowed) {
      res.status(404).json({ error: 'Dosya bulunamadı veya erişim izni yok.' });
      return;
    }
    const target = safeResolveInside(process.cwd(), allowed.path);
    if (req.query.download === '1') {
      res.download(target, path.basename(allowed.path));
      return;
    }
    if (allowed.isBinary) {
      res.json({
        path: allowed.path,
        content: '[Görsel dosyası — indirmek için İndir butonunu kullanın]',
      });
      return;
    }
    res.json({ path: allowed.path, content: fs.readFileSync(target, 'utf8') });
  });

  // ========================
  // AUTHENTICATION & ACCOUNT
  // ========================
  router.post('/auth/register', authLimiter, (req: Request, res: Response) => {
    if (getSystemSetting('allow_registration', 'true') === 'false') {
      res.status(403).json({ error: 'Yeni kullanıcı kayıtları yönetici tarafından geçici olarak kapatılmıştır.' });
      return;
    }

    const { username, email, password } = req.body || {};
    if (!username || typeof username !== 'string' || username.trim().length < 2) {
      res.status(400).json({ error: 'Kullanıcı adı en az 2 karakter olmalıdır.' });
      return;
    }
    if (!email || typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      res.status(400).json({ error: 'Geçerli bir e-posta adresi girin.' });
      return;
    }
    if (!password || typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'Şifre en az 6 karakter olmalıdır.' });
      return;
    }

    const emailNormalized = email.trim().toLowerCase();
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(emailNormalized);
    if (existing) {
      res.status(409).json({ error: 'Bu e-posta adresi zaten kayıtlı.' });
      return;
    }

    const userId = `usr_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();
    const hash = bcrypt.hashSync(password, 12);

    db.prepare(
      'INSERT INTO users (id, username, email, password_hash, role, theme_pref, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(userId, username.trim().slice(0, 50), emailNormalized, hash, 'user', 'dark', now, now);

    seedStarterProject(userId, now);

    createNotification({
      userId,
      type: 'info',
      title: 'HTML TO APK STUDIO’ya Hoş Geldiniz',
      message: 'Örnek HTML projeniz hazırlandı. Hemen önizleyip gerçek Android APK olarak derleyebilirsiniz.',
      linkSection: 'projects',
    });

    const token = signAuthToken({ userId, email: emailNormalized, role: 'user' });
    const csrfToken = setAuthCookies(req, res, token);
    const membership = resolveUserMembership(userId);
    recordAuditLog({
      actorUserId: userId,
      action: 'USER_REGISTERED',
      targetType: 'user',
      targetId: userId,
      ipAddress: req.ip || null,
    });

    res.status(201).json({
      token,
      csrfToken,
      user: {
        id: userId,
        username: username.trim(),
        email: emailNormalized,
        role: 'user',
        avatarUrl: null,
        bio: null,
        themePref: 'dark',
        createdAt: now,
      },
      membership,
      payments: [],
      unreadNotifications: getUnreadNotificationCount(userId),
    });
  });

  router.post('/auth/login', authLimiter, (req: Request, res: Response) => {
    const { email, password } = req.body || {};
    if (!email || !password) {
      res.status(400).json({ error: 'E-posta ve şifre gereklidir.' });
      return;
    }

    const emailNormalized = String(email).trim().toLowerCase();
    const user = db
      .prepare('SELECT id, username, email, password_hash, role, avatar_url, bio, theme_pref, created_at FROM users WHERE email = ?')
      .get(emailNormalized) as
      | {
          id: string;
          username: string;
          email: string;
          password_hash: string;
          role: 'user' | 'admin';
          avatar_url: string | null;
          bio: string | null;
          theme_pref: string | null;
          created_at: string;
        }
      | undefined;

    if (!user || !bcrypt.compareSync(String(password), user.password_hash)) {
      res.status(401).json({ error: 'E-posta veya şifre hatalı.' });
      return;
    }

    const token = signAuthToken({ userId: user.id, email: user.email, role: user.role });
    const csrfToken = setAuthCookies(req, res, token);
    const membership = resolveUserMembership(user.id);
    const payments = db
      .prepare(
        `SELECT p.*, sp.name as plan_name, sp.code as plan_code
         FROM payments p
         JOIN subscription_plans sp ON p.plan_id = sp.id
         WHERE p.user_id = ?
         ORDER BY p.created_at DESC`
      )
      .all(user.id);

    res.json({
      token,
      csrfToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        avatarUrl: user.avatar_url,
        bio: user.bio,
        themePref: user.theme_pref === 'light' ? 'light' : 'dark',
        createdAt: user.created_at,
      },
      membership,
      payments,
      unreadNotifications: getUnreadNotificationCount(user.id),
    });
  });

  router.post('/auth/logout', (req: Request, res: Response) => {
    clearAuthCookies(req, res);
    res.json({ ok: true });
  });

  router.post('/auth/forgot-password', authLimiter, (req: Request, res: Response) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Geçerli bir e-posta adresi girin.' });
      return;
    }

    const smtpConfigured = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER);
    const user = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email) as
      | { id: string; email: string }
      | undefined;

    if (user) {
      const rawToken = crypto.randomBytes(24).toString('hex');
      const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
      const now = new Date().toISOString();
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

      db.prepare('DELETE FROM password_resets WHERE user_id = ? AND used_at IS NULL').run(user.id);
      db.prepare(
        'INSERT INTO password_resets (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(`pwr_${crypto.randomUUID().slice(0, 10)}`, user.id, tokenHash, expiresAt, now);

      console.info(
        `[PasswordReset] ${user.email} için şifre sıfırlama kodu oluşturuldu (30 dk geçerli): ${rawToken}`
      );
      recordAuditLog({
        actorUserId: user.id,
        action: 'PASSWORD_RESET_REQUESTED',
        targetType: 'user',
        targetId: user.id,
        ipAddress: req.ip || null,
      });
    }

    res.json({
      ok: true,
      smtpConfigured,
      message: smtpConfigured
        ? 'Eğer e-posta adresi sistemde kayıtlıysa şifre sıfırlama kodu gönderildi.'
        : 'SMTP e-posta sunucusu (.env içinde SMTP_HOST / SMTP_USER) yapılandırılmadığı için e-posta gönderilemedi. Sıfırlama jetonu sunucu günlüğüne kaydedildi.',
    });
  });

  router.post('/auth/reset-password', authLimiter, (req: Request, res: Response) => {
    const { token, newPassword } = req.body || {};
    if (!token || typeof token !== 'string') {
      res.status(400).json({ error: 'Sıfırlama kodu gereklidir.' });
      return;
    }
    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 6) {
      res.status(400).json({ error: 'Yeni şifre en az 6 karakter olmalıdır.' });
      return;
    }

    const tokenHash = crypto.createHash('sha256').update(token.trim()).digest('hex');
    const resetRow = db
      .prepare(
        'SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL ORDER BY created_at DESC LIMIT 1'
      )
      .get(tokenHash) as
      | { id: string; user_id: string; expires_at: string }
      | undefined;

    if (!resetRow || new Date(resetRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Sıfırlama kodu geçersiz veya süresi dolmuş.' });
      return;
    }

    const now = new Date().toISOString();
    const newHash = bcrypt.hashSync(newPassword, 12);

    db.transaction(() => {
      db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
        newHash,
        now,
        resetRow.user_id
      );
      db.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRow.id);
    })();

    recordAuditLog({
      actorUserId: resetRow.user_id,
      action: 'PASSWORD_RESET_COMPLETED',
      targetType: 'user',
      targetId: resetRow.user_id,
      ipAddress: req.ip || null,
    });

    res.json({ ok: true, message: 'Şifreniz başarıyla sıfırlandı. Şimdi yeni şifrenizle giriş yapabilirsiniz.' });
  });

  router.get('/auth/me', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = db
      .prepare('SELECT id, username, email, role, avatar_url, bio, theme_pref, created_at FROM users WHERE id = ?')
      .get(req.authUser!.id) as {
      id: string;
      username: string;
      email: string;
      role: 'user' | 'admin';
      avatar_url: string | null;
      bio: string | null;
      theme_pref: string | null;
      created_at: string;
    };

    const payments = db
      .prepare(
        `SELECT p.*, sp.name as plan_name, sp.code as plan_code
         FROM payments p
         JOIN subscription_plans sp ON p.plan_id = sp.id
         WHERE p.user_id = ?
         ORDER BY p.created_at DESC`
      )
      .all(user.id);

    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        avatarUrl: user.avatar_url,
        bio: user.bio,
        themePref: user.theme_pref === 'light' ? 'light' : 'dark',
        createdAt: user.created_at,
      },
      membership: req.membership,
      payments,
      unreadNotifications: getUnreadNotificationCount(user.id),
    });
  });

  router.put('/auth/profile', requireAuth, (req: AuthedRequest, res: Response) => {
    const { username, bio, themePref } = req.body || {};
    const nextUsername = String(username ?? req.authUser!.username).trim().slice(0, 50);
    if (nextUsername.length < 2) {
      res.status(400).json({ error: 'Kullanıcı adı en az 2 karakter olmalıdır.' });
      return;
    }
    const nextBio = typeof bio === 'string' ? bio.trim().slice(0, 300) : req.authUser!.bio || null;
    const nextTheme = themePref === 'light' ? 'light' : themePref === 'dark' ? 'dark' : req.authUser!.themePref || 'dark';
    const now = new Date().toISOString();

    db.prepare('UPDATE users SET username = ?, bio = ?, theme_pref = ?, updated_at = ? WHERE id = ?').run(
      nextUsername,
      nextBio,
      nextTheme,
      now,
      req.authUser!.id
    );

    res.json({
      ok: true,
      user: {
        id: req.authUser!.id,
        username: nextUsername,
        email: req.authUser!.email,
        role: req.authUser!.role,
        avatarUrl: req.authUser!.avatarUrl || null,
        bio: nextBio,
        themePref: nextTheme,
      },
    });
  });

  router.post(
    '/auth/avatar',
    requireAuth,
    uploadMemory.single('avatar'),
    (req: AuthedRequest, res: Response) => {
      const file = req.file;
      if (!file) {
        res.status(400).json({ error: 'Profil fotoğrafı seçilmedi.' });
        return;
      }
      if (file.size > 3 * 1024 * 1024) {
        res.status(400).json({ error: 'Profil fotoğrafı en fazla 3 MB olabilir.' });
        return;
      }
      const imgCheck = isValidImageBuffer(file.buffer);
      if (!imgCheck.valid || !imgCheck.type) {
        res.status(400).json({ error: 'Yalnızca geçerli PNG, JPG veya WEBP görselleri kabul edilir.' });
        return;
      }

      const ext = imgCheck.type === 'jpeg' ? '.jpg' : `.${imgCheck.type}`;
      for (const existing of fs.readdirSync(AVATARS_STORAGE_DIR)) {
        if (existing.startsWith(req.authUser!.id)) {
          fs.rmSync(path.join(AVATARS_STORAGE_DIR, existing), { force: true });
        }
      }

      const filePath = path.join(AVATARS_STORAGE_DIR, `${req.authUser!.id}${ext}`);
      fs.writeFileSync(filePath, file.buffer);
      const avatarUrl = `/api/users/${req.authUser!.id}/avatar?v=${Date.now()}`;
      db.prepare('UPDATE users SET avatar_url = ?, updated_at = ? WHERE id = ?').run(
        avatarUrl,
        new Date().toISOString(),
        req.authUser!.id
      );

      res.json({ ok: true, avatarUrl });
    }
  );

  router.get('/users/:id/avatar', (req: Request, res: Response) => {
    const uid = String(req.params.id || '').replace(/[^a-zA-Z0-9_-]/g, '');
    if (!uid) {
      res.status(404).end();
      return;
    }
    const candidates = ['.png', '.jpg', '.webp'].map((ext) => path.join(AVATARS_STORAGE_DIR, `${uid}${ext}`));
    const found = candidates.find((c) => fs.existsSync(c));
    if (!found) {
      res.status(404).end();
      return;
    }
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(found);
  });

  router.put('/auth/password', requireAuth, (req: AuthedRequest, res: Response) => {
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword || String(newPassword).length < 6) {
      res.status(400).json({ error: 'Mevcut şifre ve en az 6 karakterli yeni şifre gereklidir.' });
      return;
    }

    const row = db
      .prepare('SELECT password_hash FROM users WHERE id = ?')
      .get(req.authUser!.id) as { password_hash: string } | undefined;

    if (!row || !bcrypt.compareSync(String(currentPassword), row.password_hash)) {
      res.status(401).json({ error: 'Mevcut şifreniz hatalı.' });
      return;
    }

    const newHash = bcrypt.hashSync(String(newPassword), 12);
    db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
      newHash,
      new Date().toISOString(),
      req.authUser!.id
    );

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'USER_PASSWORD_CHANGED',
      targetType: 'user',
      targetId: req.authUser!.id,
      ipAddress: req.ip || null,
    });

    createNotification({
      userId: req.authUser!.id,
      type: 'info',
      title: 'Şifre Güncellendi',
      message: 'Hesap şifreniz güvenli şekilde değiştirildi.',
      linkSection: 'account',
    });

    res.json({ ok: true });
  });

  // ========================
  // NOTIFICATIONS
  // ========================
  router.get('/notifications', requireAuth, (req: AuthedRequest, res: Response) => {
    const notifications = db
      .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 60')
      .all(req.authUser!.id);
    res.json({
      notifications,
      unreadCount: getUnreadNotificationCount(req.authUser!.id),
    });
  });

  router.post('/notifications/:id/read', requireAuth, (req: AuthedRequest, res: Response) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(
      req.params.id,
      req.authUser!.id
    );
    res.json({ ok: true, unreadCount: getUnreadNotificationCount(req.authUser!.id) });
  });

  router.post('/notifications/read-all', requireAuth, (req: AuthedRequest, res: Response) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.authUser!.id);
    res.json({ ok: true, unreadCount: 0 });
  });

  // ========================
  // PROJECTS & UPLOAD
  // ========================
  router.get('/projects', requireAuth, (req: AuthedRequest, res: Response) => {
    const projects = db
      .prepare(
        `SELECT p.*,
          (SELECT COUNT(*) FROM builds b WHERE b.project_id = p.id) as build_count,
          (SELECT b.status FROM builds b WHERE b.project_id = p.id ORDER BY b.created_at DESC LIMIT 1) as last_build_status
         FROM projects p
         WHERE p.user_id = ?
         ORDER BY p.updated_at DESC`
      )
      .all(req.authUser!.id) as Array<Record<string, unknown>>;

    res.json({
      projects: projects.map((p) => ({
        ...p,
        config: JSON.parse(String(p.config_json)),
      })),
    });
  });

  router.post(
    '/projects/create',
    requireAuth,
    checkProjectQuota,
    (req: AuthedRequest, res: Response) => {
      const { name, htmlContent, cssContent, jsContent, packageName } = req.body || {};
      const projectName = String(name || 'Yeni HTML Projesi').trim().slice(0, 60);
      const config = getDefaultApkConfig(projectName);

      if (packageName) {
        const check = validateAndroidPackageName(String(packageName));
        if (!check.valid) {
          res.status(400).json({ error: check.reason });
          return;
        }
        config.packageName = String(packageName).trim();
      }

      const projectId = `prj_${crypto.randomUUID().slice(0, 10)}`;
      const storageDir = path.join(PROJECTS_STORAGE_DIR, projectId);
      fs.mkdirSync(path.join(storageDir, 'css'), { recursive: true });
      fs.mkdirSync(path.join(storageDir, 'js'), { recursive: true });

      const html =
        typeof htmlContent === 'string' && htmlContent.trim()
          ? htmlContent
          : `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${projectName}</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main class="container">
    <h1>${projectName}</h1>
    <p>HTML TO APK STUDIO ile Android WebView uygulamasına dönüştürülmeye hazır.</p>
    <button id="actionBtn" type="button">Etkileşimi Test Et</button>
    <p id="statusText"></p>
  </main>
  <script src="js/app.js"></script>
</body>
</html>
`;

      const css =
        typeof cssContent === 'string'
          ? cssContent
          : `body {
  margin: 0; font-family: system-ui, -apple-system, sans-serif;
  background: #0b1020; color: #f8fafc; min-height: 100vh;
  display: grid; place-items: center; padding: 24px;
}
.container {
  max-width: 420px; width: 100%; background: #151d2e;
  border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 24px;
}
button {
  margin-top: 12px; background: #6366f1; color: #fff;
  border: none; border-radius: 8px; padding: 10px 16px; font-weight: 600; cursor: pointer;
}
`;

      const js =
        typeof jsContent === 'string'
          ? jsContent
          : `document.getElementById('actionBtn')?.addEventListener('click', () => {
  const el = document.getElementById('statusText');
  if (el) el.textContent = 'WebView JavaScript motoru sorunsuz çalışıyor (' + new Date().toLocaleTimeString('tr-TR') + ')';
});
`;

      fs.writeFileSync(path.join(storageDir, 'index.html'), html, 'utf8');
      fs.writeFileSync(path.join(storageDir, 'css', 'style.css'), css, 'utf8');
      fs.writeFileSync(path.join(storageDir, 'js', 'app.js'), js, 'utf8');

      const totalSize = Buffer.byteLength(html) + Buffer.byteLength(css) + Buffer.byteLength(js);
      const now = new Date().toISOString();

      db.prepare(
        `INSERT INTO projects (id, user_id, name, entry_file, total_files, total_size_bytes, config_json, storage_dir, created_at, updated_at)
         VALUES (?, ?, ?, 'index.html', 3, ?, ?, ?, ?, ?)`
      ).run(projectId, req.authUser!.id, projectName, totalSize, JSON.stringify(config), storageDir, now, now);

      syncProjectFilesIndex(projectId, req.authUser!.id, storageDir);

      res.status(201).json({
        project: {
          id: projectId,
          name: projectName,
          entry_file: 'index.html',
          total_files: 3,
          total_size_bytes: totalSize,
          config,
          files: listProjectFiles(storageDir),
          created_at: now,
          updated_at: now,
        },
      });
    }
  );

  router.post(
    '/projects/seed-sample',
    requireAuth,
    checkProjectQuota,
    (req: AuthedRequest, res: Response) => {
      const now = new Date().toISOString();
      const projectId = seedStarterProject(req.authUser!.id, now);
      const project = db
        .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
        .get(projectId, req.authUser!.id) as Record<string, unknown>;

      const storageDir = String(project.storage_dir);
      const files = listProjectFiles(storageDir);
      const htmlFiles = files.filter((f) => /\.(html|htm)$/i.test(f.path)).map((f) => f.path);

      res.status(201).json({
        project: {
          ...project,
          config: JSON.parse(String(project.config_json)),
          files,
          htmlFiles,
        },
      });
    }
  );

  router.post(
    '/projects/upload',
    requireAuth,
    checkProjectQuota,
    uploadMemory.array('files', 200),
    (req: AuthedRequest, res: Response) => {
      const uploadedFiles = req.files as Express.Multer.File[] | undefined;
      if (!uploadedFiles || uploadedFiles.length === 0) {
        res.status(400).json({ error: 'Yüklenecek dosya seçilmedi.' });
        return;
      }

      const maxUploadBytes = (req.membership?.limits.maxUploadMb || 10) * 1024 * 1024;
      const totalIncomingBytes = uploadedFiles.reduce((acc, f) => acc + f.size, 0);
      if (totalIncomingBytes > maxUploadBytes) {
        res.status(413).json({
          error: `Toplam yükleme boyutu paketinize tanımlı ${req.membership?.limits.maxUploadMb} MB sınırını aşıyor.`,
          upgradeRequired: !req.membership?.isPremium,
        });
        return;
      }

      const rawName = String(req.body?.name || '').trim();
      const firstFileName = path.basename(uploadedFiles[0].originalname, path.extname(uploadedFiles[0].originalname));
      const projectName = (rawName || firstFileName || 'Yüklenen Proje').slice(0, 60);

      const projectId = `prj_${crypto.randomUUID().slice(0, 10)}`;
      const storageDir = path.join(PROJECTS_STORAGE_DIR, projectId);
      fs.mkdirSync(storageDir, { recursive: true });

      try {
        let totalExtractedBytes = 0;
        let totalFilesSaved = 0;

        let relativePaths: string[] = [];
        if (req.body?.relativePaths) {
          try {
            relativePaths = JSON.parse(String(req.body.relativePaths));
          } catch {
            relativePaths = [];
          }
        }

        for (let i = 0; i < uploadedFiles.length; i++) {
          const file = uploadedFiles[i];
          const ext = path.extname(file.originalname).toLowerCase();

          if (ext === '.zip') {
            const zip = new AdmZip(file.buffer);
            const entries = zip.getEntries();

            const nonDirEntries = entries.filter((e) => !e.isDirectory && !e.entryName.startsWith('__MACOSX/'));
            let commonRootPrefix = '';
            if (nonDirEntries.length > 0) {
              const firstSegs = nonDirEntries.map((e) => e.entryName.replace(/\\/g, '/').split('/')[0]);
              const allHaveFolder = nonDirEntries.every((e) => e.entryName.replace(/\\/g, '/').includes('/'));
              if (allHaveFolder && firstSegs.every((s) => s === firstSegs[0])) {
                commonRootPrefix = `${firstSegs[0]}/`;
              }
            }

            for (const entry of nonDirEntries) {
              let entryRel = entry.entryName.replace(/\\/g, '/');
              if (commonRootPrefix && entryRel.startsWith(commonRootPrefix)) {
                entryRel = entryRel.slice(commonRootPrefix.length);
              }
              if (!entryRel || entryRel.startsWith('.')) continue;
              if (!isAllowedWebFile(entryRel)) continue;

              const destAbs = safeResolveInside(storageDir, entryRel);
              const data = entry.getData();
              totalExtractedBytes += data.length;
              if (totalExtractedBytes > maxUploadBytes * 2) {
                throw new Error('Açılan ZIP arşivi güvenlik boyut sınırını aşıyor (Zip Bomb koruması).');
              }

              fs.mkdirSync(path.dirname(destAbs), { recursive: true });
              fs.writeFileSync(destAbs, data);
              totalFilesSaved += 1;
            }
          } else {
            if (!isAllowedWebFile(file.originalname)) {
              throw new Error(`Desteklenmeyen dosya türü: ${file.originalname}`);
            }
            const rel = relativePaths[i] || file.originalname;
            const cleanRel = rel.replace(/\\/g, '/').replace(/^\/+/, '');
            const destAbs = safeResolveInside(storageDir, cleanRel);
            totalExtractedBytes += file.buffer.length;
            fs.mkdirSync(path.dirname(destAbs), { recursive: true });
            fs.writeFileSync(destAbs, file.buffer);
            totalFilesSaved += 1;
          }
        }

        const files = listProjectFiles(storageDir);
        if (files.length === 0) {
          throw new Error('Proje içinde geçerli HTML, CSS, JS veya medya dosyası bulunamadı.');
        }

        const htmlFiles = files.filter((f) => /\.(html|htm)$/i.test(f.path)).map((f) => f.path);
        let entryFile = '';
        let entryFileNeedsSelection = false;

        if (htmlFiles.includes('index.html')) {
          entryFile = 'index.html';
        } else if (htmlFiles.length === 1) {
          entryFile = htmlFiles[0];
        } else if (htmlFiles.length > 1) {
          entryFile = htmlFiles[0];
          entryFileNeedsSelection = true;
        } else {
          throw new Error('Projede en az bir .html giriş dosyası bulunmalıdır.');
        }

        const config = getDefaultApkConfig(projectName);
        const now = new Date().toISOString();

        db.prepare(
          `INSERT INTO projects (id, user_id, name, entry_file, total_files, total_size_bytes, config_json, storage_dir, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          projectId,
          req.authUser!.id,
          projectName,
          entryFile,
          totalFilesSaved,
          totalExtractedBytes,
          JSON.stringify(config),
          storageDir,
          now,
          now
        );

        syncProjectFilesIndex(projectId, req.authUser!.id, storageDir);

        res.status(201).json({
          entryFileNeedsSelection,
          htmlFiles,
          project: {
            id: projectId,
            name: projectName,
            entry_file: entryFile,
            total_files: totalFilesSaved,
            total_size_bytes: totalExtractedBytes,
            config,
            files,
            created_at: now,
            updated_at: now,
          },
        });
      } catch (err) {
        fs.rmSync(storageDir, { recursive: true, force: true });
        res.status(400).json({
          error: err instanceof Error ? err.message : 'Dosya yükleme başarısız oldu.',
        });
      }
    }
  );

  router.get('/projects/:id', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const storageDir = String(project.storage_dir);
    const files = listProjectFiles(storageDir);
    const htmlFiles = files.filter((f) => /\.(html|htm)$/i.test(f.path)).map((f) => f.path);
    const builds = db
      .prepare('SELECT * FROM builds WHERE project_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(project.id, req.authUser!.id) as Array<Record<string, unknown>>;

    res.json({
      project: {
        ...project,
        config: JSON.parse(String(project.config_json)),
        files,
        htmlFiles,
      },
      builds: builds.map((b) => ({
        ...b,
        logs: JSON.parse(String(b.logs_json || '[]')),
      })),
    });
  });

  router.put('/projects/:id/config', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const currentConfig: ApkProjectConfig = JSON.parse(String(project.config_json));
    const incoming = req.body || {};

    const nextConfig: ApkProjectConfig = {
      ...currentConfig,
      ...incoming,
    };

    const pkgValidation = validateAndroidPackageName(nextConfig.packageName);
    if (!pkgValidation.valid) {
      res.status(400).json({ error: pkgValidation.reason });
      return;
    }

    if (
      (nextConfig.iconPreset === 'aurum' || nextConfig.iconPreset === 'cobalt') &&
      !req.membership?.limits.premiumIcons
    ) {
      res.status(403).json({
        error: 'Seçilen uygulama ikonu Premium üyelik gerektirir.',
        upgradeRequired: true,
      });
      return;
    }

    const projectName = String(incoming.projectName || project.name).trim().slice(0, 60) || String(project.name);
    const now = new Date().toISOString();

    db.prepare('UPDATE projects SET name = ?, config_json = ?, updated_at = ? WHERE id = ?').run(
      projectName,
      JSON.stringify(nextConfig),
      now,
      project.id
    );

    res.json({
      name: projectName,
      config: nextConfig,
      updated_at: now,
    });
  });

  router.put('/projects/:id/entry', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const entryFile = String(req.body?.entryFile || '').trim();
    try {
      const resolved = safeResolveInside(String(project.storage_dir), entryFile);
      if (!fs.existsSync(resolved) || !/\.(html|htm)$/i.test(resolved)) {
        res.status(400).json({ error: 'Seçilen giriş HTML dosyası projede bulunamadı.' });
        return;
      }
      db.prepare('UPDATE projects SET entry_file = ?, updated_at = ? WHERE id = ?').run(
        entryFile,
        new Date().toISOString(),
        project.id
      );
      res.json({ entry_file: entryFile });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Geçersiz dosya yolu.' });
    }
  });

  // Upload custom app icon + multi-density Android mipmap PNGs + optional adaptive foreground
  router.post(
    '/projects/:id/icon',
    requireAuth,
    uploadMemory.fields([
      { name: 'icon', maxCount: 1 },
      { name: 'foreground', maxCount: 1 },
      { name: 'mipmap_mdpi', maxCount: 1 },
      { name: 'mipmap_hdpi', maxCount: 1 },
      { name: 'mipmap_xhdpi', maxCount: 1 },
      { name: 'mipmap_xxhdpi', maxCount: 1 },
      { name: 'mipmap_xxxhdpi', maxCount: 1 },
    ]),
    (req: AuthedRequest, res: Response) => {
      const project = db
        .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
        .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

      if (!project) {
        res.status(404).json({ error: 'Proje bulunamadı.' });
        return;
      }

      const filesMap = (req.files || {}) as Record<string, Express.Multer.File[]>;
      const file = filesMap.icon?.[0];
      if (!file) {
        res.status(400).json({ error: 'İkon dosyası yüklenmedi.' });
        return;
      }

      const ext = path.extname(file.originalname).toLowerCase();
      if (!ALLOWED_ICON_EXTENSIONS.has(ext)) {
        res.status(400).json({ error: 'İkon yalnızca PNG, JPG veya WEBP formatında olabilir.' });
        return;
      }

      const imgCheck = isValidImageBuffer(file.buffer);
      if (!imgCheck.valid) {
        res.status(400).json({ error: 'Yüklenen dosya geçerli bir görsel değil (imza doğrulanamadı).' });
        return;
      }

      const pngDim = imgCheck.type === 'png' ? getPngDimensions(file.buffer) : null;
      const isSquare = pngDim ? pngDim.width === pngDim.height : true;

      const metaDir = path.join(String(project.storage_dir), '__studio_meta');
      fs.mkdirSync(metaDir, { recursive: true });
      for (const existing of fs.readdirSync(metaDir)) {
        if (existing.startsWith('custom_icon') || existing.startsWith('custom_foreground')) {
          fs.rmSync(path.join(metaDir, existing), { force: true });
        }
      }

      const iconRel = `__studio_meta/custom_icon${ext}`;
      fs.writeFileSync(path.join(String(project.storage_dir), iconRel), file.buffer);

      // Store pre-rendered Android mipmap resolutions if provided
      const mipmapRoot = path.join(metaDir, 'mipmaps');
      fs.rmSync(mipmapRoot, { recursive: true, force: true });
      const densityKeys = ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'] as const;
      const generatedDensities: string[] = [];
      for (const d of densityKeys) {
        const dFile = filesMap[`mipmap_${d}`]?.[0];
        if (dFile && isValidImageBuffer(dFile.buffer).valid) {
          const densityDir = path.join(mipmapRoot, `mipmap-${d}`);
          fs.mkdirSync(densityDir, { recursive: true });
          fs.writeFileSync(path.join(densityDir, 'ic_launcher.png'), dFile.buffer);
          generatedDensities.push(`mipmap-${d}`);
        }
      }

      let fgRel: string | null = null;
      const fgFile = filesMap.foreground?.[0];
      if (fgFile && isValidImageBuffer(fgFile.buffer).valid) {
        fgRel = '__studio_meta/custom_foreground.png';
        fs.writeFileSync(path.join(String(project.storage_dir), fgRel), fgFile.buffer);
      }

      const config: ApkProjectConfig = JSON.parse(String(project.config_json));
      config.iconPreset = 'custom';
      config.customIconPath = iconRel;
      config.customForegroundPath = fgRel || iconRel;
      if (req.body?.adaptiveIconEnabled !== undefined) {
        config.adaptiveIconEnabled = req.body.adaptiveIconEnabled === 'true' || req.body.adaptiveIconEnabled === true;
      } else {
        config.adaptiveIconEnabled = true;
      }
      if (req.body?.adaptiveBgColor) {
        config.adaptiveBgColor = sanitizeHexColor(req.body.adaptiveBgColor, '#0B1020');
      }

      db.prepare('UPDATE projects SET config_json = ?, updated_at = ? WHERE id = ?').run(
        JSON.stringify(config),
        new Date().toISOString(),
        project.id
      );

      res.json({
        config,
        validation: {
          isSquare,
          dimensions: pngDim,
          generatedDensities,
        },
      });
    }
  );

  router.get('/projects/:id/icon-preview', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!project) {
      res.status(404).end();
      return;
    }

    const config: ApkProjectConfig = JSON.parse(String(project.config_json));
    const relTarget =
      req.query.variant === 'foreground' && config.customForegroundPath
        ? config.customForegroundPath
        : config.customIconPath;

    if (relTarget) {
      try {
        const abs = safeResolveInside(String(project.storage_dir), relTarget);
        if (fs.existsSync(abs)) {
          res.setHeader('Cache-Control', 'no-store');
          res.sendFile(abs);
          return;
        }
      } catch {
        // ignore
      }
    }
    res.status(404).end();
  });

  router.get('/projects/:id/file', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const relPath = String(req.query.path || '');
    try {
      const target = safeResolveInside(String(project.storage_dir), relPath);
      if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
        res.status(404).json({ error: 'Dosya bulunamadı.' });
        return;
      }
      const content = fs.readFileSync(target, 'utf8');
      res.json({ path: relPath, content });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Dosya okunamadı.' });
    }
  });

  router.put('/projects/:id/file', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const { path: relPath, content } = req.body || {};
    if (!relPath || typeof content !== 'string') {
      res.status(400).json({ error: 'Dosya yolu ve içeriği gereklidir.' });
      return;
    }
    if (!isAllowedWebFile(String(relPath))) {
      res.status(400).json({ error: 'Bu dosya uzantısına izin verilmiyor.' });
      return;
    }

    try {
      const target = safeResolveInside(String(project.storage_dir), String(relPath));
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, content, 'utf8');

      const files = listProjectFiles(String(project.storage_dir));
      const totalSize = files.reduce((s, f) => s + f.size, 0);
      db.prepare(
        'UPDATE projects SET total_files = ?, total_size_bytes = ?, updated_at = ? WHERE id = ?'
      ).run(files.length, totalSize, new Date().toISOString(), project.id);

      syncProjectFilesIndex(String(project.id), req.authUser!.id, String(project.storage_dir));

      res.json({ ok: true, files });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Dosya kaydedilemedi.' });
    }
  });

  router.delete('/projects/:id', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as { id: string; storage_dir: string } | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const builds = db
      .prepare('SELECT artifact_path FROM builds WHERE project_id = ?')
      .all(project.id) as Array<{ artifact_path: string | null }>;
    for (const b of builds) {
      if (b.artifact_path && fs.existsSync(b.artifact_path)) {
        fs.rmSync(b.artifact_path, { force: true });
      }
    }

    db.prepare('DELETE FROM projects WHERE id = ?').run(project.id);
    if (project.storage_dir && fs.existsSync(project.storage_dir)) {
      fs.rmSync(project.storage_dir, { recursive: true, force: true });
    }

    res.json({ ok: true });
  });

  // Live HTML Preview Static Asset Server
  router.get('/projects/:id/preview/*', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as { storage_dir: string; entry_file: string } | undefined;

    if (!project) {
      res.status(404).send('Proje bulunamadı.');
      return;
    }

    const reqSubPath = (req.params as Record<string, string>)[0] || project.entry_file;
    try {
      const target = safeResolveInside(project.storage_dir, reqSubPath);
      if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
        res.status(404).send('Dosya bulunamadı.');
        return;
      }

      const ext = path.extname(target).toLowerCase();
      res.setHeader('Content-Type', getMimeType(target));
      res.setHeader('Cache-Control', 'no-store');

      if (ext === '.html' || ext === '.htm') {
        let html = fs.readFileSync(target, 'utf8');
        const errorReporter = `<script>
(function(){
  function sendErr(type, msg){
    try { window.parent.postMessage({ source: 'html-apk-preview', type: type, message: String(msg) }, '*'); } catch(e){}
  }
  window.addEventListener('error', function(e){ sendErr('error', (e.message || 'Hata') + (e.filename ? ' (' + e.filename.split('/').pop() + ':' + e.lineno + ')' : '')); });
  window.addEventListener('unhandledrejection', function(e){ sendErr('error', 'Promise Hatası: ' + (e.reason && e.reason.message ? e.reason.message : e.reason)); });
  var origErr = console.error;
  console.error = function(){ sendErr('console', Array.from(arguments).join(' ')); origErr.apply(console, arguments); };
})();
</script>`;
        if (html.includes('</head>')) {
          html = html.replace('</head>', `${errorReporter}</head>`);
        } else {
          html = errorReporter + html;
        }
        res.send(html);
        return;
      }

      res.sendFile(target);
    } catch {
      res.status(400).send('Geçersiz önizleme yolu.');
    }
  });

  router.get('/projects/:id/android-preview', requireAuth, (req: AuthedRequest, res: Response) => {
    const project = db
      .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as
      | { storage_dir: string; entry_file: string; config_json: string }
      | undefined;

    if (!project) {
      res.status(404).json({ error: 'Proje bulunamadı.' });
      return;
    }

    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'apk-inspect-'));
    try {
      const config: ApkProjectConfig = JSON.parse(project.config_json);
      generateAndroidWebViewProject({
        workDir: tmpDir,
        projectStorageDir: project.storage_dir,
        entryFile: project.entry_file,
        config,
      });

      const pkgPath = config.packageName.split('.').join('/');
      const mainKt = fs.readFileSync(path.join(tmpDir, `app/src/main/kotlin/${pkgPath}/MainActivity.kt`), 'utf8');
      const manifest = fs.readFileSync(path.join(tmpDir, 'app/src/main/AndroidManifest.xml'), 'utf8');
      const gradle = fs.readFileSync(path.join(tmpDir, 'app/build.gradle.kts'), 'utf8');
      const dockerfile = fs.readFileSync(path.join(tmpDir, 'Dockerfile'), 'utf8');

      res.json({ mainKt, manifest, gradle, dockerfile });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Android kaynak kodu oluşturulamadı.' });
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  // ========================
  // BUILD PIPELINE ROUTES
  // ========================
  router.post(
    '/build',
    requireAuth,
    buildLimiter,
    checkBuildQuota,
    (req: AuthedRequest, res: Response) => {
      if (getSystemSetting('maintenance_mode', 'false') === 'true' && req.authUser!.role !== 'admin') {
        res.status(503).json({ error: 'Sistem şu anda bakım modundadır; yeni derlemeler geçici olarak durduruldu.' });
        return;
      }

      const { projectId } = req.body || {};
      if (!projectId) {
        res.status(400).json({ error: 'Proje kimliği (projectId) gereklidir.' });
        return;
      }

      const project = db
        .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
        .get(projectId, req.authUser!.id) as
        | { id: string; config_json: string; entry_file: string }
        | undefined;

      if (!project) {
        res.status(404).json({ error: 'Proje bulunamadı.' });
        return;
      }

      const config: ApkProjectConfig = JSON.parse(project.config_json);
      const pkgCheck = validateAndroidPackageName(config.packageName);
      if (!pkgCheck.valid) {
        res.status(400).json({ error: pkgCheck.reason });
        return;
      }

      const buildId = `bld_${crypto.randomUUID().slice(0, 10)}`;
      const now = new Date().toISOString();
      const isPriority = req.membership?.limits.priorityQueue ? 1 : 0;

      const initialLogs = [
        {
          timestamp: now,
          stage: 'Kuyruğa alındı',
          level: 'info',
          message: isPriority
            ? 'Öncelikli Premium derleme kuyruğuna eklendi.'
            : 'Standart derleme kuyruğuna eklendi.',
        },
      ];

      db.prepare(
        `INSERT INTO builds (id, project_id, user_id, status, stage, stage_index, total_stages, build_mode, logs_json, is_priority, created_at)
         VALUES (?, ?, ?, 'queued', 'Kuyruğa alındı', 0, 12, 'pending', ?, ?, ?)`
      ).run(buildId, project.id, req.authUser!.id, JSON.stringify(initialLogs), isPriority, now);

      incrementMonthlyBuildUsage(req.authUser!.id);

      setImmediate(() => {
        void startBuildPipeline(buildId);
      });

      res.status(202).json({
        buildId,
        status: 'queued',
        isPriority: Boolean(isPriority),
      });
    }
  );

  router.get('/builds', requireAuth, (req: AuthedRequest, res: Response) => {
    const builds = db
      .prepare(
        `SELECT b.*, p.name as project_name, p.config_json
         FROM builds b
         JOIN projects p ON b.project_id = p.id
         WHERE b.user_id = ?
         ORDER BY b.created_at DESC
         LIMIT 50`
      )
      .all(req.authUser!.id) as Array<Record<string, unknown>>;

    res.json({
      builds: builds.map((b) => {
        const cfg = JSON.parse(String(b.config_json || '{}'));
        return {
          ...b,
          package_name: cfg.packageName || '',
          app_name: cfg.appName || b.project_name,
          version_name: cfg.versionName || '1.0.0',
          logs: JSON.parse(String(b.logs_json || '[]')),
        };
      }),
    });
  });

  router.get('/build/:id/status', requireAuth, (req: AuthedRequest, res: Response) => {
    const build = db
      .prepare('SELECT * FROM builds WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as Record<string, unknown> | undefined;

    if (!build) {
      res.status(404).json({ error: 'Derleme kaydı bulunamadı.' });
      return;
    }

    res.json({
      build: {
        ...build,
        logs: JSON.parse(String(build.logs_json || '[]')),
      },
    });
  });

  router.get('/build/:id/download', requireAuth, (req: AuthedRequest, res: Response) => {
    const build = db
      .prepare('SELECT * FROM builds WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id) as
      | {
          id: string;
          status: string;
          artifact_path: string | null;
          artifact_filename: string | null;
        }
      | undefined;

    if (!build) {
      res.status(404).json({ error: 'Derleme kaydı bulunamadı.' });
      return;
    }

    if (!build.artifact_path || !fs.existsSync(build.artifact_path)) {
      res.status(404).json({ error: 'İndirilecek derleme çıktısı bulunamadı.' });
      return;
    }

    const resolvedArtifact = path.resolve(build.artifact_path);
    const resolvedRoot = path.resolve(BUILD_ARTIFACTS_DIR);
    if (!resolvedArtifact.startsWith(resolvedRoot + path.sep)) {
      res.status(403).json({ error: 'Güvenlik engeli: Geçersiz dosya yolu.' });
      return;
    }

    res.download(resolvedArtifact, build.artifact_filename || 'android-build-output.zip');
  });

  router.post('/build/:id/cancel', requireAuth, (req: AuthedRequest, res: Response) => {
    const build = db
      .prepare('SELECT id FROM builds WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.authUser!.id);

    if (!build) {
      res.status(404).json({ error: 'Derleme kaydı bulunamadı.' });
      return;
    }

    const cancelled = cancelBuildJob(req.params.id);
    res.json({ ok: cancelled });
  });

  // ========================
  // PREMIUM PLANS, PROMO CODES & PAYMENTS
  // ========================
  router.get('/plans', (_req: Request, res: Response) => {
    const plans = db
      .prepare('SELECT * FROM subscription_plans ORDER BY price_try ASC')
      .all() as Array<Record<string, unknown>>;
    const limits = db.prepare('SELECT * FROM system_limits').all();
    const provider = getPaymentProviderStatus();

    res.json({
      plans: plans.map((p) => ({
        ...p,
        features: JSON.parse(String(p.features_json || '[]')),
      })),
      limits,
      paymentProvider: provider,
    });
  });

  router.post('/promo-codes/validate', requireAuth, (req: AuthedRequest, res: Response) => {
    const { code, planId } = req.body || {};
    if (!code || !planId) {
      res.status(400).json({ error: 'Promosyon kodu ve paket seçimi gereklidir.' });
      return;
    }

    const plan = db
      .prepare('SELECT id, name, price_try FROM subscription_plans WHERE id = ? OR code = ?')
      .get(planId, planId) as { id: string; name: string; price_try: number } | undefined;

    if (!plan) {
      res.status(404).json({ error: 'Paket bulunamadı.' });
      return;
    }

    const evalRes = evaluatePromoCode(String(code), plan.price_try);
    if (!evalRes.valid) {
      res.status(400).json({ error: evalRes.reason });
      return;
    }

    res.json({
      ok: true,
      code: evalRes.code,
      discountPercent: evalRes.discountPercent,
      originalAmountTry: plan.price_try,
      discountTry: evalRes.discountTry,
      finalAmountTry: evalRes.finalAmountTry,
    });
  });

  router.post('/payments/checkout', requireAuth, (req: AuthedRequest, res: Response) => {
    const { planId, promoCode } = req.body || {};
    if (!planId) {
      res.status(400).json({ error: 'Paket seçimi (planId) gereklidir.' });
      return;
    }

    const plan = db
      .prepare('SELECT * FROM subscription_plans WHERE id = ? OR code = ?')
      .get(planId, planId) as
      | {
          id: string;
          code: string;
          name: string;
          price_try: number;
          duration_days: number | null;
          is_lifetime: number;
        }
      | undefined;

    if (!plan) {
      res.status(404).json({ error: 'Seçilen üyelik paketi bulunamadı.' });
      return;
    }

    let finalAmountTry = plan.price_try;
    let discountTry = 0;
    let promoCodeId: string | null = null;
    let appliedPromoCode: string | null = null;

    if (promoCode && String(promoCode).trim()) {
      const evalRes = evaluatePromoCode(String(promoCode), plan.price_try);
      if (!evalRes.valid) {
        res.status(400).json({ error: evalRes.reason });
        return;
      }
      finalAmountTry = evalRes.finalAmountTry!;
      discountTry = evalRes.discountTry!;
      promoCodeId = evalRes.promoId!;
      appliedPromoCode = evalRes.code!;
    }

    const providerStatus = getPaymentProviderStatus();
    const paymentId = `pay_${crypto.randomUUID().slice(0, 12)}`;
    const providerRef = `REF-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const now = new Date().toISOString();

    const signedPayload = JSON.stringify({
      paymentId,
      userId: req.authUser!.id,
      planId: plan.id,
      amountTry: finalAmountTry,
      originalAmountTry: plan.price_try,
      discountTry,
      promoCodeId,
      providerRef,
    });
    const checkoutSignature = signWebhookPayload(signedPayload);

    db.prepare(
      `INSERT INTO payments (id, user_id, plan_id, provider, provider_reference, amount_try, original_amount_try, discount_try, promo_code_id, currency, status, is_test_mode, checkout_token, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'TRY', 'pending', ?, ?, ?)`
    ).run(
      paymentId,
      req.authUser!.id,
      plan.id,
      providerStatus.provider,
      providerRef,
      finalAmountTry,
      plan.price_try,
      discountTry,
      promoCodeId,
      providerStatus.isLiveConfigured ? 0 : 1,
      checkoutSignature,
      now
    );

    db.prepare(
      `INSERT INTO payment_events (id, payment_id, event_type, signature_verified, payload_json, created_at)
       VALUES (?, ?, 'checkout_session_created', 1, ?, ?)`
    ).run(`pev_${crypto.randomUUID().slice(0, 10)}`, paymentId, signedPayload, now);

    res.status(201).json({
      payment: {
        id: paymentId,
        planId: plan.id,
        planName: plan.name,
        originalAmountTry: plan.price_try,
        discountTry,
        appliedPromoCode,
        amountTry: finalAmountTry,
        currency: 'TRY',
        provider: providerStatus.provider,
        providerLabel: providerStatus.label,
        isTestMode: !providerStatus.isLiveConfigured,
        providerReference: providerRef,
        signedPayload,
        checkoutSignature,
      },
    });
  });

  router.post('/payments/webhook/verify', (req: Request, res: Response) => {
    const {
      paymentId,
      signedPayload,
      signature,
      outcome,
      merchant_oid,
      status: paytrStatus,
      total_amount,
      hash: paytrHash,
    } = req.body || {};

    const now = new Date().toISOString();

    if (merchant_oid && paytrHash) {
      const ok = verifyPaytrCallbackHash({
        merchantOid: String(merchant_oid),
        status: String(paytrStatus),
        totalAmount: String(total_amount),
        receivedHash: String(paytrHash),
      });
      if (!ok) {
        res.status(403).send('PAYTR notification failed: bad hash');
        return;
      }
      const payment = db
        .prepare('SELECT * FROM payments WHERE provider_reference = ?')
        .get(String(merchant_oid)) as
        | { id: string; user_id: string; plan_id: string; status: string; amount_try: number }
        | undefined;
      if (!payment) {
        res.status(404).send('Payment not found');
        return;
      }
      if (payment.status === 'completed') {
        res.send('OK');
        return;
      }
      if (paytrStatus === 'success') {
        finalizePaymentAndGrantSubscription(payment.id, true, req.body, now);
      } else {
        db.prepare(`UPDATE payments SET status = 'failed' WHERE id = ?`).run(payment.id);
      }
      res.send('OK');
      return;
    }

    if (!paymentId || !signedPayload || !signature) {
      res.status(400).json({ error: 'Ödeme doğrulama imzası eksik.' });
      return;
    }

    const sigValid = verifyWebhookSignature(String(signedPayload), String(signature));
    if (!sigValid) {
      db.prepare(
        `INSERT INTO payment_events (id, payment_id, event_type, signature_verified, payload_json, created_at)
         VALUES (?, ?, 'invalid_signature', 0, ?, ?)`
      ).run(`pev_${crypto.randomUUID().slice(0, 10)}`, String(paymentId), JSON.stringify(req.body), now);
      res.status(403).json({ error: 'Webhook imza doğrulaması başarısız oldu.' });
      return;
    }

    const parsed = JSON.parse(String(signedPayload)) as {
      paymentId: string;
      userId: string;
      planId: string;
      amountTry: number;
    };

    const payment = db
      .prepare('SELECT * FROM payments WHERE id = ?')
      .get(parsed.paymentId) as
      | {
          id: string;
          user_id: string;
          plan_id: string;
          amount_try: number;
          status: string;
          is_test_mode: number;
        }
      | undefined;

    if (!payment) {
      res.status(404).json({ error: 'Ödeme kaydı bulunamadı.' });
      return;
    }

    if (payment.status === 'completed') {
      res.status(409).json({ error: 'Bu ödeme zaten işlendi ve üyelik tanımlandı.' });
      return;
    }

    if (outcome === 'failed') {
      db.prepare(`UPDATE payments SET status = 'failed' WHERE id = ?`).run(payment.id);
      db.prepare(
        `INSERT INTO payment_events (id, payment_id, event_type, signature_verified, payload_json, created_at)
         VALUES (?, ?, 'payment_failed', 1, ?, ?)`
      ).run(`pev_${crypto.randomUUID().slice(0, 10)}`, payment.id, String(signedPayload), now);
      res.json({ ok: false, status: 'failed' });
      return;
    }

    const subscription = finalizePaymentAndGrantSubscription(payment.id, true, parsed, now);
    const membership = resolveUserMembership(payment.user_id);

    res.json({
      ok: true,
      status: 'completed',
      isTestMode: Boolean(payment.is_test_mode),
      subscription,
      membership,
    });
  });

  // ========================
  // ADMIN PANEL ROUTES
  // ========================
  router.get('/admin/overview', requireAuth, requireAdmin, (_req: AuthedRequest, res: Response) => {
    const users = db
      .prepare('SELECT id, username, email, role, avatar_url, created_at FROM users ORDER BY created_at DESC')
      .all() as Array<{
      id: string;
      username: string;
      email: string;
      role: 'user' | 'admin';
      avatar_url: string | null;
      created_at: string;
    }>;

    const usersWithMembership = users.map((u) => ({
      ...u,
      membership: resolveUserMembership(u.id),
    }));

    const builds = db
      .prepare(
        `SELECT b.*, p.name as project_name, p.config_json, u.email as owner_email, u.username as owner_username
         FROM builds b
         JOIN projects p ON b.project_id = p.id
         JOIN users u ON b.user_id = u.id
         ORDER BY b.created_at DESC
         LIMIT 80`
      )
      .all() as Array<Record<string, unknown>>;

    const parsedBuilds = builds.map((b) => {
      const cfg = JSON.parse(String(b.config_json || '{}'));
      return {
        ...b,
        package_name: cfg.packageName || '',
        app_name: cfg.appName || b.project_name,
        version_name: cfg.versionName || '1.0.0',
        logs: JSON.parse(String(b.logs_json || '[]')),
      };
    });

    const payments = db
      .prepare(
        `SELECT p.*, u.email as user_email, u.username, sp.name as plan_name, pc.code as promo_code
         FROM payments p
         JOIN users u ON p.user_id = u.id
         JOIN subscription_plans sp ON p.plan_id = sp.id
         LEFT JOIN promo_codes pc ON p.promo_code_id = pc.id
         ORDER BY p.created_at DESC
         LIMIT 100`
      )
      .all() as Array<Record<string, unknown>>;

    const plans = db
      .prepare('SELECT * FROM subscription_plans ORDER BY price_try ASC')
      .all() as Array<Record<string, unknown>>;

    const limits = db.prepare('SELECT * FROM system_limits').all();

    const promoCodes = db.prepare('SELECT * FROM promo_codes ORDER BY created_at DESC').all();

    const settingsRows = db.prepare('SELECT key, value, updated_at FROM system_settings').all() as Array<{
      key: string;
      value: string;
      updated_at: string;
    }>;
    const systemSettings: Record<string, string> = {};
    for (const s of settingsRows) systemSettings[s.key] = s.value;

    const errorLogs = db
      .prepare(
        `SELECT e.*, u.email as user_email
         FROM error_logs e
         LEFT JOIN users u ON e.user_id = u.id
         ORDER BY e.created_at DESC
         LIMIT 60`
      )
      .all();

    const auditLogs = db
      .prepare(
        `SELECT a.*, u.email as actor_email
         FROM audit_logs a
         LEFT JOIN users u ON a.actor_user_id = u.id
         ORDER BY a.created_at DESC
         LIMIT 80`
      )
      .all();

    const projectCountRow = db.prepare('SELECT COUNT(*) as c FROM projects').get() as { c: number };
    const totalBuildsRow = db.prepare('SELECT COUNT(*) as c FROM builds').get() as { c: number };
    const completedBuildsRow = db
      .prepare(`SELECT COUNT(*) as c FROM builds WHERE status IN ('completed_apk', 'completed_bundle')`)
      .get() as { c: number };
    const failedBuildsRow = db
      .prepare(`SELECT COUNT(*) as c FROM builds WHERE status = 'failed'`)
      .get() as { c: number };

    const revenueSummary = db
      .prepare(
        `SELECT COALESCE(SUM(amount_try), 0) as totalRevenue FROM payments WHERE status = 'completed'`
      )
      .get() as { totalRevenue: number };

    const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString();
    const monthlyRevenueRow = db
      .prepare(
        `SELECT COALESCE(SUM(amount_try), 0) as monthlyRevenue FROM payments WHERE status = 'completed' AND completed_at >= ?`
      )
      .get(thirtyDaysAgo) as { monthlyRevenue: number };

    const revenueByPlan = db
      .prepare(
        `SELECT sp.name as plan_name, COUNT(p.id) as sales_count, COALESCE(SUM(p.amount_try), 0) as revenue_try
         FROM subscription_plans sp
         LEFT JOIN payments p ON p.plan_id = sp.id AND p.status = 'completed'
         GROUP BY sp.id, sp.name
         ORDER BY sp.price_try ASC`
      )
      .all();

    const activePromosRow = db
      .prepare('SELECT COUNT(*) as c FROM promo_codes WHERE is_active = 1')
      .get() as { c: number };

    res.json({
      stats: {
        totalUsers: usersWithMembership.length,
        premiumUsers: usersWithMembership.filter((u) => u.membership.isPremium).length,
        totalProjects: projectCountRow.c,
        totalBuilds: totalBuildsRow.c,
        completedBuilds: completedBuildsRow.c,
        failedBuilds: failedBuildsRow.c,
        totalRevenueTry: revenueSummary.totalRevenue,
        monthlyRevenueTry: monthlyRevenueRow.monthlyRevenue,
        activePromoCodes: activePromosRow.c,
      },
      revenueByPlan,
      users: usersWithMembership,
      builds: parsedBuilds,
      payments,
      promoCodes,
      plans: plans.map((p) => ({
        ...p,
        features: JSON.parse(String(p.features_json || '[]')),
      })),
      limits,
      systemSettings,
      errorLogs,
      auditLogs,
    });
  });

  router.get('/admin/builds/:id/download', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const build = db
      .prepare('SELECT id, artifact_path, artifact_filename FROM builds WHERE id = ?')
      .get(req.params.id) as
      | { id: string; artifact_path: string | null; artifact_filename: string | null }
      | undefined;

    if (!build || !build.artifact_path || !fs.existsSync(build.artifact_path)) {
      res.status(404).json({ error: 'İndirilecek derleme çıktısı bulunamadı.' });
      return;
    }

    const resolvedArtifact = path.resolve(build.artifact_path);
    const resolvedRoot = path.resolve(BUILD_ARTIFACTS_DIR);
    if (!resolvedArtifact.startsWith(resolvedRoot + path.sep)) {
      res.status(403).json({ error: 'Güvenlik engeli: Geçersiz dosya yolu.' });
      return;
    }

    res.download(resolvedArtifact, build.artifact_filename || 'android-build-output.apk');
  });

  router.put('/admin/users/:id/role', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const targetId = req.params.id;
    const role = req.body?.role === 'admin' ? 'admin' : req.body?.role === 'user' ? 'user' : null;
    if (!role) {
      res.status(400).json({ error: 'Geçersiz rol değeri.' });
      return;
    }
    if (targetId === req.authUser!.id && role !== 'admin') {
      res.status(400).json({ error: 'Kendi yönetici yetkinizi düşüremezsiniz.' });
      return;
    }

    db.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?').run(
      role,
      new Date().toISOString(),
      targetId
    );

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_UPDATE_USER_ROLE',
      targetType: 'user',
      targetId,
      details: { role },
      ipAddress: req.ip || null,
    });

    res.json({ ok: true });
  });

  router.post('/admin/promo-codes', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const { code, discountPercent, maxUses, expiresAt } = req.body || {};
    const cleanCode = String(code || '')
      .trim()
      .toUpperCase()
      .replace(/[^A-Z0-9_-]/g, '');

    if (cleanCode.length < 3 || cleanCode.length > 32) {
      res.status(400).json({ error: 'Promosyon kodu 3-32 karakter (A-Z, 0-9, _ veya -) olmalıdır.' });
      return;
    }

    const pct = Math.round(Number(discountPercent));
    if (!Number.isFinite(pct) || pct < 1 || pct > 95) {
      res.status(400).json({ error: 'İndirim oranı %1 ile %95 arasında olmalıdır.' });
      return;
    }

    const limit = Math.max(1, Math.round(Number(maxUses) || 100));
    const existing = db.prepare('SELECT id FROM promo_codes WHERE UPPER(code) = ?').get(cleanCode);
    if (existing) {
      res.status(409).json({ error: 'Bu promosyon kodu zaten mevcut.' });
      return;
    }

    const id = `prm_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();
    const expIso = expiresAt ? new Date(String(expiresAt)).toISOString() : null;

    db.prepare(
      `INSERT INTO promo_codes (id, code, discount_percent, max_uses, current_uses, expires_at, is_active, created_by, created_at)
       VALUES (?, ?, ?, ?, 0, ?, 1, ?, ?)`
    ).run(id, cleanCode, pct, limit, expIso, req.authUser!.id, now);

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_CREATE_PROMO',
      targetType: 'promo_code',
      targetId: id,
      details: { code: cleanCode, discountPercent: pct, maxUses: limit, expiresAt: expIso },
      ipAddress: req.ip || null,
    });

    res.status(201).json({ ok: true, id });
  });

  router.put('/admin/promo-codes/:id', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const promo = db.prepare('SELECT * FROM promo_codes WHERE id = ?').get(req.params.id) as
      | { id: string; is_active: number }
      | undefined;
    if (!promo) {
      res.status(404).json({ error: 'Promosyon kodu bulunamadı.' });
      return;
    }

    const isActive = req.body?.is_active !== undefined ? (req.body.is_active ? 1 : 0) : promo.is_active;
    db.prepare('UPDATE promo_codes SET is_active = ? WHERE id = ?').run(isActive, promo.id);

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_TOGGLE_PROMO',
      targetType: 'promo_code',
      targetId: promo.id,
      details: { is_active: Boolean(isActive) },
      ipAddress: req.ip || null,
    });

    res.json({ ok: true });
  });

  router.delete('/admin/promo-codes/:id', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    db.prepare('DELETE FROM promo_codes WHERE id = ?').run(req.params.id);
    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_DELETE_PROMO',
      targetType: 'promo_code',
      targetId: req.params.id,
      ipAddress: req.ip || null,
    });
    res.json({ ok: true });
  });

  router.put('/admin/settings', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const allowedKeys = new Set([
      'allow_registration',
      'maintenance_mode',
      'default_build_timeout_ms',
      'max_global_upload_mb',
    ]);
    const incoming = req.body || {};
    const now = new Date().toISOString();
    const stmt = db.prepare(
      'INSERT INTO system_settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at'
    );

    db.transaction(() => {
      for (const [k, v] of Object.entries(incoming)) {
        if (allowedKeys.has(k)) {
          stmt.run(k, String(v), now);
        }
      }
    })();

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_UPDATE_SETTINGS',
      targetType: 'system_settings',
      details: incoming,
      ipAddress: req.ip || null,
    });

    res.json({ ok: true });
  });

  router.post(
    '/admin/subscriptions/grant',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const { userId, planId } = req.body || {};
      if (!userId || !planId) {
        res.status(400).json({ error: 'Kullanıcı ve paket seçimi gereklidir.' });
        return;
      }

      const plan = db
        .prepare('SELECT * FROM subscription_plans WHERE id = ? OR code = ?')
        .get(planId, planId) as
        | { id: string; name: string; duration_days: number | null; is_lifetime: number }
        | undefined;
      if (!plan) {
        res.status(404).json({ error: 'Paket bulunamadı.' });
        return;
      }

      const now = new Date();
      const nowIso = now.toISOString();
      const expiresAt =
        plan.is_lifetime === 1 || !plan.duration_days
          ? null
          : new Date(now.getTime() + plan.duration_days * 86400000).toISOString();

      db.transaction(() => {
        db.prepare(
          `UPDATE subscriptions SET status = 'cancelled', updated_at = ? WHERE user_id = ? AND status = 'active'`
        ).run(nowIso, userId);

        db.prepare(
          `INSERT INTO subscriptions (id, user_id, plan_id, status, started_at, expires_at, is_lifetime, granted_by, created_at, updated_at)
           VALUES (?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)`
        ).run(
          `sub_${crypto.randomUUID().slice(0, 10)}`,
          userId,
          plan.id,
          nowIso,
          expiresAt,
          plan.is_lifetime,
          req.authUser!.id,
          nowIso,
          nowIso
        );
      })();

      createNotification({
        userId,
        type: 'success',
        title: 'Premium Üyelik Tanımlandı',
        message: `Hesabınıza "${plan.name}" üyeliği tanımlandı.`,
        linkSection: 'account',
      });

      recordAuditLog({
        actorUserId: req.authUser!.id,
        action: 'ADMIN_GRANT_PREMIUM',
        targetType: 'user',
        targetId: userId,
        details: { planId: plan.id, planName: plan.name, expiresAt },
        ipAddress: req.ip || null,
      });

      res.json({ ok: true, membership: resolveUserMembership(userId) });
    }
  );

  router.post(
    '/admin/subscriptions/:id/extend',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const days = Math.max(1, Math.min(3650, Number(req.body?.days) || 30));
      const sub = db
        .prepare('SELECT * FROM subscriptions WHERE id = ?')
        .get(req.params.id) as
        | { id: string; user_id: string; is_lifetime: number; expires_at: string | null }
        | undefined;

      if (!sub) {
        res.status(404).json({ error: 'Abonelik kaydı bulunamadı.' });
        return;
      }
      if (sub.is_lifetime === 1) {
        res.status(400).json({ error: 'Kalıcı Premium üyeliğin süresi zaten süresizdir.' });
        return;
      }

      const baseDate =
        sub.expires_at && new Date(sub.expires_at).getTime() > Date.now()
          ? new Date(sub.expires_at)
          : new Date();
      const nextExpires = new Date(baseDate.getTime() + days * 86400000).toISOString();

      db.prepare(
        `UPDATE subscriptions SET status = 'active', expires_at = ?, updated_at = ? WHERE id = ?`
      ).run(nextExpires, new Date().toISOString(), sub.id);

      recordAuditLog({
        actorUserId: req.authUser!.id,
        action: 'ADMIN_EXTEND_SUBSCRIPTION',
        targetType: 'subscription',
        targetId: sub.id,
        details: { userId: sub.user_id, addedDays: days, nextExpires },
        ipAddress: req.ip || null,
      });

      res.json({ ok: true, nextExpires });
    }
  );

  router.post(
    '/admin/subscriptions/:id/cancel',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const sub = db
        .prepare('SELECT * FROM subscriptions WHERE id = ?')
        .get(req.params.id) as { id: string; user_id: string } | undefined;

      if (!sub) {
        res.status(404).json({ error: 'Abonelik bulunamadı.' });
        return;
      }

      db.prepare(`UPDATE subscriptions SET status = 'cancelled', updated_at = ? WHERE id = ?`).run(
        new Date().toISOString(),
        sub.id
      );

      recordAuditLog({
        actorUserId: req.authUser!.id,
        action: 'ADMIN_CANCEL_SUBSCRIPTION',
        targetType: 'subscription',
        targetId: sub.id,
        details: { userId: sub.user_id },
        ipAddress: req.ip || null,
      });

      res.json({ ok: true });
    }
  );

  router.put('/admin/plans/:id', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const { price_try, duration_days } = req.body || {};
    const price = Number(price_try);
    if (!Number.isFinite(price) || price <= 0) {
      res.status(400).json({ error: 'Geçerli bir paket fiyatı girin.' });
      return;
    }

    const plan = db
      .prepare('SELECT * FROM subscription_plans WHERE id = ?')
      .get(req.params.id) as { id: string; is_lifetime: number; duration_days: number | null } | undefined;
    if (!plan) {
      res.status(404).json({ error: 'Paket bulunamadı.' });
      return;
    }

    const nextDuration =
      plan.is_lifetime === 1 ? null : Math.max(1, Number(duration_days) || plan.duration_days || 30);

    db.prepare(
      'UPDATE subscription_plans SET price_try = ?, duration_days = ?, updated_at = ? WHERE id = ?'
    ).run(price, nextDuration, new Date().toISOString(), plan.id);

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_UPDATE_PLAN',
      targetType: 'subscription_plan',
      targetId: plan.id,
      details: { price_try: price, duration_days: nextDuration },
      ipAddress: req.ip || null,
    });

    res.json({ ok: true });
  });

  router.put('/admin/limits/:tier', requireAuth, requireAdmin, (req: AuthedRequest, res: Response) => {
    const tier = req.params.tier;
    if (tier !== 'free' && tier !== 'premium') {
      res.status(400).json({ error: 'Geçersiz üyelik seviyesi.' });
      return;
    }

    const { max_projects, monthly_builds, max_upload_mb, priority_queue, premium_icons, ad_free } =
      req.body || {};

    db.prepare(
      `UPDATE system_limits
       SET max_projects = ?, monthly_builds = ?, max_upload_mb = ?, priority_queue = ?, premium_icons = ?, ad_free = ?, updated_at = ?
       WHERE tier = ?`
    ).run(
      Math.max(1, Number(max_projects) || 1),
      Math.max(1, Number(monthly_builds) || 1),
      Math.max(1, Number(max_upload_mb) || 5),
      priority_queue ? 1 : 0,
      premium_icons ? 1 : 0,
      ad_free ? 1 : 0,
      new Date().toISOString(),
      tier
    );

    recordAuditLog({
      actorUserId: req.authUser!.id,
      action: 'ADMIN_UPDATE_LIMITS',
      targetType: 'system_limits',
      targetId: tier,
      details: { max_projects, monthly_builds, max_upload_mb, priority_queue, premium_icons, ad_free },
      ipAddress: req.ip || null,
    });

    res.json({ ok: true });
  });

  // ========================
  // ADMIN-ONLY CODE & ARTIFACTS EXPLORER
  // ========================
  router.get(
    '/admin/code-explorer/tree',
    requireAuth,
    requireAdmin,
    (_req: AuthedRequest, res: Response) => {
      const builds = db
        .prepare(
          `SELECT b.id, b.project_id, b.status, b.build_mode, b.artifact_filename, b.artifact_size_bytes, b.sha256, b.created_at, b.completed_at,
                  p.name as project_name, p.config_json, u.email as owner_email, u.username as owner_username
           FROM builds b
           JOIN projects p ON b.project_id = p.id
           JOIN users u ON b.user_id = u.id
           ORDER BY b.created_at DESC
           LIMIT 50`
        )
        .all() as Array<Record<string, unknown>>;

      const projects = db
        .prepare(
          `SELECT p.id, p.name, p.entry_file, p.config_json, p.storage_dir, p.updated_at, u.email as owner_email, u.username as owner_username
           FROM projects p
           JOIN users u ON p.user_id = u.id
           ORDER BY p.updated_at DESC
           LIMIT 40`
        )
        .all() as Array<Record<string, unknown>>;

      res.json({
        builds: builds.map((b) => {
          const cfg = JSON.parse(String(b.config_json || '{}'));
          return {
            id: b.id,
            project_id: b.project_id,
            project_name: b.project_name,
            app_name: cfg.appName || b.project_name,
            package_name: cfg.packageName || '',
            version_name: cfg.versionName || '1.0.0',
            version_code: cfg.versionCode || 1,
            status: b.status,
            build_mode: b.build_mode,
            artifact_filename: b.artifact_filename,
            artifact_size_bytes: b.artifact_size_bytes,
            sha256: b.sha256,
            owner_email: b.owner_email,
            owner_username: b.owner_username,
            created_at: b.created_at,
            completed_at: b.completed_at,
          };
        }),
        projects: projects.map((p) => {
          const cfg = JSON.parse(String(p.config_json || '{}'));
          const files = fs.existsSync(String(p.storage_dir))
            ? listProjectFiles(String(p.storage_dir))
            : [];
          return {
            id: p.id,
            name: p.name,
            entry_file: p.entry_file,
            package_name: cfg.packageName || '',
            version_name: cfg.versionName || '1.0.0',
            owner_email: p.owner_email,
            owner_username: p.owner_username,
            updated_at: p.updated_at,
            files,
          };
        }),
        platformFiles: collectSafeSourceFiles(),
      });
    }
  );

  router.get(
    '/admin/code-explorer/project-file',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const projectId = String(req.query.projectId || '').trim();
      const relPath = String(req.query.path || '').trim();
      const project = db
        .prepare('SELECT id, storage_dir FROM projects WHERE id = ?')
        .get(projectId) as { id: string; storage_dir: string } | undefined;

      if (!project) {
        res.status(404).json({ error: 'Proje bulunamadı.' });
        return;
      }

      try {
        const target = safeResolveInside(project.storage_dir, relPath);
        if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
          res.status(404).json({ error: 'Dosya bulunamadı.' });
          return;
        }
        if (req.query.download === '1') {
          res.download(target, path.basename(relPath));
          return;
        }
        const binaryExts = new Set(['.png', '.jpg', '.jpeg', '.webp', '.ico', '.woff', '.woff2', '.ttf']);
        if (binaryExts.has(path.extname(target).toLowerCase())) {
          res.json({
            path: relPath,
            content: '[İkili görsel/font dosyası — indirmek için Dosyayı İndir butonunu kullanın]',
          });
          return;
        }
        res.json({ path: relPath, content: fs.readFileSync(target, 'utf8') });
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'Dosya okunamadı.' });
      }
    }
  );

  router.get(
    '/admin/code-explorer/project-zip',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const projectId = String(req.query.projectId || '').trim();
      const project = db
        .prepare('SELECT * FROM projects WHERE id = ?')
        .get(projectId) as
        | { id: string; name: string; entry_file: string; config_json: string; storage_dir: string }
        | undefined;

      if (!project || !fs.existsSync(project.storage_dir)) {
        res.status(404).json({ error: 'Proje bulunamadı.' });
        return;
      }

      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'apk-admin-zip-'));
      try {
        const config: ApkProjectConfig = JSON.parse(project.config_json);
        generateAndroidWebViewProject({
          workDir: tmpDir,
          projectStorageDir: project.storage_dir,
          entryFile: project.entry_file,
          config,
        });

        const zip = new AdmZip();
        zip.addLocalFolder(tmpDir);
        const buffer = zip.toBuffer();
        const slug = config.packageName.replace(/[^a-z0-9_.-]/gi, '_');
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${slug}-full-android-and-web-source.zip"`
        );
        res.setHeader('Content-Length', String(buffer.length));
        res.send(buffer);
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'ZIP oluşturulamadı.' });
      } finally {
        fs.rmSync(tmpDir, { recursive: true, force: true });
      }
    }
  );

  router.get(
    '/admin/code-explorer/android-files',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const projectId = String(req.query.projectId || '').trim();
      const project = db
        .prepare('SELECT * FROM projects WHERE id = ?')
        .get(projectId) as
        | { id: string; entry_file: string; config_json: string; storage_dir: string }
        | undefined;

      if (!project || !fs.existsSync(project.storage_dir)) {
        res.status(404).json({ error: 'Proje bulunamadı.' });
        return;
      }

      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'apk-admin-inspect-'));
      try {
        const config: ApkProjectConfig = JSON.parse(project.config_json);
        const generated = generateAndroidWebViewProject({
          workDir: tmpDir,
          projectStorageDir: project.storage_dir,
          entryFile: project.entry_file,
          config,
        });

        const textExts = new Set(['.kt', '.java', '.xml', '.kts', '.properties', '.pro', '.sh', '']);
        const files: Array<{ path: string; size: number; content: string }> = [];

        for (const rel of generated.generatedFiles) {
          const ext = path.extname(rel).toLowerCase();
          const base = path.basename(rel);
          if (!textExts.has(ext) && base !== 'Dockerfile') continue;
          const abs = path.join(tmpDir, rel);
          if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
            const content = fs.readFileSync(abs, 'utf8');
            files.push({
              path: rel,
              size: Buffer.byteLength(content),
              content,
            });
          }
        }

        files.sort((a, b) => a.path.localeCompare(b.path));
        res.json({ files });
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'Android kaynakları okunamadı.' });
      } finally {
        fs.rmSync(tmpDir, { recursive: true, force: true });
      }
    }
  );

  return router;
}

function finalizePaymentAndGrantSubscription(
  paymentId: string,
  signatureVerified: boolean,
  eventPayload: unknown,
  nowIso: string
) {
  return db.transaction(() => {
    const payment = db
      .prepare('SELECT * FROM payments WHERE id = ?')
      .get(paymentId) as {
      id: string;
      user_id: string;
      plan_id: string;
      promo_code_id: string | null;
      discount_try: number;
      status: string;
    };

    if (payment.status === 'completed') {
      return null;
    }

    const plan = db
      .prepare('SELECT * FROM subscription_plans WHERE id = ?')
      .get(payment.plan_id) as {
      id: string;
      name: string;
      duration_days: number | null;
      is_lifetime: number;
    };

    db.prepare(`UPDATE payments SET status = 'completed', completed_at = ? WHERE id = ?`).run(
      nowIso,
      payment.id
    );

    if (payment.promo_code_id) {
      db.prepare(
        `INSERT OR IGNORE INTO promo_redemptions (id, promo_code_id, user_id, payment_id, discount_try, redeemed_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(
        `prd_${crypto.randomUUID().slice(0, 10)}`,
        payment.promo_code_id,
        payment.user_id,
        payment.id,
        payment.discount_try || 0,
        nowIso
      );
      db.prepare('UPDATE promo_codes SET current_uses = current_uses + 1 WHERE id = ?').run(
        payment.promo_code_id
      );
    }

    db.prepare(
      `INSERT INTO payment_events (id, payment_id, event_type, signature_verified, payload_json, created_at)
       VALUES (?, ?, 'payment_completed', ?, ?, ?)`
    ).run(
      `pev_${crypto.randomUUID().slice(0, 10)}`,
      payment.id,
      signatureVerified ? 1 : 0,
      JSON.stringify(eventPayload),
      nowIso
    );

    db.prepare(
      `UPDATE subscriptions SET status = 'cancelled', updated_at = ? WHERE user_id = ? AND status = 'active'`
    ).run(nowIso, payment.user_id);

    const expiresAt =
      plan.is_lifetime === 1 || !plan.duration_days
        ? null
        : new Date(Date.now() + plan.duration_days * 86400000).toISOString();

    const subId = `sub_${crypto.randomUUID().slice(0, 10)}`;
    db.prepare(
      `INSERT INTO subscriptions (id, user_id, plan_id, status, started_at, expires_at, is_lifetime, granted_by, created_at, updated_at)
       VALUES (?, ?, ?, 'active', ?, ?, ?, NULL, ?, ?)`
    ).run(subId, payment.user_id, plan.id, nowIso, expiresAt, plan.is_lifetime, nowIso, nowIso);

    createNotification({
      userId: payment.user_id,
      type: 'success',
      title: 'Ödeme Onaylandı — Premium Aktif',
      message: `${plan.name} aboneliğiniz doğrulandı ve hesabınızda aktifleştirildi.`,
      linkSection: 'account',
    });

    return { id: subId, startedAt: nowIso, expiresAt, isLifetime: plan.is_lifetime === 1 };
  })();
}
