import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import { db } from './db.ts';
import {
  createGatewayOrderRecord,
  processVerifiedWebhookEvent,
  type PaymentMethod,
} from './payments.ts';
import {
  calculateServerPricePaise,
  generateCode,
  getPaymentMode,
  hashPassword,
  sanitizeText,
  signSessionToken,
  validateCampaignUrl,
  verifyPassword,
  verifySessionToken,
  type SessionPayload,
} from './security.ts';
import { createProjectZipBuffer } from './zip.ts';

interface AuthenticatedRequest extends Request {
  auth?: SessionPayload;
}

const SESSION_COOKIE_NAME = 'sb_session';

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.length > 0) {
    return forwarded.split(',')[0]?.trim() || '';
  }
  return req.socket.remoteAddress || '';
}

function attachSessionCookie(req: Request, res: Response, token: string): void {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https' || process.env.NODE_ENV === 'production';
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: isHttps ? 'none' : 'lax',
    secure: Boolean(isHttps),
    maxAge: 1000 * 60 * 60 * 24 * 7,
    path: '/',
  });
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const cookieToken = req.cookies?.[SESSION_COOKIE_NAME] as string | undefined;
  const authHeader = req.headers.authorization;
  const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : undefined;
  const token = cookieToken || bearerToken;

  if (!token) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const payload = verifySessionToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    return;
  }

  req.auth = payload;
  next();
}

function requireCustomer(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  requireAuth(req, res, () => {
    if (!req.auth || req.auth.accountType !== 'customer') {
      res.status(403).json({ error: 'Customer account required.' });
      return;
    }
    const user = db.prepare('SELECT id, status FROM users WHERE id = ?').get(req.auth.id) as
      | { id: number; status: string }
      | undefined;
    if (!user || user.status !== 'active') {
      res.status(403).json({ error: 'Customer account is suspended or inactive.' });
      return;
    }
    next();
  });
}

const SOLE_ADMIN_USER_ID = 'rudra@1941';

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  requireAuth(req, res, () => {
    if (!req.auth || req.auth.accountType !== 'admin') {
      res.status(403).json({ error: 'Administrator privileges required.' });
      return;
    }
    const admin = db
      .prepare('SELECT id, email, role, permissions_json, is_active FROM admin_accounts WHERE id = ?')
      .get(req.auth.id) as
      | { id: number; email: string; role: string; permissions_json: string; is_active: number }
      | undefined;

    if (!admin || admin.is_active !== 1 || admin.email.toLowerCase() !== SOLE_ADMIN_USER_ID) {
      res.status(403).json({ error: 'Administrator account is disabled or unauthorized.' });
      return;
    }
    next();
  });
}

function writeAuditLog(params: {
  actorType: 'customer' | 'admin' | 'webhook' | 'system';
  actorId: number | null;
  actorEmail: string;
  action: string;
  entityType: string;
  entityId: string;
  ipAddress: string;
  metadata?: Record<string, unknown>;
}): void {
  db.prepare(`
    INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, entity_type, entity_id, ip_address, metadata_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    params.actorType,
    params.actorId,
    params.actorEmail,
    params.action,
    params.entityType,
    params.entityId,
    params.ipAddress,
    JSON.stringify(params.metadata || {}),
  );
}

export function createApiRouter(): express.Router {
  const router = express.Router();

  // Webhook endpoint MUST receive raw body for cryptographic HMAC verification
  router.post(
    '/webhooks/razorpay',
    express.raw({ type: 'application/json' }),
    (req: Request, res: Response) => {
      const signature = (req.headers['x-razorpay-signature'] as string) || '';
      const rawBody = Buffer.isBuffer(req.body) ? req.body : JSON.stringify(req.body || {});
      const result = processVerifiedWebhookEvent(rawBody, signature, getClientIp(req));
      res.status(result.status).json({
        ok: result.ok,
        message: result.message,
        paymentCode: result.paymentCode,
        paymentStatus: result.paymentStatus,
      });
    },
  );

  router.use(express.json({ limit: '3mb' }));

  // Health & config
  router.get('/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      app: 'SOCIAL BOOST',
      paymentMode: getPaymentMode(),
      timestamp: new Date().toISOString(),
    });
  });

  // Public compliant services catalogue
  router.get('/services', (_req: Request, res: Response) => {
    const services = db
      .prepare(`
        SELECT id, slug, name, category, description, compliance_note,
               reference_quantity, reference_price_paise, min_quantity, max_quantity,
               estimated_turnaround, is_active, policy_approved
        FROM services
        WHERE is_active = 1 AND policy_approved = 1
        ORDER BY id ASC
      `)
      .all();

    const paymentSettings = db
      .prepare('SELECT merchant_upi_id, merchant_name, upi_direct_enabled, upi_qr_image_data FROM payment_settings WHERE id = 1')
      .get() as
      | { merchant_upi_id: string; merchant_name: string; upi_direct_enabled: number; upi_qr_image_data: string }
      | undefined;

    res.json({
      services,
      paymentMode: getPaymentMode(),
      upiConfig: {
        merchantUpiId: paymentSettings?.merchant_upi_id || '',
        merchantName: paymentSettings?.merchant_name || 'SOCIAL BOOST',
        upiDirectEnabled: paymentSettings?.upi_direct_enabled === 1,
        upiQrImageUrl: paymentSettings?.upi_qr_image_data || '',
      },
    });
  });

  // Auth: Register customer
  router.post('/auth/register', (req: Request, res: Response) => {
    const name = sanitizeText(req.body?.name, 80);
    const email = sanitizeText(req.body?.email, 120).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 24);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (name.length < 2) {
      res.status(400).json({ error: 'Please enter your full name (at least 2 characters).' });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters long.' });
      return;
    }

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    const existingAdmin = db.prepare('SELECT id FROM admin_accounts WHERE email = ?').get(email);
    if (existing || existingAdmin) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const result = db
      .prepare(`
        INSERT INTO users (name, email, phone, password_hash, wallet_balance_paise, status)
        VALUES (?, ?, ?, ?, 0, 'active')
      `)
      .run(name, email, phone, hashPassword(password));

    const userId = Number(result.lastInsertRowid);
    const token = signSessionToken({
      id: userId,
      email,
      name,
      accountType: 'customer',
      role: 'customer',
    });

    attachSessionCookie(req, res, token);
    writeAuditLog({
      actorType: 'customer',
      actorId: userId,
      actorEmail: email,
      action: 'auth.register',
      entityType: 'user',
      entityId: String(userId),
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      token,
      user: {
        id: userId,
        name,
        email,
        phone,
        walletBalancePaise: 0,
        accountType: 'customer',
        role: 'customer',
      },
    });
  });

  // Auth: Login (customer or admin)
  router.post('/auth/login', (req: Request, res: Response) => {
    const email = sanitizeText(req.body?.email, 120).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const portal = req.body?.portal === 'admin' ? 'admin' : 'customer';

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    if (portal === 'admin') {
      if (email !== SOLE_ADMIN_USER_ID) {
        writeAuditLog({
          actorType: 'admin',
          actorId: null,
          actorEmail: email,
          action: 'auth.admin_login_rejected',
          entityType: 'admin_account',
          entityId: email,
          ipAddress: getClientIp(req),
        });
        res.status(401).json({ error: 'Invalid administrator credentials.' });
        return;
      }

      const admin = db
        .prepare(
          'SELECT id, name, email, password_hash, role, permissions_json, is_active FROM admin_accounts WHERE lower(email) = ?',
        )
        .get(SOLE_ADMIN_USER_ID) as
        | {
            id: number;
            name: string;
            email: string;
            password_hash: string;
            role: string;
            permissions_json: string;
            is_active: number;
          }
        | undefined;

      if (!admin || !verifyPassword(password, admin.password_hash)) {
        writeAuditLog({
          actorType: 'admin',
          actorId: admin?.id ?? null,
          actorEmail: email,
          action: 'auth.admin_login_failed',
          entityType: 'admin_account',
          entityId: email,
          ipAddress: getClientIp(req),
        });
        res.status(401).json({ error: 'Invalid administrator credentials.' });
        return;
      }

      if (admin.is_active !== 1) {
        res.status(403).json({ error: 'This administrator account is disabled.' });
        return;
      }

      db.prepare("UPDATE admin_accounts SET last_login_at = datetime('now') WHERE id = ?").run(admin.id);

      const token = signSessionToken({
        id: admin.id,
        email: admin.email,
        name: admin.name,
        accountType: 'admin',
        role: admin.role,
      });
      attachSessionCookie(req, res, token);

      writeAuditLog({
        actorType: 'admin',
        actorId: admin.id,
        actorEmail: admin.email,
        action: 'auth.admin_login',
        entityType: 'admin_account',
        entityId: String(admin.id),
        ipAddress: getClientIp(req),
      });

      res.json({
        token,
        user: {
          id: admin.id,
          name: admin.name,
          email: admin.email,
          accountType: 'admin',
          role: admin.role,
          permissions: JSON.parse(admin.permissions_json || '[]'),
        },
      });
      return;
    }

    const user = db
      .prepare('SELECT id, name, email, phone, password_hash, wallet_balance_paise, status FROM users WHERE email = ?')
      .get(email) as
      | {
          id: number;
          name: string;
          email: string;
          phone: string;
          password_hash: string;
          wallet_balance_paise: number;
          status: string;
        }
      | undefined;

    if (!user || !verifyPassword(password, user.password_hash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (user.status !== 'active') {
      res.status(403).json({ error: 'Your account has been suspended. Please contact support.' });
      return;
    }

    const token = signSessionToken({
      id: user.id,
      email: user.email,
      name: user.name,
      accountType: 'customer',
      role: 'customer',
    });
    attachSessionCookie(req, res, token);

    writeAuditLog({
      actorType: 'customer',
      actorId: user.id,
      actorEmail: user.email,
      action: 'auth.customer_login',
      entityType: 'user',
      entityId: String(user.id),
      ipAddress: getClientIp(req),
    });

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        walletBalancePaise: user.wallet_balance_paise,
        accountType: 'customer',
        role: 'customer',
      },
    });
  });

  router.post('/auth/logout', (_req: AuthenticatedRequest, res: Response) => {
    res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
    res.json({ ok: true });
  });

  router.get('/auth/me', (req: AuthenticatedRequest, res: Response) => {
    const cookieToken = req.cookies?.[SESSION_COOKIE_NAME] as string | undefined;
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : undefined;
    const token = cookieToken || bearerToken;
    if (!token) {
      res.json({ user: null });
      return;
    }
    const payload = verifySessionToken(token);
    if (!payload) {
      res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
      res.json({ user: null });
      return;
    }

    if (payload.accountType === 'admin') {
      const admin = db
        .prepare('SELECT id, name, email, role, permissions_json, is_active FROM admin_accounts WHERE id = ?')
        .get(payload.id) as
        | { id: number; name: string; email: string; role: string; permissions_json: string; is_active: number }
        | undefined;

      if (!admin || admin.is_active !== 1 || admin.email.toLowerCase() !== SOLE_ADMIN_USER_ID) {
        res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
        res.json({ user: null });
        return;
      }

      res.json({
        user: {
          id: admin.id,
          name: admin.name,
          email: admin.email,
          accountType: 'admin',
          role: admin.role,
          permissions: JSON.parse(admin.permissions_json || '[]'),
        },
      });
      return;
    }

    const user = db
      .prepare('SELECT id, name, email, phone, wallet_balance_paise, status FROM users WHERE id = ?')
      .get(payload.id) as
      | {
          id: number;
          name: string;
          email: string;
          phone: string;
          wallet_balance_paise: number;
          status: string;
        }
      | undefined;

    if (!user || user.status !== 'active') {
      res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
      res.json({ user: null });
      return;
    }

    res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        walletBalancePaise: user.wallet_balance_paise,
        accountType: 'customer',
        role: 'customer',
      },
    });
  });

  // Customer Dashboard KPIs & Summary
  router.get('/customer/dashboard', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const userId = req.auth!.id;

    const user = db
      .prepare('SELECT wallet_balance_paise FROM users WHERE id = ?')
      .get(userId) as { wallet_balance_paise: number } | undefined;

    const orderStats = db
      .prepare(`
        SELECT
          COUNT(*) as totalOrders,
          SUM(CASE WHEN status IN ('awaiting_payment', 'queued', 'in_progress') THEN 1 ELSE 0 END) as pendingOrders,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedOrders
        FROM orders
        WHERE user_id = ?
      `)
      .get(userId) as { totalOrders: number; pendingOrders: number | null; completedOrders: number | null };

    const activeServicesCount = db
      .prepare('SELECT COUNT(*) as count FROM services WHERE is_active = 1 AND policy_approved = 1')
      .get() as { count: number };

    const recentTransactions = db
      .prepare(`
        SELECT t.*, p.payment_code, p.method as payment_method, p.receipt_number, o.order_code
        FROM transactions t
        LEFT JOIN payments p ON t.payment_id = p.id
        LEFT JOIN orders o ON t.order_id = o.id
        WHERE t.user_id = ?
        ORDER BY t.created_at DESC, t.id DESC
        LIMIT 8
      `)
      .all(userId);

    const recentOrders = db
      .prepare(`
        SELECT *
        FROM orders
        WHERE user_id = ?
        ORDER BY created_at DESC, id DESC
        LIMIT 5
      `)
      .all(userId);

    res.json({
      walletBalancePaise: user?.wallet_balance_paise ?? 0,
      totalOrders: orderStats.totalOrders || 0,
      pendingOrders: orderStats.pendingOrders || 0,
      completedOrders: orderStats.completedOrders || 0,
      availableServices: activeServicesCount.count || 0,
      recentTransactions,
      recentOrders,
    });
  });

  // Customer Orders: List
  router.get('/orders', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const userId = req.auth!.id;
    const orders = db
      .prepare(`
        SELECT o.*,
          (SELECT p.payment_code FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as latest_payment_code,
          (SELECT p.receipt_number FROM payments p WHERE p.order_id = o.id AND p.status = 'captured' ORDER BY p.id DESC LIMIT 1) as receipt_number
        FROM orders o
        WHERE o.user_id = ?
        ORDER BY o.created_at DESC, o.id DESC
      `)
      .all(userId);

    res.json({ orders });
  });

  // Customer Orders: Create (Strict server-side price calculation!)
  router.post('/orders', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const userId = req.auth!.id;
    const serviceId = Number(req.body?.serviceId);
    const quantity = Number(req.body?.quantity);
    const rawUrl = typeof req.body?.targetUrl === 'string' ? req.body.targetUrl : '';

    if (!Number.isInteger(serviceId) || serviceId <= 0) {
      res.status(400).json({ error: 'Please select a valid service.' });
      return;
    }

    const service = db
      .prepare('SELECT * FROM services WHERE id = ? AND is_active = 1 AND policy_approved = 1')
      .get(serviceId) as
      | {
          id: number;
          name: string;
          reference_quantity: number;
          reference_price_paise: number;
          min_quantity: number;
          max_quantity: number;
        }
      | undefined;

    if (!service) {
      res.status(404).json({ error: 'Selected service is unavailable or not approved.' });
      return;
    }

    if (!Number.isInteger(quantity) || quantity < service.min_quantity || quantity > service.max_quantity) {
      res.status(400).json({
        error: `Quantity must be a whole number between ${service.min_quantity.toLocaleString()} and ${service.max_quantity.toLocaleString()}.`,
      });
      return;
    }

    const urlCheck = validateCampaignUrl(rawUrl);
    if (!urlCheck.valid || !urlCheck.normalized) {
      res.status(400).json({ error: urlCheck.error || 'Invalid campaign URL.' });
      return;
    }

    // Authoritative server-side price calculation
    const totalAmountPaise = calculateServerPricePaise(
      quantity,
      service.reference_quantity,
      service.reference_price_paise,
    );

    const orderCode = generateCode('SB-ORD');
    const insertRes = db
      .prepare(`
        INSERT INTO orders (
          order_code, user_id, service_id, service_name_snapshot, target_url, quantity,
          reference_quantity_snapshot, reference_price_paise_snapshot, total_amount_paise,
          status, payment_status, progress_percent, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_payment', 'unpaid', 0, 'Order created. Complete verified checkout to queue.')
      `)
      .run(
        orderCode,
        userId,
        service.id,
        service.name,
        urlCheck.normalized,
        quantity,
        service.reference_quantity,
        service.reference_price_paise,
        totalAmountPaise,
      );

    const orderId = Number(insertRes.lastInsertRowid);
    const createdOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    writeAuditLog({
      actorType: 'customer',
      actorId: userId,
      actorEmail: req.auth!.email,
      action: 'order.created',
      entityType: 'order',
      entityId: orderCode,
      ipAddress: getClientIp(req),
      metadata: { serviceId: service.id, quantity, totalAmountPaise },
    });

    res.status(201).json({ order: createdOrder });
  });

  // Customer Transactions & Payments
  router.get('/transactions', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const userId = req.auth!.id;
    const transactions = db
      .prepare(`
        SELECT t.*, p.payment_code, p.method as payment_method, p.gateway, p.receipt_number, p.webhook_verified, o.order_code
        FROM transactions t
        LEFT JOIN payments p ON t.payment_id = p.id
        LEFT JOIN orders o ON t.order_id = o.id
        WHERE t.user_id = ?
        ORDER BY t.created_at DESC, t.id DESC
      `)
      .all(userId);

    const payments = db
      .prepare(`
        SELECT p.*, o.order_code, o.service_name_snapshot
        FROM payments p
        LEFT JOIN orders o ON p.order_id = o.id
        WHERE p.user_id = ?
        ORDER BY p.created_at DESC, p.id DESC
      `)
      .all(userId);

    res.json({ transactions, payments });
  });

  // Payment Receipt (Customer owner or Admin)
  router.get('/payments/receipt/:paymentCode', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const paymentCode = sanitizeText(req.params.paymentCode, 64);
    const payment = db
      .prepare(`
        SELECT p.*, u.name as customer_name, u.email as customer_email, o.order_code, o.service_name_snapshot, o.quantity, o.target_url
        FROM payments p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN orders o ON p.order_id = o.id
        WHERE p.payment_code = ?
      `)
      .get(paymentCode) as
      | {
          id: number;
          user_id: number;
          payment_code: string;
          status: string;
        }
      | undefined;

    if (!payment) {
      res.status(404).json({ error: 'Receipt not found.' });
      return;
    }

    if (req.auth!.accountType !== 'admin' && payment.user_id !== req.auth!.id) {
      res.status(403).json({ error: 'Access denied to this receipt.' });
      return;
    }

    res.json({ receipt: payment });
  });

  // Create order-specific payment request OR wallet top-up OR wallet pay
  router.post('/payments/create-order', requireCustomer, async (req: AuthenticatedRequest, res: Response) => {
    const userId = req.auth!.id;
    const purpose = req.body?.purpose === 'wallet_topup' ? 'wallet_topup' : 'order_payment';
    const method = (req.body?.method || 'upi') as PaymentMethod;
    const allowedMethods: PaymentMethod[] = ['upi', 'gpay', 'phonepe', 'paytm', 'card_netbanking', 'wallet'];

    if (!allowedMethods.includes(method)) {
      res.status(400).json({ error: 'Unsupported payment method.' });
      return;
    }

    if (purpose === 'wallet_topup') {
      if (method === 'wallet') {
        res.status(400).json({ error: 'Cannot top up wallet using wallet balance.' });
        return;
      }
      const amountInr = Number(req.body?.amountInr);
      if (!Number.isFinite(amountInr) || amountInr < 10 || amountInr > 50000) {
        res.status(400).json({ error: 'Wallet top-up must be between ₹10 and ₹50,000.' });
        return;
      }
      const amountPaise = Math.round(amountInr * 100);
      const paymentCode = generateCode('SB-PAY');

      try {
        const gw = await createGatewayOrderRecord({
          amountPaise,
          receiptCode: paymentCode,
          notes: { purpose: 'wallet_topup', userId: String(userId) },
        });

        db.prepare(`
          INSERT INTO payments (
            payment_code, order_id, user_id, purpose, gateway, gateway_order_id,
            method, amount_paise, currency, status
          ) VALUES (?, NULL, ?, 'wallet_topup', ?, ?, ?, ?, 'INR', 'created')
        `).run(paymentCode, userId, gw.gateway, gw.gatewayOrderId, method, amountPaise);

        res.status(201).json({
          paymentMode: getPaymentMode(),
          paymentCode,
          gateway: gw.gateway,
          gatewayOrderId: gw.gatewayOrderId,
          keyId: gw.keyId,
          amountPaise,
          currency: 'INR',
          method,
        });
      } catch (err) {
        res.status(502).json({ error: err instanceof Error ? err.message : 'Payment gateway error.' });
      }
      return;
    }

    // Order payment
    const orderId = Number(req.body?.orderId);
    const order = db
      .prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?')
      .get(orderId, userId) as
      | {
          id: number;
          order_code: string;
          user_id: number;
          total_amount_paise: number;
          payment_status: string;
          status: string;
        }
      | undefined;

    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }
    if (order.payment_status === 'paid') {
      res.status(400).json({ error: 'This order has already been paid and verified.' });
      return;
    }

    // Instant internal Wallet Balance payment
    if (method === 'wallet') {
      const user = db
        .prepare('SELECT wallet_balance_paise FROM users WHERE id = ?')
        .get(userId) as { wallet_balance_paise: number };

      if (user.wallet_balance_paise < order.total_amount_paise) {
        res.status(400).json({ error: 'Insufficient wallet balance. Please add funds or select UPI / Gateway.' });
        return;
      }

      const paymentCode = generateCode('SB-PAY');
      const receiptNumber = `RCPT-${paymentCode.replace('SB-PAY-', '')}`;

      const payWithWallet = db.transaction(() => {
        const deductRes = db
          .prepare(`
            UPDATE users
            SET wallet_balance_paise = wallet_balance_paise - ?,
                updated_at = datetime('now')
            WHERE id = ? AND wallet_balance_paise >= ?
          `)
          .run(order.total_amount_paise, userId, order.total_amount_paise);

        if (deductRes.changes === 0) {
          throw new Error('Insufficient wallet balance.');
        }

        const payInsert = db
          .prepare(`
            INSERT INTO payments (
              payment_code, order_id, user_id, purpose, gateway, gateway_order_id, gateway_payment_id,
              method, amount_paise, currency, status, webhook_verified, receipt_number, verified_at
            ) VALUES (?, ?, ?, 'order_payment', 'wallet', ?, ?, 'wallet', ?, 'INR', 'captured', 1, ?, datetime('now'))
          `)
          .run(
            paymentCode,
            order.id,
            userId,
            `wallet_ord_${order.order_code}_${Date.now()}`,
            `wallet_pay_${Date.now()}`,
            order.total_amount_paise,
            receiptNumber,
          );

        db.prepare(`
          UPDATE orders
          SET payment_status = 'paid',
              status = 'queued',
              progress_percent = 15,
              notes = 'Paid via verified account wallet balance. Campaign queued.',
              updated_at = datetime('now')
          WHERE id = ?
        `).run(order.id);

        db.prepare(`
          INSERT INTO transactions (tx_code, user_id, order_id, payment_id, type, direction, amount_paise, status, description)
          VALUES (?, ?, ?, ?, 'wallet_debit', 'debit', ?, 'completed', ?)
        `).run(
          generateCode('SB-TX'),
          userId,
          order.id,
          Number(payInsert.lastInsertRowid),
          order.total_amount_paise,
          `Wallet balance used for ${order.order_code}`,
        );
      });

      try {
        payWithWallet();
        writeAuditLog({
          actorType: 'customer',
          actorId: userId,
          actorEmail: req.auth!.email,
          action: 'payment.wallet_captured',
          entityType: 'order',
          entityId: order.order_code,
          ipAddress: getClientIp(req),
          metadata: { paymentCode, amountPaise: order.total_amount_paise },
        });
        res.json({
          settledImmediately: true,
          paymentCode,
          receiptNumber,
          status: 'captured',
        });
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'Wallet payment failed.' });
      }
      return;
    }

    // Gateway order (UPI / GPay / PhonePe / Paytm / Card)
    const paymentCode = generateCode('SB-PAY');
    try {
      const gw = await createGatewayOrderRecord({
        amountPaise: order.total_amount_paise,
        receiptCode: paymentCode,
        notes: {
          orderCode: order.order_code,
          userId: String(userId),
        },
      });

      db.prepare(`
        INSERT INTO payments (
          payment_code, order_id, user_id, purpose, gateway, gateway_order_id,
          method, amount_paise, currency, status
        ) VALUES (?, ?, ?, 'order_payment', ?, ?, ?, ?, 'INR', 'created')
      `).run(paymentCode, order.id, userId, gw.gateway, gw.gatewayOrderId, method, order.total_amount_paise);

      res.status(201).json({
        paymentMode: getPaymentMode(),
        paymentCode,
        gateway: gw.gateway,
        gatewayOrderId: gw.gatewayOrderId,
        keyId: gw.keyId,
        amountPaise: order.total_amount_paise,
        currency: 'INR',
        method,
        orderCode: order.order_code,
      });
    } catch (err) {
      res.status(502).json({ error: err instanceof Error ? err.message : 'Gateway order creation failed.' });
    }
  });

  // Customer submits 12-digit UPI UTR / Reference Number after paying Merchant UPI QR/DeepLink
  router.post('/payments/submit-upi-utr', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const paymentCode = sanitizeText(req.body?.paymentCode, 64);
    const utrNumber = sanitizeText(req.body?.utrNumber, 32).replace(/\s+/g, '').toUpperCase();

    if (!/^[A-Z0-9]{10,22}$/.test(utrNumber)) {
      res.status(400).json({ error: 'Please enter a valid 10–22 character UPI Reference / UTR Number.' });
      return;
    }

    const payment = db
      .prepare('SELECT id, user_id, order_id, purpose, amount_paise, status FROM payments WHERE payment_code = ?')
      .get(paymentCode) as
      | { id: number; user_id: number; order_id: number | null; purpose: string; amount_paise: number; status: string }
      | undefined;

    if (!payment || payment.user_id !== req.auth!.id) {
      res.status(404).json({ error: 'Payment session not found.' });
      return;
    }

    if (payment.status === 'captured' || payment.status === 'refunded') {
      res.status(400).json({ error: 'This payment is already settled.' });
      return;
    }

    const duplicateUtr = db
      .prepare('SELECT id FROM payments WHERE utr_number = ? AND id != ?')
      .get(utrNumber, payment.id);
    if (duplicateUtr) {
      res.status(409).json({ error: 'This UPI Reference / UTR number has already been submitted.' });
      return;
    }

    db.transaction(() => {
      db.prepare(`
        UPDATE payments
        SET status = 'pending',
            utr_number = ?,
            gateway_payment_id = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).run(utrNumber, `upi_utr_${utrNumber}`, payment.id);

      if (payment.purpose === 'order_payment' && payment.order_id) {
        db.prepare(`
          UPDATE orders
          SET payment_status = 'pending',
              notes = ?,
              updated_at = datetime('now')
          WHERE id = ? AND payment_status != 'paid'
        `).run(`UPI UTR ${utrNumber} submitted. Awaiting merchant verification.`, payment.order_id);
      }
    })();

    writeAuditLog({
      actorType: 'customer',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'payment.upi_utr_submitted',
      entityType: 'payment',
      entityId: paymentCode,
      ipAddress: getClientIp(req),
      metadata: { utrNumber, amountPaise: payment.amount_paise },
    });

    res.json({
      ok: true,
      status: 'pending',
      message: 'UTR recorded. Your order will queue as soon as the UPI receipt is verified.',
    });
  });

  // Customer Support Tickets
  router.get('/support', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const tickets = db
      .prepare(`
        SELECT s.*, o.order_code
        FROM support_tickets s
        LEFT JOIN orders o ON s.order_id = o.id
        WHERE s.user_id = ?
        ORDER BY s.created_at DESC
      `)
      .all(req.auth!.id);

    res.json({ tickets });
  });

  router.post('/support', requireCustomer, (req: AuthenticatedRequest, res: Response) => {
    const userId = req.auth!.id;
    const subject = sanitizeText(req.body?.subject, 140);
    const message = sanitizeText(req.body?.message, 1500);
    const orderId = req.body?.orderId ? Number(req.body.orderId) : null;

    if (subject.length < 4 || message.length < 10) {
      res.status(400).json({ error: 'Please provide a clear subject and detailed message.' });
      return;
    }

    if (orderId) {
      const ownsOrder = db.prepare('SELECT id FROM orders WHERE id = ? AND user_id = ?').get(orderId, userId);
      if (!ownsOrder) {
        res.status(400).json({ error: 'Selected order was not found on your account.' });
        return;
      }
    }

    const ticketCode = generateCode('SB-TKT');
    const insertRes = db
      .prepare(`
        INSERT INTO support_tickets (ticket_code, user_id, order_id, subject, message, status)
        VALUES (?, ?, ?, ?, ?, 'open')
      `)
      .run(ticketCode, userId, orderId, subject, message);

    const ticket = db.prepare('SELECT * FROM support_tickets WHERE id = ?').get(Number(insertRes.lastInsertRowid));
    res.status(201).json({ ticket });
  });

  // ==================== ADMIN ENDPOINTS (RBAC Protected) ====================

  router.get('/admin/overview', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const dailyRevenue = db
      .prepare(`
        SELECT COALESCE(SUM(amount_paise), 0) as total
        FROM payments
        WHERE status = 'captured' AND date(verified_at) = date('now')
      `)
      .get() as { total: number };

    const monthlyRevenue = db
      .prepare(`
        SELECT COALESCE(SUM(amount_paise), 0) as total
        FROM payments
        WHERE status = 'captured' AND strftime('%Y-%m', verified_at) = strftime('%Y-%m', 'now')
      `)
      .get() as { total: number };

    const totalRefunds = db
      .prepare(`SELECT COALESCE(SUM(amount_paise), 0) as total FROM refunds WHERE status = 'processed'`)
      .get() as { total: number };

    const counts = db
      .prepare(`
        SELECT
          (SELECT COUNT(*) FROM users) as totalCustomers,
          (SELECT COUNT(*) FROM orders) as totalOrders,
          (SELECT COUNT(*) FROM orders WHERE status IN ('queued', 'in_progress', 'awaiting_payment')) as activeOrders,
          (SELECT COUNT(*) FROM support_tickets WHERE status != 'resolved') as openTickets
      `)
      .get() as {
      totalCustomers: number;
      totalOrders: number;
      activeOrders: number;
      openTickets: number;
    };

    const revenueSeries = db
      .prepare(`
        SELECT date(verified_at) as day, SUM(amount_paise) as revenue_paise, COUNT(*) as tx_count
        FROM payments
        WHERE status = 'captured' AND verified_at >= datetime('now', '-7 days')
        GROUP BY date(verified_at)
        ORDER BY day ASC
      `)
      .all();

    res.json({
      dailyRevenuePaise: dailyRevenue.total,
      monthlyRevenuePaise: monthlyRevenue.total,
      totalRefundedPaise: totalRefunds.total,
      ...counts,
      revenueSeries,
    });
  });

  router.get('/admin/customers', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const customers = db
      .prepare(`
        SELECT u.id, u.name, u.email, u.phone, u.wallet_balance_paise, u.status, u.created_at,
          (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) as order_count,
          (SELECT COALESCE(SUM(p.amount_paise), 0) FROM payments p WHERE p.user_id = u.id AND p.status = 'captured') as total_spent_paise
        FROM users u
        ORDER BY u.created_at DESC
      `)
      .all();
    res.json({ customers });
  });

  router.patch('/admin/customers/:id/status', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const customerId = Number(req.params.id);
    const status = req.body?.status;
    if (status !== 'active' && status !== 'suspended') {
      res.status(400).json({ error: 'Invalid customer status.' });
      return;
    }

    const result = db
      .prepare("UPDATE users SET status = ?, updated_at = datetime('now') WHERE id = ?")
      .run(status, customerId);

    if (result.changes === 0) {
      res.status(404).json({ error: 'Customer not found.' });
      return;
    }

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: `customer.${status}`,
      entityType: 'user',
      entityId: String(customerId),
      ipAddress: getClientIp(req),
    });

    res.json({ ok: true });
  });

  router.get('/admin/orders', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const orders = db
      .prepare(`
        SELECT o.*, u.name as customer_name, u.email as customer_email,
          (SELECT p.id FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as latest_payment_id,
          (SELECT p.payment_code FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as latest_payment_code,
          (SELECT p.method FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as payment_method,
          (SELECT p.status FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as payment_gateway_status,
          (SELECT p.utr_number FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as utr_number,
          (SELECT p.receipt_number FROM payments p WHERE p.order_id = o.id AND p.status = 'captured' ORDER BY p.id DESC LIMIT 1) as receipt_number,
          (SELECT p.webhook_verified FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) as webhook_verified
        FROM orders o
        JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC, o.id DESC
      `)
      .all();
    res.json({ orders });
  });

  router.patch('/admin/orders/:id/status', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const orderId = Number(req.params.id);
    const status = req.body?.status;
    const progressPercent = Number(req.body?.progressPercent);
    const notes = sanitizeText(req.body?.notes, 300);

    const allowedStatuses = ['awaiting_payment', 'queued', 'in_progress', 'completed', 'payment_failed', 'refunded', 'cancelled'];
    if (!allowedStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid order status.' });
      return;
    }

    const existing = db.prepare('SELECT id, order_code, payment_status FROM orders WHERE id = ?').get(orderId) as
      | { id: number; order_code: string; payment_status: string }
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    if ((status === 'queued' || status === 'in_progress' || status === 'completed') && existing.payment_status !== 'paid') {
      res.status(400).json({ error: 'Cannot advance fulfillment until payment is verified.' });
      return;
    }

    const safeProgress = Number.isFinite(progressPercent)
      ? Math.max(0, Math.min(100, Math.round(progressPercent)))
      : status === 'completed'
        ? 100
        : status === 'in_progress'
          ? 55
          : status === 'queued'
            ? 15
            : 0;

    db.prepare(`
      UPDATE orders
      SET status = ?,
          progress_percent = ?,
          notes = COALESCE(NULLIF(?, ''), notes),
          updated_at = datetime('now')
      WHERE id = ?
    `).run(status, safeProgress, notes, orderId);

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'order.status_updated',
      entityType: 'order',
      entityId: existing.order_code,
      ipAddress: getClientIp(req),
      metadata: { status, progressPercent: safeProgress },
    });

    res.json({ ok: true });
  });

  router.get('/admin/services', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const services = db.prepare('SELECT * FROM services ORDER BY id ASC').all();
    res.json({ services });
  });

  router.post('/admin/services', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const name = sanitizeText(req.body?.name, 80);
    const category = sanitizeText(req.body?.category, 60) || 'Creator Promotion';
    const description = sanitizeText(req.body?.description, 320);
    const complianceNote =
      sanitizeText(req.body?.complianceNote, 240) ||
      'Instagram-policy compliant campaign placement. Never requires account credentials.';
    const referenceQuantity = Number(req.body?.referenceQuantity);
    const referencePriceInr = Number(req.body?.referencePriceInr);
    const minQuantity = Number(req.body?.minQuantity) || 100;
    const maxQuantity = Number(req.body?.maxQuantity) || 500000;
    const estimatedTurnaround = sanitizeText(req.body?.estimatedTurnaround, 60) || '24–72 hours';
    const policyApproved = req.body?.policyApproved === false ? 0 : 1;

    if (name.length < 2 || !Number.isInteger(referenceQuantity) || referenceQuantity <= 0 || !Number.isFinite(referencePriceInr) || referencePriceInr <= 0) {
      res.status(400).json({ error: 'Valid service name, reference quantity, and price in ₹ are required.' });
      return;
    }

    const slug = `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36).slice(-4)}`;
    const referencePricePaise = Math.round(referencePriceInr * 100);

    const insertRes = db
      .prepare(`
        INSERT INTO services (
          slug, name, category, description, compliance_note,
          reference_quantity, reference_price_paise, min_quantity, max_quantity,
          estimated_turnaround, is_active, policy_approved
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        slug,
        name,
        category,
        description || 'Policy-compliant creator reach campaign.',
        complianceNote,
        referenceQuantity,
        referencePricePaise,
        minQuantity,
        maxQuantity,
        estimatedTurnaround,
        policyApproved,
        policyApproved,
      );

    const service = db.prepare('SELECT * FROM services WHERE id = ?').get(Number(insertRes.lastInsertRowid));
    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'service.created',
      entityType: 'service',
      entityId: slug,
      ipAddress: getClientIp(req),
      metadata: { name, referenceQuantity, referencePricePaise },
    });

    res.status(201).json({ service });
  });

  router.patch('/admin/services/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const serviceId = Number(req.params.id);
    const existing = db.prepare('SELECT * FROM services WHERE id = ?').get(serviceId) as
      | {
          id: number;
          name: string;
          reference_quantity: number;
          reference_price_paise: number;
          is_active: number;
          policy_approved: number;
        }
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Service not found.' });
      return;
    }

    const name = req.body?.name !== undefined ? sanitizeText(req.body.name, 80) : existing.name;
    const referenceQuantity =
      req.body?.referenceQuantity !== undefined ? Number(req.body.referenceQuantity) : existing.reference_quantity;
    const referencePricePaise =
      req.body?.referencePriceInr !== undefined
        ? Math.round(Number(req.body.referencePriceInr) * 100)
        : existing.reference_price_paise;
    const isActive = req.body?.isActive !== undefined ? (req.body.isActive ? 1 : 0) : existing.is_active;
    const policyApproved =
      req.body?.policyApproved !== undefined ? (req.body.policyApproved ? 1 : 0) : existing.policy_approved;

    if (!Number.isInteger(referenceQuantity) || referenceQuantity <= 0 || !Number.isFinite(referencePricePaise) || referencePricePaise <= 0) {
      res.status(400).json({ error: 'Invalid reference quantity or price.' });
      return;
    }

    db.prepare(`
      UPDATE services
      SET name = ?,
          reference_quantity = ?,
          reference_price_paise = ?,
          is_active = ?,
          policy_approved = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(name, referenceQuantity, referencePricePaise, isActive, policyApproved, serviceId);

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'service.updated',
      entityType: 'service',
      entityId: String(serviceId),
      ipAddress: getClientIp(req),
      metadata: { name, referenceQuantity, referencePricePaise, isActive, policyApproved },
    });

    res.json({ ok: true });
  });

  router.get('/admin/payments', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const payments = db
      .prepare(`
        SELECT p.*, u.name as customer_name, u.email as customer_email,
               o.order_code, o.target_url, o.service_name_snapshot, o.quantity, o.status as order_status
        FROM payments p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN orders o ON p.order_id = o.id
        ORDER BY p.created_at DESC, p.id DESC
      `)
      .all();

    const refunds = db
      .prepare(`
        SELECT r.*, u.name as customer_name, u.email as customer_email, p.payment_code, o.order_code, a.name as admin_name
        FROM refunds r
        JOIN users u ON r.user_id = u.id
        JOIN payments p ON r.payment_id = p.id
        LEFT JOIN orders o ON r.order_id = o.id
        JOIN admin_accounts a ON r.admin_id = a.id
        ORDER BY r.created_at DESC
      `)
      .all();

    const upiSettings = db
      .prepare('SELECT merchant_upi_id, merchant_name, upi_direct_enabled, upi_qr_image_data, updated_at FROM payment_settings WHERE id = 1')
      .get();

    res.json({ payments, refunds, upiSettings });
  });

  // Admin: Update Merchant UPI ID (VPA), Business Name & Custom UPI QR Image
  router.patch('/admin/upi-settings', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const merchantUpiId = sanitizeText(req.body?.merchantUpiId, 100).toLowerCase();
    const merchantName = sanitizeText(req.body?.merchantName, 80) || 'SOCIAL BOOST';
    const upiDirectEnabled = req.body?.upiDirectEnabled === false ? 0 : 1;

    const existingSettings = db
      .prepare('SELECT upi_qr_image_data FROM payment_settings WHERE id = 1')
      .get() as { upi_qr_image_data: string } | undefined;

    let upiQrImageData = existingSettings?.upi_qr_image_data || '';
    if (typeof req.body?.upiQrImageData === 'string') {
      const candidate = req.body.upiQrImageData.trim();
      if (candidate === '') {
        upiQrImageData = '';
      } else if (
        candidate.length <= 2_200_000 &&
        /^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(candidate)
      ) {
        upiQrImageData = candidate;
      } else {
        res.status(400).json({ error: 'QR image must be a valid PNG, JPG, or WebP under 1.5 MB.' });
        return;
      }
    }

    if (merchantUpiId && !/^[a-z0-9._-]{2,}@[a-z0-9]{2,}$/i.test(merchantUpiId)) {
      res.status(400).json({ error: 'Please enter a valid UPI ID (example: yourname@okicici or business@ybl).' });
      return;
    }

    if (!merchantUpiId && !upiQrImageData) {
      res.status(400).json({ error: 'Provide either a Merchant UPI ID or upload a UPI QR code image.' });
      return;
    }

    db.prepare(`
      UPDATE payment_settings
      SET merchant_upi_id = ?,
          merchant_name = ?,
          upi_direct_enabled = ?,
          upi_qr_image_data = ?,
          updated_at = datetime('now')
      WHERE id = 1
    `).run(merchantUpiId, merchantName, upiDirectEnabled, upiQrImageData);

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'admin.upi_settings_updated',
      entityType: 'payment_settings',
      entityId: '1',
      ipAddress: getClientIp(req),
      metadata: { merchantUpiId, merchantName, upiDirectEnabled, hasCustomQr: Boolean(upiQrImageData) },
    });

    res.json({
      ok: true,
      merchantUpiId,
      merchantName,
      upiDirectEnabled: upiDirectEnabled === 1,
      upiQrImageUrl: upiQrImageData,
    });
  });

  // Admin: Verify or reject a pending UPI UTR payment against bank/UPI statement
  router.post('/admin/payments/:id/verify-upi', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const paymentId = Number(req.params.id);
    const decision = req.body?.decision === 'reject' ? 'reject' : 'approve';
    const reason = sanitizeText(req.body?.reason, 200);

    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as
      | {
          id: number;
          payment_code: string;
          order_id: number | null;
          user_id: number;
          purpose: 'order_payment' | 'wallet_topup';
          method: string;
          amount_paise: number;
          status: string;
          utr_number: string | null;
        }
      | undefined;

    if (!payment) {
      res.status(404).json({ error: 'Payment record not found.' });
      return;
    }
    if (payment.status !== 'pending' && payment.status !== 'created') {
      res.status(400).json({ error: 'Only pending payments can be verified or rejected.' });
      return;
    }

    if (decision === 'approve') {
      const receiptNumber = `RCPT-${payment.payment_code.replace('SB-PAY-', '')}`;
      db.transaction(() => {
        db.prepare(`
          UPDATE payments
          SET status = 'captured',
              webhook_verified = 1,
              receipt_number = ?,
              failure_reason = NULL,
              verified_at = datetime('now'),
              updated_at = datetime('now')
          WHERE id = ?
        `).run(receiptNumber, payment.id);

        if (payment.purpose === 'order_payment' && payment.order_id) {
          db.prepare(`
            UPDATE orders
            SET payment_status = 'paid',
                status = 'queued',
                progress_percent = 15,
                notes = 'UPI payment verified by administrator. Campaign queued.',
                updated_at = datetime('now')
            WHERE id = ?
          `).run(payment.order_id);

          db.prepare(`
            INSERT INTO transactions (tx_code, user_id, order_id, payment_id, type, direction, amount_paise, status, description)
            VALUES (?, ?, ?, ?, 'order_payment', 'debit', ?, 'completed', ?)
          `).run(
            generateCode('SB-TX'),
            payment.user_id,
            payment.order_id,
            payment.id,
            payment.amount_paise,
            `Verified UPI payment (UTR ${payment.utr_number || payment.payment_code})`,
          );
        } else if (payment.purpose === 'wallet_topup') {
          db.prepare(`
            UPDATE users
            SET wallet_balance_paise = wallet_balance_paise + ?,
                updated_at = datetime('now')
            WHERE id = ?
          `).run(payment.amount_paise, payment.user_id);

          db.prepare(`
            INSERT INTO transactions (tx_code, user_id, order_id, payment_id, type, direction, amount_paise, status, description)
            VALUES (?, ?, NULL, ?, 'wallet_topup', 'credit', ?, 'completed', ?)
          `).run(
            generateCode('SB-TX'),
            payment.user_id,
            payment.id,
            payment.amount_paise,
            `Wallet top-up verified via UPI (UTR ${payment.utr_number || payment.payment_code})`,
          );
        }
      })();

      writeAuditLog({
        actorType: 'admin',
        actorId: req.auth!.id,
        actorEmail: req.auth!.email,
        action: 'admin.upi_payment_verified',
        entityType: 'payment',
        entityId: payment.payment_code,
        ipAddress: getClientIp(req),
        metadata: { utrNumber: payment.utr_number, receiptNumber, amountPaise: payment.amount_paise },
      });

      res.json({ ok: true, status: 'captured', receiptNumber });
      return;
    }

    // Reject
    const failMsg = reason || 'UPI UTR could not be matched in merchant bank statement.';
    db.transaction(() => {
      db.prepare(`
        UPDATE payments
        SET status = 'failed',
            failure_reason = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).run(failMsg, payment.id);

      if (payment.purpose === 'order_payment' && payment.order_id) {
        db.prepare(`
          UPDATE orders
          SET payment_status = 'failed',
              status = 'payment_failed',
              notes = ?,
              updated_at = datetime('now')
          WHERE id = ? AND payment_status != 'paid'
        `).run(failMsg, payment.order_id);
      }
    })();

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'admin.upi_payment_rejected',
      entityType: 'payment',
      entityId: payment.payment_code,
      ipAddress: getClientIp(req),
      metadata: { utrNumber: payment.utr_number, reason: failMsg },
    });

    res.json({ ok: true, status: 'failed' });
  });

  router.post('/admin/refunds', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const paymentId = Number(req.body?.paymentId);
    const reason = sanitizeText(req.body?.reason, 240);
    const destination = req.body?.destination === 'original_source' ? 'original_source' : 'wallet';

    if (reason.length < 4) {
      res.status(400).json({ error: 'Please specify a refund reason.' });
      return;
    }

    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as
      | {
          id: number;
          payment_code: string;
          order_id: number | null;
          user_id: number;
          amount_paise: number;
          status: string;
        }
      | undefined;

    if (!payment) {
      res.status(404).json({ error: 'Payment record not found.' });
      return;
    }
    if (payment.status !== 'captured') {
      res.status(400).json({ error: 'Only captured, verified payments can be refunded.' });
      return;
    }

    const refundCode = generateCode('SB-REF');

    const processRefund = db.transaction(() => {
      const refInsert = db
        .prepare(`
          INSERT INTO refunds (refund_code, payment_id, order_id, user_id, admin_id, amount_paise, reason, destination, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'processed')
        `)
        .run(
          refundCode,
          payment.id,
          payment.order_id,
          payment.user_id,
          req.auth!.id,
          payment.amount_paise,
          reason,
          destination,
        );

      db.prepare(`UPDATE payments SET status = 'refunded', updated_at = datetime('now') WHERE id = ?`).run(payment.id);

      if (payment.order_id) {
        db.prepare(`
          UPDATE orders
          SET status = 'refunded',
              payment_status = 'refunded',
              notes = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(`Refunded (${refundCode}): ${reason}`, payment.order_id);
      }

      if (destination === 'wallet') {
        db.prepare(`
          UPDATE users
          SET wallet_balance_paise = wallet_balance_paise + ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(payment.amount_paise, payment.user_id);
      }

      db.prepare(`
        INSERT INTO transactions (tx_code, user_id, order_id, payment_id, refund_id, type, direction, amount_paise, status, description)
        VALUES (?, ?, ?, ?, ?, 'refund_credit', 'credit', ?, 'completed', ?)
      `).run(
        generateCode('SB-TX'),
        payment.user_id,
        payment.order_id,
        payment.id,
        Number(refInsert.lastInsertRowid),
        payment.amount_paise,
        `Refund ${refundCode} (${destination === 'wallet' ? 'Credited to Wallet' : 'Original Source'}): ${reason}`,
      );
    });

    processRefund();

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'refund.processed',
      entityType: 'payment',
      entityId: payment.payment_code,
      ipAddress: getClientIp(req),
      metadata: { refundCode, amountPaise: payment.amount_paise, destination, reason },
    });

    res.status(201).json({ ok: true, refundCode });
  });

  router.get('/admin/support', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const tickets = db
      .prepare(`
        SELECT s.*, u.name as customer_name, u.email as customer_email, o.order_code
        FROM support_tickets s
        JOIN users u ON s.user_id = u.id
        LEFT JOIN orders o ON s.order_id = o.id
        ORDER BY CASE s.status WHEN 'open' THEN 0 WHEN 'in_review' THEN 1 ELSE 2 END, s.created_at DESC
      `)
      .all();
    res.json({ tickets });
  });

  router.patch('/admin/support/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const ticketId = Number(req.params.id);
    const adminReply = sanitizeText(req.body?.adminReply, 1500);
    const status = req.body?.status;

    if (status !== 'open' && status !== 'in_review' && status !== 'resolved') {
      res.status(400).json({ error: 'Invalid ticket status.' });
      return;
    }

    const result = db
      .prepare(`
        UPDATE support_tickets
        SET admin_reply = ?,
            status = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `)
      .run(adminReply, status, ticketId);

    if (result.changes === 0) {
      res.status(404).json({ error: 'Support ticket not found.' });
      return;
    }

    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'support.updated',
      entityType: 'support_ticket',
      entityId: String(ticketId),
      ipAddress: getClientIp(req),
      metadata: { status },
    });

    res.json({ ok: true });
  });

  router.get('/admin/audit-logs', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const logs = db
      .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC, id DESC LIMIT 100')
      .all();
    res.json({ logs });
  });

  router.get('/admin/export-zip', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const zipBuffer = createProjectZipBuffer();
    writeAuditLog({
      actorType: 'admin',
      actorId: req.auth!.id,
      actorEmail: req.auth!.email,
      action: 'admin.project_zip_exported',
      entityType: 'system',
      entityId: 'social-boost-source.zip',
      ipAddress: getClientIp(req),
      metadata: { bytes: zipBuffer.length },
    });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="social-boost-source.zip"');
    res.setHeader('Content-Length', String(zipBuffer.length));
    res.send(zipBuffer);
  });

  return router;
}
