-- Contractor Pro — PostgreSQL schema (multi-tenant, RBAC, tamper-evident audit log)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  country text,
  currency text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text,
  email_verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- one membership per user per organization; role drives all permission checks
CREATE TABLE IF NOT EXISTS memberships (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('owner','admin','manager','accountant','supervisor','worker','client')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, user_id)
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  token_hash text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS otp_codes (
  email text PRIMARY KEY,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts int NOT NULL DEFAULT 0
);

-- Offline-first sync: latest full snapshot + per-record changes with versions
CREATE TABLE IF NOT EXISTS sync_snapshots (
  cursor bigserial PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  device_id text,
  data jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sync_snapshots_org ON sync_snapshots(org_id, cursor DESC);

CREATE TABLE IF NOT EXISTS records (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  module text NOT NULL,
  id text NOT NULL,
  data jsonb NOT NULL,
  version int NOT NULL DEFAULT 1,
  updated_at timestamptz NOT NULL,
  deleted boolean NOT NULL DEFAULT false,
  PRIMARY KEY (org_id, module, id)
);

CREATE TABLE IF NOT EXISTS subscriptions (
  org_id uuid PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,
  license_id text UNIQUE,
  plan text NOT NULL DEFAULT 'free',
  status text NOT NULL DEFAULT 'active',
  expires_at timestamptz,
  provider text,
  provider_ref text
);

CREATE TABLE IF NOT EXISTS ai_usage (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  day date NOT NULL,
  calls int NOT NULL DEFAULT 0,
  PRIMARY KEY (org_id, day)
);

-- Append-only audit log with a hash chain (each row commits to the previous one)
CREATE TABLE IF NOT EXISTS audit_log (
  seq bigserial PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  at timestamptz NOT NULL DEFAULT now(),
  user_id text,
  role text,
  action text NOT NULL,
  module text,
  record_id text,
  details text,
  ip text,
  prev_hash text NOT NULL,
  hash text NOT NULL
);
CREATE INDEX IF NOT EXISTS audit_org_seq ON audit_log(org_id, seq DESC);

CREATE OR REPLACE FUNCTION audit_log_immutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_log is append-only';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS audit_log_no_update ON audit_log;
CREATE TRIGGER audit_log_no_update BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_log_immutable();

CREATE TABLE IF NOT EXISTS crypto_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id),
  plan text NOT NULL,
  price_usd numeric NOT NULL,
  currency text NOT NULL,
  amount_crypto numeric NOT NULL,
  address text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz,
  confirmed_by uuid REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS crypto_invoices_org ON crypto_invoices(org_id, created_at DESC);
