#!/usr/bin/env bash
# نصب یک‌مرحله‌ای سرور ترید یار روی Ubuntu/Debian
# استفاده:  sudo ./install.sh api.example.com
set -euo pipefail

DOMAIN="${1:-}"
if [[ -z "$DOMAIN" ]]; then
  echo "❌ استفاده: sudo ./install.sh <دامنه>   (مثال: sudo ./install.sh api.example.com)"
  exit 1
fi
if [[ $EUID -ne 0 ]]; then
  echo "❌ با sudo اجرا کنید."
  exit 1
fi
cd "$(dirname "$0")"

echo "▶ بررسی Docker ..."
if ! command -v docker >/dev/null 2>&1; then
  echo "  Docker نصب نیست؛ در حال نصب ..."
  curl -fsSL https://get.docker.com | sh
fi
docker compose version >/dev/null 2>&1 || { echo "❌ افزونهٔ docker compose نصب نیست."; exit 1; }

echo "▶ ساخت فایل تنظیمات (.env) ..."
if [[ ! -f .env ]]; then
  cp .env.example .env
fi
TOKEN="$(grep -E '^ADMIN_TOKEN=.+' .env | cut -d= -f2- || true)"
if [[ -z "$TOKEN" ]]; then
  TOKEN="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
fi
sed -i "s|^DOMAIN=.*|DOMAIN=${DOMAIN}|" .env
if grep -q '^ADMIN_TOKEN=' .env; then
  sed -i "s|^ADMIN_TOKEN=.*|ADMIN_TOKEN=${TOKEN}|" .env
else
  echo "ADMIN_TOKEN=${TOKEN}" >> .env
fi
if grep -q '^PUBLIC_URL=' .env; then sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=https://${DOMAIN}|" .env; else echo "PUBLIC_URL=https://${DOMAIN}" >> .env; fi
STOK="$(grep -E '^SYNC_TOKEN=.+' .env | cut -d= -f2- || true)"
if [[ -z "$STOK" ]]; then
  STOK="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  sed -i "s|^SYNC_TOKEN=.*|SYNC_TOKEN=${STOK}|" .env
fi
VSEC="$(grep -E '^VAULT_SECRET=.+' .env | cut -d= -f2- || true)"
if [[ -z "$VSEC" ]]; then
  VSEC="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  if grep -q '^VAULT_SECRET=' .env; then sed -i "s|^VAULT_SECRET=.*|VAULT_SECRET=${VSEC}|" .env; else echo "VAULT_SECRET=${VSEC}" >> .env; fi
fi
echo ""; echo "🔐 ADMIN_TOKEN (برای ثبت کلیدهای API از پنل مدیر): ${TOKEN}"
echo "🔑 SYNC_TOKEN (برای set-server-url.py): ${STOK}"
chmod 600 .env

if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  echo "▶ باز کردن پورت‌های 80 و 443 در فایروال ..."
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ufw allow 443/udp >/dev/null
fi

echo "▶ ساخت و اجرای سرور ..."
docker compose up -d --build

echo "▶ منتظر آماده‌شدن سرور ..."
for i in $(seq 1 30); do
  if docker compose exec -T tradyar wget -qO- http://127.0.0.1:8787/health >/dev/null 2>&1; then
    OK=1; break
  fi
  sleep 2
done
[[ "${OK:-0}" == "1" ]] || { echo "❌ سرور بالا نیامد. لاگ: docker compose logs tradyar"; exit 1; }

echo "▶ نصب نگهبان سلامت (هر دقیقه بررسی و خودترمیمی) ..."
chmod +x healthwatch.sh
HERE="$(pwd)"
cat > /etc/systemd/system/tradyar-health.service <<UNIT
[Unit]
Description=Trad-Yar health watch
[Service]
Type=oneshot
ExecStart=${HERE}/healthwatch.sh
UNIT
cat > /etc/systemd/system/tradyar-health.timer <<UNIT
[Unit]
Description=Trad-Yar health watch (every minute)
[Timer]
OnBootSec=90
OnUnitActiveSec=60
AccuracySec=5s
[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload
systemctl enable --now tradyar-health.timer >/dev/null 2>&1 || echo "  (systemd در دسترس نبود؛ healthwatch.sh را دستی با cron اجرا کنید)"

cat <<MSG

✅ سرور ترید یار روشن شد.

  آدرس سرور:      https://${DOMAIN}
  تست سلامت:      https://${DOMAIN}/health
  رمز صفحهٔ آمار: ${TOKEN}
     (ذخیره‌اش کنید؛ در فایل .env هم هست)

  گام بعدی: همین آدرس را داخل برنامه تنظیم کنید:
     ./set-server-url.sh https://${DOMAIN}   (روی پوشهٔ برنامه)

  نگاه به آمار:
     curl -H "Authorization: Bearer ${TOKEN}" https://${DOMAIN}/status

MSG
