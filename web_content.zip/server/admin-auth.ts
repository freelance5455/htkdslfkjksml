import { createHash, createCipheriv, createDecipheriv, createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, eq, gt, gte, sql } from "drizzle-orm";
import type { Request, Response } from "express";
import { parse } from "cookie";
import { getDb } from "./db";
import { adminAccounts, adminChallenges, adminInvitations, adminSessions, type AdminRole } from "../drizzle/schema";

const scrypt = promisify(scryptCallback) as (password: string | Buffer, salt: string | Buffer, keylen: number) => Promise<Buffer>;
export const SESSION_COOKIE = "tolovchi_admin_session";
export const MFA_COOKIE = "tolovchi_admin_mfa";
export const CSRF_COOKIE = "tolovchi_admin_csrf";
const SESSION_MS = 12 * 60 * 60 * 1000;
const MFA_MS = 5 * 60 * 1000;
const attemptsByKey = new Map<string, { count: number; resetAt: number }>();

export type AdminIdentity = { id: number; email: string; displayName: string; role: AdminRole };
const safeIdentity = (admin: Pick<typeof adminAccounts.$inferSelect, "id" | "email" | "displayName" | "role">): AdminIdentity => ({ id: admin.id, email: admin.email, displayName: admin.displayName, role: admin.role });

function digest(value: string) { return createHash("sha256").update(value).digest("hex"); }
function affectedRows(result: unknown) {
  const value = Array.isArray(result) ? result[0] : result;
  const counts = value as { affectedRows?: number; rowsAffected?: number } | undefined;
  return counts?.affectedRows ?? counts?.rowsAffected ?? 0;
}
function constantTimeTextEqual(a: string, b: string) {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
function cookieOptions(maxAge: number) {
  return { httpOnly: true, secure: true, sameSite: "none" as const, path: "/", maxAge };
}
function readCookies(req: Request) { return parse(req.headers.cookie ?? ""); }

export function csrfCookieFromRequest(req: Request) { return readCookies(req)[CSRF_COOKIE] ?? ""; }
export function validCsrf(req: Request) {
  const cookieToken = csrfCookieFromRequest(req);
  const headerToken = req.headers["x-admin-csrf"];
  return !!cookieToken && typeof headerToken === "string" && constantTimeTextEqual(cookieToken, headerToken);
}

async function passwordDigest(password: string, salt: string) { return (await scrypt(password, salt, 64)).toString("hex"); }
function encryptionKey() {
  const secret = process.env.TOTP_ENCRYPTION_KEY;
  if (!secret || secret.length < 32) throw new Error("TOTP_ENCRYPTION_KEY must be configured with at least 32 random characters.");
  return createHash("sha256").update(secret, "utf8").digest();
}
function encryptTotp(secret: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return `v1.${iv.toString("base64url")}.${cipher.getAuthTag().toString("base64url")}.${ciphertext.toString("base64url")}`;
}
function decryptTotp(payload: string) {
  const [version, iv, tag, data] = payload.split(".");
  if (version !== "v1" || !iv || !tag || !data) throw new Error("Invalid encrypted MFA data.");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "base64url"));
  decipher.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(data, "base64url")), decipher.final()]).toString("utf8");
}

function decodeBase32(value: string) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const input = value.toUpperCase().replace(/=+$/g, "").replace(/\s/g, "");
  let buffer = 0;
  let bits = 0;
  const result: number[] = [];
  for (const char of input) {
    const index = alphabet.indexOf(char);
    if (index < 0) throw new Error("Invalid authenticator secret.");
    buffer = (buffer << 5) | index;
    bits += 5;
    if (bits >= 8) { bits -= 8; result.push((buffer >> bits) & 255); }
  }
  return Buffer.from(result);
}
export function verifyTotp(secret: string, token: string, now = Date.now()) {
  if (!/^\d{6}$/.test(token)) return false;
  const key = decodeBase32(secret);
  const supplied = Buffer.from(token);
  for (const drift of [-1, 0, 1]) {
    const counter = BigInt(Math.floor(now / 30_000) + drift);
    const counterBuffer = Buffer.alloc(8);
    counterBuffer.writeBigUInt64BE(counter);
    const hmac = createHmac("sha1", key).update(counterBuffer).digest();
    const offset = hmac[hmac.length - 1] & 0x0f;
    const value = ((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) | ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff);
    const expected = Buffer.from(String(value % 1_000_000).padStart(6, "0"));
    if (timingSafeEqual(supplied, expected)) return true;
  }
  return false;
}

export function isValidNewPassword(password: string) { return password.length >= 12 && password.length <= 128; }
export function normalizeEmail(email: string) { return email.trim().toLowerCase(); }
export function isValidEmail(email: string) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 320; }

export async function makeCredential(password: string) {
  const salt = randomBytes(16).toString("base64url");
  return { passwordSalt: salt, passwordHash: await passwordDigest(password, salt) };
}
async function passwordMatches(password: string, salt: string, expected: string) {
  const actual = Buffer.from(await passwordDigest(password, salt), "hex");
  const stored = Buffer.from(expected, "hex");
  return actual.length === stored.length && timingSafeEqual(actual, stored);
}

export function issueRecoveryCodes() {
  const codes = Array.from({ length: 10 }, () => randomBytes(12).toString("hex").toUpperCase());
  return { codes, hashes: JSON.stringify(codes.map(digest)) };
}
export function matchesRecoveryCode(code: string, hashesJson: string) {
  let hashes: string[] = [];
  try { hashes = JSON.parse(hashesJson) as string[]; } catch { return null; }
  const hash = digest(code.replace(/[-\s]/g, "").toUpperCase());
  const index = hashes.findIndex(item => constantTimeTextEqual(item, hash));
  if (index < 0) return null;
  hashes.splice(index, 1);
  return JSON.stringify(hashes);
}

export async function adminCount() {
  const db = await getDb();
  if (!db) return 0;
  const rows = await db.select({ id: adminAccounts.id }).from(adminAccounts).limit(1);
  return rows.length;
}

export async function verifyBootstrapToken(token: string) {
  const configured = process.env.ADMIN_SETUP_TOKEN ?? "";
  return configured.length >= 32 && token.length > 0 && constantTimeTextEqual(configured, token);
}

export async function startMfaChallenge(res: Response, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const token = randomBytes(32).toString("base64url");
  await db.insert(adminChallenges).values({ tokenHash: digest(token), adminId, attempts: 0, expiresAt: new Date(Date.now() + MFA_MS) });
  res.cookie(MFA_COOKIE, token, cookieOptions(MFA_MS));
}

export async function getChallenge(req: Request) {
  const db = await getDb();
  const token = readCookies(req)[MFA_COOKIE];
  if (!db || !token) return null;
  const rows = await db.select().from(adminChallenges).where(eq(adminChallenges.tokenHash, digest(token))).limit(1);
  if (!rows[0] || rows[0].expiresAt.getTime() < Date.now() || rows[0].attempts >= 5) return null;
  return rows[0];
}

export async function recordChallengeFailure(tokenHash: string) {
  const db = await getDb();
  if (db) {
    await db.update(adminChallenges).set({ attempts: sql`${adminChallenges.attempts} + 1` }).where(eq(adminChallenges.tokenHash, tokenHash));
    await db.delete(adminChallenges).where(and(eq(adminChallenges.tokenHash, tokenHash), gte(adminChallenges.attempts, 5)));
  }
}

export function clearMfaCookie(res: Response) { res.clearCookie(MFA_COOKIE, cookieOptions(0)); }

export async function establishAdminSession(res: Response, admin: AdminIdentity) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const token = randomBytes(32).toString("base64url");
  const csrf = randomBytes(32).toString("base64url");
  await db.insert(adminSessions).values({ tokenHash: digest(token), adminId: admin.id, expiresAt: new Date(Date.now() + SESSION_MS) });
  res.cookie(SESSION_COOKIE, token, cookieOptions(SESSION_MS));
  res.cookie(CSRF_COOKIE, csrf, { ...cookieOptions(SESSION_MS), httpOnly: false });
}

export async function authenticateAdmin(req: Request): Promise<AdminIdentity | null> {
  const db = await getDb();
  const token = readCookies(req)[SESSION_COOKIE];
  if (!db || !token) return null;
  const rows = await db.select({ id: adminAccounts.id, email: adminAccounts.email, displayName: adminAccounts.displayName, role: adminAccounts.role, expiresAt: adminSessions.expiresAt, tokenHash: adminSessions.tokenHash })
    .from(adminSessions).innerJoin(adminAccounts, eq(adminSessions.adminId, adminAccounts.id))
    .where(and(eq(adminSessions.tokenHash, digest(token)), eq(adminAccounts.isActive, true))).limit(1);
  const row = rows[0];
  if (!row || row.expiresAt.getTime() < Date.now()) {
    if (row) await db.delete(adminSessions).where(eq(adminSessions.tokenHash, row.tokenHash));
    return null;
  }
  return safeIdentity(row);
}

export async function revokeCurrentSession(req: Request, res: Response) {
  const db = await getDb();
  const token = readCookies(req)[SESSION_COOKIE];
  if (db && token) await db.delete(adminSessions).where(eq(adminSessions.tokenHash, digest(token)));
  res.clearCookie(SESSION_COOKIE, cookieOptions(0));
  res.clearCookie(CSRF_COOKIE, { ...cookieOptions(0), httpOnly: false });
  clearMfaCookie(res);
}

export function allowAttempts(key: string, max = 8, windowMs = 10 * 60 * 1000) {
  const now = Date.now();
  const item = attemptsByKey.get(key);
  if (!item || item.resetAt <= now) { attemptsByKey.set(key, { count: 1, resetAt: now + windowMs }); return true; }
  if (item.count >= max) return false;
  item.count += 1;
  return true;
}

export async function verifyAccountPassword(email: string, password: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(adminAccounts).where(eq(adminAccounts.email, email)).limit(1);
  const admin = rows[0];
  if (!admin) {
    await passwordDigest(password, "unlisted-account-fixed-salt");
    return null;
  }
  if (!admin.isActive) { await passwordMatches(password, admin.passwordSalt, admin.passwordHash); return null; }
  if (admin.lockedUntil && admin.lockedUntil.getTime() > Date.now()) return null;
  if (!await passwordMatches(password, admin.passwordSalt, admin.passwordHash)) {
    const failedAttempts = admin.failedAttempts + 1;
    await db.update(adminAccounts).set({ failedAttempts, lockedUntil: failedAttempts >= 8 ? new Date(Date.now() + 15 * 60 * 1000) : null }).where(eq(adminAccounts.id, admin.id));
    return null;
  }
  await db.update(adminAccounts).set({ failedAttempts: 0, lockedUntil: null }).where(eq(adminAccounts.id, admin.id));
  return admin;
}

export async function verifySecondFactor(adminId: number, code: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(adminAccounts).where(eq(adminAccounts.id, adminId)).limit(1);
  const admin = rows[0];
  if (!admin || !admin.isActive) return null;
  const seed = decryptTotp(admin.totpCiphertext);
  if (verifyTotp(seed, code)) return { admin, recoveryCodes: admin.recoveryCodes };
  const remaining = matchesRecoveryCode(code, admin.recoveryCodes);
  if (remaining !== null) {
    const result = await db.update(adminAccounts).set({ recoveryCodes: remaining })
      .where(and(eq(adminAccounts.id, admin.id), eq(adminAccounts.recoveryCodes, admin.recoveryCodes)));
    if (affectedRows(result) !== 1) return null;
    return { admin, recoveryCodes: remaining, usedRecoveryCode: true };
  }
  return null;
}

export function encryptTotpForStorage(secret: string) { return encryptTotp(secret); }
export function hashToken(token: string) { return digest(token); }

export async function removeChallenge(tokenHash: string) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.delete(adminChallenges).where(eq(adminChallenges.tokenHash, tokenHash));
  return affectedRows(result) === 1;
}

export async function invitationByToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(adminInvitations).where(and(eq(adminInvitations.tokenHash, digest(token)), gt(adminInvitations.expiresAt, new Date()))).limit(1);
  return rows[0] ?? null;
}

export async function deleteInvitation(tokenHash: string) {
  const db = await getDb();
  if (db) await db.delete(adminInvitations).where(eq(adminInvitations.tokenHash, tokenHash));
}
