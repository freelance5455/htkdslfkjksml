#!/usr/bin/env bash
# نگهبان سلامت سرور ترید یار — هر دقیقه توسط systemd timer اجرا می‌شود (install.sh نصبش می‌کند).
# docker فقط کانتینر «مرده» را دوباره بالا می‌آورد؛ کانتینر «هنگ‌کرده/ناسالم» را ری‌استارت نمی‌کند.
# این اسکریپت همین خلأ را پر می‌کند:
#   ۱) /health داخلی ۳ بار پشت‌سرهم جواب نداد  → docker compose up -d + restart tradyar
#   ۲) داخلی سالم است ولی آدرس عمومی (HTTPS) جواب نمی‌دهد → restart caddy
cd "$(dirname "$0")" || exit 1
STATE_DIR="${STATE_DIR:-/var/tmp}"
F_IN="$STATE_DIR/tradyar-health-in"
F_PUB="$STATE_DIR/tradyar-health-pub"
DOMAIN="$(grep -E '^DOMAIN=.+' .env 2>/dev/null | cut -d= -f2- | tr -d '"' || true)"

bump() {  # bump FILE ok|fail  → خروجی: تعداد شکست پشت‌سرهم
  local f="$1" n=0
  if [[ "$2" == "ok" ]]; then echo 0 > "$f"; echo 0; return; fi
  n=$(( $(cat "$f" 2>/dev/null || echo 0) + 1 )); echo "$n" > "$f"; echo "$n"
}

if docker compose exec -T tradyar wget -qO- -T 5 http://127.0.0.1:8787/health >/dev/null 2>&1; then
  bump "$F_IN" ok >/dev/null
  if [[ -n "$DOMAIN" ]]; then
    if curl -fsS -m 8 "https://$DOMAIN/health" >/dev/null 2>&1; then
      bump "$F_PUB" ok >/dev/null
    else
      n=$(bump "$F_PUB" fail)
      if (( n >= 3 )); then
        logger -t tradyar-health "آدرس عمومی $n بار جواب نداد؛ ری‌استارت caddy"
        docker compose restart caddy; bump "$F_PUB" ok >/dev/null
      fi
    fi
  fi
else
  n=$(bump "$F_IN" fail)
  if (( n >= 3 )); then
    logger -t tradyar-health "سلامت داخلی $n بار شکست خورد؛ ری‌استارت tradyar"
    docker compose up -d
    docker compose restart tradyar
    bump "$F_IN" ok >/dev/null
  fi
fi
