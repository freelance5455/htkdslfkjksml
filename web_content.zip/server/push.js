import "./config.js";
import webpush from "web-push";
import { q } from "./db.js";

const publicKey = process.env.VAPID_PUBLIC_KEY || "";
const privateKey = process.env.VAPID_PRIVATE_KEY || "";
const subject = process.env.VAPID_SUBJECT || "mailto:admin@mazohubstore.com";

if (publicKey && privateKey) webpush.setVapidDetails(subject, publicKey, privateKey);

export function pushConfigured(){ return Boolean(publicKey && privateKey); }
export function getVapidPublicKey(){ return publicKey; }

export async function sendPushToAdmins(payload){
  if(!pushConfigured()) return {sent:0, skipped:true, reason:"VAPID keys are not configured"};
  const rows = (await q("SELECT ps.id, ps.endpoint, ps.p256dh, ps.auth FROM push_subscriptions ps JOIN users u ON u.id=ps.user_id WHERE ps.active=true AND ps.device_type='mobile' AND u.active=true AND u.role='admin'" )).rows;
  let sent=0;
  for(const s of rows){
    try{
      await webpush.sendNotification({endpoint:s.endpoint,keys:{p256dh:s.p256dh,auth:s.auth}},JSON.stringify(payload),{TTL:86400});
      sent++;
      await q("UPDATE push_subscriptions SET last_seen_at=NOW() WHERE id=$1",[s.id]);
    }catch(e){
      if(e.statusCode===404 || e.statusCode===410){
        await q("UPDATE push_subscriptions SET active=false WHERE id=$1",[s.id]);
      }
    }
  }
  return {sent,skipped:false};
}

export async function sendNewOrderPush(order){
  return sendPushToAdmins({
    type:"new_order",
    title:"NEW ORDER — MAZO HUB",
    body:`${order.order_number} · ${order.customer_name} · ${Number(order.total).toLocaleString("en-EG")} EGP`,
    order_number:order.order_number,
    url:"/admin/"
  });
}
