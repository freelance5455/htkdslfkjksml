import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const owner = {
  id: 7,
  openId: "owner-open-id",
  email: "owner@example.com",
  name: "Owner User",
  loginMethod: "manus",
  role: "owner" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

describe("dashboard identity", () => {
  it("returns the signed-in viewer name, email, id, and role", async () => {
    const ctx: TrpcContext = {
      user: owner,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: () => undefined } as TrpcContext["res"],
    };
    const result = await appRouter.createCaller(ctx).dashboard.overview();
    expect(result.viewer).toMatchObject({ id: 7, name: "Owner User", email: "owner@example.com", role: "owner" });
  });
});
