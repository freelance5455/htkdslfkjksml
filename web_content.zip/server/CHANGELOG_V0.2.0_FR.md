# SKYNET V2 — Journal des modifications 0.2.0

Cette mise à jour renforce le socle serveur existant sans supprimer l'interface HTML ni les modules historiques.

## Ajouts programmés

1. **Registre IOC dédié** : table `threat_indicators`, cloisonnée par organisation, dédoublonnage par empreinte SHA-256, validation des formats IPv4/domaine/URL/SHA-256, consultation via `GET /indicators`.
2. **Moteur local de règles de détection v1** : catalogue consultable via `GET /detection-rules` et évaluation effective de règles locales via `POST /detection-tests`.
3. **Score opérationnel explicable v1** : `GET /risk/summary` calcule un score pondéré à partir des 500 derniers événements du seul espace de l'organisation.
4. **Capacités annoncées plus précisément** : l'API distingue les fonctions locales des intégrations externes non configurées.
5. **Tests unitaires** : scénarios de correspondance et de non-correspondance des règles.

## Limites à ne pas masquer

- Le registre IOC ne consulte pas encore de flux CTI externes et ne vérifie pas la réputation d'un indicateur.
- Les règles de détection sont locales et simples ; elles ne remplacent pas un moteur SIEM/EDR de production.
- Le score de risque est un indicateur opérationnel heuristique, non une prédiction certifiée.
- `Base.metadata.create_all` crée les nouvelles tables, mais un système de migrations versionnées devra être mis en place avant une exploitation durable.
- L'interface HTML historique n'est pas automatiquement reliée à cette API par cette mise à jour.
- Cette version n'est ni auditée indépendamment ni certifiée pour la production.

## Vérifications

Exécuter depuis `server/` :

```bash
python -m compileall -q app
pytest -q
```

Les tests unitaires couvrent le moteur de règles local. Ils ne constituent pas un test de sécurité ni un test d'intégration complet.
