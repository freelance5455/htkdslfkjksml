import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { db } from './db.ts';
import { CSRF_COOKIE_NAME, parseCookies, SESSION_COOKIE_NAME, verifyAuthToken } from './security.ts';

export interface SystemLimitsRow {
  tier: 'free' | 'premium';
  max_projects: number;
  monthly_builds: number;
  max_upload_mb: number;
  priority_queue: number;
  premium_icons: number;
  ad_free: number;
  updated_at: string;
}

export interface ResolvedMembership {
  tier: 'free' | 'premium';
  isPremium: boolean;
  isLifetime: boolean;
  planCode: string;
  planName: string;
  subscriptionId: string | null;
  startedAt: string | null;
  expiresAt: string | null;
  remainingDays: number | null;
  limits: {
    maxProjects: number;
    monthlyBuilds: number;
    maxUploadMb: number;
    priorityQueue: boolean;
    premiumIcons: boolean;
    adFree: boolean;
  };
  usage: {
    projectCount: number;
    monthKey: string;
    monthlyBuildsUsed: number;
    remainingMonthlyBuilds: number;
  };
}

export interface AuthedRequest extends Request {
  authUser?: {
    id: string;
    username: string;
    email: string;
    role: 'user' | 'admin';
    avatarUrl?: string | null;
    bio?: string | null;
    themePref?: 'dark' | 'light';
  };
  membership?: ResolvedMembership;
}

export function getCurrentMonthKey(): string {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

export function resolveUserMembership(userId: string): ResolvedMembership {
  const now = new Date();
  const nowIso = now.toISOString();

  // Auto-expire any non-lifetime active subscription whose expires_at has passed
  db.prepare(`
    UPDATE subscriptions
    SET status = 'expired', updated_at = ?
    WHERE user_id = ? AND status = 'active' AND is_lifetime = 0 AND expires_at IS NOT NULL AND expires_at <= ?
  `).run(nowIso, userId, nowIso);

  const activeSub = db
    .prepare(`
      SELECT s.*, p.code as plan_code, p.name as plan_name
      FROM subscriptions s
      JOIN subscription_plans p ON s.plan_id = p.id
      WHERE s.user_id = ? AND s.status = 'active'
      ORDER BY s.is_lifetime DESC, s.created_at DESC
      LIMIT 1
    `)
    .get(userId) as
    | {
        id: string;
        plan_id: string;
        plan_code: string;
        plan_name: string;
        started_at: string;
        expires_at: string | null;
        is_lifetime: number;
      }
    | undefined;

  const isPremium = Boolean(activeSub);
  const tier: 'free' | 'premium' = isPremium ? 'premium' : 'free';

  const limitRow = db
    .prepare('SELECT * FROM system_limits WHERE tier = ?')
    .get(tier) as SystemLimitsRow;

  const projectCountRow = db
    .prepare('SELECT COUNT(*) as c FROM projects WHERE user_id = ?')
    .get(userId) as { c: number };

  const monthKey = getCurrentMonthKey();
  const usageRow = db
    .prepare('SELECT builds_count FROM build_usage WHERE user_id = ? AND month_key = ?')
    .get(userId, monthKey) as { builds_count: number } | undefined;

  const monthlyBuildsUsed = usageRow?.builds_count ?? 0;

  let remainingDays: number | null = null;
  if (activeSub) {
    if (activeSub.is_lifetime === 1 || !activeSub.expires_at) {
      remainingDays = null;
    } else {
      const diffMs = new Date(activeSub.expires_at).getTime() - now.getTime();
      remainingDays = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    }
  }

  return {
    tier,
    isPremium,
    isLifetime: activeSub?.is_lifetime === 1,
    planCode: activeSub?.plan_code || 'free',
    planName: activeSub?.plan_name || 'Ücretsiz Plan',
    subscriptionId: activeSub?.id || null,
    startedAt: activeSub?.started_at || null,
    expiresAt: activeSub?.expires_at || null,
    remainingDays,
    limits: {
      maxProjects: limitRow.max_projects,
      monthlyBuilds: limitRow.monthly_builds,
      maxUploadMb: limitRow.max_upload_mb,
      priorityQueue: Boolean(limitRow.priority_queue),
      premiumIcons: Boolean(limitRow.premium_icons),
      adFree: Boolean(limitRow.ad_free),
    },
    usage: {
      projectCount: projectCountRow.c,
      monthKey,
      monthlyBuildsUsed,
      remainingMonthlyBuilds: Math.max(0, limitRow.monthly_builds - monthlyBuildsUsed),
    },
  };
}

export function incrementMonthlyBuildUsage(userId: string): void {
  const monthKey = getCurrentMonthKey();
  const nowIso = new Date().toISOString();
  const existing = db
    .prepare('SELECT id, builds_count FROM build_usage WHERE user_id = ? AND month_key = ?')
    .get(userId, monthKey) as { id: string; builds_count: number } | undefined;

  if (existing) {
    db.prepare('UPDATE build_usage SET builds_count = builds_count + 1, updated_at = ? WHERE id = ?').run(
      nowIso,
      existing.id
    );
  } else {
    db.prepare(
      'INSERT INTO build_usage (id, user_id, month_key, builds_count, updated_at) VALUES (?, ?, ?, 1, ?)'
    ).run(`usg_${crypto.randomUUID().slice(0, 10)}`, userId, monthKey, nowIso);
  }
}

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  try {
    const cookies = parseCookies(req.headers.cookie);
    const authHeader = req.headers.authorization;
    const bearerToken =
      authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : undefined;
    const queryToken = typeof req.query.token === 'string' ? req.query.token.trim() : undefined;
    const cookieToken = cookies[SESSION_COOKIE_NAME];

    const token = bearerToken || cookieToken || queryToken;
    if (!token) {
      res.status(401).json({ error: 'Oturum açmanız gerekiyor.' });
      return;
    }

    // Double-submit CSRF check when authenticating exclusively via HttpOnly cookie on mutating methods
    const isMutating = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method.toUpperCase());
    if (isMutating && !bearerToken && cookieToken) {
      const csrfCookie = cookies[CSRF_COOKIE_NAME];
      const csrfHeader = String(req.headers['x-csrf-token'] || '');
      if (!csrfCookie || !csrfHeader || csrfCookie !== csrfHeader) {
        res.status(403).json({ error: 'CSRF güvenlik doğrulaması başarısız.' });
        return;
      }
    }

    const decoded = verifyAuthToken(token);
    const user = db
      .prepare('SELECT id, username, email, role, avatar_url, bio, theme_pref FROM users WHERE id = ?')
      .get(decoded.userId) as
      | {
          id: string;
          username: string;
          email: string;
          role: 'user' | 'admin';
          avatar_url: string | null;
          bio: string | null;
          theme_pref: string | null;
        }
      | undefined;

    if (!user) {
      res.status(401).json({ error: 'Kullanıcı hesabı bulunamadı.' });
      return;
    }

    req.authUser = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      avatarUrl: user.avatar_url,
      bio: user.bio,
      themePref: user.theme_pref === 'light' ? 'light' : 'dark',
    };
    req.membership = resolveUserMembership(user.id);
    next();
  } catch {
    res.status(401).json({ error: 'Geçersiz veya süresi dolmuş oturum jetonu.' });
  }
}

export function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.authUser || req.authUser.role !== 'admin') {
    res.status(403).json({ error: 'Bu işlem için yönetici yetkisi gereklidir.' });
    return;
  }
  next();
}

export function checkProjectQuota(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.membership) {
    res.status(401).json({ error: 'Üyelik bilgisi doğrulanamadı.' });
    return;
  }
  if (req.membership.usage.projectCount >= req.membership.limits.maxProjects) {
    res.status(403).json({
      error: `Proje sınırına (${req.membership.limits.maxProjects}) ulaştınız. Daha fazla proje için Premium üyeliğe geçin.`,
      upgradeRequired: !req.membership.isPremium,
      code: 'PROJECT_LIMIT_REACHED',
    });
    return;
  }
  next();
}

export function checkBuildQuota(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.membership) {
    res.status(401).json({ error: 'Üyelik bilgisi doğrulanamadı.' });
    return;
  }
  if (req.membership.usage.monthlyBuildsUsed >= req.membership.limits.monthlyBuilds) {
    res.status(403).json({
      error: `Aylık APK derleme limitinize (${req.membership.limits.monthlyBuilds}) ulaştınız. Limitlerinizi artırmak için Premium üyeliğe geçin.`,
      upgradeRequired: !req.membership.isPremium,
      code: 'BUILD_LIMIT_REACHED',
    });
    return;
  }
  next();
}
