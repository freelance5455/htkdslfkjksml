import type { JavaTrack, ServerSoftware } from "../shared/minecraft";

const MANIFEST_URL =
  "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const FORGE_PROMOTIONS_URL =
  "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json";
const CACHE_MS = 15 * 60 * 1000;

type MojangManifest = {
  latest?: { release?: string; snapshot?: string };
  versions?: Array<{ id: string; type: string; releaseTime?: string }>;
};
type ForgePromotions = { promos?: Record<string, string> };
type CacheRecord<T> = { expiresAt: number; value: T };

let manifestCache: CacheRecord<MojangManifest> | undefined;
let forgeCache: CacheRecord<ForgePromotions> | undefined;
let manifestPending: Promise<MojangManifest> | undefined;
let forgePending: Promise<ForgePromotions> | undefined;

async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  if (!response.ok)
    throw new Error(
      `Version catalog request failed with HTTP ${response.status}`
    );
  return (await response.json()) as T;
}

async function getManifest(): Promise<MojangManifest> {
  if (manifestCache && manifestCache.expiresAt > Date.now())
    return manifestCache.value;
  if (!manifestPending) {
    manifestPending = fetchJson<MojangManifest>(MANIFEST_URL)
      .then(value => {
        if (!Array.isArray(value.versions))
          throw new Error("Mojang version manifest is invalid");
        manifestCache = { value, expiresAt: Date.now() + CACHE_MS };
        return value;
      })
      .finally(() => {
        manifestPending = undefined;
      });
  }
  return manifestPending;
}

async function getForgePromotions(): Promise<ForgePromotions> {
  if (forgeCache && forgeCache.expiresAt > Date.now()) return forgeCache.value;
  if (!forgePending) {
    forgePending = fetchJson<ForgePromotions>(FORGE_PROMOTIONS_URL)
      .then(value => {
        if (!value.promos)
          throw new Error("Forge promotion catalog is invalid");
        forgeCache = { value, expiresAt: CACHE_MS + Date.now() };
        return value;
      })
      .finally(() => {
        forgePending = undefined;
      });
  }
  return forgePending;
}

export async function listJavaVersions(
  track: JavaTrack,
  software: ServerSoftware
) {
  const manifest = await getManifest();
  let versions = (manifest.versions ?? [])
    .filter(version => version.type === track)
    .map(version => version.id);

  if (software === "forge") {
    if (track === "old_alpha" || track === "old_beta") versions = [];
    else {
      const promotions = await getForgePromotions();
      const compatibleMinecraftVersions = new Set(
        Object.keys(promotions.promos ?? {}).map(key =>
          key.replace(/-(latest|recommended)$/, "")
        )
      );
      versions = versions.filter(version =>
        compatibleMinecraftVersions.has(version)
      );
    }
  }

  return {
    versions,
    updatedAt: new Date().toISOString(),
    source: "Mojang" as const,
    latestRelease: manifest.latest?.release ?? null,
    latestSnapshot: manifest.latest?.snapshot ?? null,
  };
}

export function getHostingStatus() {
  return {
    connected: false as const,
    state: "not-configured" as const,
    provider: null,
    message:
      "К этой панели не подключён игровой хостинг. Сайт может сохранять и экспортировать настройки, но не размещает процесс Minecraft и не выдаёт IP:порт.",
    note: "Для настоящего сервера нужны отдельный постоянно работающий игровой узел, игровые TCP/UDP-порты и безопасно настроенный провайдер с проверкой доступа.",
  };
}

export function getProvisioningResult() {
  return {
    created: false as const,
    code: "HOSTING_NOT_CONNECTED" as const,
    message:
      "Сервер не запущен: игровой хостинг не подключён. Конфигурацию можно сохранить в панели и экспортировать.",
  };
}
