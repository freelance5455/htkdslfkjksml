/**
 * JARVIS Conversation Context Engine
 * Bounded, structured context assembly combining:
 * 1. Current user message
 * 2. Recent conversation dialogue (deduplicated, bounded window)
 * 3. Active task/plan state & tool observations
 * 4. Relevant long-term memories (relevance-filtered)
 * 5. Active user preferences
 */

import { db } from '../db/database.ts';
import { memorySystem } from '../memory/memorySystem.ts';
import { preferenceSystem, UserPreferences } from '../memory/preferenceSystem.ts';
import type { ChatMessage, FileAttachmentEntity, MemoryEntry, TaskItem } from '../types.ts';

export interface BoundedContextEnvelope {
  currentMessage: string;
  recentMessages: { role: 'user' | 'assistant' | 'system'; content: string }[];
  relevantMemories: MemoryEntry[];
  preferences: UserPreferences;
  attachedFiles?: FileAttachmentEntity[];
  projectContext?: {
    id: string;
    name: string;
    description: string;
    contextBrief?: string;
    status: string;
  };
  activeTask?: {
    id: string;
    title: string;
    status: string;
    executedSteps: { stepNumber: number; title: string; output?: unknown; status: string }[];
  };
  formattedPrompt: string;
}

export class ContextEngine {
  private static readonly MAX_RECENT_MESSAGES = 8;
  private static readonly MAX_MESSAGE_CHARS = 1000;
  private static readonly MAX_MEMORY_ITEMS = 4;

  /**
   * Build complete bounded context envelope for a new user request
   */
  public async buildContext(params: {
    userPrompt: string;
    conversationId?: string;
    projectId?: string;
    currentTask?: TaskItem;
    userId?: string;
  }): Promise<BoundedContextEnvelope> {
    const { userPrompt, conversationId = 'conv_default', currentTask, userId = 'usr_jarvis_prime' } = params;

    // 1. Fetch recent conversation history with bounded window
    const rawMessages = await db.getMessages(conversationId);
    const recentMessages = this.extractBoundedRecentMessages(rawMessages, userPrompt);

    // 2. Fetch project context if conversation is associated with a project
    let projectContext: BoundedContextEnvelope['projectContext'] | undefined;
    let targetProjectId = params.projectId;
    if (!targetProjectId && db.getConversation) {
      const conv = await db.getConversation(conversationId);
      if (conv?.projectId) {
        targetProjectId = conv.projectId;
      }
    }
    if (targetProjectId && db.getProject) {
      const proj = await db.getProject(targetProjectId);
      if (proj && !proj.isTrash) {
        projectContext = {
          id: proj.id,
          name: proj.name,
          description: proj.description,
          contextBrief: proj.contextBrief,
          status: proj.status,
        };
      }
    }

    // 3. Fetch relevant long-term memories
    const relevantMemories = await memorySystem.retrieve({
      text: userPrompt,
      limit: ContextEngine.MAX_MEMORY_ITEMS,
      minImportance: 5,
    });

    // 4. Fetch user preferences
    const preferences = await preferenceSystem.getPreferences(userId);

    // 5. Summarize active task execution state if present
    let activeTaskSummary: BoundedContextEnvelope['activeTask'] | undefined;
    if (currentTask && currentTask.plan) {
      activeTaskSummary = {
        id: currentTask.id,
        title: currentTask.title,
        status: currentTask.status,
        executedSteps: currentTask.plan.steps.map((s) => ({
          stepNumber: s.stepNumber,
          title: s.title,
          output: s.toolOutput,
          status: s.status,
        })),
      };
    }

    // 6. Fetch attached files for this conversation or project
    let attachedFiles: FileAttachmentEntity[] = [];
    if (db.getFiles) {
      attachedFiles = await db.getFiles({ conversationId, projectId: targetProjectId });
    }

    // 7. Compose formatted prompt envelope with layered hierarchy
    const formattedPrompt = this.formatContextEnvelope({
      userPrompt,
      recentMessages,
      projectContext,
      relevantMemories,
      preferences,
      activeTask: activeTaskSummary,
      attachedFiles,
    });

    return {
      currentMessage: userPrompt,
      recentMessages,
      projectContext,
      relevantMemories,
      preferences,
      attachedFiles,
      activeTask: activeTaskSummary,
      formattedPrompt,
    };
  }

  /**
   * Filter, deduplicate, and limit recent messages
   */
  private extractBoundedRecentMessages(
    messages: ChatMessage[],
    currentPrompt: string
  ): { role: 'user' | 'assistant' | 'system'; content: string }[] {
    if (!messages || messages.length === 0) return [];

    // Filter out duplicate trailing user message if it matches the currentPrompt
    const filtered = messages.filter((m, idx) => {
      if (idx === messages.length - 1 && m.role === 'user' && m.content.trim() === currentPrompt.trim()) {
        return false;
      }
      return true;
    });

    // Take the last N messages
    const bounded = filtered.slice(-ContextEngine.MAX_RECENT_MESSAGES);

    return bounded.map((m) => ({
      role: m.role,
      content: m.content.length > ContextEngine.MAX_MESSAGE_CHARS
        ? m.content.slice(0, ContextEngine.MAX_MESSAGE_CHARS) + '... [truncated]'
        : m.content,
    }));
  }

  /**
   * Format context sections into an organized prompt envelope
   */
  private formatContextEnvelope(params: {
    userPrompt: string;
    recentMessages: { role: 'user' | 'assistant' | 'system'; content: string }[];
    projectContext?: BoundedContextEnvelope['projectContext'];
    relevantMemories: MemoryEntry[];
    preferences: UserPreferences;
    activeTask?: BoundedContextEnvelope['activeTask'];
    attachedFiles?: FileAttachmentEntity[];
  }): string {
    const sections: string[] = [];

    // Layer 1: Project Context (if conversation is part of an active project)
    if (params.projectContext) {
      const p = params.projectContext;
      const brief = p.contextBrief ? `\nScope/Brief: ${p.contextBrief}` : '';
      sections.push(`--- LAYER 1: PROJECT WORKSPACE CONTEXT ---\nProject: "${p.name}" (${p.status})\nDescription: ${p.description}${brief}`);
    }

    // Layer 2: Attached Files & Documents Context
    if (params.attachedFiles && params.attachedFiles.length > 0) {
      const filesFormatted = params.attachedFiles
        .map((f) => {
          const preview = f.textContent ? `\nExtracted Content:\n${f.textContent.slice(0, 1500)}` : '';
          return `• [FILE] ${f.originalName} (${f.fileCategory}, status: ${f.extractionStatus}): ${f.summary || 'No summary'}${preview}`;
        })
        .join('\n\n');
      sections.push(`--- LAYER 2: ATTACHED WORKSPACE FILES & DOCUMENTS ---\n${filesFormatted}`);
    }

    // Layer 3: Recent Conversation History Section
    if (params.recentMessages.length > 0) {
      const dialogue = params.recentMessages
        .map((m) => `[CURRENT_CONTEXT] ${m.role.toUpperCase()}: ${m.content}`)
        .join('\n');
      sections.push(`--- LAYER 3: RECENT CONVERSATION CONTEXT / ACTIVE HISTORY ---\n${dialogue}`);
    }

    // Layer 4: Active Task & Step Execution Section
    if (params.activeTask && params.activeTask.executedSteps.length > 0) {
      const stepsFormatted = params.activeTask.executedSteps
        .map((s) => {
          const outStr = s.output ? ` | Output: ${typeof s.output === 'string' ? s.output.slice(0, 300) : JSON.stringify(s.output).slice(0, 300)}` : '';
          return `Step #${s.stepNumber} [${s.status}]: ${s.title}${outStr}`;
        })
        .join('\n');
      sections.push(`--- LAYER 4: EXECUTED TASK CONTEXT ---\nTask: ${params.activeTask.title} (${params.activeTask.status})\n${stepsFormatted}`);
    }

    // Layer 5: Long-Term Memories Section with Epistemic Truth Labels
    if (params.relevantMemories.length > 0) {
      const memoriesFormatted = params.relevantMemories
        .map((m) => `• [STORED] [${m.key}]: ${m.content}`)
        .join('\n');
      sections.push(`--- LAYER 5: RELEVANT LONG-TERM MEMORIES ---\n${memoriesFormatted}`);
    }

    // Layer 6: User Preferences Section
    const prefLines: string[] = [];
    if (params.preferences.preferredLanguage) prefLines.push(`Language Preference: ${params.preferences.preferredLanguage}`);
    if (params.preferences.explanationDepth) prefLines.push(`Depth Preference: ${params.preferences.explanationDepth}`);
    if (params.preferences.technicalLevel) prefLines.push(`Technical Level: ${params.preferences.technicalLevel}`);
    if (prefLines.length > 0) {
      sections.push(`--- LAYER 6: USER PREFERENCES ---\n${prefLines.join('\n')}`);
    }

    // Target Current Request
    sections.push(`--- CURRENT USER REQUEST ---\n[CURRENT_CONTEXT] ${params.userPrompt}`);

    return sections.join('\n\n');
  }
}

export const contextEngine = new ContextEngine();
