import fs from 'node:fs';
import path from 'node:path';
import type {
  ConversationThread,
  MemoryCategory,
  UserMemoryItem,
} from '../../src/lib/jarvisTypes';
import { isDuplicateMemory } from '../../src/lib/memoryLogic';

export interface PersistentJarvisStore {
  threads: ConversationThread[];
  memories: UserMemoryItem[];
}

const VALID_CATEGORIES = new Set<MemoryCategory>([
  'preference',
  'project',
  'decision',
  'task',
  'fact',
]);

export class JarvisMemoryStore {
  private filePath: string;
  private cache: PersistentJarvisStore | null = null;

  constructor(dataDir = path.resolve(process.cwd(), '.data')) {
    this.filePath = path.join(dataDir, 'jarvis-store.json');
  }

  private ensureLoaded(): PersistentJarvisStore {
    if (this.cache) return this.cache;

    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const parsed = JSON.parse(raw) as Partial<PersistentJarvisStore>;
        this.cache = {
          threads: Array.isArray(parsed.threads) ? parsed.threads : [],
          memories: Array.isArray(parsed.memories) ? parsed.memories : [],
        };
        return this.cache;
      }
    } catch {
      // Recover gracefully if file is unreadable
    }

    this.cache = { threads: [], memories: [] };
    return this.cache;
  }

  private persist(): void {
    const data = this.ensureLoaded();
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const tmpPath = `${this.filePath}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tmpPath, this.filePath);
  }

  listThreads(): ConversationThread[] {
    return [...this.ensureLoaded().threads].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  getThread(id: string): ConversationThread | undefined {
    return this.ensureLoaded().threads.find((t) => t.id === id);
  }

  upsertThread(thread: ConversationThread): ConversationThread {
    const store = this.ensureLoaded();
    const sanitized: ConversationThread = {
      id: String(thread.id).slice(0, 80),
      title: String(thread.title || 'New Conversation').slice(0, 120),
      domain: thread.domain || 'general',
      createdAt: Number(thread.createdAt) || Date.now(),
      updatedAt: Number(thread.updatedAt) || Date.now(),
      messages: Array.isArray(thread.messages) ? thread.messages.slice(-100) : [],
    };

    const idx = store.threads.findIndex((t) => t.id === sanitized.id);
    if (idx >= 0) {
      store.threads[idx] = sanitized;
    } else {
      store.threads.unshift(sanitized);
    }

    // Keep up to 50 recent threads
    store.threads = store.threads
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, 50);

    this.persist();
    return sanitized;
  }

  migrateThreads(incoming: ConversationThread[]): ConversationThread[] {
    const store = this.ensureLoaded();
    const existingIds = new Set(store.threads.map((t) => t.id));
    let changed = false;

    for (const thread of incoming.slice(0, 30)) {
      if (!thread?.id || existingIds.has(thread.id)) continue;
      if (!Array.isArray(thread.messages) || thread.messages.length === 0) continue;
      store.threads.push({
        id: String(thread.id).slice(0, 80),
        title: String(thread.title || 'Saved Conversation').slice(0, 120),
        domain: thread.domain || 'general',
        createdAt: Number(thread.createdAt) || Date.now(),
        updatedAt: Number(thread.updatedAt) || Date.now(),
        messages: thread.messages.slice(-100),
      });
      existingIds.add(thread.id);
      changed = true;
    }

    if (changed) {
      store.threads = store.threads
        .sort((a, b) => b.updatedAt - a.updatedAt)
        .slice(0, 50);
      this.persist();
    }

    return this.listThreads();
  }

  deleteThread(id: string): boolean {
    const store = this.ensureLoaded();
    const before = store.threads.length;
    store.threads = store.threads.filter((t) => t.id !== id);
    if (store.threads.length !== before) {
      this.persist();
      return true;
    }
    return false;
  }

  clearThreads(): void {
    const store = this.ensureLoaded();
    store.threads = [];
    this.persist();
  }

  listMemories(): UserMemoryItem[] {
    return [...this.ensureLoaded().memories].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  addMemory(input: {
    category: MemoryCategory;
    content: string;
    sourceThreadId?: string;
    completed?: boolean;
  }): { item: UserMemoryItem; created: boolean } {
    const store = this.ensureLoaded();
    const cleanContent = input.content.trim().slice(0, 500);
    if (!cleanContent) {
      throw new Error('Memory content cannot be empty.');
    }
    const category: MemoryCategory = VALID_CATEGORIES.has(input.category)
      ? input.category
      : 'fact';

    if (isDuplicateMemory(store.memories, cleanContent, category)) {
      const existing = store.memories.find(
        (m) => m.category === category && m.content.toLowerCase() === cleanContent.toLowerCase(),
      ) ?? store.memories[0];
      return { item: existing, created: false };
    }

    const now = Date.now();
    const item: UserMemoryItem = {
      id: `mem-${now}-${Math.random().toString(36).slice(2, 7)}`,
      category,
      content: cleanContent,
      completed: category === 'task' ? Boolean(input.completed) : undefined,
      sourceThreadId: input.sourceThreadId,
      createdAt: now,
      updatedAt: now,
    };

    store.memories.unshift(item);
    store.memories = store.memories.slice(0, 200);
    this.persist();
    return { item, created: true };
  }

  updateMemory(
    id: string,
    patch: { content?: string; category?: MemoryCategory; completed?: boolean },
  ): UserMemoryItem | null {
    const store = this.ensureLoaded();
    const idx = store.memories.findIndex((m) => m.id === id);
    if (idx === -1) return null;

    const current = store.memories[idx];
    const nextCategory =
      patch.category && VALID_CATEGORIES.has(patch.category)
        ? patch.category
        : current.category;
    const nextContent =
      patch.content !== undefined ? patch.content.trim().slice(0, 500) : current.content;
    if (!nextContent) {
      throw new Error('Memory content cannot be empty.');
    }

    const updated: UserMemoryItem = {
      ...current,
      category: nextCategory,
      content: nextContent,
      completed:
        nextCategory === 'task'
          ? patch.completed !== undefined
            ? Boolean(patch.completed)
            : Boolean(current.completed)
          : undefined,
      updatedAt: Date.now(),
    };

    store.memories[idx] = updated;
    this.persist();
    return updated;
  }

  deleteMemory(id: string): boolean {
    const store = this.ensureLoaded();
    const before = store.memories.length;
    store.memories = store.memories.filter((m) => m.id !== id);
    if (store.memories.length !== before) {
      this.persist();
      return true;
    }
    return false;
  }

  clearMemories(): void {
    const store = this.ensureLoaded();
    store.memories = [];
    this.persist();
  }
}

export const memoryStore = new JarvisMemoryStore();
