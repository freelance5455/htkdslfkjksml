import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { JarvisMemoryStore } from './memoryStore';
import { buildJarvisSystemInstruction } from '../ai/systemPrompt';

test('JarvisMemoryStore persists, updates, deduplicates, and deletes memories across reloads', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jarvis-mem-test-'));
  try {
    const store1 = new JarvisMemoryStore(tmpDir);
    const added = store1.addMemory({
      category: 'project',
      content: 'Building Android integration for JARVIS AI',
    });
    assert.equal(added.created, true);

    const dup = store1.addMemory({
      category: 'project',
      content: 'building android integration for jarvis ai',
    });
    assert.equal(dup.created, false);

    // Reload from disk in a fresh store instance
    const store2 = new JarvisMemoryStore(tmpDir);
    const memories = store2.listMemories();
    assert.equal(memories.length, 1);
    assert.equal(memories[0].content, 'Building Android integration for JARVIS AI');

    const updated = store2.updateMemory(memories[0].id, {
      category: 'task',
      content: 'Finish Android intent bridge spec',
      completed: true,
    });
    assert.equal(updated?.category, 'task');
    assert.equal(updated?.completed, true);

    assert.equal(store2.deleteMemory(memories[0].id), true);
    assert.equal(store2.listMemories().length, 0);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('buildJarvisSystemInstruction injects only saved memories and enforces memory honesty', () => {
  const promptWithMemories = buildJarvisSystemInstruction({
    domain: 'planning',
    depth: 'balanced',
    languagePreference: 'auto',
    detectedLanguage: 'english',
    memories: [
      {
        id: 'm1',
        category: 'project',
        content: 'Launching JARVIS v2 text workspace',
        createdAt: 1000,
        updatedAt: 1000,
      },
    ],
  });

  assert.ok(promptWithMemories.includes('Launching JARVIS v2 text workspace'));
  assert.ok(promptWithMemories.includes('NEVER falsely claim to remember'));

  const promptEmpty = buildJarvisSystemInstruction({
    domain: 'general',
    depth: 'balanced',
    languagePreference: 'hinglish',
    detectedLanguage: 'hinglish',
    memories: [],
    inputMode: 'voice',
    listeningActive: false,
  });
  assert.ok(promptEmpty.includes('(No saved user memories yet.)'));
  assert.ok(promptEmpty.includes('NEVER introduce yourself'));
  assert.ok(promptEmpty.includes('[VOICE_STATUS] Microphone listening mode is currently OFF.'));
});
