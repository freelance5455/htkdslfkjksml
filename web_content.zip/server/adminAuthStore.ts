import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface AdminAccount {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  salt: string;
  role: 'admin';
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}

export interface AdminSession {
  token: string;
  adminId: string;
  email: string;
  name: string;
  role: 'admin';
  createdAt: number;
  expiresAt: number;
}

export interface PasswordResetToken {
  token: string;
  email: string;
  expiresAt: number;
  createdAt: number;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const ADMIN_ACCOUNTS_FILE = path.join(DATA_DIR, 'admin_accounts.json');
const ADMIN_SESSIONS_FILE = path.join(DATA_DIR, 'admin_sessions.json');
const RESET_TOKENS_FILE = path.join(DATA_DIR, 'admin_reset_tokens.json');

// Secret key for HMAC signing of tokens
const SESSION_SECRET = process.env.ADMIN_SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const SESSION_DURATION_MS = 24 * 60 * 60 * 1000; // 24 Hours
const RESET_TOKEN_DURATION_MS = 60 * 60 * 1000; // 1 Hour

// Default configured Admin Email from environment or project owner
const DEFAULT_ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'sudipdas22061999@gmail.com').toLowerCase().trim();

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) {
    console.error('Failed to create data directory:', e);
  }
}

// In-Memory caches with file persistence
let adminAccounts: AdminAccount[] = [];
let activeSessions: Map<string, AdminSession> = new Map();
let resetTokens: Map<string, PasswordResetToken> = new Map();

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

function generateToken(payload: string): string {
  const randomPart = crypto.randomBytes(24).toString('hex');
  const timestamp = Date.now().toString();
  const raw = `${payload}:${timestamp}:${randomPart}`;
  const hmac = crypto.createHmac('sha256', SESSION_SECRET).update(raw).digest('hex');
  return `adm_${Buffer.from(raw).toString('base64url')}.${hmac}`;
}

function verifyTokenSignature(token: string): { valid: boolean; raw?: string } {
  try {
    if (!token.startsWith('adm_')) return { valid: false };
    const parts = token.slice(4).split('.');
    if (parts.length !== 2) return { valid: false };
    const [b64Raw, hmac] = parts;
    const raw = Buffer.from(b64Raw, 'base64url').toString('utf8');
    const expectedHmac = crypto.createHmac('sha256', SESSION_SECRET).update(raw).digest('hex');
    
    // Constant-time comparison
    if (crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(expectedHmac))) {
      return { valid: true, raw };
    }
    return { valid: false };
  } catch {
    return { valid: false };
  }
}

// Load Accounts from File
function loadAccounts(): void {
  try {
    if (fs.existsSync(ADMIN_ACCOUNTS_FILE)) {
      const data = fs.readFileSync(ADMIN_ACCOUNTS_FILE, 'utf8');
      adminAccounts = JSON.parse(data);
    } else {
      adminAccounts = [];
    }
  } catch (err) {
    console.error('Error loading admin accounts:', err);
    adminAccounts = [];
  }

  // Ensure default Admin Account exists
  const existingDefault = adminAccounts.find(a => a.email.toLowerCase() === DEFAULT_ADMIN_EMAIL);
  if (!existingDefault) {
    // Generate initial secure account with a securely hashed credential
    // Note: Admin can use this or reset password at any time via the Forgot Password or Setup screen
    const salt = generateSalt();
    const initialHash = hashPassword('Admin@EduMind2026!', salt);
    const newAdmin: AdminAccount = {
      id: 'admin_primary_01',
      email: DEFAULT_ADMIN_EMAIL,
      name: 'StudySkill Lead Administrator',
      passwordHash: initialHash,
      salt: salt,
      role: 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    adminAccounts.push(newAdmin);
    saveAccounts();
    console.log(`[AdminAuth] Initialized Primary Admin Account for: ${DEFAULT_ADMIN_EMAIL}`);
  }
}

function saveAccounts(): void {
  try {
    fs.writeFileSync(ADMIN_ACCOUNTS_FILE, JSON.stringify(adminAccounts, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving admin accounts:', err);
  }
}

function loadSessions(): void {
  try {
    if (fs.existsSync(ADMIN_SESSIONS_FILE)) {
      const data = fs.readFileSync(ADMIN_SESSIONS_FILE, 'utf8');
      const list: AdminSession[] = JSON.parse(data);
      const now = Date.now();
      activeSessions.clear();
      list.forEach(s => {
        if (s.expiresAt > now) {
          activeSessions.set(s.token, s);
        }
      });
    }
  } catch (err) {
    console.error('Error loading admin sessions:', err);
  }
}

function saveSessions(): void {
  try {
    const list = Array.from(activeSessions.values());
    fs.writeFileSync(ADMIN_SESSIONS_FILE, JSON.stringify(list, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving admin sessions:', err);
  }
}

// Initialize stores
loadAccounts();
loadSessions();

/**
 * Authenticate Admin with Email & Password
 */
export function authenticateAdmin(email: string, password: string): {
  success: boolean;
  token?: string;
  user?: { id: string; email: string; name: string; role: 'admin' };
  error?: string;
} {
  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanPassword = (password || '').trim();

  if (!cleanEmail || !cleanPassword) {
    return { success: false, error: 'Email and password are required.' };
  }

  // Find admin account
  const account = adminAccounts.find(a => a.email.toLowerCase() === cleanEmail);
  if (!account) {
    return { success: false, error: 'Access Denied: Invalid email or password.' };
  }

  // Verify Role
  if (account.role !== 'admin') {
    return { success: false, error: 'Access Denied: Account does not have administrator privileges.' };
  }

  // Verify Password
  const inputHash = hashPassword(cleanPassword, account.salt);
  const isMatch = crypto.timingSafeEqual(
    Buffer.from(inputHash, 'hex'),
    Buffer.from(account.passwordHash, 'hex')
  );

  if (!isMatch) {
    return { success: false, error: 'Access Denied: Invalid email or password.' };
  }

  // Update last login
  account.lastLoginAt = new Date().toISOString();
  saveAccounts();

  // Create active session
  const token = generateToken(account.id);
  const now = Date.now();
  const session: AdminSession = {
    token,
    adminId: account.id,
    email: account.email,
    name: account.name,
    role: 'admin',
    createdAt: now,
    expiresAt: now + SESSION_DURATION_MS
  };

  activeSessions.set(token, session);
  saveSessions();

  return {
    success: true,
    token,
    user: {
      id: account.id,
      email: account.email,
      name: account.name,
      role: 'admin'
    }
  };
}

/**
 * Verify an Admin Session Token
 */
export function verifyAdminSession(token?: string): {
  valid: boolean;
  user?: { id: string; email: string; name: string; role: 'admin' };
  error?: string;
} {
  if (!token) {
    return { valid: false, error: 'Access Denied: No authentication token provided.' };
  }

  const cleanToken = token.trim();

  // Check cryptographic signature first
  const sigCheck = verifyTokenSignature(cleanToken);
  if (!sigCheck.valid) {
    return { valid: false, error: 'Access Denied: Invalid or forged session token.' };
  }

  // Check in-memory active session
  const session = activeSessions.get(cleanToken);
  if (!session) {
    return { valid: false, error: 'Access Denied: Session expired or not found. Please log in again.' };
  }

  // Check expiration
  if (Date.now() > session.expiresAt) {
    activeSessions.delete(cleanToken);
    saveSessions();
    return { valid: false, error: 'Access Denied: Admin session has expired. Please log in again.' };
  }

  // Check role claim
  if (session.role !== 'admin') {
    return { valid: false, error: 'Access Denied: Account lacks required administrator claims.' };
  }

  return {
    valid: true,
    user: {
      id: session.adminId,
      email: session.email,
      name: session.name,
      role: 'admin'
    }
  };
}

/**
 * Invalidate Admin Session (Logout)
 */
export function invalidateAdminSession(token: string): boolean {
  if (!token) return false;
  const deleted = activeSessions.delete(token.trim());
  if (deleted) {
    saveSessions();
  }
  return true;
}

/**
 * Request Admin Password Reset
 */
export function requestAdminPasswordReset(email: string): {
  success: boolean;
  message: string;
  resetToken?: string;
} {
  const cleanEmail = (email || '').trim().toLowerCase();
  if (!cleanEmail) {
    return { success: false, message: 'Admin email is required.' };
  }

  const account = adminAccounts.find(a => a.email.toLowerCase() === cleanEmail);
  if (!account) {
    // For security reasons, still return a generic success message so attacker cannot enumerate emails
    return { 
      success: true, 
      message: 'If the provided email is registered as an Admin, password reset instructions and security token have been generated.' 
    };
  }

  // Generate 32-byte secure reset token
  const resetToken = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  resetTokens.set(resetToken, {
    token: resetToken,
    email: cleanEmail,
    createdAt: now,
    expiresAt: now + RESET_TOKEN_DURATION_MS
  });

  return {
    success: true,
    message: 'Password reset security verification initiated successfully.',
    resetToken: resetToken // Provided securely for reset flow
  };
}

/**
 * Reset Admin Password with Token
 */
export function resetAdminPassword(token: string, newPassword: string): {
  success: boolean;
  message: string;
} {
  const cleanToken = (token || '').trim();
  const cleanNewPassword = (newPassword || '').trim();

  if (!cleanToken || !cleanNewPassword) {
    return { success: false, message: 'Reset token and new password are required.' };
  }

  if (cleanNewPassword.length < 8) {
    return { success: false, message: 'New password must be at least 8 characters long.' };
  }

  const record = resetTokens.get(cleanToken);
  if (!record || Date.now() > record.expiresAt) {
    resetTokens.delete(cleanToken);
    return { success: false, message: 'Invalid or expired password reset token. Please request a new one.' };
  }

  const account = adminAccounts.find(a => a.email.toLowerCase() === record.email.toLowerCase());
  if (!account) {
    return { success: false, message: 'Admin account not found.' };
  }

  // Hash new password with fresh salt
  const newSalt = generateSalt();
  account.salt = newSalt;
  account.passwordHash = hashPassword(cleanNewPassword, newSalt);
  account.updatedAt = new Date().toISOString();
  saveAccounts();

  // Invalidate reset token
  resetTokens.delete(cleanToken);

  // Invalidate all existing sessions for this admin (force re-login for security)
  for (const [sToken, session] of activeSessions.entries()) {
    if (session.adminId === account.id) {
      activeSessions.delete(sToken);
    }
  }
  saveSessions();

  return {
    success: true,
    message: 'Admin password updated securely. Please sign in with your new credentials.'
  };
}

/**
 * Update Admin Profile / Change Password (when logged in)
 */
export function updateAdminCredentials(
  adminId: string,
  currentPassword: string,
  newPassword?: string,
  newName?: string
): { success: boolean; message: string } {
  const account = adminAccounts.find(a => a.id === adminId);
  if (!account) {
    return { success: false, message: 'Admin account not found.' };
  }

  // Verify current password
  const currentHash = hashPassword(currentPassword.trim(), account.salt);
  const isMatch = crypto.timingSafeEqual(
    Buffer.from(currentHash, 'hex'),
    Buffer.from(account.passwordHash, 'hex')
  );

  if (!isMatch) {
    return { success: false, message: 'Current password is incorrect.' };
  }

  if (newName && newName.trim()) {
    account.name = newName.trim();
  }

  if (newPassword && newPassword.trim()) {
    if (newPassword.trim().length < 8) {
      return { success: false, message: 'New password must be at least 8 characters long.' };
    }
    const newSalt = generateSalt();
    account.salt = newSalt;
    account.passwordHash = hashPassword(newPassword.trim(), newSalt);
  }

  account.updatedAt = new Date().toISOString();
  saveAccounts();

  return { success: true, message: 'Admin credentials updated successfully.' };
}

/**
 * Get sanitized info about configured Admin account
 */
export function getSanitizedAdminConfig(): {
  email: string;
  name: string;
  role: 'admin';
  isConfigured: boolean;
} {
  const primary = adminAccounts.find(a => a.role === 'admin') || {
    email: DEFAULT_ADMIN_EMAIL,
    name: 'StudySkill Lead Administrator',
    role: 'admin' as const
  };

  return {
    email: primary.email,
    name: primary.name,
    role: 'admin',
    isConfigured: adminAccounts.length > 0
  };
}
