/**
 * JARVIS Version Evolution & Metadata Foundation
 * Governs product versioning, underlying provider decoupling, release criteria,
 * and evolutionary validation lifecycle.
 * 
 * Strict Reality Contract:
 * - Product version (JARVIS 4.6) is distinct from underlying model engines.
 * - Version evolution is governed by rigorous gates:
 *   IMPROVEMENT -> IMPLEMENTATION -> AUTOMATED TESTS -> REGRESSION TESTS ->
 *   SECURITY CHECK -> BUILD -> RUNTIME CHECK -> CHECKPOINT -> VERSION ELIGIBLE.
 * - Never invents model names or allows uncontrolled self-modifying code.
 */

import { VersionEvolutionEntry, VersionMetadata } from '../types.ts';

export class VersionManager {
  private static instance: VersionManager;
  private currentVersion = '5.1.0';
  private productName = 'JARVIS 5.1';
  private previousVersion = '4.6.0';

  private evolutionHistory: VersionEvolutionEntry[] = [
    {
      version: '4.0.0',
      releaseDate: '2026-08-15T00:00:00.000Z',
      changelog: [
        'Initialized 11-stage autonomous agentic core loop',
        'Persistent SQLite state storage with zero mock data',
        'Defensive permission boundary with human-in-the-loop authorization',
      ],
      capabilitiesAdded: ['core_loop', 'sqlite_persistence', 'permission_boundary'],
      bugsFixed: [],
      testsPassedCount: 35,
      checkpointRef: 'CHK-CORE-4.0.0',
      isEligible: true,
    },
    {
      version: '4.5.0',
      previousVersion: '4.0.0',
      releaseDate: '2026-09-02T00:00:00.000Z',
      changelog: [
        'Hardened defensive cybersecurity scanner and CWE inspection',
        'Deterministic compound arithmetic and SIP financial simulations',
        'Multi-agent sub-specialist collaboration framework',
      ],
      capabilitiesAdded: ['defensive_cybersecurity', 'finance_simulator', 'sub_agents'],
      bugsFixed: ['Resolved mock data leaks in telemetry', 'Fixed race condition in SQLite prepare statements'],
      testsPassedCount: 65,
      checkpointRef: 'CHK-TASK7-4.5.0',
      isEligible: true,
    },
    {
      version: '4.6.0',
      previousVersion: '4.5.0',
      releaseDate: '2026-09-05T00:00:00.000Z',
      changelog: [
        'Truth-anchored verification contracts and epistemic status tagging',
        'Multilingual natural Hindi and Hinglish execution with standard technical English vocabulary',
        'Non-blocking model execution timeout bounding with local heuristic fallback',
        'Speech synthesis integration with rate, pitch, and voice preference controls',
      ],
      capabilitiesAdded: ['epistemic_tagging', 'multilingual_hindi_hinglish', 'speech_synthesis'],
      bugsFixed: ['Fixed synthetic tool hallucination', 'Corrected voice synthesis pitch persistence'],
      testsPassedCount: 90,
      checkpointRef: 'CHK-TASK8-4.6.0',
      isEligible: true,
    },
    {
      version: '5.1.0',
      previousVersion: '4.6.0',
      releaseDate: '2026-09-08T00:00:00.000Z',
      changelog: [
        'JARVIS 5.1 Real Execution Edition — Sovereign AI Operating System',
        'Direct multi-cloud deployment scaffolding (Vercel, Netlify, Cloud Run, GitHub Pages)',
        'Fullstack, SPA & Android companion generator suite enabled',
        'PDF-1.4 binary buffer generation and sandboxed document workspace',
        'Artifact card system with interactive preview modal and direct download',
        'Plus (+) Popover creation studio and dedicated voice dictation transcript review',
        'Universal ₹0 legitimate resource discovery and master 407-outcome verification audit',
      ],
      capabilitiesAdded: ['real_execution_engine', 'artifact_system', 'document_generator', 'website_generator', 'app_scaffolder', 'workflow_dag', 'outcome_audit'],
      bugsFixed: ['Resolved artifact rendering gap', 'Fixed dictation auto-submit with review banner'],
      testsPassedCount: 126,
      checkpointRef: 'CHK-FINAL-5.1.0',
      isEligible: true,
    },
  ];

  private constructor() {}

  public static getInstance(): VersionManager {
    if (!VersionManager.instance) {
      VersionManager.instance = new VersionManager();
    }
    return VersionManager.instance;
  }

  public getVersionMetadata(): VersionMetadata {
    return {
      currentVersion: this.currentVersion,
      productName: this.productName,
      previousVersion: this.previousVersion,
      underlyingArchitecture: {
        primaryModelProvider: 'Google Gemini (gemini-2.5-flash / gemini-2.0-flash)',
        fallbackProvider: 'Deterministic Local Edge Heuristics',
        localHeuristicActive: true,
        registeredToolsCount: 14,
        registeredCapabilitiesCount: 12,
      },
      evolutionLifecycle: [
        '1. IMPROVEMENT (Identified user/system need)',
        '2. IMPLEMENTATION (Type-safe code changes)',
        '3. AUTOMATED TESTS (Unit & integration suite execution)',
        '4. REGRESSION TESTS (Tasks #1-#8 zero-defect verification)',
        '5. SECURITY CHECK (Permission boundaries & CWE hygiene)',
        '6. BUILD (Vite & server production compilation)',
        '7. RUNTIME CHECK (Live health check & endpoint validation)',
        '8. CHECKPOINT (Persistent verifiable system checkpoint)',
        '9. VERSION ELIGIBLE (Authorized release promotion)',
      ],
      history: [...this.evolutionHistory],
      lastValidatedTimestamp: new Date().toISOString(),
    };
  }

  /**
   * Evaluates whether a proposed version upgrade qualifies under the governance lifecycle.
   */
  public evaluateVersionEligibility(proposal: {
    targetVersion: string;
    improvements: string[];
    automatedTestsPassed: boolean;
    testsPassedCount: number;
    regressionPassed: boolean;
    securityCheckPassed: boolean;
    buildPassed: boolean;
    checkpointRef?: string;
  }): { eligible: boolean; reasons: string[]; entry?: VersionEvolutionEntry } {
    const reasons: string[] = [];

    if (!proposal.targetVersion || !/^\d+\.\d+\.\d+$/.test(proposal.targetVersion)) {
      reasons.push('Invalid semver target version format (must be X.Y.Z).');
    }

    if (!proposal.improvements || proposal.improvements.length === 0) {
      reasons.push('Every version bump requires at least one genuine functional improvement.');
    }

    if (!proposal.automatedTestsPassed) {
      reasons.push('Automated test suite must achieve 100% pass rate.');
    }

    if (proposal.testsPassedCount < 90) {
      reasons.push(`Tests passed count (${proposal.testsPassedCount}) must not regress below baseline (90).`);
    }

    if (!proposal.regressionPassed) {
      reasons.push('Full regression verification for prior tasks #1-#8 is mandatory.');
    }

    if (!proposal.securityCheckPassed) {
      reasons.push('Security audit verification must pass without high-severity vulnerabilities.');
    }

    if (!proposal.buildPassed) {
      reasons.push('Production build compilation must succeed cleanly.');
    }

    if (!proposal.checkpointRef) {
      reasons.push('A valid persistent checkpoint reference is required for rollback safety.');
    }

    const eligible = reasons.length === 0;

    const entry: VersionEvolutionEntry | undefined = eligible
      ? {
          version: proposal.targetVersion,
          previousVersion: this.currentVersion,
          releaseDate: new Date().toISOString(),
          changelog: proposal.improvements,
          capabilitiesAdded: proposal.improvements,
          bugsFixed: [],
          testsPassedCount: proposal.testsPassedCount,
          checkpointRef: proposal.checkpointRef || 'CHK-PENDING',
          isEligible: true,
        }
      : undefined;

    return { eligible, reasons, entry };
  }

  /**
   * Promotes the system version after satisfying all eligibility gates.
   */
  public applyVersionPromotion(entry: VersionEvolutionEntry): boolean {
    if (!entry.isEligible) {
      return false;
    }
    this.previousVersion = this.currentVersion;
    this.currentVersion = entry.version;
    this.productName = `JARVIS ${entry.version.split('.').slice(0, 2).join('.')}`;
    this.evolutionHistory.push(entry);
    return true;
  }
}

export const versionManager = VersionManager.getInstance();
