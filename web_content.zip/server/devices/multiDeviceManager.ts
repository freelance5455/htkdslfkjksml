/**
 * JARVIS Multi-Device Pairing & Sync Protocol
 * Manages connected devices (Desktop, Mobile, Tablet) and handles cross-device session migration.
 */

export interface PairedDevice {
  id: string;
  name: string;
  type: 'desktop_browser' | 'android_companion' | 'tablet' | 'terminal';
  ipAddress?: string;
  lastHeartbeat: string;
  status: 'ONLINE' | 'STANDBY' | 'DISCONNECTED';
}

export class MultiDeviceManager {
  private devices: Map<string, PairedDevice> = new Map();

  constructor() {
    // Current primary web terminal device
    this.devices.set('dev_web_host', {
      id: 'dev_web_host',
      name: 'Primary AI Studio Web Console',
      type: 'desktop_browser',
      lastHeartbeat: new Date().toISOString(),
      status: 'ONLINE',
    });
  }

  public getDevices(): PairedDevice[] {
    return Array.from(this.devices.values());
  }

  public registerDevice(device: Omit<PairedDevice, 'lastHeartbeat'>): PairedDevice {
    const full: PairedDevice = {
      ...device,
      lastHeartbeat: new Date().toISOString(),
    };
    this.devices.set(device.id, full);
    return full;
  }

  public updateHeartbeat(deviceId: string): boolean {
    const dev = this.devices.get(deviceId);
    if (dev) {
      dev.lastHeartbeat = new Date().toISOString();
      dev.status = 'ONLINE';
      return true;
    }
    return false;
  }
}

export const multiDeviceManager = new MultiDeviceManager();
