import fs from 'fs';
import path from 'path';

export interface StoredConversation {
  id: string;
  type?: 'direct' | 'group';
  name?: string | null;
  photo_url?: string | null;
  creator_id?: string | null;
  admin_ids?: string[];
  memberIds: string[];
  createdAt: string;
  updatedAt: string;
  auto_delete_chat_duration?: 'off' | '5m';
  auto_delete_chat_started_at?: string | null;
  wallpaper?: string | null;
  cleared_at_by_user?: Record<string, string>;
  deleted_by_users?: string[];
}

export interface StoredMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  message_type: 'text' | 'image' | 'video' | 'audio' | 'voice' | 'file' | 'system';
  media_url?: string | null;
  created_at: string;
  updated_at: string;
  deleted_at?: string | null;
  read_at?: string | null;
  delivered_at?: string | null;
  viewed_at?: string | null;
  expires_at?: string | null;
  reply_to_id?: string | null;
  is_view_once?: boolean;
  is_edited?: boolean;
  file_name?: string | null;
  file_size?: number | null;
  mime_type?: string | null;
  reactions: { user_id: string; reaction: string; created_at?: string }[];
  deleted_for_users: string[];
  starred_for_users: string[];
}

export interface StoredCall {
  id: string;
  caller_id: string;
  receiver_id: string;
  call_type: 'voice' | 'video';
  status: 'connected' | 'missed' | 'rejected' | 'failed' | 'cancelled';
  started_at: string;
  ended_at?: string | null;
  duration_seconds: number;
  created_at: string;
  deleted_for_users: string[];
}

export interface StoredStatusStory {
  id: string;
  user_id: string;
  media_type: 'image' | 'video' | 'text';
  content?: string | null;
  media_url?: string | null;
  background_color?: string | null;
  caption?: string | null;
  created_at: string;
  expires_at: string;
  privacy: 'friends' | 'selected' | 'nobody';
  selected_friends?: string[];
  views: { user_id: string; viewed_at: string }[];
}

interface NexaDataStore {
  conversations: StoredConversation[];
  messages: StoredMessage[];
  calls: StoredCall[];
  statuses: StoredStatusStory[];
}

const DATA_FILE = path.join(process.cwd(), 'data', 'nexa_store.json');

function loadStore(): NexaDataStore {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      const initial: NexaDataStore = { conversations: [], messages: [], calls: [], statuses: [] };
      fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
      fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2), 'utf8');
      return initial;
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      conversations: Array.isArray(parsed.conversations) ? parsed.conversations : [],
      messages: Array.isArray(parsed.messages) ? parsed.messages : [],
      calls: Array.isArray(parsed.calls) ? parsed.calls : [],
      statuses: Array.isArray(parsed.statuses) ? parsed.statuses : [],
    };
  } catch (err) {
    console.error('Failed to read data store, resetting:', err);
    return { conversations: [], messages: [], calls: [], statuses: [] };
  }
}

function saveStore(store: NexaDataStore) {
  try {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to save data store:', err);
  }
}

let storeMemory: NexaDataStore = loadStore();

export const ChatStore = {
  getConversation(id: string): StoredConversation | undefined {
    return storeMemory.conversations.find((c) => c.id === id);
  },

  getConversationBetween(userA: string, userB: string): StoredConversation | undefined {
    return storeMemory.conversations.find(
      (c) => c.type !== 'group' && c.memberIds.includes(userA) && c.memberIds.includes(userB)
    );
  },

  getConversationsForUser(userId: string): StoredConversation[] {
    return storeMemory.conversations.filter((c) => {
      if (!c.memberIds.includes(userId)) return false;
      // If deleted by user and no newer message exists, hide from list
      if (c.deleted_by_users && c.deleted_by_users.includes(userId)) {
        const lastMsg = this.getLastMessage(c.id, userId);
        if (!lastMsg) return false;
      }
      return true;
    });
  },

  upsertConversation(conv: StoredConversation): StoredConversation {
    const idx = storeMemory.conversations.findIndex((c) => c.id === conv.id);
    if (idx >= 0) {
      storeMemory.conversations[idx] = {
        ...storeMemory.conversations[idx],
        ...conv,
        updatedAt: new Date().toISOString(),
      };
    } else {
      storeMemory.conversations.push(conv);
    }
    saveStore(storeMemory);
    return conv;
  },

  updateConversation(id: string, updates: Partial<StoredConversation>): StoredConversation | null {
    const conv = storeMemory.conversations.find((c) => c.id === id);
    if (!conv) return null;
    Object.assign(conv, updates, { updatedAt: new Date().toISOString() });
    saveStore(storeMemory);
    return conv;
  },

  clearChatForUser(conversationId: string, userId: string): boolean {
    const conv = storeMemory.conversations.find((c) => c.id === conversationId);
    if (!conv) return false;
    if (!conv.cleared_at_by_user) conv.cleared_at_by_user = {};
    conv.cleared_at_by_user[userId] = new Date().toISOString();
    saveStore(storeMemory);
    return true;
  },

  deleteChatForUser(conversationId: string, userId: string): boolean {
    const conv = storeMemory.conversations.find((c) => c.id === conversationId);
    if (!conv) return false;
    if (!conv.cleared_at_by_user) conv.cleared_at_by_user = {};
    conv.cleared_at_by_user[userId] = new Date().toISOString();
    if (!conv.deleted_by_users) conv.deleted_by_users = [];
    if (!conv.deleted_by_users.includes(userId)) {
      conv.deleted_by_users.push(userId);
    }
    saveStore(storeMemory);
    return true;
  },

  getMessages(conversationId: string, userId: string): StoredMessage[] {
    const conv = this.getConversation(conversationId);
    const now = Date.now();
    const nowIso = new Date(now).toISOString();

    // Check Auto-Delete Chat (5 minutes)
    if (
      conv &&
      conv.auto_delete_chat_duration === '5m' &&
      conv.auto_delete_chat_started_at
    ) {
      const started = new Date(conv.auto_delete_chat_started_at).getTime();
      if (now - started >= 5 * 60 * 1000) {
        // Clear all messages in this conversation
        storeMemory.messages = storeMemory.messages.filter((m) => m.conversation_id !== conversationId);
        // Reset timer so next messages have another 5m or user resets
        conv.auto_delete_chat_started_at = nowIso;
        saveStore(storeMemory);
        return [];
      }
    }

    const userClearedAt = conv?.cleared_at_by_user?.[userId];
    const userClearedTime = userClearedAt ? new Date(userClearedAt).getTime() : 0;

    return storeMemory.messages
      .filter((m) => {
        if (m.conversation_id !== conversationId) return false;
        // Filter out if created before or at user's cleared timestamp
        if (userClearedTime > 0 && new Date(m.created_at).getTime() <= userClearedTime) {
          return false;
        }
        // Filter out if user deleted for me
        if (m.deleted_for_users && m.deleted_for_users.includes(userId)) return false;
        // Filter out expired disappearing messages
        if (m.expires_at && m.expires_at <= nowIso) return false;
        return true;
      })
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  },

  getLastMessage(conversationId: string, userId: string): StoredMessage | null {
    const msgs = this.getMessages(conversationId, userId);
    return msgs.length > 0 ? msgs[msgs.length - 1] : null;
  },

  getUnreadCount(conversationId: string, userId: string): number {
    const msgs = this.getMessages(conversationId, userId);
    return msgs.filter((m) => m.sender_id !== userId && !m.read_at).length;
  },

  addMessage(msg: StoredMessage): StoredMessage {
    storeMemory.messages.push(msg);
    // Update conversation updatedAt
    const conv = storeMemory.conversations.find((c) => c.id === msg.conversation_id);
    if (conv) {
      conv.updatedAt = msg.created_at;
      // If deleted by any member, restore for them now that a new message arrived
      if (conv.deleted_by_users && conv.deleted_by_users.length > 0) {
        conv.deleted_by_users = [];
      }
      // If auto-delete chat is active and not started yet, start the timer
      if (conv.auto_delete_chat_duration === '5m' && !conv.auto_delete_chat_started_at) {
        conv.auto_delete_chat_started_at = msg.created_at;
      }
    }
    saveStore(storeMemory);
    return msg;
  },

  markMessagesDelivered(conversationId: string, recipientUserId: string): void {
    const now = new Date().toISOString();
    let updated = false;
    for (const msg of storeMemory.messages) {
      if (msg.conversation_id === conversationId && msg.sender_id !== recipientUserId && !msg.delivered_at) {
        msg.delivered_at = now;
        updated = true;
      }
    }
    if (updated) saveStore(storeMemory);
  },

  markMessageDelivered(messageId: string): void {
    const now = new Date().toISOString();
    const msg = storeMemory.messages.find((m) => m.id === messageId);
    if (msg && !msg.delivered_at) {
      msg.delivered_at = now;
      saveStore(storeMemory);
    }
  },

  updateMessage(
    messageId: string,
    updates: Partial<StoredMessage>
  ): StoredMessage | null {
    const msg = storeMemory.messages.find((m) => m.id === messageId);
    if (!msg) return null;
    Object.assign(msg, updates);
    saveStore(storeMemory);
    return msg;
  },

  deleteMessageForUser(messageId: string, userId: string): boolean {
    const msg = storeMemory.messages.find((m) => m.id === messageId);
    if (!msg) return false;
    if (!msg.deleted_for_users) msg.deleted_for_users = [];
    if (!msg.deleted_for_users.includes(userId)) {
      msg.deleted_for_users.push(userId);
    }
    saveStore(storeMemory);
    return true;
  },

  deleteMessageForEveryone(messageId: string, senderId: string): boolean {
    const msg = storeMemory.messages.find((m) => m.id === messageId);
    if (!msg || msg.sender_id !== senderId) return false;
    msg.deleted_at = new Date().toISOString();
    msg.content = 'This message was deleted';
    msg.media_url = null;
    saveStore(storeMemory);
    return true;
  },

  clearMessagesForEveryone(conversationId: string): boolean {
    const initialCount = storeMemory.messages.length;
    storeMemory.messages = storeMemory.messages.filter((m) => m.conversation_id !== conversationId);
    saveStore(storeMemory);
    return storeMemory.messages.length < initialCount;
  },

  addReaction(messageId: string, userId: string, reaction: string): boolean {
    const msg = storeMemory.messages.find((m) => m.id === messageId);
    if (!msg) return false;
    if (!msg.reactions) msg.reactions = [];
    msg.reactions = msg.reactions.filter((r) => r.user_id !== userId);
    msg.reactions.push({ user_id: userId, reaction, created_at: new Date().toISOString() });
    saveStore(storeMemory);
    return true;
  },

  removeReaction(messageId: string, userId: string): boolean {
    const msg = storeMemory.messages.find((m) => m.id === messageId);
    if (!msg || !msg.reactions) return false;
    msg.reactions = msg.reactions.filter((r) => r.user_id !== userId);
    saveStore(storeMemory);
    return true;
  },

  markMessagesRead(conversationId: string, readerUserId: string): void {
    const now = new Date().toISOString();
    let updated = false;
    for (const msg of storeMemory.messages) {
      if (msg.conversation_id === conversationId && msg.sender_id !== readerUserId && !msg.read_at) {
        msg.read_at = now;
        updated = true;
      }
    }
    if (updated) saveStore(storeMemory);
  },

  // Calls
  addCall(call: StoredCall): StoredCall {
    storeMemory.calls.push(call);
    saveStore(storeMemory);
    return call;
  },

  updateCall(callId: string, updates: Partial<StoredCall>): StoredCall | null {
    const call = storeMemory.calls.find((c) => c.id === callId);
    if (!call) return null;
    Object.assign(call, updates);
    saveStore(storeMemory);
    return call;
  },

  getCallsForUser(userId: string): StoredCall[] {
    return storeMemory.calls
      .filter((c) => {
        if (c.caller_id !== userId && c.receiver_id !== userId) return false;
        if (c.deleted_for_users && c.deleted_for_users.includes(userId)) return false;
        return true;
      })
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  deleteCallForUser(callId: string, userId: string): boolean {
    const call = storeMemory.calls.find((c) => c.id === callId);
    if (!call) return false;
    if (!call.deleted_for_users) call.deleted_for_users = [];
    if (!call.deleted_for_users.includes(userId)) {
      call.deleted_for_users.push(userId);
    }
    saveStore(storeMemory);
    return true;
  },

  clearAllCallsForUser(userId: string): void {
    for (const call of storeMemory.calls) {
      if (call.caller_id === userId || call.receiver_id === userId) {
        if (!call.deleted_for_users) call.deleted_for_users = [];
        if (!call.deleted_for_users.includes(userId)) {
          call.deleted_for_users.push(userId);
        }
      }
    }
    saveStore(storeMemory);
  },

  // Status / Stories
  addStatusStory(story: StoredStatusStory): StoredStatusStory {
    storeMemory.statuses.push(story);
    saveStore(storeMemory);
    return story;
  },

  getActiveStatuses(friendUserIds: string[], currentUserId: string): StoredStatusStory[] {
    const nowIso = new Date().toISOString();
    // Keep active within 24h
    return storeMemory.statuses.filter((s) => {
      if (s.expires_at <= nowIso) return false;
      // If it's my status
      if (s.user_id === currentUserId) return true;
      // If it's a friend's status
      if (!friendUserIds.includes(s.user_id)) return false;
      if (s.privacy === 'nobody') return false;
      if (s.privacy === 'selected') {
        return s.selected_friends?.includes(currentUserId);
      }
      return true;
    }).sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  },

  recordStatusView(statusId: string, viewerUserId: string): boolean {
    const story = storeMemory.statuses.find((s) => s.id === statusId);
    if (!story) return false;
    if (!story.views) story.views = [];
    if (!story.views.some((v) => v.user_id === viewerUserId)) {
      story.views.push({ user_id: viewerUserId, viewed_at: new Date().toISOString() });
      saveStore(storeMemory);
      return true;
    }
    return false;
  },

  deleteStatusStory(statusId: string, userId: string): boolean {
    const idx = storeMemory.statuses.findIndex((s) => s.id === statusId && s.user_id === userId);
    if (idx >= 0) {
      storeMemory.statuses.splice(idx, 1);
      saveStore(storeMemory);
      return true;
    }
    return false;
  },
};
