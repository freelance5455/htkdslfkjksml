import http from 'node:http';
import { createApp } from './app.js';
import { MemoryStore } from './store-memory.js';
import { AnthropicProvider, LocalProvider } from './ai-gateway.js';

const env = process.env, prod = env.NODE_ENV === 'production';
const jwtSecret = env.JWT_SECRET || '';
if (prod && jwtSecret.length < 32) { console.error('JWT_SECRET (>=32 chars) is required in production'); process.exit(1); }
if (prod && !env.DATABASE_URL) { console.error('DATABASE_URL is required in production (in-memory storage would lose data)'); process.exit(1); }

let store;
if (env.DATABASE_URL) { const { PgStore } = await import('./store-pg.js'); store = await PgStore.connect(env.DATABASE_URL); }
else { console.warn('WARNING: no DATABASE_URL — using in-memory store (development only)'); store = new MemoryStore(); }

const aiProvider = env.ANTHROPIC_API_KEY ? new AnthropicProvider({ apiKey: env.ANTHROPIC_API_KEY, model: env.AI_MODEL || 'claude-sonnet-4-6' }) : new LocalProvider();
// Development mailer prints the OTP to the console. In production configure a real mailer (SMTP/provider) instead.
const mailer = prod ? null : { mode: 'console', async send(email, code) { console.log(`[dev OTP] ${email}: ${code}`); } };

const handler = createApp({
  store, aiProvider, mailer,
  config: { jwtSecret: jwtSecret || 'dev-only-secret-change-me-dev-only-secret', corsOrigins: (env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean), aiDailyLimit: Number(env.AI_DAILY_LIMIT_PER_ORG) || 200 }
});
http.createServer(handler).listen(Number(env.PORT) || 8080, () => console.log('Contractor Pro server listening on', env.PORT || 8080));
