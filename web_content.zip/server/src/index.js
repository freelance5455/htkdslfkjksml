import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import http from 'node:http';
import {Server} from 'socket.io';
import {pool} from './db.js';
import {auth,adminOnly,driverOnly,passengerOnly,signToken} from './auth.js';
dotenv.config();
if(!process.env.JWT_SECRET) throw new Error('Configure JWT_SECRET no .env');
const app=express(), server=http.createServer(app);
const io=new Server(server,{cors:{origin:true,credentials:true}});
app.use(cors()); app.use(express.json({limit:'1mb'}));
app.use(express.static(new URL('../public',import.meta.url)));
const km=(a,b,c,d)=>{const R=6371,rad=x=>x*Math.PI/180,dl=rad(c-a),dn=rad(d-b);const q=Math.sin(dl/2)**2+Math.cos(rad(a))*Math.cos(rad(c))*Math.sin(dn/2)**2;return 2*R*Math.asin(Math.sqrt(q));};
const roomUser=id=>`user:${id}`;
io.use(async(socket,next)=>{
 try{
  const token=socket.handshake.auth?.token;
  const decoded=await import('jsonwebtoken').then(m=>m.default.verify(token,process.env.JWT_SECRET));
  socket.user={id:decoded.sub,role:decoded.role}; next();
 }catch{next(new Error('Não autorizado'));}
});
io.on('connection',socket=>{socket.join(roomUser(socket.user.id));});
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'WBS MOBI API',version:'0.2.0'}));

app.post('/api/auth/register',async(req,res)=>{
 try{
  const {name,email,phone,cpf,password,role,cnhNumber,vehicleType,vehicleModel,vehiclePlate}=req.body;
  if(!name||!email||!phone||!cpf||!password||password.length<8||!['passenger','driver'].includes(role))
   return res.status(400).json({error:'Confira os campos obrigatórios. Senha mínima de 8 caracteres.'});
  if(role==='driver'&&(!cnhNumber||!['car','motorcycle'].includes(vehicleType)||!vehicleModel||!vehiclePlate))
   return res.status(400).json({error:'Preencha CNH e dados do veículo.'});
  const hash=await bcrypt.hash(password,12),status=role==='driver'?'pending':'active',client=await pool.connect();
  try{
   await client.query('BEGIN');
   const q=await client.query(`INSERT INTO users(name,email,phone,cpf,password_hash,role,status)
    VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,name,email,role,status`,
    [name,email.toLowerCase(),phone,cpf,hash,role,status]);
   const user=q.rows[0];
   if(role==='driver')await client.query(`INSERT INTO driver_profiles(user_id,cnh_number,vehicle_type,vehicle_model,vehicle_plate)
    VALUES($1,$2,$3,$4,$5)`,[user.id,cnhNumber,vehicleType,vehicleModel,vehiclePlate.toUpperCase()]);
   await client.query('COMMIT');res.status(201).json({user,message:role==='driver'?'Cadastro enviado para análise.':'Conta criada.'});
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
 }catch(e){if(e.code==='23505')return res.status(409).json({error:'E-mail ou CPF já cadastrado.'});console.error(e);res.status(500).json({error:'Não foi possível criar a conta.'});}
});
app.post('/api/auth/login',async(req,res)=>{
 const q=await pool.query('SELECT * FROM users WHERE email=$1',[String(req.body.email||'').toLowerCase()]),u=q.rows[0];
 if(!u||!(await bcrypt.compare(req.body.password||'',u.password_hash)))return res.status(401).json({error:'E-mail ou senha inválidos.'});
 if(['blocked','rejected','pending'].includes(u.status))return res.status(403).json({error:u.status==='pending'?'Cadastro aguardando aprovação.':'Conta sem acesso.'});
 res.json({token:signToken(u),user:{id:u.id,name:u.name,email:u.email,role:u.role,status:u.status}});
});
app.get('/api/me',auth,async(req,res)=>{const q=await pool.query('SELECT id,name,email,phone,role,status FROM users WHERE id=$1',[req.auth.sub]);res.json(q.rows[0]||null);});

app.get('/api/admin/drivers',auth,adminOnly,async(_req,res)=>{
 const q=await pool.query(`SELECT u.id,u.name,u.email,u.phone,u.status,u.created_at,d.vehicle_type,d.vehicle_model,d.vehicle_plate,d.is_online
 FROM users u JOIN driver_profiles d ON d.user_id=u.id ORDER BY u.created_at DESC`);res.json(q.rows);
});
app.patch('/api/admin/drivers/:id/:decision',auth,adminOnly,async(req,res)=>{
 const status=req.params.decision==='approve'?'approved':req.params.decision==='reject'?'rejected':null;
 if(!status)return res.status(400).json({error:'Ação inválida.'});
 const q=await pool.query('UPDATE users SET status=$1 WHERE id=$2 AND role=$3 RETURNING id,name,status',[status,req.params.id,'driver']);
 if(!q.rowCount)return res.status(404).json({error:'Motorista não encontrado.'});res.json(q.rows[0]);
});
app.get('/api/admin/summary',auth,adminOnly,async(_req,res)=>{
 const q=await pool.query(`SELECT (SELECT COUNT(*) FROM users WHERE role='passenger') passengers,
 (SELECT COUNT(*) FROM users WHERE role='driver') drivers,
 (SELECT COUNT(*) FROM users WHERE role='driver' AND status='pending') pending_drivers,
 (SELECT COUNT(*) FROM rides) rides,
 (SELECT COALESCE(SUM(commission_cents),0) FROM rides WHERE status='completed') commission_cents`);res.json(q.rows[0]);
});

app.post('/api/driver/online',auth,driverOnly,async(req,res)=>{
 const q=await pool.query(`UPDATE driver_profiles d SET is_online=true FROM users u
 WHERE d.user_id=$1 AND u.id=d.user_id AND u.status='approved' RETURNING d.is_online`,[req.auth.sub]);
 if(!q.rowCount)return res.status(403).json({error:'Motorista não aprovado ou perfil inexistente.'});
 res.json({online:true});
});
app.post('/api/driver/offline',auth,driverOnly,async(req,res)=>{
 await pool.query('UPDATE driver_profiles SET is_online=false WHERE user_id=$1',[req.auth.sub]);res.json({online:false});
});
app.post('/api/driver/location',auth,driverOnly,async(req,res)=>{
 const {lat,lng}=req.body;
 if(!Number.isFinite(lat)||!Number.isFinite(lng)||lat < -90||lat>90||lng < -180||lng>180)return res.status(400).json({error:'Coordenadas inválidas.'});
 const q=await pool.query(`UPDATE driver_profiles SET lat=$2,lng=$3,location_updated_at=NOW()
 WHERE user_id=$1 RETURNING user_id`,[req.auth.sub,lat,lng]);
 if(!q.rowCount)return res.status(404).json({error:'Perfil de motorista não encontrado.'});
 res.json({updated:true});
});

app.post('/api/rides',auth,passengerOnly,async(req,res)=>{
 const {origin,destination,fareCents,vehicleType,originLat,originLng}=req.body;
 const fare=Math.round(Number(fareCents));
 if(!origin||!destination||!Number.isInteger(fare)||fare<=0||fare>10000000||!['car','motorcycle'].includes(vehicleType))
  return res.status(400).json({error:'Informe origem, destino, categoria e valor válido em centavos.'});
 if(originLat!=null&&(!Number.isFinite(originLat)||originLat < -90||originLat>90))return res.status(400).json({error:'Latitude inválida.'});
 if(originLng!=null&&(!Number.isFinite(originLng)||originLng < -180||originLng>180))return res.status(400).json({error:'Longitude inválida.'});
 const commission=Math.round(fare*.15),driverAmount=fare-commission;
 const q=await pool.query(`INSERT INTO rides(passenger_id,origin,destination,origin_lat,origin_lng,vehicle_type,fare_cents,commission_cents,driver_amount_cents)
 VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
 [req.auth.sub,origin,destination,originLat??null,originLng??null,vehicleType,fare,commission,driverAmount]);
 const ride=q.rows[0];
 if(originLat!=null&&originLng!=null){
  const radius=Number(process.env.DISPATCH_RADIUS_KM||8),limit=Number(process.env.DISPATCH_DRIVER_LIMIT||5);
  const ds=await pool.query(`SELECT d.user_id,d.lat,d.lng FROM driver_profiles d JOIN users u ON u.id=d.user_id
   WHERE d.is_online=true AND d.vehicle_type=$1 AND u.status='approved'
   AND d.lat IS NOT NULL AND d.lng IS NOT NULL AND d.location_updated_at>NOW()-INTERVAL '2 minutes'`,
   [vehicleType]);
  const nearest=ds.rows.map(d=>({...d,distance:km(originLat,originLng,d.lat,d.lng)})).filter(d=>d.distance<=radius).sort((a,b)=>a.distance-b.distance).slice(0,limit);
  for(const d of nearest)io.to(roomUser(d.user_id)).emit('ride:offer',{rideId:ride.id,origin,destination,vehicleType,fareCents:fare,driverAmountCents:driverAmount,distanceKm:Number(d.distance.toFixed(2))});
  await pool.query("UPDATE rides SET status='dispatching' WHERE id=$1",[ride.id]);
  io.to(roomUser(req.auth.sub)).emit('ride:status',{rideId:ride.id,status:'dispatching',offersSent:nearest.length});
 }
 res.status(201).json({...ride,dispatchStatus:originLat!=null&&originLng!=null?'dispatching':'waiting_for_location'});
});
app.get('/api/driver/rides/available',auth,driverOnly,async(req,res)=>{
 const q=await pool.query(`SELECT r.id,r.origin,r.destination,r.vehicle_type,r.fare_cents,r.driver_amount_cents,r.created_at
 FROM rides r JOIN driver_profiles d ON d.user_id=$1 JOIN users u ON u.id=$1
 WHERE r.status IN ('requested','dispatching') AND r.vehicle_type=d.vehicle_type AND d.is_online=true AND u.status='approved'
 ORDER BY r.created_at DESC`,[req.auth.sub]);res.json(q.rows);
});
app.post('/api/rides/:id/accept',auth,driverOnly,async(req,res)=>{
 const approved=await pool.query(`SELECT u.status,d.is_online FROM users u JOIN driver_profiles d ON d.user_id=u.id WHERE u.id=$1`,[req.auth.sub]);
 if(approved.rows[0]?.status!=='approved'||!approved.rows[0]?.is_online)return res.status(403).json({error:'Motorista precisa estar aprovado e online.'});
 const client=await pool.connect();
 try{
  await client.query('BEGIN');
  const q=await client.query(`UPDATE rides r SET driver_id=$1,status='accepted'
   FROM driver_profiles d WHERE r.id=$2 AND r.status IN ('requested','dispatching')
   AND d.user_id=$1 AND d.vehicle_type=r.vehicle_type RETURNING r.*`,[req.auth.sub,req.params.id]);
  if(!q.rowCount){await client.query('ROLLBACK');return res.status(409).json({error:'Corrida indisponível ou categoria incompatível.'});}
  await client.query('COMMIT');const ride=q.rows[0];
  io.to(roomUser(ride.passenger_id)).emit('ride:status',{rideId:ride.id,status:'accepted',driverId:req.auth.sub});
  res.json(ride);
 }catch(e){await client.query('ROLLBACK');console.error(e);res.status(500).json({error:'Falha ao aceitar corrida.'});}finally{client.release();}
});
app.post('/api/rides/:id/complete',auth,driverOnly,async(req,res)=>{
 const q=await pool.query(`UPDATE rides SET status='completed',completed_at=NOW()
 WHERE id=$1 AND driver_id=$2 AND status='accepted'
 RETURNING id,fare_cents,commission_cents,driver_amount_cents`,[req.params.id,req.auth.sub]);
 if(!q.rowCount)return res.status(404).json({error:'Corrida não encontrada.'});
 const r=q.rows[0];io.emit('ride:status',{rideId:r.id,status:'completed'});
 res.json(r);
});
app.get('/api/rides/:id',auth,async(req,res)=>{
 const q=await pool.query('SELECT * FROM rides WHERE id=$1',[req.params.id]),r=q.rows[0];
 if(!r)return res.status(404).json({error:'Corrida não encontrada.'});
 if(req.auth.role!=='admin'&&r.passenger_id!==req.auth.sub&&r.driver_id!==req.auth.sub)return res.status(403).json({error:'Sem acesso.'});
 res.json(r);
});
const port=process.env.PORT||3000;server.listen(port,()=>console.log(`WBS MOBI v2 em http://localhost:${port}`));
