import pg from "pg";

const { Pool } = pg;

// Single shared connection pool. DATABASE_URL comes from env only —
// never hardcode credentials here.
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export async function query<T = any>(text: string, params: any[] = []): Promise<T[]> {
  const result = await pool.query(text, params);
  return result.rows as T[];
}
