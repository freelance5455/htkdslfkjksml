import { randomUUID } from 'node:crypto';
import { GENESIS, chainHash } from './audit.js';
import { resolveChange } from './sync.js';

export class MemoryStore {
  kind = 'memory';
  users = new Map(); orgs = new Map(); members = new Map(); refresh = new Map(); otps = new Map();
  snaps = []; recs = new Map(); subs = new Map(); usage = new Map(); audits = []; cursor = 0;

  async createOrgWithOwner({ orgName, email, passwordHash, emailVerified = false }) {
    const org = { id: randomUUID(), name: orgName, createdAt: new Date().toISOString() };
    const user = { id: randomUUID(), email, passwordHash, emailVerified };
    this.orgs.set(org.id, org); this.users.set(user.id, user);
    this.members.set(user.id, { orgId: org.id, userId: user.id, role: 'owner' });
    this.subs.set(org.id, { orgId: org.id, licenseId: 'LIC-' + randomUUID().slice(0, 8).toUpperCase(), plan: 'free', status: 'active', expiresAt: null });
    return { org, user };
  }
  async createUser({ email, passwordHash }) { const user = { id: randomUUID(), email, passwordHash, emailVerified: false }; this.users.set(user.id, user); return user; }
  async getUserByEmail(email) { return [...this.users.values()].find(u => u.email === email) || null; }
  async getUserById(id) { return this.users.get(id) || null; }
  async setPassword(userId, passwordHash) { const u = this.users.get(userId); if (u) u.passwordHash = passwordHash; }
  async markVerified(userId) { const u = this.users.get(userId); if (u) u.emailVerified = true; }
  async getMembership(userId) { return this.members.get(userId) || null; }
  async listMembers(orgId) {
    return [...this.members.values()].filter(m => m.orgId === orgId).map(m => ({ id: m.userId, email: this.users.get(m.userId).email, role: m.role }));
  }
  async addMember({ orgId, userId, role }) { this.members.set(userId, { orgId, userId, role }); }
  async setRole(orgId, userId, role) { const m = this.members.get(userId); if (m && m.orgId === orgId) { m.role = role; return true; } return false; }

  async saveRefresh(hash, userId, expiresAt) { this.refresh.set(hash, { userId, expiresAt }); }
  async takeRefresh(hash) { const r = this.refresh.get(hash); this.refresh.delete(hash); return r && r.expiresAt > Date.now() ? r : null; }
  async revokeRefresh(userId) { for (const [k, v] of this.refresh) if (v.userId === userId) this.refresh.delete(k); }

  async setOtp(email, codeHash, expiresAt) { this.otps.set(email, { codeHash, expiresAt, attempts: 0 }); }
  async getOtp(email) { return this.otps.get(email) || null; }
  async bumpOtp(email) { const o = this.otps.get(email); if (o) o.attempts++; }
  async deleteOtp(email) { this.otps.delete(email); }

  async pushSnapshot(orgId, deviceId, data) { this.cursor++; this.snaps.push({ cursor: this.cursor, orgId, deviceId, data }); return this.cursor; }
  async latestSnapshot(orgId) { for (let i = this.snaps.length - 1; i >= 0; i--) if (this.snaps[i].orgId === orgId) return this.snaps[i]; return null; }

  async applyChange(orgId, ch) {
    const key = `${orgId}|${ch.module}|${ch.id}`, ex = this.recs.get(key) || null;
    const r = resolveChange(ex, ch);
    if (r.status === 'applied') this.recs.set(key, { module: ch.module, id: ch.id, data: ch.data ?? null, version: r.version, updatedAt: ch.updatedAt, deleted: !!ch.deleted });
    return { ...r, server: this.recs.get(key) || null };
  }
  async listRecords(orgId, modules) {
    return [...this.recs.entries()].filter(([k, v]) => k.startsWith(orgId + '|') && modules.includes(v.module)).map(([, v]) => v);
  }

  async getSubscription(orgId) { return this.subs.get(orgId) || null; }

  cryptoInvoices = new Map();
  async createCryptoInvoice({ orgId, plan, priceUsd, currency, amountCrypto, address, createdBy }) {
    const inv = { id: randomUUID(), orgId, plan, priceUsd, currency, amountCrypto, address, status: 'pending', createdBy, createdAt: new Date().toISOString(), confirmedAt: null, confirmedBy: null };
    this.cryptoInvoices.set(inv.id, inv);
    return inv;
  }
  async listCryptoInvoices(orgId) { return [...this.cryptoInvoices.values()].filter(i => i.orgId === orgId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }
  async markCryptoInvoicePaid(orgId, id, confirmedBy) {
    const inv = this.cryptoInvoices.get(id);
    if (!inv || inv.orgId !== orgId) return false;
    inv.status = 'paid'; inv.confirmedAt = new Date().toISOString(); inv.confirmedBy = confirmedBy;
    return true;
  }
  async findSubscriptionByLicense(licenseId) { return [...this.subs.values()].find(s => s.licenseId === licenseId) || null; }
  async incAiUsage(orgId, day) { const k = orgId + '|' + day, n = (this.usage.get(k) || 0) + 1; this.usage.set(k, n); return n; }

  async appendAudit(orgId, e) {
    const prev = [...this.audits].reverse().find(a => a.orgId === orgId);
    const prevHash = prev ? prev.hash : GENESIS;
    const row = { seq: this.audits.length + 1, orgId, ...e, prevHash };
    row.hash = chainHash(prevHash, row);
    this.audits.push(row); return row;
  }
  async listAudit(orgId, limit = 100) { return this.audits.filter(a => a.orgId === orgId).slice(-limit).reverse(); }
  async allAudit(orgId) { return this.audits.filter(a => a.orgId === orgId); }
}
