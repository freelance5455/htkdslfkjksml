// Conflict resolution for offline edits. Pure function, shared by every store.
// existing: {version, updatedAt, deleted, data} | null ; ch: {data, updatedAt, baseVersion, deleted}
export function resolveChange(existing, ch) {
  const at = Date.parse(ch.updatedAt);
  if (!Number.isFinite(at)) return { status: 'invalid' };
  if (!existing) return { status: 'applied', version: 1, resolved: 'created' };
  if (Number(ch.baseVersion) === existing.version) return { status: 'applied', version: existing.version + 1, resolved: 'fast-forward' };
  // concurrent edit: last-writer-wins by timestamp; the loser is reported back to the client
  if (at > Date.parse(existing.updatedAt)) return { status: 'applied', version: existing.version + 1, resolved: 'client-wins' };
  return { status: 'conflict', version: existing.version, resolved: 'server-wins' };
}
