import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import pg from 'pg';
if (!process.env.DATABASE_URL) { console.error('DATABASE_URL is required'); process.exit(1); }
const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'sql');
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort()) { await pool.query(fs.readFileSync(path.join(dir, f), 'utf8')); console.log('applied', f); }
await pool.end();
