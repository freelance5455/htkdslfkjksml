// Generic abstraction so real dropshipping suppliers can be plugged in
// later without touching routes/controllers. Only MockSupplierProvider
// (see ./MockSupplierProvider.ts) is implemented today.

export interface SupplierProduct {
  id: string;
  name: string;
  category: string;
  imageUrl: string;
  supplierCostCents: number;
  suggestedPriceCents: number;
  isDemo: boolean;
}

export interface SupplierVariant {
  id: string;
  productId: string;
  name: string;
  priceCents: number;
}

export interface ShippingOption {
  id: string;
  label: string;
  etaDays: number;
  costCents: number;
}

export interface SupplierProvider {
  name: string;
  searchProducts(query: string, category?: string): Promise<SupplierProduct[]>;
  getProduct(id: string): Promise<SupplierProduct | null>;
  getVariants(productId: string): Promise<SupplierVariant[]>;
  getInventory(productId: string): Promise<number>;
  getShippingOptions(productId: string, destinationCountry: string): Promise<ShippingOption[]>;
  createOrder(payload: {
    productId: string;
    variantId?: string;
    quantity: number;
    destinationAddress: Record<string, string>;
  }): Promise<{ supplierOrderId: string; status: string }>;
}
