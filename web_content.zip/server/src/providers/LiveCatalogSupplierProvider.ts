import type {
  SupplierProduct,
  SupplierProvider,
  SupplierVariant,
  ShippingOption,
} from "./SupplierProvider.js";

// Real product-discovery data from DummyJSON (https://dummyjson.com), a free
// public product API — used here so Product Finder shows genuine names,
// images and prices instead of invented ones, with no key required.
//
// This is a discovery/inspiration source, NOT a connected dropshipping
// fulfillment supplier: createOrder() below correctly refuses to place a
// real order, because there is no live supplier account to fulfill one.
// Swap this class for a real supplier's SDK (once you have a contract with
// one) and nothing else in the app needs to change.
const BASE_URL = "https://dummyjson.com";

const CATEGORY_MAP: Record<string, string> = {
  electronics: "smartphones",
  fashion: "womens-dresses",
  beauty: "beauty",
  home: "home-decoration",
  fitness: "sports-accessories",
  accessories: "sunglasses",
};

interface DummyJsonProduct {
  id: number;
  title: string;
  category: string;
  price: number;
  thumbnail: string;
}

function toSupplierProduct(p: DummyJsonProduct): SupplierProduct {
  // DummyJSON returns a retail-style price; we treat that as the suggested
  // retail price and derive an estimated supplier cost at a common 45%
  // wholesale ratio so Product Finder can show a real, if approximate, margin.
  const suggestedPriceCents = Math.round(p.price * 100);
  const supplierCostCents = Math.round(suggestedPriceCents * 0.45);
  return {
    id: String(p.id),
    name: p.title,
    category: p.category,
    imageUrl: p.thumbnail,
    supplierCostCents,
    suggestedPriceCents,
    isDemo: false,
  };
}

export class LiveCatalogSupplierProvider implements SupplierProvider {
  name = "dummyjson";

  async searchProducts(query: string, category?: string): Promise<SupplierProduct[]> {
    const mappedCategory = category && category !== "trending" ? CATEGORY_MAP[category] ?? category : undefined;
    const url = query.trim()
      ? `${BASE_URL}/products/search?q=${encodeURIComponent(query)}&limit=24`
      : mappedCategory
      ? `${BASE_URL}/products/category/${encodeURIComponent(mappedCategory)}?limit=24`
      : `${BASE_URL}/products?limit=24`;

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Supplier catalog request failed (${res.status}).`);
    const body = (await res.json()) as { products: DummyJsonProduct[] };
    return body.products.map(toSupplierProduct);
  }

  async getProduct(id: string): Promise<SupplierProduct | null> {
    const res = await fetch(`${BASE_URL}/products/${encodeURIComponent(id)}`);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`Supplier product request failed (${res.status}).`);
    const product = (await res.json()) as DummyJsonProduct;
    return toSupplierProduct(product);
  }

  async getVariants(productId: string): Promise<SupplierVariant[]> {
    // The public catalog doesn't expose real variants — report the single
    // real listing rather than inventing sizes/colors that don't exist.
    return [{ id: `${productId}-default`, productId, name: "Standard", priceCents: 0 }];
  }

  async getInventory(_productId: string): Promise<number> {
    // Not exposed by the public catalog; report unknown rather than a made-up number.
    return -1;
  }

  async getShippingOptions(_productId: string, _destinationCountry: string): Promise<ShippingOption[]> {
    // No live supplier is connected, so there are no real shipping options yet.
    return [];
  }

  async createOrder(): Promise<{ supplierOrderId: string; status: string }> {
    throw new Error(
      "No live fulfillment supplier is connected. Connect a real SupplierProvider (e.g. a dropshipping API you have an account with) before creating supplier orders."
    );
  }
}
