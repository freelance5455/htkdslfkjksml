import { sha256 } from './crypto.js';
export const GENESIS = '0'.repeat(64);
// Each audit row commits to the previous row's hash -> any edit/deletion breaks the chain.
export function chainHash(prev, e) {
  return sha256([prev, e.at, e.userId ?? '', e.role ?? '', e.action, e.module ?? '', e.recordId ?? '', e.details ?? '', e.ip ?? ''].join('|'));
}
export function verifyChain(rows) {
  let prev = GENESIS;
  for (const r of rows) {
    if (r.prevHash !== prev || chainHash(prev, r) !== r.hash) return { ok: false, brokenAt: r.seq };
    prev = r.hash;
  }
  return { ok: true };
}
