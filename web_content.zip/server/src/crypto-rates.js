// Fetches a live BTC/USD rate from a public exchange-rate API.
// USDT is treated as pegged ~1:1 to USD and needs no live lookup.
// The fetch implementation is injectable so tests never need real network access.
export async function getBtcUsdRate(fetchImpl = fetch) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 5000);
  try {
    const res = await fetchImpl('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd', { signal: ctrl.signal });
    if (!res.ok) throw new Error('rate provider returned ' + res.status);
    const j = await res.json();
    const rate = j && j.bitcoin && j.bitcoin.usd;
    if (!rate || typeof rate !== 'number' || rate <= 0) throw new Error('rate provider returned no usable price');
    return rate;
  } finally {
    clearTimeout(timer);
  }
}
