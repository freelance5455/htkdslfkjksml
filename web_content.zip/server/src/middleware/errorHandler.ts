import type { Request, Response, NextFunction } from "express";

// Central error handler: never leak stack traces to clients.
export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  console.error(err);
  const status = err.status ?? 500;
  const message =
    status === 500 ? "Something went wrong. Please try again." : err.message ?? "Request failed.";
  res.status(status).json({ success: false, error: message });
}

export function notFound(_req: Request, res: Response) {
  res.status(404).json({ success: false, error: "Not found." });
}
