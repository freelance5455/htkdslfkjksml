// Role-based access control. Single source of truth for the server AND the AI context filter.
export const ROLES = ['owner', 'admin', 'manager', 'accountant', 'supervisor', 'worker', 'client'];

const R = 'read', W = 'write', D = 'delete';
const ALL = [R, W, D];

// module -> role -> allowed actions
export const MATRIX = {
  projects:      { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R, W], worker: [R], client: [R] },
  clients:       { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [], worker: [], client: [] },
  leads:         { owner: ALL, admin: ALL, manager: ALL, accountant: [], supervisor: [], worker: [], client: [] },
  estimates:     { owner: ALL, admin: ALL, manager: ALL, accountant: [R, W], supervisor: [], worker: [], client: [R] },
  contracts:     { owner: ALL, admin: ALL, manager: [R, W], accountant: [R], supervisor: [], worker: [], client: [R] },
  changeOrders:  { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R, W], worker: [], client: [R] },
  invoices:      { owner: ALL, admin: ALL, manager: [R], accountant: ALL, supervisor: [], worker: [], client: [R] },
  finance:       { owner: ALL, admin: ALL, manager: [R], accountant: ALL, supervisor: [], worker: [], client: [] },
  accounts:      { owner: ALL, admin: ALL, manager: [], accountant: ALL, supervisor: [], worker: [], client: [] },
  team:          { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R], worker: [], client: [] },
  timeEntries:   { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R, W], worker: [R], client: [] },
  materials:     { owner: ALL, admin: ALL, manager: ALL, accountant: [R, W], supervisor: [R, W], worker: [R], client: [] },
  inventory:     { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R, W], worker: [R, W], client: [] },
  equipment:     { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R, W], worker: [R], client: [] },
  suppliers:     { owner: ALL, admin: ALL, manager: ALL, accountant: [R, W], supervisor: [R], worker: [], client: [] },
  schedule:      { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R, W], worker: [R], client: [R] },
  dailyLogs:     { owner: ALL, admin: ALL, manager: ALL, accountant: [], supervisor: [R, W], worker: [R, W], client: [R] },
  documents:     { owner: ALL, admin: ALL, manager: ALL, accountant: [R, W], supervisor: [R, W], worker: [], client: [R] },
  notifications: { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [R], worker: [R], client: [] },
  smartDrawings: { owner: ALL, admin: ALL, manager: ALL, accountant: [R], supervisor: [], worker: [], client: [] },
  // system resources
  users:   { owner: ALL, admin: [R, W], manager: [], accountant: [], supervisor: [], worker: [], client: [] },
  audit:   { owner: [R], admin: [R], manager: [], accountant: [R], supervisor: [], worker: [], client: [] },
  billing: { owner: ALL, admin: [], manager: [], accountant: [R], supervisor: [], worker: [], client: [] },
  ai:      { owner: [R], admin: [R], manager: [R], accountant: [R], supervisor: [R], worker: [], client: [] }
};

export const DATA_MODULES = Object.keys(MATRIX).filter(k => !['users', 'audit', 'billing', 'ai'].includes(k));

export function can(role, action, resource) {
  const row = MATRIX[resource];
  if (!row || !ROLES.includes(role)) return false;
  return (row[role] || []).includes(action);
}

export function readableModules(role) {
  return DATA_MODULES.filter(m => can(role, R, m));
}

// Only these roles may overwrite a whole workspace snapshot.
export function canPushSnapshot(role) { return ['owner', 'admin', 'manager'].includes(role); }

// Remove everything the role may not read from a workspace snapshot.
export function filterSnapshot(snapshot, role) {
  const out = {};
  if (!snapshot || typeof snapshot !== 'object') return out;
  const readable = new Set(readableModules(role));
  for (const [k, v] of Object.entries(snapshot)) {
    if (DATA_MODULES.includes(k)) { if (readable.has(k)) out[k] = v; continue; }
    if (['auth', 'license', 'services', 'security', 'sync', 'audit', 'teamAccess', 'portalAccess', 'smart'].includes(k)) continue;
    out[k] = v; // settings such as lang/currency/country
  }
  return out;
}

// A role may only assign roles strictly below its own power (owner is never assignable).
const POWER = { owner: 6, admin: 5, manager: 4, accountant: 3, supervisor: 2, worker: 1, client: 1 };
export function canAssignRole(actorRole, targetRole) {
  if (targetRole === 'owner') return false;
  if (!ROLES.includes(targetRole) || !can(actorRole, W, 'users')) return false;
  return POWER[actorRole] > POWER[targetRole];
}
