import jwt from 'jsonwebtoken';
export function signToken(user){return jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:'12h'});}
export function auth(req,res,next){
 const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
 if(!token)return res.status(401).json({error:'Faça login.'});
 try{req.auth=jwt.verify(token,process.env.JWT_SECRET);next();}
 catch{return res.status(401).json({error:'Sessão inválida ou expirada.'});}
}
export const adminOnly=(req,res,next)=>req.auth?.role==='admin'?next():res.status(403).json({error:'Acesso exclusivo do administrador.'});
export const driverOnly=(req,res,next)=>req.auth?.role==='driver'?next():res.status(403).json({error:'Acesso exclusivo do motorista.'});
export const passengerOnly=(req,res,next)=>req.auth?.role==='passenger'?next():res.status(403).json({error:'Acesso exclusivo do passageiro.'});
