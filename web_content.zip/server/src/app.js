import { hashPassword, verifyPassword, signJwt, verifyJwt, randomToken, sha256 } from './crypto.js';
import { can, canAssignRole, canPushSnapshot, filterSnapshot, readableModules, DATA_MODULES, ROLES } from './rbac.js';
import { verifyChain } from './audit.js';
import { askAi, LocalProvider } from './ai-gateway.js';
import { getBtcUsdRate } from './crypto-rates.js';

export const VERSION = '1.0.0';
const ACCESS_TTL = 15 * 60, REFRESH_TTL = 30 * 24 * 3600, OTP_TTL = 10 * 60;
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m) => new HttpError(400, m), deny = (m = 'Forbidden') => new HttpError(403, m);

export function createApp({ store, config, aiProvider = new LocalProvider(), mailer = null }) {
  const secret = config.jwtSecret;
  const hits = new Map();
  function limit(key, max, windowMs) {
    const now = Date.now(), arr = (hits.get(key) || []).filter(t => now - t < windowMs);
    if (arr.length >= max) throw new HttpError(429, 'Too many attempts, try again later');
    arr.push(now); hits.set(key, arr);
  }

  const json = (res, status, body, extra = {}) => {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extra });
    res.end(JSON.stringify(body));
  };
  function cors(req) {
    const o = req.headers.origin, list = config.corsOrigins || [];
    const h = { vary: 'Origin', 'access-control-allow-methods': 'GET,POST,PATCH,OPTIONS', 'access-control-allow-headers': 'authorization,content-type', 'access-control-max-age': '600' };
    if (!list.length) h['access-control-allow-origin'] = '*';
    else if (o && list.includes(o)) h['access-control-allow-origin'] = o;
    return h;
  }
  async function body(req, max = 10 * 1024 * 1024) {
    let size = 0; const chunks = [];
    for await (const c of req) { size += c.length; if (size > max) throw new HttpError(413, 'Payload too large'); chunks.push(c); }
    if (!size) return {};
    try { const j = JSON.parse(Buffer.concat(chunks).toString('utf8')); return j && typeof j === 'object' ? j : {}; } catch { throw bad('Invalid JSON'); }
  }

  async function issue(user, member) {
    const refreshToken = randomToken(48);
    await store.saveRefresh(sha256(refreshToken), user.id, Date.now() + REFRESH_TTL * 1000);
    const accessToken = signJwt({ sub: user.id }, secret, ACCESS_TTL);
    return { accessToken, refreshToken, expiresIn: ACCESS_TTL, user: { id: user.id, email: user.email, emailVerified: !!user.emailVerified, workspaceId: member.orgId, role: member.role } };
  }
  async function auth(req) {
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    const claims = m && verifyJwt(m[1], secret);
    if (!claims) throw new HttpError(401, 'Authentication required');
    const user = await store.getUserById(claims.sub), member = user && await store.getMembership(user.id);
    if (!member) throw new HttpError(401, 'Authentication required');
    return { user, orgId: member.orgId, role: member.role, ip: req.socket?.remoteAddress || '' };
  }
  const log = (ctx, action, module = '', recordId = '', details = '') =>
    store.appendAudit(ctx.orgId, { at: new Date().toISOString(), userId: ctx.user.id, role: ctx.role, action, module, recordId, details: String(details).slice(0, 300), ip: ctx.ip });
  const need = (ctx, action, resource) => { if (!can(ctx.role, action, resource)) throw deny(); };
  const normEmail = (e) => String(e || '').trim().toLowerCase();
  const checkPassword = (p) => { if (typeof p !== 'string' || p.length < 10 || p.length > 200) throw bad('Password must be 10-200 characters'); };

  const routes = {
    'GET /health': async () => [200, { ok: true, version: VERSION, store: store.kind }],

    'POST /api/auth/register': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email);
      if (!EMAIL.test(email)) throw bad('Invalid email'); checkPassword(b.password);
      limit('reg|' + req.socket?.remoteAddress, 10, 3600e3);
      if (await store.getUserByEmail(email)) throw new HttpError(409, 'Account already exists');
      const { user, org } = await store.createOrgWithOwner({ orgName: String(b.orgName || email.split('@')[0]).slice(0, 120), email, passwordHash: await hashPassword(b.password) });
      const member = await store.getMembership(user.id);
      const ctx = { user, orgId: org.id, role: 'owner', ip: req.socket?.remoteAddress || '' }; await log(ctx, 'register', 'users', user.id);
      return [201, await issue(user, member)];
    },
    'POST /api/auth/login': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email);
      limit('login|' + email, 8, 15 * 60e3); limit('loginip|' + req.socket?.remoteAddress, 40, 15 * 60e3);
      const user = await store.getUserByEmail(email);
      // verify against a dummy hash when user is unknown so timing does not reveal accounts
      const ok = await verifyPassword(String(b.password || ''), user?.passwordHash || 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAA');
      if (!user || !ok) throw new HttpError(401, 'Invalid email or password');
      const member = await store.getMembership(user.id); if (!member) throw new HttpError(401, 'Invalid email or password');
      await log({ user, orgId: member.orgId, role: member.role, ip: req.socket?.remoteAddress || '' }, 'login', 'users', user.id);
      return [200, await issue(user, member)];
    },
    'POST /api/auth/request-otp': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email);
      if (!EMAIL.test(email)) throw bad('Invalid email');
      limit('otp|' + email, 5, 3600e3);
      if (!mailer) throw new HttpError(501, 'Email delivery is not configured on this server');
      const code = String(Math.floor(100000 + Math.random() * 900000));
      await store.setOtp(email, sha256(email + ':' + code), Date.now() + OTP_TTL * 1000);
      await mailer.send(email, code);
      return [200, { ok: true, deliveryMode: mailer.mode || 'provider' }];
    },
    'POST /api/auth/verify-otp': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email), code = String(b.code || '').trim();
      limit('otpv|' + email, 10, 3600e3);
      const o = await store.getOtp(email);
      if (!o || o.expiresAt < Date.now() || o.attempts >= 5) throw new HttpError(401, 'Invalid or expired code');
      if (sha256(email + ':' + code) !== o.codeHash) { await store.bumpOtp(email); throw new HttpError(401, 'Invalid or expired code'); }
      await store.deleteOtp(email);
      let user = await store.getUserByEmail(email), member;
      if (!user) { ({ user } = await store.createOrgWithOwner({ orgName: email.split('@')[0], email, passwordHash: null, emailVerified: true })); }
      else await store.markVerified(user.id);
      user.emailVerified = true; member = await store.getMembership(user.id);
      await log({ user, orgId: member.orgId, role: member.role, ip: req.socket?.remoteAddress || '' }, 'login-otp', 'users', user.id);
      return [200, await issue(user, member)];
    },
    'POST /api/auth/refresh': async (req) => {
      const b = await body(req, 1e5), r = await store.takeRefresh(sha256(String(b.refreshToken || '')));   // single use (rotation)
      if (!r) throw new HttpError(401, 'Invalid refresh token');
      const user = await store.getUserById(r.userId), member = user && await store.getMembership(user.id);
      if (!member) throw new HttpError(401, 'Invalid refresh token');
      return [200, await issue(user, member)];
    },
    'POST /api/auth/logout': async (req) => { const c = await auth(req); await store.revokeRefresh(c.user.id); await log(c, 'logout', 'users', c.user.id); return [200, { ok: true }]; },
    'GET /api/auth/me': async (req) => { const c = await auth(req); return [200, { user: { id: c.user.id, email: c.user.email, emailVerified: !!c.user.emailVerified, workspaceId: c.orgId, role: c.role, permissions: { readable: readableModules(c.role) } } }]; },
    'POST /api/account/password': async (req) => {
      const c = await auth(req), b = await body(req, 1e5); checkPassword(b.password);
      await store.setPassword(c.user.id, await hashPassword(b.password)); await store.revokeRefresh(c.user.id);
      await log(c, 'password-change', 'users', c.user.id); return [200, { ok: true }];
    },

    'GET /api/users': async (req) => { const c = await auth(req); need(c, 'read', 'users'); return [200, { users: await store.listMembers(c.orgId) }]; },
    'POST /api/users': async (req) => {
      const c = await auth(req), b = await body(req, 1e5), email = normEmail(b.email);
      if (!EMAIL.test(email)) throw bad('Invalid email'); checkPassword(b.password);
      if (!canAssignRole(c.role, b.role)) throw deny('You cannot assign this role');
      if (await store.getUserByEmail(email)) throw new HttpError(409, 'Account already exists');
      const user = await store.createUser({ email, passwordHash: await hashPassword(b.password) });
      await store.addMember({ orgId: c.orgId, userId: user.id, role: b.role });
      await log(c, 'user-create', 'users', user.id, `role=${b.role}`); return [201, { user: { id: user.id, email, role: b.role } }];
    },
    'PATCH /api/users/:id': async (req, p) => {
      const c = await auth(req), b = await body(req, 1e5);
      if (p.id === c.user.id) throw deny('You cannot change your own role');
      const target = await store.getMembership(p.id);
      if (!target || target.orgId !== c.orgId) throw new HttpError(404, 'User not found');
      if (!canAssignRole(c.role, b.role) || !canAssignRole(c.role, target.role)) throw deny('You cannot assign this role');
      await store.setRole(c.orgId, p.id, b.role); await log(c, 'role-change', 'users', p.id, `${target.role}->${b.role}`); return [200, { ok: true }];
    },
    'GET /api/audit': async (req, _p, url) => {
      const c = await auth(req); need(c, 'read', 'audit');
      const n = Math.min(500, Math.max(1, Number(url.searchParams.get('limit')) || 100));
      return [200, { entries: await store.listAudit(c.orgId, n), chain: verifyChain(await store.allAudit(c.orgId)) }];
    },

    'POST /api/sync/push': async (req) => {
      const c = await auth(req), b = await body(req);
      if (b.workspaceId !== c.orgId) throw deny('Wrong workspace');
      if (!canPushSnapshot(c.role)) throw deny('Your role cannot upload a full backup');
      if (!b.snapshot || typeof b.snapshot !== 'object' || Array.isArray(b.snapshot)) throw bad('snapshot is required');
      const cursor = await store.pushSnapshot(c.orgId, String(b.deviceId || ''), b.snapshot);
      await log(c, 'sync-push', 'sync', String(cursor)); return [200, { ok: true, cursor }];
    },
    'GET /api/sync/pull': async (req, _p, url) => {
      const c = await auth(req);
      if (url.searchParams.get('workspaceId') !== c.orgId) throw deny('Wrong workspace');
      const s = await store.latestSnapshot(c.orgId);
      return [200, { latest: s ? filterSnapshot(s.data, c.role) : null, cursor: s ? s.cursor : 0 }];
    },
    'POST /api/sync/changes': async (req) => {
      const c = await auth(req), b = await body(req);
      if (!Array.isArray(b.changes) || b.changes.length > 500) throw bad('changes must be an array of at most 500 items');
      const applied = [], conflicts = [], rejected = [];
      for (const ch of b.changes) {
        if (!ch || !DATA_MODULES.includes(ch.module) || typeof ch.id !== 'string' || !ch.id || ch.id.length > 120) { rejected.push({ id: ch?.id, reason: 'invalid' }); continue; }
        if (!can(c.role, ch.deleted ? 'delete' : 'write', ch.module)) { rejected.push({ module: ch.module, id: ch.id, reason: 'forbidden' }); continue; }
        const r = await store.applyChange(c.orgId, ch);
        if (r.status === 'invalid') rejected.push({ module: ch.module, id: ch.id, reason: 'invalid' });
        else if (r.status === 'conflict') conflicts.push({ module: ch.module, id: ch.id, resolved: r.resolved, server: r.server });
        else { applied.push({ module: ch.module, id: ch.id, version: r.version, resolved: r.resolved }); await log(c, ch.deleted ? 'delete' : 'sync-write', ch.module, ch.id); }
      }
      return [200, { applied, conflicts, rejected }];
    },
    'GET /api/sync/records': async (req) => { const c = await auth(req); return [200, { records: await store.listRecords(c.orgId, readableModules(c.role)) }]; },

    'POST /api/license/validate': async (req) => {
      const c = await auth(req), b = await body(req, 1e5);
      const sub = await store.getSubscription(c.orgId);
      const valid = !!sub && sub.licenseId === String(b.licenseId || '') && sub.status === 'active' && (!sub.expiresAt || new Date(sub.expiresAt) > new Date());
      return [200, { valid, plan: valid ? sub.plan : null, expiresAt: valid ? sub.expiresAt : null }];
    },
    'POST /api/billing/create-checkout': async (req) => {
      const c = await auth(req); need(c, 'write', 'billing');
      throw new HttpError(501, 'No payment provider is configured on this server');
    },
    'POST /api/billing/crypto-invoice': async (req) => {
      const c = await auth(req); need(c, 'write', 'billing');
      const b = await body(req, 1e4);
      const plan = String(b.plan || ''), currency = String(b.currency || '').toLowerCase();
      const priceUsd = (config.planPricesUsd || {})[plan];
      if (!priceUsd) throw bad('Unknown plan');
      if (!['btc', 'usdt'].includes(currency)) throw bad('currency must be "btc" or "usdt"');
      const address = (config.cryptoAddresses || {})[currency];
      if (!address) throw new HttpError(501, 'No ' + currency.toUpperCase() + ' receiving address is configured on this server');
      let amountCrypto;
      if (currency === 'usdt') amountCrypto = priceUsd; // stablecoin, ~1:1 with USD
      else {
        let rate;
        try { rate = await getBtcUsdRate(); }
        catch { throw new HttpError(503, 'Live exchange rate is temporarily unavailable, try again shortly'); }
        amountCrypto = Math.round((priceUsd / rate) * 1e8) / 1e8;
      }
      const inv = await store.createCryptoInvoice({ orgId: c.orgId, plan, priceUsd, currency, amountCrypto, address, createdBy: c.user.id });
      await log(c, 'crypto-invoice-create', 'billing', inv.id, `${currency} ${amountCrypto}`);
      return [201, inv];
    },
    'GET /api/billing/crypto-invoices': async (req) => {
      const c = await auth(req); need(c, 'read', 'billing');
      return [200, { invoices: await store.listCryptoInvoices(c.orgId) }];
    },
    'POST /api/billing/crypto-invoice/:id/confirm': async (req, p) => {
      const c = await auth(req); need(c, 'write', 'billing');
      const ok = await store.markCryptoInvoicePaid(c.orgId, p.id, c.user.id);
      if (!ok) throw new HttpError(404, 'Invoice not found');
      await log(c, 'crypto-invoice-confirm', 'billing', p.id);
      return [200, { ok: true }];
    },

    'POST /api/ai/copilot': async (req) => {
      const c = await auth(req); need(c, 'read', 'ai');
      const b = await body(req, 2e5), q = String(b.question || '').trim();
      if (!q) throw bad('question is required'); if (q.length > 2000) throw bad('question is too long');
      const day = new Date().toISOString().slice(0, 10);
      const calls = await store.incAiUsage(c.orgId, day);
      if (calls > (config.aiDailyLimit ?? 200)) throw new HttpError(429, 'Daily AI limit reached');
      const snap = await store.latestSnapshot(c.orgId);                   // data comes from the server, never from the client
      let out;
      try { out = await askAi({ provider: aiProvider, question: q, snapshot: snap ? snap.data : {}, role: c.role }); }
      catch { throw new HttpError(502, 'AI service is temporarily unavailable'); }
      await log(c, 'ai-ask', 'ai', '', `provider=${out.provider} modules=${out.modules.length}`);
      return [200, out];
    }
  };

  const table = Object.entries(routes).map(([k, h]) => {
    const [method, path] = k.split(' ');
    return { method, h, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') };
  });

  return async function handle(req, res) {
    const ch = cors(req);
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204, ch); return res.end(); }
      const url = new URL(req.url, 'http://x');
      for (const r of table) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(url.pathname); if (!m) continue;
        const [status, payload] = await r.h(req, m.groups || {}, url);
        return json(res, status, payload, ch);
      }
      json(res, 404, { error: 'Not found' }, ch);
    } catch (e) {
      if (e instanceof HttpError) return json(res, e.status, { error: e.message }, ch);
      console.error('Unhandled error:', e);
      json(res, 500, { error: 'Internal server error' }, ch);
    }
  };
}
