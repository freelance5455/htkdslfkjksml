const express=require('express');
const cors=require('cors');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const {Pool}=require('pg');
const http=require('http');
const {WebSocketServer}=require('ws');

const app=express();
const server=http.createServer(app);
const wss=new WebSocketServer({server});
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const JWT_SECRET=process.env.JWT_SECRET||'change-me';
app.use(cors({origin:process.env.CORS_ORIGIN||'*'}));
app.use(express.json());

function auth(req,res,next){
  try{
    const h=req.headers.authorization||'';
    if(!h.startsWith('Bearer ')) return res.status(401).json({error:'ورود لازم است'});
    req.user=jwt.verify(h.slice(7),JWT_SECRET); next();
  }catch(e){res.status(401).json({error:'نشست نامعتبر است'});}
}
function roles(...allowed){return (req,res,next)=>allowed.includes(req.user.role)?next():res.status(403).json({error:'دسترسی مجاز نیست'});}
function broadcast(data){
  const s=JSON.stringify(data);
  wss.clients.forEach(c=>{if(c.readyState===1)c.send(s);});
}

app.get('/api/health',(req,res)=>res.json({ok:true,app:'آشپزخانه نمکدون',version:'network-full-v1'}));

app.post('/api/login',async(req,res)=>{
  const {username,password}=req.body||{};
  const r=await pool.query('SELECT * FROM users WHERE username=$1',[username]);
  if(!r.rows[0]||!(await bcrypt.compare(password,r.rows[0].password_hash)))
    return res.status(401).json({error:'نام کاربری یا رمز عبور اشتباه است'});
  const u=r.rows[0];
  const token=jwt.sign({id:u.id,name:u.name,role:u.role},JWT_SECRET,{expiresIn:'12h'});
  res.json({token,user:{id:u.id,name:u.name,role:u.role}});
});

app.get('/api/menu',auth,async(req,res)=>{
  const r=await pool.query('SELECT id,name,category,price,cost,active FROM menu_items WHERE active=true ORDER BY name');
  res.json(r.rows);
});

app.post('/api/menu',auth,roles('manager'),async(req,res)=>{
  const {name,category,price,cost}=req.body;
  const r=await pool.query(
    'INSERT INTO menu_items(name,category,price,cost) VALUES($1,$2,$3,$4) RETURNING *',
    [name,category||'',price||0,cost||0]);
  res.status(201).json(r.rows[0]);
});

app.get('/api/orders',auth,async(req,res)=>{
  const r=await pool.query(`
    SELECT o.*, COALESCE(json_agg(json_build_object(
      'id',oi.id,'menu_item_id',oi.menu_item_id,'item_name',oi.item_name,
      'quantity',oi.quantity,'unit_price',oi.unit_price
    ) ORDER BY oi.id) FILTER (WHERE oi.id IS NOT NULL),'[]') items
    FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id
    GROUP BY o.id ORDER BY o.created_at DESC LIMIT 200`);
  res.json(r.rows);
});

app.post('/api/orders',auth,roles('manager','cashier'),async(req,res)=>{
  const {order_type,table_name,customer_name,phone,note,payment_method,items=[]}=req.body;
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    let total=0;
    for(const x of items) total += Number(x.quantity||1)*Number(x.unit_price||0);
    const o=await client.query(`
      INSERT INTO orders(order_type,table_name,customer_name,phone,note,payment_method,total,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [order_type,table_name||'',customer_name||'',phone||'',note||'',payment_method||null,total,req.user.id]);
    for(const x of items){
      await client.query(`
        INSERT INTO order_items(order_id,menu_item_id,item_name,quantity,unit_price,unit_cost)
        VALUES($1,$2,$3,$4,$5,$6)`,
        [o.rows[0].id,x.menu_item_id||null,x.item_name,x.quantity||1,x.unit_price||0,x.unit_cost||0]);
    }
    await client.query('COMMIT');
    broadcast({type:'order.created',order_id:o.rows[0].id});
    res.status(201).json(o.rows[0]);
  }catch(e){await client.query('ROLLBACK');res.status(500).json({error:e.message});}
  finally{client.release();}
});

app.patch('/api/orders/:id/status',auth,roles('manager','cashier','kitchen','delivery'),async(req,res)=>{
  const {status}=req.body;
  const allowed=['جدید','در حال آماده‌سازی','آماده','در مسیر','تحویل شد','لغو شد'];
  if(!allowed.includes(status)) return res.status(400).json({error:'وضعیت نامعتبر'});
  const r=await pool.query('UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 RETURNING *',[status,req.params.id]);
  if(!r.rows[0]) return res.status(404).json({error:'سفارش پیدا نشد'});
  broadcast({type:'order.updated',order:r.rows[0]});
  res.json(r.rows[0]);
});

app.get('/api/reports/today',auth,roles('manager'),async(req,res)=>{
  const sales=await pool.query(`SELECT COALESCE(SUM(total),0) total,COUNT(*) orders FROM orders WHERE created_at::date=CURRENT_DATE AND status<>'لغو شد'`);
  const expenses=await pool.query(`SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE created_at::date=CURRENT_DATE`);
  res.json({sales:sales.rows[0],expenses:expenses.rows[0]});
});

wss.on('connection',ws=>ws.send(JSON.stringify({type:'connected',app:'آشپزخانه نمکدون'})));
server.listen(process.env.PORT||3000,()=>console.log('Namakdoon Network API started'));
