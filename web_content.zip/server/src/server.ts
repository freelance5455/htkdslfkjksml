import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";

import { authRouter } from "./routes/auth.js";
import { productsRouter } from "./routes/products.js";
import { aiRouter } from "./routes/ai.js";
import { storeRouter } from "./routes/store.js";
import { ordersRouter } from "./routes/orders.js";
import { customersRouter } from "./routes/customers.js";
import { analyticsRouter } from "./routes/analytics.js";
import { supplierRouter } from "./routes/supplier.js";
import { publicStoreRouter } from "./routes/publicStore.js";
import { errorHandler, notFound } from "./middleware/errorHandler.js";

const app = express();

app.use(helmet());
app.use(
  cors({
    origin: process.env.APP_URL ?? "http://localhost:5173",
    credentials: true,
  })
);
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());

// Generous general limit; auth/AI routes get their own tighter limits below.
const generalLimiter = rateLimit({ windowMs: 60 * 1000, max: 120 });
app.use(generalLimiter);

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, max: 15 });

app.get("/api/health", (_req, res) => res.json({ success: true, data: { status: "ok" } }));

app.use("/api/auth", authLimiter, authRouter);
app.use("/api/products", productsRouter);
app.use("/api/ai", aiLimiter, aiRouter);
app.use("/api/store", storeRouter);
app.use("/api/orders", ordersRouter);
app.use("/api/customers", customersRouter);
app.use("/api/analytics", analyticsRouter);
app.use("/api/supplier", supplierRouter);
app.use("/api/public", publicStoreRouter);

app.use(notFound);
app.use(errorHandler);

const port = Number(process.env.PORT) || 4000;
app.listen(port, () => {
  console.log(`AI Reseller API listening on :${port}`);
});
