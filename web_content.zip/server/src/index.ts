import "dotenv/config";
import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { PrismaClient, Role, PaymentStatus } from "@prisma/client";

const app = express();
const prisma = new PrismaClient();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters.");
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173", credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

type AuthRequest = Request & { user?: { id: string; role: Role } };
const cookieOptions = () => ({
  httpOnly: true, secure: process.env.COOKIE_SECURE === "true",
  sameSite: "lax" as const, path: "/", maxAge: 7 * 24 * 60 * 60 * 1000
});
function auth(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.cookies?.oda_session;
  if (!token) return res.status(401).json({ error: "Authentication required" });
  try {
    const payload = jwt.verify(token, JWT_SECRET!) as { sub: string; role: Role };
    req.user = { id: payload.sub, role: payload.role };
    next();
  } catch { return res.status(401).json({ error: "Session expired; please sign in again" }); }
}
function admin(req: AuthRequest, res: Response, next: NextFunction) {
  if (req.user?.role !== "ADMIN") return res.status(403).json({ error: "Admin access required" });
  next();
}
const asyncRoute = (fn: (req: AuthRequest, res: Response) => Promise<unknown>) =>
  (req: AuthRequest, res: Response, next: NextFunction) => Promise.resolve(fn(req, res)).catch(next);

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "ODA Learning API" }));

app.post("/api/auth/register", asyncRoute(async (req, res) => {
  const data = z.object({
    name: z.string().trim().min(2).max(80),
    email: z.string().trim().email().max(254),
    password: z.string().min(10).max(128),
    language: z.enum(["en", "om"]).default("en")
  }).parse(req.body);
  const email = data.email.toLowerCase();
  if (await prisma.user.findUnique({ where: { email } })) return res.status(409).json({ error: "Email already registered" });
  const user = await prisma.user.create({ data: {
    name: data.name, email, passwordHash: await bcrypt.hash(data.password, 12), preferredLanguage: data.language
  }, select: { id: true, name: true, email: true, role: true, preferredLanguage: true } });
  const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET!, { expiresIn: "7d" });
  res.cookie("oda_session", token, cookieOptions()).status(201).json({ user });
}));

app.post("/api/auth/login", asyncRoute(async (req, res) => {
  const data = z.object({ email: z.string().email(), password: z.string().min(1).max(128) }).parse(req.body);
  const user = await prisma.user.findUnique({ where: { email: data.email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(data.password, user.passwordHash))) return res.status(401).json({ error: "Invalid email or password" });
  const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET!, { expiresIn: "7d" });
  res.cookie("oda_session", token, cookieOptions()).json({ user: { id: user.id, name: user.name, email: user.email, role: user.role, preferredLanguage: user.preferredLanguage } });
}));

app.post("/api/auth/logout", (_req, res) => res.clearCookie("oda_session", { httpOnly: true, sameSite: "lax", secure: process.env.COOKIE_SECURE === "true", path: "/" }).json({ ok: true }));
app.get("/api/auth/me", auth, asyncRoute(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { id: true, name: true, email: true, role: true, preferredLanguage: true, createdAt: true } });
  res.json({ user });
}));

app.get("/api/curriculum", asyncRoute(async (_req, res) => {
  const grades = await prisma.grade.findMany({ orderBy: { number: "asc" }, include: {
    subjects: { orderBy: { nameEn: "asc" }, include: { chapters: { orderBy: { order: "asc" }, include: { lessons: { orderBy: { order: "asc" }, select: { id: true, titleEn: true, titleOm: true, videoUrl: true, pdfUrl: true, order: true } } } } }
  } });
  res.json({ grades });
}));

app.get("/api/lessons/:id", auth, asyncRoute(async (req, res) => {
  const lesson = await prisma.lesson.findUnique({ where: { id: req.params.id }, include: { questions: { select: { id: true, promptEn: true, promptOm: true, options: true, explanationEn: true, explanationOm: true } } } });
  if (!lesson) return res.status(404).json({ error: "Lesson not found" });
  res.json({ lesson });
}));

app.post("/api/progress/:lessonId", auth, asyncRoute(async (req, res) => {
  const data = z.object({ completed: z.boolean() }).parse(req.body);
  const progress = await prisma.lessonProgress.upsert({
    where: { userId_lessonId: { userId: req.user!.id, lessonId: req.params.lessonId } },
    update: { completed: data.completed }, create: { userId: req.user!.id, lessonId: req.params.lessonId, completed: data.completed }
  });
  res.json({ progress });
}));

app.get("/api/student/dashboard", auth, asyncRoute(async (req, res) => {
  const [user, progress, payments] = await Promise.all([
    prisma.user.findUnique({ where: { id: req.user!.id }, select: { id: true, name: true, email: true, preferredLanguage: true } }),
    prisma.lessonProgress.findMany({ where: { userId: req.user!.id }, include: { lesson: { select: { id: true, titleEn: true, titleOm: true } } }, orderBy: { updatedAt: "desc" }, take: 20 }),
    prisma.payment.findMany({ where: { userId: req.user!.id }, select: { id: true, amount: true, currency: true, status: true, createdAt: true }, orderBy: { createdAt: "desc" }, take: 10 })
  ]);
  res.json({ user, progress, payments });
}));

app.post("/api/payments", auth, asyncRoute(async (req, res) => {
  const data = z.object({ amount: z.number().int().positive().max(10000000), reference: z.string().trim().min(3).max(120), note: z.string().max(500).optional() }).parse(req.body);
  const payment = await prisma.payment.create({ data: { userId: req.user!.id, amount: data.amount, reference: data.reference, note: data.note } });
  res.status(201).json({ payment });
}));

app.get("/api/admin/overview", auth, admin, asyncRoute(async (_req, res) => {
  const [students, pendingPayments, lessons, questions] = await Promise.all([
    prisma.user.count({ where: { role: "STUDENT" } }),
    prisma.payment.count({ where: { status: "PENDING" } }),
    prisma.lesson.count(), prisma.question.count()
  ]);
  res.json({ students, pendingPayments, lessons, questions });
}));
app.get("/api/admin/users", auth, admin, asyncRoute(async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const users = await prisma.user.findMany({ where: { role: "STUDENT" }, select: { id: true, name: true, email: true, createdAt: true }, orderBy: { createdAt: "desc" }, skip: (page - 1) * 50, take: 50 });
  res.json({ users, page });
}));
app.get("/api/admin/payments", auth, admin, asyncRoute(async (_req, res) => {
  const payments = await prisma.payment.findMany({ include: { user: { select: { id: true, name: true, email: true } } }, orderBy: { createdAt: "desc" }, take: 200 });
  res.json({ payments });
}));
app.patch("/api/admin/payments/:id", auth, admin, asyncRoute(async (req, res) => {
  const data = z.object({ status: z.enum(["APPROVED", "REJECTED"]), adminNote: z.string().max(500).optional() }).parse(req.body);
  const payment = await prisma.payment.update({ where: { id: req.params.id }, data: { status: data.status as PaymentStatus, adminNote: data.adminNote, reviewedAt: new Date() } });
  res.json({ payment });
}));

app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid input", details: err.issues.map(i => ({ path: i.path.join("."), message: i.message })) });
  // Do not leak stack traces or database details to clients.
  console.error(err);
  return res.status(500).json({ error: "Unexpected server error" });
});
app.listen(PORT, () => console.log(`ODA API listening on port ${PORT}`));
