import { Router } from "express";
import { z } from "zod";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";
import { LiveCatalogSupplierProvider } from "../providers/LiveCatalogSupplierProvider.js";
import { query } from "../database/pool.js";

export const supplierRouter = Router();
supplierRouter.use(requireAuth);

// Real product-discovery data (see LiveCatalogSupplierProvider). Swap this
// for a real fulfillment supplier's SDK once you have a supplier
// account — nothing else in this file needs to change.
const supplier = new LiveCatalogSupplierProvider();

supplierRouter.get("/products", async (req: AuthedRequest, res, next) => {
  try {
    const q = typeof req.query.q === "string" ? req.query.q : "";
    const category = typeof req.query.category === "string" ? req.query.category : undefined;
    const products = await supplier.searchProducts(q, category);
    res.json({ success: true, data: products, provider: supplier.name });
  } catch (err) {
    next(err);
  }
});

const importSchema = z.object({ supplierProductId: z.string() });

// Copies a real catalog product into the user's own product catalog as a
// draft — it does not place a live supplier order (see
// LiveCatalogSupplierProvider.createOrder, which correctly refuses to,
// since no fulfillment supplier is connected).
supplierRouter.post("/import", async (req: AuthedRequest, res, next) => {
  try {
    const parsed = importSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ success: false, error: "Missing product to import." });

    const [store] = await query("SELECT id FROM stores WHERE user_id = $1", [req.userId]);
    if (!store) return res.status(400).json({ success: false, error: "No store found for this account." });

    const product = await supplier.getProduct(parsed.data.supplierProductId);
    if (!product) return res.status(404).json({ success: false, error: "Supplier product not found." });

    const [row] = await query(
      `INSERT INTO products (store_id, name, price_cents, status, tags)
       VALUES ($1,$2,$3,'draft',$4) RETURNING *`,
      [store.id, product.name, product.suggestedPriceCents, ["imported"]]
    );
    res.status(201).json({ success: true, data: row });
  } catch (err) {
    next(err);
  }
});
