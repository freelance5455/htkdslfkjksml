import { Router } from "express";
import { query } from "../database/pool.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";

export const ordersRouter = Router();
ordersRouter.use(requireAuth);

// Returns real orders if any exist; otherwise returns [] and the client
// shows an honest empty state (never fabricated orders).
ordersRouter.get("/", async (req: AuthedRequest, res, next) => {
  try {
    const [store] = await query("SELECT id FROM stores WHERE user_id = $1", [req.userId]);
    if (!store) return res.json({ success: true, data: [] });
    const rows = await query(
      `SELECT o.*, c.name as customer_name FROM orders o
       LEFT JOIN customers c ON c.id = o.customer_id
       WHERE o.store_id = $1 ORDER BY o.created_at DESC LIMIT 100`,
      [store.id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});
