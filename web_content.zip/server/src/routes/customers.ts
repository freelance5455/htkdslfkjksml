import { Router } from "express";
import { query } from "../database/pool.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";

export const customersRouter = Router();
customersRouter.use(requireAuth);

customersRouter.get("/", async (req: AuthedRequest, res, next) => {
  try {
    const [store] = await query("SELECT id FROM stores WHERE user_id = $1", [req.userId]);
    if (!store) return res.json({ success: true, data: [] });
    const rows = await query(
      "SELECT * FROM customers WHERE store_id = $1 ORDER BY created_at DESC LIMIT 200",
      [store.id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});
