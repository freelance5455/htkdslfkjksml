import { Router } from "express";
import { query } from "../database/pool.js";

export const publicStoreRouter = Router();

// GET /api/public/stores/:slug — no auth required. Returns a storefront's
// public info plus its active products only (never drafts/archived), or a
// 404 if the slug doesn't exist. Also logs a real visit for analytics.
publicStoreRouter.get("/stores/:slug", async (req, res, next) => {
  try {
    const [store] = await query(
      "SELECT id, name, slug, tagline, description, currency, logo_url FROM stores WHERE slug = $1",
      [req.params.slug]
    );
    if (!store) return res.status(404).json({ success: false, error: "Store not found." });

    const [theme] = await query("SELECT * FROM store_themes WHERE store_id = $1", [store.id]);
    const products = await query(
      `SELECT id, name, short_description, price_cents, compare_at_price_cents
       FROM products WHERE store_id = $1 AND status = 'active' ORDER BY created_at DESC`,
      [store.id]
    );

    await query("INSERT INTO store_visitors (store_id, path, referrer) VALUES ($1, $2, $3)", [
      store.id,
      `/store/${store.slug}`,
      req.get("referer") ?? null,
    ]);

    res.json({ success: true, data: { store, theme, products } });
  } catch (err) {
    next(err);
  }
});
