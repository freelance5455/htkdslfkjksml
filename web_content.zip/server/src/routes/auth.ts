import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { query } from "../database/pool.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";

export const authRouter = Router();

// GET /api/auth/me — lets the client check for a valid session on load
// (the session cookie is httpOnly, so JS can't read it directly).
authRouter.get("/me", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const [user] = await query("SELECT id, name, email FROM users WHERE id = $1", [req.userId]);
    if (!user) return res.status(401).json({ success: false, error: "Not authenticated." });
    const [store] = await query("SELECT id, name, slug FROM stores WHERE user_id = $1", [req.userId]);
    res.json({ success: true, data: { user, store: store ?? null } });
  } catch (err) {
    next(err);
  }
});

const registerSchema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  password: z.string().min(8).max(200),
  storeName: z.string().min(1).max(120),
});

function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function issueSession(res: any, userId: string) {
  const token = jwt.sign({ userId }, process.env.SESSION_SECRET!, { expiresIn: "7d" });
  res.cookie("session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

// POST /api/auth/register — creates user, store, default theme in one transaction.
authRouter.post("/register", async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ success: false, error: "Please check your details and try again." });
    }
    const { name, email, password, storeName } = parsed.data;

    const existing = await query("SELECT id FROM users WHERE email = $1", [email]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, error: "An account with this email already exists." });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const [user] = await query(
      "INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id",
      [name, email, passwordHash]
    );

    const slugBase = slugify(storeName) || "store";
    let slug = slugBase;
    let suffix = 1;
    while ((await query("SELECT id FROM stores WHERE slug = $1", [slug])).length > 0) {
      slug = `${slugBase}-${++suffix}`;
    }

    const [store] = await query(
      "INSERT INTO stores (user_id, name, slug) VALUES ($1, $2, $3) RETURNING id",
      [user.id, storeName, slug]
    );
    await query("INSERT INTO store_themes (store_id) VALUES ($1)", [store.id]);
    await query("INSERT INTO settings (store_id) VALUES ($1)", [store.id]);

    issueSession(res, user.id);
    res.status(201).json({ success: true, data: { userId: user.id, storeId: store.id, storeSlug: slug } });
  } catch (err) {
    next(err);
  }
});

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });

authRouter.post("/login", async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ success: false, error: "Please enter a valid email and password." });
    }
    const { email, password } = parsed.data;
    const [user] = await query("SELECT id, password_hash FROM users WHERE email = $1", [email]);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ success: false, error: "Incorrect email or password." });
    }
    issueSession(res, user.id);
    res.json({ success: true, data: { userId: user.id } });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/logout", (_req, res) => {
  res.clearCookie("session");
  res.json({ success: true, data: null });
});
