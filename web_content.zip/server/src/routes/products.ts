import { Router } from "express";
import { z } from "zod";
import { query } from "../database/pool.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";

export const productsRouter = Router();
productsRouter.use(requireAuth);

async function storeIdForUser(userId: string) {
  const [store] = await query("SELECT id FROM stores WHERE user_id = $1 LIMIT 1", [userId]);
  return store?.id as string | undefined;
}

productsRouter.get("/", async (req: AuthedRequest, res, next) => {
  try {
    const storeId = await storeIdForUser(req.userId!);
    if (!storeId) return res.json({ success: true, data: [] });
    const rows = await query(
      "SELECT * FROM products WHERE store_id = $1 ORDER BY created_at DESC",
      [storeId]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});

const productSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(5000).optional(),
  priceCents: z.number().int().min(0),
  compareAtPriceCents: z.number().int().min(0).optional(),
  sku: z.string().max(80).optional(),
  inventory: z.number().int().min(0).default(0),
  status: z.enum(["draft", "active", "archived"]).default("draft"),
  tags: z.array(z.string()).default([]),
});

productsRouter.post("/", async (req: AuthedRequest, res, next) => {
  try {
    const parsed = productSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ success: false, error: "Please check the product fields." });
    }
    const storeId = await storeIdForUser(req.userId!);
    if (!storeId) return res.status(400).json({ success: false, error: "No store found for this account." });
    const p = parsed.data;
    const [row] = await query(
      `INSERT INTO products (store_id, name, description, price_cents, compare_at_price_cents, sku, inventory, status, tags)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [storeId, p.name, p.description ?? null, p.priceCents, p.compareAtPriceCents ?? null, p.sku ?? null, p.inventory, p.status, p.tags]
    );
    res.status(201).json({ success: true, data: row });
  } catch (err) {
    next(err);
  }
});

productsRouter.get("/:id", async (req: AuthedRequest, res, next) => {
  try {
    const [row] = await query("SELECT * FROM products WHERE id = $1", [req.params.id]);
    if (!row) return res.status(404).json({ success: false, error: "Product not found." });
    res.json({ success: true, data: row });
  } catch (err) {
    next(err);
  }
});

productsRouter.put("/:id", async (req: AuthedRequest, res, next) => {
  try {
    const parsed = productSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ success: false, error: "Please check the product fields." });
    }
    const p = parsed.data;
    const [row] = await query(
      `UPDATE products SET
        name = COALESCE($2, name),
        description = COALESCE($3, description),
        price_cents = COALESCE($4, price_cents),
        status = COALESCE($5, status),
        updated_at = now()
       WHERE id = $1 RETURNING *`,
      [req.params.id, p.name, p.description, p.priceCents, p.status]
    );
    if (!row) return res.status(404).json({ success: false, error: "Product not found." });
    res.json({ success: true, data: row });
  } catch (err) {
    next(err);
  }
});

productsRouter.delete("/:id", async (req: AuthedRequest, res, next) => {
  try {
    await query("DELETE FROM products WHERE id = $1", [req.params.id]);
    res.json({ success: true, data: null });
  } catch (err) {
    next(err);
  }
});
