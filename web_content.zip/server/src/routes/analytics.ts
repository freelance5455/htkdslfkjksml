import { Router } from "express";
import { query } from "../database/pool.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";

export const analyticsRouter = Router();
analyticsRouter.use(requireAuth);

// Returns real aggregates when data exists. If there's no sales/visitor
// history yet, the client shows "No sales data yet" — analytics are never
// invented.
analyticsRouter.get("/", async (req: AuthedRequest, res, next) => {
  try {
    const [store] = await query("SELECT id FROM stores WHERE user_id = $1", [req.userId]);
    if (!store) return res.json({ success: true, data: { hasData: false } });

    const [salesRow] = await query(
      "SELECT COALESCE(SUM(total_cents),0) as total_cents, COUNT(*) as order_count FROM orders WHERE store_id = $1 AND is_demo = false",
      [store.id]
    );
    const [visitorRow] = await query(
      "SELECT COUNT(*) as visitor_count FROM store_visitors WHERE store_id = $1",
      [store.id]
    );
    const topProducts = await query(
      `SELECT p.name, COALESCE(SUM(oi.quantity),0) as units_sold
       FROM products p
       LEFT JOIN order_items oi ON oi.product_id = p.id
       WHERE p.store_id = $1
       GROUP BY p.name ORDER BY units_sold DESC LIMIT 5`,
      [store.id]
    );

    const hasData = Number(salesRow.order_count) > 0 || Number(visitorRow.visitor_count) > 0;
    res.json({
      success: true,
      data: {
        hasData,
        totalSalesCents: Number(salesRow.total_cents),
        orderCount: Number(salesRow.order_count),
        visitorCount: Number(visitorRow.visitor_count),
        conversionRate:
          Number(visitorRow.visitor_count) > 0
            ? Number(salesRow.order_count) / Number(visitorRow.visitor_count)
            : 0,
        topProducts,
      },
    });
  } catch (err) {
    next(err);
  }
});
