import { Router } from "express";
import { z } from "zod";
import { query } from "../database/pool.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";

export const storeRouter = Router();
storeRouter.use(requireAuth);

storeRouter.get("/", async (req: AuthedRequest, res, next) => {
  try {
    const [store] = await query("SELECT * FROM stores WHERE user_id = $1", [req.userId]);
    if (!store) return res.status(404).json({ success: false, error: "No store found." });
    const [theme] = await query("SELECT * FROM store_themes WHERE store_id = $1", [store.id]);
    res.json({ success: true, data: { ...store, theme } });
  } catch (err) {
    next(err);
  }
});

const updateSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  tagline: z.string().max(200).optional(),
  description: z.string().max(2000).optional(),
  currency: z.string().length(3).optional(),
  timezone: z.string().max(80).optional(),
});

storeRouter.put("/", async (req: AuthedRequest, res, next) => {
  try {
    const parsed = updateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ success: false, error: "Please check store settings." });
    const p = parsed.data;
    const [row] = await query(
      `UPDATE stores SET
        name = COALESCE($2, name),
        tagline = COALESCE($3, tagline),
        description = COALESCE($4, description),
        currency = COALESCE($5, currency),
        timezone = COALESCE($6, timezone),
        updated_at = now()
       WHERE user_id = $1 RETURNING *`,
      [req.userId, p.name, p.tagline, p.description, p.currency, p.timezone]
    );
    if (!row) return res.status(404).json({ success: false, error: "No store found." });
    res.json({ success: true, data: row });
  } catch (err) {
    next(err);
  }
});
