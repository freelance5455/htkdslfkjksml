import { scrypt as _scrypt, randomBytes, createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
const scrypt = promisify(_scrypt);

export const sha256 = (s) => createHash('sha256').update(String(s)).digest('hex');
export const randomToken = (n = 32) => randomBytes(n).toString('base64url');

export async function hashPassword(pw) {
  const salt = randomBytes(16);
  const key = await scrypt(String(pw), salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}
export async function verifyPassword(pw, stored) {
  try {
    const [alg, s, k] = String(stored || '').split('$');
    if (alg !== 'scrypt') return false;
    const salt = Buffer.from(s, 'base64'), want = Buffer.from(k, 'base64');
    const got = await scrypt(String(pw), salt, want.length, { N: 16384, r: 8, p: 1 });
    return got.length === want.length && timingSafeEqual(got, want);
  } catch { return false; }
}

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
export function signJwt(payload, secret, ttlSec) {
  const now = Math.floor(Date.now() / 1000);
  const body = { ...payload, iat: now, exp: now + ttlSec };
  const head = b64({ alg: 'HS256', typ: 'JWT' });
  const data = `${head}.${b64(body)}`;
  return `${data}.${createHmac('sha256', secret).update(data).digest('base64url')}`;
}
export function verifyJwt(token, secret) {
  try {
    const [h, p, sig] = String(token || '').split('.');
    if (!h || !p || !sig) return null;
    if (JSON.parse(Buffer.from(h, 'base64url').toString()).alg !== 'HS256') return null;
    const want = createHmac('sha256', secret).update(`${h}.${p}`).digest();
    const got = Buffer.from(sig, 'base64url');
    if (got.length !== want.length || !timingSafeEqual(got, want)) return null;
    const body = JSON.parse(Buffer.from(p, 'base64url').toString());
    if (!body.exp || body.exp < Math.floor(Date.now() / 1000)) return null;
    return body;
  } catch { return null; }
}
