/**
 * JARVIS Dynamic Intent Classifier & Capability Discovery Engine
 * Maps user requests to intent categories, required capabilities, and execution modalities.
 * Enforces intelligent tool selection:
 * - Direct model reasoning for simple queries (e.g. "12 × 12") without unnecessary tools
 * - Precise depth inference ('BRIEF' | 'NORMAL' | 'DETAILED' | 'DEEP' | 'RESEARCH')
 * - Safe boundary separation: Defensive Security vs Prohibited Offensive Exploits
 * - Device & App control detection (marked for truthfulness/unavailability)
 */

import { CapabilityDescriptor, capabilityRegistry } from '../capabilities/capabilityRegistry.ts';
import { LanguageSystem, SupportedLanguage } from '../language/languageSystem.ts';
import type { AgentRole, ResponseDepthLevel } from '../types.ts';

export type UserIntentType =
  | 'CONVERSATIONAL'
  | 'EDUCATIONAL_EXPLANATION'
  | 'RESEARCH'
  | 'CODING'
  | 'CODE_DEBUG'
  | 'TOOL_TASK'
  | 'SYSTEM_CONTROL'
  | 'DEVICE_CONTROL'
  | 'CYBERSECURITY_DEFENSIVE'
  | 'SECURITY_AUDIT'
  | 'UNAUTHORIZED_EXPLOIT_REJECTED'
  | 'CLARIFICATION_NEEDED'
  | 'MEMORY_OPERATION'
  | 'WEBSITE_GENERATION'
  | 'DOCUMENT_GENERATION'
  | 'APP_GENERATION'
  | 'IMAGE_GENERATION'
  | 'VIDEO_GENERATION'
  | 'AI_SHORT_FILM_GENERATION'
  | 'DEPLOYMENT';

export interface AnalyzedIntent {
  rawPrompt: string;
  intentType: UserIntentType;
  requiredCapabilities: CapabilityDescriptor[];
  requiresToolExecution: boolean;
  recommendedAgent: AgentRole;
  targetLanguage: SupportedLanguage;
  explanationDepth: ResponseDepthLevel;
  confidence: number;
  reasoning: string;
  isOffensiveExploitProhibited: boolean;
}

export class IntentClassifier {
  /**
   * Convenience static classifier for standalone prompts
   */
  public static classifyIntent(prompt: string): AnalyzedIntent {
    return this.analyze({ prompt });
  }

  /**
   * Dynamically analyzes user goal and context to discover required capabilities and execution strategy.
   */
  public static analyze(
    params:
      | string
      | {
          prompt: string;
          conversationHistory?: string[];
          userPreferredLanguage?: string;
          userPreferredDepth?: ResponseDepthLevel;
        }
  ): AnalyzedIntent {
    const options = typeof params === 'string' ? { prompt: params } : params;
    const { prompt, conversationHistory, userPreferredLanguage, userPreferredDepth } = options;
    const cleanPrompt = (prompt || '').trim();
    const lower = cleanPrompt.toLowerCase();

    // 1. Resolve Language (Preserving technical terms, supporting Hinglish/Hindi/English)
    const targetLanguage = LanguageSystem.resolveLanguage({
      currentPrompt: cleanPrompt,
      conversationHistory,
      userPreferredLanguage,
    });

    // 2. Resolve Response Depth Level (Section 11 & 12)
    let depth: ResponseDepthLevel = userPreferredDepth || 'NORMAL';
    if (
      /\b(brief|short|concise|quick|summary|tldr|in\s+short|in\s+one\s+sentence|single\s+sentence|one\s+line)\b/i.test(lower) ||
      /\b(short\s+mein|short\s+me|chhota\s+batao|simple\s+bhasha|simple\s+language|aasan\s+bhasha|in\s+simple\s+terms)\b/i.test(lower) ||
      lower.includes('simple samjhao') ||
      lower.includes('simple batao') ||
      lower.includes('short mein') ||
      lower.includes('short me')
    ) {
      depth = 'BRIEF';
    } else if (
      /\b(research\s+paper|academic|peer\s+reviewed|cite\s+sources|scholarly)\b/i.test(lower) ||
      /\b(deep\s+research|research\s+karo|research\s+level)\b/i.test(lower) ||
      lower.includes('deep research')
    ) {
      depth = 'RESEARCH';
    } else if (
      lower.includes('jee level') ||
      lower.includes('deep level') ||
      lower.includes('rigorous') ||
      lower.includes('exhaustive') ||
      /\b(deepest|maximum\s+detail)\b/i.test(lower)
    ) {
      depth = 'DEEP';
    } else if (
      /\b(deep|detailed|in-depth|thorough|comprehensive|explain\s+everything|in\s+detail|detail\s+mein|detail\s+me|properly|technical\s+explanation)\b/i.test(lower) ||
      lower.includes('in detail') ||
      lower.includes('detail mein') ||
      lower.includes('detail me') ||
      lower.includes('properly') ||
      lower.includes('technical explanation') ||
      lower.includes('detail mein samjhao') ||
      lower.includes('detail me samjhao') ||
      lower.includes('vistar se samjhao') ||
      lower.includes('deep detail mein') ||
      lower.includes('class 9 level') ||
      lower.includes('class 10 level') ||
      lower.includes('class 12 level') ||
      lower.includes('vistar se')
    ) {
      depth = 'DETAILED';
    }

    // 3. Prohibited Offensive Exploits Check (Section 9)
    const hasOffensiveExploit =
      /\b(hack\s+(?:into\s+)?(?:an\s+|a\s+|the\s+)?(?:instagram|facebook|account|wifi|phone|system|database|network|password)?|steal\s+password|steal\s+token|steal\s+session|account\s+takeover|bypass\s+auth|instagram\s+hack|facebook\s+hack|wifi\s+hack|crack\s+password|exploit\s+(?:cve|sql|vulnerability|zero-day|0day)|sql\s+injection|create\s+malware|ransomware|keylogger|ddos)\b/i.test(lower) &&
      !lower.includes('prevent') &&
      !lower.includes('defend') &&
      !lower.includes('mitigate') &&
      !lower.includes('audit');

    if (hasOffensiveExploit) {
      return {
        rawPrompt: cleanPrompt,
        intentType: 'UNAUTHORIZED_EXPLOIT_REJECTED',
        requiredCapabilities: capabilityRegistry.discoverCapabilities(['defensive_cybersecurity']),
        requiresToolExecution: false,
        recommendedAgent: 'SECURITY',
        targetLanguage,
        explanationDepth: depth,
        confidence: 0.99,
        reasoning: 'Prohibited offensive exploit / unauthorized access request detected. Strictly rejecting and redirecting to defensive security posture.',
        isOffensiveExploitProhibited: true,
      };
    }

    // 4. Memory / Preference Command Check (Section 5 & Section 12)
    const isMemoryOperation =
      /^(?:please\s+)?(?:remember\s+(?:that|this)|forget\s+(?:that|this|memory)|show\s+(?:what\s+you\s+remember|my\s+memories|my\s+preferences)|clear\s+(?:my\s+preferences|all\s+memories)|what\s+(?:do\s+you\s+remember|preferences\s+do\s+you\s+remember)|kaunsi\s+preferences\s+remember\s+hain|mere\s+baare\s+mein\s+kya\s+yaad\s+hai)/i.test(lower) ||
      /\bremember\s+that\s+i\s+prefer\b/i.test(lower);

    if (isMemoryOperation) {
      return {
        rawPrompt: cleanPrompt,
        intentType: 'MEMORY_OPERATION',
        requiredCapabilities: capabilityRegistry.discoverCapabilities(['memory_retrieval_storage']),
        requiresToolExecution: false,
        recommendedAgent: 'GENERAL',
        targetLanguage,
        explanationDepth: depth,
        confidence: 0.98,
        reasoning: 'Explicit memory or user preference management command parsed.',
        isOffensiveExploitProhibited: false,
      };
    }

    // 5. Simple Direct Arithmetic / Calculation Check (Section 4 & Section 19)
    // E.g., "12 × 12", "12 * 12", "what is 144 / 12", "calculate 15 + 25"
    const isDirectArithmetic =
      /^(?:what\s+is\s+|calculate\s+|solve\s+)?\d+\s*(?:×|\*|x|\/|÷|\+|-|\^|%)\s*\d+(?:\s*calculate\s+karo)?\s*\??$/i.test(lower.trim());

    if (isDirectArithmetic) {
      return {
        rawPrompt: cleanPrompt,
        intentType: 'CONVERSATIONAL',
        requiredCapabilities: capabilityRegistry.discoverCapabilities(['general_dialogue']),
        requiresToolExecution: false, // Model answers directly without unnecessary tool invocation
        recommendedAgent: 'GENERAL',
        targetLanguage,
        explanationDepth: depth,
        confidence: 0.98,
        reasoning: 'Direct arithmetic question solvable via direct reasoning; invoking elevated sandbox or search is unnecessary and forbidden.',
        isOffensiveExploitProhibited: false,
      };
    }

    // 6. Native Device / App Control Check (Section 14)
    const isDeviceControl =
      !/\b(bana\s*do|banado|banao|create|build|scaffold|code)\b/i.test(lower) &&
      (/\b(open\s+app|open\s+screen|tap\s+screen|tap\s+ui|type\s+text\s+on\s+phone|press\s+key|scroll\s+screen|read\s+screen|take\s+screenshot|control\s+phone)\b/i.test(lower) ||
      /^(?:please\s+)?open\s+(?:instagram|whatsapp|facebook|twitter|youtube|spotify|camera|gallery|settings|chrome|maps)\.?$/i.test(lower.trim()));

    if (isDeviceControl) {
      return {
        rawPrompt: cleanPrompt,
        intentType: 'DEVICE_CONTROL',
        requiredCapabilities: capabilityRegistry.discoverCapabilities(['device_app_control']),
        requiresToolExecution: true,
        recommendedAgent: 'AUTOMATION',
        targetLanguage,
        explanationDepth: depth,
        confidence: 0.95,
        reasoning: 'Device / app control action identified. Bound to device abstraction contract (marked UNAVAILABLE in web container).',
        isOffensiveExploitProhibited: false,
      };
    }

    // 6b. Detection of How-To / Educational Questions vs Active Creation Requests
    const isHowToQuestion =
      /\b(kaise\s+(?:banate\s+hain|banayein?|banta\s+hai|karein?|banaya\s+jata\s+hai|seekhein?)|kya\s+(?:hota|hoti|hote)\s+hai|samjhao|sikhao|batao\s+kaise|steps\s+kya\s+hain)\b/i.test(lower) ||
      /\b(how\s+to\s+(?:make|build|create|develop|code|design|generate)|how\s+(?:do\s+you|can\s+i|is\s+it)\s+(?:make|build|create|developed|designed)|what\s+is\s+(?:the\s+process|a|an)|tutorial\s+(?:on|for)|guide\s+(?:to|for)|explain\s+how\s+to)\b/i.test(lower);

    const hasCreationVerb =
      /\b(bana\s*do|banado|banao|bana\s+ke\s+do|banakar\s+do|bana\s+de|bana\s+dijiye|tayyar\s+karo|create|build|generate|make|produce|scaffold|design\s+and\s+build|write|develop|code)\b/i.test(lower);

    const isShortFilmCreation =
      !isHowToQuestion &&
      (
        /\b(short\s*film|ai\s*film|movie|feature\s*film|cinema|film\s*studio|shortfilm)\b/i.test(lower) ||
        (/\b(?:film|cinema)\b/i.test(lower) && /\b(?:bana|make|create|generate|produce)\b/i.test(lower))
      );

    const isCodeDebug =
      !isHowToQuestion &&
      (
        /\b(code\s+fix|fix\s+code|debug\s+code|code\s+debug|fix\s+this\s+code|fix\s+bug|debug\s+this|troubleshoot\s+code)\b/i.test(lower) ||
        /\b(code\s+fix\s+karo|bug\s+fix\s+karo|error\s+fix\s+karo|code\s+theek\s+karo)\b/i.test(lower)
      );

    const isWebsiteCreation =
      !isHowToQuestion &&
      (hasCreationVerb || /\b(website|landing\s+page)\b/i.test(lower)) &&
      /\b(website|site|landing\s+page|web\s+portal|webpage|web\s+site)\b/i.test(lower);

    const isDocumentCreation =
      !isHowToQuestion &&
      (hasCreationVerb || /\b(pdf|document|docx?|csv|json)\b/i.test(lower)) &&
      /\b(pdf|document|doc|docx|csv|json|txt|spreadsheet|notes\s+file|text\s+file)\b/i.test(lower);

    const isAppCreation =
      !isHowToQuestion &&
      !isDeviceControl &&
      (hasCreationVerb || /\b(scaffold|develop\s+app)\b/i.test(lower)) &&
      /\b(app|application|mobile\s+app|android\s+app|ios\s+app|react\s+native\s+app)\b/i.test(lower);

    const isImageCreation =
      !isHowToQuestion &&
      (hasCreationVerb || /\b(draw|paint|synthesize\s+image|generate\s+image)\b/i.test(lower)) &&
      /\b(image|photo|picture|tasveer|chhavi|diagram|artwork|illustration|drawing)\b/i.test(lower);

    const isVideoCreation =
      !isHowToQuestion &&
      !isShortFilmCreation &&
      (hasCreationVerb || /\b(animate|render\s+video|generate\s+video)\b/i.test(lower)) &&
      /\b(video|animation|motion\s+graphic|clip)\b/i.test(lower);

    const isDeployment =
      !isHowToQuestion &&
      (
        (/\b(deploy|publish|host)\b/i.test(lower) && /\b(vercel|netlify|cloud\s+run|github\s+pages|render|container)\b/i.test(lower)) ||
        /\b(deploy\s+kar\s*do|host\s+kar\s*do|hosting\s+karo|deploy\s+karo|host\s+karo)\b/i.test(lower)
      );

    const isExplicitResearch =
      !isHowToQuestion &&
      (/\b(research\s+karo|deep\s+research|conduct\s+research|research\s+about|literature\s+review)\b/i.test(lower) ||
       (lower.includes('research') && (hasCreationVerb || lower.includes('karo') || lower.includes('do'))));

    // 6c. Capability Discovery Feature Extraction
    const features: string[] = [];

    if (targetLanguage === 'hinglish' || targetLanguage === 'hi') {
      features.push('multilingual');
    }

    if (isShortFilmCreation) {
      features.push('media');
      features.push('film_studio');
    }

    if (isWebsiteCreation || isAppCreation || isCodeDebug) {
      features.push('code');
      features.push('coding_agent');
    }

    if (isDocumentCreation) {
      features.push('document_generation');
    }

    if (isImageCreation || isVideoCreation || isShortFilmCreation) {
      features.push('media');
    }

    if (isDeployment) {
      features.push('automation');
      features.push('deployment');
    }

    // Defensive Cybersecurity features
    const hasCyberKeywords =
      /\b(vulnerability|cve|security\s+audit|security|owasp|threat\s+model|auth\s+flow|hashing|secure\s+coding|log\s+analysis|penetration\s+test|ctf|static\s+analysis)\b/i.test(lower);
    if (hasCyberKeywords) {
      features.push('cybersecurity');
      features.push('security');
    }

    // Coding & Software features
    const hasCodingKeywords =
      /\b(code|algorithm|function|script|debug|typescript|javascript|python|sandbox|test\s+matrix|regex|sql|api\s+route|refactor)\b/i.test(lower);
    if (hasCodingKeywords) {
      features.push('code');
      if (lower.includes('run') || lower.includes('execute') || lower.includes('sandbox') || lower.includes('test')) {
        features.push('sandbox');
      }
    }

    // Research & Live fact-finding features
    const hasResearchKeywords =
      /\b(search|web|find\s+out|latest|current\s+news|sources|citations|market\s+data|finance|stock|sip|fact\s+check)\b/i.test(lower);
    if (hasResearchKeywords) {
      features.push('research');
      features.push('web');
    }

    // Educational / Explanatory features
    const hasExplanationKeywords =
      isHowToQuestion ||
      /\b(explain|how\s+does|what\s+is|why\s+does|understand|derive|concept|theory|physics|quantum|biology|intuition|teach\s+me)\b/i.test(lower);
    if (hasExplanationKeywords) {
      features.push('explanation');
      features.push('reasoning');
    }

    // System & Diagnostics
    const hasSystemKeywords =
      /\b(status|diagnostics|telemetry|health|metrics|cpu|memory|db|uptime|inspect)\b/i.test(lower);
    if (hasSystemKeywords) {
      features.push('system');
    }

    // External action / automation
    const hasExternalAction =
      /\b(send\s+email|post\s+publicly|delete\s+all|wipe|drop\s+database|execute\s+shell|automate|dispatch|webhook|external\s+action)\b/i.test(lower);
    if (hasExternalAction) {
      features.push('automation');
    }

    // Discover capabilities from registry
    const discoveredCapabilities = capabilityRegistry.discoverCapabilities(
      features.length > 0 ? features : ['general_dialogue']
    );

    // 7. Intent Classification and Execution Strategy
    let intentType: UserIntentType = 'CONVERSATIONAL';
    let requiresToolExecution = false;
    let recommendedAgent: AgentRole = 'GENERAL';
    let reasoning = 'General conversational query; direct reasoning synthesis.';

    if (isHowToQuestion) {
      // Educational explanation without generating project artifacts
      intentType = 'EDUCATIONAL_EXPLANATION';
      requiresToolExecution = false;
      recommendedAgent = 'GENERAL';
      reasoning = 'Educational/conceptual explanation of steps and methodology; direct pedagogical reasoning without project generator tools.';
    } else if (isShortFilmCreation) {
      intentType = 'AI_SHORT_FILM_GENERATION';
      requiresToolExecution = true;
      recommendedAgent = 'GENERAL';
      reasoning = 'AI Short Film Studio production pipeline requested. Orchestrates complete multi-scene screenplay, character/world bible, continuity registry, and shot clips.';
    } else if (isCodeDebug) {
      intentType = 'CODE_DEBUG';
      requiresToolExecution = true;
      recommendedAgent = 'CODING';
      reasoning = 'Code debugging and repair task requested. Analyzes code errors and produces verified fix.';
    } else if (isWebsiteCreation) {
      intentType = 'WEBSITE_GENERATION';
      requiresToolExecution = true;
      recommendedAgent = 'CODING';
      reasoning = 'Autonomous responsive website generation requested. Synthesizes full HTML5/Tailwind CSS project artifact.';
    } else if (isDocumentCreation) {
      intentType = 'DOCUMENT_GENERATION';
      requiresToolExecution = true;
      recommendedAgent = 'RESEARCH';
      reasoning = 'Structured document/PDF generation requested. Generates valid downloadable document artifact.';
    } else if (isAppCreation) {
      intentType = 'APP_GENERATION';
      requiresToolExecution = true;
      recommendedAgent = 'CODING';
      reasoning = 'Application project scaffolding requested. Scaffolds modular codebase architecture with truthful execution status.';
    } else if (isImageCreation) {
      intentType = 'IMAGE_GENERATION';
      requiresToolExecution = true;
      recommendedAgent = 'GENERAL';
      reasoning = 'Visual image generation requested. Synthesizes image or reports truthful provider credential requirements.';
    } else if (isVideoCreation) {
      intentType = 'VIDEO_GENERATION';
      requiresToolExecution = true;
      recommendedAgent = 'GENERAL';
      reasoning = 'Video generation requested. Orchestrates video synthesis job with truthful configuration status.';
    } else if (isDeployment) {
      intentType = 'DEPLOYMENT';
      requiresToolExecution = true;
      recommendedAgent = 'AUTOMATION';
      reasoning = 'Multi-cloud deployment scaffolding requested. Generates verified deployment config files.';
    } else if (isExplicitResearch) {
      intentType = 'RESEARCH';
      requiresToolExecution = true;
      recommendedAgent = 'RESEARCH';
      reasoning = 'Autonomous deep research requested. Gathers multi-source findings and produces cited report.';
    } else if (hasExternalAction) {
      intentType = 'SYSTEM_CONTROL';
      requiresToolExecution = true;
      recommendedAgent = 'AUTOMATION';
      reasoning = 'Request involves high-consequence system or external action requiring permissions.';
    } else if (hasCyberKeywords) {
      intentType = (lower.includes('audit') || lower.includes('security audit') || lower.includes('auth flow') || lower.includes('hashing') || lower.includes('password'))
        ? 'SECURITY_AUDIT'
        : 'CYBERSECURITY_DEFENSIVE';
      requiresToolExecution = lower.includes('audit') || lower.includes('scan') || lower.includes('inspect') || lower.includes('flow') || lower.includes('hash');
      recommendedAgent = 'SECURITY';
      reasoning = 'Authorized defensive cybersecurity analysis and threat modeling.';
    } else if (hasCodingKeywords && (lower.includes('run') || lower.includes('execute') || lower.includes('test') || lower.includes('sandbox'))) {
      intentType = 'CODING';
      requiresToolExecution = true;
      recommendedAgent = 'CODING';
      reasoning = 'Algorithmic or coding task requiring sandboxed execution and analysis.';
    } else if (hasCodingKeywords) {
      intentType = 'CODING';
      requiresToolExecution = false; // Direct synthesis of code solution without running sandbox
      recommendedAgent = 'CODING';
      reasoning = 'Code synthesis or architectural design query.';
    } else if (hasResearchKeywords && (lower.includes('search') || lower.includes('lookup') || lower.includes('find') || lower.includes('sip') || lower.includes('quote'))) {
      intentType = 'RESEARCH';
      requiresToolExecution = true;
      recommendedAgent = 'RESEARCH';
      reasoning = 'Requires external research or financial quantitative tool queries.';
    } else if (hasExplanationKeywords) {
      intentType = 'EDUCATIONAL_EXPLANATION';
      requiresToolExecution = false;
      recommendedAgent = 'GENERAL';
      reasoning = 'Educational/conceptual explanation; multi-tier pedagogical structure.';
    } else if (hasSystemKeywords && (lower.includes('show') || lower.includes('check') || lower.includes('run'))) {
      intentType = 'SYSTEM_CONTROL';
      requiresToolExecution = true;
      recommendedAgent = 'GENERAL';
      reasoning = 'System telemetry and health diagnostic check.';
    }

    return {
      rawPrompt: cleanPrompt,
      intentType,
      requiredCapabilities: discoveredCapabilities,
      requiresToolExecution,
      recommendedAgent,
      targetLanguage,
      explanationDepth: depth,
      confidence: 0.9,
      reasoning,
      isOffensiveExploitProhibited: false,
    };
  }
}
