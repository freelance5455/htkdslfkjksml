import {
  CapitalRaidSeason,
  ClanEvent,
  ClanEventType,
  ClanInfo,
  ClanRole,
  ClanSnapshot,
  ClanWarEntry,
  CurrentWarInfo,
  CwlGroupInfo,
  CwlPlayerRating,
  CwlStandingClan,
  CwlWarSummary,
  HistoryPoint,
  OfficialAchievement,
  OfficialUnitEntry,
  PlayerCombatStats,
  PlayerProfile,
  ROLE_LABELS_RU,
  SyncProgressInfo,
  UpgradeDetailType,
  UpgradeEvent,
  VILLAGE_ENTITIES,
  VillageCategory,
  VillageItemInstance,
  WarMemberDetail,
  calculatePlayerProgress,
  computeClanAggregateStats,
  getCapForTh,
  getWallCapForTh,
  groupPlayersByTownHall,
} from '../src/shared/cocData.ts';
import {
  buildSnapshotPlayerEntry,
  computeClanPlayerRatings,
  translateCocUnitNameRu,
} from '../src/utils/clanAnalytics.ts';

const SUPERCELL_API_BASE = 'https://api.clashofclans.com/v1';

const OFFICIAL_NAME_TO_ENTITY_ID: Record<string, string> = {
  'Barbarian King': 'barbarian_king',
  'Archer Queen': 'archer_queen',
  'Grand Warden': 'grand_warden',
  'Royal Champion': 'royal_champion',
  'Minion Prince': 'minion_prince',
  'Electro Dragon': 'electro_dragon',
  'Root Rider': 'root_rider',
  'Dragon': 'dragon',
  'Balloon': 'balloon',
  'Yeti': 'yeti',
  'Healer': 'healer',
  'Rage Spell': 'rage_spell',
  'Freeze Spell': 'freeze_spell',
  'Spirit Fox': 'spirit_fox',
};

const SIEGE_MACHINE_NAMES = new Set([
  'Wall Wrecker',
  'Battle Blimp',
  'Stone Slammer',
  'Siege Barracks',
  'Log Launcher',
  'Flame Flinger',
  'Battle Drill',
  'Troop Launcher',
]);

const PET_NAMES = new Set([
  'L.A.S.S.I',
  'Electro Owl',
  'Mighty Yak',
  'Unicorn',
  'Frosty',
  'Diggy',
  'Poison Lizard',
  'Phoenix',
  'Spirit Fox',
  'Angry Jelly',
  'Sneezy',
]);

export class CocApiError extends Error {
  statusCode: number;
  reason: string;

  constructor(statusCode: number, reason: string, message: string) {
    super(message);
    this.name = 'CocApiError';
    this.statusCode = statusCode;
    this.reason = reason;
  }
}

export type CocSecretName = 'SUPERCELL_API_KEY' | 'CLASH_OF_CLANS_API_KEY' | 'CLASH_API_TOKEN';

const SECRET_PRIORITY: CocSecretName[] = [
  'CLASH_API_TOKEN',
  'CLASH_OF_CLANS_API_KEY',
  'SUPERCELL_API_KEY',
];

let preferredSecretName: CocSecretName | null = null;

function cleanSecretValue(raw: string): string {
  const trimmed = raw.trim();
  const unquoted = trimmed.replace(/^["']+|["']+$/g, '').trim();
  const withoutHeader = unquoted
    .replace(/^(?:[A-Z0-9_]+\s*=\s*)?(?:Authorization\s*:\s*)?(?:Bearer\s+)?/i, '')
    .trim();
  const compacted = withoutHeader.replace(/[\r\n\s]+/g, '');
  const jwtMatch = compacted.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
  return jwtMatch ? jwtMatch[0] : compacted;
}

export function getSecretCandidates(): Array<{ name: CocSecretName; token: string }> {
  const orderedNames = preferredSecretName
    ? [preferredSecretName, ...SECRET_PRIORITY.filter((n) => n !== preferredSecretName)]
    : SECRET_PRIORITY;

  const list: Array<{ name: CocSecretName; token: string }> = [];
  for (const name of orderedNames) {
    const token = cleanSecretValue(process.env[name] || '');
    if (token) {
      list.push({ name, token });
    }
  }
  return list;
}

export function getActiveSecretName(): CocSecretName | null {
  return getSecretCandidates()[0]?.name ?? null;
}

export function getServerCocToken(): string {
  return getSecretCandidates()[0]?.token ?? '';
}

export function hasValidServerCocToken(): boolean {
  return getSecretCandidates().some((c) => /^[\x21-\x7E]+$/.test(c.token));
}

export function normalizeCocTag(rawTag: string): string {
  let decoded = rawTag.trim();
  for (let i = 0; i < 2; i++) {
    if (decoded.includes('%')) {
      try {
        const next = decodeURIComponent(decoded);
        if (next === decoded) break;
        decoded = next;
      } catch {
        break;
      }
    }
  }
  const cleaned = decoded.trim().toUpperCase().replace(/\s+/g, '').replace(/^#+/, '');
  return `#${cleaned}`;
}

export function validateCocTag(rawTag: string): { valid: boolean; normalized: string } {
  const normalized = normalizeCocTag(rawTag);
  const valid = /^#[0289CGJLPQRUVY]{3,14}$/.test(normalized);
  return { valid, normalized };
}

export function encodeCocTag(rawTag: string): string {
  return encodeURIComponent(normalizeCocTag(rawTag));
}

function parseCocTimestamp(raw?: string): string {
  if (!raw) return new Date().toISOString();
  const m = raw.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})/);
  if (m) {
    return `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}.000Z`;
  }
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}

// TTL Cache + In-Flight Deduplication
interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const apiCache = new Map<string, CacheEntry<unknown>>();
const inFlightRequests = new Map<string, Promise<unknown>>();

export function getCacheStats(): { entries: number; ttlSeconds: number } {
  const now = Date.now();
  for (const [key, entry] of apiCache.entries()) {
    if (entry.expiresAt <= now) {
      apiCache.delete(key);
    }
  }
  return { entries: apiCache.size, ttlSeconds: 60 };
}

export function clearApiCache(): void {
  apiCache.clear();
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

let cachedOutboundIp: { ip: string; expiresAt: number } | null = null;

export async function getServerOutboundIp(): Promise<string | null> {
  if (cachedOutboundIp && cachedOutboundIp.expiresAt > Date.now()) {
    return cachedOutboundIp.ip;
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 3000);
  try {
    const resp = await fetch('https://api.ipify.org?format=json', { signal: ctrl.signal });
    if (!resp.ok) return null;
    const data = (await resp.json()) as { ip?: string };
    if (data.ip) {
      cachedOutboundIp = { ip: data.ip, expiresAt: Date.now() + 300000 };
      return data.ip;
    }
    return null;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function logSupercellCall(entry: {
  endpoint: string;
  stage: 'cache_hit' | 'network' | 'upstream_http' | 'parse_json' | 'config';
  status: number;
  elapsedMs: number;
  error?: string;
}) {
  const ts = new Date().toISOString();
  const base = `[CoC API] ${ts} | ${entry.endpoint} | stage=${entry.stage} | status=${entry.status} | ${entry.elapsedMs}ms`;
  if (entry.error && entry.status >= 500) {
    console.warn(`${base} | error=${entry.error}`);
  } else if (entry.error) {
    console.info(`${base} | detail=${entry.error}`);
  } else {
    console.info(base);
  }
}

async function fetchSupercellJson<T>(
  pathWithQuery: string,
  options?: { timeoutMs?: number; cacheTtlMs?: number; bypassCache?: boolean }
): Promise<T> {
  const timeoutMs = options?.timeoutMs ?? 10000;
  const cacheTtlMs = options?.cacheTtlMs ?? 60000;
  const bypassCache = options?.bypassCache ?? false;
  const startedAt = Date.now();

  const rawCandidates = getSecretCandidates();
  if (rawCandidates.length === 0) {
    logSupercellCall({
      endpoint: pathWithQuery,
      stage: 'config',
      status: 401,
      elapsedMs: Date.now() - startedAt,
      error: 'missing_api_key_secret',
    });
    throw new CocApiError(
      401,
      'missingToken',
      'Секрет SUPERCELL_API_KEY (или CLASH_OF_CLANS_API_KEY / CLASH_API_TOKEN) не задан на сервере. Добавьте официальный API-ключ с developer.clashofclans.com в Secrets.'
    );
  }

  // Deduplicate identical token values while preserving secret names for diagnostics
  const candidates: Array<{ name: CocSecretName; token: string }> = [];
  const seenTokens = new Set<string>();
  for (const c of rawCandidates) {
    if (/^[\x21-\x7E]+$/.test(c.token) && !seenTokens.has(c.token)) {
      seenTokens.add(c.token);
      candidates.push(c);
    }
  }

  if (candidates.length === 0) {
    logSupercellCall({
      endpoint: pathWithQuery,
      stage: 'config',
      status: 401,
      elapsedMs: Date.now() - startedAt,
      error: 'invalid_token_format',
    });
    throw new CocApiError(
      401,
      'invalidTokenFormat',
      'Значение API-ключа в Secrets содержит недопустимые символы и не является корректным Bearer-токеном Clash of Clans API.'
    );
  }

  if (!bypassCache && cacheTtlMs > 0) {
    const cached = apiCache.get(pathWithQuery);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.value as T;
    }
  }

  const existingFlight = inFlightRequests.get(pathWithQuery);
  if (existingFlight) {
    return existingFlight as Promise<T>;
  }

  const runFetch = async (): Promise<T> => {
    let candidateIdx = 0;
    const maxRetries = 3;
    let attempt = 0;

    while (true) {
      const currentCandidate = candidates[candidateIdx];
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);

      let resp: Response;
      try {
        resp = await fetch(`${SUPERCELL_API_BASE}${pathWithQuery}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${currentCandidate.token}`,
            Accept: 'application/json',
          },
          signal: ctrl.signal,
        });
      } catch (err) {
        clearTimeout(timer);
        const errName = err instanceof Error ? err.name : 'Error';
        if (errName === 'AbortError') {
          if (attempt < 1) {
            attempt++;
            await sleep(600 * attempt);
            continue;
          }
          logSupercellCall({
            endpoint: pathWithQuery,
            stage: 'network',
            status: 504,
            elapsedMs: Date.now() - startedAt,
            error: 'upstream_timeout',
          });
          throw new CocApiError(
            504,
            'timeout',
            'Network Error: превышено время ожидания ответа от серверов Clash of Clans.'
          );
        }
        if (attempt < 1) {
          attempt++;
          await sleep(600 * attempt);
          continue;
        }
        logSupercellCall({
          endpoint: pathWithQuery,
          stage: 'network',
          status: 502,
          elapsedMs: Date.now() - startedAt,
          error: `upstream_network_${errName}`,
        });
        throw new CocApiError(
          502,
          'networkError',
          'Network Error: не удалось установить соединение с официальным Clash of Clans API.'
        );
      } finally {
        clearTimeout(timer);
      }

      if (resp.ok) {
        preferredSecretName = currentCandidate.name;
        let json: T;
        try {
          json = (await resp.json()) as T;
        } catch {
          logSupercellCall({
            endpoint: pathWithQuery,
            stage: 'parse_json',
            status: resp.status,
            elapsedMs: Date.now() - startedAt,
            error: 'invalid_json_from_supercell',
          });
          throw new CocApiError(
            502,
            'invalidJson',
            'Ошибка 502: официальный Clash of Clans API вернул некорректный JSON.'
          );
        }
        if (cacheTtlMs > 0) {
          apiCache.set(pathWithQuery, {
            value: json,
            expiresAt: Date.now() + cacheTtlMs,
          });
        }
        logSupercellCall({
          endpoint: pathWithQuery,
          stage: 'upstream_http',
          status: resp.status,
          elapsedMs: Date.now() - startedAt,
        });
        return json;
      }

      let errBody: { reason?: string; message?: string } = {};
      try {
        errBody = (await resp.json()) as { reason?: string; message?: string };
      } catch {
        // non-JSON response
      }

      const reason = errBody.reason || '';

      // If another distinct secret is configured and the current one got 401/403, try the next secret
      if ((resp.status === 401 || resp.status === 403) && candidateIdx + 1 < candidates.length) {
        console.info(
          `[CoC API] ${new Date().toISOString()} | ${pathWithQuery} | fallback from ${currentCandidate.name} (${resp.status}) to ${candidates[candidateIdx + 1].name}`
        );
        candidateIdx++;
        attempt = 0;
        continue;
      }

      // Exponential backoff on 429 and transient 5xx (502, 503, 504)
      if ((resp.status === 429 || resp.status >= 502) && attempt < maxRetries) {
        const retryAfterHeader = resp.headers.get('retry-after');
        const retryAfterMs = retryAfterHeader ? Number(retryAfterHeader) * 1000 : 0;
        const backoffMs = Math.max(
          Number.isFinite(retryAfterMs) ? retryAfterMs : 0,
          750 * Math.pow(2, attempt) + Math.floor(Math.random() * 250)
        );
        attempt++;
        await sleep(Math.min(backoffMs, 8000));
        continue;
      }

      logSupercellCall({
        endpoint: pathWithQuery,
        stage: 'upstream_http',
        status: resp.status,
        elapsedMs: Date.now() - startedAt,
        error: `${currentCandidate.name}:${reason || errBody.message || `http_${resp.status}`}`,
      });

      if (resp.status === 401) {
        throw new CocApiError(
          401,
          reason || 'unauthorized',
          `Ошибка 401: проблема авторизации в Clash of Clans API (${errBody.message || reason || 'unauthorized'}). Проверьте секрет ${currentCandidate.name}.`
        );
      }

      if (resp.status === 403) {
        const outboundIp = await getServerOutboundIp();
        const ipHint = outboundIp
          ? ` Текущий исходящий IP сервера: ${outboundIp}.`
          : '';
        const detailMsg = errBody.message ? ` Ответ Supercell: ${errBody.message}.` : '';
        if (reason === 'accessDenied.invalidIp' || errBody.message?.toLowerCase().includes('ip')) {
          throw new CocApiError(
            403,
            'accessDenied.invalidIp',
            `Ошибка 403: доступ запрещён — исходящий IP-адрес сервера не разрешён в белом списке ключа на developer.clashofclans.com.${ipHint}`
          );
        }
        throw new CocApiError(
          403,
          reason || 'accessDenied',
          `Ошибка 403: ключ ${currentCandidate.name} отклонён Supercell API (${reason || 'accessDenied'}).${detailMsg}${ipHint} Проверьте, что в Secrets сохранён действующий ключ именно от Clash of Clans API.`
        );
      }

      if (resp.status === 404) {
        throw new CocApiError(
          404,
          reason || 'notFound',
          'Ошибка 404: клан, игрок или ресурс с указанным тегом не найден в Clash of Clans API.'
        );
      }

      if (resp.status === 429) {
        throw new CocApiError(
          429,
          reason || 'requestThrottled',
          'Ошибка 429: превышен лимит запросов к Supercell API. Повторите через несколько секунд.'
        );
      }

      if (resp.status === 400) {
        throw new CocApiError(
          400,
          reason || 'badRequest',
          'Ошибка 400: некорректный запрос или формат тега для Clash of Clans API.'
        );
      }

      if (resp.status >= 500) {
        throw new CocApiError(
          resp.status,
          reason || 'serverError',
          `Ошибка ${resp.status}: внутренняя ошибка или техработы на серверах Supercell.`
        );
      }

      throw new CocApiError(
        resp.status,
        reason || 'apiError',
        `Ошибка Clash of Clans API (${resp.status}).`
      );
    }
  };

  const promise = runFetch().finally(() => {
    inFlightRequests.delete(pathWithQuery);
  });
  inFlightRequests.set(pathWithQuery, promise);
  return promise;
}

export interface OfficialClanSearchItem {
  tag: string;
  name: string;
  clanLevel: number;
  badgeUrl?: string;
  warLeague: string;
  locationName?: string;
  memberCount: number;
  clanPoints: number;
  clanCapitalPoints?: number;
  warWins: number;
  isWarLogPublic?: boolean;
}

export interface PaginatedResponse<T> {
  items: T[];
  paging?: {
    cursors?: {
      after?: string;
      before?: string;
    };
  };
}

interface RawOfficialClan {
  tag: string;
  name: string;
  description?: string;
  type?: string;
  clanLevel: number;
  clanPoints?: number;
  clanBuilderBasePoints?: number;
  clanCapitalPoints?: number;
  badgeUrls?: { small?: string; medium?: string; large?: string };
  warLeague?: { id?: number; name?: string };
  capitalLeague?: { id?: number; name?: string };
  clanCapital?: {
    capitalHallLevel?: number;
    districts?: Array<{ id: number; name: string; districtHallLevel: number }>;
  };
  chatLanguage?: { id?: number; name?: string; languageCode?: string };
  location?: { id?: number; name?: string; isCountry?: boolean; countryCode?: string };
  requiredTownhallLevel?: number;
  requiredTrophies?: number;
  requiredBuilderBaseTrophies?: number;
  warFrequency?: string;
  warWins?: number;
  warLosses?: number;
  warTies?: number;
  warWinStreak?: number;
  isWarLogPublic?: boolean;
  isFamilyFriendly?: boolean;
  labels?: Array<{ id: number; name: string; iconUrls?: { small?: string; medium?: string } }>;
  members?: number;
  memberList?: RawOfficialClanMember[];
}

export interface RawOfficialClanMember {
  tag: string;
  name: string;
  role?: ClanRole;
  townHallLevel?: number;
  expLevel?: number;
  league?: { id?: number; name?: string; iconUrls?: { small?: string; tiny?: string; medium?: string } };
  trophies?: number;
  builderBaseTrophies?: number;
  donations?: number;
  donationsReceived?: number;
  clanRank?: number;
  previousClanRank?: number;
}

interface RawOfficialPlayer {
  tag: string;
  name: string;
  role?: ClanRole;
  townHallLevel: number;
  townHallWeaponLevel?: number;
  expLevel?: number;
  builderHallLevel?: number;
  trophies: number;
  bestTrophies?: number;
  builderBaseTrophies?: number;
  bestBuilderBaseTrophies?: number;
  warStars: number;
  attackWins?: number;
  defenseWins?: number;
  donations: number;
  donationsReceived: number;
  clanCapitalContributions?: number;
  warPreference?: 'in' | 'out';
  league?: { id?: number; name?: string; iconUrls?: { small?: string; tiny?: string; medium?: string } };
  builderBaseLeague?: { id?: number; name?: string };
  clan?: {
    tag: string;
    name: string;
    clanLevel: number;
    badgeUrls?: { small?: string; medium?: string; large?: string };
  };
  heroes?: Array<{
    name: string;
    level: number;
    maxLevel?: number;
    village: string;
    equipment?: Array<{ name: string; level: number; maxLevel?: number; village?: string }>;
  }>;
  heroEquipment?: Array<{
    name: string;
    level: number;
    maxLevel?: number;
    village?: string;
  }>;
  troops?: Array<{
    name: string;
    level: number;
    maxLevel?: number;
    village: string;
    superTroopIsActive?: boolean;
  }>;
  spells?: Array<{
    name: string;
    level: number;
    maxLevel?: number;
    village: string;
  }>;
  achievements?: Array<{
    name: string;
    stars: number;
    value: number;
    target: number;
    info: string;
    completionInfo?: string | null;
    village: string;
  }>;
  legendStatistics?: {
    legendTrophies?: number;
    previousSeason?: { id?: string; rank?: number; trophies?: number };
    bestSeason?: { id?: string; rank?: number; trophies?: number };
    previousBuilderBaseSeason?: { id?: string; rank?: number; trophies?: number };
    bestBuilderBaseSeason?: { id?: string; rank?: number; trophies?: number };
    currentSeason?: { id?: string; rank?: number; trophies?: number };
  };
  labels?: Array<{ id: number; name: string; iconUrls?: { small?: string; medium?: string } }>;
}

interface RawOfficialWarLogEntry {
  result?: 'win' | 'lose' | 'tie' | null;
  endTime?: string;
  teamSize?: number;
  attacksPerMember?: number;
  clan?: {
    tag?: string;
    name?: string;
    clanLevel?: number;
    badgeUrls?: { small?: string; medium?: string; large?: string };
    attacks?: number;
    stars?: number;
    destructionPercentage?: number;
  };
  opponent?: {
    tag?: string;
    name?: string;
    clanLevel?: number;
    badgeUrls?: { small?: string; medium?: string; large?: string };
    stars?: number;
    destructionPercentage?: number;
  };
}

interface RawOfficialWarMember {
  tag: string;
  name: string;
  townhallLevel?: number;
  mapPosition?: number;
  attacks?: Array<{
    attackerTag: string;
    defenderTag: string;
    stars: number;
    destructionPercentage: number;
    order?: number;
    duration?: number;
  }>;
  opponentAttacks?: number;
  bestOpponentAttack?: {
    attackerTag?: string;
    stars: number;
    destructionPercentage: number;
  };
}

interface RawOfficialWarClan {
  tag?: string;
  name?: string;
  clanLevel?: number;
  badgeUrls?: { small?: string; medium?: string; large?: string };
  attacks?: number;
  stars?: number;
  destructionPercentage?: number;
  members?: RawOfficialWarMember[];
}

interface RawOfficialCurrentWar {
  state?: string;
  teamSize?: number;
  attacksPerMember?: number;
  preparationStartTime?: string;
  startTime?: string;
  endTime?: string;
  clan?: RawOfficialWarClan;
  opponent?: RawOfficialWarClan;
}

interface RawOfficialCwlGroup {
  state?: string;
  season?: string;
  clans?: Array<{
    tag: string;
    name: string;
    clanLevel: number;
    badgeUrls?: { small?: string; medium?: string; large?: string };
    members?: Array<{ tag: string; name: string; townHallLevel: number }>;
  }>;
  rounds?: Array<{
    warTags: string[];
  }>;
}

interface RawOfficialCapitalRaidSeason {
  state?: string;
  startTime?: string;
  endTime?: string;
  capitalTotalLoot?: number;
  raidsCompleted?: number;
  totalAttacks?: number;
  enemyDistrictsDestroyed?: number;
  offensiveReward?: number;
  defensiveReward?: number;
  members?: Array<{
    tag: string;
    name: string;
    attacks?: number;
    attackLimit?: number;
    bonusAttackLimit?: number;
    capitalResourcesLooted?: number;
  }>;
  attackLog?: Array<{
    defender?: {
      tag?: string;
      name?: string;
      level?: number;
      badgeUrls?: { small?: string; medium?: string; large?: string };
    };
    attackCount?: number;
    districtCount?: number;
    districtsDestroyed?: number;
    districts?: Array<{
      id: number;
      name: string;
      districtHallLevel: number;
      destructionPercent?: number;
      stars?: number;
      attackCount?: number;
      totalLooted?: number;
    }>;
  }>;
  defenseLog?: Array<unknown>;
}

function mapRawClanToSearchItem(c: RawOfficialClan): OfficialClanSearchItem {
  return {
    tag: c.tag,
    name: c.name,
    clanLevel: c.clanLevel ?? 1,
    badgeUrl: c.badgeUrls?.medium || c.badgeUrls?.large || c.badgeUrls?.small,
    warLeague: c.warLeague?.name ?? 'Без лиги',
    locationName: c.location?.name,
    memberCount: c.members ?? c.memberList?.length ?? 0,
    clanPoints: c.clanPoints ?? 0,
    clanCapitalPoints: c.clanCapitalPoints ?? 0,
    warWins: c.warWins ?? 0,
    isWarLogPublic: c.isWarLogPublic,
  };
}

function mapRawPlayerToProfile(
  offPlayer: RawOfficialPlayer,
  prevPlayer?: PlayerProfile,
  wAgg?: {
    attacks: number;
    stars: number;
    threeStars: number;
    destSum: number;
    defensesFaced: number;
    starsConceded: number;
    defensesHeld: number;
  },
  memberSummary?: RawOfficialClanMember
): PlayerProfile {
  const nowIso = new Date().toISOString();
  const th = Math.max(1, Math.min(18, offPlayer.townHallLevel ?? memberSummary?.townHallLevel ?? 15));
  const keepVerifiedBuildings =
    Boolean(prevPlayer?.buildingsVerified) && prevPlayer?.townHallLevel === th;

  let items: VillageItemInstance[] = [];
  if (keepVerifiedBuildings && prevPlayer) {
    items = prevPlayer.items.map((it) => ({ ...it, levels: [...it.levels] }));
  } else {
    for (const def of VILLAGE_ENTITIES) {
      if (def.category !== 'heroes' && def.category !== 'lab') continue;
      const cap = getCapForTh(def, th);
      if (cap.maxLevel <= 0 || cap.count <= 0) continue;
      items.push({
        id: def.id,
        nameRu: def.nameRu,
        category: def.category,
        levels: Array(cap.count).fill(0),
        maxLevelForTh: cap.maxLevel,
        expectedCount: cap.count,
        supercellId: def.supercellIds[0],
      });
    }
  }

  const apiEntities = [
    ...(offPlayer.heroes ?? []).filter((h) => h.village === 'home'),
    ...(offPlayer.troops ?? []).filter((t) => t.village === 'home'),
    ...(offPlayer.spells ?? []).filter((s) => s.village === 'home'),
  ];

  for (const e of apiEntities) {
    const id = OFFICIAL_NAME_TO_ENTITY_ID[e.name];
    if (!id) continue;
    const item = items.find((i) => i.id === id);
    if (item && item.levels.length > 0) {
      item.levels[0] = e.level;
    }
  }

  const wallCap = getWallCapForTh(th);
  const walls =
    keepVerifiedBuildings && prevPlayer
      ? prevPlayer.walls
      : {
          totalCount: 0,
          maxLevelForTh: wallCap.maxLevel,
          byLevel: {},
        };

  const progress = calculatePlayerProgress(th, items, walls);
  const warAttacksUsed = wAgg?.attacks ?? 0;
  const warDefensesFaced = wAgg?.defensesFaced ?? 0;

  const combat: PlayerCombatStats = {
    attacksWon: offPlayer.attackWins ?? 0,
    defensesWon: offPlayer.defenseWins ?? 0,
    warAttacksUsed,
    warStarsEarned: wAgg?.stars ?? 0,
    warThreeStars: wAgg?.threeStars ?? 0,
    warAvgDestruction:
      warAttacksUsed > 0 ? Number((wAgg!.destSum / warAttacksUsed).toFixed(1)) : 0,
    warDefensesFaced,
    warStarsConceded: wAgg?.starsConceded ?? 0,
    warDefenseHoldRate:
      warDefensesFaced > 0 ? Math.round((wAgg!.defensesHeld / warDefensesFaced) * 100) : 0,
  };

  const apiHeroes: OfficialUnitEntry[] = (offPlayer.heroes ?? []).map((h) => ({
    name: h.name,
    level: h.level,
    maxLevel: h.maxLevel ?? h.level,
    village: h.village,
    equipment: h.equipment?.map((eq) => ({
      name: eq.name,
      level: eq.level,
      maxLevel: eq.maxLevel ?? eq.level,
      village: eq.village,
    })),
  }));

  const rawEquipList =
    offPlayer.heroEquipment && offPlayer.heroEquipment.length > 0
      ? offPlayer.heroEquipment
      : (offPlayer.heroes ?? []).flatMap((h) => h.equipment ?? []);

  const seenEquipNames = new Set<string>();
  const apiHeroEquipment: OfficialUnitEntry[] = [];
  for (const eq of rawEquipList) {
    const key = `${eq.name}::${eq.village ?? 'home'}`;
    if (seenEquipNames.has(key)) continue;
    seenEquipNames.add(key);
    apiHeroEquipment.push({
      name: eq.name,
      level: eq.level,
      maxLevel: eq.maxLevel ?? eq.level,
      village: eq.village ?? 'home',
    });
  }

  const apiTroops: OfficialUnitEntry[] = [];
  const apiSiegeMachines: OfficialUnitEntry[] = [];
  const apiPets: OfficialUnitEntry[] = [];

  for (const t of offPlayer.troops ?? []) {
    const entry: OfficialUnitEntry = {
      name: t.name,
      level: t.level,
      maxLevel: t.maxLevel ?? t.level,
      village: t.village,
      superTroopIsActive: t.superTroopIsActive,
    };
    if (SIEGE_MACHINE_NAMES.has(t.name)) {
      apiSiegeMachines.push(entry);
    } else if (PET_NAMES.has(t.name)) {
      apiPets.push(entry);
    } else {
      apiTroops.push(entry);
    }
  }

  const apiSpells: OfficialUnitEntry[] = (offPlayer.spells ?? []).map((s) => ({
    name: s.name,
    level: s.level,
    maxLevel: s.maxLevel ?? s.level,
    village: s.village,
  }));

  const achievements: OfficialAchievement[] = (offPlayer.achievements ?? []).map((a) => ({
    name: a.name,
    stars: a.stars,
    value: a.value,
    target: a.target,
    info: a.info,
    completionInfo: a.completionInfo,
    village: a.village,
  }));

  return {
    tag: offPlayer.tag,
    name: offPlayer.name,
    role: offPlayer.role ?? memberSummary?.role ?? 'member',
    townHallLevel: th,
    townHallWeaponLevel: offPlayer.townHallWeaponLevel,
    builderHallLevel: offPlayer.builderHallLevel ?? 0,
    expLevel: offPlayer.expLevel ?? memberSummary?.expLevel ?? 0,
    trophies: offPlayer.trophies ?? memberSummary?.trophies ?? 0,
    bestTrophies: offPlayer.bestTrophies ?? 0,
    builderBaseTrophies: offPlayer.builderBaseTrophies ?? memberSummary?.builderBaseTrophies ?? 0,
    bestBuilderBaseTrophies: offPlayer.bestBuilderBaseTrophies ?? 0,
    warStars: offPlayer.warStars ?? 0,
    donations: offPlayer.donations ?? memberSummary?.donations ?? 0,
    donationsReceived: offPlayer.donationsReceived ?? memberSummary?.donationsReceived ?? 0,
    clanCapitalContributions: offPlayer.clanCapitalContributions ?? 0,
    warPreference: offPlayer.warPreference,
    clanRank: memberSummary?.clanRank,
    previousClanRank: memberSummary?.previousClanRank,
    league: offPlayer.league?.name
      ? {
          id: offPlayer.league.id,
          name: offPlayer.league.name,
          iconUrl:
            offPlayer.league.iconUrls?.medium ||
            offPlayer.league.iconUrls?.small ||
            offPlayer.league.iconUrls?.tiny,
        }
      : memberSummary?.league?.name
      ? {
          id: memberSummary.league.id,
          name: memberSummary.league.name,
          iconUrl:
            memberSummary.league.iconUrls?.medium ||
            memberSummary.league.iconUrls?.small ||
            memberSummary.league.iconUrls?.tiny,
        }
      : undefined,
    builderBaseLeague: offPlayer.builderBaseLeague?.name
      ? {
          id: offPlayer.builderBaseLeague.id,
          name: offPlayer.builderBaseLeague.name,
        }
      : undefined,
    clanRef: offPlayer.clan
      ? {
          tag: offPlayer.clan.tag,
          name: offPlayer.clan.name,
          clanLevel: offPlayer.clan.clanLevel,
          badgeUrl:
            offPlayer.clan.badgeUrls?.medium ||
            offPlayer.clan.badgeUrls?.small ||
            offPlayer.clan.badgeUrls?.large,
        }
      : undefined,
    apiHeroes,
    apiHeroEquipment,
    apiTroops,
    apiSpells,
    apiSiegeMachines,
    apiPets,
    achievements,
    labels: (offPlayer.labels ?? []).map((l) => ({
      id: l.id,
      name: l.name,
      iconUrl: l.iconUrls?.medium || l.iconUrls?.small,
    })),
    legendStatistics: offPlayer.legendStatistics,
    lastSyncedAt: nowIso,
    items,
    walls,
    activeBuilders: prevPlayer?.activeBuilders ?? [],
    progress,
    combat,
    buildingsVerified: keepVerifiedBuildings || Boolean(prevPlayer?.buildingsVerified),
    playerDetailsLoaded: true,
    lastJsonImportAt: prevPlayer?.lastJsonImportAt,
    jsonVillage: prevPlayer?.jsonVillage,
  };
}

/**
 * GET /v1/clans/{clanTag}
 */
export async function getClanByTagOfficial(rawTag: string, bypassCache = false): Promise<RawOfficialClan> {
  const encodedTag = encodeCocTag(rawTag);
  return fetchSupercellJson<RawOfficialClan>(`/clans/${encodedTag}`, {
    timeoutMs: 10000,
    cacheTtlMs: 60000,
    bypassCache,
  });
}

/**
 * GET /v1/clans/{clanTag}/members (with pagination)
 */
export async function getClanMembersOfficial(
  rawTag: string,
  params?: { limit?: number; after?: string; before?: string }
): Promise<PaginatedResponse<RawOfficialClanMember>> {
  const encodedTag = encodeCocTag(rawTag);
  const qs = new URLSearchParams();
  if (params?.limit) qs.set('limit', String(params.limit));
  if (params?.after) qs.set('after', params.after);
  if (params?.before) qs.set('before', params.before);
  const queryStr = qs.toString() ? `?${qs.toString()}` : '';
  return fetchSupercellJson<PaginatedResponse<RawOfficialClanMember>>(
    `/clans/${encodedTag}/members${queryStr}`,
    { timeoutMs: 10000, cacheTtlMs: 60000 }
  );
}

/**
 * GET /v1/players/{playerTag}
 */
export async function getPlayerByTagOfficial(rawTag: string, bypassCache = false): Promise<PlayerProfile> {
  const encodedTag = encodeCocTag(rawTag);
  const raw = await fetchSupercellJson<RawOfficialPlayer>(`/players/${encodedTag}`, {
    timeoutMs: 10000,
    cacheTtlMs: 60000,
    bypassCache,
  });
  return mapRawPlayerToProfile(raw);
}

/**
 * GET /v1/clans/{clanTag}/currentwar
 */
export async function getCurrentWarOfficial(rawTag: string, bypassCache = false): Promise<CurrentWarInfo> {
  const encodedTag = encodeCocTag(rawTag);
  const raw = await fetchSupercellJson<RawOfficialCurrentWar>(`/clans/${encodedTag}/currentwar`, {
    timeoutMs: 9000,
    cacheTtlMs: 30000,
    bypassCache,
  });
  return mapCurrentWar(raw);
}

/**
 * GET /v1/clans/{clanTag}/warlog
 */
export async function getWarLogOfficial(rawTag: string, limit = 20, bypassCache = false) {
  const encodedTag = encodeCocTag(rawTag);
  return fetchSupercellJson<{ items?: RawOfficialWarLogEntry[] }>(
    `/clans/${encodedTag}/warlog?limit=${Math.min(50, Math.max(1, limit))}`,
    { timeoutMs: 9000, cacheTtlMs: 120000, bypassCache }
  );
}

/**
 * GET /v1/clans/{clanTag}/capitalraidseasons
 */
export async function getCapitalRaidSeasonsOfficial(rawTag: string, limit = 5, bypassCache = false) {
  const encodedTag = encodeCocTag(rawTag);
  return fetchSupercellJson<{ items?: RawOfficialCapitalRaidSeason[] }>(
    `/clans/${encodedTag}/capitalraidseasons?limit=${Math.min(20, Math.max(1, limit))}`,
    { timeoutMs: 9000, cacheTtlMs: 120000, bypassCache }
  );
}

/**
 * Lightweight live connectivity check against GET /v1/locations?limit=1
 */
export async function testSupercellApiConnection(): Promise<{
  ok: boolean;
  statusCode: number;
  elapsedMs: number;
  sampleLocation?: string;
}> {
  const started = Date.now();
  const data = await fetchSupercellJson<{ items?: Array<{ id: number; name: string }> }>(
    '/locations?limit=1',
    { timeoutMs: 8000, cacheTtlMs: 0, bypassCache: true }
  );
  return {
    ok: true,
    statusCode: 200,
    elapsedMs: Date.now() - started,
    sampleLocation: data.items?.[0]?.name,
  };
}

/**
 * GET /v1/clans?name={name} (supports pagination)
 */
export async function searchClansByNameOfficial(
  name: string,
  params?: { limit?: number; after?: string; before?: string }
): Promise<PaginatedResponse<OfficialClanSearchItem>> {
  const trimmed = name.trim();
  if (trimmed.length < 3) {
    throw new CocApiError(
      400,
      'badRequest',
      'Для поиска клана по названию введите минимум 3 символа или точный #тег клана.'
    );
  }
  const qs = new URLSearchParams({
    name: trimmed,
    limit: String(params?.limit ?? 15),
  });
  if (params?.after) qs.set('after', params.after);
  if (params?.before) qs.set('before', params.before);

  const resp = await fetchSupercellJson<{
    items?: RawOfficialClan[];
    paging?: PaginatedResponse<OfficialClanSearchItem>['paging'];
  }>(`/clans?${qs.toString()}`, { timeoutMs: 10000, cacheTtlMs: 45000 });

  return {
    items: (resp.items ?? []).map(mapRawClanToSearchItem),
    paging: resp.paging,
  };
}

/**
 * Search clans by tag (#2UPLGJVC -> GET /v1/clans/%232UPLGJVC) or name (GET /v1/clans?name=...)
 */
export async function searchClansOfficial(
  query: string,
  params?: { limit?: number; after?: string; before?: string }
): Promise<PaginatedResponse<OfficialClanSearchItem>> {
  const trimmed = query.trim();
  if (!trimmed) return { items: [] };

  const startsWithHash = trimmed.startsWith('#');
  const cleanAlnum = trimmed.toUpperCase().replace(/[^#A-Z0-9]/g, '');
  const looksLikeBareTag = !startsWithHash && /^[0289CGJLPQRUVY]{4,12}$/.test(cleanAlnum);

  if (startsWithHash) {
    const { valid, normalized } = validateCocTag(trimmed);
    if (!valid) {
      throw new CocApiError(
        400,
        'badRequest',
        'Ошибка 400: некорректный формат тега клана (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y, например #2UPLGJVC).'
      );
    }
    const clan = await getClanByTagOfficial(normalized);
    return { items: [mapRawClanToSearchItem(clan)] };
  }

  if (looksLikeBareTag) {
    try {
      const exactClan = await getClanByTagOfficial(cleanAlnum);
      const exactItem = mapRawClanToSearchItem(exactClan);
      if (trimmed.length >= 3) {
        const byName = await searchClansByNameOfficial(trimmed, params).catch(() => ({
          items: [] as OfficialClanSearchItem[],
          paging: undefined,
        }));
        const merged = [exactItem];
        for (const item of byName.items) {
          if (item.tag !== exactItem.tag) merged.push(item);
        }
        return { items: merged, paging: byName.paging };
      }
      return { items: [exactItem] };
    } catch (err) {
      if (err instanceof CocApiError && err.statusCode === 404 && trimmed.length >= 3) {
        return searchClansByNameOfficial(trimmed, params);
      }
      throw err;
    }
  }

  return searchClansByNameOfficial(trimmed, params);
}

function mapWarMembers(
  members: RawOfficialWarMember[] | undefined,
  opponentMembersByTag: Map<string, RawOfficialWarMember>
): WarMemberDetail[] {
  return (members ?? [])
    .slice()
    .sort((a, b) => (a.mapPosition ?? 99) - (b.mapPosition ?? 99))
    .map((m) => ({
      tag: m.tag,
      name: m.name,
      townHallLevel: m.townhallLevel ?? 1,
      mapPosition: m.mapPosition ?? 0,
      attacks: (m.attacks ?? []).map((atk, idx) => {
        const defender = opponentMembersByTag.get(atk.defenderTag);
        return {
          attackerTag: atk.attackerTag,
          attackerName: m.name,
          defenderTag: atk.defenderTag,
          defenderName: defender?.name,
          defenderTownHall: defender?.townhallLevel,
          stars: atk.stars,
          destructionPercentage: Number((atk.destructionPercentage ?? 0).toFixed(1)),
          order: atk.order ?? idx + 1,
          duration: atk.duration,
        };
      }),
      opponentAttacks: m.opponentAttacks ?? 0,
      bestOpponentAttack: m.bestOpponentAttack
        ? {
            attackerTag: m.bestOpponentAttack.attackerTag ?? '',
            stars: m.bestOpponentAttack.stars,
            destructionPercentage: Number(
              (m.bestOpponentAttack.destructionPercentage ?? 0).toFixed(1)
            ),
          }
        : undefined,
    }));
}

function mapCurrentWar(raw: RawOfficialCurrentWar): CurrentWarInfo {
  const oppMap = new Map<string, RawOfficialWarMember>();
  for (const m of raw.opponent?.members ?? []) oppMap.set(m.tag, m);

  const clanMap = new Map<string, RawOfficialWarMember>();
  for (const m of raw.clan?.members ?? []) clanMap.set(m.tag, m);

  return {
    state: raw.state ?? 'notInWar',
    teamSize: raw.teamSize ?? 0,
    attacksPerMember: raw.attacksPerMember ?? 2,
    preparationStartTime: raw.preparationStartTime ? parseCocTimestamp(raw.preparationStartTime) : undefined,
    startTime: raw.startTime ? parseCocTimestamp(raw.startTime) : undefined,
    endTime: raw.endTime ? parseCocTimestamp(raw.endTime) : undefined,
    clan: {
      tag: raw.clan?.tag ?? '',
      name: raw.clan?.name ?? '',
      badgeUrl:
        raw.clan?.badgeUrls?.medium ||
        raw.clan?.badgeUrls?.small ||
        raw.clan?.badgeUrls?.large,
      clanLevel: raw.clan?.clanLevel ?? 1,
      attacks: raw.clan?.attacks ?? 0,
      stars: raw.clan?.stars ?? 0,
      destructionPercentage: Number((raw.clan?.destructionPercentage ?? 0).toFixed(2)),
      members: mapWarMembers(raw.clan?.members, oppMap),
    },
    opponent: {
      tag: raw.opponent?.tag ?? '',
      name: raw.opponent?.name ?? '',
      badgeUrl:
        raw.opponent?.badgeUrls?.medium ||
        raw.opponent?.badgeUrls?.small ||
        raw.opponent?.badgeUrls?.large,
      clanLevel: raw.opponent?.clanLevel ?? 1,
      attacks: raw.opponent?.attacks ?? 0,
      stars: raw.opponent?.stars ?? 0,
      destructionPercentage: Number((raw.opponent?.destructionPercentage ?? 0).toFixed(2)),
      members: mapWarMembers(raw.opponent?.members, clanMap),
    },
  };
}

export async function loadClanFromSupercellApi(
  rawClanTag: string,
  existingPlayersByTag: Map<string, PlayerProfile>,
  existingHistory: HistoryPoint[],
  existingSnapshots: ClanSnapshot[],
  existingClanTag: string | null,
  existingEvents: UpgradeEvent[],
  existingClanEvents: ClanEvent[] = [],
  existingWars: ClanWarEntry[] = [],
  bypassCache = false,
  onProgress?: (progress: Partial<SyncProgressInfo>) => void,
  existingClan?: ClanInfo | null
): Promise<{
  clan: ClanInfo;
  players: PlayerProfile[];
  wars: ClanWarEntry[];
  currentWar: CurrentWarInfo | null;
  cwl: CwlGroupInfo | null;
  capitalRaids: CapitalRaidSeason[];
  events: UpgradeEvent[];
  newUpgrades: UpgradeEvent[];
  clanEvents: ClanEvent[];
  history: HistoryPoint[];
  snapshots: ClanSnapshot[];
  checkedMembers: number;
  totalMembers: number;
  errorsCount: number;
}> {
  onProgress?.({
    stage: 'fetching_clan',
    statusText: 'Получение данных клана и списка участников из Supercell API...',
    checkedMembers: 0,
    totalMembers: 0,
    upgradesFound: 0,
    errorsCount: 0,
  });

  const encodedTag = encodeCocTag(rawClanTag);
  const rawClan = await fetchSupercellJson<RawOfficialClan>(`/clans/${encodedTag}`, {
    timeoutMs: 10000,
    cacheTtlMs: bypassCache ? 0 : 60000,
    bypassCache,
  });

  // Fetch members via dedicated /members endpoint (or fallback to clan.memberList)
  let memberList: RawOfficialClanMember[] = rawClan.memberList ?? [];
  try {
    const membersResp = await fetchSupercellJson<PaginatedResponse<RawOfficialClanMember>>(
      `/clans/${encodedTag}/members?limit=50`,
      { timeoutMs: 10000, cacheTtlMs: bypassCache ? 0 : 60000, bypassCache }
    );
    if (Array.isArray(membersResp.items) && membersResp.items.length > 0) {
      memberList = membersResp.items;
    }
  } catch (err) {
    if (err instanceof CocApiError && err.statusCode === 429) throw err;
  }

  const nowIso = new Date().toISOString();
  const clan: ClanInfo = {
    tag: rawClan.tag,
    name: rawClan.name,
    description: rawClan.description,
    type: rawClan.type,
    level: rawClan.clanLevel ?? 1,
    warLeague: rawClan.warLeague?.name ?? 'Без лиги',
    capitalLeague: rawClan.capitalLeague?.name,
    clanPoints: rawClan.clanPoints ?? 0,
    clanBuilderBasePoints: rawClan.clanBuilderBasePoints ?? 0,
    clanCapitalPoints: rawClan.clanCapitalPoints ?? 0,
    capitalHallLevel: rawClan.clanCapital?.capitalHallLevel,
    capitalDistricts: rawClan.clanCapital?.districts?.map((d) => ({
      id: d.id,
      name: d.name,
      districtHallLevel: d.districtHallLevel,
    })),
    locationName: rawClan.location?.name,
    locationCountryCode: rawClan.location?.countryCode,
    chatLanguage: rawClan.chatLanguage?.name,
    requiredTownhallLevel: rawClan.requiredTownhallLevel,
    requiredTrophies: rawClan.requiredTrophies,
    requiredBuilderBaseTrophies: rawClan.requiredBuilderBaseTrophies,
    warFrequency: rawClan.warFrequency,
    warWins: rawClan.warWins ?? 0,
    warLosses: rawClan.warLosses,
    warTies: rawClan.warTies,
    warWinStreak: rawClan.warWinStreak ?? 0,
    membersCount: rawClan.members ?? memberList.length,
    isWarLogPublic: rawClan.isWarLogPublic,
    isFamilyFriendly: rawClan.isFamilyFriendly,
    labels: rawClan.labels?.map((l) => ({
      id: l.id,
      name: l.name,
      iconUrl: l.iconUrls?.medium || l.iconUrls?.small,
    })),
    lastSyncedAt: nowIso,
    badgeUrl: rawClan.badgeUrls?.large || rawClan.badgeUrls?.medium || rawClan.badgeUrls?.small,
  };

  // 1. Warlog & Current War
  let rawWarLog: RawOfficialWarLogEntry[] = [];
  let currentWar: CurrentWarInfo | null = null;
  let rawCurrentWar: RawOfficialCurrentWar | null = null;

  if (rawClan.isWarLogPublic !== false) {
    try {
      const wlResp = await fetchSupercellJson<{ items?: RawOfficialWarLogEntry[] }>(
        `/clans/${encodedTag}/warlog?limit=20`,
        { timeoutMs: 9000, cacheTtlMs: bypassCache ? 0 : 120000, bypassCache }
      );
      rawWarLog = wlResp.items ?? [];
    } catch (err) {
      if (err instanceof CocApiError && err.statusCode === 429) throw err;
    }
  }

  try {
    const cw = await fetchSupercellJson<RawOfficialCurrentWar>(
      `/clans/${encodedTag}/currentwar`,
      { timeoutMs: 9000, cacheTtlMs: bypassCache ? 0 : 30000, bypassCache }
    );
    if (cw && cw.state) {
      currentWar = mapCurrentWar(cw);
      if (cw.state !== 'notInWar') {
        rawCurrentWar = cw;
      }
    }
  } catch (err) {
    if (err instanceof CocApiError && err.statusCode === 429) throw err;
  }

  // 2. Clan War League (CWL)
  let cwl: CwlGroupInfo | null = null;
  try {
    const rawGroup = await fetchSupercellJson<RawOfficialCwlGroup>(
      `/clans/${encodedTag}/currentwar/leaguegroup`,
      { timeoutMs: 9000, cacheTtlMs: bypassCache ? 0 : 60000, bypassCache }
    );
    if (rawGroup && rawGroup.state && rawGroup.state !== 'notInWar') {
      const rounds = (rawGroup.rounds ?? []).map((r, idx) => ({
        roundIndex: idx + 1,
        warTags: (r.warTags ?? []).filter((wt) => wt && wt !== '#0'),
      }));

      // Collect war tags involving any clan in the group (cap reasonably to respect rate limit)
      const cwlWars: CwlWarSummary[] = [];
      const standingsMap = new Map<string, CwlStandingClan>();
      for (const c of rawGroup.clans ?? []) {
        standingsMap.set(c.tag, {
          tag: c.tag,
          name: c.name,
          clanLevel: c.clanLevel,
          badgeUrl: c.badgeUrls?.medium || c.badgeUrls?.small || c.badgeUrls?.large,
          warsPlayed: 0,
          wins: 0,
          losses: 0,
          ties: 0,
          stars: 0,
          destructionSum: 0,
        });
      }

      const playerRatingsMap = new Map<
        string,
        { tag: string; name: string; th: number; attacks: number; wars: Set<string>; stars: number; threeStars: number; destSum: number }
      >();

      const allWarTags: Array<{ roundIndex: number; warTag: string }> = [];
      for (const r of rounds) {
        for (const wt of r.warTags) {
          allWarTags.push({ roundIndex: r.roundIndex, warTag: wt });
        }
      }

      // Fetch CWL wars in small batches of 4
      for (let i = 0; i < allWarTags.length; i += 4) {
        const batch = allWarTags.slice(i, i + 4);
        const fetched = await Promise.all(
          batch.map(async ({ roundIndex, warTag }) => {
            try {
              const w = await fetchSupercellJson<RawOfficialCurrentWar>(
                `/clanwarleagues/wars/${encodeCocTag(warTag)}`,
                { timeoutMs: 8000, cacheTtlMs: 60000 }
              );
              return { roundIndex, warTag, w };
            } catch {
              return null;
            }
          })
        );

        for (const item of fetched) {
          if (!item || !item.w || !item.w.clan || !item.w.opponent) continue;
          const { roundIndex, warTag, w } = item;
          const mapped = mapCurrentWar(w);

          // Update standings for both clans when war is active/ended
          if (w.state === 'inWar' || w.state === 'warEnded') {
            const c1 = standingsMap.get(mapped.clan.tag);
            const c2 = standingsMap.get(mapped.opponent.tag);
            const s1 = mapped.clan.stars;
            const s2 = mapped.opponent.stars;
            const d1 = mapped.clan.destructionPercentage;
            const d2 = mapped.opponent.destructionPercentage;

            if (c1) {
              c1.stars += s1;
              c1.destructionSum += d1;
              if (w.state === 'warEnded') {
                c1.warsPlayed += 1;
                if (s1 > s2 || (s1 === s2 && d1 > d2)) {
                  c1.wins += 1;
                  c1.stars += 10; // official CWL war win bonus
                } else if (s1 < s2 || (s1 === s2 && d1 < d2)) {
                  c1.losses += 1;
                } else {
                  c1.ties += 1;
                }
              }
            }
            if (c2) {
              c2.stars += s2;
              c2.destructionSum += d2;
              if (w.state === 'warEnded') {
                c2.warsPlayed += 1;
                if (s2 > s1 || (s2 === s1 && d2 > d1)) {
                  c2.wins += 1;
                  c2.stars += 10;
                } else if (s2 < s1 || (s2 === s1 && d2 < d1)) {
                  c2.losses += 1;
                } else {
                  c2.ties += 1;
                }
              }
            }
          }

          // Collect wars involving our clan + player ratings
          const involvesOurClan =
            mapped.clan.tag === clan.tag || mapped.opponent.tag === clan.tag;
          if (involvesOurClan) {
            const ourSide = mapped.clan.tag === clan.tag ? mapped.clan : mapped.opponent;
            const oppSide = mapped.clan.tag === clan.tag ? mapped.opponent : mapped.clan;
            cwlWars.push({
              warTag,
              roundIndex,
              state: mapped.state,
              teamSize: mapped.teamSize,
              startTime: mapped.startTime,
              endTime: mapped.endTime,
              clan: {
                tag: ourSide.tag,
                name: ourSide.name,
                badgeUrl: ourSide.badgeUrl,
                stars: ourSide.stars,
                destructionPercentage: ourSide.destructionPercentage,
                attacks: ourSide.attacks,
                members: ourSide.members,
              },
              opponent: {
                tag: oppSide.tag,
                name: oppSide.name,
                badgeUrl: oppSide.badgeUrl,
                stars: oppSide.stars,
                destructionPercentage: oppSide.destructionPercentage,
                attacks: oppSide.attacks,
                members: oppSide.members,
              },
            });

            for (const m of ourSide.members) {
              const cur = playerRatingsMap.get(m.tag) ?? {
                tag: m.tag,
                name: m.name,
                th: m.townHallLevel,
                attacks: 0,
                wars: new Set<string>(),
                stars: 0,
                threeStars: 0,
                destSum: 0,
              };
              cur.wars.add(warTag);
              for (const atk of m.attacks) {
                cur.attacks += 1;
                cur.stars += atk.stars;
                if (atk.stars === 3) cur.threeStars += 1;
                cur.destSum += atk.destructionPercentage;
              }
              playerRatingsMap.set(m.tag, cur);
            }
          }
        }
      }

      const standings = Array.from(standingsMap.values()).sort(
        (a, b) => b.stars - a.stars || b.destructionSum - a.destructionSum
      );

      const playerRatings: CwlPlayerRating[] = Array.from(playerRatingsMap.values())
        .map((p) => ({
          tag: p.tag,
          name: p.name,
          townHallLevel: p.th,
          attacksUsed: p.attacks,
          warsParticipated: p.wars.size,
          stars: p.stars,
          threeStars: p.threeStars,
          avgDestruction: p.attacks > 0 ? Number((p.destSum / p.attacks).toFixed(1)) : 0,
        }))
        .sort((a, b) => b.stars - a.stars || b.avgDestruction - a.avgDestruction);

      cwl = {
        state: rawGroup.state,
        season: rawGroup.season ?? '',
        clans: (rawGroup.clans ?? []).map((c) => ({
          tag: c.tag,
          name: c.name,
          clanLevel: c.clanLevel,
          badgeUrl: c.badgeUrls?.medium || c.badgeUrls?.small || c.badgeUrls?.large,
          membersCount: c.members?.length ?? 0,
        })),
        rounds,
        wars: cwlWars.sort((a, b) => a.roundIndex - b.roundIndex),
        standings,
        playerRatings,
      };
    }
  } catch (err) {
    if (err instanceof CocApiError && err.statusCode === 429) throw err;
    // 404 simply means the clan is not currently in a CWL season
  }

  // 3. Clan Capital Raid Seasons
  let capitalRaids: CapitalRaidSeason[] = [];
  try {
    const capResp = await fetchSupercellJson<{ items?: RawOfficialCapitalRaidSeason[] }>(
      `/clans/${encodedTag}/capitalraidseasons?limit=6`,
      { timeoutMs: 9000, cacheTtlMs: bypassCache ? 0 : 120000, bypassCache }
    );
    capitalRaids = (capResp.items ?? []).map((s) => ({
      state: s.state ?? 'ended',
      startTime: parseCocTimestamp(s.startTime),
      endTime: parseCocTimestamp(s.endTime),
      capitalTotalLoot: s.capitalTotalLoot ?? 0,
      raidsCompleted: s.raidsCompleted ?? 0,
      totalAttacks: s.totalAttacks ?? 0,
      enemyDistrictsDestroyed: s.enemyDistrictsDestroyed ?? 0,
      offensiveReward: s.offensiveReward ?? 0,
      defensiveReward: s.defensiveReward ?? 0,
      members: (s.members ?? [])
        .map((m) => ({
          tag: m.tag,
          name: m.name,
          attacks: m.attacks ?? 0,
          attackLimit: m.attackLimit ?? 5,
          bonusAttackLimit: m.bonusAttackLimit ?? 0,
          capitalResourcesLooted: m.capitalResourcesLooted ?? 0,
        }))
        .sort((a, b) => b.capitalResourcesLooted - a.capitalResourcesLooted),
      attackLog: (s.attackLog ?? []).map((log) => ({
        defenderName: log.defender?.name ?? 'Клан',
        defenderTag: log.defender?.tag ?? '',
        defenderLevel: log.defender?.level ?? 1,
        defenderBadgeUrl:
          log.defender?.badgeUrls?.medium ||
          log.defender?.badgeUrls?.small ||
          log.defender?.badgeUrls?.large,
        attackCount: log.attackCount ?? 0,
        districtCount: log.districtCount ?? 0,
        districtsDestroyed: log.districtsDestroyed ?? 0,
        districts: (log.districts ?? []).map((d) => ({
          id: d.id,
          name: d.name,
          districtHallLevel: d.districtHallLevel,
          destructionPercent: d.destructionPercent ?? 0,
          stars: d.stars ?? 0,
          attackCount: d.attackCount ?? 0,
          totalLooted: d.totalLooted ?? 0,
        })),
      })),
      defenseLogCount: s.defenseLog?.length ?? 0,
    }));
  } catch (err) {
    if (err instanceof CocApiError && err.statusCode === 429) throw err;
  }

  // 4. Map War Log
  const monthNames = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const wars: ClanWarEntry[] = rawWarLog
    .filter((w) => w.clan && w.opponent)
    .slice(0, 20)
    .reverse()
    .map((w, idx) => {
      const endIso = parseCocTimestamp(w.endTime);
      const dObj = new Date(endIso);
      const teamSize = w.teamSize ?? 15;
      const attacksPerMember = w.attacksPerMember ?? 2;
      const clanStars = w.clan?.stars ?? 0;
      const oppStars = w.opponent?.stars ?? 0;
      const clanDest = Number((w.clan?.destructionPercentage ?? 0).toFixed(1));
      const oppDest = Number((w.opponent?.destructionPercentage ?? 0).toFixed(1));

      let result: 'win' | 'loss' | 'draw' = 'draw';
      if (w.result === 'win') result = 'win';
      else if (w.result === 'lose') result = 'loss';
      else if (clanStars > oppStars || (clanStars === oppStars && clanDest > oppDest)) result = 'win';
      else if (clanStars < oppStars || (clanStars === oppStars && clanDest < oppDest)) result = 'loss';

      return {
        id: `war-${idx + 1}-${endIso.slice(0, 10)}`,
        date: endIso.slice(0, 10),
        label: `${dObj.getUTCDate()} ${monthNames[dObj.getUTCMonth()]}`,
        endTimeIso: endIso,
        opponentName: w.opponent?.name ?? 'Соперник',
        opponentTag: w.opponent?.tag ?? '#—',
        opponentLevel: w.opponent?.clanLevel,
        opponentBadgeUrl:
          w.opponent?.badgeUrls?.medium ||
          w.opponent?.badgeUrls?.small ||
          w.opponent?.badgeUrls?.large,
        teamSize,
        attacksPerMember,
        clanStars,
        maxStars: teamSize * 3,
        opponentStars: oppStars,
        clanDestruction: clanDest,
        opponentDestruction: oppDest,
        attacksUsed: w.clan?.attacks ?? 0,
        maxAttacks: teamSize * attacksPerMember,
        threeStarAttacks: 0,
        defensesHeld: 0,
        totalEnemyAttacks: 0,
        result,
      };
    });

  // Extract real per-player war stats from currentwar if available
  const playerWarAgg = new Map<
    string,
    {
      attacks: number;
      stars: number;
      threeStars: number;
      destSum: number;
      defensesFaced: number;
      starsConceded: number;
      defensesHeld: number;
    }
  >();

  if (rawCurrentWar?.clan?.members) {
    for (const m of rawCurrentWar.clan.members) {
      const agg = {
        attacks: 0,
        stars: 0,
        threeStars: 0,
        destSum: 0,
        defensesFaced: 0,
        starsConceded: 0,
        defensesHeld: 0,
      };
      for (const atk of m.attacks ?? []) {
        agg.attacks += 1;
        agg.stars += atk.stars;
        if (atk.stars === 3) agg.threeStars += 1;
        agg.destSum += atk.destructionPercentage;
      }
      if ((m.opponentAttacks ?? 0) > 0 || m.bestOpponentAttack) {
        agg.defensesFaced = 1;
        const bestStars = m.bestOpponentAttack?.stars ?? 0;
        agg.starsConceded = bestStars;
        if (bestStars < 3) agg.defensesHeld = 1;
      }
      playerWarAgg.set(m.tag, agg);
    }
  }

  // 5. Fetch detailed profiles for all clan members (batches of 5 to respect Supercell rate limits)
  const isSameClan = existingClanTag === clan.tag;
  const priorUpgradeEvents = isSameClan ? existingEvents : [];
  const priorClanEvents = isSameClan ? existingClanEvents : [];
  const previousSnapshotAt =
    isSameClan && existingSnapshots.length > 0
      ? existingSnapshots[existingSnapshots.length - 1].timestamp
      : undefined;

  const existingUpgradeDedupKeys = new Set(
    priorUpgradeEvents.map((e) => e.dedupKey).filter((x): x is string => Boolean(x))
  );
  const existingClanEventDedupKeys = new Set(
    priorClanEvents.map((e) => e.dedupKey).filter((x): x is string => Boolean(x))
  );

  const players: PlayerProfile[] = [];
  const newEvents: UpgradeEvent[] = [];
  const newClanEvents: ClanEvent[] = [];

  const pushUpgradeEvent = (evt: UpgradeEvent) => {
    if (evt.dedupKey && existingUpgradeDedupKeys.has(evt.dedupKey)) return;
    if (evt.dedupKey) existingUpgradeDedupKeys.add(evt.dedupKey);
    newEvents.push(evt);
  };

  const pushClanEvent = (evt: ClanEvent) => {
    if (existingClanEventDedupKeys.has(evt.dedupKey)) return;
    existingClanEventDedupKeys.add(evt.dedupKey);
    newClanEvents.push(evt);
  };

  const batchSize = 5;
  let checkedMembers = 0;
  let errorsCount = 0;

  onProgress?.({
    stage: 'checking_members',
    statusText: `Проверка уровней участников (0 из ${memberList.length})...`,
    checkedMembers: 0,
    totalMembers: memberList.length,
    upgradesFound: 0,
    errorsCount: 0,
  });

  for (let start = 0; start < memberList.length; start += batchSize) {
    const batch = memberList.slice(start, start + batchSize);
    const batchPlayers = await Promise.all(
      batch.map(async (member) => {
        const encP = encodeCocTag(member.tag);
        let offPlayer: RawOfficialPlayer | null = null;
        try {
          offPlayer = await fetchSupercellJson<RawOfficialPlayer>(`/players/${encP}`, {
            timeoutMs: 8000,
            cacheTtlMs: bypassCache ? 0 : 60000,
            bypassCache,
          });
        } catch (err) {
          if (err instanceof CocApiError && err.statusCode === 429) throw err;
          errorsCount += 1;
        }

        const prevPlayer = isSameClan ? existingPlayersByTag.get(member.tag) : undefined;
        const wAgg = playerWarAgg.get(member.tag);

        if (offPlayer) {
          const profile = mapRawPlayerToProfile(offPlayer, prevPlayer, wAgg, member);

          // Detect ALL real upgrades vs previous saved state (never on initial connect)
          if (prevPlayer) {
            // 1. Town Hall level upgrade
            if (profile.townHallLevel > prevPlayer.townHallLevel) {
              const fromLv = prevPlayer.townHallLevel;
              const toLv = profile.townHallLevel;
              const dedupKey = `upg:${member.tag}:townhall:${fromLv}->${toLv}`;
              pushUpgradeEvent({
                id: `sc-${member.tag}-th-${toLv}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                previousCheckAt: previousSnapshotAt,
                detectedAt: nowIso,
                lastConfirmedAt: nowIso,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: toLv,
                category: 'townhall',
                detailType: 'townhall',
                itemId: 'town_hall',
                apiName: 'Town Hall',
                itemNameRu: 'Ратуша',
                village: 'home',
                fromLevel: fromLv,
                toLevel: toLv,
                status: 'completed',
                source: 'coc_api',
              });
              pushClanEvent({
                id: `ce-${member.tag}-th-${toLv}-${Date.now()}`,
                dedupKey: `ce:${dedupKey}`,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'upgrade_townhall',
                title: `Повышение Ратуши TH${fromLv} → TH${toLv}`,
                description: `${profile.name} (${member.tag}) повысил уровень Ратуши с ${fromLv} до ${toLv}.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: toLv,
                previousValue: fromLv,
                newValue: toLv,
                deltaLabel: `+${toLv - fromLv}`,
                source: 'coc_api',
                read: false,
              });
            }

            // 1b. Town Hall Weapon level upgrade (TH12+)
            if (
              prevPlayer.playerDetailsLoaded !== false &&
              (profile.townHallWeaponLevel ?? 0) > 0 &&
              profile.townHallLevel === prevPlayer.townHallLevel &&
              (profile.townHallWeaponLevel ?? 0) > (prevPlayer.townHallWeaponLevel ?? 0)
            ) {
              const fromW = prevPlayer.townHallWeaponLevel ?? 0;
              const toW = profile.townHallWeaponLevel ?? 0;
              const dedupKey = `upg:${member.tag}:th_weapon:th${profile.townHallLevel}:${fromW}->${toW}`;
              pushUpgradeEvent({
                id: `sc-${member.tag}-thw-${toW}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                previousCheckAt: previousSnapshotAt,
                detectedAt: nowIso,
                lastConfirmedAt: nowIso,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                category: 'townhall',
                detailType: 'townhall',
                itemId: 'town_hall_weapon',
                apiName: `Town Hall Weapon (TH${profile.townHallLevel})`,
                itemNameRu: `Оружие Ратуши TH${profile.townHallLevel}`,
                village: 'home',
                fromLevel: fromW,
                toLevel: toW,
                status: 'completed',
                source: 'coc_api',
              });
              pushClanEvent({
                id: `ce-${member.tag}-thw-${toW}-${Date.now()}`,
                dedupKey: `ce:${dedupKey}`,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'upgrade_townhall',
                title: `Оружие Ратуши TH${profile.townHallLevel}: ${fromW} → ${toW}`,
                description: `${profile.name} улучшил оружие Ратуши с ${fromW} до ${toW} уровня.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: fromW,
                newValue: toW,
                deltaLabel: `+${toW - fromW}`,
                source: 'coc_api',
                read: false,
              });
            }

            // 1c. Builder Hall level upgrade (Builder Base)
            if (
              prevPlayer.playerDetailsLoaded !== false &&
              prevPlayer.builderHallLevel > 0 &&
              profile.builderHallLevel > prevPlayer.builderHallLevel
            ) {
              const fromBh = prevPlayer.builderHallLevel;
              const toBh = profile.builderHallLevel;
              const dedupKey = `upg:${member.tag}:builder_hall:${fromBh}->${toBh}`;
              pushUpgradeEvent({
                id: `sc-${member.tag}-bh-${toBh}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                previousCheckAt: previousSnapshotAt,
                detectedAt: nowIso,
                lastConfirmedAt: nowIso,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                category: 'townhall',
                detailType: 'townhall',
                itemId: 'builder_hall',
                apiName: 'Builder Hall',
                itemNameRu: 'Дом строителя',
                village: 'builderBase',
                fromLevel: fromBh,
                toLevel: toBh,
                status: 'completed',
                source: 'coc_api',
              });
            }

            // 2. Heroes, Equipment, Troops (incl. Super & Builder Base), Spells, Siege Machines, Pets
            const compareUnitLists = (
              prevList: OfficialUnitEntry[],
              curList: OfficialUnitEntry[],
              detailType: UpgradeDetailType,
              category: VillageCategory,
              clanEventType: ClanEventType,
              kindLabel: string
            ) => {
              if (prevPlayer.playerDetailsLoaded === false) return;
              const prevMap = new Map<string, number>();
              for (const u of prevList) {
                prevMap.set(`${u.name}::${u.village || 'home'}`, u.level);
              }
              for (const cur of curList) {
                const village = cur.village || 'home';
                const key = `${cur.name}::${village}`;
                const prevLv = prevMap.get(key);
                const isNewUnlock =
                  prevLv === undefined && prevPlayer.playerDetailsLoaded === true && cur.level > 0;
                const fromLv = prevLv ?? 0;
                if ((prevLv !== undefined && cur.level > prevLv) || isNewUnlock) {
                  const ruName = translateCocUnitNameRu(cur.name);
                  const isSuperTroop = Boolean(
                    cur.superTroopIsActive || cur.name.startsWith('Super ')
                  );
                  const dedupKey = `upg:${member.tag}:${detailType}:${cur.name}:${village}:${fromLv}->${cur.level}`;
                  pushUpgradeEvent({
                    id: `sc-${member.tag}-${detailType}-${cur.name}-${cur.level}-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                    dedupKey,
                    timestamp: nowIso,
                    previousSnapshotAt,
                    previousCheckAt: previousSnapshotAt,
                    detectedAt: nowIso,
                    lastConfirmedAt: nowIso,
                    playerTag: member.tag,
                    playerName: profile.name,
                    townHallLevel: profile.townHallLevel,
                    category,
                    detailType,
                    itemId: `${detailType}:${cur.name}`,
                    apiName: cur.name,
                    itemNameRu: ruName,
                    village,
                    isSuperTroop,
                    fromLevel: fromLv,
                    toLevel: cur.level,
                    status: 'completed',
                    source: 'coc_api',
                  });
                  pushClanEvent({
                    id: `ce-${member.tag}-${detailType}-${cur.name}-${cur.level}-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                    dedupKey: `ce:${dedupKey}`,
                    timestamp: nowIso,
                    previousSnapshotAt,
                    type: clanEventType,
                    title: `${kindLabel}: ${cur.name} (${fromLv} → ${cur.level})`,
                    description: `${profile.name} (TH${profile.townHallLevel}) улучшил ${cur.name} (${ruName}) с ${fromLv} до ${cur.level} уровня.`,
                    playerTag: member.tag,
                    playerName: profile.name,
                    townHallLevel: profile.townHallLevel,
                    previousValue: fromLv,
                    newValue: cur.level,
                    deltaLabel: `+${cur.level - fromLv}`,
                    source: 'coc_api',
                    read: false,
                  });
                }
              }
            };

            compareUnitLists(prevPlayer.apiHeroes, profile.apiHeroes, 'hero', 'heroes', 'upgrade_hero', 'Герой');
            compareUnitLists(
              prevPlayer.apiHeroEquipment,
              profile.apiHeroEquipment,
              'equipment',
              'heroes',
              'upgrade_equipment',
              'Оборудование'
            );
            compareUnitLists(prevPlayer.apiTroops, profile.apiTroops, 'troop', 'lab', 'upgrade_troop', 'Войско');
            compareUnitLists(prevPlayer.apiSpells, profile.apiSpells, 'spell', 'lab', 'upgrade_spell', 'Заклинание');
            compareUnitLists(
              prevPlayer.apiSiegeMachines,
              profile.apiSiegeMachines,
              'siege',
              'lab',
              'upgrade_siege',
              'Осадная машина'
            );
            compareUnitLists(prevPlayer.apiPets, profile.apiPets, 'pet', 'lab', 'upgrade_pet', 'Питомец');

            // 3. Experience Level (ClanEvent only, keep UpgradeEvent strictly for unit/hero/TH upgrades)
            if (prevPlayer.expLevel > 0 && profile.expLevel > prevPlayer.expLevel) {
              const dedupKey = `ce:exp:${member.tag}:${prevPlayer.expLevel}->${profile.expLevel}`;
              pushClanEvent({
                id: `ce-${member.tag}-exp-${profile.expLevel}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'progress_metric',
                title: `Опыт игрока: ур. ${prevPlayer.expLevel} → ${profile.expLevel}`,
                description: `${profile.name} повысил уровень опыта аккаунта до ${profile.expLevel}.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: prevPlayer.expLevel,
                newValue: profile.expLevel,
                deltaLabel: `+${profile.expLevel - prevPlayer.expLevel}`,
                source: 'coc_api',
                read: false,
              });
            }

            // 4. Significant Trophy Change (>= 20) (ClanEvent only)
            const trophyDiff = profile.trophies - prevPlayer.trophies;
            if (Math.abs(trophyDiff) >= 20) {
              const dedupKey = `ce:tr:${member.tag}:${prevPlayer.trophies}->${profile.trophies}`;
              pushClanEvent({
                id: `ce-${member.tag}-tr-${profile.trophies}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'progress_metric',
                title: `Трофеи: ${prevPlayer.trophies} → ${profile.trophies}`,
                description: `${profile.name}: изменение кубков ${trophyDiff > 0 ? `+${trophyDiff}` : trophyDiff} между проверками.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: prevPlayer.trophies,
                newValue: profile.trophies,
                deltaLabel: `${trophyDiff > 0 ? '+' : ''}${trophyDiff}`,
                source: 'coc_api',
                read: false,
              });
            }

            // 5. War Stars increase (ClanEvent only)
            if (prevPlayer.playerDetailsLoaded !== false && profile.warStars > prevPlayer.warStars) {
              const dedupKey = `ce:ws:${member.tag}:${prevPlayer.warStars}->${profile.warStars}`;
              pushClanEvent({
                id: `ce-${member.tag}-ws-${profile.warStars}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'progress_metric',
                title: `Звёзды войн: ${prevPlayer.warStars} → ${profile.warStars}★`,
                description: `${profile.name} заработал +${profile.warStars - prevPlayer.warStars}★ в войнах.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: prevPlayer.warStars,
                newValue: profile.warStars,
                deltaLabel: `+${profile.warStars - prevPlayer.warStars}★`,
                source: 'coc_api',
                read: false,
              });
            }

            // 6. Donations increase (ClanEvent only)
            if (profile.donations > prevPlayer.donations) {
              const donGain = profile.donations - prevPlayer.donations;
              const dedupKey = `ce:don:${member.tag}:${prevPlayer.donations}->${profile.donations}`;
              pushClanEvent({
                id: `ce-${member.tag}-don-${profile.donations}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'donations_change',
                title: `Пожертвования: +${donGain} войск`,
                description: `${profile.name} отправил войска (${prevPlayer.donations} → ${profile.donations}).`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: prevPlayer.donations,
                newValue: profile.donations,
                deltaLabel: `+${donGain}`,
                source: 'coc_api',
                read: false,
              });
            }

            // 7. Clan Capital Contributions increase (ClanEvent only)
            if (
              prevPlayer.playerDetailsLoaded !== false &&
              profile.clanCapitalContributions > prevPlayer.clanCapitalContributions
            ) {
              const capGain = profile.clanCapitalContributions - prevPlayer.clanCapitalContributions;
              const dedupKey = `ce:cap:${member.tag}:${prevPlayer.clanCapitalContributions}->${profile.clanCapitalContributions}`;
              pushClanEvent({
                id: `ce-${member.tag}-cap-${profile.clanCapitalContributions}-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'progress_metric',
                title: `Вклад в столицу: +${capGain.toLocaleString('ru-RU')}`,
                description: `${profile.name} внёс ${capGain.toLocaleString('ru-RU')} золота столицы.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: prevPlayer.clanCapitalContributions,
                newValue: profile.clanCapitalContributions,
                deltaLabel: `+${capGain}`,
                source: 'coc_api',
                read: false,
              });
            }

            // 8. Role change
            if (profile.role !== prevPlayer.role) {
              const dedupKey = `ce:role:${member.tag}:${prevPlayer.role}->${profile.role}:${previousSnapshotAt || 'init'}`;
              pushClanEvent({
                id: `ce-${member.tag}-role-${Date.now()}`,
                dedupKey,
                timestamp: nowIso,
                previousSnapshotAt,
                type: 'roster_role',
                title: `Смена роли: ${ROLE_LABELS_RU[prevPlayer.role]} → ${ROLE_LABELS_RU[profile.role]}`,
                description: `Участник ${profile.name} изменил звание в клане.`,
                playerTag: member.tag,
                playerName: profile.name,
                townHallLevel: profile.townHallLevel,
                previousValue: ROLE_LABELS_RU[prevPlayer.role],
                newValue: ROLE_LABELS_RU[profile.role],
                source: 'coc_api',
                read: false,
              });
            }
          }

          return profile;
        }

        // Fallback if single player request failed transiently (keep prior loaded details, update fresh member summary)
        const th = Math.max(1, Math.min(18, member.townHallLevel ?? prevPlayer?.townHallLevel ?? 15));
        const wallCap = getWallCapForTh(th);
        const items: VillageItemInstance[] = prevPlayer?.items ?? [];
        const walls = prevPlayer?.walls ?? { totalCount: 0, maxLevelForTh: wallCap.maxLevel, byLevel: {} };
        const progress = prevPlayer?.progress ?? calculatePlayerProgress(th, items, walls);
        return {
          tag: member.tag,
          name: member.name,
          role: member.role ?? prevPlayer?.role ?? 'member',
          townHallLevel: th,
          townHallWeaponLevel: prevPlayer?.townHallWeaponLevel,
          builderHallLevel: prevPlayer?.builderHallLevel ?? 0,
          expLevel: member.expLevel ?? prevPlayer?.expLevel ?? 0,
          trophies: member.trophies ?? prevPlayer?.trophies ?? 0,
          bestTrophies: prevPlayer?.bestTrophies ?? 0,
          builderBaseTrophies: member.builderBaseTrophies ?? prevPlayer?.builderBaseTrophies ?? 0,
          bestBuilderBaseTrophies: prevPlayer?.bestBuilderBaseTrophies ?? 0,
          warStars: prevPlayer?.warStars ?? 0,
          donations: member.donations ?? prevPlayer?.donations ?? 0,
          donationsReceived: member.donationsReceived ?? prevPlayer?.donationsReceived ?? 0,
          clanCapitalContributions: prevPlayer?.clanCapitalContributions ?? 0,
          warPreference: prevPlayer?.warPreference,
          clanRank: member.clanRank,
          previousClanRank: member.previousClanRank,
          league: member.league?.name
            ? {
                id: member.league.id,
                name: member.league.name,
                iconUrl: member.league.iconUrls?.medium || member.league.iconUrls?.small,
              }
            : prevPlayer?.league,
          builderBaseLeague: prevPlayer?.builderBaseLeague,
          clanRef: prevPlayer?.clanRef,
          apiHeroes: prevPlayer?.apiHeroes ?? [],
          apiHeroEquipment: prevPlayer?.apiHeroEquipment ?? [],
          apiTroops: prevPlayer?.apiTroops ?? [],
          apiSpells: prevPlayer?.apiSpells ?? [],
          apiSiegeMachines: prevPlayer?.apiSiegeMachines ?? [],
          apiPets: prevPlayer?.apiPets ?? [],
          achievements: prevPlayer?.achievements ?? [],
          labels: prevPlayer?.labels,
          legendStatistics: prevPlayer?.legendStatistics,
          lastSyncedAt: prevPlayer?.lastSyncedAt ?? nowIso,
          items,
          walls,
          activeBuilders: prevPlayer?.activeBuilders ?? [],
          progress,
          combat: prevPlayer?.combat ?? {
            attacksWon: 0,
            defensesWon: 0,
            warAttacksUsed: wAgg?.attacks ?? 0,
            warStarsEarned: wAgg?.stars ?? 0,
            warThreeStars: wAgg?.threeStars ?? 0,
            warAvgDestruction: 0,
            warDefensesFaced: wAgg?.defensesFaced ?? 0,
            warStarsConceded: wAgg?.starsConceded ?? 0,
            warDefenseHoldRate: 0,
          },
          buildingsVerified: Boolean(prevPlayer?.buildingsVerified),
          playerDetailsLoaded: Boolean(prevPlayer?.playerDetailsLoaded),
          lastJsonImportAt: prevPlayer?.lastJsonImportAt,
          jsonVillage: prevPlayer?.jsonVillage,
        } as PlayerProfile;
      })
    );
    players.push(...batchPlayers);
    checkedMembers += batchPlayers.length;
    onProgress?.({
      stage: 'checking_members',
      statusText: `Проверка участников: ${checkedMembers} из ${memberList.length}`,
      checkedMembers,
      totalMembers: memberList.length,
      upgradesFound: newEvents.length,
      errorsCount,
    });
  }

  // Detect Clan Capital Hall & District Hall upgrades (never attributed to a specific player)
  if (isSameClan && existingClan) {
    if (
      (existingClan.capitalHallLevel ?? 0) > 0 &&
      (clan.capitalHallLevel ?? 0) > (existingClan.capitalHallLevel ?? 0)
    ) {
      const fromCh = existingClan.capitalHallLevel ?? 0;
      const toCh = clan.capitalHallLevel ?? 0;
      const dedupKey = `upg:capital:${clan.tag}:capital_hall:${fromCh}->${toCh}`;
      pushUpgradeEvent({
        id: `sc-${clan.tag}-ch-${toCh}-${Date.now()}`,
        dedupKey,
        timestamp: nowIso,
        previousSnapshotAt,
        previousCheckAt: previousSnapshotAt,
        detectedAt: nowIso,
        lastConfirmedAt: nowIso,
        playerTag: clan.tag,
        playerName: `Клан ${clan.name}`,
        townHallLevel: toCh,
        category: 'townhall',
        detailType: 'capital',
        itemId: 'capital_hall',
        apiName: 'Capital Hall',
        itemNameRu: 'Ратуша столицы клана',
        village: 'clanCapital',
        fromLevel: fromCh,
        toLevel: toCh,
        status: 'completed',
        source: 'coc_api',
      });
    }

    const prevDistricts = new Map<number, number>();
    for (const d of existingClan.capitalDistricts ?? []) {
      prevDistricts.set(d.id, d.districtHallLevel);
    }
    for (const d of clan.capitalDistricts ?? []) {
      const prevLv = prevDistricts.get(d.id);
      if (prevLv !== undefined && d.districtHallLevel > prevLv) {
        const dedupKey = `upg:capital:${clan.tag}:district_${d.id}:${prevLv}->${d.districtHallLevel}`;
        pushUpgradeEvent({
          id: `sc-${clan.tag}-dist-${d.id}-${d.districtHallLevel}-${Date.now()}`,
          dedupKey,
          timestamp: nowIso,
          previousSnapshotAt,
          previousCheckAt: previousSnapshotAt,
          detectedAt: nowIso,
          lastConfirmedAt: nowIso,
          playerTag: clan.tag,
          playerName: `Клан ${clan.name}`,
          townHallLevel: d.districtHallLevel,
          category: 'townhall',
          detailType: 'capital',
          itemId: `capital_district:${d.id}`,
          apiName: d.name,
          itemNameRu: d.name,
          village: 'clanCapital',
          fromLevel: prevLv,
          toLevel: d.districtHallLevel,
          status: 'completed',
          source: 'coc_api',
        });
      }
    }
  }

  // Detect Clan Roster Joins / Leaves and New Finished Wars
  if (isSameClan && existingPlayersByTag.size > 0) {
    const currentTags = new Set(players.map((p) => p.tag));
    for (const p of players) {
      if (!existingPlayersByTag.has(p.tag)) {
        pushClanEvent({
          id: `ce-join-${p.tag}-${Date.now()}`,
          dedupKey: `ce:join:${p.tag}:${previousSnapshotAt || 'init'}`,
          timestamp: nowIso,
          previousSnapshotAt,
          type: 'roster_join',
          title: `Новый участник: ${p.name} (TH${p.townHallLevel})`,
          description: `Игрок ${p.name} (${p.tag}) вступил в клан.`,
          playerTag: p.tag,
          playerName: p.name,
          townHallLevel: p.townHallLevel,
          source: 'coc_api',
          read: false,
        });
      }
    }
    for (const [prevTag, prevP] of existingPlayersByTag.entries()) {
      if (!currentTags.has(prevTag)) {
        pushClanEvent({
          id: `ce-leave-${prevTag}-${Date.now()}`,
          dedupKey: `ce:leave:${prevTag}:${previousSnapshotAt || 'init'}`,
          timestamp: nowIso,
          previousSnapshotAt,
          type: 'roster_leave',
          title: `Покинул клан: ${prevP.name} (TH${prevP.townHallLevel})`,
          description: `Игрок ${prevP.name} (${prevP.tag}) вышел из состава клана.`,
          playerTag: prevP.tag,
          playerName: prevP.name,
          townHallLevel: prevP.townHallLevel,
          source: 'coc_api',
          read: false,
        });
      }
    }
  }

  if (isSameClan && existingWars.length > 0 && wars.length > 0) {
    const prevWarKeys = new Set(existingWars.map((w) => `${w.endTimeIso ?? w.date}:${w.opponentTag}`));
    for (const w of wars) {
      const wk = `${w.endTimeIso ?? w.date}:${w.opponentTag}`;
      if (!prevWarKeys.has(wk)) {
        const resRu = w.result === 'win' ? 'Победа' : w.result === 'loss' ? 'Поражение' : 'Ничья';
        pushClanEvent({
          id: `ce-war-${w.opponentTag}-${Date.now()}`,
          dedupKey: `ce:war:${wk}`,
          timestamp: nowIso,
          previousSnapshotAt,
          type: 'war_result',
          title: `Завершена КВ vs ${w.opponentName}: ${resRu}`,
          description: `Счёт ${w.clanStars}:${w.opponentStars}★ (${w.clanDestruction}% vs ${w.opponentDestruction}%), формат ${w.teamSize}×${w.teamSize}.`,
          previousValue: `${w.opponentStars}★`,
          newValue: `${w.clanStars}★`,
          deltaLabel: resRu,
          source: 'coc_api',
          read: false,
        });
      }
    }
  }

  // Merge real events (strictly for this clan, keep up to 5000 historical upgrade events)
  const events = [...newEvents, ...priorUpgradeEvents].slice(0, 5000);
  const clanEvents = [...newClanEvents, ...priorClanEvents].slice(0, 1000);

  // Build real HistoryPoint for today
  const todayIso = nowIso.slice(0, 10);
  const dObj = new Date(`${todayIso}T00:00:00Z`);
  const todayLabel = `${dObj.getUTCDate()} ${monthNames[dObj.getUTCMonth()]}`;
  const pCount = Math.max(1, players.length);
  const avgFn = (fn: (p: PlayerProfile) => number) =>
    Number((players.reduce((s, p) => s + fn(p), 0) / pCount).toFixed(1));

  const byTownHall: Record<number, number> = {};
  const thBuckets: Record<number, number[]> = {};
  const byPlayer: Record<string, number> = {};
  for (const p of players) {
    byPlayer[p.tag] = p.progress.overallPct;
    if (!thBuckets[p.townHallLevel]) thBuckets[p.townHallLevel] = [];
    thBuckets[p.townHallLevel].push(p.progress.overallPct);
  }
  for (const [thStr, arr] of Object.entries(thBuckets)) {
    byTownHall[Number(thStr)] = Number((arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(1));
  }

  const todayEvents = events.filter((e) => e.timestamp.slice(0, 10) === todayIso);
  const byCat: Record<VillageCategory | 'townhall', number> = {
    defenses: 0,
    heroes: 0,
    lab: 0,
    traps: 0,
    resources: 0,
    walls: 0,
    townhall: 0,
  };
  for (const ev of todayEvents) {
    byCat[ev.category] = (byCat[ev.category] ?? 0) + 1;
  }

  const todayPoint: HistoryPoint = {
    date: todayIso,
    label: todayLabel,
    clanAvgPct: avgFn((p) => p.progress.overallPct),
    clanDefensesPct: avgFn((p) => p.progress.defensesPct),
    clanHeroesPct: avgFn((p) => p.progress.heroesPct),
    clanLabPct: avgFn((p) => p.progress.labPct),
    clanWallsPct: avgFn((p) => p.progress.wallsPct),
    byTownHall,
    byPlayer,
    upgradesCount: todayEvents.length,
    upgradesByCategory: byCat,
  };

  const baseHistory = isSameClan ? [...existingHistory] : [];
  const idx = baseHistory.findIndex((h) => h.date === todayIso);
  if (idx >= 0) {
    baseHistory[idx] = todayPoint;
  } else {
    baseHistory.push(todayPoint);
  }
  const trimmedHistory = baseHistory.slice(-180);

  // Create real Snapshot entry (never fabricated before first sync)
  const totalTrophies = players.reduce((s, p) => s + p.trophies, 0);
  const totalDonations = players.reduce((s, p) => s + p.donations, 0);
  const totalDonationsReceived = players.reduce((s, p) => s + p.donationsReceived, 0);
  const avgTownHall = Number((players.reduce((s, p) => s + p.townHallLevel, 0) / pCount).toFixed(2));
  const avgBaseProgressPct = avgFn((p) => p.progress.overallPct);

  const byPlayerSnap: ClanSnapshot['byPlayer'] = {};
  for (const p of players) {
    byPlayerSnap[p.tag] = buildSnapshotPlayerEntry(p);
  }

  const newSnapshot: ClanSnapshot = {
    id: `snap-${Date.now()}`,
    timestamp: nowIso,
    memberCount: clan.membersCount,
    clanPoints: clan.clanPoints,
    clanBuilderBasePoints: clan.clanBuilderBasePoints ?? 0,
    clanCapitalPoints: clan.clanCapitalPoints,
    totalTrophies,
    totalDonations,
    totalDonationsReceived,
    warWins: clan.warWins,
    warLosses: clan.warLosses ?? 0,
    warTies: clan.warTies ?? 0,
    warWinStreak: clan.warWinStreak,
    avgTownHall,
    avgBaseProgressPct,
    byPlayer: byPlayerSnap,
  };

  const baseSnapshots = isSameClan ? [...existingSnapshots] : [];
  baseSnapshots.push(newSnapshot);
  const trimmedSnapshots = baseSnapshots.slice(-1000);

  // Compute & save player composite scores in the snapshot for historical rating tracking
  const tempState = {
    clan,
    players,
    events,
    activeUpgrades: [],
    clanEvents,
    history: trimmedHistory,
    snapshots: trimmedSnapshots,
    wars,
    currentWar,
    cwl,
    capitalRaids,
    clanStats: computeClanAggregateStats(players, wars),
    thGroups: groupPlayersByTownHall(players, events),
    hasApiToken: true,
    syncConfig: {
      autoSyncEnabled: true,
      intervalMinutes: 360,
      lastSyncAt: nowIso,
      lastSyncStatus: 'ok' as const,
      lastSyncError: null,
    },
  };
  const computedRatings = computeClanPlayerRatings(tempState, Date.now());
  for (const r of computedRatings) {
    if (newSnapshot.byPlayer[r.player.tag]) {
      newSnapshot.byPlayer[r.player.tag].compositeScore = r.totalScore;
    }
  }

  onProgress?.({
    stage: 'finalizing',
    statusText: 'Сохранение журнала улучшений и обновление данных...',
    checkedMembers,
    totalMembers: memberList.length,
    upgradesFound: newEvents.length,
    errorsCount,
  });

  return {
    clan,
    players,
    wars,
    currentWar,
    cwl,
    capitalRaids,
    events,
    newUpgrades: newEvents,
    clanEvents,
    history: trimmedHistory,
    snapshots: trimmedSnapshots,
    checkedMembers,
    totalMembers: memberList.length,
    errorsCount,
  };
}
