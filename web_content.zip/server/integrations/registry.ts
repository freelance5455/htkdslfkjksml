import type { IntegrationPluginInfo } from '../../src/lib/jarvisTypes';

export interface IntegrationPlugin {
  info: IntegrationPluginInfo;
  requiresConfirmation?: boolean;
  requiresPermission?: boolean;
  // Future tool execution hook for Android/Desktop/External services
  executeAction?: (action: string, payload: Record<string, unknown>) => Promise<unknown>;
}

class IntegrationRegistry {
  private plugins = new Map<string, IntegrationPlugin>();

  register(plugin: IntegrationPlugin): void {
    this.plugins.set(plugin.info.id, plugin);
  }

  list(): IntegrationPluginInfo[] {
    return Array.from(this.plugins.values()).map((p) => p.info);
  }

  get(id: string): IntegrationPlugin | undefined {
    return this.plugins.get(id);
  }
}

export const integrationRegistry = new IntegrationRegistry();

integrationRegistry.register({
  requiresPermission: true,
  info: {
    id: 'files-context',
    name: 'Local File & Code Context',
    category: 'files',
    description:
      'Attach text, markdown, JSON, or source code files directly into conversations for analysis, debugging, or planning. Consequential file writes/deletes always require confirmation.',
    status: 'active',
    capabilities: ['Code Review', 'Document Summary', 'Zero-Upload Browser Read'],
  },
});

integrationRegistry.register({
  requiresPermission: true,
  requiresConfirmation: true,
  info: {
    id: 'android-companion',
    name: 'Android Apps, Reminders & Smart Devices',
    category: 'android',
    description:
      'Modular action contract prepared for Android app intents, reminders, smart device controls, and quick-capture widgets with explicit permission and confirmation.',
    status: 'ready',
    capabilities: ['App Intents', 'Reminders', 'Smart Devices'],
  },
});

integrationRegistry.register({
  requiresPermission: true,
  requiresConfirmation: true,
  info: {
    id: 'computer-tools',
    name: 'Browser & Computer Tools',
    category: 'computer',
    description:
      'Extensible sandboxed tool-calling interface prepared for browser automation, terminal scripts, and desktop workspace tools.',
    status: 'ready',
    capabilities: ['Browser Actions', 'Sandboxed Tools', 'Task Runners'],
  },
});

integrationRegistry.register({
  requiresPermission: true,
  requiresConfirmation: true,
  info: {
    id: 'external-services',
    name: 'Calendar & External APIs',
    category: 'services',
    description:
      'Expandable plugin slot for authorized Google Calendar sync, messaging, issue trackers, and custom REST webhooks with pre-send confirmation.',
    status: 'planned',
    capabilities: ['Calendar Sync', 'External APIs', 'Confirmation Guard'],
  },
});
