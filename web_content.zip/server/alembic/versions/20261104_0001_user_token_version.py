"""Ajoute le compteur de révocation des jetons utilisateur.

Migration tolérante aux bases du prototype : si la colonne existe déjà, elle n'est
pas recréée. Les tables historiques restent intactes.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect
from app.database import Base
from app import models  # noqa: F401 — enregistre les modèles

revision = "20261104_0001"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    # Baseline : crée les tables absentes sur une installation neuve sans toucher aux tables existantes.
    Base.metadata.create_all(bind=bind)
    inspector = inspect(bind)
    if "users" in inspector.get_table_names():
        columns = {c["name"] for c in inspector.get_columns("users")}
        if "token_version" not in columns:
            op.add_column("users", sa.Column("token_version", sa.Integer(), nullable=False, server_default="0"))

def downgrade():
    bind = op.get_bind()
    # Baseline : crée les tables absentes sur une installation neuve sans toucher aux tables existantes.
    Base.metadata.create_all(bind=bind)
    inspector = inspect(bind)
    if "users" in inspector.get_table_names():
        columns = {c["name"] for c in inspector.get_columns("users")}
        if "token_version" in columns:
            op.drop_column("users", "token_version")
