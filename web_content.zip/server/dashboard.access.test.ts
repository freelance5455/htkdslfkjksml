import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function contextFor(user: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

const trainee = {
  id: 2,
  openId: "trainee-open-id",
  email: "trainee@example.com",
  name: "Trainee User",
  loginMethod: "manus",
  role: "trainee" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

describe("dashboard access control", () => {
  it("requires authentication for the overview", async () => {
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.dashboard.overview()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires authentication to update a profile name", async () => {
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.dashboard.updateMyName({ name: "Updated Name" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("does not allow trainees to change roles", async () => {
    const caller = appRouter.createCaller(contextFor(trainee));
    await expect(caller.dashboard.updateUserRole({ userId: 3, role: "technician" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("does not allow trainees to create workspace accounts", async () => {
    const caller = appRouter.createCaller(contextFor(trainee));
    await expect(caller.dashboard.createAccount({ username: "Kristoffer liedtke ✔", name: "New teammate", email: "new@example.com", password: "temporary-pass-123", role: "technician" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("does not allow trainees to create schedules", async () => {
    const caller = appRouter.createCaller(contextFor(trainee));
    await expect(caller.dashboard.createSchedule({
      title: "Field shift",
      location: "Workshop",
      shift: "09:00 — 17:00",
      startAt: "2026-09-08T09:00:00.000Z",
      endAt: "2026-09-08T17:00:00.000Z",
      assigneeAccountId: 1,
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
