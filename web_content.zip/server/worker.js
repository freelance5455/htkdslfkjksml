// Detox relay: a tiny Cloudflare Worker that lets two guardians press Lapse / Relapse for you.
// Setup: create a Worker, paste this whole file in, add a KV namespace binding named DETOX, deploy.
// Your phone talks to it; guardians just open a private link in their browser (no app needed).

const HABITS = { scroll: 'NoScroll', fap: 'NoFap', booze: 'NoBooze', drugs: 'Drug free' };
const HEAD = {
  'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type',
  'access-control-allow-methods': 'GET,POST,OPTIONS', 'cache-control': 'no-store'
};
const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...HEAD, 'content-type': 'application/json; charset=utf-8' } });
const rnd = (n) => {
  const a = crypto.getRandomValues(new Uint8Array(n));
  return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};
const sha = async (t) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map((x) => x.toString(16).padStart(2, '0')).join('');
const clean = (s, n = 24) => String(s || '').replace(/[<>&"'`]/g, '').trim().slice(0, n);
const num = (v) => (Number.isFinite(+v) ? +v : 0);

const getA = async (env, id) => { const r = id ? await env.DETOX.get('a:' + id) : null; return r ? JSON.parse(r) : null; };
const putA = (env, a) => env.DETOX.put('a:' + a.id, JSON.stringify(a));
async function asOwner(env, id, key) {
  const a = key ? await getA(env, id) : null;
  return a && a.kh === (await sha(String(key))) ? a : null;
}
async function asGuardian(env, token) {
  const t = token ? await env.DETOX.get('t:' + token) : null;
  if (!t) return null;
  const { id, slot } = JSON.parse(t), a = await getA(env, id);
  if (!a || !a.g[slot] || a.g[slot].token !== token) return null;
  return { a, slot, g: a.g[slot] };
}

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: HEAD });
    if (!env.DETOX) return J({ error: 'Add a KV namespace binding named DETOX to this Worker.' }, 500);
    const u = new URL(req.url), p = u.pathname, post = req.method === 'POST';
    let b = {};
    if (post) { try { b = await req.json(); } catch { return J({ error: 'bad json' }, 400); } }
    const now = Date.now();
    try {
      if (p === '/api/ping') return J({ ok: true, name: 'detox-relay', v: 1 });

      if (p === '/api/register' && post) {
        const id = rnd(9), key = rnd(24);
        await putA(env, { id, kh: await sha(key), habit: clean(b.habit, 8), owner: clean(b.owner), lastAt: 0, balls: 0, best: 0, seq: 0, g: [null, null], ev: [], created: now });
        return J({ id, key });
      }

      if (p === '/api/invite' && post) {
        const a = await asOwner(env, b.id, b.key); if (!a) return J({ error: 'unauthorised' }, 401);
        const slot = +b.slot; if (slot !== 0 && slot !== 1) return J({ error: 'bad slot' }, 400);
        const name = clean(b.name); if (!name) return J({ error: 'name needed' }, 400);
        if (a.g[slot]) await env.DETOX.delete('t:' + a.g[slot].token);
        const token = rnd(18);
        a.g[slot] = { name, token, seen: 0, last: 0, created: now };
        if (b.owner) a.owner = clean(b.owner);
        await env.DETOX.put('t:' + token, JSON.stringify({ id: a.id, slot }));
        await putA(env, a);
        return J({ token, url: u.origin + '/g/' + token });
      }

      if (p === '/api/revoke' && post) {
        const a = await asOwner(env, b.id, b.key); if (!a) return J({ error: 'unauthorised' }, 401);
        const slot = +b.slot;
        if (a.g[slot]) { await env.DETOX.delete('t:' + a.g[slot].token); a.g[slot] = null; await putA(env, a); }
        return J({ ok: true });
      }

      if (p === '/api/state' && post) {
        const a = await asOwner(env, b.id, b.key); if (!a) return J({ error: 'unauthorised' }, 401);
        Object.assign(a, { habit: clean(b.habit, 8), owner: clean(b.owner), lastAt: num(b.lastAt), balls: num(b.balls), best: num(b.best) });
        await putA(env, a);
        return J({ ok: true });
      }

      if (p === '/api/poll') {
        const a = await asOwner(env, u.searchParams.get('id'), u.searchParams.get('key')); if (!a) return J({ error: 'unauthorised' }, 401);
        const after = num(u.searchParams.get('after'));
        return J({
          events: a.ev.filter((e) => e.seq > after).map(({ seq, id, kind, at, by }) => ({ seq, id, kind, at, by })),
          guardians: a.g.map((g, slot) => (g ? { slot, name: g.name, seen: g.seen } : null)).filter(Boolean)
        });
      }

      let m = p.match(/^\/api\/g\/([\w-]+)$/);
      if (m) {
        const r = await asGuardian(env, m[1]); if (!r) return J({ error: 'This link is no longer active.' }, 404);
        if (now - r.g.seen > 60000) { r.g.seen = now; await putA(env, r.a); }
        return J({ owner: r.a.owner || '', habit: HABITS[r.a.habit] || 'Detox', lastAt: r.a.lastAt, balls: r.a.balls, best: r.a.best, guardian: r.g.name, now });
      }

      m = p.match(/^\/api\/g\/([\w-]+)\/event$/);
      if (m && post) {
        const r = await asGuardian(env, m[1]); if (!r) return J({ error: 'This link is no longer active.' }, 404);
        if (b.kind !== 'y' && b.kind !== 'p') return J({ error: 'bad kind' }, 400);
        if (now - r.g.last < 20000) return J({ error: 'Slow down a moment, you just sent one.' }, 429);
        r.g.last = now; r.g.seen = now;
        r.a.seq += 1;
        r.a.ev.push({ seq: r.a.seq, id: rnd(6), kind: b.kind, at: now, by: r.g.name, slot: r.slot });
        if (r.a.ev.length > 100) r.a.ev.splice(0, r.a.ev.length - 100);
        r.a.lastAt = now;
        await putA(env, r.a);
        return J({ ok: true, at: now });
      }

      m = p.match(/^\/g\/([\w-]+)$/);
      if (m) return new Response(PAGE, { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex' } });

      return J({ error: 'not found' }, 404);
    } catch (e) {
      return J({ error: 'server error' }, 500);
    }
  }
};

const PAGE = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>Detox guardian</title><style>
*{box-sizing:border-box;margin:0}body{min-height:100vh;font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#f6f8ff;
background:radial-gradient(120% 70% at 50% -5%,#22308a,#0e1646 40%,#04061a);display:flex;justify-content:center;padding:28px 20px}
main{width:100%;max-width:420px;text-align:center}h1{font-weight:300;font-size:30px;letter-spacing:-.02em;margin:26px 0 6px}
h1 em{font-style:italic;background:linear-gradient(120deg,#9fd0ff,#c09bff);-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{color:#aab6e6;font-size:15px}.clock{display:flex;justify-content:center;gap:12px;margin:30px 0 8px}
.clock div{min-width:64px;padding:14px 6px;border-radius:20px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.13)}
.clock b{display:block;font-weight:300;font-size:32px;font-variant-numeric:tabular-nums}.clock i{font-style:normal;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8190c8}
.meta{color:#8190c8;font-size:13.5px;margin-bottom:34px}.btns{display:flex;gap:16px}.b{flex:1;padding:18px 8px 16px;border-radius:26px;border:1px solid rgba(255,255,255,.14);
background:rgba(255,255,255,.06);color:#fff;font:inherit;cursor:pointer}.b i{display:block;width:62px;height:62px;border-radius:50%;margin:0 auto 10px}
.y i{background:radial-gradient(circle at 34% 28%,#fff0a8,#ffc933 55%,#e58a06);box-shadow:0 14px 26px -10px rgba(255,190,40,.9)}
.p i{background:radial-gradient(circle at 34% 28%,#dcc3ff,#9b5cff 55%,#5a22c8);box-shadow:0 14px 26px -10px rgba(155,92,255,.9)}
.b b{display:block;font-size:16px}.b span{font-size:12px;color:#aab6e6}.b:active{transform:scale(.97)}.b:disabled{opacity:.45}
.note{margin-top:26px;color:#8190c8;font-size:13px}#msg{margin-top:20px;min-height:24px;color:#9fd0ff;font-size:15px}.err{color:#ff9db0!important}
.sheet{position:fixed;inset:0;background:rgba(2,4,16,.7);display:none;align-items:flex-end;justify-content:center;padding:16px}.sheet.on{display:flex}
.card{width:100%;max-width:420px;background:#12184a;border:1px solid rgba(255,255,255,.14);border-radius:28px;padding:24px 22px}
.card h2{font-weight:600;font-size:21px;margin-bottom:8px}.card p{color:#aab6e6;margin-bottom:18px;font-size:15px}
.go,.no{display:block;width:100%;padding:15px;border-radius:26px;border:0;font:600 16px system-ui;color:#fff;margin-top:10px;cursor:pointer}
.go{background:linear-gradient(135deg,#4f86ff,#8a5cff)}.no{background:rgba(255,255,255,.1)}
</style></head><body><main id="m"><p class="sub" style="margin-top:40vh">Loading...</p></main>
<div class="sheet" id="sh"><div class="card"><h2 id="sht"></h2><p id="shp"></p><button class="go" id="ok">Yes, send it</button><button class="no" id="no">Cancel</button></div></div>
<script>
const T=location.pathname.split('/').pop(),m=document.getElementById('m'),sh=document.getElementById('sh');let D=null,off=0,pick=null;
const $=s=>document.querySelector(s),pad=n=>String(n).padStart(2,'0');
function tick(){if(!D||!D.lastAt)return;let t=Math.max(0,Math.floor((Date.now()+off-D.lastAt)/1000));$('#d').textContent=Math.floor(t/86400);$('#h').textContent=pad(Math.floor(t%86400/3600));$('#mi').textContent=pad(Math.floor(t%3600/60));$('#s').textContent=pad(t%60)}
function draw(){const who=D.owner||'your friend';m.innerHTML='<h1>You are <em></em>\\'s guardian</h1><p class="sub"></p><div class="clock"><div><b id="d">0</b><i>days</i></div><div><b id="h">00</b><i>hrs</i></div><div><b id="mi">00</b><i>min</i></div><div><b id="s">00</b><i>sec</i></div></div><p class="meta"></p><div class="btns"><button class="b y" data-k="y"><i></i><b>Lapse</b><span>A slip</span></button><button class="b p" data-k="p"><i></i><b>Relapse</b><span>They fell back</span></button></div><p id="msg"></p><p class="note">Only use these if they cannot do it themselves. You can never mark a day as passed. Be kind: this is someone trusting you.</p>';
m.querySelector('em').textContent=who;m.querySelector('.sub').textContent='Hi '+D.guardian+'. Here is how long '+who+' has gone with '+D.habit+'.';
m.querySelector('.meta').textContent=D.balls+' balls in their pit \\u00b7 best streak '+D.best+' days';
m.querySelectorAll('.b').forEach(b=>b.onclick=()=>ask(b.dataset.k));tick()}
function ask(k){pick=k;$('#sht').textContent=k==='y'?'Mark a lapse?':'Mark a relapse?';$('#shp').textContent=(k==='y'?'A lapse restarts their timer and gives them a couple of yellow balls.':'A relapse restarts their timer and removes one ball from their pit.')+' They will see it was you.';sh.classList.add('on')}
$('#no').onclick=()=>sh.classList.remove('on');
$('#ok').onclick=async()=>{sh.classList.remove('on');const msg=$('#msg');msg.className='';msg.textContent='Sending...';
try{const r=await fetch('/api/g/'+T+'/event',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:pick})});const j=await r.json();
if(!r.ok)throw new Error(j.error||'Failed');msg.textContent='Sent. They will see it when Detox next checks in.';D.lastAt=j.at}catch(e){msg.className='err';msg.textContent=e.message}};
fetch('/api/g/'+T).then(async r=>{const j=await r.json();if(!r.ok)throw new Error(j.error);D=j;off=j.now-Date.now();draw();setInterval(tick,500)})
.catch(e=>{m.innerHTML='<h1>Link <em>unavailable</em></h1><p class="sub"></p>';m.querySelector('.sub').textContent=e.message||'Something went wrong.'});
</script></body></html>`;
