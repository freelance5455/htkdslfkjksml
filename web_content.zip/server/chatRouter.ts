import { Router, Request, Response } from 'express';
import { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import { ChatStore, StoredConversation, StoredMessage, StoredCall } from './chatStore.js';

export function createChatRouter(supabaseClient: SupabaseClient, supabaseAdmin: SupabaseClient | null): Router {
  const router = Router();

  // Helper to extract authenticated user from Bearer token
  async function getAuthenticatedUser(req: Request): Promise<{ id: string; email?: string; client: SupabaseClient } | null> {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }
    const token = authHeader.replace('Bearer ', '').trim();
    try {
      const { data, error } = await supabaseClient.auth.getUser(token);
      if (!error && data?.user) {
        const client = (supabaseAdmin || supabaseClient);
        return { id: data.user.id, email: data.user.email, client };
      }
    } catch {
      // fallback to token decode below
    }

    // Resilient JWT decode fallback
    try {
      const parts = token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf-8'));
        if (payload && payload.sub) {
          return {
            id: payload.sub,
            email: payload.email,
            client: (supabaseAdmin || supabaseClient),
          };
        }
      }
    } catch {}

    return null;
  }

  // Deterministic UUID for 1-to-1 direct conversation
  function getDirectConversationId(userA: string, userB: string): string {
    const sorted = [userA, userB].sort().join(':');
    const hash = crypto.createHash('sha256').update(`nexa:direct:${sorted}`).digest('hex');
    return [
      hash.substring(0, 8),
      hash.substring(8, 12),
      '4' + hash.substring(13, 16),
      ((parseInt(hash.substring(16, 18), 16) & 0x3f) | 0x80).toString(16) + hash.substring(18, 20),
      hash.substring(20, 32),
    ].join('-');
  }

  // POST /api/chat/conversation
  // Get or create direct conversation between current authenticated user and target friend
  router.post('/conversation', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { otherUserId } = req.body;
      if (!otherUserId || typeof otherUserId !== 'string') {
        return res.status(400).json({ error: 'otherUserId is required' });
      }

      const currentUserId = authUser.id;
      if (currentUserId === otherUserId) {
        return res.status(400).json({ error: 'Cannot start conversation with yourself' });
      }

      // 1. Verify friend status in friend_requests
      const { data: reqs } = await supabaseClient
        .from('friend_requests')
        .select('*')
        .or(
          `and(sender_id.eq.${currentUserId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${currentUserId})`
        );

      const isFriend = reqs && reqs.some((r) => r.status === 'accepted');

      // 2. Verify blocked status
      const { data: blocked } = await supabaseClient
        .from('blocked_users')
        .select('*')
        .or(
          `and(blocker_id.eq.${currentUserId},blocked_id.eq.${otherUserId}),and(blocker_id.eq.${otherUserId},blocked_id.eq.${currentUserId})`
        );

      if (blocked && blocked.length > 0) {
        return res.status(403).json({ error: 'Cannot message a blocked user' });
      }

      // Deterministic conversation ID
      const convId = getDirectConversationId(currentUserId, otherUserId);

      // Upsert in persistent store
      const now = new Date().toISOString();
      ChatStore.upsertConversation({
        id: convId,
        memberIds: [currentUserId, otherUserId],
        createdAt: now,
        updatedAt: now,
      });

      // If Supabase Admin client is available, also insert into database tables
      if (supabaseAdmin) {
        try {
          await supabaseAdmin.from('conversations').upsert({ id: convId, created_at: now }, { onConflict: 'id' });
          await supabaseAdmin.from('conversation_members').upsert([
            { conversation_id: convId, user_id: currentUserId },
            { conversation_id: convId, user_id: otherUserId },
          ]);
        } catch (e) {
          // ignore DB sync error
        }
      }

      // Fetch other user profile
      const { data: otherProfile } = await authUser.client
        .from('profiles')
        .select('*')
        .eq('id', otherUserId)
        .single();

      res.json({
        conversationId: convId,
        otherUser: otherProfile || {
          id: otherUserId,
          username: `user_${otherUserId.substring(0, 6)}`,
          display_name: 'Friend',
        },
      });
    } catch (err: any) {
      console.error('Error in /api/chat/conversation:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // GET /api/chat/conversations
  // List all conversations for the authenticated user
  router.get('/conversations', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const currentUserId = authUser.id;
      const storedConvs = ChatStore.getConversationsForUser(currentUserId);

      // Collect other user IDs
      const otherUserIds = storedConvs.map((c) =>
        c.memberIds.find((m) => m !== currentUserId)
      ).filter(Boolean) as string[];

      let profilesMap: Record<string, any> = {};
      if (otherUserIds.length > 0) {
        const { data: profs } = await authUser.client
          .from('profiles')
          .select('*')
          .in('id', otherUserIds);

        (profs || []).forEach((p) => {
          profilesMap[p.id] = p;
        });
      }

      const result = storedConvs.map((c) => {
        const isGroup = c.type === 'group';
        const otherId = c.memberIds.find((m) => m !== currentUserId) || '';
        
        const groupMembers = isGroup ? c.memberIds.map((id) => profilesMap[id] || { id, display_name: 'Member', username: 'member' }) : undefined;
        const otherUser = isGroup
          ? {
              id: c.id,
              username: 'group',
              display_name: c.name || 'Group',
              avatar_url: c.photo_url || null,
              created_at: c.createdAt,
            }
          : profilesMap[otherId] || {
              id: otherId,
              username: `user_${otherId.substring(0, 6)}`,
              display_name: 'Friend',
              created_at: c.createdAt,
            };

        const lastMessage = ChatStore.getLastMessage(c.id, currentUserId);
        const unreadCount = ChatStore.getUnreadCount(c.id, currentUserId);

        return {
          id: c.id,
          type: c.type || 'direct',
          name: c.name || null,
          photo_url: c.photo_url || null,
          creator_id: c.creator_id || null,
          admin_ids: c.admin_ids || [],
          members: groupMembers,
          otherUser,
          lastMessage,
          unreadCount,
          isPinned: false,
          isMuted: false,
          clearedAt: c.cleared_at_by_user?.[currentUserId] || null,
          disappearingDuration: 'off',
          autoDeleteChatDuration: c.auto_delete_chat_duration || 'off',
          autoDeleteChatStartedAt: c.auto_delete_chat_started_at || null,
          wallpaper: c.wallpaper || null,
        };
      });

      // Sort by last message created_at descending
      result.sort((a, b) => {
        const timeA = a.lastMessage?.created_at ? new Date(a.lastMessage.created_at).getTime() : 0;
        const timeB = b.lastMessage?.created_at ? new Date(b.lastMessage.created_at).getTime() : 0;
        return timeB - timeA;
      });

      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/chat/conversations:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // GET /api/chat/messages
  router.get('/messages', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const conversationId = req.query.conversationId as string;
      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      const messages = ChatStore.getMessages(conversationId, authUser.id);
      res.json(messages);
    } catch (err: any) {
      console.error('Error in /api/chat/messages:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/send
  router.post('/send', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const {
        conversationId,
        content,
        messageType = 'text',
        mediaUrl,
        replyToId,
        isViewOnce = false,
        fileName,
        fileSize,
        disappearingDuration = 'off',
      } = req.body;

      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      let expiresAt: string | null = null;
      if (disappearingDuration && disappearingDuration !== 'off') {
        const now = Date.now();
        if (disappearingDuration === '5m') expiresAt = new Date(now + 5 * 60 * 1000).toISOString();
        else if (disappearingDuration === '1h') expiresAt = new Date(now + 60 * 60 * 1000).toISOString();
        else if (disappearingDuration === '24h') expiresAt = new Date(now + 24 * 3600 * 1000).toISOString();
        else if (disappearingDuration === '7d') expiresAt = new Date(now + 7 * 24 * 3600 * 1000).toISOString();
        else if (disappearingDuration === '30d') expiresAt = new Date(now + 30 * 24 * 3600 * 1000).toISOString();
        else if (disappearingDuration === '90d') expiresAt = new Date(now + 90 * 24 * 3600 * 1000).toISOString();
      }

      const now = new Date().toISOString();
      const newMsg: StoredMessage = {
        id: crypto.randomUUID(),
        conversation_id: conversationId,
        sender_id: authUser.id,
        content: content || '',
        message_type: messageType,
        media_url: mediaUrl || null,
        created_at: now,
        updated_at: now,
        delivered_at: now,
        read_at: null,
        viewed_at: null,
        expires_at: expiresAt,
        reply_to_id: replyToId || null,
        is_view_once: Boolean(isViewOnce),
        is_edited: false,
        file_name: fileName || null,
        file_size: fileSize || null,
        reactions: [],
        deleted_for_users: [],
        starred_for_users: [],
      };

      ChatStore.addMessage(newMsg);

      // Attempt Supabase database write if admin is available
      if (supabaseAdmin) {
        try {
          await supabaseAdmin.from('messages').insert({
            id: newMsg.id,
            conversation_id: conversationId,
            sender_id: authUser.id,
            content: newMsg.content,
            message_type: newMsg.message_type,
            media_url: newMsg.media_url,
            created_at: now,
            updated_at: now,
          });
        } catch {}
      }

      res.json(newMsg);
    } catch (err: any) {
      console.error('Error in /api/chat/send:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // PATCH /api/chat/message/:id
  router.patch('/message/:id', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const messageId = req.params.id;
      const { action, content, reaction } = req.body;

      if (action === 'edit') {
        const updated = ChatStore.updateMessage(messageId, {
          content,
          is_edited: true,
          updated_at: new Date().toISOString(),
        });
        return res.json({ success: true, message: updated });
      }

      if (action === 'delete_for_me') {
        ChatStore.deleteMessageForUser(messageId, authUser.id);
        return res.json({ success: true });
      }

      if (action === 'delete_for_everyone') {
        const success = ChatStore.deleteMessageForEveryone(messageId, authUser.id);
        return res.json({ success });
      }

      if (action === 'add_reaction') {
        ChatStore.addReaction(messageId, authUser.id, reaction);
        return res.json({ success: true });
      }

      if (action === 'remove_reaction') {
        ChatStore.removeReaction(messageId, authUser.id);
        return res.json({ success: true });
      }

      if (action === 'mark_read') {
        const convId = req.body.conversationId;
        if (convId) {
          ChatStore.markMessagesRead(convId, authUser.id);
        }
        return res.json({ success: true });
      }

      res.status(400).json({ error: 'Unknown action' });
    } catch (err: any) {
      console.error('Error in /api/chat/message/:id:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // Calls Endpoints
  // POST /api/calls/log
  router.post('/calls/log', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { receiverId, callType, status = 'missed', startedAt, durationSeconds = 0 } = req.body;
      const callId = crypto.randomUUID();
      const now = new Date().toISOString();

      const newCall: StoredCall = {
        id: callId,
        caller_id: authUser.id,
        receiver_id: receiverId,
        call_type: callType === 'video' ? 'video' : 'voice',
        status,
        started_at: startedAt || now,
        ended_at: null,
        duration_seconds: durationSeconds,
        created_at: now,
        deleted_for_users: [],
      };

      ChatStore.addCall(newCall);
      res.json({ id: callId });
    } catch (err: any) {
      console.error('Error in /api/calls/log:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // PATCH /api/calls/:id
  router.patch('/calls/:id', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const callId = req.params.id;
      const { status, durationSeconds, endedAt } = req.body;

      const updated = ChatStore.updateCall(callId, {
        status,
        duration_seconds: durationSeconds,
        ended_at: endedAt || new Date().toISOString(),
      });

      res.json({ success: true, call: updated });
    } catch (err: any) {
      console.error('Error in /api/calls/:id:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // GET /api/calls/history
  router.get('/calls/history', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const calls = ChatStore.getCallsForUser(authUser.id);

      // Collect user profiles
      const userIds = new Set<string>();
      calls.forEach((c) => {
        userIds.add(c.caller_id);
        userIds.add(c.receiver_id);
      });

      let profilesMap: Record<string, any> = {};
      if (userIds.size > 0) {
        const { data: profs } = await supabaseClient
          .from('profiles')
          .select('*')
          .in('id', Array.from(userIds));

        (profs || []).forEach((p) => {
          profilesMap[p.id] = p;
        });
      }

      const result = calls.map((c) => ({
        id: c.id,
        caller_id: c.caller_id,
        receiver_id: c.receiver_id,
        call_type: c.call_type,
        status: c.status,
        duration_seconds: c.duration_seconds,
        started_at: c.started_at,
        ended_at: c.ended_at,
        created_at: c.created_at,
        caller: profilesMap[c.caller_id] || { id: c.caller_id, display_name: 'User', username: 'user' },
        receiver: profilesMap[c.receiver_id] || { id: c.receiver_id, display_name: 'User', username: 'user' },
      }));

      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/calls/history:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // DELETE /api/calls/:id
  router.delete('/calls/:id', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const callId = req.params.id;
      if (callId === 'all') {
        ChatStore.clearAllCallsForUser(authUser.id);
      } else {
        ChatStore.deleteCallForUser(callId, authUser.id);
      }

      res.json({ success: true });
    } catch (err: any) {
      console.error('Error in DELETE /api/calls/:id:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // -------------------------------------------------------------
  // Group Conversations
  // -------------------------------------------------------------

  // POST /api/chat/group
  router.post('/group', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { name, photoUrl, memberIds = [] } = req.body;
      if (!name || typeof name !== 'string' || !name.trim()) {
        return res.status(400).json({ error: 'Group name is required' });
      }

      const allMemberIds = Array.from(new Set([authUser.id, ...memberIds]));
      if (allMemberIds.length < 2) {
        return res.status(400).json({ error: 'Group must have at least 2 members' });
      }

      const groupId = crypto.randomUUID();
      const now = new Date().toISOString();

      const newGroup: StoredConversation = {
        id: groupId,
        type: 'group',
        name: name.trim(),
        photo_url: photoUrl || null,
        creator_id: authUser.id,
        admin_ids: [authUser.id],
        memberIds: allMemberIds,
        createdAt: now,
        updatedAt: now,
      };

      ChatStore.upsertConversation(newGroup);

      // Add system message "Group created"
      const systemMsg: StoredMessage = {
        id: crypto.randomUUID(),
        conversation_id: groupId,
        sender_id: authUser.id,
        content: `Group "${name.trim()}" created`,
        message_type: 'system',
        created_at: now,
        updated_at: now,
        reactions: [],
        deleted_for_users: [],
        starred_for_users: [],
      };
      ChatStore.addMessage(systemMsg);

      res.json(newGroup);
    } catch (err: any) {
      console.error('Error creating group:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/group/:id/members
  router.post('/group/:id/members', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const groupId = req.params.id;
      const { action, userId } = req.body; // action: 'add' | 'remove' | 'leave'

      const group = ChatStore.getConversation(groupId);
      if (!group || group.type !== 'group') {
        return res.status(404).json({ error: 'Group not found' });
      }

      let members = [...group.memberIds];
      const targetUser = userId || authUser.id;

      if (action === 'add') {
        if (!members.includes(targetUser)) members.push(targetUser);
      } else if (action === 'remove' || action === 'leave') {
        members = members.filter((m) => m !== targetUser);
      }

      ChatStore.updateConversation(groupId, { memberIds: members });
      res.json({ success: true, memberIds: members });
    } catch (err: any) {
      console.error('Error in group members:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/clear-all
  // Clear all messages in conversation for both participants
  router.post('/clear-all', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { conversationId } = req.body;
      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      ChatStore.clearMessagesForEveryone(conversationId);

      // Attempt DB wipe
      if (supabaseAdmin) {
        try {
          await supabaseAdmin.from('messages').delete().eq('conversation_id', conversationId);
        } catch {}
      }

      res.json({ success: true });
    } catch (err: any) {
      console.error('Error in /api/chat/clear-all:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/clear-for-me
  router.post('/clear-for-me', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { conversationId } = req.body;
      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      ChatStore.clearChatForUser(conversationId, authUser.id);
      res.json({ success: true });
    } catch (err: any) {
      console.error('Error in /api/chat/clear-for-me:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/delete-chat-for-me
  router.post('/delete-chat-for-me', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { conversationId } = req.body;
      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      ChatStore.deleteChatForUser(conversationId, authUser.id);
      res.json({ success: true });
    } catch (err: any) {
      console.error('Error in /api/chat/delete-chat-for-me:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/mark-delivered
  router.post('/mark-delivered', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { conversationId, messageId } = req.body;
      if (messageId) {
        ChatStore.markMessageDelivered(messageId);
      } else if (conversationId) {
        ChatStore.markMessagesDelivered(conversationId, authUser.id);
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('Error in /api/chat/mark-delivered:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/auto-delete
  router.post('/auto-delete', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { conversationId, duration } = req.body; // 'off' | '5m'
      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      const now = new Date().toISOString();
      const updated = ChatStore.updateConversation(conversationId, {
        auto_delete_chat_duration: duration === '5m' ? '5m' : 'off',
        auto_delete_chat_started_at: duration === '5m' ? now : null,
      });

      res.json({ success: true, conversation: updated });
    } catch (err: any) {
      console.error('Error in /api/chat/auto-delete:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/chat/wallpaper
  router.post('/wallpaper', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { conversationId, wallpaper } = req.body;
      if (!conversationId) {
        return res.status(400).json({ error: 'conversationId is required' });
      }

      const updated = ChatStore.updateConversation(conversationId, { wallpaper });
      res.json({ success: true, conversation: updated });
    } catch (err: any) {
      console.error('Error in /api/chat/wallpaper:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // -------------------------------------------------------------
  // WhatsApp-Style Status / Stories
  // -------------------------------------------------------------

  // POST /api/status
  router.post('/status', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const {
        mediaType = 'text',
        content,
        mediaUrl,
        backgroundColor = '#10b981',
        caption,
        privacy = 'friends',
        selectedFriends = [],
      } = req.body;

      const now = Date.now();
      const newStatus = ChatStore.addStatusStory({
        id: crypto.randomUUID(),
        user_id: authUser.id,
        media_type: mediaType,
        content: content || null,
        media_url: mediaUrl || null,
        background_color: backgroundColor,
        caption: caption || null,
        created_at: new Date(now).toISOString(),
        expires_at: new Date(now + 24 * 3600 * 1000).toISOString(),
        privacy,
        selected_friends: selectedFriends,
        views: [],
      });

      res.json(newStatus);
    } catch (err: any) {
      console.error('Error creating status:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // GET /api/status
  router.get('/status', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Fetch accepted friends
      const { data: reqs } = await supabaseClient
        .from('friend_requests')
        .select('*')
        .or(`sender_id.eq.${authUser.id},receiver_id.eq.${authUser.id}`)
        .eq('status', 'accepted');

      const friendIds = (reqs || []).map((r) =>
        r.sender_id === authUser.id ? r.receiver_id : r.sender_id
      );

      const statuses = ChatStore.getActiveStatuses(friendIds, authUser.id);

      // Collect user profiles
      const userIds = Array.from(new Set(statuses.map((s) => s.user_id)));
      let profilesMap: Record<string, any> = {};
      if (userIds.length > 0) {
        const { data: profs } = await authUser.client
          .from('profiles')
          .select('*')
          .in('id', userIds);

        (profs || []).forEach((p) => {
          profilesMap[p.id] = p;
        });
      }

      // Also get viewer profiles if any
      const allViewerIds = new Set<string>();
      statuses.forEach((s) => s.views?.forEach((v) => allViewerIds.add(v.user_id)));
      let viewerMap: Record<string, any> = {};
      if (allViewerIds.size > 0) {
        const { data: vProfs } = await authUser.client
          .from('profiles')
          .select('*')
          .in('id', Array.from(allViewerIds));

        (vProfs || []).forEach((vp) => {
          viewerMap[vp.id] = vp;
        });
      }

      const formatted = statuses.map((s) => ({
        ...s,
        user: profilesMap[s.user_id] || {
          id: s.user_id,
          display_name: 'Friend',
          username: 'user',
        },
        views: (s.views || []).map((v) => ({
          ...v,
          user: viewerMap[v.user_id] || {
            id: v.user_id,
            display_name: 'Friend',
            username: 'user',
          },
        })),
      }));

      res.json(formatted);
    } catch (err: any) {
      console.error('Error fetching statuses:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // POST /api/status/:id/view
  router.post('/status/:id/view', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const statusId = req.params.id;
      ChatStore.recordStatusView(statusId, authUser.id);
      res.json({ success: true });
    } catch (err: any) {
      console.error('Error recording status view:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  // DELETE /api/status/:id
  router.delete('/status/:id', async (req: Request, res: Response) => {
    try {
      const authUser = await getAuthenticatedUser(req);
      if (!authUser) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const statusId = req.params.id;
      ChatStore.deleteStatusStory(statusId, authUser.id);
      res.json({ success: true });
    } catch (err: any) {
      console.error('Error deleting status:', err);
      res.status(500).json({ error: err.message || 'Internal server error' });
    }
  });

  return router;
}
