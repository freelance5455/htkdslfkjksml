import "./config.js"; import pg from "pg"; import bcrypt from "bcryptjs";
const {Pool}=pg; export const pool=new Pool({connectionString:process.env.DATABASE_URL});
export const q=(s,p)=>pool.query(s,p);
export async function init(){
await q(`CREATE TABLE IF NOT EXISTS users(
id BIGSERIAL PRIMARY KEY,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,
role TEXT NOT NULL DEFAULT 'cashier' CHECK(role IN('admin','manager','cashier')),
display_name TEXT NOT NULL,active BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS products(
id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,sku TEXT UNIQUE NOT NULL,barcode TEXT UNIQUE NOT NULL,
category TEXT NOT NULL,selling_price NUMERIC(12,2) NOT NULL CHECK(selling_price>=0),
cost_price NUMERIC(12,2) NOT NULL DEFAULT 0,sizes JSONB NOT NULL DEFAULT '[]',
colors JSONB NOT NULL DEFAULT '[]',images JSONB NOT NULL DEFAULT '[]',description TEXT NOT NULL DEFAULT '',
stock INTEGER NOT NULL DEFAULT 0 CHECK(stock>=0),min_stock INTEGER NOT NULL DEFAULT 0 CHECK(min_stock>=0),
active BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ DEFAULT NOW(),updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS orders(
id BIGSERIAL PRIMARY KEY,order_number TEXT UNIQUE NOT NULL,customer_name TEXT NOT NULL,phone TEXT NOT NULL,
email TEXT NOT NULL DEFAULT '',governorate TEXT NOT NULL,city TEXT NOT NULL,address TEXT NOT NULL,
building_details TEXT NOT NULL DEFAULT '',apartment_number TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',
subtotal NUMERIC(12,2) NOT NULL,discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0,shipping_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
total NUMERIC(12,2) NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN('pending','confirmed','shipped','delivered','cancelled')),
created_at TIMESTAMPTZ DEFAULT NOW(),updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS order_items(
id BIGSERIAL PRIMARY KEY,order_id BIGINT REFERENCES orders(id) ON DELETE CASCADE,product_id BIGINT REFERENCES products(id),
product_name TEXT NOT NULL,sku TEXT NOT NULL,size TEXT NOT NULL DEFAULT '',color TEXT NOT NULL DEFAULT '',
quantity INTEGER NOT NULL,price NUMERIC(12,2) NOT NULL,line_total NUMERIC(12,2) NOT NULL);
CREATE TABLE IF NOT EXISTS stock_movements(
id BIGSERIAL PRIMARY KEY,product_id BIGINT REFERENCES products(id),change_qty INTEGER NOT NULL,reason TEXT NOT NULL,
order_id BIGINT REFERENCES orders(id) ON DELETE SET NULL,created_at TIMESTAMPTZ DEFAULT NOW());
CREATE INDEX IF NOT EXISTS oi_phone ON orders(phone);CREATE INDEX IF NOT EXISTS sm_product ON stock_movements(product_id);CREATE TABLE IF NOT EXISTS push_subscriptions(
id BIGSERIAL PRIMARY KEY,endpoint TEXT UNIQUE NOT NULL,p256dh TEXT NOT NULL,auth TEXT NOT NULL,user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,device_type TEXT NOT NULL DEFAULT 'mobile',active BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ DEFAULT NOW(),last_seen_at TIMESTAMPTZ DEFAULT NOW());`);
const u=process.env.ADMIN_USERNAME||'mazo';const p=process.env.ADMIN_PASSWORD||'mazo44';
const r=await q('SELECT id FROM users WHERE username=$1',[u]);if(!r.rowCount){
await q('INSERT INTO users(username,password_hash,role,display_name) VALUES($1,$2,$3,$4)',
[u,await bcrypt.hash(p,12),'admin','MAZO HUB Owner']);}}
