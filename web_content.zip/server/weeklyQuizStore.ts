import fs from 'fs';
import path from 'path';
import { 
  WeeklyQuiz, 
  WeeklyQuizSubmission, 
  WeeklyQuizLeaderboardEntry, 
  MCQQuestion, 
  WeeklyQuizWinner,
  AdminOverviewStats,
  AdminQuizGlobalSettings,
  QuizReminderSubscription,
  QuizNotificationAlert,
  WeeklyQuizStatus
} from '../src/types';

const DATA_DIR = path.join(process.cwd(), 'data');
const QUIZZES_FILE = path.join(DATA_DIR, 'weekly_quizzes.json');
const SUBMISSIONS_FILE = path.join(DATA_DIR, 'weekly_submissions.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'admin_settings.json');
const SUBSCRIPTIONS_FILE = path.join(DATA_DIR, 'quiz_subscriptions.json');
const ALERTS_FILE = path.join(DATA_DIR, 'quiz_alerts.json');
const QUESTION_BANK_FILE = path.join(DATA_DIR, 'question_bank.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) {
    console.error('Failed to create data directory:', e);
  }
}

const DEFAULT_ADMIN_SETTINGS: AdminQuizGlobalSettings = {
  defaultRules: [
    'প্রতিটি প্রশ্নের জন্য সঠিক উত্তরের নির্দিষ্ট মান থাকবে।',
    'একটি নির্দিষ্ট সময়সীমা (Timer) কার্যকর থাকবে। সময় শেষ হলে স্বয়ংক্রিয়ভাবে জমা হবে।',
    'প্রতিটি শিক্ষার্থী কেবল ১ বারই অফিশিয়াল অংশগ্রহণের সুযোগ পাবে।',
    'সর্বোচ্চ স্কোর এবং সর্বনিম্ন সময় নেওয়া শিক্ষার্থী বিজয়ী হিসেবে বিবেচিত হবে।',
    'অ্যাডমিন স্কোর ও টাইম যাচাই করে বিজয়ী ঘোষণা ও পুরস্কার পাঠাবে।'
  ],
  defaultDuration: 20,
  defaultMarksPerQuestion: 1,
  defaultNegativeMarking: false,
  defaultNegativeMarks: 0.25,
  leaderboardVisibility: true,
  resultVisibility: true,
  explanationVisibility: true,
  maxAttempts: 1,
  showPrizeSection: true,
  showCountdownTimer: true,
  requireAdsBeforeQuiz: true,
  defaultAdSeconds: 5,
  enable10MinAlerts: true,
  adminEmail: 'sudipdas22061999@gmail.com'
};

// Initial Sample Questions for Week 1 Mega Quiz
const INITIAL_WEEK_1_QUESTIONS: MCQQuestion[] = [
  {
    id: 'wq-1',
    subject: 'History',
    question: '১৯০৫ সালে বঙ্গভঙ্গ কার্যকর করার সময় ভারতের বড়লাট (Viceroy) কে ছিলেন?',
    options: ['A. লর্ড কার্জন', 'B. লর্ড ডালহৌসি', 'C. লর্ড ক্যানিং', 'D. লর্ড রিপন'],
    correctOptionIndex: 0,
    explanation: '১৯০৫ সালের ১৬ অক্টোবর লর্ড কার্জনের আমলে বঙ্গভঙ্গ কার্যকর করা হয়েছিল। এর প্রতিবাদে স্বদেশী ও বয়কট আন্দোলন শুরু হয়।',
    shortConcept: 'বঙ্গভঙ্গ ১৯০৫',
    rememberPoint: 'লর্ড কার্জন বঙ্গভঙ্গ কার্যকর করেন এবং ১৯১১ সালে লর্ড হার্ডিঞ্জ তা রদ করেন।',
    difficulty: 'Medium'
  },
  {
    id: 'wq-2',
    subject: 'Indian Polity',
    question: 'ভারতের সংবিধানের কোন অনুচ্ছেদে সমতার অধিকার (Right to Equality) বর্ণিত রয়েছে?',
    options: ['A. অনুচ্ছেদ ১২-১৫', 'B. অনুচ্ছেদ ১৪-১৮', 'C. অনুচ্ছেদ ১৯-২২', 'D. অনুচ্ছেদ ২৫-২৮'],
    correctOptionIndex: 1,
    explanation: 'ভারতীয় সংবিধানের তৃতীয় অংশে ১৪ থেকে ১৮ নম্বর অনুচ্ছেদে নাগরিকদের মৌলিক সমতার অধিকার বিস্তারিতভাবে বর্ণিত হয়েছে।',
    shortConcept: 'মৌলিক অধিকার - সমতা',
    rememberPoint: 'অনুচ্ছেদ ১৪: আইনের দৃষ্টিতে সমতা, অনুচ্ছেদ ১৭: অস্পৃশ্যতা দূরীকরণ।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-3',
    subject: 'Geography',
    question: 'পশ্চিমবঙ্গের সর্বোচ্চ শৃঙ্গ কোনটি?',
    options: ['A. টাইগার হিল', 'B. সান্দাকফু', 'C. ফালুট', 'D. সবরগ্রাম'],
    correctOptionIndex: 1,
    explanation: 'সান্দাকফু (৩৬৩৬ মিটার বা ১১,৯২৯ ফুট) পশ্চিমবঙ্গ ও ভারতের পশ্চিমবঙ্গ রাজ্যের সর্বোচ্চ পর্বতশৃঙ্গ। এটি সিঙ্গালীলা পর্বতশ্রেণীতে অবস্থিত।',
    shortConcept: 'পশ্চিমবঙ্গের ভূগোল',
    rememberPoint: 'সান্দাকফু থেকে কাঞ্চনজঙ্ঘা ও এভারেস্ট সহ হিমালয়ের চারটি সর্বোচ্চ শৃঙ্গ দৃশ্যমান।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-4',
    subject: 'General Science',
    question: 'মানবদেহের বৃহত্তম অন্তঃক্ষরা গ্রন্থি (Largest Endocrine Gland) কোনটি?',
    options: ['A. পিটুইটারি', 'B. থাইরয়েড', 'C. অগ্ন্যাশয়', 'D. অ্যাড্রেনাল'],
    correctOptionIndex: 1,
    explanation: 'থাইরয়েড গ্রন্থি মানবদেহের সবচেয়ে বড় অন্তঃক্ষরা গ্রন্থি। এটি গলার সামনের অংশে অবস্থিত এবং থাইরক্সিন হরমোন ক্ষরণ করে।',
    shortConcept: 'হরমোন ও অন্তঃক্ষরা তন্ত্র',
    rememberPoint: 'পিটুইটারি হল মাস্টার গ্ল্যান্ড এবং লিভার/যকৃৎ মানবদেহের সার্বিক বৃহত্তম গ্রন্থি (বহিঃক্ষরা)।',
    difficulty: 'Medium'
  },
  {
    id: 'wq-5',
    subject: 'Current Affairs',
    question: 'চন্দ্রযান-৩ সফলভাবে চাঁদের দক্ষিণ মেরুতে অবতরণকারী ঐতিহাসিক দিনটিকে ভারত সরকার কী দিবস হিসেবে ঘোষণা করেছে?',
    options: ['A. জাতীয় বিজ্ঞান দিবস', 'B. জাতীয় মহাকাশ দিবস', 'C. ইসরো দিবস', 'D. বিক্রম ল্যান্ডার দিবস'],
    correctOptionIndex: 1,
    explanation: '২৩ আগস্ট ২০২৩ সালে চন্দ্রযান-৩ এর বিক্রম ল্যান্ডার চাঁদের দক্ষিণ মেরুর শিবশক্তি পয়েন্টে অবতরণ করে। এই গৌরবময় দিনটিকে প্রধানমন্ত্রী "জাতীয় মহাকাশ দিবস" (National Space Day) হিসেবে ঘোষণা করেন।',
    shortConcept: 'মহাকাশ গবেষণা ও ইসরো',
    rememberPoint: '২৩ আগস্ট = জাতীয় মহাকাশ দিবস।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-6',
    subject: 'Mathematics',
    question: 'একটি আসল ৫ বছরে সুদে-আসলে দ্বিগুণ হলে, বার্ষিক সুদের হার (Simple Interest Rate) কত?',
    options: ['A. ১০%', 'B. ১৫%', 'C. ২০%', 'D. ২৫%'],
    correctOptionIndex: 2,
    explanation: 'ধরি আসল P টাকা। ৫ বছরে সুদ I = P টাকা। সূত্র: I = (P * R * T) / 100 => P = (P * R * 5) / 100 => R = 100 / 5 = ২০%।',
    shortConcept: 'সরল সুদ (Simple Interest)',
    rememberPoint: 'দ্বিগুণ হলে সুদ = ১০০% / সময় = ১০০ / ৫ = ২০%।',
    difficulty: 'Medium'
  },
  {
    id: 'wq-7',
    subject: 'Reasoning',
    question: 'যদি B = 2, BAG = 10 হয়, তবে BOX এর মান কত হবে?',
    options: ['A. 39', 'B. 41', 'C. 43', 'D. 45'],
    correctOptionIndex: 1,
    explanation: 'বর্ণমালার স্থানীয় মান যোগ: B(2) + O(15) + X(24) = 2 + 15 + 24 = 41।',
    shortConcept: 'Coding - Alphabet Place Value',
    rememberPoint: 'A=1, B=2, ... Z=26।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-8',
    subject: 'General Knowledge',
    question: 'ভারতের প্রাচীনতম তৈলখনি বা তেল শোধনাগার কোনটি?',
    options: ['A. জামনগর', 'B. ডিগবয়', 'C. বরৌনি', 'D. ট্রম্বে'],
    correctOptionIndex: 1,
    explanation: 'অসমের ডিগবয় ভারতের তথা এশিয়ার প্রাচীনতম পরিচালিত তৈলখনি ও তেল শোধনাগার, যা ১৯০১ সালে প্রতিষ্ঠিত হয়েছিল।',
    shortConcept: 'ভারতের খনিজ ও সম্পদ',
    rememberPoint: 'ডিগবয়, আসাম = ভারতের প্রথম তেল শোধনাগার।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-9',
    subject: 'History',
    question: 'মৌর্য সাম্রাজ্যের প্রতিষ্ঠাতা কে ছিলেন?',
    options: ['A. বিন্দুসার', 'B. অশোক', 'C. চন্দ্রগুপ্ত মৌর্য', 'D. ধননন্দ'],
    correctOptionIndex: 2,
    explanation: 'চাণক্য (কৌটিল্য)-এর সহায়তায় শেষ নন্দ রাজা ধননন্দকে পরাজিত করে ৩২১ খ্রিস্টপূর্বাব্দে চন্দ্রগুপ্ত মৌর্য মৌর্য বংশের প্রতিষ্ঠা করেন।',
    shortConcept: 'প্রাচীন ভারতীয় ইতিহাস',
    rememberPoint: 'কৌটিল্যের অর্থশাস্ত্র চন্দ্রগুপ্ত মৌর্যের শাসনকাল সম্পর্কে জানতে সাহায্য করে।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-10',
    subject: 'General Science',
    question: 'কোন ভিটামিনের অভাবে রিকেট (Rickets) রোগ হয়?',
    options: ['A. ভিটামিন A', 'B. ভিটামিন B', 'C. ভিটামিন C', 'D. ভিটামিন D'],
    correctOptionIndex: 3,
    explanation: 'ভিটামিন D এর অভাবে শিশুদের হাড় নরম ও বাঁকা হয়ে রিকেট রোগ হয় এবং বড়দের অস্টিওম্যালাসিয়া হয়।',
    shortConcept: 'ভিটামিন ও অভাবজনিত রোগ',
    rememberPoint: 'ভিটামিন D সূর্যালোক থেকে ত্বকে সংশ্লেষিত হয়।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-11',
    subject: 'Geography',
    question: 'কোন নদীকে "দক্ষিণ ভারতের গঙ্গা" (Ganga of South India) বলা হয়?',
    options: ['A. কৃষ্ণা', 'B. গোদাবরী', 'C. কাবেরী', 'D. নর্মদা'],
    correctOptionIndex: 1,
    explanation: 'দৈর্ঘ্য ও ঐতিহাসিক গুরুত্বের কারণে গোদাবরী নদীকে "বৃদ্ধ গঙ্গা" বা "দক্ষিণ ভারতের গঙ্গা" বলা হয়।',
    shortConcept: 'ভারতের নদ-নদী',
    rememberPoint: 'গোদাবরী ভারতের দ্বিতীয় দীর্ঘতম নদী (১৪৬৫ কিমি)।',
    difficulty: 'Medium'
  },
  {
    id: 'wq-12',
    subject: 'Indian Polity',
    question: 'ভারতের উপরাষ্ট্রপতি কার পদাধিকারবলে সভাপতি (Ex-officio Chairman)?',
    options: ['A. লোকসভা', 'B. রাজ্যসভা', 'C. নীতি আয়োগ', 'D. অর্থ কমিশন'],
    correctOptionIndex: 1,
    explanation: 'সংবিধানের অনুচ্ছেদ ৬৪ অনুসারে ভারতের উপরাষ্ট্রপতি পদাধিকারবলে রাজ্যসভার চেয়ারম্যান হিসেবে দায়িত্ব পালন করেন।',
    shortConcept: 'সংসদ ও রাজ্যসভা',
    rememberPoint: 'উপরাষ্ট্রপতি রাজ্যসভার সদস্য নন, কিন্তু তিনি এর সভাপতি।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-13',
    subject: 'Mathematics',
    question: 'দুটি সংখ্যার গ.সা.গু ১২ এবং ল.সা.গু ৭২। একটি সংখ্যা ২৪ হলে অপর সংখ্যাটি কত?',
    options: ['A. ৩৬', 'B. ৪৮', 'C. ১৮', 'D. ৩২'],
    correctOptionIndex: 0,
    explanation: 'সূত্র: দুটি সংখ্যার গুণফল = গ.সা.গু * ল.সা.গু। অপর সংখ্যা = (১২ * ৭২) / ২৪ = ৩৬।',
    shortConcept: 'HCF and LCM',
    rememberPoint: 'Product of two numbers = HCF × LCM.',
    difficulty: 'Easy'
  },
  {
    id: 'wq-14',
    subject: 'Reasoning',
    question: 'সিরিজটি সম্পূর্ণ করুন: 3, 8, 15, 24, 35, ?',
    options: ['A. 46', 'B. 48', 'C. 49', 'D. 50'],
    correctOptionIndex: 1,
    explanation: 'প্যাটার্ন: 2^2 - 1 = 3, 3^2 - 1 = 8, 4^2 - 1 = 15, 5^2 - 1 = 24, 6^2 - 1 = 35, সুতরাং পরবর্তী সংখ্যা 7^2 - 1 = 49 - 1 = 48। অথবা পার্থক্য: +5, +7, +9, +11, +13 => 35 + 13 = 48।',
    shortConcept: 'Number Series',
    rememberPoint: 'Differences increase by 2 each step.',
    difficulty: 'Medium'
  },
  {
    id: 'wq-15',
    subject: 'Current Affairs',
    question: '২০২৪ সালের প্যারিস অলিম্পিকে ভারতের একমাত্র রৌপ্য পদকটি কে জয় করেন?',
    options: ['A. মনু ভাকের', 'B. নীরজ চোপড়া', 'C. পি. ভি. সিন্ধু', 'D. অমন শেরাওয়াত'],
    correctOptionIndex: 1,
    explanation: 'প্যারিস ২০২৪ অলিম্পিকে পুরুষদের জ্যাভলিন থ্রোতে নীরজ চোপড়া ৮৯.৪৫ মিটার ছুড়ে রৌপ্য পদক জয় করেন।',
    shortConcept: 'Sports & Olympics',
    rememberPoint: 'নীরজ চোপড়া টোকিও অলিম্পিকে সোনা এবং প্যারিস অলিম্পিকে রৌপ্য জয় করেন।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-16',
    subject: 'History',
    question: 'সিপাহী বিদ্রোহের (১৮৫৭) প্রথম শহীদ কে ছিলেন?',
    options: ['A. তাঁতিয়া তোপী', 'B. মঙ্গল পাণ্ডে', 'C. নানা সাহেব', 'D. বাহাদুর শাহ জাফর'],
    correctOptionIndex: 1,
    explanation: '১৮৫৭ সালের ২৯ মার্চ ব্যারাকপুর সেনানিবাসে চর্বিযুক্ত কার্তুজ ব্যবহারের বিরুদ্ধে বিদ্রোহ ঘোষণা করেন মঙ্গল পাণ্ডে। ৮ এপ্রিল ১৮৫৭ তাকে ফাঁসি দেওয়া হয়।',
    shortConcept: '১৮৫৭ সালের মহাবিদ্রোহ',
    rememberPoint: 'ব্যারাকপুর সেনানিবাসে ৩৪তম বেঙ্গল নেটিভ ইনফ্যান্ট্রির সিপাহী ছিলেন মঙ্গল পাণ্ডে।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-17',
    subject: 'General Science',
    question: 'শব্দ তরঙ্গ (Sound Waves) নিচের কোন মাধ্যমের মধ্য দিয়ে চলাচল করতে পারে না?',
    options: ['A. কঠিন', 'B. তরল', 'C. গ্যাসীয়', 'D. শূন্যস্থান (Vacuum)'],
    correctOptionIndex: 3,
    explanation: 'শব্দ হল এক প্রকার যান্ত্রিক তরঙ্গ (Mechanical Wave), যার চলাচলের জন্য জড় মাধ্যমের প্রয়োজন হয়। তাই শূন্যস্থানে শব্দ চলতে পারে না।',
    shortConcept: 'শব্দবিজ্ঞান (Acoustics)',
    rememberPoint: 'শব্দের বেগ কঠিন মাধ্যমে সর্বাধিক এবং শূন্যে শূন্য। আলো শূন্যস্থানেও চলতে পারে।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-18',
    subject: 'General Knowledge',
    question: 'আন্তর্জাতিক বিচারালয় (International Court of Justice)-এর সদর দপ্তর কোথায় অবস্থিত?',
    options: ['A. নিউ ইয়র্ক', 'B. জেনেভা', 'C. দ্য হেগ', 'D. প্যারিস'],
    correctOptionIndex: 2,
    explanation: 'জাতিসংঘের প্রধান বিচার বিভাগীয় সংস্থা ইন্টারন্যাশনাল কোর্ট অফ জাস্টিস নেদারল্যান্ডসের দ্য হেগ (The Hague) শহরে অবস্থিত পিস প্যালেসে অবস্থিত।',
    shortConcept: 'আন্তর্জাতিক সংস্থা ও সদর দপ্তর',
    rememberPoint: 'ICJ গঠিত হয় ১৯৪৫ সালে এবং এতে ১৫ জন বিচারক ৯ বছরের মেয়াদে নির্বাচিত হন।',
    difficulty: 'Easy'
  },
  {
    id: 'wq-19',
    subject: 'Indian Economy',
    question: 'নীতি আয়োগ (NITI Aayog) কবে গঠিত হয়?',
    options: ['A. ১ জানুয়ারি ২০১৪', 'B. ১ জানুয়ারি ২০১৫', 'C. ১৫ আগস্ট ২০১৫', 'D. ১ জুলাই ২০১৭'],
    correctOptionIndex: 1,
    explanation: 'পরিকল্পনা কমিশনের (Planning Commission) পরিবর্তে ১ জানুয়ারি ২০১৫ তারিখে কেন্দ্রীয় সরকার নীতি আয়োগ (National Institution for Transforming India) গঠন করে।',
    shortConcept: 'ভারতের অর্থনৈতিক পরিকল্পনা',
    rememberPoint: 'প্রধানমন্ত্রী নীতি আয়োগের পদাধিকারবলে চেয়ারম্যান।',
    difficulty: 'Medium'
  },
  {
    id: 'wq-20',
    subject: 'Mathematics',
    question: 'যদি কোনো দ্রব্যের ক্রয়মূল্য ৫০০ টাকা এবং বিক্রয়মূল্য ৫৫০ টাকা হয়, তবে শতকরা লাভের হার কত?',
    options: ['A. ৫%', 'B. ৮%', 'C. ১০%', 'D. ১২%'],
    correctOptionIndex: 2,
    explanation: 'লাভ = ৫৫০ - ৫০০ = ৫০ টাকা। শতকরা লাভ = (লাভ / ক্রয়মূল্য) * ১০০ = (৫০ / ৫০০) * ১০০ = ১০%।',
    shortConcept: 'লাভ ও ক্ষতি (Profit & Loss)',
    rememberPoint: 'লাভ বা ক্ষতি সর্বদা ক্রয়মূল্যের উপর হিসেব করা হয়।',
    difficulty: 'Easy'
  }
];

// Initial pre-populated sample quizzes (Today Evening, Tomorrow Morning, Weekly Mega)
const nowTimestamp = Date.now();
const todayDateStr = new Date(nowTimestamp).toISOString().split('T')[0];
const tomorrowDateStr = new Date(nowTimestamp + 24 * 60 * 60 * 1000).toISOString().split('T')[0];

const SAMPLE_QUIZZES_LIST: WeeklyQuiz[] = [
  {
    id: 'quiz-evening-today-2026',
    title: 'আজকের সান্ধ্য স্পেশাল লাইভ কুইজ (Evening Mega Challenge)',
    description: 'আজকের সান্ধ্য স্পেশাল দ্রুতগতির লাইভ কুইজ! দ্রুততম সময়ে সঠিক উত্তর দিয়ে জিতে নিন আকর্ষণীয় ফিজিক্যাল পুরস্কার।',
    category: 'Evening Special',
    startDate: todayDateStr,
    startTime: '19:00', // 7:00 PM
    endDate: todayDateStr,
    endTime: '22:00', // 10:00 PM
    questionCount: 15,
    timeLimit: 15,
    subjects: ['History', 'General Science', 'Geography', 'Current Affairs'],
    targetLevel: 'Competitive Exam',
    language: 'bn',
    prizeName: 'Fastrack Smart Digital Watch / Scientific Calculator',
    prizeDescription: 'আজকের সান্ধ্য কুইজের শীর্ষ বিজয়ীর জন্য আকর্ষণীয় ডিজিটাল স্মার্ট ওয়াচ অথবা সায়েন্টিফিক ক্যালকুলেটর হোম ডেলিভারি।',
    prizeImage: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
    prizeValue: '₹1,500',
    eligibilityRules: [
      'প্রশ্ন সংখ্যা: ১৫ টি MCQ',
      'সময়সীমা: ১৫ মিনিট',
      'নেগেটিভ মার্কিং: প্রতিটি ভুল উত্তরের জন্য ০.২৫ মার্ক কাটা যাবে',
      'প্রবেশের আগে ২টি স্পনসরড এড দেখে এন্ট্রি পাস আনলক করতে হবে',
      'কুইজ আরম্ভের ১০ মিনিট পূর্বে সমস্ত ইউজারদের ডিভাইসে অ্যালার্ট পাঠানো হবে'
    ],
    requireAdsBeforeQuiz: true,
    adWatchSeconds: 5,
    notification10MinSent: false,
    winnerAnnouncementDate: todayDateStr,
    status: 'live',
    questions: INITIAL_WEEK_1_QUESTIONS.slice(0, 15),
    participantsCount: 14,
    winnerVerified: false,
    prizeStatus: 'Pending Verification',
    createdAt: new Date(nowTimestamp - 12 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'quiz-morning-tomorrow-2026',
    title: 'আগামীকাল সকালের সাধারণ জ্ঞান ও কারেন্ট অ্যাফেয়ার্স চ্যালেঞ্জ (Morning 9:00 AM)',
    description: 'আগামীকাল সকাল ৯:০০ টায় শুরু হবে বিশেষ সকালের কুইজ! প্রস্তুত হয়ে অ্যালার্ট সেট করে রাখুন।',
    category: 'Morning Challenge',
    startDate: tomorrowDateStr,
    startTime: '09:00', // 9:00 AM
    endDate: tomorrowDateStr,
    endTime: '12:00', // 12:00 PM
    questionCount: 10,
    timeLimit: 12,
    subjects: ['Current Affairs', 'Indian Polity', 'Economics', 'Reasoning'],
    targetLevel: 'SSC / WBCS / Rail',
    language: 'bn',
    prizeName: 'NCERT & Competitive Exam Reference Book Set',
    prizeDescription: 'সকালের কুইজের ১ম স্থানাধিকারীর জন্য সম্পূর্ণ এক্সাম রেফারেন্স বই সেট কুরিয়ারের মাধ্যমে পাঠানো হবে।',
    prizeImage: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
    prizeValue: '₹1,200',
    eligibilityRules: [
      'প্রশ্ন সংখ্যা: ১০ টি MCQ',
      'সময়সীমা: ১২ মিনিট',
      'সকাল ৮:৫০ মিনিটে (১০ মিনিট আগে) রিমাইন্ডার অ্যালার্ট পাবেন',
      'প্রত্যেক শিক্ষার্থী ১ বার অংশগ্রহণের সুযোগ পাবে'
    ],
    requireAdsBeforeQuiz: true,
    adWatchSeconds: 5,
    notification10MinSent: false,
    winnerAnnouncementDate: tomorrowDateStr,
    status: 'scheduled',
    questions: INITIAL_WEEK_1_QUESTIONS.slice(5, 15),
    participantsCount: 6,
    winnerVerified: false,
    prizeStatus: 'Pending Verification',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'quiz-week-1-2026',
    title: 'StudySkill গ্র্যান্ড মেগা কুইজ – Week 1',
    description: 'সারা সপ্তাহের অল-সাবজেক্ট মেগা কুইজ! সকল বিষয় মিলিয়ে সেরা প্রস্তুতি ও লিডারবোর্ডের সেরা পুরস্কার।',
    category: 'Grand Weekly',
    startDate: new Date(nowTimestamp - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    startTime: '10:00',
    endDate: new Date(nowTimestamp + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endTime: '20:00',
    questionCount: 20,
    timeLimit: 20,
    subjects: ['History', 'Geography', 'Indian Polity', 'General Science', 'General Knowledge', 'Current Affairs', 'Mathematics', 'Reasoning'],
    targetLevel: 'Competitive Exam',
    language: 'bn',
    prizeName: 'Executive Leather Notebook + Smart Exam Kit',
    prizeDescription: 'One premium notebook set with hardbound study planner and metallic executive pen for the official Weekly Quiz winner.',
    prizeImage: 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&w=600&q=80',
    prizeValue: '₹2,000',
    eligibilityRules: [
      'Total Questions: 20',
      'Time Limit: 20 Minutes',
      'One attempt per user',
      'Score is calculated automatically',
      'Highest score gets the highest rank',
      'Final winner is verified by the Admin',
      'Prize is manually dispatched by the Admin'
    ],
    requireAdsBeforeQuiz: true,
    adWatchSeconds: 5,
    notification10MinSent: false,
    winnerAnnouncementDate: new Date(nowTimestamp + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'live',
    questions: INITIAL_WEEK_1_QUESTIONS,
    participantsCount: 18,
    winnerVerified: false,
    prizeStatus: 'Pending Verification',
    createdAt: new Date(nowTimestamp - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString()
  }
];

const DEFAULT_WEEKLY_QUIZ: WeeklyQuiz = SAMPLE_QUIZZES_LIST[0];

// Initial Sample Submissions for leaderboard realism
const INITIAL_SUBMISSIONS: WeeklyQuizSubmission[] = [
  {
    id: 'sub-sample-1',
    userId: 'user-rahul-01',
    displayName: 'Rahul Sharma',
    quizId: 'quiz-week-1-2026',
    answers: {},
    correctAnswers: 19,
    wrongAnswers: 1,
    unanswered: 0,
    score: 19,
    totalQuestions: 20,
    startTime: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    submitTime: new Date(Date.now() - 28 * 60 * 1000).toISOString(),
    completionTimeSeconds: 720, // 12m 00s
    status: 'verified'
  },
  {
    id: 'sub-sample-2',
    userId: 'user-amit-02',
    displayName: 'Amit Roy',
    quizId: 'quiz-week-1-2026',
    answers: {},
    correctAnswers: 19,
    wrongAnswers: 1,
    unanswered: 0,
    score: 19,
    totalQuestions: 20,
    startTime: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    submitTime: new Date(Date.now() - 46 * 60 * 1000).toISOString(),
    completionTimeSeconds: 840, // 14m 00s
    status: 'submitted'
  },
  {
    id: 'sub-sample-3',
    userId: 'user-priya-03',
    displayName: 'Priya Mukherjee',
    quizId: 'quiz-week-1-2026',
    answers: {},
    correctAnswers: 18,
    wrongAnswers: 2,
    unanswered: 0,
    score: 18,
    totalQuestions: 20,
    startTime: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
    submitTime: new Date(Date.now() - 79 * 60 * 1000).toISOString(),
    completionTimeSeconds: 660, // 11m 00s
    status: 'submitted'
  },
  {
    id: 'sub-sample-4',
    userId: 'user-suman-04',
    displayName: 'Suman Ghosh',
    quizId: 'quiz-week-1-2026',
    answers: {},
    correctAnswers: 18,
    wrongAnswers: 2,
    unanswered: 0,
    score: 18,
    totalQuestions: 20,
    startTime: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
    submitTime: new Date(Date.now() - 106 * 60 * 1000).toISOString(),
    completionTimeSeconds: 840, // 14m 00s
    status: 'submitted'
  },
  {
    id: 'sub-sample-5',
    userId: 'user-arjun-05',
    displayName: 'Arjun Das',
    quizId: 'quiz-week-1-2026',
    answers: {},
    correctAnswers: 17,
    wrongAnswers: 3,
    unanswered: 0,
    score: 17,
    totalQuestions: 20,
    startTime: new Date(Date.now() - 180 * 60 * 1000).toISOString(),
    submitTime: new Date(Date.now() - 168 * 60 * 1000).toISOString(),
    completionTimeSeconds: 720,
    status: 'submitted'
  }
];

// In-Memory Storage Cache
let quizzesCache: WeeklyQuiz[] = [];
let submissionsCache: WeeklyQuizSubmission[] = [];
let subscriptionsCache: QuizReminderSubscription[] = [];
let alertsCache: QuizNotificationAlert[] = [];
let questionBankCache: MCQQuestion[] = [];

// Load state from file or initialize
export function initializeStore() {
  try {
    if (fs.existsSync(QUIZZES_FILE)) {
      const data = fs.readFileSync(QUIZZES_FILE, 'utf-8');
      const loaded: WeeklyQuiz[] = JSON.parse(data);
      if (Array.isArray(loaded) && loaded.length > 0) {
        quizzesCache = loaded;
      }
    }
  } catch (e) {
    console.error('Error loading quizzes file:', e);
  }

  // Ensure default/sample quizzes are present
  if (!quizzesCache || quizzesCache.length === 0) {
    quizzesCache = [...SAMPLE_QUIZZES_LIST];
    saveQuizzesToFile();
  } else {
    // If only 1 quiz exists, add the evening/morning samples for rich multi-quiz support
    if (quizzesCache.length === 1 && !quizzesCache.some(q => q.id === 'quiz-evening-today-2026')) {
      quizzesCache = [...SAMPLE_QUIZZES_LIST, ...quizzesCache.filter(q => q.id !== 'quiz-week-1-2026')];
      saveQuizzesToFile();
    }
  }

  try {
    if (fs.existsSync(SUBMISSIONS_FILE)) {
      const data = fs.readFileSync(SUBMISSIONS_FILE, 'utf-8');
      submissionsCache = JSON.parse(data);
    }
  } catch (e) {
    console.error('Error loading submissions file:', e);
  }

  if (!submissionsCache || submissionsCache.length === 0) {
    submissionsCache = INITIAL_SUBMISSIONS;
    saveSubmissionsToFile();
  }

  try {
    if (fs.existsSync(SUBSCRIPTIONS_FILE)) {
      const data = fs.readFileSync(SUBSCRIPTIONS_FILE, 'utf-8');
      subscriptionsCache = JSON.parse(data);
    }
  } catch (e) {
    subscriptionsCache = [];
  }

  try {
    if (fs.existsSync(ALERTS_FILE)) {
      const data = fs.readFileSync(ALERTS_FILE, 'utf-8');
      alertsCache = JSON.parse(data);
    }
  } catch (e) {
    alertsCache = [];
  }

  try {
    if (fs.existsSync(QUESTION_BANK_FILE)) {
      const data = fs.readFileSync(QUESTION_BANK_FILE, 'utf-8');
      questionBankCache = JSON.parse(data);
    }
  } catch (e) {
    questionBankCache = [];
  }

  if (!questionBankCache || questionBankCache.length === 0) {
    questionBankCache = [...INITIAL_WEEK_1_QUESTIONS];
    saveQuestionBankToFile();
  }
}

function saveQuizzesToFile() {
  try {
    fs.writeFileSync(QUIZZES_FILE, JSON.stringify(quizzesCache, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to save quizzes to file:', e);
  }
}

function saveSubmissionsToFile() {
  try {
    fs.writeFileSync(SUBMISSIONS_FILE, JSON.stringify(submissionsCache, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to save submissions to file:', e);
  }
}

function saveSubscriptionsToFile() {
  try {
    fs.writeFileSync(SUBSCRIPTIONS_FILE, JSON.stringify(subscriptionsCache, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to save subscriptions to file:', e);
  }
}

function saveAlertsToFile() {
  try {
    fs.writeFileSync(ALERTS_FILE, JSON.stringify(alertsCache.slice(-50), null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to save alerts to file:', e);
  }
}

function saveQuestionBankToFile() {
  try {
    fs.writeFileSync(QUESTION_BANK_FILE, JSON.stringify(questionBankCache, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to save question bank to file:', e);
  }
}

// Ensure initialized on module load
initializeStore();

// Dynamically compute status for public display
export function computeDynamicStatus(quiz: WeeklyQuiz): WeeklyQuizStatus {
  if (quiz.status === 'draft' || quiz.status === 'paused' || quiz.status === 'winner_announced') {
    return quiz.status;
  }
  if (quiz.winnerVerified) {
    return 'winner_announced';
  }

  try {
    const startDateTime = new Date(`${quiz.startDate}T${quiz.startTime || '10:00'}:00`);
    const endDateTime = new Date(`${quiz.endDate}T${quiz.endTime || '20:00'}:00`);
    const now = new Date();

    if (now < startDateTime) {
      return 'scheduled';
    } else if (now >= startDateTime && now <= endDateTime) {
      return 'live';
    } else {
      return 'ended';
    }
  } catch (e) {
    return quiz.status;
  }
}

// Getter Helpers
export function getAllQuizzes(): WeeklyQuiz[] {
  return quizzesCache;
}

export function getPublicQuizzesList(userId?: string) {
  const visible = quizzesCache.filter(q => !q.isArchived);

  return visible.map(q => {
    const dynStatus = computeDynamicStatus(q);
    const sanitized = getSanitizedQuiz({ ...q, status: dynStatus }, false);
    
    // Check if current user has attempted this quiz
    let userAttempt = null;
    let hasJoined = false;

    if (userId) {
      if (q.joinedUserIds && Array.isArray(q.joinedUserIds)) {
        hasJoined = q.joinedUserIds.includes(userId);
      }
      const sub = getUserSubmission(q.id, userId);
      if (sub) {
        userAttempt = {
          score: sub.score,
          totalQuestions: sub.totalQuestions,
          completionTimeSeconds: sub.completionTimeSeconds,
          submitTime: sub.submitTime
        };
      }
    }

    return {
      ...sanitized,
      userAttempt,
      hasJoined
    };
  });
}

// User Join Quiz Management
export function joinQuiz(params: {
  quizId: string;
  userId: string;
  displayName?: string;
  browserPushEnabled?: boolean;
}): { success: boolean; message: string; quiz?: WeeklyQuiz } {
  const { quizId, userId, displayName, browserPushEnabled } = params;
  const quiz = getQuizById(quizId);
  if (!quiz) {
    return { success: false, message: 'Quiz not found' };
  }

  if (!quiz.joinedUserIds) {
    quiz.joinedUserIds = [];
  }

  if (!quiz.joinedUserIds.includes(userId)) {
    quiz.joinedUserIds.push(userId);
    quiz.participantsCount = Math.max(quiz.participantsCount || 0, quiz.joinedUserIds.length);
    quiz.updatedAt = new Date().toISOString();
    saveQuizzesToFile();
  }

  // Register subscription for automatic push notification before quiz
  subscribeToQuizReminder({
    quizId,
    userId,
    userName: displayName || 'Learner',
    browserPushEnabled: browserPushEnabled !== false
  });

  return {
    success: true,
    message: '✓ আপনি সফলভাবে এই কুইজে যুক্ত হয়েছেন! কুইজ শুরুর পূর্বে নোটিফিকেশন পৌঁছে যাবে।',
    quiz: getSanitizedQuiz(quiz, false) as any
  };
}

export function hasUserJoined(quizId: string, userId: string): boolean {
  const quiz = getQuizById(quizId);
  if (!quiz || !quiz.joinedUserIds) return false;
  return quiz.joinedUserIds.includes(userId);
}

export function getQuizById(id: string): WeeklyQuiz | undefined {
  const quiz = quizzesCache.find(q => q.id === id);
  if (quiz) {
    quiz.status = computeDynamicStatus(quiz);
  }
  return quiz;
}

export function getCurrentActiveQuiz(): WeeklyQuiz | undefined {
  // Check live quizzes first
  for (const q of quizzesCache) {
    const dyn = computeDynamicStatus(q);
    if (dyn === 'live' && !q.isArchived) {
      return { ...q, status: 'live' };
    }
  }
  // Then scheduled/upcoming
  for (const q of quizzesCache) {
    const dyn = computeDynamicStatus(q);
    if (dyn === 'scheduled' && !q.isArchived) {
      return { ...q, status: 'scheduled' };
    }
  }
  // Fallback to first non-archived
  const nonArchived = quizzesCache.find(q => !q.isArchived);
  return nonArchived || quizzesCache[0];
}

// Reminder Subscriptions
export function subscribeToQuizReminder(subscription: {
  quizId: string;
  userId: string;
  userName?: string;
  phone?: string;
  browserPushEnabled?: boolean;
}): { success: boolean; message: string } {
  const existingIdx = subscriptionsCache.findIndex(
    s => s.quizId === subscription.quizId && s.userId === subscription.userId
  );

  const subData: QuizReminderSubscription = {
    id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    quizId: subscription.quizId,
    userId: subscription.userId,
    userName: subscription.userName || 'Learner',
    phone: subscription.phone?.trim(),
    browserPushEnabled: subscription.browserPushEnabled !== false,
    createdAt: new Date().toISOString()
  };

  if (existingIdx >= 0) {
    subscriptionsCache[existingIdx] = subData;
  } else {
    subscriptionsCache.push(subData);
  }

  saveSubscriptionsToFile();
  return { 
    success: true, 
    message: 'কুইজ আরম্ভ হওয়ার ১০ মিনিট আগে আপনার ফোনে মেসেজ এবং ডিভাইসে অ্যালার্ট পৌঁছে যাবে।' 
  };
}

export function getQuizSubscriptions(quizId: string): QuizReminderSubscription[] {
  return subscriptionsCache.filter(s => s.quizId === quizId);
}

// Alerts and 10-Minute Warnings
export function getRecentNotificationAlerts(): QuizNotificationAlert[] {
  const oneHourAgo = Date.now() - 60 * 60 * 1000;
  return alertsCache.filter(a => new Date(a.timestamp).getTime() > oneHourAgo);
}

export function triggerQuizNotification10Min(quizId: string, customMessage?: string): { success: boolean; alert?: QuizNotificationAlert } {
  const quiz = getQuizById(quizId);
  if (!quiz) return { success: false };

  const reminderMinutes = quiz.notificationReminderMinutes || 10;
  const message = customMessage || quiz.notificationMessage || `⏰ কুইজ সতর্কতা: "${quiz.title}" শুরু হতে মাত্র ${reminderMinutes} মিনিট বাকি! অ্যাপে প্রবেশ করে প্রস্তুত থাকুন।`;

  const alert: QuizNotificationAlert = {
    id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    quizId: quiz.id,
    quizTitle: quiz.notificationTitle || quiz.title,
    startTime: quiz.startTime,
    startDate: quiz.startDate,
    message,
    timestamp: new Date().toISOString(),
    type: '10_min_warning'
  };

  alertsCache.push(alert);
  saveAlertsToFile();

  quiz.notification10MinSent = true;
  saveQuizzesToFile();

  const subs = getQuizSubscriptions(quizId);
  console.log(`[QUIZ REMINDER ALERT] Broadcasted for "${quiz.title}" to ${subs.length} joined users (${reminderMinutes} mins before start). Push notification simulated.`);

  return { success: true, alert };
}

// Automated Reminder Checker (Runs periodically)
export function checkAndTriggerUpcoming10MinAlerts() {
  const now = new Date();
  const settings = getAdminSettings();
  if (settings.enable10MinAlerts === false) return;

  for (const quiz of quizzesCache) {
    if (quiz.isArchived || quiz.status === 'ended' || quiz.status === 'draft' || quiz.notification10MinSent) {
      continue;
    }

    if (quiz.notificationReminderEnabled === false) {
      continue;
    }

    try {
      const startDateTime = new Date(`${quiz.startDate}T${quiz.startTime || '10:00'}:00`);
      const diffMs = startDateTime.getTime() - now.getTime();
      const diffMins = diffMs / (1000 * 60);
      const reminderMins = quiz.notificationReminderMinutes || 10;

      // Trigger when within reminder interval
      if (diffMins <= reminderMins && diffMins > 0) {
        console.log(`[AUTO-TRIGGER] Quiz "${quiz.title}" is ${Math.round(diffMins)} minutes away (trigger threshold: ${reminderMins}m)! Sending reminder notification...`);
        triggerQuizNotification10Min(quiz.id);
      }
    } catch (e) {
      console.warn('Error evaluating reminder alert for quiz:', quiz.id, e);
    }
  }
}

// Run auto-checker every 30 seconds
setInterval(() => {
  try {
    checkAndTriggerUpcoming10MinAlerts();
  } catch (e) {}
}, 30000);

export function getSanitizedQuiz(quiz: WeeklyQuiz, isTakingQuiz = false) {
  // During taking quiz, omit correctOptionIndex and explanations to prevent cheating
  // Also strip winnerClaimInfo for privacy on public requests
  const sanitized = {
    ...quiz,
    questions: quiz.questions.map((q, idx) => ({
      id: q.id || `q-${idx}`,
      subject: q.subject,
      question: q.question,
      options: q.options,
      difficulty: q.difficulty,
      // If taking quiz, hide answers
      ...(isTakingQuiz ? {} : {
        correctOptionIndex: q.correctOptionIndex,
        explanation: q.explanation,
        shortConcept: q.shortConcept,
        rememberPoint: q.rememberPoint
      })
    }))
  };

  delete sanitized.winnerClaimInfo;
  if (sanitized.winner) {
    delete sanitized.winner.claimInfo;
  }

  return sanitized;
}

export function getAllSubmissions(): WeeklyQuizSubmission[] {
  return submissionsCache;
}

export function getQuizSubmissions(quizId: string): WeeklyQuizSubmission[] {
  return submissionsCache.filter(s => s.quizId === quizId);
}

export function getUserSubmission(quizId: string, userId: string): WeeklyQuizSubmission | undefined {
  return submissionsCache.find(s => s.quizId === quizId && s.userId === userId);
}

// Calculate Leaderboard rankings
export function calculateLeaderboard(quizId: string, currentUserId?: string): {
  leaderboard: WeeklyQuizLeaderboardEntry[];
  winner?: WeeklyQuizWinner;
  totalParticipants: number;
} {
  const quiz = getQuizById(quizId);
  const submissions = getQuizSubmissions(quizId);

  // Sort logic:
  // 1. Score DESC (Highest score wins)
  // 2. completionTimeSeconds ASC (Faster completion wins)
  // 3. submitTime ASC
  const sorted = [...submissions].sort((a, b) => {
    if (b.score !== a.score) {
      return b.score - a.score;
    }
    if (a.completionTimeSeconds !== b.completionTimeSeconds) {
      return a.completionTimeSeconds - b.completionTimeSeconds;
    }
    return new Date(a.submitTime).getTime() - new Date(b.submitTime).getTime();
  });

  const leaderboard: WeeklyQuizLeaderboardEntry[] = sorted.map((sub, index) => ({
    rank: index + 1,
    userId: sub.userId,
    displayName: sub.displayName || `Participant #${index + 1}`,
    score: sub.score,
    totalQuestions: sub.totalQuestions,
    completionTimeSeconds: sub.completionTimeSeconds,
    submitTime: sub.submitTime,
    isCurrentUser: currentUserId ? sub.userId === currentUserId : false,
    isWinner: index === 0 && (quiz?.winnerVerified || quiz?.status === 'winner_announced')
  }));

  // Return winner if recorded or top rank if announced
  const winner = quiz?.winner || (sorted.length > 0 && quiz?.winnerVerified ? {
    userId: sorted[0].userId,
    displayName: sorted[0].displayName,
    score: sorted[0].score,
    totalQuestions: sorted[0].totalQuestions,
    completionTimeSeconds: sorted[0].completionTimeSeconds,
    rank: 1,
    status: quiz.prizeStatus,
    announcedAt: quiz.updatedAt
  } : undefined);

  return {
    leaderboard,
    winner,
    totalParticipants: submissions.length
  };
}

// Record a new Quiz Submission with Server-side score validation
export function recordSubmission(params: {
  quizId: string;
  userId: string;
  displayName: string;
  answers: Record<number, number>;
  startTime: string;
  clientTimeTakenSeconds?: number;
}): {
  submission: WeeklyQuizSubmission;
  rank: number;
  totalParticipants: number;
  reviewQuestions: MCQQuestion[];
} {
  const { quizId, userId, displayName, answers, startTime, clientTimeTakenSeconds } = params;
  const quiz = getQuizById(quizId);

  if (!quiz) {
    throw new Error('Quiz not found');
  }

  // Check if user already submitted
  const existing = getUserSubmission(quizId, userId);
  if (existing) {
    const { leaderboard, totalParticipants } = calculateLeaderboard(quizId, userId);
    const userRank = leaderboard.find(l => l.userId === userId)?.rank || 1;
    return {
      submission: existing,
      rank: userRank,
      totalParticipants,
      reviewQuestions: quiz.questions
    };
  }

  // Server-side timing validation
  const startTs = new Date(startTime).getTime();
  const nowTs = Date.now();
  const calculatedTimeTaken = Math.max(5, Math.round((nowTs - startTs) / 1000));
  const completionTimeSeconds = clientTimeTakenSeconds && clientTimeTakenSeconds > 0 
    ? Math.min(clientTimeTakenSeconds, calculatedTimeTaken + 10) 
    : calculatedTimeTaken;

  // Server-side Score Calculation against true answer keys
  let correctAnswers = 0;
  let wrongAnswers = 0;
  let unanswered = 0;

  quiz.questions.forEach((q, idx) => {
    const chosen = answers[idx];
    if (chosen === undefined || chosen === null || chosen === -1) {
      unanswered++;
    } else if (chosen === q.correctOptionIndex) {
      correctAnswers++;
    } else {
      wrongAnswers++;
    }
  });

  const marksPerQ = quiz.marksPerQuestion || 1;
  const negMarks = quiz.negativeMarks || 0.25;
  const rawScore = quiz.negativeMarking
    ? (correctAnswers * marksPerQ) - (wrongAnswers * negMarks)
    : correctAnswers * marksPerQ;
  const score = Math.max(0, Math.round(rawScore * 100) / 100);

  const newSubmission: WeeklyQuizSubmission = {
    id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    userId,
    displayName: displayName || 'Learner',
    quizId,
    answers,
    correctAnswers,
    wrongAnswers,
    unanswered,
    score,
    totalQuestions: quiz.questions.length,
    startTime: new Date(startTime).toISOString(),
    submitTime: new Date().toISOString(),
    completionTimeSeconds,
    status: 'submitted'
  };

  submissionsCache.push(newSubmission);
  saveSubmissionsToFile();

  // Update participant count in quiz
  quiz.participantsCount = getQuizSubmissions(quizId).length;
  quiz.updatedAt = new Date().toISOString();
  saveQuizzesToFile();

  const { leaderboard, totalParticipants } = calculateLeaderboard(quizId, userId);
  const userRank = leaderboard.find(l => l.userId === userId)?.rank || totalParticipants;

  return {
    submission: newSubmission,
    rank: userRank,
    totalParticipants,
    reviewQuestions: quiz.questions
  };
}

// Admin Management Functions
export function createOrUpdateQuiz(quizData: Partial<WeeklyQuiz>): WeeklyQuiz {
  const now = new Date().toISOString();
  if (quizData.id) {
    const idx = quizzesCache.findIndex(q => q.id === quizData.id);
    if (idx >= 0) {
      quizzesCache[idx] = {
        ...quizzesCache[idx],
        ...quizData,
        updatedAt: now
      };
      saveQuizzesToFile();
      return quizzesCache[idx];
    }
  }

  const newQuiz: WeeklyQuiz = {
    id: quizData.id || `quiz-week-${Date.now()}`,
    title: quizData.title || 'Weekly Mega Quiz Challenge',
    description: quizData.description || 'Participate and win weekly prizes!',
    startDate: quizData.startDate || now.split('T')[0],
    startTime: quizData.startTime || '10:00',
    endDate: quizData.endDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endTime: quizData.endTime || '20:00',
    questionCount: quizData.questions?.length || quizData.questionCount || 20,
    timeLimit: quizData.timeLimit || 20,
    subjects: quizData.subjects || ['General Knowledge', 'Current Affairs', 'Mathematics'],
    targetLevel: quizData.targetLevel || 'Competitive Exam',
    language: quizData.language || 'bn',
    prizeName: quizData.prizeName || 'Premium Notebook Set',
    prizeDescription: quizData.prizeDescription || 'One premium notebook set for the winner',
    prizeImage: quizData.prizeImage || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
    eligibilityRules: quizData.eligibilityRules || [
      'One attempt per user',
      'Highest score with fastest time wins',
      'Winner is verified by admin'
    ],
    status: quizData.status || 'draft',
    questions: quizData.questions || INITIAL_WEEK_1_QUESTIONS,
    participantsCount: 0,
    winnerVerified: false,
    prizeStatus: 'Pending Verification',
    createdAt: now,
    updatedAt: now
  };

  quizzesCache.unshift(newQuiz);
  saveQuizzesToFile();
  return newQuiz;
}

export function deleteQuiz(id: string): boolean {
  const initialLen = quizzesCache.length;
  quizzesCache = quizzesCache.filter(q => q.id !== id);
  submissionsCache = submissionsCache.filter(s => s.quizId !== id);
  if (quizzesCache.length !== initialLen) {
    saveQuizzesToFile();
    saveSubmissionsToFile();
    return true;
  }
  return false;
}

export function setQuizStatus(id: string, status: WeeklyQuiz['status']): WeeklyQuiz | null {
  const quiz = getQuizById(id);
  if (!quiz) return null;
  quiz.status = status;
  quiz.updatedAt = new Date().toISOString();
  saveQuizzesToFile();
  return quiz;
}

export function verifyWinner(quizId: string, winnerUserId?: string): WeeklyQuiz | null {
  const quiz = getQuizById(quizId);
  if (!quiz) return null;

  const { leaderboard } = calculateLeaderboard(quizId);
  if (leaderboard.length === 0) return null;

  const targetWinnerEntry = winnerUserId 
    ? leaderboard.find(l => l.userId === winnerUserId) || leaderboard[0]
    : leaderboard[0];

  const winnerObj: WeeklyQuizWinner = {
    userId: targetWinnerEntry.userId,
    displayName: targetWinnerEntry.displayName,
    score: targetWinnerEntry.score,
    totalQuestions: targetWinnerEntry.totalQuestions,
    completionTimeSeconds: targetWinnerEntry.completionTimeSeconds,
    rank: targetWinnerEntry.rank,
    status: 'Winner Confirmed',
    announcedAt: new Date().toISOString()
  };

  quiz.winner = winnerObj;
  quiz.winnerVerified = true;
  quiz.prizeStatus = 'Winner Confirmed';
  quiz.status = 'winner_announced';
  quiz.updatedAt = new Date().toISOString();

  saveQuizzesToFile();
  return quiz;
}

export function updatePrizeStatus(quizId: string, prizeStatus: WeeklyQuiz['prizeStatus'], deliveryNotes?: string): WeeklyQuiz | null {
  const quiz = getQuizById(quizId);
  if (!quiz) return null;

  quiz.prizeStatus = prizeStatus;
  if (quiz.winner) {
    quiz.winner.status = prizeStatus;
    if (deliveryNotes) {
      quiz.winner.deliveryNotes = deliveryNotes;
    }
  }
  quiz.updatedAt = new Date().toISOString();
  saveQuizzesToFile();
  return quiz;
}

export function claimPrizeContactInfo(
  quizId: string,
  userId: string,
  claimInfo: {
    fullName: string;
    phone: string;
    address: string;
    pincode: string;
    state?: string;
    additionalNotes?: string;
  }
): { success: boolean; message: string; quiz?: WeeklyQuiz } {
  const quiz = getQuizById(quizId);
  if (!quiz) return { success: false, message: 'Quiz not found' };

  if (!quiz.winnerVerified || quiz.winner?.userId !== userId) {
    return { success: false, message: 'Unauthorized: Only the officially confirmed winner can submit delivery details.' };
  }

  const claimData = {
    fullName: claimInfo.fullName?.trim() || 'Winner',
    phone: claimInfo.phone?.trim() || '',
    address: claimInfo.address?.trim() || '',
    pincode: claimInfo.pincode?.trim() || '',
    state: claimInfo.state?.trim() || '',
    additionalNotes: claimInfo.additionalNotes?.trim() || '',
    submittedAt: new Date().toISOString()
  };

  quiz.winnerClaimInfo = claimData;
  if (quiz.winner) {
    quiz.winner.claimInfo = claimData;
    if (quiz.prizeStatus === 'Winner Confirmed' || quiz.prizeStatus === 'Pending Verification' || quiz.prizeStatus === 'Prize Pending') {
      quiz.prizeStatus = 'Prize Processing';
      quiz.winner.status = 'Prize Processing';
    }
  }
  quiz.updatedAt = new Date().toISOString();
  saveQuizzesToFile();

  return { success: true, message: 'Winner delivery details registered successfully', quiz };
}

// Global Admin Settings Functions
let adminSettingsCache: AdminQuizGlobalSettings | null = null;

export function getAdminSettings(): AdminQuizGlobalSettings {
  if (adminSettingsCache) return adminSettingsCache;
  if (fs.existsSync(SETTINGS_FILE)) {
    try {
      const data = fs.readFileSync(SETTINGS_FILE, 'utf-8');
      adminSettingsCache = { ...DEFAULT_ADMIN_SETTINGS, ...JSON.parse(data) };
      return adminSettingsCache!;
    } catch (e) {
      console.warn('Error reading admin settings file:', e);
    }
  }
  adminSettingsCache = { ...DEFAULT_ADMIN_SETTINGS };
  return adminSettingsCache;
}

export function saveAdminSettings(settings: Partial<AdminQuizGlobalSettings>): AdminQuizGlobalSettings {
  const current = getAdminSettings();
  adminSettingsCache = { ...current, ...settings };
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(adminSettingsCache, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving admin settings:', e);
  }
  return adminSettingsCache;
}

// Duplicate a Quiz for future weeks
export function duplicateQuiz(id: string): WeeklyQuiz | null {
  const source = getQuizById(id);
  if (!source) return null;

  const now = new Date();
  const nextWeekStart = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const nextWeekEnd = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);

  const cloned: WeeklyQuiz = {
    ...source,
    id: `quiz-week-${Date.now()}`,
    title: `${source.title} (Copy)`,
    startDate: nextWeekStart.toISOString().split('T')[0],
    endDate: nextWeekEnd.toISOString().split('T')[0],
    status: 'draft',
    isArchived: false,
    participantsCount: 0,
    winner: undefined,
    winnerVerified: false,
    winnerClaimInfo: undefined,
    prizeStatus: 'Pending Verification',
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    questions: JSON.parse(JSON.stringify(source.questions || []))
  };

  quizzesCache.unshift(cloned);
  saveQuizzesToFile();
  return cloned;
}

// Extend quiz end time by specified hours or days
export function extendQuizTime(id: string, extendHours: number): WeeklyQuiz | null {
  const quiz = getQuizById(id);
  if (!quiz) return null;

  try {
    const currentEndDateTime = new Date(`${quiz.endDate}T${quiz.endTime || '20:00'}:00`);
    const newEndDateTime = new Date(currentEndDateTime.getTime() + extendHours * 60 * 60 * 1000);

    quiz.endDate = newEndDateTime.toISOString().split('T')[0];
    const hrs = String(newEndDateTime.getHours()).padStart(2, '0');
    const mins = String(newEndDateTime.getMinutes()).padStart(2, '0');
    quiz.endTime = `${hrs}:${mins}`;
    
    // If it was ended and extended, re-enable to live
    if (quiz.status === 'ended' || quiz.status === 'completed') {
      quiz.status = 'live';
    }
    
    quiz.updatedAt = new Date().toISOString();
    saveQuizzesToFile();
    return quiz;
  } catch (e) {
    console.error('Failed to extend quiz time:', e);
    return null;
  }
}

// Toggle Archive status
export function archiveQuiz(id: string, isArchived: boolean): WeeklyQuiz | null {
  const quiz = getQuizById(id);
  if (!quiz) return null;
  quiz.isArchived = isArchived;
  quiz.updatedAt = new Date().toISOString();
  saveQuizzesToFile();
  return quiz;
}

// Get full Admin Overview Statistics
export function getAdminOverviewStats(): AdminOverviewStats {
  const allQuizzes = getAllQuizzes();
  const allSubs = getAllSubmissions();
  
  const uniqueUsers = new Set<string>();
  allSubs.forEach(s => uniqueUsers.add(s.userId));

  const now = new Date();
  let activeQuizzesCount = 0;
  let upcomingQuizzesCount = 0;
  let completedQuizzesCount = 0;
  let draftQuizzesCount = 0;
  let totalQuestionsCount = 0;

  allQuizzes.forEach(q => {
    totalQuestionsCount += (q.questions?.length || 0);
    if (q.status === 'draft') {
      draftQuizzesCount++;
    } else if (q.status === 'live') {
      activeQuizzesCount++;
    } else if (q.status === 'scheduled' || q.status === 'published') {
      upcomingQuizzesCount++;
    } else if (q.status === 'ended' || q.status === 'completed' || q.status === 'winner_announced') {
      completedQuizzesCount++;
    }
  });

  const currentQuiz = getCurrentActiveQuiz() || allQuizzes[0];

  return {
    totalUsers: uniqueUsers.size,
    totalParticipants: allSubs.length,
    totalQuizzes: allQuizzes.length,
    activeQuizzesCount,
    upcomingQuizzesCount,
    completedQuizzesCount,
    draftQuizzesCount,
    totalQuestionsCount,
    currentQuiz,
    currentPrize: currentQuiz ? {
      name: currentQuiz.prizeName,
      description: currentQuiz.prizeDescription,
      image: currentQuiz.prizeImage,
      status: currentQuiz.prizeStatus
    } : undefined,
    recentSubmissions: allSubs.slice(-10).reverse()
  };
}

// Question Bank CRUD Operations
export function getQuestionBank(): MCQQuestion[] {
  return questionBankCache;
}

export function addQuestionToBank(question: MCQQuestion): MCQQuestion {
  const newQ: MCQQuestion = {
    ...question,
    id: question.id || `qb-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`
  };
  questionBankCache.unshift(newQ);
  saveQuestionBankToFile();
  return newQ;
}

export function updateQuestionInBank(id: string, question: Partial<MCQQuestion>): MCQQuestion | null {
  const idx = questionBankCache.findIndex(q => q.id === id);
  if (idx < 0) return null;
  questionBankCache[idx] = { ...questionBankCache[idx], ...question };
  saveQuestionBankToFile();
  return questionBankCache[idx];
}

export function deleteQuestionFromBank(id: string): boolean {
  const initialLen = questionBankCache.length;
  questionBankCache = questionBankCache.filter(q => q.id !== id);
  if (questionBankCache.length !== initialLen) {
    saveQuestionBankToFile();
    return true;
  }
  return false;
}

export function bulkAddQuestionsToBank(questions: MCQQuestion[]): { addedCount: number; total: number } {
  if (!Array.isArray(questions) || questions.length === 0) {
    return { addedCount: 0, total: questionBankCache.length };
  }

  const validQuestions = questions.map((q, i) => ({
    id: q.id || `qb-bulk-${Date.now()}-${i}`,
    question: q.question || 'Question text',
    options: Array.isArray(q.options) && q.options.length >= 2 ? q.options : ['Option A', 'Option B', 'Option C', 'Option D'],
    correctOptionIndex: typeof q.correctOptionIndex === 'number' ? q.correctOptionIndex : 0,
    explanation: q.explanation || 'Detailed explanation',
    shortConcept: q.shortConcept || '',
    rememberPoint: q.rememberPoint || '',
    subject: q.subject || 'General Knowledge',
    topic: q.topic || '',
    difficulty: q.difficulty || 'Medium'
  }));

  questionBankCache = [...validQuestions, ...questionBankCache];
  saveQuestionBankToFile();
  return { addedCount: validQuestions.length, total: questionBankCache.length };
}
