import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getDashboardOverview, getDb, getPasswordResetRequests } from "./db";
import { WORK_ROLES, passwordResetRequests, schedules, users, workspaceAccounts } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { createLocalSession, hashPassword, localCookieOptions, localSessionCookieName, readLocalSession, verifyPassword } from "./localAuth";
import { getWorkspaceAccountById, getWorkspaceAccountByIdentifier } from "./db";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "owner" && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Owner or admin access is required." });
  return next();
});
const ownerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "owner") throw new TRPCError({ code: "FORBIDDEN", message: "Only the workspace owner can manage accounts." });
  return next();
});
const usernameSchema = z.string().trim().min(1).max(120).transform(value => value.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9._-]/g, "")).refine(value => value.length >= 3 && value.length <= 64, { message: "Username must contain at least 3 usable characters." });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    localLogin: publicProcedure.input(z.object({ identifier: z.string().trim().min(3).max(320), password: z.string().min(8).max(128), rememberMe: z.boolean().default(false) })).mutation(async ({ input, ctx }) => {
      const account = await getWorkspaceAccountByIdentifier(input.identifier);
      if (!account?.passwordHash || !(await verifyPassword(input.password, account.passwordHash))) throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect." });
      const secure = getSessionCookieOptions(ctx.req).secure;
      ctx.res.cookie(localSessionCookieName(), createLocalSession(account.id, input.rememberMe), localCookieOptions(input.rememberMe, secure));
      return { success: true } as const;
    }),
    requestPasswordReset: publicProcedure.input(z.object({ identifier: z.string().trim().min(3).max(320) })).mutation(async ({ input }) => {
      const db = await getDb();
      if (db) await db.insert(passwordResetRequests).values({ identifier: input.identifier.toLowerCase() });
      return { success: true } as const;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(localSessionCookieName(), { ...localCookieOptions(true, getSessionCookieOptions(ctx.req).secure), maxAge: 0 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    overview: protectedProcedure.query(async ({ ctx }) => ({ viewer: { id: ctx.user.id, name: ctx.user.name, email: ctx.user.email, role: ctx.user.role }, ...(await getDashboardOverview()) })),
    updateMyName: protectedProcedure.input(z.object({ name: z.string().trim().min(2).max(120) })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      await db.update(users).set({ name: input.name }).where(eq(users.id, ctx.user.id));
      if (ctx.user.openId.startsWith("local:")) {
        const accountId = Number(ctx.user.openId.slice("local:".length));
        if (Number.isInteger(accountId) && accountId > 0) await db.update(workspaceAccounts).set({ name: input.name }).where(eq(workspaceAccounts.id, accountId));
      }
      return { success: true, name: input.name } as const;
    }),
    changeMyPassword: protectedProcedure.input(z.object({ currentPassword: z.string().min(8).max(128), newPassword: z.string().min(8).max(128) })).mutation(async ({ input, ctx }) => {
      const account = ctx.user.openId.startsWith("local:") ? await getWorkspaceAccountById(Number(ctx.user.openId.slice("local:".length))) : await getWorkspaceAccountByIdentifier(ctx.user.email ?? "");
      if (!account?.passwordHash || !(await verifyPassword(input.currentPassword, account.passwordHash))) throw new TRPCError({ code: "UNAUTHORIZED", message: "Current password is incorrect." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      await db.update(workspaceAccounts).set({ passwordHash: await hashPassword(input.newPassword) }).where(eq(workspaceAccounts.id, account.id));
      return { success: true } as const;
    }),
    passwordResetRequests: ownerProcedure.query(() => getPasswordResetRequests()),
    updateUserRole: adminProcedure.input(z.object({ userId: z.number().int().positive(), role: z.enum(WORK_ROLES) })).mutation(async ({ input, ctx }) => {
      if (input.userId === ctx.user.id && input.role !== "owner" && ctx.user.role === "owner") throw new TRPCError({ code: "BAD_REQUEST", message: "The owner cannot remove their own owner role." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      await db.update(users).set({ role: input.role }).where(eq(users.id, input.userId));
      return { success: true } as const;
    }),
    createSchedule: ownerProcedure.input(z.object({
      title: z.string().trim().min(2).max(160),
      location: z.string().trim().min(2).max(160),
      shift: z.string().trim().min(2).max(80),
      startAt: z.string().datetime(),
      endAt: z.string().datetime(),
      assigneeAccountId: z.number().int().positive(),
    })).mutation(async ({ input, ctx }) => {
      const startAt = new Date(input.startAt);
      const endAt = new Date(input.endAt);
      if (endAt <= startAt) throw new TRPCError({ code: "BAD_REQUEST", message: "End time must be after start time." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      const assignee = await db.select().from(workspaceAccounts).where(eq(workspaceAccounts.id, input.assigneeAccountId)).limit(1);
      if (!assignee[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Assigned account was not found." });
      await db.insert(schedules).values({
        title: input.title,
        location: input.location,
        shift: input.shift,
        startAt,
        endAt,
        status: "scheduled",
        assigneeName: assignee[0].name,
        assigneeAccountId: assignee[0].id,
      });
      return { success: true } as const;
    }),
    createAccount: ownerProcedure.input(z.object({ username: usernameSchema, name: z.string().trim().min(2).max(120), email: z.string().trim().email(), password: z.string().min(8).max(128), role: z.enum(WORK_ROLES).default("trainee") })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      try {
        const result = await db.insert(workspaceAccounts).values({ username: input.username.toLowerCase(), name: input.name, email: input.email.toLowerCase(), passwordHash: await hashPassword(input.password), role: input.role, createdBy: ctx.user.id });
        const accountId = Number(result[0].insertId);
        await db.insert(users).values({ openId: `local:${accountId}`, name: input.name, email: input.email.toLowerCase(), loginMethod: "local", role: input.role });
        return { success: true, id: accountId } as const;
      } catch (error: any) {
        if (error?.code === "ER_DUP_ENTRY") throw new TRPCError({ code: "CONFLICT", message: "That username or email is already in use." });
        throw error;
      }
    }),
    setAccountPassword: ownerProcedure.input(z.object({ accountId: z.number().int().positive(), password: z.string().min(8).max(128) })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      const result = await db.update(workspaceAccounts).set({ passwordHash: await hashPassword(input.password) }).where(eq(workspaceAccounts.id, input.accountId));
      if (!result[0].affectedRows) throw new TRPCError({ code: "NOT_FOUND", message: "Workspace account was not found." });
      return { success: true } as const;
    }),
    resolvePasswordReset: ownerProcedure.input(z.object({ requestId: z.number().int().positive(), accountId: z.number().int().positive(), password: z.string().min(8).max(128) })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      const account = await db.select({ id: workspaceAccounts.id }).from(workspaceAccounts).where(eq(workspaceAccounts.id, input.accountId)).limit(1);
      if (!account[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Workspace account was not found." });
      await db.update(workspaceAccounts).set({ passwordHash: await hashPassword(input.password) }).where(eq(workspaceAccounts.id, input.accountId));
      await db.update(passwordResetRequests).set({ status: "resolved", resolvedAt: new Date(), resolvedBy: ctx.user.id }).where(eq(passwordResetRequests.id, input.requestId));
      return { success: true } as const;
    }),
    removeAccount: ownerProcedure.input(z.object({ accountId: z.number().int().positive() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is unavailable." });
      await db.delete(workspaceAccounts).where(eq(workspaceAccounts.id, input.accountId));
      await db.delete(users).where(eq(users.openId, `local:${input.accountId}`));
      return { success: true } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
