import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  createCustomer,
  createReceipt,
  deleteCustomer,
  deleteReceipt,
  listCustomers,
  listReceipts,
  updateCustomer,
  updateReceipt,
} from "./db";

const customerInput = z.object({
  name: z.string().trim().min(1, "Customer name is required.").max(120),
  phone: z.string().trim().max(40).optional().transform(value => value || undefined),
});

const receiptInput = z.object({
  customerId: z.number().int().positive(),
  receiptDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a valid receipt date."),
  quantity: z.number().int().min(1).max(9999),
  note: z.string().trim().max(255).optional().transform(value => value || undefined),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  customers: router({
    list: publicProcedure.query(() => listCustomers()),
    create: publicProcedure.input(customerInput).mutation(({ input }) => createCustomer(input)),
    update: publicProcedure
      .input(z.object({ id: z.number().int().positive(), data: customerInput }))
      .mutation(({ input }) => updateCustomer(input.id, input.data)),
    remove: publicProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ input }) => deleteCustomer(input.id)),
  }),
  receipts: router({
    list: publicProcedure
      .input(z.object({ startDate: z.string().optional(), endDate: z.string().optional() }))
      .query(({ input }) => listReceipts(input.startDate, input.endDate)),
    create: publicProcedure.input(receiptInput).mutation(({ input }) => createReceipt(input)),
    update: publicProcedure
      .input(z.object({ id: z.number().int().positive(), data: receiptInput }))
      .mutation(({ input }) => updateReceipt(input.id, input.data)),
    remove: publicProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ input }) => deleteReceipt(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
