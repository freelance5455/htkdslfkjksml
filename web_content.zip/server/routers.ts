import { and, desc, eq, gt } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { adminAccounts, adminChallenges, adminInvitations, adminSessions, announcements, auditEvents, bootstrapClaims, featureSettings, releases } from "../drizzle/schema";
import { getDb } from "./db";
import { adminProcedure, publicProcedure, rolesProcedure, router } from "./_core/trpc";
import {
  adminCount, allowAttempts, clearMfaCookie, deleteInvitation, establishAdminSession, encryptTotpForStorage,
  getChallenge, hashToken, isValidEmail, isValidNewPassword, issueRecoveryCodes, makeCredential, matchesRecoveryCode,
  normalizeEmail, removeChallenge, revokeCurrentSession, startMfaChallenge, verifyAccountPassword,
  verifyBootstrapToken, verifySecondFactor, verifyTotp,
} from "./admin-auth";
import { demoIncidents, demoOverview, demoSupport, demoUsage } from "./demo-data";
import { TRPCError } from "@trpc/server";

const ownerAdmin = ["owner", "admin"] as const;
const allReaders = ["owner", "admin", "analyst", "support"] as const;
const metricReaders = ["owner", "admin", "analyst"] as const;

async function writeAudit(actorEmail: string, action: string, resourceType: string, summary: string) {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
  await db.insert(auditEvents).values({ actorEmail, action, resourceType, summary: summary.slice(0, 500) });
}

const base32Pattern = /^[A-Z2-7]{24,64}$/i;
const newPassword = z.string().min(12).max(128);
const otp = z.string().regex(/^\d{6}$/);
function changedRows(result: unknown) {
  const value = Array.isArray(result) ? result[0] : result;
  return (value as { affectedRows?: number; rowsAffected?: number } | undefined)?.affectedRows
    ?? (value as { rowsAffected?: number } | undefined)?.rowsAffected ?? 0;
}

export const appRouter = router({
  auth: router({
    bootstrapStatus: publicProcedure.query(async () => ({
      initialized: (await adminCount()) > 0,
      setupAvailable: Boolean(process.env.ADMIN_SETUP_TOKEN && process.env.ADMIN_SETUP_TOKEN.length >= 32 && process.env.TOTP_ENCRYPTION_KEY && process.env.TOTP_ENCRYPTION_KEY.length >= 32),
    })),
    me: publicProcedure.query(({ ctx }) => ctx.admin),
    bootstrap: publicProcedure.input(z.object({
      setupToken: z.string().min(1).max(256), email: z.string().email().max(320), displayName: z.string().trim().min(1).max(120),
      password: newPassword, totpSecret: z.string().regex(base32Pattern), code: otp,
    })).mutation(async ({ input, ctx }) => {
      if (!await verifyBootstrapToken(input.setupToken)) throw new TRPCError({ code: "FORBIDDEN", message: "The setup token is invalid or not configured." });
      if (!verifyTotp(input.totpSecret, input.code)) throw new TRPCError({ code: "BAD_REQUEST", message: "That authenticator code is not valid yet. Check your phone clock and try again." });
      if (await adminCount() > 0) throw new TRPCError({ code: "CONFLICT", message: "Initial owner setup is already complete." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const email = normalizeEmail(input.email);
      const credentials = await makeCredential(input.password);
      const codes = issueRecoveryCodes();
      try {
        const created = await db.transaction(async tx => {
          await tx.insert(bootstrapClaims).values({ claim: "initial-owner" });
          await tx.insert(adminAccounts).values({
            email, displayName: input.displayName.trim(), ...credentials,
            totpCiphertext: encryptTotpForStorage(input.totpSecret.toUpperCase()), recoveryCodes: codes.hashes, role: "owner",
          });
          const rows = await tx.select().from(adminAccounts).where(eq(adminAccounts.email, email)).limit(1);
          await tx.insert(auditEvents).values({ actorEmail: email, action: "owner.bootstrap", resourceType: "admin_account", summary: "Initial owner account created with two-factor authentication." });
          return rows[0];
        });
        if (!created) throw new Error("Owner account could not be loaded after creation.");
        await establishAdminSession(ctx.res, { id: created.id, email: created.email, displayName: created.displayName, role: created.role });
        return { admin: { id: created.id, email: created.email, displayName: created.displayName, role: created.role }, recoveryCodes: codes.codes };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({ code: "CONFLICT", message: "Owner setup is no longer available. Refresh to check its status." });
      }
    }),
    login: publicProcedure.input(z.object({ email: z.string().email().max(320), password: z.string().min(1).max(128) })).mutation(async ({ input, ctx }) => {
      const email = normalizeEmail(input.email);
      const key = `${ctx.req.ip ?? "unknown"}:${email}`;
      if (!allowAttempts(key, 12)) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Wait ten minutes and try again." });
      const admin = await verifyAccountPassword(email, input.password);
      if (!admin) throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect, or sign-in is temporarily locked." });
      await startMfaChallenge(ctx.res, admin.id);
      return { secondFactorRequired: true };
    }),
    verifySecondFactor: publicProcedure.input(z.object({ code: z.string().min(6).max(80) })).mutation(async ({ ctx, input }) => {
      const challenge = await getChallenge(ctx.req);
      if (!challenge) { clearMfaCookie(ctx.res); throw new TRPCError({ code: "UNAUTHORIZED", message: "Your sign-in challenge expired. Start again." }); }
      const result = await verifySecondFactor(challenge.adminId, input.code);
      if (!result) {
        await import("./admin-auth").then(({ recordChallengeFailure }) => recordChallengeFailure(challenge.tokenHash));
        throw new TRPCError({ code: "UNAUTHORIZED", message: "That verification or recovery code is not valid." });
      }
      if (!await removeChallenge(challenge.tokenHash)) {
        clearMfaCookie(ctx.res);
        throw new TRPCError({ code: "UNAUTHORIZED", message: "This sign-in challenge has already been used. Start again." });
      }
      clearMfaCookie(ctx.res);
      await establishAdminSession(ctx.res, { id: result.admin.id, email: result.admin.email, displayName: result.admin.displayName, role: result.admin.role });
      const db = await getDb();
      if (db) {
        await db.update(adminAccounts).set({ lastLoginAt: new Date() }).where(eq(adminAccounts.id, result.admin.id));
        await db.insert(auditEvents).values({ actorEmail: result.admin.email, action: "auth.login", resourceType: "admin_session", summary: result.usedRecoveryCode ? "Admin signed in using a one-time recovery code." : "Admin signed in with two-factor authentication." });
      }
      return { admin: { id: result.admin.id, email: result.admin.email, displayName: result.admin.displayName, role: result.admin.role }, recoveryCodesRemaining: JSON.parse(result.recoveryCodes).length };
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => { await revokeCurrentSession(ctx.req, ctx.res); return { success: true }; }),
    invitationInfo: publicProcedure.input(z.object({ token: z.string().min(20).max(128) })).query(async ({ input }) => {
      const invitation = await (await import("./admin-auth")).invitationByToken(input.token);
      return invitation ? { valid: true, email: invitation.email, role: invitation.role, resetting: Boolean(invitation.resetAdminId) } : { valid: false };
    }),
    acceptInvitation: publicProcedure.input(z.object({
      token: z.string().min(20).max(128), email: z.string().email().max(320), displayName: z.string().trim().min(1).max(120),
      password: newPassword, totpSecret: z.string().regex(base32Pattern), code: otp,
    })).mutation(async ({ input, ctx }) => {
      const { invitationByToken } = await import("./admin-auth");
      const invitation = await invitationByToken(input.token);
      const email = normalizeEmail(input.email);
      if (!invitation || invitation.email !== email) throw new TRPCError({ code: "FORBIDDEN", message: "This invitation is invalid, expired, or assigned to another email." });
      if (!verifyTotp(input.totpSecret, input.code)) throw new TRPCError({ code: "BAD_REQUEST", message: "That authenticator code is not valid yet." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const credentials = await makeCredential(input.password);
      const codes = issueRecoveryCodes();
      try {
        const created = await db.transaction(async tx => {
          const claimed = await tx.delete(adminInvitations).where(and(eq(adminInvitations.tokenHash, invitation.tokenHash), gt(adminInvitations.expiresAt, new Date())));
          if (changedRows(claimed) !== 1) throw new Error("Invitation has already been used or expired.");
          let createdAdmin;
          if (invitation.resetAdminId) {
            const existing = await tx.select().from(adminAccounts).where(eq(adminAccounts.id, invitation.resetAdminId)).limit(1);
            if (!existing[0] || existing[0].email !== email || existing[0].role === "owner") throw new Error("Invalid access reset target.");
            await tx.update(adminAccounts).set({
              displayName: input.displayName.trim(), ...credentials,
              totpCiphertext: encryptTotpForStorage(input.totpSecret.toUpperCase()), recoveryCodes: codes.hashes,
              failedAttempts: 0, lockedUntil: null, isActive: true, lastLoginAt: new Date(),
            }).where(eq(adminAccounts.id, invitation.resetAdminId));
            await tx.delete(adminSessions).where(eq(adminSessions.adminId, invitation.resetAdminId));
            await tx.insert(auditEvents).values({ actorEmail: invitation.createdBy, action: "team.access_reset_completed", resourceType: "admin_account", summary: `Access credentials reset for ${email}; previous sessions revoked.` });
          } else {
            await tx.insert(adminAccounts).values({ email, displayName: input.displayName.trim(), ...credentials, totpCiphertext: encryptTotpForStorage(input.totpSecret.toUpperCase()), recoveryCodes: codes.hashes, role: invitation.role });
            await tx.insert(auditEvents).values({ actorEmail: invitation.createdBy, action: "team.invitation_accepted", resourceType: "admin_account", summary: `An invited ${invitation.role} administrator enrolled with two-factor authentication.` });
          }
          const rows = await tx.select().from(adminAccounts).where(eq(adminAccounts.email, email)).limit(1);
          createdAdmin = rows[0];
          return createdAdmin;
        });
        if (!created) throw new Error("Account could not be loaded.");
        await establishAdminSession(ctx.res, { id: created.id, email: created.email, displayName: created.displayName, role: created.role });
        return { admin: { id: created.id, email: created.email, displayName: created.displayName, role: created.role }, recoveryCodes: codes.codes };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({ code: "CONFLICT", message: "This invitation was already used or the account already exists." });
      }
    }),
  }),

  dashboard: router({
    overview: rolesProcedure(...metricReaders).query(() => demoOverview),
    incidents: rolesProcedure(...metricReaders).query(() => ({ dataMode: "DEMO", privacy: "No end-user financial records are included.", items: demoIncidents })),
    support: rolesProcedure("owner", "admin", "support").query(() => ({ dataMode: "DEMO", privacy: "Anonymized sample text only; no user identity or financial records.", items: demoSupport })),
    usage: rolesProcedure(...metricReaders).query(() => demoUsage),
  }),

  configuration: router({
    listFeatures: rolesProcedure(...metricReaders).query(async () => {
      const defaults = [
        { key: "bill_reminders", label: "Bill reminders", description: "Scheduling and notification preferences." },
        { key: "debt_ledger", label: "Debt ledger", description: "Customer-facing debt tracking capability." },
        { key: "zakat_tools", label: "Zakat tools", description: "Customer-facing zakat calculator and guidance." },
        { key: "family_sharing", label: "Family sharing", description: "Shared household access for eligible plans." },
        { key: "premium_reports", label: "Premium reports", description: "Advanced reports included with Premium." },
        { key: "cloud_backup", label: "Cloud backup", description: "Optional encrypted backup capability." },
      ];
      const db = await getDb();
      const saved = db ? await db.select().from(featureSettings) : [];
      return defaults.map(feature => {
        const existing = saved.find(item => item.key === feature.key);
        return { ...feature, enabled: existing?.enabled ?? true, updatedAt: existing?.updatedAt ?? null, updatedBy: existing?.updatedBy ?? null };
      });
    }),
    setFeature: rolesProcedure(...ownerAdmin).input(z.object({ key: z.string().min(2).max(64), enabled: z.boolean() })).mutation(async ({ input, ctx }) => {
      const allowed = ["bill_reminders", "debt_ledger", "zakat_tools", "family_sharing", "premium_reports", "cloud_backup"];
      if (!allowed.includes(input.key)) throw new TRPCError({ code: "BAD_REQUEST", message: "Unknown feature." });
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const row = {
        bill_reminders: ["Bill reminders", "Scheduling and notification preferences."], debt_ledger: ["Debt ledger", "Customer-facing debt tracking capability."],
        zakat_tools: ["Zakat tools", "Customer-facing zakat calculator and guidance."], family_sharing: ["Family sharing", "Shared household access for eligible plans."],
        premium_reports: ["Premium reports", "Advanced reports included with Premium."], cloud_backup: ["Cloud backup", "Optional encrypted backup capability."],
      }[input.key] as [string, string];
      await db.insert(featureSettings).values({ key: input.key, label: row[0], description: row[1], enabled: input.enabled, updatedBy: ctx.admin.email }).onDuplicateKeyUpdate({ set: { enabled: input.enabled, updatedBy: ctx.admin.email, updatedAt: new Date() } });
      await writeAudit(ctx.admin.email, "feature.updated", "feature_flag", `${row[0]} set to ${input.enabled ? "on" : "off"}.`);
      return { saved: true };
    }),
    listAnnouncements: rolesProcedure(...metricReaders).query(async () => {
      const db = await getDb();
      return db ? db.select().from(announcements).orderBy(desc(announcements.createdAt)).limit(50) : [];
    }),
    createAnnouncement: rolesProcedure(...ownerAdmin).input(z.object({ title: z.string().trim().min(3).max(160), body: z.string().trim().min(5).max(3000), status: z.enum(["draft", "published"]) })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      await db.insert(announcements).values({ ...input, createdBy: ctx.admin.email, publishAt: input.status === "published" ? new Date() : null });
      await writeAudit(ctx.admin.email, `announcement.${input.status}`, "announcement", `Announcement “${input.title}” ${input.status}.`);
      return { saved: true };
    }),
  }),

  operations: router({
    listReleases: rolesProcedure(...metricReaders).query(async () => {
      const db = await getDb();
      const saved = db ? await db.select().from(releases).orderBy(desc(releases.createdAt)).limit(50) : [];
      return { dataMode: "DEMO + owner entries", items: [
        { id: "demo-1", version: "2.6.0", platform: "android", status: "live", notes: "Improved reminder reliability and Uzbek localization.", releaseDate: "2026-10-28T00:00:00.000Z", source: "DEMO" },
        { id: "demo-2", version: "2.5.3", platform: "ios", status: "review", notes: "Stability fixes and accessibility refinements.", releaseDate: "2026-11-05T00:00:00.000Z", source: "DEMO" },
        ...saved.map(item => ({ ...item, source: "OWNER ENTRY" })),
      ] };
    }),
    createRelease: rolesProcedure(...ownerAdmin).input(z.object({ version: z.string().trim().min(1).max(48), platform: z.enum(["android", "ios", "backend"]), status: z.enum(["planned", "review", "live", "paused"]), notes: z.string().trim().min(3).max(2000), releaseDate: z.string().optional() })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      await db.insert(releases).values({ ...input, releaseDate: input.releaseDate ? new Date(input.releaseDate) : null, createdBy: ctx.admin.email });
      await writeAudit(ctx.admin.email, "release.created", "app_release", `Release ${input.version} (${input.platform}) recorded as ${input.status}.`);
      return { saved: true };
    }),
  }),

  team: router({
    list: rolesProcedure("owner", "admin").query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      const members = await db.select({ id: adminAccounts.id, email: adminAccounts.email, displayName: adminAccounts.displayName, role: adminAccounts.role, isActive: adminAccounts.isActive, createdAt: adminAccounts.createdAt, lastLoginAt: adminAccounts.lastLoginAt }).from(adminAccounts).orderBy(adminAccounts.createdAt);
      return members.map(member => ({ ...member, current: member.id === ctx.admin.id }));
    }),
    invitations: rolesProcedure("owner", "admin").query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select({ email: adminInvitations.email, role: adminInvitations.role, resetAdminId: adminInvitations.resetAdminId, expiresAt: adminInvitations.expiresAt, createdAt: adminInvitations.createdAt }).from(adminInvitations).where(gt(adminInvitations.expiresAt, new Date())).orderBy(desc(adminInvitations.createdAt));
    }),
    invite: rolesProcedure("owner").input(z.object({ email: z.string().email().max(320), role: z.enum(["admin", "analyst", "support"]) })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const email = normalizeEmail(input.email);
      const existing = await db.select({ id: adminAccounts.id }).from(adminAccounts).where(eq(adminAccounts.email, email)).limit(1);
      if (existing.length) throw new TRPCError({ code: "CONFLICT", message: "That administrator already exists." });
      const token = randomBytes(32).toString("base64url");
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      await db.insert(adminInvitations).values({ tokenHash: hashToken(token), email, role: input.role, createdBy: ctx.admin.email, expiresAt });
      await writeAudit(ctx.admin.email, "team.invited", "admin_invitation", `Invitation created for ${email} as ${input.role}.`);
      return { link: `/?invite=${encodeURIComponent(token)}`, email, role: input.role, expiresAt };
    }),
    resetAccess: rolesProcedure("owner").input(z.object({ adminId: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const rows = await db.select().from(adminAccounts).where(eq(adminAccounts.id, input.adminId)).limit(1);
      const target = rows[0];
      if (!target || target.role === "owner" || target.id === ctx.admin.id) throw new TRPCError({ code: "FORBIDDEN", message: "Access reset is available only for another non-owner administrator." });
      const resetRole = target.role as "admin" | "analyst" | "support";
      const token = randomBytes(32).toString("base64url");
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      await db.transaction(async tx => {
        await tx.delete(adminInvitations).where(eq(adminInvitations.email, target.email));
        await tx.update(adminAccounts).set({ isActive: false }).where(eq(adminAccounts.id, target.id));
        await tx.delete(adminSessions).where(eq(adminSessions.adminId, target.id));
        await tx.insert(adminInvitations).values({ tokenHash: hashToken(token), email: target.email, role: resetRole, resetAdminId: target.id, createdBy: ctx.admin.email, expiresAt });
        await tx.insert(auditEvents).values({ actorEmail: ctx.admin.email, action: "team.access_reset_started", resourceType: "admin_account", summary: `Access for ${target.email} suspended pending password and MFA re-enrollment.` });
      });
      return { link: `/?invite=${encodeURIComponent(token)}`, email: target.email, expiresAt };
    }),
    changeRole: rolesProcedure("owner").input(z.object({ adminId: z.number().int().positive(), role: z.enum(["admin", "analyst", "support"]) })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const target = await db.select().from(adminAccounts).where(eq(adminAccounts.id, input.adminId)).limit(1);
      if (!target[0] || target[0].role === "owner") throw new TRPCError({ code: "FORBIDDEN", message: "The owner account cannot be reassigned." });
      await db.update(adminAccounts).set({ role: input.role }).where(eq(adminAccounts.id, input.adminId));
      await writeAudit(ctx.admin.email, "team.role_changed", "admin_account", `${target[0].email} role changed to ${input.role}.`);
      return { saved: true };
    }),
    setActive: rolesProcedure("owner").input(z.object({ adminId: z.number().int().positive(), active: z.boolean() })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const rows = await db.select().from(adminAccounts).where(eq(adminAccounts.id, input.adminId)).limit(1);
      const target = rows[0];
      if (!target || target.role === "owner" || target.id === ctx.admin.id) throw new TRPCError({ code: "FORBIDDEN", message: "The owner account cannot be suspended here." });
      await db.update(adminAccounts).set({ isActive: input.active }).where(eq(adminAccounts.id, target.id));
      if (!input.active) await db.delete(adminSessions).where(eq(adminSessions.adminId, target.id));
      await writeAudit(ctx.admin.email, input.active ? "team.account_reactivated" : "team.account_suspended", "admin_account", `${target.email} administrator account ${input.active ? "reactivated" : "suspended; all sessions revoked"}.`);
      return { saved: true };
    }),
    changeMyPassword: rolesProcedure(...allReaders).input(z.object({ currentPassword: z.string().min(1).max(128), newPassword })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
      const account = await verifyAccountPassword(ctx.admin.email, input.currentPassword);
      if (!account || account.id !== ctx.admin.id) throw new TRPCError({ code: "FORBIDDEN", message: "The current password is incorrect." });
      const credentials = await makeCredential(input.newPassword);
      await db.update(adminAccounts).set(credentials).where(eq(adminAccounts.id, ctx.admin.id));
      await db.delete(adminSessions).where(eq(adminSessions.adminId, ctx.admin.id));
      await writeAudit(ctx.admin.email, "auth.password_changed", "admin_account", "Administrator changed their own password; all sessions revoked.");
      await revokeCurrentSession(ctx.req, ctx.res);
      return { saved: true };
    }),
  }),

  audit: router({
    list: rolesProcedure(...metricReaders).input(z.object({ limit: z.number().int().min(1).max(100).default(50) }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(auditEvents).orderBy(desc(auditEvents.createdAt)).limit(input?.limit ?? 50);
    }),
  }),
});

export type AppRouter = typeof appRouter;
