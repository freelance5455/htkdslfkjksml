import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  getHostingStatus,
  getProvisioningResult,
  listJavaVersions,
} from "./minecraft";

const provisionInput = z.object({
  name: z.string().trim().min(1).max(32),
  edition: z.enum(["java", "bedrock"]),
  software: z.enum(["vanilla", "forge"]),
  track: z.enum(["old_alpha", "old_beta", "release", "snapshot"]),
  version: z.string().trim().min(1).max(64),
  maxPlayers: z.number().int().min(1).max(100),
  protectionWidth: z.number().int().min(1).max(100),
  protectionLength: z.number().int().min(1).max(100),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  minecraft: router({
    versions: publicProcedure
      .input(
        z.object({
          track: z.enum(["old_alpha", "old_beta", "release", "snapshot"]),
          software: z.enum(["vanilla", "forge"]),
        })
      )
      .query(({ input }) => listJavaVersions(input.track, input.software)),
    hostingStatus: publicProcedure.query(() => getHostingStatus()),
    provision: publicProcedure
      .input(provisionInput)
      .mutation(() => getProvisioningResult()),
  }),
});

export type AppRouter = typeof appRouter;
