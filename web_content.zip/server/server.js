const http = require('http');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const server = http.createServer((req,res)=>{
  res.writeHead(200, {'Content-Type':'text/plain'});
  res.end('ZYNKO server is running.\n');
});
const wss = new WebSocket.Server({server});
const rooms = new Map();

function broadcast(room, payload, except) {
  const set = rooms.get(room);
  if (!set) return;
  const data = JSON.stringify(payload);
  for (const client of set) if (client !== except && client.readyState === WebSocket.OPEN) client.send(data);
}

wss.on('connection', ws => {
  ws.room = null;
  ws.name = 'Member';

  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === 'join') {
      if (ws.room && rooms.get(ws.room)) rooms.get(ws.room).delete(ws);
      ws.room = String(msg.room || 'default').slice(0,80);
      ws.name = String(msg.name || 'Member').slice(0,40);
      if (!rooms.has(ws.room)) rooms.set(ws.room, new Set());
      rooms.get(ws.room).add(ws);
      broadcast(ws.room, {type:'message', name:'System', text: ws.name + ' joined the room.'}, ws);
      return;
    }

    if (msg.type === 'message' && ws.room) {
      const text = String(msg.text || '').slice(0,4000);
      if (!text) return;
      broadcast(ws.room, {type:'message', name:ws.name, text}, ws);
    }

    if (msg.type === 'sticker' && ws.room) {
      const sticker = String(msg.sticker || '');
      if (!sticker) return;
      broadcast(ws.room, {type:'sticker', name:ws.name, sticker}, ws);
    }
  });

  ws.on('close', ()=>{
    if (ws.room && rooms.get(ws.room)) {
      rooms.get(ws.room).delete(ws);
      broadcast(ws.room, {type:'message', name:'System', text: ws.name + ' left the room.'});
      if (rooms.get(ws.room).size === 0) rooms.delete(ws.room);
    }
  });
});

server.listen(PORT, ()=>console.log(`ZYNKO server listening on port ${PORT}`));
