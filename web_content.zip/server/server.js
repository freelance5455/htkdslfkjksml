// Shadow Blade online server - no dependencies. Run:  node server.js
// Optional env: PORT, DATA_FILE, OWNER_CODE_HASH (sha256 of "sbowner|<your owner code>")
const http=require('http'),fs=require('fs'),crypto=require('crypto');
const PORT=process.env.PORT||3000,FILE=process.env.DATA_FILE||'data.json';
const OWNER=process.env.OWNER_CODE_HASH||'36ffbdd24ffef4e53524f465ac01ba70a39383c5f5dafde2e8b65dea9605272b';
const UPU=process.env.UPSTASH_REDIS_REST_URL,UPT=process.env.UPSTASH_REDIS_REST_TOKEN;
let DB={users:{},teams:{}};
async function upCmd(c){const r=await fetch(UPU,{method:'POST',headers:{Authorization:'Bearer '+UPT,'Content-Type':'application/json'},body:JSON.stringify(c)});return r.json()}
async function loadDB(){if(UPU){const r=await upCmd(['GET','mxblade_db']);if(r&&r.result)DB=JSON.parse(r.result);console.log('db: upstash',Object.keys(DB.users).length,'users')}else{try{DB=JSON.parse(fs.readFileSync(FILE,'utf8'))}catch(e){}console.log('db: file',Object.keys(DB.users).length,'users')}}
let dirty=0;const persist=()=>{dirty=1};
setInterval(()=>{if(dirty){dirty=0;try{if(UPU)upCmd(['SET','mxblade_db',JSON.stringify(DB)]).catch(e=>console.log('upstash error',e.message));else{fs.writeFileSync(FILE+'.tmp',JSON.stringify(DB));fs.renameSync(FILE+'.tmp',FILE)}}catch(e){console.log('save error',e.message)}}},3000);
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const key=n=>Object.keys(DB.users).find(u=>u.toLowerCase()==String(n||'').toLowerCase());
const TOK={},now=()=>Date.now(),isOn=u=>now()-(u.seen||0)<40000;
const ownerOk=c=>sha('sbowner|'+String(c||''))===OWNER;
const pw=(p,s)=>crypto.scryptSync(String(p||''),s,32).toString('hex');
const mk=n=>{const t=crypto.randomBytes(16).toString('hex');TOK[t]=n;return t};
const push=(to,msg)=>{const u=DB.users[to];if(!u)return false;u.inbox=u.inbox||[];if(u.inbox.length>200)u.inbox.shift();u.inbox.push(msg);persist();return true};
const ops={
register(b){const n=String(b.name||'').trim();if(!/^[\w\u0600-\u06FF]{3,16}$/.test(n))return{err:'bad_name'};if(key(n))return{err:'taken'};if(String(b.pass||'').length<4)return{err:'bad_pass'};const salt=crypto.randomBytes(8).toString('hex');DB.users[n]={salt,hash:pw(b.pass,salt),data:b.data||null,inbox:[],mx:0,seen:now(),team:null};persist();return{token:mk(n),name:n,data:DB.users[n].data,mx:0,team:null,admin:false}},
login(b){const k=key(b.name);if(!k)return{err:'bad_login'};const u=DB.users[k];if(pw(b.pass,u.salt)!==u.hash)return{err:'bad_login'};u.seen=now();persist();return{token:mk(k),name:k,data:u.data,mx:u.mx||0,team:u.team,admin:!!u.admin}},
};
const authed={
save(n,b){if(b.data&&JSON.stringify(b.data).length<400000){DB.users[n].data=b.data;persist()}return{ok:1}},
hb(n){const u=DB.users[n];u.seen=now();const inbox=u.inbox||[];u.inbox=[];if(inbox.length)persist();return{ok:1,inbox,mx:u.mx||0,team:u.team,admin:!!u.admin}},
send(n,b){const to=key(b.to);if(!to||to==n)return{err:'no_user'};const m=b.msg||{};m.from=n;m.ts=now();if(JSON.stringify(m).length>5000)return{err:'big'};push(to,m);return{ok:1}},
who(n,b){const k=key(b.name);return k?{exists:1,online:isOn(DB.users[k]),name:k}:{exists:0}},
mxsend(n,b){const to=key(b.to),a=Math.floor(+b.n);if(!to||to==n)return{err:'no_user'};if(!(a>0)||a>(DB.users[n].mx||0))return{err:'no_funds'};DB.users[n].mx-=a;DB.users[to].mx=(DB.users[to].mx||0)+a;push(to,{t:'mxrecv',from:n,n:a,ts:now()});persist();return{ok:1,mx:DB.users[n].mx}},
mxspend(n,b){const a=Math.floor(+b.n);if(!(a>0)||a>(DB.users[n].mx||0))return{err:'no_funds',mx:DB.users[n].mx||0};DB.users[n].mx-=a;persist();return{ok:1,mx:DB.users[n].mx}},
mxset(n,b){if(!ownerOk(b.code))return{err:'denied'};const a=Math.max(0,Math.min(9e15,Math.floor(+b.n)||0));DB.users[n].mx=a;persist();return{ok:1,mx:a}},
adminadd(n,b){if(!ownerOk(b.code))return{err:'denied'};const k=key(b.name);if(!k)return{err:'no_user'};DB.users[k].admin=1;persist();return{ok:1,name:k}},
adminremove(n,b){if(!ownerOk(b.code))return{err:'denied'};const k=key(b.name);if(!k)return{err:'no_user'};DB.users[k].admin=0;persist();return{ok:1}},
adminlist(n,b){if(!ownerOk(b.code)&&!DB.users[n].admin)return{err:'denied'};return{admins:Object.keys(DB.users).filter(x=>DB.users[x].admin)}},
giveall(n,b){const u=DB.users[n];if(!ownerOk(b.code)&&!u.admin)return{err:'denied'};const t0=now();if(t0-(u.lastGive||0)<5000)return{err:'wait'};const kind=String(b.kind),a=Math.floor(+b.n)||0;if((kind=='mx'||kind=='m')&&!(a>0&&a<=1e12))return{err:'bad'};if(!['mx','m','sw','ar','wg','ch','up'].includes(kind))return{err:'bad'};u.lastGive=t0;let c=0;for(const nm of Object.keys(DB.users)){const t=DB.users[nm];if(!isOn(t))continue;if(kind=='mx'){t.mx=(t.mx||0)+a;push(nm,{t:'mxrecv',from:n,n:a,ts:t0})}else if(kind=='m')push(nm,{t:'gift',from:n,g:{k:'m',v:a},ts:t0});else push(nm,{t:'gift',from:n,g:{k:kind,v:b.v},ts:t0});c++}persist();return{ok:1,count:c}},
teamcreate(n,b){const t=String(b.name||'').trim();if(!/^[\w\u0600-\u06FF]{3,16}$/.test(t))return{err:'bad_name'};if(DB.users[n].team)return{err:'in_team'};if(Object.keys(DB.teams).some(x=>x.toLowerCase()==t.toLowerCase()))return{err:'taken'};DB.teams[t]={leader:n,members:[n],inv:[]};DB.users[n].team=t;persist();return{ok:1,team:t}},
teaminvite(n,b){const u=DB.users[n],t=u.team&&DB.teams[u.team];if(!t)return{err:'no_team'};const to=key(b.to);if(!to||to==n)return{err:'no_user'};if(DB.users[to].team)return{err:'has_team'};if(t.members.length>=30)return{err:'full'};if(!t.inv.includes(to))t.inv.push(to);push(to,{t:'tinv',team:u.team,from:n,ts:now()});persist();return{ok:1}},
teamjoin(n,b){const u=DB.users[n];if(u.team)return{err:'in_team'};const tn=Object.keys(DB.teams).find(x=>x==b.team),t=DB.teams[tn];if(!t||!t.inv.includes(n))return{err:'no_invite'};t.inv=t.inv.filter(x=>x!=n);t.members.push(n);u.team=tn;persist();return{ok:1,team:tn}},
teamleave(n){const u=DB.users[n],t=u.team&&DB.teams[u.team];if(!t)return{err:'no_team'};t.members=t.members.filter(x=>x!=n);if(!t.members.length)delete DB.teams[u.team];else if(t.leader==n)t.leader=t.members[0];u.team=null;persist();return{ok:1}},
teaminfo(n){const u=DB.users[n],t=u.team&&DB.teams[u.team];if(!t)return{team:null};return{team:u.team,leader:t.leader,members:t.members.map(m=>({name:m,online:DB.users[m]?isOn(DB.users[m]):false}))}}
};
const srv=http.createServer((req,res)=>{
if(req.method=='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS'});return res.end()}
if(req.method=='GET'){res.writeHead(200,{'Content-Type':'text/plain','Access-Control-Allow-Origin':'*'});return res.end('MX Blade server OK')}
let body='';req.on('data',d=>{body+=d;if(body.length>600000)req.destroy()});
req.on('end',()=>{let b;try{b=JSON.parse(body||'{}')}catch(e){return send(res,{err:'bad_json'},400)}
try{if(ops[b.op])return send(res,ops[b.op](b));const n=TOK[b.token];if(!n||!DB.users[n])return send(res,{err:'auth'},401);if(!authed[b.op])return send(res,{err:'bad_op'},400);send(res,authed[b.op](n,b))}catch(e){console.log('error',b.op,e.message);send(res,{err:'server'},500)}})
});
loadDB().then(()=>srv.listen(PORT,()=>console.log('MX Blade server on port',PORT)));
function send(res,o,c=200){res.writeHead(c,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS'});res.end(JSON.stringify(o))}
