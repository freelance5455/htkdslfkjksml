// NEXUS AI proxy - Node.js 18+, no third-party packages required.
"use strict";
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const ROOT = path.resolve(__dirname, "..");
function loadEnv(){
  const file=path.join(__dirname,".env");
  if(!fs.existsSync(file))return;
  for(const line of fs.readFileSync(file,"utf8").split(/\r?\n/)){
    const m=line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);if(m&&!process.env[m[1]])process.env[m[1]]=m[2].replace(/^["']|["']$/g,"");
  }
}
loadEnv();
const PORT=Number(process.env.PORT||8787);
const API_KEY=process.env.AI_API_KEY||"";
const API_URL=process.env.AI_API_URL||"https://api.openai.com/v1/chat/completions";
const MODEL=process.env.AI_MODEL||"gpt-4o-mini";
const ALLOWED_ORIGIN=process.env.ALLOWED_ORIGIN||"*";
const MIME={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".svg":"image/svg+xml",".webmanifest":"application/manifest+json"};
function send(res,status,data){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":ALLOWED_ORIGIN,"Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,OPTIONS","Cache-Control":"no-store"});res.end(JSON.stringify(data));}
function readBody(req){return new Promise((resolve,reject)=>{let body="",size=0;req.on("data",chunk=>{size+=chunk.length;if(size>30000){reject(new Error("الطلب أكبر من الحجم المسموح"));req.destroy();}else body+=chunk;});req.on("end",()=>{try{resolve(JSON.parse(body||"{}"));}catch(_){reject(new Error("JSON غير صالح"));}});req.on("error",reject);});}
const server=http.createServer(async(req,res)=>{
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":ALLOWED_ORIGIN,"Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,OPTIONS"});return res.end();}
  const url=new URL(req.url,"http://localhost");
  if(url.pathname==="/api/health"&&req.method==="GET")return send(res,200,{ok:true,configured:!!API_KEY,model:MODEL});
  if(url.pathname==="/api/chat"&&req.method==="POST"){
    if(!API_KEY)return send(res,503,{error:"لم يتم إعداد AI_API_KEY في ملف .env على الخادم."});
    try{
      const body=await readBody(req);const message=typeof body.message==="string"?body.message.trim():"";
      if(!message||message.length>4000)return send(res,400,{error:"الرسالة فارغة أو أطول من الحد المسموح."});
      const history=Array.isArray(body.history)?body.history.slice(-10).filter(x=>x&&["user","assistant"].includes(x.role)&&typeof x.content==="string").map(x=>({role:x.role,content:x.content.slice(0,4000)})):[];
      const messages=[{role:"system",content:"أنت NEXUS AI، مساعد تعليمي وتقني. أجب بالعربية الواضحة أو باللهجة التي يستعملها المستخدم. كن دقيقاً، وصرّح عندما لا تعرف. لا تطلب كلمات المرور أو مفاتيح API."},...history,{role:"user",content:message}];
      const upstream=await fetch(API_URL,{method:"POST",headers:{"Authorization":"Bearer "+API_KEY,"Content-Type":"application/json"},body:JSON.stringify({model:MODEL,messages,temperature:0.7})});
      const data=await upstream.json().catch(()=>({}));
      if(!upstream.ok)return send(res,502,{error:data.error?.message||"مزوّد الذكاء الاصطناعي رفض الطلب. تحقق من المفتاح والنموذج والحدود."});
      const reply=data.choices?.[0]?.message?.content;
      if(typeof reply!=="string")return send(res,502,{error:"استجابة غير متوقعة من مزوّد API."});
      return send(res,200,{reply,model:MODEL});
    }catch(err){return send(res,500,{error:err.message||"حدث خطأ في الخادم."});}
  }
  if(req.method!=="GET"&&req.method!=="HEAD")return send(res,405,{error:"Method not allowed"});
  const rel=url.pathname==="/"?"index.html":decodeURIComponent(url.pathname).replace(/^\/+/,"");
  const file=path.resolve(ROOT,rel);
  if(!file.startsWith(ROOT+path.sep)&&file!==ROOT)return send(res,403,{error:"Forbidden"});
  fs.readFile(file,(err,buf)=>{if(err)return send(res,404,{error:"الملف غير موجود"});res.writeHead(200,{"Content-Type":MIME[path.extname(file)]||"application/octet-stream","X-Content-Type-Options":"nosniff"});res.end(buf);});
});
server.listen(PORT,()=>console.log(`NEXUS ZERO X running at http://localhost:${PORT}`));
