// Aldeia do Reino — servidor de narrativas generativas (Node.js 18+, sem dependências)
// Usa API compatível com OpenAI. A chave fica somente no servidor, nunca no APK.
const http = require('node:http');
const { URL } = require('node:url');
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.MODEL_API_KEY || '';
const BASE_URL = (process.env.MODEL_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const MODEL = process.env.MODEL_NAME || 'gpt-4o-mini';
const MAX_BODY = 32_000;
const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || '*';
  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/health') {
    res.writeHead(200); return res.end(JSON.stringify({ok:true,service:'aldeia-reino-narrative',configured:!!API_KEY,model:MODEL}));
  }
  if (req.method !== 'POST' || url.pathname !== '/api/narrative') {
    res.writeHead(404); return res.end(JSON.stringify({error:'Rota não encontrada'}));
  }
  if (!API_KEY) { res.writeHead(503); return res.end(JSON.stringify({error:'Servidor sem MODEL_API_KEY configurada. Configure a chave nas variáveis de ambiente do host.'})); }
  let raw='';
  req.on('data', chunk => { raw += chunk; if (raw.length > MAX_BODY) { res.writeHead(413); res.end(JSON.stringify({error:'Pedido muito grande'})); req.destroy(); } });
  req.on('end', async () => {
    let body; try { body = JSON.parse(raw || '{}'); } catch { res.writeHead(400); return res.end(JSON.stringify({error:'JSON inválido'})); }
    const context = String(body.context || '').slice(0, 12000);
    const currentMessage = String(body.message || '').slice(0, 2000);
    if (!context.trim()) { res.writeHead(400); return res.end(JSON.stringify({error:'Falta o contexto da personagem'})); }
    const history = Array.isArray(body.history) ? body.history.slice(-8).map(x => {
      if (typeof x === 'string') return {role:'user',content:x.slice(0,700)};
      const role = x && x.role === 'assistant' ? 'assistant' : 'user';
      const content = String(x?.content ?? x?.text ?? '').slice(0,1000);
      return {role,content};
    }).filter(x => x.content) : [];
    const system = `Você é o motor generativo de personagens do RPG medieval-fantástico Aldeia do Reino. Responda em português brasileiro como a entidade descrita no contexto; nunca como um assistente externo. Cada indivíduo tem identidade, desejos, crenças, limites, humor e memória consistentes. Responda diretamente ao conteúdo da mensagem atual e varie a fala com base no histórico real. Não repita saudação ou frase genérica se o jogador perguntou algo específico. Use detalhes do contexto, faça perguntas quando naturais e proponha opções sem controlar o jogador. Não altere inventário, atributos ou estado de jogo; apenas dialogue e narre percepções. Normalmente 2–6 frases. Conteúdo apropriado para fantasia. Contexto do mundo e da personagem:\n${context}`;
    const chatMessages = [{role:'system',content:system}, ...history];
    if (currentMessage) chatMessages.push({role:'user',content:currentMessage});
    const controller = new AbortController(); const timer = setTimeout(()=>controller.abort(), 25000);
    try {
      const response = await fetch(`${BASE_URL}/chat/completions`, {method:'POST', signal:controller.signal, headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'}, body:JSON.stringify({model:MODEL,temperature:0.92,max_tokens:320,messages:chatMessages})});
      const data = await response.json().catch(()=>({}));
      if (!response.ok) { console.error('Provider error', response.status, JSON.stringify(data).slice(0,500)); res.writeHead(502); return res.end(JSON.stringify({error:'O provedor de IA recusou o pedido',status:response.status})); }
      const text = data?.choices?.[0]?.message?.content;
      if (!text || typeof text !== 'string') { res.writeHead(502); return res.end(JSON.stringify({error:'Resposta vazia do modelo'})); }
      res.writeHead(200); res.end(JSON.stringify({text:text.trim(),model:MODEL,generated:true}));
    } catch (e) { res.writeHead(504); res.end(JSON.stringify({error:e.name==='AbortError'?'Tempo limite do modelo excedido':'Não foi possível conectar ao provedor de IA'})); }
    finally { clearTimeout(timer); }
  });
});
server.listen(PORT, '0.0.0.0', ()=>console.log(`Aldeia AI server listening on ${PORT}; model=${MODEL}`));
