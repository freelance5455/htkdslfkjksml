import express from "express";
import multer from "multer";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.AI_API_KEY || "";
const BASE_URL = (process.env.AI_BASE_URL || "https://generativelanguage.googleapis.com/v1beta/openai").replace(/\/+$/, "");
const MODEL = process.env.AI_MODEL || "gemini-2.5-flash";
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 8);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 }
});

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    apiKeyConfigured: Boolean(API_KEY),
    model: MODEL,
    providerEndpointConfigured: Boolean(BASE_URL)
  });
});

app.post("/api/chat", upload.single("file"), async (req, res) => {
  try {
    if (!API_KEY) {
      return res.status(503).json({
        error: "A chave da API ainda não foi configurada no servidor. Preencha AI_API_KEY no arquivo .env."
      });
    }

    const message = String(req.body.message || "").trim();
    if (!message && !req.file) {
      return res.status(400).json({ error: "Digite uma mensagem ou anexe um arquivo." });
    }

    let userContent = message || "Analise o arquivo anexado e explique seu conteúdo.";
    const file = req.file;

    if (file) {
      const mime = file.mimetype || "application/octet-stream";
      if (mime.startsWith("image/")) {
        userContent = [
          { type: "text", text: message || "Analise esta imagem e descreva o que consegue observar." },
          { type: "image_url", image_url: { url: `data:${mime};base64,${file.buffer.toString("base64")}` } }
        ];
      } else if (mime.startsWith("text/") || /\.(txt|csv|json|md)$/i.test(file.originalname)) {
        const text = file.buffer.toString("utf8").slice(0, 30000);
        userContent += `\n\nConteúdo do arquivo "${file.originalname}":\n${text}`;
      } else {
        return res.status(415).json({
          error: "Este servidor aceita imagens e arquivos de texto (TXT, CSV, JSON e MD). PDF e DOCX ainda precisam de um módulo de leitura."
        });
      }
    }

    const upstream = await fetch(`${BASE_URL}/chat/completions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: "Você é a DUARTE IA, uma assistente útil, clara e segura. Responda em português brasileiro, salvo se o usuário pedir outro idioma. Explique de forma simples e não invente fatos." },
          { role: "user", content: userContent }
        ],
        temperature: 0.7
      })
    });

    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { error: raw }; }

    if (!upstream.ok) {
      const detail = data?.error?.message || data?.error || data?.message || `O provedor respondeu com HTTP ${upstream.status}.`;
      return res.status(502).json({ error: `Falha no provedor de IA: ${String(detail).slice(0, 900)}` });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) {
      return res.status(502).json({ error: "O provedor respondeu, mas não retornou texto. Confira o modelo configurado." });
    }
    return res.json({ reply });
  } catch (error) {
    if (error?.code === "LIMIT_FILE_SIZE") {
      return res.status(413).json({ error: `O arquivo é grande demais. Limite atual: ${MAX_UPLOAD_MB} MB.` });
    }
    console.error("Erro em /api/chat:", error);
    return res.status(500).json({ error: "Erro interno no servidor. Confira os registros da hospedagem." });
  }
});

app.use(express.static(path.resolve(__dirname, "..")));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.resolve(__dirname, "../index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`DUARTE IA pronta na porta ${PORT}`);
  console.log(`Modelo configurado: ${MODEL}`);
});
