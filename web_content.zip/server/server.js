'use strict';
/**
 * ترید یار — سرور اختصاصی (نسخهٔ ۱.۰)
 * ------------------------------------------------------------------
 * جایگزین کامل Cloudflare Workerها؛ روی سرور/VPS شخصی خودتان اجرا می‌شود.
 *
 *  GET  /          → خواندن داده‌های همگام‌سازی        (سازگار با کلاینت فعلی)
 *  POST /          → ذخیرهٔ داده‌های همگام‌سازی        (سازگار با کلاینت فعلی)
 *  *    /relay?u=  → ریلی امن به APIهای صرافی/هوش مصنوعی (فقط دامنه‌های مجاز)
 *  GET  /health    → سلامت سرور (برای مانیتورینگ)
 *  GET  /status    → آمار کامل (فقط با ADMIN_TOKEN)
 *
 * بدون هیچ وابستگی خارجی؛ فقط Node.js 20 یا بالاتر.
 */

const http = require('node:http');
const fsp = require('node:fs/promises');
const path = require('node:path');
const zlib = require('node:zlib');
const dns = require('node:dns/promises');
const net = require('node:net');
const crypto = require('node:crypto');
const { Readable } = require('node:stream');

const VERSION = '1.0.0';

/* دامنه‌هایی که ریلی اجازهٔ عبور به آن‌ها را دارد (همان فهرست کلاینت) */
const DEFAULT_ALLOWED_HOSTS = [
  'api.binance.com', 'data-api.binance.vision', 'fapi.binance.com',
  'api.bybit.com', 'www.okx.com', 'api.gateio.ws', 'api.kucoin.com',
  'api.mexc.com', 'api.bitget.com', 'api.kraken.com', 'api-pub.bitfinex.com',
  'www.bitstamp.net', 'api.coinex.com', 'api.bitmart.com', 'api.coinbase.com',
  'api.crypto.com', 'www.bitmex.com', 'api.hitbtc.com', 'api.huobi.pro',
  'api.lbkex.com', 'api.coingecko.com', 'coincheck.com',
  'api.openai.com',
  'text.pollinations.ai',
  // ★ سرویس‌های هوش مصنوعی (بخش API Keys پنل ادمین)
  'api.anthropic.com', 'generativelanguage.googleapis.com', 'api.groq.com',
  'openrouter.ai', 'api.deepseek.com', 'api.x.ai', 'api.mistral.ai',
  'api.perplexity.ai', 'api.together.xyz', 'api.gapgpt.app',
];

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key, anthropic-version, anthropic-dangerous-direct-browser-access',
  'Access-Control-Max-Age': '86400',
  'Access-Control-Expose-Headers': 'X-Tradyar-Relay, X-Relay-Cache',
};
const BASE_HEADERS = {
  ...CORS,
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
};

/* ------------------------------ تنظیمات ------------------------------ */

function envInt(env, name, def) {
  const n = parseInt(env[name], 10);
  return Number.isFinite(n) && n >= 0 ? n : def;
}
const envBool = (v) => /^(1|true|yes|on)$/i.test(String(v || ''));

function loadConfig(env = process.env) {
  return {
    port: envInt(env, 'PORT', 8787),
    host: env.HOST || '0.0.0.0',
    dataDir: path.resolve(env.DATA_DIR || './data'),
    trustProxy: envBool(env.TRUST_PROXY),
    maxSyncBytes: envInt(env, 'MAX_SYNC_BYTES', 10 * 1024 * 1024),
    maxRelayBody: envInt(env, 'MAX_RELAY_BODY', 6 * 1024 * 1024),
    maxRelayResponse: envInt(env, 'MAX_RELAY_RESPONSE', 8 * 1024 * 1024),
    // نکته: شبکه‌های موبایل ایران CGNAT دارند و چندین کاربر یک IP مشترک‌اند؛ سقف‌ها عمداً سخاوتمندانه‌اند
    syncRatePerMin: envInt(env, 'SYNC_RATE_PER_MIN', 600),
    relayRatePerMin: envInt(env, 'RELAY_RATE_PER_MIN', 2400),
    maxConcurrentRelay: envInt(env, 'MAX_CONCURRENT_RELAY', 200),
    relayCacheTtlMs: envInt(env, 'RELAY_CACHE_TTL_MS', 1500),
    relayCacheMaxEntries: envInt(env, 'RELAY_CACHE_MAX_ENTRIES', 500),
    upstreamGetTimeoutMs: envInt(env, 'UPSTREAM_GET_TIMEOUT_MS', 10000),
    upstreamPostTimeoutMs: envInt(env, 'UPSTREAM_POST_TIMEOUT_MS', 90000),
    snapshotIntervalMin: envInt(env, 'SNAPSHOT_INTERVAL_MIN', 5),
    maxSnapshots: envInt(env, 'MAX_SNAPSHOTS', 200),
    maxDailyBackups: envInt(env, 'MAX_DAILY_BACKUPS', 30),
    adminToken: env.ADMIN_TOKEN || '',
    // ===== FIX 7f: SYNC_TOKEN for /sync authentication =====
    syncToken: env.SYNC_TOKEN || '',
    extraAllowedHosts: (env.EXTRA_ALLOWED_HOSTS || '')
      .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
    logRequests: envBool(env.LOG_REQUESTS),
  };
}

function makeLogger(silent = false) {
  return (level, msg, extra) => {
    if (silent) return;
    process.stdout.write(JSON.stringify({ t: new Date().toISOString(), level, msg, ...extra }) + '\n');
  };
}

/* ------------------------------ ابزارها ------------------------------ */

function httpErr(status, code) {
  const e = new Error(code);
  e.status = status;
  e.code = code;
  return e;
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return (
      a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168)
    );
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    if (x === '::' || x === '::1') return true;
    if (x.startsWith('::ffff:')) {
      const rest = x.slice(7);
      return net.isIPv4(rest) ? isPrivateIp(rest) : true;
    }
    return /^(fc|fd|fe[89ab])/.test(x);
  }
  return true; // ناشناخته = غیرمجاز
}

function makeHostChecker(list) {
  return (host) => {
    const h = String(host).toLowerCase().replace(/\.$/, '');
    return list.some((x) => h === x || h.endsWith('.' + x));
  };
}

class RateLimiter {
  constructor(limit, windowMs = 60000) {
    this.limit = limit;
    this.win = windowMs;
    this.map = new Map();
  }
  hit(key, now = Date.now()) {
    if (this.limit <= 0) return { ok: true, retryAfter: 0 };
    let e = this.map.get(key);
    if (!e || now >= e.reset) {
      if (this.map.size > 200000) this.map.clear(); // دفاع در برابر پر شدن حافظه
      e = { count: 0, reset: now + this.win };
      this.map.set(key, e);
    }
    e.count++;
    return { ok: e.count <= this.limit, retryAfter: Math.max(1, Math.ceil((e.reset - now) / 1000)) };
  }
  sweep(now = Date.now()) {
    for (const [k, e] of this.map) if (now >= e.reset) this.map.delete(k);
  }
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = parseInt(req.headers['content-length'], 10);
    if (Number.isFinite(declared) && declared > limit) {
      req.resume();
      return reject(httpErr(413, 'too_large'));
    }
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(httpErr(413, 'too_large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
    req.on('aborted', () => reject(httpErr(400, 'aborted')));
  });
}

function sendJson(res, status, obj, extra) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8', ...extra });
  res.end(body);
}

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

/* اعتبارسنجی سند همگام‌سازی: یا پاکتِ رمزنگاری‌شده، یا سند ساده با فیلد v */
function validateDoc(text) {
  let o;
  try { o = JSON.parse(text); } catch { return false; }
  if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
  if (o.encrypted && (o.ct || o.enc)) return true;
  return o.v !== undefined;
}

/* ------------------------- ذخیره‌سازی + بکاپ ------------------------- */

class SyncStore {
  constructor(cfg, log) {
    this.cfg = cfg;
    this.log = log;
    this.file = path.join(cfg.dataDir, 'sync.json');
    this.backupDir = path.join(cfg.dataDir, 'backups');
    this.text = null;
    this.gz = null;
    this.payload = null;
    this.updatedAt = 0;
    this.lastSnapshotAt = 0;
    this.writes = 0;
    this.chain = Promise.resolve();
  }

  async init() {
    await fsp.mkdir(this.backupDir, { recursive: true });
    try {
      this.text = await fsp.readFile(this.file, 'utf8');
      this.updatedAt = (await fsp.stat(this.file)).mtimeMs;
      JSON.parse(this.text);
    } catch (e) {
      if (e.code === 'ENOENT') {
        this.text = null;
      } else {
        this.log('error', 'sync.json خراب است؛ تلاش برای بازیابی از آخرین بکاپ', { err: String(e.message) });
        this.text = null;
        await this._recoverFromBackup();
      }
    }
    const snaps = await this._list('sync-');
    if (snaps.length) {
      try { this.lastSnapshotAt = (await fsp.stat(path.join(this.backupDir, snaps[snaps.length - 1]))).mtimeMs; } catch { /* ignore */ }
    }
  }

  async _list(prefix) {
    try { return (await fsp.readdir(this.backupDir)).filter((f) => f.startsWith(prefix)).sort(); } catch { return []; }
  }

  async _recoverFromBackup() {
    const all = [...(await this._list('sync-')), ...(await this._list('daily-'))].reverse();
    for (const f of all) {
      try {
        const t = await fsp.readFile(path.join(this.backupDir, f), 'utf8');
        if (validateDoc(t)) {
          this.text = t;
          this.updatedAt = Date.now();
          await fsp.writeFile(this.file, t);
          this.log('warn', 'بازیابی از بکاپ انجام شد', { file: f });
          return;
        }
      } catch { /* بعدی */ }
    }
  }

  async _prune(prefix, keep) {
    const files = await this._list(prefix);
    for (const f of files.slice(0, Math.max(0, files.length - keep))) {
      await fsp.unlink(path.join(this.backupDir, f)).catch(() => {});
    }
  }

  async _snapshot(now) {
    if (this.text === null) return;
    const dueSnap = now - this.lastSnapshotAt >= this.cfg.snapshotIntervalMin * 60000;
    if (dueSnap) {
      const name = 'sync-' + new Date(now).toISOString().replace(/[:.]/g, '-') + '.json';
      await fsp.writeFile(path.join(this.backupDir, name), this.text);
      this.lastSnapshotAt = now;
      await this._prune('sync-', this.cfg.maxSnapshots);
    }
    const daily = 'daily-' + new Date(now).toISOString().slice(0, 10) + '.json';
    const dailyPath = path.join(this.backupDir, daily);
    const exists = await fsp.access(dailyPath).then(() => true, () => false);
    if (!exists) {
      await fsp.writeFile(dailyPath, this.text);
      await this._prune('daily-', this.cfg.maxDailyBackups);
    }
  }

  get() { return this.text; }

  /* پاسخ آمادهٔ GET: {"ok":true,"doc":<سند>} — متن هنگام ذخیره اعتبارسنجی شده، پس parse/stringify مجدد لازم نیست */
  getPayload() {
    if (this.text === null) return null;
    if (!this.payload) this.payload = Buffer.from('{"ok":true,"doc":' + this.text + '}');
    return this.payload;
  }

  async getGzip() {
    const payload = this.getPayload();
    if (!payload) return null;
    if (!this.gz) {
      const gz = await new Promise((res, rej) => zlib.gzip(payload, (e, b) => (e ? rej(e) : res(b))));
      if (payload === this.payload) this.gz = gz; // اگر در این فاصله سند عوض شده، کش نکن
      return gz;
    }
    return this.gz;
  }

  /* نوشتن‌ها پشت‌سرهم و اتمیک انجام می‌شوند (نوشتن در فایل موقت + rename) */
  put(text) {
    const run = async () => {
      const now = Date.now();
      await this._snapshot(now);
      const tmp = this.file + '.tmp';
      const fh = await fsp.open(tmp, 'w');
      try { await fh.writeFile(text); await fh.sync(); } finally { await fh.close(); }
      await fsp.rename(tmp, this.file);
      this.text = text;
      this.payload = null;
      this.gz = null;
      this.updatedAt = now;
      this.writes++;
    };
    const p = this.chain.then(run);
    this.chain = p.catch(() => {});
    return p;
  }

  async backupCount() {
    return (await this._list('sync-')).length + (await this._list('daily-')).length;
  }
}

/* ------------------------------ برنامه ------------------------------ */

async function createApp(cfg, deps = {}) {
  const log = deps.log || makeLogger(false);
  const fetchImpl = deps.fetch || globalThis.fetch;
  const hostAllowed = makeHostChecker([...DEFAULT_ALLOWED_HOSTS, ...cfg.extraAllowedHosts]);

  /* DNS با کش ۶۰ ثانیه‌ای؛ برای جلوگیری از SSRF به آدرس‌های داخلی */
  const dnsCache = new Map();
  const lookup = deps.lookup || (async (host) => {
    const hit = dnsCache.get(host);
    if (hit && hit.exp > Date.now()) return hit.addrs;
    const addrs = await dns.lookup(host, { all: true });
    dnsCache.set(host, { addrs, exp: Date.now() + 60000 });
    if (dnsCache.size > 1000) dnsCache.clear();
    return addrs;
  });

  const store = new SyncStore(cfg, log);
  await store.init();

  const syncLimiter = new RateLimiter(cfg.syncRatePerMin);
  const relayLimiter = new RateLimiter(cfg.relayRatePerMin);
  const sweeper = setInterval(() => { syncLimiter.sweep(); relayLimiter.sweep(); }, 60000);
  sweeper.unref();

  const startedAt = Date.now();
  const stats = {
    syncGets: 0, syncPuts: 0, syncRejected: 0,
    relayRequests: 0, relayCacheHits: 0, relayCoalesced: 0, relayErrors: 0, relayBusy: 0,
    rateLimited: 0, hosts: {},
  };
  const hostStat = (h) => (stats.hosts[h] ||= { ok: 0, err: 0, s403: 0, s429: 0, s451: 0 });

  const cache = new Map();     // url → {status, ctype, buf, exp}
  const inflight = new Map();  // url → Promise
  let activeRelay = 0;

  function clientIp(req) {
    if (cfg.trustProxy) {
      const cf = req.headers['cf-connecting-ip'];
      if (cf) return String(cf).trim();
      const xff = req.headers['x-forwarded-for'];
      if (xff) return String(xff).split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }

  async function assertSafeTarget(u) {
    if (u.protocol !== 'https:') throw httpErr(400, 'https_only');
    if (u.username || u.password) throw httpErr(400, 'bad_url');
    if (u.port && u.port !== '443') throw httpErr(403, 'port_not_allowed');
    if (net.isIP(u.hostname) || u.hostname.startsWith('[')) throw httpErr(403, 'ip_not_allowed');
    if (!hostAllowed(u.hostname)) throw httpErr(403, 'host_not_allowed');
    let addrs;
    try { addrs = await lookup(u.hostname); } catch { throw httpErr(502, 'dns_failed'); }
    if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw httpErr(403, 'private_address');
  }

  /* درخواست به مقصد؛ ریدایرکت‌ها دستی و با بررسی مجدد دامنه دنبال می‌شوند */
  async function upstreamFetch(target, method, headers, body, timeoutMs, clientSignal) {
    let current = target;
    let m = method;
    let b = body;
    const signals = [AbortSignal.timeout(timeoutMs)];
    if (clientSignal) signals.push(clientSignal);
    const signal = AbortSignal.any(signals);
    for (let hop = 0; hop <= 3; hop++) {
      await assertSafeTarget(current);
      const resp = await fetchImpl(current.toString(), { method: m, headers, body: b, redirect: 'manual', signal });
      if ([301, 302, 303, 307, 308].includes(resp.status)) {
        const loc = resp.headers.get('location');
        if (resp.body) resp.body.cancel().catch(() => {});
        if (!loc) throw httpErr(502, 'bad_redirect');
        try { current = new URL(loc, current); } catch { throw httpErr(502, 'bad_redirect'); }
        if (resp.status === 303 || ((resp.status === 301 || resp.status === 302) && m === 'POST')) { m = 'GET'; b = undefined; }
        continue;
      }
      return resp;
    }
    throw httpErr(502, 'too_many_redirects');
  }

  const mapUpstreamError = (e) => {
    if (e && e.status) return e;
    if (e && (e.name === 'TimeoutError' || e.name === 'AbortError')) return httpErr(504, 'upstream_timeout');
    return httpErr(502, 'upstream_error');
  };

  function sendBuffered(res, r, cacheState) {
    res.writeHead(r.status, {
      ...BASE_HEADERS,
      'Content-Type': r.ctype,
      'Content-Length': r.buf.length,
      'X-Tradyar-Relay': '1',
      'X-Relay-Cache': cacheState,
    });
    res.end(r.buf);
  }

  async function handleRelay(req, res, url) {
    stats.relayRequests++;
    const raw = url.searchParams.get('u');
    if (!raw) throw httpErr(400, 'missing_u');
    if (raw.length > 4096) throw httpErr(414, 'url_too_long');
    if (req.method !== 'GET' && req.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    let target;
    try { target = new URL(raw); } catch { throw httpErr(400, 'bad_url'); }
    await assertSafeTarget(target);

    const host = target.hostname.toLowerCase();
    const hs = hostStat(host);
    const auth = req.headers['authorization'];
    const ct = req.headers['content-type'];
    const headers = {
      'user-agent': 'Mozilla/5.0 (compatible; TradYarRelay/' + VERSION + ')',
      accept: 'application/json, text/plain, */*',
    };
    if (ct) headers['content-type'] = ct;
    if (auth) headers['authorization'] = auth;
    // ★ هدرهای احراز هویت سایر سرویس‌های هوش مصنوعی (Claude و ...)
    for (const h of ['x-api-key', 'anthropic-version', 'x-goog-api-key']) {
      if (req.headers[h]) headers[h] = String(req.headers[h]);
    }

    const body = req.method === 'POST' ? await readBody(req, cfg.maxRelayBody) : undefined;
    const cacheable = req.method === 'GET' && !auth && !req.headers['x-api-key'] && cfg.relayCacheTtlMs > 0;
    const key = target.toString();

    if (cacheable) {
      const hit = cache.get(key);
      if (hit && hit.exp > Date.now()) {
        stats.relayCacheHits++;
        return sendBuffered(res, hit, 'HIT');
      }
      const pending = inflight.get(key);
      if (pending) {
        stats.relayCoalesced++;
        const r = await pending;
        return sendBuffered(res, r, 'COALESCED');
      }
    }

    if (activeRelay >= cfg.maxConcurrentRelay) {
      stats.relayBusy++;
      throw httpErr(503, 'busy');
    }

    const note = (status) => {
      if (status >= 200 && status < 400) hs.ok++;
      else {
        hs.err++;
        if (status === 403) hs.s403++;
        else if (status === 429) hs.s429++;
        else if (status === 451) hs.s451++;
      }
    };

    activeRelay++;
    try {
      if (cacheable) {
        // درخواست مشترک: به قطع شدن یک کلاینت وابسته نیست
        const run = (async () => {
          const resp = await upstreamFetch(target, 'GET', headers, undefined, cfg.upstreamGetTimeoutMs, null);
          const declared = parseInt(resp.headers.get('content-length'), 10);
          if (Number.isFinite(declared) && declared > cfg.maxRelayResponse) throw httpErr(502, 'response_too_large');
          const buf = Buffer.from(await resp.arrayBuffer());
          if (buf.length > cfg.maxRelayResponse) throw httpErr(502, 'response_too_large');
          note(resp.status);
          return { status: resp.status, ctype: resp.headers.get('content-type') || 'application/json', buf };
        })();
        inflight.set(key, run);
        let r;
        try { r = await run; } finally { inflight.delete(key); }
        if (r.status >= 200 && r.status < 300) {
          cache.set(key, { ...r, exp: Date.now() + cfg.relayCacheTtlMs });
          while (cache.size > cfg.relayCacheMaxEntries) cache.delete(cache.keys().next().value);
        }
        return sendBuffered(res, r, 'MISS');
      }

      // POST یا درخواست دارای Authorization: بدون کش، پاسخ مستقیم عبور داده می‌شود
      const ac = new AbortController();
      res.on('close', () => { if (!res.writableEnded) ac.abort(); });
      const resp = await upstreamFetch(target, req.method, headers, body, cfg.upstreamPostTimeoutMs, ac.signal);
      note(resp.status);
      res.writeHead(resp.status, {
        ...BASE_HEADERS,
        'Content-Type': resp.headers.get('content-type') || 'application/json',
        'X-Tradyar-Relay': '1',
        'X-Relay-Cache': 'BYPASS',
      });
      if (!resp.body) return res.end();
      const stream = Readable.fromWeb(resp.body);
      stream.on('error', () => res.destroy());
      stream.pipe(res);
    } catch (e) {
      hs.err++;
      throw e;
    } finally {
      activeRelay--;
    }
  }

  async function handleSync(req, res) {
    // ===== FIX 7f: Authentication on /sync endpoint =====
    if (cfg.syncToken) {
      const provided = req.headers['x-tradyar-token'] || '';
      if (provided !== cfg.syncToken) {
        stats.syncRejected++;
        throw httpErr(401, 'unauthorized');
      }
    } else {
      console.warn('[SECURITY] SYNC_TOKEN not set — /sync endpoint is open!');
    }
    if (req.method === 'GET') {
      stats.syncGets++;
      const text = store.get();
      if (text === null) return sendJson(res, 200, { ok: false, reason: 'no_data' });
      const wantsGzip = /\bgzip\b/.test(req.headers['accept-encoding'] || '') && text.length > 1024;
      const headers = { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8', Vary: 'Accept-Encoding' };
      if (wantsGzip) {
        const gz = await store.getGzip();
        res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': gz.length });
        return res.end(gz);
      }
      const out = store.getPayload();
      res.writeHead(200, { ...headers, 'Content-Length': out.length });
      return res.end(out);
    }
    if (req.method === 'POST') {
      const text = await readBody(req, cfg.maxSyncBytes);
      if (!validateDoc(text)) {
        stats.syncRejected++;
        throw httpErr(400, 'invalid_doc');
      }
      await store.put(text);
      stats.syncPuts++;
      return sendJson(res, 200, { ok: true, size: text.length, at: store.updatedAt });
    }
    throw httpErr(405, 'method_not_allowed');
  }

  async function handleStatus(req, res) {
    if (!cfg.adminToken) throw httpErr(404, 'not_found');
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!m || !safeEqual(m[1], cfg.adminToken)) throw httpErr(401, 'unauthorized');
    const mem = process.memoryUsage();
    sendJson(res, 200, {
      ok: true,
      version: VERSION,
      node: process.version,
      uptimeSec: Math.round((Date.now() - startedAt) / 1000),
      memoryMB: Math.round(mem.rss / 1048576),
      sync: {
        exists: store.text !== null,
        bytes: store.text ? Buffer.byteLength(store.text) : 0,
        updatedAt: store.updatedAt ? new Date(store.updatedAt).toISOString() : null,
        writes: store.writes,
        backups: await store.backupCount(),
      },
      relay: { active: activeRelay, cacheEntries: cache.size },
      stats,
    });
  }

  async function route(req, res) {
    const ip = clientIp(req);
    const url = new URL(req.url, 'http://localhost');
    const p = url.pathname.replace(/\/+$/, '') || '/';

    if (req.method === 'OPTIONS') {
      res.writeHead(204, BASE_HEADERS);
      return res.end();
    }
    if (p === '/health') {
      return sendJson(res, 200, { ok: true, service: 'tradyar', version: VERSION, uptimeSec: Math.round((Date.now() - startedAt) / 1000) });
    }
    if (p === '/status') return handleStatus(req, res);

    if (p === '/relay') {
      const rl = relayLimiter.hit(ip);
      if (!rl.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter }); }
      return handleRelay(req, res, url);
    }
    if (p === '/' || p === '/sync') {
      const rl = syncLimiter.hit(ip);
      if (!rl.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter }); }
      return handleSync(req, res);
    }
    throw httpErr(404, 'not_found');
  }

  const server = http.createServer(async (req, res) => {
    const t0 = Date.now();
    try {
      await route(req, res);
    } catch (e) {
      const err = mapUpstreamError(e);
      const isKnown = e && e.status;
      if (!isKnown) {
        stats.relayErrors++;
        log('error', 'خطای پیش‌بینی‌نشده', { url: String(req.url).slice(0, 200), err: String(e && e.message) });
      }
      if (!res.headersSent) {
        sendJson(res, err.status, { ok: false, error: err.code }, err.retryAfter ? { 'Retry-After': String(err.retryAfter) } : undefined);
      } else {
        res.destroy();
      }
    } finally {
      if (cfg.logRequests) {
        log('info', 'req', { m: req.method, u: String(req.url).slice(0, 120), s: res.statusCode, ms: Date.now() - t0, ip: clientIp(req) });
      }
    }
  });
  // ★ SRV-ROBUST: افزایش timeoutها برای پایداری بیشتر
  server.requestTimeout = 120000; // 2 دقیقه
  server.headersTimeout = 30000;
  server.keepAliveTimeout = 70000; // بیشتر از header timeout برای جلوگیری از خطای ECONNRESET
  // ★ SRV-ROBUST: فعال‌سازی keepAlive برای اتصال‌های ماندگار
  server.on('connection', (socket) => {
    socket.setTimeout(120000); // 2 دقیقه برای هر اتصال
    socket.setKeepAlive(true, 30000); // فعال‌سازی TCP keepAlive هر ۳۰ ثانیه
    socket.setNoDelay(true); // غیرفعال‌سازی Nagle's algorithm برای سرعت بیشتر
    socket.on('error', (e) => {
      // خطای اتصال — فقط لاگ بزن و ادامه بده
      if (e.code !== 'ECONNRESET' && e.code !== 'EPIPE') {
        log('warn', 'خطای سوکت', { err: String(e.message), code: e.code });
      }
    });
    socket.on('timeout', () => {
      // اتصال بی‌تحرک — ببندش
      socket.destroy();
    });
  });

  async function close() {
    clearInterval(sweeper);
    await new Promise((resolve) => {
      const force = setTimeout(() => { server.closeAllConnections(); resolve(); }, 8000);
      force.unref();
      server.close(() => { clearTimeout(force); resolve(); });
      server.closeIdleConnections();
    });
    await store.chain;
  }

  return { server, store, stats, close, config: cfg };
}

/* ------------------------------ اجرا ------------------------------ */

async function main() {
  const cfg = loadConfig();
  const log = makeLogger(false);
  const app = await createApp(cfg, { log });
  await new Promise((resolve, reject) => {
    app.server.once('error', reject);
    app.server.listen(cfg.port, cfg.host, resolve);
  });
  log('info', 'سرور ترید یار روشن شد', { port: cfg.port, host: cfg.host, version: VERSION, dataDir: cfg.dataDir, trustProxy: cfg.trustProxy });
  if (!cfg.adminToken) log('warn', 'ADMIN_TOKEN تنظیم نشده؛ مسیر /status غیرفعال است');
  if (!cfg.syncToken) log('warn', 'SYNC_TOKEN تنظیم نشده؛ مسیر /sync بدون احراز هویت است!');

  // ★ SRV-ROBUST: مانیتورینگ حافظه و مانیتورینگ خودکار
  const memMonitor = setInterval(() => {
    const mem = process.memoryUsage();
    if (mem.rss > 500 * 1024 * 1024) {
      // اگر حافظه بیش از ۵۰۰MB شد، هشدار بده
      log('warn', 'مصرف حافظه بالا', { rssMB: Math.round(mem.rss / 1048576), heapMB: Math.round(mem.heapUsed / 1048576) });
    }
  }, 60000);
  memMonitor.unref();

  // ★ SRV-ROBUST: جلوگیری از کرش روی خطاهای پیش‌بینی‌نشده
  process.on('uncaughtException', (e) => {
    log('error', 'uncaughtException — سرور ادامه می‌دهد', { err: String(e && e.message || e), stack: e && e.stack ? e.stack.slice(0, 500) : null });
  });

  let stopping = false;
  const stop = async (sig) => {
    if (stopping) return;
    stopping = true;
    log('info', 'در حال خاموش‌شدن امن', { sig });
    await app.close();
    process.exit(0);
  };
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
  process.on('unhandledRejection', (e) => log('error', 'unhandledRejection', { err: String(e && e.message || e) }));
}

if (require.main === module) {
  main().catch((e) => {
    console.error('شروع سرور ناموفق بود:', e);
    process.exit(1);
  });
}

module.exports = { createApp, loadConfig, validateDoc, isPrivateIp, DEFAULT_ALLOWED_HOSTS };
