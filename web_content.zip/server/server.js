import express from "express";
import cors from "cors";
import "dotenv/config";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/chat", async (req, res) => {
  const { message } = req.body || {};
  if (!message) return res.status(400).json({ error: "Message required" });

  // Replace this section with your preferred AI provider.
  // Keep the secret key ONLY in .env on the server.
  //
  // Example environment variables:
  // OPENAI_API_KEY=...
  // ANTHROPIC_API_KEY=...
  //
  // The starter intentionally returns a safe demo response until you
  // connect a provider.

  res.json({
    reply: `I heard: "${message}". Your Voice Orb interface is working. Connect your AI provider in server/server.js to enable real AI answers.`
  });
});

app.listen(process.env.PORT || 5000, () => {
  console.log(`Voice Orb backend running on port ${process.env.PORT || 5000}`);
});