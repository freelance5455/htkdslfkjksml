const WebSocket=require("ws");
const http=require("http");
const crypto=require("crypto");
const server=http.createServer((req,res)=>{res.writeHead(200,{"Content-Type":"text/plain"});res.end("ANMOL FIGHTERS server online");});
const wss=new WebSocket.Server({server});
const rooms=new Map();
function id(){return crypto.randomBytes(3).toString("hex").toUpperCase()}
function send(ws,msg){if(ws.readyState===1)ws.send(JSON.stringify(msg))}
function broadcast(room,msg){for(const p of room.players.values())send(p.ws,msg)}
wss.on("connection",ws=>{
 let player=null,room=null;
 ws.on("message",raw=>{
  let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==="create"){
   const code=id(), r={players:new Map()}; rooms.set(code,r);
   player={id:id(),name:m.name||"Player",x:0,y:0,hp:100,ws};room=r;room.code=code;
   r.players.set(player.id,player);send(ws,{type:"joined",code,id:player.id});broadcast(r,{type:"state",players:[...r.players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp}))});
  } else if(m.type==="join"){
   const r=rooms.get(String(m.code||"").toUpperCase()); if(!r||r.players.size>=8){send(ws,{type:"error",message:"Room unavailable"});return}
   room=r;player={id:id(),name:m.name||"Player",x:0,y:0,hp:100,ws};r.players.set(player.id,player);
   send(ws,{type:"joined",code:r.code,id:player.id});broadcast(r,{type:"state",players:[...r.players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp}))});
  } else if(!player||!room)return;
  else if(m.type==="move"){player.x=Number(m.x)||0;player.y=Number(m.y)||0}
  else if(m.type==="damage"){
   const target=room.players.get(m.target); if(target&&target!==player)target.hp=Math.max(0,target.hp-(Number(m.amount)||25));
  } else if(m.type==="ability"){broadcast(room,{type:"ability",id:player.id,ability:m.ability,x:player.x,y:player.y})}
  else if(m.type==="reset"){for(const p of room.players.values())p.hp=100}
 });
 ws.on("close",()=>{if(player&&room){room.players.delete(player.id);broadcast(room,{type:"state",players:[...room.players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp}))});if(!room.players.size)rooms.delete(room.code)}})
});
setInterval(()=>{for(const r of rooms.values())broadcast(r,{type:"state",players:[...r.players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp}))})},100);
server.listen(process.env.PORT||8080,"0.0.0.0",()=>console.log("ANMOL FIGHTERS server running"));
