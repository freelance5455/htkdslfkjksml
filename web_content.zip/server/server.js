const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
app.use(express.json({limit:'16kb'}));
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');next()});
const recentRequests=new Map();
app.use('/api/',(req,res,next)=>{const ip=req.ip||'local';const now=Date.now(),last=recentRequests.get(ip)||0;if(now-last<900)return res.status(429).json({error:'Aguarde um instante antes de pedir outra resposta.'});recentRequests.set(ip,now);next()});
const projectRoot = path.resolve(__dirname, '..');
const root = fs.existsSync(path.join(projectRoot, 'www', 'index.html')) ? path.join(projectRoot, 'www') : projectRoot;
app.use(express.static(root, {extensions:['html']}));
app.post('/api/narrative', async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({error:'IA não configurada; o jogo continua com narrativa local.'});
  try {
    const body = req.body || {};
    const safe = value => JSON.stringify(value ?? '').slice(0,5000);
    const prompt = `Você é o motor narrativo de Aldeia do Reino: Ecos da Névoa, RPG sombrio de fantasia em português brasileiro. Gere fala específica e distinta, com subtexto, voz própria, sentimentos plausíveis, memória de relações e consequências graduais. Nunca revele todo mistério cedo demais; não repita frases recentes; não decida ações do jogador nem altere recursos/flags por conta própria. Se o contexto for monstro, fale de modo fragmentado e não humano; se for aldeão, preserve raça, profissão, temperamento e lembranças. Responda com 1 a 3 parágrafos sem markdown. Contexto: ${safe(body.context)}. Estado: ${safe(body.player)}. Memórias recentes: ${safe(body.history)}.`;
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method:'POST', headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4o-mini',temperature:1.05,max_tokens:420,messages:[{role:'system',content:'Escreva ficção original para um jogo. Nunca afirme que eventos fictícios são reais.'},{role:'user',content:prompt}]})
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({error:'O serviço de IA não respondeu.',detail:data.error?.message || 'Falha do provedor'});
    const text = data.choices?.[0]?.message?.content?.trim();
    if (!text) return res.status(502).json({error:'Resposta vazia da IA.'});
    res.json({text});
  } catch (e) { res.status(500).json({error:'Falha ao gerar narrativa.'}); }
});
const port = process.env.PORT || 4173;
app.listen(port, '0.0.0.0', () => console.log(`Aldeia do Reino disponível na porta ${port}`));
