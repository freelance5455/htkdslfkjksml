'use strict';
/**
 * ترید یار — سرور اختصاصی (نسخهٔ ۱.۰)
 * ------------------------------------------------------------------
 * جایگزین کامل Cloudflare Workerها؛ روی سرور/VPS شخصی خودتان اجرا می‌شود.
 *
 *  GET  /          → خواندن داده‌های همگام‌سازی        (سازگار با کلاینت فعلی)
 *  POST /          → ذخیرهٔ داده‌های همگام‌سازی        (سازگار با کلاینت فعلی)
 *  *    /relay?u=  → ریلی امن به APIهای صرافی/هوش مصنوعی (فقط دامنه‌های مجاز)
 *  GET  /health    → سلامت سرور (برای مانیتورینگ)
 *  GET  /status    → آمار کامل (فقط با ADMIN_TOKEN)
 *
 * بدون هیچ وابستگی خارجی؛ فقط Node.js 20 یا بالاتر.
 */

const http = require('node:http');
const fsp = require('node:fs/promises');
const path = require('node:path');
const zlib = require('node:zlib');
const dns = require('node:dns/promises');
const net = require('node:net');
const crypto = require('node:crypto');
const { Vault } = require('./vault');
const { Readable } = require('node:stream');
const { BotManager } = require('./bot');
const { CONNECTORS, ALL_HOSTS, listExchanges, ExchangeError, prepareOrder, floorToStep } = require('./exchanges');

const { createPay } = require('./pay');
const VERSION = '1.2.0';

/* دامنه‌هایی که ریلی اجازهٔ عبور به آن‌ها را دارد (همان فهرست کلاینت) */
const DEFAULT_ALLOWED_HOSTS = [
  'api.binance.com', 'data-api.binance.vision', 'fapi.binance.com',
  'api.bybit.com', 'www.okx.com', 'api.gateio.ws', 'api.kucoin.com',
  'api.mexc.com', 'api.bitget.com', 'api.kraken.com', 'api-pub.bitfinex.com',
  'www.bitstamp.net', 'api.coinex.com', 'api.bitmart.com', 'api.coinbase.com',
  'api.crypto.com', 'www.bitmex.com', 'api.hitbtc.com', 'api.huobi.pro',
  'api.lbkex.com', 'api.coingecko.com', 'coincheck.com',
  'api.openai.com',
  'text.pollinations.ai',
  // ★ سرویس‌های هوش مصنوعی (بخش API Keys پنل ادمین)
  'api.anthropic.com', 'generativelanguage.googleapis.com', 'api.groq.com',
  'openrouter.ai', 'api.deepseek.com', 'api.x.ai', 'api.mistral.ai',
  'api.perplexity.ai', 'api.together.xyz', 'api.gapgpt.app',
];

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key, x-admin-token, x-tradyar-token, x-trade-token, anthropic-version, anthropic-dangerous-direct-browser-access',
  'Access-Control-Max-Age': '86400',
  'Access-Control-Expose-Headers': 'X-Tradyar-Relay, X-Relay-Cache',
};
const BASE_HEADERS = {
  ...CORS,
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
};

/* ------------------------------ تنظیمات ------------------------------ */

function envInt(env, name, def) {
  const n = parseInt(env[name], 10);
  return Number.isFinite(n) && n >= 0 ? n : def;
}
const envBool = (v) => /^(1|true|yes|on)$/i.test(String(v || ''));

function loadConfig(env = process.env) {
  return {
    port: envInt(env, 'PORT', 8787),
    host: env.HOST || '0.0.0.0',
    dataDir: path.resolve(env.DATA_DIR || './data'),
    trustProxy: envBool(env.TRUST_PROXY),
    maxSyncBytes: envInt(env, 'MAX_SYNC_BYTES', 10 * 1024 * 1024),
    maxRelayBody: envInt(env, 'MAX_RELAY_BODY', 6 * 1024 * 1024),
    maxRelayResponse: envInt(env, 'MAX_RELAY_RESPONSE', 8 * 1024 * 1024),
    // نکته: شبکه‌های موبایل ایران CGNAT دارند و چندین کاربر یک IP مشترک‌اند؛ سقف‌ها عمداً سخاوتمندانه‌اند
    syncRatePerMin: envInt(env, 'SYNC_RATE_PER_MIN', 600),
    relayRatePerMin: envInt(env, 'RELAY_RATE_PER_MIN', 2400),
    maxConcurrentRelay: envInt(env, 'MAX_CONCURRENT_RELAY', 200),
    relayCacheTtlMs: envInt(env, 'RELAY_CACHE_TTL_MS', 1500),
    relayCacheMaxEntries: envInt(env, 'RELAY_CACHE_MAX_ENTRIES', 500),
    upstreamGetTimeoutMs: envInt(env, 'UPSTREAM_GET_TIMEOUT_MS', 10000),
    upstreamPostTimeoutMs: envInt(env, 'UPSTREAM_POST_TIMEOUT_MS', 90000),
    snapshotIntervalMin: envInt(env, 'SNAPSHOT_INTERVAL_MIN', 5),
    maxSnapshots: envInt(env, 'MAX_SNAPSHOTS', 200),
    maxDailyBackups: envInt(env, 'MAX_DAILY_BACKUPS', 30),
    adminToken: env.ADMIN_TOKEN || '',
    claimLock: env.CLAIM_LOCK === '1',
    autoApprove: env.AUTO_APPROVE_ADMINS !== '0',
    vaultSecret: env.VAULT_SECRET || '',
    publicUrl: env.PUBLIC_URL || '',
    // ===== FIX 7f: SYNC_TOKEN for /sync authentication =====
    syncToken: env.SYNC_TOKEN || '',
    extraAllowedHosts: (env.EXTRA_ALLOWED_HOSTS || '')
      .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
    logRequests: envBool(env.LOG_REQUESTS),
    // ★ اتصال معاملاتی به صرافی‌ها (کلیدها ذخیره نمی‌شوند؛ فقط برای امضای همان درخواست)
    tradeEnabled: env.TRADE_ENABLED === undefined ? true : envBool(env.TRADE_ENABLED),
    tradeToken: env.TRADE_TOKEN || '',
    tradePublicRatePerMin: envInt(env, 'TRADE_PUBLIC_RATE_PER_MIN', 3000),
    tradeSignedRatePerMin: envInt(env, 'TRADE_SIGNED_RATE_PER_MIN', 120),
    tradeMarketsTtlMs: envInt(env, 'TRADE_MARKETS_TTL_MS', 10 * 60 * 1000),
    tradeTickersTtlMs: envInt(env, 'TRADE_TICKERS_TTL_MS', 8000),
    tradeTimeoutMs: envInt(env, 'TRADE_TIMEOUT_MS', 15000),
    // ★ ربات ۲۴ساعتهٔ سمت سرور
    botEnabled: env.BOT_ENABLED === undefined ? true : envBool(env.BOT_ENABLED),
    botKey: env.BOT_KEY || '',
    botMax: envInt(env, 'BOT_MAX', 200),
    botMaxOrderUsd: envInt(env, 'BOT_MAX_ORDER_USD', 500),
    botMinEveryMin: envInt(env, 'BOT_MIN_EVERY_MIN', 5),
    botParallel: envInt(env, 'BOT_PARALLEL', 3),
    tradeAdminToken: env.TRADE_ADMIN_TOKEN || '',
    aiKey: env.AI_API_KEY || '',
    aiBaseUrl: env.AI_BASE_URL || '',
    aiModel: env.AI_MODEL || '',
  };
}

function makeLogger(silent = false) {
  return (level, msg, extra) => {
    if (silent) return;
    process.stdout.write(JSON.stringify({ t: new Date().toISOString(), level, msg, ...extra }) + '\n');
  };
}

/* ------------------------------ ابزارها ------------------------------ */

function httpErr(status, code) {
  const e = new Error(code);
  e.status = status;
  e.code = code;
  return e;
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return (
      a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168)
    );
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    if (x === '::' || x === '::1') return true;
    if (x.startsWith('::ffff:')) {
      const rest = x.slice(7);
      return net.isIPv4(rest) ? isPrivateIp(rest) : true;
    }
    return /^(fc|fd|fe[89ab])/.test(x);
  }
  return true; // ناشناخته = غیرمجاز
}

function makeHostChecker(list) {
  return (host) => {
    const h = String(host).toLowerCase().replace(/\.$/, '');
    return list.some((x) => h === x || h.endsWith('.' + x));
  };
}

class RateLimiter {
  constructor(limit, windowMs = 60000) {
    this.limit = limit;
    this.win = windowMs;
    this.map = new Map();
  }
  hit(key, now = Date.now()) {
    if (this.limit <= 0) return { ok: true, retryAfter: 0 };
    let e = this.map.get(key);
    if (!e || now >= e.reset) {
      if (this.map.size > 200000) this.map.clear(); // دفاع در برابر پر شدن حافظه
      e = { count: 0, reset: now + this.win };
      this.map.set(key, e);
    }
    e.count++;
    return { ok: e.count <= this.limit, retryAfter: Math.max(1, Math.ceil((e.reset - now) / 1000)) };
  }
  sweep(now = Date.now()) {
    for (const [k, e] of this.map) if (now >= e.reset) this.map.delete(k);
  }
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = parseInt(req.headers['content-length'], 10);
    if (Number.isFinite(declared) && declared > limit) {
      req.resume();
      return reject(httpErr(413, 'too_large'));
    }
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(httpErr(413, 'too_large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
    req.on('aborted', () => reject(httpErr(400, 'aborted')));
  });
}

function sendJson(res, status, obj, extra) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8', ...extra });
  res.end(body);
}

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

/* اعتبارسنجی سند همگام‌سازی: یا پاکتِ رمزنگاری‌شده، یا سند ساده با فیلد v */
/* حذف کلیدهای API از سند همگام‌سازی (متن ساده): هرگز نباید به کاربران برسد */
function scrubDoc(text) {
  try {
    const o = JSON.parse(text);
    if (o && typeof o === 'object' && !o.encrypted) {
      let ch = false;
      const SECRET_KEYS = ['aiKeysShared', 'aiKeysAdmin', 'aiKeys', 'irApiKey', 'apiKey', 'apiKeys', 'adminToken', 'vaultSecret'];
      const strip = (x) => {
        if (!x || typeof x !== 'object') return;
        for (const k of SECRET_KEYS) if (k in x) { delete x[k]; ch = true; }
      };
      strip(o); strip(o.data); strip(o.settings);
      if (o.data && typeof o.data === 'object') strip(o.data.settings);
      if (ch) return JSON.stringify(o);
    }
  } catch { /* نه JSON */ }
  return text;
}

/* ادغام سمت سرور: جلوگیری از «آخرین نوشتن برنده است» (گم‌شدن تیکت/پرداخت/ثبت‌نام کاربران هم‌زمان).
   فقط وقتی هر دو سند رمزنگاری‌نشده باشند؛ در غیر این صورت رفتار قبلی. */
const MERGE_ARRAYS = ['users', 'payments', 'tickets', 'discounts', 'notifications', 'settingsLog', 'vipPosts', 'tournaments', 'customPages', 'payouts', 'adminSalaries', 'ads', 'analysisLog'];
const MERGE_CAP = { notifications: 2000, settingsLog: 500, analysisLog: 2000 };
const MERGE_OBJECTS = ['settings', 'catalog', 'costs', 'referralProgram', 'vpnMsg', 'exchangesState'];
function mergeDocs(oldText, newText) {
  try {
    const a = JSON.parse(oldText), b = JSON.parse(newText);
    if (!a || !b || typeof a !== 'object' || typeof b !== 'object' || a.encrypted || b.encrypted || Array.isArray(a) || Array.isArray(b)) return newText;
    const out = { ...a, ...b };
    for (const k of MERGE_ARRAYS) {
      const x = Array.isArray(a[k]) ? a[k] : [], y = Array.isArray(b[k]) ? b[k] : [];
      if (!x.length && !y.length) continue;
      const map = new Map();
      let loose = 0;
      for (const r of [...x, ...y]) {
        if (!r || typeof r !== 'object') continue;
        const id = r.id !== undefined && r.id !== null ? String(r.id) : '__n' + (loose++);
        const cur = map.get(id);
        if (!cur || (r.updatedAt || 0) >= (cur.updatedAt || 0)) map.set(id, r);
      }
      let arr = [...map.values()];
      const cap = MERGE_CAP[k];
      if (cap && arr.length > cap) arr = arr.sort((m, n) => (n.updatedAt || n.at || n.createdAt || 0) - (m.updatedAt || m.at || m.createdAt || 0)).slice(0, cap);
      out[k] = arr;
    }
    for (const k of MERGE_OBJECTS) {
      if (a[k] && typeof a[k] === 'object' && b[k] && typeof b[k] === 'object') {
        if (k === 'exchangesState' || k === 'costs') { out[k] = (b[k].updatedAt || 0) >= (a[k].updatedAt || 0) ? b[k] : a[k]; if (k === 'costs' && !(a[k].updatedAt || b[k].updatedAt)) out[k] = b[k]; }
        else out[k] = (b[k].updatedAt || 0) >= (a[k].updatedAt || 0) ? b[k] : a[k];
      } else if (a[k] && !b[k]) out[k] = a[k];
    }
    out.syncedAt = Math.max(a.syncedAt || 0, b.syncedAt || 0, Date.now());
    return JSON.stringify(out);
  } catch { return newText; }
}

function validateDoc(text) {
  let o;
  try { o = JSON.parse(text); } catch { return false; }
  if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
  if (o.encrypted && (o.ct || o.enc)) return true;
  return o.v !== undefined;
}

/* ------------------------- ذخیره‌سازی + بکاپ ------------------------- */

class SyncStore {
  constructor(cfg, log) {
    this.cfg = cfg;
    this.log = log;
    this.file = path.join(cfg.dataDir, 'sync.json');
    this.backupDir = path.join(cfg.dataDir, 'backups');
    this.text = null;
    this.gz = null;
    this.payload = null;
    this.updatedAt = 0;
    this.lastSnapshotAt = 0;
    this.writes = 0;
    this.chain = Promise.resolve();
  }

  async init() {
    await fsp.mkdir(this.backupDir, { recursive: true });
    try {
      this.text = await fsp.readFile(this.file, 'utf8');
      this.updatedAt = (await fsp.stat(this.file)).mtimeMs;
      JSON.parse(this.text);
    } catch (e) {
      if (e.code === 'ENOENT') {
        this.text = null;
      } else {
        this.log('error', 'sync.json خراب است؛ تلاش برای بازیابی از آخرین بکاپ', { err: String(e.message) });
        this.text = null;
        await this._recoverFromBackup();
      }
    }
    const snaps = await this._list('sync-');
    if (snaps.length) {
      try { this.lastSnapshotAt = (await fsp.stat(path.join(this.backupDir, snaps[snaps.length - 1]))).mtimeMs; } catch { /* ignore */ }
    }
  }

  async _list(prefix) {
    try { return (await fsp.readdir(this.backupDir)).filter((f) => f.startsWith(prefix)).sort(); } catch { return []; }
  }

  async _recoverFromBackup() {
    const all = [...(await this._list('sync-')), ...(await this._list('daily-'))].reverse();
    for (const f of all) {
      try {
        const t = await fsp.readFile(path.join(this.backupDir, f), 'utf8');
        if (validateDoc(t)) {
          this.text = t;
          this.updatedAt = Date.now();
          await fsp.writeFile(this.file, t);
          this.log('warn', 'بازیابی از بکاپ انجام شد', { file: f });
          return;
        }
      } catch { /* بعدی */ }
    }
  }

  async _prune(prefix, keep) {
    const files = await this._list(prefix);
    for (const f of files.slice(0, Math.max(0, files.length - keep))) {
      await fsp.unlink(path.join(this.backupDir, f)).catch(() => {});
    }
  }

  async _snapshot(now) {
    if (this.text === null) return;
    const dueSnap = now - this.lastSnapshotAt >= this.cfg.snapshotIntervalMin * 60000;
    if (dueSnap) {
      const name = 'sync-' + new Date(now).toISOString().replace(/[:.]/g, '-') + '.json';
      await fsp.writeFile(path.join(this.backupDir, name), this.text);
      this.lastSnapshotAt = now;
      await this._prune('sync-', this.cfg.maxSnapshots);
    }
    const daily = 'daily-' + new Date(now).toISOString().slice(0, 10) + '.json';
    const dailyPath = path.join(this.backupDir, daily);
    const exists = await fsp.access(dailyPath).then(() => true, () => false);
    if (!exists) {
      await fsp.writeFile(dailyPath, this.text);
      await this._prune('daily-', this.cfg.maxDailyBackups);
    }
  }

  get() { return this.text; }

  /* پاسخ آمادهٔ GET: {"ok":true,"doc":<سند>} — متن هنگام ذخیره اعتبارسنجی شده، پس parse/stringify مجدد لازم نیست */
  getPayload() {
    if (this.text === null) return null;
    if (!this.payload) this.payload = Buffer.from('{"ok":true,"doc":' + this.text + '}');
    return this.payload;
  }

  async getGzip() {
    const payload = this.getPayload();
    if (!payload) return null;
    if (!this.gz) {
      const gz = await new Promise((res, rej) => zlib.gzip(payload, (e, b) => (e ? rej(e) : res(b))));
      if (payload === this.payload) this.gz = gz; // اگر در این فاصله سند عوض شده، کش نکن
      return gz;
    }
    return this.gz;
  }

  /* نوشتن‌ها پشت‌سرهم و اتمیک انجام می‌شوند (نوشتن در فایل موقت + rename) */
  put(text) {
    const run = async () => {
      const now = Date.now();
      await this._snapshot(now);
      const tmp = this.file + '.tmp';
      const fh = await fsp.open(tmp, 'w');
      try { await fh.writeFile(text); await fh.sync(); } finally { await fh.close(); }
      await fsp.rename(tmp, this.file);
      this.text = text;
      this.payload = null;
      this.gz = null;
      this.updatedAt = now;
      this.writes++;
    };
    const p = this.chain.then(run);
    this.chain = p.catch(() => {});
    return p;
  }

  async backupCount() {
    return (await this._list('sync-')).length + (await this._list('daily-')).length;
  }
}

/* ------------------------------ برنامه ------------------------------ */

async function createApp(cfg, deps = {}) {
  const log = deps.log || makeLogger(false);
  const fetchImpl = deps.fetch || globalThis.fetch;
  const hostAllowed = makeHostChecker([...DEFAULT_ALLOWED_HOSTS, ...cfg.extraAllowedHosts]);

  /* DNS با کش ۶۰ ثانیه‌ای؛ برای جلوگیری از SSRF به آدرس‌های داخلی */
  const dnsCache = new Map();
  const lookup = deps.lookup || (async (host) => {
    const hit = dnsCache.get(host);
    if (hit && hit.exp > Date.now()) return hit.addrs;
    const addrs = await dns.lookup(host, { all: true });
    dnsCache.set(host, { addrs, exp: Date.now() + 60000 });
    if (dnsCache.size > 1000) dnsCache.clear();
    return addrs;
  });

  const store = new SyncStore(cfg, log);
  await store.init();
  if (store.text) { const sc = scrubDoc(store.text); if (sc !== store.text) { await store.put(sc); log('warn', 'کلیدهای API از سند همگام‌سازی پاک شدند'); } }
  /* ===== v18.6: پوشهٔ امن اسرار — کلیدها و دسترسی مدیر؛ بدون وارد کردن توکن ===== */
  const secretsDir = path.join(cfg.dataDir, 'secrets');
  await fsp.mkdir(secretsDir, { recursive: true, mode: 0o700 });
  try { await fsp.chmod(secretsDir, 0o700); await fsp.chmod(cfg.dataDir, 0o700); } catch { /* ویندوز */ }
  let vaultSecret = cfg.vaultSecret || cfg.adminToken;
  if (!vaultSecret) {
    const kf = path.join(secretsDir, 'vault.key');
    try { vaultSecret = (await fsp.readFile(kf, 'utf8')).trim(); } catch { vaultSecret = ''; }
    if (!vaultSecret) { vaultSecret = crypto.randomBytes(32).toString('hex'); await fsp.writeFile(kf, vaultSecret, { mode: 0o600 }); }
  }
  let vaultDir = secretsDir;
  try { await fsp.access(path.join(cfg.dataDir, 'vault.json')); vaultDir = cfg.dataDir; } catch { /* نصب تازه: داخل secrets */ }
  const vault = new Vault(vaultDir, vaultSecret);
  await vault.init();
  const adminsFile = path.join(secretsDir, 'admins.json');
  let adminsDb = { admins: [], pending: [] };
  try { adminsDb = { admins: [], pending: [], ...JSON.parse(await fsp.readFile(adminsFile, 'utf8')) }; } catch { /* اولین اجرا */ }
  const saveAdmins = async () => { const tmp = adminsFile + '.tmp'; await fsp.writeFile(tmp, JSON.stringify(adminsDb, null, 1), { mode: 0o600 }); await fsp.rename(tmp, adminsFile); };
  const keyHash = (k) => crypto.createHash('sha256').update('tyar-admin|' + k).digest('hex');
  /* ----- ثبت‌نام دائمی سرورها (آدرس/IP) — غیرمحرمانه، با امضا برای کلاینت ----- */
  const serversFile = path.join(secretsDir, 'servers.json');
  try { await fsp.access(serversFile); } catch { try { await fsp.rename(path.join(cfg.dataDir, 'servers.json'), serversFile); } catch { /* نصب تازه */ } }
  const SRV_RE = /^https?:\/\/[A-Za-z0-9.-]+(:\d{1,5})?(\/[A-Za-z0-9._~%/-]*)?$/;
  let servers = [];
  try { servers = JSON.parse(await fsp.readFile(serversFile, 'utf8')); } catch { servers = []; }
  const saveServers = async () => { const tmp = serversFile + '.tmp'; await fsp.writeFile(tmp, JSON.stringify(servers, null, 1), { mode: 0o600 }); await fsp.rename(tmp, serversFile); };
  if (!servers.length && cfg.publicUrl && SRV_RE.test(cfg.publicUrl)) { servers = [{ url: cfg.publicUrl.replace(/\/+$/, ''), label: 'سرور اصلی', enabled: true, at: Date.now() }]; await saveServers(); }
  const signServers = (list) => crypto.createHash('sha256').update((cfg.syncToken || '') + '|' + list.map((x) => x.url).join('\n') + '|' + (cfg.syncToken || '')).digest('hex');
  const vaultLimiter = new RateLimiter(20);
  const aiLimiter = new RateLimiter(cfg.relayRatePerMin || 60);

  const syncLimiter = new RateLimiter(cfg.syncRatePerMin);
  const relayLimiter = new RateLimiter(cfg.relayRatePerMin);
  const sweeper = setInterval(() => { syncLimiter.sweep(); relayLimiter.sweep(); }, 60000);
  sweeper.unref();

  const startedAt = Date.now();
  const stats = {
    syncGets: 0, syncPuts: 0, syncRejected: 0,
    relayRequests: 0, relayCacheHits: 0, relayCoalesced: 0, relayErrors: 0, relayBusy: 0,
    rateLimited: 0, hosts: {},
  };
  const hostStat = (h) => (stats.hosts[h] ||= { ok: 0, err: 0, s403: 0, s429: 0, s451: 0 });

  const cache = new Map();     // url → {status, ctype, buf, exp}
  const inflight = new Map();  // url → Promise
  let activeRelay = 0;

  function clientIp(req) {
    if (cfg.trustProxy) {
      const cf = req.headers['cf-connecting-ip'];
      if (cf) return String(cf).trim();
      const xff = req.headers['x-forwarded-for'];
      if (xff) return String(xff).split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }

  async function assertSafeTarget(u) {
    if (u.protocol !== 'https:') throw httpErr(400, 'https_only');
    if (u.username || u.password) throw httpErr(400, 'bad_url');
    if (u.port && u.port !== '443') throw httpErr(403, 'port_not_allowed');
    if (net.isIP(u.hostname) || u.hostname.startsWith('[')) throw httpErr(403, 'ip_not_allowed');
    if (!hostAllowed(u.hostname)) throw httpErr(403, 'host_not_allowed');
    let addrs;
    try { addrs = await lookup(u.hostname); } catch { throw httpErr(502, 'dns_failed'); }
    if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw httpErr(403, 'private_address');
  }

  /* درخواست به مقصد؛ ریدایرکت‌ها دستی و با بررسی مجدد دامنه دنبال می‌شوند */
  async function upstreamFetch(target, method, headers, body, timeoutMs, clientSignal) {
    let current = target;
    let m = method;
    let b = body;
    const signals = [AbortSignal.timeout(timeoutMs)];
    if (clientSignal) signals.push(clientSignal);
    const signal = AbortSignal.any(signals);
    for (let hop = 0; hop <= 3; hop++) {
      await assertSafeTarget(current);
      const resp = await fetchImpl(current.toString(), { method: m, headers, body: b, redirect: 'manual', signal });
      if ([301, 302, 303, 307, 308].includes(resp.status)) {
        const loc = resp.headers.get('location');
        if (resp.body) resp.body.cancel().catch(() => {});
        if (!loc) throw httpErr(502, 'bad_redirect');
        try { current = new URL(loc, current); } catch { throw httpErr(502, 'bad_redirect'); }
        if (resp.status === 303 || ((resp.status === 301 || resp.status === 302) && m === 'POST')) { m = 'GET'; b = undefined; }
        continue;
      }
      return resp;
    }
    throw httpErr(502, 'too_many_redirects');
  }

  const mapUpstreamError = (e) => {
    if (e && e.status) return e;
    if (e && (e.name === 'TimeoutError' || e.name === 'AbortError')) return httpErr(504, 'upstream_timeout');
    return httpErr(502, 'upstream_error');
  };

  function sendBuffered(res, r, cacheState) {
    res.writeHead(r.status, {
      ...BASE_HEADERS,
      'Content-Type': r.ctype,
      'Content-Length': r.buf.length,
      'X-Tradyar-Relay': '1',
      'X-Relay-Cache': cacheState,
    });
    res.end(r.buf);
  }

  async function handleRelay(req, res, url) {
    stats.relayRequests++;
    const raw = url.searchParams.get('u');
    if (!raw) throw httpErr(400, 'missing_u');
    if (raw.length > 4096) throw httpErr(414, 'url_too_long');
    if (req.method !== 'GET' && req.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    let target;
    try { target = new URL(raw); } catch { throw httpErr(400, 'bad_url'); }
    await assertSafeTarget(target);

    const host = target.hostname.toLowerCase();
    const hs = hostStat(host);
    const auth = req.headers['authorization'];
    const ct = req.headers['content-type'];
    const headers = {
      'user-agent': 'Mozilla/5.0 (compatible; TradYarRelay/' + VERSION + ')',
      accept: 'application/json, text/plain, */*',
    };
    if (ct) headers['content-type'] = ct;
    if (auth) headers['authorization'] = auth;
    // ★ هدرهای احراز هویت سایر سرویس‌های هوش مصنوعی (Claude و ...)
    for (const h of ['x-api-key', 'anthropic-version', 'x-goog-api-key']) {
      if (req.headers[h]) headers[h] = String(req.headers[h]);
    }

    const body = req.method === 'POST' ? await readBody(req, cfg.maxRelayBody) : undefined;
    const cacheable = req.method === 'GET' && !auth && !req.headers['x-api-key'] && cfg.relayCacheTtlMs > 0;
    const key = target.toString();

    if (cacheable) {
      const hit = cache.get(key);
      if (hit && hit.exp > Date.now()) {
        stats.relayCacheHits++;
        return sendBuffered(res, hit, 'HIT');
      }
      const pending = inflight.get(key);
      if (pending) {
        stats.relayCoalesced++;
        const r = await pending;
        return sendBuffered(res, r, 'COALESCED');
      }
    }

    if (activeRelay >= cfg.maxConcurrentRelay) {
      stats.relayBusy++;
      throw httpErr(503, 'busy');
    }

    const note = (status) => {
      if (status >= 200 && status < 400) hs.ok++;
      else {
        hs.err++;
        if (status === 403) hs.s403++;
        else if (status === 429) hs.s429++;
        else if (status === 451) hs.s451++;
      }
    };

    activeRelay++;
    try {
      if (cacheable) {
        // درخواست مشترک: به قطع شدن یک کلاینت وابسته نیست
        const run = (async () => {
          const resp = await upstreamFetch(target, 'GET', headers, undefined, cfg.upstreamGetTimeoutMs, null);
          const declared = parseInt(resp.headers.get('content-length'), 10);
          if (Number.isFinite(declared) && declared > cfg.maxRelayResponse) throw httpErr(502, 'response_too_large');
          const buf = Buffer.from(await resp.arrayBuffer());
          if (buf.length > cfg.maxRelayResponse) throw httpErr(502, 'response_too_large');
          note(resp.status);
          return { status: resp.status, ctype: resp.headers.get('content-type') || 'application/json', buf };
        })();
        inflight.set(key, run);
        let r;
        try { r = await run; } finally { inflight.delete(key); }
        if (r.status >= 200 && r.status < 300) {
          cache.set(key, { ...r, exp: Date.now() + cfg.relayCacheTtlMs });
          while (cache.size > cfg.relayCacheMaxEntries) cache.delete(cache.keys().next().value);
        }
        return sendBuffered(res, r, 'MISS');
      }

      // POST یا درخواست دارای Authorization: بدون کش، پاسخ مستقیم عبور داده می‌شود
      const ac = new AbortController();
      res.on('close', () => { if (!res.writableEnded) ac.abort(); });
      const resp = await upstreamFetch(target, req.method, headers, body, cfg.upstreamPostTimeoutMs, ac.signal);
      note(resp.status);
      res.writeHead(resp.status, {
        ...BASE_HEADERS,
        'Content-Type': resp.headers.get('content-type') || 'application/json',
        'X-Tradyar-Relay': '1',
        'X-Relay-Cache': 'BYPASS',
      });
      if (!resp.body) return res.end();
      const stream = Readable.fromWeb(resp.body);
      stream.on('error', () => res.destroy());
      stream.pipe(res);
    } catch (e) {
      hs.err++;
      throw e;
    } finally {
      activeRelay--;
    }
  }

  async function handleSync(req, res) {
    // ===== FIX 7f: Authentication on /sync endpoint =====
    if (cfg.syncToken) {
      const provided = req.headers['x-tradyar-token'] || '';
      if (!safeEqual(provided, cfg.syncToken)) {
        stats.syncRejected++;
        throw httpErr(401, 'unauthorized');
      }
    } else {
      console.warn('[SECURITY] SYNC_TOKEN not set — /sync endpoint is open!');
    }
    if (req.method === 'GET') {
      stats.syncGets++;
      const text = store.get();
      if (text === null) return sendJson(res, 200, { ok: false, reason: 'no_data' });
      const wantsGzip = /\bgzip\b/.test(req.headers['accept-encoding'] || '') && text.length > 1024;
      const headers = { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8', Vary: 'Accept-Encoding' };
      if (wantsGzip) {
        const gz = await store.getGzip();
        res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': gz.length });
        return res.end(gz);
      }
      const out = store.getPayload();
      res.writeHead(200, { ...headers, 'Content-Length': out.length });
      return res.end(out);
    }
    if (req.method === 'POST') {
      const text = scrubDoc(await readBody(req, cfg.maxSyncBytes));
      if (!validateDoc(text)) {
        stats.syncRejected++;
        throw httpErr(400, 'invalid_doc');
      }
      const prev = store.get();
      const merged = prev ? mergeDocs(prev, text) : text;
      await store.put(merged);
      stats.syncPuts++;
      return sendJson(res, 200, { ok: true, size: merged.length, at: store.updatedAt });
    }
    throw httpErr(405, 'method_not_allowed');
  }


  /* ===================== معاملات و تحلیل روی صرافی‌های واقعی ===================== */

  const tradeHostAllowed = makeHostChecker(ALL_HOSTS);
  const tradePubLimiter = new RateLimiter(cfg.tradePublicRatePerMin);
  const tradeSignedLimiter = new RateLimiter(cfg.tradeSignedRatePerMin);
  const tradeSweep = setInterval(() => { tradePubLimiter.sweep(); tradeSignedLimiter.sweep(); }, 60000);
  tradeSweep.unref();
  const marketsCache = new Map(); // ex → {at, list, map, inflight}
  const tickersCache = new Map(); // ex → {at, list, inflight}
  const klinesCache = new Map();  // key → {at, data}
  stats.trade = { public: 0, signed: 0, orders: 0, errors: 0 };

  /* HTTP به صرافی: فقط دامنه‌های کانکتورها، فقط HTTPS، بدون ریدایرکت، با بررسی DNS */
  const tradeCtx = {
    now: () => (deps.now ? deps.now() : Date.now()),
    async http(method, urlStr, { headers = {}, body } = {}) {
      let u;
      try { u = new URL(urlStr); } catch { throw httpErr(400, 'bad_url'); }
      if (u.protocol !== 'https:' || !tradeHostAllowed(u.hostname)) throw httpErr(403, 'host_not_allowed');
      let addrs;
      try { addrs = await lookup(u.hostname); } catch { throw httpErr(502, 'dns_failed'); }
      if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw httpErr(403, 'private_address');
      const resp = await fetchImpl(u.toString(), {
        method, redirect: 'manual', signal: AbortSignal.timeout(cfg.tradeTimeoutMs),
        headers: { 'user-agent': 'TradYar/' + VERSION, accept: 'application/json', ...headers }, body,
      });
      const text = await resp.text();
      let json = null;
      try { json = JSON.parse(text); } catch { /* ممکن است JSON نباشد */ }
      return { status: resp.status, json, text: text.slice(0, 2000) };
    },
  };

  function getConnector(id) {
    const c = CONNECTORS[String(id || '').toLowerCase()];
    if (!c) throw httpErr(400, 'unknown_exchange');
    return c;
  }

  async function getMarkets(c, force) {
    let e = marketsCache.get(c.id);
    if (e && !force && Date.now() - e.at < cfg.tradeMarketsTtlMs) return e;
    if (e && e.inflight) return e.inflight;
    const inflight = (async () => {
      const list = await c.markets(tradeCtx);
      const map = new Map(list.map((m) => [m.symbol, m]));
      const fresh = { at: Date.now(), list, map };
      marketsCache.set(c.id, fresh);
      return fresh;
    })();
    marketsCache.set(c.id, { ...(e || { at: 0, list: [], map: new Map() }), inflight });
    try { return await inflight; } catch (err) { if (e) marketsCache.set(c.id, e); else marketsCache.delete(c.id); throw err; }
  }

  async function getTickers(c) {
    const e = tickersCache.get(c.id);
    if (e && Date.now() - e.at < cfg.tradeTickersTtlMs) return e.list;
    if (e && e.inflight) return e.inflight;
    const inflight = c.tickers(tradeCtx).then((list) => { tickersCache.set(c.id, { at: Date.now(), list }); return list; });
    tickersCache.set(c.id, { ...(e || { at: 0, list: [] }), inflight });
    try { return await inflight; } catch (err) { if (e && e.list) tickersCache.set(c.id, { at: e.at, list: e.list }); else tickersCache.delete(c.id); throw err; }
  }

  const sanitizeCreds = (cr) => {
    if (!cr || typeof cr !== 'object') throw httpErr(400, 'missing_creds');
    const out = {};
    for (const k of ['apiKey', 'apiSecret', 'passphrase']) {
      if (cr[k] !== undefined) {
        const v = String(cr[k]).trim();
        if (v.length > 512 || /[\r\n]/.test(v)) throw httpErr(400, 'bad_creds');
        out[k] = v;
      }
    }
    return out;
  };

  /* خطاهای صرافی → پاسخ مشخص و قابل‌نمایش به کاربر (بدون افشای کلیدها) */
  const exchangeFail = (res, e) => {
    stats.trade.errors++;
    sendJson(res, 422, { ok: false, error: 'exchange_error', message: String(e.message || 'خطای صرافی').slice(0, 300), code: e.exCode !== undefined ? String(e.exCode) : undefined, status: e.exStatus });
  };

  /* ثبت سفارش + محافظت بومی (مشترک بین مسیر /order و ربات ۲۴ساعته) */
  async function placeOrderFlow(c, creds, o, protIn) {
    const mk = (await getMarkets(c)).map.get(String(o.symbol));
    const prepared = prepareOrder(mk, o);
    const order = {
      ...prepared, symbol: mk.symbol, test: o.test === true, clientId: o.clientId ? String(o.clientId).slice(0, 36).replace(/[^\w-]/g, '') : undefined,
      sl: Number(o.sl) || 0, tp: Number(o.tp) || 0, leverage: Number(o.leverage) || 0, marginMode: o.marginMode === 'cross' ? 'cross' : o.marginMode ? 'isolated' : undefined, reduceOnly: o.reduceOnly === true,
    };
    if (c.type === 'futures' && order.leverage && mk.maxLeverage && order.leverage > mk.maxLeverage) throw new ExchangeError('اهرم بیشتر از سقف مجاز این جفت‌ارز است (' + mk.maxLeverage + ')', { code: 'leverage_too_high' });
    const r = await c.placeOrder(tradeCtx, creds, order);
    stats.trade.orders++;
    const out = { ok: true, exchange: c.id, test: order.test, symbol: mk.symbol, side: order.side, type: order.type, sent: { qty: order.qty, quoteQty: order.quoteQty, price: order.price }, orderId: r.orderId, status: r.status, filledQty: r.filledQty, quoteSpent: r.quoteSpent };
    // محافظت بومی: فیوچرز همراه سفارش؛ اسپات (Binance/OKX) بعد از پر شدن خرید مارکت
    const prot = protIn || {};
    if (c.type === 'futures') out.protection = { native: !!r.nativeProtection, mode: 'attached' };
    else if (order.side === 'buy' && (Number(prot.sl) > 0 || Number(prot.tp) > 0)) {
      if (typeof c.protect !== 'function' || c.id === 'mexc') out.protection = { native: false, reason: 'unsupported' };
      else if (order.type !== 'market' || order.test) out.protection = { native: false, reason: 'limit_pending' };
      else if (!(Number(prot.sl) > 0 && Number(prot.tp) > 0)) out.protection = { native: false, reason: 'need_both_sl_tp' };
      else {
        try {
          await new Promise((r2) => setTimeout(r2, deps.protectDelayMs !== undefined ? deps.protectDelayMs : 900));
          const bal = await c.balance(tradeCtx, creds);
          const free = (bal.balances.find((x) => x.asset.toUpperCase() === mk.base) || { free: 0 }).free;
          const est = Number(prot.refPrice) > 0 ? (Number(order.quoteQty) / Number(prot.refPrice)) * 0.998 : free;
          const qty = floorToStep(Math.min(free, est), mk.stepSize);
          if (!(Number(qty) > 0)) throw new ExchangeError('موجودی خریداری‌شده هنوز در حساب دیده نمی‌شود', { code: 'no_base_balance' });
          const pr = await c.protect(tradeCtx, creds, { market: mk, qty, sl: Number(prot.sl), tp: Number(prot.tp) });
          out.protection = { native: true, orderId: pr.orderId, qty };
        } catch (pe) {
          out.protection = { native: false, reason: 'failed', message: String(pe.message || '').slice(0, 200) };
        }
      }
    }
    return out;
  }

  let egressCache = null;
  async function handleTrade(req, res, url, p) {
    if (!cfg.tradeEnabled) throw httpErr(404, 'trade_disabled');
    if (cfg.tradeToken) {
      const provided = req.headers['x-tradyar-token'] || req.headers['x-trade-token'] || '';
      if (!safeEqual(provided, cfg.tradeToken)) throw httpErr(401, 'unauthorized');
    }
    const op = p.replace(/^\/trade(\/v1)?\/?/, '');
    const ip = clientIp(req);

    if (op === 'health') return sendJson(res, 200, { ok: true, trade: true, version: VERSION, exchanges: Object.keys(CONNECTORS).length, tokenRequired: !!cfg.tradeToken });
    if (op === 'exchanges') return sendJson(res, 200, { ok: true, exchanges: listExchanges().filter((x) => !(bots && bots.admin.disabledExchanges.includes(x.id))) });
    if (op === 'egress') {
      // IP خروجی سرور: همان چیزی که باید در «IP whitelist» کلید API صرافی ثبت شود
      if (!egressCache || Date.now() - egressCache.at > 600000) {
        try {
          const r = await fetchImpl('https://api.ipify.org?format=json', { signal: AbortSignal.timeout(6000) });
          const j = await r.json();
          egressCache = { at: Date.now(), ip: j.ip };
        } catch { egressCache = { at: Date.now(), ip: null }; }
      }
      return sendJson(res, 200, { ok: true, ip: egressCache.ip });
    }
    if (op === 'bot/info') return sendJson(res, 200, { ok: true, enabled: !!bots, ai: !!(bots && bots.aiConfigured()), caps: bots ? bots.caps : null, paused: !!(bots && bots.admin.paused), note: bots ? bots.admin.note : '', disabledExchanges: bots ? bots.admin.disabledExchanges : [] });
    if (req.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    if (op.startsWith('bot/')) return handleBot(req, res, op, ip);

    const SIGNED = new Set(['balance', 'verify', 'order', 'protect', 'orders', 'cancel', 'positions', 'close', 'leverage']);
    const PUBLIC = new Set(['markets', 'tickers', 'klines']);
    if (!SIGNED.has(op) && !PUBLIC.has(op)) throw httpErr(404, 'unknown_op');
    const lim = (SIGNED.has(op) ? tradeSignedLimiter : tradePubLimiter).hit(ip);
    if (!lim.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: lim.retryAfter }); }
    (SIGNED.has(op) ? (stats.trade.signed++) : (stats.trade.public++));

    let body;
    try { body = JSON.parse((await readBody(req, 64 * 1024)) || '{}'); } catch (e) { if (e.status) throw e; throw httpErr(400, 'bad_json'); }
    const c = getConnector(body.exchange);

    try {
      if (op === 'markets') {
        const m = await getMarkets(c, body.refresh === true);
        return sendJson(res, 200, { ok: true, exchange: c.id, type: c.type, at: m.at, markets: m.list });
      }
      if (op === 'tickers') {
        return sendJson(res, 200, { ok: true, exchange: c.id, at: Date.now(), tickers: await getTickers(c) });
      }
      if (op === 'klines') {
        const symbol = String(body.symbol || '');
        if (!symbol || symbol.length > 40) throw httpErr(400, 'bad_symbol');
        const limit = Math.max(20, Math.min(parseInt(body.limit, 10) || 300, 1000));
        const key = [c.id, symbol, body.interval, limit].join('|');
        const hit = klinesCache.get(key);
        let data;
        if (hit && Date.now() - hit.at < 3000) data = hit.data;
        else {
          data = await c.klines(tradeCtx, symbol, body.interval, limit);
          klinesCache.set(key, { at: Date.now(), data });
          while (klinesCache.size > 600) klinesCache.delete(klinesCache.keys().next().value);
        }
        return sendJson(res, 200, { ok: true, exchange: c.id, symbol, klines: data });
      }

      // ---------- عملیات امضاشده ----------
      const creds = sanitizeCreds(body.creds);
      if (op === 'balance' || op === 'verify') {
        const t0 = Date.now();
        const b = await c.balance(tradeCtx, creds);
        const out = { ok: true, exchange: c.id, latencyMs: Date.now() - t0, ...b };
        if (op === 'verify') {
          out.warnings = [];
          if (b.canWithdraw === true) out.warnings.push('این کلید دسترسی «برداشت» دارد — برای امنیت، کلید را فقط با دسترسی Spot/Futures Trade بسازید.');
          if (b.canTrade === false) out.warnings.push('این کلید اجازهٔ معامله ندارد.');
        }
        return sendJson(res, 200, out);
      }

      if (op === 'order') return sendJson(res, 200, await placeOrderFlow(c, creds, body.order || {}, body.protect));

      if (op === 'protect') {
        if (typeof c.protect !== 'function') throw new ExchangeError('این صرافی حد ضرر/سود بومی ندارد', { code: 'unsupported' });
        const mk = (await getMarkets(c)).map.get(String(body.symbol));
        if (!mk) throw new ExchangeError('جفت‌ارز پیدا نشد', { code: 'unknown_symbol' });
        const pr = await c.protect(tradeCtx, creds, { market: mk, qty: floorToStep(Number(body.qty), mk.stepSize), sl: Number(body.sl), tp: Number(body.tp) });
        return sendJson(res, 200, { ok: true, ...pr, raw: undefined });
      }
      if (op === 'orders') {
        if (typeof c.openOrders !== 'function') throw new ExchangeError('مشاهدهٔ سفارش‌های باز برای این صرافی در ترید یار پشتیبانی نمی‌شود', { code: 'unsupported' });
        return sendJson(res, 200, { ok: true, orders: await c.openOrders(tradeCtx, creds, body.symbol) });
      }
      if (op === 'cancel') {
        if (typeof c.cancelOrder !== 'function') throw new ExchangeError('لغو سفارش برای این صرافی در ترید یار پشتیبانی نمی‌شود', { code: 'unsupported' });
        const r = await c.cancelOrder(tradeCtx, creds, String(body.symbol), String(body.orderId));
        return sendJson(res, 200, { ok: true, orderId: r.orderId });
      }
      if (op === 'positions') {
        if (typeof c.positions !== 'function') return sendJson(res, 200, { ok: true, positions: [] });
        return sendJson(res, 200, { ok: true, positions: await c.positions(tradeCtx, creds, body.symbol) });
      }
      if (op === 'close') {
        if (typeof c.closePosition !== 'function') throw new ExchangeError('این صرافی موقعیت فیوچرز ندارد', { code: 'unsupported' });
        await c.closePosition(tradeCtx, creds, String(body.positionId));
        return sendJson(res, 200, { ok: true });
      }
      if (op === 'leverage') {
        if (typeof c.setLeverage !== 'function') throw new ExchangeError('این صرافی اهرم ندارد', { code: 'unsupported' });
        await c.setLeverage(tradeCtx, creds, String(body.symbol), Number(body.leverage), body.marginMode);
        return sendJson(res, 200, { ok: true });
      }
    } catch (e) {
      if (e instanceof ExchangeError) return exchangeFail(res, e);
      throw e;
    }
    throw httpErr(404, 'unknown_op');
  }


  /* ===================== ربات ۲۴ساعته ===================== */
  const bots = cfg.botEnabled && !deps.noBots ? new BotManager(cfg, {
    CONNECTORS, ctx: tradeCtx, getMarkets, getTickers, placeOrderFlow, fetch: fetchImpl, now: deps.now, log,
    aiAvailable: () => vault.items.some((p) => p.enabled && p.key && p.base && p.model),
    aiCall: async (msgs) => {
      const list = vault.items.filter((p) => p.enabled && p.key && p.base && p.model);
      let last = null;
      for (const p of list.slice(0, 4)) { try { return await callProvider(p, msgs); } catch (e) { last = e; } }
      throw last || new Error('no_provider');
    },
  }) : null;
  if (bots && !deps.manualBots) bots.start();

  async function handleBot(req, res, op, ip) {
    if (!bots) throw httpErr(404, 'bots_disabled');
    const lim = tradeSignedLimiter.hit(ip);
    if (!lim.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: lim.retryAfter }); }
    let body;
    try { body = JSON.parse((await readBody(req, 64 * 1024)) || '{}'); } catch (e) { if (e.status) throw e; throw httpErr(400, 'bad_json'); }
    const wrap = async (fn) => {
      try { return sendJson(res, 200, Object.assign({ ok: true }, await fn())); }
      catch (e) {
        if (e instanceof ExchangeError) return exchangeFail(res, e);
        if (e && e.status && e.code) return sendJson(res, e.status, { ok: false, error: e.code, message: e.message !== e.code ? e.message : undefined, code: e.exCode !== undefined ? String(e.exCode) : undefined });
        throw e;
      }
    };
    if (op.startsWith('bot/admin/')) {
      const okTok = cfg.tradeAdminToken && safeEqual(req.headers['x-admin-token'] || '', cfg.tradeAdminToken);
      if (!okTok && !isAdminReq(req)) throw httpErr(401, 'unauthorized');
      switch (op) {
        case 'bot/admin/list': return wrap(async () => ({ bots: bots.adminList(), summary: bots.adminSummary() }));
        case 'bot/admin/summary': return wrap(async () => ({ summary: bots.adminSummary() }));
        case 'bot/admin/detail': return wrap(async () => ({ bot: bots.adminDetail(body.botId) }));
        case 'bot/admin/stop': return wrap(async () => bots.adminStop(body.botId));
        case 'bot/admin/block': return wrap(async () => bots.adminBlock(body.botId, body.on !== false));
        case 'bot/admin/run': return wrap(async () => bots.adminRun(body.botId));
        case 'bot/admin/delete': return wrap(async () => bots.adminDelete(body.botId));
        case 'bot/admin/stopall': return wrap(async () => bots.adminStopAll());
        case 'bot/admin/expiry': return wrap(async () => bots.adminSetExpiry(body.botId, body.expiresAt));
        case 'bot/admin/config': return wrap(async () => ({ config: body && body.set ? bots._applyAdmin(body.set) : bots.adminView() }));
        default: throw httpErr(404, 'unknown_op');
      }
    }
    switch (op) {
      case 'bot/save': return wrap(async () => bots.save(body, sanitizeCreds));
      case 'bot/status': return wrap(async () => ({ bot: bots.view(bots._auth(body.botId, body.botToken)) }));
      case 'bot/update': return wrap(async () => ({ bot: bots.update(body.botId, body.botToken, body) }));
      case 'bot/start': return wrap(async () => ({ bot: bots.setRunning(body.botId, body.botToken, true) }));
      case 'bot/stop': return wrap(async () => ({ bot: bots.setRunning(body.botId, body.botToken, false) }));
      case 'bot/run': return wrap(async () => ({ bot: bots.runNow(body.botId, body.botToken) }));
      case 'bot/delete': return wrap(async () => bots.remove(body.botId, body.botToken));
      default: throw httpErr(404, 'unknown_op');
    }
  }

  /* ---------- گاوصندوق کلیدها (فقط مدیر با ADMIN_TOKEN) ---------- */
  const isAdminReq = (req) => {
    const t = String(req.headers['x-admin-token'] || '');
    if (!t) return false;
    if (cfg.adminToken && safeEqual(t, cfg.adminToken)) return true;
    if (t.length < 32) return false;
    const h = keyHash(t);
    return adminsDb.admins.some((a) => safeEqual(a.h, h));
  };
  const pay = await createPay({ cfg, secretsDir, log, sendJson, readBody, httpErr, safeEqual, isAdminReq });
  /* مدیر خودکار: اولین گوشیِ مدیر خودش را «ثبت» می‌کند؛ گوشی‌های بعدی با تأییدِ مدیر قبلی اضافه می‌شوند */
  async function handleAdminApi(req, res, p) {
    const rl = vaultLimiter.hit(clientIp(req));
    if (!rl.ok) throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter });
    const syncOk = !cfg.syncToken || safeEqual(req.headers['x-tradyar-token'] || '', cfg.syncToken);
    const admin = isAdminReq(req);
    if (!syncOk && !admin) throw httpErr(401, 'unauthorized');
    const now = Date.now();
    adminsDb.pending = adminsDb.pending.filter((x) => now - x.at < 86400000);
    if (p === '/admin/status' && req.method === 'GET') {
      const t = String(req.headers['x-admin-token'] || '');
      const h = t.length >= 32 ? keyHash(t) : '';
      const status = admin ? 'admin' : (h && adminsDb.pending.some((x) => x.h === h) ? 'pending' : 'none');
      return sendJson(res, 200, { ok: true, status, claimed: adminsDb.admins.length > 0 || !!cfg.adminToken });
    }
    if (p === '/admin/claim' && req.method === 'POST') {
      let body; try { body = JSON.parse(await readBody(req, 4096)); } catch { throw httpErr(400, 'bad_json'); }
      const key = String(body && body.key || '');
      if (!/^[A-Za-z0-9_-]{32,128}$/.test(key)) throw httpErr(400, 'bad_key');
      const label = String(body.label || '').slice(0, 40);
      const h = keyHash(key);
      if (adminsDb.admins.some((a) => a.h === h)) return sendJson(res, 200, { ok: true, status: 'admin' });
      if (admin || cfg.autoApprove || (!adminsDb.admins.length && !cfg.claimLock)) {
        adminsDb.admins.push({ h, label, at: now });
        await saveAdmins();
        log('info', 'admin device registered', { label, first: !admin });
        return sendJson(res, 200, { ok: true, status: 'admin', first: !admin });
      }
      if (!adminsDb.pending.some((x) => x.h === h)) {
        adminsDb.pending.push({ id: crypto.randomBytes(6).toString('hex'), h, label, at: now });
        if (adminsDb.pending.length > 10) adminsDb.pending = adminsDb.pending.slice(-10);
        await saveAdmins();
      }
      return sendJson(res, 202, { ok: true, status: 'pending' });
    }
    if (!admin) throw httpErr(401, 'unauthorized');
    if (p === '/admin/requests' && req.method === 'GET') {
      return sendJson(res, 200, { ok: true, requests: adminsDb.pending.map((x) => ({ id: x.id, label: x.label, at: x.at })) });
    }
    if (p === '/admin/approve' && req.method === 'POST') {
      let body; try { body = JSON.parse(await readBody(req, 2048)); } catch { throw httpErr(400, 'bad_json'); }
      const i = adminsDb.pending.findIndex((x) => x.id === String(body && body.id || ''));
      if (i < 0) throw httpErr(404, 'not_found');
      const [x] = adminsDb.pending.splice(i, 1);
      if (body.approve !== false) adminsDb.admins.push({ h: x.h, label: x.label, at: now });
      await saveAdmins();
      log('info', 'admin request ' + (body.approve === false ? 'rejected' : 'approved'), { label: x.label });
      return sendJson(res, 200, { ok: true });
    }
    throw httpErr(404, 'not_found');
  }
  async function handleVault(req, res) {
    const rl = vaultLimiter.hit(clientIp(req));
    if (!rl.ok) throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter });
    if (!vault.enabled) throw httpErr(503, 'vault_disabled');
    if (!isAdminReq(req)) throw httpErr(401, 'unauthorized');
    if (req.method === 'GET') return sendJson(res, 200, { ok: true, providers: vault.masked() });
    if (req.method === 'POST' || req.method === 'PUT') {
      let body;
      try { body = JSON.parse(await readBody(req, 256 * 1024)); } catch { throw httpErr(400, 'bad_json'); }
      await vault.replace(body && body.providers);
      log('info', 'vault updated', { n: vault.items.length });
      return sendJson(res, 200, { ok: true, providers: vault.masked() });
    }
    throw httpErr(405, 'method_not_allowed');
  }

  async function safeProviderUrl(raw) {
    let u;
    try { u = new URL(raw); } catch { throw httpErr(400, 'bad_provider_url'); }
    if (u.protocol !== 'https:' || u.username || u.password || (u.port && u.port !== '443')) throw httpErr(400, 'bad_provider_url');
    if (net.isIP(u.hostname) || u.hostname.startsWith('[')) throw httpErr(403, 'ip_not_allowed');
    let addrs;
    try { addrs = await lookup(u.hostname); } catch { throw httpErr(502, 'dns_failed'); }
    if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw httpErr(403, 'private_address');
    return u;
  }

  async function callProvider(p, msgs) {
    const sys = msgs.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
    const conv = msgs.filter((m) => m.role !== 'system').map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }));
    const base = p.base.replace(/\/+$/, '');
    let url, headers, body, parse;
    if (p.kind === 'anthropic') {
      url = base + '/messages';
      headers = { 'content-type': 'application/json', 'x-api-key': p.key, 'anthropic-version': '2023-06-01' };
      body = { model: p.model, max_tokens: 2000, messages: conv }; if (sys) body.system = sys;
      parse = (j) => (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
    } else if (p.kind === 'gemini') {
      url = base + '/models/' + encodeURIComponent(String(p.model).replace(/^models\//, '')) + ':generateContent';
      headers = { 'content-type': 'application/json', 'x-goog-api-key': p.key };
      body = { contents: conv.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })), generationConfig: { maxOutputTokens: 2000, temperature: 0.4 } };
      if (sys) body.systemInstruction = { parts: [{ text: sys }] };
      parse = (j) => ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map((x) => x.text || '').join('');
    } else {
      url = base + '/chat/completions';
      headers = { 'content-type': 'application/json', authorization: 'Bearer ' + p.key };
      body = { model: p.model, messages: (sys ? [{ role: 'system', content: sys }] : []).concat(conv) };
      if (/^(o\d|gpt-5)/i.test(p.model)) body.max_completion_tokens = 2500; else { body.max_tokens = 2000; body.temperature = 0.4; }
      parse = (j) => { const c = j.choices && j.choices[0] && j.choices[0].message ? j.choices[0].message.content : ''; return Array.isArray(c) ? c.map((x) => x.text || '').join('') : c; };
    }
    const u = await safeProviderUrl(url);
    const resp = await fetchImpl(u.toString(), { method: 'POST', headers, body: JSON.stringify(body), redirect: 'manual', signal: AbortSignal.timeout(45000) });
    if (!resp.ok) { if (resp.body) resp.body.cancel().catch(() => {}); throw httpErr(502, 'provider_http_' + resp.status); }
    const j = await resp.json();
    const text = parse(j || {});
    if (!text || !String(text).trim()) throw httpErr(502, 'provider_empty');
    return String(text);
  }

  async function handleAi(req, res) {
    if (req.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    if (cfg.syncToken && !safeEqual(req.headers['x-tradyar-token'] || '', cfg.syncToken) && !isAdminReq(req)) throw httpErr(401, 'unauthorized');
    const rl = aiLimiter.hit(clientIp(req));
    if (!rl.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter }); }
    let body;
    try { body = JSON.parse(await readBody(req, 96 * 1024)); } catch { throw httpErr(400, 'bad_json'); }
    const msgs = Array.isArray(body && body.messages) ? body.messages.slice(-30).map((m) => ({ role: String(m && m.role || 'user'), content: String(m && m.content || '').slice(0, 12000) })).filter((m) => m.content) : [];
    if (!msgs.length) throw httpErr(400, 'no_messages');
    const admin = isAdminReq(req);
    const list = vault.items.filter((p) => p.enabled && p.key && p.base && p.model && (admin || p.shared));
    if (!list.length) throw httpErr(503, 'no_provider');
    let last = null;
    for (const p of list.slice(0, 4)) {
      try { const text = await callProvider(p, msgs); return sendJson(res, 200, { ok: true, text, provider: p.name }); }
      catch (e) { last = e; log('warn', 'ai provider failed', { id: p.id, err: String(e && e.message) }); }
    }
    /* جزئیات خطای ارائه‌دهنده (ممکن است بخشی از کلید/آدرس را داشته باشد) فقط برای مدیر */
    throw httpErr(502, admin ? String((last && last.message) || 'all_providers_failed').replace(/(sk-|gsk_|AIza|xai-)[A-Za-z0-9_-]{6,}/g, '$1***') : 'ai_unavailable');
  }


  /* ===== v18.6: هیچ‌وقت داده از بین نمی‌رود =====
     وقتی مدیر سروری را از فهرست حذف می‌کند:
     ۱) رکورد سرور برای همیشه در data/servers-archive.json می‌ماند
     ۲) سند همگام‌سازی آن سرور گرفته و در data/inherited/ ذخیره می‌شود (هرگز پاک نمی‌شود)
     ۳) همان سند به «سرور بعدی» فهرست فرستاده می‌شود (اگر آن سرور هنوز داده‌ای ندارد، سند اصلی‌اش می‌شود)
     ۴) اگر سرور بعدی در دسترس نبود، هر ۵ دقیقه دوباره تلاش می‌شود */
  const archiveFile = path.join(secretsDir, 'servers-archive.json');
  const pendingFile = path.join(secretsDir, 'migrations-pending.json');
  const inheritDir = path.join(secretsDir, 'inherited');
  let archive = []; try { archive = JSON.parse(await fsp.readFile(archiveFile, 'utf8')); } catch { archive = []; }
  let pending = []; try { pending = JSON.parse(await fsp.readFile(pendingFile, 'utf8')); } catch { pending = []; }
  const writeJsonAtomic = async (f, v) => { const tmp = f + '.tmp'; await fsp.writeFile(tmp, JSON.stringify(v, null, 1), { mode: 0o600 }); await fsp.rename(tmp, f); };
  const normUrl = (u) => String(u || '').trim().replace(/\/+$/, '').toLowerCase();
  const selfUrl = cfg.publicUrl ? normUrl(cfg.publicUrl) : '';
  const slug = (u) => String(u).replace(/^https?:\/\//i, '').replace(/[^A-Za-z0-9.-]+/g, '_').slice(0, 80);

  async function archiveServer(x, extra) {
    archive.push({ url: x.url, label: x.label || '', enabled: x.enabled !== false, at: x.at || 0, removedAt: Date.now(), ...extra });
    if (archive.length > 5000) archive = archive.slice(-5000);
    await writeJsonAtomic(archiveFile, archive);
  }

  async function fetchRemovedDoc(url) {
    if (selfUrl && normUrl(url) === selfUrl) return { text: store.get(), source: 'self' };
    try {
      const u = new URL(url + '/sync');
      const host = u.hostname.replace(/^\[|\]$/g, '');
      const addrs = net.isIP(host) ? [{ address: host }] : await lookup(host);
      if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw new Error('private');
      const headers = cfg.syncToken ? { 'x-tradyar-token': cfg.syncToken } : {};
      const r = await fetchImpl(u.toString(), { headers, redirect: 'manual', signal: AbortSignal.timeout(15000) });
      if (r.ok) {
        const t = await r.text();
        if (t && validateDoc(t)) return { text: t, source: 'remote' };
      }
    } catch { /* برو سراغ نسخهٔ محلی */ }
    /* سرور حذف‌شده در دسترس نیست → نسخهٔ همین سرور (کلاینت‌ها به همهٔ سرورها همگام می‌شوند) */
    return { text: store.get(), source: 'local-fallback' };
  }

  async function inheritLocal(rec) {
    await fsp.mkdir(inheritDir, { recursive: true });
    const name = slug(rec.from) + '-' + new Date(rec.removedAt || Date.now()).toISOString().replace(/[:.]/g, '-') + '.json';
    await fsp.writeFile(path.join(inheritDir, name), JSON.stringify(rec), { mode: 0o600 });
    let adopted = false;
    if (store.get() === null && rec.doc && validateDoc(rec.doc)) { await store.put(scrubDoc(rec.doc)); adopted = true; }
    return { file: name, adopted };
  }

  async function deliverToTarget(target, rec, adminTok) {
    if (selfUrl && normUrl(target) === selfUrl) return inheritLocal(rec);
    const u = new URL(target + '/servers/inherit');
    const host = u.hostname.replace(/^\[|\]$/g, '');
    const addrs = net.isIP(host) ? [{ address: host }] : await lookup(host);
    if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw new Error('private_target');
    const headers = { 'content-type': 'application/json' };
    if (cfg.syncToken) headers['x-tradyar-token'] = cfg.syncToken;
    if (adminTok) headers['x-admin-token'] = adminTok;
    const r = await fetchImpl(u.toString(), { method: 'POST', headers, body: JSON.stringify(rec), redirect: 'manual', signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error('target_http_' + r.status);
    return r.json();
  }

  const pickTarget = (oldList, removedUrl, newList) => {
    const live = newList.filter((x) => x.enabled !== false).map((x) => x.url);
    if (!live.length) return null;
    const i = oldList.findIndex((x) => x.url === removedUrl);
    for (let k = 1; k <= oldList.length; k++) {
      const c = oldList[(i + k) % oldList.length];
      if (c && live.includes(c.url)) return c.url;
    }
    return live[0];
  };

  async function migrateRemoved(x, oldList, newList, adminTok) {
    const { text, source } = await fetchRemovedDoc(x.url);
    const rec = { v: 1, from: x.url, label: x.label || '', removedAt: Date.now(), source, doc: text };
    const target = pickTarget(oldList, x.url, newList);
    const keep = await inheritLocal({ ...rec, to: target });   // نسخهٔ محلی همیشه ذخیره می‌شود
    await archiveServer(x, { to: target, source, localFile: keep.file, hasData: !!text });
    if (!target || !text) return { url: x.url, to: target, ok: !!target, saved: keep.file, hasData: !!text };
    try { await deliverToTarget(target, rec, adminTok); return { url: x.url, to: target, ok: true, saved: keep.file }; }
    catch (e) {
      pending.push({ target, file: keep.file, from: x.url, tries: 0, at: Date.now() });
      await writeJsonAtomic(pendingFile, pending);
      log('warn', 'migration queued', { from: x.url, to: target, err: String(e && e.message) });
      return { url: x.url, to: target, ok: false, queued: true, saved: keep.file };
    }
  }

  async function retryPending() {
    if (!pending.length) return;
    const keep = [];
    for (const m of pending) {
      try {
        const rec = JSON.parse(await fsp.readFile(path.join(inheritDir, m.file), 'utf8'));
        await deliverToTarget(m.target, rec, '');
      } catch { m.tries = (m.tries || 0) + 1; keep.push(m); }
    }
    if (keep.length !== pending.length) { pending = keep; await writeJsonAtomic(pendingFile, pending); }
  }
  const migTimer = setInterval(() => { retryPending().catch(() => {}); }, 300000);
  migTimer.unref();

  async function handleInherit(req, res) {
    if (req.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    const okTok = cfg.syncToken && safeEqual(req.headers['x-tradyar-token'] || '', cfg.syncToken);
    if (!okTok && !isAdminReq(req)) throw httpErr(401, 'unauthorized');
    let rec;
    try { rec = JSON.parse(await readBody(req, cfg.maxSyncBytes)); } catch { throw httpErr(400, 'bad_json'); }
    if (!rec || typeof rec !== 'object' || !SRV_RE.test(String(rec.from || ''))) throw httpErr(400, 'bad_record');
    if (rec.doc != null && !validateDoc(String(rec.doc))) throw httpErr(400, 'invalid_doc');
    const out = await inheritLocal({ v: 1, from: String(rec.from), label: String(rec.label || '').slice(0, 60), removedAt: Number(rec.removedAt) || Date.now(), source: String(rec.source || ''), doc: rec.doc == null ? null : String(rec.doc) });
    log('info', 'inherited data from removed server', { from: rec.from, adopted: out.adopted });
    return sendJson(res, 200, { ok: true, ...out });
  }

  async function handleServers(req, res) {
    const rl = vaultLimiter.hit(clientIp(req));
    if (!rl.ok) throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter });
    if (req.method === 'GET') {
      if (cfg.syncToken && !safeEqual(req.headers['x-tradyar-token'] || '', cfg.syncToken) && !isAdminReq(req)) throw httpErr(401, 'unauthorized');
      const list = servers.filter((x) => x.enabled !== false);
      return sendJson(res, 200, { ok: true, servers: list, sig: signServers(list) });
    }
    if (req.method === 'PUT' || req.method === 'POST') {
      if (!isAdminReq(req)) throw httpErr(401, 'unauthorized');
      let body;
      try { body = JSON.parse(await readBody(req, 64 * 1024)); } catch { throw httpErr(400, 'bad_json'); }
      if (!body || !Array.isArray(body.servers) || body.servers.length > 30) throw httpErr(400, 'bad_list');
      const seen = new Set(); const next = [];
      for (const x of body.servers) {
        const url = String(x && x.url || '').trim().replace(/\/+$/, '');
        if (!SRV_RE.test(url) || url.length > 300 || seen.has(url)) continue;
        seen.add(url);
        next.push({ url, label: String(x.label || '').slice(0, 60), enabled: x.enabled !== false, at: Number(x.at) || Date.now() });
      }
      const oldList = servers;
      const nextUrls = new Set(next.map((x) => x.url));
      const removed = oldList.filter((x) => !nextUrls.has(x.url));
      servers = next; await saveServers();
      log('info', 'servers registry updated', { n: servers.length, removed: removed.length });
      const adminTok = String(req.headers['x-admin-token'] || '');
      const migrations = [];
      for (const x of removed) {
        try { migrations.push(await migrateRemoved(x, oldList, next, adminTok)); }
        catch (e) { migrations.push({ url: x.url, ok: false, error: String(e && e.message) }); log('error', 'migration failed', { url: x.url, err: String(e && e.message) }); }
      }
      return sendJson(res, 200, { ok: true, servers, sig: signServers(servers.filter((x) => x.enabled !== false)), migrations });
    }
    throw httpErr(405, 'method_not_allowed');
  }

  async function handleStatus(req, res) {
    if (!cfg.adminToken) throw httpErr(404, 'not_found');
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!m || !safeEqual(m[1], cfg.adminToken)) throw httpErr(401, 'unauthorized');
    const mem = process.memoryUsage();
    sendJson(res, 200, {
      ok: true,
      version: VERSION,
      node: process.version,
      uptimeSec: Math.round((Date.now() - startedAt) / 1000),
      memoryMB: Math.round(mem.rss / 1048576),
      sync: {
        exists: store.text !== null,
        bytes: store.text ? Buffer.byteLength(store.text) : 0,
        updatedAt: store.updatedAt ? new Date(store.updatedAt).toISOString() : null,
        writes: store.writes,
        backups: await store.backupCount(),
      },
      relay: { active: activeRelay, cacheEntries: cache.size },
      stats,
    });
  }

  async function serveApp(res) {
    try {
      const html = await fsp.readFile(path.join(__dirname, 'public', 'index.html'));
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      res.end(html);
    } catch { throw httpErr(404, 'app_not_deployed'); }
  }

  async function route(req, res) {
    const ip = clientIp(req);
    const url = new URL(req.url, 'http://localhost');
    const p = url.pathname.replace(/\/+$/, '') || '/';

    if (req.method === 'OPTIONS') {
      res.writeHead(204, BASE_HEADERS);
      return res.end();
    }
    if (p === '/health') {
      return sendJson(res, 200, { ok: true, service: 'tradyar', version: VERSION, uptimeSec: Math.round((Date.now() - startedAt) / 1000) });
    }
    if (p === '/status') return handleStatus(req, res);
    if (p === '/vault') return handleVault(req, res);
    if (p.startsWith('/admin/')) return handleAdminApi(req, res, p);
    if (p === '/servers') return handleServers(req, res);
    if (p === '/servers/inherit') return handleInherit(req, res);
    if (pay.isGatewayPath(p)) return pay.handle(req, res, url, p);
    if (p === '/app' || p === '/app/index.html') return serveApp(res);
    if (p === '/ai') return handleAi(req, res);
    if (p === '/trade' || p.startsWith('/trade/')) return handleTrade(req, res, url, p);

    if (p === '/relay') {
      const rl = relayLimiter.hit(ip);
      if (!rl.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter }); }
      return handleRelay(req, res, url);
    }
    if (p === '/' || p === '/sync') {
      const rl = syncLimiter.hit(ip);
      if (!rl.ok) { stats.rateLimited++; throw Object.assign(httpErr(429, 'rate_limited'), { retryAfter: rl.retryAfter }); }
      return handleSync(req, res);
    }
    throw httpErr(404, 'not_found');
  }

  const server = http.createServer(async (req, res) => {
    const t0 = Date.now();
    try {
      await route(req, res);
    } catch (e) {
      const err = mapUpstreamError(e);
      const isKnown = e && e.status;
      if (!isKnown) {
        stats.relayErrors++;
        log('error', 'خطای پیش‌بینی‌نشده', { url: String(req.url).slice(0, 200), err: String(e && e.message) });
      }
      if (!res.headersSent) {
        sendJson(res, err.status, { ok: false, error: err.code }, err.retryAfter ? { 'Retry-After': String(err.retryAfter) } : undefined);
      } else {
        res.destroy();
      }
    } finally {
      if (cfg.logRequests) {
        log('info', 'req', { m: req.method, u: String(req.url).slice(0, 120), s: res.statusCode, ms: Date.now() - t0, ip: clientIp(req) });
      }
    }
  });
  // ★ SRV-ROBUST: افزایش timeoutها برای پایداری بیشتر
  server.requestTimeout = 120000; // 2 دقیقه
  server.headersTimeout = 30000;
  server.keepAliveTimeout = 70000; // بیشتر از header timeout برای جلوگیری از خطای ECONNRESET
  // ★ SRV-ROBUST: فعال‌سازی keepAlive برای اتصال‌های ماندگار
  server.on('connection', (socket) => {
    socket.setTimeout(120000); // 2 دقیقه برای هر اتصال
    socket.setKeepAlive(true, 30000); // فعال‌سازی TCP keepAlive هر ۳۰ ثانیه
    socket.setNoDelay(true); // غیرفعال‌سازی Nagle's algorithm برای سرعت بیشتر
    socket.on('error', (e) => {
      // خطای اتصال — فقط لاگ بزن و ادامه بده
      if (e.code !== 'ECONNRESET' && e.code !== 'EPIPE') {
        log('warn', 'خطای سوکت', { err: String(e.message), code: e.code });
      }
    });
    socket.on('timeout', () => {
      // اتصال بی‌تحرک — ببندش
      socket.destroy();
    });
  });

  async function close() {
    clearInterval(sweeper);
    clearInterval(tradeSweep);
    clearInterval(migTimer);
    if (bots) bots.stop();
    await new Promise((resolve) => {
      const force = setTimeout(() => { server.closeAllConnections(); resolve(); }, 8000);
      force.unref();
      server.close(() => { clearTimeout(force); resolve(); });
      server.closeIdleConnections();
    });
    await store.chain;
  }

  return { server, store, stats, close, config: cfg, bots };
}

/* ------------------------------ اجرا ------------------------------ */

async function main() {
  const cfg = loadConfig();
  const log = makeLogger(false);
  const app = await createApp(cfg, { log });
  await new Promise((resolve, reject) => {
    app.server.once('error', reject);
    app.server.listen(cfg.port, cfg.host, resolve);
  });
  log('info', 'سرور ترید یار روشن شد', { port: cfg.port, host: cfg.host, version: VERSION, dataDir: cfg.dataDir, trustProxy: cfg.trustProxy });
  if (!cfg.adminToken) log('warn', 'ADMIN_TOKEN تنظیم نشده؛ مسیر /status غیرفعال است');
  if (!cfg.syncToken) log('warn', 'SYNC_TOKEN تنظیم نشده؛ مسیر /sync بدون احراز هویت است!');

  // ★ SRV-ROBUST: مانیتورینگ حافظه و مانیتورینگ خودکار
  const memMonitor = setInterval(() => {
    const mem = process.memoryUsage();
    if (mem.rss > 500 * 1024 * 1024) {
      // اگر حافظه بیش از ۵۰۰MB شد، هشدار بده
      log('warn', 'مصرف حافظه بالا', { rssMB: Math.round(mem.rss / 1048576), heapMB: Math.round(mem.heapUsed / 1048576) });
    }
  }, 60000);
  memMonitor.unref();

  // ★ SRV-ROBUST: جلوگیری از کرش روی خطاهای پیش‌بینی‌نشده
  process.on('uncaughtException', (e) => {
    log('error', 'uncaughtException — سرور ادامه می‌دهد', { err: String(e && e.message || e), stack: e && e.stack ? e.stack.slice(0, 500) : null });
  });

  let stopping = false;
  const stop = async (sig) => {
    if (stopping) return;
    stopping = true;
    log('info', 'در حال خاموش‌شدن امن', { sig });
    await app.close();
    process.exit(0);
  };
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
  process.on('unhandledRejection', (e) => log('error', 'unhandledRejection', { err: String(e && e.message || e) }));
}

if (require.main === module) {
  main().catch((e) => {
    console.error('شروع سرور ناموفق بود:', e);
    process.exit(1);
  });
}

module.exports = {
  mergeDocs, createApp, loadConfig, validateDoc, isPrivateIp, DEFAULT_ALLOWED_HOSTS };
