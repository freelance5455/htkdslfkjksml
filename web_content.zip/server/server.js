const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = process.env.PORT || 8080;
const HOST = process.env.HOST || "0.0.0.0";
const ROOT = path.join(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const DATA = path.join(ROOT, "data");
const USERS = path.join(DATA, "users.json");
const MESSAGES = path.join(DATA, "messages.json");
const UPLOADS = path.join(DATA, "uploads");

fs.mkdirSync(DATA, {recursive:true});
fs.mkdirSync(UPLOADS, {recursive:true});
for (const f of [USERS, MESSAGES]) if (!fs.existsSync(f)) fs.writeFileSync(f, "{}", "utf8");

function readJson(file, fallback={}) { try { return JSON.parse(fs.readFileSync(file,"utf8")); } catch { return fallback; } }
function writeJson(file, obj) { fs.writeFileSync(file, JSON.stringify(obj,null,2), "utf8"); }
function id() { return crypto.randomBytes(16).toString("hex"); }
function hash(p) { return crypto.createHash("sha256").update(p).digest("hex"); }
function json(res, code, body) {
  res.writeHead(code, {"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,OPTIONS"});
  res.end(JSON.stringify(body));
}
function body(req) {
  return new Promise((resolve,reject)=>{
    let b=""; req.on("data",c=>{b+=c; if(b.length>2e6) req.destroy();});
    req.on("end",()=>{try{resolve(b?JSON.parse(b):{});}catch(e){reject(e);}});
    req.on("error",reject);
  });
}
function safeName(name){ return String(name||"file").replace(/[^a-zA-Z0-9._-]/g,"_").slice(0,100); }

const sessions = new Map();
const sockets = new Map(); // userId -> Set(ws)

function broadcastUser(userId, payload) {
  const set=sockets.get(userId); if(!set) return;
  const data=JSON.stringify(payload);
  for(const ws of set) if(ws.readyState===1) ws.send(data);
}

const server = http.createServer(async (req,res)=>{
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":"*"});return res.end();}
  const u = new URL(req.url, `http://${req.headers.host}`);
  if(u.pathname.startsWith("/api/")) {
    try {
      if(req.method==="POST" && u.pathname==="/api/register"){
        const x=await body(req); const users=readJson(USERS);
        const phone=String(x.phone||"").trim(), name=String(x.name||"").trim(), pass=String(x.password||"");
        if(!phone||!name||pass.length<4) return json(res,400,{error:"Nom, numéro et mot de passe (4 caractères minimum) requis."});
        if(Object.values(users).some(v=>v.phone===phone)) return json(res,409,{error:"Ce numéro existe déjà."});
        const user={id:id(),phone,name,passwordHash:hash(pass),createdAt:Date.now()};
        users[user.id]=user; writeJson(USERS,users);
        const token=id(); sessions.set(token,user.id);
        return json(res,201,{token,user:{id:user.id,name:user.name,phone:user.phone}});
      }
      if(req.method==="POST" && u.pathname==="/api/login"){
        const x=await body(req); const users=readJson(USERS);
        const user=Object.values(users).find(v=>v.phone===String(x.phone||"").trim() && v.passwordHash===hash(String(x.password||"")));
        if(!user) return json(res,401,{error:"Numéro ou mot de passe incorrect."});
        const token=id(); sessions.set(token,user.id);
        return json(res,200,{token,user:{id:user.id,name:user.name,phone:user.phone}});
      }
      if(req.method==="GET" && u.pathname==="/api/health") return json(res,200,{ok:true,time:new Date().toISOString()});
      if(req.method==="GET" && u.pathname==="/api/users"){
        const users=readJson(USERS);
        return json(res,200,{users:Object.values(users).map(v=>({id:v.id,name:v.name,phone:v.phone}))});
      }
      if(req.method==="GET" && u.pathname==="/api/messages"){
        const a=u.searchParams.get("a"), b=u.searchParams.get("b");
        const all=readJson(MESSAGES);
        const out=Object.values(all).filter(m=>(m.from===a&&m.to===b)||(m.from===b&&m.to===a)).sort((x,y)=>x.createdAt-y.createdAt);
        return json(res,200,{messages:out});
      }
      if(req.method==="POST" && u.pathname==="/api/upload"){
        const x=await body(req); // data URL upload, suitable for prototype/small files
        const token=req.headers.authorization?.replace("Bearer ",""); const uid=sessions.get(token);
        if(!uid) return json(res,401,{error:"Non connecté."});
        const data=String(x.data||""); const match=data.match(/^data:([^;]+);base64,(.+)$/);
        if(!match) return json(res,400,{error:"Fichier invalide."});
        const mime=match[1], buf=Buffer.from(match[2],"base64");
        if(buf.length>8*1024*1024) return json(res,413,{error:"Fichier trop volumineux (8 Mo max)."});
        const filename=id()+"-"+safeName(x.name); fs.writeFileSync(path.join(UPLOADS,filename),buf);
        return json(res,201,{url:`/uploads/${filename}`,name:x.name||filename,mime,size:buf.length});
      }
    } catch(e) { console.error(e); return json(res,500,{error:"Erreur serveur."}); }
  }
  if(u.pathname.startsWith("/uploads/")){
    const file=path.join(UPLOADS,path.basename(u.pathname));
    if(!fs.existsSync(file)) return res.writeHead(404).end();
    return fs.createReadStream(file).pipe(res);
  }
  let filePath=u.pathname==="/" ? path.join(PUBLIC,"index.html") : path.join(PUBLIC,path.normalize(u.pathname).replace(/^(\.\.[\/\\])+/, ""));
  if(!filePath.startsWith(PUBLIC)) return res.writeHead(403).end();
  if(!fs.existsSync(filePath)) filePath=path.join(PUBLIC,"index.html");
  const ext=path.extname(filePath); const types={".html":"text/html; charset=utf-8",".js":"text/javascript",".css":"text/css",".json":"application/json",".webmanifest":"application/manifest+json"};
  res.writeHead(200,{"Content-Type":types[ext]||"application/octet-stream"});
  fs.createReadStream(filePath).pipe(res);
});

const wss = new WebSocket.Server({server});
wss.on("connection",(ws)=>{
  let userId=null;
  ws.on("message",(raw)=>{
    let m; try{m=JSON.parse(raw.toString())}catch{return;}
    if(m.type==="auth"){ userId=m.userId; if(!sockets.has(userId)) sockets.set(userId,new Set()); sockets.get(userId).add(ws); ws.send(JSON.stringify({type:"ready"})); return; }
    if(!userId) return;
    if(m.type==="message"){
      const all=readJson(MESSAGES); const msg={id:id(),from:userId,to:m.to,text:String(m.text||""),attachment:m.attachment||null,createdAt:Date.now()};
      all[msg.id]=msg; writeJson(MESSAGES,all);
      broadcastUser(msg.to,{type:"message",message:msg}); broadcastUser(msg.from,{type:"message:ack",message:msg});
    }
    if(["call-offer","call-answer","ice","call-end"].includes(m.type)){
      broadcastUser(m.to,{...m,type:m.type,from:userId});
    }
    if(m.type==="typing") broadcastUser(m.to,{type:"typing",from:userId,typing:!!m.typing});
  });
  ws.on("close",()=>{ if(userId && sockets.has(userId)){sockets.get(userId).delete(ws); if(!sockets.get(userId).size)sockets.delete(userId);} });
});

server.listen(PORT,HOST,()=>console.log(`DAGACHAT prêt sur http://localhost:${PORT}`));
