// Farm Simulator — онлайн бөлме сервері (қосымша пакеттер қажет емес, тек Node.js 18+)
// Іске қосу:  node server.js      (порт: PORT айнымалысы, әдепкі 8080)
const http = require('http');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const MAX_ROOM = 8;          // бір бөлмедегі ең көп ойыншы
const MAX_MSG = 2048;        // бір хабардың ең үлкен өлшемі (байт)
const MAX_RATE = 40;         // бір ойыншыдан секундына ең көп хабар
const rooms = new Map();     // код -> Set(клиент)
let nextId = 1;

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'access-control-allow-origin': '*' });
  res.end('Farm Simulator server OK\nбөлмелер: ' + rooms.size + '\n');
});

server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  if (String(req.headers.upgrade || '').toLowerCase() !== 'websocket' || !key) { sock.destroy(); return; }
  const acc = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  const c = { sock, id: String(nextId++), room: null, buf: Buffer.alloc(0), d: {}, alive: Date.now(), n: 0, t0: Date.now() };
  sock.setNoDelay(true);
  sock.on('data', b => { c.buf = Buffer.concat([c.buf, b]); if (c.buf.length > 16384) return kill(c); parse(c); });
  sock.on('close', () => drop(c));
  sock.on('error', () => drop(c));
  send(c, { t: 'welcome', id: c.id });
});

function frame(op, payload) {
  const len = payload.length;
  let h;
  if (len < 126) h = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([h, payload]);
}
function send(c, obj) { if (c.sock.destroyed) return; try { c.sock.write(frame(1, Buffer.from(JSON.stringify(obj)))); } catch (e) {} }
function kill(c) { try { c.sock.write(frame(8, Buffer.alloc(0))); } catch (e) {} try { c.sock.destroy(); } catch (e) {} drop(c); }

function parse(c) {
  for (;;) {
    const b = c.buf;
    if (b.length < 2) return;
    const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80;
    let len = b[1] & 0x7f, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; const big = b.readBigUInt64BE(2); if (big > 65536n) return kill(c); len = Number(big); off = 10; }
    if (!masked) return kill(c);                 // клиенттен келетін кадрлар әрдайым маскіленген
    if (len > MAX_MSG) return kill(c);
    if (b.length < off + 4 + len) return;
    const mask = b.subarray(off, off + 4), data = Buffer.from(b.subarray(off + 4, off + 4 + len));
    for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
    c.buf = b.subarray(off + 4 + len);
    c.alive = Date.now();
    if (!fin) return kill(c);                    // бөлшектелген хабарларды қолдамаймыз
    if (op === 8) return kill(c);
    if (op === 9) { try { c.sock.write(frame(10, data)); } catch (e) {} continue; }
    if (op !== 1) continue;
    const now = Date.now();
    if (now - c.t0 > 1000) { c.t0 = now; c.n = 0; }
    if (++c.n > MAX_RATE) continue;              // тым жиі жіберсе, артығын елемейміз
    let m; try { m = JSON.parse(data.toString('utf8')); } catch (e) { continue; }
    handle(c, m);
  }
}

function handle(c, m) {
  if (!m || typeof m !== 'object') return;
  if (m.t === 'join') {
    const code = String(m.room || '').toLowerCase();
    if (!/^[a-z0-9]{3,8}$/.test(code)) return;
    leave(c);
    let r = rooms.get(code);
    if (!r) { r = new Set(); rooms.set(code, r); }
    if (r.size >= MAX_ROOM) { send(c, { t: 'full' }); return; }
    r.add(c); c.room = code;
    send(c, { t: 'snap', list: [...r].filter(x => x !== c).map(x => ({ id: x.id, d: x.d })) });
  } else if (m.t === 'p') {
    if (!c.room || !m.d || typeof m.d !== 'object' || Array.isArray(m.d)) return;
    const s = JSON.stringify(m.d);
    if (s.length > 1500) return;
    c.d = m.d;
    const r = rooms.get(c.room);
    if (r) for (const o of r) if (o !== c) send(o, { t: 'p', id: c.id, d: c.d });
  } else if (m.t === 'leave') leave(c);
}

function leave(c) {
  if (!c.room) return;
  const r = rooms.get(c.room);
  if (r) {
    r.delete(c);
    for (const o of r) send(o, { t: 'left', id: c.id });
    if (!r.size) rooms.delete(c.room);
  }
  c.room = null; c.d = {};
}
function drop(c) { leave(c); }

setInterval(() => {                               // ұйқтап қалған байланыстарды тазалау
  const now = Date.now();
  for (const r of rooms.values()) for (const c of r) {
    if (now - c.alive > 70000) kill(c);
    else try { c.sock.write(frame(9, Buffer.alloc(0))); } catch (e) {}
  }
}, 25000);

server.listen(PORT, () => console.log('Farm server іске қосылды, порт ' + PORT));
