/**
 * R2-compatible object bucket backed by the application database.
 *
 * Vercel has no R2 binding, so archived originals live in a `resource_files`
 * table (base64). The surface matches the small subset of R2 used by
 * `worker/routes/resources.ts`: put / list / get / delete.
 */

export interface BucketObject {
  key: string;
  httpMetadata?: { contentType?: string };
}

export interface FileBucket {
  put(key: string, value: ArrayBuffer, options?: { httpMetadata?: { contentType?: string } }): Promise<void>;
  list(options: { prefix: string; limit?: number }): Promise<{ objects: BucketObject[] }>;
  get(key: string): Promise<{ body: Uint8Array; httpMetadata?: { contentType?: string } } | null>;
  delete(key: string): Promise<void>;
}

interface PreparedStatement {
  bind(...values: unknown[]): PreparedStatement;
  run(): Promise<unknown>;
  all<T>(): Promise<{ results: T[] }>;
  first<T>(): Promise<T | null>;
}

export function createFileBucket(db: { prepare(sql: string): PreparedStatement }): FileBucket {
  return {
    async put(key, value, options) {
      const bytes = new Uint8Array(value);
      await db
        .prepare(
          `INSERT OR REPLACE INTO resource_files (key, content_type, size, data, created_at)
           VALUES (?, ?, ?, ?, ?)`,
        )
        .bind(key, options?.httpMetadata?.contentType ?? 'application/octet-stream', bytes.byteLength, Buffer.from(bytes).toString('base64'), new Date().toISOString())
        .run();
    },
    async list({ prefix, limit }) {
      const { results } = await db
        .prepare('SELECT key, content_type FROM resource_files WHERE key LIKE ? ORDER BY key LIMIT ?')
        .bind(`${prefix}%`, Math.min(Math.max(Number(limit) || 1000, 1), 1000))
        .all<{ key: string; content_type: string | null }>();
      return {
        objects: results.map((row) => ({
          key: row.key,
          httpMetadata: { contentType: row.content_type ?? 'application/octet-stream' },
        })),
      };
    },
    async get(key) {
      const row = await db
        .prepare('SELECT content_type, data FROM resource_files WHERE key = ?')
        .bind(key)
        .first<{ content_type: string | null; data: string }>();
      if (!row) return null;
      return {
        body: new Uint8Array(Buffer.from(row.data, 'base64')),
        httpMetadata: { contentType: row.content_type ?? 'application/octet-stream' },
      };
    },
    async delete(key) {
      await db.prepare('DELETE FROM resource_files WHERE key = ?').bind(key).run();
    },
  };
}
