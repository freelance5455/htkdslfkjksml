import WebSocket from 'ws';
import crypto from 'crypto';
import { execFileSync } from 'child_process';
import path from 'path';

const TRUSTED_CLIENT_TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const CHROMIUM_FULL_VERSION = '143.0.3650.75';
const SEC_MS_GEC_VERSION = `2-${CHROMIUM_FULL_VERSION}`;
const WSS_URL = 'wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1';

let cachedToken: string | null = null;
let tokenExpiresAt = 0;

/**
 * Get or refresh the short-lived Sec-MS-GEC v2 token (valid for ~5 mins, refresh after 4 mins)
 */
export function getSecMsGecToken(): string {
  const now = Date.now();
  if (cachedToken && now < tokenExpiresAt) {
    return cachedToken;
  }

  try {
    const scriptPath = path.join(process.cwd(), 'scripts', 'edge_drm.py');
    const token = execFileSync('python3', [scriptPath], {
      encoding: 'utf-8',
      timeout: 3000,
    }).trim();

    if (token && token.includes('-')) {
      cachedToken = token;
      tokenExpiresAt = now + 4 * 60 * 1000; // cache for 4 minutes
      return token;
    }
  } catch (err: any) {
    console.warn('Failed to generate v2 token via edge_drm.py:', err.message);
  }

  // Fallback to legacy v1 calculation if Python invocation fails
  const ticks = Math.floor(now / 1000) + 11644473600;
  const rounded = ticks - (ticks % 300);
  const windowsTicks = rounded * 10000000;
  return crypto
    .createHash('sha256')
    .update(`${windowsTicks}${TRUSTED_CLIENT_TOKEN}`)
    .digest('hex')
    .toUpperCase();
}

/**
 * Synthesize speech using Microsoft Edge Neural TTS with v2 DRM authentication
 */
export async function synthesizeViaEdgeWs(
  ssml: string,
  outputFormat: string = 'audio-24khz-96kbitrate-mono-mp3'
): Promise<Buffer> {
  const token = getSecMsGecToken();
  const reqId = crypto.randomUUID().replace(/-/g, '');
  const url = `${WSS_URL}?TrustedClientToken=${TRUSTED_CLIENT_TOKEN}&Sec-MS-GEC=${token}&Sec-MS-GEC-Version=${SEC_MS_GEC_VERSION}&ConnectionId=${reqId}`;

  const muid = crypto.randomBytes(16).toString('hex').toUpperCase();

  return new Promise((resolve, reject) => {
    const audioChunks: Buffer[] = [];
    let isFinished = false;

    const ws = new WebSocket(url, {
      headers: {
        Pragma: 'no-cache',
        'Cache-Control': 'no-cache',
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
        Origin: 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Accept-Language': 'en-US,en;q=0.9',
        Cookie: `muid=${muid};`,
      },
      handshakeTimeout: 7000,
    });

    const timeoutTimer = setTimeout(() => {
      if (!isFinished) {
        isFinished = true;
        try {
          ws.close();
        } catch {}
        if (audioChunks.length > 0) {
          resolve(Buffer.concat(audioChunks));
        } else {
          reject(new Error('Edge Neural TTS WebSocket timeout'));
        }
      }
    }, 12000);

    ws.on('open', () => {
      const timestamp = new Date().toUTCString();
      const configMsg =
        `X-Timestamp:${timestamp}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n` +
        JSON.stringify({
          context: {
            synthesis: {
              audio: {
                metadataoptions: {
                  sentenceBoundaryEnabled: false,
                  wordBoundaryEnabled: false,
                },
                outputFormat,
              },
            },
          },
        });
      ws.send(configMsg);

      const speechMsg = `X-RequestId:${reqId}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${timestamp}\r\nPath:ssml\r\n\r\n${ssml}`;
      ws.send(speechMsg);
    });

    ws.on('message', (data: WebSocket.RawData) => {
      const buf = Buffer.isBuffer(data) ? data : Buffer.from(data as any);
      const needle = Buffer.from('Path:audio\r\n');
      const idx = buf.indexOf(needle);
      if (idx !== -1) {
        audioChunks.push(buf.subarray(idx + needle.length));
      }
      if (buf.toString().includes('Path:turn.end')) {
        isFinished = true;
        clearTimeout(timeoutTimer);
        try {
          ws.close();
        } catch {}
        resolve(Buffer.concat(audioChunks));
      }
    });

    ws.on('error', (err) => {
      if (!isFinished) {
        isFinished = true;
        clearTimeout(timeoutTimer);
        reject(err);
      }
    });

    ws.on('close', () => {
      if (!isFinished) {
        isFinished = true;
        clearTimeout(timeoutTimer);
        if (audioChunks.length > 0) {
          resolve(Buffer.concat(audioChunks));
        } else {
          reject(new Error('Connection closed before audio received'));
        }
      }
    });
  });
}
