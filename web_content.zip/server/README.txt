MX Blade server - يشتغل على استضافة (مو داخل التطبيق)
1) ارفع server.js و package.json على مستودع GitHub جديد.
2) render.com -> New -> Web Service -> اختر المستودع -> Start Command: node server.js -> Free.
3) انسخ الرابط (https://xxxx.onrender.com) وابعثه حتى يتحط داخل اللعبة (DEFSRV).
لحفظ الحسابات دايماً: حساب مجاني على upstash.com وضيف بـ Render:
UPSTASH_REDIS_REST_URL و UPSTASH_REDIS_REST_TOKEN
