export interface Workflow {
  id: string;
  name: string;
  steps: string[];
  enabled: boolean;
}

export function createWorkflow(name: string, steps: string[]): Workflow {
  return { id: crypto.randomUUID(), name, steps, enabled: false };
}
