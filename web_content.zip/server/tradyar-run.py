#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
راه‌اندازی یک‌خطی سرور ترید یار (بدون هیچ تنظیم دیگری)

    python3 tradyar-run.py                                   ← فقط سرور
    python3 tradyar-run.py --public-url https://api.example.com --port 8787

• همه‌چیز (دیتا، کلیدها، رمزنگاری توکن، پوشهٔ data) خودکار ساخته می‌شود.
• اگر سرور بسته شود، خودکار دوباره بالا می‌آید.
• فقط Node.js نسخهٔ ۲۰ به بالا لازم است (nodejs.org).
"""
import argparse, os, shutil, socket, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def main():
    ap = argparse.ArgumentParser(description="ترید یار — اجرای سرور و ربات‌ها")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--public-url", default="", help="آدرس عمومی سرور (برای لینک پرداخت)")
    ap.add_argument("--data", default=str(HERE / "data"))
    a = ap.parse_args()

    node = shutil.which("node") or shutil.which("nodejs")
    if not node:
        sys.exit("Node.js پیدا نشد. از https://nodejs.org نسخهٔ 20 یا بالاتر را نصب کنید و دوباره اجرا کنید.")
    ver = subprocess.run([node, "-v"], capture_output=True, text=True).stdout.strip().lstrip("v")
    try:
        if int(ver.split(".")[0]) < 20:
            sys.exit(f"نسخهٔ Node شما {ver} است؛ نسخهٔ 20 یا بالاتر لازم است.")
    except ValueError:
        pass

    env = dict(os.environ)
    env.update({"PORT": str(a.port), "HOST": "0.0.0.0", "DATA_DIR": a.data})
    if env.get("NODE_ENV") is None:
        env["NODE_ENV"] = "production"
    if a.public_url:
        env["PUBLIC_URL"] = a.public_url
    Path(a.data).mkdir(parents=True, exist_ok=True)

    ip = lan_ip()
    print("=" * 60)
    print("ترید یار روشن شد")
    print(f"  روی همین دستگاه : http://127.0.0.1:{a.port}")
    print(f"  داخل شبکه/وای‌فای: http://{ip}:{a.port}")
    if a.public_url:
        print(f"  آدرس عمومی      : {a.public_url}")
    print("  (برای دسترسی از بیرون، پورت را باز کنید یا دامنه/تونل بگذارید؛ برای APK بهتر است https باشد.)")
    print("  توقف: Ctrl+C")
    print("=" * 60, flush=True)

    fails = 0
    while True:
        t0 = time.time()
        try:
            p = subprocess.Popen([node, "server.js"], cwd=str(HERE), env=env)
            p.wait()
        except KeyboardInterrupt:
            try:
                p.terminate()
            except Exception:
                pass
            print("\nمتوقف شد.")
            return
        fails = fails + 1 if time.time() - t0 < 20 else 0
        wait = min(30, 2 * max(1, fails))
        print(f"سرور بسته شد؛ {wait} ثانیه دیگر دوباره اجرا می‌شود…", flush=True)
        time.sleep(wait)


if __name__ == "__main__":
    main()
