import type {
  AIModelAdapterInfo,
  AssistantDomain,
  AttachmentContext,
  DetectedLanguage,
  ExplanationDepth,
  LanguagePreference,
  UserMemoryItem,
} from '../../src/lib/jarvisTypes';

export interface ConversationTurn {
  role: 'user' | 'assistant';
  content: string;
}

export interface StreamChatParams {
  message: string;
  history: ConversationTurn[];
  memories: UserMemoryItem[];
  attachment?: AttachmentContext | null;
  domain: AssistantDomain;
  depth: ExplanationDepth;
  languagePreference: LanguagePreference;
  detectedLanguage: DetectedLanguage;
  inputMode?: 'text' | 'voice';
  listeningActive?: boolean;
  explicitMemoryRequested?: boolean;
  allowExplicitMemorySave?: boolean;
}

export interface StreamChatResult {
  fullText: string;
  followUps: string[];
  detectedLanguage: DetectedLanguage;
  modelId?: string;
}

export interface AIProviderAdapter {
  info: AIModelAdapterInfo;
  streamChat(
    params: StreamChatParams,
    onRawChunk: (accumulatedText: string) => void,
    signal?: AbortSignal,
  ): Promise<StreamChatResult>;
}
