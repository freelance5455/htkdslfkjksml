import type { AIModelAdapterInfo } from '../../src/lib/jarvisTypes';
import {
  geminiFlashLiteAdapter,
  geminiHydrogenAdapter,
} from './providers/geminiProvider';
import type { AIProviderAdapter } from './types';

/**
 * Expandable AI Provider Registry.
 * New AI models or external providers (OpenAI-compatible, Anthropic, local Ollama, etc.)
 * can be registered here via `aiRegistry.register(adapter)` without modifying UI or routes.
 */
class AIRegistry {
  private adapters = new Map<string, AIProviderAdapter>();
  private externalSlots: AIModelAdapterInfo[] = [];

  register(adapter: AIProviderAdapter): void {
    this.adapters.set(adapter.info.id, adapter);
  }

  registerConfigurableSlot(info: AIModelAdapterInfo): void {
    this.externalSlots.push(info);
  }

  get(id: string): AIProviderAdapter | undefined {
    return this.adapters.get(id);
  }

  getDefault(): AIProviderAdapter {
    return this.adapters.get('gemini-3.1-flash-lite') ?? Array.from(this.adapters.values())[0];
  }

  listAllInfo(): AIModelAdapterInfo[] {
    return [
      ...Array.from(this.adapters.values()).map((a) => a.info),
      ...this.externalSlots,
    ];
  }
}

export const aiRegistry = new AIRegistry();

aiRegistry.register(geminiFlashLiteAdapter);
aiRegistry.register(geminiHydrogenAdapter);

const externalBaseUrl = process.env.EXTERNAL_LLM_BASE_URL;
const externalModelName = process.env.EXTERNAL_LLM_MODEL || 'custom-llm-adapter';

if (externalBaseUrl) {
  aiRegistry.register({
    info: {
      id: externalModelName,
      name: `External Adapter (${externalModelName})`,
      provider: 'OpenAI-Compatible Endpoint',
      description: `Connected via server-side EXTERNAL_LLM_BASE_URL adapter.`,
      status: 'active',
      capabilities: ['Custom Model', 'Expandable Slot'],
      latencyTier: 'fast',
      supportsStreaming: false,
    },
    async streamChat(params, onRawChunk) {
      const response = await fetch(`${externalBaseUrl.replace(/\/$/, '')}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(process.env.EXTERNAL_LLM_KEY
            ? { Authorization: `Bearer ${process.env.EXTERNAL_LLM_KEY}` }
            : {}),
        },
        body: JSON.stringify({
          model: externalModelName,
          stream: false,
          messages: [
            ...params.history.slice(-12),
            { role: 'user', content: params.message },
          ],
        }),
      });
      if (!response.ok) {
        throw new Error(`External adapter returned ${response.status}`);
      }
      const data = await response.json();
      const text = data.choices?.[0]?.message?.content ?? '';
      onRawChunk(text);
      return {
        fullText: text,
        followUps: [],
        detectedLanguage: params.detectedLanguage,
      };
    },
  });
} else {
  aiRegistry.registerConfigurableSlot({
    id: 'external-openai-compatible',
    name: 'OpenAI-Compatible / Local Adapter',
    provider: 'Expandable Adapter Interface',
    description:
      'Plug-in adapter slot for local models (Ollama/vLLM) or third-party REST LLM endpoints via server environment configuration.',
    status: 'configurable',
    capabilities: ['Plugin Interface', 'Server-Side Proxy'],
    latencyTier: 'fast',
    supportsStreaming: true,
  });
}
