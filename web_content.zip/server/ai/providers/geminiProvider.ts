import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { detectLanguage } from '../../../src/lib/language';
import { extractFollowUps } from '../../../src/lib/streamParser';
import { normalizeConversationHistory } from '../../../src/lib/voiceState';
import type { MemoryCategory, UserMemoryItem } from '../../../src/lib/jarvisTypes';
import { buildJarvisSystemInstruction } from '../systemPrompt';
import type { AIProviderAdapter, StreamChatParams, StreamChatResult } from '../types';

const REQUEST_TIMEOUT_MS = 35_000;
const FIRST_CHUNK_TIMEOUT_MS = 12_000;

export function createGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured. Please verify your secret in Settings > Secrets.',
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function createGeminiTextAdapter(config: {
  id: string;
  name: string;
  description: string;
  latencyTier: 'ultra-fast' | 'fast';
  capabilities: string[];
  thinkingLevel: ThinkingLevel;
}): AIProviderAdapter {
  return {
    info: {
      id: config.id,
      name: config.name,
      provider: 'Google Gemini',
      description: config.description,
      status: 'active',
      capabilities: config.capabilities,
      latencyTier: config.latencyTier,
      supportsStreaming: true,
    },
    async streamChat(
      params: StreamChatParams,
      onRawChunk: (accumulatedText: string) => void,
      signal?: AbortSignal,
    ): Promise<StreamChatResult> {
      const ai = createGeminiClient();
      const systemInstruction = buildJarvisSystemInstruction({
        domain: params.domain,
        depth: params.depth,
        languagePreference: params.languagePreference,
        detectedLanguage: params.detectedLanguage,
        memories: params.memories,
        inputMode: params.inputMode,
        listeningActive: params.listeningActive,
        message: params.message,
        history: params.history,
        explicitMemoryRequested: params.explicitMemoryRequested,
        allowExplicitMemorySave: params.allowExplicitMemorySave,
      });

      const userPrompt = params.attachment
        ? `[Attached File: ${params.attachment.name}]\n\`\`\`\n${params.attachment.content.slice(0, 18000)}\n\`\`\`\n\n${params.message}`
        : params.message;

      const normalizedHistory = normalizeConversationHistory(params.history, 20);
      const contents = normalizedHistory.map((turn) => ({
        role: turn.role,
        parts: [{ text: turn.text }],
      }));
      if (contents.length > 0 && contents[contents.length - 1].role === 'user') {
        contents[contents.length - 1] = {
          role: 'user',
          parts: [{ text: `${contents[contents.length - 1].parts[0].text}\n\n${userPrompt}` }],
        };
      } else {
        contents.push({
          role: 'user',
          parts: [{ text: userPrompt }],
        });
      }

      const executeStream = async (targetModelId: string, allowFastStallFallback: boolean) => {
        let timer: ReturnType<typeof setTimeout> | undefined;
        let firstChunkTimer: ReturnType<typeof setTimeout> | undefined;
        let onAbort: (() => void) | undefined;
        let receivedAnyChunk = false;

        const timeoutPromise = new Promise<never>((_, reject) => {
          timer = setTimeout(() => {
            reject(new Error('Request timed out while waiting for Gemini response.'));
          }, REQUEST_TIMEOUT_MS);

          if (allowFastStallFallback) {
            firstChunkTimer = setTimeout(() => {
              if (!receivedAnyChunk) {
                reject(new Error('Model stalled before emitting response (fallback eligible).'));
              }
            }, FIRST_CHUNK_TIMEOUT_MS);
          }

          onAbort = () => {
            if (timer) clearTimeout(timer);
            if (firstChunkTimer) clearTimeout(firstChunkTimer);
            reject(new Error('Generation stopped by user.'));
          };
          signal?.addEventListener('abort', onAbort, { once: true });
        });

        const run = async () => {
          const stream = await ai.models.generateContentStream({
            model: targetModelId,
            contents,
            config: {
              systemInstruction,
              thinkingConfig: {
                thinkingLevel:
                  targetModelId === 'gemini-3.1-flash-lite'
                    ? ThinkingLevel.MINIMAL
                    : config.thinkingLevel,
              },
            },
          });

          let accumulated = '';
          for await (const chunk of stream) {
            if (signal?.aborted) {
              throw new Error('Generation stopped by user.');
            }
            const piece = chunk.text ?? '';
            if (piece) {
              if (!receivedAnyChunk) {
                receivedAnyChunk = true;
                if (firstChunkTimer) clearTimeout(firstChunkTimer);
              }
              accumulated += piece;
              onRawChunk(accumulated);
            }
          }
          return accumulated;
        };

        try {
          return await Promise.race([run(), timeoutPromise]);
        } finally {
          if (timer) clearTimeout(timer);
          if (firstChunkTimer) clearTimeout(firstChunkTimer);
          if (onAbort) signal?.removeEventListener('abort', onAbort);
        }
      };

      const isRetryableError = (err: unknown) => {
        const msg = err instanceof Error ? err.message : String(err);
        return (
          msg.includes('503') ||
          msg.includes('UNAVAILABLE') ||
          msg.includes('high demand') ||
          msg.includes('429') ||
          msg.includes('ECONNRESET') ||
          msg.includes('fallback eligible')
        );
      };

      let accumulated = '';
      let usedModelId = config.id;
      let lastError: unknown;
      const attemptModels =
        config.id === 'gemini-4-hydrogen'
          ? ['gemini-4-hydrogen', 'gemini-3.1-flash-lite']
          : [config.id, config.id];

      for (let attempt = 0; attempt < attemptModels.length; attempt++) {
        if (signal?.aborted) {
          throw new Error('Generation stopped by user.');
        }
        const targetModel = attemptModels[attempt];
        const hasFallbackRemaining = attempt < attemptModels.length - 1;
        try {
          accumulated = await executeStream(
            targetModel,
            hasFallbackRemaining && targetModel === 'gemini-4-hydrogen',
          );
          usedModelId = targetModel;
          lastError = undefined;
          break;
        } catch (err) {
          lastError = err;
          if (!isRetryableError(err) || attempt === attemptModels.length - 1) {
            throw err;
          }
          await new Promise((r) => setTimeout(r, 350 * (attempt + 1)));
        }
      }

      if (lastError) {
        throw lastError;
      }

      const parsed = extractFollowUps(accumulated);
      const replyTextLang = detectLanguage(parsed.text || params.message);
      const replyLang =
        params.languagePreference === 'auto'
          ? replyTextLang !== 'english'
            ? replyTextLang
            : params.detectedLanguage
          : params.languagePreference;

      return {
        fullText: parsed.text,
        followUps: parsed.followUps,
        detectedLanguage: replyLang,
        modelId: usedModelId,
      };
    },
  };
}

export const geminiHydrogenAdapter = createGeminiTextAdapter({
  id: 'gemini-4-hydrogen',
  name: 'Gemini 4 Hydrogen',
  description:
    'Primary fast JARVIS intelligence. Tuned with low-latency reasoning for natural humor, coding, project planning, and EN/HI/Hinglish fluency.',
  latencyTier: 'fast',
  capabilities: ['Reasoning & Coding', 'Project Planning', 'EN / HI / Hinglish', 'Memory Aware'],
  thinkingLevel: ThinkingLevel.LOW,
});

export const geminiFlashLiteAdapter = createGeminiTextAdapter({
  id: 'gemini-3.1-flash-lite',
  name: 'Gemini 3.1 Flash Lite',
  description:
    'Ultra-fast response engine built for near-instant everyday Q&A, quick advice, and rapid brainstorming.',
  latencyTier: 'ultra-fast',
  capabilities: ['Ultra-Low Latency', 'Quick Answers', 'EN / HI / Hinglish'],
  thinkingLevel: ThinkingLevel.MINIMAL,
});

export async function extractDurableMemoriesFromTurn(opts: {
  userMessage: string;
  existingMemories: UserMemoryItem[];
}): Promise<Array<{ category: MemoryCategory; content: string }>> {
  const msg = opts.userMessage.trim();
  if (msg.length < 8) return [];

  const ai = createGeminiClient();
  const existingPreview = opts.existingMemories
    .slice(0, 25)
    .map((m) => `[${m.category}] ${m.content}`)
    .join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: [
        'The user explicitly asked JARVIS to remember or save something.',
        'Extract ONLY the specific fact(s), preference(s), project(s), decision(s), or task(s) the user explicitly asked to save:',
        '- "preference": user likes, dislikes, style/language preferences, preferred tools',
        '- "project": ongoing work, apps, or goals the user asked to track',
        '- "decision": concrete choices the user asked to record',
        '- "task": reminders or tasks the user asked to remember',
        '- "fact": personal facts (name, role, stack, constraints) the user asked to remember',
        '',
        'Rules:',
        '- Return [] if no concrete storable fact/task/preference was stated (e.g. "remember me?").',
        '- Do NOT repeat items already in Existing Memories.',
        '- Strip the "remember that / yaad rakhna" wrapper and keep each item concise (under 140 chars).',
        '',
        `Existing Memories:\n${existingPreview || '(none)'}`,
        '',
        `User Message:\n${msg}`,
      ].join('\n'),
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              category: {
                type: Type.STRING,
                enum: ['preference', 'project', 'decision', 'task', 'fact'],
              },
              content: {
                type: Type.STRING,
              },
            },
            required: ['category', 'content'],
          },
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '[]').trim());
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (item): item is { category: MemoryCategory; content: string } =>
          item &&
          typeof item.content === 'string' &&
          item.content.trim().length > 4 &&
          ['preference', 'project', 'decision', 'task', 'fact'].includes(item.category),
      )
      .slice(0, 3);
  } catch {
    return [];
  }
}

export async function transcribeVoiceClip(opts: {
  audioBase64: string;
  mimeType: string;
  languagePreference?: string;
}): Promise<string> {
  const ai = createGeminiClient();
  const hint =
    opts.languagePreference === 'hindi'
      ? 'Transcribe the spoken Hindi audio cleanly in Devanagari script. Return only the spoken words.'
      : opts.languagePreference === 'hinglish'
        ? 'Transcribe the spoken audio cleanly (use Roman script for Hinglish/English). Return only the spoken words.'
        : 'Transcribe the spoken audio accurately in English, Hindi, or Hinglish as spoken. Return only the spoken words with no commentary.';

  const response = await ai.models.generateContent({
    model: 'gemini-3.5-transcribe',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: opts.mimeType || 'audio/webm',
            data: opts.audioBase64,
          },
        },
        { text: hint },
      ],
    },
  });

  return (response.text ?? '').trim();
}
