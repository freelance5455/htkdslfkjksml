export interface ModelTarget {
  provider: string;
  model: string;
  reason: string;
}

export function selectModel(task: string): ModelTarget {
  const t = task.toLowerCase();
  if (/code|debug|python|typescript|program/.test(t))
    return { provider: "provider-neutral", model: "coding-model", reason: "coding task" };
  if (/image|photo|vision/.test(t))
    return { provider: "provider-neutral", model: "vision-model", reason: "visual task" };
  if (/research|latest|current|search/.test(t))
    return { provider: "provider-neutral", model: "research-model", reason: "fresh information" };
  return { provider: "provider-neutral", model: "general-model", reason: "general task" };
}
