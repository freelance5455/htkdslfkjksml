/**
 * JARVIS Centralized Configuration Manager
 * Single source of truth for runtime, database, models, security, and server configurations.
 */

import type {
  AppConfig,
  ConfigValidationResult,
  SanitizedConfigDiagnostics,
} from './types.ts';
import {
  generateSanitizedDiagnostics,
  validateEnvironment,
} from './validator.ts';

export class ConfigurationManager {
  private static instance: ConfigurationManager;
  private currentConfig: AppConfig;
  private validationResult: ConfigValidationResult;

  private constructor() {
    const { config, validation } = validateEnvironment(process.env);
    this.currentConfig = config;
    this.validationResult = validation;

    if (!validation.isValid) {
      const errorSummary = validation.errors.join('; ');
      if (config.runtime.isProduction) {
        throw new Error(`[CONFIG FATAL] Production configuration validation failed: ${errorSummary}`);
      } else {
        console.warn(`[CONFIG WARNING] Configuration issues detected: ${errorSummary}`);
      }
    }

    if (validation.warnings.length > 0 && config.runtime.logLevel === 'debug') {
      for (const warning of validation.warnings) {
        console.warn(`[CONFIG NOTE] ${warning}`);
      }
    }
  }

  public static getInstance(): ConfigurationManager {
    if (!ConfigurationManager.instance) {
      ConfigurationManager.instance = new ConfigurationManager();
    }
    return ConfigurationManager.instance;
  }

  public getConfig(): AppConfig {
    return this.currentConfig;
  }

  public getValidation(): ConfigValidationResult {
    return this.validationResult;
  }

  public getSanitizedDiagnostics(): SanitizedConfigDiagnostics {
    return generateSanitizedDiagnostics(this.currentConfig, this.validationResult);
  }

  public reload(customEnv?: NodeJS.ProcessEnv): { config: AppConfig; validation: ConfigValidationResult } {
    const { config, validation } = validateEnvironment(customEnv || process.env);
    this.currentConfig = config;
    this.validationResult = validation;
    return { config, validation };
  }
}

export const configManager = ConfigurationManager.getInstance();
export const config: AppConfig = configManager.getConfig();

export function getSanitizedConfig(): SanitizedConfigDiagnostics {
  return configManager.getSanitizedDiagnostics();
}

export function validateConfig(): ConfigValidationResult {
  return configManager.getValidation();
}

export * from './types.ts';
export * from './validator.ts';
