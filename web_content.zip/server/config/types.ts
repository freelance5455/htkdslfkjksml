/**
 * JARVIS Centralized Configuration Types
 * Type-safe configuration contracts across runtime, server, database, models, and security.
 */

export type NodeEnvironment = 'development' | 'production' | 'test';
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export type DatabaseProviderType = 'sqlite' | 'postgres';

export interface ServerConfig {
  port: number;
  host: string;
  corsOrigin: string;
  bodyLimit: string;
  keepAliveTimeoutMs: number;
}

export interface DatabaseConfig {
  provider: DatabaseProviderType;
  sqlitePath: string;
  sqliteWal: boolean;
  databaseUrl?: string;
  poolMax: number;
  idleTimeoutMs: number;
  connectionTimeoutMs: number;
}

export interface ModelsConfig {
  defaultModelId: string;
  geminiApiKey?: string;
  hasGeminiApiKey: boolean;
  timeoutMs: number;
  maxTokens: number;
  temperature: number;
  fallbackChain: string[];
}

export interface SecurityConfig {
  rateLimitWindowMs: number;
  rateLimitMaxRequests: number;
  taskTimeoutMs: number;
  requireAuthForSensitive: boolean;
  maxAuditLogHistory: number;
}

export interface RuntimeConfig {
  nodeEnv: NodeEnvironment;
  isProduction: boolean;
  isDevelopment: boolean;
  isTest: boolean;
  logLevel: LogLevel;
  appUrl?: string;
}

export interface AppConfig {
  server: ServerConfig;
  database: DatabaseConfig;
  models: ModelsConfig;
  security: SecurityConfig;
  runtime: RuntimeConfig;
}

export interface SanitizedConfigDiagnostics {
  runtime: {
    nodeEnv: NodeEnvironment;
    isProduction: boolean;
    isDevelopment: boolean;
    logLevel: LogLevel;
    appUrlConfigured: boolean;
  };
  server: {
    port: number;
    host: string;
    corsOrigin: string;
    bodyLimit: string;
    keepAliveTimeoutMs: number;
  };
  database: {
    activeProvider: DatabaseProviderType;
    isPersistent: boolean;
    sqliteStoragePath: string;
    sqliteWalActive: boolean;
    postgresConfigured: boolean;
    sanitizedDatabaseTarget?: string;
    poolMax: number;
  };
  models: {
    defaultModelId: string;
    hasGeminiApiKey: boolean;
    timeoutMs: number;
    maxTokens: number;
    temperature: number;
    fallbackChain: string[];
  };
  security: {
    rateLimitWindowMs: number;
    rateLimitMaxRequests: number;
    taskTimeoutMs: number;
    requireAuthForSensitive: boolean;
    maxAuditLogHistory: number;
  };
  health: {
    isValid: boolean;
    validatedAt: string;
    warnings: string[];
  };
}

export interface ConfigValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}
