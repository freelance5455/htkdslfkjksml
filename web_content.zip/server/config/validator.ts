/**
 * JARVIS Configuration Validator & Sanitizer
 * Validates required/optional environment settings and strips sensitive credentials.
 */

import type {
  AppConfig,
  ConfigValidationResult,
  DatabaseProviderType,
  LogLevel,
  NodeEnvironment,
  SanitizedConfigDiagnostics,
} from './types.ts';

export function parseNumber(
  val: string | undefined,
  defaultVal: number,
  min = 1,
  max = Number.MAX_SAFE_INTEGER
): { value: number; warning?: string } {
  if (val === undefined || val.trim() === '') {
    return { value: defaultVal };
  }
  const parsed = Number(val.trim());
  if (Number.isNaN(parsed)) {
    return {
      value: defaultVal,
      warning: `Invalid numeric value "${val}". Falling back to default: ${defaultVal}`,
    };
  }
  if (parsed < min || parsed > max) {
    return {
      value: defaultVal,
      warning: `Numeric value ${parsed} outside allowed range [${min}, ${max}]. Falling back to default: ${defaultVal}`,
    };
  }
  return { value: parsed };
}

export function parseBoolean(val: string | undefined, defaultVal: boolean): boolean {
  if (val === undefined || val.trim() === '') return defaultVal;
  const lower = val.trim().toLowerCase();
  return lower === 'true' || lower === '1' || lower === 'yes';
}

export function parseString(val: string | undefined, defaultVal: string): string {
  if (val === undefined || val.trim() === '') return defaultVal;
  return val.trim();
}

export function parseStringList(val: string | undefined, defaultVal: string[]): string[] {
  if (val === undefined || val.trim() === '') return defaultVal;
  return val
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

export function sanitizeDatabaseUrl(rawUrl?: string): string | undefined {
  if (!rawUrl || rawUrl.trim() === '') return undefined;
  try {
    const parsed = new URL(rawUrl);
    if (parsed.password) {
      parsed.password = '***';
    }
    return parsed.toString();
  } catch {
    // If not a standard URL, mask characters
    if (rawUrl.length > 8) {
      return `${rawUrl.slice(0, 4)}...***`;
    }
    return '***';
  }
}

export function validateEnvironment(
  rawEnv: NodeJS.ProcessEnv
): { config: AppConfig; validation: ConfigValidationResult } {
  const errors: string[] = [];
  const warnings: string[] = [];

  // 1. Runtime Environment
  const rawNodeEnv = (rawEnv.NODE_ENV || 'development').trim().toLowerCase();
  let nodeEnv: NodeEnvironment = 'development';
  if (rawNodeEnv === 'production' || rawNodeEnv === 'prod') {
    nodeEnv = 'production';
  } else if (rawNodeEnv === 'test') {
    nodeEnv = 'test';
  }

  const rawLogLevel = (rawEnv.LOG_LEVEL || (nodeEnv === 'production' ? 'info' : 'debug'))
    .trim()
    .toLowerCase();
  const validLogLevels: LogLevel[] = ['debug', 'info', 'warn', 'error'];
  const logLevel: LogLevel = validLogLevels.includes(rawLogLevel as LogLevel)
    ? (rawLogLevel as LogLevel)
    : 'info';

  const appUrl = rawEnv.APP_URL?.trim();

  // 2. Server Configuration
  const portResult = parseNumber(rawEnv.PORT, 3000, 1, 65535);
  if (portResult.warning) warnings.push(portResult.warning);
  const serverPort = portResult.value;
  const serverHost = parseString(rawEnv.HOST, '0.0.0.0');
  const corsOrigin = parseString(rawEnv.CORS_ORIGIN, '*');
  const bodyLimit = parseString(rawEnv.BODY_LIMIT, '2mb');
  const keepAliveResult = parseNumber(rawEnv.KEEP_ALIVE_TIMEOUT_MS, 65000, 1000, 300000);
  if (keepAliveResult.warning) warnings.push(keepAliveResult.warning);

  // 3. Database Configuration
  const rawDbUrl = rawEnv.DATABASE_URL?.trim();
  let dbProvider: DatabaseProviderType = 'sqlite';
  let validatedDbUrl: string | undefined = undefined;

  if (rawDbUrl && rawDbUrl.length > 0) {
    const isPostgresProtocol =
      rawDbUrl.startsWith('postgresql://') || rawDbUrl.startsWith('postgres://');
    if (isPostgresProtocol) {
      dbProvider = 'postgres';
      validatedDbUrl = rawDbUrl;
    } else {
      const msg = `DATABASE_URL is defined but lacks postgresql:// or postgres:// scheme. Defaulting to SQLite.`;
      if (nodeEnv === 'production') {
        errors.push(msg);
      } else {
        warnings.push(msg);
      }
    }
  }

  const sqlitePath = parseString(rawEnv.SQLITE_DB_PATH, 'data/jarvis.db');
  const sqliteWal = parseBoolean(rawEnv.SQLITE_WAL, true);

  const poolMaxResult = parseNumber(rawEnv.DATABASE_POOL_MAX, 10, 1, 100);
  if (poolMaxResult.warning) warnings.push(poolMaxResult.warning);

  const idleTimeoutResult = parseNumber(rawEnv.DATABASE_IDLE_TIMEOUT_MS, 30000, 1000, 120000);
  if (idleTimeoutResult.warning) warnings.push(idleTimeoutResult.warning);

  const connTimeoutResult = parseNumber(rawEnv.DATABASE_CONNECTION_TIMEOUT_MS, 10000, 500, 60000);
  if (connTimeoutResult.warning) warnings.push(connTimeoutResult.warning);

  // 4. Models Configuration
  const rawApiKey = rawEnv.GEMINI_API_KEY?.trim();
  const hasGeminiApiKey = Boolean(
    rawApiKey &&
      rawApiKey !== 'MY_GEMINI_API_KEY' &&
      rawApiKey !== 'TODO' &&
      rawApiKey !== ''
  );

  const defaultModelId = parseString(rawEnv.DEFAULT_MODEL_ID, 'gemini-3.8-flash');
  const timeoutResult = parseNumber(rawEnv.MODEL_TIMEOUT_MS, 30000, 1000, 120000);
  if (timeoutResult.warning) warnings.push(timeoutResult.warning);

  const maxTokensResult = parseNumber(rawEnv.MODEL_MAX_TOKENS, 2048, 128, 32768);
  if (maxTokensResult.warning) warnings.push(maxTokensResult.warning);

  const rawTemp = rawEnv.MODEL_TEMPERATURE;
  let modelTemp = 0.2;
  if (rawTemp !== undefined && rawTemp.trim() !== '') {
    const parsedTemp = parseFloat(rawTemp);
    if (!Number.isNaN(parsedTemp) && parsedTemp >= 0 && parsedTemp <= 2) {
      modelTemp = parsedTemp;
    } else {
      warnings.push(`MODEL_TEMPERATURE "${rawTemp}" invalid, using default 0.2`);
    }
  }

  const fallbackChain = parseStringList(rawEnv.MODEL_FALLBACK_CHAIN, [
    'gemini-3.1-flash-lite',
    'gemini-3.1-pro-preview',
  ]);

  // 5. Security Configuration
  const rateLimitWindowResult = parseNumber(rawEnv.RATE_LIMIT_WINDOW_MS, 60000, 1000, 3600000);
  if (rateLimitWindowResult.warning) warnings.push(rateLimitWindowResult.warning);

  const rateLimitMaxResult = parseNumber(rawEnv.RATE_LIMIT_MAX_REQUESTS, 120, 5, 10000);
  if (rateLimitMaxResult.warning) warnings.push(rateLimitMaxResult.warning);

  const taskTimeoutResult = parseNumber(rawEnv.TASK_TIMEOUT_MS, 120000, 5000, 600000);
  if (taskTimeoutResult.warning) warnings.push(taskTimeoutResult.warning);

  const requireAuthForSensitive = parseBoolean(rawEnv.REQUIRE_AUTH_FOR_SENSITIVE, false);
  const maxAuditLogHistory = parseNumber(rawEnv.MAX_AUDIT_LOG_HISTORY, 1000, 10, 50000).value;

  const appConfig: AppConfig = {
    runtime: {
      nodeEnv,
      isProduction: nodeEnv === 'production',
      isDevelopment: nodeEnv === 'development',
      isTest: nodeEnv === 'test',
      logLevel,
      appUrl,
    },
    server: {
      port: serverPort,
      host: serverHost,
      corsOrigin,
      bodyLimit,
      keepAliveTimeoutMs: keepAliveResult.value,
    },
    database: {
      provider: dbProvider,
      sqlitePath,
      sqliteWal,
      databaseUrl: validatedDbUrl,
      poolMax: poolMaxResult.value,
      idleTimeoutMs: idleTimeoutResult.value,
      connectionTimeoutMs: connTimeoutResult.value,
    },
    models: {
      defaultModelId,
      geminiApiKey: hasGeminiApiKey ? rawApiKey : undefined,
      hasGeminiApiKey,
      timeoutMs: timeoutResult.value,
      maxTokens: maxTokensResult.value,
      temperature: modelTemp,
      fallbackChain,
    },
    security: {
      rateLimitWindowMs: rateLimitWindowResult.value,
      rateLimitMaxRequests: rateLimitMaxResult.value,
      taskTimeoutMs: taskTimeoutResult.value,
      requireAuthForSensitive,
      maxAuditLogHistory,
    },
  };

  return {
    config: appConfig,
    validation: {
      isValid: errors.length === 0,
      errors,
      warnings,
    },
  };
}

export function generateSanitizedDiagnostics(
  config: AppConfig,
  validation: ConfigValidationResult
): SanitizedConfigDiagnostics {
  return {
    runtime: {
      nodeEnv: config.runtime.nodeEnv,
      isProduction: config.runtime.isProduction,
      isDevelopment: config.runtime.isDevelopment,
      logLevel: config.runtime.logLevel,
      appUrlConfigured: Boolean(config.runtime.appUrl),
    },
    server: {
      port: config.server.port,
      host: config.server.host,
      corsOrigin: config.server.corsOrigin,
      bodyLimit: config.server.bodyLimit,
      keepAliveTimeoutMs: config.server.keepAliveTimeoutMs,
    },
    database: {
      activeProvider: config.database.provider,
      isPersistent: true,
      sqliteStoragePath: config.database.sqlitePath,
      sqliteWalActive: config.database.sqliteWal,
      postgresConfigured: Boolean(config.database.databaseUrl),
      sanitizedDatabaseTarget: sanitizeDatabaseUrl(config.database.databaseUrl),
      poolMax: config.database.poolMax,
    },
    models: {
      defaultModelId: config.models.defaultModelId,
      hasGeminiApiKey: config.models.hasGeminiApiKey,
      timeoutMs: config.models.timeoutMs,
      maxTokens: config.models.maxTokens,
      temperature: config.models.temperature,
      fallbackChain: config.models.fallbackChain,
    },
    security: {
      rateLimitWindowMs: config.security.rateLimitWindowMs,
      rateLimitMaxRequests: config.security.rateLimitMaxRequests,
      taskTimeoutMs: config.security.taskTimeoutMs,
      requireAuthForSensitive: config.security.requireAuthForSensitive,
      maxAuditLogHistory: config.security.maxAuditLogHistory,
    },
    health: {
      isValid: validation.isValid,
      validatedAt: new Date().toISOString(),
      warnings: validation.warnings,
    },
  };
}
