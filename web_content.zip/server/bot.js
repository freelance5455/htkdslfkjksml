'use strict';
/**
 * ربات معامله ۲۴ ساعته (سمت سرور)
 * ------------------------------------------------------------------
 * • کلیدهای API با AES-256-GCM رمزنگاری و روی دیسک ذخیره می‌شوند (کلید رمزنگاری: BOT_KEY یا فایل data/bot.key).
 * • هر ربات با یک botToken تصادفی کنترل می‌شود؛ فقط هش آن روی سرور می‌ماند.
 * • چرخه: اسکن همهٔ ارزها ← تحلیل (موتور analysis.js و اختیاری هوش مصنوعی) ← سایز/قفل‌های ایمنی ← سفارش واقعی.
 * • حد ضرر/سود اسپات (برای صرافی‌های بدون OCO بومی) توسط «نگهبان» سرور هر ۲۰ ثانیه چک می‌شود.
 */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { analyze } = require('./analysis');
const { floorToStep, ExchangeError } = require('./exchanges');

const STABLE = new Set(['USDT', 'USDC', 'USD', 'FDUSD', 'BUSD', 'TUSD', 'DAI']);
const SCOPES = { top50: 50, top100: 100, top200: 200, top500: 500, all: 100000 };
const TF_SEC = { '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400 };
const HTF = { '5m': '15m', '15m': '1h', '30m': '1h', '1h': '4h', '4h': '1d', '1d': '1d' };
const DAY = 86400000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };
const rid = (n = 16) => crypto.randomBytes(n).toString('hex');
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

function berr(status, code, message) { const e = new Error(message || code); e.status = status; e.code = code; return e; }

function defaultSettings() {
  return {
    everyMin: 15, scope: 'top100', tf: '1h', minVolUsd: 100000,
    sizing: { mode: 'fixed', usd: 10, pct: 5, riskPct: 1 },
    leverage: 3, maxOrderUsd: 20, maxDaily: 5, maxDailyUsd: 100, maxOpen: 3,
    minRR: 1.5, minScore: 70, useAI: false, aiMax: 3, allowShort: false,
  };
}

function sanitizeSettings(inp, caps, prev) {
  const d = Object.assign(defaultSettings(), prev || {});
  const s = inp && typeof inp === 'object' ? inp : {};
  const pick = (v, lo, hi, dflt) => { const n = num(v); return n >= lo && n <= hi ? n : dflt; };
  const out = {
    everyMin: Math.round(pick(s.everyMin, caps.minEveryMin, 1440, d.everyMin)),
    scope: SCOPES[s.scope] ? s.scope : d.scope,
    tf: TF_SEC[s.tf] ? s.tf : d.tf,
    minVolUsd: pick(s.minVolUsd, 0, 1e9, d.minVolUsd),
    sizing: {
      mode: ['fixed', 'pct', 'risk'].includes(s.sizing && s.sizing.mode) ? s.sizing.mode : d.sizing.mode,
      usd: pick(s.sizing && s.sizing.usd, 1, caps.maxOrderUsd, d.sizing.usd),
      pct: pick(s.sizing && s.sizing.pct, 0.1, 100, d.sizing.pct),
      riskPct: pick(s.sizing && s.sizing.riskPct, 0.1, 10, d.sizing.riskPct),
    },
    leverage: Math.round(pick(s.leverage, 1, 50, d.leverage)),
    maxOrderUsd: pick(s.maxOrderUsd, 1, caps.maxOrderUsd, Math.min(d.maxOrderUsd, caps.maxOrderUsd)),
    maxDaily: Math.round(pick(s.maxDaily, 1, 100, d.maxDaily)),
    maxDailyUsd: pick(s.maxDailyUsd, 1, caps.maxOrderUsd * 100, d.maxDailyUsd),
    maxOpen: Math.round(pick(s.maxOpen, 1, 50, d.maxOpen)),
    minRR: pick(s.minRR, 1, 10, d.minRR),
    minScore: Math.round(pick(s.minScore, 50, 100, d.minScore)),
    useAI: s.useAI === undefined ? d.useAI : s.useAI === true,
    aiMax: Math.round(pick(s.aiMax, 1, 10, d.aiMax)),
    allowShort: s.allowShort === undefined ? d.allowShort : s.allowShort === true,
  };
  return out;
}

/* محاسبهٔ حجم (هم‌ارز sizing سمت کلاینت) */
function sizeOrder(o) {
  const r = { qty: 0, notional: 0, rr: 0, margin: 0, riskUsd: 0, errors: [] };
  const buy = o.side === 'buy', entry = o.entry, sl = o.sl, tp = o.tp;
  if (!(entry > 0) || !(sl > 0) || !(tp > 0)) { r.errors.push('سطوح نامعتبر'); return r; }
  if (buy ? sl >= entry || tp <= entry : sl <= entry || tp >= entry) { r.errors.push('سطوح حد ضرر/سود نسبت به قیمت درست نیست'); return r; }
  const dist = Math.abs(entry - sl);
  let notional;
  if (o.mode === 'risk') notional = (o.balance * o.riskPct / 100) / dist * entry;
  else if (o.mode === 'pct') notional = o.balance * o.pct / 100;
  else notional = o.usd;
  notional = Math.min(notional, o.maxOrderUsd);
  const lev = o.futures ? Math.max(1, o.leverage || 1) : 1;
  const avail = o.balance * (o.futures ? 0.95 : 0.99) * lev;
  notional = Math.min(notional, avail);
  if (!(notional > 0)) { r.errors.push('موجودی کافی نیست'); return r; }
  r.notional = notional; r.qty = notional / entry; r.margin = notional / lev;
  r.riskUsd = r.qty * dist; r.rr = (r.qty * Math.abs(tp - entry)) / r.riskUsd;
  const m = o.market || {};
  if (m.minNotional && notional < m.minNotional) r.errors.push('مبلغ کمتر از حداقل صرافی (' + m.minNotional + ')');
  if (m.minQty && r.qty < m.minQty) r.errors.push('حجم کمتر از حداقل صرافی (' + m.minQty + ')');
  return r;
}

class BotManager {
  constructor(cfg, deps) {
    this.cfg = cfg;
    this.d = deps; // { CONNECTORS, ctx, getMarkets, getTickers, placeOrderFlow, fetch, now, log }
    this.now = deps.now || (() => Date.now());
    this.file = path.join(cfg.dataDir, 'bots.json');
    this.keyFile = path.join(cfg.dataDir, 'bot.key');
    this.bots = new Map();
    this.klCache = new Map();
    this.active = 0;
    this.maxParallel = cfg.botParallel || 3;
    this.caps = { maxOrderUsd: cfg.botMaxOrderUsd || 500, minEveryMin: cfg.botMinEveryMin || 5 };
    this.adminFile = path.join(cfg.dataDir, 'bot-admin.json');
    this.admin = { paused: false, maxBots: cfg.botMax || 200, disabledExchanges: [], requireSub: false, note: '' };
    this.key = this._loadKey();
    this._load();
    this._loadAdmin();
    this.timers = [];
  }

  /* ---------- ذخیره‌سازی و رمزنگاری ---------- */
  _loadKey() {
    if (this.cfg.botKey) return crypto.createHash('sha256').update(String(this.cfg.botKey)).digest();
    try { fs.mkdirSync(this.cfg.dataDir, { recursive: true }); } catch { /* ignore */ }
    try { return Buffer.from(fs.readFileSync(this.keyFile, 'utf8').trim(), 'hex'); } catch { /* new key */ }
    const k = crypto.randomBytes(32);
    fs.writeFileSync(this.keyFile, k.toString('hex'), { mode: 0o600 });
    return k;
  }
  enc(obj) {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', this.key, iv);
    const ct = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
    return [iv, c.getAuthTag(), ct].map((b) => b.toString('base64')).join('.');
  }
  dec(str) {
    const [iv, tag, ct] = String(str).split('.').map((x) => Buffer.from(x, 'base64'));
    const d = crypto.createDecipheriv('aes-256-gcm', this.key, iv);
    d.setAuthTag(tag);
    return JSON.parse(Buffer.concat([d.update(ct), d.final()]).toString('utf8'));
  }
  _load() {
    try {
      const j = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      for (const b of j.bots || []) this.bots.set(b.id, b);
    } catch { /* first run */ }
  }
  _save() {
    if (this._saveT) return;
    this._saveT = setTimeout(() => { this._saveT = null; this._saveNow(); }, 150);
    if (this._saveT.unref) this._saveT.unref();
  }
  _saveNow() {
    try {
      fs.mkdirSync(this.cfg.dataDir, { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ v: 1, bots: [...this.bots.values()] }), { mode: 0o600 });
      fs.renameSync(tmp, this.file);
    } catch (e) { this.d.log('error', 'ذخیرهٔ ربات‌ها ناموفق', { err: String(e.message) }); }
  }

  /* ---------- زمان‌بندی ---------- */
  start() {
    const t1 = setInterval(() => this.tick().catch(() => {}), 15000);
    const t2 = setInterval(() => this.guardTick().catch(() => {}), 20000);
    t1.unref(); t2.unref();
    this.timers.push(t1, t2);
    setTimeout(() => this.tick().catch(() => {}), 2000).unref();
  }
  stop() {
    this.timers.forEach(clearInterval); this.timers = [];
    if (this._saveT) { clearTimeout(this._saveT); this._saveT = null; }
    this._saveNow();
  }
  _loadAdmin() {
    try {
      const j = JSON.parse(fs.readFileSync(this.adminFile, 'utf8'));
      this._applyAdmin(j, true);
    } catch { /* پیش‌فرض */ }
  }
  _applyAdmin(j, silent) {
    const a = this.admin, c = this.caps;
    if (j.paused !== undefined) a.paused = j.paused === true;
    if (j.requireSub !== undefined) a.requireSub = j.requireSub === true;
    if (Array.isArray(j.disabledExchanges)) a.disabledExchanges = j.disabledExchanges.map((x) => String(x).toLowerCase()).filter((x) => this.d.CONNECTORS[x]);
    if (j.note !== undefined) a.note = String(j.note || '').slice(0, 200);
    const n = (v, lo, hi) => { v = Number(v); return Number.isFinite(v) && v >= lo && v <= hi ? v : null; };
    const mb = n(j.maxBots, 1, 5000); if (mb !== null) a.maxBots = Math.round(mb);
    const mo = n(j.maxOrderUsd, 1, 100000); if (mo !== null) c.maxOrderUsd = mo;
    const me = n(j.minEveryMin, 1, 1440); if (me !== null) c.minEveryMin = Math.round(me);
    const mp = n(j.maxParallel, 1, 20); if (mp !== null) this.maxParallel = Math.round(mp);
    if (!silent) {
      try { fs.mkdirSync(this.cfg.dataDir, { recursive: true }); fs.writeFileSync(this.adminFile + '.tmp', JSON.stringify(this.adminView()), { mode: 0o600 }); fs.renameSync(this.adminFile + '.tmp', this.adminFile); } catch (e) { this.d.log('error', 'ذخیرهٔ تنظیمات مدیر ربات ناموفق', { err: String(e.message) }); }
    }
    return this.adminView();
  }
  adminView() {
    return Object.assign({}, this.admin, { maxOrderUsd: this.caps.maxOrderUsd, minEveryMin: this.caps.minEveryMin, maxParallel: this.maxParallel });
  }
  async tick() {
    if (this.admin.paused) return;
    const now = this.now(), ps = [];
    for (const b of this.bots.values()) {
      if (!b.running || b.busy) continue;
      if (b.expiresAt && now > b.expiresAt) { b.running = false; b.status.phase = 'expired'; b.status.lastError = 'اشتراک تمام شده؛ ربات متوقف شد'; this._save(); continue; }
      if ((b.status.nextAt || 0) > now) continue;
      if (this.active >= this.maxParallel) break;
      ps.push(this._runBot(b));
    }
    if (ps.length) await Promise.allSettled(ps);
  }
  async _runBot(b) {
    b.busy = true; this.active++;
    try { await this.runCycle(b); }
    catch (e) { /* runCycle خطاها را خودش مدیریت می‌کند */ }
    finally { b.busy = false; this.active--; this._save(); }
  }

  /* ---------- API عمومی ---------- */
  _auth(id, token) {
    const b = this.bots.get(String(id));
    if (!b) throw berr(404, 'bot_not_found');
    const h = sha(token || '');
    if (!crypto.timingSafeEqual(Buffer.from(h), Buffer.from(b.tokenHash))) throw berr(401, 'bad_bot_token');
    return b;
  }
  _snapEquity(b, bal, mlist, tmap) {
    const px = new Map();
    for (const m of mlist) if (m.quote === 'USDT') { const t = tmap.get(m.symbol); if (t && t.last > 0 && !px.has(m.base)) px.set(m.base, t.last); }
    let eq = 0;
    for (const x of bal.balances) {
      const a = String(x.asset).toUpperCase(), q = (x.free || 0) + (x.locked || 0);
      if (STABLE.has(a)) eq += q; else if (px.has(a)) eq += q * px.get(a);
    }
    if (!(eq >= 0)) return;
    b.status.equityUsd = eq;
    if (!(b.startEquity > 0)) b.startEquity = eq;
    const now = this.now(); b.equity = b.equity || [];
    const last = b.equity[b.equity.length - 1];
    if (!last || now - last.t >= 30 * 60000) b.equity.push({ t: now, v: +eq.toFixed(4) });
    else last.v = +eq.toFixed(4);
    if (b.equity.length > 1500) b.equity = b.equity.slice(-1500);
  }
  _stats(b) {
    const now = this.now(), eq = b.equity || [];
    const entries = b.trades.filter((t) => t.kind === 'entry');
    const okEntries = entries.filter((t) => t.ok);
    const closed = b.guards.filter((g) => g.status === 'tp' || g.status === 'sl');
    const wins = closed.filter((g) => g.status === 'tp').length, losses = closed.length - wins;
    const cur = (b.status && b.status.equityUsd) || 0, start = b.startEquity || 0;
    const at = (ms) => { const lim = now - ms; let v = null; for (const p of eq) { if (p.t <= lim) v = p.v; else break; } return v == null && eq.length ? eq[0].v : v; };
    const d1 = at(DAY), d7 = at(7 * DAY), d30 = at(30 * DAY);
    const d = (base) => (base > 0 ? cur - base : 0);
    return {
      equityUsd: cur, startEquityUsd: start,
      pnlTotal: d(start), pnlTotalPct: start > 0 ? (cur - start) / start * 100 : 0,
      pnl24h: d(d1), pnl7d: d(d7), pnl30d: d(d30),
      pnl7dPct: d7 > 0 ? (cur - d7) / d7 * 100 : 0,
      trades: okEntries.length, failed: entries.length - okEntries.length,
      open: b.guards.filter((g) => g.status === 'open').length + 0,
      closed: closed.length, wins, losses, winRate: closed.length ? wins / closed.length * 100 : null,
      todayOpened: entries.filter((t) => t.ok && now - t.at < DAY).length,
    };
  }
  view(b) {
    const now = this.now();
    return {
      id: b.id, exchange: b.exchange, running: !!b.running, busy: !!b.busy, expiresAt: b.expiresAt || 0, createdAt: b.createdAt, label: b.label,
      settings: b.settings, status: b.status,
      stats: this._stats(b), equity: (b.equity || []).filter((p) => this.now() - p.t < 31 * DAY).filter((_, i, a) => a.length < 260 || i % Math.ceil(a.length / 260) === 0), trades: b.trades.slice(0, 40), guards: b.guards.filter((g) => g.status === 'open' || now - (g.closedAt || 0) < DAY),
    };
  }
  async save(body, sanitizeCreds) {
    const c = this.d.CONNECTORS[String(body.exchange || '').toLowerCase()];
    if (!c) throw berr(400, 'unknown_exchange');
    if (this.admin.disabledExchanges.includes(c.id)) throw berr(403, 'exchange_disabled', 'این صرافی توسط مدیر غیرفعال شده است');
    const creds = sanitizeCreds(body.creds);
    if (!creds.apiKey || !creds.apiSecret) throw berr(400, 'missing_creds');
    let bal;
    try { bal = await c.balance(this.d.ctx, creds); }
    catch (e) { if (e instanceof ExchangeError) throw Object.assign(berr(422, 'exchange_error', e.message), { exCode: e.exCode }); throw e; }
    const expiresAt = num(body.expiresAt) > this.now() ? num(body.expiresAt) : 0;
    let b, token;
    if (body.botId) {
      b = this._auth(body.botId, body.botToken);
      b.exchange = c.id; b.credsEnc = this.enc(creds);
      b.settings = sanitizeSettings(body.settings, this.caps, b.settings);
    } else {
      if (this.bots.size >= this.admin.maxBots) throw berr(503, 'bot_capacity');
      token = rid(24);
      b = {
        id: 'b_' + rid(8), tokenHash: sha(token), exchange: c.id, credsEnc: this.enc(creds), label: String(body.label || '').slice(0, 40), owner: String(body.owner || '').slice(0, 64),
        settings: sanitizeSettings(body.settings, this.caps), running: false, expiresAt: 0, createdAt: this.now(),
        status: { phase: 'idle', nextAt: 0, fails: 0 }, trades: [], guards: [],
      };
      this.bots.set(b.id, b);
    }
    if (expiresAt || body.expiresAt === 0) b.expiresAt = expiresAt;
    if (body.start === true) { b.running = true; b.status.phase = 'queued'; b.status.nextAt = 0; b.status.fails = 0; b.status.lastError = null; }
    this._save();
    const usdt = ((bal.balances || []).find((x) => STABLE.has(String(x.asset).toUpperCase())) || { free: 0 }).free;
    b.status.balanceUsd = usdt;
    return { bot: this.view(b), botToken: token };
  }
  update(id, token, body) {
    const b = this._auth(id, token);
    if (body.settings) b.settings = sanitizeSettings(body.settings, this.caps, b.settings);
    if (body.expiresAt !== undefined) b.expiresAt = num(body.expiresAt) > this.now() ? num(body.expiresAt) : 0;
    this._save();
    return this.view(b);
  }
  setRunning(id, token, on) {
    const b = this._auth(id, token);
    if (on && this.admin.paused) throw berr(423, 'trading_paused', this.admin.note || 'معاملهٔ خودکار موقتاً توسط مدیر متوقف شده است');
    if (on && b.blocked) throw berr(403, 'bot_blocked', 'این ربات توسط مدیر مسدود شده است');
    if (on && this.admin.disabledExchanges.includes(b.exchange)) throw berr(403, 'exchange_disabled', 'این صرافی توسط مدیر غیرفعال شده است');
    if (on && b.expiresAt && this.now() > b.expiresAt) throw berr(402, 'subscription_expired', 'اشتراک تمام شده است');
    b.running = !!on;
    b.status.phase = on ? 'queued' : 'stopped';
    if (on) { b.status.nextAt = 0; b.status.fails = 0; b.status.lastError = null; }
    this._save();
    return this.view(b);
  }
  runNow(id, token) {
    const b = this._auth(id, token);
    if (!b.running) throw berr(409, 'bot_stopped');
    b.status.nextAt = 0; this._save();
    if (!this.d.noImmediate) setTimeout(() => this.tick().catch(() => {}), 10);
    return this.view(b);
  }
  remove(id, token) {
    const b = this._auth(id, token);
    this.bots.delete(b.id); this._save();
    return { ok: true };
  }
  adminList() {
    return [...this.bots.values()].map((b) => {
      const st = this._stats(b);
      return { id: b.id, label: b.label, owner: b.owner || '', exchange: b.exchange, running: !!b.running, busy: !!b.busy, blocked: !!b.blocked, expiresAt: b.expiresAt || 0, createdAt: b.createdAt,
        phase: b.status.phase, lastCycleAt: b.status.lastCycleAt || 0, nextAt: b.status.nextAt || 0, lastError: b.status.lastError || '', fails: b.status.fails || 0,
        equityUsd: st.equityUsd, pnlTotal: st.pnlTotal, pnlTotalPct: st.pnlTotalPct, pnl24h: st.pnl24h, winRate: st.winRate, trades: st.trades, failed: st.failed, open: st.open,
        scope: b.settings.scope, tf: b.settings.tf, usd: b.settings.sizing && b.settings.sizing.usd, useAI: !!b.settings.useAI };
    });
  }
  adminSummary() {
    const l = this.adminList(), by = {};
    for (const x of l) { by[x.exchange] = by[x.exchange] || { n: 0, running: 0, equity: 0 }; by[x.exchange].n++; if (x.running) by[x.exchange].running++; by[x.exchange].equity += x.equityUsd || 0; }
    return {
      total: l.length, running: l.filter((x) => x.running).length, blocked: l.filter((x) => x.blocked).length, errors: l.filter((x) => x.lastError && x.running).length,
      equityUsd: l.reduce((s, x) => s + (x.equityUsd || 0), 0), pnlTotal: l.reduce((s, x) => s + (x.pnlTotal || 0), 0), trades: l.reduce((s, x) => s + (x.trades || 0), 0),
      active: this.active, ai: this.aiConfigured(), byExchange: by, config: this.adminView(),
    };
  }
  adminDetail(id) { const b = this.bots.get(String(id)); if (!b) throw berr(404, 'bot_not_found'); return Object.assign(this.view(b), { owner: b.owner || '', blocked: !!b.blocked }); }
  adminStop(id) { const b = this.bots.get(String(id)); if (!b) throw berr(404, 'bot_not_found'); b.running = false; b.status.phase = 'stopped'; this._save(); return { ok: true }; }
  adminBlock(id, on) { const b = this.bots.get(String(id)); if (!b) throw berr(404, 'bot_not_found'); b.blocked = !!on; if (on) { b.running = false; b.status.phase = 'stopped'; } this._save(); return { ok: true, blocked: !!on }; }
  adminRun(id) { const b = this.bots.get(String(id)); if (!b) throw berr(404, 'bot_not_found'); if (!b.running) throw berr(409, 'bot_stopped'); b.status.nextAt = 0; this._save(); if (!this.d.noImmediate) setTimeout(() => this.tick().catch(() => {}), 10); return { ok: true }; }
  adminDelete(id) { if (!this.bots.delete(String(id))) throw berr(404, 'bot_not_found'); this._save(); return { ok: true }; }
  adminStopAll() { let n = 0; for (const b of this.bots.values()) if (b.running) { b.running = false; b.status.phase = 'stopped'; n++; } this._save(); return { stopped: n }; }
  adminSetExpiry(id, ms) { const b = this.bots.get(String(id)); if (!b) throw berr(404, 'bot_not_found'); b.expiresAt = Number(ms) > this.now() ? Number(ms) : 0; this._save(); return { ok: true, expiresAt: b.expiresAt }; }

  /* ---------- کندل با کش مشترک بین ربات‌ها ---------- */
  async _klines(c, symbol, tf, limit) {
    const key = [c.id, symbol, tf, limit].join('|');
    const hit = this.klCache.get(key);
    const ttl = Math.min(120000, TF_SEC[tf] * 250);
    if (hit && this.now() - hit.at < ttl) return hit.p;
    const p = c.klines(this.d.ctx, symbol, tf, limit);
    this.klCache.set(key, { at: this.now(), p });
    p.catch(() => this.klCache.delete(key));
    while (this.klCache.size > 3000) this.klCache.delete(this.klCache.keys().next().value);
    return p;
  }

  /* ---------- هوش مصنوعی (اختیاری) ---------- */
  aiConfigured() { return !!this.cfg.aiKey || !!(this.d.aiCall && this.d.aiAvailable && this.d.aiAvailable()); }
  async _ai(c, row, res, klines) {
    if (!this.aiConfigured()) return null;
    const rows = klines.slice(-48).map((k) => [k[1], k[2], k[3], k[4]].map((x) => +(+x).toPrecision(6)).join(','));
    const prompt = `You are a disciplined crypto trading analyst. Analyze ${row.base}/${row.quote} (${res.tf} candles; format open,high,low,close; oldest first):\n${rows.join('\n')}\nIndicators: RSI ${res.rsi.toFixed(0)}, ADX ${res.adx.toFixed(0)}, engine signal ${res.dir} (${res.strength}).\nReply ONLY with JSON: {"direction":"buy|sell|neutral","entry":number,"stop_loss":number,"take_profit_1":number,"take_profit_2":number,"confidence":0-100}`;
    let txt = '';
    if (this.cfg.aiKey) {
      const r = await this.d.fetch((this.cfg.aiBaseUrl || 'https://api.openai.com/v1').replace(/\/+$/, '') + '/chat/completions', {
        method: 'POST', signal: AbortSignal.timeout(40000),
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + this.cfg.aiKey },
        body: JSON.stringify({ model: this.cfg.aiModel || 'gpt-4o-mini', temperature: 0.2, messages: [{ role: 'user', content: prompt }] }),
      });
      const j = await r.json();
      txt = (j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
    } else {
      /* هوش مصنوعیِ خودِ برنامه: همان سرویس‌هایی که مدیر در گاوصندوق سرور ثبت کرده */
      txt = await this.d.aiCall([{ role: 'user', content: prompt }]);
    }
    const m = String(txt).match(/\{[\s\S]*\}/);
    if (!m) return null;
    let p; try { p = JSON.parse(m[0]); } catch { return null; }
    const dir = /buy|long/i.test(p.direction) ? 'buy' : /sell|short/i.test(p.direction) ? 'sell' : 'neutral';
    return { dir, entry: num(p.entry), sl: num(p.stop_loss), tp1: num(p.take_profit_1), tp2: num(p.take_profit_2), confidence: num(p.confidence) };
  }

  /* ---------- یک چرخهٔ کامل ---------- */
  async runCycle(b) {
    const st = b.status, S = b.settings, t0 = this.now();
    st.phase = 'scanning'; st.notes = [];
    const stage = { opened: 0, candidates: 0, scanned: 0, ai: 0 };
    try {
      const c = this.d.CONNECTORS[b.exchange];
      const creds = this.dec(b.credsEnc);
      const futures = c.type === 'futures';
      const mk = await this.d.getMarkets(c);
      const tickers = await this.d.getTickers(c);
      const tmap = new Map(tickers.map((t) => [t.symbol, t]));
      let rows = mk.list.filter((m) => m.trading && STABLE.has(m.quote) && tmap.get(m.symbol) && tmap.get(m.symbol).last > 0 && tmap.get(m.symbol).quoteVol >= S.minVolUsd)
        .map((m) => ({ m, t: tmap.get(m.symbol) })).sort((x, y) => y.t.quoteVol - x.t.quoteVol).slice(0, SCOPES[S.scope]);

      const cap = Number(this.cfg.scanCap) || 0;
      if (cap > 0 && rows.length > cap) {
        const byVol = rows.slice(0, Math.ceil(cap / 3)), rest = rows.slice(byVol.length);
        const mom = rest.map((r) => ({ r, s: Math.abs(r.t.changePct || 0) * Math.log10(10 + (r.t.quoteVol || 0)) })).sort((x, y) => y.s - x.s).slice(0, cap - byVol.length).map((x) => x.r);
        rows = byVol.concat(mom);
      }
      // اسکن موازی
      const results = [];
      const queue = rows.slice();
      const worker = async () => {
        while (queue.length && b.running) {
          const r = queue.shift();
          try {
            const k = await this._klines(c, r.m.symbol, S.tf, 250);
            let res = analyze(k);
            if (res && res.dir !== 'neutral' && res.strength >= S.minScore - 10) {
              const hk = HTF[S.tf];
              if (hk && hk !== S.tf) { try { res = analyze(k, { htf: await this._klines(c, r.m.symbol, hk, 120) }) || res; } catch { /* بدون تأیید */ } }
            }
            stage.scanned++;
            if (res && res.tp1 > 0) results.push(Object.assign(res, { row: r, klines: k, tf: S.tf }));
          } catch (e) { stage.scanned++; if (/rate|429|too many/i.test(String(e.message))) await sleep(2500); }
        }
      };
      await Promise.all(Array.from({ length: 4 }, worker));
      if (!b.running) { st.phase = 'stopped'; return; }
      if (!results.length) throw berr(502, 'scan_empty', 'اسکن نتیجه‌ای نداد (صرافی در دسترس نیست؟)');

      st.phase = 'trading';
      const bal = await c.balance(this.d.ctx, creds);
      let free = (bal.balances.find((x) => String(x.asset).toUpperCase() === 'USDT') || { free: 0 }).free;
      st.balanceUsd = free;
      try { this._snapEquity(b, bal, mk.list, tmap); } catch { /* آمار اختیاری است */ }
      const held = new Set(bal.balances.filter((x) => !STABLE.has(String(x.asset).toUpperCase()) && x.free + x.locked > 0).map((x) => String(x.asset).toUpperCase()));
      const openPos = new Set();
      if (futures && typeof c.positions === 'function') { try { (await c.positions(this.d.ctx, creds)).forEach((p) => openPos.add(p.symbol)); } catch { /* ignore */ } }
      const traded = new Set(b.trades.filter((t) => t.ok && now24(t.at, this.now())).map((t) => t.symbol));
      const openGuards = b.guards.filter((g) => g.status === 'open').length;

      const pre = S.useAI && this.aiConfigured() ? Math.max(50, S.minScore - 10) : S.minScore;
      const cands = results.filter((r) => r.dir !== 'neutral' && (futures ? (r.dir === 'buy' || S.allowShort) : r.dir === 'buy') && r.strength >= pre && r.rr1 >= 1 &&
        !traded.has(r.row.m.symbol) && (futures ? !openPos.has(r.row.m.symbol) : !held.has(r.row.m.base))).sort((x, y) => y.strength - x.strength);
      stage.candidates = cands.length;

      let aiUsed = 0;
      for (const r of cands) {
        if (!b.running) break;
        const m = r.row.m, last = r.row.t.last;
        const today = b.trades.filter((t) => t.ok && !t.test && t.at >= startOfDay(this.now()) && t.kind !== 'exit');
        if (today.length >= S.maxDaily) { st.notes.push('سقف معاملات امروز پر شد'); break; }
        if (today.reduce((s, t) => s + (t.notional || 0), 0) >= S.maxDailyUsd) { st.notes.push('سقف مبلغ امروز پر شد'); break; }
        if (!futures && openGuards + stage.opened >= S.maxOpen) { st.notes.push('سقف پوزیشن‌های هم‌زمان پر شد'); break; }
        let plan = { dir: r.dir, sl: r.sl, tp: r.tp1, src: 'bot' };
        if (S.useAI && this.aiConfigured()) {
          if (aiUsed >= S.aiMax) break;
          const soft = !!(this.d.aiSoft && this.d.aiSoft());   // AI رایگان پیش‌فرض: اگر در دسترس نبود، فقط موتور تحلیل
          let aiFail = false;
          try {
            aiUsed++; stage.ai++;
            const ai = await this._ai(c, m, r, r.klines);
            if (!ai) aiFail = true;
            else {
              if (ai.dir !== r.dir) { st.notes.push(m.base + ': AI موافق نبود'); continue; }
              if (ai.confidence < S.minScore) { st.notes.push(m.base + ': اطمینان AI ' + ai.confidence); continue; }
              if (!(ai.sl > 0 && ai.tp1 > 0)) { st.notes.push(m.base + ': AI حد ضرر/سود نداد'); continue; }
              if (ai.entry > 0 && Math.abs(ai.entry - last) / last > 0.03) { st.notes.push(m.base + ': ورود AI از بازار دور است'); continue; }
              plan = { dir: ai.dir, sl: ai.sl, tp: ai.tp1, src: 'bot-ai' };
            }
          } catch (e) { aiFail = true; }
          if (aiFail) {
            if (soft && r.strength >= S.minScore) st.notes.push(m.base + ': AI در دسترس نبود؛ فقط موتور تحلیل');
            else { st.notes.push(m.base + ': ' + (soft ? 'امتیاز موتور کم' : 'خطای AI')); continue; }
          }
        } else if (r.strength < S.minScore) continue;

        const sz = sizeOrder({ side: plan.dir, entry: last, sl: plan.sl, tp: plan.tp, mode: S.sizing.mode, usd: S.sizing.usd, pct: S.sizing.pct, riskPct: S.sizing.riskPct, balance: free, maxOrderUsd: S.maxOrderUsd, leverage: S.leverage, futures, market: m });
        if (sz.errors.length) { st.notes.push(m.base + ': ' + sz.errors[0]); continue; }
        if (sz.rr < S.minRR) { st.notes.push(m.base + ': R/R کم (' + sz.rr.toFixed(2) + ')'); continue; }
        const rec = { id: rid(6), at: this.now(), symbol: m.symbol, base: m.base, side: plan.dir, notional: sz.notional, src: plan.src, sl: plan.sl, tp: plan.tp, ok: false, kind: 'entry' };
        try {
          const order = { symbol: m.symbol, side: plan.dir, type: 'market', sl: plan.sl, tp: plan.tp, clientId: 'bot' + rid(8) };
          if (futures) { order.qty = sz.qty; order.leverage = Math.min(S.leverage, m.maxLeverage || S.leverage); order.marginMode = 'isolated'; } else order.quoteQty = sz.notional;
          const out = await this.d.placeOrderFlow(c, creds, order, futures ? undefined : { sl: plan.sl, tp: plan.tp, refPrice: last });
          Object.assign(rec, { ok: true, orderId: out.orderId, protection: out.protection && out.protection.native ? 'native' : futures ? 'attached' : 'guard' });
          if (!futures && !(out.protection && out.protection.native)) {
            b.guards.push({ id: rid(6), symbol: m.symbol, base: m.base, qty: num(out.filledQty) || (sz.notional / last) * 0.997, sl: plan.sl, tp: plan.tp, at: this.now(), status: 'open' });
          }
          stage.opened++; free -= sz.margin;
        } catch (e) {
          rec.err = String(e.message || '').slice(0, 160); st.notes.push(m.base + ': ' + rec.err);
          b.trades.unshift(rec);
          if (/invalid api|signature|permission|whitelist|unauthor|ip/i.test(rec.err) && !/balance|insufficient/i.test(rec.err)) throw Object.assign(berr(401, 'auth', rec.err), { fatal: true });
          if (/balance|insufficient|موجودی/i.test(rec.err)) break;
          continue;
        }
        b.trades.unshift(rec);
      }
      b.trades = b.trades.slice(0, 200);
      Object.assign(st, { phase: 'idle', lastCycleAt: this.now(), lastError: null, fails: 0, scanned: stage.scanned, candidates: stage.candidates, opened: stage.opened, ai: stage.ai, tookMs: this.now() - t0 });
      st.nextAt = this.now() + S.everyMin * 60000;
      st.notes = st.notes.slice(0, 5);
    } catch (e) {
      st.fails = (st.fails || 0) + 1; st.lastError = String(e.message || 'خطا').slice(0, 200); st.phase = 'error'; st.lastCycleAt = this.now();
      st.nextAt = this.now() + 5 * 60000;
      this.d.log('warn', 'خطای چرخهٔ ربات', { bot: b.id, ex: b.exchange, err: st.lastError });
      if (e.fatal || e.exCode !== undefined && /invalid|signature|permission|ip/i.test(st.lastError) || st.fails >= 5) { b.running = false; st.phase = 'stopped'; st.lastError = (e.fatal ? 'کلید یا آی‌پی مجاز نیست: ' : st.fails >= 5 ? '۵ خطای پشت‌سرهم: ' : '') + st.lastError; }
    }
  }

  /* ---------- نگهبان حد ضرر/سود (اسپات بدون OCO بومی) ---------- */
  async guardTick() {
    for (const b of this.bots.values()) {
      const open = b.guards.filter((g) => g.status === 'open');
      if (!open.length || b.guardBusy) continue;
      b.guardBusy = true;
      try {
        const c = this.d.CONNECTORS[b.exchange];
        const tk = new Map((await this.d.getTickers(c)).map((t) => [t.symbol, t]));
        const mk = await this.d.getMarkets(c);
        const creds = this.dec(b.credsEnc);
        for (const g of open) {
          const t = tk.get(g.symbol); if (!t) continue;
          const hit = t.last <= g.sl ? 'sl' : t.last >= g.tp ? 'tp' : null;
          if (!hit) continue;
          try {
            const bal = await c.balance(this.d.ctx, creds);
            const free = (bal.balances.find((x) => String(x.asset).toUpperCase() === g.base) || { free: 0 }).free;
            const qty = Math.min(free, g.qty || free);
            const m = mk.map.get(g.symbol);
            if (qty > 0 && m) {
              await this.d.placeOrderFlow(c, creds, { symbol: g.symbol, side: 'sell', type: 'market', qty: floorToStep(qty, m.stepSize) || qty }, undefined);
              b.trades.unshift({ id: rid(6), at: this.now(), symbol: g.symbol, base: g.base, side: 'sell', notional: qty * t.last, src: 'guard-' + hit, ok: true, kind: 'exit' });
            }
            g.status = hit; g.closedAt = this.now(); g.closePrice = t.last;
          } catch (e) { g.status = 'error'; g.err = String(e.message || '').slice(0, 160); g.closedAt = this.now(); }
        }
        this._save();
      } catch { /* بعداً دوباره */ } finally { b.guardBusy = false; }
    }
  }
}

function startOfDay(now) { const d = new Date(now); d.setHours(0, 0, 0, 0); return d.getTime(); }
function now24(at, now) { return now - at < DAY; }

module.exports = { BotManager, sanitizeSettings, defaultSettings, sizeOrder };
