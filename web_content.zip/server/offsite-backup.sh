#!/usr/bin/env bash
# بکاپ کامل داده‌های سرور (بیرون از کانتینر) — هیچ نسخه‌ای پاک نمی‌شود.
# اجرای روزانه با cron:   0 3 * * *  /opt/tradyar/server/offsite-backup.sh
# اختیاری: کپی بیرون از سرور با rclone →  RCLONE_REMOTE=mydrive:tradyar-backups ./offsite-backup.sh
set -euo pipefail
cd "$(dirname "$0")"
DEST="${BACKUP_DIR:-/root/tradyar-backups}"
mkdir -p "$DEST"
FILE="$DEST/tradyar-$(date +%Y-%m-%d_%H%M).tar.gz"
docker compose exec -T tradyar sh -c 'tar -czf - -C /data .' > "$FILE"
[ -s "$FILE" ] || { echo "❌ بکاپ خالی بود"; rm -f "$FILE"; exit 1; }
echo "✅ $FILE ($(du -h "$FILE" | cut -f1))"
if [ -n "${RCLONE_REMOTE:-}" ]; then
  rclone copy "$DEST" "$RCLONE_REMOTE" --immutable && echo "☁️  کپی شد به $RCLONE_REMOTE"
fi
