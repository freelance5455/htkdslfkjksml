'use strict';
/**
 * ترید یار — اتصال واقعی به صرافی‌ها (بازار، تحلیل و معامله)
 * ------------------------------------------------------------------
 * هر کانکتور این توابع را دارد (همه با امضای واقعی API رسمی هر صرافی):
 *   markets()                      → فهرست همهٔ جفت‌ارزهای قابل معامله + قوانین دقت/حداقل
 *   tickers()                      → قیمت و حجم ۲۴ساعتهٔ همهٔ جفت‌ارزها
 *   klines(symbol, interval, n)    → کندل‌ها [ts,o,h,l,c,v] صعودی
 *   balance(creds)                 → موجودی‌ها
 *   placeOrder(creds, order)       → ثبت سفارش واقعی (یا تست، اگر صرافی پشتیبانی کند)
 *   protect(creds, plan)           → حد ضرر/سود بومی صرافی (اگر پشتیبانی شود)
 *   positions(creds) / closePosition(creds, ...)   → فقط بازارهای فیوچرز
 *
 * کلیدهای API هیچ‌جا ذخیره یا لاگ نمی‌شوند؛ فقط برای امضای همان درخواست استفاده می‌شوند.
 */

const crypto = require('node:crypto');

/* ------------------------------ ابزارها ------------------------------ */

class ExchangeError extends Error {
  constructor(message, { code, status, raw } = {}) {
    super(message);
    this.name = 'ExchangeError';
    this.exCode = code;
    this.exStatus = status;
    this.raw = raw;
  }
}

const hmac = (algo, secret, msg, enc = 'hex') => crypto.createHmac(algo, secret).update(msg).digest(enc);
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const sha512 = (s) => crypto.createHash('sha512').update(s).digest('hex');
const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };
const rnd = (len = 32) => crypto.randomBytes(len).toString('hex').slice(0, len);

const cleanObj = (o) => {
  const r = {};
  for (const k of Object.keys(o || {})) if (o[k] !== undefined && o[k] !== null && o[k] !== '') r[k] = o[k];
  return r;
};
const qs = (o) => Object.entries(cleanObj(o)).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
const qsRaw = (o) => Object.entries(cleanObj(o)).map(([k, v]) => `${k}=${v}`).join('&');
const sortedKeys = (o) => Object.keys(cleanObj(o)).sort();

/* تعداد رقم اعشار یک step مثل 0.001 → 3 (با پشتیبانی از 1e-7) */
function decimalsOf(step) {
  const n = Number(step);
  if (!(n > 0)) return 8;
  const s = String(n);
  if (s.includes('e-')) {
    const [m, e] = s.split('e-');
    return parseInt(e, 10) + ((m.split('.')[1] || '').length);
  }
  const i = s.indexOf('.');
  return i < 0 ? 0 : s.length - i - 1;
}
const stepFromDecimals = (d) => (Number.isInteger(+d) && +d >= 0 ? Number((10 ** -d).toFixed(Math.min(+d, 20))) : 0);

/* گرد کردن رو به پایین به مضرب step و برگرداندن رشتهٔ بدون نماد علمی */
function floorToStep(value, step) {
  const v = Number(value);
  if (!(v > 0)) return '0';
  if (!(step > 0)) return String(v);
  const d = decimalsOf(step);
  const units = Math.floor(v / step + 1e-9);
  return (units * step).toFixed(Math.min(d, 20));
}

const STABLES = new Set(['USDT', 'USDC', 'USD', 'BUSD', 'FDUSD', 'TUSD', 'DAI', 'EUR', 'TRY', 'USDD']);
const normInterval = (iv) => (['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'].includes(iv) ? iv : '1h');
const IV_SEC = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800 };

/* خروجی استاندارد بازار */
function mkMarket(o) {
  const m = {
    symbol: o.symbol, base: String(o.base || '').toUpperCase(), quote: String(o.quote || '').toUpperCase(),
    tickSize: num(o.tickSize), stepSize: num(o.stepSize), minQty: num(o.minQty), minNotional: num(o.minNotional),
    trading: o.trading !== false, type: o.type || 'spot',
  };
  if (o.maxLeverage) m.maxLeverage = num(o.maxLeverage);
  return m;
}

/* اعتبارسنجی و گردکردن سفارش بر اساس قوانین بازار؛ خروجی: مقادیر آمادهٔ ارسال (رشته) */
function prepareOrder(market, o) {
  const side = String(o.side || '').toLowerCase();
  const type = String(o.type || 'market').toLowerCase();
  if (side !== 'buy' && side !== 'sell') throw new ExchangeError('side نامعتبر است', { code: 'bad_side' });
  if (type !== 'market' && type !== 'limit') throw new ExchangeError('type نامعتبر است', { code: 'bad_type' });
  if (!market) throw new ExchangeError('جفت‌ارز در این صرافی پیدا نشد', { code: 'unknown_symbol' });
  if (market.trading === false) throw new ExchangeError('معامله روی این جفت‌ارز فعلاً غیرفعال است', { code: 'not_trading' });
  const out = { side, type, market };
  const quoteDec = STABLES.has(market.quote) ? 2 : 8;
  if (type === 'limit') {
    const price = Number(o.price);
    if (!(price > 0)) throw new ExchangeError('قیمت نامعتبر است', { code: 'bad_price' });
    out.price = market.tickSize > 0 ? floorToStep(price, market.tickSize) : String(price);
    const qty = Number(o.qty);
    if (!(qty > 0)) throw new ExchangeError('حجم نامعتبر است', { code: 'bad_qty' });
    out.qty = market.stepSize > 0 ? floorToStep(qty, market.stepSize) : String(qty);
    if (!(Number(out.qty) > 0)) throw new ExchangeError('حجم بعد از گرد کردن صفر شد (کمتر از حداقل گام)', { code: 'below_step' });
    if (market.minQty && Number(out.qty) < market.minQty) throw new ExchangeError('حجم کمتر از حداقل مجاز صرافی است (' + market.minQty + ')', { code: 'below_min_qty' });
    if (market.minNotional && Number(out.qty) * Number(out.price) < market.minNotional) throw new ExchangeError('ارزش سفارش کمتر از حداقل صرافی است (' + market.minNotional + ' ' + market.quote + ')', { code: 'below_min_notional' });
    return out;
  }
  // سفارش مارکت
  if (market.type === 'futures' || side === 'sell') {
    const qty = Number(o.qty);
    if (!(qty > 0)) throw new ExchangeError('حجم نامعتبر است', { code: 'bad_qty' });
    out.qty = market.stepSize > 0 ? floorToStep(qty, market.stepSize) : String(qty);
    if (!(Number(out.qty) > 0)) throw new ExchangeError('حجم بعد از گرد کردن صفر شد', { code: 'below_step' });
    if (market.minQty && Number(out.qty) < market.minQty) throw new ExchangeError('حجم کمتر از حداقل مجاز صرافی است (' + market.minQty + ')', { code: 'below_min_qty' });
    return out;
  }
  // خرید مارکت اسپات: مبلغ به واحد quote
  const qq = Number(o.quoteQty);
  if (!(qq > 0)) throw new ExchangeError('مبلغ خرید نامعتبر است', { code: 'bad_quote_qty' });
  out.quoteQty = (Math.floor(qq * 10 ** quoteDec + 1e-9) / 10 ** quoteDec).toFixed(quoteDec);
  if (market.minNotional && Number(out.quoteQty) < market.minNotional) throw new ExchangeError('مبلغ خرید کمتر از حداقل صرافی است (' + market.minNotional + ' ' + market.quote + ')', { code: 'below_min_notional' });
  return out;
}

/* ------------------------- کانکتور پایه (ساختار مشترک) ------------------------- */

/**
 * ctx = { http(method,url,{headers,body}) → {status,json,text}, now(), nonce() }
 * کانکتورها فقط درخواست می‌سازند/امضا می‌کنند؛ شبکه را ctx انجام می‌دهد.
 */

const need = (creds, ...fields) => {
  for (const f of fields) if (!creds || !creds[f]) throw new ExchangeError('فیلد ' + f + ' برای این صرافی لازم است', { code: 'missing_' + f });
};
const bad = (msg, code, raw) => new ExchangeError(msg, { code, raw });

/* ============================ Binance / MEXC (خانوادهٔ مشابه) ============================ */

function binanceLike({ id, name, base, headerName, ivMap, mexc }) {
  const signed = async (ctx, creds, method, path, params = {}) => {
    need(creds, 'apiKey', 'apiSecret');
    const p = cleanObj({ ...params, recvWindow: 10000, timestamp: ctx.now() });
    const query = qs(p);
    const signature = hmac('sha256', creds.apiSecret, query);
    const r = await ctx.http(method, `${base}${path}?${query}&signature=${signature}`, { headers: { [headerName]: creds.apiKey } });
    return unwrap(r);
  };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || (j && typeof j === 'object' && !Array.isArray(j) && j.code && Number(j.code) < 0) || (mexc && j && j.code && Number(j.code) !== 200 && j.msg)) {
      throw new ExchangeError((j && (j.msg || j.message)) || 'خطای صرافی ' + r.status, { code: j && j.code, status: r.status, raw: j });
    }
    return j;
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));

  return {
    id, name, type: 'spot', needsPassphrase: false, hosts: [new URL(base).hostname],
    async markets(ctx) {
      const j = await pub(ctx, '/api/v3/exchangeInfo');
      return (j.symbols || []).map((s) => {
        const f = {};
        (s.filters || []).forEach((x) => { f[x.filterType] = x; });
        const active = mexc ? (String(s.status) === '1' || String(s.status).toUpperCase() === 'ENABLED') && s.isSpotTradingAllowed !== false : s.status === 'TRADING' && s.isSpotTradingAllowed !== false;
        let tick = f.PRICE_FILTER ? num(f.PRICE_FILTER.tickSize) : 0;
        let step = f.LOT_SIZE ? num(f.LOT_SIZE.stepSize) : 0;
        let minQty = f.LOT_SIZE ? num(f.LOT_SIZE.minQty) : 0;
        let minNot = f.NOTIONAL ? num(f.NOTIONAL.minNotional) : f.MIN_NOTIONAL ? num(f.MIN_NOTIONAL.minNotional) : 0;
        if (mexc) {
          tick = tick || stepFromDecimals(s.quoteAssetPrecision != null ? s.quoteAssetPrecision : s.quotePrecision);
          step = step || num(s.baseSizePrecision) || stepFromDecimals(s.baseAssetPrecision);
          minNot = minNot || num(s.quoteAmountPrecision);
        }
        return mkMarket({ symbol: s.symbol, base: s.baseAsset, quote: s.quoteAsset, trading: active, tickSize: tick, stepSize: step, minQty, minNotional: minNot });
      });
    },
    async tickers(ctx) {
      const j = await pub(ctx, '/api/v3/ticker/24hr');
      return (Array.isArray(j) ? j : []).map((t) => {
        const last = num(t.lastPrice), open = num(t.openPrice);
        return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : num(t.priceChangePercent), quoteVol: num(t.quoteVolume), high: num(t.highPrice), low: num(t.lowPrice) };
      });
    },
    async klines(ctx, symbol, interval, limit) {
      const iv = ivMap[normInterval(interval)];
      const j = await pub(ctx, '/api/v3/klines', { symbol, interval: iv, limit: Math.min(limit || 300, 1000) });
      return (Array.isArray(j) ? j : []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]);
    },
    async balance(ctx, creds) {
      const j = await signed(ctx, creds, 'GET', '/api/v3/account');
      return { balances: (j.balances || []).map((b) => ({ asset: b.asset, free: num(b.free), locked: num(b.locked) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: j.canTrade !== false, canWithdraw: j.canWithdraw === true };
    },
    async placeOrder(ctx, creds, o) {
      const m = o.market;
      const params = { symbol: m.symbol, side: o.side.toUpperCase(), type: o.type.toUpperCase() };
      if (o.type === 'limit') { params.quantity = o.qty; params.price = o.price; params.timeInForce = 'GTC'; }
      else if (o.quoteQty) params.quoteOrderQty = o.quoteQty;
      else params.quantity = o.qty;
      if (o.clientId) params.newClientOrderId = o.clientId;
      const j = await signed(ctx, creds, 'POST', o.test ? '/api/v3/order/test' : '/api/v3/order', params);
      return { orderId: String((j && (j.orderId || j.orderListId)) || ''), status: j && j.status, filledQty: num(j && j.executedQty), quoteSpent: num(j && j.cummulativeQuoteQty), raw: j };
    },
    async openOrders(ctx, creds, symbol) {
      const j = await signed(ctx, creds, 'GET', '/api/v3/openOrders', { symbol });
      return (Array.isArray(j) ? j : []).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: String(x.side).toLowerCase(), type: String(x.type).toLowerCase(), price: num(x.price), qty: num(x.origQty), filled: num(x.executedQty), status: x.status, time: x.time }));
    },
    async cancelOrder(ctx, creds, symbol, orderId) {
      const j = await signed(ctx, creds, 'DELETE', '/api/v3/order', { symbol, orderId });
      return { orderId: String(orderId), raw: j };
    },
    /* OCO فروش بومی (فقط Binance): حد سود + حد ضرر، هر کدام فعال شد دیگری لغو می‌شود */
    async protect(ctx, creds, p) {
      if (mexc) return { native: false, reason: 'unsupported' };
      const m = p.market;
      const params = {
        symbol: m.symbol, side: 'SELL', quantity: p.qty,
        aboveType: 'LIMIT_MAKER', abovePrice: floorToStep(p.tp, m.tickSize),
        belowType: 'STOP_LOSS_LIMIT', belowStopPrice: floorToStep(p.sl, m.tickSize),
        belowPrice: floorToStep(p.sl * 0.995, m.tickSize), belowTimeInForce: 'GTC',
      };
      const j = await signed(ctx, creds, 'POST', '/api/v3/orderList/oco', params);
      return { native: true, orderId: String((j && j.orderListId) || ''), raw: j };
    },
  };
}

const BINANCE_IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
const MEXC_IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '60m', '4h': '4h', '1d': '1d', '1w': '1W' };

/* ================================== Bybit v5 ================================== */

function bybit() {
  const base = 'https://api.bybit.com';
  const IV = { '1m': '1', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D', '1w': 'W' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || Number(j.retCode) !== 0) throw new ExchangeError((j && j.retMsg) || 'خطای Bybit ' + r.status, { code: j && j.retCode, status: r.status, raw: j });
    return j.result;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const ts = String(ctx.now()), recv = '10000';
    const query = method === 'GET' ? qs(params || {}) : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    const sign = hmac('sha256', creds.apiSecret, ts + creds.apiKey + recv + (method === 'GET' ? query : bodyStr));
    const headers = { 'X-BAPI-API-KEY': creds.apiKey, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': sign, 'Content-Type': 'application/json' };
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
  return {
    id: 'bybit', name: 'Bybit', type: 'spot', needsPassphrase: false, hosts: ['api.bybit.com'],
    async markets(ctx) {
      const r = await pub(ctx, '/v5/market/instruments-info', { category: 'spot', limit: 1000 });
      return (r.list || []).map((s) => mkMarket({
        symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, trading: s.status === 'Trading',
        tickSize: num(s.priceFilter && s.priceFilter.tickSize), stepSize: num(s.lotSizeFilter && s.lotSizeFilter.basePrecision),
        minQty: num(s.lotSizeFilter && s.lotSizeFilter.minOrderQty), minNotional: num(s.lotSizeFilter && s.lotSizeFilter.minOrderAmt),
      }));
    },
    async tickers(ctx) {
      const r = await pub(ctx, '/v5/market/tickers', { category: 'spot' });
      return (r.list || []).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: num(t.price24hPcnt) * 100, quoteVol: num(t.turnover24h), high: num(t.highPrice24h), low: num(t.lowPrice24h) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const r = await pub(ctx, '/v5/market/kline', { category: 'spot', symbol, interval: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
      return (r.list || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).reverse();
    },
    async balance(ctx, creds) {
      const r = await call(ctx, creds, 'GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED' });
      const coins = (r.list && r.list[0] && r.list[0].coin) || [];
      return { balances: coins.map((c) => { const wb = num(c.walletBalance), lk = num(c.locked); return { asset: c.coin, free: Math.max(0, wb - lk), locked: lk }; }).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Bybit حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { category: 'spot', symbol: o.market.symbol, side: o.side === 'buy' ? 'Buy' : 'Sell', orderType: o.type === 'limit' ? 'Limit' : 'Market' };
      if (o.type === 'limit') { body.qty = o.qty; body.price = o.price; body.timeInForce = 'GTC'; }
      else if (o.quoteQty) { body.qty = o.quoteQty; body.marketUnit = 'quoteCoin'; }
      else { body.qty = o.qty; body.marketUnit = 'baseCoin'; }
      if (o.clientId) body.orderLinkId = o.clientId;
      const r = await call(ctx, creds, 'POST', '/v5/order/create', null, body);
      return { orderId: String(r.orderId || ''), raw: r };
    },
  };
}

/* =================================== OKX v5 =================================== */

function okx() {
  const base = 'https://www.okx.com';
  const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || String(j.code) !== '0') {
      const d = j && j.data && j.data[0];
      throw new ExchangeError((d && d.sMsg) || (j && j.msg) || 'خطای OKX ' + r.status, { code: (d && d.sCode) || (j && j.code), status: r.status, raw: j });
    }
    const d = j.data && j.data[0];
    if (d && d.sCode !== undefined && String(d.sCode) !== '0') throw new ExchangeError(d.sMsg || 'سفارش رد شد', { code: d.sCode, raw: j });
    return j.data;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret', 'passphrase');
    const ts = new Date(ctx.now()).toISOString();
    const reqPath = path + (params && Object.keys(cleanObj(params)).length ? '?' + qs(params) : '');
    const bodyStr = body ? JSON.stringify(body) : '';
    const sign = hmac('sha256', creds.apiSecret, ts + method + reqPath + bodyStr, 'base64');
    const headers = { 'OK-ACCESS-KEY': creds.apiKey, 'OK-ACCESS-SIGN': sign, 'OK-ACCESS-TIMESTAMP': ts, 'OK-ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json' };
    return unwrap(await ctx.http(method, base + reqPath, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
  return {
    id: 'okx', name: 'OKX', type: 'spot', needsPassphrase: true, hosts: ['www.okx.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v5/public/instruments', { instType: 'SPOT' });
      return d.map((s) => mkMarket({ symbol: s.instId, base: s.baseCcy, quote: s.quoteCcy, trading: s.state === 'live', tickSize: num(s.tickSz), stepSize: num(s.lotSz), minQty: num(s.minSz) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v5/market/tickers', { instType: 'SPOT' });
      return d.map((t) => { const last = num(t.last), open = num(t.open24h); return { symbol: t.instId, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.volCcy24h), high: num(t.high24h), low: num(t.low24h) }; });
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/api/v5/market/candles', { instId: symbol, bar: IV[normInterval(interval)], limit: Math.min(limit || 300, 300) });
      return d.map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).reverse();
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v5/account/balance', {});
      const det = (d[0] && d[0].details) || [];
      return { balances: det.map((x) => ({ asset: x.ccy, free: num(x.availBal), locked: num(x.frozenBal) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('OKX حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { instId: o.market.symbol, tdMode: 'cash', side: o.side, ordType: o.type };
      if (o.type === 'limit') { body.sz = o.qty; body.px = o.price; }
      else if (o.quoteQty) { body.sz = o.quoteQty; body.tgtCcy = 'quote_ccy'; }
      else { body.sz = o.qty; body.tgtCcy = 'base_ccy'; }
      if (o.clientId) body.clOrdId = o.clientId;
      const d = await call(ctx, creds, 'POST', '/api/v5/trade/order', null, body);
      return { orderId: String((d[0] && d[0].ordId) || ''), raw: d };
    },
    /* OCO بومی OKX (اسپات): فروش با حد سود/ضرر مارکت */
    async protect(ctx, creds, p) {
      const body = { instId: p.market.symbol, tdMode: 'cash', side: 'sell', ordType: 'oco', sz: p.qty, tpTriggerPx: floorToStep(p.tp, p.market.tickSize), tpOrdPx: '-1', slTriggerPx: floorToStep(p.sl, p.market.tickSize), slOrdPx: '-1' };
      const d = await call(ctx, creds, 'POST', '/api/v5/trade/order-algo', null, body);
      return { native: true, orderId: String((d[0] && d[0].algoId) || ''), raw: d };
    },
  };
}

/* ================================== KuCoin ================================== */

function kucoin() {
  const base = 'https://api.kucoin.com';
  const IV = { '1m': '1min', '5m': '5min', '15m': '15min', '30m': '30min', '1h': '1hour', '4h': '4hour', '1d': '1day', '1w': '1week' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || String(j.code) !== '200000') throw new ExchangeError((j && j.msg) || 'خطای KuCoin ' + r.status, { code: j && j.code, status: r.status, raw: j });
    return j.data;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret', 'passphrase');
    const ts = String(ctx.now());
    const ep = path + (params && Object.keys(cleanObj(params)).length ? '?' + qs(params) : '');
    const bodyStr = body ? JSON.stringify(body) : '';
    const headers = {
      'KC-API-KEY': creds.apiKey, 'KC-API-TIMESTAMP': ts, 'KC-API-KEY-VERSION': '2', 'Content-Type': 'application/json',
      'KC-API-SIGN': hmac('sha256', creds.apiSecret, ts + method + ep + bodyStr, 'base64'),
      'KC-API-PASSPHRASE': hmac('sha256', creds.apiSecret, creds.passphrase, 'base64'),
    };
    return unwrap(await ctx.http(method, base + ep, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'kucoin', name: 'KuCoin', type: 'spot', needsPassphrase: true, hosts: ['api.kucoin.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v2/symbols');
      return d.map((s) => mkMarket({ symbol: s.symbol, base: s.baseCurrency, quote: s.quoteCurrency, trading: s.enableTrading !== false, tickSize: num(s.priceIncrement), stepSize: num(s.baseIncrement), minQty: num(s.baseMinSize), minNotional: num(s.minFunds || s.quoteMinSize) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v1/market/allTickers');
      return ((d && d.ticker) || []).map((t) => ({ symbol: t.symbol, last: num(t.last), changePct: num(t.changeRate) * 100, quoteVol: num(t.volValue), high: num(t.high), low: num(t.low) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const iv = normInterval(interval);
      const end = Math.floor(ctx.now() / 1000), start = end - IV_SEC[iv] * Math.min(limit || 300, 1500);
      const d = await pub(ctx, '/api/v1/market/candles', { symbol, type: IV[iv], startAt: start, endAt: end });
      return (d || []).map((k) => [num(k[0]) * 1000, num(k[1]), num(k[3]), num(k[4]), num(k[2]), num(k[5])]).reverse();
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v1/accounts', { type: 'trade' });
      return { balances: d.map((x) => ({ asset: x.currency, free: num(x.available), locked: num(x.holds) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      const body = { clientOid: o.clientId || rnd(24), side: o.side, symbol: o.market.symbol, type: o.type };
      if (o.type === 'limit') { body.size = o.qty; body.price = o.price; }
      else if (o.quoteQty) body.funds = o.quoteQty;
      else body.size = o.qty;
      const d = await call(ctx, creds, 'POST', o.test ? '/api/v1/orders/test' : '/api/v1/orders', null, body);
      return { orderId: String((d && d.orderId) || ''), raw: d };
    },
  };
}

/* ================================ Gate.io v4 ================================ */

function gate() {
  const host = 'https://api.gateio.ws', prefix = '/api/v4';
  const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '7d' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || (j && !Array.isArray(j) && j.label)) throw new ExchangeError((j && (j.message || j.label)) || 'خطای Gate ' + r.status, { code: j && j.label, status: r.status, raw: j });
    return j;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const ts = String(Math.floor(ctx.now() / 1000));
    const query = params ? qs(params) : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    const payload = [method, prefix + path, query, sha512(bodyStr), ts].join('\n');
    const headers = { KEY: creds.apiKey, Timestamp: ts, SIGN: hmac('sha512', creds.apiSecret, payload), 'Content-Type': 'application/json', Accept: 'application/json' };
    return unwrap(await ctx.http(method, `${host}${prefix}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${host}${prefix}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'gate', name: 'Gate.io', type: 'spot', needsPassphrase: false, hosts: ['api.gateio.ws'],
    async markets(ctx) {
      const d = await pub(ctx, '/spot/currency_pairs');
      return d.map((s) => mkMarket({ symbol: s.id, base: s.base, quote: s.quote, trading: s.trade_status === 'tradable', tickSize: stepFromDecimals(s.precision), stepSize: stepFromDecimals(s.amount_precision), minQty: num(s.min_base_amount), minNotional: num(s.min_quote_amount) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/spot/tickers');
      return d.map((t) => ({ symbol: t.currency_pair, last: num(t.last), changePct: num(t.change_percentage), quoteVol: num(t.quote_volume), high: num(t.high_24h), low: num(t.low_24h) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/spot/candlesticks', { currency_pair: symbol, interval: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
      return d.map((k) => [num(k[0]) * 1000, num(k[5]), num(k[3]), num(k[4]), num(k[2]), num(k[6])]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/spot/accounts', {});
      return { balances: d.map((x) => ({ asset: x.currency, free: num(x.available), locked: num(x.locked) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Gate حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { currency_pair: o.market.symbol, side: o.side, type: o.type, account: 'spot', text: 't-' + (o.clientId || rnd(16)) };
      if (o.type === 'limit') { body.amount = o.qty; body.price = o.price; body.time_in_force = 'gtc'; }
      else { body.amount = o.quoteQty || o.qty; body.time_in_force = 'ioc'; }
      const d = await call(ctx, creds, 'POST', '/spot/orders', null, body);
      return { orderId: String((d && d.id) || ''), status: d && d.status, raw: d };
    },
  };
}

/* ================================ Bitget v2 ================================ */

function bitget() {
  const base = 'https://api.bitget.com';
  const IV = { '1m': '1min', '5m': '5min', '15m': '15min', '30m': '30min', '1h': '1h', '4h': '4h', '1d': '1day', '1w': '1week' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || String(j.code) !== '00000') throw new ExchangeError((j && j.msg) || 'خطای Bitget ' + r.status, { code: j && j.code, status: r.status, raw: j });
    return j.data;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret', 'passphrase');
    const ts = String(ctx.now());
    const query = params ? qs(params) : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    const headers = {
      'ACCESS-KEY': creds.apiKey, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json', locale: 'en-US',
      'ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + path + (query ? '?' + query : '') + bodyStr, 'base64'),
    };
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'bitget', name: 'Bitget', type: 'spot', needsPassphrase: true, hosts: ['api.bitget.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v2/spot/public/symbols');
      return d.map((s) => mkMarket({ symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, trading: s.status === 'online', tickSize: stepFromDecimals(s.pricePrecision), stepSize: stepFromDecimals(s.quantityPrecision), minQty: num(s.minTradeAmount), minNotional: num(s.minTradeUSDT) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v2/spot/market/tickers');
      return d.map((t) => { const last = num(t.lastPr), open = num(t.open); return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : num(t.change24h) * 100, quoteVol: num(t.quoteVolume), high: num(t.high24h), low: num(t.low24h) }; });
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/api/v2/spot/market/candles', { symbol, granularity: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
      return d.map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).sort((a, b) => a[0] - b[0]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v2/spot/account/assets', {});
      return { balances: d.map((x) => ({ asset: x.coin, free: num(x.available), locked: num(x.frozen) + num(x.locked) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Bitget حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { symbol: o.market.symbol, side: o.side, orderType: o.type, force: 'gtc', clientOid: o.clientId || rnd(24) };
      if (o.type === 'limit') { body.price = o.price; body.size = o.qty; }
      else body.size = o.quoteQty || o.qty; // خرید مارکت: مبلغ quote | فروش مارکت: مقدار base
      const d = await call(ctx, creds, 'POST', '/api/v2/spot/trade/place-order', null, body);
      return { orderId: String((d && d.orderId) || ''), raw: d };
    },
  };
}

/* ================================== LBank v2 ================================== */

function lbank() {
  const base = 'https://api.lbkex.com';
  const IV = { '1m': 'minute1', '5m': 'minute5', '15m': 'minute15', '30m': 'minute30', '1h': 'hour1', '4h': 'hour4', '1d': 'day1', '1w': 'week1' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || (String(j.result) !== 'true' && j.result !== true)) throw new ExchangeError('خطای LBank (کد ' + ((j && j.error_code) || r.status) + ')' + (j && j.msg ? ': ' + j.msg : ''), { code: j && j.error_code, status: r.status, raw: j });
    return j.data;
  };
  /* امضا: پارامترها مرتب → MD5 با حروف بزرگ → HmacSHA256 */
  const call = async (ctx, creds, path, params) => {
    need(creds, 'apiKey', 'apiSecret');
    const sys = { api_key: creds.apiKey, signature_method: 'HmacSHA256', timestamp: String(ctx.now()), echostr: rnd(35) };
    const all = cleanObj({ ...(params || {}), ...sys });
    const prepared = sortedKeys(all).map((k) => `${k}=${all[k]}`).join('&');
    const sign = hmac('sha256', creds.apiSecret, md5(prepared).toUpperCase());
    const body = qs({ ...all, sign });
    const headers = { 'Content-Type': 'application/x-www-form-urlencoded', contentType: 'application/x-www-form-urlencoded', timestamp: sys.timestamp, signature_method: sys.signature_method, echostr: sys.echostr };
    return unwrap(await ctx.http('POST', base + path, { headers, body }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'lbank', name: 'LBank', type: 'spot', needsPassphrase: false, hosts: ['api.lbkex.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/v2/accuracy.do');
      return (d || []).map((s) => {
        const [b, q] = String(s.symbol).split('_');
        return mkMarket({ symbol: s.symbol, base: b, quote: q, tickSize: stepFromDecimals(num(s.priceAccuracy)), stepSize: stepFromDecimals(num(s.quantityAccuracy)), minQty: num(s.minTranQua) });
      });
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/v2/ticker/24hr.do', { symbol: 'all' });
      return (d || []).map((t) => ({ symbol: t.symbol, last: num(t.ticker && t.ticker.latest), changePct: num(t.ticker && t.ticker.change), quoteVol: num(t.ticker && t.ticker.turnover), high: num(t.ticker && t.ticker.high), low: num(t.ticker && t.ticker.low) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const iv = normInterval(interval), size = Math.min(limit || 300, 2000);
      const d = await pub(ctx, '/v2/kline.do', { symbol, size, type: IV[iv], time: Math.floor(ctx.now() / 1000) - IV_SEC[iv] * size });
      return (d || []).map((k) => [num(k[0]) * 1000, num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, '/v2/user_info.do', {});
      const free = (d && d.free) || {};
      const frozen = (d && d.freeze) || {};
      let balances;
      if (d && Array.isArray(d.balances)) balances = d.balances.map((b) => ({ asset: String(b.asset).toUpperCase(), free: num(b.free), locked: num(b.locked) }));
      else balances = Object.keys(free).map((k) => ({ asset: k.toUpperCase(), free: num(free[k]), locked: num(frozen[k]) }));
      return { balances: balances.filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      const sym = o.market.symbol;
      let params;
      if (o.type === 'limit') params = { symbol: sym, type: o.side, price: o.price, amount: o.qty };
      else if (o.side === 'buy') params = { symbol: sym, type: 'buy_market', price: o.quoteQty }; // خرید مارکت: price = مبلغ quote
      else params = { symbol: sym, type: 'sell_market', amount: o.qty };
      if (o.clientId) params.custom_id = o.clientId;
      const d = await call(ctx, creds, o.test ? '/v2/supplement/create_order_test.do' : '/v2/create_order.do', params);
      return { orderId: String((d && (d.order_id || d.orderId)) || ''), raw: d };
    },
  };
}

/* ================================== XT.com v4 ================================== */

function xt() {
  const base = 'https://sapi.xt.com';
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || (j.rc !== undefined && Number(j.rc) !== 0)) throw new ExchangeError((j && (j.mc || j.msg)) || 'خطای XT ' + r.status, { code: j && (j.rc !== undefined ? j.rc : j.mc), status: r.status, raw: j });
    return j.result;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const ts = String(ctx.now()), recv = '10000';
    const hdr = { 'xt-validate-algorithms': 'HmacSHA256', 'xt-validate-appkey': creds.apiKey, 'xt-validate-recvwindow': recv, 'xt-validate-timestamp': ts };
    const X = sortedKeys(hdr).map((k) => `${k}=${hdr[k]}`).join('&');
    const query = params ? sortedKeys(params).map((k) => `${k}=${params[k]}`).join('&') : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    let Y = '#' + method + '#' + path;
    if (query) Y += '#' + query;
    if (bodyStr) Y += '#' + bodyStr;
    const headers = { ...hdr, 'xt-validate-signature': hmac('sha256', creds.apiSecret, X + Y), 'Content-Type': 'application/json' };
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'xt', name: 'XT.com', type: 'spot', needsPassphrase: false, hosts: ['sapi.xt.com'],
    async markets(ctx) {
      const r = await pub(ctx, '/v4/public/symbol');
      return ((r && r.symbols) || []).map((s) => {
        let minNot = 0;
        (s.filters || []).forEach((f) => { if (f.filter === 'QUOTE_QTY' || f.filter === 'MIN_NOTIONAL') minNot = num(f.min); });
        return mkMarket({ symbol: s.symbol, base: s.baseCurrency, quote: s.quoteCurrency, trading: s.state === 'ONLINE' && s.tradingEnabled !== false, tickSize: stepFromDecimals(s.pricePrecision), stepSize: stepFromDecimals(s.quantityPrecision), minNotional: minNot });
      });
    },
    async tickers(ctx) {
      const r = await pub(ctx, '/v4/public/ticker/24h');
      return (Array.isArray(r) ? r : []).map((t) => ({ symbol: t.s, last: num(t.c), changePct: num(t.cr) * 100, quoteVol: num(t.q), high: num(t.h), low: num(t.l) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const r = await pub(ctx, '/v4/public/kline', { symbol, interval: normInterval(interval), limit: Math.min(limit || 300, 1000) });
      return (Array.isArray(r) ? r : []).map((k) => [num(k.t), num(k.o), num(k.h), num(k.l), num(k.c), num(k.v)]).sort((a, b) => a[0] - b[0]);
    },
    async balance(ctx, creds) {
      const r = await call(ctx, creds, 'GET', '/v4/balances', null);
      return { balances: ((r && r.assets) || []).map((x) => ({ asset: String(x.currency).toUpperCase(), free: num(x.availableAmount), locked: num(x.frozenAmount) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('XT حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { symbol: o.market.symbol, side: o.side.toUpperCase(), type: o.type.toUpperCase(), bizType: 'SPOT' };
      if (o.type === 'limit') { body.timeInForce = 'GTC'; body.price = o.price; body.quantity = o.qty; }
      else if (o.quoteQty) body.quoteQty = o.quoteQty;
      else body.quantity = o.qty;
      if (o.clientId) body.clientOrderId = o.clientId;
      const r = await call(ctx, creds, 'POST', '/v4/order', null, body);
      return { orderId: String((r && r.orderId) || ''), raw: r };
    },
  };
}

/* ======================== Bitunix (فیوچرز USDT-M) ======================== */

function bitunix() {
  const base = 'https://fapi.bitunix.com';
  const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || Number(j.code) !== 0) throw new ExchangeError((j && j.msg) || 'خطای Bitunix ' + r.status, { code: j && j.code, status: r.status, raw: j });
    return j.data;
  };
  /* امضا: digest = SHA256(nonce+timestamp+apiKey+query+body) ؛ sign = SHA256(digest+secret) */
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const nonce = rnd(32), ts = String(ctx.now());
    const p = cleanObj(params || {});
    const qSign = sortedKeys(p).map((k) => k + p[k]).join('');
    const bodyStr = body ? JSON.stringify(body) : '';
    const digest = sha256(nonce + ts + creds.apiKey + qSign + bodyStr);
    const headers = { 'api-key': creds.apiKey, nonce, timestamp: ts, sign: sha256(digest + creds.apiSecret), language: 'en-US', 'Content-Type': 'application/json' };
    const query = qs(p);
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'bitunix', name: 'Bitunix (Futures)', type: 'futures', needsPassphrase: false, hosts: ['fapi.bitunix.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v1/futures/market/trading_pairs');
      return (d || []).map((s) => mkMarket({
        symbol: s.symbol, base: s.base, quote: s.quote, type: 'futures', trading: String(s.symbolStatus || 'OPEN').toUpperCase() === 'OPEN',
        stepSize: stepFromDecimals(num(s.basePrecision)), tickSize: stepFromDecimals(num(s.quotePrecision)), minQty: num(s.minTradeVolume), maxLeverage: s.maxLeverage,
      }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v1/futures/market/tickers');
      return (d || []).map((t) => { const last = num(t.lastPrice || t.last), open = num(t.open); return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.quoteVol), high: num(t.high), low: num(t.low) }; });
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/api/v1/futures/market/kline', { symbol, interval: IV[normInterval(interval)], limit: Math.min(limit || 300, 200) });
      return (d || []).map((k) => [num(k.time), num(k.open), num(k.high), num(k.low), num(k.close), num(k.baseVol)]).sort((a, b) => a[0] - b[0]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v1/futures/account', { marginCoin: 'USDT' });
      const a = Array.isArray(d) ? d[0] : d;
      return { balances: a ? [{ asset: a.marginCoin || 'USDT', free: num(a.available), locked: num(a.frozen) + num(a.margin) }] : [], canTrade: true, equityExtra: a ? { crossUnrealizedPNL: num(a.crossUnrealizedPNL), isolationUnrealizedPNL: num(a.isolationUnrealizedPNL) } : null };
    },
    async setLeverage(ctx, creds, symbol, leverage, marginMode) {
      if (marginMode) await call(ctx, creds, 'POST', '/api/v1/futures/account/change_margin_mode', null, { symbol, marginCoin: 'USDT', marginMode: marginMode === 'cross' ? 'CROSS' : 'ISOLATION' });
      return call(ctx, creds, 'POST', '/api/v1/futures/account/change_leverage', null, { symbol, marginCoin: 'USDT', leverage: Number(leverage) });
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Bitunix حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      if (o.leverage) {
        try { await this.setLeverage(ctx, creds, o.market.symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw new ExchangeError('تنظیم اهرم ناموفق: ' + e.message, { code: e.exCode, raw: e.raw }); }
      }
      const body = { symbol: o.market.symbol, qty: o.qty, side: o.side === 'buy' ? 'BUY' : 'SELL', tradeSide: o.reduceOnly ? 'CLOSE' : 'OPEN', orderType: o.type === 'limit' ? 'LIMIT' : 'MARKET', clientId: o.clientId || rnd(24) };
      if (o.type === 'limit') { body.price = o.price; body.effect = 'GTC'; }
      if (o.sl > 0) { body.slPrice = floorToStep(o.sl, o.market.tickSize); body.slStopType = 'MARK_PRICE'; body.slOrderType = 'MARKET'; }
      if (o.tp > 0) { body.tpPrice = floorToStep(o.tp, o.market.tickSize); body.tpStopType = 'MARK_PRICE'; body.tpOrderType = 'MARKET'; }
      const d = await call(ctx, creds, 'POST', '/api/v1/futures/trade/place_order', null, body);
      return { orderId: String((d && d.orderId) || ''), nativeProtection: !!(o.sl > 0 || o.tp > 0), raw: d };
    },
    async positions(ctx, creds, symbol) {
      const d = await call(ctx, creds, 'GET', '/api/v1/futures/position/get_pending_positions', symbol ? { symbol } : {});
      return (d || []).map((p) => ({ positionId: String(p.positionId), symbol: p.symbol, side: String(p.side).toLowerCase() === 'buy' ? 'long' : 'short', qty: num(p.qty), entry: num(p.avgOpenPrice), leverage: num(p.leverage), margin: num(p.margin), pnl: num(p.unrealizedPNL), liqPrice: num(p.liqPrice) }));
    },
    async closePosition(ctx, creds, positionId) {
      const d = await call(ctx, creds, 'POST', '/api/v1/futures/trade/flash_close_position', null, { positionId: String(positionId) });
      return { raw: d };
    },
    async openOrders(ctx, creds, symbol) {
      const d = await call(ctx, creds, 'GET', '/api/v1/futures/trade/get_pending_orders', symbol ? { symbol } : {});
      const list = (d && (d.orderList || d)) || [];
      return (Array.isArray(list) ? list : []).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: String(x.side).toLowerCase(), type: String(x.orderType || '').toLowerCase(), price: num(x.price), qty: num(x.qty), filled: num(x.tradeQty), status: x.status }));
    },
    async cancelOrder(ctx, creds, symbol, orderId) {
      const d = await call(ctx, creds, 'POST', '/api/v1/futures/trade/cancel_orders', null, { symbol, orderList: [{ orderId: String(orderId) }] });
      return { orderId: String(orderId), raw: d };
    },
  };
}

/* -------------------------------- رجیستری -------------------------------- */

const CONNECTORS = {
  binance: binanceLike({ id: 'binance', name: 'Binance', base: 'https://api.binance.com', headerName: 'X-MBX-APIKEY', ivMap: BINANCE_IV }),
  mexc: binanceLike({ id: 'mexc', name: 'MEXC', base: 'https://api.mexc.com', headerName: 'X-MEXC-APIKEY', ivMap: MEXC_IV, mexc: true }),
  bybit: bybit(),
  okx: okx(),
  kucoin: kucoin(),
  gate: gate(),
  bitget: bitget(),
  lbank: lbank(),
  xt: xt(),
  bitunix: bitunix(),
};

const ALL_HOSTS = [...new Set(Object.values(CONNECTORS).flatMap((c) => c.hosts))];

const listExchanges = () => Object.values(CONNECTORS).map((c) => ({
  id: c.id, name: c.name, type: c.type, needsPassphrase: !!c.needsPassphrase,
  features: { protect: typeof c.protect === 'function', positions: typeof c.positions === 'function', orders: typeof c.openOrders === 'function', test: ['binance', 'mexc', 'kucoin', 'lbank'].includes(c.id) },
}));

module.exports = { CONNECTORS, ALL_HOSTS, listExchanges, ExchangeError, prepareOrder, floorToStep, decimalsOf, stepFromDecimals, hmac, md5, sha256, sha512 };
