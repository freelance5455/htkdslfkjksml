'use strict';
/**
 * ترید یار — کانکتورهای فیوچرز USDT-M (دائمی): Bitget, LBank, XT
 * قرارداد مثل bitunix() در exchanges.js است؛ همهٔ مقدارها (qty) در اپ بر حسب «کوین پایه» است
 * و تبدیل به واحد صرافی (قرارداد/لات) درون کانکتور انجام می‌شود.
 * استفاده: const { bitget, lbank, xt } = require('./futures-c')(H)
 */
module.exports = function build(H) {
  const { ExchangeError, hmac, md5, num, rnd, cleanObj, qs, sortedKeys, decimalsOf, stepFromDecimals, floorToStep, mkMarket, normInterval, IV_SEC, need } = H;
  const r12 = (x) => Number(Number(x).toPrecision(12));
  const arr = (x) => (Array.isArray(x) ? x : []);
  const isUsdt = (s) => String(s || '').toUpperCase() === 'USDT';
  const failLev = (e) => new ExchangeError('تنظیم اهرم ناموفق: ' + e.message, { code: e.exCode, raw: e.raw });
  const tsCache = () => { const m = new Map(); return { get: (k, now, ttl) => { const v = m.get(k); return v && now - v.t < ttl ? v.d : undefined; }, set: (k, d, now) => m.set(k, { t: now, d }) }; };

  /* ================================ Bitget (mix v2) ================================ */
  function bitget() {
    const base = 'https://api.bitget.com', PT = 'USDT-FUTURES';
    const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '00000') throw new ExchangeError((j && j.msg) || 'خطای Bitget ' + r.status, { code: j && j.code, status: r.status, raw: j });
      return j.data;
    };
    /* امضا: base64(HMAC-SHA256(ts + METHOD + path + ?query + body)) */
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = String(ctx.now());
      const query = params ? qs(params) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const headers = {
        'ACCESS-KEY': creds.apiKey, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json', locale: 'en-US',
        'ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + path + (query ? '?' + query : '') + bodyStr, 'base64'),
      };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const modes = tsCache();
    /* حالت پوزیشن حساب: hedge_mode | one_way_mode (پیش‌فرض hedge) */
    const posMode = async (ctx, creds, symbol) => {
      const k = creds.apiKey, c = modes.get(k, ctx.now(), 600000);
      if (c) return c;
      let m = 'hedge_mode';
      try {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/account', { symbol, productType: PT, marginCoin: 'USDT' });
        if (d && d.posMode) m = d.posMode;
      } catch { /* پیش‌فرض */ }
      modes.set(k, m, ctx.now());
      return m;
    };
    const self = {
      id: 'bitget_futures', name: 'Bitget Futures', type: 'futures', needsPassphrase: true, hosts: ['api.bitget.com'],
      async markets(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/contracts', { productType: PT });
        return arr(d).filter((s) => String(s.quoteCoin).toUpperCase() === 'USDT' && String(s.symbolType || 'perpetual').toLowerCase() === 'perpetual').map((s) => mkMarket({
          symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: String(s.symbolStatus || 'normal').toLowerCase() === 'normal',
          tickSize: r12(num(s.priceEndStep || 1) * stepFromDecimals(num(s.pricePlace))), stepSize: num(s.sizeMultiplier) || stepFromDecimals(num(s.volumePlace)),
          minQty: num(s.minTradeNum), minNotional: num(s.minTradeUSDT), maxLeverage: s.maxLever,
        }));
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/tickers', { productType: PT });
        return arr(d).map((t) => ({ symbol: t.symbol, last: num(t.lastPr), changePct: num(t.change24h) * 100, quoteVol: num(t.usdtVolume || t.quoteVolume), high: num(t.high24h), low: num(t.low24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const d = await pub(ctx, '/api/v2/mix/market/candles', { symbol, productType: PT, granularity: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
        return arr(d).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/accounts', { productType: PT });
        const a = arr(d).find((x) => isUsdt(x.marginCoin)) || arr(d)[0];
        return { balances: a ? [{ asset: 'USDT', free: num(a.available), locked: num(a.locked) }] : [], canTrade: true, equityExtra: a ? { unrealizedPL: num(a.unrealizedPL), accountEquity: num(a.accountEquity) } : null };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) await call(ctx, creds, 'POST', '/api/v2/mix/account/set-margin-mode', null, { symbol, productType: PT, marginCoin: 'USDT', marginMode: marginMode === 'cross' ? 'crossed' : 'isolated' });
        return call(ctx, creds, 'POST', '/api/v2/mix/account/set-leverage', null, { symbol, productType: PT, marginCoin: 'USDT', leverage: String(Number(leverage)) });
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Bitget حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const symbol = o.market.symbol;
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw failLev(e); }
        }
        const hedge = (await posMode(ctx, creds, symbol)) !== 'one_way_mode';
        const body = { symbol, productType: PT, marginMode: o.marginMode === 'cross' ? 'crossed' : 'isolated', marginCoin: 'USDT', size: String(o.qty), orderType: o.type === 'limit' ? 'limit' : 'market', clientOid: o.clientId || rnd(24) };
        if (hedge) {
          // هج‌مود: در بستن، side جهت «پوزیشن» است (بستن لانگ = buy/close)
          body.side = o.reduceOnly ? (o.side === 'buy' ? 'sell' : 'buy') : o.side;
          body.tradeSide = o.reduceOnly ? 'close' : 'open';
        } else {
          body.side = o.side;
          if (o.reduceOnly) body.reduceOnly = 'YES';
        }
        if (o.type === 'limit') { body.price = o.price; body.force = 'gtc'; }
        let prot = false;
        if (!o.reduceOnly) {
          if (o.sl > 0) { body.presetStopLossPrice = floorToStep(o.sl, o.market.tickSize); prot = true; }
          if (o.tp > 0) { body.presetStopSurplusPrice = floorToStep(o.tp, o.market.tickSize); prot = true; }
        }
        const d = await call(ctx, creds, 'POST', '/api/v2/mix/order/place-order', null, body);
        return { orderId: String((d && d.orderId) || ''), nativeProtection: prot, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
        return arr(d).filter((p) => !symbol || p.symbol === symbol).filter((p) => num(p.total) > 0).map((p) => {
          const side = String(p.holdSide).toLowerCase() === 'short' ? 'short' : 'long';
          return { positionId: `${p.symbol}|${side}`, symbol: p.symbol, side, qty: num(p.total), entry: num(p.openPriceAvg), leverage: num(p.leverage), margin: num(p.marginSize), pnl: num(p.unrealizedPL), liqPrice: num(p.liquidationPrice), _available: num(p.available) };
        }).map(({ _available, ...x }) => x);
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
        const p = arr(d).find((x) => x.symbol === symbol && String(x.holdSide).toLowerCase() === side && num(x.total) > 0);
        if (!p) throw new ExchangeError('پوزیشن پیدا نشد', { code: 'no_position' });
        const hedge = (await posMode(ctx, creds, symbol)) !== 'one_way_mode';
        const body = { symbol, productType: PT, marginMode: String(p.marginMode || 'crossed').toLowerCase().startsWith('iso') ? 'isolated' : 'crossed', marginCoin: 'USDT', size: String(p.available && num(p.available) > 0 ? p.available : p.total), orderType: 'market', clientOid: rnd(24) };
        if (hedge) { body.side = side === 'long' ? 'buy' : 'sell'; body.tradeSide = 'close'; } else { body.side = side === 'long' ? 'sell' : 'buy'; body.reduceOnly = 'YES'; }
        const r = await call(ctx, creds, 'POST', '/api/v2/mix/order/place-order', null, body);
        return { raw: r };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/order/orders-pending', { productType: PT, symbol });
        const list = (d && d.entrustedList) || [];
        return arr(list).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: String(x.side).toLowerCase(), type: String(x.orderType || '').toLowerCase(), price: num(x.price), qty: num(x.size), filled: num(x.baseVolume), status: x.status }));
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/api/v2/mix/order/cancel-order', null, { symbol, productType: PT, orderId: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  /* ================================ XT.com (fapi) ================================ */
  function xt() {
    const base = 'https://fapi.xt.com';
    const unwrap = (r) => {
      const j = r.json;
      const code = j && (j.returnCode !== undefined ? j.returnCode : j.rc);
      if (r.status >= 400 || !j || (code !== undefined && Number(code) !== 0)) throw new ExchangeError((j && (j.msgInfo || j.mc || j.msg)) || 'خطای XT ' + r.status, { code: j && (code !== undefined ? code : j.mc), status: r.status, raw: j });
      return j.result;
    };
    /* امضا: X = هدرهای validate (مرتب) ، Y = #METHOD#path#query#body ؛ sign = HMAC-SHA256(X+Y) */
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(ctx.now()), recv = '10000';
      const hdr = { 'xt-validate-algorithms': 'HmacSHA256', 'xt-validate-appkey': creds.apiKey, 'xt-validate-recvwindow': recv, 'xt-validate-timestamp': ts };
      const X = sortedKeys(hdr).map((k) => `${k}=${hdr[k]}`).join('&');
      const query = params ? sortedKeys(params).map((k) => `${k}=${params[k]}`).join('&') : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      let Y = '#' + method + '#' + path;
      if (query) Y += '#' + query;
      if (bodyStr) Y += '#' + bodyStr;
      const headers = { ...hdr, 'xt-validate-signature': hmac('sha256', creds.apiSecret, X + Y), 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const lc = (s) => String(s || '').toLowerCase();
    const cache = tsCache();
    const rawContracts = async (ctx) => {
      const c = cache.get('c', ctx.now(), 600000);
      if (c) return c;
      const r = await pub(ctx, '/future/market/v1/public/symbol/list');
      const list = Array.isArray(r) ? r : arr(r && (r.symbols || r.items));
      const d = list.filter((s) => lc(s.contractType || 'perpetual') === 'perpetual' && lc(s.quoteCoin) === 'usdt' && lc(s.underlyingType || 'u_based') !== 'coin_based');
      cache.set('c', d, ctx.now());
      return d;
    };
    const meta = async (ctx, symbol) => {
      const s = (await rawContracts(ctx)).find((x) => lc(x.symbol) === lc(symbol));
      if (!s) throw new ExchangeError('جفت‌ارز در XT فیوچرز پیدا نشد', { code: 'unknown_symbol' });
      return { cs: num(s.contractSize) || 1, stepC: stepFromDecimals(num(s.quantityPrecision) || 0) || 1 };
    };
    const IVX = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
    const self = {
      id: 'xt_futures', name: 'XT Futures', type: 'futures', needsPassphrase: false, hosts: ['fapi.xt.com'],
      async markets(ctx) {
        const list = await rawContracts(ctx);
        return list.map((s) => {
          const cs = num(s.contractSize) || 1, stepC = stepFromDecimals(num(s.quantityPrecision) || 0) || 1;
          return mkMarket({
            symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: s.tradeSwitch !== false && s.openSwitch !== false,
            tickSize: num(s.minStepPrice) || stepFromDecimals(num(s.pricePrecision)), stepSize: r12(cs * stepC), minQty: r12(num(s.minQty || 1) * cs), minNotional: num(s.minNotional),
            maxLeverage: s.maxLeverage || s.leverageMax,
          });
        });
      },
      async tickers(ctx) {
        const r = await pub(ctx, '/future/market/v1/public/q/tickers');
        return arr(r).map((t) => { const last = num(t.c), open = num(t.o); return { symbol: t.s, last, changePct: open > 0 ? ((last - open) / open) * 100 : num(t.r) * 100, quoteVol: num(t.v), high: num(t.h), low: num(t.l) }; });
      },
      async klines(ctx, symbol, interval, limit) {
        const { cs } = await meta(ctx, symbol);
        const r = await pub(ctx, '/future/market/v1/public/q/kline', { symbol, interval: IVX[normInterval(interval)], limit: Math.min(limit || 300, 500) });
        return arr(r).map((k) => [num(k.t), num(k.o), num(k.h), num(k.l), num(k.c), r12(num(k.a) * cs)]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const r = await call(ctx, creds, 'GET', '/future/user/v1/balance/detail', { coin: 'usdt' });
        const a = Array.isArray(r) ? r.find((x) => lc(x.coin) === 'usdt') || r[0] : r;
        if (!a) return { balances: [], canTrade: true };
        const free = num(a.availableBalance), wallet = num(a.walletBalance);
        const locked = a.openOrderMarginFrozen !== undefined || a.isolatedMargin !== undefined || a.crossedMargin !== undefined ? num(a.openOrderMarginFrozen) + num(a.isolatedMargin) + num(a.crossedMargin) : Math.max(0, wallet - free);
        return { balances: [{ asset: 'USDT', free, locked }], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) await call(ctx, creds, 'POST', '/future/user/v1/position/change-type', null, { symbol, positionType: marginMode === 'cross' ? 'CROSSED' : 'ISOLATED' });
        const res = [];
        for (const positionSide of ['LONG', 'SHORT']) res.push(await call(ctx, creds, 'POST', '/future/user/v1/position/adjust-leverage', null, { symbol, positionSide, leverage: Number(leverage) }));
        return res;
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('XT حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const symbol = o.market.symbol;
        const { cs, stepC } = await meta(ctx, symbol);
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw failLev(e); }
        }
        const contracts = floorToStep(Number(o.qty) / cs, stepC);
        if (!(Number(contracts) > 0)) throw new ExchangeError('حجم کمتر از یک قرارداد است', { code: 'below_step' });
        // جهت پوزیشن: باز کردن buy=LONG ؛ بستن sell=LONG
        const positionSide = (o.side === 'buy') !== !!o.reduceOnly ? 'LONG' : 'SHORT';
        const body = { symbol, orderSide: o.side.toUpperCase(), orderType: o.type === 'limit' ? 'LIMIT' : 'MARKET', origQty: contracts, positionSide, clientOrderId: o.clientId || rnd(24) };
        if (o.type === 'limit') { body.price = o.price; body.timeInForce = 'GTC'; }
        let prot = false;
        if (!o.reduceOnly) {
          if (o.sl > 0) { body.triggerStopPrice = floorToStep(o.sl, o.market.tickSize); prot = true; }
          if (o.tp > 0) { body.triggerProfitPrice = floorToStep(o.tp, o.market.tickSize); prot = true; }
        }
        const r = await call(ctx, creds, 'POST', '/future/trade/v1/order/create', null, body);
        return { orderId: String((r && typeof r === 'object' ? r.orderId : r) || ''), nativeProtection: prot, raw: r };
      },
      async positions(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/future/user/v1/position/list', symbol ? { symbol } : {});
        const list = Array.isArray(r) ? r : arr(r && r.items);
        const out = [];
        for (const p of list.filter((x) => num(x.positionSize) > 0)) {
          let cs = 1;
          try { cs = (await meta(ctx, p.symbol)).cs; } catch { /* ناشناخته */ }
          const side = lc(p.positionSide) === 'short' ? 'short' : 'long';
          out.push({ positionId: `${p.symbol}|${side}`, symbol: p.symbol, side, qty: r12(num(p.positionSize) * cs), entry: num(p.entryPrice), leverage: num(p.leverage), margin: num(p.isolatedMargin || p.margin), pnl: num(p.unrealizedProfit), liqPrice: num(p.liquidationPrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const r = await call(ctx, creds, 'GET', '/future/user/v1/position/list', { symbol });
        const list = Array.isArray(r) ? r : arr(r && r.items);
        const p = list.find((x) => x.symbol === symbol && lc(x.positionSide) === side && num(x.positionSize) > 0);
        if (!p) throw new ExchangeError('پوزیشن پیدا نشد', { code: 'no_position' });
        const size = num(p.availableCloseSize) > 0 ? p.availableCloseSize : p.positionSize;
        const body = { symbol, orderSide: side === 'long' ? 'SELL' : 'BUY', orderType: 'MARKET', origQty: String(size), positionSide: side.toUpperCase(), clientOrderId: rnd(24) };
        return { raw: await call(ctx, creds, 'POST', '/future/trade/v1/order/create', null, body) };
      },
      async openOrders(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/future/trade/v1/order/list', cleanObj({ symbol, state: 'NEW' }));
        const list = Array.isArray(r) ? r : arr(r && (r.items || r.list));
        const out = [];
        for (const x of list) {
          let cs = 1;
          try { cs = (await meta(ctx, x.symbol)).cs; } catch { /* ناشناخته */ }
          out.push({ orderId: String(x.orderId), symbol: x.symbol, side: lc(x.orderSide), type: lc(x.orderType), price: num(x.price), qty: r12(num(x.origQty) * cs), filled: r12(num(x.executedQty) * cs), status: x.state });
        }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/future/trade/v1/order/cancel', null, { orderId: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  /* ================================ LBank (lbkperp) ================================ */
  function lbank() {
    const base = 'https://lbkperp.lbank.com', PG = 'SwapU';
    const IV = { '1m': 'minute1', '5m': 'minute5', '15m': 'minute15', '30m': 'minute30', '1h': 'hour1', '4h': 'hour4', '1d': 'day1', '1w': 'week1' };
    // مقادیر enum سفارش (طبق مستندات؛ در صورت تغییر اینجا اصلاح شود)
    const ENUM = { open: '0', close: '1', limit: '0', market: '4', orig: '0' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || (j.result !== undefined && String(j.result) !== 'true') || (j.error_code !== undefined && Number(j.error_code) !== 0)) throw new ExchangeError('خطای LBank (کد ' + ((j && j.error_code) || r.status) + ')' + (j && j.msg ? ': ' + j.msg : ''), { code: j && j.error_code, status: r.status, raw: j });
      return j.data;
    };
    /* امضا: همهٔ پارامترها + api_key/signature_method/timestamp/echostr ، مرتب → MD5 بزرگ → HmacSHA256(hex) ؛ GET: query ، POST: بدنهٔ JSON */
    const call = async (ctx, creds, method, path, params) => {
      need(creds, 'apiKey', 'apiSecret');
      const sys = { signature_method: 'HmacSHA256', timestamp: String(ctx.now()), echostr: rnd(35) };
      const all = cleanObj({ ...(params || {}), api_key: creds.apiKey, ...sys });
      const prepared = sortedKeys(all).map((k) => `${k}=${all[k]}`).join('&');
      const sign = hmac('sha256', creds.apiSecret, md5(prepared).toUpperCase());
      const headers = { 'Content-Type': 'application/json', timestamp: sys.timestamp, signature_method: sys.signature_method, echostr: sys.echostr };
      const full = { ...all, sign };
      if (method === 'GET') return unwrap(await ctx.http('GET', `${base}${path}?${qs(full)}`, { headers }));
      return unwrap(await ctx.http(method, base + path, { headers, body: JSON.stringify(full) }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const cache = tsCache();
    const rawInstruments = async (ctx) => {
      const c = cache.get('i', ctx.now(), 600000);
      if (c) return c;
      const d = arr(await pub(ctx, '/cfd/openApi/v1/pub/instrument', { productGroup: PG })).filter((s) => !s.clearCurrency || isUsdt(s.clearCurrency));
      cache.set('i', d, ctx.now());
      return d;
    };
    const mult = (s) => num(s.volumeMultiple) || 1;
    const meta = async (ctx, symbol) => {
      const s = (await rawInstruments(ctx)).find((x) => x.symbol === symbol);
      if (!s) throw new ExchangeError('جفت‌ارز در LBank فیوچرز پیدا نشد', { code: 'unknown_symbol' });
      return { vm: mult(s), vt: num(s.volumeTick) || 1 };
    };
    const longSide = (v) => ['BUY', 'LONG', '2'].includes(String(v).toUpperCase());
    const self = {
      id: 'lbank_futures', name: 'LBank Futures', type: 'futures', needsPassphrase: false, hosts: ['lbkperp.lbank.com'],
      async markets(ctx) {
        return (await rawInstruments(ctx)).map((s) => {
          const vm = mult(s);
          return mkMarket({
            symbol: s.symbol, base: s.baseCurrency, quote: s.clearCurrency || s.priceCurrency || 'USDT', type: 'futures',
            trading: s.isTrading === undefined ? !/suspend|delist|halt|stop/i.test(String(s.status || s.state || '')) : !!s.isTrading,
            tickSize: num(s.priceTick), stepSize: r12((num(s.volumeTick) || 1) * vm), minQty: r12(num(s.minOrderVolume) * vm), maxLeverage: s.maxLeverage || s.leverageMax,
          });
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/cfd/openApi/v1/pub/marketData', { productGroup: PG });
        return arr(d).map((t) => { const last = num(t.lastPrice), open = num(t.openPrice); return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.turnover), high: num(t.highestPrice), low: num(t.lowestPrice) }; });
      },
      async klines(ctx, symbol, interval, limit) {
        const iv = normInterval(interval), size = Math.min(limit || 300, 2000);
        const { vm } = await meta(ctx, symbol);
        const d = await pub(ctx, '/cfd/openApi/v1/pub/kline', { symbol, size, type: IV[iv], startTime: Math.floor(ctx.now() / 1000) - IV_SEC[iv] * size });
        const t = (k) => { const x = num(k.time !== undefined ? k.time : k.t !== undefined ? k.t : k[0]); return x < 1e12 ? x * 1000 : x; };
        return arr(d).map((k) => Array.isArray(k)
          ? [t(k), num(k[1]), num(k[2]), num(k[3]), num(k[4]), r12(num(k[5]) * vm)]
          : [t(k), num(k.open), num(k.high), num(k.low), num(k.close), r12(num(k.volume) * vm)]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/cfd/openApi/v1/prv/account', { asset: 'USDT', productGroup: PG });
        const a = Array.isArray(d) ? d.find((x) => isUsdt(x.asset)) || d[0] : d;
        if (!a) return { balances: [], canTrade: true };
        const total = num(a.balance), free = num(a.available !== undefined ? a.available : a.availableBalance);
        return { balances: [{ asset: 'USDT', free, locked: Math.max(0, total - free) }], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        return call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/setLeverage', { symbol, productGroup: PG, leverage: Number(leverage), positionType: marginMode === 'cross' ? '1' : marginMode ? '2' : undefined });
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('LBank حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const symbol = o.market.symbol;
        const { vm, vt } = await meta(ctx, symbol);
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw failLev(e); }
        }
        const lots = floorToStep(Number(o.qty) / vm, vt);
        if (!(Number(lots) > 0)) throw new ExchangeError('حجم کمتر از حداقل قرارداد است', { code: 'below_step' });
        const body = { symbol, volume: lots, side: o.side === 'buy' ? 'BUY' : 'SELL', offsetFlag: o.reduceOnly ? ENUM.close : ENUM.open, orderPriceType: o.type === 'limit' ? ENUM.limit : ENUM.market, origType: ENUM.orig, clientOrderId: o.clientId || rnd(24) };
        if (o.type === 'limit') body.price = o.price;
        const d = await call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/placeOrder', body);
        return { orderId: String((d && (d.orderSysID || d.orderId || d.orderSysId)) || ''), nativeProtection: false, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/cfd/openApi/v1/prv/position', cleanObj({ productGroup: PG, symbol }));
        const list = Array.isArray(d) ? d : arr(d && (d.positionList || d.list));
        const out = [];
        for (const p of list.filter((x) => num(x.volume || x.position) > 0)) {
          let vm = 1;
          try { vm = (await meta(ctx, p.symbol)).vm; } catch { /* ناشناخته */ }
          const side = longSide(p.side || p.direction || p.posiDirection || p.positionSide) ? 'long' : 'short';
          out.push({ positionId: `${p.symbol}|${side}`, symbol: p.symbol, side, qty: r12(num(p.volume || p.position) * vm), entry: num(p.openPrice || p.avgPrice), leverage: num(p.leverage), margin: num(p.positionMargin || p.margin), pnl: num(p.unrealizedProfit || p.unrealisedPnl || p.floatProfit), liqPrice: num(p.liquidationPrice || p.liqPrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const ps = await self.positions(ctx, creds, symbol);
        const p = ps.find((x) => x.symbol === symbol && x.side === side);
        if (!p) throw new ExchangeError('پوزیشن پیدا نشد', { code: 'no_position' });
        const { vm } = await meta(ctx, symbol);
        const body = { symbol, volume: String(r12(p.qty / vm)), side: side === 'long' ? 'SELL' : 'BUY', offsetFlag: ENUM.close, orderPriceType: ENUM.market, origType: ENUM.orig, clientOrderId: rnd(24) };
        return { raw: await call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/placeOrder', body) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/cfd/openApi/v1/prv/orderList', cleanObj({ productGroup: PG, symbol }));
        const list = Array.isArray(d) ? d : arr(d && (d.orderList || d.list));
        const out = [];
        for (const x of list) {
          let vm = 1;
          try { vm = (await meta(ctx, x.symbol)).vm; } catch { /* ناشناخته */ }
          out.push({ orderId: String(x.orderSysID || x.orderId), symbol: x.symbol, side: String(x.side || '').toLowerCase(), type: Number(x.orderPriceType) === Number(ENUM.market) ? 'market' : 'limit', price: num(x.price), qty: r12(num(x.volume) * vm), filled: r12(num(x.tradeVolume || x.volumeTraded) * vm), status: x.orderStatus || x.status });
        }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/cancelOrder', { symbol, orderSysID: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  return { bitget: bitget(), lbank: lbank(), xt: xt() };
};
