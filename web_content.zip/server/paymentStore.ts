import fs from 'fs';
import path from 'path';

export interface PaymentOrder {
  orderId: string;
  userId: string;
  userName: string;
  userPhone?: string;
  userEmail?: string;
  plan: 'monthly' | 'yearly';
  amount: number;
  currency: 'INR';
  paymentMethod: 'upi' | 'card' | 'netbanking';
  transactionId?: string;
  cardLast4?: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  createdAt: string;
  verifiedAt?: string;
  expiresAt?: string;
}

const DATA_DIR = path.join(process.cwd(), 'server', 'data');
const PAYMENTS_FILE = path.join(DATA_DIR, 'subscription_payments.json');

// In-memory payment store
let paymentOrders: PaymentOrder[] = [];

// Initialize file store
export function initPaymentStore() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(PAYMENTS_FILE)) {
      const raw = fs.readFileSync(PAYMENTS_FILE, 'utf-8');
      paymentOrders = JSON.parse(raw);
    } else {
      paymentOrders = [];
      fs.writeFileSync(PAYMENTS_FILE, JSON.stringify(paymentOrders, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Error initializing payment store:', err);
    paymentOrders = [];
  }
}

function persistPayments() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(PAYMENTS_FILE, JSON.stringify(paymentOrders, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error persisting payments:', err);
  }
}

export function createPaymentOrder(params: {
  userId: string;
  userName: string;
  userPhone?: string;
  userEmail?: string;
  plan: 'monthly' | 'yearly';
  amount: number;
  currency: 'INR';
  paymentMethod: 'upi' | 'card' | 'netbanking';
}): PaymentOrder {
  const timestamp = Date.now();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const orderId = `EDUPRO-${timestamp.toString().slice(-6)}-${randomSuffix}`;

  const order: PaymentOrder = {
    orderId,
    userId: params.userId || 'guest_user',
    userName: params.userName || 'Student',
    userPhone: params.userPhone,
    userEmail: params.userEmail,
    plan: params.plan,
    amount: params.amount,
    currency: params.currency || 'INR',
    paymentMethod: params.paymentMethod,
    status: 'PENDING',
    createdAt: new Date().toISOString(),
  };

  paymentOrders.unshift(order);
  persistPayments();
  return order;
}

export function verifyAndActivatePayment(params: {
  orderId?: string;
  userId: string;
  userName: string;
  plan: 'monthly' | 'yearly';
  amount: number;
  currency: 'INR';
  paymentMethod: 'upi' | 'card' | 'netbanking';
  transactionId: string;
  userPhone?: string;
  cardLast4?: string;
}): { success: boolean; order?: PaymentOrder; error?: string } {
  const trx = (params.transactionId || '').trim();

  // Strict Validation: Transaction ID or OTP must not be empty and must be authentic
  if (!trx || trx.length < 4) {
    return {
      success: false,
      error: 'অনুগ্রহ করে সঠিক Transaction ID বা পেমেন্ট রেফারেন্স নম্বর প্রদান করুন।'
    };
  }

  // Calculate validity period
  const durationDays = params.plan === 'yearly' ? 365 : 30;
  const expiryDate = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString();
  const now = new Date().toISOString();

  let order: PaymentOrder | undefined;

  if (params.orderId) {
    order = paymentOrders.find((o) => o.orderId === params.orderId);
  }

  if (order) {
    order.status = 'SUCCESS';
    order.transactionId = trx;
    order.verifiedAt = now;
    order.expiresAt = expiryDate;
    if (params.cardLast4) order.cardLast4 = params.cardLast4;
  } else {
    // Create completed order
    const timestamp = Date.now();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderId = params.orderId || `EDUPRO-${timestamp.toString().slice(-6)}-${randomSuffix}`;

    order = {
      orderId,
      userId: params.userId,
      userName: params.userName,
      userPhone: params.userPhone,
      plan: params.plan,
      amount: params.amount,
      currency: params.currency,
      paymentMethod: params.paymentMethod,
      transactionId: trx,
      cardLast4: params.cardLast4,
      status: 'SUCCESS',
      createdAt: now,
      verifiedAt: now,
      expiresAt: expiryDate,
    };
    paymentOrders.unshift(order);
  }

  persistPayments();
  return { success: true, order };
}

export function getUserActiveSubscription(userId: string): PaymentOrder | null {
  const userOrders = paymentOrders.filter(
    (o) => o.userId === userId && o.status === 'SUCCESS' && o.expiresAt
  );

  if (userOrders.length === 0) return null;

  // Find latest non-expired subscription
  const now = new Date().toISOString();
  const activeOrder = userOrders.find((o) => o.expiresAt && o.expiresAt > now);
  return activeOrder || null;
}

export function deactivateSubscription(userId?: string, orderId?: string): boolean {
  let changed = false;
  paymentOrders = paymentOrders.map((o) => {
    if ((orderId && o.orderId === orderId) || (userId && o.userId === userId) || (!orderId && !userId)) {
      changed = true;
      return {
        ...o,
        status: 'FAILED',
        expiresAt: new Date(Date.now() - 1000).toISOString(),
      };
    }
    return o;
  });
  if (changed) {
    persistPayments();
  }
  return true;
}

export function getAllPaymentsAdmin(): PaymentOrder[] {
  return [...paymentOrders];
}
