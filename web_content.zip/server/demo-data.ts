export const demoOverview = {
  dataMode: "DEMO" as const,
  updatedAt: "2026-11-03T18:00:00.000Z",
  users: { total: 24860, dau: 3240, mau: 11840, newToday: 42, growthPercent: 8.4 },
  premium: { subscribers: 2864, monthlyRevenueUsd: 8420, changePercent: 6.2 },
  ads: { revenueMtdUsd: 2175, changePercent: 3.7, impressionsMtd: 184300 },
  registrations: [
    { date: "Oct 28", count: 87 }, { date: "Oct 29", count: 96 }, { date: "Oct 30", count: 105 },
    { date: "Oct 31", count: 98 }, { date: "Nov 01", count: 121 }, { date: "Nov 02", count: 116 }, { date: "Nov 03", count: 142 },
  ],
  monthlyGrowth: [
    { month: "May", users: 14820 }, { month: "Jun", users: 16210 }, { month: "Jul", users: 17860 },
    { month: "Aug", users: 19620 }, { month: "Sep", users: 21330 }, { month: "Oct", users: 22950 }, { month: "Nov", users: 24860 },
  ],
  revenueTrend: [
    { month: "May", premium: 6100, ads: 1580 }, { month: "Jun", premium: 6500, ads: 1710 },
    { month: "Jul", premium: 6830, ads: 1820 }, { month: "Aug", premium: 7210, ads: 1930 },
    { month: "Sep", premium: 7690, ads: 2010 }, { month: "Oct", premium: 7930, ads: 2098 },
    { month: "Nov", premium: 8420, ads: 2175 },
  ],
};

export const demoIncidents = [
  { id: "CR-2048", title: "Reminder delivery delay", category: "Notifications", severity: "medium", status: "investigating", affectedSessions: 18, createdAt: "2026-11-03T16:40:00.000Z" },
  { id: "CR-2047", title: "Android startup crash", category: "Stability", severity: "high", status: "monitoring", affectedSessions: 7, createdAt: "2026-11-03T11:12:00.000Z" },
  { id: "CR-2046", title: "Slow monthly report response", category: "Performance", severity: "low", status: "resolved", affectedSessions: 31, createdAt: "2026-11-02T14:20:00.000Z" },
];

export const demoSupport = [
  { id: "TKT-7314", topic: "Reminder settings", excerpt: "A reminder preference is not saving after an app update.", category: "How-to", status: "open", receivedAt: "2026-11-03T17:22:00.000Z" },
  { id: "TKT-7313", topic: "Language display", excerpt: "One screen still shows a fallback translation.", category: "Localization", status: "triaged", receivedAt: "2026-11-03T15:08:00.000Z" },
  { id: "TKT-7312", topic: "Premium restore", excerpt: "The restore-purchase action did not finish on this device.", category: "Subscription", status: "open", receivedAt: "2026-11-03T12:45:00.000Z" },
  { id: "FDB-918", topic: "Calendar improvement", excerpt: "A compact agenda view would be helpful on smaller screens.", category: "Suggestion", status: "review", receivedAt: "2026-11-02T19:10:00.000Z" },
];

export const demoUsage = {
  dataMode: "DEMO" as const,
  period: "November 2026",
  apiRequests: 1840000,
  storageGb: 42.8,
  databaseGb: 6.4,
  backendAvailability: 99.96,
  estimatedCostUsd: 186.40,
  costBreakdown: [
    { service: "Application runtime", amount: 82.6 }, { service: "Database", amount: 54.2 },
    { service: "Object storage", amount: 23.7 }, { service: "Network & monitoring", amount: 25.9 },
  ],
  series: [
    { day: "Oct 28", requests: 132000 }, { day: "Oct 29", requests: 141000 }, { day: "Oct 30", requests: 138000 },
    { day: "Oct 31", requests: 149000 }, { day: "Nov 01", requests: 159000 }, { day: "Nov 02", requests: 173000 }, { day: "Nov 03", requests: 184000 },
  ],
};
