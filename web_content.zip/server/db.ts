import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'projects');
const ARTIFACTS_DIR = path.join(DATA_DIR, 'artifacts');
const AVATARS_DIR = path.join(DATA_DIR, 'avatars');

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });
fs.mkdirSync(ARTIFACTS_DIR, { recursive: true });
fs.mkdirSync(AVATARS_DIR, { recursive: true });

export const DB_PATH = path.join(DATA_DIR, 'studio.db');
export const PROJECTS_STORAGE_DIR = UPLOADS_DIR;
export const BUILD_ARTIFACTS_DIR = ARTIFACTS_DIR;
export const AVATARS_STORAGE_DIR = AVATARS_DIR;

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function ensureColumn(tableName: string, columnName: string, columnDef: string): void {
  const cols = db.prepare(`PRAGMA table_info(${tableName})`).all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === columnName)) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDef}`);
  }
}

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS roles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL,
      permissions_json TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
      avatar_url TEXT,
      bio TEXT,
      theme_pref TEXT NOT NULL DEFAULT 'dark',
      created_at TEXT NOT NULL,
      updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS password_resets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      token_hash TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS subscription_plans (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      price_try REAL NOT NULL,
      duration_days INTEGER,
      is_lifetime INTEGER NOT NULL DEFAULT 0,
      description TEXT NOT NULL,
      features_json TEXT NOT NULL,
      is_highlighted INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      plan_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('active', 'expired', 'cancelled')),
      started_at TEXT NOT NULL,
      expires_at TEXT,
      is_lifetime INTEGER NOT NULL DEFAULT 0,
      granted_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (plan_id) REFERENCES subscription_plans(id)
    );

    CREATE TABLE IF NOT EXISTS promo_codes (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      discount_percent INTEGER NOT NULL CHECK (discount_percent >= 1 AND discount_percent <= 95),
      max_uses INTEGER NOT NULL DEFAULT 100,
      current_uses INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_by TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      plan_id TEXT NOT NULL,
      provider TEXT NOT NULL,
      provider_reference TEXT NOT NULL,
      amount_try REAL NOT NULL,
      original_amount_try REAL,
      discount_try REAL NOT NULL DEFAULT 0,
      promo_code_id TEXT,
      currency TEXT NOT NULL DEFAULT 'TRY',
      status TEXT NOT NULL CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')),
      is_test_mode INTEGER NOT NULL DEFAULT 1,
      checkout_token TEXT NOT NULL,
      created_at TEXT NOT NULL,
      completed_at TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (plan_id) REFERENCES subscription_plans(id)
    );

    CREATE TABLE IF NOT EXISTS promo_redemptions (
      id TEXT PRIMARY KEY,
      promo_code_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      payment_id TEXT NOT NULL,
      discount_try REAL NOT NULL,
      redeemed_at TEXT NOT NULL,
      UNIQUE (promo_code_id, payment_id),
      FOREIGN KEY (promo_code_id) REFERENCES promo_codes(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS payment_events (
      id TEXT PRIMARY KEY,
      payment_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      signature_verified INTEGER NOT NULL DEFAULT 0,
      payload_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS build_usage (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      month_key TEXT NOT NULL,
      builds_count INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      UNIQUE (user_id, month_key),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS system_limits (
      tier TEXT PRIMARY KEY CHECK (tier IN ('free', 'premium')),
      max_projects INTEGER NOT NULL,
      monthly_builds INTEGER NOT NULL,
      max_upload_mb INTEGER NOT NULL,
      priority_queue INTEGER NOT NULL DEFAULT 0,
      premium_icons INTEGER NOT NULL DEFAULT 0,
      ad_free INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      name TEXT NOT NULL,
      entry_file TEXT NOT NULL DEFAULT 'index.html',
      total_files INTEGER NOT NULL DEFAULT 0,
      total_size_bytes INTEGER NOT NULL DEFAULT 0,
      config_json TEXT NOT NULL,
      storage_dir TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS project_files (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      file_path TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      is_binary INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      UNIQUE (project_id, file_path),
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS builds (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'completed_apk', 'completed_bundle', 'failed', 'cancelled')),
      stage TEXT NOT NULL,
      stage_index INTEGER NOT NULL DEFAULT 0,
      total_stages INTEGER NOT NULL DEFAULT 12,
      build_mode TEXT NOT NULL,
      artifact_path TEXT,
      artifact_filename TEXT,
      artifact_size_bytes INTEGER DEFAULT 0,
      sha256 TEXT,
      logs_json TEXT NOT NULL,
      error_message TEXT,
      is_priority INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      started_at TEXT,
      completed_at TEXT,
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS build_files (
      id TEXT PRIMARY KEY,
      build_id TEXT NOT NULL,
      project_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      file_path TEXT NOT NULL,
      file_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (build_id) REFERENCES builds(id) ON DELETE CASCADE,
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info',
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      link_section TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS error_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      source TEXT NOT NULL,
      level TEXT NOT NULL DEFAULT 'error',
      message TEXT NOT NULL,
      stack TEXT,
      path TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_user_id TEXT,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT,
      details_json TEXT NOT NULL,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
  `);

  // Safe migrations for pre-existing studio.db tables
  ensureColumn('users', 'avatar_url', 'TEXT');
  ensureColumn('users', 'bio', 'TEXT');
  ensureColumn('users', 'theme_pref', "TEXT NOT NULL DEFAULT 'dark'");
  ensureColumn('users', 'updated_at', 'TEXT');
  ensureColumn('payments', 'original_amount_try', 'REAL');
  ensureColumn('payments', 'discount_try', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('payments', 'promo_code_id', 'TEXT');

  // Indexes for performance
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
    CREATE INDEX IF NOT EXISTS idx_project_files_project ON project_files(project_id);
    CREATE INDEX IF NOT EXISTS idx_builds_user_created ON builds(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_builds_project ON builds(project_id);
    CREATE INDEX IF NOT EXISTS idx_build_files_build ON build_files(build_id);
    CREATE INDEX IF NOT EXISTS idx_payments_user_created ON payments(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_error_logs_created ON error_logs(created_at DESC);
  `);

  const now = new Date().toISOString();

  // Seed Roles
  const roleCount = (db.prepare('SELECT COUNT(*) as c FROM roles').get() as { c: number }).c;
  if (roleCount === 0) {
    const insertRole = db.prepare(
      'INSERT INTO roles (id, name, description, permissions_json) VALUES (?, ?, ?, ?)'
    );
    insertRole.run(
      'role_user',
      'user',
      'Standart geliştirici hesabı',
      JSON.stringify(['projects:rw', 'builds:rw', 'billing:rw'])
    );
    insertRole.run(
      'role_admin',
      'admin',
      'Tam yetkili sistem yöneticisi',
      JSON.stringify(['*'])
    );
  }

  // Seed System Settings
  const defaultSettings: Array<[string, string]> = [
    ['allow_registration', 'true'],
    ['maintenance_mode', 'false'],
    ['default_build_timeout_ms', '300000'],
    ['max_global_upload_mb', '50'],
  ];
  const insertSetting = db.prepare(
    'INSERT OR IGNORE INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)'
  );
  for (const [k, v] of defaultSettings) {
    insertSetting.run(k, v, now);
  }

  // Seed Subscription Plans (Only if empty)
  const planCount = (db.prepare('SELECT COUNT(*) as c FROM subscription_plans').get() as { c: number }).c;
  if (planCount === 0) {
    const insertPlan = db.prepare(`
      INSERT INTO subscription_plans (id, code, name, price_try, duration_days, is_lifetime, description, features_json, is_highlighted, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertPlan.run(
      'plan_monthly',
      'monthly',
      'Aylık Premium',
      150,
      30,
      0,
      'Aktif proje geliştiren bağımsız geliştiriciler için aylık esnek erişim.',
      JSON.stringify([
        'Premium özelliklerin tamamına erişim',
        'Aylık 250 APK derleme hakkı',
        'Öncelikli derleme kuyruğu',
        'Reklamsız kullanım deneyimi',
        '50 MB proje yükleme ve geniş depolama',
        'Adaptive ikon ve tüm ikon paketleri',
        'Öncelikli teknik destek',
      ]),
      0,
      now
    );

    insertPlan.run(
      'plan_yearly',
      'yearly',
      'Yıllık Premium',
      1000,
      365,
      0,
      'Düzenli uygulama yayınlayan ekipler ve stüdyolar için en avantajlı yıllık plan.',
      JSON.stringify([
        'Aylık paketteki tüm özellikler',
        '%44 daha avantajlı yıllık fiyat (1.000 TL / 365 gün)',
        'Öncelikli APK oluşturma sırası',
        'Genişletilmiş proje depolama alanı',
        'Yüksek aylık derleme limitleri',
        'Premium uygulama ikonları ve özelleştirme',
        'Premium öncelikli destek',
      ]),
      1,
      now
    );

    insertPlan.run(
      'plan_lifetime',
      'lifetime',
      'Kalıcı Premium',
      2000,
      null,
      1,
      'Tek seferlik ödeme ile platformdaki tüm Premium özelliklere süresiz sahip olun.',
      JSON.stringify([
        'Premium özelliklerin tamamına süresiz erişim',
        'Süresiz öncelikli APK derleme',
        'Genişletilmiş kalıcı proje depolama alanı',
        'Yüksek derleme limitleri',
        'Kalıcı reklamsız kullanım',
        'Tüm gelecek Premium ikon paketleri',
        'Ömür boyu Premium destek',
      ]),
      0,
      now
    );
  }

  // Seed System Limits (Free vs Premium)
  const limitCount = (db.prepare('SELECT COUNT(*) as c FROM system_limits').get() as { c: number }).c;
  if (limitCount === 0) {
    const insertLimit = db.prepare(`
      INSERT INTO system_limits (tier, max_projects, monthly_builds, max_upload_mb, priority_queue, premium_icons, ad_free, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertLimit.run('free', 3, 5, 10, 0, 0, 0, now);
    insertLimit.run('premium', 100, 250, 50, 1, 1, 1, now);
  }

  // Seed Root Admin from Environment Variable (never hardcode plaintext admin secret in frontend)
  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@htmltoapk.studio').trim().toLowerCase();
  const existingAdmin = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail) as
    | { id: string }
    | undefined;

  if (!existingAdmin) {
    const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
    const adminId = userCount === 0 ? 'usr_admin_root' : `usr_${crypto.randomUUID().slice(0, 10)}`;
    const envPass = process.env.ADMIN_PASSWORD?.trim();
    const initialPass = envPass || crypto.randomBytes(12).toString('base64url');
    if (!envPass) {
      console.warn(
        `[Security] ADMIN_PASSWORD tanımlı değil. "${adminEmail}" için tek seferlik yönetici parolası oluşturuldu: ${initialPass}`
      );
    }
    const adminHash = bcrypt.hashSync(initialPass, 12);

    db.prepare(`
      INSERT INTO users (id, username, email, password_hash, role, theme_pref, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'admin', 'dark', ?, ?)
    `).run(adminId, process.env.ADMIN_NAME || 'Sistem Yöneticisi', adminEmail, adminHash, now, now);

    db.prepare(`
      INSERT INTO subscriptions (id, user_id, plan_id, status, started_at, expires_at, is_lifetime, granted_by, created_at, updated_at)
      VALUES (?, ?, 'plan_lifetime', 'active', ?, NULL, 1, ?, ?, ?)
    `).run(`sub_${crypto.randomUUID().slice(0, 8)}`, adminId, now, adminId, now, now);

    seedStarterProject(adminId, now);
  } else {
    // Sync project_files index for existing projects
    const existingProjects = db
      .prepare('SELECT id, user_id, storage_dir FROM projects')
      .all() as Array<{ id: string; user_id: string; storage_dir: string }>;
    for (const p of existingProjects) {
      if (p.storage_dir && fs.existsSync(p.storage_dir)) {
        syncProjectFilesIndex(p.id, p.user_id, p.storage_dir);
      }
    }
  }
}

export function syncProjectFilesIndex(
  projectId: string,
  userId: string,
  storageDir: string
): void {
  const binaryExts = new Set([
    '.png',
    '.jpg',
    '.jpeg',
    '.webp',
    '.ico',
    '.woff',
    '.woff2',
    '.ttf',
    '.otf',
  ]);
  const found: Array<{ rel: string; size: number; isBinary: number }> = [];

  const walk = (dir: string, prefix: string) => {
    if (!fs.existsSync(dir)) return;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.startsWith('__studio_meta')) continue;
      const full = path.join(dir, entry.name);
      const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) {
        walk(full, rel);
      } else if (entry.isFile()) {
        const st = fs.statSync(full);
        found.push({
          rel,
          size: st.size,
          isBinary: binaryExts.has(path.extname(entry.name).toLowerCase()) ? 1 : 0,
        });
      }
    }
  };

  walk(storageDir, '');
  const now = new Date().toISOString();

  db.transaction(() => {
    db.prepare('DELETE FROM project_files WHERE project_id = ?').run(projectId);
    const ins = db.prepare(`
      INSERT INTO project_files (id, project_id, user_id, file_path, size_bytes, is_binary, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const f of found) {
      ins.run(`pfi_${crypto.randomUUID().slice(0, 10)}`, projectId, userId, f.rel, f.size, f.isBinary, now);
    }
  })();
}

export function createNotification(params: {
  userId: string;
  type?: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  linkSection?: string;
}): void {
  try {
    db.prepare(`
      INSERT INTO notifications (id, user_id, type, title, message, is_read, link_section, created_at)
      VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `).run(
      `ntf_${crypto.randomUUID().slice(0, 10)}`,
      params.userId,
      params.type || 'info',
      params.title,
      params.message,
      params.linkSection || null,
      new Date().toISOString()
    );
  } catch {
    // non-fatal
  }
}

export function recordErrorLog(params: {
  userId?: string | null;
  source: string;
  level?: 'error' | 'warn';
  message: string;
  stack?: string | null;
  path?: string | null;
}): void {
  try {
    db.prepare(`
      INSERT INTO error_logs (id, user_id, source, level, message, stack, path, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      `err_${crypto.randomUUID().slice(0, 10)}`,
      params.userId || null,
      params.source,
      params.level || 'error',
      params.message.slice(0, 2000),
      params.stack ? params.stack.slice(0, 4000) : null,
      params.path || null,
      new Date().toISOString()
    );
  } catch {
    // non-fatal
  }
}

export function getStudioSampleWebAssets(): {
  indexHtml: string;
  styleCss: string;
  appJs: string;
  singleHtml: string;
} {
  const styleCss = `* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: #0b1020;
  color: #f8fafc;
  min-height: 100vh;
}
.studio-shell { max-width: 560px; margin: 0 auto; padding-bottom: 32px; }
.topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 16px 18px; border-bottom: 1px solid rgba(255,255,255,0.08);
  background: #111827; position: sticky; top: 0; z-index: 10;
}
.brand { font-size: 16px; font-weight: 700; color: #ffffff; }
.subtitle { font-size: 11px; color: #94a3b8; }
.tabs {
  display: flex; gap: 6px; padding: 12px 16px;
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.tab {
  flex: 1; background: #151d2e; color: #94a3b8;
  border: 1px solid rgba(255,255,255,0.08); border-radius: 10px;
  padding: 9px 10px; font-size: 12px; font-weight: 600; cursor: pointer;
}
.tab.active { background: #6366f1; color: #ffffff; border-color: #6366f1; }
.content { padding: 16px; }
.panel { display: none; flex-direction: column; gap: 14px; }
.panel.active { display: flex; }
.hero-card {
  background: #151d2e;
  border: 1px solid rgba(99,102,241,0.35); border-radius: 14px; padding: 18px;
}
.hero-card h1 { font-size: 19px; line-height: 1.3; margin-bottom: 8px; }
.hero-card p { font-size: 13px; color: #94a3b8; line-height: 1.5; }
.stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.stat-card {
  background: #151d2e; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 12px; padding: 12px 14px;
}
.stat-label { display: block; font-size: 11px; color: #94a3b8; margin-bottom: 4px; }
.stat-val { font-size: 13px; color: #ffffff; }
.card {
  background: #151d2e; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px; padding: 16px;
}
.card h2 { font-size: 14px; font-weight: 600; margin-bottom: 10px; }
.card-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 10px; }
.card-head h2 { margin-bottom: 0; }
.field-label { display: block; font-size: 11px; color: #94a3b8; margin-bottom: 6px; }
input, textarea {
  width: 100%; background: #0b1020; color: #ffffff;
  border: 1px solid rgba(255,255,255,0.12); border-radius: 10px;
  padding: 10px 12px; font-size: 13px; font-family: monospace; outline: none;
}
.feedback { margin-top: 8px; font-size: 12px; }
.feedback.ok { color: #22c55e; }
.feedback.err { color: #ef4444; }
.btn-primary {
  background: #6366f1; color: #fff; border: 0; border-radius: 8px;
  padding: 7px 12px; font-size: 12px; font-weight: 600; cursor: pointer;
}
.btn-secondary {
  background: rgba(59,130,246,0.15); color: #93c5fd; border: 1px solid rgba(59,130,246,0.3);
  border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 600; cursor: pointer;
}
.preview-box {
  margin-top: 12px; border: 1px dashed rgba(255,255,255,0.16);
  border-radius: 12px; padding: 10px; background: #0b1020; min-height: 80px;
}
.code-out {
  background: #0b1020; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px;
  padding: 12px; font-family: monospace; font-size: 11px; color: #cbd5e1;
  overflow-x: auto; line-height: 1.5; white-space: pre-wrap;
}
`;

  const appJs = `const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.panel');

tabs.forEach((btn) => {
  btn.addEventListener('click', () => {
    tabs.forEach((t) => t.classList.remove('active'));
    panels.forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    const target = document.getElementById('tab-' + btn.dataset.tab);
    if (target) target.classList.add('active');
  });
});

const pkgInput = document.getElementById('pkgInput');
const pkgFeedback = document.getElementById('pkgFeedback');
const manifestOutput = document.getElementById('manifestOutput');
const pkgRegex = /^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$/;

function updateManifest() {
  const pkg = (pkgInput.value || 'com.htmltoapk.ornek').trim();
  const valid = pkgRegex.test(pkg);
  pkgFeedback.textContent = valid
    ? 'Geçerli Android paket adı formatı.'
    : 'Geçersiz format (ör. com.firma.uygulama)';
  pkgFeedback.className = 'feedback ' + (valid ? 'ok' : 'err');

  manifestOutput.textContent =
    '<manifest xmlns:android="http://schemas.android.com/apk/res/android"\\n' +
    '    package="' + pkg + '">\\n' +
    '  <uses-permission android:name="android.permission.INTERNET" />\\n' +
    '  <application android:label="HTML TO APK STUDIO" android:icon="@mipmap/ic_launcher">\\n' +
    '    <activity android:name=".MainActivity" android:exported="true" />\\n' +
    '  </application>\\n' +
    '</manifest>';
}

pkgInput.addEventListener('input', updateManifest);
updateManifest();

const htmlCode = document.getElementById('htmlCode');
const liveRender = document.getElementById('liveRender');
const runPreviewBtn = document.getElementById('runPreviewBtn');

function renderPreview() {
  liveRender.innerHTML = htmlCode.value;
}
runPreviewBtn.addEventListener('click', renderPreview);
renderPreview();

const copyBtn = document.getElementById('copyManifestBtn');
copyBtn.addEventListener('click', () => {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(manifestOutput.textContent || '');
    copyBtn.textContent = 'Kopyalandı';
    setTimeout(() => { copyBtn.textContent = 'Kopyala'; }, 1500);
  }
});
`;

  const bodyMarkup = `  <div class="studio-shell">
    <header class="topbar">
      <div class="brand">HTML TO APK STUDIO</div>
      <span class="subtitle">Örnek WebView Uygulaması</span>
    </header>

    <nav class="tabs" role="tablist">
      <button class="tab active" data-tab="overview" type="button">Ana Panel</button>
      <button class="tab" data-tab="editor" type="button">Kod & Önizleme</button>
      <button class="tab" data-tab="manifest" type="button">Manifest Üret</button>
    </nav>

    <main class="content">
      <section id="tab-overview" class="panel active">
        <div class="hero-card">
          <h1>HTML Projelerini Android Uygulamalarına Dönüştür</h1>
          <p>Bu örnek uygulama, HTML TO APK STUDIO WebView motoru üzerinde çalışan etkileşimli başlangıç şablonudur.</p>
        </div>

        <div class="stats-grid">
          <div class="stat-card">
            <span class="stat-label">Motor</span>
            <strong class="stat-val">Android WebView</strong>
          </div>
          <div class="stat-card">
            <span class="stat-label">Hedef SDK</span>
            <strong class="stat-val">API 34 (Android 14)</strong>
          </div>
          <div class="stat-card">
            <span class="stat-label">JS Bridge</span>
            <strong class="stat-val">Güvenli Kapalı</strong>
          </div>
          <div class="stat-card">
            <span class="stat-label">Çevrimdışı</span>
            <strong class="stat-val">Assets Destekli</strong>
          </div>
        </div>

        <div class="card">
          <h2>Hızlı Paket Doğrulayıcı</h2>
          <label class="field-label" for="pkgInput">Android Paket Adı</label>
          <input id="pkgInput" type="text" value="com.htmltoapk.ornek" />
          <p id="pkgFeedback" class="feedback ok">Geçerli Android paket adı formatı.</p>
        </div>
      </section>

      <section id="tab-editor" class="panel">
        <div class="card">
          <div class="card-head">
            <h2>Canlı HTML Editörü</h2>
            <button id="runPreviewBtn" class="btn-primary" type="button">Önizlemeyi Güncelle</button>
          </div>
          <textarea id="htmlCode" rows="6">&lt;div style="padding:16px;background:#151d2e;border-radius:12px;color:#fff;font-family:sans-serif"&gt;
  &lt;h3 style="margin:0 0 6px"&gt;Merhaba Android!&lt;/h3&gt;
  &lt;p style="margin:0;color:#94a3b8;font-size:13px"&gt;WebView içinde canlı çalışıyor.&lt;/p&gt;
&lt;/div&gt;</textarea>
          <div id="liveRender" class="preview-box"></div>
        </div>
      </section>

      <section id="tab-manifest" class="panel">
        <div class="card">
          <div class="card-head">
            <h2>AndroidManifest.xml Önizleme</h2>
            <button id="copyManifestBtn" class="btn-secondary" type="button">Kopyala</button>
          </div>
          <pre id="manifestOutput" class="code-out"></pre>
        </div>
      </section>
    </main>
  </div>`;

  const indexHtml = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>HTML TO APK STUDIO — Örnek Uygulama</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
${bodyMarkup}
  <script src="js/app.js"></script>
</body>
</html>
`;

  const singleHtml = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>HTML TO APK STUDIO</title>
  <style>
${styleCss}
  </style>
</head>
<body>
${bodyMarkup}
  <script>
${appJs}
  </script>
</body>
</html>
`;

  return { indexHtml, styleCss, appJs, singleHtml };
}

export function seedStarterProject(userId: string, now: string): string {
  const projectId = `prj_${crypto.randomUUID().slice(0, 10)}`;
  const storageDir = path.join(PROJECTS_STORAGE_DIR, projectId);
  fs.mkdirSync(path.join(storageDir, 'css'), { recursive: true });
  fs.mkdirSync(path.join(storageDir, 'js'), { recursive: true });

  const { indexHtml, styleCss, appJs } = getStudioSampleWebAssets();

  fs.writeFileSync(path.join(storageDir, 'index.html'), indexHtml, 'utf8');
  fs.writeFileSync(path.join(storageDir, 'css', 'style.css'), styleCss, 'utf8');
  fs.writeFileSync(path.join(storageDir, 'js', 'app.js'), appJs, 'utf8');

  const totalSize =
    Buffer.byteLength(indexHtml) + Buffer.byteLength(styleCss) + Buffer.byteLength(appJs);

  const defaultConfig = {
    appName: 'HTML TO APK STUDIO',
    packageName: 'com.htmltoapk.studio.ornek',
    versionName: '1.0.0',
    versionCode: 1,
    iconPreset: 'nebula',
    customIconPath: null,
    adaptiveIconEnabled: true,
    adaptiveBgColor: '#0B1020',
    customForegroundPath: null,
    splashEnabled: true,
    splashBgColor: '#0B1020',
    splashTitle: 'HTML TO APK STUDIO',
    splashDurationMs: 1400,
    orientation: 'unspecified',
    fullscreen: false,
    statusBarVisible: true,
    statusBarColor: '#0B1020',
    navigationBarVisible: true,
    navigationBarColor: '#0B1020',
    internetPermission: true,
    offlineEnabled: true,
    launchAnimation: 'fade',
  };

  db.prepare(`
    INSERT INTO projects (id, user_id, name, entry_file, total_files, total_size_bytes, config_json, storage_dir, created_at, updated_at)
    VALUES (?, ?, ?, 'index.html', 3, ?, ?, ?, ?, ?)
  `).run(projectId, userId, 'HTML to APK Studio (Örnek Uygulama)', totalSize, JSON.stringify(defaultConfig), storageDir, now, now);

  syncProjectFilesIndex(projectId, userId, storageDir);

  return projectId;
}
