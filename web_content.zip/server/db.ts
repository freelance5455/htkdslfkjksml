import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { User, UserPreferences, Conversation, ChatMessage, SupportTicket, TicketReply, SystemNotification } from '../src/types.js';

interface DbUserRecord extends User {
  passwordHash: string;
  salt: string;
  verificationCode?: string;
  resetToken?: string;
  resetTokenExpires?: number;
}

interface DbSessionRecord {
  token: string;
  userId: string;
  createdAt: number;
  expiresAt: number;
}

interface DatabaseSchema {
  users: DbUserRecord[];
  sessions: DbSessionRecord[];
  preferences: Record<string, UserPreferences>;
  conversations: Conversation[];
  messages: ChatMessage[];
  tickets?: SupportTicket[];
  notifications?: SystemNotification[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const defaultDb: DatabaseSchema = {
  users: [],
  sessions: [],
  preferences: {},
  conversations: [],
  messages: [],
  tickets: [],
  notifications: [],
};

export const defaultPreferences: UserPreferences = {
  theme: 'system',
  voice: {
    voiceURI: '',
    rate: 1.0,
    pitch: 1.0,
    autoRead: false,
  },
  personalization: {
    aiName: 'AI Pocket Chat',
    responseStyle: 'Friendly',
    responseLength: 'Balanced',
    preferredLanguage: 'English',
    customInstructions: '',
  },
  notifications: {
    enabled: true,
    aiUpdates: true,
    productUpdates: true,
    accountAlerts: true,
  },
  appearance: {
    theme: 'system',
    fontSize: 'base',
    chatDensity: 'comfortable',
    animations: true,
  },
  aiSettings: {
    model: 'gemini-3.8-flash',
    temperature: 0.7,
    maxTokens: 2048,
    streamResponse: true,
  },
};

class DatabaseManager {
  private data: DatabaseSchema = { ...defaultDb };
  private initialized = false;

  constructor() {
    this.init();
  }

  private init() {
    if (this.initialized) return;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(raw);
        // Guarantee arrays exist
        this.data.users = this.data.users || [];
        this.data.sessions = this.data.sessions || [];
        this.data.preferences = this.data.preferences || {};
        this.data.conversations = this.data.conversations || [];
        this.data.messages = this.data.messages || [];
        this.data.tickets = this.data.tickets || [];
        this.data.notifications = this.data.notifications || [];
      } else {
        this.saveSync();
      }
      this.initialized = true;
    } catch (err) {
      console.error('Error initializing database file:', err);
      this.data = { ...defaultDb };
    }
  }

  private saveSync() {
    try {
      const tempPath = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(this.data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Failed to save database file:', err);
    }
  }

  // Password utilities
  public hashPassword(password: string): { salt: string; hash: string } {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(password, salt, 64).toString('hex');
    return { salt, hash };
  }

  public verifyPassword(password: string, hash: string, salt: string): boolean {
    try {
      const derivedHash = crypto.scryptSync(password, salt, 64).toString('hex');
      return crypto.timingSafeEqual(Buffer.from(derivedHash, 'hex'), Buffer.from(hash, 'hex'));
    } catch {
      return false;
    }
  }

  // Users
  public findUserByEmail(email: string): DbUserRecord | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
  }

  public findUserById(id: string): DbUserRecord | undefined {
    return this.data.users.find(u => u.id === id);
  }

  public createUser(params: { name: string; email: string; password: string }): { user: User; verificationCode: string } {
    const existing = this.findUserByEmail(params.email);
    if (existing) {
      throw new Error('An account with this email address already exists.');
    }

    const { salt, hash } = this.hashPassword(params.password);
    const userId = 'usr_' + crypto.randomBytes(8).toString('hex');
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();

    const record: DbUserRecord = {
      id: userId,
      name: params.name.trim(),
      email: params.email.trim().toLowerCase(),
      passwordHash: hash,
      salt,
      emailVerified: true, // No email verification required
      verificationCode,
      createdAt: new Date().toISOString(),
      bio: 'AI Pocket Chat Explorer',
    };

    this.data.users.push(record);
    this.data.preferences[userId] = JSON.parse(JSON.stringify(defaultPreferences));
    this.saveSync();

    const { passwordHash, salt: s, verificationCode: vc, resetToken, resetTokenExpires, ...safeUser } = record;
    return { user: safeUser, verificationCode };
  }

  public verifyUserEmail(userId: string, code?: string): boolean {
    const user = this.findUserById(userId);
    if (!user) return false;
    if (code && user.verificationCode && user.verificationCode !== code.trim()) {
      return false;
    }
    user.emailVerified = true;
    user.verificationCode = undefined;
    this.saveSync();
    return true;
  }

  public regenerateVerificationCode(userId: string): string | null {
    const user = this.findUserById(userId);
    if (!user) return null;
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    user.verificationCode = newCode;
    this.saveSync();
    return newCode;
  }

  public createPasswordReset(email: string): { token: string; code: string } | null {
    const user = this.findUserByEmail(email);
    if (!user) return null;
    const token = crypto.randomBytes(24).toString('hex');
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    user.resetToken = token;
    user.verificationCode = code;
    user.resetTokenExpires = Date.now() + 1000 * 60 * 60; // 1 hour
    this.saveSync();
    return { token, code };
  }

  public resetPasswordWithTokenOrCode(identifier: string, newPassword: string): boolean {
    const user = this.data.users.find(
      u => (u.resetToken === identifier || u.verificationCode === identifier) &&
           u.resetTokenExpires &&
           u.resetTokenExpires > Date.now()
    );
    if (!user) return false;

    const { salt, hash } = this.hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    user.resetToken = undefined;
    user.resetTokenExpires = undefined;
    user.verificationCode = undefined;
    this.saveSync();
    return true;
  }

  public changePassword(userId: string, currentPass: string, newPass: string): boolean {
    const user = this.findUserById(userId);
    if (!user) return false;
    if (!this.verifyPassword(currentPass, user.passwordHash, user.salt)) {
      return false;
    }
    const { salt, hash } = this.hashPassword(newPass);
    user.passwordHash = hash;
    user.salt = salt;
    this.saveSync();
    return true;
  }

  public updateUserProfile(userId: string, updates: { name?: string; bio?: string; photoURL?: string }): User | null {
    const user = this.findUserById(userId);
    if (!user) return null;
    if (updates.name !== undefined) user.name = updates.name.trim();
    if (updates.bio !== undefined) user.bio = updates.bio.trim();
    if (updates.photoURL !== undefined) user.photoURL = updates.photoURL;
    this.saveSync();
    const { passwordHash, salt, verificationCode, resetToken, resetTokenExpires, ...safeUser } = user;
    return safeUser;
  }

  public deleteUserAccount(userId: string): boolean {
    const index = this.data.users.findIndex(u => u.id === userId);
    if (index === -1) return false;
    this.data.users.splice(index, 1);
    this.data.sessions = this.data.sessions.filter(s => s.userId !== userId);
    delete this.data.preferences[userId];
    this.data.conversations = this.data.conversations.filter(c => c.userId !== userId);
    this.data.messages = this.data.messages.filter(m => m.userId !== userId);
    this.saveSync();
    return true;
  }

  // Sessions
  public createSession(userId: string): string {
    const token = 'tok_' + crypto.randomBytes(32).toString('hex');
    const now = Date.now();
    const expiresAt = now + 1000 * 60 * 60 * 24 * 30; // 30 days
    this.data.sessions.push({ token, userId, createdAt: now, expiresAt });
    this.saveSync();
    return token;
  }

  public getSession(token: string): DbSessionRecord | undefined {
    const session = this.data.sessions.find(s => s.token === token);
    if (!session) return undefined;
    if (session.expiresAt < Date.now()) {
      this.deleteSession(token);
      return undefined;
    }
    return session;
  }

  public deleteSession(token: string) {
    this.data.sessions = this.data.sessions.filter(s => s.token !== token);
    this.saveSync();
  }

  // Preferences
  public getPreferences(userId: string): UserPreferences {
    if (!this.data.preferences[userId]) {
      this.data.preferences[userId] = JSON.parse(JSON.stringify(defaultPreferences));
      this.saveSync();
    }
    return this.data.preferences[userId];
  }

  public updatePreferences(userId: string, prefs: Partial<UserPreferences>): UserPreferences {
    const current = this.getPreferences(userId);
    this.data.preferences[userId] = {
      ...current,
      ...prefs,
      voice: { ...current.voice, ...(prefs.voice || {}) },
      personalization: { ...current.personalization, ...(prefs.personalization || {}) },
      notifications: { ...current.notifications, ...(prefs.notifications || {}) },
      appearance: { ...current.appearance, ...(prefs.appearance || {}) },
      aiSettings: { ...current.aiSettings, ...(prefs.aiSettings || {}) },
    };
    this.saveSync();
    return this.data.preferences[userId];
  }

  // Conversations
  public getConversations(userId: string): Conversation[] {
    return this.data.conversations
      .filter(c => c.userId === userId)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  public getConversationById(id: string, userId: string): Conversation | undefined {
    return this.data.conversations.find(c => c.id === id && c.userId === userId);
  }

  public createConversation(userId: string, title?: string): Conversation {
    const newConv: Conversation = {
      id: 'conv_' + crypto.randomBytes(8).toString('hex'),
      userId,
      title: (title || 'New Conversation').trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.conversations.unshift(newConv);
    this.saveSync();
    return newConv;
  }

  public renameConversation(id: string, userId: string, newTitle: string): Conversation | null {
    const conv = this.getConversationById(id, userId);
    if (!conv) return null;
    conv.title = newTitle.trim();
    conv.updatedAt = new Date().toISOString();
    this.saveSync();
    return conv;
  }

  public deleteConversation(id: string, userId: string): boolean {
    const idx = this.data.conversations.findIndex(c => c.id === id && c.userId === userId);
    if (idx === -1) return false;
    this.data.conversations.splice(idx, 1);
    this.data.messages = this.data.messages.filter(m => m.conversationId !== id);
    this.saveSync();
    return true;
  }

  public deleteAllConversations(userId: string): boolean {
    const convIds = this.data.conversations.filter(c => c.userId === userId).map(c => c.id);
    this.data.conversations = this.data.conversations.filter(c => c.userId !== userId);
    this.data.messages = this.data.messages.filter(m => !convIds.includes(m.conversationId));
    this.saveSync();
    return true;
  }

  // Messages
  public getMessages(conversationId: string, userId: string): ChatMessage[] {
    const conv = this.getConversationById(conversationId, userId);
    if (!conv) return [];
    return this.data.messages
      .filter(m => m.conversationId === conversationId && m.userId === userId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  public addMessage(params: {
    conversationId: string;
    userId: string;
    role: 'user' | 'model';
    content: string;
  }): ChatMessage {
    const msg: ChatMessage = {
      id: 'msg_' + crypto.randomBytes(8).toString('hex'),
      conversationId: params.conversationId,
      userId: params.userId,
      role: params.role,
      content: params.content,
      createdAt: new Date().toISOString(),
    };
    this.data.messages.push(msg);

    // Update conversation updatedAt and lastMessage
    const conv = this.getConversationById(params.conversationId, params.userId);
    if (conv) {
      conv.updatedAt = msg.createdAt;
      conv.lastMessage = params.content.slice(0, 80);
    }

    this.saveSync();
    return msg;
  }

  public setMessageFeedback(messageId: string, userId: string, feedback: 'like' | 'dislike' | null): boolean {
    const msg = this.data.messages.find(m => m.id === messageId && m.userId === userId);
    if (!msg) return false;
    msg.feedback = feedback;
    this.saveSync();
    return true;
  }

  // Search
  public searchChats(userId: string, query: string) {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    const results: Array<{
      conversationId: string;
      conversationTitle: string;
      messageId?: string;
      messageContent?: string;
      matchType: 'title' | 'message';
      date: string;
    }> = [];

    // Title matches
    const userConvs = this.getConversations(userId);
    for (const c of userConvs) {
      if (c.title.toLowerCase().includes(q)) {
        results.push({
          conversationId: c.id,
          conversationTitle: c.title,
          matchType: 'title',
          date: c.updatedAt,
        });
      }
    }

    // Message matches
    const userMessages = this.data.messages.filter(m => m.userId === userId);
    for (const m of userMessages) {
      if (m.content.toLowerCase().includes(q)) {
        const conv = userConvs.find(c => c.id === m.conversationId);
        if (conv) {
          results.push({
            conversationId: conv.id,
            conversationTitle: conv.title,
            messageId: m.id,
            messageContent: m.content.slice(0, 140),
            matchType: 'message',
            date: m.createdAt,
          });
        }
      }
    }

    return results;
  }

  // Admin & Support Tickets
  public getAllUsersForAdmin() {
    return this.data.users.map(u => {
      const convCount = this.data.conversations.filter(c => c.userId === u.id).length;
      const msgCount = this.data.messages.filter(m => m.userId === u.id).length;
      const { passwordHash, salt, verificationCode, resetToken, resetTokenExpires, ...safeUser } = u;
      return {
        ...safeUser,
        conversationCount: convCount,
        messageCount: msgCount,
      };
    });
  }

  public createSupportTicket(params: {
    userId?: string;
    userName: string;
    userEmail: string;
    subject: string;
    category?: string;
    message: string;
  }): SupportTicket {
    if (!this.data.tickets) this.data.tickets = [];

    const ticket: SupportTicket = {
      id: 'tkt_' + crypto.randomBytes(8).toString('hex'),
      userId: params.userId,
      userName: params.userName.trim(),
      userEmail: params.userEmail.trim().toLowerCase(),
      subject: params.subject.trim(),
      category: params.category || 'General Inquiry',
      message: params.message.trim(),
      status: 'pending',
      replies: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.data.tickets.unshift(ticket);
    this.saveSync();
    return ticket;
  }

  public getAllTicketsForAdmin(): SupportTicket[] {
    if (!this.data.tickets) this.data.tickets = [];
    return [...this.data.tickets].sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  public getUserTickets(userEmail: string, userId?: string): SupportTicket[] {
    if (!this.data.tickets) this.data.tickets = [];
    return this.data.tickets.filter(
      t => (userId && t.userId === userId) || (t.userEmail.toLowerCase() === userEmail.toLowerCase())
    );
  }

  public replyToTicket(ticketId: string, replyMessage: string): SupportTicket | null {
    if (!this.data.tickets) this.data.tickets = [];
    const ticket = this.data.tickets.find(t => t.id === ticketId);
    if (!ticket) return null;

    const reply: TicketReply = {
      id: 'rpl_' + crypto.randomBytes(8).toString('hex'),
      sender: 'admin',
      message: replyMessage.trim(),
      createdAt: new Date().toISOString(),
    };

    ticket.replies.push(reply);
    ticket.status = 'replied';
    ticket.updatedAt = reply.createdAt;

    // Create a notification for the user
    this.addNotification({
      title: `Admin Reply: ${ticket.subject}`,
      message: replyMessage.trim(),
      targetUserId: ticket.userId,
    });

    this.saveSync();
    return ticket;
  }

  // System Notifications
  public addNotification(params: { title: string; message: string; targetUserId?: string }): SystemNotification {
    if (!this.data.notifications) this.data.notifications = [];
    const notif: SystemNotification = {
      id: 'notif_' + crypto.randomBytes(8).toString('hex'),
      title: params.title.trim(),
      message: params.message.trim(),
      targetUserId: params.targetUserId,
      createdAt: new Date().toISOString(),
      read: false,
    };
    this.data.notifications.unshift(notif);
    this.saveSync();
    return notif;
  }

  public getUserNotifications(userId?: string): SystemNotification[] {
    if (!this.data.notifications) this.data.notifications = [];
    return this.data.notifications.filter(
      n => !n.targetUserId || n.targetUserId === userId
    );
  }
}

export const db = new DatabaseManager();
