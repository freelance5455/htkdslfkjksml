import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type { User, Chat, Message, Report, VerificationRecord, BanRecord, AuditLog, StatusStory, AppSettings, AIAgentConfig } from '../src/types/index.ts';

interface StoredUser extends User {
  passwordHash: string;
  salt: string;
  isTemporaryPassword?: boolean;
}

interface DatabaseSchema {
  adminKeyHash: string;
  adminKeySalt: string;
  settings: AppSettings;
  aiAgentConfig: AIAgentConfig;
  users: StoredUser[];
  chats: Chat[];
  messages: Message[];
  reports: Report[];
  banRecords: BanRecord[];
  verificationRecords: VerificationRecord[];
  auditLogs: AuditLog[];
  statuses: StatusStory[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const actualSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, actualSalt, 1000, 64, 'sha512').toString('hex');
  return { hash, salt: actualSalt };
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  const computed = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return computed === hash;
}

let dbInstance: DatabaseSchema | null = null;

function loadDatabase(): DatabaseSchema {
  if (dbInstance) return dbInstance;

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const defaultAIAgentConfig: AIAgentConfig = {
    name: 'Unknown Gamer AI Support',
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=UGAgent&backgroundColor=051c38',
    systemPrompt: `You are the official 24/7 AI Support Agent for Unknown Gamer esports messaging application.
You help players with:
- Clan rules, scrims, esports rankings, and match setups.
- Explaining how to report toxic players or cheaters using the in-chat Report button.
- Answering questions about account bans, unban appeals, and verification Blue Ticks (only Admin can unban or grant badges).
- Directing users to Admin's WhatsApp Service: 03260715961 (https://wa.me/923260715961) for urgent manual help, tournament registration, or payment issues.
Tone: Friendly, gaming-fluent, professional esports assistant. You can respond fluently in Urdu, Roman Urdu, or English matching the user's language. Keep responses concise, clear, and actionable.`,
    knowledgeBase: `1. Official WhatsApp Hotline: 03260715961 (https://wa.me/923260715961).
2. Admin credentials and setup: Admin creates gamer accounts and manages bans/unbans.
3. Blue Tick: Unknown Gamer Verified Badge, only granted by Admin.
4. Calling: Both Voice Call and Video Call are available via the Phone/Video icons in 1-on-1 chats.
5. Report: Users can click any message or the 3-dots in chat to report conduct violations directly to the Admin Dashboard.
6. Temporary Password: Users can change temporary passwords in Profile Settings.`,
    isActive: true,
    model: 'gemini-3.8-flash',
    lastTrainedAt: new Date().toISOString(),
    lastTrainedBy: 'Admin (System)',
  };

  const aiUser: StoredUser = {
    id: 'usr_ug_ai_agent',
    username: 'UGAgent',
    fullName: 'Unknown Gamer AI Support',
    role: 'user',
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=UGAgent&backgroundColor=051c38',
    status: 'active',
    verifiedBlueTick: true,
    isTemporaryPassword: false,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    bio: 'Official 24/7 AI Support & Clan Assistant. Trained by Admin.',
    online: true,
    lastSeen: new Date().toISOString(),
    customStatus: '🤖 24/7 AI Esports Helpdesk',
    passwordHash: '',
    salt: '',
  };

  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      dbInstance = JSON.parse(content);
      if (dbInstance) {
        if (!dbInstance.aiAgentConfig) {
          dbInstance.aiAgentConfig = defaultAIAgentConfig;
        }
        if (!dbInstance.users.some(u => u.id === 'usr_ug_ai_agent')) {
          dbInstance.users.unshift(aiUser);
        }
        return dbInstance;
      }
    } catch (err) {
      console.error('Failed to parse db.json, creating initial seed', err);
    }
  }

  // Initial Seed
  const initialAdminKey = 'Abu bakr'; // Required initial key per prompt specification
  const adminKeyCredentials = hashPassword(initialAdminKey);

  const defaultPasswordCreds = hashPassword('gamer123');

  const now = new Date().toISOString();

  const seedUsers: StoredUser[] = [
    {
      id: 'usr_shadow_01',
      username: 'ShadowSniper',
      fullName: 'Zain "Shadow" Malik',
      role: 'user',
      avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=ShadowSniper&backgroundColor=0d1527',
      status: 'active',
      verifiedBlueTick: true,
      isTemporaryPassword: false,
      createdAt: now,
      lastLoginAt: now,
      bio: 'Apex Predator & PUBG Squad Leader. Esports tournament competitor.',
      online: true,
      lastSeen: now,
      customStatus: '⚡ In Scrims Tournament',
      passwordHash: defaultPasswordCreds.hash,
      salt: defaultPasswordCreds.salt,
    },
    {
      id: 'usr_viper_02',
      username: 'CyberViper',
      fullName: 'Hamza Viper',
      role: 'user',
      avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberViper&backgroundColor=0a1120',
      status: 'active',
      verifiedBlueTick: false,
      isTemporaryPassword: false,
      createdAt: now,
      lastLoginAt: now,
      bio: 'Valorant Radiant Assaulter. Unknown Gamer Clan Member.',
      online: true,
      lastSeen: now,
      customStatus: '🎮 Grinding Ranked',
      passwordHash: defaultPasswordCreds.hash,
      salt: defaultPasswordCreds.salt,
    },
    {
      id: 'usr_ghost_03',
      username: 'NeonGhost',
      fullName: 'Daniyal Ghost',
      role: 'user',
      avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=NeonGhost&backgroundColor=051226',
      status: 'active',
      verifiedBlueTick: true,
      isTemporaryPassword: true, // Temporary password to test first-login prompt!
      createdAt: now,
      lastLoginAt: now,
      bio: 'Tactical strategist. Scrims daily at 9:00 PM PST.',
      online: false,
      lastSeen: new Date(Date.now() - 3600000).toISOString(),
      customStatus: '💤 Away from Keyboard',
      passwordHash: defaultPasswordCreds.hash,
      salt: defaultPasswordCreds.salt,
    },
    {
      id: 'usr_aura_04',
      username: 'AuraQueen',
      fullName: 'Sarah Aura',
      role: 'user',
      avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=AuraQueen&backgroundColor=0b1a33',
      status: 'active',
      verifiedBlueTick: false,
      isTemporaryPassword: false,
      createdAt: now,
      lastLoginAt: now,
      bio: 'Sniper specialist & clutch champion. Join our Discord squad.',
      online: true,
      lastSeen: now,
      customStatus: '🏆 15-win streak',
      passwordHash: defaultPasswordCreds.hash,
      salt: defaultPasswordCreds.salt,
    }
  ];

  const seedChats: Chat[] = [
    {
      id: 'chat_group_squad1',
      type: 'group',
      name: 'Unknown Gamer Squad 01',
      avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=UnknownGamerSquad&backgroundColor=003366',
      description: 'Official clan communication and scrim scheduling channel.',
      participants: ['usr_shadow_01', 'usr_viper_02', 'usr_ghost_03', 'usr_aura_04'],
      adminIds: ['usr_shadow_01'],
      createdAt: now,
      updatedAt: now,
      unreadCounts: {
        'usr_shadow_01': 0,
        'usr_viper_02': 0,
        'usr_ghost_03': 1,
        'usr_aura_04': 0,
      },
      lastMessage: {
        id: 'msg_seed_03',
        text: 'Tonight 9 PM scrims ready raho sab! Unknown Gamer champions only. 🎯',
        senderId: 'usr_shadow_01',
        senderName: 'ShadowSniper',
        createdAt: now,
      }
    },
    {
      id: 'chat_direct_1',
      type: 'direct',
      participants: ['usr_shadow_01', 'usr_viper_02'],
      createdAt: now,
      updatedAt: now,
      unreadCounts: {
        'usr_shadow_01': 0,
        'usr_viper_02': 0,
      },
      lastMessage: {
        id: 'msg_seed_02',
        text: 'Bhai match analysis check kar lo, custom loadout OP hai.',
        senderId: 'usr_viper_02',
        senderName: 'CyberViper',
        createdAt: now,
      }
    }
  ];

  const seedMessages: Message[] = [
    {
      id: 'msg_seed_01',
      chatId: 'chat_direct_1',
      senderId: 'usr_shadow_01',
      senderName: 'ShadowSniper',
      senderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ShadowSniper&backgroundColor=0d1527',
      text: 'Salam Viper! Scrims ka time confirm ho gaya hai.',
      readBy: ['usr_shadow_01', 'usr_viper_02'],
      deliveredTo: ['usr_shadow_01', 'usr_viper_02'],
      deletedFor: [],
      isDeletedForEveryone: false,
      createdAt: new Date(Date.now() - 1200000).toISOString(),
    },
    {
      id: 'msg_seed_02',
      chatId: 'chat_direct_1',
      senderId: 'usr_viper_02',
      senderName: 'CyberViper',
      senderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=CyberViper&backgroundColor=0a1120',
      text: 'Bhai match analysis check kar lo, custom loadout OP hai.',
      readBy: ['usr_shadow_01', 'usr_viper_02'],
      deliveredTo: ['usr_shadow_01', 'usr_viper_02'],
      deletedFor: [],
      isDeletedForEveryone: false,
      createdAt: new Date(Date.now() - 600000).toISOString(),
    },
    {
      id: 'msg_seed_03',
      chatId: 'chat_group_squad1',
      senderId: 'usr_shadow_01',
      senderName: 'ShadowSniper',
      senderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ShadowSniper&backgroundColor=0d1527',
      text: 'Tonight 9 PM scrims ready raho sab! Unknown Gamer champions only. 🎯',
      readBy: ['usr_shadow_01', 'usr_viper_02', 'usr_aura_04'],
      deliveredTo: ['usr_shadow_01', 'usr_viper_02', 'usr_aura_04', 'usr_ghost_03'],
      deletedFor: [],
      isDeletedForEveryone: false,
      createdAt: now,
    }
  ];

  const initialSettings: AppSettings = {
    whatsappServiceNumber: '03260715961',
    whatsappUrl: 'https://wa.me/923260715961',
    appVersion: 'v2.4.0 Esports Edition',
    allowNewGroups: true,
    allowFileSharing: true,
    systemNotice: 'Welcome to Unknown Gamer! Contact Admin on WhatsApp for tournament registrations.',
  };

  const initialStatuses: StatusStory[] = [
    {
      id: 'status_01',
      userId: 'usr_shadow_01',
      username: 'ShadowSniper',
      userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ShadowSniper&backgroundColor=0d1527',
      fullName: 'Zain "Shadow" Malik',
      caption: '25 Kills in Tournament Scrims! Unknown Gamer squad undefeated 🔥',
      mediaUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80',
      createdAt: now,
      expiresAt: new Date(Date.now() + 86400000).toISOString(),
      viewers: ['usr_viper_02', 'usr_aura_04'],
    }
  ];

  dbInstance = {
    adminKeyHash: adminKeyCredentials.hash,
    adminKeySalt: adminKeyCredentials.salt,
    settings: initialSettings,
    aiAgentConfig: defaultAIAgentConfig,
    users: [aiUser, ...seedUsers],
    chats: seedChats,
    messages: seedMessages,
    reports: [],
    banRecords: [],
    verificationRecords: [
      {
        id: 'ver_01',
        userId: 'usr_shadow_01',
        username: 'ShadowSniper',
        grantedBy: 'Admin',
        grantedAt: now,
        note: 'Official Unknown Gamer Tournament Captain'
      },
      {
        id: 'ver_02',
        userId: 'usr_ghost_03',
        username: 'NeonGhost',
        grantedBy: 'Admin',
        grantedAt: now,
        note: 'Verified Clan Strategist'
      }
    ],
    auditLogs: [
      {
        id: 'log_01',
        action: 'SYSTEM_INITIALIZED',
        details: 'Unknown Gamer Database initialized with initial Admin Key.',
        timestamp: now,
      }
    ],
    statuses: initialStatuses,
  };

  saveDatabase();
  return dbInstance;
}

function saveDatabase() {
  if (!dbInstance) return;
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbInstance, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write to db.json', err);
  }
}

// Strip password hash and salt for public return
function sanitizeUser(user: StoredUser): User {
  const { passwordHash, salt, ...safe } = user;
  return safe;
}

export const db = {
  // ADMIN AUTH & SETTINGS
  verifyAdminKey(key: string): boolean {
    const data = loadDatabase();
    return verifyPassword(key, data.adminKeyHash, data.adminKeySalt);
  },

  updateAdminKey(newKey: string): boolean {
    const data = loadDatabase();
    const creds = hashPassword(newKey);
    data.adminKeyHash = creds.hash;
    data.adminKeySalt = creds.salt;
    this.addAuditLog('ADMIN_KEY_CHANGED', undefined, undefined, 'Admin access key updated successfully.');
    saveDatabase();
    return true;
  },

  getSettings(): AppSettings {
    const data = loadDatabase();
    return data.settings;
  },

  updateSettings(updates: Partial<AppSettings>): AppSettings {
    const data = loadDatabase();
    data.settings = { ...data.settings, ...updates };
    this.addAuditLog('SETTINGS_UPDATED', undefined, undefined, 'App settings updated.');
    saveDatabase();
    return data.settings;
  },

  // USER MANAGEMENT
  getAllUsers(): User[] {
    const data = loadDatabase();
    return data.users.map(sanitizeUser);
  },

  getUserById(id: string): User | null {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === id);
    return user ? sanitizeUser(user) : null;
  },

  getUserByUsername(username: string): StoredUser | null {
    const data = loadDatabase();
    const user = data.users.find(u => u.username.toLowerCase() === username.toLowerCase());
    return user || null;
  },

  createUser(payload: {
    fullName: string;
    username: string;
    temporaryPassword?: string;
    avatarUrl?: string;
    status?: 'active' | 'banned';
    bio?: string;
    verifiedBlueTick?: boolean;
  }): { success: boolean; user?: User; error?: string } {
    const data = loadDatabase();
    const cleanUsername = payload.username.trim();

    if (!cleanUsername) return { success: false, error: 'Username is required' };
    if (!payload.fullName.trim()) return { success: false, error: 'Full name is required' };

    const exists = data.users.some(u => u.username.toLowerCase() === cleanUsername.toLowerCase());
    if (exists) {
      return { success: false, error: 'A gamer with this username already exists' };
    }

    const tempPassword = payload.temporaryPassword || 'gamer' + Math.floor(1000 + Math.random() * 9000);
    const creds = hashPassword(tempPassword);
    const now = new Date().toISOString();

    const newUser: StoredUser = {
      id: 'usr_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      username: cleanUsername,
      fullName: payload.fullName.trim(),
      role: 'user',
      avatarUrl: payload.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}&backgroundColor=0c1222`,
      status: payload.status || 'active',
      verifiedBlueTick: Boolean(payload.verifiedBlueTick),
      isTemporaryPassword: true,
      createdAt: now,
      lastLoginAt: now,
      bio: payload.bio || 'Unknown Gamer Clan Recruit',
      online: false,
      lastSeen: now,
      passwordHash: creds.hash,
      salt: creds.salt,
    };

    data.users.push(newUser);

    if (newUser.verifiedBlueTick) {
      data.verificationRecords.push({
        id: 'ver_' + Date.now(),
        userId: newUser.id,
        username: newUser.username,
        grantedBy: 'Admin',
        grantedAt: now,
        note: 'Initial verified badge assigned at account creation',
      });
    }

    this.addAuditLog('USER_CREATED', newUser.id, newUser.username, `Admin created user "${newUser.username}" (${newUser.fullName}) with temporary password.`);
    saveDatabase();

    return { success: true, user: sanitizeUser(newUser) };
  },

  updateUser(id: string, updates: Partial<{
    fullName: string;
    username: string;
    bio: string;
    avatarUrl: string;
    customStatus: string;
    verifiedBlueTick: boolean;
  }>): { success: boolean; user?: User; error?: string } {
    const data = loadDatabase();
    const userIndex = data.users.findIndex(u => u.id === id);
    if (userIndex === -1) return { success: false, error: 'User not found' };

    const user = data.users[userIndex];

    if (updates.username && updates.username.toLowerCase() !== user.username.toLowerCase()) {
      const exists = data.users.some(u => u.id !== id && u.username.toLowerCase() === updates.username!.toLowerCase());
      if (exists) return { success: false, error: 'Username already in use' };
      user.username = updates.username.trim();
    }

    if (updates.fullName) user.fullName = updates.fullName.trim();
    if (updates.bio !== undefined) user.bio = updates.bio;
    if (updates.avatarUrl) user.avatarUrl = updates.avatarUrl;
    if (updates.customStatus !== undefined) user.customStatus = updates.customStatus;

    if (updates.verifiedBlueTick !== undefined && updates.verifiedBlueTick !== user.verifiedBlueTick) {
      this.setBlueTick(id, updates.verifiedBlueTick);
    }

    saveDatabase();
    return { success: true, user: sanitizeUser(user) };
  },

  resetUserPassword(userId: string, newPassword?: string): { success: boolean; temporaryPassword?: string; error?: string } {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    const generatedPassword = newPassword || 'gamer' + Math.floor(1000 + Math.random() * 9000);
    const creds = hashPassword(generatedPassword);
    user.passwordHash = creds.hash;
    user.salt = creds.salt;
    user.isTemporaryPassword = true;

    this.addAuditLog('PASSWORD_RESET', user.id, user.username, `Admin reset password for user "${user.username}".`);
    saveDatabase();

    return { success: true, temporaryPassword: generatedPassword };
  },

  banUser(userId: string, options: {
    banType: 'temporary' | 'permanent';
    durationDays?: number;
    reason: string;
    bannedBy?: string;
  }): { success: boolean; banRecord?: BanRecord; error?: string } {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    const now = new Date();
    const expiresAt = options.banType === 'temporary' && options.durationDays
      ? new Date(now.getTime() + options.durationDays * 86400000).toISOString()
      : undefined;

    const banRecord: BanRecord = {
      id: 'ban_' + Date.now(),
      userId: user.id,
      username: user.username,
      bannedBy: options.bannedBy || 'Admin',
      banType: options.banType,
      durationDays: options.durationDays,
      expiresAt,
      reason: options.reason || 'Violation of Unknown Gamer esports rules',
      createdAt: now.toISOString(),
    };

    user.status = 'banned';
    user.banInfo = banRecord;
    data.banRecords.unshift(banRecord);

    this.addAuditLog('USER_BANNED', user.id, user.username, `User "${user.username}" banned (${options.banType}). Reason: ${options.reason}`);
    saveDatabase();

    return { success: true, banRecord };
  },

  unbanUser(userId: string): { success: boolean; error?: string } {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    user.status = 'active';
    if (user.banInfo) {
      user.banInfo.unbannedAt = new Date().toISOString();
    }

    const latestBan = data.banRecords.find(b => b.userId === userId && !b.unbannedAt);
    if (latestBan) {
      latestBan.unbannedAt = new Date().toISOString();
    }

    this.addAuditLog('USER_UNBANNED', user.id, user.username, `User "${user.username}" was unbanned by Admin.`);
    saveDatabase();

    return { success: true };
  },

  deleteUser(userId: string): { success: boolean; error?: string } {
    const data = loadDatabase();
    const idx = data.users.findIndex(u => u.id === userId);
    if (idx === -1) return { success: false, error: 'User not found' };

    const username = data.users[idx].username;
    data.users.splice(idx, 1);

    // Remove user from group chats
    data.chats.forEach(chat => {
      chat.participants = chat.participants.filter(p => p !== userId);
    });

    this.addAuditLog('USER_DELETED', userId, username, `User "${username}" was permanently deleted by Admin.`);
    saveDatabase();

    return { success: true };
  },

  setBlueTick(userId: string, granted: boolean, note?: string): { success: boolean; error?: string } {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    user.verifiedBlueTick = granted;
    const now = new Date().toISOString();

    if (granted) {
      data.verificationRecords.unshift({
        id: 'ver_' + Date.now(),
        userId: user.id,
        username: user.username,
        grantedBy: 'Admin',
        grantedAt: now,
        note: note || 'Unknown Gamer Verified Badge granted by Admin',
      });
      this.addAuditLog('BLUE_TICK_GRANTED', user.id, user.username, `Granted Unknown Gamer verified badge to "${user.username}".`);
    } else {
      const activeRecord = data.verificationRecords.find(v => v.userId === userId && !v.revokedAt);
      if (activeRecord) {
        activeRecord.revokedAt = now;
      }
      this.addAuditLog('BLUE_TICK_REVOKED', user.id, user.username, `Revoked Unknown Gamer verified badge from "${user.username}".`);
    }

    saveDatabase();
    return { success: true };
  },

  // AUDIT LOGS & BAN HISTORY
  addAuditLog(action: string, targetUserId?: string, targetUsername?: string, details = '', adminKeyUsed?: string) {
    const data = loadDatabase();
    const log: AuditLog = {
      id: 'log_' + Date.now() + Math.random().toString(36).substring(2, 5),
      action,
      targetUserId,
      targetUsername,
      details,
      timestamp: new Date().toISOString(),
      adminKeyUsed: adminKeyUsed ? '***' : undefined,
    };
    data.auditLogs.unshift(log);
    // keep max 500 logs
    if (data.auditLogs.length > 500) data.auditLogs.pop();
    saveDatabase();
  },

  getAuditLogs(): AuditLog[] {
    const data = loadDatabase();
    return data.auditLogs;
  },

  getBanRecords(): BanRecord[] {
    const data = loadDatabase();
    return data.banRecords;
  },

  // USER AUTHENTICATION
  authenticateUser(username: string, password: string): {
    success: boolean;
    user?: User;
    token?: string;
    isTemporaryPassword?: boolean;
    error?: string;
    banInfo?: BanRecord;
  } {
    const data = loadDatabase();
    const user = data.users.find(u => u.username.toLowerCase() === username.toLowerCase());

    if (!user) {
      return { success: false, error: 'Invalid username or password' };
    }

    const isValid = verifyPassword(password, user.passwordHash, user.salt);
    if (!isValid) {
      return { success: false, error: 'Invalid username or password' };
    }

    // Check ban status
    if (user.status === 'banned') {
      // Check if temporary ban has expired
      if (user.banInfo?.expiresAt && new Date(user.banInfo.expiresAt) <= new Date()) {
        user.status = 'active';
        user.banInfo.unbannedAt = new Date().toISOString();
        saveDatabase();
      } else {
        return {
          success: false,
          error: 'Your account is banned.',
          banInfo: user.banInfo,
        };
      }
    }

    user.lastLoginAt = new Date().toISOString();
    user.online = true;
    saveDatabase();

    const token = 'tok_' + user.id + '_' + Date.now();
    return {
      success: true,
      user: sanitizeUser(user),
      token,
      isTemporaryPassword: user.isTemporaryPassword,
    };
  },

  changeUserPassword(userId: string, currentPassword: string, newPassword: string): { success: boolean; error?: string } {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    const isValid = verifyPassword(currentPassword, user.passwordHash, user.salt);
    if (!isValid) return { success: false, error: 'Current password is incorrect' };

    if (!newPassword || newPassword.length < 4) {
      return { success: false, error: 'New password must be at least 4 characters long' };
    }

    const creds = hashPassword(newPassword);
    user.passwordHash = creds.hash;
    user.salt = creds.salt;
    user.isTemporaryPassword = false;

    this.addAuditLog('USER_PASSWORD_CHANGED', user.id, user.username, `User "${user.username}" changed their own password.`);
    saveDatabase();
    return { success: true };
  },

  setUserOnlineStatus(userId: string, isOnline: boolean) {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (user) {
      user.online = isOnline;
      user.lastSeen = new Date().toISOString();
      saveDatabase();
    }
  },

  // CHAT & MESSAGING
  getChatsForUser(userId: string): Chat[] {
    const data = loadDatabase();
    return data.chats.filter(c => c.participants.includes(userId));
  },

  getChatById(chatId: string): Chat | null {
    const data = loadDatabase();
    return data.chats.find(c => c.id === chatId) || null;
  },

  createDirectChat(userA: string, userB: string): Chat {
    const data = loadDatabase();
    const existing = data.chats.find(c =>
      c.type === 'direct' &&
      c.participants.length === 2 &&
      c.participants.includes(userA) &&
      c.participants.includes(userB)
    );

    if (existing) return existing;

    const now = new Date().toISOString();
    const newChat: Chat = {
      id: 'chat_dm_' + Date.now() + Math.random().toString(36).substring(2, 5),
      type: 'direct',
      participants: [userA, userB],
      createdAt: now,
      updatedAt: now,
      unreadCounts: {
        [userA]: 0,
        [userB]: 0,
      },
    };

    data.chats.unshift(newChat);
    saveDatabase();
    return newChat;
  },

  createGroupChat(creatorId: string, name: string, participantIds: string[], avatar?: string, description?: string): Chat {
    const data = loadDatabase();
    const allMembers = Array.from(new Set([creatorId, ...participantIds]));
    const now = new Date().toISOString();

    const unreadCounts: Record<string, number> = {};
    allMembers.forEach(id => {
      unreadCounts[id] = 0;
    });

    const newChat: Chat = {
      id: 'chat_grp_' + Date.now() + Math.random().toString(36).substring(2, 5),
      type: 'group',
      name: name.trim(),
      avatar: avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(name)}&backgroundColor=002244`,
      description: description || 'Unknown Gamer Clan Squad',
      participants: allMembers,
      adminIds: [creatorId],
      createdAt: now,
      updatedAt: now,
      unreadCounts,
    };

    data.chats.unshift(newChat);
    const creator = data.users.find(u => u.id === creatorId);
    this.addAuditLog('GROUP_CREATED', creatorId, creator?.username, `Squad "${name}" created with ${allMembers.length} members.`);
    saveDatabase();
    return newChat;
  },

  deleteGroup(chatId: string): boolean {
    const data = loadDatabase();
    const idx = data.chats.findIndex(c => c.id === chatId && c.type === 'group');
    if (idx === -1) return false;

    const chatName = data.chats[idx].name;
    data.chats.splice(idx, 1);
    data.messages = data.messages.filter(m => m.chatId !== chatId);

    this.addAuditLog('GROUP_DELETED', undefined, undefined, `Group "${chatName}" was deleted.`);
    saveDatabase();
    return true;
  },

  getMessages(chatId: string, userId: string): Message[] {
    const data = loadDatabase();
    return data.messages.filter(m => m.chatId === chatId && !m.deletedFor.includes(userId));
  },

  addMessage(payload: {
    chatId: string;
    senderId: string;
    text: string;
    mediaUrl?: string;
    mediaType?: 'image' | 'file' | 'apk';
    fileName?: string;
    fileSize?: string;
    replyTo?: { id: string; text: string; senderName: string };
  }): { message: Message; chat: Chat } {
    const data = loadDatabase();
    const chat = data.chats.find(c => c.id === payload.chatId);
    if (!chat) throw new Error('Chat not found');

    const sender = data.users.find(u => u.id === payload.senderId);
    if (!sender) throw new Error('Sender not found');

    // Server-side check if user is banned
    if (sender.status === 'banned') {
      throw new Error('Banned users cannot send messages.');
    }

    const now = new Date().toISOString();
    const message: Message = {
      id: 'msg_' + Date.now() + Math.random().toString(36).substring(2, 5),
      chatId: payload.chatId,
      senderId: sender.id,
      senderName: sender.username,
      senderAvatar: sender.avatarUrl,
      text: payload.text,
      mediaUrl: payload.mediaUrl,
      mediaType: payload.mediaType,
      fileName: payload.fileName,
      fileSize: payload.fileSize,
      replyTo: payload.replyTo,
      readBy: [sender.id],
      deliveredTo: [sender.id],
      deletedFor: [],
      isDeletedForEveryone: false,
      createdAt: now,
    };

    data.messages.push(message);

    // Determine preview text for last message
    let previewText = message.text;
    if (!previewText) {
      if (message.mediaType === 'image') previewText = '📷 Photo';
      else if (message.mediaType === 'apk') previewText = `📦 APK: ${message.fileName || 'Android App'}`;
      else previewText = `📎 File: ${message.fileName || 'Attachment'}`;
    }

    // Update chat last message and unread counts
    chat.updatedAt = now;
    chat.lastMessage = {
      id: message.id,
      text: previewText,
      senderId: sender.id,
      senderName: sender.username,
      createdAt: now,
      mediaType: message.mediaType,
      fileName: message.fileName,
      fileSize: message.fileSize,
    };

    chat.participants.forEach(pid => {
      if (pid !== sender.id) {
        chat.unreadCounts[pid] = (chat.unreadCounts[pid] || 0) + 1;
      }
    });

    saveDatabase();
    return { message, chat };
  },

  deleteMessage(messageId: string, userId: string, forEveryone: boolean): { success: boolean; isForEveryone: boolean; error?: string } {
    const data = loadDatabase();
    const message = data.messages.find(m => m.id === messageId);
    if (!message) return { success: false, isForEveryone: false, error: 'Message not found' };

    if (forEveryone) {
      if (message.senderId !== userId) {
        return { success: false, isForEveryone: false, error: 'You can only delete your own messages for everyone' };
      }
      message.isDeletedForEveryone = true;
      message.text = '🚫 This message was deleted';
      delete message.mediaUrl;
      delete message.mediaType;
    } else {
      if (!message.deletedFor.includes(userId)) {
        message.deletedFor.push(userId);
      }
    }

    saveDatabase();
    return { success: true, isForEveryone: forEveryone };
  },

  markChatRead(chatId: string, userId: string): string[] {
    const data = loadDatabase();
    const chat = data.chats.find(c => c.id === chatId);
    if (chat && chat.unreadCounts) {
      chat.unreadCounts[userId] = 0;
    }

    const updatedMessageIds: string[] = [];
    data.messages.forEach(m => {
      if (m.chatId === chatId && !m.readBy.includes(userId)) {
        m.readBy.push(userId);
        if (!m.deliveredTo.includes(userId)) {
          m.deliveredTo.push(userId);
        }
        updatedMessageIds.push(m.id);
      }
    });

    saveDatabase();
    return updatedMessageIds;
  },

  // REPORTS & MODERATION
  createReport(payload: {
    reporterId: string;
    reportedUserId: string;
    messageId?: string;
    chatId?: string;
    reason: string;
    evidenceSnippet?: string;
  }): Report {
    const data = loadDatabase();
    const reporter = data.users.find(u => u.id === payload.reporterId);
    const reported = data.users.find(u => u.id === payload.reportedUserId);

    const report: Report = {
      id: 'rep_' + Date.now(),
      reporterId: payload.reporterId,
      reporterUsername: reporter?.username || 'Unknown',
      reportedUserId: payload.reportedUserId,
      reportedUsername: reported?.username || 'Unknown',
      messageId: payload.messageId,
      chatId: payload.chatId,
      reason: payload.reason,
      evidenceSnippet: payload.evidenceSnippet,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    data.reports.unshift(report);
    this.addAuditLog('REPORT_SUBMITTED', reported?.id, reported?.username, `Report filed by "${reporter?.username}": ${payload.reason}`);
    saveDatabase();
    return report;
  },

  getReports(): Report[] {
    const data = loadDatabase();
    return data.reports;
  },

  resolveReport(reportId: string, status: 'action_taken' | 'dismissed', note?: string): boolean {
    const data = loadDatabase();
    const report = data.reports.find(r => r.id === reportId);
    if (!report) return false;

    report.status = status;
    report.reviewedAt = new Date().toISOString();
    report.resolutionNote = note || `Moderated by Admin (${status})`;

    this.addAuditLog('REPORT_RESOLVED', report.reportedUserId, report.reportedUsername, `Report #${reportId} set to "${status}". Note: ${report.resolutionNote}`);
    saveDatabase();
    return true;
  },

  // STORIES / STATUSES
  getStatuses(): StatusStory[] {
    const data = loadDatabase();
    const now = new Date();
    // filter expired (24 hours)
    return data.statuses.filter(s => new Date(s.expiresAt) > now);
  },

  createStatus(userId: string, caption: string, mediaUrl?: string): StatusStory {
    const data = loadDatabase();
    const user = data.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');

    const now = new Date();
    const story: StatusStory = {
      id: 'status_' + Date.now(),
      userId: user.id,
      username: user.username,
      userAvatar: user.avatarUrl,
      fullName: user.fullName,
      caption,
      mediaUrl,
      createdAt: now.toISOString(),
      expiresAt: new Date(now.getTime() + 86400000).toISOString(),
      viewers: [],
    };

    data.statuses.unshift(story);
    saveDatabase();
    return story;
  },

  viewStatus(statusId: string, userId: string) {
    const data = loadDatabase();
    const story = data.statuses.find(s => s.id === statusId);
    if (story && !story.viewers.includes(userId)) {
      story.viewers.push(userId);
      saveDatabase();
    }
  },

  // AI AGENT TRAINING & CONFIG
  getAIAgentConfig(): AIAgentConfig {
    const data = loadDatabase();
    return data.aiAgentConfig;
  },

  updateAIAgentConfig(updates: Partial<AIAgentConfig>, trainedBy = 'Admin'): AIAgentConfig {
    const data = loadDatabase();
    data.aiAgentConfig = {
      ...data.aiAgentConfig,
      ...updates,
      lastTrainedAt: new Date().toISOString(),
      lastTrainedBy: trainedBy,
    };

    // Also update virtual AI user profile if name or avatar changed
    const aiUser = data.users.find(u => u.id === 'usr_ug_ai_agent');
    if (aiUser) {
      if (updates.name) aiUser.fullName = updates.name;
      if (updates.avatarUrl) aiUser.avatarUrl = updates.avatarUrl;
    }

    this.addAuditLog('AI_AGENT_TRAINED', undefined, undefined, `Admin updated training instructions and knowledge for ${data.aiAgentConfig.name}.`);
    saveDatabase();
    return data.aiAgentConfig;
  }
};

