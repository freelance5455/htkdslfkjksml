import { asc, desc, eq, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { ENV } from "./_core/env";
import { InsertUser, PasswordResetRequest, Schedule, TeamMember, User, WorkspaceAccount, passwordResetRequests, schedules, teamMembers, users, workspaceAccounts } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const isOwner = user.openId === ENV.ownerOpenId;
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (field === "name" && isOwner) continue;
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (isOwner) { values.role = "owner"; updateSet.role = "owner"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getWorkspaceAccountByIdentifier(identifier: string) {
  const db = await getDb();
  if (!db) return undefined;
  const normalized = identifier.trim().toLowerCase();
  const usernameLike = normalized.replace(/\s+/g, "-").replace(/[^a-z0-9._-]/g, "");
  const result = await db.select().from(workspaceAccounts).where(or(eq(workspaceAccounts.email, normalized), eq(workspaceAccounts.username, normalized), eq(workspaceAccounts.username, usernameLike))).limit(1);
  return result[0];
}

export async function getWorkspaceAccountById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(workspaceAccounts).where(eq(workspaceAccounts.id, id)).limit(1);
  return result[0];
}

export async function getPasswordResetRequests() {
  const db = await getDb();
  if (!db) return [] as PasswordResetRequest[];
  return db.select().from(passwordResetRequests).orderBy(desc(passwordResetRequests.createdAt)).limit(50);
}

export async function ensureLocalUser(account: WorkspaceAccount) {
  const db = await getDb();
  if (!db) return undefined;
  const openId = `local:${account.id}`;
  await db.insert(users).values({ openId, name: account.name, email: account.email, loginMethod: "local", role: account.role }).onDuplicateKeyUpdate({ set: { name: account.name, email: account.email, role: account.role, lastSignedIn: new Date() } });
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getDashboardOverview() {
  const db = await getDb();
  if (!db) return { schedules: [] as Schedule[], team: [] as TeamMember[], accounts: [] as WorkspaceAccount[], isDemoData: false };
  const [scheduleRows, teamRows, accountRows] = await Promise.all([
    db.select().from(schedules).orderBy(asc(schedules.startAt)).limit(50),
    db.select().from(teamMembers).orderBy(asc(teamMembers.name)).limit(100),
    db.select({ id: workspaceAccounts.id, username: workspaceAccounts.username, name: workspaceAccounts.name, email: workspaceAccounts.email, role: workspaceAccounts.role, createdBy: workspaceAccounts.createdBy, createdAt: workspaceAccounts.createdAt }).from(workspaceAccounts).orderBy(asc(workspaceAccounts.name)).limit(100),
  ]);
  const accountTeamRows: TeamMember[] = accountRows.map(account => ({
    id: account.id,
    name: account.name,
    initials: account.name.split(" ").map(part => part[0] ?? "").join("").slice(0, 2).toUpperCase(),
    role: account.role,
    rank: account.role === "owner" ? "Owner" : account.role[0].toUpperCase() + account.role.slice(1),
    status: "available",
    createdAt: account.createdAt,
  }));
  return { schedules: scheduleRows, team: teamRows.length > 0 ? teamRows : accountTeamRows, accounts: accountRows, isDemoData: false };
}

export type DashboardOverview = Awaited<ReturnType<typeof getDashboardOverview>>;
export type Viewer = Pick<User, "id" | "name" | "email" | "role">;
