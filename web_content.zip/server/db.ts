import fs from 'fs';
import path from 'path';

export interface User {
  id: string;
  name: string;
  username: string;
  email?: string;
  phone?: string;
  phoneCountryCode?: string;
  avatar: string;
  coverImage: string;
  bio: string;
  province: string;
  verified: boolean;
  isPrivate: boolean;
  isAdmin: boolean;
  isSuspended?: boolean;
  friends: string[];
  followers: string[];
  following: string[];
  blockedUsers: string[];
  createdAt: string;
  lastSeenAt: string;
}

export interface VerificationCode {
  phoneOrEmail: string;
  code: string;
  expiresAt: number;
  attempts: number;
  createdAt: number;
}

export interface Post {
  id: string;
  authorId: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'none';
  likes: { userId: string; reaction: 'like' | 'love' | 'angola' | 'laugh' | 'fire' }[];
  comments: {
    id: string;
    authorId: string;
    text: string;
    createdAt: string;
    replies?: { id: string; authorId: string; text: string; createdAt: string }[];
  }[];
  sharesCount: number;
  savedBy: string[];
  hashtags: string[];
  province: string;
  pageId?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Story {
  id: string;
  authorId: string;
  mediaUrl?: string;
  mediaType: 'image' | 'video' | 'text';
  textContent?: string;
  backgroundGradient?: string;
  privacy: 'public' | 'friends' | 'private';
  views: { userId: string; viewedAt: string }[];
  reactions: { userId: string; emoji: string }[];
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location' | 'contact';
  mediaUrl?: string;
  fileName?: string;
  fileSize?: string;
  audioDurationSeconds?: number;
  location?: { lat: number; lng: number; address: string };
  contact?: { name: string; phone: string };
  replyTo?: { messageId: string; text: string; senderName: string };
  reactions: { userId: string; emoji: string }[];
  status: 'sent' | 'delivered' | 'read';
  deliveredTo: string[];
  readBy: string[];
  deletedFor: string[];
  isDeletedForEveryone?: boolean;
  isPinned?: boolean;
  expiresAt?: number;
  createdAt: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  name?: string;
  avatar?: string;
  participantIds: string[];
  adminIds?: string[];
  pinnedMessageIds?: string[];
  ephemeralTimerMinutes?: number;
  updatedAt: string;
  lastMessage?: string;
  lastMessageTime?: string;
}

export interface FriendRequest {
  id: string;
  fromUserId: string;
  toUserId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

export interface GroupCommunity {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  avatar: string;
  category: string;
  isPrivate: boolean;
  creatorId: string;
  adminIds: string[];
  memberIds: string[];
  pendingMemberIds: string[];
  rules: string[];
  province?: string;
  createdAt: string;
}

export interface PageProfile {
  id: string;
  name: string;
  handle: string;
  category: string;
  description: string;
  avatar: string;
  coverImage: string;
  ownerId: string;
  followers: string[];
  contactEmail: string;
  contactPhone: string;
  province: string;
  metrics: {
    viewsThisWeek: number;
    reach: number;
    engagementRate: string;
  };
  createdAt: string;
}

export interface MarketplaceItem {
  id: string;
  sellerId: string;
  title: string;
  description: string;
  price: number;
  currency: 'AOA' | 'USD';
  category: string;
  province: string;
  images: string[];
  condition: 'Novo' | 'Usado como novo' | 'Bom estado';
  contactPhone: string;
  sold: boolean;
  createdAt: string;
}

export interface CallLog {
  id: string;
  callerId: string;
  receiverId: string;
  callType: 'audio' | 'video';
  status: 'completed' | 'missed' | 'rejected';
  durationSeconds: number;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  fromUserId: string;
  type: 'like' | 'comment' | 'friend_request' | 'friend_accepted' | 'follow' | 'mention' | 'call' | 'group_invite' | 'marketplace_inquiry';
  targetId?: string;
  text: string;
  read: boolean;
  createdAt: string;
}

export interface ContentReport {
  id: string;
  reporterId: string;
  targetType: 'post' | 'user' | 'message' | 'marketplace';
  targetId: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface DatabaseSchema {
  users: User[];
  verificationCodes: VerificationCode[];
  posts: Post[];
  stories: Story[];
  conversations: Conversation[];
  messages: Message[];
  friendRequests: FriendRequest[];
  groups: GroupCommunity[];
  pages: PageProfile[];
  marketplace: MarketplaceItem[];
  callLogs: CallLog[];
  notifications: NotificationItem[];
  reports: ContentReport[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'angola_connect_db.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      } catch (err) {
        console.error('Failed to load database, recreating defaults:', err);
      }
    }
    const initial = this.getInitialSeed();
    this.save(initial);
    return initial;
  }

  private save(dataToSave?: DatabaseSchema) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave || this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error saving database to disk:', err);
    }
  }

  public get<K extends keyof DatabaseSchema>(key: K): DatabaseSchema[K] {
    return this.data[key];
  }

  public set<K extends keyof DatabaseSchema>(key: K, value: DatabaseSchema[K]) {
    this.data[key] = value;
    this.save();
  }

  public persist() {
    this.save();
  }

  private getInitialSeed(): DatabaseSchema {
    const now = new Date().toISOString();

    const users: User[] = [
      {
        id: 'usr_admin',
        name: 'Administrador Angola Connect',
        username: 'admin',
        email: 'admin@angolaconnect.ao',
        phone: '+244923000001',
        phoneCountryCode: '+244',
        avatar: '/src/assets/images/angola_user_manuel_1793388060300.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        bio: 'Equipa oficial do Angola Connect 🇦🇴. Conectando Angola ao mundo com inovação, tecnologia e cultura.',
        province: 'Luanda',
        verified: true,
        isPrivate: false,
        isAdmin: true,
        friends: ['usr_maria', 'usr_manuel', 'usr_rosa'],
        followers: ['usr_maria', 'usr_manuel', 'usr_rosa'],
        following: ['usr_maria', 'usr_manuel'],
        blockedUsers: [],
        createdAt: '2026-01-01T08:00:00.000Z',
        lastSeenAt: now,
      },
      {
        id: 'usr_maria',
        name: 'Maria Tchizé',
        username: 'mariatcl',
        email: 'maria.tchize@angolaconnect.ao',
        phone: '+244924112233',
        phoneCountryCode: '+244',
        avatar: '/src/assets/images/angola_user_maria_1793388059496.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        bio: 'Empreendedora na área de moda & criadora de conteúdos em Luanda. Apaixonada pela cultura angolana e Kizomba 💃🏽✨',
        province: 'Luanda',
        verified: true,
        isPrivate: false,
        isAdmin: false,
        friends: ['usr_admin', 'usr_manuel'],
        followers: ['usr_admin', 'usr_manuel'],
        following: ['usr_admin'],
        blockedUsers: [],
        createdAt: '2026-02-10T10:00:00.000Z',
        lastSeenAt: now,
      },
      {
        id: 'usr_manuel',
        name: 'Bruno Manuel Neto',
        username: 'brunoneto',
        email: 'bruno.neto@angolaconnect.ao',
        phone: '+244935445566',
        phoneCountryCode: '+244',
        avatar: '/src/assets/images/angola_user_manuel_1793388060300.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        bio: 'Desenvolvedor de Software & entusiasta de inovação tecnológica em Angola. Benguela & Luanda 💻🚀',
        province: 'Benguela',
        verified: true,
        isPrivate: false,
        isAdmin: false,
        friends: ['usr_admin', 'usr_maria'],
        followers: ['usr_admin', 'usr_maria'],
        following: ['usr_maria'],
        blockedUsers: [],
        createdAt: '2026-02-15T12:00:00.000Z',
        lastSeenAt: now,
      },
      {
        id: 'usr_rosa',
        name: 'Dra. Rosa Sambila',
        username: 'rosasambila',
        email: 'rosa.sambila@angolaconnect.ao',
        phone: '+244944778899',
        phoneCountryCode: '+244',
        avatar: '/src/assets/images/angola_user_maria_1793388059496.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        bio: 'Médica e pesquisadora em saúde pública no Huambo. Defensora do desenvolvimento comunitário 🏥🇦🇴',
        province: 'Huambo',
        verified: true,
        isPrivate: false,
        isAdmin: false,
        friends: ['usr_admin'],
        followers: ['usr_admin'],
        following: ['usr_admin'],
        blockedUsers: [],
        createdAt: '2026-03-01T09:00:00.000Z',
        lastSeenAt: now,
      }
    ];

    const posts: Post[] = [
      {
        id: 'post_1',
        authorId: 'usr_admin',
        content: 'Bem-vindos oficialmente à plataforma ANGOLA CONNECT 🇦🇴! Um espaço feito com orgulho para aproximar os angolanos em Luanda, Benguela, Huambo, Cabinda e em toda a diáspora ao redor do mundo. Conectando Angola ao mundo! #AngolaConnect #AngolaAvante #Luanda #TecnologiaAngola',
        mediaUrl: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        mediaType: 'image',
        likes: [
          { userId: 'usr_maria', reaction: 'angola' },
          { userId: 'usr_manuel', reaction: 'fire' },
          { userId: 'usr_rosa', reaction: 'love' }
        ],
        comments: [
          {
            id: 'comm_1',
            authorId: 'usr_maria',
            text: 'Parabéns pela iniciativa! É exactamente disto que o nosso país precisava para valorizar a nossa gente e os nossos criadores 👏🏾🇦🇴',
            createdAt: '2026-03-10T14:30:00.000Z'
          },
          {
            id: 'comm_2',
            authorId: 'usr_manuel',
            text: 'Excelente velocidade e experiência visual de topo. Vamos ligar Angola inteira! 🔥',
            createdAt: '2026-03-10T14:45:00.000Z'
          }
        ],
        sharesCount: 18,
        savedBy: ['usr_maria'],
        hashtags: ['AngolaConnect', 'AngolaAvante', 'Luanda', 'TecnologiaAngola'],
        province: 'Luanda',
        createdAt: '2026-03-10T14:00:00.000Z'
      },
      {
        id: 'post_2',
        authorId: 'usr_maria',
        content: 'Nova coleção inspirada nos padrões tradicionais Samakaka acabada de chegar ao nosso ateliê! Orgulho na nossa identidade têxtil e na força das nossas raízes africanas. O que acharam deste corte moderno? #ModaAngolana #Samakaka #Cultura #LuandaModa',
        mediaUrl: '/src/assets/images/angola_samakaka_fashion_1793388060870.jpg',
        mediaType: 'image',
        likes: [
          { userId: 'usr_admin', reaction: 'love' },
          { userId: 'usr_manuel', reaction: 'like' }
        ],
        comments: [
          {
            id: 'comm_3',
            authorId: 'usr_manuel',
            text: 'Espetacular o acabamento! Já disponível para encomenda no Marketplace?',
            createdAt: '2026-03-11T09:15:00.000Z'
          }
        ],
        sharesCount: 7,
        savedBy: ['usr_admin'],
        hashtags: ['ModaAngolana', 'Samakaka', 'Cultura', 'LuandaModa'],
        province: 'Luanda',
        createdAt: '2026-03-11T09:00:00.000Z'
      },
      {
        id: 'post_3',
        authorId: 'usr_manuel',
        content: 'Dia produtivo em Benguela! A comunidade tech do litoral angolano está a crescer a passos largos. Quem estiver a desenvolver projectos de impacto em Angola, envie mensagem para marcarmos um encontro e debatermos ideias! 💡🇦🇴 #Benguela #Inovacao #StartupsAngola',
        mediaType: 'none',
        likes: [
          { userId: 'usr_admin', reaction: 'angola' },
          { userId: 'usr_maria', reaction: 'fire' }
        ],
        comments: [],
        sharesCount: 3,
        savedBy: [],
        hashtags: ['Benguela', 'Inovacao', 'StartupsAngola'],
        province: 'Benguela',
        createdAt: '2026-03-12T11:20:00.000Z'
      }
    ];

    const stories: Story[] = [
      {
        id: 'story_1',
        authorId: 'usr_maria',
        mediaUrl: '/src/assets/images/angola_samakaka_fashion_1793388060870.jpg',
        mediaType: 'image',
        textContent: 'Novidades no ateliê hoje! ✨',
        privacy: 'public',
        views: [{ userId: 'usr_manuel', viewedAt: now }, { userId: 'usr_admin', viewedAt: now }],
        reactions: [{ userId: 'usr_manuel', emoji: '🔥' }],
        createdAt: now
      },
      {
        id: 'story_2',
        authorId: 'usr_admin',
        mediaUrl: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        mediaType: 'image',
        textContent: 'Luanda ao fim do dia. Linda nossa terra 🇦🇴',
        privacy: 'public',
        views: [{ userId: 'usr_maria', viewedAt: now }],
        reactions: [{ userId: 'usr_maria', emoji: '❤️' }],
        createdAt: now
      }
    ];

    const conversations: Conversation[] = [
      {
        id: 'conv_general',
        type: 'direct',
        participantIds: ['usr_admin', 'usr_maria'],
        updatedAt: now,
        lastMessage: 'Olá Maria! Como está a receção da nova coleção?',
        lastMessageTime: now
      },
      {
        id: 'conv_group_luanda',
        type: 'group',
        name: 'Comunidade Criativa Angola 🇦🇴',
        avatar: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        participantIds: ['usr_admin', 'usr_maria', 'usr_manuel', 'usr_rosa'],
        adminIds: ['usr_admin'],
        updatedAt: now,
        lastMessage: 'Bem-vindos a todos ao grupo oficial!',
        lastMessageTime: now
      }
    ];

    const messages: Message[] = [
      {
        id: 'msg_1',
        conversationId: 'conv_general',
        senderId: 'usr_admin',
        text: 'Olá Maria! Como está a receção da nova coleção?',
        type: 'text',
        reactions: [{ userId: 'usr_maria', emoji: '🙌' }],
        status: 'read',
        deliveredTo: ['usr_maria'],
        readBy: ['usr_maria'],
        deletedFor: [],
        createdAt: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: 'msg_2',
        conversationId: 'conv_general',
        senderId: 'usr_maria',
        text: 'Está maravilhosa! As peças em Samakaka estão a ter enorme procura no Marketplace do Angola Connect.',
        type: 'text',
        reactions: [],
        status: 'read',
        deliveredTo: ['usr_admin'],
        readBy: ['usr_admin'],
        deletedFor: [],
        createdAt: new Date(Date.now() - 1800000).toISOString()
      },
      {
        id: 'msg_3',
        conversationId: 'conv_group_luanda',
        senderId: 'usr_admin',
        text: 'Bem-vindos a todos ao grupo oficial! Partilhem aqui os vossos projectos e eventos culturais.',
        type: 'text',
        reactions: [{ userId: 'usr_manuel', emoji: '🚀' }],
        status: 'read',
        deliveredTo: ['usr_maria', 'usr_manuel', 'usr_rosa'],
        readBy: ['usr_maria', 'usr_manuel'],
        deletedFor: [],
        createdAt: new Date(Date.now() - 7200000).toISOString()
      }
    ];

    const groups: GroupCommunity[] = [
      {
        id: 'grp_tech',
        name: 'Startups & Tecnologia Angola 💻',
        description: 'Ponto de encontro dos programadores, fundadores de startups e inovadores de todas as províncias de Angola.',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        avatar: '/src/assets/images/angola_user_manuel_1793388060300.jpg',
        category: 'Tecnologia',
        isPrivate: false,
        creatorId: 'usr_manuel',
        adminIds: ['usr_manuel', 'usr_admin'],
        memberIds: ['usr_manuel', 'usr_admin', 'usr_maria'],
        pendingMemberIds: [],
        rules: [
          'Respeito mútuo entre todos os membros.',
          'Partilhar oportunidades reais e projectos funcionais.',
          'Sem spam ou anúncios enganosos.'
        ],
        province: 'Luanda',
        createdAt: '2026-02-01T00:00:00.000Z'
      },
      {
        id: 'grp_cultura',
        name: 'Música, Semba & Kizomba 🎵',
        description: 'Espaço dedicado aos ritmos nacionais, novos talentos musicais e eventos culturais em Angola.',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        avatar: '/src/assets/images/angola_user_maria_1793388059496.jpg',
        category: 'Arte & Cultura',
        isPrivate: false,
        creatorId: 'usr_maria',
        adminIds: ['usr_maria'],
        memberIds: ['usr_maria', 'usr_admin', 'usr_rosa'],
        pendingMemberIds: [],
        rules: [
          'Promoção da cultura e artistas angolanos.',
          'Divulgação com links autênticos.'
        ],
        province: 'Luanda',
        createdAt: '2026-02-05T00:00:00.000Z'
      }
    ];

    const pages: PageProfile[] = [
      {
        id: 'page_samakaka',
        name: 'Samakaka Couture Luanda',
        handle: 'samakakacouture',
        category: 'Moda & Vestuário',
        description: 'Design contemporâneo angolano valorizando o tecido tradicional e o artesanato autêntico.',
        avatar: '/src/assets/images/angola_samakaka_fashion_1793388060870.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        ownerId: 'usr_maria',
        followers: ['usr_admin', 'usr_manuel', 'usr_rosa'],
        contactEmail: 'contacto@samakaka.ao',
        contactPhone: '+244924112233',
        province: 'Luanda',
        metrics: {
          viewsThisWeek: 1420,
          reach: 8900,
          engagementRate: '8.4%'
        },
        createdAt: '2026-02-12T00:00:00.000Z'
      },
      {
        id: 'page_angolatech',
        name: 'Angola Inovação & Tech Hub',
        handle: 'angolatech',
        category: 'Inovação & Empresas',
        description: 'Plataforma de aceleração e notícias do ecossistema tecnológico angolano.',
        avatar: '/src/assets/images/angola_user_manuel_1793388060300.jpg',
        coverImage: '/src/assets/images/luanda_skyline_banner_1793388059121.jpg',
        ownerId: 'usr_manuel',
        followers: ['usr_admin', 'usr_maria'],
        contactEmail: 'info@angolatech.ao',
        contactPhone: '+244935445566',
        province: 'Luanda',
        metrics: {
          viewsThisWeek: 3100,
          reach: 15400,
          engagementRate: '11.2%'
        },
        createdAt: '2026-02-20T00:00:00.000Z'
      }
    ];

    const marketplace: MarketplaceItem[] = [
      {
        id: 'mkt_1',
        sellerId: 'usr_maria',
        title: 'Casaco & Conjunto Samakaka Exclusivo',
        description: 'Conjunto completo confeccionado artesanalmente com tecido Samakaka genuíno de alta qualidade. Tamanhos M e L disponíveis.',
        price: 45000,
        currency: 'AOA',
        category: 'Moda & Beleza',
        province: 'Luanda',
        images: ['/src/assets/images/angola_samakaka_fashion_1793388060870.jpg'],
        condition: 'Novo',
        contactPhone: '+244924112233',
        sold: false,
        createdAt: '2026-03-05T00:00:00.000Z'
      },
      {
        id: 'mkt_2',
        sellerId: 'usr_manuel',
        title: 'MacBook Air M2 16GB / 512GB Impecável',
        description: 'Equipamento em estado irrepreensível, bateria a 98%, teclado português, com carregador original e caixa. Ideal para trabalho e desenvolvimento.',
        price: 950000,
        currency: 'AOA',
        category: 'Telefones & Tecnologia',
        province: 'Benguela',
        images: ['/src/assets/images/angola_user_manuel_1793388060300.jpg'],
        condition: 'Usado como novo',
        contactPhone: '+244935445566',
        sold: false,
        createdAt: '2026-03-08T00:00:00.000Z'
      },
      {
        id: 'mkt_3',
        sellerId: 'usr_admin',
        title: 'Apartamento T3 com Vista Baía de Luanda',
        description: 'Excelente apartamento com acabamentos modernos, estacionamento privativo e segurança 24h na baixa de Luanda.',
        price: 85000000,
        currency: 'AOA',
        category: 'Imóveis',
        province: 'Luanda',
        images: ['/src/assets/images/luanda_skyline_banner_1793388059121.jpg'],
        condition: 'Bom estado',
        contactPhone: '+244923000001',
        sold: false,
        createdAt: '2026-03-09T00:00:00.000Z'
      }
    ];

    const notifications: NotificationItem[] = [
      {
        id: 'notif_1',
        userId: 'usr_admin',
        fromUserId: 'usr_maria',
        type: 'comment',
        targetId: 'post_1',
        text: 'comentou a sua publicação de boas-vindas.',
        read: false,
        createdAt: '2026-03-10T14:31:00.000Z'
      },
      {
        id: 'notif_2',
        userId: 'usr_admin',
        fromUserId: 'usr_manuel',
        type: 'like',
        targetId: 'post_1',
        text: 'reagiu com fogo à sua publicação.',
        read: true,
        createdAt: '2026-03-10T14:46:00.000Z'
      }
    ];

    return {
      users,
      verificationCodes: [],
      posts,
      stories,
      conversations,
      messages,
      friendRequests: [],
      groups,
      pages,
      marketplace,
      callLogs: [],
      notifications,
      reports: []
    };
  }
}

export const db = new Database();
