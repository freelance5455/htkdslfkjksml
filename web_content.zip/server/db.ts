import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { hashPassword } from './security.ts';

const dbPath = process.env.DATABASE_PATH || path.resolve(process.cwd(), 'data', 'social_boost.db');
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initializeDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL DEFAULT '',
      password_hash TEXT NOT NULL,
      wallet_balance_paise INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS admin_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'operations_admin' CHECK (role IN ('super_admin', 'operations_admin', 'support_admin')),
      permissions_json TEXT NOT NULL DEFAULT '["all"]',
      is_active INTEGER NOT NULL DEFAULT 1,
      last_login_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      compliance_note TEXT NOT NULL,
      reference_quantity INTEGER NOT NULL,
      reference_price_paise INTEGER NOT NULL,
      min_quantity INTEGER NOT NULL DEFAULT 100,
      max_quantity INTEGER NOT NULL DEFAULT 500000,
      estimated_turnaround TEXT NOT NULL DEFAULT '24–72 hours',
      is_active INTEGER NOT NULL DEFAULT 1,
      policy_approved INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_code TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      service_id INTEGER NOT NULL,
      service_name_snapshot TEXT NOT NULL,
      target_url TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      reference_quantity_snapshot INTEGER NOT NULL,
      reference_price_paise_snapshot INTEGER NOT NULL,
      total_amount_paise INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'awaiting_payment' CHECK (status IN ('awaiting_payment', 'queued', 'in_progress', 'completed', 'payment_failed', 'refunded', 'cancelled')),
      payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid', 'pending', 'paid', 'failed', 'refunded')),
      progress_percent INTEGER NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (service_id) REFERENCES services(id)
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payment_code TEXT NOT NULL UNIQUE,
      order_id INTEGER,
      user_id INTEGER NOT NULL,
      purpose TEXT NOT NULL DEFAULT 'order_payment' CHECK (purpose IN ('order_payment', 'wallet_topup')),
      gateway TEXT NOT NULL DEFAULT 'upi_direct' CHECK (gateway IN ('upi_direct', 'razorpay', 'wallet', 'demo_razorpay')),
      gateway_order_id TEXT NOT NULL UNIQUE,
      gateway_payment_id TEXT,
      method TEXT NOT NULL DEFAULT 'upi' CHECK (method IN ('upi', 'gpay', 'phonepe', 'paytm', 'card_netbanking', 'wallet')),
      amount_paise INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'INR',
      status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'pending', 'captured', 'failed', 'refunded')),
      webhook_verified INTEGER NOT NULL DEFAULT 0,
      webhook_event_id TEXT,
      receipt_number TEXT,
      utr_number TEXT,
      failure_reason TEXT,
      verified_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (order_id) REFERENCES orders(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS refunds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      refund_code TEXT NOT NULL UNIQUE,
      payment_id INTEGER NOT NULL,
      order_id INTEGER,
      user_id INTEGER NOT NULL,
      admin_id INTEGER NOT NULL,
      amount_paise INTEGER NOT NULL,
      reason TEXT NOT NULL,
      destination TEXT NOT NULL DEFAULT 'wallet' CHECK (destination IN ('wallet', 'original_source')),
      status TEXT NOT NULL DEFAULT 'processed' CHECK (status IN ('processed', 'pending', 'failed')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (payment_id) REFERENCES payments(id),
      FOREIGN KEY (order_id) REFERENCES orders(id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (admin_id) REFERENCES admin_accounts(id)
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tx_code TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      order_id INTEGER,
      payment_id INTEGER,
      refund_id INTEGER,
      type TEXT NOT NULL CHECK (type IN ('order_payment', 'wallet_topup', 'wallet_debit', 'refund_credit')),
      direction TEXT NOT NULL CHECK (direction IN ('credit', 'debit')),
      amount_paise INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed')),
      description TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (order_id) REFERENCES orders(id),
      FOREIGN KEY (payment_id) REFERENCES payments(id),
      FOREIGN KEY (refund_id) REFERENCES refunds(id)
    );

    CREATE TABLE IF NOT EXISTS support_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_code TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      order_id INTEGER,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      admin_reply TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_review', 'resolved')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (order_id) REFERENCES orders(id)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_type TEXT NOT NULL CHECK (actor_type IN ('customer', 'admin', 'webhook', 'system')),
      actor_id INTEGER,
      actor_email TEXT NOT NULL DEFAULT '',
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      ip_address TEXT NOT NULL DEFAULT '',
      metadata_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS payment_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      merchant_upi_id TEXT NOT NULL DEFAULT '',
      merchant_name TEXT NOT NULL DEFAULT 'SOCIAL BOOST',
      upi_direct_enabled INTEGER NOT NULL DEFAULT 1,
      upi_qr_image_data TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const paymentCols = db.prepare('PRAGMA table_info(payments)').all() as Array<{ name: string }>;
  if (!paymentCols.some((c) => c.name === 'utr_number')) {
    db.exec('ALTER TABLE payments ADD COLUMN utr_number TEXT');
  }

  const settingCols = db.prepare('PRAGMA table_info(payment_settings)').all() as Array<{ name: string }>;
  if (!settingCols.some((c) => c.name === 'upi_qr_image_data')) {
    db.exec("ALTER TABLE payment_settings ADD COLUMN upi_qr_image_data TEXT NOT NULL DEFAULT ''");
  }

  seedInitialData();
}

function seedInitialData(): void {
  const settingsRow = db.prepare('SELECT id FROM payment_settings WHERE id = 1').get();
  if (!settingsRow) {
    db.prepare(`
      INSERT INTO payment_settings (id, merchant_upi_id, merchant_name, upi_direct_enabled)
      VALUES (1, ?, 'SOCIAL BOOST', 1)
    `).run(process.env.MERCHANT_UPI_ID || 'socialboost@okaxis');
  }

  const serviceCount = db.prepare('SELECT COUNT(*) as count FROM services').get() as { count: number };
  if (serviceCount.count === 0) {
    const insertService = db.prepare(`
      INSERT INTO services (
        slug, name, category, description, compliance_note,
        reference_quantity, reference_price_paise, min_quantity, max_quantity,
        estimated_turnaround, is_active, policy_approved
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertService.run(
      'views',
      'Views',
      'Reach & Impressions',
      'Promote your reel or video post across curated creator discovery feeds to accelerate authentic organic reach.',
      'Compliant content distribution. No bot traffic or password required.',
      10000,
      1000, // ₹10
      1000,
      1000000,
      '12–48 hours',
      1,
      1,
    );

    insertService.run(
      'likes',
      'Likes',
      'Post Amplification',
      'Boost content visibility in niche interest communities through compliant creator showcase placements.',
      'Platform-policy compliant promotion. Does not guarantee artificial interaction.',
      1000,
      2000, // ₹20
      100,
      250000,
      '12–36 hours',
      1,
      1,
    );

    insertService.run(
      'followers-standard',
      'Followers – standard',
      'Audience Growth',
      'Standard creator profile spotlight campaign designed to connect your public handle with relevant niche audiences.',
      'Discovery-based campaign. Organic follow-through varies by content quality.',
      1000,
      20000, // ₹200
      100,
      100000,
      '24–72 hours',
      1,
      1,
    );

    insertService.run(
      'followers-refill',
      'Followers – refill package',
      'Audience Growth Plus',
      'Extended creator spotlight campaign with 30-day campaign pacing support and audience retention monitoring.',
      'Policy-compliant extended placement. No artificial follower guarantees.',
      1000,
      30000, // ₹300
      100,
      100000,
      '24–96 hours',
      1,
      1,
    );
  }

  const SOLE_ADMIN_ID = 'rudra@1941';
  const existingRudra = db
    .prepare('SELECT id FROM admin_accounts WHERE lower(email) = ?')
    .get(SOLE_ADMIN_ID) as { id: number } | undefined;

  if (!existingRudra) {
    const legacyAdmin = db.prepare('SELECT id FROM admin_accounts ORDER BY id ASC LIMIT 1').get() as
      | { id: number }
      | undefined;

    if (legacyAdmin) {
      db.prepare(`
        UPDATE admin_accounts
        SET name = 'Administrator',
            email = ?,
            password_hash = ?,
            role = 'super_admin',
            permissions_json = ?,
            is_active = 1
        WHERE id = ?
      `).run(
        SOLE_ADMIN_ID,
        hashPassword('tuku@1941'),
        JSON.stringify(['customers', 'orders', 'services', 'payments', 'refunds', 'support', 'audit']),
        legacyAdmin.id,
      );
    } else {
      db.prepare(`
        INSERT INTO admin_accounts (name, email, password_hash, role, permissions_json, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
      `).run(
        'Administrator',
        SOLE_ADMIN_ID,
        hashPassword('tuku@1941'),
        'super_admin',
        JSON.stringify(['customers', 'orders', 'services', 'payments', 'refunds', 'support', 'audit']),
      );
    }
  } else {
    db.prepare(`
      UPDATE admin_accounts
      SET password_hash = ?,
          role = 'super_admin',
          is_active = 1
      WHERE id = ?
    `).run(hashPassword('tuku@1941'), existingRudra.id);
  }

  // Ensure no other admin account can ever authenticate
  db.prepare('UPDATE admin_accounts SET is_active = 0 WHERE lower(email) != ?').run(SOLE_ADMIN_ID);
  db.prepare('DELETE FROM admin_accounts WHERE lower(email) != ? AND id NOT IN (SELECT admin_id FROM refunds)').run(
    SOLE_ADMIN_ID,
  );

  // Remove any previously seeded demo accounts and their sample records cleanly
  const demoEmails = ['demo@socialboost.in', 'kabir@creatorstudio.in'];
  const demoUsers = db
    .prepare(`SELECT id FROM users WHERE lower(email) IN (?, ?)`)
    .all(...demoEmails) as Array<{ id: number }>;

  if (demoUsers.length > 0) {
    const demoUserIds = demoUsers.map((u) => u.id);
    const placeholders = demoUserIds.map(() => '?').join(', ');
    db.transaction(() => {
      db.prepare(`DELETE FROM support_tickets WHERE user_id IN (${placeholders})`).run(...demoUserIds);
      db.prepare(`DELETE FROM transactions WHERE user_id IN (${placeholders})`).run(...demoUserIds);
      db.prepare(`DELETE FROM refunds WHERE user_id IN (${placeholders})`).run(...demoUserIds);
      db.prepare(`DELETE FROM payments WHERE user_id IN (${placeholders})`).run(...demoUserIds);
      db.prepare(`DELETE FROM orders WHERE user_id IN (${placeholders})`).run(...demoUserIds);
      db.prepare(`DELETE FROM users WHERE id IN (${placeholders})`).run(...demoUserIds);
    })();
  }
}
