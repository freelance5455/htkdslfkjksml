import { and, asc, desc, eq, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  barrelReceipts,
  customers,
  InsertCustomer,
  InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listCustomers() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(customers).orderBy(asc(customers.name));
}

export async function createCustomer(input: InsertCustomer) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(customers).values(input);
  const created = await db.select().from(customers).orderBy(desc(customers.id)).limit(1);
  return created[0];
}

export async function updateCustomer(id: number, input: Partial<InsertCustomer>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(customers).set(input).where(eq(customers.id, id));
  const updated = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return updated[0];
}

export async function deleteCustomer(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const history = await db
    .select({ id: barrelReceipts.id })
    .from(barrelReceipts)
    .where(eq(barrelReceipts.customerId, id))
    .limit(1);
  if (history.length > 0) {
    throw new Error("This customer has barrel history and cannot be deleted.");
  }
  await db.delete(customers).where(eq(customers.id, id));
  return { success: true };
}

export async function listReceipts(startDate?: string, endDate?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const filters = [];
  if (startDate) filters.push(gte(barrelReceipts.receiptDate, startDate));
  if (endDate) filters.push(lte(barrelReceipts.receiptDate, endDate));
  const condition = filters.length > 0 ? and(...filters) : undefined;

  return db
    .select({
      id: barrelReceipts.id,
      customerId: barrelReceipts.customerId,
      customerName: customers.name,
      receiptDate: barrelReceipts.receiptDate,
      quantity: barrelReceipts.quantity,
      note: barrelReceipts.note,
      createdAt: barrelReceipts.createdAt,
    })
    .from(barrelReceipts)
    .leftJoin(customers, eq(barrelReceipts.customerId, customers.id))
    .where(condition)
    .orderBy(desc(barrelReceipts.receiptDate), desc(barrelReceipts.id));
}

export async function createReceipt(input: { customerId: number; receiptDate: string; quantity: number; note?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const customer = await db.select({ id: customers.id }).from(customers).where(eq(customers.id, input.customerId)).limit(1);
  if (customer.length === 0) throw new Error("Customer not found.");
  await db.insert(barrelReceipts).values(input);
  return { success: true };
}

export async function updateReceipt(id: number, input: { customerId: number; receiptDate: string; quantity: number; note?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existingReceipt = await db.select({ id: barrelReceipts.id }).from(barrelReceipts).where(eq(barrelReceipts.id, id)).limit(1);
  if (existingReceipt.length === 0) throw new Error("Receipt not found.");
  const customer = await db.select({ id: customers.id }).from(customers).where(eq(customers.id, input.customerId)).limit(1);
  if (customer.length === 0) throw new Error("Customer not found.");
  await db.update(barrelReceipts).set(input).where(eq(barrelReceipts.id, id));
  return { success: true };
}

export async function deleteReceipt(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(barrelReceipts).where(eq(barrelReceipts.id, id));
  return { success: true };
}
