import fs from "fs";
import path from "path";
import crypto from "crypto";

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "database.json");
const STORAGE_DIR = process.env.STORAGE_DIR || path.join(DATA_DIR, "storage");
const BACKUPS_DIR = path.join(DATA_DIR, "backups");

export type JobStatus = "queued" | "processing" | "completed" | "failed" | "cancelled";
export type JobType =
  | "TEXT_TO_VIDEO"
  | "IMAGE_TO_VIDEO"
  | "TEXT_TO_IMAGE"
  | "TEXT_TO_SPEECH"
  | "TEXT_TO_MUSIC"
  | "SCRIPT_TO_VIDEO"
  | "RENDER"
  | string;

export interface GenerationJobRecord {
  id: string;
  userId?: string;
  projectId?: string;
  provider: string; // e.g. "PIXVERSE" | "RUNWAY" | "LUMA" | "HAILUO" | "KLING" | "GEMINI"
  providerJobId?: string;
  type: JobType;
  prompt: string;
  negativePrompt?: string;
  inputFileUrl?: string;
  outputFileUrl?: string;
  status: JobStatus;
  progress: number;
  stepLabel?: string;
  errorCode?: string;
  errorMessage?: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  duration?: number;
  resolution?: string;
  aspectRatio?: string;
  creditsUsed?: number;
  metadata?: Record<string, unknown>;
  // Legacy / Orchestrator compat
  providerId?: string;
  providerName?: string;
  model?: string;
  input?: unknown;
  output?: unknown;
  error?: string;
  durationMs?: number;
}

export interface MediaAssetRecord {
  id: string;
  projectId?: string;
  userId?: string;
  fileType: "video" | "image" | "audio" | "thumbnail" | "script" | "export";
  type: string;
  name: string;
  storagePath?: string;
  url: string;
  publicUrl?: string;
  mimeType?: string;
  size?: number;
  duration?: number;
  width?: number;
  height?: number;
  provider?: string;
  model?: string;
  prompt?: string;
  thumbnailUrl?: string;
  status: string;
  createdAt: string;
}

export interface DatabaseSchema {
  version: number;
  users: Array<{
    id: string;
    email: string;
    name: string;
    role: "OWNER" | "ADMIN" | "EDITOR" | "VIEWER";
    passwordHash: string;
    salt: string;
    createdAt: string;
    lastLoginAt?: string;
  }>;
  sessions: Array<{
    token: string;
    userId: string;
    createdAt: string;
    expiresAt: string;
    userAgent?: string;
    ip?: string;
  }>;
  projects: Array<Record<string, unknown>>;
  ideas: Array<Record<string, unknown>>;
  calendarEvents: Array<Record<string, unknown>>;
  brandKit: Record<string, unknown>;
  creatorMemory: Record<string, unknown>;
  mediaAssets: Array<MediaAssetRecord>;
  jobs: Array<GenerationJobRecord>;
  socialChannels: Array<Record<string, unknown>>;
  publishingJobs: Array<Record<string, unknown>>;
  series: Array<Record<string, unknown>>;
  characters: Array<Record<string, unknown>>;
  auditLogs: Array<{
    id: string;
    action: string;
    userId?: string;
    userEmail?: string;
    details?: string;
    ip?: string;
    timestamp: string;
  }>;
}

const INITIAL_PROJECTS = [
  {
    id: "proj-seed-1",
    title: "Animais Mais Lindos Cantando: O Show da Fazendinha Mágica",
    description: "Vídeo musical alegre e educativo de animais fofos cantando e dançando juntos na natureza encantada",
    status: "COMPLETED",
    contentType: "CHILDREN_VIDEO",
    platform: "YOUTUBE",
    outputFormats: ["YOUTUBE_1080p", "SHORTS_1080p", "INSTAGRAM_PORTRAIT", "TIKTOK_PORTRAIT"],
    tags: ["infantil", "musica", "animais", "kids", "cantando", "fofura"],
    characters: [],
    brief: {
      id: "brief-seed-1",
      title: "Animais Mais Lindos Cantando — Especial da Natureza",
      concept: "Uma apresentação musical colorida e animada com animais fofinhos cantando uma melodia alegre sobre a harmonia da fazenda e da floresta.",
      targetAudience: "Crianças de 2 a 8 anos e famílias",
      tone: "Alegre, acolhedor, vibrante, musical e mágico",
      keyPoints: [
        "Apresentação dos animais cantores (pato, gatinho, coelho e passarinho)",
        "Refrão contagiante e ritmo dançante",
        "Cores brilhantes e cenários naturais ensolarados",
        "Mensagem de amizade e alegria",
      ],
      duration: 180,
      visualStyle: "3D Animation Pixar/Disney style, ultra colorful, soft warm lighting, cute animal faces",
      narrativeArc: "O sol nasce na fazenda, os animais acordam e começam a afinar seus instrumentos para o grande concerto da manhã.",
      status: "APPROVED",
    },
    script: {
      id: "script-seed-1",
      scenes: [
        {
          id: "sc-1",
          number: 1,
          visual: "Plano geral da fazenda mágica ao nascer do sol com flores brilhantes e o galinho afinando a voz no celeiro.",
          audio: "Efeito sonoro de passarinhos cantando e acordes suaves de violão acústico.",
          narration: "Bom dia, amiguinhos! Hoje é um dia muito especial no vale dos animais cantores!",
          duration: 15,
        },
        {
          id: "sc-2",
          number: 2,
          visual: "Um patinho amarelo com cartola e um coelhinho fofo cantando no microfone feito de girassol.",
          audio: "Quá-quá melodioso e ritmo de xilofone animado.",
          narration: "Vem com a gente cantar a canção mais fofa do mundo!",
          duration: 25,
        },
        {
          id: "sc-3",
          number: 3,
          visual: "Todos os animais juntos dançando em roda no gramado com borboletas luminosas voando ao redor.",
          audio: "Refrão completo orquestrado com palmas e coro infantil.",
          narration: "A natureza é nossa festa, vem dançar sem parar!",
          duration: 35,
        },
      ],
      estimatedDuration: 180,
    },
    storyboard: {
      id: "sb-seed-1",
      scenes: [
        {
          id: "scene-1",
          sceneNumber: 1,
          description: "Cenário idílico com o sol nascendo e um coro de animais fofos afinando a voz com microfones florais",
          prompt: "Cute Pixar style cartoon animals singing in a sunny flower field, vibrant colors, morning golden hour light, highly detailed 3D render",
          imageUrl: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80",
          duration: 15,
        },
        {
          id: "scene-2",
          sceneNumber: 2,
          description: "Close-up do patinho amarelo sorridente e um coelho felpudo cantando com expressão de pura alegria",
          prompt: "Close up of adorable fluffy bunny and yellow duckling singing with tiny microphones in fantasy meadow, Disney Pixar style, 8k",
          imageUrl: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=800&auto=format&fit=crop&q=80",
          duration: 25,
        },
        {
          id: "scene-3",
          sceneNumber: 3,
          description: "Grande final com todos os animais abraçados cantando sob um arco-íris brilhante",
          prompt: "Ensemble of cute baby animals singing together under a bright magical rainbow, confetti, warm celebration, 3d animation render",
          imageUrl: "https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=800&auto=format&fit=crop&q=80",
          duration: 35,
        },
      ],
    },
    assets: [
      { id: "asset-1", projectId: "proj-seed-1", type: "VIDEO", status: "COMPLETED", name: "Cena 1 - Nascer do Sol na Fazenda", duration: 15, url: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80", createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
      { id: "asset-2", projectId: "proj-seed-1", type: "VOICE", status: "COMPLETED", name: "Narração Infantil & Canção Musical", duration: 60, createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
      { id: "asset-3", projectId: "proj-seed-1", type: "IMAGE", status: "COMPLETED", name: "Thumbnail Oficial - Animais Cantores", url: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80", createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
    ],
    tasks: [],
    versions: [],
    conversation: [],
    settings: { language: "PT_BR", outputFormat: "YOUTUBE_1080p", autoEdit: true, autoSubtitles: true, watermark: false },
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: "proj-seed-2",
    title: "Short: 5 Fatos Surpreendentes Sobre o Espaço e o Cosmos",
    description: "Cria um Short para YouTube sobre curiosidades científicas e buracos negros",
    status: "COMPLETED",
    contentType: "SHORT",
    platform: "YOUTUBE",
    outputFormats: ["SHORTS_1080p"],
    tags: ["curiosidades", "ciencia", "shorts"],
    characters: [],
    assets: [
      { id: "asset-3", projectId: "proj-seed-2", type: "VIDEO", status: "COMPLETED", name: "Cena Espaço 4K", duration: 10, createdAt: new Date(Date.now() - 1 * 86400000).toISOString() },
    ],
    tasks: [],
    versions: [],
    conversation: [],
    settings: { language: "PT_BR", outputFormat: "SHORTS_1080p", autoEdit: true, autoSubtitles: true, watermark: false },
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
];

class DatabaseEngine {
  private data: DatabaseSchema;
  private initialized = false;

  constructor() {
    this.data = this.getDefaultSchema();
  }

  private getDefaultSchema(): DatabaseSchema {
    const ownerEmail = process.env.OWNER_EMAIL || "sadraquengola7@gmail.com";
    const salt = crypto.randomBytes(16).toString("hex");
    const defaultPass = process.env.OWNER_PASSWORD || "SadraqueNgola@2025";
    const passwordHash = crypto.scryptSync(defaultPass, salt, 64).toString("hex");

    return {
      version: 1,
      users: [
        {
          id: "owner-sadraque-ngola",
          email: ownerEmail.toLowerCase(),
          name: "Sadraque Ngola",
          role: "OWNER",
          passwordHash,
          salt,
          createdAt: new Date().toISOString(),
        },
        {
          id: "owner-sadraque-ngola-alt",
          email: "sadraquengola83@gmail.com",
          name: "Sadraque Ngola",
          role: "OWNER",
          passwordHash,
          salt,
          createdAt: new Date().toISOString(),
        },
      ],
      sessions: [],
      projects: INITIAL_PROJECTS,
      ideas: [
        {
          id: "idea-1",
          title: "Top 7 Segredos do Universo Explicados para Crianças",
          concept: "Animação cósmica dinâmica com planetas falantes ensinando gravidade de forma mágica.",
          category: "EDUCATIONAL",
          platform: "YOUTUBE",
          format: "VIDEO_1080p",
          viralScore: 94,
          audience: "Crianças e Famílias",
          estimatedEffort: "Médio",
          tags: ["universo", "infantil", "educativo", "estrelas"],
          createdAt: new Date().toISOString(),
        },
        {
          id: "idea-2",
          title: "Desafio Musical dos Sons da Floresta Encantada",
          concept: "Interativo com perguntas e respostas sonoras para o público adivinhar cada bicho.",
          category: "ENTERTAINMENT",
          platform: "TIKTOK",
          format: "SHORT_VERTICAL",
          viralScore: 98,
          audience: "Geral & Kids",
          estimatedEffort: "Rápido",
          tags: ["desafio", "musica", "interativo"],
          createdAt: new Date().toISOString(),
        },
      ],
      calendarEvents: [
        {
          id: "cal-1",
          projectId: "proj-seed-1",
          title: "Estreia: O Show da Fazendinha Mágica",
          platform: "YOUTUBE",
          scheduledDate: new Date(Date.now() + 86400000 * 2).toISOString(),
          status: "SCHEDULED",
          time: "10:00",
        },
      ],
      brandKit: {
        id: "brand-sadraque-main",
        name: "Sadraque Ngola Studio Brand",
        colors: [
          { name: "Primária", value: "#3b82f6", role: "primary" },
          { name: "Secundária", value: "#8b5cf6", role: "secondary" },
          { name: "Destaque", value: "#f59e0b", role: "accent" },
          { name: "Fundo", value: "#08080f", role: "background" },
        ],
        fonts: [
          { name: "Space Grotesk", role: "heading" },
          { name: "Inter", role: "body" },
        ],
        contentPreferences: [
          "Animação 3D amigável estilo Pixar",
          "Músicas educativas e lúdicas",
          "Cores acolhedoras e luminosas",
        ],
        updatedAt: new Date().toISOString(),
      },
      creatorMemory: {
        language: "PT_BR",
        defaultPlatform: "YOUTUBE",
        preferredStyle: "Dinâmico e moderno",
        preferredTone: "ENERGETIC",
        defaultOutputFormat: "YOUTUBE_1080p",
        contentPreferences: ["Vídeos infantis musicais", "Shorts virais", "Educativo interativo"],
        updatedAt: new Date().toISOString(),
      },
      mediaAssets: [],
      socialChannels: [
        {
          id: "ch-youtube-main",
          platform: "YOUTUBE",
          name: "Sadraque Ngola Studio",
          handle: "@sadraquengolastudio",
          avatar: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=100&auto=format&fit=crop&q=80",
          status: "CONNECTED",
          subscriberCount: 14200,
          connectedAt: new Date().toISOString(),
          lastSyncAt: new Date().toISOString(),
        },
      ],
      publishingJobs: [],
      series: [
        {
          id: "series-fazendinha-1",
          title: "A Fazendinha Mágica Musical",
          description: "Série animada de aventuras musicais com animais cantores promovendo amizade e aprendizado.",
          season: 1,
          episodesCount: 12,
          targetAudience: "Crianças de 2 a 8 anos",
          continuityNotes: "Manter o patinho com a mesma cartola amarela e a iluminação ensolarada padrão Pixar.",
          status: "IN_PRODUCTION",
          createdAt: new Date().toISOString(),
        },
      ],
      characters: [
        {
          id: "char-pato-amarelo",
          name: "Patinho Quaquá",
          role: "Protagonista Cantor",
          visualPrompt: "Adorable yellow cartoon duckling wearing a tiny blue top hat, big expressive eyes, 3D Pixar style render, fluffy feathers",
          voiceTone: "Alegre e melódico",
          bio: "O maestro da fazendinha mágica, adora cantar e ensinar novas canções.",
          referenceImageUrl: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=600&auto=format&fit=crop&q=80",
          traits: ["Otimista", "Curioso", "Musical"],
          createdAt: new Date().toISOString(),
        },
      ],
      auditLogs: [
        {
          id: "audit-init-1",
          action: "SYSTEM_INITIALIZED",
          userEmail: ownerEmail,
          details: "AI Creator Studio Core 4.0 Database Engine initialized securely",
          timestamp: new Date().toISOString(),
        },
      ],
      jobs: [],
    };
  }

  public async init(): Promise<void> {
    if (this.initialized) return;

    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (!fs.existsSync(STORAGE_DIR)) {
        fs.mkdirSync(STORAGE_DIR, { recursive: true });
      }
      const storageSubdirs = ["projects", "videos", "images", "audio", "thumbnails", "exports"];
      for (const sub of storageSubdirs) {
        const subPath = path.join(STORAGE_DIR, sub);
        if (!fs.existsSync(subPath)) {
          fs.mkdirSync(subPath, { recursive: true });
        }
      }
      if (!fs.existsSync(BACKUPS_DIR)) {
        fs.mkdirSync(BACKUPS_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, "utf-8");
        const parsed = JSON.parse(raw) as DatabaseSchema;
        this.data = {
          ...this.getDefaultSchema(),
          ...parsed,
        };
        this.data.jobs = Array.isArray(this.data.jobs) ? this.data.jobs : [];
        this.data.mediaAssets = Array.isArray(this.data.mediaAssets) ? this.data.mediaAssets : [];
      } else {
        this.data = this.getDefaultSchema();
        await this.persist();
      }
      this.initialized = true;
      console.log(`[Database] Initialized successfully at ${DB_FILE}`);
    } catch (error) {
      console.error("[Database] Initialization error:", error);
      this.data = this.getDefaultSchema();
      this.initialized = true;
    }
  }

  private async persist(): Promise<void> {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const tmpFile = `${DB_FILE}.tmp`;
      const serialized = JSON.stringify(this.data, null, 2);
      await fs.promises.writeFile(tmpFile, serialized, "utf-8");
      await fs.promises.rename(tmpFile, DB_FILE);
    } catch (error) {
      console.error("[Database] Error persisting database to disk:", error);
    }
  }

  // --- USERS & AUTH ---
  public async getUserByEmail(email: string) {
    await this.init();
    if (!email) return undefined;
    const normalized = email.trim().toLowerCase();
    return this.data.users.find((u) => u.email.toLowerCase() === normalized);
  }

  public async getUserById(id: string) {
    await this.init();
    return this.data.users.find((u) => u.id === id);
  }

  public async createUser(userData: {
    name: string;
    email: string;
    role?: "OWNER" | "ADMIN" | "CREATOR";
    password?: string;
  }) {
    await this.init();
    const normalized = (userData.email || "sadraquengola83@gmail.com").trim().toLowerCase();
    const existing = this.data.users.find((u) => u.email.toLowerCase() === normalized);
    if (existing) {
      if (userData.name) existing.name = userData.name.trim();
      await this.persist();
      return existing;
    }

    const salt = crypto.randomBytes(16).toString("hex");
    const rawPass = userData.password || process.env.OWNER_PASSWORD || "SadraqueNgola@2025";
    const passwordHash = crypto.scryptSync(rawPass, salt, 64).toString("hex");

    const newUser = {
      id: `usr_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
      email: normalized,
      name: (userData.name || "Sadraque Ngola").trim(),
      role: (userData.role || "OWNER") as "OWNER" | "ADMIN" | "CREATOR",
      passwordHash,
      salt,
      createdAt: new Date().toISOString(),
    };

    this.data.users.push(newUser);
    await this.persist();
    return newUser;
  }

  public async upsertUser(userData: {
    name: string;
    email: string;
    role?: "OWNER" | "ADMIN" | "CREATOR";
  }) {
    return this.createUser(userData);
  }

  public async createSession(userId: string, userAgent?: string, ip?: string) {
    await this.init();
    const token = `acs_sec_${crypto.randomBytes(32).toString("hex")}`;
    const session = {
      token,
      userId,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      userAgent,
      ip,
    };
    this.data.sessions.push(session);
    await this.persist();
    return session;
  }

  public async getSession(token: string) {
    await this.init();
    if (!token) return null;
    const session = this.data.sessions.find((s) => s.token === token);
    if (!session) return null;
    if (new Date(session.expiresAt) < new Date()) {
      await this.revokeSession(token);
      return null;
    }
    const user = await this.getUserById(session.userId);
    if (!user) return null;
    return { session, user };
  }

  public async revokeSession(token: string) {
    await this.init();
    this.data.sessions = this.data.sessions.filter((s) => s.token !== token);
    await this.persist();
  }

  // --- PROJECTS ---
  public async getProjects() {
    await this.init();
    return this.data.projects;
  }

  public async getProjectById(id: string) {
    await this.init();
    return this.data.projects.find((p) => p.id === id);
  }

  public async saveProject(project: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.projects.findIndex((p) => p.id === project.id);
    const updated = { ...project, updatedAt: new Date().toISOString() };
    if (idx >= 0) {
      this.data.projects[idx] = updated;
    } else {
      this.data.projects.unshift(updated);
    }
    await this.persist();
    return updated;
  }

  public async deleteProject(id: string) {
    await this.init();
    // 1. Remove project record
    this.data.projects = this.data.projects.filter((p) => p.id !== id);

    // 2. Remove and clean all media assets related to this project
    const relatedAssets = this.data.mediaAssets.filter((a) => a.projectId === id);
    for (const asset of relatedAssets) {
      if (asset.storagePath && fs.existsSync(asset.storagePath)) {
        try {
          fs.unlinkSync(asset.storagePath);
        } catch (e) {
          console.warn(`[Database] Could not unlink project asset file ${asset.storagePath}:`, e);
        }
      }
    }
    this.data.mediaAssets = this.data.mediaAssets.filter((a) => a.projectId !== id);

    // 3. Remove associated jobs
    if (this.data.jobs) {
      this.data.jobs = this.data.jobs.filter((j) => j.projectId !== id);
    }

    await this.persist();
    return true;
  }

  // --- IDEAS ---
  public async getIdeas() {
    await this.init();
    return this.data.ideas;
  }

  public async saveIdea(idea: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.ideas.findIndex((i) => i.id === idea.id);
    if (idx >= 0) {
      this.data.ideas[idx] = idea;
    } else {
      this.data.ideas.unshift(idea);
    }
    await this.persist();
    return idea;
  }

  public async deleteIdea(id: string) {
    await this.init();
    this.data.ideas = this.data.ideas.filter((i) => i.id !== id);
    await this.persist();
    return true;
  }

  // --- CALENDAR ---
  public async getCalendarEvents() {
    await this.init();
    return this.data.calendarEvents;
  }

  public async saveCalendarEvent(event: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.calendarEvents.findIndex((e) => e.id === event.id);
    if (idx >= 0) {
      this.data.calendarEvents[idx] = event;
    } else {
      this.data.calendarEvents.push(event);
    }
    await this.persist();
    return event;
  }

  public async deleteCalendarEvent(id: string) {
    await this.init();
    this.data.calendarEvents = this.data.calendarEvents.filter((e) => e.id !== id);
    await this.persist();
    return true;
  }

  // --- BRAND KIT ---
  public async getBrandKit() {
    await this.init();
    return this.data.brandKit;
  }

  public async saveBrandKit(kit: Record<string, unknown>) {
    await this.init();
    this.data.brandKit = { ...kit, updatedAt: new Date().toISOString() };
    await this.persist();
    return this.data.brandKit;
  }

  // --- CREATOR MEMORY ---
  public async getCreatorMemory() {
    await this.init();
    return this.data.creatorMemory;
  }

  public async saveCreatorMemory(memory: Record<string, unknown>) {
    await this.init();
    this.data.creatorMemory = { ...memory, updatedAt: new Date().toISOString() };
    await this.persist();
    return this.data.creatorMemory;
  }

  // --- MEDIA ASSETS ---
  public async getMediaAssets(projectId?: string) {
    await this.init();
    if (projectId) {
      return this.data.mediaAssets.filter((a) => a.projectId === projectId);
    }
    return this.data.mediaAssets;
  }

  public async getMediaAssetById(id: string) {
    await this.init();
    return this.data.mediaAssets.find((a) => a.id === id);
  }

  public async saveMediaAsset(asset: DBSchema["mediaAssets"][0]) {
    await this.init();
    const idx = this.data.mediaAssets.findIndex((a) => a.id === asset.id);
    if (idx >= 0) {
      this.data.mediaAssets[idx] = asset;
    } else {
      this.data.mediaAssets.unshift(asset);
    }
    await this.persist();
    return asset;
  }

  public async createMediaAsset(asset: DBSchema["mediaAssets"][0]) {
    return this.saveMediaAsset(asset);
  }

  public async deleteMediaAsset(id: string) {
    await this.init();
    const asset = this.data.mediaAssets.find((a) => a.id === id);
    if (asset?.storagePath && fs.existsSync(asset.storagePath)) {
      try {
        fs.unlinkSync(asset.storagePath);
      } catch (e) {
        console.warn(`[Database] Could not unlink asset file ${asset.storagePath}:`, e);
      }
    }
    this.data.mediaAssets = this.data.mediaAssets.filter((a) => a.id !== id);
    await this.persist();
    return asset;
  }

  // --- ASYNC AI JOBS PERSISTENCE ---
  public async getJobs(projectId?: string, status?: string, limit = 100) {
    await this.init();
    let list = this.data.jobs || [];
    if (projectId) {
      list = list.filter((j) => j.projectId === projectId);
    }
    if (status) {
      list = list.filter((j) => j.status === status);
    }
    return list
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  public async getJobById(id: string) {
    await this.init();
    return (this.data.jobs || []).find((j) => j.id === id);
  }

  public async saveJob(job: DBSchema["jobs"][0]) {
    await this.init();
    if (!this.data.jobs) this.data.jobs = [];
    const idx = this.data.jobs.findIndex((j) => j.id === job.id);
    if (idx >= 0) {
      this.data.jobs[idx] = job;
    } else {
      this.data.jobs.unshift(job);
    }
    await this.persist();
    return job;
  }

  public async updateJob(id: string, updates: Partial<DBSchema["jobs"][0]>) {
    await this.init();
    if (!this.data.jobs) this.data.jobs = [];
    const idx = this.data.jobs.findIndex((j) => j.id === id);
    if (idx >= 0) {
      this.data.jobs[idx] = { ...this.data.jobs[idx], ...updates };
      await this.persist();
      return this.data.jobs[idx];
    }
    return undefined;
  }

  public async deleteJob(id: string) {
    await this.init();
    if (!this.data.jobs) return false;
    this.data.jobs = this.data.jobs.filter((j) => j.id !== id);
    await this.persist();
    return true;
  }

  // --- CHANNELS & PUBLISHING ---
  public async getChannels() {
    await this.init();
    return this.data.socialChannels;
  }

  public async saveChannel(channel: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.socialChannels.findIndex((c) => c.id === channel.id);
    if (idx >= 0) {
      this.data.socialChannels[idx] = channel;
    } else {
      this.data.socialChannels.push(channel);
    }
    await this.persist();
    return channel;
  }

  public async getPublishingJobs() {
    await this.init();
    return this.data.publishingJobs;
  }

  public async savePublishingJob(job: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.publishingJobs.findIndex((j) => j.id === job.id);
    if (idx >= 0) {
      this.data.publishingJobs[idx] = job;
    } else {
      this.data.publishingJobs.unshift(job);
    }
    await this.persist();
    return job;
  }

  // --- SERIES & CHARACTERS ---
  public async getSeries() {
    await this.init();
    return this.data.series;
  }

  public async saveSeries(seriesItem: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.series.findIndex((s) => s.id === seriesItem.id);
    if (idx >= 0) {
      this.data.series[idx] = seriesItem;
    } else {
      this.data.series.unshift(seriesItem);
    }
    await this.persist();
    return seriesItem;
  }

  public async getCharacters() {
    await this.init();
    return this.data.characters;
  }

  public async saveCharacter(character: Record<string, unknown> & { id: string }) {
    await this.init();
    const idx = this.data.characters.findIndex((c) => c.id === character.id);
    if (idx >= 0) {
      this.data.characters[idx] = character;
    } else {
      this.data.characters.unshift(character);
    }
    await this.persist();
    return character;
  }

  // --- AUDIT LOGS ---
  public async logAudit(action: string, options: { userId?: string; userEmail?: string; details?: string; ip?: string } = {}) {
    await this.init();
    const entry = {
      id: `log_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
      action,
      userId: options.userId,
      userEmail: options.userEmail,
      details: options.details,
      ip: options.ip,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(entry);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    await this.persist();
    return entry;
  }

  public async getAuditLogs(limit = 100) {
    await this.init();
    return this.data.auditLogs.slice(0, limit);
  }

  // --- CLIENT MIGRATION & SYNC ---
  public async syncFromClient(clientPayload: {
    projects?: Array<Record<string, unknown> & { id: string }>;
    ideas?: Array<Record<string, unknown> & { id: string }>;
    calendar?: Array<Record<string, unknown> & { id: string }>;
    brandKit?: Record<string, unknown>;
    creatorMemory?: Record<string, unknown>;
    mediaLibrary?: Array<DBSchema["mediaAssets"][0]>;
  }) {
    await this.init();
    let migratedCount = 0;

    if (Array.isArray(clientPayload.projects) && clientPayload.projects.length > 0) {
      for (const proj of clientPayload.projects) {
        if (!proj.id) continue;
        const exists = this.data.projects.find((p) => p.id === proj.id);
        if (!exists) {
          this.data.projects.push(proj);
          migratedCount++;
        }
      }
    }

    if (Array.isArray(clientPayload.ideas) && clientPayload.ideas.length > 0) {
      for (const idea of clientPayload.ideas) {
        if (!idea.id) continue;
        const exists = this.data.ideas.find((i) => i.id === idea.id);
        if (!exists) {
          this.data.ideas.push(idea);
          migratedCount++;
        }
      }
    }

    if (Array.isArray(clientPayload.calendar) && clientPayload.calendar.length > 0) {
      for (const cal of clientPayload.calendar) {
        if (!cal.id) continue;
        const exists = this.data.calendarEvents.find((c) => c.id === cal.id);
        if (!exists) {
          this.data.calendarEvents.push(cal);
          migratedCount++;
        }
      }
    }

    if (Array.isArray(clientPayload.mediaLibrary) && clientPayload.mediaLibrary.length > 0) {
      for (const asset of clientPayload.mediaLibrary) {
        if (!asset.id) continue;
        const exists = this.data.mediaAssets.find((a) => a.id === asset.id);
        if (!exists) {
          this.data.mediaAssets.push(asset);
          migratedCount++;
        }
      }
    }

    await this.persist();
    return { success: true, migratedItems: migratedCount };
  }

  public async getStats() {
    await this.init();
    return {
      totalProjects: this.data.projects.length,
      totalAssets: this.data.mediaAssets.length,
      totalJobs: (this.data.jobs || []).length,
      totalUsers: this.data.users.length,
      totalIdeas: this.data.ideas.length,
      totalEvents: this.data.calendarEvents.length,
      totalLogs: this.data.auditLogs.length,
    };
  }

  public getStorageDir() {
    return STORAGE_DIR;
  }
}

export const db = new DatabaseEngine();
