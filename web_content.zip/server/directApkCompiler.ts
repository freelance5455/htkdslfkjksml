import AdmZip from 'adm-zip';
import { execFile } from 'child_process';
import fs from 'fs';
import path from 'path';
import { promisify } from 'util';
import {
  resolveForegroundSource,
  resolveIconSourceForDensity,
  type ApkProjectConfig,
} from './androidGenerator.ts';
import { sanitizeHexColor, sanitizeXmlText, validateAndroidPackageName } from './security.ts';

const execFileAsync = promisify(execFile);

const MIPMAP_DENSITIES = [
  'mipmap-mdpi',
  'mipmap-hdpi',
  'mipmap-xhdpi',
  'mipmap-xxhdpi',
  'mipmap-xxxhdpi',
] as const;

export interface DirectSdkTools {
  available: boolean;
  sdkDir: string;
  buildToolsDir: string;
  androidJar: string;
  aapt2: string;
  d8: string;
  zipalign: string;
  apksigner: string;
  javac: string;
  keytool: string;
}

export function findDirectSdkTools(): DirectSdkTools {
  const sdkDir =
    process.env.ANDROID_HOME ||
    process.env.ANDROID_SDK_ROOT ||
    (fs.existsSync('/opt/android-sdk') ? '/opt/android-sdk' : '');

  const buildToolsRoot = sdkDir ? path.join(sdkDir, 'build-tools') : '';
  let buildToolsDir = '';
  if (buildToolsRoot && fs.existsSync(buildToolsRoot)) {
    const versions = fs.readdirSync(buildToolsRoot).sort().reverse();
    if (versions.length > 0) {
      buildToolsDir = path.join(buildToolsRoot, versions[0]);
    }
  }

  const platformsRoot = sdkDir ? path.join(sdkDir, 'platforms') : '';
  let androidJar = '';
  if (platformsRoot && fs.existsSync(platformsRoot)) {
    const plats = fs.readdirSync(platformsRoot).sort().reverse();
    for (const p of plats) {
      const candidate = path.join(platformsRoot, p, 'android.jar');
      if (fs.existsSync(candidate)) {
        androidJar = candidate;
        break;
      }
    }
  }

  const aapt2 = buildToolsDir ? path.join(buildToolsDir, 'aapt2') : '';
  const d8 = buildToolsDir ? path.join(buildToolsDir, 'd8') : '';
  const zipalign = buildToolsDir ? path.join(buildToolsDir, 'zipalign') : '';
  const apksigner = buildToolsDir ? path.join(buildToolsDir, 'apksigner') : '';

  const javacCandidates = ['/usr/bin/javac', '/usr/lib/jvm/java-17-openjdk-amd64/bin/javac'];
  const javac = javacCandidates.find((p) => fs.existsSync(p)) || '';
  const keytoolCandidates = ['/usr/bin/keytool', '/usr/lib/jvm/java-17-openjdk-amd64/bin/keytool'];
  const keytool = keytoolCandidates.find((p) => fs.existsSync(p)) || '';

  const available = Boolean(
    androidJar &&
      fs.existsSync(aapt2) &&
      fs.existsSync(d8) &&
      fs.existsSync(zipalign) &&
      fs.existsSync(apksigner) &&
      javac &&
      keytool
  );

  return {
    available,
    sdkDir,
    buildToolsDir,
    androidJar,
    aapt2,
    d8,
    zipalign,
    apksigner,
    javac,
    keytool,
  };
}

function copyDirRecursive(srcDir: string, destDir: string): void {
  fs.mkdirSync(destDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    if (entry.name.startsWith('__studio_meta')) continue;
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, destPath);
    } else if (entry.isFile()) {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

async function ensureSigningKeystore(keytoolPath: string): Promise<string> {
  const dataDir = path.resolve(process.cwd(), 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  const ksPath = path.join(dataDir, 'studio-debug.p12');
  if (fs.existsSync(ksPath)) return ksPath;

  await execFileAsync(keytoolPath, [
    '-genkeypair',
    '-v',
    '-keystore',
    ksPath,
    '-storetype',
    'PKCS12',
    '-storepass',
    'android123',
    '-keypass',
    'android123',
    '-alias',
    'htmltoapkstudio',
    '-keyalg',
    'RSA',
    '-keysize',
    '2048',
    '-validity',
    '10000',
    '-dname',
    'CN=HTML to APK Studio, O=HTML to APK Studio, C=TR',
  ]);

  return ksPath;
}

export async function compileDirectAndroidApk(params: {
  workDir: string;
  projectStorageDir: string;
  entryFile: string;
  config: ApkProjectConfig;
  outputApkPath: string;
  onLog: (level: 'info' | 'success' | 'warn' | 'error', msg: string) => void;
}): Promise<void> {
  const { workDir, projectStorageDir, entryFile, config, outputApkPath, onLog } = params;
  const tools = findDirectSdkTools();
  if (!tools.available) {
    throw new Error('Android SDK build-tools (aapt2/d8/apksigner) veya JDK bulunamadı.');
  }

  const pkgCheck = validateAndroidPackageName(config.packageName);
  if (!pkgCheck.valid) {
    throw new Error(pkgCheck.reason || 'Geçersiz paket adı.');
  }

  const directDir = path.join(workDir, '__direct_apk');
  const resDir = path.join(directDir, 'res');
  const assetsWwwDir = path.join(directDir, 'assets', 'www');
  const srcDir = path.join(directDir, 'src');
  const genJavaDir = path.join(directDir, 'gen_java');
  const classesDir = path.join(directDir, 'classes');
  const dexDir = path.join(directDir, 'dex_out');

  fs.mkdirSync(resDir, { recursive: true });
  fs.mkdirSync(assetsWwwDir, { recursive: true });
  fs.mkdirSync(srcDir, { recursive: true });
  fs.mkdirSync(genJavaDir, { recursive: true });
  fs.mkdirSync(classesDir, { recursive: true });
  fs.mkdirSync(dexDir, { recursive: true });

  const appNameSafe = sanitizeXmlText((config.appName || 'HTML Uygulamam').trim().slice(0, 60));
  const splashTitleSafe = sanitizeXmlText((config.splashTitle || config.appName || 'Yükleniyor').trim().slice(0, 60));
  const versionNameSafe = (config.versionName || '1.0.0').replace(/[^0-9A-Za-z._-]/g, '').slice(0, 24) || '1.0.0';
  const versionCodeSafe = Math.max(1, Math.min(99999999, Number(config.versionCode) || 1));
  const splashBg = sanitizeHexColor(config.splashBgColor, '#0B1020');
  const statusBarColor = sanitizeHexColor(config.statusBarColor, '#0B1020');
  const navBarColor = sanitizeHexColor(config.navigationBarColor, '#0B1020');
  const adaptiveBgColor = sanitizeHexColor(config.adaptiveBgColor, '#0B1020');
  const splashDuration = Math.max(400, Math.min(5000, Number(config.splashDurationMs) || 1200));
  const adaptiveEnabled = config.adaptiveIconEnabled !== false;
  const offlineEnabled = config.offlineEnabled !== false;
  const entryClean = entryFile.replace(/\\/g, '/').replace(/^\/+/, '') || 'index.html';
  const packagePath = config.packageName.split('.').join('/');

  const writeFile = (rel: string, content: string) => {
    const abs = path.join(directDir, rel);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, 'utf8');
  };

  const orientationAttr =
    config.orientation === 'portrait'
      ? 'android:screenOrientation="portrait"'
      : config.orientation === 'landscape'
      ? 'android:screenOrientation="landscape"'
      : 'android:screenOrientation="unspecified"';

  const internetPerms = config.internetPermission
    ? `    <uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />`
    : '';

  const mainLauncher = !config.splashEnabled
    ? `            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>`
    : '';

  const splashActivityXml = config.splashEnabled
    ? `        <activity
            android:name=".SplashActivity"
            android:exported="true"
            ${orientationAttr}
            android:theme="@style/Theme.AppSplash">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>`
    : '';

  writeFile(
    'AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageName}"
    android:versionCode="${versionCodeSafe}"
    android:versionName="${versionNameSafe}">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />
${internetPerms}

    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:networkSecurityConfig="@xml/network_security_config"
        android:theme="@style/Theme.HtmlToApkApp">

${splashActivityXml}

        <activity
            android:name=".MainActivity"
            android:exported="${config.splashEnabled ? 'false' : 'true'}"
            android:configChanges="orientation|screenSize|keyboardHidden"
            ${orientationAttr}>
${mainLauncher}
        </activity>
    </application>
</manifest>
`
  );

  writeFile(
    'res/xml/network_security_config.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`
  );

  writeFile(
    'res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${appNameSafe}</string>
    <string name="splash_title">${splashTitleSafe}</string>
</resources>
`
  );

  writeFile(
    'res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="status_bar_color">${statusBarColor}</color>
    <color name="nav_bar_color">${navBarColor}</color>
    <color name="splash_bg_color">${splashBg}</color>
    <color name="ic_launcher_background">${adaptiveBgColor}</color>
</resources>
`
  );

  writeFile(
    'res/values/styles.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.HtmlToApkApp" parent="@android:style/Theme.DeviceDefault.NoActionBar">
        <item name="android:statusBarColor">@color/status_bar_color</item>
        <item name="android:navigationBarColor">@color/nav_bar_color</item>
        <item name="android:windowFullscreen">${config.fullscreen ? 'true' : 'false'}</item>
    </style>

    <style name="Theme.AppSplash" parent="@android:style/Theme.DeviceDefault.NoActionBar">
        <item name="android:windowBackground">@color/splash_bg_color</item>
        <item name="android:statusBarColor">@color/splash_bg_color</item>
        <item name="android:navigationBarColor">@color/splash_bg_color</item>
        <item name="android:windowFullscreen">true</item>
    </style>
</resources>
`
  );

  writeFile(
    'res/anim/anim_enter_fade.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<alpha xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="320"
    android:fromAlpha="0.0"
    android:toAlpha="1.0" />
`
  );

  writeFile(
    'res/anim/anim_enter_slide.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<translate xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="340"
    android:fromXDelta="100%"
    android:toXDelta="0%" />
`
  );

  writeFile(
    'res/anim/anim_enter_scale.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<scale xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="320"
    android:fromXScale="0.92"
    android:fromYScale="0.92"
    android:pivotX="50%"
    android:pivotY="50%"
    android:toXScale="1.0"
    android:toYScale="1.0" />
`
  );

  writeFile(
    'res/anim/anim_exit_fade.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<alpha xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="260"
    android:fromAlpha="1.0"
    android:toAlpha="0.0" />
`
  );

  writeFile(
    'res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/root_container"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="${statusBarColor}">

    <WebView
        android:id="@+id/app_webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>
`
  );

  writeFile(
    'res/layout/activity_splash.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/splash_bg_color"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="32dp">

    <ImageView
        android:id="@+id/splash_icon"
        android:layout_width="96dp"
        android:layout_height="96dp"
        android:contentDescription="@string/app_name"
        android:src="@mipmap/ic_launcher" />

    <TextView
        android:id="@+id/splash_label"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="@string/splash_title"
        android:textColor="#F8FAFC"
        android:textSize="22sp"
        android:textStyle="bold" />
</LinearLayout>
`
  );

  // Copy App Icon & Adaptive Icon across all mipmap densities
  const fgSourceAbs = resolveForegroundSource(projectStorageDir, config);
  for (const density of MIPMAP_DENSITIES) {
    const iconSourceAbs = resolveIconSourceForDensity(projectStorageDir, config, density);
    if (iconSourceAbs) {
      const ext = path.extname(iconSourceAbs).toLowerCase() || '.png';
      const dest = path.join(resDir, density, `ic_launcher${ext}`);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(iconSourceAbs, dest);

      const roundDest = path.join(resDir, density, `ic_launcher_round${ext}`);
      fs.copyFileSync(iconSourceAbs, roundDest);
    }

    if (adaptiveEnabled && fgSourceAbs) {
      const fgExt = path.extname(fgSourceAbs).toLowerCase() || '.png';
      const fgDest = path.join(resDir, density, `ic_launcher_foreground${fgExt}`);
      fs.mkdirSync(path.dirname(fgDest), { recursive: true });
      fs.copyFileSync(fgSourceAbs, fgDest);
    }
  }

  if (adaptiveEnabled && fgSourceAbs) {
    const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
`;
    writeFile('res/mipmap-anydpi-v26/ic_launcher.xml', adaptiveXml);
    writeFile('res/mipmap-anydpi-v26/ic_launcher_round.xml', adaptiveXml);
  }

  // Copy HTML/CSS/JS/Media files into assets/www/
  copyDirRecursive(projectStorageDir, assetsWwwDir);

  // MainActivity.java (Hardened Android WebView + local HTTPS asset server + offline support)
  writeFile(
    `src/${packagePath}/MainActivity.java`,
    `package ${config.packageName};

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;
    private static final String LOCAL_APP_ORIGIN = "https://appassets.androidplatform.net";
    private static final boolean INTERNET_ENABLED = ${config.internetPermission ? 'true' : 'false'};
    private static final boolean OFFLINE_ENABLED = ${offlineEnabled ? 'true' : 'false'};

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureSystemBars();

        webView = findViewById(R.id.app_webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowContentAccess(false);

        if (INTERNET_ENABLED && isNetworkAvailable()) {
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        } else if (OFFLINE_ENABLED) {
            settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        } else {
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        }

        WebView.setWebContentsDebuggingEnabled(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null && "appassets.androidplatform.net".equalsIgnoreCase(url.getHost())) {
                    String rawPath = url.getPath();
                    if (rawPath == null || rawPath.isEmpty()) return null;
                    if (rawPath.startsWith("/assets/")) {
                        String assetPath = rawPath.substring("/assets/".length());
                        if (assetPath.contains("..") || assetPath.contains("\\\\")) {
                            return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", null, null);
                        }
                        try {
                            InputStream is = getAssets().open(assetPath);
                            return new WebResourceResponse(guessMimeType(assetPath), "UTF-8", is);
                        } catch (IOException e) {
                            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, null);
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return true;
                String urlStr = uri.toString();
                if (urlStr.startsWith(LOCAL_APP_ORIGIN)) {
                    return false;
                }
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase(Locale.ROOT) : "";
                if ("tel".equals(scheme) || "mailto".equals(scheme) || "sms".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                if (("http".equals(scheme) || "https".equals(scheme)) && INTERNET_ENABLED) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });

        webView.loadUrl(LOCAL_APP_ORIGIN + "/assets/www/${entryClean}");
    }

    private String guessMimeType(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "application/javascript";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".ttf")) return "font/ttf";
        if (lower.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    @SuppressWarnings("deprecation")
    private void configureSystemBars() {
        getWindow().setStatusBarColor(Color.parseColor("${statusBarColor}"));
        getWindow().setNavigationBarColor(Color.parseColor("${navBarColor}"));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                if (${config.fullscreen ? 'true' : 'false'}) {
                    controller.hide(WindowInsets.Type.systemBars());
                } else {
                    if (!${config.statusBarVisible ? 'true' : 'false'}) controller.hide(WindowInsets.Type.statusBars());
                    if (!${config.navigationBarVisible ? 'true' : 'false'}) controller.hide(WindowInsets.Type.navigationBars());
                }
            }
        } else if (${config.fullscreen ? 'true' : 'false'}) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        android.net.Network network = cm.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
`
  );

  if (config.splashEnabled) {
    const animResEnter =
      config.launchAnimation === 'slide'
        ? 'R.anim.anim_enter_slide'
        : config.launchAnimation === 'scale'
        ? 'R.anim.anim_enter_scale'
        : config.launchAnimation === 'fade'
        ? 'R.anim.anim_enter_fade'
        : '0';

    writeFile(
      `src/${packagePath}/SplashActivity.java`,
      `package ${config.packageName};

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

public class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            ${
              animResEnter !== '0'
                ? `overridePendingTransition(${animResEnter}, R.anim.anim_exit_fade);`
                : ''
            }
            finish();
        }, ${splashDuration}L);
    }
}
`
    );
  }

  // Step 1: aapt2 compile resources
  const compiledResZip = path.join(directDir, 'compiled_res.zip');
  onLog('info', 'Android kaynakları ve adaptive ikonlar (aapt2 compile) derleniyor...');
  await execFileAsync(tools.aapt2, ['compile', '--dir', resDir, '-o', compiledResZip], {
    cwd: directDir,
  });

  // Step 2: aapt2 link -> unsigned-unaligned.apk + R.java
  const unsignedUnalignedApk = path.join(directDir, 'unsigned-unaligned.apk');
  onLog('info', 'AndroidManifest.xml ve assets paketleniyor (aapt2 link)...');
  await execFileAsync(
    tools.aapt2,
    [
      'link',
      '-o',
      unsignedUnalignedApk,
      '-I',
      tools.androidJar,
      '--manifest',
      path.join(directDir, 'AndroidManifest.xml'),
      '-A',
      path.join(directDir, 'assets'),
      '--java',
      genJavaDir,
      '-R',
      compiledResZip,
      '--auto-add-overlay',
    ],
    { cwd: directDir }
  );

  // Step 3: javac compile R.java + MainActivity.java (+ SplashActivity.java)
  const javaFiles: string[] = [
    path.join(genJavaDir, packagePath, 'R.java'),
    path.join(srcDir, packagePath, 'MainActivity.java'),
  ];
  if (config.splashEnabled) {
    javaFiles.push(path.join(srcDir, packagePath, 'SplashActivity.java'));
  }

  onLog('info', 'Android WebView sınıfları derleniyor (javac)...');
  await execFileAsync(
    tools.javac,
    ['--release', '11', '-classpath', tools.androidJar, '-d', classesDir, ...javaFiles],
    { cwd: directDir }
  );

  // Step 4: d8 -> classes.dex
  const classFiles: string[] = [];
  const walkClasses = (dir: string) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walkClasses(full);
      else if (entry.name.endsWith('.class')) classFiles.push(full);
    }
  };
  walkClasses(classesDir);

  onLog('info', 'Dalvik bayt kodu üretiliyor (d8 -> classes.dex)...');
  await execFileAsync(
    tools.d8,
    ['--lib', tools.androidJar, '--min-api', '24', '--output', dexDir, ...classFiles],
    { cwd: directDir }
  );

  const classesDex = path.join(dexDir, 'classes.dex');
  if (!fs.existsSync(classesDex)) {
    throw new Error('classes.dex üretilemedi.');
  }

  // Step 5: Inject classes.dex into unsigned APK
  const apkZip = new AdmZip(unsignedUnalignedApk);
  apkZip.addLocalFile(classesDex, '', 'classes.dex');
  apkZip.writeZip(unsignedUnalignedApk);

  // Step 6: zipalign
  const alignedApk = path.join(directDir, 'unsigned-aligned.apk');
  onLog('info', 'APK bellek hizalaması yapılıyor (zipalign)...');
  await execFileAsync(tools.zipalign, ['-f', '-p', '4', unsignedUnalignedApk, alignedApk], {
    cwd: directDir,
  });

  // Step 7: Sign & verify with apksigner
  const keystorePath = await ensureSigningKeystore(tools.keytool);
  onLog('info', 'APK dijital olarak imzalanıyor (apksigner v2/v3)...');
  await execFileAsync(
    tools.apksigner,
    [
      'sign',
      '--ks',
      keystorePath,
      '--ks-pass',
      'pass:android123',
      '--key-pass',
      'pass:android123',
      '--ks-key-alias',
      'htmltoapkstudio',
      '--out',
      outputApkPath,
      alignedApk,
    ],
    { cwd: directDir }
  );

  await execFileAsync(tools.apksigner, ['verify', outputApkPath], { cwd: directDir });
  onLog('success', 'APK imzası ve yapısı apksigner verify ile doğrulandı.');
}
