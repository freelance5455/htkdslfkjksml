import { PNG } from 'pngjs';

function parseHexColor(hex: string): { r: number; g: number; b: number } {
  const cleaned = hex.replace('#', '').trim();
  if (/^[0-9a-fA-F]{6}$/.test(cleaned)) {
    return {
      r: parseInt(cleaned.slice(0, 2), 16),
      g: parseInt(cleaned.slice(2, 4), 16),
      b: parseInt(cleaned.slice(4, 6), 16),
    };
  }
  return { r: 22, g: 163, b: 74 };
}

export function generateServerFallbackPngIcon(themeColor: string, size = 192): Uint8Array {
  const { r, g, b } = parseHexColor(themeColor);
  const png = new PNG({ width: size, height: size });
  const radius = size * 0.22;
  const cx = size / 2;
  const cy = size / 2;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (size * y + x) << 2;
      const dx = Math.max(Math.abs(x - cx) - (size / 2 - radius), 0);
      const dy = Math.max(Math.abs(y - cy) - (size / 2 - radius), 0);
      const dist = Math.hypot(dx, dy);

      if (dist > radius) {
        png.data[idx] = 0;
        png.data[idx + 1] = 0;
        png.data[idx + 2] = 0;
        png.data[idx + 3] = 0;
        continue;
      }

      const nx = x / size;
      const ny = y / size;
      const inOuterRing =
        Math.abs(nx - 0.5) < 0.24 &&
        Math.abs(ny - 0.5) < 0.24 &&
        (Math.abs(nx - 0.5) > 0.17 || Math.abs(ny - 0.5) > 0.17);
      const inInnerDot = Math.hypot(nx - 0.5, ny - 0.5) < 0.085;

      if (inOuterRing || inInnerDot) {
        png.data[idx] = 255;
        png.data[idx + 1] = 255;
        png.data[idx + 2] = 255;
        png.data[idx + 3] = 255;
      } else {
        const factor = 1 - (y / size) * 0.14;
        png.data[idx] = Math.round(r * factor);
        png.data[idx + 1] = Math.round(g * factor);
        png.data[idx + 2] = Math.round(b * factor);
        png.data[idx + 3] = 255;
      }
    }
  }

  return new Uint8Array(PNG.sync.write(png));
}
