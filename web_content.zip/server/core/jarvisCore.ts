import type { JarvisResponse, Capability, Depth } from "../../shared/types.js";
import { planAgent } from "../agents/orchestrator.js";

const capabilityNames = [
  "general-intelligence","context-reasoning","model-router","model-reliability",
  "long-term-memory","memory-retrieval","memory-truthfulness","founder-mode",
  "emotional-expression","multi-chat","projects-workspace","keyboard-input",
  "continuous-microphone","voice-chat","universal-files","pdf-intelligence",
  "document-generation","web-research","website-intelligence",
  "free-resource-discovery","source-verification","image-generation",
  "image-editing","video-generation","video-editing","coding-agent",
  "website-generator","app-generator","deployment-agent","hosting-intelligence",
  "automation","agent-orchestrator","android-assistant","background-operation",
  "screen-awareness","device-control","social-media","security","verification",
  "self-correction","backup-versioning","rollback","autonomous-upgrade",
  "api-access","ai-assistant-access"
];

function depth(message: string): Depth {
  const m = message.toLowerCase();
  if (/research|deep research|comprehensive|thorough/.test(m)) return "RESEARCH";
  if (/deep|very detailed/.test(m)) return "DEEP";
  if (/detail|detailed|vistar|विस्तार/.test(m)) return "DETAILED";
  if (/brief|short|quick/.test(m)) return "BRIEF";
  return "NORMAL";
}

export const jarvisCore = {
  capabilities(): Capability[] {
    return capabilityNames.map(name => ({
      name,
      status: "CONFIG_REQUIRED",
      description: "Integration exists; live provider/device configuration is required."
    }));
  },

  async handle(message: string): Promise<JarvisResponse> {
    if (!message.trim()) {
      return {
        text: "Founder Sir, tell me what you want JARVIS to do.",
        depth: "NORMAL",
        status: "AVAILABLE",
        verification: "VERIFIED",
        actions: []
      };
    }

    const plan = planAgent(message);

    return {
      text:
        `JARVIS received the goal. Plan: ${plan.stages.join(" → ")}. ` +
        `I will only claim a result after the relevant capability is available ` +
        `and the output has been verified.`,
      depth: depth(message),
      status: "CONFIG_REQUIRED",
      verification: "UNVERIFIED",
      actions: plan.stages
    };
  }
};
