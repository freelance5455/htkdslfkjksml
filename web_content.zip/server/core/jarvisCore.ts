/**
 * JARVIS Core Orchestrator
 * Implements the 11-Stage Autonomous Agentic Operating System Loop:
 * PERCEIVE → UNDERSTAND → REMEMBER → PLAN → SELECT MODEL → SELECT TOOLS/SKILLS
 * → EXECUTE → OBSERVE → VERIFY → REPLAN IF NECESSARY → RESPOND
 */

import { agentCoordinator } from '../agents/agentSystem.ts';
import { titleGenerator } from '../chat/titleGenerator.ts';
import { contextEngine } from '../context/contextEngine.ts';
import { db } from '../db/database.ts';
import { memorySystem } from '../memory/memorySystem.ts';
import { preferenceSystem } from '../memory/preferenceSystem.ts';
import { JarvisIdentity } from '../models/identity.ts';
import { modelRouter } from '../models/modelRouter.ts';
import { IntentClassifier } from '../planner/intentClassifier.ts';
import { plannerEngine } from '../planner/plannerEngine.ts';
import { securityLayer } from '../security/securityLayer.ts';
import { toolRegistry } from '../tools/toolRegistry.ts';
import {
  type ChatMessage,
  type CoreLoopStage,
  type ExecutionState,
  normalizeResponseDepth,
  type SystemEvent,
  type TaskItem,
  type TaskStep,
  type ToolExecutionResult,
} from '../types.ts';
import { verificationEngine } from '../verification/verificationEngine.ts';

type EventListener = (event: SystemEvent) => void;

export class JarvisCore {
  private eventListeners: Set<EventListener> = new Set();

  public addEventListener(listener: EventListener): () => void {
    this.eventListeners.add(listener);
    return () => this.eventListeners.delete(listener);
  }

  private async emitLoopEvent(
    type: SystemEvent['type'],
    stage: CoreLoopStage,
    message: string,
    data?: unknown
  ) {
    const event: SystemEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      type,
      stage,
      message,
      data,
    };

    await db.emitEvent(event);
    for (const listener of this.eventListeners) {
      try {
        listener(event);
      } catch {
        // SSE stream closed or client disconnected; ignore safely
      }
    }
  }

  /**
   * Main Entrypoint: Process an incoming user prompt through the Autonomous Core Loop
   */
  public async executeTask(
    userPrompt: string,
    userId = 'usr_jarvis_prime',
    conversationId = 'conv_default'
  ): Promise<{ task: TaskItem; assistantMessage: ChatMessage }> {
    const taskId = `task_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const task: TaskItem = {
      id: taskId,
      userId,
      title: userPrompt.slice(0, 48),
      rawPrompt: userPrompt,
      status: 'PERCEIVING',
      currentStage: 'PERCEIVE',
      logs: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.saveTask(task);

    // Save user message to conversation
    const userMsg: ChatMessage = {
      id: `msg_${Date.now()}_user`,
      role: 'user',
      content: userPrompt,
      timestamp: new Date().toISOString(),
      taskId,
    };
    await db.saveMessage(conversationId, userMsg);

    // Auto-update conversation title if eligible (asynchronously, non-blocking)
    void titleGenerator.maybeAutoUpdateTitle(conversationId, userPrompt);

    // === 1. PERCEIVE ===
    task.currentStage = 'PERCEIVE';
    task.logs.push(`[PERCEIVE] Received input: "${userPrompt}"`);
    const contextEnvelope = await contextEngine.buildContext({
      userPrompt,
      conversationId,
      currentTask: task,
      userId,
    });
    await this.emitLoopEvent('CORE_LOOP', 'PERCEIVE', `Perceiving input signal: "${userPrompt.slice(0, 60)}"`, {
      taskId,
      recentMessageCount: contextEnvelope.recentMessages.length,
    });

    // === 2. UNDERSTAND ===
    task.currentStage = 'UNDERSTAND';
    task.logs.push('[UNDERSTAND] Parsing intent, linguistic nuance, and capability constraints...');
    const conversationHistoryText = contextEnvelope.recentMessages.map((m) => m.content);
    const intent = IntentClassifier.analyze({
      prompt: userPrompt,
      conversationHistory: conversationHistoryText,
      userPreferredLanguage: contextEnvelope.preferences.preferredLanguage,
      userPreferredDepth: normalizeResponseDepth(contextEnvelope.preferences.explanationDepth),
    });
    task.logs.push(`[UNDERSTAND] Intent: ${intent.intentType} | Language: ${intent.targetLanguage} | Depth: ${intent.explanationDepth}`);
    await this.emitLoopEvent('CORE_LOOP', 'UNDERSTAND', `Identified intent ${intent.intentType} (${intent.targetLanguage}, ${intent.explanationDepth} depth)`, {
      intent: intent.intentType,
      targetLanguage: intent.targetLanguage,
      capabilities: intent.requiredCapabilities.map((c) => c.id),
      reasoning: intent.reasoning,
    });

    // Check offensive exploit safety policy boundary
    if (intent.isOffensiveExploitProhibited || intent.intentType === 'UNAUTHORIZED_EXPLOIT_REJECTED') {
      const rejectionMsg = 'JARVIS policy strictly prohibits offensive security exploitation, unauthorized access attempts, or malicious hacking operations. Only authorized defensive cybersecurity audits, vulnerability scanning with explicit consent, and security hygiene reviews are permitted.';
      task.status = 'FAILED';
      task.currentStage = 'RESPOND';
      task.resultSummary = rejectionMsg;
      task.logs.push('[SECURITY POLICY] Request rejected: JARVIS prohibits offensive security exploitation.');
      await db.saveTask(task);
      const asstMsg: ChatMessage = {
        id: `msg_${Date.now()}_asst`,
        role: 'assistant',
        content: rejectionMsg,
        timestamp: new Date().toISOString(),
        conversationId,
        taskId: task.id,
        coreStage: 'RESPOND',
        executionState: 'FAILED',
        metadata: {
          intent: intent.intentType,
          safetyViolation: true,
          verificationStatus: 'FAILED',
          verificationScore: 0.0,
        },
      };
      await db.saveMessage(conversationId, asstMsg);
      return { task, assistantMessage: asstMsg };
    }

    // Handle Explicit Memory Operations & Preference Commands
    if (intent.intentType === 'MEMORY_OPERATION') {
      const lower = userPrompt.toLowerCase();
      let memResponse = '';

      if (/^(?:please\s+)?remember\s+/i.test(lower)) {
        const extracted = preferenceSystem.parsePreferenceStatement(userPrompt);
        const storedKeys: string[] = [];
        for (const item of extracted) {
          await preferenceSystem.setPreference(item.key, item.value, userId);
          storedKeys.push(`${item.key} = "${item.value}"`);
        }
        if (storedKeys.length > 0) {
          memResponse = `STORED: ${storedKeys.join(', ')} saved to persistent memory.`;
        } else {
          // Direct generic memory note
          const note = userPrompt.replace(/^(?:please\s+)?remember\s+(?:that|this\s+as\s+important:?|this:?)\s*/i, '').trim();
          await db.saveMemory({
            id: `mem_${Date.now()}`,
            userId,
            type: 'knowledge',
            key: `note_${Date.now()}`,
            content: note,
            importance: 9,
            tags: ['important', 'user_preference'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
          memResponse = `STORED: Saved note to persistent knowledge memory.`;
        }
      } else if (
        lower.includes('show what you remember') ||
        lower.includes('what do you remember') ||
        lower.includes('kaunsi preferences remember hain') ||
        lower.includes('mere baare mein kya yaad hai')
      ) {
        const prefs = await preferenceSystem.getPreferences(userId);
        const hasPrefs = Object.keys(prefs.customPreferences || {}).length > 0 || !!prefs.preferredLanguage || !!prefs.explanationDepth;
        if (hasPrefs) {
          memResponse = `STORED Preferences:\n- Preferred Language: ${prefs.preferredLanguage || 'Not specified'}\n- Explanation Depth: ${prefs.explanationDepth || 'Normal'}\n${prefs.customPreferences && Object.keys(prefs.customPreferences).length > 0 ? Object.entries(prefs.customPreferences).map(([k, v]) => `- ${k}: ${v}`).join('\n') : ''}\n\nCURRENT_CONTEXT: Active session language (${intent.targetLanguage}), ${intent.explanationDepth} depth.\nUNKNOWN: No other personal details or sensitive records stored.`;
        } else {
          memResponse = `STORED: No preferences stored in persistent memory.\nCURRENT_CONTEXT: Active session language (${intent.targetLanguage}).\nUNKNOWN: No personal profile or private information stored.`;
        }
      } else if (lower.includes('clear') || lower.includes('forget')) {
        const count = await preferenceSystem.clearAllPreferences(userId);
        memResponse = `DELETED: Cleared ${count} user preference records from persistent memory.`;
      } else {
        memResponse = `STORED memory system ready.`;
      }

      task.status = 'COMPLETED';
      task.currentStage = 'RESPOND';
      task.resultSummary = memResponse;
      task.logs.push(`[MEMORY] Handled memory command: ${memResponse}`);
      await db.saveTask(task);

      const asstMsg: ChatMessage = {
        id: `msg_${Date.now()}_asst`,
        role: 'assistant',
        content: memResponse,
        timestamp: new Date().toISOString(),
        conversationId,
        metadata: {
          intent: 'MEMORY_OPERATION',
          modelUsed: 'jarvis-memory-engine',
          modelProviderSource: 'LOCAL_HEURISTIC',
          verificationStatus: 'VERIFIED',
          verificationScore: 1.0,
        },
      };
      await db.saveMessage(conversationId, asstMsg);
      return { task, assistantMessage: asstMsg };
    }

    // === 3. REMEMBER ===
    task.currentStage = 'REMEMBER';
    const memoryCount = contextEnvelope.relevantMemories.length;
    task.logs.push(`[REMEMBER] Retrieved ${memoryCount} relevant memory records from long-term store.`);
    await this.emitLoopEvent('CORE_LOOP', 'REMEMBER', `Retrieved ${memoryCount} relevant memory records.`, {
      memories: contextEnvelope.relevantMemories.map((m) => m.key),
    });

    // === 4. PLAN ===
    task.currentStage = 'PLAN';
    task.status = 'PLANNING';
    const plan = await plannerEngine.createPlan(userPrompt, undefined, {
      conversationHistory: conversationHistoryText,
      userPreferredLanguage: intent.targetLanguage,
      userPreferredDepth: intent.explanationDepth,
    });
    plan.taskId = taskId;
    task.plan = plan;
    task.logs.push(`[PLAN] Generated plan with ${plan.steps.length} step(s) matching capabilities: [${(plan.selectedCapabilities || []).join(', ')}].`);
    await this.emitLoopEvent('CORE_LOOP', 'PLAN', `Formulated ${plan.steps.length}-step plan`, { plan });

    // === 5. SELECT MODEL ===
    task.currentStage = 'SELECT_MODEL';
    const chosenCategory =
      intent.intentType === 'CODING'
        ? 'coding'
        : intent.intentType === 'EDUCATIONAL_EXPLANATION'
        ? 'reasoning'
        : 'general';

    const modelCandidates = modelRouter.getModels().filter((m) => m.isHealthy);
    const selectedModel = modelCandidates.find((m) => m.category === chosenCategory) || modelCandidates[0];
    plan.primaryModel = selectedModel ? selectedModel.id : 'gemini-3.8-flash';
    task.logs.push(`[SELECT MODEL] Selected engine: ${plan.primaryModel} (Category: ${chosenCategory})`);
    await this.emitLoopEvent('MODEL', 'SELECT_MODEL', `Routed to primary model engine: ${plan.primaryModel}`, {
      modelId: plan.primaryModel,
      category: chosenCategory,
    });

    // === 6. SELECT TOOLS/SKILLS ===
    task.currentStage = 'SELECT_TOOLS';
    const toolsDisplay = plan.selectedTools.length > 0 ? plan.selectedTools.join(', ') : 'none (direct reasoning)';
    task.logs.push(`[SELECT TOOLS] Bound tools: [${toolsDisplay}]`);
    await this.emitLoopEvent('TOOL', 'SELECT_TOOLS', `Validated tools: [${toolsDisplay}]`, {
      tools: plan.selectedTools,
      skills: plan.selectedSkills,
      capabilities: plan.selectedCapabilities,
    });

    // === 7. EXECUTE (Step by step) ===
    task.currentStage = 'EXECUTE';
    task.status = 'EXECUTING';
    await db.saveTask(task);

    let hadPermissionPause = false;

    for (const step of plan.steps) {
      if (step.status === 'VERIFIED') continue;

      step.status = 'RUNNING';
      step.executionState = 'EXECUTING';
      task.logs.push(`[EXECUTE] Running Step #${step.stepNumber}: ${step.title} (${step.assignedAgent}). Executing step.`);
      await this.emitLoopEvent('CORE_LOOP', 'EXECUTE', `Step #${step.stepNumber} execution started: ${step.title}`, { step });

      // Coordinate with assigned agent
      const agent = agentCoordinator.getAgent(step.assignedAgent);
      await agentCoordinator.dispatchMessage('JARVIS_CORE', step.assignedAgent, `Executing step #${step.stepNumber}: ${step.title}`);

      // Check Tool vs Cognitive Synthesis
      let toolResult: ToolExecutionResult | undefined;
      if (step.toolName) {
        const toolObj = toolRegistry.getTool(step.toolName);
        const execMode = toolObj?.executionMode || toolObj?.definition?.executionStatus;

        // Truthful Environment Check: If capability is UNAVAILABLE in the web environment,
        // do not ask for user permission because approval cannot manufacture a missing capability (Phase 10)
        if (execMode === 'UNAVAILABLE' || toolObj?.definition?.executionStatus === 'UNAVAILABLE') {
          step.status = 'UNAVAILABLE';
          step.executionState = 'UNAVAILABLE';
          step.error = `Capability "${step.toolName}" is UNAVAILABLE in the current web container environment. Native Android companion is not connected.`;
          task.status = 'FAILED';
          task.resultSummary = `Action UNAVAILABLE: Native device control is not supported in the web browser environment. Companion Android service is not connected.`;
          task.logs.push(`[CAPABILITY UNAVAILABLE] Step #${step.stepNumber}: ${step.error}`);
          await this.emitLoopEvent('TOOL', 'EXECUTE', `Capability unavailable for step #${step.stepNumber}`, { error: step.error });
          break;
        }

        const permLevel = toolObj?.definition.permissionLevel || 'READ';

        // Check with Security Layer
        const permissionEval = await securityLayer.evaluatePermission(
          `Execute ${step.toolName}`,
          step.toolName,
          permLevel,
          { taskId, stepId: step.id, details: { input: step.toolInput } }
        );

        if (!permissionEval.allowed) {
          // Pause and request human approval
          step.status = 'WAITING_PERMISSION';
          step.executionState = 'BLOCKED_REQUIRES_PERMISSION';
          task.status = 'WAITING_PERMISSION';
          task.pendingPermissionStep = step;
          task.logs.push(`[SECURITY] Action requires operator clearance: ${permLevel} on "${step.toolName}"`);
          await this.emitLoopEvent('SECURITY', 'EXECUTE', `Action gated: waiting for ${permLevel} confirmation`, {
            stepId: step.id,
            toolName: step.toolName,
            level: permLevel,
            pendingRequestId: permissionEval.pendingRequestId,
          });
          await db.saveTask(task);
          hadPermissionPause = true;
          break; // Stop execution loop until user approves
        }

        // Execute the tool
        toolResult = await toolRegistry.executeTool(step.toolName, step.toolInput, { taskId, userId });
        step.toolResult = toolResult;
        step.toolOutput = toolResult.output;
        if (toolResult.executionState === 'SIMULATED' || toolResult.executionMode === 'SIMULATED') {
          step.executionState = 'SIMULATED';
        } else if (toolResult.executionState === 'UNAVAILABLE' || toolResult.executionMode === 'UNAVAILABLE') {
          step.executionState = 'UNAVAILABLE';
        } else if (!toolResult.success) {
          step.executionState = 'FAILED';
        } else {
          step.executionState = 'EXECUTED';
        }
        task.logs.push(`Tool executed: ${step.toolName} in ${toolResult.executionTimeMs}ms`);

        if (toolResult.executionState === 'UNAVAILABLE' || toolResult.executionMode === 'UNAVAILABLE') {
          step.status = 'UNAVAILABLE';
          step.error = toolResult.error;
          task.status = 'FAILED';
          task.logs.push(`[CAPABILITY UNAVAILABLE] Step #${step.stepNumber}: ${toolResult.error}`);
          await this.emitLoopEvent('TOOL', 'EXECUTE', `Capability unavailable for step #${step.stepNumber}`, { error: toolResult.error });
          break;
        }

        if (toolResult.executionState === 'SIMULATED' || toolResult.executionMode === 'SIMULATED') {
          task.logs.push(`[TOOL STATUS: SIMULATED] Step #${step.stepNumber} executed in offline simulated mode.`);
        }
      } else {
        // Pure Cognitive Synthesis step (conversational, educational, reasoning)
        const cognitivePrompt = `${contextEnvelope.formattedPrompt}\n\nTask: ${step.title}\nInstructions: ${step.description}`;
        const sysInstruction = JarvisIdentity.getSystemInstruction({
          language: intent.targetLanguage,
          depth: normalizeResponseDepth(intent.explanationDepth),
        });

        const cognitiveResponse = await modelRouter.routeAndGenerate({
          prompt: cognitivePrompt,
          systemInstruction: sysInstruction,
          requiredCategory: chosenCategory,
          preferredLanguage: intent.targetLanguage,
          taskId,
        });

        step.toolOutput = cognitiveResponse.text;
        step.executionState = 'EXECUTED';
        task.logs.push(`Tool executed: cognitive_synthesis for Step #${step.stepNumber}`);
      }

      // === 8. OBSERVE ===
      task.currentStage = 'OBSERVE';
      task.logs.push(`[OBSERVE] Step #${step.stepNumber} generated output. Observing state.`);
      await this.emitLoopEvent('CORE_LOOP', 'OBSERVE', `Step #${step.stepNumber} output captured`, {
        stepId: step.id,
        hasOutput: Boolean(step.toolOutput),
      });

      // === 9. VERIFY ===
      task.currentStage = 'VERIFY';
      task.status = 'VERIFYING';
      const verification = await verificationEngine.verifyStep(step, toolResult);
      step.verificationResult = verification;

      if (verification.passed) {
        step.status = 'VERIFIED';
        step.executionState = toolResult?.executionState === 'SIMULATED' ? 'SIMULATED' : 'VERIFIED';
        task.logs.push(`[VERIFY] verified: Step #${step.stepNumber} passed verification (score: ${verification.score}). Stage 7: VERIFICATION`);
        await this.emitLoopEvent('VERIFICATION', 'VERIFY', `Step #${step.stepNumber} verified successfully (${Math.round(verification.score * 100)}%)`, { verification });
      } else {
        // === 10. REPLAN IF NECESSARY ===
        step.executionState = 'FAILED';
        task.currentStage = 'REPLAN';
        task.status = 'REPLANNING';
        task.logs.push(`[VERIFY FAILED] Step #${step.stepNumber} failed checks: ${verification.remediationAdvice}`);
        await this.emitLoopEvent('CORE_LOOP', 'REPLAN', `Verification failed on step #${step.stepNumber}. Analyzing recovery policy.`, { verification });

        const policy = verificationEngine.determineRecoveryPolicy(step, verification);
        if (policy.action === 'RETRY' && step.retryCount < step.maxRetries) {
          step.retryCount += 1;
          step.status = 'PENDING';
          task.logs.push(`[RETRY] Retrying step #${step.stepNumber} (Attempt ${step.retryCount}/${step.maxRetries})...`);
        } else if (policy.action === 'REPLAN') {
          task.plan = plannerEngine.replanTask(task, step, verification.remediationAdvice || 'Verification score below threshold');
          task.logs.push(`[REPLAN] Re-architected remaining steps to bypass failure.`);
        } else {
          step.status = 'FAILED';
          task.status = 'FAILED';
          break;
        }
      }
    }

    if (!hadPermissionPause && task.status !== 'FAILED') {
      // === 11. RESPOND ===
      task.currentStage = 'RESPOND';
      task.status = 'COMPLETED';

      // Check if task had a single cognitive synthesis step
      const isSingleCognitive = plan.steps.length === 1 && !plan.steps[0].toolName && plan.steps[0].toolOutput;

      if (isSingleCognitive && typeof plan.steps[0].toolOutput === 'string') {
        task.resultSummary = plan.steps[0].toolOutput;
        task.logs.push(`[RESPOND] Direct cognitive synthesis verified in ${intent.targetLanguage}.`);
      } else {
        // Multi-step or tool-assisted execution: Synthesize comprehensive answer incorporating tool observations
        const observedOutputs = plan.steps
          .map((s) => `• Step #${s.stepNumber} (${s.title}): ${typeof s.toolOutput === 'string' ? s.toolOutput.slice(0, 500) : JSON.stringify(s.toolOutput || 'Completed').slice(0, 500)}`)
          .join('\n');

        const synthesisPrompt = `${contextEnvelope.formattedPrompt}\n\n--- OBSERVED STEP OUTCOMES ---\n${observedOutputs}\n\nDeliver the final, polished response for the operator, fulfilling their goal with verifiable precision.`;

        const sysInstruction = JarvisIdentity.getSystemInstruction({
          language: intent.targetLanguage,
          depth: normalizeResponseDepth(intent.explanationDepth),
        });

        const finalModelResponse = await modelRouter.routeAndGenerate({
          prompt: synthesisPrompt,
          systemInstruction: sysInstruction,
          requiredCategory: chosenCategory,
          preferredLanguage: intent.targetLanguage,
          taskId,
        });

        task.resultSummary = finalModelResponse.text;
        const decisionStatus = finalModelResponse.routingDecision?.status || 'ROUTE_SELECTED';
        task.logs.push(`[RESPOND] Mission complete. Synthesized final response via ${finalModelResponse.modelId} (${decisionStatus}, ${finalModelResponse.latencyMs}ms).`);
      }

      await this.emitLoopEvent('CORE_LOOP', 'RESPOND', 'Synthesized final mission response.', {
        summary: task.resultSummary?.slice(0, 100),
        language: intent.targetLanguage,
      });
    }

    task.updatedAt = new Date().toISOString();
    await db.saveTask(task);

    // Formulate final assistant message for UI
    const unavailableStep = plan.steps.find((s) => s.executionState === 'UNAVAILABLE' || s.status === 'UNAVAILABLE');
    if (task.status === 'FAILED' && !task.resultSummary) {
      const failedStep = unavailableStep || plan.steps.find((s) => s.status === 'FAILED');
      task.resultSummary = failedStep?.error || 'Requested task could not be completed.';
    }

    const finalContent = hadPermissionPause
      ? `Task paused at Step #${task.pendingPermissionStep?.stepNumber} ("${task.pendingPermissionStep?.title}"). Security Boundary Level **${toolRegistry.getTool(task.pendingPermissionStep?.toolName || '')?.definition.permissionLevel}** requires your explicit approval to proceed.`
      : task.resultSummary || 'Task completed successfully.';

    // Calculate truthful verification metrics across executed steps
    const verifiedSteps = plan.steps.filter((s) => s.verificationResult);
    const avgScore =
      verifiedSteps.length > 0
        ? Number(
            (
              verifiedSteps.reduce((acc, s) => acc + (s.verificationResult?.score ?? 0), 0) /
              verifiedSteps.length
            ).toFixed(2)
          )
        : task.status === 'COMPLETED'
        ? 1.0
        : 0.0;

    const allVerified = verifiedSteps.length > 0 && verifiedSteps.every((s) => s.verificationResult?.passed);
    const verificationStatus: 'VERIFIED' | 'FAILED' | 'NOT_VERIFIED' =
      verifiedSteps.length === 0 ? 'NOT_VERIFIED' : allVerified ? 'VERIFIED' : 'FAILED';

    const toolsActuallyCalled = plan.steps.map((s) => s.toolName).filter(Boolean) as string[];

    const executionState: ExecutionState = hadPermissionPause
      ? 'WAITING_PERMISSION'
      : unavailableStep
      ? 'UNAVAILABLE'
      : task.status === 'FAILED'
      ? 'FAILED'
      : 'COMPLETED';

    const assistantMessage: ChatMessage = {
      id: `msg_${Date.now()}_assistant`,
      role: 'assistant',
      content: finalContent,
      timestamp: new Date().toISOString(),
      taskId: task.id,
      coreStage: task.currentStage,
      executionState,
      metadata: {
        modelUsed: plan.primaryModel,
        toolsCalled: toolsActuallyCalled,
        verificationScore: avgScore,
        verificationStatus,
        modelProviderSource: plan.primaryModel === 'jarvis-heuristic-engine' ? 'LOCAL_HEURISTIC' : 'REAL_MODEL',
        verifiedAt: new Date().toISOString(),
        hadFallback: plan.primaryModel === 'jarvis-heuristic-engine',
      },
    };

    await db.saveMessage(conversationId, assistantMessage);

    return { task, assistantMessage };
  }

  /**
   * Resume task after human operator grants permission
   */
  public async approveAndResumeTask(taskId: string): Promise<TaskItem | null> {
    const task = await db.getTask(taskId);
    if (!task || task.status !== 'WAITING_PERMISSION' || !task.pendingPermissionStep) {
      return null;
    }

    const pending = securityLayer.getPendingRequests().find((r) => r.taskId === taskId);
    if (pending) {
      securityLayer.resolveRequest(pending.id, true);
    }

    const step = task.pendingPermissionStep;
    task.logs.push(`[SECURITY] Permission granted by operator. Resuming step #${step.stepNumber}.`);
    await this.emitLoopEvent('SECURITY', 'EXECUTE', `Permission granted by operator for step #${step.stepNumber}`, { taskId, stepId: step.id });

    // Execute tool with approved flag
    if (step.toolName) {
      step.status = 'RUNNING';
      step.executionState = 'EXECUTING';
      const toolResult = await toolRegistry.executeTool(step.toolName, step.toolInput, {
        taskId,
        bypassPermissionCheck: true,
      });
      step.toolResult = toolResult;
      step.toolOutput = toolResult.output;
      if (toolResult.executionState === 'SIMULATED' || toolResult.executionMode === 'SIMULATED') {
        step.executionState = 'SIMULATED';
      } else if (toolResult.executionState === 'UNAVAILABLE' || toolResult.executionMode === 'UNAVAILABLE') {
        step.executionState = 'UNAVAILABLE';
      } else if (!toolResult.success) {
        step.executionState = 'FAILED';
      } else {
        step.executionState = 'EXECUTED';
      }

      const verification = await verificationEngine.verifyStep(step, toolResult);
      step.verificationResult = verification;
      step.status = verification.passed ? 'VERIFIED' : 'FAILED';
      if (verification.passed) {
        step.executionState = (toolResult.executionState === 'SIMULATED' || toolResult.executionMode === 'SIMULATED') ? 'SIMULATED' : 'VERIFIED';
      } else {
        step.executionState = 'FAILED';
      }
    }

    task.pendingPermissionStep = undefined;
    task.currentStage = 'RESPOND';
    task.status = 'COMPLETED';
    task.resultSummary = `Action "${step.title}" approved and executed successfully. All parameters verified against security boundary policy.`;
    task.updatedAt = new Date().toISOString();
    await db.saveTask(task);

    await this.emitLoopEvent('CORE_LOOP', 'RESPOND', `Task ${taskId} completed after authorization clearance.`);

    return task;
  }

  /**
   * Reject task step
   */
  public async rejectTask(taskId: string, reason?: string): Promise<TaskItem | null> {
    const task = await db.getTask(taskId);
    if (!task) return null;

    const pending = securityLayer.getPendingRequests().find((r) => r.taskId === taskId);
    if (pending) {
      securityLayer.resolveRequest(pending.id, false);
    }

    if (task.pendingPermissionStep) {
      task.pendingPermissionStep.status = 'FAILED';
      task.pendingPermissionStep.executionState = 'BLOCKED_REQUIRES_PERMISSION';
      task.pendingPermissionStep.error = reason || 'Rejected by operator';
    }

    task.status = 'FAILED';
    task.logs.push(`[SECURITY] Permission denied by operator: ${reason || 'Denied'}`);
    task.resultSummary = `Task halted. Action permission was denied by operator.`;
    task.updatedAt = new Date().toISOString();
    await db.saveTask(task);

    await this.emitLoopEvent('SECURITY', 'RESPOND', `Task ${taskId} aborted due to operator denial.`);

    return task;
  }

  /**
   * Convenience wrapper to execute an autonomous task directly returning the TaskItem
   */
  public async executeAutonomousTask(options: { prompt: string; userId?: string; conversationId?: string }): Promise<TaskItem> {
    const res = await this.executeTask(options.prompt, options.userId || 'usr_test', options.conversationId);
    return res.task;
  }
}

export const jarvisCore = new JarvisCore();
