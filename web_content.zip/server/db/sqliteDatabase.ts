import fs from 'fs';
import { DatabaseSync } from 'node:sqlite';
import path from 'path';

import type {
  AuditLog,
  ChatMessage,
  FileAttachmentEntity,
  GeneratedDocumentEntity,
  MemoryEntry,
  SkillDefinition,
  SystemEvent,
  TaskItem,
  ToolDefinition,
  VerificationResult,
} from '../types.ts';
import {
  DEFAULT_CONVERSATION,
  DEFAULT_MEMORIES,
  DEFAULT_MESSAGE,
  DEFAULT_PROJECT,
  DEFAULT_USER,
  SQLITE_SCHEMA,
} from './schema.ts';
import type {
  AgentRunEntity,
  ConversationEntity,
  DatabaseHealth,
  IDatabase,
  ProjectEntity,
  ToolCallEntity,
  UserEntity,
} from './types.ts';

export class SqliteDatabase implements IDatabase {
  private db: DatabaseSync | null = null;
  private dbPath: string;
  private isInitialized = false;

  constructor(filePath?: string) {
    const dataDir = path.resolve(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.dbPath = filePath || path.join(dataDir, 'jarvis.db');
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized && this.db) {
      return;
    }

    try {
      this.db = new DatabaseSync(this.dbPath);
      this.runSchemaMigrations();
      this.db.exec(SQLITE_SCHEMA);
      this.runSchemaMigrations();
      this.seedDefaults();
      this.isInitialized = true;
      console.log(`[SQLITE] Persistent database initialized at: ${this.dbPath}`);
    } catch (error) {
      console.error('[SQLITE ERROR] Failed to initialize SQLite database:', error);
      throw error;
    }
  }

  private runSchemaMigrations(): void {
    if (!this.db) return;
    const safeExec = (sql: string) => {
      try {
        this.db!.exec(sql);
      } catch {}
    };

    safeExec('ALTER TABLE conversations ADD COLUMN topic TEXT DEFAULT "General"');
    safeExec('ALTER TABLE conversations ADD COLUMN is_archived INTEGER DEFAULT 0');
    safeExec('ALTER TABLE conversations ADD COLUMN is_trash INTEGER DEFAULT 0');
    safeExec('ALTER TABLE conversations ADD COLUMN has_custom_title INTEGER DEFAULT 0');
    safeExec('ALTER TABLE conversations ADD COLUMN project_id TEXT DEFAULT NULL');
    safeExec('ALTER TABLE projects ADD COLUMN context_brief TEXT DEFAULT ""');
    safeExec('ALTER TABLE projects ADD COLUMN is_archived INTEGER DEFAULT 0');
    safeExec('ALTER TABLE projects ADD COLUMN is_trash INTEGER DEFAULT 0');
    safeExec('ALTER TABLE projects ADD COLUMN updated_at TEXT DEFAULT ""');
  }

  private getClient(): DatabaseSync {
    if (!this.db) {
      this.db = new DatabaseSync(this.dbPath);
      this.runSchemaMigrations();
      this.db.exec(SQLITE_SCHEMA);
      this.runSchemaMigrations();
      this.seedDefaults();
      this.isInitialized = true;
    }
    return this.db;
  }

  private seedDefaults(): void {
    if (!this.db) return;

    const countRow = this.db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
    if (countRow && countRow.count > 0) {
      return; // Already seeded
    }

    const insertUser = this.db.prepare(
      'INSERT OR IGNORE INTO users (id, username, name, role, created_at) VALUES (?, ?, ?, ?, ?)'
    );
    insertUser.run(
      DEFAULT_USER.id,
      DEFAULT_USER.username,
      DEFAULT_USER.name,
      DEFAULT_USER.role,
      DEFAULT_USER.createdAt
    );

    const insertConv = this.db.prepare(
      'INSERT OR IGNORE INTO conversations (id, user_id, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
    );
    insertConv.run(
      DEFAULT_CONVERSATION.id,
      DEFAULT_CONVERSATION.userId,
      DEFAULT_CONVERSATION.title,
      DEFAULT_CONVERSATION.createdAt,
      DEFAULT_CONVERSATION.updatedAt
    );

    const insertMsg = this.db.prepare(
      'INSERT OR IGNORE INTO messages (id, conversation_id, role, content, timestamp, metadata) VALUES (?, ?, ?, ?, ?, ?)'
    );
    insertMsg.run(
      DEFAULT_MESSAGE.id,
      DEFAULT_CONVERSATION.id,
      DEFAULT_MESSAGE.role,
      DEFAULT_MESSAGE.content,
      DEFAULT_MESSAGE.timestamp,
      null
    );

    const insertMem = this.db.prepare(
      'INSERT OR IGNORE INTO memories (id, user_id, type, key, content, importance, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    for (const mem of DEFAULT_MEMORIES) {
      insertMem.run(
        mem.id,
        mem.userId,
        mem.type,
        mem.key,
        mem.content,
        mem.importance,
        JSON.stringify(mem.tags || []),
        mem.createdAt,
        mem.updatedAt
      );
    }

    const insertProj = this.db.prepare(
      'INSERT OR IGNORE INTO projects (id, user_id, name, description, status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
    );
    insertProj.run(
      DEFAULT_PROJECT.id,
      DEFAULT_PROJECT.userId,
      DEFAULT_PROJECT.name,
      DEFAULT_PROJECT.description,
      DEFAULT_PROJECT.status,
      DEFAULT_PROJECT.createdAt
    );
  }

  public async getHealth(): Promise<DatabaseHealth> {
    const client = this.getClient();
    const tables = [
      'users',
      'conversations',
      'messages',
      'memories',
      'projects',
      'tasks',
      'tool_calls',
      'agent_runs',
      'verifications',
      'audit_logs',
      'system_events',
    ];

    const recordCounts: Record<string, number> = {};
    for (const t of tables) {
      try {
        const row = client.prepare(`SELECT COUNT(*) as cnt FROM ${t}`).get() as { cnt: number };
        recordCounts[t] = row?.cnt || 0;
      } catch {
        recordCounts[t] = 0;
      }
    }

    return {
      provider: 'sqlite',
      status: 'CONNECTED',
      isPersistent: true,
      databasePathOrHost: this.dbPath,
      totalTables: tables.length,
      recordCounts,
      lastMigration: '2026-09-04-01-initial-sqlite',
    };
  }

  // Users
  public async getUser(id: string): Promise<UserEntity | null> {
    const client = this.getClient();
    const row = client.prepare('SELECT * FROM users WHERE id = ?').get(id) as any;
    if (!row) return null;
    return {
      id: row.id,
      username: row.username,
      name: row.name,
      role: row.role,
      createdAt: row.created_at,
    };
  }

  public async saveUser(user: UserEntity): Promise<UserEntity> {
    const client = this.getClient();
    client
      .prepare(
        'INSERT INTO users (id, username, name, role, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET username=excluded.username, name=excluded.name, role=excluded.role'
      )
      .run(user.id, user.username, user.name, user.role, user.createdAt);
    return user;
  }

  // Conversations & Messages
  public async getConversations(
    userId: string,
    filter?: { projectId?: string; includeArchived?: boolean; includeTrash?: boolean; isTrashOnly?: boolean }
  ): Promise<ConversationEntity[]> {
    const client = this.getClient();
    let query = `
      SELECT c.*, p.name as project_name 
      FROM conversations c 
      LEFT JOIN projects p ON c.project_id = p.id 
      WHERE c.user_id = ?
    `;
    const params: any[] = [userId];

    if (filter?.isTrashOnly) {
      query += ' AND c.is_trash = 1';
    } else if (!filter?.includeTrash) {
      query += ' AND c.is_trash = 0';
    }

    if (filter?.projectId) {
      query += ' AND c.project_id = ?';
      params.push(filter.projectId);
    }

    if (!filter?.includeArchived && !filter?.isTrashOnly) {
      query += ' AND c.is_archived = 0';
    }

    query += ' ORDER BY c.updated_at DESC';

    const rows = client.prepare(query).all(...params) as any[];
    return rows.map((r) => {
      const countRow = client.prepare('SELECT COUNT(*) as cnt FROM messages WHERE conversation_id = ?').get(r.id) as any;
      const lastMsgRow = client.prepare('SELECT content FROM messages WHERE conversation_id = ? ORDER BY timestamp DESC LIMIT 1').get(r.id) as any;
      return {
        id: r.id,
        userId: r.user_id,
        title: r.title,
        topic: r.topic || 'General',
        isArchived: Boolean(r.is_archived),
        isTrash: Boolean(r.is_trash),
        hasCustomTitle: Boolean(r.has_custom_title),
        projectId: r.project_id || undefined,
        projectName: r.project_name || undefined,
        messageCount: countRow?.cnt || 0,
        lastMessageSnippet: lastMsgRow?.content ? (lastMsgRow.content.length > 80 ? lastMsgRow.content.slice(0, 80) + '...' : lastMsgRow.content) : undefined,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      };
    });
  }

  public async getConversation(id: string): Promise<ConversationEntity | null> {
    const client = this.getClient();
    const row = client.prepare(`
      SELECT c.*, p.name as project_name 
      FROM conversations c 
      LEFT JOIN projects p ON c.project_id = p.id 
      WHERE c.id = ?
    `).get(id) as any;
    if (!row) return null;
    return {
      id: row.id,
      userId: row.user_id,
      title: row.title,
      topic: row.topic || 'General',
      isArchived: Boolean(row.is_archived),
      isTrash: Boolean(row.is_trash),
      hasCustomTitle: Boolean(row.has_custom_title),
      projectId: row.project_id || undefined,
      projectName: row.project_name || undefined,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  }

  public async saveConversation(conv: ConversationEntity): Promise<ConversationEntity> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO conversations (id, user_id, title, topic, is_archived, is_trash, has_custom_title, project_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           title = excluded.title,
           topic = excluded.topic,
           is_archived = excluded.is_archived,
           is_trash = excluded.is_trash,
           has_custom_title = excluded.has_custom_title,
           project_id = excluded.project_id,
           updated_at = excluded.updated_at`
      )
      .run(
        conv.id,
        conv.userId,
        conv.title,
        conv.topic || 'General',
        conv.isArchived ? 1 : 0,
        conv.isTrash ? 1 : 0,
        conv.hasCustomTitle ? 1 : 0,
        conv.projectId || null,
        conv.createdAt,
        conv.updatedAt
      );
    return conv;
  }

  public async deleteConversation(id: string): Promise<boolean> {
    const client = this.getClient();
    client.prepare('DELETE FROM messages WHERE conversation_id = ?').run(id);
    const result = client.prepare('DELETE FROM conversations WHERE id = ?').run(id);
    return (result as any)?.changes > 0;
  }

  public async softDeleteConversation(id: string): Promise<boolean> {
    const client = this.getClient();
    const result = client.prepare('UPDATE conversations SET is_trash = 1, updated_at = ? WHERE id = ?').run(new Date().toISOString(), id);
    return (result as any)?.changes > 0;
  }

  public async restoreConversation(id: string): Promise<ConversationEntity | null> {
    const client = this.getClient();
    client.prepare('UPDATE conversations SET is_trash = 0, is_archived = 0, updated_at = ? WHERE id = ?').run(new Date().toISOString(), id);
    return this.getConversation(id);
  }

  public async searchConversations(
    userId: string,
    query: string,
    options?: { projectId?: string; includeArchived?: boolean }
  ): Promise<Array<ConversationEntity & { matchedSnippet?: string }>> {
    const client = this.getClient();
    const cleanQ = query.trim();
    if (!cleanQ) {
      return this.getConversations(userId, options);
    }
    const likePattern = `%${cleanQ}%`;
    let sql = `
      SELECT DISTINCT c.*, p.name as project_name, m.content as matched_content
      FROM conversations c
      LEFT JOIN projects p ON c.project_id = p.id
      LEFT JOIN messages m ON c.id = m.conversation_id AND m.content LIKE ?
      WHERE c.user_id = ?
        AND c.is_trash = 0
        AND (c.title LIKE ? OR c.topic LIKE ? OR m.content LIKE ?)
    `;
    const params: any[] = [likePattern, userId, likePattern, likePattern, likePattern];
    if (options?.projectId) {
      sql += ' AND c.project_id = ?';
      params.push(options.projectId);
    }
    if (!options?.includeArchived) {
      sql += ' AND c.is_archived = 0';
    }
    sql += ' ORDER BY c.updated_at DESC LIMIT 50';

    const rows = client.prepare(sql).all(...params) as any[];
    const seen = new Set<string>();
    const results: Array<ConversationEntity & { matchedSnippet?: string }> = [];

    for (const r of rows) {
      if (seen.has(r.id)) continue;
      seen.add(r.id);
      const countRow = client.prepare('SELECT COUNT(*) as cnt FROM messages WHERE conversation_id = ?').get(r.id) as any;
      
      let snippet: string | undefined;
      if (r.matched_content) {
        const idx = r.matched_content.toLowerCase().indexOf(cleanQ.toLowerCase());
        if (idx !== -1) {
          const start = Math.max(0, idx - 25);
          const end = Math.min(r.matched_content.length, idx + cleanQ.length + 35);
          snippet = (start > 0 ? '...' : '') + r.matched_content.slice(start, end).replace(/\n/g, ' ') + (end < r.matched_content.length ? '...' : '');
        }
      }

      results.push({
        id: r.id,
        userId: r.user_id,
        title: r.title,
        topic: r.topic || 'General',
        isArchived: Boolean(r.is_archived),
        isTrash: Boolean(r.is_trash),
        hasCustomTitle: Boolean(r.has_custom_title),
        projectId: r.project_id || undefined,
        projectName: r.project_name || undefined,
        messageCount: countRow?.cnt || 0,
        matchedSnippet: snippet,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      });
    }

    return results;
  }

  public async getMessages(conversationId: string): Promise<ChatMessage[]> {
    const client = this.getClient();
    const rows = client
      .prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY timestamp ASC')
      .all(conversationId) as any[];
    return rows.map((r) => ({
      id: r.id,
      role: r.role,
      content: r.content,
      timestamp: r.timestamp,
      taskId: r.task_id || undefined,
      coreStage: r.core_stage || undefined,
      metadata: r.metadata ? JSON.parse(r.metadata) : undefined,
    }));
  }

  public async saveMessage(conversationId: string, message: ChatMessage): Promise<void> {
    const client = this.getClient();
    client
      .prepare(
        'INSERT OR IGNORE INTO conversations (id, user_id, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
      )
      .run(conversationId, 'usr_jarvis_prime', 'Active Conversation', new Date().toISOString(), new Date().toISOString());

    client
      .prepare(
        `INSERT INTO messages (id, conversation_id, role, content, timestamp, task_id, core_stage, metadata)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           role = excluded.role,
           content = excluded.content,
           timestamp = excluded.timestamp,
           task_id = excluded.task_id,
           core_stage = excluded.core_stage,
           metadata = excluded.metadata`
      )
      .run(
        message.id,
        conversationId,
        message.role,
        message.content,
        message.timestamp,
        message.taskId || null,
        message.coreStage || null,
        message.metadata ? JSON.stringify(message.metadata) : null
      );

    // Update conversation updatedAt timestamp
    client
      .prepare('UPDATE conversations SET updated_at = ? WHERE id = ?')
      .run(message.timestamp || new Date().toISOString(), conversationId);
  }

  // Memories
  public async getMemories(query?: { type?: string; text?: string; limit?: number }): Promise<MemoryEntry[]> {
    const client = this.getClient();
    let sql = 'SELECT * FROM memories WHERE 1=1';
    const params: any[] = [];

    if (query?.type) {
      sql += ' AND type = ?';
      params.push(query.type);
    }
    if (query?.text) {
      sql += ' AND (key LIKE ? OR content LIKE ? OR tags LIKE ?)';
      const wildcard = `%${query.text}%`;
      params.push(wildcard, wildcard, wildcard);
    }
    sql += ' ORDER BY importance DESC, created_at DESC';
    if (query?.limit) {
      sql += ' LIMIT ?';
      params.push(query.limit);
    }

    const rows = client.prepare(sql).all(...params) as any[];
    return rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      type: r.type,
      key: r.key,
      content: r.content,
      importance: r.importance,
      tags: r.tags ? JSON.parse(r.tags) : [],
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  }

  public async saveMemory(memory: MemoryEntry): Promise<MemoryEntry> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO memories (id, user_id, type, key, content, importance, tags, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           type = excluded.type,
           key = excluded.key,
           content = excluded.content,
           importance = excluded.importance,
           tags = excluded.tags,
           updated_at = excluded.updated_at`
      )
      .run(
        memory.id,
        memory.userId,
        memory.type,
        memory.key,
        memory.content,
        memory.importance,
        JSON.stringify(memory.tags || []),
        memory.createdAt,
        memory.updatedAt
      );
    return memory;
  }

  public async deleteMemory(id: string): Promise<boolean> {
    const client = this.getClient();
    const result = client.prepare('DELETE FROM memories WHERE id = ?').run(id) as any;
    return (result?.changes || 0) > 0;
  }

  // Projects
  public async getProjects(
    userId: string,
    filter?: { includeArchived?: boolean; includeTrash?: boolean; isTrashOnly?: boolean }
  ): Promise<ProjectEntity[]> {
    const client = this.getClient();
    let sql = `
      SELECT p.*, COUNT(c.id) as conv_count 
      FROM projects p 
      LEFT JOIN conversations c ON p.id = c.project_id AND c.is_trash = 0
      WHERE p.user_id = ?
    `;
    const params: any[] = [userId];

    if (filter?.isTrashOnly) {
      sql += ' AND p.is_trash = 1';
    } else if (!filter?.includeTrash) {
      sql += ' AND p.is_trash = 0';
    }

    if (!filter?.includeArchived && !filter?.isTrashOnly) {
      sql += ' AND p.is_archived = 0';
    }

    sql += ' GROUP BY p.id ORDER BY p.updated_at DESC, p.created_at DESC';

    const rows = client.prepare(sql).all(...params) as any[];
    return rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      name: r.name,
      description: r.description,
      contextBrief: r.context_brief || '',
      status: r.status,
      isArchived: Boolean(r.is_archived),
      isTrash: Boolean(r.is_trash),
      createdAt: r.created_at,
      updatedAt: r.updated_at || r.created_at,
      conversationCount: Number(r.conv_count || 0),
    }));
  }

  public async getProject(id: string): Promise<ProjectEntity | null> {
    const client = this.getClient();
    const row = client
      .prepare(`
        SELECT p.*, COUNT(c.id) as conv_count 
        FROM projects p 
        LEFT JOIN conversations c ON p.id = c.project_id AND c.is_trash = 0
        WHERE p.id = ?
        GROUP BY p.id
      `)
      .get(id) as any;
    if (!row) return null;
    return {
      id: row.id,
      userId: row.user_id,
      name: row.name,
      description: row.description,
      contextBrief: row.context_brief || '',
      status: row.status,
      isArchived: Boolean(row.is_archived),
      isTrash: Boolean(row.is_trash),
      createdAt: row.created_at,
      updatedAt: row.updated_at || row.created_at,
      conversationCount: Number(row.conv_count || 0),
    };
  }

  public async saveProject(project: ProjectEntity): Promise<ProjectEntity> {
    const client = this.getClient();
    const now = new Date().toISOString();
    const updatedAt = project.updatedAt || now;
    client
      .prepare(
        `INSERT INTO projects (id, user_id, name, description, context_brief, status, is_archived, is_trash, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           name = excluded.name,
           description = excluded.description,
           context_brief = excluded.context_brief,
           status = excluded.status,
           is_archived = excluded.is_archived,
           is_trash = excluded.is_trash,
           updated_at = excluded.updated_at`
      )
      .run(
        project.id,
        project.userId,
        project.name,
        project.description,
        project.contextBrief || '',
        project.status,
        project.isArchived ? 1 : 0,
        project.isTrash ? 1 : 0,
        project.createdAt,
        updatedAt
      );
    return {
      ...project,
      updatedAt,
    };
  }

  public async deleteProject(id: string, hardDelete = false): Promise<boolean> {
    const client = this.getClient();
    if (hardDelete) {
      // Dissociate associated conversations
      client.prepare('UPDATE conversations SET project_id = NULL WHERE project_id = ?').run(id);
      const result = client.prepare('DELETE FROM projects WHERE id = ?').run(id) as any;
      return (result?.changes || 0) > 0;
    } else {
      // Soft-delete (move to trash)
      const now = new Date().toISOString();
      const result = client.prepare('UPDATE projects SET is_trash = 1, updated_at = ? WHERE id = ?').run(now, id) as any;
      return (result?.changes || 0) > 0;
    }
  }

  public async softDeleteProject(id: string): Promise<boolean> {
    const client = this.getClient();
    const now = new Date().toISOString();
    const result = client.prepare('UPDATE projects SET is_trash = 1, updated_at = ? WHERE id = ?').run(now, id) as any;
    return (result?.changes || 0) > 0;
  }

  public async restoreProject(id: string): Promise<ProjectEntity | null> {
    const client = this.getClient();
    const now = new Date().toISOString();
    client.prepare("UPDATE projects SET is_trash = 0, is_archived = 0, status = 'ACTIVE', updated_at = ? WHERE id = ?").run(now, id);
    return this.getProject(id);
  }

  // Tasks & Steps
  public async getTasks(): Promise<TaskItem[]> {
    const client = this.getClient();
    const rows = client.prepare('SELECT * FROM tasks ORDER BY created_at DESC').all() as any[];
    return rows.map((r) => this.rowToTask(r));
  }

  public async getTask(id: string): Promise<TaskItem | null> {
    const client = this.getClient();
    const row = client.prepare('SELECT * FROM tasks WHERE id = ?').get(id) as any;
    if (!row) return null;
    return this.rowToTask(row);
  }

  public async saveTask(task: TaskItem): Promise<TaskItem> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO tasks (id, user_id, title, raw_prompt, status, current_stage, plan, logs, result_summary, pending_permission_step, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           title = excluded.title,
           raw_prompt = excluded.raw_prompt,
           status = excluded.status,
           current_stage = excluded.current_stage,
           plan = excluded.plan,
           logs = excluded.logs,
           result_summary = excluded.result_summary,
           pending_permission_step = excluded.pending_permission_step,
           updated_at = excluded.updated_at`
      )
      .run(
        task.id,
        task.userId,
        task.title,
        task.rawPrompt,
        task.status,
        task.currentStage,
        task.plan ? JSON.stringify(task.plan) : null,
        JSON.stringify(task.logs || []),
        task.resultSummary || null,
        task.pendingPermissionStep ? JSON.stringify(task.pendingPermissionStep) : null,
        task.createdAt,
        task.updatedAt || new Date().toISOString()
      );
    return task;
  }

  public async updateTask(id: string, updates: Partial<TaskItem>): Promise<TaskItem | null> {
    const existing = await this.getTask(id);
    if (!existing) return null;
    const merged: TaskItem = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    return this.saveTask(merged);
  }

  private rowToTask(r: any): TaskItem {
    return {
      id: r.id,
      userId: r.user_id,
      title: r.title,
      rawPrompt: r.raw_prompt,
      status: r.status,
      currentStage: r.current_stage,
      plan: r.plan ? JSON.parse(r.plan) : undefined,
      logs: r.logs ? JSON.parse(r.logs) : [],
      resultSummary: r.result_summary || undefined,
      pendingPermissionStep: r.pending_permission_step ? JSON.parse(r.pending_permission_step) : undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  }

  // Tools & Skills
  public async getRegisteredTools(): Promise<ToolDefinition[]> {
    return [];
  }

  public async getRegisteredSkills(): Promise<SkillDefinition[]> {
    return [];
  }

  public async recordToolCall(call: ToolCallEntity): Promise<void> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO tool_calls (id, task_id, tool_name, input, output, permission_granted, success, duration_ms, timestamp)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        call.id,
        call.taskId || null,
        call.toolName,
        JSON.stringify(call.input ?? null),
        JSON.stringify(call.output ?? null),
        call.permissionGranted ? 1 : 0,
        call.success ? 1 : 0,
        call.durationMs || 0,
        call.timestamp
      );
  }

  public async getToolCalls(limit = 50): Promise<ToolCallEntity[]> {
    const client = this.getClient();
    const rows = client
      .prepare('SELECT * FROM tool_calls ORDER BY timestamp DESC LIMIT ?')
      .all(limit) as any[];
    return rows.map((r) => ({
      id: r.id,
      taskId: r.task_id || undefined,
      toolName: r.tool_name,
      input: r.input ? JSON.parse(r.input) : null,
      output: r.output ? JSON.parse(r.output) : null,
      permissionGranted: Boolean(r.permission_granted),
      success: Boolean(r.success),
      durationMs: r.duration_ms,
      timestamp: r.timestamp,
    }));
  }

  // Agent Runs
  public async recordAgentRun(run: AgentRunEntity): Promise<void> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO agent_runs (id, task_id, agent_role, status, input, output, duration_ms, timestamp)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        run.id,
        run.taskId || null,
        run.agentRole,
        run.status,
        run.input,
        run.output,
        run.durationMs || 0,
        run.timestamp
      );
  }

  public async getAgentRuns(limit = 50): Promise<AgentRunEntity[]> {
    const client = this.getClient();
    const rows = client
      .prepare('SELECT * FROM agent_runs ORDER BY timestamp DESC LIMIT ?')
      .all(limit) as any[];
    return rows.map((r) => ({
      id: r.id,
      taskId: r.task_id || undefined,
      agentRole: r.agent_role,
      status: r.status,
      input: r.input,
      output: r.output,
      durationMs: r.duration_ms,
      timestamp: r.timestamp,
    }));
  }

  // Verification Results
  public async recordVerification(res: VerificationResult): Promise<void> {
    const client = this.getClient();
    const id = `verif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    client
      .prepare(
        `INSERT INTO verifications (id, step_id, passed, score, failure_classification, remediation_advice, checks_performed, timestamp)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        id,
        res.stepId,
        res.passed ? 1 : 0,
        res.score,
        res.failureClassification || null,
        res.remediationAdvice || null,
        JSON.stringify(res.checksPerformed || []),
        res.timestamp
      );
  }

  public async getVerifications(limit = 50): Promise<VerificationResult[]> {
    const client = this.getClient();
    const rows = client
      .prepare('SELECT * FROM verifications ORDER BY timestamp DESC LIMIT ?')
      .all(limit) as any[];
    return rows.map((r) => ({
      stepId: r.step_id,
      status: r.passed ? ('VERIFIED' as const) : ('FAILED' as const),
      passed: Boolean(r.passed),
      score: r.score,
      failureClassification: r.failure_classification || undefined,
      remediationAdvice: r.remediation_advice || undefined,
      checksPerformed: r.checks_performed ? JSON.parse(r.checks_performed) : [],
      verifiedAt: r.timestamp,
      timestamp: r.timestamp,
    }));
  }

  // Audit Logs
  public async recordAuditLog(log: AuditLog): Promise<void> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO audit_logs (id, timestamp, action, actor, permission_level, details, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        log.id,
        log.timestamp,
        log.action,
        log.actor,
        log.permissionLevel,
        JSON.stringify(log.details || {}),
        log.status
      );
  }

  public async getAuditLogs(limit = 50): Promise<AuditLog[]> {
    const client = this.getClient();
    const rows = client
      .prepare('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?')
      .all(limit) as any[];
    return rows.map((r) => ({
      id: r.id,
      timestamp: r.timestamp,
      action: r.action,
      actor: r.actor,
      permissionLevel: r.permission_level as any,
      details: r.details ? JSON.parse(r.details) : {},
      status: r.status as any,
    }));
  }

  // System Events
  public async emitEvent(event: SystemEvent): Promise<void> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT INTO system_events (id, timestamp, type, stage, message, data)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(
        event.id,
        event.timestamp,
        event.type,
        event.stage || null,
        event.message,
        event.data ? JSON.stringify(event.data) : null
      );
  }

  public async getEvents(limit = 50): Promise<SystemEvent[]> {
    const client = this.getClient();
    const rows = client
      .prepare('SELECT * FROM system_events ORDER BY timestamp DESC LIMIT ?')
      .all(limit) as any[];
    return rows.map((r) => ({
      id: r.id,
      timestamp: r.timestamp,
      type: r.type as any,
      stage: r.stage as any,
      message: r.message,
      data: r.data ? JSON.parse(r.data) : undefined,
    }));
  }

  // Files & Attachments
  public async saveFile(file: FileAttachmentEntity): Promise<FileAttachmentEntity> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT OR REPLACE INTO files (
          id, conversation_id, project_id, user_id, filename, original_name,
          mime_type, size_bytes, file_category, storage_path, text_content,
          summary, is_extracted, extraction_status, extraction_note, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        file.id,
        file.conversationId || null,
        file.projectId || null,
        file.userId,
        file.filename,
        file.originalName,
        file.mimeType,
        file.sizeBytes,
        file.fileCategory,
        file.storagePath,
        file.textContent || null,
        file.summary || null,
        file.isExtracted ? 1 : 0,
        file.extractionStatus || 'EMPTY',
        file.extractionNote || null,
        file.createdAt,
        file.updatedAt || file.createdAt
      );
    return file;
  }

  public async getFile(id: string): Promise<FileAttachmentEntity | null> {
    const client = this.getClient();
    const row = client.prepare('SELECT * FROM files WHERE id = ?').get(id) as any;
    if (!row) return null;
    return this.mapFileRow(row);
  }

  public async getFiles(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<FileAttachmentEntity[]> {
    const client = this.getClient();
    let query = 'SELECT * FROM files WHERE 1=1';
    const params: any[] = [];
    if (filter?.conversationId) {
      query += ' AND conversation_id = ?';
      params.push(filter.conversationId);
    }
    if (filter?.projectId) {
      query += ' AND project_id = ?';
      params.push(filter.projectId);
    }
    if (filter?.userId) {
      query += ' AND user_id = ?';
      params.push(filter.userId);
    }
    query += ' ORDER BY created_at DESC';
    const rows = client.prepare(query).all(...params) as any[];
    return rows.map((r) => this.mapFileRow(r));
  }

  public async deleteFile(id: string): Promise<boolean> {
    const client = this.getClient();
    const result = client.prepare('DELETE FROM files WHERE id = ?').run(id);
    return Number((result as any)?.changes || 0) > 0;
  }

  private mapFileRow(r: any): FileAttachmentEntity {
    return {
      id: r.id,
      conversationId: r.conversation_id || undefined,
      projectId: r.project_id || undefined,
      userId: r.user_id,
      filename: r.filename,
      originalName: r.original_name,
      mimeType: r.mime_type,
      sizeBytes: Number(r.size_bytes),
      fileCategory: r.file_category,
      storagePath: r.storage_path,
      textContent: r.text_content || undefined,
      summary: r.summary || undefined,
      isExtracted: Boolean(r.is_extracted),
      extractionStatus: r.extraction_status,
      extractionNote: r.extraction_note || undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at || undefined,
    };
  }

  // Generated Documents
  public async saveDocument(doc: GeneratedDocumentEntity): Promise<GeneratedDocumentEntity> {
    const client = this.getClient();
    client
      .prepare(
        `INSERT OR REPLACE INTO documents (
          id, title, filename, format, content, size_bytes,
          conversation_id, project_id, user_id, created_at, download_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        doc.id,
        doc.title,
        doc.filename,
        doc.format,
        doc.content,
        doc.sizeBytes,
        doc.conversationId || null,
        doc.projectId || null,
        doc.userId,
        doc.createdAt,
        doc.downloadUrl
      );
    return doc;
  }

  public async getDocument(id: string): Promise<GeneratedDocumentEntity | null> {
    const client = this.getClient();
    const r = client.prepare('SELECT * FROM documents WHERE id = ?').get(id) as any;
    if (!r) return null;
    return {
      id: r.id,
      title: r.title,
      filename: r.filename,
      format: r.format,
      content: r.content,
      sizeBytes: Number(r.size_bytes),
      conversationId: r.conversation_id || undefined,
      projectId: r.project_id || undefined,
      userId: r.user_id,
      createdAt: r.created_at,
      downloadUrl: r.download_url,
    };
  }

  public async getDocuments(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<GeneratedDocumentEntity[]> {
    const client = this.getClient();
    let query = 'SELECT * FROM documents WHERE 1=1';
    const params: any[] = [];
    if (filter?.conversationId) {
      query += ' AND conversation_id = ?';
      params.push(filter.conversationId);
    }
    if (filter?.projectId) {
      query += ' AND project_id = ?';
      params.push(filter.projectId);
    }
    if (filter?.userId) {
      query += ' AND user_id = ?';
      params.push(filter.userId);
    }
    query += ' ORDER BY created_at DESC';
    const rows = client.prepare(query).all(...params) as any[];
    return rows.map((r) => ({
      id: r.id,
      title: r.title,
      filename: r.filename,
      format: r.format,
      content: r.content,
      sizeBytes: Number(r.size_bytes),
      conversationId: r.conversation_id || undefined,
      projectId: r.project_id || undefined,
      userId: r.user_id,
      createdAt: r.created_at,
      downloadUrl: r.download_url,
    }));
  }

  public async deleteDocument(id: string): Promise<boolean> {
    const client = this.getClient();
    const result = client.prepare('DELETE FROM documents WHERE id = ?').run(id) as any;
    return (result?.changes || 0) > 0;
  }

  public async close(): Promise<void> {
    if (this.db) {
      try {
        this.db.close();
      } catch {}
      this.db = null;
      this.isInitialized = false;
    }
  }
}
