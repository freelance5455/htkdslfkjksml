import type {
  ChatMessage,
  MemoryEntry,
} from '../types.ts';
import type {
  ConversationEntity,
  ProjectEntity,
  UserEntity,
} from './types.ts';

export const SQLITE_SCHEMA = `
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = NORMAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    topic TEXT DEFAULT 'General',
    is_archived INTEGER DEFAULT 0,
    is_trash INTEGER DEFAULT 0,
    has_custom_title INTEGER DEFAULT 0,
    project_id TEXT DEFAULT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations(user_id, updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_conversations_project ON conversations(project_id);

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    task_id TEXT,
    core_stage TEXT,
    metadata TEXT,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
  );
  CREATE INDEX IF NOT EXISTS idx_messages_conv_time ON messages(conversation_id, timestamp ASC);

  CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL,
    key TEXT NOT NULL,
    content TEXT NOT NULL,
    importance INTEGER NOT NULL DEFAULT 5,
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_memories_user_type ON memories(user_id, type, importance DESC);
  CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key);

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    context_brief TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    is_archived INTEGER DEFAULT 0,
    is_trash INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    raw_prompt TEXT NOT NULL,
    status TEXT NOT NULL,
    current_stage TEXT NOT NULL,
    plan TEXT,
    logs TEXT NOT NULL DEFAULT '[]',
    result_summary TEXT,
    pending_permission_step TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_tasks_created ON tasks(created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);

  CREATE TABLE IF NOT EXISTS tool_calls (
    id TEXT PRIMARY KEY,
    task_id TEXT,
    tool_name TEXT NOT NULL,
    input TEXT NOT NULL,
    output TEXT NOT NULL,
    permission_granted INTEGER NOT NULL DEFAULT 1,
    success INTEGER NOT NULL DEFAULT 1,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    timestamp TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_tool_calls_time ON tool_calls(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_tool_calls_task ON tool_calls(task_id);

  CREATE TABLE IF NOT EXISTS agent_runs (
    id TEXT PRIMARY KEY,
    task_id TEXT,
    agent_role TEXT NOT NULL,
    status TEXT NOT NULL,
    input TEXT NOT NULL,
    output TEXT NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    timestamp TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_agent_runs_time ON agent_runs(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_agent_runs_task ON agent_runs(task_id);

  CREATE TABLE IF NOT EXISTS verifications (
    id TEXT PRIMARY KEY,
    step_id TEXT NOT NULL,
    passed INTEGER NOT NULL,
    score REAL NOT NULL,
    failure_classification TEXT,
    remediation_advice TEXT,
    checks_performed TEXT NOT NULL,
    timestamp TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_verifications_time ON verifications(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_verifications_step ON verifications(step_id);

  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    action TEXT NOT NULL,
    actor TEXT NOT NULL,
    permission_level TEXT NOT NULL,
    details TEXT NOT NULL,
    status TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_audit_logs_time ON audit_logs(timestamp DESC);

  CREATE TABLE IF NOT EXISTS system_events (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    type TEXT NOT NULL,
    stage TEXT,
    message TEXT NOT NULL,
    data TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_system_events_time ON system_events(timestamp DESC);

  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    conversation_id TEXT,
    project_id TEXT,
    user_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    original_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    file_category TEXT NOT NULL,
    storage_path TEXT NOT NULL,
    text_content TEXT,
    summary TEXT,
    is_extracted INTEGER NOT NULL DEFAULT 0,
    extraction_status TEXT NOT NULL DEFAULT 'EMPTY',
    extraction_note TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_files_conv ON files(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_files_proj ON files(project_id);
  CREATE INDEX IF NOT EXISTS idx_files_time ON files(created_at DESC);

  CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    filename TEXT NOT NULL,
    format TEXT NOT NULL,
    content TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    conversation_id TEXT,
    project_id TEXT,
    user_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    download_url TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_docs_conv ON documents(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_docs_proj ON documents(project_id);
  CREATE INDEX IF NOT EXISTS idx_docs_time ON documents(created_at DESC);
`;

export const POSTGRES_SCHEMA = `
  CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(128) PRIMARY KEY,
    username VARCHAR(128) NOT NULL,
    name VARCHAR(256) NOT NULL,
    role VARCHAR(64) NOT NULL DEFAULT 'user',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(512) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_conversations_user ON conversations(user_id, updated_at DESC);

  CREATE TABLE IF NOT EXISTS messages (
    id VARCHAR(128) PRIMARY KEY,
    conversation_id VARCHAR(128) NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role VARCHAR(64) NOT NULL,
    content TEXT NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    task_id VARCHAR(128),
    core_stage VARCHAR(64),
    metadata JSONB
  );
  CREATE INDEX IF NOT EXISTS idx_pg_messages_conv_time ON messages(conversation_id, timestamp ASC);

  CREATE TABLE IF NOT EXISTS memories (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    type VARCHAR(64) NOT NULL,
    key VARCHAR(256) NOT NULL,
    content TEXT NOT NULL,
    importance INT NOT NULL DEFAULT 5,
    tags JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_memories_user_type ON memories(user_id, type, importance DESC);
  CREATE INDEX IF NOT EXISTS idx_pg_memories_key ON memories(key);

  CREATE TABLE IF NOT EXISTS projects (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(256) NOT NULL,
    description TEXT NOT NULL,
    status VARCHAR(64) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_projects_user ON projects(user_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS tasks (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    title VARCHAR(512) NOT NULL,
    raw_prompt TEXT NOT NULL,
    status VARCHAR(64) NOT NULL,
    current_stage VARCHAR(64) NOT NULL,
    plan JSONB,
    logs JSONB NOT NULL DEFAULT '[]'::jsonb,
    result_summary TEXT,
    pending_permission_step JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_tasks_created ON tasks(created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_pg_tasks_status ON tasks(status);

  CREATE TABLE IF NOT EXISTS tool_calls (
    id VARCHAR(128) PRIMARY KEY,
    task_id VARCHAR(128),
    tool_name VARCHAR(128) NOT NULL,
    input JSONB NOT NULL,
    output JSONB NOT NULL,
    permission_granted BOOLEAN NOT NULL DEFAULT TRUE,
    success BOOLEAN NOT NULL DEFAULT TRUE,
    duration_ms INT NOT NULL DEFAULT 0,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_tool_calls_time ON tool_calls(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_pg_tool_calls_task ON tool_calls(task_id);

  CREATE TABLE IF NOT EXISTS agent_runs (
    id VARCHAR(128) PRIMARY KEY,
    task_id VARCHAR(128),
    agent_role VARCHAR(64) NOT NULL,
    status VARCHAR(64) NOT NULL,
    input TEXT NOT NULL,
    output TEXT NOT NULL,
    duration_ms INT NOT NULL DEFAULT 0,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_agent_runs_time ON agent_runs(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_pg_agent_runs_task ON agent_runs(task_id);

  CREATE TABLE IF NOT EXISTS verifications (
    id VARCHAR(128) PRIMARY KEY,
    step_id VARCHAR(128) NOT NULL,
    passed BOOLEAN NOT NULL,
    score NUMERIC(4, 2) NOT NULL,
    failure_classification VARCHAR(128),
    remediation_advice TEXT,
    checks_performed JSONB NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_pg_verifications_time ON verifications(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_pg_verifications_step ON verifications(step_id);

  CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(128) PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    action VARCHAR(256) NOT NULL,
    actor VARCHAR(128) NOT NULL,
    permission_level VARCHAR(64) NOT NULL,
    details JSONB NOT NULL,
    status VARCHAR(64) NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_pg_audit_logs_time ON audit_logs(timestamp DESC);

  CREATE TABLE IF NOT EXISTS system_events (
    id VARCHAR(128) PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    type VARCHAR(64) NOT NULL,
    stage VARCHAR(64),
    message TEXT NOT NULL,
    data JSONB
  );
  CREATE INDEX IF NOT EXISTS idx_pg_system_events_time ON system_events(timestamp DESC);

  CREATE TABLE IF NOT EXISTS files (
    id VARCHAR(128) PRIMARY KEY,
    conversation_id VARCHAR(128),
    project_id VARCHAR(128),
    user_id VARCHAR(128) NOT NULL,
    filename VARCHAR(512) NOT NULL,
    original_name VARCHAR(512) NOT NULL,
    mime_type VARCHAR(128) NOT NULL,
    size_bytes BIGINT NOT NULL,
    file_category VARCHAR(64) NOT NULL,
    storage_path TEXT NOT NULL,
    text_content TEXT,
    summary TEXT,
    is_extracted BOOLEAN NOT NULL DEFAULT FALSE,
    extraction_status VARCHAR(64) NOT NULL DEFAULT 'EMPTY',
    extraction_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ
  );
  CREATE INDEX IF NOT EXISTS idx_pg_files_conv ON files(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_pg_files_proj ON files(project_id);
  CREATE INDEX IF NOT EXISTS idx_pg_files_time ON files(created_at DESC);

  CREATE TABLE IF NOT EXISTS documents (
    id VARCHAR(128) PRIMARY KEY,
    title VARCHAR(512) NOT NULL,
    filename VARCHAR(512) NOT NULL,
    format VARCHAR(32) NOT NULL,
    content TEXT NOT NULL,
    size_bytes BIGINT NOT NULL,
    conversation_id VARCHAR(128),
    project_id VARCHAR(128),
    user_id VARCHAR(128) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    download_url TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_pg_docs_conv ON documents(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_pg_docs_proj ON documents(project_id);
  CREATE INDEX IF NOT EXISTS idx_pg_docs_time ON documents(created_at DESC);
`;

export const DEFAULT_USER: UserEntity = {
  id: 'usr_jarvis_prime',
  username: 'operator',
  name: 'Primary Operator',
  role: 'admin',
  createdAt: '2026-09-04T00:00:00.000Z',
};

export const DEFAULT_CONVERSATION: ConversationEntity = {
  id: 'conv_default',
  userId: DEFAULT_USER.id,
  title: 'JARVIS Primary Session',
  topic: 'General',
  createdAt: '2026-09-04T00:00:00.000Z',
  updatedAt: '2026-09-04T00:00:00.000Z',
};

export const DEFAULT_MESSAGE: ChatMessage = {
  id: 'msg_welcome',
  role: 'assistant',
  content:
    'JARVIS Autonomous Operating System initialized. Core agentic loop active. Models routed, memory online, permission boundary engaged. How may I assist your mission today?',
  timestamp: '2026-09-04T00:00:00.000Z',
};

export const DEFAULT_MEMORIES: MemoryEntry[] = [
  {
    id: 'mem_1',
    userId: DEFAULT_USER.id,
    type: 'long_term',
    key: 'system_directive',
    content:
      'JARVIS is an autonomous personal AI operating system designed for goal decomposition, verifiable tool execution, and safe autonomous task completion.',
    importance: 10,
    tags: ['core', 'directive', 'safety'],
    createdAt: '2026-09-04T00:00:00.000Z',
    updatedAt: '2026-09-04T00:00:00.000Z',
  },
  {
    id: 'mem_2',
    userId: DEFAULT_USER.id,
    type: 'knowledge',
    key: 'security_boundaries',
    content:
      'Read operations are automatic. Safe writes are audited. Sensitive actions (file modifications, code sandboxes) and External actions require explicit human confirmation.',
    importance: 9,
    tags: ['security', 'permissions', 'policy'],
    createdAt: '2026-09-04T00:00:00.000Z',
    updatedAt: '2026-09-04T00:00:00.000Z',
  },
  {
    id: 'mem_3',
    userId: DEFAULT_USER.id,
    type: 'knowledge',
    key: 'finance_guidelines',
    content:
      'Financial analytics strictly operates in simulation and paper-trading mode. No real-world automated financial transfers or trading executions are permitted.',
    importance: 8,
    tags: ['finance', 'guardrails', 'simulation'],
    createdAt: '2026-09-04T00:00:00.000Z',
    updatedAt: '2026-09-04T00:00:00.000Z',
  },
];

export const DEFAULT_PROJECT: ProjectEntity = {
  id: 'proj_alpha',
  userId: DEFAULT_USER.id,
  name: 'System Architecture & Operations',
  description: 'Master operations workspace for JARVIS autonomous tasks and research pipelines.',
  contextBrief: 'Core operational pipeline and engineering tasks for JARVIS autonomous agentic system.',
  status: 'ACTIVE',
  isArchived: false,
  isTrash: false,
  createdAt: '2026-09-04T00:00:00.000Z',
  updatedAt: '2026-09-04T00:00:00.000Z',
};
