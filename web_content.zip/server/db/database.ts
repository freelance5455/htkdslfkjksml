export interface RecordBase { id: string; createdAt: string; updatedAt: string; }

export interface Conversation extends RecordBase {
  title: string;
  archived: boolean;
}

export interface Message extends RecordBase {
  conversationId: string;
  role: "user" | "assistant";
  content: string;
}

/*
Production implementation contract:
- SQLite local persistence / PostgreSQL when DATABASE_URL is configured.
- Conversations, messages, memories, projects, tasks, tool calls,
  agent runs, verifications, audit logs and system events.
*/
export class DatabaseManager {
  async health() { return { ok: true }; }
}
