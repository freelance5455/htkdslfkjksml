/**
 * JARVIS Unified Persistent Database Foundation
 *
 * Implements persistent storage for:
 * 1. Users
 * 2. Conversations
 * 3. Messages
 * 4. Memories
 * 5. Projects
 * 6. Tasks
 * 7. Tool Calls
 * 8. Agent Runs
 * 9. Verifications
 * 10. Audit Logs
 * 11. System Events
 *
 * Supports two enterprise persistent backends:
 * - Production Managed PostgreSQL (via DATABASE_URL, supporting Cloud SQL, Supabase, Neon, AWS RDS)
 * - Durable Local SQLite (via Node 22 native node:sqlite, storing to data/jarvis.db)
 *
 * Data survives dev server restarts, process recycles, and persists on disk.
 */

import { config } from '../config/index.ts';
import type {
  AuditLog,
  ChatMessage,
  FileAttachmentEntity,
  GeneratedDocumentEntity,
  MemoryEntry,
  SkillDefinition,
  SystemEvent,
  TaskItem,
  ToolDefinition,
  VerificationResult,
} from '../types.ts';
import { PostgresDatabase } from './postgresDatabase.ts';
import { SqliteDatabase } from './sqliteDatabase.ts';
import type {
  AgentRunEntity,
  ConversationEntity,
  DatabaseHealth,
  IDatabase,
  ProjectEntity,
  ToolCallEntity,
  UserEntity,
} from './types.ts';

export * from './types.ts';

class DatabaseManager implements IDatabase {
  private activeDriver: IDatabase;
  private isInitialized = false;
  private initializationPromise: Promise<void> | null = null;
  private lastHealth: DatabaseHealth | null = null;

  constructor() {
    // Default to configured SQLite driver immediately for synchronous call compatibility
    this.activeDriver = new SqliteDatabase(config.database.sqlitePath);
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) return;
    if (this.initializationPromise) return this.initializationPromise;

    this.initializationPromise = (async () => {
      const databaseUrl = config.database.databaseUrl;
      const isPostgresUrl =
        typeof databaseUrl === 'string' &&
        (databaseUrl.startsWith('postgresql://') || databaseUrl.startsWith('postgres://'));

      if (isPostgresUrl) {
        console.log('[DATABASE] Valid PostgreSQL DATABASE_URL detected. Initializing PostgreSQL driver...');
        const pgDriver = new PostgresDatabase(databaseUrl, {
          max: config.database.poolMax,
          idleTimeoutMillis: config.database.idleTimeoutMs,
          connectionTimeoutMillis: config.database.connectionTimeoutMs,
        });
        try {
          await pgDriver.initialize();
          this.activeDriver = pgDriver;
          this.isInitialized = true;
          this.lastHealth = await pgDriver.getHealth();
          console.log('[DATABASE] Successfully connected to production PostgreSQL database.');
          return;
        } catch (pgError: any) {
          console.warn(
            '[DATABASE WARNING] Failed to connect to PostgreSQL with DATABASE_URL:',
            pgError?.message || pgError
          );
          console.warn(`[DATABASE] Falling back to persistent local SQLite storage (${config.database.sqlitePath}).`);
        }
      }

      // SQLite driver initialization (default persistent store)
      const sqliteDriver = new SqliteDatabase(config.database.sqlitePath);
      await sqliteDriver.initialize();
      this.activeDriver = sqliteDriver;
      this.isInitialized = true;
      this.lastHealth = await sqliteDriver.getHealth();
      console.log(`[DATABASE] Persistent SQLite database online at: ${config.database.sqlitePath}`);
    })();

    return this.initializationPromise;
  }

  public async getHealth(): Promise<DatabaseHealth> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    return this.activeDriver.getHealth();
  }

  // Ensure initialized before executing query
  private async ensureInit(): Promise<IDatabase> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    return this.activeDriver;
  }

  // Users
  public async getUser(id: string): Promise<UserEntity | null> {
    const driver = await this.ensureInit();
    return driver.getUser(id);
  }

  public async saveUser(user: UserEntity): Promise<UserEntity> {
    const driver = await this.ensureInit();
    if (driver.saveUser) {
      return driver.saveUser(user);
    }
    return user;
  }

  // Conversations & Messages
  public async getConversations(
    userId: string,
    filter?: { projectId?: string; includeArchived?: boolean; includeTrash?: boolean; isTrashOnly?: boolean }
  ): Promise<ConversationEntity[]> {
    const driver = await this.ensureInit();
    return driver.getConversations(userId, filter);
  }

  public async getConversation(id: string): Promise<ConversationEntity | null> {
    const driver = await this.ensureInit();
    if (driver.getConversation) {
      return driver.getConversation(id);
    }
    const all = await driver.getConversations('usr_jarvis_prime');
    return all.find((c) => c.id === id) || null;
  }

  public async saveConversation(conv: ConversationEntity): Promise<ConversationEntity> {
    const driver = await this.ensureInit();
    if (driver.saveConversation) {
      return driver.saveConversation(conv);
    }
    return conv;
  }

  public async deleteConversation(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    if (driver.deleteConversation) {
      return driver.deleteConversation(id);
    }
    return false;
  }

  public async softDeleteConversation(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    if (driver.softDeleteConversation) {
      return driver.softDeleteConversation(id);
    }
    return false;
  }

  public async restoreConversation(id: string): Promise<ConversationEntity | null> {
    const driver = await this.ensureInit();
    if (driver.restoreConversation) {
      return driver.restoreConversation(id);
    }
    return null;
  }

  public async getMessages(conversationId: string): Promise<ChatMessage[]> {
    const driver = await this.ensureInit();
    return driver.getMessages(conversationId);
  }

  public async saveMessage(conversationId: string, message: ChatMessage): Promise<void> {
    const driver = await this.ensureInit();
    return driver.saveMessage(conversationId, message);
  }

  // Memories
  public async getMemories(query?: { type?: string; text?: string; limit?: number }): Promise<MemoryEntry[]> {
    const driver = await this.ensureInit();
    return driver.getMemories(query);
  }

  public async saveMemory(memory: MemoryEntry): Promise<MemoryEntry> {
    const driver = await this.ensureInit();
    return driver.saveMemory(memory);
  }

  public async deleteMemory(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    return driver.deleteMemory(id);
  }

  // Projects
  public async getProjects(userId: string): Promise<ProjectEntity[]> {
    const driver = await this.ensureInit();
    return driver.getProjects(userId);
  }

  public async getProject(id: string): Promise<ProjectEntity | null> {
    const driver = await this.ensureInit();
    if (driver.getProject) {
      return driver.getProject(id);
    }
    const all = await driver.getProjects('usr_jarvis_prime');
    return all.find((p) => p.id === id) || null;
  }

  public async saveProject(project: ProjectEntity): Promise<ProjectEntity> {
    const driver = await this.ensureInit();
    if (driver.saveProject) {
      return driver.saveProject(project);
    }
    return project;
  }

  public async deleteProject(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    if (driver.deleteProject) {
      return driver.deleteProject(id);
    }
    return false;
  }

  public async softDeleteProject(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    if (driver.softDeleteProject) {
      return driver.softDeleteProject(id);
    }
    return false;
  }

  public async restoreProject(id: string): Promise<ProjectEntity | null> {
    const driver = await this.ensureInit();
    if (driver.restoreProject) {
      return driver.restoreProject(id);
    }
    return null;
  }

  public async searchConversations(
    userId: string,
    query: string,
    options?: { projectId?: string; includeArchived?: boolean }
  ): Promise<Array<ConversationEntity & { matchedSnippet?: string }>> {
    const driver = await this.ensureInit();
    if (driver.searchConversations) {
      return driver.searchConversations(userId, query, options);
    }
    return [];
  }

  // Tasks & Steps
  public async getTasks(): Promise<TaskItem[]> {
    const driver = await this.ensureInit();
    return driver.getTasks();
  }

  public async getTask(id: string): Promise<TaskItem | null> {
    const driver = await this.ensureInit();
    return driver.getTask(id);
  }

  public async saveTask(task: TaskItem): Promise<TaskItem> {
    const driver = await this.ensureInit();
    return driver.saveTask(task);
  }

  public async updateTask(id: string, updates: Partial<TaskItem>): Promise<TaskItem | null> {
    const driver = await this.ensureInit();
    return driver.updateTask(id, updates);
  }

  // Tools & Skills
  public async getRegisteredTools(): Promise<ToolDefinition[]> {
    const driver = await this.ensureInit();
    return driver.getRegisteredTools();
  }

  public async getRegisteredSkills(): Promise<SkillDefinition[]> {
    const driver = await this.ensureInit();
    return driver.getRegisteredSkills();
  }

  public async recordToolCall(call: ToolCallEntity): Promise<void> {
    const driver = await this.ensureInit();
    return driver.recordToolCall(call);
  }

  public async getToolCalls(limit = 50): Promise<ToolCallEntity[]> {
    const driver = await this.ensureInit();
    return driver.getToolCalls(limit);
  }

  // Agent Runs
  public async recordAgentRun(run: AgentRunEntity): Promise<void> {
    const driver = await this.ensureInit();
    return driver.recordAgentRun(run);
  }

  public async getAgentRuns(limit = 50): Promise<AgentRunEntity[]> {
    const driver = await this.ensureInit();
    return driver.getAgentRuns(limit);
  }

  // Verification Results
  public async recordVerification(res: VerificationResult): Promise<void> {
    const driver = await this.ensureInit();
    return driver.recordVerification(res);
  }

  public async getVerifications(limit = 50): Promise<VerificationResult[]> {
    const driver = await this.ensureInit();
    return driver.getVerifications(limit);
  }

  // Audit Logs
  public async recordAuditLog(log: AuditLog): Promise<void> {
    const driver = await this.ensureInit();
    return driver.recordAuditLog(log);
  }

  public async getAuditLogs(limit = 50): Promise<AuditLog[]> {
    const driver = await this.ensureInit();
    return driver.getAuditLogs(limit);
  }

  // System Events
  public async emitEvent(event: SystemEvent): Promise<void> {
    const driver = await this.ensureInit();
    return driver.emitEvent(event);
  }

  public async getEvents(limit = 50): Promise<SystemEvent[]> {
    const driver = await this.ensureInit();
    return driver.getEvents(limit);
  }

  // Files & Attachments
  public async saveFile(file: FileAttachmentEntity): Promise<FileAttachmentEntity> {
    const driver = await this.ensureInit();
    return driver.saveFile(file);
  }

  public async getFile(id: string): Promise<FileAttachmentEntity | null> {
    const driver = await this.ensureInit();
    return driver.getFile(id);
  }

  public async getFiles(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<FileAttachmentEntity[]> {
    const driver = await this.ensureInit();
    return driver.getFiles(filter);
  }

  public async deleteFile(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    return driver.deleteFile(id);
  }

  // Generated Documents
  public async saveDocument(doc: GeneratedDocumentEntity): Promise<GeneratedDocumentEntity> {
    const driver = await this.ensureInit();
    if (driver.saveDocument) {
      return driver.saveDocument(doc);
    }
    return doc;
  }

  public async getDocument(id: string): Promise<GeneratedDocumentEntity | null> {
    const driver = await this.ensureInit();
    if (driver.getDocument) {
      return driver.getDocument(id);
    }
    return null;
  }

  public async getDocuments(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<GeneratedDocumentEntity[]> {
    const driver = await this.ensureInit();
    if (driver.getDocuments) {
      return driver.getDocuments(filter);
    }
    return [];
  }

  public async deleteDocument(id: string): Promise<boolean> {
    const driver = await this.ensureInit();
    if (driver.deleteDocument) {
      return driver.deleteDocument(id);
    }
    return true;
  }
}

export const db: IDatabase = new DatabaseManager();

export async function initializeDatabase(): Promise<void> {
  await db.initialize();
}
