import type {
  AuditLog,
  ChatMessage,
  FileAttachmentEntity,
  GeneratedDocumentEntity,
  MemoryEntry,
  PermissionLevel,
  SkillDefinition,
  SystemEvent,
  TaskItem,
  ToolDefinition,
  VerificationResult,
} from '../types.ts';

export interface UserEntity {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface ConversationEntity {
  id: string;
  userId: string;
  title: string;
  topic?: string;
  createdAt: string;
  updatedAt: string;
  isArchived?: boolean;
  isTrash?: boolean;
  hasCustomTitle?: boolean;
  projectId?: string;
  projectName?: string;
  messageCount?: number;
  lastMessageSnippet?: string;
}

export interface ProjectEntity {
  id: string;
  userId: string;
  name: string;
  description: string;
  contextBrief?: string;
  status: 'ACTIVE' | 'ARCHIVED';
  isArchived?: boolean;
  isTrash?: boolean;
  conversationCount?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface ToolCallEntity {
  id: string;
  taskId?: string;
  toolName: string;
  input: unknown;
  output: unknown;
  permissionGranted: boolean;
  success: boolean;
  durationMs: number;
  timestamp: string;
}

export interface AgentRunEntity {
  id: string;
  taskId?: string;
  agentRole: string;
  status: 'RUNNING' | 'SUCCESS' | 'FAILED';
  input: string;
  output: string;
  durationMs: number;
  timestamp: string;
}

export interface PermissionEntity {
  id: string;
  level: PermissionLevel;
  resource: string;
  grantedTo: string;
  grantedAt: string;
  expiresAt?: string;
}

export interface DatabaseHealth {
  provider: 'sqlite' | 'postgres';
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  isPersistent: boolean;
  databasePathOrHost: string;
  totalTables: number;
  recordCounts: Record<string, number>;
  lastMigration: string;
  error?: string;
}

export interface IDatabase {
  initialize(): Promise<void>;
  getHealth(): Promise<DatabaseHealth>;
  close?(): Promise<void>;

  // Users
  getUser(id: string): Promise<UserEntity | null>;
  saveUser?(user: UserEntity): Promise<UserEntity>;

  // Conversations & Messages
  getConversations(
    userId: string,
    filter?: { projectId?: string; includeArchived?: boolean; includeTrash?: boolean; isTrashOnly?: boolean }
  ): Promise<ConversationEntity[]>;
  getConversation?(id: string): Promise<ConversationEntity | null>;
  saveConversation?(conv: ConversationEntity): Promise<ConversationEntity>;
  deleteConversation?(id: string): Promise<boolean>;
  softDeleteConversation?(id: string): Promise<boolean>;
  restoreConversation?(id: string): Promise<ConversationEntity | null>;
  getMessages(conversationId: string): Promise<ChatMessage[]>;
  saveMessage(conversationId: string, message: ChatMessage): Promise<void>;

  // Memories
  getMemories(query?: { type?: string; text?: string; limit?: number }): Promise<MemoryEntry[]>;
  saveMemory(memory: MemoryEntry): Promise<MemoryEntry>;
  deleteMemory(id: string): Promise<boolean>;

  // Projects
  getProjects(userId: string): Promise<ProjectEntity[]>;
  getProject?(id: string): Promise<ProjectEntity | null>;
  saveProject?(project: ProjectEntity): Promise<ProjectEntity>;
  deleteProject?(id: string): Promise<boolean>;
  softDeleteProject?(id: string): Promise<boolean>;
  restoreProject?(id: string): Promise<ProjectEntity | null>;
  searchConversations?(userId: string, query: string, options?: { projectId?: string; includeArchived?: boolean }): Promise<Array<ConversationEntity & { matchedSnippet?: string }>>;

  // Tasks & Steps
  getTasks(): Promise<TaskItem[]>;
  getTask(id: string): Promise<TaskItem | null>;
  saveTask(task: TaskItem): Promise<TaskItem>;
  updateTask(id: string, updates: Partial<TaskItem>): Promise<TaskItem | null>;

  // Tools & Skills
  getRegisteredTools(): Promise<ToolDefinition[]>;
  getRegisteredSkills(): Promise<SkillDefinition[]>;
  recordToolCall(call: ToolCallEntity): Promise<void>;
  getToolCalls(limit?: number): Promise<ToolCallEntity[]>;

  // Agent Runs
  recordAgentRun(run: AgentRunEntity): Promise<void>;
  getAgentRuns(limit?: number): Promise<AgentRunEntity[]>;

  // Verification Results
  recordVerification(res: VerificationResult): Promise<void>;
  getVerifications(limit?: number): Promise<VerificationResult[]>;

  // Permissions & Audit
  recordAuditLog(log: AuditLog): Promise<void>;
  getAuditLogs(limit?: number): Promise<AuditLog[]>;

  // System Events
  emitEvent(event: SystemEvent): Promise<void>;
  getEvents(limit?: number): Promise<SystemEvent[]>;

  // Files & Attachments
  saveFile(file: FileAttachmentEntity): Promise<FileAttachmentEntity>;
  getFile(id: string): Promise<FileAttachmentEntity | null>;
  getFiles(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<FileAttachmentEntity[]>;
  deleteFile(id: string): Promise<boolean>;

  // Generated Documents
  saveDocument?(doc: GeneratedDocumentEntity): Promise<GeneratedDocumentEntity>;
  getDocument?(id: string): Promise<GeneratedDocumentEntity | null>;
  getDocuments?(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<GeneratedDocumentEntity[]>;
  deleteDocument?(id: string): Promise<boolean>;
}
