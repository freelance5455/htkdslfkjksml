import pg from 'pg';

import { config } from '../config/index.ts';
import type {
  AuditLog,
  ChatMessage,
  FileAttachmentEntity,
  GeneratedDocumentEntity,
  MemoryEntry,
  SkillDefinition,
  SystemEvent,
  TaskItem,
  ToolDefinition,
  VerificationResult,
} from '../types.ts';
import {
  DEFAULT_CONVERSATION,
  DEFAULT_MEMORIES,
  DEFAULT_MESSAGE,
  DEFAULT_PROJECT,
  DEFAULT_USER,
  POSTGRES_SCHEMA,
} from './schema.ts';
import type {
  AgentRunEntity,
  ConversationEntity,
  DatabaseHealth,
  IDatabase,
  ProjectEntity,
  ToolCallEntity,
  UserEntity,
} from './types.ts';

const { Pool } = pg;

export class PostgresDatabase implements IDatabase {
  private pool: pg.Pool;
  private isInitialized = false;
  private connectionString: string;

  constructor(
    connectionString?: string,
    poolOptions?: { max?: number; idleTimeoutMillis?: number; connectionTimeoutMillis?: number }
  ) {
    this.connectionString =
      connectionString ||
      config.database.databaseUrl ||
      'postgresql://postgres@localhost:5432/jarvis';

    const isLocal =
      this.connectionString.includes('localhost') ||
      this.connectionString.includes('127.0.0.1') ||
      this.connectionString.includes('host.docker.internal');

    this.pool = new Pool({
      connectionString: this.connectionString,
      ssl: isLocal ? false : { rejectUnauthorized: false },
      max: poolOptions?.max ?? config.database.poolMax,
      idleTimeoutMillis: poolOptions?.idleTimeoutMillis ?? config.database.idleTimeoutMs,
      connectionTimeoutMillis:
        poolOptions?.connectionTimeoutMillis ?? config.database.connectionTimeoutMs,
    });

    this.pool.on('error', (err) => {
      console.warn('[POSTGRES POOL WARNING]', err.message);
    });
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // Test connection
      const client = await this.pool.connect();
      try {
        await client.query(POSTGRES_SCHEMA);
        await this.seedDefaults(client);
        this.isInitialized = true;
        console.log('[POSTGRES] Connected and migrations executed successfully.');
      } finally {
        client.release();
      }
    } catch (error) {
      await this.pool.end().catch(() => {});
      throw error;
    }
  }

  private async seedDefaults(client: pg.PoolClient): Promise<void> {
    const check = await client.query('SELECT COUNT(*) as count FROM users');
    if (parseInt(check.rows[0]?.count || '0', 10) > 0) {
      return;
    }

    await client.query(
      `INSERT INTO users (id, username, name, role, created_at)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (id) DO NOTHING`,
      [DEFAULT_USER.id, DEFAULT_USER.username, DEFAULT_USER.name, DEFAULT_USER.role, DEFAULT_USER.createdAt]
    );

    await client.query(
      `INSERT INTO conversations (id, user_id, title, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (id) DO NOTHING`,
      [
        DEFAULT_CONVERSATION.id,
        DEFAULT_CONVERSATION.userId,
        DEFAULT_CONVERSATION.title,
        DEFAULT_CONVERSATION.createdAt,
        DEFAULT_CONVERSATION.updatedAt,
      ]
    );

    await client.query(
      `INSERT INTO messages (id, conversation_id, role, content, timestamp, metadata)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (id) DO NOTHING`,
      [
        DEFAULT_MESSAGE.id,
        DEFAULT_CONVERSATION.id,
        DEFAULT_MESSAGE.role,
        DEFAULT_MESSAGE.content,
        DEFAULT_MESSAGE.timestamp,
        null,
      ]
    );

    for (const mem of DEFAULT_MEMORIES) {
      await client.query(
        `INSERT INTO memories (id, user_id, type, key, content, importance, tags, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (id) DO NOTHING`,
        [
          mem.id,
          mem.userId,
          mem.type,
          mem.key,
          mem.content,
          mem.importance,
          JSON.stringify(mem.tags || []),
          mem.createdAt,
          mem.updatedAt,
        ]
      );
    }

    await client.query(
      `INSERT INTO projects (id, user_id, name, description, status, created_at)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (id) DO NOTHING`,
      [
        DEFAULT_PROJECT.id,
        DEFAULT_PROJECT.userId,
        DEFAULT_PROJECT.name,
        DEFAULT_PROJECT.description,
        DEFAULT_PROJECT.status,
        DEFAULT_PROJECT.createdAt,
      ]
    );
  }

  public async getHealth(): Promise<DatabaseHealth> {
    const tables = [
      'users',
      'conversations',
      'messages',
      'memories',
      'projects',
      'tasks',
      'tool_calls',
      'agent_runs',
      'verifications',
      'audit_logs',
      'system_events',
    ];

    const recordCounts: Record<string, number> = {};
    try {
      for (const t of tables) {
        const res = await this.pool.query(`SELECT COUNT(*) as cnt FROM ${t}`);
        recordCounts[t] = parseInt(res.rows[0]?.cnt || '0', 10);
      }

      // Obfuscate credentials from display string
      const sanitized = this.connectionString.replace(/:[^:@]+@/, ':***@');

      return {
        provider: 'postgres',
        status: 'CONNECTED',
        isPersistent: true,
        databasePathOrHost: sanitized,
        totalTables: tables.length,
        recordCounts,
        lastMigration: '2026-09-04-01-initial-postgres',
      };
    } catch (err: any) {
      return {
        provider: 'postgres',
        status: 'ERROR',
        isPersistent: true,
        databasePathOrHost: 'unreachable',
        totalTables: tables.length,
        recordCounts: {},
        lastMigration: 'unknown',
        error: err?.message || String(err),
      };
    }
  }

  public async getUser(id: string): Promise<UserEntity | null> {
    const res = await this.pool.query('SELECT * FROM users WHERE id = $1', [id]);
    const r = res.rows[0];
    if (!r) return null;
    return {
      id: r.id,
      username: r.username,
      name: r.name,
      role: r.role,
      createdAt: r.created_at,
    };
  }

  public async saveUser(user: UserEntity): Promise<UserEntity> {
    await this.pool.query(
      `INSERT INTO users (id, username, name, role, created_at)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (id) DO UPDATE SET
         username = EXCLUDED.username,
         name = EXCLUDED.name,
         role = EXCLUDED.role`,
      [user.id, user.username, user.name, user.role, user.createdAt]
    );
    return user;
  }

  public async getConversations(userId: string): Promise<ConversationEntity[]> {
    const res = await this.pool.query(
      'SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC',
      [userId]
    );
    return res.rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      title: r.title,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  }

  public async saveConversation(conv: ConversationEntity): Promise<ConversationEntity> {
    await this.pool.query(
      `INSERT INTO conversations (id, user_id, title, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (id) DO UPDATE SET
         title = EXCLUDED.title,
         updated_at = EXCLUDED.updated_at`,
      [conv.id, conv.userId, conv.title, conv.createdAt, conv.updatedAt]
    );
    return conv;
  }

  public async getMessages(conversationId: string): Promise<ChatMessage[]> {
    const res = await this.pool.query(
      'SELECT * FROM messages WHERE conversation_id = $1 ORDER BY timestamp ASC',
      [conversationId]
    );
    return res.rows.map((r) => ({
      id: r.id,
      role: r.role,
      content: r.content,
      timestamp: r.timestamp,
      taskId: r.task_id || undefined,
      coreStage: r.core_stage || undefined,
      metadata: r.metadata || undefined,
    }));
  }

  public async saveMessage(conversationId: string, message: ChatMessage): Promise<void> {
    await this.pool.query(
      `INSERT INTO conversations (id, user_id, title, created_at, updated_at)
       VALUES ($1, 'usr_jarvis_prime', 'Active Conversation', NOW(), NOW())
       ON CONFLICT (id) DO NOTHING`,
      [conversationId]
    );

    await this.pool.query(
      `INSERT INTO messages (id, conversation_id, role, content, timestamp, task_id, core_stage, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (id) DO UPDATE SET
         role = EXCLUDED.role,
         content = EXCLUDED.content,
         timestamp = EXCLUDED.timestamp,
         task_id = EXCLUDED.task_id,
         core_stage = EXCLUDED.core_stage,
         metadata = EXCLUDED.metadata`,
      [
        message.id,
        conversationId,
        message.role,
        message.content,
        message.timestamp,
        message.taskId || null,
        message.coreStage || null,
        message.metadata ? JSON.stringify(message.metadata) : null,
      ]
    );

    await this.pool.query(
      'UPDATE conversations SET updated_at = $1 WHERE id = $2',
      [message.timestamp || new Date().toISOString(), conversationId]
    );
  }

  public async getMemories(query?: { type?: string; text?: string; limit?: number }): Promise<MemoryEntry[]> {
    let sql = 'SELECT * FROM memories WHERE 1=1';
    const params: any[] = [];
    let idx = 1;

    if (query?.type) {
      sql += ` AND type = $${idx++}`;
      params.push(query.type);
    }
    if (query?.text) {
      sql += ` AND (key ILIKE $${idx} OR content ILIKE $${idx} OR tags::text ILIKE $${idx})`;
      params.push(`%${query.text}%`);
      idx++;
    }
    sql += ' ORDER BY importance DESC, created_at DESC';
    if (query?.limit) {
      sql += ` LIMIT $${idx++}`;
      params.push(query.limit);
    }

    const res = await this.pool.query(sql, params);
    return res.rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      type: r.type,
      key: r.key,
      content: r.content,
      importance: r.importance,
      tags: typeof r.tags === 'string' ? JSON.parse(r.tags) : r.tags || [],
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  }

  public async saveMemory(memory: MemoryEntry): Promise<MemoryEntry> {
    await this.pool.query(
      `INSERT INTO memories (id, user_id, type, key, content, importance, tags, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       ON CONFLICT (id) DO UPDATE SET
         type = EXCLUDED.type,
         key = EXCLUDED.key,
         content = EXCLUDED.content,
         importance = EXCLUDED.importance,
         tags = EXCLUDED.tags,
         updated_at = EXCLUDED.updated_at`,
      [
        memory.id,
        memory.userId,
        memory.type,
        memory.key,
        memory.content,
        memory.importance,
        JSON.stringify(memory.tags || []),
        memory.createdAt,
        memory.updatedAt,
      ]
    );
    return memory;
  }

  public async deleteMemory(id: string): Promise<boolean> {
    const res = await this.pool.query('DELETE FROM memories WHERE id = $1', [id]);
    return (res.rowCount || 0) > 0;
  }

  public async getProjects(userId: string): Promise<ProjectEntity[]> {
    const res = await this.pool.query(
      'SELECT * FROM projects WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    );
    return res.rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      name: r.name,
      description: r.description,
      status: r.status,
      createdAt: r.created_at,
    }));
  }

  public async saveProject(project: ProjectEntity): Promise<ProjectEntity> {
    await this.pool.query(
      `INSERT INTO projects (id, user_id, name, description, status, created_at)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (id) DO UPDATE SET
         name = EXCLUDED.name,
         description = EXCLUDED.description,
         status = EXCLUDED.status`,
      [
        project.id,
        project.userId,
        project.name,
        project.description,
        project.status,
        project.createdAt,
      ]
    );
    return project;
  }

  public async getTasks(): Promise<TaskItem[]> {
    const res = await this.pool.query('SELECT * FROM tasks ORDER BY created_at DESC');
    return res.rows.map((r) => this.rowToTask(r));
  }

  public async getTask(id: string): Promise<TaskItem | null> {
    const res = await this.pool.query('SELECT * FROM tasks WHERE id = $1', [id]);
    const r = res.rows[0];
    if (!r) return null;
    return this.rowToTask(r);
  }

  public async saveTask(task: TaskItem): Promise<TaskItem> {
    await this.pool.query(
      `INSERT INTO tasks (id, user_id, title, raw_prompt, status, current_stage, plan, logs, result_summary, pending_permission_step, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       ON CONFLICT (id) DO UPDATE SET
         title = EXCLUDED.title,
         raw_prompt = EXCLUDED.raw_prompt,
         status = EXCLUDED.status,
         current_stage = EXCLUDED.current_stage,
         plan = EXCLUDED.plan,
         logs = EXCLUDED.logs,
         result_summary = EXCLUDED.result_summary,
         pending_permission_step = EXCLUDED.pending_permission_step,
         updated_at = EXCLUDED.updated_at`,
      [
        task.id,
        task.userId,
        task.title,
        task.rawPrompt,
        task.status,
        task.currentStage,
        task.plan ? JSON.stringify(task.plan) : null,
        JSON.stringify(task.logs || []),
        task.resultSummary || null,
        task.pendingPermissionStep ? JSON.stringify(task.pendingPermissionStep) : null,
        task.createdAt,
        task.updatedAt || new Date().toISOString(),
      ]
    );
    return task;
  }

  public async updateTask(id: string, updates: Partial<TaskItem>): Promise<TaskItem | null> {
    const existing = await this.getTask(id);
    if (!existing) return null;
    const merged: TaskItem = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    return this.saveTask(merged);
  }

  private rowToTask(r: any): TaskItem {
    return {
      id: r.id,
      userId: r.user_id,
      title: r.title,
      rawPrompt: r.raw_prompt,
      status: r.status,
      currentStage: r.current_stage,
      plan: typeof r.plan === 'string' ? JSON.parse(r.plan) : r.plan || undefined,
      logs: typeof r.logs === 'string' ? JSON.parse(r.logs) : r.logs || [],
      resultSummary: r.result_summary || undefined,
      pendingPermissionStep:
        typeof r.pending_permission_step === 'string'
          ? JSON.parse(r.pending_permission_step)
          : r.pending_permission_step || undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  }

  public async getRegisteredTools(): Promise<ToolDefinition[]> {
    return [];
  }

  public async getRegisteredSkills(): Promise<SkillDefinition[]> {
    return [];
  }

  public async recordToolCall(call: ToolCallEntity): Promise<void> {
    await this.pool.query(
      `INSERT INTO tool_calls (id, task_id, tool_name, input, output, permission_granted, success, duration_ms, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [
        call.id,
        call.taskId || null,
        call.toolName,
        JSON.stringify(call.input ?? null),
        JSON.stringify(call.output ?? null),
        call.permissionGranted,
        call.success,
        call.durationMs || 0,
        call.timestamp,
      ]
    );
  }

  public async getToolCalls(limit = 50): Promise<ToolCallEntity[]> {
    const res = await this.pool.query(
      'SELECT * FROM tool_calls ORDER BY timestamp DESC LIMIT $1',
      [limit]
    );
    return res.rows.map((r) => ({
      id: r.id,
      taskId: r.task_id || undefined,
      toolName: r.tool_name,
      input: r.input,
      output: r.output,
      permissionGranted: Boolean(r.permission_granted),
      success: Boolean(r.success),
      durationMs: r.duration_ms,
      timestamp: r.timestamp,
    }));
  }

  public async recordAgentRun(run: AgentRunEntity): Promise<void> {
    await this.pool.query(
      `INSERT INTO agent_runs (id, task_id, agent_role, status, input, output, duration_ms, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        run.id,
        run.taskId || null,
        run.agentRole,
        run.status,
        run.input,
        run.output,
        run.durationMs || 0,
        run.timestamp,
      ]
    );
  }

  public async getAgentRuns(limit = 50): Promise<AgentRunEntity[]> {
    const res = await this.pool.query(
      'SELECT * FROM agent_runs ORDER BY timestamp DESC LIMIT $1',
      [limit]
    );
    return res.rows.map((r) => ({
      id: r.id,
      taskId: r.task_id || undefined,
      agentRole: r.agent_role,
      status: r.status,
      input: r.input,
      output: r.output,
      durationMs: r.duration_ms,
      timestamp: r.timestamp,
    }));
  }

  public async recordVerification(res: VerificationResult): Promise<void> {
    const id = `verif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    await this.pool.query(
      `INSERT INTO verifications (id, step_id, passed, score, failure_classification, remediation_advice, checks_performed, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        id,
        res.stepId,
        res.passed,
        res.score,
        res.failureClassification || null,
        res.remediationAdvice || null,
        JSON.stringify(res.checksPerformed || []),
        res.timestamp,
      ]
    );
  }

  public async getVerifications(limit = 50): Promise<VerificationResult[]> {
    const res = await this.pool.query(
      'SELECT * FROM verifications ORDER BY timestamp DESC LIMIT $1',
      [limit]
    );
    return res.rows.map((r) => ({
      stepId: r.step_id,
      status: r.passed ? ('VERIFIED' as const) : ('FAILED' as const),
      passed: Boolean(r.passed),
      score: parseFloat(r.score),
      failureClassification: r.failure_classification,
      remediationAdvice: r.remediation_advice || undefined,
      checksPerformed: typeof r.checks_performed === 'string' ? JSON.parse(r.checks_performed) : r.checks_performed || [],
      verifiedAt: r.timestamp,
      timestamp: r.timestamp,
    }));
  }

  public async recordAuditLog(log: AuditLog): Promise<void> {
    await this.pool.query(
      `INSERT INTO audit_logs (id, timestamp, action, actor, permission_level, details, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        log.id,
        log.timestamp,
        log.action,
        log.actor,
        log.permissionLevel,
        JSON.stringify(log.details || {}),
        log.status,
      ]
    );
  }

  public async getAuditLogs(limit = 50): Promise<AuditLog[]> {
    const res = await this.pool.query(
      'SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT $1',
      [limit]
    );
    return res.rows.map((r) => ({
      id: r.id,
      timestamp: r.timestamp,
      action: r.action,
      actor: r.actor,
      permissionLevel: r.permission_level as any,
      details: typeof r.details === 'string' ? JSON.parse(r.details) : r.details || {},
      status: r.status as any,
    }));
  }

  public async emitEvent(event: SystemEvent): Promise<void> {
    await this.pool.query(
      `INSERT INTO system_events (id, timestamp, type, stage, message, data)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        event.id,
        event.timestamp,
        event.type,
        event.stage || null,
        event.message,
        event.data ? JSON.stringify(event.data) : null,
      ]
    );
  }

  public async getEvents(limit = 50): Promise<SystemEvent[]> {
    const res = await this.pool.query(
      'SELECT * FROM system_events ORDER BY timestamp DESC LIMIT $1',
      [limit]
    );
    return res.rows.map((r) => ({
      id: r.id,
      timestamp: r.timestamp,
      type: r.type as any,
      stage: r.stage as any,
      message: r.message,
      data: r.data,
    }));
  }

  // Files & Attachments
  public async saveFile(file: FileAttachmentEntity): Promise<FileAttachmentEntity> {
    await this.pool.query(
      `INSERT INTO files (
        id, conversation_id, project_id, user_id, filename, original_name,
        mime_type, size_bytes, file_category, storage_path, text_content,
        summary, is_extracted, extraction_status, extraction_note, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      ON CONFLICT (id) DO UPDATE SET
        conversation_id = EXCLUDED.conversation_id,
        project_id = EXCLUDED.project_id,
        filename = EXCLUDED.filename,
        text_content = EXCLUDED.text_content,
        summary = EXCLUDED.summary,
        is_extracted = EXCLUDED.is_extracted,
        extraction_status = EXCLUDED.extraction_status,
        extraction_note = EXCLUDED.extraction_note,
        updated_at = EXCLUDED.updated_at`,
      [
        file.id,
        file.conversationId || null,
        file.projectId || null,
        file.userId,
        file.filename,
        file.originalName,
        file.mimeType,
        file.sizeBytes,
        file.fileCategory,
        file.storagePath,
        file.textContent || null,
        file.summary || null,
        file.isExtracted,
        file.extractionStatus || 'EMPTY',
        file.extractionNote || null,
        file.createdAt,
        file.updatedAt || file.createdAt,
      ]
    );
    return file;
  }

  public async getFile(id: string): Promise<FileAttachmentEntity | null> {
    const res = await this.pool.query('SELECT * FROM files WHERE id = $1', [id]);
    if (res.rows.length === 0) return null;
    return this.mapFileRow(res.rows[0]);
  }

  public async getFiles(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<FileAttachmentEntity[]> {
    let query = 'SELECT * FROM files WHERE 1=1';
    const params: any[] = [];
    let idx = 1;
    if (filter?.conversationId) {
      query += ` AND conversation_id = $${idx++}`;
      params.push(filter.conversationId);
    }
    if (filter?.projectId) {
      query += ` AND project_id = $${idx++}`;
      params.push(filter.projectId);
    }
    if (filter?.userId) {
      query += ` AND user_id = $${idx++}`;
      params.push(filter.userId);
    }
    query += ' ORDER BY created_at DESC';
    const res = await this.pool.query(query, params);
    return res.rows.map((r) => this.mapFileRow(r));
  }

  public async deleteFile(id: string): Promise<boolean> {
    const res = await this.pool.query('DELETE FROM files WHERE id = $1', [id]);
    return (res.rowCount ?? 0) > 0;
  }

  private mapFileRow(r: any): FileAttachmentEntity {
    return {
      id: r.id,
      conversationId: r.conversation_id || undefined,
      projectId: r.project_id || undefined,
      userId: r.user_id,
      filename: r.filename,
      originalName: r.original_name,
      mimeType: r.mime_type,
      sizeBytes: Number(r.size_bytes),
      fileCategory: r.file_category,
      storagePath: r.storage_path,
      textContent: r.text_content || undefined,
      summary: r.summary || undefined,
      isExtracted: Boolean(r.is_extracted),
      extractionStatus: r.extraction_status,
      extractionNote: r.extraction_note || undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at || undefined,
    };
  }

  // Generated Documents
  public async saveDocument(doc: GeneratedDocumentEntity): Promise<GeneratedDocumentEntity> {
    await this.pool.query(
      `INSERT INTO documents (
        id, title, filename, format, content, size_bytes,
        conversation_id, project_id, user_id, created_at, download_url
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      ON CONFLICT (id) DO UPDATE SET
        title = EXCLUDED.title,
        content = EXCLUDED.content,
        download_url = EXCLUDED.download_url`,
      [
        doc.id,
        doc.title,
        doc.filename,
        doc.format,
        doc.content,
        doc.sizeBytes,
        doc.conversationId || null,
        doc.projectId || null,
        doc.userId,
        doc.createdAt,
        doc.downloadUrl,
      ]
    );
    return doc;
  }

  public async getDocument(id: string): Promise<GeneratedDocumentEntity | null> {
    const res = await this.pool.query('SELECT * FROM documents WHERE id = $1', [id]);
    if (res.rows.length === 0) return null;
    const r = res.rows[0];
    return {
      id: r.id,
      title: r.title,
      filename: r.filename,
      format: r.format,
      content: r.content,
      sizeBytes: Number(r.size_bytes),
      conversationId: r.conversation_id || undefined,
      projectId: r.project_id || undefined,
      userId: r.user_id,
      createdAt: r.created_at,
      downloadUrl: r.download_url,
    };
  }

  public async getDocuments(filter?: { conversationId?: string; projectId?: string; userId?: string }): Promise<GeneratedDocumentEntity[]> {
    let query = 'SELECT * FROM documents WHERE 1=1';
    const params: any[] = [];
    let idx = 1;
    if (filter?.conversationId) {
      query += ` AND conversation_id = $${idx++}`;
      params.push(filter.conversationId);
    }
    if (filter?.projectId) {
      query += ` AND project_id = $${idx++}`;
      params.push(filter.projectId);
    }
    if (filter?.userId) {
      query += ` AND user_id = $${idx++}`;
      params.push(filter.userId);
    }
    query += ' ORDER BY created_at DESC';
    const res = await this.pool.query(query, params);
    return res.rows.map((r) => ({
      id: r.id,
      title: r.title,
      filename: r.filename,
      format: r.format,
      content: r.content,
      sizeBytes: Number(r.size_bytes),
      conversationId: r.conversation_id || undefined,
      projectId: r.project_id || undefined,
      userId: r.user_id,
      createdAt: r.created_at,
      downloadUrl: r.download_url,
    }));
  }

  public async close(): Promise<void> {
    try {
      await this.pool.end();
    } catch {}
    this.isInitialized = false;
  }
}
