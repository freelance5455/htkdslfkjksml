import { describe, expect, it } from "vitest";
import { demoIncidents, demoOverview, demoSupport } from "./demo-data";
import {
  issueRecoveryCodes,
  matchesRecoveryCode,
  verifyTotp,
} from "./admin-auth";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const makeContext = (overrides: Partial<TrpcContext> = {}): TrpcContext => ({
  req: { method: "GET", headers: {}, ip: "127.0.0.1" } as TrpcContext["req"],
  res: { clearCookie() {} } as unknown as TrpcContext["res"],
  user: null,
  admin: null,
  ...overrides,
});

describe("dashboard admin security", () => {
  it("verifies RFC 6238 TOTP values with a time-based code", () => {
    const rfcSecret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ";
    expect(verifyTotp(rfcSecret, "287082", 59_000)).toBe(true);
    expect(verifyTotp(rfcSecret, "000000", 59_000)).toBe(false);
  });

  it("consumes a recovery code exactly once", () => {
    const pack = issueRecoveryCodes();
    const remaining = matchesRecoveryCode(pack.codes[0]!, pack.hashes);
    expect(remaining).not.toBeNull();
    expect(matchesRecoveryCode(pack.codes[0]!, remaining!)).toBeNull();
    expect(matchesRecoveryCode(pack.codes[1]!, pack.hashes)).not.toBeNull();
  });

  it("rejects aggregate admin data calls without an authenticated admin", async () => {
    const caller = appRouter.createCaller(makeContext());
    await expect(caller.dashboard.overview()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("limits support administrators to their anonymized support queue", async () => {
    const caller = appRouter.createCaller(
      makeContext({
        admin: {
          id: 2,
          email: "support@example.invalid",
          displayName: "Support",
          role: "support",
        },
      })
    );
    await expect(caller.dashboard.support()).resolves.toMatchObject({
      dataMode: "DEMO",
    });
    await expect(caller.dashboard.overview()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    await expect(caller.dashboard.incidents()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    await expect(caller.configuration.listFeatures()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    await expect(caller.operations.listReleases()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    await expect(caller.audit.list()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("rejects admin mutations without the CSRF double-submit proof", async () => {
    const ctx = makeContext({
      req: {
        method: "POST",
        headers: { cookie: "" },
        ip: "127.0.0.1",
      } as TrpcContext["req"],
      admin: {
        id: 1,
        email: "owner@example.invalid",
        displayName: "Owner",
        role: "owner",
      },
    });
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.configuration.setFeature({ key: "zakat_tools", enabled: false })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("keeps synthetic user/incident/support records free of personal financial fields", () => {
    const payload = JSON.stringify({
      demoOverview,
      demoIncidents,
      demoSupport,
    }).toLowerCase();
    for (const forbidden of [
      "bank_balance",
      "personal_debt",
      "financial_record",
      "income",
      "zakat_information",
      "account_number",
    ]) {
      expect(payload).not.toContain(forbidden);
    }
    for (const collection of [demoOverview, ...demoIncidents, ...demoSupport]) {
      for (const key of Object.keys(collection)) {
        expect(key.toLowerCase()).not.toMatch(
          /(debt|balance|income|zakat|accountnumber|financialrecord)/
        );
      }
    }
  });
});
