/**
 * JARVIS User Preference Memory System
 * Manages explicit user preferences for language, explanation depth, technical level,
 * and project context. Stored persistently with editable/deletable lifecycle.
 */

import { db } from '../db/database.ts';
import type { MemoryEntry, MemoryEpistemicState, ResponseDepthLevel } from '../types.ts';

export interface UserPreferences {
  preferredLanguage?: 'en' | 'hi' | 'hinglish';
  explanationDepth?: 'brief' | 'standard' | 'in-depth' | ResponseDepthLevel;
  teachingStyle?: 'intuitive' | 'rigorous' | 'socratic' | 'practical';
  technicalLevel?: 'beginner' | 'intermediate' | 'expert';
  activeProject?: string;
  responseFormat?: 'markdown' | 'concise' | 'structured';
  customPreferences?: Record<string, string>;
}

export class PreferenceSystem {
  private static readonly PREF_KEY_PREFIX = 'user_pref_';

  /**
   * Parse a natural language statement to extract preferences
   * E.g. "Remember that I prefer detailed Hinglish explanations."
   */
  public parsePreferenceStatement(statement: string): { key: string; value: string }[] {
    const lower = statement.toLowerCase();
    const results: { key: string; value: string }[] = [];

    // Language preference
    if (lower.includes('hinglish')) {
      results.push({ key: 'preferred_language', value: 'hinglish' });
    } else if (lower.includes('hindi') || lower.includes('devanagari')) {
      results.push({ key: 'preferred_language', value: 'hi' });
    } else if (lower.includes('english')) {
      results.push({ key: 'preferred_language', value: 'en' });
    }

    // Depth preference
    if (
      lower.includes('detailed') ||
      lower.includes('detail mein') ||
      lower.includes('detail me') ||
      lower.includes('vistar se')
    ) {
      results.push({ key: 'explanation_depth', value: 'DETAILED' });
    } else if (lower.includes('deep level') || lower.includes('jee level') || lower.includes('rigorous')) {
      results.push({ key: 'explanation_depth', value: 'DEEP' });
    } else if (lower.includes('research level') || lower.includes('academic')) {
      results.push({ key: 'explanation_depth', value: 'RESEARCH' });
    } else if (lower.includes('brief') || lower.includes('short') || lower.includes('simple batao') || lower.includes('simple samjhao')) {
      results.push({ key: 'explanation_depth', value: 'BRIEF' });
    }

    // Zero-cost requirement
    if (lower.includes('₹0') || lower.includes('zero cost') || lower.includes('zero mandatory')) {
      results.push({ key: 'cost_constraint', value: '₹0 mandatory cost target' });
    }

    // If no standard preference was found, treat as general knowledge preference
    if (results.length === 0) {
      const clean = statement
        .replace(/^(?:please\s+)?remember\s+(?:that|this\s+as\s+important:?|this:?)\s*/i, '')
        .trim();
      if (clean) {
        results.push({ key: 'general_preference', value: clean });
      }
    }

    return results;
  }

  /**
   * Classifies memory state for a given inquiry or key
   */
  public async classifyMemoryState(
    keyOrQuery: string,
    userId = 'usr_jarvis_prime'
  ): Promise<{ state: MemoryEpistemicState; content?: string; key?: string }> {
    const memories = await db.getMemories({ limit: 50 });
    const target = keyOrQuery.toLowerCase();

    // Check persistent database storage
    const found = memories.find((m) =>
      m.key.toLowerCase().includes(target) || m.content.toLowerCase().includes(target)
    );

    if (found) {
      return {
        state: 'STORED',
        content: found.content,
        key: found.key,
      };
    }

    return {
      state: 'UNKNOWN',
    };
  }

  /**
   * Retrieve all active preferences for a user
   */
  public async getPreferences(userId = 'usr_jarvis_prime'): Promise<UserPreferences> {
    const memories = await db.getMemories({ type: 'knowledge', limit: 50 });
    const prefs: UserPreferences = {
      customPreferences: {},
    };

    for (const mem of memories) {
      if (!mem.key.startsWith(PreferenceSystem.PREF_KEY_PREFIX)) continue;
      const cleanKey = mem.key.replace(PreferenceSystem.PREF_KEY_PREFIX, '');

      switch (cleanKey) {
        case 'preferred_language':
          if (['en', 'hi', 'hinglish'].includes(mem.content)) {
            prefs.preferredLanguage = mem.content as any;
          }
          break;
        case 'explanation_depth':
          if (['brief', 'standard', 'in-depth'].includes(mem.content)) {
            prefs.explanationDepth = mem.content as any;
          }
          break;
        case 'teaching_style':
          prefs.teachingStyle = mem.content as any;
          break;
        case 'technical_level':
          if (['beginner', 'intermediate', 'expert'].includes(mem.content)) {
            prefs.technicalLevel = mem.content as any;
          }
          break;
        case 'active_project':
          prefs.activeProject = mem.content;
          break;
        case 'response_format':
          prefs.responseFormat = mem.content as any;
          break;
        default:
          if (prefs.customPreferences) {
            prefs.customPreferences[cleanKey] = mem.content;
          }
          break;
      }
    }

    return prefs;
  }

  /**
   * Set or update a specific preference
   */
  public async setPreference(
    key: string,
    value: string,
    userId = 'usr_jarvis_prime'
  ): Promise<MemoryEntry> {
    const prefKey = `${PreferenceSystem.PREF_KEY_PREFIX}${key}`;
    // Look for existing memory
    const existing = await db.getMemories({ type: 'knowledge' });
    const match = existing.find((m) => m.key === prefKey);

    const entry: MemoryEntry = {
      id: match?.id || `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      type: 'knowledge',
      key: prefKey,
      content: value,
      importance: 9,
      tags: ['preference', key],
      createdAt: match?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.saveMemory(entry);
    return entry;
  }

  /**
   * Delete a specific preference
   */
  public async deletePreference(key: string, userId = 'usr_jarvis_prime'): Promise<boolean> {
    const prefKey = `${PreferenceSystem.PREF_KEY_PREFIX}${key}`;
    const existing = await db.getMemories({ type: 'knowledge' });
    const match = existing.find((m) => m.key === prefKey);
    if (match) {
      return db.deleteMemory(match.id);
    }
    return false;
  }

  /**
   * Clear all user preferences
   */
  public async clearAllPreferences(userId = 'usr_jarvis_prime'): Promise<number> {
    const existing = await db.getMemories({ type: 'knowledge' });
    let deletedCount = 0;
    for (const mem of existing) {
      if (mem.key.startsWith(PreferenceSystem.PREF_KEY_PREFIX)) {
        await db.deleteMemory(mem.id);
        deletedCount++;
      }
    }
    return deletedCount;
  }
}

export const preferenceSystem = new PreferenceSystem();
