export interface Memory {
  id: string;
  key: string;
  value: string;
  confidence: number;
}

const memories = new Map<string, Memory>();

export function remember(key: string, value: string): Memory {
  const item = { id: crypto.randomUUID(), key, value, confidence: 1 };
  memories.set(key, item);
  return item;
}

export function recall(key: string): Memory | undefined {
  return memories.get(key);
}

export function relevantMemories(query: string): Memory[] {
  const q = query.toLowerCase();
  return [...memories.values()].filter(m =>
    q.includes(m.key.toLowerCase()) || m.value.toLowerCase().includes(q)
  );
}
