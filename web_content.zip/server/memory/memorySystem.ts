/**
 * JARVIS Memory System Abstraction
 * Supports short-term, long-term, task history, and knowledge documents.
 * Features importance scoring, hybrid relevance retrieval, and a pluggable vector store interface.
 */

import { db } from '../db/database.ts';
import type { IDatabase } from '../db/database.ts';
import type { MemoryEntry, MemoryQuery } from '../types.ts';

export interface VectorEmbedding {
  id: string;
  vector: number[];
  metadata: Record<string, unknown>;
}

export interface IVectorStore {
  upsert(embedding: VectorEmbedding): Promise<void>;
  querySimilar(vector: number[], topK: number): Promise<string[]>;
}

/**
 * Lightweight in-memory cosine vector store for forward compatibility
 */
export class SimpleVectorStore implements IVectorStore {
  private vectors: Map<string, number[]> = new Map();

  async upsert(embedding: VectorEmbedding): Promise<void> {
    this.vectors.set(embedding.id, embedding.vector);
  }

  async querySimilar(queryVector: number[], topK: number): Promise<string[]> {
    const scores: { id: string; score: number }[] = [];
    for (const [id, vec] of this.vectors.entries()) {
      const score = this.cosineSimilarity(queryVector, vec);
      scores.push({ id, score });
    }
    scores.sort((a, b) => b.score - a.score);
    return scores.slice(0, topK).map((s) => s.id);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length || a.length === 0) return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB) || 1);
  }
}

export class MemorySystem {
  private database: IDatabase;
  private vectorStore: IVectorStore;

  constructor(database: IDatabase = db, vectorStore: IVectorStore = new SimpleVectorStore()) {
    this.database = database;
    this.vectorStore = vectorStore;
  }

  /**
   * Add or update a memory entry
   */
  public async store(
    entry: Omit<MemoryEntry, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<MemoryEntry> {
    const id = `mem_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const fullEntry: MemoryEntry = {
      ...entry,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await this.database.saveMemory(fullEntry);

    // Forward compatibility: generate synthetic pseudo-embedding for future vector queries
    const syntheticVector = this.computePseudoEmbedding(fullEntry.content);
    await this.vectorStore.upsert({
      id: fullEntry.id,
      vector: syntheticVector,
      metadata: { key: fullEntry.key, type: fullEntry.type },
    });

    return fullEntry;
  }

  /**
   * Retrieve relevant memories matching query criteria
   */
  public async retrieve(query: MemoryQuery): Promise<MemoryEntry[]> {
    const all = await this.database.getMemories({
      type: query.type,
      text: query.text,
      limit: query.limit ?? 10,
    });

    if (query.minImportance !== undefined) {
      return all.filter((m) => m.importance >= query.minImportance!);
    }
    return all;
  }

  /**
   * Build unified memory context string for model prompts
   */
  public async getPromptContext(userGoal: string): Promise<string> {
    const relevantMemories = await this.retrieve({
      text: userGoal,
      limit: 6,
    });

    if (relevantMemories.length === 0) {
      return 'No specific prior memories found for this task context.';
    }

    const lines = relevantMemories.map(
      (m) => `[${m.type.toUpperCase()}] (Importance ${m.importance}/10) ${m.key}: ${m.content}`
    );

    return lines.join('\n');
  }

  /**
   * Delete memory
   */
  public async delete(id: string): Promise<boolean> {
    return this.database.deleteMemory(id);
  }

  /**
   * Compute normalized character n-gram distribution as deterministic vector
   */
  private computePseudoEmbedding(text: string): number[] {
    const dim = 16;
    const vector = new Array(dim).fill(0);
    const cleaned = text.toLowerCase();
    for (let i = 0; i < cleaned.length; i++) {
      const charCode = cleaned.charCodeAt(i);
      vector[charCode % dim] += 1;
    }
    const magnitude = Math.sqrt(vector.reduce((acc, v) => acc + v * v, 0)) || 1;
    return vector.map((v) => v / magnitude);
  }
}

export const memorySystem = new MemorySystem();
