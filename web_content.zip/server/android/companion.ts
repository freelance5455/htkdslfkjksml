export const androidCompanion = {
  packageName: "ai.jarvis.companion",
  offlineSync: true,
  assistantIntegration: true,
  backgroundOperation: "OS_PERMISSION_REQUIRED",
  screenAwareness: "ACCESSIBILITY_PERMISSION_REQUIRED",
  deviceControl: "EXPLICIT_PERMISSION_REQUIRED",
  apkCompilation: "ANDROID_BUILD_ENVIRONMENT_REQUIRED"
};
