import os, hmac
from datetime import datetime, timedelta, timezone
import jwt
from pwdlib import PasswordHash
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .database import get_db
from .models import User

ALGORITHM = "HS256"
SECRET = os.getenv("SKYNET_JWT_SECRET", "")
TOKEN_MINUTES = int(os.getenv("TOKEN_MINUTES", "30"))
password_hash = PasswordHash.recommended()
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/token")


def hash_password(value: str) -> str:
    return password_hash.hash(value)

def verify_password(value: str, hashed: str) -> bool:
    return password_hash.verify(value, hashed)

def create_token(user: User) -> str:
    if len(SECRET) < 32:
        raise HTTPException(status_code=503, detail="Configuration JWT manquante : définir SKYNET_JWT_SECRET (32 caractères minimum)")
    now = datetime.now(timezone.utc)
    payload = {"sub": user.id, "org": user.organization_id, "role": user.role, "tv": int(user.token_version),
               "iat": now, "exp": now + timedelta(minutes=TOKEN_MINUTES)}
    return jwt.encode(payload, SECRET, algorithm=ALGORITHM)

def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> User:
    if len(SECRET) < 32:
        raise HTTPException(status_code=503, detail="Configuration JWT manquante")
    try:
        payload = jwt.decode(token, SECRET, algorithms=[ALGORITHM], options={"require": ["exp", "sub", "org", "role", "tv"]})
        user = db.get(User, payload["sub"])
        if not user or not user.active or user.organization_id != payload["org"] or user.role != payload["role"] or int(user.token_version) != int(payload["tv"]):
            raise ValueError("invalid user")
        return user
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Jeton invalide ou expiré", headers={"WWW-Authenticate": "Bearer"})

def require_roles(*roles: str):
    def checker(user: User = Depends(current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Permission insuffisante")
        return user
    return checker
