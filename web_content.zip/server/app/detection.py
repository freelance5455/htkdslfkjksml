"""Small deterministic defensive rule engine used for synthetic self-tests."""
from fastapi import HTTPException

DETECTION_RULES = {
    "critical_security_event": {"description": "Détecte un événement explicitement classé critique.", "event_types": ["*"], "minimum_severity": "critical"},
    "authentication_anomaly": {"description": "Repère les événements d'échec d'authentification connus.", "event_types": ["auth.failed_login", "authentication.failed", "login.failed"], "minimum_severity": "high"},
    "malware_alert": {"description": "Repère les événements malware/antivirus signalés par une source autorisée.", "event_types": ["malware.detected", "malware.quarantined", "edr.malware_alert"], "minimum_severity": "high"},
    "ransomware_signal": {"description": "Repère les événements de détection de rançongiciel signalés par un outil défensif.", "event_types": ["ransomware.detected", "edr.ransomware_alert"], "minimum_severity": "critical"},
}
SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def evaluate_detection_rule(rule_name: str, event_type: str, severity: str) -> dict:
    rule = DETECTION_RULES.get(rule_name)
    if not rule:
        raise HTTPException(404, "Règle de détection inconnue")
    if severity not in SEVERITY_ORDER:
        raise HTTPException(422, "Niveau de gravité invalide")
    event_match = "*" in rule["event_types"] or event_type.lower() in rule["event_types"]
    severity_match = SEVERITY_ORDER[severity] >= SEVERITY_ORDER[rule["minimum_severity"]]
    return {"matched": bool(event_match and severity_match), "event_type_match": event_match,
            "severity_match": severity_match, "rule_name": rule_name}
