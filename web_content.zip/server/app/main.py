import hashlib, os, uuid, hmac
from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import select, desc, func
from collections import defaultdict, deque
from threading import Lock
import time
from .database import Base, engine, get_db
from .models import Organization, User, SecurityEvent, AuditEntry, Approval, ThreatIndicator
from .security import verify_password, create_token, current_user, require_roles, hash_password

app = FastAPI(title="SKYNET V2 API", version="0.3.0", description="Socle serveur de préparation — prototype, à auditer avant production")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8000").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])

_auth_attempts = defaultdict(deque)
_auth_lock = Lock()
AUTH_WINDOW_SECONDS = int(os.getenv("AUTH_RATE_WINDOW_SECONDS", "60"))
AUTH_MAX_ATTEMPTS = int(os.getenv("AUTH_RATE_MAX_ATTEMPTS", "8"))

@app.middleware("http")
async def auth_rate_limit(request: Request, call_next):
    if request.url.path in ("/auth/token", "/setup/first-admin") and request.method == "POST":
        client_ip = request.client.host if request.client else "unknown"
        key = f"{request.url.path}:{client_ip}"
        now = time.monotonic()
        with _auth_lock:
            attempts = _auth_attempts[key]
            while attempts and now - attempts[0] > AUTH_WINDOW_SECONDS:
                attempts.popleft()
            if len(attempts) >= AUTH_MAX_ATTEMPTS:
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=429, content={"detail": "Trop de tentatives. Réessayez plus tard."}, headers={"Retry-After": str(AUTH_WINDOW_SECONDS)})
            attempts.append(now)
    return await call_next(request)
# Schéma géré par Alembic : aucune modification implicite de la base au démarrage.

class EventIn(BaseModel):
    source: str = Field(min_length=1, max_length=100)
    event_type: str = Field(min_length=1, max_length=100)
    severity: str = Field(default="info", pattern="^(info|low|medium|high|critical)$")
    asset: str | None = Field(default=None, max_length=255)
    summary: str = Field(min_length=1, max_length=10000)
    evidence_text: str | None = Field(default=None, max_length=2_000_000)

class ApprovalIn(BaseModel):
    action_type: str = Field(min_length=1, max_length=100)
    target: str = Field(min_length=1, max_length=255)
    justification: str = Field(min_length=10, max_length=5000)

class ReviewIn(BaseModel):
    decision: str = Field(pattern="^(approved|rejected)$")
    note: str = Field(min_length=3, max_length=2000)

class IndicatorIn(BaseModel):
    indicator_type: str = Field(pattern="^(domain|ipv4|sha256|url)$")
    value: str = Field(min_length=3, max_length=2048)
    source: str = Field(min_length=2, max_length=120)
    confidence: int = Field(default=50, ge=0, le=100)
    note: str | None = Field(default=None, max_length=2000)

class DetectionTestIn(BaseModel):
    rule_name: str = Field(min_length=2, max_length=120)
    sample_event_type: str = Field(min_length=2, max_length=100)
    expected_severity: str = Field(pattern="^(info|low|medium|high|critical)$")

class BootstrapIn(BaseModel):
    organization_name: str = Field(min_length=2, max_length=180)
    admin_email: str = Field(min_length=5, max_length=255)
    admin_password: str = Field(min_length=14, max_length=200)
    setup_key: str = Field(min_length=20, max_length=200)

@app.get("/ready")
def readiness(db: Session = Depends(get_db)):
    """Readiness probe: verifies database access; does not imply production certification."""
    try:
        db.execute(select(func.count()).select_from(Organization)).scalar_one()
        return {"status": "ready", "database": "reachable", "production_certified": False}
    except Exception:
        raise HTTPException(503, "Base de données indisponible")

@app.get("/platform/capabilities")
def capabilities():
    return {
        "api": True, "tenant_scoped_storage": True, "human_approval_workflow": True,
        "event_ingestion": True, "indicator_registry": "local_tenant_scoped_registry",
        "local_correlation": "same_asset_candidates_only", "detection_rule_engine": "local_rules_v1",
        "ai_provider": "not_configured", "live_cti_feeds": "not_configured",
        "external_edr_siem_connectors": "not_configured", "production_certified": False
    }

def normalize_indicator(indicator_type: str, raw_value: str) -> str:
    value = raw_value.strip().lower()
    if indicator_type == "sha256":
        if len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
            raise HTTPException(422, "Une empreinte SHA-256 doit contenir 64 caractères hexadécimaux")
    elif indicator_type == "ipv4":
        import ipaddress
        try:
            value = str(ipaddress.IPv4Address(value))
        except ValueError:
            raise HTTPException(422, "Adresse IPv4 invalide")
    elif indicator_type == "domain":
        import re
        if len(value) > 253 or not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", value):
            raise HTTPException(422, "Nom de domaine invalide")
    elif indicator_type == "url":
        from urllib.parse import urlsplit
        parsed = urlsplit(value)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise HTTPException(422, "URL invalide : seuls http et https sont acceptés")
    return value

@app.post("/indicators")
def add_indicator(data: IndicatorIn, user: User = Depends(require_roles("admin", "security_manager", "analyst")), db: Session = Depends(get_db)):
    value = normalize_indicator(data.indicator_type, data.value)
    value_hash = hashlib.sha256(value.encode("utf-8")).hexdigest()
    existing = db.scalar(select(ThreatIndicator).where(
        ThreatIndicator.organization_id == user.organization_id,
        ThreatIndicator.indicator_type == data.indicator_type,
        ThreatIndicator.value_hash == value_hash))
    if existing:
        existing.confidence = max(existing.confidence, data.confidence)
        existing.note = data.note or existing.note
        existing.source = data.source
        db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id,
            action="indicator.updated", object_type="threat_indicator", object_id=existing.id,
            details={"indicator_type": data.indicator_type, "value_sha256": value_hash}))
        db.commit()
        return {"id": existing.id, "status": "updated", "value_sha256": value_hash, "external_reputation_checked": False}
    item = ThreatIndicator(id=str(uuid.uuid4()), organization_id=user.organization_id,
        indicator_type=data.indicator_type, value=value, value_hash=value_hash, source=data.source,
        confidence=data.confidence, note=data.note, created_by=user.id)
    db.add(item)
    db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id,
        action="indicator.registered", object_type="threat_indicator", object_id=item.id,
        details={"indicator_type": data.indicator_type, "value_sha256": value_hash,
                  "source": data.source, "confidence": data.confidence}))
    db.commit()
    return {"id": item.id, "status": "stored", "value_sha256": value_hash,
            "external_reputation_checked": False,
            "message": "Indicateur stocké dans le registre de l'organisation ; aucune réputation externe n'a été vérifiée."}

@app.get("/indicators")
def list_indicators(limit: int = 100, user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = max(1, min(limit, 500))
    rows = db.scalars(select(ThreatIndicator).where(ThreatIndicator.organization_id == user.organization_id)
        .order_by(desc(ThreatIndicator.created_at)).limit(limit)).all()
    return [{"id": x.id, "indicator_type": x.indicator_type, "value": x.value,
        "value_sha256": x.value_hash, "source": x.source, "confidence": x.confidence,
        "note": x.note, "status": x.status, "created_at": x.created_at.isoformat()} for x in rows]

from .detection import DETECTION_RULES, evaluate_detection_rule

@app.get("/detection-rules")
def list_detection_rules(user: User = Depends(current_user)):
    return [{"name": name, **rule} for name, rule in DETECTION_RULES.items()]

@app.get("/correlations")
def correlations(limit: int = 200, user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = max(1, min(limit, 500))
    rows = db.scalars(select(SecurityEvent).where(SecurityEvent.organization_id == user.organization_id)
                      .order_by(desc(SecurityEvent.created_at)).limit(limit)).all()
    groups = {}
    for event in rows:
        if event.asset:
            groups.setdefault(event.asset.casefold(), []).append(event)
    links = []
    for asset, events in groups.items():
        if len(events) > 1:
            links.append({"asset": asset, "event_ids": [e.id for e in events],
                          "count": len(events), "severities": sorted({e.severity for e in events}),
                          "confidence": "candidate_only"})
    return {"events_examined": len(rows), "candidate_links": links,
            "method": "same-asset grouping", "confirmed_incidents": 0,
            "warning": "Les rapprochements sont des pistes à examiner, pas des incidents confirmés."}

@app.post("/detection-tests")
def detection_test(data: DetectionTestIn, user: User = Depends(require_roles("admin", "security_manager", "analyst")), db: Session = Depends(get_db)):
    result = evaluate_detection_rule(data.rule_name, data.sample_event_type, data.expected_severity)
    synthetic = SecurityEvent(id=str(uuid.uuid4()), organization_id=user.organization_id,
        source="skynet-self-test", event_type=data.sample_event_type, severity=data.expected_severity,
        asset="SYNTHETIC-TEST", summary="Événement synthétique de test — aucune menace réelle", evidence_sha256=None)
    db.add(synthetic)
    db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id,
        action="detection.rule_tested", object_type="detection_test", object_id=synthetic.id,
        details={"rule_name": data.rule_name, "result": result, "synthetic": True}))
    db.commit()
    return {"test_id": synthetic.id, "passed": result["matched"], "detection": result,
        "scope": "local_rule_logic_and_synthetic_event", "production_detection_effectiveness_verified": False,
        "synthetic": True, "message": "Test de logique locale uniquement ; ne prouve pas la détection en production."}


@app.get("/risk/summary")
def risk_summary(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Transparent operational score based only on this tenant's recent stored events."""
    rows = db.scalars(select(SecurityEvent).where(SecurityEvent.organization_id == user.organization_id)
        .order_by(desc(SecurityEvent.created_at)).limit(500)).all()
    weights = {"info": 0, "low": 5, "medium": 12, "high": 22, "critical": 35}
    raw = sum(weights.get(e.severity, 0) for e in rows)
    score = min(100, raw)
    level = "low" if score < 20 else "moderate" if score < 45 else "high" if score < 70 else "critical"
    counts = {key: sum(1 for e in rows if e.severity == key) for key in weights}
    return {"score": score, "level": level, "events_examined": len(rows), "severity_counts": counts,
        "method": "weighted_sum_of_recent_event_severity_v1", "window": "latest_500_events",
        "limitations": ["Score indicatif, non prédictif", "Ne remplace pas une analyse de risque complète", "Dépend de la qualité des événements ingérés"]}

@app.get("/ai/status")
def ai_status():
    configured = bool(os.getenv("SKYNET_AI_BASE_URL") and os.getenv("SKYNET_AI_API_KEY"))
    return {"configured": configured, "mode": "external_provider_not_connected" if not configured else "credentials_present",
            "autonomous_actions": False, "human_approval_required": True,
            "note": "La présence de paramètres ne prouve pas la disponibilité ni la sécurité du fournisseur."}

@app.get("/integrations/status")
def integration_status():
    names = ["STIX/TAXII", "SIEM", "EDR", "ticketing"]
    return {"integrations": [{"name": n, "configured": False, "status": "not_connected"} for n in names],
            "note": "Aucun flux externe n'est interrogé dans cette version."}

@app.get("/health")
def health():
    return {"status": "ok", "service": "skynet-v2-api", "mode": "starter", "time": datetime.now(timezone.utc).isoformat()}

@app.post("/setup/first-admin")
def first_admin(data: BootstrapIn, db: Session = Depends(get_db)):
    expected = os.getenv("SKYNET_SETUP_KEY", "")
    if not expected or not hmac.compare_digest(data.setup_key, expected):
        raise HTTPException(403, "Clé initiale incorrecte")
    if db.scalar(select(User.id).limit(1)):
        raise HTTPException(409, "Initialisation déjà effectuée")
    org_id, user_id = str(uuid.uuid4()), str(uuid.uuid4())
    org = Organization(id=org_id, name=data.organization_name)
    user = User(id=user_id, organization_id=org_id, email=data.admin_email.lower(), password_hash=hash_password(data.admin_password), role="admin")
    db.add_all([org, user]); db.commit()
    return {"created": True, "organization_id": org_id, "admin_email": user.email, "message": "Conservez les identifiants en lieu sûr."}

@app.post("/auth/token")
def token(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username.lower()))
    if not user or not user.active or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Identifiants incorrects")
    return {"access_token": create_token(user), "token_type": "bearer", "expires_in": int(os.getenv("TOKEN_MINUTES", "30"))*60}

@app.post("/auth/logout")
def logout(user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.token_version = int(user.token_version) + 1
    db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id,
        action="auth.sessions_revoked", object_type="user", object_id=user.id,
        details={"token_version": user.token_version}))
    db.commit()
    return {"revoked": True, "message": "Tous les jetons de cet utilisateur sont désormais invalidés."}

@app.post("/events")
def create_event(data: EventIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    evidence_hash = hashlib.sha256(data.evidence_text.encode("utf-8")).hexdigest() if data.evidence_text else None
    item = SecurityEvent(id=str(uuid.uuid4()), organization_id=user.organization_id, source=data.source, event_type=data.event_type, severity=data.severity, asset=data.asset, summary=data.summary, evidence_sha256=evidence_hash)
    db.add(item)
    db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id, action="event.created", object_type="security_event", object_id=item.id, details={"severity": data.severity, "source": data.source}))
    db.commit()
    return {"id": item.id, "evidence_sha256": evidence_hash, "status": "stored"}

@app.get("/events")
def list_events(limit: int = 100, user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = max(1, min(limit, 500))
    rows = db.scalars(select(SecurityEvent).where(SecurityEvent.organization_id == user.organization_id).order_by(desc(SecurityEvent.created_at)).limit(limit)).all()
    return [{"id": x.id, "source": x.source, "event_type": x.event_type, "severity": x.severity, "asset": x.asset, "summary": x.summary, "evidence_sha256": x.evidence_sha256, "created_at": x.created_at.isoformat()} for x in rows]

@app.post("/approvals")
def request_approval(data: ApprovalIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    item = Approval(id=str(uuid.uuid4()), organization_id=user.organization_id, requested_by=user.id, action_type=data.action_type, target=data.target, justification=data.justification)
    db.add(item); db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id, action="approval.requested", object_type="approval", object_id=item.id, details={"action_type": data.action_type}))
    db.commit()
    return {"id": item.id, "status": item.status, "message": "Aucune action technique n'est exécutée par cette demande."}

@app.get("/approvals")
def list_approvals(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Approval).where(Approval.organization_id == user.organization_id).order_by(desc(Approval.created_at)).limit(200)).all()
    return [{"id": x.id, "action_type": x.action_type, "target": x.target, "justification": x.justification, "status": x.status, "created_at": x.created_at.isoformat()} for x in rows]

@app.post("/approvals/{approval_id}/review")
def review_approval(approval_id: str, data: ReviewIn, user: User = Depends(require_roles("admin", "security_manager")), db: Session = Depends(get_db)):
    item = db.scalar(select(Approval).where(Approval.id == approval_id, Approval.organization_id == user.organization_id))
    if not item: raise HTTPException(404, "Demande introuvable")
    if item.status != "pending": raise HTTPException(409, "Demande déjà traitée")
    item.status, item.reviewed_by, item.review_note, item.reviewed_at = data.decision, user.id, data.note, datetime.now(timezone.utc)
    db.add(AuditEntry(id=str(uuid.uuid4()), organization_id=user.organization_id, actor_user_id=user.id, action="approval.reviewed", object_type="approval", object_id=item.id, details={"decision": data.decision}))
    db.commit()
    return {"id": item.id, "status": item.status, "note": "L'approbation enregistre une décision ; elle n'exécute aucune action distante."}

@app.get("/audit")
def audit(limit: int = 100, user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = max(1, min(limit, 500))
    rows = db.scalars(select(AuditEntry).where(AuditEntry.organization_id == user.organization_id).order_by(desc(AuditEntry.created_at)).limit(limit)).all()
    return [{"id": x.id, "actor_user_id": x.actor_user_id, "action": x.action, "object_type": x.object_type, "object_id": x.object_id, "details": x.details, "created_at": x.created_at.isoformat()} for x in rows]
