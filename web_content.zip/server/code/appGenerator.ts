/**
 * JARVIS App Generator & Scaffolding Engine
 * Generates modular application architectures:
 * - Vite + Express Full-Stack TypeScript
 * - React Client-Side SPA
 * - Android Companion Kotlin / Jetpack Compose
 * - Node.js REST API Microservice
 */

export interface AppScaffoldRequest {
  appName: string;
  architecture: 'fullstack_express_vite' | 'react_spa' | 'android_compose' | 'node_api';
  description: string;
}

export interface AppScaffoldFile {
  path: string;
  content: string;
  description: string;
}

export interface AppScaffoldResult {
  id: string;
  appName: string;
  architecture: string;
  fileCount: number;
  files: AppScaffoldFile[];
  setupInstructions: string[];
  generatedAt: string;
}

export class AppGenerator {
  public scaffoldApp(req: AppScaffoldRequest): AppScaffoldResult {
    const id = `app_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const name = req.appName.toLowerCase().replace(/[^a-z0-9_-]/g, '-');
    const arch = req.architecture || 'fullstack_express_vite';
    const files: AppScaffoldFile[] = [];

    if (arch === 'fullstack_express_vite') {
      files.push({
        path: 'package.json',
        description: 'Node.js dependencies and build scripts',
        content: JSON.stringify(
          {
            name,
            version: '1.0.0',
            type: 'module',
            scripts: {
              dev: 'tsx server.ts',
              build: 'vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --outfile=dist/server.cjs',
              start: 'node dist/server.cjs',
            },
            dependencies: {
              express: '^4.21.0',
              react: '^18.3.1',
              'react-dom': '^18.3.1',
              'lucide-react': '^0.468.0',
            },
            devDependencies: {
              '@types/express': '^4.17.21',
              '@types/react': '^18.3.12',
              '@types/react-dom': '^18.3.1',
              typescript: '^5.6.3',
              vite: '^5.4.10',
              esbuild: '^0.24.0',
              tsx: '^4.19.2',
            },
          },
          null,
          2
        ),
      });

      files.push({
        path: 'server.ts',
        description: 'Express server with Vite middleware integration',
        content: `import express from 'express';\nimport path from 'path';\nimport { createServer as createViteServer } from 'vite';\n\nconst app = express();\nconst PORT = 3000;\n\napp.use(express.json());\n\n// REST API endpoints\napp.get('/api/health', (req, res) => {\n  res.json({ status: 'ok', app: '${name}', timestamp: new Date().toISOString() });\n});\n\nasync function bootstrap() {\n  if (process.env.NODE_ENV !== 'production') {\n    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });\n    app.use(vite.middlewares);\n  } else {\n    app.use(express.static('dist'));\n    app.get('*', (req, res) => res.sendFile(path.resolve('dist/index.html')));\n  }\n  app.listen(PORT, '0.0.0.0', () => console.log('Server running on port ' + PORT));\n}\n\nbootstrap();`,
      });

      files.push({
        path: 'src/App.tsx',
        description: 'Main React application component',
        content: `import React, { useState, useEffect } from 'react';\n\nexport default function App() {\n  const [health, setHealth] = useState<string>('Checking...');\n  useEffect(() => {\n    fetch('/api/health').then(r => r.json()).then(d => setHealth(d.status)).catch(() => setHealth('Error'));\n  }, []);\n  return (\n    <main className="min-h-screen bg-slate-50 text-slate-900 p-8">\n      <h1 className="text-3xl font-bold mb-4">${req.appName}</h1>\n      <p className="text-slate-600 mb-4">${req.description}</p>\n      <div className="p-4 bg-white rounded-lg border border-slate-200">\n        Backend Health: <span className="font-bold text-emerald-600">{health}</span>\n      </div>\n    </main>\n  );\n}`,
      });
    } else if (arch === 'android_compose') {
      files.push({
        path: 'app/build.gradle.kts',
        description: 'Android application Gradle configuration',
        content: `plugins {\n    alias(libs.plugins.android.application)\n    alias(libs.plugins.kotlin.android)\n    alias(libs.plugins.kotlin.compose)\n}\n\nandroid {\n    namespace = "com.jarvis.${name.replace(/-/g, '')}"\n    compileSdk = 35\n    defaultConfig {\n        applicationId = "com.jarvis.${name.replace(/-/g, '')}"\n        minSdk = 26\n        targetSdk = 35\n        versionCode = 1\n        versionName = "1.0.0"\n    }\n}`,
      });

      files.push({
        path: 'app/src/main/AndroidManifest.xml',
        description: 'Android Manifest with Foreground & Assist Services',
        content: `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n    <application\n        android:allowBackup="true"\n        android:icon="@mipmap/ic_launcher"\n        android:label="${req.appName}"\n        android:theme="@style/Theme.Material3.DayNight">\n        <activity android:name=".MainActivity" android:exported="true">\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>\n        </activity>\n    </application>\n</manifest>`,
      });

      files.push({
        path: 'app/src/main/java/MainActivity.kt',
        description: 'Kotlin Jetpack Compose Main Activity',
        content: `package com.jarvis.${name.replace(/-/g, '')}\n\nimport android.os.Bundle\nimport androidx.activity.ComponentActivity\nimport androidx.activity.compose.setContent\nimport androidx.compose.material3.Text\nimport androidx.compose.material3.Surface\n\nclass MainActivity : ComponentActivity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContent {\n            Surface {\n                Text("${req.appName} — Sovereign Android Experience")\n            }\n        }\n    }\n}`,
      });
    } else {
      // node_api or react_spa default
      files.push({
        path: 'package.json',
        description: 'Package manifest',
        content: JSON.stringify({ name, version: '1.0.0', type: 'module' }, null, 2),
      });
      files.push({
        path: 'index.js',
        description: 'API entry point',
        content: `// Sovereign API for ${req.appName}\nconsole.log('App running.');`,
      });
    }

    files.push({
      path: 'README.md',
      description: 'Setup and execution guide',
      content: `# ${req.appName}\n\n${req.description}\n\n## Architecture\n${arch}\n\n## Instructions\n1. Run \`npm install\`\n2. Run \`npm run dev\`\n3. Open in browser on port 3000\n`,
    });

    return {
      id,
      appName: req.appName,
      architecture: arch,
      fileCount: files.length,
      files,
      setupInstructions: [
        'Run npm install in root folder',
        'Configure .env with your environment variables',
        'Run npm run dev to launch the development environment',
      ],
      generatedAt: new Date().toISOString(),
    };
  }
}

export const appGenerator = new AppGenerator();
