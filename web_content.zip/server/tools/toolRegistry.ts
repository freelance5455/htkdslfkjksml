import type { Permission, Status } from "../../shared/types.js";

export interface ToolDefinition {
  name: string;
  permission: Permission;
  status: Status;
}

export const tools: ToolDefinition[] = [
  { name: "web_search", permission: "READ", status: "CONFIG_REQUIRED" },
  { name: "file_read", permission: "READ", status: "AVAILABLE" },
  { name: "file_write", permission: "SAFE_WRITE", status: "AVAILABLE" },
  { name: "pdf_generator", permission: "SAFE_WRITE", status: "CONFIG_REQUIRED" },
  { name: "image_generator", permission: "SAFE_WRITE", status: "CONFIG_REQUIRED" },
  { name: "video_generator", permission: "SAFE_WRITE", status: "CONFIG_REQUIRED" },
  { name: "code_sandbox", permission: "SAFE_WRITE", status: "CONFIG_REQUIRED" },
  { name: "website_builder", permission: "SAFE_WRITE", status: "CONFIG_REQUIRED" },
  { name: "app_builder", permission: "SAFE_WRITE", status: "CONFIG_REQUIRED" },
  { name: "deployment", permission: "EXTERNAL_ACTION", status: "CONFIG_REQUIRED" },
  { name: "device_control", permission: "EXTERNAL_ACTION", status: "UNAVAILABLE" },
  { name: "social_publish", permission: "EXTERNAL_ACTION", status: "CONFIG_REQUIRED" }
];
