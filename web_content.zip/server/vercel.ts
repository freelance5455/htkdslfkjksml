/**
 * Vercel entry point.
 *
 * Serves the same Hono API as the Cloudflare Worker build. If TURSO_DATABASE_URL
 * is provided, it connects to remote Turso libSQL. Otherwise, it defaults to a
 * local SQLite database in /tmp/edumentor.db so the app functions out of the box.
 *
 * Optional environment variables:
 *   TURSO_DATABASE_URL, TURSO_AUTH_TOKEN
 *   OPENAI_API_KEY, OPENAI_BASE_URL, AI_MODEL
 */
import app from '../worker/index';
import { d1FromClient } from '../worker/db-libsql';
import { createFileBucket } from './files';
import type { Env } from '../worker/lib';

/** Trims accidental whitespace, newlines and wrapping quotes from pasted values. */
function envValue(name: string): string {
  const raw = process.env[name];
  if (!raw) return '';
  return raw.trim().replace(/^["']|["']$/g, '').trim();
}

const configuredUrl = envValue('TURSO_DATABASE_URL') || envValue('LIBSQL_URL');
const authToken = envValue('TURSO_AUTH_TOKEN');

async function createEnv(): Promise<Env> {
  let client;

  if (configuredUrl) {
    if (!/^(libsql|https?|file):/.test(configuredUrl)) {
      throw new Error(`TURSO_DATABASE_URL must start with libsql://, https://, or file: (got "${configuredUrl.slice(0, 12)}…").`);
    }
    client = configuredUrl.startsWith('file:')
      ? await import('@libsql/client').then(({ createClient }) => createClient({ url: configuredUrl }))
      : await import('@libsql/client/web').then(({ createClient }) =>
          createClient({ url: configuredUrl, authToken: authToken || undefined }),
        );
  } else {
    // Default fallback to local SQLite in /tmp so app works out of the box without Turso setup
    client = await import('@libsql/client').then(({ createClient }) =>
      createClient({ url: 'file:/tmp/edumentor.db' }),
    );
  }

  const db = d1FromClient(client as never);

  return {
    DB: db,
    FILES: createFileBucket(db as never) as never,
    ASSETS: { fetch: async () => new Response('Not found', { status: 404 }) } as never,
    OPENAI_API_KEY: envValue('OPENAI_API_KEY') || undefined,
    OPENAI_BASE_URL: envValue('OPENAI_BASE_URL') || undefined,
    AI_MODEL: envValue('AI_MODEL') || undefined,
    APP_ENV: process.env.APP_ENV || 'vercel',
  };
}

let cachedEnv: Env | null = null;
let envInitError: string | null = null;

async function getOrInitEnv(): Promise<Env> {
  if (cachedEnv) return cachedEnv;
  if (envInitError) throw new Error(envInitError);
  try {
    cachedEnv = await createEnv();
    return cachedEnv;
  } catch (err: unknown) {
    envInitError = err instanceof Error ? err.message : String(err);
    throw err;
  }
}

export default async function handler(req: any, res: any) {
  // If invoked with a standard Web Request (Edge runtime / fetch handler)
  if (typeof req?.headers?.get === 'function' && typeof req?.url === 'string' && !res) {
    try {
      const env = await getOrInitEnv();
      return await app.fetch(req, env);
    } catch (err: any) {
      return new Response(JSON.stringify({ error: `Database initialization error: ${err?.message || err}` }), {
        status: 500,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      });
    }
  }

  // Node.js Serverless runtime (req: IncomingMessage, res: ServerResponse)
  try {
    const rawPath =
      req.headers?.['x-matched-path'] ||
      req.headers?.['x-forwarded-uri'] ||
      req.url ||
      '/';

    const url = new URL(rawPath, `https://${req.headers?.host || 'localhost'}`);

    if (url.searchParams.has('__path')) {
      url.pathname = url.searchParams.get('__path')!;
      url.searchParams.delete('__path');
    }

    const { pathname } = url;
    if (!pathname.startsWith('/api/') && pathname !== '/api') {
      res.statusCode = 404;
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ error: 'Endpoint not found.', code: 'not_found' }));
      return;
    }

    let env: Env;
    try {
      env = await getOrInitEnv();
    } catch (dbErr: any) {
      res.statusCode = 503;
      res.setHeader('content-type', 'application/json');
      res.end(
        JSON.stringify({
          error: `Database initialization error: ${dbErr?.message || dbErr}`,
          code: 'database_error',
          hint: 'If you configured TURSO_DATABASE_URL, check the URL and token in Vercel Settings → Environment Variables.',
        }),
      );
      return;
    }

    // Build the request body safely, handling Vercel pre-parsed bodies
    let body: any = null;
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      if (req.body !== undefined && req.body !== null) {
        body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
      } else {
        const chunks: Buffer[] = [];
        for await (const chunk of req) {
          chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
        }
        if (chunks.length > 0) {
          body = Buffer.concat(chunks);
        }
      }
    }

    const headers = new Headers();
    if (req.headers) {
      for (const [key, val] of Object.entries(req.headers)) {
        if (val !== undefined) {
          if (Array.isArray(val)) val.forEach((v) => headers.append(key, v));
          else headers.set(key, String(val));
        }
      }
    }

    const webReq = new Request(url.toString(), {
      method: req.method || 'GET',
      headers,
      body,
    });

    const webRes = await app.fetch(webReq, env);

    res.statusCode = webRes.status;
    webRes.headers.forEach((val, key) => {
      if (key.toLowerCase() === 'set-cookie') {
        const cookies = (webRes.headers as any).getSetCookie?.() || val;
        res.setHeader('set-cookie', cookies);
      } else {
        res.setHeader(key, val);
      }
    });

    const resBuffer = await webRes.arrayBuffer();
    res.end(Buffer.from(resBuffer));
  } catch (err: any) {
    console.error('[vercel server error]', err);
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader('content-type', 'application/json');
    }
    res.end(JSON.stringify({ error: `Server error: ${err?.message || err}`, code: 'server_error' }));
  }
}
