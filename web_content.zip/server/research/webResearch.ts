export interface ResearchResult {
  query: string;
  status: "VERIFIED" | "UNVERIFIED";
  sources: string[];
  summary: string;
}

export async function research(query: string): Promise<ResearchResult> {
  return {
    query,
    status: "UNVERIFIED",
    sources: [],
    summary: "Configure a legitimate live search provider before claiming current web results."
  };
}
