'use strict';
/**
 * موتور تحلیل تکنیکال سمت سرور (برای ربات ۲۴ساعته)
 * ورودی: کندل‌ها [ts,o,h,l,c,v] صعودی  →  خروجی: سیگنال + پلن (ورود / حد ضرر / حد سود)
 * ترکیب: روند EMA، مومنتوم MACD، RSI، قدرت روند ADX، شکست قیمتی، حجم و تأیید تایم‌فریم بالاتر.
 */

const last = (a) => a[a.length - 1];

function ema(arr, p) {
  const k = 2 / (p + 1);
  const out = new Array(arr.length);
  let e = arr[0];
  for (let i = 0; i < arr.length; i++) { e = i === 0 ? arr[0] : arr[i] * k + e * (1 - k); out[i] = e; }
  return out;
}

function rsi(c, p = 14) {
  const out = new Array(c.length).fill(50);
  if (c.length <= p) return out;
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = c[i] - c[i - 1]; if (d >= 0) g += d; else l -= d; }
  g /= p; l /= p;
  out[p] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  for (let i = p + 1; i < c.length; i++) {
    const d = c[i] - c[i - 1];
    g = (g * (p - 1) + (d > 0 ? d : 0)) / p;
    l = (l * (p - 1) + (d < 0 ? -d : 0)) / p;
    out[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  }
  return out;
}

function trueRange(h, l, c) {
  return h.map((x, i) => (i === 0 ? x - l[i] : Math.max(x - l[i], Math.abs(x - c[i - 1]), Math.abs(l[i] - c[i - 1]))));
}

function atr(h, l, c, p = 14) {
  const tr = trueRange(h, l, c);
  const out = new Array(c.length).fill(0);
  if (tr.length < p) return out;
  let a = 0;
  for (let i = 0; i < p; i++) a += tr[i];
  a /= p; out[p - 1] = a;
  for (let i = p; i < tr.length; i++) { a = (a * (p - 1) + tr[i]) / p; out[i] = a; }
  return out;
}

function adx(h, l, c, p = 14) {
  const n = c.length;
  if (n < p * 2 + 2) return { adx: 0, pdi: 0, mdi: 0 };
  const tr = trueRange(h, l, c);
  const pdm = [0], mdm = [0];
  for (let i = 1; i < n; i++) {
    const up = h[i] - h[i - 1], dn = l[i - 1] - l[i];
    pdm.push(up > dn && up > 0 ? up : 0);
    mdm.push(dn > up && dn > 0 ? dn : 0);
  }
  let sTR = 0, sP = 0, sM = 0;
  for (let i = 1; i <= p; i++) { sTR += tr[i]; sP += pdm[i]; sM += mdm[i]; }
  const dx = [];
  let pdi = 0, mdi = 0;
  for (let i = p; i < n; i++) {
    if (i > p) { sTR = sTR - sTR / p + tr[i]; sP = sP - sP / p + pdm[i]; sM = sM - sM / p + mdm[i]; }
    pdi = sTR ? (100 * sP) / sTR : 0; mdi = sTR ? (100 * sM) / sTR : 0;
    dx.push(pdi + mdi ? (100 * Math.abs(pdi - mdi)) / (pdi + mdi) : 0);
  }
  if (dx.length < p) return { adx: 0, pdi, mdi };
  let a = dx.slice(0, p).reduce((x, y) => x + y, 0) / p;
  for (let i = p; i < dx.length; i++) a = (a * (p - 1) + dx[i]) / p;
  return { adx: a, pdi, mdi };
}

function macdHist(c) {
  const e12 = ema(c, 12), e26 = ema(c, 26);
  const line = e12.map((x, i) => x - e26[i]);
  const sig = ema(line, 9);
  return line.map((x, i) => x - sig[i]);
}

/** روند ساده برای تایم‌فریم بالاتر: 1 صعودی، -1 نزولی، 0 خنثی */
function trendOf(klines) {
  if (!klines || klines.length < 55) return 0;
  const c = klines.map((k) => k[4]);
  const e20 = ema(c, 20), e50 = ema(c, 50);
  const a = last(e20), b = last(e50), px = last(c);
  if (px > a && a > b) return 1;
  if (px < a && a < b) return -1;
  return 0;
}

function analyze(klines, opts = {}) {
  if (!Array.isArray(klines) || klines.length < 60) return null;
  const o = klines.map((k) => +k[1]), h = klines.map((k) => +k[2]), l = klines.map((k) => +k[3]), c = klines.map((k) => +k[4]), v = klines.map((k) => +k[5]);
  const n = c.length, px = c[n - 1];
  if (!(px > 0) || c.some((x) => !(x > 0))) return null;

  const e20 = ema(c, 20), e50 = ema(c, 50), e200 = ema(c, Math.min(200, n - 1));
  const R = rsi(c), A = atr(h, l, c), D = adx(h, l, c), M = macdHist(c);
  const atrV = A[n - 1];
  if (!(atrV > 0) || atrV / px < 0.001 || atrV / px > 0.2) return null; // کاملاً بی‌حرکت یا بی‌ثبات

  let s = 50;
  const why = [];
  const bull = px > e20[n - 1] && e20[n - 1] > e50[n - 1];
  const bear = px < e20[n - 1] && e20[n - 1] < e50[n - 1];
  if (bull) { s += 14; why.push('روند صعودی: قیمت بالای EMA20 و EMA50'); }
  else if (bear) { s -= 14; why.push('روند نزولی: قیمت پایین EMA20 و EMA50'); }
  if (e50[n - 1] > e200[n - 1] && px > e200[n - 1]) { s += 8; why.push('بالای EMA بلندمدت'); }
  else if (e50[n - 1] < e200[n - 1] && px < e200[n - 1]) { s -= 8; why.push('پایین EMA بلندمدت'); }

  const m1 = M[n - 1], m2 = M[n - 2];
  if (m1 > 0 && m1 > m2) { s += 10; why.push('مومنتوم MACD مثبت و رو به رشد'); }
  else if (m1 < 0 && m1 < m2) { s -= 10; why.push('مومنتوم MACD منفی و رو به افت'); }

  const r = R[n - 1];
  if (r >= 52 && r <= 68) { s += 7; why.push('RSI در محدودهٔ قدرت (' + r.toFixed(0) + ')'); }
  else if (r > 78) { s -= 9; why.push('RSI اشباع خرید (' + r.toFixed(0) + ')'); }
  else if (r <= 48 && r >= 32) { s -= 7; why.push('RSI ضعیف (' + r.toFixed(0) + ')'); }
  else if (r < 22) { s += 5; why.push('RSI اشباع فروش (' + r.toFixed(0) + ')'); }

  if (D.adx >= 22) {
    if (D.pdi > D.mdi) { s += 9; why.push('ADX قوی با غلبهٔ خریداران (' + D.adx.toFixed(0) + ')'); }
    else { s -= 9; why.push('ADX قوی با غلبهٔ فروشندگان (' + D.adx.toFixed(0) + ')'); }
  }

  const hh = Math.max(...h.slice(n - 21, n - 1)), ll = Math.min(...l.slice(n - 21, n - 1));
  if (px > hh) { s += 9; why.push('شکست سقف ۲۰ کندل'); }
  else if (px < ll) { s -= 9; why.push('شکست کف ۲۰ کندل'); }

  const vAvg = v.slice(n - 21, n - 1).reduce((x, y) => x + y, 0) / 20;
  if (vAvg > 0 && v[n - 1] > vAvg * 1.6) {
    if (c[n - 1] > o[n - 1]) { s += 6; why.push('حجم بالا همراه کندل صعودی'); }
    else { s -= 6; why.push('حجم بالا همراه کندل نزولی'); }
  }

  if (opts.htf !== undefined) {
    const t = typeof opts.htf === 'number' ? opts.htf : trendOf(opts.htf);
    if (t === 1) { s += 6; why.push('تأیید تایم‌فریم بالاتر (صعودی)'); }
    else if (t === -1) { s -= 6; why.push('تأیید تایم‌فریم بالاتر (نزولی)'); }
  }

  s = Math.max(0, Math.min(100, Math.round(s)));
  const dir = s >= 62 ? 'buy' : s <= 38 ? 'sell' : 'neutral';
  const strength = dir === 'buy' ? s : dir === 'sell' ? 100 - s : 0;

  // پلن: حد ضرر بر پایهٔ ATR و سوینگ اخیر
  const swingLow = Math.min(...l.slice(n - 11)), swingHigh = Math.max(...h.slice(n - 11));
  let sl, tp1, tp2;
  if (dir === 'sell') {
    sl = Math.max(px + 1.4 * atrV, Math.min(swingHigh + 0.2 * atrV, px + 3.5 * atrV));
    const d = sl - px; tp1 = px - 1.8 * d; tp2 = px - 3 * d;
  } else {
    sl = Math.min(px - 1.4 * atrV, Math.max(swingLow - 0.2 * atrV, px - 3.5 * atrV));
    const d = px - sl; tp1 = px + 1.8 * d; tp2 = px + 3 * d;
  }
  const dist = Math.abs(px - sl);
  const rr1 = dist > 0 ? Math.abs(tp1 - px) / dist : 0;
  return { dir, score: s, strength, entry: px, sl, tp1, tp2: tp2 > 0 ? tp2 : tp1, rr1, atr: atrV, rsi: r, adx: D.adx, reasons: why.slice(0, 6) };
}

module.exports = { analyze, ema, rsi, atr, adx, macdHist, trendOf };
