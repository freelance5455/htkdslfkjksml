import { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { db } from "./db";

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    role: "OWNER" | "ADMIN" | "EDITOR" | "VIEWER";
  };
  sessionToken?: string;
}

// Timing-safe password verification
export function verifyPassword(providedPassword: string, storedHash: string, salt: string): boolean {
  try {
    const computedHash = crypto.scryptSync(providedPassword, salt, 64).toString("hex");
    const bufA = Buffer.from(computedHash, "hex");
    const bufB = Buffer.from(storedHash, "hex");
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch (error) {
    console.error("[Auth] Error verifying password:", error);
    return false;
  }
}

// Authentication middleware for Express
export async function requireAuthMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization || (req.headers["x-session-token"] as string);
    let token = "";

    if (authHeader && typeof authHeader === "string") {
      if (authHeader.startsWith("Bearer ")) {
        token = authHeader.substring(7).trim();
      } else {
        token = authHeader.trim();
      }
    }

    if (!token) {
      return res.status(401).json({
        error: "Unauthorized",
        message: "Token de sessão não fornecido. Acesso protegido para o proprietário Sadraque Ngola.",
      });
    }

    const sessionData = await db.getSession(token);
    if (!sessionData) {
      return res.status(401).json({
        error: "Unauthorized",
        message: "Sessão expirada ou inválida. Faça login novamente.",
      });
    }

    req.user = {
      id: sessionData.user.id,
      email: sessionData.user.email,
      name: sessionData.user.name,
      role: sessionData.user.role,
    };
    req.sessionToken = token;

    next();
  } catch (error: unknown) {
    console.error("[Auth] Middleware error:", error);
    return res.status(500).json({ error: "Internal Auth Error" });
  }
}

// Optional auth middleware (attaches user if session present, but doesn't block)
export async function optionalAuthMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization || (req.headers["x-session-token"] as string);
    let token = "";

    if (authHeader && typeof authHeader === "string") {
      if (authHeader.startsWith("Bearer ")) {
        token = authHeader.substring(7).trim();
      } else {
        token = authHeader.trim();
      }
    }

    if (token) {
      const sessionData = await db.getSession(token);
      if (sessionData) {
        req.user = {
          id: sessionData.user.id,
          email: sessionData.user.email,
          name: sessionData.user.name,
          role: sessionData.user.role,
        };
        req.sessionToken = token;
      }
    }
  } catch (err) {
    // Ignore and proceed
  }
  next();
}
