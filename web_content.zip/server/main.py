from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime, timedelta, timezone
import sqlite3

app=FastAPI(title="Mikan VPN API")
DB="mikan.db"
def conn():
 c=sqlite3.connect(DB)
 c.execute("""CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY, login TEXT UNIQUE, password TEXT,
 created TEXT, days INTEGER, traffic_gb INTEGER, subscription TEXT)""")
 c.commit(); return c

class User(BaseModel):
 login:str; password:str; days:int=30; traffic_gb:int=100

@app.get("/health")
def health(): return {"ok":True}

@app.post("/users")
def create(u:User):
 c=conn(); exp=datetime.now(timezone.utc)+timedelta(days=u.days)
 try:
  c.execute("INSERT INTO users(login,password,created,days,traffic_gb,subscription) VALUES(?,?,?,?,?,?)",
   (u.login,u.password,datetime.now(timezone.utc).isoformat(),u.days,u.traffic_gb,"PENDING_SERVER_SUBSCRIPTION"))
  c.commit()
 except sqlite3.IntegrityError: raise HTTPException(409,"login already exists")
 return {"login":u.login,"expires":exp.isoformat(),"traffic_gb":u.traffic_gb}

@app.post("/login")
def login(login:str,password:str):
 c=conn(); r=c.execute("SELECT login,created,days,traffic_gb,subscription FROM users WHERE login=? AND password=?",(login,password)).fetchone()
 if not r: raise HTTPException(401,"bad credentials")
 created=datetime.fromisoformat(r[1]); expires=created+timedelta(days=r[2])
 return {"login":r[0],"expires":expires.isoformat(),"traffic_gb":r[3],"subscription":r[4]}
