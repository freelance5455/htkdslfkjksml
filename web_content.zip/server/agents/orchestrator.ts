export interface AgentPlan {
  goal: string;
  stages: string[];
  status: "PLANNED" | "RUNNING" | "VERIFIED" | "FAILED";
}

export function planAgent(goal: string): AgentPlan {
  return {
    goal,
    stages: [
      "PERCEIVE","UNDERSTAND","REMEMBER","PLAN","MODEL_ROUTE",
      "TOOL_SKILL_ROUTE","EXECUTE","OBSERVE","VERIFY","REPLAN","DELIVER"
    ],
    status: "PLANNED"
  };
}
