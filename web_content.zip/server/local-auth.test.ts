import { describe, expect, it } from "vitest";
import { createLocalSession, hashPassword, localCookieOptions, readLocalSession, verifyPassword } from "./localAuth";

describe("local workspace authentication", () => {
  it("hashes and verifies passwords without storing plaintext", async () => {
    const password = "correct-horse-battery-staple";
    const encoded = await hashPassword(password);
    expect(encoded).not.toContain(password);
    expect(await verifyPassword(password, encoded)).toBe(true);
    expect(await verifyPassword("wrong-password", encoded)).toBe(false);
  });

  it("rejects tampered local sessions", () => {
    const token = createLocalSession(12);
    expect(readLocalSession(token)?.accountId).toBe(12);
    expect(readLocalSession(`${token}tampered`)).toBeNull();
  });

  it("only persists the cookie when remember me is enabled", () => {
    expect(localCookieOptions(false)).not.toHaveProperty("maxAge");
    expect(localCookieOptions(true).maxAge).toBeGreaterThan(0);
    expect(localCookieOptions(true, true)).toMatchObject({ secure: true, sameSite: "none" });
  });
});
