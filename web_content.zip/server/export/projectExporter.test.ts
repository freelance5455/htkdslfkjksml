import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import JSZip from 'jszip';
import {
  buildProjectSourceZipBuffer,
  collectProjectSourceFiles,
  shouldExcludeExportEntry,
} from './projectExporter';

test('shouldExcludeExportEntry excludes secrets, node_modules, and build artifacts while keeping source & .env.example', () => {
  assert.equal(shouldExcludeExportEntry('node_modules', true), true);
  assert.equal(shouldExcludeExportEntry('dist', true), true);
  assert.equal(shouldExcludeExportEntry('.data', true), true);
  assert.equal(shouldExcludeExportEntry('.env', false), true);
  assert.equal(shouldExcludeExportEntry('.env.local', false), true);
  assert.equal(shouldExcludeExportEntry('.env.example', false), false);
  assert.equal(shouldExcludeExportEntry('src/App.tsx', false), false);
  assert.equal(shouldExcludeExportEntry('server.ts', false), false);
});

test('buildProjectSourceZipBuffer generates a valid ZIP with frontend, backend, config, and assets', async () => {
  const rootDir = path.resolve(process.cwd());
  const listed = collectProjectSourceFiles(rootDir);
  assert.ok(listed.some((f) => f.relativePath === 'src/App.tsx'));
  assert.ok(listed.some((f) => f.relativePath === 'server.ts'));
  assert.ok(listed.some((f) => f.relativePath === 'package.json'));
  assert.ok(!listed.some((f) => f.relativePath === '.env'));
  assert.ok(!listed.some((f) => f.relativePath.startsWith('node_modules/')));

  const { buffer, fileCount, files } = await buildProjectSourceZipBuffer(rootDir);
  assert.ok(fileCount >= 20);
  assert.ok(buffer.length > 10_000);

  const loaded = await JSZip.loadAsync(buffer);
  const pkgJson = await loaded.file('package.json')?.async('string');
  assert.ok(pkgJson?.includes('"express"'));
  const serverTs = await loaded.file('server.ts')?.async('string');
  assert.ok(serverTs?.includes('/api/project/export'));
  assert.ok(files.includes('public/manifest.webmanifest'));
});
