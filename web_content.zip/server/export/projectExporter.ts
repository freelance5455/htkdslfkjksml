import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';

const EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.playwright-cli',
  '.aistudio',
  '.data',
  '.next',
  '.cache',
  'coverage',
  'build',
]);

const EXCLUDED_FILES = new Set([
  '.env',
  '.env.local',
  '.env.production.local',
  '.env.development.local',
  '.DS_Store',
  'Thumbs.db',
  'server.js',
]);

export function shouldExcludeExportEntry(relPosixPath: string, isDirectory: boolean): boolean {
  const baseName = path.posix.basename(relPosixPath);
  if (isDirectory) {
    return EXCLUDED_DIRS.has(baseName);
  }
  if (EXCLUDED_FILES.has(baseName)) return true;
  if (/^\.env\..+\.local$/i.test(baseName)) return true;
  if (baseName.endsWith('.log')) return true;
  return false;
}

export interface CollectedSourceFile {
  relativePath: string;
  sizeBytes: number;
}

export function collectProjectSourceFiles(rootDir: string): CollectedSourceFile[] {
  const results: CollectedSourceFile[] = [];

  const walk = (currentDir: string, relPrefix: string) => {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });
    entries.sort((a, b) => a.name.localeCompare(b.name));

    for (const entry of entries) {
      const relPosix = relPrefix ? `${relPrefix}/${entry.name}` : entry.name;
      const isDir = entry.isDirectory();
      if (shouldExcludeExportEntry(relPosix, isDir)) {
        continue;
      }
      const fullPath = path.join(currentDir, entry.name);
      if (isDir) {
        walk(fullPath, relPosix);
      } else if (entry.isFile()) {
        const stat = fs.statSync(fullPath);
        results.push({
          relativePath: relPosix,
          sizeBytes: stat.size,
        });
      }
    }
  };

  walk(rootDir, '');
  return results;
}

export async function buildProjectSourceZipBuffer(rootDir: string): Promise<{
  buffer: Buffer;
  fileCount: number;
  files: string[];
}> {
  const zip = new JSZip();
  const collected = collectProjectSourceFiles(rootDir);

  for (const item of collected) {
    const absPath = path.join(rootDir, ...item.relativePath.split('/'));
    const data = fs.readFileSync(absPath);
    zip.file(item.relativePath, data);
  }

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  return {
    buffer,
    fileCount: collected.length,
    files: collected.map((f) => f.relativePath),
  };
}
