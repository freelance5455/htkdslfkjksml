export function buildStandaloneStudioHtml(): string {
  return `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>HTML to APK Studio — Tam Tek Dosya Sürümü</title>
  <style>
    :root {
      --bg: #0B0D14;
      --sidebar: #0E111A;
      --surface: #121622;
      --surface-hover: #171C2B;
      --border: rgba(255, 255, 255, 0.08);
      --border-strong: rgba(255, 255, 255, 0.16);
      --primary: #7C6CF0;
      --primary-hover: #6D5CE6;
      --accent: #4F8BFF;
      --gold: #F5C451;
      --text: #EDF1F7;
      --muted: #94A3B8;
      --dim: #64748B;
      --ok: #34D399;
      --err: #F87171;
      --warn: #FBBF24;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Inter", sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      line-height: 1.5;
    }
    button, input, select, textarea { font: inherit; color: inherit; }
    button { cursor: pointer; }
    code, pre, .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }

    /* Topbar */
    .topbar {
      position: sticky;
      top: 0;
      z-index: 30;
      height: 56px;
      padding: 0 20px;
      background: rgba(11, 13, 20, 0.88);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 20px;
    }
    .topbar-left { display: flex; align-items: center; gap: 12px; }
    .menu-toggle {
      display: none;
      background: none;
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 6px 10px;
      font-size: 13px;
      color: var(--muted);
    }
    .brand { font-size: 16px; font-weight: 700; color: #fff; letter-spacing: -0.02em; white-space: nowrap; }
    .topnav { display: flex; align-items: center; gap: 20px; overflow-x: auto; }
    .topnav button {
      background: none;
      border: 0;
      border-bottom: 2px solid transparent;
      padding: 6px 2px;
      font-size: 12px;
      font-weight: 500;
      color: var(--muted);
      white-space: nowrap;
    }
    .topnav button.active, .topnav button:hover { color: #fff; }
    .topnav button.active { border-bottom-color: var(--primary); }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: var(--primary);
      color: #fff;
      border: 0;
      border-radius: 10px;
      padding: 9px 15px;
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
      transition: background 0.15s ease;
    }
    .btn:hover { background: var(--primary-hover); }
    .btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .btn-ghost {
      background: var(--surface);
      border: 1px solid var(--border-strong);
      color: #fff;
    }
    .btn-ghost:hover { background: var(--surface-hover); }
    .btn-gold { background: var(--gold); color: #0B0D14; }
    .btn-gold:hover { background: #E7B53E; }
    .btn-ok { background: #10B981; color: #0B0D14; }
    .btn-danger { background: rgba(248, 113, 113, 0.12); color: var(--err); border: 1px solid rgba(248, 113, 113, 0.3); }

    /* Shell */
    .shell { display: flex; flex: 1; min-height: 0; }
    .sidebar {
      width: 240px;
      flex-shrink: 0;
      background: var(--sidebar);
      border-right: 1px solid var(--border);
      padding: 16px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 16px;
    }
    .side-nav { display: flex; flex-direction: column; gap: 4px; }
    .side-nav button {
      width: 100%;
      text-align: left;
      background: none;
      border: 0;
      border-radius: 10px;
      padding: 10px 12px;
      font-size: 12px;
      font-weight: 500;
      color: var(--muted);
      transition: background 0.15s ease, color 0.15s ease;
    }
    .side-nav button:hover { background: rgba(255, 255, 255, 0.04); color: #fff; }
    .side-nav button.active { background: rgba(124, 108, 240, 0.16); color: #fff; }
    .side-nav button.prem { color: var(--gold); }
    .side-footer {
      border-top: 1px solid var(--border);
      padding-top: 12px;
      font-size: 11px;
      color: var(--muted);
    }

    .viewport {
      flex: 1;
      min-width: 0;
      padding: 24px 28px;
      max-width: 1360px;
      width: 100%;
      margin: 0 auto;
    }
    .section { display: none; flex-direction: column; gap: 22px; }
    .section.active { display: flex; }

    .page-head { display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 14px; }
    .page-head h1 { font-size: 24px; font-weight: 700; color: #fff; letter-spacing: -0.02em; }
    .page-head p { font-size: 13px; color: var(--muted); margin-top: 4px; }

    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 20px;
    }
    .card h2 { font-size: 14px; font-weight: 600; color: #fff; margin-bottom: 10px; }
    .muted { font-size: 12px; color: var(--muted); }

    .grid-4 { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
    .grid-3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
    .grid-2 { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
    .split-12 { display: grid; grid-template-columns: repeat(12, minmax(0, 1fr)); gap: 20px; align-items: start; }
    .col-4 { grid-column: span 4; }
    .col-5 { grid-column: span 5; }
    .col-7 { grid-column: span 7; }
    .col-8 { grid-column: span 8; }

    .stat-num { font-size: 26px; font-weight: 700; color: #fff; margin-top: 6px; font-variant-numeric: tabular-nums; }

    .upload-banner {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      padding: 22px;
      border-radius: 16px;
      background: linear-gradient(120deg, #171B2E, #141827, #121622);
      border: 1px solid rgba(124, 108, 240, 0.45);
      cursor: pointer;
    }
    .upload-banner:hover { border-color: var(--primary); }

    .action-card {
      text-align: left;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 18px;
      transition: background 0.15s ease, border-color 0.15s ease;
    }
    .action-card:hover { background: var(--surface-hover); border-color: var(--border-strong); }
    .action-card h3 { font-size: 14px; font-weight: 600; color: #fff; margin-bottom: 6px; }

    label.lbl { display: block; font-size: 11px; font-weight: 500; color: var(--muted); margin-bottom: 6px; }
    input[type="text"], input[type="number"], select, textarea {
      width: 100%;
      background: var(--bg);
      border: 1px solid var(--border-strong);
      border-radius: 10px;
      padding: 9px 12px;
      font-size: 13px;
      color: #fff;
      outline: none;
    }
    input:focus, select:focus, textarea:focus { border-color: var(--primary); }
    .check-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      border-radius: 10px;
      background: var(--bg);
      border: 1px solid var(--border);
      font-size: 12px;
      cursor: pointer;
    }
    .check-row input { width: 16px; height: 16px; accent-color: var(--primary); }

    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; text-align: left; font-size: 12px; }
    th { padding: 11px 14px; font-size: 11px; color: var(--dim); border-bottom: 1px solid var(--border); }
    td { padding: 12px 14px; border-bottom: 1px solid rgba(255,255,255,0.05); }

    /* Icons Gallery */
    .icon-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
    .icon-option {
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 8px;
      text-align: left;
    }
    .icon-option.active { border-color: var(--primary); background: rgba(124, 108, 240, 0.14); }
    .icon-option img { width: 100%; aspect-ratio: 1; object-fit: cover; border-radius: 8px; display: block; margin-bottom: 6px; }
    .icon-option span { display: block; font-size: 11px; font-weight: 500; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    /* Preview Frame */
    .preview-stage {
      background: #07090F;
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 20px;
      display: flex;
      justify-content: center;
      min-height: 540px;
    }
    .device-frame {
      background: #fff;
      border: 10px solid #1E2538;
      border-radius: 30px;
      width: 375px;
      height: 620px;
      max-width: 100%;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      transition: width 0.2s ease, height 0.2s ease;
    }
    .device-frame.tablet { width: 768px; height: 580px; border-radius: 20px; }
    .device-frame.desktop { width: 100%; height: 580px; border-radius: 12px; border-width: 2px; }
    .device-frame iframe { width: 100%; height: 100%; border: 0; flex: 1; background: #fff; }

    /* Launcher Preview */
    .launcher-preview {
      background: linear-gradient(180deg, #171D31, #0D101B);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 24px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
    }
    .launcher-preview img {
      width: 76px;
      height: 76px;
      border-radius: 20px;
      object-fit: cover;
      border: 1px solid rgba(255,255,255,0.16);
    }

    pre.codebox {
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 14px;
      font-size: 11px;
      color: #CBD5E1;
      overflow: auto;
      max-height: 440px;
      line-height: 1.55;
      white-space: pre;
    }

    /* Modal */
    .modal-backdrop {
      position: fixed;
      inset: 0;
      z-index: 60;
      background: rgba(0,0,0,0.76);
      backdrop-filter: blur(4px);
      display: none;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }
    .modal-backdrop.open { display: flex; }
    .modal-card {
      width: 100%;
      max-width: 880px;
      max-height: 90vh;
      background: var(--surface);
      border: 1px solid var(--border-strong);
      border-radius: 18px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .modal-head {
      padding: 16px 22px;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .modal-body { padding: 20px 22px; overflow-y: auto; display: flex; flex-direction: column; gap: 16px; }
    .modal-foot {
      padding: 14px 22px;
      border-top: 1px solid var(--border);
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }

    .toast {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 80;
      background: #171D2E;
      border: 1px solid var(--primary);
      color: #fff;
      padding: 11px 16px;
      border-radius: 12px;
      font-size: 12px;
      display: none;
    }
    .toast.show { display: block; }

    @media (max-width: 960px) {
      .sidebar { display: none; }
      .sidebar.mobile-open {
        display: flex;
        position: fixed;
        top: 56px;
        bottom: 0;
        left: 0;
        z-index: 45;
      }
      .menu-toggle { display: inline-flex; }
      .topnav { display: none; }
      .grid-4, .grid-3, .grid-2 { grid-template-columns: 1fr; }
      .split-12 { grid-template-columns: 1fr; }
      .col-4, .col-5, .col-7, .col-8 { grid-column: span 1; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="topbar-left">
      <button id="menuToggleBtn" class="menu-toggle" type="button">Menü</button>
      <div class="brand">HTML to APK Studio</div>
    </div>
    <nav class="topnav" id="topNav">
      <button class="active" data-nav="dashboard" type="button">Panel</button>
      <button data-nav="projects" type="button">Projeler</button>
      <button data-nav="preview" type="button">Önizleme</button>
      <button data-nav="settings" type="button">APK Ayarları</button>
      <button data-nav="build" type="button">Derleme & Kod</button>
      <button data-nav="premium" type="button">Premium</button>
    </nav>
    <button id="topBuildBtn" class="btn" type="button">APK Oluştur</button>
  </header>

  <div class="shell">
    <aside class="sidebar" id="sidebar">
      <div class="side-nav" id="sideNav">
        <button class="active" data-nav="dashboard" type="button">Ana Panel</button>
        <button data-nav="projects" type="button">Projelerim</button>
        <button data-nav="preview" type="button">Canlı Önizleme</button>
        <button data-nav="settings" type="button">APK & Logo Ayarları</button>
        <button data-nav="build" type="button">Derleme & Android Kodu</button>
        <button class="prem" data-nav="premium" type="button">Premium Üyelik</button>
      </div>
      <div class="side-footer">
        <div style="color:#fff;font-weight:600;">Çevrimdışı Studio Sürümü</div>
        <div style="margin-top:2px;">Tüm veriler tarayıcınızda saklanır</div>
      </div>
    </aside>

    <main class="viewport">
      <!-- 1. ANA PANEL -->
      <section id="sec-dashboard" class="section active">
        <div class="page-head">
          <div>
            <h1>Ana Panel</h1>
            <p>HTML projenizi yükleyin, logosunu seçin ve Android WebView projesini hazırlayın.</p>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button id="createNewProjBtn" class="btn btn-ghost" type="button">Yeni Proje Oluştur</button>
            <button id="exportCurrentHtmlBtn" class="btn" type="button">Aktif Projeyi .HTML İndir</button>
          </div>
        </div>

        <label class="upload-banner">
          <div>
            <h2 style="margin-bottom:4px;font-size:16px;">HTML Yükle, Logonu Seç ve Hazırla</h2>
            <p class="muted">Herhangi bir .html dosyası seçin; uygulama logosunu ve paket adını ayarlayıp Android projesini oluşturun.</p>
          </div>
          <span class="btn">HTML Dosyası Seç</span>
          <input id="quickHtmlUpload" type="file" accept=".html,.htm" hidden />
        </label>

        <div class="grid-4">
          <div class="card">
            <p class="muted">Toplam Proje</p>
            <div id="dashProjCount" class="stat-num">1</div>
          </div>
          <div class="card">
            <p class="muted">Üretilen Paket</p>
            <div id="dashBuildCount" class="stat-num">0</div>
          </div>
          <div class="card">
            <p class="muted">Aktif Proje</p>
            <div id="dashActiveName" class="stat-num" style="font-size:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">—</div>
          </div>
          <div class="card">
            <p class="muted">Hedef SDK</p>
            <div class="stat-num">API 34</div>
          </div>
        </div>

        <div>
          <h2 style="font-size:14px;margin-bottom:12px;">Hızlı İşlemler</h2>
          <div class="grid-3">
            <button class="action-card" data-nav="projects" type="button">
              <h3>Projelerim</h3>
              <p class="muted">HTML, CSS ve JS dosyalarını düzenleyin veya yeni proje ekleyin.</p>
            </button>
            <button class="action-card" data-nav="preview" type="button">
              <h3>Canlı Önizleme</h3>
              <p class="muted">Telefon, tablet ve masaüstü ekranlarında projenizi test edin.</p>
            </button>
            <button class="action-card" id="dashOpenPreBuildBtn" type="button">
              <h3>Logo Seç & APK Hazırla</h3>
              <p class="muted">Özel logo yükleyip AndroidManifest.xml ve Kotlin projesini üretin.</p>
            </button>
          </div>
        </div>

        <div class="card" style="padding:0;overflow:hidden;">
          <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
            <h2 style="margin:0;">Son Dönüştürmeler</h2>
            <button class="btn btn-ghost" data-nav="build" type="button">Derleme Hattı</button>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Uygulama</th>
                  <th>Paket Adı</th>
                  <th>Durum</th>
                  <th>Tarih</th>
                </tr>
              </thead>
              <tbody id="recentBuildsTbody"></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- 2. PROJELERIM -->
      <section id="sec-projects" class="section">
        <div class="page-head">
          <div>
            <h1>Projelerim</h1>
            <p>Kayıtlı HTML/CSS/JS projelerinizi düzenleyin ve giriş dosyasını yönetin.</p>
          </div>
          <button id="projAddBtn" class="btn" type="button">+ Yeni Proje</button>
        </div>

        <div class="split-12">
          <div class="col-4" id="projectsListCol" style="display:flex;flex-direction:column;gap:10px;"></div>
          <div class="col-8 card" style="padding:0;overflow:hidden;">
            <div style="padding:14px 18px;border-bottom:1px solid var(--border);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
              <div>
                <div id="editorProjTitle" style="font-size:14px;font-weight:600;color:#fff;">—</div>
                <div id="editorProjPkg" class="mono muted" style="font-size:11px;">—</div>
              </div>
              <div style="display:flex;gap:8px;">
                <button id="saveEditorFileBtn" class="btn btn-ghost" type="button">Dosyayı Kaydet</button>
                <button id="editorBuildBtn" class="btn" type="button">APK Oluştur</button>
              </div>
            </div>
            <div style="display:flex;gap:6px;padding:10px 14px;border-bottom:1px solid var(--border);background:#0E111A;">
              <button class="btn btn-ghost file-tab" data-file="html" type="button">index.html</button>
              <button class="btn btn-ghost file-tab" data-file="css" type="button">css/style.css</button>
              <button class="btn btn-ghost file-tab" data-file="js" type="button">js/app.js</button>
            </div>
            <div style="padding:14px;">
              <textarea id="codeEditorArea" rows="17" spellcheck="false"></textarea>
            </div>
          </div>
        </div>
      </section>

      <!-- 3. CANLI ONIZLEME -->
      <section id="sec-preview" class="section">
        <div class="page-head">
          <div>
            <h1>Canlı HTML Önizleme</h1>
            <p>Projenizin gerçek mobil WebView görünümünü ve çalışma zamanı hatalarını kontrol edin.</p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button class="btn btn-ghost device-switch" data-mode="mobile" type="button">Telefon</button>
            <button class="btn btn-ghost device-switch" data-mode="tablet" type="button">Tablet</button>
            <button class="btn btn-ghost device-switch" data-mode="desktop" type="button">Masaüstü</button>
            <button id="refreshPreviewBtn" class="btn" type="button">Yenile</button>
          </div>
        </div>

        <div class="preview-stage">
          <div id="deviceFrame" class="device-frame">
            <iframe id="livePreviewIframe" sandbox="allow-scripts allow-forms allow-modals"></iframe>
          </div>
        </div>

        <div class="card">
          <h2>Çalışma Zamanı Hata Monitörü</h2>
          <div id="previewErrorsBox" class="mono muted">Hata tespit edilmedi.</div>
        </div>
      </section>

      <!-- 4. APK & LOGO AYARLARI -->
      <section id="sec-settings" class="section">
        <div class="page-head">
          <div>
            <h1>APK & WebView Ayarları</h1>
            <p>Uygulama logosu, paket adı, Splash ekranı ve Android sistem çubuklarını yapılandırın.</p>
          </div>
          <button id="saveSettingsBtn" class="btn" type="button">Ayarları Kaydet</button>
        </div>

        <div class="split-12">
          <div class="col-7" style="display:flex;flex-direction:column;gap:16px;">
            <div class="card">
              <h2>Temel Uygulama Kimliği</h2>
              <div class="grid-2">
                <div>
                  <label class="lbl" for="setAppName">Uygulama Adı</label>
                  <input id="setAppName" type="text" />
                </div>
                <div>
                  <label class="lbl" for="setPkgName">Paket Adı (Application ID)</label>
                  <input id="setPkgName" type="text" class="mono" />
                  <div id="setPkgErr" style="font-size:11px;color:var(--err);margin-top:4px;display:none;">Geçersiz paket adı (ör. com.firma.uygulama)</div>
                </div>
                <div>
                  <label class="lbl" for="setVerName">Sürüm Adı</label>
                  <input id="setVerName" type="text" class="mono" />
                </div>
                <div>
                  <label class="lbl" for="setVerCode">Sürüm Kodu</label>
                  <input id="setVerCode" type="number" min="1" />
                </div>
              </div>
            </div>

            <div class="card">
              <h2>Ekran & WebView İzinleri</h2>
              <div class="grid-2" style="margin-bottom:12px;">
                <div>
                  <label class="lbl" for="setOrientation">Ekran Yönü</label>
                  <select id="setOrientation">
                    <option value="unspecified">Otomatik (Sensör)</option>
                    <option value="portrait">Dikey (Portrait)</option>
                    <option value="landscape">Yatay (Landscape)</option>
                  </select>
                </div>
                <div>
                  <label class="lbl" for="setLaunchAnim">Açılış Animasyonu</label>
                  <select id="setLaunchAnim">
                    <option value="fade">Yumuşak Geçiş (Fade)</option>
                    <option value="slide">Yatay Kayma (Slide)</option>
                    <option value="scale">Ölçekli Açılış (Scale)</option>
                    <option value="none">Yok</option>
                  </select>
                </div>
              </div>
              <div class="grid-2">
                <label class="check-row"><span>Tam Ekran Modu</span><input id="setFullscreen" type="checkbox" /></label>
                <label class="check-row"><span>İnternet Erişimi İzni</span><input id="setInternet" type="checkbox" /></label>
                <label class="check-row"><span>Splash Ekranı Aktif</span><input id="setSplashEnabled" type="checkbox" /></label>
                <div>
                  <label class="lbl" for="setSplashTitle">Splash Başlığı</label>
                  <input id="setSplashTitle" type="text" />
                </div>
              </div>
            </div>
          </div>

          <div class="col-5 card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
              <h2 style="margin:0;">Uygulama İkonu / Logosu</h2>
              <label class="btn btn-ghost" style="padding:6px 10px;font-size:11px;">
                Logo Yükle (PNG/SVG)
                <input id="settingsLogoUpload" type="file" accept=".png,.jpg,.jpeg,.webp,.svg" hidden />
              </label>
            </div>
            <div class="launcher-preview" style="margin-bottom:14px;">
              <img id="settingsLauncherImg" alt="Uygulama İkonu" />
              <div id="settingsLauncherLabel" style="font-size:12px;font-weight:600;color:#fff;"></div>
            </div>
            <div id="settingsIconGrid" class="icon-grid"></div>
          </div>
        </div>
      </section>

      <!-- 5. DERLEME & ANDROID KODLARI -->
      <section id="sec-build" class="section">
        <div class="page-head">
          <div>
            <h1>Android WebView Projesi & Kod Çıktısı</h1>
            <p>Projeniz için üretilen Kotlin, Gradle, Manifest ve Docker dosyalarını inceleyin veya kopyalayın.</p>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button id="buildDownloadSingleHtmlBtn" class="btn btn-ghost" type="button">Tek Dosya .HTML İndir</button>
            <button id="buildTriggerBtn" class="btn" type="button">Logo Seç ve Hazırla</button>
          </div>
        </div>

        <div class="card">
          <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
            <div style="display:flex;gap:8px;flex-wrap:wrap;" id="androidTabsBar">
              <button class="btn btn-ghost android-tab" data-tab="kotlin" type="button">MainActivity.kt</button>
              <button class="btn btn-ghost android-tab" data-tab="splash" type="button">SplashActivity.kt</button>
              <button class="btn btn-ghost android-tab" data-tab="manifest" type="button">AndroidManifest.xml</button>
              <button class="btn btn-ghost android-tab" data-tab="gradle" type="button">app/build.gradle.kts</button>
              <button class="btn btn-ghost android-tab" data-tab="docker" type="button">Dockerfile</button>
              <button class="btn btn-ghost android-tab" data-tab="script" type="button">build-apk.sh</button>
            </div>
            <div style="display:flex;gap:8px;">
              <button id="copyActiveAndroidBtn" class="btn btn-ghost" type="button">Kodu Kopyala</button>
              <button id="downloadActiveAndroidBtn" class="btn" type="button">Bu Dosyayı İndir</button>
            </div>
          </div>
          <pre id="androidCodePre" class="codebox"></pre>
        </div>
      </section>

      <!-- 6. PREMIUM PLANLAR -->
      <section id="sec-premium" class="section">
        <div class="page-head">
          <div>
            <h1>Premium Üyelik Paketleri</h1>
            <p>Sınırsız proje, öncelikli derleme ve tüm Premium ikon paketleri için sunucu sürümünde mevcut planlar.</p>
          </div>
        </div>
        <div class="grid-3">
          <div class="card">
            <h2>Aylık Premium</h2>
            <div class="stat-num" style="margin-bottom:8px;">150 TL <span class="muted">/ ay</span></div>
            <p class="muted">Aktif proje geliştiren geliştiriciler için aylık esnek erişim, öncelikli derleme ve Premium ikonlar.</p>
          </div>
          <div class="card" style="border-color:rgba(245,196,81,0.5);">
            <h2 style="color:var(--gold);">Yıllık Premium</h2>
            <div class="stat-num" style="margin-bottom:8px;">1.000 TL <span class="muted">/ yıl</span></div>
            <p class="muted">%44 daha avantajlı yıllık fiyat, geniş depolama alanı ve öncelikli destek.</p>
          </div>
          <div class="card">
            <h2>Kalıcı Premium</h2>
            <div class="stat-num" style="margin-bottom:8px;">2.000 TL <span class="muted">/ tek sefer</span></div>
            <p class="muted">Tek seferlik ödeme ile süresiz öncelikli APK derleme ve tüm gelecek ikon paketleri.</p>
          </div>
        </div>
      </section>
    </main>
  </div>

  <!-- APK ONCESI LOGO & KIMLIK MODALI -->
  <div id="preBuildModal" class="modal-backdrop">
    <div class="modal-card">
      <div class="modal-head">
        <div>
          <div style="font-size:15px;font-weight:600;color:#fff;">APK Hazırlamadan Önce Logo & Kimlik Ayarları</div>
          <div id="modalProjSub" class="muted"></div>
        </div>
        <button id="closeModalBtn" class="btn btn-ghost" type="button">Kapat</button>
      </div>
      <div class="modal-body">
        <div class="grid-2">
          <div style="display:flex;flex-direction:column;gap:12px;">
            <div class="launcher-preview">
              <img id="modalLauncherImg" alt="Önizleme" />
              <div id="modalLauncherTitle" style="font-size:13px;font-weight:600;color:#fff;"></div>
              <div id="modalLauncherPkg" class="mono muted" style="font-size:11px;"></div>
            </div>
            <label class="upload-banner" style="padding:12px;">
              <div>
                <div style="font-size:12px;font-weight:600;color:#fff;">Kendi Logonuzu Yükleyin</div>
                <div class="muted">PNG, JPG, WEBP veya SVG (512×512 PNG yapılır)</div>
              </div>
              <span class="btn" style="padding:7px 12px;">Seç</span>
              <input id="modalLogoInput" type="file" accept=".png,.jpg,.jpeg,.webp,.svg" hidden />
            </label>
          </div>

          <div style="display:flex;flex-direction:column;gap:12px;">
            <div>
              <label class="lbl">Hazır Uygulama Simgeleri</label>
              <div id="modalIconGrid" class="icon-grid"></div>
            </div>
            <div>
              <label class="lbl" for="modalAppName">Uygulama Adı</label>
              <input id="modalAppName" type="text" />
            </div>
            <div>
              <label class="lbl" for="modalPkgName">Paket Adı</label>
              <input id="modalPkgName" type="text" class="mono" />
            </div>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button id="cancelModalBtn" class="btn btn-ghost" type="button">Vazgeç</button>
        <button id="confirmModalBuildBtn" class="btn" type="button">Logoyu Kaydet ve Android Projesini Oluştur</button>
      </div>
    </div>
  </div>

  <div id="toast" class="toast"></div>

  <script>
    (function () {
      const STORAGE_KEY = 'html_apk_studio_standalone_v1';
      const memoryFallback = {};
      function safeGet(key) {
        try { return window.localStorage.getItem(key); } catch (e) { return memoryFallback[key] || null; }
      }
      function safeSet(key, val) {
        memoryFallback[key] = val;
        try { window.localStorage.setItem(key, val); } catch (e) {}
      }
      function showToast(msg) {
        const el = document.getElementById('toast');
        el.textContent = msg;
        el.classList.add('show');
        setTimeout(() => el.classList.remove('show'), 2600);
      }
      async function safeCopy(text) {
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(text);
            showToast('Kod panoya kopyalandı.');
            return;
          }
        } catch (e) {}
        try {
          const ta = document.createElement('textarea');
          ta.value = text;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
          showToast('Kod panoya kopyalandı.');
        } catch (e) {
          showToast('Kopyalama desteklenmiyor.');
        }
      }
      function downloadTextFile(filename, content, mime) {
        const blob = new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1500);
      }

      // Generate 6 crisp offline app icons via HTML5 Canvas (zero external URL dependencies)
      function makePresetIcon(c1, c2, letter) {
        const c = document.createElement('canvas');
        c.width = 256;
        c.height = 256;
        const ctx = c.getContext('2d');
        const g = ctx.createLinearGradient(0, 0, 256, 256);
        g.addColorStop(0, c1);
        g.addColorStop(1, c2);
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 256, 256);
        ctx.fillStyle = 'rgba(255,255,255,0.16)';
        ctx.beginPath();
        ctx.arc(128, 128, 78, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 92px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(letter, 128, 134);
        return c.toDataURL('image/png');
      }

      const PRESET_ICONS = [
        { id: 'nebula', name: 'Nebula Studio', src: makePresetIcon('#7C6CF0', '#4F8BFF', 'H') },
        { id: 'commerce', name: 'Ticaret & Mağaza', src: makePresetIcon('#059669', '#10B981', 'M') },
        { id: 'media', name: 'Medya & Oyun', src: makePresetIcon('#EC4899', '#8B5CF6', 'O') },
        { id: 'utility', name: 'Araç & Finans', src: makePresetIcon('#0EA5E9', '#2563EB', 'A') },
        { id: 'cobalt', name: 'Cobalt Prism', src: makePresetIcon('#4F8BFF', '#1E3A8A', 'C') },
        { id: 'aurum', name: 'Aurum Gold', src: makePresetIcon('#F59E0B', '#B45309', 'G') },
      ];

      function createDefaultProject(name, htmlContent) {
        const slug = (name || 'uygulama').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 18) || 'uygulama';
        return {
          id: 'prj_' + Math.random().toString(36).slice(2, 10),
          name: name || 'HTML to APK Studio (Örnek)',
          html: htmlContent || '<!DOCTYPE html>\\n<html lang="tr">\\n<head>\\n  <meta charset="UTF-8" />\\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\\n  <title>Mobil Uygulamam</title>\\n  <link rel="stylesheet" href="css/style.css" />\\n</head>\\n<body>\\n  <main class="box">\\n    <h1>HTML to APK Studio</h1>\\n    <p>Bu örnek proje Android WebView içinde çalışmaya hazırdır.</p>\\n    <button id="testBtn" type="button">Etkileşimi Test Et</button>\\n    <p id="out"></p>\\n  </main>\\n  <script src="js/app.js"><\\/script>\\n</body>\\n</html>',
          css: 'body{margin:0;font-family:system-ui,sans-serif;background:#0b0d14;color:#edf1f7;padding:24px;display:grid;place-items:center;min-height:100vh}.box{max-width:420px;width:100%;background:#121622;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:22px}button{margin-top:12px;background:#7c6cf0;color:#fff;border:0;border-radius:10px;padding:10px 16px;font-weight:600;cursor:pointer}',
          js: "document.getElementById('testBtn')?.addEventListener('click', () => {\\n  const el = document.getElementById('out');\\n  if (el) el.textContent = 'WebView aktif: ' + new Date().toLocaleTimeString('tr-TR');\\n});",
          config: {
            appName: name || 'HTML Uygulamam',
            packageName: 'com.htmltoapk.' + slug,
            versionName: '1.0.0',
            versionCode: 1,
            iconPreset: 'nebula',
            customLogoDataUrl: null,
            orientation: 'unspecified',
            launchAnimation: 'fade',
            fullscreen: false,
            internetPermission: true,
            splashEnabled: true,
            splashTitle: name || 'HTML Uygulamam',
          }
        };
      }

      let state = {
        projects: [],
        selectedProjectId: null,
        builds: [],
        activeFileTab: 'html',
        activeAndroidTab: 'kotlin',
      };

      try {
        const raw = safeGet(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed.projects) && parsed.projects.length > 0) {
            state = Object.assign(state, parsed);
          }
        }
      } catch (e) {}

      if (state.projects.length === 0) {
        const starter = createDefaultProject('HTML to APK Studio (Örnek)');
        state.projects.push(starter);
        state.selectedProjectId = starter.id;
      }
      if (!state.selectedProjectId || !state.projects.some((p) => p.id === state.selectedProjectId)) {
        state.selectedProjectId = state.projects[0].id;
      }

      function persist() {
        try { safeSet(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
      }

      function getActiveProject() {
        return state.projects.find((p) => p.id === state.selectedProjectId) || state.projects[0];
      }

      function getProjectIconSrc(proj) {
        if (proj.config.iconPreset === 'custom' && proj.config.customLogoDataUrl) {
          return proj.config.customLogoDataUrl;
        }
        const found = PRESET_ICONS.find((i) => i.id === proj.config.iconPreset);
        return found ? found.src : PRESET_ICONS[0].src;
      }

      function rasterizeImageFile(file, cb) {
        const reader = new FileReader();
        reader.onload = () => {
          const img = new Image();
          img.onload = () => {
            const c = document.createElement('canvas');
            c.width = 512;
            c.height = 512;
            const ctx = c.getContext('2d');
            const scale = Math.max(512 / (img.width || 512), 512 / (img.height || 512));
            const w = (img.width || 512) * scale;
            const h = (img.height || 512) * scale;
            ctx.drawImage(img, (512 - w) / 2, (512 - h) / 2, w, h);
            cb(c.toDataURL('image/png'));
          };
          img.onerror = () => showToast('Görsel dosyası okunamadı.');
          img.src = String(reader.result || '');
        };
        reader.readAsDataURL(file);
      }

      // Navigation
      function navigateTo(sec) {
        document.querySelectorAll('.section').forEach((s) => s.classList.remove('active'));
        const target = document.getElementById('sec-' + sec);
        if (target) target.classList.add('active');

        document.querySelectorAll('[data-nav]').forEach((b) => {
          b.classList.toggle('active', b.dataset.nav === sec);
        });
        document.getElementById('sidebar').classList.remove('mobile-open');

        if (sec === 'preview') renderPreview();
        if (sec === 'settings') renderSettings();
        if (sec === 'build') renderAndroidOutputs();
        if (sec === 'projects') renderProjects();
        if (sec === 'dashboard') renderDashboard();
      }

      document.querySelectorAll('[data-nav]').forEach((btn) => {
        btn.addEventListener('click', () => navigateTo(btn.dataset.nav));
      });
      document.getElementById('menuToggleBtn').addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('mobile-open');
      });

      // Dashboard
      function renderDashboard() {
        const proj = getActiveProject();
        document.getElementById('dashProjCount').textContent = state.projects.length;
        document.getElementById('dashBuildCount').textContent = state.builds.length;
        document.getElementById('dashActiveName').textContent = proj ? proj.name : '—';

        const tbody = document.getElementById('recentBuildsTbody');
        if (state.builds.length === 0) {
          tbody.innerHTML = '<tr><td colspan="4" class="muted" style="text-align:center;padding:24px;">Henüz bir dönüştürme oluşturulmadı.</td></tr>';
        } else {
          tbody.innerHTML = state.builds.slice(0, 8).map((b) =>
            '<tr>' +
              '<td style="color:#fff;font-weight:600;">' + escapeHtml(b.appName) + '</td>' +
              '<td class="mono muted">' + escapeHtml(b.packageName) + '</td>' +
              '<td style="color:var(--ok);">Android Paketi Hazır</td>' +
              '<td class="muted">' + escapeHtml(b.date) + '</td>' +
            '</tr>'
          ).join('');
        }
      }

      function escapeHtml(s) {
        return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      }

      // Quick HTML upload
      document.getElementById('quickHtmlUpload').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          const baseName = file.name.replace(/\\.[^.]+$/, '') || 'HTML Projesi';
          const proj = createDefaultProject(baseName, String(reader.result || ''));
          proj.css = '';
          proj.js = '';
          state.projects.unshift(proj);
          state.selectedProjectId = proj.id;
          persist();
          renderDashboard();
          openPreBuildModal();
        };
        reader.readAsText(file, 'utf-8');
        e.target.value = '';
      });

      document.getElementById('createNewProjBtn').addEventListener('click', () => {
        const proj = createDefaultProject('Yeni Proje ' + (state.projects.length + 1));
        state.projects.unshift(proj);
        state.selectedProjectId = proj.id;
        persist();
        navigateTo('projects');
        showToast('Yeni proje oluşturuldu.');
      });

      document.getElementById('projAddBtn').addEventListener('click', () => {
        const proj = createDefaultProject('Yeni Proje ' + (state.projects.length + 1));
        state.projects.unshift(proj);
        state.selectedProjectId = proj.id;
        persist();
        renderProjects();
        showToast('Yeni proje eklendi.');
      });

      // Projects Editor
      function renderProjects() {
        const active = getActiveProject();
        const listCol = document.getElementById('projectsListCol');
        listCol.innerHTML = '';

        state.projects.forEach((p) => {
          const card = document.createElement('div');
          card.className = 'card';
          card.style.padding = '14px';
          card.style.borderColor = p.id === active.id ? 'var(--primary)' : 'var(--border)';
          card.innerHTML =
            '<div style="display:flex;align-items:center;gap:12px;cursor:pointer;">' +
              '<img src="' + getProjectIconSrc(p) + '" style="width:40px;height:40px;border-radius:10px;object-fit:cover;flex-shrink:0;" alt="" />' +
              '<div style="min-width:0;flex:1;">' +
                '<div style="font-size:13px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + escapeHtml(p.name) + '</div>' +
                '<div class="mono muted" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + escapeHtml(p.config.packageName) + '</div>' +
              '</div>' +
            '</div>' +
            '<div style="display:flex;justify-content:space-between;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);font-size:11px;">' +
              '<button type="button" class="proj-prev-btn" style="background:none;border:0;color:var(--accent);">Önizle</button>' +
              (state.projects.length > 1 ? '<button type="button" class="proj-del-btn" style="background:none;border:0;color:var(--err);">Sil</button>' : '<span></span>') +
            '</div>';
          card.firstChild.addEventListener('click', () => {
            state.selectedProjectId = p.id;
            persist();
            renderProjects();
          });
          card.querySelector('.proj-prev-btn').addEventListener('click', () => {
            state.selectedProjectId = p.id;
            navigateTo('preview');
          });
          const delBtn = card.querySelector('.proj-del-btn');
          if (delBtn) {
            delBtn.addEventListener('click', () => {
              state.projects = state.projects.filter((x) => x.id !== p.id);
              state.selectedProjectId = state.projects[0].id;
              persist();
              renderProjects();
            });
          }
          listCol.appendChild(card);
        });

        document.getElementById('editorProjTitle').textContent = active.name;
        document.getElementById('editorProjPkg').textContent = active.config.packageName;
        document.getElementById('codeEditorArea').value = active[state.activeFileTab] || '';
        document.querySelectorAll('.file-tab').forEach((t) => {
          t.style.borderColor = t.dataset.file === state.activeFileTab ? 'var(--primary)' : 'var(--border-strong)';
        });
      }

      document.querySelectorAll('.file-tab').forEach((btn) => {
        btn.addEventListener('click', () => {
          const active = getActiveProject();
          active[state.activeFileTab] = document.getElementById('codeEditorArea').value;
          state.activeFileTab = btn.dataset.file;
          persist();
          renderProjects();
        });
      });

      document.getElementById('saveEditorFileBtn').addEventListener('click', () => {
        const active = getActiveProject();
        active[state.activeFileTab] = document.getElementById('codeEditorArea').value;
        persist();
        showToast('Dosya kaydedildi.');
      });

      // Preview
      function buildCombinedHtml(proj) {
        let html = proj.html || '';
        const errScript = '<script>(function(){window.addEventListener("error",function(e){window.parent.postMessage({source:"studio-preview",msg:e.message},"*");});})();<\\/script>';
        if (proj.css && html.includes('</head>')) {
          html = html.replace('</head>', '<style>' + proj.css + '</style>' + errScript + '</head>');
        } else {
          html = errScript + (proj.css ? '<style>' + proj.css + '</style>' : '') + html;
        }
        if (proj.js && html.includes('</body>')) {
          html = html.replace('</body>', '<script>' + proj.js + '<\\/script></body>');
        } else if (proj.js) {
          html += '<script>' + proj.js + '<\\/script>';
        }
        return html;
      }

      function renderPreview() {
        const proj = getActiveProject();
        document.getElementById('previewErrorsBox').textContent = 'Hata tespit edilmedi.';
        document.getElementById('livePreviewIframe').srcdoc = buildCombinedHtml(proj);
      }

      window.addEventListener('message', (ev) => {
        if (ev.data && ev.data.source === 'studio-preview') {
          document.getElementById('previewErrorsBox').textContent = 'Hata: ' + ev.data.msg;
        }
      });

      document.querySelectorAll('.device-switch').forEach((btn) => {
        btn.addEventListener('click', () => {
          const frame = document.getElementById('deviceFrame');
          frame.classList.remove('tablet', 'desktop');
          if (btn.dataset.mode !== 'mobile') frame.classList.add(btn.dataset.mode);
        });
      });
      document.getElementById('refreshPreviewBtn').addEventListener('click', renderPreview);

      // Settings
      const PKG_REGEX = /^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$/;
      function renderSettings() {
        const proj = getActiveProject();
        const c = proj.config;
        document.getElementById('setAppName').value = c.appName;
        document.getElementById('setPkgName').value = c.packageName;
        document.getElementById('setVerName').value = c.versionName;
        document.getElementById('setVerCode').value = c.versionCode;
        document.getElementById('setOrientation').value = c.orientation;
        document.getElementById('setLaunchAnim').value = c.launchAnimation;
        document.getElementById('setFullscreen').checked = Boolean(c.fullscreen);
        document.getElementById('setInternet').checked = Boolean(c.internetPermission);
        document.getElementById('setSplashEnabled').checked = Boolean(c.splashEnabled);
        document.getElementById('setSplashTitle').value = c.splashTitle;

        document.getElementById('settingsLauncherImg').src = getProjectIconSrc(proj);
        document.getElementById('settingsLauncherLabel').textContent = c.appName;

        const grid = document.getElementById('settingsIconGrid');
        grid.innerHTML = '';
        PRESET_ICONS.forEach((ic) => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'icon-option' + (c.iconPreset === ic.id ? ' active' : '');
          btn.innerHTML = '<img src="' + ic.src + '" alt="" /><span>' + ic.name + '</span>';
          btn.addEventListener('click', () => {
            c.iconPreset = ic.id;
            c.customLogoDataUrl = null;
            persist();
            renderSettings();
          });
          grid.appendChild(btn);
        });
      }

      document.getElementById('settingsLogoUpload').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        rasterizeImageFile(file, (dataUrl) => {
          const proj = getActiveProject();
          proj.config.iconPreset = 'custom';
          proj.config.customLogoDataUrl = dataUrl;
          persist();
          renderSettings();
          showToast('Özel logo 512×512 PNG olarak eklendi.');
        });
        e.target.value = '';
      });

      document.getElementById('saveSettingsBtn').addEventListener('click', () => {
        const proj = getActiveProject();
        const pkg = document.getElementById('setPkgName').value.trim();
        const errEl = document.getElementById('setPkgErr');
        if (!PKG_REGEX.test(pkg)) {
          errEl.style.display = 'block';
          return;
        }
        errEl.style.display = 'none';
        proj.config.appName = document.getElementById('setAppName').value.trim() || proj.name;
        proj.config.packageName = pkg;
        proj.config.versionName = document.getElementById('setVerName').value.trim() || '1.0.0';
        proj.config.versionCode = Math.max(1, Number(document.getElementById('setVerCode').value) || 1);
        proj.config.orientation = document.getElementById('setOrientation').value;
        proj.config.launchAnimation = document.getElementById('setLaunchAnim').value;
        proj.config.fullscreen = document.getElementById('setFullscreen').checked;
        proj.config.internetPermission = document.getElementById('setInternet').checked;
        proj.config.splashEnabled = document.getElementById('setSplashEnabled').checked;
        proj.config.splashTitle = document.getElementById('setSplashTitle').value.trim() || proj.config.appName;
        persist();
        renderSettings();
        showToast('APK ayarları kaydedildi.');
      });

      // Android Code Outputs
      function getAndroidFileMap(proj) {
        const c = proj.config;
        return {
          kotlin: {
            filename: 'MainActivity.kt',
            content: 'package ' + c.packageName + '\\n\\nimport android.annotation.SuppressLint\\nimport android.os.Bundle\\nimport android.webkit.WebResourceRequest\\nimport android.webkit.WebResourceResponse\\nimport android.webkit.WebSettings\\nimport android.webkit.WebView\\nimport android.webkit.WebViewClient\\nimport androidx.activity.OnBackPressedCallback\\nimport androidx.appcompat.app.AppCompatActivity\\nimport androidx.webkit.WebViewAssetLoader\\n\\nclass MainActivity : AppCompatActivity() {\\n    private lateinit var webView: WebView\\n    private val localOrigin = "https://appassets.androidplatform.net"\\n\\n    @SuppressLint("SetJavaScriptEnabled")\\n    override fun onCreate(savedInstanceState: Bundle?) {\\n        super.onCreate(savedInstanceState)\\n        webView = WebView(this)\\n        setContentView(webView)\\n\\n        val assetLoader = WebViewAssetLoader.Builder()\\n            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))\\n            .build()\\n\\n        webView.settings.apply {\\n            javaScriptEnabled = true\\n            domStorageEnabled = true\\n            useWideViewPort = true\\n            loadWithOverviewMode = true\\n            allowFileAccess = true\\n            allowFileAccessFromFileURLs = false\\n            allowUniversalAccessFromFileURLs = false\\n            cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK\\n        }\\n        WebView.setWebContentsDebuggingEnabled(false)\\n\\n        webView.webViewClient = object : WebViewClient() {\\n            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {\\n                return assetLoader.shouldInterceptRequest(req.url)\\n            }\\n        }\\n\\n        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {\\n            override fun handleOnBackPressed() {\\n                if (webView.canGoBack()) webView.goBack() else finish()\\n            }\\n        })\\n\\n        webView.loadUrl("$localOrigin/assets/www/index.html")\\n    }\\n}'
          },
          splash: {
            filename: 'SplashActivity.kt',
            content: 'package ' + c.packageName + '\\n\\nimport android.content.Intent\\nimport android.os.Bundle\\nimport android.os.Handler\\nimport android.os.Looper\\nimport androidx.appcompat.app.AppCompatActivity\\n\\nclass SplashActivity : AppCompatActivity() {\\n    override fun onCreate(savedInstanceState: Bundle?) {\\n        super.onCreate(savedInstanceState)\\n        Handler(Looper.getMainLooper()).postDelayed({\\n            startActivity(Intent(this, MainActivity::class.java))\\n            finish()\\n        }, 1200L)\\n    }\\n}'
          },
          manifest: {
            filename: 'AndroidManifest.xml',
            content: '<?xml version="1.0" encoding="utf-8"?>\\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\\n' + (c.internetPermission ? '    <uses-permission android:name="android.permission.INTERNET" />\\n' : '') + '    <application\\n        android:allowBackup="false"\\n        android:icon="@mipmap/ic_launcher"\\n        android:label="' + c.appName + '"\\n        android:roundIcon="@mipmap/ic_launcher"\\n        android:supportsRtl="true">\\n        <activity\\n            android:name=".MainActivity"\\n            android:exported="true"\\n            android:screenOrientation="' + c.orientation + '"\\n            android:configChanges="orientation|screenSize|keyboardHidden">\\n            <intent-filter>\\n                <action android:name="android.intent.action.MAIN" />\\n                <category android:name="android.intent.category.LAUNCHER" />\\n            </intent-filter>\\n        </activity>\\n    </application>\\n</manifest>'
          },
          gradle: {
            filename: 'build.gradle.kts',
            content: 'plugins {\\n    id("com.android.application")\\n    id("org.jetbrains.kotlin.android")\\n}\\n\\nandroid {\\n    namespace = "' + c.packageName + '"\\n    compileSdk = 34\\n    defaultConfig {\\n        applicationId = "' + c.packageName + '"\\n        minSdk = 24\\n        targetSdk = 34\\n        versionCode = ' + c.versionCode + '\\n        versionName = "' + c.versionName + '"\\n    }\\n}\\n\\ndependencies {\\n    implementation("androidx.appcompat:appcompat:1.7.0")\\n    implementation("androidx.webkit:webkit:1.11.0")\\n}'
          },
          docker: {
            filename: 'Dockerfile',
            content: 'FROM eclipse-temurin:17-jdk-jammy\\nENV ANDROID_SDK_ROOT=/opt/android-sdk\\nWORKDIR /workspace\\nCOPY . /workspace\\nRUN gradle --no-daemon assembleDebug'
          },
          script: {
            filename: 'build-apk.sh',
            content: '#!/usr/bin/env bash\\nset -euo pipefail\\ndocker build -t html-apk-project .\\nCID=$(docker create html-apk-project)\\nmkdir -p out\\ndocker cp "$CID:/workspace/app/build/outputs/apk/debug/app-debug.apk" ./out/app-debug.apk\\ndocker rm "$CID"\\necho "APK hazir: ./out/app-debug.apk"'
          }
        };
      }

      function renderAndroidOutputs() {
        const proj = getActiveProject();
        const files = getAndroidFileMap(proj);
        const cur = files[state.activeAndroidTab] || files.kotlin;
        document.getElementById('androidCodePre').textContent = cur.content;
        document.querySelectorAll('.android-tab').forEach((t) => {
          t.style.borderColor = t.dataset.tab === state.activeAndroidTab ? 'var(--primary)' : 'var(--border-strong)';
        });
      }

      document.querySelectorAll('.android-tab').forEach((btn) => {
        btn.addEventListener('click', () => {
          state.activeAndroidTab = btn.dataset.tab;
          renderAndroidOutputs();
        });
      });

      document.getElementById('copyActiveAndroidBtn').addEventListener('click', () => {
        safeCopy(document.getElementById('androidCodePre').textContent);
      });

      document.getElementById('downloadActiveAndroidBtn').addEventListener('click', () => {
        const files = getAndroidFileMap(getActiveProject());
        const cur = files[state.activeAndroidTab] || files.kotlin;
        downloadTextFile(cur.filename, cur.content);
      });

      // Pre-Build Logo & Identity Modal
      let modalDraftConfig = null;
      function openPreBuildModal() {
        const proj = getActiveProject();
        modalDraftConfig = Object.assign({}, proj.config);
        document.getElementById('modalProjSub').textContent = 'Proje: ' + proj.name;
        document.getElementById('modalAppName').value = modalDraftConfig.appName;
        document.getElementById('modalPkgName').value = modalDraftConfig.packageName;
        refreshModalPreview();
        document.getElementById('preBuildModal').classList.add('open');
      }

      function refreshModalPreview() {
        const src =
          modalDraftConfig.iconPreset === 'custom' && modalDraftConfig.customLogoDataUrl
            ? modalDraftConfig.customLogoDataUrl
            : (PRESET_ICONS.find((i) => i.id === modalDraftConfig.iconPreset) || PRESET_ICONS[0]).src;
        document.getElementById('modalLauncherImg').src = src;
        document.getElementById('modalLauncherTitle').textContent = modalDraftConfig.appName || 'Uygulama';
        document.getElementById('modalLauncherPkg').textContent = modalDraftConfig.packageName;

        const grid = document.getElementById('modalIconGrid');
        grid.innerHTML = '';
        PRESET_ICONS.forEach((ic) => {
          const b = document.createElement('button');
          b.type = 'button';
          b.className = 'icon-option' + (modalDraftConfig.iconPreset === ic.id ? ' active' : '');
          b.innerHTML = '<img src="' + ic.src + '" alt="" /><span>' + ic.name + '</span>';
          b.addEventListener('click', () => {
            modalDraftConfig.iconPreset = ic.id;
            modalDraftConfig.customLogoDataUrl = null;
            refreshModalPreview();
          });
          grid.appendChild(b);
        });
      }

      document.getElementById('modalAppName').addEventListener('input', (e) => {
        modalDraftConfig.appName = e.target.value;
        document.getElementById('modalLauncherTitle').textContent = modalDraftConfig.appName || 'Uygulama';
      });
      document.getElementById('modalPkgName').addEventListener('input', (e) => {
        modalDraftConfig.packageName = e.target.value.trim();
        document.getElementById('modalLauncherPkg').textContent = modalDraftConfig.packageName;
      });
      document.getElementById('modalLogoInput').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        rasterizeImageFile(file, (dataUrl) => {
          modalDraftConfig.iconPreset = 'custom';
          modalDraftConfig.customLogoDataUrl = dataUrl;
          refreshModalPreview();
          showToast('Logo 512×512 PNG olarak eklendi.');
        });
        e.target.value = '';
      });

      function closeModal() {
        document.getElementById('preBuildModal').classList.remove('open');
      }
      document.getElementById('closeModalBtn').addEventListener('click', closeModal);
      document.getElementById('cancelModalBtn').addEventListener('click', closeModal);

      document.getElementById('confirmModalBuildBtn').addEventListener('click', () => {
        if (!PKG_REGEX.test(modalDraftConfig.packageName)) {
          showToast('Geçersiz Android paket adı (ör. com.firma.uygulama)');
          return;
        }
        const proj = getActiveProject();
        proj.config = Object.assign({}, proj.config, modalDraftConfig);
        state.builds.unshift({
          appName: proj.config.appName,
          packageName: proj.config.packageName,
          date: new Date().toLocaleString('tr-TR'),
        });
        persist();
        closeModal();
        navigateTo('build');
        showToast('Logo ve Android WebView dosyaları hazırlandı.');
      });

      document.getElementById('topBuildBtn').addEventListener('click', openPreBuildModal);
      document.getElementById('dashOpenPreBuildBtn').addEventListener('click', openPreBuildModal);
      document.getElementById('editorBuildBtn').addEventListener('click', openPreBuildModal);
      document.getElementById('buildTriggerBtn').addEventListener('click', openPreBuildModal);

      function exportActiveAsHtml() {
        const proj = getActiveProject();
        downloadTextFile('index.html', buildCombinedHtml(proj), 'text/html;charset=utf-8');
        showToast('Tek dosya HTML indirildi.');
      }
      document.getElementById('exportCurrentHtmlBtn').addEventListener('click', exportActiveAsHtml);
      document.getElementById('buildDownloadSingleHtmlBtn').addEventListener('click', exportActiveAsHtml);

      renderDashboard();
    })();
  </script>
</body>
</html>
`;
}
