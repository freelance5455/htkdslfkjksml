/**
 * JARVIS Files & Attachments API Router
 */

import { Router } from 'express';
import type { Request, Response } from 'express';

import { fileManager } from '../files/fileManager.ts';

export const filesRouter = Router();

// 1. Upload file (JSON with base64 data)
filesRouter.post('/upload', async (req: Request, res: Response) => {
  try {
    const { originalName, mimeType, base64Data, conversationId, projectId } = req.body;

    if (!originalName || !mimeType || !base64Data) {
      return res.status(400).json({
        error: 'Missing required upload parameters: originalName, mimeType, and base64Data are required.',
      });
    }

    const cleanBase64 = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
    const buffer = Buffer.from(cleanBase64, 'base64');

    const file = await fileManager.uploadFile({
      originalName,
      mimeType,
      buffer,
      conversationId,
      projectId,
      userId: req.body.userId || 'usr_jarvis_prime',
    });

    return res.status(201).json({
      success: true,
      file,
    });
  } catch (error) {
    console.error('[FILES ROUTER ERROR]', error);
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'File upload failed',
    });
  }
});

// 2. List files
filesRouter.get('/', async (req: Request, res: Response) => {
  try {
    const conversationId = typeof req.query.conversationId === 'string' ? req.query.conversationId : undefined;
    const projectId = typeof req.query.projectId === 'string' ? req.query.projectId : undefined;
    const userId = typeof req.query.userId === 'string' ? req.query.userId : undefined;

    const files = await fileManager.getFiles({ conversationId, projectId, userId });
    return res.json({ success: true, files });
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to retrieve files',
    });
  }
});

// 3. Get file metadata
filesRouter.get('/:id', async (req: Request, res: Response) => {
  try {
    const file = await fileManager.getFile(req.params.id);
    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }
    return res.json({ success: true, file });
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to retrieve file',
    });
  }
});

// 4. Download file
filesRouter.get('/:id/download', async (req: Request, res: Response) => {
  try {
    const result = await fileManager.getFileBuffer(req.params.id);
    if (!result) {
      return res.status(404).json({ error: 'File or storage content not found' });
    }
    const { buffer, file } = result;

    res.setHeader('Content-Type', file.mimeType || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${file.originalName}"`);
    res.setHeader('Content-Length', buffer.length);
    return res.send(buffer);
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Download failed',
    });
  }
});

// 5. Delete file
filesRouter.delete('/:id', async (req: Request, res: Response) => {
  try {
    const success = await fileManager.deleteFile(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'File not found or already deleted' });
    }
    return res.json({ success: true, message: 'File successfully deleted' });
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to delete file',
    });
  }
});
