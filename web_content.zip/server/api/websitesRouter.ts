/**
 * JARVIS Websites API Router
 * Endpoints for website project generation, preview, metadata, and .zip package download.
 */

import { Router, Request, Response } from 'express';
import { websiteGenerator } from '../code/websiteGenerator.ts';

export const websitesRouter = Router();

// List all generated websites
websitesRouter.get('/', (req: Request, res: Response) => {
  const websites = websiteGenerator.getAllWebsites();
  res.json({
    success: true,
    total: websites.length,
    websites: websites.map(w => ({
      id: w.id,
      title: w.title,
      theme: w.theme,
      fileCount: w.fileCount,
      totalBytes: w.totalBytes,
      previewUrl: w.previewUrl,
      downloadUrl: w.downloadUrl,
      generatedAt: w.generatedAt,
      buildStatus: w.buildStatus,
    })),
  });
});

// Generate website
websitesRouter.post('/generate', (req: Request, res: Response) => {
  try {
    const pkg = websiteGenerator.generateWebsite(req.body || {});
    res.status(201).json({
      success: true,
      message: `Website project "${pkg.title}" synthesized successfully.`,
      data: pkg,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message || 'Website generation failed',
    });
  }
});

// Get website metadata
websitesRouter.get('/:id', (req: Request, res: Response) => {
  const pkg = websiteGenerator.getWebsite(req.params.id);
  if (!pkg) {
    res.status(404).json({ success: false, error: 'Website project not found' });
    return;
  }
  res.json({
    success: true,
    data: pkg,
  });
});

// Live preview website (HTML)
websitesRouter.get('/:id/preview', (req: Request, res: Response) => {
  const pkg = websiteGenerator.getWebsite(req.params.id);
  if (!pkg) {
    res.status(404).send('<!DOCTYPE html><html><body><h1>Website Project Not Found</h1></body></html>');
    return;
  }
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.send(pkg.htmlContent);
});

// Download full project (.zip)
websitesRouter.get('/:id/download', (req: Request, res: Response) => {
  const pkg = websiteGenerator.getWebsite(req.params.id);
  const zipBuffer = websiteGenerator.getWebsiteZip(req.params.id);

  if (!pkg || !zipBuffer) {
    res.status(404).json({ success: false, error: 'Website package not found' });
    return;
  }

  const safeName = pkg.title.toLowerCase().replace(/[^a-z0-9_-]/g, '-');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${safeName}-project.zip"`);
  res.setHeader('Content-Length', zipBuffer.length.toString());
  res.send(zipBuffer);
});

// Get individual file content from project
websitesRouter.get('/:id/files/:filename(*)', (req: Request, res: Response) => {
  const pkg = websiteGenerator.getWebsite(req.params.id);
  if (!pkg) {
    res.status(404).json({ success: false, error: 'Website project not found' });
    return;
  }
  const filename = req.params.filename;
  const file = pkg.files.find(f => f.name === filename);
  if (!file) {
    res.status(404).json({ success: false, error: `File "${filename}" not found in project` });
    return;
  }
  res.setHeader('Content-Type', `${file.mimeType}; charset=utf-8`);
  res.send(file.content);
});
