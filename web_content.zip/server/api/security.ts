import { Request, Response, Router } from 'express';

import { jarvisCore } from '../core/jarvisCore.ts';
import { db } from '../db/database.ts';
import { securityLayer } from '../security/securityLayer.ts';

export const securityRouter = Router();

securityRouter.get('/api/security/requests', (req: Request, res: Response) => {
  try {
    const pendingRequests = securityLayer.getPendingRequests();
    res.json({ requests: pendingRequests, pendingRequests });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve pending security requests' });
  }
});

securityRouter.post('/api/security/approve', async (req: Request, res: Response) => {
  try {
    const { taskId, requestId } = req.body;
    let targetTaskId = taskId;
    if (!targetTaskId && requestId) {
      const match = securityLayer.getPendingRequests().find((r) => r.id === requestId);
      if (match) targetTaskId = match.taskId;
    }
    if (!targetTaskId) {
      res.status(400).json({ error: 'taskId or requestId is required for approval' });
      return;
    }
    const updatedTask = await jarvisCore.approveAndResumeTask(targetTaskId);
    if (!updatedTask) {
      res.status(404).json({ error: 'Task not found or not waiting for permission' });
      return;
    }
    res.json({ success: true, task: updatedTask });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to approve security request' });
  }
});

securityRouter.post('/api/security/reject', async (req: Request, res: Response) => {
  try {
    const { taskId, requestId, reason } = req.body;
    let targetTaskId = taskId;
    if (!targetTaskId && requestId) {
      const match = securityLayer.getPendingRequests().find((r) => r.id === requestId);
      if (match) targetTaskId = match.taskId;
    }
    if (!targetTaskId) {
      res.status(400).json({ error: 'taskId or requestId is required for rejection' });
      return;
    }
    const updatedTask = await jarvisCore.rejectTask(targetTaskId, reason);
    if (!updatedTask) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }
    res.json({ success: true, task: updatedTask });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to reject security request' });
  }
});

securityRouter.get('/api/security/audit', async (req: Request, res: Response) => {
  try {
    const logs = await db.getAuditLogs(100);
    const pendingRequests = securityLayer.getPendingRequests();
    res.json({ auditLogs: logs, pendingRequests });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve security audit data' });
  }
});
