/**
 * JARVIS Version, Founder Identity & Free Resource Discovery Router
 */

import { Request, Response, Router } from 'express';
import { freeResourceDiscovery } from '../discovery/freeResourceDiscovery.ts';
import { universalResourceEngine } from '../discovery/universalResourceEngine.ts';
import { FOUNDER_PROFILE } from '../models/identity.ts';
import { webResearchEngine } from '../research/webResearchEngine.ts';
import type { FreeResourceQuery } from '../types.ts';
import { versionManager } from '../version/versionManager.ts';

export const versionAndDiscoveryRouter = Router();

// GET /api/founder/profile - Retrieve verified founder identity profile
versionAndDiscoveryRouter.get('/api/founder/profile', (_req: Request, res: Response) => {
  res.json({
    founder: FOUNDER_PROFILE,
  });
});

// GET /api/version/metadata - Retrieve system version, decoupled provider info & evolution ledger
versionAndDiscoveryRouter.get('/api/version/metadata', (_req: Request, res: Response) => {
  res.json({
    version: versionManager.getVersionMetadata(),
  });
});

// POST /api/version/evaluate - Evaluate version promotion criteria
versionAndDiscoveryRouter.post('/api/version/evaluate', (req: Request, res: Response) => {
  try {
    const evaluation = versionManager.evaluateVersionEligibility(req.body || {});
    res.json(evaluation);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to evaluate version' });
  }
});

// POST /api/discovery/free-resources - Search legitimate copyright-safe free resources
versionAndDiscoveryRouter.post('/api/discovery/free-resources', (req: Request, res: Response) => {
  try {
    const query: FreeResourceQuery = req.body || {};
    const result = freeResourceDiscovery.discover(query);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to search free resources' });
  }
});

// GET /api/discovery/free-resources - Get pre-curated categories or default recommendations
versionAndDiscoveryRouter.get('/api/discovery/free-resources', (req: Request, res: Response) => {
  try {
    const category = req.query.category as any;
    const result = freeResourceDiscovery.discover({
      query: (req.query.q as string) || '',
      category,
      mustBeGenuinelyFree: true,
      noPaymentCardRequired: true,
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to list free resources' });
  }
});

// POST /api/discovery/universal-investigate - Truthful universal website/app/service investigation
versionAndDiscoveryRouter.post('/api/discovery/universal-investigate', async (req: Request, res: Response) => {
  try {
    const query = typeof req.body?.query === 'string' ? req.body.query : '';
    if (!query) {
      return res.status(400).json({ error: 'Missing query parameter.' });
    }
    const investigation = await universalResourceEngine.investigate(query);
    return res.json({ success: true, investigation });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Investigation failed' });
  }
});

// POST /api/research/synthesize - Multi-source web research & factual synthesis
versionAndDiscoveryRouter.post('/api/research/synthesize', async (req: Request, res: Response) => {
  try {
    const { query, focusArea, maxSources } = req.body || {};
    if (!query) {
      return res.status(400).json({ error: 'Missing query parameter.' });
    }
    const report = await webResearchEngine.conductResearch({
      query,
      focusArea,
      maxSources: typeof maxSources === 'number' ? maxSources : 5,
    });
    return res.json({ success: true, report });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Research synthesis failed' });
  }
});
