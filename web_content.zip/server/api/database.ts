import { Request, Response, Router } from 'express';

import { db } from '../db/database.ts';

export const databaseRouter = Router();

const healthHandler = async (req: Request, res: Response) => {
  try {
    const health = await db.getHealth();
    res.json(health);
  } catch (err: any) {
    res.status(500).json({ status: 'ERROR', error: err?.message || String(err) });
  }
};

databaseRouter.get('/api/database/status', healthHandler);
databaseRouter.get('/api/database/health', healthHandler);
