/**
 * JARVIS Projects Workspace Router
 * Endpoints for Project lifecycle: Create, List, Detail, Update, Archive, Restore, Delete,
 * and associated conversations management.
 */

import { Request, Response, Router } from 'express';
import { db } from '../db/database.ts';
import type {
  ProjectCreateApiRequest,
  ProjectDetailApiResponse,
  ProjectItem,
  ProjectsListApiResponse,
  ProjectUpdateApiRequest,
} from '../types.ts';

export const projectsRouter = Router();
const DEFAULT_USER_ID = 'usr_jarvis_prime';

// GET /api/projects - List projects with conversation counts
projectsRouter.get('/api/projects', async (req: Request, res: Response) => {
  try {
    const includeArchived = req.query.includeArchived === 'true';
    const includeTrash = req.query.includeTrash === 'true';
    const isTrashOnly = req.query.isTrashOnly === 'true';

    const entities = await db.getProjects(DEFAULT_USER_ID);
    let filtered = entities;

    if (isTrashOnly) {
      filtered = filtered.filter((p) => p.isTrash);
    } else {
      if (!includeTrash) {
        filtered = filtered.filter((p) => !p.isTrash);
      }
      if (!includeArchived) {
        filtered = filtered.filter((p) => !p.isArchived);
      }
    }

    const projects: ProjectItem[] = filtered.map((p) => ({
      id: p.id,
      userId: p.userId,
      name: p.name,
      description: p.description,
      contextBrief: p.contextBrief || '',
      status: p.status,
      isArchived: p.isArchived,
      isTrash: p.isTrash,
      conversationCount: p.conversationCount || 0,
      createdAt: p.createdAt,
      updatedAt: p.updatedAt || p.createdAt,
    }));

    const response: ProjectsListApiResponse = { projects };
    res.json(response);
  } catch (err: any) {
    console.error('Failed to list projects:', err);
    res.status(500).json({ error: err?.message || 'Failed to list projects' });
  }
});

// POST /api/projects - Create a new project
projectsRouter.post('/api/projects', async (req: Request, res: Response) => {
  try {
    const body: ProjectCreateApiRequest = req.body || {};
    const name = (body.name || '').trim();
    if (!name) {
      res.status(400).json({ error: 'Project name is required' });
      return;
    }

    const description = (body.description || '').trim() || 'Custom Project Workspace';
    const contextBrief = (body.contextBrief || '').trim();
    const now = new Date().toISOString();
    const id = `proj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    if (!db.saveProject) {
      res.status(500).json({ error: 'Project persistence not supported by database engine' });
      return;
    }

    const saved = await db.saveProject({
      id,
      userId: DEFAULT_USER_ID,
      name,
      description,
      contextBrief,
      status: 'ACTIVE',
      isArchived: false,
      isTrash: false,
      createdAt: now,
      updatedAt: now,
    });

    const project: ProjectItem = {
      id: saved.id,
      userId: saved.userId,
      name: saved.name,
      description: saved.description,
      contextBrief: saved.contextBrief || '',
      status: saved.status,
      isArchived: false,
      isTrash: false,
      conversationCount: 0,
      createdAt: saved.createdAt,
      updatedAt: saved.updatedAt || saved.createdAt,
    };

    res.status(201).json({ success: true, project });
  } catch (err: any) {
    console.error('Failed to create project:', err);
    res.status(500).json({ error: err?.message || 'Failed to create project' });
  }
});

// GET /api/projects/:id - Get project detail and associated conversations
projectsRouter.get('/api/projects/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    if (!db.getProject) {
      res.status(500).json({ error: 'getProject not supported' });
      return;
    }

    const entity = await db.getProject(id);
    if (!entity) {
      res.status(404).json({ error: `Project ${id} not found` });
      return;
    }

    // Retrieve associated conversations
    const convEntities = await db.getConversations(DEFAULT_USER_ID, { projectId: id });
    const conversations = convEntities.map((c) => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      topic: c.topic || 'General',
      isArchived: c.isArchived || false,
      isTrash: c.isTrash || false,
      hasCustomTitle: c.hasCustomTitle || false,
      projectId: c.projectId,
      projectName: entity.name,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      messageCount: c.messageCount || 0,
      lastMessageSnippet: c.lastMessageSnippet,
    }));

    const project: ProjectItem = {
      id: entity.id,
      userId: entity.userId,
      name: entity.name,
      description: entity.description,
      contextBrief: entity.contextBrief || '',
      status: entity.status,
      isArchived: entity.isArchived,
      isTrash: entity.isTrash,
      conversationCount: conversations.length,
      conversations,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt || entity.createdAt,
    };

    const response: ProjectDetailApiResponse = { project, conversations };
    res.json(response);
  } catch (err: any) {
    console.error('Failed to get project detail:', err);
    res.status(500).json({ error: err?.message || 'Failed to retrieve project' });
  }
});

// PUT /api/projects/:id - Update project name, description, contextBrief, status, archived/trash
projectsRouter.put('/api/projects/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    if (!db.getProject || !db.saveProject) {
      res.status(500).json({ error: 'Project persistence not supported' });
      return;
    }

    const existing = await db.getProject(id);
    if (!existing) {
      res.status(404).json({ error: `Project ${id} not found` });
      return;
    }

    const body: ProjectUpdateApiRequest = req.body || {};
    const updated = await db.saveProject({
      ...existing,
      name: body.name !== undefined ? body.name.trim() : existing.name,
      description: body.description !== undefined ? body.description.trim() : existing.description,
      contextBrief: body.contextBrief !== undefined ? body.contextBrief.trim() : existing.contextBrief,
      status: body.status || (body.isArchived ? 'ARCHIVED' : existing.status),
      isArchived: body.isArchived !== undefined ? Boolean(body.isArchived) : existing.isArchived,
      isTrash: body.isTrash !== undefined ? Boolean(body.isTrash) : existing.isTrash,
      updatedAt: new Date().toISOString(),
    });

    const project: ProjectItem = {
      id: updated.id,
      userId: updated.userId,
      name: updated.name,
      description: updated.description,
      contextBrief: updated.contextBrief || '',
      status: updated.status,
      isArchived: updated.isArchived,
      isTrash: updated.isTrash,
      conversationCount: updated.conversationCount || 0,
      createdAt: updated.createdAt,
      updatedAt: updated.updatedAt || updated.createdAt,
    };

    res.json({ success: true, project });
  } catch (err: any) {
    console.error('Failed to update project:', err);
    res.status(500).json({ error: err?.message || 'Failed to update project' });
  }
});

// POST /api/projects/:id/restore - Restore a project from trash or archive
projectsRouter.post('/api/projects/:id/restore', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    if (!db.getProject || !db.saveProject) {
      res.status(500).json({ error: 'Project operations not supported' });
      return;
    }

    const existing = await db.getProject(id);
    if (!existing) {
      res.status(404).json({ error: `Project ${id} not found` });
      return;
    }

    const restored = await db.saveProject({
      ...existing,
      status: 'ACTIVE',
      isArchived: false,
      isTrash: false,
      updatedAt: new Date().toISOString(),
    });

    res.json({ success: true, project: restored });
  } catch (err: any) {
    console.error('Failed to restore project:', err);
    res.status(500).json({ error: err?.message || 'Failed to restore project' });
  }
});

// DELETE /api/projects/:id - Delete project (soft by default, permanent with ?permanent=true)
projectsRouter.delete('/api/projects/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const isPermanent = req.query.permanent === 'true';

    if (!db.deleteProject) {
      res.status(500).json({ error: 'deleteProject not supported' });
      return;
    }

    const deleted = isPermanent
      ? await db.deleteProject(id)
      : db.softDeleteProject
      ? await db.softDeleteProject(id)
      : await db.deleteProject(id);
    res.json({ success: deleted, deletedId: id, permanent: isPermanent });
  } catch (err: any) {
    console.error('Failed to delete project:', err);
    res.status(500).json({ error: err?.message || 'Failed to delete project' });
  }
});
