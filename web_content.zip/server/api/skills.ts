import { Request, Response, Router } from 'express';

import { skillRegistry } from '../skills/skillRegistry.ts';

export const skillsRouter = Router();

skillsRouter.get('/api/skills', (req: Request, res: Response) => {
  try {
    const skills = skillRegistry.getAllSkills();
    res.json({ skills });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to enumerate skills' });
  }
});
