import { Request, Response, Router } from 'express';

import { modelRouter } from '../models/modelRouter.ts';

export const modelsRouter = Router();

modelsRouter.get('/api/models', (req: Request, res: Response) => {
  try {
    const models = modelRouter.getModels();
    res.json({ models });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to enumerate models' });
  }
});

modelsRouter.get('/api/models/decisions', (req: Request, res: Response) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 20;
    const decisions = modelRouter.getRoutingDecisions(Number.isNaN(limit) ? 20 : limit);
    res.json({ decisions });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve model decisions' });
  }
});

modelsRouter.post('/api/models/test', async (req: Request, res: Response) => {
  try {
    const prompt = typeof req.body?.prompt === 'string' && req.body.prompt.trim()
      ? req.body.prompt.trim()
      : 'Ping JARVIS Model Router for status check.';
    const preferredModelId = req.body?.modelId as string | undefined;

    const response = await modelRouter.routeAndGenerate({
      prompt,
      systemInstruction: 'You are a test probe responding with a 1-sentence verification.',
      requiredCategory: (req.body?.category as any) || 'general',
      temperature: 0.1,
      maxTokens: 100,
    });

    res.json({
      success: true,
      response,
      decision: response.routingDecision,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err?.message || 'Model test execution failed',
      code: err?.code,
    });
  }
});
