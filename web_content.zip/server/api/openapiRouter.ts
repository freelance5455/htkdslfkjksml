/**
 * JARVIS OS OpenAPI 3.0.3 Specification Router
 * Provides machine-readable and human-downloadable API definitions for all JARVIS OS endpoints.
 */

import { Router } from 'express';
import type { Request, Response } from 'express';

export const openapiRouter = Router();

export const JARVIS_OPENAPI_SPEC = {
  openapi: '3.0.3',
  info: {
    title: 'JARVIS Personal Autonomous AI Operating System API',
    version: '5.1.0',
    description:
      'High-performance, sovereign REST and SSE API for JARVIS 5.1. Provides conversational intelligence, autonomous task execution, model routing, file sandboxing, PDF intelligence, document generation, and memory persistence.',
    contact: {
      name: 'Aaradhy Parmar (Founder & Architect)',
      url: 'https://github.com/aaradhyparmar/jarvis-os',
    },
    license: {
      name: 'Proprietary / Sovereign Personal OS License',
    },
  },
  servers: [
    {
      url: '/',
      description: 'Local Container / Standard Deployment Host',
    },
  ],
  paths: {
    '/api/status': {
      get: {
        summary: 'System Status & Diagnostics',
        description: 'Returns real-time operating metrics, uptime, active model provider, and database health.',
        responses: {
          '200': {
            description: 'JARVIS System Status Payload',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: { type: 'string', example: 'ONLINE' },
                    version: { type: 'string', example: '5.1.0' },
                    uptimeSeconds: { type: 'number', example: 1420 },
                    activeModel: { type: 'string', example: 'gemini-2.5-flash' },
                    dbStatus: { type: 'string', example: 'HEALTHY' },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/api/health': {
      get: {
        summary: 'Comprehensive Health Check',
        description: 'Checks core subsystems, memory subsystem, database, and sub-agents.',
        responses: {
          '200': {
            description: 'System health report',
          },
        },
      },
    },
    '/api/chat': {
      post: {
        summary: 'Execute Chat Query or Autonomous Command',
        description: 'Primary conversational endpoint running the 11-stage autonomous agentic core loop.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['prompt'],
                properties: {
                  prompt: { type: 'string', description: 'User command or prompt' },
                  conversationId: { type: 'string', default: 'conv_default' },
                  userId: { type: 'string', default: 'usr_jarvis_prime' },
                },
              },
            },
          },
        },
        responses: {
          '200': {
            description: 'Autonomous execution result and assistant response message',
          },
          '400': { description: 'Missing required prompt' },
          '429': { description: 'Rate limit exceeded' },
        },
      },
    },
    '/api/files/upload': {
      post: {
        summary: 'Upload & Parse Workspace File',
        description: 'Accepts base64 file payloads, verifies mime types, stores in data/uploads/, and extracts text streams.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['originalName', 'mimeType', 'base64Data'],
                properties: {
                  originalName: { type: 'string' },
                  mimeType: { type: 'string' },
                  base64Data: { type: 'string' },
                  conversationId: { type: 'string' },
                  projectId: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          '201': { description: 'File uploaded and parsed successfully' },
          '400': { description: 'Invalid upload parameters' },
        },
      },
    },
    '/api/files': {
      get: {
        summary: 'List Attached Files',
        parameters: [
          { name: 'conversationId', in: 'query', schema: { type: 'string' } },
          { name: 'projectId', in: 'query', schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'List of file attachment entities' },
        },
      },
    },
    '/api/files/{id}/download': {
      get: {
        summary: 'Download File Binary',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'Binary stream of uploaded file' },
          '404': { description: 'File not found' },
        },
      },
    },
    '/api/documents/generate': {
      post: {
        summary: 'Generate Structured Document (PDF 1.4, Markdown, TXT, JSON)',
        description: 'Creates real byte-level downloadable documents and valid PDF-1.4 specifications.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['title', 'format', 'content'],
                properties: {
                  title: { type: 'string' },
                  format: { type: 'string', enum: ['pdf', 'md', 'txt', 'json'] },
                  content: { type: 'string' },
                  conversationId: { type: 'string' },
                  projectId: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          '201': { description: 'Document generated and saved to data/documents/' },
          '400': { description: 'Invalid parameters' },
        },
      },
    },
    '/api/documents/{id}/download': {
      get: {
        summary: 'Download Generated Document',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'Document binary' },
          '404': { description: 'Document not found' },
        },
      },
    },
    '/api/tools': {
      get: {
        summary: 'List Registered System Tools',
        responses: {
          '200': { description: 'Array of registered system and agentic tools' },
        },
      },
    },
    '/api/models': {
      get: {
        summary: 'List Configured Model Providers & Target Catalog',
        responses: {
          '200': { description: 'Model catalog and active fallback chain' },
        },
      },
    },
    '/api/memory': {
      get: {
        summary: 'Retrieve Long-Term Memories',
        parameters: [
          { name: 'query', in: 'query', schema: { type: 'string' } },
          { name: 'type', in: 'query', schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'Matched memory records' },
        },
      },
      post: {
        summary: 'Store New Long-Term Memory',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['key', 'content'],
                properties: {
                  key: { type: 'string' },
                  content: { type: 'string' },
                  type: { type: 'string', default: 'knowledge' },
                  importance: { type: 'number', default: 5 },
                },
              },
            },
          },
        },
        responses: {
          '201': { description: 'Memory stored' },
        },
      },
    },
    '/api/security/audit': {
      get: {
        summary: 'Security Audit Logs & Pending Permission Requests',
        responses: {
          '200': { description: 'Security audit events' },
        },
      },
    },
    '/api/openapi.json': {
      get: {
        summary: 'OpenAPI Specification JSON',
        responses: {
          '200': { description: 'OpenAPI 3.0 specification' },
        },
      },
    },
  },
};

// 1. Return raw OpenAPI JSON
openapiRouter.get('/api/openapi.json', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  return res.json(JARVIS_OPENAPI_SPEC);
});

// 2. Downloadable OpenAPI Specification file
openapiRouter.get('/api/docs/download', (req: Request, res: Response) => {
  const jsonStr = JSON.stringify(JARVIS_OPENAPI_SPEC, null, 2);
  const buffer = Buffer.from(jsonStr, 'utf-8');
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="jarvis_openapi_5.1.0.json"');
  res.setHeader('Content-Length', buffer.length);
  return res.send(buffer);
});
