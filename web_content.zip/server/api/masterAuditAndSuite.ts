/**
 * JARVIS Master Audit & Capability Suite Router
 * API endpoints exposing:
 * - 407-Outcome Audit Engine (/api/audit/outcomes-407)
 * - Real Media Generation (/api/media/*)
 * - Autonomous Code & Website Generation (/api/code/*)
 * - Multi-Cloud Deployment Scaffolding (/api/deploy/*)
 * - DAG Workflows & Automation (/api/workflows/*)
 * - Android Companion & Screen Bridge (/api/android/*)
 * - Social Media Gateway (/api/social/*)
 * - System Backup & Upgrade (/api/system/*)
 */

import { Router } from 'express';
import { outcomeAuditEngine } from '../verification/outcomeAudit.ts';
import { mediaEngine } from '../media/mediaEngine.ts';
import { codingEngine } from '../code/codingAgent.ts';
import { websiteGenerator } from '../code/websiteGenerator.ts';
import { appGenerator } from '../code/appGenerator.ts';
import { deploymentEngine } from '../deploy/deploymentEngine.ts';
import { workflowEngine } from '../automation/workflowEngine.ts';
import { androidCompanion } from '../android/androidCompanion.ts';
import { socialMediaIntegrator } from '../social/socialMediaIntegrator.ts';
import { systemManager } from '../system/systemManager.ts';
import { multiDeviceManager } from '../devices/multiDeviceManager.ts';
import { db } from '../db/database.ts';

export const masterAuditAndSuiteRouter = Router();

// --- 407 Outcome Audit Endpoints ---
masterAuditAndSuiteRouter.get('/api/audit/outcomes-407', (req, res) => {
  try {
    const { category, status, search } = req.query as {
      category?: string;
      status?: any;
      search?: string;
    };

    const summary = outcomeAuditEngine.getSummary();
    const outcomes = outcomeAuditEngine.filterOutcomes({ category, status, search });
    const categories = outcomeAuditEngine.getCategories();

    res.json({
      success: true,
      summary,
      count: outcomes.length,
      categories,
      outcomes,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Audit query failed' });
  }
});

// --- Media Generation Endpoints ---
masterAuditAndSuiteRouter.post('/api/media/generate-image', async (req, res) => {
  try {
    const { prompt, aspectRatio, style, negativePrompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ success: false, error: 'Prompt is required' });
    }
    const result = await mediaEngine.generateImage({ prompt, aspectRatio, style, negativePrompt });
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Image generation failed' });
  }
});

masterAuditAndSuiteRouter.post('/api/media/orchestrate-video', async (req, res) => {
  try {
    const { prompt, durationSeconds, aspectRatio, providerPreference } = req.body;
    if (!prompt) {
      return res.status(400).json({ success: false, error: 'Prompt is required' });
    }
    const result = await mediaEngine.orchestrateVideo({
      prompt,
      durationSeconds,
      aspectRatio,
      providerPreference,
    });
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Video orchestration failed' });
  }
});

// --- Code & Website Generation Endpoints ---
masterAuditAndSuiteRouter.post('/api/code/generate', async (req, res) => {
  try {
    const { objective, language, framework, includeTests } = req.body;
    if (!objective) {
      return res.status(400).json({ success: false, error: 'Objective is required' });
    }
    const result = await codingEngine.generateCodeProject({ objective, language, framework, includeTests });
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Code generation failed' });
  }
});

masterAuditAndSuiteRouter.post('/api/code/website', (req, res) => {
  try {
    const { title, theme, description, features, ctaText } = req.body;
    if (!title || !description) {
      return res.status(400).json({ success: false, error: 'Title and description are required' });
    }
    const result = websiteGenerator.generateWebsite({ title, theme, description, features, ctaText });
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Website generation failed' });
  }
});

masterAuditAndSuiteRouter.post('/api/code/app', (req, res) => {
  try {
    const { appName, architecture, description } = req.body;
    if (!appName || !description) {
      return res.status(400).json({ success: false, error: 'appName and description are required' });
    }
    const result = appGenerator.scaffoldApp({ appName, architecture, description });
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'App scaffolding failed' });
  }
});

// --- Deployment Endpoints ---
masterAuditAndSuiteRouter.get('/api/deploy/targets', (req, res) => {
  try {
    const targets = deploymentEngine.getAvailableTargets();
    res.json({ success: true, targets });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

masterAuditAndSuiteRouter.post('/api/deploy/scaffold', (req, res) => {
  try {
    const { target } = req.body;
    if (!target) {
      return res.status(400).json({ success: false, error: 'Target is required' });
    }
    const result = deploymentEngine.scaffoldDeployConfig(target);
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// --- Workflow & Automation Endpoints ---
masterAuditAndSuiteRouter.get('/api/workflows', (req, res) => {
  try {
    const workflows = workflowEngine.getWorkflows();
    const runs = workflowEngine.getAllRuns();
    res.json({ success: true, workflows, runs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

masterAuditAndSuiteRouter.post('/api/workflows/execute/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const run = await workflowEngine.executeWorkflow(id);
    res.json({ success: true, run });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Workflow execution failed' });
  }
});

// --- Android Companion & Device Endpoints ---
masterAuditAndSuiteRouter.get('/api/android/companion/status', (req, res) => {
  try {
    const contracts = androidCompanion.getArchitecturalContracts();
    const screenAwareness = androidCompanion.getScreenAwarenessStatus();
    const pairedDevices = androidCompanion.getPairedDevices();
    res.json({ success: true, contracts, screenAwareness, pairedDevices });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

masterAuditAndSuiteRouter.post('/api/android/companion/command', (req, res) => {
  try {
    const { action, params } = req.body;
    const result = androidCompanion.executeDeviceCommand({ action, params, requiresPhysicalBridge: true });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// --- Multi-Device Endpoints ---
masterAuditAndSuiteRouter.get('/api/devices', (req, res) => {
  try {
    const devices = multiDeviceManager.getDevices();
    res.json({ success: true, devices });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// --- Social Media Gateway Endpoints ---
masterAuditAndSuiteRouter.get('/api/social/status', (req, res) => {
  try {
    const platforms = socialMediaIntegrator.getPlatformStatuses();
    const drafts = socialMediaIntegrator.getDrafts();
    res.json({ success: true, platforms, drafts });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

masterAuditAndSuiteRouter.post('/api/social/draft', (req, res) => {
  try {
    const { platform, text } = req.body;
    if (!platform || !text) {
      return res.status(400).json({ success: false, error: 'Platform and text are required' });
    }
    const draft = socialMediaIntegrator.createDraft(platform, text);
    res.json({ success: true, draft });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// --- System Backup & Upgrade Endpoints ---
masterAuditAndSuiteRouter.post('/api/system/backup', async (req, res) => {
  try {
    const convs = await db.getConversations('usr_jarvis_prime');
    const mems = await db.getMemories();
    const projs = await db.getProjects('usr_jarvis_prime');
    const logs = db.getAuditLogs ? await db.getAuditLogs(100) : [];

    const snapshot = systemManager.generateSnapshot({
      conversationsCount: convs.length,
      memoriesCount: mems.length,
      projectsCount: projs.length,
      auditLogsCount: logs.length,
      conversations: convs,
      memories: mems,
      projects: projs,
    });

    res.json({ success: true, snapshot });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

masterAuditAndSuiteRouter.get('/api/system/upgrade', (req, res) => {
  try {
    const candidate = systemManager.checkUpgradeCandidates();
    res.json({ success: true, candidate });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});
