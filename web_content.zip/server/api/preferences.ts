import { Request, Response, Router } from 'express';
import { preferenceSystem } from '../memory/preferenceSystem.ts';

export const preferencesRouter = Router();

preferencesRouter.get('/api/preferences', async (req: Request, res: Response) => {
  try {
    const userId = (req.query.userId as string) || 'usr_jarvis_prime';
    const prefs = await preferenceSystem.getPreferences(userId);
    res.json({ success: true, preferences: prefs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to fetch preferences' });
  }
});

preferencesRouter.post('/api/preferences', async (req: Request, res: Response) => {
  try {
    const userId = req.body?.userId || 'usr_jarvis_prime';
    const { key, value } = req.body;

    if (!key || typeof key !== 'string') {
      res.status(400).json({ success: false, error: 'Preference key is required' });
      return;
    }

    if (value === undefined || value === null) {
      await preferenceSystem.deletePreference(key, userId);
    } else {
      await preferenceSystem.setPreference(key, String(value), userId);
    }

    const updated = await preferenceSystem.getPreferences(userId);
    res.json({ success: true, preferences: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to update preference' });
  }
});

preferencesRouter.delete('/api/preferences/:key', async (req: Request, res: Response) => {
  try {
    const userId = (req.query.userId as string) || 'usr_jarvis_prime';
    const { key } = req.params;
    await preferenceSystem.deletePreference(key, userId);
    const updated = await preferenceSystem.getPreferences(userId);
    res.json({ success: true, preferences: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to delete preference' });
  }
});
