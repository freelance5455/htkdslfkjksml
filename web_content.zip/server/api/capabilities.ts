import { Request, Response, Router } from 'express';
import { capabilityRegistry } from '../capabilities/capabilityRegistry.ts';
import { IntentClassifier } from '../planner/intentClassifier.ts';

export const capabilitiesRouter = Router();

capabilitiesRouter.get('/api/capabilities', (req: Request, res: Response) => {
  try {
    const category = req.query.category as string | undefined;
    const capabilities = category
      ? capabilityRegistry.getByCategory(category as any)
      : capabilityRegistry.getAll();
    res.json({ success: true, capabilities });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to list capabilities' });
  }
});

capabilitiesRouter.post('/api/capabilities/discover', (req: Request, res: Response) => {
  try {
    const { prompt, features } = req.body;

    if (Array.isArray(features)) {
      const discovered = capabilityRegistry.discoverCapabilities(features);
      res.json({ success: true, capabilities: discovered });
      return;
    }

    if (typeof prompt === 'string') {
      const intent = IntentClassifier.analyze({ prompt });
      res.json({
        success: true,
        intent,
        capabilities: intent.requiredCapabilities,
      });
      return;
    }

    res.status(400).json({ success: false, error: 'Either prompt string or features array is required' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Capability discovery failed' });
  }
});
