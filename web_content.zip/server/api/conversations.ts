/**
 * JARVIS Multi-Chat Conversation Workspace Router
 * CRUD operations for isolated conversations, topics, projects, search, and message histories.
 */

import { Request, Response, Router } from 'express';
import { db } from '../db/database.ts';
import type {
  ConversationCreateApiRequest,
  ConversationDetailApiResponse,
  ConversationItem,
  ConversationSearchApiResponse,
  ConversationsListApiResponse,
  ConversationUpdateApiRequest,
} from '../types.ts';

export const conversationsRouter = Router();

const DEFAULT_USER_ID = 'usr_jarvis_prime';

// GET /api/conversations/search - Search conversations by title, topic, or message snippet
conversationsRouter.get('/api/conversations/search', async (req: Request, res: Response) => {
  try {
    const query = ((req.query.q as string) || '').trim();
    const projectId = (req.query.projectId as string) || undefined;
    const includeArchived = req.query.includeArchived === 'true';

    if (!db.searchConversations) {
      res.status(500).json({ error: 'Search not supported by database engine' });
      return;
    }

    const matches = await db.searchConversations(DEFAULT_USER_ID, query, {
      projectId,
      includeArchived,
    });

    const conversations = matches.map((c) => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      topic: c.topic || 'General',
      isArchived: c.isArchived || false,
      isTrash: c.isTrash || false,
      hasCustomTitle: c.hasCustomTitle || false,
      projectId: c.projectId,
      projectName: (c as any).projectName,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      messageCount: c.messageCount || 0,
      matchedSnippet: c.matchedSnippet,
      lastMessageSnippet: c.lastMessageSnippet,
    }));

    const response: ConversationSearchApiResponse = {
      query,
      totalFound: conversations.length,
      conversations,
    };
    res.json(response);
  } catch (err: any) {
    console.error('Failed to search conversations:', err);
    res.status(500).json({ error: err?.message || 'Failed to search conversations' });
  }
});

// GET /api/conversations - List conversations with metadata, project filtering, and archive/trash flags
conversationsRouter.get('/api/conversations', async (req: Request, res: Response) => {
  try {
    const projectId = (req.query.projectId as string) || undefined;
    const includeArchived = req.query.includeArchived === 'true';
    const includeTrash = req.query.includeTrash === 'true';
    const isTrashOnly = req.query.isTrashOnly === 'true';

    const rawConvs = await db.getConversations(DEFAULT_USER_ID, {
      projectId,
      includeArchived,
      includeTrash,
      isTrashOnly,
    });

    const conversations: ConversationItem[] = rawConvs.map((c) => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      topic: c.topic || 'General',
      isArchived: c.isArchived || false,
      isTrash: c.isTrash || false,
      hasCustomTitle: c.hasCustomTitle || false,
      projectId: c.projectId,
      projectName: (c as any).projectName,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      messageCount: c.messageCount || 0,
      lastMessageSnippet: c.lastMessageSnippet,
    }));

    const response: ConversationsListApiResponse = { conversations };
    res.json(response);
  } catch (err: any) {
    console.error('Failed to list conversations:', err);
    res.status(500).json({ error: err?.message || 'Failed to list conversations' });
  }
});

// POST /api/conversations - Create a new isolated conversation
conversationsRouter.post('/api/conversations', async (req: Request, res: Response) => {
  try {
    const body: ConversationCreateApiRequest = req.body || {};
    const title = (body.title || '').trim() || 'New Session';
    const topic = (body.topic || 'General').trim();
    const projectId = body.projectId ? body.projectId.trim() : undefined;
    const now = new Date().toISOString();

    const id = `conv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newConv = await db.saveConversation({
      id,
      userId: DEFAULT_USER_ID,
      title,
      topic,
      isArchived: false,
      isTrash: false,
      hasCustomTitle: Boolean(body.title && body.title.trim() !== 'New Session'),
      projectId,
      createdAt: now,
      updatedAt: now,
    });

    // Lookup project name if assigned
    let projectName: string | undefined;
    if (projectId && db.getProject) {
      const proj = await db.getProject(projectId);
      if (proj) projectName = proj.name;
    }

    const item: ConversationItem = {
      id: newConv.id,
      userId: newConv.userId,
      title: newConv.title,
      topic: newConv.topic || 'General',
      isArchived: false,
      isTrash: false,
      hasCustomTitle: newConv.hasCustomTitle || false,
      projectId: newConv.projectId,
      projectName,
      createdAt: newConv.createdAt,
      updatedAt: newConv.updatedAt,
      messageCount: 0,
    };

    res.status(201).json({ success: true, conversation: item });
  } catch (err: any) {
    console.error('Failed to create conversation:', err);
    res.status(500).json({ error: err?.message || 'Failed to create conversation' });
  }
});

// GET /api/conversations/:id - Retrieve conversation and its isolated messages
conversationsRouter.get('/api/conversations/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const conv = await db.getConversation(id);
    if (!conv) {
      res.status(404).json({ error: `Conversation ${id} not found` });
      return;
    }

    const messages = await db.getMessages(id);
    const item: ConversationItem = {
      id: conv.id,
      userId: conv.userId,
      title: conv.title,
      topic: conv.topic || 'General',
      isArchived: conv.isArchived || false,
      isTrash: conv.isTrash || false,
      hasCustomTitle: conv.hasCustomTitle || false,
      projectId: conv.projectId,
      projectName: (conv as any).projectName,
      createdAt: conv.createdAt,
      updatedAt: conv.updatedAt,
      messageCount: messages.length,
      lastMessageSnippet: messages.length > 0 ? messages[messages.length - 1].content.slice(0, 100) : undefined,
    };

    const response: ConversationDetailApiResponse = {
      conversation: item,
      messages,
    };
    res.json(response);
  } catch (err: any) {
    console.error('Failed to get conversation:', err);
    res.status(500).json({ error: err?.message || 'Failed to retrieve conversation' });
  }
});

// PUT /api/conversations/:id - Rename, change topic, move/remove project, or archive/trash
conversationsRouter.put('/api/conversations/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const body: ConversationUpdateApiRequest = req.body || {};
    const existing = await db.getConversation(id);
    if (!existing) {
      res.status(404).json({ error: `Conversation ${id} not found` });
      return;
    }

    const isRenaming = body.title !== undefined && body.title.trim() !== existing.title;
    const hasCustomTitle = isRenaming ? true : (body.hasCustomTitle !== undefined ? Boolean(body.hasCustomTitle) : existing.hasCustomTitle);

    let updatedProjectId = existing.projectId;
    if (body.projectId !== undefined) {
      updatedProjectId = body.projectId === null || body.projectId === '' ? undefined : body.projectId;
    }

    const updated = await db.saveConversation({
      ...existing,
      title: body.title !== undefined ? body.title.trim() : existing.title,
      topic: body.topic !== undefined ? body.topic.trim() : (existing.topic || 'General'),
      isArchived: body.isArchived !== undefined ? Boolean(body.isArchived) : existing.isArchived,
      isTrash: body.isTrash !== undefined ? Boolean(body.isTrash) : existing.isTrash,
      hasCustomTitle,
      projectId: updatedProjectId,
      updatedAt: new Date().toISOString(),
    });

    const msgs = await db.getMessages(id);
    const item: ConversationItem = {
      id: updated.id,
      userId: updated.userId,
      title: updated.title,
      topic: updated.topic || 'General',
      isArchived: updated.isArchived || false,
      isTrash: updated.isTrash || false,
      hasCustomTitle: updated.hasCustomTitle || false,
      projectId: updated.projectId,
      projectName: (updated as any).projectName,
      createdAt: updated.createdAt,
      updatedAt: updated.updatedAt,
      messageCount: msgs.length,
      lastMessageSnippet: msgs.length > 0 ? msgs[msgs.length - 1].content.slice(0, 100) : undefined,
    };

    res.json({ success: true, conversation: item });
  } catch (err: any) {
    console.error('Failed to update conversation:', err);
    res.status(500).json({ error: err?.message || 'Failed to update conversation' });
  }
});

// POST /api/conversations/:id/restore - Restore a conversation from trash or archive
conversationsRouter.post('/api/conversations/:id/restore', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    if (db.restoreConversation) {
      await db.restoreConversation(id);
    } else {
      const existing = await db.getConversation(id);
      if (existing) {
        await db.saveConversation({
          ...existing,
          isTrash: false,
          isArchived: false,
          updatedAt: new Date().toISOString(),
        });
      }
    }

    const restored = await db.getConversation(id);
    res.json({ success: true, conversation: restored });
  } catch (err: any) {
    console.error('Failed to restore conversation:', err);
    res.status(500).json({ error: err?.message || 'Failed to restore conversation' });
  }
});

// DELETE /api/conversations/:id - Soft-delete (move to trash) by default, permanent with ?permanent=true
conversationsRouter.delete('/api/conversations/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const isPermanent = req.query.permanent === 'true';

    const existing = await db.getConversation(id);
    if (!existing) {
      res.status(404).json({ error: `Conversation ${id} not found` });
      return;
    }

    if (isPermanent) {
      const deleted = await db.deleteConversation(id);
      res.json({ success: deleted, deletedId: id, permanent: true });
    } else {
      if (db.softDeleteConversation) {
        await db.softDeleteConversation(id);
      } else {
        await db.saveConversation({
          ...existing,
          isTrash: true,
          updatedAt: new Date().toISOString(),
        });
      }
      res.json({ success: true, deletedId: id, permanent: false });
    }
  } catch (err: any) {
    console.error('Failed to delete conversation:', err);
    res.status(500).json({ error: err?.message || 'Failed to delete conversation' });
  }
});
