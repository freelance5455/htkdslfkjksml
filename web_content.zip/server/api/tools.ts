import { Request, Response, Router } from 'express';

import { toolRegistry } from '../tools/toolRegistry.ts';

export const toolsRouter = Router();

toolsRouter.get('/api/tools', (req: Request, res: Response) => {
  try {
    const tools = toolRegistry.getAllDefinitions();
    res.json({ tools });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to enumerate tools' });
  }
});

toolsRouter.post('/api/tools/execute', async (req: Request, res: Response) => {
  try {
    const { toolName, parameters, params } = req.body;
    const toolParams = parameters !== undefined ? parameters : params;
    if (!toolName) {
      res.status(400).json({ error: 'toolName is required' });
      return;
    }
    const result = await toolRegistry.executeTool(toolName, toolParams, { userId: 'usr_jarvis_prime' });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to execute tool' });
  }
});
