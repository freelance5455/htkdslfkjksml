import { Request, Response, Router } from 'express';

import { memorySystem } from '../memory/memorySystem.ts';

export const memoryRouter = Router();

memoryRouter.get('/api/memory', async (req: Request, res: Response) => {
  try {
    const type = req.query.type as any;
    const text = (req.query.text || req.query.query) as string;
    const memories = await memorySystem.retrieve({ type, text, limit: 50 });
    res.json({ memories });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve memories' });
  }
});

memoryRouter.post('/api/memory', async (req: Request, res: Response) => {
  try {
    const { key, content, type, importance, tags } = req.body;
    if (!key || !content) {
      res.status(400).json({ error: 'key and content are required' });
      return;
    }

    const saved = await memorySystem.store({
      userId: 'usr_jarvis_prime',
      type: type || 'knowledge',
      key,
      content,
      importance: Number(importance) || 5,
      tags: Array.isArray(tags) ? tags : [],
    });

    res.json({ success: true, memory: saved });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to save memory' });
  }
});

memoryRouter.delete('/api/memory/:id', async (req: Request, res: Response) => {
  try {
    const success = await memorySystem.delete(req.params.id);
    res.json({ success });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to delete memory' });
  }
});
