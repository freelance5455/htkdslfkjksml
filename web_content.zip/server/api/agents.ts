import { Request, Response, Router } from 'express';

import { agentCoordinator } from '../agents/agentSystem.ts';

export const agentsRouter = Router();

agentsRouter.get('/api/agents', (req: Request, res: Response) => {
  try {
    const agents = agentCoordinator.getAllAgents();
    const messages = agentCoordinator.getMessageHistory();
    res.json({ agents, recentMessages: messages });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to enumerate agents' });
  }
});
