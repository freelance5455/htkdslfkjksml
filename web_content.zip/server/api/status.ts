import { Request, Response, Router } from 'express';

import { agentCoordinator } from '../agents/agentSystem.ts';
import { config, getSanitizedConfig } from '../config/index.ts';
import { db } from '../db/database.ts';
import { modelRouter } from '../models/modelRouter.ts';
import { securityLayer } from '../security/securityLayer.ts';
import { skillRegistry } from '../skills/skillRegistry.ts';
import { toolRegistry } from '../tools/toolRegistry.ts';

export const statusRouter = Router();

const healthHandler = (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    system: 'JARVIS AI Operating System',
    assistantIdentity: 'JARVIS 5.1',
    version: '5.1.0',
    environment: config.runtime.nodeEnv,
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
};

statusRouter.get('/health', healthHandler);
statusRouter.get('/api/health', healthHandler);

const configHandler = (req: Request, res: Response) => {
  res.json(getSanitizedConfig());
};

statusRouter.get('/config', configHandler);
statusRouter.get('/api/config', configHandler);
statusRouter.get('/config/diagnostics', configHandler);
statusRouter.get('/api/config/diagnostics', configHandler);

statusRouter.get('/api/status', async (req: Request, res: Response) => {
  try {
    const models = modelRouter.getModels();
    const tools = toolRegistry.getAllDefinitions();
    const skills = skillRegistry.getAllSkills();
    const agents = agentCoordinator.getAllAgents();
    const tasks = await db.getTasks();
    const pendingPermissions = securityLayer.getPendingRequests();
    const dbHealth = await db.getHealth();

    res.json({
      system: 'JARVIS OS',
      assistantIdentity: 'JARVIS 5.1',
      version: '5.1.0',
      operationalStatus: 'HEALTHY',
      coreLoop: 'STANDBY_READY',
      environment: config.runtime.nodeEnv,
      database: dbHealth,
      activeAgentsCount: agents.length,
      registeredToolsCount: tools.length,
      registeredSkillsCount: skills.length,
      modelsConfiguredCount: models.length,
      totalTasksExecuted: tasks.length,
      pendingAuthorizationsCount: pendingPermissions.length,
      memoryUsageRssMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      hasGeminiApiKey: config.models.hasGeminiApiKey,
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to get system status' });
  }
});
