import { Request, Response, Router } from 'express';

import { jarvisCore } from '../core/jarvisCore.ts';
import { db } from '../db/database.ts';

export const tasksRouter = Router();

tasksRouter.get('/api/tasks', async (req: Request, res: Response) => {
  try {
    const tasks = await db.getTasks();
    res.json({ tasks });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve tasks' });
  }
});

tasksRouter.get('/api/tasks/:id', async (req: Request, res: Response) => {
  try {
    const task = await db.getTask(req.params.id);
    if (!task) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }
    res.json({ task });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve task' });
  }
});

tasksRouter.post('/api/tasks', async (req: Request, res: Response) => {
  try {
    const { goal } = req.body;
    if (!goal) {
      res.status(400).json({ error: 'Task goal is required' });
      return;
    }
    const result = await jarvisCore.executeTask(goal);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to create and execute task' });
  }
});

tasksRouter.post('/api/tasks/:id/approve', async (req: Request, res: Response) => {
  try {
    const updatedTask = await jarvisCore.approveAndResumeTask(req.params.id);
    if (!updatedTask) {
      res.status(404).json({ error: 'Task not pending approval or not found' });
      return;
    }
    res.json({ success: true, task: updatedTask });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to approve task' });
  }
});

tasksRouter.post('/api/tasks/:id/reject', async (req: Request, res: Response) => {
  try {
    const { reason } = req.body;
    const updatedTask = await jarvisCore.rejectTask(req.params.id, reason);
    if (!updatedTask) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }
    res.json({ success: true, task: updatedTask });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to reject task' });
  }
});
