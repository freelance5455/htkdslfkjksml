import { Router } from 'express';

import { agentsRouter } from './agents.ts';
import { capabilitiesRouter } from './capabilities.ts';
import { chatRouter } from './chat.ts';
import { conversationsRouter } from './conversations.ts';
import { databaseRouter } from './database.ts';
import { documentsRouter } from './documentsRouter.ts';
import { eventsRouter } from './events.ts';
import { filesRouter } from './filesRouter.ts';
import { memoryRouter } from './memory.ts';
import { modelsRouter } from './models.ts';
import { openapiRouter } from './openapiRouter.ts';
import { preferencesRouter } from './preferences.ts';
import { projectsRouter } from './projects.ts';
import { securityRouter } from './security.ts';
import { skillsRouter } from './skills.ts';
import { statusRouter } from './status.ts';
import { tasksRouter } from './tasks.ts';
import { toolsRouter } from './tools.ts';
import { versionAndDiscoveryRouter } from './versionAndDiscovery.ts';
import { masterAuditAndSuiteRouter } from './masterAuditAndSuite.ts';
import { websitesRouter } from './websitesRouter.ts';
import { mediaRouter } from './mediaRouter.ts';

export const apiRouter = Router();

// Mount all modular domain routers
apiRouter.use(statusRouter);
apiRouter.use(databaseRouter);
apiRouter.use(conversationsRouter);
apiRouter.use(projectsRouter);
apiRouter.use(chatRouter);
apiRouter.use(mediaRouter);
apiRouter.use('/api/files', filesRouter);
apiRouter.use('/api/documents', documentsRouter);
apiRouter.use('/api/websites', websitesRouter);
apiRouter.use(openapiRouter);
apiRouter.use(masterAuditAndSuiteRouter);
apiRouter.use(tasksRouter);
apiRouter.use(memoryRouter);
apiRouter.use(toolsRouter);
apiRouter.use(skillsRouter);
apiRouter.use(modelsRouter);
apiRouter.use(agentsRouter);
apiRouter.use(securityRouter);
apiRouter.use(eventsRouter);
apiRouter.use(capabilitiesRouter);
apiRouter.use(preferencesRouter);
apiRouter.use(versionAndDiscoveryRouter);

export {
  agentsRouter,
  capabilitiesRouter,
  chatRouter,
  conversationsRouter,
  databaseRouter,
  documentsRouter,
  eventsRouter,
  filesRouter,
  memoryRouter,
  modelsRouter,
  openapiRouter,
  preferencesRouter,
  projectsRouter,
  securityRouter,
  skillsRouter,
  statusRouter,
  tasksRouter,
  toolsRouter,
  versionAndDiscoveryRouter,
};
