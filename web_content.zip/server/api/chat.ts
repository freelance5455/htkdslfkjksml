import { Request, Response, Router } from 'express';

import { jarvisCore } from '../core/jarvisCore.ts';
import { db } from '../db/database.ts';
import { securityLayer } from '../security/securityLayer.ts';

export const chatRouter = Router();

const handleExecution = async (req: Request, res: Response) => {
  try {
    const rawInput = req.body?.prompt || req.body?.command || req.body?.goal;
    const conversationId = req.body?.conversationId || 'conv_default';

    if (!rawInput || typeof rawInput !== 'string') {
      res.status(400).json({ error: 'Command or prompt string is required' });
      return;
    }

    // Check rate limits
    const ip = req.ip || 'anonymous';
    if (!securityLayer.checkRateLimit(ip)) {
      res.status(429).json({ error: 'Rate limit exceeded. Please wait a moment.' });
      return;
    }

    const sanitizedPrompt = securityLayer.sanitizeInput(rawInput);
    const result = await jarvisCore.executeTask(
      sanitizedPrompt,
      'usr_jarvis_prime',
      conversationId
    );

    res.json({
      success: true,
      task: result.task,
      message: result.assistantMessage,
    });
  } catch (err: any) {
    console.error('Command/Chat endpoint execution failed:', err);
    res.status(500).json({ error: err?.message || 'Failed to process task in JARVIS Core' });
  }
};

chatRouter.post('/api/chat', handleExecution);
chatRouter.post('/api/command', handleExecution);

chatRouter.get('/api/chat/messages', async (req: Request, res: Response) => {
  try {
    const convId = (req.query.conversationId as string) || 'conv_default';
    const messages = await db.getMessages(convId);
    res.json({ messages });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to retrieve messages' });
  }
});
