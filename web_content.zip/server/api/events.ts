import { Request, Response, Router } from 'express';

import { jarvisCore } from '../core/jarvisCore.ts';
import type { SystemEvent } from '../types.ts';

export const eventsRouter = Router();

eventsRouter.get('/api/events', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  // Send initial keepalive
  try {
    res.write(`data: ${JSON.stringify({ type: 'INIT', message: 'SSE Stream Connected' })}\n\n`);
  } catch {
    return;
  }

  const unsubscribe = jarvisCore.addEventListener((event: SystemEvent) => {
    if (!res.writableEnded && !res.destroyed) {
      try {
        res.write(`data: ${JSON.stringify(event)}\n\n`);
      } catch {
        unsubscribe();
      }
    }
  });

  req.on('close', () => {
    unsubscribe();
  });
});
