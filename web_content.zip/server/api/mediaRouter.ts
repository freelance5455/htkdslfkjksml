/**
 * JARVIS Media, Film Studio & Autonomous Upgrade API Router
 * Endpoints for AI Short Film Studio, Video Jobs, Code Debugging, and Self-Upgrade Engine.
 */

import { Router, Request, Response } from 'express';
import { shortFilmStudio } from '../media/shortFilmStudio.ts';
import { mediaEngine } from '../media/mediaEngine.ts';
import { selfUpgradeEngine } from '../system/selfUpgradeEngine.ts';
import { codingEngine } from '../code/codingAgent.ts';

export const mediaRouter = Router();

/**
 * AI Short Film Studio: Create new film package
 */
mediaRouter.post('/api/media/film/create', async (req: Request, res: Response) => {
  try {
    const { prompt, title, genre, targetDuration, aspectRatio, language, tone } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'prompt is required for film creation' });
    }

    const filmPackage = await shortFilmStudio.createShortFilm({
      prompt,
      title,
      genre,
      targetDuration: targetDuration || '10m',
      aspectRatio: aspectRatio || '16:9',
      language: language || 'en',
      tone,
    });

    res.json({ success: true, filmPackage });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Film creation failed' });
  }
});

/**
 * AI Short Film Studio: List all film packages
 */
mediaRouter.get(['/api/media/film/projects', '/api/film-studio/projects'], (req: Request, res: Response) => {
  const projects = shortFilmStudio.listFilmProjects();
  res.json({ success: true, count: projects.length, projects });
});

/**
 * AI Short Film Studio: Retrieve film package details
 */
mediaRouter.get('/api/media/film/:id', (req: Request, res: Response) => {
  const film = shortFilmStudio.getFilmProject(req.params.id);
  if (!film) {
    return res.status(404).json({ error: 'Film project not found' });
  }
  res.json({ success: true, film });
});

/**
 * AI Short Film Studio: Download ZIP production deliverable
 */
mediaRouter.get('/api/media/film/:id/download', (req: Request, res: Response) => {
  const zip = shortFilmStudio.getFilmZip(req.params.id);
  if (!zip) {
    return res.status(404).json({ error: 'Film production ZIP not found' });
  }

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.id}_production_package.zip"`);
  res.send(zip);
});

/**
 * AI Short Film Studio: Single-scene/shot regeneration
 */
mediaRouter.post('/api/media/film/:id/regenerate-shot', (req: Request, res: Response) => {
  const { sceneId, shotId, customPrompt } = req.body;
  if (!sceneId || !shotId) {
    return res.status(400).json({ error: 'sceneId and shotId required' });
  }

  const shot = shortFilmStudio.regenerateShot(req.params.id, sceneId, shotId, customPrompt);
  if (!shot) {
    return res.status(404).json({ error: 'Specified scene or shot not found in project' });
  }

  res.json({ success: true, shot });
});

/**
 * Video Generation: List video jobs
 */
mediaRouter.get('/api/media/video/jobs', (req: Request, res: Response) => {
  res.json({
    success: true,
    providers: mediaEngine.getVideoProviders(),
    jobs: mediaEngine.listVideoJobs(),
  });
});

/**
 * Video Generation: Dispatch video job
 */
mediaRouter.post('/api/media/video/create', async (req: Request, res: Response) => {
  try {
    const job = await mediaEngine.orchestrateVideo(req.body);
    res.json({ success: true, job });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Video job dispatch failed' });
  }
});

/**
 * Autonomous Code Debugger Endpoint
 */
mediaRouter.post('/api/code/debug', async (req: Request, res: Response) => {
  try {
    const { code, errorDescription, filePath, language } = req.body;
    if (!code) {
      return res.status(400).json({ error: 'code is required for debugging' });
    }

    const debugResult = await codingEngine.debugCode({
      code,
      errorDescription,
      filePath,
      language,
    });

    res.json({ success: true, ...debugResult });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Code debug failed' });
  }
});

/**
 * Self-Upgrade Engine: Status and history
 */
mediaRouter.get('/api/system/upgrade/status', (req: Request, res: Response) => {
  res.json({
    success: true,
    currentVersion: selfUpgradeEngine.getCurrentVersion(),
    versionHistory: selfUpgradeEngine.getVersionHistory(),
    upgradeHistory: selfUpgradeEngine.getUpgradeHistory(),
  });
});

/**
 * Self-Upgrade Engine: Execute controlled upgrade simulation or rollback test
 */
mediaRouter.post('/api/system/upgrade/execute', async (req: Request, res: Response) => {
  try {
    const { targetVersion, improvementDescription, simulateFailureStage } = req.body;
    const record = await selfUpgradeEngine.executeControlledUpgrade({
      targetVersion,
      improvementDescription,
      simulateFailureStage,
    });

    res.json({ success: true, record });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Upgrade execution failed' });
  }
});
