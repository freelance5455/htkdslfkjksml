/**
 * JARVIS Document Generation API Router
 */

import { Router } from 'express';
import type { Request, Response } from 'express';

import { db } from '../db/database.ts';
import { documentGenerator } from '../documents/documentGenerator.ts';

export const documentsRouter = Router();

// 1. Generate document
documentsRouter.post('/generate', async (req: Request, res: Response) => {
  try {
    const { title, format, content, conversationId, projectId } = req.body;

    if (!title || !format || !content) {
      return res.status(400).json({
        error: 'title, format (pdf|md|txt|json|csv), and content are required.',
      });
    }

    if (!['pdf', 'md', 'txt', 'json', 'csv'].includes(format)) {
      return res.status(400).json({
        error: 'Invalid format. Supported formats: pdf, md, txt, json, csv.',
      });
    }

    const doc = await documentGenerator.generateDocument({
      title,
      format,
      content,
      conversationId,
      projectId,
      userId: req.body.userId || 'usr_jarvis_prime',
    });

    return res.status(201).json({ success: true, document: doc });
  } catch (error) {
    console.error('[DOCUMENTS ROUTER ERROR]', error);
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Document generation failed',
    });
  }
});

// 2. List generated documents
documentsRouter.get('/', async (req: Request, res: Response) => {
  try {
    const conversationId = typeof req.query.conversationId === 'string' ? req.query.conversationId : undefined;
    const projectId = typeof req.query.projectId === 'string' ? req.query.projectId : undefined;

    if (db.getDocuments) {
      const docs = await db.getDocuments({ conversationId, projectId });
      return res.json({ success: true, documents: docs });
    }
    return res.json({ success: true, documents: [] });
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to retrieve documents',
    });
  }
});

// 3. Get document metadata
documentsRouter.get('/:id', async (req: Request, res: Response) => {
  try {
    const doc = await documentGenerator.getDocument(req.params.id);
    if (!doc) {
      return res.status(404).json({ error: 'Document not found' });
    }
    return res.json({ success: true, document: doc });
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to retrieve document',
    });
  }
});

// 4. Download generated document
documentsRouter.get('/:id/download', async (req: Request, res: Response) => {
  try {
    const result = await documentGenerator.getDocumentBuffer(req.params.id);
    if (!result) {
      return res.status(404).json({ error: 'Document not found' });
    }
    const { buffer, doc } = result;

    const mimeMap: Record<string, string> = {
      pdf: 'application/pdf',
      md: 'text/markdown',
      txt: 'text/plain',
      json: 'application/json',
      csv: 'text/csv',
    };

    res.setHeader('Content-Type', mimeMap[doc.format] || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${doc.filename}"`);
    res.setHeader('Content-Length', buffer.length);
    return res.send(buffer);
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Download failed',
    });
  }
});
