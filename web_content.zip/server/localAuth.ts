import { createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { ENV } from "./_core/env";

const scrypt = promisify(scryptCallback);
const LOCAL_COOKIE = "workroom_local_session";

export function localSessionCookieName() { return LOCAL_COOKIE; }

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, encoded: string) {
  const [, salt, storedHex] = encoded.split(":");
  if (!salt || !storedHex) return false;
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  const stored = Buffer.from(storedHex, "hex");
  return stored.length === derived.length && timingSafeEqual(stored, derived);
}

function secret() { return ENV.cookieSecret || "workroom-development-secret"; }
function encode(value: string) { return Buffer.from(value).toString("base64url"); }
function decode(value: string) { return Buffer.from(value, "base64url").toString(); }

export function createLocalSession(accountId: number, rememberMe = true) {
  const payload = encode(JSON.stringify({ accountId, exp: Date.now() + (rememberMe ? 1000 * 60 * 60 * 24 * 30 : 1000 * 60 * 60 * 8) }));
  const signature = createHmac("sha256", secret()).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

export function readLocalSession(token?: string | null) {
  if (!token) return null;
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return null;
  const expected = createHmac("sha256", secret()).update(payload).digest("base64url");
  if (signature.length !== expected.length || !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  try {
    const parsed = JSON.parse(decode(payload)) as { accountId: number; exp: number };
    return parsed.exp > Date.now() ? parsed : null;
  } catch { return null; }
}

export function localCookieOptions(rememberMe = true, secure = ENV.isProduction) {
  return { httpOnly: true, sameSite: secure ? "none" as const : "lax" as const, secure, path: "/", ...(rememberMe ? { maxAge: 1000 * 60 * 60 * 24 * 30 } : {}) };
}
