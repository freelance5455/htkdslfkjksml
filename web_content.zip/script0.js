function buyStarItem(type){
  const costs={revive:20,double:35,time:50,shield:70};
  const names={revive:"Vida extra",double:"Multiplicador de pontos",time:"Tempo Supremo",shield:"Escudo Supremo"};
  const inventoryMap={revive:"life",double:"double",time:"time",shield:"shield"};
  const max={revive:5,double:9,time:5,shield:9};
  const cost=costs[type], invId=inventoryMap[type];
  if(!cost||!invId)return;
  state.stars=Number(state.stars)||0;
  state.inventory=state.inventory||{};
  const have=Number(state.inventory[invId])||0;
  if(state.stars<cost){ecoNotify("⭐ Estrelas insuficientes!","Você precisa de "+cost+" estrelas.");return;}
  if(have>=max[type]){ecoNotify("📦 Limite atingido!","Você já possui o máximo desse item.");return;}
  if(state.settings.confirmBuy&&!confirm(`Comprar ${names[type]} por ${cost} estrelas?`))return;
  state.stars-=cost;
  state.inventory[invId]=have+1;
  save();renderAll();sound("win");ecoNotify("⭐ Compra realizada!",names[type]+" adquirido.");
}function ecoNotify(title,message){if(state.settings&&!state.settings.notify)return;const box=document.getElementById("ecoNotifications");if(!box)return;const n=document.createElement("div");n.className="eco-notify";n.innerHTML="<b>"+title+"</b><span>"+message+"</span>";box.appendChild(n);setTimeout(()=>n.remove(),4200);}
const phases=[
{name:"🏫 Escola Sustentável",icon:"🏫",difficulty:"DIFÍCIL",time:48,lives:3,items:18,desc:"Organize a escola antes do sinal.",pool:[["📄","Folha","blue"],["📚","Livro","blue"],["📦","Caixa","blue"],["🧴","Garrafa PET","red"],["🥤","Copo plástico","red"],["🛍️","Sacola","red"],["🍾","Garrafa de vidro","green"],["🫙","Pote de vidro","green"],["🥫","Lata","yellow"]]},
{name:"🌳 Praça Central",icon:"🌳",difficulty:"DIFÍCIL",time:43,lives:3,items:22,desc:"A praça está cheia de resíduos.",pool:[["📰","Jornal","blue"],["📦","Papelão","blue"],["📄","Papel","blue"],["🧴","PET","red"],["🛍️","Plástico","red"],["🥤","Embalagem","red"],["🍾","Vidro","green"],["🫙","Pote","green"],["🥫","Lata","yellow"],["🥤","Metal","yellow"]]},
{name:"🧺 Feira",icon:"🧺",difficulty:"EXTREMO",time:39,lives:2,items:26,desc:"Pouco tempo e muito movimento.",pool:[["📦","Caixa","blue"],["📰","Folheto","blue"],["📄","Papel","blue"],["🧴","Embalagem PET","red"],["🛍️","Sacola","red"],["🧃","Plástico","red"],["🍾","Garrafa","green"],["🫙","Vidro","green"],["🥫","Metal","yellow"],["🥤","Lata","yellow"]]},
{name:"🏙️ Centro Urbano",icon:"🏙️",difficulty:"EXTREMO",time:36,lives:2,items:30,desc:"O trânsito não para. Você também não.",pool:[["📰","Papel","blue"],["📦","Papelão","blue"],["📄","Revista","blue"],["🧴","Plástico","red"],["🛍️","Sacola","red"],["🧃","PET","red"],["🍾","Vidro","green"],["🫙","Pote","green"],["🥫","Metal","yellow"],["🥤","Lata","yellow"]]},
{name:"🏭 Zona Industrial",icon:"🏭",difficulty:"INSANO",time:33,lives:1,items:35,desc:"Uma falha pode acabar com tudo.",pool:[["📦","Papelão","blue"],["📰","Papel","blue"],["📄","Folha","blue"],["🧴","PET","red"],["🛍️","Plástico","red"],["🧃","Embalagem","red"],["🍾","Vidro","green"],["🫙","Pote","green"],["🥫","Metal","yellow"],["🥤","Lata","yellow"]]},
{name:"🌎 Desafio Brasil",icon:"🌎",difficulty:"PESADÍSSIMO",time:31,lives:1,items:42,desc:"A prova final da campanha.",pool:[["📦","Papelão","blue"],["📰","Papel","blue"],["📄","Papel","blue"],["🧴","PET","red"],["🛍️","Plástico","red"],["🧃","Plástico","red"],["🍾","Vidro","green"],["🫙","Vidro","green"],["🥫","Metal","yellow"],["🥤","Metal","yellow"]]}
];
window.ecoPhases=phases;

const storyChapters=[
 {title:"O chamado",icon:"🏫",subtitle:"Capítulo 1 • A primeira coleta",text:"A escola amanhece cercada por resíduos, e algo chama sua atenção: materiais diferentes foram misturados como se ninguém soubesse para onde cada um deveria ir. A diretora pede sua ajuda antes que o problema chegue às ruas.",dialog:"“Se conseguirmos começar aqui, podemos mostrar para toda a cidade que separar corretamente faz diferença.”",goal:"Concluir a missão da Escola Sustentável.",reward:"⭐ +15 bônus de história"},
 {title:"A praça esquecida",icon:"🌳",subtitle:"Capítulo 2 • Um lugar para recuperar",text:"Depois da escola, você encontra a Praça Central tomada por embalagens e garrafas. No meio da bagunça, há uma placa antiga sobre reciclagem quase escondida. Os moradores querem recuperar a praça — e descobrir quem deixou aquilo acontecer.",dialog:"“A praça era o coração do bairro. Vamos devolver esse espaço para as pessoas.”",goal:"Limpar a Praça Central.",reward:"⭐ +20 bônus de história"},
 {title:"Dia de feira",icon:"🧺",subtitle:"Capítulo 3 • Muito movimento",text:"É dia de feira. Em poucos minutos, o movimento transforma a praça em um labirinto de embalagens. Você percebe que, desta vez, não basta recolher: será preciso criar uma estratégia antes que a confusão cresça.",dialog:"“Hoje vai ser difícil. Mas se a feira funcionar, todo mundo vai perceber que reciclar pode fazer parte da rotina.”",goal:"Organizar a Feira.",reward:"⭐ +25 bônus de história"},
 {title:"O centro em alerta",icon:"🏙️",subtitle:"Capítulo 4 • A cidade não para",text:"No centro urbano, o descarte irregular começa a bloquear pontos de passagem. Um aviso inesperado mostra que a cidade está produzindo mais resíduos do que a coleta consegue acompanhar. A missão agora exige rapidez, precisão e uma nova ideia.",dialog:"“Cada minuto conta. O objetivo não é só limpar: é criar um exemplo que possa ser repetido.”",goal:"Recuperar o Centro Urbano.",reward:"⭐ +30 bônus de história"},
 {title:"A zona industrial",icon:"🏭",subtitle:"Capítulo 5 • O grande teste",text:"A coleta chega à Zona Industrial. São muitos materiais diferentes, pouco tempo e uma sequência de erros que ameaça todo o trabalho anterior. Sua equipe precisa trabalhar como nunca para descobrir a origem do problema.",dialog:"“Chegamos ao ponto em que qualquer erro custa caro. Concentre-se e mantenha a sequência.”",goal:"Concluir a missão da Zona Industrial.",reward:"⭐ +35 bônus de história"},
 {title:"Um futuro mais verde",icon:"🌎",subtitle:"Capítulo 6 • Desafio Brasil",text:"O trabalho alcançou uma escala maior. Depois de tudo que você descobriu, surge uma última pergunta: será que a mudança consegue continuar quando a campanha terminar? Agora você precisa completar a etapa final e provar que uma decisão correta pode inspirar milhares de outras.",dialog:"“A missão nunca foi apenas separar lixo. Foi ensinar que cada escolha deixa uma marca no mundo.”",goal:"Vencer o Desafio Brasil.",reward:"🏆 Final da história +40⭐"}, {title:"A rota dos recicláveis",icon:"🚛",subtitle:"Capítulo 7 • A coleta precisa chegar",text:"Depois do grande desafio, os materiais separados começam a desaparecer do caminho. Nada foi perdido por acaso: as rotas estão desencontradas. A equipe organiza uma missão especial para descobrir o que está acontecendo e garantir que cada material chegue ao destino correto.",dialog:"“Separar é só o começo. Agora precisamos garantir que cada material siga o caminho certo.”",goal:"Concluir a missão e manter a coleta organizada.",reward:"⭐ +45 bônus de história"},
 {title:"O rio pede ajuda",icon:"💧",subtitle:"Capítulo 8 • Protegendo a água",text:"Resíduos começaram a aparecer próximos ao rio, carregados pela chuva. A comunidade se reúne às pressas e encontra sinais de que o problema começou muito antes de chegar à água. Agora é preciso proteger o rio e impedir que a história se repita.",dialog:"“Se protegermos o rio hoje, estaremos protegendo muito mais do que a paisagem.”",goal:"Concluir a missão de limpeza e prevenção.",reward:"⭐ +50 bônus de história"},
 {title:"A grande mobilização",icon:"🤝",subtitle:"Capítulo 9 • Todos juntos",text:"Escolas, moradores e comerciantes finalmente trabalham lado a lado. Pela primeira vez, as pistas encontradas ao longo da jornada começam a fazer sentido: a mudança não depende de um herói, mas de milhares de pequenas escolhas feitas todos os dias.",dialog:"“Uma pessoa pode começar uma mudança. Uma comunidade pode fazer essa mudança durar.”",goal:"Completar a missão da mobilização.",reward:"⭐ +55 bônus de história"},
 {title:"O legado verde",icon:"🏆",subtitle:"Capítulo 10 • O último desafio",text:"A última etapa chegou. A cidade está diferente, mas o verdadeiro teste começa agora: manter tudo o que foi conquistado quando ninguém estiver olhando. Você terá uma última missão para transformar a campanha em um legado.",dialog:"“A história termina aqui, mas o trabalho continua. O verdadeiro prêmio é deixar um lugar melhor para quem vem depois.”",goal:"Vencer o último desafio e concluir a campanha.",reward:"🏆 Final completo +60⭐"},
];
function renderStory(){
 let e=$("storyList"); if(!e)return;
 let p=Math.max(0,Math.min(storyChapters.length,Number(state.storyProgress)||0));
 $("storyProg").style.width=(p/storyChapters.length*100)+"%";
 $("storyText").textContent=p>=storyChapters.length?"🏆 História concluída! Você ajudou a construir uma cidade mais limpa.":`Capítulo ${p+1} de ${storyChapters.length} • ${p} concluído(s)`;
 e.innerHTML="";
 storyChapters.forEach((c,i)=>{
   let unlocked=i<=p,done=i<p,current=i===p;
   let button=done?`<button type="button" class="btn ghost story-action" onclick="startStoryChapter(${i})">↻ Jogar novamente</button>`:
     unlocked?`<button type="button" class="btn gold story-action" onclick="startStoryChapter(${i})">▶ Jogar capítulo</button>`:
     `<button type="button" class="btn story-action" disabled>🔒 Bloqueado</button>`;
   let status=done?`<div class="story-complete">✓ CAPÍTULO CONCLUÍDO</div>`:current?`<div class="story-reward">⭐ Próximo capítulo disponível</div>`:`<div class="small">Complete o capítulo anterior</div>`;
   let d=document.createElement("div");
   d.className=`story-card ${unlocked?"":"locked"} ${current?"current":""}`;
   d.innerHTML=`<div class="story-icon">${c.icon}</div><div><div class="story-chapter">${c.subtitle}</div><h3>${c.title}</h3><p class="small">${c.text}</p>${status}</div><div>${button}</div>`;
   e.appendChild(d);
 });
}
function startStoryChapter(index){
 index=Number(index);
 if(!Number.isInteger(index)||index<0||index>=storyChapters.length)return;
 if(index>Number(state.storyProgress||0))return;
 const c=storyChapters[index];
 const launch=()=>{
   modalAction=null;
   $("modal").classList.remove("show");
   setTimeout(()=>startGame(index,true),30);
 };
 openModal(
   c.icon,
   c.title,
   `${c.dialog}<div class="story-dialog"><b>Objetivo</b><br>${c.goal}<br><br><span class="story-reward">${c.reward}</span></div>`,
   launch
 );
}

const shopItems=[
{id:"life",icon:"❤️",name:"Vida Extra",price:650,desc:"+1 vida na próxima missão.",max:5,cat:"equip"},
{id:"shield",icon:"🛡️",name:"Escudo",price:500,desc:"Anula um erro sem perder a fase.",max:9,cat:"equip"},
{id:"double",icon:"⭐",name:"Estrela Dourada",price:750,desc:"Dobra pontos dos próximos 5 acertos.",max:9,cat:"equip"},
{id:"time",icon:"⏱️",name:"Tempo Extra",price:900,desc:"+6 segundos no início da missão.",max:5,cat:"equip"},
{id:"magnet",icon:"🧲",name:"Ímã de Moedas",price:750,desc:"Ajuda a aumentar ganhos durante a missão.",max:9,cat:"equip"},
{id:"heart",icon:"💚",name:"Coração Eco",price:900,desc:"Recupera 1 vida uma vez na missão.",max:5,cat:"equip"},
{id:"badge",icon:"🌿",name:"Emblema Folha",price:1800,desc:"Item raro de coleção para quem apoia a jornada verde.",max:1,cat:"rare"},
{id:"pin",icon:"📍",name:"Pin Explorador",price:2400,desc:"Marca especial de quem percorreu o mapa inteiro.",max:1,cat:"rare"},
{id:"trophy",icon:"🏆",name:"Troféu Mini Verde",price:3200,desc:"Peça de coleção para jogadores dedicados.",max:1,cat:"rare"},
{id:"planet",icon:"🌎",name:"Globo Sustentável",price:4500,desc:"Item raro reservado para grandes colecionadores.",max:1,cat:"rare"},
{id:"leaf",icon:"🍃",name:"Folha Dourada",price:6000,desc:"Uma das peças mais caras da loja.",max:1,cat:"rare"},
{id:"crown",icon:"👑",name:"Coroa Eco",price:9000,desc:"Símbolo de prestígio para quem juntou muitos recursos.",max:1,cat:"rare"}
];
const missions=[
{id:"m1",icon:"🌱",name:"Primeiro passo verde",desc:"Acerte 15 resíduos e mostre que você já domina o básico.",goal:15,reward:35,starReward:0,type:"correct"},
{id:"m2",icon:"🔥",name:"Combo de respeito",desc:"Faça uma sequência de 10 acertos sem quebrar o ritmo.",goal:10,reward:55,starReward:2,type:"streak"},
{id:"m3",icon:"🪙",name:"Cofre sustentável",desc:"Acumule 250 moedas ao longo da sua jornada.",goal:250,reward:75,starReward:0,type:"coins"},
{id:"m4",icon:"🏁",name:"Rota de aprendizado",desc:"Conclua 4 fases e avance pela campanha.",goal:4,reward:90,starReward:2,type:"wins"},
{id:"m5",icon:"🎯",name:"Olho de águia",desc:"Responda 50 resíduos. Cada escolha conta.",goal:50,reward:100,starReward:2,type:"answered"},
{id:"m6",icon:"💎",name:"Precisão rara",desc:"Conclua 2 fases sem errar nenhum resíduo.",goal:2,reward:120,starReward:4,type:"perfect"},
{id:"m7",icon:"⭐",name:"Estrela em ascensão",desc:"Junte 500 estrelas com suas partidas e recompensas.",goal:500,reward:130,starReward:4,type:"stars"},
{id:"m8",icon:"🗺️",name:"Explorador da coleta",desc:"Libere 4 áreas diferentes do mapa.",goal:4,reward:110,starReward:2,type:"unlocked"},
{id:"m9",icon:"📖",name:"Capítulo por capítulo",desc:"Conclua 3 capítulos do Modo História.",goal:3,reward:100,starReward:4,type:"story"},
{id:"m10",icon:"⚡",name:"Ritmo constante",desc:"Alcance uma sequência de 15 acertos.",goal:15,reward:150,starReward:5,type:"streak"},
{id:"m11",icon:"🏆",name:"Veterano da coleta",desc:"Conclua 8 fases e prove que sua evolução é consistente.",goal:8,reward:170,starReward:4,type:"wins"},
{id:"m12",icon:"🌎",name:"Guardião do planeta",desc:"Libere todas as 6 áreas principais da campanha.",goal:6,reward:220,starReward:6,type:"unlocked"}
];
const achievements=[
{id:"a1",icon:"🌱",name:"Primeira Folha",desc:"Conclua sua primeira fase e dê o primeiro passo na jornada.",type:"wins",goal:1},
{id:"a2",icon:"🔥",name:"Fogo Verde",desc:"Alcance 8 acertos seguidos sem quebrar o combo.",type:"bestStreak",goal:8},
{id:"a3",icon:"💰",name:"Economista Verde",desc:"Junte 250 moedas para fortalecer sua jornada.",type:"coins",goal:250},
{id:"a4",icon:"🌎",name:"Explorador do Mapa",desc:"Desbloqueie todas as 6 áreas principais.",type:"unlocked",goal:6},
{id:"a5",icon:"⚡",name:"Mira Perfeita",desc:"Conclua uma fase com 100% de acerto.",type:"perfect",goal:1},
{id:"a6",icon:"👑",name:"Lenda da Coleta",desc:"Conclua 10 fases e prove sua consistência.",type:"wins",goal:10},
{id:"a7",icon:"📦",name:"Caçador de Resíduos",desc:"Acerte corretamente 50 resíduos durante suas partidas.",type:"correct",goal:50},
{id:"a8",icon:"🎯",name:"Mão Certeira",desc:"Acerte corretamente 150 resíduos.",type:"correct",goal:150},
{id:"a9",icon:"🧠",name:"Memória Ambiental",desc:"Responda a 100 resíduos ao longo da campanha.",type:"answered",goal:100},
{id:"a10",icon:"🧭",name:"Sem Caminho Perdido",desc:"Responda a 300 resíduos e mantenha o foco.",type:"answered",goal:300},
{id:"a11",icon:"🔥",name:"Combo de Aço",desc:"Alcance 15 acertos seguidos.",type:"bestStreak",goal:15},
{id:"a12",icon:"💥",name:"Sequência Imparável",desc:"Alcance 25 acertos seguidos.",type:"bestStreak",goal:25},
{id:"a13",icon:"🪙",name:"Cofre Cheio",desc:"Acumule 1.000 moedas.",type:"coins",goal:1000},
{id:"a14",icon:"💎",name:"Fortuna Sustentável",desc:"Acumule 2.500 moedas.",type:"coins",goal:2500},
{id:"a15",icon:"⭐",name:"Colecionador de Estrelas",desc:"Acumule 500 estrelas.",type:"stars",goal:500},
{id:"a16",icon:"🌟",name:"Constelação Verde",desc:"Acumule 1.500 estrelas.",type:"stars",goal:1500},
{id:"a17",icon:"💯",name:"Olhar de Águia",desc:"Conclua 3 fases sem errar nenhum resíduo.",type:"perfect",goal:3},
{id:"a18",icon:"🏆",name:"Campeão da Campanha",desc:"Conclua 20 fases.",type:"wins",goal:20},
{id:"a19",icon:"📖",name:"Viajante da História",desc:"Conclua 5 capítulos do Modo História.",type:"story",goal:5},
{id:"a20",icon:"📚",name:"Guardião da História",desc:"Conclua todos os 10 capítulos da história.",type:"story",goal:10},
{id:"a21",icon:"🗺️",name:"Mapa Completo",desc:"Desbloqueie todas as áreas disponíveis da campanha.",type:"unlocked",goal:10},
{id:"a22",icon:"♻️",name:"Especialista em Reciclagem",desc:"Acerte corretamente 500 resíduos.",type:"correct",goal:500},
{id:"a23",icon:"🏅",name:"Veterano Verde",desc:"Conclua 30 fases.",type:"wins",goal:30},
{id:"a24",icon:"🌳",name:"Raiz Forte",desc:"Mantenha uma jornada longa: responda a 750 resíduos.",type:"answered",goal:750}
];
let state={score:0,stars:0,coins:0,trophies:0,level:1,unlocked:1,wins:0,profileName:"EcoGuardião",profileAvatar:"🧑",bestStreak:0,perfect:0,totalCorrect:0,totalAnswered:0,passPremium:false,passClaims:{},passStickers:0,inventory:{life:0,shield:0,double:0,time:0,magnet:0,heart:0},claimedMissions:{},unlockedAchievements:{},settings:{music:true,sound:true,vibe:true,musicVol:30,soundVol:45,vibeVol:60,tips:true,notify:true,reducedMotion:false,confirmBuy:true},storyProgress:0};

// ===== PASSE ECO: sistema integrado no index.html =====
const ecoPassRewards=Array.from({length:30},(_,i)=>({
  level:i+1,
  free:["🪙",`${50+(i*10)} moedas`],
  premium:i%5===4?["🎟️","Figurinha Eco rara"]:i%3===0?["⭐",`${40+(i*5)} estrelas`]:["🪙",`${150+(i*20)} moedas`]
}));
function passLevel(){return Math.min(30,Math.max(1,1+Math.floor((Number(state.score)||0)/1000)))}
function passPremiumUnlocked(){return state.passPremium===true}
function buyPassPremium(){
  state.coins=Number(state.coins)||0;
  if(passPremiumUnlocked()){ecoNotify("👑 Premium ativo!","O Passe Premium já está desbloqueado.");renderPass();return;}
  if(state.coins<1000){ecoNotify("🪙 Moedas insuficientes!",`Você tem ${state.coins} moedas. Junte 1.000 moedas para desbloquear o Premium.`);renderPass();return;}
  state.coins-=1000;
  state.passPremium=true;
  save();
  renderAll();
  sound("win");
  ecoNotify("👑 Passe Premium desbloqueado!","A trilha Premium está liberada. Agora você pode resgatar as recompensas dos níveis alcançados.");
}
function claimPass(level,tier){
  const lv=passLevel();
  if(level>lv){ecoNotify("🔒 Nível bloqueado",`Alcance o nível ${level} do Passe Eco para resgatar esta recompensa.`);return;}
  if(tier==="premium"&&!passPremiumUnlocked()){buyPassPremium();return;}
  state.passClaims=state.passClaims||{};
  const key=`${tier}_${level}`;
  if(state.passClaims[key]){ecoNotify("✅ Já resgatado","Essa recompensa já foi adicionada ao seu inventário.");return;}
  const r=ecoPassRewards[level-1][tier];
  if(r[0]==="🪙")state.coins+=parseInt(r[1],10)||0;
  else if(r[0]==="⭐")state.stars+=parseInt(r[1],10)||0;
  else state.passStickers=(Number(state.passStickers)||0)+1;
  state.passClaims[key]=1;
  save();
  renderAll();
  sound("win");
  ecoNotify("🎁 Recompensa resgatada!",`${r[0]} ${r[1]}`);
}
function renderPass(){
  const current=passLevel(),el=$("passList");
  if(!el)return;
  state.passClaims=state.passClaims||{};
  const prog=current>=30?100:((current-1)/29)*100;
  $("passLevelText").textContent=`NÍVEL ${current}/30`;
  $("passProg").style.width=prog+"%";
  $("passXpText").textContent=`${Math.min(30000,Number(state.score)||0)} pontos de passe • nível baseado na pontuação`;
  const status=$("passStatus");
  status.innerHTML=passPremiumUnlocked()?`👑 <b>Premium desbloqueado</b> • Trilha Premium ativa. 🪙 Moedas: <b>${state.coins}</b>`:`🔒 <b>Premium bloqueado</b> • Custa <b>🪙 1.000 moedas</b>. <button class="btn gold" style="margin-left:8px" onclick="buyPassPremium()">Comprar Premium — 1.000 🪙</button>`;
  el.innerHTML=ecoPassRewards.map(r=>{
    const unlocked=r.level<=current;
    const fc=!!state.passClaims[`free_${r.level}`];
    const pc=!!state.passClaims[`premium_${r.level}`];
    const freeBtn=fc?`<span class="tag">✓ RESGATADO</span>`:unlocked?`<button class="btn primary" onclick="claimPass(${r.level},'free')">Resgatar</button>`:`<span class="pass-lock">🔒 Nível ${r.level}</span>`;
    const premBtn=pc?`<span class="tag">✓ RESGATADO</span>`:!passPremiumUnlocked()?`<button class="btn gold" onclick="buyPassPremium()">👑 Comprar por 1.000 🪙</button>`:unlocked?`<button class="btn gold" onclick="claimPass(${r.level},'premium')">Resgatar</button>`:`<span class="pass-lock">🔒 Nível ${r.level}</span>`;
    return `<div class="pass-row ${r.level===current?"current":!unlocked?"locked":""}"><div class="pass-tier">${r.level}</div><div class="pass-reward ${fc?"claimed":""}"><span class="reward-icon">${r.free[0]}</span><div><b>${r.free[1]}</b><div class="small">🎁 Grátis</div></div>${freeBtn}</div><div class="pass-reward premium ${pc?"claimed":""}"><span class="reward-icon pass-crown">${r.premium[0]}</span><div><b>${r.premium[1]}</b><div class="small">👑 Premium</div></div>${premBtn}</div></div>`;
  }).join("");
}
window.buyPassPremium=buyPassPremium;
window.claimPass=claimPass;
window.renderPass=renderPass;

let game=null,timerId=null,musicCtx=null,musicTimer=null;


function $(id){return document.getElementById(id)}
function replaceStateFromCloud(cloud){
 try{
  if(!cloud||typeof cloud!=="object")return;
  const numKeys=["score","stars","coins","trophies","level","unlocked","wins","bestStreak","perfect","totalCorrect","totalAnswered","storyProgress"];
  for(const k of numKeys){const v=Number(cloud[k]);if(Number.isFinite(v))state[k]=Math.max(Number(state[k])||0,v)}
  if(cloud.inventory&&typeof cloud.inventory==="object"){
   state.inventory={...state.inventory};
   for(const [k,v] of Object.entries(cloud.inventory)){const n=Number(v);if(Number.isFinite(n))state.inventory[k]=Math.max(Number(state.inventory[k])||0,n)}
  }
  if(cloud.claimedMissions&&typeof cloud.claimedMissions==="object")state.claimedMissions={...cloud.claimedMissions,...state.claimedMissions};
  if(cloud.unlockedAchievements&&typeof cloud.unlockedAchievements==="object")state.unlockedAchievements={...cloud.unlockedAchievements,...state.unlockedAchievements};
  localStorage.setItem("ecoColetaV2",JSON.stringify(state));
  renderAll();
 }catch(e){console.warn("Falha ao aplicar progresso da nuvem",e)}
}
window.replaceStateFromCloud=replaceStateFromCloud;
function save(){
 localStorage.setItem("ecoColetaV2",JSON.stringify(state));
 window.state=state;
 if(window.ecoOnline?.connected)window.ecoOnline.saveCloud().catch(()=>{});
 if(window.lanOnline?.publish)window.lanOnline.publish();
}
function load(){
 try{
  let s=JSON.parse(localStorage.getItem("ecoColetaV2"));
  if(s)state={...state,...s,inventory:{...state.inventory,...(s.inventory||{})},settings:{...state.settings,...(s.settings||{})}};
  state.passPremium=state.passPremium===true; state.passClaims=state.passClaims||{}; state.passStickers=Number(state.passStickers)||0;
  state.settings={music:true,sound:true,vibe:true,musicVol:30,soundVol:45,vibeVol:60,tips:true,notify:true,reducedMotion:false,confirmBuy:true,...(state.settings||{})};
  if(typeof state.stars!=="number"||!Number.isFinite(state.stars))state.stars=Number(state.score)||0;
  if(typeof state.storyProgress!=="number"||!Number.isFinite(state.storyProgress))state.storyProgress=0;
 }catch(e){state.stars=Number(state.stars)||Number(state.score)||0;state.storyProgress=0}
}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");window.scrollTo({top:0,behavior:"smooth"});renderAll();if(id==="pass")renderPass();if(id==="settings")syncSettings()}
function toast(t){let e=$("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),1800)}
const liveEvents={
 corrida:{name:"🌿 Corrida da Reciclagem",duration:30*60*1000},
 raio:{name:"⚡ Desafio Relâmpago",duration:30*60*1000},
 copa:{name:"🏆 Copa Verde",duration:30*60*1000},
 limpeza:{name:"♻️ Hora da Limpeza",duration:30*60*1000}
};
const LIVE_EVENT_END_KEY="ecoLiveEventEndShared";
function getSharedEventEnd(){
 const now=Date.now();
 let end=Number(localStorage.getItem(LIVE_EVENT_END_KEY));
 const copaEnd=Number(localStorage.getItem("ecoLiveEventEnd_copa"));
 if(!Number.isFinite(end)||end<=now){
   if(Number.isFinite(copaEnd)&&copaEnd>now) end=copaEnd;
   else end=now+liveEvents.copa.duration;
   localStorage.setItem(LIVE_EVENT_END_KEY,String(end));
 }
 // Migra cronômetros antigos e força todos os eventos a usarem exatamente o mesmo final.
 Object.keys(liveEvents).forEach(id=>localStorage.setItem("ecoLiveEventEnd_"+id,String(end)));
 return end;
}
function startLiveEvent(id){
 const ev=liveEvents[id];if(!ev)return;
 getSharedEventEnd();
 localStorage.setItem("ecoLiveEvent",id);
 toast(ev.name+" iniciado!");
 show('map');
}
function updateLiveEvents(){
 const now=Date.now();
 let end=getSharedEventEnd();
 if(now>=end){
   end=now+liveEvents.copa.duration;
   localStorage.setItem(LIVE_EVENT_END_KEY,String(end));
   Object.keys(liveEvents).forEach(id=>localStorage.setItem("ecoLiveEventEnd_"+id,String(end)));
 }
 const left=Math.max(0,end-now);
 const m=String(Math.floor(left/60000)).padStart(2,'0');
 const sec=String(Math.floor(left/1000)%60).padStart(2,'0');
 Object.keys(liveEvents).forEach((id,i)=>{
  const el=$("eventTimer"+(i+1));if(el)el.textContent="🔴 AO VIVO • "+m+":"+sec;
 });
}
setInterval(updateLiveEvents,1000);updateLiveEvents();

function sound(kind="ok"){
 if(!state.settings.sound)return;
 try{let c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.frequency.value=kind==="bad"?150:kind==="win"?700:520;o.type=kind==="bad"?"sawtooth":"sine";g.gain.value=.045*(Number(state.settings.soundVol||45)/100);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.12)}catch(e){}
}
function startMusic(){
 if(!state.settings.music||musicCtx||Number(state.settings.musicVol||0)<=0)return;
 try{musicCtx=new (window.AudioContext||window.webkitAudioContext)();let c=musicCtx;
   let notes=[261.63,329.63,392,329.63,293.66,349.23,440,349.23],i=0;
   function tick(){if(!musicCtx)return;let o=c.createOscillator(),g=c.createGain();o.type="triangle";o.frequency.value=notes[i++%notes.length];g.gain.setValueAtTime(.012*(Number(state.settings.musicVol||30)/30),c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.45);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.46)}
   tick();musicTimer=setInterval(tick,480)
 }catch(e){}
}
function stopMusic(){if(musicTimer)clearInterval(musicTimer);musicTimer=null;if(musicCtx){musicCtx.close();musicCtx=null}}
function vibe(ms=35){if(state.settings.vibe&&navigator.vibrate){let factor=Number(state.settings.vibeVol||60)/60;navigator.vibrate(Math.max(1,Math.round(ms*factor)))}}
function toggleSetting(k){state.settings[k]=!state.settings[k];save();syncSettings();if(k==="music")state.settings.music?startMusic():stopMusic();if(k==="reducedMotion")document.body.classList.toggle("reduced-motion",!!state.settings.reducedMotion);toast(state.settings[k]?"Ativado":"Desativado")}
function setVolume(k,value){value=Math.max(0,Math.min(100,Number(value)||0));state.settings[k+"Vol"]=value;$(k+"VolumeText").textContent=value+"%";save();if(k==="music"){stopMusic();if(state.settings.music&&value>0)startMusic()}}
function syncSettings(){["music","sound","vibe","tips","notify","reducedMotion","confirmBuy"].forEach(k=>{let e=$(k+"Switch");if(e)e.classList.toggle("on",!!state.settings[k])});["music","sound","vibe"].forEach(k=>{let r=$(k+"Volume"),t=$(k+"VolumeText"),v=Number(state.settings[k+"Vol"]);if(r)r.value=Number.isFinite(v)?v:0;if(t)t.textContent=(Number.isFinite(v)?v:0)+"%"});document.body.classList.toggle("reduced-motion",!!state.settings.reducedMotion)}
function exportSave(){try{const data={version:5,exportedAt:new Date().toISOString(),state};const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="EcoColeta-backup.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast("📤 Backup criado!")}catch(e){toast("❌ Não foi possível criar o backup")}}
function importSave(input){const file=input.files&&input.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const data=JSON.parse(reader.result);const incoming=data&&data.state?data.state:data;if(!incoming||typeof incoming!=="object"||typeof incoming.score!=="number")throw new Error("invalid");if(!confirm("Restaurar este backup? O progresso atual será substituído."))return;state={...state,...incoming,inventory:{...state.inventory,...(incoming.inventory||{})},settings:{...state.settings,...(incoming.settings||{})}};save();renderAll();syncSettings();toast("📥 Backup restaurado!")}catch(e){toast("❌ Backup inválido ou corrompido")}finally{input.value=""}};reader.readAsText(file)}
const profileAvatars=["🧑‍🔬","🧑‍🚀","🧑‍🎨","🦸","🦹","🐼","🦊","🐢","🌳","🌎"];
function profileRank(){
 const s=Number(state.score)||0;
 if(s>=12000)return ["🌎","Guardião do Planeta"];
 if(s>=8000)return ["🌳","Mestre da Floresta"];
 if(s>=5000)return ["♻️","Herói da Reciclagem"];
 if(s>=2500)return ["🌿","Guardião Verde"];
 if(s>=1000)return ["🌱","Protetor da Natureza"];
 return ["🌿","Semente Verde"];
}
function profileTitle(){
 const w=Number(state.wins)||0, p=Number(state.perfect)||0, st=Number(state.bestStreak)||0;
 if(p>=10)return "💎 Lenda da Precisão";
 if(st>=15)return "🔥 Mestre das Sequências";
 if(w>=20)return "🏆 Campeão da Coleta";
 if(w>=10)return "⚡ Especialista Eco";
 if(w>=5)return "🌳 Explorador Verde";
 return "🌱 Novato Verde";
}
function setProfileName(v){
 const name=String(v||"").trim().slice(0,18);
 state.profileName=name||"EcoGuardião"; save(); renderProfile();
}
function chooseProfileAvatar(a){state.profileAvatar=a;save();renderProfile();toast("✨ Avatar atualizado!");}
function renderProfile(){
 const name=state.profileName||"EcoGuardião",avatar=state.profileAvatar||"🧑";
 const r=profileRank(),title=profileTitle();
 const level=Math.max(1,Number(state.level)||1),score=Math.max(0,Number(state.score)||0);
 const currentXP=score%1000,pct=Math.min(100,Math.floor(currentXP/10));
 const els={
  profileAvatar:$("profileAvatar"),profileName:$("profileName"),profileTitle:$("profileTitle"),
  profileRank:$("profileRank"),profileTrophies:$("profileTrophies"),profileXpText:$("profileXpText"),
  profileXpPct:$("profileXpPct"),profileXpBar:$("profileXpBar"),profileNameInput:$("profileNameInput"),
  pWins:$("pWins"),pCorrect:$("pCorrect"),pStreak:$("pStreak"),pPerfect:$("pPerfect"),pStars:$("pStars"),pCoins:$("pCoins")
 };
 if(!els.profileAvatar)return;
 els.profileAvatar.textContent=avatar;els.profileName.textContent=name;els.profileName.classList.toggle("pass-active",passPremiumUnlocked());els.profileTitle.textContent=title;
 els.profileRank.textContent=r[0]+" "+r[1];els.profileTrophies.textContent=Number(state.trophies)||0;
 els.profileXpText.textContent=`Nível ${level} • ${currentXP}/1000 XP`;
 els.profileXpPct.textContent=pct+"%";els.profileXpBar.style.width=pct+"%";
 const levelDot=$("profileLevelDot"); if(levelDot) levelDot.textContent=level;
 if(document.activeElement!==els.profileNameInput)els.profileNameInput.value=name;
 els.pWins.textContent=Number(state.wins)||0;els.pCorrect.textContent=Number(state.totalCorrect)||0;
 els.pStreak.textContent=Number(state.bestStreak)||0;els.pPerfect.textContent=Number(state.perfect)||0;
 els.pStars.textContent=Number(state.stars)||0;els.pCoins.textContent=Number(state.coins)||0;
 $("avatarGrid").innerHTML=profileAvatars.map(a=>`<button class="avatar-choice ${a===avatar?"selected":""}" onclick="chooseProfileAvatar('${a}')">${a}</button>`).join("");
 const earned=achievements.filter(a=>state.unlockedAchievements&&state.unlockedAchievements[a.id]);
 $("profileBadges").innerHTML=earned.length?earned.map(a=>`<div class="profile-ach"><div class="ico">${a.icon}</div><div class="txt"><b>${a.name}</b><br><small>${a.desc}</small></div></div>`).join("")
 :" <div class='small'>Ainda não há distintivos. Complete missões e fases para construir sua coleção.</div>";
 const impact=Math.max(0,Number(state.totalCorrect)||0);
 $("profileLegacy").textContent=impact?`Você já separou corretamente ${impact} itens. Cada acerto representa uma pequena ação que ajuda a manter a missão verde. Continue evoluindo para desbloquear novos títulos e transformar seu perfil em uma verdadeira identidade Eco.`:"Sua jornada começa agora. Complete sua primeira missão para registrar seu primeiro marco no legado Eco.";
}

function renderAll(){renderStats();renderMap();renderMissions();renderAchievements();renderShop();renderStory();updateCampaign();renderPass()}
function renderStats(){
 let stars=Math.max(0,Math.floor(Number(state.stars)||0));
 let coins=Math.max(0,Math.floor(Number(state.coins)||0));
 let trophies=Math.max(0,Math.floor(Number(state.trophies)||0));
 let level=Math.max(1,Math.floor(Number(state.level)||1));
 $("stars").textContent=stars;
 $("coins").textContent=coins;
 $("trophies").textContent=trophies;
 $("playerLevel").textContent=level;
 $("shopStars").textContent=stars;
 $("shopCoins").textContent=coins;
 if($("homeLevel"))$("homeLevel").textContent=level;
 if($("homeStarMini"))$("homeStarMini").textContent=stars;
 if($("homeCoinMini"))$("homeCoinMini").textContent=coins;
 if($("homeTrophyMini"))$("homeTrophyMini").textContent=trophies;
 let xp=Math.max(0,Math.floor(Number(state.score)||0))%1500;
 let pct=Math.max(0,Math.min(100,xp/1500*100));
 if($("homeLevelProg"))$("homeLevelProg").style.width=pct+"%";
 if($("homeXpText"))$("homeXpText").textContent=xp.toLocaleString("pt-BR")+" / 1.500 XP";
 if($("homeNextLevel"))$("homeNextLevel").textContent=(1500-xp).toLocaleString("pt-BR")+" XP";
}
function updateCampaign(){
 let areas=Math.max(0,Math.min(phases.length,Number(state.unlocked||1)-1));
 let chapters=Math.max(0,Math.min(storyChapters.length,Number(state.storyProgress||0)));
 let areaPct=areas/phases.length*100,storyPct=chapters/storyChapters.length*100;
 let p=Math.round(areaPct*.6+storyPct*.4);
 $("campProg").style.width=p+"%";
 $("campPercent").textContent=p+"%";
 $("campAreas").textContent=`${areas}/${phases.length}`;
 $("campChapters").textContent=`${chapters}/${storyChapters.length}`;
 $("campWins").textContent=Number(state.wins||0);
 $("campLevel").textContent=Number(state.level||1);
 let next="🎯 Próximo objetivo: continue a campanha.";
 if(areas<phases.length) next=`🎯 Próximo objetivo: liberar ${phases[areas].name}.`;
 else if(chapters<storyChapters.length) next=`📖 Próximo objetivo: concluir ${storyChapters[chapters].title}.`;
 else next="🏆 Campanha completa! Continue jogando para dominar as fases e conquistas.";
 $("campNext").textContent=next;
 $("campText").textContent=`${areas} de ${phases.length} áreas liberadas • ${chapters} de ${storyChapters.length} capítulos concluídos • ${Number(state.wins||0)} vitórias`;
 $("campTitle").textContent=p>=100?"Campanha concluída!":p>=75?"Você está perto do final!":p>=40?"Sua jornada está ganhando força!":"Sua jornada está começando";
}
function renderMap(){
 let e=$("levels");e.innerHTML="";
 phases.forEach((p,i)=>{let unlocked=i<state.unlocked,c=document.createElement("div");c.className="card level"+(unlocked?"":" locked");let d=unlocked?`<button class="btn primary" onclick="startGame(${i})">Jogar</button>`:`<button class="btn" disabled>🔒 Bloqueada</button>`;c.innerHTML=`<div><div class="icon">${p.icon}</div><div style="margin-top:6px"><span class="tag ${i>=5?"boss":i>=3?"insane":i>=2?"extreme":""}">${p.difficulty}</span></div><h3>${p.name}</h3><p class="small">${p.desc}</p></div><div><div class="small">⏱️ ${p.time}s • ❤️ ${p.lives} • 📦 ${p.items} resíduos</div><div class="progress"><i style="width:${unlocked?100:0}%"></i></div>${d}</div>`;e.appendChild(c)})
}
function renderMissions(){
 let e=$("missionList");e.innerHTML="";
 missions.forEach(m=>{let val=missionValue(m.type),done=val>=m.goal,claimed=!!state.claimedMissions[m.id],pct=Math.min(100,val/m.goal*100),c=document.createElement("div");c.className="row mission-row "+(done?"done":"")+(claimed?" claimed":"");c.innerHTML=`<div class="ico">${m.icon}</div><div style="flex:1;min-width:0"><div class="mission-top"><b>${m.name}</b><span class="mission-state">${claimed?"✓ RESGATADA":done?"✨ CONCLUÍDA":"EM ANDAMENTO"}</span></div><div class="small mission-desc">${m.desc}</div><div class="progress"><i style="width:${pct}%"></i></div><div class="small mission-meta">${Math.min(val,m.goal)} / ${m.goal} • Recompensa: <b>🪙 ${m.reward}</b>${m.starReward?` + <b>⭐ ${m.starReward}</b>`:""}</div></div><button class="btn ${done&&!claimed?"gold":"ghost"}" ${!done||claimed?"disabled":""} onclick="claimMission('${m.id}')">${claimed?"✓ Resgatada":done?"Resgatar":"Ver progresso"}</button>`;e.appendChild(c)})
}
function missionValue(t){return t==="correct"?state.totalCorrect:t==="streak"?state.bestStreak:t==="coins"?state.coins:t==="wins"?state.wins:t==="unlocked"?state.unlocked:t==="answered"?state.totalAnswered:t==="perfect"?state.perfect:t==="stars"?state.stars:t==="story"?state.storyProgress:0}
function claimMission(id){let m=missions.find(x=>x.id===id);if(!m||state.claimedMissions[id]||missionValue(m.type)<m.goal)return;state.claimedMissions[id]=1;state.coins+=m.reward;state.score+=40;if(m.starReward)state.stars+=m.starReward;toast(`🎯 Missão concluída! +${m.reward} moedas${m.starReward?` e +${m.starReward}⭐`:""}`);sound("win");save();renderAll()}
function achievementValue(type){
 if(type==="wins")return Number(state.wins)||0;
 if(type==="bestStreak")return Number(state.bestStreak)||0;
 if(type==="coins")return Number(state.coins)||0;
 if(type==="stars")return Number(state.stars)||0;
 if(type==="unlocked")return Number(state.unlocked)||0;
 if(type==="perfect")return Number(state.perfect)||0;
 if(type==="correct")return Number(state.totalCorrect)||0;
 if(type==="answered")return Number(state.totalAnswered)||0;
 if(type==="story")return Number(state.storyProgress)||0;
 return 0;
}
function renderAchievements(){
 let e=$("achievementList");if(!e)return;e.innerHTML="";
 let unlockedCount=0;
 achievements.forEach(a=>{
   let val=achievementValue(a.type),done=val>=a.goal,claimed=!!state.unlockedAchievements[a.id];
   if(done)unlockedCount++;
   if(done&&!claimed){state.unlockedAchievements[a.id]=1;state.trophies++;state.coins+=20;save();setTimeout(()=>toast(`🏆 Conquista desbloqueada: ${a.name} +20🪙`),80)}
   let pct=Math.min(100,(val/a.goal)*100);
   let c=document.createElement("div");
   c.className="card achievement "+(done?"unlocked":"");
   c.innerHTML=`<div class="achievement-head"><div class="shopicon">${a.icon}</div><div><div class="achievement-label">${done?"🏆 DESBLOQUEADA":"🔒 EM PROGRESSO"}</div><h3>${a.name}</h3></div></div><p class="small achievement-desc">${a.desc}</p><div class="progress achievement-progress"><i style="width:${pct}%"></i></div><div class="achievement-meta"><span>${Math.min(val,a.goal)} / ${a.goal}</span><span>${done?"Concluída":"Faltam "+Math.max(0,a.goal-val)}</span></div>`;
   e.appendChild(c);
 });
 let counter=$("achievementCounter");if(counter)counter.textContent=`${unlockedCount} / ${achievements.length} desbloqueadas`;
}
function renderShop(){
 let equip=$("shopList"),rare=$("shopRareList");equip.innerHTML="";rare.innerHTML="";
 shopItems.forEach(s=>{let have=state.inventory[s.id]||0,c=document.createElement("div");c.className="card shopitem "+(s.cat==="rare"?"rare":"");c.innerHTML=`<div><div class="shopicon">${s.icon}</div><h3>${s.name}</h3><p class="small">${s.desc}</p></div><div><div class="price">🪙 ${s.price} • Possui: ${have}</div><button class="btn gold" style="width:100%;margin-top:8px" ${state.coins<s.price||have>=s.max?"disabled":""} onclick="buy('${s.id}')">${have>=s.max?"✓ Adquirido":"Comprar por "+s.price+" 🪙"}</button></div>`;(s.cat==="rare"?rare:equip).appendChild(c)})
}
function buy(id){let s=shopItems.find(x=>x.id===id);if(!s||state.coins<s.price||(state.inventory[id]||0)>=s.max)return;if(state.settings.confirmBuy&&!confirm(`Comprar ${s.name} por ${s.price} moedas?`))return;state.coins-=s.price;state.inventory[id]=(state.inventory[id]||0)+1;save();toast(`🛒 ${s.name} comprado!`);sound("win");renderAll()}

function makeRound(pool,n){let a=[];for(let i=0;i<n;i++)a.push(pool[Math.floor(Math.random()*pool.length)]);return a}
function startGame(index,storyMode=false){
 if(index>=state.unlocked)return;
 if(storyMode && index>Number(state.storyProgress||0))return;
 stopMusic();
 let p=phases[index],rounds=makeRound(p.pool,p.items),lives=p.lives+(state.inventory.life?1:0),time=p.time+(state.inventory.time?6:0);
 if(state.inventory.life)state.inventory.life--;if(state.inventory.time)state.inventory.time--;
 game={index,p,rounds,pos:0,lives,timeLeft:time,streak:0,shield:state.inventory.shield,double:state.inventory.double,magnet:state.inventory.magnet,heart:state.inventory.heart,answered:0,correct:0,started:Date.now(),story:!!storyMode};window.game=game;
 state.totalAnswered=state.totalAnswered;save();
 $("phaseName").textContent=p.name;$("difficultyText").textContent=`${p.difficulty} • ${p.items} resíduos`;show("game");nextRound();clearInterval(timerId);timerId=setInterval(tick,1000);sound("win");startMusic()
}
function nextRound(){
 if(!game)return;
 if(game.pos>=game.rounds.length){winGame();return}
 let it=game.rounds[game.pos];$("wasteEmoji").textContent=it[0];$("wasteName").textContent=it[1];$("roundTag").textContent=`${game.pos+1}/${game.rounds.length}`;
 if(state.settings.tips && game.pos===0) setTimeout(()=>toast("💡 Dica: observe o material e escolha a lixeira correta. Sequências longas aumentam sua recompensa!"),120);$("lives").textContent=game.lives;$("streak").textContent=game.streak;$("levelProg").style.width=(game.pos/game.rounds.length*100)+"%";$("feedback").textContent="";$("comboText").textContent=game.streak>=3?`🔥 Sequência x${game.streak}`:"";$("shieldCount").textContent=game.shield;$("doubleCount").textContent=game.double}
function tick(){if(!game)return;game.timeLeft--;let s=Math.max(0,game.timeLeft);$("timer").textContent=`00:${String(s).padStart(2,"0")}`;$("timer").classList.toggle("danger",s<=8);if(s<=0)loseGame("⏱️ Tempo esgotado!")}
function answer(type){
 if(!game)return;
 let it=game.rounds[game.pos],ok=type===it[2];game.answered++;state.totalAnswered++;
 if(ok){
   game.correct++;game.streak++;state.totalCorrect++;state.bestStreak=Math.max(state.bestStreak,game.streak);
   let pts=100+game.streak*15;if(game.double>0){pts*=2;game.double--}let coins=2+(game.streak>=5?2:0);if(game.magnet>0){coins+=2;game.magnet--}
   state.score+=pts;let starGain=Math.max(5,Math.floor(pts*0.25));state.stars+=starGain;state.coins+=coins;game.pos++;
   $("feedback").innerHTML=`<span class="oktext">✅ Correto! +${starGain}⭐ +${coins}🪙</span>`;sound("ok");vibe(25);
   if(game.streak>=5)toast(`🔥 Combo x${game.streak}!`);
   save();checkLevel();setTimeout(nextRound,110);
 }else{
   game.streak=0;
   if(game.shield>0){game.shield--;$("feedback").innerHTML=`<span class="dangertext">🛡️ Escudo ativado! Você continua.</span>`;sound("bad");vibe(70);save();setTimeout(nextRound,180);return}
   game.lives--;sound("bad");vibe(120);
   if(game.lives<=0){loseGame("💥 Você ficou sem vidas!");return}
   $("feedback").innerHTML=`<span class="dangertext">❌ Separação errada! Vida perdida.</span>`;$("lives").textContent=game.lives;setTimeout(nextRound,280)
 }
}
function useBoost(id){
 if(!game)return toast("Jogue uma fase para usar equipamentos.");
 if(id==="shield"&&game.shield>0){game.shield--;toast("🛡️ Escudo equipado");}
 else if(id==="double"&&game.double>0){game.double--;toast("⭐ Bônus ativado");}
 else toast("Você não possui esse item.");
 save();nextRound()
}
function checkLevel(){let n=1+Math.floor(state.score/1500);if(n>state.level){state.level=n;toast(`⬆️ Nível ${n}!`)}}
function winGame(){
 if(!game)return;clearInterval(timerId);timerId=null;stopMusic();
 let perfect=game.correct===game.answered;state.wins++;if(perfect)state.perfect++;
 let winStars=Math.max(15,25+game.streak*3);state.score+=100+game.streak*10;state.stars+=winStars;state.coins+=35+game.p.items;
 let i=game.index;if(i+1===state.unlocked&&state.unlocked<phases.length)state.unlocked++;
 let storyWin=!!game.story,storyBonus=0;
 if(storyWin){ if(i===Number(state.storyProgress||0))state.storyProgress=Math.min(storyChapters.length,i+1); storyBonus=15+(i*5); state.stars+=storyBonus; }
 if(game.lives===game.p.lives&&perfect)state.trophies++;
 state.inventory.heart=Math.max(0,state.inventory.heart);
 save();
 if(window.lanOnline?.finish)window.lanOnline.finish();
 sound("win");renderAll();
 openModal(storyWin?"📖":(perfect?"🏆":"🎉"),storyWin?"CAPÍTULO CONCLUÍDO!":(perfect?"FASE PERFEITA!":"MISSÃO CONCLUÍDA!"),`${game.p.name}<br><br>Acertos: ${game.correct}/${game.rounds.length}<br>⭐ +${winStars} • 🪙 +${35+game.p.items}${storyWin?`<br>📖 Bônus da história: +${storyBonus}⭐`: ""}${perfect?"<br><br>🏆 Troféu de precisão!":""}`,storyWin?()=>show("story"):null);
 game=null;window.game=null
}
function loseGame(msg){if(!game)return;clearInterval(timerId);timerId=null;stopMusic();if(window.lanOnline?.finish)window.lanOnline.finish();openModal("💥","MISSÃO FALHOU",`${msg}<br><br>Você chegou a ${game.pos}/${game.rounds.length} resíduos.<br>Não desista: tente de novo.`);sound("bad");game=null;window.game=null}
function confirmExit(){if(!game)return;clearInterval(timerId);timerId=null;stopMusic();game=null;window.game=null;if(window.lanOnline?.finish)window.lanOnline.finish();show("map");toast("↩️ Você saiu da missão.")}
let modalAction=null;
function openModal(icon,title,text,action=null){modalAction=typeof action==="function"?action:null;$("modalIcon").textContent=icon;$("modalTitle").textContent=title;$("modalText").innerHTML=text;$("modal").classList.add("show")}
function closeModal(){modalAction=null;$("modal").classList.remove("show");show("map")}
function resetGame(){
 if(!confirm("Apagar TODO o progresso, moedas, troféus, compras, conquistas e fases desbloqueadas?"))return;
 try{
  localStorage.removeItem("ecoColetaV2");
  localStorage.removeItem("ecoColeta");
 }catch(e){}
 state={score:0,stars:0,coins:0,trophies:0,level:1,unlocked:1,wins:0,bestStreak:0,perfect:0,totalCorrect:0,totalAnswered:0,passPremium:false,passClaims:{},passStickers:0,inventory:{life:0,shield:0,double:0,time:0,magnet:0,heart:0},claimedMissions:{},unlockedAchievements:{},settings:{music:true,sound:true,vibe:true,musicVol:30,soundVol:45,vibeVol:60,tips:true,notify:true,reducedMotion:false,confirmBuy:true},storyProgress:0};
 game=null;timerId=null;stopMusic();
 try{ sessionStorage.clear(); }catch(e){}
 toast("🗑️ Progresso apagado! Recarregando...");
 setTimeout(()=>location.reload(),120);
}

load();renderAll();syncSettings();
setTimeout(()=>{let b=$("loadbar"),t=$("loadtext"),card=$("startCard"),button=$("startGameButton");let n=0,id=setInterval(()=>{n+=10;b.style.width=n+"%";t.textContent=n<100?`Preparando o jogo ${n}%`:`Tudo pronto!`;if(n>=100){clearInterval(id);card.classList.add("ready");button.focus();}},45);button.addEventListener("click",async()=>{
  try{
    const root=document.documentElement;
    if(!document.fullscreenElement && root.requestFullscreen){await root.requestFullscreen({navigationUI:"hide"});}
  }catch(e){}
  document.body.classList.add("fullscreen-active");
  $("loading").classList.add("hidden");
  show("home");
},{once:true})},100);
document.addEventListener("click",()=>{if(state.settings.music)startMusic()},{once:true});
document.addEventListener("fullscreenchange",()=>{if(!document.fullscreenElement)document.body.classList.remove("fullscreen-active");else document.body.classList.add("fullscreen-active")});
