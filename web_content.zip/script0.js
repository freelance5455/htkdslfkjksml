
(() => {
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const root = document.documentElement;
  const state = { currency: localStorage.getItem('fc_currency') || 'USD', theme: localStorage.getItem('fc_theme') || 'light', currentCalc:null, currentResult:null };
  const currencyMeta = {USD:'$',EUR:'€',GBP:'£',INR:'₹',CAD:'C$',AUD:'A$',CHF:'CHF ',JPY:'¥',NZD:'NZ$'};
  const calculators = [
    {id:'loan',group:'Loans',name:'Loan Payment',desc:'Monthly payment, interest & total',icon:'loan'},
    {id:'mortgage',group:'Loans',name:'Mortgage',desc:'Payment, tax & insurance',icon:'home'},
    {id:'payoff',group:'Loans',name:'Loan Payoff',desc:'Payoff time & interest saved',icon:'calendar'},
    {id:'mutual',group:'Investing',name:'Mutual Fund Return',desc:'Regular or lump-sum growth',icon:'growth'},
    {id:'compound',group:'Investing',name:'Compound Interest',desc:'Flexible compounding',icon:'chart'},
    {id:'investment',group:'Investing',name:'Investment Return',desc:'Growth and annualized return',icon:'trend'},
    {id:'savings',group:'Savings',name:'Savings Growth',desc:'Recurring deposits & interest',icon:'savings'},
    {id:'goal',group:'Savings',name:'Savings Goal',desc:'Required regular deposit',icon:'target'},
    {id:'tax',group:'Everyday',name:'Tax / VAT',desc:'Add or remove tax',icon:'tax'},
    {id:'tip',group:'Everyday',name:'Tip Calculator',desc:'Tip and bill split',icon:'tip'},
    {id:'percent',group:'Everyday',name:'Percentage',desc:'4 quick percentage tools',icon:'percent'}
  ];
  const currency = () => currencyMeta[state.currency] || '$';
  const money = n => `${currency()}${Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2})}`;
  const num = v => Number(String(v).replace(/,/g,'')) || 0;
  const clamp = (v,min,max) => Math.min(max,Math.max(min,v));
  const fmt = n => Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2});
  function icon(name,size=18){
    const paths = {
      grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
      compare:'<path d="M5 7h14M5 12h14M5 17h14"/><path d="M8 4 5 7l3 3M16 9l3 3-3 3"/>',
      bookmark:'<path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-3.5L6 21z"/>',
      settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .36 2l.06.06-1.86 1.86-.06-.06a1.8 1.8 0 0 0-2-.36 1.8 1.8 0 0 0-1.1 1.65v.08h-2.63v-.08A1.8 1.8 0 0 0 11.07 18.5a1.8 1.8 0 0 0-2-.36l-.06.06-1.86-1.86.06-.06a1.8 1.8 0 0 0 .36-2A1.8 1.8 0 0 0 5.9 13.2h-.08v-2.63h.08A1.8 1.8 0 0 0 7.57 9.47a1.8 1.8 0 0 0-.36-2l-.06-.06L9.01 5.55l.06.06a1.8 1.8 0 0 0 2 .36A1.8 1.8 0 0 0 12.17 4.3v-.08h2.63v.08A1.8 1.8 0 0 0 15.9 5.95a1.8 1.8 0 0 0 2-.36l.06-.06 1.86 1.86-.06.06a1.8 1.8 0 0 0-.36 2 1.8 1.8 0 0 0 1.65 1.1h.08v2.63h-.08A1.8 1.8 0 0 0 19.4 15z"/>' ,
      search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
      back:'<path d="m15 18-6-6 6-6"/>',
      chevron:'<path d="m9 6 6 6-6 6"/>',
      share:'<path d="M12 4v12"/><path d="m7 9 5-5 5 5"/><path d="M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/>',
      save:'<path d="M6 4h12v17l-6-3.5L6 21z"/>',
      moon:'<path d="M20.8 15.5A8.8 8.8 0 0 1 8.5 3.2 8.9 8.9 0 1 0 20.8 15.5z"/>',
      sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
      loan:'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h14V9.5"/><path d="M9 20v-5h6v5"/><circle cx="17.5" cy="6" r="2.5"/>',
      home:'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h14V9.5"/><path d="M9 20v-5h6v5"/>',
      calendar:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/><path d="m9 15 2 2 4-4"/>',
      growth:'<path d="M4 18V6M4 18h16"/><path d="m6 15 4-4 3 2 5-6"/><path d="M15 7h3v3"/>',
      chart:'<path d="M4 18V6M4 18h16"/><rect x="6" y="12" width="2.5" height="4" rx=".5"/><rect x="11" y="9" width="2.5" height="7" rx=".5"/><rect x="16" y="6" width="2.5" height="10" rx=".5"/>',
      trend:'<path d="M4 18V6M4 18h16"/><path d="m6 15 4-4 3 2 5-6"/><path d="m16 7 3-1v3"/>',
      savings:'<path d="M5 9h8a4 4 0 0 1 4 4v4H7a2 2 0 0 1-2-2V9Z"/><path d="M7 9V7a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M17 12h2.5a1.5 1.5 0 0 1 0 3H17"/>',
      target:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="m12 2 1.2 3"/>',
      tax:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h2M14 11h2M8 15h2M14 15h2M8 19h8"/>',
      tip:'<path d="M7 4h10v16H7z"/><path d="M9 7h6M9 11h6M9 15h2M13 15h2M9 18h6"/>',
      percent:'<circle cx="7" cy="7" r="2.2"/><circle cx="17" cy="17" r="2.2"/><path d="m6 18 12-12"/>'
    };
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.grid}</svg>`;
  }
  $$('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon,17));
  $('#searchIcon').innerHTML=icon('search',19);
  function applyTheme(){root.dataset.theme=state.theme==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):state.theme; $('#themeBtn').innerHTML=icon(root.dataset.theme==='dark'?'sun':'moon',18)}
  applyTheme();
  $('#themeBtn').addEventListener('click',()=>{state.theme=root.dataset.theme==='dark'?'light':'dark';localStorage.setItem('fc_theme',state.theme);applyTheme()});

  function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove('show'),1700)}
  function setView(name){$$('.view').forEach(v=>v.classList.remove('active'));$('#'+name+'View').classList.add('active');$$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.nav===name));window.scrollTo({top:0,behavior:'smooth'})}
  $$('.nav-btn').forEach(b=>b.addEventListener('click',()=>{
    if(b.dataset.nav==='home') setView('home');
    if(b.dataset.nav==='compare') renderCompare();
    if(b.dataset.nav==='saved') renderSaved();
    if(b.dataset.nav==='settings') renderSettings();
  }));

  function readList(key){try{return JSON.parse(localStorage.getItem(key)||'[]')}catch{return []}}
  function writeList(key,val){localStorage.setItem(key,JSON.stringify(val))}
  function pushRecent(item){const arr=readList('fc_history').filter(x=>x.id!==item.id);arr.unshift(item);writeList('fc_history',arr.slice(0,12));renderRecent()}
  function saveItem(item){const arr=readList('fc_saved').filter(x=>x.id!==item.id);arr.unshift(item);writeList('fc_saved',arr.slice(0,50));toast('Calculation saved');}
  function baseItem(calcId,label,summary,values,result){return {id:calcId+'-'+Date.now(),calcId,label,summary,values,result,created:Date.now()}}
  function renderRecent(){const row=$('#recentRow'),arr=readList('fc_history'); if(!arr.length){row.innerHTML='<div class="recent-chip" style="cursor:default;color:var(--muted)">Your calculations will appear here</div>';return} row.innerHTML=arr.slice(0,8).map((x,i)=>`<button class="recent-chip" data-open="${i}">${icon(x.calcId==='mutual'?'growth':x.calcId==='loan'?'loan':'chart',14)} ${x.label} · ${x.result}</button>`).join(''); $$('.recent-chip[data-open]').forEach(btn=>btn.addEventListener('click',()=>openHistory(Number(btn.dataset.open))))}
  function openHistory(i){const item=readList('fc_history')[i];if(!item)return;openCalc(item.calcId,item.values)}
  $('#clearRecent').addEventListener('click',()=>{localStorage.removeItem('fc_history');renderRecent();toast('Recent calculations cleared')});

  function cardVisual(id){
    const stroke='stroke="currentColor"';
    const art={
      loan:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 33h60" opacity=".22"/><path d="M8 28 20 23 30 26 42 17 52 19 64 9"/><circle cx="64" cy="9" r="2.4" fill="currentColor" stroke="none"/></svg>`,
      mortgage:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 22 25 8l18 14"/><path d="M13 21v14h24V21"/><path d="M21 35V26h8v9"/><path d="M48 33h16M48 27h11M48 21h6" opacity=".68"/></svg>`,
      payoff:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="7" width="28" height="27" rx="4"/><path d="M15 5v5M29 5v5M8 15h28"/><path d="M48 27h5M48 22h9M48 17h13" opacity=".78"/><path d="m52 13 4-4 6 6"/><path d="M58 9h4v4"/></svg>`,
      mutual:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 33h58" opacity=".22"/><path d="M9 29c7-3 9-8 16-7 6 1 7 8 13 6 8-3 10-11 25-17"/><path d="M56 11h9v9"/></svg>`,
      compound:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M8 34h56" opacity=".22"/><path d="M14 34V25M25 34V20M36 34V15M47 34V10M58 34V6"/><path d="m54 8 4-2 0 5"/></svg>`,
      investment:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 33h58" opacity=".22"/><path d="M9 29 21 26 31 28 41 19 52 20 63 9"/><path d="M56 9h7v7"/></svg>`,
      savings:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M10 28c0-6 5-9 11-9h19c5 0 9 4 9 9v6H20c-6 0-10-3-10-6Z"/><path d="M18 19V11c0-3 2-5 5-5h8c3 0 5 2 5 5v8"/><circle cx="49" cy="28" r="3"/></svg>`,
      target:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="27" cy="22" r="13"/><circle cx="27" cy="22" r="7"/><circle cx="27" cy="22" r="2.2" fill="currentColor" stroke="none"/><path d="m40 13 8-7M44 6h7v7"/></svg>`,
      tax:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="5" width="25" height="31" rx="4"/><path d="M14 12h13M14 18h4M23 18h4M14 24h4M23 24h4M14 30h13"/><path d="m49 31 9-20M48 12h4M53 12h4M58 31h4M53 31h4"/></svg>`,
      tip:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="6" width="25" height="30" rx="4"/><path d="M15 14h13M15 20h13M15 26h5M24 26h4"/><path d="M53 8v25M45 16h16M48 12l10 18" opacity=".8"/></svg>`,
      percent:`<svg viewBox="0 0 72 42" ${stroke} fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="13" r="4"/><circle cx="52" cy="29" r="4"/><path d="M15 31 55 9"/></svg>`
    };
    return art[id]||art.loan;
  }
  function renderHome(filter=''){const host=$('#calcContent');const groups={};calculators.filter(c=>(c.name+' '+c.desc+' '+c.group).toLowerCase().includes(filter.toLowerCase())).forEach(c=>(groups[c.group]??=[]).push(c));host.innerHTML=Object.keys(groups).map(g=>`<section class="section"><div class="category-title">${g}</div><div class="calc-grid">${groups[g].map(c=>`<button class="calc-card" data-calc="${c.id}"><div><div class="card-top"><div class="calc-icon">${icon(c.icon,18)}</div><div class="card-art" aria-hidden="true">${cardVisual(c.id)}</div></div><div class="card-copy"><h3>${c.name}</h3><p>${c.desc}</p></div></div><div class="card-footer"><span class="card-tag">${g}</span><span class="card-arrow">${icon('chevron',13)}</span></div></button>`).join('')}</div></section>`).join('') || '<div class="history-empty">No calculators found.</div>'; $$('.calc-card',host).forEach(b=>b.addEventListener('click',()=>openCalc(b.dataset.calc)));}
  $('#searchInput').addEventListener('input',e=>renderHome(e.target.value));
  renderRecent();renderHome();

  function input(label,id,value='',type='number',attrs=''){
    const l=(label+' '+id).toLowerCase();
    const percent=/rate|percentage|interest|return/.test(l);
    const duration=/term|period|years|months/.test(l) && !/loanTerm|mortTerm/.test(id);
    const people=/people/.test(l);
    const moneyField=!duration && !people && /amount|price|balance|payment|contribution|deposit|investment|savings|bill|target|principal|premium|insurance|salary|value|tax/.test(l) && !percent;
    let affix='', cls='input-wrap';
    if(percent){affix='<span class="input-affix suffix">%</span>';cls+=' has-suffix';}
    else if(moneyField){affix=`<span class="input-affix prefix">${currency()}</span>`;}
    else if(duration){
      const durationUnit=/months?/.test(l)?'mo':'yr';
      affix=`<span class="input-affix suffix">${durationUnit}</span>`;cls+=' has-suffix';
    }
    else if(people){affix='<span class="input-affix suffix">people</span>';cls+=' has-suffix';}
    return `<div class="field"><label for="${id}">${label}</label><div class="${cls}"><input id="${id}" type="${type}" value="${value}" ${attrs}/>${affix}</div></div>`
  }
  function selectField(label,id,opts,selected){return `<div class="field"><label for="${id}">${label}</label><select id="${id}">${opts.map(o=>`<option value="${o[0]}" ${o[0]===selected?'selected':''}>${o[1]}</option>`).join('')}</select></div>`}
  function calcShell(title,subtitle,body){return `<div class="back-row"><button class="icon-btn" id="backCalc">${icon('back',19)}</button><div><h2>${title}</h2><p class="subtle">${subtitle}</p></div></div>${body}<div id="calcResult"></div>`}
  function openCalc(id, values={}){state.currentCalc=id;state.currentResult=null;setView('calc');renderCalc(id,values)}
  function commonCalcData(id, v){
    const D={};
    if(id==='loan') return {title:'Loan Payment',subtitle:'Estimate periodic payment and total cost',body:`<div class="panel">${input('Loan amount','loanAmt',v.loanAmt??25000)}${input('Interest rate (p.a.)','loanRate',v.loanRate??6.5)}<div class="field-row">${input('Loan term','loanTerm',v.loanTerm??5,'number','step="1"')} ${selectField('Term','loanUnit',[['years','Years'],['months','Months']],v.loanUnit??'years')}</div>${selectField('Payment frequency','loanFreq',[['12','Monthly'],['26','Biweekly'],['52','Weekly']],v.loanFreq??'12')}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='mortgage') return {title:'Mortgage',subtitle:'Estimate principal, interest, tax and insurance',body:`<div class="panel">${input('Home price','mortPrice',v.mortPrice??300000)}${input('Down payment','mortDown',v.mortDown??60000)}${input('Interest rate (p.a.)','mortRate',v.mortRate??6.2)}<div class="field-row">${input('Loan term','mortTerm',v.mortTerm??30,'number','step="1"')} ${selectField('Term','mortUnit',[['years','Years'],['months','Months']],v.mortUnit??'years')}</div><div class="field-row">${input('Property tax / year','mortTax',v.mortTax??0)}${input('Insurance / year','mortIns',v.mortIns??0)}</div></div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='payoff') return {title:'Loan Payoff',subtitle:'See how extra payments change payoff time',body:`<div class="panel">${input('Remaining balance','payBal',v.payBal??18500)}${input('Interest rate (p.a.)','payRate',v.payRate??6.5)}${input('Current payment','payPmt',v.payPmt??400)}${input('Extra payment','payExtra',v.payExtra??100)}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='mutual') return {title:'Mutual Fund Return',subtitle:'Estimate growth from regular or lump-sum investing',body:`<div class="panel"><div class="segmented"><button class="mode active" data-mode="regular">Regular investment</button><button class="mode" data-mode="lump">Lump sum</button></div><div id="mutualFields">${input('Monthly contribution','mfAmt',v.mfAmt??500)}${input('Expected annual return','mfRate',v.mfRate??12)}${input('Investment period','mfYears',v.mfYears??15)}</div></div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='compound') return {title:'Compound Interest',subtitle:'Model growth with compounding and contributions',body:`<div class="panel">${input('Starting amount','ciStart',v.ciStart??5000)}${input('Monthly contribution','ciMonthly',v.ciMonthly??200)}${input('Annual return','ciRate',v.ciRate??7)}${input('Investment period (years)','ciYears',v.ciYears??10)}${selectField('Compounding','ciComp',[['12','Monthly'],['4','Quarterly'],['1','Annually']],v.ciComp??'12')}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='investment') return {title:'Investment Return',subtitle:'Estimate growth and annualized return',body:`<div class="panel">${input('Initial investment','invStart',v.invStart??10000)}${input('Monthly contribution','invMonthly',v.invMonthly??300)}${input('Expected annual return','invRate',v.invRate??8)}${input('Investment period (years)','invYears',v.invYears??10)}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='savings') return {title:'Savings Growth',subtitle:'Estimate savings with recurring deposits',body:`<div class="panel">${input('Starting balance','svStart',v.svStart??1000)}${input('Monthly deposit','svMonthly',v.svMonthly??300)}${input('Interest rate (p.a.)','svRate',v.svRate??4)}${input('Saving period (years)','svYears',v.svYears??5)}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='goal') return {title:'Savings Goal',subtitle:'Find the regular amount needed to reach a target',body:`<div class="panel">${input('Target amount','goalTarget',v.goalTarget??10000)}${input('Current savings','goalCurrent',v.goalCurrent??2000)}${input('Expected annual return','goalRate',v.goalRate??4)}${input('Time to goal (years)','goalYears',v.goalYears??2)}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='tax') return {title:'Tax / VAT',subtitle:'Add or remove a percentage-based tax',body:`<div class="panel"><div class="segmented"><button class="mode active" data-mode="add">Add tax</button><button class="mode" data-mode="remove">Remove tax</button></div>${input('Amount','taxAmt',v.taxAmt??100)}${input('Tax rate','taxRate',v.taxRate??20)}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='tip') return {title:'Tip Calculator',subtitle:'Tip, total bill and per-person split',body:`<div class="panel">${input('Bill amount','tipAmt',v.tipAmt??80)}${input('Tip percentage','tipRate',v.tipRate??18)}${input('Number of people','tipPeople',v.tipPeople??3)}</div><button class="primary-btn" id="doCalc">Calculate</button>`};
    if(id==='percent') return {title:'Percentage',subtitle:'Four quick percentage calculations',body:`<div class="panel"><div class="segmented" style="grid-template-columns:repeat(2,1fr)"><button class="mode active" data-mode="of">Percent of</button><button class="mode" data-mode="change">Increase / decrease</button></div><div id="percentFields">${input('Percentage','pctA',v.pctA??18)}${input('Value','pctB',v.pctB??250)}</div></div><button class="primary-btn" id="doCalc">Calculate</button>`};
    return null;
  }

  function readVals(id){const ids={loan:['loanAmt','loanRate','loanTerm','loanUnit','loanFreq'],mortgage:['mortPrice','mortDown','mortRate','mortTerm','mortUnit','mortTax','mortIns'],payoff:['payBal','payRate','payPmt','payExtra'],mutual:['mfAmt','mfRate','mfYears'],compound:['ciStart','ciMonthly','ciRate','ciYears','ciComp'],investment:['invStart','invMonthly','invRate','invYears'],savings:['svStart','svMonthly','svRate','svYears'],goal:['goalTarget','goalCurrent','goalRate','goalYears'],tax:['taxAmt','taxRate'],tip:['tipAmt','tipRate','tipPeople'],percent:['pctA','pctB']};const o={};(ids[id]||[]).forEach(k=>{const el=$('#'+k);if(el)o[k]=el.tagName==='SELECT'?el.value:num(el.value)});o._mode=$('.mode.active')?.dataset.mode||null;return o}

  function amortPayment(P, annualRate, periods, ppy){const r=annualRate/100/ppy;if(P<=0)return 0;if(r===0)return P/periods;const q=Math.pow(1+r,periods);return P*(r*q)/(q-1)}
  function fvRegular(payment, annualRate, years, ppy){const n=Math.round(years*ppy), r=annualRate/100/ppy;if(n<=0)return payment;if(r===0)return payment*n;return payment*((Math.pow(1+r,n)-1)/r)}
  function renderCalc(id, values={}){
    const D=commonCalcData(id,values);$('#calcView').innerHTML=calcShell(D.title,D.subtitle,D.body);$('#backCalc').addEventListener('click',()=>setView('home'));
    $$('.mode').forEach(btn=>btn.addEventListener('click',()=>{
      $$('.mode').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
      if(id==='mutual'){
        const f=$('#mutualFields');const regular=btn.dataset.mode==='regular';
        f.innerHTML=regular?`${input('Monthly contribution','mfAmt',values.mfAmt??500)}${input('Expected annual return','mfRate',values.mfRate??12)}${input('Investment period','mfYears',values.mfYears??15)}`:`${input('Lump-sum amount','mfAmt',values.mfAmt??5000)}${input('Expected annual return','mfRate',values.mfRate??12)}${input('Investment period','mfYears',values.mfYears??15)}`;
      }
      if(id==='percent'){
        const f=$('#percentFields');f.innerHTML=btn.dataset.mode==='of'?`${input('Percentage','pctA',values.pctA??18)}${input('Value','pctB',values.pctB??250)}`:`${input('Original value','pctA',values.pctA??200)}${input('New value','pctB',values.pctB??250)}`;
      }
    }));
    $('#doCalc').addEventListener('click',()=>calculate(id));
    if(values && Object.keys(values).length) calculate(id);
  }

  function calculate(id){
    const v=readVals(id); let r={};
    if(id==='loan'){const p=num(v.loanAmt), rate=num(v.loanRate), ppy=num(v.loanFreq), term=num(v.loanTerm), periods=Math.max(1,Math.round(v.loanUnit==='months'?term*ppy/12:term*ppy)); const payment=amortPayment(p,rate,periods,ppy);r={title:'Periodic payment',big:money(payment),a:['Total interest',money(Math.max(0,payment*periods-p))],b:['Total repayment',money(payment*periods)],note:'Estimate based on a fixed interest rate and regular payments.',chart:loanChart(p,rate,periods,ppy),chartTitle:'Balance over time',compare:v};}
    if(id==='mortgage'){const price=num(v.mortPrice),down=num(v.mortDown),P=Math.max(0,price-down),ppy=12,periods=Math.max(1,Math.round(num(v.mortTerm)*(v.mortUnit==='months'?1:12))),payment=amortPayment(P,num(v.mortRate),periods,ppy),extras=(num(v.mortTax)+num(v.mortIns))/12;r={title:'Estimated monthly payment',big:money(payment+extras),a:['Principal + interest',money(payment)],b:['Tax + insurance',money(extras)],note:`Loan amount: ${money(P)}. Taxes and insurance are optional estimates.`,chart:loanChart(P,num(v.mortRate),periods,ppy),chartTitle:'Balance over time',compare:v};}
    if(id==='payoff'){const P=num(v.payBal),annual=num(v.payRate),current=num(v.payPmt),extra=num(v.payExtra),r0=annual/100/12;let months=Infinity, monthsExtra=Infinity;if(r0===0){months=P/current;monthsExtra=P/(current+extra)}else if(current<=P*r0){months=Infinity;monthsExtra=extra>0&&current+extra>P*r0? -Math.log(1-r0*P/(current+extra))/Math.log(1+r0):Infinity}else{months=-Math.log(1-r0*P/current)/Math.log(1+r0);monthsExtra=-Math.log(1-r0*P/(current+extra))/Math.log(1+r0)} const interest=months===Infinity?Infinity:current*months-P, interest2=monthsExtra===Infinity?Infinity:(current+extra)*monthsExtra-P;r={title:'Current payoff estimate',big:months===Infinity?'Payment too low':`${Math.ceil(months)} months`,a:['Current interest',months===Infinity?'Not enough':money(interest)],b:['With extra payment',monthsExtra===Infinity?'No payoff':`${Math.ceil(monthsExtra)} months`],note:months!==Infinity&&monthsExtra!==Infinity?`Extra payment could save about ${Math.max(0,Math.ceil(months-monthsExtra))} months and ${money(Math.max(0,interest-interest2))} in interest.`:'Increase the regular payment above monthly interest.',chart:payoffChart(P,annual,current,extra),chartTitle:'Balance payoff',compare:v};}
    if(id==='mutual'){const regular=v._mode!=='lump', amount=num(v.mfAmt), rate=num(v.mfRate), years=num(v.mfYears), end=regular?fvRegular(amount,rate,years,12):amount*Math.pow(1+rate/100,years), invested=regular?amount*12*years:amount; r={title:'Estimated future value',big:money(end),a:['Total invested',money(invested)],b:['Estimated returns',money(end-invested)],note:'Estimated results based on your assumed return; actual mutual-fund returns are not guaranteed.',chart:growthChart(invested,end,years),chartTitle:'Growth over time',compare:v};}
    if(id==='compound'){const P=num(v.ciStart),m=num(v.ciMonthly),rate=num(v.ciRate),years=num(v.ciYears),ppy=num(v.ciComp),growth=P*Math.pow(1+rate/100/ppy,ppy*years)+fvRegular(m,rate,years,12),invested=P+m*12*years;r={title:'Estimated future value',big:money(growth),a:['Total invested',money(invested)],b:['Interest growth',money(growth-invested)],note:'Estimate assumes constant return and regular monthly contributions.',chart:growthChart(invested,growth,years),chartTitle:'Growth over time',compare:v};}
    if(id==='investment'){const P=num(v.invStart),m=num(v.invMonthly),rate=num(v.invRate),years=num(v.invYears),end=P*Math.pow(1+rate/100,years)+fvRegular(m,rate,years,12),invested=P+m*12*years;r={title:'Estimated final value',big:money(end),a:['Total invested',money(invested)],b:['Estimated growth',money(end-invested)],note:'Expected return is an assumption, not a guarantee.',chart:growthChart(invested,end,years),chartTitle:'Growth over time',compare:v};}
    if(id==='savings'){const P=num(v.svStart),m=num(v.svMonthly),rate=num(v.svRate),years=num(v.svYears),end=P*Math.pow(1+rate/100,years)+fvRegular(m,rate,years,12),invested=P+m*12*years;r={title:'Estimated savings balance',big:money(end),a:['Total deposits',money(invested)],b:['Interest earned',money(end-invested)],note:'Assumes a constant interest rate and monthly deposits.',chart:growthChart(invested,end,years),chartTitle:'Savings growth',compare:v};}
    if(id==='goal'){const target=num(v.goalTarget),current=num(v.goalCurrent),rate=num(v.goalRate),years=num(v.goalYears),n=Math.max(1,Math.round(years*12)),r0=rate/100/12,fvCurrent=current*Math.pow(1+r0,n),remaining=Math.max(0,target-fvCurrent),pmt=r0===0?remaining/n:remaining*r0/(Math.pow(1+r0,n)-1);r={title:'Required monthly saving',big:money(pmt),a:['Target',money(target)],b:['Starting savings',money(current)],note:`About ${money(pmt)} per month over ${fmt(years)} years at an assumed ${fmt(rate)}% return.`,chart:goalChart(target,current,rate,years),chartTitle:'Path to goal',compare:v};}
    if(id==='tax'){const amount=num(v.taxAmt),rate=num(v.taxRate),add=v._mode!=='remove'; const total=add?amount*(1+rate/100):amount/(1+rate/100);r={title:add?'Total after tax':'Amount before tax',big:money(total),a:[add?'Tax added':'Tax portion',money(add?total-amount:amount-total)],b:[add?'Original amount':'Tax-inclusive amount',money(amount)],note:add?`Adds ${fmt(rate)}% tax to the entered amount.`:`Removes ${fmt(rate)}% tax from the tax-inclusive amount.`,compare:v};}
    if(id==='tip'){const bill=num(v.tipAmt),rate=num(v.tipRate),people=Math.max(1,Math.round(num(v.tipPeople))),tip=bill*rate/100,total=bill+tip;r={title:'Total bill',big:money(total),a:['Tip',money(tip)],b:['Per person',money(total/people)],note:`${people} ${people===1?'person':'people'} · ${fmt(rate)}% tip`,compare:v};}
    if(id==='percent'){if(v._mode==='change'){const a=num(v.pctA),b=num(v.pctB),pct=a===0?0:(b-a)/Math.abs(a)*100;r={title:'Percentage change',big:`${fmt(pct)}%`,a:['Original',fmt(a)],b:['New value',fmt(b)],note:pct>=0?'Increase from original value.':'Decrease from original value.',compare:v};}else{const p=num(v.pctA),b=num(v.pctB),res=b*p/100;r={title:`${fmt(p)}% of value`,big:fmt(res),a:['Percentage',`${fmt(p)}%`],b:['Value',fmt(b)],note:'Quick percentage calculation.',compare:v};}}
    state.currentResult=r;state.currentValues=v;
    const chart=r.chart?`<div class="chart-card"><div class="chart-head"><strong>${r.chartTitle||'Overview'}</strong><span>Illustrative</span></div><div id="dynamicChart">${r.chart}</div></div>`:'';
    const config=whatIfConfig(id,v);
    const whatIf=config?`<div class="slider-card"><div class="slider-top"><span>What-If: ${config.label}</span><span id="whatRateVal">${config.format(config.value)}</span></div><input id="whatRate" type="range" min="${config.min}" max="${config.max}" step="${config.step}" value="${config.value}"><div class="range-labels"><span>${config.format(config.min)}</span><span>${config.format((config.min+config.max)/2)}</span><span>${config.format(config.max)}</span></div><div class="slider-foot"><span>${config.hint}</span><strong id="whatResult">Drag to explore</strong></div></div>`:'';
    $('#calcResult').innerHTML=`<div class="result-card flash"><div class="eyebrow">${r.title}</div><div class="result-big" id="resultBig">${r.big}</div><div class="metrics"><div class="metric"><small id="metricALabel">${r.a[0]}</small><strong id="metricAValue">${r.a[1]}</strong></div><div class="metric"><small id="metricBLabel">${r.b[0]}</small><strong id="metricBValue">${r.b[1]}</strong></div></div></div>${whatIf}${chart}<div class="result-actions"><button class="secondary-btn" id="saveResult">${icon('save',15)} Save</button><button class="secondary-btn" id="shareResult">${icon('share',15)} Share</button></div>${r.note?`<div class="disclaimer">${r.note}</div>`:''}`;
    const item=baseItem(id,calculators.find(c=>c.id===id)?.name||id,Object.values(v).filter(x=>x!==null&&x!==undefined).slice(0,3).join(' · '),v,r.big);pushRecent(item);
    $('#saveResult').addEventListener('click',()=>saveItem(item));$('#shareResult').addEventListener('click',()=>shareResult(item,r));
    const rateEl=$('#whatRate');if(rateEl){const update=()=>{const val=Number(rateEl.value);$('#whatRateVal').textContent=config.format(val);const pct=((val-Number(rateEl.min))/(Number(rateEl.max)-Number(rateEl.min)))*100;rateEl.style.setProperty('--range-pct',`${clamp(pct,0,100)}%`);const base={...v};config.apply(base,val);const temp=simulate(id,base);$('#whatResult').textContent=temp.preview||`New estimate: ${temp.big}`;$('#resultBig').textContent=temp.big;$('#metricALabel').textContent=temp.a?.[0]||r.a[0];$('#metricAValue').textContent=temp.a?.[1]||r.a[1];$('#metricBLabel').textContent=temp.b?.[0]||r.b[0];$('#metricBValue').textContent=temp.b?.[1]||r.b[1];if($('#dynamicChart')&&temp.chart){$('#dynamicChart').innerHTML=temp.chart}};rateEl.addEventListener('input',update);rateEl.dispatchEvent(new Event('input'));}
  }

  function whatIfConfig(id,v){
    const pct=x=>`${fmt(x)}%`, moneyFmt=x=>money(x);
    if(id==='loan') return {label:'interest rate',value:clamp(num(v.loanRate),0,20),min:0,max:20,step:.1,format:pct,hint:'See how your payment changes.',apply:(b,x)=>b.loanRate=x};
    if(id==='mortgage') return {label:'interest rate',value:clamp(num(v.mortRate),0,15),min:0,max:15,step:.1,format:pct,hint:'See how the payment changes.',apply:(b,x)=>b.mortRate=x};
    if(id==='payoff') return {label:'extra payment',value:clamp(num(v.payExtra),0,1000),min:0,max:1000,step:10,format:moneyFmt,hint:'Explore faster payoff with extra money.',apply:(b,x)=>b.payExtra=x};
    if(id==='mutual') return {label:'expected return',value:clamp(num(v.mfRate),0,20),min:0,max:20,step:.1,format:pct,hint:'Change the assumed annual return.',apply:(b,x)=>b.mfRate=x};
    if(id==='compound') return {label:'expected return',value:clamp(num(v.ciRate),0,20),min:0,max:20,step:.1,format:pct,hint:'Change the assumed annual return.',apply:(b,x)=>b.ciRate=x};
    if(id==='investment') return {label:'expected return',value:clamp(num(v.invRate),0,20),min:0,max:20,step:.1,format:pct,hint:'Change the assumed annual return.',apply:(b,x)=>b.invRate=x};
    if(id==='savings') return {label:'interest rate',value:clamp(num(v.svRate),0,15),min:0,max:15,step:.1,format:pct,hint:'See how interest affects savings.',apply:(b,x)=>b.svRate=x};
    if(id==='goal') return {label:'expected return',value:clamp(num(v.goalRate),0,15),min:0,max:15,step:.1,format:pct,hint:'See how growth affects the monthly target.',apply:(b,x)=>b.goalRate=x};
    if(id==='tax') return {label:'tax rate',value:clamp(num(v.taxRate),0,30),min:0,max:30,step:.5,format:pct,hint:'Adjust the tax instantly.',apply:(b,x)=>b.taxRate=x};
    if(id==='tip') return {label:'tip percentage',value:clamp(num(v.tipRate),0,30),min:0,max:30,step:1,format:pct,hint:'Adjust the tip instantly.',apply:(b,x)=>b.tipRate=x};
    return null;
  }

  function simulate(id,v){
    if(id==='loan'){const p=num(v.loanAmt),ppy=num(v.loanFreq),term=num(v.loanTerm),years=v.loanUnit==='months'?term/12:term,periods=Math.max(1,Math.round(v.loanUnit==='months'?term*ppy/12:term*ppy)),payment=amortPayment(p,num(v.loanRate),periods,ppy);return {big:money(payment),a:['Total interest',money(Math.max(0,payment*periods-p))],b:['Total repayment',money(payment*periods)],chart:loanChart(p,num(v.loanRate),periods,ppy),preview:`New payment: ${money(payment)}`};}
    if(id==='mortgage'){const price=num(v.mortPrice),down=num(v.mortDown),P=Math.max(0,price-down),periods=Math.max(1,Math.round(num(v.mortTerm)*(v.mortUnit==='months'?1:12))),payment=amortPayment(P,num(v.mortRate),periods,12),extras=(num(v.mortTax)+num(v.mortIns))/12,total=payment+extras;return {big:money(total),a:['Principal + interest',money(payment)],b:['Tax + insurance',money(extras)],chart:loanChart(P,num(v.mortRate),periods,12),preview:`New payment: ${money(total)}`};}
    if(id==='payoff'){const P=num(v.payBal),annual=num(v.payRate),current=num(v.payPmt),extra=num(v.payExtra),r=annual/100/12;let months,monthsExtra;if(r===0){months=P/current;monthsExtra=P/(current+extra)}else{months=current<=P*r?Infinity:-Math.log(1-r*P/current)/Math.log(1+r);monthsExtra=current+extra<=P*r?Infinity:-Math.log(1-r*P/(current+extra))/Math.log(1+r)}const interest=months===Infinity?Infinity:current*months-P, interest2=monthsExtra===Infinity?Infinity:(current+extra)*monthsExtra-P;return {big:months===Infinity?'Payment too low':`${Math.ceil(months)} months`,a:['Current interest',months===Infinity?'Not enough':money(interest)],b:['With extra payment',monthsExtra===Infinity?'No payoff':`${Math.ceil(monthsExtra)} months`],chart:payoffChart(P,annual,current,extra),preview:monthsExtra===Infinity?'No payoff at this rate':`With extra: ${Math.ceil(monthsExtra)} months`};}
    if(id==='mutual'){const regular=v._mode!=='lump',a=num(v.mfAmt),rr=num(v.mfRate),y=num(v.mfYears),end=regular?fvRegular(a,rr,y,12):a*Math.pow(1+rr/100,y),invested=regular?a*12*y:a;return {big:money(end),a:['Total invested',money(invested)],b:['Estimated returns',money(end-invested)],chart:growthChart(invested,end,y),preview:`New value: ${money(end)}`};}
    if(id==='compound'){const P=num(v.ciStart),m=num(v.ciMonthly),rr=num(v.ciRate),y=num(v.ciYears),ppy=num(v.ciComp),end=P*Math.pow(1+rr/100/ppy,ppy*y)+fvRegular(m,rr,y,12),invested=P+m*12*y;return {big:money(end),a:['Total invested',money(invested)],b:['Interest growth',money(end-invested)],chart:growthChart(invested,end,y),preview:`New value: ${money(end)}`};}
    if(id==='investment'){const P=num(v.invStart),m=num(v.invMonthly),rr=num(v.invRate),y=num(v.invYears),end=P*Math.pow(1+rr/100,y)+fvRegular(m,rr,y,12),invested=P+m*12*y;return {big:money(end),a:['Total invested',money(invested)],b:['Estimated growth',money(end-invested)],chart:growthChart(invested,end,y),preview:`New value: ${money(end)}`};}
    if(id==='savings'){const P=num(v.svStart),m=num(v.svMonthly),rr=num(v.svRate),y=num(v.svYears),end=P*Math.pow(1+rr/100,y)+fvRegular(m,rr,y,12),invested=P+m*12*y;return {big:money(end),a:['Total deposits',money(invested)],b:['Interest earned',money(end-invested)],chart:growthChart(invested,end,y),preview:`New balance: ${money(end)}`};}
    if(id==='goal'){const target=num(v.goalTarget),current=num(v.goalCurrent),rr=num(v.goalRate),y=num(v.goalYears),n=Math.max(1,Math.round(y*12)),r0=rr/100/12,fvCurrent=current*Math.pow(1+r0,n),remaining=Math.max(0,target-fvCurrent),pmt=r0===0?remaining/n:remaining*r0/(Math.pow(1+r0,n)-1);return {big:money(pmt),a:['Target',money(target)],b:['Starting savings',money(current)],chart:goalChart(target,current,rr,y),preview:`New monthly saving: ${money(pmt)}`};}
    if(id==='tax'){const amount=num(v.taxAmt),rr=num(v.taxRate),add=v._mode!=='remove',total=add?amount*(1+rr/100):amount/(1+rr/100);return {big:money(total),a:[add?'Tax added':'Tax portion',money(add?total-amount:amount-total)],b:[add?'Original amount':'Tax-inclusive amount',money(amount)],preview:`New total: ${money(total)}`};}
    if(id==='tip'){const bill=num(v.tipAmt),rr=num(v.tipRate),people=Math.max(1,Math.round(num(v.tipPeople))),tip=bill*rr/100,total=bill+tip;return {big:money(total),a:['Tip',money(tip)],b:['Per person',money(total/people)],preview:`New total: ${money(total)}`};}
    return {big:'—',a:[],b:[]};
  }

  function growthChart(invested,end,years){
    const w=440,h=150,pad=18, safeYears=Math.max(.1,years), span=Math.max(Math.abs(end),Math.abs(invested),1);const pts=[];
    for(let i=0;i<=24;i++){const t=i/24;const val=invested+(end-invested)*Math.pow(t,1.55);const y=h-pad-clamp((val-Math.min(invested,end))/(span||1),0,1)*(h-pad*2);pts.push([pad+t*(w-pad*2),clamp(y,pad,h-pad)]);}
    return chartSvg(pts,'Illustrative growth chart',true);
  }
  function loanChart(P,rate,periods,ppy){
    const w=440,h=150,pad=18,n=Math.max(2,Math.min(40,periods)),pay=amortPayment(P,rate,periods,ppy),r=rate/100/ppy;let bal=P;const vals=[bal];for(let i=0;i<n-1;i++){bal=Math.max(0,r?bal*(1+r)-pay:bal-pay);vals.push(bal)}const max=Math.max(P,1);const pts=vals.map((val,i)=>[pad+i/(vals.length-1)*(w-pad*2),pad+(1-clamp(val/max,0,1))*(h-pad*2)]);return chartSvg(pts,'Illustrative loan balance chart',false);
  }
  function payoffChart(P,annual,current,extra){
    const w=440,h=150,pad=18,n=28,r=annual/100/12;const series=(payment)=>{let bal=P,arr=[bal];for(let i=0;i<n-1;i++){bal=Math.max(0,r?bal*(1+r)-payment:bal-payment);arr.push(bal)}return arr};const a=series(current),b=series(current+extra),max=Math.max(P,1);const ptsA=a.map((v,i)=>[pad+i/(n-1)*(w-pad*2),pad+(1-clamp(v/max,0,1))*(h-pad*2)]);const ptsB=b.map((v,i)=>[pad+i/(n-1)*(w-pad*2),pad+(1-clamp(v/max,0,1))*(h-pad*2)]);return chartSvg(ptsB,'Illustrative payoff chart',false,ptsA);
  }
  function goalChart(target,current,rate,years){
    const n=Math.max(1,Math.round(years*12)),r=rate/100/12,fvCurrent=current*Math.pow(1+r,n),remaining=Math.max(0,target-fvCurrent),pmt=r===0?remaining/n:remaining*r/(Math.pow(1+r,n)-1);const w=440,h=150,pad=18,pts=[];for(let i=0;i<=24;i++){const t=i/24,months=Math.round(t*n),fv=r===0?current+pmt*months:current*Math.pow(1+r,months)+pmt*((Math.pow(1+r,months)-1)/r);pts.push([pad+t*(w-pad*2),h-pad-(clamp(fv/Math.max(target,1),0,1))*(h-pad*2)])}return chartSvg(pts,'Illustrative savings goal chart',false);
  }
  function chartSvg(points,label,area=false,secondary=null){
    const line=points.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');const areaPath=line+` L ${points.at(-1)[0].toFixed(1)} 132 L ${points[0][0].toFixed(1)} 132 Z`;const secondaryPath=secondary?secondary.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' '):'';return `<svg class="chart" viewBox="0 0 440 150" role="img" aria-label="${label}"><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="var(--accent)" stop-opacity=".18"/><stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs><line x1="18" y1="132" x2="422" y2="132" stroke="var(--border)"/><line x1="18" y1="28" x2="18" y2="132" stroke="var(--border)" opacity=".45"/><path d="${areaPath}" fill="${area?'url(#chartFill)':'none'}" class="dynamic-area"/><path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round" class="dynamic-line"/>${secondaryPath?`<path d="${secondaryPath}" fill="none" stroke="var(--muted)" stroke-width="1.7" stroke-dasharray="5 5" stroke-linecap="round"/>`:''}<circle cx="${points.at(-1)[0].toFixed(1)}" cy="${points.at(-1)[1].toFixed(1)}" r="3.2" fill="var(--accent)"/><text x="408" y="20" text-anchor="end" fill="var(--muted)" font-size="9">${secondaryPath?'Dashed: current':'Today → future'}</text></svg>`;
  }

  async function shareResult(item,r){const text=`${item.label}\n${r.title}: ${r.big}\n${r.a[0]}: ${r.a[1]}\n${r.b[0]}: ${r.b[1]}\nFinance Calculator — estimate only.`;if(navigator.share){try{await navigator.share({title:item.label,text})}catch{}}else{try{await navigator.clipboard.writeText(text);toast('Result copied')}catch{toast('Sharing not available')}}}

  function renderCompare(){
    setView('compare');
    $('#compareView').innerHTML=`<div class="back-row"><div><h2>Compare Scenarios</h2><p class="subtle">Compare two simple finance scenarios side by side.</p></div></div><div class="panel">${selectField('Scenario type','compareType',[['investment','Investment'],['loan','Loan']], 'investment')}<div id="compareInputs"></div><button class="primary-btn" id="compareBtn">Compare</button></div><div id="compareResult"></div>`;
    const renderInputs=()=>{
      const type=$('#compareType').value;
      if(type==='investment'){
        $('#compareInputs').innerHTML=`<div class="field-row">${input('Scenario A amount','cmpAmtA',300)}${input('Scenario B amount','cmpAmtB',300)}</div><div class="field-row">${input('Scenario A expected return','cmpRateA',7)}${input('Scenario B expected return','cmpRateB',9)}</div><div class="field-row">${input('Investment period','cmpYears',10)}</div><p class="subtle tiny">Amounts are regular monthly contributions. Expected return is an assumption, not a guarantee.</p>`;
      }else{
        $('#compareInputs').innerHTML=`<div class="field-row">${input('Loan amount','cmpLoanAmt',30000)}${input('Loan term (years)','cmpLoanYears',10)}</div><div class="field-row">${input('Scenario A interest rate','cmpLoanRateA',4.5)}${input('Scenario B interest rate','cmpLoanRateB',5.25)}</div>`;
      }
    };
    renderInputs();
    $('#compareType').addEventListener('change',renderInputs);
    $('#compareBtn').addEventListener('click',()=>{
      const type=$('#compareType').value;
      if(type==='loan'){
        const amt=num($('#cmpLoanAmt').value), years=num($('#cmpLoanYears').value), a=num($('#cmpLoanRateA').value), b=num($('#cmpLoanRateB').value);
        const per=Math.max(1,Math.round(years*12));
        const A=amortPayment(amt,a,per,12), B=amortPayment(amt,b,per,12);
        const diff=Math.abs(B-A);
        $('#compareResult').innerHTML=`<div class="result-card"><div class="eyebrow">Scenario comparison</div><div class="result-big">${money(diff)} monthly difference</div><div class="metrics"><div class="metric"><small>Scenario A</small><strong>${money(A)}/mo</strong></div><div class="metric"><small>Scenario B</small><strong>${money(B)}/mo</strong></div></div></div>`;
      }else{
        const amtA=num($('#cmpAmtA').value), amtB=num($('#cmpAmtB').value), a=num($('#cmpRateA').value), b=num($('#cmpRateB').value), years=num($('#cmpYears').value);
        const A=fvRegular(amtA,a,years,12), B=fvRegular(amtB,b,years,12), diff=Math.abs(B-A);
        $('#compareResult').innerHTML=`<div class="result-card"><div class="eyebrow">Scenario comparison</div><div class="result-big">${money(diff)} difference</div><div class="metrics"><div class="metric"><small>Scenario A · ${a.toFixed(2)}% expected return</small><strong>${money(A)}</strong></div><div class="metric"><small>Scenario B · ${b.toFixed(2)}% expected return</small><strong>${money(B)}</strong></div></div></div>`;
      }
    });
  }
  function renderSaved(){setView('saved');const arr=readList('fc_saved');$('#savedView').innerHTML=`<div class="back-row"><div><h2>Saved Calculations</h2><p class="subtle">Stored locally on this device.</p></div></div><div class="panel">${arr.length?arr.map((x,i)=>`<div class="history-item"><div><strong>${x.label}</strong><span>${x.result} · ${new Date(x.created).toLocaleDateString()}</span></div><div class="history-actions"><button class="icon-btn" title="Open" data-open-save="${i}">${icon('back',15)}</button><button class="icon-btn" title="Delete" data-del-save="${i}">×</button></div></div>`).join(''):'<div class="history-empty">No saved calculations yet.</div>'}</div>`;$$('[data-open-save]').forEach(b=>b.addEventListener('click',()=>{const x=arr[Number(b.dataset.openSave)];openCalc(x.calcId,x.values)}));$$('[data-del-save]').forEach(b=>b.addEventListener('click',()=>{arr.splice(Number(b.dataset.delSave),1);writeList('fc_saved',arr);renderSaved();toast('Saved calculation deleted')}));}
  function renderSettings(){
    setView('settings');
    $('#settingsView').innerHTML=`<div class="back-row"><div><h2>Settings</h2><p class="subtle">Simple preferences. Everything else stays offline.</p></div></div><div class="panel"><div class="section-head"><h2>Currency</h2><span class="subtle">Display only</span></div>${selectField('Default currency','settingsCurrency',Object.keys(currencyMeta).map(k=>[k,`${currencyMeta[k]} ${k}`]),state.currency)}<div class="section-head" style="margin-top:15px"><h2>Appearance</h2><span class="subtle">No account required</span></div><div class="segmented" id="appearanceSeg"><button data-theme="light">Light</button><button data-theme="dark">Dark</button><button data-theme="system">System</button></div></div><div class="panel"><div class="section-head"><h2>Data</h2></div><button class="secondary-btn" id="clearAll" style="width:100%">Clear history & saved calculations</button></div><div class="disclaimer">This app provides mathematical estimates from numbers you enter. It does not provide personalized financial advice, guarantee investment returns, or connect to financial accounts. No internet connection is required for core calculations.</div>`;
    $('#settingsCurrency').addEventListener('change',e=>{
      state.currency=e.target.value;
      localStorage.setItem('fc_currency',state.currency);
      $('#currencyBtn').textContent=`${currency()} ${state.currency}`;
      toast(`Currency: ${state.currency}`);
      if($('#calcView').classList.contains('active') && state.currentCalc){
        const currentValues=readVals(state.currentCalc);
        renderCalc(state.currentCalc,currentValues);
      }
    });
    $$('#appearanceSeg button').forEach(b=>b.addEventListener('click',()=>{
      state.theme=b.dataset.theme;
      localStorage.setItem('fc_theme',state.theme);
      applyTheme();
      renderSettings();
    }));
    $('#clearAll').addEventListener('click',()=>{
      localStorage.removeItem('fc_history');
      localStorage.removeItem('fc_saved');
      renderSettings();
      toast('History and saved calculations cleared');
    });
  }
  $('#currencyBtn').addEventListener('click',()=>{
    const keys=Object.keys(currencyMeta);
    const next=keys[(keys.indexOf(state.currency)+1)%keys.length];
    state.currency=next;
    localStorage.setItem('fc_currency',next);
    $('#currencyBtn').textContent=`${currency()} ${state.currency}`;
    $('#currencyBtn').classList.remove('flash'); void $('#currencyBtn').offsetWidth; $('#currencyBtn').classList.add('flash');
    toast(`Currency: ${state.currency}`);

    // Instant visual refresh: recalculate the active screen with the new currency symbol.
    if($('#compareView').classList.contains('active')){
      renderCompare();
    } else if($('#savedView').classList.contains('active')){
      renderSaved();
    } else if($('#settingsView').classList.contains('active')){
      renderSettings();
    } else if($('#calcView').classList.contains('active') && state.currentCalc){
      const currentValues=readVals(state.currentCalc);
      renderCalc(state.currentCalc,currentValues);
    } else {
      renderRecent();
      renderHome($('#searchInput').value);
    }
  });
  if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
})();
