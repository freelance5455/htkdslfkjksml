JAIBIR SPOKEN MANDARIN – EDUCATIONAL VOICE TEST
Upload this ZIP as a zipped site. It contains only index.html (no MP3/media files).
The two voice buttons use the device/browser Chinese speech engine (zh-CN).
If the APK builder preview does not support Web Speech API, this builder may not support spoken output from a plain HTML site. Test in Chrome first.
