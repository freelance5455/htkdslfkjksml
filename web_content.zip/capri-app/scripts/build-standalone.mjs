import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const dir = path.join(root, "public", "characters");
const names = {
  idle: "capri-idle.png",
  happy: "capri-happy.png",
  excited: "capri-excited.png",
  thinking: "capri-thinking.png",
  speaking: "capri-speaking.png",
  listening: "capri-listening.png",
  annoyed: "capri-annoyed.png",
  sad: "capri-sad.png",
  surprised: "capri-surprised.png",
  micro: "capri-microphone.png",
};

let sprites = {};
for (const [key, file] of Object.entries(names)) {
  const full = path.join(dir, file);
  if (!fs.existsSync(full)) {
    console.warn("Falta sprite", file);
    continue;
  }
  const base64 = fs.readFileSync(full).toString("base64");
  sprites[key] = `data:image/png;base64,${base64}`;
}

const template = fs.readFileSync(path.join(root, "scripts", "standalone", "template.html"), "utf8");
const html = template
  .replace("__SPRITES__", JSON.stringify(sprites))
  .replaceAll("__SELF__", "capri.html");

for (const out of ["public/capri.html", "capri.html"]) {
  fs.writeFileSync(path.join(root, out), html);
}
const size = (fs.statSync(path.join(root, "public/capri.html")).size / 1024 / 1024).toFixed(2);
console.log(`capri.html generado (${size} MB) con ${Object.keys(sprites).length} expresiones incrustadas`);
