# Capri AI

Asistente con personaje interactivo, memoria persistente, voz y APIs configurables.

## Mejoras recientes
- **Animación de sentarse**: al soltar a Capri cerca de la barra de chat hace una animación de aterrizaje (sit-land).
- **Más arrastrable**: rangos de arrastre ampliados, mejor feedback al soltar (se guarda el asiento `composer` / `float` en los ajustes).
- **Composer mejorado**: acepta **cualquier tipo de archivo** (`*/*`), previsualización más clara (imagen / texto / archivo) y texto de ayuda actualizado.
- **Comandos tipo Siri**: di o escribe cosas como «busca el clima en Google», «abre YouTube», «reproduce música», «abre WhatsApp», «abre Maps», etc. Abre la web/app correspondiente (limitación del navegador: no puede controlar apps nativas cerradas como un asistente del sistema).
- Persistencia: los cambios de asiento del personaje se guardan junto al resto de ajustes.

Incluye **dos formas de uso**:

## 1. App completa (Next.js + PostgreSQL)

```bash
npm install
npx drizzle-kit push     # crea las tablas
npm run dev              # http://localhost:3000
# o en producción
npm run build && npm start
```

- Chats, mensajes, emociones, recuerdos, ajustes y claves de API se guardan en PostgreSQL.
- Motores incluidos: **Capri Local** (motor propio, funciona sin red) y **Capri Online** (nube sin clave, con reintentos y respaldo local automático). También puedes añadir OpenAI, Groq, Anthropic, Gemini, Mistral, OpenRouter o cualquier API compatible con OpenAI.
- Voz: dictado del navegador + lectura en voz alta + modo manos libres.
- Estudio de Capri: personaje, 10 expresiones, voz, personalidad, escena, rendimiento y accesibilidad.
- Ventana flotante (solo voz) con Document Picture-in-Picture en Chrome/Edge de escritorio; en móvil instala la PWA.

## 2. Archivo HTML ejecutable (sin servidor)

`capri.html` (también en `public/capri.html`) es una **app completa en un solo archivo**:

- Se abre con doble clic (móvil u ordenador); no necesita Node, ni base de datos, ni internet.
- Personaje chibi arrastrable con 10 expresiones incrustadas en base64.
- Memoria, chats, ajustes y respaldos en `localStorage` (exportar / importar JSON).
- Motor local de Capri, voz del sistema, dictado (requiere Chrome/Edge y https o localhost).
- Opcional: conectar tu propia API compatible OpenAI desde Ajustes → IA.

Para regenerarlo después de cambiar el template:

```bash
node scripts/build-standalone.mjs
```

Genera `capri.html` y `public/capri.html` incrustando los sprites de `public/characters`.

## Estructura

- `src/app` — rutas Next.js (chat, estado, memoria, ajustes, proveedores, `/mini` flotante, manifest PWA).
- `src/lib` — motor local (`engine.ts`), memoria (`memory.ts`), proveedores (`providers.ts`, `online.ts`), tipos y utilidades.
- `src/components` — UI, personaje interactivo, estudio, ajustes y modo voz.
- `scripts/standalone/template.html` — plantilla del archivo único.
