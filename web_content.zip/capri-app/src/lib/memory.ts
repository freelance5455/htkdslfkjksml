import type { Memory } from "@/lib/types";
import { fold, tokens } from "@/lib/text";

export function retrieveMemories(memories: Memory[], query: string, limit = 6): Memory[] {
  const queryTokens = new Set(tokens(query));
  const scored = memories.map((memory) => {
    const memoryTokens = tokens(`${memory.content} ${memory.keywords} ${memory.kind}`);
    const overlap = memoryTokens.filter((token) => queryTokens.has(token)).length;
    const direct = fold(query).includes(fold(memory.content).slice(0, 18)) ? 2 : 0;
    const kindBonus =
      memory.kind === "perfil" ? 1.6 : memory.kind === "preferencia" ? 1.1 : memory.kind === "tarea" ? 0.8 : 0;
    const ageDays = Math.max(0, (Date.now() - new Date(memory.createdAt).getTime()) / 86_400_000);
    const recency = Math.max(0, 1.2 - ageDays / 120);
    return {
      memory,
      overlap,
      score: overlap * 2.4 + direct + kindBonus + memory.importance * 0.45 + recency + Math.min(1, memory.uses * 0.1),
    };
  });

  const relevant = scored
    .filter((entry) => entry.score >= 1.8 && (entry.overlap > 0 || entry.memory.kind === "perfil"))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((entry) => entry.memory);

  if (relevant.length) return relevant;

  return scored
    .filter((entry) => entry.memory.kind === "perfil")
    .sort((a, b) => b.score - a.score)
    .slice(0, Math.min(2, limit))
    .map((entry) => entry.memory);
}

export function normalizeMemory(content: string): string {
  return fold(content).replace(/\s+/g, " ").trim();
}

export function dedupeCandidates<T extends { content: string }>(candidates: T[], existing: Memory[]): T[] {
  const known = new Set(existing.map((memory) => normalizeMemory(memory.content)));
  const local = new Set<string>();
  return candidates.filter((candidate) => {
    const key = normalizeMemory(candidate.content);
    if (!key || known.has(key) || local.has(key)) return false;
    local.add(key);
    return true;
  });
}

export function memoryLine(memory: Memory): string {
  const labels: Record<Memory["kind"], string> = {
    perfil: "Perfil",
    preferencia: "Prefiere",
    gusto: "Le gusta",
    tarea: "Pendiente",
    dato: "Dato",
  };
  return `${labels[memory.kind]}: ${memory.content}`;
}

export function memoryBlock(memories: Memory[]): string {
  if (!memories.length) return "";
  return memories.map((memory) => `- ${memoryLine(memory)}`).join("\n");
}

export function findForgettable(memories: Memory[], query: string): Memory[] {
  const clean = fold(
    query
      .replace(/^.*?\b(olvida|olvidate|olvídate|borra|elimina|quita)\b/i, "")
      .replace(/\b(de|del|la|el|lo|los|las|mis|mi|tus|tu|eso|esto|sobre)\b/gi, " ")
      .trim(),
  );
  if (!clean) return [];
  return memories.filter((memory) => {
    const haystack = fold(memory.content);
    return haystack.includes(clean) || clean.includes(haystack) || tokens(clean).some((token) => haystack.includes(token));
  });
}
