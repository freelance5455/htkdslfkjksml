import { cleanRewrite, extractTasks, fold, keywords, summarize, titleFromMessage, tokens, countWords, splitTrailingRequest } from "@/lib/text";
import type { Attachment, Emotion, Memory, Role, Settings } from "@/lib/types";

export type EngineInput = {
  text: string;
  history: { role: Role; content: string }[];
  memories: Memory[];
  relevant?: Memory[];
  saved: Memory[];
  summary: string;
  settings: Settings;
  attachments: Attachment[];
  nowIso?: string;
  timezone?: string;
};

export type EngineResult = {
  text: string;
  skill: string;
  emotion: Emotion;
  forgetIds: string[];
  remember: { content: string; kind: "tarea" | "dato"; importance: number }[];
};

export const SKILL_LABELS: Record<string, string> = {
  memoria: "Memoria",
  plan: "Planificador",
  ideas: "Ideas",
  explicar: "Explicación",
  resumen: "Resumen",
  redaccion: "Redacción",
  archivos: "Archivos",
  matematicas: "Cálculo",
  codigo: "Código",
  decision: "Decisión",
  hora: "Hora",
  charla: "Conversación",
  general: "Respuesta",
};

const has = (text: string, pattern: RegExp) => pattern.test(text);

function seed(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash);
}

function pick<T>(items: T[], s: number): T {
  return items[s % items.length];
}

function userName(input: EngineInput): string {
  if (input.settings.userName.trim()) return input.settings.userName.trim();
  for (const memory of [...input.memories, ...input.saved]) {
    const match = memory.content.match(/(?:Se llama|El usuario se llama)\s+([\p{L}][\p{L}'-]+(?:\s+[\p{L}][\p{L}'-]+)?)/iu);
    if (match) return match[1];
  }
  return "";
}

function assistantName(input: EngineInput): string {
  return input.settings.assistantName || "Capri";
}

const KIND_LABELS: Record<string, string> = {
  perfil: "Perfil",
  preferencia: "Preferencia",
  gusto: "Gusto",
  tarea: "Pendiente",
  dato: "Dato",
};

function memorySnapshot(memories: Memory[], limit = 4): string {
  if (!memories.length) return "";
  return memories
    .slice(0, limit)
    .map((memory) => `- ${memory.content}`)
    .join("\n");
}

function greetingFor(date: Date): string {
  const hour = Number(
    new Intl.DateTimeFormat("es-ES", { hour: "numeric", hour12: false, timeZone: "UTC" }).format(date),
  );
  if (hour < 12) return "Buenos días";
  if (hour < 20) return "Buenas tardes";
  return "Buenas noches";
}

function lastUserTopic(input: EngineInput): string {
  const previous = [...input.history].reverse().find((entry) => entry.role === "user" && entry.content.trim());
  return previous ? summarize(previous.content, 1, 120) : "";
}

const KNOWLEDGE: { keys: string[]; title: string; idea: string; facts: string[]; example: string }[] = [
  {
    keys: ["inteligencia artificial", "machine learning", "aprendizaje automatico", "modelos de lenguaje"],
    title: "Inteligencia artificial",
    idea: "Un sistema de software que aprende patrones a partir de datos para hacer tareas que normalmente requieren criterio humano.",
    facts: [
      "Un modelo no «sabe»: estima la respuesta más probable según los ejemplos con los que se entrenó.",
      "Datos de calidad > modelos enormes cuando el problema está bien definido.",
      "La clave práctica es medir: exactitud, velocidad y coste antes de escalar.",
    ],
    example: "Un clasificador de correos usa miles de ejemplos etiquetados para separar spam de mensajes reales.",
  },
  {
    keys: ["fotosintesis", "planta", "clorofila"],
    title: "Fotosíntesis",
    idea: "El proceso con el que las plantas convierten luz, agua y CO₂ en azúcares y liberan oxígeno.",
    facts: [
      "Ocurre en los cloroplastos, donde la clorofila captura luz.",
      "6 CO₂ + 6 H₂O + luz → glucosa + 6 O₂ como ecuación resumen.",
      "Casi todo el oxígeno que respiramos proviene de organismos fotosintéticos.",
    ],
    example: "Una hoja expuesta al sol produce glucosa que la planta usa como energía y material de crecimiento.",
  },
  {
    keys: ["gravedad", "relatividad", "einstein"],
    title: "Gravedad",
    idea: "La atracción entre masas; Einstein la describió como la curvatura del espacio-tiempo.",
    facts: [
      "La fuerza es proporcional a las masas e inversa al cuadrado de la distancia.",
      "No es una «cuerda»: los objetos siguen la geometría curvada por la masa.",
      "Explica desde una manzana hasta la órbita de los planetas y los agujeros negros.",
    ],
    example: "La Luna no «cae» hacia la Tierra porque su velocidad lateral compensa la caída constante.",
  },
  {
    keys: ["agujero negro", "agujeros negros", "horizonte de sucesos"],
    title: "Agujeros negros",
    idea: "Regiones donde la gravedad es tan intensa que ni la luz puede escapar.",
    facts: [
      "El horizonte de sucesos es la frontera: dentro, ninguna trayectoria sale.",
      "Se forman por el colapso de estrellas muy masivas o son supermasivos en centros galácticos.",
      "Sagitario A* es el agujero negro supermasivo de nuestra galaxia.",
    ],
    example: "La primera imagen de M87* se obtuvo combinando radiotelescopios de todo el planeta.",
  },
  {
    keys: ["adn", "genetica", "genes", "arn"],
    title: "ADN y genes",
    idea: "El ADN es la molécula que guarda instrucciones para construir y operar un ser vivo.",
    facts: [
      "Usa cuatro bases: A, T, C y G; el orden forma el código.",
      "Un gen es un tramo con instrucciones para una proteína o una función.",
      "Las mutaciones son cambios en la secuencia y son la materia prima de la evolución.",
    ],
    example: "La insulina recombinante se produce insertando el gen humano en bacterias.",
  },
  {
    keys: ["cambio climatico", "calentamiento global", "efecto invernadero"],
    title: "Cambio climático",
    idea: "El aumento de gases de efecto invernadero eleva la temperatura media y altera el clima.",
    facts: [
      "El CO₂ atmosférico ha subido de ~280 ppm (preindustrial) a más de 420 ppm.",
      "Los impactos incluyen olas de calor, sequías, subida del nivel del mar y acidificación oceánica.",
      "Mitigación = reducir emisiones; adaptación = prepararse para los cambios ya inevitables.",
    ],
    example: "Una ciudad puede mitigar con transporte público y adaptarse con drenajes para lluvias extremas.",
  },
  {
    keys: ["sistema solar", "planetas", "marte", "jupiter"],
    title: "Sistema solar",
    idea: "Un sistema con el Sol al centro, ocho planetas, lunas, asteroides y cometas.",
    facts: [
      "Júpiter contiene más masa que todos los demás planetas juntos.",
      "Los planetas rocosos están cerca del Sol; los gigantes gaseosos, más lejos.",
      "Marte es el objetivo más explorado por su cercanía y su historia de agua líquida.",
    ],
    example: "Un año en Mercurio dura 88 días; en Neptuno, unos 165 años terrestres.",
  },
  {
    keys: ["sueno", "dormir", "insomnio", "descanso"],
    title: "Sueño y descanso",
    idea: "Dormir consolida memoria, regula hormonas y repara tejidos. Es un pilar de salud, no un lujo.",
    facts: [
      "La mayoría de adultos necesita entre 7 y 9 horas por noche.",
      "La luz brillante por la noche retrasa la melatonina y dificulta conciliar el sueño.",
      "Horarios regulares mejoran la calidad más que dormir de golpe el fin de semana.",
    ],
    example: "Un ritual de 20 minutos sin pantallas antes de dormir suele mejorar la latencia del sueño.",
  },
  {
    keys: ["ansiedad", "estres", "estrés", "calma"],
    title: "Calmar la ansiedad",
    idea: "La ansiedad es una respuesta de alerta; se vuelve problema cuando es constante o desproporcionada.",
    facts: [
      "Respirar lento (inhalar 4 s, exhalar 6 s) activa el sistema parasimpático.",
      "Nombrar lo que sientes reduce la carga emocional («etiquetado afectivo»).",
      "Suplementos y dietas milagro no sustituyen tratamiento psicológico cuando hay un trastorno.",
    ],
    example: "Escribe qué temes, qué parte controlas y el siguiente paso mínimo; el cerebro baja el ritmo.",
  },
  {
    keys: ["finanzas", "ahorrar", "ahorro", "dinero", "presupuesto"],
    title: "Finanzas personales",
    idea: "Ordenar el dinero es un sistema: ingresos, gastos, colchón y metas.",
    facts: [
      "Regla práctica: 50 % necesidades, 30 % deseos, 20 % ahorro e inversión (ajustable).",
      "Un colchón de 3 a 6 meses de gastos evita endeudarse ante imprevistos.",
      "La deuda de tarjeta con interés alto se paga antes que cualquier inversión de bajo retorno.",
    ],
    example: "Automatizar una transferencia de ahorro el día de cobro funciona mejor que ahorrar «lo que sobre».",
  },
  {
    keys: ["marketing", "ventas", "clientes", "negocio", "emprender"],
    title: "Marketing y validación",
    idea: "Primero un problema real y un cliente concreto; después el mensaje; al final el producto pulido.",
    facts: [
      "Un nicho claro convierte mejor que un mensaje para todos.",
      "Propuesta de valor = resultado + plazo + prueba de que funciona.",
      "Antes de invertir en anuncios, valida con 10 conversaciones reales.",
    ],
    example: "Una consultora puede vender una auditoría de 30 minutos antes de ofrecer un proyecto completo.",
  },
  {
    keys: ["programacion", "programar", "javascript", "typescript", "python", "react", "next.js"],
    title: "Aprender a programar",
    idea: "Se aprende construyendo proyectos pequeños y completos, no acumulando tutoriales.",
    facts: [
      "La calidad sube cuando tu ciclo es: romper, leer el error, aplicar un cambio pequeño, verificar.",
      "Versionar con Git desde el primer día te da red de seguridad y portafolio.",
      "Entender datos, peticiones y estado resuelve más que memorizar APIs.",
    ],
    example: "Construye una lista de tareas persistente: cubre formularios, estado, almacenamiento y despliegue.",
  },
  {
    keys: ["idiomas", "ingles", "aprender un idioma", "hablar ingles"],
    title: "Aprender un idioma",
    idea: "El idioma se automatiza con exposición comprensible y uso diario, no con gramática aislada.",
    facts: [
      "20 minutos diarios superan a 4 horas un sábado.",
      "Hablar desde el principio reduce el miedo y acelera la recuperación de vocabulario.",
      "Repaso espaciado (1-3-7-21 días) es la forma más eficiente de retener palabras.",
    ],
    example: "Elige un tema favorito y consume 15 minutos de contenido fácil con subtítulos antes de practicar en voz alta.",
  },
  {
    keys: ["receta", "cocinar", "cena", "comida rapida", "tortilla", "pasta"],
    title: "Cocina práctica",
    idea: "Cocinar bien es cuestión de orden: base, proteína, verdura y un toque ácido o picante.",
    facts: [
      "Prepara todo cortado y medido antes de encender el fuego.",
      "Sal en capas, no solo al final: el sabor penetra mejor.",
      "El calor alto sella, el medio cocina y el bajo concentra.",
      "Un ácido (limón o vinagre) al final despierta cualquier plato.",
    ],
    example: "Pasta al limón: mezcla la pasta con aceite, limón, queso y pimienta fuera del fuego y liga con agua de cocción.",
  },
  {
    keys: ["ejercicio", "entrenar", "rutina de ejercicio", "gimnasio", "correr", "fuerza", "hipertrofia"],
    title: "Entrenamiento",
    idea: "Progresar es aumentar carga, repeticiones o calidad técnica de forma gradual y sostenible.",
    facts: [
      "2 a 4 sesiones por semana con 8-12 series por grupo muscular es un buen punto de partida.",
      "La proteína repartida en 3-4 comidas ayuda a conservar y construir músculo.",
      "Dormir 7-9 h mejora la recuperación más que cualquier suplemento.",
      "Calienta con movilidad y una serie ligera del ejercicio para reducir lesiones.",
    ],
    example: "Rutina simple: sentadilla, press, remo y bisagra de cadera; 3 series de 6-10 repeticiones con 2 minutos de descanso.",
  },
  {
    keys: ["instagram", "redes sociales", "contenido", "copywriting", "publicar"],
    title: "Contenido y redes",
    idea: "Publica para una persona concreta y un problema concreto; el algoritmo premia conversaciones, no solo vistas.",
    facts: [
      "Gancho en los primeros 2 segundos o en la primera línea.",
      "Estructura útil: problema, promesa, prueba y llamada a la acción.",
      "Un solo CTA por pieza; dos compiten y ninguno convierte.",
      "Reutiliza: un vídeo largo genera 3 clips, 1 carrusel y 5 publicaciones cortas.",
    ],
    example: "«3 errores por los que tu café sabe a quemado» supera a «Nuestra nueva cafetería ideal».",
  },
  {
    keys: ["contrato", "factura", "autonomo", "autónomo", "impuestos", "iva"],
    title: "Gestión básica",
    idea: "La base es separar cuentas, facturar con datos correctos y guardar justificantes.",
    facts: [
      "Una factura necesita número, fecha, datos de ambas partes y desglose del IVA.",
      "Reserva un 20-30 % de impuestos y contingencias si eres autónomo.",
      "Cobra por adelantado o por hitos para no financiar al cliente.",
      "Un gestor se amortiza si evita un solo error de IVA.",
    ],
    example: "Presupuesto: alcance, entregables, plazos, precio fijo, forma de pago y qué no incluye.",
  },
];

function containsKey(text: string, keys: string[]): boolean {
  return keys.some((key) => {
    const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, "i").test(text);
  });
}

function findKnowledge(text: string) {
  const folded = fold(text);
  return KNOWLEDGE.find((entry) => containsKey(folded, entry.keys));
}

function evalMath(raw: string): { value: number; expression: string } | null {
  let expression = raw
    .replace(/¿|cuánto es|cuanto es|calcula|resultado de/gi, " ")
    .replace(/elevado a|al cuadrado/gi, "^")
    .replace(/,\s*(?=\d)/g, ".")
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/raíz de|raiz de/gi, "sqrt")
    .replace(/\bpor\b/gi, "*")
    .replace(/\bentre\b/gi, "/")
    .replace(/\bmás\b|\bmas\b/gi, "+")
    .replace(/\bmenos\b/gi, "-")
    .replace(/(\d)\s*[xX]\s*(\d)/g, "$1*$2")
    .trim();

  const percentOf = expression.match(/(\d+(?:\.\d+)?)\s*%\s*(?:de|\*)\s*(\d+(?:\.\d+)?)/i);
  if (percentOf) {
    const value = (Number(percentOf[1]) / 100) * Number(percentOf[2]);
    return { value, expression: `${percentOf[1]}% de ${percentOf[2]}` };
  }

  if (!/\d/.test(expression) || !/[-+*/^]|sqrt|sin|cos|tan|log|ln/.test(expression)) return null;
  if (!/^[\d\s+\-*/^%().a-zA-Z]+$/.test(expression)) return null;

  const tokens = expression.match(/sqrt|abs|sin|cos|tan|log|ln|pi|e|\d+(?:\.\d+)?|[-+*/^%()]/g);
  if (!tokens) return null;

  const precedence: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2, "%": 2, "^": 3 };
  const functions = new Set(["sqrt", "abs", "sin", "cos", "tan", "log", "ln"]);
  const output: (number | string)[] = [];
  const stack: string[] = [];

  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    if (/^\d/.test(token)) {
      output.push(Number(token));
    } else if (token === "pi") {
      output.push(Math.PI);
    } else if (token === "e") {
      output.push(Math.E);
    } else if (functions.has(token)) {
      stack.push(token);
    } else if (token in precedence) {
      if (token === "-" && (index === 0 || tokens[index - 1] in precedence || tokens[index - 1] === "(")) {
        output.push(0);
      }
      while (
        stack.length &&
        stack[stack.length - 1] in precedence &&
        precedence[stack[stack.length - 1]] >= precedence[token] &&
        token !== "^"
      ) {
        output.push(stack.pop() as string);
      }
      stack.push(token);
    } else if (token === "(") {
      stack.push(token);
    } else if (token === ")") {
      while (stack.length && stack[stack.length - 1] !== "(") output.push(stack.pop() as string);
      stack.pop();
      if (stack.length && functions.has(stack[stack.length - 1])) output.push(stack.pop() as string);
    }
  }
  while (stack.length) output.push(stack.pop() as string);

  const values: number[] = [];
  for (const token of output) {
    if (typeof token === "number") {
      values.push(token);
      continue;
    }
    if (functions.has(token)) {
      const value = values.pop();
      if (value === undefined) return null;
      values.push(
        token === "sqrt"
          ? Math.sqrt(value)
          : token === "abs"
            ? Math.abs(value)
            : token === "sin"
              ? Math.sin(value)
              : token === "cos"
                ? Math.cos(value)
                : token === "tan"
                  ? Math.tan(value)
                  : token === "log"
                    ? Math.log10(value)
                    : Math.log(value),
      );
      continue;
    }
    const right = values.pop();
    const left = values.pop();
    if (right === undefined || left === undefined) return null;
    values.push(
      token === "+"
        ? left + right
        : token === "-"
          ? left - right
          : token === "*"
            ? left * right
            : token === "/"
              ? right === 0
                ? Number.NaN
                : left / right
              : token === "%"
                ? left % right
                : left ** right,
    );
  }
  const value = values.pop();
  if (value === undefined || !Number.isFinite(value)) return null;
  const rounded = Math.round(value * 1e8) / 1e8;
  return { value: rounded, expression };
}

function solveMath(rawText: string): { expression: string; value: number }[] {
  const results: { expression: string; value: number }[] = [];
  const push = (expression: string, value: number) => {
    if (!Number.isFinite(value)) return;
    const rounded = Math.round(value * 1e8) / 1e8;
    if (!results.some((entry) => entry.expression === expression)) results.push({ expression, value: rounded });
  };

  let source = rawText;
  for (const match of rawText.matchAll(/(\d+(?:[.,]\d+)?)\s*%\s*(?:de|\*)\s*(\d+(?:[.,]\d+)?)/gi)) {
    const percent = Number(match[1].replace(",", "."));
    const total = Number(match[2].replace(",", "."));
    push(`${match[1]}% de ${match[2]}`, (percent / 100) * total);
    source = source.replace(match[0], " ");
  }

  const chunks = source.match(/[\d(][\d\s+\-*/^().,]*[\d)]/g) ?? [];
  for (const chunk of chunks) {
    if (!/\d\s*[+\-*/^]\s*[\d(]/.test(chunk) && !/\(\s*\d/.test(chunk)) continue;
    const solved = evalMath(chunk);
    if (solved) push(solved.expression.trim(), solved.value);
  }
  return results.slice(0, 4);
}

function planBlocks(tasks: string[], startHour: number, startMinute: number) {
  const durationFor = (task: string) => {
    const folded = fold(task);
    if (/reunion|reunión|entrevista|clase|presentacion/.test(folded)) return 60;
    if (/llamada|telefon|email|correo/.test(folded)) return 25;
    if (/gym|ejercicio|correr|entren|yoga|caminar/.test(folded)) return 50;
    if (/comida|comer|almuerzo|cena|desayuno/.test(folded)) return 45;
    if (/comprar|super|recado|banco|tramite/.test(folded)) return 30;
    if (/leer|estudiar|repasar/.test(folded)) return 50;
    return 40;
  };
  const blocks: { label: string; start: string; end: string; minutes: number; rest?: boolean }[] = [];
  let minutes = startHour * 60 + startMinute;
  const format = (total: number) => {
    const hours = Math.floor((total % 1440) / 60);
    const mins = total % 60;
    return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
  };
  let focusMinutes = 0;
  tasks.forEach((task, index) => {
    const duration = durationFor(task);
    blocks.push({ label: task, start: format(minutes), end: format(minutes + duration), minutes: duration });
    focusMinutes += duration;
    minutes += duration;
    if (index < tasks.length - 1) {
      const rest = duration >= 50 ? 15 : 10;
      blocks.push({ label: "Descanso activo", start: format(minutes), end: format(minutes + rest), minutes: rest, rest: true });
      minutes += rest;
    }
  });
  return { blocks, focusMinutes };
}

function codeAnswer(text: string): { intro: string; code: string; notes: string[] } | null {
  const folded = fold(text);
  if (/debounce|retrasar|espera al escribir/.test(folded)) {
    return {
      intro: "Aquí tienes un hook de debounce reutilizable (TypeScript) para no disparar búsquedas en cada tecla:",
      code: `import { useEffect, useState } from "react";

export function useDebounced<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debounced;
}

// Uso
const query = useDebounced(input, 250);
useEffect(() => { if (query) buscar(query); }, [query]);`,
      notes: ["250–400 ms suele sentirse inmediato sin saturar la API.", "Cancela el timeout en el cleanup para evitar fugas."],
    };
  }
  if (/sql|consulta|base de datos|postgres/.test(folded)) {
    return {
      intro: "Consulta SQL con agregados, filtros y orden:",
      code: `SELECT c.id,
       c.title,
       COUNT(m.id) AS mensajes,
       MAX(m.created_at) AS ultimo_mensaje
FROM conversations c
LEFT JOIN messages m ON m.conversation_id = c.id
WHERE c.updated_at > NOW() - INTERVAL '30 days'
GROUP BY c.id, c.title
ORDER BY ultimo_mensaje DESC
LIMIT 20;`,
      notes: ["LEFT JOIN conserva conversaciones sin mensajes.", "Agrupa por todas las columnas no agregadas para evitar errores."],
    };
  }
  if (/fetch|peticion|petición|api|http/.test(folded)) {
    return {
      intro: "Petición con manejo de errores, timeout y respuesta tipada:",
      code: `async function getJson<T>(url: string): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(\`HTTP \${res.status}\`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

const data = await getJson<{ items: string[] }>("/api/items");`,
      notes: ["AbortController evita esperas eternas.", "Revisa res.ok: fetch no lanza error en 4xx/5xx."],
    };
  }
  if (/python/.test(folded)) {
    return {
      intro: "Patrón limpio en Python para contar y ordenar frecuencias:",
      code: `from collections import Counter

def top_words(text: str, limit: int = 5) -> list[tuple[str, int]]:
    words = [w.strip(".,;:!?").lower() for w in text.split()]
    words = [w for w in words if len(w) > 3]
    return Counter(words).most_common(limit)

print(top_words("Hola mundo mundo de la programación"))`,
      notes: ["Counter es O(n) y mucho más legible que diccionarios manuales.", "Filtra palabras cortas antes de contar."],
    };
  }
  if (/regex|expresion regular|expresión regular|email|correo/.test(folded)) {
    return {
      intro: "Validación de correo pragmática (no intenta cubrir el RFC completo):",
      code: `const EMAIL = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/;

if (!EMAIL.test(value)) {
  throw new Error("Correo no válido");
}`,
      notes: ["Valida el formato; la prueba definitiva es enviar un correo de verificación.", "Evita regex monstruosas: son difíciles de mantener."],
    };
  }
  if (/css|centrar|flex|grid/.test(folded)) {
    return {
      intro: "Centrado perfecto con Grid, sin trucos:",
      code: `.container {
  display: grid;
  place-items: center;
  min-height: 100dvh;
}`,
      notes: ["place-items centra en ambos ejes.", "100dvh evita saltos en móviles con barra del navegador."],
    };
  }
  return null;
}

function filesAnswer(attachments: Attachment[], question: string): string {
  const lines: string[] = [`### Archivos recibidos (${attachments.length})`];
  for (const attachment of attachments) {
    const meta = [`**${attachment.name}**`, `${Math.max(1, Math.round(attachment.size / 1024))} KB`];
    if (attachment.kind === "image") {
      lines.push(`- ${meta.join(" · ")} · imagen adjunta. La tengo guardada en este chat para acompañar la conversación.`);
      continue;
    }
    const body = attachment.text ?? "";
    const words = countWords(body);
    const fileKeywords = keywords(body, 6);
    const rows = body.split(/\r?\n/).filter(Boolean);
    lines.push(
      `- ${meta.join(" · ")} · ${words} palabras · ${rows.length} líneas · temas: ${fileKeywords.join(", ") || "sin datos"}`,
    );
    if (/\.csv$/i.test(attachment.name)) {
      const header = rows[0]?.split(",").slice(0, 8) ?? [];
      lines.push(`  - Columnas detectadas (${header.length}): ${header.map((h) => h.trim()).join(" · ")}`);
    }
    if (body.trim()) {
      lines.push(`  - **Resumen:** ${summarize(body, 3, 420)}`);
    }
  }
  const questionClean = question
    .replace(/analy\w*|resume\w*|resúme\w*|archivos?\b|adjuntos?\b|documentos?\b|por favor/gi, " ")
    .replace(/\b(este|esta|esto|estos|estas|el|la|los|las|un|una|y|dime|dame|temas?|sobre|del|de)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  lines.push("");
  lines.push(
    questionClean
      ? `Sobre tu pregunta («${questionClean}»): usa los datos de arriba como base y dime si quieres que extraiga cifras, limpie el texto o lo reescriba.`
      : "¿Quieres que lo resuma, extraiga los puntos clave o lo reescriba?",
  );
  return lines.join("\n");
}

const INSULT_PATTERNS = [
  "idiota",
  "imbecil",
  "imbécil",
  "estupida",
  "estúpida",
  "tonta",
  "puta",
  "mierda",
  "cabrona",
  "gilipollas",
  "pendeja",
  "inutil",
  "inútil",
  "basura",
  "asco",
  "callate",
  "cállate",
  "no sirves",
  "odio",
];

const SAD_PATTERNS = [
  "triste",
  "deprimid",
  "ansiedad",
  "ansios",
  "solo",
  "sola",
  "llorar",
  "llorando",
  "duele",
  "dolor",
  "perdi",
  "perdí",
  "murio",
  "murió",
  "falleci",
  "falleció",
  "miedo",
  "abrumad",
  "agotad",
  "cansad",
  "fracaso",
  "ruptura",
  "duelo",
  "fatal",
  "no puedo mas",
  "no puedo más",
  "hundid",
  "desesperad",
  "sin fuerzas",
  "sufriendo",
  "sufro",
  "angustia",
  "panic",
  "pánico",
  "me siento mal",
  "me siento fatal",
  "no aguanto",
];

const SURPRISE_PATTERNS = ["no puede ser", "increible", "increíble", "sorpresa", "vaya", "en serio", "wow", "flipando", "no me lo puedo creer"];
const EXCITED_PATTERNS = ["genial", "increible", "increíble", "perfecto", "lo logre", "lo logré", "conseguido", "funciona", "funcionó", "bravo", "guau", "felicidades", "enhorabuena", "por fin"];
const HAPPY_PATTERNS = ["gracias", "me gusta", "buena idea", "contenta", "contento", "feliz", "jaja", "jeje"];

export function classifyEmotion(text: string, skill: string): Emotion {
  const folded = fold(text);
  if (INSULT_PATTERNS.some((word) => folded.includes(word))) return "annoyed";
  if (SAD_PATTERNS.some((word) => folded.includes(word))) return "sad";
  if (skill === "ideas" || skill === "plan") return "happy";
  if (/\?$/.test(text.trim()) && text.trim().length < 90) return "thinking";
  if (SURPRISE_PATTERNS.some((word) => folded.includes(word))) return "surprised";
  if (EXCITED_PATTERNS.some((word) => folded.includes(word))) return "excited";
  if (skill === "charla" || skill === "hora") return "happy";
  if (HAPPY_PATTERNS.some((word) => folded.includes(word))) return "happy";
  return "idle";
}

export function runEngine(input: EngineInput): EngineResult {
  const rawText = input.text.trim();
  const folded = fold(rawText);
  const now = input.nowIso ? new Date(input.nowIso) : new Date();
  const safeNow = Number.isNaN(now.getTime()) ? new Date() : now;
  const settings = input.settings;
  const name = userName(input);
  const capri = assistantName(input);
  const seedValue = seed(rawText + safeNow.getMinutes());
  const relevantMemories = input.relevant ?? input.memories;
  const memoryList = memorySnapshot([
    ...relevantMemories,
    ...input.saved.filter((memory) => !relevantMemories.some((item) => item.id === memory.id)),
  ]);
  const applyPreferences = (value: string): string => {
    let output = value;
    const instructions = settings.customInstructions;
    if (/breve|breves|corto|conciso|al grano|resumid/i.test(instructions) && output.length > 1100) {
      const cut = output.slice(0, 1100);
      const boundary = Math.max(cut.lastIndexOf("\n"), cut.lastIndexOf(". "));
      output = `${cut.slice(0, boundary > 300 ? boundary : 1100).trimEnd()}\n\n_Dime si quieres que amplíe._`;
    }
    if (settings.tone === "profesional" || settings.tone === "directo") {
      output = output.replace(/[\u{1F300}-\u{1FAFF}\u{2700}-\u{27BF}]/gu, "").replace(/ {2,}/g, " ");
    }
    if (settings.tone === "directo") {
      output = output.replace(/^(¡?(claro|por supuesto|genial|perfecto|estupendo)[!.,]?\s*)/i, "");
    }
    if (settings.tone === "divertido" && output.length > 40 && !/😊|✨|🧠|🎉/.test(output)) {
      output += "\n\n✨";
    }
    if (/emojis?/i.test(instructions) && !/😊|✨|🧠|🎉/.test(output)) output += " ✨";
    const preferredName = instructions.match(/ll[aá]mame\s+([\p{L}][\p{L}'-]{1,20})/iu);
    if (preferredName && !name) {
      output = `${output}\n\n_Por cierto, ${preferredName[1]}: puedes guardarlo como tu nombre en Ajustes → Rol IA._`;
    }
    return output;
  };

  const result = (text: string, skill: string, extra?: Partial<EngineResult>): EngineResult => ({
    text: applyPreferences(text),
    skill,
    emotion: extra?.emotion ?? classifyEmotion(rawText, skill),
    forgetIds: extra?.forgetIds ?? [],
    remember: extra?.remember ?? [],
  });

  const who = name ? `, ${name}` : "";
  const insulted = INSULT_PATTERNS.some((word) => folded.includes(word));
  if (insulted) {
    return result(
      `Oye… eso me ha dolido un poco${who}. 😤\n\nPuedo ayudarte con casi todo, pero te pido que hablemos con respeto. Si estás frustrado por algo, cuéntame **qué no está funcionando** y lo arreglamos juntos: puedo revisar pasos, rehacer el plan o probar otro enfoque.`,
      "charla",
      { emotion: "annoyed" },
    );
  }

  if (!rawText && input.attachments.length) {
    return result(filesAnswer(input.attachments, ""), "archivos");
  }

  // ---- Memory operations -------------------------------------------------
  if (has(folded, /^(olvida|olvidate|elimina|borra|quita)\b/) || has(folded, /\bolvida (que|lo|eso|mi|mis)\b/)) {
    const forget = input.memories.filter((memory) => {
      const probe = folded
        .replace(/^.*?\b(olvida|olvidate|elimina|borra|quita)\b/, "")
        .replace(/\b(que|lo|de|del|la|el|los|las|mi|mis|sobre|eso|esto)\b/g, " ");
      const words = tokens(probe);
      return words.length > 0 && words.some((word) => fold(memory.content).includes(word));
    });
    if (forget.length) {
      return result(
        `Hecho${who}. Olvidé ${forget.length === 1 ? "esto" : `estas ${forget.length} cosas`}:\n${forget
          .map((memory) => `- ${memory.content}`)
          .join("\n")}\n\nMi memoria está actualizada; ya no lo usaré en próximas respuestas.`,
        "memoria",
        { forgetIds: forget.map((memory) => memory.id) },
      );
    }
    return result(
      "No encontré un recuerdo que coincida con eso. Abre el panel **Memoria** para ver y borrar los recuerdos exactos.",
      "memoria",
    );
  }

  if (
    has(folded, /(que|qué) recuerdas|(que|qué) sabes de mi|mi memoria|mis recuerdos|ensename|enséñame (tu|la) memoria/) ||
    has(folded, /^memoria$/)
  ) {
    const groups: Record<string, Memory[]> = {};
    for (const memory of input.memories) {
      groups[memory.kind] = groups[memory.kind] ?? [];
      groups[memory.kind].push(memory);
    }
    const label: Record<string, string> = {
      perfil: "Sobre ti",
      preferencia: "Preferencias",
      gusto: "Gustos",
      tarea: "Pendientes",
      dato: "Datos",
    };
    const sections = Object.entries(groups).map(
      ([kind, list]) => `**${label[kind] ?? kind}**\n${list.slice(0, 6).map((memory) => `- ${memory.content}`).join("\n")}`,
    );
    if (!sections.length) {
      return result(
        "Todavía no tengo recuerdos guardados. Pídeme algo como «recuerda que mi color favorito es el violeta» o «recuérdame llamar a Ana mañana» y lo guardaré de forma permanente.",
        "memoria",
      );
    }
    const summaryLine = input.summary ? `\n\n**Contexto de este chat:** ${input.summary}` : "";
    return result(
      `Esto es lo que guardo en mi memoria a largo plazo (${input.memories.length} ${input.memories.length === 1 ? "recuerdo" : "recuerdos"}):\n\n${sections.join(
        "\n\n",
      )}${summaryLine}\n\nPuedes borrar cualquiera diciendo «olvida …».`,
      "memoria",
    );
  }

  if (has(folded, /\b(recuerda|recuérdame|recuerdame|no olvides|memoriza|apunta|guarda)\b/) && input.saved.length) {
    const split = splitTrailingRequest(rawText);
    if (split.tail) {
      const extra = runEngine({ ...input, text: split.tail, saved: input.saved });
      return result(
        `Guardado en mi memoria${who} 🧠\n${input.saved
          .map((memory) => `- **${KIND_LABELS[memory.kind] ?? "Dato"}:** ${memory.content}`)
          .join("\n")}\n\n---\n\n${extra.text}`,
        extra.skill === "charla" ? "memoria" : extra.skill,
      );
    }
    return result(
      `Guardado en mi memoria${who} 🧠\n${input.saved
        .map((memory) => `- **${KIND_LABELS[memory.kind] ?? "Dato"}:** ${memory.content}`)
        .join("\n")}\n\nLo tendré en cuenta en este chat y en los próximos.`,
      "memoria",
    );
  }
  if (has(folded, /\b(recuerda|recuérdame|recuerdame|no olvides)\b/) && !input.saved.length) {
    return result(
      "Claro, pero necesito el detalle: dime por ejemplo «recuerda que trabajo en diseño» o «recuérdame llamar al dentista el lunes». Así lo guardo con precisión.",
      "memoria",
    );
  }

  // ---- Time --------------------------------------------------------------
  if (has(folded, /\b((que|qué) hora|hora es|hoy es|que dia|qué día|fecha de hoy)\b/)) {
    const locale = "es-ES";
    const time = new Intl.DateTimeFormat(locale, {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: input.timezone,
    }).format(safeNow);
    const day = new Intl.DateTimeFormat(locale, {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      timeZone: input.timezone,
    }).format(safeNow);
    return result(`**${greetingFor(safeNow)}${who}.** Son las **${time}** del **${day}**. ¿Quieres que planifique lo que queda del día?`, "hora");
  }

  // ---- Math --------------------------------------------------------------
  const mathResults = has(folded, /cuanto|cuánto|calcula|resultado|=|%|\d\s*[+\-*/^]\s*\d/) ? solveMath(rawText) : [];
  if (mathResults.length) {
    const formatted = (value: number) =>
      new Intl.NumberFormat("es-ES", { maximumFractionDigits: 8 }).format(value);
    if (mathResults.length === 1) {
      const [only] = mathResults;
      return result(
        `**Resultado: ${formatted(only.value)}**\n\nOperación: \`${only.expression}\`\n\n- Acepto paréntesis, potencias (\`^\`), raíz (\`sqrt\`), porcentajes y funciones trigonométricas.\n- Si quieres lo redondeo, lo explico paso a paso o lo aplico a tu presupuesto.`,
        "matematicas",
      );
    }
    return result(
      `### Resultados\n${mathResults
        .map((entry) => `- \`${entry.expression}\` = **${formatted(entry.value)}**`)
        .join("\n")}\n\nPuedo encadenar paréntesis, potencias (\`^\`), raíz cuadrada (\`sqrt\`) y porcentajes. Dime si quieres el desarrollo paso a paso.`,
      "matematicas",
    );
  }

  // ---- Files -------------------------------------------------------------
  if (input.attachments.length) {
    return result(filesAnswer(input.attachments, rawText), "archivos");
  }

  if (has(folded, /\b(archivo|adjunt\w*|documento|pdf|imagen|foto|csv|excel|analiza\w*)\b/)) {
    return result(
      `### Adjunta el archivo y lo trabajo al instante\nPulsa **+** en el compositor y elige uno de estos formatos:\n- **Texto** (.txt, .md, .csv, .json, .log, código): cuento palabras y líneas, extraigo temas y resumo.\n- **Imágenes** (jpg, png): se guardan en el chat y las uso como contexto visual.\n- **Otros** documentos: guardo nombre, tipo y tamaño.\n\nMáximo 4 archivos de 12 MB. En cuanto lo adjuntes, dime también qué quieres saber y cruzo el análisis con tu pregunta.`,
      "archivos",
    );
  }

  // ---- Summarize ---------------------------------------------------------
  if (has(folded, /\b(resume|resumen|sintetiza|sintetizar|sintesis|extrae lo importante|puntos clave)\b/)) {
    const candidate = rawText
      .replace(/^.*?(resume|resumen de|sintetiza|puntos clave de)\b[:\s]*/i, "")
      .trim();
    if (candidate.length > 120) {
      const short = summarize(candidate, 5, 700);
      return result(
        `### Resumen\n${short
          .split(/(?<=[.!?…])\s+/)
          .filter(Boolean)
          .map((line) => `- ${line}`)
          .join("\n")}\n\n**Datos:** ${countWords(candidate)} palabras · ${Math.max(1, Math.round(countWords(candidate) / 200))} min de lectura · temas: ${keywords(
          candidate,
          5,
        ).join(", ")}.`,
        "resumen",
      );
    }
    if (input.summary) {
      return result(
        `### Resumen de nuestra conversación\n${input.summary
          .split(/(?<=[.!?…])\s+/)
          .filter(Boolean)
          .map((line) => `- ${line}`)
          .join("\n")}\n\nPega el texto completo si quieres que resuma un documento largo.`,
        "resumen",
      );
    }
    return result(
      "Pega el texto que quieres resumir (o adjúntalo con el botón **+**) y te devuelvo los puntos clave, el conteo de palabras y los temas principales.",
      "resumen",
    );
  }

  // ---- Rewrite -----------------------------------------------------------
  if (has(folded, /(\b(mejora|corrige|reformula|reescribe|redaccion|redacción)\b|mas profesional|más profesional)/)) {
    const candidate = rawText
      .replace(/^.*?(mejora|corrige|reformula|reescribe|redaccion de|redacción de)\b[:\s]*/i, "")
      .replace(/^(este|el|mi) texto\b[:\s]*/i, "")
      .trim();
    if (candidate.length < 12) {
      return result(
        "Pásame el texto (escrito o adjunto) y lo devuelvo corregido: ortografía, puntuación, claridad y una versión más corta.",
        "redaccion",
      );
    }
    const { text: improved, changes } = cleanRewrite(candidate);
    return result(
      `### Versión mejorada\n> ${improved}\n\n**Qué cambié**${changes.length ? "" : " (ya estaba bastante limpio)"}\n${changes
        .map((change) => `- ${change}`)
        .join("\n") || "- ajusté el ritmo para que suene natural"}\n\n¿Lo quiero más breve, más formal o con otro tono?`,
      "redaccion",
    );
  }

  // ---- Planning ----------------------------------------------------------
  if (
    has(folded, /\b(organiza|organizame|organízame|planifica|planificame|agenda|plan del dia|plan de la semana|rutina|horario|planifica)\b/) ||
    has(folded, /\b(hazme un plan|haz un plan|mi plan)\b/)
  ) {
    const tasks = extractTasks(rawText);
    const hourMatch = rawText.match(/(?:a las|desde las|empieza a las)\s*(\d{1,2})(?::(\d{2}))?/i);
    const startHour = hourMatch ? Math.min(22, Number(hourMatch[1])) : 9;
    const startMinute = hourMatch?.[2] ? Number(hourMatch[2]) : 0;
    const effectiveTasks = tasks.length
      ? tasks
      : ["Revisar prioridades y correo", "Bloque de trabajo profundo", "Avanzar el proyecto principal", "Cierre y plan de mañana"];
    const { blocks, focusMinutes } = planBlocks(effectiveTasks, startHour, startMinute);
    return result(
      `### Plan del día${name ? ` para ${name}` : ""}\n${blocks
        .map((block) =>
          block.rest
            ? `- ${block.start}–${block.end} · ☕ ${block.label} (${block.minutes} min)`
            : `- **${block.start}–${block.end}** · ${block.label} (${block.minutes} min)`,
        )
        .join("\n")}\n\n**Tiempo de foco:** ${Math.round((focusMinutes / 60) * 10) / 10} h + pausas.\n**Consejo:** empieza por la tarea más incómoda; dejarás de postergarla el resto del día.${
        tasks.length ? "" : "\n\nDime tu lista real con «organiza: reunión 10:00, gimnasio, informe» y ajusto los bloques a tu día."
      }`,
      "plan",
      tasks.length
        ? {
            remember: [
              { content: `Plan del día: ${tasks.join(", ")}`, kind: "tarea", importance: 3 },
            ],
          }
        : undefined,
    );
  }

  // ---- Ideas -------------------------------------------------------------
  if (has(folded, /(\bideas?\b|brainstorm|lluvia de ideas|creativ\w*|nombres para|se me ocurre)/)) {
    const topic =
      rawText
        .replace(/^.*?\b(?:dame|dime|necesito|quiero|busco|genera|crea|propón|propone)\b/gi, " ")
        .replace(/\b(?:ideas?|brainstorm|lluvia de ideas|creatividad|creativas?|creativos?|nombres para)\b/gi, " ")
        .replace(
          /^[\s]*(?:(?:para|sobre|acerca de|de|del|con|un|una|unos|unas|el|la|los|las|mi|mis|nuestro|nuestra)\s+){1,3}/i,
          "",
        )
        .replace(/\s+/g, " ")
        .trim() || "tu proyecto";
    const foldedTopic = fold(topic);
    const isEvent = /boda|cumplea|fiesta|evento|aniversario|graduaci|viaje|vacaciones|regalo|celebracion|celebracion/.test(foldedTopic);
    const isBusiness = /negocio|tienda|marca|cafeter|producto|app|startup|servicio|emprend|restaurante|tienda/.test(foldedTopic);
    const ideas = isEvent
      ? [
          `**Formato con un solo protagonista:** elige el momento que la gente recordará de ${topic} (ceremonia al atardecer, cena larga, brunch) e invierte ahí.`,
          `**Regla 70/20/10:** 70 % en comida y música, 20 % en fotografía, 10 % en decoración. Lo demás suele olvidarse.`,
          `**Lista de 30:** cada invitado debe poder nombrar a tres personas que verá allí; si no, esa invitación sobra y libera presupuesto.`,
          `**Detalle útil:** un recuerdo que se use (playlist impresa, semillas, fotos instantáneas) en lugar de objetos guardados.`,
          `**Plan B escrito:** alternativa por lluvia, retraso o cancelación, con una hora límite para decidir sin estrés.`,
          pick(
            [
              `**Aliado inesperado:** pide a dos amigos que se encarguen de la música y de las fotos; les das una tarea clara y tú ganas calma.`,
              `**Antesala digital:** una página sencilla con hora, mapa y confirmación reduce 80 % de las preguntas por mensaje.`,
            ],
            seedValue,
          ),
        ]
      : isBusiness
        ? [
            `**Nicho primero:** define el cliente exacto de ${topic} en una frase y elimina lo que no le sirve.`,
            `**Oferta mínima:** empaqueta el resultado más buscado de ${topic} con plazo y precio claros.`,
            `**Prueba en 7 días:** un piloto con 5 personas reales; mide cuántas repiten o recomiendan.`,
            `**Contenido útil:** una pieza que resuelva una duda frecuente de ${topic}; enlaza tu oferta al final.`,
            `**Alianza estratégica:** busca quién ya tiene a tu cliente y propón una comisión o intercambio.`,
            `**Métrica única:** elige una cifra que mueva el negocio (conversión, recompra, coste por cliente) y revísala cada viernes.`,
          ]
        : [
      `**Reto de 7 días:** una acción mínima diaria sobre ${topic}, con cierre el día 7 y resultados visibles.`,
      `**Detrás de cámaras:** documenta una semana de ${topic} en piezas de 30 segundos; la autenticidad vende más que la perfección.`,
      `**Antes / después:** haz visible el cambio que produce ${topic} con una métrica concreta y una captura.`,
      `**Versión low-cost:** resuelve la parte más dolorosa de ${topic} con una plantilla descargable.`,
      `**Alianza inesperada:** une ${topic} con un sector que no lo use aún (educación, salud, hostelería) y prueba un piloto.`,
      pick(
        [
          `**Idea salvaje:** convierte ${topic} en un juego por equipos con ranking semanal público.`,
          `**Idea salvaje:** ofrece ${topic} como suscripción sorpresa mensual: el cliente no elige, descubre.`,
          `**Idea salvaje:** documenta un fracaso de ${topic} y lo que aprendiste; el contenido honesto retiene.`,
        ],
        seedValue,
      ),
    ];
    return result(
      `### Ideas sobre ${topic}\n${ideas.map((idea) => `- ${idea}`).join("\n")}\n\n${
        (input.relevant ?? []).length
          ? `Tengo en cuenta: ${(input.relevant ?? [])
              .slice(0, 2)
              .map((memory) => memory.content.toLowerCase())
              .join(" · ")}\n\n`
          : ""
      }**Siguiente paso:** elige una idea y dime «desarrolla la 2» para convertirla en plan con pasos y métricas.`,
      "ideas",
    );
  }

  // ---- Code --------------------------------------------------------------
  if (
    has(
      folded,
      /\b(codigo|componente|hook|script|programar|programacion|sql|regex|typescript|javascript|python|css|react|query|endpoint|api|snippet|funcion javascript)\b/,
    )
  ) {
    const snippet = codeAnswer(rawText);
    if (snippet) {
      return result(
        `${snippet.intro}\n\`\`\`\n${snippet.code}\n\`\`\`\n**Notas**\n${snippet.notes
          .map((note) => `- ${note}`)
          .join("\n")}\n\n¿Quieres que lo adapte a tu stack o le añada tests?`,
        "codigo",
      );
    }
    return result(
      `### Enfoque para tu código\n1. **Contrato:** define entrada, salida y errores antes de escribir.\n2. **Versión mínima:** implementa el caso feliz sin abstracciones.\n3. **Bordes:** valida nulos, límites y tiempos de espera.\n4. **Prueba:** un test por borde; si algo se repite tres veces, extrae una función.\n\nDime el lenguaje (TypeScript, Python, SQL…) y el caso concreto, y te doy el snippet listo para copiar.`,
      "codigo",
    );
  }

  // ---- Knowledge / explain ----------------------------------------------
  const knowledgeTopic = findKnowledge(rawText);
  if (
    has(folded, /\b(que es|qué es|explica|explícame|explicame|como funciona|cómo funciona|aprender|aprende|definicion|definición|cuentame|cuéntame|hablame|háblame de)\b/) ||
    knowledgeTopic
  ) {
    const knowledge = knowledgeTopic;
    if (knowledge) {
      return result(
        `### ${knowledge.title}\n**Idea central:** ${knowledge.idea}\n\n**Claves**\n${knowledge.facts
          .map((fact) => `- ${fact}`)
          .join("\n")}\n\n**Ejemplo:** ${knowledge.example}\n\n¿Quieres que te lo explique con una analogía, en 3 frases o con un plan de estudio?`,
        "explicar",
        {
          remember: [
            {
              content: `Le interesa aprender sobre ${knowledge.title}`,
              kind: "dato",
              importance: 1,
            },
          ],
        },
      );
    }
    const topic = rawText
      .replace(/.*?\b(que es|qué es|explica(me|r)?|explícame|como funciona|cómo funciona|aprender|aprende|sobre|de)\b/gi, " ")
      .replace(/[¿?¡!.]/g, " ")
      .replace(/\s+/g, " ")
      .trim() || "el tema";
    return result(
      `### ${topic.charAt(0).toUpperCase() + topic.slice(1)}\n**Cómo lo abordaría**\n1. **Definición operativa:** describe ${topic} en una frase que puedas comprobar.\n2. **Mecanismo:** identifica las 3 piezas que lo hacen funcionar y cómo se relacionan.\n3. **Ejemplo real:** busca un caso cercano y explica qué cambió.\n4. **Autoevaluación:** intenta explicarlo sin notas; lo que falles es tu siguiente estudio.\n\n*Nota honesta:* mi conocimiento es local y no navega en tiempo real; para cifras actuales conviene contrastar una fuente. ¿Quieres el plan de estudio en 5 días o una analogía rápida?`,
      "explicar",
    );
  }

  // ---- Decisions ---------------------------------------------------------
  const decisionMatch = rawText.match(/(?:entre\s+)?([^,;?]{2,60}?)\s+(?:o|vs\.?|versus)\s+([^,;?]{2,60}?)(?:[?.]|$)/i);
  if (decisionMatch && has(folded, /recomienda|recomiendas|elijo|escojo|decidir|decision|decisión|pros|contras|mejor|conviene|ayuda a elegir/)) {
    const optionA = decisionMatch[1].replace(/^.*?\b(entre|elijo|escojo|prefiero|debo|elegir)\b/gi, " ").trim() || "opción A";
    const optionB = decisionMatch[2].trim() || "opción B";
    return result(
        `### ${optionA} vs. ${optionB}\n\n**Criterios que importan**\n- Coste total y tiempo de puesta en marcha.\n- Riesgo de quedarte atascado (dependencias, soporte, curva de aprendizaje).\n- Beneficio medible a 3 meses, no solo la sensación inicial.\n\n**Cómo lo veo**\n- **${optionA}:** cómodo si buscas control y algo probado; suele ser más lento.\n- **${optionB}:** más ágil si puedes tolerar algo de incertidumbre y aprender rápido.\n\n**Mi recomendación:** prueba ${optionA} durante una semana con un criterio de éxito escrito. Si no lo cumple, cambia a ${optionB} sin culpa. La decisión reversible es casi siempre la mejor primera apuesta.${
        (input.relevant ?? []).length
          ? `\n\n**Tengo en cuenta:** ${(input.relevant ?? [])
              .slice(0, 2)
              .map((memory) => memory.content.toLowerCase())
              .join(" · ")}`
          : ""
      }`,
      "decision",
    );
  }

  // ---- Small talk --------------------------------------------------------
  if (has(folded, /^(hola|buenas|buenos dias|buenas tardes|buenas noches|hey|saludos|que tal|qué tal)\b/)) {
    return result(
      `${greetingFor(safeNow)}${who}! Soy ${capri}. 👋\n\nEstoy lista para pensar contigo: puedo **recordar** lo que me cuentes, **organizar** tu día, **generar ideas**, **resumir o mejorar** textos, **analizar archivos**, **calcular**, **escribir código** y **hablarte en voz alta**.\n\n${
        memoryList ? `Sigo teniendo presente esto:\n${memoryList}\n\n` : ""
      }¿Por dónde empezamos?`,
      "charla",
    );
  }
  if (has(folded, /quien eres|quién eres|tu nombre|te llamas|como te llamas|cómo te llamas/)) {
    return result(
      `Soy **${capri}**, tu asistente personal en este dispositivo. Mi avatar es un personaje vivo que se mueve por el chat y cambia de expresión mientras pienso, hablo o escucho.\n\n**Lo que me hace diferente**\n- 🧠 Memoria persistente: guardo datos, preferencias y pendientes en PostgreSQL.\n- ⚡ Respuestas en streaming, con motor local (sin esperas de red externas).\n- 🎨 Cambio de avatar, voz y accesibilidad en Ajustes.\n- 📎 Trabajo con archivos e imágenes que adjuntes.\n\n¿Quieres que te enseñe lo que ya recuerdo de ti?`,
      "charla",
    );
  }
  if (has(folded, /que puedes hacer|qué puedes hacer|habilidades|capacidades|para que sirves|para qué sirves|ayuda/)) {
    return result(
      `### Mis habilidades (todas activas)\n- 🧠 **Memoria real:** «recuerda que…», «¿qué recuerdas?», «olvida…». Persiste entre chats.\n- 🗓️ **Planificador:** «organiza mi día: reunión 10:00, informe, gym» → bloques con horas y pausas.\n- ✨ **Ideas:** «dame ideas para…» → seis enfoques accionables.\n- 📚 **Explicar:** «explícame cómo funciona X» → idea central, claves y ejemplo.\n- 📝 **Redacción:** «mejora este texto: …» → corrección real, no solo promesas.\n- 📄 **Archivos e imágenes:** adjunta con **+** y te doy métricas, resumen y temas.\n- 🔢 **Cálculo:** «(1350*1.21)-200» o «15% de 240».\n- 💻 **Código:** hooks, SQL, fetch, Python, regex, CSS.\n- 🎙️ **Voz:** dictado por micrófono y lectura en voz alta desde Ajustes.\n\nPruébame con algo concreto; respondo en segundos.`,
      "charla",
    );
  }
  if (has(folded, /^(gracias|mil gracias|te lo agradezco|genial|perfecto|excelente)\b/)) {
    return result(
      pick(
        [
          `¡De nada${who}! Si quieres, guardo esto en memoria para retomarlo cuando vuelvas.`,
          `Un placer${who}. ¿Damos el siguiente paso o lo dejamos aquí por ahora?`,
          `Para eso estoy. Puedo dejarte un resumen del chat o convertirlo en plan si te sirve.`,
        ],
        seedValue,
      ),
      "charla",
    );
  }
  if (has(folded, /chiste|broma|algo divertido/)) {
    return result(
      pick(
        [
          "**Chiste de programadores:** «Funciona en mi máquina». — *Y así nació el clásico: también funciona en producción, pero solo los viernes.*",
          "**Chiste de productividad:** mi lista de tareas tiene una tarea llamada «hacer la lista de tareas». La IA no la puede completar por mí.",
          "**Chiste de IA:** le pedí a un modelo que fuera breve. Respondió «ok» y luego cuarenta párrafos de contexto.",
        ],
        seedValue,
      ),
      "charla",
    );
  }
  const emotional = SAD_PATTERNS.some((word) => folded.includes(word));
  if (emotional) {
    return result(
      `Siento mucho que estés pasando por esto${who}. 🤍\n\nNo puedo quitarte lo que duele, pero sí puedo acompañarte ahora mismo:\n\n1. **Nómbralo:** escribe en una frase qué es lo que más pesa (${"sin filtros"}).\n2. **Baja el ruido:** respira 4 segundos al inspirar y 6 al espirar, cinco veces.\n3. **Un paso pequeño:** elige la acción más pequeña que te alivie hoy (beber agua, salir 10 minutos, avisar a alguien).\n\nSi quieres, te armo un plan suave para hoy, te ayudo a escribir un mensaje difícil o simplemente te escucho. ¿Qué te vendría mejor?`,
      "charla",
      { emotion: "sad" },
    );
  }
  if (has(folded, /como estas|cómo estás|que tal estas|qué tal estás|animo|desanimado|cansado/)) {
    return result(
      `Estoy al 100 %${who} (no me cansa pensar, solo la batería del móvil). Más importante: ¿cómo estás tú?\n\nSi es un día pesado, prueba algo pequeño: elige **una** tarea de 10 minutos y hazla. Si quieres, te armo un plan suave para hoy o te escucho.`,
      "charla",
    );
  }

  // ---- Continuations / fallback -----------------------------------------
  if (/^(si|sí|ok|vale|dale|hazlo|continua|continúa|y luego|claro|perfecto)[.!]?$/.test(folded)) {
    const topic = lastUserTopic(input);
    return result(
      `Vamos${who}. Para ejecutarlo bien necesito un dato: ¿${
        topic ? `seguimos con «${topic}»` : "sobre qué tema avanzamos"
      } y qué resultado quieres al final?\n\nMientras tanto, mi sugerencia: define **un** entregable mínimo y lo construimos ahora.`,
      "general",
    );
  }

  // ---- Helpful generic response -----------------------------------------
  const topic = rawText
    .replace(/^(hola|oye|por favor|necesito|quiero|puedes|podrias|podrías|ayudame|ayúdame)\b/gi, " ")
    .replace(/[¿?¡!]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  const isWriting = has(folded, /escribe|redacta|email|correo|mensaje|carta|post|publicacion/);
  const isBusiness = has(folded, /negocio|vender|cliente|precio|producto|estrategia|marketing/);
  const steps = isWriting
    ? [
        "**Objetivo:** define quién lee y qué acción quieres provocar.",
        "**Estructura:** contexto breve → propuesta concreta → siguiente paso claro.",
        "**Cierre:** una sola llamada a la acción, sin tres opciones compitiendo.",
      ]
    : isBusiness
      ? [
          "**Problema:** escribe el dolor exacto del cliente en una frase.",
          "**Oferta:** resultado + plazo + prueba; elimina adjetivos vacíos.",
          "**Prueba:** lanza a 10 personas antes de pulir la web o el logo.",
        ]
      : [
          "**Define el resultado:** ¿cómo se ve «terminado» en una frase medible?",
          "**Reduce:** parte de la versión mínima que ya puedas probar hoy.",
          "**Verifica:** mide una señal real antes de añadir complejidad.",
        ];
  return result(
    `Te ayudo con **${topic || "eso"}**. Mi enfoque rápido:\n\n${steps
      .map((step, index) => `${index + 1}. ${step}`)
      .join("\n")}\n\n${
      input.summary ? `**Sigo el hilo de este chat:** ${input.summary}\n\n` : ""
    }${
      memoryList ? `**Contexto que recuerdo:**\n${memoryList}\n\n` : ""
    }**Siguiente paso:** dime el detalle clave (para quién, en cuánto tiempo y qué restricción tienes) y lo convierto en un plan concreto. También puedo darte ideas, un resumen o un ejemplo escrito.`,
    "general",
  );
}

export function deriveTitle(text: string): string {
  return titleFromMessage(text);
}

export function settingsGreeting(settings: Settings): string {
  const name = settings.userName?.trim();
  return name ? `Hola, ${name}. Soy ${settings.assistantName}.` : `Hola, soy ${settings.assistantName}.`;
}

export function buildConversationSummary(messages: { role: Role; content: string }[], previous: string): string {
  const userLines = messages.filter((message) => message.role === "user").map((message) => message.content);
  if (!userLines.length) return previous;
  const packed = summarize(userLines.slice(-4).join(". "), 3, 360);
  return packed.slice(0, 600);
}
