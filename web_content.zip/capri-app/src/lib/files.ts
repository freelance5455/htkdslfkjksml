import type { Attachment } from "@/lib/types";

const TEXT_EXTENSION = /\.(txt|md|markdown|csv|tsv|json|log|yml|yaml|html|css|js|jsx|ts|tsx|py|sql|xml|sh|env)$/i;
export const MAX_FILE_BYTES = 12 * 1024 * 1024;

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function compressImage(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 720 / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("No pude procesar la imagen.");
  context.drawImage(bitmap, 0, 0, width, height);
  bitmap.close?.();
  return canvas.toDataURL("image/jpeg", 0.82);
}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("No pude leer el archivo."));
    reader.readAsDataURL(file);
  });
}

export async function fileToCharacterImage(file: File): Promise<Attachment> {
  if (file.size > MAX_FILE_BYTES) throw new Error("La imagen pasa de 12 MB.");
  const base: Attachment = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    name: file.name.slice(0, 120),
    kind: "image",
    mime: "image/jpeg",
    size: file.size,
  };
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 360 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("canvas");
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    return { ...base, dataUrl: canvas.toDataURL("image/png") };
  } catch {
    return { ...base, dataUrl: await readAsDataUrl(file) };
  }
}

export async function fileToAttachment(file: File): Promise<Attachment> {
  if (file.size > MAX_FILE_BYTES) {
    throw new Error(`«${file.name}» pasa de 12 MB. Prueba con uno más pequeño.`);
  }
  const base: Attachment = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    name: file.name.slice(0, 120),
    kind: "file",
    mime: file.type || "application/octet-stream",
    size: file.size,
  };

  if (file.type.startsWith("image/")) {
    let dataUrl = "";
    try {
      dataUrl = await compressImage(file);
    } catch {
      dataUrl = file.size < 900_000 ? await readAsDataUrl(file) : "";
    }
    return { ...base, kind: "image", dataUrl: dataUrl || undefined };
  }

  if (file.type.startsWith("text/") || TEXT_EXTENSION.test(file.name) || file.type === "application/json") {
    const text = (await file.text()).slice(0, 200_000);
    return { ...base, kind: "text", text };
  }

  return base;
}

export async function filesToAttachments(files: File[]): Promise<{ attachments: Attachment[]; error: string | null }> {
  const allowed = files.slice(0, 4);
  const attachments: Attachment[] = [];
  let error: string | null = null;
  for (const file of allowed) {
    try {
      attachments.push(await fileToAttachment(file));
    } catch (cause) {
      error = cause instanceof Error ? cause.message : "No pude adjuntar el archivo.";
    }
  }
  return { attachments, error };
}
