import type { AiProvider } from "@/lib/types";

export type GatewayMessage = { role: "system" | "user" | "assistant"; content: string };

export type GatewayResult = {
  text: string;
  providerName: string;
  error?: string;
};

export function isRemote(provider: AiProvider | null | undefined): boolean {
  return Boolean(provider && provider.kind !== "local" && provider.baseUrl && provider.baseUrl !== "local");
}

function normalizeBase(baseUrl: string): string {
  return baseUrl.trim().replace(/\/+$/, "");
}

function looksLikeOpenAI(provider: AiProvider): boolean {
  return ["openai", "groq", "mistral", "openrouter", "custom"].includes(provider.kind);
}

type StreamChunk = (delta: string) => void;

async function readSse(
  response: Response,
  onDelta: StreamChunk,
  extract: (payload: unknown) => string | null,
): Promise<string> {
  if (!response.body) throw new Error("El proveedor no devolvió contenido.");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let full = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const raw of lines) {
      const line = raw.trim();
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      try {
        const delta = extract(JSON.parse(data));
        if (delta) {
          full += delta;
          onDelta(delta);
        }
      } catch {
        // ignore partial JSON
      }
    }
  }
  return full;
}

async function callOpenAiCompatible(
  provider: AiProvider,
  messages: GatewayMessage[],
  onDelta?: StreamChunk,
): Promise<string> {
  const url = `${normalizeBase(provider.baseUrl)}/chat/completions`;
  const wantStream = Boolean(onDelta);
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${provider.apiKey}`,
      "HTTP-Referer": "https://capri.ai",
      "X-Title": "Capri AI",
    },
    body: JSON.stringify({
      model: provider.model,
      messages,
      temperature: provider.temperature,
      max_tokens: provider.maxTokens,
      stream: wantStream,
    }),
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`HTTP ${response.status}${detail ? ` · ${detail.slice(0, 220)}` : ""}`);
  }
  if (!wantStream) {
    const data = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    return data.choices?.[0]?.message?.content ?? "";
  }
  const text = await readSse(response, onDelta as StreamChunk, (payload) => {
    const typed = payload as { choices?: { delta?: { content?: string } }[] };
    return typed.choices?.[0]?.delta?.content ?? null;
  });
  return text;
}

async function callAnthropic(provider: AiProvider, messages: GatewayMessage[]): Promise<string> {
  const system = messages.filter((message) => message.role === "system").map((message) => message.content).join("\n\n");
  const rest = messages.filter((message) => message.role !== "system");
  const response = await fetch(`${normalizeBase(provider.baseUrl)}/messages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": provider.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: provider.model,
      max_tokens: provider.maxTokens,
      temperature: provider.temperature,
      system: system || undefined,
      messages: rest.map((message) => ({
        role: message.role === "assistant" ? "assistant" : "user",
        content: message.content,
      })),
    }),
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`HTTP ${response.status}${detail ? ` · ${detail.slice(0, 220)}` : ""}`);
  }
  const data = (await response.json()) as { content?: { type: string; text?: string }[] };
  return (data.content ?? []).filter((part) => part.type === "text").map((part) => part.text ?? "").join("");
}

async function callGemini(provider: AiProvider, messages: GatewayMessage[]): Promise<string> {
  const model = provider.model || "gemini-2.0-flash";
  const base = normalizeBase(provider.baseUrl);
  const system = messages.filter((message) => message.role === "system").map((message) => message.content).join("\n\n");
  const contents = messages
    .filter((message) => message.role !== "system")
    .map((message) => ({
      role: message.role === "assistant" ? "model" : "user",
      parts: [{ text: message.content }],
    }));
  const response = await fetch(
    `${base}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(provider.apiKey)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents,
        systemInstruction: system ? { parts: [{ text: system }] } : undefined,
        generationConfig: {
          temperature: provider.temperature,
          maxOutputTokens: provider.maxTokens,
        },
      }),
    },
  );
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`HTTP ${response.status}${detail ? ` · ${detail.slice(0, 220)}` : ""}`);
  }
  const data = (await response.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  return (data.candidates?.[0]?.content?.parts ?? []).map((part) => part.text ?? "").join("");
}

export async function callProvider(
  provider: AiProvider,
  messages: GatewayMessage[],
  onDelta?: StreamChunk,
): Promise<GatewayResult> {
  try {
    let text = "";
    if (looksLikeOpenAI(provider)) {
      text = await callOpenAiCompatible(provider, messages, onDelta);
    } else if (provider.kind === "anthropic") {
      text = await callAnthropic(provider, messages);
    } else if (provider.kind === "gemini") {
      text = await callGemini(provider, messages);
    } else {
      throw new Error("Tipo de proveedor no soportado.");
    }
    return { text: text.trim(), providerName: provider.name };
  } catch (error) {
    return {
      text: "",
      providerName: provider.name,
      error: error instanceof Error ? error.message : "Error desconocido del proveedor.",
    };
  }
}
