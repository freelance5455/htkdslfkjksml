export type Role = "user" | "assistant";

export type AttachmentKind = "image" | "text" | "file";

export type Attachment = {
  id: string;
  name: string;
  kind: AttachmentKind;
  mime: string;
  size: number;
  text?: string;
  dataUrl?: string;
};

export type MemoryKind = "perfil" | "preferencia" | "gusto" | "tarea" | "dato";

export type ChatMessage = {
  id: string;
  conversationId: string;
  role: Role;
  content: string;
  attachments: Attachment[];
  memoriesUsed: string[];
  skill: string | null;
  emotion?: Emotion | null;
  provider?: string | null;
  createdAt: string;
  pending?: boolean;
};

export type Conversation = {
  id: string;
  title: string;
  pinned: boolean;
  summary: string;
  topics: string[];
  createdAt: string;
  updatedAt: string;
  messageCount?: number;
};

export type Memory = {
  id: string;
  conversationId: string | null;
  kind: MemoryKind;
  content: string;
  keywords: string;
  importance: number;
  uses: number;
  createdAt: string;
};

/* ------------------------------------------------------------------ */
/* Open configuration                                                  */
/* ------------------------------------------------------------------ */

export type CharacterStyle = "capri" | "spark" | "nova" | "cyber" | "zen" | "quantum" | "custom";

export type Emotion =
  | "idle"
  | "happy"
  | "excited"
  | "thinking"
  | "speaking"
  | "listening"
  | "annoyed"
  | "sad"
  | "surprised"
  | "singing";
export type Tone = "cercano" | "profesional" | "divertido" | "directo" | "anime";
export type Speed = "instant" | "rapido" | "natural";
export type ProviderKind = "local" | "online" | "openai" | "anthropic" | "gemini" | "groq" | "mistral" | "openrouter" | "custom";
export type ThemeId = "midnight" | "graphite" | "light" | "sakura" | "ocean" | "forest" | "custom";
export type BubbleStyle = "modern" | "minimal" | "classic";
export type FontChoice = "system" | "serif" | "mono" | "rounded";

export type AiProvider = {
  id: string;
  name: string;
  kind: ProviderKind;
  baseUrl: string;
  model: string;
  apiKey: string;
  enabled: boolean;
  temperature: number;
  maxTokens: number;
  notes: string;
  docs?: string;
};

export type CustomBackground = {
  type: "gradient" | "image";
  css: string;
  imageUrl: string | null;
  imageOpacity: number;
  blur: number;
  dim: number;
};

export type Settings = {
  assistantName: string;
  userName: string;
  tone: Tone;
  customInstructions: string;
  memoryEnabled: boolean;
  // character
  character: CharacterStyle;
  customCharacter: string | null;
  characterSize: number;
  characterVisible: boolean;
  characterFollow: boolean;
  expressionImages: Partial<Record<Emotion, string | null>>;
  autoEmotion: boolean;
  floatingAssistant: boolean;
  floatingHotkey: boolean;
  // character interaction
  characterPhysics: boolean;
  characterSit: boolean;
  characterSeat: "composer" | "float" | "corner";
  characterReactions: boolean;
  characterGreeting: string;
  characterPetMessage: string;
  // performance / device
  performanceMode: "auto" | "low" | "medium" | "high";
  lowDataMode: boolean;
  compactMessages: boolean;
  maxContextMessages: number;
  streamChunks: boolean;
  // look
  theme: ThemeId;
  accent: string;
  background: CustomBackground;
  bubbleStyle: BubbleStyle;
  font: FontChoice;
  radius: number;
  // voice
  voiceURI: string | null;
  rate: number;
  pitch: number;
  volume: number;
  autoSpeak: boolean;
  autoSendVoice: boolean;
  liveVoice: boolean;
  listenLang: string;
  voicePreset: string;
  // behaviour
  speed: Speed;
  preferredProvider: string;
  providers: AiProvider[];
  systemPrompt: string;
  webSearchEnabled: boolean;
  // accessibility
  fontScale: number;
  highContrast: boolean;
  reduceMotion: boolean;
  spacious: boolean;
};

export const CAPRI_PROVIDER_ID = "capri-local";

export const CAPRI_ONLINE_ID = "capri-online";

export const DEFAULT_PROVIDERS: AiProvider[] = [
  {
    id: CAPRI_PROVIDER_ID,
    name: "Capri Motor local",
    kind: "local",
    baseUrl: "local",
    model: "capri-brain",
    apiKey: "",
    enabled: true,
    temperature: 0.7,
    maxTokens: 1200,
    notes: "Funciona sin internet ni claves: memoria, planes, ideas, código, cálculo, archivos y voz.",
  },
  {
    id: CAPRI_ONLINE_ID,
    name: "Capri Online",
    kind: "online",
    baseUrl: "https://text.pollinations.ai/openai",
    model: "openai",
    apiKey: "",
    enabled: true,
    temperature: 0.8,
    maxTokens: 1400,
    notes: "IA en la nube lista para usar, sin clave. Si no hay conexión, Capri responde con el motor local.",
  },
];

export const DEFAULT_SETTINGS: Settings = {
  assistantName: "Capri",
  userName: "",
  tone: "cercano",
  customInstructions: "",
  memoryEnabled: true,
  character: "capri",
  customCharacter: null,
  characterSize: 0.9,
  characterVisible: true,
  characterFollow: true,
  characterPhysics: true,
  characterSit: true,
  characterSeat: "composer",
  characterReactions: true,
  characterGreeting: "¡Hola! Soy Capri. Arrástrame, siéntame en la barra o tócame para saludar.",
  characterPetMessage: "¡Jeje! Eso ticklea. ¿En qué te ayudo?",
  performanceMode: "auto",
  lowDataMode: false,
  compactMessages: false,
  maxContextMessages: 14,
  streamChunks: true,
  expressionImages: {},
  autoEmotion: true,
  floatingAssistant: true,
  floatingHotkey: true,
  theme: "midnight",
  accent: "#14b8a6",
  background: { type: "gradient", css: "", imageUrl: null, imageOpacity: 0.45, blur: 0, dim: 0.35 },
  bubbleStyle: "modern",
  font: "system",
  radius: 18,
  voiceURI: null,
  rate: 1,
  pitch: 1.1,
  volume: 1,
  autoSpeak: false,
  autoSendVoice: true,
  liveVoice: false,
  listenLang: "es-ES",
  voicePreset: "dulce",
  speed: "rapido",
  preferredProvider: CAPRI_PROVIDER_ID,
  providers: DEFAULT_PROVIDERS,
  systemPrompt: "",
  webSearchEnabled: false,
  fontScale: 1,
  highContrast: false,
  reduceMotion: false,
  spacious: false,
};

export type AppStats = {
  conversations: number;
  messages: number;
  memories: number;
};

export type AppState = {
  settings: Settings;
  conversations: Conversation[];
  activeId: string | null;
  messages: ChatMessage[];
  memories: Memory[];
  stats: AppStats;
};

export const CHARACTER_STYLES: {
  id: CharacterStyle;
  name: string;
  description: string;
  accent: string;
  sprite: string;
}[] = [
  { id: "capri", name: "Capri Chibi", description: "Vocaloid teal con cascos", accent: "#2dd4bf", sprite: "/characters/capri-idle.png" },
  { id: "spark", name: "Capri Spark", description: "Estrella centelleante", accent: "#a78bfa", sprite: "" },
  { id: "nova", name: "Nova Celestial", description: "Esfera cósmica pulsante", accent: "#f472b6", sprite: "" },
  { id: "cyber", name: "Cyber Bot", description: "Asistente robótico", accent: "#2dd4bf", sprite: "" },
  { id: "zen", name: "Zen Armonía", description: "Equilibrio y calma", accent: "#fbbf24", sprite: "" },
  { id: "quantum", name: "Púlsar Cuántico", description: "Ondas de energía", accent: "#60a5fa", sprite: "" },
  { id: "custom", name: "Mi imagen", description: "Tu foto o dibujo", accent: "#c084fc", sprite: "" },
];

export const MOOD_SPRITES: Record<string, string> = {
  idle: "/characters/capri-idle.png",
  happy: "/characters/capri-happy.png",
  thinking: "/characters/capri-thinking.png",
  speaking: "/characters/capri-speaking.png",
  listening: "/characters/capri-listening.png",
  singing: "/characters/capri-microphone.png",
  annoyed: "/characters/capri-annoyed.png",
  sad: "/characters/capri-sad.png",
  surprised: "/characters/capri-surprised.png",
  excited: "/characters/capri-excited.png",
};

export const EMOTIONS: { id: Emotion; name: string; hint: string; sprite: string }[] = [
  { id: "idle", name: "Neutral", hint: "Reposo y saludo", sprite: MOOD_SPRITES.idle },
  { id: "happy", name: "Feliz", hint: "Respuestas positivas", sprite: MOOD_SPRITES.happy },
  { id: "excited", name: "Emocionada", hint: "Logros y buenas noticias", sprite: "/characters/capri-excited.png" },
  { id: "thinking", name: "Pensando", hint: "Mientras procesa", sprite: MOOD_SPRITES.thinking },
  { id: "speaking", name: "Hablando", hint: "Mientras responde", sprite: MOOD_SPRITES.speaking },
  { id: "listening", name: "Escuchando", hint: "Micrófono activo", sprite: MOOD_SPRITES.listening },
  { id: "annoyed", name: "Enfadada", hint: "Insultos o quejas", sprite: "/characters/capri-annoyed.png" },
  { id: "sad", name: "Triste", hint: "Temas sensibles", sprite: "/characters/capri-sad.png" },
  { id: "surprised", name: "Sorprendida", hint: "Sorpresa o asombro", sprite: "/characters/capri-surprised.png" },
  { id: "singing", name: "Cantando", hint: "Voz y música", sprite: MOOD_SPRITES.singing },
];

export function expressionImage(settings: Settings, emotion: Emotion): string | null {
  const override = settings.expressionImages?.[emotion];
  if (override) return override;
  if (settings.character === "custom") return settings.customCharacter;
  if (settings.character === "capri") return EMOTIONS.find((item) => item.id === emotion)?.sprite ?? MOOD_SPRITES.idle;
  return null;
}

export const THEMES: {
  id: ThemeId;
  name: string;
  swatch: [string, string];
  vars: Record<string, string>;
}[] = [
  {
    id: "midnight",
    name: "Medianoche",
    swatch: ["#0b1220", "#14b8a6"],
    vars: {
      "--bg": "#080b12",
      "--bg-soft": "#0d131f",
      "--panel": "rgba(18,24,36,0.92)",
      "--panel-solid": "#121826",
      "--panel-2": "#172033",
      "--line": "rgba(148,163,184,0.16)",
      "--line-strong": "rgba(45,212,191,0.34)",
      "--text": "#eef2f8",
      "--muted": "#94a3b8",
      "--glow-1": "rgba(20,184,166,0.22)",
      "--glow-2": "rgba(59,130,246,0.16)",
    },
  },
  {
    id: "graphite",
    name: "Grafito",
    swatch: ["#141518", "#a3a3a3"],
    vars: {
      "--bg": "#0c0d0f",
      "--bg-soft": "#121316",
      "--panel": "rgba(24,26,30,0.94)",
      "--panel-solid": "#181a1e",
      "--panel-2": "#202329",
      "--line": "rgba(255,255,255,0.1)",
      "--line-strong": "rgba(255,255,255,0.26)",
      "--text": "#f4f4f5",
      "--muted": "#a1a1aa",
      "--glow-1": "rgba(120,120,130,0.16)",
      "--glow-2": "rgba(80,80,90,0.14)",
    },
  },
  {
    id: "light",
    name: "Claro",
    swatch: ["#f7f8fa", "#0f766e"],
    vars: {
      "--bg": "#f5f6f8",
      "--bg-soft": "#ffffff",
      "--panel": "rgba(255,255,255,0.96)",
      "--panel-solid": "#ffffff",
      "--panel-2": "#eef1f5",
      "--line": "rgba(15,23,42,0.12)",
      "--line-strong": "rgba(15,118,110,0.4)",
      "--text": "#0f172a",
      "--muted": "#5b6779",
      "--glow-1": "rgba(20,184,166,0.14)",
      "--glow-2": "rgba(59,130,246,0.1)",
    },
  },
  {
    id: "sakura",
    name: "Sakura",
    swatch: ["#1a1220", "#f9a8d4"],
    vars: {
      "--bg": "#120d18",
      "--bg-soft": "#1a1222",
      "--panel": "rgba(32,22,40,0.94)",
      "--panel-solid": "#201628",
      "--panel-2": "#2b1c36",
      "--line": "rgba(249,168,212,0.18)",
      "--line-strong": "rgba(249,168,212,0.42)",
      "--text": "#fdf2f8",
      "--muted": "#c9a9c1",
      "--glow-1": "rgba(249,168,212,0.22)",
      "--glow-2": "rgba(192,132,252,0.18)",
    },
  },
  {
    id: "ocean",
    name: "Océano",
    swatch: ["#071a24", "#38bdf8"],
    vars: {
      "--bg": "#06141c",
      "--bg-soft": "#0a1d29",
      "--panel": "rgba(13,33,44,0.94)",
      "--panel-solid": "#0d212c",
      "--panel-2": "#123040",
      "--line": "rgba(56,189,248,0.18)",
      "--line-strong": "rgba(56,189,248,0.42)",
      "--text": "#ecfeff",
      "--muted": "#8fb7c9",
      "--glow-1": "rgba(56,189,248,0.2)",
      "--glow-2": "rgba(45,212,191,0.16)",
    },
  },
  {
    id: "forest",
    name: "Bosque",
    swatch: ["#0b1710", "#4ade80"],
    vars: {
      "--bg": "#08120c",
      "--bg-soft": "#0e1c14",
      "--panel": "rgba(18,32,24,0.94)",
      "--panel-solid": "#122018",
      "--panel-2": "#1a2e22",
      "--line": "rgba(74,222,128,0.16)",
      "--line-strong": "rgba(74,222,128,0.4)",
      "--text": "#f0fdf4",
      "--muted": "#94b8a4",
      "--glow-1": "rgba(74,222,128,0.18)",
      "--glow-2": "rgba(20,184,166,0.14)",
    },
  },
];

export const ACCENTS = ["#14b8a6", "#a855f7", "#3b82f6", "#f472b6", "#f59e0b", "#ef4444", "#22c55e", "#e2e8f0"];

export const VOICE_PRESETS: { id: string; name: string; description: string; rate: number; pitch: number; volume: number }[] = [
  { id: "dulce", name: "Dulce", description: "Aguda, cercana y animada", rate: 1.04, pitch: 1.18, volume: 1 },
  { id: "natural", name: "Natural", description: "Equilibrada, conversacional", rate: 1, pitch: 1.02, volume: 1 },
  { id: "calma", name: "Calma", description: "Lenta y relajante", rate: 0.9, pitch: 0.98, volume: 0.9 },
  { id: "energia", name: "Energía", description: "Rápida y expresiva", rate: 1.18, pitch: 1.12, volume: 1 },
  { id: "narrador", name: "Narrador", description: "Grave y pausada", rate: 0.95, pitch: 0.85, volume: 1 },
];

export const LISTEN_LANGS = [
  { id: "es-ES", label: "Español (España)" },
  { id: "es-MX", label: "Español (México)" },
  { id: "es-AR", label: "Español (Argentina)" },
  { id: "en-US", label: "English (US)" },
  { id: "en-GB", label: "English (UK)" },
  { id: "pt-BR", label: "Português (Brasil)" },
  { id: "fr-FR", label: "Français" },
  { id: "de-DE", label: "Deutsch" },
  { id: "it-IT", label: "Italiano" },
  { id: "ja-JP", label: "日本語" },
];

export const PROVIDER_PRESETS: {
  kind: ProviderKind;
  name: string;
  baseUrl: string;
  model: string;
  docs: string;
}[] = [
  { kind: "openai", name: "OpenAI", baseUrl: "https://api.openai.com/v1", model: "gpt-4o-mini", docs: "https://platform.openai.com/api-keys" },
  { kind: "groq", name: "Groq", baseUrl: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile", docs: "https://console.groq.com/keys" },
  { kind: "anthropic", name: "Anthropic", baseUrl: "https://api.anthropic.com/v1", model: "claude-3-5-haiku-latest", docs: "https://console.anthropic.com/settings/keys" },
  { kind: "gemini", name: "Google Gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", model: "gemini-2.0-flash", docs: "https://aistudio.google.com/app/apikey" },
  { kind: "mistral", name: "Mistral", baseUrl: "https://api.mistral.ai/v1", model: "mistral-small-latest", docs: "https://console.mistral.ai/api-keys" },
  { kind: "openrouter", name: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1", model: "openai/gpt-4o-mini", docs: "https://openrouter.ai/keys" },
  { kind: "custom", name: "API compatible OpenAI", baseUrl: "http://localhost:11434/v1", model: "llama3.1", docs: "https://platform.openai.com/docs/api-reference" },
];

export function mergeSettings(partial: Partial<Settings> | null | undefined): Settings {
  const clean = partial ?? {};
  const merged: Settings = { ...DEFAULT_SETTINGS, ...clean };
  merged.fontScale = Math.min(1.35, Math.max(0.9, Number(merged.fontScale) || 1));
  merged.rate = Math.min(1.8, Math.max(0.5, Number(merged.rate) || 1));
  merged.pitch = Math.min(1.8, Math.max(0.5, Number(merged.pitch) || 1.1));
  merged.volume = Math.min(1, Math.max(0, Number(merged.volume) ?? 1));
  merged.characterSize = Math.min(1.8, Math.max(0.5, Number(merged.characterSize) || 0.9));
  merged.expressionImages = typeof clean.expressionImages === "object" && clean.expressionImages ? { ...clean.expressionImages } : {};
  merged.maxContextMessages = Math.min(30, Math.max(4, Number(merged.maxContextMessages) || 14));
  merged.characterSeat = ["composer", "float", "corner"].includes(merged.characterSeat) ? merged.characterSeat : "composer";
  merged.performanceMode = ["auto", "low", "medium", "high"].includes(merged.performanceMode) ? merged.performanceMode : "auto";
  merged.characterGreeting = (merged.characterGreeting || "").slice(0, 200);
  merged.characterPetMessage = (merged.characterPetMessage || "").slice(0, 200);
  merged.radius = Math.min(28, Math.max(4, Number(merged.radius) || 18));
  merged.assistantName = (merged.assistantName || "Capri").slice(0, 24);
  merged.userName = (merged.userName || "").slice(0, 32);
  merged.customInstructions = (merged.customInstructions || "").slice(0, 800);
  merged.systemPrompt = (merged.systemPrompt || "").slice(0, 4000);
  merged.background = {
    ...DEFAULT_SETTINGS.background,
    ...(clean.background ?? {}),
  };
  merged.background.dim = Math.min(0.9, Math.max(0, Number(merged.background.dim) || 0));
  merged.background.blur = Math.min(20, Math.max(0, Number(merged.background.blur) || 0));
  merged.background.imageOpacity = Math.min(1, Math.max(0.05, Number(merged.background.imageOpacity) || 0.45));
  merged.providers = Array.isArray(clean.providers) && clean.providers.length
    ? clean.providers.slice(0, 12).map((provider) => ({
        ...provider,
        id: provider.id || `p-${Math.random().toString(36).slice(2, 9)}`,
        temperature: Math.min(2, Math.max(0, Number(provider.temperature) || 0.7)),
        maxTokens: Math.min(16000, Math.max(128, Number(provider.maxTokens) || 1200)),
        notes: (provider.notes || "").slice(0, 500),
        apiKey: (provider.apiKey || "").slice(0, 400),
        baseUrl: (provider.baseUrl || "").slice(0, 300),
        model: (provider.model || "").slice(0, 120),
        name: (provider.name || "Proveedor").slice(0, 60),
      }))
    : DEFAULT_PROVIDERS;
  if (!merged.providers.some((provider) => provider.id === merged.preferredProvider)) {
    merged.preferredProvider = merged.providers[0]?.id ?? CAPRI_PROVIDER_ID;
  }
  return merged;
}

export function isOnlineEngine(provider: AiProvider | null | undefined): boolean {
  return Boolean(provider && (provider.kind === "online" || provider.kind === "openai" || provider.kind === "anthropic" || provider.kind === "gemini" || provider.kind === "groq" || provider.kind === "mistral" || provider.kind === "openrouter" || provider.kind === "custom"));
}

export function activeProvider(settings: Settings): AiProvider | null {
  return settings.providers.find((provider) => provider.id === settings.preferredProvider) ?? settings.providers[0] ?? null;
}

export function maskKey(key: string): string {
  if (!key) return "";
  if (key.length <= 8) return "••••";
  return `${key.slice(0, 4)}••••${key.slice(-4)}`;
}
