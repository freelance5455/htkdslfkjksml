import type { MemoryKind } from "@/lib/types";

const STOPWORDS = new Set(
  `a al algo algun alguna algunas alguno algunos ante antes aqui asi aun bajo bien cada casi como con contra cual cuales cualquier cuando cuanto de del desde donde dos el ella ellas ellos en entre era eran es esa esas ese eso esos esta estaba estan este esto estos estoy fue fueron ha habia han hasta hay la las le les lo los mas me mi mis mucho muy nada ni no nos nosotros o os otro para pero poco por porque que quien quienes se sea segun ser si sin sobre solo son soy su sus tambien tan tanto te tengo ti tiene tienen todo todos tu tus un una uno unos vosotros y ya yo
  the and for with that this from have has are was were you your our about into over under they them their will would can could should what when where which who whom how why not but all any can just like make made more most much need only other out some such than then there these
  haz hacer quiero queria necesito puedes podrias ayudame ayuda dime dame decir damos favor gracias hola buenas buenos
  `.split(/\s+/).filter(Boolean),
);

export function fold(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

export function tokens(value: string): string[] {
  return fold(value)
    .replace(/[^a-z0-9ñ\s%+/-]/g, " ")
    .split(/\s+/)
    .filter((word) => word.length > 2 && !STOPWORDS.has(word) && !/^\d+$/.test(word));
}

export function keywords(value: string, limit = 8): string[] {
  const counts = new Map<string, number>();
  for (const token of tokens(value)) {
    counts.set(token, (counts.get(token) ?? 0) + 1);
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)
    .slice(0, limit)
    .map(([word]) => word);
}

export function titleFromMessage(value: string): string {
  const clean = value
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return "Nuevo chat";
  const short = clean.length > 46 ? `${clean.slice(0, 46).trimEnd()}…` : clean;
  return short.charAt(0).toUpperCase() + short.slice(1);
}

export function countWords(value: string): number {
  const match = value.trim().match(/[\p{L}\p{N}'’-]+/gu);
  return match ? match.length : 0;
}

export function sentenceSplit(value: string): string[] {
  return value
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?…])\s+/)
    .map((sentence) => sentence.trim())
    .filter((sentence) => sentence.length > 0);
}

export function summarize(value: string, maxSentences = 4, maxChars = 900): string {
  const sentences = sentenceSplit(value);
  if (sentences.length <= maxSentences) return sentences.join(" ").slice(0, maxChars);
  const freq = new Map<string, number>();
  for (const token of tokens(value)) freq.set(token, (freq.get(token) ?? 0) + 1);
  const scored = sentences.map((sentence, index) => {
    const words = tokens(sentence);
    const score =
      words.reduce((sum, word) => sum + (freq.get(word) ?? 0), 0) / Math.max(4, words.length) +
      (index === 0 ? 1.5 : 0);
    return { sentence, index, score };
  });
  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, maxSentences)
    .sort((a, b) => a.index - b.index)
    .map((entry) => entry.sentence)
    .join(" ")
    .slice(0, maxChars);
}

export function cleanRewrite(value: string): { text: string; changes: string[] } {
  const changes: string[] = [];
  let text = value.replace(/\s+/g, " ").trim();
  const fillers = /\b(o sea|es que|pues nada|pues|este+|eh+|em+|tipo|como que|digamos|en plan)\b[,:\s]*/gi;
  if (fillers.test(text)) {
    changes.push("quité muletillas y palabras de relleno");
    text = text.replace(fillers, " ");
  }
  const repeated = text.replace(/\b(\p{L}+)\s+\1\b/giu, "$1");
  if (repeated !== text) {
    changes.push("eliminé palabras repetidas");
    text = repeated;
  }
  const clauses = text.split(/\s+y\s+/i);
  if (clauses.length > 1) {
    const seen = new Set<string>();
    const unique = clauses.filter((clause) => {
      const key = fold(clause).replace(/\b(muy|bastante|realmente)\b/g, "").replace(/\s+/g, " ").trim();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    if (unique.length < clauses.length) {
      changes.push("uní ideas que se repetían");
      text = unique.join(" y ");
    }
  }
  const tidy = text
    .replace(/\s+([,.;:!?])/g, "$1")
    .replace(/([,.;:!?])(?=[^\s\d])/g, "$1 ")
    .replace(/\s+/g, " ")
    .trim();
  if (tidy !== text) {
    changes.push("ordené la puntuación y los espacios");
    text = tidy;
  }
  const capitalized = text.replace(
    /(^|[.!?]\s+)(\p{Ll})/gu,
    (_all, prefix: string, letter: string) => `${prefix}${letter.toUpperCase()}`,
  );
  if (capitalized !== text) {
    changes.push("puse mayúscula al inicio de cada frase");
    text = capitalized;
  }
  if (text && !/[.!?…]$/.test(text)) {
    text = `${text}.`;
    changes.push("cerré la última frase");
  }
  return { text, changes };
}

export function splitTrailingRequest(text: string): { head: string; tail: string | null } {
  const match = text.match(NEW_REQUEST);
  if (!match || match.index === undefined) return { head: text, tail: null };
  return { head: text.slice(0, match.index), tail: text.slice(match.index).replace(/^\s+y\s+/i, "") };
}

export function extractTasks(value: string): string[] {
  const withoutGreeting = value
    .replace(/^\s*(hola|buenas|buenos d[ií]as|hey|oye|qué tal)[,!.\s]+/i, "")
    .replace(/^\s*(?:me llamo|mi nombre es|soy)\s+[\p{L}'-]+[,!.\s]+/iu, "")
    .replace(/^[\s\S]*?\b(?:organ[ií]za(?:me|r)?|planif[ií]ca(?:me|r)?|ag[ée]nda(?:me)?|planea|prepara|hazme|haz|crea|arma)\b[^:.\n]{0,40}:\s*/iu, "");
  const stripped = withoutGreeting.replace(
    /^\s*(?:oye\s+)?(?:por favor\s+)?(?:organiza(?:me|r)?|planifica(?:me|r)?|agenda(?:me)?|planea|prepara|hazme|haz|crea|arma)(?:\s+(?:un|una|el|la|mi))?\s*(?:plan|horario|agenda|rutina)?\s*(?:de|para|del|de la)?\s*(?:mi\s+)?(?:d[ií]a|jornada|semana|hoy|mañana|tarde)?\b[\s:,.–-]*/i,
    "",
  );
  const clean = stripped.trim() ? stripped : value;
  return clean
    .split(/\n|;|,(?=\s|\p{L})|\s+y\s+(?=(?:luego\s+)?\p{L}+)/u)
    .map((task) =>
      task
        .replace(/^[-•*\d.)\s]+/, "")
        .replace(/\b(?:desde|a|sobre|antes de|después de|a eso de)\s+las?\s*\d{1,2}(?::\d{2})?\s*(?:h|hs|horas)?\b/gi, "")
        .replace(/\b\d{1,2}:\d{2}\b/g, "")
        .replace(/^[:\-–,\s]+|[:\-–,\s]+$/g, "")
        .trim(),
    )
    .filter((task) => task.length > 2 && task.length < 120)
    .slice(0, 8);
}

export type MemoryCandidate = { kind: MemoryKind; content: string; importance: number };

const MEMORY_STOP =
  /\s+(?:y\s+)?(?:olvida|olvidate|olvídalo|borra|elimina|quita|recuerda|recuérdame|recuerdame|no olvides|apunta|guarda|memoriza)\b[\s\S]*$/i;
const NEW_REQUEST =
  /\s+y\s+(?=(?:dame|dime|haz|hazme|organiza|planifica|agenda|explica|explícame|resume|resúmeme|escribe|calcula|cuánto|cuanto|ayúdame|ayudame|genera|crea|propón|propon|recomienda|traduce|corrige|mejora)\b)/i;

function addCandidate(list: MemoryCandidate[], kind: MemoryKind, raw: string, importance: number) {
  const head = raw.trim().replace(MEMORY_STOP, "").split(NEW_REQUEST)[0];
  let content = head.replace(/^[,:\-\s]+/, "").replace(/[.\s]+$/, "");
  content = content.replace(/^(que|de que)\s+/i, "").trim();
  if (content.length < 3 || content.length > 200) return;
  content = content.charAt(0).toUpperCase() + content.slice(1);
  if (list.some((item) => fold(item.content) === fold(content))) return;
  list.push({ kind, content, importance });
}

function overlapRatio(a: string, b: string): number {
  const left = new Set(tokens(a));
  const right = new Set(tokens(b));
  if (!left.size || !right.size) return 0;
  let shared = 0;
  for (const token of left) if (right.has(token)) shared += 1;
  return shared / Math.min(left.size, right.size);
}

export function extractMemoryCandidates(text: string): MemoryCandidate[] {
  const found: MemoryCandidate[] = [];
  const source = text.replace(/\s+/g, " ").trim();
  if (!source) return found;

  const nameMatch = source.match(/\b(?:me llamo|mi nombre es)\s+([\p{L}][\p{L}'-]{1,24}(?:\s+[\p{L}][\p{L}'-]{1,24})?)/iu);
  if (nameMatch) addCandidate(found, "perfil", `Se llama ${nameMatch[1]}`, 4);
  const greetingName = source.match(/(?:^|hola[,!.\s]+|buenas[,!.\s]+|buenos d[ií]as[,!.\s]+)soy\s+([A-ZÁÉÍÓÚÑ][\p{L}'-]{1,20})/iu);
  if (greetingName) addCandidate(found, "perfil", `Se llama ${greetingName[1]}`, 4);
  const jobMatch = source.match(/\bsoy\s+((?:profesor|profesora|programador|programadora|diseñador|diseñadora|estudiante|médico|medico|ingeniero|ingeniera|emprendedor|emprendedora|docente|abogado|abogada|enfermero|enfermera)[\p{L}\s]{0,20})/iu);
  if (jobMatch) {
    addCandidate(found, "perfil", `Se dedica a: ${jobMatch[1].trim()}`, 2);
  }

  const explicit =
    /\b(?:recuerda(?:te|lo)?|recuérdame|recuerdame|no olvides|ten en cuenta|apunta|guarda|memoriza)\b(?:\s+que)?[:\s]+([^.!?\n]{3,200})/giu;
  for (const match of source.matchAll(explicit)) {
    const raw = match[1];
    const kind: MemoryKind = /\b(?:comprar|llamar|enviar|entregar|terminar|ir a|pagar|reservar|cita|reunion|reunión|mañana|hoy a las)\b/i.test(
      raw,
    )
      ? "tarea"
      : "dato";
    addCandidate(found, kind, raw, kind === "tarea" ? 3 : 3);
  }

  const preference =
    /\b(?:prefiero|preferiria|preferiría|me gusta|me gustan|me encanta|me encantan|no me gusta|no me gustan|odio|detesto)\b[:\s]+([^.!?\n]{2,120})/giu;
  for (const match of source.matchAll(preference)) {
    const negative = /^(no me gusta|no me gustan|odio|detesto)/i.test(match[0].trim());
    addCandidate(found, negative ? "gusto" : "preferencia", match[0].trim(), 2);
  }

  const personal =
    /\bmi\s+([\p{L}\s]{3,28}?)\s+(?:es|son|está|esta|esta en)\s+([^.!?\n]{2,90})/giu;
  for (const match of source.matchAll(personal)) {
    addCandidate(found, "dato", `Su ${match[1].trim()} es ${match[2].trim()}`, 2);
  }

  const places = /\b(?:vivo en|vive en|trabajo en|trabaja en|estudio en|estudia en)\s+([^.!?\n]{2,70})/giu;
  for (const match of source.matchAll(places)) {
    addCandidate(found, "perfil", `${match[0].trim()}`, 3);
  }

  const duties = /\b(?:tengo que|debo|he de)\s+([^.!?\n]{3,140})/giu;
  for (const match of source.matchAll(duties)) {
    addCandidate(found, "tarea", match[0].trim(), 2);
  }

  const age = /\btengo\s+(\d{1,2})\s+años\b/iu;
  const ageMatch = source.match(age);
  if (ageMatch) addCandidate(found, "perfil", `Tiene ${ageMatch[1]} años`, 3);

  return found
    .filter(
      (candidate, index) =>
        !found.some((other, otherIndex) => otherIndex < index && overlapRatio(other.content, candidate.content) > 0.7),
    )
    .slice(0, 6);
}

export function relativeTime(iso: string): string {
  const date = new Date(iso);
  const diff = Date.now() - date.getTime();
  if (Number.isNaN(diff)) return "";
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "ahora";
  if (minutes < 60) return `hace ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `hace ${hours} h`;
  const days = Math.round(hours / 24);
  if (days < 7) return `hace ${days} d`;
  return date.toLocaleDateString("es", { day: "2-digit", month: "short" });
}

export function sortMemories<T extends { kind: MemoryKind; createdAt: string }>(list: T[]): T[] {
  const order: Record<MemoryKind, number> = {
    perfil: 0,
    preferencia: 1,
    gusto: 2,
    tarea: 3,
    dato: 4,
  };
  return [...list].sort(
    (a, b) => order[a.kind] - order[b.kind] || b.createdAt.localeCompare(a.createdAt),
  );
}
