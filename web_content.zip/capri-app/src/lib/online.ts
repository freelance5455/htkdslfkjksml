import type { AiProvider } from "@/lib/types";

export type OnlineMessage = { role: "system" | "user" | "assistant"; content: string };

const ONLINE_ENDPOINT = process.env.CAPRI_ONLINE_URL || "https://text.pollinations.ai/openai";
const ONLINE_KEY = process.env.CAPRI_ONLINE_API_KEY || "";
const ONLINE_MODEL = process.env.CAPRI_ONLINE_MODEL || "openai";

export type OnlineResult = { text: string; error?: string; model: string };

function extractSse(payload: unknown): string | null {
  const typed = payload as { choices?: { delta?: { content?: string }; message?: { content?: string } }[] };
  return typed.choices?.[0]?.delta?.content ?? typed.choices?.[0]?.message?.content ?? null;
}

/**
 * Capri Online: cloud engine that works out of the box (no user key).
 * Uses a public OpenAI-compatible endpoint, overridable with env vars or any
 * user provider configured in Settings.
 */
export async function callCapriOnline(
  messages: OnlineMessage[],
  options: { temperature?: number; maxTokens?: number; model?: string; provider?: AiProvider; onDelta?: (delta: string) => void } = {},
): Promise<OnlineResult> {
  const primary = options.model || ONLINE_MODEL;
  const models = [primary, "openai"].filter((model, index, list) => model && list.indexOf(model) === index);
  let lastError = "";

  const plain = await requestPlainText(messages, primary);
  if (!plain.error && plain.text) {
    options.onDelta?.(plain.text);
    return plain;
  }
  lastError = plain.error ?? "Respuesta vacía";

  for (const model of models) {
    const attempt = await requestOnline(messages, {
      ...options,
      model,
    });
    if (!attempt.error && attempt.text) return attempt;
    lastError = attempt.error ?? "Respuesta vacía";
    if (/limit|capacity|503|429|UNAVAILABLE|FREE_LIMIT/i.test(lastError)) break;
  }

  if (ONLINE_KEY) return { text: "", model: primary, error: lastError };

  return { text: "", model: primary, error: lastError };
}

async function requestOnline(
  messages: OnlineMessage[],
  options: { temperature?: number; maxTokens?: number; model: string; onDelta?: (delta: string) => void },
): Promise<OnlineResult> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (ONLINE_KEY) headers.Authorization = `Bearer ${ONLINE_KEY}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6_500);

  try {
    const response = await fetch(ONLINE_ENDPOINT, {
      method: "POST",
      headers,
      signal: controller.signal,
      body: JSON.stringify({
        model: options.model,
        messages,
        temperature: options.temperature ?? 0.8,
        max_tokens: options.maxTokens ?? 1400,
        stream: Boolean(options.onDelta),
        private: true,
      }),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      return { text: "", model: options.model, error: `HTTP ${response.status}${detail ? ` · ${detail.slice(0, 160)}` : ""}` };
    }

    if (!options.onDelta || !response.body) {
      const data = (await response.json()) as unknown;
      const text = extractSse(data) ?? "";
      if (text && options.onDelta) options.onDelta(text);
      return { text: text.trim(), model: options.model };
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let full = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const raw of lines) {
        const line = raw.trim();
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const delta = extractSse(JSON.parse(data));
          if (delta) {
            full += delta;
            options.onDelta(delta);
          }
        } catch {
          // partial JSON
        }
      }
    }
    return { text: full.trim(), model: options.model };
  } catch (error) {
    return {
      text: "",
      model: options.model,
      error: error instanceof Error ? (error.name === "AbortError" ? "Tiempo de espera agotado" : error.message) : "Error de red",
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function requestPlainText(messages: OnlineMessage[], model: string): Promise<OnlineResult> {
  try {
    const prompt = messages
      .filter((message) => message.role !== "system")
      .slice(-4)
      .map((message) => `${message.role === "user" ? "Usuario" : "Asistente"}: ${message.content}`)
      .join("\n");
    const system = messages.find((message) => message.role === "system")?.content ?? "";
    const full = `${system.slice(0, 700)}\n\n${prompt}`.slice(0, 1800);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5_000);
    const response = await fetch(`https://text.pollinations.ai/${encodeURIComponent(full)}?model=${encodeURIComponent(model)}`, {
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!response.ok) return { text: "", model, error: `HTTP ${response.status}` };
    const text = await response.text();
    if (!text.trim() || text.trim().startsWith("{")) return { text: "", model, error: "Respuesta no válida" };
    return { text: text.trim(), model };
  } catch (error) {
    return {
      text: "",
      model,
      error: error instanceof Error ? (error.name === "AbortError" ? "Tiempo de espera agotado" : error.message) : "Error de red",
    };
  }
}
