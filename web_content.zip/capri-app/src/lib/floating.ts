"use client";

type DocumentPictureInPicture = {
  requestWindow: (options?: {
    width?: number;
    height?: number;
    disallowReturnToOpener?: boolean;
    preferInitialWindowPlacement?: boolean;
  }) => Promise<Window>;
  window: Window | null;
};

function getPiP(): DocumentPictureInPicture | null {
  if (typeof window === "undefined") return null;
  const scope = window as unknown as { documentPictureInPicture?: DocumentPictureInPicture };
  return scope.documentPictureInPicture ?? null;
}

export function canFloat(): boolean {
  return Boolean(getPiP());
}

export function isMobileDevice(): boolean {
  if (typeof navigator === "undefined") return false;
  return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
}

export function supportsAlwaysOnTop(): boolean {
  return Boolean(getPiP());
}

export type FloatResult = { ok: boolean; message: string; mode: "pip" | "popup" | "none" };

/**
 * Opens Capri as an always-on-top assistant window.
 * Uses Document Picture-in-Picture when available (Chrome/Edge 116+),
 * otherwise falls back to a small popup window that floats over the desktop.
 */
export async function openFloatingAssistant(): Promise<FloatResult> {
  if (typeof window === "undefined") return { ok: false, message: "Solo funciona en el navegador.", mode: "none" };
  const url = `${window.location.origin}/mini`;

  const pip = getPiP();
  if (pip) {
    try {
      const existing = pip.window;
      if (existing && !existing.closed) {
        existing.focus();
        return { ok: true, message: "La ventana flotante ya está abierta.", mode: "pip" };
      }
      const pipWindow = await pip.requestWindow({ width: 380, height: 600, disallowReturnToOpener: false });
      const doc = pipWindow.document;
      doc.title = "Capri AI";
      Object.assign(doc.body.style, { margin: "0", background: "#080b12", overflow: "hidden" });
      const frame = doc.createElement("iframe");
      frame.src = `${url}?mode=voice&pip=1`;
      frame.title = "Capri AI flotante";
      frame.allow = "microphone; autoplay; clipboard-write";
      Object.assign(frame.style, {
        border: "0",
        width: "100%",
        height: "100%",
        display: "block",
        background: "#080b12",
      });
      doc.body.appendChild(frame);
      // keep the tiny PiP window responsive to mobile-sized layouts
      try {
        pipWindow.matchMedia("(display-mode: picture-in-picture)").addEventListener?.("change", () => undefined);
      } catch {
        // ignore
      }
      return {
        ok: true,
        message: "Capri ya flota sobre otras ventanas. Mantén esta pestaña abierta.",
        mode: "pip",
      };
    } catch {
      // fall through to popup
    }
  }

  if (isMobileDevice()) {
    return {
      ok: false,
      message:
        "En móvil los navegadores no permiten ventanas sobre otras apps. Instala Capri como app (menú del navegador → Añadir a pantalla de inicio) y usa el modo voz: sigue activo con el micrófono.",
      mode: "none",
    };
  }

  const popup = window.open(
    `${url}?mode=voice&pip=1`,
    "capri-assistant",
    "popup=yes,width=392,height=640,left=80,top=80,resizable=yes,scrollbars=no",
  );
  if (popup) {
    popup.focus();
    return {
      ok: true,
      message: "Abierto en ventana flotante (solo voz). Para que quede siempre encima de cualquier app, usa Chrome o Edge 116+.",
      mode: "popup",
    };
  }

  return {
    ok: false,
    message: "El navegador bloqueó la ventana emergente. Permite las ventanas para este sitio y vuelve a intentarlo.",
    mode: "none",
  };
}
