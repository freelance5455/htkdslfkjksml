export type SpeechCallbacks = {
  voiceURI?: string | null;
  rate?: number;
  pitch?: number;
  volume?: number;
  lang?: string;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: () => void;
};

export function hasSynthesis(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function listVoices(): SpeechSynthesisVoice[] {
  if (!hasSynthesis()) return [];
  return window.speechSynthesis.getVoices();
}

export function loadVoices(callback: (voices: SpeechSynthesisVoice[]) => void): () => void {
  if (!hasSynthesis()) return () => undefined;
  const synth = window.speechSynthesis;
  const deliver = () => callback(synth.getVoices());
  deliver();
  synth.addEventListener("voiceschanged", deliver);
  return () => synth.removeEventListener("voiceschanged", deliver);
}

export function speak(text: string, callbacks: SpeechCallbacks = {}): boolean {
  if (!hasSynthesis() || !text.trim()) return false;
  const synth = window.speechSynthesis;
  synth.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "es-ES";
  utterance.rate = callbacks.rate ?? 1.05;
  utterance.pitch = callbacks.pitch ?? 1.1;
  utterance.volume = callbacks.volume ?? 1;
  const voices = synth.getVoices();
  const chosen =
    voices.find((voice) => voice.voiceURI === callbacks.voiceURI) ??
    voices.find((voice) => (callbacks.lang ? voice.lang === callbacks.lang : /^es/i.test(voice.lang))) ??
    voices.find((voice) => /^es/i.test(voice.lang));
  if (chosen) {
    utterance.voice = chosen;
    utterance.lang = chosen.lang;
  }
  utterance.onstart = () => callbacks.onStart?.();
  utterance.onend = () => callbacks.onEnd?.();
  utterance.onerror = () => callbacks.onError?.();
  synth.speak(utterance);
  return true;
}

export function stopSpeaking(): void {
  if (hasSynthesis()) window.speechSynthesis.cancel();
}

type RecognitionAlternative = { transcript: string; confidence: number };
type RecognitionResult = { isFinal: boolean; length: number; 0: RecognitionAlternative };
type RecognitionEvent = {
  resultIndex: number;
  results: { length: number; [index: number]: RecognitionResult };
};

type RecognitionInstance = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((event: RecognitionEvent) => void) | null;
  onend: (() => void) | null;
  onerror: ((event: unknown) => void) | null;
};

type RecognitionConstructor = new () => RecognitionInstance;

export function getRecognitionConstructor(): RecognitionConstructor | null {
  if (typeof window === "undefined") return null;
  const scope = window as unknown as {
    SpeechRecognition?: RecognitionConstructor;
    webkitSpeechRecognition?: RecognitionConstructor;
  };
  return scope.SpeechRecognition ?? scope.webkitSpeechRecognition ?? null;
}

export function hasRecognition(): boolean {
  return Boolean(getRecognitionConstructor());
}

export type RecognizerOptions = {
  lang?: string;
  continuous?: boolean;
  onTranscript: (finalText: string, interimText: string) => void;
  onEnd?: () => void;
  onError?: (code: string) => void;
};

export function createRecognizer(options: RecognizerOptions): { start: () => boolean; stop: () => void } | null {
  const Constructor = getRecognitionConstructor();
  if (!Constructor) return null;
  const recognition = new Constructor();
  recognition.lang = options.lang ?? "es-ES";
  recognition.continuous = options.continuous ?? false;
  recognition.interimResults = true;
  let stopped = false;

  recognition.onresult = (event) => {
    let finalText = "";
    let interimText = "";
    for (let index = event.resultIndex; index < event.results.length; index += 1) {
      const result = event.results[index];
      const transcript = result[0]?.transcript ?? "";
      if (result.isFinal) finalText += transcript;
      else interimText += transcript;
    }
    options.onTranscript(finalText.trim(), interimText.trim());
  };
  recognition.onend = () => {
    if (!stopped) {
      options.onEnd?.();
    }
  };
  recognition.onerror = (event) => {
    const code = typeof event === "object" && event && "error" in event ? String((event as { error: unknown }).error) : "unknown";
    options.onError?.(code);
  };

  return {
    start: () => {
      try {
        recognition.start();
        stopped = false;
        return true;
      } catch {
        return false;
      }
    },
    stop: () => {
      stopped = true;
      try {
        recognition.stop();
      } catch {
        recognition.abort();
      }
    },
  };
}
