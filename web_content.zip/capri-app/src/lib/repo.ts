import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { conversations, memories, messages, settings } from "@/db/schema";
import { buildConversationSummary } from "@/lib/engine";
import { dedupeCandidates, normalizeMemory, retrieveMemories } from "@/lib/memory";
import { keywords } from "@/lib/text";
import {
  DEFAULT_SETTINGS,
  mergeSettings,
  type AppState,
  type Attachment,
  type ChatMessage,
  type Conversation,
  type Memory,
  type MemoryKind,
  type Role,
  type Settings,
} from "@/lib/types";

function iso(value: Date | string | null | undefined): string {
  if (!value) return new Date().toISOString();
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function mapConversation(row: typeof conversations.$inferSelect, messageCount = 0): Conversation {
  return {
    id: row.id,
    title: row.title,
    pinned: row.pinned,
    summary: row.summary,
    topics: Array.isArray(row.topics) ? row.topics : [],
    createdAt: iso(row.createdAt),
    updatedAt: iso(row.updatedAt),
    messageCount,
  };
}

function mapMessage(row: typeof messages.$inferSelect): ChatMessage {
  return {
    id: row.id,
    conversationId: row.conversationId,
    role: row.role as Role,
    content: row.content,
    attachments: Array.isArray(row.attachments) ? row.attachments : [],
    memoriesUsed: Array.isArray(row.memoriesUsed) ? row.memoriesUsed : [],
    skill: row.skill,
    emotion: (row.emotion as ChatMessage["emotion"]) ?? "idle",
    createdAt: iso(row.createdAt),
  };
}

function mapMemory(row: typeof memories.$inferSelect): Memory {
  return {
    id: row.id,
    conversationId: row.conversationId,
    kind: row.kind as MemoryKind,
    content: row.content,
    keywords: row.keywords,
    importance: row.importance,
    uses: row.uses,
    createdAt: iso(row.createdAt),
  };
}

export async function getSettings(): Promise<Settings> {
  const rows = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  if (!rows.length) {
    const initial = mergeSettings(DEFAULT_SETTINGS);
    await db.insert(settings).values({ id: 1, data: initial }).onConflictDoNothing();
    return initial;
  }
  return mergeSettings(rows[0].data);
}

export async function saveSettings(partial: Partial<Settings>): Promise<Settings> {
  const current = await getSettings();
  const merged = mergeSettings({ ...current, ...partial });
  await db
    .insert(settings)
    .values({ id: 1, data: merged, updatedAt: new Date() })
    .onConflictDoUpdate({ target: settings.id, set: { data: merged, updatedAt: new Date() } });
  return merged;
}

export async function listConversations(): Promise<Conversation[]> {
  const rows = await db
    .select({
      row: conversations,
      messageCount: sql<number>`(select count(*)::int from ${messages} where ${messages.conversationId} = ${conversations.id})`,
    })
    .from(conversations)
    .orderBy(desc(conversations.pinned), desc(conversations.updatedAt))
    .limit(100);
  return rows.map((entry) => mapConversation(entry.row, Number(entry.messageCount) || 0));
}

export async function getConversation(id: string): Promise<Conversation | null> {
  const rows = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return rows.length ? mapConversation(rows[0]) : null;
}

export async function createConversation(title = "Nuevo chat"): Promise<Conversation> {
  const rows = await db.insert(conversations).values({ title }).returning();
  return mapConversation(rows[0]);
}

export async function updateConversation(
  id: string,
  patch: { title?: string; pinned?: boolean; summary?: string; topics?: string[] },
): Promise<Conversation | null> {
  const rows = await db
    .update(conversations)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(conversations.id, id))
    .returning();
  return rows.length ? mapConversation(rows[0]) : null;
}

export async function deleteConversation(id: string): Promise<void> {
  await db.delete(conversations).where(eq(conversations.id, id));
}

export async function getMessages(conversationId: string, limit = 200): Promise<ChatMessage[]> {
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt)
    .limit(limit);
  return rows.map(mapMessage);
}

export async function insertMessage(input: {
  conversationId: string;
  role: Role;
  content: string;
  attachments?: Attachment[];
  memoriesUsed?: string[];
  skill?: string | null;
  emotion?: string | null;
}): Promise<ChatMessage> {
  const rows = await db
    .insert(messages)
    .values({
      conversationId: input.conversationId,
      role: input.role,
      content: input.content,
      attachments: input.attachments ?? [],
      memoriesUsed: input.memoriesUsed ?? [],
      skill: input.skill ?? null,
      emotion: input.emotion ?? "idle",
    })
    .returning();
  return mapMessage(rows[0]);
}

export async function listMemories(): Promise<Memory[]> {
  const rows = await db
    .select()
    .from(memories)
    .orderBy(desc(memories.importance), desc(memories.createdAt))
    .limit(400);
  return rows.map(mapMemory);
}

export async function insertMemories(
  candidates: { kind: MemoryKind; content: string; importance?: number }[],
  conversationId: string | null,
): Promise<Memory[]> {
  if (!candidates.length) return [];
  const existing = await listMemories();
  const known = new Set(existing.map((memory) => normalizeMemory(memory.content)));
  const fresh = candidates.filter((candidate) => {
    const key = normalizeMemory(candidate.content);
    if (!key || known.has(key)) return false;
    known.add(key);
    return true;
  });
  if (!fresh.length) return [];
  const rows = await db
    .insert(memories)
    .values(
      fresh.map((candidate) => ({
        conversationId,
        kind: candidate.kind,
        content: candidate.content.slice(0, 240),
        keywords: keywords(candidate.content, 8).join(" "),
        importance: Math.min(5, Math.max(1, candidate.importance ?? 2)),
      })),
    )
    .returning();
  return rows.map(mapMemory);
}

export async function deleteMemory(id: string): Promise<void> {
  await db.delete(memories).where(eq(memories.id, id));
}

export async function deleteMemories(ids: string[]): Promise<void> {
  if (!ids.length) return;
  await db.delete(memories).where(inArray(memories.id, ids));
}

export async function touchMemories(ids: string[]): Promise<void> {
  if (!ids.length) return;
  await db
    .update(memories)
    .set({ uses: sql`${memories.uses} + 1`, lastUsedAt: new Date() })
    .where(inArray(memories.id, ids));
}

export async function pickMemoriesFor(query: string, limit = 6): Promise<Memory[]> {
  const all = await listMemories();
  return retrieveMemories(all, query, limit);
}

export async function rememberFromTurn(
  conversationId: string | null,
  candidates: { kind: MemoryKind; content: string; importance: number }[],
  existing: Memory[],
): Promise<Memory[]> {
  return insertMemories(dedupeCandidates(candidates, existing), conversationId);
}

function publicSettings(config: Settings): Settings {
  const mask = (key: string) => (key ? (key.length <= 8 ? "••••" : `${key.slice(0, 4)}••••${key.slice(-4)}`) : "");
  return {
    ...config,
    providers: config.providers.map((provider) => ({ ...provider, apiKey: mask(provider.apiKey) })),
  };
}

export async function loadState(conversationId?: string | null): Promise<AppState> {
  const [storedSettings, conversationList, memoryList] = await Promise.all([
    getSettings(),
    listConversations(),
    listMemories(),
  ]);

  let activeId: string | null = null;
  if (conversationId && conversationList.some((conversation) => conversation.id === conversationId)) {
    activeId = conversationId;
  } else if (conversationList.length) {
    activeId = conversationList[0].id;
  }

  const history = activeId ? await getMessages(activeId) : [];
  const totalMessages = conversationList.reduce((sum, item) => sum + (item.messageCount ?? 0), 0);

  return {
    settings: publicSettings(storedSettings),
    conversations: conversationList,
    activeId,
    messages: history,
    memories: memoryList,
    stats: {
      conversations: conversationList.length,
      messages: totalMessages,
      memories: memoryList.length,
    },
  };
}

export async function lastUserMessage(conversationId: string): Promise<ChatMessage | null> {
  const rows = await db
    .select()
    .from(messages)
    .where(and(eq(messages.conversationId, conversationId), eq(messages.role, "user")))
    .orderBy(desc(messages.createdAt))
    .limit(1);
  return rows.length ? mapMessage(rows[0]) : null;
}

export async function deleteTrailingAssistant(conversationId: string): Promise<void> {
  const rows = await db
    .select()
    .from(messages)
    .where(and(eq(messages.conversationId, conversationId), eq(messages.role, "assistant")))
    .orderBy(desc(messages.createdAt))
    .limit(1);
  if (rows.length) await db.delete(messages).where(eq(messages.id, rows[0].id));
}

export async function refreshConversationMemory(
  conversationId: string,
  history: { role: Role; content: string }[],
  previousSummary: string,
): Promise<Conversation | null> {
  const summary = buildConversationSummary(history, previousSummary);
  const topics = keywords(history.slice(-4).map((entry) => entry.content).join(" "), 6);
  return updateConversation(conversationId, { summary, topics });
}

export async function ensureConversation(id: string | null | undefined, title: string): Promise<Conversation> {
  if (id) {
    const found = await getConversation(id);
    if (found) return found;
  }
  return createConversation(title);
}

export async function updateMessage(
  id: string,
  patch: { content?: string; skill?: string | null; memoriesUsed?: string[]; emotion?: string },
): Promise<void> {
  await db.update(messages).set(patch).where(eq(messages.id, id));
}
