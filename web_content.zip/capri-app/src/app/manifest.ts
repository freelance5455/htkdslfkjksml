import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Capri AI — asistente con personaje",
    short_name: "Capri",
    description:
      "Asistente con memoria, voz, emociones y personaje interactivo. Funciona también instalada en el móvil.",
    start_url: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#080b12",
    theme_color: "#080b12",
    lang: "es",
    icons: [
      { src: "/characters/avatar.png", sizes: "256x256", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    shortcuts: [
      { name: "Modo voz", short_name: "Voz", url: "/mini?mode=voice" },
      { name: "Estudio", short_name: "Estudio", url: "/?studio=1" },
    ],
  };
}
