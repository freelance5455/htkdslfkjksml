import { NextResponse } from "next/server";
import { classifyEmotion, deriveTitle, runEngine } from "@/lib/engine";
import { retrieveMemories } from "@/lib/memory";
import { callCapriOnline } from "@/lib/online";
import { callProvider, isRemote, type GatewayMessage } from "@/lib/providers";
import {
  createConversation,
  deleteMemories,
  deleteTrailingAssistant,
  getConversation,
  getMessages,
  getSettings,
  insertMemories,
  insertMessage,
  listMemories,
  refreshConversationMemory,
  touchMemories,
  updateConversation,
  updateMessage,
} from "@/lib/repo";
import { extractMemoryCandidates } from "@/lib/text";
import { activeProvider, type Attachment, type ChatMessage, type Emotion, type Settings } from "@/lib/types";

export const dynamic = "force-dynamic";

type Body = {
  conversationId?: string | null;
  text?: string;
  attachments?: Attachment[];
  mode?: "send" | "regenerate";
  timezone?: string;
  nowIso?: string;
  providerId?: string;
};

const TONE_GUIDE: Record<Settings["tone"], string> = {
  cercano: "Habla de forma cercana, cálida y clara, de tú.",
  profesional: "Mantén un tono profesional, preciso y bien estructurado.",
  divertido: "Sé ingeniosa y ligera, con algún toque de humor sin restar precisión.",
  directo: "Ve al grano: respuestas breves, accionables y sin relleno.",
  anime: "Habla con energía kawaii, cercana y expresiva, sin perder utilidad.",
};

function buildSystem(settings: Settings, memories: { content: string }[], summary: string): string {
  const blocks = [
    `Te llamas ${settings.assistantName} y eres la asistente personal de esta app (Capri AI).`,
    TONE_GUIDE[settings.tone] ?? TONE_GUIDE.cercano,
    settings.userName ? `La persona usuaria se llama ${settings.userName}.` : "",
    "Responde en el idioma del usuario. Usa Markdown claro: listas, negritas y bloques de código cuando aporte.",
    "Sé concreta y útil; si faltan datos, haz una pregunta breve al final.",
    "Empieza SIEMPRE tu respuesta con una etiqueta de emoción entre corchetes para tu avatar, una sola de: [idle] [happy] [excited] [thinking] [annoyed] [sad] [surprised]. Elige la que corresponda al tono de tu mensaje (si el usuario te insulta o falta al respeto usa [annoyed]; si te cuenta algo triste usa [sad]; si le das una buena noticia usa [excited]). No expliques la etiqueta.",
    summary ? `Resumen de la conversación hasta ahora: ${summary}` : "",
    memories.length
      ? `Memoria a largo plazo del usuario (úsala solo si es relevante):\n${memories
          .map((memory) => `- ${memory.content}`)
          .join("\n")}`
      : "",
    settings.customInstructions ? `Instrucciones personalizadas: ${settings.customInstructions}` : "",
    settings.systemPrompt ? `Contexto extra del usuario: ${settings.systemPrompt}` : "",
  ];
  return blocks.filter(Boolean).join("\n\n");
}

const EMOTION_TAG = /^\s*\[(idle|happy|excited|thinking|annoyed|sad|surprised|listening|singing)\]\s*/i;

function extractEmotion(text: string, fallbackText: string, skill: string): { text: string; emotion: Emotion } {
  const match = text.match(EMOTION_TAG);
  if (match) {
    return { text: text.replace(EMOTION_TAG, ""), emotion: match[1].toLowerCase() as Emotion };
  }
  return { text, emotion: classifyEmotion(fallbackText, skill) };
}

function splitChunks(text: string, speed: Settings["speed"]): string[] {
  if (speed === "instant") return [text];
  const size = speed === "natural" ? 24 : 70;
  const chunks: string[] = [];
  let index = 0;
  while (index < text.length) {
    let end = Math.min(text.length, index + size);
    if (end < text.length) {
      const nextSpace = text.indexOf(" ", end);
      if (nextSpace !== -1 && nextSpace - end < 30) end = nextSpace + 1;
    }
    chunks.push(text.slice(index, end));
    index = end;
  }
  return chunks.length ? chunks : [text];
}

function sanitizeAttachments(input: unknown): Attachment[] {
  if (!Array.isArray(input)) return [];
  return input.slice(0, 4).flatMap((raw) => {
    if (!raw || typeof raw !== "object") return [];
    const item = raw as Partial<Attachment>;
    const name = String(item.name ?? "archivo").slice(0, 120);
    const kind = item.kind === "image" ? "image" : item.kind === "text" ? "text" : "file";
    const size = Math.max(0, Number(item.size) || 0);
    const attachment: Attachment = {
      id: String(item.id ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`),
      name,
      kind,
      mime: String(item.mime ?? "application/octet-stream").slice(0, 120),
      size,
    };
    if (kind === "text" && typeof item.text === "string") attachment.text = item.text.slice(0, 120_000);
    if (kind === "image" && typeof item.dataUrl === "string" && item.dataUrl.length < 2_500_000) {
      attachment.dataUrl = item.dataUrl;
    }
    return [attachment];
  });
}

function attachmentsAsText(attachments: Attachment[]): string {
  return attachments
    .map((attachment) =>
      attachment.kind === "text" && attachment.text
        ? `[Archivo: ${attachment.name}]\n${attachment.text.slice(0, 8000)}`
        : `[Archivo adjunto: ${attachment.name} · ${attachment.kind} · ${Math.round(attachment.size / 1024)} KB]`,
    )
    .join("\n\n");
}

export async function POST(request: Request) {
  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return NextResponse.json({ error: "Cuerpo inválido." }, { status: 400 });
  }

  const mode = body.mode === "regenerate" ? "regenerate" : "send";
  const rawText = String(body.text ?? "").slice(0, 8000);
  const attachments = sanitizeAttachments(body.attachments);

  if (mode === "send" && !rawText.trim() && !attachments.length) {
    return NextResponse.json({ error: "Escribe un mensaje." }, { status: 400 });
  }
  if (mode === "regenerate" && !body.conversationId) {
    return NextResponse.json({ error: "Falta el chat a regenerar." }, { status: 400 });
  }

  try {
    const config = await getSettings();
    const existingConversation = body.conversationId ? await getConversation(body.conversationId) : null;

    if (mode === "regenerate" && existingConversation) {
      await deleteTrailingAssistant(existingConversation.id);
    }

    let history: ChatMessage[] = existingConversation ? await getMessages(existingConversation.id) : [];
    let userMessage: ChatMessage | null = null;
    let text = rawText;
    let attachmentList = attachments;

    if (mode === "regenerate") {
      const lastUserIndex = [...history].reverse().findIndex((message) => message.role === "user");
      if (lastUserIndex === -1) {
        return NextResponse.json({ error: "No hay mensaje que regenerar." }, { status: 400 });
      }
      const index = history.length - 1 - lastUserIndex;
      userMessage = history[index];
      text = userMessage.content;
      attachmentList = userMessage.attachments;
      history = history.slice(0, index);
    }

    const active =
      existingConversation ?? (await createConversation(deriveTitle(text || attachmentList[0]?.name || "Nuevo chat")));
    if (!existingConversation) history = [];

    if (mode === "send") {
      userMessage = await insertMessage({
        conversationId: active.id,
        role: "user",
        content: rawText,
        attachments,
      });
    }

    const allMemories = await listMemories();
    const relevant = config.memoryEnabled ? retrieveMemories(allMemories, text, 6) : [];
    let saved = config.memoryEnabled ? await insertMemories(extractMemoryCandidates(text), active.id) : [];

    const selected =
      (body.providerId ? config.providers.find((provider) => provider.id === body.providerId) : null) ??
      activeProvider(config);
    const isBuiltInOnline = Boolean(selected && selected.kind === "online" && selected.enabled);
    const useRemote = Boolean(selected && selected.enabled && isRemote(selected) && (selected.apiKey || isBuiltInOnline));
    const memoriesUsed = relevant.slice(0, 4).map((memory) => memory.content);

    const localEngine =
      !useRemote
        ? runEngine({
            text,
            history: history.map((message) => ({ role: message.role, content: message.content })),
            memories: allMemories,
            relevant,
            saved,
            summary: active.summary,
            settings: config,
            attachments: attachmentList,
            timezone: body.timezone,
            nowIso: body.nowIso,
          })
        : null;

    if (localEngine && config.memoryEnabled && localEngine.remember.length) {
      saved = [...saved, ...(await insertMemories(localEngine.remember, active.id))];
    }
    if (localEngine && localEngine.forgetIds.length) {
      await deleteMemories(localEngine.forgetIds);
    }
    if (relevant.length) void touchMemories(relevant.map((memory) => memory.id)).catch(() => undefined);

    const assistantMessage = await insertMessage({
      conversationId: active.id,
      role: "assistant",
      content: localEngine?.text ?? "",
      memoriesUsed,
      skill: localEngine?.skill ?? "ia",
      emotion: localEngine?.emotion ?? "idle",
    });

    const needsTitle = active.title === "Nuevo chat" && Boolean(text.trim() || attachmentList.length);
    if (needsTitle) {
      await updateConversation(active.id, { title: deriveTitle(text || attachmentList[0]?.name || "Nuevo chat") });
    }

    const gatewayMessages: GatewayMessage[] = [
      { role: "system", content: buildSystem(config, relevant, active.summary) },
      ...history.slice(-Math.max(4, config.maxContextMessages)).map((message) => ({
        role: message.role as "user" | "assistant",
        content: message.content.slice(0, 4000),
      })),
      {
        role: "user" as const,
        content: [text, attachmentsAsText(attachmentList)].filter(Boolean).join("\n\n"),
      },
    ];

    const encoder = new TextEncoder();
    const delay = config.speed === "instant" || config.lowDataMode ? 0 : config.speed === "natural" ? 24 : 10;

    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        let closed = false;
        const send = (payload: unknown) => {
          if (closed) return;
          try {
            controller.enqueue(encoder.encode(`${JSON.stringify(payload)}\n`));
          } catch {
            closed = true;
          }
        };

        send({
          type: "meta",
          conversation: { ...active, messageCount: history.length + 2 },
          userMessage,
          assistantMessage: { ...assistantMessage, content: localEngine?.text ?? "", pending: true },
          newMemories: saved,
          deletedMemoryIds: localEngine?.forgetIds ?? [],
          memoriesUsed,
          skill: localEngine?.skill ?? "ia",
          emotion: localEngine?.emotion ?? "idle",
          provider: useRemote ? selected?.name : "Capri local",
          online: isBuiltInOnline,
        });

        let finalText = "";
        let providerNote = "";
        let providerError = "";

        if (useRemote && selected) {
          if (selected.kind === "online") {
            const online = await callCapriOnline(gatewayMessages, {
              temperature: selected.temperature,
              maxTokens: selected.maxTokens,
              model: selected.model,
              onDelta: (delta) => {
                finalText += delta;
                send({ type: "delta", value: delta });
              },
            });
            if (online.error) providerError = online.error;
            else if (!online.text) providerError = "El motor online devolvió una respuesta vacía.";
            else if (!finalText) {
              finalText = online.text;
              send({ type: "delta", value: online.text });
            }
          } else {
            const result = await callProvider(selected, gatewayMessages, (delta) => {
              finalText += delta;
              send({ type: "delta", value: delta });
            });
            if (result.error) {
              providerError = result.error;
            } else if (!result.text) {
              providerError = "El proveedor devolvió una respuesta vacía.";
            } else if (!finalText) {
              finalText = result.text;
              send({ type: "delta", value: result.text });
            }
          }
        }

        if (!finalText) {
          const fallback = localEngine ?? runEngine({
            text,
            history: history.map((message) => ({ role: message.role, content: message.content })),
            memories: allMemories,
            relevant,
            saved,
            summary: active.summary,
            settings: config,
            attachments: attachmentList,
            timezone: body.timezone,
            nowIso: body.nowIso,
          });
          finalText = fallback.text;
          if (providerError) {
            providerNote = `\n\n> ⚠️ **${selected?.name ?? "Tu API"}** no respondió (${providerError.slice(
              0,
              180,
            )}). Respondí con el motor local de Capri. Revisa URL, modelo y clave en Ajustes → Proveedores.`;
            finalText += providerNote;
          }
          for (const chunk of splitChunks(finalText, config.speed)) {
            send({ type: "delta", value: chunk });
            if (delay) await new Promise((resolve) => setTimeout(resolve, delay));
          }
        }

        let emotion: Emotion = localEngine?.emotion ?? "idle";
        if (finalText) {
          const parsed = extractEmotion(finalText, text, localEngine?.skill ?? "general");
          finalText = parsed.text;
          emotion = parsed.emotion;
        }

        await updateMessage(assistantMessage.id, { content: finalText, emotion });
        const refreshed =
          (await refreshConversationMemory(
            active.id,
            [
              ...history.map((message) => ({ role: message.role, content: message.content })),
              { role: "user" as const, content: text },
              { role: "assistant" as const, content: finalText },
            ],
            active.summary,
          )) ?? active;

        send({
          type: "done",
          conversation: { ...refreshed, messageCount: history.length + 2 },
          assistantId: assistantMessage.id,
          content: finalText,
          emotion,
          provider: useRemote && !providerError ? selected?.name : "Capri local",
          providerError: providerError || null,
        });
        closed = true;
        controller.close();
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "application/x-ndjson; charset=utf-8",
        "Cache-Control": "no-store, no-transform",
        "X-Accel-Buffering": "no",
      },
    });
  } catch (error) {
    console.error("chat error", error);
    return NextResponse.json(
      { error: "Algo falló al pensar la respuesta. Revisa la conexión e inténtalo de nuevo." },
      { status: 500 },
    );
  }
}
