import { NextResponse } from "next/server";
import { callCapriOnline } from "@/lib/online";

export const dynamic = "force-dynamic";

export async function GET() {
  const started = Date.now();
  const result = await callCapriOnline(
    [
      { role: "system", content: "Responde en una sola frase breve." },
      { role: "user", content: "Confirma que estás en línea." },
    ],
    { maxTokens: 60, temperature: 0.4 },
  );
  return NextResponse.json({
    ok: !result.error,
    model: result.model,
    latencyMs: Date.now() - started,
    reply: result.text || null,
    error: result.error ?? null,
  });
}
