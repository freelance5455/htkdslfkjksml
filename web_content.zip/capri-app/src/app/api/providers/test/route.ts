import { NextResponse } from "next/server";
import { getSettings } from "@/lib/repo";
import { callProvider, isRemote, type GatewayMessage } from "@/lib/providers";
import { maskKey, type AiProvider } from "@/lib/types";

export const dynamic = "force-dynamic";

type Body = {
  providerId?: string;
  draft?: AiProvider;
  messages?: GatewayMessage[];
  model?: string;
  temperature?: number;
  maxTokens?: number;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Body;
    const settings = await getSettings();
    const stored = body.providerId
      ? settings.providers.find((item) => item.id === body.providerId)
      : settings.providers.find((item) => item.id === settings.preferredProvider);
    const draft = body.draft;
    const provider: AiProvider | undefined = draft
      ? {
          ...draft,
          apiKey: draft.apiKey && !draft.apiKey.includes("••••") ? draft.apiKey : stored?.apiKey ?? "",
        }
      : stored;

    if (!provider || !isRemote(provider)) {
      return NextResponse.json(
        { error: "Selecciona un proveedor remoto con URL base antes de probar." },
        { status: 400 },
      );
    }

    const messages = (body.messages ?? []).slice(-20);
    if (!messages.length) {
      return NextResponse.json({ error: "Añade al menos un mensaje." }, { status: 400 });
    }

    const started = Date.now();
    const result = await callProvider(
      {
        ...provider,
        model: body.model?.trim() || provider.model,
        temperature: body.temperature ?? provider.temperature,
        maxTokens: body.maxTokens ?? provider.maxTokens,
      },
      messages,
    );

    if (result.error) {
      return NextResponse.json(
        {
          ok: false,
          provider: provider.name,
          key: maskKey(provider.apiKey),
          error: result.error,
          hint:
            "Comprueba la URL base (debe terminar en /v1 en la mayoría de APIs), el nombre del modelo y que la clave sea válida.",
        },
        { status: 502 },
      );
    }

    return NextResponse.json({
      ok: true,
      provider: provider.name,
      model: body.model || provider.model,
      latencyMs: Date.now() - started,
      reply: result.text,
    });
  } catch (error) {
    console.error("providers test", error);
    return NextResponse.json({ error: "No pude probar el proveedor." }, { status: 500 });
  }
}
