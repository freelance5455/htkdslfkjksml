import { NextResponse } from "next/server";
import { getSettings } from "@/lib/repo";
import type { AiProvider } from "@/lib/types";

export const dynamic = "force-dynamic";

type Body = { draft?: AiProvider; providerId?: string };

async function fetchOpenAiModels(baseUrl: string, apiKey: string): Promise<string[]> {
  const response = await fetch(`${baseUrl.replace(/\/+$/, "")}/models`, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = (await response.json()) as { data?: { id?: string }[] };
  return (data.data ?? []).map((model) => model.id ?? "").filter(Boolean).sort();
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Body;
    const settings = await getSettings();
    const stored = body.providerId ? settings.providers.find((item) => item.id === body.providerId) : undefined;
    const provider = body.draft
      ? {
          ...body.draft,
          apiKey:
            body.draft.apiKey && !body.draft.apiKey.includes("••••")
              ? body.draft.apiKey
              : stored?.apiKey ?? "",
        }
      : stored;

    if (!provider) return NextResponse.json({ models: [], error: "Proveedor no encontrado." }, { status: 404 });
    if (provider.kind === "local") return NextResponse.json({ models: [], error: "El motor local no expone modelos." });
    if (!provider.apiKey) return NextResponse.json({ models: [], error: "Añade una API key para listar los modelos." });

    if (provider.kind === "anthropic") {
      const response = await fetch(`${provider.baseUrl.replace(/\/+$/, "")}/models`, {
        headers: { "x-api-key": provider.apiKey, "anthropic-version": "2023-06-01" },
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = (await response.json()) as { data?: { id?: string }[] };
      return NextResponse.json({ models: (data.data ?? []).map((model) => model.id ?? "").filter(Boolean).sort() });
    }

    if (provider.kind === "gemini") {
      const base = provider.baseUrl.replace(/\/+$/, "");
      const response = await fetch(`${base}/models?key=${encodeURIComponent(provider.apiKey)}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = (await response.json()) as { models?: { name?: string; supportedGenerationMethods?: string[] }[] };
      const models = (data.models ?? [])
        .filter((model) => !model.supportedGenerationMethods || model.supportedGenerationMethods.includes("generateContent"))
        .map((model) => (model.name ?? "").replace(/^models\//, ""))
        .filter(Boolean)
        .sort();
      return NextResponse.json({ models });
    }

    return NextResponse.json({ models: await fetchOpenAiModels(provider.baseUrl, provider.apiKey) });
  } catch (error) {
    return NextResponse.json({
      models: [],
      error: `No pude listar modelos: ${error instanceof Error ? error.message : "error desconocido"}. Puedes escribir el nombre a mano.`,
    });
  }
}
