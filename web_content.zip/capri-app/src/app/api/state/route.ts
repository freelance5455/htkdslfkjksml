import { NextResponse } from "next/server";
import { loadState } from "@/lib/repo";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const conversationId = url.searchParams.get("conversationId");
    const state = await loadState(conversationId);
    return NextResponse.json(state, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("state error", error);
    return NextResponse.json({ error: "No pude cargar el estado." }, { status: 500 });
  }
}
