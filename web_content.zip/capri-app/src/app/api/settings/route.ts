import { NextResponse } from "next/server";
import { getSettings, saveSettings } from "@/lib/repo";
import { maskKey, type Settings } from "@/lib/types";

export const dynamic = "force-dynamic";

function maskSettings(settings: Settings): Settings {
  return {
    ...settings,
    providers: settings.providers.map((provider) => ({ ...provider, apiKey: maskKey(provider.apiKey) })),
  };
}

export async function GET() {
  try {
    return NextResponse.json(maskSettings(await getSettings()), {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("settings get", error);
    return NextResponse.json({ error: "No pude leer los ajustes." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as Partial<Settings>;
    const current = await getSettings();
    if (Array.isArray(body.providers)) {
      body.providers = body.providers.map((provider) => {
        if (!provider.apiKey || provider.apiKey.includes("••••")) {
          const stored = current.providers.find((item) => item.id === provider.id);
          return { ...provider, apiKey: stored?.apiKey ?? "" };
        }
        return provider;
      });
    }
    const saved = await saveSettings(body);
    return NextResponse.json(maskSettings(saved));
  } catch (error) {
    console.error("settings patch", error);
    return NextResponse.json({ error: "No pude guardar los ajustes." }, { status: 500 });
  }
}
