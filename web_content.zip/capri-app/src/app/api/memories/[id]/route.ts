import { NextResponse } from "next/server";
import { deleteMemory } from "@/lib/repo";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function DELETE(_request: Request, { params }: Params) {
  try {
    const { id } = await params;
    await deleteMemory(id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("memory delete", error);
    return NextResponse.json({ error: "No pude borrar el recuerdo." }, { status: 500 });
  }
}
