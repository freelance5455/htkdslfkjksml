import { NextResponse } from "next/server";
import { deleteMemories, insertMemories, listMemories } from "@/lib/repo";
import type { MemoryKind } from "@/lib/types";

export const dynamic = "force-dynamic";

const KINDS: MemoryKind[] = ["perfil", "preferencia", "gusto", "tarea", "dato"];

export async function GET() {
  try {
    return NextResponse.json(await listMemories(), { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("memories list", error);
    return NextResponse.json({ error: "No pude cargar la memoria." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { content?: string; kind?: MemoryKind };
    const content = (body.content ?? "").trim();
    if (content.length < 3) {
      return NextResponse.json({ error: "Escribe un recuerdo más largo." }, { status: 400 });
    }
    const kind = body.kind && KINDS.includes(body.kind) ? body.kind : "dato";
    const created = await insertMemories([{ kind, content: content.slice(0, 240), importance: 4 }], null);
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("memory create", error);
    return NextResponse.json({ error: "No pude guardar el recuerdo." }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    const all = await listMemories();
    await deleteMemories(all.map((memory) => memory.id));
    return NextResponse.json({ ok: true, deleted: all.length });
  } catch (error) {
    console.error("memories clear", error);
    return NextResponse.json({ error: "No pude vaciar la memoria." }, { status: 500 });
  }
}
