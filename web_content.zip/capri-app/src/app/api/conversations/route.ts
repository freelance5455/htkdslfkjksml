import { NextResponse } from "next/server";
import { createConversation, listConversations } from "@/lib/repo";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json(await listConversations(), { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("conversations list", error);
    return NextResponse.json({ error: "No pude cargar los chats." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as { title?: string };
    const conversation = await createConversation(body.title?.slice(0, 80) || "Nuevo chat");
    return NextResponse.json(conversation, { status: 201 });
  } catch (error) {
    console.error("conversation create", error);
    return NextResponse.json({ error: "No pude crear el chat." }, { status: 500 });
  }
}
