import { NextResponse } from "next/server";
import { deleteConversation, getMessages, updateConversation } from "@/lib/repo";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Params) {
  try {
    const { id } = await params;
    const rows = await getMessages(id);
    return NextResponse.json(rows, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("conversation messages", error);
    return NextResponse.json({ error: "No pude cargar los mensajes." }, { status: 500 });
  }
}

export async function PATCH(request: Request, { params }: Params) {
  try {
    const { id } = await params;
    const body = (await request.json()) as { title?: string; pinned?: boolean };
    const patch: { title?: string; pinned?: boolean } = {};
    if (typeof body.title === "string") patch.title = body.title.trim().slice(0, 80) || "Nuevo chat";
    if (typeof body.pinned === "boolean") patch.pinned = body.pinned;
    const updated = await updateConversation(id, patch);
    if (!updated) return NextResponse.json({ error: "Chat no encontrado." }, { status: 404 });
    return NextResponse.json(updated);
  } catch (error) {
    console.error("conversation patch", error);
    return NextResponse.json({ error: "No pude actualizar el chat." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: Params) {
  try {
    const { id } = await params;
    await deleteConversation(id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("conversation delete", error);
    return NextResponse.json({ error: "No pude borrar el chat." }, { status: 500 });
  }
}
