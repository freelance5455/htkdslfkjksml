import CapriApp from "@/components/CapriApp";
import { loadState } from "@/lib/repo";
import type { AppState } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function Page() {
  let initialState: AppState | null = null;
  let bootError = false;
  try {
    initialState = await loadState();
  } catch (error) {
    console.error("No pude precargar el estado de Capri:", error);
    bootError = true;
  }

  return <CapriApp initialState={initialState} bootError={bootError} />;
}
