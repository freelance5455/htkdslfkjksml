"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CharacterAvatar } from "@/components/CharacterAvatar";
import { Icon } from "@/components/icons";
import { plainForSpeech } from "@/components/Markdown";
import { createRecognizer, hasRecognition, hasSynthesis, speak, stopSpeaking } from "@/lib/speech";
import { DEFAULT_SETTINGS, mergeSettings, expressionImage, type AppState, type ChatMessage, type Emotion, type Settings } from "@/lib/types";

type Item = { id: string; role: "user" | "assistant"; text: string; emotion: Emotion };

export default function MiniAssistantPage() {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [voiceOnly, setVoiceOnly] = useState(true);
  const [textMode, setTextMode] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const recognizer = useRef<{ start: () => boolean; stop: () => void } | null>(null);
  const accumulated = useRef("");
  const settingsRef = useRef(settings);

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get("mode") === "voice") setVoiceOnly(true);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    settingsRef.current = settings;
    try {
      const look = window.localStorage.getItem("capri-look");
      if (look) {
        const parsed = JSON.parse(look) as Record<string, string>;
        const root = document.documentElement;
        if (parsed.theme) root.dataset.theme = parsed.theme;
        if (parsed.accent) root.style.setProperty("--accent", parsed.accent);
        if (parsed.fontScale) root.style.setProperty("--font-scale", String(parsed.fontScale));
      }
    } catch {
      // ignore
    }
  }, [settings]);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const response = await fetch("/api/state", { cache: "no-store" });
        if (!response.ok) throw new Error();
        const state = (await response.json()) as AppState;
        if (cancelled) return;
        setSettings(mergeSettings(state.settings));
        const last = state.messages.slice(-6).map((message) => ({
          id: message.id,
          role: message.role,
          text: message.content,
          emotion: (message.emotion ?? "idle") as Emotion,
        }));
        setItems(last);
        setConversationId(state.activeId);
        if (state.settings.liveVoice) setVoiceOnly(true);
      } catch {
        if (!cancelled) setError("No pude cargar los ajustes. Escribe igualmente: usaré el motor local.");
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [items, busy]);

  const send = useCallback(
    async (raw?: string) => {
      const text = (raw ?? input).trim();
      if (!text || busy) return;
      setBusy(true);
      setError(null);
      setInput("");
      accumulated.current = "";
      const tempId = `u-${Date.now()}`;
      setItems((current) => [...current, { id: tempId, role: "user", text, emotion: "listening" }]);

      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            conversationId,
            text,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            nowIso: new Date().toISOString(),
            providerId: settingsRef.current.preferredProvider,
          }),
        });
        if (!response.ok || !response.body) throw new Error("No pude responder.");
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let assistantId: string | null = null;

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let newline = buffer.indexOf("\n");
          while (newline >= 0) {
            const line = buffer.slice(0, newline).trim();
            buffer = buffer.slice(newline + 1);
            newline = buffer.indexOf("\n");
            if (!line) continue;
            let event: Record<string, unknown>;
            try {
              event = JSON.parse(line) as Record<string, unknown>;
            } catch {
              continue;
            }
            if (event.type === "meta") {
              const assistant = event.assistantMessage as ChatMessage;
              assistantId = assistant.id;
              setConversationId((event.conversation as { id: string }).id);
              setItems((current) => [
                ...current,
                { id: assistant.id, role: "assistant", text: "", emotion: (assistant.emotion ?? "thinking") as Emotion },
              ]);
            } else if (event.type === "delta") {
              accumulated.current += String(event.value ?? "");
              const snapshot = accumulated.current;
              setItems((current) =>
                current.map((item) =>
                  item.id === (assistantId ?? "") ? { ...item, text: snapshot.replace(/^\s*\[[a-z]+\]\s*/i, ""), emotion: "speaking" } : item,
                ),
              );
            } else if (event.type === "done") {
              const content = String(event.content ?? accumulated.current).replace(/^\s*\[[a-z]+\]\s*/i, "");
              const emotion = (event.emotion as Emotion) ?? "happy";
              setItems((current) =>
                current.map((item) => (item.id === (assistantId ?? "") ? { ...item, text: content, emotion } : item)),
              );
              if (hasSynthesis() && content) {
                setSpeaking(true);
                speak(plainForSpeech(content).slice(0, 900), {
                  rate: settingsRef.current.rate,
                  pitch: settingsRef.current.pitch,
                  volume: settingsRef.current.volume,
                  voiceURI: settingsRef.current.voiceURI,
                  lang: settingsRef.current.listenLang,
                  onEnd: () => setSpeaking(false),
                  onError: () => setSpeaking(false),
                });
              }
            }
          }
        }
      } catch {
        setError("No pude responder. Revisa la conexión e inténtalo otra vez.");
      } finally {
        setBusy(false);
      }
    },
    [busy, conversationId, input],
  );

  const toggleListen = useCallback(() => {
    if (listening) {
      recognizer.current?.stop();
      setListening(false);
      return;
    }
    if (!hasRecognition()) {
      setError("Este navegador no permite dictado aquí. Escribe el mensaje.");
      return;
    }
    stopSpeaking();
    setSpeaking(false);
    let draft = "";
    const instance = createRecognizer({
      lang: settingsRef.current.listenLang,
      onTranscript: (finalText, interimText) => {
        if (interimText) setInput(interimText);
        if (finalText) {
          draft = `${draft} ${finalText}`.trim();
          setInput(draft);
        }
      },
      onEnd: () => {
        setListening(false);
        const value = draft.trim();
        if (value && settingsRef.current.autoSendVoice) void send(value);
      },
      onError: () => {
        setListening(false);
        setError("No pude usar el micrófono. Revisa los permisos.");
      },
    });
    recognizer.current = instance;
    if (instance?.start()) {
      setListening(true);
      setInput("");
    } else {
      setError("No pude activar el micrófono.");
    }
  }, [listening, send]);

  const lastEmotion = [...items].reverse().find((item) => item.role === "assistant")?.emotion ?? "idle";
  const mood: Emotion = speaking ? "speaking" : listening ? "listening" : busy ? "thinking" : lastEmotion;

  return (
    <div className="mini-root">
      <header className="mini-head">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[0.8rem] font-semibold">{settings.assistantName}</p>
          <p className="text-[0.6rem] text-[var(--muted)]">
            {busy ? "pensando…" : listening ? "escuchando" : speaking ? "hablando" : error ? "sin conexión" : "en línea"}
          </p>
        </div>
        <button type="button" className={`tool-btn ${textMode ? "on" : ""}`} onClick={() => setTextMode((value) => !value)} aria-label="Alternar teclado">
          <Icon name="pencil" size={15} />
        </button>
        <button type="button" className="icon-btn" onClick={() => window.close()} aria-label="Cerrar ventana">
          <Icon name="close" size={16} />
        </button>
      </header>

      <div className="mini-stage" style={{ minHeight: 150 }}>
        <button
          type="button"
          onClick={toggleListen}
          className="character-btn"
          aria-label={listening ? "Detener micrófono" : "Hablar con Capri"}
        >
          <CharacterAvatar character={settings.character} customImage={expressionImage(settings, mood)} imageOverride={expressionImage(settings, mood)} size={settings.characterSize > 1 ? 132 : 112} mood={mood} still={settings.reduceMotion} />
        </button>
      </div>

      <div className="mini-caption">
        {listening ? "Te escucho…" : speaking ? "Hablando…" : error ?? "Toca a Capri para hablar"}
      </div>

      <div className="mini-scroll" ref={scrollRef}>
        {!items.length && ready && (
          <p className="mini-empty">
            Soy {settings.assistantName}. Tócame y háblame: funciona sobre otras ventanas y uso tu memoria y tus ajustes.
          </p>
        )}
        {items.slice(-8).map((item) => (
          <div key={item.id} className={`mini-bubble ${item.role}`}>
            {item.text || (
              <span className="typing-dots">
                <span />
                <span style={{ animationDelay: "0.15s" }} />
                <span style={{ animationDelay: "0.3s" }} />
              </span>
            )}
          </div>
        ))}
        {error && <p className="mini-error">{error}</p>}
      </div>

      <div className="mini-actions">
        <button type="button" className={`voice-round ${listening ? "danger" : "primary"}`} onClick={toggleListen} aria-label="Micrófono">
          <Icon name={listening ? "stop" : "mic"} size={22} />
        </button>
        <button
          type="button"
          className={`voice-round ${speaking ? "primary" : ""}`}
          onClick={() => {
            stopSpeaking();
            setSpeaking(false);
          }}
          aria-label="Detener voz"
        >
          <Icon name="volumeOff" size={20} />
        </button>
      </div>

      {(textMode || !voiceOnly) && (
        <div className="mini-composer">
          <input
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                void send();
              }
            }}
            placeholder={`Escribe a ${settings.assistantName}…`}
            aria-label="Mensaje"
          />
          <button type="button" className="send-btn" onClick={() => void send()} disabled={busy || !input.trim()} aria-label="Enviar">
            <Icon name={busy ? "stop" : "send"} size={16} />
          </button>
        </div>
      )}
      <p className="mini-hint">Modo asistente · mantener la pestaña principal abierta permite la ventana flotante.</p>
    </div>
  );
}
