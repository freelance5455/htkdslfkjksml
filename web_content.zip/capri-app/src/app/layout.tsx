import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Capri AI — Chat con personaje, memoria y voz",
  description:
    "Capri AI: chat rápido con personaje chibi animado, memoria persistente, voz real, archivos y cualquier API de IA que quieras conectar.",
  applicationName: "Capri AI",
};

export const viewport: Viewport = {
  themeColor: "#080b12",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

const LOOK_BOOTSTRAP = `(function(){try{var raw=localStorage.getItem('capri-look');if(!raw)return;var s=JSON.parse(raw);var r=document.documentElement;if(s.theme)r.dataset.theme=s.theme;if(s.font)r.dataset.font=s.font;if(s.bubbles)r.dataset.bubbles=s.bubbles;if(s.accent)r.style.setProperty('--accent',s.accent);if(s.fontScale)r.style.setProperty('--font-scale',String(s.fontScale));if(s.radius)r.style.setProperty('--radius',s.radius+'px');if(s.highContrast)r.dataset.highContrast='true';if(s.reduceMotion)r.dataset.reduceMotion='true';}catch(e){}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es" data-theme="midnight" data-font="system" data-bubbles="modern" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: LOOK_BOOTSTRAP }} />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
