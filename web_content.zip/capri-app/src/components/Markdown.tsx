"use client";

import type { ReactNode } from "react";

function inline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const pattern = /(\*\*[^*]+\*\*|`[^`]+`|_[^_]+_|\*[^*]+\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let index = 0;
  while ((match = pattern.exec(text))) {
    if (match.index > lastIndex) nodes.push(text.slice(lastIndex, match.index));
    const token = match[0];
    const key = `${keyPrefix}-${index}`;
    if (token.startsWith("**")) nodes.push(<strong key={key}>{token.slice(2, -2)}</strong>);
    else if (token.startsWith("`")) nodes.push(<code key={key}>{token.slice(1, -1)}</code>);
    else if (token.startsWith("_")) nodes.push(<em key={key}>{token.slice(1, -1)}</em>);
    else nodes.push(<em key={key}>{token.slice(1, -1)}</em>);
    lastIndex = match.index + token.length;
    index += 1;
  }
  if (lastIndex < text.length) nodes.push(text.slice(lastIndex));
  return nodes;
}

export function Markdown({ text }: { text: string }) {
  const lines = text.replace(/\r/g, "").split("\n");
  const blocks: ReactNode[] = [];
  let listItems: string[] = [];
  let listType: "ul" | "ol" | null = null;
  let codeLines: string[] = [];
  let inCode = false;

  const flushList = (key: string) => {
    if (!listItems.length || !listType) return;
    const items = listItems.map((item, index) => <li key={`${key}-li-${index}`}>{inline(item, `${key}-li-${index}`)}</li>);
    blocks.push(listType === "ul" ? <ul key={`${key}-ul`}>{items}</ul> : <ol key={`${key}-ol`}>{items}</ol>);
    listItems = [];
    listType = null;
  };

  lines.forEach((line, lineIndex) => {
    const key = `l${lineIndex}`;
    if (line.trim().startsWith("```")) {
      if (inCode) {
        blocks.push(
          <pre key={`${key}-pre`}>
            <code>{codeLines.join("\n")}</code>
          </pre>,
        );
        codeLines = [];
        inCode = false;
      } else {
        flushList(key);
        inCode = true;
      }
      return;
    }
    if (inCode) {
      codeLines.push(line);
      return;
    }
    if (!line.trim()) {
      flushList(key);
      return;
    }
    const bullet = line.match(/^\s*[-•*]\s+(.*)$/);
    const numbered = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (bullet) {
      if (listType !== "ul") flushList(key);
      listType = "ul";
      listItems.push(bullet[1]);
      return;
    }
    if (numbered) {
      if (listType !== "ol") flushList(key);
      listType = "ol";
      listItems.push(numbered[1]);
      return;
    }
    flushList(key);
    if (line.startsWith("### ")) {
      blocks.push(<h3 key={key}>{inline(line.slice(4), key)}</h3>);
      return;
    }
    if (line.startsWith("## ")) {
      blocks.push(<h2 key={key}>{inline(line.slice(3), key)}</h2>);
      return;
    }
    if (line.startsWith("> ")) {
      blocks.push(<blockquote key={key}>{inline(line.slice(2), key)}</blockquote>);
      return;
    }
    blocks.push(<p key={key}>{inline(line, key)}</p>);
  });

  flushList("final");
  if (inCode && codeLines.length) {
    blocks.push(
      <pre key="final-pre">
        <code>{codeLines.join("\n")}</code>
      </pre>,
    );
  }

  return <div className="capri-markdown">{blocks}</div>;
}

export function plainForSpeech(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " bloque de código omitido. ")
    .replace(/[#>*_`]/g, " ")
    .replace(/^\s*\d+[.)]\s+/gm, "")
    .replace(/\[(.*?)\]\(.*?\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 1400);
}
