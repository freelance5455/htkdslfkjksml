"use client";

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { CharacterAvatar, type Mood } from "@/components/CharacterAvatar";
import { Icon, type IconName } from "@/components/icons";
import { relativeTime } from "@/lib/text";
import {
  ACCENTS,
  CHARACTER_STYLES,
  EMOTIONS,
  LISTEN_LANGS,
  PROVIDER_PRESETS,
  THEMES,
  VOICE_PRESETS,
  type BubbleStyle,
  type CharacterStyle,
  type Conversation,
  type Emotion,
  type FontChoice,
  type Memory,
  type ProviderKind,
  type Settings,
  type Speed,
  type ThemeId,
  type Tone,
} from "@/lib/types";

export type ToastState = { text: string; kind: "ok" | "error" | "info" } | null;

export function Toast({ toast }: { toast: ToastState }) {
  if (!toast) return null;
  return (
    <div className={`toast ${toast.kind}`} role="status">
      <Icon name={toast.kind === "error" ? "close" : toast.kind === "ok" ? "check" : "sparkles"} size={15} />
      <span>{toast.text}</span>
    </div>
  );
}

function Overlay({ onClose }: { onClose: () => void }) {
  return <div className="overlay" onClick={onClose} aria-hidden="true" />;
}

function useEscape(onClose: () => void, active: boolean) {
  useEffect(() => {
    if (!active) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [active, onClose]);
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`switch ${checked ? "on" : ""}`} onClick={onChange} />
  );
}

function Row({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <div className="row">
      <div className="min-w-0">
        <p className="row-title">{title}</p>
        {description && <p className="row-desc">{description}</p>}
      </div>
      <div className="flex-none pt-0.5">{children}</div>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
  format?: (value: number) => string;
}) {
  return (
    <div className="py-2">
      <div className="flex items-center justify-between">
        <span className="row-title">{label}</span>
        <span className="tag">{format ? format(value) : value.toFixed(2)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} aria-label={label} className="mt-1.5" />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Sidebar                                                            */
/* ------------------------------------------------------------------ */

export function Sidebar({
  open,
  onClose,
  conversations,
  activeId,
  memoryCount,
  settings,
  onSelect,
  onNew,
  onRename,
  onDelete,
  onPin,
  onOpenSettings,
  onOpenMemory,
  onOpenStudio,
  onOpenPerformance,
  onOpenVoice,
  onExport,
}: {
  open: boolean;
  onClose: () => void;
  conversations: Conversation[];
  activeId: string | null;
  memoryCount: number;
  settings: Settings;
  onSelect: (id: string) => void;
  onNew: () => void;
  onRename: (id: string, title: string) => void;
  onDelete: (id: string) => void;
  onPin: (id: string) => void;
  onOpenSettings: () => void;
  onOpenMemory: () => void;
  onOpenStudio: () => void;
  onOpenPerformance: () => void;
  onOpenVoice: () => void;
  onExport: () => void;
}) {
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<{ id: string; title: string } | null>(null);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return conversations;
    return conversations.filter(
      (conversation) =>
        conversation.title.toLowerCase().includes(needle) ||
        conversation.summary.toLowerCase().includes(needle) ||
        conversation.topics.some((topic) => topic.includes(needle)),
    );
  }, [conversations, query]);

  return (
    <>
      {open && <div className="overlay overlay-mobile" onClick={onClose} aria-hidden="true" />}
      <aside className={`sidebar ${open ? "open" : ""}`} aria-label="Barra lateral">
        <div className="brand">
          <div className="brand-logo">
            <CharacterAvatar character={settings.character} customImage={settings.customCharacter} size={26} mood="happy" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[0.9rem] font-semibold leading-tight">{settings.assistantName} AI</p>
            <p className="text-[0.66rem] text-[var(--muted)]">Chat con memoria y voz</p>
          </div>
          <button type="button" className="icon-btn mobile-only" onClick={onClose} aria-label="Cerrar menú">
            <Icon name="close" size={17} />
          </button>
        </div>

        <button type="button" className="new-chat" onClick={onNew}>
          <Icon name="plus" size={16} />
          Nuevo chat
        </button>

        <div className="search-box mt-1">
          <Icon name="search" size={14} className="text-[var(--muted)]" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar chats…" aria-label="Buscar chats" />
        </div>

        <div className="sidebar-scroll">
          <p className="sidebar-label">{query ? `Resultados · ${filtered.length}` : "Recientes"}</p>
          {filtered.map((conversation) => (
            <div key={conversation.id} className={`conv ${conversation.id === activeId ? "active" : ""}`}>
              {editing?.id === conversation.id ? (
                <form
                  className="flex flex-1 items-center gap-1 p-1"
                  onSubmit={(event) => {
                    event.preventDefault();
                    onRename(conversation.id, editing.title);
                    setEditing(null);
                  }}
                >
                  <input autoFocus value={editing.title} onChange={(event) => setEditing({ id: conversation.id, title: event.target.value })} className="field py-1 text-[0.78rem]" aria-label="Nuevo título" />
                  <button type="submit" className="mini-icon" aria-label="Guardar">
                    <Icon name="check" size={14} />
                  </button>
                </form>
              ) : (
                <>
                  <button type="button" className="conv-btn" onClick={() => onSelect(conversation.id)}>
                    <span className="conv-title">
                      {conversation.pinned ? "📌 " : ""}
                      {conversation.title}
                    </span>
                    <span className="conv-meta">
                      {relativeTime(conversation.updatedAt)} · {conversation.messageCount ?? 0} mensajes
                    </span>
                  </button>
                  <button type="button" className="mini-icon" onClick={() => onPin(conversation.id)} aria-label="Fijar">
                    <Icon name="pin" size={13} />
                  </button>
                  <button type="button" className="mini-icon" onClick={() => setEditing({ id: conversation.id, title: conversation.title })} aria-label="Renombrar">
                    <Icon name="pencil" size={13} />
                  </button>
                  <button type="button" className="mini-icon" onClick={() => onDelete(conversation.id)} aria-label="Borrar">
                    <Icon name="trash" size={13} />
                  </button>
                </>
              )}
            </div>
          ))}
          {!filtered.length && (
            <p className="px-2 py-5 text-center text-[0.76rem] leading-relaxed text-[var(--muted)]">
              {query ? "Sin resultados." : "Aún no hay chats. Escribe abajo para empezar; Capri recordará el contexto."}
            </p>
          )}
        </div>

        <div className="sidebar-foot">
          <button type="button" className="side-item" onClick={onOpenStudio}>
            <Icon name="star" size={16} />
            Estudio de Capri
          </button>
          <button type="button" className="side-item" onClick={onOpenVoice}>
            <Icon name="wave" size={16} />
            Modo voz
          </button>
          <button type="button" className="side-item" onClick={onOpenMemory}>
            <Icon name="brain" size={16} />
            Memoria
            <span className="badge">{memoryCount}</span>
          </button>
          <button type="button" className="side-item" onClick={onOpenSettings}>
            <Icon name="settings" size={16} />
            Ajustes y APIs
          </button>
          <button type="button" className="side-item" onClick={onOpenPerformance}>
            <Icon name="gauge" size={16} />
            Rendimiento
          </button>
          <button type="button" className="side-item" onClick={onExport}>
            <Icon name="download" size={16} />
            Exportar chat
          </button>
          <a className="side-item" href="/capri.html" download="capri.html" style={{ textDecoration: "none" }}>
            <Icon name="device" size={16} />
            App ejecutable (HTML)
          </a>
          <p className="px-2 pt-1 text-[0.62rem] leading-snug text-[var(--muted)]">
            Datos guardados en tu PostgreSQL local · {settings.providers.length} proveedor(es)
          </p>
        </div>
      </aside>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Settings                                                           */
/* ------------------------------------------------------------------ */

type Tab = "general" | "personaje" | "aspecto" | "voz" | "apis" | "memoria" | "accesible" | "rendimiento";

const TONES: { id: Tone; label: string }[] = [
  { id: "cercano", label: "Cercano" },
  { id: "profesional", label: "Profesional" },
  { id: "divertido", label: "Divertido" },
  { id: "directo", label: "Directo" },
  { id: "anime", label: "Anime ✨" },
];

const SPEEDS: { id: Speed; label: string }[] = [
  { id: "instant", label: "Instantánea" },
  { id: "rapido", label: "Rápida" },
  { id: "natural", label: "Natural" },
];

const FONTS: { id: FontChoice; label: string }[] = [
  { id: "system", label: "Sistema" },
  { id: "rounded", label: "Redonda" },
  { id: "serif", label: "Serif" },
  { id: "mono", label: "Mono" },
];

const BUBBLES: { id: BubbleStyle; label: string }[] = [
  { id: "modern", label: "Moderna" },
  { id: "minimal", label: "Minimal" },
  { id: "classic", label: "Clásica" },
];

const BACKGROUND_PRESETS: { name: string; css: string }[] = [
  { name: "Aurora", css: "radial-gradient(60% 60% at 20% 10%, #0f766e80, transparent), radial-gradient(50% 50% at 85% 15%, #1d4ed880, transparent)" },
  { name: "Neón", css: "radial-gradient(50% 50% at 15% 15%, #db277780, transparent), radial-gradient(55% 55% at 85% 25%, #0891b280, transparent)" },
  { name: "Atardecer", css: "linear-gradient(160deg, #7c2d1280, #db277760, #1e1b4b90)" },
  { name: "Bosque", css: "radial-gradient(60% 60% at 25% 20%, #16653480, transparent), radial-gradient(50% 50% at 80% 30%, #36531470, transparent)" },
  { name: "Mono", css: "linear-gradient(180deg, #33415550, #0f172a90)" },
];

export function SettingsModal({
  open,
  onClose,
  initialTab = "general",
  settings,
  voices,
  memories,
  onChange,
  onReset,
  onSave,
  onUploadCharacter,
  onUploadExpression,
  onClearExpression,
  onTestVoice,
  onAddMemory,
  onDeleteMemory,
  onForgetAll,
  onOpenFloating,
  onExportAll,
}: {
  open: boolean;
  onClose: () => void;
  initialTab?: Tab;
  settings: Settings;
  voices: SpeechSynthesisVoice[];
  memories: Memory[];
  onChange: (patch: Partial<Settings>) => void;
  onReset: () => void;
  onSave: () => void;
  onUploadCharacter: (file: File) => void;
  onUploadExpression: (emotion: Emotion, file: File) => void;
  onClearExpression: (emotion: Emotion) => void;
  onTestVoice: () => void;
  onAddMemory: (content: string) => void;
  onDeleteMemory: (id: string) => void;
  onForgetAll: () => void;
  onOpenFloating: () => void;
  onExportAll: () => void;
}) {
  const [tab, setTab] = useState<Tab>(initialTab);
  const [providerTests, setProviderTests] = useState<Record<string, { loading?: boolean; ok?: boolean; message?: string; latency?: number }>>({});
  const [discoveredModels, setDiscoveredModels] = useState<Record<string, string[]>>({});
  const [loadingModels, setLoadingModels] = useState<Record<string, boolean>>({});
  const [memoryDraft, setMemoryDraft] = useState("");
  const characterRef = useRef<HTMLInputElement | null>(null);
  const backgroundRef = useRef<HTMLInputElement | null>(null);
  const expressionRef = useRef<HTMLInputElement | null>(null);
  const [expressionTarget, setExpressionTarget] = useState<Emotion>("happy");
  useEscape(onClose, open);
  if (!open) return null;

  const spanishVoices = [...voices].sort((a, b) => {
    const aEs = /^es/i.test(a.lang) ? 0 : 1;
    const bEs = /^es/i.test(b.lang) ? 0 : 1;
    return aEs - bEs || a.name.localeCompare(b.name);
  });

  const updateProvider = (id: string, patch: Partial<Settings["providers"][number]>) => {
    onChange({ providers: settings.providers.map((provider) => (provider.id === id ? { ...provider, ...patch } : provider)) });
  };

  const addProvider = (kind: ProviderKind) => {
    const preset = PROVIDER_PRESETS.find((item) => item.kind === kind) ?? PROVIDER_PRESETS[0];
    const provider = {
      id: `p-${kind}-${Math.random().toString(36).slice(2, 7)}`,
      name: preset.name,
      kind,
      baseUrl: preset.baseUrl,
      model: preset.model,
      apiKey: "",
      enabled: true,
      temperature: 0.7,
      maxTokens: 1200,
      notes: preset.kind === "custom" ? "Servidor compatible con la API de OpenAI." : preset.docs,
      docs: preset.docs,
    };
    onChange({ providers: [...settings.providers, provider], preferredProvider: provider.id });
  };

  const testOne = async (provider: Settings["providers"][number]) => {
    setProviderTests((current) => ({
      ...current,
      [provider.id]: { ...current[provider.id], loading: true, message: undefined },
    }));
    try {
      const response = await fetch("/api/providers/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          draft: provider,
          providerId: provider.id,
          messages: [
            { role: "system", content: "Responde en una sola frase corta y amable." },
            { role: "user", content: "Di hola y confirma que la conexión funciona." },
          ],
        }),
      });
      const data = (await response.json()) as { ok?: boolean; reply?: string; error?: string; latencyMs?: number };
      setProviderTests((current) => ({
        ...current,
        [provider.id]: data.ok
          ? { loading: false, ok: true, latency: data.latencyMs, message: `✅ ${data.reply?.slice(0, 180) ?? "Conexión correcta"}` }
          : { loading: false, ok: false, message: `⚠️ ${data.error ?? "No se pudo conectar."} Revisa URL base, modelo y clave.` },
      }));
    } catch {
      setProviderTests((current) => ({ ...current, [provider.id]: { loading: false, ok: false, message: "⚠️ Error de red al probar la API." } }));
    }
  };

  const discoverModels = async (provider: Settings["providers"][number]) => {
    setLoadingModels((current) => ({ ...current, [provider.id]: true }));
    try {
      const response = await fetch("/api/providers/models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ draft: provider }),
      });
      const data = (await response.json()) as { models?: string[]; error?: string };
      setDiscoveredModels((current) => ({ ...current, [provider.id]: data.models ?? [] }));
      if (data.error) {
        setProviderTests((current) => ({ ...current, [provider.id]: { loading: false, ok: false, message: `⚠️ ${data.error}` } }));
      }
    } catch {
      setProviderTests((current) => ({ ...current, [provider.id]: { loading: false, ok: false, message: "⚠️ No pude listar modelos." } }));
    } finally {
      setLoadingModels((current) => ({ ...current, [provider.id]: false }));
    }
  };

  const tabs: { id: Tab; label: string; icon: IconName }[] = [
    { id: "general", label: "General", icon: "sliders" },
    { id: "personaje", label: "Personaje", icon: "star" },
    { id: "aspecto", label: "Apariencia", icon: "eye" },
    { id: "voz", label: "Voz", icon: "volume" },
    { id: "apis", label: "APIs / IA", icon: "device" },
    { id: "memoria", label: "Memoria", icon: "brain" },
    { id: "rendimiento", label: "Rendimiento", icon: "gauge" },
    { id: "accesible", label: "Accesible", icon: "shield" },
  ];

  return (
    <>
      <Overlay onClose={onClose} />
      <section className="modal" role="dialog" aria-modal="true" aria-label="Ajustes de Capri">
        <div className="modal-head">
          <CharacterAvatar character={settings.character} customImage={settings.customCharacter} size={30} mood="happy" />
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-[0.98rem] font-semibold">Ajustes de {settings.assistantName}</h2>
            <p className="text-[0.68rem] text-[var(--muted)]">Todo es configurable: personaje, fondo, voz, APIs y memoria</p>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Cerrar ajustes">
            <Icon name="close" size={18} />
          </button>
        </div>

        <div className="tabs">
          {tabs.map((item) => (
            <button key={item.id} type="button" className={`tab ${tab === item.id ? "active" : ""}`} onClick={() => setTab(item.id)}>
              <Icon name={item.icon} size={14} />
              {item.label}
            </button>
          ))}
        </div>

        <div className="modal-body">
          {tab === "general" && (
            <>
              <div className="section">
                <p className="section-title">Identidad</p>
                <label className="mb-1 block text-[0.75rem] text-[var(--muted)]">Nombre del asistente</label>
                <input className="field" value={settings.assistantName} maxLength={24} onChange={(event) => onChange({ assistantName: event.target.value })} placeholder="Capri" />
                <label className="mb-1 mt-3 block text-[0.75rem] text-[var(--muted)]">Tu nombre</label>
                <input className="field" value={settings.userName} maxLength={32} onChange={(event) => onChange({ userName: event.target.value })} placeholder="¿Cómo te llamas?" />
              </div>

              <div className="section">
                <p className="section-title">Personalidad</p>
                <div className="chip-row">
                  {TONES.map((tone) => (
                    <button key={tone.id} type="button" className={`chip ${settings.tone === tone.id ? "active" : ""}`} onClick={() => onChange({ tone: tone.id })}>
                      {tone.label}
                    </button>
                  ))}
                </div>
                <label className="mb-1 mt-3 block text-[0.75rem] text-[var(--muted)]">Instrucciones personalizadas</label>
                <textarea className="field min-h-[70px]" value={settings.customInstructions} maxLength={800} onChange={(event) => onChange({ customInstructions: event.target.value })} placeholder="Ej.: respuestas breves, llámame por mi nombre, tono técnico…" />
                <label className="mb-1 mt-3 block text-[0.75rem] text-[var(--muted)]">Contexto extra para la IA (se envía en cada mensaje)</label>
                <textarea className="field min-h-[70px]" value={settings.systemPrompt} maxLength={4000} onChange={(event) => onChange({ systemPrompt: event.target.value })} placeholder="Ej.: trabajo en una startup de energía solar y prefiero ejemplos de negocio." />
              </div>

              <div className="section">
                <p className="section-title">Comportamiento</p>
                <p className="mb-1 text-[0.75rem] text-[var(--muted)]">Velocidad de escritura</p>
                <div className="chip-row">
                  {SPEEDS.map((speed) => (
                    <button key={speed.id} type="button" className={`chip ${settings.speed === speed.id ? "active" : ""}`} onClick={() => onChange({ speed: speed.id })}>
                      {speed.label}
                    </button>
                  ))}
                </div>
                <div className="mt-2">
                  <Row title="Memoria a largo plazo" description="Guarda datos, gustos y pendientes en PostgreSQL entre chats.">
                    <Toggle checked={settings.memoryEnabled} onChange={() => onChange({ memoryEnabled: !settings.memoryEnabled })} label="Memoria" />
                  </Row>
                  <Row title="Mostrar personaje en el chat" description="El personaje flota sobre la conversación con atajos rápidos.">
                    <Toggle checked={settings.characterVisible} onChange={() => onChange({ characterVisible: !settings.characterVisible })} label="Mostrar personaje" />
                  </Row>
                  <Row title="El personaje se mueve" description="Se desplaza suavemente por la conversación.">
                    <Toggle checked={settings.characterFollow} onChange={() => onChange({ characterFollow: !settings.characterFollow })} label="Movimiento del personaje" />
                  </Row>
                </div>
              </div>
            </>
          )}

          {tab === "personaje" && (
            <>
              <div className="section">
                <p className="section-title">Elige el personaje</p>
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                  {CHARACTER_STYLES.map((style) => (
                    <button
                      key={style.id}
                      type="button"
                      className={`card-option ${settings.character === style.id ? "active" : ""}`}
                      onClick={() => (style.id === "custom" ? characterRef.current?.click() : onChange({ character: style.id }))}
                    >
                      {style.id === "capri" ? (
                        <CharacterAvatar character="capri" size={54} mood="happy" />
                      ) : style.id === "custom" ? (
                        settings.customCharacter ? (
                          <CharacterAvatar character="custom" customImage={settings.customCharacter} size={54} mood="happy" />
                        ) : (
                          <span className="grid h-[78px] place-items-center text-[var(--accent)]">
                            <Icon name="upload" size={26} />
                          </span>
                        )
                      ) : (
                        <CharacterAvatar character={style.id as CharacterStyle} size={46} mood="happy" />
                      )}
                      <span className="name">{style.name}</span>
                      <span className="desc">{style.description}</span>
                    </button>
                  ))}
                </div>
                <input
                  ref={characterRef}
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) onUploadCharacter(file);
                    event.target.value = "";
                  }}
                />
                <p className="hint mt-2">
                  Capri Chibi usa 5 expresiones (idle, pensando, hablando, escuchando y micrófono). Puedes subir tu propio dibujo o foto; se recorta y se muestra completo.
                </p>
              </div>

              <div className="section">
                <p className="section-title">Tamaño y presencia</p>
                <Slider label="Escala del personaje" value={settings.characterSize} min={0.5} max={1.8} step={0.05} onChange={(value) => onChange({ characterSize: value })} format={(value) => `${Math.round(value * 100)}%`} />
                <Row title="Movimiento automático" description="Si lo desactivas, se queda quieto en la esquina.">
                  <Toggle checked={settings.characterFollow} onChange={() => onChange({ characterFollow: !settings.characterFollow })} label="Movimiento" />
                </Row>
                <Row title="Ocultar personaje" description="Solo chat, sin personaje flotante.">
                  <Toggle checked={!settings.characterVisible} onChange={() => onChange({ characterVisible: !settings.characterVisible })} label="Ocultar" />
                </Row>
              </div>

              <div className="section">
                <p className="section-title">Expresiones del personaje</p>
                <p className="hint mb-2">
                  Capri reacciona con la emoción que detecta en la conversación. Puedes sustituir cualquier expresión por tu propia imagen (PNG o JPG).
                </p>
                <div className="expression-grid">
                  {EMOTIONS.map((emotion) => {
                    const custom = settings.expressionImages?.[emotion.id] ?? null;
                    return (
                      <div key={emotion.id} className={`expression-card ${custom ? "customized" : ""}`}>
                        {custom && <span className="badge-dot" />}
                        <div className="expr-stage">
                          <CharacterAvatar
                            character={settings.character}
                            customImage={settings.customCharacter}
                            imageOverride={
                              custom ??
                              (settings.character === "capri" || settings.character === "custom" ? undefined : null)
                            }
                            mood={emotion.id}
                            size={58}
                            still
                          />
                        </div>
                        <span className="expr-label">{emotion.name}</span>
                        <span className="expr-hint">{emotion.hint}</span>
                        <div className="expr-actions">
                          <button
                            type="button"
                            className="btn sm"
                            onClick={() => {
                              setExpressionTarget(emotion.id);
                              expressionRef.current?.click();
                            }}
                          >
                            <Icon name="upload" size={11} /> Subir
                          </button>
                          {custom && (
                            <button type="button" className="mini-icon" onClick={() => onClearExpression(emotion.id)} aria-label={`Restaurar ${emotion.name}`}>
                              <Icon name="refresh" size={12} />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <input
                  ref={expressionRef}
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) onUploadExpression(expressionTarget, file);
                    event.target.value = "";
                  }}
                />
                <div className="mt-3">
                  <Row title="Reacciones automáticas" description="La IA elige la emoción de cada respuesta (enfadada si la faltan al respeto, triste si te pasa algo, emocionada con buenas noticias).">
                    <Toggle checked={settings.autoEmotion} onChange={() => onChange({ autoEmotion: !settings.autoEmotion })} label="Reacciones automáticas" />
                  </Row>
                </div>
              </div>

              <div className="section">
                <p className="section-title">Asistente fuera de la app</p>
                <p className="hint mb-2">
                  Abre a Capri en una ventana flotante siempre visible (Document Picture-in-Picture en Chrome/Edge). Sirve como un asistente tipo Siri sobre cualquier programa: puedes hablarle mientras usas otras apps.
                </p>
                <button type="button" className="btn primary w-full" onClick={onOpenFloating}>
                  <Icon name="globe" size={15} /> Usar en pantalla
                </button>
                <div className="mt-2">
                  <Row title="Permitir ventana flotante" description="Muestra la opción en el menú del personaje.">
                    <Toggle checked={settings.floatingAssistant} onChange={() => onChange({ floatingAssistant: !settings.floatingAssistant })} label="Ventana flotante" />
                  </Row>
                  <Row title="El personaje también aparece allí" description="Puedes hablarle y te contesta con voz y emoción.">
                    <Toggle checked={settings.floatingHotkey} onChange={() => onChange({ floatingHotkey: !settings.floatingHotkey })} label="Personaje en la ventana" />
                  </Row>
                </div>
              </div>
            </>
          )}

          {tab === "aspecto" && (
            <>
              <div className="section">
                <p className="section-title">Tema</p>
                <div className="grid grid-cols-3 gap-2">
                  {THEMES.map((theme) => (
                    <button key={theme.id} type="button" className={`card-option ${settings.theme === theme.id ? "active" : ""}`} onClick={() => onChange({ theme: theme.id as ThemeId })}>
                      <span className="swatch" style={{ background: `linear-gradient(135deg, ${theme.swatch[0]}, ${theme.swatch[1]})` }} />
                      <span className="name">{theme.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="section">
                <p className="section-title">Color de acento</p>
                <div className="flex flex-wrap gap-2">
                  {ACCENTS.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => onChange({ accent: color })}
                      aria-label={`Acento ${color}`}
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: 999,
                        background: color,
                        border: settings.accent === color ? "2px solid var(--text)" : "1px solid var(--line)",
                        boxShadow: settings.accent === color ? `0 0 0 3px ${color}44` : "none",
                      }}
                    />
                  ))}
                  <label className="flex items-center gap-1 text-[0.7rem] text-[var(--muted)]">
                    <input type="color" value={settings.accent} onChange={(event) => onChange({ accent: event.target.value })} aria-label="Color personalizado" className="h-7 w-8 cursor-pointer rounded border border-[var(--line)] bg-transparent" />
                    Otro
                  </label>
                </div>
              </div>

              <div className="section">
                <p className="section-title">Fondo</p>
                <div className="chip-row">
                  {BACKGROUND_PRESETS.map((preset) => (
                    <button key={preset.name} type="button" className="chip" onClick={() => onChange({ background: { ...settings.background, type: "gradient", css: preset.css, imageUrl: null } })}>
                      <span style={{ width: 12, height: 12, borderRadius: 999, background: preset.css, display: "inline-block" }} />
                      {preset.name}
                    </button>
                  ))}
                  <button type="button" className="chip" onClick={() => onChange({ background: { ...settings.background, type: "gradient", css: "", imageUrl: null } })}>
                    Sin fondo
                  </button>
                  <button type="button" className="chip" onClick={() => backgroundRef.current?.click()}>
                    <Icon name="upload" size={12} /> Subir imagen
                  </button>
                </div>
                <input
                  ref={backgroundRef}
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => {
                      const url = String(reader.result ?? "");
                      onChange({ background: { ...settings.background, type: "image", imageUrl: url } });
                    };
                    reader.readAsDataURL(file);
                    event.target.value = "";
                  }}
                />
                {settings.background.imageUrl && (
                  <>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="h-10 w-16 rounded-md border border-[var(--line)] bg-cover bg-center" style={{ backgroundImage: `url(${settings.background.imageUrl})` }} />
                      <button type="button" className="btn sm danger" onClick={() => onChange({ background: { ...settings.background, imageUrl: null, type: "gradient" } })}>
                        Quitar imagen
                      </button>
                    </div>
                    <Slider label="Opacidad de la imagen" value={settings.background.imageOpacity} min={0.05} max={1} step={0.05} onChange={(value) => onChange({ background: { ...settings.background, imageOpacity: value } })} format={(value) => `${Math.round(value * 100)}%`} />
                  </>
                )}
                <Slider label="Oscurecer fondo" value={settings.background.dim} min={0} max={0.9} step={0.05} onChange={(value) => onChange({ background: { ...settings.background, dim: value } })} format={(value) => `${Math.round(value * 100)}%`} />
                <Slider label="Desenfoque" value={settings.background.blur} min={0} max={20} step={1} onChange={(value) => onChange({ background: { ...settings.background, blur: value } })} format={(value) => `${value}px`} />
              </div>

              <div className="section">
                <p className="section-title">Estilo del chat</p>
                <p className="mb-1 text-[0.75rem] text-[var(--muted)]">Burbujas</p>
                <div className="chip-row">
                  {BUBBLES.map((bubble) => (
                    <button key={bubble.id} type="button" className={`chip ${settings.bubbleStyle === bubble.id ? "active" : ""}`} onClick={() => onChange({ bubbleStyle: bubble.id })}>
                      {bubble.label}
                    </button>
                  ))}
                </div>
                <p className="mb-1 mt-3 text-[0.75rem] text-[var(--muted)]">Tipografía</p>
                <div className="chip-row">
                  {FONTS.map((font) => (
                    <button key={font.id} type="button" className={`chip ${settings.font === font.id ? "active" : ""}`} onClick={() => onChange({ font: font.id })}>
                      {font.label}
                    </button>
                  ))}
                </div>
                <Slider label="Redondeo" value={settings.radius} min={4} max={28} step={1} onChange={(value) => onChange({ radius: value })} format={(value) => `${value}px`} />
              </div>
            </>
          )}

          {tab === "voz" && (
            <>
              <div className="section">
                <p className="section-title">Voz del sistema</p>
                <label className="mb-1 block text-[0.75rem] text-[var(--muted)]">Voz</label>
                <select className="field" value={settings.voiceURI ?? ""} onChange={(event) => onChange({ voiceURI: event.target.value || null })} aria-label="Voz">
                  <option value="">Automática (español)</option>
                  {spanishVoices.map((voice) => (
                    <option key={voice.voiceURI} value={voice.voiceURI}>
                      {voice.name} · {voice.lang}
                      {voice.localService ? " · local" : ""}
                    </option>
                  ))}
                </select>
                {!voices.length && <p className="hint mt-1">Tu navegador aún no ofrece voces; se usará la voz del sistema por defecto.</p>}
                <p className="mb-1 mt-3 text-[0.75rem] text-[var(--muted)]">Presets rápidos</p>
                <div className="chip-row">
                  {VOICE_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      className={`chip ${settings.voicePreset === preset.id ? "active" : ""}`}
                      onClick={() => onChange({ voicePreset: preset.id, rate: preset.rate, pitch: preset.pitch, volume: preset.volume })}
                      title={preset.description}
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
                <Slider label="Velocidad" value={settings.rate} min={0.5} max={1.8} step={0.05} onChange={(value) => onChange({ rate: value })} format={(value) => `${value.toFixed(2)}×`} />
                <Slider label="Tono" value={settings.pitch} min={0.5} max={1.8} step={0.05} onChange={(value) => onChange({ pitch: value })} format={(value) => value.toFixed(2)} />
                <Slider label="Volumen" value={settings.volume} min={0} max={1} step={0.05} onChange={(value) => onChange({ volume: value })} format={(value) => `${Math.round(value * 100)}%`} />
                <button type="button" className="btn mt-1" onClick={onTestVoice}>
                  <Icon name="volume" size={15} /> Probar voz
                </button>
              </div>

              <div className="section">
                <p className="section-title">Escucha</p>
                <label className="mb-1 block text-[0.75rem] text-[var(--muted)]">Idioma del micrófono</label>
                <select className="field" value={settings.listenLang} onChange={(event) => onChange({ listenLang: event.target.value })} aria-label="Idioma del micrófono">
                  {LISTEN_LANGS.map((lang) => (
                    <option key={lang.id} value={lang.id}>
                      {lang.label}
                    </option>
                  ))}
                </select>
                <Row title="Leer respuestas en voz alta" description="Capri habla automáticamente al terminar de responder.">
                  <Toggle checked={settings.autoSpeak} onChange={() => onChange({ autoSpeak: !settings.autoSpeak })} label="Leer respuestas" />
                </Row>
                <Row title="Enviar al terminar de hablar" description="El dictado se envía solo cuando dejas de hablar.">
                  <Toggle checked={settings.autoSendVoice} onChange={() => onChange({ autoSendVoice: !settings.autoSendVoice })} label="Enviar al hablar" />
                </Row>
                <Row title="Manos libres" description="Después de responder vuelve a escuchar automáticamente.">
                  <Toggle checked={settings.liveVoice} onChange={() => onChange({ liveVoice: !settings.liveVoice })} label="Manos libres" />
                </Row>
                <p className="hint mt-2">
                  El reconocimiento usa el motor del navegador (Chrome/Edge/Safari). La lectura usa Web Speech. Todo se puede probar desde el botón de voz del compositor.
                </p>
              </div>
            </>
          )}

          {tab === "apis" && (
            <>
              <div className="section">
                <p className="section-title">Dos motores incluidos</p>
                <div className="grid grid-cols-2 gap-2">
                  {settings.providers
                    .filter((provider) => provider.kind === "local" || provider.kind === "online")
                    .map((provider) => (
                      <button
                        key={provider.id}
                        type="button"
                        className={`card-option ${settings.preferredProvider === provider.id ? "active" : ""}`}
                        onClick={() => onChange({ preferredProvider: provider.id })}
                      >
                        <Icon name={provider.kind === "local" ? "device" : "globe"} size={20} />
                        <span className="name">{provider.name}</span>
                        <span className="desc">{provider.kind === "local" ? "Sin internet ni claves" : "IA en la nube sin clave"}</span>
                      </button>
                    ))}
                </div>
                <p className="hint mt-2">
                  **Capri Local** responde al instante sin conexión. **Capri Online** funciona sin configurar nada (motor público de demo, ~1 respuesta cada 30 s) y, si está ocupado o sin red, responde Capri Local automáticamente. Para uso intensivo añade tu propia clave en «Añadir API por servicio» (OpenAI, Groq, Gemini…).
                </p>
                <button
                  type="button"
                  className="btn sm mt-2"
                  onClick={async () => {
                    setProviderTests((current) => ({ ...current, online: { loading: true } }));
                    try {
                      const response = await fetch("/api/online", { cache: "no-store" });
                      const data = (await response.json()) as { ok?: boolean; latencyMs?: number; reply?: string; error?: string };
                      setProviderTests((current) => ({
                        ...current,
                        online: data.ok
                          ? { loading: false, ok: true, latency: data.latencyMs, message: `✅ Capri Online disponible · ${data.latencyMs} ms · ${data.reply?.slice(0, 80) ?? ""}` }
                          : { loading: false, ok: false, message: `⚠️ Capri Online no disponible (${data.error ?? "sin red"}). Se usará el motor local.` },
                      }));
                    } catch {
                      setProviderTests((current) => ({ ...current, online: { loading: false, ok: false, message: "⚠️ Sin conexión al motor online." } }));
                    }
                  }}
                >
                  <Icon name="wave" size={13} /> Comprobar Capri Online
                </button>
                {providerTests.online?.message && (
                  <p className={`mt-2 rounded-lg border px-2.5 py-2 text-[0.71rem] leading-relaxed ${providerTests.online.ok ? "border-emerald-500/40 text-emerald-300" : "border-rose-500/40 text-rose-300"}`}>
                    {providerTests.online.message}
                  </p>
                )}
              </div>

              <div className="section">
                <p className="section-title">Motor activo</p>
                <select className="field" value={settings.preferredProvider} onChange={(event) => onChange({ preferredProvider: event.target.value })} aria-label="Proveedor activo">
                  {settings.providers.map((provider) => (
                    <option key={provider.id} value={provider.id}>
                      {provider.name} · {provider.kind === "local" ? "motor propio" : provider.model || "sin modelo"}
                    </option>
                  ))}
                </select>
                <p className="hint mt-1">
                  Cambia de motor sin tocar el resto: la memoria, la voz y el personaje siguen igual. Si una API falla, Capri responde con su motor local.
                </p>
              </div>

              <div className="section">
                <p className="section-title">Añadir API por servicio</p>
                <div className="grid grid-cols-2 gap-2">
                  {PROVIDER_PRESETS.map((preset) => (
                    <button key={preset.kind} type="button" className="provider-preset" onClick={() => addProvider(preset.kind)}>
                      <span className="dot">{preset.name.slice(0, 2).toUpperCase()}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[0.78rem] font-medium">{preset.name}</span>
                        <span className="block truncate text-[0.62rem] text-[var(--muted)]">{preset.baseUrl.replace("https://", "")}</span>
                      </span>
                      <Icon name="plus" size={14} />
                    </button>
                  ))}
                </div>
                <p className="hint mt-2">
                  También puedes añadir cualquier servidor compatible con OpenAI (Ollama, LM Studio, vLLM, tu propio backend). Solo necesitas la URL base y el nombre del modelo.
                </p>
              </div>

              {settings.providers.map((provider) => {
                const isActive = settings.preferredProvider === provider.id;
                const models = discoveredModels[provider.id] ?? [];
                const test = providerTests[provider.id];
                return (
                  <div key={provider.id} className={`provider-card ${isActive ? "selected" : ""}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[0.85rem] font-semibold">
                          {provider.name}
                          <span className="ml-1 text-[0.65rem] font-normal text-[var(--muted)]">· {provider.kind}</span>
                        </p>
                        <div className="mt-1 flex flex-wrap items-center gap-1">
                          <span className={`status-pill ${isActive ? "ok" : ""}`}>{isActive ? "en uso" : "guardado"}</span>
                          {provider.kind !== "local" && (
                            <span className={`status-pill ${provider.apiKey ? "ok" : "bad"}`}>{provider.apiKey ? "clave guardada" : "sin clave"}</span>
                          )}
                          {test && <span className={`status-pill ${test.ok ? "ok" : "bad"}`}>{test.ok ? `${test.latency ?? 0} ms` : "error"}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button type="button" className="btn sm" onClick={() => onChange({ preferredProvider: provider.id })} disabled={isActive}>
                          {isActive ? "En uso" : "Usar"}
                        </button>
                        {provider.kind !== "local" && (
                          <button
                            type="button"
                            className="mini-icon"
                            aria-label="Eliminar proveedor"
                            onClick={() => {
                              const providers = settings.providers.filter((item) => item.id !== provider.id);
                              onChange({ providers, preferredProvider: providers[0]?.id ?? settings.preferredProvider });
                            }}
                          >
                            <Icon name="trash" size={14} />
                          </button>
                        )}
                      </div>
                    </div>

                    {provider.kind === "local" ? (
                      <p className="hint mt-2">{provider.notes}</p>
                    ) : (
                      <div className="mt-2 grid gap-2">
                        <label className="text-[0.68rem] text-[var(--muted)]">
                          URL base
                          <input className="field mt-1" value={provider.baseUrl} onChange={(event) => updateProvider(provider.id, { baseUrl: event.target.value })} placeholder="https://api.openai.com/v1" />
                        </label>
                        <label className="text-[0.68rem] text-[var(--muted)]">
                          API key{" "}
                          <span className="normal-case">(se guarda en tu PostgreSQL y se muestra enmascarada)</span>
                          <input className="field mt-1" type="password" value={provider.apiKey} onChange={(event) => updateProvider(provider.id, { apiKey: event.target.value })} placeholder="sk-…" autoComplete="off" />
                        </label>
                        <div className="flex items-end gap-2">
                          <label className="min-w-0 flex-1 text-[0.68rem] text-[var(--muted)]">
                            Modelo
                            <input className="field mt-1" value={provider.model} onChange={(event) => updateProvider(provider.id, { model: event.target.value })} placeholder="gpt-4o-mini" />
                          </label>
                          <button
                            type="button"
                            className="btn sm"
                            onClick={() => void discoverModels(provider)}
                            disabled={loadingModels[provider.id]}
                            title="Consultar los modelos disponibles con esta clave"
                          >
                            <Icon name="refresh" size={13} /> {loadingModels[provider.id] ? "…" : "Listar"}
                          </button>
                        </div>
                        {models.length > 0 && (
                          <div className="model-list">
                            {models.map((model) => (
                              <button key={model} type="button" className={`model-chip ${model === provider.model ? "active" : ""}`} onClick={() => updateProvider(provider.id, { model })}>
                                {model}
                              </button>
                            ))}
                          </div>
                        )}
                        <div className="grid grid-cols-2 gap-2">
                          <label className="text-[0.68rem] text-[var(--muted)]">
                            Temperatura · {provider.temperature.toFixed(1)}
                            <input type="range" min={0} max={2} step={0.1} value={provider.temperature} onChange={(event) => updateProvider(provider.id, { temperature: Number(event.target.value) })} className="mt-1" />
                          </label>
                          <label className="text-[0.68rem] text-[var(--muted)]">
                            Máx. tokens
                            <input className="field mt-1" type="number" min={128} max={16000} step={64} value={provider.maxTokens} onChange={(event) => updateProvider(provider.id, { maxTokens: Number(event.target.value) })} />
                          </label>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <button type="button" className="btn sm primary" onClick={() => void testOne(provider)} disabled={providerTests[provider.id]?.loading}>
                            <Icon name="wave" size={13} /> {providerTests[provider.id]?.loading ? "Probando…" : "Probar"}
                          </button>
                          <button type="button" className="btn sm" onClick={() => onChange({ preferredProvider: provider.id })}>
                            <Icon name="check" size={13} /> Guardar y usar
                          </button>
                          <span className="ml-auto flex items-center gap-1 text-[0.66rem] text-[var(--muted)]">
                            activo <Toggle checked={provider.enabled} onChange={() => updateProvider(provider.id, { enabled: !provider.enabled })} label="Activar proveedor" />
                          </span>
                        </div>
                        {test?.message && (
                          <p className={`rounded-lg border px-2.5 py-2 text-[0.71rem] leading-relaxed ${test.ok ? "border-emerald-500/40 text-emerald-300" : "border-rose-500/40 text-rose-300"}`}>{test.message}</p>
                        )}
                        <p className="hint">Documentación de claves: {provider.docs ?? "consulta tu proveedor"}.</p>
                      </div>
                    )}
                  </div>
                );
              })}

              <div className="section">
                <p className="section-title">Cómo se elige el motor</p>
                <ol className="hint ml-4 list-decimal space-y-1">
                  <li>Si el proveedor activo tiene clave y está habilitado, Capri responde con esa API en streaming.</li>
                  <li>Si falta la clave, hay error de red o límite de cuota, responde el motor local al instante.</li>
                  <li>La memoria, las emociones y la voz se aplican igual con cualquier motor.</li>
                </ol>
              </div>
            </>
          )}

          {tab === "memoria" && (
            <>
              <div className="section">
                <p className="section-title">Nuevo recuerdo</p>
                <form
                  className="flex gap-2"
                  onSubmit={(event) => {
                    event.preventDefault();
                    if (memoryDraft.trim().length < 3) return;
                    onAddMemory(memoryDraft.trim());
                    setMemoryDraft("");
                  }}
                >
                  <input className="field" value={memoryDraft} onChange={(event) => setMemoryDraft(event.target.value)} placeholder="«Prefiero reuniones por la mañana»" aria-label="Nuevo recuerdo" />
                  <button type="submit" className="btn primary" aria-label="Guardar">
                    <Icon name="plus" size={16} />
                  </button>
                </form>
                <p className="hint mt-1">También funciona en el chat: «recuerda que…», «¿qué recuerdas de mí?» u «olvida …».</p>
              </div>
              <div className="section">
                <p className="section-title">Recuerdos · {memories.length}</p>
                {memories.map((memory) => (
                  <div key={memory.id} className="memory-item">
                    <div className="min-w-0 flex-1">
                      <span className="kind">{memory.kind}</span>
                      <p className="mt-1 text-[0.82rem] leading-snug">{memory.content}</p>
                      <p className="mt-0.5 text-[0.64rem] text-[var(--muted)]">
                        {relativeTime(memory.createdAt)} · usada {memory.uses} {memory.uses === 1 ? "vez" : "veces"}
                      </p>
                    </div>
                    <button type="button" className="mini-icon" onClick={() => onDeleteMemory(memory.id)} aria-label="Borrar recuerdo">
                      <Icon name="trash" size={14} />
                    </button>
                  </div>
                ))}
                {!memories.length && <p className="hint">Todavía no hay recuerdos guardados.</p>}
                {memories.length > 0 && (
                  <button type="button" className="btn danger mt-3 w-full" onClick={onForgetAll}>
                    <Icon name="trash" size={15} /> Borrar toda la memoria
                  </button>
                )}
              </div>
            </>
          )}

          {tab === "rendimiento" && (
            <>
              <div className="section">
                <p className="section-title">Perfil del dispositivo</p>
                <div className="grid grid-cols-2 gap-2">
                  {([
                    { id: "auto", name: "Automático", desc: "Detecta tu equipo" },
                    { id: "low", name: "Ahorro", desc: "Móvil modesto / batería" },
                    { id: "medium", name: "Equilibrado", desc: "Uso diario" },
                    { id: "high", name: "Máxima", desc: "Todos los efectos" },
                  ] as const).map((mode) => (
                    <button
                      key={mode.id}
                      type="button"
                      className={`card-option ${settings.performanceMode === mode.id ? "active" : ""}`}
                      onClick={() => onChange({ performanceMode: mode.id })}
                    >
                      <span className="name">{mode.name}</span>
                      <span className="desc">{mode.desc}</span>
                    </button>
                  ))}
                </div>
                <p className="hint mt-2">
                  En modo ahorro se desactivan desenfoques, animaciones y física del personaje, se recortan las respuestas largas y se reduce el trabajo por mensaje. Recomendado para móviles con poca memoria.
                </p>
              </div>
              <div className="section">
                <p className="section-title">Ajustes finos</p>
                <Row title="Física y movimiento del personaje" description="Apágalo para no gastar batería animando al personaje.">
                  <Toggle checked={settings.characterPhysics} onChange={() => onChange({ characterPhysics: !settings.characterPhysics })} label="Física" />
                </Row>
                <Row title="Sin streaming (respuesta completa)" description="Menos peticiones visuales, útil con datos lentos.">
                  <Toggle checked={settings.lowDataMode} onChange={() => onChange({ lowDataMode: !settings.lowDataMode })} label="Ahorro de datos" />
                </Row>
                <Row title="Mensajes compactos" description="Reduce espacios y oculta acciones secundarias.">
                  <Toggle checked={settings.compactMessages} onChange={() => onChange({ compactMessages: !settings.compactMessages })} label="Compacto" />
                </Row>
                <Row title="Reducir movimiento" description="Desactiva todas las animaciones.">
                  <Toggle checked={settings.reduceMotion} onChange={() => onChange({ reduceMotion: !settings.reduceMotion })} label="Reducir movimiento" />
                </Row>
                <div className="py-2">
                  <div className="flex items-center justify-between">
                    <span className="row-title">Contexto enviado a la IA</span>
                    <span className="tag">{settings.maxContextMessages} mensajes</span>
                  </div>
                  <input type="range" min={4} max={30} step={2} value={settings.maxContextMessages} onChange={(event) => onChange({ maxContextMessages: Number(event.target.value) })} aria-label="Mensajes de contexto" className="mt-1.5" />
                  <p className="row-desc">Menos mensajes = respuestas más rápidas y económicas.</p>
                </div>
              </div>
              <div className="section">
                <p className="section-title">Almacenamiento</p>
                <p className="hint mb-2">Tus chats, recuerdos y ajustes se guardan en PostgreSQL. Puedes exportar un respaldo completo en cualquier momento.</p>
                <button type="button" className="btn w-full" onClick={onExportAll}>
                  <Icon name="download" size={15} /> Exportar todos mis datos (JSON)
                </button>
                <div className="mt-2 rounded-xl border border-[var(--line)] p-3">
                  <p className="row-title">Versión ejecutable sin servidor</p>
                  <p className="row-desc mb-2">
                    Descarga un único archivo <code>capri.html</code> con el personaje, la memoria local y el motor Capri Local incluidos. Se abre con doble clic en móvil u ordenador, sin instalar nada.
                  </p>
                  <a className="btn primary w-full" href="/capri.html" download="capri.html" style={{ textDecoration: "none" }}>
                    <Icon name="download" size={15} /> Descargar capri.html
                  </a>
                  <a className="btn w-full mt-2" href="/capri.html" target="_blank" rel="noopener" style={{ textDecoration: "none" }}>
                    <Icon name="globe" size={15} /> Abrir versión HTML
                  </a>
                </div>
              </div>
            </>
          )}

          {tab === "accesible" && (
            <>
              <div className="section">
                <p className="section-title">Lectura</p>
                <Slider label="Tamaño del texto" value={settings.fontScale} min={0.9} max={1.35} step={0.05} onChange={(value) => onChange({ fontScale: value })} format={(value) => `${Math.round(value * 100)}%`} />
                <Row title="Alto contraste" description="Bordes y textos más definidos.">
                  <Toggle checked={settings.highContrast} onChange={() => onChange({ highContrast: !settings.highContrast })} label="Alto contraste" />
                </Row>
                <Row title="Reducir movimiento" description="Detiene animaciones y el paseo del personaje.">
                  <Toggle checked={settings.reduceMotion} onChange={() => onChange({ reduceMotion: !settings.reduceMotion })} label="Reducir movimiento" />
                </Row>
                <Row title="Espaciado cómodo" description="Más aire entre mensajes.">
                  <Toggle checked={settings.spacious} onChange={() => onChange({ spacious: !settings.spacious })} label="Espaciado" />
                </Row>
                <div className="row">
                  <div>
                    <p className="row-title">Atajos de teclado</p>
                    <p className="row-desc">
                      Enter envía · Shift + Enter salta línea · Ctrl/⌘ + K abre búsqueda
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        <div className="modal-foot">
          <button type="button" className="btn ghost" onClick={onReset}>
            <Icon name="refresh" size={15} /> Restablecer
          </button>
          <div className="flex gap-2">
            <button type="button" className="btn" onClick={onClose}>
              Cerrar
            </button>
            <button type="button" className="btn primary" onClick={onSave}>
              Guardar cambios
            </button>
          </div>
        </div>
      </section>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Voice overlay                                                      */
/* ------------------------------------------------------------------ */

export function VoiceOverlay({
  open,
  onClose,
  listening,
  speaking,
  interim,
  caption,
  assistantName,
  character,
  customCharacter,
  reduceMotion,
  speechAvailable,
  liveVoice,
  onToggleLive,
  onTalk,
  onSend,
}: {
  open: boolean;
  onClose: () => void;
  listening: boolean;
  speaking: boolean;
  interim: string;
  caption: string;
  assistantName: string;
  character: CharacterStyle;
  customCharacter: string | null;
  reduceMotion: boolean;
  speechAvailable: boolean;
  liveVoice: boolean;
  onToggleLive: () => void;
  onTalk: () => void;
  onSend: (text: string) => void;
}) {
  useEscape(onClose, open);
  if (!open) return null;
  const mood: Mood = speaking ? "speaking" : listening ? "listening" : "idle";

  return (
    <div className="voice" role="dialog" aria-modal="true" aria-label="Modo voz">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${listening || speaking ? "bg-emerald-400" : "bg-[var(--muted)]"}`} />
          <p className="text-[0.75rem] font-semibold uppercase tracking-[0.12em]">{assistantName} · voz</p>
        </div>
        <button type="button" className="icon-btn" onClick={onClose} aria-label="Cerrar voz">
          <Icon name="close" size={18} />
        </button>
      </div>

      <div className="voice-stage">
        <CharacterAvatar character={character} customImage={customCharacter} size={150} mood={mood} still={reduceMotion} />
        <span className="tag">
          {speaking ? "hablando" : listening ? "escuchando" : "en espera"}
          {liveVoice ? " · manos libres" : ""}
        </span>
        <div className="wave" aria-hidden="true">
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((bar) => (
            <span key={bar} style={{ animationDelay: `${bar * 0.08}s`, animationPlayState: listening || speaking ? "running" : "paused", height: listening || speaking ? undefined : 8 }} />
          ))}
        </div>
        <div className="voice-caption">{interim || caption}</div>
        {!speechAvailable && <p className="hint max-w-[440px] text-center">Este navegador no permite dictado. Puedes escribir y Capri te responde en voz alta.</p>}
        <div className="flex items-center justify-center gap-4 pt-1">
          <button type="button" className={`voice-round ${listening ? "danger" : "primary"}`} onClick={onTalk} disabled={!speechAvailable} aria-label={listening ? "Detener" : "Hablar"}>
            <Icon name={listening ? "stop" : "mic"} size={24} />
          </button>
          <button type="button" className="voice-round" onClick={() => onSend("")} aria-label="Detener y cerrar" style={{ display: "none" }} />
          <button type="button" className="voice-round danger" onClick={onClose} aria-label="Cerrar y detener">
            <Icon name="close" size={24} />
          </button>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          <button type="button" className={`btn sm ${liveVoice ? "primary" : ""}`} onClick={onToggleLive}>
            <Icon name="refresh" size={13} /> {liveVoice ? "Manos libres activo" : "Activar manos libres"}
          </button>
          {interim.trim() && (
            <button type="button" className="btn sm" onClick={() => onSend(interim.trim())}>
              <Icon name="send" size={13} /> Enviar al chat
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
