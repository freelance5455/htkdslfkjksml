"use client";

import { useEffect, useRef, useState } from "react";
import { CharacterAvatar, type Mood } from "@/components/CharacterAvatar";
import { Icon } from "@/components/icons";
import type { CharacterStyle } from "@/lib/types";

type Props = {
  character: CharacterStyle;
  customImage: string | null;
  mood: Mood;
  assistantName: string;
  reduceMotion: boolean;
  size: number;
  onAction: (prompt: string) => void;
  onVoice: () => void;
  onFloat: () => void;
  allowFloat: boolean;
};

const ACTIONS: { label: string; prompt: string; iconName: "brain" | "calendar" | "bulb" | "book" }[] = [
  { label: "¿Qué recuerdas de mí?", prompt: "¿Qué recuerdas de mí?", iconName: "brain" },
  { label: "Organiza mi día", prompt: "Organiza mi día: revisar correo, trabajo profundo, gimnasio", iconName: "calendar" },
  { label: "Dame ideas", prompt: "Dame ideas creativas para un proyecto personal", iconName: "bulb" },
  { label: "Explícame algo", prompt: "Explícame cómo funciona la inteligencia artificial", iconName: "book" },
];

const STATUS: Record<Mood, string> = {
  idle: "en línea",
  happy: "contenta",
  excited: "emocionada",
  thinking: "pensando",
  speaking: "hablando",
  listening: "escuchando",
  annoyed: "enfadada",
  sad: "preocupada",
  surprised: "sorprendida",
  singing: "cantando",
};

export function Companion({ character, customImage, mood, assistantName, reduceMotion, size, onAction, onVoice, onFloat, allowFloat }: Props) {
  const [wander, setWander] = useState({ x: 84, y: 22 });
  const [open, setOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (reduceMotion) return;
    const timer = window.setInterval(() => {
      setWander({ x: 78 + Math.random() * 14, y: 12 + Math.random() * 34 });
    }, 7000);
    return () => window.clearInterval(timer);
  }, [reduceMotion]);

  useEffect(() => {
    if (!open) return;
    const timeout = window.setTimeout(() => setOpen(false), 9000);
    return () => window.clearTimeout(timeout);
  }, [open]);

  const scaled = Math.round(52 * size);

  return (
    <div className="companion-layer">
      <div
        className={`companion ${reduceMotion ? "companion-still" : ""}`}
        style={{ left: `${reduceMotion ? 88 : wander.x}%`, top: `${reduceMotion ? 18 : wander.y}%` }}
      >
        <button
          ref={buttonRef}
          type="button"
          className="companion-btn"
          aria-label={`${assistantName}: atajos rápidos`}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <CharacterAvatar
            character={character}
            customImage={customImage}
            mood={mood}
            size={scaled}
            still={reduceMotion}
          />
        </button>
        <span className="companion-tag">
          {assistantName} · {STATUS[mood]}
        </span>
        {open && (
          <div className={`companion-bubble ${(reduceMotion ? 88 : wander.x) > 70 ? "left" : "right"}`} role="menu">
            <div className="flex items-center justify-between px-1 pb-1">
              <span className="text-[0.64rem] uppercase tracking-[0.12em] text-[var(--muted)]">Atajos</span>
              <button type="button" className="mini-icon" onClick={() => setOpen(false)} aria-label="Cerrar atajos">
                <Icon name="close" size={13} />
              </button>
            </div>
            {ACTIONS.map((action) => (
              <button
                key={action.label}
                type="button"
                className="companion-action"
                onClick={() => {
                  setOpen(false);
                  onAction(action.prompt);
                }}
              >
                <Icon name={action.iconName} size={14} />
                {action.label}
              </button>
            ))}
            <button
              type="button"
              className="companion-action"
              onClick={() => {
                setOpen(false);
                onVoice();
              }}
            >
              <Icon name="wave" size={14} />
              Hablar con {assistantName}
            </button>
            {allowFloat && (
              <button
                type="button"
                className="companion-action"
                onClick={() => {
                  setOpen(false);
                  onFloat();
                }}
              >
                <Icon name="globe" size={14} />
                Usar en pantalla
              </button>
            )}
            <p className="px-1 pt-1 text-[0.6rem] leading-snug text-[var(--muted)]">
              Puedes cambiar el personaje y su tamaño en Ajustes → Personaje.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
