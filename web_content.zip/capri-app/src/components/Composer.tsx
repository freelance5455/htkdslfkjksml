"use client";

import { useEffect, useRef, useState } from "react";
import { Icon } from "@/components/icons";
import { formatBytes } from "@/lib/files";
import type { Attachment } from "@/lib/types";

type Props = {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  busy: boolean;
  attachments: Attachment[];
  onAddFiles: (files: File[]) => void;
  onRemoveAttachment: (id: string) => void;
  dictating: boolean;
  onToggleDictation: () => void;
  onOpenVoice: () => void;
  onOpenSettings: () => void;
  interim: string;
  assistantName: string;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  speechAvailable: boolean;
  providerLabel: string;
  modelLabel: string;
  onOpenProviders: () => void;
};

export function Composer({
  value,
  onChange,
  onSend,
  onStop,
  busy,
  attachments,
  onAddFiles,
  onRemoveAttachment,
  dictating,
  onToggleDictation,
  onOpenVoice,
  onOpenSettings,
  interim,
  assistantName,
  autoSpeak,
  onToggleAutoSpeak,
  speechAvailable,
  providerLabel,
  modelLabel,
  onOpenProviders,
}: Props) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [dragOver, setDragOver] = useState(false);

  useEffect(() => {
    const element = textareaRef.current;
    if (!element) return;
    element.style.height = "auto";
    element.style.height = `${Math.min(160, element.scrollHeight)}px`;
  }, [value]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        textareaRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <div className="composer-dock">
      <div
        className="composer"
        onDragOver={(event) => {
          event.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragOver(false);
          const files = Array.from(event.dataTransfer.files ?? []);
          if (files.length) onAddFiles(files);
        }}
        style={dragOver ? { borderColor: "var(--accent)", boxShadow: "0 0 0 3px color-mix(in srgb, var(--accent) 20%, transparent)" } : undefined}
      >
        {attachments.length > 0 && (
          <div className="attach-row">
            {attachments.map((attachment) => (
              <span key={attachment.id} className="attach">
                {attachment.kind === "image" && attachment.dataUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={attachment.dataUrl} alt={attachment.name} />
                ) : (
                  <Icon name={attachment.kind === "text" ? "book" : attachment.kind === "file" ? "device" : "plus"} size={14} />
                )}
                <span className="min-w-0 flex-1">
                  <span className="attach-name">{attachment.name}</span>
                  <span className="block text-[0.6rem] text-[var(--muted)]">
                    {formatBytes(attachment.size)}
                    {attachment.kind === "text" ? " · texto" : attachment.kind === "image" ? " · imagen" : " · archivo"}
                  </span>
                </span>
                <button type="button" onClick={() => onRemoveAttachment(attachment.id)} aria-label={`Quitar ${attachment.name}`} className="text-[var(--muted)]">
                  <Icon name="close" size={12} />
                </button>
              </span>
            ))}
          </div>
        )}

        <textarea
          ref={textareaRef}
          rows={1}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              onSend();
            }
          }}
          placeholder={dictating ? "Escuchando… habla ahora" : `Pregunta lo que quieras a ${assistantName}…`}
          aria-label={`Mensaje para ${assistantName}`}
          enterKeyHint="send"
        />
        {dictating && interim && <p className="px-2 pb-1 text-[0.72rem] italic text-[var(--accent)]">{interim}</p>}

        <div className="composer-row">
          <button type="button" className="tool-btn" onClick={() => fileRef.current?.click()} title="Adjuntar archivos o imágenes" aria-label="Adjuntar">
            <Icon name="plus" size={19} />
          </button>
          <input
            ref={fileRef}
            type="file"
            hidden
            multiple
            accept="*/*"
            onChange={(event) => {
              const files = Array.from(event.target.files ?? []);
              if (files.length) onAddFiles(files);
              event.target.value = "";
            }}
          />
          <button
            type="button"
            className={`tool-btn ${dictating ? "recording" : ""}`}
            onClick={onToggleDictation}
            title={speechAvailable ? (dictating ? "Detener dictado" : "Dictar por voz") : "Dictado no disponible en este navegador"}
            aria-label="Dictado"
          >
            <Icon name="mic" size={18} />
          </button>
          <button type="button" className={`tool-btn ${autoSpeak ? "on" : ""}`} onClick={onToggleAutoSpeak} title={autoSpeak ? "Desactivar lectura" : "Leer respuestas en voz alta"} aria-label="Lectura en voz alta">
            <Icon name={autoSpeak ? "volume" : "volumeOff"} size={18} />
          </button>
          <button type="button" className="tool-btn" onClick={onOpenVoice} title="Modo de voz en directo" aria-label="Modo voz">
            <Icon name="wave" size={18} />
          </button>
          <button type="button" className="tool-btn" onClick={onOpenProviders} title={`${providerLabel} · ${modelLabel}`} aria-label="Cambiar modelo">
            <Icon name="device" size={17} />
          </button>
          <span className="hidden min-w-0 flex-1 truncate px-1 text-[0.66rem] text-[var(--muted)] sm:block" title={`${providerLabel} · ${modelLabel}`}>
            {providerLabel} · {modelLabel}
          </span>
          <button type="button" className="tool-btn" onClick={onOpenSettings} title="Ajustes" aria-label="Ajustes" style={{ display: "none" }}>
            <Icon name="settings" size={17} />
          </button>
          {busy ? (
            <button type="button" className="send-btn" onClick={onStop} aria-label="Detener respuesta">
              <Icon name="stop" size={17} />
            </button>
          ) : (
            <button type="button" className="send-btn" onClick={onSend} disabled={!value.trim() && attachments.length === 0} aria-label="Enviar">
              <Icon name="send" size={18} />
            </button>
          )}
        </div>
      </div>
      <p className="composer-hint">
        {assistantName} puede equivocarse. Enter envía · Shift+Enter salto · arrastra o adjunta cualquier archivo (imágenes, docs, código, PDF…).
      </p>
    </div>
  );
}
