"use client";

import type { CSSProperties } from "react";

export type IconName =
  | "menu"
  | "close"
  | "plus"
  | "mic"
  | "volume"
  | "volumeOff"
  | "send"
  | "settings"
  | "brain"
  | "search"
  | "pin"
  | "pencil"
  | "trash"
  | "download"
  | "check"
  | "chevron"
  | "star"
  | "refresh"
  | "copy"
  | "stop"
  | "upload"
  | "sparkles"
  | "eye"
  | "smile"
  | "sliders"
  | "history"
  | "shield"
  | "calendar"
  | "bulb"
  | "book"
  | "globe"
  | "wave"
  | "device"
  | "gauge";

const PATHS: Record<IconName, string> = {
  menu: "M4 6h16M4 12h16M4 18h16",
  close: "M6 6l12 12M18 6L6 18",
  plus: "M12 5v14M5 12h14",
  mic: "M12 3a3 3 0 0 1 3 3v6a3 3 0 1 1-6 0V6a3 3 0 0 1 3-3ZM5 11a7 7 0 0 0 14 0M12 18v3M8 21h8",
  volume: "M4 10v4h3l4 4V6L7 10H4Zm12-3a6 6 0 0 1 0 10M18 4a9 9 0 0 1 0 16",
  volumeOff: "M4 10v4h3l4 4V6L7 10H4Zm11-1 5 6m0-6-5 6",
  send: "M12 19V5M5 12l7-7 7 7",
  settings:
    "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm8-3.5a8 8 0 0 0-.1-1.3l2-1.6-2-3.4-2.4 1a8 8 0 0 0-2.2-1.3L15 2.5h-4l-.3 2.6a8 8 0 0 0-2.2 1.3l-2.4-1-2 3.4 2 1.6a8 8 0 0 0 0 2.6l-2 1.6 2 3.4 2.4-1a8 8 0 0 0 2.2 1.3l.3 2.6h4l.3-2.6a8 8 0 0 0 2.2-1.3l2.4 1 2-3.4-2-1.6c.06-.43.1-.86.1-1.3Z",
  brain:
    "M9.5 4A3.5 3.5 0 0 0 6 7.5v.8A3.5 3.5 0 0 0 4 11.5c0 1 .4 1.9 1 2.5A3.5 3.5 0 0 0 8 20h1.5V4Zm5 0A3.5 3.5 0 0 1 18 7.5v.8a3.5 3.5 0 0 1 2 3.2c0 1-.4 1.9-1 2.5A3.5 3.5 0 0 1 16 20h-1.5V4Zm-3.5 2v2m3 2v2m-3 3v2",
  search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.3-4.3",
  pin: "M9 4h6l-1 6 3 3v2H7v-2l3-3-1-6Zm3 11v5",
  pencil: "M4 20h4L20 8l-4-4L4 16v4Zm10-14 4 4",
  trash: "M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13M10 11v6m4-6v6",
  download: "M12 4v10m-4-4 4 4 4-4M5 20h14",
  check: "M4 12l5 5L20 6",
  chevron: "M6 9l6 6 6-6",
  star: "M12 3l2.6 5.6 6.1.8-4.5 4.3 1.1 6.1-5.3-3-5.3 3 1.1-6.1L3.3 9.4l6.1-.8L12 3Z",
  refresh: "M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6",
  copy: "M9 9h10v10H9V9Zm-4 6H4V4h11v1",
  stop: "M7 7h10v10H7z",
  upload: "M12 16V4m-4 4 4-4 4 4M4 16v4h16v-4",
  sparkles: "M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8L12 3Zm7 10 .9 2.1 2.1.9-2.1.9L19 19l-.9-2.1-2.1-.9 2.1-.9L19 13Z",
  eye: "M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Zm10 2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  smile: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM8.5 14a4 4 0 0 0 7 0M9 9.5h.01M15 9.5h.01",
  sliders: "M4 7h9m4 0h3M4 17h4m4 0h8M13 4v6M8 14v6",
  history: "M3 12a9 9 0 1 0 3-6.7M3 5v5h5M12 8v4l3 2",
  shield: "M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3Zm-2.5 9 2 2 4-4",
  calendar: "M4 6h16v14H4V6Zm4-3v4m8-4v4M4 11h16m-11 4h2m3 0h1",
  bulb: "M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5.9 1.2.9 1.9V16h5.2v-.2c0-.7.3-1.4.9-1.9A6 6 0 0 0 12 3Z",
  book: "M4 5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2V5Zm2 13h13M8 7h7",
  globe: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm-9-9h18M12 3c2.5 2.5 3.8 5.6 3.8 9S14.5 18.5 12 21c-2.5-2.5-3.8-5.6-3.8-9S9.5 5.5 12 3Z",
  wave: "M3 12c2 0 2-5 4-5s2 10 4 10 2-7 4-7 2 4 4 4h2",
  device: "M5 4h14v12H5V4Zm4 16h6m-3-4v4",
  gauge: "M4 18a8 8 0 1 1 16 0M12 18l4-5M8 18h8",
};

export function Icon({
  name,
  size = 19,
  className,
  style,
}: {
  name: IconName;
  size?: number;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={style}
      aria-hidden="true"
    >
      <path d={PATHS[name]} />
    </svg>
  );
}
