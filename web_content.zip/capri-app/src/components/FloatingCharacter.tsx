"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CharacterAvatar, type Mood } from "@/components/CharacterAvatar";
import { Icon } from "@/components/icons";
import type { CharacterStyle } from "@/lib/types";

type Props = {
  character: CharacterStyle;
  image: string | null;
  mood: Mood;
  assistantName: string;
  size: number;
  physics: boolean;
  seat: "composer" | "float" | "corner";
  reactions: boolean;
  petMessage: string;
  allowFloat: boolean;
  onAction: (prompt: string) => void;
  onVoice: () => void;
  onFloat: () => void;
  onOpenStudio: () => void;
  onPet: () => void;
  onSeatChange?: (seat: "composer" | "float" | "corner") => void;
};

type Point = { x: number; y: number };
type Mode = "seated" | "floating" | "dragging";

const GREETINGS = [
  "¡Hola! Soy {name}. Arrástrame a donde quieras 😊",
  "{name} aquí. Tócame y te digo algo.",
  "Estoy en la barra del chat, ¡hablamos!",
  "Puedes sentarme en otra esquina si arrastras.",
];

export function FloatingCharacter({
  character,
  image,
  mood,
  assistantName,
  size,
  physics,
  seat,
  reactions,
  petMessage,
  allowFloat,
  onAction,
  onVoice,
  onFloat,
  onOpenStudio,
  onPet,
  onSeatChange,
}: Props) {
  const [modeOverride, setModeOverride] = useState<Mode | null>(null);
  const [offsetOverride, setOffsetOverride] = useState<Point | null>(null);
  const mode: Mode = modeOverride ?? (seat === "float" ? "floating" : "seated");
  const offset: Point = offsetOverride ?? (seat === "corner" ? { x: -8, y: -6 } : { x: 0, y: 0 });
  const setMode = setModeOverride;
  const setOffset = (next: Point | ((current: Point) => Point)) => {
    setOffsetOverride((current) => {
      const base = current ?? (seat === "corner" ? { x: -8, y: -6 } : { x: 0, y: 0 });
      return typeof next === "function" ? next(base) : next;
    });
  };
  const [floatPos, setFloatPos] = useState<Point>({ x: 84, y: 18 });
  const [open, setOpen] = useState(false);
  const [petting, setPetting] = useState(false);
  const [speech, setSpeech] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [landing, setLanding] = useState(false);
  const dragRef = useRef<{ start: Point; origin: Point; moved: boolean } | null>(null);
  const layerRef = useRef<HTMLDivElement | null>(null);
  const speechTimer = useRef<number | null>(null);

  const say = useCallback((message: string) => {
    setSpeech(message);
    if (speechTimer.current) window.clearTimeout(speechTimer.current);
    speechTimer.current = window.setTimeout(() => setSpeech(null), 4200);
  }, []);

  useEffect(() => {
    if (mode !== "floating" || !physics) return;
    const timer = window.setInterval(() => {
      setFloatPos((current) => ({
        x: Math.max(12, Math.min(88, current.x + (Math.random() - 0.5) * 16)),
        y: Math.max(6, Math.min(46, current.y + (Math.random() - 0.5) * 14)),
      }));
    }, 5200);
    return () => window.clearInterval(timer);
  }, [mode, physics]);

  useEffect(
    () => () => {
      if (speechTimer.current) window.clearTimeout(speechTimer.current);
    },
    [],
  );

  const floorOffset = mode === "seated" ? 0 : 0;

  const onPointerDown = (event: React.PointerEvent<HTMLButtonElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      start: { x: event.clientX, y: event.clientY },
      origin: mode === "floating" ? floatPos : offset,
      moved: false,
    };
    setDragging(true);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    if (!drag) return;
    const dx = event.clientX - drag.start.x;
    const dy = event.clientY - drag.start.y;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) drag.moved = true;
    if (mode === "floating") {
      const rect = layerRef.current?.getBoundingClientRect();
      if (!rect) return;
      setFloatPos({
        x: Math.max(4, Math.min(96, drag.origin.x + (dx / rect.width) * 100)),
        y: Math.max(1, Math.min(85, drag.origin.y + (dy / rect.height) * 100)),
      });
    } else {
      setOffset({
        x: Math.max(-180, Math.min(180, drag.origin.x + dx)),
        y: Math.max(-320, Math.min(80, drag.origin.y + dy)),
      });
      setMode("dragging");
    }
  };

  const onPointerUp = (event: React.PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    dragRef.current = null;
    setDragging(false);
    try {
      event.currentTarget.releasePointerCapture(event.pointerId);
    } catch {
      // ignore
    }
    if (!drag) return;

    if (!drag.moved) {
      if (reactions) {
        setPetting(true);
        say(petMessage || GREETINGS[Math.floor(Math.random() * GREETINGS.length)].replace("{name}", assistantName));
        onPet();
        window.setTimeout(() => setPetting(false), 1600);
      } else {
        setOpen((value) => !value);
      }
      return;
    }

    // Dropped near the bottom composer → sit on the chat bar (with landing animation)
    const target = event.currentTarget.getBoundingClientRect();
    const viewportHeight = window.innerHeight;
    if (target.top > viewportHeight * 0.55) {
      setMode("seated");
      setOffset({ x: Math.max(-160, Math.min(160, offset.x)), y: -2 });
      setLanding(true);
      window.setTimeout(() => setLanding(false), 700);
      onSeatChange?.("composer");
      say("¡Me siento aquí para acompañarte! ✨");
    } else {
      setMode("floating");
      setFloatPos((current) => ({
        x: Math.max(6, Math.min(94, current.x)),
        y: Math.max(3, Math.min(72, current.y)),
      }));
      onSeatChange?.("float");
      say("¡Floto a tu lado!");
    }
  };

  const seated = mode !== "floating";
  const px = Math.round(46 * size);

  return (
    <div className="character-layer" ref={layerRef} aria-live="polite">
      {seated ? (
        <div
          className={`character character-seated ${dragging ? "dragging" : ""} ${landing ? "landing" : ""}`}
          style={{ transform: `translate(${offset.x}px, ${offset.y}px)` }}
        >
          <CharacterBubble
            open={open}
            speech={speech}
            assistantName={assistantName}
            allowFloat={allowFloat}
            onClose={() => setOpen(false)}
            onAction={(prompt) => {
              setOpen(false);
              onAction(prompt);
            }}
            onVoice={() => {
              setOpen(false);
              onVoice();
            }}
            onFloat={() => {
              setOpen(false);
              onFloat();
            }}
            onStudio={() => {
              setOpen(false);
              onOpenStudio();
            }}
          />
          <CharacterButton
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onDoubleClick={() => onOpenStudio()}
            ariaLabel={`${assistantName}: arrastra, toca para saludar`}
            open={open}
            dragging={dragging}
            petting={petting}
            mood={mood}
            character={character}
            image={image}
            px={px}
          />
          <span className="character-tag">{assistantName} · arrástrame</span>
        </div>
      ) : (
        <div className="character character-floating" style={{ left: `${floatPos.x}%`, top: `${floatPos.y}%` }}>
          <CharacterBubble
            open={open}
            speech={speech}
            assistantName={assistantName}
            allowFloat={allowFloat}
            onClose={() => setOpen(false)}
            onAction={(prompt) => {
              setOpen(false);
              onAction(prompt);
            }}
            onVoice={() => {
              setOpen(false);
              onVoice();
            }}
            onFloat={() => {
              setOpen(false);
              onFloat();
            }}
            onStudio={() => {
              setOpen(false);
              onOpenStudio();
            }}
          />
          <CharacterButton
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onDoubleClick={() => onOpenStudio()}
            ariaLabel={`${assistantName}: arrastra o toca`}
            open={open}
            dragging={dragging}
            petting={petting}
            mood={mood}
            character={character}
            image={image}
            px={px}
          />
          <span className="character-tag">{assistantName} · flotando</span>
        </div>
      )}
      <span className="sr-only">{`Personaje ${assistantName}. Usa Tab y Enter para abrir sus acciones.`}</span>
      <span style={{ display: "none" }}>{floorOffset}</span>
    </div>
  );
}

function CharacterButton({
  onPointerDown,
  onPointerMove,
  onPointerUp,
  onDoubleClick,
  ariaLabel,
  open,
  dragging,
  petting,
  mood,
  character,
  image,
  px,
}: {
  onPointerDown: (event: React.PointerEvent<HTMLButtonElement>) => void;
  onPointerMove: (event: React.PointerEvent<HTMLButtonElement>) => void;
  onPointerUp: (event: React.PointerEvent<HTMLButtonElement>) => void;
  onDoubleClick: () => void;
  ariaLabel: string;
  open: boolean;
  dragging: boolean;
  petting: boolean;
  mood: Mood;
  character: CharacterStyle;
  image: string | null;
  px: number;
}) {
  return (
    <button
      type="button"
      className={`character-btn ${dragging ? "grabbing" : ""} ${petting ? "happy-hop" : ""}`}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onDoubleClick={onDoubleClick}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onPointerUp({ currentTarget: event.currentTarget, clientX: 0, clientY: 0, pointerId: 0 } as unknown as React.PointerEvent<HTMLButtonElement>);
        }
      }}
      aria-label={ariaLabel}
      aria-expanded={open}
      title="Tócame para saludar · arrástrame para moverme · doble toque para el estudio"
    >
      <CharacterAvatar character={character} customImage={image} imageOverride={image} mood={mood} size={px} />
    </button>
  );
}

function CharacterBubble({
  open,
  speech,
  assistantName,
  allowFloat,
  onClose,
  onAction,
  onVoice,
  onFloat,
  onStudio,
}: {
  open: boolean;
  speech: string | null;
  assistantName: string;
  allowFloat: boolean;
  onClose: () => void;
  onAction: (prompt: string) => void;
  onVoice: () => void;
  onFloat: () => void;
  onStudio: () => void;
}) {
  if (speech && !open) {
    return (
      <div className="character-speech">
        {speech}
        <button type="button" className="mini-icon" onClick={onClose} aria-label="Cerrar mensaje">
          <Icon name="close" size={11} />
        </button>
      </div>
    );
  }
  if (!open) return null;
  return (
    <div className="character-menu" role="menu">
      <div className="flex items-center justify-between px-1 pb-1">
        <span className="text-[0.62rem] uppercase tracking-[0.12em] text-[var(--muted)]">{assistantName}</span>
        <button type="button" className="mini-icon" onClick={onClose} aria-label="Cerrar menú">
          <Icon name="close" size={12} />
        </button>
      </div>
      <button type="button" className="companion-action" onClick={() => onAction("¿Qué recuerdas de mí?")}>
        <Icon name="brain" size={13} /> ¿Qué recuerdas de mí?
      </button>
      <button type="button" className="companion-action" onClick={() => onAction("Organiza mi día con lo que sepas de mí")}>
        <Icon name="calendar" size={13} /> Organiza mi día
      </button>
      <button type="button" className="companion-action" onClick={onVoice}>
        <Icon name="wave" size={13} /> Hablar en voz
      </button>
      <button type="button" className="companion-action" onClick={onStudio}>
        <Icon name="star" size={13} /> Personalizar a {assistantName}
      </button>
      {allowFloat && (
        <button type="button" className="companion-action" onClick={onFloat}>
          <Icon name="globe" size={13} /> Usar en pantalla
        </button>
      )}
    </div>
  );
}
