"use client";

import { useId } from "react";
import { MOOD_SPRITES, type CharacterStyle } from "@/lib/types";

import type { Emotion } from "@/lib/types";

export type Mood = Emotion;

type Props = {
  character?: CharacterStyle;
  customImage?: string | null;
  imageOverride?: string | null;
  mood?: Mood;
  size?: number;
  className?: string;
  still?: boolean;
  look?: { x: number; y: number };
};

const PALETTES: Record<string, { a: string; b: string; glow: string; face: string; body: string }> = {
  spark: { a: "#d8b4fe", b: "#6d28d9", glow: "#a855f7", face: "#f5f3ff", body: "#c4b5fd" },
  nova: { a: "#fbcfe8", b: "#7e22ce", glow: "#f472b6", face: "#fdf2f8", body: "#f0abfc" },
  cyber: { a: "#99f6e4", b: "#0f766e", glow: "#2dd4bf", face: "#ecfeff", body: "#5eead4" },
  zen: { a: "#fde68a", b: "#4d7c0f", glow: "#fbbf24", face: "#fefce8", body: "#fcd34d" },
  quantum: { a: "#bfdbfe", b: "#3730a3", glow: "#60a5fa", face: "#eff6ff", body: "#93c5fd" },
};

export function CharacterAvatar({
  character = "capri",
  customImage,
  imageOverride,
  mood = "idle",
  size = 64,
  className = "",
  still = false,
  look = { x: 0, y: 0 },
}: Props) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");

  const sprite =
    imageOverride ??
    (character === "capri"
      ? MOOD_SPRITES[mood] ?? "/characters/capri-" + mood + ".png"
      : character === "custom"
        ? customImage
        : null);

  if (sprite) {
    const height = size * 1.5;
    return (
      <span
        className={`sprite-wrap ${still ? "" : "sprite-bob"} ${className}`}
        style={{ width: size, height, flex: "none" }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={sprite}
          alt="Capri"
          width={size}
          height={height}
          draggable={false}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "contain",
            objectPosition: "center bottom",
            filter: "drop-shadow(0 6px 14px rgba(0,0,0,0.35))",
          }}
        />
      </span>
    );
  }

  const palette = PALETTES[character] ?? PALETTES.spark;
  const gradientId = `g-${uid}`;
  const glowId = `glow-${uid}`;
  const pupilX = Math.max(-1, Math.min(1, look.x)) * 2.3;
  const pupilY = Math.max(-1, Math.min(1, look.y)) * 2;
  const talking = mood === "speaking";
  const closedEyes = mood === "sad";
  const happy = mood === "happy";

  return (
    <svg
      viewBox="0 0 120 146"
      width={size}
      height={size * 1.216}
      className={className}
      role="img"
      aria-label={`Asistente ${character}`}
    >
      <defs>
        <linearGradient id={gradientId} x1="24" y1="20" x2="96" y2="104" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={palette.a} />
          <stop offset="1" stopColor={palette.b} />
        </linearGradient>
        <radialGradient id={glowId} cx="50%" cy="50%">
          <stop offset="0" stopColor={palette.glow} stopOpacity="0.55" />
          <stop offset="1" stopColor={palette.glow} stopOpacity="0" />
        </radialGradient>
      </defs>

      {(character === "nova" || character === "quantum") && (
        <>
          <ellipse cx="60" cy="62" rx="55" ry="48" fill={`url(#${glowId})`} />
          <g className={still ? undefined : "orbit-ring"}>
            <ellipse
              cx="60"
              cy="62"
              rx="51"
              ry="36"
              fill="none"
              stroke={palette.glow}
              strokeOpacity="0.5"
              strokeWidth="1.2"
              strokeDasharray={character === "quantum" ? "3 5" : undefined}
              transform="rotate(-18 60 62)"
            />
            <circle cx="104" cy="50" r="3" fill={palette.body} opacity="0.9" />
          </g>
        </>
      )}

      <ellipse cx="60" cy="136" rx="25" ry="4.6" fill="#000" opacity="0.3" />

      <g className={still ? undefined : "char-bob"}>
        <g className={still ? undefined : "char-antenna"}>
          <path d="M60 26V14" stroke={palette.body} strokeWidth="2.6" strokeLinecap="round" />
          <path
            d="M60 4l2.6 5.4 5.9.8-4.3 4.2 1 5.9-5.2-2.8-5.2 2.8 1-5.9-4.3-4.2 5.9-.8L60 4Z"
            fill={palette.face}
            className={still ? undefined : "char-sparkle"}
          />
        </g>

        <ellipse cx="27" cy="78" rx="7.5" ry="12.5" fill={`url(#${gradientId})`} transform="rotate(-16 27 78)" />
        <ellipse cx="93" cy="78" rx="7.5" ry="12.5" fill={`url(#${gradientId})`} transform="rotate(16 93 78)" />

        <path
          d="M60 24c18.6 0 31 13.4 31 32.6 0 12.7-2.7 22.7-7.5 30C78.7 93.3 70.5 98 60 98s-18.7-4.7-23.5-11.4C31.7 79.3 29 69.3 29 56.6 29 37.4 41.4 24 60 24Z"
          fill={`url(#${gradientId})`}
          stroke="#fff"
          strokeOpacity="0.28"
          strokeWidth="1.4"
        />
        <ellipse cx="60" cy="72" rx="24" ry="20" fill="#fff" opacity="0.12" />

        {closedEyes ? (
          <path d="M44 58q5 4 10 0M66 58q5 4 10 0" stroke="#241242" strokeWidth="2.4" strokeLinecap="round" fill="none" />
        ) : (
          <>
            <g className={still ? undefined : "char-eye"}>
              <ellipse cx="49" cy="57" rx="6.2" ry="7.2" fill={palette.face} />
              <ellipse cx={49 + pupilX} cy={57 + pupilY} rx="2.7" ry="3.2" fill="#1c1033" />
              <circle cx={50.4 + pupilX} cy={55.4 + pupilY} r="0.9" fill="#fff" />
            </g>
            <g className={still ? undefined : "char-eye"} style={{ animationDelay: "0.18s" }}>
              <ellipse cx="71" cy="57" rx="6.2" ry="7.2" fill={palette.face} />
              <ellipse cx={71 + pupilX} cy={57 + pupilY} rx="2.7" ry="3.2" fill="#1c1033" />
              <circle cx={72.4 + pupilX} cy={55.4 + pupilY} r="0.9" fill="#fff" />
            </g>
          </>
        )}
        <ellipse cx="38" cy="66" rx="4.6" ry="2.6" fill="#fb7185" opacity="0.5" />
        <ellipse cx="82" cy="66" rx="4.6" ry="2.6" fill="#fb7185" opacity="0.5" />
        {talking ? (
          <ellipse cx="60" cy="75" rx="5" ry="4.4" fill="#2a1247" className="char-mouth talking" />
        ) : happy ? (
          <path d="M52 72q8 9 16 0" stroke="#2a1247" strokeWidth="2.6" strokeLinecap="round" fill="none" />
        ) : (
          <path d="M54 74q6 5 12 0" stroke="#2a1247" strokeWidth="2.6" strokeLinecap="round" fill="none" />
        )}
      </g>
    </svg>
  );
}
