"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CharacterAvatar, type Mood } from "@/components/CharacterAvatar";
import { CharacterStudio } from "@/components/CharacterStudio";
import { FloatingCharacter } from "@/components/FloatingCharacter";
import { Composer } from "@/components/Composer";
import { Icon, type IconName } from "@/components/icons";
import { Markdown, plainForSpeech } from "@/components/Markdown";
import { SettingsModal, Sidebar, Toast, VoiceOverlay, type ToastState } from "@/components/Panels";
import { fileToCharacterImage, filesToAttachments, formatBytes } from "@/lib/files";
import { openFloatingAssistant } from "@/lib/floating";
import { createRecognizer, hasRecognition, hasSynthesis, listVoices, loadVoices, speak, stopSpeaking } from "@/lib/speech";
import { relativeTime, sortMemories } from "@/lib/text";
import {
  DEFAULT_SETTINGS,
  activeProvider,
  expressionImage,
  mergeSettings,
  type AppState,
  type Attachment,
  type ChatMessage,
  type Conversation,
  type Emotion,
  type Memory,
  type Settings,
} from "@/lib/types";

const SKILL_LABELS: Record<string, string> = {
  memoria: "Memoria",
  plan: "Plan",
  ideas: "Ideas",
  explicar: "Explicación",
  resumen: "Resumen",
  redaccion: "Redacción",
  archivos: "Archivos",
  matematicas: "Cálculo",
  codigo: "Código",
  decision: "Decisión",
  hora: "Hora",
  charla: "Charla",
  general: "Respuesta",
  ia: "IA",
};

type StreamEvent =
  | {
      type: "meta";
      conversation: Conversation;
      userMessage: ChatMessage | null;
      assistantMessage: ChatMessage;
      newMemories: Memory[];
      deletedMemoryIds: string[];
      memoriesUsed: string[];
      skill: string;
      emotion?: Emotion;
      provider: string;
    }
  | { type: "delta"; value: string }
  | {
      type: "done";
      conversation: Conversation;
      assistantId: string;
      content: string;
      emotion?: Emotion;
      provider: string;
      providerError: string | null;
    };

const SUGGESTIONS = [
  { title: "Organizarme", hint: "Un plan real con horas y pausas", prompt: "Organiza mi día: revisar correo, reunión de equipo, trabajo profundo y gimnasio", icon: "calendar" as const },
  { title: "Ideas creativas", hint: "Seis enfoques accionables", prompt: "Dame ideas creativas para un proyecto personal", icon: "sparkles" as const },
  { title: "Aprender algo", hint: "Explicación clara con ejemplo", prompt: "Explícame cómo funciona la inteligencia artificial", icon: "book" as const },
  { title: "Mi memoria", hint: "Lo que Capri recuerda de ti", prompt: "¿Qué recuerdas de mí?", icon: "brain" as const },
];

function patchConversation(list: Conversation[], conversation: Conversation): Conversation[] {
  const exists = list.some((item) => item.id === conversation.id);
  const next = exists
    ? list.map((item) =>
        item.id === conversation.id
          ? { ...item, ...conversation, messageCount: conversation.messageCount || item.messageCount }
          : item,
      )
    : [conversation, ...list];
  return next.sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return b.updatedAt.localeCompare(a.updatedAt);
  });
}

/** Intenta ejecutar comandos tipo Siri (abrir webs/apps, buscar, música). Devuelve true si se manejó. */
function tryDeviceCommand(raw: string, toast: (msg: string, kind?: "ok" | "error" | "info") => void): boolean {
  const text = raw.trim().toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
  if (!text) return false;

  const open = (url: string, label: string) => {
    try {
      window.open(url, "_blank", "noopener,noreferrer");
      toast(`Abriendo ${label}…`, "ok");
      return true;
    } catch {
      toast(`No pude abrir ${label}.`, "error");
      return true;
    }
  };

  // Buscar en Google / YouTube
  const searchMatch = text.match(/^(busca|buscar|search|google)\s+(?:en\s+google\s+)?(.+)$/i) || text.match(/^busca\s+(.+)\s+en\s+google$/i);
  if (searchMatch) {
    const q = (searchMatch[2] || searchMatch[1] || "").trim();
    if (q) return open(`https://www.google.com/search?q=${encodeURIComponent(q)}`, `búsqueda: ${q}`);
  }
  const ytSearch = text.match(/^(busca|buscar|reproduce|pon)\s+(?:en\s+)?(?:youtube|yt)\s+(.+)$/i) || text.match(/^(pon|reproduce)\s+(.+)\s+en\s+youtube$/i);
  if (ytSearch) {
    const q = (ytSearch[2] || ytSearch[1] || "").trim();
    if (q) return open(`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`, `YouTube: ${q}`);
  }

  // Música
  if (/^(reproduce|pon|play)\s+(musica|música|music)|abre\s+(spotify|musica|música)/i.test(text) || text === "musica" || text === "música") {
    return open("https://music.youtube.com/", "YouTube Music");
  }
  if (/abre\s+spotify/i.test(text)) return open("https://open.spotify.com/", "Spotify");

  // Apps / sitios comunes
  const apps: [RegExp, string, string][] = [
    [/^(abre|abrir|open)\s+(youtube|yt)$/i, "https://www.youtube.com/", "YouTube"],
    [/^(abre|abrir|open)\s+(whatsapp|wsp|wa)$/i, "https://web.whatsapp.com/", "WhatsApp"],
    [/^(abre|abrir|open)\s+(gmail|correo|email)$/i, "https://mail.google.com/", "Gmail"],
    [/^(abre|abrir|open)\s+(maps|mapas|google\s*maps)$/i, "https://maps.google.com/", "Google Maps"],
    [/^(abre|abrir|open)\s+(drive|google\s*drive)$/i, "https://drive.google.com/", "Google Drive"],
    [/^(abre|abrir|open)\s+(twitter|x)$/i, "https://x.com/", "X"],
    [/^(abre|abrir|open)\s+(instagram|ig)$/i, "https://www.instagram.com/", "Instagram"],
    [/^(abre|abrir|open)\s+(tiktok)$/i, "https://www.tiktok.com/", "TikTok"],
    [/^(abre|abrir|open)\s+(netflix)$/i, "https://www.netflix.com/", "Netflix"],
    [/^(abre|abrir|open)\s+(traductor|translate)$/i, "https://translate.google.com/", "Traductor"],
    [/^(abre|abrir|open)\s+(clima|tiempo|weather)$/i, "https://www.google.com/search?q=clima", "el clima"],
    [/^(abre|abrir|open)\s+(calculadora)$/i, "https://www.google.com/search?q=calculadora", "calculadora"],
  ];
  for (const [re, url, label] of apps) {
    if (re.test(text)) return open(url, label);
  }

  // "abre [cualquier cosa]" genérico → búsqueda Google
  const genericOpen = text.match(/^(abre|abrir|open)\s+(.+)$/i);
  if (genericOpen) {
    const target = genericOpen[2].trim();
    if (target.length > 1) return open(`https://www.google.com/search?q=${encodeURIComponent(target)}`, target);
  }

  return false;
}

export default function CapriApp({ initialState, bootError = false }: { initialState: AppState | null; bootError?: boolean }) {
  const [settings, setSettings] = useState<Settings>(initialState?.settings ?? DEFAULT_SETTINGS);
  const [conversations, setConversations] = useState<Conversation[]>(initialState?.conversations ?? []);
  const [activeId, setActiveId] = useState<string | null>(initialState?.activeId ?? null);
  const [messages, setMessages] = useState<ChatMessage[]>(initialState?.messages ?? []);
  const [memories, setMemories] = useState<Memory[]>(initialState?.memories ?? []);
  const [draft, setDraft] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [busy, setBusy] = useState(false);
  const [streamingId, setStreamingId] = useState<string | null>(null);
  const [firstChunk, setFirstChunk] = useState(false);
  const [pending, setPending] = useState(false);
  const [happy, setHappy] = useState(false);
  const [reaction, setReaction] = useState<Emotion>("idle");
  const [studioOpen, setStudioOpen] = useState(false);
  const [lowPower, setLowPower] = useState(false);
  const [simpleMode, setSimpleMode] = useState(false);
  const [panelOpen, setPanelOpen] = useState<"chat" | "voz">("chat");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<"general" | "personaje" | "aspecto" | "voz" | "apis" | "memoria" | "accesible" | "rendimiento">("general");
  const [studioTab, setStudioTab] = useState<"personaje" | "expresiones" | "voz" | "personalidad" | "escena" | "asistente">("personaje");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [dictating, setDictating] = useState(false);
  const [interim, setInterim] = useState("");
  const [voiceListening, setVoiceListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [voiceCaption, setVoiceCaption] = useState("Toca el micrófono y habla. Te escucho y respondo en voz alta.");
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [loadingState, setLoadingState] = useState(!initialState);
  const [dbError, setDbError] = useState(bootError);
  const [autoScroll, setAutoScroll] = useState(true);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const busyRef = useRef(false);
  const settingsRef = useRef(settings);
  const activeIdRef = useRef(activeId);
  const streamingRef = useRef<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const accumulatedRef = useRef("");
  const firstChunkRef = useRef(false);
  const toastTimer = useRef<number | null>(null);
  const happyTimer = useRef<number | null>(null);
  const persistTimer = useRef<number | null>(null);
  const recognizerRef = useRef<{ start: () => boolean; stop: () => void } | null>(null);
  const voiceDraftRef = useRef("");
  const voiceStartRef = useRef<(() => void) | null>(null);
  const voiceOpenRef = useRef(false);
  const liveVoiceRef = useRef(settings.liveVoice);
  const autoSendVoiceRef = useRef(settings.autoSendVoice);
  const sendRef = useRef<((options: { text?: string; mode?: "send" | "regenerate" }) => Promise<void>) | null>(null);

  const speechAvailable = useMemo(() => hasRecognition(), []);
  const provider = useMemo(() => activeProvider(settings), [settings]);
  const providerLabel = provider?.kind === "local" || !provider ? "Capri local" : provider.name;
  const modelLabel = provider?.kind === "local" || !provider ? "motor propio" : provider.model || "modelo sin definir";
  const userInitial = (settings.userName || "Tú").trim().charAt(0).toUpperCase() || "T";

  const showToast = useCallback((text: string, kind: "ok" | "error" | "info" = "info") => {
    setToast({ text, kind });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 4200);
  }, []);

  /* ------------------------- visual settings ------------------------- */
  useEffect(() => {
    settingsRef.current = settings;
    liveVoiceRef.current = settings.liveVoice;
    autoSendVoiceRef.current = settings.autoSendVoice;
    const root = document.documentElement;
    root.dataset.theme = settings.theme;
    root.dataset.font = settings.font;
    root.dataset.bubbles = settings.bubbleStyle;
    root.dataset.highContrast = settings.highContrast ? "true" : "false";
    root.dataset.reduceMotion = settings.reduceMotion ? "true" : "false";
    root.style.setProperty("--accent", settings.accent);
    root.style.setProperty("--font-scale", String(settings.fontScale));
    root.style.setProperty("--radius", `${settings.radius}px`);
    root.style.setProperty("--bg-opacity", String(settings.background.imageOpacity));
    root.style.setProperty("--bg-blur", `${settings.background.blur}px`);
    root.style.setProperty("--bg-dim", String(settings.background.dim));
    const perf =
      settings.performanceMode === "auto"
        ? lowPower
          ? "low"
          : "medium"
        : settings.performanceMode;
    root.dataset.perf = perf;
    root.dataset.compact = settings.compactMessages ? "true" : "false";
    root.dataset.simple = simpleMode ? "true" : "false";
    try {
      window.localStorage.setItem(
        "capri-look",
        JSON.stringify({
          theme: settings.theme,
          accent: settings.accent,
          font: settings.font,
          bubbles: settings.bubbleStyle,
          fontScale: settings.fontScale,
          radius: settings.radius,
          highContrast: settings.highContrast,
          reduceMotion: settings.reduceMotion,
        }),
      );
    } catch {
      // ignore storage errors
    }
  }, [settings, lowPower, simpleMode]);

  useEffect(() => {
    const nav = navigator as Navigator & { deviceMemory?: number; connection?: { saveData?: boolean; effectiveType?: string } };
    const weak =
      (nav.hardwareConcurrency ?? 8) <= 4 ||
      (nav.deviceMemory ?? 8) <= 4 ||
      Boolean(nav.connection?.saveData) ||
      /2g|slow-2g/.test(nav.connection?.effectiveType ?? "");
    setLowPower(weak);
    try {
      setSimpleMode(window.localStorage.getItem("capri-simple") === "1");
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem("capri-simple", simpleMode ? "1" : "0");
    } catch {
      // ignore
    }
  }, [simpleMode]);

  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);

  useEffect(() => {
    voiceOpenRef.current = voiceOpen;
  }, [voiceOpen]);

  useEffect(() => {
    setVoices(listVoices());
    return loadVoices((available) => setVoices(available));
  }, []);

  const applyState = useCallback((state: AppState) => {
    setSettings(mergeSettings(state.settings));
    setConversations(state.conversations);
    setActiveId(state.activeId);
    setMessages(state.messages);
    setMemories(state.memories);
    activeIdRef.current = state.activeId;
  }, []);

  const refreshState = useCallback(
    async (conversationId?: string | null) => {
      setLoadingState(true);
      try {
        const query = conversationId ? `?conversationId=${encodeURIComponent(conversationId)}` : "";
        const response = await fetch(`/api/state${query}`, { cache: "no-store" });
        if (!response.ok) throw new Error("state");
        const state = (await response.json()) as AppState;
        applyState(state);
        setDbError(false);
      } catch {
        setDbError(true);
        showToast("No pude cargar la base de datos. Reintenta en unos segundos.", "error");
      } finally {
        setLoadingState(false);
      }
    },
    [applyState, showToast],
  );

  useEffect(() => {
    if (initialState) return;
    void refreshState();
  }, [initialState, refreshState]);

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get("studio") === "1") {
        setStudioTab("personaje");
        setStudioOpen(true);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (!autoScroll) return;
    const frame = window.requestAnimationFrame(() => {
      const element = scrollRef.current;
      if (element) element.scrollTop = element.scrollHeight;
      bottomRef.current?.scrollIntoView({ block: "end" });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [messages, autoScroll, pending]);

  useEffect(
    () => () => {
      stopSpeaking();
      recognizerRef.current?.stop();
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (happyTimer.current) window.clearTimeout(happyTimer.current);
      if (persistTimer.current) window.clearTimeout(persistTimer.current);
    },
    [],
  );

  const queuePersist = useCallback((next: Settings) => {
    if (persistTimer.current) window.clearTimeout(persistTimer.current);
    persistTimer.current = window.setTimeout(() => {
      void fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(next),
      })
        .then(async (response) => {
          if (!response.ok) throw new Error();
          const saved = (await response.json()) as Settings;
          setSettings((current) => mergeSettings({ ...current, ...saved }));
        })
        .catch(() => showToast("No pude guardar los ajustes en el servidor.", "error"));
    }, 500);
  }, [showToast]);

  const changeSettings = useCallback(
    (patch: Partial<Settings>) => {
      setSettings((current) => {
        const next = mergeSettings({ ...current, ...patch });
        queuePersist(next);
        return next;
      });
    },
    [queuePersist],
  );

  const saveSettingsNow = useCallback(async () => {
    try {
      if (persistTimer.current) window.clearTimeout(persistTimer.current);
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settingsRef.current),
      });
      if (!response.ok) throw new Error();
      const saved = (await response.json()) as Settings;
      setSettings(mergeSettings(saved));
      showToast("Ajustes guardados", "ok");
      setSettingsOpen(false);
    } catch {
      showToast("No pude guardar los ajustes.", "error");
    }
  }, [showToast]);

  const resetSettings = useCallback(async () => {
    setSettings(DEFAULT_SETTINGS);
    try {
      await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(DEFAULT_SETTINGS),
      });
      showToast("Ajustes restablecidos", "ok");
    } catch {
      showToast("No pude restablecer los ajustes.", "error");
    }
  }, [showToast]);

  /* ------------------------------ voice ------------------------------ */
  const openSettings = useCallback((tab: "general" | "personaje" | "aspecto" | "voz" | "apis" | "memoria" | "accesible" | "rendimiento" = "general") => {
    setSettingsTab(tab);
    setSettingsOpen(true);
  }, []);

  const speakText = useCallback(
    (text: string, id?: string) => {
      if (!hasSynthesis()) {
        showToast("Este navegador no permite lectura en voz alta.", "error");
        return;
      }
      const body = plainForSpeech(text);
      if (!body) return;
      setSpeakingId(id ?? "voice");
      const started = speak(body, {
        voiceURI: settingsRef.current.voiceURI,
        rate: settingsRef.current.rate,
        pitch: settingsRef.current.pitch,
        volume: settingsRef.current.volume,
        lang: settingsRef.current.listenLang,
        onEnd: () => {
          setSpeakingId(null);
          if (liveVoiceRef.current && voiceOpenRef.current) window.setTimeout(() => voiceStartRef.current?.(), 320);
        },
        onError: () => setSpeakingId(null),
      });
      if (!started) setSpeakingId(null);
    },
    [showToast],
  );

  const stopSpeakingNow = useCallback(() => {
    stopSpeaking();
    setSpeakingId(null);
  }, []);

  /* ------------------------------ chat ------------------------------- */
  const runChat = useCallback(
    async (options: { text?: string; mode?: "send" | "regenerate" }) => {
      if (busyRef.current) return;
      const mode = options.mode ?? "send";
      const text = (options.text ?? "").trim();
      const files = mode === "send" ? attachments : [];
      if (mode === "send" && !text && !files.length) return;
      if (mode === "regenerate" && !activeIdRef.current) {
        showToast("No hay respuesta que regenerar.", "info");
        return;
      }

      // Comandos tipo asistente (estilo Siri) — abren apps/webs del dispositivo cuando es posible
      if (mode === "send" && text && !files.length) {
        const handled = tryDeviceCommand(text, showToast);
        if (handled) {
          setDraft("");
          return;
        }
      }

      stopSpeakingNow();
      setBusy(true);
      busyRef.current = true;
      setPending(true);
      setFirstChunk(false);
      firstChunkRef.current = false;
      setAutoScroll(true);
      accumulatedRef.current = "";
      setVoiceCaption(`${settingsRef.current.assistantName} está pensando…`);

      const tempId = `temp-${Date.now()}`;
      if (mode === "send") {
        setMessages((current) => [
          ...current,
          {
            id: tempId,
            conversationId: activeIdRef.current ?? "pending",
            role: "user",
            content: text,
            attachments: files,
            memoriesUsed: [],
            skill: null,
            createdAt: new Date().toISOString(),
            pending: true,
          },
        ]);
        setDraft("");
        setAttachments([]);
      } else {
        setMessages((current) => {
          const index = [...current].reverse().findIndex((message) => message.role === "assistant");
          if (index === -1) return current;
          return current.filter((_message, position) => position !== current.length - 1 - index);
        });
      }

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            conversationId: activeIdRef.current,
            text,
            attachments: files,
            mode,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            nowIso: new Date().toISOString(),
            providerId: settingsRef.current.preferredProvider,
          }),
        });

        if (!response.ok || !response.body) {
          const data = (await response.json().catch(() => ({}))) as { error?: string };
          throw new Error(data.error || "No pude generar la respuesta.");
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        const handle = (event: StreamEvent) => {
          if (event.type === "meta") {
            streamingRef.current = event.assistantMessage.id;
            setStreamingId(event.assistantMessage.id);
            setPending(false);
            setActiveId(event.conversation.id);
            activeIdRef.current = event.conversation.id;
            setConversations((current) => patchConversation(current, event.conversation));
            setMessages((current) => {
              const cleaned = current.filter((message) => message.id !== tempId && message.id !== event.assistantMessage.id);
              const next = [...cleaned];
              if (mode === "send" && event.userMessage) next.push(event.userMessage);
              next.push({ ...event.assistantMessage, content: "", pending: true, emotion: event.emotion ?? "thinking" });
              return next;
            });
            if (event.deletedMemoryIds.length) {
              setMemories((current) => current.filter((memory) => !event.deletedMemoryIds.includes(memory.id)));
            }
            if (event.newMemories.length) {
              setMemories((current) => {
                const known = new Set(current.map((memory) => memory.id));
                return sortMemories([...event.newMemories.filter((memory) => !known.has(memory.id)), ...current]);
              });
            }
            return;
          }

          if (event.type === "delta") {
            if (!firstChunkRef.current) {
              firstChunkRef.current = true;
              setFirstChunk(true);
            }
            accumulatedRef.current += event.value;
            const target = streamingRef.current;
            const value = accumulatedRef.current;
            setMessages((current) => current.map((message) => (message.id === target ? { ...message, content: value, pending: false } : message)));
            return;
          }

          if (event.type === "done") {
            setConversations((current) => patchConversation(current, event.conversation));
            setMessages((current) =>
              current.map((message) =>
                message.id === event.assistantId
                  ? { ...message, content: event.content, pending: false, provider: event.provider, emotion: event.emotion ?? message.emotion }
                  : message,
              ),
            );
            if (event.emotion && settingsRef.current.autoEmotion) setReaction(event.emotion);
            if (event.providerError) {
              showToast(`${providerLabel}: ${event.providerError.slice(0, 140)}`, "error");
            }
          }
        };

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let newline = buffer.indexOf("\n");
          while (newline >= 0) {
            const line = buffer.slice(0, newline).trim();
            buffer = buffer.slice(newline + 1);
            newline = buffer.indexOf("\n");
            if (!line) continue;
            try {
              handle(JSON.parse(line) as StreamEvent);
            } catch {
              // ignore malformed lines
            }
          }
        }

        setMessages((current) => current.map((message) => (message.id === streamingRef.current ? { ...message, pending: false } : message)));
        setHappy(true);
        if (happyTimer.current) window.clearTimeout(happyTimer.current);
        happyTimer.current = window.setTimeout(() => setHappy(false), 2200);

        const reply = accumulatedRef.current;
        if (reply) {
          setVoiceCaption(reply.split("\n")[0].replace(/[#*>`]/g, "").slice(0, 220));
          setVoiceTranscript(reply.slice(0, 600));
          if (settingsRef.current.autoSpeak || voiceOpenRef.current) speakText(reply, streamingRef.current ?? "voice");
        }
      } catch (error) {
        if ((error as Error).name === "AbortError") {
          setMessages((current) => {
            const target = streamingRef.current;
            return current.flatMap((message) => (message.id === target ? (message.content ? [{ ...message, pending: false }] : []) : [message]));
          });
          showToast("Respuesta detenida", "info");
        } else {
          showToast(error instanceof Error ? error.message : "Algo falló al responder.", "error");
          setMessages((current) => current.filter((message) => message.id !== streamingRef.current && message.id !== tempId));
        }
      } finally {
        streamingRef.current = null;
        abortRef.current = null;
        setStreamingId(null);
        setPending(false);
        setBusy(false);
        busyRef.current = false;
        setFirstChunk(false);
        if (liveVoiceRef.current && voiceOpenRef.current && !hasSynthesis()) {
          window.setTimeout(() => voiceStartRef.current?.(), 320);
        }
      }
    },
    [attachments, providerLabel, showToast, speakText, stopSpeakingNow],
  );

  sendRef.current = runChat;

  const stopResponse = useCallback(() => {
    abortRef.current?.abort();
    setBusy(false);
    busyRef.current = false;
    setStreamingId(null);
    setPending(false);
  }, []);

  const selectConversation = useCallback(
    async (id: string) => {
      setSidebarOpen(false);
      setActiveId(id);
      activeIdRef.current = id;
      setAutoScroll(true);
      try {
        const response = await fetch(`/api/conversations/${id}`, { cache: "no-store" });
        if (!response.ok) throw new Error();
        setMessages((await response.json()) as ChatMessage[]);
      } catch {
        showToast("No pude abrir ese chat.", "error");
      }
    },
    [showToast],
  );

  const newChat = useCallback(() => {
    abortRef.current?.abort();
    stopSpeakingNow();
    setActiveId(null);
    activeIdRef.current = null;
    setMessages([]);
    setDraft("");
    setAttachments([]);
    setSidebarOpen(false);
    setAutoScroll(true);
  }, [stopSpeakingNow]);

  const renameConversation = useCallback(
    async (id: string, title: string) => {
      const clean = title.trim() || "Nuevo chat";
      setConversations((current) => {
        const existing = current.find((item) => item.id === id);
        return existing ? patchConversation(current, { ...existing, title: clean, updatedAt: new Date().toISOString() }) : current;
      });
      try {
        const response = await fetch(`/api/conversations/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: clean }),
        });
        if (!response.ok) throw new Error();
        showToast("Título actualizado", "ok");
      } catch {
        showToast("No pude renombrar el chat.", "error");
      }
    },
    [showToast],
  );

  const togglePin = useCallback(
    async (id: string) => {
      const conversation = conversations.find((item) => item.id === id);
      if (!conversation) return;
      const pinned = !conversation.pinned;
      setConversations((current) => patchConversation(current, { ...conversation, pinned }));
      try {
        await fetch(`/api/conversations/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pinned }),
        });
      } catch {
        showToast("No pude fijar el chat.", "error");
      }
    },
    [conversations, showToast],
  );

  const removeConversation = useCallback(
    async (id: string) => {
      if (!window.confirm("¿Borrar este chat? La memoria se conserva.")) return;
      const wasActive = activeIdRef.current === id;
      setConversations((current) => current.filter((conversation) => conversation.id !== id));
      if (wasActive) newChat();
      try {
        await fetch(`/api/conversations/${id}`, { method: "DELETE" });
        showToast("Chat borrado", "ok");
      } catch {
        showToast("No pude borrar el chat.", "error");
      }
    },
    [newChat, showToast],
  );

  const addFiles = useCallback(
    async (files: File[]) => {
      const { attachments: next, error } = await filesToAttachments(files);
      if (error) showToast(error, "error");
      if (next.length) {
        setAttachments((current) => [...current, ...next].slice(0, 4));
        showToast(next.length === 1 ? `«${next[0].name}» listo` : `${next.length} archivos listos`, "ok");
      }
    },
    [showToast],
  );

  const deleteMemoryById = useCallback(
    async (id: string) => {
      setMemories((current) => current.filter((memory) => memory.id !== id));
      try {
        await fetch(`/api/memories/${id}`, { method: "DELETE" });
        showToast("Recuerdo borrado", "ok");
      } catch {
        showToast("No pude borrar el recuerdo.", "error");
      }
    },
    [showToast],
  );

  const addMemory = useCallback(
    async (content: string) => {
      try {
        const response = await fetch("/api/memories", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content }),
        });
        if (!response.ok) throw new Error();
        const created = (await response.json()) as Memory[];
        setMemories((current) => {
          const known = new Set(current.map((memory) => memory.id));
          return sortMemories([...created.filter((memory) => !known.has(memory.id)), ...current]);
        });
        showToast(created.length ? "Recuerdo guardado" : "Ya tenía ese recuerdo", created.length ? "ok" : "info");
      } catch {
        showToast("No pude guardar el recuerdo.", "error");
      }
    },
    [showToast],
  );

  const forgetAll = useCallback(async () => {
    if (!window.confirm("¿Borrar todos los recuerdos? No se puede deshacer.")) return;
    try {
      const response = await fetch("/api/memories", { method: "DELETE" });
      if (!response.ok) throw new Error();
      setMemories([]);
      showToast("Memoria vaciada", "ok");
    } catch {
      showToast("No pude vaciar la memoria.", "error");
    }
  }, [showToast]);

  const uploadCharacter = useCallback(
    async (file: File) => {
      const dataUrl = await fileToCharacterImage(file)
        .then((attachment) => attachment.dataUrl)
        .catch(() => undefined);
      if (dataUrl) {
        changeSettings({ customCharacter: dataUrl, character: "custom" });
        showToast("Personaje personalizado actualizado", "ok");
      } else {
        showToast("No pude procesar esa imagen.", "error");
      }
    },
    [changeSettings, showToast],
  );

  const uploadExpression = useCallback(
    async (emotion: Emotion, file: File) => {
      const dataUrl = await fileToCharacterImage(file)
        .then((attachment) => attachment.dataUrl)
        .catch(() => undefined);
      if (!dataUrl) {
        showToast("No pude procesar esa imagen.", "error");
        return;
      }
      changeSettings({ expressionImages: { ...settingsRef.current.expressionImages, [emotion]: dataUrl } });
      showToast(`Expresión «${emotion}» actualizada`, "ok");
    },
    [changeSettings, showToast],
  );

  const clearExpression = useCallback(
    (emotion: Emotion) => {
      const next = { ...settingsRef.current.expressionImages };
      delete next[emotion];
      changeSettings({ expressionImages: next });
      showToast("Expresión restaurada", "ok");
    },
    [changeSettings, showToast],
  );

  const openFloating = useCallback(async () => {
    const result = await openFloatingAssistant();
    showToast(result.message, result.ok ? "ok" : "error");
    if (result.ok) setSettingsOpen(false);
  }, [showToast]);

  const testVoice = useCallback(() => {
    speakText(
      `Hola, soy ${settingsRef.current.assistantName}. Esta es mi voz con velocidad ${settingsRef.current.rate.toFixed(2)} y tono ${settingsRef.current.pitch.toFixed(2)}. ¿Hablamos?`,
    );
  }, [speakText]);

  /* --------------------------- recognizers --------------------------- */
  const startDictation = useCallback(() => {
    if (dictating) {
      recognizerRef.current?.stop();
      setDictating(false);
      setInterim("");
      return;
    }
    if (!hasRecognition()) {
      showToast("Tu navegador no soporta dictado. Escribe en el chat.", "error");
      return;
    }
    const recognizer = createRecognizer({
      lang: settingsRef.current.listenLang,
      onTranscript: (finalText, interimText) => {
        setInterim(interimText);
        if (finalText) setDraft((current) => `${current}${current ? " " : ""}${finalText}`.trim());
      },
      onEnd: () => {
        setDictating(false);
        setInterim("");
      },
      onError: (code) => {
        setDictating(false);
        if (code === "not-allowed" || code === "service-not-allowed") showToast("Permite el micrófono para dictar.", "error");
      },
    });
    recognizerRef.current = recognizer;
    if (recognizer?.start()) {
      setDictating(true);
      showToast("Te escucho…", "info");
    } else {
      showToast("No pude activar el micrófono.", "error");
    }
  }, [dictating, showToast]);

  const startVoiceListening = useCallback(() => {
    if (!hasRecognition()) {
      showToast("Este navegador no permite dictado. Escribe en el chat.", "error");
      return;
    }
    recognizerRef.current?.stop();
    voiceDraftRef.current = "";
    setVoiceListening(true);
    setVoiceTranscript("");
    setVoiceCaption("Te escucho…");
    const recognizer = createRecognizer({
      lang: settingsRef.current.listenLang,
      continuous: false,
      onTranscript: (finalText, interimText) => {
        if (interimText) setVoiceCaption(interimText);
        if (finalText) {
          voiceDraftRef.current = `${voiceDraftRef.current} ${finalText}`.trim();
          setVoiceTranscript(voiceDraftRef.current);
          setVoiceCaption(finalText);
        }
      },
      onEnd: () => {
        setVoiceListening(false);
        const text = voiceDraftRef.current.trim();
        if (!text) {
          setVoiceCaption("No te escuché. Toca el micrófono y vuelve a intentar.");
          return;
        }
        if (autoSendVoiceRef.current && sendRef.current) {
          void sendRef.current({ text });
        }
      },
      onError: () => {
        setVoiceListening(false);
        setVoiceCaption("No pude acceder al micrófono. Revisa los permisos.");
      },
    });
    recognizerRef.current = recognizer;
    if (recognizer?.start()) {
      setVoiceListening(true);
      setVoiceCaption("Te escucho…");
    } else {
      setVoiceListening(false);
      showToast("No pude activar el micrófono.", "error");
    }
  }, [showToast]);

  voiceStartRef.current = startVoiceListening;

  const toggleVoiceListening = useCallback(() => {
    if (voiceListening) {
      recognizerRef.current?.stop();
      setVoiceListening(false);
      return;
    }
    startVoiceListening();
  }, [startVoiceListening, voiceListening]);

  const closeVoice = useCallback(() => {
    recognizerRef.current?.stop();
    setVoiceListening(false);
    setVoiceOpen(false);
    stopSpeakingNow();
  }, [stopSpeakingNow]);

  const openVoice = useCallback(() => {
    setSettingsOpen(false);
    setVoiceOpen(true);
    setVoiceCaption(
      hasRecognition() ? "Toca el micrófono y habla. Te escucho y respondo en voz alta." : "Sin dictado disponible: escribe y te responderé en voz alta.",
    );
  }, []);

  /* ------------------------------ export ----------------------------- */
  const exportAll = useCallback(() => {
    const blob = new Blob(
      [JSON.stringify({ exportedAt: new Date().toISOString(), settings, conversations, memories, messages }, null, 2)],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "capri-respaldo-completo.json";
    anchor.click();
    URL.revokeObjectURL(url);
    showToast("Respaldo exportado", "ok");
  }, [conversations, memories, messages, settings, showToast]);

  const exportConversation = useCallback(() => {
    if (!messages.length) {
      showToast("No hay mensajes que exportar.", "info");
      return;
    }
    const title = conversations.find((conversation) => conversation.id === activeIdRef.current)?.title ?? "Chat";
    const markdown = [
      `# ${title}`,
      "",
      ...messages.map(
        (message) =>
          `**${message.role === "user" ? "Tú" : settingsRef.current.assistantName}** · ${new Date(message.createdAt).toLocaleString("es")}\n\n${message.content}\n`,
      ),
    ].join("\n");
    const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `capri-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40) || "chat"}.md`;
    anchor.click();
    URL.revokeObjectURL(url);
    showToast("Chat exportado", "ok");
  }, [conversations, messages, showToast]);

  const copyMessage = useCallback(
    (message: ChatMessage) => {
      void navigator.clipboard
        .writeText(message.content)
        .then(() => showToast("Copiado", "ok"))
        .catch(() => showToast("No pude copiar.", "error"));
    },
    [showToast],
  );

  const activeConversation = conversations.find((conversation) => conversation.id === activeId);
  const companionEmotion: Emotion =
    voiceListening || dictating
      ? "listening"
      : speakingId
        ? "speaking"
        : busy
          ? firstChunk
            ? "speaking"
            : "thinking"
          : happy
            ? "happy"
            : settings.autoEmotion
              ? reaction
              : "idle";
  const companionMood: Mood = companionEmotion;
  const lastAssistantId = useMemo(() => [...messages].reverse().find((message) => message.role === "assistant")?.id ?? null, [messages]);
  const bg = settings.background;

  return (
    <div className="capri-root">
      <div className="bg-scene" aria-hidden="true">
        {bg.imageUrl && (
          <div className="bg-image" style={{ backgroundImage: `url(${bg.imageUrl})`, opacity: bg.imageOpacity, filter: `blur(${bg.blur}px)` }} />
        )}
        {!bg.imageUrl && bg.css && <div className="bg-image" style={{ background: bg.css, opacity: 1, filter: `blur(${bg.blur}px)` }} />}
        <div className="bg-dim" />
        <div className="bg-grid" />
      </div>

      <div className="layout">
        <Sidebar
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          conversations={conversations}
          activeId={activeId}
          memoryCount={memories.length}
          settings={settings}
          onSelect={(id) => void selectConversation(id)}
          onNew={newChat}
          onRename={(id, value) => void renameConversation(id, value)}
          onDelete={(id) => void removeConversation(id)}
          onPin={(id) => void togglePin(id)}
          onOpenSettings={() => {
            setSidebarOpen(false);
            openSettings("general");
          }}
          onOpenStudio={() => {
            setSidebarOpen(false);
            setStudioTab("personaje");
            setStudioOpen(true);
          }}
          onOpenPerformance={() => {
            setSidebarOpen(false);
            openSettings("rendimiento");
          }}
          onOpenVoice={openVoice}
          onOpenMemory={() => {
            setSidebarOpen(false);
            openSettings("memoria");
          }}
          onExport={exportConversation}
        />

        <main className="main">
          <header className="topbar">
            <button type="button" className="icon-btn mobile-only" onClick={() => setSidebarOpen(true)} aria-label="Abrir menú">
              <Icon name="menu" size={19} />
            </button>
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-[0.9rem] font-semibold leading-tight">{activeConversation?.title || "Nuevo chat"}</h1>
              <p className="mt-0.5 flex items-center gap-1.5 text-[0.68rem] text-[var(--muted)]">
                <span className={`h-1.5 w-1.5 rounded-full ${busy ? "bg-[var(--accent)]" : "bg-emerald-400"}`} />
                {busy ? (firstChunk ? `${settings.assistantName} respondiendo…` : `${settings.assistantName} pensando…`) : `${providerLabel} · ${modelLabel}`}
              </p>
            </div>
            <button type="button" className="icon-btn" onClick={() => { setStudioTab("personaje"); setStudioOpen(true); }} aria-label="Estudio de Capri" title="Personalizar a Capri">
              <Icon name="star" size={18} />
            </button>
            <button type="button" className="btn sm" onClick={() => openSettings("apis")} title="Cambiar modelo o API">
              <Icon name="device" size={14} />
              <span className="hidden sm:inline">{providerLabel}</span>
            </button>
            <button type="button" className="icon-btn" onClick={() => openSettings("memoria")} aria-label="Memoria" style={{ position: "relative" }}>
              <Icon name="brain" size={18} />
              {memories.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-[16px] min-w-[16px] place-items-center rounded-full px-1 text-[0.58rem] font-bold" style={{ background: "var(--accent)", color: "#04201d" }}>
                  {memories.length > 99 ? "99+" : memories.length}
                </span>
              )}
            </button>
            <button type="button" className="icon-btn" onClick={() => openSettings("general")} aria-label="Ajustes">
              <Icon name="settings" size={18} />
            </button>
          </header>

          <div className="chat-area">
            {dbError && (
              <div className="mx-3 mt-2 flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-[0.73rem] text-rose-300">
                <Icon name="shield" size={14} />
                <span className="flex-1">No pude conectar con la base de datos.</span>
                <button type="button" className="btn sm" onClick={() => void refreshState(activeId)}>
                  Reintentar
                </button>
              </div>
            )}

            {loadingState && !messages.length ? (
              <div className="hero">
                <CharacterAvatar character={settings.character} customImage={settings.customCharacter} imageOverride={expressionImage(settings, "thinking")} size={110} mood="idle" />
                <p className="hero-sub">Despertando a {settings.assistantName}…</p>
              </div>
            ) : messages.length === 0 ? (
              <div className="hero">
                {settings.characterVisible ? (
                  <CharacterAvatar
                    character={settings.character}
                    customImage={settings.customCharacter}
                    imageOverride={expressionImage(settings, "happy")}
                    size={Math.round(80 * settings.characterSize + 30)}
                    mood="happy"
                    still={settings.reduceMotion}
                  />
                ) : (
                  <div className="grid h-14 w-14 place-items-center rounded-2xl" style={{ background: "var(--accent)", color: "#04201d" }}>
                    <Icon name="sparkles" size={26} />
                  </div>
                )}
                <h2 className="hero-title">Hola, soy {settings.assistantName}.</h2>
                <p className="hero-sub">
                  Pregunta, crea, organiza y trabaja con archivos. Tengo memoria entre chats, entiendo tu voz y puedo responder en voz alta.
                </p>
                <div className="suggestion-grid">
                  {SUGGESTIONS.map((suggestion) => (
                    <button key={suggestion.title} type="button" className="suggestion" onClick={() => void runChat({ text: suggestion.prompt })}>
                      <Icon name={suggestion.icon} size={16} className="mt-0.5 text-[var(--accent)]" />
                      <span className="min-w-0">
                        <b>{suggestion.title}</b>
                        <span>{suggestion.hint}</span>
                      </span>
                    </button>
                  ))}
                </div>
                <div className="chip-row justify-center">
                  <span className="chip">
                    <Icon name="brain" size={12} /> {memories.length} recuerdos
                  </span>
                  <span className="chip">
                    <Icon name="wave" size={12} /> {speechAvailable ? "voz lista" : "voz de salida"}
                  </span>
                  <span className="chip">
                    <Icon name="device" size={12} /> {providerLabel}
                  </span>
                </div>
              </div>
            ) : (
              <div
                className="messages-scroll"
                ref={scrollRef}
                onScroll={(event) => {
                  const element = event.currentTarget;
                  setAutoScroll(element.scrollHeight - element.scrollTop - element.clientHeight < 140);
                }}
              >
                <div className="messages" style={{ gap: settings.spacious ? 26 : 18 }}>
                  {messages.map((message) => {
                    const isUser = message.role === "user";
                    const isStreaming = streamingId === message.id;
                    return (
                      <div key={message.id} className={`msg ${isUser ? "user" : ""}`}>
                        {!isUser && (
                          <div className="msg-avatar">
                            <CharacterAvatar
                              character={settings.character}
                              customImage={settings.customCharacter}
                              imageOverride={expressionImage(settings, isStreaming ? "speaking" : message.emotion ?? "idle")}
                              size={isStreaming ? 30 : 28}
                              mood="idle"
                              still={settings.reduceMotion}
                            />
                          </div>
                        )}
                        <div className={`bubble ${isUser ? "user" : "assistant"}`}>
                          {message.attachments.length > 0 && (
                            <div className="mb-2 flex flex-wrap gap-1.5">
                              {message.attachments.map((attachment) =>
                                attachment.kind === "image" && attachment.dataUrl ? (
                                  // eslint-disable-next-line @next/next/no-img-element
                                  <img key={attachment.id} src={attachment.dataUrl} alt={attachment.name} className="max-h-44 rounded-lg border border-[var(--line)] object-cover" />
                                ) : (
                                  <span key={attachment.id} className="attach">
                                    <Icon name="book" size={13} />
                                    <span className="attach-name">{attachment.name}</span>
                                    <span className="text-[0.6rem] text-[var(--muted)]">{formatBytes(attachment.size)}</span>
                                  </span>
                                ),
                              )}
                            </div>
                          )}

                          {isUser ? (
                            <p style={{ margin: 0, whiteSpace: "pre-wrap" }}>{message.content}</p>
                          ) : message.content ? (
                            <>
                              <Markdown text={message.content} />
                              {isStreaming && <span className="caret" />}
                            </>
                          ) : (
                            <span className="typing-dots" aria-label="Escribiendo">
                              <span />
                              <span style={{ animationDelay: "0.15s" }} />
                              <span style={{ animationDelay: "0.3s" }} />
                            </span>
                          )}

                          <div className="msg-meta">
                            <span>{relativeTime(message.createdAt)}</span>
                            {!isUser && message.skill && <span className="tag">{SKILL_LABELS[message.skill] ?? message.skill}</span>}
                            {!isUser && message.provider && <span className="tag">{message.provider}</span>}
                            {message.memoriesUsed.slice(0, 2).map((memory, index) => (
                              <span key={`${message.id}-m-${index}`} className="tag mem" title={memory}>
                                🧠 {memory}
                              </span>
                            ))}
                          </div>

                          {!isUser && message.content && !isStreaming && (
                            <div className="msg-actions">
                              <button type="button" className="msg-action" onClick={() => copyMessage(message)}>
                                <Icon name="copy" size={12} /> Copiar
                              </button>
                              <button
                                type="button"
                                className="msg-action"
                                onClick={() => (speakingId === message.id ? stopSpeakingNow() : speakText(message.content, message.id))}
                              >
                                <Icon name={speakingId === message.id ? "stop" : "volume"} size={12} />
                                {speakingId === message.id ? "Detener" : "Escuchar"}
                              </button>
                              <button type="button" className="msg-action" onClick={() => void addMemory(message.content.replace(/\s+/g, " ").slice(0, 200))}>
                                <Icon name="brain" size={12} /> Recordar
                              </button>
                              {message.id === lastAssistantId && !busy && (
                                <button type="button" className="msg-action" onClick={() => void runChat({ mode: "regenerate" })}>
                                  <Icon name="refresh" size={12} /> Regenerar
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                        {isUser && <div className="msg-user-avatar">{userInitial}</div>}
                      </div>
                    );
                  })}

                  {pending && !streamingId && (
                    <div className="msg">
                      <div className="msg-avatar">
                        <CharacterAvatar character={settings.character} customImage={settings.customCharacter} imageOverride={expressionImage(settings, "thinking")} size={28} mood="idle" />
                      </div>
                      <div className="bubble assistant">
                        <span className="typing-dots">
                          <span />
                          <span style={{ animationDelay: "0.15s" }} />
                          <span style={{ animationDelay: "0.3s" }} />
                        </span>
                        <span className="ml-2 text-[0.7rem] text-[var(--muted)]">{settings.assistantName} está pensando…</span>
                      </div>
                    </div>
                  )}
                  <div ref={bottomRef} />
                </div>
              </div>
            )}

            {settings.characterVisible && (
              <FloatingCharacter
                character={settings.character}
                image={expressionImage(settings, companionEmotion)}
                mood={companionEmotion}
                assistantName={settings.assistantName}
                size={settings.characterSize}
                physics={settings.characterPhysics && !settings.reduceMotion && !lowPower}
                seat={settings.characterSeat}
                reactions={settings.characterReactions}
                petMessage={settings.characterPetMessage}
                allowFloat={settings.floatingAssistant}
                onAction={(prompt) => void runChat({ text: prompt })}
                onVoice={openVoice}
                onFloat={() => void openFloating()}
                onOpenStudio={() => {
                  setStudioTab("personaje");
                  setStudioOpen(true);
                }}
                onPet={() => {
                  setReaction("happy");
                  setHappy(true);
                  if (happyTimer.current) window.clearTimeout(happyTimer.current);
                  happyTimer.current = window.setTimeout(() => setHappy(false), 2000);
                }}
                onSeatChange={(nextSeat) => {
                  changeSettings({ characterSeat: nextSeat });
                }}
              />
            )}

            {!autoScroll && messages.length > 0 && (
              <button
                type="button"
                className="icon-btn"
                onClick={() => {
                  setAutoScroll(true);
                  if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
                }}
                aria-label="Ir al final"
                style={{ position: "absolute", bottom: 12, right: 16, zIndex: 16, background: "var(--panel-solid)", border: "1px solid var(--line)" }}
              >
                <Icon name="chevron" size={17} />
              </button>
            )}
          </div>

          <Composer
            value={draft}
            onChange={setDraft}
            onSend={() => void runChat({ text: draft })}
            onStop={stopResponse}
            busy={busy}
            attachments={attachments}
            onAddFiles={(files) => void addFiles(files)}
            onRemoveAttachment={(id) => setAttachments((current) => current.filter((attachment) => attachment.id !== id))}
            dictating={dictating}
            onToggleDictation={startDictation}
            onOpenVoice={openVoice}
            onOpenSettings={() => openSettings("general")}
            interim={interim}
            assistantName={settings.assistantName}
            autoSpeak={settings.autoSpeak}
            onToggleAutoSpeak={() => changeSettings({ autoSpeak: !settings.autoSpeak })}
            speechAvailable={speechAvailable}
            providerLabel={providerLabel}
            modelLabel={modelLabel}
            onOpenProviders={() => openSettings("apis")}
          />
        </main>
      </div>

      <CharacterStudio
        open={studioOpen}
        onClose={() => setStudioOpen(false)}
        settings={settings}
        memories={memories}
        voices={voices}
        onChange={changeSettings}
        onSave={() => void saveSettingsNow()}
        onUploadExpression={(emotion, file) => void uploadExpression(emotion, file)}
        onClearExpression={(emotion) => clearExpression(emotion)}
        onTestVoice={testVoice}
        onOpenFloating={() => void openFloating()}
        onDeleteMemory={(id) => void deleteMemoryById(id)}
      />

      <SettingsModal
        key={`${settingsTab}-${settingsOpen ? "open" : "closed"}`}
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        initialTab={settingsTab}
        settings={settings}
        voices={voices}
        memories={memories}
        onChange={changeSettings}
        onReset={() => void resetSettings()}
        onSave={() => void saveSettingsNow()}
        onUploadCharacter={(file) => void uploadCharacter(file)}
        onUploadExpression={(emotion, file) => void uploadExpression(emotion, file)}
        onClearExpression={(emotion) => clearExpression(emotion)}
        onOpenFloating={() => void openFloating()}
        onExportAll={exportAll}
        onTestVoice={testVoice}
        onAddMemory={(content) => void addMemory(content)}
        onDeleteMemory={(id) => void deleteMemoryById(id)}
        onForgetAll={() => void forgetAll()}
      />

      <VoiceOverlay
        open={voiceOpen}
        onClose={closeVoice}
        listening={voiceListening}
        speaking={Boolean(speakingId)}
        interim={voiceTranscript || interim}
        caption={voiceCaption}
        assistantName={settings.assistantName}
        character={settings.character}
        customCharacter={settings.customCharacter}
        reduceMotion={settings.reduceMotion}
        speechAvailable={speechAvailable}
        liveVoice={settings.liveVoice}
        onToggleLive={() => changeSettings({ liveVoice: !settings.liveVoice })}
        onTalk={toggleVoiceListening}
        onSend={(text) => {
          const value = text || voiceTranscript.trim();
          if (value) {
            setVoiceTranscript("");
            void runChat({ text: value });
          }
        }}
      />

      <nav className="mobile-nav" aria-label="Navegación principal">
        {([
          { id: "chat", label: "Chat", icon: "history" as IconName, action: () => setSidebarOpen(true) },
          { id: "studio", label: "Estudio", icon: "star" as IconName, action: () => { setStudioTab("personaje"); setStudioOpen(true); } },
          { id: "voice", label: "Voz", icon: "wave" as IconName, action: openVoice },
          { id: "settings", label: "Ajustes", icon: "settings" as IconName, action: () => openSettings("rendimiento") },
        ]).map((item) => (
          <button key={item.id} type="button" onClick={item.action} aria-label={item.label}>
            <Icon name={item.icon} size={18} />
            {item.label}
          </button>
        ))}
      </nav>

      <Toast toast={toast} />
    </div>
  );
}
