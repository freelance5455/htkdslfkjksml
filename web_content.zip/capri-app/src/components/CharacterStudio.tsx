"use client";

import { useEffect, useRef, useState } from "react";
import { CharacterAvatar } from "@/components/CharacterAvatar";
import { Icon } from "@/components/icons";
import { relativeTime } from "@/lib/text";
import {
  ACCENTS,
  CHARACTER_STYLES,
  EMOTIONS,
  THEMES,
  VOICE_PRESETS,
  expressionImage,
  type CharacterStyle,
  type Emotion,
  type Memory,
  type Settings,
  type ThemeId,
} from "@/lib/types";

type Props = {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  memories: Memory[];
  voices: SpeechSynthesisVoice[];
  onChange: (patch: Partial<Settings>) => void;
  onSave: () => void;
  onUploadExpression: (emotion: Emotion, file: File) => void;
  onClearExpression: (emotion: Emotion) => void;
  onTestVoice: () => void;
  onOpenFloating: () => void;
  onDeleteMemory: (id: string) => void;
};

type Section = "personaje" | "expresiones" | "voz" | "personalidad" | "escena" | "asistente";

const PRESETS: { id: string; name: string; description: string; patch: Partial<Settings> }[] = [
  {
    id: "capri-clasica",
    name: "Capri clásica",
    description: "Cercana, curiosa y con voz dulce",
    patch: { tone: "cercano", accent: "#2dd4bf", theme: "midnight", voicePreset: "dulce", rate: 1.02, pitch: 1.18, characterSize: 0.9 },
  },
  {
    id: "modo-anime",
    name: "Modo anime",
    description: "Energía kawaii y reacciones exageradas",
    patch: { tone: "anime", accent: "#f472b6", theme: "sakura", voicePreset: "energia", rate: 1.14, pitch: 1.3, characterSize: 1.05 },
  },
  {
    id: "mentora",
    name: "Mentora seria",
    description: "Profesional, directa y ordenada",
    patch: { tone: "profesional", accent: "#3b82f6", theme: "graphite", voicePreset: "narrador", rate: 0.98, pitch: 0.92, characterSize: 0.82 },
  },
  {
    id: "zen",
    name: "Zen",
    description: "Calma, pausada y con fondo suave",
    patch: { tone: "cercano", accent: "#22c55e", theme: "forest", voicePreset: "calma", rate: 0.92, pitch: 1.02, characterSize: 0.78 },
  },
  {
    id: "movil-ligera",
    name: "Móvil ligero",
    description: "Bajo consumo para teléfonos modestos",
    patch: { performanceMode: "low", characterPhysics: false, reduceMotion: true, characterSeat: "composer", characterSize: 0.72, streamChunks: false },
  },
  {
    id: "multitarea",
    name: "Multitarea",
    description: "Flotando y lista para usar en pantalla",
    patch: { characterSeat: "float", floatingAssistant: true, characterPhysics: true, autoSpeak: false, liveVoice: false },
  },
];

export function CharacterStudio({
  open,
  onClose,
  settings,
  memories,
  voices,
  onChange,
  onSave,
  onUploadExpression,
  onClearExpression,
  onTestVoice,
  onOpenFloating,
  onDeleteMemory,
}: Props) {
  const [section, setSection] = useState<Section>("personaje");
  const [preview, setPreview] = useState<Emotion>("happy");
  const [petCount, setPetCount] = useState(0);
  const [custom, setCustom] = useState("");
  const expressionRef = useRef<HTMLInputElement | null>(null);
  const [expressionTarget, setExpressionTarget] = useState<Emotion>("happy");

  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;

  const sections: { id: Section; label: string; icon: "star" | "sparkles" | "volume" | "smile" | "eye" | "globe" }[] = [
    { id: "personaje", label: "Personaje", icon: "star" },
    { id: "expresiones", label: "Expresiones", icon: "sparkles" },
    { id: "voz", label: "Voz", icon: "volume" },
    { id: "personalidad", label: "Personalidad", icon: "smile" },
    { id: "escena", label: "Escena", icon: "eye" },
    { id: "asistente", label: "Asistente", icon: "globe" },
  ];

  const petTalk = [
    "¡Jeje! ¿Me has llamado?",
    "Me encanta estar aquí contigo.",
    "¿Quieres que organice tu día?",
    "Tócame otra vez y me pongo contenta.",
  ];

  return (
    <>
      <div className="overlay" onClick={onClose} aria-hidden="true" />
      <section className="modal" role="dialog" aria-modal="true" aria-label="Estudio de Capri" style={{ maxWidth: 980 }}>
        <div className="modal-head">
          <div className="brand-logo" style={{ width: 30, height: 30, borderRadius: 9 }}>
            <Icon name="star" size={16} />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-[0.98rem] font-semibold">Estudio de {settings.assistantName}</h2>
            <p className="text-[0.68rem] text-[var(--muted)]">Personaliza el personaje, su voz, sus reacciones y cómo aparece</p>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Cerrar estudio">
            <Icon name="close" size={18} />
          </button>
        </div>

        <div className="tabs">
          {sections.map((item) => (
            <button key={item.id} type="button" className={`tab ${section === item.id ? "active" : ""}`} onClick={() => setSection(item.id)}>
              <Icon name={item.icon} size={14} />
              {item.label}
            </button>
          ))}
        </div>

        <div className="modal-body">
          <div className="studio-grid">
            <div className="studio-preview">
              <p className="text-[0.7rem] uppercase tracking-[0.1em] text-[var(--muted)]">Vista previa</p>
              <div className="studio-stage">
                <button
                  type="button"
                  className="character-btn"
                  onClick={() => {
                    setPreview("happy");
                    setPetCount((value) => value + 1);
                  }}
                  aria-label={`Probar reacción de ${settings.assistantName}`}
                >
                  <CharacterAvatar
                    character={settings.character}
                    customImage={settings.customCharacter}
                    imageOverride={expressionImage(settings, preview)}
                    mood={preview}
                    size={Math.round(96 * settings.characterSize + 24)}
                    still={settings.reduceMotion}
                  />
                </button>
              </div>
              <p className="text-center text-[0.74rem] font-medium">{settings.assistantName}</p>
              <p className="text-center text-[0.66rem] text-[var(--muted)]">
                {petCount > 0 ? petTalk[petCount % petTalk.length] : "Toca el personaje para probar su reacción"}
              </p>
              <div className="studio-expression-row">
                {(["idle", "happy", "excited", "thinking", "speaking", "listening", "annoyed", "sad", "surprised", "singing"] as Emotion[]).map((emotion) => (
                  <button
                    key={emotion}
                    type="button"
                    className={`chip ${preview === emotion ? "active" : ""}`}
                    onClick={() => setPreview(emotion)}
                    style={{ fontSize: "0.64rem", padding: "3px 7px" }}
                  >
                    {emotion}
                  </button>
                ))}
              </div>
              <div className="w-full border-t border-[var(--line)] pt-2">
                <p className="mb-1 text-[0.62rem] uppercase tracking-[0.1em] text-[var(--muted)]">Presets completos</p>
                <div className="grid gap-1.5">
                  {PRESETS.map((preset) => (
                    <button key={preset.id} type="button" className="studio-preset" onClick={() => onChange(preset.patch)}>
                      <b>{preset.name}</b>
                      <span>{preset.description}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="min-w-0">
              {section === "personaje" && (
                <>
                  <div className="section">
                    <p className="section-title">Nombre</p>
                    <input className="field" value={settings.assistantName} maxLength={24} onChange={(event) => onChange({ assistantName: event.target.value })} placeholder="Capri" />
                    <p className="hint mt-1">Aparece en el chat, el personaje, la voz y la ventana flotante.</p>
                  </div>

                  <div className="section">
                    <p className="section-title">Personaje</p>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      {CHARACTER_STYLES.map((style) => (
                        <button
                          key={style.id}
                          type="button"
                          className={`card-option ${settings.character === style.id ? "active" : ""}`}
                          onClick={() => onChange({ character: style.id as CharacterStyle })}
                        >
                          <CharacterAvatar
                            character={style.id}
                            customImage={settings.customCharacter}
                            imageOverride={style.id === "capri" ? undefined : style.id === "custom" ? settings.customCharacter : null}
                            size={46}
                            mood="happy"
                            still
                          />
                          <span className="name">{style.name}</span>
                        </button>
                      ))}
                    </div>
                    <p className="hint mt-2">Sube un dibujo o foto propia desde Ajustes → Personaje → Mi imagen.</p>
                  </div>

                  <div className="section">
                    <p className="section-title">Cómo se comporta</p>
                    <div className="row">
                      <div>
                        <p className="row-title">Tamaño</p>
                        <p className="row-desc">Escala del personaje en el chat y el estudio.</p>
                      </div>
                      <span className="tag">{Math.round(settings.characterSize * 100)}%</span>
                    </div>
                    <input type="range" min={0.5} max={1.8} step={0.05} value={settings.characterSize} onChange={(event) => onChange({ characterSize: Number(event.target.value) })} aria-label="Tamaño del personaje" />
                    <div className="mt-2">
                      <p className="mb-1 text-[0.74rem] text-[var(--muted)]">Dónde aparece</p>
                      <div className="chip-row">
                        {[
                          { id: "composer", label: "Sentada en la barra" },
                          { id: "float", label: "Flotando por el chat" },
                          { id: "corner", label: "Esquina" },
                        ].map((option) => (
                          <button key={option.id} type="button" className={`chip ${settings.characterSeat === option.id ? "active" : ""}`} onClick={() => onChange({ characterSeat: option.id as Settings["characterSeat"] })}>
                            {option.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="mt-1">
                      <ToggleRow title="Física y paseo" description="Se mueve solo, se deja arrastrar y cae suavemente." checked={settings.characterPhysics} onChange={() => onChange({ characterPhysics: !settings.characterPhysics })} />
                      <ToggleRow title="Se puede sentar" description="Suéltalo sobre la barra del chat y se queda ahí." checked={settings.characterSit} onChange={() => onChange({ characterSit: !settings.characterSit })} />
                      <ToggleRow title="Reacciones al tocarlo" description="Al tocarlo te habla; doble toque abre este estudio." checked={settings.characterReactions} onChange={() => onChange({ characterReactions: !settings.characterReactions })} />
                      <ToggleRow title="Mostrar personaje" description="Si lo apagas, solo verás el chat." checked={settings.characterVisible} onChange={() => onChange({ characterVisible: !settings.characterVisible })} />
                    </div>
                    <label className="mt-2 block text-[0.7rem] text-[var(--muted)]">Frase al saludar</label>
                    <input className="field mt-1" value={settings.characterGreeting} maxLength={200} onChange={(event) => onChange({ characterGreeting: event.target.value })} />
                    <label className="mt-2 block text-[0.7rem] text-[var(--muted)]">Frase al acariciarlo</label>
                    <input className="field mt-1" value={settings.characterPetMessage} maxLength={200} onChange={(event) => onChange({ characterPetMessage: event.target.value })} />
                  </div>
                </>
              )}

              {section === "expresiones" && (
                <div className="section">
                  <p className="section-title">Imagen para cada emoción</p>
                  <p className="hint mb-2">
                    Sustituye cada expresión por tu propia imagen. La IA elige la emoción de cada respuesta y el personaje cambia solo.
                  </p>
                  <div className="expression-grid">
                    {EMOTIONS.map((emotion) => {
                      const override = settings.expressionImages?.[emotion.id] ?? null;
                      return (
                        <div key={emotion.id} className={`expression-card ${override ? "customized" : ""}`}>
                          {override && <span className="badge-dot" />}
                          <div className="expr-stage">
                            <CharacterAvatar
                              character={settings.character}
                              customImage={settings.customCharacter}
                              imageOverride={expressionImage(settings, emotion.id)}
                              mood={emotion.id}
                              size={58}
                              still
                            />
                          </div>
                          <span className="expr-label">{emotion.name}</span>
                          <span className="expr-hint">{emotion.hint}</span>
                          <div className="expr-actions">
                            <button
                              type="button"
                              className="btn sm"
                              onClick={() => {
                                setExpressionTarget(emotion.id);
                                expressionRef.current?.click();
                              }}
                            >
                              <Icon name="upload" size={11} /> Subir
                            </button>
                            {override && (
                              <button type="button" className="mini-icon" onClick={() => onClearExpression(emotion.id)} aria-label={`Restaurar ${emotion.name}`}>
                                <Icon name="refresh" size={12} />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <input
                    ref={expressionRef}
                    type="file"
                    accept="image/*"
                    hidden
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      if (file) onUploadExpression(expressionTarget, file);
                      event.target.value = "";
                    }}
                  />
                  <div className="mt-2">
                    <ToggleRow title="Reacciones automáticas" description="La IA escoge la emoción de cada respuesta." checked={settings.autoEmotion} onChange={() => onChange({ autoEmotion: !settings.autoEmotion })} />
                  </div>
                </div>
              )}

              {section === "voz" && (
                <>
                  <div className="section">
                    <p className="section-title">Voz</p>
                    <div className="chip-row">
                      {VOICE_PRESETS.map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          className={`chip ${settings.voicePreset === preset.id ? "active" : ""}`}
                          onClick={() => onChange({ voicePreset: preset.id, rate: preset.rate, pitch: preset.pitch, volume: preset.volume })}
                          title={preset.description}
                        >
                          {preset.name}
                        </button>
                      ))}
                    </div>
                    <label className="mt-2 block text-[0.7rem] text-[var(--muted)]">Voz del sistema</label>
                    <select className="field mt-1" value={settings.voiceURI ?? ""} onChange={(event) => onChange({ voiceURI: event.target.value || null })}>
                      <option value="">Automática (español)</option>
                      {voices.map((voice) => (
                        <option key={voice.voiceURI} value={voice.voiceURI}>
                          {voice.name} · {voice.lang}
                        </option>
                      ))}
                    </select>
                    <SliderRow label="Velocidad" value={settings.rate} min={0.5} max={1.8} step={0.05} onChange={(value) => onChange({ rate: value })} format={(value) => `${value.toFixed(2)}×`} />
                    <SliderRow label="Tono" value={settings.pitch} min={0.5} max={1.8} step={0.05} onChange={(value) => onChange({ pitch: value })} format={(value) => value.toFixed(2)} />
                    <SliderRow label="Volumen" value={settings.volume} min={0} max={1} step={0.05} onChange={(value) => onChange({ volume: value })} format={(value) => `${Math.round(value * 100)}%`} />
                    <button type="button" className="btn" onClick={onTestVoice}>
                      <Icon name="volume" size={14} /> Probar voz
                    </button>
                  </div>
                  <div className="section">
                    <p className="section-title">Conversación por voz</p>
                    <ToggleRow title="Leer las respuestas" description="Habla al terminar cada mensaje." checked={settings.autoSpeak} onChange={() => onChange({ autoSpeak: !settings.autoSpeak })} />
                    <ToggleRow title="Enviar al dejar de hablar" description="Dictado manos libres." checked={settings.autoSendVoice} onChange={() => onChange({ autoSendVoice: !settings.autoSendVoice })} />
                    <ToggleRow title="Manos libres continuo" description="Vuelve a escuchar después de responder." checked={settings.liveVoice} onChange={() => onChange({ liveVoice: !settings.liveVoice })} />
                    <ToggleRow title="Solo voz en la ventana flotante" description="El asistente externo usa micrófono y audio, sin teclado." checked={settings.floatingHotkey} onChange={() => onChange({ floatingHotkey: !settings.floatingHotkey })} />
                  </div>
                </>
              )}

              {section === "personalidad" && (
                <>
                  <div className="section">
                    <p className="section-title">Tono</p>
                    <div className="chip-row">
                      {(["cercano", "profesional", "divertido", "directo", "anime"] as const).map((tone) => (
                        <button key={tone} type="button" className={`chip ${settings.tone === tone ? "active" : ""}`} onClick={() => onChange({ tone })}>
                          {tone}
                        </button>
                      ))}
                    </div>
                    <label className="mt-2 block text-[0.7rem] text-[var(--muted)]">Tu nombre</label>
                    <input className="field mt-1" value={settings.userName} maxLength={32} onChange={(event) => onChange({ userName: event.target.value })} placeholder="¿Cómo te llamas?" />
                    <label className="mt-2 block text-[0.7rem] text-[var(--muted)]">Instrucciones personalizadas</label>
                    <textarea className="field mt-1 min-h-[70px]" value={settings.customInstructions} maxLength={800} onChange={(event) => onChange({ customInstructions: event.target.value })} placeholder="Respuestas breves, llámame por mi nombre, enfoque técnico…" />
                    <label className="mt-2 block text-[0.7rem] text-[var(--muted)]">Contexto extra para la IA</label>
                    <textarea className="field mt-1 min-h-[70px]" value={settings.systemPrompt} maxLength={4000} onChange={(event) => onChange({ systemPrompt: event.target.value })} placeholder="Trabajo en… / estudio… / prefiero ejemplos de…" />
                  </div>
                  <div className="section">
                    <p className="section-title">Memoria ({memories.length})</p>
                    <form
                      className="flex gap-2"
                      onSubmit={(event) => {
                        event.preventDefault();
                        if (custom.trim().length < 3) return;
                        onChange({ memoryEnabled: true });
                        setCustom("");
                      }}
                    >
                      <input className="field" value={custom} onChange={(event) => setCustom(event.target.value)} placeholder="Añade un recuerdo rápido…" aria-label="Recuerdo" />
                      <button type="submit" className="btn" disabled title="Guarda recuerdos desde Ajustes → Memoria">
                        <Icon name="plus" size={15} />
                      </button>
                    </form>
                    <div className="mt-2 max-h-[220px] overflow-y-auto">
                      {memories.slice(0, 12).map((memory) => (
                        <div key={memory.id} className="memory-item">
                          <div className="min-w-0 flex-1">
                            <span className="kind">{memory.kind}</span>
                            <p className="mt-1 text-[0.8rem] leading-snug">{memory.content}</p>
                            <p className="text-[0.62rem] text-[var(--muted)]">{relativeTime(memory.createdAt)}</p>
                          </div>
                          <button type="button" className="mini-icon" onClick={() => onDeleteMemory(memory.id)} aria-label="Borrar recuerdo">
                            <Icon name="trash" size={13} />
                          </button>
                        </div>
                      ))}
                      {!memories.length && <p className="hint">Aún no hay recuerdos. Dile «recuerda que…» en el chat.</p>}
                    </div>
                  </div>
                </>
              )}

              {section === "escena" && (
                <>
                  <div className="section">
                    <p className="section-title">Tema</p>
                    <div className="grid grid-cols-3 gap-2">
                      {THEMES.map((theme) => (
                        <button key={theme.id} type="button" className={`card-option ${settings.theme === theme.id ? "active" : ""}`} onClick={() => onChange({ theme: theme.id as ThemeId })}>
                          <span className="swatch" style={{ background: `linear-gradient(135deg, ${theme.swatch[0]}, ${theme.swatch[1]})` }} />
                          <span className="name">{theme.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="section">
                    <p className="section-title">Color de acento</p>
                    <div className="flex flex-wrap gap-2">
                      {ACCENTS.map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => onChange({ accent: color })}
                          aria-label={`Acento ${color}`}
                          style={{
                            width: 30,
                            height: 30,
                            borderRadius: 999,
                            background: color,
                            border: settings.accent === color ? "2px solid var(--text)" : "1px solid var(--line)",
                          }}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="section">
                    <p className="section-title">Fondo</p>
                    <div className="flex flex-wrap gap-2">
                      <button type="button" className="btn sm" onClick={() => onChange({ background: { ...settings.background, imageUrl: null, type: "gradient", css: "" } })}>
                        Sin fondo
                      </button>
                      <button type="button" className="btn sm" onClick={() => onChange({ theme: "light", background: { ...settings.background, imageUrl: null, css: "" } })}>
                        Modo claro
                      </button>
                    </div>
                    <SliderRow label="Oscurecer fondo" value={settings.background.dim} min={0} max={0.9} step={0.05} onChange={(value) => onChange({ background: { ...settings.background, dim: value } })} format={(value) => `${Math.round(value * 100)}%`} />
                  </div>
                </>
              )}

              {section === "asistente" && (
                <>
                  <div className="section">
                    <p className="section-title">Ventana flotante</p>
                    <p className="hint mb-2">
                      En Chrome o Edge de escritorio, Capri se abre en una ventana siempre visible por encima de otras aplicaciones, en modo solo voz.
                      En móvil los navegadores no permiten superponer ventanas sobre otras apps: usa el aviso de instalación y el micrófono.
                    </p>
                    <button type="button" className="btn primary w-full" onClick={onOpenFloating}>
                      <Icon name="globe" size={15} /> Usar en pantalla (solo voz)
                    </button>
                    <div className="mt-2">
                      <ToggleRow title="Permitir ventana flotante" description="Muestra la opción en el menú del personaje." checked={settings.floatingAssistant} onChange={() => onChange({ floatingAssistant: !settings.floatingAssistant })} />
                    </div>
                  </div>
                  <div className="section">
                    <p className="section-title">Rendimiento del dispositivo</p>
                    <div className="chip-row">
                      {(["auto", "low", "medium", "high"] as const).map((mode) => (
                        <button key={mode} type="button" className={`chip ${settings.performanceMode === mode ? "active" : ""}`} onClick={() => onChange({ performanceMode: mode })}>
                          {mode === "auto" ? "Automático" : mode === "low" ? "Ahorro" : mode === "medium" ? "Equilibrado" : "Máxima"}
                        </button>
                      ))}
                    </div>
                    <div className="mt-2">
                      <ToggleRow title="Física del personaje" description="Apágala para ahorrar batería." checked={settings.characterPhysics} onChange={() => onChange({ characterPhysics: !settings.characterPhysics })} />
                      <ToggleRow title="Reducir movimiento" description="Sin animaciones ni transiciones." checked={settings.reduceMotion} onChange={() => onChange({ reduceMotion: !settings.reduceMotion })} />
                      <ToggleRow title="Ahorro de datos" description="Sin streaming palabra por palabra." checked={settings.lowDataMode} onChange={() => onChange({ lowDataMode: !settings.lowDataMode })} />
                    </div>
                  </div>
                  <div className="section">
                    <p className="section-title">Accesibilidad</p>
                    <SliderRow label="Tamaño del texto" value={settings.fontScale} min={0.9} max={1.35} step={0.05} onChange={(value) => onChange({ fontScale: value })} format={(value) => `${Math.round(value * 100)}%`} />
                    <ToggleRow title="Alto contraste" description="Mejor legibilidad con poca luz." checked={settings.highContrast} onChange={() => onChange({ highContrast: !settings.highContrast })} />
                    <ToggleRow title="Mensajes compactos" description="Más contenido en pantalla." checked={settings.compactMessages} onChange={() => onChange({ compactMessages: !settings.compactMessages })} />
                    <ToggleRow title="Espaciado cómodo" description="Más aire entre mensajes." checked={settings.spacious} onChange={() => onChange({ spacious: !settings.spacious })} />
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="modal-foot">
          <button type="button" className="btn ghost" onClick={onClose}>
            Cerrar
          </button>
          <button type="button" className="btn primary" onClick={onSave}>
            <Icon name="check" size={15} /> Guardar
          </button>
        </div>
      </section>
    </>
  );
}

function ToggleRow({
  title,
  description,
  checked,
  onChange,
}: {
  title: string;
  description?: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <div className="row">
      <div className="min-w-0">
        <p className="row-title">{title}</p>
        {description && <p className="row-desc">{description}</p>}
      </div>
      <button type="button" role="switch" aria-checked={checked} aria-label={title} className={`switch ${checked ? "on" : ""}`} onClick={onChange} />
    </div>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  step,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
  format?: (value: number) => string;
}) {
  return (
    <div className="py-2">
      <div className="flex items-center justify-between">
        <span className="row-title">{label}</span>
        <span className="tag">{format ? format(value) : value}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} aria-label={label} className="mt-1" />
    </div>
  );
}
