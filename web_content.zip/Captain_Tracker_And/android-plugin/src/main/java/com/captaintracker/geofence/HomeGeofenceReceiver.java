package com.captaintracker.geofence;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;

public class HomeGeofenceReceiver extends BroadcastReceiver {
  private static final String CHANNEL="captain_home_alerts";
  @Override public void onReceive(Context context,Intent intent){
    GeofencingEvent event=GeofencingEvent.fromIntent(intent);
    if(event==null||event.hasError())return;
    int transition=event.getGeofenceTransition();
    if(transition!=Geofence.GEOFENCE_TRANSITION_ENTER&&transition!=Geofence.GEOFENCE_TRANSITION_EXIT)return;
    android.content.SharedPreferences prefs=context.getSharedPreferences("captain_geofence",0);
    if(!prefs.getBoolean("enabled",false))return;
    boolean activeShift=prefs.getBoolean("activeShift",false);
    // Do not prompt to start a shift if one is already open, or to close a shift if none is open.
    if(transition==Geofence.GEOFENCE_TRANSITION_EXIT && activeShift)return;
    if(transition==Geofence.GEOFENCE_TRANSITION_ENTER && !activeShift)return;
    String title,body;
    if(transition==Geofence.GEOFENCE_TRANSITION_EXIT){title="غادرت نطاق المنزل";body="لا تنسَ تسجيل قراءة عداد البداية وبدء الشيفت.";}
    else {title="وصلت إلى نطاق المنزل";body="لا تنسَ تسجيل قراءة عداد النهاية وإنهاء الشيفت.";}
    NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"تنبيهات المنزل والشيفت",NotificationManager.IMPORTANCE_HIGH));
    Intent open=context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
    PendingIntent content=open==null?null:PendingIntent.getActivity(context,transition,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    NotificationCompat.Builder notification=new NotificationCompat.Builder(context,CHANNEL).setSmallIcon(context.getApplicationInfo().icon).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true);
    if(content!=null)notification.setContentIntent(content);
    manager.notify(transition==Geofence.GEOFENCE_TRANSITION_EXIT?4101:4102,notification.build());
  }
}
