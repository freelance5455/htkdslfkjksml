package com.captaintracker.geofence;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.PendingIntent;
import android.os.Build;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;

/** Re-registers the persisted home fence after Android finishes booting. */
public class BootGeofenceReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
    android.content.SharedPreferences prefs = context.getSharedPreferences("captain_geofence", Context.MODE_PRIVATE);
    if (!prefs.getBoolean("enabled", false)) return;
    double lat = Double.longBitsToDouble(prefs.getLong("lat", Double.doubleToLongBits(999d)));
    double lng = Double.longBitsToDouble(prefs.getLong("lng", Double.doubleToLongBits(999d)));
    float radius = prefs.getFloat("radius", 300f);
    if (Math.abs(lat) > 90 || Math.abs(lng) > 180 || radius < 100 || radius > 1000) return;

    Geofence fence = new Geofence.Builder().setRequestId("captain-home")
      .setCircularRegion(lat, lng, radius)
      .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
      .setLoiteringDelay(30000).setExpirationDuration(Geofence.NEVER_EXPIRE).build();
    GeofencingRequest request = new GeofencingRequest.Builder()
      .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER).addGeofence(fence).build();
    Intent receiver = new Intent(context, HomeGeofenceReceiver.class);
    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
    if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_MUTABLE;
    PendingIntent pi = PendingIntent.getBroadcast(context, 9001, receiver, flags);
    GeofencingClient client = LocationServices.getGeofencingClient(context);
    try {
      client.addGeofences(request, pi).addOnFailureListener(error ->
        android.util.Log.e("CaptainTracker", "Could not restore home geofence after boot", error));
    } catch (SecurityException error) {
      android.util.Log.e("CaptainTracker", "Missing location permission after boot", error);
    }
  }
}
