package com.captaintracker.geofence;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.ContextCompat;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.location.*;
import com.google.android.gms.tasks.Task;
import java.util.Collections;

@CapacitorPlugin(name = "GeofenceManager", permissions = {
  @com.getcapacitor.annotation.Permission(alias = "location", strings = { Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }),
  @com.getcapacitor.annotation.Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
})
public class GeofenceManagerPlugin extends Plugin {
  private String pendingAction = "";
  private double pendingLat, pendingLng;
  private float pendingRadius;
  private FusedLocationProviderClient fused;
  private GeofencingClient geofencing;

  @PluginMethod public void getCurrentLocation(PluginCall call) {
    if (!hasForegroundLocation()) {
      pendingAction = "current";
      requestPermissionForAlias("location", call, "locationPermissionCallback");
      return;
    }
    readCurrentLocation(call);
  }

  private void readCurrentLocation(PluginCall call) {
    if (fused == null) fused = LocationServices.getFusedLocationProviderClient(getContext());
    try {
      fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
        .addOnSuccessListener(location -> {
          if (location == null) { call.reject("Current location is unavailable. Turn on GPS and try again."); return; }
          JSObject out = new JSObject(); out.put("latitude", location.getLatitude()); out.put("longitude", location.getLongitude()); call.resolve(out);
        }).addOnFailureListener(e -> call.reject(e.getMessage()));
    } catch (SecurityException e) { call.reject("Location permission denied", e); }
  }

  @PluginMethod public void enable(PluginCall call) {
    double lat = call.getDouble("latitude", 0d), lng = call.getDouble("longitude", 0d);
    float radius = (float) call.getDouble("radius", 300d);
    if (Math.abs(lat)>90 || Math.abs(lng)>180 || radius<100 || radius>1000) { call.reject("Invalid home coordinates or radius"); return; }
    if (!hasForegroundLocation()) {
      pendingAction="enable"; pendingLat=lat; pendingLng=lng; pendingRadius=radius;
      requestPermissionForAlias("location", call, "locationPermissionCallback");
      return;
    }
    if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
      getContext().getSharedPreferences("captain_geofence",0).edit().putLong("lat", Double.doubleToLongBits(lat)).putLong("lng", Double.doubleToLongBits(lng)).putFloat("radius",radius).apply();
      Intent settings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getContext().getPackageName()));
      getActivity().startActivity(settings);
      call.reject("Allow Location access all the time in Android App permissions, then return and tap Enable again."); return;
    }
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      pendingAction="notifications"; pendingLat=lat; pendingLng=lng; pendingRadius=radius;
      requestPermissionForAlias("notifications", call, "notificationPermissionCallback"); return;
    }
    registerGeofence(call,lat,lng,radius);
  }

  private void registerGeofence(PluginCall call,double lat,double lng,float radius) {
    if (geofencing == null) geofencing=LocationServices.getGeofencingClient(getContext());
    Geofence fence = new Geofence.Builder().setRequestId("captain-home")
      .setCircularRegion(lat,lng,radius).setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER|Geofence.GEOFENCE_TRANSITION_EXIT)
      .setLoiteringDelay(30000).setExpirationDuration(Geofence.NEVER_EXPIRE).build();
    GeofencingRequest request = new GeofencingRequest.Builder().setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER).addGeofence(fence).build();
    PendingIntent pi = getGeofencePendingIntent();
    try { geofencing.addGeofences(request,pi).addOnSuccessListener(v->{
      getContext().getSharedPreferences("captain_geofence",0).edit().putLong("lat",Double.doubleToLongBits(lat)).putLong("lng",Double.doubleToLongBits(lng)).putFloat("radius",radius).putBoolean("enabled",true).apply();
      JSObject out=new JSObject(); out.put("enabled",true); out.put("message","Home geofence active ("+(int)radius+" m). Background location and notifications are enabled."); call.resolve(out);
    }).addOnFailureListener(e->call.reject("Could not register home geofence: "+e.getMessage())); }
    catch(SecurityException e){call.reject("Background location permission is required",e);}
  }

  @PluginMethod public void setShiftState(PluginCall call) {
    boolean active = call.getBoolean("active", false);
    getContext().getSharedPreferences("captain_geofence",0).edit().putBoolean("activeShift",active).apply();
    call.resolve();
  }

  @PluginMethod public void disable(PluginCall call) {
    if(geofencing==null) geofencing=LocationServices.getGeofencingClient(getContext());
    geofencing.removeGeofences(getGeofencePendingIntent()).addOnCompleteListener(t->{getContext().getSharedPreferences("captain_geofence",0).edit().putBoolean("enabled",false).apply(); call.resolve();});
  }
  private PendingIntent getGeofencePendingIntent(){
    Intent intent=new Intent(getContext(),HomeGeofenceReceiver.class);
    int flags=PendingIntent.FLAG_UPDATE_CURRENT; if(Build.VERSION.SDK_INT>=23) flags|=PendingIntent.FLAG_MUTABLE;
    return PendingIntent.getBroadcast(getContext(),9001,intent,flags);
  }
  private boolean hasForegroundLocation(){return ContextCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}

  @com.getcapacitor.annotation.PermissionCallback
  private void locationPermissionCallback(PluginCall call) {
    String action = pendingAction; pendingAction = "";
    if (!hasForegroundLocation()) { call.reject("Location permission denied"); return; }
    if ("current".equals(action)) { readCurrentLocation(call); return; }
    if ("enable".equals(action)) { enable(call); return; }
    call.reject("Permission flow was interrupted. Please try again.");
  }

  @com.getcapacitor.annotation.PermissionCallback
  private void notificationPermissionCallback(PluginCall call) {
    pendingAction = "";
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      call.reject("Notification permission denied"); return;
    }
    registerGeofence(call, pendingLat, pendingLng, pendingRadius);
  }
}
