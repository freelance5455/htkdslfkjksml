#!/usr/bin/env python3
"""Install Captain Tracker's native geofence bridge into a generated Capacitor Android project."""
from pathlib import Path
import re, shutil, sys
root = Path(__file__).resolve().parents[1]
android = root / 'android'
if not android.is_dir():
    sys.exit('Android project not found. Run: npx cap add android')
app = android / 'app'
manifest = app / 'src/main/AndroidManifest.xml'
gradle = app / 'build.gradle'
if not manifest.exists() or not gradle.exists():
    sys.exit('Unexpected Capacitor Android structure; expected app/src/main/AndroidManifest.xml and app/build.gradle')
# Copy native bridge and receivers.
src = root / 'android-plugin/src/main/java/com/captaintracker/geofence'
dst = app / 'src/main/java/com/captaintracker/geofence'
dst.mkdir(parents=True, exist_ok=True)
for file in src.glob('*.java'):
    shutil.copy2(file, dst / file.name)
# Capacitor MainActivity: register the custom bridge plugin before BridgeActivity setup.
main = app / 'src/main/java/com/captaintracker/app/MainActivity.java'
main.parent.mkdir(parents=True, exist_ok=True)
main.write_text('''package com.captaintracker.app;\n\nimport android.os.Bundle;\nimport com.getcapacitor.BridgeActivity;\nimport com.captaintracker.geofence.GeofenceManagerPlugin;\n\npublic class MainActivity extends BridgeActivity {\n  @Override public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(GeofenceManagerPlugin.class);\n    super.onCreate(savedInstanceState);\n  }\n}\n''')
# Merge required permissions and receivers idempotently.
text = manifest.read_text()
perms = [
 'android.permission.ACCESS_COARSE_LOCATION',
 'android.permission.ACCESS_FINE_LOCATION',
 'android.permission.ACCESS_BACKGROUND_LOCATION',
 'android.permission.POST_NOTIFICATIONS',
 'android.permission.RECEIVE_BOOT_COMPLETED',
]
for perm in perms:
    if f'android:name="{perm}"' not in text:
        text = text.replace('<manifest ', '<manifest ', 1)
        close = text.find('>') + 1
        text = text[:close] + f'\n    <uses-permission android:name="{perm}" />' + text[close:]
receivers = '''\n        <receiver android:name="com.captaintracker.geofence.HomeGeofenceReceiver" android:enabled="true" android:exported="false" />\n        <receiver android:name="com.captaintracker.geofence.BootGeofenceReceiver" android:enabled="true" android:exported="false">\n            <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /></intent-filter>\n        </receiver>\n'''
if 'com.captaintracker.geofence.HomeGeofenceReceiver' not in text:
    text = text.replace('</application>', receivers + '    </application>')
manifest.write_text(text)
# Add Play Services Location dependency.
g = gradle.read_text()
if 'com.google.android.gms:play-services-location' not in g:
    g = re.sub(r'(dependencies\s*\{)', r"\1\n    implementation 'com.google.android.gms:play-services-location:21.3.0'", g, count=1)
    gradle.write_text(g)
print('Captain Tracker native geofence bridge installed.')
