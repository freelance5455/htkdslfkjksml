ABDULLA AI ASSISTANT — Native Android APK Project

এই প্রজেক্টটি Capacitor দিয়ে তৈরি। HTML ডিজাইন www/index.html-এ আছে।

APK বানানোর ধাপ:
1) কম্পিউটারে Node.js LTS এবং Android Studio ইনস্টল করুন।
2) এই ফোল্ডার খুলে Terminal চালান:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3) Android Studio খুললে Gradle Sync শেষ হতে দিন।
4) Build > Build APK(s) নির্বাচন করুন।

Routine Notification:
- Android 13+ এ প্রথমবার Notification permission Allow করতে হবে।
- রুটিন যোগ হওয়ার পরে Native Local Notification schedule হবে।
- নির্ধারিত সময়ে Notification আসবে এবং App বন্ধ/ব্যাকগ্রাউন্ডে থাকলেও Android scheduler ব্যবহার করবে।
- Force Stop, ফোনের বিশেষ Battery restriction বা notification বন্ধ থাকলে Android notification নাও আসতে পারে।

নোট: HTML ফাইলকে শুধু APK নামে rename করলে Native notification হবে না। এই Capacitor project Android হিসেবে build করতে হবে।
