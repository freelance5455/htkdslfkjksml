const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('GCF', {
  save: (prof, cat, name, buf) => ipcRenderer.invoke('gcf:save', prof, cat, name, buf),
  list: (prof, cat) => ipcRenderer.invoke('gcf:list', prof, cat),
  open: p => ipcRenderer.invoke('gcf:open', p),
  folder: prof => ipcRenderer.invoke('gcf:folder', prof)
});
