(function () {
  var A = window.App, $ = A.$, esc = A.esc;
  if (!A.init({})) return;
  var fid = new URLSearchParams(location.search).get('id');
  var friend = fid && A.friendById(fid);
  if (!friend) { location.replace('home.html'); return; }
  var me = A.me();
  var lastSig = '', players = {}, rec = null;
  var EMOJIS = '😀 😂 🥹 😍 🥰 😘 😎 🤩 🥳 😭 😅 😉 😊 🙃 🤔 🙄 😴 🤗 👍 👎 👏 🙌 🙏 💪 🔥 ✨ 💖 ❤️ 💔 🎉 ☕ 🍕 🍔 🍰 🌿 🌍 📍 📸 🎵 🏃 😋 🤝 👋 😇 🥺 😤 🤯 😱 💯'.split(' ');

  /* ---------- üst bar ---------- */
  function renderHeader() {
    friend = A.friendById(fid);
    if (!friend) { location.replace('home.html'); return; }
    $('#c-avatar').src = A.avatar(friend);
    $('#c-name').textContent = friend.name;
    $('#c-best').style.display = friend.best ? 'flex' : 'none';
    var loc = friend.linked && A.shareOf(friend.id) && A.canSee(me.id, friend.id);
    var el = $('#c-status');
    el.innerHTML = '<span class="size-2 rounded-full ' + (friend.online ? 'bg-accent' : 'bg-muted-foreground') + '"></span>' + esc(friend.status) + (loc ? ' • Canlı konum aktif' : '');
    el.className = 'text-xs font-semibold flex items-center gap-1 ' + (friend.online ? 'text-accent-foreground' : 'text-muted-foreground');
    $('#pill-text').textContent = friend.linked ? 'Bestie sohbeti • mesajlar bu cihazda saklanır' : 'Bu kişi kayıtlı değil • mesajların ona ulaşmaz';
  }

  /* ---------- mesajlar ---------- */
  function bars(id, n) {
    var h = 7, i, out = '';
    for (i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
    for (i = 0; i < n; i++) { h = (h * 1103515245 + 12345) >>> 0; out += '<span data-bar class="w-1 rounded-full bg-muted-foreground/60" style="height:' + (6 + (h >> 8) % 18) + 'px"></span>'; }
    return out;
  }
  function ticks(m) {
    if (m.from !== me.id || m.type === 'call') return '';
    return '<iconify-icon icon="solar:check-read-linear" class="' + (m.read ? 'text-primary' : 'text-muted-foreground') + '" width="14" height="14"></iconify-icon>';
  }
  function locCard(m) {
    var s = A.shareOf(m.from), live = !m.ended && m.until > Date.now() && s;
    var pos = live ? s : m;
    var left = live ? Math.max(1, Math.round((m.until - Date.now()) / 60000)) : 0;
    return '<div class="bg-card border-2 ' + (live ? 'border-accent/70' : 'border-border') + ' rounded-2xl p-3 overflow-hidden shadow-sm w-64 max-w-full">' +
      '<div class="flex items-center justify-between mb-2"><div class="flex items-center gap-2">' +
      (live ? '<span class="relative flex size-3"><span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span><span class="relative inline-flex rounded-full size-3 bg-accent"></span></span><span class="text-xs font-extrabold">Canlı Konum Paylaşılıyor</span>' :
        '<iconify-icon icon="solar:map-point-wave-bold" class="text-muted-foreground" width="16" height="16"></iconify-icon><span class="text-xs font-extrabold text-muted-foreground">Konum paylaşımı sona erdi</span>') +
      '</div>' + (live ? '<span class="text-[11px] font-bold text-accent-foreground">' + left + ' dk</span>' : '') + '</div>' +
      '<div class="relative rounded-xl overflow-hidden border border-border h-32 bg-muted"><iframe title="Konum" loading="lazy" tabindex="-1" class="w-full h-full border-0 pointer-events-none" src="' + A.osmEmbed(pos.lat, pos.lng, 0.004) + '"></iframe>' +
      '<a href="' + A.osmLink(pos.lat, pos.lng) + '" target="_blank" rel="noopener" class="absolute inset-0 flex items-end p-2"><span class="bg-card/90 border border-border rounded-lg px-2.5 py-1 text-[11px] font-extrabold">Haritada aç</span></a></div></div>';
  }
  function bubbleBody(m, mine) {
    var cls = mine ? 'bg-primary text-primary-foreground rounded-br-sm shadow-sm' : 'bg-card border border-border rounded-bl-sm';
    if (m.type === 'image') return '<div class="' + cls + ' p-1.5 rounded-2xl overflow-hidden"><img data-view src="' + m.data + '" class="rounded-xl max-h-60 w-full object-cover cursor-zoom-in" alt="Fotoğraf" /></div>';
    if (m.type === 'file') return '<div class="' + cls + ' p-3 rounded-2xl flex items-center gap-3"><div class="size-10 rounded-xl ' + (mine ? 'bg-primary-foreground/20' : 'bg-primary/15 text-primary') + ' flex items-center justify-center shrink-0"><iconify-icon icon="solar:file-bold" width="22" height="22"></iconify-icon></div><div class="min-w-0"><p class="text-sm font-bold truncate max-w-[10rem]">' + esc(m.name) + '</p><p class="text-[11px] opacity-80">' + A.fmtSize(m.size || 0) + '</p></div><a href="' + m.data + '" download="' + esc(m.name) + '" class="size-9 rounded-full ' + (mine ? 'bg-primary-foreground/20' : 'bg-input border border-border') + ' flex items-center justify-center shrink-0" aria-label="İndir"><iconify-icon icon="solar:download-linear" width="18" height="18"></iconify-icon></a></div>';
    if (m.type === 'voice') return '<div class="' + cls + ' p-3 rounded-2xl flex items-center gap-3 min-w-[13rem]" data-voice="' + m.id + '"><button type="button" data-play class="size-9 rounded-full ' + (mine ? 'bg-primary-foreground text-primary' : 'bg-primary text-primary-foreground') + ' flex items-center justify-center shrink-0" aria-label="Oynat"><iconify-icon icon="solar:play-bold" width="16" height="16"></iconify-icon></button><div class="flex-1"><div class="flex items-center gap-0.5 h-6">' + bars(m.id, 22) + '</div><div class="text-[10px] font-semibold opacity-80" data-vtime>' + A.fmtDur(m.dur || 0) + '</div></div></div>';
    if (m.type === 'location') return locCard(m);
    return '<div class="' + cls + ' p-3.5 rounded-2xl"><p class="text-sm font-medium leading-relaxed whitespace-pre-wrap break-words">' + esc(m.text) + '</p></div>';
  }
  function renderMsgs(force) {
    var list = A.msgs(fid);
    var sig = JSON.stringify(list.map(function (m) { return [m.id, m.read, m.ended]; }));
    if (!force && sig === lastSig) return;
    lastSig = sig;
    var box = $('#msgs'), nearBottom = (window.innerHeight + window.scrollY) >= document.body.scrollHeight - 160;
    var html = '', lastDay = null;
    if (!list.length) {
      html = '<div class="text-center py-12"><div class="size-16 rounded-full bg-primary/15 text-primary mx-auto flex items-center justify-center mb-3"><iconify-icon icon="solar:chat-round-dots-bold" width="30" height="30"></iconify-icon></div><p class="font-heading font-extrabold">' + esc(friend.name) + ' ile sohbet başlat</p><p class="text-xs text-muted-foreground font-semibold mt-1">İlk mesajı sen yaz 👋</p></div>';
    }
    list.forEach(function (m) {
      var day = A.dayStart(m.ts);
      if (day !== lastDay) {
        lastDay = day;
        html += '<div class="flex items-center gap-3 my-2"><div class="h-px bg-border flex-1"></div><span class="text-[11px] font-extrabold uppercase text-muted-foreground tracking-wider">' + A.fmtDay(m.ts) + '</span><div class="h-px bg-border flex-1"></div></div>';
      }
      if (m.type === 'call') {
        html += '<div class="flex justify-center"><div class="px-3.5 py-1.5 rounded-full bg-card border border-border text-[11px] font-bold text-muted-foreground flex items-center gap-1.5"><iconify-icon icon="' + (m.video ? 'solar:videocamera-record-bold' : 'solar:phone-bold') + '" width="14" height="14"></iconify-icon>' + esc(m.text) + ' • ' + A.fmtTime(m.ts) + '</div></div>';
        return;
      }
      var mine = m.from === me.id;
      if (mine) {
        html += '<div class="flex items-end justify-end gap-2 max-w-[86%] ml-auto" data-mid="' + m.id + '"><div class="min-w-0">' + bubbleBody(m, true) + '<div class="flex items-center justify-end gap-1 mr-1 mt-1"><span class="text-[10px] text-muted-foreground">' + A.fmtTime(m.ts) + '</span>' + ticks(m) + '</div></div></div>';
      } else {
        html += '<div class="flex items-end gap-2 max-w-[86%]" data-mid="' + m.id + '"><img src="' + A.avatar(friend) + '" class="size-7 rounded-full object-cover shrink-0 mb-5" alt="" /><div class="min-w-0">' + bubbleBody(m, false) + '<span class="text-[10px] text-muted-foreground ml-1 mt-1 block">' + A.fmtTime(m.ts) + '</span></div></div>';
      }
    });
    box.innerHTML = html;
    refreshVoice();
    if (force === 'scroll' || nearBottom || list.length && list[list.length - 1].from === me.id) window.scrollTo(0, document.body.scrollHeight);
  }

  /* ---------- ses oynatma ---------- */
  function refreshVoice() {
    Object.keys(players).forEach(function (id) { paintVoice(id); });
  }
  function paintVoice(id) {
    var p = players[id], el = $('[data-voice="' + id + '"]'); if (!p || !el) return;
    var msg = A.msgs(fid).filter(function (m) { return m.id === id; })[0]; if (!msg) return;
    var ratio = msg.dur ? Math.min(1, p.audio.currentTime / msg.dur) : 0, bs = A.$$('[data-bar]', el);
    bs.forEach(function (b, i) { b.className = 'w-1 rounded-full ' + (i < Math.round(ratio * bs.length) ? 'bg-current' : 'bg-muted-foreground/60'); });
    el.querySelector('[data-play] iconify-icon').setAttribute('icon', p.audio.paused ? 'solar:play-bold' : 'solar:pause-bold');
    el.querySelector('[data-vtime]').textContent = p.audio.paused && ratio === 0 ? A.fmtDur(msg.dur) : A.fmtDur(p.audio.currentTime) + ' / ' + A.fmtDur(msg.dur);
  }
  function togglePlay(id) {
    var msg = A.msgs(fid).filter(function (m) { return m.id === id; })[0]; if (!msg) return;
    Object.keys(players).forEach(function (k) { if (k !== id && !players[k].audio.paused) { players[k].audio.pause(); paintVoice(k); } });
    var p = players[id];
    if (!p) {
      var a = new Audio(msg.data);
      p = players[id] = { audio: a };
      a.addEventListener('timeupdate', function () { paintVoice(id); });
      a.addEventListener('pause', function () { paintVoice(id); });
      a.addEventListener('ended', function () { a.currentTime = 0; paintVoice(id); });
    }
    if (p.audio.paused) p.audio.play().catch(function () { A.toast('Ses oynatılamadı.', 'error'); }); else p.audio.pause();
    paintVoice(id);
  }

  /* ---------- gönderme ---------- */
  function sendText() {
    var input = $('#msg-input'), t = input.value.trim();
    if (!t) return;
    if (A.sendMsg(fid, { type: 'text', text: t })) { input.value = ''; syncMain(); hideEmoji(); }
  }
  function sendFile(file) {
    if (!file) return;
    if (/^image\//.test(file.type)) {
      A.resizeImage(file, 1000, 0.72).then(function (data) { A.sendMsg(fid, { type: 'image', data: data, name: file.name }); })
        .catch(function (e) { A.toast(e.message, 'error'); });
      return;
    }
    if (file.size > 1000000) { A.toast('Dosya en fazla 1 MB olabilir.', 'error'); return; }
    var fr = new FileReader();
    fr.onload = function () { A.sendMsg(fid, { type: 'file', data: fr.result, name: file.name, size: file.size, mime: file.type }); };
    fr.onerror = function () { A.toast('Dosya okunamadı.', 'error'); };
    fr.readAsDataURL(file);
  }
  function syncMain() {
    var has = $('#msg-input').value.trim().length > 0;
    $('#main-btn').innerHTML = '<iconify-icon icon="' + (has ? 'solar:plain-bold' : 'solar:microphone-3-bold') + '" width="20" height="20"></iconify-icon>';
    $('#main-btn').setAttribute('aria-label', has ? 'Gönder' : 'Ses kaydet');
  }

  /* ---------- ses kaydı ---------- */
  function showRec(on) {
    $('#compose').style.display = on ? 'none' : '';
    $('#recbar').classList.toggle('hidden', !on);
    $('#recbar').classList.toggle('flex', on);
  }
  function startRec() {
    if (rec) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { A.toast('Ses kaydı bu tarayıcıda desteklenmiyor (https veya localhost gerekir).', 'error'); return; }
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      var types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'];
      var mt = types.filter(function (t) { return MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t); })[0];
      var mr = new MediaRecorder(stream, mt ? { mimeType: mt } : undefined);
      var r = rec = { mr: mr, stream: stream, chunks: [], start: Date.now(), send: false };
      mr.ondataavailable = function (e) { if (e.data && e.data.size) r.chunks.push(e.data); };
      mr.onstop = function () {
        stream.getTracks().forEach(function (t) { t.stop(); });
        clearInterval(r.timer); rec = null; showRec(false);
        if (!r.send) return;
        var dur = (Date.now() - r.start) / 1000;
        if (dur < 0.7) { A.toast('Kayıt çok kısa.'); return; }
        var blob = new Blob(r.chunks, { type: mr.mimeType || 'audio/webm' });
        if (blob.size > 900000) { A.toast('Ses kaydı çok uzun.', 'error'); return; }
        var fr = new FileReader();
        fr.onload = function () { A.sendMsg(fid, { type: 'voice', data: fr.result, dur: Math.round(dur) }); };
        fr.readAsDataURL(blob);
      };
      mr.start(); showRec(true);
      r.timer = setInterval(function () {
        var s = (Date.now() - r.start) / 1000;
        $('#rec-time').textContent = A.fmtDur(s);
        if (s >= 60) stopRec(true);
      }, 200);
      $('#rec-time').textContent = '0:00';
    }).catch(function () { A.toast('Mikrofon izni verilmedi.', 'error'); });
  }
  function stopRec(send) { if (!rec) return; rec.send = send; try { rec.mr.stop(); } catch (e) { rec = null; showRec(false); } }

  /* ---------- konum ---------- */
  function hasActiveLocHere() {
    return A.msgs(fid).some(function (m) { return m.type === 'location' && m.from === me.id && !m.ended && m.until > Date.now(); });
  }
  function postLocation() {
    var s = A.myShare(); if (!s) return;
    A.sendMsg(fid, { type: 'location', lat: s.lat, lng: s.lng, until: s.until });
  }
  function renderLocRow() {
    var s = A.myShare(), row = $('#loc-row');
    if (!friend.linked) { row.style.display = 'none'; return; }
    row.style.display = '';
    if (!s) {
      row.innerHTML = '<button type="button" id="loc-start" class="flex items-center gap-1.5 text-xs font-bold text-muted-foreground bg-input px-3 py-1.5 rounded-full border border-border"><iconify-icon icon="solar:map-point-wave-bold" width="16" height="16"></iconify-icon>Konumumu paylaş</button>';
      $('#loc-start').addEventListener('click', openLocSheet);
    } else {
      var here = hasActiveLocHere();
      row.innerHTML = (here ? '<span class="flex items-center gap-1.5 text-xs font-bold text-accent-foreground bg-accent/40 px-3 py-1.5 rounded-full border border-accent"><iconify-icon icon="solar:map-point-wave-bold" width="16" height="16"></iconify-icon>Canlı Konum Paylaşılıyor</span>' :
        '<button type="button" id="loc-here" class="flex items-center gap-1.5 text-xs font-bold text-accent-foreground bg-accent/40 px-3 py-1.5 rounded-full border border-accent"><iconify-icon icon="solar:map-point-wave-bold" width="16" height="16"></iconify-icon>Bu sohbette de paylaş</button>') +
        '<button type="button" id="loc-stop" class="text-xs font-bold text-destructive hover:underline">Paylaşımı Durdur</button>';
      if (!here) $('#loc-here').addEventListener('click', postLocation);
      $('#loc-stop').addEventListener('click', function () { A.stopShare(); A.toast('Konum paylaşımı durduruldu'); });
    }
  }
  function openLocSheet() {
    var s = A.sheet(A.sheetHeader('Canlı konum paylaş', esc(friend.name) + ' ile ne kadar süre?') +
      '<div class="space-y-2">' + [[15, '15 dakika'], [60, '1 saat'], [480, '8 saat']].map(function (o) {
        return '<button type="button" data-min="' + o[0] + '" class="w-full h-12 rounded-2xl bg-input border border-border px-4 text-sm font-extrabold text-left flex items-center justify-between">' + o[1] + '<iconify-icon icon="solar:alt-arrow-right-linear" width="16" height="16"></iconify-icon></button>';
      }).join('') + '</div><p class="text-[11px] text-muted-foreground font-semibold mt-3">Konum, profildeki gizlilik ayarına göre görünür. Hayalet modundaysan kimse göremez.</p>', { noFocus: true });
    s.el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-min]'); if (!b) return;
      b.disabled = true;
      A.getPosition().then(function (p) { A.startShare(+b.getAttribute('data-min'), p); s.close(); postLocation(); })
        .catch(function (err) { A.toast(err.message, 'error'); b.disabled = false; });
    });
  }

  /* ---------- emoji ---------- */
  function hideEmoji() { $('#emoji-pop').classList.add('hidden'); }
  $('#emoji-grid').innerHTML = EMOJIS.map(function (e) { return '<button type="button" data-emo class="size-9 text-xl rounded-lg">' + e + '</button>'; }).join('');
  $('#emoji-pop').addEventListener('click', function (e) {
    var b = e.target.closest('[data-emo]'); if (!b) return;
    var input = $('#msg-input'), s = input.selectionStart == null ? input.value.length : input.selectionStart, en = input.selectionEnd == null ? s : input.selectionEnd;
    input.value = input.value.slice(0, s) + b.textContent + input.value.slice(en);
    input.focus(); input.selectionStart = input.selectionEnd = s + b.textContent.length; syncMain();
  });
  $('#emoji-btn').addEventListener('click', function () { $('#emoji-pop').classList.toggle('hidden'); });

  /* ---------- olaylar ---------- */
  $('#msg-input').addEventListener('input', syncMain);
  $('#msg-input').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendText(); } });
  $('#main-btn').addEventListener('click', function () { if ($('#msg-input').value.trim()) sendText(); else startRec(); });
  $('#rec-send').addEventListener('click', function () { stopRec(true); });
  $('#rec-cancel').addEventListener('click', function () { stopRec(false); });
  $('#attach').addEventListener('click', function () { $('#file-input').click(); });
  $('#camera').addEventListener('click', function () { $('#cam-input').click(); });
  ['file-input', 'cam-input'].forEach(function (id) {
    $('#' + id).addEventListener('change', function (e) { sendFile(e.target.files[0]); e.target.value = ''; });
  });
  $('#btn-voice').addEventListener('click', function () { A.call(fid, false); });
  $('#btn-video').addEventListener('click', function () { A.call(fid, true); });
  $('#c-back').addEventListener('click', function () {
    if (history.length > 1 && document.referrer && document.referrer.indexOf(location.host) >= 0) history.back(); else location.href = 'home.html';
  });
  $('#c-head-info').addEventListener('click', function () { location.href = 'friends.html'; });
  $('#btn-more').addEventListener('click', function () {
    A.actionSheet(friend.name, [
      { label: friend.best ? 'En iyi arkadaşlıktan çıkar' : 'En iyi arkadaş yap', icon: 'solar:heart-bold', run: function () { A.toggleBest(fid); } },
      { label: 'Sohbeti temizle', icon: 'solar:trash-bin-trash-bold', danger: true, run: function () {
        A.confirm('Sohbeti temizle', 'Bu sohbetteki tüm mesajlar silinecek.', 'Temizle', true).then(function (ok) { if (ok) { A.clearChat(fid); A.toast('Sohbet temizlendi'); } });
      } },
      { label: 'Arkadaşı kaldır', icon: 'solar:user-plus-bold', danger: true, run: function () {
        A.confirm('Arkadaşı kaldır', friend.name + ' listenden ve sohbet geçmişinden silinecek.', 'Kaldır', true).then(function (ok) { if (ok) { A.removeFriend(fid); location.href = 'home.html'; } });
      } }
    ]);
  });
  $('#msgs').addEventListener('click', function (e) {
    var wrap = e.target.closest('[data-mid]'); if (!wrap) return;
    var id = wrap.getAttribute('data-mid');
    if (e.target.closest('[data-play]')) { togglePlay(id); return; }
    var msg = A.msgs(fid).filter(function (m) { return m.id === id; })[0]; if (!msg) return;
    if (e.target.closest('[data-view]')) {
      var ov = document.createElement('div');
      ov.className = 'fixed inset-0 z-[70] bg-black/90 flex items-center justify-center p-4';
      ov.innerHTML = '<img src="' + msg.data + '" class="max-w-full max-h-full rounded-xl" alt="" />';
      ov.addEventListener('click', function () { ov.remove(); });
      document.body.appendChild(ov); return;
    }
    if (e.target.closest('a,iframe')) return;
    var items = [];
    if (msg.type === 'text') items.push({ label: 'Kopyala', icon: 'solar:copy-bold', run: function () { A.copyText(msg.text).then(function () { A.toast('Kopyalandı'); }); } });
    if (msg.from === me.id) items.push({ label: 'Mesajı sil', icon: 'solar:trash-bin-trash-bold', danger: true, run: function () { A.deleteMsg(fid, id); } });
    if (items.length) A.actionSheet('Mesaj', items);
  });
  document.addEventListener('click', function (e) { if (!e.target.closest('#emoji-pop,#emoji-btn')) hideEmoji(); });

  function sync() {
    renderHeader(); renderMsgs(); renderLocRow();
    if (!document.hidden) A.markRead(fid);
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden) A.markRead(fid); });
  A.onChange(sync);
  setInterval(function () { if (A.msgs(fid).some(function (m) { return m.type === 'location'; })) renderMsgs(true); }, 30000);
  syncMain(); renderHeader(); renderMsgs('scroll'); renderLocRow(); A.markRead(fid);
  window.addEventListener('beforeunload', function () { if (rec) stopRec(false); });
})();
