package com.portfolio.myapp;

// Splash Activity placeholder