# Arrow Escape - Android app (phone + tablet)

Game ka poora code `www/index.html` mein hai (ek hi file). Pehle browser mein test karne ke liye us file ko seedha Chrome mein khol lo.

## APK banane ke steps (ek baar)
Zaroori: Node.js (18+) aur Android Studio install ho.

1. Is folder mein terminal kholo.
2. `npm install`
3. `npx cap add android`
4. `npx cap sync android`
5. `npx cap open android` (Android Studio khulega)
6. Android Studio mein: Build > Build Bundle(s) / APK(s) > Build APK(s)
7. APK milegi: `android/app/build/outputs/apk/debug/app-debug.apk` - ise phone/tablet mein install karo.

## Vibration chalane ke liye
`android/app/src/main/AndroidManifest.xml` mein `<application>` se pehle ye line jodo:

`<uses-permission android:name="android.permission.VIBRATE" />`

## Tablet landscape + portrait dono
Default Capacitor app dono orientation mein chalta hai. Sirf portrait chahiye to `AndroidManifest.xml` ke `<activity>` mein
`android:screenOrientation="portrait"` jodo.

## Game badalna ho
`www/index.html` edit karo, phir `npx cap sync android` chalao aur dobara APK banao.

## Play Store ke liye
appId `com.arrowescape.game` ko apne naam wale unique id se badal do (capacitor.config.json), aur Build > Generate Signed Bundle se AAB banao.
