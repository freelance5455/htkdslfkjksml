دلفري قنا - نسخة Android محلية

هذه النسخة تصلح مشكلة فتح androidplatform.net/web/index.html.
صفحة التطبيق موجودة داخل assets/index.html ويتم تحميلها عبر:
file:///android_asset/index.html

ملاحظة: المشروع جاهز للبناء، لكن بيئة ChatGPT الحالية لا تحتوي Android SDK/Gradle لإخراج APK هنا.
