#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Générateur de codes d'activation Pro pour CMC Moyennes.

À GARDER PRIVÉ : ne mettez jamais ce fichier dans un dépôt GitHub public, ni
nulle part où quelqu'un d'autre que vous pourrait le lire. Quiconque l'obtient
peut fabriquer ses propres codes d'activation.

Utilisation :
    python3 generate_code.py 1A2B-3C4D

« 1A2B-3C4D » est la clé affichée dans l'application, dans
Réglages > Version Pro, que l'acheteur vous communique (SMS, WhatsApp...).
Le script affiche le code à lui renvoyer en retour.

Ce script reproduit exactement le calcul fait par l'application (fichier
MainActivity.java, méthodes licenseSecret/expectedCodeFor) : pour une même
clé d'appareil, il donne toujours le même code, et ce code n'active
l'application QUE sur l'appareil qui a cette clé.
"""
import sys
import hashlib
import hmac

# Doit rester identique à LIC_XOR dans MainActivity.java.
LIC_XOR = [
    0x3E, 0x5B, 0x0C, 0x71, 0x26, 0x4D, 0x18, 0x6F, 0x3A, 0x51, 0x05, 0x78, 0x2D, 0x40, 0x13, 0x6C,
    0x37, 0x5E, 0x08, 0x75, 0x22, 0x49, 0x1C, 0x63, 0x3E, 0x51, 0x05, 0x78,
]
KEY = b"CMC-Moyennes-Pro"
SECRET = bytes(LIC_XOR[i] ^ KEY[i % len(KEY)] for i in range(len(LIC_XOR)))


def generate(device_key: str) -> str:
    device_key = device_key.strip().upper()
    digest = hmac.new(SECRET, device_key.encode("ascii"), hashlib.sha256).hexdigest().upper()
    code = digest[:10]
    return code[:5] + "-" + code[5:]


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Utilisation : python3 generate_code.py <clé affichée dans l'application>")
        sys.exit(1)
    print(f"Clé d'appareil : {sys.argv[1].strip().upper()}")
    print(f"Code à communiquer à l'acheteur : {generate(sys.argv[1])}")
