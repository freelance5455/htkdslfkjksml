ESTRADA — projeto Android para gerar APK

Este projeto coloca o arquivo HTML original dentro de um aplicativo Android usando WebView, em tela cheia e orientação horizontal.

COMO GERAR O APK
1. Instale o Android Studio em um computador: https://developer.android.com/studio
2. Extraia o arquivo ZIP.
3. No Android Studio, escolha Open e selecione a pasta ESTRADA (a pasta que contém settings.gradle).
4. Aguarde o Gradle sincronizar e instalar os componentes solicitados.
5. Para criar um APK de teste: menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, clique em Locate na notificação do Android Studio. O APK normalmente fica em app/build/outputs/apk/debug/app-debug.apk.
7. Copie o APK para o celular Android e abra-o para instalar. Talvez seja necessário autorizar instalação dessa fonte.

IMPORTANTE
- O jogo usa Three.js e a fonte VT323 por URLs externas. A conexão com a internet é necessária para carregar esses recursos, salvo se forem incorporados localmente depois.
- O projeto-fonte não é um APK já compilado. A compilação precisa do Android SDK/Gradle do Android Studio.
- Teste em um aparelho real; desempenho 3D varia conforme o celular.


OTIMIZAÇÃO PARA CELULAR:
O jogo agora inicia no perfil EQUILÍBRIO, com resolução 3D reduzida, bloom mais leve e limite de renderização próximo de 30 FPS, inclusive no menu, para aliviar celulares modestos. Nas opções, você pode escolher EQUILÍBRIO, NORMAL, CLÁSSICO, REALISTA ou ULTRA REALISTA; os perfis mais altos podem voltar a causar travamentos.


ORIENTACAO DA TELA
O aplicativo foi configurado para acompanhar a orientacao do celular (portrait e landscape). Ao virar o aparelho, o Android pode redimensionar a tela e o jogo recalcula a proporcao da camera pelo evento resize. Se a rotacao automatica do Android estiver desligada, ative-a nas configuracoes rapidas do celular.
