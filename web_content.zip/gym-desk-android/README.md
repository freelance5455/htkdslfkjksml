# Gym Desk for Android

1. Install Android Studio (free) from developer.android.com/studio.
2. Open Android Studio, choose Open, and select this folder. Let it finish syncing (first time takes a few minutes).
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk.
5. Send that APK to your phone and install it (allow "install unknown apps" when asked).

Notes
- Members, payments and settings are stored on the phone that runs the app. Phones do not share data with each other.
- Reminders open WhatsApp with the message filled in. Fonts and WhatsApp need internet.
- To change the app, edit app/src/main/assets/index.html and build again.
