# KINGLDZ STORE

Plataforma moderna de aplicaciones Android — MVP Frontend

## Diseño
- Dark mode premium
- Acento rojo/neón
- Glassmorphism
- Totalmente responsive (móvil prioritario)
- Iconos de redes sociales
- Soporte para iconos personalizados de apps

## Características incluidas
- Página de inicio completa
- Catálogo de aplicaciones con filtros
- Página de detalle de cada app
- Sistema de favoritos (localStorage)
- Buscador funcional
- Categorías
- Redes sociales con iconos
- Simulación de descarga
- Compartir
- Navegación móvil inferior

## Cómo poner tu logo de KINGLDZ

1. Coloca tu imagen en: `assets/logo/logo.png`
2. Recomendado: 256x256 px o superior, formato PNG con fondo transparente
3. Si no existe el archivo, se muestra la "K" automática

## Cómo poner iconos de las aplicaciones

1. Copia tus iconos (png/jpg/webp) a la carpeta: `assets/icons/`
2. Abre el archivo `data/apps.js`
3. En cada app agrega la línea:
   ```js
   iconImage: "nombre-del-archivo.png",
   ```
4. El emoji (`icon`) se usa como respaldo si la imagen no carga

## Cómo poner tus redes sociales

1. Abre `index.html`
2. Busca los enlaces que dicen `tu_usuario` o `tu_invite`
3. Cámbialos por tus enlaces reales de:
   - Telegram
   - Instagram
   - TikTok
   - YouTube
   - X (Twitter)
   - Discord
   - GitHub

## Cómo ejecutarlo en Termux

```bash
cd kingldz-store
python -m http.server 8080
```

Luego abre: `http://127.0.0.1:8080`

## Estructura

```
kingldz-store/
├── index.html
├── css/style.css
├── js/app.js
├── data/apps.js
├── assets/
│   ├── logo/          ← Pon aquí logo.png
│   ├── icons/         ← Pon aquí los iconos de las apps
│   └── social/
└── README.md
```

---
© 2026 KINGLDZ STORE
