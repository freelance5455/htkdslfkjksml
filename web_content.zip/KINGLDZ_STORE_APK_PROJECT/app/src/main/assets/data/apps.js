/* 
  CÓMO PONER TUS PROPIOS ICONOS DE APPS:
  1. Copia tu imagen (png/jpg/webp) a la carpeta:  assets/icons/
  2. Ponle un nombre simple, ejemplo: nova.png
  3. En la app correspondiente agrega:  iconImage: "nova.png"
  4. El campo "icon" (emoji) se usa como respaldo si la imagen no carga.

  Ejemplo:
  icon: "🚀",
  iconImage: "nova.png",
*/

const APPS = [
  {
    id: 1,
    name: "Nova Launcher Prime",
    slug: "nova-launcher-prime",
    icon: "🚀",
    // iconImage: "nova.png",   // <-- descomenta y pon tu archivo aquí
    category: "Lanzadores",
    developer: "TeslaCoil Software",
    version: "8.0.18",
    size: "12.4 MB",
    android: "7.0+",
    arch: "Universal",
    downloads: 2450000,
    rating: 4.8,
    votes: 12840,
    date: "2026-08-15",
    updated: "2026-09-01",
    description: "El lanzador más personalizable y fluido para Android. Cambia completamente la apariencia de tu dispositivo con iconos, gestos, carpetas y mucho más.",
    longDescription: "Nova Launcher Prime es la versión premium del lanzador más popular de Android. Ofrece un control total sobre la interfaz de tu dispositivo: gestos personalizados, carpetas con scroll, ocultar apps, drawer con pestañas, y un rendimiento excepcional. Ideal para quienes quieren personalizar cada detalle de su teléfono.",
    tags: ["launcher", "personalización", "prime"],
    featured: true,
    screenshots: 4
  },
  {
    id: 2,
    name: "YouTube Vanced ReVanced",
    slug: "youtube-revanced",
    icon: "▶️",
    category: "Multimedia",
    developer: "ReVanced Team",
    version: "19.16.39",
    size: "48.2 MB",
    android: "8.0+",
    arch: "arm64-v8a",
    downloads: 5120000,
    rating: 4.7,
    votes: 89200,
    date: "2026-07-20",
    updated: "2026-09-03",
    description: "YouTube sin anuncios, con reproducción en segundo plano y modo Picture-in-Picture. La mejor experiencia de YouTube en Android.",
    longDescription: "ReVanced es la continuación espiritual de Vanced. Disfruta de YouTube sin publicidad, con reproducción en segundo plano, modo PiP, control de velocidad y muchas más funciones que no están disponibles en la versión oficial.",
    tags: ["youtube", "sin ads", "multimedia"],
    featured: true,
    screenshots: 5
  },
  {
    id: 3,
    name: "Solid Explorer",
    slug: "solid-explorer",
    icon: "📁",
    category: "Herramientas",
    developer: "NeatBytes",
    version: "2.8.46",
    size: "18.7 MB",
    android: "5.0+",
    arch: "Universal",
    downloads: 980000,
    rating: 4.9,
    votes: 34500,
    date: "2026-06-10",
    updated: "2026-08-28",
    description: "El administrador de archivos más potente y elegante para Android. Soporte dual panel, cloud y root.",
    longDescription: "Solid Explorer combina un diseño moderno con funciones avanzadas: doble panel, soporte para FTP/SFTP/SMB, Google Drive, Dropbox, root access, y un sistema de pestañas. Perfecto tanto para usuarios básicos como avanzados.",
    tags: ["file manager", "root", "cloud"],
    featured: true,
    screenshots: 4
  },
  {
    id: 4,
    name: "MacroDroid Pro",
    slug: "macrodroid-pro",
    icon: "⚙️",
    category: "Productividad",
    developer: "ArloSoft",
    version: "5.43.12",
    size: "22.1 MB",
    android: "6.0+",
    arch: "Universal",
    downloads: 1560000,
    rating: 4.6,
    votes: 22100,
    date: "2026-05-22",
    updated: "2026-09-02",
    description: "Automatiza tu Android de forma sencilla. Crea macros potentes sin necesidad de programar.",
    longDescription: "MacroDroid te permite automatizar casi cualquier tarea en tu dispositivo. Desde silenciar el teléfono en reuniones hasta respaldar fotos automáticamente. Interfaz intuitiva y cientos de triggers y acciones disponibles.",
    tags: ["automatización", "macros", "productividad"],
    featured: false,
    screenshots: 3
  },
  {
    id: 5,
    name: "ADX Audio Editor",
    slug: "adx-audio-editor",
    icon: "🎧",
    category: "Música",
    developer: "ADX Soft",
    version: "3.2.1",
    size: "31.5 MB",
    android: "7.0+",
    arch: "arm64-v8a",
    downloads: 420000,
    rating: 4.5,
    votes: 8900,
    date: "2026-08-01",
    updated: "2026-08-25",
    description: "Editor de audio profesional para Android. Graba, edita, aplica efectos y exporta en alta calidad.",
    longDescription: "ADX Audio Editor es una herramienta completa para edición de audio en el móvil. Incluye equalizador, efectos, recorte preciso, conversión de formatos y soporte para proyectos multi-pista.",
    tags: ["audio", "editor", "música"],
    featured: false,
    screenshots: 4
  },
  {
    id: 6,
    name: "Game Booster 4x",
    slug: "game-booster-4x",
    icon: "🎮",
    category: "Juegos",
    developer: "XGame Labs",
    version: "4.1.0",
    size: "9.8 MB",
    android: "8.0+",
    arch: "Universal",
    downloads: 3200000,
    rating: 4.4,
    votes: 56700,
    date: "2026-04-15",
    updated: "2026-08-30",
    description: "Optimiza tu dispositivo para juegos. Más FPS, menos lag y control total del rendimiento.",
    longDescription: "Game Booster 4x limpia la memoria, cierra procesos en segundo plano, optimiza la GPU y te da un panel de control rápido mientras juegas. Compatible con la mayoría de juegos populares.",
    tags: ["juegos", "optimización", "fps"],
    featured: true,
    screenshots: 3
  },
  {
    id: 7,
    name: "KWGT Pro",
    slug: "kwgt-pro",
    icon: "📐",
    category: "Personalización",
    developer: "Kustom Industries",
    version: "3.79b",
    size: "14.2 MB",
    android: "5.0+",
    arch: "Universal",
    downloads: 1870000,
    rating: 4.8,
    votes: 41200,
    date: "2026-03-28",
    updated: "2026-09-01",
    description: "Crea widgets personalizados increíbles. La herramienta definitiva de personalización visual.",
    longDescription: "KWGT (Kustom Widget Maker) te permite diseñar widgets desde cero o usar miles de presets de la comunidad. Combínalo con KLWP para personalizar absolutamente todo tu Android.",
    tags: ["widgets", "kustom", "personalización"],
    featured: false,
    screenshots: 5
  },
  {
    id: 8,
    name: "Termux",
    slug: "termux",
    icon: "💻",
    category: "Herramientas",
    developer: "Termux Dev",
    version: "0.119.0",
    size: "8.4 MB",
    android: "7.0+",
    arch: "arm64-v8a",
    downloads: 4100000,
    rating: 4.9,
    votes: 98400,
    date: "2026-02-10",
    updated: "2026-08-20",
    description: "Emulador de terminal Linux completo en Android. Instala paquetes, programa y automatiza.",
    longDescription: "Termux convierte tu Android en un entorno Linux completo. Usa apt, python, node, git, vim y cientos de paquetes. Ideal para desarrolladores, pentesters y entusiastas de la terminal.",
    tags: ["terminal", "linux", "desarrollo"],
    featured: true,
    screenshots: 3
  },
  {
    id: 9,
    name: "Photomath Plus",
    slug: "photomath-plus",
    icon: "📷",
    category: "Educación",
    developer: "Photomath Inc",
    version: "8.36.0",
    size: "27.3 MB",
    android: "6.0+",
    arch: "Universal",
    downloads: 8900000,
    rating: 4.6,
    votes: 215000,
    date: "2026-01-05",
    updated: "2026-09-04",
    description: "Resuelve problemas matemáticos con la cámara. Explicaciones paso a paso detalladas.",
    longDescription: "Photomath escanea cualquier problema matemático y te muestra la solución con explicaciones claras. Ideal para estudiantes de todos los niveles, desde aritmética básica hasta cálculo avanzado.",
    tags: ["matemáticas", "educación", "estudiantes"],
    featured: false,
    screenshots: 4
  },
  {
    id: 10,
    name: "NetGuard Pro",
    slug: "netguard-pro",
    icon: "🛡️",
    category: "Seguridad",
    developer: "M66B",
    version: "2.327",
    size: "6.1 MB",
    android: "5.1+",
    arch: "Universal",
    downloads: 1340000,
    rating: 4.7,
    votes: 28900,
    date: "2026-07-08",
    updated: "2026-08-15",
    description: "Firewall sin root. Controla qué apps tienen acceso a internet de forma sencilla y potente.",
    longDescription: "NetGuard es un firewall basado en VPN local que no requiere root. Bloquea el acceso a internet de cualquier aplicación, ahorra datos y protege tu privacidad. Versión Pro con más funciones.",
    tags: ["firewall", "privacidad", "seguridad"],
    featured: false,
    screenshots: 3
  },
  {
    id: 11,
    name: "VLC for Android",
    slug: "vlc-android",
    icon: "🎬",
    category: "Multimedia",
    developer: "VideoLAN",
    version: "3.5.4",
    size: "35.8 MB",
    android: "4.1+",
    arch: "Universal",
    downloads: 12500000,
    rating: 4.5,
    votes: 542000,
    date: "2026-05-01",
    updated: "2026-08-22",
    description: "El reproductor multimedia más completo. Reproduce casi cualquier formato de video y audio.",
    longDescription: "VLC es el reproductor de código abierto más popular del mundo. Soporta prácticamente todos los formatos sin necesidad de codecs adicionales, subtítulos, streaming y mucho más.",
    tags: ["video", "reproductor", "multimedia"],
    featured: false,
    screenshots: 4
  },
  {
    id: 12,
    name: "Swift Backup",
    slug: "swift-backup",
    icon: "💾",
    category: "Herramientas",
    developer: "Swift Apps",
    version: "5.1.3",
    size: "11.9 MB",
    android: "7.0+",
    arch: "Universal",
    downloads: 670000,
    rating: 4.8,
    votes: 15600,
    date: "2026-08-10",
    updated: "2026-09-05",
    description: "Respaldo moderno y rápido de apps + datos. Soporta root y no-root con Material Design.",
    longDescription: "Swift Backup es la evolución de los respaldos en Android. Interfaz moderna, backups incrementales, soporte para Google Drive y almacenamiento local, y restauración selectiva de datos.",
    tags: ["backup", "root", "restaurar"],
    featured: true,
    screenshots: 4
  }
];

const CATEGORIES = [
  { id: "apps", name: "Apps", icon: "📱", count: 48 },
  { id: "juegos", name: "Juegos", icon: "🎮", count: 36 },
  { id: "herramientas", name: "Herramientas", icon: "🔧", count: 29 },
  { id: "personalizacion", name: "Personalización", icon: "🎨", count: 22 },
  { id: "musica", name: "Música", icon: "🎵", count: 18 },
  { id: "multimedia", name: "Multimedia", icon: "🎬", count: 25 },
  { id: "productividad", name: "Productividad", icon: "📊", count: 15 },
  { id: "educacion", name: "Educación", icon: "📚", count: 12 },
  { id: "seguridad", name: "Seguridad", icon: "🔒", count: 14 },
  { id: "redes", name: "Redes Sociales", icon: "💬", count: 9 },
  { id: "emuladores", name: "Emuladores", icon: "🕹️", count: 11 },
  { id: "lanzadores", name: "Lanzadores", icon: "🏠", count: 8 }
];

function formatDownloads(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return num.toString();
}

function getAppBySlug(slug) {
  return APPS.find(a => a.slug === slug);
}

function getFeaturedApps() {
  return APPS.filter(a => a.featured);
}

function getTopDownloaded(limit = 10) {
  return [...APPS].sort((a, b) => b.downloads - a.downloads).slice(0, limit);
}

function getRecentApps(limit = 8) {
  return [...APPS].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, limit);
}

function searchApps(query) {
  const q = query.toLowerCase().trim();
  if (!q) return APPS;
  return APPS.filter(a => 
    a.name.toLowerCase().includes(q) ||
    a.description.toLowerCase().includes(q) ||
    a.category.toLowerCase().includes(q) ||
    a.developer.toLowerCase().includes(q) ||
    a.tags.some(t => t.includes(q))
  );
}