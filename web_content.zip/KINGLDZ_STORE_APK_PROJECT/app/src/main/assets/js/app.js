// ===============================
// KINGLDZ STORE - Main App Logic
// ===============================

let currentPage = 'home';
let favorites = JSON.parse(localStorage.getItem('kingldz_favorites') || '[]');

// Toast notification
function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast ${type} show`;
  setTimeout(() => toast.classList.remove('show'), 2800);
}

// Favorites
function toggleFavorite(id) {
  id = Number(id);
  const idx = favorites.indexOf(id);
  if (idx === -1) {
    favorites.push(id);
    showToast('❤️ Añadido a favoritos');
  } else {
    favorites.splice(idx, 1);
    showToast('Eliminado de favoritos');
  }
  localStorage.setItem('kingldz_favorites', JSON.stringify(favorites));
  renderCurrentPage();
}

function isFavorite(id) {
  return favorites.includes(Number(id));
}

// Navigation
function navigate(page, params = {}) {
  currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  
  const pageEl = document.getElementById(`page-${page}`);
  if (pageEl) pageEl.classList.add('active');
  
  // Update nav active states
  document.querySelectorAll('.nav a, .mobile-nav a').forEach(a => {
    a.classList.toggle('active', a.dataset.page === page);
  });
  
  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
  
  // Render page content
  if (page === 'home') renderHome();
  else if (page === 'apps') renderApps(params);
  else if (page === 'detail') renderDetail(params.slug);
  else if (page === 'categories') renderCategories();
  else if (page === 'favorites') renderFavorites();
  else if (page === 'search') renderSearch(params.q);
}

// Helper: render app icon (image or emoji fallback)
function renderIcon(app) {
  if (app.iconImage) {
    return `<img src="assets/icons/${app.iconImage}" alt="${app.name}" onerror="this.parentElement.innerHTML='${app.icon || '📦'}'">`;
  }
  return app.icon || '📦';
}

// Render helpers
function createAppCard(app) {
  return `
    <article class="app-card" onclick="navigate('detail', {slug: '${app.slug}'})">
      <div class="app-card-header">
        <div class="app-icon">${renderIcon(app)}</div>
        <div class="app-info">
          <h3>${app.name}</h3>
          <div class="category">${app.category}</div>
          <div class="meta">v${app.version} · ${app.size}</div>
        </div>
      </div>
      <p class="app-desc">${app.description}</p>
      <div class="app-footer">
        <div class="app-stats">
          <span class="rating">★ ${app.rating}</span>
          <span>↓ ${formatDownloads(app.downloads)}</span>
        </div>
        <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); navigate('detail', {slug: '${app.slug}'})">
          Ver
        </button>
      </div>
    </article>
  `;
}

function createRankingItem(app, index) {
  return `
    <div class="ranking-item" onclick="navigate('detail', {slug: '${app.slug}'})" style="cursor:pointer">
      <div class="rank-number ${index < 3 ? 'top' : ''}">${index + 1}</div>
      <div class="rank-icon">${renderIcon(app)}</div>
      <div class="rank-info">
        <h4>${app.name}</h4>
        <p>${app.category} · ★ ${app.rating}</p>
      </div>
      <div class="rank-downloads">${formatDownloads(app.downloads)}</div>
    </div>
  `;
}

// Page renderers
function renderHome() {
  const featured = getFeaturedApps();
  const top = getTopDownloaded(8);
  const recent = getRecentApps(6);
  
  document.getElementById('featured-apps').innerHTML = featured.map(createAppCard).join('');
  document.getElementById('top-downloads').innerHTML = top.map((a, i) => createRankingItem(a, i)).join('');
  document.getElementById('recent-apps').innerHTML = recent.map(createAppCard).join('');
  
  // Categories preview
  document.getElementById('categories-preview').innerHTML = CATEGORIES.slice(0, 8).map(cat => `
    <div class="category-card" onclick="navigate('apps', {category: '${cat.name}'})">
      <div class="cat-icon">${cat.icon}</div>
      <h4>${cat.name}</h4>
    </div>
  `).join('');
}

function renderApps(params = {}) {
  let apps = [...APPS];
  let title = 'Todas las aplicaciones';
  
  if (params.category) {
    apps = apps.filter(a => a.category.toLowerCase() === params.category.toLowerCase());
    title = params.category;
  }
  
  if (params.sort === 'downloads') {
    apps.sort((a, b) => b.downloads - a.downloads);
  } else if (params.sort === 'rating') {
    apps.sort((a, b) => b.rating - a.rating);
  } else if (params.sort === 'date') {
    apps.sort((a, b) => new Date(b.date) - new Date(a.date));
  }
  
  document.getElementById('apps-page-title').textContent = title;
  document.getElementById('apps-list').innerHTML = apps.length 
    ? apps.map(createAppCard).join('') 
    : '<p style="color:var(--text-muted);text-align:center;padding:40px">No se encontraron aplicaciones.</p>';
}

function renderDetail(slug) {
  const app = getAppBySlug(slug);
  if (!app) {
    navigate('home');
    return;
  }
  
  const favActive = isFavorite(app.id);
  
  document.getElementById('detail-content').innerHTML = `
    <div class="detail-header">
      <div class="detail-icon">${renderIcon(app)}</div>
      <div class="detail-info">
        <h1>${app.name}</h1>
        <div class="detail-meta">
          <span>★ ${app.rating} (${app.votes.toLocaleString()} votos)</span>
          <span>↓ ${formatDownloads(app.downloads)} descargas</span>
          <span>${app.category}</span>
          <span>por ${app.developer}</span>
        </div>
        <div class="detail-actions">
          <button class="btn-download" onclick="startDownload('${app.name}', '${app.version}', '${app.size}')">
            ⬇ Descargar APK
          </button>
          <button class="btn btn-outline" onclick="toggleFavorite(${app.id})">
            ${favActive ? '❤️ Favorito' : '🤍 Favorito'}
          </button>
          <button class="btn btn-outline" onclick="shareApp('${app.name}', '${app.slug}')">
            ↗ Compartir
          </button>
        </div>
      </div>
    </div>
    
    <div class="detail-section">
      <h2>Acerca de esta aplicación</h2>
      <p>${app.longDescription}</p>
    </div>
    
    <div class="detail-section">
      <h2>Información</h2>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px;font-size:0.9rem">
        <div><span style="color:var(--text-muted)">Versión</span><br><strong>${app.version}</strong></div>
        <div><span style="color:var(--text-muted)">Tamaño</span><br><strong>${app.size}</strong></div>
        <div><span style="color:var(--text-muted)">Android</span><br><strong>${app.android}</strong></div>
        <div><span style="color:var(--text-muted)">Arquitectura</span><br><strong>${app.arch}</strong></div>
        <div><span style="color:var(--text-muted)">Actualizado</span><br><strong>${app.updated}</strong></div>
        <div><span style="color:var(--text-muted)">Publicado</span><br><strong>${app.date}</strong></div>
      </div>
    </div>
    
    <div class="detail-section">
      <h2>Capturas de pantalla</h2>
      <div class="screenshots">
        ${Array(app.screenshots).fill(0).map((_, i) => `
          <div class="screenshot">Captura ${i + 1}</div>
        `).join('')}
      </div>
    </div>
    
    <div class="detail-section">
      <h2>Versiones disponibles</h2>
      <div class="versions-list">
        <div class="version-item">
          <div class="ver-info">
            <span class="ver-name">v${app.version} <span style="color:var(--accent);font-size:0.8rem">· Actual</span></span>
            <span class="ver-meta">${app.size} · ${app.updated}</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="startDownload('${app.name}', '${app.version}', '${app.size}')">Descargar</button>
        </div>
        <div class="version-item">
          <div class="ver-info">
            <span class="ver-name">v${app.version.split('.').map((n,i) => i===2 ? Math.max(0,n-1) : n).join('.')}</span>
            <span class="ver-meta">${(parseFloat(app.size)-0.3).toFixed(1)} MB · 2026-08-10</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="startDownload('${app.name}', 'anterior', '${app.size}')">Descargar</button>
        </div>
        <div class="version-item">
          <div class="ver-info">
            <span class="ver-name">v${app.version.split('.').map((n,i) => i===1 ? Math.max(0,n-1) : n).join('.')}</span>
            <span class="ver-meta">${(parseFloat(app.size)-0.8).toFixed(1)} MB · 2026-07-15</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="startDownload('${app.name}', 'antigua', '${app.size}')">Descargar</button>
        </div>
      </div>
    </div>
  `;
}

function renderCategories() {
  document.getElementById('categories-list').innerHTML = CATEGORIES.map(cat => `
    <div class="category-card" onclick="navigate('apps', {category: '${cat.name}'})">
      <div class="cat-icon">${cat.icon}</div>
      <h4>${cat.name}</h4>
      <p style="font-size:0.8rem;color:var(--text-muted);margin-top:4px">${cat.count} apps</p>
    </div>
  `).join('');
}

function renderFavorites() {
  const favApps = APPS.filter(a => favorites.includes(a.id));
  const container = document.getElementById('favorites-list');
  
  if (favApps.length === 0) {
    container.innerHTML = `
      <div style="text-align:center;padding:60px 20px;color:var(--text-muted)">
        <div style="font-size:3rem;margin-bottom:16px">🤍</div>
        <h3 style="margin-bottom:8px;color:#fff">No tienes favoritos aún</h3>
        <p>Explora aplicaciones y guarda las que más te gusten</p>
        <button class="btn btn-primary" style="margin-top:20px" onclick="navigate('apps')">Explorar apps</button>
      </div>
    `;
  } else {
    container.innerHTML = favApps.map(createAppCard).join('');
  }
}

function renderSearch(query) {
  const results = searchApps(query || '');
  document.getElementById('search-query-display').textContent = query ? `"${query}"` : 'Todas';
  document.getElementById('search-results').innerHTML = results.length
    ? results.map(createAppCard).join('')
    : '<p style="color:var(--text-muted);text-align:center;padding:40px">No se encontraron resultados.</p>';
}

// Download simulation
function startDownload(name, version, size) {
  showToast(`⬇ Iniciando descarga: ${name} (${size})`);
  // In a real app this would trigger the actual APK download
  setTimeout(() => {
    showToast(`✅ ${name} listo para instalar`);
  }, 2000);
}

// Share
function shareApp(name, slug) {
  const url = window.location.origin + window.location.pathname + '#detail/' + slug;
  if (navigator.share) {
    navigator.share({ title: name + ' - KINGLDZ STORE', url });
  } else {
    navigator.clipboard.writeText(url).then(() => showToast('🔗 Enlace copiado'));
  }
}

// Search handling
function handleSearch(e) {
  e.preventDefault();
  const q = document.getElementById('search-input').value.trim();
  navigate('search', { q });
}

function handleMobileSearch(e) {
  e.preventDefault();
  const q = document.getElementById('mobile-search-input').value.trim();
  navigate('search', { q });
  document.getElementById('mobile-search-overlay').classList.add('hidden');
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  // Hash routing simple
  const hash = window.location.hash.slice(1);
  if (hash.startsWith('detail/')) {
    navigate('detail', { slug: hash.replace('detail/', '') });
  } else if (hash === 'apps') {
    navigate('apps');
  } else if (hash === 'categories') {
    navigate('categories');
  } else if (hash === 'favorites') {
    navigate('favorites');
  } else {
    navigate('home');
  }
  
  // Search form
  const searchForm = document.getElementById('search-form');
  if (searchForm) searchForm.addEventListener('submit', handleSearch);
});

// Expose for onclick
window.navigate = navigate;
window.toggleFavorite = toggleFavorite;
window.startDownload = startDownload;
window.shareApp = shareApp;
window.handleSearch = handleSearch;
window.handleMobileSearch = handleMobileSearch;