KINGLDZ STORE — Android WebView project

Open this folder in Android Studio and build:
Build > Generate App Bundles or APKs > Generate APKs

The website files are in app/src/main/assets/.
Application ID: com.kingldz.store
Version: 1.0 (1)
