/* ============================================================
   СЛОВАРЬ ПРОСТЫХ СЛОВ (уровень A1-A2)
   Формат: французское_слово|русский_перевод
   - Не повторяйте одно и то же французское слово дважды
   - Внутри файла — только эта одна переменная, ничего больше
   - Всего слов: ~2050
   ============================================================ */

window.WORDS_EASY = `

/* ---------- ПРИВЕТСТВИЯ И ВЕЖЛИВОСТЬ ---------- */
bonjour|здравствуйте
bonsoir|добрый вечер
salut|привет
coucou|приветик
au revoir|до свидания
à bientôt|до скорого
à demain|до завтра
à tout à l'heure|до скорого
bonne nuit|спокойной ночи
bonne journée|хорошего дня
bonne soirée|хорошего вечера
bon week-end|хороших выходных
merci|спасибо
merci beaucoup|большое спасибо
mille mercis|тысяча благодарностей
de rien|не за что
je vous en prie|пожалуйста
s'il vous plaît|пожалуйста
s'il te plaît|пожалуйста (ты)
pardon|извините
excusez-moi|извините меня
désolé|извините
je suis désolé|я сожалею
ce n'est pas grave|ничего страшного
oui|да
non|нет
peut-être|может быть
bien sûr|конечно
d'accord|согласен
pas du tout|вовсе нет
absolument|абсолютно
comment ça va|как дела
ça va bien|всё хорошо
ça va mal|всё плохо
comme ci comme ça|так себе
enchanté|приятно познакомиться
comment tu t'appelles|как тебя зовут
je m'appelle|меня зовут
je ne comprends pas|я не понимаю
parlez-vous anglais|вы говорите по-английски
je ne parle pas français|я не говорю по-французски
parlez plus lentement|говорите медленнее
pouvez-vous répéter|можете повторить
bienvenue|добро пожаловать
félicitations|поздравления
bon anniversaire|с днём рождения
bonne chance|удачи
bon voyage|счастливого пути
bon appétit|приятного аппетита
santé|за здоровье
à votre santé|за ваше здоровье
joyeux Noël|счастливого Рождества
bonne année|с Новым годом

/* ---------- ЧИСЛА ---------- */
zéro|ноль
un|один
deux|два
trois|три
quatre|четыре
cinq|пять
six|шесть
sept|семь
huit|восемь
neuf|девять
dix|десять
onze|одиннадцать
douze|двенадцать
treize|тринадцать
quatorze|четырнадцать
quinze|пятнадцать
seize|шестнадцать
dix-sept|семнадцать
dix-huit|восемнадцать
dix-neuf|девятнадцать
vingt|двадцать
vingt et un|двадцать один
vingt-deux|двадцать два
vingt-trois|двадцать три
trente|тридцать
trente et un|тридцать один
quarante|сорок
cinquante|пятьдесят
soixante|шестьдесят
soixante-dix|семьдесят
soixante et onze|семьдесят один
quatre-vingts|восемьдесят
quatre-vingt-dix|девяносто
cent|сто
deux cents|двести
cinq cents|пятьсот
mille|тысяча
deux mille|две тысячи
un million|миллион
un milliard|миллиард

/* ---------- ПОРЯДКОВЫЕ ЧИСЛИТЕЛЬНЫЕ ---------- */
premier|первый
deuxième|второй
troisième|третий
quatrième|четвёртый
cinquième|пятый
sixième|шестой
septième|седьмой
huitième|восьмой
neuvième|девятый
dixième|десятый
dernier|последний

/* ---------- ДНИ, МЕСЯЦЫ, СЕЗОНЫ ---------- */
lundi|понедельник
mardi|вторник
mercredi|среда
jeudi|четверг
vendredi|пятница
samedi|суббота
dimanche|воскресенье
janvier|январь
février|февраль
mars|март
avril|апрель
mai|май
juin|июнь
juillet|июль
août|август
septembre|сентябрь
octobre|октябрь
novembre|ноябрь
décembre|декабрь
le printemps|весна
l'été|лето
l'automne|осень
l'hiver|зима
la saison|сезон
la matinée|утро
la soirée|вечер

/* ---------- ВРЕМЯ И ВРЕМЯ СУТОК ---------- */
aujourd'hui|сегодня
demain|завтра
hier|вчера
avant-hier|позавчера
après-demain|послезавтра
maintenant|сейчас
tout de suite|сразу
bientôt|скоро
toujours|всегда
jamais|никогда
souvent|часто
parfois|иногда
rarement|редко
déjà|уже
encore|ещё
avant|до
après|после
tôt|рано
tard|поздно
le jour|день
la nuit|ночь
le matin|утро
l'après-midi|после обеда
le soir|вечер
la semaine|неделя
le mois|месяц
l'année|год
l'heure|час
la minute|минута
la seconde|секунда
le temps|время
le moment|момент
la fois|раз
l'aube|рассвет
l'aurore|заря
le crépuscule|сумерки
midi|полдень
minuit|полночь
le quart d'heure|четверть часа
la demi-heure|полчаса
le début|начало
la fin|конец
la moitié|половина
le quart|четверть

/* ---------- ЦВЕТА ---------- */
rouge|красный
bleu|синий
vert|зелёный
jaune|жёлтый
noir|чёрный
blanc|белый
gris|серый
orange|оранжевый
violet|фиолетовый
rose|розовый
marron|коричневый
beige|бежевый
turquoise|бирюзовый
doré|золотой
argenté|серебряный
pourpre|пурпурный
bleu clair|голубой
bleu foncé|тёмно-синий
vert clair|светло-зелёный

/* ---------- СЕМЬЯ ---------- */
la famille|семья
la mère|мать
la maman|мама
le père|отец
le papa|папа
les parents|родители
le frère|брат
la sœur|сестра
le fils|сын
la fille|дочь
l'enfant|ребёнок
le bébé|малыш
la grand-mère|бабушка
le grand-père|дедушка
les grands-parents|бабушка и дедушка
l'arrière-grand-mère|прабабушка
l'arrière-grand-père|прадедушка
l'oncle|дядя
la tante|тётя
le cousin|двоюродный брат
la cousine|двоюродная сестра
le mari|муж
la femme|жена
l'époux|супруг
l'épouse|супруга
le neveu|племянник
la nièce|племянница
l'ami|друг
l'amie|подруга
le meilleur ami|лучший друг
le petit ami|парень
la petite amie|девушка
le fiancé|жених
la fiancée|невеста
le voisin|сосед
la voisine|соседка
le collègue|коллега
le copain|приятель
la copine|приятельница
le demi-frère|сводный брат
la demi-sœur|сводная сестра
le beau-père|отчим, тесть
la belle-mère|мачеха, тёща
le beau-frère|шурин, зять
la belle-sœur|свояченица, невестка
le parrain|крёстный отец
la marraine|крёстная мать
le filleul|крестник
la filleule|крестница

/* ---------- ЧАСТИ ТЕЛА ---------- */
le corps|тело
la tête|голова
le visage|лицо
les cheveux|волосы
le front|лоб
les sourcils|брови
l'œil|глаз
les yeux|глаза
le nez|нос
la bouche|рот
les lèvres|губы
l'oreille|ухо
la dent|зуб
la langue|язык
le menton|подбородок
la joue|щека
le cou|шея
la gorge|горло
l'épaule|плечо
le bras|рука
la main|кисть руки
le doigt|палец
le pouce|большой палец
l'ongle|ноготь
le coude|локоть
le poignet|запястье
le dos|спина
la poitrine|грудь
le ventre|живот
la taille|талия
la hanche|бедро
la jambe|нога
le genou|колено
la cheville|лодыжка
le pied|ступня
le talon|пятка
le cœur|сердце
le sang|кровь
l'os|кость
la peau|кожа
le cerveau|мозг
le poumon|легкое
le foie|печень
l'estomac|желудок
le rein|почка
le muscle|мышца
le nerf|нерв
la barbe|борода
la moustache|усы
la paume|ладонь
le poing|кулак
l'avant-bras|предплечье
le mollet|икра ноги
la cuisse|бедро
l'index|указательный палец
le majeur|средний палец
l'annulaire|безымянный палец
l'auriculaire|мизинец

/* ---------- ЕДА ---------- */
le pain|хлеб
la baguette|багет
le croissant|круассан
la brioche|бриошь
le sandwich|бутерброд
le hamburger|гамбургер
la pizza|пицца
les pâtes|макароны
le riz|рис
la soupe|суп
la salade|салат
le fromage|сыр
le beurre|сливочное масло
l'huile|масло
le vinaigre|уксус
le sel|соль
le poivre|перец
le sucre|сахар
la farine|мука
le miel|мёд
la confiture|варенье
le chocolat|шоколад
le bonbon|конфета
le biscuit|печенье
le gâteau|торт
la tarte|пирог
la glace|мороженое
le yaourt|йогурт
la crème|сливки
le dessert|десерт
la confiserie|сладости
la viande|мясо
le bœuf|говядина
le porc|свинина
le poulet|курица
le poisson|рыба
le jambon|ветчина
la saucisse|колбаса
l'œuf|яйцо
la salade verte|зелёный салат
le potage|суп-пюре
la tartine|бутерброд на хлебе
le gratin|запеканка
la quiche|киш
la purée|пюре
les frites|картошка фри
la sauce|соус
le bouillon|бульон
les céréales|хлопья
la pâtisserie|пирожное
la viennoiserie|сдоба
la charcuterie|колбасные изделия
les fruits de mer|морепродукты
la crêpe|блин
la gauffre|вафля
le pain d'épices|пряник
la bague|бублик
la bretzel|крендель

/* ---------- НАПИТКИ ---------- */
l'eau|вода
le lait|молоко
le café|кофе
le thé|чай
le chocolat chaud|горячий шоколад
le vin|вино
le vin rouge|красное вино
le vin blanc|белое вино
le champagne|шампанское
la bière|пиво
le cidre|сидр
le jus|сок
le jus d'orange|апельсиновый сок
le jus de pomme|яблочный сок
la limonade|лимонад
le sirop|сироп
le cocktail|коктейль
le whisky|виски
la vodka|водка
le rhum|ром

/* ---------- ОВОЩИ ---------- */
la tomate|помидор
la pomme de terre|картофель
la carotte|морковь
l'oignon|лук
l'ail|чеснок
la courgette|кабачок
l'aubergine|баклажан
le poivron|перец овощ
le concombre|огурец
le chou|капуста
le brocoli|брокколи
les petits pois|горошек
les haricots|фасоль
le maïs|кукуруза
le champignon|гриб
la betterave|свёкла
la citrouille|тыква
l'épinard|шпинат
la laitue|салат-латук
le radis|редис
le navet|репа
le panais|пастернак
la courge|тыква
le potiron|крупная тыква
le poireau|лук-порей
l'échalote|шалот
la ciboulette|лук-резанец
le persil|петрушка
la coriandre|кориандр
le basilic|базилик
la menthe|мята
le thym|тимьян
le romarin|розмарин
la sauge|шалфей
l'aneth|укроп

/* ---------- ФРУКТЫ И ЯГОДЫ ---------- */
la pomme|яблоко
la banane|банан
l'orange|апельсин
la fraise|клубника
le raisin|виноград
le citron|лимон
la pêche|персик
l'abricot|абрикос
la cerise|вишня
la prune|слива
la poire|груша
le melon|дыня
la pastèque|арбуз
l'ananas|ананас
la mangue|манго
le kiwi|киви
la framboise|малина
la myrtille|черника
la mûre|ежевика
la groseille|смородина
la noix|орех
la noisette|лесной орех
l'amande|миндаль
la châtaigne|каштан
le figue|инжир
la datte|финик
la grenade|гранат
la clémentine|клементин
le pamplemousse|грейпфрут
le cassis|чёрная смородина
la rhubarbe|ревень
la nectarine|нектарин
la mirabelle|мирабель

/* ---------- ДОМАШНИЕ ЖИВОТНЫЕ ---------- */
le chat|кот
le chien|собака
le lapin|кролик
le hamster|хомяк
la souris|мышь
le cheval|лошадь
la vache|корова
le cochon|свинья
le mouton|овца
la chèvre|коза
l'âne|осёл
la poule|курица
le canard|утка
l'oie|гусь
le taureau|бык
le veau|телёнок
le poulain|жеребёнок
le chaton|котёнок
le chiot|щенок
l'agneau|ягнёнок
le caneton|утёнок
le poussin|цыплёнок
l'oison|гусёнок
le lapereau|крольчонок
le chevreau|козлёнок
le porcelet|поросёнок

/* ---------- ДИКИЕ ЖИВОТНЫЕ ---------- */
le lion|лев
le tigre|тигр
l'éléphant|слон
le singe|обезьяна
l'ours|медведь
le loup|волк
le renard|лиса
le cerf|олень
le sanglier|кабан
le lièvre|заяц
l'écureuil|белка
le hérisson|ёж
la chauve-souris|летучая мышь
le rat|крыса
la girafe|жираф
le zèbre|зебра
le kangourou|кенгуру
le panda|панда
le rhinocéros|носорог
l'hippopotame|бегемот
le chameau|верблюд
le dromadaire|одногорбый верблюд
le crocodile|крокодил
le serpent|змея
le lézard|ящерица
la tortue|черепаха
la grenouille|лягушка
le blaireau|барсук
la belette|ласка
le putois|хорёк
la fouine|куница
la loutre|выдра
le castor|бобр
la taupe|крот
le loir|соня
l'ourson|медвежонок
le faon|оленёнок
le louveteau|волчонок
le renardeau|лисёнок

/* ---------- ПТИЦЫ И НАСЕКОМЫЕ ---------- */
l'oiseau|птица
le pigeon|голубь
la mouette|чайка
l'aigle|орёл
le hibou|сова
le corbeau|ворон
le moineau|воробей
le cygne|лебедь
le paon|павлин
la cigogne|аист
le pingouin|пингвин
le perroquet|попугай
l'abeille|пчела
la guêpe|оса
la fourmi|муравей
la mouche|муха
le moustique|комар
le papillon|бабочка
l'araignée|паук
la coccinelle|божья коровка
l'escargot|улитка
le ver|червяк
la libellule|стрекоза
la sauterelle|кузнечик
le grillon|сверчок
le cafard|таракан
la mite|моль
la puce|блоха
le merle|дрозд
le rouge-gorge|малиновка
la mésange|синица
l'hirondelle|ласточка
l'alouette|жаворонок
le rossignol|соловей
le coucou|кукушка
le pic-vert|дятел
la chouette|сова (без ушек)
le faucon|сокол
le vautour|гриф

/* ---------- МОРСКИЕ ЖИВОТНЫЕ ---------- */
la baleine|кит
le dauphin|дельфин
le requin|акула
la pieuvre|осьминог
la méduse|медуза
le crabe|краб
la crevette|креветка
la truite|форель
le saumon|лосось
le thon|тунец
la sardine|сардина
le homard|лобстер
l'huître|устрица
la moule|мидия
l'étoile de mer|морская звезда
l'oursin|морской ёж
l'hippocampe|морской конёк
la murène|мурена
le phoque|тюлень
l'orque|косатка

/* ---------- ДОМ И КОМНАТЫ ---------- */
la maison|дом
l'appartement|квартира
la porte|дверь
la fenêtre|окно
le mur|стена
le toit|крыша
le sol|пол
le plafond|потолок
la chambre|комната
la cuisine|кухня
la salle de bain|ванная
les toilettes|туалет
le salon|гостиная
la salle à manger|столовая
le couloir|коридор
l'entrée|прихожая
le garage|гараж
la cave|подвал
le grenier|чердак
le balcon|балкон
la terrasse|terrasse
le jardin|сад
l'escalier|лестница
l'ascenseur|лифт
la buanderie|прачечная
le cellier|кладовая
le vestibule|прихожая
le palier|лестничная площадка
le rez-de-chaussée|первый этаж
l'étage|этаж
le sous-sol|подвал
la remise|сарай
la cabane|хижина
le chalet|домик
la tente|палатка
le camping|кемпинг
la tente de camping|походная палатка

/* ---------- МЕБЕЛЬ И ПРЕДМЕТЫ ДОМА ---------- */
la table|стол
la chaise|стул
le fauteuil|кресло
le lit|кровать
l'armoire|шкаф
le canapé|диван
la lampe|лампа
le miroir|зеркало
le tapis|ковёр
le rideau|штора
l'oreiller|подушка
la couverture|одеяло
le drap|простыня
la serviette|полотенце
la baignoire|ванна
la douche|душ
le buffet|буфет
la commode|комод
la bibliothèque|библиотека (мебель)
l'étagère|полка
le tabouret|табурет
le banc|скамья
le hamac|гамак
le paravent|ширма
le porte-manteau|вешалка
le cintre|плечики
la taie d'oreiller|наволочка
le réveil|будильник
la poussière|пыль
le désordre|беспорядок
l'ordre|порядок
le chiffon|тряпка
l'éponge|губка

/* ---------- ПОСУДА И КУХОННЫЕ ПРИБОРЫ ---------- */
le verre|стакан
la tasse|чашка
l'assiette|тарелка
le bol|миска
la cuillère|ложка
la fourchette|вилка
le couteau|нож
la serviette de table|салфетка
la casserole|кастрюля
la poêle|сковорода
le four|духовка
le frigo|холодильник
l'évier|раковина
la bouteille|бутылка
la boîte|коробка
le bouchon|пробка
la plaque|плита
le micro-ondes|микроволновка
la bouilloire|чайник
le grille-pain|тостер
le mixeur|блендер
la râpe|тёрка
le couvercle|крышка
la passoire|дуршлаг
la planche à découper|доска
le verre à pied|бокал
le pichet|кувшин
le pot|банка
la spatule|лопатка
la louche|половник
le tire-bouchon|штопор
l'ouvre-boîte|консервный нож
la balance|весы

/* ---------- ОДЕЖДА И АКСЕССУАРЫ ---------- */
la chemise|рубашка
le tee-shirt|футболка
le pantalon|брюки
le jean|джинсы
la robe|платье
la jupe|юбка
le manteau|пальто
la veste|куртка
le pull|свитер
le sweat|толстовка
la chaussure|обувь
le chapeau|шляпа
la casquette|кепка
l'écharpe|шарф
les gants|перчатки
les chaussettes|носки
la botte|сапог
la ceinture|пояс
la cravate|галстук
le bouton|пуговица
la poche|карман
la manche|рукав
le col|воротник
la sandale|сандалия
la basket|кроссовок
la bottine|ботинок
le short|шорты
le maillot de bain|купальник
le collier|ожерелье
la bague|кольцо
le bracelet|браслет
les boucles d'oreilles|серьги
le parfum|духи
le sac|сумка
les lunettes de soleil|солнечные очки
le foulard|шарф
le béret|берет
le maillot|майка
le débardeur|майка без рукавов
le polo|поло
le chemisier|блузка
le gilet|жилет
le blouson|куртка
la parka|парка
le survêtement|спортивный костюм
les baskets|кроссовки
la doudoune|пуховик
l'imperméable|плащ
la salopette|комбинезон

/* ---------- УКРАШЕНИЯ И ЛИЧНЫЕ ВЕЩИ ---------- */
le portefeuille|кошелёк
les lunettes|очки
le parapluie|зонт
le peigne|расчёска
la brosse à dents|зубная щётка
le savon|мыло
la montre|часы наручные
le bijou|украшение
le mouchoir|платок
le sac à main|сумочка

/* ---------- ТРАНСПОРТ ---------- */
la voiture|машина
le vélo|велосипед
le train|поезд
l'avion|самолёт
le bus|автобус
le car|автобус междугородний
le métro|метро
le tramway|трамвай
le taxi|такси
la moto|мотоцикл
le camion|грузовик
le bateau|лодка
le navire|корабль
l'hélicoptère|вертолёт
la fusée|ракета
le tracteur|трактор
le scooter|скутер
la gare|вокзал
l'aéroport|аэропорт
le port|порт
la station|станция
l'arrêt|остановка
le billet|билет
le quai|перрон
la route|дорога
l'autoroute|шоссе
le chemin|путь
le pont|мост
le carrefour|перекрёсток
le feu rouge|красный свет
le parking|парковка
le trolley|троллейбус
le funiculaire|фуникулёр
le ferry|паром
la barque|лодка
le canoë|каноэ
le kayak|каяк
le voilier|парусник
le cargo|грузовое судно
la berline|седан
le break|универсал
le cabriolet|кабриолет
le camion de livraison|фургон доставки

/* ---------- ШКОЛА И УЧЁБА ---------- */
l'école|школа
l'université|университет
le collège|средняя школа
le lycée|лицей
le professeur|учитель
le maître|учитель (мл. классы)
la maîtresse|учительница
l'élève|ученик
l'étudiant|студент
la leçon|урок
le cours|занятие
la classe|класс
le devoir|домашнее задание
l'examen|экзамен
la note|оценка
le livre|книга
le cahier|тетрадь
le stylo|ручка
le crayon|карандаш
la gomme|ластик
la règle|линейка
le sac à dos|рюкзак
la bibliothèque|библиотека
la salle de classe|классная комната
le tableau|доска
la craie|мел
le compas|циркуль
le rapporteur|транспортир
la trousse|пенал
le surligneur|маркер
la colle|клей
les ciseaux|ножницы
le taille-crayon|точилка
le feutre|фломастер
la feuille|лист
le classeur|папка
la récréation|перемена
la cantine|столовая
l'institutrice|учительница
le cartable|портфель
la rentrée|начало учебного года
les vacances|каникулы

/* ---------- ПРОФЕССИИ ---------- */
le médecin|врач
l'infirmier|медбрат
l'infirmière|медсестра
l'avocat|адвокат
le juge|судья
le policier|полицейский
le pompier|пожарный
le soldat|солдат
le facteur|почтальон
le boulanger|пекарь
le boucher|мясник
le cuisinier|повар
le serveur|официант
le vendeur|продавец
le coiffeur|парикмахер
le mécanicien|механик
le plombier|сантехник
l'électricien|электрик
le menuisier|плотник
le maçon|каменщик
le peintre|художник
l'architecte|архитектор
l'ingénieur|инженер
le comptable|бухгалтер
le secrétaire|секретарь
le directeur|директор
l'employé|служащий
l'ouvrier|рабочий
le paysan|крестьянин
le pêcheur|рыбак
le chasseur|охотник
le jardinier|садовник
le fleuriste|флорист
le pharmacien|аптекарь
le dentiste|стоматолог
le vétérinaire|ветеринар
le journaliste|журналист
l'écrivain|писатель
le musicien|музыкант
le chanteur|певец
l'acteur|актёр
le danseur|танцор
le sportif|спортсмен
le livreur|курьер
le traducteur|переводчик
le photographe|фотограф
le guide|гид
le barman|бармен
le pâtissier|кондитер
le fromager|сыровар

/* ---------- МЕСТА В ГОРОДЕ ---------- */
la ville|город
le village|деревня
le quartier|район
la rue|улица
la place|площадь
le magasin|магазин
la boutique|лавка
le supermarché|супермаркет
le marché|рынок
la boulangerie|пекарня
la boucherie|мясная лавка
la pharmacie|аптека
le restaurant|ресторан
le café|кафе
l'hôtel|отель
la plage|пляж
le parc|парк
l'église|церковь
l'hôpital|больница
la banque|банк
la poste|почта
le cinéma|кинотеатр
le musée|музей
le théâtre|театр
la mairie|мэрия
le commissariat|полицейский участок
la librairie|книжный магазин
la station-service|заправка
le stade|стадион
la piscine|бассейн
l'immeuble|здание
le bâtiment|строение
le gratte-ciel|небоскрёб
la tour|башня
le château|замок
la cathédrale|собор
le temple|храм
le cimetière|кладбище
l'opéra|опера
le palais|дворец
la prison|тюрьма
le tribunal|суд

/* ---------- ПРИРОДА ---------- */
le soleil|солнце
la lune|lune
le ciel|небо
la mer|море
l'océan|океан
la montagne|гора
la colline|холм
la rivière|река
le fleuve|река (впадает в море)
le lac|озеро
la forêt|лес
l'arbre|дерево
la fleur|цветок
l'herbe|трава
la terre|земля
la pierre|камень
le feu|огонь
l'air|воздух
la pluie|дождь
la neige|снег
le vent|ветер
le nuage|облако
l'orage|гроза
la glace|лёд
le brouillard|туман
l'étoile|звезда
le sable|песок
la vague|волна
la feuille|лист
la branche|ветка
la racine|корень
la graine|семя
le ruisseau|ручей
la mare|пруд
l'étang|пруд
la flaque|лужа
le pré|луг
le buisson|куст
le bosquet|роща
la clairière|поляна
le sentier|тропинка

/* ---------- ПОГОДА (выражения) ---------- */
il fait beau|хорошая погода
il fait mauvais|плохая погода
il fait chaud|жарко
il fait froid|холодно
il pleut|идёт дождь
il neige|идёт снег
il y a du vent|ветрено
il y a du soleil|солнечно
il y a des nuages|облачно
il y a du brouillard|туманно
il fait lourd|душно
il fait humide|влажно
il gèle|морозит
il dégèle|оттепель

/* ---------- ГЛАГОЛЫ БАЗОВЫЕ ---------- */
être|быть
avoir|иметь
aller|идти
faire|делать
dire|говорить
pouvoir|мочь
vouloir|хотеть
devoir|долженствовать
savoir|знать
voir|видеть
venir|приходить
prendre|брать
donner|давать
parler|говорить
aimer|любить
adorer|обожать
détester|ненавидеть
manger|кушать
boire|пить
dormir|спать
lire|читать
écrire|писать
écouter|слушать
entendre|слышать
regarder|смотреть
travailler|работать
jouer|играть
marcher|ходить
courir|бегать
acheter|покупать
payer|платить
ouvrir|открывать
fermer|закрывать
commencer|начинать
finir|заканчивать
attendre|ждать
aider|помогать
chercher|искать
trouver|находить
apprendre|учить
comprendre|понимать
oublier|забывать
penser|думать
croire|верить
vivre|жить
partir|уезжать
arriver|приезжать
rester|оставаться
rentrer|возвращаться
sortir|выходить
entrer|входить
monter|подниматься
descendre|спускаться
nager|плавать
chanter|петь
danser|танцевать
rire|смеяться
pleurer|плакать
répondre|отвечать
demander|спрашивать
remercier|благодарить
appeler|звонить
tomber|падать
laver|мыть
conduire|водить
connaître|знать
mettre|класть
tenir|держать
devenir|становиться
crier|кричать
sauter|прыгать
lever|поднимать
pousser|толкать
tirer|тянуть
jeter|бросать
attraper|ловить
lancer|кидать
porter|нести
poser|класть
garder|хранить
montrer|показывать
cacher|прятать
perdre|терять
gagner|выигрывать
voler|летать, воровать
tourner|вращать
avancer|продвигаться
reculer|отступать
continuer|продолжать
revenir|возвращаться
souhaiter|желать
espérer|надеяться
préférer|предпочитать
essayer|пробовать
réussir|удаваться
rater|проваливать
choisir|выбирать
décider|решать
changer|менять
créer|создавать
construire|строить
casser|ломать
réparer|ремонтировать
nettoyer|чистить
ranger|убирать
cuisiner|готовить
goûter|пробовать
sentir|чувствовать
toucher|трогать
raconter|рассказывать
expliquer|объяснять
décrire|описывать
reconnaître|узнавать
remarquer|замечать
observer|наблюдать
imaginer|воображать
rêver|мечтать
promettre|обещать
mentir|лгать
avouer|признавать
protéger|защищать
défendre|защищать
attaquer|атаковать
blesser|ранить
guérir|лечить
habiter|жить
ajouter|добавлять
arroser|поливать
brancher|подключать
charger|заряжать
cliquer|кликать
coller|приклеивать
commander|заказывать
confirmer|подтверждать
couper|резать
découper|вырезать
déranger|беспокоить
dessiner|рисовать
effacer|стирать
emprunter|одалживать (взять)
envoyer|отправлять
gonfler|надувать
imprimer|печатать
installer|устанавливать
inviter|приглашать
laisser|оставлять
louer|арендовать
mélanger|смешивать
mesurer|измерять
mouiller|мочить
multiplier|умножать
noter|записывать
offrir|дарить
partager|делить
passer|проходить
peser|весить
plier|складывать
préparer|готовить
prêter|одалживать (дать)
recopier|переписывать
refuser|отказывать
remplir|наполнять
rencontrer|встречать
rendre|возвращать
répéter|повторять
réserver|бронировать
ressembler|быть похожим
retourner|возвращать
réveiller|будить
signer|подписывать
sonner|звонить (в дверь)
souffler|дуть
suivre|следовать
téléphoner|звонить по телефону
terminer|заканчивать
tremper|мочить, макать
utiliser|использовать
vider|опустошать
visiter|посещать
voyager|путешествовать

/* ---------- ВОЗВРАТНЫЕ ГЛАГОЛЫ ---------- */
s'asseoir|садиться
se lever|вставать
se coucher|ложиться
se réveiller|просыпаться
s'endormir|засыпать
se laver|мыться
se doucher|принимать душ
s'habiller|одеваться
se déshabiller|раздеваться
se promener|гулять
s'amuser|развлекаться
se reposer|отдыхать
s'inquiéter|беспокоиться
se fâcher|сердиться
s'ennuyer|скучать
se dépêcher|торопиться
se souvenir|вспоминать
s'excuser|извиняться
se marier|жениться
s'appeler|называться
se brosser les dents|чистить зубы
se coiffer|причёсываться
se maquiller|краситься
se raser|бриться
se couper|порезаться
se casser|сломать (себе)
se blesser|пораниться
se tromper|ошибаться
s'habituer|привыкать
se couvrir|укрываться
se découvrir|раскрываться
se mettre à|приниматься
s'occuper de|заботиться о

/* ---------- ПРИЛАГАТЕЛЬНЫЕ ---------- */
grand|большой
petit|маленький
bon|хороший
mauvais|плохой
beau|красивый
joli|хорошенький
laid|уродливый
nouveau|новый
vieux|старый
jeune|молодой
chaud|горячий
froid|холодный
tiède|тёплый
frais|свежий
facile|простой
difficile|трудный
heureux|счастливый
malheureux|несчастный
triste|грустный
riche|богатый
pauvre|бедный
long|длинный
court|короткий
haut|высокий
bas|низкий
fort|сильный
faible|слабый
rapide|быстрый
lent|медленный
propre|чистый
sale|грязный
plein|полный
vide|пустой
cher|дорогой
lourd|тяжёлый
léger|лёгкий
content|довольный
fatigué|уставший
malade|больной
gentil|милый
méchant|злой
intelligent|умный
bête|глупый
drôle|смешной
sérieux|серьёзный
clair|светлый
sombre|тёмный
vif|яркий
pâle|бледный
brillant|блестящий
doux|мягкий
dur|твёрдый
souple|гибкий
épais|толстый
mince|тонкий
large|широкий
étroit|узкий
profond|глубокий
rond|круглый
carré|квадратный
pointu|острый
lisse|гладкий
humide|влажный
sec|сухой
mouillé|мокрый
gras|жирный
maigre|худой
gros|толстый
fin|тонкий
ouvert|открытый
fermé|закрытый
libre|свободный
occupé|занятый
seul|одинокий
sucré|сладкий
salé|солёный
amer|горький
acide|кислый
épicé|острый
délicieux|вкусный
poli|вежливый
impoli|невежливый
sincère|искренний
vrai|правдивый
faux|ложный
juste|справедливый
sage|мудрый
calme|спокойный
nerveux|нервный
timide|застенчивый
courageux|смелый
paresseux|ленивый
travailleur|трудолюбивый
fidèle|верный
jaloux|ревнивый
amoureux|влюблённый
surpris|удивлённый
célèbre|известный
célibataire|холостой
marié|женатый
prêt|готовый
plat|плоский
solide|прочный
joyeux|радостный
fâché|сердитый
inquiet|обеспокоенный
confus|смущённый
fier|гордый
honteux|пристыженный
déçu|разочарованный
effrayé|испуганный
étonné|удивлённый
ému|растроганный
agacé|раздражённый
gêné|смущённый
ravi|восхищённый
penaud|пристыженный
soulagé|обрадованный

/* ---------- МЕСТОИМЕНИЯ ---------- */
je|я
tu|ты
il|он
elle|она
on|мы (обобщ.)
nous|мы
vous|вы
ils|они
elles|они (ж.р.)
moi|мне, меня
toi|тебе, тебя
lui|ему, его
leur|им, их

/* ---------- ПРЕДЛОГИ ---------- */
avec|с
sans|без
pour|для
contre|против
sur|на
sous|под
dans|в
chez|у
vers|к
pendant|во время
depuis|с
jusqu'à|до
entre|между
devant|перед
derrière|за
à côté de|рядом с
loin de|далеко от
près de|близко от
par|через
en|в (стране)
au|в (место)
aux|у, при

/* ---------- СОЮЗЫ, НАРЕЧИЯ, ВОПРОСЫ ---------- */
et|и
ou|или
mais|но
parce que|потому что
si|если
quand|когда
où|где
comment|как
pourquoi|почему
combien|сколько
qui|кто
quoi|что
quel|какой
quelle|какая
ici|здесь
là|там
là-bas|вон там
partout|везде
nulle part|нигде
quelque part|где-то
dehors|снаружи
dedans|внутри
dessus|сверху
dessous|снизу
aussi|тоже
non plus|тоже нет
beaucoup|много
peu|мало
très|очень
trop|слишком
assez|достаточно
plus|больше
moins|меньше
bien|хорошо
mal|плохо
mieux|лучше
vite|быстро
lentement|медленно
ensemble|вместе
surtout|особенно
presque|почти
environ|около
seulement|только
déjà|уже
encore|ещё
enfin|наконец
alors|тогда
donc|значит
cependant|однако
pourtant|всё же
en effet|в самом деле
par exemple|например
en fait|на самом деле

/* ---------- СПОРТ ---------- */
le sport|спорт
le football|футбол
le basketball|баскетбол
le tennis|теннис
le rugby|регби
la natation|плавание
le cyclisme|велоспорт
la course|бег
le ski|лыжи
le patinage|коньки
la boxe|бокс
le judo|дзюдо
la gymnastique|гимнастика
le yoga|йога
le golf|гольф
le hockey|хоккей
le baseball|бейсбол
le volleyball|волейбол
le match|матч
l'équipe|команда
le joueur|игрок
le ballon|мяч
le ballon de foot|футбольный мяч
la raquette|ракетка
la crosse|клюшка
le casque|шлем
le maillot|спортивная форма
le ring|ринг
la piste|трасса
le terrain|поле
la coupe|кубок
la médaille|медаль
le champion|чемпион

/* ---------- МУЗЫКА И ИСКУССТВО ---------- */
le piano|пианино
la guitare|гитара
le violon|скрипка
la flûte|флейта
la trompette|труба
le tambour|барабан
le saxophone|саксофон
l'accordéon|аккордеон
la musique|музыка
la chanson|песня
le concert|концерт
l'orchestre|оркестр
le tableau|картина
la peinture|живопись
le dessin|рисунок
le cinéma|кино
le film|фильм
la danse|танец
le chef-d'œuvre|шедевр
le musée|музей
l'exposition|выставка
le pinceau|кисть
la couleur|цвет
le poème|стихотворение
l'histoire|история
le conte|сказка
la blague|шутка
la devinette|загадка

/* ---------- ИГРУШКИ И ИГРЫ ---------- */
le jeu|игра
le jouet|игрушка
la poupée|кукла
le ballon de jeu|мяч
la corde à sauter|скакалка
le cerceau|обруч
le puzzle|пазл
les billes|шарики
les cartes|карты
les dés|кости
les dominos|домино
les échecs|шахматы
les dames|шашки
le loto|лото
le coloriage|раскраска
la marelle|классики

/* ---------- ПРАЗДНИКИ ---------- */
Noël|Рождество
le Nouvel An|Новый год
Pâques|Пасха
la fête nationale|национальный праздник
la Toussaint|День всех святых
la Saint-Valentin|День Валентина
le Carnaval|Карнавал
le réveillon|новогодний ужин
la fête des Mères|День матери
la fête des Pères|День отца
l'anniversaire|день рождения
le mariage|свадьба
la fête|праздник
le cadeau|подарок
la carte postale|открытка

/* ---------- ЗДОРОВЬЕ ---------- */
la santé|здоровье
le médicament|лекарство
la pilule|таблетка
le pansement|бинт
la fièvre|температура
la toux|кашель
le rhume|насморк
la grippe|грипп
le mal|боль
la douleur|боль
la blessure|рана
l'ordonnance|рецепт
la pharmacie|аптека
le rendez-vous|приём
l'ambulance|скорая помощь
le patient|пациент
le thermomètre|термометр

/* ---------- ЭМОЦИИ И ЧУВСТВА ---------- */
l'amour|любовь
la joie|радость
la peur|страх
la colère|гнев
la tristesse|грусть
le bonheur|счастье
l'espoir|надежда
la chance|удача
la surprise|удивление
l'ennui|скука
la honte|стыд
la fierté|гордость
la patience|терпение
la fatigue|усталость
la faim|голод
la soif|жажда
le sourire|улыбка
le rire|смех
la larme|слеза
le frisson|дрожь

/* ---------- ДЕНЬГИ И ПОКУПКИ ---------- */
l'argent|деньги
le prix|цена
la monnaie|сдача, монета
la carte bancaire|банковская карта
le billet|банкнота
les soldes|распродажа
la caisse|касса
le reçu|чек
la facture|счёт
la remise|скидка
gratuit|бесплатно
gratuitement|бесплатно
le budget|бюджет
la pièce|монета
le ticket|талон
le coupon|купон
le rabais|скидка
la promotion|акция
le caddie|тележка
la vitrine|витрина
l'étiquette|ценник
le paquet|пакет
le sac en plastique|пластиковый пакет

/* ---------- КУХНЯ И ГОТОВКА ---------- */
la recette|рецепт
le repas|приём пищи
le petit-déjeuner|завтрак
le déjeuner|обед
le dîner|ужин
le goûter|полдник
la nappe|скатерть
la vaisselle|посуда
le lave-vaisselle|посудомоечная машина

/* ---------- БЫТОВАЯ ТЕХНИКА ---------- */
le téléphone|телефон
l'ordinateur|компьютер
la télévision|телевизор
la radio|радио
la machine à laver|стиральная машина
le sèche-linge|сушильная машина
l'aspirateur|пылесос
le fer à repasser|утюг
le climatiseur|кондиционер
le ventilateur|вентилятор
le chauffage|отопление
la prise|розетка
l'ampoule|лампочка
la pile|батарейка
le chargeur|зарядка
le câble|кабель

/* ---------- РАЗНОЕ ---------- */
le voyage|путешествие
les vacances|каникулы
le week-end|выходные
le message|сообщение
le journal|газета
le magazine|журнал
la lettre|письмо
l'adresse|адрес
le timbre|марка
l'enveloppe|конверт
le stylo à bille|шариковая ручка
le papier|бумага
la clé|ключ
le portail|ворота
la sonnette|звонок
le numéro|номер
le nom|имя, фамилия
le prénom|имя
l'âge|возраст
le pays|страна
la langue|язык
le monde|мир
le groupe|группа
l'exemple|пример
le problème|проблема
la solution|решение
la question|вопрос
la réponse|ответ
l'idée|идея
la pensée|мысль
le mot|слово
la phrase|фраза
le texte|текст
la page|страница
le titre|заголовок
le début|начало
la suite|продолжение

`;