/* ============================================================
   СЛОВАРЬ СРЕДНИХ СЛОВ (уровень B1-B2)
   Формат: французское_слово|русский_перевод
   - Не повторяйте одно и то же французское слово дважды
   - Внутри файла — только эта одна переменная, ничего больше
   - Всего слов: ~2900
   ============================================================ */

window.WORDS_MEDIUM = `

/* ---------- ПРИРОДА И ЛАНДШАФТ ---------- */
la colline|холм
la vallée|долина
la plaine|равнина
le champ|поле
la prairie|луг
le désert|пустыня
le bois|лес, древесина
le rocher|скала
la falaise|утёс
la grotte|пещера
la cascade|водопад
la source|источник
le ruisseau|ручей
le courant|течение
la marée|прилив
l'île|остров
la presqu'île|полуостров
le cap|мыс
la baie|бухта
le golfe|залив
le détroit|пролив
le canal|канал
l'horizon|горизонт
le paysage|пейзаж
l'aube|рассвет
le crépuscule|сумерки
la brume|дымка
la gelée|мороз
la chaleur|жара
la fraîcheur|прохлада
l'humidité|влажность
la sécheresse|засуха
l'inondation|наводнение
le tremblement de terre|землетрясение
la tempête|буря
l'ouragan|ураган
la foudre|молния
le tonnerre|гром
l'arc-en-ciel|радуга
la météo|прогноз погоды
le climat|климат
la température|температура
le degré|градус
la planète|планета
la galaxie|галактика
l'univers|вселенная
la nature|природа
l'environnement|окружающая среда
la pollution|загрязнение
le recyclage|переработка
l'énergie|энергия
le pétrole|нефть
le charbon|уголь
le gaz|газ
l'électricité|электричество
le nucléaire|ядерная энергия
la centrale|электростанция
le barrage|плотина
le moulin|мельница
la ferme|ферма
l'élevage|животноводство
la culture|культура, выращивание
la récolte|урожай
l'engrais|удобрение
le labour|пахота
le verger|фруктовый сад
la serre|теплица
la vigne|виноградная лоза
le tournesol|подсолнух
l'avoine|овёс
l'orge|ячмень
le seigle|рожь
les céréales|злаки

/* ---------- ДЕРЕВЬЯ И РАСТЕНИЯ ---------- */
le chêne|дуб
le pin|сосна
le sapin|ель
le bouleau|берёза
le peuplier|тополь
le saule|ива
le hêtre|бук
le noyer|орех (дерево)
le cerisier|вишнёвое дерево
le pommier|яблоня
le poirier|груша (дерево)
l'olivier|олива
le figuier|инжир (дерево)
le palmier|пальма
le cactus|кактус
la fougère|папоротник
la mousse|мох
le lichen|лишайник
l'écorce|кора
le tronc|ствол
la racine|корень
la branche|ветка
la feuille|лист
le bouton|бутон
la tige|стебель
le pétale|лепесток
le pollen|пыльца
l'orchidée|орхидея
la rose|роза
la tulipe|тюльпан
la marguerite|ромашка
le lys|лилия
la lavande|лаванда

/* ---------- ИНСТРУМЕНТЫ И СТРОИТЕЛЬСТВО ---------- */
l'outil|инструмент
le clou|гвоздь
le marteau|молоток
la vis|винт
le tournevis|отвёртка
la scie|пила
la hache|топор
la lime|напильник
la pince|щипцы
les ciseaux|ножницы
la colle|клей
la ficelle|верёвка
la corde|верёвка
le nœud|узел
la chaîne|цепь
le crochet|крюк
la serrure|замок
le cadenas|навесной замок
la poignée|ручка двери
la charnière|петля
l'écrou|гайка
le boulon|болт
la rondelle|шайба
la réparation|ремонт
la construction|строительство
le chantier|стройплощадка
le béton|бетон
le ciment|цемент
la brique|кирпич
le gravier|гравий
le plâtre|штукатурка
le vernis|лак
le pinceau|кисть
le rouleau|валик
l'échafaudage|строительные леса
la grue|кран
la pelleteuse|экскаватор
le bulldozer|бульдозер
l'usine|завод
l'atelier|мастерская
l'entrepôt|склад
la charrue|плуг
la bêche|лопата
la pelle|лопата
la pioche|кирка
le râteau|грабли
la faux|коса
la faucille|серп

/* ---------- ЭКОНОМИКА И БИЗНЕС ---------- */
le plan|план
le devis|смета
le reçu|квитанция
la commande|заказ
la livraison|доставка
le fournisseur|поставщик
la signature|подпись
la société|компания
l'entreprise|предприятие
la concurrence|конкуренция
le profit|прибыль
la perte|убыток
l'investissement|инвестиция
le crédit|кредит
le prêt|заём
l'intérêt|процент
la dette|долг
la faillite|банкротство
l'impôt|налог
la taxe|сбор
le revenu|доход
le salaire|зарплата
la grève|забастовка
le syndicat|профсоюз
l'embauche|наём
le licenciement|увольнение
la carrière|карьера
la promotion|повышение
la compétence|навык
la formation|обучение
le stage|стажировка
le diplôme|диплом
la faculté|факультет
la recherche|исследование
la bourse|биржа, стипендия
l'action|акция
l'obligation|облигация
le dividende|дивиденд
le bilan|баланс
la comptabilité|бухгалтерия
le chiffre d'affaires|оборот
le bénéfice|прибыль
la marge|маржа
le marchand|торговец
le grossiste|оптовик
le détaillant|розничный продавец
la publicité|реклама
le marketing|маркетинг
le slogan|слоган
la marque|бренд
la clientèle|клиентура
la fidélité|верность

/* ---------- НАУКА ---------- */
la science|наука
la physique|физика
la chimie|химия
la biologie|биология
les mathématiques|математика
l'histoire|история
la géographie|география
la philosophie|философия
la psychologie|психология
la sociologie|социология
l'économie|экономика
le droit|право
la médecine|медицина
la littérature|литература
l'astronomie|астрономия
la géologie|геология
la botanique|ботаника
la zoologie|зоология
la génétique|генетика
la bactérie|бактерия
le virus|вирус
la cellule|клетка
le gène|ген
l'organisme|организм
le squelette|скелет
l'hormone|гормон
le métabolisme|метаболизм
la digestion|пищеварение
la respiration|дыхание
la circulation|кровообращение
l'immunité|иммунитет
l'anticorps|антитело
le vaccin|вакцина
l'atome|атом
la molécule|молекула
l'électron|электрон
le neutron|нейтрон
l'oxygène|кислород
l'hydrogène|водород
le carbone|углерод
l'azote|азот
l'expérience|эксперимент
le laboratoire|лаборатория
l'appareil|прибор
la mesure|измерение
le calcul|вычисление
la formule|формула
l'équation|уравнение
la théorie|теория
l'hypothèse|гипотеза
la conclusion|вывод

/* ---------- ОБРАЗОВАНИЕ ---------- */
l'enseignement|обучение
l'instruction|образование
le savoir|знание
la connaissance|знание
la méthode|метод
la leçon|урок
l'exercice|упражнение
la dictée|диктант
la rédaction|сочинение
la dissertation|эссе
la conférence|лекция
le séminaire|семинар
la soutenance|защита
la thèse|диссертация
le mémoire|дипломная работа
le baccalauréat|бакалавриат
la licence|бакалавриат
le master|магистратура
le doctorat|докторантура
l'érudit|эрудит
le savant|учёный
le chercheur|исследователь
l'inscription|запись
la rentrée|начало учебного года
les vacances scolaires|школьные каникулы
l'uniforme|форма
le tableau noir|классная доска
la craie|мел
l'emploi du temps|расписание
la note|оценка
la moyenne|средний балл
le classement|рейтинг

/* ---------- ИСКУССТВО И ЛИТЕРАТУРА ---------- */
la poésie|поэзия
le roman|роман
la nouvelle|новелла
le conte|сказка
la fable|басня
la pièce|пьеса
la scène|сцена
le spectacle|спектакль
la représentation|представление
l'acte|акт
le rôle|роль
le personnage|персонаж
le héros|герой
l'intrigue|интрига
le dénouement|развязка
l'auteur|автор
le lecteur|читатель
le public|публика
la critique|критика
le succès|успех
l'échec|провал
la gloire|слава
la célébrité|известность
le talent|талант
le génie|гений
l'inspiration|вдохновение
l'imagination|воображение
la créativité|творчество
la sculpture|скульптура
l'architecture|архитектура
la photographie|фотография
l'esquisse|набросок
la toile|полотно
le chef-d'œuvre|шедевр
l'exposition|выставка
la galerie|галерея
le cadre|рамка
la nuance|оттенок
le contraste|контраст
la lumière|свет
l'ombre|тень
la perspective|перспектива
le volume|объём
la surface|поверхность
la texture|текстура
le style|стиль
la mode|мода
le roman policier|детектив
la science-fiction|научная фантастика
le poème|стихотворение
le vers|стих
la rime|рифма
la strophe|строфа
le chapitre|глава
le paragraphe|параграф
la préface|предисловие
la dédicace|посвящение

/* ---------- ОДЕЖДА РАСШИРЕННО ---------- */
la couture|шитьё
le tissu|ткань
la soie|шёлк
le coton|хлопок
le lin|лён
la laine|шерсть
le cuir|кожа
le velours|бархат
la dentelle|кружево
la fermeture éclair|молния
la boucle|пряжка
le lacet|шнурок
la semelle|подошва
le talon|каблук
les collants|колготки
le pyjama|пижама
la robe de chambre|халат
le costume|костюм
le tailleur|костюм (жен.)
la doudoune|пуховик
l'imperméable|плащ
le manteau de fourrure|шуба
le gilet|жилет
le cardigan|кардиган
la salopette|комбинезон
le survêtement|спортивный костюм
le maillot de bain|купальник
la cravate|галстук
le nœud papillon|бабочка
la casquette|кепка
le béret|берет
la ceinture|ремень
les bretelles|подтяжки
le mouchoir|платок
l'ongle|ноготь

/* ---------- ЗДОРОВЬЕ И МЕДИЦИНА ---------- */
l'infection|инфекция
la fièvre|лихорадка
la toux|кашель
le rhume|насморк
la grippe|грипп
l'angine|ангина
la bronchite|бронхит
la pneumonie|пневмония
l'asthme|астма
l'allergie|аллергия
le diabète|диабет
le cancer|рак
l'infarctus|инфаркт
l'AVC|инсульт
la fracture|перелом
l'entorse|растяжение
la brûlure|ожог
la blessure|рана
la cicatrice|шрам
le pansement|бинт
le bandage|повязка
l'ordonnance|рецепт
le médicament|лекарство
la pilule|таблетка
le sirop|сироп
la pommade|мазь
la piqûre|укол
l'analyse|анализ
la radiographie|рентген
l'échographie|УЗИ
le scanner|томограф
l'opération|операция
la chirurgie|хирургия
l'anesthésie|анестезия
la convalescence|выздоровление
la guérison|исцеление
le traitement|лечение
la thérapie|терапия
le psychiatre|психиатр
le psychologue|психолог
la dépression|депрессия
l'anxiété|тревога
le stress|стресс
l'insomnie|бессонница
la migraine|мигрень
la nausée|тошнота
le vertige|головокружение
l'évanouissement|обморок
le coma|кома
la paralysie|паралич
le handicap|инвалидность
la prothèse|протез
la greffe|трансплантация
le donneur|донор
la transfusion|переливание
le rendez-vous|приём
l'ambulance|скорая
le stéthoscope|стетоскоп
le thermomètre|термометр
la tension|давление
le pouls|пульс
la clinique|клиника
l'urgence|скорая помощь
la consultation|консультация
la douleur|боль
le diagnostic|диагноз
le symptôme|симптом
la prévention|профилактика
l'hygiène|гигиена
la nutrition|питание
le régime|диета
la calorie|калория
la vitamine|витамин
la protéine|белок

/* ---------- АНАТОМИЯ РАСШИРЕННО ---------- */
l'artère|артерия
la veine|вена
le tendon|сухожилие
le ligament|связка
le cartilage|хрящ
la colonne vertébrale|позвоночник
la côte|ребро
le crâne|череп
la mâchoire|челюсть
la paupière|веко
le cil|ресница
la pupille|зрачок
l'iris|радужка
la narine|ноздря
la pommette|скула
la tempe|висок
la nuque|затылок
l'aisselle|подмышка
l'avant-bras|предплечье
le mollet|икра (ноги)
la cuisse|бедро
l'orteil|палец ноги
le sourcil|бровь
l'intestin|кишечник
la vessie|мочевой пузырь
le pancréas|поджелудочная
la thyroïde|щитовидная железа
la vertèbre|позвонок
le bassin|таз
la clavicule|ключица

/* ---------- ОЩУЩЕНИЯ И РЕАКЦИИ ---------- */
la faim|голод
la soif|жажда
le sommeil|сон (потребность)
la fatigue|усталость
la démangeaison|зуд
le frisson|дрожь
la sueur|пот
la larme|слеза
le sourire|улыбка
le rire|смех
le hoquet|икота
l'éternuement|чихание
le bâillement|зевота
le tressaillement|вздрагивание
la sensation|ощущение
la douleur|боль
le picotement|покалывание
la brûlure|жжение
l'engourdissement|онемение

/* ---------- КУХОННЫЕ ИНСТРУМЕНТЫ ---------- */
la spatule|лопатка
la louche|половник
l'écumoire|шумовка
le presse-ail|чеснокодавилка
le casse-noix|орехокол
le tire-bouchon|штопор
le décapsuleur|открывалка
l'ouvre-boîte|консервный нож
l'épluche-légumes|овощечистка
la râpe|тёрка
la mandoline|мандалина
le mortier|ступа
le pilon|пестик
la balance|весы
le verre doseur|мерный стакан
la minuterie|таймер
le chinois|сито
la passoire|дуршлаг
l'entonnoir|воронка
la planche à découper|разделочная доска
le mixeur|блендер
le robot|кухонный комбайн
le batteur|миксер
le hachoir|мясорубка
le grille-pain|тостер
la bouilloire|чайник
la cafetière|кофеварка
la théière|заварочный чайник
la cocotte-minute|скороварка
le wok|вок

/* ---------- ОФИС И КАНЦЕЛЯРИЯ ---------- */
l'agrafeuse|степлер
le trombone|скрепка
la perforatrice|дырокол
le ruban adhésif|скотч
la calculatrice|калькулятор
le classeur|папка-регистратор
la chemise|папка
le sous-main|настольная папка
le bloc-notes|блокнот
l'agenda|ежедневник
le tampon|печать
l'encre|чернила
la cartouche|картридж
la corbeille|корзина
la lampe de bureau|настольная лампа
le trombone|скрепка

/* ---------- ИНФОРМАТИКА РАСШИРЕННО ---------- */
le clic|клик
le double-clic|двойной клик
le curseur|курсор
l'icône|иконка
le menu|меню
l'onglet|вкладка
la fenêtre|окно
télécharger|скачать
installer|установить
désinstaller|удалить
redémarrer|перезагрузить
sauvegarder|сохранить
partager|поделиться
commenter|комментировать
publier|публиковать
naviguer|навигировать
chercher|искать
le pare-feu|брандмауэр
le chiffrement|шифрование
le pirate informatique|хакер
le mot-dièse|хештег
le profil|профиль
le pseudo|никнейм
la messagerie|мессенджер
le forum|форум
le blogue|блог
le podcast|подкаст
le streaming|стриминг
le cloud|облако

/* ---------- БАНК И ЛИЧНЫЕ ФИНАНСЫ ---------- */
le compte bancaire|банковский счёт
le compte courant|текущий счёт
le compte épargne|сберегательный счёт
le livret|сберкнижка
le découvert|овердрафт
le virement|перевод
le retrait|снятие
le dépôt|внесение
le distributeur|банкомат
le chéquier|чек. книжка
le chèque|чек
les frais bancaires|банковские комиссии
l'épargne|сбережения
le placement|вложение
l'assurance-vie|страхование жизни
la carte de crédit|кредитная карта
la carte de débit|дебетовая карта
le code confidentiel|ПИН-код
le solde|баланс
le relevé|выписка
la prime|премия

/* ---------- СТРАХОВАНИЕ ---------- */
l'assurance|страхование
l'assurance auto|автострахование
l'assurance habitation|страхование жилья
l'assurance santé|медстрахование
le sinistre|страховой случай
le dégât|ущерб
l'indemnisation|возмещение
l'expertise|экспертиза
la garantie|гарантия
la franchise|франшиза
l'assuré|застрахованный
le contrat d'assurance|страховой договор

/* ---------- НЕДВИЖИМОСТЬ ---------- */
l'immobilier|недвижимость
l'agence immobilière|агентство недвижимости
l'agent immobilier|риэлтор
le bien immobilier|недвижимое имущество
le terrain|участок
la parcelle|надел
le cadastre|кадастр
l'hypothèque|ипотека
le notaire|нотариус
l'acte de propriété|свидетельство о собственности
la copropriété|совладение
le syndic|управляющий домом
la surface habitable|жилая площадь
le mètre carré|квадратный метр
le studio|студия
le duplex|дуплекс
le loft|лофт
la mansarde|мансарда
la mezzanine|мезонин

/* ---------- ЭКОЛОГИЯ И КЛИМАТ ---------- */
le réchauffement climatique|глобальное потепление
l'effet de serre|парниковый эффект
l'empreinte carbone|углеродный след
les énergies renouvelables|возобновляемые источники
l'éolienne|ветряк
le panneau solaire|солнечная панель
l'énergie hydraulique|гидроэнергия
la biomasse|биомасса
la géothermie|геотермия
les déchets|отходы
la décharge|свалка
l'incinération|сжигание
le compostage|компостирование
le tri sélectif|сортировка мусора
le développement durable|устойчивое развитие
la biodiversité|биоразнообразие
l'écosystème|экосистема
l'espèce menacée|исчезающий вид
l'extinction|вымирание
la protection|защита
la réserve naturelle|природный заповедник
le parc national|национальный парк
l'ONG|НКО

/* ---------- МЕЖДУНАРОДНЫЕ ОТНОШЕНИЯ ---------- */
les Nations Unies|ООН
l'Union européenne|Евросоюз
le Parlement|парламент
la commission|комиссия
la directive|директива
le règlement|регламент
le traité|договор
l'accord|соглашение
le sommet|саммит
la diplomatie|дипломатия
l'ambassade|посольство
la coopération|сотрудничество
l'aide humanitaire|гуманитарная помощь
les sanctions|санкции
l'embargo|эмбарго
le conflit armé|вооружённый конфликт
le cessez-le-feu|прекращение огня
les négociations|переговоры
la médiation|посредничество
le référendum|референдум
le plébiscite|плебисцит

/* ---------- ВОЕННОЕ ДЕЛО ---------- */
l'armée|армия
l'armée de terre|сухопутные войска
l'armée de l'air|ВВС
la marine|ВМФ
le régiment|полк
le bataillon|батальон
la compagnie|рота
le peloton|взвод
l'escouade|отделение
l'officier|офицер
le sous-officier|унтер-офицер
le caporal|капрал
le sergent|сержант
le lieutenant|лейтенант
le capitaine|капитан
le commandant|майор
le colonel|полковник
le général|генерал
le maréchal|маршал
le casque|шлем
le bouclier|щит
l'épée|меч
le fusil|винтовка
le pistolet|пистолет
le canon|пушка
le char|танк
l'avion de chasse|истребитель
le sous-marin|подводная лодка
le porte-avions|авианосец

/* ---------- АРХИТЕКТУРА ---------- */
la colonne|колонна
le pilier|столб
l'arc|арка
la voûte|свод
le dôme|купол
la coupole|купол
la façade|фасад
la corniche|карниз
la balustrade|балюстрада
le fronton|фронтон
le portail|портал
le portique|портик
le péristyle|перистиль
le chapiteau|капитель
le fût|ствол колонны
la chapelle|часовня
l'abside|апсида
la nef|неф
le transept|трансепт
le clocher|колокольня
le créneau|зубец стены
la meurtrière|бойница
le donjon|донжон
la tour de guet|сторожевая башня
le rempart|крепостная стена
le fossé|ров
le pont-levis|подъёмный мост

/* ---------- МУЗЫКА РАСШИРЕННО ---------- */
l'instrument à cordes|струнный инструмент
l'instrument à vent|духовой инструмент
l'instrument à percussion|ударный инструмент
le clavecin|клавесин
la harpe|арфа
l'orgue|орган
la contrebasse|контрабас
le violoncelle|виолончель
l'alto|альт
le hautbois|гобой
la clarinette|кларнет
le basson|фагот
le cor|валторна
le trombone|тромбон
le tuba|туба
la timbale|литавра
le xylophone|ксилофон
l'harmonica|губная гармошка
le banjo|банджо
la mandoline|мандолина
le ukulélé|укулеле

/* ---------- КИНО И ТЕЛЕВИДЕНИЕ ---------- */
le réalisateur|режиссёр
le metteur en scène|постановщик
le scénariste|сценарист
le producteur|продюсер
l'acteur principal|главный актёр
le second rôle|второстепенная роль
le figurant|статист
le cascadeur|каскадёр
la doublure|дублёр
le tournage|съёмки
le plateau|съёмочная площадка
le studio|студия
la caméra|камера
le micro|микрофон
l'éclairage|освещение
le montage|монтаж
les effets spéciaux|спецэффекты
la bande-annonce|трейлер
le générique|титры
l'Oscar|Оскар
la Palme d'or|Золотая пальмовая ветвь
le César|Сезар
le festival|фестиваль
la projection|показ
la séance|сеанс

/* ---------- ФОТОГРАФИЯ ---------- */
l'appareil photo|фотоаппарат
l'objectif|объектив
le flash|вспышка
le trépied|штатив
le déclencheur|спуск
la pellicule|плёнка
le négatif|негатив
le tirage|печать
l'agrandissement|увеличение
le développement|проявка
le cadrage|кадрирование
l'exposition|экспозиция
la luminosité|яркость
la retouche|ретушь
le photomontage|фотомонтаж
le selfie|селфи
le portrait|портрет
la macro|макро
le panorama|панорама

/* ---------- ЖИВОПИСЬ И РИСУНОК ---------- */
l'aquarelle|акварель
la peinture à l'huile|масляная живопись
la gouache|гуашь
l'acrylique|акрил
le pastel|пастель
le fusain|уголь
le chevalet|мольберт
la palette|палитра
le vernissage|вернисаж
le croquis|набросок
l'étude|этюд
la nature morte|натюрморт
l'autoportrait|автопортрет
la fresque|фреска
la mosaïque|мозаика

/* ---------- ЛИТЕРАТУРНЫЕ ЖАНРЫ ---------- */
l'autobiographie|автобиография
la biographie|биография
l'essai|эссе
les mémoires|мемуары
le journal intime|дневник
la correspondance|переписка
le pamphlet|памфлет
le manifeste|манифест
la tragédie|трагедия
la comédie|комедия
le drame|драма
la farce|фарс
le vaudeville|водевиль
le mélodrame|мелодрама
l'épopée|эпопея
la légende|легенда
le mythe|миф
la saga|сага
la trilogie|трилогия
le best-seller|бестселлер
le prix littéraire|литературная премия
l'académie|академия
l'académicien|академик

/* ---------- МОДА И СТИЛЬ ---------- */
la haute couture|высокая мода
le prêt-à-porter|прет-а-порте
le défilé|показ мод
le mannequin|манекенщица
le styliste|стилист
le créateur|дизайнер
la tendance|тенденция
la collection|коллекция
la griffe|бренд
le logo|логотип
l'accessoire|аксессуар
le sac à main|сумочка
le foulard|шарф
les lunettes de soleil|солнечные очки
le sac à dos|рюкзак

/* ---------- КОСМЕТИКА ---------- */
le rouge à lèvres|губная помада
le mascara|тушь
le fond de teint|тональный крем
la poudre|пудра
le blush|румяна
l'eye-liner|подводка
le vernis à ongles|лак для ногтей
le dissolvant|средство для снятия лака
la crème hydratante|увлажняющий крем
le sérum|сыворотка
la lotion|лосьон
le tonique|тоник
le gommage|скраб
le masque|маска
l'après-shampooing|бальзам-ополаскиватель
le gel douche|гель для душа
le déodorant|дезодорант
le dentifrice|зубная паста
la brosse à cheveux|расчёска
le sèche-cheveux|фен
le lisseur|выпрямитель

/* ---------- МЕБЕЛЬ РАСШИРЕННО ---------- */
le buffet|буфет
la commode|комод
le chiffonnier|шифоньер
le secrétaire|секретер
la bibliothèque|библиотека (мебель)
l'étagère|полка
le vaisselier|посудный шкаф
la vitrine|витрина
le guéridon|журнальный столик
le tabouret|табурет
le banc|скамья
le pouf|пуф
le hamac|гамак
le paravent|ширма
le porte-manteau|вешалка
le cintre|плечики
la patère|крючок для одежды
la console|консоль
le divan|диван (вост.)

/* ---------- ВЕЩИ И МАТЕРИАЛЫ ---------- */
la matière|материя
la substance|вещество
le métal|металл
le verre|стекло
le papier|бумага
le carton|картон
le plastique|пластик
le caoutchouc|резина
le cuir|кожа
la céramique|керамика
la porcelaine|фарфор
la faïence|фаянс
le marbre|мрамор
le granit|гранит
le bronze|бронза
le laiton|латунь
l'étain|олово
le zinc|цинк
le nickel|никель
le titane|титан

/* ---------- ТРАНСПОРТ РАСШИРЕННО ---------- */
la berline|седан
le break|универсал
le cabriolet|кабриолет
le coupé|купе
le monospace|минивэн
le pick-up|пикап
le fourgon|фургон
la camionnette|фургончик
le semi-remorque|полуприцеп
l'autocar|автобус дальнего следования
le trolleybus|троллейбус
le funiculaire|фуникулёр
le téléphérique|канатная дорога
la péniche|баржа
le chalutier|траулер
le voilier|парусник
le yacht|яхта
le canoë|каноэ
le kayak|каяк
la barque|лодка
la gondole|гондола
le ferry|паром

/* ---------- НАСЕКОМЫЕ РАСШИРЕННО ---------- */
la libellule|стрекоза
la demoiselle|стрекоза (лёгк.)
la sauterelle|кузнечик
le criquet|саранча
le grillon|сверчок
le cafard|таракан
la blatte|таракан
la termite|термит
la mite|моль
la puce|блоха
la punaise|клоп
le pou|вошь
la tique|клещ
l'acarien|клещ (микро)
le scolopendre|сколопендра
le mille-pattes|многоножка
le scorpion|скорпион
la mante religieuse|богомол

/* ---------- ДЕРЕВЬЯ И ЦВЕТЫ РАСШИРЕННО ---------- */
l'érable|клён
le tilleul|липа
le charme|граб
le frêne|ясень
l'orme|вяз
le marronnier|каштан (дерево)
l'acacia|акация
le cyprès|кипарис
le séquoia|секвойя
le baobab|баобаб
le bambou|бамбук
le buisson|куст
l'arbuste|кустарник
la haie|живая изгородь
le gazon|газон
la pelouse|лужайка
le trèfle|клевер
la pâquerette|маргаритка
le coquelicot|мак
le bleuet|василёк
la pivoine|пион
l'iris|ирис
la jacinthe|гиацинт
le narcisse|нарцисс
le muguet|ландыш
l'hortensia|гортензия
la glycine|глициния

/* ---------- МОРСКАЯ ЖИЗНЬ РАСШИРЕННО ---------- */
l'étoile de mer|морская звезда
l'oursin|морской ёж
le concombre de mer|морской огурец
le corail|коралл
l'anémone|анемона
l'éponge|губка
l'hippocampe|морской конёк
la murène|мурена
le barracuda|барракуда
l'espadon|меч-рыба
le requin-marteau|молот-рыба
la baleine bleue|синий кит
l'orque|косатка
le cachalot|кашалот
le narval|нарвал
le phoque|тюлень
l'otarie|морской лев
le morse|морж

/* ---------- ПТИЦЫ РАСШИРЕННО ---------- */
le merle|дрозд
la grive|певчий дрозд
le rouge-gorge|малиновка
la mésange|синица
le pinson|зяблик
l'étourneau|скворец
la pie|сорока
le geai|сойка
le chardonneret|щегол
l'hirondelle|ласточка
le martinet|стриж
l'alouette|жаворонок
la fauvette|славка
le rossignol|соловей
le coucou|кукушка
le pic-vert|дятел
la chouette|сова (без ушек)
l'effraie|сипуха
le faucon|сокол
l'épervier|ястреб
le vautour|гриф

/* ---------- ФЕРМА РАСШИРЕННО ---------- */
l'étable|коровник
l'écurie|конюшня
la bergerie|овчарня
la porcherie|свинарник
le poulailler|курятник
le clapier|крольчатник
le rucher|пасека
la grange|амбар
le silo|силос
le fumier|навоз
la paille|солома
le foin|сено
la moisson|жатва
le battage|молотьба
la traite|доение
la tonte|стрижка
le marquage|мечение

/* ---------- ДИКИЕ ЖИВОТНЫЕ РАСШИРЕННО ---------- */
le blaireau|барсук
la belette|ласка
l'hermine|горностай
la martre|куница
la fouine|куница (кам.)
le putois|хорёк
la loutre|выдра
le castor|бобр
le ragondin|нутрия
la musaraigne|землеройка
la taupe|крот
le campagnol|полёвка
le mulot|лесная мышь
le loir|соня
le lérot|соня-полчок
la gerboise|тушканчик

/* ---------- ПРОФЕССИИ РАСШИРЕННО ---------- */
le traducteur|переводчик
l'interprète|переводчик (устн.)
le rédacteur|редактор
le correcteur|корректор
le libraire|книготорговец
l'éditeur|издатель
le bibliothécaire|библиотекарь
l'historien|историк
le géographe|географ
le mathématicien|математик
le physicien|физик
le chimiste|химик
le biologiste|биолог
le médecin généraliste|терапевт
le chirurgien|хирург
le dermatologue|дерматолог
le cardiologue|кардиолог
le neurologue|невролог
le pédiatre|педиатр
le gynécologue|гинеколог
le radiologue|радиолог
l'anesthésiste|анестезиолог
le pharmacien|фармацевт
le kinésithérapeute|физиотерапевт
le psychanalyste|психоаналитик
l'orthophoniste|логопед
le notaire|нотариус
le greffier|секретарь суда
l'huissier|судебный пристав
le douanier|таможенник
le diplomate|дипломат
l'ambassadeur|посол
le consul|консул
le fonctionnaire|чиновник
l'inspecteur|инспектор
le commissaire|комиссар
le gendarme|жандарм
le militaire|военный
le marin|моряк
le pilote|пилот
le steward|стюард
l'hôtesse de l'air|стюардесса
le conducteur|водитель
le chauffeur|шофёр
le carrossier|кузовщик
le carreleur|плиточник
le peintre en bâtiment|маляр
le couvreur|кровельщик
le vitrier|стекольщик
le serrurier|слесарь
le bijoutier|ювелир
le horloger|часовщик
le tailleur|портной
le cordonnier|сапожник
le chapelier|шляпник
le pâtissier|кондитер
le confiseur|кондитер
le glacier|производитель мороженого
le sommelier|сомелье
le maître d'hôtel|метрдотель
le gérant|управляющий
le PDG|генеральный директор
le cadre|руководитель
le technicien|техник
l'opérateur|оператор
le développeur|разработчик
l'analyste|аналитик
le consultant|консультант
le commercial|торговый представитель
le négociateur|переговорщик
le courtier|брокер
le comptable agréé|присяжный бухгалтер

/* ---------- ПРИРОДА И ЖИВОТНЫЕ СРЕДНЕГО УРОВНЯ ---------- */
le mammifère|млекопитающее
l'oiseau migrateur|перелётная птица
le rongeur|грызун
l'amphibien|земноводное
le reptile|рептилия
l'insecte|насекомое
le prédateur|хищник
la proie|добыча
le troupeau|стадо
la meute|стая
l'essaim|рой
la nichée|выводок
le nid|гнездо
la tanière|логово
la fourrure|мех
la plume|перо
l'aile|крыло
le bec|клюв
la griffe|коготь
la corne|рог
la queue|хвост
l'écaille|чешуя
la nageoire|плавник
l'instinct|инстинкт
l'hibernation|зимняя спячка
la migration|миграция

/* ---------- ДОМ И ИНТЕРЬЕР СРЕДНЕГО УРОВНЯ ---------- */
le logement|жильё
le propriétaire|владелец
le locataire|арендатор
le bail|арендный договор
le loyer|квартплата
les charges|коммунальные платежи
la caution|залог
le mobilier|мебель
l'ameublement|обстановка
la décoration|декорирование
le revêtement|покрытие
le carrelage|плитка
le parquet|паркет
la moquette|ковролин
la tapisserie|обои
la plinthe|плинтус
le store|жалюзи
la persienne|ставни
le volet|ставень
le conduit|дымоход
la cheminée|камин
la chaudière|котёл
le radiateur|радиатор
le climatiseur|кондиционер
le thermostat|термостат

/* ---------- ЕДА РАСШИРЕННО ---------- */
l'aliment|продукт
la denrée|продовольствие
la conserve|консервы
le surgelé|замороженный продукт
le bio|экологически чистый
l'additif|добавка
le conservateur|консервант
l'arôme|ароматизатор
la saveur|вкус
l'assaisonnement|приправа
la vinaigrette|винегрет
la mayonnaise|майонез
la moutarde|горчица
le ketchup|кетчуп
la sauce|соус
la garniture|гарнир
l'entrée|закуска
le plat principal|основное блюдо
le hors-d'œuvre|закуска
le buffet|буфет
le menu|меню
la carte|меню

/* ---------- ПУТЕШЕСТВИЯ РАСШИРЕННО ---------- */
le lieu|место
le site|объект, сайт
le monument|памятник
le patrimoine|наследие
la cathédrale|собор
le château|замок
le palais|дворец
la forteresse|крепость
la tour|башня
le beffroi|ратушная башня
le musée national|национальный музей
la galerie d'art|художественная галерея
la place centrale|центральная площадь
la fontaine|фонтан
le jardin public|публичный сад
le pont historique|исторический мост
les ruines|руины
le panorama|панорама

/* ---------- ЭМОЦИИ РАСШИРЕННО ---------- */
l'enthousiasme|энтузиазм
l'indifférence|безразличие
la mélancolie|меланхолия
la nostalgie|ностальгия
l'angoisse|тревога
la détresse|отчаяние
la sérénité|безмятежность
l'euphorie|эйфория
l'exaltation|восторг
l'irritation|раздражение
l'agacement|досада
la contrariété|огорчение
la déception|разочарование
la satisfaction|удовлетворение
le soulagement|облегчение
la reconnaissance|признательность
l'admiration|восхищение
la compassion|сострадание
l'empathie|эмпатия
la tendresse|нежность
l'affection|привязанность
la passion|страсть
la haine|ненависть
le mépris|презрение
la rancune|злопамятство
la culpabilité|вина
le remords|раскаяние
le regret|сожаление
la confusion|замешательство
la perplexité|недоумение
l'étonnement|изумление

/* ---------- ОБЩЕСТВО ---------- */
la population|население
la classe sociale|социальный класс
la bourgeoisie|буржуазия
le prolétariat|пролетариат
la noblesse|дворянство
le clergé|духовенство
la famille recomposée|сводная семья
le couple|пара
le divorce|развод
le mariage civil|гражданский брак
le mariage religieux|церковный брак
l'adoption|усыновление
l'héritage|наследство
le testament|завещание
la solidarité|солидарность
la tolérance|терпимость
le racisme|расизм
la discrimination|дискриминация
l'égalité des sexes|равенство полов
le féminisme|феминизм
l'immigration|иммиграция
l'émigration|эмиграция
l'intégration|интеграция
la diversité|разнообразие
la laïcité|светскость

/* ---------- ПОГОДА РАСШИРЕННО ---------- */
la prévision|прогноз
le bulletin météo|метеосводка
l'averse|ливень
la bruine|морось
la giboulée|весенний дождь
le grésil|ледяной дождь
la grêle|град
le verglas|гололёд
la canicule|жара
la vague de froid|волна холода
le redoux|оттепель
le dégel|таяние
la bise|северный ветер
le mistral|мистраль
la brise|бриз
la rafale|порыв ветра
la tornade|торнадо
le cyclone|циклон
la mousson|муссон
la rosée|роса
le givre|иней

/* ---------- ВЕЛИЧИНЫ И МЕРЫ ---------- */
le détail|деталь
l'ensemble|целое
la partie|часть
le morceau|кусок
la tranche|ломтик
la moitié|половина
le quart|четверть
le tiers|треть
le double|двойной
le triple|тройной
la douzaine|дюжина
la centaine|сотня
le millier|тысяча
la totalité|целостность
la série|серия
le type|тип
l'espèce|вид
la sorte|род
la variété|разнообразие
la qualité|качество
la quantité|количество
le poids|вес
la taille|размер
la dimension|измерение
la forme|форма
la longueur|длина
la largeur|ширина
la hauteur|высота
la profondeur|глубина
la distance|расстояние
l'épaisseur|толщина
la vitesse|скорость
la force|сила
la puissance|мощность

/* ---------- ГЛАГОЛЫ СРЕДНЕГО УРОВНЯ ---------- */
accompagner|сопровождать
accueillir|принимать
admirer|восхищаться
affirmer|утверждать
améliorer|улучшать
annoncer|объявлять
appartenir|принадлежать
apprécier|ценить
arranger|устраивать
assister|присутствовать
assurer|обеспечивать
attaquer|атаковать
augmenter|увеличивать
avancer|продвигаться
avouer|признавать
bénéficier|извлекать пользу
bouger|двигаться
briller|блистать
calculer|вычислять
causer|причинять, беседовать
célébrer|праздновать
chasser|гнать, охотиться
chauffer|нагревать
circuler|циркулировать
comparer|сравнивать
comporter|включать
conclure|заключать
confirmer|подтверждать
confondre|путать
conseiller|советовать
considérer|рассматривать
constater|констатировать
continuer|продолжать
convaincre|убеждать
corriger|исправлять
critiquer|критиковать
décevoir|разочаровывать
déclarer|заявлять
décorer|украшать
découvrir|обнаруживать
défiler|маршировать
définir|определять
dégager|освобождать
démontrer|демонстрировать
dénoncer|разоблачать
dépendre|зависеть
déplacer|перемещать
déranger|беспокоить
développer|развивать
diriger|управлять
discuter|обсуждать
disparaître|исчезать
disposer|располагать
distinguer|различать
distribuer|распределять
diviser|делить
dominer|господствовать
douter|сомневаться
échanger|обменивать
échapper|ускользать
éclairer|освещать
élever|поднимать
éliminer|устранять
embrasser|целовать, обнимать
emmener|уводить
employer|использовать
emporter|уносить
emprunter|заимствовать
encourager|поощрять
enlever|удалять
enregistrer|записывать
enseigner|преподавать
entourer|окружать
entraîner|тренировать
envahir|вторгаться
envoyer|посылать
épargner|экономить
éprouver|испытывать
établir|устанавливать
étaler|раскладывать
étonner|удивлять
étudier|изучать
évaluer|оценивать
éviter|избегать
exagérer|преувеличивать
examiner|изучать
exécuter|выполнять
exiger|требовать
exister|существовать
expliquer|объяснять
explorer|исследовать
exprimer|выражать
fabriquer|изготавливать
faciliter|облегчать
favoriser|благоприятствовать
figurer|фигурировать
fixer|фиксировать
fonctionner|работать
fonder|основывать
forcer|принуждать
former|формировать
frapper|ударять
gérer|управлять
gouverner|управлять
grandir|расти
habituer|приучать
hésiter|колебаться
indiquer|указывать
informer|информировать
insister|настаивать
installer|устанавливать
intéresser|интересовать
interroger|спрашивать
interrompre|прерывать
intervenir|вмешиваться
inviter|приглашать
juger|судить
justifier|оправдывать
lancer|запускать
libérer|освобождать
limiter|ограничивать
livrer|доставлять
maintenir|поддерживать
manifester|проявлять
manquer|не хватать
mériter|заслуживать
mêler|смешивать
menacer|угрожать
mener|вести
mesurer|измерять
modifier|изменять
motiver|мотивировать
négliger|пренебрегать
négocier|вести переговоры
nier|отрицать
nommer|называть
noter|отмечать
nourrir|кормить
obéir|подчиняться
obliger|обязывать
occuper|занимать
offrir|предлагать
opérer|оперировать
opposer|противопоставлять
organiser|организовывать
oser|осмеливаться
pardonner|прощать
partager|делить
participer|участвовать
parvenir|достигать
peser|весить
placer|размещать
plaindre|жаловаться
plaire|нравиться
poursuivre|преследовать
préciser|уточнять
préférer|предпочитать
préparer|готовить
présenter|представлять
préserver|сохранять
prêter|одалживать
prévenir|предупреждать
prévoir|предвидеть
prier|просить
produire|производить
profiter|пользоваться
progresser|прогрессировать
prolonger|продлевать
prononcer|произносить
proposer|предлагать
protester|протестовать
prouver|доказывать
provoquer|вызывать
publier|публиковать
qualifier|квалифицировать
quitter|покидать
rappeler|напоминать
rapporter|приносить
rapprocher|сближать
rassembler|собирать
rassurer|успокаивать
recevoir|получать
rechercher|искать
reconnaître|узнавать
recruter|набирать
réduire|сокращать
réfléchir|размышлять
refuser|отказывать
regretter|сожалеть
rejeter|отвергать
relier|связывать
remarquer|замечать
remercier|благодарить
remettre|возвращать
remplacer|заменять
remplir|наполнять
rencontrer|встречать
rendre|возвращать
renforcer|усиливать
renoncer|отказываться
rentrer|возвращаться
renverser|опрокидывать
répandre|распространять
réparer|ремонтировать
répéter|повторять
représenter|представлять
reprocher|упрекать
réserver|бронировать
résister|сопротивляться
résoudre|решать
respecter|уважать
ressembler|быть похожим
ressentir|чувствовать
restaurer|восстанавливать
retenir|задерживать
retirer|убирать
retourner|возвращать
réussir|удаваться
révéler|раскрывать
revoir|снова видеть
risquer|рисковать
saisir|схватить
satisfaire|удовлетворять
sauver|спасать
sécher|сушить
séduire|соблазнять
sélectionner|отбирать
sembler|казаться
séparer|разделять
serrer|сжимать
signaler|сигнализировать
signer|подписывать
signifier|означать
simplifier|упрощать
situer|располагать
soigner|лечить
sonner|звонить
souffrir|страдать
soulager|облегчать
soulever|поднимать
souligner|подчёркивать
soumettre|подчинять
soupçonner|подозревать
sourire|улыбаться
soutenir|поддерживать
subir|подвергаться
suivre|следовать
supposer|предполагать
supprimer|удалять
surprendre|удивлять
surveiller|следить
survivre|выживать
taire|умалчивать
témoigner|свидетельствовать
tendre|натягивать
tenter|пытаться
terminer|заканчивать
tirer|тянуть
tolérer|терпеть
toucher|трогать
tourner|вращать
tracer|чертить
traduire|переводить
trahir|предавать
traîner|тащить
traiter|обрабатывать
transformer|превращать
transmettre|передавать
transporter|перевозить
traverser|пересекать
trembler|дрожать
tromper|обманывать
trouver|находить
unir|соединять
utiliser|использовать
vaincre|побеждать
valider|утверждать
varier|варьировать
vérifier|проверять
verser|наливать
viser|целиться
visiter|посещать
voter|голосовать
voyager|путешествовать

/* ---------- ГЛАГОЛЫ ДОПОЛНИТЕЛЬНО ---------- */
aborder|подходить, обсуждать
aboutir|приводить к
abriter|укрывать
accomplir|совершать
accorder|предоставлять
accroître|увеличивать
accumuler|накапливать
accuser|обвинять
adapter|адаптировать
adhérer|присоединяться
admirer|восхищаться
affaiblir|ослаблять
afficher|выставлять
agir|действовать
agrandir|увеличивать
ajouter|добавлять
alarmer|тревожить
alléger|облегчать
aller chercher|сходить за
amuser|развлекать
annoncer|объявлять
apercevoir|замечать
applaudir|аплодировать
apporter|приносить
appuyer|нажимать
arracher|вырывать
arrestationner|арестовывать
aspirer|вдыхать
assister à|присутствовать на
atteindre|достигать
attirer|привлекать
attribuer|приписывать
avaler|глотать
avertir|предупреждать
bannir|изгонять
bâtir|строить
blesser|ранить
boucher|затыкать
bronzer|загорать
casser|ломать
céder|уступать
cerner|окружать
charger|грузить
chasser|прогонять
châtier|наказывать
chercher à|пытаться
choisir|выбирать
combattre|бороться
commander|заказывать
commettre|совершать
communiquer|сообщать
composer|составлять
comprimer|сжимать
compter|считать
conduire|вести
confier|доверять
conquérir|завоёвывать
consacrer|посвящать
conserver|хранить
consister à|состоять в
consoler|утешать
consommer|потреблять
construire|строить
contempler|созерцать
contenir|содержать
contester|оспаривать
contracter|сокращать
contredire|противоречить
contribuer|способствовать
convenir|подходить
convertir|преобразовывать
coûter|стоить
couvrir|покрывать
craindre|бояться
créer|создавать
crier|кричать
débarquer|высаживаться
débattre|обсуждать
débarrasser|освобождать
déborder|переливаться
décharger|разгружать
déchirer|рвать
décider|решать
déclencher|запускать
décoller|взлетать
découper|разрезать
décrire|описывать
défendre|защищать
déformer|деформировать
déguster|пробовать
délivrer|освобождать
demander à|просить
démarrer|запускать
démentir|опровергать
démolir|сносить
dénicher|разыскивать
dépasser|превышать
dépenser|тратить
déposer|класть
dériver|дрейфовать
désirer|желать
détacher|отделять
détruire|разрушать
dévoiler|раскрывать
différer|отсрочивать
digérer|переваривать
disputer|спорить
dissimuler|скрывать
distraire|развлекать
documenter|документировать
dompter|укрощать
dormir|спать
douter de|сомневаться в
écarter|отодвигать
échouer|потерпеть неудачу
éclater|взрываться
écouler|сбывать
écraser|раздавливать
effacer|стирать
effrayer|пугать
égarer|терять
éloigner|отдалять
emballer|упаковывать
embarquer|грузить
embellir|украшать
émerveiller|восхищать
émettre|издавать
emmener|уводить
énerver|нервировать
enfanter|рожать
enfermer|запирать
enflammer|воспламенять
enfoncer|вбивать
engager|нанимать
enrichir|обогащать
entasser|нагромождать
entreprendre|предпринимать
entretenir|поддерживать
énumérer|перечислять
épouser|жениться
épuiser|истощать
équiper|оснащать
errer|блуждать
espérer|надеяться
essayer|пробовать
essuyer|вытирать
estimer|оценивать
éteindre|гасить
étendre|растягивать
étouffer|душить
éveiller|будить
évoluer|развиваться
exaucer|выслушивать
excéder|превышать
excuser|извинять
exhaler|испускать
exposer|выставлять
expulser|изгонять
extraire|извлекать
fâcher|сердить
fatiguer|утомлять
fendre|раскалывать
fêter|праздновать
feuilleter|листать
filtrer|фильтровать
flatter|льстить
flotter|плавать
fouiller|обыскивать
fournir|поставлять
franchir|пересекать
freiner|тормозить
fréquenter|посещать
frotter|тереть
fuir|убегать
fusionner|объединять
gâcher|портить
gagner|зарабатывать
garantir|гарантировать
gaspiller|расточать
geler|замерзать
gémir|стонать
gêner|мешать
germer|прорастать
glisser|скользить
goûter à|пробовать
gratter|царапать
graver|гравировать
grimper|взбираться
guérir|вылечивать
guider|вести
hausser|повышать
héberger|приютить
heurter|ударять
hisser|поднимать
humilier|унижать
identifier|идентифицировать
ignorer|игнорировать
illustrer|иллюстрировать
imaginer|воображать
imiter|имитировать
implanter|внедрять
impliquer|вовлекать
imposer|навязывать
imprimer|печатать
improviser|импровизировать
inclure|включать
indigner|возмущать
induire|вводить
infliger|налагать
influencer|влиять
inhaler|вдыхать
initier|посвящать
innover|вводить новшества
inscrire|записывать
insérer|вставлять
insinuer|внушать
inspecter|инспектировать
inspirer|вдохновлять
interdire|запрещать
introduire|вводить
inventer|изобретать
inverser|инвертировать
investir|инвестировать
irriter|раздражать
isoler|изолировать
jaillir|брызгать
jeter|бросать
joindre|присоединять
jongler|жонглировать
jouer à|играть в
jouir|наслаждаться
justifier|оправдывать
lâcher|выпускать
laisser|оставлять
lancer|бросать
lasser|утомлять
laver|мыть
lécher|лизать
léguer|завещать
lever|поднимать
lier|связывать
lisser|гладить
loger|размещать
lutter|бороться
manier|управлять
manipuler|манипулировать
maîtriser|владеть
marier|женить
marquer|отмечать
maudire|проклинать
méditer|размышлять
méfier|не доверять
mélanger|смешивать
mémoriser|запоминать
mendier|просить милостыню
mentionner|упоминать
mentir|лгать
mépriser|презирать
mettre en marche|запускать
meubler|обставлять
migrer|мигрировать
minimiser|преуменьшать
mordre|кусать
mouiller|мочить
multiplier|умножать
murmurer|шептать
muter|переводить
narguer|насмехаться
naviguer|плавать
neutraliser|нейтрализовать
nouer|завязывать
obscurcir|затемнять
observer|наблюдать
obstruer|загромождать
obtenir|получать
ôter|убирать
oublier|забывать
outrager|оскорблять
ouvrir|открывать
pâlir|бледнеть
parcourir|пробегать
parler de|говорить о
participer à|участвовать в
parvenir à|достигать
passer|проходить
pencher|наклонять
pénétrer|проникать
percer|пробивать
percevoir|воспринимать
percuter|ударять
perdre|терять
perfectionner|совершенствовать
persécuter|преследовать
persévérer|упорствовать
personnaliser|персонализировать
persuader|убеждать
pétiller|искриться
peupler|населять
photographier|фотографировать
piller|грабить
pincer|щипать
piquer|колоть
plaisanter|шутить
planer|парить
planifier|планировать
planter|сажать
plier|складывать
plonger|погружать
poignarder|закалывать
polluer|загрязнять
poser une question|задавать вопрос
positionner|позиционировать
posséder|владеть
pourrir|гнить
pousser|толкать
pratiquer|практиковать
précéder|предшествовать
préconiser|рекомендовать
prédire|предсказывать
prélever|взимать
préméditer|замышлять
prendre soin de|заботиться о
préoccuper|заботить
prescrire|предписывать
pressentir|предчувствовать
presser|давить
présumer|предполагать
prétendre|претендовать
prévaloir|преобладать
prévoir|предвидеть
priver|лишать
procéder|действовать
proclamer|провозглашать
procurer|доставлять
professer|исповедовать
prohiber|запрещать
projeter|проецировать
prolonger|продлевать
promener|прогуливать
promettre|обещать
promouvoir|продвигать
prononcer|произносить
prophétiser|пророчествовать
proportionner|соразмерять
proscrire|запрещать
prospecter|разведывать
prospérer|процветать
protéger|защищать
psalmodier|петь псалмы
punir|наказывать
purifier|очищать
poursuivre|преследовать
quémander|выпрашивать
raccompagner|провожать
raccrocher|вешать трубку
raconter|рассказывать
rafraîchir|освежать
ralentir|замедлять
ramasser|собирать
ramener|приносить
ramper|ползать
ranger|убирать
ranimer|оживлять
rapetisser|уменьшать
rapiécer|латать
rater|проваливать
rattraper|догонять
ravager|опустошать
ravir|восхищать
rayonner|сиять
réagir|реагировать
réaliser|осуществлять
rebondir|отскакивать
recharger|перезагружать
réciter|декламировать
réclamer|требовать
récolter|собирать урожай
recommander|рекомендовать
recommencer|начинать заново
récompenser|награждать
réconcilier|мирить
reconquérir|отвоёвывать
reconstruire|отстраивать
recopier|переписывать
recouvrir|покрывать
recruter|набирать
rectifier|исправлять
reculer|отступать
récupérer|восстанавливать
recycler|перерабатывать
rédiger|составлять
redonner|возвращать
redouter|опасаться
redresser|выпрямлять
réécrire|переписывать
refaire|переделывать
refermer|закрывать
réfléchir à|обдумывать
refléter|отражать
refroidir|охлаждать
regarder|смотреть
regretter|сожалеть
réjouir|радовать
relâcher|ослаблять
relater|рассказывать
relever|поднимать
relire|перечитывать
remettre en question|ставить под сомнение
remonter|подниматься
remuer|двигать
renfermer|заключать
renforcer|усиливать
renifler|сопеть
renouveler|обновлять
rénover|обновлять
renseigner|информировать
rentabiliser|делать рентабельным
repartir|уезжать
répartir|распределять
repasser|гладить
repentir|раскаиваться
repérer|обнаруживать
répliquer|возражать
reporter|откладывать
reposer|отдыхать
repousser|отталкивать
reprendre|возобновлять
représenter|представлять
réprimer|подавлять
reproduire|воспроизводить
réprouver|осуждать
répudier|отвергать
répugner|внушать отвращение
requérir|требовать
rescaper|спасать
résider|проживать
résigner|смиряться
respirer|дышать
ressaisir|схватить снова
ressasser|пережёвывать
resserrer|сжимать
ressortir|выходить
ressusciter|воскрешать
restituer|возвращать
restreindre|ограничивать
résulter|следовать
résumer|резюмировать
rétablir|восстанавливать
retailler|подрезать
retarder|задерживать
retentir|звучать
retomber|падать снова
retordre|перекручивать
retoucher|подправлять
retracer|описывать
rétracter|втягивать
retrancher|вычитать
retransmettre|ретранслировать
retravailler|дорабатывать
rétrécir|суживать
réunir|собирать
réutiliser|повторно использовать
revaloriser|повышать стоимость
révasser|мечтать
réveiller|будить
revendiquer|требовать
revendre|перепродавать
revenir|возвращаться
rêver|мечтать
revêtir|надевать
réviser|пересматривать
revivre|оживать
révolter|возмущать
révoquer|отзывать
ricaner|хихикать
ridiculiser|высмеивать
rincer|полоскать
riposter|отвечать ударом
rivaliser|соперничать
roidir|натягивать
rompre|разрывать
ronfler|храпеть
ronger|грызть
rougir|краснеть
rouiller|ржаветь
rouler|катать
rugir|рычать
ruiner|разорять
ruisseler|струиться
ruser|хитрить
sacrifier|жертвовать
saigner|кровоточить
salir|пачкать
saluer|приветствовать
sanctionner|санкционировать
sangloter|рыдать
saper|подрывать
saturer|насыщать
savourer|смаковать
sceller|запечатывать
scier|пилить
scruter|вглядываться
sculpter|ваять
sécher|сушить
seconder|помогать
secouer|трясти
secourir|помогать
séjourner|пребывать
semer|сеять
séparer|разделять
serpenter|извиваться
sévir|свирепствовать
signaler|сигнализировать
sombrer|тонуть
sonder|зондировать
songer|мечтать
sonner|звонить
sortir|выходить
souffler|дуть
souhaiter|желать
souiller|пачкать
soulager|облегчать
soupçonner|подозревать
soupirer|вздыхать
sourciller|хмуриться
souscrire|подписываться
sous-estimer|недооценивать
soustraire|вычитать
spécialiser|специализировать
spécifier|уточнять
spolier|грабить
stabiliser|стабилизировать
stationner|парковаться
stimuler|стимулировать
stopper|останавливать
stresser|нервничать
structurer|структурировать
stupéfier|ошеломлять
subdiviser|подразделять
subjuguer|покорять
submerger|затоплять
subordonner|подчинять
subsister|существовать
substituer|заменять
sucrer|подслащивать
suer|потеть
suffire|хватать
suggérer|предлагать
suinter|сочиться
superposer|накладывать
superviser|контролировать
supplanter|вытеснять
suppléer|замещать
supplier|умолять
supposer|предполагать
suppurer|гноиться
surélever|надстраивать
surestimer|переоценивать
surgir|появляться
surmonter|преодолевать
surnager|держаться на поверхности
surnommer|давать прозвище
surpasser|превосходить
surplomber|нависать
sursauter|вздрагивать
survenir|случаться
survoler|пролетать над
susciter|возбуждать
suspecter|подозревать
suspendre|подвешивать
sustenter|подкреплять
symboliser|символизировать
sympathiser|симпатизировать
synchroniser|синхронизировать
synthétiser|синтезировать
systématiser|систематизировать
tabasser|избивать
tâcher|стараться
tailler|обрезать
tamiser|просеивать
tanguer|качаться
taper|стучать
tarder|задерживаться
tartiner|намазывать
tasser|утрамбовывать
tâter|щупать
tatouer|татуировать
teindre|красить
télécharger|скачивать
téléphoner|звонить
témoigner|свидетельствовать
temporiser|выжидать
tendre|тянуть
tenir|держать
ternir|тускнеть
terrasser|сваливать
terrifier|ужасать
tester|тестировать
tinter|звенеть
tisser|ткать
titiller|щекотать
titrer|озаглавливать
tonifier|тонизировать
tonner|греметь
torcher|вытирать
tordre|скручивать
torturer|пытать
touiller|перемешивать
tourbillonner|кружиться
tourmenter|мучить
tousser|кашлять
tracasser|беспокоить
tracter|буксировать
traficoter|жульничать
tramer|замышлять
trancher|резать
tranquilliser|успокаивать
transbahuter|перетаскивать
transcender|превосходить
transcrire|переписывать
transférer|переносить
transfigurer|преображать
transfuser|переливать
transgresser|преступать
transiger|идти на компромисс
transiter|проходить транзитом
transparaître|просвечивать
transpercer|пронзать
transpirer|потеть
transplanter|пересаживать
transposer|переставлять
traquer|загонять
trébucher|спотыкаться
tremper|мочить
tressaillir|вздрагивать
tresser|заплетать
tricher|обманывать
tricoter|вязать
trier|сортировать
trimer|вкалывать
triompher|торжествовать
tripatouiller|подделывать
tripler|утраивать
triturer|перемалывать
tronquer|урезать
trotter|семенить
troubler|смущать
trouer|пробивать
truander|жульничать
truster|присваивать
tuer|убивать
tuméfier|опухать
turbiner|вкалывать
tutoyer|обращаться на «ты»
tyranniser|тиранить
ulcérer|разъедать
unifier|объединять
urger|спешно требоваться
user|изнашивать
usurper|узурпировать
vaciller|шататься
valider|утверждать
valoriser|оценивать
vandaliser|вандализировать
vanner|провеивать
vanter|хвалить
vaporiser|распылять
veiller|бодрствовать
venger|мстить
venter|быть ветреным
verbaliser|составлять протокол
verdir|зеленеть
verrouiller|запирать
versifier|рифмовать
vêtir|одевать
vexer|досаждать
vibrer|вибрировать
vider|опустошать
vieillir|стареть
vilipender|поносить
violenter|насиловать
violer|нарушать
virer|поворачивать
virevolter|кружиться
visionner|просматривать
visser|привинчивать
visualiser|визуализировать
vitrer|остеклять
vitupérer|порицать
vivifier|оживлять
vociférer|орать
voiler|закрывать вуалью
volatiliser|улетучиваться
vomir|рвать
vouer|посвящать
vriller|сверлить
vrombir|гудеть
vulgariser|популяризировать
zébrer|полосить
zézayer|шепелявить
zoner|районировать
zoomer|увеличивать

/* ---------- ПРИЛАГАТЕЛЬНЫЕ СРЕДНЕГО УРОВНЯ ---------- */
absent|отсутствующий
absolu|абсолютный
abstrait|абстрактный
actif|активный
actuel|текущий
agréable|приятный
aimable|любезный
ambigu|двусмысленный
ancien|древний, бывший
apparent|видимый
approfondi|углублённый
ardent|пылкий
attentif|внимательный
avancé|продвинутый
bavard|болтливый
bienveillant|благожелательный
brutal|грубый
capable|способный
certain|определённый
complexe|сложный
conscient|сознательный
constant|постоянный
convenable|подходящий
convaincant|убедительный
courant|обычный
cruel|жестокий
curieux|любопытный
décevant|разочаровывающий
décisif|решающий
délicat|деликатный
démocratique|демократический
dense|плотный
dépendant|зависимый
désagréable|неприятный
désireux|желающий
désolé|огорчённый
déterminé|решительный
dévoué|преданный
différent|различный
discret|сдержанный
distinct|отчётливый
divers|разнообразный
doué|одарённый
dramatique|драматический
durable|прочный
dynamique|динамичный
efficace|эффективный
élégant|элегантный
éminent|выдающийся
énorme|огромный
entier|целый
essentiel|существенный
étonnant|удивительный
étrange|странный
évident|очевидный
exact|точный
exceptionnel|исключительный
exigeant|требовательный
expérimenté|опытный
extraordinaire|необычайный
extrême|крайний
fameux|знаменитый
favorable|благоприятный
fertile|плодородный
fier|гордый
figuré|образный
fluide|плавный
formidable|потрясающий
fragile|хрупкий
fréquent|частый
généreux|щедрый
génial|гениальный
gigantesque|гигантский
glorieux|славный
gratuit|бесплатный
grave|серьёзный
habituel|обычный
hardi|дерзкий
honnête|честный
hostile|враждебный
humble|скромный
idéal|идеальный
impatient|нетерпеливый
important|важный
impossible|невозможный
impressionnant|впечатляющий
incapable|неспособный
inconnu|неизвестный
incontournable|обязательный
indépendant|независимый
indifférent|безразличный
indispensable|необходимый
inévitable|неизбежный
inférieur|низший
infini|бесконечный
inquiet|обеспокоенный
insensible|бесчувственный
insignifiant|незначительный
insupportable|невыносимый
intense|интенсивный
intéressant|интересный
intime|интимный
inutile|бесполезный
inventif|изобретательный
irréel|нереальный
juste|справедливый
lâche|трусливый
léger|легкомысленный
logique|логичный
lucide|ясный
magnifique|великолепный
majeur|главный
maladroit|неловкий
médiocre|посредственный
méfiant|недоверчивый
mémorable|памятный
modeste|скромный
mondial|мировой
mou|мягкий
mystérieux|таинственный
naturel|естественный
nécessaire|необходимый
net|чёткий
neutre|нейтральный
nombreux|многочисленный
notable|значительный
nuisible|вредный
obéissant|послушный
objectif|объективный
obscur|тёмный
occasionnel|случайный
ordinaire|обычный
original|оригинальный
paisible|мирный
particulier|особенный
passionnant|увлекательный
patient|терпеливый
pénible|утомительный
permanent|постоянный
persévérant|упорный
personnel|личный
persuasif|убедительный
peureux|боязливый
pittoresque|живописный
plaisant|приятный
poétique|поэтический
populaire|популярный
positif|положительный
possible|возможный
précieux|ценный
précis|точный
préféré|любимый
prestigieux|престижный
principal|главный
profond|глубокий
propre|собственный
provocant|провокационный
prudent|благоразумный
puissant|мощный
pur|чистый
quotidien|повседневный
radical|радикальный
rassurant|успокаивающий
rauque|хриплый
récent|недавний
reconnaissant|благодарный
redoutable|грозный
réel|реальный
réfléchi|обдуманный
régulier|регулярный
relatif|относительный
remarquable|выдающийся
réservé|сдержанный
résistant|стойкий
respectueux|уважительный
responsable|ответственный
rigoureux|строгий
romantique|романтичный
rude|грубый
sain|здоровый
satisfaisant|удовлетворительный
savant|учёный
secret|тайный
sensible|чувствительный
sévère|суровый
simple|простой
sobre|трезвый
solide|прочный
somptueux|роскошный
sophistiqué|изощрённый
souple|гибкий
spontané|непроизвольный
stable|стабильный
strict|строгий
subtil|тонкий
suffisant|достаточный
sûr|уверенный
surprenant|удивительный
susceptible|обидчивый
sympathique|симпатичный
talentueux|талантливый
tendre|нежный
terrible|ужасный
tolérant|терпимый
tranquille|спокойный
typique|типичный
unique|уникальный
urgent|срочный
utile|полезный
vague|неопределённый
vaillant|доблестный
vain|тщетный
valable|действительный
vaste|обширный
véritable|истинный
versatile|непостоянный
victorieux|победоносный
vigoureux|энергичный
violent|насильственный
visible|видимый
vivant|живой
volontaire|добровольный
vorace|прожорливый
vrai|настоящий
vulgaire|вульгарный
zélé|усердный

/* ---------- ПРИЛАГАТЕЛЬНЫЕ ДОПОЛНИТЕЛЬНО ---------- */
agressif|агрессивный
aimable|любезный
alerte|бдительный
amical|дружеский
amusant|забавный
angoissant|тревожный
anonyme|анонимный
arrogant|надменный
attirant|привлекательный
avare|скупой
bavard|болтливый
bien élevé|воспитанный
blessant|обидный
bordélique|беспорядочный
brillant|блестящий
calme|спокойный
capricieux|капризный
célèbre|знаменитый
charmant|очаровательный
chic|шикарный
compétent|компетентный
compréhensif|понимающий
concerné|заинтересованный
confiant|уверенный
consciencieux|добросовестный
créatif|творческий
curieux|любопытный
déçu|разочарованный
dégoûtant|отвратительный
délicieux|восхитительный
désagréable|неприятный
désespéré|отчаявшийся
digne|достойный
discret|сдержанный
distrait|рассеянный
drôle|забавный
dur|жёсткий
éblouissant|ослепительный
économe|экономный
efficace|эффективный
énervant|раздражающий
enthousiaste|восторженный
envieux|завистливый
épuisé|изнурённый
étonnant|удивительный
étranger|иностранный
excellent|отличный
excentrique|эксцентричный
exigeant|требовательный
fâché|рассерженный
faible|слабый
fascinant|пленительный
fatigant|утомительный
fier|гордый
fou|сумасшедший
fragile|хрупкий
franc|откровенный
froid|холодный
gai|весёлый
gauche|неуклюжий
généreux|щедрый
gêné|смущённый
gênant|стесняющий
gentil|милый
glacial|ледяной
gourmand|лакомка
gracieux|грациозный
grossier|грубый
heureux|счастливый
honnête|честный
hostile|враждебный
idiot|глупый
impatient|нетерпеливый
impertinent|дерзкий
important|важный
imprudent|неосторожный
inattendu|неожиданный
incompétent|некомпетентный
inconscient|бессознательный
indécis|нерешительный
indiscret|нескромный
injuste|несправедливый
innocent|невинный
insolent|наглый
insouciant|беззаботный
insupportable|невыносимый
intelligent|умный
intéressé|заинтересованный
inutile|бесполезный
jaloux|ревнивый
lâche|трусливый
las|уставший
léger|легкомысленный
lent|медленный
loquace|разговорчивый
lourd|тяжёлый
loyal|верный
maladroit|неловкий
malhonnête|нечестный
méchant|злой
mécontent|недовольный
méfiant|недоверчивый
menteur|лживый
méticuleux|педантичный
minutieux|тщательный
modeste|скромный
moqueur|насмешливый
morose|мрачный
mou|мягкий
muet|немой
négligent|небрежный
nerveux|нервный
niais|глуповатый
nonchalant|беспечный
obéissant|послушный
obstiné|упрямый
optimiste|оптимистичный
orgueilleux|гордый
original|оригинальный
ouvert|открытый
paisible|мирный
paresseux|ленивый
patient|терпеливый
pénible|тяжёлый
perfide|коварный
pessimiste|пессимистичный
poli|вежливый
ponctuel|пунктуальный
prétentieux|самодовольный
paresseux|ленивый
prodigue|расточительный
propre|чистый
prudent|осторожный
puéril|ребяческий
rancunier|злопамятный
raisonnable|разумный
rapide|быстрый
réaliste|реалистичный
réservé|сдержанный
rêveur|мечтательный
riche|богатый
rieur|смешливый
robuste|крепкий
rusé|хитрый
sage|мудрый
sale|грязный
satisfait|довольный
sauvage|дикий
sec|сухой
sensible|чувствительный
sérieux|серьёзный
sévère|строгий
sincère|искренний
sociable|общительный
soigneux|аккуратный
solennel|торжественный
solitaire|одинокий
sombre|мрачный
soucieux|озабоченный
souple|гибкий
sourd|глухой
sportif|спортивный
stressé|напряжённый
stupide|глупый
sympathique|приятный
taciturne|молчаливый
talentueux|талантливый
têtu|упрямый
timide|застенчивый
tolérant|терпимый
tranquille|спокойный
triste|грустный
trompeur|обманчивый
vaniteux|тщеславный
vexé|обиженный
violent|жестокий
vivant|живой
volontaire|волевой

/* ---------- АБСТРАКТНЫЕ СУЩЕСТВИТЕЛЬНЫЕ ---------- */
l'aptitude|способность
l'attitude|отношение
l'avantage|преимущество
l'inconvénient|недостаток
la certitude|уверенность
la crainte|опасение
la déception|разочарование
la défaite|поражение
la domination|господство
l'échec|неудача
l'effort|усилие
l'égalité|равенство
l'engagement|обязательство
l'ennui|скука
l'enthousiasme|энтузиазм
l'envie|зависть, желание
l'erreur|ошибка
l'esprit|дух, ум
l'état|состояние
l'étonnement|изумление
l'être|существо
l'événement|событие
l'évolution|эволюция
l'exemple|пример
l'exigence|требование
l'existence|существование
l'expérience|опыт
l'explication|объяснение
l'expression|выражение
l'extérieur|внешняя сторона
la faculté|способность
la faiblesse|слабость
la foi|вера
la fonction|функция
la force|сила
la forme|форма
la frontière|граница
la générosité|щедрость
la gloire|слава
la grandeur|величие
la honte|стыд
l'hypothèse|гипотеза
l'idéal|идеал
l'identité|идентичность
l'ignorance|невежество
l'image|образ
l'imagination|воображение
l'importance|важность
l'impression|впечатление
l'incertitude|неопределённость
l'inconvénient|неудобство
l'indépendance|независимость
l'indifférence|безразличие
l'influence|влияние
l'innovation|инновация
l'inquiétude|тревога
l'inspiration|вдохновение
l'instinct|инстинкт
l'intelligence|интеллект
l'intention|намерение
l'intérêt|интерес
l'interprétation|интерпретация
l'intuition|интуиция
l'ironie|ирония
la jalousie|ревность
le jugement|суждение
la justice|справедливость
la liberté|свобода
la limite|предел
la logique|логика
la lucidité|ясность
la maîtrise|мастерство
la manière|способ
la maxime|максима
la mémoire|память
la menace|угроза
la mentalité|менталитет
la méthode|метод
la modestie|скромность
la motivation|мотивация
la nécessité|необходимость
la notoriété|известность
l'objectif|цель
l'obligation|обязанность
l'occasion|случай
l'opinion|мнение
l'opportunité|возможность
l'opposition|противодействие
l'organisation|организация
l'originalité|оригинальность
la patience|терпение
la pauvreté|бедность
la peur|страх
la philosophie|философия
la pitié|жалость
la plénitude|полнота
la politique|политика
la possibilité|возможность
la préférence|предпочтение
la prévention|предупреждение
la priorité|приоритет
la profondeur|глубина
la promesse|обещание
la prospérité|процветание
la prudence|осторожность
la qualité|качество
la quantité|количество
la rage|ярость
la raison|разум, причина
la reconnaissance|признание
la réflexion|размышление
la relation|отношение
la religion|религия
la rencontre|встреча
la répétition|повторение
la réponse|ответ
la responsabilité|ответственность
la retenue|сдержанность
la richesse|богатство
la sagesse|мудрость
la satisfaction|удовлетворение
la sécurité|безопасность
la sensibilité|чувствительность
la sensualité|чувственность
la simplicité|простота
la sincérité|искренность
la situation|ситуация
la sociabilité|общительность
la solidarité|солидарность
la solitude|одиночество
la souffrance|страдание
la source|источник
la stabilité|стабильность
la stratégie|стратегия
la subtilité|тонкость
la suggestion|внушение
la surprise|сюрприз
la sympathie|симпатия
la taciturnité|молчаливость
la ténacité|настойчивость
la tentation|искушение
la théorie|теория
la tolérance|терпимость
la tristesse|грусть
l'union|союз
l'usage|использование
l'utilité|полезность
la valeur|ценность
la vanité|тщеславие
la vérité|правда
la vertu|добродетель
la victoire|победа
la vieillesse|старость
la vigueur|бодрость
la violence|насилие
la vision|видение
la volonté|воля
la zone|зона

`;