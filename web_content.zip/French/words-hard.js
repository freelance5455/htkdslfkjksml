/* ============================================================
   СЛОВАРЬ СЛОЖНЫХ СЛОВ (уровень C1-C2)
   Формат: французское_слово|русский_перевод
   - Не повторяйте одно и то же французское слово дважды
   - Внутри файла — только эта одна переменная, ничего больше
   - Всего слов: ~2520
   ============================================================ */

window.WORDS_HARD = `

/* ---------- АБСТРАКТНЫЕ СУЩЕСТВИТЕЛЬНЫЕ: ПСИХОЛОГИЯ ---------- */
l'abnégation|самоотверженность
l'abstraction|абстракция
l'absurdité|абсурдность
l'accablement|подавленность
l'acception|значение (слова)
l'accomplissement|свершение
l'accroissement|увеличение
l'acculturation|аккультурация
l'acharnement|упорство
l'acquiescement|согласие
l'adéquation|соответствие
l'adhésion|присоединение
l'affabulation|вымысел
l'affinité|сродство
l'affliction|скорбь
l'aggravation|ухудшение
l'agissement|действие
l'aliénation|отчуждение
l'allégation|утверждение
l'allégeance|верность
l'allégorie|аллегория
l'altération|изменение
l'ambivalence|двойственность
l'amenuisement|уменьшение
l'amertume|горечь
l'amplification|усиление
l'anéantissement|уничтожение
l'anomalie|аномалия
l'antagonisme|антагонизм
l'antinomie|антиномия
l'apaisement|успокоение
l'aperception|апперцепция
l'apitoiement|сострадание
l'aporie|апория
l'apostasie|вероотступничество
l'apothéose|апофеоз
l'appréhension|опасение
l'approbation|одобрение
l'arbitraire|произвол
l'archétype|архетип
l'ardeur|пыл
l'ascendance|восхождение
l'ascétisme|аскетизм
l'aspiration|стремление
l'assiduité|усердие
l'assouvissement|утоление
l'astuce|хитрость
l'atavisme|атавизм
l'atrophie|атрофия
l'atténuation|смягчение
l'authenticité|подлинность
l'autorité|авторитет
l'avarice|скупость
l'avènement|наступление
l'avidité|жадность
la béatitude|блаженство
la bienveillance|благожелательность
la candeur|чистосердечие
la capitulation|капитуляция
la clairvoyance|прозорливость
la clémence|милосердие
la cohérence|связность
la commensurabilité|соизмеримость
la compassion|сострадание
la complaisance|снисходительность
la conciliation|примирение
la concupiscence|вожделение
la condescendance|снисходительность
la connivence|попустительство
la consécration|освящение
la contrition|раскаяние
la controverse|полемика
la convergence|сходимость
la conviction|убеждение
la corruptibilité|подверженность коррупции
la crédibilité|достоверность
la cupidité|алчность
la décadence|упадок
la déférence|почтительность
la délectation|наслаждение
la démagogie|демагогия
la démesure|чрезмерность
la dénégation|отрицание
la désuétude|устарелость
la détermination|решимость
la dévotion|преданность
la dextérité|ловкость
la dichotomie|дихотомия
la dilection|привязанность
la discrétion|сдержанность
la dissension|разногласие
la dissidence|инакомыслие
la dissonance|диссонанс
la divagation|блуждание
la docilité|послушание
la dualité|двойственность
l'ébranlement|потрясение
l'effervescence|кипение
l'effronterie|нахальство
l'éloquence|красноречие
l'embellie|просвет
l'empathie|эмпатия
l'empressement|усердие
l'endurance|выносливость
l'énigme|загадка
l'enjouement|весёлость
l'ennui|скука
l'entendement|рассудок
l'enthousiasme|воодушевление
l'énumération|перечисление
l'éphémère|мимолётное
l'équité|справедливость
l'équivoque|двусмысленность
l'errement|блуждание
l'éruption|вспышка
l'esprit|ум, дух
l'estime|уважение
l'euphémisme|эвфемизм
l'exaltation|восторг
l'exaucement|удовлетворение
l'excès|излишество
l'exigence|требовательность
l'exubérance|изобилие
l'idiosyncrasie|идиосинкразия
l'idolâtrie|идолопоклонство
l'illumination|озарение
l'imbrication|переплетение
l'immanence|имманентность
l'immensité|необъятность
l'immuabilité|неизменность
l'impalpabilité|неосязаемость
l'impertinence|дерзость
l'imprégnation|пропитывание
l'impunité|безнаказанность
l'inanité|тщетность
l'incertitude|неопределённость
l'incidence|влияние
l'incongruité|неуместность
l'incrédulité|неверие
l'indigence|нищета
l'indignation|негодование
l'indolence|безразличие
l'indubitabilité|несомненность
l'inertie|инерция
l'inférence|умозаключение
l'infinité|бесконечность
l'ingéniosité|изобретательность
l'ingérence|вмешательство
l'inhérence|присущность
l'iniquité|несправедливость
l'innocuité|безвредность
l'inquiétude|беспокойство
l'insolence|наглость
l'instabilité|нестабильность
l'insubordination|неповиновение
l'intégrité|целостность
l'intelligibilité|понятность
l'intempérance|невоздержанность
l'interdépendance|взаимозависимость
l'interpellation|обращение
l'intransigeance|непримиримость
l'introspection|самонаблюдение
l'intuition|интуиция
l'invraisemblance|неправдоподобие
l'irrévérence|непочтительность
l'irritabilité|раздражительность
la jubilation|ликование
la lucidité|ясность ума
la magnanimité|великодушие
la mélancolie|меланхолия
la munificence|щедрость
la nonchalance|небрежность
la nostalgie|ностальгия
l'obstination|упрямство
l'omniscience|всезнание
l'opiniâtreté|упорство
l'opulence|изобилие
l'outrecuidance|самонадеянность
la paresse|лень
la perspicacité|проницательность
la piété|благочестие
la placidité|спокойствие
la prééminence|превосходство
la préméditation|предумысел
la prescience|предвидение
la prévoyance|предусмотрительность
la propension|склонность
la prospérité|процветание
la prudence|благоразумие
la pusillanimité|малодушие
la quiétude|покой
la rancœur|злопамятство
la réciprocité|взаимность
la réconciliation|примирение
la récurrence|повторяемость
la rédemption|искупление
la réitération|повторение
la réminiscence|воспоминание
la réprobation|порицание
la résilience|устойчивость
la résignation|смирение
la réticence|сдержанность
la rétrospection|ретроспекция
la révérence|почтение
la sagacité|проницательность
la sérénité|безмятежность
la servilité|раболепие
la sollicitude|заботливость
la spontanéité|непосредственность
la stupidité|глупость
la sublimation|сублимация
la subtilité|тонкость
la suffisance|самодовольство
la superficialité|поверхностность
la sympathie|симпатия
la taciturnité|молчаливость
la ténacité|настойчивость
la témérité|безрассудная смелость
la ténuité|тонкость
la transparence|прозрачность
la tromperie|обман
la turbulence|турбулентность
la véhémence|неистовство
la vénération|почитание
la versatilité|непостоянство
la vicissitude|превратность
la vigilance|бдительность
la vilité|низость
la vivacité|живость
la volubilité|говорливость

/* ---------- ГЛАГОЛЫ СЛОЖНОГО УРОВНЯ ---------- */
abhorrer|питать отвращение
abjurer|отрекаться
abreuver|поить
abroger|отменять
absoudre|отпускать
abstenir|воздерживаться
accabler|отягощать
accaparer|захватывать
accéder|получать доступ
accentuer|подчёркивать
acclamer|приветствовать
accommoder|приспосабливать
accoutumer|приучать
accréditer|аккредитовать
accroître|увеличивать
acharner|ожесточаться
acquiescer|соглашаться
acquitter|оправдывать
adjuger|присуждать
admonester|журить
adonner|предаваться
adoucir|смягчать
adresser|адресовать
affaiblir|ослаблять
affaler|сваливать
affamer|морить голодом
affecter|влиять
affermir|укреплять
afficher|выставлять напоказ
affilier|присоединять
affliger|огорчать
affluer|притекать
affranchir|освобождать
affronter|противостоять
agencer|устраивать
agrémenter|украшать
aiguiser|заострять
aimanter|притягивать
ajourner|откладывать
ajuster|регулировать
alléguer|ссылаться
allier|соединять
allonger|удлинять
amadouer|улещивать
amaigrir|худеть
amasser|накапливать
ambitionner|стремиться
aménager|обустраивать
amener|приводить
amerrir|приводняться
amoindrir|уменьшать
amollir|размягчать
amonceler|нагромождать
amorcer|начинать
amortir|амортизировать
amputer|ампутировать
anéantir|уничтожать
annexer|аннексировать
apitoyer|жалеть
aplatir|сплющивать
apprêter|готовить
apprivoiser|приручать
approvisionner|снабжать
arbitrer|судить
arguer|утверждать
arpenter|мерить шагами
arrimer|закреплять
articuler|членораздельно говорить
asperger|обрызгивать
assainir|оздоровлять
assaisonner|приправлять
assassiner|убивать
assécher|высушивать
assener|наносить удар
asservir|порабощать
assiéger|осаждать
assimiler|усваивать
assombrir|омрачать
assommer|оглушать
assortir|подбирать
assouplir|делать гибким
assouvir|утолять
assujettir|подчинять
astiquer|начищать
atomiser|распылять
atrophier|атрофировать
attabler|усаживать за стол
attarder|задерживать
atteler|запрягать
attiédir|остужать
attiser|разжигать
attribuer|приписывать
attrister|огорчать
augurer|предвещать
auréoler|окружать ореолом
authentifier|удостоверять
automatiser|автоматизировать
avantager|давать преимущество
aventurer|рисковать
aveugler|ослеплять
avilir|унижать
aviver|оживлять
avoisiner|граничить
avorter|прерывать
badigeonner|красить
bafouer|насмехаться
baigner|купать
balancer|качать
balayer|подметать
ballotter|перекатывать
bannir|изгонять
barricader|баррикадировать
barrer|загораживать
batailler|сражаться
bavarder|болтать
bégayer|заикаться
bénir|благословлять
bercer|укачивать
beurrer|намазывать маслом
biaiser|идти окольным путём
bifurquer|разветвляться
blêmir|бледнеть
blinder|бронировать
blottir|прижиматься
boiter|хромать
bondir|прыгать
border|окаймлять
boucler|застёгивать
bouder|дуться
bouillir|кипеть
bouleverser|потрясать
bourdonner|жужжать
bourrer|набивать
bousculer|толкать
brader|распродавать
brancher|подключать
brandir|размахивать
braquer|наводить
braver|бросать вызов
bredouiller|бормотать
briser|разбивать
broncher|спотыкаться
broyer|дробить
bruire|шуметь
brunir|делать коричневым
brusquer|грубить
buter|упираться
cailler|свёртываться
camoufler|маскировать
capitaliser|накапливать
captiver|пленять
capturer|захватывать
caractériser|характеризовать
caresser|ласкать
catalyser|катализировать
cautériser|прижигать
célébrer|праздновать
censurer|цензурировать
cerner|окружать
chagriner|огорчать
chamailler|ссориться
chanceler|шататься
charmer|очаровывать
châtier|наказывать
chausser|обувать
cheminer|идти
chérir|лелеять
chevaucher|ездить верхом
chiffonner|мять
circonscrire|ограничивать
clamer|восклицать
clapoter|плескаться
claquer|хлопать
cligner|щуриться
cloisonner|разделять
clore|закрывать
coaliser|объединять
codifier|кодифицировать
coexister|сосуществовать
coffrer|заключать
coincer|заклинивать
collectionner|коллекционировать
combattre|сражаться
combiner|комбинировать
commémorer|увековечивать память
communier|причащаться
compatir|сочувствовать
compenser|компенсировать
comploter|замышлять
comporter|включать
compromettre|компрометировать
concentrer|концентрировать
concevoir|замышлять
concilier|примирять
concorder|согласовываться
concrétiser|конкретизировать
condamner|осуждать
condenser|сгущать
conditionner|обусловливать
confectionner|изготавливать
confesser|признаваться
confiner|ограничивать
confisquer|конфисковать
conformer|сообразовывать
conforter|укреплять
confronter|сопоставлять
congédier|увольнять
congeler|замораживать
conjuguer|спрягать
conjurer|заклинать
conquérir|завоёвывать
consacrer|посвящать
consentir|соглашаться
consister|состоять
consolider|укреплять
consumer|истощать
contaminer|загрязнять
contempler|созерцать
contracter|сокращать
contraindre|принуждать
contrarier|противоречить
contraster|контрастировать
contredire|противоречить
contribuer|способствовать
convenir|подходить
convertir|преобразовывать
convier|приглашать
convoyer|сопровождать
coordonner|координировать
corroborer|подтверждать
corrompre|развращать
côtoyer|соседствовать
courroucer|гневить
cravacher|хлестать
crépiter|потрескивать
creuser|копать
crever|прорывать
cristalliser|кристаллизовать
croiser|скрещивать
croître|расти
crouler|рушиться
croupir|гнить
cueillir|собирать плоды
culminer|достигать вершины
curer|чистить
damer|утрамбовывать
déambuler|прогуливаться
déballer|распаковывать
débarquer|высаживаться
débattre|обсуждать
débaucher|увольнять
déblayer|расчищать
débloquer|разблокировать
déborder|переливаться
débourser|расходовать
débrouiller|распутывать
débuter|начинать
déceler|обнаруживать
décerner|присуждать
décharger|разгружать
déchiffrer|расшифровывать
déchirer|рвать
déclamer|декламировать
déclencher|запускать
décliner|отклонять
décoller|отклеивать
décomposer|разлагать
décréter|постановлять
dédaigner|пренебрегать
dédommager|возмещать
déduire|выводить
défaire|разбирать
déferler|обрушиваться
défier|бросать вызов
défigurer|обезображивать
défiler|дефилировать
défoncer|взламывать
déformer|деформировать
défricher|расчищать
défroisser|разглаживать
dégénérer|вырождаться
dégonfler|сдувать
dégorger|изливать
dégourdir|разминать
dégrader|ухудшать
déguiser|маскировать
déguster|дегустировать
délabrer|разрушать
délasser|давать отдохнуть
délecter|наслаждаться
déléguer|делегировать
délibérer|обсуждать
délimiter|разграничивать
délivrer|освобождать
déloger|выселять
démanteler|демонтировать
démarrer|запускать
démasquer|разоблачать
démêler|распутывать
démentir|опровергать
démettre|увольнять
démeurer|пребывать
démissionner|уходить в отставку
démocratiser|демократизировать
démolir|сносить
démonter|разбирать
démontrer|доказывать
dénicher|находить
dénier|отказывать
dénombrer|пересчитывать
dénommer|называть
dénoncer|разоблачать
dénoter|обозначать
dénouer|развязывать
dénuder|обнажать
dépayser|сбивать с толку
dépecer|разделывать
dépeindre|изображать
déplaire|не нравиться
déplier|разворачивать
déplorer|оплакивать
déployer|развёртывать
dépouiller|обдирать
dépoussiérer|вытирать пыль
dépraver|развращать
déprimer|угнетать
déraper|соскальзывать
dérégler|расстраивать
dérober|красть
dérouler|разворачивать
désaltérer|утолять жажду
désarmer|разоружать
désavouer|отрекаться
désemparer|покидать
désenchanter|разочаровывать
déséquilibrer|выводить из равновесия
déshériter|лишать наследства
déshonorer|бесчестить
déshydrater|обезвоживать
désigner|обозначать
désinfecter|дезинфицировать
désintégrer|разрушать
désobéir|не подчиняться
désoler|огорчать
désorganiser|дезорганизовать
désorienter|дезориентировать
dessécher|высушивать
desservir|обслуживать
destiner|предназначать
destituer|смещать
détailler|детализировать
déteindre|линять
détenir|владеть
détendre|расслаблять
déterrer|выкапывать
détourner|отклонять
détraquer|ломать
dévaler|спускаться
dévaloriser|обесценивать
dévaliser|обкрадывать
devancer|опережать
déverser|выливать
dévêtir|раздевать
dévier|отклоняться
deviser|беседовать
dévoiler|раскрывать
dévorer|пожирать
diffamer|клеветать
différencier|различать
diffuser|распространять
digérer|переваривать
dilapider|расточать
diluer|разбавлять
discerner|различать
discipliner|дисциплинировать
discourir|рассуждать
discréditer|дискредитировать
discriminer|дискриминировать
disculper|оправдывать
disjoindre|разъединять
disloquer|разрушать
dispenser|освобождать
disperser|рассеивать
disséminer|рассеивать
disséquer|рассекать
dissimuler|скрывать
dissiper|рассеивать
dissocier|разъединять
dissoudre|растворять
dissuader|разубеждать
distancer|опережать
distendre|растягивать
distiller|перегонять
distordre|искривлять
distraire|развлекать
divaguer|блуждать
diverger|расходиться
diversifier|диверсифицировать
divertir|развлекать
divorcer|разводиться
divulguer|разглашать
documenter|документировать
domestiquer|приручать
dompter|укрощать
dorer|золотить
doter|наделять
douer|одаривать
dresser|дрессировать
duper|обманывать
durcir|упрочнять
ébrancher|обрубать ветви
ébranler|потрясать
ébruiter|разглашать
écailler|чистить рыбу
écarquiller|широко открывать
écarter|отстранять
échafauder|строить планы
écharper|разрывать
éclaircir|разъяснять
éclipser|затмевать
éclore|расцветать
éconduire|отказывать
économiser|экономить
écorcher|сдирать кожу
écouler|сбывать
écourter|сокращать
écraser|раздавливать
écrier|восклицать
écrouler|обрушиваться
édicter|предписывать
édifier|возводить
éditer|издавать
éduquer|воспитывать
effaroucher|отпугивать
effectuer|выполнять
effeuiller|обрывать листья
effiler|утончать
effleurer|слегка касаться
effondrer|обрушивать
efforcer|стараться
effrayer|пугать
égaliser|уравнивать
égarer|терять
égayer|развеселить
égoutter|сливать
élaborer|разрабатывать
élancer|устремляться
élargir|расширять
électriser|электризовать
élimer|изнашивать
élucider|разъяснять
éluder|уклоняться
émanciper|эмансипировать
émaner|исходить
emballer|упаковывать
embarquer|грузить
embarrasser|смущать
embaucher|нанимать
embellir|украшать
embêter|надоедать
emboîter|вставлять
embouteiller|создавать пробку
embrouiller|запутывать
embuer|запотевать
émerger|появляться
émettre|испускать
émigrer|эмигрировать
emmagasiner|запасать
emmêler|запутывать
émonder|обрубать
émouvoir|волновать
emparer|захватывать
emperler|покрывать каплями
empester|вонять
empêtrer|запутывать
empiéter|посягать
empiler|складывать в кучу
empocher|класть в карман
empoisonner|отравлять
empresser|спешить
emprisonner|заключать
encadrer|обрамлять
encaisser|получать деньги
encastrer|вставлять
encenser|окуривать
encercler|окружать
enchaîner|приковывать
enchevêtrer|перепутывать
enclencher|запускать
enclore|огораживать
encombrer|загромождать
encourir|навлекать
endetter|вводить в долги
endiguer|сдерживать
endolorir|вызывать боль
endommager|повреждать
endosser|надевать
endurcir|закалять
enfanter|рожать
enfermer|запирать
enfiler|нанизывать
enflammer|воспламенять
enfler|раздувать
enfoncer|вбивать
enfouir|закапывать
enfreindre|нарушать
engendrer|порождать
englober|охватывать
engloutir|поглощать
engouffrer|проглатывать
engourdir|онемевать
enivrer|опьянять
enjamber|перешагивать
enjoindre|предписывать
enjoliver|украшать
enlacer|обвивать
enlaidir|делать уродливым
ennoblir|облагораживать
énoncer|излагать
enquêter|расследовать
enraciner|укоренять
enrager|беситься
enrayer|останавливать
enrichir|обогащать
enrouer|хрипнуть
enrouler|наматывать
ensemencer|засевать
enserrer|сжимать
ensevelir|погребать
ensoleiller|озарять солнцем
ensorceler|околдовывать
entacher|пятнать
entailler|надрезать
entasser|нагромождать
entériner|утверждать
enthousiasmer|воодушевлять
enticher|увлекать
entraver|препятствовать
entrechoquer|сталкивать
entrecouper|перемежать
entrelacer|переплетать
entremêler|смешивать
entreposer|складировать
entreprendre|предпринимать
entrevoir|предвидеть
entrouvrir|приоткрывать
envahir|вторгаться
envenimer|отравлять
envisager|рассматривать
envoler|улетать
épanouir|расцветать
éparpiller|разбрасывать
épater|поражать
épancher|изливать
épaissir|утолщать
épeler|произносить по буквам
épier|подглядывать
épiloguer|рассуждать
éponger|вытирать губкой
épouvanter|ужасать
éprendre|влюбляться
épuiser|истощать
équilibrer|уравновешивать
érafler|царапать
érailler|рвать
ériger|воздвигать
éructer|отрыгивать
escalader|взбираться
escamoter|утаивать
escompter|рассчитывать
escorter|сопровождать
espacer|размещать с промежутками
espionner|шпионить
esquinter|портить
esquisser|набрасывать
essaimer|роиться
essorer|отжимать
essouffler|запыхаться
estomper|затушёвывать
estropier|калечить
étager|располагать ярусами
étaler|раскладывать
éterniser|увековечивать
étêter|обрубать верхушку
étinceler|сверкать
étiqueter|наклеивать ярлыки
étirer|растягивать
étoffer|расширять
étouffer|душить
étourdir|оглушать
étrangler|душить
étreindre|обнимать
évacuer|эвакуировать
évader|бежать
évaporer|испарять
éveiller|будить
éventer|обмахивать
évertuer|усердствовать
évider|выдалбливать
évincer|вытеснять
exagérer|преувеличивать
exalter|превозносить
exaucer|выслушивать
excéder|превышать
exceller|превосходить
excepter|исключать
exciter|возбуждать
exclamer|восклицать
exhiber|выставлять
exhorter|увещевать
exiler|изгонять
expédier|отправлять
expérimenter|экспериментировать
expier|искупать
expirer|истекать
exploiter|эксплуатировать
exterminer|истреблять
extraire|извлекать
extrapoler|экстраполировать
exulter|ликовать
falsifier|фальсифицировать
farcir|фаршировать
fasciner|очаровывать
féconder|оплодотворять
fédérer|объединять
feindre|притворяться
fêler|трескаться
festonner|украшать фестонами
feuilleter|листать
ficeler|связывать
fidéliser|привязывать
figer|застывать
filtrer|фильтровать
finaliser|завершать
fiscaliser|облагать налогом
flamber|пылать
flancher|сдаваться
flâner|прогуливаться
flécher|обозначать стрелками
fléchir|сгибать
fleurir|цвести
fluctuer|колебаться
fluidifier|разжижать
focaliser|фокусировать
fomenter|подстрекать
fonder|основывать
fondre|плавить
forer|бурить
forger|ковать
formaliser|формализовать
fortifier|укреплять
fossiliser|окаменевать
foudroyer|поражать
fouetter|хлестать
fourbir|начищать
fourmiller|кишеть
fracasser|разбивать
fractionner|дробить
fracturer|ломать
fragmenter|фрагментировать
franchir|пересекать
fraterniser|брататься
frauder|обманывать
frictionner|растирать
frissonner|дрожать
froisser|мять
frôler|задевать
fructifier|плодоносить
fuguer|убегать
fulminer|метать громы
fureter|рыскать
fusionner|объединять
fustiger|бичевать
gâcher|портить
galoper|скакать
galvaniser|гальванизировать
garantir|гарантировать
garnir|украшать
gaspiller|расточать
gâter|портить
gazouiller|щебетать
gémir|стонать
généraliser|обобщать
générer|генерировать
germer|прорастать
gesticuler|жестикулировать
gifler|давать пощёчину
glacer|замораживать
glaner|подбирать колосья
globaliser|глобализировать
glorifier|прославлять
gober|проглатывать
gonfler|надувать
gracier|миловать
graduer|градуировать
graisser|смазывать
granuler|гранулировать
grasseyer|картавить
graver|гравировать
gravir|взбираться
greffer|прививать
grelotter|дрожать от холода
griffer|царапать
griffonner|нацарапать
grignoter|грызть
grimacer|гримасничать
grincer|скрипеть
grogner|ворчать
grommeler|бормотать
gronder|ругать
grossir|увеличиваться
guetter|подстерегать
guillotiner|гильотинировать
habituer|приучать
halluciner|галлюцинировать
handicaper|затруднять
hanter|преследовать
harmoniser|гармонизировать
harponner|гарпунить
hausser|повышать
hâter|торопить
héberger|приютить
heurter|ударять
hisser|поднимать
homologuer|утверждать
horripiler|раздражать
hospitaliser|госпитализировать
huiler|смазывать маслом
humecter|увлажнять
humidifier|увлажнять
humilier|унижать
hypnotiser|гипнотизировать
idéaliser|идеализировать
illuminer|освещать
illustrer|иллюстрировать
imbiber|пропитывать
immerger|погружать
immigrer|иммигрировать
immobiliser|обездвиживать
immoler|приносить в жертву
impatienter|раздражать
implanter|внедрять
impliquer|вовлекать
implorer|умолять
imprégner|пропитывать
impressionner|впечатлять
improviser|импровизировать
incarcérer|заключать
incendier|поджигать
inciter|побуждать
incliner|наклонять
incommoder|беспокоить
incorporer|включать
indemniser|возмещать
indigner|возмущать
indisposer|раздражать
induire|вводить в заблуждение
infester|заполонять
infiltrer|просачиваться
infirmer|опровергать
infliger|налагать
influencer|влиять
inhaler|вдыхать
inhiber|подавлять
initier|посвящать
injecter|вводить инъекцию
innover|вводить новшества
inoculer|прививать
insinuer|внушать
insister|настаивать
inspecter|инспектировать
inspirer|вдохновлять
instaurer|устанавливать
instituer|учреждать
instruire|обучать
intensifier|усиливать
intercéder|ходатайствовать
interférer|вмешиваться
interloquer|смущать
interpeller|окликать
interpoler|интерполировать
interpréter|интерпретировать
intimider|запугивать
intituler|озаглавливать
intoxiquer|отравлять
intriguer|интриговать
invalider|аннулировать
inverser|инвертировать
invoquer|ссылаться
irriguer|орошать
irriter|раздражать
isoler|изолировать
jaillir|брызгать
jalouser|завидовать
japper|лаять
jargonner|говорить на жаргоне
jauger|измерять
jeûner|поститься
jongler|жонглировать
jouir|наслаждаться
juger|судить
jurer|клясться
juxtaposer|сопоставлять
labourer|пахать
lacer|шнуровать
lâcher|выпускать
laïciser|секуляризировать
lamenter|плакаться
languir|томиться
lapider|забрасывать камнями
larder|шпиговать
larmoyer|плакать
lasser|утомлять
lécher|лизать
légiférer|законодательствовать
légitimer|узаконивать
léguer|завещать
lessiver|стирать
libérer|освобождать
licencier|увольнять
ligoter|связывать
limer|опиливать
liquéfier|разжижать
liquider|ликвидировать
lisser|гладить
localiser|локализовать
longer|идти вдоль
lubrifier|смазывать
lutter|бороться
maculer|пачкать
magnétiser|магнетизировать
maintenir|поддерживать
majorer|увеличивать
malmener|грубо обращаться
maltraiter|плохо обращаться
manier|управлять
manifester|проявлять
manigancer|замышлять
manipuler|манипулировать
manœuvrer|маневрировать
maquiller|наносить макияж
marchander|торговаться
mariner|мариновать
martyriser|мучить
massacrer|уничтожать
masser|массировать
matérialiser|материализовать
mater|укрощать
maudire|проклинать
mécaniser|механизировать
médire|злословить
méditer|размышлять
méfier|не доверять
mégoter|скупиться
mélanger|смешивать
mémoriser|запоминать
mendier|просить милостыню
mentionner|упоминать
mépriser|презирать
mériter|заслуживать
métamorphoser|превращать
meubler|обставлять
meuler|шлифовать
miauler|мяукать
migrer|мигрировать
mijoter|тушить
militer|бороться
mimer|имитировать
miner|подрывать
minimiser|преуменьшать
mirer|целиться
modérer|умерять
moderniser|модернизировать
moisir|плесневеть
molester|притеснять
monétiser|монетизировать
monnayer|обращать в деньги
monopoliser|монополизировать
morfondre|зябнуть
motiver|мотивировать
mouler|формовать
mouliner|молоть
mousser|пениться
mouvoir|двигать
murer|замуровывать
murmurer|шептать
muter|переводить
mutiler|калечить
mystifier|мистифицировать
narguer|насмехаться
narrer|повествовать
nationaliser|национализировать
natter|заплетать
naviguer|плавать
navrer|огорчать
nécessiter|требовать
négliger|пренебрегать
négocier|вести переговоры
neutraliser|нейтрализовать
nicher|гнездиться
niveler|выравнивать
noircir|чернить
notifier|уведомлять
nouer|завязывать
nuancer|нюансировать
nuire|вредить
objecter|возражать
objectiver|объективировать
oblitérer|заклеивать
obscurcir|затемнять
obséder|преследовать
obstiner|упорствовать
obstruer|загромождать
obtempérer|подчиняться
obvier|устранять
octroyer|даровать
œuvrer|трудиться
offenser|оскорблять
officialiser|официализировать
omettre|упускать
ondoyer|волниться
opiner|высказывать мнение
opprimer|угнетать
optimiser|оптимизировать
orchestrer|организовывать
orienter|ориентировать
orner|украшать
ôter|убирать
ourdir|замышлять
outrager|оскорблять
outrepasser|превышать
ouvrer|работать
ovationner|устраивать овацию
oxyder|окислять
pacifier|умиротворять
pactiser|заключать пакт
pagayer|грести
paître|пастись
pâlir|бледнеть
palper|ощупывать
panacher|смешивать
papillonner|порхать
parachever|завершать
paraître|казаться
paralyser|парализовать
paraphraser|перефразировать
parcourir|пробегать
parier|держать пари
parlementer|вести переговоры
parodier|пародировать
parsemer|усыпать
particulariser|обособлять
parvenir|достигать
passionner|увлекать
pasticher|подражать
patiner|кататься на коньках
pâtir|страдать
patrouiller|патрулировать
pavoiser|украшать флагами
peaufiner|доводить до совершенства
pécher|грешить
peigner|расчёсывать
peler|очищать
pencher|наклонять
pénétrer|проникать
percer|пробивать
percevoir|воспринимать
percuter|ударять
perdurer|продолжаться
pérenniser|увековечивать
perfectionner|совершенствовать
perforer|просверливать
péricliter|приходить в упадок
périr|погибать
perler|перлить
perpétuer|продолжать
perquisitionner|производить обыск
persécuter|преследовать
persévérer|упорствовать
persifler|насмехаться
personnaliser|персонализировать
persuader|убеждать
pervertir|развращать
pester|ругаться
pétiller|искриться
pétrir|месить
peupler|населять
philosopher|философствовать
photocopier|фотокопировать
pianoter|барабанить пальцами
picorer|клевать
piétiner|топтаться
piger|понимать
piler|толочь
piller|грабить
piloter|пилотировать
pincer|щипать
piocher|копать
piquer|колоть
pirater|пиратствовать
pistonner|проталкивать
pivoter|вращаться
placarder|расклеивать
plaider|судиться
plaindre|жаловаться
planer|парить
planifier|планировать
plaquer|накладывать
plâtrer|штукатурить
plisser|морщить
plomber|пломбировать
plonger|погружать
ployer|гнуть
plumer|ощипывать
poignarder|закалывать
poindre|всходить
poinçonner|пробивать
poireauter|ждать
poisser|пачкать смолой
poivrer|перчить
polir|полировать
polluer|загрязнять
polycopier|размножать
pomper|качать
poncer|шлифовать
pondre|нестись
pontifier|важничать
populariser|популяризировать
positionner|позиционировать
poster|отправлять по почте
postuler|подавать заявление
poudrer|пудрить
poursuivre|преследовать
préconiser|рекомендовать
prédire|предсказывать
prédisposer|предрасполагать
prédominer|преобладать
préfigurer|предвещать
préfixer|устанавливать
prélever|взимать
préméditer|предумышлять
préoccuper|заботить
préposer|приставлять
présager|предвещать
prescrire|предписывать
préserver|сохранять
présider|председательствовать
pressentir|предчувствовать
pressurer|эксплуатировать
présumer|предполагать
prétendre|претендовать
prétexter|ссылаться
prévaloir|преобладать
primer|преобладать
priser|ценить
privatiser|приватизировать
priver|лишать
privilégier|давать привилегию
procéder|действовать
proclamer|провозглашать
procurer|доставлять
prodiguer|расточать
profaner|осквернять
proférer|произносить
professer|исповедовать
programmer|программировать
progresser|прогрессировать
prohiber|запрещать
projeter|проецировать
proliférer|размножаться
promouvoir|продвигать
promulguer|обнародовать
prôner|превозносить
pronostiquer|прогнозировать
propager|распространять
prophétiser|пророчествовать
proportionner|соразмерять
proscrire|запрещать
prospecter|разведывать
prospérer|процветать
psalmodier|петь псалмы
puer|вонять
puiser|черпать
pulluler|кишеть
purger|чистить
purifier|очищать
putréfier|гнить
quémander|выпрашивать
quereller|ссориться
questionner|расспрашивать
rabâcher|повторять
rabaisser|принижать
rabattre|сбивать
raccommoder|штопать
raccompagner|провожать
raccorder|соединять
raccourcir|укорачивать
raccrocher|вешать трубку
racheter|выкупать
racler|скрести
radier|вычёркивать
radoter|говорить вздор
radoucir|смягчать
raffermir|укреплять
raffiner|утончать
raffoler|обожать
rafistoler|подлатать
rafler|уносить всё
rafraîchir|освежать
raidir|делать жёстким
railler|насмехаться
raisonner|рассуждать
rajouter|добавлять
rajuster|поправлять
ralentir|замедлять
râler|ворчать
rallier|привлекать
rallonger|удлинять
rallumer|снова зажигать
ramasser|собирать
ramener|приносить обратно
ramer|грести
ramifier|разветвлять
ramollir|размягчать
ramoner|чистить трубу
ramper|ползать
rancir|прогоркать
randonner|совершать поход
ranimer|оживлять
rapetisser|уменьшать
rapiécer|латать
rassasier|насыщать
rassembler|собирать
rasséréner|успокаивать
rasseoir|усаживать
rassurer|успокаивать
ratatiner|сморщивать
ratifier|ратифицировать
rattacher|привязывать
rattraper|догонять
raturer|зачёркивать
ravager|опустошать
ravaler|проглатывать
ravir|восхищать
ravitailler|снабжать
raviver|оживлять
rayer|царапать
rayonner|сиять
réactiver|реактивировать
réaliser|осуществлять
réanimer|реанимировать
rebâtir|перестраивать
rebeller|бунтовать
rebondir|отскакивать
rebuter|отталкивать
recaler|проваливать на экзамене
récapituler|резюмировать
recenser|пересчитывать
réchauffer|подогревать
rechigner|упираться
récidiver|повторяться
réciter|декламировать
réclamer|требовать
récolter|собирать урожай
recommander|рекомендовать
récompenser|награждать
réconcilier|мирить
réconforter|утешать
reconnaître|узнавать
reconquérir|отвоёвывать
reconsidérer|пересматривать
reconstituer|восстанавливать
reconvertir|перепрофилировать
recopier|переписывать
recoudre|зашивать
recourber|загибать
recourir|прибегать
recouvrer|восстанавливать
recracher|выплёвывать
recruter|набирать
rectifier|исправлять
requérir|требовать
récurer|чистить
récuser|отводить
recycler|перерабатывать
rédiger|составлять
redire|повторять
redistribuer|перераспределять
redouter|опасаться
redresser|выпрямлять
réécrire|переписывать
rééditer|переиздавать
réelire|переизбирать
rééquilibrer|восстанавливать равновесие
réessayer|пробовать снова
réévaluer|переоценивать
référer|докладывать
refermer|закрывать снова
refiler|всучивать
refleurir|снова цвести
refluer|отступать
refondre|переплавлять
réformer|реформировать
refouler|оттеснять
réfracter|преломлять
refréner|обуздывать
réfrigérer|охлаждать
réfuter|опровергать
regagner|возвращаться
regarnir|снова снабжать
régénérer|регенерировать
régenter|управлять
régir|управлять
régner|царствовать
regorger|изобиловать
régulariser|урегулировать
réguler|регулировать
rehausser|повышать
réifier|овеществлять
réimprimer|перепечатывать
réincarner|перевоплощать
réinsérer|реинтегрировать
réinstaller|переустанавливать
réintégrer|восстанавливать
réitérer|повторять
rejaillir|брызгать
relâcher|ослаблять
relancer|перезапускать
relater|рассказывать
relativiser|релятивизировать
relayer|сменять
reléguer|ссылать
reluire|блестеть
reluquer|поглядывать
remâcher|пережёвывать
remanger|есть снова
remarier|снова женить
remballer|упаковывать обратно
rembarrer|осаживать
remblayer|засыпать
rembobiner|перематывать
rembourrer|набивать
rembourser|возмещать
rembrunir|омрачать
remédier|исправлять
remémorer|вспоминать
remiser|ставить в гараж
remmener|уводить обратно
remodeler|переделывать
remordre|укусить снова
remorquer|буксировать
rempiler|снова наниматься
remporter|уносить
remuer|двигать
renâcler|фыркать
renaître|возрождаться
renchérir|повышать цену
rendormir|усыплять снова
renfermer|заключать
renfiler|снова нанизывать
renflouer|спасать от банкротства
renfoncer|вдавливать
renier|отрекаться
renifler|сопеть
renommer|переименовывать
renouer|возобновлять
renouveler|обновлять
rénover|обновлять
renseigner|информировать
rentabiliser|делать рентабельным
renverser|опрокидывать
repaître|насыщать
reparaître|появляться снова
repartir|уезжать снова
répartir|распределять
repeindre|перекрашивать
repentir|раскаиваться
répercuter|отражать
repérer|обнаруживать
répertorier|составлять список
repeupler|вновь заселять
repiquer|пересаживать
replacer|переставлять
replanter|пересаживать
replier|складывать
répliquer|возражать
replonger|снова погружаться
reporter|откладывать
reposer|отдыхать
repousser|отталкивать
reprendre|возобновлять
représenter|представлять
réprimer|подавлять
reprocher|упрекать
reproduire|воспроизводить
réprouver|осуждать
republier|переиздавать
répudier|отвергать
répugner|внушать отвращение
réputer|считать
réquisitionner|реквизировать
rescaper|спасать
rescinder|расторгать
résider|проживать
résigner|смиряться
résilier|расторгать
resplendir|блистать
responsabiliser|возлагать ответственность
ressaisir|схватить снова
ressasser|пережёвывать
ressemeler|подбивать подмётки
ressentir|чувствовать
resserrer|сжимать
resservir|подавать снова
ressortir|выходить снова
ressouder|снова спаивать
ressusciter|воскрешать
ressuyer|вытирать
restaurer|восстанавливать
restituer|возвращать
restreindre|ограничивать
résulter|следовать
résumer|резюмировать
resurgir|возникать вновь
rétablir|восстанавливать
retailler|подрезать
retaper|подлатать
retarder|задерживать
retenir|удерживать
retentir|звучать
retirer|убирать
retomber|падать снова
retordre|перекручивать
retoucher|подправлять
retourner|возвращать
retracer|описывать
rétracter|втягивать
retrancher|вычитать
retransmettre|ретранслировать
retravailler|дорабатывать
rétrécir|суживать
retremper|закалять
réunifier|воссоединять
réunir|собирать
réutiliser|повторно использовать
revaloriser|повышать стоимость
révasser|мечтать
révéler|разоблачать
revendiquer|требовать
revendre|перепродавать
rêver|мечтать
revêtir|надевать
revigorer|взбадривать
réviser|пересматривать
revivre|оживать
révolter|возмущать
révolutionner|революционизировать
révoquer|отзывать
ricaner|хихикать
ricocher|рикошетить
ridiculiser|высмеивать
rincer|полоскать
riposter|отвечать ударом
rissoler|подрумянивать
rivaliser|соперничать
rogner|обрезать
roidir|натягивать
romancer|приукрашивать
rompre|разрывать
ronchonner|ворчать
ronfler|храпеть
rosir|розоветь
roucouler|ворковать
rouer|бить палками
rouiller|ржаветь
roupiller|дремать
rouspéter|протестовать
roussir|подрумянивать
routiniser|превращать в рутину
rouvrir|снова открывать
rôder|бродить
ruer|лягаться
rugir|рычать
ruiner|разорять
ruisseler|струиться
ruminer|жевать жвачку
ruser|хитрить
sabler|посыпать песком
saborder|саботировать
sabrer|рубить
saccager|разрушать
sacrifier|жертвовать
saigner|кровоточить
saler|солить
saliver|выделять слюну
saluer|приветствовать
sanctionner|санкционировать
sangloter|рыдать
saper|подрывать
sasser|просеивать
saturer|насыщать
savourer|смаковать
savonner|мылить
scander|скандировать
sceller|запечатывать
schématiser|схематизировать
scier|пилить
scinder|расщеплять
scintiller|сверкать
scléroser|склерозировать
scolariser|обучать
scruter|вглядываться
sculpter|ваять
seconder|помогать
secouer|трясти
secourir|помогать
sécréter|выделять
séculariser|секуляризовать
séduire|соблазнять
segmenter|сегментировать
séjourner|пребывать
sélectionner|отбирать
seller|седлать
sembler|казаться
semer|сеять
sensibiliser|привлекать внимание
seriner|вдалбливать
seringuer|опрыскивать
serpenter|извиваться
serrer|сжимать
sertir|оправлять
sévir|свирепствовать
sidérer|поражать
siéger|заседать
signaler|сигнализировать
signifier|означать
simplifier|упрощать
simuler|симулировать
singer|обезьянничать
siphonner|сифонить
situer|располагать
skier|кататься на лыжах
soigner|лечить
solder|распродавать
solidifier|отвердевать
solliciter|ходатайствовать
sombrer|тонуть
sommeiller|дремать
somnoler|дремать
sonder|зондировать
songer|мечтать
sonoriser|озвучивать
sophistiquer|усложнять
souder|паять
souffler|дуть
souffrir|страдать
souiller|пачкать
soûler|напаивать
soulager|облегчать
soulever|поднимать
souligner|подчёркивать
soumettre|подчинять
soupçonner|подозревать
souper|ужинать
soupirer|вздыхать
sourciller|хмуриться
souscrire|подписываться
sous-estimer|недооценивать
soustraire|вычитать
soutenir|поддерживать
spécialiser|специализировать
spécifier|уточнять
spolier|грабить
sponsoriser|спонсировать
squatter|сквотировать
stabiliser|стабилизировать
standardiser|стандартизировать
stationner|парковаться
statuer|постановлять
stigmatiser|клеймить
stimuler|стимулировать
stipuler|оговаривать
stopper|останавливать
stresser|нервничать
structurer|структурировать
stupéfier|ошеломлять
subdiviser|подразделять
subir|подвергаться
subjuguer|покорять
submerger|затоплять
subordonner|подчинять
subsister|существовать
substituer|заменять
subtiliser|утончать
subvenir|обеспечивать
sucrer|подслащивать
suer|потеть
suffire|хватать
suggérer|предлагать
suicider|совершать самоубийство
suinter|сочиться
suivre|следовать
superposer|накладывать
superviser|контролировать
supplanter|вытеснять
suppléer|замещать
supplier|умолять
supporter|поддерживать
supposer|предполагать
supprimer|удалять
suppurer|гноиться
surélever|надстраивать
surestimer|переоценивать
surfaire|завышать цену
surgeler|быстро замораживать
surgir|внезапно появляться
surmonter|преодолевать
surnager|держаться на поверхности
surnommer|давать прозвище
surpasser|превосходить
surpayer|переплачивать
surplomber|нависать
surprendre|удивлять
sursauter|вздрагивать
surveiller|следить
survenir|случаться
survivre|выживать
survoler|пролетать над
susciter|возбуждать
suspecter|подозревать
suspendre|подвешивать
sustenter|подкреплять
symboliser|символизировать
sympathiser|симпатизировать
synchroniser|синхронизировать
synthétiser|синтезировать
systématiser|систематизировать
tabasser|избивать
tabler|рассчитывать
tacher|пачкать
tâcher|стараться
tâtonner|нащупывать
tailler|обрезать
taire|умалчивать
tambouriner|барабанить
tamiser|просеивать
tancer|бранить
tanguer|качаться
tapisser|обивать
tapoter|похлопывать
taquiner|поддразнивать
tarifer|устанавливать тариф
tartiner|намазывать
tasser|утрамбовывать
tâter|щупать
tatouer|татуировать
taxer|облагать налогом
teindre|красить
télégraphier|телеграфировать
téléviser|телевещать
témoigner|свидетельствовать
tempérer|умерять
temporiser|выжидать
tendre|натягивать
tenter|пытаться
tergiverser|вилять
ternir|тускнеть
terrasser|сваливать
terrifier|ужасать
tester|тестировать
téter|сосать
texturer|текстурировать
théâtraliser|театрализовать
théoriser|теоретизировать
tinter|звенеть
tisser|ткать
titiller|щекотать
titrer|озаглавливать
tolérer|терпеть
tonifier|тонизировать
tonner|греметь
toper|хлопать
torcher|вытирать
tordre|скручивать
torturer|пытать
touiller|перемешивать
tourbillonner|кружиться
tourmenter|мучить
tousser|кашлять
tracasser|беспокоить
tracter|буксировать
traficoter|жульничать
trahir|предавать
traire|доить
tramer|замышлять
trancher|резать
tranquilliser|успокаивать
transbahuter|перетаскивать
transcender|превосходить
transcrire|переписывать
transférer|переносить
transfigurer|преображать
transfuser|переливать
transgresser|преступать
transiger|идти на компромисс
transiter|проходить транзитом
transparaître|просвечивать
transpercer|пронзать
transpirer|потеть
transplanter|пересаживать
transposer|переставлять
traquer|загонять
trébucher|спотыкаться
tremper|мочить
tressaillir|вздрагивать
tresser|заплетать
tricher|обманывать
tricoter|вязать
trier|сортировать
trimer|вкалывать
trimbaler|таскать
triompher|торжествовать
tripatouiller|подделывать
tripler|утраивать
triturer|перемалывать
tronquer|урезать
trotter|семенить
troubler|смущать
trouer|пробивать
truander|жульничать
truster|присваивать
tuméfier|опухать
turbiner|вкалывать
tuteurer|подвязывать к колу
tutoyer|обращаться на «ты»
tyranniser|тиранить
ulcérer|разъедать
unifier|объединять
urger|спешно требоваться
user|изнашивать
usurper|узурпировать
vaciller|шататься
valider|утверждать
valoriser|оценивать
vandaliser|вандализировать
vanner|провеивать
vanter|хвалить
vaporiser|распылять
varier|варьировать
veiller|бодрствовать
vendanger|собирать виноград
venger|мстить
venter|быть ветреным
verbaliser|составлять протокол
verdir|зеленеть
verrouiller|запирать
versifier|рифмовать
vêtir|одевать
vexer|досаждать
vibrer|вибрировать
vicier|портить
vilipender|поносить
violenter|насиловать
violer|нарушать
virer|поворачивать
virevolter|кружиться
visionner|просматривать
visser|привинчивать
visualiser|визуализировать
vitrer|остеклять
vitupérer|порицать
vivifier|оживлять
vociférer|орать
voiler|закрывать вуалью
voisiner|соседствовать
volatiliser|улетучиваться
vomir|рвать
vouer|посвящать
vriller|сверлить
vrombir|гудеть
vulgariser|популяризировать
zébrer|полосить
zézayer|шепелявить
zoner|районировать
zoomer|увеличивать

/* ---------- ПРИЛАГАТЕЛЬНЫЕ СЛОЖНОГО УРОВНЯ ---------- */
abrupt|обрывистый
abscons|непонятный
abstrus|тёмный, сложный
acariâtre|сварливый
acerbe|едкий
acrimonieux|язвительный
affable|приветливый
affligeant|огорчительный
affluent|приток
aguerri|закалённый
aguichant|привлекающий
alerte|бдительный
altier|надменный
ambiant|окружающий
ambivalent|двусмысленный
amène|любезный
amphigourique|туманный
anodin|безобидный
antédiluvien|допотопный
apocalyptique|апокалиптический
apocryphe|апокрифический
aride|засушливый
assidu|усердный
astringent|вяжущий
atavique|атавистический
atemporel|вневременной
austère|суровый
authentique|подлинный
autochtone|коренной
auxiliaire|вспомогательный
avare|скупой
avéré|доказанный
avisé|благоразумный
balbutiant|запинающийся
béat|блаженный
belliqueux|воинственный
bénin|безобидный
bienveillant|благожелательный
bilieux|желчный
blafard|бледный
blessant|оскорбительный
béotien|неотёсанный
branchu|ветвистый
brumeux|туманный
burlesque|бурлескный
caduque|увядший
candide|простодушный
capiteux|дурманящий
captieux|коварный
caustique|едкий
céleste|небесный
cérébral|мозговой
chatoyant|переливчатый
chimérique|призрачный
circonspect|осмотрительный
clairsemé|редкий
clinquant|мишурный
coercitif|принудительный
cohérent|связный
colossal|колоссальный
commensurable|соизмеримый
comminatoire|угрожающий
compendieux|сжатый
compulsif|навязчивый
concomitant|сопутствующий
concupiscent|сладострастный
conjectural|предположительный
conséquent|последовательный
considérable|значительный
constant|постоянный
contigu|смежный
contrit|сокрушённый
convenable|подходящий
convivial|дружелюбный
convulsif|судорожный
corollaire|следствие
corrosif|едкий
cossu|зажиточный
criard|кричащий
croulant|обветшалый
crucial|решающий
cupide|алчный
débridé|разнузданный
dédaigneux|пренебрежительный
défavorable|неблагоприятный
déficient|неполноценный
délectable|восхитительный
délétère|губительный
démesuré|чрезмерный
dénué|лишённый
dépréciatif|уничижительный
déréglé|неумеренный
dérisoire|смехотворный
désabusé|разочарованный
désaffecté|заброшенный
désinvolte|непринуждённый
désœuvré|праздный
déterminant|определяющий
détonnant|контрастирующий
diaphane|прозрачный
didactique|дидактический
diffus|расплывчатый
dilatoire|оттягивающий
disert|красноречивый
disgracieux|неуклюжий
disparate|разнородный
dispendieux|дорогостоящий
dissolu|распущенный
dissuasif|сдерживающий
divin|божественный
docile|послушный
dogmatique|догматический
dolent|жалобный
douteux|сомнительный
draconien|драконовский
drastique|радикальный
ductile|ковкий
dupe|обманутый
ébahi|изумлённый
éblouissant|ослепительный
écarlate|алый
éclectique|эклектичный
éculé|избитый
édifiant|назидательный
élégiaque|элегический
éloquent|красноречивый
élusif|уклончивый
émérite|заслуженный
éminent|выдающийся
empressé|услужливый
énigmatique|загадочный
enjôleur|обаятельный
ennuyeux|скучный
enviable|завидный
épineux|тернистый
éprouvant|изнурительный
équivoque|двусмысленный
éradicable|искоренимый
érudit|эрудированный
eschatologique|эсхатологический
ésotérique|эзотерический
exécrable|отвратительный
exhaustif|исчерпывающий
exigu|тесный
exorable|умилостивимый
expéditif|быстрый
explicite|явный
extatique|экстатический
exténuant|изнурительный
extrinsèque|внешний
fallacieux|обманчивый
fameux|знаменитый
fastidieux|утомительный
fatal|фатальный
fébrile|лихорадочный
fécond|плодовитый
félon|вероломный
fervent|ревностный
fétide|зловонный
feutré|приглушённый
fictif|вымышленный
filandreux|волокнистый
flasque|дряблый
fluet|худощавый
fortuit|случайный
frivole|легкомысленный
frugal|умеренный
fulgurant|молниеносный
funeste|пагубный
futile|пустячный
gargantuesque|необъятный
gauche|неуклюжий
générique|типовой
germain|родственный
glabre|безбородый
grandiloquent|напыщенный
gratuit|необоснованный
grégaire|стадный
grossier|грубый
hasardeux|рискованный
hâtif|поспешный
hautain|надменный
hermétique|герметичный
hétéroclite|разнородный
heuristique|эвристический
honni|опозоренный
hypothétique|гипотетический
idiosyncrasique|идиосинкразический
ignare|невежественный
illimité|безграничный
illusoire|иллюзорный
immuable|неизменный
impavide|неустрашимый
impénétrable|непроницаемый
impérieux|властный
imperturbable|невозмутимый
impitoyable|беспощадный
implacable|неумолимый
implicite|неявный
impromptu|экспромтом
impudique|бесстыдный
impuni|безнаказанный
inabordable|недоступный
inaccessible|недосягаемый
inaccoutumé|непривычный
inadéquat|неадекватный
inaliénable|неотчуждаемый
inanimé|неодушевлённый
inattendu|неожиданный
inaugural|вступительный
incandescent|раскалённый
incisif|резкий
incongru|неуместный
inconsidéré|необдуманный
inconstant|непостоянный
incontestable|неоспоримый
incrédule|неверующий
inculte|невозделанный
indéfectible|непоколебимый
indélébile|неизгладимый
indemne|невредимый
indéniable|неоспоримый
indéterminé|неопределённый
indigent|нищий
indiscret|нескромный
indiscutable|бесспорный
indolent|безразличный
indomptable|неукротимый
indubitable|несомненный
indu|необоснованный
inéluctable|неотвратимый
inepte|неумелый
inexorable|неумолимый
inextricable|запутанный
infaillible|безошибочный
infamant|позорящий
infécond|бесплодный
infime|мельчайший
informulé|невысказанный
ingénu|наивный
inhérent|присущий
inique|несправедливый
injurieux|оскорбительный
inné|врождённый
inopiné|неожиданный
inouï|неслыханный
inqualifiable|неописуемый
insatiable|ненасытный
insidieux|коварный
insignifiant|ничтожный
insolite|необычный
insondable|непостижимый
insoupçonné|неподозреваемый
instable|нестабильный
insubmersible|непотопляемый
intangible|неприкосновенный
intarissable|неиссякаемый
intègre|неподкупный
intempestif|неуместный
interminable|бесконечный
intolérable|невыносимый
intrépide|бесстрашный
intrinsèque|внутренне присущий
inversement|обратно
invétéré|закоренелый
inviolable|нерушимый
irascible|вспыльчивый
irréfutable|неопровержимый
irrémédiable|непоправимый
irréprochable|безупречный
irrévocable|бесповоротный
itérative|повторяющийся
jaculatoire|краткий, отрывистый
jubilatoire|ликующий
laconique|лаконичный
lancinant|ноющий
languissant|томительный
latent|скрытый
légitime|законный
limpide|ясный
lointain|далёкий
loquace|разговорчивый
lucratif|прибыльный
lugubre|мрачный
magnanime|великодушный
malléable|податливый
manifeste|явный
maquillé|подделанный
marginal|второстепенный
marmoréen|мраморный
médiocre|посредственный
mendiant|нищенствующий
mesquin|мелочный
méticuleux|педантичный
mièvre|жеманный
mineur|второстепенный
minutieux|тщательный
misanthrope|мизантропический
mitigé|смягчённый
mordant|едкий
moribond|умирающий
morose|мрачный
mutuel|взаимный
nauséeux|тошнотворный
nébuleux|туманный
néfaste|зловещий
négligeable|незначительный
névralgique|болевой
nocif|вредный
notoire|известный
nubile|брачного возраста
obséquieux|подобострастный
obsolète|устаревший
obtus|тупоугольный
occulte|тайный
odieux|ненавистный
œcuménique|экуменический
offensant|обидный
omnipotent|всемогущий
onéreux|обременительный
opiniâtre|упорный
opulent|богатый
orageux|бурный
outrancier|чрезмерный
outré|преувеличенный
pacifique|мирный
palpable|осязаемый
paradoxal|парадоксальный
parcimonieux|экономный
paresseux|ленивый
partial|пристрастный
paternel|отцовский
pathétique|жалостный
patibulaire|виселичный
paupérisé|обнищавший
perfide|коварный
pérenne|многолетний
péremptoire|категорический
périphérique|периферийный
perméable|проницаемый
pernicieux|пагубный
perpétuel|вечный
persan|персидский
perspicace|проницательный
pertinent|уместный
pervers|извращённый
pesant|тяжёлый
pétulant|резвый
pieux|благочестивый
pinailleur|придирчивый
pittoresque|живописный
pléthorique|избыточный
pluriel|множественный
pondéré|уравновешенный
portatif|переносной
posthume|посмертный
pragmatique|прагматичный
précaire|ненадёжный
précoce|ранний
prédominant|преобладающий
prégnant|выразительный
prématuré|преждевременный
prépondérant|преобладающий
prérogative|прерогатива
pressant|неотложный
présomptueux|самонадеянный
prestigieux|престижный
prévenant|предупредительный
probité|честность
prodigieux|изумительный
proéminent|выступающий
profus|обильный
prolixe|многословный
prompt|быстрый
propice|благоприятный
prosaïque|прозаический
prospère|процветающий
providentiel|провидениальный
prudent|осторожный
pudique|стыдливый
pusillanime|малодушный
putatif|предполагаемый
querelleur|драчливый
quintessencié|рафинированный
radieux|сияющий
râpeux|шероховатый
ratatiné|сморщенный
rationnel|рациональный
ravissant|восхитительный
rébarbatif|отталкивающий
réciproque|взаимный
récurrent|возвратный
réfractaire|неподатливый
régional|региональный
réglé|улаженный
réjouissant|отрадный
reluisant|блестящий
remarquable|выдающийся
remuant|подвижный
renfrogné|нахмуренный
repentant|раскаивающийся
replet|полный
représentatif|показательный
répugnant|отвратительный
résolu|решительный
resserré|сжатый
retors|изворотливый
revêche|неприветливый
révélateur|показательный
révoltant|возмутительный
ric-rac|в обрез
rigide|жёсткий
robuste|крепкий
rocambolesque|невероятный
routinier|рутинный
rugueux|шершавый
rusé|хитрый
sacré|священный
sagace|проницательный
salutaire|благотворный
savant|учёный
scabreux|пикантный
scrupuleux|щепетильный
scrutateur|пытливый
séculaire|вековой
sédentaire|оседлый
séditieux|мятежный
semblable|подобный
sensationnel|сенсационный
sensible|чувствительный
serein|безмятежный
sibyllin|загадочный
significatif|значительный
similaire|сходный
simulé|притворный
sinistre|зловещий
sobre|трезвый
solaire|солнечный
solennel|торжественный
somnolent|сонный
sonore|звучный
sordide|грязный
souverain|верховный
spartiate|спартанский
spectaculaire|эффектный
spontané|непроизвольный
squalide|грязный
stérile|бесплодный
stoïque|стоический
subit|внезапный
sublime|возвышенный
subreptice|тайный
subséquent|последующий
succinct|сжатый
sucré|приторный
suave|мягкий
subjectif|субъективный
supérieur|высший
superflu|излишний
superstitieux|суеверный
supplémentaire|дополнительный
sûr|надёжный
suranné|устарелый
surnaturel|сверхъестественный
susceptible|обидчивый
suspect|подозрительный
svelte|стройный
taciturne|молчаливый
tangible|осязаемый
taquin|насмешливый
téméraire|безрассудный
tempéré|умеренный
tenace|цепкий
tendre|нежный
ténébreux|мрачный
tentant|соблазнительный
terne|тусклый
terre-à-terre|приземлённый
terrifiant|устрашающий
théorique|теоретический
tissé|тканый
tolérant|терпимый
torride|знойный
tortueux|извилистый
touffu|густой
tragique|трагический
transitoire|переходный
transparent|прозрачный
trompeur|обманчивый
tumultueux|бурный
turbulent|беспокойный
ultérieur|последующий
unanime|единодушный
uni|однотонный
unique|уникальный
usé|изношенный
usuel|обычный
utile|полезный
vacant|незанятый
vachard|ленивый
vain|тщетный
valeureux|доблестный
varié|разнообразный
vaste|обширный
véhément|неистовый
véniel|простительный
venimeux|ядовитый
ventru|пузатый
verbeux|многословный
verglacé|обледенелый
vermoulu|червивый
versatile|непостоянный
vertigineux|головокружительный
vé tuste|изношенный
vexatoire|оскорбительный
vicieux|порочный
vigilant|бдительный
vil|подлый
violent|яростный
virulent|вирулентный
visqueux|вязкий
vital|жизненно важный
vivace|живучий
vivifiant|бодрящий
volage|ветреный
volatil|летучий
volubile|говорливый
vorace|прожорливый
vulnérable|уязвимый
zébré|полосатый
zélé|усердный

/* ---------- СУЩЕСТВИТЕЛЬНЫЕ СЛОЖНОГО УРОВНЯ ---------- */
l'aberration|отклонение
l'abjection|подлость
l'abjuration|отречение
l'abnégation|самоотверженность
l'abomination|мерзость
l'abrasion|истирание
l'abrogation|отмена
l'absolution|отпущение
l'abstention|воздержание
l'abstinence|воздержанность
l'abstraction|абстрагирование
l'abysse|бездна
l'acabit|характер
l'académicien|академик
l'accaparement|захват
l'accélération|ускорение
l'accession|восхождение
l'accolade|объятие
l'accommodement|соглашение
l'accointance|знакомство
l'accoutumance|привыкание
l'accréditation|аккредитация
l'acculturation|аккультурация
l'accumulation|накопление
l'accusation|обвинение
l'acérité|жёсткость
l'achèvement|завершение
l'acidité|кислотность
l'aconit|аконит
l'acquisition|приобретение
l'acrimonie|язвительность
l'adage|поговорка
l'adaptation|адаптация
l'adhérence|сцепление
l'adhésion|присоединение
l'adjonction|добавление
l'admiration|восхищение
l'admonition|наставление
l'adolescence|отрочество
l'adulation|обожание
l'adversité|невзгода
l'aération|проветривание
l'affabilité|приветливость
l'affaiblissement|ослабление
l'affectation|притворство
l'afféterie|жеманство
l'affiche|афиша
l'affinité|сродство
l'affirmation|утверждение
l'affleurement|выход на поверхность
l'affliction|скорбь
l'affluence|наплыв
l'affront|оскорбление
l'agencement|расположение
l'agenda|повестка
l'agglomération|агломерация
l'agilité|ловкость
l'agnosticisme|агностицизм
l'agonie|агония
l'agrégat|агрегат
l'agrément|согласие
l'aliénation|отчуждение
l'allégeance|верноподданность
l'allégresse|ликование
l'allégorie|аллегория
l'alliance|союз
l'allocation|пособие
l'allure|ход, вид
l'altération|изменение
l'altruisme|альтруизм
l'amalgame|смешение
l'ambassadeur|посол
l'ambiance|атмосфера
l'ambiguïté|двусмысленность
l'amertume|горечь
l'amitié|дружба
l'amnésie|амнезия
l'amnistie|амнистия
l'amorce|начало
l'amplitude|амплитуда
l'analogie|аналогия
l'anathème|анафема
l'anecdote|анекдот
l'anesthésie|анестезия
l'angoisse|тоска
l'animosité|враждебность
l'annexion|аннексия
l'annihilation|уничтожение
l'annonce|объявление
l'anomalie|аномалия
l'anonymat|анонимность
l'antagonisme|антагонизм
l'antécédent|предшествующее
l'anthropologie|антропология
l'anticipation|предвосхищение
l'antipathie|антипатия
l'antiquité|древность
l'anxiété|тревожность
l'apathie|апатия
l'aperçu|обзор
l'apitoiement|жалость
l'aplomb|уверенность
l'apogée|апогей
l'apologie|апология
l'apostasie|отступничество
l'apostrophe|обращение
l'apothéose|апофеоз
l'apparat|парадность
l'appartenance|принадлежность
l'appât|приманка
l'appel|призыв
l'appellation|название
l'appétit|аппетит
l'application|применение
l'appréciation|оценка
l'appréhension|опасение
l'apprentissage|учение
l'approbation|одобрение
l'approche|подход
l'appui|опора
l'aptitude|способность
l'arbitrage|арбитраж
l'arborescence|древовидная структура
l'archéologie|археология
l'archipel|архипелаг
l'argument|аргумент
l'aridité|сухость
l'arithmétique|арифметика
l'armistice|перемирие
l'arome|аромат
l'arrogance|высокомерие
l'articulation|артикуляция
l'artifice|уловка
l'artisanat|ремесло
l'ascendant|влияние
l'ascèse|аскеза
l'asile|приют
l'aspérité|шероховатость
l'aspiration|вдох
l'assainissement|оздоровление
l'assassinat|убийство
l'assaut|штурм
l'assemblée|собрание
l'assertion|утверждение
l'assiduité|прилежание
l'assimilation|ассимиляция
l'assises|суд присяжных
l'association|объединение
l'assonance|ассонанс
l'assoupissement|дремлют
l'assurance|уверенность
l'asthénie|астения
l'astuce|уловка
l'ataraxie|атараксия
l'atavisme|атавизм
l'athéisme|атеизм
l'atome|атом
l'atout|козырь
l'atrocité|зверство
l'attachement|привязанность
l'atténuation|смягчение
l'attestation|свидетельство
l'attirail|снаряжение
l'attirance|влечение
l'attitude|отношение
l'attrait|привлекательность
l'attribution|присвоение
l'audace|смелость
l'audience|аудиенция
l'augure|предзнаменование
l'aumône|милостыня
l'aura|аура
l'auspice|покровительство
l'austérité|суровость
l'autel|алтарь
l'authenticité|подлинность
l'autocratie|самодержавие
l'automate|автомат
l'autonomie|автономия
l'autopsie|вскрытие
l'avalanche|лавина
l'avarice|скупость
l'avatar|аватар
l'avènement|пришествие
l'avenue|проспект
l'aversion|отвращение
l'aveu|признание
l'avidité|жадность
l'avilissement|унижение
l'axiome|аксиома
la bagatelle|пустяк
la banalité|банальность
la banqueroute|банкротство
la barbarie|варварство
la bassesse|низость
la béatitude|блаженство
la bénévolence|благожелательность
la bienfaisance|благотворительность
la bienveillance|доброжелательность
la bipolarité|биполярность
la bonhomie|добродушие
la bouffonnerie|шутовство
la bouleversement|потрясение
la bravoure|храбрость
la brusquerie|резкость
la brutalité|жестокость
la bureaucratie|бюрократия
la candeur|чистосердечие
la caprice|каприз
la captivité|плен
la carence|недостаток
la caresse|ласка
la caricature|карикатура
la carnation|цвет кожи
la catastrophe|катастрофа
la célébrité|знаменитость
la censure|цензура
la certitude|уверенность
la cervoise|пиво (стар.)
la chaleur|тепло
la charité|милосердие
la chasteté|целомудрие
la chute|падение
la circonspection|осмотрительность
la clairvoyance|прозорливость
la clémence|милосердие
la cohésion|сплочённость
la coïncidence|совпадение
la collusion|сговор
la commisération|сострадание
la commotion|сотрясение
la compassion|сострадание
la compétence|компетентность
la complaisance|угодливость
la complexion|телосложение
la componction|сокрушённость
la compromission|компромисс
la conciliation|примирение
la concision|краткость
la concorde|согласие
la conflagration|пожар
la confusion|путаница
la congénère|сородич
la conjecture|предположение
la connerie|глупость
la conscience|сознание
la conséquence|последствие
la considération|рассмотрение
la consistance|консистенция
la consœur|коллега (ж.)
la conspiration|заговор
la constance|постоянство
la contrainte|принуждение
la contrition|раскаяние
la contusion|ушиб
la convoitise|вожделение
la convulsion|судорога
la coopération|сотрудничество
la coordonnée|координата
la cordialité|сердечность
la corrélation|корреляция
la correspondance|переписка
la corruption|коррупция
la courtoisie|учтивость
la crédibilité|достоверность
la crédulité|доверчивость
la crise|кризис
la cruauté|жестокость
la culmination|кульминация
la cupidité|алчность
la curiosité|любопытство
la cybernétique|кибернетика
la débâcle|крах
la débandade|разброд
la débauche|разврат
la débilité|слабоумие
la déchéance|падение
la décision|решение
la déclamation|декламация
la déconvenue|неудача
la découverte|открытие
la décrépitude|дряхлость
la déduction|вывод
la défaillance|отказ
la déférence|почтительность
la définition|определение
la dégradation|деградация
la délectation|услада
la délibération|обсуждение
la délimitation|разграничение
la démence|слабоумие
la démission|отставка
la démocratie|демократия
la démonstration|демонстрация
la dénégation|отрицание
la déontologie|деонтология
la dépravation|развращённость
la dépréciation|обесценивание
la dérogation|отступление
la désaffection|охлаждение
la désapprobation|неодобрение
la désillusion|разочарование
la désinvolture|непринуждённость
la désolation|опустошение
la désuétude|устарелость
la détérioration|ухудшение
la détermination|решимость
la détresse|отчаяние
la dévastation|опустошение
la déviance|отклонение
la dextérité|ловкость
la dialectique|диалектика
la dichotomie|дихотомия
la didactique|дидактика
la diligence|прилежание
la discorde|разлад
la discrétion|сдержанность
la discrédit|дискредитация
la disparité|несоответствие
la dispense|освобождение
la dispersion|рассеивание
la disproportion|несоразмерность
la dissension|разногласие
la dissimulation|сокрытие
la dissipation|расточительство
la dissolution|растворение
la distorsion|искажение
la divagation|блуждание
la divergence|расхождение
la diversité|многообразие
la divination|гадание
la docilité|послушание
la dogmatique|догматика
la domination|господство
la donation|дарение
la dualité|двойственность
la dubitation|сомнение
la ductilité|ковкость
la duperie|обман
la duplicité|двуличность
la dynamique|динамика
l'ébauche|набросок
l'ébriété|опьянение
l'ébullition|кипение
l'écart|разрыв
l'ecchymose|синяк
l'ecclésiastique|церковнослужитель
l'échafaudage|леса
l'échéance|срок
l'échec|неудача
l'échelle|шкала
l'échiquier|шахматная доска
l'écho|эхо
l'éclat|блеск
l'éclipse|затмение
l'école|школа (учение)
l'écologie|экология
l'économie|экономика
l'écoulement|истечение
l'écriture|письменность
l'édification|назидание
l'effigie|изображение
l'effondrement|обвал
l'effronterie|наглость
l'effusion|излияние
l'égalité|равенство
l'égarement|заблуждение
l'égoïsme|эгоизм
l'élaboration|разработка
l'élan|порыв
l'élection|выборы
l'électricité|электричество
l'élégance|элегантность
l'élévation|возвышение
l'élite|элита
l'éloquence|красноречие
l'élucidation|разъяснение
l'élusion|уклонение
l'émanation|эманация
l'embargo|эмбарго
l'embellie|просвет
l'embrasement|возгорание
l'émergence|возникновение
l'émerveillement|восхищение
l'émission|передача
l'émotion|волнение
l'empathie|сопереживание
l'emphase|напыщенность
l'empire|империя
l'emprise|власть
l'émulation|соревнование
l'énigme|загадка
l'énonciation|высказывание
l'engouement|увлечение
l'enrichissement|обогащение
l'enseignement|преподавание
l'envergure|размах
l'envolée|подъём
l'éphémère|мимолётное
l'épopée|эпопея
l'équilibre|равновесие
l'équité|беспристрастность
l'équivoque|двусмысленность
l'ère|эра
l'ergonomie|эргономика
l'érosion|эрозия
l'errance|блуждание
l'érudition|эрудиция
l'escale|остановка
l'escapade|эскапада
l'esclavage|рабство
l'escompte|скидка
l'espérance|надежда
l'espionnage|шпионаж
l'esthétique|эстетика
l'estime|уважение
l'estocade|удар шпагой
l'ethnologie|этнология
l'étiologie|этиология
l'étiquette|этикет
l'étonnement|изумление
l'étreinte|объятие
l'étude|изучение
l'euphorie|эйфория
l'évaluation|оценка
l'évasion|побег
l'évidence|очевидность
l'exaction|вымогательство
l'exaltation|восторг
l'examen|экзамен
l'exaspération|раздражение
l'excavation|раскопки
l'excellence|превосходство
l'excentricité|эксцентричность
l'exception|исключение
l'exclusion|исключение
l'excursion|экскурсия
l'exécration|проклятие
l'exemplarité|образцовость
l'exercice|упражнение
l'exhalaison|испарение
l'exhibition|показ
l'exhortation|увещевание
l'exigence|требование
l'exil|ссылка
l'existence|существование
l'exode|исход
l'exonération|освобождение
l'expansion|расширение
l'expectative|выжидание
l'expédition|экспедиция
l'expertise|экспертиза
l'exploit|подвиг
l'exploration|исследование
l'exposition|выставка
l'expression|выражение
l'extase|экстаз
l'extension|расширение
l'extinction|вымирание
l'extraction|добыча
l'extradition|экстрадиция
l'extravagance|эксцентричность
la fable|басня
la facétie|шутка
la faconde|красноречие
la faillibilité|погрешимость
la fausseté|фальшь
la fécondité|плодовитость
la félicité|блаженство
la ferveur|пылкость
la férocité|свирепость
la fertilité|плодородие
la fiabilité|надёжность
la fidélité|верность
la filiation|происхождение
la finitude|конечность
la flagrance|очевидность
la flatterie|лесть
la fluctuation|колебание
la focalisation|фокусировка
la fondation|основание
la forfaiture|должностное преступление
la formalité|формальность
la fraternité|братство
la fraude|мошенничество
la frugalité|умеренность
la frustration|фрустрация
la fugacité|мимолётность
la fureur|ярость
la fusion|слияние
la futilité|пустячность
la gageure|пари
la garantie|гарантия
la gaucherie|неловкость
la généalogie|генеалогия
la généralité|обобщение
la générosité|щедрость
la génétique|генетика
la gérance|управление
la gestion|управление
la gloriole|тщеславие
la glossolalie|глоссолалия
la gloutonnerie|обжорство
la gourmandise|лакомство
la grâce|благодать
la gradation|градация
la grammaire|грамматика
la gratitude|благодарность
la gravité|серьёзность
la grégarité|стадность
la griserie|опьянение
la grossièreté|грубость
la garantie|поручительство
la hantise|навязчивая идея
la hardiesse|смелость
la hargne|враждебность
la hâte|спешка
la hégémonie|гегемония
la hérédité|наследственность
la hérésie|ересь
la hésitation|колебание
la hiérarchie|иерархия
la hiérarchisation|иерархизация
la hilarité|веселье
la horde|орда
la hostilité|враждебность
la humilité|смирение
la hygiène|гигиена
la hyperbole|гипербола
la hypocrisie|лицемерие
l'idiosyncrasie|идиосинкразия
l'idolâtrie|идолопоклонство
l'ignominie|позор
l'illégalité|незаконность
l'illégitimité|незаконность
l'illumination|озарение
l'illusion|иллюзия
l'imagination|воображение
l'imbrication|переплетение
l'imitation|подражание
l'immanence|имманентность
l'immensité|необъятность
l'immersion|погружение
l'immigration|иммиграция
l'imminence|близость
l'immobilité|неподвижность
l'immolation|жертвоприношение
l'immunité|иммунитет
l'impasse|тупик
l'impatience|нетерпение
l'impécuniosité|безденежье
l'impénitence|нерасскаянность
l'impératif|императив
l'imperfection|несовершенство
l'impérialisme|империализм
l'impertinence|дерзость
l'impétuosité|стремительность
l'impiété|нечестие
l'implacabilité|неумолимость
l'implication|вовлечение
l'imploration|мольба
l'impolitesse|невежливость
l'importance|важность
l'importunité|навязчивость
l'imposture|обман
l'impotence|бессилие
l'imprécation|проклятие
l'imprégnation|пропитывание
l'impréparation|неподготовленность
l'impression|впечатление
l'imprévisibilité|непредсказуемость
l'imprévoyance|непредусмотрительность
l'imprudence|неосторожность
l'impudence|бесстыдство
l'impuissance|бессилие
l'impulsion|импульс
l'impunité|безнаказанность
l'imputation|вменение
l'inadéquation|несоответствие
l'inanité|тщетность
l'inaptitude|неспособность
l'inattention|невнимательность
l'incandescence|накал
l'incantation|заклинание
l'incapacité|неспособность
l'incarcération|заключение
l'incarnation|воплощение
l'incendie|пожар
l'incertitude|неопределённость
l'incessant|непрерывный
l'incidence|влияние
l'incinération|сжигание
l'incision|разрез
l'incitation|побуждение
l'incivilité|невежливость
l'inclémence|немилосердие
l'inclination|склонность
l'incohérence|несвязность
l'incolore|бесцветный
l'incompatibilité|несовместимость
l'incompétence|некомпетентность
l'incompréhension|непонимание
l'inconduite|неправильное поведение
l'inconscience|несознательность
l'inconséquence|непоследовательность
l'inconstance|непостоянство
l'inconvenance|неуместность
l'incorporation|включение
l'incorrection|неправильность
l'incrédulité|неверие
l'incrimination|обвинение
l'incrustation|инкрустация
l'incubation|инкубация
l'inculpation|обвинение
l'inculture|невежество
l'indécence|непристойность
l'indécision|нерешительность
l'indéfectibilité|непоколебимость
l'indépendance|независимость
l'indicateur|указатель
l'indifférence|безразличие
l'indigence|нищета
l'indignation|негодование
l'indignité|недостойность
l'indiscrétion|нескромность
l'indiscipline|недисциплинированность
l'indisposition|недомогание
l'individualisme|индивидуализм
l'indivision|совладение
l'indolence|праздность
l'indubitabilité|несомненность
l'induction|индукция
l'indulgence|снисходительность
l'industrie|промышленность
l'inégalité|неравенство
l'ineptie|глупость
l'inertie|инерция
l'inexactitude|неточность
l'inexpérience|неопытность
l'infamie|бесчестие
l'infanterie|пехота
l'infatuation|самомнение
l'inférence|вывод
l'infériorité|неполноценность
l'infertilité|бесплодие
l'infidélité|неверность
l'infiltration|инфильтрация
l'infinité|бесконечность
l'inflation|инфляция
l'influence|влияние
l'informatique|информатика
l'information|информация
l'infortune|несчастье
l'ingéniosité|изобретательность
l'ingénuité|простодушие
l'ingérence|вмешательство
l'ingratitude|неблагодарность
l'inhérence|присущность
l'inhibition|заторможенность
l'inhumanité|бесчеловечность
l'inimitié|вражда
l'iniquité|несправедливость
l'initiation|посвящение
l'initiative|инициатива
l'injonction|предписание
l'innocence|невинность
l'innovation|новшество
l'inquiétude|беспокойство
l'insalubrité|нездоровье
l'insatiabilité|ненасытность
l'inscription|запись
l'insécurité|небезопасность
l'insensibilité|бесчувственность
l'insertion|вставка
l'insidiosité|коварство
l'insigne|знак
l'insignifiance|незначительность
l'insistance|настойчивость
l'insolation|солнечный удар
l'insolence|наглость
l'insomnie|бессонница
l'insouciance|беспечность
l'instabilité|нестабильность
l'installation|установка
l'instance|инстанция
l'instauration|установление
l'instigation|подстрекательство
l'instinct|инстинкт
l'institution|учреждение
l'instruction|обучение
l'insubordination|неповиновение
l'insuffisance|недостаточность
l'insulte|оскорбление
l'intégralité|целостность
l'intégration|интеграция
l'intégrité|честность
l'intelligibilité|понятность
l'intelligence|интеллект
l'intempérance|невоздержанность
l'intensité|интенсивность
l'intention|намерение
l'interaction|взаимодействие
l'interdiction|запрет
l'interdépendance|взаимозависимость
l'intérêt|интерес
l'interférence|интерференция
l'interlocuteur|собеседник
l'intermède|интермедия
l'interminable|бесконечный
l'intermittence|прерывистость
l'interpellation|оклик
l'interprétation|толкование
l'interrogation|вопрос
l'interruption|прерывание
l'intersection|пересечение
l'interstice|промежуток
l'intervention|вмешательство
l'intimité|близость
l'intolérance|нетерпимость
l'intoxication|отравление
l'intransigeance|непримиримость
l'intrigue|интрига
l'introduction|введение
l'introspection|самонаблюдение
l'intrusion|вторжение
l'intuition|интуиция
l'invalidation|аннулирование
l'invasion|вторжение
l'invective|брань
l'inventaire|инвентарь
l'invention|изобретение
l'inversion|инверсия
l'investigation|расследование
l'invincibilité|непобедимость
l'inviolabilité|неприкосновенность
l'invraisemblance|неправдоподобие
l'irascibilité|вспыльчивость
l'ironie|ирония
l'irrationalité|иррациональность
l'irréalité|нереальность
l'irrégularité|нерегулярность
l'irréligion|безбожие
l'irrépressibilité|неподавляемость
l'irréprochabilité|безупречность
l'irrésolution|нерешительность
l'irréversibilité|необратимость
l'irrigation|орошение
l'irritation|раздражение
l'isolement|изоляция
l'itinéraire|маршрут
la jalousie|ревность
la jactance|хвастовство
la jalousie|зависть
la jovialité|весёлость
la jubilation|ликование
la judicature|судебная власть
la juridiction|юрисдикция
la jurisprudence|юриспруденция
la justesse|точность
la justification|обоснование
la lâcheté|трусость
la lamentation|жалоба
la lassitude|усталость
la latence|латентность
la légèreté|легкомыслие
la législation|законодательство
la légitimité|законность
la lenteur|медлительность
la lésion|повреждение
la lésine|скаредность
la léthargie|летаргия
la libéralité|щедрость
la libération|освобождение
la licence|лицензия
la limpidité|прозрачность
la litanie|литания
la litige|спор
la logistique|логистика
la loyauté|верность
la lucidité|ясность
la lucrativité|прибыльность
la lugubrité|мрачность
la luxure|похоть
la macération|мацерация
la machination|махинация
la magnificence|великолепие
la magnification|возвеличивание
la majesté|величие
la malignité|злокачественность
la malhonnêteté|нечестность
la malléabilité|податливость
la malfaisance|злодеяние
la malice|озорство
la malnutrition|недоедание
la management|менеджмент
la mansuétude|кротость
la manutention|погрузка
la mappemonde|карта мира
la marginalité|маргинальность
la maturité|зрелость
la médiation|посредничество
la médiocrité|посредственность
la mélancolie|меланхолия
la médisance|злословие
la mémoire|память
la menace|угроза
la méprise|ошибка
la mercantilisation|коммерциализация
la merveille|чудо
la mesquinerie|мелочность
la métamorphose|метаморфоза
la méthode|метод
la méticulosité|педантичность
la mévente|плохой сбыт
la migration|миграция
la minutie|тщательность
la misanthropie|мизантропия
la miséricorde|милосердие
la modération|умеренность
la modestie|скромность
la modification|изменение
la moisson|жатва
la monstruosité|чудовищность
la moralité|нравственность
la morosité|мрачность
la mortalité|смертность
la motivation|мотивация
la mulâtrie|мулатство
la multiplicité|множественность
la munificence|щедрость
la mutation|мутация
la mutualité|взаимность
la mystification|мистификация
la naïveté|наивность
la narration|повествование
la natalité|рождаемость
la négligence|небрежность
la négociation|переговоры
la nervosité|нервозность
la neutralité|нейтралитет
la nocivité|вредность
la nomination|назначение
la nonchalance|беспечность
la norme|норма
la nostalgie|ностальгия
la notoriété|известность
la nourriture|пища
la nouveauté|новизна
la nuisance|вред
la nullité|недействительность
la nutrition|питание
l'obédience|подчинение
l'obéissance|послушание
l'objection|возражение
l'objectivité|объективность
l'obligation|обязательство
l'oblitération|заклеивание
l'obscénité|непристойность
l'obscurité|темнота
l'obsession|одержимость
l'obsolescence|устаревание
l'obstacle|препятствие
l'obstination|упрямство
l'obstruction|обструкция
l'occasion|случай
l'occultation|затмение
l'occupation|занятие
l'octroi|предоставление
l'odyssée|одиссея
l'offense|обида
l'officialisation|официальное оформление
l'olfaction|обоняние
l'oligarchie|олигархия
l'omission|упущение
l'omnipotence|всемогущество
l'omniprésence|вездесущность
l'onction|помазание
l'opacité|непрозрачность
l'opiniâtreté|упорство
l'opportunité|своевременность
l'opposition|противодействие
l'oppression|угнетение
l'opulence|изобилие
l'oraison|молитва
l'orbite|орбита
l'ordination|рукоположение
l'ordinaire|обычное
l'organisation|организация
l'orgueil|гордыня
l'orientation|ориентация
l'origine|происхождение
l'ostentation|показная роскошь
l'ostracisme|остракизм
l'oubli|забвение
l'outrage|оскорбление
l'ouverture|открытие
l'ouvrage|работа
l'ovation|овация
la pacification|умиротворение
la paganisme|язычество
la pagination|пагинация
la panacée|панацея
la panique|паника
la paralysie|паралич
la paraphrase|пересказ
la parcimonie|бережливость
la partialité|пристрастность
la participation|участие
la particularité|особенность
la passivité|пассивность
la paternité|отцовство
la pathologie|патология
la patience|терпение
la patrouille|патруль
la paupérisation|обнищание
la pénalité|наказание
la pénétration|проникновение
la pénibilité|тяжесть
la pénitence|покаяние
la perception|восприятие
la perdition|погибель
la perennité|долговечность
la perfection|совершенство
la perfidie|коварство
la péripétie|перипетия
la périphérie|периферия
la permanence|постоянство
la permission|разрешение
la perpétuité|вечность
la perplexité|недоумение
la persécution|преследование
la persévérance|настойчивость
la persistance|стойкость
la personnalité|личность
la perspicacité|проницательность
la persuasion|убеждение
la perte|потеря
la perversité|извращённость
la pétition|петиция
la petitesse|мелочность
la peur|страх
la phase|фаза
la philanthropie|филантропия
la philosophie|философия
la physionomie|физиономия
la picturalité|живописность
la piété|благочестие
la piraterie|пиратство
la pitié|жалость
la placidité|спокойствие
la plénitude|полнота
la pluralité|множественность
la polémique|полемика
la polissonnerie|шалость
la pollution|загрязнение
la polyvalence|многофункциональность
la pompe|помпа
la ponctualité|пунктуальность
la popularité|популярность
la postérité|потомство
la posture|поза
la potentialité|потенциальность
la poudre|порошок
la pragmatique|прагматика
la prédilection|пристрастие
la prédiction|предсказание
la prédominance|преобладание
la prééminence|превосходство
la préface|предисловие
la préférence|предпочтение
la préhension|схватывание
la préhistoire|предыстория
la prémonition|предчувствие
la préméditation|предумышленность
la prémisse|предпосылка
la préoccupation|озабоченность
la prépondérance|преобладание
la préposition|предлог
la prérogative|прерогатива
la prescience|предвидение
la prescription|предписание
la présence|присутствие
la préservation|сохранение
la présidence|председательство
la pression|давление
la prestation|исполнение
la prestidigitation|фокусничество
la présomption|предположение
la prévention|предупреждение
la prévoyance|предусмотрительность
la primauté|первенство
la priorité|приоритет
la privation|лишение
la probabilité|вероятность
la probité|честность
la procédure|процедура
la procréation|деторождение
la prodigalité|расточительность
la production|производство
la profanation|осквернение
la profession|профессия
la profondeur|глубина
la progéniture|потомство
la progression|прогрессия
la prohibition|запрет
la projection|проекция
la prolifération|разрастание
la prolixité|многословность
la promesse|обещание
la promotion|повышение
la promptitude|быстрота
la propension|склонность
la prophétie|пророчество
la proportion|пропорция
la proposition|предложение
la propriété|собственность
la proscription|изгнание
la prospérité|процветание
la prostitution|проституция
la protection|защита
la protestation|протест
la prouesse|подвиг
la provenance|происхождение
la provocation|провокация
la prudence|благоразумие
la psychanalyse|психоанализ
la psychose|психоз
la puberté|половое созревание
la publicité|публичность
la pudeur|стыдливость
la puérilité|ребячество
la punition|наказание
la pureté|чистота
la pusillanimité|малодушие
la qualification|квалификация
la quantité|количество
la querelle|ссора
la quête|поиск
la quiétude|спокойствие
la quintessence|квинтэссенция
la quotidienneté|повседневность
la raillerie|насмешка
la rancune|злопамятство
la rapidité|быстрота
la rareté|редкость
la rationalité|рациональность
la réaction|реакция
la rébellion|мятеж
la récrimination|жалоба
la récolte|урожай
la recommandation|рекомендация
la récompense|награда
la reconnaissance|признательность
la reconquête|отвоевание
la recrudescence|обострение
la rectitude|прямота
la récurrence|возврат
la rédaction|составление
la rédemption|искупление
la réduction|сокращение
la réédition|переиздание
la réfection|переделка
la référence|отсылка
la réforme|реформа
la réflexion|размышление
la réfutation|опровержение
la régence|регентство
la régénération|возрождение
la régression|регрессия
la régularité|регулярность
la réhabilitation|реабилитация
la réitération|повторение
la relation|отношение
la relativité|относительность
la relaxation|расслабление
la relégation|изгнание
la relève|смена
la religieuse|монахиня
la relique|реликвия
la remise|скидка
la remontrance|увещевание
la rémunération|вознаграждение
la renaissance|возрождение
la renommée|известность
la renonciation|отказ
la réorganisation|реорганизация
la répression|репрессия
la réprimande|выговор
la reprise|возобновление
la réprobation|порицание
la répugnance|отвращение
la réputation|репутация
la requête|просьба
la réquisition|реквизиция
la rescousse|спасение
la réserve|сдержанность
la résidence|резиденция
la résignation|смирение
la résistance|сопротивление
la résolution|решение
la résonance|резонанс
la résorption|рассасывание
la responsabilité|ответственность
la ressemblance|сходство
la ressource|ресурс
la restauration|реставрация
la restitution|возврат
la restriction|ограничение
la résultante|равнодействующая
la résurgence|возрождение
la rétention|удержание
la réticence|сдержанность
la retombée|последствие
la retraite|отставка
la réunion|собрание
la revanche|месть
la révélation|откровение
la revendication|требование
la revendication|претензия
la réverbération|отражение
la révérence|почтение
la revue|обзор
la révolution|революция
la rhétorique|риторика
la rigidité|жёсткость
la rigueur|строгость
la riposte|отпор
la rivalité|соперничество
la robustesse|прочность
la rondeur|округлость
la roublardise|хитрость
la routine|рутина
la rudesse|грубость
la rumeur|слух
la rusticité|простота
la sagacité|проницательность
la sagesse|мудрость
la salubrité|здоровье
la sanctification|освящение
la sang-froid|хладнокровие
la satiété|пресыщение
la satiété|насыщение
la satisfaction|удовлетворение
la saturation|насыщение
la sauvagerie|дикость
la saveur|вкус
la scélératesse|злодейство
la scission|раскол
la sécheresse|сухость
la sédentarité|оседлость
la séduction|обаяние
la ségrégation|сегрегация
la séléction|отбор
la sémantique|семантика
la sénilité|старческое слабоумие
la sensibilité|чувствительность
la sensualité|чувственность
la sentence|приговор
la sentimentalité|сентиментальность
la séquence|последовательность
la sérénité|безмятежность
la servilité|раболепие
la servitude|рабство
la sévérité|суровость
la sibylle|сивилла
la signification|значение
la similitude|сходство
la simplicité|простота
la simultanéité|одновременность
la sincérité|искренность
la singularité|своеобразие
la sinistralité|леворукость
la sociabilité|общительность
la solidarité|солидарность
la solidité|прочность
la solitude|одиночество
la sollicitation|ходатайство
la sollicitude|заботливость
la somnolence|сонливость
la sophistication|изощрённость
la sordidité|грязь
la soumission|подчинение
la soudaineté|внезапность
la souplesse|гибкость
la sournoiserie|скрытность
la souscription|подписка
la souveraineté|суверенитет
la spaciosité|просторность
la spoliation|ограбление
la spontanéité|непосредственность
la sporadisme|спорадичность
la stabilité|стабильность
la stérilité|бесплодие
la stoïcisme|стоицизм
la stupeur|оцепенение
la stupidité|глупость
la subordination|подчинение
la subversion|подрыв
la succulence|сочность
la suffisance|самодовольство
la suggestion|внушение
la sujétion|зависимость
la supériorité|превосходство
la superficialité|поверхностность
la supplication|мольба
la surcharge|перегрузка
la surenchère|перебивание цены
la surabondance|изобилие
la surenchère|перебивание
la surexcitation|перевозбуждение
la surface|поверхность
la surpopulation|перенаселение
la surveillance|наблюдение
la survie|выживание
la susceptibilité|обидчивость
la suspicion|подозрение
la symbiose|симбиоз
la symétrie|симметрия
la sympathie|симпатия
la syncope|обморок
la syndicalisation|объединение в профсоюз
la synonymie|синонимия
la synthèse|синтез
la systématisation|систематизация
la taciturnité|молчаливость
la tactique|тактика
la tanière|логово
la tarification|тарификация
la tautologie|тавтология
la témérité|безрассудство
la tempérance|воздержанность
la témérité|отвага
la ténacité|упорство
la tension|напряжение
la tentation|искушение
la ténuité|тонкость
la tergiversation|виляние
la terminologie|терминология
la terrasse|терраса
la territorialité|территориальность
la timidité|застенчивость
la tolérance|терпимость
la torpeur|оцепенение
la torture|пытка
la totalité|целостность
la tourmente|смятение
la tournure|оборот
la tradition|традиция
la trahison|предательство
la tranquillité|спокойствие
la transaction|сделка
la transcendance|трансцендентность
la transcription|переписывание
la transgression|нарушение
la transition|переход
la transparence|прозрачность
la transpiration|потоотделение
la transplantation|пересадка
la transport|транспорт
la transposition|перестановка
la trappe|люк
la traque|травля
la traumatisme|травма
la traversée|пересечение
la trêve|перемирие
la tribulation|злоключение
la tristesse|печаль
la trivialité|пошлость
la tromperie|обман
la trouvaille|находка
la truculence|выразительность
la turbulence|буйность
la tyrannie|тирания
l'ubiquité|вездесущность
l'ultimatum|ультиматум
l'unanimité|единодушие
l'uniformité|единообразие
l'union|объединение
l'urbanité|учтивость
l'urgence|срочность
l'usurpation|узурпация
l'utilité|польза
l'utopie|утопия
la vacance|вакансия
la vacuité|пустота
la vagabondage|бродяжничество
la vagabondage|бродяжничество
la vaine|тщетность
la valeur|ценность
la validation|утверждение
la vanité|тщеславие
la variation|изменение
la vaticination|пророчество
la végétation|растительность
la velléité|полужелание
la vénération|благоговение
la vengeance|месть
la vénalité|продажность
la vérification|проверка
la versatilité|непостоянство
la vertu|добродетель
la vétusté|ветхость
la vexation|оскорбление
la viabilité|жизнеспособность
la vicissitude|превратность
la victimisation|виктимизация
la viduité|вдовство
la vigilance|бдительность
la vigueur|сила
la vindicte|мстительность
la vingtaine|двадцатка
la violation|нарушение
la violence|насилие
la virilité|мужественность
la visée|цель
la visibilité|видимость
la vision|видение
la vitalité|жизненность
la vivacité|живость
la vocation|призвание
la vogue|мода
la volatilité|летучесть
la volonté|воля
la volupté|сладострастие
la voracité|прожорливость
la vulgarité|вульгарность
la vulnérabilité|уязвимость
la zizanie|разлад

`;