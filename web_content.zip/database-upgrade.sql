-- CONNECTLY V2 DATABASE MIGRATION

-- Username and recent chat fields
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS username TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique
ON public.profiles (LOWER(username))
WHERE username IS NOT NULL;

ALTER TABLE public.chats
ADD COLUMN IF NOT EXISTS last_message_at TIMESTAMPTZ;

UPDATE public.chats
SET last_message_at=created_at
WHERE last_message_at IS NULL;

ALTER TABLE public.messages
ADD COLUMN IF NOT EXISTS message_type TEXT NOT NULL DEFAULT 'text';

ALTER TABLE public.messages
ADD COLUMN IF NOT EXISTS media_path TEXT;

-- Safe membership function (avoids recursive RLS)
CREATE OR REPLACE FUNCTION public.is_connectly_member(p_chat_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path=public
AS $$
 SELECT EXISTS (
  SELECT 1 FROM public.chat_members
  WHERE chat_id=p_chat_id AND user_id=(SELECT auth.uid())
 );
$$;

CREATE OR REPLACE FUNCTION public.is_connectly_creator(p_chat_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path=public
AS $$
 SELECT EXISTS (
  SELECT 1 FROM public.chats
  WHERE id=p_chat_id AND created_by=(SELECT auth.uid())
 );
$$;

REVOKE ALL ON FUNCTION public.is_connectly_member(uuid) FROM public;
REVOKE ALL ON FUNCTION public.is_connectly_creator(uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.is_connectly_member(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_connectly_creator(uuid) TO authenticated;

-- Repair chat and membership policies
DROP POLICY IF EXISTS "Read member chats" ON public.chats;
DROP POLICY IF EXISTS "Create chats" ON public.chats;
DROP POLICY IF EXISTS "Read memberships" ON public.chat_members;
DROP POLICY IF EXISTS "Add members" ON public.chat_members;
DROP POLICY IF EXISTS "Read messages" ON public.messages;
DROP POLICY IF EXISTS "Send messages" ON public.messages;

CREATE POLICY "Read member chats" ON public.chats
FOR SELECT TO authenticated
USING (
 created_by=(SELECT auth.uid())
 OR public.is_connectly_member(id)
);

CREATE POLICY "Create chats" ON public.chats
FOR INSERT TO authenticated
WITH CHECK (created_by=(SELECT auth.uid()));

CREATE POLICY "Read memberships" ON public.chat_members
FOR SELECT TO authenticated
USING (public.is_connectly_member(chat_id));

CREATE POLICY "Add members" ON public.chat_members
FOR INSERT TO authenticated
WITH CHECK (public.is_connectly_creator(chat_id));

CREATE POLICY "Read messages" ON public.messages
FOR SELECT TO authenticated
USING (public.is_connectly_member(chat_id));

CREATE POLICY "Send messages" ON public.messages
FOR INSERT TO authenticated
WITH CHECK (
 sender_id=(SELECT auth.uid())
 AND public.is_connectly_member(chat_id)
);

-- Recent chat timestamp trigger
CREATE OR REPLACE FUNCTION public.connectly_update_chat_time()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
BEGIN
 UPDATE public.chats
 SET last_message_at=NEW.created_at
 WHERE id=NEW.chat_id;
 RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS connectly_message_timestamp ON public.messages;

CREATE TRIGGER connectly_message_timestamp
AFTER INSERT ON public.messages
FOR EACH ROW
EXECUTE FUNCTION public.connectly_update_chat_time();

-- Private voice message storage
INSERT INTO storage.buckets
(id,name,public,file_size_limit,allowed_mime_types)
VALUES (
 'connectly-voice','connectly-voice',false,10485760,
 ARRAY['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav','audio/aac']
)
ON CONFLICT(id) DO UPDATE SET
 public=false,file_size_limit=10485760,
 allowed_mime_types=EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Connectly voice read" ON storage.objects;
DROP POLICY IF EXISTS "Connectly voice upload" ON storage.objects;

CREATE POLICY "Connectly voice read"
ON storage.objects FOR SELECT TO authenticated
USING (
 bucket_id='connectly-voice'
 AND public.is_connectly_member(
  (storage.foldername(name))[1]::uuid
 )
);

CREATE POLICY "Connectly voice upload"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
 bucket_id='connectly-voice'
 AND (storage.foldername(name))[2]=(SELECT auth.uid())::text
 AND public.is_connectly_member(
  (storage.foldername(name))[1]::uuid
 )
);
