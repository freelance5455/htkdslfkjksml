# Botline Android Port (from desktop 1.0.14)

This project keeps the original Botline 1.0.14 renderer and replaces the Electron `preload.cjs` / IPC layer with an Android/browser-compatible `window.botline` bridge.

## Implemented in the mobile bridge
- state loading/persistence
- encrypted-at-rest app state (AES-GCM; key stored in Capacitor Preferences/app-private storage)
- Telegram API ID/hash setup
- Telegram user login: phone -> code -> optional 2FA -> StringSession
- Telegram bot token verification
- saved accounts, toggle, remove, emergency pause
- Telegram dialogs/groups for user accounts
- text/media sends for Telegram user and bot accounts
- immediate multi-account dispatch
- text schedules while the app is active
- basic account tasks: check, refresh groups, pause, resume
- renderer callbacks: auth request/error, state changed

## Deliberately still pending
The desktop build's Reddit/Instagram OAuth callback servers, social publishing, member-invite queue, and persistent recurring-media attachments need their own mobile adapters. The bridge exposes the same API names and returns a clear "not ported yet" error for these instead of silently changing behavior.

## Build
Requires Node.js, Android Studio / Android SDK, and Java 17+.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Then build/sign the APK from Android Studio or Gradle.

The app ID is `is.botline.mobile`.
