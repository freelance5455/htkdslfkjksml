const api = window.botline;
let state = { accounts: [], schedules: [], logs: [], health: { totals: {}, failureRate: 0, status: "good", byAccount: [] }, telegramSetup: false, telegramApiId: null };
let currentAuthKind = null;
let dialogs = [];
let forceApiSetup = false;
let selectedAccountIds = new Set();
let groupEmptyMessage = "No groups or channels found.";
let selectedMedia = null;
let selectedTaskAccountIds = new Set();
let selectedInviteAccountIds = new Set();
let inviteDialogs = [];
let inviteStartAccountId = null;
let inviteAccountStats = [];
let inviteLoopTotal = 0;
let inviteLoopProcessed = 0;
let continuingInviteLoop = false;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const escapeHtml = (value = "") => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
const accountName = (id) => state.accounts.find((item) => item.id === id)?.name || "Removed account";
const scheduleAccountIds = (schedule) => schedule.accountIds?.length ? schedule.accountIds : (schedule.accountId ? [schedule.accountId] : []);
const scheduleAccountNames = (schedule) => scheduleAccountIds(schedule).map(accountName).join(", ") || "No accounts";
const fmtDate = (value) => value ? new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(value)) : "Never";
const fmtInterval = (minutes) => minutes < 60 ? `${minutes} min` : minutes < 1440 ? `${minutes / 60} hr` : minutes < 10080 ? `${minutes / 1440} day` : "1 week";
const accountPlatform = (account) => ({ bot: "Telegram bot", user: "Telegram phone", reddit: "Reddit", instagram: "Instagram" }[account.type] || account.type);
const accountIdentity = (account) => account.type === "reddit" ? `u/${account.username}` : account.username ? `@${account.username}` : account.phoneHint || account.telegramId || account.instagramId || "Connected account";

function toast(message, error = false) {
  const node = $("#toast"); node.textContent = message; node.className = `toast${error ? " error" : ""}`;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => node.classList.add("hidden"), 4200);
}
function errorMessage(error) { return String(error?.message || error || "Something went wrong.").replace(/^Error invoking remote method '[^']+': Error: /, ""); }
function setBusy(button, busy, busyText = "Working…") { if (!button) return; if (busy) { button.dataset.label = button.textContent; button.textContent = busyText; button.disabled = true; } else { button.textContent = button.dataset.label || button.textContent; button.disabled = false; } }
function empty(text) { return `<div class="empty">${escapeHtml(text)}</div>`; }

function go(view) {
  $$(".view").forEach((node) => node.classList.toggle("active", node.id === `view-${view}`));
  $$(".nav-item").forEach((node) => node.classList.toggle("active", node.dataset.view === view));
  const names = { overview: ["COMMAND CENTER", "Overview"], compose: ["MESSAGE CONTROL", "Send message"], social: ["SOCIAL CONTROL", "Social publishing"], invite: ["MEMBER CONTROL", "Invite members"], tasks: ["ACCOUNT AUTOMATION", "Account tasks"], accounts: ["CONNECTIONS", "Accounts"], schedules: ["AUTOMATION", "Schedules"], activity: ["DELIVERY LOG", "Activity"] };
  $("#eyebrow").textContent = names[view][0]; $("#page-title").textContent = names[view][1];
}

function render() {
  const activeAccounts = state.accounts.filter((item) => item.enabled).length;
  const activeSchedules = state.schedules.filter((item) => item.enabled).length;
  const delivered = state.logs.filter((item) => item.status === "delivered").length;
  const failed = state.logs.filter((item) => item.status === "failed").length;
  $("#metrics").innerHTML = [
    [activeAccounts, "Active accounts", `${state.accounts.length} connected`],
    [activeSchedules, "Running schedules", `${state.schedules.length} configured`],
    [delivered, "Delivered", "Recent local log"],
    [failed, "Failed", failed ? "Needs attention" : "All clear"],
  ].map(([value,label,note]) => `<div class="metric"><small>${label}</small><strong>${value}</strong><span>${note}</span></div>`).join("");
  renderHealth();

  const accountRows = state.accounts.slice(0, 4).map(accountMini).join("");
  $("#overview-accounts").innerHTML = accountRows ? `<div class="mini-list">${accountRows}</div>` : empty("Connect a Telegram, Reddit, or Instagram account to begin.");
  const next = [...state.schedules].filter((item) => item.enabled).sort((a,b) => Date.parse(a.nextRunAt) - Date.parse(b.nextRunAt)).slice(0,4);
  $("#overview-schedules").innerHTML = next.length ? `<div class="mini-list">${next.map(scheduleMini).join("")}</div>` : empty("No scheduled messages yet.");
  $("#overview-activity").innerHTML = state.logs.length ? `<div class="mini-list">${state.logs.slice(0,5).map(logMini).join("")}</div>` : empty("Delivery results will appear here.");

  $("#accounts-list").innerHTML = state.accounts.length ? state.accounts.map(accountCard).join("") : empty("No accounts connected. Use “Connect account” to add one.");
  $("#schedules-list").innerHTML = state.schedules.length ? state.schedules.map(scheduleCard).join("") : empty("No schedules. Create one from Send message.");
  $("#activity-list").innerHTML = state.logs.length ? `<div class="log-head"><span>Time</span><span>Account</span><span>Destination</span><span>Source</span><span>Status</span></div>${state.logs.map(logRow).join("")}` : empty("No delivery activity yet.");

  const validIds = new Set(state.accounts.filter((item) => item.enabled && ["bot", "user"].includes(item.type)).map((item) => item.id));
  selectedAccountIds = new Set([...selectedAccountIds].filter((id) => validIds.has(id)));
  $("#compose-accounts").innerHTML = state.accounts.length ? state.accounts.map((account) => {
    const selectable = account.enabled && ["bot", "user"].includes(account.type);
    const selected = selectedAccountIds.has(account.id);
    const note = selectable ? accountPlatform(account) : ["reddit", "instagram"].includes(account.type) ? `${accountPlatform(account)} · use Social publishing` : `${accountPlatform(account)} · Paused`;
    return `<label class="account-choice ${selected ? "selected" : ""} ${selectable ? "" : "disabled"}"><input type="checkbox" data-account-id="${account.id}" ${selected ? "checked" : ""} ${selectable ? "" : "disabled"}><div class="avatar ${account.type}">${escapeHtml((account.name || "?")[0])}</div><div class="row-main"><strong>${escapeHtml(account.name)}</strong><small>${escapeHtml(note)}</small></div></label>`;
  }).join("") : empty("Connect an account first.");
  const taskIds = new Set(state.accounts.map((item) => item.id));
  selectedTaskAccountIds = new Set([...selectedTaskAccountIds].filter((id) => taskIds.has(id)));
  $("#task-accounts").innerHTML = state.accounts.length ? state.accounts.map((account) => {
    const selected = selectedTaskAccountIds.has(account.id);
    return `<label class="account-choice ${selected ? "selected" : ""}"><input type="checkbox" data-task-account-id="${account.id}" ${selected ? "checked" : ""}><div class="avatar ${account.type}">${escapeHtml((account.name || "?")[0])}</div><div class="row-main"><strong>${escapeHtml(account.name)}</strong><small>${escapeHtml(accountPlatform(account))}${account.enabled ? "" : " · Paused"}</small></div></label>`;
  }).join("") : empty("Connect an account first.");
  const inviteIds = new Set(state.accounts.filter((item) => item.enabled && item.type === "user").map((item) => item.id));
  selectedInviteAccountIds = new Set([...selectedInviteAccountIds].filter((id) => inviteIds.has(id)));
  $("#invite-accounts").innerHTML = state.accounts.length ? state.accounts.map((account) => {
    const selectable = account.enabled && account.type === "user";
    const selected = selectedInviteAccountIds.has(account.id);
    const note = account.type === "user" ? (account.enabled ? "Phone account" : "Phone account · Paused") : `${accountPlatform(account)} · cannot invite Telegram members`;
    return `<label class="account-choice ${selected ? "selected" : ""} ${selectable ? "" : "disabled"}"><input type="checkbox" data-invite-account-id="${account.id}" ${selected ? "checked" : ""} ${selectable ? "" : "disabled"}><div class="avatar ${account.type}">${escapeHtml((account.name || "?")[0])}</div><div class="row-main"><strong>${escapeHtml(account.name)}</strong><small>${note}</small></div></label>`;
  }).join("") : empty("Connect a phone account first.");
  const needsSetup = !state.telegramSetup || forceApiSetup;
  $("#api-setup").classList.toggle("hidden", !needsSetup);
  $("#api-ready").classList.toggle("hidden", needsSetup);
  $("#api-id").required = needsSetup;
  $("#api-hash").required = needsSetup;
  if (needsSetup && state.telegramApiId && !$("#api-id").value) $("#api-id").value = state.telegramApiId;
  const socialCurrent = $("#social-account").value;
  const socialAccounts = state.accounts.filter((account) => account.enabled && ["reddit", "instagram"].includes(account.type));
  $("#social-account").innerHTML = socialAccounts.length ? socialAccounts.map((account) => `<option value="${escapeHtml(account.id)}">${escapeHtml(account.name)} · ${escapeHtml(accountPlatform(account))}</option>`).join("") : `<option value="">Connect Reddit or Instagram first</option>`;
  if (socialAccounts.some((account) => account.id === socialCurrent)) $("#social-account").value = socialCurrent;
  updateSocialFields();
  renderSendOrder();
  renderTaskOrder();
  renderInviteOrder();
}
function renderHealth() {
  const health = state.health || { totals: {}, failureRate: 0, status: "good", byAccount: [] };
  const label = health.status === "needs-review" ? "Needs review" : health.status === "watch" ? "Watch" : "Good";
  $("#health-status").textContent = label;
  $("#health-status").className = `badge ${health.status === "needs-review" ? "fail" : health.status === "good" ? "ok" : ""}`;
  $("#health-rate").textContent = `${health.failureRate || 0}%`;
  const totals = health.totals || {};
  $("#health-breakdown").innerHTML = [
    ["Delivered", totals.delivered || 0],
    ["Invited", totals.invited || 0],
    ["Skipped", totals.skipped || 0],
    ["Failed", totals.failed || 0],
    ["Unavailable", (totals.unavailable || 0) + (totals.stopped || 0)],
    ["API limits", totals["api-limited"] || 0],
  ].map(([label, value]) => `<span><b>${value}</b>${label}</span>`).join("");
  $("#health-accounts").innerHTML = health.byAccount?.length
    ? health.byAccount.map((item) => { const unavailable = (item.unavailable || 0) + (item.stopped || 0); const apiLimited = item["api-limited"] || 0; return `<div class="health-account ${item.failed + unavailable + apiLimited ? "needs-review" : ""}"><strong>${escapeHtml(item.accountName)}</strong><small>${item.failed || 0} failed · ${unavailable} unavailable · ${apiLimited} API limits${item.lastError ? ` · ${escapeHtml(item.lastError)}` : ""}</small></div>`; }).join("")
    : `<small class="dim">No delivery history yet.</small>`;
}
function renderInviteOrder() {
  const ids = [...selectedInviteAccountIds];
  const nextId = inviteStartAccountId && ids.includes(inviteStartAccountId) ? inviteStartAccountId : ids[0];
  $("#invite-order-count").textContent = ids.length ? `${ids.length} selected · next ${accountName(nextId)}` : "0 selected";
  $("#invite-send-order").innerHTML = ids.length ? ids.map((id, index) => {
    const account = state.accounts.find((item) => item.id === id);
    if (!account) return "";
    return `<div class="order-row"><span class="order-number">${index + 1}</span><div><strong>${escapeHtml(account.name)}</strong><small>Phone account</small></div><div class="order-buttons"><button type="button" data-invite-order="up" data-id="${escapeHtml(id)}" ${index === 0 ? "disabled" : ""} title="Move earlier">↑</button><button type="button" data-invite-order="down" data-id="${escapeHtml(id)}" ${index === ids.length - 1 ? "disabled" : ""} title="Move later">↓</button></div></div>`;
  }).join("") : empty("Select phone accounts to set the invite order.");
}
function renderTaskOrder() {
  const ids = [...selectedTaskAccountIds];
  $("#task-order-count").textContent = `${ids.length} selected`;
  $("#task-send-order").innerHTML = ids.length ? ids.map((id, index) => {
    const account = state.accounts.find((item) => item.id === id);
    if (!account) return "";
    return `<div class="order-row"><span class="order-number">${index + 1}</span><div><strong>${escapeHtml(account.name)}</strong><small>${escapeHtml(accountPlatform(account))}</small></div><div class="order-buttons"><button type="button" data-task-order="up" data-id="${escapeHtml(id)}" ${index === 0 ? "disabled" : ""} title="Move earlier">↑</button><button type="button" data-task-order="down" data-id="${escapeHtml(id)}" ${index === ids.length - 1 ? "disabled" : ""} title="Move later">↓</button></div></div>`;
  }).join("") : empty("Select accounts to set their task order.");
}
function renderSendOrder() {
  const ids = [...selectedAccountIds];
  $("#order-count").textContent = `${ids.length} selected`;
  $("#send-order").innerHTML = ids.length ? ids.map((id, index) => {
    const account = state.accounts.find((item) => item.id === id);
    if (!account) return "";
    return `<div class="order-row"><span class="order-number">${index + 1}</span><div><strong>${escapeHtml(account.name)}</strong><small>${account.type === "bot" ? "Bot" : "Phone account"}</small></div><div class="order-buttons"><button type="button" data-order="up" data-id="${escapeHtml(id)}" ${index === 0 ? "disabled" : ""} title="Move earlier">↑</button><button type="button" data-order="down" data-id="${escapeHtml(id)}" ${index === ids.length - 1 ? "disabled" : ""} title="Move later">↓</button></div></div>`;
  }).join("") : empty("Select accounts to set their send order.");
}
function accountMini(a) { return `<div class="mini-row"><div class="avatar ${a.type}">${escapeHtml((a.name || "?")[0])}</div><div class="row-main"><strong>${escapeHtml(a.name)}</strong><small>${escapeHtml(accountPlatform(a))} · ${escapeHtml(accountIdentity(a))}</small></div><span class="badge ${a.enabled ? "ok" : ""}">${a.enabled ? "Active" : "Paused"}</span></div>`; }
function scheduleMini(s) { return `<div class="mini-row"><div class="avatar">◷</div><div class="row-main"><strong>${escapeHtml(s.name)}</strong><small>${escapeHtml(scheduleAccountNames(s))} · ${s.destinations.length} target${s.destinations.length === 1 ? "" : "s"}</small></div><span class="badge">${fmtDate(s.nextRunAt)}</span></div>`; }
function logMini(l) { const ok = !["failed", "stopped", "unavailable", "api-limited"].includes(l.status); return `<div class="mini-row"><div class="avatar ${ok ? "" : "user"}">${ok ? "✓" : "!"}</div><div class="row-main"><strong>${escapeHtml(l.accountName)}</strong><small>${escapeHtml(l.detail || l.destination)} · ${fmtDate(l.createdAt)}</small></div><span class="badge ${ok ? "ok" : "fail"}">${l.status}</span></div>`; }
function accountCard(a) { return `<div class="card-row"><div class="avatar ${a.type}">${escapeHtml((a.name || "?")[0])}</div><div class="row-main"><strong>${escapeHtml(a.name)}</strong><small>${escapeHtml(accountPlatform(a))} · ${escapeHtml(accountIdentity(a))} · Added ${fmtDate(a.createdAt)}</small></div><span class="badge ${a.enabled ? "ok" : ""}">${a.enabled ? "Active" : "Paused"}</span><div class="card-actions"><button class="toggle ${a.enabled ? "on" : ""}" data-action="toggle-account" data-id="${a.id}" data-enabled="${!a.enabled}" title="${a.enabled ? "Pause" : "Resume"}"></button><button class="icon-button remove" data-action="remove-account" data-id="${a.id}">Remove</button></div></div>`; }
function scheduleCard(s) { const mediaName = s.mediaName || s.imageName; return `<div class="card-row"><div class="avatar">◷</div><div class="row-main"><strong>${escapeHtml(s.name)}</strong><small>${escapeHtml(scheduleAccountNames(s))} · ${escapeHtml(s.destinations.join(", "))} · Every ${fmtInterval(s.intervalMinutes)}${s.delaySeconds ? ` · ${s.delaySeconds}s account delay${s.randomizeDelay ? ` ±${s.variationPercent || 20}%` : ""}` : ""}${mediaName ? ` · ${escapeHtml(mediaName)}` : ""} · Next ${fmtDate(s.nextRunAt)}</small></div><span class="badge ${s.enabled ? "ok" : ""}">${s.enabled ? "Running" : "Paused"}</span><div class="card-actions"><button class="toggle ${s.enabled ? "on" : ""}" data-action="toggle-schedule" data-id="${s.id}" data-enabled="${!s.enabled}"></button><button class="icon-button remove" data-action="remove-schedule" data-id="${s.id}">Remove</button></div></div>`; }
function logRow(l) { const ok = !["failed", "stopped", "unavailable", "api-limited"].includes(l.status); return `<div class="log-row"><span class="dim">${fmtDate(l.createdAt)}</span><span>${escapeHtml(l.accountName)}</span><span title="${escapeHtml(l.error || l.detail || "")}">${escapeHtml(l.detail || l.destination)}</span><span class="dim">${escapeHtml(l.source)}</span><span class="badge ${ok ? "ok" : "fail"}">${l.status}</span></div>`; }

function openModal(id) { $(`#${id}`).classList.remove("hidden"); }
function closeModal(id) { $(`#${id}`).classList.add("hidden"); }
function destinationValues() { return $("#destinations").value.split(/[\n,]+/).map((value) => value.trim()).filter(Boolean); }
function clearDialogs() {
  const loadedValues = new Set(dialogs.map((dialog) => dialog.value));
  if (loadedValues.size) $("#destinations").value = destinationValues().filter((value) => !loadedValues.has(value)).join("\n");
  dialogs = [];
  groupEmptyMessage = "No groups or channels found.";
  $("#group-search").value = "";
  $("#group-search-wrap").classList.add("hidden");
  $("#group-actions").classList.add("hidden");
  $("#dialog-chips").innerHTML = "";
}
function matchingDialogs() {
  const query = $("#group-search").value.trim().toLowerCase();
  return dialogs.filter((dialog) => !query || [dialog.title, dialog.username, dialog.kind, ...dialog.accountNames].filter(Boolean).join(" ").toLowerCase().includes(query));
}
function renderDialogs() {
  const selected = new Set(destinationValues());
  const filtered = matchingDialogs();
  const selectedCount = dialogs.filter((dialog) => selected.has(dialog.value)).length;
  $("#group-count").textContent = `${filtered.length} of ${dialogs.length} · ${selectedCount} selected`;
  $("#dialog-chips").innerHTML = filtered.length ? filtered.map((dialog) => `<button type="button" class="chip ${selected.has(dialog.value) ? "selected" : ""}" data-dialog="${escapeHtml(dialog.value)}"><span>${escapeHtml(dialog.title)}</span><small>${escapeHtml(dialog.kind)} · ${escapeHtml(dialog.accountNames.join(", "))}</small></button>`).join("") : `<span class="hint">${dialogs.length ? "No groups match your search." : escapeHtml(groupEmptyMessage)}</span>`;
}
function clearInviteDialogs() {
  const loadedValues = new Set(inviteDialogs.map((item) => item.value));
  if (loadedValues.has($("#invite-destination").value.trim())) $("#invite-destination").value = "";
  inviteDialogs = [];
  $("#invite-group-search").value = "";
  $("#invite-group-search-wrap").classList.add("hidden");
  $("#invite-dialog-chips").innerHTML = "";
}
function matchingInviteDialogs() {
  const query = $("#invite-group-search").value.trim().toLowerCase();
  return inviteDialogs.filter((item) => !query || [item.title, item.username, ...item.accountNames].filter(Boolean).join(" ").toLowerCase().includes(query));
}
function renderInviteDialogs() {
  const destination = $("#invite-destination").value.trim();
  const filtered = matchingInviteDialogs();
  $("#invite-group-count").textContent = `${filtered.length} of ${inviteDialogs.length}`;
  $("#invite-dialog-chips").innerHTML = filtered.length ? filtered.map((item) => `<button type="button" class="chip ${destination === item.value ? "selected" : ""}" data-invite-dialog="${escapeHtml(item.value)}"><span>${escapeHtml(item.title)}</span><small>${escapeHtml(item.accountNames.join(", "))}</small></button>`).join("") : `<span class="hint">${inviteDialogs.length ? "No groups match your search." : "No shared groups found."}</span>`;
}
function inviteUsernameValues() {
  const seen = new Set();
  const values = [];
  for (const raw of $("#invite-usernames").value.split(/[\s,;]+/)) {
    const username = raw.trim().replace(/^https?:\/\/(?:www\.)?t\.me\//i, "").replace(/^@/, "").replace(/\/$/, "");
    if (!username || seen.has(username.toLowerCase())) continue;
    seen.add(username.toLowerCase());
    values.push(username);
  }
  return values;
}
function renderInviteResults(result) {
  const node = $("#invite-results");
  node.classList.remove("hidden");
  const stopped = result.stoppedAccounts?.length || 0;
  node.innerHTML = `<div class="invite-result-summary"><strong>${result.invited} invited</strong><span>${result.skipped} already joined</span><span>${result.failed} failed</span>${stopped ? `<span>${stopped} account${stopped === 1 ? "" : "s"} unavailable this batch</span>` : ""}</div><div class="invite-result-list">${result.results.map((item) => `<div class="invite-result-row"><span class="badge ${item.status === "failed" ? "fail" : "ok"}">${escapeHtml(item.status)}</span><strong>${escapeHtml(item.username)}</strong><small>${escapeHtml(item.accountName)}${item.error ? ` · ${escapeHtml(item.error)}` : ""}</small></div>`).join("")}</div>`;
}
function resetInviteLoop() {
  inviteLoopTotal = 0;
  inviteLoopProcessed = 0;
  continuingInviteLoop = false;
  $("#invite-loop-panel").classList.add("hidden");
}
function renderInviteLoop(remainingCount) {
  const panel = $("#invite-loop-panel");
  panel.classList.toggle("hidden", remainingCount === 0);
  if (!remainingCount) return;
  const nextCount = Math.min(25, remainingCount);
  $("#invite-loop-title").textContent = `Next ${nextCount} ready`;
  $("#invite-loop-detail").textContent = `${inviteLoopProcessed} of ${inviteLoopTotal} processed · ${remainingCount} still queued · account cycle will resume where it stopped`;
  $("#continue-invite-button").textContent = `Continue with next ${nextCount} →`;
}
function resetInviteProgress(total) {
  $("#invite-progress").classList.remove("hidden");
  $("#invite-progress-title").textContent = "Preparing invite job";
  $("#invite-progress-count").textContent = `0 / ${total}`;
  $("#invite-progress-bar").style.width = "0%";
  $("#invite-progress-message").textContent = "Checking selected accounts…";
  $("#invite-account-alerts").innerHTML = "";
  inviteAccountStats = [...selectedInviteAccountIds].map((accountId) => ({ accountId, accountName: accountName(accountId), status: "checking", actions: 0, invited: 0, skipped: 0, failed: 0, currentUsername: null, stopReason: null, floodWaitUntil: null, rateLimitCode: null }));
  renderInviteAccountStatus();
}
function renderInviteAccountStatus(accounts = inviteAccountStats) {
  inviteAccountStats = accounts;
  $("#invite-account-status").innerHTML = accounts.length ? accounts.map((item) => {
    const remaining = item.floodWaitUntil ? Math.max(0, Math.ceil((item.floodWaitUntil - Date.now()) / 1000)) : null;
    const unavailable = ["unavailable", "api-limited"].includes(item.status);
    const limit = remaining !== null
      ? (remaining > 0 ? `Telegram API FLOOD_WAIT: ${remaining}s remaining` : "Telegram API FLOOD_WAIT expired")
      : item.rateLimitCode === "PEER_FLOOD"
        ? "Telegram returned PEER_FLOOD for automated invitations; normal account use may still work"
        : unavailable ? (item.stopReason || "Unavailable for this run") : "No Telegram API rate limit reported";
    const current = item.currentUsername ? `Now: ${item.currentUsername}` : item.status === "checking" ? "Checking connection…" : item.status === "active" ? "Sending request…" : unavailable ? "Removed from this run only" : "Waiting in cycle";
    const statusLabel = item.status === "api-limited" ? "API limit" : item.status === "unavailable" ? "This run only" : item.status;
    return `<div class="invite-account-state ${unavailable ? item.status : ""}"><div class="invite-account-state-head"><strong>${escapeHtml(item.accountName)}</strong><span class="badge ${unavailable ? "fail" : "ok"}">${escapeHtml(statusLabel)}</span></div><small>${escapeHtml(current)}</small><div class="invite-account-metrics"><span><b>${item.actions || 0}</b> actions</span><span><b>${item.invited || 0}</b> invited</span><span><b>${item.skipped || 0}</b> skipped</span><span><b>${item.failed || 0}</b> failed</span></div><p>${escapeHtml(limit)}</p></div>`;
  }).join("") : empty("No invite accounts selected.");
}
function renderInviteProgress(update) {
  const node = $("#invite-progress");
  node.classList.remove("hidden");
  const current = Number.isFinite(update.current) ? update.current : Number($("#invite-progress-count").textContent.split("/")[0].trim()) || 0;
  const total = Number.isFinite(update.total) ? update.total : Number($("#invite-progress-count").textContent.split("/")[1]) || 0;
  const titles = { starting: "Preparing invite job", waiting: "Waiting between invitations", inviting: "Sending invitation", running: "Invite cycle running", stopping: "Stopping invite job", stopped: "Invite job ended", completed: "Invite batch complete", "account-unavailable": "Account unavailable for this run", "account-api-limited": "Telegram API response reported" };
  $("#invite-progress-title").textContent = titles[update.status] || "Invite cycle running";
  $("#invite-progress-count").textContent = `${current} / ${total}`;
  $("#invite-progress-bar").style.width = `${total ? Math.min(100, Math.round(current / total * 100)) : 0}%`;
  if (update.message) $("#invite-progress-message").textContent = update.message;
  if (Array.isArray(update.accounts)) renderInviteAccountStatus(update.accounts);
  if (["account-unavailable", "account-api-limited"].includes(update.status)) {
    $("#invite-progress-message").textContent = update.reason || "This account was removed from the current invite run.";
    const alert = document.createElement("div");
    alert.className = "invite-account-alert";
    const label = update.status === "account-api-limited" ? `${update.accountName || "Account"}: ${update.rateLimitCode || "API limit"}` : `${update.accountName || "Account"} unavailable for this run`;
    alert.innerHTML = `<strong>${escapeHtml(label)}</strong><span>${escapeHtml(update.reason || "Removed from the current invite run.")}</span>`;
    $("#invite-account-alerts").append(alert);
    toast(`${label}: ${update.reason || "Review the Telegram response."}`, true);
  }
}

function selectedSocialAccount() {
  return state.accounts.find((account) => account.id === $("#social-account").value && account.enabled);
}
function updateSocialFields() {
  const account = selectedSocialAccount();
  const previousKind = $("#social-kind").value;
  const isReddit = account?.type === "reddit";
  const isInstagram = account?.type === "instagram";
  const choices = isReddit
    ? [["reddit-text", "Reddit text post"], ["reddit-link", "Reddit link post"]]
    : isInstagram
      ? [["instagram-image", "Instagram image"], ["instagram-reel", "Instagram Reel"]]
      : [];
  $("#social-kind").innerHTML = choices.length
    ? choices.map(([value, label]) => `<option value="${value}">${label}</option>`).join("")
    : `<option value="">Choose a connected account</option>`;
  if (choices.some(([value]) => value === previousKind)) $("#social-kind").value = previousKind;
  const kind = $("#social-kind").value;
  const needsUrl = kind === "reddit-link" || isInstagram;
  $("#social-reddit-fields").classList.toggle("hidden", !isReddit);
  $("#social-instagram-fields").classList.toggle("hidden", !isInstagram);
  $("#social-url-wrap").classList.toggle("hidden", !needsUrl);
  $("#social-body-wrap").classList.toggle("hidden", kind !== "reddit-text");
  $("#social-share-wrap").classList.toggle("hidden", kind !== "instagram-reel");
  $("#social-subreddit").required = isReddit;
  $("#social-title").required = isReddit;
  $("#social-url").required = needsUrl;
  $("#social-publish-button").disabled = !account;
  $("#social-url-label").firstChild.textContent = kind === "reddit-link" ? "Reddit link URL" : kind === "instagram-reel" ? "Public Reel video URL" : "Public image URL";
}
function renderSocialProgress(update) {
  const panel = $("#social-progress");
  panel.classList.remove("hidden", "failed", "completed");
  panel.classList.toggle("failed", update.status === "failed");
  panel.classList.toggle("completed", update.status === "completed");
  const titles = { starting: "Preparing post", uploading: "Uploading media", processing: "Processing media", publishing: "Publishing", completed: "Published", failed: "Publishing failed" };
  $("#social-progress-title").textContent = titles[update.status] || "Working";
  $("#social-progress-message").textContent = update.message || "";
}

$("#nav").addEventListener("click", (event) => { const button = event.target.closest("[data-view]"); if (button) go(button.dataset.view); });
document.addEventListener("click", async (event) => {
  const goButton = event.target.closest("[data-go]"); if (goButton) go(goButton.dataset.go);
  const close = event.target.closest("[data-close]"); if (close) closeModal(close.dataset.close);
  const action = event.target.closest("[data-action]"); if (!action) return;
  try {
    if (action.dataset.action === "toggle-account") await api.toggleAccount(action.dataset.id, action.dataset.enabled === "true");
    if (action.dataset.action === "remove-account" && confirm("Remove this account and its schedules from Botline?")) await api.removeAccount(action.dataset.id);
    if (action.dataset.action === "toggle-schedule") await api.toggleSchedule(action.dataset.id, action.dataset.enabled === "true");
    if (action.dataset.action === "remove-schedule" && confirm("Remove this schedule?")) await api.removeSchedule(action.dataset.id);
  } catch (error) { toast(errorMessage(error), true); }
});
$("#connect-button").addEventListener("click", () => openModal("connect-modal"));
$("#emergency-pause-button").addEventListener("click", async (event) => {
  if (!confirm("Pause all active accounts and schedules? Any invite job will stop after the current platform request.")) return;
  setBusy(event.currentTarget, true, "Pausing…");
  try {
    const result = await api.emergencyPause();
    toast(`Paused ${result.accountsPaused} account${result.accountsPaused === 1 ? "" : "s"} and ${result.schedulesPaused} schedule${result.schedulesPaused === 1 ? "" : "s"}.`);
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(event.currentTarget, false, "Pause all"); }
});
$("#change-api").addEventListener("click", () => { forceApiSetup = true; render(); $("#api-id").focus(); });
$$('.tab').forEach((button) => button.addEventListener("click", () => { $$(".tab").forEach((n) => n.classList.toggle("active", n === button)); $$(".tab-panel").forEach((n) => n.classList.toggle("active", n.id === `${button.dataset.tab}-form`)); }));

$("#bot-form").addEventListener("submit", async (event) => { event.preventDefault(); const button = event.submitter; setBusy(button, true, "Verifying…"); try { await api.addBot($("#bot-token").value); $("#bot-form").reset(); closeModal("connect-modal"); toast("Bot connected securely."); } catch (error) { toast(errorMessage(error), true); } finally { setBusy(button, false); } });
$("#reddit-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  setBusy(button, true, "Waiting for Reddit…");
  try {
    await api.connectReddit({ clientId: $("#reddit-client-id").value, clientSecret: $("#reddit-client-secret").value });
    $("#reddit-form").reset();
    closeModal("connect-modal");
    toast("Reddit account connected securely.");
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(button, false); }
});
$("#instagram-browser-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  setBusy(button, true, "Waiting for Meta…");
  try {
    const result = await api.loginInstagram({ appId: $("#instagram-app-id").value, appSecret: $("#instagram-app-secret").value });
    $("#instagram-browser-form").reset();
    closeModal("connect-modal");
    const names = result.connectedInstagramAccounts || [];
    toast(names.length > 1 ? `${names.length} Instagram accounts connected securely.` : `${names[0] || "Instagram account"} connected securely.`);
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(button, false); }
});
$("#instagram-token-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  setBusy(button, true, "Verifying…");
  try {
    await api.connectInstagram({ instagramId: $("#instagram-account-id").value, accessToken: $("#instagram-access-token").value });
    $("#instagram-token-form").reset();
    closeModal("connect-modal");
    toast("Instagram account connected securely.");
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(button, false); }
});
$("#user-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  setBusy(button, true, "Requesting code…");
  try {
    if (!state.telegramSetup || forceApiSetup) {
      state = await api.configureTelegram({ apiId: $("#api-id").value, apiHash: $("#api-hash").value });
      forceApiSetup = false;
      render();
    }
    await api.startUserLogin({ phone: $("#phone").value });
    $("#user-form").reset();
    closeModal("connect-modal");
    closeModal("auth-modal");
    toast("Telegram account connected securely.");
  } catch (error) {
    closeModal("auth-modal");
    toast(errorMessage(error), true);
  } finally { setBusy(button, false); }
});
api.onAuthRequest(({ kind }) => { currentAuthKind = kind; const password = kind === "password"; $("#auth-title").textContent = password ? "Enter 2-step password" : "Enter login code"; $("#auth-copy").textContent = password ? "This account has Telegram 2-step verification enabled." : "Enter the code Telegram sent to your account."; $("#auth-label").firstChild.textContent = password ? "Cloud password" : "Verification code"; $("#auth-value").type = password ? "password" : "text"; $("#auth-value").value = ""; openModal("auth-modal"); setTimeout(() => $("#auth-value").focus(), 50); });
api.onAuthError(({ message }) => toast(`Telegram sign-in: ${message}`, true));
$("#auth-form").addEventListener("submit", async (event) => { event.preventDefault(); try { await api.respondToAuth({ kind: currentAuthKind, value: $("#auth-value").value }); closeModal("auth-modal"); } catch (error) { toast(errorMessage(error), true); } });
$("#cancel-auth").addEventListener("click", async () => { await api.cancelAuth(); closeModal("auth-modal"); });

$("#message-text").addEventListener("input", () => $("#char-count").textContent = $("#message-text").value.length);
function renderMediaSelection() {
  const limit = selectedMedia ? 1024 : 4096;
  $("#media-selection").classList.toggle("hidden", !selectedMedia);
  $("#media-name").textContent = selectedMedia?.name || "";
  $("#media-size").textContent = selectedMedia ? `${(selectedMedia.size / 1024 / 1024).toFixed(1)} MB · ${selectedMedia.kind}` : "";
  $("#media-icon").textContent = selectedMedia?.kind === "photo" ? "IMG" : selectedMedia?.kind === "video" ? "VID" : "FILE";
  $("#message-text").maxLength = limit;
  $("#char-limit").textContent = limit;
  if ($("#message-text").value.length > limit) $("#message-text").value = $("#message-text").value.slice(0, limit);
  $("#char-count").textContent = $("#message-text").value.length;
}
$("#choose-media").addEventListener("click", async () => {
  try { const media = await api.chooseMedia(); if (media) { selectedMedia = media; renderMediaSelection(); } }
  catch (error) { toast(errorMessage(error), true); }
});
$("#remove-media").addEventListener("click", () => { selectedMedia = null; renderMediaSelection(); });
$("#randomize-delay").addEventListener("change", () => $("#variation-wrap").classList.toggle("hidden", !$("#randomize-delay").checked));
$("#frequency").addEventListener("change", () => { const recurring = $("#frequency").value !== "once"; $("#schedule-name-wrap").classList.toggle("hidden", !recurring); $("#schedule-name").required = recurring; $("#send-button").textContent = recurring ? "Review and create schedule →" : "Review and send →"; });
$("#compose-accounts").addEventListener("change", (event) => { const input = event.target.closest("[data-account-id]"); if (!input) return; if (input.checked) selectedAccountIds.add(input.dataset.accountId); else selectedAccountIds.delete(input.dataset.accountId); input.closest(".account-choice").classList.toggle("selected", input.checked); clearDialogs(); renderSendOrder(); });
$("#select-all-accounts").addEventListener("click", () => { selectedAccountIds = new Set(state.accounts.filter((account) => account.enabled && ["bot", "user"].includes(account.type)).map((account) => account.id)); clearDialogs(); render(); });
$("#clear-accounts").addEventListener("click", () => { selectedAccountIds.clear(); clearDialogs(); render(); });
$("#send-order").addEventListener("click", (event) => {
  const button = event.target.closest("[data-order]");
  if (!button) return;
  const ids = [...selectedAccountIds];
  const index = ids.indexOf(button.dataset.id);
  const nextIndex = button.dataset.order === "up" ? index - 1 : index + 1;
  if (index < 0 || nextIndex < 0 || nextIndex >= ids.length) return;
  [ids[index], ids[nextIndex]] = [ids[nextIndex], ids[index]];
  selectedAccountIds = new Set(ids);
  renderSendOrder();
});
$("#task-accounts").addEventListener("change", (event) => {
  const input = event.target.closest("[data-task-account-id]");
  if (!input) return;
  if (input.checked) selectedTaskAccountIds.add(input.dataset.taskAccountId); else selectedTaskAccountIds.delete(input.dataset.taskAccountId);
  input.closest(".account-choice").classList.toggle("selected", input.checked);
  renderTaskOrder();
});
$("#select-all-task-accounts").addEventListener("click", () => { selectedTaskAccountIds = new Set(state.accounts.map((account) => account.id)); render(); });
$("#clear-task-accounts").addEventListener("click", () => { selectedTaskAccountIds.clear(); render(); });
$("#task-send-order").addEventListener("click", (event) => {
  const button = event.target.closest("[data-task-order]");
  if (!button) return;
  const ids = [...selectedTaskAccountIds];
  const index = ids.indexOf(button.dataset.id);
  const nextIndex = button.dataset.taskOrder === "up" ? index - 1 : index + 1;
  if (index < 0 || nextIndex < 0 || nextIndex >= ids.length) return;
  [ids[index], ids[nextIndex]] = [ids[nextIndex], ids[index]];
  selectedTaskAccountIds = new Set(ids);
  renderTaskOrder();
});
$("#invite-accounts").addEventListener("change", (event) => {
  const input = event.target.closest("[data-invite-account-id]");
  if (!input) return;
  if (input.checked) selectedInviteAccountIds.add(input.dataset.inviteAccountId); else selectedInviteAccountIds.delete(input.dataset.inviteAccountId);
  input.closest(".account-choice").classList.toggle("selected", input.checked);
  inviteStartAccountId = null;
  resetInviteLoop();
  clearInviteDialogs();
  renderInviteOrder();
});
$("#select-all-invite-accounts").addEventListener("click", () => {
  selectedInviteAccountIds = new Set(state.accounts.filter((account) => account.enabled && account.type === "user").map((account) => account.id));
  inviteStartAccountId = null;
  resetInviteLoop();
  clearInviteDialogs();
  render();
});
$("#clear-invite-accounts").addEventListener("click", () => { selectedInviteAccountIds.clear(); inviteStartAccountId = null; resetInviteLoop(); clearInviteDialogs(); render(); });
$("#invite-send-order").addEventListener("click", (event) => {
  const button = event.target.closest("[data-invite-order]");
  if (!button) return;
  const ids = [...selectedInviteAccountIds];
  const index = ids.indexOf(button.dataset.id);
  const nextIndex = button.dataset.inviteOrder === "up" ? index - 1 : index + 1;
  if (index < 0 || nextIndex < 0 || nextIndex >= ids.length) return;
  [ids[index], ids[nextIndex]] = [ids[nextIndex], ids[index]];
  selectedInviteAccountIds = new Set(ids);
  inviteStartAccountId = null;
  resetInviteLoop();
  renderInviteOrder();
});
$("#invite-group-search").addEventListener("input", renderInviteDialogs);
$("#invite-destination").addEventListener("input", () => { resetInviteLoop(); if (inviteDialogs.length) renderInviteDialogs(); });
$("#load-invite-dialogs").addEventListener("click", async (event) => {
  const ids = [...selectedInviteAccountIds];
  if (!ids.length) return toast("Select at least one phone account first.", true);
  setBusy(event.currentTarget, true, "Loading…");
  try {
    const raw = await api.listDialogs(ids);
    const merged = new Map();
    for (const item of raw.filter((dialog) => dialog.kind === "group")) {
      const value = item.username ? `@${item.username}` : item.id;
      if (!merged.has(value)) merged.set(value, { ...item, value, accountNames: [] });
      const mergedItem = merged.get(value);
      if (!mergedItem.accountNames.includes(item.accountName)) mergedItem.accountNames.push(item.accountName);
    }
    inviteDialogs = [...merged.values()].sort((a, b) => a.title.localeCompare(b.title));
    $("#invite-group-search-wrap").classList.remove("hidden");
    renderInviteDialogs();
    $("#invite-group-search").focus();
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(event.currentTarget, false); }
});
$("#invite-dialog-chips").addEventListener("click", (event) => {
  const chip = event.target.closest("[data-invite-dialog]");
  if (!chip) return;
  $("#invite-destination").value = chip.dataset.inviteDialog;
  resetInviteLoop();
  renderInviteDialogs();
});
$("#invite-usernames").addEventListener("input", () => {
  resetInviteLoop();
  const count = inviteUsernameValues().length;
  $("#invite-username-count").textContent = `${count} user${count === 1 ? "" : "s"}`;
});
$("#continue-invite-button").addEventListener("click", () => {
  const remaining = inviteUsernameValues().length;
  if (!remaining) return resetInviteLoop();
  continuingInviteLoop = true;
  $("#invite-form").requestSubmit($("#invite-button"));
});
$("#stop-invite-button").addEventListener("click", async (event) => {
  setBusy(event.currentTarget, true, "Stopping…");
  try {
    const result = await api.cancelInvite();
    if (!result.stopped) toast("No invite job is currently running.", true);
  } catch (error) { toast(errorMessage(error), true); }
});
$("#task-randomize-delay").addEventListener("change", () => $("#task-variation-wrap").classList.toggle("hidden", !$("#task-randomize-delay").checked));
$("#group-search").addEventListener("input", renderDialogs);
$("#select-visible-groups").addEventListener("click", () => { const values = new Set(destinationValues()); matchingDialogs().forEach((dialog) => values.add(dialog.value)); $("#destinations").value = [...values].join("\n"); renderDialogs(); });
$("#clear-loaded-groups").addEventListener("click", () => { const loaded = new Set(dialogs.map((dialog) => dialog.value)); $("#destinations").value = destinationValues().filter((value) => !loaded.has(value)).join("\n"); renderDialogs(); });
$("#destinations").addEventListener("input", () => { if (dialogs.length) renderDialogs(); });
$("#load-dialogs").addEventListener("click", async (event) => {
  const selectedAccounts = state.accounts.filter((account) => selectedAccountIds.has(account.id) && account.enabled);
  if (!selectedAccountIds.size) return toast("Select at least one account first.", true);
  setBusy(event.currentTarget, true, "Loading…");
  try {
    const raw = await api.listDialogs(selectedAccounts.map((account) => account.id));
    groupEmptyMessage = selectedAccounts.some((account) => account.type === "bot") ? "No bot-visible groups found yet. Send a message in the group, then refresh." : "No groups or channels found.";
    const merged = new Map();
    for (const dialog of raw) {
      const value = dialog.username ? `@${dialog.username}` : dialog.id;
      if (!merged.has(value)) merged.set(value, { ...dialog, value, accountNames: [] });
      const item = merged.get(value);
      if (!item.accountNames.includes(dialog.accountName)) item.accountNames.push(dialog.accountName);
    }
    dialogs = [...merged.values()].sort((a, b) => a.title.localeCompare(b.title));
    $("#group-search-wrap").classList.remove("hidden");
    $("#group-actions").classList.remove("hidden");
    renderDialogs();
    $("#group-search").focus();
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(event.currentTarget, false); }
});
$("#dialog-chips").addEventListener("click", (event) => { const chip = event.target.closest("[data-dialog]"); if (!chip) return; const values = destinationValues(); const value = chip.dataset.dialog; const index = values.indexOf(value); if (index >= 0) values.splice(index, 1); else values.push(value); $("#destinations").value = values.join("\n"); renderDialogs(); });

$("#social-account").addEventListener("change", updateSocialFields);
$("#social-kind").addEventListener("change", updateSocialFields);
$("#load-subreddits").addEventListener("click", async (event) => {
  const account = selectedSocialAccount();
  if (account?.type !== "reddit") return toast("Choose a Reddit account first.", true);
  setBusy(event.currentTarget, true, "Loading…");
  try {
    const items = await api.listRedditSubreddits(account.id);
    $("#social-subreddit-list").innerHTML = items.map((item) => `<option value="${escapeHtml(item.name)}">${escapeHtml(item.title)}</option>`).join("");
    toast(`Loaded ${items.length} subscribed communit${items.length === 1 ? "y" : "ies"}.`);
    $("#social-subreddit").focus();
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(event.currentTarget, false); }
});
$("#social-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  const account = selectedSocialAccount();
  if (!account) return toast("Choose a connected Reddit or Instagram account.", true);
  const payload = {
    accountId: account.id,
    kind: $("#social-kind").value,
    subreddit: $("#social-subreddit").value,
    title: $("#social-title").value,
    body: $("#social-body").value,
    url: $("#social-url").value,
    caption: $("#social-caption").value,
    shareToFeed: $("#social-share-feed").checked,
  };
  const destination = account.type === "reddit" ? `r/${payload.subreddit.trim().replace(/^r\//i, "")}` : accountIdentity(account);
  if (!confirm(`Review and publish this ${account.type === "reddit" ? "post" : "media"} to ${destination} using ${account.name}?`)) return;
  setBusy(button, true, "Publishing…");
  renderSocialProgress({ status: "starting", message: `Preparing ${accountPlatform(account)} publishing…` });
  try {
    await api.publishSocial(payload);
    toast(`Published successfully with ${account.name}.`);
    if (account.type === "reddit") { $("#social-title").value = ""; $("#social-body").value = ""; }
    else $("#social-caption").value = "";
    $("#social-url").value = "";
  } catch (error) { renderSocialProgress({ status: "failed", message: errorMessage(error) }); toast(errorMessage(error), true); }
  finally { setBusy(button, false); }
});
$("#compose-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  const payload = { accountIds: [...selectedAccountIds], destinations: $("#destinations").value, text: $("#message-text").value, delaySeconds: Number($("#account-delay").value), randomizeDelay: $("#randomize-delay").checked, variationPercent: Number($("#delay-variation").value), mediaPath: selectedMedia?.path || null };
  if (!payload.accountIds.length) return toast("Select at least one account.", true);
  if (!payload.text.trim() && !payload.mediaPath) return toast("Write a message or choose an attachment.", true);
  setBusy(button, true, $("#frequency").value === "once" ? "Sending…" : "Saving…");
  try {
    if ($("#frequency").value === "once") {
      const result = await api.sendMessage(payload);
      toast(`Delivered ${result.delivered} message${result.delivered === 1 ? "" : "s"}${result.failed ? `; ${result.failed} failed` : ""}.`);
    } else {
      await api.addSchedule({ ...payload, name: $("#schedule-name").value, intervalMinutes: Number($("#frequency").value) });
      toast(`Schedule created for ${payload.accountIds.length} account${payload.accountIds.length === 1 ? "" : "s"}.`);
    }
    $("#destinations").value = "";
    $("#message-text").value = "";
    $("#schedule-name").value = "";
    $("#char-count").textContent = "0";
    selectedMedia = null;
    renderMediaSelection();
    clearDialogs();
    go($("#frequency").value === "once" ? "activity" : "schedules");
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(button, false); }
});

$("#invite-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  const usernames = inviteUsernameValues();
  const continuing = continuingInviteLoop;
  continuingInviteLoop = false;
  const payload = {
    accountIds: [...selectedInviteAccountIds],
    destination: $("#invite-destination").value,
    usernames,
    delaySeconds: Number($("#invite-delay").value),
    confirmed: $("#invite-confirmed").checked,
    startAccountId: inviteStartAccountId,
  };
  if (!payload.accountIds.length) return toast("Select at least one phone account.", true);
  if (!payload.destination.trim()) return toast("Choose one destination group.", true);
  if (!usernames.length) return toast("Enter at least one Telegram username.", true);
  if (usernames.length > 360) return toast("The queue can contain up to 360 usernames.", true);
  if (!payload.confirmed) return toast("Review the destination and username list before starting the batch.", true);
  if (!continuing || !inviteLoopTotal) {
    inviteLoopTotal = usernames.length;
    inviteLoopProcessed = 0;
  }
  const batch = usernames.slice(0, 25);
  const remaining = usernames.slice(25);
  payload.usernames = batch;
  const accountNames = payload.accountIds.map(accountName).join(", ");
  if (!confirm(`Review batch: invite the next ${batch.length} of ${usernames.length} queued user${usernames.length === 1 ? "" : "s"} to ${payload.destination.trim()} using ${accountNames}?`)) return;
  setBusy(button, true, "Inviting…");
  $("#invite-loop-panel").classList.add("hidden");
  $("#stop-invite-button").classList.remove("hidden");
  $("#stop-invite-button").disabled = false;
  $("#stop-invite-button").textContent = "Stop job";
  resetInviteProgress(batch.length);
  $("#invite-results").classList.add("hidden");
  try {
    const result = await api.inviteMembers(payload);
    inviteLoopProcessed += result.processed || 0;
    inviteStartAccountId = result.nextAccountId || null;
    renderInviteOrder();
    renderInviteResults(result);
    if (Array.isArray(result.accountStats)) renderInviteAccountStatus(result.accountStats);
    const unprocessed = (result.remainingUsernames || []).map((username) => username.replace(/^@/, ""));
    const queued = [...unprocessed, ...remaining];
    $("#invite-usernames").value = queued.map((username) => `@${username}`).join("\n");
    $("#invite-username-count").textContent = `${queued.length} user${queued.length === 1 ? "" : "s"}`;
    $("#invite-confirmed").checked = queued.length > 0;
    renderInviteLoop(queued.length);
    toast(`${result.cancelled ? "Stopped. " : ""}${result.invited} invited${result.skipped ? `; ${result.skipped} already joined` : ""}${result.failed ? `; ${result.failed} failed` : ""}${queued.length ? `; ${queued.length} still queued` : ""}.`);
  } catch (error) { toast(errorMessage(error), true); }
  finally {
    setBusy(button, false);
    $("#stop-invite-button").classList.add("hidden");
    $("#stop-invite-button").disabled = false;
    $("#stop-invite-button").textContent = "Stop job";
  }
});

$("#task-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  const payload = { accountIds: [...selectedTaskAccountIds], instruction: $("#task-instruction").value, delaySeconds: Number($("#task-delay").value), randomizeDelay: $("#task-randomize-delay").checked, variationPercent: Number($("#task-delay-variation").value) };
  if (!payload.accountIds.length) return toast("Select at least one account for the task.", true);
  if (!payload.instruction.trim()) return toast("Describe what the selected accounts should do.", true);
  setBusy(button, true, "Running…");
  try {
    const result = await api.runTask(payload);
    const complete = result.completed ?? 0;
    const failed = result.failedAccounts ?? result.failed ?? 0;
    toast(`Task complete for ${complete} account${complete === 1 ? "" : "s"}${failed ? `; ${failed} failed` : ""}.`);
    $("#task-instruction").value = "";
  } catch (error) { toast(errorMessage(error), true); }
  finally { setBusy(button, false); }
});

document.addEventListener("keydown", (event) => { if (event.key === "Escape") { closeModal("connect-modal"); if (!$("#auth-modal").classList.contains("hidden")) $("#cancel-auth").click(); } });
api.onStateChanged((next) => { state = next; render(); });
api.onInviteProgress(renderInviteProgress);
api.onSocialProgress(renderSocialProgress);
setInterval(() => { if (inviteAccountStats.some((item) => item.floodWaitUntil)) renderInviteAccountStatus(); }, 1000);
api.getState().then((next) => { state = next; render(); }).catch((error) => toast(errorMessage(error), true));
