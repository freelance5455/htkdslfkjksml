import { Preferences } from '@capacitor/preferences';

const KEY_NAME = 'botline_state_key_v1';
const STATE_NAME = 'botline_state_v4';
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function b64(bytes) {
  let s=''; for (const b of bytes) s += String.fromCharCode(b); return btoa(s);
}
function unb64(s) {
  const raw=atob(s); return Uint8Array.from(raw, c=>c.charCodeAt(0));
}
async function getKey() {
  const existing=(await Preferences.get({ key: KEY_NAME })).value;
  let raw;
  if (existing) raw=unb64(existing);
  else { raw=crypto.getRandomValues(new Uint8Array(32)); await Preferences.set({ key: KEY_NAME, value: b64(raw) }); }
  return crypto.subtle.importKey('raw', raw, { name:'AES-GCM' }, false, ['encrypt','decrypt']);
}
export function blankState(){ return { accounts:[], schedules:[], logs:[], settings:{}, version:4 }; }
export async function readState(){
  const value=(await Preferences.get({ key: STATE_NAME })).value;
  if (!value) return blankState();
  try {
    const packet=JSON.parse(value); const key=await getKey();
    const plain=await crypto.subtle.decrypt({ name:'AES-GCM', iv:unb64(packet.iv) }, key, unb64(packet.data));
    return { ...blankState(), ...JSON.parse(decoder.decode(plain)) };
  } catch { return blankState(); }
}
export async function writeState(state){
  const key=await getKey(); const iv=crypto.getRandomValues(new Uint8Array(12));
  const cipher=await crypto.subtle.encrypt({ name:'AES-GCM', iv }, key, encoder.encode(JSON.stringify(state)));
  await Preferences.set({ key: STATE_NAME, value: JSON.stringify({ iv:b64(iv), data:b64(new Uint8Array(cipher)) }) });
}
