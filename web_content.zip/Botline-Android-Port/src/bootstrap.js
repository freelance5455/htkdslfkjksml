import './polyfills.js';
import './mobile-bridge.js';
import './app.js';
