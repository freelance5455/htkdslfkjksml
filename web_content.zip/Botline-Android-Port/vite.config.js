import { defineConfig } from 'vite';
import { nodePolyfills } from 'vite-plugin-node-polyfills';

export default defineConfig({
  plugins: [nodePolyfills({ include: ['buffer', 'process', 'path', 'util', 'events', 'stream'] })],
  build: { target: 'es2022' }
});
