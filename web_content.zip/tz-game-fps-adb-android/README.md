# TZ Game FPS ADB — projeto Android

Projeto Android nativo em Java que exibe a interface pelo `app/src/main/assets/index.html` e integra a API real do Shizuku.

## Abrir e compilar
1. Extraia o ZIP e abra a pasta `tz-game-fps-adb-android` no Android Studio.
2. Use JDK 17 e sincronize o projeto Gradle; o Android Studio instalará as ferramentas Android necessárias.
3. Conecte um aparelho Android 6.0+ e execute o app, ou gere um APK em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Na primeira abertura, o app tenta abrir o Shizuku; inicie o serviço no Shizuku e volte ao app.
5. Aceite a solicitação de autorização do Shizuku para o TZ Game FPS ADB.

No Android 11+, a ativação inicial do Shizuku pode usar depuração sem fio. A inicialização do serviço e a autorização precisam ser confirmadas pelo usuário. O app não pode ativar Shizuku silenciosamente nem conceder a própria permissão.

## O que está incluído
- `index.html` integrado como interface exibida pelo app.
- Verificação do Binder Shizuku e solicitação/recebimento de permissão real.
- Jogos listados: Free Fire MAX, Free Fire, Blood Strike, CODM e Roblox.
- Botão Criador que abre https://youtube.com/@toxzin_fps?si=qyI5GJ_9JNtnJ5mG.
- Ainda não há comandos de otimização, ajustes de FPS ou alterações nos jogos.

## Dependências
Android Gradle Plugin 8.7.3, Shizuku API/Provider 13.1.5, AndroidX Core 1.15.0; minSdk 23, compileSdk/targetSdk 35.
