package com.toxzinfps.tzgamefpsadb;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE_SHIZUKU = 7301;
    private static final String PREFS = "tz_settings";
    private static final String PREF_FIRST_LAUNCH = "opened_shizuku_once";
    private static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";
    private static final String CREATOR_URL = "https://youtube.com/@toxzin_fps?si=qyI5GJ_9JNtnJ5mG";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private boolean pageReady = false;
    private boolean permissionRequestInFlight = false;
    private String currentState = "off";

    private final Runnable binderReceivedListener = this::onShizukuBinderReady;
    private final Runnable binderDeadListener = () -> runOnUiThread(() -> setState("off"));
    private final Shizuku.OnRequestPermissionResultListener permissionResultListener = (requestCode, grantResult) -> {
        if (requestCode != REQUEST_CODE_SHIZUKU) return;
        permissionRequestInFlight = false;
        runOnUiThread(() -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                setState("connected");
                Toast.makeText(this, "Shizuku autorizado para TZ Game FPS ADB", Toast.LENGTH_LONG).show();
            } else {
                setState("permission");
                Toast.makeText(this, "Permissão não concedida. Você pode solicitar novamente.", Toast.LENGTH_LONG).show();
            }
        });
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff090d12);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AppBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                applyState();
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionResultListener);

        handler.postDelayed(() -> {
            if (hasShizukuPermission()) setState("connected");
            else if (isShizukuRunning()) requestShizukuPermission();
            else {
                setState("off");
                openShizukuOnFirstLaunch();
            }
        }, 500);
    }

    private class AppBridge {
        @JavascriptInterface public void activateShizuku() { runOnUiThread(() -> MainActivity.this.activateShizuku()); }
        @JavascriptInterface public void openCreator() { runOnUiThread(MainActivity.this::openCreator); }
    }

    private void setState(String state) {
        currentState = state;
        applyState();
    }

    private void applyState() {
        if (!pageReady || webView == null) return;
        webView.evaluateJavascript("setShizukuState('" + currentState + "')", null);
    }

    private void openShizukuOnFirstLaunch() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(PREF_FIRST_LAUNCH, false)) return;
        prefs.edit().putBoolean(PREF_FIRST_LAUNCH, true).apply();
        handler.postDelayed(() -> {
            if (isShizukuRunning() || hasShizukuPermission()) return;
            Intent launch = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
            if (launch != null) {
                try {
                    startActivity(launch);
                    Toast.makeText(this, "Inicie o serviço no Shizuku e volte para este app.", Toast.LENGTH_LONG).show();
                } catch (Exception e) { setState("off"); }
            } else {
                Toast.makeText(this, "Instale o Shizuku oficial; abrindo a página de download.", Toast.LENGTH_LONG).show();
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
                catch (Exception ignored) { }
            }
        }, 250);
    }

    private void activateShizuku() {
        if (hasShizukuPermission()) { setState("connected"); return; }
        if (isShizukuRunning()) { requestShizukuPermission(); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
        if (launch != null) {
            try {
                startActivity(launch);
                Toast.makeText(this, "Inicie o serviço no Shizuku e volte para autorizar o app.", Toast.LENGTH_LONG).show();
            } catch (Exception e) { setState("off"); }
        } else {
            Toast.makeText(this, "Shizuku não está instalado. Abrindo o site oficial.", Toast.LENGTH_LONG).show();
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
            catch (Exception ignored) { }
        }
    }

    private boolean isShizukuRunning() {
        try { return Shizuku.pingBinder(); }
        catch (Exception e) { return false; }
    }

    private boolean hasShizukuPermission() {
        try {
            return Shizuku.pingBinder() && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) { return false; }
    }

    private void requestShizukuPermission() {
        if (!isShizukuRunning()) { setState("off"); return; }
        if (hasShizukuPermission()) { setState("connected"); return; }
        if (permissionRequestInFlight) return;
        try {
            permissionRequestInFlight = true;
            setState("pending");
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU);
        } catch (Exception e) {
            permissionRequestInFlight = false;
            setState("permission");
        }
    }

    private void onShizukuBinderReady() {
        runOnUiThread(() -> {
            if (hasShizukuPermission()) setState("connected");
            else requestShizukuPermission();
        });
    }

    private void openCreator() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(CREATOR_URL))); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o YouTube.", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onResume() {
        super.onResume();
        handler.postDelayed(() -> {
            if (hasShizukuPermission()) setState("connected");
            else if (isShizukuRunning() && !permissionRequestInFlight) requestShizukuPermission();
            else setState("off");
        }, 450);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionResultListener);
        if (webView != null) webView.destroy();
    }
}
