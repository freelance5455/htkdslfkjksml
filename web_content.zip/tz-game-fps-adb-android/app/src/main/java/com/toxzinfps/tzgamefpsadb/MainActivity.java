package com.toxzinfps.tzgamefpsadb;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Display;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import androidx.core.view.WindowCompat;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE_SHIZUKU = 7301;
    private static final String PREFS = "tz_settings";
    private static final String PREF_FIRST_LAUNCH = "opened_shizuku_once";
    private static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";
    private static final String CREATOR_URL = "https://youtube.com/@toxzin_fps?si=qyI5GJ_9JNtnJ5mG";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private boolean pageReady = false;
    private boolean permissionRequestInFlight = false;
    private String currentState = "off";

    private final Runnable binderReceivedListener = this::onShizukuBinderReady;
    private final Runnable binderDeadListener = () -> runOnUiThread(() -> setState("off"));
    private final Shizuku.OnRequestPermissionResultListener permissionResultListener = (requestCode, grantResult) -> {
        if (requestCode != REQUEST_CODE_SHIZUKU) return;
        permissionRequestInFlight = false;
        runOnUiThread(() -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                setState("connected");
                Toast.makeText(this, "Shizuku autorizado para TZ Game FPS ADB", Toast.LENGTH_LONG).show();
            } else {
                setState("permission");
                Toast.makeText(this, "Permissão não concedida. Você pode solicitar novamente.", Toast.LENGTH_LONG).show();
            }
        });
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff090d12);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AppBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                applyState();
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        Shizuku.addRequestPermissionResultListener(permissionResultListener);

        handler.postDelayed(() -> {
            if (hasShizukuPermission()) setState("connected");
            else if (isShizukuRunning()) requestShizukuPermission();
            else {
                setState("off");
                openShizukuOnFirstLaunch();
            }
        }, 500);
    }

    private class AppBridge {
        @JavascriptInterface public void activateShizuku() { runOnUiThread(() -> MainActivity.this.activateShizuku()); }
        @JavascriptInterface public void openCreator() { runOnUiThread(MainActivity.this::openCreator); }
        @JavascriptInterface public void applyGameMode(String game, String mode) {
            runOnUiThread(() -> MainActivity.this.applyGameMode(game, mode));
        }
    }

    private void setState(String state) {
        currentState = state;
        runOnUiThread(this::applyState);
    }

    private void applyState() {
        if (!pageReady || webView == null) return;
        webView.evaluateJavascript("setShizukuState('" + currentState + "')", null);
    }

    private void openShizukuOnFirstLaunch() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(PREF_FIRST_LAUNCH, false)) return;
        prefs.edit().putBoolean(PREF_FIRST_LAUNCH, true).apply();
        handler.postDelayed(() -> {
            if (isShizukuRunning() || hasShizukuPermission()) return;
            Intent launch = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
            if (launch != null) {
                try {
                    startActivity(launch);
                    Toast.makeText(this, "Inicie o serviço no Shizuku e volte para este app.", Toast.LENGTH_LONG).show();
                } catch (Exception e) { setState("off"); }
            } else {
                Toast.makeText(this, "Instale o Shizuku oficial; abrindo a página de download.", Toast.LENGTH_LONG).show();
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
                catch (Exception ignored) { }
            }
        }, 250);
    }

    private void activateShizuku() {
        if (hasShizukuPermission()) { setState("connected"); return; }
        if (isShizukuRunning()) { requestShizukuPermission(); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
        if (launch != null) {
            try {
                startActivity(launch);
                Toast.makeText(this, "Inicie o serviço no Shizuku e volte para autorizar o app.", Toast.LENGTH_LONG).show();
            } catch (Exception e) { setState("off"); }
        } else {
            Toast.makeText(this, "Shizuku não está instalado. Abrindo o site oficial.", Toast.LENGTH_LONG).show();
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
            catch (Exception ignored) { }
        }
    }

    private boolean isShizukuRunning() {
        try { return Shizuku.pingBinder(); }
        catch (Exception e) { return false; }
    }

    private boolean hasShizukuPermission() {
        try {
            return Shizuku.pingBinder() && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) { return false; }
    }

    private void requestShizukuPermission() {
        if (!isShizukuRunning()) { setState("off"); return; }
        if (hasShizukuPermission()) { setState("connected"); return; }
        if (permissionRequestInFlight) return;
        try {
            permissionRequestInFlight = true;
            setState("pending");
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU);
        } catch (Exception e) {
            permissionRequestInFlight = false;
            setState("permission");
        }
    }

    private void onShizukuBinderReady() {
        runOnUiThread(() -> {
            if (hasShizukuPermission()) setState("connected");
            else requestShizukuPermission();
        });
    }


    private void applyGameMode(String game, String mode) {
        if (!"performance".equals(mode) && !"standard".equals(mode)) {
            setOptimizationResult("bad", "Modo inválido.");
            return;
        }
        if (!hasShizukuPermission()) {
            setOptimizationResult("bad", "Ative o Shizuku e conceda a permissão antes de aplicar o modo.");
            if (isShizukuRunning()) requestShizukuPermission();
            else activateShizuku();
            return;
        }
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.R) {
            applyAndroid11RefreshRate(mode);
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            setOptimizationResult("bad", "Esta otimização requer Android 11 ou superior.");
            return;
        }
        String packageName = findInstalledGamePackage(game);
        if (packageName == null) {
            setOptimizationResult("bad", "Não encontrei " + game + " instalado. Confira a região/versão do jogo.");
            return;
        }
        setOptimizationResult("wait", "Enviando o modo " + ("performance".equals(mode) ? "Performance" : "Padrão") + " para o Android…");
        new Thread(() -> {
            String output = "";
            int exitCode = -1;
            try {
                String[] command = {"sh", "-c", "cmd game mode " + mode + " " + packageName};
                Process process = Shizuku.newProcess(command, null, null);
                StringBuilder text = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) text.append(line).append('\n');
                }
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) text.append(line).append('\n');
                }
                exitCode = process.waitFor();
                output = text.toString().trim();
                String lower = output.toLowerCase(java.util.Locale.ROOT);
                boolean reportedFailure = lower.contains("error") || lower.contains("failed")
                        || lower.contains("unknown") || lower.contains("not supported")
                        || lower.contains("not available");
                final boolean success = exitCode == 0 && !reportedFailure;
                final String message;
                if (success) {
                    message = "O Android aceitou o modo " + ("performance".equals(mode) ? "Performance" : "Padrão")
                            + " para " + game + ". O efeito depende do suporte do aparelho e do jogo; feche e reabra o jogo para testar.";
                } else {
                    message = "O aparelho/jogo não aceitou esse Game Mode. "
                            + (output.isEmpty() ? "Tente outro jogo ou confira a versão do Android." : output);
                }
                runOnUiThread(() -> setOptimizationResult(success ? "ok" : "bad", message));
            } catch (Exception e) {
                final String details = output;
                runOnUiThread(() -> setOptimizationResult("bad", "Falha ao executar pelo Shizuku. "
                        + (details.isEmpty() ? "Confira se o serviço continua ativo e se a permissão foi concedida." : details)));
            }
        }, "tz-game-mode").start();
    }

    private void applyAndroid11RefreshRate(String mode) {
        float maxRate = 0f;
        try {
            Display display = getWindowManager().getDefaultDisplay();
            for (Display.Mode supportedMode : display.getSupportedModes()) {
                maxRate = Math.max(maxRate, supportedMode.getRefreshRate());
            }
        } catch (Exception ignored) { }
        if (maxRate <= 60.5f) {
            setOptimizationResult("bad", "Android 11: a tela informa no máximo 60 Hz. Não há uma taxa maior para ativar.");
            return;
        }
        final String rate = String.format(java.util.Locale.US, "%.1f", maxRate);
        final boolean performance = "performance".equals(mode);
        setOptimizationResult("wait", performance
                ? "Android 11: preparando a tela para até " + rate + " Hz…"
                : "Android 11: restaurando as configurações originais da tela…");
        new Thread(() -> {
            try {
                SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                String command;
                String oldPeak = prefs.getString("a11_old_peak", null);
                String oldMin = prefs.getString("a11_old_min", null);
                boolean saved = prefs.getBoolean("a11_rate_backup_saved", false);
                if (performance) {
                    if (!saved) {
                        ShellResult before = runShizukuShell("settings get system peak_refresh_rate; settings get system min_refresh_rate");
                        if (before.exitCode != 0) throw new IllegalStateException("Não foi possível ler as configurações originais da tela.");
                        String[] values = before.output.split("\\R");
                        if (values.length < 2 || !safeSettingValue(values[0].trim()) || !safeSettingValue(values[1].trim())) {
                            throw new IllegalStateException("O Android não retornou os valores originais da taxa de atualização.");
                        }
                        oldPeak = values[0].trim();
                        oldMin = values[1].trim();
                        prefs.edit().putString("a11_old_peak", oldPeak).putString("a11_old_min", oldMin)
                                .putBoolean("a11_rate_backup_saved", true).apply();
                    }
                    command = "settings put system peak_refresh_rate " + rate
                            + " && settings put system min_refresh_rate " + rate;
                } else {
                    if (!saved || oldPeak == null || oldMin == null) {
                        runOnUiThread(() -> setOptimizationResult("bad", "Ainda não há valores guardados. Aplique Performance primeiro para criar um backup restaurável."));
                        return;
                    }
                    String peakCommand = "null".equals(oldPeak) ? "settings delete system peak_refresh_rate"
                            : "settings put system peak_refresh_rate " + oldPeak;
                    String minCommand = "null".equals(oldMin) ? "settings delete system min_refresh_rate"
                            : "settings put system min_refresh_rate " + oldMin;
                    command = peakCommand + " && " + minCommand;
                }
                ShellResult result = runShizukuShell(command);
                String lower = result.output.toLowerCase(java.util.Locale.ROOT);
                boolean ok = result.exitCode == 0 && !lower.contains("error") && !lower.contains("denied")
                        && !lower.contains("failed") && !lower.contains("unknown");
                final String message;
                if (ok && performance) {
                    message = "Android 11: solicitei até " + rate + " Hz para a tela. É uma configuração global, pode aumentar o consumo de bateria e o fabricante pode ignorá-la. Use Padrão para restaurar os valores guardados.";
                } else if (ok) {
                    message = "Android 11: valores originais da taxa de atualização restaurados.";
                    prefs.edit().remove("a11_old_peak").remove("a11_old_min").putBoolean("a11_rate_backup_saved", false).apply();
                } else {
                    message = "O aparelho não aceitou a mudança de taxa de atualização. "
                            + (result.output.isEmpty() ? "A configuração pode não ser suportada pelo fabricante." : result.output);
                }
                runOnUiThread(() -> setOptimizationResult(ok ? "ok" : "bad", message));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Falha ao ajustar a tela pelo Shizuku." : e.getMessage();
                runOnUiThread(() -> setOptimizationResult("bad", message));
            }
        }, "tz-android11-refresh-rate").start();
    }

    private boolean safeSettingValue(String value) {
        return "null".equals(value) || value.matches("[0-9]+(?:\\.[0-9]+)?");
    }

    private ShellResult runShizukuShell(String command) throws Exception {
        Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
        }
        return new ShellResult(process.waitFor(), text.toString().trim());
    }

    private static class ShellResult {
        final int exitCode;
        final String output;
        ShellResult(int exitCode, String output) { this.exitCode = exitCode; this.output = output; }
    }

    private String findInstalledGamePackage(String game) {
        String[] candidates;
        switch (game) {
            case "Free Fire MAX": candidates = new String[]{"com.dts.freefiremax"}; break;
            case "Free Fire": candidates = new String[]{"com.dts.freefireth"}; break;
            case "Blood Strike": candidates = new String[]{"com.netease.newspike", "com.netease.newspikeme"}; break;
            case "CODM": candidates = new String[]{"com.activision.callofduty.shooter", "com.garena.game.codm"}; break;
            case "Roblox": candidates = new String[]{"com.roblox.client", "com.roblox.client.vnggames"}; break;
            default: return null;
        }
        for (String candidate : candidates) {
            try {
                getPackageManager().getApplicationInfo(candidate, 0);
                return candidate;
            } catch (PackageManager.NameNotFoundException ignored) { }
        }
        return null;
    }

    private void setOptimizationResult(String kind, String message) {
        if (webView == null) return;
        runOnUiThread(() -> webView.evaluateJavascript(
                "setOptimizationResult(" + JSONObject.quote(kind) + "," + JSONObject.quote(message) + ")", null));
    }

    private void openCreator() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(CREATOR_URL))); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o YouTube.", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onResume() {
        super.onResume();
        handler.postDelayed(() -> {
            if (hasShizukuPermission()) setState("connected");
            else if (isShizukuRunning() && !permissionRequestInFlight) requestShizukuPermission();
            else setState("off");
        }, 450);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        Shizuku.removeRequestPermissionResultListener(permissionResultListener);
        if (webView != null) webView.destroy();
    }
}
