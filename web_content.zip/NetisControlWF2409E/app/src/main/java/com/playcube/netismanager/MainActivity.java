package com.playcube.netismanager;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final String DEFAULT_ROUTER = "http://192.168.1.1";
    private WebView web;
    private LinearLayout root;
    private String activeRouter = DEFAULT_ROUTER;
    private int bg = Color.rgb(8, 12, 19);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,12,19));
        getWindow().setNavigationBarColor(Color.rgb(8,12,19));
        buildShell(); showHome();
    }
    private void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg); setContentView(root);
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24,38,53)));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private WebSettings settings(WebView v) {
        WebSettings s=v.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); s.setSupportMultipleWindows(false);
        return s;
    }
    private void showHome() {
        root.removeAllViews(); web=new WebView(this); settings(web);
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void openRouter(String address, String section) {
                runOnUiThread(() -> MainActivity.this.openRouter(address));
            }
        },"AndroidBridge");
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        root.addView(web,new LinearLayout.LayoutParams(-1,-1));
        web.loadUrl("file:///android_asset/index.html");
    }
    private boolean isAllowedRouterUrl(String url) {
        try {
            Uri u=Uri.parse(url); String scheme=u.getScheme(); String host=u.getHost();
            if (scheme==null || host==null || !(scheme.equals("http")||scheme.equals("https"))) return false;
            String[] p=host.split("\\.");
            if(p.length!=4) return false;
            int a=Integer.parseInt(p[0]), b=Integer.parseInt(p[1]);
            for(String x:p){int n=Integer.parseInt(x);if(n<0||n>255)return false;}
            return a==192 && b==168;
        } catch(Exception e){return false;}
    }
    private void openRouter(String address) {
        if(address==null || !isAllowedRouterUrl(address)) {
            Toast.makeText(this,"استخدم عنوان الراوتر المحلي مثل 192.168.1.1",Toast.LENGTH_LONG).show(); return;
        }
        activeRouter=address;
        root.removeAllViews();
        LinearLayout bar=new LinearLayout(this); bar.setOrientation(LinearLayout.HORIZONTAL); bar.setBackgroundColor(Color.rgb(14,22,32));
        bar.addView(button("رجوع",()->{if(web!=null&&web.canGoBack())web.goBack();else showHome();}),new LinearLayout.LayoutParams(0,-2,1));
        bar.addView(button("تحديث",()->{if(web!=null)web.reload();}),new LinearLayout.LayoutParams(0,-2,1));
        bar.addView(button("الرئيسية",this::showHome),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(bar,new LinearLayout.LayoutParams(-1,-2));
        web=new WebView(this); settings(web);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url) {
                if(isAllowedRouterUrl(url)) return false;
                Toast.makeText(MainActivity.this,"تم منع فتح أي رابط خارجي",Toast.LENGTH_SHORT).show(); return true;
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest req, android.webkit.WebResourceError err) {
                if(req.isForMainFrame()) Toast.makeText(MainActivity.this,"تعذر الاتصال. تأكد أنك متصل بشبكة الراوتر وأن العنوان صحيح.",Toast.LENGTH_LONG).show();
            }
        });
        web.setWebChromeClient(new WebChromeClient()); root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        web.loadUrl(activeRouter);
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else showHome();}
    @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
}
