package com.karen.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

class KarenService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var brain: KarenBrain
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.forLanguageTag("tr-TR")
                tts.setPitch(1.15f)
                tts.setSpeechRate(1.0f)
                ttsReady = true
                speak("Merhaba Peter, Karen çevrimiçi.")
            }
        }
        brain = KarenBrain(this) { speak(it) }
        showBubble()
    }

    private fun startAsForeground() {
        val chId = "karen"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(chId, "Karen", NotificationManager.IMPORTANCE_LOW))
        val notif = NotificationCompat.Builder(this, chId)
            .setContentTitle("Karen dinlemede")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "K"; textSize = 22f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(Color.parseColor("#D32F2F"))
            }
            setOnClickListener { listen() }
        }
        val lp = WindowManager.LayoutParams(
            160, 160,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 16 }
        wm.addView(bubble, lp)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Bu cihazda ses tanıma yok."); return
        }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                bubble.alpha = 1f
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text != null) brain.handle(text) else speak("Seni duyamadım Peter.")
            }
            override fun onError(error: Int) { bubble.alpha = 1f; speak("Seni duyamadım Peter.") }
            override fun onReadyForSpeech(p: Bundle?) { bubble.alpha = 0.5f }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        )
    }

    private fun speak(text: String) {
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "KarenSpeechID")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        if (::bubble.isInitialized) wm.removeView(bubble)
        super.onDestroy()
    }
}
