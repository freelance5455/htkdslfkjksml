DJ B1 Forex Robot — first demo prototype

HOW TO OPEN ON ANDROID
1. Download and extract DJ_B1_Demo.zip.
2. Open the extracted folder and tap index.html.
3. If prompted, choose Chrome or another browser.

This is a browser-based educational simulator using generated sample prices.
It does NOT connect to MT5 or a broker, does NOT access live prices, and
cannot place demo or real trades. It is not an APK yet.

An installable APK requires a separate Android packaging/build step.
