CUENTA BILLETES CUBA — PROYECTO ANDROID

Este paquete contiene el proyecto Android Studio para convertir la aplicación HTML en una app Android (APK).
La aplicación web está dentro de app/src/main/assets/index.html y se abre localmente en un WebView.
No requiere conexión a Internet para mostrar la aplicación. El historial usa el almacenamiento del navegador WebView.

CÓMO GENERAR EL APK
1. En un ordenador, instala Android Studio desde la web oficial de Android Developers.
2. Descomprime CuentaBilletesCuba_AndroidStudio.zip.
3. En Android Studio, elige Open y selecciona la carpeta CuentaBilletesAndroid (la carpeta donde está settings.gradle).
4. Espera a que termine la sincronización de Gradle. Acepta instalar el Android SDK 35 si lo solicita.
5. En el menú, selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Cuando termine, pulsa Locate. El APK de prueba suele quedar en:
   app/build/outputs/apk/debug/app-debug.apk
7. Pasa ese APK al teléfono Android y ábrelo para instalarlo. Puede ser necesario autorizar temporalmente la instalación desde esa fuente.

PARA CREAR UN APK FIRMADO
En Android Studio: Build > Generate Signed Bundle / APK > APK y sigue el asistente para crear una clave de firma.

NOTAS
- Este entorno no incluye Android SDK ni Gradle, así que aquí se entrega el proyecto preparado; el APK binario debe compilarse en Android Studio.
- Mantén una copia de seguridad del APK y de la clave si generas una versión firmada.
