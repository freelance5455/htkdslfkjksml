PLAYCOINS — NUEVA VERSIÓN DE DEMOSTRACIÓN

QUÉ INCLUYE
- Interfaz adaptable a móvil.
- Instalación como aplicación web progresiva (PWA), si se publica en una web HTTPS.
- Saldo de demostración guardado en el navegador.
- Retos de prueba y simulación de recompensa.
- Funciona sin cuenta para probar la interfaz.

IMPORTANTE
Esta entrega NO es un APK Android nativo.
No contiene anuncios reales de AdMob, pagos, retiradas de dinero, servidor, autenticación ni sistema antifraude.
Las monedas son ficticias y no tienen valor monetario.
El botón “Ver anuncio de prueba” solo simula la acción; no muestra anuncios ni genera ingresos.

CÓMO PROBAR
1. Descomprime el ZIP.
2. Abre index.html en un navegador para probar la interfaz básica.
3. Para instalarla como PWA, los archivos deben estar publicados en un alojamiento HTTPS que permita service workers. Después abre la web en Chrome para Android y utiliza “Instalar aplicación” o “Añadir a pantalla de inicio” si aparece.

PARA CONVERTIRLA EN UNA APP CON INGRESOS
Hace falta una fase de desarrollo adicional: empaquetado Android, integración nativa de anuncios bonificados de AdMob, backend seguro para validar recompensas y condiciones reales de canje/pago. No se deben pagar recompensas por clics simulados ni prometer ingresos a usuarios.
