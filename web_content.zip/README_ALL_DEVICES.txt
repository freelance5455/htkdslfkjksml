AUDIT QUEST CAF-8 — ALL-DEVICES PACKAGE

Compatible target devices: Android phones, iPhone, Windows PC/laptop, and Mac.

QUICKEST OPTION
Open index.html in a modern browser. The standalone HTML game can also be downloaded separately from ChatGPT.

ANDROID
1. Extract this ZIP using Files or another archive app.
2. Open index.html in Chrome.
3. For installable home-screen/PWA features, publish the package to a secure HTTPS website first.

iPHONE / iPAD
1. Extract the ZIP in the Files app (or on a computer first).
2. Open the page in Safari. If local-file restrictions prevent full functionality, use the hosted HTTPS version.
3. To add it to the Home Screen, open the hosted HTTPS page in Safari, tap Share, then Add to Home Screen.

PC / MAC
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, Firefox, or Safari.

IMPORTANT
A ZIP or HTML file is not a native app installer (.apk/.ipa/.exe). The PWA install and offline service-worker features require HTTPS hosting. This package does not itself publish the game to the internet.

Content: 1,800 MCQs and 600 case/practice tasks across 16 chapters. Chapters 1–8 contain 113 MCQs and 38 cases each; chapters 9–16 contain 112 MCQs and 37 cases each.
