/* AUTOSCAN v2 · sw.js — Service Worker: caché offline completa (PWA)
   En APK/WebView (file://) no se registra; la app ya es 100% local.
   En navegador (https o localhost) permite instalarla como app offline. */
var CACHE = 'autoscan-v2.0.0';
var ASSETS = [
  'index.html',
  'manifest.webmanifest',
  'css/styles.css',
  'js/i18n.js', 'js/db.js', 'js/security.js', 'js/ui.js', 'js/search.js',
  'js/manual.js', 'js/qr.js', 'js/pdf.js', 'js/app.js', 'js/clients.js',
  'js/reception.js', 'js/order.js', 'js/management.js',
  'libs/dexie.min.js', 'libs/jspdf.min.js', 'libs/jszip.min.js', 'libs/qrcode.min.js',
  'assets/img/logo.png', 'assets/img/logo-bg.png',
  'assets/img/icon.png', 'assets/img/icon-96.png', 'assets/img/icon-192.png',
  'assets/fonts/JetBrainsMono-Regular.woff2', 'assets/fonts/JetBrainsMono-Bold.woff2',
  'assets/fonts/Rajdhani-Regular.woff2', 'assets/fonts/Rajdhani-Medium.woff2',
  'assets/fonts/Rajdhani-SemiBold.woff2', 'assets/fonts/Rajdhani-Bold.woff2',
  'assets/sounds/click.wav', 'assets/sounds/scan.wav',
  'assets/sounds/success.wav', 'assets/sounds/error.wav'
];

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE)
      .then(function (c) { return c.addAll(ASSETS); })
      .then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys()
      .then(function (keys) {
        return Promise.all(keys.filter(function (k) { return k !== CACHE; })
          .map(function (k) { return caches.delete(k); }));
      })
      .then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  /* red primero (aplica actualizaciones), caché como respaldo offline */
  e.respondWith(
    fetch(e.request).then(function (resp) {
      try {
        if (resp && resp.ok && e.request.url.indexOf(self.location.origin) === 0) {
          var cp = resp.clone();
          caches.open(CACHE).then(function (c) { c.put(e.request, cp); });
        }
      } catch (err) {}
      return resp;
    }).catch(function () {
      return caches.match(e.request).then(function (hit) {
        return hit || caches.match('index.html');
      });
    })
  );
});
