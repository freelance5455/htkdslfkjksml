/* AUTOSCAN · reception.js — asistente de recepción en 8 pasos */
var A = window.A || {};

A.recPrefill = null;

A.recReset = function () {
  A.rec = {
    paso: 1, cliente: null, vehiculo: null, motivo: '',
    items: [], presupuesto: [], firma: null
  };
};

A.regVista('recepcion', function () {
  if (!A.rec || A.recFinalizada) { A.recReset(); A.recFinalizada = false; }
  if (A.recPrefill) {
    var pf = A.recPrefill; A.recPrefill = null;
    if (pf.clienteId) {
      A.db.clientes.get(pf.clienteId).then(function (c) {
        if (c) A.rec.cliente = c;
        if (pf.vehiculoId) {
          A.db.vehiculos.get(pf.vehiculoId).then(function (v) {
            if (v) A.rec.vehiculo = v;
            A.recPaso(1, true);
          });
        } else A.recPaso(1, true);
      });
      return;
    }
  }
  A.recPaso(A.rec.paso || 1, true);
});

/* ---------- estructura del stepper ---------- */
A.recStepper = function () {
  var labels = [A.t('rec.s1'), A.t('rec.s2'), A.t('rec.s3'), A.t('rec.s4'), A.t('rec.s5'), A.t('rec.s6'), A.t('rec.s7'), '✓'];
  document.getElementById('rec-steps').innerHTML = labels.map(function (l, i) {
    var n = i + 1;
    var cls = n < A.rec.paso ? 'done' : n === A.rec.paso ? 'cur' : '';
    return '<div class="st-n ' + cls + '"><i></i><span>' + l + '</span></div>';
  }).join('');
};

A.recPaso = function (n, forzar) {
  if (!A.rec) A.recReset();
  if (!forzar && n === A.rec.paso + 1) A.sonido('click');
  A.rec.paso = n;
  document.getElementById('rec-stepnum').textContent = n + '/8';
  A.$$('.rec-p').forEach(function (p) { p.hidden = true; });
  var el = document.getElementById('rec-p' + n);
  if (el) el.hidden = false;
  A.recStepper();
  document.getElementById('rec-back').style.visibility = n === 1 ? 'hidden' : 'visible';
  var next = document.getElementById('rec-next');
  next.hidden = (n === 7 || n === 8);
  document.getElementById('rec-cancel').hidden = false;
  /* por paso */
  if (n === 1) A.recP1();
  if (n === 2) A.recP2();
  if (n === 3) A.recP3();
  if (n === 4) A.recP4();
  if (n === 5) A.recP5();
  if (n === 6) setTimeout(A.recP6Fit, 60);
  if (n === 7) A.recP7();
};

/* ---------- P1 Cliente ---------- */
A.recP1 = function () {
  var q = document.getElementById('r1-q');
  var form = document.getElementById('r1-form');
  form.hidden = true;
  document.getElementById('r1-new').hidden = false;
  q.oninput = function () { A.recP1Lista(q.value); };
  document.getElementById('r1-new').onclick = function () {
    form.hidden = !form.hidden;
    document.getElementById('r1-new').hidden = true;
    A.rec.cliente = null;
    A.recP1Lista(q.value);
  };
  document.getElementById('r1-foto').onclick = function () {
    A.pedirFoto({
      maxW: 400, q: 0.8, sinMarca: true,
      onFoto: function (d) { document.getElementById('r1-foto').innerHTML = '<img src="' + d + '">'; A.rec._fotoNueva = d; }
    });
  };
  A.recP1Lista(q.value);
};

A.recP1Lista = function (texto) {
  A.db.clientes.toArray().then(function (lista) {
    var t = (texto || '').toLowerCase().trim();
    var res = lista.filter(function (c) {
      if (!t) return true;
      return (c.nombre || '').toLowerCase().indexOf(t) >= 0 || (c.telefono || '').toLowerCase().indexOf(t) >= 0;
    });
    var sel = A.rec.cliente;
    var box = document.getElementById('r1-list');
    if (!res.length && !document.getElementById('r1-form').hidden === false) {
      box.innerHTML = A.emptyState('users', A.t('cli.sinClientes'));
    }
    box.innerHTML = res.map(function (c) {
      var on = sel && sel.id === c.id;
      return '<div class="card" data-pickc="' + c.id + '" style="' + (on ? 'border-color:var(--accent);box-shadow:var(--glow)' : '') + '">' +
        (c.foto ? '<img class="thumb" src="' + c.foto + '">' : '<span class="thumb ph">' + A.icon('user', 'sm') + '</span>') +
        '<div class="c-main"><div class="c-t">' + A.esc(c.nombre) + '</div><div class="c-s">' + A.esc(c.telefono || c.email || '') + '</div></div>' +
        (on ? '<span class="chip ok">' + A.t('rec.existe') + '</span>' : A.icon('right')) +
        '</div>';
    }).join('');
  });
};

document.getElementById('v-recepcion').addEventListener('click', function (e) {
  var p = e.target.closest('[data-pickc]');
  if (p) {
    A.db.clientes.get(parseInt(p.getAttribute('data-pickc'), 10)).then(function (c) {
      A.rec.cliente = c;
      A.rec.vehiculo = null;
      A.sonido('click');
      A.recP1Lista(document.getElementById('r1-q').value);
    });
    return;
  }
  var v = e.target.closest('[data-pickv]');
  if (v) {
    A.db.vehiculos.get(parseInt(v.getAttribute('data-pickv'), 10)).then(function (veh) {
      A.rec.vehiculo = veh;
      A.sonido('click');
      A.recP2Lista('');
    });
    return;
  }
});

/* ---------- P2 Vehículo ---------- */
A.recP2 = function () {
  var form = document.getElementById('r2-form');
  form.hidden = true;
  document.getElementById('r2-new').hidden = false;
  document.getElementById('r2-new').onclick = function () {
    form.hidden = !form.hidden;
    document.getElementById('r2-new').hidden = true;
    A.rec.vehiculo = null;
    A.recP2Lista('');
  };
  document.getElementById('r2-ocr').onclick = function () { A.avanzadaModal('ocr'); };
  A.recP2Lista('');
};

A.recP2Lista = function () {
  if (!A.rec.cliente) return;
  A.db.vehiculos.where('clienteId').equals(A.rec.cliente.id).toArray().then(function (vehs) {
    var sel = A.rec.vehiculo;
    var box = document.getElementById('r2-list');
    box.innerHTML = vehs.map(function (v) {
      var on = sel && sel.id === v.id;
      return '<div class="card" data-pickv="' + v.id + '" style="' + (on ? 'border-color:var(--accent);box-shadow:var(--glow)' : '') + '">' +
        '<span class="thumb ph">' + A.icon('car') + '</span>' +
        '<div class="c-main"><div class="c-t mono" style="color:var(--accent)">' + A.esc(v.placa || '') + '</div>' +
        '<div class="c-s">' + A.esc((v.marca || '') + ' ' + (v.modelo || '') + ' ' + (v.anio || '')) + '</div></div>' +
        (on ? '<span class="chip ok">' + A.t('rec.existe') + '</span>' : A.icon('right')) +
        '</div>';
    }).join('') || (document.getElementById('r2-form').hidden ? A.emptyState('car', A.t('cli.sinVeh')) : '');
  });
};

/* guardar cliente nuevo del paso 1 */
A.recP1Guardar = function () {
  var nombre = document.getElementById('r1-nombre').value.trim();
  if (!nombre) {
    document.getElementById('r1-nombre').classList.add('bad');
    A.toast(A.t('rec.faltaNombre'), 'err');
    return Promise.reject('val');
  }
  var datos = {
    nombre: nombre,
    telefono: document.getElementById('r1-tel').value.trim(),
    email: document.getElementById('r1-mail').value.trim(),
    notas: document.getElementById('r1-notas').value.trim(),
    foto: A.rec._fotoNueva || null,
    creado: Date.now()
  };
  return A.db.clientes.add(datos).then(function (id) {
    datos.id = id;
    A.rec.cliente = datos;
    A.rec._fotoNueva = null;
    document.getElementById('r1-foto').innerHTML = A.icon('camera');
    return id;
  });
};

/* guardar vehículo nuevo del paso 2 */
A.recP2Guardar = function () {
  var marca = document.getElementById('r2-marca').value.trim();
  var modelo = document.getElementById('r2-modelo').value.trim();
  var placa = document.getElementById('r2-placa').value.trim().toUpperCase();
  var bad = false;
  ['r2-marca', 'r2-modelo', 'r2-placa'].forEach(function (id) {
    var el = document.getElementById(id);
    var v = el.value.trim();
    var vac = !v;
    el.classList.toggle('bad', vac);
    if (vac) bad = true;
  });
  if (bad) { A.toast(A.t('rec.faltaMarca'), 'err'); return Promise.reject('val'); }
  var datos = {
    clienteId: A.rec.cliente.id,
    marca: marca, modelo: modelo, placa: placa,
    anio: document.getElementById('r2-anio').value.trim(),
    vin: document.getElementById('r2-vin').value.trim().toUpperCase(),
    color: document.getElementById('r2-color').value.trim(),
    km: document.getElementById('r2-km').value.trim(),
    comb: document.getElementById('r2-comb').value
  };
  return A.db.vehiculos.add(datos).then(function (id) {
    datos.id = id;
    A.rec.vehiculo = datos;
    return id;
  });
};

/* ---------- P3 Motivo ---------- */
A.recP3 = function () {
  var ta = document.getElementById('r3-motivo');
  ta.value = A.rec.motivo || '';
  ta.oninput = function () { A.rec.motivo = ta.value; };
  var chips = [A.t('rec.m1'), A.t('rec.m2'), A.t('rec.m3'), A.t('rec.m4'), A.t('rec.m5'), A.t('rec.m6')];
  document.getElementById('r3-chips').innerHTML = chips.map(function (m) {
    return '<button class="chip-btn" data-mot="' + A.esc(m) + '">' + A.esc(m) + '</button>';
  }).join('');
  A.$$('#r3-chips [data-mot]').forEach(function (b) {
    b.onclick = function () {
      ta.value = (ta.value ? ta.value + ' · ' : '') + b.getAttribute('data-mot');
      A.rec.motivo = ta.value;
      A.sonido('click');
    };
  });
};

/* ---------- P4 Checklist ---------- */
A.recP4 = function () {
  var sel = document.getElementById('r4-tpl');
  A.db.plantillas.toArray().then(function (pls) {
    var cur = sel.value;
    sel.innerHTML = pls.map(function (p) {
      return '<option value="' + p.id + '">' + A.esc(p.nombre) + ' (' + (p.items || []).length + ')</option>';
    }).join('');
    if (cur) sel.value = cur;
    if (!A.rec.items.length && pls.length) A.recCargarTpl(parseInt(sel.value, 10));
    sel.onchange = function () { A.recCargarTpl(parseInt(sel.value, 10)); };
  });
  document.getElementById('r4-savetpl').onclick = A.recGuardarTpl;
  A.recPintaItems();
};

A.recCargarTpl = function (tplId) {
  A.db.plantillas.get(tplId).then(function (p) {
    if (!p) return;
    A.rec.items = (p.items || []).map(function (it) {
      return { cat: it.cat, desc: it.desc, estado: null, foto: null, anotaciones: null, fotoDespues: null, nota: '' };
    });
    A.recPintaItems();
    A.sonido('scan');
  });
};

A.recPintaItems = function () {
  var box = document.getElementById('r4-checklist');
  box.innerHTML = A.rec.items.map(function (it, i) { return A.recItemHTML(it, i, false); }).join('') ||
    A.emptyState('clipboard', A.t('rec.semaforo'));
};

/* reutilizable: HTML de un ítem (wizard: sin fotoDespues) */
A.recItemHTML = function (it, i, conDespues) {
  var cls = it.estado === 'ok' ? 's-ok' : it.estado === 'atn' ? 's-atn' : it.estado === 'crit' ? 's-crit' : '';
  var foto = it.anotaciones || it.foto;
  return '<div class="ck-item ' + cls + '">' +
    '<div class="ck-top"><div class="grow">' +
      '<div class="ck-cat">' + A.esc(it.cat) + '</div>' +
      '<div class="ck-desc">' + A.esc(it.desc) + '</div>' +
      (it.nota ? '<div class="ck-note">' + A.esc(it.nota) + '</div>' : '') +
    '</div>' +
    (foto ? '<img class="ck-photo" data-foto="' + i + '" src="' + foto + '">' :
      '<div class="ck-ph-btn" data-cam="' + i + '">' + A.icon('camera', 'sm') + '</div>') +
    '</div>' +
    '<div class="ck-tools">' +
      '<div class="seg" data-seg="' + i + '">' +
        '<button data-e="ok" class="' + (it.estado === 'ok' ? 'on-ok' : '') + '">' + A.t('gen.ok') + '</button>' +
        '<button data-e="atn" class="' + (it.estado === 'atn' ? 'on-atn' : '') + '">' + A.t('gen.atn') + '</button>' +
        '<button data-e="crit" class="' + (it.estado === 'crit' ? 'on-crit' : '') + '">' + A.t('gen.crit') + '</button>' +
      '</div>' +
      (conDespues ? (it.fotoDespues ?
        '<img class="ck-photo" data-desp="' + i + '" src="' + it.fotoDespues + '">' :
        '<div class="ck-ph-btn" data-despcam="' + i + '" style="border-color:rgba(34,197,94,.5);color:#7CFCAC">' + A.icon('play', 'sm') + '</div>') : '') +
      '<span class="grow"></span>' +
      '<input class="ck-nota" data-nota="' + i + '" placeholder="' + A.esc(A.t('rec.notaPh')) + '" value="' + A.esc(it.nota || '') + '">' +
    '</div>' +
    (conDespues && it.foto && it.fotoDespues ? '<div class="ck-tools"><span class="chip info">' + A.icon('compare', 'sm') + ' ' + A.t('ord.comparar') + '</span></div>' : '') +
    '</div>';
};

/* delegación de eventos del checklist (wizard) */
document.getElementById('r4-checklist').addEventListener('click', function (e) {
  var seg = e.target.closest('[data-e]');
  if (seg) {
    var i = parseInt(seg.closest('[data-seg]').getAttribute('data-seg'), 10);
    var val = seg.getAttribute('data-e');
    A.rec.items[i].estado = A.rec.items[i].estado === val ? null : val;
    A.vibrar(20);
    A.recPintaItems();
    return;
  }
  var cam = e.target.closest('[data-cam]');
  if (cam) {
    var i2 = parseInt(cam.getAttribute('data-cam'), 10);
    A.pedirFoto({
      marca: 'PLACA ' + (A.rec.vehiculo ? A.rec.vehiculo.placa : '—'),
      onFoto: function (d) { A.rec.items[i2].foto = d; A.recPintaItems(); }
    });
    return;
  }
  var ft = e.target.closest('[data-foto]');
  if (ft) {
    var i3 = parseInt(ft.getAttribute('data-foto'), 10);
    var it = A.rec.items[i3];
    A.lightbox(it.anotaciones || it.foto, it.cat + ' · ' + it.desc, {
      anotar: true,
      onGuardar: function (d) { it.anotaciones = d; A.recPintaItems(); }
    });
  }
});
document.getElementById('r4-checklist').addEventListener('change', function (e) {
  var nota = e.target.closest('[data-nota]');
  if (nota) {
    A.rec.items[parseInt(nota.getAttribute('data-nota'), 10)].nota = nota.value;
  }
});

A.recGuardarTpl = function () {
  if (!A.rec.items.length) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
  A.modal(A.t('rec.guardarTpl'),
    '<label class="field"><span>' + A.t('tpl.nombre') + '</span><input id="tp-n"></label>' +
    '<label class="field"><span>' + A.t('tpl.tipo') + '</span><input id="tp-t" value="' + A.esc((A.rec.vehiculo || {}).marca || 'auto') + '"></label>' +
    '<button class="btn-primary" id="tp-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
    {
      onOpen: function () {
        document.getElementById('tp-ok').onclick = function () {
          var n = document.getElementById('tp-n').value.trim();
          if (!n) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
          A.db.plantillas.add({
            nombre: n,
            tipoVehiculo: document.getElementById('tp-t').value.trim() || 'auto',
            items: A.rec.items.map(function (it) { return { cat: it.cat, desc: it.desc }; }),
            creado: Date.now()
          }).then(function () {
            A.cerrarModal();
            A.toast(A.t('gen.guardadoTplOk'), 'ok');
          });
        };
      }
    });
};

/* ---------- P5 Presupuesto ---------- */
A.recP5 = function () {
  A.recPintaPresu();
  document.getElementById('r5-add-inv').onclick = function () { A.presuDesdeInv(); };
  document.getElementById('r5-add-man').onclick = function () {
    A.rec.presupuesto.push({ tipo: 'repuesto', nombre: '', cantidad: 1, costo: 0 });
    A.recPintaPresu();
  };
  document.getElementById('r5-add-mo').onclick = function () {
    A.rec.presupuesto.push({ tipo: 'mano', nombre: '', cantidad: 1, costo: A.getCfg('tarifaHora', 0) });
    A.recPintaPresu();
  };
};

A.presuTotal = function (arr) {
  return (arr || A.rec.presupuesto).reduce(function (s, r) { return s + (r.costo || 0) * (r.cantidad || 0); }, 0);
};
A.presuHoras = function (arr) {
  return (arr || A.rec.presupuesto).filter(function (r) { return r.tipo === 'mano'; })
    .reduce(function (s, r) { return s + (r.cantidad || 0); }, 0);
};

A.recPintaPresu = function () {
  var box = document.getElementById('r5-lines');
  var arr = A.rec.presupuesto;
  if (!arr.length) {
    box.innerHTML = A.emptyState('money', A.t('ord.presupuesto'));
  } else {
    box.innerHTML =
      '<div class="pcol-h"><span>' + A.t('rec.repPh') + '</span><span>' + A.t('gen.cant') + '</span><span>' + (A.t('gen.unidad')) + '</span><span>' + A.t('gen.importe') + '</span><span></span></div>' +
      arr.map(function (r, i) {
        var imp = (r.costo || 0) * (r.cantidad || 0);
        return '<div class="pline' + (r.tipo === 'mano' ? ' mano' : '') + '">' +
          '<input data-pn="' + i + '" value="' + A.esc(r.nombre) + '" placeholder="' + A.esc(r.tipo === 'mano' ? A.t('rec.moPh') : A.t('rec.repPh')) + '">' +
          '<input data-pc="' + i + '" inputmode="decimal" value="' + (r.cantidad || 0) + '">' +
          '<input data-pu="' + i + '" inputmode="decimal" value="' + (r.costo || 0) + '">' +
          '<b class="mono" style="color:var(--accent);align-self:center;font-size:13px">' + A.fmt.dinero(imp) + '</b>' +
          '<span class="del" data-pdel="' + i + '">' + A.icon('trash', 'sm') + '</span>' +
          '</div>';
      }).join('');
  }
  document.getElementById('r5-total').textContent = A.fmt.dinero(A.presuTotal());
  document.getElementById('r5-horas').textContent = A.fmt.horas(A.presuHoras());
};

document.getElementById('r5-lines').addEventListener('input', function (e) {
  var el = e.target;
  var i, arr = A.rec.presupuesto;
  if ((i = el.getAttribute('data-pn'))) { arr[+i].nombre = el.value; }
  if ((i = el.getAttribute('data-pc'))) { arr[+i].cantidad = parseFloat(el.value) || 0; A.recPintaTotales(); }
  if ((i = el.getAttribute('data-pu'))) { arr[+i].costo = parseFloat(el.value) || 0; A.recPintaTotales(); }
});
document.getElementById('r5-lines').addEventListener('click', function (e) {
  var d = e.target.closest('[data-pdel]');
  if (d) {
    A.rec.presupuesto.splice(parseInt(d.getAttribute('data-pdel'), 10), 1);
    A.recPintaPresu();
  }
});
A.recPintaTotales = function () {
  document.getElementById('r5-total').textContent = A.fmt.dinero(A.presuTotal());
  document.getElementById('r5-horas').textContent = A.fmt.horas(A.presuHoras());
  var box = document.getElementById('r5-lines');
  A.$$('#r5-lines [data-pc]').forEach(function (inp) {
    var i = +inp.getAttribute('data-pc');
    var row = inp.closest('.pline');
    var impEl = row.querySelector('b');
    if (impEl) impEl.textContent = A.fmt.dinero((A.rec.presupuesto[i].costo || 0) * (A.rec.presupuesto[i].cantidad || 0));
  });
};

A.presuDesdeInv = function () {
  A.db.inventario.toArray().then(function (inv) {
    if (!inv.length) { A.toast(A.t('rec.invEmpty'), 'err'); return; }
    A.modal(A.t('rec.desdeInv'),
      '<div class="searchbar">' + A.icon('search') + '<input id="pi-q" placeholder="' + A.esc(A.t('gen.buscarRep')) + '"></div>' +
      '<div id="pi-list" class="mini-list" style="max-height:46vh;overflow-y:auto">' +
      inv.map(function (i2) {
        var bajo = (i2.stock || 0) <= (i2.stockMinimo || 0);
        return '<div class="mini-item" style="cursor:pointer" data-inv="' + i2.id + '">' + A.icon('box') +
          '<span class="grow">' + A.esc(i2.nombre) + '</span>' +
          '<span class="chip ' + (bajo ? 'crit' : 'dim') + '">' + i2.stock + '</span>' +
          '<span class="mono" style="color:var(--accent)">' + A.fmt.dinero(i2.costo) + '</span></div>';
      }).join('') + '</div>',
      {
        onOpen: function () {
          var paint = function (t) {
            A.$$('#pi-list [data-inv]').forEach(function (row) {
              var db2 = inv.find(function (x) { return x.id === +row.getAttribute('data-inv'); });
              row.style.display = (db2.nombre || '').toLowerCase().indexOf((t || '').toLowerCase()) >= 0 ? '' : 'none';
            });
          };
          document.getElementById('pi-q').oninput = function () { paint(this.value); };
          document.getElementById('modal-body').onclick = function (e) {
            var p = e.target.closest('[data-inv]');
            if (!p) return;
            var item = inv.find(function (x) { return x.id === +p.getAttribute('data-inv'); });
            A.cerrarModal();
            A.rec.presupuesto.push({
              tipo: 'repuesto', nombre: item.nombre, cantidad: 1,
              costo: item.costo || 0, invId: item.id
            });
            A.recPintaPresu();
            A.sonido('click');
          };
        }
      });
  });
};

/* ---------- P6 Firma ---------- */
A.recP6Fit = function () {
  var cv = document.getElementById('r6-cv');
  if (!A._firmaRec) A._firmaRec = A.canvasFirma(cv);
  else A._firmaRec.refit();
  document.getElementById('r6-limpiar').onclick = function () { A._firmaRec.limpiar(); };
};

/* ---------- P7 Resumen ---------- */
A.recP7 = function () {
  var r = A.rec;
  var nOK = r.items.filter(function (x) { return x.estado === 'ok'; }).length;
  var nAT = r.items.filter(function (x) { return x.estado === 'atn'; }).length;
  var nCR = r.items.filter(function (x) { return x.estado === 'crit'; }).length;
  document.getElementById('r7-resumen').innerHTML =
    '<div class="kv"><span>' + A.t('gen.cliente') + '</span><span>' + A.esc(r.cliente.nombre) + (r.cliente.telefono ? ' · ' + A.esc(r.cliente.telefono) : '') + '</span></div>' +
    '<div class="kv"><span>' + A.t('gen.vehiculo') + '</span><span>' + A.esc(r.vehiculo.marca + ' ' + r.vehiculo.modelo) + ' · ' + A.esc(r.vehiculo.placa) + '</span></div>' +
    '<div class="kv"><span>' + A.t('pdf.motivo') + '</span><span>' + A.esc((r.motivo || '').slice(0, 60)) + '</span></div>' +
    '<div class="kv"><span>' + A.t('ord.check') + '</span><span class="mono">' +
      '<span style="color:#7CFCAC">' + nOK + ' OK</span> · <span style="color:#FFD68A">' + nAT + ' ATN</span> · <span style="color:#FFA8A8">' + nCR + ' CRIT</span></span></div>' +
    '<div class="kv"><span>' + A.t('rec.tiempoEst') + '</span><span>' + A.fmt.horas(A.presuHoras()) + '</span></div>' +
    '<div class="kv"><span>' + A.t('gen.total') + '</span><span style="color:var(--accent);font-size:19px;font-weight:700">' + A.fmt.dinero(A.presuTotal()) + '</span></div>';
  /* QR provisional con estado recepción */
  var dummy = { id: 0, estado: 'recepcion', fechaEntrada: Date.now() };
  var qrTxt = A.qr.textoOrden(dummy, r.vehiculo, r.cliente).replace('#0', '#—');
  document.getElementById('r7-qr').src = A.qr.dataURL(qrTxt, { size: 300 });
  document.getElementById('r7-guardar').onclick = A.recGuardarOrden;
};

/* ---------- guardar todo ---------- */
A.recGuardarOrden = function () {
  var r = A.rec;
  var total = A.presuTotal();
  A.swal(A.t('rec.guardando'));
  var db = A.db;

  var ordenId;
  db.transaction('rw', [db.ordenes, db.checklistItems, db.repuestos, db.inventario], function () {
    var firma = A._firmaRec && !A._firmaRec.vacio() ? A._firmaRec.aDataURL() : null;
    db.ordenes.add({
      vehiculoId: r.vehiculo.id,
      clienteId: r.cliente.id,
      fechaEntrada: Date.now(),
      fechaSalida: null,
      motivo: r.motivo || '',
      estado: 'recepcion',
      tecnico: null,
      firma: firma,
      firmaTecnico: null,
      presupuestoTotal: total,
      presupuestoAprobado: null,
      notasDiag: '',
      historial: [{ e: 'recepcion', ts: Date.now() }]
    }).then(function (id) {
      ordenId = id;
      var items = r.items.map(function (it) {
        return {
          ordenId: id, cat: it.cat, desc: it.desc, estado: it.estado || null,
          foto: it.foto || null, anotaciones: it.anotaciones || null,
          fotoDespues: it.fotoDespues || null, nota: it.nota || ''
        };
      });
      var lines = r.presupuesto.filter(function (x) { return x.nombre && x.nombre.trim(); })
        .map(function (x) { return { ordenId: id, tipo: x.tipo, nombre: x.nombre.trim(), cantidad: x.cantidad || 0, costo: x.costo || 0 }; });
      var p1 = items.length ? db.checklistItems.bulkAdd(items) : Promise.resolve();
      var p2 = lines.length ? db.repuestos.bulkAdd(lines) : Promise.resolve();
      /* descontar inventario de las líneas con invId */
      var p3 = Promise.resolve();
      r.presupuesto.forEach(function (x) {
        if (x.invId && x.nombre) {
          p3 = p3.then(function () {
            return db.inventario.get(x.invId).then(function (it) {
              if (it) return db.inventario.update(x.invId, { stock: Math.max(0, (it.stock || 0) - (x.cantidad || 0)) });
            });
          });
        }
      });
      return Promise.all([p1, p2, p3]);
    });
  }).then(function () {
    A.swalClose();
    A.sonido('success');
    A.vibrar([40, 60, 40]);
    A.recFinalizada = true;
    A.recPaso(8, true); /* animación protocolo completado */
    setTimeout(function () {
      A.recReset();
      A.recFinalizada = false;
      location.replace('#/orden/' + ordenId);
      A.ruta();
    }, 1700);
  }).catch(function (e) {
    A.swalClose();
    console.error(e);
    A.toast(A.t('gen.error'), 'err');
  });
};

/* ---------- footer ---------- */
document.getElementById('rec-back').addEventListener('click', function () {
  if (A.rec.paso > 1) A.recPaso(A.rec.paso - 1, true);
});
document.getElementById('rec-next').addEventListener('click', function () { A.recNext(); });
document.getElementById('rec-cancel').addEventListener('click', function () {
  A.confirmar(A.t('gen.cancelar'), A.t('rec.cancelQ')).then(function (ok) {
    if (!ok) return;
    A.recReset();
    A._firmaRec = null;
    A.ir('#/dashboard');
  });
});

A.recNext = function () {
  var r = A.rec;
  var paso = r.paso;
  var prom = Promise.resolve();
  if (paso === 1) {
    if (!r.cliente && document.getElementById('r1-form').hidden === false) prom = A.recP1Guardar();
    if (!r.cliente && document.getElementById('r1-form').hidden) { A.toast(A.t('rec.faltaCliente'), 'err'); return; }
  }
  if (paso === 2) {
    if (!r.vehiculo && document.getElementById('r2-form').hidden === false) prom = A.recP2Guardar();
    if (!r.vehiculo && document.getElementById('r2-form').hidden) { A.toast(A.t('rec.faltaVeh'), 'err'); return; }
  }
  if (paso === 3 && !(r.motivo || '').trim()) { A.toast(A.t('rec.faltaMotivo'), 'err'); return; }
  if (paso === 6) {
    if (A._firmaRec && !A._firmaRec.vacio()) r.firma = 'ok';
  }
  prom.then(function () { A.recPaso(paso + 1); }).catch(function () {});
};
