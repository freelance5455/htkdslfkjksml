/* AUTOSCAN · ui.js — helpers de interfaz, cámara, firma, anotación, comparador */
var A = window.A || {};

/* ---------- DOM ---------- */
A.$ = function (s, r) { return (r || document).querySelector(s); };
A.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
A.esc = function (s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
};
A.icon = function (n, cls) { return '<svg class="ic ' + (cls || '') + '"><use href="#i-' + n + '"/></svg>'; };

/* ---------- Preferencias de dispositivo (localStorage) ---------- */
A.prefs = null;
A.cargarPrefs = function () {
  try { A.prefs = JSON.parse(localStorage.getItem('as_prefs') || 'null'); } catch (e) { A.prefs = null; }
  A.prefs = A.prefs || { idioma: 'es', sonido: true, vib: true };
  if (!A.prefs.tema) A.prefs.tema = 'amber';
  if (!A.prefs.texto) A.prefs.texto = 'normal';
  if (A.prefs.particulas === undefined) A.prefs.particulas = true;
};
A.guardarPrefs = function () { localStorage.setItem('as_prefs', JSON.stringify(A.prefs)); };

/* ---------- Tema / acento / tamaño de texto (v2) ---------- */
A.applyTheme = function () {
  var h = document.documentElement;
  h.setAttribute('data-accent', A.prefs.tema || 'amber');
  h.setAttribute('data-texto', A.prefs.texto || 'normal');
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', '#0A0E17');
  if (A.bgFx) A.bgFx.setColor();
};
A.colorAcento = function () {
  var v = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
  return v || '#FFB020';
};
A.rgbAcento = function () {
  var v = getComputedStyle(document.documentElement).getPropertyValue('--accent-rgb').trim();
  return v || '255,176,32';
};

/* ---------- Contador animado (v2) ---------- */
A.countUp = function (el, target, fmt) {
  if (!el) return;
  var t0 = null, dur = 700, desde = 0;
  var paso = function (ts) {
    if (!t0) t0 = ts;
    var p = Math.min(1, (ts - t0) / dur);
    var e = 1 - Math.pow(1 - p, 3);
    var v = desde + (target - desde) * e;
    el.textContent = fmt ? fmt(v) : Math.round(v);
    if (p < 1) requestAnimationFrame(paso);
    else el.textContent = fmt ? fmt(target) : target;
  };
  requestAnimationFrame(paso);
};

/* ---------- Abrir URL externa (WhatsApp, etc.) ---------- */
A.abrirUrl = function (url) {
  try {
    var w = window.open(url, '_blank');
    if (!w) window.location.href = url;
  } catch (e) { window.location.href = url; }
};

/* ---------- Sonido / vibración ---------- */
A.sonido = function (n) {
  if (!A.prefs || !A.prefs.sonido) return;
  var el = document.getElementById('snd-' + n);
  if (!el) return;
  try {
    el.currentTime = 0;
    var p = el.play();
    if (p && p.catch) p.catch(function () {}); /* autoplay bloqueado: silencio */
  } catch (e) {}
};
A.vibrar = function (ms) {
  if (!A.prefs || !A.prefs.vib) return;
  try { navigator.vibrate(ms || 15); } catch (e) {}
};

/* ---------- Toast ---------- */
A.toast = function (msg, tipo) {
  var box = document.getElementById('toasts');
  var d = document.createElement('div');
  d.className = 'toast ' + (tipo || '');
  d.innerHTML = A.icon(tipo === 'err' ? 'warn' : (tipo === 'ok' ? 'check' : 'info')) + '<span>' + A.esc(msg) + '</span>';
  box.appendChild(d);
  if (tipo === 'err') A.sonido('error');
  setTimeout(function () {
    d.classList.add('out');
    setTimeout(function () { d.remove(); }, 400);
  }, 2800);
};

/* ---------- Confirm ---------- */
A.confirmar = function (titulo, msg, okLabel) {
  return new Promise(function (res) {
    var ov = document.getElementById('confirm');
    document.getElementById('confirm-title').textContent = titulo;
    document.getElementById('confirm-msg').textContent = msg;
    var ok = document.getElementById('confirm-ok');
    var no = document.getElementById('confirm-no');
    if (okLabel) ok.textContent = okLabel;
    ok.textContent = okLabel || A.t('gen.aceptar');
    var done = function (v) {
      ov.hidden = true;
      ok.onclick = no.onclick = null;
      res(v);
    };
    ok.onclick = function () { A.sonido('click'); done(true); };
    no.onclick = function () { done(false); };
    ov.hidden = false;
  });
};

/* ---------- Modal genérico ---------- */
A.modal = function (titulo, html, opts) {
  opts = opts || {};
  var ov = document.getElementById('modal');
  document.getElementById('modal-title').textContent = titulo;
  document.getElementById('modal-body').innerHTML = html;
  document.getElementById('modal-x').onclick = function () { A.cerrarModal(); if (opts.onClose) opts.onClose(); };
  ov.hidden = false;
  if (opts.onOpen) opts.onOpen();
  return {
    close: function () { A.cerrarModal(); if (opts.onClose) opts.onClose(); },
    body: document.getElementById('modal-body')
  };
};
A.cerrarModal = function () { document.getElementById('modal').hidden = true; };

/* ---------- Loading / FX ---------- */
A.swal = function (titulo) {
  document.getElementById('loading-t').textContent = titulo || A.t('gen.cargando');
  document.getElementById('loading').hidden = false;
};
A.swalClose = function () { document.getElementById('loading').hidden = true; };
A.fx = function (titulo, sub, ms) {
  return new Promise(function (res) {
    document.getElementById('fx-title').textContent = titulo;
    document.getElementById('fx-sub').textContent = sub || '';
    var ov = document.getElementById('fx');
    ov.hidden = false;
    A.sonido('scan');
    setTimeout(function () { ov.hidden = true; res(); }, ms || 1500);
  });
};

/* ---------- Formatos ---------- */
A.fmt = {
  fecha: function (ts) {
    if (!ts) return '—';
    return new Date(ts).toLocaleDateString(A.prefs.idioma === 'en' ? 'en-US' : 'es-MX', { day: '2-digit', month: 'short', year: 'numeric' });
  },
  fechaHora: function (ts) {
    if (!ts) return '—';
    var d = new Date(ts);
    return d.toLocaleDateString(A.prefs.idioma === 'en' ? 'en-US' : 'es-MX', { day: '2-digit', month: 'short' }) + ' · ' +
      ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
  },
  hora: function (ts) {
    var d = new Date(ts);
    return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
  },
  dinero: function (n) {
    return '$ ' + Number(n || 0).toLocaleString(A.prefs.idioma === 'en' ? 'en-US' : 'es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },
  horas: function (n) {
    var h = Number(n || 0);
    return (h % 1 === 0 ? h : h.toFixed(1)) + A.t('gen.horasShort');
  },
  duracion: function (ms) {
    if (!ms || ms < 0) return '—';
    var m = Math.round(ms / 60000);
    if (m < 60) return m + ' min';
    var h = Math.floor(m / 60);
    return h + A.t('gen.horasShort') + (m % 60 ? ' ' + (m % 60) + 'm' : '');
  }
};

A.emptyState = function (ic, msg) {
  return '<div class="empty">' + A.icon(ic) + '<div>' + A.esc(msg) + '</div></div>';
};

/* ---------- Cámara / compresión / marca de agua ---------- */
A._fotoCb = null;
A.pedirFoto = function (opts) {
  A._fotoCb = opts;
  var inp = document.getElementById('fi-foto');
  inp.value = '';
  inp.click();
};
document.getElementById('fi-foto').addEventListener('change', function () {
  var f = this.files && this.files[0];
  var cb = A._fotoCb; A._fotoCb = null;
  if (!f || !cb) return;
  A.comprimirFoto(f, cb).catch(function () { A.toast(A.t('gen.error'), 'err'); });
});
A.pedirImagen = function (cb) { /* galería (sin capture) */
  var inp = document.getElementById('fi-logo');
  inp.value = '';
  A._logoCb = cb;
  inp.click();
};
document.getElementById('fi-logo').addEventListener('change', function () {
  var f = this.files && this.files[0];
  var cb = A._logoCb; A._logoCb = null;
  if (!f || !cb) return;
  A.comprimirFoto(f, { onFoto: function (d) { cb(d); }, maxW: 400, q: 0.8, sinMarca: true });
});

A.comprimirFoto = function (src, opts) {
  opts = opts || {};
  if (typeof opts === 'function') opts = { onFoto: opts };
  return new Promise(function (resolve, reject) {
    var img = new Image();
    var url = null;
    img.onload = function () {
      try {
        var maxW = opts.maxW || 1200;
        var scale = Math.min(1, maxW / img.naturalWidth);
        var w = Math.round(img.naturalWidth * scale), h = Math.round(img.naturalHeight * scale);
        var cv = document.createElement('canvas');
        cv.width = w; cv.height = h;
        var ctx = cv.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        if (!opts.sinMarca && opts.marca) { /* marca de agua: fecha · placa */
          var fs = Math.max(13, Math.round(w * 0.028));
          var txt = opts.marca + ' · ' + new Date().toLocaleString(A.prefs.idioma === 'en' ? 'en-US' : 'es-MX');
          ctx.font = fs + "px 'JetBrains Mono', monospace";
          var tw = ctx.measureText(txt).width;
          var x = w - tw - fs, y = h - fs * 0.8;
          ctx.fillStyle = 'rgba(10,14,23,0.62)';
          ctx.fillRect(x - fs * 0.5, y - fs, tw + fs, fs * 1.6);
          ctx.fillStyle = A.colorAcento ? A.colorAcento() : '#FFB020';
          ctx.fillText(txt, x, y);
        }
        var out = cv.toDataURL('image/jpeg', opts.q || 0.7);
        if (url) URL.revokeObjectURL(url);
        resolve(out);
        if (opts.onFoto) opts.onFoto(out);
      } catch (e) { reject(e); }
    };
    img.onerror = reject;
    if (typeof src === 'string') { img.src = src; }
    else { url = URL.createObjectURL(src); img.src = url; }
  });
};

/* ---------- Canvas de firma ---------- */
A.canvasFirma = function (cvEl) {
  var ctx = cvEl.getContext('2d');
  var drawing = false, last = null, puntos = 0;
  var fit = function () {
    var r = cvEl.getBoundingClientRect();
    if (r.width < 10) return;
    cvEl.width = Math.round(r.width * 2);
    cvEl.height = Math.round(r.height * 2);
    ctx.lineWidth = Math.max(3, cvEl.width * 0.006);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = A.colorAcento ? A.colorAcento() : '#FFB020';
    var ag = A.rgbAcento ? A.rgbAcento() : '255,176,32';
    ctx.shadowColor = 'rgba(' + ag + ',.6)'; ctx.shadowBlur = 6;
  };
  fit();
  var pos = function (e) {
    var r = cvEl.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (cvEl.width / r.width), y: (e.clientY - r.top) * (cvEl.height / r.height) };
  };
  cvEl.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    try { cvEl.setPointerCapture(e.pointerId); } catch (_) {}
    drawing = true; last = pos(e); puntos++;
  });
  cvEl.addEventListener('pointermove', function (e) {
    if (!drawing) return;
    var p = pos(e);
    ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke();
    last = p;
  });
  var up = function () { drawing = false; };
  cvEl.addEventListener('pointerup', up);
  cvEl.addEventListener('pointercancel', up);
  return {
    vacio: function () { return puntos === 0; },
    limpiar: function () { puntos = 0; ctx.clearRect(0, 0, cvEl.width, cvEl.height); },
    refit: fit,
    aDataURL: function () { return cvEl.toDataURL('image/png'); }
  };
};

/* ---------- Lightbox + anotación sobre fotos ---------- */
A.lightbox = function (src, caption, opts) {
  opts = opts || {};
  var ov = document.getElementById('lightbox');
  var img = document.getElementById('lb-img');
  var cv = document.getElementById('lb-cv');
  var tools = document.getElementById('lb-tools');
  document.getElementById('lb-cap').textContent = caption || '';
  document.getElementById('lb-x').onclick = function () { ov.hidden = true; cv.style.display = 'none'; tools.hidden = true; };
  var btnAnno = document.getElementById('lb-anno');
  btnAnno.hidden = !opts.anotar;

  var ctx = cv.getContext('2d');
  var strokes = [], actual = null, tool = 'flecha';

  var abrirEditor = function () {
    tools.hidden = false;
    cv.style.display = 'block';
    cv.width = img.naturalWidth; cv.height = img.naturalHeight;
    var r = img.getBoundingClientRect();
    cv.style.width = r.width + 'px'; cv.style.height = r.height + 'px';
    ctx.lineWidth = Math.max(4, cv.width * 0.005);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = '#EF4444';
    A.sonido('scan');
  };
  btnAnno.onclick = function () { if (tools.hidden) abrirEditor(); else { tools.hidden = true; cv.style.display = 'none'; redraw(); } };

  A.$$('#lb-tools [data-tool]').forEach(function (b) {
    b.onclick = function () {
      tool = b.getAttribute('data-tool');
      A.$$('#lb-tools [data-tool]').forEach(function (x) { x.style.borderColor = ''; x.style.color = ''; });
      b.style.borderColor = 'var(--crit)'; b.style.color = '#FFA8A8';
    };
  });

  var redraw = function () {
    ctx.clearRect(0, 0, cv.width, cv.height);
    strokes.concat(actual ? [actual] : []).forEach(function (s) { pintar(s); });
  };
  var pintar = function (s) {
    ctx.save();
    if (s.t === 'libre') {
      ctx.beginPath();
      s.pts.forEach(function (p, i) { i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); });
      ctx.stroke();
    } else if (s.t === 'flecha') {
      var a = s.a, b = s.b;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      var ang = Math.atan2(b.y - a.y, b.x - a.x);
      var hl = Math.max(14, cv.width * 0.02);
      ctx.beginPath();
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - hl * Math.cos(ang - 0.42), b.y - hl * Math.sin(ang - 0.42));
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - hl * Math.cos(ang + 0.42), b.y - hl * Math.sin(ang + 0.42));
      ctx.stroke();
    } else if (s.t === 'circulo') {
      ctx.beginPath();
      ctx.arc(s.a.x, s.a.y, Math.hypot(s.b.x - s.a.x, s.b.y - s.a.y), 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  };

  var cvPos = function (e) {
    var r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (cv.width / r.width), y: (e.clientY - r.top) * (cv.height / r.height) };
  };
  cv.onpointerdown = function (e) {
    e.preventDefault();
    try { cv.setPointerCapture(e.pointerId); } catch (_) {}
    var p = cvPos(e);
    actual = { t: tool, a: p, b: p, pts: [p] };
    redraw();
  };
  cv.onpointermove = function (e) {
    if (!actual) return;
    var p = cvPos(e);
    actual.b = p; actual.pts.push(p);
    redraw();
  };
  cv.onpointerup = function () { if (actual) { strokes.push(actual); actual = null; } };
  document.getElementById('lb-undo').onclick = function () { strokes.pop(); redraw(); };

  document.getElementById('lb-save').onclick = function () {
    if (!strokes.length) { A.toast(A.t('ord.anotar'), 'err'); return; }
    var out = document.createElement('canvas');
    out.width = img.naturalWidth; out.height = img.naturalHeight;
    var octx = out.getContext('2d');
    octx.drawImage(img, 0, 0);
    var tmp = ctx; /* reutiliza pintar sobre octx */
    var oldCtx = ctx;
    ctx = octx;
    strokes.forEach(function (s) { pintar(s); });
    ctx = oldCtx;
    var data = out.toDataURL('image/jpeg', 0.85);
    if (opts.onGuardar) opts.onGuardar(data);
    ov.hidden = true; cv.style.display = 'none'; tools.hidden = true; strokes = [];
    A.toast(A.t('gen.guardadoOk'), 'ok');
  };

  img.src = src;
  ov.hidden = false;
  img.onload = function () { if (opts.autoEditar) setTimeout(abrirEditor, 250); };
};

/* ---------- Comparador Antes / Después ---------- */
A.comparador = function (antesSrc, despuesSrc, etiquetas) {
  var uid = 'c' + Date.now();
  var html =
    '<div class="comp" id="' + uid + '">' +
    '<img class="c-desp" src="' + despuesSrc + '" alt="">' +
    '<div class="c-antes" style="clip-path:inset(0 50% 0 0)"><img src="' + antesSrc + '"></div>' +
    '<div class="c-line" style="left:50%"></div>' +
    '<span class="c-lbl l">' + A.esc(etiquetas && etiquetas.antes || A.t('ord.antes')) + '</span>' +
    '<span class="c-lbl r">' + A.esc(etiquetas && etiquetas.despues || A.t('ord.despues')) + '</span>' +
    '<input type="range" min="0" max="100" value="50">' +
    '</div>';
  setTimeout(function () {
    var box = document.getElementById(uid);
    if (!box) return;
    var antes = box.querySelector('.c-antes');
    var line = box.querySelector('.c-line');
    box.querySelector('input').oninput = function () {
      var v = this.value;
      antes.style.clipPath = 'inset(0 ' + (100 - v) + '% 0 0)';
      line.style.left = v + '%';
    };
  }, 30);
  return html;
};

/* ---------- Descargar / compartir ---------- */
A.descargar = function (blob, filename) {
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1200);
};
A.compartir = function (blob, filename, titulo, texto) {
  var fallback = function () {
    A.descargar(blob, filename);
    A.toast(A.t('ord.shareNo'));
  };
  if (navigator.share) {
    var f = new File([blob], filename, { type: blob.type });
    navigator.share({ files: [f], title: titulo, text: texto || '' })
      .then(function () { A.toast(A.t('ord.pdfOk'), 'ok'); })
      .catch(function (e) { if (e && e.name === 'AbortError') return; fallback(); });
  } else { fallback(); }
};
