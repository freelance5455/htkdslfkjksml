/* AUTOSCAN · order.js — detalle de orden: estados, diagnóstico, checklist, presupuesto, firmas */
var A = window.A || {};

A.ord = null;

A.regVista('orden', function (id) {
  var idn = parseInt(id, 10);
  if (!idn) { A.ir('#/historial'); return; }
  var db = A.db;
  db.ordenes.get(idn).then(function (o) {
    if (!o) { A.toast(A.t('gen.error'), 'err'); A.ir('#/historial'); return; }
    Promise.all([
      db.vehiculos.get(o.vehiculoId),
      db.clientes.get(o.clienteId),
      db.checklistItems.where('ordenId').equals(idn).toArray(),
      db.repuestos.where('ordenId').equals(idn).toArray()
    ]).then(function (r) {
      A.ord = { o: o, veh: r[0], cli: r[1], items: r[2], reps: r[3] };
      /* v2: botón WhatsApp visible solo si el cliente tiene teléfono */
      var waBtn = document.getElementById('ord-wa-btn');
      if (waBtn) waBtn.hidden = !(A.ord.cli && A.ord.cli.telefono);
      A.ordRender();
    });
  });
});

A.ordRender = function () {
  var D = A.ord;
  var o = D.o, veh = D.veh, cli = D.cli;
  var ei = A.estInfo(o.estado);
  document.getElementById('ord-title').innerHTML =
    '<span class="mono" style="color:var(--accent)">#' + o.id + '</span> ' +
    A.esc(veh ? veh.placa : '—') + ' <span class="chip ' + ei.cls + '" style="margin-left:6px">' + ei.t + '</span>';

  var body = document.getElementById('ord-body');
  var idxEstado = A.ESTADOS.indexOf(o.estado);

  body.innerHTML =
    /* ---- estados ---- */
    '<div class="panel hud">' +
      '<div class="statebar">' + A.ESTADOS.map(function (e, i) {
        var cls = i < idxEstado ? 'done' : i === idxEstado ? 'cur' : '';
        return '<div class="sb-n ' + cls + '"><i></i><span>' + A.estInfo(e).t + '</span></div>';
      }).join('') + '</div>' +
      (o.estado !== 'entregado' ?
        '<button class="btn-primary sm" id="ord-avanzar">' + A.icon('right', 'sm') + A.t('est.' + A.ESTADOS[Math.min(idxEstado + 1, 4)]) + '</button>' :
        '<span class="chip ok">' + A.icon('check', 'sm') + ' ' + A.t('est.yaEntregado') + '</span>') +
    '</div>' +

    /* ---- info ---- */
    '<div class="panel hud">' +
      '<div class="kv"><span>' + A.t('gen.cliente') + '</span><span>' + A.esc(cli ? cli.nombre : '—') + (cli && cli.telefono ? ' · ' + A.esc(cli.telefono) : '') + '</span></div>' +
      '<div class="kv"><span>' + A.t('gen.vehiculo') + '</span><span>' + A.esc(veh ? (veh.marca + ' ' + veh.modelo + ' ' + (veh.anio || '')) : '—') + (veh ? ' · ' + A.esc(veh.color || '') : '') + '</span></div>' +
      '<div class="kv"><span>' + A.t('veh.comb') + ' / ' + A.t('veh.km') + '</span><span>' + A.t('veh.c_' + (veh.comb || 'gasolina')) + ' · ' + A.esc(veh.km || '—') + '</span></div>' +
      '<div class="kv"><span>' + A.t('pdf.motivo') + '</span><span>' + A.esc(o.motivo || '—') + '</span></div>' +
      '<div class="kv"><span>' + A.t('gen.tecnico') + '</span><span>' +
        '<button class="chip-btn" id="ord-tec">' + A.icon('user', 'sm') + ' ' + A.esc(o.tecnico || A.t('ord.tec')) + '</button></span></div>' +
      '<div class="kv"><span>' + A.t('gen.fecha') + '</span><span>' + A.fmt.fechaHora(o.fechaEntrada) + (o.fechaSalida ? ' → ' + A.fmt.fechaHora(o.fechaSalida) : '') + '</span></div>' +
    '</div>' +

    /* ---- diagnóstico IA ---- */
    '<div class="panel hud" id="ord-diagpanel">' +
      '<div class="panel-h">' + A.icon('zap') + '<span>' + A.t('ord.diag') + '</span><span class="grow"></span>' +
      '<button class="chip-btn" id="ord-analizar">' + A.icon('scan', 'sm') + ' ' + A.t('ord.analizar') + '</button></div>' +
      '<div id="ord-diag"><span class="hint">' + A.esc(A.t('ord.notasPh')) + '</span></div>' +
      '<label class="field"><span>' + A.t('ord.notasDiag') + '</span><textarea id="ord-notas" rows="2">' + A.esc(o.notasDiag || '') + '</textarea></label>' +
    '</div>' +

    /* ---- checklist ---- */
    '<div class="panel hud">' +
      '<div class="panel-h">' + A.icon('list') + '<span>' + A.t('ord.check') + '</span><span class="grow"></span>' +
      '<span class="chip dim mono">' + D.items.length + '</span></div>' +
      '<div class="checklist" id="ord-checklist">' +
        (D.items.map(function (it, i) { return A.recItemHTML(it, i, true); }).join('') || A.emptyState('list', A.t('ord.check'))) +
      '</div>' +
      '<div id="ord-compbox"></div>' +
    '</div>' +

    /* ---- galería ---- */
    (A.ordGal().length ?
    '<div class="panel hud"><div class="panel-h">' + A.icon('camera') + '<span>' + A.t('ord.galeria') + '</span></div>' +
      '<div class="gal">' + A.ordGal().join('') + '</div></div>' : '') +

    /* ---- presupuesto ---- */
    '<div class="panel hud">' +
      '<div class="panel-h">' + A.icon('money') + '<span>' + A.t('ord.presupuesto') + '</span><span class="grow"></span>' +
      (o.presupuestoAprobado ? '<span class="chip ok">' + A.t('ord.aprobado') + '</span>' :
        '<button class="chip-btn" id="ord-aprobar">' + A.icon('check', 'sm') + ' ' + A.t('ord.aprobar') + '</button>') + '</div>' +
      '<div id="ord-lines"></div>' +
      '<div class="row-btns">' +
        '<button class="btn ghost sm" id="ord-add-inv">' + A.icon('box', 'sm') + A.t('rec.desdeInv') + '</button>' +
        '<button class="btn ghost sm" id="ord-add-man">' + A.icon('tag', 'sm') + A.t('rec.repManual') + '</button>' +
        '<button class="btn ghost sm" id="ord-add-mo">' + A.icon('wrench', 'sm') + A.t('rec.manoObra') + '</button>' +
      '</div>' +
      '<div class="total-bar">' +
        '<div><span>' + A.t('rec.tiempoEst') + '</span><b id="ord-horas" class="mono">' + A.fmt.horas(A.presuHoras(D.reps)) + '</b></div>' +
        '<div><span>' + A.t('gen.total') + '</span><b class="mono">' + A.fmt.dinero(o.presupuestoTotal || 0) + '</b></div>' +
      '</div>' +
      (o.presupuestoAprobado ? '<div class="hint" style="color:#7CFCAC">' + A.t('ord.aprobadoEl') + ' ' + A.fmt.fechaHora(o.presupuestoAprobado) + '</div>' : '') +
    '</div>' +

    /* ---- tiempos ---- */
    '<div class="panel hud">' +
      '<div class="panel-h">' + A.icon('clock') + '<span>' + A.t('ord.tiempos') + '</span></div>' +
      '<div class="tline">' + A.ordTiempos() + '</div>' +
    '</div>' +

    /* ---- firmas ---- */
    '<div class="panel hud">' +
      '<div class="panel-h">' + A.icon('pen') + '<span>' + A.t('ord.firmas') + '</span></div>' +
      '<div class="frow2">' +
        '<div class="sign-wrap hud" style="height:150px">' + (o.firma ? '<img src="' + o.firma + '" style="width:100%;height:100%;object-fit:contain">' :
          '<button class="chip-btn" id="ord-firmacli" style="margin:auto">' + A.icon('pen', 'sm') + ' ' + A.t('ord.firmaCli') + '</button>') + '</div>' +
        '<div class="sign-wrap hud" style="height:150px">' + (o.firmaTecnico ? '<img src="' + o.firmaTecnico + '" style="width:100%;height:100%;object-fit:contain">' :
          '<button class="chip-btn" id="ord-firmatec" style="margin:auto">' + A.icon('pen', 'sm') + ' ' + A.t('ord.firmaTec') + '</button>') + '</div>' +
      '</div>' +
      '<div class="kv"><span>' + A.t('ord.firmaCli') + '</span><span>' + (o.firma ? 'OK' : A.t('ord.sinFirma')) + '</span></div>' +
      '<div class="kv"><span>' + A.t('ord.firmaTec') + '</span><span>' + (o.firmaTecnico ? 'OK' : A.t('ord.sinFirma')) + '</span></div>' +
    '</div>';

  A.ordPintaPresu();
};

/* ---- galería ---- */
A.ordGal = function () {
  var out = [];
  A.ord.items.forEach(function (it, i) {
    var src = it.anotaciones || it.foto;
    if (src) out.push('<div class="g-item"><img data-gal="' + i + '" src="' + src + '"><span class="g-tag">' + A.t('ord.antes') + '</span></div>');
    if (it.fotoDespues) out.push('<div class="g-item"><img data-gald="' + i + '" src="' + it.fotoDespues + '"><span class="g-tag" style="color:#7CFCAC">' + A.t('ord.despues') + '</span></div>');
  });
  return out;
};

/* ---- tiempos ---- */
A.ordTiempos = function () {
  var o = A.ord.o;
  var h = o.historial || [];
  var rows = h.map(function (p, i) {
    var prev = i > 0 ? h[i - 1].ts : null;
    var dur = prev ? A.fmt.duracion(p.ts - prev) : '';
    return '<div class="tl-row"><div class="tl-dot">' + A.icon('clock', 'sm') + '</div>' +
      '<div class="tl-body"><div class="tl-t" style="color:var(--accent)">' + A.estInfo(p.e).t + '</div>' +
      '<div class="tl-s">' + A.fmt.fechaHora(p.ts) + (dur ? ' · ' + A.t('gen.duracion') + ': ' + dur : '') + '</div></div></div>';
  }).join('');
  var total = o.fechaSalida ? o.fechaSalida - o.fechaEntrada : Date.now() - o.fechaEntrada;
  rows += '<div class="tl-row"><div class="tl-dot" style="border-color:var(--ok)">' + A.icon('check', 'sm') + '</div>' +
    '<div class="tl-body"><div class="tl-t" style="color:#7CFCAC">' + A.t('ord.enTotal') + '</div>' +
    '<div class="tl-s mono">' + A.fmt.duracion(total) + '</div></div></div>';
  return rows;
};

/* ---- presupuesto (persistente) ---- */
A.ordPintaPresu = function () {
  var D = A.ord;
  var box = document.getElementById('ord-lines');
  if (!box) return;
  var arr = D.reps;
  if (!arr.length) {
    box.innerHTML = A.emptyState('money', A.t('ord.presupuesto'));
  } else {
    box.innerHTML =
      '<div class="pcol-h"><span>' + A.t('rec.repPh') + '</span><span>' + A.t('gen.cant') + '</span><span>' + A.t('gen.unidad') + '</span><span>' + A.t('gen.importe') + '</span><span></span></div>' +
      arr.map(function (r, i) {
        var imp = (r.costo || 0) * (r.cantidad || 0);
        return '<div class="pline' + (r.tipo === 'mano' ? ' mano' : '') + '">' +
          '<input data-pn="' + i + '" value="' + A.esc(r.nombre) + '" placeholder="' + A.esc(r.tipo === 'mano' ? A.t('rec.moPh') : A.t('rec.repPh')) + '">' +
          '<input data-pc="' + i + '" inputmode="decimal" value="' + (r.cantidad || 0) + '">' +
          '<input data-pu="' + i + '" inputmode="decimal" value="' + (r.costo || 0) + '">' +
          '<b class="mono" style="color:var(--accent);align-self:center;font-size:13px">' + A.fmt.dinero(imp) + '</b>' +
          '<span class="del" data-pdel="' + i + '">' + A.icon('trash', 'sm') + '</span></div>';
      }).join('');
  }
  A.ordTotales();
};

A.ordTotales = function () {
  var D = A.ord;
  var horas = A.presuHoras(D.reps);
  var el = document.getElementById('ord-horas');
  if (el) el.textContent = A.fmt.horas(horas);
  A.$$('#ord-lines [data-pc]').forEach(function (inp) {
    var i = +inp.getAttribute('data-pc');
    var impEl = inp.closest('.pline').querySelector('b');
    if (impEl) impEl.textContent = A.fmt.dinero((D.reps[i].costo || 0) * (D.reps[i].cantidad || 0));
  });
};

A.ordGuardarPresu = function () {
  var D = A.ord;
  var total = A.presuTotal(D.reps);
  D.o.presupuestoTotal = total;
  A.db.ordenes.update(D.o.id, { presupuestoTotal: total });
  var el = document.querySelector('#ord-body .total-bar b.mono');
  if (el) el.textContent = A.fmt.dinero(total);
};

/* ================= eventos de la vista orden ================= */
document.getElementById('v-orden').addEventListener('click', function (e) {
  var t = e.target;
  var D = A.ord;
  if (!D) return;
  var db = A.db;

  /* avanzar estado */
  if (t.closest('#ord-avanzar')) {
    var i = A.ESTADOS.indexOf(D.o.estado);
    if (i >= 4) return;
    var nuevo = A.ESTADOS[i + 1];
    A.confirmar(A.estInfo(nuevo).t, A.t('est.avanzarQ')).then(function (ok) {
      if (!ok) return;
      var ts = Date.now();
      (D.o.historial = D.o.historial || []).push({ e: nuevo, ts: ts });
      var cambios = { estado: nuevo, historial: D.o.historial };
      if (nuevo === 'entregado') cambios.fechaSalida = ts;
      db.ordenes.update(D.o.id, cambios).then(function () {
        D.o.estado = nuevo;
        if (nuevo === 'entregado') D.o.fechaSalida = ts;
        A.sonido('success'); A.vibrar([30, 50, 30]);
        A.ordRender();
      });
    });
    return;
  }
  /* técnico */
  if (t.closest('#ord-tec')) {
    var tecs = A.getCfg('tecnicos', []) || [];
    A.modal(A.t('ord.tec'), tecs.length ?
      tecs.map(function (tc) {
        return '<div class="mini-item" style="cursor:pointer" data-tecn="' + A.esc(tc) + '">' + A.icon('user') +
          '<span class="grow">' + A.esc(tc) + '</span>' + A.icon('right') + '</div>';
      }).join('') :
      A.emptyState('user', A.t('aj.sinTec')),
      {
        onOpen: function () {
          document.getElementById('modal-body').onclick = function (ev) {
            var p = ev.target.closest('[data-tecn]');
            if (!p) return;
            db.ordenes.update(D.o.id, { tecnico: p.getAttribute('data-tecn') }).then(function () {
              D.o.tecnico = p.getAttribute('data-tecn');
              A.cerrarModal();
              A.ordRender();
            });
          };
        }
      });
    return;
  }
  /* analizar */
  if (t.closest('#ord-analizar')) {
    A.fx(A.t('ord.analizar'), A.t('ord.analizando'), 1600).then(function () {
      A.ordAnalizar();
    });
    return;
  }
  /* sugerencia → presupuesto */
  var add = t.closest('[data-addrep]');
  if (add) {
    D.reps.push({ ordenId: D.o.id, tipo: 'repuesto', nombre: add.getAttribute('data-addrep'), cantidad: 1, costo: 0 });
    db.repuestos.bulkPut(D.reps).then(function () { A.ordRender(); A.toast(A.t('gen.guardadoOk'), 'ok'); });
    return;
  }
  /* aprobar presupuesto */
  if (t.closest('#ord-aprobar')) {
    db.ordenes.update(D.o.id, { presupuestoAprobado: Date.now() }).then(function () {
      D.o.presupuestoAprobado = Date.now();
      A.ordRender();
      A.toast(A.t('ord.aprobado'), 'ok');
    });
    return;
  }
  /* presupuesto: añadir */
  if (t.closest('#ord-add-inv')) { A.ordPresuInv(); return; }
  if (t.closest('#ord-add-man')) {
    db.repuestos.add({ ordenId: D.o.id, tipo: 'repuesto', nombre: '', cantidad: 1, costo: 0 }).then(function (id) {
      db.repuestos.where('ordenId').equals(D.o.id).toArray().then(function (r) { D.reps = r; A.ordRender(); });
    });
    return;
  }
  if (t.closest('#ord-add-mo')) {
    db.repuestos.add({ ordenId: D.o.id, tipo: 'mano', nombre: '', cantidad: 1, costo: A.getCfg('tarifaHora', 0) }).then(function () {
      db.repuestos.where('ordenId').equals(D.o.id).toArray().then(function (r) { D.reps = r; A.ordRender(); });
    });
    return;
  }
  var pdel = t.closest('[data-pdel]');
  if (pdel) {
    A.confirmar(A.t('gen.eliminar'), A.t('ord.delItemQ')).then(function (ok) {
      if (!ok) return;
      db.repuestos.delete(D.reps[+pdel.getAttribute('data-pdel')].id).then(function () {
        D.reps.splice(+pdel.getAttribute('data-pdel'), 1);
        A.ordGuardarPresu();
        A.ordPintaPresu();
      });
    });
    return;
  }
  /* checklist: semáforo */
  var seg = t.closest('[data-e]');
  if (seg) {
    var it = D.items[+seg.closest('[data-seg]').getAttribute('data-seg')];
    var val = seg.getAttribute('data-e');
    it.estado = it.estado === val ? null : val;
    db.checklistItems.update(it.id, { estado: it.estado }).then(function () { A.ordRender(); });
    return;
  }
  var cam = t.closest('[data-cam]');
  if (cam) {
    var it2 = D.items[+cam.getAttribute('data-cam')];
    A.pedirFoto({
      marca: 'PLACA ' + (D.veh ? D.veh.placa : '—'),
      onFoto: function (d) {
        db.checklistItems.update(it2.id, { foto: d }).then(function () {
          it2.foto = d; A.ordRender(); A.toast(A.t('gen.guardadoOk'), 'ok');
        });
      }
    });
    return;
  }
  var dcam = t.closest('[data-despcam]');
  if (dcam) {
    var it3 = D.items[+dcam.getAttribute('data-despcam')];
    A.pedirFoto({
      marca: 'DESPUÉS · ' + (D.veh ? D.veh.placa : '—'),
      onFoto: function (d) {
        db.checklistItems.update(it3.id, { fotoDespues: d }).then(function () {
          it3.fotoDespues = d; A.ordRender(); A.toast(A.t('gen.guardadoOk'), 'ok');
        });
      }
    });
    return;
  }
  var ft = t.closest('[data-foto]');
  if (ft) {
    var it4 = D.items[+ft.getAttribute('data-foto')];
    A.lightbox(it4.anotaciones || it4.foto, it4.cat + ' · ' + it4.desc, {
      anotar: true,
      onGuardar: function (d) {
        db.checklistItems.update(it4.id, { anotaciones: d }).then(function () { it4.anotaciones = d; A.ordRender(); });
      }
    });
    return;
  }
  var gd = t.closest('[data-gald]');
  if (gd) {
    var it5 = D.items[+gd.getAttribute('data-gald')];
    A.lightbox(it5.fotoDespues, it5.cat + ' · ' + A.t('ord.despues'), { anotar: false });
    return;
  }
  var g = t.closest('[data-gal]');
  if (g) {
    var it6 = D.items[+g.getAttribute('data-gal')];
    A.lightbox(it6.anotaciones || it6.foto, it6.cat + ' · ' + A.t('ord.antes'), {
      anotar: true,
      onGuardar: function (d) {
        db.checklistItems.update(it6.id, { anotaciones: d }).then(function () { it6.anotaciones = d; A.ordRender(); });
      }
    });
    return;
  }
  /* comparador */
  var cmp = t.closest('[data-comp]');
  if (cmp) {
    var it7 = D.items[+cmp.getAttribute('data-comp')];
    document.getElementById('ord-compbox').innerHTML =
      '<div class="panel" style="padding:8px">' +
      '<div class="panel-h" style="margin-bottom:8px">' + A.icon('compare') + '<span>' + A.t('ord.comparar') + ' · ' + A.esc(it7.desc) + '</span></div>' +
      A.comparador(it7.anotaciones || it7.foto, it7.fotoDespues) + '</div>';
    document.getElementById('ord-compbox').scrollIntoView({ behavior: 'smooth', block: 'center' });
    A.sonido('scan');
    return;
  }
  /* firmas */
  if (t.closest('#ord-firmacli') || t.closest('#ord-firmatec')) {
    var esTec = !!t.closest('#ord-firmatec');
    A.modal(esTec ? A.t('ord.firmaTec') : A.t('ord.firmaCli'),
      '<div class="sign-wrap hud" style="height:220px"><canvas id="ord-fcv"></canvas></div>' +
      '<div class="row-btns"><button class="btn ghost sm" id="ord-fclear">' + A.t('gen.limpiar2') + '</button>' +
      '<button class="btn-primary sm" id="ord-fok">' + A.t('ord.firmar') + '</button></div>',
      {
        onOpen: function () {
          setTimeout(function () {
            var f = A.canvasFirma(document.getElementById('ord-fcv'));
            document.getElementById('ord-fclear').onclick = function () { f.limpiar(); };
            document.getElementById('ord-fok').onclick = function () {
              if (f.vacio()) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
              var campo = esTec ? 'firmaTecnico' : 'firma';
              var upd = {}; upd[campo] = f.aDataURL();
              db.ordenes.update(D.o.id, upd).then(function () {
                D.o[campo] = upd[campo];
                A.cerrarModal();
                A.sonido('success');
                A.ordRender();
              });
            };
          }, 80);
        }
      });
    return;
  }
  /* header */
  if (t.closest('#ord-wa-btn')) {
    var cli = D.cli || {};
    var tel = String(cli.telefono || '').replace(/[^0-9]/g, '');
    if (!tel) { A.toast(A.t('ord.waSinTel'), 'err'); return; }
    var veh = D.veh || {};
    var ei = A.estInfo(D.o.estado);
    var taller = A.getCfg('tallerNombre', '') || 'AUTOSCAN';
    var msg = A.t('ord.waMsgCli') + ' ' + (cli.nombre || '') + ', ' + A.t('ord.waMsgDe') + ' ' + taller + '. ' +
      A.t('ord.waMsgOrden') + ' #' + D.o.id + ' (' + (veh.marca || '') + ' ' + (veh.modelo || '') + ', ' + (veh.placa || '') + '): ' +
      A.t('ord.waMsgEstado') + ' ' + ei.t + '. ' +
      A.t('ord.waMsgTotal') + ': ' + A.fmt.dinero(D.o.presupuestoTotal || 0) + '. ' + A.t('ord.waMsgGracias');
    A.abrirUrl('https://wa.me/' + tel + '?text=' + encodeURIComponent(msg));
    return;
  }
  if (t.closest('#ord-qr-btn')) {
    var dataURL = A.qr.dataURL(A.qr.textoOrden(D.o, D.veh, D.cli), { size: 300 });
    A.qr.modal(document.getElementById('qr-img'), document.getElementById('qr-txt'), dataURL,
      A.qr.textoOrden(D.o, D.veh, D.cli), function () { A.vistaClienteModal(); });
    return;
  }
  if (t.closest('#ord-pdf-btn') || t.closest('#ord-share-btn')) {
    A.pdf.generar(D.o.id);
    return;
  }
});

/* inputs de presupuesto y notas (delegados por 'input'/'change') */
document.getElementById('v-orden').addEventListener('input', function (e) {
  var D = A.ord;
  if (!D) return;
  var el = e.target;
  var i;
  if ((i = el.getAttribute('data-pn')) !== null && i !== undefined) {
    D.reps[+i].nombre = el.value;
    A.db.repuestos.update(D.reps[+i].id, { nombre: el.value });
  }
  if ((i = el.getAttribute('data-pc')) !== null && i !== undefined) {
    D.reps[+i].cantidad = parseFloat(el.value) || 0;
    A.db.repuestos.update(D.reps[+i].id, { cantidad: D.reps[+i].cantidad });
    A.ordTotales(); A.ordGuardarPresu();
  }
  if ((i = el.getAttribute('data-pu')) !== null && i !== undefined) {
    D.reps[+i].costo = parseFloat(el.value) || 0;
    A.db.repuestos.update(D.reps[+i].id, { costo: D.reps[+i].costo });
    A.ordTotales(); A.ordGuardarPresu();
  }
  if (el.id === 'ord-notas') {
    D.o.notasDiag = el.value;
    A.db.ordenes.update(D.o.id, { notasDiag: el.value });
  }
});
document.getElementById('v-orden').addEventListener('change', function (e) {
  var D = A.ord;
  if (!D) return;
  var nota = e.target.closest('[data-nota]');
  if (nota) {
    var it = D.items[+nota.getAttribute('data-nota')];
    it.nota = nota.value;
    A.db.checklistItems.update(it.id, { nota: it.nota });
  }
});

/* desde inventario (en orden) */
A.ordPresuInv = function () {
  A.db.inventario.toArray().then(function (inv) {
    if (!inv.length) { A.toast(A.t('rec.invEmpty'), 'err'); return; }
    A.modal(A.t('rec.desdeInv'),
      '<div id="pi2-list" class="mini-list" style="max-height:56vh;overflow-y:auto">' +
      inv.map(function (i2) {
        var bajo = (i2.stock || 0) <= (i2.stockMinimo || 0);
        return '<div class="mini-item" style="cursor:pointer" data-inv2="' + i2.id + '">' + A.icon('box') +
          '<span class="grow">' + A.esc(i2.nombre) + '</span>' +
          '<span class="chip ' + (bajo ? 'crit' : 'dim') + '">' + i2.stock + '</span>' +
          '<span class="mono" style="color:var(--accent)">' + A.fmt.dinero(i2.costo) + '</span></div>';
      }).join('') + '</div>',
      {
        onOpen: function () {
          document.getElementById('modal-body').onclick = function (ev) {
            var p = ev.target.closest('[data-inv2]');
            if (!p) return;
            var item = inv.find(function (x) { return x.id === +p.getAttribute('data-inv2'); });
            A.cerrarModal();
            A.db.repuestos.add({ ordenId: A.ord.o.id, tipo: 'repuesto', nombre: item.nombre, cantidad: 1, costo: item.costo || 0 })
              .then(function () {
                A.db.inventario.update(item.id, { stock: Math.max(0, (item.stock || 0) - 1) });
                return A.db.repuestos.where('ordenId').equals(A.ord.o.id).toArray();
              })
              .then(function (r) {
                A.ord.reps = r;
                A.ordGuardarPresu();
                A.ordRender();
              });
          };
        }
      });
  });
};

/* diagnóstico por reglas */
A.ordAnalizar = function () {
  var D = A.ord;
  var hallados = D.items.filter(function (it) { return it.estado === 'atn' || it.estado === 'crit'; });
  var box = document.getElementById('ord-diag');
  if (!hallados.length) {
    box.innerHTML = '<span class="chip ok">' + A.icon('check', 'sm') + ' ' + A.t('ord.sinCrit') + '</span>';
    A.sonido('success');
    return;
  }
  var html = hallados.map(function (it) {
    var txt = ((it.cat || '') + ' ' + (it.desc || '')).toLowerCase();
    var reglas = A.REGLAS.filter(function (rg) {
      return rg.keys.some(function (k) { return txt.indexOf(k) >= 0; });
    });
    if (!reglas.length) return '';
    var causas = [], acciones = [], reps = [];
    reglas.forEach(function (rg) {
      causas = causas.concat(rg.causas);
      acciones = acciones.concat(rg.acciones);
      reps = reps.concat(rg.reps);
    });
    var chip = it.estado === 'crit' ? 'crit' : 'warn';
    return '<div class="ck-item ' + (it.estado === 'crit' ? 's-crit' : 's-atn') + '" style="margin-bottom:10px">' +
      '<div class="ck-top"><div class="grow"><div class="ck-cat">' + A.esc(it.cat) + ' · <span class="chip ' + chip + '" style="font-size:9px">' + (it.estado === 'crit' ? A.t('gen.crit') : A.t('gen.atn')) + '</span></div>' +
      '<div class="ck-desc">' + A.esc(it.desc) + '</div></div></div>' +
      '<div class="kv" style="color:#FFD68A"><span>' + A.t('ord.causas') + '</span><span></span></div>' +
      causas.slice(0, 4).map(function (c) { return '<div class="mini-item">' + A.icon('warn', 'sm') + '<span>' + A.esc(c) + '</span></div>'; }).join('') +
      '<div class="kv" style="color:#9BEBFF"><span>' + A.t('ord.acciones') + '</span><span></span></div>' +
      acciones.slice(0, 3).map(function (c) { return '<div class="mini-item">' + A.icon('scan', 'sm') + '<span>' + A.esc(c) + '</span></div>'; }).join('') +
      '<div class="kv"><span>' + A.t('ord.repSug') + '</span><span></span></div>' +
      '<div class="chips">' + reps.slice(0, 6).map(function (rp) {
        return '<button class="chip-btn" data-addrep="' + A.esc(rp) + '">' + A.icon('plus', 'sm') + ' ' + A.esc(rp) + '</button>';
      }).join('') + '</div>' +
      '</div>';
  }).join('');
  box.innerHTML = html || ('<span class="chip dim">' + A.t('ord.sinCrit') + '</span>');
  A.sonido('success');
};

/* vista cliente (pantalla pública) */
A.vistaClienteModal = function () {
  var D = A.ord;
  var ei = A.estInfo(D.o.estado);
  A.cerrarModal();
  A.modal('AUTOSCAN · ' + A.t('qr.estado'),
    '<div style="text-align:center;padding:10px 4px">' +
    '<img src="assets/img/logo.png" style="width:70px;margin:0 auto 10px;filter:drop-shadow(0 0 12px rgba(255,176,32,.5))">' +
    '<div class="mono" style="font-size:26px;color:var(--accent);letter-spacing:.1em">' + A.esc(D.veh ? D.veh.placa : '') + '</div>' +
    '<div style="color:var(--dim)">' + A.esc(D.veh ? (D.veh.marca + ' ' + D.veh.modelo) : '') + '</div>' +
    '<div style="margin:14px 0"><span class="chip ' + ei.cls + '" style="font-size:20px;padding:10px 22px">' + ei.t + '</span></div>' +
    '<div class="hint" style="font-size:14px">' + A.esc(A.getCfg('tallerNombre', '')) + (A.getCfg('tallerTel', '') ? ' · ' + A.esc(A.getCfg('tallerTel', '')) : '') + '</div>' +
    '<div class="hint mono">' + A.fmt.fechaHora(D.o.fechaEntrada) + '</div>' +
    '</div>' +
    '<button class="btn-primary" onclick="A.cerrarModal()">' + A.esc(A.t('gen.cerrar')) + '</button>');
};
