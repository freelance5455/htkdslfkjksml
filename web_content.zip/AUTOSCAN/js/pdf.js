/* AUTOSCAN · pdf.js — informe de orden con jsPDF (100% offline) */
var A = window.A || {};

A.pdf = {
  M: 14,
  W: 210,
  H: 297,
  _d: null,
  _y: 16,

  /* reserva espacio; si no cabe, crea página */
  _pg: function (h) {
    if (this._y + h > this.H - 26) {
      this._d.addPage();
      this._y = 16;
    }
    return this._y;
  },
  _t: function (txt, x, y, size, color, bold, align) {
    var d = this._d;
    d.setFont('helvetica', bold ? 'bold' : 'normal');
    d.setFontSize(size);
    d.setTextColor(color[0], color[1], color[2]);
    d.text(txt, x, y, { align: align || 'left' });
  },
  _ln: function (x1, y1, x2, y2, w, c) {
    this._d.setDrawColor(c[0], c[1], c[2]);
    this._d.setLineWidth(w || 0.5);
    this._d.line(x1, y1, x2, y2);
  },
  _rect: function (x, y, w, h, c) {
    this._d.setFillColor(c[0], c[1], c[2]);
    this._d.rect(x, y, w, h, 'F');
  },
  _logo: function () {
    var d = this._d;
    var logo = A.getCfg('tallerLogo', null);
    if (logo) { try { d.addImage(logo, 'JPEG', this.M, 12, 24, 24); return; } catch (e) {} }
    var cx = this.M + 12, cy = 24, R = 11;
    var pts = [];
    for (var i = 0; i < 6; i++) {
      var a = Math.PI / 180 * (60 * i - 90);
      pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
    }
    d.setDrawColor(255, 176, 32); d.setLineWidth(1.4);
    for (var j = 0; j < 6; j++) d.line(pts[j][0], pts[j][1], pts[(j + 1) % 6][0], pts[(j + 1) % 6][1]);
    d.setLineWidth(0.7);
    for (var k = 0; k < 3; k++) d.line(cx - 6, cy - 4 + k * 4, cx + 6, cy - 4 + k * 4);
  },

  generar: function (ordenId, opts) {
    opts = opts || {};
    var db = A.db;
    var self = this;
    var AMBAR = [255, 176, 32], DARK = [17, 23, 34], DIM = [110, 120, 135];
    var OKG = [34, 197, 94], WRN = [245, 158, 11], CRT = [239, 68, 68];
    var NEG = [10, 14, 23];

    return db.ordenes.get(ordenId).then(function (orden) {
      if (!orden) throw new Error('orden no encontrada');
      return Promise.all([
        db.vehiculos.get(orden.vehiculoId),
        db.clientes.get(orden.clienteId),
        db.checklistItems.where('ordenId').equals(ordenId).toArray(),
        db.repuestos.where('ordenId').equals(ordenId).toArray()
      ]).then(function (r) {
        var D = { orden: orden, veh: r[0], cli: r[1], items: r[2], reps: r[3] };
        var d = new jspdf.jsPDF({ unit: 'mm', format: 'a4' });
        self._d = d;
        self._y = 16;
        var MW = self.W - self.M * 2;

        /* ---- Encabezado ---- */
        self._logo();
        self._t((A.getCfg('tallerNombre', 'MI TALLER') || '').toUpperCase(), self.M + 30, 17, 15, NEG, true);
        var tel = A.getCfg('tallerTel', ''), dir = A.getCfg('tallerDir', '');
        self._t([tel, dir].filter(Boolean).join('  ·  ') || '—', self.M + 30, 22.5, 8.5, DIM);
        self._t(A.t('pdf.orden') + ' #' + ordenId, self.W - self.M, 17, 14, AMBAR, true, 'right');
        self._t(A.fmt.fechaHora(orden.fechaEntrada), self.W - self.M, 22.5, 8.5, DIM, false, 'right');
        self._ln(self.M, 30, self.W - self.M, 30, 1, AMBAR);
        self._y = 36;

        /* ---- Cliente / Vehículo ---- */
        var y = self._pg(30);
        self._t(A.t('pdf.cliente'), self.M, y, 8, AMBAR, true);
        self._t(D.cli ? D.cli.nombre : '—', self.M, y + 5, 11, NEG, true);
        if (D.cli && D.cli.telefono) self._t(D.cli.telefono, self.M, y + 10, 9, DIM);
        var x2 = self.W / 2 + 4;
        self._t(A.t('pdf.vehiculo'), x2, y, 8, AMBAR, true);
        if (D.veh) {
          self._t((D.veh.marca + ' ' + D.veh.modelo + ' ' + (D.veh.anio || '')).trim(), x2, y + 5, 11, NEG, true);
          self._t('PLACA ' + (D.veh.placa || '—') + ' · ' + A.t('veh.km').toUpperCase() + ': ' + (D.veh.km || '—') +
            ' · ' + A.t('veh.comb').toUpperCase() + ': ' + A.t('veh.c_' + (D.veh.comb || 'gasolina')), x2, y + 10, 9, DIM);
          if (D.veh.vin) self._t('VIN ' + D.veh.vin, x2, y + 14.5, 8, DIM);
        }
        self._y = y + (D.veh && D.veh.vin ? 22 : 18);

        /* ---- Motivo ---- */
        y = self._pg(16);
        self._t(A.t('pdf.motivo'), self.M, y, 8, AMBAR, true);
        var motivo = d.splitTextToSize(orden.motivo || '—', MW - 8);
        d.setFont('helvetica', 'normal'); d.setFontSize(10); d.setTextColor(NEG[0], NEG[1], NEG[2]);
        d.text(motivo, self.M, y + 5);
        self._y = y + 5 + motivo.length * 4.6 + 4;

        /* ---- Checklist ---- */
        y = self._pg(14);
        self._rect(self.M, y, MW, 7, DARK);
        self._t(' ' + A.t('pdf.checklist'), self.M, y + 5, 9, AMBAR, true);
        self._y = y + 12;
        if (!D.items.length) {
          y = self._pg(8);
          self._t('—', self.M, y, 9, DIM);
          self._y = y + 7;
        }
        D.items.forEach(function (it) {
          y = self._pg(11);
          var color = it.estado === 'ok' ? OKG : it.estado === 'atn' ? WRN : CRT;
          var tag = it.estado === 'ok' ? 'OK' : it.estado === 'atn' ? 'ATN' : 'CRIT';
          self._rect(self.M, y - 4, 13, 6, color);
          self._t(tag, self.M + 6.5, y - 0.2, 6.5, [255, 255, 255], true, 'center');
          self._t(it.cat + ' · ' + it.desc, self.M + 17, y, 9.5, NEG, true);
          if (it.nota) {
            self._t(it.nota, self.M + 17, y + 4, 8, DIM);
            self._y = y + 10;
          } else {
            self._y = y + 7;
          }
        });
        self._y += 4;

        /* ---- Fotos (2 por fila) ---- */
        var fotos = D.items.filter(function (it) { return it.anotaciones || it.foto; });
        if (fotos.length) {
          var fw = (MW - 6) / 2, fh = fw * 0.7;
          fotos.forEach(function (it, i) {
            if (i % 2 === 0) {
              y = self._pg(fh + 12);
            } else {
              y = self._y;
            }
            var px = self.M + (i % 2) * (fw + 6);
            try { d.addImage(it.anotaciones || it.foto, 'JPEG', px, y, fw, fh); } catch (e) {}
            self._t(it.cat + ' · ' + it.desc, px, y + fh + 4.5, 7.5, DIM);
            if (i % 2 === 1) {
              self._y = y + fh + 9;
            } else if (i === fotos.length - 1) {
              self._y = y + fh + 9;
            } else {
              self._y = y; /* queda a la espera de la columna derecha */
            }
          });
          self._y += 4;
        }

        /* ---- Presupuesto ---- */
        y = self._pg(20);
        self._rect(self.M, y, MW, 7, DARK);
        self._t(' ' + A.t('ord.presupuesto').toUpperCase(), self.M, y + 5, 9, AMBAR, true);
        self._y = y + 12;
        var total = 0, horas = 0;
        D.reps.forEach(function (r) {
          y = self._pg(8);
          var isMO = r.tipo === 'mano';
          var imp = (r.costo || 0) * (r.cantidad || 0);
          total += imp;
          if (isMO) horas += r.cantidad || 0;
          self._t((isMO ? '[MO] ' : '') + r.nombre, self.M, y, 9.5, NEG);
          self._t(isMO ? ((r.cantidad || 0) + 'h × $' + (r.costo || 0)) : ('×' + (r.cantidad || 0)), self.W - self.M - 32, y, 8.5, DIM, false, 'right');
          self._t(A.fmt.dinero(imp).replace('$ ', ''), self.W - self.M, y, 9.5, NEG, true, 'right');
          self._y = y + 6.5;
        });
        y = self._pg(18);
        self._ln(self.M, y, self.W - self.M, y, 0.6, AMBAR);
        self._t(A.t('rec.tiempoEst'), self.M, y + 6, 9, DIM);
        self._t(A.fmt.horas(horas), self.M + 30, y + 6, 10, NEG, true);
        self._t(A.t('gen.total'), self.W - self.M - 34, y + 6, 9, DIM, false, 'right');
        self._t(A.fmt.dinero(total), self.W - self.M, y + 6, 12, AMBAR, true, 'right');
        self._y = y + 13;
        if (orden.presupuestoAprobado) {
          y = self._pg(8);
          self._t(A.t('ord.aprobadoEl') + ' ' + A.fmt.fechaHora(orden.presupuestoAprobado), self.M, y, 8.5, OKG, true);
          self._y = y + 6;
        }

        /* ---- Notas de diagnóstico ---- */
        if (orden.notasDiag) {
          y = self._pg(20);
          self._t(A.t('ord.notasDiag'), self.M, y, 8, AMBAR, true);
          var nd = d.splitTextToSize(orden.notasDiag, MW - 8);
          d.setFont('helvetica', 'normal'); d.setFontSize(9.5); d.setTextColor(NEG[0], NEG[1], NEG[2]);
          d.text(nd, self.M, y + 5);
          self._y = y + 5 + nd.length * 4.6 + 6;
        }

        /* ---- Firmas (ancladas abajo) ---- */
        y = self._pg(34);
        y = Math.max(self._y, self.H - 58);
        var half = MW / 2;
        if (orden.firma) { try { d.addImage(orden.firma, 'PNG', self.M + 6, y - 17, 46, 17); } catch (e) {} }
        self._ln(self.M, y, self.M + half - 12, y, 0.5, DIM);
        self._t(A.t('ord.firmaCli'), self.M, y + 5, 8, DIM);
        if (orden.firmaTecnico) { try { d.addImage(orden.firmaTecnico, 'PNG', self.M + half + 18, y - 17, 46, 17); } catch (e) {} }
        self._ln(self.M + half + 12, y, self.W - self.M, y, 0.5, DIM);
        self._t(A.t('ord.firmaTec'), self.M + half + 12, y + 5, 8, DIM);

        /* ---- QR + pie ---- */
        try {
          var qrURL = A.qr.dataURL(A.qr.textoOrden(orden, D.veh, D.cli), { size: 220 });
          if (qrURL) d.addImage(qrURL, 'PNG', self.W - self.M - 22, self.H - 46, 22, 22);
        } catch (e) {}
        d.setFontSize(7.5); d.setTextColor(120, 130, 145);
        d.text(A.t('pdf.generado') + ' · ' + A.fmt.fechaHora(Date.now()), self.M, self.H - 10);
        d.text(A.t('pdf.pagina') + ' 1/' + d.getNumberOfPages(), self.W / 2, self.H - 10, { align: 'center' });

        var blob = d.output('blob');
        var nombre = 'AUTOSCAN-orden-' + ordenId + '.pdf';
        if (opts.soloBlob) return blob;
        A.compartir(blob, nombre, A.t('ord.compartirTxt'), A.t('ord.compartirTxt') + ' #' + ordenId);
        return blob;
      });
    });
  }
};
