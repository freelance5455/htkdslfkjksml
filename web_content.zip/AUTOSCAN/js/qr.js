/* AUTOSCAN · qr.js — códigos QR 100% locales (qrcode-generator) */
var A = window.A || {};

A.qr = {
  /* PNG dataURL del QR (canvas propio) */
  dataURL: function (texto, opts) {
    opts = opts || {};
    try {
      var qr = qrcode(0, 'M');          /* typeNumber 0 = auto */
      qr.addData(texto);
      qr.make();
      var n = qr.getModuleCount();
      var ss = opts.size || 290;
      var margin = 2;
      var cell = Math.floor(ss / (n + margin * 2));
      var real = cell * (n + margin * 2);
      var cv = document.createElement('canvas');
      cv.width = real; cv.height = real;
      var ctx = cv.getContext('2d');
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, real, real);
      ctx.fillStyle = '#0A0E17';
      for (var r = 0; r < n; r++) {
        for (var c = 0; c < n; c++) {
          if (qr.isDark(r, c)) {
            ctx.fillRect((c + margin) * cell, (r + margin) * cell, cell, cell);
          }
        }
      }
      return cv.toDataURL('image/png');
    } catch (e) {
      return '';
    }
  },

  /* Texto que codifica el QR de una orden (legible por cualquier lector) */
  textoOrden: function (orden, veh, cli) {
    var L = [];
    L.push('AUTOSCAN · ' + A.t('hist.ord') + ' #' + orden.id);
    if (veh) L.push(veh.marca + ' ' + veh.modelo + ' ' + (veh.anio || ''));
    if (veh) L.push(A.t('veh.placa') + ': ' + veh.placa);
    L.push(A.t('gen.estado') + ': ' + A.estInfo(orden.estado).t);
    if (cli) L.push(A.t('gen.cliente') + ': ' + cli.nombre);
    L.push(A.t('qr.taller') + ': ' + (A.getCfg('tallerNombre', '') || '—'));
    var tel = A.getCfg('tallerTel', '');
    if (tel) L.push('TEL: ' + tel);
    L.push(A.fmt.fechaHora(Date.now()));
    return L.join('\n');
  },

  /* Modal del QR (orden) */
  modal: function (imgEl, txtEl, dataURL, txt, onCliente) {
    imgEl.src = dataURL;
    txtEl.textContent = txt;
    var ov = document.getElementById('qrbox');
    document.getElementById('qr-x').onclick = function () { ov.hidden = true; };
    document.getElementById('qr-cliente').onclick = onCliente || null;
    ov.hidden = false;
    A.sonido('scan');
  }
};
