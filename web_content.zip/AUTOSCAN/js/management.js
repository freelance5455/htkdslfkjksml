/* AUTOSCAN · management.js — inventario, plantillas y ajustes */
var A = window.A || {};

A.removeCfg = function (clave) {
  delete A.cfg[clave];
  return A.db.config.delete(clave);
};

/* ================= INVENTARIO ================= */
A.regVista('inventario', function () {
  var q = document.getElementById('inv-q');
  q.oninput = function () { A.invLista(q.value); };
  A.invLista('');
});

A.invLista = function (texto) {
  A.db.inventario.toArray().then(function (inv) {
    /* stats */
    var valor = inv.reduce(function (s, i) { return s + (i.costo || 0) * (i.stock || 0); }, 0);
    var bajos = inv.filter(function (i) { return (i.stock || 0) <= (i.stockMinimo || 0); }).length;
    document.getElementById('inv-stats').innerHTML =
      '<div class="stat"><svg class="ic"><use href="#i-box"/></svg><b class="cyan">' + inv.length + '</b><span>' + A.t('inv.total') + '</span></div>' +
      '<div class="stat"><svg class="ic"><use href="#i-alert"/></svg><b class="' + (bajos ? 'crit' : 'ok') + '">' + bajos + '</b><span>' + A.t('inv.bajo') + '</span></div>' +
      '<div class="stat"><svg class="ic"><use href="#i-money"/></svg><b class="amber">' + A.fmt.dinero(valor) + '</b><span>' + A.t('inv.valor') + '</span></div>';

    var t = (texto || '').toLowerCase().trim();
    var res = inv.filter(function (i) { return !t || (i.nombre || '').toLowerCase().indexOf(t) >= 0; })
      .sort(function (a, b) { return (a.nombre || '').localeCompare(b.nombre || ''); });
    var box = document.getElementById('inv-list');
    if (!res.length) { box.innerHTML = A.emptyState('box', A.t('inv.vacio')); return; }
    box.innerHTML = res.map(function (i) {
      var bajo = (i.stock || 0) <= (i.stockMinimo || 0);
      return '<div class="card" data-inv="' + i.id + '">' +
        '<span class="thumb ph">' + A.icon('box') + '</span>' +
        '<div class="c-main"><div class="c-t">' + A.esc(i.nombre) + '</div>' +
        '<div class="c-s mono">min ' + (i.stockMinimo || 0) + ' · ' + A.fmt.dinero(i.costo || 0) + '</div></div>' +
        '<div class="c-r"><span class="chip ' + (bajo ? 'crit' : 'dim') + '">' + (i.stock || 0) + '</span></div>' +
        '<button class="icon-btn" data-invedit="' + i.id + '">' + A.icon('edit') + '</button>' +
        '<button class="icon-btn" data-invdel="' + i.id + '">' + A.icon('trash') + '</button>' +
        '</div>';
    }).join('');
  });
};

document.getElementById('inv-add').addEventListener('click', function () { A.formInv(null); });
document.getElementById('v-inventario').addEventListener('click', function (e) {
  var x;
  if ((x = e.target.closest('[data-invedit]'))) {
    A.db.inventario.get(parseInt(x.getAttribute('data-invedit'), 10)).then(function (i) { A.formInv(i); });
    return;
  }
  if ((x = e.target.closest('[data-invdel]'))) {
    A.confirmar(A.t('gen.eliminar'), A.t('inv.eliminarQ')).then(function (ok) {
      if (!ok) return;
      A.db.inventario.delete(parseInt(x.getAttribute('data-invdel'), 10)).then(function () {
        A.toast(A.t('gen.borradoOk'), 'ok');
        A.invLista(document.getElementById('inv-q').value);
      });
    });
    return;
  }
  var card = e.target.closest('[data-inv]');
  if (card) {
    A.db.inventario.get(parseInt(card.getAttribute('data-inv'), 10)).then(function (i) { A.formInv(i); });
  }
});

A.formInv = function (i) {
  i = i || {};
  A.modal(i.id ? A.t('inv.editarT') : A.t('inv.nuevo'),
    '<label class="field"><span>' + A.t('inv.item') + ' *</span><input id="fi-n" value="' + A.esc(i.nombre || '') + '"></label>' +
    '<div class="frow2">' +
      '<label class="field"><span>' + A.t('inv.stock') + '</span><input id="fi-s" inputmode="numeric" value="' + (i.stock || 0) + '"></label>' +
      '<label class="field"><span>' + A.t('inv.min') + '</span><input id="fi-m" inputmode="numeric" value="' + (i.stockMinimo || 0) + '"></label>' +
    '</div>' +
    '<label class="field"><span>' + A.t('inv.costo') + '</span><input id="fi-c" inputmode="decimal" value="' + (i.costo || 0) + '"></label>' +
    '<button class="btn-primary" id="fi-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
    {
      onOpen: function () {
        document.getElementById('fi-ok').onclick = function () {
          var n = document.getElementById('fi-n').value.trim();
          if (!n) { document.getElementById('fi-n').classList.add('bad'); A.toast(A.t('gen.errorCampos'), 'err'); return; }
          var datos = {
            nombre: n,
            stock: parseInt(document.getElementById('fi-s').value, 10) || 0,
            stockMinimo: parseInt(document.getElementById('fi-m').value, 10) || 0,
            costo: parseFloat(document.getElementById('fi-c').value) || 0
          };
          var p = i.id ? (datos.id = i.id, A.db.inventario.put(datos)) : A.db.inventario.add(datos);
          p.then(function () {
            A.cerrarModal();
            A.toast(A.t('gen.guardadoOk'), 'ok');
            A.invLista(document.getElementById('inv-q').value);
          });
        };
      }
    });
};

/* ================= PLANTILLAS ================= */
A.regVista('plantillas', function () { A.tplLista(); });

A.tplLista = function () {
  A.db.plantillas.toArray().then(function (pls) {
    pls.sort(function (a, b) { return (a.creado || 0) - (b.creado || 0); });
    var box = document.getElementById('tpl-list');
    if (!pls.length) { box.innerHTML = A.emptyState('clipboard', A.t('tpl.vacio')); return; }
    box.innerHTML = pls.map(function (p) {
      return '<div class="card" data-tpl="' + p.id + '">' +
        '<span class="thumb ph">' + A.icon('clipboard') + '</span>' +
        '<div class="c-main"><div class="c-t">' + A.esc(p.nombre) + '</div>' +
        '<div class="c-s">' + A.esc(p.tipoVehiculo || '') + ' · ' + (p.items || []).length + ' ítems</div></div>' +
        '<button class="icon-btn" data-tpledit="' + p.id + '">' + A.icon('edit') + '</button>' +
        '<button class="icon-btn" data-tpldel="' + p.id + '">' + A.icon('trash') + '</button>' +
        '</div>';
    }).join('');
  });
};

document.getElementById('tpl-add').addEventListener('click', function () { A.formTpl(null); });
document.getElementById('v-plantillas').addEventListener('click', function (e) {
  var x;
  if ((x = e.target.closest('[data-tpledit]'))) {
    A.db.plantillas.get(parseInt(x.getAttribute('data-tpledit'), 10)).then(function (p) { A.formTpl(p); });
    return;
  }
  if ((x = e.target.closest('[data-tpldel]'))) {
    A.confirmar(A.t('gen.eliminar'), A.t('tpl.eliminarQ')).then(function (ok) {
      if (!ok) return;
      A.db.plantillas.delete(parseInt(x.getAttribute('data-tpldel'), 10)).then(function () {
        A.toast(A.t('gen.borradoOk'), 'ok');
        A.tplLista();
      });
    });
  }
});

A.formTpl = function (p) {
  p = p || {};
  var itemsTxt = (p.items || []).map(function (it) { return it.cat + ' | ' + it.desc; }).join('\n');
  A.modal(p.id ? A.t('tpl.editarT') : A.t('tpl.nueva'),
    '<label class="field"><span>' + A.t('tpl.nombre') + '</span><input id="ft-n" value="' + A.esc(p.nombre || '') + '"></label>' +
    '<label class="field"><span>' + A.t('tpl.tipo') + '</span><input id="ft-t" value="' + A.esc(p.tipoVehiculo || 'auto') + '"></label>' +
    '<label class="field"><span>' + A.t('tpl.items') + '</span><textarea id="ft-i" rows="7" placeholder="' + A.esc(A.t('tpl.itemsPh')) + '">' + A.esc(itemsTxt) + '</textarea></label>' +
    '<button class="btn-primary" id="ft-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
    {
      onOpen: function () {
        document.getElementById('ft-ok').onclick = function () {
          var n = document.getElementById('ft-n').value.trim();
          var items = document.getElementById('ft-i').value.split('\n').map(function (l) { return l.trim(); })
            .filter(Boolean).map(function (l) {
              var parts = l.split('|');
              var cat = (parts[0] || 'GENERAL').trim();
              var desc = parts.slice(1).join('|').trim() || cat;
              return { cat: cat.toUpperCase(), desc: desc };
            });
          if (!n || !items.length) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
          var datos = {
            nombre: n,
            tipoVehiculo: document.getElementById('ft-t').value.trim() || 'auto',
            items: items,
            creado: p.creado || Date.now()
          };
          var pr = p.id ? (datos.id = p.id, A.db.plantillas.put(datos)) : A.db.plantillas.add(datos);
          pr.then(function () {
            A.cerrarModal();
            A.toast(A.t('gen.guardadoOk'), 'ok');
            A.tplLista();
          });
        };
      }
    });
};

/* ================= AJUSTES ================= */
A.regVista('ajustes', function () {
  var v = document.getElementById('v-ajustes');
  if (!v.dataset.wired) {
    v.dataset.wired = '1';
    A.ajWire();
  }
  A.ajCarga();
});

A.ajCarga = function () {
  document.getElementById('aj-nombre').value = A.getCfg('tallerNombre', '') || '';
  document.getElementById('aj-tel').value = A.getCfg('tallerTel', '') || '';
  document.getElementById('aj-dir').value = A.getCfg('tallerDir', '') || '';
  document.getElementById('aj-tarifa').value = A.getCfg('tarifaHora', 0) || 0;
  var logo = A.getCfg('tallerLogo', null);
  document.getElementById('aj-logo').innerHTML = logo ? '<img src="' + logo + '">' : A.icon('camera');
  document.getElementById('aj-idioma').value = A.prefs.idioma;
  document.getElementById('aj-sonido').checked = !!A.prefs.sonido;
  document.getElementById('aj-vib').checked = !!A.prefs.vib;
  /* v2: tema / texto / partículas / versión */
  document.getElementById('aj-texto').value = A.prefs.texto || 'normal';
  document.getElementById('aj-particulas').checked = A.prefs.particulas !== false;
  A.$$('#aj-temas .tema-btn').forEach(function (b) {
    b.classList.toggle('on', b.getAttribute('data-tema') === (A.prefs.tema || 'amber'));
  });
  var verEl = document.getElementById('aj-ver');
  if (verEl) verEl.textContent = A.VERSION || '2.0.0';
  /* v2: estado del PIN */
  A.ajPinPinta();
  /* técnicos */
  A.ajTecPinta();
  /* último respaldo */
  var lb = A.getCfg('lastBackup', null);
  var el = document.getElementById('aj-lastbk');
  el.textContent = (lb ? A.t('aj.lastbk').replace('—', A.fmt.fechaHora(lb)) : A.t('aj.lastbk'));
  /* almacenamiento */
  if (navigator.storage && navigator.storage.estimate) {
    navigator.storage.estimate().then(function (est) {
      var used = (est.usage / 1048576).toFixed(1);
      var quota = (est.quota / 1048576).toFixed(0);
      document.getElementById('aj-storage').textContent = used + ' / ' + quota + ' MB';
    });
  }
};

A.ajPinPinta = function () {
  var sw = document.getElementById('aj-pin-switch');
  var st = document.getElementById('aj-pin-status');
  var hint = document.getElementById('aj-pin-hint');
  if (!sw) return;
  var hay = !!A.getCfg('pinHash', null);
  var activo = A.pinActivo();
  sw.checked = activo;
  sw.disabled = !hay;
  if (st) {
    st.textContent = activo ? A.t('aj.pinOn') : A.t('aj.pinOff');
    st.className = 'chip ' + (activo ? 'ok' : 'dim');
  }
  if (hint) {
    hint.textContent = A.tienePregunta() ? A.t('aj.pregSet') : A.t('aj.pregNoSet');
  }
};

A.ajTecPinta = function () {
  var tecs = A.getCfg('tecnicos', []) || [];
  var box = document.getElementById('aj-tec-list');
  box.innerHTML = tecs.map(function (t) {
    return '<button class="chip-btn" data-tecx="' + A.esc(t) + '">' + A.esc(t) + ' ' + A.icon('x', 'sm') + '</button>';
  }).join('') || '<span class="hint">' + A.esc(A.t('aj.sinTec')) + '</span>';
};

A.ajWire = function () {
  var v = document.getElementById('v-ajustes');

  /* perfil */
  document.getElementById('aj-save').onclick = function () {
    var nombre = document.getElementById('aj-nombre').value.trim() || 'MI TALLER';
    Promise.all([
      A.setCfg('tallerNombre', nombre),
      A.setCfg('tallerTel', document.getElementById('aj-tel').value.trim()),
      A.setCfg('tallerDir', document.getElementById('aj-dir').value.trim()),
      A.setCfg('tarifaHora', parseFloat(document.getElementById('aj-tarifa').value) || 0)
    ]).then(function () {
      A.toast(A.t('aj.guardadoOk'), 'ok');
      A.sonido('success');
      document.title = 'AUTOSCAN — ' + nombre;
    });
  };
  document.getElementById('aj-logo').onclick = function () {
    A.pedirImagen(function (d) {
      A.setCfg('tallerLogo', d).then(function () {
        document.getElementById('aj-logo').innerHTML = '<img src="' + d + '">';
        A.toast(A.t('aj.guardadoOk'), 'ok');
      });
    });
  };
  document.getElementById('aj-logo-x').onclick = function () {
    A.removeCfg('tallerLogo').then(function () {
      document.getElementById('aj-logo').innerHTML = A.icon('camera');
    });
  };

  /* técnicos */
  document.getElementById('aj-tec-add').onclick = function () {
    var inp = document.getElementById('aj-tec-nuevo');
    var n = inp.value.trim();
    if (!n) return;
    var tecs = A.getCfg('tecnicos', []) || [];
    if (tecs.indexOf(n) >= 0) { A.toast(A.t('gen.duplicado'), 'err'); return; }
    tecs.push(n);
    A.setCfg('tecnicos', tecs).then(function () {
      inp.value = '';
      A.ajTecPinta();
      A.toast(A.t('gen.guardadoOk'), 'ok');
    });
  };
  v.addEventListener('click', function (e) {
    var x = e.target.closest('[data-tecx]');
    if (x) {
      var tecs = A.getCfg('tecnicos', []) || [];
      var n = x.getAttribute('data-tecx');
      tecs = tecs.filter(function (t) { return t !== n; });
      A.setCfg('tecnicos', tecs).then(A.ajTecPinta);
    }
  });

  /* plantillas + prefs */
  document.getElementById('aj-go-tpl').onclick = function () { A.ir('#/plantillas'); };
  document.getElementById('aj-idioma').onchange = function () {
    A.prefs.idioma = this.value;
    A.guardarPrefs();
    A.applyI18n();
    A.ruta();
    A.toast(A.t('aj.guardadoOk'), 'ok');
  };
  document.getElementById('aj-sonido').onchange = function () {
    A.prefs.sonido = this.checked; A.guardarPrefs();
    if (this.checked) A.sonido('click');
  };
  document.getElementById('aj-vib').onchange = function () {
    A.prefs.vib = this.checked; A.guardarPrefs();
    if (this.checked) A.vibrar(30);
  };
  document.getElementById('aj-sons-test').onclick = function () { A.sonido('success'); };

  /* v2: temas, texto, partículas */
  document.getElementById('aj-temas').addEventListener('click', function (e) {
    var b = e.target.closest('.tema-btn');
    if (!b) return;
    A.prefs.tema = b.getAttribute('data-tema');
    A.guardarPrefs();
    A.applyTheme();
    A.$$('#aj-temas .tema-btn').forEach(function (x) { x.classList.toggle('on', x === b); });
    A.sonido('scan'); A.vibrar(15);
    A.toast(A.t('aj.temaOk'), 'ok');
  });
  document.getElementById('aj-texto').onchange = function () {
    A.prefs.texto = this.value;
    A.guardarPrefs();
    A.applyTheme();
    A.toast(A.t('aj.guardadoOk'), 'ok');
  };
  document.getElementById('aj-particulas').onchange = function () {
    A.prefs.particulas = this.checked;
    A.guardarPrefs();
    A.bgFx.refresh();
    A.toast(A.t('aj.guardadoOk'), 'ok');
  };

  /* v2: manual */
  document.getElementById('aj-manual').onclick = function () { A.ir('#/manual'); };

  /* v2: exportar CSV */
  document.getElementById('aj-csv').onclick = function () {
    A.modal(A.t('aj.csvT'),
      ['clientes', 'ordenes', 'inventario'].map(function (tp) {
        return '<div class="mini-item" style="cursor:pointer" data-csv="' + tp + '">' +
          A.icon(tp === 'clientes' ? 'users' : (tp === 'ordenes' ? 'clipboard' : 'box')) +
          '<span class="grow">' + A.esc(A.t('aj.csv' + (tp === 'inventario' ? 'Inv' : (tp === 'ordenes' ? 'Ordenes' : 'Clientes')))) + '</span>' +
          A.icon('right') + '</div>';
      }).join(''),
      {
        onOpen: function () {
          document.getElementById('modal-body').onclick = function (ev) {
            var p = ev.target.closest('[data-csv]');
            if (!p) return;
            A.cerrarModal();
            A.exportCSV(p.getAttribute('data-csv'));
          };
        }
      });
  };

  /* seguridad v2: interruptor PIN + cambiar + pregunta */
  document.getElementById('aj-pin-switch').onchange = function () {
    var on = this.checked;
    if (!on) {
      A.setPinActivo(false).then(function () {
        A.toast(A.t('aj.pinOffOk'), 'ok');
        A.ajPinPinta();
      });
    } else {
      if (A.getCfg('pinHash', null)) {
        A.setPinActivo(true).then(function () {
          A.toast(A.t('aj.pinOnOk'), 'ok');
          A.ajPinPinta();
        });
      } else {
        /* no hay PIN guardado: crearlo ahora */
        this.checked = false;
        A.modal(A.t('aj.crearPinT'),
          '<label class="field"><span>' + A.t('aj.pinNuevo') + '</span><input id="np-a" inputmode="numeric" maxlength="4" style="-webkit-text-security:disc"></label>' +
          '<label class="field"><span>' + A.t('aj.pinNuevo2') + '</span><input id="np-b" inputmode="numeric" maxlength="4" style="-webkit-text-security:disc"></label>' +
          '<button class="btn-primary" id="np-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
          {
            onOpen: function () {
              document.getElementById('np-ok').onclick = function () {
                var a = document.getElementById('np-a').value.trim();
                var b = document.getElementById('np-b').value.trim();
                if (a.length !== 4 || a !== b) { A.toast(A.t('aj.pinNoMatch'), 'err'); return; }
                A.guardarPinConActivo(a).then(function () {
                  A.cerrarModal();
                  A.toast(A.t('aj.pinCambiado'), 'ok');
                  A.sonido('success');
                  A.ajPinPinta();
                });
              };
            }
          });
      }
    }
  };
  document.getElementById('aj-pin-cambiar').onclick = function () {
    if (!A.getCfg('pinHash', null)) { document.getElementById('aj-pin-switch').click(); return; }
    A.modal(A.t('aj.cambiarPin'),
      '<label class="field"><span>' + A.t('aj.pinActual') + '</span><input id="pc-a" inputmode="numeric" maxlength="4" style="-webkit-text-security:disc"></label>' +
      '<label class="field"><span>' + A.t('aj.pinNuevo') + '</span><input id="pc-n" inputmode="numeric" maxlength="4" style="-webkit-text-security:disc"></label>' +
      '<label class="field"><span>' + A.t('aj.pinNuevo2') + '</span><input id="pc-n2" inputmode="numeric" maxlength="4" style="-webkit-text-security:disc"></label>' +
      '<button class="btn-primary" id="pc-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
      {
        onOpen: function () {
          document.getElementById('pc-ok').onclick = function () {
            var a = document.getElementById('pc-a').value.trim();
            var n = document.getElementById('pc-n').value.trim();
            var n2 = document.getElementById('pc-n2').value.trim();
            if (n.length !== 4 || n !== n2) { A.toast(A.t('aj.pinNoMatch'), 'err'); return; }
            A.verificarPin(a).then(function (ok) {
              if (!ok) { A.toast(A.t('aj.pinBad'), 'err'); return; }
              A.guardarPinConActivo(n).then(function () {
                A.cerrarModal();
                A.toast(A.t('aj.pinCambiado'), 'ok');
                A.ajPinPinta();
              });
            });
          };
        }
      });
  };
  document.getElementById('aj-pin-pregunta').onclick = function () {
    if (A.tienePregunta()) {
      A.modal(A.t('aj.pregunta'),
        '<div class="hint" style="margin-bottom:10px"><b>' + A.esc(A.getCfg('preguntaSeg')) + '</b></div>' +
        '<label class="field"><span>' + A.t('lock.pregQ') + '</span><input id="pq-q" value="' + A.esc(A.getCfg('preguntaSeg')) + '"></label>' +
        '<label class="field"><span>' + A.t('lock.pregA') + '</span><input id="pq-a" placeholder="••••"></label>' +
        '<label class="field"><span>' + A.t('lock.pregA2') + '</span><input id="pq-a2" placeholder="••••"></label>' +
        '<div class="row-btns" style="margin-top:8px">' +
        '<button class="btn ghost danger sm" id="pq-x">' + A.esc(A.t('aj.pregQuitar')) + '</button>' +
        '<button class="btn-primary" id="pq-ok">' + A.esc(A.t('gen.guardar')) + '</button></div>',
        {
          onOpen: function () {
            document.getElementById('pq-ok').onclick = function () {
              var q = document.getElementById('pq-q').value.trim();
              var a = document.getElementById('pq-a').value.trim();
              var a2 = document.getElementById('pq-a2').value.trim();
              if (!q || !a) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
              if (a !== a2) { A.toast(A.t('lock.pregNoMatch'), 'err'); return; }
              A.guardarPregunta(q, a).then(function () {
                A.cerrarModal();
                A.toast(A.t('aj.pregGuardada'), 'ok');
                A.ajPinPinta();
              });
            };
            document.getElementById('pq-x').onclick = function () {
              A.confirmar(A.t('aj.pregQuitar'), A.t('aj.pregNoSet')).then(function (ok) {
                if (!ok) return;
                A.quitarPregunta().then(function () {
                  A.cerrarModal();
                  A.toast(A.t('aj.pregQuitada'), 'ok');
                  A.ajPinPinta();
                });
              });
            };
          }
        });
    } else {
      A.modal(A.t('aj.pregunta'),
        '<div class="hint" style="margin-bottom:10px">' + A.esc(A.t('lock.crearPregSub')) + '</div>' +
        '<label class="field"><span>' + A.t('lock.pregQ') + '</span><input id="pq-q"></label>' +
        '<label class="field"><span>' + A.t('lock.pregA') + '</span><input id="pq-a"></label>' +
        '<label class="field"><span>' + A.t('lock.pregA2') + '</span><input id="pq-a2"></label>' +
        '<button class="btn-primary" id="pq-ok" style="margin-top:8px">' + A.esc(A.t('gen.guardar')) + '</button>',
        {
          onOpen: function () {
            document.getElementById('pq-ok').onclick = function () {
              var q = document.getElementById('pq-q').value.trim();
              var a = document.getElementById('pq-a').value.trim();
              var a2 = document.getElementById('pq-a2').value.trim();
              if (!q || !a) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
              if (a !== a2) { A.toast(A.t('lock.pregNoMatch'), 'err'); return; }
              A.guardarPregunta(q, a).then(function () {
                A.cerrarModal();
                A.toast(A.t('aj.pregGuardada'), 'ok');
                A.ajPinPinta();
              });
            };
          }
        });
    }
  };

  /* respaldo */
  document.getElementById('aj-exp').onclick = function () { A.backupExport(); };
  document.getElementById('aj-imp').onclick = function () {
    A.confirmar(A.t('aj.importar'), A.t('aj.importarQ')).then(function (ok) {
      if (!ok) return;
      var inp = document.getElementById('fi-import');
      inp.value = '';
      inp.click();
    });
  };
  document.getElementById('fi-import').addEventListener('change', function () {
    var f = this.files && this.files[0];
    if (!f) return;
    A.swal(A.t('gen.cargando'));
    A.backupImport(f);
  });

  /* info */
  document.getElementById('aj-demo').onclick = function () {
    A.confirmar(A.t('aj.demo'), A.t('aj.demoQ')).then(function (ok) {
      if (!ok) return;
      A.cargarDemo().then(function () {
        A.toast(A.t('aj.demoOk'), 'ok');
        A.ir('#/dashboard');
      });
    });
  };
  document.getElementById('aj-wipe').onclick = function () {
    A.confirmar(A.t('aj.borrar'), A.t('aj.borrarQ'), A.t('gen.eliminar')).then(function (ok) {
      if (!ok) return;
      A.wipeTotal();
    });
  };
  document.getElementById('aj-avanzadas').onclick = function () {
    var items = [
      ['ocr', 'OCR de VIN / placa (Tesseract.js)'],
      ['barcode', 'Lector de código de barras'],
      ['notif', 'Notificaciones nativas'],
      ['bio', 'Biometría (huella)'],
      ['widget', 'Widget de Android'],
      ['print', 'Impresora térmica Bluetooth']
    ];
    A.modal(A.t('gen.faseAv'),
      items.map(function (it) {
        return '<div class="mini-item" style="cursor:pointer" data-av="' + it[0] + '">' + A.icon('zap') +
          '<span class="grow">' + it[1] + '</span><span class="chip warn">FASE AV.</span></div>';
      }).join('') +
      '<span class="hint">' + A.esc(A.t('gen.ocrHint')) + ' · docs/FASE-AVANZADA.txt</span>',
      {
        onOpen: function () {
          document.getElementById('modal-body').onclick = function (ev) {
            var p = ev.target.closest('[data-av]');
            if (p) A.avanzadaModal(p.getAttribute('data-av'));
          };
        }
      });
  };
  document.getElementById('aj-licencias').onclick = function () {
    A.modal(A.t('aj.licencias'),
      '<div class="hint" style="font-size:13.5px;line-height:1.8">' +
      'Dexie.js — MIT (github.com/dexie/Dexie.js)<br>' +
      'jsPDF — MIT (github.com/parallax/jsPDF)<br>' +
      'JSZip — MIT (stuk.github.io/jszip)<br>' +
      'qrcode-generator — MIT (github.com/kazuhikoarase/qrcode-generator)<br>' +
      'JetBrains Mono — OFL (jetbrains.com/mono)<br>' +
      'Rajdhani — OFL (Google Fonts)<br>' +
      'Sonidos y logo: generados para este proyecto (libres de uso).</div>');
  };
};

/* ================= EXPORTAR CSV (v2) ================= */
A.csvEsc = function (v) {
  var s = String(v == null ? '' : v);
  if (/[;"\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
  return s;
};
A.exportCSV = function (tipo) {
  var db = A.db;
  var iso = function (ts) { return ts ? new Date(ts).toISOString().slice(0, 16).replace('T', ' ') : ''; };
  A.swal(A.t('gen.cargando'));
  var pr;
  if (tipo === 'clientes') {
    pr = db.clientes.toArray().then(function (rows) {
      var head = ['id', 'nombre', 'telefono', 'email', 'notas', 'alta'];
      return [head].concat(rows.map(function (c) {
        return [c.id, c.nombre, c.telefono, c.email, c.notas, iso(c.creado)];
      }));
    });
  } else if (tipo === 'ordenes') {
    pr = Promise.all([db.ordenes.toArray(), db.vehiculos.toArray(), db.clientes.toArray()]).then(function (r) {
      var placa = {}, cli = {};
      r[1].forEach(function (v) { placa[v.id] = v.placa; });
      r[2].forEach(function (c) { cli[c.id] = c.nombre; });
      var head = ['orden', 'entrada', 'salida', 'cliente', 'placa', 'motivo', 'estado', 'tecnico', 'total'];
      return [head].concat(r[0].map(function (o) {
        return [o.id, iso(o.fechaEntrada), iso(o.fechaSalida), cli[o.clienteId] || '', placa[o.vehiculoId] || '',
          o.motivo, A.estInfo(o.estado).t, o.tecnico || '', (o.presupuestoTotal || 0).toFixed(2)];
      }));
    });
  } else {
    pr = db.inventario.toArray().then(function (rows) {
      var head = ['id', 'repuesto', 'stock', 'stock_minimo', 'costo', 'valor'];
      return [head].concat(rows.map(function (i) {
        return [i.id, i.nombre, i.stock, i.stockMinimo, (i.costo || 0).toFixed(2), ((i.costo || 0) * (i.stock || 0)).toFixed(2)];
      }));
    });
  }
  pr.then(function (tabla) {
    var csv = '\uFEFF' + tabla.map(function (fila) {
      return fila.map(A.csvEsc).join(';');
    }).join('\r\n');
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    A.swalClose();
    A.toast(A.t('aj.csvOk'), 'ok');
    A.sonido('success');
    A.compartir(blob, 'AUTOSCAN-' + tipo + '-' + new Date().toISOString().slice(0, 10) + '.csv',
      'AUTOSCAN ' + tipo, 'CSV exportado desde AUTOSCAN');
  }).catch(function (e) {
    A.swalClose();
    console.error(e);
    A.toast(A.t('gen.error'), 'err');
  });
};

/* ================= RESPALDO ================= */
A.backupExport = function () {
  A.swal(A.t('gen.cargando'));
  var db = A.db;
  var stores = ['clientes', 'vehiculos', 'ordenes', 'checklistItems', 'repuestos', 'plantillas', 'inventario', 'recordatorios', 'config'];
  return Promise.all(stores.map(function (s) { return db[s].toArray(); })).then(function (arrays) {
    var tablas = {};
    stores.forEach(function (s, i) { tablas[s] = arrays[i]; });
    var zip = new JSZip();
    zip.file('backup.json', JSON.stringify({ v: 1, fecha: Date.now(), tablas: tablas }));
    zip.file('LEEME-BACKUP.txt',
      'Respaldo de AUTOSCAN\n' +
      'Fecha: ' + new Date().toLocaleString() + '\n\n' +
      'Para restaurar: AUTOSCAN -> Ajustes -> Respaldo -> Importar .zip\n' +
      'Compatible solo con AUTOSCAN v1.x\n');
    return zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
  }).then(function (blob) {
    A.swalClose();
    A.setCfg('lastBackup', Date.now()).then(function () {
      A.ajCarga();
      var lb = A.getCfg('lastBackup');
      document.getElementById('aj-lastbk').textContent = A.t('aj.lastbk').replace('—', A.fmt.fechaHora(lb));
    });
    A.toast(A.t('aj.bkOk'), 'ok');
    A.sonido('success');
    A.compartir(blob, 'AUTOSCAN-respaldo-' + new Date().toISOString().slice(0, 10) + '.zip',
      'Respaldo AUTOSCAN', 'Respaldo de la base del taller');
  }).catch(function (e) {
    A.swalClose();
    console.error(e);
    A.toast(A.t('gen.error'), 'err');
  });
};

A.backupImport = function (file) {
  JSZip.loadAsync(file).then(function (zip) {
    var f = zip.file('backup.json');
    if (!f) throw new Error('no backup.json');
    return f.async('string');
  }).then(function (txt) {
    var data = JSON.parse(txt);
    if (!data || data.v !== 1 || !data.tablas) throw new Error('bad');
    var db = A.db;
    var tablas = data.tablas;
    var stores = Object.keys(tablas);
    return db.transaction('rw', stores.map(function (s) { return db[s]; }), function () {
      var ps = stores.map(function (s) {
        var table = db[s];
        var rows = tablas[s] || [];
        return table.clear().then(function () {
          return rows.length ? table.bulkAdd(rows) : Promise.resolve();
        });
      });
      return Promise.all(ps);
    });
  }).then(function () {
    A.swalClose();
    A.loadCfg().then(function () {
      A.toast(A.t('aj.impOk'), 'ok');
      A.sonido('success');
      A.ir('#/dashboard');
      A.ruta();
    });
  }).catch(function (e) {
    A.swalClose();
    console.error(e);
    A.toast(A.t('aj.impBad'), 'err');
  });
};

/* ================= DEMO / WIPE ================= */
A.cargarDemo = function () {
  var db = A.db;
  var now = Date.now();
  var dia = 86400000;
  var tecs = A.getCfg('tecnicos', []) || [];
  if (!tecs.length) { A.setCfg('tecnicos', ['CARLOS M.', 'LUIS R.']); }

  function maxId(tabla) {
    return db[tabla].toArray().then(function (a) {
      return a.reduce(function (m, x) { return Math.max(m, x.id || 0); }, 0);
    });
  }

  /* IDs explícitos: este Dexie no resuelve bulkAdd con array de claves */
  return Promise.all([maxId('clientes'), maxId('vehiculos'), maxId('ordenes')]).then(function (mx) {
    var c1 = mx[0] + 1, c2 = mx[0] + 2, c3 = mx[0] + 3;
    var v1 = mx[1] + 1, v2 = mx[1] + 2, v3 = mx[1] + 3, v4 = mx[1] + 4;
    var o1 = mx[2] + 1, o2 = mx[2] + 2, o3 = mx[2] + 3;

    var cli = [
      { id: c1, nombre: 'JUAN PÉREZ', telefono: '555-0101', email: '', notas: 'Cliente frecuente', foto: null, creado: now - 90 * dia },
      { id: c2, nombre: 'MARÍA GÓMEZ', telefono: '555-0202', email: 'maria@mail.com', notas: '', foto: null, creado: now - 60 * dia },
      { id: c3, nombre: 'TRANSPORTES RÁPIDO S.A.', telefono: '555-0303', email: '', notas: 'Flota de 3 unidades', foto: null, creado: now - 30 * dia }
    ];
    var veh = [
      { id: v1, clienteId: c1, marca: 'TOYOTA', modelo: 'COROLLA', anio: '2018', placa: 'ABC-123', vin: 'JTDBR32E', color: 'Blanco', km: '85000', comb: 'gasolina' },
      { id: v2, clienteId: c1, marca: 'HONDA', modelo: 'CIVIC', anio: '2015', placa: 'XYZ-889', vin: '', color: 'Gris', km: '120000', comb: 'gasolina' },
      { id: v3, clienteId: c2, marca: 'SUZUKI', modelo: 'GD150', anio: '2021', placa: 'MTO-456', vin: '', color: 'Negro', km: '21000', comb: 'gasolina' },
      { id: v4, clienteId: c3, marca: 'NISSAN', modelo: 'NP300', anio: '2020', placa: 'FLT-001', vin: '', color: 'Blanco', km: '150000', comb: 'diesel' }
    ];
    var ord = [
      { id: o1, vehiculoId: v1, clienteId: c1, fechaEntrada: now - 2 * dia, fechaSalida: null,
        motivo: 'Ruido al frenar y vibración en volante', estado: 'reparacion', tecnico: 'CARLOS M.',
        firma: null, firmaTecnico: null, presupuestoTotal: 2850, presupuestoAprobado: now - 1 * dia, notasDiag: '',
        historial: [{ e: 'recepcion', ts: now - 2 * dia }, { e: 'diagnostico', ts: now - 2 * dia + 3600000 }, { e: 'reparacion', ts: now - 1 * dia }] },
      { id: o2, vehiculoId: v3, clienteId: c2, fechaEntrada: now - 4 * dia, fechaSalida: null,
        motivo: 'Servicio de aceite y ajuste de cadena', estado: 'listo', tecnico: 'LUIS R.',
        firma: null, firmaTecnico: null, presupuestoTotal: 1200, presupuestoAprobado: now - 3 * dia, notasDiag: '',
        historial: [{ e: 'recepcion', ts: now - 4 * dia }, { e: 'diagnostico', ts: now - 4 * dia + 1800000 }, { e: 'reparacion', ts: now - 3 * dia }, { e: 'listo', ts: now - 2 * dia }] },
      { id: o3, vehiculoId: v4, clienteId: c3, fechaEntrada: now - 40 * dia, fechaSalida: now - 38 * dia,
        motivo: 'Cambio de pastillas y líquido de frenos', estado: 'entregado', tecnico: 'CARLOS M.',
        firma: null, firmaTecnico: null, presupuestoTotal: 1980, presupuestoAprobado: now - 39 * dia, notasDiag: 'Desgaste al 20%',
        historial: [{ e: 'recepcion', ts: now - 40 * dia }, { e: 'diagnostico', ts: now - 40 * dia + 7200000 }, { e: 'reparacion', ts: now - 39 * dia }, { e: 'listo', ts: now - 38 * dia }, { e: 'entregado', ts: now - 38 * dia }] }
    ];
    var items = [];
    [
      ['SEGURIDAD', 'Frenos', 'crit', 'Chirrido agudo al frenar'],
      ['SEGURIDAD', 'Suspensión', 'atn', ''],
      ['SEGURIDAD', 'Neumáticos delanteros', 'ok', ''],
      ['MOTOR', 'Nivel de aceite', 'ok', ''],
      ['MOTOR', 'Batería y bornes', 'ok', '']
    ].forEach(function (x) {
      items.push({ ordenId: o1, cat: x[0], desc: x[1], estado: x[2], foto: null, anotaciones: null, fotoDespues: null, nota: x[3] });
    });
    [['SEGURIDAD', 'Frenos', 'ok'], ['MOTOR', 'Nivel de aceite', 'ok'], ['TRANSMISIÓN', 'Cadena y piñones', 'atn']]
      .forEach(function (x) {
        items.push({ ordenId: o2, cat: x[0], desc: x[1], estado: x[2], foto: null, anotaciones: null, fotoDespues: null, nota: '' });
      });
    [['SEGURIDAD', 'Frenos', 'ok'], ['MOTOR', 'Líquido de frenos', 'ok']]
      .forEach(function (x) {
        items.push({ ordenId: o3, cat: x[0], desc: x[1], estado: x[2], foto: null, anotaciones: null, fotoDespues: null, nota: '' });
      });
    var reps = [
      { ordenId: o1, tipo: 'repuesto', nombre: 'Pastillas de freno del.', cantidad: 1, costo: 850 },
      { ordenId: o1, tipo: 'repuesto', nombre: 'Bujes de estabilizadora', cantidad: 4, costo: 95 },
      { ordenId: o1, tipo: 'mano', nombre: 'Cambio de pastillas', cantidad: 1.5, costo: 300 },
      { ordenId: o1, tipo: 'mano', nombre: 'Revisión de suspensión', cantidad: 1, costo: 300 },
      { ordenId: o2, tipo: 'repuesto', nombre: 'Aceite 10W40', cantidad: 1, costo: 380 },
      { ordenId: o2, tipo: 'repuesto', nombre: 'Filtro de aceite', cantidad: 1, costo: 120 },
      { ordenId: o2, tipo: 'mano', nombre: 'Servicio de aceite', cantidad: 0.5, costo: 300 },
      { ordenId: o3, tipo: 'repuesto', nombre: 'Pastillas de freno', cantidad: 1, costo: 720 },
      { ordenId: o3, tipo: 'mano', nombre: 'Cambio de pastillas', cantidad: 2, costo: 270 }
    ];
    var inv = [
      { nombre: 'Aceite 10W40', stock: 8, stockMinimo: 4, costo: 380 },
      { nombre: 'Aceite 5W30', stock: 3, stockMinimo: 4, costo: 420 },
      { nombre: 'Filtro de aceite', stock: 12, stockMinimo: 5, costo: 120 },
      { nombre: 'Pastillas de freno del.', stock: 2, stockMinimo: 3, costo: 850 },
      { nombre: 'Pastillas de freno tras.', stock: 6, stockMinimo: 3, costo: 780 },
      { nombre: 'Batería 12V', stock: 4, stockMinimo: 2, costo: 1450 },
      { nombre: 'Bujías (juego)', stock: 9, stockMinimo: 4, costo: 260 },
      { nombre: 'Anticongelante', stock: 2, stockMinimo: 3, costo: 190 }
    ];
    var rems = [
      { titulo: 'Llamar a Juan Pérez: repuestos llegan el viernes', fecha: now + 2 * dia, hecho: 0, creado: now },
      { titulo: 'Pedir pastillas a proveedor (stock bajo)', fecha: now + 1 * dia, hecho: 0, creado: now }
    ];

    return db.transaction('rw', [db.clientes, db.vehiculos, db.ordenes, db.checklistItems, db.repuestos, db.inventario, db.recordatorios], function () {
      return Promise.all([
        db.clientes.bulkAdd(cli),
        db.vehiculos.bulkAdd(veh),
        db.ordenes.bulkAdd(ord),
        db.checklistItems.bulkAdd(items),
        db.repuestos.bulkAdd(reps),
        db.inventario.bulkAdd(inv),
        db.recordatorios.bulkAdd(rems)
      ]);
    });
  });
};

A.wipeTotal = function () {
  A.swal(A.t('gen.cargando'));
  var db = A.db;
  var stores = ['clientes', 'vehiculos', 'ordenes', 'checklistItems', 'repuestos', 'plantillas', 'inventario', 'recordatorios', 'config'];
  return db.transaction('rw', stores.map(function (s) { return db[s]; }), function () {
    return Promise.all(stores.map(function (s) { return db[s].clear(); }));
  }).then(function () {
    A.cfg = {};
    return A.seed();
  }).then(function () {
    return A.loadCfg();
  }).then(function () {
    A.swalClose();
    A.toast(A.t('aj.borradoOk'), 'ok');
    A.desbloqueado = false;
    A.lockInit('crear');
    A.ir('#/lock');
  }).catch(function (e) {
    A.swalClose();
    A.toast(A.t('gen.error'), 'err');
  });
};
