/* AUTOSCAN · clients.js — clientes, vehículos e historial de órdenes */
var A = window.A || {};

/* util: mapa de clientes/vehículos para listas */
A._mapas = function () {
  return Promise.all([A.db.clientes.toArray(), A.db.vehiculos.toArray()]).then(function (r) {
    var mc = {}, mv = {};
    r[0].forEach(function (c) { mc[c.id] = c; });
    r[1].forEach(function (v) { mv[v.id] = v; });
    return { cli: mc, veh: mv };
  });
};

/* ================= CLIENTES (lista) ================= */
A.regVista('clientes', function () {
  var q = document.getElementById('cli-q');
  q.oninput = function () { A.cliLista(q.value); };
  A.cliLista('');
});

A.cliLista = function (texto) {
  A.db.clientes.toArray().then(function (lista) {
    var t = (texto || '').toLowerCase().trim();
    var res = lista.filter(function (c) {
      if (!t) return true;
      return (c.nombre || '').toLowerCase().indexOf(t) >= 0 || (c.telefono || '').toLowerCase().indexOf(t) >= 0;
    }).sort(function (a, b) { return (b.creado || 0) - (a.creado || 0); });
    var box = document.getElementById('cli-list');
    if (!res.length) { box.innerHTML = A.emptyState('users', A.t('cli.sinClientes')); return; }
    box.innerHTML = res.map(function (c) {
      return '<div class="card" data-cli="' + c.id + '">' +
        (c.foto ? '<img class="thumb" src="' + c.foto + '">' : '<span class="thumb ph">' + A.icon('user', 'sm') + '</span>') +
        '<div class="c-main"><div class="c-t">' + A.esc(c.nombre) + '</div>' +
        '<div class="c-s">' + A.esc(c.telefono || (c.email || '')) + '</div></div>' +
        '<div class="c-r"><span class="chip dim">' + A.vehCountCache(c.id) + '</span>' + A.icon('right') + '</div>' +
        '</div>';
    }).join('');
  });
};

/* contador de vehículos por cliente (cache ligero) */
A._vehCounts = {};
A.vehCountCache = function (clienteId) {
  var n = A._vehCounts[clienteId];
  return n === undefined ? '—' : (n + ' veh');
};
A.refrescarVehCounts = function () {
  return A.db.vehiculos.toArray().then(function (vs) {
    A._vehCounts = {};
    vs.forEach(function (v) { A._vehCounts[v.clienteId] = (A._vehCounts[v.clienteId] || 0) + 1; });
  });
};

document.getElementById('cli-add').addEventListener('click', function () { A.formCliente(null); });
document.getElementById('v-clientes').addEventListener('click', function (e) {
  var card = e.target.closest('[data-cli]');
  if (card) {
    A.refrescarVehCounts().then(function () { A.ir('#/cliente/' + card.getAttribute('data-cli')); });
  }
});

/* ================= FICHA CLIENTE ================= */
A.regVista('cliente', function (id) {
  var idn = parseInt(id, 10);
  A.refrescarVehCounts().then(function () {
    A.db.clientes.get(idn).then(function (c) {
      if (!c) { A.ir('#/clientes'); return; }
      document.getElementById('cli-ficha-title').textContent = c.nombre;
      A.fichaRender(c);
    });
  });
});

A.fichaRender = function (c) {
  var box = document.getElementById('cli-ficha');
  var db = A.db;
  db.vehiculos.where('clienteId').equals(c.id).toArray().then(function (vehs) {
    db.ordenes.where('clienteId').equals(c.id).toArray().then(function (ords) {
      ords.sort(function (a, b) { return (b.fechaEntrada || 0) - (a.fechaEntrada || 0); });
      box.innerHTML =
        '<div class="panel hud">' +
          '<div class="frow">' +
            (c.foto ? '<img class="thumb" style="width:72px;height:72px" src="' + c.foto + '">' : '<span class="thumb ph" style="width:72px;height:72px">' + A.icon('user') + '</span>') +
            '<div class="grow">' +
              '<div style="font-size:20px;font-weight:700">' + A.esc(c.nombre) + '</div>' +
              (c.telefono ? '<div class="mono" style="color:var(--accent-2);font-size:12px">' + A.icon('phone', 'sm') + ' ' + A.esc(c.telefono) + '</div>' : '') +
              (c.email ? '<div class="c-s">' + A.esc(c.email) + '</div>' : '') +
              (c.notas ? '<div class="hint">' + A.esc(c.notas) + '</div>' : '') +
              '<div class="hint">' + A.t('cli.desde') + ' ' + A.fmt.fecha(c.creado) + '</div>' +
            '</div>' +
          '</div>' +
          '<div class="row-btns">' +
            '<button class="chip-btn" data-edit-cli="' + c.id + '">' + A.icon('edit', 'sm') + A.t('gen.editar') + '</button>' +
            '<button class="chip-btn on-x" data-del-cli="' + c.id + '">' + A.icon('trash', 'sm') + A.t('gen.eliminar') + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="panel hud"><div class="panel-h">' + A.icon('car') + '<span>' + A.t('cli.vehiculosDe') + '</span><span class="grow"></span>' +
          '<button class="chip-btn" data-add-veh="' + c.id + '">' + A.icon('plus', 'sm') + A.t('cli.agregarVeh') + '</button></div>' +
          (vehs.length ? vehs.map(A.vehCard).join('') : A.emptyState('car', A.t('cli.sinVeh'))) +
        '</div>' +
        '<div class="panel hud"><div class="panel-h">' + A.icon('clipboard') + '<span>' + A.t('cli.ordDe') + '</span></div>' +
          (ords.length ? ords.map(A.ordMini).join('') : A.emptyState('clipboard', A.t('hist.sinRes'))) +
        '</div>';
    });
  });
};

A.vehCard = function (v) {
  return '<div class="card" data-veh="' + v.id + '">' +
    '<span class="thumb ph" style="width:48px;height:48px">' + A.icon('car') + '</span>' +
    '<div class="c-main">' +
      '<div class="c-t mono" style="color:var(--accent);letter-spacing:.06em">' + A.esc(v.placa || '—') + '</div>' +
      '<div class="c-s">' + A.esc((v.marca || '') + ' ' + (v.modelo || '') + ' ' + (v.anio || '')) + '</div>' +
    '</div>' +
    '<div class="c-r"><button class="chip-btn" data-ord-veh="' + v.id + '">' + A.icon('scan', 'sm') + A.t('cli.neword') + '</button></div>' +
    '<button class="icon-btn" data-edit-veh="' + v.id + '">' + A.icon('edit') + '</button>' +
    '<button class="icon-btn" data-del-veh="' + v.id + '">' + A.icon('trash') + '</button>' +
    '</div>';
};

A.ordMini = function (o) {
  var ei = A.estInfo(o.estado);
  return '<div class="card" data-ord="' + o.id + '">' +
    '<span class="thumb ph">' + A.icon('clipboard') + '</span>' +
    '<div class="c-main"><div class="c-t mono">#' + o.id + ' · ' + A.esc(o.motivo || '').slice(0, 40) + '</div>' +
    '<div class="c-s">' + A.fmt.fechaHora(o.fechaEntrada) + '</div></div>' +
    '<div class="c-r"><span class="chip ' + ei.cls + '">' + ei.t + '</span>' +
    '<span class="mono" style="color:var(--accent);font-size:13px">' + A.fmt.dinero(o.presupuestoTotal || 0) + '</span></div>' +
    '</div>';
};

/* eventos de la ficha */
document.getElementById('v-cliente').addEventListener('click', function (e) {
  var t = e.target;
  var x;
  if ((x = t.closest('[data-edit-cli]'))) {
    A.db.clientes.get(parseInt(x.getAttribute('data-edit-cli'), 10)).then(function (c) { A.formCliente(c); });
    return;
  }
  if ((x = t.closest('[data-del-cli]'))) {
    A.confirmar(A.t('gen.eliminar'), A.t('cli.eliminarQ')).then(function (ok) {
      if (!ok) return;
      var id = parseInt(x.getAttribute('data-del-cli'), 10);
      A.borrarClienteCascade(id).then(function () {
        A.toast(A.t('gen.borradoOk'), 'ok');
        A.ir('#/clientes');
      });
    });
    return;
  }
  if ((x = t.closest('[data-add-veh]'))) {
    A.formVehiculo(parseInt(x.getAttribute('data-add-veh'), 10), null);
    return;
  }
  if ((x = t.closest('[data-edit-veh]'))) {
    A.db.vehiculos.get(parseInt(x.getAttribute('data-edit-veh'), 10)).then(function (v) { A.formVehiculo(v.clienteId, v); });
    return;
  }
  if ((x = t.closest('[data-del-veh]'))) {
    A.confirmar(A.t('gen.eliminar'), A.t('veh.eliminarQ')).then(function (ok) {
      if (!ok) return;
      A.borrarVehiculoCascade(parseInt(x.getAttribute('data-del-veh'), 10)).then(function () {
        A.toast(A.t('gen.borradoOk'), 'ok');
        A.refrescarVehCounts();
        A.ruta();
      });
    });
    return;
  }
  if ((x = t.closest('[data-ord-veh]'))) {
    A.db.vehiculos.get(parseInt(x.getAttribute('data-ord-veh'), 10)).then(function (v) {
      A.recPrefill = { clienteId: v.clienteId, vehiculoId: v.id };
      A.ir('#/recepcion');
    });
    return;
  }
  if ((x = t.closest('[data-ord]'))) {
    A.ir('#/orden/' + x.getAttribute('data-ord'));
    return;
  }
  if (t.closest('#cli-ficha-neword')) {
    var m = location.hash.match(/cliente\/(\d+)/);
    if (m) A.recPrefill = { clienteId: parseInt(m[1], 10) };
    A.ir('#/recepcion');
    return;
  }
});

A.borrarClienteCascade = function (clienteId) {
  var db = A.db;
  return db.vehiculos.where('clienteId').equals(clienteId).toArray().then(function (vehs) {
    var ids = vehs.map(function (v) { return v.id; });
    var proms = ids.map(function (vid) { return A.borrarVehiculoCascade(vid, true); });
    return Promise.all(proms).then(function () {
      return db.ordenes.where('clienteId').equals(clienteId).toArray();
    });
  }).then(function (ords) {
    return Promise.all(ords.map(function (o) { return A.borrarOrdenInner(o.id); }));
  }).then(function () {
    return db.clientes.delete(clienteId);
  });
};

A.borrarVehiculoCascade = function (vehiculoId, silent) {
  var db = A.db;
  return db.ordenes.where('vehiculoId').equals(vehiculoId).toArray().then(function (ords) {
    return Promise.all(ords.map(function (o) { return A.borrarOrdenInner(o.id); }));
  }).then(function () {
    return db.vehiculos.delete(vehiculoId);
  });
};

A.borrarOrdenInner = function (ordenId) {
  var db = A.db;
  return Promise.all([
    db.checklistItems.where('ordenId').equals(ordenId).delete(),
    db.repuestos.where('ordenId').equals(ordenId).delete()
  ]).then(function () {
    return db.ordenes.delete(ordenId);
  });
};

/* ================= FORMULARIOS ================= */
A.formCliente = function (c) {
  c = c || {};
  var foto = c.foto || null;
  A.modal(c.id ? A.t('cli.editarT') : A.t('cli.nuevo'),
    '<div class="frow">' +
      '<div class="avatar-pick" id="fc-foto">' + (foto ? '<img src="' + foto + '">' : A.icon('camera')) + '</div>' +
      '<div class="grow">' +
        '<label class="field"><span>' + A.t('cli.nombre') + '</span><input id="fc-nombre" value="' + A.esc(c.nombre || '') + '" autocomplete="off"></label>' +
        '<label class="field"><span>' + A.t('cli.tel') + '</span><input id="fc-tel" inputmode="tel" value="' + A.esc(c.telefono || '') + '" autocomplete="off"></label>' +
        '<label class="field"><span>' + A.t('cli.mail') + '</span><input id="fc-mail" inputmode="email" value="' + A.esc(c.email || '') + '" autocomplete="off"></label>' +
        '<label class="field"><span>' + A.t('cli.notas') + '</span><input id="fc-notas" value="' + A.esc(c.notas || '') + '" autocomplete="off"></label>' +
      '</div>' +
    '</div>' +
    '<button class="btn-primary" id="fc-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
    {
      onOpen: function () {
        document.getElementById('fc-foto').onclick = function () {
          A.pedirFoto({
            maxW: 400, q: 0.8, sinMarca: true,
            onFoto: function (d) {
              foto = d;
              document.getElementById('fc-foto').innerHTML = '<img src="' + d + '">';
            }
          });
        };
        document.getElementById('fc-ok').onclick = function () {
          var nombre = document.getElementById('fc-nombre').value.trim();
          var telEl = document.getElementById('fc-tel');
          if (!nombre) {
            document.getElementById('fc-nombre').classList.add('bad');
            A.toast(A.t('rec.faltaNombre'), 'err'); return;
          }
          var datos = {
            nombre: nombre,
            telefono: telEl.value.trim(),
            email: document.getElementById('fc-mail').value.trim(),
            notas: document.getElementById('fc-notas').value.trim(),
            foto: foto
          };
          var p;
          if (c.id) { datos.id = c.id; p = A.db.clientes.put(datos); }
          else { datos.creado = Date.now(); p = A.db.clientes.add(datos); }
          p.then(function () {
            A.cerrarModal();
            A.toast(A.t('gen.guardadoOk'), 'ok');
            A.sonido('success');
            if (location.hash.indexOf('/cliente/') >= 0) { A.ruta(); }
            else if (A.vistas.clientes) { A.cliLista(document.getElementById('cli-q').value); A.refrescarVehCounts(); }
            if (A._formClienteCb) { var cb = A._formClienteCb; A._formClienteCb = null; cb(datos); }
          }).catch(function (e) { A.toast(A.t('gen.error'), 'err'); });
        };
      }
    });
};

A.formVehiculo = function (clienteId, v, onSaved) {
  v = v || {};
  var comb = v.comb || 'gasolina';
  A.modal(v.id ? A.t('veh.editarT') : A.t('veh.nuevo'),
    '<div class="frow2">' +
      '<label class="field"><span>' + A.t('veh.marca') + '</span><input id="fv-marca" value="' + A.esc(v.marca || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.modelo') + '</span><input id="fv-modelo" value="' + A.esc(v.modelo || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.anio') + '</span><input id="fv-anio" inputmode="numeric" value="' + A.esc(v.anio || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.placa') + '</span><input id="fv-placa" style="text-transform:uppercase" value="' + A.esc(v.placa || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.vin') + '</span><input id="fv-vin" style="text-transform:uppercase" value="' + A.esc(v.vin || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.color') + '</span><input id="fv-color" value="' + A.esc(v.color || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.km') + '</span><input id="fv-km" inputmode="numeric" value="' + A.esc(v.km || '') + '"></label>' +
      '<label class="field"><span>' + A.t('veh.comb') + '</span><select id="fv-comb">' +
        ['gasolina', 'diesel', 'gnc', 'hibrido', 'electrico'].map(function (k) {
          return '<option value="' + k + '"' + (comb === k ? ' selected' : '') + '>' + A.t('veh.c_' + k) + '</option>';
        }).join('') +
      '</select></label>' +
    '</div>' +
    '<div class="adv-row"><button class="chip-btn adv" id="fv-ocr">' + A.icon('scan', 'sm') + A.esc(A.t('gen.ocrBtn')) + '</button>' +
    '<span class="hint">' + A.esc(A.t('gen.ocrHint')) + '</span></div>' +
    '<button class="btn-primary" id="fv-ok">' + A.esc(A.t('gen.guardar')) + '</button>',
    {
      onOpen: function () {
        document.getElementById('fv-ocr').onclick = function () { A.avanzadaModal('ocr'); };
        document.getElementById('fv-ok').onclick = function () {
          var marca = document.getElementById('fv-marca').value.trim();
          var modelo = document.getElementById('fv-modelo').value.trim();
          var placa = document.getElementById('fv-placa').value.trim().toUpperCase();
          if (!marca || !modelo) {
            document.getElementById('fv-marca').classList.toggle('bad', !marca);
            document.getElementById('fv-modelo').classList.toggle('bad', !modelo);
            A.toast(A.t('rec.faltaMarca'), 'err'); return;
          }
          if (!placa) { document.getElementById('fv-placa').classList.add('bad'); A.toast(A.t('rec.faltaPlaca'), 'err'); return; }
          var datos = {
            clienteId: clienteId,
            marca: marca, modelo: modelo, placa: placa,
            anio: document.getElementById('fv-anio').value.trim(),
            vin: document.getElementById('fv-vin').value.trim().toUpperCase(),
            color: document.getElementById('fv-color').value.trim(),
            km: document.getElementById('fv-km').value.trim(),
            comb: document.getElementById('fv-comb').value
          };
          var p = v.id ? (datos.id = v.id, A.db.vehiculos.put(datos)) : A.db.vehiculos.add(datos);
          p.then(function () {
            A.cerrarModal();
            A.toast(A.t('gen.guardadoOk'), 'ok');
            A.sonido('success');
            A.refrescarVehCounts();
            if (location.hash.indexOf('/cliente/') >= 0) A.ruta();
            if (onSaved) onSaved(datos);
          }).catch(function () { A.toast(A.t('gen.error'), 'err'); });
        };
      }
    });
};

/* Fase avanzada: modal informativo */
A.avanzadaModal = function (tipo) {
  var txt = {
    ocr: ['OCR de VIN / placa (Tesseract.js)', 'Pertenece a la FASE AVANZADA del plan. Por ahora: ingresa el VIN manualmente o dicta con el micrófono del teclado (Gboard). La guía de integración está en docs/FASE-AVANZADA.txt.'],
    barcode: ['Lector de código de barras', 'Pertenece a la FASE AVANZADA (requiere bridge nativo). Por ahora: escribe el código del repuesto manualmente.'],
    notif: ['Notificaciones nativas', 'Pertenece a la FASE AVANZADA (requiere bridge nativo). Por ahora usa la lista de recordatorios del panel principal.'],
    bio: ['Biometría (huella)', 'Pertenece a la FASE AVANZADA (requiere bridge nativo). Por ahora el PIN local con hash SHA-256.'],
    widget: ['Widget de Android', 'Pertenece a la FASE AVANZADA (requiere bridge nativo).'],
    print: ['Impresora térmica Bluetooth', 'Pertenece a la FASE AVANZADA (requiere bridge nativo). El PDF es el sustituto 100% offline.']
  }[tipo] || ['Fase avanzada', '—'];
  A.modal(txt[0], '<div class="hint" style="font-size:14px">' + A.esc(txt[1]) + '</div>' +
    '<button class="btn-primary" onclick="A.cerrarModal()">' + A.esc(A.t('gen.aceptar2')) + '</button>');
};

/* ================= VEHICULOS (lista global) ================= */
A.regVista('vehiculos', function () {
  var q = document.getElementById('veh-q');
  q.oninput = function () { A.vehLista(q.value); };
  A.vehLista('');
  A.refrescarVehCounts();
});

A.vehLista = function (texto) {
  A._mapas().then(function (M) {
    var vs = Object.keys(M.veh).map(function (k) { return M.veh[k]; });
    var t = (texto || '').toLowerCase().trim();
    var res = vs.filter(function (v) {
      if (!t) return true;
      var dueno = M.cli[v.clienteId];
      return (v.placa || '').toLowerCase().indexOf(t) >= 0 ||
        (v.marca + ' ' + v.modelo).toLowerCase().indexOf(t) >= 0 ||
        (dueno && dueno.nombre || '').toLowerCase().indexOf(t) >= 0;
    });
    var box = document.getElementById('veh-list');
    if (!res.length) { box.innerHTML = A.emptyState('car', A.t('veh.sinVeh')); return; }
    res.sort(function (a, b) { return (a.placa || '').localeCompare(b.placa || ''); });
    box.innerHTML = res.map(function (v) {
      var dueno = M.cli[v.clienteId];
      return '<div class="card" data-vehgo="' + v.clienteId + '">' +
        '<span class="thumb ph">' + A.icon('car') + '</span>' +
        '<div class="c-main"><div class="c-t mono" style="color:var(--accent);letter-spacing:.06em">' + A.esc(v.placa || '—') + '</div>' +
        '<div class="c-s">' + A.esc((v.marca || '') + ' ' + (v.modelo || '') + ' ' + (v.anio || '')) + '</div>' +
        '<div class="c-s">' + A.esc(dueno ? dueno.nombre : '—') + '</div></div>' +
        '<div class="c-r"><span class="chip dim">' + A.t('veh.c_' + (v.comb || 'gasolina')) + '</span></div>' +
        '</div>';
    }).join('');
  });
};

document.getElementById('veh-add').addEventListener('click', function () {
  A.db.clientes.toArray().then(function (cli) {
    if (!cli.length) { A.toast(A.t('rec.faltaCliente'), 'err'); A.formCliente(null); return; }
    A.modal(A.t('veh.dueno'), 
      '<div class="searchbar">' + A.icon('search') + '<input id="fv-q" placeholder="' + A.esc(A.t('gen.buscarCli')) + '"></div>' +
      '<div id="fv-list" class="mini-list" style="max-height:46vh;overflow-y:auto"></div>' +
      '<button class="btn ghost" id="fv-newcli">' + A.icon('plus', 'sm') + A.esc(A.t('rec.nuevoCli')) + '</button>',
      {
        onOpen: function () {
          var paint = function (t) {
            var res = cli.filter(function (c) { return (c.nombre || '').toLowerCase().indexOf((t || '').toLowerCase()) >= 0; });
            document.getElementById('fv-list').innerHTML = res.map(function (c) {
              return '<div class="mini-item" style="cursor:pointer" data-pick="' + c.id + '">' + A.icon('user') +
                '<span class="grow">' + A.esc(c.nombre) + '</span>' + A.icon('right') + '</div>';
            }).join('') || A.emptyState('user', A.t('cli.sinClientes'));
          };
          paint('');
          document.getElementById('fv-q').oninput = function () { paint(this.value); };
          document.getElementById('modal-body').onclick = function (e) {
            var p = e.target.closest('[data-pick]');
            if (p) {
              A.cerrarModal();
              setTimeout(function () { A.formVehiculo(parseInt(p.getAttribute('data-pick'), 10), null); }, 120);
              return;
            }
            if (e.target.closest('#fv-newcli')) {
              A.cerrarModal();
              setTimeout(function () {
                A.formCliente(null);
                A._formClienteCb = function (datos) {
                  setTimeout(function () { A.formVehiculo(datos.id, null); }, 150);
                };
              }, 120);
            }
          };
        }
      });
  });
});

document.getElementById('v-vehiculos').addEventListener('click', function (e) {
  var card = e.target.closest('[data-vehgo]');
  if (card) A.ir('#/cliente/' + card.getAttribute('data-vehgo'));
});

/* ================= HISTORIAL (órdenes) ================= */
A.regVista('historial', function () {
  var sel = document.getElementById('his-estado');
  if (!sel.dataset.ok) {
    sel.innerHTML = '<option value="">' + A.esc(A.t('hist.todas')) + '</option>' +
      A.ESTADOS.map(function (e) { return '<option value="' + e + '">' + A.estInfo(e).t + '</option>'; }).join('');
    sel.dataset.ok = '1';
    sel.onchange = function () { A.hisLista(); };
    document.getElementById('his-desde').onchange = A.hisLista;
    document.getElementById('his-hasta').onchange = A.hisLista;
    document.getElementById('his-clear').onclick = function () {
      sel.value = ''; document.getElementById('his-desde').value = ''; document.getElementById('his-hasta').value = '';
      document.getElementById('his-q').value = '';
      A.hisLista();
    };
    document.getElementById('his-q').oninput = function () { A.hisLista(); };
  } else {
    sel.innerHTML = '<option value="">' + A.esc(A.t('hist.todas')) + '</option>' +
      A.ESTADOS.map(function (e) { return '<option value="' + e + '">' + A.estInfo(e).t + '</option>'; }).join('');
    var keep = sel.value; sel.value = keep;
  }
  A.hisLista();
});

A.hisLista = function () {
  var q = (document.getElementById('his-q').value || '').toLowerCase().trim();
  var estado = document.getElementById('his-estado').value;
  var desde = document.getElementById('his-desde').value ? new Date(document.getElementById('his-desde').value + 'T00:00:00').getTime() : null;
  var hasta = document.getElementById('his-hasta').value ? new Date(document.getElementById('his-hasta').value + 'T23:59:59').getTime() : null;
  A._mapas().then(function (M) {
    A.db.ordenes.toArray().then(function (ords) {
      var res = ords.filter(function (o) {
        var v = M.veh[o.vehiculoId], c = M.cli[o.clienteId];
        if (estado && o.estado !== estado) return false;
        if (desde && (o.fechaEntrada || 0) < desde) return false;
        if (hasta && (o.fechaEntrada || 0) > hasta) return false;
        if (q) {
          var hay = (v && v.placa || '').toLowerCase().indexOf(q) >= 0 ||
            (o.motivo || '').toLowerCase().indexOf(q) >= 0 ||
            (c && c.nombre || '').toLowerCase().indexOf(q) >= 0 ||
            (v && (v.marca + ' ' + v.modelo) || '').toLowerCase().indexOf(q) >= 0;
          if (!hay) return false;
        }
        return true;
      }).sort(function (a, b) { return (b.fechaEntrada || 0) - (a.fechaEntrada || 0); });
      var box = document.getElementById('his-list');
      if (!res.length) { box.innerHTML = A.emptyState('clipboard', A.t('hist.sinRes')); return; }
      box.innerHTML = res.map(function (o) {
        var v = M.veh[o.vehiculoId], c = M.cli[o.clienteId];
        var ei = A.estInfo(o.estado);
        return '<div class="card" data-ord="' + o.id + '">' +
          '<span class="thumb ph">' + A.icon('clipboard') + '</span>' +
          '<div class="c-main"><div class="c-t mono" style="color:var(--accent);letter-spacing:.06em">' +
            A.esc(v ? v.placa : '—') + ' <span style="color:var(--dim);font-weight:500">· ' + A.esc(c ? c.nombre : '—') + '</span></div>' +
          '<div class="c-s">' + A.esc(o.motivo || '').slice(0, 46) + '</div>' +
          '<div class="c-s">' + A.fmt.fechaHora(o.fechaEntrada) + (o.tecnico ? ' · ' + A.esc(o.tecnico) : '') + '</div></div>' +
          '<div class="c-r"><span class="chip ' + ei.cls + '">' + ei.t + '</span>' +
          '<span class="mono" style="color:var(--accent);font-size:13px">' + A.fmt.dinero(o.presupuestoTotal || 0) + '</span></div>' +
          '</div>';
      }).join('');
    });
  });
};

document.getElementById('v-historial').addEventListener('click', function (e) {
  var card = e.target.closest('[data-ord]');
  if (card) A.ir('#/orden/' + card.getAttribute('data-ord'));
});
