/* AUTOSCAN v2 · app.js — boot, splash, lock v2, router, dashboard v2, partículas */
var A = window.A || {};

A.VERSION = '2.0.0';
A.desbloqueado = false;
A.vistas = {};
A.regVista = function (n, fn) { A.vistas[n] = fn; };

/* ================= ROUTER ================= */
A.ir = function (h) {
  if (location.hash === h) { A.ruta(); }
  else { location.hash = h; }
};
A.ruta = function () {
  var h = location.hash || '#/dashboard';
  var parts = h.replace(/^#\//, '').split('/');
  var name = parts[0] || 'dashboard';
  var param = parts[1] ? decodeURIComponent(parts[1]) : null;

  if (!A.desbloqueado && name !== 'lock') { location.replace('#/lock'); return; }
  if (name === 'lock' && A.desbloqueado) { location.replace('#/dashboard'); return; }

  var sec = document.getElementById('v-' + name);
  if (!sec) { location.replace('#/dashboard'); return; }

  A.$$('.view').forEach(function (v) { v.hidden = true; });
  sec.hidden = false;
  var body = sec.querySelector('.view-body');
  if (body) body.scrollTop = 0;

  /* nav inferior visible salvo lock y recepción */
  var sinNav = ['lock', 'recepcion'].indexOf(name) >= 0 || !A.desbloqueado;
  document.getElementById('bnav').hidden = !!sinNav;
  A.$$('#bnav button').forEach(function (b) {
    b.classList.toggle('on', b.getAttribute('data-nav') === name);
  });
  if (A.desbloqueado) { A.sonido('click'); A.vibrar(10); }
  if (A.vistas[name]) { A.vistas[name](param); }
};

/* ================= BOOT ================= */
A.app = {
  boot: function () {
    A.cargarPrefs();
    A.applyTheme();
    A.applyI18n();
    A.swRegister();
    A.splash.start();
    var self = this;
    this._prog(12, A.t('splash.db'), 150)
      .then(function () { return A.db.open(); })
      .then(function () { return self._prog(38, A.t('splash.cfg'), 260); })
      .then(function () { return A.seed(); })
      .then(function () { return A.loadCfg(); })
      .then(function () { return self._prog(72, A.t('splash.tpl'), 240); })
      .then(function () { return self._prog(100, A.t('splash.ui'), 320); })
      .then(function () { A.splash.done(); })
      .catch(function (e) {
        console.error(e);
        A.splash.done();
        A.toast(A.t('gen.error'), 'err');
      });
  },

  _prog: function (pct, msg, ms) {
    return new Promise(function (res) {
      document.getElementById('splash-fill').style.width = pct + '%';
      document.getElementById('splash-msg').textContent = msg;
      setTimeout(res, ms || 200);
    });
  },

  /* decide la primera pantalla según el PIN (v2: interruptor pinActivo) */
  entrar: function () {
    A.bgFx.start();
    var hasHash = !!A.getCfg('pinHash', null);
    if (hasHash && A.pinActivo()) { A.lockInit('entrar'); A.ir('#/lock'); }
    else if (!hasHash && !A.getCfg('pinSalt', null)) { A.lockInit('crear'); A.ir('#/lock'); }
    else { A.desbloqueado = true; A.ir('#/dashboard'); }
  }
};

/* ================= SERVICE WORKER (PWA offline, opcional) ================= */
A.swRegister = function () {
  try {
    if ('serviceWorker' in navigator &&
        (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    }
  } catch (e) {}
};

/* ================= PARTÍCULAS DE FONDO (v2) ================= */
A.bgFx = {
  _raf: null, _parts: [], _rgb: '255,176,32',
  setColor: function () {
    this._rgb = A.rgbAcento ? A.rgbAcento() : '255,176,32';
  },
  start: function () {
    var cv = document.getElementById('bg-fx');
    if (!cv) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (this._raf) return;
    var self = this;
    var ctx = cv.getContext('2d');
    function fit() {
      cv.width = window.innerWidth;
      cv.height = window.innerHeight;
    }
    fit();
    window.addEventListener('resize', fit);
    this.setColor();
    this._parts = [];
    var N = Math.min(30, Math.max(14, Math.round(window.innerWidth / 22)));
    for (var i = 0; i < N; i++) {
      this._parts.push({
        x: Math.random() * cv.width, y: Math.random() * cv.height,
        vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
        r: Math.random() * 1.6 + 0.5
      });
    }
    function tick() {
      if (!A.prefs || !A.prefs.particulas) { self.stop(); return; }
      ctx.clearRect(0, 0, cv.width, cv.height);
      var rgb = self._rgb, ps = self._parts;
      for (var i = 0; i < ps.length; i++) {
        var p = ps[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x += cv.width; if (p.x > cv.width) p.x -= cv.width;
        if (p.y < 0) p.y += cv.height; if (p.y > cv.height) p.y -= cv.height;
        ctx.beginPath();
        ctx.fillStyle = 'rgba(' + rgb + ',0.4)';
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      for (var a = 0; a < ps.length; a++) {
        for (var b = a + 1; b < ps.length; b++) {
          var dx = ps[a].x - ps[b].x, dy = ps[a].y - ps[b].y;
          var d2 = dx * dx + dy * dy;
          if (d2 < 15000) {
            ctx.strokeStyle = 'rgba(' + rgb + ',' + (0.07 * (1 - d2 / 15000)).toFixed(3) + ')';
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(ps[a].x, ps[a].y);
            ctx.lineTo(ps[b].x, ps[b].y);
            ctx.stroke();
          }
        }
      }
      self._raf = requestAnimationFrame(tick);
    }
    this._raf = requestAnimationFrame(tick);
  },
  stop: function () {
    if (this._raf) { cancelAnimationFrame(this._raf); this._raf = null; }
    var cv = document.getElementById('bg-fx');
    if (cv) cv.getContext('2d').clearRect(0, 0, cv.width, cv.height);
  },
  refresh: function () {
    if (A.prefs && A.prefs.particulas) this.start();
    else this.stop();
  }
};

/* ================= SPLASH ================= */
A.splash = {
  _raf: null,
  _parts: [],
  start: function () {
    var cv = document.getElementById('splash-cv');
    var ctx = cv.getContext('2d');
    var self = this;
    function fit() {
      cv.width = cv.clientWidth * (window.devicePixelRatio > 1 ? 1.5 : 1);
      cv.height = cv.clientHeight * (window.devicePixelRatio > 1 ? 1.5 : 1);
    }
    fit();
    window.addEventListener('resize', fit);
    this._parts = [];
    var W = cv.width, H = cv.height;
    for (var i = 0; i < 70; i++) {
      this._parts.push({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.8 + 0.6,
        c: Math.random() < 0.75 ? 'rgba(255,176,32,' : 'rgba(0,229,255,'
      });
    }
    function tick() {
      if (!document.getElementById('splash')) { cancelAnimationFrame(self._raf); return; }
      ctx.clearRect(0, 0, cv.width, cv.height);
      var ps = self._parts;
      for (var i = 0; i < ps.length; i++) {
        var p = ps[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x += cv.width; if (p.x > cv.width) p.x -= cv.width;
        if (p.y < 0) p.y += cv.height; if (p.y > cv.height) p.y -= cv.height;
        ctx.beginPath();
        ctx.fillStyle = p.c + '0.55)';
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      for (var a = 0; a < ps.length; a++) {
        for (var b = a + 1; b < ps.length; b++) {
          var dx = ps[a].x - ps[b].x, dy = ps[a].y - ps[b].y;
          var d2 = dx * dx + dy * dy;
          if (d2 < 12000) {
            ctx.strokeStyle = 'rgba(255,176,32,' + (0.10 * (1 - d2 / 12000)).toFixed(3) + ')';
            ctx.lineWidth = 0.6;
            ctx.beginPath();
            ctx.moveTo(ps[a].x, ps[a].y);
            ctx.lineTo(ps[b].x, ps[b].y);
            ctx.stroke();
          }
        }
      }
      self._raf = requestAnimationFrame(tick);
    }
    this._raf = requestAnimationFrame(tick);
  },
  done: function () {
    var sp = document.getElementById('splash');
    if (!sp) { A.app.entrar(); return; }
    sp.style.transition = 'opacity .5s';
    sp.style.opacity = '0';
    setTimeout(function () {
      cancelAnimationFrame(A.splash._raf);
      sp.remove();
      document.getElementById('app').hidden = false;
      A.app.entrar();
    }, 520);
  }
};

/* ================= LOCK v2 (solo PIN + opciones debajo) ================= */
A.lockInit = function (modo) {
  A._lock = { modo: modo, buf: '', tmp: '', intentos: 0 };
  var sub = document.getElementById('lock-sub');
  var err = document.getElementById('lock-err');
  sub.textContent = A.t(modo === 'crear' ? 'lock.crear' : (modo === 'confirmar' ? 'lock.confirmar' : 'lock.entrar'));
  err.textContent = '';
  A.lockDots('');
  document.getElementById('lock-ver').textContent = 'v' + A.VERSION;
  /* opciones: el enlace de recuperación solo tiene sentido si ya hay PIN guardado */
  document.getElementById('lock-forgot').hidden = !(modo === 'entrar' && A.getCfg('pinHash', null));
  var pad = document.getElementById('lock-pad');
  if (!pad.dataset.listo) {
    var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'blank', '0', 'del'];
    pad.innerHTML = keys.map(function (k) {
      if (k === 'blank') return '<button class="blank" disabled></button>';
      if (k === 'del') return '<button data-k="del">' + A.icon('x') + '</button>';
      return '<button data-k="' + k + '">' + k + '</button>';
    }).join('');
    pad.dataset.listo = '1';
    pad.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b || b.disabled) return;
      A.sonido('click'); A.vibrar(12);
      var k = b.getAttribute('data-k');
      A.lockKey(k);
    });
  }
};
A.lockKey = function (k) {
  var L = A._lock;
  if (!L) return;
  if (k === 'del') { L.buf = L.buf.slice(0, -1); A.lockDots(L.buf); return; }
  if (L.buf.length >= 4) return;
  document.getElementById('lock-err').textContent = ''; /* nueva tecla: limpia el error anterior */
  L.buf += k;
  A.lockDots(L.buf);
  if (L.buf.length === 4) setTimeout(A.lockPin4, 180);
};
A.lockDots = function (buf) {
  var dots = document.getElementById('lock-dots');
  A.$$('span', dots).forEach(function (s, i) {
    s.classList.toggle('fill', i < buf.length);
  });
};
/* teclado físico (prueba en navegador de PC) */
document.addEventListener('keydown', function (e) {
  var v = document.getElementById('v-lock');
  if (!v || v.hidden || !A._lock) return;
  if (/^[0-9]$/.test(e.key)) { A.lockKey(e.key); e.preventDefault(); }
  else if (e.key === 'Backspace') { A.lockKey('del'); e.preventDefault(); }
});

A.lockPin4 = function () {
  var L = A._lock;
  var err = document.getElementById('lock-err');
  var sub = document.getElementById('lock-sub');
  var dots = document.getElementById('lock-dots');

  if (L.modo === 'crear') {
    L.tmp = L.buf; L.buf = '';
    L.modo = 'confirmar';
    sub.textContent = A.t('lock.confirmar');
    A.lockDots('');
    return;
  }
  if (L.modo === 'confirmar') {
    if (L.tmp === L.buf) {
      A.guardarPinConActivo(L.buf).then(function () {
        A.toast(A.t('gen.guardadoOk'), 'ok');
        A.sonido('success');
        A.lockOfrecerPregunta();
      });
    } else {
      L.modo = 'crear'; L.buf = ''; L.tmp = '';
      sub.textContent = A.t('lock.crear');
      err.textContent = A.t('lock.noMatch');
      A.sonido('error'); A.vibrar([80, 40, 80]);
      dots.classList.add('shake');
      setTimeout(function () {
        dots.classList.remove('shake');
        A.$$('span', dots).forEach(function (s) { s.classList.remove('fill'); });
      }, 450);
    }
    return;
  }
  /* entrar */
  A.verificarPin(L.buf).then(function (ok) {
    if (ok) {
      A.sonido('success'); A.vibrar(30);
      A.unlock();
    } else {
      L.intentos = (L.intentos || 0) + 1;
      L.buf = '';
      err.textContent = A.t('lock.errPin');
      A.sonido('error'); A.vibrar([80, 40, 80]);
      dots.classList.add('shake');
      setTimeout(function () {
        dots.classList.remove('shake');
        A.$$('span', dots).forEach(function (s) { s.classList.remove('fill'); });
      }, 450);
    }
  });
};

/* tras crear el PIN por primera vez: ofrecer pregunta de seguridad (opcional) */
A.lockOfrecerPregunta = function () {
  if (A.tienePregunta()) { A.unlock(); return; }
  A.modal(A.t('lock.crearPregT'),
    '<div class="hint" style="margin-bottom:10px">' + A.esc(A.t('lock.crearPregSub')) + '</div>' +
    '<label class="field"><span>' + A.esc(A.t('lock.pregQ')) + '</span><input id="lp-q" autocomplete="off"></label>' +
    '<label class="field"><span>' + A.esc(A.t('lock.pregA')) + '</span><input id="lp-a" autocomplete="off"></label>' +
    '<label class="field"><span>' + A.esc(A.t('lock.pregA2')) + '</span><input id="lp-a2" autocomplete="off"></label>' +
    '<div class="row-btns" style="margin-top:8px">' +
    '<button class="btn ghost" id="lp-skip">' + A.esc(A.t('lock.omitir')) + '</button>' +
    '<button class="btn-primary" id="lp-ok">' + A.esc(A.t('lock.ahora')) + '</button></div>',
    {
      onClose: function () { if (!A.desbloqueado) A.unlock(); },
      onOpen: function () {
        document.getElementById('lp-skip').onclick = function () { A.cerrarModal(); A.unlock(); };
        document.getElementById('lp-ok').onclick = function () {
          var q = document.getElementById('lp-q').value.trim();
          var a = document.getElementById('lp-a').value.trim();
          var a2 = document.getElementById('lp-a2').value.trim();
          if (!q || !a) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
          if (a !== a2) { A.toast(A.t('lock.pregNoMatch'), 'err'); return; }
          A.guardarPregunta(q, a).then(function () {
            A.cerrarModal();
            A.toast(A.t('aj.pregGuardada'), 'ok');
            A.unlock();
          });
        };
      }
    });
};

/* ¿olvidaste tu PIN? → pregunta de seguridad o borrado (con aviso) */
A.lockForgot = function () {
  if (A.tienePregunta()) {
    A.modal(A.t('lock.pregT'),
      '<label class="field"><span>' + A.esc(A.getCfg('preguntaSeg')) + '</span><input id="lf-a" autocomplete="off" placeholder="' + A.esc(A.t('lock.pregPh')) + '"></label>' +
      '<button class="btn-primary" id="lf-ok">' + A.esc(A.t('gen.aceptar')) + '</button>',
      {
        onOpen: function () {
          document.getElementById('lf-a').focus();
          document.getElementById('lf-ok').onclick = function () {
            var r = document.getElementById('lf-a').value;
            A.verificarPregunta(r).then(function (ok) {
              if (ok) {
                A.cerrarModal();
                A.toast(A.t('lock.pregOk'), 'ok');
                A.sonido('success');
                A.unlock();
                setTimeout(function () { A.toast(A.t('lock.nuevoPinOk')); }, 1500);
              } else {
                A.toast(A.t('lock.pregBad'), 'err');
                A.sonido('error'); A.vibrar([80, 40, 80]);
              }
            });
          };
        }
      });
  } else {
    A.confirmar(A.t('lock.sinPregT'), A.t('lock.sinPreg'), A.t('lock.borrarTodo')).then(function (ok) {
      if (!ok) return;
      A.wipeTotal();
    });
  }
};

A.unlock = function () {
  A.desbloqueado = true;
  A._lock = null;
  A.ir('#/dashboard');
};

/* opciones del lock */
document.addEventListener('DOMContentLoaded', function () {
  var f = document.getElementById('lock-forgot');
  if (f) f.addEventListener('click', function () { A.sonido('click'); A.lockForgot(); });
  var lg = document.getElementById('lock-lang');
  if (lg) lg.addEventListener('click', function () {
    A.prefs.idioma = A.prefs.idioma === 'es' ? 'en' : 'es';
    A.guardarPrefs();
    A.applyI18n();
    if (A._lock) {
      var modo = A._lock.modo;
      A.lockInit(modo === 'confirmar' ? 'confirmar' : (modo === 'crear' ? 'crear' : 'entrar'));
    }
    A.toast(A.t('aj.guardadoOk'), 'ok');
  });
});

/* ================= DASHBOARD v2 ================= */
A.regVista('dashboard', function () {
  var db = A.db;
  document.getElementById('dash-taller').textContent = (A.getCfg('tallerNombre', '') || '—').toUpperCase();
  document.title = 'AUTOSCAN — ' + (A.getCfg('tallerNombre', '') || '');
  A.dashReloj();

  db.ordenes.toArray().then(function (ordenes) {
    db.recordatorios.toArray().then(function (rems) {
      db.inventario.toArray().then(function (inv) {
        db.checklistItems.toArray().then(function (items) {
          A.dashRender(ordenes, rems, inv, items);
        });
      });
    });
  });
});

/* reloj vivo en la barra superior */
A._relojInt = null;
A.dashReloj = function () {
  var pinta = function () {
    var hm = document.getElementById('dclock-hm');
    var fe = document.getElementById('dclock-fecha');
    if (!hm || !fe) return;
    var d = new Date();
    hm.textContent = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    fe.textContent = d.toLocaleDateString(A.prefs.idioma === 'en' ? 'en-US' : 'es-MX', { weekday: 'short', day: '2-digit', month: 'short' }).toUpperCase();
  };
  pinta();
  if (!A._relojInt) A._relojInt = setInterval(pinta, 30000);
};

A.dashRender = function (ordenes, rems, inv, items) {
  /* --- banners contextuales (v2) --- */
  var banners = document.getElementById('dash-banners');
  var htmlB = '';
  var qsOff = localStorage.getItem('as_noway') === '1';
  if (!ordenes.length && !qsOff) {
    htmlB += '<div class="banner" id="bn-qs">' +
      '<div class="b-ic">' + A.icon('book') + '</div>' +
      '<div class="grow"><div class="b-t">' + A.esc(A.t('dash.qsT')) + '</div>' +
      '<div class="b-s">' + A.esc(A.t('dash.qsSub')) + '</div>' +
      '<div class="b-btns">' +
      '<button class="chip-btn" data-bn="manual">' + A.icon('book', 'sm') + A.esc(A.t('dash.verManual')) + '</button>' +
      '<button class="chip-btn" data-bn="demo">' + A.icon('play', 'sm') + A.esc(A.t('dash.cargarDemo')) + '</button>' +
      '<button class="chip-btn" data-bn="new">' + A.icon('scan', 'sm') + A.esc(A.t('dash.nueva')) + '</button>' +
      '</div></div>' +
      '<button class="b-x" data-bn="cerrarQs">' + A.icon('x') + '</button></div>';
  } else if (ordenes.length) {
    var lb = A.getCfg('lastBackup', null);
    if (!lb || (Date.now() - lb) > 7 * 86400000) {
      htmlB += '<div class="banner warn" id="bn-bk">' +
        '<div class="b-ic">' + A.icon('archive') + '</div>' +
        '<div class="grow"><div class="b-t">' + A.esc(A.t('dash.bkT')) + '</div>' +
        '<div class="b-s">' + A.esc(A.t('dash.bkSub')) + '</div>' +
        '<div class="b-btns"><button class="chip-btn" data-bn="bk">' + A.icon('down', 'sm') + A.esc(A.t('dash.bkAhora')) + '</button></div></div></div>';
    }
  }
  banners.innerHTML = htmlB;

  /* --- stats con contador animado --- */
  var hoy0 = A.hoy0();
  var now = new Date();
  var mesActual = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  var hoy = 0, proc = 0, listas = 0, ingresos = 0;
  ordenes.forEach(function (o) {
    if (o.fechaEntrada >= hoy0) hoy++;
    if (['recepcion', 'diagnostico', 'reparacion'].indexOf(o.estado) >= 0) proc++;
    if (o.estado === 'listo') listas++;
    if (o.estado === 'entregado' && (o.fechaSalida || o.fechaEntrada) >= mesActual) ingresos += o.presupuestoTotal || 0;
  });
  document.getElementById('dash-stats').innerHTML =
    '<div class="stat"><svg class="ic"><use href="#i-calendar"/></svg><b class="amber nUp" id="st-hoy">0</b><span>' + A.t('dash.hoy') + '</span></div>' +
    '<div class="stat"><svg class="ic"><use href="#i-wrench"/></svg><b class="cyan nUp" id="st-proc">0</b><span>' + A.t('dash.proceso') + '</span></div>' +
    '<div class="stat"><svg class="ic"><use href="#i-check"/></svg><b class="ok nUp" id="st-lis">0</b><span>' + A.t('dash.listas') + '</span></div>' +
    '<div class="stat"><svg class="ic"><use href="#i-money"/></svg><b class="amber nUp" id="st-ing">$ 0</b><span>' + A.t('dash.ingresos') + '</span></div>';
  A.countUp(document.getElementById('st-hoy'), hoy);
  A.countUp(document.getElementById('st-proc'), proc);
  A.countUp(document.getElementById('st-lis'), listas);
  A.countUp(document.getElementById('st-ing'), ingresos, function (v) { return A.fmt.dinero(Math.round(v)); });

  /* --- donut órdenes por estado (v2) --- */
  A.dashDonut(ordenes);

  /* --- recordatorios --- */
  var box = document.getElementById('dash-rem-list');
  var pend = rems.filter(function (r) { return !r.hecho; }).sort(function (a, b) { return (a.fecha || 9e15) - (b.fecha || 9e15); });
  if (!pend.length) {
    box.innerHTML = A.emptyState('clock', A.t('dash.sinRem'));
  } else {
    box.innerHTML = pend.map(function (r) {
      return '<div class="mini-item" data-id="' + r.id + '">' +
        A.icon('clock') +
        '<span class="grow">' + A.esc(r.titulo) + '</span>' +
        '<span class="chip info">' + (r.fecha ? A.fmt.fecha(r.fecha) : '—') + '</span>' +
        '<button class="icon-btn" data-done="' + r.id + '">' + A.icon('check') + '</button>' +
        '<button class="icon-btn" data-del="' + r.id + '">' + A.icon('trash') + '</button>' +
        '</div>';
    }).join('');
  }

  /* --- stock bajo --- */
  var sbox = document.getElementById('dash-stock-list');
  var bajo = inv.filter(function (i) { return (i.stock || 0) <= (i.stockMinimo || 0); });
  if (!bajo.length) {
    sbox.innerHTML = A.emptyState('box', A.t('dash.sinStock'));
  } else {
    sbox.innerHTML = bajo.map(function (i) {
      return '<div class="mini-item">' + A.icon('alert') +
        '<span class="grow">' + A.esc(i.nombre) + '</span>' +
        '<span class="chip crit">' + i.stock + ' / ' + i.stockMinimo + '</span></div>';
    }).join('');
  }

  /* --- gráfico ingresos 6 meses (entregadas) --- */
  var chart = document.getElementById('dash-chart');
  var months = [];
  var m = new Date();
  for (var i = 5; i >= 0; i--) {
    var d = new Date(m.getFullYear(), m.getMonth() - i, 1);
    months.push({ t: d.getTime(), label: d.toLocaleDateString(A.prefs.idioma === 'en' ? 'en-US' : 'es-MX', { month: 'short' }), v: 0 });
  }
  ordenes.forEach(function (o) {
    if (o.estado !== 'entregado') return;
    var ts = o.fechaSalida || o.fechaEntrada;
    if (!ts) return;
    months.forEach(function (mm) {
      if (ts >= mm.t && ts < mm.t + 32 * 86400000) mm.v += o.presupuestoTotal || 0;
    });
  });
  var max = Math.max.apply(null, months.map(function (x) { return x.v; }).concat([1]));
  chart.innerHTML = months.map(function (mm) {
    var pct = Math.max(4, Math.round(mm.v / max * 100));
    var lbl = mm.v >= 1000 ? '$' + (mm.v / 1000).toFixed(1) + 'k' : (mm.v ? '$' + Math.round(mm.v) : '');
    return '<div class="bcol' + (mm.v ? '' : ' zero') + '">' +
      '<b>' + lbl + '</b>' +
      '<div class="bar" style="height:' + pct + '%"></div>' +
      '<span>' + mm.label + '</span></div>';
  }).join('');

  /* --- fallas más detectadas (críticos) --- */
  var top = document.getElementById('dash-top');
  var counts = {};
  items.forEach(function (it) {
    if (it.estado !== 'crit') return;
    var k = it.cat + ' · ' + it.desc;
    counts[k] = (counts[k] || 0) + 1;
  });
  var arr = Object.keys(counts).map(function (k) { return { k: k, n: counts[k] }; })
    .sort(function (a, b) { return b.n - a.n; }).slice(0, 5);
  if (!arr.length) {
    top.innerHTML = A.emptyState('alert', A.t('dash.topEmpty'));
  } else {
    var mx = arr[0].n;
    top.innerHTML = arr.map(function (x) {
      return '<div class="trow"><span class="t-name">' + A.esc(x.k) + '</span>' +
        '<div class="t-bar"><div class="t-fill" style="width:' + Math.round(x.n / mx * 100) + '%"></div></div>' +
        '<span class="mono" style="color:var(--accent)">' + x.n + '</span></div>';
    }).join('');
  }
};

/* donut de estados (canvas, sin librerías) */
A.dashDonut = function (ordenes) {
  var cv = document.getElementById('dash-donut');
  var leg = document.getElementById('dash-leyenda');
  var tot = document.getElementById('dd-total');
  if (!cv || !leg) return;
  var colors = {
    recepcion: '#00E5FF', diagnostico: '#FBBF24', reparacion: '#FB923C',
    listo: '#22C55E', entregado: '#64748B'
  };
  var counts = {};
  A.ESTADOS.forEach(function (e) { counts[e] = 0; });
  ordenes.forEach(function (o) { if (counts[o.estado] !== undefined) counts[o.estado]++; });
  var n = ordenes.length;
  tot.textContent = n;

  /* leyenda */
  leg.innerHTML = A.ESTADOS.map(function (e) {
    var pct = n ? Math.round(counts[e] / n * 100) : 0;
    return '<div class="dleg"><i style="color:' + colors[e] + ';background:' + colors[e] + '"></i>' +
      '<span class="grow">' + A.estInfo(e).t + '</span>' +
      '<b class="mono">' + counts[e] + '</b><small class="mono">' + pct + '%</small></div>';
  }).join('');

  /* dibujo */
  var dpr = Math.min(2, window.devicePixelRatio || 1);
  var size = 132;
  cv.width = size * dpr; cv.height = size * dpr;
  var ctx = cv.getContext('2d');
  ctx.clearRect(0, 0, cv.width, cv.height);
  var cx = cv.width / 2, cy = cv.height / 2;
  var rOut = (size * dpr) / 2 - 4, rIn = rOut - 15 * dpr;
  if (!n) {
    ctx.beginPath();
    ctx.arc(cx, cy, (rOut + rIn) / 2, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(147,160,180,.2)';
    ctx.lineWidth = rOut - rIn;
    ctx.stroke();
    return;
  }
  var ang = -Math.PI / 2;
  A.ESTADOS.forEach(function (e) {
    if (!counts[e]) return;
    var frac = counts[e] / n;
    var a0 = ang, a1 = ang + frac * Math.PI * 2;
    ang = a1;
    ctx.beginPath();
    ctx.arc(cx, cy, (rOut + rIn) / 2, a0 + 0.02, a1 - 0.02);
    ctx.strokeStyle = colors[e];
    ctx.lineWidth = rOut - rIn;
    ctx.lineCap = 'butt';
    ctx.shadowColor = colors[e];
    ctx.shadowBlur = 6 * dpr;
    ctx.stroke();
    ctx.shadowBlur = 0;
  });
};

/* Recordatorios + banners + búsqueda (delegación en el panel) */
document.getElementById('v-dashboard').addEventListener('click', function (e) {
  var d = e.target.closest('[data-done]');
  if (d) {
    A.db.recordatorios.update(parseInt(d.getAttribute('data-done'), 10), { hecho: 1 });
    A.toast(A.t('gen.guardadoOk'), 'ok');
    A.vistas.dashboard();
    return;
  }
  var del = e.target.closest('[data-del]');
  if (del) {
    A.db.recordatorios.delete(parseInt(del.getAttribute('data-del'), 10));
    A.vistas.dashboard();
    return;
  }
  if (e.target.closest('#dash-new')) {
    A.ir('#/recepcion');
    return;
  }
  if (e.target.closest('#dash-search')) {
    A.srchAbrir();
    return;
  }
  if (e.target.closest('#dash-rem-add') || e.target.closest('#dash-rem-add2')) {
    A.remModal();
    return;
  }
  var bn = e.target.closest('[data-bn]');
  if (bn) {
    var acc = bn.getAttribute('data-bn');
    if (acc === 'manual') A.ir('#/manual');
    else if (acc === 'new') A.ir('#/recepcion');
    else if (acc === 'demo') {
      A.confirmar(A.t('aj.demo'), A.t('aj.demoQ')).then(function (ok) {
        if (!ok) return;
        A.cargarDemo().then(function () {
          A.toast(A.t('aj.demoOk'), 'ok');
          A.vistas.dashboard();
        });
      });
    }
    else if (acc === 'bk') A.backupExport();
    else if (acc === 'cerrarQs') {
      localStorage.setItem('as_noway', '1');
      document.getElementById('bn-qs').remove();
    }
  }
});

A.remModal = function () {
  A.modal(A.t('dash.rem'), [
    '<label class="field"><span>' + A.t('gen.nota') + '</span><input id="rem-t" placeholder="' + A.esc(A.t('dash.remPh')) + '"></label>',
    '<label class="field"><span>' + A.t('dash.remFecha') + '</span><input type="date" id="rem-f"></label>',
    '<button class="btn-primary" id="rem-ok">' + A.esc(A.t('gen.guardar')) + '</button>'
  ].join(''), {
    onOpen: function () {
      document.getElementById('rem-ok').onclick = function () {
        var t = document.getElementById('rem-t').value.trim();
        var f = document.getElementById('rem-f').value;
        if (!t) { A.toast(A.t('gen.errorCampos'), 'err'); return; }
        var ts = f ? new Date(f + 'T12:00:00').getTime() : null;
        A.db.recordatorios.add({ titulo: t, fecha: ts, hecho: 0, creado: Date.now() })
          .then(function () {
            A.cerrarModal();
            A.toast(A.t('gen.guardadoOk'), 'ok');
            A.vistas.dashboard();
          });
      };
    }
  });
};

/* ================= global ================= */
window.addEventListener('hashchange', A.ruta);
window.addEventListener('error', function (e) {
  console.error(e.error || e.message);
});

/* nav inferior */
document.getElementById('bnav').addEventListener('click', function (e) {
  var b = e.target.closest('[data-nav]');
  if (!b) return;
  A.sonido('click');
  A.vibrar(10);
  A.ir('#/' + b.getAttribute('data-nav'));
});

document.addEventListener('DOMContentLoaded', function () {
  /* botones back genéricos */
  A.$$('[data-back]').forEach(function (b) {
    b.addEventListener('click', function () {
      A.sonido('click');
      if (history.length > 1) history.back();
      else A.ir('#/dashboard');
    });
  });
});
