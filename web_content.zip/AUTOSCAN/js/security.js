/* AUTOSCAN · security.js — PIN local con SHA-256 + salt (Web Crypto, offline) */
var A = window.A || {};

A.sha256 = function (str) {
  var buf = new TextEncoder().encode(str);
  return crypto.subtle.digest('SHA-256', buf).then(function (h) {
    return Array.prototype.map.call(new Uint8Array(h), function (b) {
      return ('0' + b.toString(16)).slice(-2);
    }).join('');
  });
};

A.nuevoSalt = function () {
  var arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.prototype.map.call(arr, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
};

/* Hashea el PIN con el salt de la instalación */
A.hashPin = function (pin) {
  var salt = A.getCfg('pinSalt');
  if (!salt) { salt = A.nuevoSalt(); A.cfg.pinSalt = salt; A.db.config.put({ clave: 'pinSalt', valor: salt }); }
  return A.sha256(salt + '::' + pin);
};

A.guardarPin = function (pin) {
  return A.hashPin(pin).then(function (h) {
    return A.setCfg('pinHash', h);
  });
};

A.verificarPin = function (pin) {
  var guardado = A.getCfg('pinHash');
  if (!guardado) return Promise.resolve(true);
  return A.hashPin(pin).then(function (h) { return h === guardado; });
};

/* ================= PIN activable / desactivable (v2) ================= */
/* El hash se conserva: apagar el PIN es reversible con un solo interruptor */
A.pinActivo = function () {
  return !!A.getCfg('pinHash') && A.getCfg('pinActivo', true) !== false;
};
A.setPinActivo = function (on) {
  return A.setCfg('pinActivo', !!on);
};
A.quitarPin = function () {
  return A.removeCfg ? A.removeCfg('pinHash') : A.db.config.delete('pinHash').then(function () { delete A.cfg.pinHash; });
};
A.guardarPinConActivo = function (pin) {
  return A.guardarPin(pin).then(function () { return A.setPinActivo(true); });
};

/* ================= Pregunta de seguridad (v2) =================
   Recuperación de acceso offline: la respuesta se guarda hasheada
   (SHA-256 + salt de la instalación, en minúsculas y sin espacios). */
A.normResp = function (s) {
  return String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
};
A.guardarPregunta = function (pregunta, respuesta) {
  var salt = A.getCfg('pinSalt');
  if (!salt) { salt = A.nuevoSalt(); A.cfg.pinSalt = salt; A.db.config.put({ clave: 'pinSalt', valor: salt }); }
  return A.sha256(salt + '::preg::' + A.normResp(respuesta)).then(function (h) {
    return Promise.all([
      A.setCfg('preguntaSeg', String(pregunta || '').trim()),
      A.setCfg('preguntaHash', h)
    ]);
  });
};
A.tienePregunta = function () {
  return !!A.getCfg('preguntaHash') && !!A.getCfg('preguntaSeg');
};
A.verificarPregunta = function (respuesta) {
  var guardado = A.getCfg('preguntaHash');
  if (!guardado) return Promise.resolve(false);
  var salt = A.getCfg('pinSalt') || '';
  return A.sha256(salt + '::preg::' + A.normResp(respuesta)).then(function (h) {
    return h === guardado;
  });
};
A.quitarPregunta = function () {
  return Promise.all([
    A.db.config.delete('preguntaSeg'),
    A.db.config.delete('preguntaHash')
  ]).then(function () {
    delete A.cfg.preguntaSeg;
    delete A.cfg.preguntaHash;
  });
};
