/* AUTOSCAN v2 · search.js — búsqueda global: clientes, vehículos, órdenes e inventario */
var A = window.A || {};

A.srchAbrir = function () {
  var ov = document.getElementById('searchbox');
  var q = document.getElementById('srch-q');
  var res = document.getElementById('srch-res');
  q.value = '';
  res.innerHTML = '<div class="srch-hint">' + A.esc(A.t('sr.hint')) + '</div>';
  ov.hidden = false;
  setTimeout(function () { q.focus(); }, 60);
  A.sonido('scan');
};
A.srchCerrar = function () {
  document.getElementById('searchbox').hidden = true;
};

document.addEventListener('DOMContentLoaded', function () {
  var ov = document.getElementById('searchbox');
  if (!ov) return;
  document.getElementById('srch-x').addEventListener('click', function () { A.srchCerrar(); });
  /* tocar fuera cierra */
  ov.addEventListener('click', function (e) {
    if (e.target === ov) A.srchCerrar();
  });

  var tmr = null;
  document.getElementById('srch-q').addEventListener('input', function () {
    var v = this.value;
    clearTimeout(tmr);
    tmr = setTimeout(function () { A.srchBuscar(v); }, 220);
  });
  /* Enter → primer resultado */
  document.getElementById('srch-q').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      var primero = document.querySelector('#srch-res .srch-it');
      if (primero) primero.click();
    } else if (e.key === 'Escape') {
      A.srchCerrar();
    }
  });

  /* delegación de resultados */
  document.getElementById('srch-res').addEventListener('click', function (e) {
    var it = e.target.closest('[data-nav-srch]');
    if (!it) return;
    var partes = it.getAttribute('data-nav-srch').split(':');
    var tipo = partes[0], id = partes[1];
    A.srchCerrar();
    A.sonido('click');
    if (tipo === 'cli') A.ir('#/cliente/' + id);
    else if (tipo === 'veh') A.ir('#/cliente/' + id); /* ficha del dueño (muestra sus vehículos) */
    else if (tipo === 'ord') A.ir('#/orden/' + id);
    else if (tipo === 'inv') A.ir('#/inventario');
  });
});

A.srchBuscar = function (texto) {
  var res = document.getElementById('srch-res');
  var t = String(texto || '').toLowerCase().trim();
  if (!t) {
    res.innerHTML = '<div class="srch-hint">' + A.esc(A.t('sr.hint')) + '</div>';
    return;
  }
  var db = A.db;
  Promise.all([
    db.clientes.toArray(),
    db.vehiculos.toArray(),
    db.ordenes.toArray(),
    db.inventario.toArray()
  ]).then(function (r) {
    var clientes = r[0], vehiculos = r[1], ordenes = r[2], inv = r[3];

    /* mapa vehículo → placa para órdenes */
    var placaDe = {};
    vehiculos.forEach(function (v) { placaDe[v.id] = v.placa || ''; });
    var cliDe = {};
    clientes.forEach(function (c) { cliDe[c.id] = c.nombre || ''; });

    var html = '';
    var coincide = function () {
      for (var i = 0; i < arguments.length; i++) {
        if (String(arguments[i] || '').toLowerCase().indexOf(t) >= 0) return true;
      }
      return false;
    };

    /* clientes */
    var cls = clientes.filter(function (c) { return coincide(c.nombre, c.telefono, c.email); }).slice(0, 5);
    if (cls.length) {
      html += '<div class="srch-grp">' + A.esc(A.t('sr.clientes')) + '</div>';
      html += cls.map(function (c) {
        return '<div class="srch-it" data-nav-srch="cli:' + c.id + '">' + A.icon('user') +
          '<div class="grow"><div class="si-t">' + A.esc(c.nombre) + '</div>' +
          '<div class="si-s">' + A.esc(c.telefono || c.email || '—') + '</div></div>' + A.icon('right') + '</div>';
      }).join('');
    }

    /* vehículos */
    var vhs = vehiculos.filter(function (v) { return coincide(v.placa, v.marca, v.modelo, v.vin, cliDe[v.clienteId]); }).slice(0, 5);
    if (vhs.length) {
      html += '<div class="srch-grp">' + A.esc(A.t('sr.vehiculos')) + '</div>';
      html += vhs.map(function (v) {
        return '<div class="srch-it" data-nav-srch="veh:' + v.clienteId + '">' + A.icon('car') +
          '<div class="grow"><div class="si-t">' + A.esc(v.placa || (v.marca + ' ' + v.modelo)) + '</div>' +
          '<div class="si-s">' + A.esc((v.marca || '') + ' ' + (v.modelo || '') + ' ' + (v.anio || '')) + ' · ' + A.esc(cliDe[v.clienteId] || '—') + '</div></div>' + A.icon('right') + '</div>';
      }).join('');
    }

    /* órdenes (también por número) */
    var ords = ordenes.filter(function (o) {
      return coincide('#' + o.id, o.motivo, placaDe[o.vehiculoId], cliDe[o.clienteId], o.tecnico);
    }).sort(function (a, b) { return b.fechaEntrada - a.fechaEntrada; }).slice(0, 5);
    if (ords.length) {
      html += '<div class="srch-grp">' + A.esc(A.t('sr.ordenes')) + '</div>';
      html += ords.map(function (o) {
        var ei = A.estInfo(o.estado);
        return '<div class="srch-it" data-nav-srch="ord:' + o.id + '">' + A.icon('clipboard') +
          '<div class="grow"><div class="si-t">#' + o.id + ' · ' + A.esc(placaDe[o.vehiculoId] || '—') + '</div>' +
          '<div class="si-s">' + A.esc((o.motivo || '').slice(0, 40)) + '</div></div>' +
          '<span class="chip ' + ei.cls + '">' + ei.t + '</span></div>';
      }).join('');
    }

    /* inventario */
    var ivs = inv.filter(function (i) { return coincide(i.nombre); }).slice(0, 5);
    if (ivs.length) {
      html += '<div class="srch-grp">' + A.esc(A.t('sr.inventario')) + '</div>';
      html += ivs.map(function (i) {
        var bajo = (i.stock || 0) <= (i.stockMinimo || 0);
        return '<div class="srch-it" data-nav-srch="inv:0">' + A.icon('box') +
          '<div class="grow"><div class="si-t">' + A.esc(i.nombre) + '</div>' +
          '<div class="si-s">' + A.esc(A.t('inv.stock')) + ': ' + i.stock + ' / ' + i.stockMinimo + '</div></div>' +
          (bajo ? '<span class="chip crit">' + A.esc(A.t('inv.bajo')) + '</span>' : '') + '</div>';
      }).join('');
    }

    res.innerHTML = html || ('<div class="srch-hint">' + A.icon('search') + '<br>' + A.esc(A.t('sr.sinRes')) + '</div>');
  });
};
