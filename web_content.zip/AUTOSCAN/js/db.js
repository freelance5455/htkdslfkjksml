/* AUTOSCAN · db.js — IndexedDB vía Dexie · 100% local */
var A = window.A || {};

A.db = new Dexie('autoscan_db');
A.db.version(1).stores({
  clientes:       '++id, nombre, telefono',
  vehiculos:      '++id, clienteId, placa, marca',
  ordenes:        '++id, vehiculoId, clienteId, fechaEntrada, estado',
  checklistItems: '++id, ordenId, estado',
  repuestos:      '++id, ordenId, tipo',
  plantillas:     '++id, nombre, tipoVehiculo',
  inventario:     '++id, nombre',
  recordatorios:  '++id, fecha, hecho',
  config:         'clave'
});

/* ---------- Config (clave/valor) ---------- */
A.cfg = {};
A.getCfg = function (clave, def) {
  if (A.cfg[clave] !== undefined) return A.cfg[clave];
  return def;
};
A.setCfg = function (clave, valor) {
  A.cfg[clave] = valor;
  return A.db.config.put({ clave: clave, valor: valor });
};
A.loadCfg = function () {
  return A.db.config.toArray().then(function (rows) {
    A.cfg = {};
    rows.forEach(function (r) { A.cfg[r.clave] = r.valor; });
  });
};

/* ---------- Semillas iniciales (solo primer arranque) ---------- */
A.SEED_PLANTILLAS = [
  { nombre: 'Recepción estándar', tipoVehiculo: 'auto', items: [
    { cat: 'EXTERIOR', desc: 'Parabrisas y vidrios' }, { cat: 'EXTERIOR', desc: 'Luces delanteras' },
    { cat: 'EXTERIOR', desc: 'Luces traseras' }, { cat: 'EXTERIOR', desc: 'Espejos laterales' },
    { cat: 'EXTERIOR', desc: 'Carrocería / golpes' },
    { cat: 'INTERIOR', desc: 'Tablero y testigos' }, { cat: 'INTERIOR', desc: 'Aire acondicionado' },
    { cat: 'INTERIOR', desc: 'Cinturones de seguridad' }, { cat: 'INTERIOR', desc: 'Tapiz y limpieza' },
    { cat: 'MOTOR', desc: 'Nivel de aceite' }, { cat: 'MOTOR', desc: 'Líquido de frenos' },
    { cat: 'MOTOR', desc: 'Refrigerante' }, { cat: 'MOTOR', desc: 'Batería y bornes' },
    { cat: 'MOTOR', desc: 'Correas' }, { cat: 'MOTOR', desc: 'Fugas visibles' },
    { cat: 'SEGURIDAD', desc: 'Frenos' }, { cat: 'SEGURIDAD', desc: 'Neumáticos delanteros' },
    { cat: 'SEGURIDAD', desc: 'Neumáticos traseros' }, { cat: 'SEGURIDAD', desc: 'Suspensión' },
    { cat: 'SEGURIDAD', desc: 'Dirección' }, { cat: 'SEGURIDAD', desc: 'Claxon' }
  ]},
  { nombre: 'Mantenimiento básico', tipoVehiculo: 'auto', items: [
    { cat: 'ACEITE', desc: 'Aceite de motor' }, { cat: 'ACEITE', desc: 'Filtro de aceite' },
    { cat: 'FILTROS', desc: 'Filtro de aire' }, { cat: 'FILTROS', desc: 'Filtro de combustible' },
    { cat: 'MOTOR', desc: 'Bujías' }, { cat: 'MOTOR', desc: 'Líquido de frenos' },
    { cat: 'MOTOR', desc: 'Anticongelante' }, { cat: 'MOTOR', desc: 'Correa de accesorios' },
    { cat: 'SEGURIDAD', desc: 'Presión de neumáticos' }, { cat: 'SEGURIDAD', desc: 'Frenos' },
    { cat: 'SEGURIDAD', desc: 'Luces' }, { cat: 'SEGURIDAD', desc: 'Batería' },
    { cat: 'SEGURIDAD', desc: 'Suspensión' }, { cat: 'SEGURIDAD', desc: 'Alineación' }
  ]},
  { nombre: 'Moto', tipoVehiculo: 'moto', items: [
    { cat: 'MOTOR', desc: 'Nivel de aceite' }, { cat: 'MOTOR', desc: 'Batería' },
    { cat: 'MOTOR', desc: 'Carburación / inyección' }, { cat: 'MOTOR', desc: 'Fugas' },
    { cat: 'TRANSMISIÓN', desc: 'Cadena y piñones' }, { cat: 'TRANSMISIÓN', desc: 'Embrague' },
    { cat: 'SEGURIDAD', desc: 'Frenos delanteros' }, { cat: 'SEGURIDAD', desc: 'Frenos traseros' },
    { cat: 'SEGURIDAD', desc: 'Llantas' }, { cat: 'SEGURIDAD', desc: 'Luces' },
    { cat: 'SEGURIDAD', desc: 'Horquilla' }, { cat: 'SEGURIDAD', desc: 'Espejos' }
  ]},
  { nombre: 'Utilitario / Flota', tipoVehiculo: 'utilitario', items: [
    { cat: 'DOCUMENTACIÓN', desc: 'Papeles y permisos' }, { cat: 'DOCUMENTACIÓN', desc: 'Extintor vigente' },
    { cat: 'SEGURIDAD', desc: 'Luces' }, { cat: 'SEGURIDAD', desc: 'Frenos' },
    { cat: 'SEGURIDAD', desc: 'Neumáticos' }, { cat: 'SEGURIDAD', desc: 'Suspensión' },
    { cat: 'MOTOR', desc: 'Nivel de aceite' }, { cat: 'MOTOR', desc: 'Refrigerante' },
    { cat: 'MOTOR', desc: 'Batería' }, { cat: 'MOTOR', desc: 'Fugas' },
    { cat: 'CARGA', desc: 'Amarras y caja' }, { cat: 'CARGA', desc: 'Herramientas de a bordo' }
  ]}
];

A.seed = function () {
  return A.db.config.get('seeded').then(function (r) {
    if (r) return;
    var tx = A.db.transaction('rw', [A.db.plantillas, A.db.config], function () {
      A.SEED_PLANTILLAS.forEach(function (p) {
        p.creado = Date.now();
        A.db.plantillas.add(p);
      });
      var defs = {
        seeded: 1,
        tallerNombre: 'MI TALLER',
        tallerTel: '',
        tallerDir: '',
        tarifaHora: 50,
        tecnicos: [],
        tallerLogo: null,
        lastBackup: null
      };
      Object.keys(defs).forEach(function (k) { A.db.config.put({ clave: k, valor: defs[k] }); });
    });
    return tx;
  });
};

/* ---------- Utilidades compartidas ---------- */
A.ESTADOS = ['recepcion', 'diagnostico', 'reparacion', 'listo', 'entregado'];
A.estInfo = function (e) {
  var map = { recepcion: 'info', diagnostico: 'warn', reparacion: 'warn', listo: 'ok', entregado: 'dim' };
  return { t: A.t('est.' + e), cls: map[e] || 'info' };
};
A.hoy0 = function () { var d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };

/* Reglas de diagnóstico asistido (keyword → causas / acciones / repuestos) */
A.REGLAS = [
  { keys: ['freno', 'frenos', 'pastilla', 'brake'], causas: ['Pastillas desgastadas', 'Discos ranurados o cristalizados', 'Líquido de frenos vencido', 'Caliper agarrotado'],
    acciones: ['Medir espesor de pastillas', 'Revisar nivel y color del líquido', 'Prueba de frenado en vacío'],
    reps: ['Pastillas de freno', 'Líquido de frenos DOT3', 'Discos de freno'] },
  { keys: ['aceite', 'motor', 'fuga'], causas: ['Fugas por retenes o juntas', 'Consumo interno por anillos', 'Filtro vencido'],
    acciones: ['Medir nivel y calidad del aceite', 'Buscar manchas bajo el vehículo', 'Revisar junta de válvulas'],
    reps: ['Aceite de motor 5W30', 'Filtro de aceite', 'Junta de tapa válvulas'] },
  { keys: ['batería', 'bateria', 'borne', 'arranque'], causas: ['Batería al final de vida útil', 'Alternador con bajo voltaje', 'Bornes sulfatados'],
    acciones: ['Prueba de carga con multímetro', 'Revisar correa del alternador', 'Limpiar bornes'],
    reps: ['Batería 12V', 'Alternador', 'Terminal de borne'] },
  { keys: ['luz', 'luces', 'faro', 'foco'], causas: ['Foco quemado', 'Fusible abierto', 'Relay o mazo dañado'],
    acciones: ['Probar fusibles del tablero', 'Inspeccionar mazo y conectores'],
    reps: ['Foco H4', 'Fusible', 'Relay de luces'] },
  { keys: ['suspension', 'suspensión', 'amortiguador', 'ruido', 'traqueteo'], causas: ['Amortiguadores vencidos', 'Bujes de barra estabilizadora', 'Rótulas con holgura'],
    acciones: ['Prueba de rebote en cada esquina', 'Revisar bujes con palanca'],
    reps: ['Amortiguadores', 'Bujes de estabilizadora', 'Rótula inferior'] },
  { keys: ['neumatico', 'neumático', 'llanta', 'presión', 'presion'], causas: ['Desgaste desigual (alineación)', 'Presión incorrecta', 'Neumáticos vencidos'],
    acciones: ['Medir presión y profundidad', 'Revisar llanta por cortes'],
    reps: ['Neumáticos', 'Alineación y balanceo', 'Válvula de aire'] },
  { keys: ['refrigerante', 'enfriamiento', 'temperatura', 'sobrecalentamiento'], causas: ['Bomba de agua con fuga', 'Termostato pegado', 'Radiador obstruido'],
    acciones: ['Presión del sistema de enfriamiento', 'Revisar electroventilador'],
    reps: ['Anticongelante', 'Termostato', 'Bomba de agua'] },
  { keys: ['direccion', 'dirección', 'volante'], causas: ['Bomba de dirección con fuga', 'Terminales gastadas', 'Aceite de dirección bajo'],
    acciones: ['Revisar nivel de aceite de dirección', 'Prueba de holgura en terminales'],
    reps: ['Aceite de dirección', 'Terminales de dirección', 'Bomba de dirección'] },
  { keys: ['transmision', 'transmisión', 'embrague', 'clutch', 'cambio'], causas: ['Embrague al final de vida', 'Aceite de caja vencido', 'Bomba de clutch con fuga'],
    acciones: ['Probar deslizamiento del embrague', 'Revisar nivel de caja'],
    reps: ['Kit de embrague', 'Aceite de transmisión', 'Bomba de clutch'] },
  { keys: ['escape', 'humo', 'catalizador', 'ruido motor'], causas: ['Empaque de escape roto', 'Catalizador obstruido', 'Válvulas quemadas'],
    acciones: ['Inspección visual de línea de escape', 'Prueba de compresión'],
    reps: ['Empaque de escape', 'Catalizador', 'Válvulas'] },
  { keys: ['electrico', 'eléctrico', 'fusible', 'testigo', 'check engine'], causas: ['Sensor averiado (MAP, MAF, O2)', 'Mazo con falso contacto', 'Módulo con código activo'],
    acciones: ['Escaneo de códigos OBD', 'Inspección de mazos principales'],
    reps: ['Sensor O2', 'Sensor MAP', 'Fusible'] },
  { keys: ['filtro', 'aire', 'combustible'], causas: ['Filtro de aire saturado', 'Filtro de combustible obstruido', 'Bomba de gasolina con baja presión'],
    acciones: ['Inspección de filtros', 'Medir presión de combustible'],
    reps: ['Filtro de aire', 'Filtro de combustible', 'Bomba de gasolina'] },
  { keys: ['correa', 'distribution', 'distribución', 'tensor'], causas: ['Correa agrietada', 'Tensor con holgura', 'Cadena de distribución estirada'],
    acciones: ['Inspección visual de correa y tensor', 'Escucha de ruidos metálicos'],
    reps: ['Correa de accesorios', 'Tensor', 'Kit de distribución'] },
  { keys: ['parabrisas', 'vidrio', 'cristal'], causas: ['Parabrisas con fractura', 'Boquillas obstruidas'],
    acciones: ['Revisar fracturas por propagación'],
    reps: ['Parabrisas', 'Boquilla de limpiaparabrisas'] },
  { keys: ['claxon', 'bocina'], causas: ['Relay del claxon quemado', 'Contacto del volante desgastado'],
    acciones: ['Prueba directa del claxon'],
    reps: ['Claxon', 'Relay de claxon'] },
  { keys: ['alineacion', 'alineación', 'vibracion', 'vibración'], causas: ['Alineación fuera de spec', 'Balanceo pendiente', 'Rayos doblados'],
    acciones: ['Alineación computarizada', 'Balanceo dinámico'],
    reps: ['Alineación', 'Balanceo', 'Rayos'] }
];
