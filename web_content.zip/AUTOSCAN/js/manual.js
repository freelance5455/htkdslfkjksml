/* AUTOSCAN v2 · manual.js — Manual de uso completo (ES/EN) con acordeón y filtro */
var A = window.A || {};

/* Bloques: p (párrafo), ul (lista), tip (consejo), ok (consejo verde), steps (pasos numerados) */
A.MANUAL = {
  es: [
    { ic: 'info', t: 'Qué es AUTOSCAN',
      b: [
        { p: 'AUTOSCAN es el sistema de gestión de tu taller mecánico, diseñado para funcionar <b>100% sin internet</b>. Todos los datos (clientes, vehículos, órdenes, fotos, inventario) se guardan en la memoria local del teléfono. Nada sale de tu equipo.' },
        { p: 'La interfaz tipo HUD futurista está pensada para usarse con una mano, rápido, en plena faena del taller: botones grandes, colores claros y sonidos de confirmación.' },
        { ul: ['Módulo de clientes y vehículos con historial completo', 'Recepción asistida de 8 pasos con checklist semafórico', 'Presupuestos, firmas digitales y fotos con marca de agua', 'QR por orden, informes en PDF y respaldo en .zip'] },
        { tip: 'No necesitas instalar nada más: funciona en el navegador del teléfono o empaquetada como APK.' }
      ] },
    { ic: 'gear', t: 'Primeros pasos',
      b: [
        { p: 'Antes de atender tu primer cliente, configura lo básico en <b>Ajustes</b>:' },
        { steps: ['En Ajustes → Datos del taller escribe el nombre, teléfono, dirección y la <b>tarifa por hora</b> de mano de obra.', 'Añade tus <b>técnicos</b> en Ajustes → Técnicos para poder asignarlos a las órdenes.', 'Opcional: carga el <b>logo</b> del taller (saldrá en los PDF).', 'Elige <b>idioma</b>, sonidos, vibración y tema de color a tu gusto.'] },
        { tip: 'La tarifa por hora se usa para calcular la mano de obra cuando agregas trabajos al presupuesto.' }
      ] },
    { ic: 'lock', t: 'Seguridad: PIN y pregunta de recuperación',
      b: [
        { p: 'Al abrir la app por primera vez se te pide crear un <b>PIN de 4 dígitos</b>. Ese PIN protege el acceso: se guarda cifrado (hash SHA-256 con salt) en el teléfono, nunca en internet.' },
        { ul: [
          '<b>Pedir PIN al abrir la app</b>: interruptor en Ajustes → Seguridad. Si lo apagas, la app entra directo sin pedir nada; si lo enciendes, vuelve a pedirlo. Puedes cambiarlo cuando quieras (el PIN guardado no se pierde).',
          '<b>Cambiar PIN</b>: Ajustes → Seguridad → Cambiar PIN (pide el actual).',
          '<b>Pregunta de seguridad</b>: si algún día olvidas el PIN, respondes tu pregunta y recuperas el acceso al instante. Se configura al crear el PIN o luego en Ajustes → Seguridad.'
        ] },
        { ok: 'Consejo: activa la pregunta de seguridad el primer día. Sin ella, olvidar el PIN obliga a borrar todos los datos.' }
      ] },
    { ic: 'scan', t: 'Recepción asistida (los 8 pasos)',
      b: [
        { p: 'El botón gigante <b>NUEVA RECEPCIÓN</b> del inicio abre el asistente. Es el flujo principal del taller:' },
        { steps: [
          '<b>Cliente</b>: busca por nombre o teléfono, o registra uno nuevo con foto.',
          '<b>Vehículo</b>: selecciona uno del cliente o crea uno nuevo (marca, modelo, año, placa, VIN, color, km, combustible).',
          '<b>Motivo de visita</b>: describe el motivo (puedes dictarlo con el micrófono del teclado) o usa un motivo rápido.',
          '<b>Checklist</b>: revisa cada punto y márcalo en verde (ÓPTIMO), amarillo (ATENCIÓN) o rojo (CRÍTICO). Toma foto del punto si hace falta.',
          '<b>Presupuesto</b>: agrega repuestos del inventario, repuestos manuales o mano de obra. El total y las horas se calculan solos.',
          '<b>Firma</b>: el cliente firma con el dedo sobre el panel.',
          '<b>Resumen</b>: revisa todo y muestra el <b>código QR</b> de la orden al cliente.',
          '<b>Guardar</b>: la orden queda registrada en la base local.'
        ] },
        { tip: 'En el paso 4 puedes guardar tu selección de checklist como plantilla para reutilizarla en órdenes futuras.' }
      ] },
    { ic: 'circle', t: 'Estados de la orden y flujo de trabajo',
      b: [
        { p: 'Cada orden avanza por 5 estados, y cada cambio queda registrado con fecha y hora en el historial de la orden:' },
        { ul: [
          '<b>RECEPCIÓN</b>: el vehículo entra al taller.',
          '<b>DIAGNÓSTICO</b>: se revisa y se detecta la falla.',
          '<b>REPARACIÓN</b>: se trabaja con repuestos y mano de obra.',
          '<b>LISTO</b>: terminado, esperando al cliente.',
          '<b>ENTREGADO</b>: el cliente retiró el vehículo (se registra la fecha de salida y el ingreso entra al panel del mes).'
        ] },
        { p: 'Para avanzar, abre la orden y toca el botón del siguiente estado. El tiempo total en taller se calcula automáticamente.' },
        { tip: 'El panel de inicio muestra cuántas órdenes hay en cada estado con la gráfica de anillo.' }
      ] },
    { ic: 'camera', t: 'Fotos, anotaciones y antes/después',
      b: [
        { p: 'En cada punto del checklist puedes tomar una <b>foto</b>. La foto se guarda comprimida y con <b>marca de agua</b> (fecha, hora y placa) para que sea evidencia válida.' },
        { ul: [
          '<b>Anotar</b>: abre una foto y toca el lápiz para dibujar flechas, círculos o trazos libres señalando la falla.',
          '<b>Foto después</b>: al reparar, toma la foto de la corrección y compárala con la original con el deslizador <b>Antes / Después</b>.',
          'Todas las fotos de la orden se agrupan en la galería de la orden.'
        ] },
        { ok: 'Una foto anotada del problema evita discusiones: el cliente ve exactamente lo que viste tú.' }
      ] },
    { ic: 'money', t: 'Presupuestos e inventario',
      b: [
        { p: 'El presupuesto se arma en el paso 5 de la recepción o directamente en la orden abierta:' },
        { ul: [
          '<b>Desde inventario</b>: elige repuestos registrados; puedes descontar stock.',
          '<b>Repuesto manual</b>: para piezas compradas específicamente.',
          '<b>Mano de obra</b>: describe el trabajo, horas estimadas y tarifa.',
          '<b>Aprobar presupuesto</b>: marca la orden como aprobada con fecha, listo para mostrar al cliente.'
        ] },
        { p: 'En <b>Inventario</b> registras cada repuesto con stock actual y stock mínimo. Cuando el stock llega al mínimo, el panel de inicio te avisa. También puedes exportar el inventario a CSV para Excel.' }
      ] },
    { ic: 'zap', t: 'Diagnóstico asistido',
      b: [
        { p: 'Dentro de una orden, el panel <b>Diagnóstico asistido</b> cruza el motivo de la visita y los puntos marcados en rojo o amarillo con una base de reglas local (frenos, motor, batería, suspensión, electricidad y más).' },
        { ul: ['Causas probables de la falla', 'Acciones sugeridas para verificar', 'Repuestos recomendados que puedes agregar al presupuesto con un toque'] },
        { tip: 'No reemplaza tu criterio de técnico: es una checklist de experiencia acumulada que trabaja offline.' }
      ] },
    { ic: 'pen', t: 'Firmas, QR, PDF y WhatsApp',
      b: [
        { ul: [
          '<b>Firmas</b>: la del cliente (recepción) y la del técnico (al entregar) se dibujan en pantalla y quedan adjuntas a la orden.',
          '<b>QR por orden</b>: cada orden genera un código único. Con la "vista cliente" muestras el estado del vehículo en pantalla sin exponer datos privados.',
          '<b>PDF</b>: genera el informe completo de la orden (checklist, fotos, presupuesto y firmas) y compártelo por cualquier app del teléfono.',
          '<b>WhatsApp</b>: si el cliente tiene teléfono, el botón de WhatsApp abre el chat con un mensaje listo con el estado y el total de su orden.'
        ] }
      ] },
    { ic: 'search', t: 'Búsqueda global',
      b: [
        { p: 'El botón de lupa en la barra del inicio abre la <b>búsqueda global</b>: escribe cualquier cosa (nombre del cliente, placa, número de orden, repuesto) y la app busca en clientes, vehículos, órdenes e inventario a la vez.' },
        { tip: 'Funciona también escribiendo el número de orden: "#12" salta directo a la orden 12.' }
      ] },
    { ic: 'archive', t: 'Respaldo, importación y CSV',
      b: [
        { p: 'Todo vive en el teléfono, así que el respaldo es tu seguro de vida:' },
        { ul: [
          '<b>Exportar .zip</b>: genera un archivo con TODA la base de datos. Guárdalo en la nube, PC o memoria externa.',
          '<b>Importar .zip</b>: restaura la base completa en otro teléfono o tras cambiar de equipo. Reemplaza los datos actuales.',
          '<b>Exportar CSV</b>: clientes, órdenes o inventario en tablas listas para Excel.',
          '<b>Recordatorio</b>: si pasan 7 días sin respaldo, el panel de inicio te lo recuerda.'
        ] },
        { ok: 'Rutina recomendada: exporta el .zip cada viernes. Toma 5 segundos.' }
      ] },
    { ic: 'palette', t: 'Personalización y accesibilidad',
      b: [
        { ul: [
          '<b>Tema de color</b>: 5 acentos HUD (ámbar, cian, verde, magenta, rojo) que cambian toda la interfaz al instante.',
          '<b>Tamaño de texto</b>: normal, grande o muy grande para leer mejor a pleno sol.',
          '<b>Partículas de fondo</b>: animación ambiental; apágala si prefieres máximo rendimiento o batería.',
          '<b>Sonidos y vibración</b>: feedback sci-fi de cada acción.',
          '<b>Idioma</b>: español e inglés completos, cambiable en Ajustes o desde la pantalla de PIN.'
        ] }
      ] },
    { ic: 'help', t: 'Preguntas frecuentes (FAQ)',
      b: [
        { ul: [
          '<b>¿Pierdo mis datos si cierro la app?</b> No. Quedan en la base local del navegador/WebView hasta que tú los borres.',
          '<b>¿Y si cambio de teléfono?</b> Exporta el .zip en el equipo viejo e impórtalo en el nuevo.',
          '<b>¿Puedo usarla en varios talleres?</b> Cada instalación es independiente; usa respaldos distintos por taller.',
          '<b>¿Las fotos llenan la memoria?</b> Se comprimen automáticamente (~1200px, JPEG) para ahorrar espacio sin perder detalle útil.',
          '<b>¿Olvidé el PIN y no tengo pregunta de seguridad</b>: por diseño no hay "puerta trasera"; tendrías que borrar los datos y recuperarlos desde tu último respaldo .zip.',
          '<b>¿Se puede imprimir?</b> Genera el PDF y compártelo con cualquier app de impresión instalada.'
        ] }
      ] },
    { ic: 'phone', t: 'Instalación como app y fase avanzada',
      b: [
        { p: 'AUTOSCAN es una app web offline: puede instalarse en Android como APK (con un constructor "HTML to APK") o abrirse directo en el navegador. En el navegador también puedes agregarla a la pantalla de inicio como app (PWA) y funcionará sin conexión.' },
        { p: 'Funciones marcadas como <b>Fase avanzada</b> (OCR del VIN, lector de códigos, notificaciones nativas, biometría, impresora térmica) requieren un puente nativo; la guía para activarlas está en el archivo docs/FASE-AVANZADA.txt del proyecto.' }
      ] }
  ],

  en: [
    { ic: 'info', t: 'What AUTOSCAN is',
      b: [
        { p: 'AUTOSCAN is your auto shop management system, built to work <b>100% offline</b>. All data (customers, vehicles, orders, photos, inventory) is stored in the phone local memory. Nothing ever leaves your device.' },
        { p: 'The futuristic HUD interface is designed for one-handed, fast operation in the middle of a busy shop: big buttons, clear colors and confirmation sounds.' },
        { ul: ['Customers and vehicles module with full history', '8-step assisted reception with traffic-light checklist', 'Quotes, digital signatures and photos with watermark', 'Per-order QR, PDF reports and .zip backup'] },
        { tip: 'Nothing else to install: it runs in the phone browser or packaged as an APK.' }
      ] },
    { ic: 'gear', t: 'First steps',
      b: [
        { p: 'Before your first customer, set up the basics in <b>Settings</b>:' },
        { steps: ['In Settings → Workshop data enter the name, phone, address and the hourly <b>labor rate</b>.', 'Add your <b>technicians</b> in Settings → Technicians so you can assign them to orders.', 'Optional: upload the workshop <b>logo</b> (it appears on PDFs).', 'Pick <b>language</b>, sounds, haptics and color theme.'] },
        { tip: 'The hourly rate is used to compute labor cost when you add work lines to a quote.' }
      ] },
    { ic: 'lock', t: 'Security: PIN and recovery question',
      b: [
        { p: 'On first launch you create a <b>4-digit PIN</b>. It protects access and is stored hashed (SHA-256 with salt) on the phone, never online.' },
        { ul: [
          '<b>Ask for PIN when opening</b>: switch in Settings → Security. Turn it off and the app opens straight away; turn it on and it asks again anytime (the stored PIN is never lost).',
          '<b>Change PIN</b>: Settings → Security → Change PIN (asks for the current one).',
          '<b>Security question</b>: if you ever forget the PIN, answer your question and regain access instantly. Set it up when creating the PIN or later in Settings → Security.'
        ] },
        { ok: 'Tip: set the security question on day one. Without it, forgetting the PIN forces a full data wipe.' }
      ] },
    { ic: 'scan', t: 'Assisted reception (the 8 steps)',
      b: [
        { p: 'The big <b>NEW RECEPTION</b> button on the home screen opens the wizard. This is the shop main flow:' },
        { steps: [
          '<b>Customer</b>: search by name or phone, or register a new one with photo.',
          '<b>Vehicle</b>: pick one of the customer vehicles or create a new one (brand, model, year, plate, VIN, color, mileage, fuel).',
          '<b>Visit reason</b>: describe it (you can dictate with the keyboard mic) or use a quick reason chip.',
          '<b>Checklist</b>: review each point and mark it green (OK), yellow (ATTENTION) or red (CRITICAL). Take a photo if needed.',
          '<b>Quote</b>: add parts from inventory, manual parts or labor. Totals and hours compute automatically.',
          '<b>Signature</b>: the customer signs with a finger on the panel.',
          '<b>Summary</b>: review everything and show the order <b>QR code</b> to the customer.',
          '<b>Save</b>: the order is stored in the local database.'
        ] },
        { tip: 'In step 4 you can save your checklist selection as a template for future orders.' }
      ] },
    { ic: 'circle', t: 'Order statuses and workflow',
      b: [
        { p: 'Every order moves through 5 statuses, and each change is logged with date and time in the order history:' },
        { ul: [
          '<b>RECEPTION</b>: the vehicle enters the shop.',
          '<b>DIAGNOSIS</b>: inspection and fault finding.',
          '<b>REPAIR</b>: parts and labor happen here.',
          '<b>READY</b>: finished, waiting for the customer.',
          '<b>DELIVERED</b>: the customer picked up the vehicle (exit date is saved and revenue enters the month panel).'
        ] },
        { p: 'To advance, open the order and tap the next status button. Total shop time is computed automatically.' },
        { tip: 'The home panel shows how many orders sit in each status on the ring chart.' }
      ] },
    { ic: 'camera', t: 'Photos, annotations and before/after',
      b: [
        { p: 'On every checklist point you can take a <b>photo</b>. Photos are stored compressed with a <b>watermark</b> (date, time and plate) so they work as valid evidence.' },
        { ul: [
          '<b>Annotate</b>: open a photo and tap the pencil to draw arrows, circles or free strokes pointing at the fault.',
          '<b>After photo</b>: once repaired, take the fix photo and compare it with the original using the <b>Before / After</b> slider.',
          'All order photos are grouped in the order gallery.'
        ] },
        { ok: 'One annotated photo of the problem prevents arguments: the customer sees exactly what you saw.' }
      ] },
    { ic: 'money', t: 'Quotes and inventory',
      b: [
        { p: 'The quote is built on reception step 5 or directly inside the open order:' },
        { ul: [
          '<b>From inventory</b>: pick registered parts; you can deduct stock.',
          '<b>Manual part</b>: for specially purchased pieces.',
          '<b>Labor</b>: describe the job, estimated hours and rate.',
          '<b>Approve quote</b>: marks the order as approved with a date, ready to show the customer.'
        ] },
        { p: 'In <b>Inventory</b> you register each part with current stock and minimum stock. When stock hits the minimum, the home panel warns you. You can also export inventory to CSV for Excel.' }
      ] },
    { ic: 'zap', t: 'Assisted diagnosis',
      b: [
        { p: 'Inside an order, the <b>Assisted diagnosis</b> panel crosses the visit reason and the red/yellow checklist points with a local rule base (brakes, engine, battery, suspension, electrics and more).' },
        { ul: ['Likely causes of the fault', 'Suggested actions to verify', 'Recommended parts you can add to the quote with one tap'] },
        { tip: 'It does not replace your technician judgment: it is an accumulated-experience checklist that works offline.' }
      ] },
    { ic: 'pen', t: 'Signatures, QR, PDF and WhatsApp',
      b: [
        { ul: [
          '<b>Signatures</b>: customer (reception) and technician (delivery) are drawn on screen and attached to the order.',
          '<b>Per-order QR</b>: every order generates a unique code. With the "customer view" you show the vehicle status on screen without exposing private data.',
          '<b>PDF</b>: generate the full order report (checklist, photos, quote and signatures) and share it through any phone app.',
          '<b>WhatsApp</b>: if the customer has a phone number, the WhatsApp button opens the chat with a ready message including status and total.'
        ] }
      ] },
    { ic: 'search', t: 'Global search',
      b: [
        { p: 'The magnifier button on the home bar opens <b>global search</b>: type anything (customer name, plate, order number, part) and the app searches customers, vehicles, orders and inventory at once.' },
        { tip: 'It also works with the order number: "#12" jumps straight to order 12.' }
      ] },
    { ic: 'archive', t: 'Backup, import and CSV',
      b: [
        { p: 'Everything lives on the phone, so backups are your life insurance:' },
        { ul: [
          '<b>Export .zip</b>: generates a file with the WHOLE database. Keep it in the cloud, a PC or external storage.',
          '<b>Import .zip</b>: restores the full database on another phone or after switching devices. It replaces current data.',
          '<b>Export CSV</b>: customers, orders or inventory as Excel-ready tables.',
          '<b>Reminder</b>: after 7 days without a backup the home panel reminds you.'
        ] },
        { ok: 'Recommended routine: export the .zip every Friday. It takes 5 seconds.' }
      ] },
    { ic: 'palette', t: 'Customization and accessibility',
      b: [
        { ul: [
          '<b>Color theme</b>: 5 HUD accents (amber, cyan, green, magenta, red) that restyle the whole interface instantly.',
          '<b>Text size</b>: normal, large or extra large for better reading under sunlight.',
          '<b>Background particles</b>: ambient animation; turn it off for maximum performance or battery.',
          '<b>Sounds and haptics</b>: sci-fi feedback for every action.',
          '<b>Language</b>: full Spanish and English, switchable in Settings or from the PIN screen.'
        ] }
      ] },
    { ic: 'help', t: 'Frequently asked questions (FAQ)',
      b: [
        { ul: [
          '<b>Do I lose data by closing the app?</b> No. It stays in the browser/WebView local database until you delete it.',
          '<b>What if I change phones?</b> Export the .zip on the old device and import it on the new one.',
          '<b>Can I run several shops?</b> Each installation is independent; keep separate .zip backups per shop.',
          '<b>Do photos fill the memory?</b> They are auto-compressed (~1200px, JPEG) to save space without losing useful detail.',
          '<b>Forgot the PIN and no security question</b>: by design there is no backdoor; you would need to wipe data and restore from your latest .zip backup.',
          '<b>Can I print?</b> Generate the PDF and share it with any installed printing app.'
        ] }
      ] },
    { ic: 'phone', t: 'Installing as an app and advanced phase',
      b: [
        { p: 'AUTOSCAN is an offline web app: it can be packaged on Android as an APK (with any "HTML to APK" builder) or opened directly in the browser. In the browser you can also add it to the home screen as an app (PWA) and it will keep working without connection.' },
        { p: 'Features marked as <b>Advanced phase</b> (VIN OCR, barcode scanner, native notifications, biometrics, thermal printer) need a native bridge; the activation guide lives in docs/FASE-AVANZADA.txt inside the project.' }
      ] }
  ]
};

/* ---------- render del manual ---------- */
A.regVista('manual', function () {
  A.manPinta('');
  var q = document.getElementById('man-q');
  q.oninput = function () { A.manPinta(this.value); };
});

A.manBloque = function (b) {
  if (b.p) return '<p>' + b.p + '</p>';
  if (b.ul) return '<ul>' + b.ul.map(function (li) { return '<li>' + li + '</li>'; }).join('') + '</ul>';
  if (b.steps) return '<div class="man-steps">' + b.steps.map(function (s, i) {
    return '<div class="man-step"><i>' + (i + 1) + '</i><div>' + s + '</div></div>';
  }).join('') + '</div>';
  if (b.tip) return '<div class="man-tip">' + A.icon('info') + '<span>' + b.tip + '</span></div>';
  if (b.ok) return '<div class="man-tip ok">' + A.icon('check') + '<span>' + b.ok + '</span></div>';
  return '';
};

A.manPinta = function (filtro) {
  var lang = (A.prefs && A.prefs.idioma === 'en') ? 'en' : 'es';
  var data = A.MANUAL[lang];
  var t = String(filtro || '').toLowerCase().trim();
  var box = document.getElementById('man-list');
  var html = '';
  data.forEach(function (sec, i) {
    var contenido = sec.b.map(A.manBloque).join('');
    var texto = (sec.t + ' ' + sec.b.map(function (b) {
      return (b.p || '') + (b.ul ? b.ul.join(' ') : '') + (b.steps ? b.steps.join(' ') : '') + (b.tip || '') + (b.ok || '');
    }).join(' ')).toLowerCase();
    var visible = !t || texto.indexOf(t) >= 0;
    if (!visible) return;
    var abierto = t ? ' open' : (i === 0 ? ' open' : '');
    html += '<div class="man-sec' + abierto + '">' +
      '<button class="man-q" data-man="' + i + '">' +
      '<span class="m-ic">' + A.icon(sec.ic) + '</span>' +
      '<span class="grow"><span class="m-num mono">' + String(i + 1).padStart(2, '0') + '</span>' + A.esc(sec.t) + '</span>' +
      '<span class="chev">' + A.icon('chev') + '</span>' +
      '</button>' +
      '<div class="man-a"><div class="man-body">' + contenido + '</div></div>' +
      '</div>';
  });
  box.innerHTML = html || ('<div class="empty">' + A.icon('book') + '<div>' + A.esc(A.t('man.sinRes')) + '</div></div>');
};

/* acordeón (delegación) */
document.addEventListener('DOMContentLoaded', function () {
  var box = document.getElementById('man-list');
  if (!box) return;
  box.addEventListener('click', function (e) {
    var q = e.target.closest('.man-q');
    if (!q) return;
    A.sonido('click'); A.vibrar(10);
    var sec = q.closest('.man-sec');
    var abierto = sec.classList.contains('open');
    A.$$('.man-sec.open', box).forEach(function (s) { s.classList.remove('open'); });
    if (!abierto) sec.classList.add('open');
  });
});
