package com.amarnathfilms.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("file:///android_asset/")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                } catch (Exception e) {
                    // nothing can open this link
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private static String safe(String name) {
        return name.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    /** Methods the web page can call as Android.xxx(...) */
    public class Bridge {

        /** Sends the bill PDF straight to the customer's WhatsApp chat (you only press send). */
        @JavascriptInterface
        public void sharePdf(final String base64, final String name, final String text, final String phone) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        File dir = new File(getCacheDir(), "bills");
                        dir.mkdirs();
                        File file = new File(dir, safe(name));
                        FileOutputStream out = new FileOutputStream(file);
                        out.write(Base64.decode(base64, Base64.DEFAULT));
                        out.close();

                        Uri uri = FileProvider.getUriForFile(
                                MainActivity.this, getPackageName() + ".fileprovider", file);

                        String[] packages = {"com.whatsapp", "com.whatsapp.w4b"};
                        for (String pkg : packages) {
                            try {
                                Intent i = new Intent(Intent.ACTION_SEND);
                                i.setType("application/pdf");
                                i.putExtra(Intent.EXTRA_STREAM, uri);
                                i.putExtra(Intent.EXTRA_TEXT, text);
                                i.setPackage(pkg);
                                if (phone != null && phone.length() > 0) {
                                    i.putExtra("jid", phone + "@s.whatsapp.net");
                                }
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(i);
                                return;
                            } catch (ActivityNotFoundException e) {
                                // try the next WhatsApp app
                            }
                        }

                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("application/pdf");
                        i.putExtra(Intent.EXTRA_STREAM, uri);
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, "Share bill"));
                    } catch (Exception e) {
                        toast("Could not share the bill");
                    }
                }
            });
        }

        /** Saves the bill PDF in the phone's Downloads folder. */
        @JavascriptInterface
        public void savePdf(final String base64, final String name) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        byte[] data = Base64.decode(base64, Base64.DEFAULT);
                        String n = safe(name);
                        if (Build.VERSION.SDK_INT >= 29) {
                            ContentValues v = new ContentValues();
                            v.put(MediaStore.Downloads.DISPLAY_NAME, n);
                            v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                            OutputStream o = getContentResolver().openOutputStream(u);
                            o.write(data);
                            o.close();
                            toast("Bill saved in Downloads: " + n);
                        } else {
                            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                            File f = new File(dir, n);
                            FileOutputStream o = new FileOutputStream(f);
                            o.write(data);
                            o.close();
                            toast("Bill saved: " + f.getAbsolutePath());
                        }
                    } catch (Exception e) {
                        toast("Could not save the bill");
                    }
                }
            });
        }

        /** Opens the customer's WhatsApp chat with a ready message (used for reminders). */
        @JavascriptInterface
        public void openWhatsApp(final String phone, final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String enc = URLEncoder.encode(text, "UTF-8").replace("+", "%20");
                        Uri uri = Uri.parse("https://wa.me/" + phone + "?text=" + enc);
                        Intent i = new Intent(Intent.ACTION_VIEW, uri);
                        i.setPackage("com.whatsapp");
                        try {
                            startActivity(i);
                        } catch (ActivityNotFoundException e) {
                            i.setPackage(null);
                            startActivity(i);
                        }
                    } catch (Exception e) {
                        toast("Could not open WhatsApp");
                    }
                }
            });
        }
    }
}
