AMARNATH FILMS - ANDROID APP PROJECT
====================================
This builds a real Android app (APK) that can:
 - send the bill PDF straight into the customer's WhatsApp chat
 - save the bill PDF in your phone's Downloads folder
 - open WhatsApp reminders

HOW TO MAKE THE APK (needs a computer, one time, free)
1. Install Android Studio (developer.android.com/studio).
2. Unzip this file. In Android Studio choose: File > Open, and pick the folder "AmarnathFilms".
3. Wait for "Gradle sync" to finish (first time it downloads files; needs internet).
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When it finishes, click "locate". The file is app-debug.apk (inside app/build/outputs/apk/debug).
6. Send app-debug.apk to your phone and install it (allow "install unknown apps" if asked).

TO UPDATE THE APP LATER
Replace the file app/src/main/assets/index.html with the new version, then build again.
Installing over the old app keeps your bookings.
