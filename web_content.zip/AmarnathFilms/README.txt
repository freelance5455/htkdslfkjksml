AMARNATH FILMS - ANDROID APP PROJECT
====================================
This builds a real Android app (APK) that can:
(Note: Android/WhatsApp cannot pick the customer for you. The PDF opens in WhatsApp; you choose the customer once and press send.)
 - send the bill PDF through WhatsApp (open WhatsApp, pick the customer, press send)
 - save the bill PDF in your phone's Downloads folder
 - open WhatsApp reminders

HOW TO MAKE THE APK (needs a computer, one time, free)
1. Install Android Studio (developer.android.com/studio).
2. Unzip this file. In Android Studio choose: File > Open, and pick the folder "AmarnathFilms".
3. Wait for "Gradle sync" to finish (first time it downloads files; needs internet).
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When it finishes, click "locate". The file is app-debug.apk (inside app/build/outputs/apk/debug).
6. Send app-debug.apk to your phone and install it (allow "install unknown apps" if asked).

TO UPDATE THE APP LATER
Replace the file app/src/main/assets/index.html with the new version, then build again.
Installing over the old app keeps your bookings.

FIX INCLUDED (WhatsApp link error)
-----------------------------------
The Android WebView now intercepts whatsapp://send links and opens them through
WhatsApp/wa.me instead of trying to load them as a web page. This addresses
net::ERR_UNKNOWN_URL_SCHEME when tapping WhatsApp bill/reminder links.


LONG-TERM DATA SAFETY (VERSION 1.1)
----------------------------------
 - The app stores live records locally on this phone; Firebase/internet is not required for booking records.
 - On Home, open Account & data safety and tap Export backup. The JSON backup is saved in Downloads on modern Android.
 - Copy the backup file to a second safe place (for example, a computer or trusted cloud drive). A backup kept only on the same phone can be lost with the phone.
 - To restore, tap Restore backup and select an Amarnath Films JSON backup. Restoring replaces the current bookings/settings, so export a fresh backup first.
 - Export a backup weekly and before updating, clearing app storage, or uninstalling. Never clear app data without a current backup.
 - This project adds native Android file saving and file selection so backup/restore work better in the WebView app.
 - The app has been source-checked for JavaScript syntax; build and test the APK in Android Studio on the target phone before relying on it for business records.
