MIRI RADIO v2 — radio kataloqu + reklam bölməsi

Bu paket HTML/PWA başlanğıc layihəsidir, imzalanmış APK deyil.

YENİLİKLƏR
- Radio Browser API-dən canlı stansiya siyahısı yükləyir.
- Azərbaycan, Türkiyə, Rusiya, İran, İraq və Avropanın bir sıra ölkələri.
- Kataloqdan səhifələmə ilə 100-lük radio siyahıları və daha çox yükləmə.
- Axtarış, musiqi/xəbər/söhbət filtrləri, sevimlilər və audio pleyer.
- AZ/RU/EN interfeysi.
- Reklam bölməsi: reklam paketləri, müraciət forması, e-poçt proqramında müraciət hazırlamaq.

VACİB MƏHDUDİYYƏTLƏR
1. İnternet bağlantısı tələb olunur. API və radio streamləri üçüncü tərəflərdir; ölkə, şəbəkə, CORS, stream formatı və müəllif hüquqları səbəbindən bəzi kanallar açılmaya bilər.
2. “Bütün kanallar”ın hamısını bir dəfəlik fayla yığmaq real və dayanıqlı deyil: siyahılar dəyişir. Bu versiya kataloqdan dinamik yükləyir.
3. Reklam müraciəti hazırda telefonda e-poçt tətbiqini açır; serverə avtomatik göndərilmir. mailto: ünvanı boşdur, çünki sənin biznes e-poçtun verilməyib. Reklam müraciətlərini qəbul etmək üçün e-poçt və ya WhatsApp əlaqəsi əlavə edilməlidir.
4. Reklam paketləri sadəcə təklif nümunəsidir. Bu layihədə ödəniş sistemi, reklam şəbəkəsi, admin paneli və ya avtomatik gəlir yoxdur.
5. Bu layihə hazır APK deyil. APK üçün Android Studio/Capacitor, audio üçün native background playback, icazələr, build və imzalama lazımdır.

SINAQ
- ZIP-i çıxart.
- HTTPS hostinqə (məsələn Firebase Hosting) yerləşdirib açmaq daha etibarlıdır.
- Telefonda brauzer menyusundan “Ana ekrana əlavə et” seçilə bilər.
- file:// rejimində bəzi brauzerlər API bağlantılarını bloklaya bilər.

Mənbə: https://www.radio-browser.info/
API sənədləri: https://docs.radio-browser.info/
