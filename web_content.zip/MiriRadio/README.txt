# Miri Radio — başlanğıc tətbiq layihəsi

Bu ZIP telefon və kompüter brauzerində işləyən, mobil görünüşlü radio tətbiqinin başlanğıc versiyasıdır.

## Nələr var?
- Azərbaycan, rus və ingilis dilləri
- Azərbaycan, Türkiyə, Rusiya, İran, İraq və Avropa ölkələri
- Ölkəyə görə radio siyahısı
- Radio axtarışı, janr filtrləri və sevimlilər
- Canlı audio player
- PWA manifesti və sadə service worker

## Vacib qeyd
Radio siyahısı internetdəki açıq, üçüncü tərəf radio kataloqundan yüklənir. Siyahıda olan hər kanal hər zaman işləməyə bilər; yayım hüquqları, ölkə məhdudiyyətləri, stream formatı və bağlantının dəyişməsi təsir edə bilər. Bütün stansiyaların daim işləməsinə zəmanət verilmir.

## Telefonda sınaq
1. ZIP-i aç.
2. `index.html` faylını brauzerdə aç. Bəzi brauzerlər `file://` rejimində xarici siyahını yükləməyə icazə verməyə bilər.
3. Daha etibarlı sınaq üçün faylları GitHub Pages və ya Firebase Hosting kimi HTTPS hostinqə yerləşdir.
4. Sayt HTTPS ilə açıldıqda brauzerin menyusundan “Ana ekrana əlavə et / Install app” seçimi görünə bilər.

## APK haqqında
Bu paket hələ imzalanmış Android APK faylı deyil. APK yaratmaq üçün Android Studio-da WebView/Capacitor layihəsinə çevirmək, internet icazəsi, audio playback və arxa planda yayım xidmətini qurmaq, sonra APK-ni build və sign etmək lazımdır. Bu layihədə native arxa-plan audio xidməti daxil deyil.

## Radio kataloqu
Verified Radio Streams layihəsi: https://github.com/eyalev/verified-radio-streams
