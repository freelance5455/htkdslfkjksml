# Hindi2English AI — Android Studio project

This is an Android WebView app project for the Hindi2English AI prototype.

## Build an APK
1. Install **Android Studio** on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `Hindi2English_AI_Android` folder.
4. Wait for Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
8. Send that APK to your phone or share it through WhatsApp as a Document.

## App features
- Hindi/Hinglish text → English using Gemini API.
- Hindi voice → Android speech recognition (`hi-IN`) → English using Gemini API.
- Copy English translation and listen to the English result.

## Gemini API key
Open the app, expand **Connect Gemini API**, and enter your Gemini API key.
Get a key at https://aistudio.google.com/apikey

**Security:** This starter project passes the API key from the app directly to Google's API. It is suitable only for personal testing. Before public distribution, implement a secure backend so the API key is not shared with APK users.

## Notes
- Voice recognition availability and accuracy depend on the Android device, Google speech services, language packs, and internet connection.
- This environment does not include Android SDK/Gradle, so this deliverable is an Android Studio project ZIP, not a compiled APK.
