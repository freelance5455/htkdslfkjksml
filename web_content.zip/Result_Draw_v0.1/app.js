const pages = [...document.querySelectorAll('.page')];
const navItems = [...document.querySelectorAll('.nav-item')];
const toast = document.getElementById('toast');
function showToast(message){
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>toast.classList.remove('show'), 2800);
}
function openPage(id){
  pages.forEach(p=>p.classList.toggle('active',p.id===id));
  navItems.forEach(n=>n.classList.toggle('active',n.dataset.page===id));
  window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('[data-page]').forEach(btn=>{
  btn.addEventListener('click',()=>openPage(btn.dataset.page));
});
const officialLive = 'https://hokidraw.com/live-draw.html';
const officialResults = 'https://hokidraw.com/';
function openExternal(url){
  // In a packaged WebView, this opens the official page in the current web view
  // only if the wrapper permits normal navigation. Browser fallback may be needed.
  window.location.href = url;
}
document.getElementById('openLiveBtn').addEventListener('click',()=>openExternal(officialLive));
document.getElementById('openResultsBtn').addEventListener('click',()=>openExternal(officialResults));
document.getElementById('refreshBtn').addEventListener('click',()=>{
  showToast('Prototipe diperbarui. Data otomatis belum terhubung.');
});
