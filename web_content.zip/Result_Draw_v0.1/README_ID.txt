RESULT DRAW v0.1 — PROTOTIPE
================================

Isi:
- index.html: halaman aplikasi
- style.css: tema Dark Premium hitam & emas
- app.js: navigasi dan tombol menuju halaman resmi
- manifest.json: metadata PWA sederhana

PENTING:
Ini adalah prototipe antarmuka web, BELUM APK Android dan BELUM mengambil data result otomatis.
Angka hasil nyata sengaja tidak dibuat-buat. Integrasi result membutuhkan API atau sumber yang dapat diakses dan penggunaannya diizinkan.
Tombol Live Draw mengarah ke halaman resmi HokiDraw. Apakah halaman tetap terbuka di dalam aplikasi bergantung pada builder/WebView yang digunakan dan kebijakan situs.

Cara melihat prototipe:
1. Ekstrak ZIP.
2. Buka index.html di browser HP atau unggah folder ke hosting statis.
3. Navigasi Home, Result, Live Draw, dan Menu dapat dicoba.

Langkah berikut:
- Uji antarmuka.
- Pilih metode build APK gratis.
- Uji WebView dan navigasi eksternal.
- Periksa API/sumber data resmi untuk riwayat result sebelum menambahkan pengambilan otomatis.

Tidak ada SDK iklan pihak ketiga pada prototipe ini.
