// إدارة الحالة الأساسية
let state = {
    isSetupComplete: localStorage.getItem('alanzi_setup') === 'true',
    isDarkMode: localStorage.getItem('alanzi_theme') !== 'light',
    wifiConnected: localStorage.getItem('alanzi_wifi') !== 'false',
    currentWallpaper: localStorage.getItem('alanzi_wallpaper') || 'default'
};

// قائمة شبكات الواي فاي المحاكاة
const wifiNetworks = [
    { id: 'alanzi_home', name: 'ALANZI HOME', secure: false, isDefault: true },
    { id: 'tp_link', name: 'TP-Link_5G', secure: true, isDefault: false },
    { id: 'galaxy', name: 'Galaxy A16', secure: true, isDefault: false },
    { id: 'home_wifi', name: 'Home WiFi', secure: true, isDefault: false },
    { id: 'netgear', name: 'NETGEAR', secure: true, isDefault: false },
    { id: 'dlink', name: 'D-Link', secure: true, isDefault: false },
    { id: 'huawei', name: 'HUAWEI WiFi', secure: true, isDefault: false }
];

let selectedNetworkToConnect = null;

// بدء التشغيل
window.onload = () => {
    // إخفاء شاشة التشغيل بعد ثانيتين
    setTimeout(() => {
        document.getElementById('boot-screen').classList.add('hidden');
        
        if (state.isSetupComplete) {
            startMainOS();
        } else {
            startSetupWizard();
        }
    }, 2000);

    applyTheme();
    updateClock();
    setInterval(updateClock, 1000);
};

// --- معالج الإعداد (Setup Wizard) ---
function startSetupWizard() {
    document.getElementById('setup-wizard').classList.remove('hidden');
    renderWifiNetworks();
}

function renderWifiNetworks() {
    const container = document.getElementById('wifi-networks-container');
    container.innerHTML = '';

    wifiNetworks.forEach(net => {
        const isConnected = (net.isDefault && state.wifiConnected);
        
        const div = document.createElement('div');
        div.className = `wifi-item ${isConnected ? 'connected' : ''}`;
        div.onclick = () => handleNetworkClick(net);

        let statusText = isConnected ? '<span class="wifi-status">Connected</span>' : '';
        let icon = net.secure ? '🔒' : '📶';
        let checkMark = isConnected ? '<span class="wifi-check">✓</span>' : '';

        div.innerHTML = `
            <div class="wifi-info">
                <span class="wifi-icon">${icon}</span>
                <div>
                    <div class="wifi-name">${net.name}</div>
                    ${statusText}
                </div>
            </div>
            ${checkMark}
        `;
        container.appendChild(div);
    });
}

function handleNetworkClick(network) {
    if (!document.getElementById('wifi-toggle').checked) return;

    // إذا كانت الشبكة هي ALANZI HOME
    if (network.isDefault) {
        state.wifiConnected = true;
        localStorage.setItem('alanzi_wifi', 'true');
        renderWifiNetworks();
        return;
    }

    // إذا كانت شبكة أخرى، نطلب كلمة المرور
    selectedNetworkToConnect = network;
    document.getElementById('modal-wifi-title').innerText = `الاتصال بـ ${network.name}`;
    document.getElementById('wifi-password').value = '';
    document.getElementById('wifi-error-msg').classList.add('hidden');
    document.getElementById('btn-connect-wifi').classList.remove('hidden');
    document.getElementById('btn-retry-wifi').classList.add('hidden');
    document.getElementById('wifi-modal').classList.remove('hidden');
}

function closeWifiModal() {
    document.getElementById('wifi-modal').classList.add('hidden');
    selectedNetworkToConnect = null;
}

function attemptWifiConnect() {
    const btnConnect = document.getElementById('btn-connect-wifi');
    const btnRetry = document.getElementById('btn-retry-wifi');
    const errorMsg = document.getElementById('wifi-error-msg');
    
    // محاكاة التحميل
    btnConnect.innerText = 'جاري الاتصال...';
    btnConnect.disabled = true;

    setTimeout(() => {
        // دائماً يظهر خطأ للشبكات غير ALANZI HOME
        errorMsg.classList.remove('hidden');
        errorMsg.innerText = 'Incorrect password. Please try again.';
        
        btnConnect.classList.add('hidden');
        btnRetry.classList.remove('hidden');
        
        // التأكد من بقاء ALANZI HOME متصلة
        state.wifiConnected = true;
        localStorage.setItem('alanzi_wifi', 'true');
    }, 1500);
}

document.getElementById('btn-setup-next').onclick = () => {
    localStorage.setItem('alanzi_setup', 'true');
    document.getElementById('setup-wizard').classList.add('hidden');
    startMainOS();
};

// --- النظام الرئيسي (Main OS) ---
function startMainOS() {
    document.getElementById('main-os').classList.remove('hidden');
    updateWifiStatusIcon();
}

function updateClock() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    
    // تحديث الساعة في شريط الحالة والشاشة الرئيسية
    if (document.getElementById('status-time')) document.getElementById('status-time').innerText = timeStr;
    if (document.getElementById('home-time')) document.getElementById('home-time').innerText = timeStr;
    
    // تحديث التاريخ
    if (document.getElementById('home-date')) {
        const options = { weekday: 'long', day: 'numeric', month: 'long' };
        const dateStr = now.toLocaleDateString('ar-SA', options);
        document.getElementById('home-date').innerText = dateStr;
    }
}

// --- إدارة التطبيقات والنوافذ ---
function openApp(appName) {
    if (appName === 'settings') document.getElementById('app-settings').classList.remove('hidden');
    if (appName === 'store') document.getElementById('app-store').classList.remove('hidden');
}

function closeApp(appName) {
    if (appName === 'settings') document.getElementById('app-settings').classList.add('hidden');
    if (appName === 'store') document.getElementById('app-store').classList.add('hidden');
}

function goHome() {
    document.querySelectorAll('.app-screen').forEach(el => el.classList.add('hidden'));
}

function toggleAppDrawer() {
    // يمكن إضافة منطق لفتح درج التطبيقات هنا
    alert('درج التطبيقات قيد التطوير');
}

function toggleControlCenter() {
    const cc = document.getElementById('control-center');
    if (cc.classList.contains('hidden')) {
        cc.classList.remove('hidden');
    } else {
        cc.classList.add('hidden');
    }
}

// --- الإعدادات (Settings) ---
function applyTheme() {
    if (state.isDarkMode) {
        document.body.classList.remove('light-mode');
        document.body.classList.add('dark-mode');
        document.getElementById('theme-status').innerText = 'مفعل';
    } else {
        document.body.classList.add('light-mode');
        document.body.classList.remove('dark-mode');
        document.getElementById('theme-status').innerText = 'معطل';
    }
}

function toggleTheme() {
    state.isDarkMode = !state.isDarkMode;
    localStorage.setItem('alanzi_theme', state.isDarkMode ? 'dark' : 'light');
    applyTheme();
}

function changeWallpaper() {
    const colors = ['#101218', '#2b1b3d', '#1b3d2b', '#3d2b1b'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    document.getElementById('home-screen').style.backgroundColor = randomColor;
}

function updateWifiStatusIcon() {
    const icon = document.getElementById('status-wifi-icon');
    if (state.wifiConnected) {
        icon.innerText = '📶';
        icon.style.color = 'white';
    } else {
        icon.innerText = '📵';
        icon.style.color = 'gray';
    }
}

// تفعيل زر الواي فاي في معالج الإعداد
document.getElementById('wifi-toggle').addEventListener('change', (e) => {
    if (!e.target.checked) {
        state.wifiConnected = false;
        localStorage.setItem('alanzi_wifi', 'false');
    } else {
        state.wifiConnected = true;
        localStorage.setItem('alanzi_wifi', 'true');
    }
    renderWifiNetworks();
});