/* ALANZI ANDROID - script.js
   1 State  2 Icons/Data  3 Wi-Fi  4 System UI  5 Settings  6 Apps  7 Gestures  8 Boot */
(() => {
'use strict';

/* ---------- 1. State (saved in LocalStorage: "az.state") ---------- */
const S = Object.assign({lang:'ar',dark:false,wall:0,wifi:true,seen:false,done:false,bt:true,data:true,airplane:false,dnd:false,saver:false,
  night:false,pct:true,h24:false,tap:true,labels:true,roundIcons:false,showClock:true,showWx:true,cols5:false,lkDate:true,lkHint:true,bold:false,noanim:false,bigIcons:false,touches:false,widgets:false,bright:100,vol:60,inst:[],notes:[],cnt:0}, JSON.parse(localStorage.getItem('az.state') || '{}'));
const save = () => { try { localStorage.setItem('az.state', JSON.stringify(S)); } catch (e) {} };
const L = (a, e) => S.lang === 'ar' ? a : e;
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const wait = ms => new Promise(r => setTimeout(r, ms));
const os = $('#os');
let camStream = null, appId = null, sub = null, drawerOpen = false, panel = null, recentsOpen = false, torch = false, lockOn = false, batt = '87%', timers = [], inCall = false;
const RECENT = [], NOTIFS = [];

/* ---------- 2. Icons & data ---------- */
const P = {
 settings:'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.49.49 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
 phone:'M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z',
 store:'M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm0 10c-2.76 0-5-2.24-5-5h2c0 1.66 1.34 3 3 3s3-1.34 3-3h2c0 2.76-2.24 5-5 5z',
 clock:'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z',
 calc:'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM7.5 17.5H6V16h1.5v1.5zM9 9.5H6V8h3v1.5zm5 8h-4V16h4v1.5zm4 0h-2.5V16H18v1.5zm0-3H6V13h12v1.5zM18 9.5h-3V8h3v1.5z',
 notes:'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
 gallery:'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z',
 flash:'M6 2v6l3 3v11h6V11l3-3V2H6zm6 11.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z',
 count:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z',
 dice:'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM7.5 18c-.83 0-1.5-.67-1.5-1.5S6.67 15 7.5 15s1.5.67 1.5 1.5S8.33 18 7.5 18zm0-9C6.67 9 6 8.33 6 7.5S6.67 6 7.5 6 9 6.67 9 7.5 8.33 9 7.5 9zm4.5 4.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4.5 4.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm0-9c-.83 0-1.5-.67-1.5-1.5S15.67 6 16.5 6s1.5.67 1.5 1.5S17.33 9 16.5 9z',
 wifi:'M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9zm8 8l3 3 3-3a4.24 4.24 0 00-6 0zm-4-4l2 2a7.07 7.07 0 0110 0l2-2C15.14 9.14 8.87 9.14 5 13z',
 bt:'M17.71 7.71L12 2h-1v7.59L6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 11 14.41V22h1l5.71-5.71-4.3-4.29 4.3-4.29zM13 5.83l1.88 1.88L13 9.59V5.83zm1.88 10.46L13 18.17v-3.76l1.88 1.88z',
 dnd:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7 13v-2h10v2H7z',
 plane:'M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z',
 data:'M16 17.01V10h-2v7.01h-3L15 21l4-3.99h-3zM9 3L5 6.99h3V14h2V6.99h3L9 3z',
 batt:'M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4z',
 moon:'M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 01-4.4 2.26 5.403 5.403 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z',
 display:'M20 15.31L23.31 12 20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69zM12 18V6c3.31 0 6 2.69 6 6s-2.69 6-6 6z',
 lock:'M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z',
 sound:'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z',
 bell:'M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z',
 storage:'M2 20h20v-4H2v4zm2-3h2v2H4v-2zM2 4v4h20V4H2zm4 3H4V5h2v2zm-4 7h20v-4H2v4zm2-3h2v2H4v-2z',
 info:'M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z',
 lang:'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zm6.93 6h-2.95a15.65 15.65 0 00-1.38-3.56A8.03 8.03 0 0118.92 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14C4.1 13.36 4 12.69 4 12s.1-1.36.26-2h3.38c-.08.66-.14 1.32-.14 2 0 .68.06 1.34.14 2H4.26z',
 restart:'M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
 power:'M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A6.92 6.92 0 0119 12c0 3.87-3.13 7-7 7A6.995 6.995 0 018.59 6.58L7.17 5.17A8.932 8.932 0 003 12a9 9 0 0018 0c0-2.74-1.23-5.18-3.17-6.83z',
 search:'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
 sun:'M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z',
 sig:'M2 22h20V2z',
 camera:'M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z',
 home:'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
 access:'M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z',
 dev:'M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z',
 apps:'M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z'
};
const ic = (p, c = 'i') => `<svg class="${c}" viewBox="0 0 24 24"><path d="${p}"/></svg>`;
const APPS = [
 {id:'phone',ar:'الهاتف',en:'Phone',c:'#00a152',c2:'#5be08f',ic:P.phone},{id:'camera',ar:'الكاميرا',en:'Camera',c:'#d32f2f',c2:'#ff7961',ic:P.camera},{id:'gallery',ar:'المعرض',en:'Gallery',c:'#3367d6',c2:'#6e9bf8',ic:P.gallery},
 {id:'store',ar:'المتجر',en:'Store',c:'#7b1fa2',c2:'#c158dc',ic:P.store},{id:'settings',ar:'الإعدادات',en:'Settings',c:'#00796b',c2:'#3fbfae',ic:P.settings},
 {id:'clock',ar:'الساعة',en:'Clock',c:'#ef6c00',c2:'#ffb74d',ic:P.clock},{id:'calc',ar:'الحاسبة',en:'Calculator',c:'#1565c0',c2:'#5e92f3',ic:P.calc},
 {id:'notes',ar:'الملاحظات',en:'Notes',c:'#f57f17',c2:'#ffca3a',ic:P.notes}];
const EXTRA = [{id:'flash',ar:'المصباح',en:'Flashlight',c:'#fb8c00',c2:'#ffcc4d',ic:P.flash},{id:'count',ar:'العداد',en:'Counter',c:'#2e7d32',c2:'#66bb6a',ic:P.count},{id:'dice',ar:'النرد',en:'Dice',c:'#c62828',c2:'#ef6b6b',ic:P.dice}];
const allApps = () => [...APPS, ...EXTRA.filter(a => S.inst.includes(a.id))];
const byId = id => [...APPS, ...EXTRA].find(a => a.id === id);
const nm = a => L(a.ar, a.en);
const grad = a => `linear-gradient(145deg,${a.c2 || a.c},${a.c})`;
// Wallpapers: [base color, [color, x%, y%, radius%]...]  (add your own here)
const WALLS = [
 ['#002b28',[['#009688',10,10,25],['#00bfa5',90,40,15],['#00695c',20,85,30],['#009688',85,90,18],['#00897b',50,5,12]]],
 ['#07121f',[['#00C2FF',12,12,24],['#0b6e99',88,38,16],['#0a4a6e',20,86,30],['#00C2FF',86,92,14],['#08577c',50,4,12]]],
 ['#3a1230',[['#e8a2c3',12,10,22],['#c94b87',90,45,16],['#7b2a6b',20,86,30],['#f0a25a',85,92,16],['#a63a7a',50,5,12]]],
 ['#1a1030',[['#7e57c2',10,12,24],['#b39ddb',90,42,14],['#4527a0',20,86,30],['#9575cd',85,92,16],['#5e35b1',50,5,12]]],
 ['#111418',[['#2b3038',10,10,26],['#3a414c',90,40,15],['#1d2127',20,85,30],['#2b3038',85,90,18],['#353b45',50,5,12]]],
 ['#0b2a12',[['#2e7d32',10,10,25],['#9ccc65',90,40,14],['#1b5e20',20,85,30],['#66bb6a',85,90,16],['#388e3c',50,5,12]]]];
const wallImg = w => w[1].map(([c, x, y, r]) => `radial-gradient(circle at ${x}% ${y}%,${c} 0,${c} ${r}%,transparent ${r + .1}%)`).join(',');
const fmtT = d => { let h = d.getHours(); if (!S.h24) h = h % 12 || 12; return `${S.h24 ? String(h).padStart(2,'0') : h}:${String(d.getMinutes()).padStart(2,'0')}`; };
let ac; function beep(f = 660, d = .06, force) { if (!force && !S.tap) return; try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f; g.gain.value = S.vol / 400; o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + d); } catch (e) {} }
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t.t); t.t = setTimeout(() => t.classList.remove('show'), 1900); }

/* ---------- 3. Wi-Fi (fully simulated; never touches real networks) ---------- */
const NETS = [{n:'ALANZI HOME',l:4,sec:false},{n:'TP-Link_5G',l:4,sec:true},{n:'Galaxy A16',l:3,sec:true},{n:'Home WiFi',l:3,sec:true},{n:'NETGEAR',l:2,sec:true},{n:'D-Link',l:2,sec:true},{n:'HUAWEI WiFi',l:1,sec:true}];
function wifiSvg(l) {
  const a = ['M8.5 15.5a5 5 0 017 0', 'M5.5 12.2a9.3 9.3 0 0113 0', 'M2.5 8.9a13.5 13.5 0 0119 0'];
  return `<svg class="ic" viewBox="0 0 24 24">${a.map((d, i) => `<path d="${d}" opacity="${i <= l - 2 ? 1 : .25}"/>`).join('')}<circle cx="12" cy="19" r="1.4" fill="currentColor" stroke="none"/></svg>`;
}
const LOCK_SVG = '<svg class="lk" viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg>';
const CHECK_SVG = '<svg class="chk" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="currentColor"/><path d="M7.5 12.5l3 3 6-6.5" fill="none" stroke="#00222c" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function connected() { S.seen = true; save(); refresh(); notify(L('متصل بـ ALANZI HOME', 'Connected to ALANZI HOME'), L('اتصال تجريبي', 'Simulated connection')); }
function setWifi(v, anim) {
  S.wifi = v; S.seen = false; if (v) S.airplane = false; save(); refresh();
  if (v && !anim) setTimeout(() => { if (S.wifi && !S.seen) connected(); }, 1200);
}
function renderWifi(box) {
  box.innerHTML = `<div class="wf-head"><h3>Wi-Fi</h3><label class="swl"><i class="sw ${S.wifi ? 'on' : ''}" id="wfsw"></i></label></div><div class="list" id="wflist" style="background:transparent;box-shadow:none"></div>`;
  const sw = $('#wfsw', box), list = $('#wflist', box); let run = 0;
  const row = (n, small, state) => { const d = document.createElement('div'); d.className = 'item net' + (state === 1 ? ' on' : ''); d.style.background = 'var(--card)'; d.innerHTML = `${wifiSvg(n.l)}<div class="txt"><b>${n.n}</b><small>${small}</small></div>${state === 1 ? CHECK_SVG : n.sec ? LOCK_SVG : ''}`; return d; };
  async function draw() {
    const id = ++run;
    if (!S.wifi) { list.innerHTML = `<p class="muted c">${L('Wi-Fi متوقف','Wi-Fi is off')}</p>`; return; }
    list.innerHTML = '<div class="spin"></div>'; await wait(900); if (id !== run) return;
    list.innerHTML = '';
    const home = row(NETS[0], S.seen ? L('متصل', 'Connected') : '', S.seen ? 1 : 0);
    if (!S.seen) home.querySelector('small').innerHTML = `<span class="spin s"></span> ${L('جارٍ الاتصال…', 'Connecting…')}`;
    list.append(home);
    if (!S.seen) { await wait(1100); if (id !== run) return; connected(); home.replaceWith(row(NETS[0], L('متصل', 'Connected'), 1)); }
    const h = document.createElement('div'); h.className = 'sh'; h.textContent = L('الشبكات المتاحة', 'Available networks'); h.style.background = 'transparent'; list.append(h);
    NETS.slice(1).forEach(n => { const r = row(n, L('محمية', 'Secured'), 0); r.onclick = () => askPass(n); list.append(r); });
  }
  sw.onclick = () => { const v = !S.wifi; sw.classList.toggle('on', v); setWifi(v, true); draw(); };
  draw();
}
function dlg(html) { const d = $('#dialog'); d.innerHTML = `<div class="dlg">${html}</div>`; d.classList.remove('hidden'); d.onclick = e => { if (e.target === d) closeDlg(); }; return d; }
function closeDlg() { $('#dialog').classList.add('hidden'); }
// Every other network always rejects the password and never changes the ALANZI HOME link.
function askPass(n) {
  const d = dlg(`<h3>${n.n}</h3><input id="pw" type="password" placeholder="${L('كلمة المرور', 'Password')}"><div class="err"></div><div class="btns"><button class="flat" id="pc">${L('إلغاء', 'Cancel')}</button><button class="flat" id="po">${L('اتصال', 'Connect')}</button></div>`);
  const pw = $('#pw', d), err = $('.err', d), ok = $('#po', d); let failed = false, busy = false;
  $('#pc', d).onclick = closeDlg; setTimeout(() => pw.focus(), 250);
  ok.onclick = async () => {
    if (busy) return;
    if (failed) { failed = false; err.textContent = ''; pw.value = ''; ok.textContent = L('اتصال', 'Connect'); pw.focus(); return; }
    if (!pw.value) { pw.classList.add('shake'); setTimeout(() => pw.classList.remove('shake'), 400); return; }
    busy = true; ok.innerHTML = '<span class="spin s"></span>'; await wait(1400); busy = false; failed = true;
    err.textContent = 'Incorrect password'; ok.textContent = L('إعادة المحاولة', 'Retry'); pw.classList.add('shake'); setTimeout(() => pw.classList.remove('shake'), 400);
  };
}

/* ---------- 4. System UI ---------- */
function notify(t, b, c = '#00897b', p = P.settings) { if (S.dnd) return; NOTIFS.unshift({t, b, c, p}); renderNotifs(); }
function renderNotifs() {
  const d = new Date(), el = $('#notif');
  el.innerHTML = `<div class="n-top"><b>${fmtT(d)}</b><button class="flat" id="nclr">${L('مسح الكل', 'Clear all')}</button></div>` +
   (NOTIFS.length ? NOTIFS.map((n, i) => `<div class="n"><div class="ico" style="background:${n.c}">${ic(n.p)}</div><div class="txt"><b>${n.t}</b><small>${n.b}</small></div><button data-x="${i}">${ic('M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z')}</button></div>`).join('') : `<p class="muted c">${L('لا توجد إشعارات', 'No notifications')}</p>`);
  $('#nclr').onclick = () => { NOTIFS.length = 0; renderNotifs(); };
  $$('[data-x]', el).forEach(b => b.onclick = () => { NOTIFS.splice(+b.dataset.x, 1); renderNotifs(); });
  $$('.n', el).forEach((n, i) => { const item = NOTIFS[i]; let x0 = null;
    n.onpointerdown = e => { if (e.target.closest('button')) return; x0 = e.clientX; n.style.transition = 'none'; n.setPointerCapture(e.pointerId); };
    n.onpointermove = e => { if (x0 === null) return; const d = e.clientX - x0; n.style.transform = `translateX(${d}px)`; n.style.opacity = 1 - Math.abs(d) / 260; };
    n.onpointerup = e => { if (x0 === null) return; const d = e.clientX - x0; x0 = null; n.style.transition = '.2s';
      if (Math.abs(d) > 90) { n.style.transform = `translateX(${d > 0 ? 420 : -420}px)`; n.style.opacity = 0; setTimeout(() => { const k = NOTIFS.indexOf(item); if (k >= 0) NOTIFS.splice(k, 1); renderNotifs(); }, 200); }
      else { n.style.transform = ''; n.style.opacity = ''; } }; });
}
const TILES = [['wifi','wifi','Wi-Fi'],['bt','bt','Bluetooth'],['dnd','dnd',['عدم الإزعاج','Do not disturb']],['airplane','plane',['وضع الطائرة','Airplane']],['data','data',['بيانات الجوّال','Mobile data']],
 ['saver','batt',['توفير البطارية','Battery saver']],['dark','moon',['الوضع الداكن','Dark mode']],['night','display',['إضاءة ليلية','Night light']],['torch','flash',['المصباح','Flashlight']],['lock','lock',['قفل','Lock']],['stop','power',['إطفاء','Power off']]];
function renderCC() {
  const on = k => k === 'torch' ? torch : k === 'lock' ? false : S[k];
  $('#cc').innerHTML = `   <div class="sl">${ic(P.sun)}<input type="range" id="br" min="20" max="100" value="${S.bright}"></div>
   <div class="tiles">${TILES.map(([k, i, l]) => `<div class="tile ${on(k) ? 'on' : ''}" data-k="${k}"><i>${ic(P[i])}</i>${Array.isArray(l) ? L(l[0], l[1]) : l}</div>`).join('')}</div>
   <div class="qfoot"><svg viewBox="0 0 24 24" id="qs-set"><path d="${P.settings}"/></svg><span>ALANZI ANDROID</span></div>`;
  $$('.tile').forEach(t => t.onclick = () => tile(t.dataset.k));
  $('#br').oninput = e => { S.bright = +e.target.value; save(); refresh(true); };
  $('#qs-set').onclick = () => openApp('settings');
}
function tile(k) {
  if (k === 'wifi') return setWifi(!S.wifi);
  if (k === 'lock') { closePanels(); return showLock(); }
  if (k === 'torch') return setTorch(!torch);
  if (k === 'stop') { closePanels(); return powerMenu(); }
  set(k, !S[k]);
}
function set(k, v) {
  S[k] = v;
  if (k === 'airplane' && v) { S.wifi = false; S.bt = false; S.data = false; S.seen = false; }
  if ((k === 'bt' || k === 'data') && v) S.airplane = false;
  save(); refresh();
}
/* Power menu: Power off / Restart */
function powerMenu() {
  const d = dlg(`<h3>${L('خيارات الطاقة', 'Power options')}</h3><div class="pm" id="pm-off">${ic(P.power)}<b>${L('إطفاء', 'Power off')}</b></div><div class="pm" id="pm-re">${ic(P.restart)}<b>${L('إعادة التشغيل', 'Restart')}</b></div><div class="btns"><button class="flat" id="pm-c">${L('إلغاء', 'Cancel')}</button></div>`);
  $('#pm-c', d).onclick = closeDlg;
  $('#pm-re', d).onclick = () => { closeDlg(); const o = $('#off'); o.classList.remove('hidden'); o.innerHTML = '<div class="spin"></div>'; setTimeout(() => location.reload(), 1300); };
  $('#pm-off', d).onclick = () => { closeDlg(); shutdown(); };
}
function shutdown() {
  const o = $('#off'); o.classList.remove('hidden'); o.onpointerdown = o.onpointerup = null;
  o.innerHTML = `<div class="spin"></div><p>${L('جارٍ الإيقاف…', 'Powering off…')}</p>`;
  setTimeout(() => { o.innerHTML = `<p class="hint-off">${L('اضغط مطولًا على الشاشة لتشغيل الجهاز', 'Press and hold the screen to power on')}</p>`; let t;
    o.onpointerdown = () => { t = setTimeout(() => location.reload(), 900); }; o.onpointerup = () => clearTimeout(t); }, 1500);
}
function setTorch(v) { torch = v; const t = $('#torch'); t.classList.toggle('hidden', !v); t.innerHTML = v ? `<button class="fill">${L('إطفاء المصباح', 'Turn off')}</button>` : ''; t.onclick = () => setTorch(false); renderCC(); }
function chrome() { os.classList.toggle('onlight', !!(appId || drawerOpen || panel) && !recentsOpen && !lockOn); }
function refresh(light) {
  document.documentElement.dataset.theme = S.dark ? 'dark' : 'light';
  $('#dim').style.opacity = ((100 - S.bright) / 100) * .7 + (S.saver ? .12 : 0);
  $('#night').style.display = S.night ? 'block' : 'none';
  const ph = $('#phone').classList; ph.toggle('nolabels', !S.labels); ph.toggle('round', S.roundIcons); ph.toggle('nohclock', !S.showClock); ph.toggle('nowx', !S.showWx); ph.toggle('cols5', S.cols5); ph.toggle('nowg', !S.widgets);
  ph.toggle('nolkdate', !S.lkDate); ph.toggle('nolkhint', !S.lkHint); ph.toggle('bold', S.bold); ph.toggle('noanim', S.noanim); ph.toggle('bigicons', S.bigIcons);
  if (light) return;
  const w = WALLS[S.wall], wl = $('#wall'); wl.style.backgroundColor = w[0]; wl.style.backgroundImage = wallImg(w);
  $('#sb-icons').innerHTML = [S.wifi && P.wifi, S.bt && P.bt, S.dnd && P.dnd, S.airplane && P.plane, !S.airplane && P.sig, P.batt].filter(Boolean).map(p => ic(p, 'i')).join('') + (S.pct ? ` <span>${batt}</span>` : '');
  $('#pill-t').textContent = L('ابحث في التطبيقات', 'Search apps');
  $('#search').placeholder = L('بحث في التطبيقات', 'Search apps');
  $('#rc-clear').textContent = L('مسح الكل', 'CLEAR ALL');
  renderCC(); renderNotifs(); tick(); chrome();
}
if (navigator.getBattery) navigator.getBattery().then(b => { const u = () => { batt = Math.round(b.level * 100) + '%'; refresh(); }; u(); b.onlevelchange = u; }).catch(() => {});
function tick() {
  const d = new Date(), loc = S.lang === 'ar' ? 'ar-SA-u-nu-latn-ca-gregory' : 'en-US', tm = fmtT(d), dt = d.toLocaleDateString(loc, {weekday:'long', day:'numeric', month:'long'});
  $('#clock').textContent = tm; $('#lk-time').textContent = tm; $('#sb-time').textContent = tm; $('#date').textContent = dt; $('#lk-date').textContent = dt;
  const pc = parseInt(batt) || 0; $('#ring').style.setProperty('--v', pc); $('#w-pct').textContent = pc; $('#w-bl').textContent = L('البطارية', 'Battery');
  $('#w-nt').textContent = S.wifi ? 'ALANZI HOME' : 'Wi-Fi'; $('#w-ns').textContent = S.wifi ? L('متصل', 'Connected') : L('متوقف', 'Off');
  $('#wx').textContent = S.wifi ? `28° · ${L('مشمس · الرياض', 'Sunny · Riyadh')}` : L('الطقس غير متاح — لا يوجد اتصال', 'Weather unavailable — no connection');
}
setInterval(tick, 5000);
function applyLang() {
  document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'ar' ? 'rtl' : 'ltr';
  $$('[data-ar]').forEach(e => e.textContent = L(e.dataset.ar, e.dataset.en));
  renderIcons(); refresh();
}
const iconHTML = a => `<div class="app-i" data-app="${a.id}"><div class="bx" style="background:${grad(a)}">${ic(a.ic)}</div>${nm(a)}</div>`;
function renderIcons(q = '') {
  $('#dock').innerHTML = ['phone','camera','store','settings'].map(id => iconHTML(byId(id))).join('');
  $('#all').innerHTML = allApps().filter(a => (a.ar + a.en).toLowerCase().includes(q.toLowerCase())).map(iconHTML).join('');
  $$('[data-app]').forEach(e => e.onclick = () => { closeDrawer(); openApp(e.dataset.app); });
}
function openDrawer() { drawerOpen = true; $('#drawer').classList.add('open'); chrome(); }
function closeDrawer() { drawerOpen = false; $('#drawer').classList.remove('open'); $('#search').value = ''; renderIcons(); chrome(); }
function openPanel(n) { closePanels(); panel = n; $('#' + n).classList.add('open'); $('#scrim').classList.add('on'); if (n === 'notif') renderNotifs(); chrome(); }
function closePanels() { panel = null; $$('.panel').forEach(p => p.classList.remove('open')); $('#scrim').classList.remove('on'); chrome(); }
function showLock() { lockOn = true; const l = $('#lock'); l.style.transition = ''; l.style.transform = ''; l.style.opacity = ''; l.classList.remove('hidden'); chrome(); }
function unlock() { const l = $('#lock'); l.style.transition = 'transform .35s ease-in,opacity .35s'; l.style.transform = 'translateY(-100%)'; l.style.opacity = 0; setTimeout(() => { l.classList.add('hidden'); lockOn = false; chrome(); }, 350); }
function openRecents() { closePanels(); recentsOpen = true; const r = $('#recents'); r.classList.add('open');
  $('#rc-list').innerHTML = RECENT.length ? RECENT.map(id => { const a = byId(id); return `<div class="rc" data-r="${id}"><div class="ico" style="background:${grad(a)}">${ic(a.ic)}</div><b>${nm(a)}</b></div>`; }).join('') : `<p style="color:#fff">${L('لا توجد تطبيقات حديثة', 'No recent apps')}</p>`;
  $$('[data-r]').forEach(e => e.onclick = () => { closeRecents(); openApp(e.dataset.r); }); chrome(); }
function closeRecents() { recentsOpen = false; $('#recents').classList.remove('open'); chrome(); }
$('#rc-clear').onclick = () => { RECENT.length = 0; openRecents(); };
function goHome() { closeDlg(); closePanels(); closeRecents(); closeDrawer(); if (appId) closeApp(); }
function back() {
  if (!$('#dialog').classList.contains('hidden')) return closeDlg();
  if (lockOn) return;
  if (panel) return closePanels();
  if (recentsOpen) return closeRecents();
  if (appId) { if (inCall) return endCall(); if (appId === 'settings' && sub) return openApp('settings'); return closeApp(); }
  if (drawerOpen) closeDrawer();
}
$('#n-home').innerHTML = '<svg viewBox="0 0 22 22"><circle cx="11" cy="11" r="9"/></svg>'; $('#n-rec').innerHTML = '<svg viewBox="0 0 20 20"><rect x="2" y="2" width="16" height="16" rx="2"/></svg>'; $('#n-back').innerHTML = '<svg viewBox="0 0 22 22"><path d="M4 3l15 8-15 8z" style="transform:scaleX(-1);transform-origin:center"/></svg>';
$('#n-home').onclick = goHome; $('#n-back').onclick = back; $('#n-rec').onclick = () => recentsOpen ? closeRecents() : openRecents();
$('#app-back').innerHTML = ic('M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z'); $('#app-back').onclick = back;
$('#phone').addEventListener('pointerdown', e => { if (!S.touches) return; const r = $('#phone').getBoundingClientRect(), t = document.createElement('div'); t.className = 'touch'; t.style.left = (e.clientX - r.left) + 'px'; t.style.top = (e.clientY - r.top) + 'px'; $('#phone').append(t); setTimeout(() => t.remove(), 450); });
$('#scrim').onclick = closePanels;
$('#w-batt').onclick = () => openApp('settings', 'battery'); $('#w-net').onclick = () => openApp('settings', 'wifi');
$('#pill').onclick = () => { openDrawer(); setTimeout(() => $('#search').focus(), 350); };
$('#trig').onclick = openDrawer;
$('#search').oninput = e => renderIcons(e.target.value);
$('#sb-time').onclick = () => openPanel('notif'); $('#sb-icons').onclick = () => openPanel('cc');

/* ---------- 5. Settings ---------- */
function cats() {
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '-';
  return [
 {id:'network',c:'#2196f3',p:P.wifi,n:L('الشبكة والإنترنت','Network & internet'),s:L('Wi-Fi، بيانات الجوّال، وضع الطائرة','Wi-Fi, mobile data, airplane mode'),
  items:[['nav','Wi-Fi',S.wifi ? 'ALANZI HOME' : L('متوقف','Off'),() => openApp('settings','wifi')],['sw','data',L('بيانات الجوّال','Mobile data'),'4G',1],['sw','airplane',L('وضع الطائرة','Airplane mode'),L('يوقف Wi-Fi والبلوتوث والبيانات','Turns off Wi-Fi, Bluetooth and data'),0]]},
 {id:'connected',c:'#3f51b5',p:P.bt,n:L('الأجهزة المتصلة','Connected devices'),s:'Bluetooth',items:[['sw','bt','Bluetooth',L('يظهر في شريط الحالة','Shown in the status bar'),1]]},
 {id:'apps',c:'#e91e63',p:P.apps,n:L('التطبيقات','Apps'),s:L('المثبتة وإدارتها','Installed apps and management'),go:'apps'},
 {id:'display',c:'#ffa726',p:P.display,n:L('الشاشة','Display'),s:L('الوضع الداكن، السطوع، اللغة','Dark mode, brightness, language'),
  items:[['sw','dark',L('الوضع الداكن','Dark mode'),L('تغيير مظهر النظام','Change the system theme'),0],['rg','bright',L('السطوع','Brightness')],['sw','night',L('إضاءة ليلية','Night light'),L('لون دافئ للشاشة','Warm screen tint'),0],['nav',L('اللغة','Language'),L('العربية','English'),() => openApp('settings','language')]]},
 {id:'wallpaper',c:'#d81b60',p:P.gallery,n:L('الخلفية','Wallpaper'),s:L('اختر خلفية الشاشة','Choose your wallpaper'),go:'wallpaper'},
 {id:'home',c:'#00bcd4',p:P.home,n:L('الشاشة الرئيسية','Home screen'),s:L('الأيقونات، الساعة، الطقس','Icons, clock, weather'),
  items:[['h',L('الشاشة الرئيسية','Home')],['sw','showClock',L('الساعة','Clock'),L('إظهار الساعة الكبيرة','Show the big clock'),1],['sw','showWx',L('التاريخ والطقس','Date & weather'),'',1],['sw','widgets',L('الودجات','Widgets'),L('البطارية والشبكة','Battery and network'),0],['sw','labels',L('أسماء التطبيقات','App labels'),L('تحت الأيقونات في الشاشة الرئيسية','Under home-screen icons'),1],
   ['h',L('الأيقونات','Icons')],['sw','roundIcons',L('أيقونات دائرية','Round icons'),L('بدل المربعة بحواف مدورة','Instead of rounded squares'),0],['sw','bigIcons',L('أيقونات كبيرة','Large icons'),'',0],['sw','cols5',L('5 أعمدة في الدرج','5 columns in drawer'),L('بدل 4 أعمدة','Instead of 4'),0]]},
 {id:'sound',c:'#9c27b0',p:P.sound,n:L('الصوت','Sound'),s:L('مستوى الصوت، أصوات اللمس','Volume, touch sounds'),
  items:[['rg','vol',L('مستوى الصوت','Volume')],['sw','tap',L('أصوات اللمس','Touch sounds'),L('أصوات لوحات الأرقام','Keypad sounds'),1],['sw','dnd',L('عدم الإزعاج','Do not disturb'),L('كتم الإشعارات','Mute notifications'),0]]},
 {id:'notifications',c:'#ff5722',p:P.bell,n:L('الإشعارات','Notifications'),s:L('عدم الإزعاج، مسح الإشعارات','Do not disturb, clear all'),
  items:[['sw','dnd',L('عدم الإزعاج','Do not disturb'),'',0],['nav',L('مسح كل الإشعارات','Clear all notifications'),String(NOTIFS.length),() => { NOTIFS.length = 0; renderNotifs(); toast(L('تم المسح','Cleared')); openApp('settings','notifications'); }]]},
 {id:'battery',c:'#4caf50',p:P.batt,n:L('البطارية','Battery'),s:L('توفير الطاقة، النسبة','Battery saver, percentage'),
  items:[['info',L('مستوى البطارية','Battery level'),batt],['sw','saver',L('توفير الطاقة','Battery saver'),L('يخفض سطوع الشاشة','Dims the screen'),0],['sw','pct',L('نسبة البطارية','Battery percentage'),L('في شريط الحالة','In the status bar'),1]]},
 {id:'storage',c:'#795548',p:P.storage,n:L('التخزين','Storage'),s:L('بيانات النظام المحفوظة','Saved system data'),
  items:[['info',L('بيانات ALANZI المحفوظة','ALANZI saved data'),Math.round(Object.keys(localStorage).reduce((a,k)=>a+(localStorage[k]||'').length,0)/1024)+' KB'],['info',L('عدد الصور','Photos'),String(JSON.parse(localStorage.getItem('az.photos')||'[]').length)],['info',L('الملاحظات','Notes'),String(S.notes.length)],['info',L('التطبيقات المثبتة','Installed apps'),String(allApps().length)]]},
 {id:'security',c:'#00897b',p:P.lock,n:L('الأمان وشاشة القفل','Security & lock screen'),s:L('خيارات شاشة القفل','Lock screen options'),
  items:[['h',L('شاشة القفل','Lock screen')],['sw','lkDate',L('التاريخ','Date'),L('إظهاره على شاشة القفل','Show on the lock screen'),1],['sw','lkHint',L('نص التلميح','Hint text'),L('اسحب للأعلى لفتح القفل','Swipe up to unlock'),1],['nav',L('قفل الشاشة الآن','Lock now'),'',() => { goHome(); showLock(); }]]},
 {id:'access',c:'#388e3c',p:P.access,n:L('إمكانية الوصول','Accessibility'),s:L('نص عريض، تقليل الحركة','Bold text, reduce motion'),
  items:[['sw','bold',L('نص عريض','Bold text'),'',0],['sw','noanim',L('تقليل الحركة','Reduce motion'),L('يعطّل الانتقالات والحركات','Disables transitions and animations'),0],['sw','bigIcons',L('أيقونات كبيرة','Large icons'),'',0]]},
 {id:'datetime',c:'#ef6c00',p:P.clock,n:L('التاريخ والوقت','Date & time'),s:L('نظام 24 ساعة، المنطقة الزمنية','24-hour format, time zone'),
  items:[['sw','h24',L('نظام 24 ساعة','24-hour format'),'',0],['info',L('المنطقة الزمنية','Time zone'),tz],['info',L('التاريخ الحالي','Current date'),new Date().toLocaleDateString(S.lang === 'ar' ? 'ar-SA-u-nu-latn-ca-gregory' : 'en-US')]]},
 {id:'system',c:'#5c6bc0',p:P.settings,n:L('النظام','System'),s:L('اللغة، إعادة الضبط','Language, reset'),
  items:[['nav',L('اللغة','Language'),L('العربية','English'),() => openApp('settings','language')],['nav',L('إعادة ضبط النظام','Reset system'),L('يمسح كل البيانات ويعيد الإعداد','Erases data and restarts setup'),resetDlg]]},
 {id:'dev',c:'#455a64',p:P.dev,n:L('خيارات المطوّر','Developer options'),s:L('إظهار اللمسات، معلومات','Show touches, info'),
  items:[['sw','touches',L('إظهار اللمسات','Show touches'),L('دائرة عند كل لمسة','A circle at each touch'),0],['info',L('رقم البناء','Build number'),'ALANZI.1.0.2026'],['info',L('حجم الشاشة','Screen size'),`${innerWidth}×${innerHeight}`]]},
 {id:'about',c:'#9fa8da',p:P.info,n:L('لمحة عن الهاتف','About phone'),s:'ALANZI ANDROID 1.0',
  items:[['info',L('اسم النظام','System name'),'ALANZI ANDROID'],['info',L('الإصدار','Version'),'1.0'],['info','Wi-Fi',S.wifi ? 'ALANZI HOME · ' + L('متصل (محاكاة)','connected (simulated)') : L('متوقف','Off')],['info',L('الجهاز المستهدف','Target device'),'Samsung Galaxy A16 5G'],['info',L('لغة النظام','System language'),S.lang === 'ar' ? 'العربية' : 'English']]}];
}
function resetDlg() { const d = dlg(`<h3>${L('إعادة ضبط النظام؟','Reset system?')}</h3><p class="muted" style="margin-bottom:16px">${L('سيتم مسح كل الإعدادات والملاحظات والصور.','All settings, notes and photos will be erased.')}</p><div class="btns"><button class="flat" id="rn">${L('إلغاء','Cancel')}</button><button class="flat" id="ry">${L('إعادة ضبط','Reset')}</button></div>`);
  $('#rn', d).onclick = closeDlg; $('#ry', d).onclick = () => { localStorage.removeItem('az.state'); localStorage.removeItem('az.photos'); location.reload(); }; }
function itemsHTML(items) {
  return '<div class="list">' + items.map((it, i) => {
    const [t, a, b, c, d] = it;
    if (t === 'h') return `<div class="sh">${a}</div>`;
    if (t === 'sw') return `<div class="item" data-i="${i}"><div class="txt"><b>${b}</b><small>${c || ''}</small></div><i class="sw ${(S[a] ?? d) ? 'on' : ''}"></i></div>`;
    if (t === 'rg') return `<div class="item rg"><div class="txt"><b>${b}</b></div><input type="range" min="20" max="100" value="${S[a]}" data-r="${a}"></div>`;
    if (t === 'nav') return `<div class="item" data-i="${i}"><div class="txt"><b>${a}</b><small>${b || ''}</small></div>${ic('M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z', 'i chev')}</div>`;
    return `<div class="item"><div class="txt"><b>${a}</b><small>${b}</small></div></div>`;
  }).join('') + '</div>';
}
function bindItems(c, items, again) {
  $$('[data-i]', c).forEach(e => e.onclick = () => { const it = items[+e.dataset.i]; if (it[0] === 'sw') { set(it[1], !(S[it[1]] ?? it[4])); again(); } else if (it[0] === 'nav') it[3](); });
  $$('[data-r]', c).forEach(e => e.oninput = () => { S[e.dataset.r] = +e.value; save(); refresh(true); });
}
function settingsApp(c, s) {
  const T = $('#app-title'); sub = s || null; c.classList.add('flush');
  if (s === 'wifi') { T.textContent = 'Wi-Fi'; return renderWifi(c); }
  if (s === 'wallpaper') { T.textContent = L('الخلفية', 'Wallpaper'); c.innerHTML = `<div class="walls">${WALLS.map((w, i) => `<div data-w="${i}" class="${S.wall === i ? 'on' : ''}" style="background-color:${w[0]};background-image:${wallImg(w)}"></div>`).join('')}</div>`;
    return $$('[data-w]', c).forEach(x => x.onclick = () => { S.wall = +x.dataset.w; save(); refresh(); $$('[data-w]', c).forEach(y => y.classList.toggle('on', y === x)); }); }
  if (s === 'language') { T.textContent = L('اللغة', 'Language'); c.innerHTML = `<div class="list">${[['ar','العربية'],['en','English']].map(([k, n]) => `<div class="item" data-l="${k}"><div class="txt"><b>${n}</b></div><i class="rad ${S.lang === k ? 'on' : ''}"></i></div>`).join('')}</div>`;
    return $$('[data-l]', c).forEach(x => x.onclick = () => { S.lang = x.dataset.l; save(); applyLang(); openApp('settings', 'language'); }); }
  if (s === 'apps') { T.textContent = L('التطبيقات', 'Apps'); c.innerHTML = `<div class="list">${allApps().map(a => `<div class="item" data-a="${a.id}"><div class="ico" style="background:${grad(a)}">${ic(a.ic)}</div><div class="txt"><b>${nm(a)}</b><small>${EXTRA.includes(a) ? L('مثبّت من المتجر', 'Installed from Store') : L('تطبيق نظام', 'System app')}</small></div></div>`).join('')}</div>`;
    return $$('[data-a]', c).forEach(e => e.onclick = () => { const id = e.dataset.a; if (!EXTRA.some(x => x.id === id)) return toast(L('لا يمكن إزالة تطبيقات النظام', "System apps can't be removed"));
      const d = dlg(`<h3>${nm(byId(id))}</h3><p class="muted" style="margin-bottom:16px">${L('هل تريد إزالة التطبيق؟', 'Remove this app?')}</p><div class="btns"><button class="flat" id="an">${L('إلغاء', 'Cancel')}</button><button class="flat" id="ay">${L('إزالة', 'Remove')}</button></div>`);
      $('#an', d).onclick = closeDlg; $('#ay', d).onclick = () => { S.inst = S.inst.filter(x => x !== id); save(); renderIcons(); closeDlg(); openApp('settings', 'apps'); }; }); }
  const cat = cats().find(x => x.id === s);
  if (cat) { T.textContent = cat.n; const draw = () => { const y = c.scrollTop; c.innerHTML = itemsHTML(cat.items); bindItems(c, cat.items, draw); c.scrollTop = y; }; return draw(); }
  T.textContent = L('الإعدادات', 'Settings');
  const draw = q => { const all = cats().filter(x => !q || (x.n + x.s).toLowerCase().includes(q) || (x.items || []).some(i => String(i[0] === 'sw' || i[0] === 'rg' ? i[2] : i[1]).toLowerCase().includes(q)));
    $('#set-list').innerHTML = all.length ? all.map(x => `<div class="item" data-c="${x.go || x.id}"><div class="ico" style="background:${x.c}">${ic(x.p)}</div><div class="txt"><b>${x.n}</b><small>${x.s}</small></div>${ic('M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z', 'i chev')}</div>`).join('') : `<p class="muted c">${L('لا توجد نتائج', 'No results')}</p>`;
    $$('[data-c]').forEach(e => e.onclick = () => openApp('settings', e.dataset.c)); };
  c.innerHTML = `<div class="field">${ic(P.search)}<input id="set-q" placeholder="${L('ابحث في الإعدادات', 'Search settings')}"></div><div class="list" id="set-list"></div>`;
  $('#set-q').oninput = e => draw(e.target.value.trim().toLowerCase()); draw('');
}

/* ---------- 6. Apps ---------- */
function openApp(id, s) {
  closePanels(); closeRecents(); closeDrawer();
  if (id === 'flash') return setTorch(!torch);
  const a = byId(id); if (!a) return;
  stopCam(); timers.forEach(clearInterval); timers = []; inCall = false; appId = id; sub = null;
  const ri = RECENT.indexOf(id); if (ri >= 0) RECENT.splice(ri, 1); RECENT.unshift(id); RECENT.splice(6);
  const el = $('#app'), c = $('#app-content'); $('#app-title').textContent = nm(a); c.style.padding = ''; c.classList.remove('flush'); c.scrollTop = 0;
  el.style.display = 'flex'; (APP_FN[id])(c, s); chrome();
  requestAnimationFrame(() => el.classList.add('show'));
}
function stopCam() { if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; } }
function closeApp() { stopCam(); appId = null; sub = null; inCall = false; timers.forEach(clearInterval); timers = []; $('#app').classList.remove('show'); setTimeout(() => { if (!appId) $('#app').style.display = 'none'; }, 220); chrome(); }
const keys = (list, cls) => `<div class="keys ${cls}">${list.map(k => `<div class="key ${'÷×−+='.includes(k) ? 'op' : ['AC','⌫','%'].includes(k) ? 'fn' : ''}" data-k="${k}">${k}</div>`).join('')}</div>`;
let calcE = '', dial = '';
const NOTE_COLORS = ['#fff59d','#a5d6a7','#90caf9','#f8bbd0','#ffcc80'];
const PIPS = {1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]};
const diceFace = n => `<div class="die">${Array.from({length: 9}, (_, i) => `<i class="${PIPS[n].includes(i) ? 'pip' : ''}"></i>`).join('')}</div>`;
const LETTERS = {2:'ABC',3:'DEF',4:'GHI',5:'JKL',6:'MNO',7:'PQRS',8:'TUV',9:'WXYZ',0:'+'};
const APP_FN = {
 settings: settingsApp,
 store(c) {
   if (!S.wifi) { c.innerHTML = `<p class="muted c">${L('لا يوجد اتصال. فعّل Wi-Fi من الإعدادات.', 'No connection. Turn on Wi-Fi in Settings.')}</p><button class="btn" id="gw">${L('فتح Wi-Fi', 'Open Wi-Fi')}</button>`; $('#gw').onclick = () => openApp('settings', 'wifi'); return; }
   const draw = () => {
     c.innerHTML = `<div class="sh" style="background:transparent">${L('تطبيقات مقترحة', 'Suggested apps')}</div>` + EXTRA.map(a => { const on = S.inst.includes(a.id);
       return `<div class="card store-i"><div class="bx" style="background:${grad(a)}">${ic(a.ic)}</div><div class="txt"><b>${nm(a)}</b><small>${L('تطبيق إضافي', 'Extra app')}</small></div>${on ? `<button class="pillb" data-o="${a.id}">${L('فتح', 'Open')}</button><button class="flat" data-i="${a.id}">${L('إزالة', 'Remove')}</button>` : `<button class="pillb" data-i="${a.id}">${L('تثبيت', 'Install')}</button>`}</div>`; }).join('');
     $$('[data-o]', c).forEach(b => b.onclick = () => openApp(b.dataset.o));
     $$('[data-i]', c).forEach(b => b.onclick = async () => { const id = b.dataset.i;
       if (S.inst.includes(id)) S.inst = S.inst.filter(x => x !== id);
       else { b.outerHTML = '<div class="prog"><i></i></div>'; await wait(1500); if (!S.wifi) return APP_FN.store(c); S.inst.push(id); notify(nm(byId(id)), L('تم التثبيت', 'Installed'), byId(id).c, byId(id).ic); beep(880, .12, 1); }
       save(); renderIcons(); if (appId === 'store') draw(); });
   };
   draw();
 },
 clock(c) {
   const ticks = Array.from({length: 12}, (_, i) => `<line class="tk" x1="100" y1="12" x2="100" y2="${i % 3 ? 20 : 26}" transform="rotate(${i * 30} 100 100)"/>`).join('');
   c.innerHTML = `<svg viewBox="0 0 200 200" class="analog"><circle class="face" cx="100" cy="100" r="92"/>${ticks}<line class="hh" id="hh" x1="100" y1="100" x2="100" y2="55"/><line class="mh" id="mh" x1="100" y1="100" x2="100" y2="35"/><line class="sh" id="sh" x1="100" y1="112" x2="100" y2="28"/><circle cx="100" cy="100" r="5" fill="var(--p)"/></svg>
     <div class="big" id="ct" style="margin:6px 0"></div><div class="center muted" id="cd" style="margin-bottom:18px"></div>
     <div class="card center"><div class="muted">${L('ساعة الإيقاف', 'Stopwatch')}</div><div class="big" id="sw" style="font-size:46px">00:00.00</div><div class="rbtns"><button class="rb gray" id="sr">${L('تصفير', 'Reset')}</button><button class="rb" id="ss">${L('بدء', 'Start')}</button></div></div>`;
   const up = () => { const d = new Date(), s = d.getSeconds(), m = d.getMinutes() + s / 60, h = (d.getHours() % 12) + m / 60;
     $('#hh').setAttribute('transform', `rotate(${h * 30} 100 100)`); $('#mh').setAttribute('transform', `rotate(${m * 6} 100 100)`); $('#sh').setAttribute('transform', `rotate(${s * 6} 100 100)`);
     $('#ct').textContent = fmtT(d) + ':' + String(s).padStart(2, '0'); $('#cd').textContent = d.toLocaleDateString(S.lang === 'ar' ? 'ar-SA-u-nu-latn-ca-gregory' : 'en-US', {weekday:'long', day:'numeric', month:'long', year:'numeric'}); };
   up(); timers.push(setInterval(up, 1000));
   let run = 0, acc = 0, st = 0;
   timers.push(setInterval(() => { const ms = acc + (run ? Date.now() - st : 0), p = n => String(n).padStart(2, '0'); $('#sw').textContent = `${p(Math.floor(ms / 60000))}:${p(Math.floor(ms / 1000) % 60)}.${p(Math.floor(ms % 1000 / 10))}`; }, 40));
   $('#ss').onclick = () => { if (run) { acc += Date.now() - st; run = 0; $('#ss').textContent = L('متابعة', 'Resume'); } else { st = Date.now(); run = 1; $('#ss').textContent = L('إيقاف', 'Stop'); } };
   $('#sr').onclick = () => { run = 0; acc = 0; $('#ss').textContent = L('بدء', 'Start'); };
 },
 calc(c) {
   c.innerHTML = `<div class="disp" id="ds">${calcE || '0'}</div>` + keys(['AC','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','00','0','.','='], 'k4');
   $$('.key', c).forEach(b => b.onclick = () => { const k = b.dataset.k; beep(600 + Math.random() * 100);
     if (k === 'AC') calcE = ''; else if (k === '⌫') calcE = calcE.slice(0, -1);
     else if (k === '=') { try { const x = calcE.replace(/÷/g, '/').replace(/×/g, '*').replace(/−/g, '-').replace(/%/g, '/100'); calcE = /^[0-9+\-*/.() ]+$/.test(x) && x ? String(+Function('return ' + x)().toFixed(8)) : ''; } catch (e) { calcE = ''; toast(L('خطأ', 'Error')); } }
     else calcE += k; $('#ds').textContent = calcE || '0'; });
 },
 notes(c) {
   const list = () => { c.innerHTML = (S.notes.length ? `<div class="ngrid">${S.notes.map((n, i) => `<div class="nc" data-n="${i}" style="background:${NOTE_COLORS[i % 5]}"><b>${esc(n.t) || L('بدون عنوان', 'Untitled')}</b><small>${esc((n.b || '').slice(0, 90))}</small></div>`).join('')}</div>` : `<p class="muted c">${L('لا توجد ملاحظات', 'No notes')}</p>`) + `<button class="fab" id="nn">+</button>`;
     $('#nn').onclick = () => edit(-1); $$('[data-n]', c).forEach(e => e.onclick = () => edit(+e.dataset.n)); };
   const edit = i => { const n = S.notes[i] || {t: '', b: ''};
     c.innerHTML = `<input class="ti" id="nt" placeholder="${L('العنوان', 'Title')}" value="${esc(n.t)}"><textarea class="ta" id="nb" placeholder="${L('اكتب هنا…', 'Write here…')}">${esc(n.b)}</textarea><div style="display:flex;gap:10px"><button class="btn" id="sv" style="flex:1">${L('حفظ', 'Save')}</button>${i >= 0 ? `<button class="btn red" id="dl" style="flex:1">${L('حذف', 'Delete')}</button>` : ''}</div>`;
     $('#sv').onclick = () => { const o = {t: $('#nt').value.trim(), b: $('#nb').value.trim()}; if (!o.t && !o.b) return toast(L('الملاحظة فارغة', 'Note is empty')); if (i >= 0) S.notes[i] = o; else S.notes.unshift(o); save(); list(); };
     if (i >= 0) $('#dl').onclick = () => { S.notes.splice(i, 1); save(); list(); }; };
   list();
 },
 phone(c) {
   const key = k => `<div class="key rnd dg" data-k="${k}">${k}<small>${LETTERS[k] || '&nbsp;'}</small></div>`;
   c.innerHTML = `<div class="big" id="dn" style="font-size:38px;min-height:64px">${dial}</div><div class="keys k3">${['1','2','3','4','5','6','7','8','9','*','0','#'].map(key).join('')}</div>
     <div style="display:flex;justify-content:center;gap:34px;margin-top:20px;direction:ltr"><div class="key rnd" id="dd" style="width:64px;color:var(--mut)">⌫</div><div class="key rnd" id="dc" style="width:64px;background:#1faa59;color:#fff">${ic(P.phone)}</div></div>`;
   $$('.key[data-k]', c).forEach(b => b.onclick = () => { dial += b.dataset.k; beep(700 + b.dataset.k.charCodeAt(0) * 3); $('#dn').textContent = dial; });
   $('#dd').onclick = () => { dial = dial.slice(0, -1); $('#dn').textContent = dial; };
   $('#dc').onclick = () => { if (!dial) return toast(L('أدخل رقمًا', 'Enter a number')); if (S.airplane) return toast(L('وضع الطائرة مفعّل', 'Airplane mode is on')); startCall(c); };
 },
 camera(c) {
   c.style.padding = '0'; let face = 'environment';
   c.innerHTML = `<div class="cam" id="cam"><video id="cv" autoplay playsinline muted></video><div class="cam-bar"><button class="cb" id="cf">${ic('M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z')}</button><button class="shut" id="cs"></button><span class="cb" style="background:none"></span></div></div>`;
   const start = async () => { stopCam(); try { camStream = await navigator.mediaDevices.getUserMedia({video: {facingMode: face}, audio: false}); $('#cv').srcObject = camStream; }
     catch (e) { c.style.padding = ''; c.innerHTML = `<p class="muted c">${L('تعذّر تشغيل الكاميرا', 'Could not start the camera')}<br><small>${esc(e.message)}</small><br><small>${L('تحتاج فتح الصفحة عبر HTTPS أو localhost وإعطاء الإذن', 'Open the page over HTTPS or localhost and allow access')}</small></p>`; } };
   $('#cf').onclick = () => { face = face === 'environment' ? 'user' : 'environment'; start(); };
   $('#cs').onclick = () => { const v = $('#cv'); if (!v.videoWidth) return toast(L('الكاميرا غير جاهزة', 'Camera not ready'));
     const k = Math.min(1, 720 / Math.max(v.videoWidth, v.videoHeight)), cv = document.createElement('canvas'); cv.width = v.videoWidth * k; cv.height = v.videoHeight * k; cv.getContext('2d').drawImage(v, 0, 0, cv.width, cv.height);
     try { const p = JSON.parse(localStorage.getItem('az.photos') || '[]'); p.push(cv.toDataURL('image/jpeg', .7)); localStorage.setItem('az.photos', JSON.stringify(p)); toast(L('تم حفظ الصورة في المعرض', 'Photo saved to Gallery')); beep(1000, .08, 1); } catch (x) { toast(L('الذاكرة ممتلئة', 'Storage full')); }
     $('#cam').classList.add('shot'); setTimeout(() => $('#cam').classList.remove('shot'), 150); };
   start();
 },
 gallery(c) {
   const ph = () => JSON.parse(localStorage.getItem('az.photos') || '[]');
   const draw = () => { const p = ph(); c.innerHTML = `<input type="file" id="gf" accept="image/*" multiple hidden>` + (p.length ? `<div class="gal">${p.map((u, i) => `<div data-p="${i}"><img src="${u}"></div>`).join('')}</div><button class="btn red" id="gc" style="margin-top:14px">${L('حذف كل الصور', 'Delete all')}</button>` : `<p class="muted c">${L('لا توجد صور. اضغط + لرفع صور من جهازك.', 'No photos. Tap + to upload from your device.')}</p>`) + `<button class="fab" id="gu">+</button>`;
     $('#gu').onclick = () => $('#gf').click(); if (p.length) $('#gc').onclick = () => { localStorage.removeItem('az.photos'); draw(); };
     $$('[data-p]', c).forEach(e => e.onclick = () => { c.innerHTML = `<img src="${ph()[+e.dataset.p]}" style="width:100%;border-radius:14px"><button class="btn gray" id="gb" style="margin-top:14px">${L('رجوع', 'Back')}</button>`; $('#gb').onclick = draw; });
     $('#gf').onchange = async e => { const out = ph(); for (const f of e.target.files) out.push(await shrink(f)); try { localStorage.setItem('az.photos', JSON.stringify(out)); } catch (x) { toast(L('الذاكرة ممتلئة', 'Storage full')); } draw(); }; };
   draw();
 },
 count(c) {
   c.innerHTML = `<div class="cnt" id="cp"><b id="cn">${S.cnt}</b><small>${L('اضغط للعد', 'Tap to count')}</small></div><button class="btn gray" id="cr" style="max-width:200px;margin:24px auto">${L('تصفير', 'Reset')}</button>`;
   $('#cp').onclick = () => { S.cnt++; save(); $('#cn').textContent = S.cnt; beep(520); }; $('#cr').onclick = () => { S.cnt = 0; save(); $('#cn').textContent = 0; };
 },
 dice(c) {
   c.innerHTML = `<div id="dv" class="center" style="margin:30px 0">${diceFace(1)}</div><button class="btn" id="dr">${L('ارمِ النرد', 'Roll')}</button>`;
   $('#dr').onclick = async () => { for (let i = 0; i < 9; i++) { $('#dv').innerHTML = diceFace(1 + Math.floor(Math.random() * 6)); beep(300 + i * 40, .05, 1); await wait(80); } };
 }
};
function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function shrink(f) { return new Promise(res => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 720 / Math.max(im.width, im.height)), cv = document.createElement('canvas'); cv.width = im.width * k; cv.height = im.height * k; cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); res(cv.toDataURL('image/jpeg', .7)); }; im.src = r.result; }; r.readAsDataURL(f); }); }
function startCall(c) {
  inCall = true; let sec = 0;
  c.innerHTML = `<div class="center" style="padding-top:60px"><div style="font-size:26px;direction:ltr">${dial}</div><div class="muted" id="ct2" style="margin:10px 0 6px">${L('جارٍ الاتصال…', 'Calling…')}</div><small class="muted">${L('اتصال تجريبي (محاكاة)', 'Simulated call')}</small><br><br><button class="btn red" id="ec" style="width:200px;margin:30px auto">${L('إنهاء', 'End')}</button></div>`;
  $('#ec').onclick = endCall; timers.push(setInterval(() => { sec++; const e = $('#ct2'); if (e) e.textContent = String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0'); }, 1000));
}
function endCall() { inCall = false; timers.forEach(clearInterval); timers = []; APP_FN.phone($('#app-content')); toast(L('تم إنهاء المكالمة', 'Call ended')); }

/* ---------- 7. Gestures ---------- */
let g = null, lp = null;
os.addEventListener('pointerdown', e => { if (lockOn) return; g = {x: e.clientX, y: e.clientY};
  if (!appId && !drawerOpen && !panel && !recentsOpen && !e.target.closest('.app-i,.pill,#status,#nav')) lp = setTimeout(() => { g = null; openApp('settings', 'wallpaper'); }, 700); });
os.addEventListener('pointermove', e => { if (lp && g && Math.hypot(e.clientX - g.x, e.clientY - g.y) > 10) { clearTimeout(lp); lp = null; } });
os.addEventListener('pointerup', e => { clearTimeout(lp); lp = null; if (!g) return;
  const r = os.getBoundingClientRect(), dx = e.clientX - g.x, dy = e.clientY - g.y, x0 = g.x - r.left, y0 = g.y - r.top; g = null;
  if (Math.abs(dy) < 60 || Math.abs(dy) < Math.abs(dx)) return;
  if (dy > 0 && y0 < 50 && !panel) openPanel(x0 < r.width * .55 ? 'notif' : 'cc');         // top-left: notifications / top-right: control center
  else if (dy < 0 && panel) closePanels();
  else if (dy < 0 && y0 > r.height - 60) goHome();
  else if (dy < 0 && !appId && !drawerOpen && !recentsOpen && y0 > 150) openDrawer(); });
// Lock screen: drag up to unlock
const lk = $('#lock'); let ly = null;
lk.addEventListener('pointerdown', e => { ly = e.clientY; lk.style.transition = 'none'; lk.setPointerCapture(e.pointerId); });
lk.addEventListener('pointermove', e => { if (ly === null) return; const d = ly - e.clientY; if (d > 0) { lk.style.transform = `translateY(${-d}px)`; lk.style.opacity = 1 - d / 500; } });
lk.addEventListener('pointerup', e => { if (ly === null) return; const d = ly - e.clientY; ly = null; lk.style.transition = '.2s'; if (d > 100 || d < 5) unlock(); else { lk.style.transform = ''; lk.style.opacity = ''; } });

/* ---------- 8. Boot & Setup ---------- */
function startOS(withLock) {
  $('#setup').classList.add('hidden'); os.classList.remove('hidden'); applyLang(); if (withLock) showLock();
    if (S.wifi && !S.seen) setTimeout(() => { if (S.wifi && !S.seen) connected(); }, 900);
}
function step(id) { $$('.step').forEach(s => s.classList.add('hidden')); $('#' + id).classList.remove('hidden'); if (id === 'st-wifi') renderWifi($('#setup-wifi')); }
function langList() { $('#lang-list').innerHTML = [['ar','العربية'],['en','English']].map(([k, n]) => `<div class="item" data-l="${k}"><div class="txt"><b>${n}</b></div><i class="rad ${S.lang === k ? 'on' : ''}"></i></div>`).join('');
  $$('[data-l]').forEach(e => e.onclick = () => { S.lang = e.dataset.l; save(); document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'ar' ? 'rtl' : 'ltr'; $$('[data-ar]').forEach(x => x.textContent = L(x.dataset.ar, x.dataset.en)); step('st-wifi'); }); }
$('#wifi-skip').onclick = () => step('st-done');
$('#finish').onclick = () => { S.done = true; save(); startOS(false); };

document.documentElement.dataset.theme = S.dark ? 'dark' : 'light';
document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'ar' ? 'rtl' : 'ltr';
$$('[data-ar]').forEach(x => x.textContent = L(x.dataset.ar, x.dataset.en)); langList();
setTimeout(() => { $('#boot').style.opacity = 0; setTimeout(() => $('#boot').classList.add('hidden'), 500);
  if (S.done) startOS(true); else { $('#setup').classList.remove('hidden'); step('st-lang'); } }, 2400);
})();
