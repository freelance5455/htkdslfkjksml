/* ALANZI ANDROID - script.js (v1.1)
   1 State  2 Icons & data  3 Wi-Fi  4 System UI  5 Settings  6 Apps  7 Gestures  8 Setup & boot */
(() => {
'use strict';

/* ================= 0. System-wide Animations (No Lag) ================= */
const styleInject = document.createElement('style');
styleInject.innerHTML = `
  .az-fade-up { animation: azFadeUp 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both; }
  @keyframes azFadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
  
  #app { transition: opacity 0.22s ease; will-change: opacity; }
  #app.show { opacity: 1; }
  
  #dialog { transition: opacity 0.2s ease; }
  #dialog .dlg { animation: azFadeUp 0.25s ease-out both; }
  
  #drawer { transition: opacity 0.22s ease, transform 0.22s ease; will-change: opacity, transform; }
  
  .panel { transition: transform 0.28s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.28s ease; will-change: transform, opacity; }
  
  .step { transition: opacity 0.22s ease, transform 0.22s ease; will-change: opacity, transform; }
  
  .item, .card, .nc, .chk-i, .store-i { animation: azFadeUp 0.25s ease-out both; }
  
  /* Performance hints to prevent hanging */
  .screen, .app-content { -webkit-backface-visibility: hidden; backface-visibility: hidden; transform: translateZ(0); }
`;
document.head.appendChild(styleInject);

/* ================= 1. State (LocalStorage key: "az.state") ================= */
const DEF = {lang:'ar',dark:false,wall:0,accent:0,fs:1,wifi:true,seen:false,done:false,bt:true,nfc:true,data:true,roaming:false,airplane:false,vpn:false,hotspot:false,dnd:false,saver:false,night:false,
 pct:true,h24:false,tz:'',tap:true,vib:false,nsound:true,labels:true,circle:false,showClock:true,showWx:true,widgets:false,cols5:false,lkDate:true,lkHint:true,lkNotif:true,bold:false,noanim:false,
 bigIcons:false,inv:false,gray:false,touches:false,dev:false,stay:false,gesture:false,showPw:false,loc:true,wifiScan:true,btScan:true,gla:true,locApps:true,locAssist:true,unk:false,fmd:true,protect:true,
 adsPers:true,autofill:'alanzi',backup:true,autorestore:true,autosync:true,nearby:true,dns:'auto',usb:'charge',nettype:'4g',bright:100,volM:60,volR:70,volA:80,ring:'chime',timeout:120000,
 screenLock:'none',pinh:'',devName:'ALANZI Phone',hpw:'alanzi123'};
let _saved = {};
try { _saved = JSON.parse(localStorage.getItem('az.state') || '{}') || {}; } catch (e) { _saved = {}; }
const S = Object.assign({}, DEF, {acct:null,adId:'',lastBackup:0,lastScan:0,lastUpd:0,btPaired:[],usage:{},usageDay:'',dataW:0,dataM:0,inst:[],notes:[],todos:[],events:{},alarms:[],cnt:0,tgt:33}, _saved);
const save = () => { try { localStorage.setItem('az.state', JSON.stringify(S)); } catch (e) {} };
const L = (a, e) => S.lang === 'ar' ? a : e;
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const wait = ms => new Promise(r => setTimeout(r, ms));
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const hash = s => { let h = 5381; for (const ch of 'az' + s) h = ((h << 5) + h + ch.charCodeAt(0)) | 0; return String(h); };
const LOC = () => S.lang === 'ar' ? 'ar-SA-u-nu-latn-ca-gregory' : 'en-US';
const tzo = () => S.tz ? {timeZone: S.tz} : {};
function hm(d) { const p = new Intl.DateTimeFormat('en-GB', {...tzo(), hour: 'numeric', minute: 'numeric', hour12: false}).formatToParts(d), g = t => +p.find(x => x.type === t).value; return {h: g('hour') % 24, m: g('minute')}; }
const fmtT = d => { let {h, m} = hm(d); if (!S.h24) h = h % 12 || 12; return `${S.h24 ? String(h).padStart(2, '0') : h}:${String(m).padStart(2, '0')}`; };
const online = () => S.wifi || (S.data && !S.airplane);
const useData = mb => { if (S.wifi) S.dataW += mb; else if (online()) S.dataM += mb; save(); };
let ac; function beep(f = 660, d = .06, force, vol) { if (!force && !S.tap) return; try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f; g.gain.value = (vol ?? S.volM) / 400; o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + d); } catch (e) {} if (S.vib && navigator.vibrate && !force) navigator.vibrate(8); }
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t.t); t.t = setTimeout(() => t.classList.remove('show'), 1900); }
const os = $('#os');
let camStream = null, appId = null, sub = null, drawerOpen = false, panel = null, recentsOpen = false, torch = false, lockOn = false, batt = '87%', timers = [], cleanups = [], inCall = false, useStart = 0, lastAct = Date.now();
const RECENT = [], NOTIFS = [];

/* ================= 2. Icons & data ================= */
const P = {
 settings:'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.49.49 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
 phone:'M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z',
 globe:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z',
 camera:'M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z',
 gallery:'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z',
 store:'M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm0 10c-2.76 0-5-2.24-5-5h2c0 1.66 1.34 3 3 3s3-1.34 3-3h2c0 2.76-2.24 5-5 5z',
 clock:'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z',
 calc:'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM7.5 17.5H6V16h1.5v1.5zM9 9.5H6V8h3v1.5zm5 8h-4V16h4v1.5zm4 0h-2.5V16H18v1.5zm0-3H6V13h12v1.5zM18 9.5h-3V8h3v1.5z',
 notes:'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
 cal:'M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zM7 12h5v5H7z',
 todo:'M22 5.18L10.59 16.6l-4.24-4.24 1.41-1.41 2.83 2.83 10-10L22 5.18zM12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8c1.57 0 3.04.46 4.28 1.25l1.45-1.45A10.02 10.02 0 0012 2C6.48 2 2 6.48 2 12s4.48 10 10 10c1.73 0 3.36-.44 4.78-1.22l-1.5-1.5c-1 .46-2.11.72-3.28.72z',
 swap:'M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z',
 sun:'M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z',
 compass:'M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z',
 key:'M12.65 10C11.83 7.67 9.61 6 7 6c-3.31 0-6 2.69-6 6s2.69 6 6 6c2.61 0 4.83-1.67 5.65-4H17v4h4v-4h2v-4H12.65zM7 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z',
 draw:'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 000-1.41l-2.34-2.34a.996.996 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
 count:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z',
 flash:'M6 2v6l3 3v11h6V11l3-3V2H6zm6 11.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z',
 wifi:'M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9zm8 8l3 3 3-3a4.24 4.24 0 00-6 0zm-4-4l2 2a7.07 7.07 0 0110 0l2-2C15.14 9.14 8.87 9.14 5 13z',
 bt:'M17.71 7.71L12 2h-1v7.59L6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 11 14.41V22h1l5.71-5.71-4.3-4.29 4.3-4.29zM13 5.83l1.88 1.88L13 9.59V5.83zm1.88 10.46L13 18.17v-3.76l1.88 1.88z',
 dnd:'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7 13v-2h10v2H7z',
 plane:'M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z',
 data:'M16 17.01V10h-2v7.01h-3L15 21l4-3.99h-3zM9 3L5 6.99h3V14h2V6.99h3L9 3z',
 hot:'M12 11c1.33 0 4 .67 4 2v.16c-.97 1.12-2.4 1.84-4 1.84s-3.03-.72-4-1.84V13c0-1.33 2.67-2 4-2zm0-1c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm6 .2C18 6.57 15.35 4 12 4s-6 2.57-6 6.2c0 2.34 1.95 5.44 6 9.14 4.05-3.7 6-6.8 6-9.14zM12 2c4.2 0 8 3.22 8 8.2 0 3.32-2.67 7.25-8 11.8-5.33-4.55-8-8.48-8-11.8C4 5.22 7.8 2 12 2z',
 batt:'M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4z',
 moon:'M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 01-4.4 2.26 5.403 5.403 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z',
 display:'M20 15.31L23.31 12 20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69zM12 18V6c3.31 0 6 2.69 6 6s-2.69 6-6 6z',
 lock:'M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z',
 sound:'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z',
 bell:'M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z',
 storage:'M2 20h20v-4H2v4zm2-3h2v2H4v-2zM2 4v4h20V4H2zm4 3H4V5h2v2zm-4 7h20v-4H2v4zm2-3h2v2H4v-2z',
 info:'M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z',
 lang:'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zm6.93 6h-2.95a15.65 15.65 0 00-1.38-3.56A8.03 8.03 0 0118.92 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14C4.1 13.36 4 12.69 4 12s.1-1.36.26-2h3.38c-.08.66-.14 1.32-.14 2 0 .68.06 1.34.14 2H4.26z',
 power:'M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A6.92 6.92 0 0119 12c0 3.87-3.13 7-7 7A6.995 6.995 0 018.59 6.58L7.17 5.17A8.932 8.932 0 003 12a9 9 0 0018 0c0-2.74-1.23-5.18-3.17-6.83z',
 restart:'M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
 search:'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
 sig:'M2 22h20V2z',
 home:'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
 access:'M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z',
 dev:'M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z',
 apps:'M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z',
 person:'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z',
 cloud:'M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z',
 shield:'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z',
 pin:'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
 hour:'M6 2v6l4 4-4 4v6h12v-6l-4-4 4-4V2H6z',
 google:'M12 11v2.4h5.66c-.24 1.44-1.68 4.22-5.66 4.22-3.41 0-6.19-2.82-6.19-6.29s2.78-6.29 6.19-6.29c1.94 0 3.24.83 3.98 1.54l2.71-2.61C16.98 1.62 14.7.7 12 .7 5.82.7.8 5.72.8 11.9S5.82 23.1 12 23.1c6.93 0 11.5-4.87 11.5-11.72 0-.79-.09-1.39-.19-1.99H12z',
 back:'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
 fwd:'M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z',
 reload:'M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
 mic:'M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z',
 close:'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
 off:'M24 8.98C20.93 5.9 16.69 4 12 4S3.07 5.9 0 8.98L12 21 24 8.98zM2.92 9.07C5.51 7.08 8.67 6 12 6s6.49 1.08 9.08 3.07l-1.43 1.43C17.5 8.94 14.86 8 12 8c-2.86 0-5.5.94-7.65 2.5L2.92 9.07z',
 check:'M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z',
 open:'M19 19H5V5h7V3H5a2 2 0 00-2 2v14a2 2 0 002 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z',
 usage:'M3 13h2v8H3zm4-8h2v16H7zm4 5h2v11h-2zm4-3h2v14h-2zm4 6h2v8h-2z'
};
const ic = (p, c = 'i') => `<svg class="${c}" viewBox="0 0 24 24"><path d="${p}"/></svg>`;
const APPS = [
 {id:'phone',ar:'الهاتف',en:'Phone',c:'#1e88e5',ic:P.phone},{id:'browser',ar:'المتصفح',en:'Browser',c:'#4285f4',ic:P.globe},
 {id:'camera',ar:'الكاميرا',en:'Camera',c:'#e53935',ic:P.camera},{id:'gallery',ar:'المعرض',en:'Gallery',c:'#3f51b5',ic:P.gallery},
 {id:'store',ar:'المتجر',en:'Store',c:'#8e24aa',ic:P.store},{id:'settings',ar:'الإعدادات',en:'Settings',c:'#00897b',ic:P.settings},
 {id:'clock',ar:'الساعة',en:'Clock',c:'#ef6c00',ic:P.clock},{id:'calc',ar:'الحاسبة',en:'Calculator',c:'#546e7a',ic:P.calc},{id:'notes',ar:'الملاحظات',en:'Notes',c:'#fbc02d',ic:P.notes}];
const EXTRA = [
 {id:'calendar',ar:'التقويم',en:'Calendar',c:'#d32f2f',ic:P.cal,da:'الأحداث والتذكيرات',de:'Events and reminders'},
 {id:'todo',ar:'المهام',en:'Tasks',c:'#43a047',ic:P.todo,da:'قائمة مهامك اليومية',de:'Your daily to-do list'},
 {id:'convert',ar:'محوّل الوحدات',en:'Unit converter',c:'#00838f',ic:P.swap,da:'الطول والوزن والحرارة والسرعة',de:'Length, weight, temperature, speed'},
 {id:'weather',ar:'الطقس',en:'Weather',c:'#039be5',ic:P.sun,da:'حالة الطقس وتوقعات 5 أيام',de:'Conditions and 5-day outlook'},
 {id:'compass',ar:'البوصلة',en:'Compass',c:'#455a64',ic:P.compass,da:'اتجاه القبلة والشمال',de:'Find north with the sensor'},
 {id:'passgen',ar:'مولّد كلمات المرور',en:'Password generator',c:'#6d4c41',ic:P.key,da:'كلمات مرور قوية وعشوائية',de:'Strong random passwords'},
 {id:'draw',ar:'الرسم',en:'Draw',c:'#ec407a',ic:P.draw,da:'ارسم واحفظ في المعرض',de:'Sketch and save to Gallery'},
 {id:'tasbih',ar:'المسبحة',en:'Tasbih counter',c:'#26a69a',ic:P.count,da:'عدّاد ذكر مع هدف',de:'Counter with a target'},
 {id:'flash',ar:'المصباح',en:'Flashlight',c:'#f9a825',ic:P.flash,da:'أضئ الشاشة كمصباح',de:'Use the screen as a light'}];

const ST = 'fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
const APPICON = {
 phone: `<path fill="#fff" d="${P.phone}"/><path ${ST} stroke-opacity=".6" d="M14.5 3.8a6.2 6.2 0 015.7 5.7M14.5 7.4a2.7 2.7 0 012.1 2.1"/>`,
 browser: `<circle cx="12" cy="12" r="9" fill="#fff" fill-opacity=".18" ${ST.replace('fill="none" ', '')}/><ellipse cx="12" cy="12" rx="3.8" ry="9" ${ST} stroke-opacity=".65"/><path ${ST} stroke-opacity=".65" d="M3.5 9.5h17M3.5 14.5h17"/>`,
 camera: `<rect x="2.5" y="6.5" width="19" height="13.5" rx="4" fill="#fff"/><rect x="8" y="3.6" width="8" height="4" rx="2" fill="#fff" fill-opacity=".6"/><circle cx="12" cy="13.2" r="4.6" fill="#000" fill-opacity=".3"/><circle cx="12" cy="13.2" r="2.7" fill="#fff"/><circle cx="18" cy="9.6" r="1" fill="#000" fill-opacity=".3"/>`,
 gallery: `<rect x="3" y="3.5" width="18" height="17" rx="4.5" fill="#fff" fill-opacity=".28"/><path fill="#fff" d="M3 16.5l5.2-5.2 3.8 3.8 3-3 6 6V17a3.5 3.5 0 01-3.5 3.5h-11A3.5 3.5 0 013 17z"/><circle cx="16.5" cy="8.5" r="2.2" fill="#fff"/>`,
 store: `<path fill="#fff" d="M5.2 8.2h13.6l-.9 11a2.4 2.4 0 01-2.4 2.2H8.5a2.4 2.4 0 01-2.4-2.2z"/><path ${ST} stroke-opacity=".65" d="M9 8.5V7.4a3 3 0 016 0v1.1"/><path fill="#000" fill-opacity=".3" d="M10.2 12.6l4.4 2.6-4.4 2.6z"/>`,
 settings: `<path fill="#fff" d="${P.settings}"/>`,
 clock: `<circle cx="12" cy="12" r="9.2" fill="#fff" fill-opacity=".25" stroke="#fff" stroke-width="2"/><path ${ST} d="M12 6.8v5.4l3.6 2.2"/><circle cx="12" cy="12" r="1.2" fill="#fff"/>`,
 calc: `<rect x="4" y="2.5" width="16" height="19" rx="4" fill="#fff" fill-opacity=".28"/><rect x="6.5" y="5" width="11" height="4.2" rx="1.6" fill="#fff"/><g fill="#fff"><circle cx="8.6" cy="12.8" r="1.3"/><circle cx="12" cy="12.8" r="1.3"/><circle cx="8.6" cy="16.6" r="1.3"/><circle cx="12" cy="16.6" r="1.3"/></g><rect x="14.6" y="11.5" width="2.8" height="6.4" rx="1.4" fill="#fff" fill-opacity=".65"/>`,
 notes: `<path fill="#fff" d="M7 2.8h7.2L19.6 8v11a2.2 2.2 0 01-2.2 2.2H7A2.2 2.2 0 014.8 19V5A2.2 2.2 0 017 2.8z"/><path fill="#fff" fill-opacity=".55" d="M14.2 2.8V8h5.4z"/><path stroke="#000" stroke-opacity=".28" stroke-width="1.8" stroke-linecap="round" d="M8 12.2h8M8 15.8h5"/>`,
 calendar: `<rect x="3.5" y="5" width="17" height="16" rx="4" fill="#fff"/><path fill="#000" fill-opacity=".18" d="M3.5 9a4 4 0 014-4h9a4 4 0 014 4v1.2h-17z"/><rect x="7.6" y="2.6" width="2" height="4.4" rx="1" fill="#fff"/><rect x="14.4" y="2.6" width="2" height="4.4" rx="1" fill="#fff"/><rect x="7.5" y="13" width="4" height="4" rx="1.2" fill="#000" fill-opacity=".3"/>`,
 todo: `<rect x="3.5" y="3.5" width="17" height="17" rx="5.5" fill="#fff" fill-opacity=".26"/><path ${ST} stroke-width="2.6" d="M7.8 12.6l3 3 5.6-6.6"/>`,
 convert: `<path ${ST} stroke-width="2.4" d="M4.5 8h13.5m0 0l-3.2-3.2M18 8l-3.2 3.2"/><path ${ST} stroke-width="2.4" stroke-opacity=".6" d="M19.5 16H6m0 0l3.2-3.2M6 16l3.2 3.2"/>`,
 weather: `<circle cx="9.2" cy="9" r="4.2" fill="#fff" fill-opacity=".6"/><path fill="#fff" d="M8 19.5a4.2 4.2 0 010-8.4 5.7 5.7 0 0110.9 1.6 3.4 3.4 0 01-.4 6.8z"/>`,
 compass: `<circle cx="12" cy="12" r="9.2" fill="#fff" fill-opacity=".2" stroke="#fff" stroke-width="2"/><path fill="#fff" d="M12 5.2l3.1 7.2L12 11l-3.1 1.4z"/><path fill="#fff" fill-opacity=".55" d="M12 18.8l-3.1-7.2L12 13l3.1-1.4z"/>`,
 passgen: `<rect x="4.5" y="10.5" width="15" height="10.5" rx="3.5" fill="#fff"/><path ${ST} stroke-opacity=".65" stroke-width="2.2" d="M8 10.5V8a4 4 0 018 0v2.5"/><g fill="#000" fill-opacity=".3"><circle cx="8.6" cy="15.8" r="1.2"/><circle cx="12" cy="15.8" r="1.2"/><circle cx="15.4" cy="15.8" r="1.2"/></g>`,
 draw: `<path fill="#fff" d="M4 20.2l1.1-4.6L16.4 4.3a2.2 2.2 0 013.1 0l.2.2a2.2 2.2 0 010 3.1L8.4 18.9z"/><path fill="#fff" fill-opacity=".55" d="M4 20.2l4.6-1.1-3.5-3.5z"/><path stroke="#000" stroke-opacity=".28" stroke-width="1.8" stroke-linecap="round" d="M14.4 6.3l3.3 3.3"/>`,
 tasbih: `<g fill="#fff"><circle cx="12" cy="4.8" r="1.9"/><circle cx="17.1" cy="6.9" r="1.9"/><circle cx="19.2" cy="12" r="1.9"/><circle cx="17.1" cy="17.1" r="1.9"/><circle cx="12" cy="19.2" r="1.9"/><circle cx="6.9" cy="17.1" r="1.9"/><circle cx="4.8" cy="12" r="1.9"/><circle cx="6.9" cy="6.9" r="1.9"/></g><circle cx="12" cy="12" r="3.4" fill="#fff" fill-opacity=".55"/>`,
 flash: `<path fill="#fff" d="M8 2.6h8v3.6l-1.8 2.8V19a2.2 2.2 0 01-2.2 2.2A2.2 2.2 0 019.8 19V9L8 6.2z"/><rect x="10.6" y="11" width="2.8" height="4" rx="1.4" fill="#000" fill-opacity=".3"/><path ${ST} stroke-opacity=".6" stroke-width="1.8" d="M4.6 4.4l1.6 1.3M19.4 4.4l-1.6 1.3"/>`
};
const aic = a => `<svg class="i" viewBox="0 0 24 24">${APPICON[a.id] || `<path fill="#fff" d="${a.ic}"/>`}</svg>`;
const allApps = () => [...APPS, ...EXTRA.filter(a => S.inst.includes(a.id))];
const byId = id => [...APPS, ...EXTRA].find(a => a.id === id);
const nm = a => L(a.ar, a.en);
const grad = c => { const n = parseInt(c.slice(1), 16), m = v => Math.round(v + (255 - v) * .22); return `linear-gradient(160deg,rgb(${m(n >> 16)},${m((n >> 8) & 255)},${m(n & 255)}),${c})`; };
const ACC = [['#00C2FF','#0090b8',['سماوي','Cyan']],['#00BFA5','#00897b',['تيل','Teal']],['#4285f4','#1a73e8',['أزرق','Blue']],['#9c6bff','#7c4dff',['بنفسجي','Purple']],['#ff6e9e','#e0457b',['وردي','Pink']],['#ff9800','#e65100',['برتقالي','Orange']]];
const WALLS = [
 ['#002b28',[['#009688',10,10,25],['#00bfa5',90,40,15],['#00695c',20,85,30],['#009688',85,90,18],['#00897b',50,5,12]]],
 ['#07121f',[['#00C2FF',12,12,24],['#0b6e99',88,38,16],['#0a4a6e',20,86,30],['#00C2FF',86,92,14],['#08577c',50,4,12]]],
 ['#3a1230',[['#e8a2c3',12,10,22],['#c94b87',90,45,16],['#7b2a6b',20,86,30],['#f0a25a',85,92,16],['#a63a7a',50,5,12]]],
 ['#1a1030',[['#7e57c2',10,12,24],['#b39ddb',90,42,14],['#4527a0',20,86,30],['#9575cd',85,92,16],['#5e35b1',50,5,12]]],
 ['#111418',[['#2b3038',10,10,26],['#3a414c',90,40,15],['#1d2127',20,85,30],['#2b3038',85,90,18],['#353b45',50,5,12]]],
 ['#0b2a12',[['#2e7d32',10,10,25],['#9ccc65',90,40,14],['#1b5e20',20,85,30],['#66bb6a',85,90,16],['#388e3c',50,5,12]]]];
const wallImg = w => w[1].map(([c, x, y, r]) => `radial-gradient(circle at ${x}% ${y}%,${c} 0,${c} ${r}%,transparent ${r + .1}%)`).join(',');
const ZONES = [['','Auto (device)'],['Asia/Riyadh','Riyadh (GMT+3)'],['Asia/Dubai','Dubai (GMT+4)'],['Africa/Cairo','Cairo'],['Europe/London','London'],['America/New_York','New York'],['Asia/Tokyo','Tokyo']];

/* ================= 3. Wi-Fi ================= */
const NETS = [{n:'ALANZI HOME',l:4,sec:false},{n:'TP-Link_5G',l:4,sec:true},{n:'Galaxy A16',l:3,sec:true},{n:'Home WiFi',l:3,sec:true},{n:'NETGEAR',l:2,sec:true},{n:'D-Link',l:2,sec:true},{n:'HUAWEI WiFi',l:1,sec:true}];
function wifiSvg(l) {
  const a = ['M8.5 15.5a5 5 0 017 0', 'M5.5 12.2a9.3 9.3 0 0113 0', 'M2.5 8.9a13.5 13.5 0 0119 0'];
  return `<svg class="ic" viewBox="0 0 24 24">${a.map((d, i) => `<path d="${d}" opacity="${i <= l - 2 ? 1 : .25}"/>`).join('')}<circle cx="12" cy="19" r="1.4" fill="currentColor" stroke="none"/></svg>`;
}
const LOCK_SVG = '<svg class="lk" viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg>';
const CHECK_SVG = '<svg class="chk" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="currentColor"/><path d="M7.5 12.5l3 3 6-6.5" fill="none" stroke="#00222c" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function connected() { S.seen = true; save(); refresh(); notify(L('متصل بـ ALANZI HOME', 'Connected to ALANZI HOME'), L('اتصال تجريبي', 'Simulated connection')); }
function setWifi(v, anim) { S.wifi = v; S.seen = false; if (v) S.airplane = false; save(); refresh(); if (v && !anim) setTimeout(() => { if (S.wifi && !S.seen) connected(); }, 1200); }
function renderWifi(box) {
  box.innerHTML = `<div class="wf-head"><h3>Wi-Fi</h3><label><i class="sw ${S.wifi ? 'on' : ''}" id="wfsw"></i></label></div><div id="wflist"></div>`;
  const sw = $('#wfsw', box), list = $('#wflist', box); let run = 0;
  const row = (n, small, state) => { const d = document.createElement('div'); d.className = 'item net' + (state === 1 ? ' on' : ''); d.style.background = 'var(--card)'; d.innerHTML = `${wifiSvg(n.l)}<div class="txt"><b>${n.n}</b><small>${small}</small></div>${state === 1 ? CHECK_SVG : n.sec ? LOCK_SVG : ''}`; return d; };
  async function draw() {
    const id = ++run;
    if (!S.wifi) { list.innerHTML = `<p class="muted c">${L('Wi-Fi متوقف', 'Wi-Fi is off')}</p>`; return; }
    list.innerHTML = '<div class="spin"></div>'; await wait(900); if (id !== run) return;
    list.innerHTML = '';
    const home = row(NETS[0], S.seen ? L('متصل', 'Connected') : '', S.seen ? 1 : 0);
    if (!S.seen) home.querySelector('small').innerHTML = `<span class="spin s"></span> ${L('جارٍ الاتصال…', 'Connecting…')}`;
    list.append(home);
    if (!S.seen) { await wait(1100); if (id !== run) return; connected(); home.replaceWith(row(NETS[0], L('متصل', 'Connected'), 1)); }
    const h = document.createElement('div'); h.className = 'sh'; h.style.background = 'transparent'; h.textContent = L('الشبكات المتاحة', 'Available networks'); list.append(h);
    NETS.slice(1).forEach(n => { const r = row(n, L('محمية', 'Secured'), 0); r.onclick = () => askPass(n); list.append(r); });
  }
  sw.onclick = () => { const v = !S.wifi; sw.classList.toggle('on', v); setWifi(v, true); draw(); };
  draw();
}
function dlg(html) { const d = $('#dialog'); clearTimeout(d._t); d.classList.remove('out'); d.innerHTML = `<div class="dlg">${html}</div>`; d.classList.remove('hidden'); d.onclick = e => { if (e.target === d) closeDlg(); }; return d; }
function closeDlg() { const d = $('#dialog'); if (d.classList.contains('hidden')) return; d.classList.add('out'); clearTimeout(d._t); d._t = setTimeout(() => { d.classList.add('hidden'); d.classList.remove('out'); }, 150); }
function askPass(n) {
  const d = dlg(`<h3>${n.n}</h3><input class="in" id="pw" type="${S.showPw ? 'text' : 'password'}" placeholder="${L('كلمة المرور', 'Password')}"><div class="err"></div><div class="btns"><button class="flat" id="pc">${L('إلغاء', 'Cancel')}</button><button class="flat" id="po">${L('اتصال', 'Connect')}</button></div>`);
  const pw = $('#pw', d), err = $('.err', d), ok = $('#po', d); let failed = false, busy = false;
  $('#pc', d).onclick = closeDlg; setTimeout(() => pw.focus(), 250);
  ok.onclick = async () => {
    if (busy) return;
    if (failed) { failed = false; err.textContent = ''; pw.value = ''; ok.textContent = L('اتصال', 'Connect'); pw.focus(); return; }
    if (!pw.value) { pw.classList.add('shake'); setTimeout(() => pw.classList.remove('shake'), 400); return; }
    busy = true; ok.innerHTML = '<span class="spin s"></span>'; await wait(1400); busy = false; failed = true;
    err.textContent = 'Incorrect password'; ok.textContent = L('إعادة المحاولة', 'Retry'); pw.classList.add('shake'); setTimeout(() => pw.classList.remove('shake'), 400);
  };
}
function selDlg(title, opts, cur, cb) {
  const d = dlg(`<h3>${title}</h3>${opts.map(([v, l], i) => `<div class="item" data-o="${i}" style="padding:13px 4px"><i class="rad ${v === cur ? 'on' : ''}"></i><div class="txt"><b>${l}</b></div></div>`).join('')}<div class="btns"><button class="flat" id="sc">${L('إلغاء', 'Cancel')}</button></div>`);
  $('#sc', d).onclick = closeDlg; $$('[data-o]', d).forEach(e => e.onclick = () => { closeDlg(); cb(opts[+e.dataset.o][0]); });
}
function askText(title, val, cb, ph = '') {
  const d = dlg(`<h3>${title}</h3><input class="in" id="tx" value="${esc(val)}" placeholder="${esc(ph)}"><div class="btns"><button class="flat" id="tc">${L('إلغاء', 'Cancel')}</button><button class="flat" id="to">${L('حفظ', 'Save')}</button></div>`);
  $('#tc', d).onclick = closeDlg; $('#to', d).onclick = () => { const v = $('#tx', d).value.trim(); if (!v) return; closeDlg(); cb(v); }; setTimeout(() => $('#tx', d).focus(), 200);
}
function confirmDlg(title, body, yes, cb) {
  const d = dlg(`<h3>${title}</h3><p class="muted" style="margin-bottom:16px">${body}</p><div class="btns"><button class="flat" id="cn">${L('إلغاء', 'Cancel')}</button><button class="flat" id="cy">${yes}</button></div>`);
  $('#cn', d).onclick = closeDlg; $('#cy', d).onclick = () => { closeDlg(); cb(); };
}
async function progress(title, ms, done) { dlg(`<h3>${title}</h3><div class="spin"></div>`); await wait(ms); closeDlg(); done && done(); }
function pinEntry(title, cb, onCancel) {
  let v = '';
  const d = dlg(`<h3 class="center">${title}</h3><div class="dots" id="pd"><i></i><i></i><i></i><i></i></div><div class="err center" id="pe"></div><div class="keys k3 free pk">${[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k => `<div class="key" data-k="${k}">${k}</div>`).join('')}</div><div class="btns"><button class="flat" id="px">${L('إلغاء', 'Cancel')}</button></div>`);
  const draw = () => $$('#pd i', d).forEach((x, i) => x.classList.toggle('on', i < v.length));
  $('#px', d).onclick = () => { closeDlg(); onCancel && onCancel(); };
  $$('.key', d).forEach(k => k.onclick = async () => {
    const x = k.dataset.k; if (x === '') return; beep(700, .04);
    if (x === '⌫') v = v.slice(0, -1); else if (v.length < 4) v += x; draw();
    if (v.length === 4) { const r = await cb(v); if (r === false) { v = ''; draw(); $('#pe', d).textContent = L('رمز غير صحيح', 'Wrong PIN'); const b = $('.dlg', d); b.classList.add('shake'); setTimeout(() => b.classList.remove('shake'), 400); } else if (r !== 'keep') closeDlg(); }
  });
}

/* ================= 4. System UI ================= */
function notify(t, b, c = '#00897b', p = P.settings) { if (S.dnd) return; NOTIFS.unshift({t, b, c, p}); renderNotifs(); if (S.nsound) beep(880, .1, 0, S.volR); }
function renderNotifs() {
  const d = new Date(), el = $('#notif');
  el.innerHTML = `<div class="n-top"><b>${fmtT(d)}</b><button class="flat" id="nclr">${L('مسح الكل', 'Clear all')}</button></div>` +
   (NOTIFS.length ? NOTIFS.map((n, i) => `<div class="n"><div class="ico" style="background:${grad(n.c)}">${ic(n.p)}</div><div class="txt"><b>${n.t}</b><small>${n.b}</small></div><button data-x="${i}">${ic(P.close)}</button></div>`).join('') : `<p class="muted c">${L('لا توجد إشعارات', 'No notifications')}</p>`);
  $('#nclr').onclick = () => { NOTIFS.length = 0; renderNotifs(); };
  $$('[data-x]', el).forEach(b => b.onclick = () => { NOTIFS.splice(+b.dataset.x, 1); renderNotifs(); });
  $$('.n', el).forEach((n, i) => { const item = NOTIFS[i]; let x0 = null;
    n.onpointerdown = e => { if (e.target.closest('button')) return; x0 = e.clientX; n.style.transition = 'none'; n.setPointerCapture(e.pointerId); };
    n.onpointermove = e => { if (x0 === null) return; const d2 = e.clientX - x0; n.style.transform = `translateX(${d2}px)`; n.style.opacity = 1 - Math.abs(d2) / 260; };
    n.onpointerup = e => { if (x0 === null) return; const d2 = e.clientX - x0; x0 = null; n.style.transition = '.2s';
      if (Math.abs(d2) > 90) { n.style.transform = `translateX(${d2 > 0 ? 420 : -420}px)`; n.style.opacity = 0; setTimeout(() => { const k = NOTIFS.indexOf(item); if (k >= 0) NOTIFS.splice(k, 1); renderNotifs(); }, 200); }
      else { n.style.transform = ''; n.style.opacity = ''; } }; });
  const ln = $('#lk-n'), top = NOTIFS[0];
  ln.innerHTML = S.lkNotif && top && !S.dnd ? `<div><b>${top.t}</b>${top.b}</div>` : '';
}
const TILES = [['wifi','wifi','Wi-Fi'],['bt','bt','Bluetooth'],['dnd','dnd',['عدم الإزعاج','Do not disturb']],['airplane','plane',['وضع الطائرة','Airplane']],['data','data',['بيانات الجوّال','Mobile data']],['hotspot','hot',['نقطة اتصال','Hotspot']],
 ['saver','batt',['توفير البطارية','Battery saver']],['dark','moon',['الوضع الداكن','Dark mode']],['night','display',['إضاءة ليلية','Night light']],['torch','flash',['المصباح','Flashlight']],['lock','lock',['قفل','Lock']],['power','power',['إطفاء','Power off']]];
function renderCC() {
  const on = k => k === 'torch' ? torch : (k === 'lock' || k === 'power') ? false : S[k];
  $('#cc').innerHTML = `<div class="sl">${ic(P.sun)}<input type="range" id="br" min="20" max="100" value="${S.bright}"></div>
   <div class="tiles">${TILES.map(([k, i, l]) => `<div class="tile ${on(k) ? 'on' : ''}" data-k="${k}"><i>${ic(P[i])}</i>${Array.isArray(l) ? L(l[0], l[1]) : l}</div>`).join('')}</div>
   <div class="qfoot"><svg viewBox="0 0 24 24" id="qs-set"><path d="${P.settings}"/></svg><span>ALANZI ANDROID</span></div>`;
  $$('.tile').forEach(t => t.onclick = () => tile(t.dataset.k));
  $('#br').oninput = e => { S.bright = +e.target.value; save(); refresh(true); };
  $('#qs-set').onclick = () => openApp('settings');
}
function tile(k) {
  if (k === 'wifi') return setWifi(!S.wifi);
  if (k === 'lock') { closePanels(); return showLock(); }
  if (k === 'torch') return setTorch(!torch);
  if (k === 'power') { closePanels(); return powerMenu(); }
  if (k === 'hotspot' && !S.hotspot && (!S.data || S.airplane)) return toast(L('فعّل بيانات الجوّال أولًا', 'Turn on mobile data first'));
  set(k, !S[k]);
}
function set(k, v) {
  S[k] = v;
  if (k === 'airplane' && v) { S.wifi = false; S.bt = false; S.data = false; S.hotspot = false; S.seen = false; }
  if ((k === 'bt' || k === 'data') && v) S.airplane = false;
  if (k === 'data' && !v) S.hotspot = false;
  save(); refresh();
}
function setTorch(v) { torch = v; const t = $('#torch'); t.classList.toggle('hidden', !v); t.innerHTML = v ? `<button class="fill">${L('إطفاء المصباح', 'Turn off')}</button>` : ''; t.onclick = () => setTorch(false); renderCC(); }
function chrome() { os.classList.toggle('onlight', !!(appId || drawerOpen || panel) && !recentsOpen && !lockOn); }
let shownWall = -1;
function paintWall() { if (shownWall === S.wall) return; const w = WALLS[S.wall], a = $('#wall'), b = $('#wall2'), apply = el => { el.style.backgroundColor = w[0]; el.style.backgroundImage = wallImg(w); };
  if (shownWall < 0) { apply(a); shownWall = S.wall; return; }
  apply(b); b.style.opacity = 1; shownWall = S.wall; clearTimeout(b._t);
  b._t = setTimeout(() => { apply(a); b.style.transition = 'none'; b.style.opacity = 0; void b.offsetWidth; b.style.transition = ''; }, 440); }
function refresh(light) {
  const r = document.documentElement, a = ACC[S.accent] || ACC[0];
  r.dataset.theme = S.dark ? 'dark' : 'light'; r.style.setProperty('--p', a[0]); r.style.setProperty('--pd', S.dark ? a[0] : a[1]); r.style.setProperty('--fs', S.fs);
  $('#dim').style.opacity = ((100 - S.bright) / 100) * .7 + (S.saver ? .12 : 0);
  $('#night').style.display = S.night ? 'block' : 'none';
  const ph = $('#phone').classList;
  ph.toggle('nolabels', !S.labels); ph.toggle('circle', S.circle); ph.toggle('nohclock', !S.showClock); ph.toggle('nowx', !S.showWx); ph.toggle('cols5', S.cols5); ph.toggle('nolkdate', !S.lkDate); ph.toggle('nolkhint', !S.lkHint);
  ph.toggle('bold', S.bold); ph.toggle('noanim', S.noanim); ph.toggle('bigicons', S.bigIcons); ph.toggle('inv', S.inv); ph.toggle('gray', S.gray); ph.toggle('gesture', S.gesture);
  $('.widgets').classList.toggle('on', S.widgets);
  if (light) return;
  paintWall();
  $('#sb-icons').innerHTML = [S.wifi && P.wifi, S.bt && P.bt, S.vpn && P.key, S.hotspot && P.hot, S.dnd && P.dnd, S.airplane && P.plane, !S.airplane && P.sig, P.batt].filter(Boolean).map(p => ic(p, 'i')).join('') + (S.pct ? ` <span>${batt}</span>` : '');
  $('#pill-t').textContent = L('ابحث في التطبيقات', 'Search apps'); $('#search').placeholder = L('بحث في التطبيقات', 'Search apps'); $('#rc-clear').textContent = L('مسح الكل', 'CLEAR ALL');
  renderCC(); renderNotifs(); tick(); chrome();
}
if (navigator.getBattery) navigator.getBattery().then(b => { const u = () => { batt = Math.round(b.level * 100) + '%'; refresh(); }; u(); b.onlevelchange = u; }).catch(() => {});
function tick() {
  const d = new Date(), tm = fmtT(d), dt = d.toLocaleDateString(LOC(), {...tzo(), weekday: 'long', day: 'numeric', month: 'long'});
  $('#clock').textContent = tm; $('#lk-time').textContent = tm; $('#sb-time').textContent = tm; $('#date').textContent = dt; $('#lk-date').textContent = dt;
  const pc = parseInt(batt) || 0; $('#ring').style.setProperty('--v', pc); $('#w-pct').textContent = pc; $('#w-bl').textContent = L('البطارية', 'Battery');
  $('#w-nt').textContent = S.wifi ? 'ALANZI HOME' : 'Wi-Fi'; $('#w-ns').textContent = S.wifi ? L('متصل', 'Connected') : L('متوقف', 'Off');
  $('#wx').textContent = !online() ? L('الطقس غير متاح — لا يوجد اتصال', 'Weather unavailable — no connection') : (S.loc && S.pm_loc !== false) ? `\u200E28° · ${L('مشمس · الرياض', 'Sunny · Riyadh')}` : L('الموقع متوقف', 'Location is off');
}
setInterval(tick, 5000);
function applyLang() { document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'ar' ? 'rtl' : 'ltr'; $$('[data-ar]').forEach(e => e.textContent = L(e.dataset.ar, e.dataset.en)); renderIcons(); refresh(); }
const iconHTML = a => `<div class="app-i" data-app="${a.id}"><div class="bx" style="background:${grad(a.c)}">${aic(a)}</div>${nm(a)}</div>`;
function renderIcons(q = '') {
  $('#dock').innerHTML = ['phone','browser','camera','settings'].map(id => iconHTML(byId(id))).join('');
  $('#all').innerHTML = allApps().filter(a => (a.ar + a.en).toLowerCase().includes(q.toLowerCase())).map(iconHTML).join('');
  $$('[data-app]').forEach(e => e.onclick = () => { closeDrawer(); openApp(e.dataset.app); });
}
function openDrawer() { drawerOpen = true; $('#drawer').classList.add('open'); chrome(); }
function closeDrawer() { drawerOpen = false; $('#drawer').classList.remove('open'); $('#search').value = ''; renderIcons(); chrome(); }
function openPanel(n) { closePanels(); panel = n; $('#' + n).classList.add('open'); $('#scrim').classList.add('on'); if (n === 'notif') renderNotifs(); chrome(); }
function closePanels() { panel = null; $$('.panel').forEach(p => p.classList.remove('open')); $('#scrim').classList.remove('on'); chrome(); }
function showLock() { lockOn = true; const l = $('#lock'); l.classList.remove('hidden'); l.style.transition = 'none'; l.style.transform = ''; l.style.opacity = 0; void l.offsetWidth; l.style.transition = 'opacity .25s'; l.style.opacity = 1; renderNotifs(); chrome(); }
function unlock() { const l = $('#lock'); l.style.transition = 'opacity .25s'; l.style.transform = ''; l.style.opacity = 0; setTimeout(() => { l.classList.add('hidden'); lockOn = false; lastAct = Date.now(); chrome(); }, 250); }
function tryUnlock() {
  const l = $('#lock'); l.style.transition = '.15s'; l.style.transform = ''; l.style.opacity = '';
  if (!S.pinh) return unlock();
  pinEntry(L('أدخل رمز PIN', 'Enter your PIN'), pin => { if (hash(pin) === S.pinh) { unlock(); return true; } return false; });
}
function openRecents() { closePanels(); recentsOpen = true; $('#recents').classList.add('open');
  $('#rc-list').innerHTML = RECENT.length ? RECENT.map(id => { const a = byId(id); return `<div class="rc" data-r="${id}"><div class="ico" style="background:${grad(a.c)}">${aic(a)}</div><b>${nm(a)}</b></div>`; }).join('') : `<p style="color:#fff">${L('لا توجد تطبيقات حديثة', 'No recent apps')}</p>`;
  $$('[data-r]').forEach(e => e.onclick = () => { closeRecents(); openApp(e.dataset.r); }); chrome(); }
function closeRecents() { recentsOpen = false; $('#recents').classList.remove('open'); chrome(); }
$('#rc-clear').onclick = () => { RECENT.length = 0; openRecents(); };
function goHome() { closeDlg(); closePanels(); closeRecents(); closeDrawer(); if (appId) closeApp(); }
function back() {
  if (!$('#dialog').classList.contains('hidden')) return closeDlg();
  if (lockOn) return;
  if (panel) return closePanels();
  if (recentsOpen) return closeRecents();
  if (appId) { if (inCall) return endCall(); if (appId === 'settings' && sub && sub !== 'main') return openApp('settings', parentOf(sub)); return closeApp(); }
  if (drawerOpen) closeDrawer();
}
$('#n-home').innerHTML = '<svg viewBox="0 0 22 22"><circle cx="11" cy="11" r="9"/></svg>'; $('#n-rec').innerHTML = '<svg viewBox="0 0 20 20"><rect x="2" y="2" width="16" height="16" rx="3"/></svg>'; $('#n-back').innerHTML = '<svg viewBox="0 0 22 22"><path d="M4 3l15 8-15 8z" style="transform:scaleX(-1);transform-origin:center"/></svg>';
$('#n-home').onclick = goHome; $('#n-back').onclick = back; $('#n-rec').onclick = () => recentsOpen ? closeRecents() : openRecents();
$('#app-back').innerHTML = ic(P.back); $('#app-back').onclick = back;
$('#scrim').onclick = closePanels;
$('#w-batt').onclick = () => openApp('settings', 'battery'); $('#w-net').onclick = () => openApp('settings', 'wifi');
$('#pill').onclick = () => { openDrawer(); setTimeout(() => $('#search').focus(), 300); };
$('#trig').onclick = openDrawer;
$('#search').oninput = e => renderIcons(e.target.value);
$('#sb-time').onclick = () => openPanel('notif'); $('#sb-icons').onclick = () => openPanel('cc');
$('#phone').addEventListener('pointerdown', e => { lastAct = Date.now(); if (!S.touches) return; const r = $('#phone').getBoundingClientRect(), t = document.createElement('div'); t.className = 'touch'; t.style.left = (e.clientX - r.left) + 'px'; t.style.top = (e.clientY - r.top) + 'px'; $('#phone').append(t); setTimeout(() => t.remove(), 450); });
setInterval(() => { if (S.timeout > 0 && !S.stay && !lockOn && !os.classList.contains('hidden') && Date.now() - lastAct > S.timeout) { closePanels(); closeDlg(); showLock(); } }, 4000);

function powerMenu() {
  const d = dlg(`<button class="pm" id="pm-off">${ic(P.power)}<span>${L('إطفاء', 'Power off')}</span></button><button class="pm" id="pm-rs">${ic(P.restart)}<span>${L('إعادة التشغيل', 'Restart')}</span></button><div class="btns"><button class="flat" id="pm-c">${L('إلغاء', 'Cancel')}</button></div>`);
  $('#pm-c', d).onclick = closeDlg; $('#pm-off', d).onclick = () => { closeDlg(); shutdown(false); }; $('#pm-rs', d).onclick = () => { closeDlg(); shutdown(true); };
}
async function shutdown(restart) {
  goHome(); setTorch(false); const off = $('#off'); off.classList.remove('hidden'); $('#off-btn').classList.add('hidden');
  $('#off-msg').innerHTML = `<div class="spin"></div><p>${restart ? L('جارٍ إعادة التشغيل…', 'Restarting…') : L('جارٍ الإيقاف…', 'Shutting down…')}</p>`;
  await wait(1600); os.classList.add('hidden');
  if (restart) { off.classList.add('hidden'); return bootSeq(); }
  $('#off-msg').innerHTML = `<p style="color:#555;font-size:13px">${L('اضغط زر التشغيل', 'Press the power button')}</p>`; $('#off-btn').classList.remove('hidden');
}

/* ================= 5. Settings ================= */
const parentOf = id => (PG[id] ? PG[id]().p : null) || (id === 'wifi' ? 'network' : 'main');
const U = () => { const t = new Date().toDateString(); if (S.usageDay !== t) { S.usageDay = t; S.usage = {}; } };
function endUse() { if (appId && useStart) { U(); S.usage[appId] = (S.usage[appId] || 0) + Math.round((Date.now() - useStart) / 1000); save(); } useStart = 0; }
const ago = t => t ? new Date(t).toLocaleString(LOC(), {...tzo(), dateStyle: 'medium', timeStyle: 'short'}) : L('لم يحدث بعد', 'Never');
const mb = n => n < 1 ? Math.round(n * 1024) + ' KB' : n.toFixed(1) + ' MB';
const uuid = () => ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
let buildTaps = 0;
const sel = (k, t, o, f) => ['sel', k, t, o, f];
const yn = k => S[k] ? L('مفعّل', 'On') : L('متوقف', 'Off');

function setLock(v) {
  if (v === 'pin') pinEntry(L('اختر رمز PIN جديد', 'Choose a new PIN'), p1 => { pinEntry(L('أكّد رمز PIN', 'Confirm your PIN'), p2 => { if (p1 !== p2) { toast(L('الرمزان غير متطابقين', "PINs don't match")); return; } S.screenLock = 'pin'; S.pinh = hash(p2); save(); toast(L('تم تفعيل قفل PIN', 'PIN lock enabled')); if (!S.done) setupStep(5); if (appId === 'settings') openApp('settings', 'security'); }); return 'keep'; });
  else if (S.pinh) pinEntry(L('أدخل رمز PIN الحالي', 'Enter your current PIN'), p => { if (hash(p) !== S.pinh) return false; S.screenLock = 'none'; S.pinh = ''; save(); toast(L('تم إلغاء القفل', 'Screen lock removed')); if (appId === 'settings') openApp('settings', 'security'); return true; });
}
function appInfo(id) {
  const a = byId(id), extra = EXTRA.includes(a); U();
  const d = dlg(`<h3>${nm(a)}</h3><p class="muted" style="margin-bottom:6px">${extra ? L('مثبّت من المتجر', 'Installed from Store') : L('تطبيق نظام', 'System app')}</p><p class="muted" style="margin-bottom:12px">${L('وقت الاستخدام اليوم', 'Used today')}: ${Math.round((S.usage[id] || 0) / 60)} ${L('د', 'min')}</p><div class="btns"><button class="flat" id="ai-o">${L('فتح', 'Open')}</button>${extra ? `<button class="flat" id="ai-u">${L('إزالة', 'Uninstall')}</button>` : ''}<button class="flat" id="ai-c">${L('إغلاق', 'Close')}</button></div>`);
  $('#ai-c', d).onclick = closeDlg; $('#ai-o', d).onclick = () => { closeDlg(); openApp(id); };
  if (extra) $('#ai-u', d).onclick = () => { S.inst = S.inst.filter(x => x !== id); save(); renderIcons(); closeDlg(); openApp('settings', 'applist'); };
}
const BTD = ['ALANZI Buds', 'Car Audio', 'Smart Watch', 'BT Speaker'];
function checkup() { return [[L('قفل الشاشة', 'Screen lock'), S.screenLock !== 'none'], ['Play Protect', S.protect], ['Find My Device', S.fmd], [L('التثبيت من مصادر غير معروفة', 'Unknown sources blocked'), !S.unk], [L('النسخ الاحتياطي', 'Backup'), S.backup && !!S.acct]]; }
const PG = {
 network: () => ({p:'main', t:L('الشبكة والإنترنت','Network & internet'), i:[
  ['nav','Wi-Fi',S.wifi ? 'ALANZI HOME' : L('متوقف','Off'),'wifi'],['nav',L('الشبكة المحمولة','Mobile network'),'ALANZI Mobile · 4G','mobile'],['nav',L('نقطة الاتصال والربط','Hotspot & tethering'),yn('hotspot'),'hotspot'],
  ['sw','airplane',L('وضع الطائرة','Airplane mode'),L('يوقف Wi-Fi والبلوتوث والبيانات','Turns off Wi-Fi, Bluetooth and data'),0],['nav',L('استخدام البيانات','Data usage'),mb(S.dataW + S.dataM),'datausage'],
  ['sw','vpn','VPN',L('متصل عبر ALANZI VPN','Connected via ALANZI VPN'),0],sel('dns',L('DNS الخاص','Private DNS'),[['auto',L('تلقائي','Automatic')],['off',L('متوقف','Off')],['host','dns.alanzi.net']])]}),
 mobile: () => ({p:'network', t:L('الشبكة المحمولة','Mobile network'), i:[['sw','data',L('بيانات الجوّال','Mobile data'),L('الوصول للإنترنت عبر الشبكة المحمولة','Access the internet over mobile network'),1],['sw','roaming',L('التجوال','Roaming'),L('الاتصال أثناء السفر','Connect while travelling'),0],sel('nettype',L('نوع الشبكة المفضل','Preferred network type'),[['4g','4G (LTE)'],['3g','3G'],['2g','2G']]),['info',L('المشغّل','Carrier'),'ALANZI Mobile'],['info',L('حالة الإشارة','Signal'),S.airplane ? L('لا توجد خدمة','No service') : L('جيدة','Good')]]}),
 hotspot: () => ({p:'network', t:L('نقطة الاتصال والربط','Hotspot & tethering'), i:[['sw','hotspot',L('نقطة اتصال Wi-Fi','Wi-Fi hotspot'),L('تتطلب بيانات الجوّال','Requires mobile data'),0],['info',L('اسم الشبكة','Network name'),'ALANZI-Hotspot'],['nav',L('كلمة المرور','Password'),'•'.repeat(S.hpw.length),() => askText(L('كلمة مرور نقطة الاتصال','Hotspot password'),S.hpw,v => { S.hpw = v; save(); openApp('settings','hotspot'); })]]}),
 datausage: () => ({p:'network', t:L('استخدام البيانات','Data usage'), i:[['info','Wi-Fi',mb(S.dataW)],['info',L('بيانات الجوّال','Mobile data'),mb(S.dataM)],['nav',L('تصفير العدّاد','Reset counters'),'',() => { S.dataW = 0; S.dataM = 0; save(); openApp('settings','datausage'); }]]}),
 connected: () => ({p:'main', t:L('الأجهزة المتصلة','Connected devices'), i:[['sw','bt','Bluetooth',L('اسم الجهاز: ','Device name: ') + S.devName,1],
  ...(S.bt ? [['h',L('الأجهزة القريبة','Nearby devices')], ...BTD.map(n => ['nav',n,S.btPaired.includes(n) ? L('مقترن','Paired') : L('غير مقترن','Not paired'),() => { const on = S.btPaired.includes(n); progress(on ? L('جارٍ إلغاء الاقتران…','Unpairing…') : L('جارٍ الاقتران…','Pairing…'),1000,() => { S.btPaired = on ? S.btPaired.filter(x => x !== n) : [...S.btPaired, n]; save(); openApp('settings','connected'); }); }])] : []),
  ['sw','nfc','NFC',L('تبادل البيانات عند التقارب','Exchange data when devices touch'),1],sel('usb',L('تفضيلات USB','USB preferences'),[['charge',L('شحن هذا الجهاز','Charging this device')],['file',L('نقل الملفات','File transfer')]]),['info',L('الطباعة','Printing'),L('لا توجد خدمات','No services')]]}),
 apps: () => ({p:'main', t:L('التطبيقات والإشعارات','Apps & notifications'), i:[['nav',L('عرض كل التطبيقات','See all apps'),allApps().length + ' ' + L('تطبيق','apps'),'applist'],['nav',L('التطبيقات الافتراضية','Default apps'),'','defaults'],['nav',L('مدير الأذونات','Permission manager'),'','perms'],['nav',L('الإشعارات','Notifications'),yn('nsound'),'notifications'],['sw','unk',L('التثبيت من مصادر غير معروفة','Install unknown apps'),'',0]]}),
 applist: () => ({p:'apps', t:L('كل التطبيقات','All apps'), i:allApps().map(a => ['nav',nm(a),EXTRA.includes(a) ? L('مثبّت','Installed') : L('تطبيق نظام','System app'),() => appInfo(a.id)])}),
 defaults: () => ({p:'apps', t:L('التطبيقات الافتراضية','Default apps'), i:[['info',L('تطبيق المتصفح','Browser app'),L('المتصفح','Browser')],['info',L('تطبيق الهاتف','Phone app'),L('الهاتف','Phone')],['info',L('تطبيق الكاميرا','Camera app'),L('الكاميرا','Camera')],['info',L('الشاشة الرئيسية','Home app'),'ALANZI Launcher']]}),
 perms: () => ({p:'apps', t:L('مدير الأذونات','Permission manager'), i:[['nav',L('الكاميرا','Camera'),S.pm_camera === false ? L('مرفوض','Denied') : L('مسموح لتطبيق واحد','1 app allowed'),'perm_camera'],['nav',L('التخزين','Storage'),S.pm_storage === false ? L('مرفوض','Denied') : L('مسموح لتطبيقين','2 apps allowed'),'perm_storage'],['nav',L('الهاتف','Phone'),S.pm_phone === false ? L('مرفوض','Denied') : L('مسموح لتطبيق واحد','1 app allowed'),'perm_phone'],['nav',L('الموقع','Location'),S.pm_loc === false ? L('مرفوض','Denied') : L('مسموح لتطبيقين','2 apps allowed'),'perm_loc']]}),
 perm_camera: () => ({p:'perms', t:L('إذن الكاميرا','Camera permission'), i:[['sw','pm_camera',L('الكاميرا','Camera'),'',1]]}),
 perm_storage: () => ({p:'perms', t:L('إذن التخزين','Storage permission'), i:[['sw','pm_storage',L('المعرض','Gallery'),'',1]]}),
 perm_phone: () => ({p:'perms', t:L('إذن الهاتف','Phone permission'), i:[['sw','pm_phone',L('الهاتف','Phone'),'',1]]}),
 perm_loc: () => ({p:'perms', t:L('إذن الموقع','Location permission'), i:[['sw','pm_loc',L('الطقس والتقويم','Weather & Home'),'',1]]}),
 notifications: () => ({p:'apps', t:L('الإشعارات','Notifications'), i:[['sw','dnd',L('عدم الإزعاج','Do not disturb'),L('كتم الإشعارات','Mute notifications'),0],['sw','lkNotif',L('الإشعارات على شاشة القفل','Notifications on lock screen'),'',1],['sw','nsound',L('صوت الإشعارات','Notification sound'),'',1],['nav',L('مسح كل الإشعارات','Clear all'),String(NOTIFS.length),() => { NOTIFS.length = 0; renderNotifs(); openApp('settings','notifications'); }]]}),
 battery: () => ({p:'main', t:L('البطارية','Battery'), i:[['info',L('مستوى البطارية','Battery level'),batt],['sw','saver',L('توفير الطاقة','Battery saver'),L('يخفض سطوع الشاشة','Dims the screen'),0],['sw','pct',L('نسبة البطارية','Battery percentage'),L('في شريط الحالة','In the status bar'),1],['nav',L('استخدام الشاشة','Screen time'),'','wellbeing']]}),
 display: () => ({p:'main', t:L('الشاشة','Display'), i:[['sw','dark',L('الوضع الداكن','Dark mode'),L('تغيير مظهر النظام','Change the system theme'),0],['rg','bright',L('السطوع','Brightness')],['sw','night',L('إضاءة ليلية','Night light'),L('لون دافئ للشاشة','Warm screen tint'),0],sel('fs',L('حجم الخط','Font size'),[[.9,L('صغير','Small')],[1,L('افتراضي','Default')],[1.15,L('كبير','Large')],[1.3,L('الأكبر','Largest')]]),sel('accent',L('لون التمييز','Accent colour'),ACC.map((a, i) => [i, L(a[2][0], a[2][1])])),sel('timeout',L('مهلة الشاشة','Screen timeout'),[[15000,'15s'],[30000,'30s'],[60000,'1 min'],[120000,'2 min'],[300000,'5 min'],[0,L('بدون','Never')]]),['sw','circle',L('أيقونات دائرية','Round icons'),L('بدل المربعة','Instead of rounded squares'),0],['nav',L('الخلفية','Wallpaper'),'','wallpaper'],sel('lang',L('اللغة','Language'),[['ar','العربية'],['en','English']],() => applyLang())]}),
 sound: () => ({p:'main', t:L('الصوت','Sound'), i:[['rg','volM',L('الوسائط','Media volume')],['rg','volR',L('الرنين والإشعارات','Ring & notification volume')],['rg','volA',L('المنبّه','Alarm volume')],sel('ring',L('نغمة الرنين','Ringtone'),[['chime','Chime'],['pulse','Pulse'],['bell','Bell']],v => RING[v]()),['sw','tap',L('أصوات اللمس','Touch sounds'),'',1],['sw','vib',L('الاهتزاز عند اللمس','Vibrate on touch'),L('إن كان الجهاز يدعمه','If the device supports it'),0],['sw','dnd',L('عدم الإزعاج','Do not disturb'),'',0]]}),
 storage: () => { const kb = Math.round(Object.keys(localStorage).reduce((a, k) => a + (localStorage[k] || '').length, 0) / 1024); return {p:'main', t:L('التخزين','Storage'), i:[['info',L('السعة الإجمالية','Total'),'64 GB'],['info',L('المستخدَم','Used'),(12.4 + kb / 1048576).toFixed(2) + ' GB'],['info',L('بيانات ALANZI المحفوظة','ALANZI saved data'),kb + ' KB'],['info',L('الصور','Photos'),String(JSON.parse(localStorage.getItem('az.photos') || '[]').length)],['info',L('الملاحظات','Notes'),String(S.notes.length)],['info',L('التطبيقات المثبتة','Installed apps'),String(allApps().length)]]}; },
 privacy: () => ({p:'main', t:L('الخصوصية','Privacy'), i:[['nav',L('مدير الأذونات','Permission manager'),'','perms'],['sw','showPw',L('إظهار كلمات المرور','Show passwords'),L('أثناء الكتابة','While typing'),0],['sw','lkNotif',L('محتوى الإشعارات على القفل','Notification content on lock screen'),'',1],['nav',L('الإعلانات','Ads'),'','ads'],['nav','Autofill','','autofill']]}),
 location: () => ({p:'main', t:L('الموقع','Location'), i:[['sw','loc',L('استخدام الموقع','Use location'),L('يسمح للتطبيقات بمعرفة موقعك','Lets apps use your location'),1],['nav',L('أذونات الموقع','App location permissions'),'','perm_loc'],['h',L('خدمات الموقع','Location services')],['sw','wifiScan',L('البحث عن شبكات Wi-Fi','Wi-Fi scanning'),L('لتحسين دقة الموقع','Improves location accuracy'),1],['sw','btScan',L('البحث عن أجهزة Bluetooth','Bluetooth scanning'),'',1],['sw','gla',L('دقة الموقع من Google','Google Location Accuracy'),'',1],['sw','locApps',L('السماح للتطبيقات باستخدام الموقع','Allow apps to use location'),'',1],['sw','locAssist',L('مساعدة GPS عبر الإنترنت','Download GPS assistance data'),'',1]]}),
 security: () => ({p:'main', t:L('الأمان وشاشة القفل','Security & lock screen'), i:[['h',L('أمان الجهاز','Device security')],sel('screenLock',L('قفل الشاشة','Screen lock'),[['none',L('لا يوجد','None')],['pin','PIN']],setLock),['nav','Find My Device',yn('fmd'),'fmd'],['nav','Google Play Protect',yn('protect'),'protect'],['sw','unk',L('التثبيت من مصادر غير معروفة','Install unknown apps'),'',0],['info',L('التشفير','Encryption'),L('الجهاز مشفّر','Device encrypted')],['h',L('شاشة القفل','Lock screen')],['sw','lkDate',L('التاريخ','Date'),'',1],['sw','lkHint',L('نص التلميح','Hint text'),'',1],['sw','lkNotif',L('الإشعارات','Notifications'),'',1],['nav',L('قفل الشاشة الآن','Lock now'),'',() => { goHome(); showLock(); }]]}),
 fmd: () => ({p:'security', t:'Find My Device', i:[['sw','fmd','Find My Device',L('تحديد موقع الجهاز وقفله ومسحه عن بُعد','Locate, lock or erase this device remotely'),1],['info',L('آخر ظهور','Last seen'),L('الآن','Now')]]}),
 protect: () => ({p:'security', t:'Google Play Protect', i:[['sw','protect',L('فحص التطبيقات','Scan apps with Play Protect'),L('التحقق من التطبيقات بحثًا عن سلوك ضار','Check apps for harmful behaviour'),1],['nav',L('فحص الآن','Scan now'),L('آخر فحص: ','Last scan: ') + ago(S.lastScan),() => { if (!S.protect) return toast(L('فعّل الفحص أولًا', 'Turn on scanning first')); progress(L('جارٍ فحص التطبيقات…', 'Scanning apps…'), 2200, () => { S.lastScan = Date.now(); save(); notify('Google Play Protect', L('لم يتم العثور على تطبيقات ضارة', 'No harmful apps found'), '#2e7d32', P.shield); openApp('settings', 'protect'); }); }]]}),
 accounts: () => ({p:'main', t:L('الحسابات','Accounts'), i:[S.acct ? ['nav',S.acct.name,S.acct.email,'gacct'] : ['nav',L('إضافة حساب','Add account'),'Google',() => addAccount()],['sw','autosync',L('مزامنة البيانات تلقائيًا','Automatically sync data'),'',1]]}),
 gacct: () => ({p:'accounts', t:L('الحساب','Account'), i:[['info',L('الاسم','Name'),S.acct ? S.acct.name : '-'],['info',L('البريد','Email'),S.acct ? S.acct.email : '-'],['nav',L('إزالة الحساب','Remove account'),'',() => confirmDlg(L('إزالة الحساب؟','Remove account?'),L('سيتم حذف بيانات الحساب من هذا الجهاز.','Account data will be removed from this device.'),L('إزالة','Remove'),() => { S.acct = null; save(); openApp('settings','accounts'); })]]}),
 google: () => ({p:'main', t:'Google', i:[S.acct ? ['nav',S.acct.name,S.acct.email,'gacct'] : ['nav',L('تسجيل الدخول','Sign in'),L('أضف حساب Google','Add a Google account'),() => addAccount()],['h',L('الخدمات','Services')],['nav',L('الإعلانات','Ads'),'','ads'],['nav','Autofill',S.autofill === 'none' ? L('لا يوجد','None') : 'ALANZI Autofill','autofill'],['nav',L('النسخ الاحتياطي','Backup'),yn('backup'),'backup'],['nav','Find My Device',yn('fmd'),'fmd'],['nav',L('الأمان','Security'),'','gsec'],['nav',L('الإعداد والاستعادة','Set up & restore'),'','gsetup'],['nav',L('الأجهزة والمشاركة','Devices & sharing'),'','gdev']]}),
 ads: () => { if (!S.adId) { S.adId = uuid(); save(); } return {p:'google', t:L('الإعلانات','Ads'), i:[['sw','adsPers',L('إعلانات مخصّصة','Ads personalisation'),L('عرض إعلانات بناءً على اهتماماتك','Show ads based on your interests'),1],['info',L('معرّف الإعلانات','Advertising ID'),S.adId],['nav',L('إعادة تعيين معرّف الإعلانات','Reset advertising ID'),'',() => { S.adId = uuid(); save(); toast(L('تمت إعادة التعيين', 'Advertising ID reset')); openApp('settings', 'ads'); }]]}; },
 autofill: () => ({p:'google', t:'Autofill', i:[sel('autofill',L('خدمة الملء التلقائي','Autofill service'),[['none',L('لا يوجد','None')],['alanzi','ALANZI Autofill']]),['info',L('الحساب','Account'),S.acct ? S.acct.email : L('غير مسجّل','Not signed in')]]}),
 backup: () => ({p:'google', t:L('النسخ الاحتياطي','Backup'), i:[['sw','backup',L('النسخ إلى Google Drive','Back up to Google Drive'),L('التطبيقات والإعدادات والملاحظات','Apps, settings and notes'),1],['info',L('الحساب','Account'),S.acct ? S.acct.email : L('غير مسجّل','Not signed in')],['info',L('آخر نسخة','Last backup'),ago(S.lastBackup)],['nav',L('النسخ الآن','Back up now'),'',() => { if (!S.acct) return toast(L('أضف حسابًا أولًا', 'Add an account first')); if (!S.backup) return toast(L('فعّل النسخ الاحتياطي', 'Turn on backup')); if (!online()) return toast(L('لا يوجد اتصال', 'No connection')); progress(L('جارٍ النسخ الاحتياطي…', 'Backing up…'), 2200, () => { S.lastBackup = Date.now(); useData(3); notify(L('النسخ الاحتياطي', 'Backup'), L('اكتمل النسخ الاحتياطي', 'Backup complete'), '#1a73e8', P.cloud); openApp('settings', 'backup'); }); }]]}),
 gsec: () => ({p:'google', t:L('الأمان','Security'), i:[['nav',L('فحص الأمان','Security checkup'),'','checkup'],['nav','Google Play Protect',yn('protect'),'protect'],['nav','Find My Device',yn('fmd'),'fmd']]}),
 checkup: () => { const r = checkup(), ok = r.filter(x => x[1]).length; return {p:'gsec', t:L('فحص الأمان','Security checkup'), i:[['info',L('النتيجة','Result'),`${ok} / ${r.length}`],...r.map(([n, g]) => ['info',n,g ? L('جيد','Good') : L('يحتاج انتباه','Needs attention')])]}; },
 gsetup: () => ({p:'google', t:L('الإعداد والاستعادة','Set up & restore'), i:[['sw','autorestore',L('الاستعادة التلقائية','Automatic restore'),L('استعادة الإعدادات عند إعادة تثبيت تطبيق','Restore settings when reinstalling an app'),1],['info',L('نسخة الجهاز','This device'),S.devName]]}),
 gdev: () => ({p:'google', t:L('الأجهزة والمشاركة','Devices & sharing'), i:[['sw','nearby','Nearby Share',L('المشاركة مع الأجهزة القريبة','Share with nearby devices'),1],['info',L('اسم الجهاز','Device name'),S.devName]]}),
 wellbeing: () => { U(); const e = Object.entries(S.usage).sort((a, b) => b[1] - a[1]), tot = e.reduce((a, x) => a + x[1], 0); return {p:'main', t:L('الاستخدام الرقمي','Digital Wellbeing'), i:[['info',L('وقت الشاشة اليوم','Screen time today'),Math.round(tot / 60) + ' ' + L('دقيقة','min')],['h',L('التطبيقات','Apps')],...(e.length ? e.map(([id, s]) => ['info',nm(byId(id)),Math.round(s / 60) + ' ' + L('دقيقة','min')]) : [['info',L('لا توجد بيانات بعد','No data yet'),L('افتح بعض التطبيقات','Open some apps')]]),['nav',L('تصفير','Reset'),'',() => { S.usage = {}; save(); openApp('settings','wellbeing'); }]]}; },
 access: () => ({p:'main', t:L('إمكانية الوصول','Accessibility'), i:[sel('fs',L('حجم الخط','Font size'),[[.9,L('صغير','Small')],[1,L('افتراضي','Default')],[1.15,L('كبير','Large')],[1.3,L('الأكبر','Largest')]]),['sw','bold',L('نص عريض','Bold text'),'',0],['sw','bigIcons',L('أيقونات كبيرة','Large icons'),'',0],['sw','inv',L('عكس الألوان','Colour inversion'),'',0],['sw','gray',L('تدرّج الرمادي','Grayscale'),'',0],['sw','noanim',L('إزالة الحركات','Remove animations'),L('يعطّل الانتقالات','Disables transitions'),0]]}),
 system: () => ({p:'main', t:L('النظام','System'), i:[sel('lang',L('اللغات','Languages'),[['ar','العربية'],['en','English']],() => applyLang()),['sw','gesture',L('التنقل بالإيماءات','Gesture navigation'),L('سحب من الحواف والأسفل','Swipe from edges and bottom'),0],['nav',L('التاريخ والوقت','Date & time'),'','datetime'],['nav',L('تحديث النظام','System update'),'','update'],['nav',L('خيارات إعادة الضبط','Reset options'),'','reset'],...(S.dev ? [['nav',L('خيارات المطوّر','Developer options'),'','dev']] : [])]}),
 datetime: () => ({p:'system', t:L('التاريخ والوقت','Date & time'), i:[['sw','h24',L('نظام 24 ساعة','Use 24-hour format'),'',0],sel('tz',L('المنطقة الزمنية','Time zone'),ZONES),['info',L('التاريخ','Date'),new Date().toLocaleDateString(LOC(), {...tzo(), dateStyle: 'full'})],['info',L('الوقت','Time'),fmtT(new Date())]]}),
 update: () => ({p:'system', t:L('تحديث النظام','System update'), i:[['info',L('إصدار Android','Android version'),'9'],['info',L('تحديث الأمان','Security patch'),'2026-11-01'],['info',L('آخر فحص','Last checked'),ago(S.lastUpd)],['nav',L('البحث عن تحديث','Check for update'),'',() => { if (!online()) return toast(L('لا يوجد اتصال بالإنترنت', 'No internet connection')); progress(L('جارٍ البحث عن تحديثات…', 'Checking for updates…'), 2000, () => { S.lastUpd = Date.now(); useData(.3); save(); toast(L('نظامك محدّث', 'Your system is up to date')); openApp('settings', 'update'); }); }]]}),
 reset: () => ({p:'system', t:L('خيارات إعادة الضبط','Reset options'), i:[['nav',L('إعادة ضبط Wi-Fi والبلوتوث','Reset Wi-Fi & Bluetooth'),'',() => confirmDlg(L('إعادة ضبط الشبكة؟','Reset network settings?'),L('سيتم إعادة ضبط Wi-Fi والبلوتوث والبيانات.','Wi-Fi, Bluetooth and data will be reset.'),L('إعادة ضبط','Reset'),() => { Object.assign(S, {wifi:true,seen:false,bt:true,data:true,airplane:false,hotspot:false,vpn:false,btPaired:[]}); save(); refresh(); toast(L('تمت إعادة الضبط', 'Network reset')); })],['nav',L('إعادة ضبط التفضيلات','Reset preferences'),'',() => confirmDlg(L('إعادة ضبط التفضيلات؟','Reset preferences?'),L('لن تُحذف بياناتك.','Your data will not be erased.'),L('إعادة ضبط','Reset'),() => { Object.assign(S, DEF, {done:true,seen:S.seen}); save(); applyLang(); toast(L('تمت إعادة الضبط', 'Preferences reset')); })],['nav',L('إعادة ضبط المصنع','Factory data reset'),L('يمسح كل البيانات','Erases all data'),resetDlg]]}),
 dev: () => ({p:'system', t:L('خيارات المطوّر','Developer options'), i:[['sw','touches',L('إظهار اللمسات','Show touches'),'',0],['sw','stay',L('إبقاء الشاشة مفتوحة','Stay awake'),L('إيقاف القفل التلقائي','Disables auto-lock'),0],['info',L('رقم البناء','Build number'),'ALANZI.1.1.2026'],['nav',L('إيقاف خيارات المطوّر','Turn off developer options'),'',() => { S.dev = false; save(); openApp('settings','system'); }]]}),
 about: () => ({p:'main', t:L('لمحة عن الهاتف','About phone'), i:[['nav',L('اسم الجهاز','Device name'),S.devName,() => askText(L('اسم الجهاز','Device name'),S.devName,v => { S.devName = v; save(); openApp('settings','about'); })],['info',L('الطراز','Model'),'ALANZI A1'],['info',L('إصدار Android','Android version'),'9'],['info',L('تحديث الأمان','Security patch'),'2026-11-01'],['nav',L('رقم البناء','Build number'),'ALANZI.1.1.2026',() => { if (S.dev) return toast(L('أنت مطوّر بالفعل', 'You are already a developer')); buildTaps++; if (buildTaps >= 7) { S.dev = true; save(); buildTaps = 0; toast(L('أصبحت الآن مطوّرًا!', 'You are now a developer!')); } else if (buildTaps >= 3) toast(L(`بقي ${7 - buildTaps} خطوات لتصبح مطوّرًا`, `${7 - buildTaps} steps away from being a developer`)); }],['info',L('إصدار النواة','Kernel version'),'4.14.186-alanzi'],['info','Wi-Fi',S.wifi ? 'ALANZI HOME · ' + L('متصل (محاكاة)','connected (simulated)') : L('متوقف','Off')],['info',L('حجم الشاشة','Screen'),`${innerWidth}×${innerHeight}`],['info',L('الجهاز المستهدف','Target device'),'Samsung Galaxy A16 5G'],['info',L('ساعد في صنع النظام','Built with the help of'),'Claude (Anthropic)']]})
};
const RING = {chime:() => { beep(784, .15, 1, S.volR); setTimeout(() => beep(988, .2, 1, S.volR), 160); }, pulse:() => { beep(500, .1, 1, S.volR); setTimeout(() => beep(500, .1, 1, S.volR), 160); }, bell:() => { beep(1200, .3, 1, S.volR); }};
const CATS = [['network','#2196f3',P.wifi,['الشبكة والإنترنت','Network & internet'],['Wi-Fi، الشبكة المحمولة، نقطة الاتصال','Wi-Fi, mobile, hotspot']],['connected','#3f51b5',P.bt,['الأجهزة المتصلة','Connected devices'],['Bluetooth، NFC، USB','Bluetooth, NFC, USB']],['apps','#e91e63',P.apps,['التطبيقات والإشعارات','Apps & notifications'],['الأذونات، التطبيقات الافتراضية','Permissions, default apps']],['battery','#4caf50',P.batt,['البطارية','Battery'],['توفير الطاقة، النسبة','Saver, percentage']],['display','#ffa726',P.display,['الشاشة','Display'],['الوضع الداكن، الخط، المهلة','Dark mode, font, timeout']],['wallpaper','#d81b60',P.gallery,['الخلفية','Wallpaper'],['اختر خلفية','Pick a wallpaper']],['sound','#9c27b0',P.sound,['الصوت','Sound'],['مستوى الصوت، النغمات','Volume, ringtones']],['storage','#795548',P.storage,['التخزين','Storage'],['السعة والاستخدام','Capacity and usage']],['privacy','#607d8b',P.shield,['الخصوصية','Privacy'],['الأذونات، الإعلانات','Permissions, ads']],['location','#00bcd4',P.pin,['الموقع','Location'],['استخدام الموقع والخدمات','Use location, services']],['security','#00897b',P.lock,['الأمان وشاشة القفل','Security & lock screen'],['PIN، Play Protect','PIN, Play Protect']],['accounts','#1976d2',P.person,['الحسابات','Accounts'],['الحسابات والمزامنة','Accounts and sync']],['google','#ea4335',P.google,['Google','Google'],['الخدمات، النسخ الاحتياطي','Services, backup']],['wellbeing','#26a69a',P.hour,['الاستخدام الرقمي','Digital Wellbeing'],['وقت الشاشة للتطبيقات','App screen time']],['access','#388e3c',P.access,['إمكانية الوصول','Accessibility'],['النص، الألوان، الحركة','Text, colour, motion']],['system','#5c6bc0',P.settings,['النظام','System'],['اللغات، التحديث، إعادة الضبط','Languages, update, reset']],['about','#9fa8da',P.info,['لمحة عن الهاتف','About phone'],['اسم الجهاز، الإصدار','Device name, version']]];
function addAccount() {
  const d = dlg(`<h3>${L('إضافة حساب Google','Add a Google account')}</h3><input class="in" id="an" placeholder="${L('الاسم','Name')}"><input class="in" id="ae" type="email" placeholder="${L('البريد الإلكتروني','Email')}"><p class="muted" style="font-size:12px;margin:4px 0 8px">${L('يُحفظ على هذا الجهاز فقط داخل المحاكي.','Saved only on this device inside the simulator.')}</p><div class="btns"><button class="flat" id="ac">${L('إلغاء','Cancel')}</button><button class="flat" id="ao">${L('إضافة','Add')}</button></div>`);
  $('#ac', d).onclick = closeDlg; $('#ao', d).onclick = () => { const n = $('#an', d).value.trim(), e = $('#ae', d).value.trim(); if (!n || !/^\S+@\S+\.\S+$/.test(e)) return toast(L('أدخل اسمًا وبريدًا صحيحًا', 'Enter a name and a valid email')); S.acct = {name: n, email: e}; save(); closeDlg(); if (appId === 'settings') openApp('settings', sub === 'google' ? 'google' : 'accounts'); };
}
function itemsHTML(items) {
  return '<div class="list">' + items.map((it, i) => {
    const [t, a, b, c, d] = it;
    if (t === 'h') return `<div class="sh">${a}</div>`;
    if (t === 'sw') return `<div class="item" data-i="${i}"><div class="txt"><b>${b}</b><small>${c || ''}</small></div><i class="sw ${(S[a] ?? d) ? 'on' : ''}"></i></div>`;
    if (t === 'rg') return `<div class="item rg"><div class="txt"><b>${b}</b></div><input type="range" min="${a === 'bright' ? 20 : 0}" max="100" value="${S[a]}" data-r="${a}"></div>`;
    if (t === 'sel') { const cur = c.find(o => o[0] === S[a]); return `<div class="item" data-i="${i}"><div class="txt"><b>${b}</b><small>${cur ? cur[1] : ''}</small></div>${ic('M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z', 'i chev')}</div>`; }
    if (t === 'nav') return `<div class="item" data-i="${i}"><div class="txt"><b>${a}</b><small>${b || ''}</small></div>${ic('M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z', 'i chev')}</div>`;
    return `<div class="item"><div class="txt"><b>${a}</b><small>${b}</small></div></div>`;
  }).join('') + '</div>';
}
function bindItems(c, items, again) {
  $$('[data-i]', c).forEach(e => e.onclick = () => { const it = items[+e.dataset.i];
    if (it[0] === 'sw') { if (it[1] === 'hotspot' && !S.hotspot && (!S.data || S.airplane)) return toast(L('فعّل بيانات الجوّال أولًا', 'Turn on mobile data first')); if (['airplane','data','bt','dark','night','saver','dnd','circle','bigIcons','bold','inv','gray','noanim','gesture','vpn','hotspot','h24','pct','labels','showClock','showWx','widgets','cols5','lkDate','lkHint','lkNotif','touches'].includes(it[1])) set(it[1], !(S[it[1]] ?? it[4])); else { S[it[1]] = !(S[it[1]] ?? it[4]); save(); refresh(); } again(); }
    else if (it[0] === 'sel') selDlg(it[2], it[3], S[it[1]], v => { if (it[1] === 'screenLock') return it[4](v); S[it[1]] = v; save(); refresh(); it[4] && it[4](v); again(); });
    else if (it[0] === 'nav') typeof it[3] === 'function' ? it[3]() : openApp('settings', it[3]); });
  $$('[data-r]', c).forEach(e => e.oninput = () => { S[e.dataset.r] = +e.value; save(); refresh(true); });
}
function settingsApp(c, id) {
  id = id || 'main'; sub = id; c.classList.add('flush'); const T = $('#app-title');
  if (id === 'wifi') { T.textContent = 'Wi-Fi'; return renderWifi(c); }
  if (id === 'wallpaper') { T.textContent = L('الخلفية', 'Wallpaper'); c.innerHTML = `<div class="walls">${WALLS.map((w, i) => `<div data-w="${i}" class="${S.wall === i ? 'on' : ''}" style="background-color:${w[0]};background-image:${wallImg(w)}"></div>`).join('')}</div>`;
    return $$('[data-w]', c).forEach(x => x.onclick = () => { S.wall = +x.dataset.w; save(); refresh(); $$('[data-w]', c).forEach(y => y.classList.toggle('on', y === x)); }); }
  if (id !== 'main' && PG[id]) { const draw = () => { const y = c.scrollTop, pg = PG[id](); T.textContent = pg.t; c.innerHTML = itemsHTML(pg.i); bindItems(c, pg.i, draw); c.scrollTop = y; }; return draw(); }
  T.textContent = L('الإعدادات', 'Settings');
  const draw = q => {
    let rows = CATS.filter(x => !q || (L(x[3][0], x[3][1]) + L(x[4][0], x[4][1])).toLowerCase().includes(q)).map(x => `<div class="item" data-c="${x[0]}"><div class="ico" style="background:${grad(x[1])}">${ic(x[2])}</div><div class="txt"><b>${L(x[3][0], x[3][1])}</b><small>${L(x[4][0], x[4][1])}</small></div>${ic('M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z', 'i chev')}</div>`).join('');
    if (q) Object.keys(PG).forEach(pid => { const pg = PG[pid](); pg.i.forEach(it => { const ti = String(['sw', 'rg', 'sel'].includes(it[0]) ? (it[0] === 'sw' || it[0] === 'rg' ? it[2] : it[2]) : it[1]); if (it[0] !== 'h' && ti.toLowerCase().includes(q)) rows += `<div class="item" data-c="${pid}"><div class="txt"><b>${ti}</b><small>${pg.t}</small></div></div>`; }); });
    $('#set-list').innerHTML = rows || `<p class="muted c">${L('لا توجد نتائج', 'No results')}</p>`;
    $$('[data-c]').forEach(e => e.onclick = () => openApp('settings', e.dataset.c)); };
  c.innerHTML = `<div class="field">${ic(P.search)}<input id="set-q" placeholder="${L('ابحث في الإعدادات', 'Search settings')}"></div><div class="list" id="set-list"></div>`;
  $('#set-q').oninput = e => draw(e.target.value.trim().toLowerCase()); draw('');
}
function resetDlg() { confirmDlg(L('إعادة ضبط المصنع؟', 'Factory data reset?'), L('سيتم مسح كل الإعدادات والملاحظات والصور والحساب.', 'All settings, notes, photos and the account will be erased.'), L('مسح كل شيء', 'Erase everything'), () => { localStorage.removeItem('az.state'); localStorage.removeItem('az.photos'); location.reload(); }); }

/* ================= 6. Apps ================= */
const perm = k => S['pm_' + k] !== false;
const pad = n => String(n).padStart(2, '0');
function stopCam() { if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; } }
function endApp() { endUse(); stopCam(); timers.forEach(clearInterval); timers = []; cleanups.forEach(f => f()); cleanups = []; inCall = false; }
function openApp(id, s) {
  closePanels(); closeRecents(); closeDrawer();
  if (id === 'flash') return setTorch(!torch);
  const a = byId(id); if (!a) return;
  endApp(); appId = id; sub = null; useStart = Date.now();
  const ri = RECENT.indexOf(id); if (ri >= 0) RECENT.splice(ri, 1); RECENT.unshift(id); RECENT.splice(6);
  
  const el = $('#app'), c = $('#app-content'); 
  $('#app-title').textContent = nm(a); 
  c.style.padding = ''; c.classList.remove('flush'); c.scrollTop = 0;
  
  c.style.animation = 'none';
  void c.offsetWidth;
  c.style.animation = 'azFadeUp 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both';

  el.style.display = 'flex'; APP_FN[id](c, s); chrome();
  requestAnimationFrame(() => el.classList.add('show'));
}
function closeApp() { endApp(); appId = null; sub = null; $('#app').classList.remove('show'); setTimeout(() => { if (!appId) $('#app').style.display = 'none'; }, 220); chrome(); }
function denied(c, k, label) { c.innerHTML = `<p class="muted c">${L('الإذن مرفوض: ', 'Permission denied: ')}${label}</p><button class="btn" id="al">${L('السماح', 'Allow')}</button>`; $('#al').onclick = () => { S['pm_' + k] = true; save(); openApp(appId); }; }
function shrink(f) { return new Promise(res => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 720 / Math.max(im.width, im.height)), cv = document.createElement('canvas'); cv.width = im.width * k; cv.height = im.height * k; cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); res(cv.toDataURL('image/jpeg', .7)); }; im.src = r.result; }; r.readAsDataURL(f); }); }
const addPhoto = u => { const p = JSON.parse(localStorage.getItem('az.photos') || '[]'); p.push(u); localStorage.setItem('az.photos', JSON.stringify(p)); };

let ringing = false, timerEnd = 0, ctab = 'clock';
function ringAlert(title, body) {
  if (ringing) return; ringing = true; notify(title, body, '#ef6c00', P.clock);
  const iv = setInterval(() => { beep(880, .25, 1, S.volA); if (navigator.vibrate) navigator.vibrate(200); }, 700);
  const d = dlg(`<h3>${title}</h3><p class="muted" style="margin-bottom:14px">${body}</p><div class="btns"><button class="flat" id="rs">${L('غفوة 5 دقائق', 'Snooze 5 min')}</button><button class="flat" id="rd">${L('إيقاف', 'Dismiss')}</button></div>`);
  d.onclick = null; const stop = () => { clearInterval(iv); ringing = false; closeDlg(); };
  $('#rd', d).onclick = stop; $('#rs', d).onclick = () => { stop(); setTimeout(() => ringAlert(title, body), 300000); };
}
setInterval(() => { const n = new Date(), {h, m} = hm(n), k = `${pad(h)}:${pad(m)}`; S.alarms.forEach(a => { if (a.on && a.t === k && a.f !== n.getDate() + k) { a.f = n.getDate() + k; ringAlert(a.l || L('منبّه', 'Alarm'), a.t); } }); if (timerEnd && Date.now() >= timerEnd) { timerEnd = 0; ringAlert(L('انتهى المؤقت', 'Timer finished'), ''); } }, 1000);

const keys = (list, cls) => `<div class="keys ${cls}">${list.map(k => `<div class="key ${'÷×−+='.includes(k) ? 'op' : ['AC', '⌫', '%'].includes(k) ? 'fn' : ''}" data-k="${k}">${k}</div>`).join('')}</div>`;
let calcE = '', dial = '';
const LETTERS = {2:'ABC',3:'DEF',4:'GHI',5:'JKL',6:'MNO',7:'PQRS',8:'TUV',9:'WXYZ',0:'+'};
const UN = {len:[['m',1],['km',1000],['cm',.01],['mm',.001],['mi',1609.344],['ft',.3048],['in',.0254]],wt:[['kg',1],['g',.001],['lb',.45359237],['oz',.028349523]],vol:[['L',1],['mL',.001],['gal',3.785411784],['cup',.2365882365]],spd:[['m/s',1],['km/h',1 / 3.6],['mph',.44704]],tmp:[['°C'],['°F'],['K']]};
const COLS = ['#212121', '#e53935', '#fb8c00', '#43a047', '#1e88e5', '#8e24aa'];

function startCall(c) {
  inCall = true;
  c.innerHTML = `<div class="c"><div class="big" style="font-size:34px">${esc(dial)}</div><p class="muted">${L('جارٍ الاتصال…', 'Calling…')}</p><div class="spin"></div><button class="btn red" id="ec">${L('إنهاء', 'End')}</button></div>`;
  $('#ec').onclick = endCall;
}
function endCall() { inCall = false; dial = ''; if (appId === 'phone') openApp('phone'); }

const APP_FN = {
 settings: settingsApp,
 store(c) {
   if (!online()) { c.innerHTML = `<p class="muted c">${L('لا يوجد اتصال. فعّل Wi-Fi أو البيانات.', 'No connection. Turn on Wi-Fi or mobile data.')}</p><button class="btn" id="gw">${L('فتح Wi-Fi', 'Open Wi-Fi')}</button>`; $('#gw').onclick = () => openApp('settings', 'wifi'); return; }
   let q = '';
   const draw = () => { const list = EXTRA.filter(a => (a.ar + a.en).toLowerCase().includes(q));
     c.innerHTML = `<div class="field" style="margin:0 0 10px"><svg class="i" viewBox="0 0 24 24"><path d="${P.search}"/></svg><input id="sq" value="${esc(q)}" placeholder="${L('ابحث في المتجر', 'Search the store')}"></div><div class="sh" style="background:transparent;padding-inline:2px">${L('تطبيقات مقترحة', 'Suggested apps')}</div>` + list.map(a => { const on = S.inst.includes(a.id); return `<div class="store-i"><div class="bx" style="background:${grad(a.c)}">${aic(a)}</div><div class="txt"><b>${nm(a)}</b><small>${L(a.da, a.de)}</small></div>${on ? `<button class="pillb" data-o="${a.id}">${L('فتح', 'Open')}</button><button class="flat" data-i="${a.id}">${L('إزالة', 'Remove')}</button>` : `<button class="pillb" data-i="${a.id}">${L('تثبيت', 'Install')}</button>`}</div>`; }).join('');
     const sq = $('#sq'); sq.oninput = e => { q = e.target.value.trim().toLowerCase(); const p = sq.selectionStart; draw(); const n = $('#sq'); n.focus(); n.setSelectionRange(p, p); };
     $$('[data-o]', c).forEach(b => b.onclick = () => openApp(b.dataset.o));
     $$('[data-i]', c).forEach(b => b.onclick = async () => { const id = b.dataset.i;
       if (S.inst.includes(id)) S.inst = S.inst.filter(x => x !== id);
       else { b.outerHTML = '<div class="prog"><i></i></div>'; await wait(1500); if (!online()) return APP_FN.store(c); S.inst.push(id); useData(5); notify(nm(byId(id)), L('تم التثبيت', 'Installed'), byId(id).c, byId(id).ic); beep(880, .12, 1); }
       save(); renderIcons(); if (appId === 'store') draw(); }); };
   draw();
 },
 clock(c) {
   const draw = () => {
     const tabs = `<div class="tabs">${[['alarm', L('المنبّه', 'Alarm')], ['clock', L('الساعة', 'Clock')], ['timer', L('المؤقت', 'Timer')], ['sw', L('ساعة الإيقاف', 'Stopwatch')]].map(([k, l]) => `<button data-t="${k}" class="${ctab === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
     timers.forEach(clearInterval); timers = [];
     if (ctab === 'alarm') {
       c.innerHTML = tabs + (S.alarms.length ? S.alarms.map((a, i) => `<div class="card" style="display:flex;align-items:center;gap:12px"><div class="txt"><b style="font-size:30px;font-weight:300;direction:ltr;display:block">${a.t}</b><small class="muted">${esc(a.l || L('منبّه', 'Alarm'))}</small></div><i class="sw ${a.on ? 'on' : ''}" data-a="${i}"></i><button data-x="${i}" class="flat">${ic(P.close)}</button></div>`).join('') : `<p class="muted c">${L('لا توجد منبّهات', 'No alarms')}</p>`) + `<button class="fab" id="aa">+</button>`;
       $$('[data-a]', c).forEach(e => e.onclick = () => { S.alarms[+e.dataset.a].on = !S.alarms[+e.dataset.a].on; save(); draw(); });
       $$('[data-x]', c).forEach(e => e.onclick = () => { S.alarms.splice(+e.dataset.x, 1); save(); draw(); });
       $('#aa').onclick = () => { const d = dlg(`<h3>${L('منبّه جديد', 'New alarm')}</h3><input class="in" id="at" type="time" value="07:00"><input class="in" id="al2" placeholder="${L('التسمية (اختياري)', 'Label (optional)')}"><div class="btns"><button class="flat" id="ac">${L('إلغاء', 'Cancel')}</button><button class="flat" id="ao">${L('حفظ', 'Save')}</button></div>`);
         $('#ac', d).onclick = closeDlg; $('#ao', d).onclick = () => { const t = $('#at', d).value; if (!t) return; S.alarms.push({t, l: $('#al2', d).value.trim(), on: true}); save(); closeDlg(); draw(); toast(L('تم ضبط المنبّه', 'Alarm set')); }; };
     } else if (ctab === 'clock') {
       const ticks = Array.from({length: 12}, (_, i) => `<line class="tk" x1="100" y1="12" x2="100" y2="${i % 3 ? 20 : 26}" transform="rotate(${i * 30} 100 100)"/>`).join('');
       c.innerHTML = tabs + `<svg viewBox="0 0 200 200" class="analog"><circle class="face" cx="100" cy="100" r="92"/>${ticks}<line class="hh" id="hh" x1="100" y1="100" x2="100" y2="55"/><line class="mh" id="mh" x1="100" y1="100" x2="100" y2="35"/><line class="sh2" id="sh" x1="100" y1="112" x2="100" y2="28"/><circle cx="100" cy="100" r="5" fill="var(--p)"/></svg><div class="big" id="ct" style="margin:6px 0"></div><div class="center muted" id="cd"></div>`;
       const up = () => { const d = new Date(), {h, m} = hm(d), s = d.getSeconds(), mm = m + s / 60, hh = (h % 12) + mm / 60;
         $('#hh').setAttribute('transform', `rotate(${hh * 30} 100 100)`); $('#mh').setAttribute('transform', `rotate(${mm * 6} 100 100)`); $('#sh').setAttribute('transform', `rotate(${s * 6} 100 100)`);
         $('#ct').textContent = fmtT(d) + ':' + pad(s); $('#cd').textContent = d.toLocaleDateString(LOC(), {...tzo(), weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'}); };
       up(); timers.push(setInterval(up, 1000));
     } else if (ctab === 'timer') {
       const run = timerEnd > Date.now();
       c.innerHTML = tabs + (run ? `<div class="big" id="tl"></div><button class="btn red" id="tc">${L('إلغاء', 'Cancel')}</button>` : `<div style="display:flex;gap:10px;margin:20px 0;direction:ltr"><input class="ti" id="tm" type="number" min="0" max="99" value="5" style="text-align:center;font-size:30px"><input class="ti" id="ts" type="number" min="0" max="59" value="0" style="text-align:center;font-size:30px"></div><p class="center muted" style="margin-bottom:14px">${L('دقائق : ثوانٍ', 'minutes : seconds')}</p><button class="btn" id="tg">${L('ابدأ', 'Start')}</button>`);
       if (run) { const up = () => { const r = Math.max(0, Math.ceil((timerEnd - Date.now()) / 1000)); const e = $('#tl'); if (e) e.textContent = pad(Math.floor(r / 60)) + ':' + pad(r % 60); if (!r) draw(); }; up(); timers.push(setInterval(up, 250)); $('#tc').onclick = () => { timerEnd = 0; draw(); }; }
       else $('#tg').onclick = () => { const t = (+$('#tm').value || 0) * 60 + (+$('#ts').value || 0); if (!t) return toast(L('أدخل مدة', 'Enter a duration')); timerEnd = Date.now() + t * 1000; draw(); };
     } else {
       c.innerHTML = tabs + `<div class="big" id="sw" style="margin:36px 0">00:00.00</div><div class="rbtns"><button class="rb gray" id="sr">${L('تصفير', 'Reset')}</button><button class="rb" id="ss">${L('بدء', 'Start')}</button></div>`;
       let run = 0, acc = 0, st = 0;
       timers.push(setInterval(() => { const ms = acc + (run ? Date.now() - st : 0); $('#sw').textContent = `${pad(Math.floor(ms / 60000))}:${pad(Math.floor(ms / 1000) % 60)}.${pad(Math.floor(ms % 1000 / 10))}`; }, 40));
       $('#ss').onclick = () => { if (run) { acc += Date.now() - st; run = 0; $('#ss').textContent = L('متابعة', 'Resume'); } else { st = Date.now(); run = 1; $('#ss').textContent = L('إيقاف', 'Stop'); } };
       $('#sr').onclick = () => { run = 0; acc = 0; $('#ss').textContent = L('بدء', 'Start'); };
     }
     $$('[data-t]', c).forEach(b => b.onclick = () => { ctab = b.dataset.t; draw(); });
   };
   draw();
 },
 calc(c) {
   c.innerHTML = `<div class="disp" id="ds">${calcE || '0'}</div>` + keys(['AC','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','00','0','.','='], 'k4');
   $$('.key', c).forEach(b => b.onclick = () => { const k = b.dataset.k; beep(600 + Math.random() * 100);
     if (k === 'AC') calcE = ''; else if (k === '⌫') calcE = calcE.slice(0, -1);
     else if (k === '=') { try { const x = calcE.replace(/÷/g, '/').replace(/×/g, '*').replace(/−/g, '-').replace(/%/g, '/100'); calcE = /^[0-9+\-*/.() ]+$/.test(x) && x ? String(+Function('return ' + x)().toFixed(8)) : ''; } catch (e) { calcE = ''; toast(L('خطأ', 'Error')); } }
     else calcE += k; $('#ds').textContent = calcE || '0'; });
 },
 notes(c) {
   const list = () => { c.innerHTML = (S.notes.length ? S.notes.map((n, i) => `<div class="nc" data-n="${i}"><b>${esc(n.t) || L('بدون عنوان', 'Untitled')}</b><small>${esc((n.b || '').slice(0, 90))}</small></div>`).join('') : `<p class="muted c">${L('لا توجد ملاحظات', 'No notes')}</p>`) + `<button class="fab" id="nn">+</button>`;
     $('#nn').onclick = () => edit(-1); $$('[data-n]', c).forEach(e => e.onclick = () => edit(+e.dataset.n)); };
   const edit = i => { const n = S.notes[i] || {t: '', b: ''};
     c.innerHTML = `<input class="ti" id="nt" placeholder="${L('العنوان', 'Title')}" value="${esc(n.t)}"><textarea class="ta" id="nb" placeholder="${L('اكتب هنا…', 'Write here…')}">${esc(n.b)}</textarea><div style="display:flex;gap:10px"><button class="btn" id="sv" style="flex:1">${L('حفظ', 'Save')}</button>${i >= 0 ? `<button class="btn red" id="dl" style="flex:1">${L('حذف', 'Delete')}</button>` : ''}</div>`;
     $('#sv').onclick = () => { const o = {t: $('#nt').value.trim(), b: $('#nb').value.trim()}; if (!o.t && !o.b) return toast(L('الملاحظة فارغة', 'Note is empty')); if (i >= 0) S.notes[i] = o; else S.notes.unshift(o); save(); list(); };
     if (i >= 0) $('#dl').onclick = () => { S.notes.splice(i, 1); save(); list(); }; };
   list();
 },
 phone(c) {
   if (!perm('phone')) return denied(c, 'phone', L('الهاتف', 'Phone'));
   const key = k => `<div class="key dg" data-k="${k}">${k}<small>${LETTERS[k] || '&nbsp;'}</small></div>`;
   c.innerHTML = `<div class="big" id="dn" style="font-size:38px;min-height:64px">${dial}</div><div class="keys k3 free">${['1','2','3','4','5','6','7','8','9','*','0','#'].map(key).join('')}</div><div style="display:flex;justify-content:center;gap:34px;margin-top:20px;direction:ltr"><div class="key" id="dd" style="width:64px;color:var(--mut);border-radius:20px;background:transparent">⌫</div><div class="key" id="dc" style="width:64px;background:#1faa59;color:#fff;border-radius:20px">${ic(P.phone)}</div></div>`;
   $$('.key[data-k]', c).forEach(b => b.onclick = () => { dial += b.dataset.k; beep(700 + b.dataset.k.charCodeAt(0) * 3); $('#dn').textContent = dial; });
   $('#dd').onclick = () => { dial = dial.slice(0, -1); $('#dn').textContent = dial; };
   $('#dc').onclick = () => { if (!dial) return toast(L('أدخل رقمًا', 'Enter a number')); if (S.airplane) return toast(L('وضع الطائرة مفعّل', 'Airplane mode is on')); startCall(c); };
 },
 camera(c) {
   if (!perm('camera')) return denied(c, 'camera', L('الكاميرا', 'Camera'));
   c.style.padding = '0'; let face = 'environment';
   c.innerHTML = `<div class="cam" id="cam"><video id="cv" autoplay playsinline muted></video><div class="cam-bar"><button class="cb" id="cf">${ic(P.reload)}</button><button class="shut" id="cs"></button><span class="cb" style="background:none"></span></div></div>`;
   const start = async () => { stopCam(); try { camStream = await navigator.mediaDevices.getUserMedia({video: {facingMode: face}, audio: false}); $('#cv').srcObject = camStream; }
     catch (e) { c.style.padding = ''; c.innerHTML = `<p class="muted c">${L('تعذّر تشغيل الكاميرا', 'Could not start the camera')}<br><small>${esc(e.message)}</small><br><small>${L('افتح الصفحة عبر HTTPS أو localhost وامنح الإذن', 'Open the page over HTTPS or localhost and allow access')}</small></p>`; } };
   $('#cf').onclick = () => { face = face === 'environment' ? 'user' : 'environment'; start(); };
   $('#cs').onclick = () => { const v = $('#cv'); if (!v.videoWidth) return toast(L('الكاميرا غير جاهزة', 'Camera not ready'));
     if (!perm('storage')) return toast(L('إذن التخزين مرفوض', 'Storage permission denied'));
     const k = Math.min(1, 720 / Math.max(v.videoWidth, v.videoHeight)), cv = document.createElement('canvas'); cv.width = v.videoWidth * k; cv.height = v.videoHeight * k; cv.getContext('2d').drawImage(v, 0, 0, cv.width, cv.height);
     try { addPhoto(cv.toDataURL('image/jpeg', .7)); toast(L('تم حفظ الصورة في المعرض', 'Photo saved to Gallery')); beep(1000, .08, 1); } catch (x) { toast(L('الذاكرة ممتلئة', 'Storage full')); }
     $('#cam').classList.add('shot'); setTimeout(() => $('#cam').classList.remove('shot'), 150); };
   start();
 },
 gallery(c) {
   if (!perm('storage')) return denied(c, 'storage', L('التخزين', 'Storage'));
   const ph = () => JSON.parse(localStorage.getItem('az.photos') || '[]');
   const draw = () => { const p = ph(); c.innerHTML = `<input type="file" id="gf" accept="image/*" multiple hidden>` + (p.length ? `<div class="gal">${p.map((u, i) => `<div data-p="${i}"><img src="${u}"></div>`).join('')}</div><button class="btn red" id="gc" style="margin-top:14px">${L('حذف كل الصور', 'Delete all')}</button>` : `<p class="muted c">${L('لا توجد صور. اضغط + لرفع صور من جهازك.', 'No photos. Tap + to upload from your device.')}</p>`) + `<button class="fab" id="gu">+</button>`;
     $('#gu').onclick = () => $('#gf').click(); if (p.length) $('#gc').onclick = () => { localStorage.removeItem('az.photos'); draw(); };
     $$('[data-p]', c).forEach(e => e.onclick = () => { c.innerHTML = `<img src="${ph()[+e.dataset.p]}" style="width:100%;border-radius:14px"><button class="btn gray" id="gb" style="margin-top:14px">${L('رجوع', 'Back')}</button>`; $('#gb').onclick = draw; });
     $('#gf').onchange = async e => { for (const f of e.target.files) { try { addPhoto(await shrink(f)); } catch (x) { toast(L('الذاكرة ممتلئة', 'Storage full')); break; } } draw(); }; };
   draw();
 },
 browser(c) {
   c.style.padding = '0';
   const HOME = 'https://www.google.com';
   c.innerHTML = `<div class="br">
     <div class="br-bar" style="direction:ltr"><div class="br-url"><input id="bu" value="${HOME}" readonly style="direction:ltr"></div></div>
     <div class="br-page" id="bp" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:30px;text-align:center">
       <div class="g-logo" style="font-size:52px;margin:0">Google</div>
       <p class="muted">${L('سيتم فتح Google الرسمي في تبويب جديد.', 'The official Google will open in a new tab.')}</p>
       <button class="btn" id="go" style="max-width:280px">${L('افتح Google', 'Open Google')}</button>
     </div></div>`;
   const go = () => { try { window.open(HOME, '_blank', 'noopener'); } catch (e) { toast(L('تعذّر الفتح', 'Could not open')); } };
   $('#go', c).onclick = go;
   try { const w = window.open(HOME, '_blank', 'noopener'); if (!w) toast(L('اضغط زر فتح Google', 'Tap the Open Google button')); } catch (e) {}
 },
 calendar(c) {
   let d = new Date(); d.setDate(1); const key = (y, m, k) => `${y}-${m + 1}-${k}`;
   const draw = () => { const y = d.getFullYear(), m = d.getMonth(), st = S.lang === 'ar' ? 6 : 0, first = (new Date(y, m, 1).getDay() - st + 7) % 7, dim = new Date(y, m + 1, 0).getDate(), td = new Date();
     let cells = Array.from({length: 7}, (_, k) => `<div class="dn">${new Date(2023, 0, 1 + ((st + k) % 7)).toLocaleDateString(LOC(), {weekday: 'narrow'})}</div>`).join('') + '<div></div>'.repeat(first);
     for (let k = 1; k <= dim; k++) { const isT = td.getFullYear() === y && td.getMonth() === m && td.getDate() === k; cells += `<div class="d ${isT ? 't' : ''} ${(S.events[key(y, m, k)] || []).length ? 'e' : ''}" data-d="${k}">${k}</div>`; }
     c.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px"><button class="flat" id="pm" style="font-size:24px">${S.lang === 'ar' ? '›' : '‹'}</button><b style="font-size:18px">${d.toLocaleDateString(LOC(), {month: 'long', year: 'numeric'})}</b><button class="flat" id="nx" style="font-size:24px">${S.lang === 'ar' ? '‹' : '›'}</button></div><div class="cal">${cells}</div>`;
     $('#pm').onclick = () => { d.setMonth(m - 1); draw(); }; $('#nx').onclick = () => { d.setMonth(m + 1); draw(); };
     $$('[data-d]', c).forEach(e => e.onclick = () => { const k = key(y, m, +e.dataset.d), ev = S.events[k] || [];
       const dl = dlg(`<h3>${e.dataset.d}/${m + 1}/${y}</h3>${ev.map((t, i) => `<div class="opt"><span>${esc(t)}</span><button class="flat" data-r="${i}">${ic(P.close)}</button></div>`).join('') || `<p class="muted" style="margin-bottom:10px">${L('لا توجد أحداث', 'No events')}</p>`}<input class="in" id="ev" placeholder="${L('أضف حدثًا', 'Add an event')}"><div class="btns"><button class="flat" id="ec">${L('إغلاق', 'Close')}</button><button class="flat" id="ea">${L('إضافة', 'Add')}</button></div>`);
       $('#ec', dl).onclick = closeDlg; $('#ea', dl).onclick = () => { const v = $('#ev', dl).value.trim(); if (v) { S.events[k] = [...ev, v]; save(); } closeDlg(); draw(); };
       $$('[data-r]', dl).forEach(b => b.onclick = () => { S.events[k] = ev.filter((_, i) => i !== +b.dataset.r); if (!S.events[k].length) delete S.events[k]; save(); closeDlg(); draw(); }); }); };
   draw();
 },
 todo(c) {
   const draw = () => { const left = S.todos.filter(t => !t.d).length;
     c.innerHTML = `<div style="display:flex;gap:8px;margin-bottom:10px"><input class="ti" id="tt" placeholder="${L('مهمة جديدة', 'New task')}" style="margin:0"><button class="pillb" id="ta">${L('إضافة', 'Add')}</button></div><p class="muted" style="margin-bottom:6px">${left} ${L('متبقية', 'remaining')}</p>` + (S.todos.map((t, i) => `<div class="chk-i ${t.d ? 'done' : ''}"><div class="cbx ${t.d ? 'on' : ''}" data-c="${i}">${ic(P.check)}</div><div class="t">${esc(t.t)}</div><button class="flat" data-x="${i}">${ic(P.close)}</button></div>`).join('') || `<p class="muted c">${L('لا توجد مهام', 'No tasks')}</p>`);
     const add = () => { const v = $('#tt').value.trim(); if (!v) return; S.todos.unshift({t: v, d: 0}); save(); draw(); };
     $('#ta').onclick = add; $('#tt').onkeydown = e => { if (e.key === 'Enter') add(); };
     $$('[data-c]', c).forEach(e => e.onclick = () => { S.todos[+e.dataset.c].d ^= 1; save(); draw(); }); $$('[data-x]', c).forEach(e => e.onclick = () => { S.todos.splice(+e.dataset.x, 1); save(); draw(); }); };
   draw();
 },
 convert(c) {
   let cat = 'len', f = 0, t = 1;
   const conv = (v, a, b) => { if (cat === 'tmp') { const k = a === 0 ? v + 273.15 : a === 1 ? (v - 32) * 5 / 9 + 273.15 : v; return b === 0 ? k - 273.15 : b === 1 ? (k - 273.15) * 9 / 5 + 32 : k; } return v * UN[cat][a][1] / UN[cat][b][1]; };
   const draw = () => { const u = UN[cat], names = {len: L('الطول', 'Length'), wt: L('الوزن', 'Weight'), vol: L('الحجم', 'Volume'), spd: L('السرعة', 'Speed'), tmp: L('الحرارة', 'Temperature')};
     c.innerHTML = `<div class="seg" style="margin-bottom:14px">${Object.keys(UN).map(k => `<button data-k="${k}" class="${cat === k ? 'on' : ''}">${names[k]}</button>`).join('')}</div><input class="ti" id="cv" type="number" value="1" style="font-size:28px"><select class="ti" id="cf">${u.map((x, i) => `<option value="${i}" ${i === f ? 'selected' : ''}>${x[0]}</option>`).join('')}</select><select class="ti" id="ct">${u.map((x, i) => `<option value="${i}" ${i === t ? 'selected' : ''}>${x[0]}</option>`).join('')}</select><div class="card center"><div class="muted">${L('النتيجة', 'Result')}</div><div class="big" id="cr" style="font-size:38px"></div></div>`;
     const up = () => { f = +$('#cf').value; t = +$('#ct').value; const r = conv(+$('#cv').value || 0, f, t); $('#cr').textContent = (Math.round(r * 1e6) / 1e6).toLocaleString('en-US', {maximumFractionDigits: 6}) + ' ' + u[t][0]; };
     $('#cv').oninput = up; $('#cf').onchange = up; $('#ct').onchange = up; up();
     $$('[data-k]', c).forEach(b => b.onclick = () => { cat = b.dataset.k; f = 0; t = 1; draw(); }); };
   draw();
 },
 weather(c) {
   if (!online()) { c.innerHTML = `<p class="muted c">${L('لا يوجد اتصال. فعّل Wi-Fi أو البيانات.', 'No connection. Turn on Wi-Fi or mobile data.')}</p>`; return; }
   if (!(S.loc && perm('loc'))) { c.innerHTML = `<p class="muted c">${L('الموقع متوقف أو الإذن مرفوض.', 'Location is off or permission is denied.')}</p><button class="btn" id="lo">${L('تفعيل الموقع', 'Turn on location')}</button>`; $('#lo').onclick = () => { S.loc = true; S.pm_loc = true; save(); openApp('weather'); }; return; }
   useData(.2); const D = [[30,19,L('مشمس','Sunny')],[31,20,L('مشمس','Sunny')],[29,19,L('غائم جزئيًا','Partly cloudy')],[28,18,L('غائم جزئيًا','Partly cloudy')],[30,19,L('مشمس','Sunny')]];
   c.innerHTML = `<div class="wx-big"><div class="muted">${L('الرياض', 'Riyadh')}</div><b>28°</b><div>${L('مشمس', 'Sunny')}</div><div class="muted">${L('العليا 30° · الدنيا 19°', 'H 30° · L 19°')}</div></div><div class="card"><div class="opt"><span>${L('الرطوبة', 'Humidity')}</span><b>18%</b></div><div class="opt"><span>${L('الرياح', 'Wind')}</span><b>12 km/h</b></div></div><div class="card">${D.map((x, i) => `<div class="opt"><span style="width:90px">${new Date(Date.now() + i * 864e5).toLocaleDateString(LOC(), {weekday: 'long'})}</span><span class="muted" style="flex:1;text-align:center">${x[2]}</span><b>${x[0]}° / ${x[1]}°</b></div>`).join('')}</div><p class="muted center" style="font-size:12px">${L('بيانات تجريبية', 'Demo data')}</p>`;
 },
 compass(c) {
   c.innerHTML = `<div class="comp"><div class="dial" id="dial"><b class="n">N</b><b class="s">S</b><b class="e">E</b><b class="w2">W</b></div><div class="big" id="hd">--</div><p class="muted c" id="cm">${L('حرّك الجهاز لقياس الاتجاه', 'Move the device to read the heading')}</p></div>`;
   let got = false; const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
   const h = e => { let a = e.webkitCompassHeading ?? (e.alpha != null ? 360 - e.alpha : null); if (a == null) return; got = true; $('#dial').style.transform = `rotate(${-a}deg)`; $('#hd').textContent = Math.round(a) + '° ' + dirs[Math.round(a / 45) % 8]; $('#cm').textContent = ''; };
   const start = () => { window.addEventListener('deviceorientationabsolute', h, true); window.addEventListener('deviceorientation', h, true); };
   cleanups.push(() => { window.removeEventListener('deviceorientationabsolute', h, true); window.removeEventListener('deviceorientation', h, true); });
   if (window.DeviceOrientationEvent && DeviceOrientationEvent.requestPermission) { $('#cm').innerHTML = `<button class="btn" id="cp">${L('السماح بالوصول للحسّاس', 'Allow sensor access')}</button>`; $('#cp').onclick = async () => { try { if ((await DeviceOrientationEvent.requestPermission()) === 'granted') start(); } catch (e) {} }; }
   else start();
   setTimeout(() => { if (!got && $('#cm')) $('#cm').textContent = L('الحسّاس غير متاح على هذا الجهاز أو المتصفح', 'Sensor unavailable on this device or browser'); }, 2500);
 },
 draw(c) {
   let col = COLS[0], drawing = false, last = null;
   c.innerHTML = `<canvas class="cvs" id="cvs" width="600" height="600"></canvas><div class="cols" id="cols">${COLS.map((x, i) => `<i data-c="${x}" style="background:${x}" class="${i === 0 ? 'on' : ''}"></i>`).join('')}</div><div style="display:flex;gap:10px"><button class="btn gray" id="clr" style="flex:1">${L('مسح', 'Clear')}</button><button class="btn" id="sav" style="flex:1">${L('حفظ', 'Save')}</button></div>`;
   const cv = $('#cvs', c), g = cv.getContext('2d');
   g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height);
   g.lineCap = 'round'; g.lineJoin = 'round';
   const pos = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height }; };
   cv.addEventListener('pointerdown', e => { drawing = true; last = pos(e); cv.setPointerCapture(e.pointerId); });
   cv.addEventListener('pointermove', e => { if (!drawing) return; const p = pos(e); g.strokeStyle = col; g.lineWidth = 10; g.beginPath(); g.moveTo(last.x, last.y); g.lineTo(p.x, p.y); g.stroke(); last = p; });
   cv.addEventListener('pointerup', () => { drawing = false; });
   $$('[data-c]', c).forEach(e => e.onclick = () => { col = e.dataset.c; $$('[data-c]', c).forEach(x => x.classList.toggle('on', x === e)); });
   $('#clr', c).onclick = () => { g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height); };
   $('#sav', c).onclick = () => { if (!perm('storage')) return toast(L('إذن التخزين مرفوض', 'Storage permission denied')); try { addPhoto(cv.toDataURL('image/jpeg', .8)); toast(L('تم الحفظ في المعرض', 'Saved to Gallery')); } catch (x) { toast(L('الذاكرة ممتلئة', 'Storage full')); } };
 },
 tasbih(c) {
   const draw = () => {
     c.innerHTML = `<div class="cnt" id="cnt"><b>${S.cnt}</b><small>${L('من', 'of')} ${S.tgt}</small></div><div style="display:flex;gap:10px;margin-top:20px"><button class="btn gray" id="rs" style="flex:1">${L('تصفير', 'Reset')}</button><button class="btn" id="tg" style="flex:1">${L('الهدف', 'Target')}</button></div>`;
     $('#cnt').onclick = () => { S.cnt++; if (S.cnt >= S.tgt) { S.cnt = 0; beep(880, .2, 1, S.volA); toast(L('اكتمل الهدف', 'Target reached')); } else beep(700, .04); save(); draw(); };
     $('#rs').onclick = () => { S.cnt = 0; save(); draw(); };
     $('#tg').onclick = () => askText(L('الهدف', 'Target'), String(S.tgt), v => { S.tgt = Math.max(1, +v || 33); save(); draw(); });
   };
   draw();
 },
 passgen(c) {
   let len = 16, up = true, num = true, sym = true;
   const gen = () => { const L1 = 'abcdefghijklmnopqrstuvwxyz', U1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', N1 = '0123456789', S1 = '!@#$%^&*()-_=+[]{}'; let set = L1; if (up) set += U1; if (num) set += N1; if (sym) set += S1; let out = ''; const a = new Uint32Array(len); crypto.getRandomValues(a); for (let i = 0; i < len; i++) out += set[a[i] % set.length]; return out; };
   let pw = gen();
   const draw = () => {
     c.innerHTML = `<div class="pwout" id="pw">${esc(pw)}</div><div class="card"><div class="opt"><span>${L('الطول', 'Length')}</span><b>${len}</b></div><input type="range" min="6" max="40" value="${len}" id="ln"></div><div class="card"><div class="opt"><span>${L('حروف كبيرة', 'Uppercase')}</span><i class="sw ${up ? 'on' : ''}" id="o1"></i></div><div class="opt"><span>${L('أرقام', 'Numbers')}</span><i class="sw ${num ? 'on' : ''}" id="o2"></i></div><div class="opt"><span>${L('رموز', 'Symbols')}</span><i class="sw ${sym ? 'on' : ''}" id="o3"></i></div></div><button class="btn" id="rg">${L('توليد جديد', 'Generate new')}</button>`;
     $('#ln').oninput = e => { len = +e.target.value; pw = gen(); draw(); };
     $('#o1').onclick = () => { up = !up; pw = gen(); draw(); };
     $('#o2').onclick = () => { num = !num; pw = gen(); draw(); };
     $('#o3').onclick = () => { sym = !sym; pw = gen(); draw(); };
     $('#rg').onclick = () => { pw = gen(); draw(); };
     $('#pw').onclick = async () => { try { await navigator.clipboard.writeText(pw); toast(L('تم النسخ', 'Copied')); } catch (e) { toast(L('تعذّر النسخ', 'Copy failed')); } };
   };
   draw();
 }
};

/* ================= 7. Gestures (improved control) ================= */
document.addEventListener('contextmenu', e => e.preventDefault());

function swipe(el, onSwipe, opts = {}) {
  const ignore = opts.ignore || '__none__';
  let start = null;
  el.addEventListener('pointerdown', e => {
    if (e.target.closest(ignore)) return;
    start = { x: e.clientX, y: e.clientY, t: Date.now(), scroll: el.scrollTop };
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
  }, { passive: true });
  const finish = e => {
    if (!start) return;
    const s = start; start = null;
    if (Date.now() - s.t > 900) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (Math.abs(dx) >= (opts.minH || 60)) onSwipe(dx > 0 ? 'right' : 'left', Math.abs(dx), s, e);
    } else if (Math.abs(dy) >= (opts.minV || 50)) {
      onSwipe(dy > 0 ? 'down' : 'up', Math.abs(dy), s, e);
    }
  };
  el.addEventListener('pointerup', finish, { passive: true });
  el.addEventListener('pointercancel', () => { start = null; }, { passive: true });
}

swipe($('#lock'), (dir, dist) => { if (dir === 'up' && dist > 40) tryUnlock(); }, { ignore: 'button,input', minV: 40 });

(() => {
  const sb = $('#status'); let lastTap = 0;
  swipe(sb, (dir, dist) => { if (dir === 'down' && dist > 15) openPanel('notif'); }, { ignore: '__none__', minV: 15 });
  sb.addEventListener('click', e => {
    if (e.target.closest('button')) return;
    const now = Date.now();
    if (now - lastTap < 300) { lastTap = 0; openPanel('cc'); } else lastTap = now;
  });
})();

swipe($('#home'), (dir, dist) => { if (dir === 'up' && dist > 55) openDrawer(); }, { ignore: '.app-i,.w,#pill,#trig', minV: 50 });

swipe($('#drawer'), (dir, dist) => { if (dir === 'down' && dist > 70) closeDrawer(); }, { ignore: 'input,.app-i,.app-grid', minV: 60 });
$('#drawer').addEventListener('click', e => { if (e.target.id === 'drawer') closeDrawer(); });

$$('.panel').forEach(p => {
  swipe(p, (dir, dist, s) => {
    if (s.scroll > 0) return;
    if (dir === 'up' && dist > 50) closePanels();
    if (dir === 'down' && dist > 100) closePanels();
  }, { ignore: 'input,.tile,.n,button,.sl', minV: 45 });
});

(() => {
  const W = $('#phone'); let edge = null;
  W.addEventListener('pointerdown', e => {
    if (lockOn || drawerOpen || panel || recentsOpen) return;
    const r = W.getBoundingClientRect(), zone = 22;
    if (e.clientX - r.left < zone || r.right - e.clientX < zone) edge = { x: e.clientX, y: e.clientY };
  }, { passive: true });
  W.addEventListener('pointerup', e => {
    if (!edge) return;
    const dx = e.clientX - edge.x, dy = e.clientY - edge.y; edge = null;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy)) back();
  }, { passive: true });
  W.addEventListener('pointercancel', () => { edge = null; }, { passive: true });
})();

['#n-home', '#n-rec', '#n-back', '#app-back'].forEach(sel => {
  const el = $(sel); if (!el) return;
  let pressed = false;
  el.addEventListener('pointerdown', () => {
    pressed = true;
    el.style.transition = 'transform .08s, opacity .08s';
    el.style.transform = 'scale(.85)'; el.style.opacity = '0.6';
  }, { passive: true });
  const up = () => { if (!pressed) return; pressed = false; el.style.transform = ''; el.style.opacity = ''; };
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => el.addEventListener(ev, up, { passive: true }));
});

document.addEventListener('pointerdown', e => {
  const i = e.target.closest('.app-i'); if (!i) return;
  i.style.transition = 'transform .08s'; i.style.transform = 'scale(.88)';
  const reset = () => { i.style.transform = ''; i.style.transition = ''; };
  setTimeout(() => {
    i.addEventListener('pointerup', reset, { once: true });
    i.addEventListener('pointercancel', reset, { once: true });
    i.addEventListener('pointerleave', reset, { once: true });
  }, 0);
}, { passive: true });

/* ================= 8. Setup & boot ================= */
let setupIdx = 0, setupTransit = false;

function setupStep(i) {
  if (setupTransit) return; // Prevent rapid clicking during animation
  setupIdx = i;
  const box = $('#step');
  if (!box) return;

  setupTransit = true;

  // 1. Fade out current content
  box.style.transition = 'opacity 0.22s ease, transform 0.22s ease';
  box.style.opacity = 0;
  box.style.transform = 'translateY(-10px)';

  setTimeout(() => {
    // 2. Build new content
    const finish = () => { S.done = true; save(); $('#setup').classList.add('hidden'); $('#os').classList.remove('hidden'); refresh(); toast(L('أهلاً بك في ALANZI ANDROID', 'Welcome to ALANZI ANDROID')); };
    const next = () => setupStep(i + 1);

    if (i === 0) {
      box.innerHTML = `<div class="step">
        <svg class="slogo" viewBox="0 0 100 100" style="margin-top: 30px; width: 130px; height: 130px; margin-bottom: 20px;">
          <path d="M50 15 L85 85 H65 L58 65 H42 L35 85 H15 Z M46 50 H54 L50 38 Z" fill="var(--sa)"/>
        </svg>
        <h2 class="stitle" style="margin-top: 10px;">${L('مرحبًا بك في', 'Welcome to')}<br><b>ALANZI<br>ANDROID</b></h2>
        <div class="srow" style="border:0; margin-top: auto; padding-bottom: 0;">
          <div class="t" style="font-size: 17px;">${L('اللغة', 'Language')}<br><small style="color:var(--mut); font-size:15px;">${L('العربية', 'English')}</small></div>
          <svg viewBox="0 0 24 24" style="fill:var(--mut); width:26px;"><path d="${P.globe}"/></svg>
        </div>
        <div class="srow" style="border:0; padding-top: 10px;">
          <div class="t" style="font-size: 17px;">${L('إعدادات إمكانية الوصول', 'Accessibility settings')}</div>
          <svg viewBox="0 0 24 24" style="fill:var(--mut); width:26px;"><path d="${P.access}"/></svg>
        </div>
        <button class="snext" id="sn">${L('البداية', 'Start')}</button>
      </div>`;
      $('#sn', box).onclick = next;
    } else if (i === 1) {
      box.innerHTML = `<div class="step">
        <svg class="sico" viewBox="0 0 24 24" style="width: 70px; height: 70px; margin-bottom: 20px;"><path d="${P.person}"/></svg>
        <h2 class="stitle">${L('تسجيل الدخول', 'Sign in')}</h2>
        <p class="sdesc">${L('أضف حسابك لمزامنة بياناتك. يُحفظ داخل المحاكي فقط.', 'Add your account to sync data. Saved locally in the simulator.')}</p>
        <input class="sfield" id="an" placeholder="${L('الاسم', 'Name')}">
        <input class="sfield" id="ae" type="email" placeholder="${L('البريد الإلكتروني', 'Email')}">
        <div style="display:flex; justify-content:flex-end; margin-top:auto; gap:12px; align-items:center;">
          <button class="flat" id="sk">${L('تخطي', 'Skip')}</button>
          <button class="snext" id="sn" style="margin-top:0; margin-left:0;">${L('التالي', 'Next')}</button>
        </div>
      </div>`;
      $('#sn', box).onclick = () => {
        const n = $('#an', box).value.trim(), e = $('#ae', box).value.trim();
        if (n && /^\S+@\S+\.\S+$/.test(e)) { S.acct = {name: n, email: e}; save(); }
        next();
      };
      $('#sk', box).onclick = next;
    } else if (i === 2) {
      box.innerHTML = `<div class="step">
        <svg class="sico" viewBox="0 0 24 24" style="width: 70px; height: 70px; margin-bottom: 20px;"><path d="${P.cal}"/></svg>
        <h2 class="stitle">${L('التاريخ والوقت', 'Date & time')}</h2>
        <p class="sdesc">${L('عيّن منطقتك الزمنية وراجع الوقت والتاريخ الحاليين.', 'Set your time zone and review the current date and time.')}</p>
        <div class="srow" style="border:0; padding-bottom:0;">
          <div class="t">${L('المنطقة الزمنية', 'Time zone')}<br><small style="font-size:15px;">Auto (device)</small></div>
        </div>
        <div class="srow" style="border:0; padding-top:10px; padding-bottom:0;">
          <div class="t">${L('التاريخ الحالي', 'Current date')}<br><small style="font-size:15px;">${new Date().toLocaleDateString('en-CA')}</small></div>
        </div>
        <div class="srow" style="border:0; padding-top:10px;">
          <div class="t">${L('الوقت الحالي', 'Current time')}<br><small style="font-size:15px;">${fmtT(new Date())}</small></div>
        </div>
        <button class="snext" id="sn">${L('التالي', 'Next')}</button>
      </div>`;
      $('#sn', box).onclick = next;
    } else if (i === 3) {
      box.innerHTML = `<div class="step">
        <svg class="sico" viewBox="0 0 24 24" style="width: 70px; height: 70px; margin-bottom: 20px;"><path d="${P.pin}"/></svg>
        <h2 class="stitle">${L('خدمات الموقع', 'Location services')}</h2>
        <div class="srow" id="l1" style="border:0; align-items:flex-start; padding-top:10px;">
          <div class="cbx ${S.loc ? 'on' : ''}" style="margin-top:4px; margin-inline-end:16px;">${ic(P.check)}</div>
          <div class="t" style="font-size:17px; line-height:1.5;">${L('السماح للتطبيقات التي طلبت إذنك باستخدام معلومات موقعك.', 'Allow apps that requested your permission to use your location info.')}</div>
        </div>
        <div class="srow" id="l2" style="border:0; align-items:flex-start; padding-top:10px;">
          <div class="cbx ${S.locAssist ? 'on' : ''}" style="margin-top:4px; margin-inline-end:16px;">${ic(P.check)}</div>
          <div class="t" style="font-size:17px; line-height:1.5;">${L('عند تشغيل الموقع، نزّل بيانات المساعدة من الإنترنت لتحسين أداء GPS.', 'When location is on, download assistance data to improve GPS.')}</div>
        </div>
        <button class="snext" id="sn">${L('التالي', 'Next')}</button>
      </div>`;
      $('#l1', box).onclick = () => { S.loc = !S.loc; save(); setupStep(3); };
      $('#l2', box).onclick = () => { S.locAssist = !S.locAssist; save(); setupStep(3); };
      $('#sn', box).onclick = next;
    } else if (i === 4) {
      box.innerHTML = `<div class="step">
        <svg class="sico" viewBox="0 0 24 24" style="width: 70px; height: 70px; margin-bottom: 20px;"><path d="${P.lock}"/></svg>
        <h2 class="stitle">${L('احمِ جهازك', 'Protect your device')}</h2>
        <p class="sdesc">${L('امنع الآخرين من استخدام هذا الجهاز دون إذنك عبر قفل الشاشة.', 'Prevent others from using this device without your permission.')}</p>
        <div class="srow" id="set-pin" style="border-bottom:1px solid var(--line);">
          <div class="t">PIN</div>
          <svg viewBox="0 0 24 24" style="width:24px;fill:var(--mut);"><path d="${P.lock}"/></svg>
        </div>
        <div style="display:flex; justify-content:flex-end; margin-top:auto;">
          <button class="flat" id="sk">${L('ليس الآن', 'Not now')}</button>
        </div>
      </div>`;
      $('#set-pin', box).onclick = () => setLock('pin');
      $('#sk', box).onclick = next;
    } else if (i === 5) {
      box.innerHTML = `<div class="step">
        <svg class="sico" viewBox="0 0 24 24" style="width: 80px; height: 80px; margin-bottom: 20px;"><path d="${P.check}"/></svg>
        <h2 class="stitle">${L('كل شيء جاهز', 'All set')}</h2>
        <p class="sdesc">${L('تم إعداد جهازك. استمتع بـ ALANZI ANDROID.', 'Your device is set up. Enjoy ALANZI ANDROID.')}</p>
        <button class="snext" id="sn">${L('ابدأ', 'Start')}</button>
      </div>`;
      $('#sn', box).onclick = finish;
    } else finish();

    // 3. Prepare fade in (start slightly lower)
    box.style.transform = 'translateY(10px)';
    
    // 4. Fade in new content
    requestAnimationFrame(() => {
      box.style.opacity = 1;
      box.style.transform = 'translateY(0)';
      
      // Allow next transition after animation completes
      setTimeout(() => { setupTransit = false; }, 220);
    });
  }, 220); // Wait for fade out to finish
}

async function bootSeq() {
  const b = $('#boot'); b.classList.remove('hidden'); b.style.opacity = '';
  $('#os').classList.add('hidden'); $('#setup').classList.add('hidden'); $('#off').classList.add('hidden');
  applyLang(); await wait(1500);
  b.style.opacity = 0; await wait(520); b.classList.add('hidden'); b.style.opacity = '';
  if (S.done) { $('#os').classList.remove('hidden'); refresh(); } else { $('#setup').classList.remove('hidden'); setupStep(0); }
}
applyLang();
bootSeq();

})();