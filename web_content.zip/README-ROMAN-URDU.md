# GymTracker Android Wrapper (Roman Urdu)

Yeh Android WebView wrapper hai jo aapki deployed GymTracker web app ko Android app ke andar kholta hai. Yeh abhi full native Kotlin/Room app nahi hai.

## APK banane ka asaan tareeqa (GitHub Actions)

1. ZIP ko extract karein.
2. GitHub par naya repository banayein, misal ke taur par `GymTracker-Android`.
3. Is folder ke tamam files repository mein upload karein. `.github/workflows/build-apk.yml` bhi upload hona chahiye.
4. GitHub repository ke **Actions** tab mein jayein.
5. Agar workflow manually chalana ho to **Build GymTracker APK** select karein aur **Run workflow** dabayein.
6. Build complete hone par run ke neeche **Artifacts** mein `GymTracker-debug-apk` download karein.
7. ZIP artifact extract karein; andar `app-debug.apk` hoga. Isay apne Android phone par install karein.

## Ahm limitations

- App internet connection par depend karti hai kyun ke website online load hoti hai.
- Attendance storage browser WebView ke local storage par depend karti hai; app data clear/uninstall karne se records ja sakte hain. JSON backup rakhein.
- Native Android notifications, Room database, offline bundled web assets, signed release APK aur Google Drive backup is starter mein shamil nahi.
- Debug APK testing ke liye hai. Public release ke liye signed release build aur proper QA chahiye.
- Workflow build ko tabhi successful samjhein jab GitHub Actions job green ho aur APK artifact maujood ho.

## Project structure

- `app/src/main/java/.../MainActivity.kt`: WebView activity
- `app/src/main/AndroidManifest.xml`: Android app declaration
- `app/build.gradle.kts`: Android build configuration
- `.github/workflows/build-apk.yml`: cloud APK build workflow

- `index.html`: ZIP ke root mein web entry page hai; yeh deployed GymTracker web app ko open karta hai. Is file ko akelay use karne par bhi internet chahiye.
