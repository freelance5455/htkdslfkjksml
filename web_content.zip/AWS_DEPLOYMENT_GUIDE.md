# 🚀 Complete AWS Serverless Deployment Guide
## Maa Annapurna Tiffin Service & Smart QR Management
**Location:** Kunwar Singh Nagar | **Contact:** +91 9311155593 | **Storage:** AWS DynamoDB & Cognito

---

## 📑 Architecture Overview

```mermaid
flowchart TD
    subgraph Client ["Client Device (Mobile Browser / PWA / Laptop)"]
        UI["Maa Annapurna Tiffin App\n(HTML5 / Tailwind / Vanilla JS)"]
        Auth["CognitoAuth Client\n(Native REST SDK)"]
        DDBClient["DynamoClient\n(Partitioned by userId)"]
        Tokens["localStorage\n(JWT Tokens ONLY)"]
    end

    subgraph AWS ["Amazon Web Services (AWS Cloud - ap-south-1 Mumbai)"]
        Cognito["AWS Cognito User Pool\n(Sign Up, OTP, Sign In, Reset)"]
        APIGW["AWS API Gateway\n(JWT Authorizer + CORS)"]
        Lambda["AWS Lambda (Node.js 20)\n(index.handler)"]
        DynamoDB[("AWS DynamoDB Table\n(TiffinTrackerData\nPK: userId)")]
        S3["AWS S3 Static Website\n(Web Hosting & CDN)"]
    end

    UI --> Auth
    Auth <-->|"1. Auth REST / Tokens"| Cognito
    Auth --> Tokens
    UI --> DDBClient
    DDBClient -->|"2. Bearer JWT + Data"| APIGW
    APIGW -->|"3. Verified sub claim"| Lambda
    Lambda <-->|"4. GetItem / PutItem (userId)"| DynamoDB
    S3 -.->|"Hosts App Assets"| UI
```

---

## 📌 Prerequisites & AWS Free Tier Overview
All services chosen here fall safely within the **AWS Always Free Tier** or **12-Month Free Tier**:
- **AWS Cognito:** 50,000 Monthly Active Users (MAU) completely free.
- **AWS DynamoDB:** 25 GB of storage + 25 Read & 25 Write Capacity Units free forever.
- **AWS Lambda:** 1 Million invocations + 3.2 million seconds compute time free every month.
- **AWS API Gateway:** 1 Million HTTP API calls free per month.
- **AWS S3:** 5 GB standard storage free for 12 months.

---

## 🗄️ Step 1: Create AWS DynamoDB Table

### Click-by-Click Console Instructions:
1. Log in to the [AWS Management Console](https://console.aws.amazon.com/).
2. Select your desired AWS Region in the top-right header (Recommended for India: **Asia Pacific (Mumbai) `ap-south-1`**).
3. Search for **DynamoDB** in the top search bar and click on it.
4. Click the orange **Create table** button.
5. In the **Table details** section:
   - **Table name:** `TiffinTrackerData` *(exact match)*
   - **Partition key:** `userId`
   - **Data type:** `String` (Leave as `S`)
   - **Sort key:** *Leave blank (No sort key required)*
6. In the **Table settings** section:
   - Select **Customize settings**.
   - Under **Table class**, select **DynamoDB Standard**.
   - Under **Capacity calculator / Read/write capacity settings**, select **On-demand** *(Pay only for what you use, 0 maintenance cost, ideal for free tier)*.
   - Encryption at rest: **Owned by Amazon DynamoDB** (Default).
7. Scroll to the bottom and click **Create table**.
8. Wait ~10 seconds until the table status becomes **Active**.

---

## 🔐 Step 2: Create AWS Cognito User Pool

### Click-by-Click Console Instructions:
1. In the AWS Console search bar, search for **Cognito** and click **Cognito**.
2. Click **Create user pool**.

#### Step 2.1: Configure sign-in experience
- **Cognito user pool sign-in options:**
  - Check **Email**
  - Check **Phone number**
- Click **Next**.

#### Step 2.2: Configure security requirements
- **Password policy:** Select **Cognito defaults** (Minimum length: 8, Numbers, Special characters, Uppercase, Lowercase).
- **Multi-factor authentication (MFA):** Select **No MFA** *(or Optional MFA if SMS OTP is configured)*.
- **User account recovery:** Check **Enable self-service account recovery**.
- **Delivery method:** Select **Email only**.
- Click **Next**.

#### Step 2.3: Configure sign-up experience
- **Self-registration:** Ensure **Enable self-registration** is checked.
- **Attribute verification and user confirmation:**
  - Check **Send email message, verify email address**.
- **Required attributes:**
  - Select `email`
  - Select `name`
  - Select `phone_number`
- Click **Next**.

#### Step 2.4: Configure message delivery
- Under **Email provider**, select **Send email with Cognito** (Free Tier: 50 emails/day; switch to Amazon SES for high volume).
- Click **Next**.

#### Step 2.5: Integrate your app
- **User pool name:** `tiffin-tracker-users`
- **Initial app client:**
  - **App type:** Select **Public client** *(Crucial: This is for single-page browser web apps)*.
  - **App client name:** `tiffin-tracker-web-client`
  - **Client secret:** Select **Don't generate a client secret** *(CRITICAL: Web apps running in browsers cannot keep secrets)*.
  - **Allowed return URLs / Domain:** Leave default.
- Click **Next**.

#### Step 2.6: Review and create
- Review all settings.
- Click **Create user pool**.

### 📝 Important IDs to Copy:
- Click on your newly created user pool `tiffin-tracker-users`.
- In the **User pool overview**, copy:
  1. **User pool ID** (e.g., `ap-south-1_aBc123XyZ`)
- Click the **App integration** tab, scroll to the bottom under **App clients and analytics**, and copy:
  2. **Client ID** (e.g., `3ab12cd34ef56gh78ij90klmn`)

---

## 🛡️ Step 3: Create AWS IAM Role for Lambda

### Click-by-Click Console Instructions:
1. Search for **IAM** in the top search bar.
2. In the left navigation, click **Roles**, then click **Create role**.
3. Select **AWS service** as the trusted entity type.
4. Under **Use case**, select **Lambda**, then click **Next**.
5. In **Add permissions**, search for and check:
   - `AWSLambdaBasicExecutionRole`
6. Click **Next**.
7. **Role name:** `TiffinTrackerLambdaRole`
8. Click **Create role**.
9. Now click on the newly created role `TiffinTrackerLambdaRole`.
10. Click **Add permissions** &rarr; **Create inline policy**.
11. Click the **JSON** tab and paste the following policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem",
        "dynamodb:UpdateItem",
        "dynamodb:Query"
      ],
      "Resource": "arn:aws:dynamodb:ap-south-1:*:table/TiffinTrackerData"
    }
  ]
}
```

12. Click **Next**. Name the policy `DynamoDBTiffinAccessPolicy` and click **Create policy**.

---

## ⚡ Step 4: Deploy AWS Lambda Function

### Click-by-Click Console Instructions:
1. Search for **Lambda** in the AWS Console search bar.
2. Click **Create function**.
3. Choose **Author from scratch**:
   - **Function name:** `tiffin-tracker-api`
   - **Runtime:** **Node.js 20.x**
   - **Architecture:** **x86_64**
   - **Permissions:** Click *Change default execution role*, select **Use an existing role**, and pick `TiffinTrackerLambdaRole`.
4. Click **Create function**.

### Step 4.1: Paste Lambda Code
1. In the **Code source** editor, open `index.mjs` or `index.js`.
2. Replace all contents with the code located in your project at `lambda/index.js`:

```javascript
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

const REGION = process.env.AWS_REGION || process.env.REGION || 'ap-south-1';
const TABLE_NAME = process.env.TABLE_NAME || 'TiffinTrackerData';

const ddbClient = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(ddbClient);

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS',
  'Content-Type': 'application/json'
};

exports.handler = async (event) => {
  const httpMethod = event.httpMethod || event.requestContext?.http?.method || 'GET';

  if (httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: 'CORS OK' }) };
  }

  try {
    let userId = null;
    if (event.requestContext?.authorizer?.jwt?.claims?.sub) {
      userId = event.requestContext.authorizer.jwt.claims.sub;
    } else if (event.requestContext?.authorizer?.claims?.sub) {
      userId = event.requestContext.authorizer.claims.sub;
    } else if (event.headers?.Authorization || event.headers?.authorization) {
      const authHeader = event.headers.Authorization || event.headers.authorization;
      const token = authHeader.replace(/^Bearer\s+/i, '');
      try {
        const parts = token.split('.');
        if (parts.length === 3) {
          const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf8'));
          userId = payload.sub || payload['cognito:username'];
        }
      } catch {}
    }

    if (!userId && event.queryStringParameters?.userId) userId = event.queryStringParameters.userId;
    if (!userId && event.body) {
      try { const p = JSON.parse(event.body); if (p.userId) userId = p.userId; } catch {}
    }

    if (!userId) {
      return {
        statusCode: 401,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: 'Unauthorized: Missing Cognito User ID' })
      };
    }

    if (httpMethod === 'GET') {
      const getCmd = new GetCommand({ TableName: TABLE_NAME, Key: { userId } });
      const result = await docClient.send(getCmd);
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ message: 'Success', item: result.Item || null })
      };
    }

    if (httpMethod === 'POST' || httpMethod === 'PUT') {
      const bodyData = typeof event.body === 'string' ? JSON.parse(event.body) : (event.body || {});
      const itemToSave = {
        userId,
        updatedAt: new Date().toISOString(),
        clients: Array.isArray(bodyData.clients) ? bodyData.clients : [],
        logs: Array.isArray(bodyData.logs) ? bodyData.logs : [],
        boxStates: bodyData.boxStates || {},
        settings: bodyData.settings || {},
        weeklyMenu: bodyData.weeklyMenu || {},
        customMenus: Array.isArray(bodyData.customMenus) ? bodyData.customMenus : [],
        extraItemsCatalog: Array.isArray(bodyData.extraItemsCatalog) ? bodyData.extraItemsCatalog : []
      };

      await docClient.send(new PutCommand({ TableName: TABLE_NAME, Item: itemToSave }));
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: true, message: 'Saved to DynamoDB', updatedAt: itemToSave.updatedAt, userId })
      };
    }

    return { statusCode: 405, headers: CORS_HEADERS, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  } catch (error) {
    return { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ error: error.message }) };
  }
};
```
3. Click the orange **Deploy** button above the code editor.

### Step 4.2: Configure Environment Variables
1. Click the **Configuration** tab under the function overview.
2. Select **Environment variables** on the left.
3. Click **Edit** &rarr; **Add environment variable**:
   - Key: `TABLE_NAME` | Value: `TiffinTrackerData`
   - Key: `REGION` | Value: `ap-south-1`
4. Click **Save**.

---

## 🌐 Step 5: Configure AWS API Gateway

### Click-by-Click Console Instructions:
1. Search for **API Gateway** in the top search bar.
2. Click **Create API**.
3. Under **HTTP API**, click **Build** *(Recommended: Lowest cost, native JWT Cognito integration)*.

#### Step 5.1: Create Routes & Integrations
1. **API name:** `tiffin-tracker-gateway`
2. Click **Add integration**:
   - Integration type: **Lambda**
   - Lambda function: Select `tiffin-tracker-api`
3. Click **Next**.
4. Under **Configure routes**:
   - Method: `ANY`
   - Resource path: `/data`
   - Integration: Select `tiffin-tracker-api`
5. Click **Next** &rarr; Stage name: `$default` (Auto-deploy enabled) &rarr; Click **Next** &rarr; Click **Create**.

#### Step 5.2: Configure CORS (Cross-Origin Resource Sharing)
1. On the left menu of your API, click **CORS**.
2. Click **Configure**:
   - **Access-Control-Allow-Origin:** `*`
   - **Access-Control-Allow-Headers:** `Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token`
   - **Access-Control-Allow-Methods:** `GET, POST, PUT, OPTIONS`
3. Click **Save**.

### 📝 Copy Your Invoke URL:
- In the API Overview, copy your **Invoke URL** (e.g. `https://a1b2c3d4e5.execute-api.ap-south-1.amazonaws.com`).

---

## 🪣 Step 6: Host Frontend on AWS S3 Static Website

### Click-by-Click Console Instructions:
1. Search for **S3** in the top search bar.
2. Click **Create bucket**.
   - **Bucket name:** `maa-annapurna-tiffin-app` *(Bucket names must be globally unique; append your initials if taken)*.
   - **AWS Region:** `ap-south-1`
   - **Block Public Access settings for this bucket:** **Uncheck "Block all public access"** and acknowledge the warning checkbox.
3. Click **Create bucket**.

#### Step 6.1: Enable Static Website Hosting
1. Click into your new bucket.
2. Go to the **Properties** tab.
3. Scroll to the very bottom to **Static website hosting** &rarr; Click **Edit**.
   - Select **Enable**.
   - **Hosting type:** Host a static website.
   - **Index document:** `index.html`
   - **Error document:** `index.html`
4. Click **Save changes**.

#### Step 6.2: Add Public Read Bucket Policy
1. Go to the **Permissions** tab.
2. Scroll to **Bucket policy** &rarr; Click **Edit**.
3. Paste the following JSON (replace `maa-annapurna-tiffin-app` with your exact bucket name):

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::maa-annapurna-tiffin-app/*"
    }
  ]
}
```
4. Click **Save changes**.

#### Step 6.3: Upload Application Files
1. Go to the **Objects** tab &rarr; Click **Upload**.
2. Upload the files from `C:\Users\Admin\.gemini\antigravity\scratch\tiffin-tracker-app\`:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `aws-config.js`
   - `cognito-auth.js`
   - `dynamo-client.js`
   - `manifest.json`
   - `sw.js`
3. Click **Upload**.

Your live website URL will appear under **Properties &rarr; Static website hosting &rarr; Bucket website endpoint**.

---

## ⚙️ Step 7: Connect the Web App to Your AWS Cloud

You have **two quick methods** to connect the app to your deployed AWS infrastructure:

### Method A: In-App UI Configuration (Easiest - 1 Click)
1. Open the app in your browser.
2. In the top bar or settings, click the purple **AWS Setup** / **Cloud** button.
3. Enter your values:
   - **AWS Region:** `ap-south-1`
   - **Cognito User Pool ID:** `ap-south-1_xxxxxxxxx`
   - **Cognito App Client ID:** `3ab12cd34ef56gh78ij90klmn`
   - **API Gateway Invoke URL:** `https://xxxxxx.execute-api.ap-south-1.amazonaws.com`
   - **DynamoDB Table Name:** `TiffinTrackerData`
4. Click **Save AWS Cloud Settings**.
5. The cloud status badge instantly turns to **`☁️ DynamoDB: Synced`**!

### Method B: Edit `aws-config.js`
Open `aws-config.js` and set your credentials:

```javascript
const AWS_CONFIG = {
  region: 'ap-south-1',
  userPoolId: 'ap-south-1_aBcDeFg12',
  clientId: '3ab12cd34ef56gh78ij90klmn',
  apiGatewayUrl: 'https://xxxxxx.execute-api.ap-south-1.amazonaws.com',
  tableName: 'TiffinTrackerData'
};
```

---

## 🖨️ Step 8: Generating 300 QR Stickers for Tiffin Boxes
1. Navigate to the **6-Digit QR Code Generator & Print** tab in the app.
2. Click the **🔥 300 Boxes (Full Kitchen)** preset button.
3. The generator will render 300 unique 6-digit stickers (`MAT001` through `MAT300` or `100001` to `100300`) with smooth progress feedback:
   ```
   Generating 300 QR Stickers... 150/300 (50%)
   ✅ 300 Stickers Ready (MAT001 to MAT300)
   ```
4. Click **Print Stickers (A4)** to print or save as a PDF. The layout is optimized with `page-break-inside: avoid;` to fit exactly on standard sticker sheets without cutting codes across pages.

---

## 🧪 Step 9: Verification Checklist
- [x] **Sign Up:** Register a new user (`owner@domain.com`).
- [x] **Verify OTP:** Enter the 6-digit code received via email to activate the account.
- [x] **Sign In:** Log in to receive Cognito tokens (`idToken`, `accessToken`, `refreshToken`, `userId`).
- [x] **Zero Business Data in localStorage:** Open DevTools &rarr; Application &rarr; Local Storage. Verify only `cognito_*` tokens exist.
- [x] **Cloud Multi-Device Sync:** Disptach a box or register a customer, open the app on another phone or incognito tab, log in with the same account, and verify all records load instantly from AWS DynamoDB.
- [x] **Forgot Password:** Request a reset code, enter the OTP and set a new password.
- [x] **300 Stickers:** Generate 300 QR codes and print to A4.
