CHURAI — APK-ready web project

1. Open index.html in Acode to test the app.
2. This version is a standalone HTML/CSS/JS demo.
3. To make a real Android APK, wrap this web app with an Android WebView/Capacitor-style build.
4. The current AI replies are demo replies; no API key is included.
