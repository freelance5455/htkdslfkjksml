# CPLS V2 — Stage 1119

هدف: تشخیص واقعی کانال Futures WebSocket رسمی LBank بدون حدس‌زدن subscription.

## تغییرات
- اتصال Native OkHttp به `wss://lbkperpws.lbank.com/ws` اضافه شد.
- در زمان اتصال هیچ subscription ساختگی ارسال نمی‌شود.
- پیام‌های اولیه/خطا/بسته‌شدن اتصال به UI از طریق `cpNativeFuturesWsDiag` گزارش می‌شوند.
- اگر پیام `action=ping` دریافت شود، همان شناسه با `action=pong` پاسخ داده می‌شود.
- reconnect با backoff تا ۳۰ ثانیه انجام می‌شود.
- Futures REST/market/depth feed فعلی حفظ شده و به WebSocket آزمایشی وابسته نشده است.
- هیچ قیمت ساختگی یا K-Line ساختگی به‌عنوان داده زنده معرفی نمی‌شود.

مرجع رسمی: https://www.lbank.com/docs/contract.html

## وضعیت
این مرحله برای مشخص کردن این است که آیا خود کانال Futures WebSocket روی دستگاه باز می‌شود و آیا سرور پیام اولیه/heartbeat می‌فرستد. فرمت subscription عمومی Futures در مستند فعلی LBank به اندازه‌ای مشخص نیست که بتوان با اطمینان آن را حدس زد.
