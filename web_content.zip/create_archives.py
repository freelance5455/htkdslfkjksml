import os
import zipfile
import subprocess
import shutil

ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
PUBLIC_DIR = os.path.join(ROOT_DIR, "public")
DIST_DIR = os.path.join(ROOT_DIR, "dist")

os.makedirs(PUBLIC_DIR, exist_ok=True)

# 1. Run build to create dist
print("Running npm run build...")
try:
    subprocess.run(["npm", "run", "build"], cwd=ROOT_DIR, check=True)
    print("Build successful.")
except Exception as e:
    print(f"Build failed or warning: {e}")

SOURCE_ZIP_NAME = "shanju-source-code.zip"
DIST_ZIP_NAME = "shanju-production-dist.zip"

source_zip_path = os.path.join(PUBLIC_DIR, SOURCE_ZIP_NAME)
dist_zip_path = os.path.join(PUBLIC_DIR, DIST_ZIP_NAME)

# Remove old zips if existing
for p in [source_zip_path, dist_zip_path]:
    if os.path.exists(p):
        os.remove(p)

# 2. Create source code zip
EXCLUDE_DIRS = {"node_modules", "dist", ".git", ".idea", ".vscode", "__pycache__"}
EXCLUDE_FILES = {SOURCE_ZIP_NAME, DIST_ZIP_NAME, "create_archives.py"}

print("Packaging full source code...")
with zipfile.ZipFile(source_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        # Filter out directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        
        for file in files:
            if file in EXCLUDE_FILES or file.endswith(".zip"):
                continue
            abs_file_path = os.path.join(root, file)
            # Relative path inside the zip
            rel_path = os.path.relpath(abs_file_path, ROOT_DIR)
            zipf.write(abs_file_path, arcname=os.path.join("shanju-ecommerce", rel_path))

print(f"Source ZIP created at: {source_zip_path} (Size: {os.path.getsize(source_zip_path)} bytes)")

# 3. Create production dist zip
if os.path.exists(DIST_DIR):
    print("Packaging production dist...")
    with zipfile.ZipFile(dist_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(DIST_DIR):
            for file in files:
                if file.endswith(".zip"):
                    continue
                abs_file_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_file_path, DIST_DIR)
                zipf.write(abs_file_path, arcname=rel_path)
    print(f"Dist ZIP created at: {dist_zip_path} (Size: {os.path.getsize(dist_zip_path)} bytes)")
    
    # Copy zips into dist as well so Vite preview/production servers can also serve them
    shutil.copy(source_zip_path, os.path.join(DIST_DIR, SOURCE_ZIP_NAME))
    shutil.copy(dist_zip_path, os.path.join(DIST_DIR, DIST_ZIP_NAME))

print("All archives created successfully!")
