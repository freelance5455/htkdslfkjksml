package com.salaryot.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int A4_W = 595, A4_H = 842;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl("file:///android_asset/salary_ot_calculator.html");
    }

    private void toast(String m){ runOnUiThread(() -> Toast.makeText(this,m,Toast.LENGTH_SHORT).show()); }

    private void exportWholePage(final String name, final boolean png) {
        runOnUiThread(() -> {
            String js = "document.body.classList.add('android-exporting');renderReport();true;";
            webView.evaluateJavascript(js, value -> webView.postDelayed(() -> {
                try {
                    int w = A4_W;
                    webView.measure(ViewMeasure(w), ViewMeasureUnspec());
                    int h = Math.max(A4_H, webView.getMeasuredHeight());
                    webView.layout(0,0,w,h);
                    if (png) savePng(name,w,h); else savePdf(name,w,h);
                } catch(Exception e){ toast("ส่งออกไฟล์ไม่สำเร็จ: "+e.getMessage()); }
                finally { webView.evaluateJavascript("document.body.classList.remove('android-exporting');true;", null); }
            }, 350));
        });
    }

    private int ViewMeasure(int size){ return android.view.View.MeasureSpec.makeMeasureSpec(size, android.view.View.MeasureSpec.EXACTLY); }
    private int ViewMeasureUnspec(){ return android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED); }

    private void savePng(String name,int w,int h) throws Exception {
        Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp); c.drawColor(Color.WHITE); webView.draw(c);
        if(Build.VERSION.SDK_INT>=29){ ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"image/png");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Salary_OT");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);try(OutputStream o=getContentResolver().openOutputStream(u)){bmp.compress(Bitmap.CompressFormat.PNG,100,o);} }
        else {File d=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"Salary_OT");d.mkdirs();try(FileOutputStream o=new FileOutputStream(new File(d,name))){bmp.compress(Bitmap.CompressFormat.PNG,100,o);}}
        toast("บันทึก PNG ใน Downloads/Salary_OT แล้ว");
    }

    private void savePdf(String name,int w,int h) throws Exception {
        PdfDocument doc=new PdfDocument();int pages=(int)Math.ceil(h/(double)A4_H);
        for(int i=0;i<pages;i++){PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(A4_W,A4_H,i+1).create();PdfDocument.Page p=doc.startPage(info);Canvas c=p.getCanvas();c.drawColor(Color.WHITE);c.save();c.translate(0,-i*A4_H);webView.draw(c);c.restore();doc.finishPage(p);}
        if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Salary_OT");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);try(OutputStream o=getContentResolver().openOutputStream(u)){doc.writeTo(o);}}
        else {File d=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"Salary_OT");d.mkdirs();try(FileOutputStream o=new FileOutputStream(new File(d,name))){doc.writeTo(o);}}
        doc.close();toast("บันทึก PDF A4 ใน Downloads/Salary_OT แล้ว");
    }

    private class Bridge {
        @JavascriptInterface public void exportPNG(){ exportWholePage("salary-"+System.currentTimeMillis()+".png",true); }
        @JavascriptInterface public void printA4(){ exportWholePage("salary-"+System.currentTimeMillis()+".pdf",false); }
        @JavascriptInterface public void printReport(){
            runOnUiThread(() -> {
                webView.evaluateJavascript("document.body.classList.add('android-exporting');renderReport();true;", v -> webView.postDelayed(() -> {
                    PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                    pm.print("Salary_OT_Report", webView.createPrintDocumentAdapter("Salary_OT_Report"), attrs);
                    webView.postDelayed(() -> webView.evaluateJavascript("document.body.classList.remove('android-exporting');true;", null), 1500);
                },350));
            });
        }
        @JavascriptInterface public void saveTextFile(String name,String mime,String b64){
            try{byte[] data=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Salary_OT");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(data);}}else{File d=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"Salary_OT");d.mkdirs();try(FileOutputStream o=new FileOutputStream(new File(d,name))){o.write(data);}}toast("บันทึก CSV ใน Downloads/Salary_OT แล้ว");}catch(Exception e){toast("บันทึก CSV ไม่สำเร็จ");}
        }
    }
}
