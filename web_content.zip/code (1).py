import os
import re
import hashlib
import uuid
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
import pefile  # pip install pefile

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'exe', 'dll'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_license_info(pe_path):
    """
    Analyzes an EXE/DLL for common license validation patterns.
    Returns a dict with findings.
    """
    info = {
        'filename': os.path.basename(pe_path),
        'size': os.path.getsize(pe_path),
        'version': None,
        'company': None,
        'product': None,
        'description': None,
        'strings_found': [],
        'potential_key_formats': [],
        'analysis_status': 'success'
    }

    try:
        pe = pefile.PE(pe_path)
        
        # Extract Version Info
        if hasattr(pe, 'FILE_INFO'):
            for file_info in pe.FILE_INFO:
                if file_info.Key == b'StringFileInfo':
                    for string_table in file_info.StringTable:
                        for entry in string_table.entries.items():
                            key, value = entry
                            val_str = value.decode('utf-8', errors='ignore')
                            if key == b'CompanyName':
                                info['company'] = val_str
                            elif key == b'ProductName':
                                info['product'] = val_str
                            elif key == b'ProductVersion':
                                info['version'] = val_str
                            elif key == b'FileDescription':
                                info['description'] = val_str

        # Scan all readable sections for license-related strings
        license_keywords = [
            b'license', b'key', b'serial', b'register', b'activation', 
            b'invalid', b'error', b'check', b'valid', b'auth', b'trial',
            b'expired', b'name', b'email', b'code'
        ]
        
        found_strings = set()
        for section in pe.sections:
            try:
                data = section.get_data()
                # Decode as ASCII/UTF-8, ignore errors
                text = data.decode('ascii', errors='ignore')
                # Find strings longer than 4 chars
                words = re.findall(r'\b[a-zA-Z0-9]{4,}\b', text)
                for word in words:
                    lower_word = word.lower()
                    for kw in license_keywords:
                        if kw.decode() in lower_word:
                            found_strings.add(word)
            except Exception:
                continue

        info['strings_found'] = list(found_strings)[:50]  # Limit to 50 most relevant

        # Heuristic Key Format Detection
        # Look for patterns like XXXX-XXXX-XXXX-XXXX or AAAAA-BBBBB
        common_patterns = [
            r'[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}',  # Standard CD-Key style
            r'[A-Za-z0-9]{20,}',                                   # Long alphanumeric keys
            r'\d{10,}',                                             # Numeric serials
        ]
        
        detected_formats = []
        for pattern in common_patterns:
            matches = re.findall(pattern, text)
            if matches:
                detected_formats.append({
                    'pattern': pattern,
                    'count': len(matches),
                    'example': matches[0][:20] + '...'
                })
        
        info['potential_key_formats'] = detected_formats

    except Exception as e:
        info['analysis_status'] = f'error: {str(e)}'
    
    return info

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Process the file
        result = extract_license_info(filepath)
        
        # Clean up uploaded file after analysis (optional, remove this line if you want to keep them)
        # os.remove(filepath)
        
        return jsonify(result)
    
    return jsonify({'error': 'Invalid file type. Only .exe and .dll allowed.'}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)