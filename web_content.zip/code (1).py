import random
import json
import os
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify

app = Flask(__name__)

# File to store user generation data (simulating a database)
DATA_FILE = 'user_data.json'

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    return {"last_generated": None, "card_details": None}

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f)

def generate_luhn_number():
    """Generates a random credit card number that passes the Luhn check."""
    # Common prefixes for Visa (4), Mastercard (51-55), Amex (34/37)
    prefix = random.choice(['4', '51', '52', '53', '54', '55', '34', '37'])
    
    # Generate random digits (length 13-19 depending on type, standard is usually 16)
    length = len(prefix) + random.randint(10, 16 - len(prefix))
    number = prefix + ''.join([str(random.randint(0, 9)) for _ in range(length - len(prefix) - 1)])
    
    # Calculate Luhn check digit
    def luhn_checksum(n):
        digits = [int(d) for d in n[::-1]]
        odd_sum = sum(digits[0::2])
        even_sum = sum(sum(divmod(2 * d, 10)) for d in digits[1::2])
        return (odd_sum + even_sum) % 10

    check_digit = (10 - luhn_checksum(number)) % 10
    return number + str(check_digit)

def generate_expiry():
    """Generates a future expiry date."""
    month = random.randint(1, 12)
    year = random.randint(datetime.now().year + 1, datetime.now().year + 5)
    return f"{month:02d}/{year}"

def generate_cvv():
    """Generates a 3 or 4 digit CVV."""
    if random.random() > 0.9: # 10% chance of 4 digits (Amex style)
        return ''.join([str(random.randint(0, 9)) for _ in range(4)])
    return ''.join([str(random.randint(0, 9)) for _ in range(3)])

@app.route('/')
def index():
    data = load_data()
    return render_template('index.html', last_gen=data.get('last_generated'), card=data.get('card_details'))

@app.route('/generate', methods=['POST'])
def generate_card():
    data = load_data()
    now = datetime.now()
    
    # Check limit: If last generated was today, block
    if data.get('last_generated'):
        last_date = datetime.strptime(data['last_generated'], '%Y-%m-%d %H:%M:%S')
        if last_date.date() == now.date():
            return jsonify({
                'success': False, 
                'message': 'You have already generated a card today! Come back tomorrow.'
            }), 429 # Too Many Requests

    # Generate new card
    new_card = {
        'number': generate_luhn_number(),
        'expiry': generate_expiry(),
        'cvv': generate_cvv(),
        'balance': '$100.00',
        'type': 'Visa' if generate_luhn_number().startswith('4') else ('Mastercard' if generate_luhn_number().startswith(('51','52','53','54','55')) else 'AMEX')
    }
    
    # Save data
    data['last_generated'] = now.strftime('%Y-%m-%d %H:%M:%S')
    data['card_details'] = new_card
    save_data(data)

    return jsonify({
        'success': True,
        'card': new_card
    })

if __name__ == '__main__':
    app.run(debug=True)