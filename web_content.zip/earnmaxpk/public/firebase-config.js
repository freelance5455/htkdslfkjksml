// Paste your Firebase Web App config (Project settings > Your apps). These values are public by design.
export const firebaseConfig = { apiKey: 'PASTE', authDomain: 'PASTE.firebaseapp.com', projectId: 'PASTE', appId: 'PASTE' };
