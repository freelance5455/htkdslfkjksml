import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFirestore, collection, doc, onSnapshot, query, where } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { firebaseConfig } from './firebase-config.js';

const auth = getAuth(initializeApp(firebaseConfig)), db = getFirestore(auth.app);
const $ = s => document.querySelector(s), app = $('#app');
const rs = n => 'Rs ' + (+n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 });
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => '&#' + c.charCodeAt(0) + ';');
const pkDay = (ms = Date.now()) => new Date(ms + 5 * 36e5).toISOString().slice(0, 10);
const S = { splash: true, tab: 'home', filter: 'All', mode: 'in', me: null, tasks: [], tx: [], wd: [], done: new Set(), started: {}, rot: 0, cfg: { minWithdraw: 500, refPercent: 10, dailyBonus: 5 } };
let unsub = [], installEv;
document.documentElement.dataset.theme = localStorage.theme || 'light';
const q0 = new URLSearchParams(location.search).get('ref'); if (q0) { S.ref = q0.toUpperCase(); S.mode = 'up'; }
const prizes = () => String(S.cfg.prizes ?? '0,1,2,5,10').split(',').map(Number).filter(n => n >= 0 && n <= 1000);
const refLink = () => location.origin + '/?ref=' + S.me.refCode;
const IC = { App: '📱', Video: '▶️', Survey: '📝', Social: '💬', Game: '🎮', Other: '⭐' };

const toast = m => { const t = $('#toast'); t.textContent = m; t.className = 'show'; setTimeout(() => t.className = '', 2600); };
async function api(a, body = {}) {
  const r = await fetch('/api/' + a, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + await auth.currentUser.getIdToken() }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Request failed'); return j;
}
const rows = s => s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));

onAuthStateChanged(auth, async u => {
  unsub.forEach(f => f()); unsub = []; S.me = null; S.tab = 'home';
  if (!u) return render();
  try { await api('init', { name: S.name, ref: S.ref }); } catch (e) { toast(e.message); }
  const sub = (q, fn) => unsub.push(onSnapshot(q, s => { fn(s); render(); }, e => console.error(e)));
  sub(doc(db, 'users', u.uid), s => S.me = s.data());
  sub(doc(db, 'settings', 'app'), s => Object.assign(S.cfg, s.data() || {}));
  sub(collection(db, 'tasks'), s => S.tasks = rows(s).filter(t => t.active));
  sub(query(collection(db, 'transactions'), where('uid', '==', u.uid)), s => S.tx = rows(s));
  sub(query(collection(db, 'withdrawals'), where('uid', '==', u.uid)), s => S.wd = rows(s));
  sub(query(collection(db, 'completions'), where('uid', '==', u.uid)), s => S.done = new Set(s.docs.map(d => d.id)));
});

const head = (t, back) => `<div class="top"><div class="row">${back ? `<button class="back" data-act="tab" data-v="${back}">←</button>` : '<span style="width:40px"></span>'}<h1>${t}</h1><span style="width:40px"></span></div></div>`;
const list = a => a.length ? a.map(t => `<div class="card row"><span>${esc(t.note)}<small>${t.createdAt ? new Date(t.createdAt.seconds * 1000).toLocaleString('en-PK', { dateStyle: 'medium', timeStyle: 'short' }) : ''}</small></span><b class="${t.amount < 0 ? 'neg' : 'pos'}">${t.amount < 0 ? '−' : '+'}${rs(Math.abs(t.amount))}</b></div>`).join('') : '<p class="sm c">No activity yet. Complete a task to earn your first reward.</p>';
const taskList = L => L.length ? L.map(t => {
  const done = S.done.has(`${auth.currentUser.uid}_${t.id}_${t.repeat === 'daily' ? pkDay() : 'once'}`), s = S.started[t.id];
  return `<div class="card row"><span class="row" style="justify-content:flex-start"><span class="ic">${IC[t.type] || '⭐'}</span><span><b>${esc(t.title)}</b><small>${t.repeat === 'daily' ? 'Daily' : 'One time'} • <span class="pos">+${rs(t.reward)}</span></small></span></span>${done ? '<i class="st-paid">Done ✓</i>' : s ? `<button class="btn sm2" data-act="claim" data-id="${t.id}" data-until="${s}">Claim</button>` : `<button class="btn sm2" data-act="start" data-id="${t.id}">${t.type === 'Game' ? 'Play' : 'Start'}</button>`}</div>`;
}).join('') : '<p class="sm c">Nothing available here right now. Check back soon.</p>';
const wheel = P => `<div class="wheel" id="wh" style="transform:rotate(${S.rot}deg);background:conic-gradient(${P.map((_, i) => `${['#7c3aed', '#f5b301', '#ec4899', '#10b981', '#f97316'][i % 5]} ${i * 360 / P.length}deg ${(i + 1) * 360 / P.length}deg`).join(',')})">${P.map((v, i) => `<span style="transform:rotate(${(i + .5) * 360 / P.length}deg) translateY(-62px)">${v}</span>`).join('')}</div>`;

const V = {
  home() {
    const m = S.me, today = S.tx.filter(t => t.amount > 0 && t.createdAt && pkDay(t.createdAt.seconds * 1000) === pkDay()).reduce((a, t) => a + t.amount, 0);
    const T = [['tasks', '✅', 'Tasks', '#10b981,#34d399', 'All'], ['tasks', '▶️', 'Watch Ads', '#f97316,#fb923c', 'Video'], ['games', '🎮', 'Games', '#6d28d9,#8b5cf6'], ['rewards', '🎁', 'Daily Bonus', '#d97706,#fbbf24'], ['rewards', '🎡', 'Spin Wheel', '#db2777,#f472b6'], ['tasks', '📝', 'Survey', '#0d9488,#2dd4bf', 'Survey']];
    return `<div class="top"><div class="row"><h1>👑 Earn Max PK</h1><button class="back" data-act="tab" data-v="settings">⚙</button></div><div class="pcard"><div class="avatar sm">${esc(m.name[0] || '?')}</div><div><b>${esc(m.name)}</b><small>${m.vip ? 'Premium User ✔' : 'Member'}</small></div>${m.vip ? '<span class="badge">VIP</span>' : ''}</div><div class="bal"><small>Verified balance</small><b>${rs(m.balance)}</b><button class="btn" data-act="tab" data-v="wallet">Withdraw →</button></div></div>
<div class="g3">${[['Today', rs(today)], ['Lifetime', rs(m.totalEarned)], ['Tasks done', m.tasksDone]].map(([l, v]) => `<div class="card st c" style="margin:0"><b>${v}</b><small>${l}</small></div>`).join('')}</div>
<div class="ban p" data-act="tab" data-v="refer" style="margin-top:12px"><div><b>Refer &amp; Earn</b><small>Get ${S.cfg.refPercent}% bonus</small></div><span class="big2">👥</span></div>
<h3>Quick Access</h3><div class="g3">${T.map(([v, i, l, c, f]) => `<button class="tile" style="background:linear-gradient(160deg,${c})" data-act="go" data-v="${v}" data-f="${f || 'All'}"><span>${i}</span>${l}</button>`).join('')}</div>
<h3>Recent activity</h3>${list(S.tx.slice(0, 5))}`;
  },
  tasks() {
    const F = ['All', 'App', 'Video', 'Survey', 'Social', 'Other'];
    return head('Tasks') + `<div class="ban p"><div><b>Complete Tasks &amp; Earn Money</b><small>Credited after server verification</small></div><span class="big2">🎁</span></div><div class="chips">${F.map(f => `<button class="chip ${S.filter === f ? 'on' : ''}" data-act="filter" data-v="${f}">${f}</button>`).join('')}</div>${taskList(S.tasks.filter(t => t.type !== 'Game' && (S.filter === 'All' || t.type === S.filter)))}`;
  },
  games: () => head('Games', 'home') + `<div class="ban"><div><b>Play Games &amp; Earn</b><small>Have fun, win rewards</small></div><span class="big2">🎮</span></div>${taskList(S.tasks.filter(t => t.type === 'Game'))}`,
  rewards() {
    const m = S.me, d = pkDay(), P = prizes(), bd = m.lastBonus === d, sd = m.lastSpin === d, cd = m.lastScratch === d;
    return head('Rewards') + `<div class="card c"><h2>Daily Bonus</h2><b class="gold">${rs(S.cfg.dailyBonus)}</b><button class="btn" data-act="bonus" ${bd ? 'disabled' : ''}>${bd ? 'Claimed today' : 'Claim now'}</button></div>
<div class="card c"><h2>Spin &amp; Win</h2><div class="ptr">▼</div>${wheel(P)}<button class="btn" data-act="spin" ${sd ? 'disabled' : ''}>${sd ? 'Spun today' : 'Spin now'}</button><p class="sm">Possible prizes: ${P.map(rs).join(' • ')}. One spin a day, picked by the server.</p></div>
<div class="card c"><h2>Scratch Card</h2><div class="scr ${S.scr != null ? 'open' : ''}">${S.scr != null ? rs(S.scr) : cd ? '✓' : '?'}</div><button class="btn" data-act="scratch" ${cd ? 'disabled' : ''}>${cd ? 'Scratched today' : 'Scratch now'}</button></div>`;
  },
  refer() {
    const m = S.me, l = esc(refLink());
    return head('Refer & Earn') + `<div class="ban"><div><b>Invite Friends</b><small>Get ${S.cfg.refPercent}% bonus</small></div><span class="big2">🤝</span></div><div class="card"><small>Your referral link</small><div class="row"><code>${l}</code><button class="btn sm2" data-act="copy" data-v="${l}">Copy</button></div></div>
<div class="card"><b>Share via</b><div class="g4">${[['wa', '💬', 'WhatsApp'], ['tg', '✈️', 'Telegram'], ['fb', '📘', 'Facebook'], ['more', '•••', 'More']].map(([k, i, n]) => `<button class="qa" data-act="share" data-v="${k}"><span>${i}</span>${n}</button>`).join('')}</div></div>
<div class="g2"><div class="card st"><b>${m.refCount}</b><small>Friends joined</small></div><div class="card st"><b>${rs(m.refEarned)}</b><small>Referral earnings</small></div></div>
<h3>How it works</h3><div class="card">1. Share your link<br>2. Friends join and earn<br>3. You get ${S.cfg.refPercent}% of their rewards</div>`;
  },
  wallet() {
    const m = S.me, M = [['easypaisa', 'Easypaisa', '🟢'], ['jazzcash', 'JazzCash', '🔴'], ['bank', 'Bank Transfer', '🏦']];
    return head('Withdraw', 'home') + `<div class="ban p"><div><small>Your verified balance</small><b class="bigb">${rs(m.balance)}</b><small>Pending ${rs(m.pending)} • Paid ${rs(m.totalWithdrawn)}</small></div><span class="big2">👛</span></div>
<form id="wf"><h3>Select method</h3>${M.map(([k, l, i], n) => `<label class="card opt row"><span>${i} ${l}</span><input type="radio" name="method" value="${k}" ${n ? '' : 'checked'}></label>`).join('')}
<h3>Account number</h3><input name="account" placeholder="03XXXXXXXXX or IBAN" required><h3>Enter amount</h3><input name="amount" type="number" min="${S.cfg.minWithdraw}" step="1" placeholder="Minimum ${rs(S.cfg.minWithdraw)}" required><div class="chips">${[500, 1000, 2000, 5000].map(v => `<button type="button" class="chip" data-act="amt" data-v="${v}">${rs(v)}</button>`).join('')}</div><button class="btn">Request withdraw</button><p class="sm">Reviewed and paid manually. The amount is held until a decision; rejected requests are refunded.</p></form>
<h3>Withdrawals</h3>${S.wd.length ? S.wd.map(w => `<div class="card row"><span>${esc(w.method)} • ${esc(w.account)}<small>${esc(w.note || '')}</small></span><span class="r"><b>${rs(w.amount)}</b><i class="st-${w.status}">${w.status}</i></span></div>`).join('') : '<p class="sm c">No withdrawals yet.</p>'}`;
  },
  history: () => head('Transaction History', 'me') + list(S.tx),
  me() {
    const m = S.me, M = [['wallet', '💳', 'My Wallet'], ['history', '💰', 'My Earnings'], ['history', '🧾', 'Transaction History'], ['refer', '👥', 'My Referrals'], ['settings', '⚙️', 'Account Settings']];
    return `<div class="top c"><div class="avatar">${esc(m.name[0] || '?')}</div><h1>${esc(m.name)}</h1><p>${m.vip ? 'Premium User ✔' : 'Member'} • ${esc(m.email)}</p></div><div class="card menu">${M.map(([v, i, l]) => `<button data-act="tab" data-v="${v}">${i} ${l}</button>`).join('')}${S.cfg.supportEmail ? `<a href="mailto:${esc(S.cfg.supportEmail)}">💬 Help &amp; Support</a>` : ''}<button data-act="out">🚪 Logout</button></div>`;
  },
  settings: () => head('Settings', 'me') + `<div class="card menu"><div class="row"><span>🌙 Dark Mode</span><label class="sw"><input type="checkbox" data-act="theme" ${document.documentElement.dataset.theme === 'dark' ? 'checked' : ''}><i></i></label></div>${installEv ? '<button data-act="install">📲 Install app</button>' : ''}<button data-act="share" data-v="more">🔗 Share App</button>${S.cfg.supportEmail ? `<a href="mailto:${esc(S.cfg.supportEmail)}">💬 Contact Us</a>` : ''}<button data-act="out">🚪 Logout</button></div>`
};
const splash = () => '<div class="splash"><div class="crown">👑</div><h1>Earn Max PK</h1><p>Earn More • Live Better</p><div class="gift">🎁</div><p>Play • Earn • Withdraw<br>Without Any Investment</p><div class="bar"><span></span></div></div>';
const authView = () => `<div class="top c"><div class="crown">👑</div><h1>Earn Max PK</h1><p>Earn More • Live Better</p></div><form class="card" id="af">${S.mode === 'up' ? '<input name="name" placeholder="Full name" required maxlength="40">' : ''}<input name="email" type="email" placeholder="Email" required><input name="pw" type="password" placeholder="Password (6+ characters)" minlength="6" required>${S.mode === 'up' ? `<input name="ref" placeholder="Referral code (optional)" value="${esc(S.ref)}">` : ''}<button class="btn">${S.mode === 'up' ? 'Create account' : 'Sign in'}</button><p class="sm c" data-act="mode">${S.mode === 'up' ? 'Have an account? Sign in' : 'New here? Create an account'}</p></form><p class="sm c">Every balance shown is verified by the server. There are no demo balances.</p>`;
const nav = () => `<nav>${[['home', '🏠', 'Home'], ['tasks', '✅', 'Tasks'], ['rewards', '🎁', 'Rewards'], ['refer', '👥', 'Refer'], ['me', '👤', 'Profile']].map(([k, i, l]) => `<button class="${S.tab === k ? 'on' : ''}" data-act="tab" data-v="${k}"><span>${i}</span>${l}</button>`).join('')}</nav>`;

function render() {
  if (S.splash) return app.innerHTML = splash();
  if (S.busy || document.activeElement?.matches('input,select')) return; // keep animations and forms intact
  if (!auth.currentUser) return app.innerHTML = authView();
  if (!S.me) return app.innerHTML = '<div class="top"><h1>👑 Earn Max PK</h1><p>Loading your account…</p></div>';
  app.innerHTML = V[S.tab]() + nav();
}

const act = {
  tab: v => { S.tab = v; S.filter = 'All'; scrollTo(0, 0); },
  go: (v, b) => { S.tab = v; S.filter = b.dataset.f; scrollTo(0, 0); },
  filter: v => { S.filter = v; },
  mode: () => { S.mode = S.mode === 'up' ? 'in' : 'up'; },
  start: async id => { const t = S.tasks.find(x => x.id === id), r = await api('start', { id }); S.started[id] = Date.now() + r.wait * 1000; if (t.url) open(t.url, '_blank', 'noopener'); },
  claim: async id => { const r = await api('claim', { id }); delete S.started[id]; toast('+' + rs(r.reward) + ' added to your balance'); },
  bonus: async () => { await api('bonus'); toast('Daily bonus added'); },
  spin: async () => {
    S.busy = true;
    try {
      const r = await api('spin'), seg = 360 / prizes().length, w = $('#wh');
      S.rot = (Math.floor(S.rot / 360) + 6) * 360 - (r.index + .5) * seg;
      w.style.transition = 'transform 3.5s cubic-bezier(.2,.8,.2,1)'; w.style.transform = `rotate(${S.rot}deg)`;
      await new Promise(f => setTimeout(f, 3700));
      toast(r.prize ? `You won ${rs(r.prize)}` : 'No prize this time. Try again tomorrow');
    } finally { S.busy = false; }
  },
  scratch: async () => { const r = await api('scratch'); S.scr = r.prize; toast(r.prize ? `You won ${rs(r.prize)}` : 'No prize this time. Try again tomorrow'); },
  amt: v => { document.querySelector('[name=amount]').value = v; return false; },
  copy: async v => { await navigator.clipboard.writeText(v); toast('Link copied'); return false; },
  share: v => { const l = refLink(), t = 'Join me on Earn Max PK: ' + l; ({ wa: () => open('https://wa.me/?text=' + encodeURIComponent(t)), tg: () => open('https://t.me/share/url?url=' + encodeURIComponent(l) + '&text=' + encodeURIComponent('Join me on Earn Max PK')), fb: () => open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(l)), more: () => navigator.share ? navigator.share({ text: t }) : navigator.clipboard.writeText(t).then(() => toast('Link copied')) })[v](); return false; },
  theme: () => { const d = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = d; localStorage.theme = d; return false; },
  install: () => installEv.prompt(),
  out: () => signOut(auth)
};
app.addEventListener('click', async e => {
  const b = e.target.closest('[data-act]'); if (!b) return; let keep;
  try { keep = await act[b.dataset.act](b.dataset.id || b.dataset.v, b); } catch (x) { toast(x.message); }
  if (keep !== false) render();
});
app.addEventListener('submit', async e => {
  e.preventDefault(); document.activeElement.blur();
  const f = Object.fromEntries(new FormData(e.target)), btn = e.target.querySelector('.btn'); btn.disabled = true;
  try {
    if (e.target.id === 'af') { S.name = f.name; S.ref = f.ref || S.ref; await (S.mode === 'up' ? createUserWithEmailAndPassword : signInWithEmailAndPassword)(auth, f.email, f.pw); }
    else { await api('withdraw', f); toast('Withdrawal requested'); e.target.reset(); }
  } catch (x) { toast(x.code?.startsWith('auth/') ? 'Check your email and password, then try again' : x.message); }
  btn.disabled = false;
});
setInterval(() => document.querySelectorAll('[data-until]').forEach(b => { const s = Math.ceil((b.dataset.until - Date.now()) / 1000); b.textContent = s > 0 ? s + 's' : 'Claim'; b.disabled = s > 0; }), 500);
addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEv = e; });
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js');
setTimeout(() => { S.splash = false; render(); }, 1500);
render();
