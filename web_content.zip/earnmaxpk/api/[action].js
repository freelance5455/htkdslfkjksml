// Vercel serverless function: every money movement happens here, with the Admin SDK.
const admin = require('firebase-admin');
if (!admin.apps.length) admin.initializeApp({ credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
const db = admin.firestore(), FV = admin.firestore.FieldValue, inc = FV.increment;
const day = () => new Date(Date.now() + 5 * 36e5).toISOString().slice(0, 10); // Pakistan date
const fail = (m, c = 400) => { const e = new Error(m); e.user = true; e.code = c; throw e; };
const now = () => FV.serverTimestamp();

module.exports = async (req, res) => {
  try {
    if (req.method !== 'POST') fail('POST only', 405);
    let u;
    try { u = await admin.auth().verifyIdToken((req.headers.authorization || '').slice(7)); } catch { fail('Please sign in again', 401); }
    const a = req.query.action, b = req.body || {}, uid = u.uid, uRef = db.doc(`users/${uid}`);
    const cfg = { minWithdraw: 500, refPercent: 10, dailyBonus: 5, ...((await db.doc('settings/app').get()).data() || {}) };

    const pay = (tx, to, amt, note, extra = {}) => {
      tx.set(db.doc(`users/${to}`), { balance: inc(amt), totalEarned: inc(amt), ...extra }, { merge: true });
      tx.set(db.collection('transactions').doc(), { uid: to, amount: amt, note, createdAt: now() });
    };
    // One reward per completion key (duplicate-proof), optional minimum-wait gate, referral commission.
    const award = (key, amt, note, extra, gate) => db.runTransaction(async tx => {
      const cRef = db.doc(`completions/${key}`);
      const [us, cs, gs] = await Promise.all([tx.get(uRef), tx.get(cRef), gate ? tx.get(gate.ref) : null]);
      if (!us.exists) fail('Account not ready, reload the app');
      if (cs.exists) fail('Already claimed');
      if (gate && (!gs.exists || Date.now() - gs.data().at < gate.wait * 1000)) fail('Finish the task first, then claim');
      tx.set(cRef, { uid, at: now() });
      if (gate) tx.delete(gate.ref);
      pay(tx, uid, amt, note, extra);
      const r = us.data().refUid, c = Math.round(amt * cfg.refPercent) / 100;
      if (r && c > 0) pay(tx, r, c, 'Referral commission', { refEarned: inc(c) });
    });

    if (a === 'init') {
      const s = await uRef.get();
      if (s.exists) { await uRef.update({ lastSeen: Date.now() }); return res.json({ ok: true }); }
      let refUid = null;
      if (b.ref) {
        const q = await db.collection('users').where('refCode', '==', String(b.ref).toUpperCase()).limit(1).get();
        if (!q.empty && q.docs[0].id !== uid) refUid = q.docs[0].id;
      }
      const batch = db.batch();
      batch.create(uRef, { name: String(b.name || 'Member').slice(0, 40), email: u.email || '', refCode: uid.slice(0, 6).toUpperCase(), refUid, balance: 0, pending: 0, totalEarned: 0, totalWithdrawn: 0, tasksDone: 0, refCount: 0, refEarned: 0, lastSeen: Date.now(), createdAt: now() });
      if (refUid) batch.update(db.doc(`users/${refUid}`), { refCount: inc(1) });
      await batch.commit();
      return res.json({ ok: true });
    }
    if (a === 'start' || a === 'claim') {
      const t = (await db.doc(`tasks/${b.id}`).get()).data();
      if (!t || !t.active) fail('Task unavailable', 404);
      const sRef = db.doc(`starts/${uid}_${b.id}`), wait = t.minSeconds || 15;
      if (a === 'start') { await sRef.set({ at: Date.now() }); return res.json({ ok: true, wait }); }
      await award(`${uid}_${b.id}_${t.repeat === 'daily' ? day() : 'once'}`, Number(t.reward), `Task: ${t.title}`, { tasksDone: inc(1) }, { ref: sRef, wait });
      return res.json({ ok: true, reward: t.reward });
    }
    if (a === 'bonus') {
      await award(`${uid}_bonus_${day()}`, cfg.dailyBonus, 'Daily bonus', { lastBonus: day() });
      return res.json({ ok: true });
    }
    if (a === 'spin' || a === 'scratch') { // server-side random prize, once per day each
      const P = String(cfg.prizes ?? '0,1,2,5,10').split(',').map(Number).filter(n => n >= 0 && n <= 1000);
      if (!P.length) fail('Not available right now');
      const index = require('crypto').randomInt(P.length), prize = P[index];
      await award(`${uid}_${a}_${day()}`, prize, a === 'spin' ? 'Spin & Win' : 'Scratch card', { [a === 'spin' ? 'lastSpin' : 'lastScratch']: day() });
      return res.json({ ok: true, index, prize });
    }
    if (a === 'withdraw') {
      const amount = Math.round(Number(b.amount) * 100) / 100, m = b.method, acct = String(b.account || '').replace(/[\s-]/g, '');
      if (!['easypaisa', 'jazzcash', 'bank'].includes(m)) fail('Choose a payment method');
      if (!(amount >= cfg.minWithdraw)) fail(`Minimum withdrawal is Rs ${cfg.minWithdraw}`);
      if (m === 'bank' ? acct.length < 10 : !/^03\d{9}$/.test(acct)) fail(m === 'bank' ? 'Enter your IBAN or account number' : 'Enter an 11-digit number starting with 03');
      await db.runTransaction(async tx => {
        const s = await tx.get(uRef);
        if (!s.exists || s.data().balance < amount) fail('Not enough verified balance');
        tx.update(uRef, { balance: inc(-amount), pending: inc(amount) });
        tx.set(db.collection('withdrawals').doc(), { uid, name: s.data().name, method: m, account: acct, amount, status: 'pending', createdAt: now() });
        tx.set(db.collection('transactions').doc(), { uid, amount: -amount, note: `Withdrawal requested (${m})`, createdAt: now() });
      });
      return res.json({ ok: true });
    }
    if (a === 'review') {
      if (!u.admin) fail('Admins only', 403);
      await db.runTransaction(async tx => {
        const wRef = db.doc(`withdrawals/${b.id}`), w = await tx.get(wRef);
        if (!w.exists || w.data().status !== 'pending') fail('Already processed');
        const { uid: to, amount } = w.data(), ok = b.approve === true;
        tx.update(wRef, { status: ok ? 'paid' : 'rejected', note: String(b.note || '').slice(0, 200), reviewedAt: now() });
        tx.update(db.doc(`users/${to}`), ok ? { pending: inc(-amount), totalWithdrawn: inc(amount) } : { pending: inc(-amount), balance: inc(amount) });
        if (!ok) tx.set(db.collection('transactions').doc(), { uid: to, amount, note: 'Withdrawal rejected, amount refunded', createdAt: now() });
      });
      return res.json({ ok: true });
    }
    fail('Unknown action', 404);
  } catch (e) { res.status(e.code || 500).json({ error: e.user ? e.message : 'Server error' }); }
};
