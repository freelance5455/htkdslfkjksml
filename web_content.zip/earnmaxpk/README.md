# Earn Max PK

Static PWA (`public/`) + one Vercel serverless function (`api/[action].js`) + Firebase Auth/Firestore.

## Setup
1. Firebase console: create a project, enable **Email/Password** auth and **Firestore**.
2. Paste your web app config into `public/firebase-config.js`.
3. Publish `firestore.rules` (Firestore > Rules, or `firebase deploy --only firestore:rules`).
4. Vercel: import this folder, add env var `FIREBASE_SERVICE_ACCOUNT` = the full service-account JSON (Project settings > Service accounts > Generate key). Never commit this key.
5. Open the site, create your own account, copy your UID from Firebase Auth, then grant admin once (locally, with the key saved as `key.json`):
   `node -e "const a=require('firebase-admin');a.initializeApp({credential:a.credential.cert(require('./key.json'))});a.auth().setCustomUserClaims('YOUR_UID',{admin:true}).then(()=>process.exit())"`
6. Sign in at `/admin.html`, set Settings, and add tasks.

## What is and isn't verified
- Balances change only inside the server function. Firestore rules block every client write to wallets, withdrawals and transactions.
- Duplicate rewards are blocked by a unique completion key per user/task (per day for daily tasks).
- The task timer only stops instant claims. It does not prove a user watched an ad or finished a survey. For real proof, have your ad/offer network call a server postback and credit from there instead of `claim`.
- Payouts are manual: send the money from your Easypaisa/JazzCash/bank account, then press Approve. Reject refunds the user automatically.
- You fund payouts. Only create tasks whose reward is below what the network pays you.

## Rewards, games and spin
- Games are tasks with type **Game** (add them in Admin > Tasks). Link each one to a real game page or partner.
- Spin & Win and Scratch use the prize list in Admin > Settings (default 0,1,2,5,10 PKR). The server picks the prize at random, once per day per user. Set prizes you can afford.
