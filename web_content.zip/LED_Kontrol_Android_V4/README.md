# LED Kontrol — Native BLE V4

Bu sürüm Web Bluetooth kullanmaz. Android’in **Yakındaki cihazlar** (BLUETOOTH_SCAN + BLUETOOTH_CONNECT) izinleri ve native BluetoothGatt kullanılır.

## Telefonda derleme
Android Studio şart değildir. Gradle tabanlı projeyi telefonda destekleyen bir Android IDE ile açabilirsiniz. AndroidIDE geçmişte bu iş için kullanılabiliyordu ancak proje artık arşivlenmiş/bakımı bırakılmıştır.

## Çalışma
1. Uygulamayı kurun.
2. Android ayarlarından uygulamaya **Yakındaki cihazlar** iznini verin.
3. Bluetooth’u açın.
4. Uygulamada Bağlan’a basın.
5. ELK-BLEDOM bulununca FFF0/FFF3 veya FFE5/FFE9 yazma kanalı seçilir.

Web Bluetooth / navigator.bluetooth bu sürümde bağlantı için kullanılmaz.
