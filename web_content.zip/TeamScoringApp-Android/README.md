# Team Scoring Android App

This is a native Android wrapper around the phone-friendly Team Scoring app.

## Build the APK in Android Studio

1. Install Android Studio from https://developer.android.com/studio
2. Open the `TeamScoringApp-Android` folder in Android Studio.
3. Allow Android Studio to install/sync the required Android SDK and Gradle components.
4. Select **Build > Build APK(s)**.
5. The debug APK will be created under:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer that APK to the Android phone and install it.

The app contains the scoring page locally, so it does not require an internet connection after installation.
