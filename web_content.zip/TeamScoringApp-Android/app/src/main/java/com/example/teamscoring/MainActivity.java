package com.example.teamscoring;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int CREATE_XLSX = 42;
    private WebView webView;
    private String pendingRowsJson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportXLSX(String rowsJson) {
            pendingRowsJson = rowsJson;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            intent.putExtra(Intent.EXTRA_TITLE, "team-scores.xlsx");
            startActivityForResult(intent, CREATE_XLSX);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_XLSX && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                writeWorkbook(data.getData(), pendingRowsJson == null ? "[]" : pendingRowsJson);
            } catch (Exception e) {
                webView.evaluateJavascript("alert('Could not create the Excel file: " + jsEscape(e.getMessage()) + "')", null);
            }
        }
    }

    private void writeWorkbook(Uri uri, String rowsJson) throws Exception {
        JSONArray rows = new JSONArray(rowsJson);
        int greenTotal = 0, whiteTotal = 0, redTotal = 0;
        StringBuilder results = new StringBuilder();
        results.append(sheetRow(new String[]{"Event","Heat","Green Position","Green Points","White Position","White Points","Red Position","Red Points"}));
        for (int i=0;i<rows.length();i++) {
            JSONObject r=rows.getJSONObject(i);
            int gp=r.optInt("greenPoints",0), wp=r.optInt("whitePoints",0), rp=r.optInt("redPoints",0);
            greenTotal+=gp; whiteTotal+=wp; redTotal+=rp;
            results.append(sheetRow(new String[]{String.valueOf(r.optInt("event")),String.valueOf(r.optInt("heat")),r.optString("green"),String.valueOf(gp),r.optString("white"),String.valueOf(wp),r.optString("red"),String.valueOf(rp)}));
        }
        StringBuilder summary=new StringBuilder();
        summary.append(sheetRow(new String[]{"Team","Total Points"}));
        summary.append(sheetRow(new String[]{"Green",String.valueOf(greenTotal)}));
        summary.append(sheetRow(new String[]{"White",String.valueOf(whiteTotal)}));
        summary.append(sheetRow(new String[]{"Red",String.valueOf(redTotal)}));
        String workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Results\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"Summary\" sheetId=\"2\" r:id=\"rId2\"/></sheets></workbook>";
        String rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/></Relationships>";
        String rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";
        String types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>";
        try (OutputStream os=getContentResolver().openOutputStream(uri); ZipOutputStream zip=new ZipOutputStream(os)) {
            put(zip,"[Content_Types].xml",types); put(zip,"_rels/.rels",rootRels); put(zip,"xl/workbook.xml",workbook); put(zip,"xl/_rels/workbook.xml.rels",rels);
            put(zip,"xl/worksheets/sheet1.xml",sheet(results.toString())); put(zip,"xl/worksheets/sheet2.xml",sheet(summary.toString()));
        }
        webView.evaluateJavascript("alert('Excel file exported successfully.')", null);
    }

    private static String sheet(String rows){return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"+rows+"</sheetData></worksheet>";}
    private static String sheetRow(String[] vals){StringBuilder b=new StringBuilder("<row>");for(String v:vals){if(v.matches("-?\\d+(\\.\\d+)?")) b.append("<c><v>").append(v).append("</v></c>"); else b.append("<c t=\"inlineStr\"><is><t>").append(xml(v)).append("</t></is></c>");}return b.append("</row>").toString();}
    private static String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private static String jsEscape(String s){if(s==null)return "Unknown error";return s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");}
    private static void put(ZipOutputStream zip,String name,String content)throws Exception{zip.putNextEntry(new ZipEntry(name));zip.write(content.getBytes(StandardCharsets.UTF_8));zip.closeEntry();}

    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
