DhruvMovies - LocalStream direct-play setup

1. Start LocalStream File & Server on the same local network.
2. Find the exact direct URL of an authorized video file.
3. Open app/src/main/assets/index.html.
4. Set LOCAL_STREAM_VIDEO_URL to that exact direct video URL.
5. Build and install the APK.
6. Press PLAY; the app will load that configured source directly.

This build does not use the public Flower demo video and does not include a local-file picker.
The configured source must be a video you are authorized to stream.
