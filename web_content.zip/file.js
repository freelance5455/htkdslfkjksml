window.FileHandler = {
    isProcessing: false,

    init() {
        const fileInput = document.getElementById('file-input');
        const chooseBtn = document.getElementById('choose-button');
        const dropZone = document.getElementById('drop-zone');

        if (!fileInput) return;

        const openPicker = (e) => {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            if (this.isProcessing) return;
            fileInput.click();
        };

        if (chooseBtn) chooseBtn.onclick = openPicker;

        if (dropZone) {
            dropZone.onclick = (e) => {
                if (e.target !== chooseBtn && !chooseBtn.contains(e.target)) {
                    openPicker(e);
                }
            };
        }

        fileInput.onchange = (e) => {
            if (e.target.files && e.target.files.length > 0) {
                const selected = e.target.files[0];
                fileInput.value = '';
                this.processSelectedFile(selected);
            }
        };
    },

    async processSelectedFile(file) {
        if (!file || this.isProcessing) return;

        this.isProcessing = true;

        try {
            AppState.reset();
            if (window.UI) {
                UI.resetView();
                UI.log(`تم اختيار الملف: ${file.name}`, 'info');
                UI.updateProgress(10, 'جاري معالجة وتهيئة الملف...');
            }

            AppState.file = file;
            await new Promise(r => setTimeout(r, 80));

            const buffer = await file.arrayBuffer();
            AppState.fileBuffer = buffer;

            if (window.UI) UI.updateProgress(30, 'جاري حساب الهاش SHA-256...');

            const hash = await Utils.calculateSHA256(buffer);
            AppState.hashHex = hash;

            if (window.UI) {
                UI.showFileInfo(file.name, file.size, hash);
                UI.updateProgress(40, 'تمت القراءة المبدئية، جاري إرسال الحزمة للتحليل...');
            }

            await new Promise(r => setTimeout(r, 80));

            if (window.App && typeof window.App.startAnalysis === 'function') {
                await window.App.startAnalysis();
            }

        } catch (error) {
            console.error(error);
            if (window.UI) {
                UI.log(`خطأ غير متوقع: ${error.message}`, 'error');
                UI.hideProgress();
            }
            alert('حدث خطأ أثناء معالجة الملف: ' + error.message);
        } finally {
            this.isProcessing = false;
        }
    }
};
