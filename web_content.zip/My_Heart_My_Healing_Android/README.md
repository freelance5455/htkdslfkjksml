# My Heart, My Healing — Android project

This ZIP contains the finished notebook packaged as a simple Android WebView app project.

## What is included
- `app/src/main/assets/index.html` — the complete notebook interface and its built-in journal.
- `MainActivity.java` — opens the notebook inside an Android app.
- Android Gradle project files.

## Build an APK with Android Studio
1. Extract this ZIP on a computer.
2. Open Android Studio.
3. Choose **Open** and select the extracted `My_Heart_My_Healing_Android` folder.
4. Allow Gradle sync to finish. Android Studio may ask to install Android SDK Platform 35 and a compatible build-tools version.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, use the APK link shown by Android Studio. The usual output location is `app/build/outputs/apk/debug/app-debug.apk`.

## Important notes
- This is the Android Studio source project, not a prebuilt APK.
- The app works offline because the notebook HTML is bundled inside it.
- Journal entries are stored locally by the WebView on that device. They are not encrypted. Avoid saving passwords or highly sensitive information.
- Use the notebook's **Export my backup** button before clearing app data or uninstalling; uninstalling may remove locally stored entries.
- No internet permission is requested by this project.
