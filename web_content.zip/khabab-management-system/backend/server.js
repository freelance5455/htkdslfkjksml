require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const admin = require('firebase-admin');

if (!admin.apps.length) admin.initializeApp({ credential: admin.credential.applicationDefault() });
const db = admin.firestore();
const auth = admin.auth();
const app = express();
app.use(helmet());
app.use(express.json({ limit: '32kb' }));
// Serve the responsive frontend from the same origin.
app.use(express.static(path.join(__dirname, '../public')));
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000').split(',').map(s => s.trim());
app.use(cors({ origin(origin, cb) { if (!origin || allowedOrigins.includes(origin)) return cb(null, true); return cb(new Error('Origin not allowed')); } }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));

const ROLES = ['CEO', 'MANAGER', 'EMPLOYEE'];
const clean = value => String(value ?? '').trim();
const num = value => Number.isFinite(Number(value)) ? Number(value) : null;
const fail = (res, status, error) => res.status(status).json({ error });

async function requireAuth(req, res, next) {
  try {
    const h = req.headers.authorization || '';
    if (!h.startsWith('Bearer ')) return fail(res, 401, 'Sign in required');
    const decoded = await auth.verifyIdToken(h.slice(7));
    const snap = await db.collection('users').doc(decoded.uid).get();
    if (!snap.exists || snap.data().active === false) return fail(res, 403, 'Account is inactive or not provisioned');
    req.user = { uid: decoded.uid, ...snap.data() };
    next();
  } catch (e) { return fail(res, 401, 'Invalid or expired login token'); }
}
function allow(...roles) { return (req, res, next) => req.user && roles.includes(req.user.role) ? next() : fail(res, 403, 'Not permitted for this role'); }
async function audit(req, action, target, extra = {}) {
  await db.collection('auditLogs').add({ actorUid: req.user.uid, actorRole: req.user.role, action, target, extra, createdAt: admin.firestore.FieldValue.serverTimestamp() });
}
function distanceMeters(aLat, aLng, bLat, bLng) {
  const rad = n => n * Math.PI / 180; const R = 6371000;
  const dLat = rad(bLat - aLat), dLng = rad(bLng - aLng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(aLat)) * Math.cos(rad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}
async function getUser(uid) { const s = await db.collection('users').doc(uid).get(); return s.exists ? { uid: s.id, ...s.data() } : null; }
async function canSeeBranch(req, branchId) {
  if (req.user.role === 'CEO') return true;
  if (req.user.role === 'MANAGER') return req.user.branchId === branchId;
  return req.user.branchId === branchId;
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'Khabab & K O API' }));
app.get('/api/me', requireAuth, (req, res) => res.json({ uid: req.user.uid, name: req.user.name, email: req.user.email, role: req.user.role, branchId: req.user.branchId || null, active: req.user.active !== false }));

// CEOs provision staff through Firebase Auth and the protected API; public signup is intentionally disabled.
app.post('/api/users', requireAuth, allow('CEO'), async (req, res) => {
  try {
    const { name, email, password, role, branchId, managerUid = null, monthlySalary = 0 } = req.body || {};
    if (!clean(name) || !clean(email) || typeof password !== 'string' || password.length < 12 || !ROLES.includes(role)) return fail(res, 400, 'Provide name, email, password (12+ chars), and valid role');
    if (role !== 'CEO' && !clean(branchId)) return fail(res, 400, 'Branch is required for managers and employees');
    if (role === 'EMPLOYEE') {
      if (!managerUid) return fail(res, 400, 'Employee must have a manager');
      const manager = await getUser(managerUid);
      if (!manager || manager.role !== 'MANAGER' || manager.active === false || manager.branchId !== branchId) return fail(res, 400, 'Manager must be active and assigned to the same branch');
      const team = await db.collection('users').where('managerUid', '==', managerUid).get();
      if (team.docs.filter(d => d.data().active !== false).length >= 10) return fail(res, 409, 'This manager already has 10 active employees');
    }
    if (role === 'MANAGER') {
      const managers = await db.collection('users').where('role', '==', 'MANAGER').get();
      if (managers.docs.filter(d => d.data().active !== false).length >= 500) return fail(res, 409, 'Manager capacity (500) reached');
    }
    if (role === 'CEO') {
      const ceos = await db.collection('users').where('role', '==', 'CEO').get();
      if (ceos.docs.filter(d => d.data().active !== false).length >= 2) return fail(res, 409, 'CEO capacity (2) reached');
    }
    const branch = role === 'CEO' ? null : await db.collection('branches').doc(branchId).get();
    if (role !== 'CEO' && (!branch.exists || branch.data().active === false)) return fail(res, 400, 'Branch does not exist or is inactive');
    const userRecord = await auth.createUser({ email: clean(email).toLowerCase(), password, displayName: clean(name), disabled: false });
    const data = { name: clean(name), email: clean(email).toLowerCase(), role, branchId: role === 'CEO' ? null : branchId, managerUid: role === 'EMPLOYEE' ? managerUid : null, monthlySalary: role === 'EMPLOYEE' ? Math.max(0, num(monthlySalary) || 0) : 0, active: true, createdAt: admin.firestore.FieldValue.serverTimestamp(), createdBy: req.user.uid };
    try { await db.collection('users').doc(userRecord.uid).set(data); } catch (e) { await auth.deleteUser(userRecord.uid); throw e; }
    await audit(req, 'USER_CREATED', userRecord.uid, { role, branchId: data.branchId });
    res.status(201).json({ uid: userRecord.uid, ...data, createdAt: undefined });
  } catch (e) { if (e.code === 'auth/email-already-exists') return fail(res, 409, 'Email already exists'); console.error(e); return fail(res, 500, 'Could not create account'); }
});

app.get('/api/dashboard', requireAuth, async (req, res) => {
  try {
    const [usersSnap, branchesSnap, tasksSnap, todaySnap] = await Promise.all([
      req.user.role === 'CEO' ? db.collection('users').get() : db.collection('users').where('branchId', '==', req.user.branchId).get(),
      req.user.role === 'CEO' ? db.collection('branches').get() : db.collection('branches').where(admin.firestore.FieldPath.documentId(), '==', req.user.branchId || '__none__').get(),
      req.user.role === 'CEO' ? db.collection('tasks').get() : db.collection('tasks').where('branchId', '==', req.user.branchId || '__none__').get(),
      db.collection('attendance').where('dateKey', '==', new Date().toISOString().slice(0, 10)).get()
    ]);
    const people = usersSnap.docs.map(d => d.data());
    const branches = branchesSnap.docs.map(d => ({ id: d.id, name: d.data().name, code: d.data().code, active: d.data().active !== false }));
    const tasks = tasksSnap.docs.map(d => d.data());
    const attendance = todaySnap.docs.filter(d => req.user.role === 'CEO' || d.data().branchId === req.user.branchId);
    res.json({ totals: { employees: people.filter(u => u.role === 'EMPLOYEE' && u.active !== false).length, managers: people.filter(u => u.role === 'MANAGER' && u.active !== false).length, ceos: req.user.role === 'CEO' ? people.filter(u => u.role === 'CEO' && u.active !== false).length : undefined, branches: branches.filter(b => b.active).length, checkedInToday: attendance.filter(d => d.data().status === 'PRESENT').length, openTasks: tasks.filter(t => t.status !== 'COMPLETED').length }, branches, recentTasks: tasks.slice(0, 8).map(t => ({ title: t.title, status: t.status, priority: t.priority })) });
  } catch (e) { console.error(e); fail(res, 500, 'Could not load dashboard'); }
});

app.get('/api/branches', requireAuth, async (req, res) => {
  const snap = req.user.role === 'CEO' ? await db.collection('branches').get() : await db.collection('branches').where(admin.firestore.FieldPath.documentId(), '==', req.user.branchId || '__none__').get();
  res.json(snap.docs.map(d => ({ id: d.id, ...d.data(), geofence: undefined })));
});
app.post('/api/branches', requireAuth, allow('CEO'), async (req, res) => {
  const { name, code, city, latitude, longitude, radiusMeters = 150, managerUid = null } = req.body || {};
  const lat = num(latitude), lng = num(longitude), radius = num(radiusMeters);
  if (!clean(name) || !clean(code) || !clean(city) || lat === null || lng === null || lat < -90 || lat > 90 || lng < -180 || lng > 180 || radius === null || radius < 30 || radius > 1000) return fail(res, 400, 'Provide name, unique code, city, valid GPS coordinates, and a 30–1000m radius');
  if (managerUid) { const m = await getUser(managerUid); if (!m || m.role !== 'MANAGER') return fail(res, 400, 'Manager UID must belong to a manager'); }
  const codeSnap = await db.collection('branches').where('code', '==', clean(code).toUpperCase()).get();
  if (!codeSnap.empty) return fail(res, 409, 'Branch code already exists');
  const ref = await db.collection('branches').add({ name: clean(name), code: clean(code).toUpperCase(), city: clean(city), latitude: lat, longitude: lng, radiusMeters: radius, managerUid, active: true, createdAt: admin.firestore.FieldValue.serverTimestamp(), createdBy: req.user.uid });
  await audit(req, 'BRANCH_CREATED', ref.id, { code }); res.status(201).json({ id: ref.id, name, code: clean(code).toUpperCase(), city });
});

app.post('/api/attendance/check-in', requireAuth, allow('EMPLOYEE'), async (req, res) => {
  try {
    const lat = num(req.body?.latitude), lng = num(req.body?.longitude);
    if (lat === null || lng === null || lat < -90 || lat > 90 || lng < -180 || lng > 180) return fail(res, 400, 'Valid device coordinates required');
    if (!req.user.branchId) return fail(res, 400, 'No branch assigned');
    const branchSnap = await db.collection('branches').doc(req.user.branchId).get();
    if (!branchSnap.exists || branchSnap.data().active === false) return fail(res, 400, 'Assigned branch unavailable');
    const b = branchSnap.data();
    const distance = distanceMeters(lat, lng, b.latitude, b.longitude);
    if (distance > b.radiusMeters) return res.status(403).json({ error: 'Outside branch geofence', distanceMeters: Math.round(distance), allowedRadiusMeters: b.radiusMeters });
    const dateKey = new Date().toISOString().slice(0, 10);
    const ref = db.collection('attendance').doc(`${req.user.uid}_${dateKey}`);
    const old = await ref.get(); if (old.exists && old.data().status === 'PRESENT') return fail(res, 409, 'Already checked in today');
    await ref.set({ uid: req.user.uid, employeeName: req.user.name, branchId: req.user.branchId, dateKey, status: 'PRESENT', checkInAt: admin.firestore.FieldValue.serverTimestamp(), checkInLocation: new admin.firestore.GeoPoint(lat, lng), distanceMeters: Math.round(distance), gpsAccuracyMeters: num(req.body?.accuracyMeters), method: 'EMPLOYEE_INITIATED_GPS' });
    await audit(req, 'ATTENDANCE_CHECK_IN', ref.id, { branchId: req.user.branchId, distanceMeters: Math.round(distance) });
    res.status(201).json({ ok: true, dateKey, distanceMeters: Math.round(distance), message: 'Check-in recorded. GPS can be spoofed; review suspicious activity.' });
  } catch (e) { console.error(e); fail(res, 500, 'Check-in failed'); }
});
app.post('/api/attendance/check-out', requireAuth, allow('EMPLOYEE'), async (req, res) => {
  const dateKey = new Date().toISOString().slice(0, 10); const ref = db.collection('attendance').doc(`${req.user.uid}_${dateKey}`); const snap = await ref.get();
  if (!snap.exists || snap.data().status !== 'PRESENT') return fail(res, 409, 'No active check-in found');
  if (snap.data().checkOutAt) return fail(res, 409, 'Already checked out');
  await ref.update({ checkOutAt: admin.firestore.FieldValue.serverTimestamp() }); await audit(req, 'ATTENDANCE_CHECK_OUT', ref.id); res.json({ ok: true, message: 'Check-out recorded' });
});
app.get('/api/attendance', requireAuth, async (req, res) => {
  let q = db.collection('attendance');
  if (req.user.role === 'EMPLOYEE') q = q.where('uid', '==', req.user.uid);
  else if (req.user.role === 'MANAGER') q = q.where('branchId', '==', req.user.branchId);
  if (req.query.date) q = q.where('dateKey', '==', clean(req.query.date));
  const snap = await q.limit(300).get(); res.json(snap.docs.map(d => ({ id: d.id, ...d.data(), checkInLocation: undefined })));
});

app.post('/api/tasks', requireAuth, allow('CEO', 'MANAGER'), async (req, res) => {
  const { title, branchId, assigneeUid = null, dueDate = null, priority = 'NORMAL' } = req.body || {};
  if (!clean(title) || !branchId || !['LOW', 'NORMAL', 'HIGH', 'URGENT'].includes(priority)) return fail(res, 400, 'Title, branch, and valid priority required');
  if (req.user.role === 'MANAGER' && branchId !== req.user.branchId) return fail(res, 403, 'Managers can only create tasks for their branch');
  const branch = await db.collection('branches').doc(branchId).get(); if (!branch.exists) return fail(res, 400, 'Branch not found');
  if (assigneeUid) { const assignee = await getUser(assigneeUid); if (!assignee || assignee.branchId !== branchId || assignee.active === false) return fail(res, 400, 'Assignee must be active and in this branch'); }
  const ref = await db.collection('tasks').add({ title: clean(title), branchId, assigneeUid, dueDate: dueDate || null, priority, status: 'OPEN', createdBy: req.user.uid, createdAt: admin.firestore.FieldValue.serverTimestamp(), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  await audit(req, 'TASK_CREATED', ref.id, { branchId }); res.status(201).json({ id: ref.id, title: clean(title), status: 'OPEN' });
});
app.get('/api/tasks', requireAuth, async (req, res) => {
  let q = db.collection('tasks');
  if (req.user.role === 'MANAGER') q = q.where('branchId', '==', req.user.branchId);
  if (req.user.role === 'EMPLOYEE') q = q.where('assigneeUid', '==', req.user.uid);
  const snap = await q.limit(300).get(); res.json(snap.docs.map(d => ({ id: d.id, ...d.data() })));
});
app.patch('/api/tasks/:id', requireAuth, async (req, res) => {
  const ref = db.collection('tasks').doc(req.params.id); const snap = await ref.get(); if (!snap.exists) return fail(res, 404, 'Task not found'); const task = snap.data();
  if (req.user.role === 'MANAGER' && task.branchId !== req.user.branchId) return fail(res, 403, 'Task belongs to another branch');
  if (req.user.role === 'EMPLOYEE' && task.assigneeUid !== req.user.uid) return fail(res, 403, 'Task is not assigned to you');
  const status = clean(req.body?.status).toUpperCase(); if (!['OPEN', 'IN_PROGRESS', 'COMPLETED'].includes(status)) return fail(res, 400, 'Invalid task status');
  await ref.update({ status, updatedAt: admin.firestore.FieldValue.serverTimestamp(), updatedBy: req.user.uid }); await audit(req, 'TASK_STATUS_UPDATED', ref.id, { status }); res.json({ ok: true, status });
});

// Payroll endpoints expose salary only to CEOs. They calculate a draft estimate, not statutory payroll.
app.get('/api/payroll/draft', requireAuth, allow('CEO'), async (req, res) => {
  const month = clean(req.query.month); if (!/^\d{4}-\d{2}$/.test(month)) return fail(res, 400, 'month must be YYYY-MM');
  const snap = await db.collection('users').where('role', '==', 'EMPLOYEE').get();
  const rows = snap.docs.map(d => ({ uid: d.id, name: d.data().name, branchId: d.data().branchId, monthlySalary: Math.max(0, num(d.data().monthlySalary) || 0), active: d.data().active !== false })).filter(u => u.active);
  res.json({ month, status: 'DRAFT_ESTIMATE', warning: 'Not an approved payroll or payslip. Configure attendance, overtime, statutory deductions, tax, and review before payment.', count: rows.length, grossEstimate: rows.reduce((s, u) => s + u.monthlySalary, 0), rows });
});
app.post('/api/payroll/approve', requireAuth, allow('CEO'), async (req, res) => {
  const { month, note = '' } = req.body || {}; if (!/^\d{4}-\d{2}$/.test(clean(month))) return fail(res, 400, 'month must be YYYY-MM');
  const ref = db.collection('payrollRuns').doc(clean(month)); const existing = await ref.get(); if (existing.exists && existing.data().status === 'APPROVED') return fail(res, 409, 'This month is already approved');
  await ref.set({ month: clean(month), status: 'APPROVED', note: clean(note).slice(0, 500), approvedBy: req.user.uid, approvedAt: admin.firestore.FieldValue.serverTimestamp(), warning: 'Approval records an internal workflow state only; it does not transfer funds or guarantee statutory compliance.' }); await audit(req, 'PAYROLL_DRAFT_APPROVED', month); res.json({ ok: true, status: 'APPROVED', message: 'Internal approval saved; no payment was initiated.' });
});

app.get('/api/reports/workforce', requireAuth, allow('CEO', 'MANAGER'), async (req, res) => {
  const snap = req.user.role === 'CEO' ? await db.collection('users').get() : await db.collection('users').where('branchId', '==', req.user.branchId).get();
  const users = snap.docs.map(d => d.data()).filter(u => u.active !== false);
  res.json({ employees: users.filter(u => u.role === 'EMPLOYEE').length, managers: users.filter(u => u.role === 'MANAGER').length });
});

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Unexpected server error' }); });
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Khabab & K O API listening on port ${port}`));
