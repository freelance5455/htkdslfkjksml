require('dotenv').config();
const admin = require('firebase-admin');
if (!admin.apps.length) admin.initializeApp({ credential: admin.credential.applicationDefault() });
const auth = admin.auth(); const db = admin.firestore();
async function main() {
  const seeds = [
    { email: process.env.CEO1_EMAIL, password: process.env.CEO1_TEMP_PASSWORD, name: 'CEO 1' },
    { email: process.env.CEO2_EMAIL, password: process.env.CEO2_TEMP_PASSWORD, name: 'CEO 2' }
  ];
  if (seeds.some(s => !s.email || !s.password || s.password.length < 12 || s.password.startsWith('replace-'))) throw new Error('Set both CEO emails and unique passwords (12+ chars) in .env first.');
  for (const s of seeds) {
    let user;
    try { user = await auth.getUserByEmail(s.email); }
    catch (e) { if (e.code !== 'auth/user-not-found') throw e; user = await auth.createUser({ email: s.email, password: s.password, displayName: s.name }); }
    await db.collection('users').doc(user.uid).set({ name: s.name, email: s.email.toLowerCase(), role: 'CEO', branchId: null, managerUid: null, monthlySalary: 0, active: true, createdAt: admin.firestore.FieldValue.serverTimestamp(), provisionedBy: 'one-time-seed-script' }, { merge: true });
    console.log(`CEO provisioned: ${s.email}. Require password reset/rotation before operational use.`);
  }
  console.log('Seed complete. Delete temporary passwords from .env and secure the account credentials.');
}
main().then(() => process.exit(0)).catch(e => { console.error(e.message); process.exit(1); });
