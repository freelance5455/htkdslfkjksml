# Khabab & K O Management System — starter

Includes responsive HTML/CSS/JavaScript frontend, Node.js/Express API, Firebase Authentication, Firestore, GPS geofence check-in/out, branches, tasks, dashboard counts, and CEO-only salary estimate/approval workflow.

## Important limitations
- This is a starter implementation, not a production-certified payroll or HR platform.
- GPS geofence is a useful check, not proof of physical presence; device coordinates can be spoofed. Use risk review and consider managed devices/attestation if needed.
- Payroll endpoint is an estimate from monthly salary only. It does not calculate Indian statutory deductions, tax, overtime, leave, or bank transfers.
- The dashboard reads Firestore documents and counts records in the queried collection. For 5,000 employees, use pagination and aggregated counters before large-scale production; Firestore queries have billing implications.
- Add stronger validation, automated tests, backups, monitoring, account recovery, rate limiting/WAF, audit retention policy, and security review before real data.

## File structure
```
public/index.html           Frontend, Firebase web sign-in, API calls
backend/server.js           Express API, Firebase Admin, role checks
backend/seed-ceos.js        One-time creation of two CEO accounts
firebase/firestore.rules    Deny direct client access; API uses Admin SDK
.env.example                Environment variable template
package.json                Node dependencies and commands
```

## Setup using an Android phone
You can edit files on Android, but Firebase Admin SDK needs a Node.js server that stays online. A browser-only HTML-to-APK builder cannot safely host the backend. Use a cloud Node host or a Node-capable Android terminal for testing; for real company use, deploy the API to a managed server and serve the frontend over HTTPS.

### A. Firebase project
1. Open https://console.firebase.google.com and create a project.
2. Enable Authentication → Sign-in method → Email/Password.
3. Create a Firestore database in production mode.
4. Add a Web App in Project settings; copy its `apiKey`, `authDomain`, `projectId`, and `appId` into `public/index.html` where the `REPLACE_...` values appear.
5. In Firestore Rules, publish `firebase/firestore.rules`. These rules deny all client direct reads/writes; the Express backend uses Admin SDK and performs authorization itself.
6. In Project settings → Service accounts, generate a private key JSON. Store it only as a server secret/file outside `public/`; never upload it into an APK or expose it in frontend code.

### B. Run the backend on a Node host
1. Upload this project to a private Git repository or your hosting provider's secure project area. Do not upload `.env` or `service-account.json` to a public repository.
2. Set the Node runtime to 20 or newer and run `npm install`.
3. Configure server environment variables using your host's secret manager. Set `GOOGLE_APPLICATION_CREDENTIALS` to the service-account file path if the host supports file secrets; alternatively adapt initialization to the host's workload identity. Set `ALLOWED_ORIGINS` to the exact HTTPS origin(s) of the frontend.
4. Start with `npm start`. Confirm `/api/health` returns `{ "ok": true, "service": "Khabab & K O API" }`.
5. The Express server already serves `public/index.html` from the same origin. Then `API = ''` uses same-origin requests. For a separate frontend host, set `API` to the backend HTTPS origin and update `ALLOWED_ORIGINS`.

### C. Bootstrap the two CEOs (one-time)
1. Set `CEO1_EMAIL`, `CEO2_EMAIL`, `CEO1_TEMP_PASSWORD`, `CEO2_TEMP_PASSWORD` in the server environment. Use unique random passwords of at least 12 characters.
2. Run `npm run seed-ceos` in the project environment once. Existing email accounts are reused and their CEO role record is merged.
3. Sign in using the web app and rotate temporary passwords. Remove temporary password values from the environment after seeding.
4. Do not expose a public signup endpoint. CEO accounts should be provisioned through this controlled process.

### D. Create records in this order
1. Sign in as a CEO.
2. Open Branches; create a branch using the branch's actual GPS coordinates and a suitable radius. Save the returned Branch ID.
3. Create a MANAGER account using that Branch ID; note the Firebase UID returned.
4. Create EMPLOYEE accounts with the same Branch ID and the manager's Firebase UID. The starter enforces a maximum of 10 active employees per manager and 500 managers / 2 CEOs.
5. Managers can create tasks for their own branch. Employees can view and update tasks assigned to their UID.
6. Employees check in/out with GPS. Check-in only succeeds inside the branch geofence.
7. CEOs can load a monthly salary estimate and record an internal approval. No payment is initiated.

## Hosting frontend on same server
The starter already serves the `public/` folder from Express. For a production static host, configure fallback to `index.html` and HTTPS.

## Android packaging
For easiest Android use, open the deployed HTTPS frontend in Chrome and choose menu → Add to Home screen / Install app (exact wording varies). This creates a home-screen web app. A true APK wrapper can be built later, but the backend must remain hosted online; never bundle the Firebase Admin service account into an APK.

## Security checklist before real launch
- Use HTTPS, managed secrets, password resets, and multi-factor authentication for CEOs.
- Add manager/employee read APIs with pagination and carefully scoped fields; never return salary to non-CEOs.
- Review the dashboard queries and add Firestore composite indexes if Firebase requests them.
- Add idempotency, rate limits, monitoring, backups, incident response, and automated authorization tests.
- Use an explicit payroll approval separation policy; one CEO approval is not a substitute for financial controls.
- Publish employee notice/consent for location processing, collect GPS only on employee action, set retention periods, and comply with applicable Indian privacy and employment laws.
