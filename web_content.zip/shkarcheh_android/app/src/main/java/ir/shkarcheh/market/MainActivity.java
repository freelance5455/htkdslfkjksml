package ir.shkarcheh.market;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);
  WebView w=new WebView(this); setContentView(w);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
  w.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){setResult(RESULT_CANCELED);super.onBackPressed();}
}