COLOR CODE CALCULATOR — SPCK EDITOR

How to use:
1. Extract Color_Code_Calculator.zip.
2. Open the extracted project folder in SPCK Editor, or create a project and copy index.html.
3. Open index.html and tap Preview.
4. Enter a HEX color such as #FF1493 and tap Calculate Color.

Features:
- Color preview
- HEX, RGB and HSL values
- CSS background-color snippet
- Copy buttons
- Supports 3-digit and 6-digit HEX codes
- Works offline; no API key or external library required

Note: The built-in color-name list includes common colors only. Other valid HEX values are shown as custom colors.
