# Vaulta (Android)

Proyecto de Android Studio que muestra la app Vaulta dentro de un WebView.
La app web está en `app/src/main/assets/index.html`.

## Probar en tu celular
1. Instala **Android Studio** (última versión estable): https://developer.android.com/studio
2. `File > Open` y elige la carpeta **Vaulta-Android** (la que contiene `settings.gradle.kts`).
3. Espera a que termine "Gradle Sync". La primera vez descarga Gradle y el SDK 35
   (acepta las licencias si te las pide). Si ofrece "Update" para el plugin de Android Gradle, acepta.
4. En el celular: `Ajustes > Acerca del teléfono`, toca 7 veces "Número de compilación",
   luego `Opciones de desarrollador > Depuración por USB` (actívala).
5. Conecta el celular por cable y acepta "Permitir depuración USB".
6. Arriba en Android Studio elige tu celular y pulsa **Run ▶**.

## Generar el APK para instalar sin cable
`Build > Build Bundle(s) / APK(s) > Build APK(s)`. El archivo queda en
`app/build/outputs/apk/debug/app-debug.apk`. Pásalo al celular e instálalo
(permite "instalar apps de orígenes desconocidos").

## Cambiar la app
Edita `app/src/main/assets/index.html` y vuelve a pulsar Run.
