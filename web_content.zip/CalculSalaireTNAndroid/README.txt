Calcul Salaire TN Android project (V15)


Contains the V15 proposed-print-layout HTML in app/src/main/assets/index.html and a basic Android WebView shell.


Build APK:
1. Open this folder in Android Studio (Open project).
2. Allow Gradle sync/download.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find APK in app/build/outputs/apk/debug/.

Note: This archive is the Android Studio project, not a compiled APK.
