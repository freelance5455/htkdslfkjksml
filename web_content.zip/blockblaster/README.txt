Block Blaster — 100 Level Edition

Open index.html in a modern browser with internet access (Babylon.js loads from cdnjs).

How to play:
- Drag the three pieces onto the 8x8 grid.
- Complete rows or columns to blast them.
- Each level has a unique board layout, line-clear objective, move limit, and increasing piece difficulty.
- Clear the required number of lines before moves run out.
- Complete all 100 levels to win.
- If you run out of moves or have no valid placement, retry the current level.
- Press P or Esc to pause.

The game stores your best score in browser localStorage.
