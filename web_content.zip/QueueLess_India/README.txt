QueueLess India — Starter ZIP

WHAT THIS IS
A phone-friendly HTML prototype for an IDT demonstration. It includes all 28 Indian states and 8 union territories, city/district and service-centre fields, token creation, queue display, and a staff "call next" demo control.

IMPORTANT LIMITATION
This starter stores demo queue data in the browser on one device only. It is not yet a real nationwide multi-user service. Different users' phones will not see the same queue until an online backend (for example Firebase) and secure staff sign-in/permissions are added. Do not use this prototype for real appointments or public services.

HOW TO USE
1. Extract the ZIP.
2. Upload the index.html file (or the extracted folder, if your APK builder accepts folders) to your web-to-APK builder.
3. Build a new APK.
4. Open the app and enter a state, city/district, service centre, and service.
5. Get tokens and use Staff Desk > Call next token to demonstrate the flow.

SAFETY / PRIVACY
Use only a first name or nickname in the demo. Do not enter phone numbers, addresses, identity numbers, or sensitive information.
