package com.banktycoon.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;
import android.view.Window;
import android.view.WindowInsets;
import android.view.View;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private String pendingRewardKind;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // One-time startup orientation request. The manifest is the primary lock.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        MobileAds.initialize(this, status -> loadRewardedAd());
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7,19,29));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/www/index.html");
        setContentView(webView);
    }
    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, "ca-app-pub-3940256099942544/5224354917", request, new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
            @Override public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error) { rewardedAd = null; }
        });
    }

    private class AdBridge {
        @JavascriptInterface public void showRewardedAd(String kind) {
            runOnUiThread(() -> {
                pendingRewardKind = kind;
                if (rewardedAd == null) {
                    webView.evaluateJavascript("toast('📺 الإعلان غير جاهز الآن، حاول بعد قليل')", null);
                    loadRewardedAd();
                    return;
                }
                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { rewardedAd = null; loadRewardedAd(); }
                    @Override public void onAdFailedToShowFullScreenContent(AdError adError) { rewardedAd = null; loadRewardedAd(); }
                });
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    String safe = pendingRewardKind == null ? "cash" : pendingRewardKind.replace("'", "\\'");
                    webView.evaluateJavascript("rewardAd('" + safe + "')", null);
                });
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onResume() {
        super.onResume();
        // Landscape is declared as a fixed Activity orientation in AndroidManifest.
        // Do not repeatedly call setRequestedOrientation(): Android may detect that
        // as an orientation-request loop and ignore subsequent requests.
    }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
