/* MLBB VS BOT - Mesin OTP Gmail + database bersama.
   Pasang di akun Gmail INDUK. Deploy: Aplikasi Web | Jalankan sebagai: Saya | Akses: Siapa saja.
   Jalankan fungsi izin() SEKALI dari editor untuk menyetujui izin Gmail. */
var USERS = {'FirasXDev': 'Cgh1yg6', 'FirasXCo': 'Cgh1yg6'}; // harus sama dengan login di APK
var DAY = 864e5;

function izin() { GmailApp.getInboxUnreadCount(); PropertiesService.getScriptProperties().getKeys(); LockService.getScriptLock(); return 'Izin OK'; }
function doGet() { return out_({ok: 1, msg: 'Mesin OTP MLBB aktif'}); }
function doPost(e) {
  var r;
  try { r = locked_(JSON.parse(e.postData.contents)); if (r && r._g) r = gmail_(r._g); }
  catch (x) { r = {err: String(x && x.message || x)}; }
  return out_(r);
}
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function locked_(d) {
  var l = LockService.getScriptLock(); l.waitLock(25000);
  try { var S = load_(), b = JSON.stringify(S); tick_(S); var r = route_(S, d); if (JSON.stringify(S) !== b) save_(S); return r; }
  finally { l.releaseLock(); }
}
function load_() {
  var P = PropertiesService.getScriptProperties().getProperties(), n = +P.n || 0, s = '';
  for (var i = 0; i < n; i++) s += P['c' + i] || '';
  return s ? JSON.parse(s) : {price: 4000, delay: 14, stock: [], pays: [], orders: []};
}
function save_(S) {
  var p = PropertiesService.getScriptProperties(), s = JSON.stringify(S), d = {}, n = 0, old = +p.getProperty('n') || 0;
  for (var i = 0; i < s.length; i += 8000) { d['c' + n] = s.substr(i, 8000); n++; }
  d.n = String(n); p.setProperties(d);
  for (var j = n; j < old; j++) p.deleteProperty('c' + j);
}
function role_(d) {
  var u = d.u;
  if (!u || !Object.prototype.hasOwnProperty.call(USERS, u) || USERS[u] !== d.p) return '';
  return u === 'FirasXDev' ? 'dev' : 'co';
}
function route_(S, d) {
  var a = d.a, r = role_(d);
  if (a === 'state') return pub_(S, r);
  if (a === 'mine') return {now: Date.now(), orders: (d.list || []).slice(0, 30).map(function (m) { return mine_(S, m || {}); }).filter(Boolean)};
  if (a === 'order') return order_(S, d, r);
  if (a === 'otp') return otp_(S, d);
  if (r !== 'dev') throw new Error('Akses ditolak: hanya Developer yang boleh melakukan ini.');
  if (a === 'ping') return ping_();
  if (a === 'dev') { dev_(S, d); return pub_(S, 'dev'); }
  throw new Error('Aksi tidak dikenal.');
}
function find_(arr, id) { for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return arr[i]; return null; }
function need_(S, id) { var s = find_(S.stock, id); if (!s) throw new Error('Akun tidak ditemukan.'); return s; }
function ord_(S, id) { var o = find_(S.orders, id); if (!o) throw new Error('Pesanan tidak ditemukan.'); return o; }
function uid_() { return Utilities.getUuid().replace(/-/g, '').slice(0, 8); }
function clean_(t, n) { return String(t == null ? '' : t).replace(/[^\x20-\x7E]/g, '').trim().slice(0, n); }
function mask_(e) { var p = e.split('@'), l = p[0]; return (l.length > 5 ? l.slice(0, 3) + '****' + l.slice(-2) : l.slice(0, 1) + '****') + '@' + p[1]; }
function emOf_(S, o) { var s = find_(S.stock, o.sid); return s ? s.em : ''; }
function free_(S, o) { var s = find_(S.stock, o.sid); if (s && s.rid === o.id) s.rid = null; }

function pub_(S, r) {
  var dv = r === 'dev';
  var o = {now: Date.now(), price: S.price, delay: S.delay, pays: S.pays, stock: S.stock.map(function (s) {
    return {id: s.id, em: dv ? s.em : mask_(s.em), lm: s.lm, ra: s.ra, rid: dv ? s.rid : (s.rid ? 1 : 0)};
  })};
  if (dv) o.orders = S.orders.slice().reverse().slice(0, 150).map(function (x) {
    var c = {}; for (var k in x) c[k] = x[k]; delete c.tok; c.em = emOf_(S, x); return c;
  });
  return o;
}
function mine_(S, m) {
  var o = find_(S.orders, m.id); if (!o || o.tok !== m.tok) return null;
  var s = find_(S.stock, o.sid);
  return {id: o.id, nm: o.nm, st: o.st, t0: o.t0, s: o.s || 0, e: o.e || 0, em: (o.st === 'active' && s) ? s.em : ''};
}
// Sewa aktif 24 jam sejak di-ACC. Terakhir match = tanggal mulai, siap lagi = berakhir + jeda (default 14 hari).
function approve_(S, o, now) {
  var s = find_(S.stock, o.sid); o.st = 'active'; o.s = now; o.e = now + DAY;
  if (s) { s.lm = now; s.ra = o.e + S.delay * DAY; s.rid = o.id; }
}
function tick_(S) {
  var now = Date.now();
  S.orders.forEach(function (o) { if (o.st === 'active' && now >= o.e) { o.st = 'expired'; free_(S, o); } });
  if (S.orders.length > 400) S.orders = S.orders.filter(function (o) { return o.st === 'pending' || o.st === 'active'; }).concat(S.orders.filter(function (o) { return o.st !== 'pending' && o.st !== 'active'; }).slice(-250));
}
function order_(S, d, r) {
  var free = !!r, now = Date.now(), s = null;
  if (!free) {
    if (!d.pay || !S.pays.some(function (p) { return p.id === d.pay; })) throw new Error('Pilih metode pembayaran yang valid.');
    if (!clean_(d.ref, 60)) throw new Error('Isi nama pengirim / bukti transfer.');
  }
  if (d.sid && d.sid !== 'auto') {
    s = find_(S.stock, d.sid);
    if (!s || s.rid || s.ra > now) throw new Error('Akun itu sudah tidak siap. Pilih akun lain.');
  } else {
    s = S.stock.filter(function (x) { return !x.rid && x.ra <= now; }).sort(function (a, b) { return a.ra - b.ra; })[0];
    if (!s) throw new Error('Stok akun siap sedang habis.');
  }
  var o = {id: 'ORD-' + Math.floor(1e5 + Math.random() * 9e5), tok: Utilities.getUuid().replace(/-/g, ''), nm: clean_(d.nm, 30) || 'Pengunjung', sid: s.id, st: 'pending', t0: now, pay: free ? '' : d.pay, ref: clean_(d.ref, 60), free: free};
  s.rid = o.id; S.orders.push(o);
  if (free) approve_(S, o, now);
  return {id: o.id, tok: o.tok, st: o.st};
}
function dev_(S, d) {
  var now = Date.now(), op = d.op, s, o;
  if (op === 'cfg') {
    var p = Math.round(+d.price), y = Math.round(+d.delay);
    if (!(p >= 0 && p <= 1e7) || !(y >= 0 && y <= 365)) throw new Error('Harga atau jeda tidak valid.');
    S.price = p; S.delay = y;
  } else if (op === 'add') {
    (d.list || []).forEach(function (x) {
      var em = String(x.em || '').trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) throw new Error('Email tidak valid: ' + em);
      if (S.stock.some(function (k) { return k.em === em; })) throw new Error('Email sudah ada di stock: ' + em);
      S.stock.push({id: uid_(), em: em, lm: +x.lm || 0, ra: +x.ra || now, rid: null});
    });
  } else if (op === 'ready') { s = need_(S, d.id); s.ra = now; }
  else if (op === 'cool') { s = need_(S, d.id); s.lm = now; s.ra = now + S.delay * DAY; }
  else if (op === 'del') {
    s = need_(S, d.id); if (s.rid) throw new Error('Akun sedang dipesan/disewa. Tolak atau matikan pesanannya dulu.');
    S.stock = S.stock.filter(function (k) { return k.id !== s.id; });
  } else if (op === 'ok') {
    o = ord_(S, d.oid); if (o.st !== 'pending') throw new Error('Pesanan ini tidak berstatus pending.'); approve_(S, o, now);
  } else if (op === 'no') {
    o = ord_(S, d.oid); if (o.st !== 'pending') throw new Error('Pesanan ini tidak berstatus pending.'); o.st = 'rejected'; free_(S, o);
  } else if (op === 'kill') {
    o = ord_(S, d.oid); if (o.st !== 'active') throw new Error('Sewa ini tidak sedang aktif.');
    o.st = 'killed'; o.e = Math.min(o.e, now); s = find_(S.stock, o.sid);
    if (s) { s.rid = null; s.lm = now; s.ra = now + S.delay * DAY; }
  } else if (op === 'addpay') {
    var nm = clean_(d.name, 40), no = clean_(d.no, 40), img = String(d.img || '');
    if (!nm || (!no && !img)) throw new Error('Data pembayaran belum lengkap.');
    if (img && (img.indexOf('data:image/') !== 0 || img.length > 60000)) throw new Error('Gambar QRIS tidak valid / terlalu besar.');
    S.pays.push({id: uid_(), type: clean_(d.type, 10) || 'DANA', no: no, name: nm, img: img});
  } else if (op === 'delpay') { S.pays = S.pays.filter(function (p) { return p.id !== d.id; }); }
  else throw new Error('Operasi tidak dikenal.');
}
// Cek otomatis Gmail Induk (dipanggil tombol "Simpan & Cek Otomatis")
function ping_() {
  var me = ''; try { me = Session.getEffectiveUser().getEmail(); } catch (e) {}
  var n = GmailApp.search('newer_than:7d (moonton OR mlbb OR "mobile legends")', 0, 50).length;
  return {ok: 1, gm: me, mt: n, now: Date.now()};
}
// Validasi pesanan (di dalam lock), lalu baca Gmail di luar lock supaya tidak antre.
function otp_(S, d) {
  var o = find_(S.orders, d.id); if (!o || o.tok !== d.tok) throw new Error('Pesanan tidak ditemukan.');
  if (o.st !== 'active' || Date.now() >= o.e) return {st: o.st === 'active' ? 'expired' : o.st};
  var s = find_(S.stock, o.sid); if (!s) throw new Error('Akun tidak ditemukan.');
  return {_g: {em: s.em, t0: o.s}};
}
function gmail_(g) {
  var code = null, at = 0;
  GmailApp.search('newer_than:2d (moonton OR mlbb OR "mobile legends" OR "bang bang")', 0, 50).forEach(function (t) {
    t.getMessages().forEach(function (m) {
      var dt = m.getDate().getTime(); if (dt < g.t0 || dt <= at) return;
      var raw = m.getRawContent().slice(0, 8000).toLowerCase();
      var to = (m.getTo() + ' ' + m.getCc() + ' ' + (raw.match(/^(?:delivered-to|x-original-to):\s*\S+/gm) || []).join(' ')).toLowerCase().match(/[a-z0-9._+-]+@[a-z0-9.-]+/g) || [];
      if (to.indexOf(g.em) < 0) return;
      var body = m.getSubject() + ' ' + m.getPlainBody();
      if (!/moonton|mobile legends|mlbb|bang bang/i.test(m.getFrom() + ' ' + body)) return;
      var c = extract_(body); if (c) { code = c; at = dt; }
    });
  });
  return {st: 'active', code: code, at: at || null};
}
function extract_(t) {
  var m = t.match(/(?:code|kode|verification|verifikasi)\D{0,60}(\d{4,8})/i) || t.match(/\b(\d{6})\b/);
  return m ? m[1] : null;
}
