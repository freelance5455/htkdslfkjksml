// ============================================================================
// FILE: GoogleAppsScript_OTP.gs
// MESIN PEMBACA OTP MOONTON OTOMATIS + DATABASE STOK BERSAMA UNTUK APK ANDROID
// 100% GRATIS • TANPA SERVER / NETLIFY • LANGSUNG TERHUBUNG KE GMAIL INDUK
// ============================================================================
// CARA PASANG (1 MENIT):
// 1. Buka https://script.google.com menggunakan akun GMAIL INDUK Anda.
// 2. Klik "+ Project baru", hapus semua kode bawaan, tempel seluruh kode ini.
// 3. Klik "Terapkan (Deploy)" -> "Deployment baru".
// 4. Pilih jenis: "Aplikasi Web" (Web App).
//    - Jalankan sebagai: "Saya" (akun Gmail Induk Anda)
//    - Yang memiliki akses: "Siapa saja" (Anyone)
// 5. Klik "Terapkan", izinkan akses Gmail, lalu salin URL Web App-nya ke dalam APK!

function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents || '{}');
    var action = body.action || '';
    var props = PropertiesService.getScriptProperties();

    // 1. Ambil database stok & pengaturan bersama untuk APK
    if (action === 'get_state') {
      var raw = props.getProperty('FIRASX_APK_STATE');
      return jsonResponse({
        ok: true,
        state: raw ? JSON.parse(raw) : null
      });
    }

    // 2. Simpan perubahan stok/harga/pembayaran dari Developer
    if (action === 'save_state') {
      if (body.state) {
        props.setProperty('FIRASX_APK_STATE', JSON.stringify(body.state));
      }
      return jsonResponse({ ok: true });
    }

    // 3. Verifikasi kecocokan Gmail Induk & akses kotak masuk
    if (action === 'verify_gmail') {
      var activeEmail = Session.getActiveUser().getEmail();
      var inputEmail = String(body.masterEmail || '').trim().toLowerCase();

      if (activeEmail && inputEmail && activeEmail.toLowerCase() !== inputEmail) {
        return jsonResponse({
          valid: false,
          message: '❌ Akun Google Apps Script ini milik ' + activeEmail + ', bukan ' + inputEmail + '. Buka script.google.com memakai akun ' + inputEmail + '!'
        });
      }

      // Tes baca 1 thread inbox untuk memastikan izin Gmail aktif
      var threads = GmailApp.getInboxThreads(0, 1);
      return jsonResponse({
        valid: true,
        message: '✅ SUKSES! Mesin Gmail APK aktif untuk ' + (activeEmail || inputEmail) + '. Siap menangkap OTP Moonton otomatis!'
      });
    }

    // 4. Cari kode OTP Moonton terbaru untuk email bertitik tertentu
    if (action === 'fetch_otp') {
      var target = String(body.targetEmail || '').trim().toLowerCase();
      var threads = GmailApp.search('moonton', 0, 15);

      for (var i = 0; i < threads.length; i++) {
        var messages = threads[i].getMessages();
        for (var j = messages.length - 1; j >= 0; j--) {
          var msg = messages[j];
          var toAddr = String(msg.getTo() || '').toLowerCase();
          var bodyText = String(msg.getPlainBody() || '');
          var rawContent = String(msg.getRawContent() || '').toLowerCase();

          // Cocokkan email bertitik pada header To, Delivered-To, atau isi email ("Dear h.ara.panindubapam@gmail.com")
          if (toAddr.indexOf(target) !== -1 || rawContent.indexOf(target) !== -1 || bodyText.toLowerCase().indexOf(target) !== -1) {
            var match = bodyText.match(/Verification code[:\s\r\n]*([0-9]{6})/i) || bodyText.match(/\b([0-9]{6})\b/);
            if (match && match[1]) {
              return jsonResponse({
                found: true,
                otp: match[1],
                to: body.targetEmail,
                sender: msg.getFrom(),
                date: Utilities.formatDate(msg.getDate(), 'Asia/Jakarta', 'dd MMM yyyy HH:mm:ss')
              });
            }
          }
        }
      }

      return jsonResponse({ found: false });
    }

    return jsonResponse({ error: 'Action tidak dikenal' });
  } catch (err) {
    return jsonResponse({ error: String(err) });
  }
}

function doGet(e) {
  return jsonResponse({ status: 'FirasX Rent APK Bridge Active' });
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
