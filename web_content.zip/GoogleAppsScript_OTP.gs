/**
 * MESIN PEMBACA OTP GMAIL & SINKRONISASI STOK REAL-TIME (UNTUK HTML-TO-APK)
 * Cara pasang:
 * 1. Buka https://script.google.com menggunakan akun Gmail Induk (misal: harapanindubapam@gmail.com)
 * 2. Buat Project Baru -> Hapus semua kode bawaan -> Tempel seluruh kode ini -> Simpan
 * 3. Klik Terapkan (Deploy) -> Deployment baru -> Jenis: Aplikasi Web
 *    - Jalankan sebagai: Saya (email Gmail Induk Anda)
 *    - Yang memiliki akses: Siapa saja (Anyone)
 * 4. Salin URL Web App (https://script.google.com/macros/s/.../exec) dan tempel di Panel Developer APK!
 */

const PROP_KEY_STATE = 'MLBB_SHARED_STATE_V1';

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'ping';
  const props = PropertiesService.getScriptProperties();

  if (action === 'ping') {
    const activeEmail = Session.getEffectiveUser().getEmail();
    return jsonOut({
      ok: true,
      message: 'Terhubung ke Google Apps Script Gmail Induk: ' + (activeEmail || 'Aktif'),
      gmail: activeEmail
    });
  }

  if (action === 'getState') {
    const raw = props.getProperty(PROP_KEY_STATE);
    return jsonOut({
      ok: true,
      state: raw ? JSON.parse(raw) : null
    });
  }

  if (action === 'getOtps') {
    const otps = scanMoontonOtps();
    return jsonOut({
      ok: true,
      otps: otps,
      checkedAt: new Date().toISOString()
    });
  }

  return jsonOut({ ok: false, error: 'Action tidak dikenal' });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const props = PropertiesService.getScriptProperties();

    if (body.action === 'saveState' && body.state) {
      props.setProperty(PROP_KEY_STATE, JSON.stringify(body.state));
      return jsonOut({ ok: true, message: 'Database stok & pengaturan tersinkron ke semua HP!' });
    }

    if (body.action === 'verify') {
      const activeEmail = Session.getEffectiveUser().getEmail();
      const otps = scanMoontonOtps();
      return jsonOut({
        ok: true,
        gmail: activeEmail,
        otpCount: otps.length,
        message: '✅ TERHUBUNG! Mesin Pembaca Gmail aktif & siap menarik OTP Moonton otomatis.'
      });
    }

    return jsonOut({ ok: false, error: 'Payload POST tidak valid' });
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

function scanMoontonOtps() {
  const results = [];
  // Cari di INBOX dan SPAM sekaligus (in:anywhere mencakup Spam & Trash di Gmail Search)
  const queries = [
    'in:anywhere (from:moonton OR subject:Moonton OR subject:"Mobile Legends" OR "verification code" OR "kode verifikasi")'
  ];

  const threads = GmailApp.search(queries[0], 0, 20);
  for (let i = 0; i < threads.length; i++) {
    const messages = threads[i].getMessages();
    for (let j = 0; j < messages.length; j++) {
      const msg = messages[j];
      const subject = msg.getSubject() || '';
      const to = msg.getTo() || '';
      const dateObj = msg.getDate();
      const plain = msg.getPlainBody() || '';
      const htmlStripped = (msg.getBody() || '').replace(/<[^>]+>/g, ' ');
      const fullText = subject + ' ' + plain + ' ' + htmlStripped;

      // Tangkap 6 digit kode OTP Moonton
      const match = fullText.match(/\b(\d{6})\b/);
      if (match) {
        results.push({
          id: msg.getId(),
          code: match[1],
          to: to,
          subject: subject,
          timestamp: dateObj ? dateObj.getTime() : 0,
          date: dateObj ? Utilities.formatDate(dateObj, 'Asia/Jakarta', 'dd MMM yyyy HH:mm:ss') + ' WIB' : '-'
        });
      }
    }
  }

  // Urutkan dari yang paling baru
  results.sort((a, b) => b.timestamp - a.timestamp);
  return results.slice(0, 25);
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
