# MedPocket ProGuard rules
# The app is a thin WebView shell; keep the WebView bridge intact.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class androidx.webkit.** { *; }
