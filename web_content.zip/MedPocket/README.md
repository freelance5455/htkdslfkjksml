# MedPocket 13.0 — Android + Netlify

This package contains the Android Studio project and the matching static Netlify site.

## Final completion work in this revision

### Repaired navigation and support actions
- Added the missing Drug Reference and Disease Guide page renderers. Both pages support search and local add/edit/delete operations.
- Changed the rating action to save an actual local rating rather than opening an email draft.
- Improved the app-share fallback so it copies the share text/link or presents the link for manual copying.

### Eight added features
1. Universal Search across files, notes, flashcards, MCQs, drugs, conditions, protocols and references.
2. Bulk File Transfer: select multiple stored files and export/import a MedPocket package without replacing existing records.
3. Duplicate Finder: flags same-name/same-size candidate duplicates for manual review; it does not automatically delete them.
4. Storage Manager: reports local attachment storage and identifies orphaned file blobs, with a confirmation-protected cleanup.
5. Data Integrity Check: checks folder structure, duplicate identifiers, incomplete flashcards and invalid MCQ answer indexes.
6. Device Diagnostics: checks browser storage, IndexedDB, secure context, crypto, notifications, camera API and file-store access.
7. Study Report: exports a JSON summary of study organisation and saved content.
8. Quick Launcher: Ctrl/Cmd+K (or the home-screen tile) opens a searchable navigation palette.

### Four Android host capabilities
- Native multi-file document picker for HTML file inputs.
- Runtime camera/microphone permission handling for supported web features.
- Pinch-to-zoom in the Android WebView, with zoom controls hidden.
- Android Downloads handling for ordinary HTTP(S) downloads and external URL hand-off to Android apps.

## Deploy to Netlify

1. Deploy the **contents** of `netlify-site/` using Netlify's manual deploy flow, or connect the repository.
2. Use no build command and set the publish directory to `netlify-site`.
3. Use the HTTPS deployment URL. Browser-local storage and IndexedDB keep data on that device.

## Android build

Open this folder in Android Studio (it contains `settings.gradle`). The embedded web application is in `app/src/main/assets/www/`.

The Android project uses Gradle 8.7 and Android Gradle Plugin configuration in the project. A full Android build was not run in this environment because the Gradle distribution and Android SDK were not available offline.

## Important limits

- Browser storage quotas and Android device memory still constrain very large files.
- The Duplicate Finder detects likely duplicates by matching filename and file size; it does not compare file hashes.
- PPT/PPTX rendering remains dependent on the bundled web viewer's supported content and cannot guarantee full fidelity for every animation, embedded object or complex layout.
- Clinical references are educational records. Confirm clinical decisions and dosing against current authoritative sources and local protocols.
- Cloud sync is optional and requires a user-configured endpoint; it is not enabled by default.
