# MedPocket — Netlify web deployment

## Deploy

This is a static web app. In Netlify, choose **Add new site → Deploy manually** and drag the **contents of `netlify-site/`** (the folder containing `index.html`, `_redirects`, `sw.js`, and the icons) into the deploy area. Alternatively, connect the repository and leave the build command blank with publish directory `netlify-site`.

## Important behaviour

- MedPocket stores profiles, study data, and uploaded files in the browser on the current device using localStorage and IndexedDB. This deployment does not upload users' study files to Netlify or provide account-based cloud sync. Browser/device data clearing can remove locally stored information; use the app's backup/export features.
- Use the HTTPS Netlify URL, not a local `file://` URL. File rendering libraries are loaded from their existing CDN URLs, so first-time previewing of formats such as PDF, DOCX, spreadsheets and PPTX requires internet access to load those libraries. Core app shell is cached by the service worker.
- Large uploads now report storage failures rather than creating broken file records. PDF canvas rendering uses a bounded backing resolution to reduce memory spikes on large/complex pages. A browser may still be unable to preview a document that exceeds device memory; the saved original remains downloadable.
- For updates, deploy the whole folder. The service worker cache version is managed in `sw.js`.

## Project structure

- `netlify-site/index.html` — MedPocket web application
- `netlify-site/sw.js` — offline shell caching and notifications
- `netlify-site/manifest.webmanifest` and icon files — installable web app metadata
- `netlify.toml`, `netlify-site/_redirects` — Netlify deployment configuration
- `app/`, `gradle/`, Gradle files — original Android Studio project retained

The original Android project remains in this package. Its embedded web app copy was updated with the same file-storage and PDF-rendering fixes as the Netlify root copy.
