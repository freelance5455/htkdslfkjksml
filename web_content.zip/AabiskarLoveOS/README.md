# Aabiskar LoveOS — prototype + Firebase setup notes

This package contains a responsive, interactive frontend prototype. It is **not yet a live multi-user app**: login, Google sign-in, password reset emails, partner pairing, real-time chat across devices, and cloud photo storage are placeholders until a Firebase project is configured and the backend rules are deployed.

## Important admin security
- Intended admin email: `aabiskarsharma09@gmail.com`
- Do not put an admin password in HTML/JavaScript or commit it to source control.
- Do not grant admin rights based only on an email string supplied by the browser.
- For production, assign a Firebase custom claim (`admin: true`) using a trusted Admin SDK environment, then enforce that claim in database rules and server-side admin operations.
- Firebase's password reset flow should send a reset email; the app must never ask an administrator to share their existing password with a developer or AI.

## Suggested beginner setup
1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web app in Project settings and copy the Firebase web configuration.
3. In Authentication → Sign-in method, enable Google and Email/Password. Configure the authorized domains.
4. Build and test the auth flow first, including email verification and password reset.
5. Create Firestore, then write and test security rules in the Firebase Emulator or Rules Playground before deploying.
6. Implement invitation codes transactionally: store only a hash of a random code, expire it, limit attempts, and require the invitee's authenticated UID to accept.
7. Store messages under a couple-scoped path. Every read/write must verify that the authenticated UID is a current member of that couple.
8. Keep private letters under the author's user path. Shared letters should be explicitly published to a couple path; do not rely on hiding UI controls.
9. Add private photo storage only after checking current Firebase billing requirements and quotas. Set strict file-size/type rules and couple membership checks.
10. Test with two separate accounts and an unrelated third account. Verify that the third account cannot read messages, letters, invitations, or photos.
11. Deploy only after tests pass; configure budget alerts if the chosen service requires billing.

## Prototype
Open `index.html` in a browser to explore the UI. It stores demo content only in the current page session and does not send data anywhere. Do not enter a real password in the prototype.
