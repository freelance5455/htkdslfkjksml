# RiverCrew Android V2

Aplicação Android de gestão para tripulações de cruzeiros fluviais.

## Nesta versão
- Português / Français / English
- 6 barcos
- Seleção de barco
- Dashboard
- Plano de navegação com adicionar/remover etapas
- Escala de tripulação com alteração de folgas
- Manutenção com estados e prioridades
- Registo e remoção de ocorrências
- Checklists
- Eclusas e caudais (dados demonstrativos)
- Relatórios e exportação JSON
- Dados guardados localmente no dispositivo através de localStorage
- Funciona em modo offline para as funções locais

## Compilar
Abrir a pasta `RiverCrew_Android` no Android Studio e executar `Build > Build APK(s)`.
