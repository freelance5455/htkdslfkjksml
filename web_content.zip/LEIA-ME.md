# DEAD HORIZON - gerar o APK

A pasta `www/` e o jogo completo (index.html, icones e manifest).

## Opcao 1: Capacitor (no computador, com Node.js e Android Studio)
1. Nesta pasta: `npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/assets`
2. `npx cap init "DEAD HORIZON" com.deadhorizon.game --web-dir=www`
3. `npx cap add android`
4. Icone: crie `assets/icon-only.png` (copie icon-512.png) e rode `npx capacitor-assets generate --android`
5. Deitado: em `android/app/src/main/AndroidManifest.xml`, na tag `<activity>`, adicione `android:screenOrientation="sensorLandscape"`
6. `npx cap sync` e `npx cap open android`. No Android Studio: Build > Build APK(s).
7. O APK fica em `android/app/build/outputs/apk/debug/`. Copie para o celular e instale.

## Opcao 2: PWABuilder
Hospede a pasta `www/` em HTTPS (GitHub Pages ou Netlify), cole o link em pwabuilder.com e baixe o pacote Android.

## Opcao 3: Claude Code (no computador)
Abra esta pasta no Claude Code e peca: "gere o APK debug deste projeto Capacitor".
