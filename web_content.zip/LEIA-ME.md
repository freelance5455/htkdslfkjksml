# Aldeia do Reino: Ecos da Névoa — v3.2

Projeto de RPG 3D web preparado para empacotamento Android com Capacitor.

## Novidades v3.2
- Controles de toque e layout mobile mais confortáveis.
- NPCs mudam de área ao longo do ciclo do mundo, incentivando o jogador a procurá-los.
- Oficina dentro do inventário: criar poções, melhorar espada e reforçar armadura.
- Melhorias de equipamento persistem no salvamento; espada aumenta o dano e armadura reduz o dano recebido.
- Workflow do GitHub Actions para gerar APK de depuração automaticamente.

## Rodar no computador
Requer Node.js 20 ou superior.

```bash
npm install
npm run dev
```

## Gerar APK localmente
Requer JDK 17, Android SDK e Android Studio/Gradle compatíveis.

```bash
npm install
npm run build
npx cap add android   # só na primeira vez
npm run android:sync
cd android
./gradlew assembleDebug
```

APK de depuração esperado: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Gerar APK pelo GitHub
1. Extraia os arquivos do ZIP e envie o conteúdo para um repositório GitHub.
2. Abra a aba **Actions** do repositório.
3. Execute **Build Android APK** com **Run workflow** (ou faça push para `main`/`master`).
4. Quando a execução terminar, abra a execução e baixe o artefato `aldeia-do-reino-debug-apk`.
5. Extraia o artefato para obter `app-debug.apk` e envie esse APK ao amigo. No Android, pode ser necessário autorizar a instalação do arquivo baixado.

O APK gerado pelo workflow é de depuração para teste/compartilhamento, não uma versão assinada para publicação na Play Store.

## Observações
- A narrativa básica funciona localmente. Recursos que dependam de um servidor de IA continuam dependendo de endpoint/configuração próprios; não coloque chaves secretas no código do jogo.
- O APK ainda precisa ser compilado num ambiente com dependências Android. O ZIP é o projeto-fonte, não o APK final.


## Sistema de personagem v3.3
- Progressão de nível por experiência e pontos de atributo.
- Atributos: força, agilidade e vitalidade.
- Ficha com altura (1,78 m), peso corporal (72 kg), vida máxima e carga.
- Capacidade de carga aumenta com força; coleta é bloqueada quando a mochila está cheia.
- Inventário com recursos, consumíveis e equipamentos já integrado.
