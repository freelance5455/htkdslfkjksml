# Etiquetas de anomalia: app de busca

Busca nas etiquetas da planilha **NotasAnomalias_Safra 26/27** (2.555 etiquetas, atualizada até 15/11/2026).

## O que o app faz
- **Busca** por palavra (todas as palavras precisam aparecer, sem diferenciar acento ou maiúscula), com escopo: Tudo, Descrição, Equipamento, Nota/Ordem (controle), Notificador ou Local de instalação.
- **Atalhos**: Caldeiraria, Caldeira, Utilidades, Produção, Extração.
- **Mais filtros**: Área, Centro de trabalho, Tipo (azul/vermelha), Prioridade, Status, Setor, Quando executar, Risco de lesão e período da **data de registro**.
- Toque em uma etiqueta para ver todos os detalhes (providências, comentários, prazo, responsável).
- **Importar Excel**: botão no topo; escolha uma planilha nova (.xlsx ou .xlsm). Ela substitui as etiquetas e fica guardada no aparelho. A programação é mantida.
- **Programar para resolver**: marque a caixa em qualquer etiqueta. Ela vai para a aba **Programadas**, onde você pode marcar como concluída, reabrir ou remover (e limpar as concluídas). Fica salva no aparelho.

## Testar agora (sem compilar)
Abra `dist/anomalias.html` no Chrome do computador ou do celular. É um arquivo único, funciona offline.

## Compilar o app Android (APK)
Precisa de: Node.js 18+ e Android Studio (com JDK 17).
```
npm install
npx cap add android
npx cap sync android
npx cap open android
```
No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Atualizar os dados no projeto (antes de compilar)
```
node build.js "NovaPlanilha.xlsm"
npx cap sync android
```
Isso refaz `www/dados.js` e `dist/anomalias.html`.

## Ajustes
- Nomes de Área e Centro de trabalho: no início de `www/app.js` (objetos `AREA` e `CENTRO`). A relação, por exemplo `IM_ENCAN = Caldeiraria`, foi deduzida dos dados e deve ser conferida.
- O atalho **Caldeira** procura "caldeira" ou "cald." no equipamento, na descrição e no setor.
- O app lê a aba **Lista compl.** (etiquetas ativas). A aba oculta de encerradas (Safra 22/23) não está incluída.
