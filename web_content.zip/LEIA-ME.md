# JARVIS PWA — Protótipo 01

Este projeto é um protótipo de assistente de voz instalável (PWA). Não inclui uma IA generativa e não finge ter uma: os comandos respondidos são locais e limitados a hora, data, saudação e ajuda.

## Arquivos

- `index.html`: interface e estrutura.
- `style.css`: visual futurista azul e layout responsivo.
- `app.js`: Web Speech API, síntese de fala, palavra de ativação e comandos locais.
- `manifest.json`: metadados de instalação do PWA.
- `sw.js`: cache offline da interface.
- `icon.svg`, `icon-192.png`, `icon-512.png`: ícones.

## Hospedar gratuitamente no GitHub Pages

1. Entre em https://github.com/ e crie uma conta, se ainda não tiver.
2. Crie um repositório público chamado `jarvis-pwa`.
3. Envie todos os arquivos desta pasta para a raiz do repositório (não envie apenas o ZIP).
4. Abra **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**, selecione `main` e a pasta `/ (root)`, e salve.
6. Aguarde o GitHub publicar o site. O endereço terá formato `https://SEU-USUARIO.github.io/jarvis-pwa/`.
7. Abra o endereço no Chrome do Moto G24. Toque em **Iniciar escuta** e permita o microfone.
8. No menu do Chrome, escolha **Adicionar à tela inicial** ou **Instalar app**, se essa opção aparecer.

O GitHub Pages fornece HTTPS gratuitamente. A publicação pode levar alguns minutos.

## Como usar

- Toque em **Iniciar escuta**.
- Permita o microfone quando o Chrome solicitar.
- Diga, por exemplo: **“Jarvis, que horas são?”**, **“Jarvis, que dia é hoje?”**, **“Jarvis, ajuda”** ou **“Jarvis, olá”**.
- Toque em **Parar** para encerrar a escuta.
- O campo de texto serve para testar comandos sem usar o microfone.

## Limitações reais

- `SpeechRecognition` / `webkitSpeechRecognition` não é suportado em todos os navegadores. O código mostra uma mensagem se a API não existir.
- Em muitos navegadores Chromium, o reconhecimento de voz usa um serviço remoto do navegador e pode precisar de internet. O app não instala um modelo de reconhecimento offline.
- A palavra “Jarvis” é detectada pelo reconhecimento contínuo do navegador, não por um motor dedicado de wake word. Pode falhar, reconhecer errado ou encerrar sozinho.
- Android pode pausar a página ou o microfone quando o app vai para segundo plano, a tela bloqueia, a bateria entra em economia ou o navegador decide suspender a página. Portanto, não é uma escuta contínua garantida.
- A fala usa `SpeechSynthesis` do navegador e as vozes disponíveis no aparelho.
- A versão inicial não consulta a internet, não é uma IA generativa e não controla outros apps do telefone.
- O service worker armazena os arquivos da interface para acesso offline, mas isso não garante reconhecimento de voz offline.

## Segurança

Nunca coloque chaves de API secretas em `app.js` ou em outro arquivo público do PWA. Para adicionar IA online, use um backend intermediário e confira os limites e as condições do plano gratuito do provedor.
