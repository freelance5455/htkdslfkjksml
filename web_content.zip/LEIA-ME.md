# Aldeia do Reino v12 — Mundo Imersivo (HTML to APK)

## Instalação pelo celular
1. Baixe e importe este ZIP diretamente no aplicativo **HTML to APK**. Não coloque todos os arquivos dentro de outra pasta antes de compactar.
2. Quando o conversor pedir o arquivo de entrada, selecione `index.html` da raiz do ZIP. Há cópias sincronizadas em `web/index.html` e `www/index.html` para conversores que usam essas pastas.
3. Nas opções do aplicativo, configure **Orientation / Screen Orientation = Landscape / Horizontal** e, se disponível, **Fullscreen = ativado**. O manifesto também declara `orientation: landscape`, mas alguns conversores usam uma opção nativa própria.
4. Gere um APK novo. O APK antigo não incorpora os arquivos atualizados.
5. Abra o jogo com internet ativa na primeira inicialização, porque o motor gráfico Three.js é carregado de um CDN. Se ele não carregar, a versão tenta usar o modo de compatibilidade 2D, que tem gráficos e recursos mais simples.

## Controles estilo RPG mobile
- Analógico virtual no lado esquerdo: movimento.
- Arrastar o cenário no lado direito: girar a câmera.
- Botão de câmera: alterna primeira e terceira pessoa.
- Botões inferiores: interagir, atacar, coletar e acampar.
- Painel ⚙️: sensibilidade, volume e perfil gráfico.
- Diálogo: escreva uma mensagem e toque em `Enviar`; Enter também envia. As sugestões rápidas preenchem a mensagem, não enviam automaticamente.

## Conversa e IA
O diálogo local foi atualizado para usar o texto digitado, a espécie/raça, a personalidade, o humor, os objetivos, a relação e as memórias da entidade. Ele cria respostas contextuais variadas, mas **não é um modelo de linguagem generativo**. Para respostas generativas reais, publique `server/` num serviço Node.js com HTTPS, configure `MODEL_API_KEY` como segredo no serviço e informe o endpoint `https://SEU-HOST/api/narrative` nos três arquivos `game-config.json` (raiz, `web/` e `www/`). A chave nunca deve ficar dentro do ZIP nem do APK.

O servidor aceita `MODEL_NAME` e `MODEL_BASE_URL` opcionais. O uso do provedor de modelo pode gerar custos; configure limites no serviço usado.

## O que a versão v12 aprimora
- orientação horizontal e HUD adaptada a telas baixas;
- diálogo com histórico por personagem, envio único e retorno específico à mensagem;
- tentativa de orientar o mundo 3D pela horizontal e ajuste da câmera no redimensionamento;
- relevo procedural suave, variação de cor por vértice e objetos posicionados no terreno;
- movimento autônomo de NPCs e animais, fuga de animais, companheiros e animação de membros;
- criaturas místicas com silhuetas diferentes;
- modelo de servidor generativo opcional e fallback contextual local.

## Limites verificados
Os scripts passam na checagem de sintaxe JavaScript, as três cópias do HTML são iguais, o manifesto pede paisagem e os IDs HTML não se duplicam. A instalação com o aplicativo HTML to APK e o comportamento em aparelho físico precisam ser confirmados no dispositivo; não há APK compilado incluído neste ZIP.
