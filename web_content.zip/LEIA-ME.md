# Open World Car Brasil 3D – Android (Capacitor)

## Caminho fácil (sem instalar nada): GitHub Actions
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta.
2. Vá em Actions > "Build Android" > Run workflow.
3. Ao terminar, baixe o artefato `owcb-android`: `app-debug.apk` (instale no celular para testar) e `app-release.aab` (para a Play Store).

## Assinatura (obrigatória para publicar)
keytool -genkey -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 upload.jks   -> cole em Settings > Secrets > KEYSTORE_BASE64
Crie também KEY_ALIAS (upload) e KEY_PASS (a senha). GUARDE o upload.jks e a senha em local seguro.

## Caminho local
./prepare.sh && npm install && npx cap add android && npx cap sync android && npx cap open android
No AndroidManifest.xml, adicione android:screenOrientation="sensorLandscape" na <activity>.
Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle.

## Checklist Play Store
- Conta de desenvolvedor Google Play (taxa única de US$ 25).
- Enviar o .aab (a Play Store não aceita mais APK para apps novos).
- Ícone 512x512, imagem de destaque 1024x500, 2+ capturas de tela.
- Política de privacidade (URL). O jogo só salva dados no aparelho e não coleta nada.
- Questionário de classificação etária e declaração de segurança de dados.
- Contas pessoais novas: teste fechado com 12 testadores por 14 dias antes de produção.
- Ícone do app: use `npx @capacitor/assets generate` com uma imagem em resources/icon.png.
