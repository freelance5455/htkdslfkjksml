# THE BACKROOMS: NO WAY OUT — projeto Android (APK)

Projeto Android Studio que embute o jogo (app/src/main/assets/index.html) numa WebView,
forçado em horizontal e tela cheia. Não foi compilado no ambiente do Claude: o APK sai no seu build.

## Opção 1 — Android Studio (PC)
1. Descompacte o ZIP e abra a pasta no Android Studio (File > Open).
2. Aguarde o Gradle sincronizar.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O arquivo fica em app/build/outputs/apk/debug/app-debug.apk. Copie para o celular e instale.

## Opção 2 — Sem PC (GitHub)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive .github).
2. Aba Actions > "Build APK" > Run workflow.
3. Quando terminar, baixe o artefato "no-way-out-apk" (contém app-debug.apk).

## Atualizar o jogo
Substitua app/src/main/assets/index.html pelo novo arquivo e gere o APK de novo.

## Extras
extras/capa.png (capa) e extras/icone-512.png (ícone para loja).
