# Aiko para Android

Projeto do aplicativo Android da Aiko. Ele abre a página da assistente dentro do app e liga o celular a ela:
voz (ouvir e falar), alarmes, timers, agenda, abrir aplicativos, mapas, ligação, SMS, lanterna e configurações.

Este pacote ainda não foi compilado. O APK sai do passo abaixo.

## Como gerar o APK (sem instalar nada no computador)

1. Crie uma conta gratuita em github.com e um repositório novo (pode ser privado).
2. Envie todo o conteúdo desta pasta para o repositório (botão "Add file > Upload files").
   A pasta oculta `.github` precisa ir junto. Se o navegador não mostrar pastas ocultas, use o GitHub Desktop.
3. No repositório, abra a aba **Actions**, escolha **Compilar APK** e toque em **Run workflow**.
4. Espere uns 5 minutos. Ao terminar, abra a execução e baixe **Aiko-APK** (um .zip com o `app-debug.apk`).
5. No celular, abra o `app-debug.apk`. O Android vai pedir para permitir instalar de fontes desconhecidas.

## Alternativa: Android Studio

Abra esta pasta no Android Studio, aguarde a sincronização e use **Build > Build APK(s)**.

## Primeiro uso

- Permita o microfone quando o Android pedir.
- Para conversar livremente, abra "Conexão com a IA" no app e cole uma chave da API da Anthropic.
  A chave fica só no celular e o uso é cobrado na sua conta da API.
  Sem chave, ela entende os comandos de tarefa, mas não conversa livremente.
- Para ouvir a voz, o celular precisa ter o "Serviço de fala do Google" com português instalado.
- Para usar o seu modelo VRM, abra "Meu próprio modelo (VRM)". O arquivo vale até fechar o app.

## Comandos de exemplo

- "alarme para 7 e meia", "timer de 10 minutos"
- "marca dentista amanhã às 15h" (abre a agenda para você salvar)
- "abre o WhatsApp", "pesquisa receita de bolo", "rota para a rodoviária"
- "ligar para 11 98765 4321" e "manda SMS para ... dizendo ..." (só abrem a tela, você confirma)
- "liga a lanterna", "abre o wifi"

## Observações

- O APK gerado é de teste (debug). Serve para instalar nos seus celulares. Para publicar na Play Store seria preciso assinar uma versão de lançamento.
- Ligações e mensagens nunca são enviadas sozinhas, e o Android não deixa um app ligar ou desligar Wi-Fi e Bluetooth.
- A página usa bibliotecas da internet (três.js, leitor de VRM), então o app precisa de conexão.
