# Linha de Visão — projeto web completo, versão 0.4

## Abrir e jogar

Abra `index.html` em um navegador atualizado. O jogo contra bot funciona offline. O HTML contém o mapa, personagens, armas, ícones, interface, efeitos sonoros e toda a lógica. Não há arquivos de imagem, fontes ou bibliotecas externas para carregar.

## Publicar no site

O ZIP tem `index.html` na raiz.

- Netlify Drop: envie o ZIP ou extraia e envie a pasta que contém `index.html`. Depois abra o endereço gerado no celular ou computador.
- AppsGeyser: use este HTML ou ZIP na opção de converter conteúdo HTML em APK.
- WebIntoApp: use este ZIP como HTML Project Files, com `index.html` na raiz.
- Outros serviços estáticos: publique a pasta ou os arquivos mantendo `index.html` como página inicial.

`LEIA-ME.md` e `test-game.cjs` são documentação e testes; não são necessários para rodar o jogo. `test-game.cjs` executa com Node.js: `node test-game.cjs`.

## Controles

- Analógico único à ESQUERDA: move e vira o personagem na direção do movimento. Encostar sem arrastar não altera a direção. Soltar para o movimento e o giro.
- TIRO à direita: segure para disparar.
- MIRA: toque para fixar a direção da arma. Nesse modo você consegue andar para trás ou para os lados sem virar. Toque novamente para liberar.
- RECARGA: botão ao lado de MIRA.
- GRANADAS: selecione EXP ou LUZ e toque ARREMESSAR. É necessário comprar a granada na preparação. A contagem mostra o estoque de cada tipo.
- PC: WASD/setas movem, mouse mira, clique esquerdo atira, R recarrega, F fixa/libera a mira, E alterna o tipo de granada, Q arremessa. Esc pausa.

## Regras e equipamentos

- Vence quem conquistar 10 rodadas. Cada rodada tem 20 segundos de preparação, 3 segundos de contagem e até 90 segundos de combate.
- Saldo inicial de $1.000. Ao terminar a rodada, cada jogador recebe $800; o vencedor recebe mais $400. Empate não dá ponto nem bônus.
- 12 armas: pistolas Atlas/Veloz/Titã; submetralhadoras Vetor/Compacta/Precisão; fuzis Sentinela/Assalto/Ágil; snipers Vigia/Batedor/Colosso.
- Dois capacetes e dois coletes, com proteção que se desgasta ao absorver dano e penalidade de peso.
- Granada explosiva e de luz. Podem atingir quem lançou. Paredes bloqueiam os efeitos.
- O inimigo só aparece na visão e quando não está atrás de obstáculo. Granada de luz temporariamente impede enxergá-lo.
- Compras valem para a rodada atual. Trocar um item durante a preparação devolve o gasto anterior do mesmo slot. Dinheiro não gasto permanece.

## Limites desta versão web

O modo disponível pelo HTML é contra bot. Publicar o arquivo em um site ou convertê-lo em um APK genérico não adiciona PvP Bluetooth nem PvP pela internet. Para Bluetooth, use o projeto Android completo fornecido separadamente e gere o aplicativo; ele ainda precisa de validação em dois celulares.

Os testes automáticos validam lógica de combate, economia, equipamentos, granadas, visão, analógico único, mira fixa, recarga, escolha de granada e troca de mensagens. Não houve teste visual em navegador ou de toque em aparelho físico neste ambiente.
