BlockRealm: Legacy 4.0.0 PWA

Serve this directory through HTTPS or localhost. Opening index.html directly works for play, but browser installation and offline service-worker caching require an HTTP(S) origin.

Recommended mobile settings:
- Landscape orientation
- Reimagined preset
- View distance 2
- Render scale 80%
- Adaptive Quality enabled

This project is original and is not affiliated with Mojang or Microsoft.
