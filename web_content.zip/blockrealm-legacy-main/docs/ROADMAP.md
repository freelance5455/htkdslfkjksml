# Roadmap

## Stability

- Rebuild the APK through standard Android Gradle tooling
- Add physical-device smoke tests
- Add automated WebView startup diagnostics
- Expand crash and error reporting

## Gameplay

- More creatures and improved AI
- Farming and food progression
- Chests and expanded storage
- More crafting and smelting recipes
- Structures, ruins, and biome landmarks
- Improved combat and item drops

## Rendering

- Better godray occlusion
- Refined water and cloud rendering
- Dynamic shadow options
- More scalable shader quality levels
- Device-specific performance presets

## World systems

- Larger biome variety
- Better cave networks
- Rivers and coastlines
- Save migration and versioning
- Optional finite-world mode

## Community

- Public issue templates
- Contributor documentation
- Reproducible release builds
- GitHub Pages playable demo
- Signed release checksums
