# Frequently Asked Questions

## What is BlockRealm?

BlockRealm is an open-source, mobile-first voxel survival sandbox built with JavaScript and WebGL. It features procedural terrain, crafting, survival systems, configurable shaders, offline PWA support, and an Android launcher project.

## Is BlockRealm Minecraft?

No. BlockRealm is an independent original voxel sandbox project. It is not affiliated with Mojang Studios or Microsoft.

## Can it run on mobile?

Yes. The browser/PWA build is designed for mobile controls and has rendered successfully on a Realme 13 Pro+ 5G. Landscape orientation is recommended.

## Does it work offline?

Yes. The PWA can cache the game for offline use after installation. The standalone build also contains local assets.

## Why is the APK marked experimental?

An earlier APK wrapper displayed a black screen because the packaged launcher did not match the maintainable Android source project. The web build works, but the APK should be rebuilt from the Android Studio project and tested on physical devices before being called stable.

## Does it support shaders?

Yes. BlockRealm includes compatibility, reimagined, cinematic, and shader-disabled modes so users can choose between performance and visual quality.

## Can I contribute?

Yes. Read `CONTRIBUTING.md`, open an issue for significant changes, and submit focused pull requests.

## What license does it use?

The source code is licensed under Apache License 2.0. The BlockRealm name, logo, and branding are not automatically granted for unrestricted reuse.
