# Contributing

1. Fork the repository and create a focused branch.
2. Keep changes small and explain the gameplay or rendering impact.
3. Run JavaScript syntax checks before opening a pull request.
4. Do not commit generated build folders, signing keys, keystores, or secrets.
5. Clearly mark files that substantially modify existing Apache-2.0 licensed code.
