# Changelog

## 4.0.0

- Open-source initial release
- Procedural streamed voxel worlds
- Survival inventory, crafting, furnaces, creatures, and shaders
- PWA and Android Studio packaging
- Documented experimental APK launcher status
