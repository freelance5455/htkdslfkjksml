@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle 8.13 is required. Open android/ in Android Studio or install Gradle 8.13.
exit /b 1
