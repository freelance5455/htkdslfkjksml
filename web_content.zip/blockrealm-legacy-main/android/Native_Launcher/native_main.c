/* DISABLED: BlockRealm now launches through MainActivity.java.
 * The old NativeActivity/WebView bridge caused ANRs on some Android/MIUI devices.
 * Kept for historical reference; it is intentionally not part of the Gradle app. */
