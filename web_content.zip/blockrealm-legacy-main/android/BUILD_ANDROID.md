# Building fatihmc / BlockRealm Legacy

This source has been changed to use a plain `Activity + WebView` launcher rather than the old NativeActivity bridge.
It is intended for Android 11 / MIUI 12.5 compatibility.

## Build

Open the `android` directory in Android Studio and run:

`./gradlew assembleDebug`

The APK will be under `app/build/outputs/apk/debug/`.

If Gradle Wrapper files are missing, Android Studio can regenerate them, or install Gradle 8.13 and run:

`gradle assembleDebug`

## Changes

- Application label: `fatihmc`
- Direct offline `file:///android_asset/index.html` loading
- No `WebViewAssetLoader`
- No forced WebView hardware layer
- Android mode automatically enables the game's low-risk renderer/safe mode
- Removed `powerPreference: high-performance` from WebGL initialization
- Old NativeActivity launcher disabled
