# Notice

BlockRealm: Legacy is an original voxel-survival project. It is not affiliated with or endorsed by Mojang Studios or Microsoft. The project intentionally uses original procedural textures, generated audio, original creature names and original branding. “Complementary Reimagined” is used only as a user-provided visual reference; no code or assets from that shader pack are included.
