package com.gamerzartist.blockrealm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Simple Android 11-compatible launcher.
 *
 * Deliberately avoids WebViewAssetLoader and the old NativeActivity launcher.
 * The game is fully offline, so loading directly from android_asset is the
 * most conservative path for older/MIUI WebView implementations.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "BlockRealm";
    private static final String GAME_URL =
            "file:///android_asset/index.html?android=1&build=40000&safe=1";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private FrameLayout root;
    private WebView webView;
    private TextView status;
    private boolean pageFinished;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Let Android choose the compatible hardware renderer. Do not force a
        // WebView hardware layer; this avoids several MIUI/WebView GPU crashes.
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);

        buildSurface();
        createGameWebView();
        enterImmersiveMode();

        // If the page never finishes, show a useful diagnostic instead of an
        // apparently frozen black screen.
        mainHandler.postDelayed(() -> {
            if (!pageFinished && webView != null) {
                showStatus("BlockRealm yükleniyor…\n\nAndroid System WebView/Chrome güncel değilse güncelleyin.");
            }
        }, 8000L);
    }

    private void buildSurface() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 14, 12));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(15f);
        status.setGravity(Gravity.CENTER);
        status.setPadding(36, 36, 36, 36);
        status.setText("FATIHMC\n\nBlockRealm başlatılıyor…");
        root.addView(status, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void createGameWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 14, 12));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setKeepScreenOn(true);
        // Keep the WebView visible from the beginning. The HTML boot screen
        // handles loading, so Android never leaves an invisible view behind.
        webView.setVisibility(View.VISIBLE);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                Log.println(priority(message.messageLevel()), TAG,
                        message.message() + " @" + message.sourceId() + ":" + message.lineNumber());
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageFinished = true;
                status.setVisibility(View.GONE);
                enterImmersiveMode();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request == null || request.isForMainFrame()) {
                    showStatus("Oyun açılamadı.\n\n" +
                            (error == null ? "Bilinmeyen WebView hatası." : error.getDescription()));
                }
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        webView.loadUrl(GAME_URL);
    }

    private void showStatus(String text) {
        if (status == null) return;
        status.setText("FATIHMC\n\n" + text);
        status.setVisibility(View.VISIBLE);
        if (webView != null) webView.bringToFront();
        if (status.getParent() == root) status.bringToFront();
    }

    private static int priority(ConsoleMessage.MessageLevel level) {
        switch (level) {
            case ERROR: return Log.ERROR;
            case WARNING: return Log.WARN;
            case LOG: return Log.INFO;
            case TIP: return Log.DEBUG;
            default: return Log.VERBOSE;
        }
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "window.BlockRealmAndroidBack ? window.BlockRealmAndroidBack() : false",
                result -> {
                    if (!"true".equals(result)) super.onBackPressed();
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        enterImmersiveMode();
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "window.BlockRealmAndroidPause && window.BlockRealmAndroidPause()", null);
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
