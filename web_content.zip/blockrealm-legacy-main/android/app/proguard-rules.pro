# BlockRealm keeps its launcher deliberately small and unobfuscated.
