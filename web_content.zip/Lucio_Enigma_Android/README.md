# Lucio y el Enigma de las Tildes — Proyecto Android

Este proyecto envuelve la versión HTML del juego en una aplicación Android (WebView) e incorpora las cuatro ilustraciones PNG.

## Compilar la APK
1. Instala Android Studio y los componentes Android SDK 35 y JDK 17.
2. Abre la carpeta `Lucio_Enigma_Android` en Android Studio.
3. Espera a que termine la sincronización de Gradle.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará la APK en `app/build/outputs/apk/debug/app-debug.apk`.

## Música de fondo
- El archivo es `app/src/main/assets/musica_fondo.wav`: un loop de 28 s que se repite sin cortes.
- Empieza con el primer toque en la pantalla, porque Android no deja sonar audio antes de que el usuario toque algo.
- El botón de volumen de arriba apaga y prende los efectos y la música. La música se pausa cuando la app pasa a segundo plano.
- Para cambiar el volumen o el archivo, editar `MUSICA_FONDO` en `index.html` (sección "3b. MÚSICA DE FONDO EN LOOP").
- `MainActivity.kt` activa `allowFileAccessFromFileURLs` para que la página pueda leer el WAV y repetirlo con Web Audio sin cortes.

## Importante
- El HTML y las imágenes se incluyen dentro de la aplicación.
- La versión actual usa Tailwind CSS, Google Fonts y Font Awesome desde CDN; por eso necesita internet para cargar esos recursos externos y no es completamente offline todavía.
- La configuración de compilación es un proyecto preparado para Android Studio; no se adjunta una APK ya compilada.
