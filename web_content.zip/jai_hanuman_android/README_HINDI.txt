Jai Hanuman Trading Android project

यह APK नहीं है; यह Android ऐप का source project है, जिसमें आपकी index.html शामिल है।
APK बनाने के लिए Android SDK और Gradle वाले build environment की जरूरत है।
इस ZIP को Android Studio/संगत cloud build service में खोलकर build करना होगा।

Project: app/src/main/assets/index.html में आपकी बिलिंग HTML फाइल है।
ध्यान दें: बिल स्थानीय WebView storage में सेव होंगे; ऐप का data मिटाने पर बिल मिट सकते हैं। नियमित backup/export करें।
