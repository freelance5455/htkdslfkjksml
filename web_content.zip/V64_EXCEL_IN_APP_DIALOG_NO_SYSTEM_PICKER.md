# V64 Excel in-app dialog picker

Version 2.30 / versionCode 34.

Choose File no longer launches a second Activity or any Android DocumentsUI/system picker. The WebView file chooser callback and AndroidDPM bridge both open an AlertDialog directly inside MainActivity. The dialog lists .xlsx/.csv/.txt files from MediaStore.Downloads and returns the selected content URI to the WebView. Legacy ACTION_OPEN_DOCUMENT/ACTION_GET_CONTENT/ACTION_PICK/ACTION_CREATE_DOCUMENT import paths were removed.
