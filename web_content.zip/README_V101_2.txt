CryptoPulse V101.2
- Robust pull-to-refresh for Android WebView using capture-phase touch events.
- Refresh no longer reloads the entire page; it restarts the shared LBank hub and refreshes the active chart.
- Pull indicator remains visible during refresh and reports whether live data arrived.
- LBank V2 market WebSocket uses the documented endpoint wss://api.lbank.info/ws/V2/.
