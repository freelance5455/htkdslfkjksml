CYBER CRASH V1 — RIFKI DEVELOPER
Peningkatan source dari proyek YXC V5.

Pembaruan:
- Tema antarmuka ungu neon terinspirasi gambar referensi.
- Soundtrack dasar dari video pertama yang diberikan (base_theme.mp3).
- Tombol Sound ON/OFF dan pemilihan musik lokal.
- Sapaan suara Indonesia memakai Android/WebView Speech Synthesis (suara tersedia bergantung perangkat).
- Tombol tes suara AI dan pengaturan kecepatan bicara.
- Robot asisten memakai sapaan suara yang sama.
- Fitur simulasi tetap sepenuhnya lokal/offline; tidak mengirim pesan, menargetkan nomor/grup, atau membuat perangkat lain crash.

Catatan:
- Akun dan papan chat tetap tersimpan lokal di perangkat, bukan sistem multiuser/server.
- ZIP ini adalah source Android Studio, bukan APK yang sudah ditandatangani.
- Buka folder CyberCrashAndroid di Android Studio, lalu Build > Build APK(s).
