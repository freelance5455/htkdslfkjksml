윙키 LIVE Android Studio 프로젝트

이 프로젝트는 현재 제작된 윙키 LIVE 웹 화면을 Android WebView 앱으로 감싸는 기본 프로젝트입니다.
아직 APK 바이너리는 아닙니다.

APK 만들기:
1. PC에 Android Studio와 Android SDK를 설치합니다.
2. Android Studio에서 이 폴더를 Open 합니다.
3. Gradle Sync가 끝날 때까지 기다립니다.
4. Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 생성된 app-debug.apk를 Android 휴대폰으로 옮겨 설치합니다.

주의:
- 마이크 권한은 Android에서 허용해야 합니다.
- 이 버전의 방송 시작은 로컬 미리보기이며 실제 인터넷 생중계가 아닙니다.
- 공개 라이브 방송에는 별도의 스트리밍 서버, 계정, 채팅 서버, 안전·신고·차단 기능이 필요합니다.
- 배포용 APK는 서명 및 개인정보처리방침 등 추가 준비가 필요합니다.
