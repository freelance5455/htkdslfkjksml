ہرن دوڑ (Hiran Run) — Subway Surfers جیسی گیم
=============================================
ہرن ٹرین کی چھتوں پر بھاگتا ہے، چیتا پیچھے آتا ہے۔

کنٹرول
------
بائیں/دائیں سوائپ = لین بدلیں
اوپر سوائپ (یا ٹیپ) = چھلانگ
دو بار رکاوٹ سے ٹکرائے تو چیتا پکڑ لیتا ہے۔ 9 سیکنڈ بعد خطرہ کم ہو جاتا ہے۔

پہلے فون کے براؤزر میں ٹیسٹ کریں
--------------------------------
web/index.html کو Chrome میں کھولیں۔ (کمپیوٹر پر: تیر کی کیز اور Space)

APK بنانے کے دو طریقے
----------------------
طریقہ 1 (آسان، بغیر کوڈنگ):
  web فولڈر سے index.html کسی آن لائن "HTML to APK" ٹول
  (مثلاً WebIntoApp یا Median) میں اپلوڈ کریں۔ APK مل جائے گی۔

طریقہ 2 (Android Studio):
  1) Android Studio انسٹال کریں۔
  2) File > Open > اسی HiranRun فولڈر کو کھولیں۔ Gradle Sync ہونے دیں۔
  3) Build > Build Bundle(s) / APK(s) > Build APK(s)
  4) APK یہاں ملے گی: app/build/outputs/apk/debug/app-debug.apk

گیم کا کوڈ: app/src/main/assets/index.html
(ہرن کی ڈرائنگ: deer() فنکشن، چیتے کی: cheetah() فنکشن)
