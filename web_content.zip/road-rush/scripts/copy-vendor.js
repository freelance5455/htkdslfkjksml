// Copies three.js out of node_modules so the game works fully offline inside the app.
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'node_modules', 'three', 'build', 'three.min.js');
const dst = path.join(__dirname, '..', 'www', 'vendor', 'three.min.js');
if (!fs.existsSync(src)) { console.warn('three.js not installed yet. Run: npm install'); process.exit(0); }
fs.copyFileSync(src, dst);
console.log('Copied three.min.js -> www/vendor/');
