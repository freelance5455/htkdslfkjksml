// Locks the Android app to portrait. Safe to run repeatedly.
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(f)) { console.warn('No android project yet. Run: npm run android:add'); process.exit(0); }
let x = fs.readFileSync(f, 'utf8');
if (!/screenOrientation/.test(x)) {
  x = x.replace('<activity', '<activity\n            android:screenOrientation="portrait"');
  fs.writeFileSync(f, x);
  console.log('Locked orientation to portrait.');
} else console.log('Orientation already set.');
