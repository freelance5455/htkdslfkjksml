# Road Rush: Android / Google Play project

This folder wraps the game (`www/index.html`) into an Android app using **Capacitor**.
The game runs fully offline: three.js is copied into `www/vendor/` by `npm install`.

## 0. Read this before you publish (important)

1. **Trademark / IP risk.** The game currently uses the years 1985 / 1955 / 2015, the "88 MPH" time-travel trigger,
   fire trails, and a stainless gull-wing sports car. Together these closely imitate a famous film franchise and a real
   car brand. Google Play can reject or remove apps for this (Intellectual Property policy). Before publishing:
   - never use the words "DeLorean" or the film's name in the title, description, screenshots or in-game text;
   - ideally rename the eras (e.g. "Summer Coast", "Autumn Past", "Winter Future", "Neo City 2100"), change the
     trigger speed/text, and give the car its own design. Ask Claude to do this pass for you.
2. **Package name.** In `capacitor.config.json` change `com.CHANGEME.roadrush` to your own unique ID
   (e.g. `com.yourname.roadrush`). It can never be changed after you publish.
3. **Privacy policy URL.** Play requires one. Edit `store/PRIVACY_POLICY.md` and host it somewhere public
   (GitHub Pages, your site, a public Notion page).

## 1. One-time setup on your computer

- Install Node.js (current LTS) and Android Studio (it bundles the JDK and Android SDK).
- In Android Studio's SDK Manager install the **Android 16 (API 36)** platform: Google Play requires new apps and
  updates to target API 36 or higher (checked Oct 2026: https://developer.android.com/google/play/requirements/target-sdk).

## 2. Build the Android project

```bash
npm install            # installs Capacitor + three.js, copies three.min.js into www/vendor
npm run android:add    # creates the android/ folder and locks portrait orientation
npm run assets         # generates all launcher icons + splash screens from /assets
npm run sync           # re-run any time you change www/
npm run open           # opens the project in Android Studio
```

After `android:add`, open `android/variables.gradle` and confirm `targetSdkVersion` is 36 or higher
(the latest Capacitor should already do this; if not, update Capacitor with `npm i @capacitor/core@latest @capacitor/android@latest @capacitor/cli@latest`).

Test on a real phone: plug it in (USB debugging on) and press Run in Android Studio.

## 3. Version numbers

In `android/app/build.gradle` set `versionCode` (a whole number; **+1 for every upload**) and `versionName` (e.g. "1.0.0").

## 4. Create a signed release bundle (.aab)

1. Android Studio -> **Build -> Generate Signed App Bundle / APK -> Android App Bundle**.
2. Create a new keystore (this is your *upload key*). **Back it up and never commit it to git.**
3. Choose the **release** variant and finish. The `.aab` ends up in `android/app/release/`.
4. In Play Console keep **Play App Signing** on (default).

## 5. Google Play Console checklist

- Create a developer account (one-time registration fee, ID verification).
- **New personal accounts** (created after 13 Nov 2023) must run a **closed test with at least 12 testers opted in
  for 14 continuous days** before applying for production access. Organization accounts are exempt.
  Plan roughly 3 weeks for a first launch. Use *Internal testing* (up to 100 testers, no review) for quick checks.
- Create the app, then fill in: store listing (`store/STORE_LISTING.md`), privacy policy URL, **Data safety**
  (answers in STORE_LISTING.md), **Content rating** questionnaire, **Ads** (none), **Target audience**, app access (none needed).
- Upload graphics: `store/icon-512.png` (icon), `store/feature-graphic-1024x500.png` (feature graphic).
  **Screenshots:** take real ones from your phone (at least 2; 4-8 recommended), portrait.
- Upload the `.aab` to your closed test track, add testers, wait out the 14 days, then apply for production.

## 6. Updating the game later

Edit `www/index.html` -> `npm run sync` -> raise `versionCode` -> build a new signed .aab -> upload.

## 7. Notes

- The game saves your best score with `localStorage` on the device only; it makes no network requests.
- If `www/vendor/three.min.js` is missing the game still works with a flat 2D car instead of the 3D model.
- three.js is MIT licensed (https://threejs.org). Capacitor is MIT licensed.
- Alternative route (Trusted Web Activity / Bubblewrap) needs the game hosted on HTTPS; Capacitor is simpler because
  everything is bundled in the app.
