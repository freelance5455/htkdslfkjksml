# Play Store listing (draft: edit freely)

**App name (max 30):** Road Rush: Time Drive

**Short description (max 80):** Dodge traffic and drive through eras, skies and a glowing neon future.

**Full description (max 4000):**

Hit the road and race through time!

Steer your sports car, dodge traffic, cones, trucks and storm clouds, and reach top speed to jump to a new era.
Each era has its own world: sunny palm-lined coasts, warm autumn boulevards, snowy winter streets and a glowing
neon megacity where flying cars fill the sky.

- Simple one-finger steering: just drag
- Drive through beaches, an ocean bridge, a busy downtown with a passing metro, and more
- A flying sky section with drones and storms
- Day turns to night, trees sway in the wind, headlights light the road
- 3D car on a classic top-down road
- Works offline, no ads, no sign-up

How far can you go? Beat your best distance!

(Do NOT mention any film, franchise or car brand names here.)

**Category:** Games -> Racing
**Tags:** Racing, Arcade, Casual

## Data safety form answers
- Does your app collect or share any required user data types? **No**
- Is all user data encrypted in transit? **Not applicable (no data collected)**
- Do you provide a way for users to request data deletion? **Not applicable**

## Other forms
- Ads: **No ads**
- Content rating: answer the IARC questionnaire honestly (cartoon car crashes with no injuries; no violence, gambling, or user-generated content)
- Target audience: choose 13+ or all ages after reviewing Play's families policy (picking under-13 adds extra requirements)
- App access: **All functionality available without special access**

## Graphics
- App icon 512x512: `icon-512.png`
- Feature graphic 1024x500: `feature-graphic-1024x500.png`
- Phone screenshots: take 4-8 portrait screenshots from your phone (road, beach, bridge, flying section, neon city)
