# Privacy Policy for Road Rush

_Last updated: [DATE]_

Road Rush ("the app") is a game published by [YOUR NAME OR COMPANY].

**Data we collect:** none. The app does not collect, transmit, sell or share personal information.

**Data stored on your device:** the app stores your best score locally on your device. It never leaves your device
and is removed when you uninstall the app.

**Network access:** the app works offline and does not connect to any servers.

**Ads and analytics:** the app contains no ads and no third-party analytics or tracking.

**Children:** the app does not knowingly collect information from anyone, including children.

**Changes:** if this policy changes, the updated version will be posted at this address.

**Contact:** [YOUR EMAIL]
