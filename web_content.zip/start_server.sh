#!/bin/sh
cd "$(dirname "$0")"
PORT=8158
nohup python3 -m http.server "$PORT" --bind 0.0.0.0 > server.log 2>&1 &
echo $! > server.pid
echo "Notepad server running at http://localhost:$PORT/"
