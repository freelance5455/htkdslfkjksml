# Total Shop Calculator (Android)

A simple offline Android app for a shop counter. Enter individual item amounts, see the running total, enter money received, and see change to return or balance still due.

## Build an APK using Android Studio
1. Install Android Studio on a computer and allow it to install Android SDK Platform 35 and a compatible Android Gradle Plugin.
2. Open this `TotalShopCalculator` folder as a project.
3. Wait for Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and open it to install. You may need to allow installing apps from that file manager.

This project uses a local HTML interface in an Android WebView and does not need internet access at runtime. The app calculates amounts only; it does not process UPI/card payments or save sales history.
