ZFMA TV — version web
Ouvre index.html dans un navigateur moderne.
Les chaînes SNRT et MEDI1TV utilisent leurs pages/lecteurs reliés depuis les sites des diffuseurs. Certains diffuseurs peuvent bloquer l'intégration iframe ou appliquer des limites géographiques.
2M : son application officielle my2M annonce le direct; aucun lecteur web officiel intégrable n'a été identifié.
CANAL+ FOOT : accès via le service officiel et l'abonnement requis; aucun flux provenant d'un serveur tiers n'est inclus.
EPG : importe un fichier XMLTV correspondant aux chaînes. M3U : importe des flux personnels autorisés.
Cette version est une interface web, pas un APK Android natif.
