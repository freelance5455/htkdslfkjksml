package com.teacher.app;

import android.app.*;
import android.os.*;
import android.print.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> uploadCallback;
    static final int FILE_REQ=1001;

    @Override public void onCreate(Bundle b){ super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web=new WebView(this); setContentView(web); configure();
        web.loadUrl("file:///android_asset/index.html");
    }
    void configure(){
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setDefaultTextEncodingName("UTF-8");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(uploadCallback!=null) uploadCallback.onReceiveValue(null); uploadCallback=cb;
                try{ Intent i=p.createIntent(); startActivityForResult(i,FILE_REQ); }catch(Exception e){ uploadCallback=null; return false; } return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Object(){ @JavascriptInterface public void print(){ runOnUiThread(()->doPrint()); } },"AndroidPrint");
        web.setOnLongClickListener(v->false);
        web.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{
            try{ Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url)); startActivity(i); }catch(Exception ignored){}
        });
    }
    void doPrint(){
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        String job="تطبيق الأستاذ";
        pm.print(job, web.createPrintDocumentAdapter(job), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
    }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==FILE_REQ&&uploadCallback!=null){ Uri[] a=null; if(c==RESULT_OK&&d!=null){ if(d.getClipData()!=null){int n=d.getClipData().getItemCount();a=new Uri[n];for(int i=0;i<n;i++)a[i]=d.getClipData().getItemAt(i).getUri();} else if(d.getData()!=null)a=new Uri[]{d.getData()};} uploadCallback.onReceiveValue(a); uploadCallback=null; }}
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
