// Empty initial data file. The app stores changes locally in Android WebView storage.
window.__TA_SEED__ = {st:[], log:[], last:0, ts:0};
