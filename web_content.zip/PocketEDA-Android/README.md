# PocketEDA for Android

A WebView wrapper around the PocketEDA web app. The whole app is `app/src/main/assets/index.html`
and runs offline. Edit that file to change the app; the Java code only hosts it and handles file opening.

## Build the APK in Android Studio
1. Install Android Studio (Koala or newer) and open this folder.
2. Let Gradle sync (it downloads Gradle 8.7, Android Gradle Plugin 8.5.2 and SDK 34 if missing).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK is at `app/build/outputs/apk/debug/app-debug.apk`. Copy it to the phone and install it
   (allow "Install unknown apps" for your file manager).

If sync complains about the Gradle wrapper, run `gradle wrapper --gradle-version 8.7` once, or set
Android Studio's Gradle to the bundled version.

## Build without Android Studio (GitHub Actions)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the Actions tab and run "Build APK" (it also runs on every push).
3. Download the `PocketEDA-debug-apk` artifact, unzip it and install `app-debug.apk`.

## Signed release build (for sharing or a store)
Create a keystore (Build > Generate Signed Bundle / APK) and choose APK > release.
The debug APK works fine for personal use.

## Notes
- minSdk 26 (Android 8.0), targetSdk 34, package `app.pocketeda`.
- Designs autosave inside the app. Export gives a JSON box to copy; Open files reads KiCad and Gerber files.
