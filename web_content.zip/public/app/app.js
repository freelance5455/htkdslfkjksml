(() => {
'use strict';
const API = '../api/index.php';
const CUR = '؋'; // currency symbol shown next to amounts; change if needed
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => Number(n || 0).toLocaleString('en-US', {maximumFractionDigits: 2}) + ' ' + CUR;
const day = d => d ? String(d).slice(0, 10) : '—';
const ST = {active: 'فعال', suspended: 'بند', expired: 'پای ته رسېدلی'};
const SV = {hotspot: 'Hotspot', pppoe: 'PPPoE', both: 'دواړه'};
const TABS = [['dash', 'ډشبورډ', '▦'], ['cust', 'مشتریان', '☻'], ['pack', 'پکیجونه', '❖'], ['pay', 'تادیې', '＄']];

let csrf = '', tab = 'dash', appName = 'احمدي وای فای';
let custFilter = '', custQuery = '', timer = null;

async function api(route, {method = 'GET', data, params = {}} = {}) {
  const opt = {method, credentials: 'same-origin', headers: {Accept: 'application/json'}};
  if (method !== 'GET') {
    opt.headers['Content-Type'] = 'application/json';
    opt.headers['X-CSRF-Token'] = csrf;
    opt.body = JSON.stringify(data || {});
  }
  let res;
  try { res = await fetch(API + '?' + new URLSearchParams({r: route, ...params}), opt); }
  catch { throw new Error('له سرور سره اړیکه نشته'); }
  let j = {};
  try { j = await res.json(); } catch { /* ignore */ }
  if (res.status === 401 && route !== 'login') { boot(); throw new Error(j.error || 'لومړی ننوځئ'); }
  if (!res.ok) throw new Error(j.error || 'تېروتنه رامنځته شوه');
  return j;
}

function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg; t.className = bad ? 'bad' : ''; t.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(() => { t.hidden = true; }, 2800);
}

function openSheet(html, mount) {
  $('#sheet').innerHTML = html;
  $('#sheet').hidden = false; $('#sheet-bg').hidden = false;
  if (mount) mount($('#sheet'));
}
function closeSheet() { $('#sheet').hidden = true; $('#sheet-bg').hidden = true; $('#sheet').innerHTML = ''; }
$('#sheet-bg').addEventListener('click', closeSheet);

async function boot() {
  closeSheet();
  try {
    const s = await (await fetch(API + '?r=session', {credentials: 'same-origin'})).json();
    csrf = s.csrf; appName = s.app || appName;
    s.auth ? renderShell() : renderLogin();
  } catch {
    $('#app').innerHTML = '<div class="login"><div class="card"><p class="err">له سرور سره اړیکه نشته. انټرنېټ وګورئ.</p><button class="btn" id="retry">بیا هڅه</button></div></div>';
    $('#retry').onclick = boot;
  }
}

function renderLogin() {
  $('#app').innerHTML = `<div class="login"><div class="card">
    <h1>${esc(appName)}</h1><p style="color:var(--muted);margin:0 0 16px">مدیریت ته ننوتل</p>
    <p class="err" id="err"></p>
    <label>ایمیل</label><input id="em" type="email" dir="ltr" autocomplete="username" inputmode="email">
    <label>پاسورډ</label><input id="pw" type="password" dir="ltr" autocomplete="current-password">
    <button class="btn" id="go">ننوتل</button></div></div>`;
  const go = async () => {
    const b = $('#go'); b.disabled = true; $('#err').textContent = '';
    try {
      const r = await api('login', {method: 'POST', data: {email: $('#em').value, password: $('#pw').value}});
      csrf = r.csrf; renderShell();
    } catch (e) { $('#err').textContent = e.message; b.disabled = false; }
  };
  $('#go').onclick = go;
  $('#pw').addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
}

function renderShell() {
  $('#app').innerHTML = `<header class="top"><div><h1>${esc(appName)}</h1><small>ISP MANAGER</small></div><button id="out">وتل</button></header>
    <main id="view"></main>
    <nav class="tabs"><div class="in">${TABS.map(([k, l, i]) => `<button data-t="${k}"><span>${i}</span>${l}</button>`).join('')}</div></nav>`;
  $('#out').onclick = async () => { try { await api('logout', {method: 'POST'}); } catch {} boot(); };
  document.querySelectorAll('nav.tabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; load(); });
  load();
}

async function load() {
  document.querySelectorAll('nav.tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === tab));
  const v = $('#view'); v.innerHTML = '<div class="empty">…</div>';
  document.querySelectorAll('.fab').forEach(f => f.remove());
  try {
    if (tab === 'dash') await viewDash(v);
    else if (tab === 'cust') await viewCust(v);
    else if (tab === 'pack') await viewPack(v);
    else await viewPay(v);
  } catch (e) { if (e.message) { v.innerHTML = `<div class="empty">${esc(e.message)}</div>`; } }
}

function fab(fn) {
  const b = document.createElement('button');
  b.className = 'fab'; b.textContent = '+'; b.setAttribute('aria-label', 'نوی');
  b.onclick = fn; document.body.appendChild(b);
}

/* ---------- Dashboard ---------- */
async function viewDash(v) {
  const d = await api('dashboard');
  const st = (n, l, c = '') => `<div class="card stat ${c}"><div class="n">${n}</div><div class="l">${l}</div></div>`;
  v.innerHTML = `<div class="grid">
    ${st(d.total, 'ټول مشتریان')}${st(d.active, 'فعال', 'ok')}
    ${st(d.expired, 'پای ته رسېدلي', 'warn')}${st(d.suspended, 'بند شوي', 'bad')}
    ${st(d.expiring_soon, 'په ۷ ورځو کې پای ته رسېږي', 'warn')}${st(money(d.revenue_today), 'نن عاید')}
  </div>
  <div class="card stat"><div class="n">${money(d.revenue_month)}</div><div class="l">د دې میاشتې عاید</div></div>
  <h2>وروستۍ تادیې</h2><div class="list">${d.recent.length ? d.recent.map(p =>
    `<div class="item"><div><div class="t">${esc(p.full_name)}</div><div class="s">${day(p.paid_at)}</div></div><div class="amt">${money(p.amount)}</div></div>`).join('') : '<div class="empty">تادیه نشته</div>'}</div>`;
}

/* ---------- Customers ---------- */
async function viewCust(v) {
  v.innerHTML = `<input class="search" id="q" placeholder="د نوم، username یا شمېرې لټون" value="${esc(custQuery)}">
    <div class="filters">${[['', 'ټول'], ['active', 'فعال'], ['expired', 'پای ته رسېدلي'], ['suspended', 'بند']].map(([k, l]) =>
      `<button data-f="${k}" class="${custFilter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
    <div class="list" id="cl"></div>`;
  $('#q').oninput = e => { custQuery = e.target.value; clearTimeout(timer); timer = setTimeout(fillCust, 300); };
  v.querySelectorAll('.filters button').forEach(b => b.onclick = () => { custFilter = b.dataset.f; viewCust(v); });
  fab(() => custForm());
  await fillCust();
}

let custItems = [];
async function fillCust() {
  const r = await api('customers', {params: {q: custQuery, status: custFilter}});
  custItems = r.items;
  const l = $('#cl'); if (!l) return;
  l.innerHTML = custItems.length ? custItems.map((c, i) => `<button class="item" data-i="${i}">
    <div><div class="t">${esc(c.full_name)}</div><div class="s">${esc(c.username)} · ${esc(SV[c.service_type] || c.service_type)}</div></div>
    <span class="chip ${esc(c.status)}">${ST[c.status] || esc(c.status)}</span></button>`).join('') : '<div class="empty">مشتری ونه موندل شو</div>';
  l.querySelectorAll('button.item').forEach(b => b.onclick = () => custDetail(custItems[b.dataset.i]));
}

function custDetail(c) {
  const suspended = c.status === 'suspended';
  openSheet(`<h3>${esc(c.full_name)}</h3>
    <div class="kv"><span>Username</span><span dir="ltr">${esc(c.username)}</span></div>
    <div class="kv"><span>موبایل</span><span dir="ltr">${esc(c.phone || '—')}</span></div>
    <div class="kv"><span>ډول</span><span>${esc(SV[c.service_type] || c.service_type)}</span></div>
    <div class="kv"><span>پکیج</span><span>${esc(c.package_name || '—')}</span></div>
    <div class="kv"><span>پای نېټه</span><span>${day(c.expires_at)}</span></div>
    <div class="kv"><span>حالت</span><span class="chip ${esc(c.status)}">${ST[c.status] || esc(c.status)}</span></div>
    <div class="note">دا اپ یوازې د اپ ډیټابیس بدلوي؛ په MikroTik کې یوزر نه فعالوي او نه بندوي.</div>
    <button class="btn" id="renew">تادیه + نوی کول</button>
    <button class="btn sec ${suspended ? '' : 'red'}" id="tg">${suspended ? 'فعالول' : 'بندول'}</button>
    <button class="btn sec" id="cl">تړل</button>`, s => {
    s.querySelector('#cl').onclick = closeSheet;
    s.querySelector('#renew').onclick = () => payForm(c);
    s.querySelector('#tg').onclick = async () => {
      try { await api('customer_status', {method: 'POST', data: {id: c.id, status: suspended ? 'active' : 'suspended'}}); closeSheet(); toast('ثبت شو'); load(); }
      catch (e) { toast(e.message, true); }
    };
  });
}

async function custForm() {
  let packs = [];
  try { packs = (await api('packages')).items.filter(p => +p.active); } catch (e) { return toast(e.message, true); }
  openSheet(`<h3>نوی مشتری</h3><form id="f">
    <label>بشپړ نوم</label><input name="full_name" required>
    <label>موبایل</label><input name="phone" dir="ltr" inputmode="tel">
    <label>Username</label><input name="username" dir="ltr" required autocapitalize="off" autocorrect="off">
    <label>ډول</label><select name="service_type"><option value="hotspot">Hotspot</option><option value="pppoe">PPPoE</option></select>
    <label>پکیج</label><select name="package_id"><option value="">—</option>${packs.map(p => `<option value="${+p.id}">${esc(p.name)} — ${money(p.price)}</option>`).join('')}</select>
    <button class="btn" type="submit">ثبتول</button><button class="btn sec" type="button" id="x">لغوه</button></form>`, s => {
    s.querySelector('#x').onclick = closeSheet;
    submitForm(s.querySelector('#f'), 'customer_create', () => { tab = 'cust'; });
  });
}

function payForm(c) {
  openSheet(`<h3>تادیه — ${esc(c.full_name)}</h3><form id="f">
    <label>مبلغ (${CUR})</label><input name="amount" type="number" step="0.01" min="0.01" inputmode="decimal" dir="ltr" value="${c.package_price ? +c.package_price : ''}" required>
    <label>یادښت</label><input name="note">
    <label class="chk"><input type="checkbox" name="renew" ${c.package_id ? 'checked' : 'disabled'}> د پکیج مودې ته پای نېټه اوږده کړه</label>
    <button class="btn" type="submit">تادیه ثبتول</button><button class="btn sec" type="button" id="x">لغوه</button></form>`, s => {
    s.querySelector('#x').onclick = closeSheet;
    submitForm(s.querySelector('#f'), 'payment_create', () => {}, {customer_id: c.id});
  });
}

function submitForm(form, route, after, extra = {}) {
  form.onsubmit = async e => {
    e.preventDefault();
    const btn = form.querySelector('[type=submit]'); btn.disabled = true;
    const data = {...extra};
    new FormData(form).forEach((v, k) => { data[k] = v; });
    form.querySelectorAll('input[type=checkbox]').forEach(cb => { data[cb.name] = cb.checked; });
    try { await api(route, {method: 'POST', data}); closeSheet(); toast('ثبت شو'); after(); load(); }
    catch (err) { toast(err.message, true); btn.disabled = false; }
  };
}

/* ---------- Packages ---------- */
async function viewPack(v) {
  const r = await api('packages');
  v.innerHTML = `<div class="list">${r.items.length ? r.items.map(p => `<div class="item"><div>
    <div class="t">${esc(p.name)}</div>
    <div class="s">${esc(SV[p.service_type] || p.service_type)} · ${+p.validity_days} ورځې · ${+p.speed_down_kbps || '—'}/${+p.speed_up_kbps || '—'} kbps</div></div>
    <div class="amt">${money(p.price)}</div></div>`).join('') : '<div class="empty">پکیج نشته</div>'}</div>`;
  fab(() => openSheet(`<h3>نوی پکیج</h3><form id="f">
    <label>د پکیج نوم</label><input name="name" required>
    <label>ډول</label><select name="service_type"><option value="both">دواړه</option><option value="hotspot">Hotspot</option><option value="pppoe">PPPoE</option></select>
    <label>بیه (${CUR})</label><input name="price" type="number" step="0.01" min="0" inputmode="decimal" dir="ltr" required>
    <label>ورځې</label><input name="validity_days" type="number" min="1" value="30" dir="ltr" required>
    <label>Download kbps</label><input name="speed_down_kbps" type="number" min="0" value="2048" dir="ltr">
    <label>Upload kbps</label><input name="speed_up_kbps" type="number" min="0" value="1024" dir="ltr">
    <button class="btn" type="submit">پکیج ثبتول</button><button class="btn sec" type="button" id="x">لغوه</button></form>`, s => {
    s.querySelector('#x').onclick = closeSheet;
    submitForm(s.querySelector('#f'), 'package_create', () => {});
  }));
}

/* ---------- Payments ---------- */
async function viewPay(v) {
  const r = await api('payments');
  v.innerHTML = `<div class="list">${r.items.length ? r.items.map(p => `<div class="item"><div>
    <div class="t">${esc(p.full_name)}</div><div class="s">${day(p.paid_at)}${p.note ? ' · ' + esc(p.note) : ''}</div></div>
    <div class="amt">${money(p.amount)}</div></div>`).join('') : '<div class="empty">تادیه نشته</div>'}</div>`;
  fab(async () => {
    try {
      const cs = (await api('customers')).items;
      if (!cs.length) return toast('لومړی مشتری ثبت کړئ', true);
      openSheet(`<h3>نوې تادیه</h3><label>مشتری</label><select id="cs">${cs.map((c, i) => `<option value="${i}">${esc(c.full_name)} — ${esc(c.username)}</option>`).join('')}</select>
        <button class="btn" id="n">دوام</button><button class="btn sec" id="x">لغوه</button>`, s => {
        s.querySelector('#x').onclick = closeSheet;
        s.querySelector('#n').onclick = () => payForm(cs[+s.querySelector('#cs').value]);
      });
    } catch (e) { toast(e.message, true); }
  });
}

if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
boot();
})();
