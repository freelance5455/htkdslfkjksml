import React, { useState, useEffect } from 'react';
import { 
  Search, TrendingUp, Sparkles, CheckCircle2, AlertCircle, 
  Youtube, BarChart3, Lightbulb, Tag, Eye, ThumbsUp, 
  MessageSquare, Copy, Check, RefreshCw, Flame, Award,
  Compass, Sliders, ArrowUpRight, Play, Layers, Zap
} from 'lucide-react';

// --- KONFIGURASI GEMINI API ---
const apiKey = "";
const GEMINI_MODEL = "gemini-3-flash-preview";

// Fungsi utilitas untuk memanggil Gemini API dengan Exponential Backoff
async function fetchGeminiWithRetry(prompt, systemInstruction, responseSchema = null) {
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;
  
  const payload = {
    contents: [{ parts: [{ text: prompt }] }],
    systemInstruction: {
      parts: [{ text: systemInstruction }]
    }
  };

  if (responseSchema) {
    payload.generationConfig = {
      responseMimeType: "application/json",
      responseSchema: responseSchema
    };
  }

  let delay = 1000;
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      const text = result.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!text) throw new Error("Respons kosong dari AI");
      
      return responseSchema ? JSON.parse(text) : text;
    } catch (error) {
      if (attempt === 3) throw error;
      await new Promise(resolve => setTimeout(resolve, delay));
      delay *= 2;
    }
  }
}

// --- KOMPONEN GAUGE SKOR (MIRIP VIDIQ SCORE) ---
const ScoreGauge = ({ score, label, size = "md" }) => {
  const radius = size === "lg" ? 44 : 30;
  const stroke = size === "lg" ? 8 : 6;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const getColor = (val) => {
    if (val >= 75) return "#10b981"; // Emerald
    if (val >= 50) return "#f59e0b"; // Amber
    return "#ef4444"; // Red
  };

  const color = getColor(score);

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative flex items-center justify-center">
        <svg height={radius * 2} width={radius * 2} className="-rotate-90 transform">
          <circle
            stroke="#1e293b"
            fill="transparent"
            strokeWidth={stroke}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
          <circle
            stroke={color}
            fill="transparent"
            strokeWidth={stroke}
            strokeDasharray={circumference + ' ' + circumference}
            style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.8s ease-in-out' }}
            strokeLinecap="round"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
        </svg>
        <span 
          className={`absolute font-bold ${size === "lg" ? "text-xl" : "text-sm"}`}
          style={{ color }}
        >
          {score}
        </span>
      </div>
      {label && <span className="mt-1 text-xs font-medium text-slate-400">{label}</span>}
    </div>
  );
};

// --- APLIKASI UTAMA ---
export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [copiedText, setCopiedText] = useState(null);

  // State untuk Riset Kata Kunci
  const [kwInput, setKwInput] = useState('Tutorial AI untuk Pemula');
  const [kwLoading, setKwLoading] = useState(false);
  const [kwData, setKwData] = useState({
    keyword: "Tutorial AI untuk Pemula",
    overallScore: 78,
    searchVolume: 84,
    competition: 32,
    monthlySearches: "145,200",
    relatedKeywords: [
      { term: "cara menggunakan chatgpt bahasa indonesia", volume: 88, competition: 28, score: 82 },
      { term: "aplikasi ai terbaik 2026 gratis", volume: 92, competition: 45, score: 75 },
      { term: "belajar artificial intelligence dari nol", volume: 74, competition: 22, score: 79 },
      { term: "tools ai untuk konten kreator youtube", volume: 81, competition: 35, score: 77 },
      { term: "membuat video dengan ai otomatis", volume: 95, competition: 58, score: 69 }
    ],
    questions: [
      "Bagaimana cara mulai belajar AI tanpa coding?",
      "Apa saja aplikasi AI gratis yang wajib dicoba pemula?",
      "Bisakah menghasilkan uang dari YouTube menggunakan AI?"
    ]
  });

  // State untuk AI Idea Generator
  const [nicheInput, setNicheInput] = useState('Teknologi & Produktivitas');
  const [ideasLoading, setIdeasLoading] = useState(false);
  const [dailyIdeas, setDailyIdeas] = useState([
    {
      id: 1,
      title: "7 Website AI Rahasia yang Akan Menghemat 10 Jam Kerja Minggu Ini!",
      prediction: "Sangat Tinggi",
      score: 94,
      hook: "Mulai dengan menunjukkan hasil akhir dalam 5 detik pertama sebelum menjelaskan daftar website.",
      tags: ["ai tools", "produktivitas", "website rahasia", "teknologi 2026"]
    },
    {
      id: 2,
      title: "Saya Mencoba Hidup 24 Jam Hanya Menggunakan Asisten AI (Hasilnya Mengejutkan!)",
      prediction: "Tinggi",
      score: 86,
      hook: "Tantangan personal dengan elemen humor saat AI membuat keputusan yang aneh.",
      tags: ["tantangan 24 jam", "eksperimen ai", "vlog teknologi", "indonesia"]
    },
    {
      id: 3,
      title: "Jangan Beli Laptop Baru Sebelum Mengaktifkan 5 Fitur Tersembunyi Ini",
      prediction: "Tinggi",
      score: 81,
      hook: "Tunjukkan perbandingan kecepatan laptop sebelum dan sesudah optimasi.",
      tags: ["tips laptop", "windows 11", "percepat laptop", "tutorial pc"]
    }
  ]);

  // State untuk SEO Video Optimizer
  const [seoTitle, setSeoTitle] = useState('Cara Edit Video Cepat di CapCut PC untuk Pemula 2026');
  const [seoDesc, setSeoDesc] = useState('Di video ini kita akan belajar cara edit video cepat menggunakan CapCut PC dari awal sampai export. Cocok untuk YouTuber pemula yang ingin meningkatkan kualitas konten.');
  const [seoTags, setSeoTags] = useState(['capcut pc', 'tutorial edit video', 'edit video pemula', 'capcut indonesia', 'cara edit video youtube']);
  const [newTag, setNewTag] = useState('');
  const [seoOptimizing, setSeoOptimizing] = useState(false);

  // Fungsi Copy ke Clipboard (Sesuai aturan iFrame)
  const copyToClipboard = (text, id) => {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    try {
      document.execCommand('copy');
      setCopiedText(id);
      setTimeout(() => setCopiedText(null), 2000);
    } catch (err) {
      console.error('Gagal menyalin teks', err);
    }
    document.body.removeChild(textArea);
  };

  // Handler Riset Kata Kunci dengan Gemini
  const handleKeywordResearch = async (e) => {
    e.preventDefault();
    if (!kwInput.trim()) return;
    setKwLoading(true);

    try {
      const schema = {
        type: "OBJECT",
        properties: {
          keyword: { type: "STRING" },
          overallScore: { type: "INTEGER" },
          searchVolume: { type: "INTEGER" },
          competition: { type: "INTEGER" },
          monthlySearches: { type: "STRING" },
          relatedKeywords: {
            type: "ARRAY",
            items: {
              type: "OBJECT",
              properties: {
                term: { type: "STRING" },
                volume: { type: "INTEGER" },
                competition: { type: "INTEGER" },
                score: { type: "INTEGER" }
              }
            }
          },
          questions: {
            type: "ARRAY",
            items: { type: "STRING" }
          }
        },
        required: ["keyword", "overallScore", "searchVolume", "competition", "monthlySearches", "relatedKeywords", "questions"]
      };

      const prompt = `Analisis kata kunci YouTube berikut dalam Bahasa Indonesia: "${kwInput}". Berikan estimasi realistis untuk skor keseluruhan (0-100, tinggi berarti volume tinggi & kompetisi rendah), volume pencarian (0-100), skor kompetisi (0-100, rendah lebih baik), estimasi pencarian bulanan (format angka dengan koma), 5 kata kunci terkait yang relevan beserta metriknya, dan 3 pertanyaan yang sering dicari penonton terkait topik ini.`;
      const sysPrompt = "Anda adalah pakar SEO YouTube dan analis data seperti vidIQ. Berikan data analitik kata kunci yang akurat, strategis, dan relevan untuk pasar penonton Indonesia.";

      const result = await fetchGeminiWithRetry(prompt, sysPrompt, schema);
      setKwData(result);
    } catch (err) {
      console.error(err);
    } finally {
      setKwLoading(false);
    }
  };

  // Handler Generate Ide Harian dengan Gemini
  const handleGenerateIdeas = async (e) => {
    e.preventDefault();
    if (!nicheInput.trim()) return;
    setIdeasLoading(true);

    try {
      const schema = {
        type: "ARRAY",
        items: {
          type: "OBJECT",
          properties: {
            id: { type: "INTEGER" },
            title: { type: "STRING" },
            prediction: { type: "STRING" },
            score: { type: "INTEGER" },
            hook: { type: "STRING" },
            tags: { type: "ARRAY", items: { type: "STRING" } }
          },
          required: ["id", "title", "prediction", "score", "hook", "tags"]
        }
      };

      const prompt = `Buat 4 ide video YouTube viral yang sangat menarik (high CTR) untuk niche: "${nicheInput}" dalam Bahasa Indonesia. Sertakan judul yang memancing rasa penasaran, prediksi performa ("Sangat Tinggi" atau "Tinggi"), skor potensi (75-98), saran hook 5 detik pertama, dan 4 tag utama.`;
      const sysPrompt = "Anda adalah ahli strategi konten viral YouTube seperti vidIQ Daily Ideas. Fokus pada psikologi klik (CTR), retensi penonton, dan tren terkini.";

      const result = await fetchGeminiWithRetry(prompt, sysPrompt, schema);
      setDailyIdeas(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIdeasLoading(false);
    }
  };

  // Handler Optimasi SEO Otomatis dengan Gemini
  const handleAutoOptimizeSEO = async () => {
    if (!seoTitle.trim()) return;
    setSeoOptimizing(true);

    try {
      const schema = {
        type: "OBJECT",
        properties: {
          optimizedTitle: { type: "STRING" },
          optimizedDescription: { type: "STRING" },
          recommendedTags: { type: "ARRAY", items: { type: "STRING" } }
        },
        required: ["optimizedTitle", "optimizedDescription", "recommendedTags"]
      };

      const prompt = `Optimalkan metadata video YouTube ini untuk SEO dan CTR maksimal dalam Bahasa Indonesia. Judul saat ini: "${seoTitle}". Deskripsi saat ini: "${seoDesc}". Buat judul yang lebih menarik (maks 65 karakter), deskripsi kaya kata kunci (2 paragraf dengan call-to-action), dan 8 tag SEO terbaik.`;
      const sysPrompt = "Anda adalah mesin optimasi SEO YouTube vidIQ. Tingkatkan daya tarik judul dan kepadatan kata kunci deskripsi tanpa terlihat spam.";

      const result = await fetchGeminiWithRetry(prompt, sysPrompt, schema);
      setSeoTitle(result.optimizedTitle);
      setSeoDesc(result.optimizedDescription);
      setSeoTags(result.recommendedTags);
    } catch (err) {
      console.error(err);
    } finally {
      setSeoOptimizing(false);
    }
  };

  // Perhitungan Skor SEO Real-time untuk Tab Optimizer
  const calculateSeoScore = () => {
    let score = 0;
    // Panjang judul ideal (40 - 65 karakter)
    if (seoTitle.length >= 35 && seoTitle.length <= 70) score += 25;
    else if (seoTitle.length > 15) score += 15;

    // Panjang deskripsi
    if (seoDesc.length >= 150) score += 25;
    else if (seoDesc.length >= 60) score += 15;

    // Jumlah tag
    if (seoTags.length >= 5) score += 25;
    else score += seoTags.length * 4;

    // Kesesuaian kata kunci antara judul, deskripsi, dan tag
    const titleWords = seoTitle.toLowerCase().split(' ').filter(w => w.length > 3);
    const descLower = seoDesc.toLowerCase();
    const tagsLower = seoTags.join(' ').toLowerCase();
    
    let matchCount = 0;
    titleWords.forEach(word => {
      if (descLower.includes(word) && tagsLower.includes(word)) matchCount++;
    });
    score += Math.min(25, matchCount * 8);

    return Math.min(100, score);
  };

  const currentSeoScore = calculateSeoScore();

  const handleAddTag = (e) => {
    e.preventDefault();
    if (newTag.trim() && !seoTags.includes(newTag.trim().toLowerCase())) {
      setSeoTags([...seoTags, newTag.trim().toLowerCase()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove) => {
    setSeoTags(seoTags.filter(t => t !== tagToRemove));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col md:flex-row">
      
      {/* SIDEBAR NAVIGASI */}
      <aside className="w-full md:w-64 bg-slate-900 border-b md:border-b-0 md:border-r border-slate-800 flex flex-col justify-between shrink-0">
        <div>
          {/* Logo Header */}
          <div className="p-5 flex items-center gap-3 border-b border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Zap className="w-6 h-6 text-white fill-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight text-white flex items-center gap-1.5">
                CreatorPulse
                <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  PRO
                </span>
              </h1>
              <p className="text-xs text-slate-400">YouTube Growth Suite</p>
            </div>
          </div>

          {/* Menu Navigasi */}
          <nav className="p-3 flex md:flex-col gap-1.5 overflow-x-auto">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === 'dashboard' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
                  : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-200'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              Ringkasan Channel
            </button>

            <button
              onClick={() => setActiveTab('keywords')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === 'keywords' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
                  : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-200'
              }`}
            >
              <Compass className="w-4 h-4" />
              Riset Kata Kunci
            </button>

            <button
              onClick={() => setActiveTab('ideas')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === 'ideas' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
                  : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-200'
              }`}
            >
              <Lightbulb className="w-4 h-4" />
              Ide Harian AI
              <span className="ml-auto hidden md:inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            </button>

            <button
              onClick={() => setActiveTab('seo')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === 'seo' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
                  : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-200'
              }`}
            >
              <Sliders className="w-4 h-4" />
              Audit & Skor SEO
            </button>
          </nav>
        </div>

        {/* Status Channel di Sidebar Bawah */}
        <div className="hidden md:block p-4 m-3 rounded-2xl bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-rose-500 to-orange-500 flex items-center justify-center font-bold text-sm">
              YT
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-semibold text-white truncate">Kreator Nusantara</p>
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                Terhubung
              </p>
            </div>
          </div>
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Target 100K Subs</span>
              <span className="text-white font-medium">68%</span>
            </div>
            <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 w-[68%] rounded-full"></div>
            </div>
          </div>
        </div>
      </aside>

      {/* AREA KONTEN UTAMA */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="max-w-6xl mx-auto">

          {/* ========================================================= */}
          {/* TAB 1: DASHBOARD RINGKASAN CHANNEL                        */}
          {/* ========================================================= */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-white">Ringkasan Performa Channel</h2>
                  <p className="text-sm text-slate-400">Statistik real-time 28 hari terakhir & peluang pertumbuhan.</p>
                </div>
                <button 
                  onClick={() => setActiveTab('ideas')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-medium text-sm shadow-lg shadow-blue-500/20 transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  Lihat Ide Viral Hari Ini
                </button>
              </div>

              {/* Kartu Metrik Utama */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider">Penayangan (Views)</span>
                    <Eye className="w-4 h-4 text-blue-400" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-white">482.9K</span>
                    <span className="text-xs font-semibold text-emerald-400 flex items-center">
                      +24.5% <ArrowUpRight className="w-3 h-3" />
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">94K lebih banyak dari biasanya</p>
                </div>

                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider">Waktu Tonton (Jam)</span>
                    <Play className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-white">19.4K</span>
                    <span className="text-xs font-semibold text-emerald-400 flex items-center">
                      +18.2% <ArrowUpRight className="w-3 h-3" />
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Rata-rata durasi: 04:12</p>
                </div>

                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider">Subscriber Baru</span>
                    <Youtube className="w-4 h-4 text-rose-500" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-white">+6,840</span>
                    <span className="text-xs font-semibold text-emerald-400 flex items-center">
                      +31.0% <ArrowUpRight className="w-3 h-3" />
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Total saat ini: 68,420 subs</p>
                </div>

                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider">Skor Kesehatan SEO</span>
                    <Award className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-emerald-400">84/100</span>
                    <span className="text-xs font-semibold text-slate-400">Sangat Baik</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">12 video berperingkat #1-3</p>
                </div>
              </div>

              {/* Grafik Tren & Video Terbaru */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Simulasi Grafik Penayangan */}
                <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900 border border-slate-800">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="font-semibold text-white">Kecepatan Penayangan (VPH)</h3>
                      <p className="text-xs text-slate-400">Views Per Hour dibandingkan rata-rata channel</p>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
                      <Flame className="w-3.5 h-3.5" /> 1,420 VPH
                    </span>
                  </div>

                  {/* Visualisasi Bar Chart CSS Responsif */}
                  <div className="h-48 flex items-end gap-2 pt-4">
                    {[35, 42, 38, 55, 62, 48, 70, 85, 78, 92, 88, 100, 94, 110].map((val, idx) => (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                        <div className="w-full bg-slate-800 rounded-t-lg relative flex items-end h-36 overflow-hidden">
                          <div 
                            style={{ height: `${(val / 110) * 100}%` }}
                            className="w-full bg-gradient-to-t from-blue-600 to-cyan-400 rounded-t-lg group-hover:brightness-110 transition-all"
                          ></div>
                        </div>
                        <span className="text-[10px] text-slate-500">H-{14 - idx}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Top Kata Kunci Pencarian */}
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
                  <div>
                    <h3 className="font-semibold text-white mb-1">Sumber Trafik Pencarian</h3>
                    <p className="text-xs text-slate-400 mb-4">Kata kunci teratas yang mendatangkan penonton</p>
                    
                    <div className="space-y-3">
                      {[
                        { kw: "tutorial ai bahasa indonesia", pct: "34%", rank: "#1" },
                        { kw: "cara edit video capcut pc", pct: "22%", rank: "#2" },
                        { kw: "aplikasi penghasil uang ai", pct: "18%", rank: "#3" },
                        { kw: "review laptop murah 2026", pct: "12%", rank: "#5" },
                      ].map((item, i) => (
                        <div key={i} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between">
                          <div className="truncate pr-2">
                            <p className="text-sm font-medium text-slate-200 truncate">{item.kw}</p>
                            <p className="text-xs text-slate-400">Kontribusi: {item.pct}</p>
                          </div>
                          <span className="px-2.5 py-1 rounded-lg bg-blue-500/20 text-blue-400 font-bold text-xs shrink-0">
                            {item.rank}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button 
                    onClick={() => setActiveTab('keywords')}
                    className="mt-4 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
                  >
                    Eksplorasi Lebih Banyak Kata Kunci →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: RISET KATA KUNCI (KEYWORD INSPECTOR)               */}
          {/* ========================================================= */}
          {activeTab === 'keywords' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white">Riset Kata Kunci YouTube</h2>
                <p className="text-sm text-slate-400">Temukan topik dengan volume pencarian tinggi dan tingkat persaingan rendah.</p>
              </div>

              {/* Search Bar Kata Kunci */}
              <form onSubmit={handleKeywordResearch} className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={kwInput}
                    onChange={(e) => setKwInput(e.target.value)}
                    placeholder="Masukkan topik atau kata kunci (misal: resep masakan simpel)..."
                    className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-blue-500 focus:outline-none text-white placeholder-slate-500 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={kwLoading}
                  className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-all shrink-0"
                >
                  {kwLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  {kwLoading ? 'Menganalisis...' : 'Analisis Kata Kunci'}
                </button>
              </form>

              {/* Hasil Skor Utama */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Skor Keseluruhan</span>
                    <h3 className="text-lg font-bold text-white mt-1 line-clamp-1">"{kwData.keyword}"</h3>
                    <p className="text-xs text-emerald-400 mt-1">
                      {kwData.overallScore >= 70 ? "Sangat direkomendasikan untuk dibuat!" : "Cukup kompetitif, gunakan long-tail."}
                    </p>
                  </div>
                  <ScoreGauge score={kwData.overallScore} size="lg" />
                </div>

                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-center">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Volume Pencarian</span>
                    <span className="text-sm font-bold text-blue-400">{kwData.searchVolume}/100</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden mb-3">
                    <div 
                      style={{ width: `${kwData.searchVolume}%` }}
                      className="h-full bg-blue-500 rounded-full transition-all duration-700"
                    ></div>
                  </div>
                  <p className="text-xs text-slate-400">
                    Estimasi pencarian: <strong className="text-white">{kwData.monthlySearches}</strong> / bulan
                  </p>
                </div>

                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-center">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Tingkat Kompetisi</span>
                    <span className={`text-sm font-bold ${kwData.competition < 45 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {kwData.competition}/100 ({kwData.competition < 40 ? 'Rendah' : kwData.competition < 70 ? 'Sedang' : 'Tinggi'})
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden mb-3">
                    <div 
                      style={{ width: `${kwData.competition}%` }}
                      className={`h-full rounded-full transition-all duration-700 ${kwData.competition < 45 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                    ></div>
                  </div>
                  <p className="text-xs text-slate-400">Semakin rendah skor, semakin mudah masuk halaman 1.</p>
                </div>
              </div>

              {/* Tabel Kata Kunci Terkait & Pertanyaan */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
                  <div className="p-5 border-b border-slate-800 flex items-center justify-between">
                    <h3 className="font-semibold text-white">Kata Kunci Terkait</h3>
                    <span className="text-xs text-slate-400">Klik ikon salin untuk menggunakan tag</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 text-xs text-slate-400 uppercase bg-slate-900/50">
                          <th className="py-3.5 px-5">Kata Kunci</th>
                          <th className="py-3.5 px-4 text-center">Volume</th>
                          <th className="py-3.5 px-4 text-center">Kompetisi</th>
                          <th className="py-3.5 px-4 text-center">Skor</th>
                          <th className="py-3.5 px-4 text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 text-sm">
                        {kwData.relatedKeywords.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                            <td className="py-3.5 px-5 font-medium text-slate-200">{item.term}</td>
                            <td className="py-3.5 px-4 text-center text-blue-400 font-semibold">{item.volume}</td>
                            <td className="py-3.5 px-4 text-center">
                              <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                                item.competition < 40 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                              }`}>
                                {item.competition}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              <span className="font-bold text-white">{item.score}</span>
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <button
                                onClick={() => copyToClipboard(item.term, `kw-${idx}`)}
                                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                                title="Salin kata kunci"
                              >
                                {copiedText === `kw-${idx}` ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Pertanyaan Populer Penonton */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col">
                  <h3 className="font-semibold text-white mb-1">Pertanyaan Penonton</h3>
                  <p className="text-xs text-slate-400 mb-4">Ide judul berbasis pertanyaan yang sering dicari</p>
                  <div className="space-y-3 flex-1">
                    {kwData.questions.map((q, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-start justify-between gap-2">
                        <p className="text-sm text-slate-200 leading-snug">{q}</p>
                        <button
                          onClick={() => copyToClipboard(q, `q-${idx}`)}
                          className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white shrink-0"
                        >
                          {copiedText === `q-${idx}` ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: IDE HARIAN AI (DAILY IDEAS)                        */}
          {/* ========================================================= */}
          {activeTab === 'ideas' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  Generator Ide Harian AI <Sparkles className="w-6 h-6 text-cyan-400" />
                </h2>
                <p className="text-sm text-slate-400">Dapatkan konsep video dengan prediksi CTR tinggi yang disesuaikan dengan niche channel Anda.</p>
              </div>

              {/* Input Niche */}
              <form onSubmit={handleGenerateIdeas} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={nicheInput}
                  onChange={(e) => setNicheInput(e.target.value)}
                  placeholder="Masukkan niche channel Anda (misal: Gaming Mobile, Kuliner, Keuangan)..."
                  className="flex-1 px-4 py-3.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-500 focus:outline-none text-white placeholder-slate-500 text-sm"
                />
                <button
                  type="submit"
                  disabled={ideasLoading}
                  className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all shrink-0"
                >
                  {ideasLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  {ideasLoading ? 'Meracik Ide Viral...' : 'Hasilkan Ide Baru'}
                </button>
              </form>

              {/* Daftar Kartu Ide */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {dailyIdeas.map((idea) => (
                  <div key={idea.id} className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                          <TrendingUp className="w-3.5 h-3.5" /> Prediksi: {idea.prediction}
                        </span>
                        <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-lg">
                          Skor Viral: {idea.score}/100
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-white leading-snug mb-3">
                        {idea.title}
                      </h3>

                      <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/50 mb-4">
                        <p className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">Saran Hook 5 Detik Pertama:</p>
                        <p className="text-sm text-slate-300">{idea.hook}</p>
                      </div>

                      <div className="flex flex-wrap gap-1.5 mb-5">
                        {idea.tags.map((t, i) => (
                          <span key={i} className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 text-slate-400">
                            #{t}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-3 border-t border-slate-800">
                      <button
                        onClick={() => copyToClipboard(idea.title, `idea-${idea.id}`)}
                        className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-colors"
                      >
                        {copiedText === `idea-${idea.id}` ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        {copiedText === `idea-${idea.id}` ? 'Judul Tersalin!' : 'Salin Judul'}
                      </button>
                      <button
                        onClick={() => {
                          setSeoTitle(idea.title);
                          setSeoTags(idea.tags);
                          setActiveTab('seo');
                        }}
                        className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 text-xs font-semibold transition-colors"
                      >
                        Kirim ke Audit SEO →
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 4: AUDIT & SKOR SEO VIDEO                             */}
          {/* ========================================================= */}
          {activeTab === 'seo' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-white">Audit & Optimasi SEO Video</h2>
                  <p className="text-sm text-slate-400">Uji judul, deskripsi, dan tag Anda sebelum dipublikasikan ke YouTube.</p>
                </div>
                <button
                  onClick={handleAutoOptimizeSEO}
                  disabled={seoOptimizing}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-purple-500/20 transition-all"
                >
                  {seoOptimizing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  {seoOptimizing ? 'Mengoptimalkan...' : 'Optimasi Otomatis dengan AI'}
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Form Editor Metadata */}
                <div className="lg:col-span-2 space-y-5 p-6 rounded-2xl bg-slate-900 border border-slate-800">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-sm font-semibold text-slate-200">Judul Video</label>
                      <span className={`text-xs ${seoTitle.length > 70 ? 'text-amber-400' : 'text-slate-400'}`}>
                        {seoTitle.length} / 70 karakter ideal
                      </span>
                    </div>
                    <input
                      type="text"
                      value={seoTitle}
                      onChange={(e) => setSeoTitle(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 focus:border-blue-500 focus:outline-none text-white text-sm"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-sm font-semibold text-slate-200">Deskripsi Video</label>
                      <span className="text-xs text-slate-400">{seoDesc.length} karakter</span>
                    </div>
                    <textarea
                      rows={4}
                      value={seoDesc}
                      onChange={(e) => setSeoDesc(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 focus:border-blue-500 focus:outline-none text-white text-sm leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-semibold text-slate-200 block mb-2">Tag Video ({seoTags.length})</label>
                    <form onSubmit={handleAddTag} className="flex gap-2 mb-3">
                      <input
                        type="text"
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        placeholder="Tambah tag baru lalu tekan Enter..."
                        className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-blue-500 focus:outline-none text-white text-sm"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-medium text-white"
                      >
                        Tambah
                      </button>
                    </form>
                    <div className="flex flex-wrap gap-2">
                      {seoTags.map((tag, idx) => (
                        <span 
                          key={idx} 
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-500/15 border border-blue-500/30 text-blue-300 text-xs font-medium"
                        >
                          <Tag className="w-3 h-3" />
                          {tag}
                          <button 
                            onClick={() => removeTag(tag)}
                            className="ml-1 text-blue-400 hover:text-white font-bold"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Panel Skor SEO Live (vidIQ Style Checklist) */}
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
                  <div>
                    <h3 className="font-semibold text-white text-center mb-4">Skor SEO Real-Time</h3>
                    <div className="my-4">
                      <ScoreGauge score={currentSeoScore} label="Skor Dapat Ditemukan" size="lg" />
                    </div>

                    <div className="space-y-3 mt-6">
                      <div className="flex items-center justify-between text-sm p-2.5 rounded-xl bg-slate-800/50">
                        <span className="text-slate-300 flex items-center gap-2">
                          {seoTitle.length >= 35 && seoTitle.length <= 70 ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                          )}
                          Panjang Judul Optimal
                        </span>
                        <span className="font-bold text-xs text-slate-400">
                          {seoTitle.length >= 35 && seoTitle.length <= 70 ? '25/25' : '15/25'}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-sm p-2.5 rounded-xl bg-slate-800/50">
                        <span className="text-slate-300 flex items-center gap-2">
                          {seoDesc.length >= 150 ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                          )}
                          Deskripsi Informatif
                        </span>
                        <span className="font-bold text-xs text-slate-400">
                          {seoDesc.length >= 150 ? '25/25' : '15/25'}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-sm p-2.5 rounded-xl bg-slate-800/50">
                        <span className="text-slate-300 flex items-center gap-2">
                          {seoTags.length >= 5 ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                          )}
                          Jumlah Tag Relevan
                        </span>
                        <span className="font-bold text-xs text-slate-400">
                          {seoTags.length >= 5 ? '25/25' : `${seoTags.length * 4}/25`}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-sm p-2.5 rounded-xl bg-slate-800/50">
                        <span className="text-slate-300 flex items-center gap-2">
                          <Layers className="w-4 h-4 text-blue-400 shrink-0" />
                          Konsistensi Kata Kunci
                        </span>
                        <span className="font-bold text-xs text-emerald-400">Aktif</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => copyToClipboard(`${seoTitle}\n\n${seoDesc}\n\nTags: ${seoTags.join(', ')}`, 'all-seo')}
                    className="mt-6 w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
                  >
                    {copiedText === 'all-seo' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {copiedText === 'all-seo' ? 'Semua Metadata Tersalin!' : 'Salin Semua Metadata'}
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}