const form = document.getElementById('loginForm');
const msg = document.getElementById('loginMsg');

fetch('/api/me').then(r => r.json()).then(user => {
  if (user.role) {
    window.location.href = user.role === 'owner' ? '/owner.html' : '/member.html';
  }
}).catch(() => {});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  msg.textContent = '⏳ Memproses...';
  msg.style.color = '#a78bfa';

  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.success) {
      msg.textContent = '✅ Login berhasil!';
      msg.style.color = '#4ade80';
      setTimeout(() => {
        window.location.href = data.user.role === 'owner' ? '/owner.html' : '/member.html';
      }, 700);
    } else {
      msg.textContent = '❌ ' + data.error;
      msg.style.color = '#ef4444';
    }
  } catch (err) {
    msg.textContent = '❌ Error: ' + err.message;
    msg.style.color = '#ef4444';
  }
});