// Service Worker notification & background alarm handler
self.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || typeof data !== 'object') return;

  if (data.type === 'SHOW_STUDY_NOTIFICATION') {
    const title = data.title || 'StudyPulse অ্যালার্ম';
    const body = data.body || 'আপনার নির্ধারিত সময় হয়েছে!';
    const tag = data.tag || 'studypulse-alert';

    event.waitUntil(
      self.registration.showNotification(title, {
        body,
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        tag,
        renotify: true,
        requireInteraction: true,
        vibrate: [250, 120, 250, 120, 350],
        data: {
          alarmId: data.alarmId || null,
          kind: data.kind || 'alarm',
        },
        actions:
          data.kind === 'alarm'
            ? [
                { action: 'snooze', title: '৫ মিনিট স্নুজ' },
                { action: 'dismiss', title: 'বন্ধ করুন' },
              ]
            : [{ action: 'open', title: 'অ্যাপ খুলুন' }],
      })
    );
  }
});

self.addEventListener('notificationclick', (event) => {
  const notification = event.notification;
  const action = event.action;
  const data = notification.data || {};
  notification.close();

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({
            type: 'NOTIFICATION_ACTION',
            action: action || 'open',
            alarmId: data.alarmId || null,
          });
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow('/');
      }
    })
  );
});
