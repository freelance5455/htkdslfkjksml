// IRAQI LIVE - Service Worker for PWA & Offline Support
const CACHE_NAME = 'iraqi-live-cache-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
];

// Install Event - Pre-cache core shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[IRAQI LIVE SW] Pre-caching static assets');
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[IRAQI LIVE SW] Pre-cache error on some assets:', err);
      });
    })
  );
  self.skipWaiting();
});

// Activate Event - Clean up stale caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[IRAQI LIVE SW] Deleting old cache:', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event - Network first with Cache fallback for navigation & static cache
self.addEventListener('fetch', (event) => {
  // Ignore non-GET requests or browser extension requests
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);

  // If request is from chrome-extension or external analytics, ignore
  if (!url.protocol.startsWith('http')) return;

  // For video streams / m3u8 / ts chunks, bypass cache
  if (url.pathname.endsWith('.m3u8') || url.pathname.endsWith('.ts') || url.hostname.includes('stream') || url.hostname.includes('cdn')) {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        // If response is valid, clone it into cache for static assets & html
        if (
          networkResponse &&
          networkResponse.status === 200 &&
          (event.request.destination === 'document' ||
           event.request.destination === 'style' ||
           event.request.destination === 'script' ||
           event.request.destination === 'image' ||
           event.request.destination === 'font')
        ) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return networkResponse;
      })
      .catch(async () => {
        // Offline fallback
        const cachedResponse = await caches.match(event.request);
        if (cachedResponse) {
          return cachedResponse;
        }

        // If it's a page navigation, return index.html from cache
        if (event.request.mode === 'navigate') {
          const indexFallback = await caches.match('/index.html');
          if (indexFallback) return indexFallback;
          const rootFallback = await caches.match('/');
          if (rootFallback) return rootFallback;
        }

        return new Response('IRAQI LIVE - أنت غير متصل بالإنترنت حالياً. يرجى التحقق من اتصالك بالشبكة.', {
          status: 503,
          statusText: 'Service Unavailable',
          headers: new Headers({ 'Content-Type': 'text/plain; charset=utf-8' }),
        });
      })
  );
});
