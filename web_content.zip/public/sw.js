const CACHE = 'nova-phone-manager-v13';
const SHELL = ['/', '/manifest.webmanifest', '/icon.svg'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  const u = new URL(event.request.url);
  if (event.request.method !== 'GET' || u.pathname.startsWith('/api/')) return;
  event.respondWith(fetch(event.request).then(r => { if (r.ok && u.origin === location.origin) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(event.request, copy)); } return r; }).catch(() => caches.match(event.request).then(cached => cached || caches.match('/'))));
});
