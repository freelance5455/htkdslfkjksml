/* TV LO3 — Service Worker · offline + precache controlado */
const VERSION = "lo3-v1.0.0";
const PRECACHE = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-384.png",
  "/icons/icon-512.png",
  "/icons/apple-touch-icon.png",
];

const API_HOSTS = [
  "site.api.espn.com",
  "iptv-org.github.io",
  "iptv-org.gitlab.io",
  "api.tvmaze.com",
  "www.wikidata.org",
  "query.wikidata.org",
  "archive.org",
  "api.archive.org",
  "es.wikipedia.org",
  "api.wikimedia.org",
  "de1.api.radio-browser.info",
  "api.deezer.com",
  "hacker-news.firebaseio.com",
  "wttr.in",
  "api.wheretheiss.at",
  "api.nasa.gov",
  "open.er-api.com",
];

const isMedia = (req) => {
  const dest = req.destination;
  return dest === "audio" || dest === "video" || /\.(mp3|m4a|aac|ogg|m3u8|ts|mp4)(\?|$)/i.test(req.url);
};

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(VERSION + "-pre");
      await cache.addAll(PRECACHE).catch(() => {});
      await self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);

  // Streams y medios: nunca cachear (directos y ráfagas)
  if (isMedia(request)) return;

  // Assets estáticos same-origin: cache-first con red de respaldo
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then((hit) => hit || fetch(request).then((res) => {
        if (res.ok && (url.pathname.startsWith("/img/") || url.pathname.startsWith("/icons/"))) {
          const clone = res.clone();
          caches.open(VERSION + "-img").then((c) => c.put(request, clone));
        }
        return res;
      }))
    );
    return;
  }

  // APIs públicas conocidas: network-first con fallback a caché (offline)
  if (API_HOSTS.includes(url.hostname)) {
    event.respondWith(
      fetch(request).then((res) => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(VERSION + "-api").then((c) => c.put(request, clone));
        }
        return res;
      }).catch(() => caches.match(request).then((hit) => hit || new Response(JSON.stringify({ error: "offline" }), { status: 503, headers: { "Content-Type": "application/json" } })))
    );
    return;
  }
});
