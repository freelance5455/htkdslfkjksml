const CACHE_NAME = 'ogvirk-live-v2';
const ESSENTIAL_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// 1. Install Event - Pre-cache critical core shell
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing SW & Pre-caching core assets');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ESSENTIAL_ASSETS).catch((err) => {
        console.warn('[Service Worker] Non-critical pre-cache error:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// 2. Activate Event - Clear obsolete caches & claim clients immediately
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating SW & Cleaning stale caches');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('[Service Worker] Deleting obsolete cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// 3. Fetch Event Handler - Smart caching & network resilience
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Skip non-GET methods, extension schemes, and live API / Auth endpoints
  if (
    event.request.method !== 'GET' ||
    url.protocol.startsWith('chrome-extension') ||
    url.hostname.includes('firestore.googleapis.com') ||
    url.hostname.includes('identitytoolkit.googleapis.com') ||
    url.hostname.includes('securetoken.googleapis.com') ||
    url.pathname.startsWith('/api/')
  ) {
    return;
  }

  // Strategy A: Page Navigations -> Network First, Fallback to Cache / index.html
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const copy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return networkResponse;
        })
        .catch(() => {
          return caches.match(event.request).then((cached) => {
            return cached || caches.match('/index.html') || caches.match('/');
          });
        })
    );
    return;
  }

  // Strategy B: Static assets (JS, CSS, images, fonts) -> Cache-first with Background Revalidation
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request)
        .then((networkResponse) => {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === 'basic'
          ) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(() => cachedResponse);

      return cachedResponse || fetchPromise;
    })
  );
});

// 4. Background Sync Listener - Retries pending sync actions when reconnected
self.addEventListener('sync', (event) => {
  console.log('[Service Worker] Background sync event triggered:', event.tag);
  if (event.tag === 'sync-app-state' || event.tag === 'firebase-sync') {
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({ type: 'BACKGROUND_SYNC_TRIGGERED', tag: event.tag });
        });
      })
    );
  }
});

// 5. Periodic Background Sync (if supported by browser)
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'session-keepalive') {
    console.log('[Service Worker] Periodic session keepalive sync executing');
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({ type: 'PERIODIC_KEEPALIVE_PING' });
        });
      })
    );
  }
});

// 6. Communication & Heartbeat Listener - Prevents session loss & keeps worker active
self.addEventListener('message', (event) => {
  if (!event.data) return;

  switch (event.data.type) {
    case 'PING':
      // Respond to client keepalive ping
      if (event.ports && event.ports[0]) {
        event.ports[0].postMessage({ status: 'PONG', timestamp: Date.now() });
      } else if (event.source) {
        event.source.postMessage({ type: 'PONG', timestamp: Date.now() });
      }
      break;

    case 'SKIP_WAITING':
      self.skipWaiting();
      break;

    case 'CACHE_PURGE':
      caches.delete(CACHE_NAME).then(() => {
        console.log('[Service Worker] Cache purged via admin request');
      });
      break;

    default:
      break;
  }
});
