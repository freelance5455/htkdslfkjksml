self.addEventListener('push', function(event) {
  let data = { title: 'SONÓ RADIO', body: 'Nueva notificación', tag: 'default' };
  
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: data.tag || 'sono-call',
    vibrate: [200, 100, 200, 100, 200, 100, 200],
    requireInteraction: true,
    actions: [
      { action: 'open', title: 'Abrir SonóVisión' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener('message', function(event) {
  if (event.data && event.data.type === 'PLAY_TRANSMISSION_NOTIFICATION') {
    const title = event.data.title || '🎙️ Transmisión Entrante - SONÓ RADIO';
    const options = {
      body: event.data.body || 'Transmitiendo voz en vivo...',
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      tag: event.data.tag || ('sono-audio-' + Date.now()),
      vibrate: [300, 150, 300, 150, 400],
      requireInteraction: true,
      actions: [
        { action: 'open', title: '📻 Abrir Sonó Radio Walkie-Talkie' }
      ]
    };
    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  }
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  
  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.matchAll({ type: 'window' }).then(windowClients => {
        for (let i = 0; i < windowClients.length; i++) {
          let client = windowClients[i];
          if (client.url.indexOf('/') !== -1 && 'focus' in client) {
            return client.focus();
          }
        }
        if (clients.openWindow) {
          return clients.openWindow('/');
        }
      })
    );
  }
});
