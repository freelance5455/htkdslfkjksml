const CACHE_NAME = 'syllabus-calculator-v30';
const CORE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/google-apps-script.txt',
  '/syllabus.json',
  '/malayalam.ttf',
  '/icon-192.png',
  '/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(CORE.map(u => new Request(u, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

// Network-first: always try the internet for the newest version.
// If offline (or the network is very slow and a saved copy exists), use the saved copy.
function networkFirst(req) {
  return new Promise(resolve => {
    let done = false;
    const fromCache = () =>
      caches.match(req).then(c => c || caches.match('/index.html'));

    const timer = setTimeout(() => {
      fromCache().then(c => {
        if (c && !done) { done = true; resolve(c); }
      });
    }, 4000);

    fetch(req, { cache: 'no-cache' })
      .then(res => {
        clearTimeout(timer);
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(req, copy));
        }
        if (!done) { done = true; resolve(res); }
      })
      .catch(() => {
        clearTimeout(timer);
        if (done) return;
        fromCache().then(c => {
          done = true;
          resolve(c || Response.error());
        });
      });
  });
}

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith(networkFirst(req));
});