self.addEventListener("push", event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch {}
  const title = data.title || "MAZO HUB";
  const options = {
    body: data.body || "You have a new MAZO HUB update.",
    icon: "/icon.svg",
    badge: "/icon.svg",
    tag: data.order_number || "mazo-hub",
    renotify: true,
    data: { url: data.url || "/admin/", order_number: data.order_number || "" }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  const url = new URL(event.notification.data?.url || "/admin/", self.location.origin).href;
  event.waitUntil(clients.matchAll({type:"window",includeUncontrolled:true}).then(list=>{
    for(const client of list){ if("focus" in client){ client.navigate(url); return client.focus(); } }
    return clients.openWindow(url);
  }));
});
