// FieldFlow Service Worker for Offline Task Updates and Attendance Sync
const CACHE_NAME = 'fieldflow-pwa-v1';
const DB_NAME = 'fieldflow_offline_sync_db';
const DB_VERSION = 1;
const STORE_NAME = 'offline_queue';

// Install event: cache basic app shell and activate immediately
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

// Activate event: claim all client windows
self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

/**
 * Open IndexedDB from inside the Service Worker
 */
function openIDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Read all pending records from IndexedDB
 */
async function getPendingRecordsFromDB() {
  try {
    const db = await openIDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORE_NAME], 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const items = req.result || [];
        const pending = items.filter(
          (i) => i.status === 'pending' || i.status === 'failed' || i.status === 'syncing'
        );
        resolve(pending);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[ServiceWorker] Error reading IndexedDB:', err);
    return [];
  }
}

/**
 * Update record status in IndexedDB
 */
async function updateRecordStatusInDB(id, status, error) {
  try {
    const db = await openIDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORE_NAME], 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(id);
      getReq.onsuccess = () => {
        const record = getReq.result;
        if (record) {
          record.status = status;
          if (error) record.error = error;
          const putReq = store.put(record);
          putReq.onsuccess = () => resolve();
          putReq.onerror = () => reject(putReq.error);
        } else {
          resolve();
        }
      };
      getReq.onerror = () => reject(getReq.error);
    });
  } catch (err) {
    console.warn('[ServiceWorker] Error updating record in DB:', err);
  }
}

/**
 * Remove record from IndexedDB once uploaded
 */
async function removeRecordFromDB(id) {
  try {
    const db = await openIDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORE_NAME], 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[ServiceWorker] Error deleting record in DB:', err);
  }
}

/**
 * Broadcast message to all controlled window clients
 */
async function notifyClients(message) {
  const clients = await self.clients.matchAll({ includeUncontrolled: true, type: 'window' });
  for (const client of clients) {
    client.postMessage(message);
  }
}

/**
 * Main Service Worker Background Sync Engine
 * Uploads queued technician task updates and attendance once connectivity is restored.
 */
async function syncOfflineDataViaWorker() {
  const pending = await getPendingRecordsFromDB();
  if (pending.length === 0) {
    return { synced: 0, failed: 0 };
  }

  // Count types for telemetry
  const attendanceRecords = pending.filter((r) => r.type === 'check_in' || r.type === 'check_out');
  const taskRecords = pending.filter((r) => r.type === 'update_task');

  await notifyClients({
    type: 'SERVICE_WORKER_SYNC_STARTED',
    count: pending.length,
    attendanceCount: attendanceRecords.length,
    taskCount: taskRecords.length,
  });

  try {
    // Send batch to server-side sync endpoint
    const response = await fetch('/api/sync/offline-batch', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ records: pending }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errText}`);
    }

    const result = await response.json();

    // Mark items as synced and clean up
    for (const item of pending) {
      await updateRecordStatusInDB(item.id, 'synced');
      // Remove from store
      await removeRecordFromDB(item.id);
    }

    await notifyClients({
      type: 'SERVICE_WORKER_SYNC_COMPLETED',
      success: true,
      syncedCount: pending.length,
      attendanceCount: attendanceRecords.length,
      taskCount: taskRecords.length,
      records: pending,
      timestamp: new Date().toISOString(),
    });

    return { synced: pending.length, failed: 0 };
  } catch (err) {
    console.warn('[ServiceWorker] Background sync failed or network unavailable:', err);

    for (const item of pending) {
      await updateRecordStatusInDB(item.id, 'failed', err?.message || 'Sync failed');
    }

    await notifyClients({
      type: 'SERVICE_WORKER_SYNC_FAILED',
      error: err?.message || 'Upload failed',
      count: pending.length,
    });

    throw err; // Rethrow so the browser Background Sync can retry
  }
}

// Background Sync API listener
self.addEventListener('sync', (event) => {
  if (event.tag === 'fieldflow-offline-sync' || event.tag === 'fieldflow-sync') {
    event.waitUntil(syncOfflineDataViaWorker());
  }
});

// Window postMessage listener
self.addEventListener('message', (event) => {
  if (!event.data) return;

  if (event.data.type === 'TRIGGER_SYNC') {
    event.waitUntil(syncOfflineDataViaWorker());
  } else if (event.data.type === 'PING') {
    event.source?.postMessage({ type: 'PONG', active: true });
  }
});
