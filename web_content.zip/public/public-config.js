// Firebase Console → Project settings → Your apps → Web app.
// Replace all placeholder values with your Firebase web config.
// This config is public by design; protect data using Firestore rules and Auth.
window.GROWTH_SALLER_CONFIG = {
  // Owner email for future server-side order notifications (not sent until email provider is configured).
  ownerEmail: "ranveerjaiswal282@gmail.com",
  firebase: {
    apiKey: "PASTE_FIREBASE_API_KEY",
    authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
    projectId: "PASTE_PROJECT_ID",
    storageBucket: "PASTE_PROJECT_ID.appspot.com",
    messagingSenderId: "PASTE_SENDER_ID",
    appId: "PASTE_APP_ID"
  },
  // Change these to your real UPI details:
  upiId: "yourname@upi",
  payeeName: "Growth Saller"
};
