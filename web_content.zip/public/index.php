<?php require_once __DIR__.'/../src/bootstrap.php'; require_auth(); require __DIR__.'/../src/layout.php';
$counts=[]; foreach(['customers'=>'مشتریان','packages'=>'پکیجونه','payments'=>'تادیې'] as $t=>$label){$counts[$label]=(int)db()->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();}
?>
<h1>د Ahmadi WiFi مرکزي ډشبورډ</h1><p class="muted">د مشتریانو، پکیجونو او حسابونو عمومي وضعیت</p>
<div class="grid"><?php foreach($counts as $label=>$n):?><section class="card"><div><?=$label?></div><div class="number"><?=$n?></div></section><?php endforeach;?></div>
<div class="notice">یادونه: د Hosting او MikroTik ترمنځ باید لومړی خوندي VPN جوړ وي. یوازې د 192.168.22.1 IP لیکل د انټرنېټ له لارې اتصال نه شي برابرولای.</div>
<section class="panel"><h2>چټک لینکونه</h2><p><a class="btn" href="customers.php">مشتری ثبتول</a> <a class="btn" href="packages.php">پکیج جوړول</a> <a class="btn" href="mikrotik.php">د روټر تنظیمات</a></p></section>
<?php require __DIR__.'/../src/footer.php'; ?>