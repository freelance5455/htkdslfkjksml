import * as THREE from 'three';
import { io } from 'socket.io-client';

const root=document.querySelector('#game');
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x8db6cb);
scene.fog=new THREE.Fog(0x8db6cb,90,360);
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,700);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;
root.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xd9efff,0x53604a,2.0));
const sun=new THREE.DirectionalLight(0xfff0d5,2.5);sun.position.set(-80,120,50);sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-150;sun.shadow.camera.right=150;sun.shadow.camera.top=150;sun.shadow.camera.bottom=-150;scene.add(sun);

const mat=(color,roughness=.8)=>new THREE.MeshStandardMaterial({color,roughness});
const ground=new THREE.Mesh(new THREE.PlaneGeometry(600,600),mat(0x52734d));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
const roadMat=mat(0x292f35),lineMat=mat(0xe6e1c7),sideMat=mat(0x8b9293);
function box(w,h,d,material,x,y,z,cast=true){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=cast;m.receiveShadow=true;scene.add(m);return m;}

// City grid: broad roads, sidewalks, varied buildings and windows.
for(let i=-5;i<=5;i++){
 const p=i*42;
 const road1=box(13,.12,520,roadMat,p,.06,0,false);
 const road2=box(520,.12,13,roadMat,0,.065,p,false);
 box(1,.025,520,lineMat,p-6.2,.13,0,false);box(1,.025,520,lineMat,p+6.2,.13,0,false);
 box(520,.025,1,lineMat,0,.13,p-6.2,false);box(520,.025,1,lineMat,0,.13,p+6.2,false);
}
const buildingMats=[0xb9a995,0x879ba5,0xc6c3b8,0x9baba0,0x777f8a,0xd0bca2].map(c=>mat(c));
const windowMat=new THREE.MeshStandardMaterial({color:0x273f50,metalness:.2,roughness:.25});
for(let gx=-5;gx<5;gx++)for(let gz=-5;gz<5;gz++){
 const cx=gx*42+21,cz=gz*42+21;
 for(let k=0;k<3;k++){
  const x=cx+(Math.random()-.5)*20,z=cz+(Math.random()-.5)*20;
  const w=7+Math.random()*8,d=7+Math.random()*8,h=10+Math.random()*45;
  const b=box(w,h,d,buildingMats[Math.floor(Math.random()*buildingMats.length)],x,h/2,z);
  // facade window bands
  for(let yy=4;yy<h-2;yy+=4){
   for(let xx=-w/2+1.5;xx<w/2-1;xx+=2.5){
    const win=new THREE.Mesh(new THREE.BoxGeometry(1.25,1.5,.08),windowMat);
    win.position.set(x+xx,yy,z+d/2+.05);scene.add(win);
   }
  }
 }
}
// Trees along selected sidewalks
const trunkMat=mat(0x60452d),leafMat=mat(0x2d6541);
for(let i=0;i<110;i++){
 const x=(Math.random()-.5)*420,z=(Math.random()-.5)*420;
 if(Math.abs(x%42)<9||Math.abs(z%42)<9)continue;
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.35,2,7),trunkMat);trunk.position.set(x,1,z);trunk.castShadow=true;scene.add(trunk);
 const crown=new THREE.Mesh(new THREE.SphereGeometry(1.5,8,7),leafMat);crown.position.set(x,3,z);crown.castShadow=true;scene.add(crown);
}

// Detailed low-poly sports sedan.
const car=new THREE.Group();scene.add(car);
const bodyMat=new THREE.MeshStandardMaterial({color:0x146bca,metalness:.72,roughness:.27});
const glassMat=new THREE.MeshStandardMaterial({color:0x152c3c,metalness:.45,roughness:.16});
const tireMat=mat(0x111315,.95),rimMat=new THREE.MeshStandardMaterial({color:0xb9c4c9,metalness:.85,roughness:.22});
const body=new THREE.Mesh(new THREE.BoxGeometry(2.15,.62,4.3),bodyMat);body.position.y=.82;body.castShadow=true;car.add(body);
const hood=new THREE.Mesh(new THREE.BoxGeometry(2.08,.22,1.15),bodyMat);hood.position.set(0,1.08,-1.45);car.add(hood);
const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.72,.78,2.05),glassMat);cabin.position.set(0,1.42,.15);cabin.castShadow=true;car.add(cabin);
const roof=new THREE.Mesh(new THREE.BoxGeometry(1.68,.12,1.5),bodyMat);roof.position.set(0,1.84,.15);car.add(roof);
for(const x of [-.83,.83])for(const z of [-1.38,1.42]){
 const wheel=new THREE.Group();wheel.position.set(x,.48,z);car.add(wheel);
 const t=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.28,16),tireMat);t.rotation.z=Math.PI/2;t.castShadow=true;wheel.add(t);
 const r=new THREE.Mesh(new THREE.CylinderGeometry(.23,.23,.3,12),rimMat);r.rotation.z=Math.PI/2;wheel.add(r);
}
const lightMat=new THREE.MeshStandardMaterial({color:0xfff4d5,emissive:0xffe6a0,emissiveIntensity:1.2});
for(const x of [-.72,.72]){const l=new THREE.Mesh(new THREE.BoxGeometry(.45,.18,.08),lightMat);l.position.set(x,.88,-2.17);car.add(l);}
car.position.set(0,0,0);

const keys={left:false,right:false,gas:false,brake:false,reverse:false};
let speed=0,steer=0,mode='offline',socket=null,remoteCars=new Map(),cameraYaw=0,cameraPitch=.16;
const speedEl=document.querySelector('#speed'),modeEl=document.querySelector('#mode'),menu=document.querySelector('#menu');
function toast(s){const t=document.querySelector('#toast');t.textContent=s;t.style.display='block';setTimeout(()=>t.style.display='none',2300)}
function setMode(m){mode=m;modeEl.textContent=m==='online'?'أونلاين':'أوفلاين';}
function connectOnline(){
 try{
  socket=io({timeout:2500});
  socket.on('connect',()=>{setMode('online');toast('تم الاتصال بالخادم');});
  socket.on('connect_error',()=>{setMode('offline');toast('لا يوجد خادم متاح؛ ستلعب أوفلاين');});
  socket.on('state',data=>{
   for(const p of data.players||[]){if(p.id===socket.id)continue;let obj=remoteCars.get(p.id);
    if(!obj){obj=new THREE.Mesh(new THREE.BoxGeometry(2,1,4),mat(0xd34b38));scene.add(obj);remoteCars.set(p.id,obj);}
    obj.position.set(p.x,.55,p.z);obj.rotation.y=p.rot;
   }
   for(const [id,obj] of remoteCars)if(!(data.players||[]).some(p=>p.id===id)){scene.remove(obj);remoteCars.delete(id);}
  });
 }catch(e){setMode('offline');toast('تعذر الاتصال؛ اللعب أوفلاين');}
}
document.querySelector('#offline').onclick=()=>{setMode('offline');toast('تم اختيار اللعب أوفلاين');};
document.querySelector('#online').onclick=connectOnline;
document.querySelector('#start').onclick=()=>{menu.style.display='none';};
document.querySelectorAll('.pad').forEach(el=>{
 const k=el.dataset.key;
 const on=e=>{e.preventDefault();keys[k]=true;el.classList.add('active');};
 const off=e=>{e.preventDefault();keys[k]=false;el.classList.remove('active');};
 el.addEventListener('pointerdown',on);el.addEventListener('pointerup',off);el.addEventListener('pointercancel',off);el.addEventListener('pointerleave',off);
});
addEventListener('keydown',e=>{const map={ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',ArrowUp:'gas',w:'gas',ArrowDown:'brake',s:'brake', ' ':'brake'};if(map[e.key])keys[map[e.key]]=true;});
addEventListener('keyup',e=>{const map={ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',ArrowUp:'gas',w:'gas',ArrowDown:'brake',s:'brake',' ':'brake'};if(map[e.key])keys[map[e.key]]=false;});
let pointer=null;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='touch'||e.pointerType==='mouse')pointer={x:e.clientX,y:e.clientY};});
renderer.domElement.addEventListener('pointermove',e=>{if(pointer){cameraYaw+=(e.clientX-pointer.x)*.004;cameraPitch=Math.max(-.05,Math.min(.55,cameraPitch+(e.clientY-pointer.y)*.002));pointer={x:e.clientX,y:e.clientY};}});
renderer.domElement.addEventListener('pointerup',()=>pointer=null);

const clock=new THREE.Clock();
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);
 if(keys.gas)speed+=16*dt;else if(keys.reverse)speed-=9*dt;else speed*=Math.pow(.985,dt*60);
 if(keys.brake)speed*=Math.pow(.91,dt*60);
 speed=Math.max(-12,Math.min(48,speed));
 const steerInput=(keys.left?1:0)-(keys.right?1:0);
 steer=THREE.MathUtils.damp(steer,steerInput,.18,dt);
 car.rotation.y+=steer*speed*.012*dt;
 car.position.x-=Math.sin(car.rotation.y)*speed*dt;
 car.position.z-=Math.cos(car.rotation.y)*speed*dt;
 // keep the vehicle inside the generated city
 car.position.x=THREE.MathUtils.clamp(car.position.x,-245,245);
 car.position.z=THREE.MathUtils.clamp(car.position.z,-245,245);
 speedEl.textContent=Math.round(Math.abs(speed)*3.6);
 const back=new THREE.Vector3(Math.sin(car.rotation.y+cameraYaw),0,Math.cos(car.rotation.y+cameraYaw));
 const target=car.position.clone().add(new THREE.Vector3(0,1.2,0));
 const desired=target.clone().add(back.multiplyScalar(10+cameraPitch*5)).add(new THREE.Vector3(0,4+cameraPitch*9,0));
 camera.position.lerp(desired,1-Math.pow(.001,dt));camera.lookAt(target);
 if(socket?.connected&&mode==='online')socket.emit('drive',{x:car.position.x,z:car.position.z,rot:car.rotation.y});
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
