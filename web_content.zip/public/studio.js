(() => {
  'use strict';

  const nativeApp = location.protocol === 'file:' || location.hostname === 'appassets.androidplatform.net' || !!window.AuriaNative;
  const SESSION_KEY = 'auria_sessions_v1';
  const GALLERY_KEY = 'auria_gallery_v1';
  const OWNER_KEY = 'auria_owner_v1';
  const THEME_KEY = 'auria_theme_v1';
  const $ = (selector) => document.querySelector(selector);
  const icon = (name, extra = '') => `<svg class="icon ${extra}" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const readJSON = (key, fallback) => { try { const value = JSON.parse(localStorage.getItem(key)); return value ?? fallback; } catch { return fallback; } };
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }));
  const safeSessions = readJSON(SESSION_KEY, []);
  const safeGallery = readJSON(GALLERY_KEY, []);
  const sessions = Array.isArray(safeSessions) ? safeSessions.filter(s => s && typeof s.id === 'string' && Array.isArray(s.messages)) : [];
  const gallery = Array.isArray(safeGallery) ? safeGallery.filter(g => g && typeof g.url === 'string') : [];
  let ownerId = localStorage.getItem(OWNER_KEY);
  if (!ownerId || !/^[\da-f-]{36}$/i.test(ownerId)) { ownerId = uid(); localStorage.setItem(OWNER_KEY, ownerId); }
  const state = {
    view: 'home', currentSessionId: null, busy: false, imageBusy: false, imagePrompt: '',
    imageStyle: 'Fotográfico', imageRatio: 'Cuadrado', currentImage: null,
    drafts: {}, attachment: null, listening: false, deferredInstall: null, toastTimer: null,
    libraryQuery: '', searchQuery: '', speaking: false,
  };
  const names = { home: 'Inicio', chat: 'Chat con IA', image: 'Crear imágenes', write: 'Escribir', summary: 'Resumir', translate: 'Traducir', code: 'Programar', study: 'Aprender', ideas: 'Ideas', history: 'Historial', saved: 'Guardados', download: 'Descargar app' };
  const tools = {
    write: { title: 'Escribir mejor', subtitle: 'De una idea a un texto increíble en segundos.', icon: 'pen', tone: 'tone-blue', label: '¿Qué necesitas escribir?', placeholder: 'Ej.: Un correo para presentar mi proyecto a un cliente potencial...', options: ['Profesional', 'Cercano', 'Creativo', 'Persuasivo'], button: 'Crear texto', empty: 'Tu próximo gran texto empieza aquí.', prompt: (input, option) => `Actúa como un excelente redactor. Escribe el texto solicitado a continuación con un tono ${option.toLowerCase()}. Entrega un resultado listo para usar, claro y bien redactado. Si faltan detalles, haz supuestos razonables sin inventar datos personales. Solicitud:\n${input}` },
    summary: { title: 'Resumir contenido', subtitle: 'Quédate con lo importante, sin perder el contexto.', icon: 'file', tone: 'tone-coral', label: 'Pega el texto que quieres resumir', placeholder: 'Pega aquí un artículo, apuntes, un documento o cualquier texto...', options: ['Breve', 'Detallado', 'Puntos clave', 'Explicación sencilla'], button: 'Resumir texto', empty: 'Las ideas esenciales, sin leerlo todo.', prompt: (input, option) => `Resume el siguiente contenido en español. Formato solicitado: ${option}. Sé fiel al material original; no agregues datos que no estén en el texto. Si es útil, organiza el resumen con títulos y puntos claros. Contenido:\n${input}` },
    translate: { title: 'Traducir textos', subtitle: 'Tus palabras, sin fronteras ni barreras.', icon: 'globe', tone: 'tone-mint', label: 'Texto que quieres traducir', placeholder: 'Escribe o pega aquí el texto que quieres traducir...', options: ['Inglés', 'Español', 'Francés', 'Portugués', 'Alemán', 'Italiano', 'Japonés'], button: 'Traducir ahora', empty: 'Una traducción natural que suena a ti.', prompt: (input, option) => `Traduce el siguiente texto al ${option}. Detecta automáticamente el idioma original. Conserva el significado, el tono y el formato; devuelve únicamente la traducción, sin comentarios ni introducciones. Texto:\n${input}` },
    code: { title: 'Asistente de código', subtitle: 'Construye, depura y aprende a programar.', icon: 'code', tone: 'tone-gold', label: '¿Qué quieres crear o resolver?', placeholder: 'Ej.: Crea una función que ordene una lista de objetos por fecha y explícame cómo funciona...', options: ['JavaScript', 'Python', 'TypeScript', 'SQL', 'HTML/CSS'], button: 'Generar solución', empty: 'Del problema a la solución, paso a paso.', prompt: (input, option) => `Eres un asistente de programación. Resuelve la solicitud usando ${option} cuando corresponda. Incluye código correcto y utilizable en un bloque Markdown, una explicación breve y consideraciones relevantes. Si te piden depurar, identifica el problema con precisión. Solicitud:\n${input}` },
    study: { title: 'Aprender con IA', subtitle: 'Entiende temas difíciles a tu propio ritmo.', icon: 'study', tone: 'tone-violet', label: '¿Qué tema quieres aprender?', placeholder: 'Ej.: Explícame la fotosíntesis como si estuviera empezando a estudiarla...', options: ['Explicación', 'Guía de estudio', 'Preguntas de repaso', 'Tarjetas de memoria'], button: 'Empezar a aprender', empty: 'Cada pregunta te lleva un paso más lejos.', prompt: (input, option) => `Actúa como un profesor paciente y riguroso. Ayuda a estudiar este tema: ${input}. Formato: ${option}. Explica con claridad, usa ejemplos concretos y estructura la respuesta para facilitar el aprendizaje. Si no estás seguro de un dato, dilo.` },
    ideas: { title: 'Generador de ideas', subtitle: 'Cuando necesitas una chispa de inspiración.', icon: 'bulb', tone: 'tone-pink', label: '¿Para qué necesitas ideas?', placeholder: 'Ej.: Ideas originales para lanzar una tienda de plantas en redes sociales...', options: ['Negocios', 'Contenido', 'Diseño', 'Vida diaria'], button: 'Generar ideas', empty: 'La siguiente buena idea está a una pregunta.', prompt: (input, option) => `Genera ideas originales, específicas y realizables en la categoría ${option}. Objetivo: ${input}. Propón al menos 6 ideas distintas. Para cada una escribe un nombre breve y una descripción accionable. Evita lugares comunes y adapta las sugerencias al objetivo.` },
  };
  const featureCards = [
    { view: 'chat', title: 'Chat con IA', desc: 'Pregúntale lo que quieras a tu asistente personal.', icon: 'chat', tone: 'tone-violet' },
    { view: 'image', title: 'Crear imágenes', desc: 'Convierte tus ideas en imágenes únicas.', icon: 'image', tone: 'tone-coral' },
    { view: 'write', title: 'Escribir mejor', desc: 'Correos, historias y textos a tu manera.', icon: 'pen', tone: 'tone-blue' },
    { view: 'summary', title: 'Resumir textos', desc: 'Entiende lo esencial en mucho menos tiempo.', icon: 'file', tone: 'tone-mint' },
    { view: 'translate', title: 'Traducir', desc: 'Comunica tus ideas en cualquier idioma.', icon: 'globe', tone: 'tone-gold' },
    { view: 'code', title: 'Programar', desc: 'Escribe código y resuelve problemas.', icon: 'code', tone: 'tone-pink' },
  ];

  function saveLocal() {
    try { localStorage.setItem(SESSION_KEY, JSON.stringify(sessions.slice(0, 65))); localStorage.setItem(GALLERY_KEY, JSON.stringify(gallery.slice(0, 16))); }
    catch { toast('El almacenamiento del dispositivo está lleno.', true); }
  }
  function sortedSessions() { return [...sessions].sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0)); }
  function formatDate(date) { try { return new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short' }).format(new Date(date)); } catch { return ''; } }
  function timeAgo(date) {
    const diff = Date.now() - new Date(date).getTime();
    if (!Number.isFinite(diff)) return '';
    if (diff < 60000) return 'Ahora mismo';
    if (diff < 3600000) return `Hace ${Math.floor(diff / 60000)} min`;
    if (diff < 86400000) return `Hace ${Math.floor(diff / 3600000)} h`;
    return formatDate(date);
  }
  function toast(message, error = false) {
    const el = $('#toast'); el.textContent = message; el.classList.toggle('error', error); el.classList.add('show');
    clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => el.classList.remove('show'), 3900);
  }
  function viewIcon(view) { return ({ chat: 'chat', image: 'image', write: 'pen', summary: 'file', translate: 'globe', code: 'code', study: 'study', ideas: 'bulb' })[view] || 'chat'; }
  function viewTone(view) { return ({ chat: 'tone-violet', image: 'tone-coral', write: 'tone-blue', summary: 'tone-mint', translate: 'tone-gold', code: 'tone-pink', study: 'tone-violet', ideas: 'tone-pink' })[view] || 'tone-violet'; }
  function workHeader(title, subtitle, symbol, tone, right = '') {
    return `<div class="work-heading"><div class="work-heading-left"><div class="work-icon ${tone}">${icon(symbol)}</div><div><h1>${escapeHTML(title)}</h1><p>${escapeHTML(subtitle)}</p></div></div>${right}</div>`;
  }
  function renderHome() {
    const recent = sortedSessions().slice(0, 2);
    const date = new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
    return `<div class="page-heading"><div><h1>Hola, bienvenido a Auria <span aria-hidden="true">✳</span></h1><p>Un espacio para hacer realidad todo lo que imaginas.</p></div><span class="date-label">${escapeHTML(date)}</span></div>
      <section class="hero-banner"><img class="hero-art" src="./images/hero-orb.png" alt="" aria-hidden="true"><div class="hero-content"><span class="hero-eyebrow"><b>✦</b> TU ESPACIO CREATIVO CON IA</span><h2>Las grandes ideas<br><em>empiezan aquí.</em></h2><p>Conversa, crea, aprende y resuelve. Todo lo que necesitas para dar vida a tus ideas, en un solo lugar.</p><button class="hero-cta" data-action="new-chat">Empezar a crear ${icon('arrow-right')}</button></div></section>
      <div class="section-heading"><div><h2>¿Qué te gustaría hacer hoy?</h2><p>Elige una herramienta y deja que la creatividad fluya.</p></div><button class="section-link" data-action="show-tools">Explorar todas ${icon('arrow-right')}</button></div>
      <div class="tool-grid">${featureCards.map(card => `<button class="tool-card" data-view="${card.view}"><div class="tool-icon ${card.tone}">${icon(card.icon)}</div><span class="tool-arrow">${icon('arrow-up-right')}</span><h3>${card.title}</h3><p>${card.desc}</p></button>`).join('')}</div>
      <div class="dashboard-lower"><section class="lower-card"><div class="lower-heading"><h3>Continúa donde lo dejaste</h3><button class="section-link" data-view="history">Ver historial ${icon('arrow-right')}</button></div>${recent.length ? recent.map(s => `<button class="recent-row" data-action="open-session" data-id="${escapeHTML(s.id)}"><span class="recent-bubble">${icon(viewIcon(s.tool))}</span><span class="recent-details"><span class="recent-title">${escapeHTML(s.title)}</span><span class="recent-time">${escapeHTML(names[s.tool] || 'Conversación')} · ${timeAgo(s.updatedAt)}</span></span>${icon('chevron-right')}</button>`).join('') : `<p class="lower-empty">Tus conversaciones y creaciones aparecerán aquí.<br>Empieza explorando cualquiera de las herramientas.</p>`}</section>
      <section class="lower-card tip-card"><span class="tip-icon">${icon('bulb')}</span><h3>Una idea para empezar</h3><p>Cuéntale a Auria un proyecto que tengas en mente y pídele un plan para hacerlo realidad.</p><button data-action="inspiration">Pruébalo ahora ${icon('arrow-right')}</button></section></div>`;
  }
  function inlineMarkdown(line) {
    return escapeHTML(line).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>').replace(/`([^`]+)`/g, '<code>$1</code>');
  }
  function renderMarkdown(source) {
    const pieces = String(source || '').split('```');
    return pieces.map((part, index) => {
      if (index % 2) {
        const newline = part.indexOf('\n');
        const language = newline >= 0 ? part.slice(0, newline).trim().slice(0, 25) : '';
        const code = newline >= 0 ? part.slice(newline + 1).trimEnd() : part;
        return `<div class="code-block"><div class="code-head"><span>${escapeHTML(language || 'Código')}</span><button data-action="copy-code">Copiar código</button></div><pre><code>${escapeHTML(code)}</code></pre></div>`;
      }
      return part.split('\n').map(line => {
        const trimmed = line.trim();
        if (!trimmed) return '<div style="height:7px"></div>';
        if (/^###\s/.test(trimmed)) return `<h3>${inlineMarkdown(trimmed.slice(4))}</h3>`;
        if (/^##?\s/.test(trimmed)) return `<h2>${inlineMarkdown(trimmed.replace(/^##?\s/, ''))}</h2>`;
        if (/^[-*]\s/.test(trimmed)) return `<div style="padding-left:16px;position:relative"><span style="position:absolute;left:3px">•</span>${inlineMarkdown(trimmed.slice(2))}</div>`;
        if (/^\d+\.\s/.test(trimmed)) return `<div style="padding-left:4px">${inlineMarkdown(trimmed)}</div>`;
        if (/^>\s?/.test(trimmed)) return `<blockquote>${inlineMarkdown(trimmed.replace(/^>\s?/, ''))}</blockquote>`;
        return `<p>${inlineMarkdown(line)}</p>`;
      }).join('');
    }).join('');
  }
  function renderMessage(message, index) {
    const user = message.role === 'user';
    const body = user ? escapeHTML(message.content || '') : renderMarkdown(message.content || '');
    const attachment = user && message.attachmentName ? `<div class="attachment-chip" style="margin:0 0 8px">${icon('file')}${escapeHTML(message.attachmentName)}</div>` : '';
    return `<div class="chat-message ${user ? 'user' : 'assistant'}">${user ? '' : `<span class="message-avatar">${icon('sparkles')}</span>`}<div class="message-content"><div class="message-meta">${user ? 'Tú' : 'Auria AI'}</div><div class="message-bubble ${user ? '' : 'markdown'}">${attachment}${body}</div><div class="message-actions"><button class="message-action" data-action="copy-message" data-index="${index}" aria-label="Copiar mensaje" title="Copiar">${icon('copy')}</button>${user ? '' : `<button class="message-action" data-action="speak-message" data-index="${index}" aria-label="Escuchar respuesta" title="Escuchar">${icon('volume')}</button>`}</div></div></div>`;
  }
  function renderChat() {
    const session = sessions.find(s => s.id === state.currentSessionId);
    const messages = session?.messages || [];
    const suggestions = [
      ['bulb', 'Dame ideas para un proyecto'], ['pen', 'Ayúdame a escribir un correo'],
      ['study', 'Explícame un tema difícil'], ['code', 'Ayúdame con código'],
    ];
    const chatBody = messages.length ? messages.map(renderMessage).join('') + (state.busy ? `<div class="chat-message assistant"><span class="message-avatar">${icon('sparkles')}</span><div class="message-content"><div class="message-meta">Auria AI está pensando...</div><div class="message-bubble"><span class="typing-dots"><i></i><i></i><i></i></span></div></div></div>` : (!state.busy && messages[messages.length - 1]?.role === 'user' ? `<div style="text-align:center;margin:4px 0 18px"><button class="outline-btn" data-action="retry-chat">${icon('refresh')} Reintentar respuesta</button></div>` : '')) : `<div class="chat-empty"><span class="chat-empty-mark">${icon('sparkles')}</span><h2>¿En qué puedo ayudarte hoy?</h2><p>Pregunta lo que quieras. Estoy aquí para ayudarte a pensar, crear y hacer más.</p><div class="suggestion-grid">${suggestions.map(([symbol, text]) => `<button class="suggestion" data-action="suggestion" data-text="${escapeHTML(text)}">${icon(symbol)} ${escapeHTML(text)}</button>`).join('')}</div></div>`;
    return `${workHeader('Chat con Auria', 'Tu asistente para cualquier idea, pregunta o desafío.', 'chat', 'tone-violet', `<button class="outline-btn" data-action="new-chat">${icon('plus')} Nueva conversación</button>`)}<div class="chat-shell"><div class="chat-stream" id="chat-stream">${chatBody}</div><div class="chat-composer-wrap">${state.attachment ? `<span class="attachment-chip">${icon('file')}${escapeHTML(state.attachment.name)}<button data-action="remove-attachment" title="Quitar archivo">${icon('close')}</button></span>` : ''}<div class="chat-composer"><button class="composer-icon" data-action="attach" title="Adjuntar documento" aria-label="Adjuntar documento">${icon('attach')}</button><textarea id="chat-input" rows="1" maxlength="9000" placeholder="Escribe tu mensaje aquí..." ${state.busy ? 'disabled' : ''}></textarea><button class="composer-icon" data-action="dictate" title="Dictar por voz" aria-label="Dictar por voz">${icon(state.listening ? 'stop' : 'mic')}</button><button class="composer-send" data-action="send-chat" aria-label="Enviar mensaje" ${state.busy ? 'disabled' : ''}>${icon('send')}</button></div><div class="composer-note"><span>Adjunta textos o PDF · Enter para enviar</span><span>IA gratuita con conexión</span></div></div></div>`;
  }
  function renderTool(view) {
    const tool = tools[view]; const draft = state.drafts[view] || {}; const selected = draft.option || tool.options[0];
    const result = draft.result;
    return `${workHeader(tool.title, tool.subtitle, tool.icon, tool.tone)}<div class="tool-layout"><section class="panel form-panel"><div class="panel-label">${icon('pen')} TU SOLICITUD</div><form id="tool-form" data-tool="${view}"><div class="field-block"><label class="small-label" for="tool-input">${tool.label}</label><textarea id="tool-input" class="field-textarea" maxlength="9000" placeholder="${escapeHTML(tool.placeholder)}">${escapeHTML(draft.input || '')}</textarea><p class="field-hint">Escribe con tus propias palabras. Cuanto más contexto, mejor resultado.</p></div><div class="field-block"><span class="small-label">${view === 'translate' ? 'Traducir a' : view === 'code' ? 'Lenguaje preferido' : view === 'summary' ? 'Tipo de resumen' : view === 'study' ? 'Cómo quieres aprender' : view === 'ideas' ? 'Categoría' : 'Tono del texto'}</span><div class="chip-row">${tool.options.map(option => `<button type="button" class="choice-chip ${selected === option ? 'selected' : ''}" data-action="tool-option" data-option="${escapeHTML(option)}">${escapeHTML(option)}</button>`).join('')}</div></div><div class="form-footer"><span>${icon('sparkles')} Impulsado por IA</span><button class="primary-btn" type="submit" ${state.busy ? 'disabled' : ''}>${state.busy ? '<span class="spinner white"></span> Creando...' : `${icon('sparkles')} ${tool.button}`}</button></div></form></section>
      <section class="panel result-panel"><div class="panel-label"><span>${icon('sparkles')} RESULTADO</span>${result ? `<span class="result-actions"><button data-action="copy-result" title="Copiar resultado" aria-label="Copiar resultado">${icon('copy')}</button><button data-action="speak-result" title="Escuchar resultado" aria-label="Escuchar resultado">${icon('volume')}</button></span>` : ''}</div>${result ? `<div class="result-body markdown">${renderMarkdown(result)}</div><div class="result-footer"><button class="outline-btn" data-action="save-result">${icon('bookmark')} ${draft.saved ? 'Guardado' : 'Guardar'}</button><button class="outline-btn" data-action="share-result">${icon('external')} Compartir</button></div>` : state.busy ? `<div class="result-empty"><span class="result-empty-mark"><span class="spinner"></span></span><h3>Preparando tu resultado...</h3><p>Un momento, Auria está trabajando en tu solicitud.</p></div>` : `<div class="result-empty"><span class="result-empty-mark">${icon(tool.icon)}</span><h3>Tu resultado aparecerá aquí</h3><p>${tool.empty}</p></div>`}</section></div>`;
  }
  function renderImage() {
    const examples = ['Una cabaña entre nubes al atardecer', 'Un gato astronauta en la luna', 'Una ciudad futurista llena de flores'];
    const current = state.currentImage;
    return `${workHeader('Crear imágenes', 'Convierte lo que imaginas en algo que puedas ver.', 'image', 'tone-coral')}<div class="image-layout"><section class="panel image-form"><div class="panel-label">${icon('sparkles')} DESCRIBE TU IDEA</div><div class="field-block"><label class="small-label" for="image-prompt">¿Qué quieres crear?</label><textarea id="image-prompt" class="field-textarea" maxlength="850" placeholder="Ej.: Un pequeño café en una calle de París, luces cálidas, ilustración detallada...">${escapeHTML(state.imagePrompt)}</textarea><p class="field-hint">Describe sujetos, colores, iluminación y ambiente para obtener mejores resultados.</p></div><div class="field-block"><span class="small-label">Estilo visual</span><div class="chip-row">${['Fotográfico', 'Ilustración', 'Arte 3D', 'Acuarela'].map(v => `<button class="choice-chip ${state.imageStyle === v ? 'selected' : ''}" data-action="image-style" data-value="${v}">${v}</button>`).join('')}</div></div><div class="field-block"><span class="small-label">Formato</span><div class="chip-row">${['Cuadrado', 'Horizontal', 'Vertical'].map(v => `<button class="choice-chip ${state.imageRatio === v ? 'selected' : ''}" data-action="image-ratio" data-value="${v}">${v}</button>`).join('')}</div></div><button class="primary-btn" data-action="generate-image" style="width:100%" ${state.imageBusy ? 'disabled' : ''}>${state.imageBusy ? '<span class="spinner white"></span> Creando imagen...' : `${icon('sparkles')} Generar imagen`}</button><p class="field-hint" style="text-align:center;margin-top:11px">Generación online gratuita · Puede tardar unos segundos</p><div style="border-top:1px solid var(--line);margin:21px 0 16px"></div><span class="small-label">Prueba una idea</span><div class="chip-row">${examples.map(ex => `<button class="choice-chip" data-action="image-example" data-text="${escapeHTML(ex)}">${escapeHTML(ex)}</button>`).join('')}</div></section><section class="panel image-output"><div class="panel-label">${icon('image')} TU CREACIÓN</div><div class="image-preview ${current ? 'has-image' : ''}" id="image-preview">${state.imageBusy ? `<div class="image-empty"><span class="spinner" style="width:35px;height:35px;margin-bottom:19px"></span><h3>Tu imagen está tomando forma</h3><p>La generación puede tardar entre 15 y 60 segundos.</p></div>` : current ? `<img src="${escapeHTML(current.displayUrl || current.url)}" alt="Imagen generada: ${escapeHTML(current.prompt)}">` : `<div class="image-empty"><span class="image-empty-art">${icon('image')}</span><h3>Imagina. Describe. Crea.</h3><p>Escribe una idea y Auria la convertirá en una imagen única.</p></div>`}</div>${current && !state.imageBusy ? `<div class="image-actions"><span>${escapeHTML(current.prompt.slice(0, 55))}${current.prompt.length > 55 ? '...' : ''}</span><button class="outline-btn" data-action="download-image">${icon('download')} Descargar imagen</button></div>` : ''}</section></div>${gallery.length ? `<section class="image-gallery"><div class="section-heading"><div><h2>Tus últimas creaciones</h2><p>Vuelve a inspirarte con lo que ya creaste.</p></div></div><div class="gallery-grid">${gallery.slice(0, 8).map(g => `<button class="gallery-card" data-action="open-image" data-id="${escapeHTML(g.id)}"><img src="${escapeHTML(g.url)}" alt="${escapeHTML(g.prompt)}" loading="lazy"><span>${escapeHTML(g.prompt)}</span></button>`).join('')}</div></section>` : ''}`;
  }
  function renderLibrary(savedOnly = false) {
    const items = sortedSessions().filter(s => !savedOnly || s.favorite).filter(s => `${s.title} ${s.tool}`.toLowerCase().includes(state.libraryQuery.toLowerCase()));
    return `${workHeader(savedOnly ? 'Tus guardados' : 'Tu historial', savedOnly ? 'Las ideas que quieres tener siempre a mano.' : 'Todas tus conversaciones y creaciones, en un solo lugar.', savedOnly ? 'bookmark' : 'history', 'tone-violet', !savedOnly ? `<button class="outline-btn" data-action="new-chat">${icon('plus')} Nueva conversación</button>` : '')}<div class="library-toolbar"><label class="library-search">${icon('search')}<input id="library-search" type="search" placeholder="Buscar ${savedOnly ? 'guardados' : 'en el historial'}..." value="${escapeHTML(state.libraryQuery)}" autocomplete="off"></label><span class="library-count">${items.length} ${items.length === 1 ? 'elemento' : 'elementos'}</span></div>${items.length ? `<div class="session-list">${items.map(s => `<article class="session-card"><span class="tool-icon ${viewTone(s.tool)}">${icon(viewIcon(s.tool))}</span><button class="session-main" data-action="open-session" data-id="${escapeHTML(s.id)}"><strong>${escapeHTML(s.title || 'Sin título')}</strong><span>${escapeHTML(names[s.tool] || 'Conversación')} · ${escapeHTML((s.messages.find(m => m.role === 'assistant')?.content || s.messages[0]?.content || '').slice(0, 90))}</span></button><span class="session-date">${timeAgo(s.updatedAt)}</span><button class="session-action ${s.favorite ? 'active' : ''}" data-action="favorite-session" data-id="${escapeHTML(s.id)}" title="${s.favorite ? 'Quitar de guardados' : 'Guardar'}" aria-label="${s.favorite ? 'Quitar de guardados' : 'Guardar'}">${icon('heart')}</button><button class="session-action" data-action="delete-session" data-id="${escapeHTML(s.id)}" title="Eliminar" aria-label="Eliminar">${icon('trash')}</button></article>`).join('')}</div>` : `<div class="library-empty"><span class="tool-icon tone-violet">${icon(savedOnly ? 'bookmark' : 'history')}</span><h2>${state.libraryQuery ? 'No encontramos coincidencias' : savedOnly ? 'Todavía no tienes guardados' : 'Tu historia empieza aquí'}</h2><p>${state.libraryQuery ? 'Prueba con otro término de búsqueda.' : savedOnly ? 'Guarda tus mejores respuestas para volver a ellas cuando quieras.' : 'Cada conversación y creación que hagas aparecerá aquí.'}</p>${!state.libraryQuery ? `<button class="primary-btn" data-action="new-chat">${icon('plus')} Empezar una conversación</button>` : ''}</div>`}`;
  }
  function renderDownload() {
    return `<div class="page-heading"><div><h1>Auria en todas partes</h1><p>Tu espacio creativo, también en tu teléfono.</p></div></div><section class="download-banner"><div class="download-copy"><span class="download-tag">${icon('smartphone')} AURIA PARA ANDROID</span><h1>Tu creatividad<br><span>va contigo.</span></h1><p>Conversa con la IA, crea imágenes y explora todas tus herramientas favoritas directamente desde tu móvil.</p>${nativeApp ? `<span class="download-primary">${icon('check')} Auria ya está instalada</span>` : `<a class="download-primary" href="./downloads/auria-ai.apk" download="auria-ai.apk">${icon('download')} Descargar APK gratis</a>`}<span class="download-note">${nativeApp ? 'Estás usando la aplicación de Android.' : 'Archivo APK real · Android 8.0 o superior · Sin registro'}</span></div><div class="phone-wrap"><div class="phone-mock"><div class="phone-notch"></div><div class="phone-brand">auria<span>.</span></div><div class="phone-greeting">Las grandes ideas<br>empiezan aquí.</div><div class="phone-mini-hero"></div><div class="phone-mini-label">TU ESPACIO CREATIVO</div><div class="phone-mini-grid"><span>✦ Chat con IA</span><span>◈ Imágenes</span><span>✎ Escribir</span><span>◎ Aprender</span></div></div></div></section><div class="section-heading"><div><h2>Lista para usar en 3 pasos</h2><p>Sin programar, sin configurar y sin crear una cuenta.</p></div></div><div class="steps-grid"><div class="step-card"><span class="step-num">01</span><div><strong>Descarga el archivo</strong><p>Toca el botón de arriba para guardar Auria AI en tu Android.</p></div></div><div class="step-card"><span class="step-num">02</span><div><strong>Instala la aplicación</strong><p>Abre el APK y permite la instalación desde tu navegador si Android te lo pide.</p></div></div><div class="step-card"><span class="step-num">03</span><div><strong>Empieza a crear</strong><p>Abre Auria y usa el chat, las imágenes y todas las herramientas.</p></div></div></div><div class="privacy-note">${icon('shield')}<span>La generación de IA necesita internet y utiliza servicios externos (Pollinations en el modo gratuito), sujetos a límites de uso y disponibilidad. Tus conversaciones se guardan en este dispositivo${nativeApp ? '.' : ' y se sincronizan con este sitio mediante un identificador anónimo.'} No necesitas programar ni proporcionar una clave API.</span></div>${!nativeApp && state.deferredInstall ? `<button class="outline-btn" data-action="install-pwa" style="margin-top:18px">${icon('smartphone')} Instalar también como app web</button>` : ''}`;
  }
  function render(resetScroll = true) {
    $('#breadcrumb-current').textContent = names[state.view] || 'Inicio';
    document.querySelectorAll('[data-view]').forEach(el => el.classList.toggle('active', el.dataset.view === state.view && (el.classList.contains('nav-item') || el.classList.contains('mobile-nav-item'))));
    const root = $('#view-root');
    root.innerHTML = state.view === 'home' ? renderHome() : state.view === 'chat' ? renderChat() : state.view === 'image' ? renderImage() : tools[state.view] ? renderTool(state.view) : state.view === 'history' ? renderLibrary(false) : state.view === 'saved' ? renderLibrary(true) : renderDownload();
    if (resetScroll) $('#main-scroll').scrollTop = 0;
    if (state.view === 'chat') { const stream = $('#chat-stream'); if (stream) stream.scrollTop = stream.scrollHeight; }
  }
  function closeSidebar() { $('#sidebar').classList.remove('open'); $('#sidebar-scrim').classList.remove('open'); }
  function navigate(view) {
    if (!(view in names)) view = 'home';
    closeSidebar(); closeModal(); state.view = view; state.libraryQuery = '';
    if (location.hash !== `#${view}`) history.pushState(null, '', `#${view}`);
    render();
  }
  function newChat() { state.currentSessionId = null; state.attachment = null; navigate('chat'); setTimeout(() => $('#chat-input')?.focus(), 50); }
  function currentSession() { return sessions.find(s => s.id === state.currentSessionId); }
  function updateConnection() {
    const el = $('#connection-badge'); el.classList.toggle('offline', !navigator.onLine);
    $('#connection-text').textContent = navigator.onLine ? 'IA en línea' : 'Sin conexión';
  }
  async function requestAI(messages, mode = 'chat') {
    if (!navigator.onLine) throw new Error('Necesitas conexión a internet para usar la IA.');
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 65000);
    try {
      const context = messages.slice(-14).map(m => ({ role: m.role, content: (m.content || '') + (m.attachmentText ? `\n\nArchivo adjunto (${m.attachmentName}):\n${m.attachmentText}` : '') }));
      while (context.length > 1 && context.reduce((size, message) => size + message.content.length, 0) > 44000) context.shift();
      const payload = { mode, messages: context };
      const url = nativeApp ? 'https://text.pollinations.ai/openai' : '/api/chat';
      const body = nativeApp ? { model: 'openai', messages: [{ role: 'system', content: 'Eres Auria, una asistente de IA clara, útil y amable. Responde en español salvo que pidan traducir a otro idioma. Sé honesta si no sabes algo. Organiza respuestas largas con Markdown.' }, ...payload.messages], max_tokens: 1800 } : payload;
      const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: controller.signal });
      const raw = await response.text(); let data;
      try { data = JSON.parse(raw); } catch { data = null; }
      if (!response.ok || (data && data.error)) {
        if (response.status === 402 || response.status === 429 || data?.error?.code === 'FREE_LIMIT') throw new Error('El servicio gratuito alcanzó su límite. Espera unos 30 segundos y vuelve a intentarlo.');
        throw new Error(typeof data?.error === 'string' ? data.error : data?.error?.message || 'No se pudo obtener una respuesta. Inténtalo de nuevo.');
      }
      const answer = typeof data?.answer === 'string' ? data.answer : data?.choices?.[0]?.message?.content || (typeof data === 'string' ? data : raw);
      if (!answer || typeof answer !== 'string') throw new Error('La IA no devolvió una respuesta. Inténtalo otra vez.');
      return answer.trim();
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('La respuesta tardó demasiado. Vuelve a intentarlo.');
      if (error instanceof TypeError) throw new Error('No se pudo conectar con el servicio de IA. Comprueba tu internet e inténtalo otra vez.');
      throw error;
    } finally { clearTimeout(timer); }
  }
  async function persistSession(session) {
    if (nativeApp) return;
    try { await fetch('/api/conversations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerId, session }) }); } catch { /* local copy remains available */ }
  }
  async function syncSessions() {
    if (nativeApp) return;
    try {
      const response = await fetch(`/api/conversations?ownerId=${encodeURIComponent(ownerId)}`);
      if (!response.ok) return;
      const data = await response.json();
      if (!Array.isArray(data.sessions)) return;
      let changed = false;
      for (const remote of data.sessions) {
        if (!remote || !remote.id || !Array.isArray(remote.messages)) continue;
        if (!sessions.some(local => local.id === remote.id)) { sessions.push(remote); changed = true; }
      }
      if (changed) { saveLocal(); if (['home', 'history', 'saved'].includes(state.view)) render(false); }
    } catch { /* offline history is still usable */ }
  }
  async function answerChat(session) {
    if (state.busy) return;
    state.busy = true; render(false);
    try {
      const answer = await requestAI(session.messages, 'chat');
      session.messages.push({ role: 'assistant', content: answer });
      session.updatedAt = new Date().toISOString(); saveLocal(); persistSession(session);
    } catch (error) { toast(error.message || 'No se pudo responder.', true); }
    finally { state.busy = false; render(false); }
  }
  async function sendChat(textOverride) {
    if (state.busy) return;
    const text = (textOverride ?? $('#chat-input')?.value ?? '').trim();
    if (!text && !state.attachment) { toast('Escribe un mensaje para empezar.'); return; }
    let session = currentSession();
    if (!session) {
      session = { id: uid(), title: (text || `Análisis de ${state.attachment?.name || 'documento'}`).slice(0, 70), tool: 'chat', messages: [], favorite: false, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      sessions.unshift(session); state.currentSessionId = session.id;
    }
    session.messages.push({ role: 'user', content: text || `Analiza el archivo ${state.attachment.name} y explica sus puntos más importantes.`, ...(state.attachment ? { attachmentName: state.attachment.name, attachmentText: state.attachment.text.slice(0, 14000) } : {}) });
    session.updatedAt = new Date().toISOString(); state.attachment = null; saveLocal(); persistSession(session);
    await answerChat(session);
  }
  async function submitTool() {
    if (state.busy) return;
    const view = state.view, tool = tools[view]; if (!tool) return;
    const input = $('#tool-input')?.value.trim();
    if (!input || input.length < 3) { toast('Escribe un poco más sobre lo que necesitas.'); $('#tool-input')?.focus(); return; }
    const draft = state.drafts[view] || {}; draft.input = input; draft.option = draft.option || tool.options[0]; draft.result = ''; draft.saved = false; state.drafts[view] = draft;
    state.busy = true; render(false);
    try {
      const result = await requestAI([{ role: 'user', content: tool.prompt(input, draft.option) }], view);
      draft.result = result;
      let session = sessions.find(s => s.id === draft.sessionId);
      if (!session) { session = { id: uid(), title: input.slice(0, 70), tool: view, messages: [], favorite: false, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), option: draft.option, prompt: input }; sessions.unshift(session); draft.sessionId = session.id; }
      session.title = input.slice(0, 70); session.prompt = input; session.option = draft.option; session.messages = [{ role: 'user', content: input }, { role: 'assistant', content: result }]; session.updatedAt = new Date().toISOString();
      saveLocal(); persistSession(session);
    } catch (error) { toast(error.message || 'No se pudo crear el resultado.', true); }
    finally { state.busy = false; render(false); }
  }
  async function generateImage() {
    if (state.imageBusy) return;
    const prompt = $('#image-prompt')?.value.trim();
    if (!prompt || prompt.length < 4) { toast('Describe la imagen que quieres crear.'); $('#image-prompt')?.focus(); return; }
    state.imagePrompt = prompt;
    const styleHint = { 'Fotográfico': 'photorealistic, professional photography, detailed lighting', 'Ilustración': 'beautiful digital illustration, artistic and detailed', 'Arte 3D': 'premium 3D render, soft studio lighting, detailed materials', 'Acuarela': 'delicate watercolor painting on textured paper' }[state.imageStyle];
    const dimensions = { Cuadrado: [768, 768], Horizontal: [1024, 576], Vertical: [576, 1024] }[state.imageRatio];
    const fullPrompt = `${prompt}. ${styleHint}`; const seed = Math.floor(Math.random() * 9000000) + 1000000;
    const params = new URLSearchParams({ prompt: fullPrompt, width: String(dimensions[0]), height: String(dimensions[1]), seed: String(seed) });
    const url = nativeApp ? `https://image.pollinations.ai/prompt/${encodeURIComponent(fullPrompt)}?width=${dimensions[0]}&height=${dimensions[1]}&seed=${seed}` : `/api/image?${params.toString()}`;
    state.imageBusy = true; render(false);
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 110000);
    try {
      const response = await fetch(url, { signal: controller.signal });
      if (!response.ok) {
        let data; try { data = await response.json(); } catch { /* ignore */ }
        throw new Error(data?.error || (response.status === 402 || response.status === 429 ? 'El servicio gratuito está ocupado. Espera un momento e inténtalo otra vez.' : 'No se pudo generar la imagen. Inténtalo de nuevo.'));
      }
      const blob = await response.blob();
      if (!blob.type.startsWith('image/')) throw new Error('El servicio no devolvió una imagen. Inténtalo de nuevo.');
      const item = { id: uid(), prompt, url, style: state.imageStyle, ratio: state.imageRatio, createdAt: new Date().toISOString(), displayUrl: URL.createObjectURL(blob) };
      state.currentImage = item; gallery.unshift({ id: item.id, prompt, url, style: item.style, ratio: item.ratio, createdAt: item.createdAt }); gallery.splice(16); saveLocal(); toast('¡Tu imagen está lista!');
    } catch (error) {
      toast(error.name === 'AbortError' ? 'La imagen tardó demasiado. Prueba otra vez.' : error.message || 'No se pudo generar la imagen.', true);
    } finally { clearTimeout(timer); state.imageBusy = false; render(false); }
  }
  async function downloadImage() {
    const item = state.currentImage; if (!item) return;
    if (nativeApp && window.AuriaNative?.downloadImage) { window.AuriaNative.downloadImage(item.url, `auria-${Date.now()}.jpg`); toast('Descarga iniciada. Revisa tu carpeta Descargas.'); return; }
    try {
      const response = await fetch(item.displayUrl || item.url); if (!response.ok) throw new Error();
      const blob = await response.blob(); const temp = URL.createObjectURL(blob);
      const link = document.createElement('a'); link.href = temp; link.download = `auria-${Date.now()}.${blob.type.includes('png') ? 'png' : 'jpg'}`; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(temp), 15000);
      toast('Imagen descargada.');
    } catch { toast('No se pudo descargar la imagen. Inténtalo otra vez.', true); }
  }
  async function copyText(text) {
    if (nativeApp && window.AuriaNative?.copyText) { window.AuriaNative.copyText(text); toast('Copiado al portapapeles.'); return; }
    try { await navigator.clipboard.writeText(text); toast('Copiado al portapapeles.'); }
    catch { const area = document.createElement('textarea'); area.value = text; area.style.position = 'fixed'; area.style.opacity = '0'; document.body.append(area); area.select(); document.execCommand('copy'); area.remove(); toast('Copiado al portapapeles.'); }
  }
  async function shareText(text) {
    if (nativeApp && window.AuriaNative?.shareText) { window.AuriaNative.shareText(text); return; }
    if (navigator.share) { try { await navigator.share({ title: 'Creado con Auria AI', text }); } catch { /* user canceled */ } }
    else copyText(text);
  }
  function speakText(text) {
    if (nativeApp && window.AuriaNative?.speakText) { window.AuriaNative.speakText(text.slice(0, 3500)); toast('Reproduciendo respuesta...'); return; }
    if (!('speechSynthesis' in window)) { toast('La lectura en voz alta no está disponible en este dispositivo.', true); return; }
    speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text.slice(0, 3500)); utterance.lang = 'es-ES'; utterance.rate = 1; speechSynthesis.speak(utterance); toast('Reproduciendo respuesta...');
  }
  function startDictation() {
    if (nativeApp && window.AuriaNative?.startDictation) { window.AuriaNative.startDictation(); return; }
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) { toast('El dictado no está disponible en este dispositivo. Puedes escribir tu mensaje.', true); return; }
    if (state.listening) return;
    const recognition = new Recognition(); recognition.lang = 'es-ES'; recognition.interimResults = false; recognition.maxAlternatives = 1;
    recognition.onresult = (event) => { const input = $('#chat-input'); if (input) input.value = `${input.value}${input.value ? ' ' : ''}${event.results[0][0].transcript}`; };
    recognition.onerror = () => { toast('No se pudo escuchar. Comprueba el permiso del micrófono.', true); };
    recognition.onend = () => { state.listening = false; const button = $('[data-action="dictate"]'); if (button) button.innerHTML = icon('mic'); };
    try { recognition.start(); state.listening = true; const button = $('[data-action="dictate"]'); if (button) button.innerHTML = icon('stop'); toast('Escuchando... habla ahora.'); }
    catch { toast('No se pudo iniciar el micrófono.', true); }
  }
  async function handleFile(file) {
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { toast('El archivo debe pesar menos de 2 MB.', true); return; }
    try {
      let text;
      if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
        if (!window.pdfjsLib) {
          const pdfjs = await import('./vendor/pdf.min.mjs');
          pdfjs.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdf.worker.min.mjs', location.href).href;
          window.pdfjsLib = pdfjs;
        }
        const data = new Uint8Array(await file.arrayBuffer());
        const doc = await window.pdfjsLib.getDocument({ data, isEvalSupported: false }).promise; const pages = [];
        for (let i = 1; i <= Math.min(doc.numPages, 18); i++) { const page = await doc.getPage(i); const content = await page.getTextContent(); pages.push(content.items.map(item => item.str || '').join(' ')); }
        text = pages.join('\n\n');
        if (!text.trim()) throw new Error('Este PDF no contiene texto seleccionable. Prueba con un archivo de texto.');
      } else { text = await file.text(); }
      if (!text.trim()) throw new Error('El archivo parece estar vacío.');
      state.attachment = { name: file.name.slice(0, 80), text: text.slice(0, 14000) };
      if (state.view !== 'chat') navigate('chat'); else render(false);
      toast(`Archivo adjuntado: ${file.name}`);
    } catch (error) { toast(error.message || 'No se pudo leer el archivo.', true); }
    $('#file-input').value = '';
  }
  function openSession(id) {
    const session = sessions.find(s => s.id === id); if (!session) return;
    if (session.tool === 'chat' || !tools[session.tool]) { state.currentSessionId = session.id; navigate('chat'); return; }
    state.drafts[session.tool] = { input: session.prompt || session.messages[0]?.content || '', option: session.option || tools[session.tool].options[0], result: session.messages.findLast(m => m.role === 'assistant')?.content || '', sessionId: session.id, saved: !!session.favorite };
    navigate(session.tool);
  }
  function favoriteSession(id) {
    const session = sessions.find(s => s.id === id); if (!session) return;
    session.favorite = !session.favorite; saveLocal(); persistSession(session); render(false);
    toast(session.favorite ? 'Añadido a guardados.' : 'Eliminado de guardados.');
  }
  async function deleteSession(id) {
    const index = sessions.findIndex(s => s.id === id); if (index < 0) return;
    sessions.splice(index, 1); if (state.currentSessionId === id) state.currentSessionId = null;
    Object.values(state.drafts).forEach(draft => { if (draft.sessionId === id) draft.sessionId = null; });
    saveLocal(); render(false); toast('Elemento eliminado.');
    if (!nativeApp) { try { await fetch(`/api/conversations?ownerId=${encodeURIComponent(ownerId)}&id=${encodeURIComponent(id)}`, { method: 'DELETE' }); } catch { /* local deletion already completed */ } }
  }
  function closeModal() { $('#modal-backdrop').hidden = true; $('#modal-card').innerHTML = ''; }
  function openModal(markup) { $('#modal-card').innerHTML = markup; $('#modal-backdrop').hidden = false; }
  function modalHeader(title) { return `<div class="modal-header"><h2>${title}</h2><button class="icon-button" data-action="close-modal" aria-label="Cerrar">${icon('close')}</button></div>`; }
  function showAllTools() {
    openModal(`${modalHeader('Todas las herramientas')}<div class="modal-body"><p>Elige lo que necesitas y empieza a crear.</p><div class="search-results">${[...featureCards, { view: 'study', title: 'Aprender', icon: 'study' }, { view: 'ideas', title: 'Generar ideas', icon: 'bulb' }].map(card => `<button class="search-result" data-view="${card.view}">${icon(card.icon)}<span>${card.title}</span>${icon('chevron-right')}</button>`).join('')}</div></div>`);
  }
  function showSearch() {
    state.searchQuery = '';
    openModal(`${modalHeader('Buscar en Auria')}<div class="modal-body"><input id="global-search" class="modal-search" type="search" placeholder="Busca herramientas o conversaciones..." autocomplete="off"><div class="search-results" id="global-results"></div></div>`);
    updateSearchResults(); setTimeout(() => $('#global-search')?.focus(), 50);
  }
  function updateSearchResults() {
    const el = $('#global-results'); if (!el) return;
    const query = state.searchQuery.toLowerCase();
    const choices = [...featureCards, { view: 'study', title: 'Aprender', icon: 'study' }, { view: 'ideas', title: 'Generar ideas', icon: 'bulb' }].filter(t => t.title.toLowerCase().includes(query));
    const found = sortedSessions().filter(s => s.title.toLowerCase().includes(query)).slice(0, 5);
    el.innerHTML = [...choices.map(t => `<button class="search-result" data-view="${t.view}">${icon(t.icon)}<span>${t.title}</span>${icon('chevron-right')}</button>`), ...found.map(s => `<button class="search-result" data-action="open-session" data-id="${escapeHTML(s.id)}">${icon(viewIcon(s.tool))}<span>${escapeHTML(s.title)}</span>${icon('chevron-right')}</button>`)].join('') || '<div class="empty-search">No encontramos resultados.</div>';
  }
  function showSettings() {
    openModal(`${modalHeader('Configuración')}<div class="modal-body"><p>Personaliza Auria a tu manera. No necesitas registrarte.</p><div class="settings-option"><span>Apariencia oscura<small>Cambia el aspecto de tu espacio.</small></span><button class="switch ${document.body.classList.contains('dark') ? 'on' : ''}" data-action="toggle-theme" role="switch" aria-label="Activar modo oscuro" aria-checked="${document.body.classList.contains('dark')}"></button></div><div class="settings-option"><span>Servicio de IA<small>Conexión online gratuita, sujeta a límites.</small></span>${icon('globe')}</div><div class="settings-option"><span>Historial<small>Guardado en este dispositivo${nativeApp ? '' : ' y sincronizado con este sitio'}.</small></span>${icon('shield')}</div><button class="outline-btn" data-action="confirm-clear" style="margin-top:19px;color:#b35b69;border-color:#eddbdf">${icon('trash')} Borrar mi historial</button></div>`);
  }
  function confirmClear() {
    openModal(`${modalHeader('¿Borrar todo el historial?')}<div class="modal-body"><p>Se eliminarán tus conversaciones y resultados guardados. Esta acción no se puede deshacer.</p></div><div class="modal-footer"><button class="outline-btn" data-action="close-modal">Cancelar</button><button class="primary-btn" data-action="clear-history">Sí, borrar todo</button></div>`);
  }
  async function clearHistory() {
    const ids = sessions.map(s => s.id); sessions.splice(0); gallery.splice(0); state.currentSessionId = null; state.currentImage = null; state.drafts = {}; saveLocal(); closeModal(); navigate('home'); toast('Historial eliminado.');
    if (!nativeApp) { await Promise.allSettled(ids.map(id => fetch(`/api/conversations?ownerId=${encodeURIComponent(ownerId)}&id=${encodeURIComponent(id)}`, { method: 'DELETE' }))); }
  }

  document.addEventListener('click', async (event) => {
    const viewButton = event.target.closest('[data-view]');
    if (viewButton) { event.preventDefault(); navigate(viewButton.dataset.view); return; }
    const button = event.target.closest('[data-action]'); if (!button) return;
    event.preventDefault(); const action = button.dataset.action;
    if (action === 'new-chat') newChat();
    else if (action === 'inspiration') { newChat(); const input = $('#chat-input'); if (input) input.value = 'Tengo una idea para un proyecto. ¿Puedes ayudarme a convertirla en un plan de acción paso a paso?'; }
    else if (action === 'show-tools') showAllTools();
    else if (action === 'send-chat') sendChat();
    else if (action === 'retry-chat') { const session = currentSession(); if (session && session.messages.at(-1)?.role === 'user') answerChat(session); }
    else if (action === 'suggestion') { const input = $('#chat-input'); if (input) { input.value = button.dataset.text || ''; input.focus(); } }
    else if (action === 'tool-option') { const draft = state.drafts[state.view] || {}; draft.input = $('#tool-input')?.value || ''; draft.option = button.dataset.option; state.drafts[state.view] = draft; render(false); }
    else if (action === 'image-style' || action === 'image-ratio') { state.imagePrompt = $('#image-prompt')?.value || ''; if (action === 'image-style') state.imageStyle = button.dataset.value; else state.imageRatio = button.dataset.value; render(false); }
    else if (action === 'image-example') { state.imagePrompt = button.dataset.text || ''; render(false); $('#image-prompt')?.focus(); }
    else if (action === 'generate-image') generateImage();
    else if (action === 'download-image') downloadImage();
    else if (action === 'open-image') { const image = gallery.find(g => g.id === button.dataset.id); if (image) { state.currentImage = image; render(false); $('#main-scroll').scrollTop = 0; } }
    else if (action === 'copy-result') copyText(state.drafts[state.view]?.result || '');
    else if (action === 'speak-result') speakText(state.drafts[state.view]?.result || '');
    else if (action === 'share-result') shareText(state.drafts[state.view]?.result || '');
    else if (action === 'save-result') { const draft = state.drafts[state.view]; if (draft?.sessionId) { const session = sessions.find(s => s.id === draft.sessionId); if (session) { session.favorite = true; draft.saved = true; saveLocal(); persistSession(session); render(false); toast('Guardado en tu biblioteca.'); } } }
    else if (action === 'copy-message' || action === 'speak-message') { const msg = currentSession()?.messages[Number(button.dataset.index)]; if (msg) action === 'copy-message' ? copyText(msg.content) : speakText(msg.content); }
    else if (action === 'copy-code') copyText(button.closest('.code-block')?.querySelector('code')?.textContent || '');
    else if (action === 'attach') $('#file-input').click();
    else if (action === 'remove-attachment') { state.attachment = null; render(false); }
    else if (action === 'dictate') startDictation();
    else if (action === 'open-session') { closeModal(); openSession(button.dataset.id); }
    else if (action === 'favorite-session') favoriteSession(button.dataset.id);
    else if (action === 'delete-session') deleteSession(button.dataset.id);
    else if (action === 'close-modal') closeModal();
    else if (action === 'toggle-theme') { const active = document.body.classList.toggle('dark'); localStorage.setItem(THEME_KEY, active ? 'dark' : 'light'); button.classList.toggle('on', active); button.setAttribute('aria-checked', String(active)); }
    else if (action === 'confirm-clear') confirmClear();
    else if (action === 'clear-history') clearHistory();
    else if (action === 'install-pwa' && state.deferredInstall) { state.deferredInstall.prompt(); await state.deferredInstall.userChoice; state.deferredInstall = null; render(false); }
  });
  document.addEventListener('submit', event => { if (event.target.id === 'tool-form') { event.preventDefault(); submitTool(); } });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { closeModal(); closeSidebar(); }
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); showSearch(); }
    if ((event.metaKey || event.ctrlKey) && event.key === '1') { event.preventDefault(); navigate('chat'); }
    if (event.target.id === 'chat-input' && event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); sendChat(); }
  });
  document.addEventListener('input', event => {
    if (event.target.id === 'library-search') { const position = event.target.selectionStart; state.libraryQuery = event.target.value; render(false); const input = $('#library-search'); if (input) { input.focus(); input.setSelectionRange(position, position); } }
    if (event.target.id === 'global-search') { state.searchQuery = event.target.value; updateSearchResults(); }
    if (event.target.id === 'chat-input') { event.target.style.height = '35px'; event.target.style.height = `${Math.min(event.target.scrollHeight, 132)}px`; }
  });
  $('#file-input').addEventListener('change', event => handleFile(event.target.files?.[0]));
  $('#menu-toggle').addEventListener('click', () => { $('#sidebar').classList.add('open'); $('#sidebar-scrim').classList.add('open'); });
  $('#sidebar-close').addEventListener('click', closeSidebar);
  $('#sidebar-scrim').addEventListener('click', closeSidebar);
  $('#search-trigger').addEventListener('click', showSearch);
  $('#settings-button').addEventListener('click', showSettings);
  $('#top-settings').addEventListener('click', showSettings);
  $('#modal-backdrop').addEventListener('click', event => { if (event.target.id === 'modal-backdrop') closeModal(); });
  window.addEventListener('online', updateConnection); window.addEventListener('offline', updateConnection);
  window.addEventListener('popstate', () => { const view = location.hash.replace('#', ''); state.view = view in names ? view : 'home'; render(); });
  window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); state.deferredInstall = event; if (state.view === 'download') render(false); });
  window.__auriaDictation = (transcript) => {
    if (state.view !== 'chat') navigate('chat');
    const input = $('#chat-input');
    if (input) { input.value = `${input.value}${input.value ? ' ' : ''}${transcript}`; input.focus(); }
    toast('Dictado añadido a tu mensaje.');
  };
  if (localStorage.getItem(THEME_KEY) === 'dark') document.body.classList.add('dark');
  state.view = location.hash.slice(1) in names ? location.hash.slice(1) : 'home';
  updateConnection(); render(); syncSessions();
  if (!nativeApp && 'serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('./sw.js').catch(() => {});
})();
