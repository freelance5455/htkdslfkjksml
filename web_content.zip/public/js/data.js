/* Offline fallback catalogue (used only when the API is unreachable, e.g. opened as a local file). */
window.CALCORA_DATA = {
 "products": [
  {
   "id": 23,
   "name": "CALCORA SciMaster ES Plus",
   "modelNumber": "CLC-991ES+",
   "category": "Scientific Models",
   "price": 2650,
   "description": "The legendary ES Plus style scientific calculator, 2nd edition. Natural V.P.A.M. display shows fractions and roots exactly as in your textbook, with green DEL/AC keys and 417 functions.",
   "features": [
    "Natural V.P.A.M. textbook display",
    "417 functions",
    "Fractions, roots & statistics",
    "Integration & differentiation",
    "Green DEL / AC keys",
    "Solar + battery power",
    "1-year CALCORA warranty"
   ],
   "colors": [
    "Midnight Black",
    "Graphite"
   ],
   "image": "images/products/scimaster-es.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": true,
   "isNewArrival": false,
   "stock": 80,
   "createdAt": "2026-11-03T07:41:35.108683"
  },
  {
   "id": 22,
   "name": "CALCORA ClassPro CW Pink",
   "modelNumber": "CLC-991CW-PK",
   "category": "New Arrivals",
   "price": 3550,
   "description": "The same powerful ClassPro engine in a soft Blossom Pink finish with a purple SHIFT key. Natural display, spreadsheet, equation and statistics modes — style meets science.",
   "features": [
    "Blossom Pink limited colourway",
    "Natural textbook display",
    "Spreadsheet & statistics modes",
    "Equation & inequality solver",
    "Solar + battery power",
    "Protective hard case",
    "1-year CALCORA warranty"
   ],
   "colors": [
    "Blossom Pink",
    "Midnight Black"
   ],
   "image": "images/products/classpro-pink.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 35,
   "createdAt": "2026-11-03T07:41:35.108683"
  },
  {
   "id": 21,
   "name": "CALCORA ClassPro CW",
   "modelNumber": "CLC-991CW",
   "category": "Scientific Models",
   "price": 3450,
   "description": "ClassWiz-inspired flagship scientific calculator. High-resolution natural textbook LCD, spreadsheet, table, equation and complex modes, gold SHIFT functions and an intuitive D-pad with OK key. Exam-friendly and solar powered.",
   "features": [
    "High-resolution natural textbook display",
    "540+ scientific functions",
    "Spreadsheet, Table & Equation solver",
    "Complex numbers & Base-N",
    "D-pad navigation with OK key",
    "Solar + battery dual power",
    "Slide-on hard case included",
    "1-year CALCORA warranty"
   ],
   "colors": [
    "Midnight Black",
    "Blossom Pink",
    "Arctic White"
   ],
   "image": "images/products/classpro-black.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": true,
   "isNewArrival": true,
   "stock": 60,
   "createdAt": "2026-11-03T07:41:35.108683"
  },
  {
   "id": 20,
   "name": "CALCORA Nova N2",
   "modelNumber": "CN-7002",
   "category": "New Arrivals",
   "price": 6990,
   "description": "The Nova N2 takes AI calculation further with predictive formulas and cloud backup for your math history.",
   "features": [
    "Predictive Formulas",
    "Cloud Sync",
    "Biometric Lock",
    "Metal Body"
   ],
   "colors": [
    "Titanium Black",
    "Violet Mist"
   ],
   "image": "images/products/p5.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 15,
   "createdAt": "2026-11-02T07:21:59.679489"
  },
  {
   "id": 19,
   "name": "CALCORA Nova N1",
   "modelNumber": "CN-7001",
   "category": "New Arrivals",
   "price": 5990,
   "description": "The all-new Nova N1 combines AI-assisted calculation with a futuristic design. The first of its kind.",
   "features": [
    "AI Calculation Assist",
    "Voice Input",
    "Smart History Sync",
    "Animated UI"
   ],
   "colors": [
    "Nova White",
    "Electric Violet"
   ],
   "image": "images/products/p7.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 20,
   "createdAt": "2026-11-01T07:21:59.679489"
  },
  {
   "id": 18,
   "name": "CALCORA Galaxy",
   "modelNumber": "CE-6003",
   "category": "Special Edition",
   "price": 24990,
   "description": "The Galaxy special edition features a deep-space paint finish with micro-star inlays and gold-plated keys.",
   "features": [
    "Deep-Space Finish",
    "Gold-Plated Keys",
    "Micro-Star Inlays",
    "Certificate of Authenticity"
   ],
   "colors": [
    "Galaxy Purple",
    "Starlight"
   ],
   "image": "images/products/p6.jpg",
   "status": "pre_order",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 0,
   "createdAt": "2026-10-14T07:21:59.679489"
  },
  {
   "id": 17,
   "name": "CALCORA Aurora White",
   "modelNumber": "CE-6002",
   "category": "Special Edition",
   "price": 19990,
   "description": "The Aurora edition shimmers with a pearl-white finish and soft blue ambient lighting. A collector's dream.",
   "features": [
    "Pearl White Finish",
    "Ambient Aurora Light",
    "Numbered Edition",
    "Luxury Gift Box"
   ],
   "colors": [
    "Aurora White",
    "Midnight Blue"
   ],
   "image": "images/products/p7.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 8,
   "createdAt": "2026-10-24T07:21:59.679489"
  },
  {
   "id": 16,
   "name": "CALCORA Neon Carbon",
   "modelNumber": "CE-6001",
   "category": "Special Edition",
   "price": 22990,
   "description": "A special edition with carbon-fiber weave and neon-purple glow accents. Only 500 units made worldwide.",
   "features": [
    "Real Carbon Fiber",
    "Neon Glow Accents",
    "Numbered Edition",
    "Collector Case"
   ],
   "colors": [
    "Neon Carbon",
    "Magenta Glow"
   ],
   "image": "images/products/p6.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": true,
   "isNewArrival": false,
   "stock": 3,
   "createdAt": "2026-07-26T07:21:59.679489"
  },
  {
   "id": 15,
   "name": "CALCORA D6 Fold",
   "modelNumber": "CD-5003",
   "category": "Digital Models",
   "price": 5490,
   "description": "A foldable digital calculator that fits in any pocket. Opens to a full-size keypad with a premium hinge.",
   "features": [
    "Foldable Design",
    "Full-Size Keys",
    "OLED Display",
    "Magnetic Closure"
   ],
   "colors": [
    "Midnight Black",
    "Blue Steel"
   ],
   "image": "images/products/p4.jpg",
   "status": "pre_order",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 0,
   "createdAt": "2026-10-27T07:21:59.679489"
  },
  {
   "id": 14,
   "name": "CALCORA D5 LED",
   "modelNumber": "CD-5002",
   "category": "Digital Models",
   "price": 3990,
   "description": "The D5 LED edition glows with vibrant RGB key lighting and a high-contrast display for late-night work.",
   "features": [
    "RGB Backlit Keys",
    "High-Contrast Display",
    "Custom Lighting Modes",
    "Magnetic Stand"
   ],
   "colors": [
    "RGB Black",
    "Silver"
   ],
   "image": "images/products/p1.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 16,
   "createdAt": "2026-09-24T07:21:59.679489"
  },
  {
   "id": 13,
   "name": "CALCORA D5 Slim",
   "modelNumber": "CD-5001",
   "category": "Digital Models",
   "price": 3490,
   "description": "An ultra-slim digital calculator with a minimalist design and instant response keypad. Style meets substance.",
   "features": [
    "6.2mm Ultra Slim",
    "LED Backlit Keys",
    "USB-C Charging",
    "Metal Frame"
   ],
   "colors": [
    "Space Gray",
    "Arctic White"
   ],
   "image": "images/products/p5.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 22,
   "createdAt": "2026-08-30T07:21:59.679489"
  },
  {
   "id": 12,
   "name": "CALCORA Sci Mini",
   "modelNumber": "CX-4003",
   "category": "Scientific Models",
   "price": 3990,
   "description": "A compact scientific calculator with essential functions in a slim, durable body. Perfect for exams.",
   "features": [
    "250+ Functions",
    "Approved for Exams",
    "Slim Design",
    "Slide-On Case"
   ],
   "colors": [
    "White",
    "Black"
   ],
   "image": "images/products/p1.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 40,
   "createdAt": "2026-09-14T07:21:59.679489"
  },
  {
   "id": 11,
   "name": "CALCORA Sci Pro",
   "modelNumber": "CX-4002",
   "category": "Scientific Models",
   "price": 6490,
   "description": "The Sci Pro adds graphing capabilities and a high-resolution screen for visualizing complex functions.",
   "features": [
    "High-Res Graphing",
    "500+ Functions",
    "Touchscreen Input",
    "Rechargeable Battery"
   ],
   "colors": [
    "Professional Black",
    "Ice Blue"
   ],
   "image": "images/products/p4.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 14,
   "createdAt": "2026-10-19T07:21:59.679489"
  },
  {
   "id": 10,
   "name": "CALCORA Sci X",
   "modelNumber": "CX-4001",
   "category": "Scientific Models",
   "price": 4990,
   "description": "A powerful scientific calculator with 350+ functions, ideal for engineering, physics and advanced mathematics.",
   "features": [
    "350+ Functions",
    "Natural Textbook Display",
    "Equation Solver",
    "Python Support"
   ],
   "colors": [
    "Navy Blue",
    "Dark Gray"
   ],
   "image": "images/products/p4.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": true,
   "isNewArrival": false,
   "stock": 30,
   "createdAt": "2026-08-15T07:21:59.679489"
  },
  {
   "id": 9,
   "name": "CALCORA H4 Edge",
   "modelNumber": "C3-3003",
   "category": "3D Models",
   "price": 14990,
   "description": "The H4 Edge pairs an edge-to-edge glass display with real-time 3D graphing. Built for creators and innovators.",
   "features": [
    "Edge-to-Edge Glass",
    "Real-Time 3D Graphs",
    "Dual Processors",
    "Voice Control"
   ],
   "colors": [
    "Phantom Black",
    "Electric Blue"
   ],
   "image": "images/products/p3.jpg",
   "status": "pre_order",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 0,
   "createdAt": "2026-10-28T07:21:59.679489"
  },
  {
   "id": 8,
   "name": "CALCORA H3 Mini",
   "modelNumber": "C3-3002",
   "category": "3D Models",
   "price": 9990,
   "description": "The H3 Mini brings holographic display technology into a pocket-sized form. Futuristic math wherever you go.",
   "features": [
    "Compact Hologram",
    "Touch Gestures",
    "USB-C Fast Charge",
    "16GB Storage"
   ],
   "colors": [
    "Holo Blue",
    "Pearl White"
   ],
   "image": "images/products/p3.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 12,
   "createdAt": "2026-10-04T07:21:59.679489"
  },
  {
   "id": 7,
   "name": "CALCORA H3 Holographic",
   "modelNumber": "C3-3001",
   "category": "3D Models",
   "price": 18990,
   "description": "The world's first holographic calculator. It projects your calculations in 3D above the device for an immersive experience.",
   "features": [
    "Holographic Projection",
    "Gesture Control",
    "3D Augmented UI",
    "Bluetooth 5.3"
   ],
   "colors": [
    "Holo Cyan",
    "Holo Violet"
   ],
   "image": "images/products/p3.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 5,
   "createdAt": "2026-10-22T07:21:59.679489"
  },
  {
   "id": 6,
   "name": "CALCORA P3 Obsidian",
   "modelNumber": "CP-2003",
   "category": "Premium Models",
   "price": 16990,
   "description": "The Obsidian edition features a mirror-black glass front and stealth design. Luxury redefined for the digital age.",
   "features": [
    "Mirror Glass Finish",
    "AMOLED Display",
    "Haptic Feedback Keys",
    "24K Gold Trim"
   ],
   "colors": [
    "Obsidian Black",
    "Rose Gold"
   ],
   "image": "images/products/p2.jpg",
   "status": "pre_order",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 0,
   "createdAt": "2026-10-26T07:21:59.679489"
  },
  {
   "id": 5,
   "name": "CALCORA P2 Titanium",
   "modelNumber": "CP-2002",
   "category": "Premium Models",
   "price": 15490,
   "description": "Machined from aerospace-grade titanium, the P2 delivers premium weight, feel and durability. A true engineering marvel.",
   "features": [
    "Titanium Unibody",
    "Ultra-Bright OLED",
    "Wireless Charging",
    "5 Year Warranty"
   ],
   "colors": [
    "Titanium Gray",
    "Space Black"
   ],
   "image": "images/products/p6.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 7,
   "createdAt": "2026-08-25T07:21:59.679489"
  },
  {
   "id": 4,
   "name": "CALCORA P1 Gold",
   "modelNumber": "CP-2001",
   "category": "Premium Models",
   "price": 12990,
   "description": "A luxury calculator wrapped in a champagne-gold metallic shell with a backlit keypad. The statement piece for executives.",
   "features": [
    "Gold Metallic Finish",
    "Backlit Keypad",
    "Sapphire Glass Screen",
    "Leather Pouch Included"
   ],
   "colors": [
    "Champagne Gold",
    "Obsidian Black"
   ],
   "image": "images/products/p2.jpg",
   "status": "available",
   "isFeatured": true,
   "isBestSeller": true,
   "isNewArrival": false,
   "stock": 10,
   "createdAt": "2026-08-05T07:21:59.679489"
  },
  {
   "id": 3,
   "name": "CALCORA S3",
   "modelNumber": "CS-1003",
   "category": "Standard Models",
   "price": 3490,
   "description": "A premium standard calculator with a brushed metal finish and soft-touch buttons. Perfect for the modern desk.",
   "features": [
    "Brushed Metal Body",
    "16-Digit Display",
    "Extra-Large Buttons",
    "3 Year Battery Life"
   ],
   "colors": [
    "Silver",
    "White"
   ],
   "image": "images/products/p7.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": true,
   "stock": 18,
   "createdAt": "2026-10-29T07:21:59.679489"
  },
  {
   "id": 2,
   "name": "CALCORA S2",
   "modelNumber": "CS-1002",
   "category": "Standard Models",
   "price": 2990,
   "description": "The S2 adds a faster processor and a larger display for smooth everyday math. Sleek, lightweight and built to last.",
   "features": [
    "14-Digit Display",
    "Dual Power",
    "Memory Functions",
    "Anti-Slip Base"
   ],
   "colors": [
    "Graphite",
    "Steel Blue"
   ],
   "image": "images/products/p5.jpg",
   "status": "pre_order",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 0,
   "createdAt": "2026-09-19T07:21:59.679489"
  },
  {
   "id": 1,
   "name": "CALCORA S1",
   "modelNumber": "CS-1001",
   "category": "Standard Models",
   "price": 2490,
   "description": "A reliable everyday calculator with a precision keypad and crystal-clear display. Built for students and professionals who need fast, accurate calculations.",
   "features": [
    "12-Digit LCD Display",
    "Dual Power (Solar + Battery)",
    "Precision Rubber Keys",
    "Auto Power Off"
   ],
   "colors": [
    "Midnight Black",
    "Silver"
   ],
   "image": "images/products/p1.jpg",
   "status": "available",
   "isFeatured": false,
   "isBestSeller": false,
   "isNewArrival": false,
   "stock": 25,
   "createdAt": "2026-09-04T07:21:59.679489"
  }
 ]
};
