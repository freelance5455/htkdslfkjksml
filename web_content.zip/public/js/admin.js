/* CALCORA 3D — admin dashboard (vanilla JavaScript). Talks to the secure server API. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bdt(n) { return "৳" + Number(n || 0).toLocaleString("en-IN"); }
  function fmtDate(d) { try { return new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } }
  function toast(msg, err) {
    var t = document.createElement("div");
    t.className = "toast" + (err ? " err" : "");
    t.textContent = msg;
    $("#toasts").appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }
  function api(path, method, body) {
    return fetch(path, {
      method: method || "GET", credentials: "same-origin", cache: "no-store",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (r.status === 401 && path !== "/api/admin") { showLogin(); throw new Error("Session expired — please sign in again"); }
        if (!r.ok) throw new Error(d.error || "Request failed");
        return d;
      });
    });
  }

  if (!/^https?:$/.test(location.protocol)) {
    document.querySelector("main").innerHTML = '<div class="login-box glass-strong"><h2>Admin needs the server</h2><p class="muted">The admin dashboard manages the real database, so it only works when the site is served by the CALCORA server (not opened as a local file).</p><a class="btn btn-primary" href="index.html">Back to store</a></div>';
    return;
  }

  var STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"];
  var data = { products: [], orders: [], categories: [] };
  var orderFilter = "all";
  var editing = null;

  /* ---------- auth ---------- */
  function showLogin() { $("#loginView").classList.remove("hidden"); $("#dashView").classList.add("hidden"); }
  function showDash(user) { $("#loginView").classList.add("hidden"); $("#dashView").classList.remove("hidden"); $("#whoami").textContent = "👤 " + user; loadAll(); }

  fetch("/api/admin", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
    if (d.authenticated) showDash(d.username); else showLogin();
  }).catch(showLogin);

  $("#loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var f = e.target;
    $("#loginError").innerHTML = "";
    api("/api/admin", "POST", { username: f.username.value.trim(), password: f.password.value })
      .then(function (d) { f.reset(); showDash(d.username); })
      .catch(function (ex) { $("#loginError").innerHTML = '<p class="form-error">' + esc(ex.message) + "</p>"; });
  });
  $("#logoutBtn").addEventListener("click", function () { api("/api/admin", "DELETE").then(showLogin); });
  $("#refreshBtn").addEventListener("click", function () { loadAll(); toast("Refreshed"); });

  /* ---------- data ---------- */
  function loadAll() {
    return Promise.all([api("/api/products"), api("/api/orders"), api("/api/categories")]).then(function (r) {
      data.products = r[0].products || [];
      data.orders = r[1].orders || [];
      data.categories = (r[2].categories || []).slice().sort(function (a, b) { return a.id - b.id; });
      renderStats(); renderProducts(); renderOrders(); renderCategories();
    }).catch(function (ex) { toast(ex.message, true); });
  }

  function renderStats() {
    var active = data.orders.filter(function (o) { return o.status !== "cancelled"; });
    var cards = [
      ["💎", data.products.length, "Products"],
      ["📦", data.orders.length, "Total Orders"],
      ["⏳", data.orders.filter(function (o) { return o.status === "pending"; }).length, "Pending"],
      ["💰", bdt(active.reduce(function (s, o) { return s + o.totalPrice; }, 0)), "Revenue (BDT)"],
      ["⚠️", data.products.filter(function (p) { return p.stock <= 5; }).length, "Low Stock"]
    ];
    $("#stats").innerHTML = cards.map(function (c) { return '<div class="stat-card glass-strong"><div class="emoji">' + c[0] + "</div><b>" + c[1] + "</b><span>" + c[2] + "</span></div>"; }).join("");
  }

  /* ---------- tabs ---------- */
  $("#tabs").addEventListener("click", function (e) {
    var b = e.target.closest("[data-tab]");
    if (!b) return;
    $$("#tabs .chip").forEach(function (c) { c.classList.toggle("active", c === b); });
    $$("[data-panel]").forEach(function (p) { p.classList.toggle("hidden", p.dataset.panel !== b.dataset.tab); });
  });

  /* ---------- products ---------- */
  function renderProducts() {
    var q = $("#prodSearch").value.trim().toLowerCase();
    var list = data.products.filter(function (p) { return !q || (p.name + " " + p.modelNumber + " " + p.category).toLowerCase().indexOf(q) >= 0; });
    $("#prodRows").innerHTML = list.map(function (p) {
      var flags = (p.isFeatured ? '<span class="tag tag-feat">Feat</span>' : "") + (p.isBestSeller ? '<span class="tag tag-best">Best</span>' : "") + (p.isNewArrival ? '<span class="tag tag-new">New</span>' : "");
      return '<tr data-pid="' + p.id + '"><td><div class="t-prod"><img src="' + esc(p.image) + '" alt="" /><b>' + esc(p.name) + "</b></div></td>" +
        '<td style="font-family:Courier New,monospace;color:#38bdf8;font-weight:700">' + esc(p.modelNumber) + "</td><td>" + esc(p.category) + "</td>" +
        '<td><div style="display:flex;gap:.35rem"><input class="input price-input" type="number" min="1" value="' + p.price + '" data-price /><button class="btn btn-ghost mini" data-save-price>Save</button></div></td>' +
        '<td><input class="input price-input" style="width:76px" type="number" min="0" value="' + p.stock + '" data-stock /></td>' +
        '<td><span class="status status-' + esc(p.status) + '" style="position:static">' + esc(p.status.replace(/_/g, " ")) + "</span></td>" +
        '<td><div class="flags">' + (flags || '<span class="muted">—</span>') + "</div></td>" +
        '<td><div class="row-actions"><a class="btn btn-ghost mini" href="index.html#/product/' + p.id + '" target="_blank">View</a><button class="btn btn-ghost mini" data-edit>✏️ Edit</button><button class="btn btn-danger mini" data-del>🗑</button></div></td></tr>';
    }).join("") || '<tr><td colspan="8" class="muted" style="text-align:center;padding:2rem">No products found.</td></tr>';
  }
  $("#prodSearch").addEventListener("input", renderProducts);

  $("#prodRows").addEventListener("click", function (e) {
    var row = e.target.closest("[data-pid]");
    if (!row) return;
    var id = Number(row.dataset.pid);
    var p = data.products.filter(function (x) { return x.id === id; })[0];
    if (e.target.closest("[data-save-price]")) {
      var price = Number($("[data-price]", row).value), stock = Number($("[data-stock]", row).value);
      if (!(price > 0)) { toast("Enter a valid price", true); return; }
      api("/api/products/" + id, "PUT", { price: Math.round(price), stock: Math.max(0, Math.round(stock)) })
        .then(function () { toast("✓ " + p.name + " → " + bdt(price)); loadAll(); })
        .catch(function (ex) { toast(ex.message, true); });
    } else if (e.target.closest("[data-edit]")) {
      openProductModal(p);
    } else if (e.target.closest("[data-del]")) {
      if (!confirm('Delete "' + p.name + '"? This cannot be undone.')) return;
      api("/api/products/" + id, "DELETE").then(function () { toast("Deleted " + p.name); loadAll(); }).catch(function (ex) { toast(ex.message, true); });
    }
  });

  function openProductModal(p) {
    editing = p || null;
    var f = $("#productForm");
    f.reset();
    $("#pmError").innerHTML = "";
    $("#pmTitle").textContent = p ? "Edit " + p.name : "Add New Model";
    $("#pmCategory").innerHTML = data.categories.map(function (c) { return '<option value="' + esc(c.name) + '" data-cid="' + c.id + '">' + esc(c.name) + "</option>"; }).join("");
    if (p) {
      f.name.value = p.name; f.modelNumber.value = p.modelNumber; f.category.value = p.category; f.price.value = p.price;
      f.stock.value = p.stock; f.status.value = p.status; f.description.value = p.description;
      f.features.value = (p.features || []).join("\n"); f.colors.value = (p.colors || []).join(", "); f.image.value = p.image;
      f.isFeatured.checked = !!p.isFeatured; f.isBestSeller.checked = !!p.isBestSeller; f.isNewArrival.checked = !!p.isNewArrival;
    } else {
      f.image.value = "/images/products/classpro-black.jpg"; f.stock.value = 10;
    }
    $("#pmPreview").src = f.image.value;
    $("#productModal").classList.add("open"); $("#overlay").classList.add("open");
  }
  function closeModal() { $("#productModal").classList.remove("open"); $("#overlay").classList.remove("open"); }
  $("#addProduct").addEventListener("click", function () { openProductModal(null); });
  $("#overlay").addEventListener("click", closeModal);
  document.addEventListener("click", function (e) { if (e.target.closest("[data-close]")) closeModal(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });
  $("#pmImage").addEventListener("input", function (e) { $("#pmPreview").src = e.target.value; });

  // image upload → resized JPEG data URL stored with the product
  $("#pmFile").addEventListener("change", function (e) {
    var file = e.target.files[0];
    if (!file) return;
    if (!/^image\//.test(file.type)) { toast("Please choose an image file", true); return; }
    if (file.size > 1.5 * 1024 * 1024) { toast("Image too large (max 1.5 MB)", true); return; }
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () {
        var max = 900, scale = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement("canvas");
        c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        var url = c.toDataURL("image/jpeg", 0.85);
        $("#pmImage").value = url; $("#pmPreview").src = url;
        toast("Image ready ✓");
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });

  $("#productForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var f = e.target;
    var opt = f.category.selectedOptions[0];
    var body = {
      name: f.name.value.trim(), modelNumber: f.modelNumber.value.trim(), category: f.category.value,
      categoryId: opt ? Number(opt.dataset.cid) : undefined, price: Math.round(Number(f.price.value)),
      stock: Math.max(0, Math.round(Number(f.stock.value) || 0)), status: f.status.value, description: f.description.value.trim(),
      features: f.features.value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean),
      colors: f.colors.value.split(",").map(function (s) { return s.trim(); }).filter(Boolean),
      image: f.image.value.trim(), isFeatured: f.isFeatured.checked, isBestSeller: f.isBestSeller.checked, isNewArrival: f.isNewArrival.checked
    };
    if (!body.name || !body.modelNumber || !body.description || !body.image || !(body.price > 0)) {
      $("#pmError").innerHTML = '<p class="form-error">Please fill all required fields with a valid price.</p>'; return;
    }
    $("#pmSave").disabled = true;
    api(editing ? "/api/products/" + editing.id : "/api/products", editing ? "PUT" : "POST", body)
      .then(function () { toast(editing ? "✓ Model updated" : "✓ Model created"); closeModal(); loadAll(); })
      .catch(function (ex) { $("#pmError").innerHTML = '<p class="form-error">' + esc(ex.message) + "</p>"; })
      .then(function () { $("#pmSave").disabled = false; });
  });

  /* ---------- orders ---------- */
  function renderOrders() {
    $("#orderFilters").innerHTML = ["all"].concat(STATUSES).map(function (s) {
      var n = s === "all" ? data.orders.length : data.orders.filter(function (o) { return o.status === s; }).length;
      return '<button class="chip' + (orderFilter === s ? " active" : "") + '" data-of="' + s + '">' + s.charAt(0).toUpperCase() + s.slice(1) + " (" + n + ")</button>";
    }).join("");
    var list = orderFilter === "all" ? data.orders : data.orders.filter(function (o) { return o.status === orderFilter; });
    $("#orderRows").innerHTML = list.map(function (o) {
      return '<tr data-oid="' + o.id + '"><td style="font-family:Courier New,monospace;font-weight:800;color:#c4b5fd">' + esc(o.trackingNumber) + "</td>" +
        "<td><b>" + esc(o.customerName) + '</b><br/><small class="muted">' + esc(o.phone) + '</small><br/><small class="muted">' + esc(o.address) + "</small>" + (o.message ? '<br/><em class="muted" style="font-size:.8rem">“' + esc(o.message) + "”</em>" : "") + "</td>" +
        "<td>" + (o.items || []).map(function (i) { return esc(i.productName) + " × " + i.quantity; }).join("<br/>") + "</td>" +
        '<td style="font-weight:800">' + bdt(o.totalPrice) + '</td><td class="muted">' + fmtDate(o.createdAt) + "</td>" +
        '<td><select class="input mini" style="width:auto" data-status>' + STATUSES.map(function (s) { return '<option value="' + s + '"' + (s === o.status ? " selected" : "") + ">" + s.charAt(0).toUpperCase() + s.slice(1) + "</option>"; }).join("") + "</select></td></tr>";
    }).join("") || '<tr><td colspan="6" class="muted" style="text-align:center;padding:2rem">No orders here yet.</td></tr>';
  }
  $("#orderFilters").addEventListener("click", function (e) { var b = e.target.closest("[data-of]"); if (b) { orderFilter = b.dataset.of; renderOrders(); } });
  $("#orderRows").addEventListener("change", function (e) {
    var sel = e.target.closest("[data-status]");
    if (!sel) return;
    var id = Number(sel.closest("[data-oid]").dataset.oid);
    api("/api/orders/" + id, "PUT", { status: sel.value }).then(function () { toast("✓ Order status → " + sel.value); loadAll(); }).catch(function (ex) { toast(ex.message, true); });
  });

  /* ---------- categories ---------- */
  function renderCategories() {
    $("#catRows").innerHTML = data.categories.map(function (c) {
      var n = data.products.filter(function (p) { return p.category === c.name; }).length;
      return '<div class="line" style="align-items:center;padding:.7rem .9rem;border-radius:12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06)"><span><b>' + esc(c.name) + '</b><br/><small class="muted">' + n + " products · /" + esc(c.slug) + '</small></span><button class="btn btn-danger mini" data-cdel="' + c.id + '">🗑</button></div>';
    }).join("");
  }
  $("#catRows").addEventListener("click", function (e) {
    var b = e.target.closest("[data-cdel]");
    if (!b || !confirm("Delete this category?")) return;
    api("/api/categories", "DELETE", { id: Number(b.dataset.cdel) }).then(function () { toast("Category deleted"); loadAll(); }).catch(function (ex) { toast(ex.message, true); });
  });
  $("#catForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var name = e.target.name.value.trim();
    if (!name) return;
    api("/api/categories", "POST", { name: name }).then(function () { e.target.reset(); toast("✓ Category added"); loadAll(); }).catch(function (ex) { toast(ex.message, true); });
  });
})();
