import {firebaseConfig,APPCHECK_SITE_KEY} from './firebase-config.js';
const th=localStorage.theme||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');document.documentElement.dataset.theme=th;
const G='https://www.gstatic.com/firebasejs/10.12.2/firebase-';
const [{initializeApp},AC,A,F,FN,S,R]=await Promise.all(['app','app-check','auth','firestore','functions','storage','database'].map(m=>import(G+m+'.js')));
const app=initializeApp(firebaseConfig);
if(APPCHECK_SITE_KEY){if(location.hostname==='localhost')self.FIREBASE_APPCHECK_DEBUG_TOKEN=true;AC.initializeAppCheck(app,{provider:new AC.ReCaptchaV3Provider(APPCHECK_SITE_KEY),isTokenAutoRefreshEnabled:true});}
const auth=A.getAuth(app),db=F.getFirestore(app),fx=FN.getFunctions(app),st=S.getStorage(app),rt=R.getDatabase(app);
const call=(n,d)=>FN.httpsCallable(fx,n)(d||{}).then(r=>r.data);
const $=i=>document.getElementById(i),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const err=e=>alert(String(e.message||e).replace(/^Firebase: /,'')),safeUrl=u=>/^https:\/\//.test(u||'')?esc(u):'';
const nm=u=>u?.displayName||'User',isMod=()=>['admin','superadmin'].includes(role),okImg=(f,mb)=>/^image\/(jpeg|png|webp|gif)$/.test(f.type)&&f.size<=mb*1048576;
const fmt=t=>new Date(t).toLocaleString([],{dateStyle:'short',timeStyle:'short'});
let uid,role='user',cur=null,chats=[],msgs=[],U={},subs=[],msgSub,typSub,pres={},watched=new Set(),stopPres,pending=null,typT,typing=false,synced=false,typChat,marked='',mode='login';
const show=id=>{['auth','verify','app'].forEach(x=>$(x).hidden=x!==id);$('splash').hidden=true;};
const av=(u,id)=>`<span class="av">${u?.photoURL?`<img src="${safeUrl(u.photoURL)}" alt="">`:esc((nm(u)[0]||'?').toUpperCase())}${id?`<i class="dot" data-p="${id}"></i>`:''}</span>`;
const gav=c=>`<span class="av">${c.photoURL?`<img src="${safeUrl(c.photoURL)}" alt="">`:'👥'}</span>`;
async function user(id){if(!U[id]){const s=await F.getDoc(F.doc(db,'users',id));U[id]=s.exists()?{id,...s.data()}:{id,displayName:'Deleted user'};}return U[id];}
const other=c=>c.members.find(x=>x!==uid),chatName=c=>c.type==='group'?c.name:nm(U[other(c)]);
const isUnread=c=>c.lastFrom&&c.lastFrom!==uid&&c.lastAt&&(!c.reads?.[uid]||c.lastAt.toMillis()>c.reads[uid].toMillis());
// theme
$('theme').onclick=()=>{const n=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=n;localStorage.theme=n;};
// auth UI
$('toggle').onclick=()=>{mode=mode==='login'?'reg':'login';$('dn').hidden=mode==='login';$('go').textContent=mode==='login'?'Log in':'Create account';$('toggle').textContent=mode==='login'?'Create an account':'I have an account';};
$('authForm').onsubmit=async e=>{e.preventDefault();const em=$('email').value.trim(),pw=$('pw').value;try{
 if(mode==='reg'){const c=await A.createUserWithEmailAndPassword(auth,em,pw);await A.updateProfile(c.user,{displayName:$('dn').value.trim().slice(0,40)||em.split('@')[0]});await A.sendEmailVerification(c.user);}
 else await A.signInWithEmailAndPassword(auth,em,pw);}catch(x){err(x.code==='auth/user-disabled'?'Your account has been suspended.':x);}};
$('reset').onclick=async()=>{const em=$('email').value.trim();if(!em)return err('Enter your email first');try{await A.sendPasswordResetEmail(auth,em);alert('Password reset email sent');}catch(x){err(x);}};
$('resend').onclick=()=>A.sendEmailVerification(auth.currentUser).then(()=>alert('Sent')).catch(err);
$('recheck').onclick=()=>location.reload();$('out1').onclick=()=>A.signOut(auth);
$('logout').onclick=()=>{stopPres?.();A.signOut(auth);};
A.onAuthStateChanged(auth,async u=>{subs.forEach(f=>f());subs=[];stopPres?.();stopPres=null;msgSub?.();typSub?.();cur=null;chats=[];uid=null;
 if(!u)return show('auth');
 await u.reload();if(!u.emailVerified)return show('verify');
 let t=await u.getIdTokenResult(true);
 if(!t.claims.role&&!sessionStorage.bs){sessionStorage.bs=1;try{await call('bootstrapSuperAdmin');t=await u.getIdTokenResult(true);}catch{}}
 if(t.claims.suspended){await A.signOut(auth);return err('Your account has been suspended.');}
 uid=u.uid;role=t.claims.role||'user';boot();});
// presence (multi-device: one node per connection)
function presence(){const base='status/'+uid,conn=R.push(R.ref(rt,base+'/conns')),set=()=>R.set(conn,{state:document.hidden?'away':'online'});
 const off=R.onValue(R.ref(rt,'.info/connected'),s=>{if(!s.val())return;R.onDisconnect(conn).remove();R.onDisconnect(R.ref(rt,base+'/lastSeen')).set(R.serverTimestamp());set();});
 document.onvisibilitychange=()=>{set();if(!document.hidden)markRead();};
 return()=>{off();R.remove(conn);R.set(R.ref(rt,base+'/lastSeen'),R.serverTimestamp());};}
function watchP(id){if(watched.has(id))return;watched.add(id);R.onValue(R.ref(rt,'status/'+id),s=>{const v=s.val()||{},cs=Object.values(v.conns||{});pres[id]={state:cs.some(x=>x.state==='online')?'online':cs.length?'away':'offline',last:v.lastSeen};paint();});}
function paint(){document.querySelectorAll('[data-p]').forEach(e=>e.className='dot '+(pres[e.dataset.p]?.state||'offline'));statusText();}
function statusText(){if(!cur)return;let s;if(typing)s='typing…';else if(cur.type==='group')s=cur.members.length+' members';else{const p=pres[other(cur)]||{};s=p.state==='online'?'Online':p.state==='away'?'Away':p.last?'Last seen '+fmt(p.last):'Offline';}$('cSub').textContent=s;}
function boot(){show('app');synced=false;$('admBtn').hidden=!isMod();stopPres=presence();
 subs.push(F.onSnapshot(F.doc(db,'users',uid),s=>{if(!s.exists())return;const d=s.data();U[uid]={id:uid,...d};if(d.suspended){A.signOut(auth);return;}
  const dn=auth.currentUser.displayName;if(dn&&d.displayName!==dn&&!synced){synced=true;F.updateDoc(s.ref,{displayName:dn,searchName:dn.toLowerCase()}).catch(()=>{});}
  $('meAv').innerHTML=av(U[uid]);$('meName').textContent=nm(U[uid]);}));
 subs.push(F.onSnapshot(F.query(F.collection(db,'chats'),F.where('members','array-contains',uid),F.orderBy('lastAt','desc')),s=>{
  chats=s.docs.map(d=>({id:d.id,...d.data()}));renderList();
  Promise.all(chats.flatMap(c=>c.members).map(user)).then(()=>{renderList();hdr();if(cur)drawMsgs();});
  if(cur){cur=chats.find(c=>c.id===cur.id)||null;if(!cur)closeChat();else{hdr();drawMsgs();markRead();}}}));}
function renderList(){$('list').innerHTML=chats.map(c=>{const o=c.type==='dm'?other(c):null;if(o)watchP(o);
 return `<div class="row ${cur?.id===c.id?'sel':''}" data-id="${c.id}">${o?av(U[o],o):gav(c)}<div class="rt"><b>${esc(chatName(c))}</b><small>${esc(c.lastMessage||'No messages yet')}</small></div>${isUnread(c)?'<span class="badge"></span>':''}</div>`;}).join('')||'<p class="empty">No conversations yet. Search for a person above.</p>';paint();}
$('list').onclick=e=>{const r=e.target.closest('[data-id]');r&&open(r.dataset.id);};
function hdr(){if(!cur)return;const o=cur.type==='dm'?other(cur):null;$('cTitle').textContent=chatName(cur);$('cAv').innerHTML=o?av(U[o],o):gav(cur);paint();}
function open(id){cur=chats.find(c=>c.id===id);if(!cur)return;msgSub?.();typSub?.();typing=false;pending=null;$('prev').innerHTML='';$('msgs').innerHTML='';msgs=[];
 $('noChat').hidden=true;$('chatIn').hidden=false;$('app').classList.add('open');hdr();renderList();
 msgSub=F.onSnapshot(F.query(F.collection(db,'chats',id,'messages'),F.orderBy('at','asc'),F.limitToLast(200)),s=>{msgs=s.docs.map(d=>({id:d.id,...d.data()}));drawMsgs();markRead();});
 typSub=R.onValue(R.ref(rt,'typing/'+id),s=>{const v=s.val()||{};typing=Object.keys(v).some(k=>k!==uid&&v[k]);statusText();});}
function closeChat(){stopTyping();msgSub?.();typSub?.();cur=null;$('chatIn').hidden=true;$('noChat').hidden=false;$('app').classList.remove('open');renderList();}
$('back').onclick=closeChat;$('cHead').onclick=()=>cur?.type==='group'&&groupInfo();
function markRead(){if(!cur||document.hidden||!isUnread(cur))return;const k=cur.id+cur.lastAt.toMillis();if(k===marked)return;marked=k;call('markRead',{chatId:cur.id}).catch(()=>{marked='';});}
function drawMsgs(){if(!cur)return;const box=$('msgs'),end=!box.children.length||box.scrollHeight-box.scrollTop-box.clientHeight<140,o=cur.type==='dm'?other(cur):null,rd=o&&cur.reads?.[o]?.toMillis?.()||0;
 box.innerHTML=msgs.map(m=>{const mine=m.from===uid,t=m.at?.toDate?.();
  const body=m.deleted?'<i>Message removed</i>':`${m.imageUrl?`<img class="pic" src="${safeUrl(m.imageUrl)}" data-z="1" alt="">`:''}${m.text?`<p>${esc(m.text)}</p>`:''}`;
  return `<div class="m ${mine?'me':''}">${!mine&&cur.type==='group'?`<small>${esc(nm(U[m.from]))}</small>`:''}${body}<time>${t?t.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):''}${mine&&o&&t?(rd>=t.getTime()?' ✓✓ Seen':' ✓'):''}${!m.deleted?`${!mine?`<a data-r="${m.id}">Report</a>`:''}${mine||isMod()?`<a data-d="${m.id}">Delete</a>`:''}`:''}</time></div>`;}).join('');
 if(end)box.scrollTop=box.scrollHeight;}
$('msgs').onclick=async e=>{const t=e.target;try{
 if(t.dataset.z)modal(`<img src="${t.src}" style="max-width:100%;border-radius:12px">`);
 else if(t.dataset.r){const reason=prompt('Why are you reporting this message?');if(reason!==null){await call('reportMessage',{chatId:cur.id,mid:t.dataset.r,reason});alert('Reported. Thank you.');}}
 else if(t.dataset.d&&confirm('Delete this message?'))await call('deleteMessage',{chatId:cur.id,mid:t.dataset.d});}catch(x){err(x);}};
// composer
$('form').onsubmit=async e=>{e.preventDefault();if(!cur)return;const text=$('txt').value.trim();if(!text&&!pending)return;$('send').disabled=true;
 try{let imageUrl;if(pending){const r=S.ref(st,`chat/${cur.id}/${uid}/${Date.now()}_${pending.name.replace(/[^\w.-]/g,'_')}`);await S.uploadBytes(r,pending,{contentType:pending.type});imageUrl=await S.getDownloadURL(r);}
  await call('sendMessage',{chatId:cur.id,text,imageUrl});$('txt').value='';pending=null;$('prev').innerHTML='';stopTyping();}catch(x){err(x);}$('send').disabled=false;};
$('file').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(!okImg(f,5))return err('Choose a JPG, PNG, WebP or GIF under 5 MB');pending=f;$('prev').innerHTML=`<img src="${URL.createObjectURL(f)}" alt=""><button type="button" id="rmP">✕</button>`;$('rmP').onclick=()=>{pending=null;$('prev').innerHTML='';};};
$('txt').oninput=()=>{if(!cur)return;typChat=cur.id;const r=R.ref(rt,`typing/${typChat}/${uid}`);R.set(r,true);R.onDisconnect(r).remove();clearTimeout(typT);typT=setTimeout(stopTyping,2500);};
function stopTyping(){clearTimeout(typT);if(typChat&&uid)R.remove(R.ref(rt,`typing/${typChat}/${uid}`));typChat=null;}
// people picker / search
function bindPicker(inp,box,pick,skip=()=>[]){let t;inp.oninput=()=>{clearTimeout(t);t=setTimeout(async()=>{const q=inp.value.trim().toLowerCase().slice(0,40);if(!q){box.innerHTML='';return;}
 const s=await F.getDocs(F.query(F.collection(db,'users'),F.where('searchName','>=',q),F.where('searchName','<=',q+'\uf8ff'),F.limit(8)));
 const ds=s.docs.filter(d=>d.id!==uid&&!d.data().suspended&&!skip().includes(d.id));
 box.innerHTML=ds.map(d=>`<div class="row" data-u="${d.id}">${av({id:d.id,...d.data()})}<div class="rt"><b>${esc(d.data().displayName)}</b></div></div>`).join('')||'<p class="empty">No users found</p>';
 box.onclick=e=>{const r=e.target.closest('[data-u]');if(!r)return;const d=ds.find(x=>x.id===r.dataset.u);U[d.id]={id:d.id,...d.data()};inp.value='';box.innerHTML='';pick(U[d.id]);};},300);};}
const waitChat=async id=>{for(let i=0;i<40&&!chats.find(c=>c.id===id);i++)await new Promise(r=>setTimeout(r,100));};
bindPicker($('q'),$('res'),async u=>{try{const {id}=await call('openDm',{uid:u.id});await waitChat(id);open(id);}catch(x){err(x);}});
// modals
function modal(h){$('mbody').innerHTML=h;$('modal').hidden=false;}const closeModal=()=>$('modal').hidden=true;
$('modal').onclick=e=>{if(e.target.id==='modal')closeModal();};
$('grpBtn').onclick=()=>{const sel={};modal(`<h3>New group</h3><input id="gn" placeholder="Group name" maxlength="40"><div id="chips" class="chips"></div><input id="gs" placeholder="Add members…"><div id="gr"></div><button id="gc" class="pri">Create group</button>`);
 const chips=()=>$('chips').innerHTML=Object.values(sel).map(u=>`<span class="chip" data-x="${u.id}">${esc(nm(u))} ✕</span>`).join('');
 bindPicker($('gs'),$('gr'),u=>{sel[u.id]=u;chips();},()=>Object.keys(sel));$('chips').onclick=e=>{const x=e.target.dataset.x;if(x){delete sel[x];chips();}};
 $('gc').onclick=async()=>{try{const {id}=await call('createGroup',{name:$('gn').value,members:Object.keys(sel)});closeModal();await waitChat(id);open(id);}catch(x){err(x);}};};
async function groupInfo(){const c=cur;await Promise.all(c.members.map(user));const adm=c.admins.includes(uid)||isMod();
 modal(`<h3>${esc(c.name)}</h3><p class="muted">${c.members.length} members</p>${adm?`<input id="gname" value="${esc(c.name)}" maxlength="40"><button id="gsave">Rename</button> <label class="btn">Change avatar<input id="gav" type="file" accept="image/*" hidden></label><input id="ga" placeholder="Add member…"><div id="gar"></div>`:''}
 ${c.members.map(m=>`<div class="row">${av(U[m])}<div class="rt"><b>${esc(nm(U[m]))}</b><small>${c.admins.includes(m)?'Admin':'Member'}</small></div>${adm&&m!==uid?`<a data-t="${m}">${c.admins.includes(m)?'Demote':'Make admin'}</a>${c.admins.includes(m)?'':` <a data-k="${m}">Remove</a>`}`:''}</div>`).join('')}<button id="gl" class="danger">Leave group</button>`);
 const act=async d=>{try{await call('updateGroup',{chatId:c.id,...d});closeModal();}catch(x){err(x);}};
 if(adm){$('gsave').onclick=()=>act({name:$('gname').value});bindPicker($('ga'),$('gar'),u=>act({add:[u.id]}),()=>c.members);
  $('gav').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(!okImg(f,2))return err('Image must be under 2 MB');try{const r=S.ref(st,'groupavatars/'+c.id);await S.uploadBytes(r,f,{contentType:f.type});await act({photoURL:await S.getDownloadURL(r)});}catch(x){err(x);}};}
 $('mbody').onclick=e=>{const t=e.target.dataset;if(t.k)act({remove:[t.k]});if(t.t)act({makeAdmin:{uid:t.t,admin:!c.admins.includes(t.t)}});};
 $('gl').onclick=async()=>{if(!confirm('Leave this group?'))return;try{await call('leaveGroup',{chatId:c.id});closeModal();closeChat();}catch(x){err(x);}};}
$('profBtn').onclick=()=>{const u=U[uid];modal(`<h3>Profile</h3><div class="center">${av(u)}</div><div class="center"><label class="btn">Change photo<input id="pf" type="file" accept="image/*" hidden></label></div><input id="pn" value="${esc(nm(u))}" maxlength="40"><button id="ps" class="pri">Save</button><p class="muted">${esc(u.email)} · ${esc(role)}</p>`);
 $('pf').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(!okImg(f,2))return err('Image must be JPG/PNG/WebP/GIF under 2 MB');try{const r=S.ref(st,'avatars/'+uid);await S.uploadBytes(r,f,{contentType:f.type});const url=await S.getDownloadURL(r);await F.updateDoc(F.doc(db,'users',uid),{photoURL:url});await A.updateProfile(auth.currentUser,{photoURL:url});closeModal();}catch(x){err(x);}};
 $('ps').onclick=async()=>{const n=$('pn').value.trim().slice(0,40);if(!n)return;try{await F.updateDoc(F.doc(db,'users',uid),{displayName:n,searchName:n.toLowerCase()});await A.updateProfile(auth.currentUser,{displayName:n});closeModal();}catch(x){err(x);}};};
// admin dashboard
$('admBtn').onclick=()=>admin('stats');
async function admin(tab){const tabs=['stats','users','groups','reports',role==='superadmin'&&'logs'].filter(Boolean);
 modal(`<div class="tabs">${tabs.map(t=>`<a data-tab="${t}" class="${t===tab?'on':''}">${t}</a>`).join('')}</div><div id="ab">Loading…</div>`);
 $('mbody').onclick=async e=>{const d=e.target.dataset;try{if(d.tab)return admin(d.tab);
  if(d.s){await call('setSuspended',{uid:d.s,suspended:d.v==='1'});return admin('users');}
  if(d.ro){await call('setRole',{uid:d.ro,role:d.v});return admin('users');}
  if(d.dg&&confirm('Delete this group and all its messages?')){await call('deleteGroup',{chatId:d.dg});return admin('groups');}
  if(d.rd){await call('deleteMessage',{chatId:d.c,mid:d.m,reportId:d.rd});return admin('reports');}
  if(d.rk){await call('deleteMessage',{chatId:d.c,mid:d.m,reportId:d.rk,keep:true});return admin('reports');}}catch(x){err(x);}};
 const ab=$('ab'),ts=x=>x?.toDate?fmt(x.toDate()):'';
 try{if(tab==='stats'){const s=await call('stats'),r=await F.getDocs(F.query(F.collection(db,'users'),F.orderBy('createdAt','desc'),F.limit(5)));
   ab.innerHTML=`<div class="stats">${[['Users',s.users],['Online',s.online],['Offline',s.offline],['Conversations',s.chats],['Groups',s.groups],['Suspended',s.suspended]].map(([k,v])=>`<div><b>${v}</b>${k}</div>`).join('')}</div><h4 style="margin:12px 0 4px">Recent registrations</h4>${r.docs.map(d=>`<p>${esc(d.data().displayName)} <span class="muted">${esc(d.data().email)} · ${ts(d.data().createdAt)}</span></p>`).join('')}`;}
  else if(tab==='users'){const r=await F.getDocs(F.query(F.collection(db,'users'),F.orderBy('createdAt','desc'),F.limit(100)));
   ab.innerHTML=`<table><tr><th>User</th><th>Role</th><th>Status</th><th></th></tr>${r.docs.map(d=>{const u=d.data(),sa=u.role==='superadmin',canS=d.id!==uid&&!sa&&(u.role!=='admin'||role==='superadmin');
    return `<tr><td>${esc(u.displayName)}<br><small class="muted">${esc(u.email)}</small></td><td>${esc(u.role)}</td><td>${u.suspended?'Suspended':'Active'}</td><td>${canS?`<a data-s="${d.id}" data-v="${u.suspended?0:1}">${u.suspended?'Reactivate':'Suspend'}</a>`:''} ${role==='superadmin'&&!sa?`<a data-ro="${d.id}" data-v="${u.role==='admin'?'user':'admin'}">${u.role==='admin'?'Demote':'Promote'}</a>`:''}</td></tr>`;}).join('')}</table>`;}
  else if(tab==='groups'){const r=await F.getDocs(F.query(F.collection(db,'chats'),F.where('type','==','group'),F.limit(100)));
   ab.innerHTML=`<table>${r.docs.map(d=>`<tr><td>${esc(d.data().name)}</td><td>${d.data().members.length} members</td><td><a data-dg="${d.id}">Delete</a></td></tr>`).join('')||'<tr><td>No groups</td></tr>'}</table>`;}
  else if(tab==='reports'){const r=await F.getDocs(F.query(F.collection(db,'reports'),F.orderBy('at','desc'),F.limit(50)));let h='';
   for(const d of r.docs){const x=d.data(),m=await F.getDoc(F.doc(db,'chats',x.chatId,'messages',x.mid));h+=`<tr><td>${esc(m.exists()?(m.data().deleted?'(removed)':m.data().text||'[image]'):'(gone)')}<br><small class="muted">${esc(x.reason)}</small></td><td><a data-rd="${d.id}" data-c="${x.chatId}" data-m="${x.mid}">Delete msg</a> <a data-rk="${d.id}" data-c="${x.chatId}" data-m="${x.mid}">Dismiss</a></td></tr>`;}
   ab.innerHTML=`<table>${h||'<tr><td>No reports</td></tr>'}</table>`;}
  else{const r=await F.getDocs(F.query(F.collection(db,'logs'),F.orderBy('at','desc'),F.limit(100)));
   ab.innerHTML=`<table>${r.docs.map(d=>{const x=d.data();return `<tr><td>${ts(x.at)}</td><td>${esc(x.action)}</td><td><small>${esc(x.actor)} → ${esc(x.target||'')} ${esc(x.extra||'')}</small></td></tr>`;}).join('')}</table>`;}}catch(x){ab.textContent=x.message;}}
// Android: back button
const CapApp=window.Capacitor?.Plugins?.App;CapApp?.addListener('backButton',()=>{if(!$('modal').hidden)closeModal();else if(cur)closeChat();else CapApp.exitApp();});
