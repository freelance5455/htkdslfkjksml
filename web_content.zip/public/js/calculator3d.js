/* CALCORA 3D calculator — pure HTML + CSS 3D transforms + vanilla JS.
 * Every key is a real <button>; the body is made of stacked layers so it has
 * physical thickness and can be rotated 360°.
 * Exposes window.Calcora3D.create(container, options)
 */
(function (global) {
  "use strict";
  var E = global.CalcEngine;
  var HISTORY_KEY = "calcora_html_history_v1";

  /* ---------------- key layout (ClassWiz fx-991CW inspired) ---------------- */
  function ins(token, fresh) { return { type: "insert", token: token, fresh: !!fresh }; }
  var KEYS = {
    on: { label: "ON", action: { type: "on" }, cls: "k-round" },
    angle: { label: "D/R", action: { type: "angle" }, cls: "k-round" },
    shift: { label: "SHIFT", action: { type: "shift" }, cls: "k-round k-shift" },
    pi: { label: "π", action: ins("π"), cls: "k-round" },
    e: { label: "e", action: ins("e"), cls: "k-round" },
    pct: { label: "%", action: ins("%"), cls: "k-round" },
    up: { label: "▲", action: { type: "up" }, cls: "k-dir k-up" },
    down: { label: "▼", action: { type: "down" }, cls: "k-dir k-down" },
    left: { label: "◀", action: { type: "left" }, cls: "k-dir k-left" },
    right: { label: "▶", action: { type: "right" }, cls: "k-dir k-right" },
    ok: { label: "OK", action: { type: "exe" }, cls: "k-ok" },
    rup: { label: "▲", action: { type: "up" }, cls: "k-rock k-rock-up" },
    rdown: { label: "▼", action: { type: "down" }, cls: "k-rock k-rock-down" },

    neg: { label: "(−)", action: ins("−", true), s: "|x|", sAction: ins("Abs(") },
    sqrt: { label: "√", action: ins("√("), s: "∛", sAction: ins("∛(") },
    sq: { label: "x²", action: ins("²"), s: "x⁻¹", sAction: ins("⁻¹") },
    pow: { label: "xʸ", action: ins("^("), s: "n!", sAction: ins("!") },
    log: { label: "log", action: ins("log("), s: "10ˣ", sAction: ins("10^(") },
    ln: { label: "ln", action: ins("ln("), s: "eˣ", sAction: ins("e^(") },
    ans: { label: "Ans", action: ins("Ans") },
    sin: { label: "sin", action: ins("sin("), s: "sin⁻¹", sAction: ins("sin⁻¹(") },
    cos: { label: "cos", action: ins("cos("), s: "cos⁻¹", sAction: ins("cos⁻¹(") },
    tan: { label: "tan", action: ins("tan("), s: "tan⁻¹", sAction: ins("tan⁻¹(") },
    lp: { label: "(", action: ins("(") },
    rp: { label: ")", action: ins(")") },

    d7: { label: "7", action: ins("7") }, d8: { label: "8", action: ins("8") }, d9: { label: "9", action: ins("9") },
    del: { label: "⌫", action: { type: "del" }, cls: "k-danger" },
    ac: { label: "AC", action: { type: "ac" }, cls: "k-danger" },
    d4: { label: "4", action: ins("4") }, d5: { label: "5", action: ins("5") }, d6: { label: "6", action: ins("6") },
    mul: { label: "×", action: ins("×") }, div: { label: "÷", action: ins("÷") },
    d1: { label: "1", action: ins("1") }, d2: { label: "2", action: ins("2") }, d3: { label: "3", action: ins("3") },
    add: { label: "+", action: ins("+") }, sub: { label: "−", action: ins("−") },
    d0: { label: "0", action: ins("0") }, dot: { label: ".", action: ins(".") },
    x10: { label: "×10ˣ", action: ins("×10^("), cls: "k-small" },
    format: { label: "S⇔D", action: { type: "format" }, cls: "k-small" },
    exe: { label: "EXE", action: { type: "exe" }, cls: "k-exe" }
  };
  var FUNC_ROWS = [["neg", "sqrt", "sq", "pow", "log", "ln"], ["ans", "sin", "cos", "tan", "lp", "rp"]];
  var MAIN_ROWS = [
    ["d7", "d8", "d9", "del", "ac"],
    ["d4", "d5", "d6", "mul", "div"],
    ["d1", "d2", "d3", "add", "sub"],
    ["d0", "dot", "x10", "format", "exe"]
  ];
  var KEYBOARD = {
    "0": "d0", "1": "d1", "2": "d2", "3": "d3", "4": "d4", "5": "d5", "6": "d6", "7": "d7", "8": "d8", "9": "d9",
    ".": "dot", ",": "dot", "+": "add", "-": "sub", "*": "mul", "x": "mul", "/": "div", "^": "pow",
    "(": "lp", ")": "rp", "Enter": "exe", "=": "exe", "Backspace": "del", "Escape": "ac", "Delete": "ac",
    "ArrowUp": "up", "ArrowDown": "down", "ArrowLeft": "left", "ArrowRight": "right",
    "%": "pct", "s": "sin", "c": "cos", "t": "tan", "l": "log", "n": "ln", "r": "sqrt", "p": "pi", "e": "e", "a": "ans"
  };

  /* ---------------- colour themes ---------------- */
  function hexToRgb(h) {
    h = h.replace("#", "");
    if (h.length === 3) h = h.split("").map(function (c) { return c + c; }).join("");
    var n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function mix(hex, target, t) {
    var a = hexToRgb(hex), b = hexToRgb(target);
    return "#" + a.map(function (v, i) { return Math.round(v + (b[i] - v) * t).toString(16).padStart(2, "0"); }).join("");
  }
  function isLight(hex) {
    var c = hexToRgb(hex);
    return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255 > 0.6;
  }

  function colorNameToHex(name) {
    if (!name) return "#1c1d22";
    if (/^#[0-9a-f]{3,6}$/i.test(name.trim())) return name.trim();
    var n = name.toLowerCase();
    if (n.indexOf("rose gold") >= 0) return "#d9a796";
    if (/pink|blossom|sakura|magenta glow/.test(n)) return "#f2c4cf";
    if (/gold|champagne/.test(n)) return "#c9a65f";
    if (/white|pearl|arctic|aurora/.test(n)) return "#e8eaef";
    if (/silver/.test(n)) return "#c4c9d2";
    if (/gray|grey|graphite|titanium|steel/.test(n)) return "#4a505e";
    if (/blue|navy|cyan|ice/.test(n)) return "#1d3766";
    if (/violet|purple/.test(n)) return "#3a1d6b";
    if (/green|mint/.test(n)) return "#1f4d3a";
    return "#1c1d22";
  }

  function themeVars(bodyHex, accent) {
    var light = isLight(bodyHex);
    var v = light
      ? {
          "--body": bodyHex, "--body-hi": mix(bodyHex, "#ffffff", 0.35), "--edge": mix(bodyHex, "#000000", 0.22),
          "--key": mix(bodyHex, "#ffffff", 0.45), "--key-lo": mix(bodyHex, "#000000", 0.06), "--key-side": mix(bodyHex, "#000000", 0.28),
          "--key-text": "#2b1d24", "--print": mix(bodyHex, "#000000", 0.55), "--gold": "#a3620a",
          "--shift": "#8b5cf6", "--shift-text": "#ffffff", "--bezel": "#1a1a1f"
        }
      : {
          "--body": bodyHex, "--body-hi": mix(bodyHex, "#ffffff", 0.1), "--edge": mix(bodyHex, "#000000", 0.45),
          "--key": mix(bodyHex, "#ffffff", 0.16), "--key-lo": mix(bodyHex, "#ffffff", 0.05), "--key-side": mix(bodyHex, "#000000", 0.6),
          "--key-text": "#f5f7fa", "--print": "#aab3c2", "--gold": "#e3b341",
          "--shift": "#d4a72c", "--shift-text": "#1b1405", "--bezel": "#07080b"
        };
    v["--accent"] = accent || "#8b5cf6";
    return v;
  }

  /* ---------------- feedback ---------------- */
  var audio = null;
  var soundOn = localStorage.getItem("calcora_sound") !== "off";
  function beep(kind) {
    if (!soundOn) return;
    try {
      if (!audio) {
        var AC = global.AudioContext || global.webkitAudioContext;
        if (!AC) return;
        audio = new AC();
      }
      if (audio.state === "suspended") audio.resume();
      var f = { digit: 660, op: 540, exe: 880, fn: 740, err: 170 }[kind] || 660;
      var o = audio.createOscillator(), g = audio.createGain(), t = audio.currentTime;
      var dur = kind === "err" ? 0.25 : 0.11;
      o.type = kind === "err" ? "square" : "sine";
      o.frequency.setValueAtTime(f, t);
      if (kind === "exe") o.frequency.exponentialRampToValueAtTime(f * 1.5, t + 0.09);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.07, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(audio.destination);
      o.start(t);
      o.stop(t + dur + 0.02);
    } catch (e) { /* ignore */ }
  }
  function vibrate(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignore */ } }

  /* ---------------- shared history ---------------- */
  var history = [];
  try { history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); } catch (e) { history = []; }
  var historyListeners = [];
  function pushHistory(entry) {
    history.unshift(entry);
    history = history.slice(0, 50);
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(history)); } catch (e) { /* ignore */ }
    historyListeners.forEach(function (fn) { fn(history); });
  }
  function clearHistory() {
    history = [];
    try { localStorage.removeItem(HISTORY_KEY); } catch (e) { /* ignore */ }
    historyListeners.forEach(function (fn) { fn(history); });
  }

  /* ---------------- keyboard routing: last-used / visible calculator ---------------- */
  var instances = [];
  var activeInstance = null;
  document.addEventListener("keydown", function (ev) {
    if (!activeInstance || ev.ctrlKey || ev.metaKey || ev.altKey) return;
    var tg = ev.target;
    if (tg && (tg.tagName === "INPUT" || tg.tagName === "TEXTAREA" || tg.tagName === "SELECT" || tg.isContentEditable)) return;
    if (document.body.classList.contains("modal-open") && !activeInstance.root.closest(".modal, .page-view")) return;
    if (ev.key === "!") { ev.preventDefault(); activeInstance.dispatch({ type: "insert", token: "!" }); return; }
    var id = KEYBOARD[ev.key];
    if (!id) return;
    ev.preventDefault();
    activeInstance.press(id);
  });

  /* ---------------- DOM builders ---------------- */
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html !== undefined) n.innerHTML = html;
    return n;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  function keyButton(id, extraCls) {
    var k = KEYS[id];
    var b = el("button", "key " + (k.cls || "") + " " + (extraCls || ""));
    b.type = "button";
    b.dataset.key = id;
    b.setAttribute("aria-label", k.label);
    b.innerHTML = "<span>" + esc(k.label) + "</span>";
    return b;
  }
  function keyCell(id, extraCls) {
    var k = KEYS[id];
    var cell = el("div", "kcell");
    cell.appendChild(el("span", "slabel", k.s ? esc(k.s) : "&nbsp;"));
    cell.appendChild(keyButton(id, extraCls));
    return cell;
  }

  function buildFace(modelLabel) {
    var face = el("div", "c3-face");
    face.innerHTML =
      '<div class="c3-top"><div class="c3-brand"><b>CALCORA</b><small>' + esc(modelLabel) + '</small></div>' +
      '<div class="c3-solar"><i></i><i></i><i></i><i></i></div></div>' +
      '<div class="c3-bezel"><div class="lcd" aria-live="polite">' +
      '<div class="lcd-status"><span class="ind ind-s">S</span><span class="ind ind-angle">D</span><span class="ind-text">Math</span><span class="ind-text ind-frac">a/b</span><span class="ind-arrows">▲▼</span></div>' +
      '<div class="lcd-expr"></div><div class="lcd-result"></div></div></div>' +
      '<div class="c3-wordmark"><span class="c3-line"></span><em>CLASSPRO</em></div>';

    var nav = el("div", "c3-nav");
    var col = function (ids) {
      var c = el("div", "nav-col");
      ids.forEach(function (id) { c.appendChild(keyButton(id)); });
      return c;
    };
    nav.appendChild(col(["on", "shift"]));
    nav.appendChild(col(["angle", "pi"]));
    var dpad = el("div", "dpad");
    ["up", "left", "ok", "right", "down"].forEach(function (id) { dpad.appendChild(keyButton(id)); });
    nav.appendChild(dpad);
    nav.appendChild(col(["e", "pct"]));
    var rocker = el("div", "rocker");
    rocker.appendChild(keyButton("rup"));
    rocker.appendChild(keyButton("rdown"));
    var rc = el("div", "nav-col nav-rocker");
    rc.appendChild(el("span", "caption", "HISTORY"));
    rc.appendChild(rocker);
    nav.appendChild(rc);
    face.appendChild(nav);

    FUNC_ROWS.forEach(function (row) {
      var r = el("div", "c3-row c3-func");
      row.forEach(function (id) { r.appendChild(keyCell(id, "k-pill")); });
      face.appendChild(r);
    });
    MAIN_ROWS.forEach(function (row) {
      var r = el("div", "c3-row c3-main");
      row.forEach(function (id) {
        var b = keyButton(id, "k-main");
        r.appendChild(b);
      });
      face.appendChild(r);
    });
    return face;
  }

  function buildBack(modelLabel) {
    return el("div", "c3-back",
      '<div class="back-cover"><span class="screw"></span><span class="screw"></span>' +
      '<div class="back-label"><b>CALCORA 3D</b><span>' + esc(modelLabel) + '</span><span>SOLAR · LR44</span>' +
      '<span>Designed in Dhaka · Bangladesh</span><span class="ce">CE ⚡ ♻</span></div></div>' +
      '<span class="foot f1"></span><span class="foot f2"></span><span class="foot f3"></span><span class="foot f4"></span>');
  }

  /* ---------------- factory ---------------- */
  function create(container, opts) {
    opts = opts || {};
    var modelLabel = opts.modelLabel || "CLC-991CW";
    var state = E.initialState();
    if (opts.initialTokens && opts.initialTokens.length) {
      state.tokens = opts.initialTokens.slice();
      state.cursor = state.tokens.length;
      state = E.reduce(state, { type: "exe" }, []).state;
    }
    var demoScreen = opts.demoScreen || null; // {expression, result} for product viewer

    var stage = el("div", "c3-stage");
    var floater = el("div", "c3-float");
    var calc = el("div", "c3");
    var LAYERS = 14;
    for (var i = 1; i <= LAYERS; i++) {
      var layer = el("div", "c3-layer" + (i === Math.round(LAYERS / 2) ? " c3-rim" : ""));
      layer.style.setProperty("--i", i);
      layer.style.setProperty("--n", LAYERS);
      calc.appendChild(layer);
    }
    var face = buildFace(modelLabel);
    calc.appendChild(buildBack(modelLabel));
    calc.appendChild(face);
    floater.appendChild(calc);
    stage.appendChild(floater);
    stage.appendChild(el("div", "c3-shadow"));
    container.appendChild(stage);

    var exprEl = face.querySelector(".lcd-expr");
    var resultEl = face.querySelector(".lcd-result");
    var lcd = face.querySelector(".lcd");
    var indS = face.querySelector(".ind-s");
    var indAngle = face.querySelector(".ind-angle");
    var indFrac = face.querySelector(".ind-frac");
    var shiftBtn = face.querySelector('[data-key="shift"]');

    function setTheme(bodyHex, accent) {
      var vars = themeVars(bodyHex, accent);
      Object.keys(vars).forEach(function (k) { calc.style.setProperty(k, vars[k]); });
      calc.classList.toggle("is-light", isLight(bodyHex));
    }
    setTheme(opts.bodyColor || "#1c1d22", opts.accent);

    function render() {
      var s = E.screen(state);
      if (demoScreen && !state.tokens.length && !state.error) {
        s = { expression: demoScreen.expression, cursor: null, result: demoScreen.result, error: null, shift: state.shift, angle: state.angle, fraction: false };
      }
      indS.classList.toggle("on", s.shift);
      indAngle.textContent = s.angle === "DEG" ? "D" : "R";
      indFrac.classList.toggle("on", s.fraction);
      shiftBtn.classList.toggle("active", s.shift);
      face.classList.toggle("shift-on", s.shift);
      lcd.classList.toggle("has-error", !!s.error);
      if (s.error) {
        exprEl.innerHTML = '<span class="lcd-err">' + esc(s.error) + "</span>";
        resultEl.innerHTML = '<span class="lcd-hint">[AC] :Cancel &nbsp; [◀][▶] :Goto</span>';
        return;
      }
      var chars = Array.from(s.expression);
      if (s.cursor === null) {
        exprEl.innerHTML = esc(chars.join("")) || "&nbsp;";
      } else {
        exprEl.innerHTML = esc(chars.slice(0, s.cursor).join("")) + '<span class="caret"></span>' + esc(chars.slice(s.cursor).join(""));
      }
      exprEl.scrollLeft = exprEl.scrollWidth;
      resultEl.textContent = s.result || "";
      var len = (s.result || "").length;
      resultEl.style.fontSize = len > 14 ? "0.62em" : len > 10 ? "0.8em" : "";
    }

    function soundKind(action, st) {
      if (st.error) return "err";
      if (action.type === "exe") return "exe";
      if (action.type === "insert") return /^[0-9.]$/.test(action.token) ? "digit" : "op";
      return "fn";
    }

    function dispatch(action) {
      var res = E.reduce(state, action, history);
      state = res.state;
      if (res.entry) pushHistory(res.entry);
      beep(soundKind(action, state));
      vibrate(state.error ? [40, 30, 40] : 12);
      if (state.error) {
        calc.classList.remove("shake");
        void calc.offsetWidth;
        calc.classList.add("shake");
      }
      render();
      if (opts.onChange) opts.onChange(state);
    }

    function flash(id) {
      var b = face.querySelector('[data-key="' + id + '"]');
      if (!b) return;
      b.classList.add("pressed");
      setTimeout(function () { b.classList.remove("pressed"); }, 140);
    }

    function press(id) {
      var k = KEYS[id];
      if (!k) return;
      activeInstance = api;
      var action = state.shift && k.sAction ? k.sAction : k.action;
      flash(id);
      dispatch(action);
    }

    face.addEventListener("click", function (ev) {
      var b = ev.target.closest("button[data-key]");
      if (!b) return;
      press(b.dataset.key);
    });

    /* ---------- 3D motion: idle sway + pointer tilt + drag 360° with inertia ---------- */
    var reduced = global.matchMedia && global.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var sway = opts.sway === undefined ? 1 : opts.sway;
    var dragY = opts.startAngle || 0, dragX = 0, velY = 0;
    var tiltX = 0, tiltY = 0, tTiltX = 0, tTiltY = 0;
    var dragging = false, lastX = 0, lastY = 0, lastMove = 0, startX = 0, startY = 0, moved = false;
    var visible = true, raf = 0, t0 = performance.now();
    var intro = opts.intro ? 1 : 0;

    stage.addEventListener("pointermove", function (ev) {
      if (dragging) {
        var dx = ev.clientX - lastX, dy = ev.clientY - lastY;
        if (Math.abs(ev.clientX - startX) + Math.abs(ev.clientY - startY) > 4) moved = true;
        dragY += dx * 0.45;
        dragX = Math.max(-35, Math.min(35, dragX - dy * 0.3));
        velY = dx * 0.45;
        lastX = ev.clientX; lastY = ev.clientY; lastMove = performance.now();
        return;
      }
      if (ev.pointerType !== "mouse") return;
      var r = stage.getBoundingClientRect();
      tTiltY = ((ev.clientX - r.left) / r.width - 0.5) * 16;
      tTiltX = -((ev.clientY - r.top) / r.height - 0.5) * 12;
    });
    stage.addEventListener("pointerleave", function () { tTiltX = 0; tTiltY = 0; });
    stage.addEventListener("pointerdown", function (ev) {
      if (ev.target.closest("button")) { activeInstance = api; return; }
      activeInstance = api;
      dragging = true; moved = false;
      startX = lastX = ev.clientX; startY = lastY = ev.clientY; velY = 0;
      stage.classList.add("dragging");
      try { stage.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
    });
    function endDrag() {
      if (!dragging) return;
      dragging = false;
      stage.classList.remove("dragging");
      lastMove = performance.now();
    }
    stage.addEventListener("pointerup", endDrag);
    stage.addEventListener("pointercancel", endDrag);

    function frame(now) {
      raf = 0;
      if (!visible) return;
      var t = (now - t0) / 1000;
      if (!dragging) {
        dragY += velY;
        velY *= 0.94;
        if (Math.abs(velY) < 0.05 && now - lastMove > 2600 && opts.autoReturn !== false) {
          var target = Math.round(dragY / 360) * 360; // ease back to the front
          dragY += (target - dragY) * 0.04;
          dragX += (0 - dragX) * 0.05;
        }
        if (opts.autoSpin) dragY += 0.25;
      }
      tiltX += (tTiltX - tiltX) * 0.08;
      tiltY += (tTiltY - tiltY) * 0.08;
      if (intro > 0) intro = Math.max(0, intro - 0.012);
      var ease = 1 - Math.pow(1 - (1 - intro), 3);
      var swayY = reduced ? 0 : Math.sin(t * 0.55) * 9 * sway;
      var swayX = reduced ? 0 : Math.sin(t * 0.4) * 3 * sway;
      var ry = dragY + tiltY + swayY - (1 - ease) * 540;
      var rx = 6 + dragX + tiltX + swayX;
      calc.style.transform = "rotateX(" + rx.toFixed(2) + "deg) rotateY(" + ry.toFixed(2) + "deg) scale(" + (0.55 + 0.45 * ease).toFixed(3) + ")";
      var facing = Math.cos((ry * Math.PI) / 180) > 0;
      calc.classList.toggle("show-back", !facing);
      raf = requestAnimationFrame(frame);
    }
    if ("IntersectionObserver" in global) {
      new IntersectionObserver(function (entries) {
        visible = entries[0].isIntersecting;
        if (visible && !raf) raf = requestAnimationFrame(frame);
        if (visible && opts.claimKeyboard) activeInstance = api;
      }, { threshold: 0.15 }).observe(stage);
    }
    raf = requestAnimationFrame(frame);

    render();

    var api = {
      root: container,
      press: press,
      dispatch: dispatch,
      setTheme: setTheme,
      setDemo: function (d) { demoScreen = d; render(); },
      getState: function () { return state; },
      destroy: function () {
        visible = false;
        if (raf) cancelAnimationFrame(raf);
        instances = instances.filter(function (x) { return x !== api; });
        if (activeInstance === api) activeInstance = instances[0] || null;
        container.innerHTML = "";
      }
    };
    instances.push(api);
    if (!activeInstance || opts.claimKeyboard) activeInstance = api;
    return api;
  }

  global.Calcora3D = {
    create: create,
    colorNameToHex: colorNameToHex,
    getHistory: function () { return history; },
    clearHistory: clearHistory,
    onHistory: function (fn) { historyListeners.push(fn); },
    recall: function (index) { if (activeInstance) activeInstance.dispatch({ type: "recall", index: index }); },
    setSound: function (on) { soundOn = on; localStorage.setItem("calcora_sound", on ? "on" : "off"); },
    isSoundOn: function () { return soundOn; }
  };
})(window);
