// Owner must paste values from Firebase Console > Project settings > Your apps > Web app.
export const firebaseConfig={apiKey:"REPLACE_ME",authDomain:"REPLACE_ME.firebaseapp.com",databaseURL:"https://REPLACE_ME-default-rtdb.firebaseio.com",projectId:"REPLACE_ME",storageBucket:"REPLACE_ME.appspot.com",messagingSenderId:"REPLACE_ME",appId:"REPLACE_ME"};
// reCAPTCHA v3 site key for App Check (leave "" to disable until configured).
export const APPCHECK_SITE_KEY="";
