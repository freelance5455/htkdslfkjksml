/* CALCORA scientific calculator engine — plain JavaScript, no eval().
 * Natural-input expression made of tokens + a cursor (ClassWiz style).
 * Exposes window.CalcEngine
 */
(function (global) {
  "use strict";

  var DIGIT = /^[0-9.]$/;
  var FUNCS = {
    "sin(": 1, "cos(": 1, "tan(": 1, "sin⁻¹(": 1, "cos⁻¹(": 1, "tan⁻¹(": 1,
    "log(": 1, "ln(": 1, "√(": 1, "∛(": 1, "10^(": 1, "e^(": 1, "Abs(": 1
  };
  // after a result, these keys continue from Ans (e.g. "+5" → "Ans+5")
  var CONTINUE = { "+": 1, "−": 1, "×": 1, "÷": 1, "²": 1, "⁻¹": 1, "^(": 1, "!": 1, "%": 1, "×10^(": 1 };

  function CalcError(msg) { this.message = msg; }
  var mathErr = function () { return new CalcError("Math ERROR"); };
  var syntaxErr = function () { return new CalcError("Syntax ERROR"); };

  function toRad(x, a) { return a === "DEG" ? (x * Math.PI) / 180 : x; }
  function fromRad(x, a) { return a === "DEG" ? (x * 180) / Math.PI : x; }
  function clean(v) { return Math.abs(v) < 1e-12 ? 0 : v; }

  function applyFunc(tok, x, a) {
    switch (tok) {
      case "sin(": return clean(Math.sin(toRad(x, a)));
      case "cos(": return clean(Math.cos(toRad(x, a)));
      case "tan(":
        if (Math.abs(Math.cos(toRad(x, a))) < 1e-12) throw mathErr();
        return clean(Math.tan(toRad(x, a)));
      case "sin⁻¹(": if (x < -1 || x > 1) throw mathErr(); return fromRad(Math.asin(x), a);
      case "cos⁻¹(": if (x < -1 || x > 1) throw mathErr(); return fromRad(Math.acos(x), a);
      case "tan⁻¹(": return fromRad(Math.atan(x), a);
      case "log(": if (x <= 0) throw mathErr(); return Math.log(x) / Math.LN10;
      case "ln(": if (x <= 0) throw mathErr(); return Math.log(x);
      case "√(": if (x < 0) throw mathErr(); return Math.sqrt(x);
      case "∛(": return x < 0 ? -Math.pow(-x, 1 / 3) : Math.pow(x, 1 / 3);
      case "10^(": return Math.pow(10, x);
      case "e^(": return Math.exp(x);
      case "Abs(": return Math.abs(x);
    }
    throw syntaxErr();
  }

  function factorial(n) {
    if (n < 0 || Math.floor(n) !== n || n > 170) throw mathErr();
    var r = 1;
    for (var i = 2; i <= n; i++) r *= i;
    return r;
  }

  function startsPrimary(t) {
    return t !== undefined && (DIGIT.test(t) || t === "π" || t === "e" || t === "Ans" || t === "(" || FUNCS[t] === 1);
  }

  /* ---------------- recursive-descent parser ---------------- */
  function evaluate(tokens, ans, angle) {
    var i = 0;
    var t = tokens;
    function peek() { return t[i]; }
    function close() {
      var p = peek();
      if (p === ")") { i++; return; }
      if (p === undefined) return; // auto-close at end of input
      throw syntaxErr();
    }
    function expr() {
      var v = term();
      for (;;) {
        var p = peek();
        if (p === "+") { i++; v += term(); }
        else if (p === "−") { i++; v -= term(); }
        else return v;
      }
    }
    function term() {
      var v = unary();
      for (;;) {
        var p = peek();
        if (p === "×") { i++; v *= unary(); }
        else if (p === "÷") { i++; var d = unary(); if (d === 0) throw mathErr(); v /= d; }
        else if (p === "×10^(") { i++; var e = expr(); close(); v *= Math.pow(10, e); }
        else if (startsPrimary(p)) { v *= power(); } // implicit ×: 2π, 3(4), 2sin(30)
        else return v;
      }
    }
    function unary() {
      var p = peek();
      if (p === "−") { i++; return -unary(); }
      if (p === "+") { i++; return unary(); }
      return power();
    }
    function power() {
      var b = postfix(primary());
      while (peek() === "^(") { i++; var e = expr(); close(); b = postfix(Math.pow(b, e)); }
      return b;
    }
    function postfix(v) {
      for (;;) {
        var p = peek();
        if (p === "²") { i++; v = v * v; }
        else if (p === "⁻¹") { i++; if (v === 0) throw mathErr(); v = 1 / v; }
        else if (p === "!") { i++; v = factorial(v); }
        else if (p === "%") { i++; v = v / 100; }
        else return v;
      }
    }
    function primary() {
      var tok = t[i++];
      if (tok === undefined) throw syntaxErr();
      if (DIGIT.test(tok)) {
        var s = tok;
        while (peek() !== undefined && DIGIT.test(peek())) s += t[i++];
        if (s === "." || (s.match(/\./g) || []).length > 1) throw syntaxErr();
        return parseFloat(s);
      }
      if (tok === "π") return Math.PI;
      if (tok === "e") return Math.E;
      if (tok === "Ans") return ans;
      if (tok === "(") { var v = expr(); close(); return v; }
      if (FUNCS[tok] === 1) { var x = expr(); close(); return applyFunc(tok, x, angle); }
      throw syntaxErr();
    }

    if (!t.length) throw syntaxErr();
    var v = expr();
    if (i < t.length) throw syntaxErr();
    if (!isFinite(v)) throw mathErr();
    return v;
  }

  var SUP = { "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹", "-": "⁻" };

  function formatNumber(n) {
    if (!isFinite(n)) return "Math ERROR";
    if (n === 0) return "0";
    var abs = Math.abs(n);
    if (abs >= 1e10 || abs < 1e-6) {
      var parts = n.toExponential(9).split("e");
      var exp = String(Number(parts[1])).split("").map(function (c) { return SUP[c] || c; }).join("");
      return String(Number(parts[0])) + "×10" + exp;
    }
    return String(Number(n.toPrecision(10)));
  }

  /** decimal → fraction (S⇔D). Returns null when no small exact fraction exists. */
  function toFraction(x) {
    if (!isFinite(x) || Math.floor(x) === x) return null;
    var sign = x < 0 ? "-" : "";
    var v = Math.abs(x), h1 = 1, h0 = 0, k1 = 0, k0 = 1, b = v;
    for (var n = 0; n < 32; n++) {
      var a = Math.floor(b);
      var h2 = a * h1 + h0, k2 = a * k1 + k0;
      if (k2 > 9999) break;
      h0 = h1; h1 = h2; k0 = k1; k1 = k2;
      if (Math.abs(v - h1 / k1) < 1e-10) return sign + h1 + "⁄" + k1;
      var rest = b - a;
      if (rest === 0) break;
      b = 1 / rest;
    }
    return null;
  }

  /* ---------------- state machine ---------------- */
  function initialState() {
    return { tokens: [], cursor: 0, result: null, resultValue: null, ans: 0, angle: "DEG",
      shift: false, error: null, evaluated: false, fraction: false, historyIndex: -1 };
  }

  function assign(a, b) { var o = {}, k; for (k in a) o[k] = a[k]; for (k in b) o[k] = b[k]; return o; }

  /** returns { state, entry } where entry is a new history item (or null) */
  function reduce(s, action, history) {
    history = history || [];
    var none = function (st) { return { state: st, entry: null }; };
    switch (action.type) {
      case "on":
        return none(assign(initialState(), { angle: s.angle }));
      case "ac":
        return none(assign(s, { tokens: [], cursor: 0, result: null, resultValue: null, error: null,
          evaluated: false, fraction: false, shift: false, historyIndex: -1 }));
      case "shift":
        return none(assign(s, { shift: !s.shift }));
      case "angle":
        return none(assign(s, { angle: s.angle === "DEG" ? "RAD" : "DEG", shift: false }));
      case "insert": {
        var base = assign(s, { shift: false, error: null, historyIndex: -1 });
        if (s.evaluated) {
          var tokens0 = !action.fresh && CONTINUE[action.token] ? ["Ans", action.token] : [action.token];
          return none(assign(base, { tokens: tokens0, cursor: tokens0.length, evaluated: false,
            result: null, resultValue: null, fraction: false }));
        }
        if (base.tokens.length >= 99) return none(base);
        var tk = base.tokens.slice(0, base.cursor).concat([action.token], base.tokens.slice(base.cursor));
        return none(assign(base, { tokens: tk, cursor: base.cursor + 1, result: null }));
      }
      case "del":
        if (s.error) return none(assign(s, { error: null, shift: false, cursor: s.tokens.length }));
        if (s.evaluated) return none(assign(s, { evaluated: false, result: null, resultValue: null, cursor: s.tokens.length, shift: false }));
        if (s.cursor === 0) return none(assign(s, { shift: false }));
        return none(assign(s, {
          tokens: s.tokens.slice(0, s.cursor - 1).concat(s.tokens.slice(s.cursor)),
          cursor: s.cursor - 1, shift: false
        }));
      case "left":
      case "right":
        if (s.error || s.evaluated) {
          return none(assign(s, { error: null, evaluated: false, result: null, resultValue: null, shift: false,
            cursor: action.type === "left" ? s.tokens.length : 0 }));
        }
        return none(assign(s, { shift: false,
          cursor: action.type === "left" ? Math.max(0, s.cursor - 1) : Math.min(s.tokens.length, s.cursor + 1) }));
      case "exe":
        if (!s.tokens.length) return none(assign(s, { shift: false }));
        try {
          var value = evaluate(s.tokens, s.ans, s.angle);
          var result = formatNumber(value);
          return {
            state: assign(s, { shift: false, error: null, evaluated: true, result: result, resultValue: value,
              ans: value, fraction: false, historyIndex: -1, cursor: s.tokens.length }),
            entry: { expr: s.tokens.join(""), tokens: s.tokens.slice(), result: result, value: value }
          };
        } catch (e) {
          return none(assign(s, { shift: false, evaluated: false, error: e instanceof CalcError ? e.message : "Syntax ERROR" }));
        }
      case "format": {
        if (!s.evaluated || s.resultValue === null) return none(assign(s, { shift: false }));
        if (s.fraction) return none(assign(s, { shift: false, fraction: false, result: formatNumber(s.resultValue) }));
        var f = toFraction(s.resultValue);
        if (!f) return none(assign(s, { shift: false }));
        return none(assign(s, { shift: false, fraction: true, result: f }));
      }
      case "up":
      case "down":
      case "recall": {
        if (!history.length) return none(assign(s, { shift: false }));
        var idx = action.type === "recall" ? action.index
          : action.type === "up" ? Math.min(history.length - 1, s.historyIndex + 1) : s.historyIndex - 1;
        if (idx < 0) {
          return none(assign(s, { shift: false, historyIndex: -1, tokens: [], cursor: 0, result: null, resultValue: null, evaluated: false }));
        }
        var item = history[idx];
        if (!item) return none(assign(s, { shift: false }));
        return none(assign(s, { shift: false, error: null, tokens: item.tokens.slice(), cursor: item.tokens.length,
          result: item.result, resultValue: item.value, evaluated: true, fraction: false, historyIndex: idx }));
      }
    }
    return none(s);
  }

  function screen(s) {
    return {
      expression: s.tokens.join(""),
      cursor: s.evaluated || s.error ? null : Array.from(s.tokens.slice(0, s.cursor).join("")).length,
      result: s.evaluated ? s.result : null,
      error: s.error, shift: s.shift, angle: s.angle, fraction: s.fraction
    };
  }

  global.CalcEngine = {
    evaluate: evaluate, formatNumber: formatNumber, toFraction: toFraction,
    initialState: initialState, reduce: reduce, screen: screen
  };
})(window);
