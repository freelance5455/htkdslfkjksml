/* CALCORA 3D — storefront logic (vanilla JavaScript).
 * Uses the live API (/api/products, /api/orders) when served from the server,
 * and falls back to bundled data (js/data.js) + localStorage when opened offline.
 */
(function () {
  "use strict";

  /* ============================ helpers ============================ */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var ONLINE = /^https?:$/.test(location.protocol);
  var CART_KEY = "calcora_cart_v2", WISH_KEY = "calcora_wish_v2", ORDERS_KEY = "calcora_my_orders_v2", LOCAL_ORDERS_KEY = "calcora_offline_orders_v2";

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function bdt(n) { return "৳" + Number(n || 0).toLocaleString("en-IN"); }
  function load(key, fb) { try { var v = JSON.parse(localStorage.getItem(key)); return v == null ? fb : v; } catch (e) { return fb; } }
  function save(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  function fmtDate(d) { try { return new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } }
  function debounce(fn, ms) { var t; return function () { var a = arguments; clearTimeout(t); t = setTimeout(function () { fn.apply(null, a); }, ms); }; }

  function toast(msg, isErr) {
    var t = document.createElement("div");
    t.className = "toast" + (isErr ? " err" : "");
    t.textContent = msg;
    $("#toasts").appendChild(t);
    setTimeout(function () { t.style.transition = "opacity .3s"; t.style.opacity = "0"; }, 2400);
    setTimeout(function () { t.remove(); }, 2800);
  }

  function api(path, opts) {
    if (!ONLINE) return Promise.reject(new Error("offline"));
    opts = opts || {};
    return fetch(path, {
      method: opts.method || "GET",
      headers: opts.body ? { "Content-Type": "application/json" } : undefined,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      cache: "no-store"
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) { var err = new Error(data.error || "Request failed"); err.server = true; throw err; }
        return data;
      });
    });
  }

  function imgSrc(p) {
    var src = p.image || "images/products/classpro-black.jpg";
    if (!ONLINE && src.charAt(0) === "/") src = src.slice(1);
    return src;
  }

  /* ============================ data ============================ */
  var CATEGORIES = [
    { name: "Standard Models", icon: "🧮", desc: "Everyday essentials with premium build quality." },
    { name: "Premium Models", icon: "💎", desc: "Flagship devices with luxury materials." },
    { name: "3D Models", icon: "🔷", desc: "Holographic displays and spatial interfaces." },
    { name: "Scientific Models", icon: "🧪", desc: "ClassWiz-style engineering & exam power." },
    { name: "Digital Models", icon: "💡", desc: "Sleek digital companions for modern work." },
    { name: "Special Edition", icon: "⭐", desc: "Limited runs. Numbered. Collectible." },
    { name: "New Arrivals", icon: "✨", desc: "The latest drops from the CALCORA lab." }
  ];
  var products = [];
  var byId = {};
  var cart = load(CART_KEY, []);   // [{id, qty}] — prices always resolved from products
  var wish = load(WISH_KEY, []);   // [id]
  var buyNow = null;               // [{id, qty}] for "Order Now"

  function setProducts(list) {
    products = list.map(function (p) {
      return {
        id: Number(p.id), name: p.name, modelNumber: p.modelNumber, category: p.category, price: Number(p.price),
        description: p.description || "", features: p.features || [], colors: p.colors || [], image: p.image,
        status: p.status || "available", isFeatured: !!p.isFeatured, isBestSeller: !!p.isBestSeller,
        isNewArrival: !!p.isNewArrival, stock: Number(p.stock || 0), createdAt: p.createdAt || null
      };
    });
    byId = {};
    products.forEach(function (p) { byId[p.id] = p; });
    cart = cart.filter(function (c) { return byId[c.id]; });
    wish = wish.filter(function (id) { return byId[id]; });
    save(CART_KEY, cart); save(WISH_KEY, wish);
  }

  function loadProducts() {
    $("#productGrid").innerHTML = new Array(8).join('<div class="skeleton"></div>');
    return api("/api/products")
      .then(function (d) { setProducts(d.products || []); })
      .catch(function () { setProducts((window.CALCORA_DATA && window.CALCORA_DATA.products) || []); })
      .then(function () {
        $("#statModels").textContent = products.length + "";
        renderCategories(); renderChips(); renderMarket(); renderHighlights(); renderBadges();
        route();
      });
  }

  /* ============================ product cards ============================ */
  function statusLabel(p) {
    if (p.status === "out_of_stock") return "Out of Stock";
    if (p.status === "pre_order") return "Pre-Order";
    return p.stock > 0 && p.stock <= 5 ? "Only " + p.stock + " left" : "Available";
  }
  function orderable(p) { return p.status !== "out_of_stock"; }

  function cardHTML(p) {
    var tags = (p.isFeatured ? '<span class="tag tag-feat">Featured</span>' : "") +
      (p.isBestSeller ? '<span class="tag tag-best">Best Seller</span>' : "") +
      (p.isNewArrival ? '<span class="tag tag-new">New</span>' : "");
    var inWish = wish.indexOf(p.id) >= 0;
    return '<article class="card" data-id="' + p.id + '">' +
      '<div class="card-media" data-action="view"><img src="' + esc(imgSrc(p)) + '" alt="' + esc(p.name) + '" loading="lazy" />' +
      '<div class="card-tags">' + tags + '</div><span class="status status-' + esc(p.status) + '">' + statusLabel(p) + "</span></div>" +
      '<button class="wish-btn' + (inWish ? " on" : "") + '" data-action="wish" aria-label="Wishlist">' + (inWish ? "❤️" : "♡") + "</button>" +
      '<div class="card-body"><div class="card-meta"><span class="model">' + esc(p.modelNumber) + '</span><span class="cat">' + esc(p.category) + "</span></div>" +
      '<h3 data-action="view">' + esc(p.name) + '</h3><p class="desc">' + esc(p.description) + '</p><div class="price">' + bdt(p.price) + "</div>" +
      '<div class="card-actions"><button class="btn btn-ghost" data-action="view">👁 Details</button>' +
      '<button class="btn btn-primary" data-action="order"' + (orderable(p) ? "" : " disabled") + ">⚡ Order Now</button></div>" +
      '<button class="add-cart" data-action="cart"' + (orderable(p) ? "" : " disabled") + ">" + (orderable(p) ? "🛒 Add to Cart" : "Unavailable") + "</button></div></article>";
  }

  // 3D tilt on cards (desktop)
  function attachTilt(root) {
    if (!window.matchMedia("(hover:hover)").matches) return;
    $$(".card", root).forEach(function (card) {
      card.addEventListener("pointermove", function (e) {
        var r = card.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = "perspective(900px) rotateY(" + x * 10 + "deg) rotateX(" + -y * 10 + "deg) translateY(-8px)";
      });
      card.addEventListener("pointerleave", function () { card.style.transform = ""; });
    });
  }

  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-action]");
    if (!btn) return;
    var card = btn.closest("[data-id]");
    if (!card) return;
    var id = Number(card.dataset.id), p = byId[id];
    if (!p) return;
    var a = btn.dataset.action;
    if (a === "view") openProduct(id);
    else if (a === "order") orderNow(id, 1);
    else if (a === "cart") addToCart(id, 1);
    else if (a === "wish") toggleWish(id);
  });

  /* ============================ categories / highlights / market ============================ */
  var filter = { search: "", cat: "All", sort: "featured" };

  function renderCategories() {
    $("#catGrid").innerHTML = CATEGORIES.map(function (c) {
      var n = products.filter(function (p) { return p.category === c.name; }).length;
      return '<button class="cat-card" data-cat="' + esc(c.name) + '"><span class="cat-count">' + n + ' MODELS</span><div class="cat-icon">' + c.icon +
        "</div><h3>" + esc(c.name) + "</h3><p>" + esc(c.desc) + "</p></button>";
    }).join("");
    $$("#catGrid .cat-card").forEach(function (b) {
      b.addEventListener("click", function () {
        filter.cat = b.dataset.cat; renderChips(); renderMarket();
        $("#models").scrollIntoView({ behavior: "smooth" });
      });
    });
  }

  function renderChips() {
    var names = ["All"].concat(CATEGORIES.map(function (c) { return c.name; }));
    products.forEach(function (p) { if (names.indexOf(p.category) < 0) names.push(p.category); });
    $("#catChips").innerHTML = names.map(function (n) {
      return '<button class="chip' + (filter.cat === n ? " active" : "") + '" data-chip="' + esc(n) + '">' + (n === "All" ? "All Models" : esc(n)) + "</button>";
    }).join("");
  }
  $("#catChips").addEventListener("click", function (e) {
    var b = e.target.closest("[data-chip]");
    if (!b) return;
    filter.cat = b.dataset.chip; renderChips(); renderMarket();
  });
  $("#search").addEventListener("input", debounce(function (e) { filter.search = e.target.value.trim().toLowerCase(); renderMarket(); }, 150));
  $("#sort").addEventListener("change", function (e) { filter.sort = e.target.value; renderMarket(); });

  function sortList(list, mode) {
    var l = list.slice();
    var ts = function (p) { return p.createdAt ? new Date(p.createdAt).getTime() : p.id; };
    if (mode === "price-asc") l.sort(function (a, b) { return a.price - b.price; });
    else if (mode === "price-desc") l.sort(function (a, b) { return b.price - a.price; });
    else if (mode === "name") l.sort(function (a, b) { return a.name.localeCompare(b.name); });
    else if (mode === "newest") l.sort(function (a, b) { return ts(b) - ts(a) || b.id - a.id; });
    else l.sort(function (a, b) { return (b.isFeatured - a.isFeatured) || (b.isBestSeller - a.isBestSeller) || b.id - a.id; });
    return l;
  }

  function renderMarket() {
    var q = filter.search;
    var list = products.filter(function (p) {
      if (filter.cat !== "All" && p.category !== filter.cat) return false;
      if (!q) return true;
      return (p.name + " " + p.modelNumber + " " + p.description + " " + p.category + " " + p.colors.join(" ")).toLowerCase().indexOf(q) >= 0;
    });
    list = sortList(list, filter.sort);
    $("#resultMeta").textContent = list.length + " MODEL" + (list.length === 1 ? "" : "S") + " FOUND" + (filter.cat !== "All" ? " · " + filter.cat.toUpperCase() : "");
    $("#productGrid").innerHTML = list.length ? list.map(cardHTML).join("")
      : '<div class="empty" style="grid-column:1/-1">🔍 No models match your search. <button class="btn btn-ghost btn-sm" id="resetFilters" style="margin-left:.6rem">Reset filters</button></div>';
    var reset = $("#resetFilters");
    if (reset) reset.addEventListener("click", function () { filter = { search: "", cat: "All", sort: filter.sort }; $("#search").value = ""; renderChips(); renderMarket(); });
    attachTilt($("#productGrid"));
  }

  var hlMode = "featured";
  function renderHighlights() {
    var list;
    if (hlMode === "best") list = products.filter(function (p) { return p.isBestSeller; });
    else if (hlMode === "recent") list = sortList(products, "newest");
    else list = products.filter(function (p) { return p.isFeatured; });
    $("#highlightGrid").innerHTML = list.slice(0, 4).map(cardHTML).join("") || '<div class="empty" style="grid-column:1/-1">No models yet.</div>';
    attachTilt($("#highlightGrid"));
  }
  $("#highlightTabs").addEventListener("click", function (e) {
    var b = e.target.closest("[data-hl]");
    if (!b) return;
    hlMode = b.dataset.hl;
    $$("#highlightTabs .chip").forEach(function (c) { c.classList.toggle("active", c === b); });
    renderHighlights();
  });

  function refreshCards() { renderMarket(); renderHighlights(); }

  /* ============================ cart & wishlist ============================ */
  function renderBadges() {
    var n = cart.reduce(function (s, c) { return s + c.qty; }, 0);
    $("#cartCount").textContent = n; $("#cartCount").dataset.n = n;
    $("#wishCount").textContent = wish.length; $("#wishCount").dataset.n = wish.length;
  }

  function addToCart(id, qty) {
    var p = byId[id];
    if (!p || !orderable(p)) return;
    var line = cart.filter(function (c) { return c.id === id; })[0];
    if (line) line.qty = Math.min(50, line.qty + qty); else cart.push({ id: id, qty: qty });
    save(CART_KEY, cart); renderBadges(); renderCart();
    toast("🛒 " + p.name + " added to cart");
  }
  function setQty(id, qty) {
    cart = qty <= 0 ? cart.filter(function (c) { return c.id !== id; }) : cart.map(function (c) { return c.id === id ? { id: id, qty: Math.min(50, qty) } : c; });
    save(CART_KEY, cart); renderBadges(); renderCart();
  }
  function toggleWish(id) {
    var on = wish.indexOf(id) >= 0;
    wish = on ? wish.filter(function (x) { return x !== id; }) : [id].concat(wish);
    save(WISH_KEY, wish); renderBadges(); renderWish(); refreshCards();
    if ($("#productPage").classList.contains("open")) updateWishBtn(id);
    toast(on ? "Removed from wishlist" : "❤️ Saved to wishlist");
  }

  function linesTotal(lines) { return lines.reduce(function (s, l) { var p = byId[l.id]; return s + (p ? p.price * l.qty : 0); }, 0); }

  function renderCart() {
    var body = $("#cartBody"), foot = $("#cartFoot");
    if (!cart.length) {
      body.innerHTML = '<div class="empty">Your cart is empty.<br/><br/><a class="btn btn-primary btn-sm" href="#models" data-close>Browse Models</a></div>';
      foot.innerHTML = ""; return;
    }
    body.innerHTML = cart.map(function (c) {
      var p = byId[c.id];
      return '<div class="cart-item" data-cart="' + p.id + '"><img src="' + esc(imgSrc(p)) + '" alt="" /><div><small>' + esc(p.modelNumber) + "</small><h4>" + esc(p.name) + "</h4>" +
        '<div class="ci-row"><div class="qty"><button data-q="-1">−</button><span>' + c.qty + '</span><button data-q="1">+</button></div><b>' + bdt(p.price * c.qty) + "</b></div>" +
        '<button class="remove" data-q="rm">Remove</button></div></div>';
    }).join("");
    var total = linesTotal(cart);
    foot.innerHTML = '<div class="sum-row"><span>Subtotal</span><span>' + bdt(total) + '</span></div><div class="sum-row"><span>Delivery</span><span>FREE</span></div>' +
      '<div class="sum-row total"><span>Total</span><span>' + bdt(total) + "</span></div>" +
      '<button class="btn btn-primary btn-block" id="checkoutBtn" style="margin-top:1rem">Proceed to Checkout →</button>' +
      '<button class="btn btn-ghost btn-block btn-sm" id="clearCart" style="margin-top:.5rem">Clear cart</button>';
    $("#checkoutBtn").addEventListener("click", function () { buyNow = null; openCheckout(); });
    $("#clearCart").addEventListener("click", function () { cart = []; save(CART_KEY, cart); renderBadges(); renderCart(); });
  }
  $("#cartBody").addEventListener("click", function (e) {
    var b = e.target.closest("[data-q]");
    if (!b) return;
    var id = Number(b.closest("[data-cart]").dataset.cart);
    var line = cart.filter(function (c) { return c.id === id; })[0];
    if (!line) return;
    if (b.dataset.q === "rm") setQty(id, 0); else setQty(id, line.qty + Number(b.dataset.q));
  });

  function renderWish() {
    var body = $("#wishBody");
    if (!wish.length) { body.innerHTML = '<div class="empty">Nothing saved yet. Tap ♡ on any model.</div>'; return; }
    body.innerHTML = wish.map(function (id) {
      var p = byId[id];
      return '<div class="cart-item" data-id="' + p.id + '"><img src="' + esc(imgSrc(p)) + '" alt="" /><div><small>' + esc(p.modelNumber) + "</small><h4>" + esc(p.name) + "</h4>" +
        '<div class="ci-row"><b>' + bdt(p.price) + '</b><span style="display:flex;gap:.4rem"><button class="btn btn-ghost btn-sm" data-action="view">View</button>' +
        '<button class="btn btn-primary btn-sm" data-action="cart"' + (orderable(p) ? "" : " disabled") + '>🛒</button></span></div><button class="remove" data-action="wish">Remove</button></div></div>';
    }).join("");
  }

  /* ============================ overlays ============================ */
  var openLayer = null;
  function open(id) {
    closeAll();
    var el = $(id);
    el.classList.add("open");
    $("#overlay").classList.add("open");
    document.body.classList.add("modal-open");
    openLayer = el;
  }
  function closeAll() {
    $$(".drawer.open, .modal.open").forEach(function (m) { m.classList.remove("open"); });
    $("#overlay").classList.remove("open");
    if (!$("#productPage").classList.contains("open")) document.body.classList.remove("modal-open");
    openLayer = null;
  }
  $("#overlay").addEventListener("click", closeAll);
  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-close]")) closeAll();
    var o = e.target.closest("[data-open]");
    if (o) { if (o.dataset.open === "cart") { renderCart(); open("#cartDrawer"); } else { renderWish(); open("#wishDrawer"); } }
    if (e.target.closest(".modal") && e.target.classList.contains("modal")) closeAll();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (openLayer) closeAll();
    else if ($("#productPage").classList.contains("open")) closeProduct();
  });

  /* ============================ product detail page (#/product/ID) ============================ */
  var viewerCalc = null;
  var pvState = { id: null, qty: 1, color: 0 };

  function openProduct(id) { location.hash = "#/product/" + id; }
  function closeProduct() {
    if (history.length > 1 && cameFromSite) history.back(); else location.hash = "#models";
  }
  var cameFromSite = false;

  function route() {
    var m = location.hash.match(/^#\/product\/(\d+)/);
    if (m && byId[Number(m[1])]) { renderProduct(Number(m[1])); return; }
    if ($("#productPage").classList.contains("open")) {
      $("#productPage").classList.remove("open");
      document.body.classList.remove("modal-open");
      if (viewerCalc) { viewerCalc.destroy(); viewerCalc = null; }
      document.title = "CALCORA 3D — Explore The Future of Calculation";
    }
  }
  window.addEventListener("hashchange", function () { cameFromSite = true; route(); });

  function updateWishBtn(id) {
    var b = $("#pvWish");
    if (!b) return;
    var on = wish.indexOf(id) >= 0;
    b.textContent = on ? "❤️ Saved to Wishlist" : "♡ Add to Wishlist";
  }

  function renderProduct(id) {
    var p = byId[id];
    pvState = { id: id, qty: 1, color: 0 };
    var colors = p.colors.length ? p.colors : ["Midnight Black"];
    var accent = /gold/i.test(colors[0]) ? "#f59e0b" : colors.some(function (c) { return /pink|rose/i.test(c); }) ? "#ec4899" : "#8b5cf6";
    var specs = [["Model Number", p.modelNumber], ["Category", p.category], ["Colours", colors.join(", ")],
      ["Availability", statusLabel(p)], ["Stock", p.stock > 0 ? p.stock + " units" : "—"], ["Warranty", "1 year CALCORA warranty"],
      ["Power", "Solar + battery"], ["Delivery", "Free · Cash on delivery"]];

    $("#productPageInner").innerHTML =
      '<div class="crumbs"><button id="pvBack">← Back</button><span>/</span><button data-crumb="models">Marketplace</button><span>/</span><span>' + esc(p.category) + '</span><span>/</span><b style="color:#fff">' + esc(p.name) + "</b></div>" +
      '<div class="pv-grid"><div><div class="viewer" id="viewer"><img class="photo-thumb" id="pvPhoto" src="' + esc(imgSrc(p)) + '" alt="Product photo" />' +
      '<div id="viewerCalc" style="height:100%"></div><div class="viewer-tools"><span class="hint">🖱 Drag to rotate 360° · keys work too</span>' +
      '<button class="btn btn-ghost btn-sm" id="spinBtn">⟳ Auto-spin</button></div></div></div>' +
      "<div>" +
      '<div style="display:flex;flex-wrap:wrap;gap:.45rem"><span class="chip active" style="cursor:default">' + esc(p.category) + '</span><span class="status status-' + esc(p.status) + '" style="position:static">' + statusLabel(p) + "</span>" +
      (p.isBestSeller ? '<span class="tag tag-best" style="align-self:center">Best Seller</span>' : "") + (p.isNewArrival ? '<span class="tag tag-new" style="align-self:center">New</span>' : "") + "</div>" +
      '<h1 class="pv-title">' + esc(p.name) + '</h1><div class="card-meta"><span class="model">MODEL ' + esc(p.modelNumber) + "</span></div>" +
      '<div class="pv-price">' + bdt(p.price) + "<small>BDT · per unit</small></div>" +
      '<p class="pv-desc">' + esc(p.description) + "</p>" +
      '<div class="opt-label">Colour &amp; variation</div><div class="color-opts" id="pvColors">' +
      colors.map(function (c, i) { return '<button class="color-opt' + (i === 0 ? " active" : "") + '" data-ci="' + i + '"><i style="background:' + Calcora3D.colorNameToHex(c) + '"></i>' + esc(c) + "</button>"; }).join("") + "</div>" +
      '<div class="opt-label">Quantity</div><div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap"><div class="qty lg"><button id="pvMinus">−</button><span id="pvQty">1</span><button id="pvPlus">+</button></div><span class="muted" id="pvSub">Subtotal: ' + bdt(p.price) + "</span></div>" +
      '<div class="pv-actions"><button class="btn btn-ghost" id="pvCart"' + (orderable(p) ? "" : " disabled") + '>🛒 Add to Cart</button><button class="btn btn-primary" id="pvOrder"' + (orderable(p) ? "" : " disabled") + ">⚡ Order Now</button></div>" +
      '<button class="btn btn-ghost btn-block" id="pvWish" style="margin-top:.7rem"></button>' +
      '<div class="delivery-note">🚚 Free delivery across Bangladesh · 💵 Cash on delivery · 🛡️ 1-year warranty</div></div></div>' +
      '<div class="spec-grid"><div class="spec-card glass"><h3>✨ Features</h3><ul class="feat-list">' + (p.features.length ? p.features : ["Premium CALCORA build quality"]).map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("") + "</ul></div>" +
      '<div class="spec-card glass"><h3>📋 Specifications</h3><dl class="spec-table">' + specs.map(function (s) { return "<div><dt>" + esc(s[0]) + "</dt><dd>" + esc(s[1]) + "</dd></div>"; }).join("") + "</dl></div></div>" +
      '<div style="margin-top:2.6rem"><h2 style="font-family:var(--font-display);font-size:1.4rem">You may also <span class="text-gradient">like</span></h2><div class="product-grid" id="related" style="margin-top:1.2rem"></div></div>';

    $("#productPage").classList.add("open");
    $("#productPage").scrollTop = 0;
    document.body.classList.add("modal-open");
    document.title = p.name + " (" + p.modelNumber + ") — CALCORA 3D";

    if (viewerCalc) viewerCalc.destroy();
    viewerCalc = Calcora3D.create($("#viewerCalc"), {
      modelLabel: p.modelNumber, bodyColor: Calcora3D.colorNameToHex(colors[0]), accent: accent,
      demoScreen: { expression: p.modelNumber, result: bdt(p.price) }, sway: 0.6, claimKeyboard: true
    });

    var related = products.filter(function (x) { return x.category === p.category && x.id !== p.id; }).slice(0, 4);
    if (related.length < 4) related = related.concat(products.filter(function (x) { return x.id !== p.id && related.indexOf(x) < 0; }).slice(0, 4 - related.length));
    $("#related").innerHTML = related.map(cardHTML).join("");

    updateWishBtn(id);
    var setQ = function (q) {
      pvState.qty = Math.max(1, Math.min(p.stock > 0 ? Math.min(50, p.stock) : 50, q));
      $("#pvQty").textContent = pvState.qty;
      $("#pvSub").textContent = "Subtotal: " + bdt(p.price * pvState.qty);
    };
    $("#pvMinus").onclick = function () { setQ(pvState.qty - 1); };
    $("#pvPlus").onclick = function () { setQ(pvState.qty + 1); };
    $("#pvCart").onclick = function () { addToCart(id, pvState.qty); };
    $("#pvOrder").onclick = function () { orderNow(id, pvState.qty); };
    $("#pvWish").onclick = function () { toggleWish(id); };
    $("#pvBack").onclick = closeProduct;
    $('[data-crumb="models"]').onclick = function () { location.hash = "#models"; };
    $("#pvPhoto").onclick = function () { $("#lightboxImg").src = imgSrc(p); open("#lightbox"); };
    var spinning = false;
    $("#spinBtn").onclick = function () {
      spinning = !spinning;
      viewerCalc.destroy();
      viewerCalc = Calcora3D.create($("#viewerCalc"), {
        modelLabel: p.modelNumber, bodyColor: Calcora3D.colorNameToHex(colors[pvState.color]), accent: accent,
        demoScreen: { expression: p.modelNumber, result: bdt(p.price) }, sway: 0.6, claimKeyboard: true,
        autoSpin: spinning, autoReturn: !spinning
      });
      this.textContent = spinning ? "⏸ Stop spin" : "⟳ Auto-spin";
    };
    $("#pvColors").addEventListener("click", function (e) {
      var b = e.target.closest("[data-ci]");
      if (!b) return;
      pvState.color = Number(b.dataset.ci);
      $$("#pvColors .color-opt").forEach(function (x) { x.classList.toggle("active", x === b); });
      viewerCalc.setTheme(Calcora3D.colorNameToHex(colors[pvState.color]), accent);
    });
  }

  /* ============================ checkout / orders ============================ */
  function orderNow(id, qty) {
    var p = byId[id];
    if (!p || !orderable(p)) return;
    buyNow = [{ id: id, qty: qty }];
    openCheckout();
  }

  function openCheckout() {
    var lines = buyNow || cart;
    if (!lines.length) { toast("Your cart is empty", true); return; }
    var total = linesTotal(lines);
    $("#checkoutContent").innerHTML =
      '<p class="eyebrow">Secure Checkout</p><h2>Place Your Order</h2><p class="muted" style="margin:0">Fill in your details — we deliver anywhere in Bangladesh. Pay cash on delivery.</p>' +
      '<div class="checkout-grid"><form id="orderForm" novalidate><div id="orderError"></div>' +
      '<label class="field"><span>👤 Customer Name *</span><input class="input" name="customerName" required minlength="2" placeholder="e.g. Tanvir Ahmed" autocomplete="name" /></label>' +
      '<label class="field"><span>📞 Phone Number *</span><input class="input" name="phone" required inputmode="tel" placeholder="e.g. 01712345678" autocomplete="tel" /></label>' +
      '<label class="field"><span>📍 Delivery Address *</span><textarea class="input" name="address" required placeholder="House, road, area, district…" autocomplete="street-address"></textarea></label>' +
      '<label class="field"><span>💬 Additional Message <em class="muted" style="font-weight:400">(optional)</em></span><textarea class="input" name="message" placeholder="Preferred colour, delivery time, gift wrap…"></textarea></label>' +
      '<button class="btn btn-primary btn-block" type="submit" id="placeBtn">Place Order · ' + bdt(total) + "</button>" +
      '<p class="muted" style="font-size:.78rem;text-align:center;margin:.7rem 0 0">You will receive a tracking number instantly.</p></form>' +
      '<div class="summary-box"><h4 style="margin:0 0 .9rem;font-family:var(--font-display);letter-spacing:.08em">Selected Model' + (lines.length > 1 ? "s" : "") + "</h4>" +
      lines.map(function (l) { var p = byId[l.id]; return '<div class="summary-item"><img src="' + esc(imgSrc(p)) + '" alt="" /><div><b>' + esc(p.name) + '</b><br/><small class="muted">' + esc(p.modelNumber) + " · Qty " + l.qty + " × " + bdt(p.price) + "</small></div><b>" + bdt(p.price * l.qty) + "</b></div>"; }).join("") +
      '<div class="sum-row"><span>Quantity</span><span>' + lines.reduce(function (s, l) { return s + l.qty; }, 0) + ' pcs</span></div><div class="sum-row"><span>Delivery</span><span>FREE</span></div>' +
      '<div class="sum-row total"><span>Total Price</span><span>' + bdt(total) + "</span></div></div></div>";
    open("#checkoutModal");
    $("#orderForm").addEventListener("submit", submitOrder);
  }

  function submitOrder(e) {
    e.preventDefault();
    var f = e.target, lines = buyNow || cart;
    var data = { customerName: f.customerName.value.trim(), phone: f.phone.value.trim(), address: f.address.value.trim(), message: f.message.value.trim() };
    var err = "";
    if (data.customerName.length < 2) err = "Please enter your full name.";
    else if (!/^[+0-9\s-]{8,16}$/.test(data.phone)) err = "Please enter a valid phone number (e.g. 01712345678).";
    else if (data.address.length < 5) err = "Please enter your full delivery address.";
    if (err) { $("#orderError").innerHTML = '<p class="form-error">' + esc(err) + "</p>"; return; }

    var btn = $("#placeBtn");
    btn.disabled = true; btn.textContent = "Placing order…";
    var items = lines.map(function (l) { var p = byId[l.id]; return { productId: p.id, name: p.name, price: p.price, quantity: l.qty }; });

    api("/api/orders", { method: "POST", body: { customerName: data.customerName, phone: data.phone, address: data.address, message: data.message, items: items } })
      .then(function (d) { return d.order; })
      .catch(function (ex) {
        if (ex.server) throw ex;
        // offline demo: store order locally
        var code = "CLR-" + Math.random().toString(36).slice(2, 10).toUpperCase();
        var o = { id: Date.now(), trackingNumber: code, customerName: data.customerName, phone: data.phone, address: data.address, message: data.message,
          totalPrice: linesTotal(lines), status: "pending", createdAt: new Date().toISOString(), offline: true,
          items: items.map(function (i) { return { productName: i.name, quantity: i.quantity, price: i.price }; }) };
        var local = load(LOCAL_ORDERS_KEY, []); local.unshift(o); save(LOCAL_ORDERS_KEY, local);
        return o;
      })
      .then(function (order) {
        var mine = load(ORDERS_KEY, []);
        mine.unshift({ trackingNumber: order.trackingNumber, phone: order.phone, total: order.totalPrice, createdAt: order.createdAt, status: order.status });
        save(ORDERS_KEY, mine.slice(0, 30));
        if (!buyNow) { cart = []; save(CART_KEY, cart); renderBadges(); }
        buyNow = null;
        showSuccess(order);
        renderMyOrders();
        if (ONLINE) loadProducts();
      })
      .catch(function (ex) {
        btn.disabled = false; btn.textContent = "Place Order";
        $("#orderError").innerHTML = '<p class="form-error">' + esc(ex.message || "Order failed") + "</p>";
      });
  }

  function showSuccess(o) {
    $("#checkoutContent").innerHTML =
      '<div class="success"><div class="big-check">✓</div><h2 style="margin-top:1rem">Order Confirmed!</h2>' +
      '<p class="muted">Thank you, <b style="color:#fff">' + esc(o.customerName) + "</b>. Your order has been received" + (o.offline ? " (saved on this device)" : "") + ".</p>" +
      '<div class="trk-box"><small>TRACKING NUMBER</small><b>' + esc(o.trackingNumber) + '</b><button class="btn btn-ghost btn-sm" id="copyTrk" style="margin-top:.6rem">📋 Copy</button></div>' +
      '<div class="order-box" style="max-width:460px;margin:0 auto;text-align:left">' +
      (o.items || []).map(function (i) { return '<div class="line"><span>' + esc(i.productName || i.name) + " × " + i.quantity + "</span><span>" + bdt(i.price * i.quantity) + "</span></div>"; }).join("") +
      '<div class="line total"><span>Total</span><span>' + bdt(o.totalPrice) + "</span></div></div>" +
      '<div class="hero-cta" style="justify-content:center"><button class="btn btn-primary" id="trackNow">📦 Track This Order</button><button class="btn btn-ghost" data-close>Continue Shopping</button></div></div>';
    $("#copyTrk").onclick = function () { (navigator.clipboard ? navigator.clipboard.writeText(o.trackingNumber) : Promise.reject()).then(function () { toast("Tracking number copied"); }, function () { toast(o.trackingNumber); }); };
    $("#trackNow").onclick = function () { closeAll(); setTrackMode("tracking"); $("#trackInput").value = o.trackingNumber; runTrack(); $("#track").scrollIntoView({ behavior: "smooth" }); };
  }

  /* ============================ tracking & history ============================ */
  var trackMode = "tracking";
  var FLOW = ["pending", "confirmed", "shipped", "delivered"];
  function setTrackMode(m) {
    trackMode = m;
    $$("#trackSeg button").forEach(function (b) { b.classList.toggle("active", b.dataset.mode === m); });
    $("#trackInput").placeholder = m === "tracking" ? "e.g. CLR-AB12CD34" : "e.g. 01712345678";
    $("#trackInput").inputMode = m === "tracking" ? "text" : "tel";
  }
  $("#trackSeg").addEventListener("click", function (e) { var b = e.target.closest("[data-mode]"); if (b) setTrackMode(b.dataset.mode); });
  $("#trackForm").addEventListener("submit", function (e) { e.preventDefault(); runTrack(); });

  function orderCard(o) {
    var stepper = o.status === "cancelled" ? '<span class="step cancel">✕ Order Cancelled</span>'
      : FLOW.map(function (s, i) { return '<span class="step' + (i <= FLOW.indexOf(o.status) ? " done" : "") + '">' + (i <= FLOW.indexOf(o.status) ? "✓ " : "") + s.charAt(0).toUpperCase() + s.slice(1) + "</span>"; }).join('<span class="step-line"></span>');
    var items = (o.items || []).map(function (i) { return '<div class="line"><span>' + esc(i.productName) + " × " + i.quantity + "</span><span>" + bdt(i.price * i.quantity) + "</span></div>"; }).join("");
    return '<div class="order-card glass-strong"><div class="order-head"><div><small>TRACKING</small><div class="trk">' + esc(o.trackingNumber) + "</div></div><small>Placed " + fmtDate(o.createdAt) + "</small></div>" +
      '<div class="stepper">' + stepper + '</div><div class="order-grid"><div class="order-box"><h4>Items</h4>' + (items || '<span class="muted">—</span>') +
      '<div class="line total"><span>Total</span><span>' + bdt(o.totalPrice) + '</span></div></div><div class="order-box"><h4>Delivery</h4><b>' + esc(o.customerName) + '</b><br/><span class="muted">' + esc(o.phone) + "<br/>" + esc(o.address) + "</span>" +
      (o.message ? '<br/><em class="muted">“' + esc(o.message) + "”</em>" : "") + "</div></div></div>";
  }

  function runTrack() {
    var q = $("#trackInput").value.trim();
    var out = $("#trackResults");
    if (!q) { toast("Enter a " + (trackMode === "tracking" ? "tracking" : "phone") + " number", true); return; }
    out.innerHTML = '<div class="skeleton" style="height:180px"></div>';
    var url = "/api/orders?" + (trackMode === "tracking" ? "tracking=" : "phone=") + encodeURIComponent(q);
    api(url).then(function (d) { return d.orders || []; }).catch(function (ex) {
      if (ex.server) throw ex;
      var local = load(LOCAL_ORDERS_KEY, []);
      return local.filter(function (o) { return trackMode === "tracking" ? o.trackingNumber === q.toUpperCase() : o.phone === q; });
    }).then(function (list) {
      out.innerHTML = list.length ? list.map(orderCard).join("")
        : '<div class="empty glass">📭 No orders found for <b>' + esc(q) + "</b>. Check the number and try again.</div>";
    }).catch(function (ex) { out.innerHTML = '<p class="form-error">' + esc(ex.message) + "</p>"; });
  }

  function renderMyOrders() {
    var mine = load(ORDERS_KEY, []);
    var wrap = $("#myOrdersWrap");
    if (!mine.length) { wrap.innerHTML = ""; return; }
    wrap.innerHTML = '<div class="side-card glass"><h3>🧾 My Order History <small class="muted" style="font-family:var(--font-body);letter-spacing:0">(this device)</small></h3>' +
      mine.map(function (o) {
        return '<div class="line" style="align-items:center;border-bottom:1px solid rgba(255,255,255,.06);padding:.6rem 0"><span><b style="font-family:Courier New,monospace">' + esc(o.trackingNumber) + "</b><br/><small class=\"muted\">" + fmtDate(o.createdAt) + " · " + bdt(o.total) + "</small></span>" +
          '<button class="btn btn-ghost btn-sm" data-trk="' + esc(o.trackingNumber) + '">Track</button></div>';
      }).join("") + "</div>";
  }
  $("#myOrdersWrap").addEventListener("click", function (e) {
    var b = e.target.closest("[data-trk]");
    if (!b) return;
    setTrackMode("tracking"); $("#trackInput").value = b.dataset.trk; runTrack();
    $("#trackResults").scrollIntoView({ behavior: "smooth", block: "start" });
  });

  /* ============================ calculators ============================ */
  var DEMO = ["√(", "2", ")", "÷", "2", "+", "√(", "3", ")", "÷", "3"];
  Calcora3D.create($("#heroCalc"), { intro: true, initialTokens: DEMO, sway: 1, startAngle: 0 });

  var SWATCHES = [
    { name: "Midnight Black", hex: "#1c1d22", accent: "#8b5cf6" },
    { name: "Blossom Pink", hex: "#f2c4cf", accent: "#ec4899" },
    { name: "Arctic White", hex: "#e8eaef", accent: "#38bdf8" },
    { name: "Nebula Purple", hex: "#3a1d6b", accent: "#c084fc" },
    { name: "Ocean Blue", hex: "#1d3766", accent: "#22d3ee" }
  ];
  var mainCalc = Calcora3D.create($("#mainCalc"), { sway: 0.35, claimKeyboard: true });
  $("#colorPicker").innerHTML = SWATCHES.map(function (s, i) {
    return '<button class="swatch' + (i === 0 ? " active" : "") + '" data-sw="' + i + '" title="' + s.name + '" aria-label="' + s.name + '" style="background:' + s.hex + '"></button>';
  }).join("") + '<span class="swatch-name" id="swatchName">' + SWATCHES[0].name + "</span>";
  $("#colorPicker").addEventListener("click", function (e) {
    var b = e.target.closest("[data-sw]");
    if (!b) return;
    var s = SWATCHES[Number(b.dataset.sw)];
    mainCalc.setTheme(s.hex, s.accent);
    $$("#colorPicker .swatch").forEach(function (x) { x.classList.toggle("active", x === b); });
    $("#swatchName").textContent = s.name;
  });

  var EXAMPLES = [
    ["sin(30)", ["sin(", "3", "0", ")"]], ["√2÷2+√3÷3", DEMO], ["2^(10)", ["2", "^(", "1", "0", ")"]],
    ["log(1000)", ["log(", "1", "0", "0", "0", ")"]], ["5!", ["5", "!"]], ["2π", ["2", "π"]],
    ["0.75 → S⇔D", ["0", ".", "7", "5"], true], ["15% of 2400", ["2", "4", "0", "0", "×", "1", "5", "%"]]
  ];
  $("#examples").innerHTML = EXAMPLES.map(function (x, i) { return '<span role="button" tabindex="0" data-ex="' + i + '" style="cursor:pointer">' + esc(x[0]) + "</span>"; }).join("");
  $("#examples").addEventListener("click", function (e) {
    var b = e.target.closest("[data-ex]");
    if (!b) return;
    var ex = EXAMPLES[Number(b.dataset.ex)];
    mainCalc.dispatch({ type: "ac" });
    ex[1].forEach(function (t) { mainCalc.dispatch({ type: "insert", token: t }); });
    mainCalc.dispatch({ type: "exe" });
    if (ex[2]) setTimeout(function () { mainCalc.dispatch({ type: "format" }); }, 350);
  });

  function renderHistory(list) {
    $("#historyList").innerHTML = list.length ? list.map(function (h, i) {
      return '<button class="history-item" data-h="' + i + '"><small>' + esc(h.expr) + "</small><b>= " + esc(h.result) + "</b></button>";
    }).join("") : '<div class="empty">No calculations yet — try sin(30) or √2÷2!</div>';
  }
  renderHistory(Calcora3D.getHistory());
  Calcora3D.onHistory(renderHistory);
  $("#historyList").addEventListener("click", function (e) {
    var b = e.target.closest("[data-h]");
    if (b) mainCalc.dispatch({ type: "recall", index: Number(b.dataset.h) });
  });
  $("#clearHistory").addEventListener("click", function () { Calcora3D.clearHistory(); toast("History cleared"); });

  var soundBtn = $("#soundBtn");
  var paintSound = function () { soundBtn.textContent = Calcora3D.isSoundOn() ? "🔊" : "🔇"; };
  paintSound();
  soundBtn.addEventListener("click", function () { Calcora3D.setSound(!Calcora3D.isSoundOn()); paintSound(); toast(Calcora3D.isSoundOn() ? "Sound on" : "Sound off"); });
  $("#soundMenu").addEventListener("click", function (e) { e.preventDefault(); soundBtn.click(); });

  /* ============================ legal ============================ */
  var LEGAL = {
    about: ["About CALCORA 3D", [["Our Story", "CALCORA 3D was founded in Dhaka with one mission: make calculation beautiful. We design premium futuristic calculators — from everyday standards to ClassWiz-style scientific models and numbered special editions."], ["What we believe", "Great tools make great thinkers. Every CALCORA device is tested for exam-grade accuracy, long battery life and a key feel you will love."]]],
    privacy: ["Privacy Policy", [["What we collect", "When you place an order we store your name, phone number, delivery address and order details (model, quantity, total in BDT). Your calculator history, cart and wishlist stay only in your own browser."], ["How we use it", "Order details are used only to process, deliver and track your order and to provide support via phone, Facebook or WhatsApp. We never sell your data."], ["Security", "Admin access is protected with hashed passwords and signed, http-only session cookies. Prices are always verified on the server."]]],
    terms: ["Terms & Conditions", [["Orders", "All prices are in Bangladeshi Taka (৳). Each order receives a unique tracking number. Cash on delivery is available nationwide."], ["Pricing", "Prices may change without notice; the price shown at checkout is the price you pay."], ["Warranty", "Every model includes a 1-year CALCORA warranty. Dead-on-arrival units are replaced free within 7 days."]]],
    shipping: ["Shipping & Returns", [["Delivery", "Free delivery across Bangladesh. Inside Dhaka 1–3 working days, outside Dhaka 3–5 working days."], ["Returns", "Unused products in original packaging can be returned within 7 days. Contact support on WhatsApp to start a return."]]]
  };
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-legal]");
    if (!b) return;
    var L = LEGAL[b.dataset.legal];
    $("#legalContent").innerHTML = '<p class="eyebrow">CALCORA 3D</p><h2>' + esc(L[0]) + "</h2>" + L[1].map(function (s) { return "<h3>" + esc(s[0]) + "</h3><p>" + esc(s[1]) + "</p>"; }).join("") +
      '<p style="margin-top:1.4rem" class="muted">Questions? support@calcora3d.com · +880 1700-000000</p>';
    open("#legalModal");
  });

  /* ============================ navbar & reveal ============================ */
  var nav = $("#navbar");
  var onScroll = function () { nav.classList.toggle("scrolled", window.scrollY > 20); };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  $("#menuBtn").addEventListener("click", function () { $("#mobileMenu").classList.toggle("open"); });
  $$("#mobileMenu a").forEach(function (a) { a.addEventListener("click", function () { $("#mobileMenu").classList.remove("open"); }); });

  if ("IntersectionObserver" in window) {
    var revealObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("in"); revealObs.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -60px 0px" });
    $$(".reveal").forEach(function (el) { revealObs.observe(el); });
    var links = $$(".nav-links a[href^='#']");
    var secObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        links.forEach(function (a) { a.classList.toggle("active", a.getAttribute("href") === "#" + en.target.id); });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    ["home", "calculator", "models", "track"].forEach(function (id) { var s = document.getElementById(id); if (s) secObs.observe(s); });
  } else {
    $$(".reveal").forEach(function (el) { el.classList.add("in"); });
  }

  $("#year").textContent = new Date().getFullYear();
  renderBadges();
  renderMyOrders();
  loadProducts();
})();
