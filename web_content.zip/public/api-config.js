// For an HTML-to-APK build, set this to your deployed StudyHub backend URL.
// Example: https://your-studyhub-backend.example.com
// Keep it empty when the frontend and backend are served from the same server.
window.STUDYHUB_API_BASE = "";
