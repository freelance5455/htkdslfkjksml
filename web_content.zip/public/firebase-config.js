// Replace these values with your Firebase Web App configuration.
// Firebase Console > Project settings > Your apps > Web app.
export const firebaseConfig = {
  apiKey: "REPLACE_ME",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};