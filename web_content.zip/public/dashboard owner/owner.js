async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/login.html';
}

async function loadServerInfo() {
  try {
    const res = await fetch('/api/server-info');
    if (res.status === 403) { window.location.href = '/login.html'; return; }
    const data = await res.json();
    document.getElementById('serverInfo').innerHTML = `
      <div><span>Hostname</span><span>${data.hostname}</span></div>
      <div><span>Platform</span><span>${data.platform}</span></div>
      <div><span>Port</span><span>${data.port}</span></div>
      <div><span>Uptime</span><span>${Math.floor(data.uptime)}s</span></div>
      <div><span>RAM Total</span><span>${data.memory.total}</span></div>
      <div><span>RAM Free</span><span>${data.memory.free}</span></div>
    `;
    const ipList = document.getElementById('ipList');
    if (data.addresses.length === 0) {
      ipList.innerHTML = '<p style="color:#888">Tidak ada koneksi jaringan</p>';
    } else {
      ipList.innerHTML = data.addresses.map(a => `
        <div class="ip-item" onclick="copyIP('http://${a.ip}:${data.port}')">
          🌐 http://${a.ip}:${data.port}
          <span class="iface">${a.interface}</span>
        </div>
      `).join('');
    }
    document.getElementById('photoCount').textContent = data.totalPhotos;
    document.getElementById('userCount').textContent = data.totalUsers;
  } catch (err) { console.error(err); }
}

function copyIP(text) {
  navigator.clipboard.writeText(text);
  alert('✅ Alamat disalin:\n' + text);
}

async function loadUsers() {
  const res = await fetch('/api/users');
  if (!res.ok) return;
  const users = await res.json();
  const tbody = document.getElementById('userTableBody');
  tbody.innerHTML = users.map(u => `
    <tr>
      <td>${u.id}</td>
      <td><strong>${u.username}</strong></td>
      <td><span class="badge badge-${u.role}">${u.role === 'owner' ? '👑 Owner' : '👤 Member'}</span></td>
      <td>${new Date(u.createdAt).toLocaleString('id-ID')}</td>
      <td>
        ${u.role === 'owner'
          ? '<span style="color:#666; font-size:12px;">—</span>'
          : `<button onclick="deleteUser(${u.id})" class="btn-delete">🗑️ Hapus</button>`}
      </td>
    </tr>
  `).join('');
}

function toggleAddUser() {
  const f = document.getElementById('addUserForm');
  f.style.display = f.style.display === 'none' ? 'flex' : 'none';
}

async function addUser() {
  const username = document.getElementById('newUsername').value.trim();
  const password = document.getElementById('newPassword').value;
  const role = document.getElementById('newRole').value;

  if (!username || !password) return alert('❌ Isi semua field!');
  if (username.length < 3) return alert('❌ Username minimal 3 karakter');
  if (password.length < 6) return alert('❌ Password minimal 6 karakter');
  if (!/^[a-zA-Z0-9_]+$/.test(username)) return alert('❌ Username hanya huruf, angka, underscore');

  const res = await fetch('/api/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, role })
  });
  const data = await res.json();

  if (data.success) {
    alert(`✅ Akun dibuat!\n\n👤 Username: ${username}\n🔒 Password: ${password}\n🎭 Role: ${role}\n\nBerikan info ini ke user.`);
    document.getElementById('newUsername').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('newRole').value = 'member';
    toggleAddUser();
    loadUsers();
    loadServerInfo();
  } else alert('❌ ' + data.error);
}

async function deleteUser(id) {
  if (!confirm('⚠️ Hapus user ini beserta SEMUA fotonya?')) return;
  const res = await fetch('/api/users/' + id, { method: 'DELETE' });
  const data = await res.json();
  if (data.success) {
    alert('✅ User dihapus');
    loadUsers(); loadPhotos(); loadServerInfo();
  } else alert('❌ ' + data.error);
}

async function loadPhotos() {
  const res = await fetch('/api/all-photos');
  if (!res.ok) return;
  const photos = await res.json();
  const gallery = document.getElementById('gallery');
  if (photos.length === 0) { gallery.innerHTML = '<p style="color:#888">Belum ada foto</p>'; return; }
  gallery.innerHTML = photos.map(p => `
    <div class="gallery-item">
      <img src="${p.url}" alt="${p.filename}">
      <div class="photo-meta">
        <span>👤 ${p.ownerName}</span>
        <small>${new Date(p.uploadedAt).toLocaleString('id-ID')}</small>
      </div>
      <button class="delete-btn" onclick="deletePhoto(${p.id})">✕</button>
    </div>
  `).join('');
}

async function deletePhoto(id) {
  if (!confirm('Hapus foto ini?')) return;
  await fetch('/api/photos/' + id, { method: 'DELETE' });
  loadPhotos(); loadServerInfo();
}

loadServerInfo(); loadUsers(); loadPhotos();
setInterval(loadServerInfo, 10000);