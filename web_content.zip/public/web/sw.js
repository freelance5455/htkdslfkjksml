/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "43609903e4db8fc23bc9ba1f15bff0fb"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4c4d936abb64dfa9e113fd1044f46b3f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3220028c24160a3447f6f0d901a4bfe9"
  }, {
    "url": "index.html",
    "revision": "1ad67e868d8bc391cd017c04bb06fc69"
  }, {
    "url": "icon.svg",
    "revision": "a3833bb405ed0fc768d3d1e7d60f04d7"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "a51e2de7f83e4bb634997b01aa020bfb"
  }, {
    "url": "assets/index-DCljFKhf.js",
    "revision": null
  }, {
    "url": "assets/index-CI3jU-Hr.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "a51e2de7f83e4bb634997b01aa020bfb"
  }, {
    "url": "icon.svg",
    "revision": "a3833bb405ed0fc768d3d1e7d60f04d7"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3220028c24160a3447f6f0d901a4bfe9"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4c4d936abb64dfa9e113fd1044f46b3f"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "43609903e4db8fc23bc9ba1f15bff0fb"
  }, {
    "url": "manifest.webmanifest",
    "revision": "60497375169aa3e0ddbfb2c060304f3f"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
