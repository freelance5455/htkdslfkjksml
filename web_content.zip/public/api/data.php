<?php
require_once __DIR__.'/../../src/api.php';
api_auth();
$act=$_GET['action']??'';
try {
 switch($act){
  case 'customers':
   out(db()->query('SELECT c.full_name,c.username,c.phone,c.service_type,c.status,p.name package FROM customers c LEFT JOIN packages p ON p.id=c.package_id ORDER BY c.id DESC LIMIT 500')->fetchAll());
  case 'summary':
   $r=router();
   $id=$r->query(new \RouterOS\Query('/system/identity/print'))->read();
   $res=$r->query(new \RouterOS\Query('/system/resource/print'))->read();
   $hs=$r->query(new \RouterOS\Query('/ip/hotspot/active/print'))->read();
   $pp=$r->query(new \RouterOS\Query('/ppp/active/print'))->read();
   out(['identity'=>$id[0]['name']??'','resource'=>$res[0]??[],'hotspot_active'=>count($hs),'pppoe_active'=>count($pp),
        'customers'=>(int)db()->query('SELECT COUNT(*) FROM customers')->fetchColumn()]);
  case 'hotspot':
   out(array_map(fn($x)=>['user'=>$x['user']??'','address'=>$x['address']??'','uptime'=>$x['uptime']??'','bytes_in'=>$x['bytes-in']??'0','bytes_out'=>$x['bytes-out']??'0'],
     router()->query(new \RouterOS\Query('/ip/hotspot/active/print'))->read()));
  case 'pppoe':
   out(array_map(fn($x)=>['user'=>$x['name']??'','address'=>$x['address']??'','uptime'=>$x['uptime']??'','service'=>$x['service']??''],
     router()->query(new \RouterOS\Query('/ppp/active/print'))->read()));
  default: out(['error'=>'unknown_action'],400);
 }
} catch(Throwable $e){ out(['error'=>'router_unreachable'],502); }
