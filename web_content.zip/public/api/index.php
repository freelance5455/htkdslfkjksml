<?php
declare(strict_types=1);
require_once __DIR__.'/../../src/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function out(array $d, int $c = 200): never { http_response_code($c); echo json_encode($d, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function fail(string $m, int $c = 400): never { out(['error'=>$m], $c); }
function body(): array { static $b = null; if ($b === null) { $j = json_decode((string)file_get_contents('php://input'), true); $b = is_array($j) ? $j : []; } return $b; }
function need_auth(): void { if (empty($_SESSION['admin_id'])) fail('لومړی ننوځئ', 401); }
function need_csrf(): void { if (!hash_equals(csrf(), (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) fail('غوښتنه ناسمه ده، اپ بیا پرانیزئ', 419); }
function s(mixed $v, int $max = 255): string { return mb_substr(trim((string)$v), 0, $max); }

// Effective status: expiry is evaluated live so no cron job is needed for display.
const EFF = "CASE WHEN c.status='suspended' THEN 'suspended' WHEN c.status='expired' OR (c.expires_at IS NOT NULL AND c.expires_at < NOW()) THEN 'expired' ELSE 'active' END";

$route = (string)($_GET['r'] ?? '');
$method = $_SERVER['REQUEST_METHOD'];

if ($route === 'session') {
    out(['auth'=>!empty($_SESSION['admin_id']), 'csrf'=>csrf(), 'app'=>envv('APP_NAME','Ahmadi WiFi')]);
}
if ($method !== 'GET') need_csrf();

try {
    $pdo = db();

    switch ($route) {
    case 'login':
        if ($method !== 'POST') fail('Method not allowed', 405);
        $b = body();
        $q = $pdo->prepare('SELECT id,password_hash FROM admins WHERE email=?');
        $q->execute([s($b['email'] ?? '', 190)]);
        $a = $q->fetch();
        if ($a && password_verify((string)($b['password'] ?? ''), $a['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $a['id'];
            out(['ok'=>true, 'csrf'=>csrf()]);
        }
        usleep(500000); // slow down password guessing
        fail('ایمیل یا پاسورډ ناسم دی', 401);

    case 'logout':
        $_SESSION = [];
        session_destroy();
        out(['ok'=>true]);

    case 'dashboard':
        need_auth();
        $c = $pdo->query("SELECT COUNT(*) total,
            COALESCE(SUM(e='active'),0) active, COALESCE(SUM(e='expired'),0) expired, COALESCE(SUM(e='suspended'),0) suspended
            FROM (SELECT ".EFF." AS e FROM customers c) t")->fetch();
        $soon = (int)$pdo->query("SELECT COUNT(*) FROM customers WHERE status='active' AND expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)")->fetchColumn();
        $today = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(paid_at)=CURDATE()")->fetchColumn();
        $month = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE YEAR(paid_at)=YEAR(CURDATE()) AND MONTH(paid_at)=MONTH(CURDATE())")->fetchColumn();
        $recent = $pdo->query("SELECT p.id,p.amount,p.paid_at,c.full_name FROM payments p JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC LIMIT 5")->fetchAll();
        out(['total'=>(int)$c['total'],'active'=>(int)$c['active'],'expired'=>(int)$c['expired'],'suspended'=>(int)$c['suspended'],
             'expiring_soon'=>$soon,'revenue_today'=>$today,'revenue_month'=>$month,'recent'=>$recent]);

    case 'customers':
        need_auth();
        $sql = "SELECT c.id,c.full_name,c.phone,c.username,c.service_type,c.package_id,c.expires_at,".EFF." AS status,p.name AS package_name,p.price AS package_price
                FROM customers c LEFT JOIN packages p ON p.id=c.package_id WHERE 1=1";
        $args = [];
        $qs = s($_GET['q'] ?? '', 100);
        if ($qs !== '') {
            $like = '%'.str_replace(['\\','%','_'], ['\\\\','\\%','\\_'], $qs).'%';
            $sql .= " AND (c.full_name LIKE ? OR c.username LIKE ? OR c.phone LIKE ?)";
            array_push($args, $like, $like, $like);
        }
        $st = s($_GET['status'] ?? '', 20);
        if (in_array($st, ['active','expired','suspended'], true)) { $sql .= " AND ".EFF." = ?"; $args[] = $st; }
        $sql .= " ORDER BY c.id DESC LIMIT 200";
        $q = $pdo->prepare($sql); $q->execute($args);
        out(['items'=>$q->fetchAll()]);

    case 'customer_create':
        need_auth();
        $b = body();
        $name = s($b['full_name'] ?? '', 160); $user = s($b['username'] ?? '', 100);
        $type = (string)($b['service_type'] ?? '');
        if ($name === '') fail('نوم ولیکئ');
        if (!preg_match('/^[A-Za-z0-9._@-]{2,100}$/', $user)) fail('Username باید یوازې انګلیسي توري/عددونه ولري');
        if (!in_array($type, ['hotspot','pppoe'], true)) fail('د خدمت ډول ناسم دی');
        $pid = (int)($b['package_id'] ?? 0) ?: null;
        if ($pid !== null) { $c = $pdo->prepare('SELECT COUNT(*) FROM packages WHERE id=?'); $c->execute([$pid]); if (!$c->fetchColumn()) fail('پکیج ونه موندل شو'); }
        try {
            $pdo->prepare('INSERT INTO customers(full_name,phone,username,service_type,package_id) VALUES(?,?,?,?,?)')
                ->execute([$name, s($b['phone'] ?? '', 40) ?: null, $user, $type, $pid]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') fail('دا Username مخکې ثبت دی', 409);
            throw $e;
        }
        out(['ok'=>true, 'id'=>(int)$pdo->lastInsertId()], 201);

    case 'customer_status':
        need_auth();
        $b = body();
        $st = (string)($b['status'] ?? '');
        if (!in_array($st, ['active','suspended'], true)) fail('حالت ناسم دی');
        $pdo->prepare('UPDATE customers SET status=? WHERE id=?')->execute([$st, (int)($b['id'] ?? 0)]);
        out(['ok'=>true]);

    case 'packages':
        need_auth();
        out(['items'=>$pdo->query('SELECT id,name,service_type,price,validity_days,speed_down_kbps,speed_up_kbps,active FROM packages ORDER BY id DESC')->fetchAll()]);

    case 'package_create':
        need_auth();
        $b = body();
        $name = s($b['name'] ?? '', 120);
        $type = (string)($b['service_type'] ?? 'both');
        $price = (float)($b['price'] ?? 0); $days = (int)($b['validity_days'] ?? 30);
        if ($name === '') fail('د پکیج نوم ولیکئ');
        if (!in_array($type, ['hotspot','pppoe','both'], true)) fail('ډول ناسم دی');
        if ($price < 0 || $price > 1e9) fail('بیه ناسمه ده');
        if ($days < 1 || $days > 3650) fail('ورځې ناسمې دي');
        $pdo->prepare('INSERT INTO packages(name,service_type,price,validity_days,speed_down_kbps,speed_up_kbps) VALUES(?,?,?,?,?,?)')
            ->execute([$name, $type, $price, $days, max(0,(int)($b['speed_down_kbps'] ?? 0)) ?: null, max(0,(int)($b['speed_up_kbps'] ?? 0)) ?: null]);
        out(['ok'=>true], 201);

    case 'payments':
        need_auth();
        out(['items'=>$pdo->query('SELECT p.id,p.amount,p.note,p.paid_at,c.full_name,c.username FROM payments p JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC LIMIT 100')->fetchAll()]);

    case 'payment_create':
        need_auth();
        $b = body();
        $cid = (int)($b['customer_id'] ?? 0); $amt = round((float)($b['amount'] ?? 0), 2);
        if ($amt <= 0 || $amt > 1e9) fail('مبلغ ناسم دی');
        $pdo->beginTransaction();
        try {
            $q = $pdo->prepare('SELECT c.id,p.validity_days FROM customers c LEFT JOIN packages p ON p.id=c.package_id WHERE c.id=? FOR UPDATE');
            $q->execute([$cid]);
            $c = $q->fetch();
            if (!$c) { $pdo->rollBack(); fail('مشتری ونه موندل شو', 404); }
            $renew = !empty($b['renew']);
            if ($renew && !$c['validity_days']) { $pdo->rollBack(); fail('دې مشتری ته پکیج نه دی ټاکل شوی'); }
            $pdo->prepare('INSERT INTO payments(customer_id,amount,note) VALUES(?,?,?)')->execute([$cid, $amt, s($b['note'] ?? '') ?: null]);
            if ($renew) {
                $pdo->prepare("UPDATE customers SET expires_at=DATE_ADD(GREATEST(COALESCE(expires_at,NOW()),NOW()), INTERVAL ? DAY), status='active' WHERE id=?")
                    ->execute([(int)$c['validity_days'], $cid]);
            }
            $pdo->commit();
        } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        out(['ok'=>true], 201);

    default:
        fail('Not found', 404);
    }
} catch (Throwable $e) {
    error_log('API error: '.$e->getMessage());
    fail('د سرور تېروتنه', 500);
}
