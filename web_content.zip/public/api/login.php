<?php
require_once __DIR__.'/../../src/api.php';
$in=json_decode(file_get_contents('php://input'),true)?:[];
$q=db()->prepare('SELECT id,password_hash FROM admins WHERE email=?'); $q->execute([trim($in['email']??'')]);
$a=$q->fetch();
if(!$a||!password_verify($in['password']??'',$a['password_hash'])){ sleep(1); out(['error'=>'invalid_credentials'],401); }
out(['token'=>make_token((int)$a['id'])]);
