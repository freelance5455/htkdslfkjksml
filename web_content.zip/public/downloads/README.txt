GODS OF WAR — TITAN ARENA
=========================
Local two-player 3D fighting game. Three.js + React. Fully offline.

PACKAGE CONTENTS
----------------
index.html          The complete game. Single self-contained file: JS, CSS,
                    Three.js and all generated textures are inlined. No network
                    requests, no CDN, no external fonts, images or audio.
README.txt          This file.
source/             Original TypeScript source (src/, index.html, package.json,
                    vite.config.ts) for rebuilding and packaging.

HOW TO RUN
----------
1. Easiest: open index.html in Chrome / Edge / Firefox / Safari (Android or
   desktop). No server or installation required.
2. From source:
      npm install
      npm run dev      (development)
      npm run build    (emits a new self-contained dist/index.html)

CONTROLS — TOUCH (primary)
--------------------------
Player 1 (AETHER) owns the LEFT half of the screen.
  - Analog joystick, outer bottom-left corner: move (8-way / analog)
  - LIGHT   : fast sword attack, low damage, fast recovery
  - HEAVY   : slow overhead strike, high damage, big knockback
  - DODGE   : quick step with 0.3 s invulnerability
  - SPECIAL : requires a full 100 energy meter
  - BLOCK   : hold to reduce incoming damage by ~78%

Player 2 (INFERNO) owns the RIGHT half of the screen.
  - Analog joystick, outer bottom-right corner
  - Same five actions, mirrored toward the centre of the screen.

CONTROLS — KEYBOARD (desktop testing fallback)
----------------------------------------------
P1: W A S D move · J light · K heavy · L dodge · U special · Space block
P2: Arrow keys move · Numpad1 / , light · Numpad2 / . heavy
    Numpad3 / / dodge · Numpad0 / RightShift special · Numpad5 / R-Ctrl block
Esc: pause / resume

RULES
-----
- Best of three rounds. First to two round wins takes the match.
- 100 health per round, 60 second timer. On time-out the higher health wins.
- Energy builds when you land or receive hits. Special costs a full meter.
- Attacks only hit inside their real range, swing arc and active frames.
- One hit per swing. Dodging avoids damage. Blocking reduces it.
- The camera pulls back as fighters separate and closes in at close range.

GRAPHICS PRESETS
----------------
LOW    : no shadows, capped pixel ratio, fewer particles. Weak phones.
MEDIUM : 1024 shadow map, 1.5x pixel ratio, balanced. Recommended.
HIGH   : 2048 shadow map, up to 2x pixel ratio. Desktop / flagship phones.

HONEST TECHNICAL NOTES
----------------------
- The two champions are procedurally built, joint-rigged characters (about
  142 / 153 meshes each, ~14.5k triangles each) with layered armour, cloth,
  capes and glowing weapons. They are NOT scanned/GLB models: no licensed
  rigged character asset was available offline, so a procedural rig with a
  real THREE.AnimationMixer clip set is used instead.
- Clips: idle, walk, run, light, heavy, dodge, block, hit, special, victory,
  KO. They are real AnimationClips driving named joints via cross-fades.
- All sound effects and the ambient score are synthesized at runtime with the
  Web Audio API. There are no .mp3/.ogg files.
- No accounts, no server, no analytics, no online play.
- Tested by automated scene-construction/animation checks and a production
  build. Not tested on a physical Android device in this environment.

ANDROID / APK PACKAGING
-----------------------
Option A — Capacitor (recommended):
  1. npm install
  2. npm run build
  3. npm i @capacitor/core @capacitor/android
  4. npx cap init "Gods of War" com.example.titanarena --web-dir=dist
  5. npx cap add android
  6. npx cap sync android
  7. Open android/ in Android Studio, then Build > Build Bundle(s)/APK(s).
  The game needs no INTERNET permission. Keep the WebView in portrait or
  lock it to landscape for the best arena view.

Option B — plain WebView:
  Copy index.html into app/src/main/assets/ and load it with
  webView.loadUrl("file:///android_asset/index.html"). Enable JavaScript and
  DOM storage; no network permission is required.

PERFORMANCE LIMITS
------------------
- Use LOW on 2GB-RAM or older Adreno/Mali devices.
- Expect 30-60 FPS depending on GPU, screen resolution and heat.
- Close other apps before playing; the game caps pixel ratio and disposes
  GPU resources when unmounted.
- No guarantee of 60 FPS on every device.

CREDITS / LICENSES
------------------
Three.js (MIT) · React (MIT) · Vite (MIT) · Tailwind CSS (MIT).
All game code, procedural models, textures, animations and audio are original
and generated at build/run time. No third-party art, music or character assets
are included.
