// Copy these values into the firebaseConfig object at the top of app.js.
// Firebase Console -> Project settings -> Your apps -> SDK setup and configuration -> Config
const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};