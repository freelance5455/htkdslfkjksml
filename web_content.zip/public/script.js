const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const startBtn = document.getElementById('startBtn');
const captureBtn = document.getElementById('captureBtn');
const switchBtn = document.getElementById('switchBtn');
const countdownEl = document.getElementById('countdown');
const flashEl = document.getElementById('flash');
const statusEl = document.getElementById('status');
const preview = document.getElementById('preview');
const headerNav = document.getElementById('headerNav');

let stream = null;
let facingMode = 'user';
let currentUser = null;

function setStatus(msg, color = '#a78bfa') {
  statusEl.textContent = msg;
  statusEl.style.color = color;
}

async function checkAuth() {
  try {
    const res = await fetch('/api/me');
    if (!res.ok) {
      headerNav.innerHTML = `<a href="/login.html" class="btn-dashboard">🔐 Login</a>`;
      return false;
    }
    currentUser = await res.json();
    const dashUrl = currentUser.role === 'owner' ? '/owner.html' : '/member.html';
    headerNav.innerHTML = `
      <span style="margin-right:12px; color:#a78bfa;">👤 ${currentUser.username}</span>
      <a href="${dashUrl}" class="btn-dashboard">📊 Dashboard</a>
      <button onclick="logout()" class="btn-dashboard" style="margin-left:8px;">🚪 Logout</button>
    `;
    return true;
  } catch { return false; }
}

window.logout = async () => {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/login.html';
};

async function startCamera() {
  try {
    if (stream) stream.getTracks().forEach(t => t.stop());
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    });
    video.srcObject = stream;
    captureBtn.disabled = false;
    switchBtn.disabled = false;
    startBtn.textContent = '🎥 Kamera Aktif';
    setStatus('✅ Kamera siap!', '#4ade80');
  } catch (err) {
    setStatus('❌ ' + err.message, '#ef4444');
  }
}

function capturePhoto() {
  if (!currentUser) {
    setStatus('❌ Login dulu untuk menyimpan foto', '#ef4444');
    setTimeout(() => window.location.href = '/login.html', 1200);
    return;
  }
  let count = 3;
  countdownEl.style.display = 'block';
  countdownEl.textContent = count;
  const interval = setInterval(() => {
    count--;
    if (count > 0) countdownEl.textContent = count;
    else { clearInterval(interval); countdownEl.style.display = 'none'; doCapture(); }
  }, 1000);
}

async function doCapture() {
  flashEl.classList.add('active');
  setTimeout(() => flashEl.classList.remove('active'), 400);
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  if (facingMode === 'user') { ctx.translate(canvas.width, 0); ctx.scale(-1, 1); }
  ctx.drawImage(video, 0, 0);

  canvas.toBlob(async (blob) => {
    const formData = new FormData();
    formData.append('photo', blob, 'photo.png');
    try {
      setStatus('⏳ Mengunggah...');
      const res = await fetch('/api/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (data.success) {
        setStatus('✅ Foto tersimpan!', '#4ade80');
        preview.innerHTML = `<img src="${data.photo.url}?t=${Date.now()}" alt="Hasil">`;
      } else setStatus('❌ ' + (data.error || 'Gagal'), '#ef4444');
    } catch (err) { setStatus('❌ ' + err.message, '#ef4444'); }
  }, 'image/png');
}

startBtn.addEventListener('click', startCamera);
captureBtn.addEventListener('click', capturePhoto);
switchBtn.addEventListener('click', () => {
  facingMode = facingMode === 'user' ? 'environment' : 'user';
  startCamera();
});
checkAuth();