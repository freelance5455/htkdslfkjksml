const socket = io();
let me=null, users=[], localStream=null, callMode=null;
const peers=new Map();

const $=id=>document.getElementById(id);
const login=$("login"), app=$("app"), nameInput=$("name"), passInput=$("password"), error=$("loginError");
const messages=$("messages"), input=$("message"), typing=$("typing"), memberList=$("memberList"), count=$("count");
const modal=$("call"), grid=$("remoteGrid");

$("join").onclick=join;
passInput.onkeydown=nameInput.onkeydown=e=>{if(e.key==="Enter")join()};

function join(){
  const name=nameInput.value.trim(), password=passInput.value;
  error.textContent="";
  socket.emit("join",{name,password},res=>{
    if(!res?.ok){error.textContent=res?.error||"Could not join.";return}
    me=res.me; login.classList.add("hidden"); app.classList.remove("hidden");
    $("myName").textContent=me.name; $("myAvatar").textContent=me.name[0].toUpperCase();
    $("status").textContent="● Connected";
    renderHistory(res.history||[]);
    input.focus();
  });
}
socket.on("connect",()=>{ if(me) { $("status").textContent="● Reconnected"; join(); }});
socket.on("disconnect",()=>$("status").textContent="○ Disconnected");
socket.on("connect_error",()=>$("status").textContent="○ Server unavailable");

function renderHistory(list){messages.innerHTML=""; addSystem("Welcome to NEXORA."); list.forEach(addChat)}
socket.on("chat",addChat);
socket.on("system",addSystem);
function addSystem(text){const d=document.createElement("div");d.className="system";d.textContent=text;messages.appendChild(d);scrollDown()}
function addChat(m){
 const row=document.createElement("div");row.className="message";
 const av=document.createElement("div");av.className="msg-avatar";av.textContent=m.name[0].toUpperCase();
 const body=document.createElement("div");body.className="msg-body";
 const head=document.createElement("div");head.className="msg-head";
 const nm=document.createElement("span");nm.className="msg-name";nm.textContent=m.name;
 const tm=document.createElement("span");tm.className="msg-time";tm.textContent=new Date(m.time).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
 const tx=document.createElement("div");tx.className="msg-text";tx.textContent=m.text;
 head.append(nm,tm);body.append(head,tx);row.append(av,body);messages.append(row);scrollDown()
}
function scrollDown(){messages.scrollTop=messages.scrollHeight}

socket.on("users",list=>{users=list;memberList.innerHTML="";count.textContent=list.length;list.forEach(u=>{const row=document.createElement("div");row.className="member";row.innerHTML=`<div class="avatar">${escapeHtml(u.name[0])}</div><div><b>${escapeHtml(u.name)}</b><small>Online</small></div>`;memberList.appendChild(row)})});
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

$("form").onsubmit=e=>{e.preventDefault();const text=input.value.trim();if(text){socket.emit("chat",text);input.value="";socket.emit("typing",false)}};
let typingTimer;
input.oninput=()=>{socket.emit("typing",!!input.value);clearTimeout(typingTimer);typingTimer=setTimeout(()=>socket.emit("typing",false),900)};
socket.on("typing",x=>{typing.textContent=x.typing?`${x.name} is typing...`:""});
$("emoji").onclick=()=>$("emojiPanel").classList.toggle("hidden");
document.querySelectorAll("#emojiPanel button").forEach(b=>b.onclick=()=>{input.value+=b.textContent;input.focus()});

$("members").onclick=()=>{const p=$("membersPanel");p.style.display=p.style.display==="block"?"none":"block"};
$("mute").onclick=toggleMute;
function toggleMute(){if(localStream){localStream.getAudioTracks().forEach(t=>t.enabled=!t.enabled);$("mute").textContent=localStream.getAudioTracks()[0]?.enabled?"🎙️":"🔇"}}

$("voice").onclick=()=>startCall(false);
$("video").onclick=()=>startCall(true);
$("voiceJoin").onclick=()=>startCall(false);
$("closeCall").onclick=endCall;
$("endCall").onclick=endCall;
$("callMute").onclick=toggleMute;
$("callCamera").onclick=async()=>{if(!localStream)await getMedia(true);localStream?.getVideoTracks().forEach(t=>t.enabled=!t.enabled)};

async function getMedia(video){
 try{
  localStream=await navigator.mediaDevices.getUserMedia({audio:true,video});
  $("mute").textContent="🎙️";
  return true;
 }catch(e){alert("Camera/microphone permission was denied or unavailable.");return false}
}
async function startCall(video){
 if(!me)return;
 callMode=video; $("callTitle").textContent=video?"NEXORA VIDEO CHAT":"NEXORA VOICE CHAT";modal.classList.remove("hidden");
 const ok=await getMedia(video); if(!ok)return;
 addLocalTile();
 // Ring all other online users. Each peer connection will be negotiated.
 for(const u of users) if(u.id!==me.id) socket.emit("call:request",{to:u.id,video});
}
function addLocalTile(){
 let tile=document.getElementById("localTile");
 if(!tile){tile=document.createElement("div");tile.className="video-tile";tile.id="localTile";grid.appendChild(tile)}
 tile.innerHTML="";
 const v=document.createElement("video");v.autoplay=true;v.muted=true;v.playsInline=true;v.srcObject=localStream;tile.appendChild(v);
 const n=document.createElement("div");n.className="video-name";n.textContent=me.name+" (You)";tile.appendChild(n);
}
socket.on("call:request",async({from,name,video})=>{
 if(!localStream){
   const accepted=confirm(`${name} is calling you on NEXORA. Accept?`);
   if(!accepted){socket.emit("call:hangup",{to:from});return}
   modal.classList.remove("hidden");$("callTitle").textContent=video?"NEXORA VIDEO CHAT":"NEXORA VOICE CHAT";callMode=video;
   if(!await getMedia(video))return; addLocalTile();
 }
 await makeOffer(from,video);
});

async function makeOffer(id,video){
 const pc=createPeer(id);
 const offer=await pc.createOffer(); await pc.setLocalDescription(offer);
 socket.emit("webrtc:offer",{to:id,offer});
}
function createPeer(id){
 if(peers.has(id))return peers.get(id);
 const pc=new RTCPeerConnection({iceServers:[
  {urls:"stun:stun.l.google.com:19302"},
  {urls:"stun:stun.cloudflare.com:3478"}
 ]});
 if(localStream)localStream.getTracks().forEach(t=>pc.addTrack(t,localStream));
 pc.onicecandidate=e=>{if(e.candidate)socket.emit("webrtc:ice",{to:id,candidate:e.candidate})};
 pc.ontrack=e=>showRemote(id,e.streams[0]);
 pc.onconnectionstatechange=()=>{if(["failed","closed","disconnected"].includes(pc.connectionState))removePeer(id)};
 peers.set(id,pc);return pc;
}
socket.on("webrtc:offer",async({from,offer})=>{
 const pc=createPeer(from);await pc.setRemoteDescription(offer);const answer=await pc.createAnswer();await pc.setLocalDescription(answer);socket.emit("webrtc:answer",{to:from,answer});
});
socket.on("webrtc:answer",async({from,answer})=>{const pc=peers.get(from);if(pc)await pc.setRemoteDescription(answer)});
socket.on("webrtc:ice",async({from,candidate})=>{const pc=peers.get(from);if(pc)try{await pc.addIceCandidate(candidate)}catch(e){}});
socket.on("call:hangup",({from})=>removePeer(from));

function showRemote(id,stream){
 let tile=document.getElementById("peer-"+id);
 if(!tile){tile=document.createElement("div");tile.className="video-tile";tile.id="peer-"+id;grid.appendChild(tile)}
 tile.innerHTML="";const v=document.createElement("video");v.autoplay=true;v.playsInline=true;v.srcObject=stream;tile.appendChild(v);
 const u=users.find(x=>x.id===id);const n=document.createElement("div");n.className="video-name";n.textContent=u?.name||"Player";tile.appendChild(n);
}
function removePeer(id){const pc=peers.get(id);if(pc)pc.close();peers.delete(id);document.getElementById("peer-"+id)?.remove()}
function endCall(){
 modal.classList.add("hidden");
 for(const id of peers.keys())socket.emit("call:hangup",{to:id});
 for(const pc of peers.values())pc.close();peers.clear();
 if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null}
 grid.innerHTML="";
}
