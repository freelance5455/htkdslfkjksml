const form = document.getElementById("searchForm");
const input = document.getElementById("query");
const button = document.getElementById("submitBtn");
const statusBox = document.getElementById("status");
const answerCard = document.getElementById("answerCard");
const answerBox = document.getElementById("answer");
const sourcesSection = document.getElementById("sourcesSection");
const sourcesBox = document.getElementById("sources");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const query = input.value.trim();
  if (!query) return;
  button.disabled = true;
  button.innerHTML = "Searching...";
  statusBox.textContent = "Google par search ho rahi hai aur AI jawab tayyar kar raha hai...";
  answerCard.classList.add("hidden");
  sourcesSection.classList.add("hidden");
  try {
    const response = await fetch("/api/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Search failed.");
    answerBox.textContent = data.answer;
    answerCard.classList.remove("hidden");
    sourcesBox.replaceChildren();
    (data.results || []).forEach((item) => {
      const article = document.createElement("article");
      article.className = "source";
      const link = document.createElement("a");
      link.href = item.link;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = `[${item.number}] ${item.title}`;
      const snippet = document.createElement("p");
      snippet.textContent = item.snippet;
      const url = document.createElement("small");
      url.textContent = item.link;
      article.append(link, snippet, url);
      sourcesBox.append(article);
    });
    if (data.results?.length) sourcesSection.classList.remove("hidden");
    statusBox.textContent = data.results?.length ? `${data.results.length} Google results milay.` : "Koi Google result nahin mila.";
  } catch (error) {
    statusBox.textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = 'Search <span>→</span>';
  }
});