(() => {
  const $ = id => document.getElementById(id);
  const config = window.CHATTU_FIREBASE_CONFIG || {};
  const configured = config.apiKey && !String(config.apiKey).startsWith("PASTE_") &&
    config.projectId && !String(config.projectId).startsWith("YOUR_");
  let auth, db, storage, rtdb, me = null, profile = null, friends = [], activeFriend = null;
  let friendUnsub = null, messageUnsub = null, statusUnsubs = [], statusMap = {};
  let signupMode = false, toastTimer = null, presenceRef = null;

  function toast(text) {
    const el = $("toast"); el.textContent = text; el.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
  }
  function setAuthMessage(text, good=false) {
    $("authMessage").textContent = text; $("authMessage").style.color = good ? "#238b6a" : "#d34b6d";
  }
  function setFriendMessage(text, good=false) {
    $("friendMessage").textContent = text; $("friendMessage").style.color = good ? "#238b6a" : "#d34b6d";
  }
  function safeText(s) { return String(s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function initials(name) { return (name || "?").trim().slice(0,1).toUpperCase(); }
  function makeCode(uid) { return uid.replace(/[^a-z0-9]/gi,"").slice(-8).toUpperCase().padStart(6,"C"); }
  function pairId(a,b) { return [a,b].sort().join("_"); }
  function formatTime(ts) {
    try { return ts && ts.toDate ? ts.toDate().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}) : ""; }
    catch (_) { return ""; }
  }
  function showAuth() { $("authView").classList.remove("hidden"); $("appView").classList.add("hidden"); }
  function showApp() { $("authView").classList.add("hidden"); $("appView").classList.remove("hidden"); }
  function renderAuthMode() {
    $("loginTab").classList.toggle("active", !signupMode); $("signupTab").classList.toggle("active", signupMode);
    $("nameLabel").classList.toggle("hidden", !signupMode); $("nameInput").classList.toggle("hidden", !signupMode);
    $("nameInput").required = signupMode;
    $("authSubmit").innerHTML = signupMode ? 'Create account <span>→</span>' : 'Log in <span>→</span>';
    $("passwordInput").autocomplete = signupMode ? "new-password" : "current-password";
    setAuthMessage("");
  }
  $("loginTab").addEventListener("click", () => { signupMode=false; renderAuthMode(); });
  $("signupTab").addEventListener("click", () => { signupMode=true; renderAuthMode(); });

  if (!configured) {
    setAuthMessage("Setup needed: add your Firebase web config in public/firebase-config.js.");
    $("authSubmit").disabled = true; $("authSubmit").style.opacity = ".55";
    $("authMessage").style.color = "#d34b6d";
    $("authMessage").textContent = "Setup needed: add your Firebase web config in public/firebase-config.js.";
    $("authForm").addEventListener("submit", e => e.preventDefault());
    return;
  }
  try {
    firebase.initializeApp(config);
    auth = firebase.auth(); db = firebase.firestore(); storage = firebase.storage(); rtdb = firebase.database();
  } catch(e) {
    setAuthMessage("Firebase setup error. Check firebase-config.js.");
    console.error(e); return;
  }

  $("authForm").addEventListener("submit", async e => {
    e.preventDefault(); setAuthMessage("");
    const email = $("emailInput").value.trim(), password = $("passwordInput").value;
    const name = $("nameInput").value.trim();
    $("authSubmit").disabled = true; $("authSubmit").textContent = "Please wait…";
    try {
      if (signupMode) {
        const cred = await auth.createUserWithEmailAndPassword(email, password);
        const code = makeCode(cred.user.uid);
        await db.collection("users").doc(cred.user.uid).set({
          uid: cred.user.uid, name, email, friendCode: code, createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        await cred.user.updateProfile({displayName:name});
      } else await auth.signInWithEmailAndPassword(email, password);
    } catch(err) { setAuthMessage(friendlyError(err)); }
    finally { $("authSubmit").disabled = false; renderAuthMode(); }
  });
  function friendlyError(e) {
    const map = {"auth/email-already-in-use":"This email already has an account.","auth/invalid-email":"Please enter a valid email.","auth/weak-password":"Use a password with at least 6 characters.","auth/user-not-found":"No account found for this email.","auth/wrong-password":"Incorrect email or password.","auth/invalid-credential":"Incorrect email or password.","auth/network-request-failed":"Network error. Check your internet."};
    return map[e.code] || e.message || "Something went wrong. Please try again.";
  }
  auth.onAuthStateChanged(async user => {
    cleanListeners();
    if (!user) { me=null; profile=null; showAuth(); return; }
    me = user;
    try {
      const ref = db.collection("users").doc(user.uid);
      let snap = await ref.get();
      if (!snap.exists) {
        const name = user.displayName || user.email.split("@")[0];
        profile = {uid:user.uid,name,email:user.email,friendCode:makeCode(user.uid)};
        await ref.set(profile); 
      } else profile = snap.data();
      $("myName").textContent = profile.name || "Chattu user";
      $("myAvatar").textContent = initials(profile.name);
      $("myCode").textContent = profile.friendCode || makeCode(user.uid);
      showApp(); listenFriends(); setupPresence();
    } catch(err) {
      console.error(err); toast("Could not load your profile. Check Firebase rules.");
    }
  });
  function cleanListeners() {
    if (friendUnsub) friendUnsub(); friendUnsub=null;
    if (messageUnsub) messageUnsub(); messageUnsub=null;
    statusUnsubs.forEach(u=>{try{u() }catch(_){}}); statusUnsubs=[];
    activeFriend=null; friends=[]; statusMap={};
  }
  async function setupPresence() {
    try {
      const connectedRef = rtdb.ref(".info/connected");
      presenceRef = rtdb.ref("status/" + me.uid);
      connectedRef.on("value", snap => {
        if (snap.val() === false) return;
        presenceRef.onDisconnect().set({state:"offline", lastChanged:firebase.database.ServerValue.TIMESTAMP});
        presenceRef.set({state:"online", lastChanged:firebase.database.ServerValue.TIMESTAMP});
      });
      window.addEventListener("beforeunload", () => presenceRef && presenceRef.set({state:"offline",lastChanged:firebase.database.ServerValue.TIMESTAMP}));
    } catch(e) { console.warn("Presence unavailable",e); }
  }
  function listenFriends() {
    friendUnsub = db.collection("users").doc(me.uid).collection("friends").onSnapshot(async snap => {
      const ids = snap.docs.map(d=>d.id);
      friends = await Promise.all(snap.docs.map(async d => {
        const data=d.data();
        if(data.name) return {uid:d.id,name:data.name,friendCode:data.friendCode||""};
        const userSnap=await db.collection("users").doc(d.id).get();
        return userSnap.exists ? {uid:d.id,...userSnap.data()} : {uid:d.id,name:"Unknown user"};
      }));
      friends.sort((a,b)=>(a.name||"").localeCompare(b.name||""));
      watchFriendStatuses(ids); renderFriends();
      if (activeFriend && !friends.some(f=>f.uid===activeFriend.uid)) selectFriend(null);
    }, err => {console.error(err); toast("Couldn't load friends. Check Firestore rules.");});
  }
  function watchFriendStatuses(ids) {
    statusUnsubs.forEach(u=>{try{u()}catch(_){}}); statusUnsubs=[];
    ids.forEach(uid => {
      const ref=rtdb.ref("status/"+uid);
      const cb=ref.on("value",snap=>{statusMap[uid]=snap.val()||{state:"offline"};renderFriends(); if(activeFriend && activeFriend.uid===uid) updateHeaderStatus();});
      statusUnsubs.push(()=>ref.off("value",cb));
    });
  }
  function renderFriends() {
    $("friendCount").textContent=String(friends.length);
    if(!friends.length) { $("friendList").innerHTML='<div class="empty-list">No friends yet.<br>Add someone with their friend code above.</div>'; return; }
    $("friendList").innerHTML=friends.map(f=>{
      const online=statusMap[f.uid]?.state==="online";
      return `<button class="friend-item ${activeFriend?.uid===f.uid?'selected':''}" data-uid="${safeText(f.uid)}">
        <div class="avatar">${safeText(initials(f.name))}</div><div class="friend-info"><strong>${safeText(f.name)}</strong><span>${online?"Online":"Tap to open chat"}</span></div><i class="status-dot ${online?'':'offline'}"></i></button>`;
    }).join("");
    $("friendList").querySelectorAll("[data-uid]").forEach(btn=>btn.addEventListener("click",()=>selectFriend(friends.find(f=>f.uid===btn.dataset.uid))));
  }
  $("copyCodeBtn").addEventListener("click", async()=>{
    try { await navigator.clipboard.writeText($("myCode").textContent); toast("Friend code copied!"); }
    catch(_) { toast("Your friend code is "+$("myCode").textContent); }
  });
  $("addFriendBtn").addEventListener("click", addFriend);
  $("friendCodeInput").addEventListener("keydown", e=>{if(e.key==="Enter"){e.preventDefault();addFriend();}});
  async function addFriend() {
    const code=$("friendCodeInput").value.trim().toUpperCase();
    if(!code) return setFriendMessage("Enter your friend's code.");
    if(code===$("myCode").textContent) return setFriendMessage("That's your own friend code.");
    $("addFriendBtn").disabled=true; setFriendMessage("Searching…",true);
    try {
      const found=await db.collection("users").where("friendCode","==",code).limit(1).get();
      if(found.empty) return setFriendMessage("No account found with that code.");
      const f=found.docs[0].data();
      if(f.uid===me.uid) return setFriendMessage("That's your own friend code.");
      const batch=db.batch();
      batch.set(db.collection("users").doc(me.uid).collection("friends").doc(f.uid),{name:f.name,friendCode:f.friendCode,addedAt:firebase.firestore.FieldValue.serverTimestamp()});
      batch.set(db.collection("users").doc(f.uid).collection("friends").doc(me.uid),{name:profile.name,friendCode:profile.friendCode,addedAt:firebase.firestore.FieldValue.serverTimestamp()});
      await batch.commit(); $("friendCodeInput").value=""; setFriendMessage("Friend added!",true); toast("You and "+f.name+" are now connected!");
    } catch(err) { console.error(err); setFriendMessage("Could not add friend. Check Firebase rules."); }
    finally { $("addFriendBtn").disabled=false; }
  }
  function updateHeaderStatus() {
    if(!activeFriend)return;
    const online=statusMap[activeFriend.uid]?.state==="online";
    $("chatHeader").querySelector("p").innerHTML=online?'<span class="online-dot"></span> Online now':'Last seen / offline';
  }
  function selectFriend(friend) {
    activeFriend=friend; renderFriends();
    if(messageUnsub){messageUnsub();messageUnsub=null;}
    if(!friend) {
      $("chatHeader").innerHTML='<div class="header-avatar">✦</div><div><h2>Welcome to Chattu Chat</h2><p>Connect with a friend to start talking.</p></div>';
      $("messages").classList.add("hidden");$("composer").classList.add("hidden");$("welcomePanel").classList.remove("hidden");return;
    }
    $("chatHeader").innerHTML=`<div class="header-avatar">${safeText(initials(friend.name))}</div><div><h2>${safeText(friend.name)}</h2><p>Loading status…</p></div>`;
    $("welcomePanel").classList.add("hidden");$("messages").classList.remove("hidden");$("composer").classList.remove("hidden");
    $("messages").innerHTML='<div class="day-divider">Your conversation starts here ✨</div>'; updateHeaderStatus();
    const cid=pairId(me.uid,friend.uid);
    messageUnsub=db.collection("chats").doc(cid).collection("messages").orderBy("createdAt","asc").limit(300).onSnapshot(snap=>{
      const box=$("messages"), nearBottom=box.scrollHeight-box.scrollTop-box.clientHeight<100;
      box.innerHTML="";
      if(snap.empty) box.innerHTML='<div class="day-divider">Say hello to '+safeText(friend.name)+' 👋</div>';
      snap.forEach(doc=>{
        const m=doc.data(), mine=m.senderId===me.uid, row=document.createElement("div");
        row.className="message-row"+(mine?" mine":"");
        const bubble=document.createElement("div");bubble.className="msg-bubble";
        if(m.type==="image" && m.imageUrl) {
          const img=document.createElement("img");img.className="msg-photo";img.src=m.imageUrl;img.alt="Photo shared in chat";img.loading="lazy";
          img.addEventListener("click",()=>window.open(m.imageUrl,"_blank","noopener"));
          bubble.appendChild(img);
          if(m.text){const t=document.createElement("div");t.textContent=m.text;bubble.appendChild(t);}
        } else bubble.textContent=m.text||"";
        row.appendChild(bubble);
        const time=document.createElement("div");time.className="msg-time";time.textContent=(mine?"You · ":"")+formatTime(m.createdAt);row.appendChild(time);
        box.appendChild(row);
      });
      if(nearBottom) box.scrollTop=box.scrollHeight;
    },err=>{console.error(err);toast("Could not load messages. Check Firestore rules.");});
    $("messageInput").focus();
  }
  $("composer").addEventListener("submit", async e=>{
    e.preventDefault();const text=$("messageInput").value.trim();
    if(!text||!activeFriend)return;
    $("messageInput").value="";
    try { await sendMessage({type:"text",text}); }
    catch(err){$("messageInput").value=text;console.error(err);toast("Message didn't send. Check connection and rules.");}
  });
  async function sendMessage(payload) {
    if(!activeFriend) throw new Error("Choose a friend first");
    const cid=pairId(me.uid,activeFriend.uid);
    await db.collection("chats").doc(cid).collection("messages").add({
      ...payload, senderId:me.uid, receiverId:activeFriend.uid,
      createdAt:firebase.firestore.FieldValue.serverTimestamp()
    });
    await db.collection("chats").doc(cid).set({participants:[me.uid,activeFriend.uid],lastMessage:payload.type==="image"?"📷 Photo":payload.text,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
  }
  $("photoInput").addEventListener("change", async e=>{
    const file=e.target.files && e.target.files[0];e.target.value="";
    if(!file)return;
    if(!activeFriend){toast("Open a friend's chat first.");return;}
    if(!file.type.startsWith("image/")){toast("Choose an image file.");return;}
    if(file.size>5*1024*1024){toast("Photo must be 5 MB or smaller.");return;}
    toast("Uploading photo…");
    try {
      const path=`chatPhotos/${pairId(me.uid,activeFriend.uid)}/${me.uid}_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
      const snap=await storage.ref(path).put(file,{contentType:file.type});
      const url=await snap.ref.getDownloadURL();
      await sendMessage({type:"image",imageUrl:url,text:""});
      toast("Photo sent!");
    } catch(err){console.error(err);toast("Photo upload failed. Check Storage rules.");}
  });
  $("logoutBtn").addEventListener("click", async()=>{
    try { if(presenceRef) await presenceRef.set({state:"offline",lastChanged:firebase.database.ServerValue.TIMESTAMP}); await auth.signOut(); }
    catch(e){console.error(e);toast("Couldn't log out.");}
  });
})();