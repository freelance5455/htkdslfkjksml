import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, collection, getDocs, query, where, orderBy, doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-functions.js";

const cfg = window.GROWTH_SALLER_CONFIG || {};
const configured = !!(cfg.firebase && cfg.firebase.apiKey && !cfg.firebase.apiKey.includes("PASTE_") && cfg.firebase.projectId && !cfg.firebase.projectId.includes("PASTE_"));
if (configured) {

const cfg = window.GROWTH_SALLER_CONFIG;
const $ = id => document.getElementById(id);
const app = initializeApp(cfg.firebase);
const auth = getAuth(app);
const db = getFirestore(app);
const functions = getFunctions(app);
const createOrderFn = httpsCallable(functions, "createOrder");
const updateOrderFn = httpsCallable(functions, "adminUpdateOrder");
const verifyPaymentFn = httpsCallable(functions, "submitPaymentReference");
let currentUser = null, isAdmin = false, services = [], selected = null;

function toast(msg){ const el=$("toast"); el.textContent=msg; el.style.display="block"; setTimeout(()=>el.style.display="none",3200); }
function money(n){ return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR"}).format(Number(n)||0); }
function show(id,yes){$(id).classList.toggle("hidden",!yes);}
function safeText(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function validUrl(s){try{const u=new URL(s);return u.protocol==="https:" && !!u.hostname;}catch{return false;}}
$("upiDetails").textContent = `Payee: ${cfg.payeeName} • UPI ID: ${cfg.upiId}`;

$("registerBtn").onclick = async () => {
  try {
    const email=$("email").value.trim(), password=$("password").value;
    if(!email || password.length<6) throw new Error("सही email और कम से कम 6 अक्षर का password डालें।");
    const cred=await createUserWithEmailAndPassword(auth,email,password);
    await setDoc(doc(db,"users",cred.user.uid),{email:cred.user.email,displayName:email.split("@")[0],createdAt:serverTimestamp()});
    $("authMessage").textContent="Account बन गया।";
  } catch(e){$("authMessage").textContent=e.message;}
};
$("loginBtn").onclick = async () => {
  try { await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value); $("authMessage").textContent=""; }
  catch(e){$("authMessage").textContent=e.message;}
};
$("logoutBtn").onclick = () => signOut(auth);
$("refreshBtn").onclick = async () => { await loadMyOrders(); if(isAdmin) await loadAdminOrders(); };

$("submitPaymentBtn").onclick = async () => {
  try {
    const orderId = $("paymentOrderId").value.trim();
    const utr = $("paymentUtr").value.trim();
    if (!orderId || !utr) throw new Error("Order ID और UTR/reference number दोनों भरें।");
    $("submitPaymentBtn").disabled = true;
    await verifyPaymentFn({ orderId, utr });
    $("paymentMessage").textContent = "Payment reference submit हो गया। पुष्टि के बाद status अपडेट होगा।";
    $("paymentUtr").value = "";
    await loadMyOrders();
  } catch (e) {
    $("paymentMessage").textContent = e.message || "Reference submit नहीं हो पाया।";
  } finally {
    $("submitPaymentBtn").disabled = false;
  }
};

onAuthStateChanged(auth, async user => {
  currentUser=user;
  show("authCard",!user); show("appSection",!!user); show("logoutBtn",!!user);
  if(!user){isAdmin=false;show("adminSection",false);return;}
  try {
    const token=await user.getIdTokenResult(true);
    isAdmin=String(user.email||"").toLowerCase()==="ranveerjaiswal282@gmail.com" && user.emailVerified===true;
    $("welcomeText").textContent=`Logged in: ${user.email}`;
    show("adminSection",isAdmin);
    await loadServices(); await loadMyOrders();
    if(isAdmin) await loadAdminOrders();
  } catch(e){toast("लोड करने में समस्या: "+e.message);}
});

async function loadServices(){
  const snap=await getDocs(query(collection(db,"services"),where("active","==",true)));
  services=snap.docs.map(d=>({id:d.id,...d.data()}));
  const wrap=$("services");
  if(!services.length){wrap.innerHTML='<p class="empty">अभी services नहीं हैं। Admin Firestore में service documents जोड़े।</p>';return;}
  wrap.innerHTML=services.map(s=>`<div class="service ${selected?.id===s.id?"selected":""}" data-id="${safeText(s.id)}"><span class="platform platform-${safeText(s.platform).toLowerCase()}"><b class="platform-icon">${platformIcon(s.platform)}</b>${safeText(s.platform)}</span><strong>${safeText(s.name)}</strong><div class="muted">${safeText(s.description||"")}</div><div class="price">${money(s.pricePer1000)} / 1000</div></div>`).join("");
  wrap.querySelectorAll(".service").forEach(el=>el.onclick=()=>selectService(el.dataset.id));
}
function platformIcon(platform){return ({Instagram:"◎",Facebook:"f",YouTube:"▶",TikTok:"♪"})[platform]||"★";}
function selectService(id){
  selected=services.find(s=>s.id===id); if(!selected)return;
  show("orderCard",true);
  $("selectedService").textContent=`${selected.platform} — ${selected.name} • ${money(selected.pricePer1000)} प्रति 1000`;
  $("quantity").min=selected.minQty||1; $("quantity").max=selected.maxQty||100000; $("quantity").value=selected.minQty||100;
  $("services").querySelectorAll(".service").forEach(el=>el.classList.toggle("selected",el.dataset.id===id));
  updateEstimate();
}
function updateEstimate(){
  const q=Number($("quantity").value)||0;
  $("estimate").textContent="Estimated total: "+money((selected?.pricePer1000||0)*q/1000);
}
$("quantity").addEventListener("input",updateEstimate);
$("placeOrderBtn").onclick=async()=>{
  try{
    if(!selected)throw new Error("पहले service चुनें।");
    const url=$("targetUrl").value.trim(), quantity=Number($("quantity").value);
    if(!validUrl(url))throw new Error("पूरा https:// public link डालें।");
    if(!Number.isInteger(quantity)||quantity<(selected.minQty||1)||quantity>(selected.maxQty||100000))throw new Error("Quantity सीमा के बाहर है।");
    $("placeOrderBtn").disabled=true;
    const result=await createOrderFn({serviceId:selected.id,targetUrl:url,quantity});
    $("orderMessage").textContent=`Order submit हो गया। Order ID: ${result.data.orderId}`;
    $("targetUrl").value=""; await loadMyOrders(); toast("Order submit हो गया।");
  }catch(e){$("orderMessage").textContent=e.message||"Order नहीं बना।";}
  finally{$("placeOrderBtn").disabled=false;}
};
async function loadMyOrders(){
  if(!currentUser)return;
  const snap=await getDocs(query(collection(db,"orders"),where("userId","==",currentUser.uid),orderBy("createdAt","desc")));
  $("myOrders").innerHTML=snap.empty?'<p class="empty">अभी कोई order नहीं है।</p>':snap.docs.map(d=>orderHtml(d.id,d.data(),false)).join("");
}
function orderHtml(id,o,admin){
  const dt=o.createdAt?.toDate?o.createdAt.toDate().toLocaleString("en-IN"):"Just now";
  return `<div class="${admin?"admin-row":"order"}"><div class="order-head"><strong>${safeText(o.platform)} — ${safeText(o.serviceName)}</strong><span class="status">${safeText(o.status)}</span></div><p class="muted">${admin?`Customer email: ${safeText(o.userEmail||"Email unavailable")}<br>`:""}Order: ${safeText(id)}<br>Quantity: ${Number(o.quantity)} • Total: ${money(o.totalPrice)}<br>Payment: ${safeText(o.paymentStatus||"UNPAID")}<br>Created: ${safeText(dt)}</p><p class="muted">Target: <a href="${safeText(o.targetUrl)}" target="_blank" rel="noopener noreferrer">Open link</a></p>${admin?`<div class="admin-controls"><select id="status-${safeText(id)}"><option ${o.status==="Pending"?"selected":""}>Pending</option><option ${o.status==="Processing"?"selected":""}>Processing</option><option ${o.status==="Completed"?"selected":""}>Completed</option><option ${o.status==="Cancelled"?"selected":""}>Cancelled</option></select><button data-update="${safeText(id)}">Update</button></div><div class="admin-controls"><input id="utr-${safeText(id)}" placeholder="UPI UTR/reference (optional)"><button class="secondary" data-paid="${safeText(id)}">Mark Paid</button></div>`:""}</div>`;
}
async function loadAdminOrders(){
  const snap=await getDocs(query(collection(db,"orders"),orderBy("createdAt","desc")));
  $("adminOrders").innerHTML=snap.empty?'<p class="empty">अभी कोई order नहीं है।</p>':snap.docs.map(d=>orderHtml(d.id,d.data(),true)).join("");
  $("adminOrders").querySelectorAll("[data-update]").forEach(btn=>btn.onclick=async()=>{
    try{const id=btn.dataset.update,status=$("status-"+id).value;await updateOrderFn({orderId:id,status});toast("Order status update हुआ।");await loadAdminOrders();await loadMyOrders();}
    catch(e){toast("Update failed: "+e.message);}
  });
  $("adminOrders").querySelectorAll("[data-paid]").forEach(btn=>btn.onclick=async()=>{
    try{const id=btn.dataset.paid,utr=$("utr-"+id).value.trim();if(!utr)throw new Error("पहले UTR/reference number डालें।");await verifyPaymentFn({orderId:id,utr});toast("Payment status verified/recorded.");await loadAdminOrders();await loadMyOrders();}
    catch(e){toast("Payment update failed: "+e.message);}
  });
}
} else {
  // Phone-friendly local account mode when Firebase has not been configured.
  const $ = id => document.getElementById(id);
  const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR"}).format(Number(n)||0);
  const show = (id,yes) => $(id).classList.toggle("hidden",!yes);
  const safeText = v => String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  let user = null, selected = null;
  const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
  const keyFor = email => "gs_local_"+email.toLowerCase();
  const account = () => user ? read(keyFor(user.email), null) : null;
  const saveAccount = a => localStorage.setItem(keyFor(user.email), JSON.stringify(a));
  const serviceList = [
    {id:"ig-likes",platform:"Instagram",name:"Post Likes",description:"Public Instagram post promotion",pricePer1000:25,minQty:100,maxQty:100000},
    {id:"ig-views",platform:"Instagram",name:"Reel Views",description:"Public Reel promotion",pricePer1000:20,minQty:100,maxQty:100000},
    {id:"ig-followers",platform:"Instagram",name:"Followers",description:"Instagram profile promotion",pricePer1000:80,minQty:100,maxQty:100000},
    {id:"fb-likes",platform:"Facebook",name:"Post Likes",description:"Public Facebook post promotion",pricePer1000:25,minQty:100,maxQty:100000},
    {id:"fb-views",platform:"Facebook",name:"Video Views",description:"Public Facebook video promotion",pricePer1000:20,minQty:100,maxQty:100000},
    {id:"fb-followers",platform:"Facebook",name:"Page Followers",description:"Facebook page promotion",pricePer1000:70,minQty:100,maxQty:100000},
    {id:"yt-views",platform:"YouTube",name:"Video Views",description:"Public YouTube video promotion",pricePer1000:35,minQty:100,maxQty:100000},
    {id:"yt-likes",platform:"YouTube",name:"Video Likes",description:"Public video engagement",pricePer1000:30,minQty:100,maxQty:100000},
    {id:"yt-subs",platform:"YouTube",name:"Subscribers",description:"YouTube channel promotion",pricePer1000:180,minQty:10,maxQty:10000},
    {id:"tt-likes",platform:"TikTok",name:"Video Likes",description:"Public TikTok video promotion",pricePer1000:30,minQty:100,maxQty:100000},
    {id:"tt-views",platform:"TikTok",name:"Video Views",description:"Public TikTok video promotion",pricePer1000:20,minQty:100,maxQty:100000},
    {id:"tt-followers",platform:"TikTok",name:"Followers",description:"TikTok profile promotion",pricePer1000:75,minQty:100,maxQty:100000}
  ];
  function toast(msg){const el=$("toast");el.textContent=msg;el.style.display="block";setTimeout(()=>el.style.display="none",2500);}
  function refreshWallet(){const a=account();$("walletBalance").textContent=money(a?.wallet||0);}
  function validUrl(s){try{const u=new URL(s);return u.protocol==="https:"&&!!u.hostname;}catch{return false;}}
  function renderServices(){const wrap=$("services");wrap.innerHTML=serviceList.map(s=>{const icon={Instagram:"◎",Facebook:"f",YouTube:"▶",TikTok:"♪"}[s.platform]||"★";return `<div class="service ${selected?.id===s.id?"selected":""}" data-id="${s.id}"><span class="platform platform-${s.platform.toLowerCase()}"><b class="platform-icon">${icon}</b>${s.platform}</span><strong>${s.name}</strong><div class="muted">${s.description}</div><div class="price">${money(s.pricePer1000)} / 1000</div></div>`}).join("");wrap.querySelectorAll(".service").forEach(el=>el.onclick=()=>selectService(el.dataset.id));}
  function selectService(id){selected=serviceList.find(s=>s.id===id);if(!selected)return;show("orderCard",true);$("selectedService").textContent=`${selected.platform} — ${selected.name} • ${money(selected.pricePer1000)} प्रति 1000`;$("quantity").min=selected.minQty;$("quantity").max=selected.maxQty;$("quantity").value=selected.minQty;$("services").querySelectorAll(".service").forEach(el=>el.classList.toggle("selected",el.dataset.id===id));updateEstimate();}
  function updateEstimate(){const q=Number($("quantity").value)||0;$("estimate").textContent="Total: "+money((selected?.pricePer1000||0)*q/1000);}
  function renderOrders(){const a=account(), orders=a?.orders||[];$("myOrders").innerHTML=orders.length?orders.slice().reverse().map(o=>`<div class="order"><div class="order-head"><strong>${safeText(o.platform)} — ${safeText(o.serviceName)}</strong><span class="status">${safeText(o.status)}</span></div><p class="muted">Order: ${safeText(o.id)}<br>Quantity: ${o.quantity} • Total: ${money(o.totalPrice)}<br>Payment: WALLET</p><p class="muted">Target: <a href="${safeText(o.targetUrl)}" target="_blank" rel="noopener">Open link</a></p></div>`).join(""):'<p class="empty">अभी कोई order नहीं है।</p>';}
  function enterApp(email){user={email};const existing=read(keyFor(email),{});if(!existing.walletResetToZero){existing.wallet=0;existing.deposits=existing.deposits||[];existing.walletResetToZero=true;localStorage.setItem(keyFor(email),JSON.stringify(existing));}show("authCard",false);show("appSection",true);show("logoutBtn",true);show("adminSection",false);$("welcomeText").textContent="Logged in: "+email;$("upiDetails").textContent=`Payee: ${cfg.payeeName||"Growth Saller"} • UPI ID: ${cfg.upiId||"अपना UPI ID सेट करें"}`;renderServices();refreshWallet();renderOrders();}
  $("registerBtn").onclick=()=>{const email=$("email").value.trim().toLowerCase(),password=$("password").value;if(!email.includes("@")||password.length<6){$("authMessage").textContent="सही email और कम से कम 6 अक्षर का password डालें।";return;}if(localStorage.getItem(keyFor(email))){$("authMessage").textContent="इस email से account पहले से बना है। Login करें।";return;}localStorage.setItem(keyFor(email),JSON.stringify({password,wallet:0,orders:[],deposits:[]}));$("authMessage").textContent="Account बन गया। Wallet balance उपलब्ध है।";enterApp(email);};
  $("loginBtn").onclick=()=>{const email=$("email").value.trim().toLowerCase(),password=$("password").value,a=read(keyFor(email),null);if(!a||a.password!==password){$("authMessage").textContent="Email या password सही नहीं है। पहले Register करें।";return;}enterApp(email);};
  $("logoutBtn").onclick=()=>{user=null;show("authCard",true);show("appSection",false);show("logoutBtn",false);};
  $("quantity").addEventListener("input",updateEstimate);
  $("placeOrderBtn").onclick=()=>{try{if(!selected)throw Error("पहले service चुनें।");const url=$("targetUrl").value.trim(),quantity=Number($("quantity").value);if(!validUrl(url))throw Error("पूरा https:// public link डालें।");if(!Number.isInteger(quantity)||quantity<selected.minQty||quantity>selected.maxQty)throw Error("Quantity सीमा के बाहर है।");const total=Math.round(selected.pricePer1000*quantity/1000*100)/100;const a=account();if(a.wallet<total)throw Error("Wallet balance कम है। पहले balance add करें।");a.wallet=Math.round((a.wallet-total)*100)/100;const o={id:"GS-"+Date.now().toString().slice(-9),platform:selected.platform,serviceName:selected.name,quantity,totalPrice:total,targetUrl:url,status:"Pending",createdAt:new Date().toISOString()};a.orders.push(o);saveAccount(a);$("orderMessage").textContent=`Order submit हो गया: ${o.id} • ${money(total)} wallet से काटे गए।`;$("targetUrl").value="";refreshWallet();renderOrders();toast("Order placed; wallet balance updated.");}catch(e){$("orderMessage").textContent=e.message;}};
  $("refreshBtn").onclick=()=>{refreshWallet();renderOrders();};
  $("submitPaymentBtn").onclick=()=>{const amount=Number($("depositAmount").value),utr=$("paymentUtr").value.trim();if(!Number.isFinite(amount)||amount<1||!utr){$("paymentMessage").textContent="सही Deposit Amount और UTR/reference number भरें।";return;}const a=account();a.deposits=a.deposits||[];a.deposits.push({amount,utr,status:"Pending verification",createdAt:new Date().toISOString()});saveAccount(a);$("paymentMessage").textContent="Deposit request pending है। Bank/UPI में payment verify होने के बाद ही balance add करें। यह local mode अपने-आप payment verify नहीं कर सकता।";$("depositAmount").value="";$("paymentUtr").value="";};
}
