const $ = id => document.getElementById(id);
const rp = n => 'Rp' + n.toLocaleString('id-ID');
let S = { user: null, plans: {} };

async function api(path, data) {
  const r = await fetch(path, { method: data ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' }, body: data ? JSON.stringify(data) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Terjadi kesalahan, coba lagi');
  return j;
}
function msg(t, good) { $('msg').textContent = t; $('msg').className = 'msg' + (good ? ' ok' : ''); }
async function act(fn, okText) {
  msg('');
  try { await fn(); if (okText) msg(okText, true); } catch (e) { msg(e.message); }
}
function show(w) { $('loginForm').hidden = w !== 'login'; $('regForm').hidden = w === 'login'; msg(''); }

function renderPlans() {
  const list = Object.entries(S.plans), cur = $('plan').value;
  $('plans').innerHTML = list.map(([k, p]) => `
    <div class="plan">
      <div><h3>${p.name}</h3><p>Hosting website dengan HTTPS aktif</p></div>
      <div class="price">${rp(p.price)} <small>${p.days >= 365 ? '/ tahun' : '/ bulan'}</small></div>
      <button class="btn" data-plan="${k}">Pilih paket</button>
    </div>`).join('');
  $('plan').innerHTML = list.map(([k, p]) => `<option value="${k}">${p.name} - ${rp(p.price)}</option>`).join('');
  if (cur) $('plan').value = cur;
}
function render() {
  const u = S.user;
  $('authBox').hidden = !!u;
  $('dash').hidden = !u;
  $('navAkun').textContent = u ? 'Akun' : 'Masuk';
  if (!u) return;
  const pn = u.plan === 'trial' ? 'Trial 1 bulan' : (S.plans[u.plan]?.name || 'Belum ada');
  $('st').textContent = `Halo, ${u.user}. Paket: ${pn}. ` + (u.active ? `Aktif sampai ${new Date(u.expires).toLocaleDateString('id-ID')}.` : 'Tidak aktif.');
  $('trial').hidden = !u.trialAvailable;
  $('orders').replaceChildren(...u.orders.map(o => {
    const li = document.createElement('li');
    li.textContent = `${S.plans[o.plan]?.name || o.plan} · ${o.ref} · ${o.status}`;
    return li;
  }));
}
async function load() {
  const d = await api('/api/me');
  S = { user: d.user ? d : null, plans: d.plans };
  renderPlans(); render();
}

$('doLogin').onclick = () => act(async () => {
  await api('/api/login', { username: $('lu').value, password: $('lp').value });
  await load();
});
$('doReg').onclick = () => act(async () => {
  await api('/api/register', { username: $('ru').value, email: $('re').value, password: $('rp').value });
  show('login');
}, 'Akun tersimpan. Silakan login.');
$('toReg').onclick = e => { e.preventDefault(); show('reg'); };
$('toLogin').onclick = e => { e.preventDefault(); show('login'); };
$('trial').onclick = () => act(async () => { await api('/api/trial', {}); await load(); }, 'Trial 1 bulan sudah aktif.');
$('order').onclick = () => act(async () => {
  await api('/api/order', { plan: $('plan').value, ref: $('ref').value });
  $('ref').value = '';
  await load();
}, 'Pesanan terkirim. Menunggu konfirmasi pembayaran.');
$('logout').onclick = () => act(async () => { await api('/api/logout', {}); await load(); });
document.addEventListener('click', e => {
  const p = e.target.dataset && e.target.dataset.plan;
  if (p) { $('plan').value = p; $('akun').scrollIntoView({ behavior: 'smooth' }); }
});
$('qr').onerror = () => { $('qr').hidden = true; };
load().catch(e => msg(e.message));
