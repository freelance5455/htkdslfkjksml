const $ = id => document.getElementById(id);
let selectedFile = null;
setTimeout(()=>{$("splash").classList.add("hidden");$("app").classList.remove("hidden")},1900);
$("dashboard").classList.remove("hidden");

$("projectFile").addEventListener("change",e=>{
  selectedFile=e.target.files[0]||null;
  $("fileInfo").classList.toggle("hidden",!selectedFile);
  $("fileInfo").textContent=selectedFile?`✓ ${selectedFile.name} · ${(selectedFile.size/1024/1024).toFixed(2)} MB`:"";
  $("build").disabled=!selectedFile;
});
$("build").addEventListener("click",async()=>{
  if(!selectedFile)return;
  const id=$("appId").value.trim();
  if(!/^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(id)){
    $("buildMsg").textContent="Package ID tidak valid. Contoh: com.fiqyy.aplikasi";return;
  }
  const data=new FormData();data.append("project",selectedFile);
  data.append("appName",$("appName").value);data.append("appId",id);
  $("build").disabled=true;$("build").textContent="Memproses...";
  try{
    const response=await fetch("/api/build",{method:"POST",body:data});
    const result=await response.json();
    $("buildMsg").textContent=result.error||"Build selesai.";
  }catch(e){$("buildMsg").textContent="Tidak dapat menghubungi server build. Pastikan backend aktif.";}
  finally{$("build").disabled=false;$("build").textContent="⚡ Build APK sekarang";}
});
