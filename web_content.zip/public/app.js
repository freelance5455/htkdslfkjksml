const state = { products: [], cart: {}, category: "All", query: "" };
const $ = (id) => document.getElementById(id);
const fmt = (amount) => "UGX " + new Intl.NumberFormat("en-UG", { maximumFractionDigits: 0 }).format(amount);
let toastTimer;
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
async function loadProducts() {
  const response = await fetch("/api/products");
  if (!response.ok) throw new Error("Could not load products");
  state.products = await response.json();
  renderProducts();
}
function renderProducts() {
  const filtered = state.products.filter(p =>
    (state.category === "All" || p.category === state.category) &&
    (p.name + " " + p.category + " " + p.description).toLowerCase().includes(state.query.toLowerCase())
  );
  $("product-total").textContent = `${filtered.length} product${filtered.length === 1 ? "" : "s"}`;
  $("empty-state").classList.toggle("hidden", filtered.length > 0);
  const grid = $("product-grid"); grid.replaceChildren();
  filtered.forEach((p, index) => {
    const card = document.createElement("article"); card.className = "product-card";
    const visual = document.createElement("div"); visual.className = "product-visual"; visual.style.background = ["linear-gradient(145deg,#f0f4ff,#e9edfb)","linear-gradient(145deg,#effaf6,#d8f4e8)","linear-gradient(145deg,#fff4e9,#f9e1c7)","linear-gradient(145deg,#f5efff,#e6dcff)"][index % 4];
    const stock = document.createElement("span"); stock.className = "stock-pill"; stock.textContent = p.stock > 0 ? `${p.stock} in stock` : "Out of stock";
    const emoji = document.createElement("span"); emoji.className = "product-emoji"; emoji.textContent = p.emoji;
    visual.append(stock, emoji);
    const info = document.createElement("div"); info.className = "product-info";
    const category = document.createElement("span"); category.className = "product-category"; category.textContent = p.category;
    const title = document.createElement("h3"); title.textContent = p.name;
    const desc = document.createElement("p"); desc.textContent = p.description;
    const bottom = document.createElement("div"); bottom.className = "product-bottom";
    const price = document.createElement("strong"); price.className = "price"; price.textContent = fmt(p.price);
    const add = document.createElement("button"); add.className = "add-button"; add.type = "button"; add.textContent = "+"; add.title = "Add to cart"; add.setAttribute("aria-label", `Add ${p.name} to cart`); add.disabled = p.stock < 1; add.style.opacity = add.disabled ? ".45" : "1"; add.addEventListener("click", () => addToCart(p.id));
    bottom.append(price, add); info.append(category, title, desc, bottom); card.append(visual, info); grid.append(card);
  });
}
function cartRows() {
  return Object.entries(state.cart).map(([id, quantity]) => {
    const p = state.products.find(item => item.id === id);
    return p ? { ...p, quantity } : null;
  }).filter(Boolean);
}
function total() { return cartRows().reduce((sum, p) => sum + p.price * p.quantity, 0); }
function addToCart(id) {
  const p = state.products.find(x => x.id === id); if (!p) return;
  if ((state.cart[id] || 0) >= Math.min(p.stock, 20)) return toast("Demo stock or quantity limit reached.");
  state.cart[id] = (state.cart[id] || 0) + 1; renderCart(); toast(`${p.name} added to cart.`);
}
function changeQty(id, delta) {
  const p = state.products.find(x => x.id === id); if (!p) return;
  const next = (state.cart[id] || 0) + delta;
  if (next <= 0) delete state.cart[id];
  else if (next <= Math.min(p.stock, 20)) state.cart[id] = next;
  else toast("Demo stock limit reached.");
  renderCart();
}
function renderCart() {
  const rows = cartRows();
  $("cart-count").textContent = rows.reduce((sum, p) => sum + p.quantity, 0);
  $("cart-total").textContent = fmt(total()); $("checkout-total").textContent = fmt(total());
  const container = $("cart-items"); container.replaceChildren();
  if (!rows.length) {
    const empty = document.createElement("div"); empty.className = "cart-empty"; empty.textContent = "Your cart is empty. Add a product to get started."; container.append(empty); return;
  }
  rows.forEach(p => {
    const row = document.createElement("div"); row.className = "cart-item";
    const art = document.createElement("div"); art.className = "cart-item-art"; art.textContent = p.emoji;
    const detail = document.createElement("div"); const title = document.createElement("h4"); title.textContent = p.name;
    const price = document.createElement("small"); price.textContent = fmt(p.price * p.quantity);
    const controls = document.createElement("div"); controls.className = "qty-controls";
    const minus = document.createElement("button"); minus.textContent = "−"; minus.setAttribute("aria-label", "Decrease quantity"); minus.onclick = () => changeQty(p.id, -1);
    const qty = document.createElement("span"); qty.textContent = p.quantity;
    const plus = document.createElement("button"); plus.textContent = "+"; plus.setAttribute("aria-label", "Increase quantity"); plus.onclick = () => changeQty(p.id, 1);
    controls.append(minus, qty, plus); detail.append(title, price, controls);
    const remove = document.createElement("button"); remove.className = "remove-item"; remove.textContent = "Remove"; remove.onclick = () => { delete state.cart[p.id]; renderCart(); };
    row.append(art, detail, remove); container.append(row);
  });
}
function openCart() {
  $("cart-panel").classList.add("open"); $("cart-panel").setAttribute("aria-hidden", "false"); $("cart-backdrop").classList.remove("hidden");
}
function closeCart() {
  $("cart-panel").classList.remove("open"); $("cart-panel").setAttribute("aria-hidden", "true"); $("cart-backdrop").classList.add("hidden");
}
$("cart-toggle").addEventListener("click", openCart);
$("cart-close").addEventListener("click", closeCart);
$("cart-backdrop").addEventListener("click", closeCart);
$("search").addEventListener("input", e => { state.query = e.target.value.trim(); renderProducts(); });
$("filters").addEventListener("click", e => {
  const button = e.target.closest("button[data-category]"); if (!button) return;
  state.category = button.dataset.category;
  $("filters").querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === button));
  renderProducts();
});
$("checkout-open").addEventListener("click", () => {
  if (!cartRows().length) return toast("Add at least one product first.");
  closeCart(); $("checkout-error").textContent = ""; $("checkout-modal").classList.remove("hidden");
});
$("checkout-close").addEventListener("click", () => $("checkout-modal").classList.add("hidden"));
$("checkout-modal").addEventListener("click", e => { if (e.target === $("checkout-modal")) $("checkout-modal").classList.add("hidden"); });
$("checkout-form").addEventListener("submit", async e => {
  e.preventDefault();
  const button = $("place-order"); button.disabled = true; button.textContent = "Saving order…"; $("checkout-error").textContent = "";
  const form = new FormData(e.currentTarget);
  const payload = {
    customer: { name: form.get("name"), phone: form.get("phone"), address: form.get("address") },
    paymentMethod: form.get("paymentMethod"),
    items: cartRows().map(p => ({ id: p.id, quantity: p.quantity }))
  };
  try {
    const response = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not place order.");
    $("checkout-modal").classList.add("hidden"); e.currentTarget.reset(); state.cart = {}; renderCart();
    alert(`Order received: ${data.order.id}\nTotal: ${fmt(data.order.total)}\nStatus: ${data.order.paymentStatus}\n\n${data.message}`);
  } catch (err) { $("checkout-error").textContent = err.message || "Network error. Please try again."; }
  finally { button.disabled = false; button.textContent = "Place test order"; }
});
loadProducts().catch(() => { $("product-grid").textContent = "Could not connect to the shop server. Please refresh."; });
renderCart();
