const $=id=>document.getElementById(id);
let ws=null, ticks=[], running=false, req=0;

function log(x){const t=new Date().toLocaleTimeString();$("log").textContent=`[${t}] ${x}\n`+$("log").textContent.slice(0,7000)}
function digitOf(price){
  const s=String(price);
  const d=(s.replace(/\D/g,'').slice(-1));
  return Number.isFinite(+d)?+d:null;
}
function entropy(counts,n){
  if(!n)return 0; let h=0;
  counts.forEach(c=>{if(c){const p=c/n;h-=p*Math.log2(p)}}); return h;
}
function metrics(){
  const w=Math.min(+$("window").value||200,ticks.length), a=ticks.slice(-w);
  if(!a.length)return;
  const ds=a.map(x=>x.digit).filter(x=>x!==null), c=Array(10).fill(0);
  ds.forEach(d=>c[d]++);
  const n=ds.length, ranked=c.map((v,i)=>({d:i,c:v})).sort((x,y)=>y.c-x.c);
  const top=ranked[0], second=ranked[1]||{c:0};
  const conf=n?Math.round((top.c/n)*100):0;
  const prices=a.map(x=>x.price), mean=prices.reduce((s,v)=>s+v,0)/prices.length;
  const sd=Math.sqrt(prices.reduce((s,v)=>s+(v-mean)**2,0)/prices.length);
  let streak=1; for(let i=ds.length-2;i>=0&&ds[i]===ds[ds.length-1];i--)streak++;
  $("price").textContent=a.at(-1).price;
  $("lastDigit").textContent=a.at(-1).digit;
  $("tickCount").textContent=ticks.length;
  $("volatility").textContent=sd.toFixed(5);
  $("entropy").textContent=entropy(c,n).toFixed(2);
  $("streak").textContent=`${streak} × ${ds.at(-1)}`;
  $("predDigit").textContent=top.d;
  $("confidence").textContent=conf+"%";
  $("predText").textContent=conf>=+$("threshold").value ? `Digit ${top.d} has the strongest historical frequency` : "No threshold-qualified signal";
  $("meterFill").style.width=Math.min(conf,100)+"%";
  $("meterFill").style.opacity=conf>=+$("threshold").value?"1":".45";
  $("bars").innerHTML=c.map((v,i)=>{
    const h=n?Math.max(3,(v/n)*180):3;
    return `<div class="bar-wrap"><span>${n?Math.round(v/n*100):0}%</span><div class="bar" style="height:${h}px"></div><span>${i}</span></div>`;
  }).join("");
}
function addTick(price,epoch){
  const d=digitOf(price); ticks.push({price:+price,digit:d,epoch});
  const max=Math.max(+$("window").value||200,1000); if(ticks.length>max)ticks.shift();
  metrics();
}
function connect(){
  if(ws)ws.close();
  ws=new WebSocket("wss://api.derivws.com/trading/v1/options/ws/public");
  ws.onopen=()=>{running=true;$("status").textContent="Connected • public tick stream";log("Connected to Deriv public WebSocket");
    ws.send(JSON.stringify({ticks:$("symbol").value,subscribe:1,req_id:++req}));
  };
  ws.onmessage=e=>{
    const d=JSON.parse(e.data);
    if(d.msg_type==="tick" && d.tick) addTick(d.tick.quote,d.tick.epoch);
    if(d.error) log("API error: "+d.error.message);
  };
  ws.onerror=()=>{log("WebSocket error");$("status").textContent="Connection error"};
  ws.onclose=()=>{running=false;$("status").textContent="Offline"};
}
function stop(){if(ws){ws.close();ws=null}running=false;$("status").textContent="Stopped"}
$("startBtn").onclick=connect;
$("stopBtn").onclick=stop;
$("clearBtn").onclick=()=>{ticks=[];metrics();$("log").textContent=""};
$("symbol").onchange=()=>{if(running)connect()};
$("oauthBtn").onclick=()=>{window.location.href="/auth/login"};
$("disconnectBtn").onclick=()=>{window.location.href="/auth/logout"};
metrics();
