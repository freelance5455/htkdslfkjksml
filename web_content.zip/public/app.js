'use strict';
const $ = id => document.getElementById(id);
let mode = 'html';
let selected = null;
const modeButtons = [...document.querySelectorAll('.mode')];

function setMode(nextMode) {
  if (nextMode === 'web') {
    alert('تحويل رابط URL غير متاح في هذه النسخة. استخدم ملف HTML أو ZIP.');
    return;
  }
  mode = nextMode;
  selected = null;
  $('file').value = '';
  $('fileName').textContent = 'لم يتم اختيار ملف بعد';
  modeButtons.forEach(button => button.classList.toggle('active', button.dataset.mode === mode));
  $('urlWrap').classList.add('hidden');
  $('drop').classList.remove('hidden');
  $('file').accept = mode === 'html' ? '.html,.htm,text/html' : '.zip,application/zip';
  $('dropTitle').textContent = mode === 'html' ? 'ارفع ملف HTML' : 'ارفع ملف ZIP';
  $('dropHint').textContent = mode === 'html'
    ? 'ارفع صفحة HTML واحدة. للمواقع التي تحتوي صوراً وملفات CSS استخدم ZIP.'
    : 'ارفع مشروع ZIP ويجب أن يحتوي على index.html';
}
modeButtons.forEach(button => button.addEventListener('click', () => {
  if (!button.disabled) setMode(button.dataset.mode);
}));
$('drop').addEventListener('click', () => $('file').click());
$('file').addEventListener('change', event => {
  selected = event.target.files?.[0] || null;
  $('fileName').textContent = selected
    ? `تم اختيار: ${selected.name} • ${(selected.size / 1024 / 1024).toFixed(2)} MB`
    : 'لم يتم اختيار ملف بعد';
});

function validPackage(value) {
  return /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(value);
}
function validVersion(value) {
  return /^\d+\.\d+\.\d+([.-][A-Za-z0-9.-]+)?$/.test(value);
}
function showMessage(message, percent, isError = false) {
  $('progress').classList.remove('hidden');
  $('message').textContent = message;
  $('message').style.color = isError ? '#ff8c9b' : '#b9d7f5';
  $('bar').style.width = `${Math.max(0, Math.min(100, percent))}%`;
}
function joinUrl(base, path) {
  return base.replace(/\/+$/, '') + '/' + String(path).replace(/^\/+/, '');
}
$('buildBtn').addEventListener('click', async () => {
  const server = $('server').value.trim().replace(/\/+$/, '');
  const appName = $('appName').value.trim();
  const packageId = $('packageId').value.trim();
  const version = $('version').value.trim();
  const buildNumber = Number($('build').value);

  if (!/^https?:\/\/[^ ]+$/i.test(server)) return alert('أدخل رابط خادم صحيح يبدأ بـ https:// أو http://');
  if (!selected) return alert('اختر ملف HTML أو ZIP أولاً.');
  if (mode === 'html' && !/\.html?$/i.test(selected.name)) return alert('اختر ملف HTML فقط.');
  if (mode === 'zip' && !/\.zip$/i.test(selected.name)) return alert('اختر ملف ZIP فقط.');
  if (!appName) return alert('أدخل اسم التطبيق.');
  if (!validPackage(packageId)) return alert('اسم الحزمة غير صحيح. مثال: com.yahia.myapp');
  if (!validVersion(version)) return alert('رقم الإصدار يجب أن يكون بالشكل 1.0.0');
  if (!Number.isSafeInteger(buildNumber) || buildNumber < 1) return alert('رقم البناء يجب أن يكون رقماً صحيحاً أكبر من صفر.');

  const form = new FormData();
  form.append('mode', mode);
  form.append('appName', appName);
  form.append('packageId', packageId);
  form.append('version', version);
  form.append('buildNumber', String(buildNumber));
  form.append('project', selected, selected.name);

  const headers = {};
  const apiKey = $('apiKey').value.trim();
  if (apiKey) headers['x-build-api-key'] = apiKey;

  $('buildBtn').disabled = true;
  showMessage('جاري إرسال المشروع إلى خادم البناء...', 8);
  try {
    const response = await fetch(joinUrl(server, '/api/build'), { method: 'POST', body: form, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `خطأ من الخادم (${response.status})`);
    if (!data.jobId) throw new Error('الخادم لم يرجع رقم مهمة صالحاً.');
    showMessage(`تم استلام المشروع. رقم المهمة: ${data.jobId}`, 15);
    await pollBuild(server, data.jobId, headers);
  } catch (error) {
    showMessage(`تعذر البناء: ${error.message}`, 0, true);
  } finally {
    $('buildBtn').disabled = false;
  }
});

async function pollBuild(server, jobId, headers) {
  for (let attempt = 0; attempt < 240; attempt++) {
    await new Promise(resolve => setTimeout(resolve, 3000));
    const response = await fetch(joinUrl(server, `/api/build/${encodeURIComponent(jobId)}`), { headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `تعذر قراءة حالة البناء (${response.status})`);
    const percent = data.status === 'done' ? 100 : Math.min(94, 18 + attempt * 0.32);
    showMessage(data.message || 'جاري البناء...', percent, data.status === 'error');
    if (data.status === 'done') {
      const download = joinUrl(server, data.downloadUrl);
      $('message').textContent = 'اكتمل البناء. اضغط زر تنزيل APK بالأسفل.';
      const old = document.getElementById('downloadApk');
      if (old) old.remove();
      const link = document.createElement('a');
      link.id = 'downloadApk';
      link.href = download;
      link.textContent = 'تنزيل ملف APK';
      link.className = 'download-apk';
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      $('progress').appendChild(link);
      return;
    }
    if (data.status === 'error') throw new Error(data.error || 'فشل البناء.');
  }
  throw new Error('استغرق البناء وقتاً أطول من المتوقع. تحقق من حالة الخادم.');
}

// Prefer Capacitor's native Browser plugin when available; otherwise use a normal HTTPS tab.
document.querySelectorAll('.follow-link').forEach(link => {
  link.addEventListener('click', async event => {
    event.preventDefault();
    const url = link.href;
    try {
      const browserPlugin = window.Capacitor?.Plugins?.Browser;
      if (browserPlugin?.open) {
        await browserPlugin.open({ url });
        return;
      }
    } catch (error) {
      console.warn('Native browser open failed; using browser fallback.', error);
    }
    const opened = window.open(url, '_blank', 'noopener,noreferrer');
    if (!opened) window.location.href = url;
  });
});
