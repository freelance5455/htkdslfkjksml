const state = {
  all: [],
  filtered: [],
  categories: ['Todos'],
  category: 'Todos',
  city: 'Portugal inteiro',
  query: '',
  selected: null,
  liveEvents: 0,
};

const $ = (selector) => document.querySelector(selector);
const feed = $('#wish-feed');
const template = $('#wish-card-template');
const mapPins = $('#map-pins');
const toast = $('#map-toast');
let toastTimer;

function formatRelative(date) {
  const diff = Math.max(0, Math.floor((Date.now() - new Date(date).getTime()) / 60000));
  if (diff < 1) return 'agora';
  if (diff === 1) return 'há 1 min';
  if (diff < 60) return `há ${diff} min`;
  return `há ${Math.floor(diff / 60)} h`;
}

function categoryClass(wish) {
  return ['buscando pistas', 'confirmar hoje'].includes(wish.status) ? 'searching' : '';
}

function applyFilters() {
  const q = state.query.toLowerCase().trim();
  state.filtered = state.all.filter((wish) => {
    const matchesQuery = !q || [wish.item, wish.place, wish.zone, wish.category, ...(wish.tags || [])].join(' ').toLowerCase().includes(q);
    const matchesCategory = state.category === 'Todos' || wish.category === state.category;
    const matchesCity = state.city === 'Portugal inteiro' || wish.city === state.city;
    return matchesQuery && matchesCategory && matchesCity;
  });
  renderFeed();
  renderMap();
  $('#result-count').textContent = state.filtered.length;
  $('#feed-title').textContent = state.query || state.category !== 'Todos' || state.city !== 'Portugal inteiro' ? 'Resultados no radar' : 'O que estão procurando';
}

function renderCategories() {
  const root = $('#category-filters');
  root.replaceChildren();
  state.categories.forEach((category) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `filter-chip ${state.category === category ? 'active' : ''}`;
    button.textContent = category;
    button.addEventListener('click', () => {
      state.category = category;
      renderCategories();
      applyFilters();
    });
    root.append(button);
  });
}

function renderMetrics(summary) {
  $('#metric-wishes').textContent = summary.wishes;
  $('#metric-available').textContent = summary.available;
  $('#metric-cities').textContent = summary.cities;
}

function renderFeed() {
  feed.replaceChildren();
  if (!state.filtered.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = '<strong>Nenhum sinal ainda.</strong>Tente outra busca ou coloque este desejo no mapa.';
    feed.append(empty);
    return;
  }
  state.filtered.slice(0, 18).forEach((wish, index) => {
    const card = template.content.cloneNode(true);
    const article = card.querySelector('.wish-card');
    const button = card.querySelector('.card-button');
    card.querySelector('.category-label').textContent = wish.category;
    card.querySelector('time').textContent = wish.updatedAt || 'agora';
    card.querySelector('h3').textContent = wish.item;
    card.querySelector('.place').textContent = `${wish.place} · ${wish.city}`;
    card.querySelector('.zone').textContent = wish.zone;
    const chip = card.querySelector('.status-chip');
    chip.textContent = wish.status;
    if (categoryClass(wish)) chip.classList.add('searching');
    if (state.selected === wish.id) button.classList.add('selected');
    article.style.animationDelay = `${Math.min(index * 24, 180)}ms`;
    button.addEventListener('click', () => selectWish(wish.id, true));
    feed.append(card);
  });
}

function pinPosition(wish, index) {
  const city = wish.coordinates || { x: 29, y: 65 };
  const sameCity = state.filtered.filter((item) => item.city === wish.city);
  const offset = sameCity.indexOf(wish) - (sameCity.length - 1) / 2;
  return { left: 46 + city.x * 0.44 + offset * 1.9, top: 4.5 + city.y * 0.91 + (index % 2 ? 0.7 : 0) };
}

function renderMap() {
  mapPins.replaceChildren();
  state.filtered.slice(0, 30).forEach((wish, index) => {
    const pin = document.createElement('button');
    pin.type = 'button';
    pin.className = `map-pin ${wish.placeType === 'comunidade' ? 'community' : 'market'} ${wish.source === 'sinal ao vivo' ? 'live' : ''} ${state.selected === wish.id ? 'active' : ''}`;
    const position = pinPosition(wish, index);
    pin.style.left = `${position.left}%`;
    pin.style.top = `${position.top}%`;
    pin.setAttribute('aria-label', `${wish.item} em ${wish.city}`);
    const label = document.createElement('span');
    label.className = 'pin-label';
    label.textContent = `${wish.item} · ${wish.city}`;
    pin.append(label);
    pin.addEventListener('click', () => selectWish(wish.id, false));
    mapPins.append(pin);
  });
}

function selectWish(id, fromCard) {
  state.selected = id;
  const wish = state.all.find((item) => item.id === id);
  if (!wish) return;
  renderFeed();
  renderMap();
  showToast(`${wish.item} · ${wish.city}`);
  if (fromCard) {
    const selected = feed.querySelector('.selected');
    selected?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

function showToast(message) {
  $('#toast-text').textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add('hidden'), 4200);
}

function updateConnection(connected) {
  $('#connection-label').textContent = connected ? 'mapa ao vivo conectado' : 'reconectando ao mapa vivo';
  $('#last-update').textContent = connected ? `atualizado às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : 'tentando reconectar…';
}

async function loadInitial() {
  const [wishResponse, summaryResponse] = await Promise.all([fetch('/api/wishes'), fetch('/api/summary')]);
  const wishData = await wishResponse.json();
  const summary = await summaryResponse.json();
  state.all = wishData.items;
  state.categories = ['Todos', ...summary.categories.filter((category) => category !== 'Todos')];
  renderMetrics(summary);
  renderCategories();
  applyFilters();
  updateConnection(false);
}

function connectLive() {
  const events = new EventSource('/api/events');
  events.addEventListener('connected', () => updateConnection(true));
  events.addEventListener('wish:live', (event) => {
    const wish = JSON.parse(event.data);
    state.all = [wish, ...state.all.filter((item) => item.id !== wish.id)];
    state.liveEvents += 1;
    state.selected = wish.id;
    applyFilters();
    showToast(`novo sinal: ${wish.item} em ${wish.city}`);
    $('#last-update').textContent = `novo sinal às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
  });
  events.addEventListener('wish:new', (event) => {
    const wish = JSON.parse(event.data);
    state.all = [wish, ...state.all.filter((item) => item.id !== wish.id)];
    state.selected = wish.id;
    applyFilters();
    showToast('seu desejo entrou no mapa');
  });
  events.addEventListener('summary', (event) => renderMetrics(JSON.parse(event.data)));
  events.onerror = () => updateConnection(false);
}

function setModal(open) {
  const modal = $('#modal');
  modal.hidden = !open;
  if (open) $('#wish-form input[name="item"]').focus();
}

async function submitWish(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const status = $('#form-status');
  const formData = new FormData(form);
  const payload = Object.fromEntries(formData.entries());
  payload.consent = formData.get('consent') === 'on';
  status.className = 'form-status';
  status.textContent = 'colocando no mapa…';
  try {
    const response = await fetch('/api/wishes', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Não foi possível salvar.');
    form.reset();
    setModal(false);
    showToast('desejo adicionado — obrigado por compartilhar');
  } catch (error) {
    status.className = 'form-status error';
    status.textContent = error.message;
  }
}

$('#open-wish').addEventListener('click', () => setModal(true));
$('#close-modal').addEventListener('click', () => setModal(false));
$('#modal').addEventListener('click', (event) => { if (event.target === $('#modal')) setModal(false); });
$('#wish-form').addEventListener('submit', submitWish);
$('#search').addEventListener('input', (event) => { state.query = event.target.value; applyFilters(); });
$('#city-filter').addEventListener('change', (event) => { state.city = event.target.value; applyFilters(); });
$('#clear-filters').addEventListener('click', () => {
  state.category = 'Todos'; state.city = 'Portugal inteiro'; state.query = '';
  $('#search').value = ''; $('#city-filter').value = 'Portugal inteiro'; renderCategories(); applyFilters();
});
$('#show-all').addEventListener('click', () => { state.category = 'Todos'; state.city = 'Portugal inteiro'; state.query = ''; $('#search').value = ''; $('#city-filter').value = 'Portugal inteiro'; renderCategories(); applyFilters(); });
$('#locate-me').addEventListener('click', () => showToast('Para proteger sua privacidade, escolha a cidade manualmente'));
$('#mobile-filter').addEventListener('click', () => { const open = $('#sidebar').classList.toggle('filters-open'); $('#mobile-filter').setAttribute('aria-expanded', String(open)); });
document.addEventListener('keydown', (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#search').focus(); }
  if (event.key === 'Escape') setModal(false);
});

loadInitial().catch((error) => {
  console.error(error);
  $('#connection-label').textContent = 'servidor indisponível';
  feed.innerHTML = '<div class="empty-state"><strong>Não foi possível carregar o mapa.</strong>Confira se o servidor está rodando e tente novamente.</div>';
});
connectLive();
