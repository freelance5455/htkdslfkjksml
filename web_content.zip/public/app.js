// EDITO X AI Studio Web App Client Engine

let currentService = 'Video Editing';
let currentUpiId = '8018948884@paytm';
let merchantName = 'Edito X AI Studio';

document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initServicePills();
    initPaymentTriggers();
    initOrderForm();
    initDashboard();
    initTracker();
    initSettings();
    loadStudioConfig();
    loadDashboardData();
});

// Toast notification helper
function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.style.borderColor = isError ? 'var(--danger)' : 'var(--primary)';
    toast.style.display = 'block';
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3500);
}

// 1. Navigation Tabs
function initTabs() {
    const tabs = document.querySelectorAll('.nav-tab');
    const panes = document.querySelectorAll('.tab-pane');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            panes.forEach(p => p.classList.remove('active'));

            tab.classList.add('active');
            const target = tab.getAttribute('data-tab');
            document.getElementById(target).classList.add('active');

            if (target === 'dashboard-tab') {
                loadDashboardData();
            }
        });
    });
}

// 2. Service Selection
function initServicePills() {
    const pills = document.querySelectorAll('.pill-btn');
    pills.forEach(pill => {
        pill.addEventListener('click', () => {
            pills.forEach(p => p.classList.remove('active'));
            pill.classList.add('active');
            currentService = pill.getAttribute('data-service');
        });
    });
}

function setBudget(val) {
    document.getElementById('orderBudget').value = val;
}

// Package Selector from Showreel tab
function selectPackage(serviceName, budgetVal) {
    currentService = serviceName;
    const pills = document.querySelectorAll('.pill-btn');
    pills.forEach(p => {
        if (p.getAttribute('data-service') === serviceName) {
            p.classList.add('active');
        } else {
            p.classList.remove('active');
        }
    });

    const budgetInput = document.getElementById('orderBudget');
    if (budgetInput) budgetInput.value = budgetVal;

    // Switch to order tab
    const orderTabBtn = document.querySelector('[data-tab="order-tab"]');
    if (orderTabBtn) orderTabBtn.click();
    showToast(`Selected ${serviceName} package (₹${budgetVal})`);
}

// 3. Studio Config Loader
async function loadStudioConfig() {
    try {
        const res = await fetch('/api/config');
        const data = await res.json();
        if (data.upi_id) {
            currentUpiId = data.upi_id;
            document.getElementById('displayUpi').textContent = currentUpiId;
            document.getElementById('modalUpiId').textContent = currentUpiId;
            document.getElementById('settingUpiId').value = currentUpiId;
        }
        if (data.merchant_name) {
            merchantName = data.merchant_name;
        }
    } catch (err) {
        console.error('Config fetch failed', err);
    }
}

// 4. Payment Triggers & QR Code
function getUpiLink(amount, note) {
    const budget = amount || document.getElementById('orderBudget').value || '1500';
    const noteText = note || `Edito X - ${currentService}`;
    return `upi://pay?pa=${encodeURIComponent(currentUpiId)}&pn=${encodeURIComponent(merchantName)}&am=${budget}&tn=${encodeURIComponent(noteText)}&cu=INR`;
}

function initPaymentTriggers() {
    const payBtn = document.getElementById('openUpiAppBtn');
    const qrBtn = document.getElementById('viewQrBtn');
    const qrModal = document.getElementById('qrModal');
    const closeQr = document.getElementById('closeQrModal');
    const copyUpi = document.getElementById('copyUpiBtn');

    // Pay via App
    payBtn.addEventListener('click', () => {
        const budget = document.getElementById('orderBudget').value || '1500';
        const clientName = document.getElementById('clientName').value || 'Client';
        const note = `Order for ${clientName} - ${currentService}`;
        const upiUrl = getUpiLink(budget, note);
        window.location.href = upiUrl;
    });

    // Show QR Code
    qrBtn.addEventListener('click', () => {
        const budget = document.getElementById('orderBudget').value || '1500';
        const clientName = document.getElementById('clientName').value || 'Client';
        const note = `Order for ${clientName} - ${currentService}`;
        const upiUrl = getUpiLink(budget, note);

        document.getElementById('modalAmount').textContent = `₹${budget}`;
        document.getElementById('modalUpiId').textContent = currentUpiId;

        const canvas = document.getElementById('qrCanvas');
        if (window.QRCode) {
            QRCode.toCanvas(canvas, upiUrl, {
                width: 220,
                margin: 2,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            }, (error) => {
                if (error) console.error(error);
            });
        }
        qrModal.classList.add('active');
    });

    closeQr.addEventListener('click', () => {
        qrModal.classList.remove('active');
    });

    copyUpi.addEventListener('click', () => {
        navigator.clipboard.writeText(currentUpiId);
        showToast('UPI ID copied to clipboard!');
    });
}

// 5. Submit Order Form
function initOrderForm() {
    const form = document.getElementById('orderForm');
    const successModal = document.getElementById('successModal');
    const viewDashBtn = document.getElementById('modalViewDashBtn');
    const closeSuccessBtn = document.getElementById('modalCloseSuccessBtn');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const submitBtn = document.getElementById('submitOrderBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting Project...';

        const orderData = {
            client_name: document.getElementById('clientName').value,
            client_contact: document.getElementById('clientContact').value,
            service_type: currentService,
            budget: document.getElementById('orderBudget').value,
            deadline: document.getElementById('orderDeadline').value,
            file_link: document.getElementById('fileLink').value,
            instructions: document.getElementById('instructions').value,
            transaction_id: document.getElementById('transactionId').value
        };

        try {
            const res = await fetch('/api/orders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });
            const result = await res.json();

            if (res.ok && result.success) {
                document.getElementById('assignedOrderId').textContent = `Order #${result.order.id}`;
                successModal.classList.add('active');
                form.reset();
                loadDashboardData();
            } else {
                showToast(result.error || 'Failed to submit order', true);
            }
        } catch (err) {
            showToast('Network error while placing order.', true);
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Creative Order & Start Production';
        }
    });

    closeSuccessBtn.addEventListener('click', () => {
        successModal.classList.remove('active');
    });

    viewDashBtn.addEventListener('click', () => {
        successModal.classList.remove('active');
        document.querySelector('[data-tab="dashboard-tab"]').click();
    });
}

// 6. Admin Dashboard
function initDashboard() {
    document.getElementById('refreshOrdersBtn').addEventListener('click', loadDashboardData);
    document.getElementById('adminSearchInput').addEventListener('input', debounce(loadOrdersList, 300));
    document.getElementById('filterStatusSelect').addEventListener('change', loadOrdersList);
    document.getElementById('filterServiceSelect').addEventListener('change', loadOrdersList);

    // Export Report
    document.getElementById('exportOrdersBtn').addEventListener('click', async () => {
        try {
            const res = await fetch('/api/orders');
            const data = await res.json();
            if (!data.orders || data.orders.length === 0) {
                showToast('No orders to export');
                return;
            }

            let csvContent = "data:text/csv;charset=utf-8,ID,Client Name,Contact,Service,Budget,Deadline,Status,Created At\n";
            data.orders.forEach(o => {
                csvContent += `"${o.id}","${o.client_name}","${o.client_contact}","${o.service_type}","${o.budget}","${o.deadline || ''}","${o.payment_status}","${o.created_at}"\n`;
            });

            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `Edito_X_Orders_${new Date().toISOString().slice(0,10)}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showToast('Orders report exported successfully!');
        } catch (err) {
            showToast('Failed to export report', true);
        }
    });
}

async function loadDashboardData() {
    loadStats();
    loadOrdersList();
}

async function loadStats() {
    try {
        const res = await fetch('/api/stats');
        const data = await res.json();
        if (data.stats) {
            document.getElementById('statTotalOrders').textContent = data.stats.totalOrders;
            document.getElementById('statTotalRevenue').textContent = `₹${data.stats.totalRevenue.toLocaleString()}`;
            document.getElementById('statInProgress').textContent = data.stats.inProgress;
            document.getElementById('statCompleted').textContent = data.stats.completedOrders;
            document.getElementById('order-count-badge').textContent = data.stats.totalOrders;
        }
    } catch (err) {
        console.error('Stats error:', err);
    }
}

async function loadOrdersList() {
    const tableBody = document.getElementById('ordersTableBody');
    const search = document.getElementById('adminSearchInput').value;
    const status = document.getElementById('filterStatusSelect').value;
    const service = document.getElementById('filterServiceSelect').value;

    try {
        const url = `/api/orders?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}&service=${encodeURIComponent(service)}`;
        const res = await fetch(url);
        const data = await res.json();

        if (!data.orders || data.orders.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align:center; padding: 40px; color: var(--text-dim);">
                        <i class="fa-solid fa-folder-open" style="font-size: 28px; margin-bottom: 8px; display:block;"></i>
                        No orders match your filter criteria.
                    </td>
                </tr>
            `;
            return;
        }

        tableBody.innerHTML = data.orders.map(order => {
            const cleanPhone = (order.client_contact || '').replace(/[^0-9]/g, '');
            const waMsg = encodeURIComponent(`Hi ${order.client_name}! Regarding your ${order.service_type} project (Order #${order.id}) with Edito X Studio:`);

            return `
                <tr>
                    <td><span class="order-id-chip">#${order.id}</span></td>
                    <td>
                        <span class="client-name">${escapeHtml(order.client_name)}</span>
                        <span class="client-phone"><i class="fa-solid fa-phone"></i> ${escapeHtml(order.client_contact)}</span>
                    </td>
                    <td>
                        <span class="service-badge">${escapeHtml(order.service_type)}</span>
                        <span class="deadline-tag"><i class="fa-solid fa-calendar"></i> ${order.deadline || 'Standard'}</span>
                    </td>
                    <td><span class="budget-val">₹${order.budget}</span></td>
                    <td>
                        <select class="status-select" onchange="updateOrderStatus(${order.id}, this.value)">
                            <option value="Pending Payment" ${order.payment_status === 'Pending Payment' ? 'selected' : ''}>Pending Payment</option>
                            <option value="Paid via UPI" ${order.payment_status === 'Paid via UPI' ? 'selected' : ''}>Paid via UPI</option>
                            <option value="In Progress" ${order.payment_status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                            <option value="Completed" ${order.payment_status === 'Completed' ? 'selected' : ''}>Completed</option>
                            <option value="Delivered" ${order.payment_status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                        </select>
                    </td>
                    <td>
                        <div class="action-btns">
                            <a href="https://wa.me/${cleanPhone}?text=${waMsg}" target="_blank" class="action-icon wa" title="WhatsApp Client">
                                <i class="fa-brands fa-whatsapp"></i>
                            </a>
                            <a href="tel:${cleanPhone}" class="action-icon call" title="Call Client">
                                <i class="fa-solid fa-phone"></i>
                            </a>
                            ${order.file_link ? `<a href="${escapeHtml(order.file_link)}" target="_blank" class="action-icon drive" title="Open Assets Drive"><i class="fa-brands fa-google-drive"></i></a>` : ''}
                        </div>
                    </td>
                    <td>
                        <button class="action-icon del" onclick="deleteOrder(${order.id})" title="Delete Order">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (err) {
        tableBody.innerHTML = `<tr><td colspan="7" style="color:var(--danger); text-align:center; padding:20px;">Failed to load orders.</td></tr>`;
    }
}

async function updateOrderStatus(id, newStatus) {
    try {
        const res = await fetch(`/api/orders/${id}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });
        const result = await res.json();
        if (res.ok) {
            showToast(`Order #${id} updated to ${newStatus}`);
            loadStats();
        } else {
            showToast(result.error || 'Failed to update status', true);
        }
    } catch (err) {
        showToast('Network error updating status', true);
    }
}

async function deleteOrder(id) {
    if (!confirm(`Are you sure you want to delete Order #${id}?`)) return;

    try {
        const res = await fetch(`/api/orders/${id}`, { method: 'DELETE' });
        if (res.ok) {
            showToast(`Order #${id} deleted.`);
            loadDashboardData();
        } else {
            showToast('Failed to delete order', true);
        }
    } catch (err) {
        showToast('Error deleting order', true);
    }
}

// 7. Project Tracker
function initTracker() {
    const input = document.getElementById('trackInput');
    const btn = document.getElementById('trackSearchBtn');
    const container = document.getElementById('trackResultContainer');

    btn.addEventListener('click', async () => {
        const query = input.value.trim();
        if (!query) {
            showToast('Please enter an Order ID or Phone number', true);
            return;
        }

        try {
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Searching...';
            const res = await fetch(`/api/track/${encodeURIComponent(query)}`);
            const data = await res.json();

            if (res.ok && data.order) {
                renderTrackingResult(data.order, container);
                container.style.display = 'block';
            } else {
                container.innerHTML = `
                    <div style="text-align:center; padding: 20px; color: var(--text-dim);">
                        <i class="fa-solid fa-circle-exclamation" style="font-size: 28px; margin-bottom: 8px; color: var(--warning); display:block;"></i>
                        No order found for "<strong>${escapeHtml(query)}</strong>". Please verify your Order ID or contact the studio.
                    </div>
                `;
                container.style.display = 'block';
            }
        } catch (err) {
            showToast('Failed to track order', true);
        } finally {
            btn.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i> Track Status';
        }
    });
}

function renderTrackingResult(order, container) {
    const steps = [
        'Order Placed',
        'Payment Verified',
        'In Production',
        'Quality Review',
        'Delivered'
    ];

    let currentIndex = 0;
    if (order.payment_status === 'Paid via UPI') currentIndex = 1;
    if (order.payment_status === 'In Progress') currentIndex = 2;
    if (order.payment_status === 'Completed') currentIndex = 3;
    if (order.payment_status === 'Delivered') currentIndex = 4;

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 16px; border-bottom: 1px solid var(--border-color); padding-bottom: 12px;">
            <div>
                <h3 style="font-size: 20px; font-weight:800; color:var(--primary);">Order #${order.id}</h3>
                <span style="font-size: 14px; color: var(--text-muted); font-weight:600;">${escapeHtml(order.service_type)}</span>
            </div>
            <div class="secure-badge" style="font-size: 13px;">${escapeHtml(order.payment_status)}</div>
        </div>

        <div class="timeline">
            ${steps.map((step, idx) => {
                const isDone = idx < currentIndex;
                const isActive = idx === currentIndex;
                const cls = isDone ? 'done' : (isActive ? 'active' : '');
                return `
                    <div class="timeline-step ${cls}">
                        <div class="timeline-dot">
                            ${isDone ? '<i class="fa-solid fa-check"></i>' : (isActive ? '<i class="fa-solid fa-circle"></i>' : '')}
                        </div>
                        <h4 style="font-size: 14px; font-weight: ${isActive ? '700' : '500'}; color: ${isDone || isActive ? '#fff' : 'var(--text-dim)'};">${step}</h4>
                    </div>
                `;
            }).join('')}
        </div>

        <div style="margin-top: 20px; background: rgba(0,0,0,0.25); padding: 14px; border-radius: var(--radius-md); font-size: 13px;">
            <div style="display:flex; justify-content:space-between; margin-bottom: 6px;">
                <span style="color:var(--text-muted);">Client:</span>
                <strong>${escapeHtml(order.client_name)}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; margin-bottom: 6px;">
                <span style="color:var(--text-muted);">Agreed Budget:</span>
                <strong style="color:var(--primary);">₹${order.budget}</strong>
            </div>
            <div style="display:flex; justify-content:space-between;">
                <span style="color:var(--text-muted);">Target Deadline:</span>
                <strong>${order.deadline || 'Standard'}</strong>
            </div>
        </div>
    `;
}

// 8. Settings Dialog
function initSettings() {
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settingsModal');
    const closeBtn = document.getElementById('closeSettingsModal');
    const cancelBtn = document.getElementById('cancelSettingsBtn');
    const form = document.getElementById('settingsForm');

    settingsBtn.addEventListener('click', () => {
        settingsModal.classList.add('active');
    });

    const hide = () => settingsModal.classList.remove('active');
    closeBtn.addEventListener('click', hide);
    cancelBtn.addEventListener('click', hide);

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            upi_id: document.getElementById('settingUpiId').value,
            telegram_bot_token: document.getElementById('settingBotToken').value,
            telegram_chat_id: document.getElementById('settingChatId').value
        };

        try {
            const res = await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if (res.ok) {
                showToast('Studio settings saved successfully!');
                currentUpiId = payload.upi_id;
                document.getElementById('displayUpi').textContent = currentUpiId;
                hide();
            } else {
                showToast('Failed to save settings', true);
            }
        } catch (err) {
            showToast('Error saving settings', true);
        }
    });
}

function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
