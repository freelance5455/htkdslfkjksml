const $ = (id) => document.getElementById(id);
const messagesEl = $("messages"), welcome = $("welcome"), promptEl = $("prompt");
let history = [];
let conversations = [];
let busy = false;

function renderMessage(role, content) {
  welcome.style.display = "none";
  const row = document.createElement("div");
  row.className = `message ${role === "user" ? "user" : "assistant"}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "K" : "N";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = content; // Text only: never inject model output as HTML.
  row.append(avatar, bubble);
  messagesEl.append(row);
  messagesEl.parentElement.scrollTop = messagesEl.parentElement.scrollHeight;
}

function updateHistoryList() {
  const list = $("historyList");
  list.replaceChildren();
  conversations.forEach((c, i) => {
    const b = document.createElement("button");
    b.className = "history-item" + (i === conversations.length - 1 ? " active" : "");
    b.textContent = c.title;
    b.onclick = () => loadConversation(i);
    list.append(b);
  });
}
function loadConversation(i) {
  history = [...conversations[i].messages];
  messagesEl.replaceChildren();
  welcome.style.display = history.length ? "none" : "";
  history.forEach(m => renderMessage(m.role, m.content));
  closeSidebar();
}
function newChat() {
  if (history.length) conversations.push({title: history.find(m=>m.role==="user")?.content.slice(0,34) || "Percakapan baru", messages:[...history]});
  history = [];
  messagesEl.replaceChildren();
  welcome.style.display = "";
  updateHistoryList();
  closeSidebar();
}
async function sendMessage(text) {
  const message = text.trim();
  if (!message || busy) return;
  busy = true; $("sendBtn").disabled = true;
  renderMessage("user", message);
  const prior = [...history];
  history.push({role:"user",content:message});
  const typing = document.createElement("div");
  typing.className = "typing"; typing.textContent = "✦ NexusAI sedang berpikir...";
  messagesEl.append(typing);
  messagesEl.parentElement.scrollTop = messagesEl.parentElement.scrollHeight;
  try {
    const response = await fetch("/api/chat", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message,history:prior})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Server error ${response.status}`);
    const answer = data.answer || "AI belum memberikan jawaban.";
    history.push({role:"assistant",content:answer});
    renderMessage("assistant",answer);
  } catch (err) {
    const messageError = "Gagal menghubungi AI: " + err.message;
    renderMessage("assistant",messageError);
    history.push({role:"assistant",content:messageError});
  } finally {
    typing.remove(); busy=false; $("sendBtn").disabled=false; promptEl.focus();
  }
}
$("chatForm").addEventListener("submit", e => {
  e.preventDefault(); const value=promptEl.value; promptEl.value=""; promptEl.style.height="auto"; sendMessage(value);
});
promptEl.addEventListener("input",()=>{promptEl.style.height="auto";promptEl.style.height=Math.min(promptEl.scrollHeight,130)+"px";});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
$("newChat").onclick=newChat;
$("menuBtn").onclick=()=>{$("sidebar").classList.add("open");$("scrim").classList.add("show");};
$("scrim").onclick=closeSidebar;
function closeSidebar(){$("sidebar").classList.remove("open");$("scrim").classList.remove("show");}
