import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-functions.js";
import { getFirestore, collection, getDocs, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";

// Replace these values with your Firebase project's web-app configuration.
const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_FIREBASE_APP_ID"
};
const OWNER_EMAIL = "exhibetalanjandro@gmail.com";
const $ = id => document.getElementById(id);
const authBox = $("auth"), profileBox = $("profile"), appBox = $("app");
let auth, db, setName;
const ready = firebaseConfig.apiKey.startsWith("AIza") && !firebaseConfig.projectId.startsWith("PASTE_");
if (ready) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app);
  setName = httpsCallable(getFunctions(app), "setDisplayName");
  onAuthStateChanged(auth, user => refresh(user));
} else {
  $("authMsg").textContent = "Setup needed: add your Firebase web configuration in public/app.js.";
}
function show(el, yes) { el.classList.toggle("hidden", !yes); }
function refresh(user) {
  show(authBox, !user); show(appBox, !!user);
  if (!user) { show(profileBox, false); $("role").textContent = ""; return; }
  const owner = user.email === OWNER_EMAIL && user.emailVerified;
  $("role").textContent = owner ? "OWNER" : "MEMBER";
  $("addScript").classList.toggle("hidden", !owner);
  show(profileBox, true);
  $("displayName").value = user.displayName || "";
  loadScripts();
}
$("google").onclick = async () => { try { await signInWithPopup(auth, new GoogleAuthProvider()); } catch(e) { $("authMsg").textContent = e.message; } };
$("signup").onclick = async () => { try { await createUserWithEmailAndPassword(auth, $("email").value.trim(), $("password").value); } catch(e) { $("authMsg").textContent = e.message; } };
$("login").onclick = async () => { try { await signInWithEmailAndPassword(auth, $("email").value.trim(), $("password").value); } catch(e) { $("authMsg").textContent = e.message; } };
$("logout").onclick = () => signOut(auth);
$("saveName").onclick = async () => {
  try { const result = await setName({displayName: $("displayName").value}); $("nameMsg").textContent = "Name saved: " + result.data.displayName; }
  catch(e) { $("nameMsg").textContent = e.message; }
};
async function loadScripts() {
  if (!db) return;
  const list = $("scriptList"); list.innerHTML = "";
  try {
    const snap = await getDocs(collection(db, "scripts"));
    if (snap.empty) $("scriptHint").textContent = "No scripts published yet.";
    snap.forEach(doc => {
      const data = doc.data(), item = document.createElement("div");
      item.className = "script";
      const title = document.createElement("b"); title.textContent = data.title || "Untitled";
      const desc = document.createElement("p"); desc.textContent = data.description || "";
      item.append(title, desc); list.append(item);
    });
  } catch(e) { $("scriptHint").textContent = "Could not load scripts: " + e.message; }
}
$("addScript").onclick = async () => {
  const title = prompt("Script title"); if (!title) return;
  const description = prompt("Script description / key information") || "";
  try { await addDoc(collection(db, "scripts"), {title, description, createdAt: serverTimestamp()}); loadScripts(); }
  catch(e) { alert("Publish failed: " + e.message); }
};
document.querySelectorAll(".tab").forEach(btn => btn.onclick = () => {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b === btn));
  document.querySelectorAll(".tabpage").forEach(p => show(p, p.id === btn.dataset.tab));
});
$("themeToggle").onclick = () => document.body.classList.toggle("light");
