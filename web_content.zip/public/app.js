const socket=io();
let me=null, selected=null, allUsers=[];
const $=id=>document.getElementById(id);

$("join").onclick=()=>{
  const name=$("name").value.trim()||"مستخدم";
  const fakeNumber=$("number").value.trim();
  socket.emit("register",{name,fakeNumber},res=>{
    if(!res?.ok) return alert(res.error);
    me=res.user;
    $("myNumber").textContent=me.fakeNumber;
    $("login").classList.add("hidden");
    $("app").classList.remove("hidden");
  });
};

socket.on("users", users=>{
  allUsers=users.filter(u=>u.fakeNumber!==me?.fakeNumber);
  renderUsers();
});
function renderUsers(){
  const q=$("search").value.trim().toLowerCase();
  $("users").innerHTML="";
  allUsers.filter(u=>(u.name+" "+u.fakeNumber).toLowerCase().includes(q)).forEach(u=>{
    const d=document.createElement("div");
    d.className="user "+(u.online?"online":"");
    d.innerHTML=`<b>${esc(u.name)}</b><span class="dot"></span><span class="num">${u.fakeNumber} • ${u.online?"متصل":"غير متصل"}</span>`;
    d.onclick=()=>openChat(u);
    $("users").appendChild(d);
  });
}
$("search").oninput=renderUsers;

function openChat(u){
  selected=u;
  $("chatHead").innerHTML=`<b>${esc(u.name)}</b><small>${u.fakeNumber} • ${u.online?"متصل الآن":"غير متصل"}</small>`;
  $("text").disabled=false;$("form").querySelector("button").disabled=false;
  $("messages").innerHTML="";
  socket.emit("get_history",{withUser:u.fakeNumber},res=>{
    (res.messages||[]).forEach(addMessage);
    scroll();
  });
  $("app").classList.add("chat-open");
}
socket.on("message",msg=>{
  if(selected && (msg.from===selected.fakeNumber||msg.to===selected.fakeNumber)) addMessage(msg);
  scroll();
});
function addMessage(m){
  const d=document.createElement("div");
  d.className="bubble "+(m.from===me.fakeNumber?"mine":"");
  const t=new Date(m.time).toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"});
  d.innerHTML=`${esc(m.text)} <span class="time">${t} ${m.from===me.fakeNumber?"✓✓":""}</span>`;
  $("messages").appendChild(d);
}
$("form").onsubmit=e=>{
  e.preventDefault();
  if(!selected)return;
  const text=$("text").value.trim(); if(!text)return;
  socket.emit("send_message",{to:selected.fakeNumber,text},res=>{
    if(!res?.ok) alert(res.error); else $("text").value="";
  });
};
$("text").oninput=()=>{
  if(selected) socket.emit("typing",{to:selected.fakeNumber});
};
socket.on("typing",({from})=>{
  if(selected?.fakeNumber===from){
    $("typing").textContent="يكتب الآن...";
    clearTimeout(window.typingTimer);
    window.typingTimer=setTimeout(()=>$("typing").textContent="",1000);
  }
});
function scroll(){$("messages").scrollTop=$("messages").scrollHeight}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
