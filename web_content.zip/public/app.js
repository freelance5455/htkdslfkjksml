const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safe=u=>/^https?:\/\//i.test(u)?u:'#';
async function api(m,u,b){const r=await fetch(u,{method:m,credentials:'same-origin',headers:{'Content-Type':'application/json','X-Requested-With':'fetch'},body:b?JSON.stringify(b):undefined});let j={};try{j=await r.json()}catch(e){}if(r.status===401&&u!=='/api/login')location.reload();if(!r.ok){const e=new Error(j.e||'error');e.status=r.status;throw e}return j}
let me=null,custom=[],cases=[],cur=null,activeCase=0,hist=[];
// {q}=مشفّر · {r}=الرابط/النص كما هو (encodeURI) · {n}=الأرقام فقط (ASN)
const fill=(u,v)=>u.replace(/\{q\}/g,encodeURIComponent(v)).replace(/\{r\}/g,encodeURI(v)).replace(/\{n\}/g,v.replace(/\D/g,''));
const T={
user:[['WhatsMyName','https://whatsmyname.app/?q={q}','hundreds of sites'],['Google','https://www.google.com/search?q=%22{q}%22','exact match'],['GitHub','https://github.com/{q}','dev account'],['X','https://x.com/{q}','account'],['Instagram','https://www.instagram.com/{q}/','account'],['TikTok','https://www.tiktok.com/@{q}','account'],['Reddit','https://www.reddit.com/user/{q}','activity'],['Telegram','https://t.me/{q}','user/channel']],
email:[['HIBP','https://haveibeenpwned.com/account/{q}','known breaches'],['Epieos','https://epieos.com/?q={q}&t=email','linked accounts'],['EmailRep','https://emailrep.io/{q}','reputation'],['Intelligence X','https://intelx.io/?s={q}','leaks'],['Google','https://www.google.com/search?q=%22{q}%22','web mentions']],
domain:[['Whois','https://who.is/whois/{q}','registration'],['crt.sh','https://crt.sh/?q={q}','subdomains via SSL'],['SecurityTrails','https://securitytrails.com/domain/{q}/dns','DNS history'],['URLScan','https://urlscan.io/search/#{q}','past scans'],['VirusTotal','https://www.virustotal.com/gui/domain/{q}','reputation'],['BuiltWith','https://builtwith.com/{q}','tech stack'],['Shodan','https://www.shodan.io/search?query={q}','exposed services'],['Wayback','https://web.archive.org/web/*/{q}','site history']],
ip:[['Shodan','https://www.shodan.io/host/{q}','ports/services'],['Censys','https://search.censys.io/hosts/{q}','certs/services'],['AbuseIPDB','https://www.abuseipdb.com/check/{q}','abuse reports'],['VirusTotal','https://www.virustotal.com/gui/ip-address/{q}','reputation'],['IPinfo','https://ipinfo.io/{q}','geo/ISP'],['BGP HE','https://bgp.he.net/ip/{q}','ASN'],['GreyNoise','https://viz.greynoise.io/ip/{q}','scanner noise']],
phone:[['Google','https://www.google.com/search?q=%22{q}%22','mentions'],['Sync.me','https://sync.me/search/?number={q}','caller name'],['WhatsApp','https://wa.me/{q}','WA presence'],['Telegram','https://t.me/{q}','linked account']],
name:[['Google','https://www.google.com/search?q=%22{q}%22','exact match'],['LinkedIn','https://www.linkedin.com/search/results/people/?keywords={q}','professional'],['Facebook','https://www.facebook.com/search/people/?q={q}','social'],['Archive.org','https://archive.org/search?query={q}','documents']],
img:[['Google Lens','https://lens.google.com/uploadbyurl?url={q}','reverse search'],['TinEye','https://tineye.com/search?url={q}','earliest use'],['Yandex','https://yandex.com/images/search?rpt=imageview&url={q}','faces/places'],['Bing Visual','https://www.bing.com/images/search?view=detailv2&iss=sbi&q=imgurl:{q}','alt']],
url:[['URLScan','https://urlscan.io/search/#{q}','scan history'],['VirusTotal','https://www.virustotal.com/gui/search/{q}','reputation'],['Wayback','https://web.archive.org/web/*/{r}','page history'],['archive.today','https://archive.ph/{r}','snapshots'],['Safe Browsing','https://transparencyreport.google.com/safe-browsing/search?url={q}','Google status'],['Hybrid Analysis','https://www.hybrid-analysis.com/search?query={q}','sandbox reports'],['Google','https://www.google.com/search?q=%22{q}%22','mentions']],
hash:[['VirusTotal','https://www.virustotal.com/gui/file/{q}','detections'],['MalwareBazaar','https://bazaar.abuse.ch/browse.php?search={q}','samples'],['Hybrid Analysis','https://www.hybrid-analysis.com/search?query={q}','sandbox reports'],['AlienVault OTX','https://otx.alienvault.com/indicator/file/{q}','threat intel'],['Triage','https://tria.ge/s?q={q}','sandbox'],['Google','https://www.google.com/search?q=%22{q}%22','mentions']],
crypto:[['Blockchair','https://blockchair.com/search?q={q}','multi-chain'],['Blockchain.com','https://www.blockchain.com/explorer/search?search={q}','BTC/ETH'],['Etherscan','https://etherscan.io/address/{q}','ETH address'],['WalletExplorer','https://www.walletexplorer.com/address/{q}','BTC clusters'],['ChainAbuse','https://www.chainabuse.com/address/{q}','scam reports'],['Bitcoin Abuse','https://www.bitcoinabuse.com/reports/{q}','abuse reports'],['Google','https://www.google.com/search?q=%22{q}%22','mentions']],
asn:[['bgp.he.net','https://bgp.he.net/AS{n}','prefixes/peers'],['BGPView','https://bgpview.io/asn/{n}','details'],['PeeringDB','https://www.peeringdb.com/search?q={q}','network info'],['IPinfo','https://ipinfo.io/AS{n}','summary'],['Shodan','https://www.shodan.io/search?query=asn%3AAS{n}','exposed hosts'],['Censys','https://search.censys.io/search?resource=hosts&q=autonomous_system.asn%3A{n}','hosts']],
cve:[['NVD','https://nvd.nist.gov/vuln/detail/{q}','official record'],['CVE.org','https://www.cve.org/CVERecord?id={q}','CVE record'],['GitHub Advisories','https://github.com/advisories?query={q}','advisories'],['CISA KEV','https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext={q}','exploited in the wild'],['Vulners','https://vulners.com/search?query={q}','aggregator'],['Google','https://www.google.com/search?q=%22{q}%22','write-ups']]};
const TT=Object.keys(T);
const links=(t,v)=>[...(T[t]||[]),...custom.filter(x=>x.type==t).map(x=>[x.name,x.url,x.descr])].map(([n,u,d])=>[n,fill(u,v),d||'']);
// تعرّف تلقائي على نوع القيمة
function detect(v){v=v.trim();const ip4=/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(v);
if(/^https?:\/\/\S+\.(png|jpe?g|gif|webp)(\?\S*)?$/i.test(v))return'img';if(/^https?:\/\/\S+$/i.test(v))return'url';
if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))return'email';if(/^CVE-\d{4}-\d{4,}$/i.test(v))return'cve';if(/^AS\d{1,10}$/i.test(v))return'asn';
if(ip4&&ip4.slice(1).every(x=>+x<=255))return'ip';if(/^[0-9a-f:]{2,39}$/i.test(v)&&(v.match(/:/g)||[]).length>=2)return'ip';
if(/^([a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/i.test(v))return'hash';if(/^0x[a-fA-F0-9]{40}$/.test(v)||/^(bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(v))return'crypto';
if(/^\+?[\d\s().-]{7,20}$/.test(v)&&v.replace(/\D/g,'').length>=7&&v.replace(/\D/g,'').length<=15)return'phone';
if(/^(?!-)([a-z0-9-]{1,63}\.)+[a-z]{2,24}$/i.test(v))return'domain';return null}
const CLI=[['Sherlock','username hunt','pipx install sherlock-project','sherlock {q}'],['Maigret','username dossier','pipx install maigret','maigret {q}'],['Holehe','email → sites','pipx install holehe','holehe {q}'],['theHarvester','emails/subdomains','sudo apt install theharvester','theHarvester -d {q} -b all'],['Subfinder','subdomains','go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest','subfinder -d {q}'],['Amass','attack surface map','sudo apt install amass','amass enum -d {q}'],['httpx','probe live hosts','go install github.com/projectdiscovery/httpx/cmd/httpx@latest','httpx -u {q}'],['dnsx','DNS toolkit','go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest','echo {q} | dnsx -a -resp'],['whois','registration','sudo apt install whois','whois {q}'],['dig','DNS records','sudo apt install dnsutils','dig {q} ANY +noall +answer'],['gau','archived URLs','go install github.com/lc/gau/v2/cmd/gau@latest','gau {q}'],['PhoneInfoga','phone info','docker pull sundowndev/phoneinfoga','docker run --rm -it sundowndev/phoneinfoga scan -n {q}'],['ExifTool','file metadata','sudo apt install libimage-exiftool-perl','exiftool {q}'],['WhatWeb','web fingerprint','sudo apt install whatweb','whatweb {q}'],['Nmap','port scan (authorized only)','sudo apt install nmap','nmap -sV {q}'],['SpiderFoot','automation UI','pip install spiderfoot','spiderfoot -l 127.0.0.1:5001'],['Recon-ng','recon framework','sudo apt install recon-ng','recon-ng']];
const D=[['Username',[['WhatsMyName','https://whatsmyname.app'],['Namechk','https://namechk.com'],['Sherlock','https://github.com/sherlock-project/sherlock'],['Maigret','https://github.com/soxoj/maigret']]],['Email',[['HIBP','https://haveibeenpwned.com'],['Epieos','https://epieos.com'],['Hunter','https://hunter.io'],['Holehe','https://github.com/megadose/holehe']]],['Domain',[['crt.sh','https://crt.sh'],['DNSDumpster','https://dnsdumpster.com'],['SecurityTrails','https://securitytrails.com'],['Amass','https://github.com/owasp-amass/amass']]],['IP / Network',[['Shodan','https://www.shodan.io'],['Censys','https://search.censys.io'],['GreyNoise','https://viz.greynoise.io'],['BGPView','https://bgpview.io']]],['Social',[['Social Searcher','https://www.social-searcher.com'],['TGStat','https://tgstat.com'],['Instaloader','https://github.com/instaloader/instaloader']]],['Images / Video',[['TinEye','https://tineye.com'],['InVID','https://www.invid-project.eu'],['FotoForensics','https://fotoforensics.com'],['ExifTool','https://exiftool.org']]],['Geolocation',[['Sentinel Hub','https://apps.sentinel-hub.com/eo-browser/'],['Wigle','https://wigle.net'],['SunCalc','https://www.suncalc.org'],['GeoHints','https://geohints.com']]],['Leaks / Dark Web',[['Intelligence X','https://intelx.io'],['DeHashed','https://dehashed.com'],['Ahmia','https://ahmia.fi']]],['Threat Intel',[['VirusTotal','https://www.virustotal.com'],['URLScan','https://urlscan.io'],['AlienVault OTX','https://otx.alienvault.com'],['MISP','https://www.misp-project.org']]],['Malware / Hashes',[['MalwareBazaar','https://bazaar.abuse.ch'],['Hybrid Analysis','https://www.hybrid-analysis.com'],['Triage','https://tria.ge'],['ANY.RUN','https://any.run']]],['Vulnerabilities / CVE',[['NVD','https://nvd.nist.gov'],['CVE.org','https://www.cve.org'],['CISA KEV','https://www.cisa.gov/known-exploited-vulnerabilities-catalog'],['GitHub Advisories','https://github.com/advisories']]],['Crypto / Blockchain',[['Blockchair','https://blockchair.com'],['Etherscan','https://etherscan.io'],['WalletExplorer','https://www.walletexplorer.com'],['ChainAbuse','https://www.chainabuse.com']]],['Records / Companies',[['OpenCorporates','https://opencorporates.com'],['OCCRP Aleph','https://aleph.occrp.org'],['Wikidata','https://www.wikidata.org']]],['Training',[['OSINT Framework','https://osintframework.com'],['Bellingcat Toolkit','https://bellingcat.gitbook.io/toolkit'],['Trace Labs','https://www.tracelabs.org'],['OSINT Curious','https://osintcurio.us']]]];

// ---------- مظهر ----------
function theme(t){if(!['cyan','green','amber','light'].includes(t))t='cyan';document.documentElement.dataset.theme=t==='cyan'?'':t;try{localStorage.setItem('osint_theme',t)}catch(e){}$('#th').value=t}
theme((()=>{try{return localStorage.getItem('osint_theme')}catch(e){return'cyan'}})());
$('#th').onchange=e=>theme(e.target.value);

// ---------- الدخول ----------
$('#lb').onclick=async()=>{const e=$('#le');e.style.color='var(--er)';e.textContent='';const n=$('#lu').value.trim(),p=$('#lp').value,two=!$('#lc').classList.contains('hide');if(!n||!p)return e.textContent='أدخل البيانات';
const body={n,p};if(two){const c=$('#lc').value.trim();if(!c)return e.textContent='أدخل رمز التحقق';body.c=c}
try{const r=await api('POST','/api/login',body);if(r.need2fa){$('#lc').classList.remove('hide');$('#lc').focus();e.style.color='var(--mu)';return e.textContent='أدخل رمز تطبيق المصادقة (أو رمز استرجاع)'}
me=r;$('#lp').value=$('#lc').value='';$('#lc').classList.add('hide');enter()}catch(x){e.textContent=x.status==429?'محاولات كثيرة، حاول بعد قليل':'بيانات الدخول غير صحيحة'}};
['lu','lp','lc'].forEach(i=>$('#'+i).onkeydown=e=>{if(e.key=='Enter')$('#lb').click()});
async function enter(){const[a,b]=await Promise.all([api('GET','/api/tools').catch(()=>[]),api('GET','/api/cases').catch(()=>[])]);custom=Array.isArray(a)?a:[];cases=Array.isArray(b)?b:[];
try{activeCase=+localStorage.getItem('osint_ac_'+me.n)||0}catch(e){activeCase=0}if(!cases.some(c=>c.id==activeCase&&c.status=='open'))activeCase=0;
$('#auth').classList.add('hide');$('#app').classList.remove('hide');$('#who').textContent='USER: '+me.n+' ['+me.r+']'+(me.f?' 🔒':'');$('#adt').classList.toggle('hide',me.r!=='admin');$('#ps').textContent=me.n+'@osint:~$';$('#out').innerHTML='';
pr('<span class="g">[ OSINT://TERMINAL ready ]</span>');pr('اكتب <b>help</b> أو الصق أي قيمة (إيميل، دومين، IP، رابط، hash، CVE…) وبيتعرّف عليها تلقائيًا','m');if(!me.f)pr('⚠ فعّل التحقق بخطوتين من تبويب ACCOUNT','r');renderAll();renderCaseSel();loadHist()}
$('#lo').onclick=()=>api('POST','/api/logout').catch(()=>{}).finally(()=>location.reload());

// ---------- الطرفية ----------
function pr(h,c){const d=document.createElement('div');if(c)d.className=c;d.innerHTML=h;$('#out').appendChild(d);$('#out').scrollTop=1e9}
async function addItem(body){if(!activeCase)return false;try{await api('POST','/api/cases/'+activeCase+'/items',body);return true}catch(x){pr('[!] case: '+esc(x.message),'r');return false}}
async function search(t,v){const ls=links(t,v);api('POST','/api/search',{t,v:v.slice(0,200)}).then(loadHist).catch(()=>{});pr('[*] target: '+esc(v)+' ('+t+')','m');
ls.forEach(([n,u,d])=>pr('[+] <a href="'+esc(safe(u))+'" target="_blank" rel="noopener noreferrer">'+esc(n)+'</a> <span class="m">- '+esc(d)+'</span>'));
pr('[✓] '+ls.length+' sources ready (click to open) <button class="cp" data-act="copy" data-t="'+t+'" data-v="'+esc(v)+'">copy links</button>','g');
if(activeCase){const c=cases.find(x=>x.id==activeCase);if(await addItem({kind:'search',type:t,value:v.slice(0,200)}))pr('[+] saved to case: '+esc(c?c.title:'#'+activeCase),'m')}}
async function run(c){c=c.trim();pr('<span class="g">'+esc(me.n)+'$</span> '+esc(c));const[a0,...r]=c.split(/\s+/),a=a0.toLowerCase(),v=r.join(' ');
if(a=='help')return pr('commands:\n  <value>                 تعرّف تلقائي: email / domain / ip / url / hash / cve / asn / crypto / phone\n  user|email|domain|ip|phone|name|img|url|hash|crypto|asn|cve &lt;value&gt;\n  auto &lt;value&gt;          فرض التعرّف التلقائي\n  note &lt;text&gt;          ملاحظة في الحالة النشطة\n  cases   tools   index   whoami   clear   logout','m');
if(a=='clear')return $('#out').innerHTML='';if(a=='whoami')return pr(esc(me.n)+' ('+me.r+')'+(me.f?' · 2FA on':' · 2FA off'));if(a=='logout')return $('#lo').click();
if(a=='tools')return tab('c');if(a=='index')return tab('d');if(a=='cases')return tab('k');
if(a=='note'){if(!v)return pr('usage: note &lt;text&gt;','r');if(!activeCase)return pr('اختر حالة نشطة أولًا (ACTIVE CASE)','r');return await addItem({kind:'note',text:v})&&pr('[+] note saved','g')}
if(TT.includes(a)){if(!v)return pr('usage: '+a+' &lt;value&gt;','r');return search(a,v)}
if(a=='auto'){const t=detect(v);return t?(pr('[auto] '+t,'m'),search(t,v)):pr('ما قدرت أحدد نوع القيمة، استخدم: user|name|… &lt;value&gt;','r')}
const t=detect(c);if(t){pr('[auto] '+t,'m');return search(t,c)}pr('command not found: '+esc(a0),'r')}
$('#cmd').onkeydown=e=>{if(e.key=='Enter'&&e.target.value.trim()){run(e.target.value);e.target.value=''}};
$('#out').onclick=async e=>{const b=e.target.closest('button[data-act]');if(!b)return;const ls=links(b.dataset.t,b.dataset.v).map(([n,u])=>n+': '+u).join('\n');try{await navigator.clipboard.writeText(ls);b.textContent='copied ✓'}catch(x){b.textContent='failed'}};
$('#qk').innerHTML=TT.map(t=>'<button data-p="'+t+'">'+t+'</button>').join('');$('#qk').onclick=e=>{if(e.target.dataset.p){$('#cmd').value=e.target.dataset.p+' ';$('#cmd').focus()}};
async function loadHist(){try{hist=await api('GET','/api/history')}catch(e){hist=[]}$('#hs').innerHTML=hist.slice(0,12).map((h,i)=>'<button data-h="'+i+'" title="'+esc(h.value)+'">↻ '+esc(h.type)+': '+esc(h.value.slice(0,22))+'</button>').join('')}
$('#hs').onclick=e=>{const h=hist[+e.target.dataset.h];if(h)run(h.type+' '+h.value)};
function renderCaseSel(){const o=cases.filter(c=>c.status=='open');$('#ac').innerHTML='<option value="0">— none —</option>'+o.map(c=>'<option value="'+c.id+'"'+(c.id==activeCase?' selected':'')+'>'+esc(c.title)+'</option>').join('')}
$('#ac').onchange=e=>{activeCase=+e.target.value;try{localStorage.setItem('osint_ac_'+me.n,activeCase)}catch(x){}pr(activeCase?'[case] active: '+esc(e.target.selectedOptions[0].textContent):'[case] none','m')};

// ---------- التبويبات ----------
const TABS=['t','k','c','d','m','a'];
function tab(t){document.querySelectorAll('#nv button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));TABS.forEach(i=>$('#'+i).classList.toggle('hide',i!=t));if(t=='a')renderAdmin();if(t=='k')showList();if(t=='m')renderTwoFA()}
$('#nv').onclick=e=>{if(e.target.dataset.t)tab(e.target.dataset.t)};
const dl=(name,mime,text)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime}));a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)};
const cp=async(el,text)=>{try{await navigator.clipboard.writeText(text);el.textContent='copied ✓'}catch(x){el.textContent='failed'}};

// ---------- الحالات ----------
const fail=(id,x)=>{$(id).style.color='var(--er)';$(id).textContent=x.message};
async function loadCases(){cases=await api('GET','/api/cases');renderCaseSel();renderCases()}
function renderCases(){$('#kc').innerHTML=cases.length?cases.map(c=>'<div class="card"><b>'+esc(c.title)+'</b> <span class="tag'+(c.status=='open'?' on':'')+'">'+c.status+'</span> <span class="m">'+esc(c.target||'')+' · '+c.n+' items · '+esc(c.updated_at)+'</span><div class="bar"><button class="cp" data-o="'+c.id+'">OPEN</button></div></div>').join(''):'<span class="m">لا توجد حالات بعد — أنشئ حالة وفعّلها من ACTIVE CASE لتُحفظ بحوثك تلقائيًا</span>'}
function showList(){$('#kd').classList.add('hide');$('#kl').classList.remove('hide');loadCases().catch(()=>{})}
$('#kn').onclick=async()=>{$('#ke').textContent='';try{await api('POST','/api/cases',{title:$('#kt').value,target:$('#kg').value});$('#kt').value=$('#kg').value='';await loadCases()}catch(x){fail('#ke',x)}};
$('#kc').onclick=e=>{if(e.target.dataset.o)openCase(+e.target.dataset.o)};
async function openCase(id){try{cur=await api('GET','/api/cases/'+id)}catch(x){return}renderCase();$('#kl').classList.add('hide');$('#kd').classList.remove('hide')}
function itemHtml(it){const h='<span class="m">'+esc(it.created_at)+'</span> <button class="d cp" data-di="'+it.id+'">del</button>';
if(it.kind=='search')return'<div class="card"><b>SEARCH</b> '+esc(it.type)+': '+esc(it.value)+' '+h+'<div class="links" style="margin-top:6px">'+links(it.type,it.value).map(([n,u])=>'<a href="'+esc(safe(u))+'" target="_blank" rel="noopener noreferrer">'+esc(n)+'</a>').join('')+'</div></div>';
if(it.kind=='note')return'<div class="card"><b>NOTE</b> '+h+'<div style="white-space:pre-wrap;margin-top:4px">'+esc(it.text)+'</div></div>';
return'<div class="card"><b>LINK</b> <a href="'+esc(safe(it.value))+'" target="_blank" rel="noopener noreferrer">'+esc(it.text||it.value)+'</a> '+h+'</div>'}
function renderCase(){const{case:c,items}=cur;$('#kd').innerHTML='<div class="bar"><button id="kb">← BACK</button><button id="ku">'+(activeCase==c.id?'ACTIVE ✓':'USE IN TERMINAL')+'</button><button id="ks">'+(c.status=='open'?'CLOSE CASE':'REOPEN')+'</button><button id="km">EXPORT .md</button><button id="kj">EXPORT .json</button><button id="kx" class="d">DELETE</button></div>'
+'<h2>'+esc(c.title)+'</h2><div class="m">'+esc(c.target||'')+' · '+c.status+' · '+esc(c.created_at)+'</div><div id="ki" style="margin-top:12px">'+(items.map(itemHtml).join('')||'<span class="m">فارغة — ابحث من الطرفية والحالة نشطة، أو أضف ملاحظة</span>')+'</div>'
+'<h3>ADD NOTE</h3><textarea id="kn2" maxlength="5000" placeholder="note…"></textarea><button id="kna">ADD NOTE</button><h3>ADD LINK</h3><input id="kl1" placeholder="https://…"><input id="kl2" placeholder="label (optional)"><button id="kla">ADD LINK</button><div class="err" id="kde"></div>'}
const reopen=async()=>{await openCase(cur.case.id)};
$('#kd').onclick=async e=>{const id=e.target.id,c=cur&&cur.case;if(e.target.dataset.di)return act('#kde',async()=>{await api('DELETE','/api/cases/'+c.id+'/items/'+e.target.dataset.di);await reopen()});if(!id)return;
if(id=='kb')return showList();
if(id=='ku'){activeCase=c.id;try{localStorage.setItem('osint_ac_'+me.n,activeCase)}catch(x){}renderCaseSel();return renderCase()}
if(id=='ks')return act('#kde',async()=>{await api('PUT','/api/cases/'+c.id,{status:c.status=='open'?'closed':'open'});if(activeCase==c.id&&c.status=='open'){activeCase=0}await loadCases();await reopen()});
if(id=='km')return dl('case-'+c.id+'.md','text/markdown',caseMd(cur));if(id=='kj')return dl('case-'+c.id+'.json','application/json',JSON.stringify(cur,null,2));
if(id=='kx'){if(!confirm('حذف الحالة نهائيًا؟'))return;return act('#kde',async()=>{await api('DELETE','/api/cases/'+c.id);if(activeCase==c.id)activeCase=0;await loadCases();showList()})}
if(id=='kna')return act('#kde',async()=>{await api('POST','/api/cases/'+c.id+'/items',{kind:'note',text:$('#kn2').value});await reopen()});
if(id=='kla')return act('#kde',async()=>{await api('POST','/api/cases/'+c.id+'/items',{kind:'link',value:$('#kl1').value.trim(),text:$('#kl2').value});await reopen()})};
function caseMd({case:c,items}){let o='# '+c.title+'\n\n- Target: '+(c.target||'-')+'\n- Status: '+c.status+'\n- Created: '+c.created_at+'\n- Exported: '+new Date().toISOString()+'\n\n> Authorized & legal use only.\n\n';
for(const it of items){if(it.kind=='search')o+='## Search — '+it.type+': '+it.value+'\n_'+it.created_at+'_\n\n'+links(it.type,it.value).map(([n,u,d])=>'- ['+n+']('+u+')'+(d?' — '+d:'')).join('\n')+'\n\n';
else if(it.kind=='note')o+='## Note\n_'+it.created_at+'_\n\n'+it.text.split('\n').map(l=>'> '+l).join('\n')+'\n\n';else o+='## Link\n- ['+(it.text||it.value)+']('+it.value+')\n\n'}return o}

// ---------- أدوات CLI والفهرس ----------
function renderCLI(){const t=$('#tg').value.trim()||'TARGET';$('#cl').innerHTML=CLI.map(([n,d,i,r])=>'<div class="card"><b>'+n+'</b> <span class="m">'+d+'</span><code>'+esc(i)+'</code> <button class="cp" data-c="'+esc(i)+'">copy install</button><code>'+esc(fill(r,t))+'</code> <button class="cp" data-c="'+esc(fill(r,t))+'">copy run</button></div>').join('')}
$('#tg').oninput=renderCLI;$('#cl').onclick=e=>{if(e.target.dataset.c)cp(e.target,e.target.dataset.c)};
function renderDir(){const f=$('#f').value.toLowerCase();$('#dir').innerHTML=D.map(([c,a])=>{const x=a.filter(([n])=>!f||n.toLowerCase().includes(f)||c.toLowerCase().includes(f));return x.length?'<div class="card"><b>'+esc(c)+'</b><div class="links" style="margin-top:6px">'+x.map(([n,u])=>'<a href="'+esc(safe(u))+'" target="_blank" rel="noopener noreferrer">'+esc(n)+'</a>').join('')+'</div></div>':''}).join('')}
$('#f').oninput=renderDir;
function renderAll(){renderCLI();renderDir();$('#ty').innerHTML=TT.map(t=>'<option>'+t+'</option>').join('')}

// ---------- الحساب: كلمة المرور + 2FA ----------
$('#cp2').onclick=async()=>{const e=$('#pe');e.textContent='';try{await api('POST','/api/me/password',{o:$('#op').value,p:$('#pw').value});$('#op').value=$('#pw').value='';e.style.color='var(--ok)';e.textContent='✓ changed'}catch(x){fail('#pe',x)}};
$('#hc').onclick=async()=>{try{await api('DELETE','/api/history');await loadHist();$('#he').style.color='var(--ok)';$('#he').textContent='✓ cleared'}catch(x){fail('#he',x)}};
function renderTwoFA(){$('#fe').textContent='';$('#tf').innerHTML=me.f?'<p><span class="tag on">2FA ON</span> لتعطيله أدخل كلمة المرور ورمزًا (من التطبيق أو رمز استرجاع)</p><input id="f1" type="password" placeholder="password" autocomplete="current-password"><input id="f2" placeholder="code / recovery code" autocomplete="one-time-code"><button id="fd" class="d">DISABLE 2FA</button>':'<p><span class="tag">2FA OFF</span> يحمي حسابك حتى لو تسربت كلمة المرور. تحتاج تطبيق مثل Google Authenticator أو Aegis أو 2FAS.</p><button id="fs">ENABLE 2FA</button>'}
$('#tf').onclick=async e=>{const id=e.target.id;if(!id)return;$('#fe').textContent='';
if(id=='fs')try{const r=await api('POST','/api/me/2fa/setup',{});$('#tf').innerHTML='<p>1) افتح تطبيق المصادقة وأضف حساب جديد بهذا المفتاح (أو اضغط الرابط إذا التطبيق على نفس الجهاز):</p><div class="sec">'+esc(r.secret)+'</div><div class="bar"><button class="cp" id="fc">copy key</button><a href="'+esc(r.uri)+'">open in authenticator app</a></div><p>2) اكتب الرمز المكوّن من 6 أرقام:</p><input id="f3" inputmode="numeric" maxlength="6" placeholder="123456" autocomplete="one-time-code"><button id="fe2">CONFIRM</button>';window._sec=r.secret}catch(x){fail('#fe',x)}
if(id=='fc')cp(e.target,window._sec);
if(id=='fe2')try{const r=await api('POST','/api/me/2fa/enable',{c:$('#f3').value.trim()});me.f=true;$('#who').textContent='USER: '+me.n+' ['+me.r+'] 🔒';$('#tf').innerHTML='<p><span class="tag on">2FA ON ✓</span></p><p class="r">احفظ رموز الاسترجاع هذي الحين في مكان آمن — كل رمز يعمل مرة وحدة، وما تظهر مرة ثانية:</p><div class="sec">'+r.codes.map(esc).join('<br>')+'</div><div class="bar"><button class="cp" id="fk">copy codes</button></div>';window._codes=r.codes.join('\n')}catch(x){fail('#fe',x)}
if(id=='fk')cp(e.target,window._codes);
if(id=='fd')try{await api('POST','/api/me/2fa/disable',{p:$('#f1').value,c:$('#f2').value});me.f=false;$('#who').textContent='USER: '+me.n+' ['+me.r+']';renderTwoFA()}catch(x){fail('#fe',x)}};

// ---------- الأدمن ----------
const need=()=>me&&me.r==='admin';
async function renderAdmin(){if(!need())return;try{const[us,ts,lg]=await Promise.all([api('GET','/api/admin/users'),api('GET','/api/tools'),api('GET','/api/admin/log')]);custom=ts;
$('#ul').innerHTML='<table class="tb"><tr><th>user</th><th>role</th><th>2FA</th><th></th></tr>'+us.map(u=>'<tr><td>'+esc(u.username)+'</td><td>'+esc(u.role)+'</td><td>'+(u.totp_on?'<span class="tag on">on</span> <button class="cp" data-r2="'+u.id+'">reset</button>':'<span class="tag">off</span>')+'</td><td>'+(u.username==me.n?'':'<button class="d cp" data-du="'+u.id+'">del</button>')+'</td></tr>').join('')+'</table>';
$('#ct').innerHTML=ts.length?'<table class="tb">'+ts.map(x=>'<tr><td>'+esc(x.type)+'</td><td>'+esc(x.name)+'</td><td><button class="d cp" data-dt="'+x.id+'">del</button></td></tr>').join('')+'</table>':'<span class="m">no custom tools</span>';
$('#lg').innerHTML=lg.map(l=>'<div><span class="m">'+esc(l.ts)+'</span> '+esc(l.username)+': '+esc(l.action)+'</div>').join('')||'<span class="m">empty</span>'}catch(e){}}
const act=async(id,fn)=>{$(id).textContent='';try{await fn();if(id!='#kde')renderAdmin()}catch(x){fail(id,x)}};
$('#au').onclick=()=>act('#ue',async()=>{await api('POST','/api/admin/users',{n:$('#nu').value.trim(),p:$('#np').value,r:$('#nr').value});$('#nu').value=$('#np').value=''});
$('#ul').onclick=e=>{if(e.target.dataset.du)act('#ue',()=>api('DELETE','/api/admin/users/'+e.target.dataset.du));if(e.target.dataset.r2&&confirm('تعطيل 2FA لهذا المستخدم وإنهاء جلساته؟'))act('#ue',()=>api('POST','/api/admin/users/'+e.target.dataset.r2+'/reset2fa',{}))};
$('#at2').onclick=()=>act('#te',async()=>{await api('POST','/api/admin/tools',{type:$('#ty').value,name:$('#tn').value,url:$('#tu').value.trim(),descr:$('#td').value});$('#tn').value=$('#tu').value=$('#td').value=''});
$('#ct').onclick=e=>{if(e.target.dataset.dt)act('#te',()=>api('DELETE','/api/admin/tools/'+e.target.dataset.dt))};
$('#cl2').onclick=()=>act('#te',()=>api('DELETE','/api/admin/log'));
$('#ex').onclick=()=>{location.href='/api/admin/export'};
setInterval(()=>$('#clk').textContent=new Date().toLocaleTimeString('en-GB'),1000);
api('GET','/api/me').then(u=>{me=u;enter()}).catch(()=>{});
