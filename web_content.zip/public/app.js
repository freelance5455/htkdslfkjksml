let currentUser = null;
let editingUserId = null;

const $ = id => document.getElementById(id);
const toast = msg => {
  $("toast").textContent = msg;
  $("toast").style.display = "block";
  setTimeout(() => $("toast").style.display = "none", 2500);
};

async function api(url, options = {}) {
  const r = await fetch(url, {
    headers: {"Content-Type":"application/json", ...(options.headers || {})},
    ...options
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || "Erro inesperado.");
  return data;
}

function showApp(user) {
  currentUser = user;
  $("auth").classList.add("hidden");
  $("dashboard").classList.remove("hidden");
  $("logout").classList.remove("hidden");
  $("welcome").textContent = `Olá, ${user.nick}!`;

  if (user.role === "owner") {
    $("ownerPanel").classList.remove("hidden");
    loadUsers();
    loadAdminSettings();
    loadAdminConnections();
  } else {
    $("ownerPanel").classList.add("hidden");
  }
}


let appSettings = {};

function isSafeColor(value) {
  if (!value) return false;
  const probe = document.createElement("div");
  probe.style.color = value;
  return probe.style.color !== "";
}

function applySettings(settings) {
  appSettings = settings || {};
  const root = document.documentElement;
  const map = {
    "--primary": settings.primaryColor,
    "--background": settings.backgroundColor,
    "--card": settings.cardColor,
    "--text": settings.textColor
  };

  Object.entries(map).forEach(([name, value]) => {
    if (value && isSafeColor(value)) root.style.setProperty(name, value);
  });

  const icon = $("homeIcon");
  if (settings.homeIcon) {
    icon.src = settings.homeIcon;
    icon.classList.remove("hidden");
  } else {
    icon.classList.add("hidden");
  }
}

async function loadSettings() {
  try {
    const data = await api("/api/settings");
    applySettings(data.settings);
  } catch {}
}

async function loadAdminSettings() {
  const data = await api("/api/settings");
  const st = data.settings;
  $("primaryColor").value = st.primaryColor || "";
  $("backgroundColor").value = st.backgroundColor || "";
  $("cardColor").value = st.cardColor || "";
  $("textColor").value = st.textColor || "";

  if (st.homeIcon) {
    $("adminIconPreview").src = st.homeIcon;
    $("adminIconPreview").classList.remove("hidden");
    $("adminIconEmpty").classList.add("hidden");
  }
}

function readImageAsDataURL(file) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve("");
    if (file.size > 2 * 1024 * 1024) {
      reject(new Error("Use uma imagem de até 2 MB."));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Não foi possível ler a imagem."));
    reader.readAsDataURL(file);
  });
}

$("homeIconFile").addEventListener("change", async e => {
  try {
    const dataUrl = await readImageAsDataURL(e.target.files[0]);
    if (!dataUrl) return;
    $("adminIconPreview").src = dataUrl;
    $("adminIconPreview").classList.remove("hidden");
    $("adminIconEmpty").classList.add("hidden");
    $("homeIconFile").dataset.pendingIcon = dataUrl;
  } catch (err) {
    e.target.value = "";
    toast(err.message);
  }
});

$("saveCustomization").addEventListener("click", async () => {
  const colors = {
    primaryColor: $("primaryColor").value.trim(),
    backgroundColor: $("backgroundColor").value.trim(),
    cardColor: $("cardColor").value.trim(),
    textColor: $("textColor").value.trim()
  };

  for (const [key, value] of Object.entries(colors)) {
    if (!isSafeColor(value)) {
      toast(`A cor em "${key}" não é válida. Use nomes como azul/white ou HEX como #367dff.`);
      return;
    }
  }

  const body = { ...colors };
  if ($("homeIconFile").dataset.pendingIcon) {
    body.homeIcon = $("homeIconFile").dataset.pendingIcon;
  }

  try {
    const data = await api("/api/admin/settings", {
      method: "PATCH",
      body: JSON.stringify(body)
    });
    applySettings(data.settings);
    $("homeIconFile").dataset.pendingIcon = "";
    toast("Personalização salva com sucesso.");
  } catch (err) {
    toast(err.message);
  }
});


async function loadAdminConnections() {
  const data = await api("/api/admin/connections");
  const list = $("connectionsAdminList");
  list.innerHTML = "";
  if (!data.connections.length) list.innerHTML = '<p class="hint">Nenhuma conexão enviada.</p>';

  data.connections.forEach(c => {
    const row = document.createElement("div");
    row.className = "connection-row";
    row.innerHTML = `
      <img src="${escapeAttr(c.image)}" class="connection-avatar">
      <div class="connection-info">
        <strong>${escapeHtml(c.nick)}</strong>
        <a href="${escapeAttr(c.url)}" target="_blank" rel="noopener">${escapeHtml(c.url)}</a>
      </div>
      <button class="danger-btn">Proibir links automaticamente</button>`;
    row.querySelector("button").onclick = async () => {
      if (!confirm(`Proibir links de ${c.nick}? O link atual também desaparecerá.`)) return;
      await api("/api/admin/connections/" + c.userId + "/restrict", {method:"POST"});
      toast("Links proibidos para esse usuário.");
      loadAdminConnections();
    };
    list.appendChild(row);
  });

  const ru = $("restrictedUsers");
  ru.innerHTML = "";
  if (!data.restrictedUsers.length) ru.innerHTML = '<p class="hint">Nenhum usuário restringido.</p>';
  data.restrictedUsers.forEach(u => {
    const row=document.createElement("div");
    row.className="connection-row";
    row.innerHTML=`<div class="connection-info"><strong>${escapeHtml(u.nick)}</strong><small>@${escapeHtml(u.permanentNick)}</small></div><button class="ghost">Retirar restrição</button>`;
    row.querySelector("button").onclick=async()=>{
      await api("/api/admin/connections/"+u.id+"/unrestrict",{method:"POST"});
      toast("Restrição retirada.");
      loadAdminConnections();
    };
    ru.appendChild(row);
  });

  const rusers=$("restrictionUsers");
  rusers.innerHTML="";
  data.connections.filter(c=>!c.restricted).forEach(c=>{
    const row=document.createElement("div");
    row.className="connection-row";
    row.innerHTML=`<div class="connection-info"><strong>${escapeHtml(c.nick)}</strong></div><button class="danger-btn">Restringir</button>`;
    row.querySelector("button").onclick=async()=>{
      await api("/api/admin/connections/"+c.userId+"/restrict",{method:"POST"});
      toast("Usuário restringido.");
      loadAdminConnections();
    };
    rusers.appendChild(row);
  });
}

$("openConnections").onclick=()=>{
  $("connectionsPage").classList.remove("hidden");
  loadMyConnection();
};
$("closeConnections").onclick=()=>$("connectionsPage").classList.add("hidden");
$("addRestriction").onclick=()=>{
  $("restrictionBox").classList.toggle("hidden");
  loadAdminConnections();
};

async function loadMyConnection() {
  try {
    const data=await api("/api/connections");
    const mine=data.connections.find(c=>c.userId===currentUser.id);
    if(mine) $("connectionUrl").value=mine.url;
  } catch {}
}

$("connectionForm").addEventListener("submit",async e=>{
  e.preventDefault();
  try {
    const file=$("connectionFile").files[0];
    const image=await readImageAsDataURL(file);
    await api("/api/connections",{method:"POST",body:JSON.stringify({
      image,url:$("connectionUrl").value.trim()
    })});
    toast("Conexão salva no seu perfil.");
  }catch(err){toast(err.message)}
});

$("removeConnection").onclick=async()=>{
  try{
    await api("/api/connections",{method:"DELETE"});
    $("connectionUrl").value="";
    $("connectionFile").value="";
    toast("Conexão removida.");
  }catch(err){toast(err.message)}
};

async function boot() {
  try {
    const data = await api("/api/me");
    showApp(data.user);
  } catch {
    $("auth").classList.remove("hidden");
  }
}

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/login", {
      method:"POST",
      body:JSON.stringify({
        email:$("loginEmail").value,
        password:$("loginPassword").value
      })
    });
    showApp(data.user);
    toast("Login realizado.");
  } catch(err) { toast(err.message); }
});

$("registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/register", {
      method:"POST",
      body:JSON.stringify({
        nick:$("regNick").value,
        permanentNick:$("regPermanent").value,
        email:$("regEmail").value,
        password:$("regPassword").value
      })
    });
    showApp(data.user);
    toast(data.owner ? "Conta criada. Você é o dono!" : "Conta criada.");
  } catch(err) { toast(err.message); }
});

$("logout").addEventListener("click", async () => {
  await api("/api/logout", {method:"POST"});
  location.reload();
});

async function loadUsers() {
  const data = await api("/api/admin/users");
  $("usersList").innerHTML = "";
  data.users.forEach(u => {
    const row = document.createElement("div");
    row.className = "user-row";
    const avatar = u.profilePhoto
      ? `<img class="avatar" src="${escapeAttr(u.profilePhoto)}" alt="">`
      : `<div class="avatar">${escapeHtml(u.nick.charAt(0).toUpperCase())}</div>`;
    row.innerHTML = `
      ${avatar}
      <div class="user-main">
        <strong>${escapeHtml(u.nick)}</strong>
        <small>@${escapeHtml(u.permanentNick)} · ${escapeHtml(u.email)}</small>
      </div>
      <span class="role">${u.role === "owner" ? "Dono" : "Membro"}</span>
      <button class="edit-btn">Alterar senha</button>
    `;
    row.querySelector(".edit-btn").addEventListener("click", () => openEdit(u));
    $("usersList").appendChild(row);
  });
}

function openEdit(u) {
  editingUserId = u.id;
  $("modalUserName").textContent = `${u.nick} · @${u.permanentNick}`;
  $("editNick").value = "";
  $("editPermanent").value = "";
  $("editEmail").value = "";
  $("editPassword").value = "";
  $("infoNick").textContent = u.nick;
  $("infoPermanent").textContent = u.permanentNick;
  $("infoEmail").textContent = u.email;
  $("modal").classList.remove("hidden");
}

function closeEdit() {
  editingUserId = null;
  $("modal").classList.add("hidden");
}

$("closeModal").onclick = closeEdit;
$("cancelEdit").onclick = closeEdit;
$("refreshUsers").onclick = loadUsers;

$("editUserForm").addEventListener("submit", async e => {
  e.preventDefault();
  const body = {};
  const fields = [
    ["nick","editNick"],
    ["permanentNick","editPermanent"],
    ["email","editEmail"],
    ["password","editPassword"]
  ];
  fields.forEach(([key, id]) => {
    const value = $(id).value.trim();
    if (value) body[key] = value;
  });

  if (!Object.keys(body).length) {
    toast("Altere pelo menos um campo para salvar.");
    return;
  }

  try {
    await api("/api/admin/users/" + editingUserId, {
      method:"PATCH",
      body:JSON.stringify(body)
    });
    toast("Conta alterada com sucesso.");
    closeEdit();
    loadUsers();
  } catch(err) {
    toast(err.message);
  }
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}
function escapeAttr(s) { return escapeHtml(s); }

loadSettings().finally(boot);