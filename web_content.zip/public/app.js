const server = document.querySelector("#server");
const session = document.querySelector("#session");
const overlay = document.querySelector("#overlay");
const overlayBtn = document.querySelector("#overlayBtn");

fetch("/api/status")
  .then(r => r.json())
  .then(() => server.textContent = "ONLINE")
  .catch(() => server.textContent = "OFFLINE");

fetch("/api/session", {method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});

document.querySelectorAll(".toggle").forEach(t => {
  t.addEventListener("change", () => {
    session.textContent = t.checked ? "ACTIVE" : "READY";
  });
});

overlayBtn.addEventListener("click", async () => {
  if (window.AndroidOverlay && AndroidOverlay.requestOverlayPermission) {
    AndroidOverlay.requestOverlayPermission();
    return;
  }
  overlay.textContent = "WEB MODE";
  overlayBtn.textContent = "OVERLAY REQUESTED";
});