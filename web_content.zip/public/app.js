(function dropPasswordFromUrl() {
  const url = new URL(location.href);
  if (!url.searchParams.has('password')) return;
  url.searchParams.delete('password');
  history.replaceState(null, '', url.pathname + url.search + url.hash);
  document.addEventListener('DOMContentLoaded', () => {
    const err = document.getElementById('error');
    if (err) err.textContent = 'Passwords are not accepted in the address bar. Enter it in the form instead.';
  });
})();
(() => {
'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const LABELS = {
  dashboard: { title: 'Dashboard', sub: 'Overview of your key system' },
  keys: { title: 'Key Manager', sub: 'Create, search and revoke keys' },
  dominant: { title: 'Files repository', sub: 'Browse, edit and upload files in the Dominant repository' },
  activity: { title: 'Activity Log', sub: 'Recent sign-ins and key events' },
  settings: { title: 'Settings', sub: 'System status and configuration' },
  providers: { title: 'AI Assistant', sub: 'Propose and review changes to Dominant files' },
  infra: { title: 'Infrastructure', sub: 'Cloudflare Worker, D1 database and Backblaze B2 storage' },
};

const ICONS = {
  'activity': '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
  'alert': '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  'arrow-up': '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
  'chart': '<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
  'check': '<path d="M20 6 9 17l-5-5"/>',
  'chevron-right': '<path d="m9 18 6-6-6-6"/>',
  'circle': '<circle cx="12" cy="12" r="9"/>',
  'clock': '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  'copy': '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  'edit': '<path d="M21.17 6.81a2.82 2.82 0 0 0-3.98-3.98L3.84 16.17a2 2 0 0 0-.5.83l-1.32 4.35a.5.5 0 0 0 .63.63l4.35-1.32a2 2 0 0 0 .83-.5Z"/>',
  'file': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>',
  'folder': '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  'folder-open': '<path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2"/>',
  'globe': '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  'info': '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  'key': '<path d="M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2l1.4-1.4a6.5 6.5 0 1 0-4-4Z"/><circle cx="16.5" cy="7.5" r=".5"/>',
  'layers': '<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/>',
  'plus': '<path d="M5 12h14"/><path d="M12 5v14"/>',
  'pulse': '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
  'refresh': '<path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/>',
  'server': '<rect width="20" height="8" x="2" y="2" rx="2"/><rect width="20" height="8" x="2" y="14" rx="2"/><path d="M6 6h.01"/><path d="M6 18h.01"/>',
  'settings': '<circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  'shield': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  'square': '<rect width="18" height="18" x="3" y="3" rx="2"/>',
  'trash': '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  'upload': '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  'users': '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  'x': '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  'zap': '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
};

function icon(name, cls = '') {
  return `<svg class="icon-svg ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.circle || ''}</svg>`;
}
// Draws Lucide icons in new nodes; the CDN script is loaded in index.html.
function refreshIcons(root) {
  if (!window.lucide || !root || !root.querySelectorAll) return;
  const nodes = root.matches && root.matches('i[data-lucide]') ? [root] : [...root.querySelectorAll('i[data-lucide]')];
  if (!nodes.length) return;
  try {
    window.lucide.createIcons({ nodes });
  } catch (err) {
    console.warn('Icons could not be drawn', err);
  }
}
function startIcons() {
  refreshIcons(document.body);
}
// Images and icons are not saved or dragged from the page; text stays selectable.
document.addEventListener('contextmenu', (e) => {
  if (e.target.closest && e.target.closest('img, svg, .icon-svg')) e.preventDefault();
});
document.addEventListener('dragstart', (e) => {
  if (e.target.tagName === 'IMG') e.preventDefault();
});
try {
  startIcons();
} catch (err) {
  console.warn('Icon observer could not start', err);
}

function esc(v) {
  return String(v ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

function toast(msg, type = '') {
  const el = document.createElement('div');
  el.className = 'toast' + (type === 'err' ? ' err' : type === 'ok' ? ' ok' : '');
  el.innerHTML = (type === 'ok' ? icon('check', 'sm') : type === 'err' ? icon('alert', 'sm') : '') + `<span>${esc(msg)}</span>`;
  $('#toasts').appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(8px)';
    el.style.transition = '0.3s';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

function fmtDate(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  } catch { return iso; }
}

function relTime(iso) {
  if (!iso) return '';
  const m = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return m + 'm ago';
  const h = Math.floor(m / 60);
  if (h < 24) return h + 'h ago';
  const d = Math.floor(h / 24);
  if (d < 30) return d + 'd ago';
  return fmtDate(iso);
}

// Every request gets a time limit, so a server that never answers shows an error instead of loading forever.
function requestSignal(extra) {
  const timer = AbortSignal.timeout(20000);
  return extra && typeof AbortSignal.any === 'function' ? AbortSignal.any([extra, timer]) : (extra || timer);
}
const SLOW_MSG = 'The server took too long to answer. Try again.';

async function api(url, { method = 'GET', body, silent = false, signal } = {}) {
  let res;
  try {
    res = await fetch(url, {
      method,
      signal: requestSignal(signal),
      credentials: 'same-origin',
      headers: {
        'X-Requested-With': 'RegexManager',
        ...(body ? { 'Content-Type': 'application/json' } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (err) {
    throw new Error(err && err.name === 'TimeoutError' ? SLOW_MSG : 'Cannot reach the server');
  }
  let data;
  try {
    data = await res.json();
  } catch (err) {
    if (err && err.name === 'TimeoutError') throw new Error(SLOW_MSG);
    data = {};
  }
  if (res.status === 401 && !silent) {
    showLogin();
    throw new Error(data.error || 'Session expired. Sign in again.');
  }
  if (!res.ok) throw new Error(data.error || ('Request failed (' + res.status + ')'));
  return data;
}

function showLogin() {
  $('#app').classList.add('hidden');
  closeMenu();
  $('#login').classList.remove('hidden');
  $('#password').value = '';
  setTimeout(() => $('#password').focus(), 40);
}
function showApp() {
  $('#login').classList.add('hidden');
  $('#app').classList.remove('hidden');
}

function openMenu() {
  $('#sidebar').classList.add('open');
  $('#overlay').classList.add('open');
  $('#menu-btn').setAttribute('aria-expanded', 'true');
  $('#overlay').setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}
function closeMenu() {
  $('#sidebar').classList.remove('open');
  $('#overlay').classList.remove('open');
  $('#menu-btn').setAttribute('aria-expanded', 'false');
  $('#overlay').setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

$('#menu-btn').addEventListener('click', openMenu);
$('#overlay').addEventListener('click', closeMenu);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });
$$('nav a').forEach(a => a.addEventListener('click', closeMenu));

$('#toggle-pass').addEventListener('click', (e) => {
  const input = $('#password');
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  e.currentTarget.textContent = show ? 'Hide' : 'Show';
  e.currentTarget.setAttribute('aria-pressed', String(show));
});

$('#password').addEventListener('keydown', (e) => { $('#caps-hint').hidden = !e.getModifierState('CapsLock'); });
$('#password').addEventListener('keyup', (e) => { $('#caps-hint').hidden = !e.getModifierState('CapsLock'); });

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#login-btn');
  const err = $('#error');
  if (btn.disabled) return;
  const password = $('#password').value;
  if (!password) { err.textContent = 'Enter the password to continue.'; return; }

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner spinner-sm"></span> Signing in…';
  err.textContent = '';
  try {
    await api('api/login', { method: 'POST', body: { password, remember: $('#remember').checked }, silent: true });
    $('#password').value = '';
    showApp();
    route();
  } catch (ex) {
    err.textContent = ex.message;
    $('#password').select();
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<svg class="icon-svg sm" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg> Sign in`;
  }
});

$('#logout').addEventListener('click', async () => {
  try { await api('api/logout', { method: 'POST', silent: true }); } catch {}
  showLogin();
});

// Clean paths: /admin, /admin/keys, /admin/files-repository ... Old #links still work.
const PATHS = {
  admin: 'dashboard',
  'admin/keys': 'keys',
  'admin/files-repository': 'dominant',
  'admin/activity': 'activity',
  'admin/assistant': 'providers',
  'admin/infrastructure': 'infra',
  'admin/settings': 'settings',
};
const SCREEN_PATH = Object.fromEntries(Object.entries(PATHS).map(([p, n]) => [n, p]));

function currentRoute() {
  const fromHash = location.hash.replace('#', '');
  if (LABELS[fromHash]) return fromHash;
  const rel = location.pathname.replace(/\/+$/, '');
  const at = rel.indexOf('/regex/');
  const sub = at >= 0 ? rel.slice(at + '/regex/'.length) : rel.replace(/^\/+/, '');
  return PATHS[sub] || 'dashboard';
}

// Moves to a screen by its clean path, without reloading the page.
function go(name) {
  const path = SCREEN_PATH[name] || 'admin';
  history.pushState(null, '', new URL(path, document.baseURI));
  route();
}

async function route() {
  const name = currentRoute();
  if (location.hash) history.replaceState(null, '', new URL(SCREEN_PATH[name] || 'admin', document.baseURI));
  $$('[data-route]').forEach(a => a.classList.toggle('active', a.dataset.route === name));
  const info = LABELS[name];
  $('#page-title').textContent = info.title;
  $('#page-sub').textContent = info.sub;
  $('#mobile-title').textContent = info.title;
  document.title = info.title + ' · Regex Manager';

  const view = $('#view');
  view.innerHTML = '<div class="state"><div class="spinner"></div><p>Loading…</p></div>';

  try {
    if (name === 'dashboard') await renderDashboard();
    else if (name === 'keys') await renderKeys();
    else if (name === 'activity') await renderActivity();
    else if (name === 'dominant') await renderDominant();
    else if (name === 'settings') await renderSettings();
    else if (name === 'providers') await renderProviders();
    else if (name === 'infra') await renderInfra();
    refreshIcons(view);
  } catch (err) {
    view.innerHTML = `<div class="state">
      <p class="err-text">${icon('alert')} ${esc(err.message)}</p>
      <button class="ghost small" data-retry>Try again</button>
    </div>`;
  }
}
window.addEventListener('hashchange', route);
window.addEventListener('popstate', route);
document.addEventListener('click', (e) => {
  const link = e.target.closest && e.target.closest('a[data-route]');
  if (!link || e.ctrlKey || e.metaKey || e.shiftKey) return;
  e.preventDefault();
  go(link.dataset.route);
});

// Anything that escapes a screen is shown here, so a failure is never silent.
function showFatal(message) {
  let box = document.getElementById('fatal-banner');
  if (!box) {
    box = document.createElement('div');
    box.id = 'fatal-banner';
    box.className = 'fatal-banner';
    box.setAttribute('role', 'alert');
    document.body.appendChild(box);
  }
  box.textContent = 'Something failed: ' + String(message).slice(0, 240);
}
window.addEventListener('error', (e) => showFatal(e.message || 'script error'));
window.addEventListener('unhandledrejection', (e) => showFatal((e.reason && e.reason.message) || e.reason || 'request failed'));

/* ─── Dashboard ─── */
function statCard(icoName, label, value, hint, tone, delay) {
  return `<section class="stat delay-${delay}">
    <div class="stat-top"><span class="stat-icon ${tone}">${icon(icoName, 'sm')}</span><span class="label">${esc(label)}</span></div>
    <div class="value countup ${tone}" data-count="${Number(value) || 0}">0</div>
    <div class="hint">${esc(hint)}</div>
  </section>`;
}

function keysPerDay(keys, days) {
  const out = [];
  const today = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() - i));
    const iso = d.toISOString().slice(0, 10);
    const count = keys.filter(k => String(k.createdAt || '').slice(0, 10) === iso).length;
    out.push({ date: iso, label: `${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')}`, value: count });
  }
  return out;
}

function smoothPath(pts, top, bottom) {
  const clamp = (v) => Math.min(bottom, Math.max(top, v));
  let d = `M${pts[0].x.toFixed(1)},${pts[0].y.toFixed(1)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = clamp(p1.y + (p2.y - p0.y) / 6);
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = clamp(p2.y - (p3.y - p1.y) / 6);
    d += ` C${c1x.toFixed(1)},${c1y.toFixed(1)} ${c2x.toFixed(1)},${c2y.toFixed(1)} ${p2.x.toFixed(1)},${p2.y.toFixed(1)}`;
  }
  return d;
}

function areaChart(series) {
  const W = 640, H = 180, P = 16;
  const max = Math.max(1, ...series.map(p => p.value));
  const step = series.length > 1 ? (W - P * 2) / (series.length - 1) : 0;
  const top = P, bottom = H - P;
  const pts = series.map((p, i) => ({ x: P + i * step, y: bottom - (p.value / max) * (bottom - top - 12), p }));
  const line = smoothPath(pts, top, bottom);
  const last = pts[pts.length - 1], first = pts[0];
  const area = `${line} L${last.x.toFixed(1)},${bottom} L${first.x.toFixed(1)},${bottom} Z`;
  const dots = pts.map(q => `<circle class="chart-dot" cx="${q.x.toFixed(1)}" cy="${q.y.toFixed(1)}" r="3.5"><title>${esc(q.p.label)}: ${q.p.value} created</title></circle>`).join('');
  const ticks = series.map((p, i) => ({ p, i })).filter(({ i }) => i % 3 === 0 || i === series.length - 1)
    .map(({ p, i }) => {
      const edge = i === 0 ? ' start' : (i === series.length - 1 ? ' end' : '');
      return `<text x="${(P + i * step).toFixed(1)}" y="${H - 2}" class="chart-tick${edge}">${esc(p.label)}</text>`;
    }).join('');
  return `<svg class="area-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Keys created over the last 14 days">
    <path class="chart-area" d="${area}" fill="#e5484d" fill-opacity="0.12"/>
    <path class="chart-line" d="${line}" pathLength="100"/>
    ${dots}${ticks}
  </svg>`;
}

function donut(percent) {
  const R = 52, C = 2 * Math.PI * R;
  return `<div class="donut">
    <svg viewBox="0 0 140 140" role="img" aria-label="${percent}% of keys are active">
      <circle class="donut-track" cx="70" cy="70" r="${R}" fill="none" stroke-width="14"/>
      <circle class="donut-ring" cx="70" cy="70" r="${R}" fill="none" stroke-width="14" stroke-linecap="round"
        stroke-dasharray="${C.toFixed(2)}" data-target="${(C * (1 - percent / 100)).toFixed(2)}"/>
    </svg>
    <div class="donut-center"><strong class="countup" data-count="${percent}">0</strong><span>% active</span></div>
  </div>`;
}

function countUp(el) {
  const target = Number(el.dataset.count) || 0;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = target.toLocaleString(); return; }
  const start = performance.now();
  const dur = 900;
  const tick = (now) => {
    const t = Math.min((now - start) / dur, 1);
    el.textContent = Math.round(target * (1 - Math.pow(1 - t, 3))).toLocaleString();
    if (t < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function animateDashboard() {
  document.querySelectorAll('#view .countup').forEach(countUp);
  document.querySelectorAll('#view .chart-dot').forEach((dot, i, all) => {
    dot.style.animationDelay = `${(1.1 + (i / Math.max(1, all.length - 1)) * 0.6).toFixed(2)}s`;
  });
  document.querySelectorAll('#view .donut-ring').forEach(ring => {
    ring.style.strokeDashoffset = ring.getAttribute('stroke-dasharray');
  });
  requestAnimationFrame(() => {
    document.querySelectorAll('#view .donut-ring').forEach(ring => {
      ring.style.strokeDashoffset = ring.dataset.target;
    });
  });
}

async function renderDashboard() {
  const [data, keysRes] = await Promise.all([api('api/dashboard'), api('api/keys')]);
  const keys = keysRes.keys || [];
  const active = data.activeKeys ?? 0;
  const total = data.totalKeys ?? 0;
  const revoked = data.revokedKeys ?? 0;
  const expired = data.expiredKeys ?? 0;
  const unused = data.unusedKeys ?? 0;
  const share = total ? Math.round((active / total) * 100) : 0;
  const series = keysPerDay(keys, 14);
  const created14 = series.reduce((n, p) => n + p.value, 0);
  const soon = keys.filter(isExpiringSoon).length;

  $('#view').innerHTML = `
    <div class="stats">
      ${statCard('check', 'Active keys', active, 'Currently valid', 'ok', 1)}
      ${statCard('key', 'Total keys', total, 'All time', 'info', 2)}
      ${statCard('hourglass', 'Not started', unused, 'Waiting for first use', 'info', 3)}
      ${statCard('xcircle', 'Revoked', revoked, 'Manually disabled', revoked ? 'bad' : '', 4)}
    </div>

    <div class="dash-grid">
      <section class="card delay-2 span-2">
        <div class="card-head"><h3>${icon('chart')} Keys created</h3><span class="chip-static">${created14} in 14 days</span></div>
        ${series.some((p) => p.value) ? areaChart(series) : '<div class="state">No keys created in the last 14 days</div>'}
      </section>
      <section class="card delay-3">
        <div class="card-head"><h3>${icon('zap')} Health</h3></div>
        ${donut(share)}
        <ul class="legend">
          <li><span class="sw ok"></span>${active} active</li>
          <li><span class="sw warn"></span>${expired} expired</li>
          <li><span class="sw bad"></span>${revoked} revoked</li>
          <li><span class="sw info"></span>${soon} expiring within 7 days</li>
        </ul>
      </section>
    </div>

    <div class="dash-grid">
      <section class="card delay-3 span-2">
        <div class="card-head"><h3>${icon('activity')} Recent activity</h3></div>
        ${activityTable(data.recentActivity || [])}
      </section>
      <section class="card delay-4">
        <div class="card-head"><h3>${icon('info')} Quick info</h3></div>
        <div class="info-list">
          <div class="info-row">${icon('shield', 'sm')}<div><span class="muted2">Validation endpoint</span><code class="mono mono-sm">${esc(location.origin + '/' + (location.pathname.split('/').filter(Boolean)[0] || '') + '/api/validate')}</code></div></div>
          <div class="info-row">${icon('pulse', 'sm')}<div><span class="muted2">Used in the last 24h</span><strong>${data.usedLast24h ?? 0} keys</strong></div></div>
          <div class="info-row">${icon('server', 'sm')}<div><span class="muted2">Storage</span><strong>Cloudflare D1</strong></div></div>
          <div class="info-row">${icon('clock', 'sm')}<div><span class="muted2">Session length</span><strong>12 hours</strong></div></div>
        </div>
      </section>
    </div>`;
  animateDashboard();
}

const ACTION_LABELS = {
  'login.succeeded': 'Signed in',
  'login.failed': 'Failed sign-in',
  'logout': 'Signed out',
  'key.created': 'Key created',
  'key.revoked': 'Key revoked',
  'key.restored': 'Key restored',
  'key.deleted': 'Key deleted',
  'key.renamed': 'Key renamed',
  'key.time_changed': 'Time changed',
  'key.activated': 'Key started',
  'keys.purged': 'Keys cleared',
};
function activityTable(entries) {
  if (!entries.length) return '<div class="state">No activity yet</div>';
  return `<div class="table-wrap"><table>
    <thead><tr><th>When</th><th>Action</th><th>Detail</th></tr></thead>
    <tbody>${entries.map(e => `<tr>
      <td title="${esc(fmtDate(e.at))}">${esc(relTime(e.at))}</td>
      <td>${esc(ACTION_LABELS[e.action] || e.action)}</td>
      <td class="muted">${esc((e.detail || '—').replace(/ · /g, ', '))}</td>
    </tr>`).join('')}</tbody>
  </table></div>`;
}

/* ─── Keys ─── */
let cachedKeys = [];
let keyFilter = 'all';
let keySort = 'newest';

const LIFETIME_OPTIONS = [
  ['never', 'Never expires'],
  ['1h', '1 hour'],
  ['1d', '1 day'],
  ['7d', '7 days'],
  ['30d', '30 days'],
  ['90d', '90 days'],
  ['365d', '1 year'],
  ['custom', 'Custom…'],
];
const LIFETIME_PRESETS = {
  '1h': { value: 1, unit: 'hours' },
  '1d': { value: 1, unit: 'days' },
  '7d': { value: 7, unit: 'days' },
  '30d': { value: 30, unit: 'days' },
  '90d': { value: 90, unit: 'days' },
  '365d': { value: 1, unit: 'years' },
};
const UNIT_LABELS = { minutes: 'minute', hours: 'hour', days: 'day', weeks: 'week', months: 'month', years: 'year' };
const FILTERS = [
  ['all', 'All'],
  ['active', 'Active'],
  ['unused', 'Unused'],
  ['revoked', 'Revoked'],
  ['expired', 'Expired'],
  ['soon', 'Expiring soon'],
];

function statusBadge(s) {
  s = (s || 'active').toLowerCase();
  return `<span class="badge ${esc(s)}">${esc(s === 'unused' ? 'not started' : s)}</span>`;
}

function lifetimeBody() {
  const preset = $('#key-life').value;
  if (preset === 'never') return { value: null };
  if (preset === 'custom') {
    return { value: Number($('#custom-value').value), unit: $('#custom-unit').value };
  }
  return LIFETIME_PRESETS[preset];
}

function describeLifetime() {
  const preset = $('#key-life').value;
  if (preset === 'never') return 'Never expires.';
  const body = lifetimeBody();
  if (!Number.isInteger(body.value) || body.value < 1) return 'Enter a whole number of at least 1.';
  const word = body.value === 1 ? UNIT_LABELS[body.unit] : body.unit;
  const start = $('#key-start').value === 'first_use'
    ? 'The timer starts the first time the key is used.'
    : 'The timer starts when the key is created.';
  return `Each key lasts ${body.value} ${word}. ${start}`;
}

function refreshCreateForm() {
  const custom = $('#key-life').value === 'custom';
  $('#custom-wrap').hidden = !custom;
  const never = $('#key-life').value === 'never';
  $('#key-start').disabled = never;
  if (never) $('#key-start').value = 'created';
  $('#key-preview').textContent = describeLifetime();
}

function keyRows(keys) {
  return keys.map(k => {
    const expiresCell = k.status === 'unused'
      ? '<span class="muted2">Starts on first use</span>'
      : (k.expiresAt ? esc(fmtDate(k.expiresAt)) : '<span class="muted2">Never</span>');
    const actions = [];
    if (k.status !== 'revoked') {
      actions.push(`<button class="ghost small" data-edit="${k.id}">${icon('edit', 'sm')} ${k.status === 'expired' ? 'Edit / extend' : 'Edit'}</button>`);
    }
    if (k.status === 'active' || k.status === 'unused') {
      actions.push(`<button class="danger small" data-revoke="${k.id}">${icon('trash', 'sm')} Revoke</button>`);
    }
    if (k.status === 'revoked') {
      actions.push(`<button class="ghost small" data-restore="${k.id}">${icon('refresh', 'sm')} Restore</button>`);
    }
    if (k.status === 'revoked' || k.status === 'expired') {
      actions.push(`<button class="danger small" data-delete="${k.id}">${icon('trash', 'sm')} Delete</button>`);
    }
    return `<tr>
      <td class="select-col" data-label="Select"><input type="checkbox" data-select="${k.id}" aria-label="Select key ${esc(k.hint)}"${selectedIds.has(k.id) ? ' checked' : ''}></td>
      <td data-label="Key"><code class="mono">${esc(k.hint)}</code></td>
      <td data-label="Label">${esc(k.label || '—')}</td>
      <td data-label="Status">${statusBadge(k.status)}</td>
      <td data-label="Duration">${esc(k.lifetime || '—')}</td>
      <td data-label="Expires">${expiresCell}</td>
      <td data-label="Last used" title="${esc(fmtDate(k.lastUsedAt))}">${k.lastUsedAt ? esc(relTime(k.lastUsedAt)) : '<span class="muted2">Never used</span>'}</td>
      <td class="right actions-cell"><div class="row-actions">${actions.join('')}</div></td>
    </tr>`;
  }).join('');
}

function isExpiringSoon(k) {
  return k.status === 'active' && !!k.expiresAt && (Date.parse(k.expiresAt) - Date.now()) < 7 * 86400000;
}

function sortKeys(list) {
  const copy = list.slice();
  const expiry = k => (k.expiresAt ? Date.parse(k.expiresAt) : Infinity);
  if (keySort === 'oldest') copy.sort((a, b) => a.id - b.id);
  else if (keySort === 'expiry') copy.sort((a, b) => expiry(a) - expiry(b));
  else if (keySort === 'label') copy.sort((a, b) => String(a.label || '').localeCompare(String(b.label || '')));
  else copy.sort((a, b) => b.id - a.id);
  return copy;
}

function filterKeys(q) {
  q = (q || '').trim().toLowerCase();
  const list = cachedKeys.filter(k => {
    if (keyFilter === 'soon') { if (!isExpiringSoon(k)) return false; }
    else if (keyFilter !== 'all' && k.status !== keyFilter) return false;
    if (!q) return true;
    return (k.label || '').toLowerCase().includes(q) ||
      (k.hint || '').toLowerCase().includes(q) ||
      (k.status || '').toLowerCase().includes(q);
  });
  return sortKeys(list);
}

function renderChips() {
  const el = $('#key-filters');
  if (!el) return;
  const counts = { all: cachedKeys.length };
  for (const k of cachedKeys) counts[k.status] = (counts[k.status] || 0) + 1;
  counts.soon = cachedKeys.filter(isExpiringSoon).length;
  el.innerHTML = FILTERS.map(([id, label]) =>
    `<button type="button" class="chip${keyFilter === id ? ' active' : ''}" data-filter="${id}">${esc(label)} <span class="muted2">${counts[id] || 0}</span></button>`
  ).join('');
  const removable = cachedKeys.filter(k => k.status === 'revoked' || k.status === 'expired').length;
  const purge = $('#purge-btn');
  if (purge) {
    purge.disabled = removable === 0;
    purge.innerHTML = `${icon('trash', 'sm')} Clear revoked & expired${removable ? ` (${removable})` : ''}`;
  }
}

function renderTable(keys) {
  const el = $('#key-table');
  if (!el) return;
  const countEl = $('#key-count');
  if (countEl) countEl.textContent = keys.length + ' of ' + cachedKeys.length;
  renderChips();

  if (!keys.length) {
    el.innerHTML = `<div class="state">${cachedKeys.length ? 'No keys match this filter. Clear the filter or search to see the rest.' : 'No keys yet. Create one above to give a buyer access.'}</div>`;
    return;
  }
  const allShown = keys.length > 0 && keys.every(k => selectedIds.has(k.id));
  el.innerHTML = `<div class="table-wrap"><table>
    <thead><tr>
      <th class="select-col"><input type="checkbox" id="select-all" aria-label="Select all shown keys"${allShown ? ' checked' : ''}></th>
      <th>Key</th><th>Label</th><th>Status</th><th>Duration</th><th>Expires</th><th>Last used</th><th></th>
    </tr></thead>
    <tbody>${keyRows(keys)}</tbody>
  </table></div>`;
  updateBulkBar();
}

let selectedIds = new Set();

function updateBulkBar() {
  const bar = $('#bulk-bar');
  if (!bar) return;
  const live = new Set(cachedKeys.map(k => k.id));
  for (const id of [...selectedIds]) if (!live.has(id)) selectedIds.delete(id);
  bar.hidden = selectedIds.size === 0;
  const count = $('#bulk-count');
  if (count) count.textContent = `${selectedIds.size} selected`;
}

function csvCell(value) {
  const text = value == null ? '' : String(value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function exportKeysCsv(keys) {
  const header = ['Key hint', 'Label', 'Status', 'Duration', 'Created', 'Expires', 'Last used'];
  const rows = keys.map(k => [k.hint, k.label, k.status, k.lifetime, k.createdAt, k.expiresAt || 'Never', k.lastUsedAt || '']);
  const csv = [header, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `regex-keys-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function refreshKeys() {
  const data = await api('api/keys');
  cachedKeys = data.keys || [];
  renderTable(filterKeys($('#key-search')?.value));
}

async function renderKeys() {
  const lifeOptions = LIFETIME_OPTIONS.map(([v, t]) =>
    `<option value="${v}"${v === '30d' ? ' selected' : ''}>${esc(t)}</option>`).join('');
  const unitOptions = Object.keys(UNIT_LABELS).map(u =>
    `<option value="${u}"${u === 'days' ? ' selected' : ''}>${u}</option>`).join('');

  $('#view').innerHTML = `
    <div class="card">
      <h3>${icon('plus')} Create keys</h3>
      <form id="key-form" class="key-form">
        <label class="field-group wide">
          <span class="field-label">Label</span>
          <input id="key-label" maxlength="60" placeholder="Buyer name, server, note…">
        </label>
        <label class="field-group">
          <span class="field-label">Duration</span>
          <select id="key-life">${lifeOptions}</select>
        </label>
        <div class="field-group" id="custom-wrap" hidden>
          <span class="field-label">Custom duration</span>
          <div class="custom-row">
            <input id="custom-value" type="number" min="1" step="1" value="7" aria-label="Duration value">
            <select id="custom-unit" aria-label="Duration unit">${unitOptions}</select>
          </div>
        </div>
        <label class="field-group">
          <span class="field-label">Timer starts</span>
          <select id="key-start">
            <option value="created">Right away</option>
            <option value="first_use">On first use</option>
          </select>
        </label>
        <label class="field-group">
          <span class="field-label">How many</span>
          <input id="key-count-input" type="number" min="1" max="25" step="1" value="1">
        </label>
        <button type="submit" id="key-btn">${icon('plus', 'sm')} Create</button>
      </form>
      <p class="muted fs09 mb12" id="key-preview"></p>
      <div id="key-result"></div>
    </div>

    <div class="card delay-1">
      <h3>${icon('server')} Validation endpoint</h3>
      <p class="muted mb12 fs09">
        Put this URL in the script’s <code>KeyValidateUrl</code> setting. Keys created here work immediately.
      </p>
      <div class="endpoint">
        <code id="validate-url"></code>
        <button type="button" class="ghost small" id="copy-url">${icon('copy', 'sm')} Copy</button>
      </div>
    </div>

    <div class="card delay-2">
      <h3>${icon('key')} All keys</h3>
      <div class="chips" id="key-filters"></div>
      <div class="search-row">
        <input id="key-search" type="search" placeholder="Search by label, hint or status…" aria-label="Search keys">
        <select id="key-sort" class="sort-select" aria-label="Sort keys">
          <option value="newest">Newest first</option>
          <option value="oldest">Oldest first</option>
          <option value="expiry">Expires soonest</option>
          <option value="label">Label A–Z</option>
        </select>
        <span class="count" id="key-count"></span>
        <button type="button" class="ghost small" id="export-csv">${icon('copy', 'sm')} Export CSV</button>
        <button type="button" class="ghost small" id="purge-btn" disabled></button>
      </div>
      <div class="bulk-bar" id="bulk-bar" hidden>
        <span id="bulk-count">0 selected</span>
        <div class="row-actions">
          <button type="button" class="danger small" data-bulk="revoke">${icon('trash', 'sm')} Revoke</button>
          <button type="button" class="ghost small" data-bulk="restore">${icon('refresh', 'sm')} Restore</button>
          <button type="button" class="danger small" data-bulk="delete">${icon('trash', 'sm')} Delete</button>
          <button type="button" class="ghost small" data-bulk="clear">Clear selection</button>
        </div>
      </div>
      <div id="key-table"><div class="state"><div class="spinner"></div></div></div>
    </div>`;

  // The access code is the first path segment, e.g. /<ACCESS>/regex/ -> /<ACCESS>/api/validate
  const accessCode = location.pathname.split('/').filter(Boolean)[0] || '';
  $('#validate-url').textContent = location.origin + '/' + accessCode + '/api/validate?key=';
  $('#key-life').addEventListener('change', refreshCreateForm);
  $('#custom-value').addEventListener('input', refreshCreateForm);
  $('#custom-unit').addEventListener('change', refreshCreateForm);
  $('#key-start').addEventListener('change', refreshCreateForm);
  refreshCreateForm();

  $('#key-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#key-btn');
    if (btn.disabled) return;
    const body = lifetimeBody();
    if (body.value !== null && (!Number.isInteger(body.value) || body.value < 1)) {
      toast('Enter a whole number of at least 1 for the duration', 'err');
      return;
    }
    const count = Number($('#key-count-input').value);
    if (!Number.isInteger(count) || count < 1 || count > 25) {
      toast('You can create between 1 and 25 keys at a time', 'err');
      return;
    }
    btn.disabled = true;
    btn.textContent = 'Creating…';
    try {
      const created = await api('api/keys', {
        method: 'POST',
        body: {
          label: $('#key-label').value,
          count,
          lifetime: body,
          activation: $('#key-start').value,
        },
      });
      const list = created.keys || [created.key];
      $('#key-label').value = '';
      $('#key-result').innerHTML = `
        <div class="key-box">
          <div class="warn">${icon('alert', 'sm')}
            <span>Copy ${list.length > 1 ? 'these keys' : 'this key'} now. For security ${list.length > 1 ? 'they' : 'it'} will <strong>never</strong> be shown again.</span>
          </div>
          <pre class="new-keys" id="new-keys">${list.map(esc).join('\n')}</pre>
          <div class="row-actions">
            <button type="button" class="small" id="copy-keys">${icon('copy', 'sm')} Copy ${list.length > 1 ? 'all' : 'key'}</button>
            <button type="button" class="ghost small" id="dismiss-key">Done</button>
          </div>
        </div>`;
      toast(`${list.length} key${list.length > 1 ? 's' : ''} created`, 'ok');
      await refreshKeys();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      btn.disabled = false;
      btn.innerHTML = icon('plus', 'sm') + ' Create';
    }
  });

  $('#key-sort').addEventListener('change', (e) => {
    keySort = e.target.value;
    renderTable(filterKeys($('#key-search').value));
  });
  $('#key-search').addEventListener('input', () => {
    renderTable(filterKeys($('#key-search').value));
  });

  await refreshKeys();
}

let editingKey = null;

function parseLifetimeLabel(label) {
  if (!label || /^never/i.test(label)) return { preset: 'never', value: 1, unit: 'days' };
  const m = /^(\d+) (minute|hour|day|week|month|year)s?$/i.exec(label.trim());
  if (!m) return { preset: 'custom', value: 7, unit: 'days' };
  const value = Number(m[1]);
  const unit = m[2].toLowerCase() + 's';
  for (const [id, body] of Object.entries(LIFETIME_PRESETS)) {
    if (body.value === value && body.unit === unit) return { preset: id, value, unit };
  }
  return { preset: 'custom', value, unit };
}

function editLifetimeBody() {
  const preset = $('#edit-life').value;
  if (preset === 'never') return { value: null };
  if (preset === 'custom') return { value: Number($('#edit-value').value), unit: $('#edit-unit').value };
  return LIFETIME_PRESETS[preset];
}

function refreshEditFields() {
  const preset = $('#edit-life').value;
  $('#edit-custom').hidden = preset !== 'custom';
  const note = editingKey && editingKey.status === 'unused'
    ? 'This key has not been used yet. Its timer will start on first use with the duration you choose.'
    : (preset === 'never' ? 'This key will not expire.' : '');
  $('#edit-note').textContent = note;
}

function openEdit(id) {
  const key = cachedKeys.find(k => k.id === id);
  if (!key) return;
  editingKey = key;
  const parsed = parseLifetimeLabel(key.lifetime);
  $('#edit-hint').textContent = `${key.hint} · ${key.status === 'unused' ? 'not started' : key.status}`;
  $('#edit-label').value = key.label || '';
  $('#edit-life').value = parsed.preset;
  $('#edit-value').value = parsed.value;
  $('#edit-unit').value = parsed.unit;
  refreshEditFields();
  $('#edit-dialog').showModal();
  $('#edit-label').focus();
}

$('#edit-life').innerHTML = LIFETIME_OPTIONS.map(([v, t]) => `<option value="${v}">${esc(t)}</option>`).join('');
$('#edit-unit').innerHTML = Object.keys(UNIT_LABELS).map(u => `<option value="${u}">${u}</option>`).join('');
$('#edit-life').addEventListener('change', refreshEditFields);
$('#edit-cancel').addEventListener('click', () => $('#edit-dialog').close());

$('#edit-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!editingKey) return;
  const btn = $('#edit-save');
  btn.disabled = true;
  try {
    const id = editingKey.id;
    const label = $('#edit-label').value.trim();
    if (label !== (editingKey.label || '')) {
      await api(`api/keys/${id}/rename`, { method: 'POST', body: { label } });
    }
    const lifetime = editLifetimeBody();
    if (lifetime.value !== null && (!Number.isInteger(lifetime.value) || lifetime.value < 1)) {
      throw new Error('Enter a whole number of at least 1 for the duration');
    }
    const before = parseLifetimeLabel(editingKey.lifetime);
    const changed = $('#edit-life').value !== before.preset
      || (lifetime.value !== null && (lifetime.value !== before.value || lifetime.unit !== before.unit));
    if (changed) {
      await api(`api/keys/${id}/time`, { method: 'POST', body: { lifetime } });
    }
    $('#edit-dialog').close();
    toast('Key updated', 'ok');
    await refreshKeys();
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    btn.disabled = false;
  }
});

/* View actions */
$('#view').addEventListener('click', async (e) => {
  const t = (sel) => e.target.closest(sel);
  try {
    if (t('#copy-keys')) {
      await navigator.clipboard.writeText($('#new-keys').textContent);
      toast('Copied to clipboard', 'ok');
    }
    if (t('#dismiss-key')) $('#key-result').innerHTML = '';
    if (t('#copy-url')) {
      await navigator.clipboard.writeText($('#validate-url').textContent);
      toast('Endpoint copied', 'ok');
    }
    const chip = t('[data-filter]');
    if (chip) {
      keyFilter = chip.dataset.filter;
      renderTable(filterKeys($('#key-search')?.value));
    }
    if (t('#purge-btn')) {
      const n = cachedKeys.filter(k => k.status === 'revoked' || k.status === 'expired').length;
      if (n && confirm(`Permanently delete ${n} revoked or expired key${n > 1 ? 's' : ''}? This cannot be undone.`)) {
        const res = await api('api/keys/purge', { method: 'POST' });
        toast(`${res.deleted} key${res.deleted === 1 ? '' : 's'} deleted`, 'ok');
        await refreshKeys();
      }
    }
    const rev = t('[data-revoke]');
    if (rev && confirm('Revoke this key? Anyone using it will lose access immediately.')) {
      await api(`api/keys/${rev.dataset.revoke}/revoke`, { method: 'POST' });
      toast('Key revoked', 'ok');
      await refreshKeys();
    }
    const res2 = t('[data-restore]');
    if (res2) {
      await api(`api/keys/${res2.dataset.restore}/restore`, { method: 'POST' });
      toast('Key restored', 'ok');
      await refreshKeys();
    }
    const del = t('[data-delete]');
    if (del && confirm('Delete this key permanently? This cannot be undone.')) {
      await api(`api/keys/${del.dataset.delete}/delete`, { method: 'POST' });
      toast('Key deleted', 'ok');
      await refreshKeys();
    }
    const edit = t('[data-edit]');
    if (edit) openEdit(Number(edit.dataset.edit));
    if (t('#export-csv')) {
      exportKeysCsv(filterKeys($('#key-search')?.value));
      toast('CSV downloaded', 'ok');
    }
    const bulk = t('[data-bulk]');
    if (bulk) {
      const action = bulk.dataset.bulk;
      if (action === 'clear') {
        selectedIds.clear();
        renderTable(filterKeys($('#key-search')?.value));
      } else {
        const ids = [...selectedIds];
        const verb = { revoke: 'Revoke', restore: 'Restore', delete: 'Delete' }[action];
        const warn = action === 'delete' ? ' This cannot be undone.' : (action === 'revoke' ? ' Anyone using these keys will lose access.' : '');
        if (confirm(`${verb} ${ids.length} key${ids.length === 1 ? '' : 's'}?${warn}`)) {
          const res = await api('api/keys/bulk', { method: 'POST', body: { action, ids } });
          toast(`${res.done} done${res.skipped ? `, ${res.skipped} skipped` : ''}`, res.skipped ? '' : 'ok');
          selectedIds.clear();
          await refreshKeys();
        }
      }
    }
  } catch (err) {
    toast(err.message, 'err');
  }
});

$('#view').addEventListener('change', (e) => {
  const box = e.target.closest('[data-select]');
  if (box) {
    const id = Number(box.dataset.select);
    if (box.checked) selectedIds.add(id); else selectedIds.delete(id);
    updateBulkBar();
    const all = $('#select-all');
    if (all) all.checked = cachedKeys.length > 0 && filterKeys($('#key-search')?.value).every(k => selectedIds.has(k.id));
    return;
  }
  if (e.target.closest('#select-all')) {
    const shown = filterKeys($('#key-search')?.value);
    for (const k of shown) {
      if (e.target.checked) selectedIds.add(k.id); else selectedIds.delete(k.id);
    }
    renderTable(shown);
  }
});

document.addEventListener('keydown', (e) => {
  const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes((document.activeElement && document.activeElement.tagName) || '');
  if (e.key === '?' && !typing && !e.ctrlKey && !e.metaKey) {
    e.preventDefault();
    const dlg = $('#shortcuts-dialog');
    if (dlg && !dlg.open) dlg.showModal();
    return;
  }
  if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
  const tag = (document.activeElement && document.activeElement.tagName) || '';
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  const search = $('#key-search');
  if (search) {
    e.preventDefault();
    search.focus();
  }
});

/* ─── Activity ─── */
async function renderActivity() {
  const data = await api('api/activity');
  const entries = data.entries || [];
  $('#view').innerHTML = `
    <div class="card">
      <h3>${icon('activity')} Activity log</h3>
      <p class="muted mb14 fs09">
        Sign-ins, key creation and revocations. Secrets are never logged.
      </p>
      ${activityTable(entries)}
    </div>
    <div class="card delay-1">
      <h3>${icon('info')} About this log</h3>
      <div class="info-grid">
        <div class="info-item">
          <div class="label">Events tracked</div>
          <div class="val">login, logout, key.created, key.revoked</div>
        </div>
        <div class="info-item">
          <div class="label">Retention</div>
          <div class="val">Latest 60 events shown</div>
        </div>
      </div>
    </div>`;
}

/* ─── Settings ─── */
async function renderSettings() {
  await renderSettingsBase();
  const sessions = await api('api/sessions');
  $('#view').insertAdjacentHTML('beforeend', `
    <section class="card delay-1 session-card">
      <div class="card-head"><h3>Signed-in devices</h3><span class="chip-static">${sessions.count} active</span></div>
      <p class="muted fs09">Your password is never stored in this browser. The sign-in is an HttpOnly cookie, and the server keeps only a hash of the session. Signing out everywhere ends every session, including this one.</p>
      <div class="row-actions mt12"><button type="button" class="danger small" id="signout-all">Sign out everywhere</button></div>
    </section>`);
  $('#signout-all').addEventListener('click', async () => {
    if (!confirm('Sign out of every device? You will need the password again.')) return;
    await api('api/logout-all', { method: 'POST' });
    showLogin();
    toast('Signed out everywhere', 'ok');
  });
}

async function renderSettingsBase() {
  const data = await api('api/settings');
  const items = data.integrations || [];

  $('#view').innerHTML = `
    <div class="card">
      <h3>${icon('settings')} System status</h3>
      ${items.map((i, idx) => `
        <div class="setting-row delay-${idx+1}">
          <div>
            <strong class="setting-name">${icon(i.id === 'auth' ? 'shield' : i.id === 'database' ? 'server' : 'info', 'sm')} ${esc(i.label)}</strong>
            <div class="muted muted-sm">${esc(i.message)}</div>
          </div>
          <span class="badge ${i.state === 'ok' ? 'active' : i.state === 'pending' ? 'expired' : 'revoked'}">${esc(i.state)}</span>
        </div>`).join('')}
    </div>

    <div class="card delay-2">
      <h3>${icon('shield')} Security</h3>
      <div class="info-grid">
        <div class="info-item">
          <div class="label">Admin password</div>
          <div class="val">ADMIN_PASSWORD secret, or the built-in default when unset</div>
        </div>
        <div class="info-item">
          <div class="label">Key storage</div>
          <div class="val">SHA-256 hashes only (full key shown once)</div>
        </div>
        <div class="info-item">
          <div class="label">Session</div>
          <div class="val">12 hours · HttpOnly · SameSite=Strict</div>
        </div>
        <div class="info-item">
          <div class="label">Login rate limit</div>
          <div class="val">8 attempts / 10 minutes per IP</div>
        </div>
      </div>
    </div>

    <div class="card delay-3">
      <h3>${icon('info')} Password</h3>
      <p class="muted fs09">
        Set the password with <code>npx wrangler secret put ADMIN_PASSWORD</code>.
        The status above shows whether the secret is in use.
      </p>
    </div>`;
}

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-retry]')) route();
});

/* Boot */
async function loadVersion() {
  try {
    const r = await fetch('api/health', { cache: 'no-store' });
    const h = await r.json();
    if (h.version) {
      $('#app-version').textContent = `v${h.version} · Admin`;
      $('#login-version').textContent = `Regex Manager v${h.version}`;
    }
  } catch {}
}

async function boot() {
  loadVersion();
  try {
    const session = await api('api/session', { silent: true });
    if (session.authenticated) {
      showApp();
      route();
      return;
    }
  } catch {}
  showLogin();
}
boot();


LABELS.dominant = { title: 'Dominant', sub: 'B2 file storage with D1 metadata and access controls' };

const BINARY_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.ico', '.psd', '.mp3', '.ogg', '.wav', '.flac', '.m4a', '.aac', '.mp4', '.webm', '.mov', '.avi', '.mkv', '.ttf', '.otf', '.woff', '.woff2', '.eot', '.zip', '.rar', '.7z', '.tar', '.gz', '.pdf', '.exe', '.dll', '.so', '.bin', '.rbxm', '.rbxmx', '.rbxl', '.rbxlx', '.mesh', '.anim', '.obj', '.fbx', '.blend']);
const SKIP_SEGMENTS = new Set(['.git', 'node_modules']);
const BATCH = 3; // Binary files are base64 encoded; small batches avoid oversized Worker requests.

function accessCode() {
  return location.pathname.split('/').filter(Boolean)[0] || '';
}

function extOf(name) {
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(dot).toLowerCase() : '';
}

function buildTree(files) {
  const root = { folders: {}, files: [] };
  for (const f of files) {
    const parts = f.path.split('/');
    let node = root;
    for (const part of parts.slice(0, -1)) {
      node.folders[part] = node.folders[part] || { folders: {}, files: [] };
      node = node.folders[part];
    }
    node.files.push({ name: parts[parts.length - 1], path: f.path, size: f.size || 0 });
  }
  return root;
}

function countFiles(node) {
  return node.files.length + Object.values(node.folders).reduce((n, child) => n + countFiles(child), 0);
}

function folderBytes(node) {
  return node.files.reduce((n, f) => n + (f.size || 0), 0)
    + Object.values(node.folders).reduce((n, child) => n + folderBytes(child), 0);
}

/** Selection state for Dominant tree (survives re-renders within the page). */
let domSel = { files: new Set(), folders: new Set() };

function treeHtml(node, prefix, depth, forceOpen) {
  const d = 'd' + Math.min(depth, 6);
  const folders = Object.keys(node.folders).sort((a, b) => a.localeCompare(b));
  const files = [...node.files].sort((a, b) => a.name.localeCompare(b.name));
  const folderHtml = folders.map((name) => {
    const path = prefix ? prefix + '/' + name : name;
    const child = node.folders[name];
    const open = forceOpen || depth < 1 ? ' open' : '';
    const checked = domSel.folders.has(path);
    const n = countFiles(child);
    return `<div class="tree-folder${open}" data-folder-node data-path="${esc(path)}">
      <div class="tree-row folder ${d}${checked ? ' selected' : ''}" data-folder="${esc(path)}" role="treeitem" aria-expanded="${open ? 'true' : 'false'}">
        <label class="tree-check" title="Select folder">
          <input type="checkbox" data-sel-folder="${esc(path)}" ${checked ? 'checked' : ''} aria-label="Select folder ${esc(name)}">
          <span class="tree-check-ui" aria-hidden="true"></span>
        </label>
        <span class="chev" aria-hidden="true">${icon('chevron-right', 'sm')}</span>
        <span class="tree-ico" aria-hidden="true">${icon('folder', 'sm')}</span>
        <span class="tree-name">${esc(name)}</span>
        <span class="tree-meta"><span class="tree-count">${n} file${n === 1 ? '' : 's'}</span><span class="tree-size">${fmtBytes(folderBytes(child))}</span></span>
      </div>
      <div class="tree-children"><div class="tree-inner">${treeHtml(child, path, depth + 1, forceOpen)}</div></div>
    </div>`;
  }).join('');
  const fileHtml = files.map((f) => {
    const checked = domSel.files.has(f.path);
    return `<div class="tree-row file ${d}${checked ? ' selected' : ''}" data-file="${esc(f.path)}" role="treeitem">
      <label class="tree-check" title="Select file">
        <input type="checkbox" data-sel-file="${esc(f.path)}" ${checked ? 'checked' : ''} aria-label="Select ${esc(f.name)}">
        <span class="tree-check-ui" aria-hidden="true"></span>
      </label>
      <span class="tree-ico file-ico" aria-hidden="true">${icon('file', 'sm')}</span>
      <span class="tree-name">${esc(f.name)}</span>
      <span class="tree-meta"><span class="tree-size">${fmtBytes(f.size)}</span></span>
    </div>`;
  }).join('');
  return folderHtml + fileHtml;
}

function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(2) + ' MB';
}

function updateDomBulkBar() {
  const bar = $('#dom-bulk-bar');
  if (!bar) return;
  const n = domSel.files.size + domSel.folders.size;
  bar.hidden = n === 0;
  const count = $('#dom-bulk-count');
  if (count) {
    const parts = [];
    if (domSel.files.size) parts.push(`${domSel.files.size} file${domSel.files.size === 1 ? '' : 's'}`);
    if (domSel.folders.size) parts.push(`${domSel.folders.size} folder${domSel.folders.size === 1 ? '' : 's'}`);
    count.textContent = parts.join(' · ') + ' selected';
  }
}

async function deleteDominantSelection() {
  const files = [...domSel.files];
  const folders = [...domSel.folders].sort((a, b) => b.length - a.length); // deepest first
  if (!files.length && !folders.length) return;
  const label = [
    files.length ? `${files.length} file${files.length === 1 ? '' : 's'}` : null,
    folders.length ? `${folders.length} folder${folders.length === 1 ? '' : 's'}` : null,
  ].filter(Boolean).join(' and ');
  if (!confirm(`Permanently delete ${label}? This cannot be undone.`)) return;

  let deleted = 0;
  const errors = [];
  for (const path of files) {
    try {
      await api('api/dominant/files?path=' + encodeURIComponent(path), { method: 'DELETE' });
      deleted++;
      domSel.files.delete(path);
    } catch (err) {
      errors.push({ path, error: err.message });
    }
  }
  for (const prefix of folders) {
    try {
      const res = await api('api/dominant/folder?prefix=' + encodeURIComponent(prefix), { method: 'DELETE' });
      deleted += res.deleted || 0;
      domSel.folders.delete(prefix);
      // drop any selected files that lived under this folder
      for (const p of [...domSel.files]) {
        if (p === prefix || p.startsWith(prefix + '/')) domSel.files.delete(p);
      }
    } catch (err) {
      errors.push({ path: prefix + '/', error: err.message });
    }
  }
  toast(
    errors.length
      ? `Deleted ${deleted}, ${errors.length} error${errors.length === 1 ? '' : 's'}`
      : `Deleted ${deleted} item${deleted === 1 ? '' : 's'}`,
    errors.length ? 'err' : 'ok'
  );
  if (errors.length) console.warn('Dominant delete errors', errors);
  renderDominant({ query: $('#dom-search')?.value || '' });
}

async function renderDominant(state = {}) {
  const view = $('#view');
  const data = await api('api/dominant/files');
  const all = data.files || [];
  let storageLabel = data.storage || 'd1';
  let b2Configured = false;
  try {
    const meta = await api('api/dominant/meta');
    if (meta && meta.storage) storageLabel = meta.storage;
    b2Configured = meta?.b2Configured === true;
  } catch {}
  // prune selection of paths that no longer exist
  const live = new Set(all.map((f) => f.path));
  for (const p of [...domSel.files]) if (!live.has(p)) domSel.files.delete(p);
  // folders stay selected even if empty after filter; prune only if no file under them
  for (const folder of [...domSel.folders]) {
    const still = all.some((f) => f.path === folder || f.path.startsWith(folder + '/'));
    if (!still) domSel.folders.delete(folder);
  }

  const query = (state.query || '').trim().toLowerCase();
  const shown = query ? all.filter((f) => f.path.toLowerCase().includes(query)) : all;
  const total = all.reduce((n, f) => n + (f.size || 0), 0);
  const access = accessCode();
  const origin = location.origin;

  view.innerHTML = `
    <section class="card dom-head">
      <div class="dom-stats">
        <div><span class="muted2">Files</span><strong>${all.length}</strong></div>
        <div><span class="muted2">Total size</span><strong>${fmtBytes(total)}</strong></div>
        <div><span class="muted2">Showing</span><strong>${shown.length}</strong></div>
        <div><span class="muted2">Storage</span><strong>${storageLabel}</strong></div>
      </div>
      <div class="dom-actions">
        <button class="small" id="dom-upload-files">${icon('upload', 'sm')} Upload files</button>
        <button class="ghost small" id="dom-upload-folder">${icon('folder', 'sm')} Upload folder</button>
        ${b2Configured ? `<button class="ghost small" id="dom-migrate">${icon('layers', 'sm')} Move legacy D1 files to B2</button>` : ''}
        <button class="ghost small" id="dom-new">${icon('plus', 'sm')} New file</button>
        <input type="file" id="dom-file-input" multiple hidden>
        <input type="file" id="dom-folder-input" webkitdirectory directory multiple hidden>
      </div>
      <div class="progress" id="dom-progress" hidden><div class="progress-bar" id="dom-progress-bar"></div></div>
      <p class="muted2 fs09" id="dom-progress-text" hidden></p>
    </section>

    <div class="dom-bulk-bar" id="dom-bulk-bar" hidden>
      <span id="dom-bulk-count">0 selected</span>
      <div class="dom-bulk-actions">
        <button type="button" class="danger small" id="dom-bulk-delete">${icon('trash', 'sm')} Delete selected</button>
        <button type="button" class="ghost small" id="dom-bulk-clear">Clear selection</button>
      </div>
    </div>

    <div class="dom-grid">
      <section class="card dom-tree-card">
        <div class="card-head">
          <h3>Files</h3>
          <div class="dom-tree-tools">
            <button type="button" class="ghost small" id="dom-expand-all" title="Expand all">Expand</button>
            <button type="button" class="ghost small" id="dom-collapse-all" title="Collapse all">Collapse</button>
            <input id="dom-search" class="dom-search" type="search" placeholder="Filter by path…" value="${esc(state.query || '')}">
          </div>
        </div>
        <div class="dom-tree" id="dom-tree" role="tree" aria-label="Dominant files">
          ${all.length ? treeHtml(buildTree(shown), '', 0, !!query) : '<div class="state">No files yet. Upload a folder to start.</div>'}
        </div>
      </section>

      <section class="card dom-detail" id="dom-detail">
        <div class="state"><p class="muted2">Select a file to preview it.<br><span class="fs09">Use the checkboxes to multi-select files and folders for bulk delete.</span></p></div>
      </section>
    </div>

    <section class="card">
      <div class="card-head"><h3>Loadstring</h3></div>
      <p class="muted2 fs09">Paste this in an executor. The key must be a Regex key that is not revoked or expired.</p>
      <div class="field-row">
        <input id="dom-key" placeholder="REGEX_xxxxxxxxxx" autocomplete="off" spellcheck="false">
        <button class="small" id="dom-make">Generate</button>
      </div>
      <pre class="code-block" id="dom-snippet">loadstring(game:HttpGet("${esc(origin)}/${esc(access)}/regex/api/dominant/load?key=KEY"))()</pre>
      <div class="row-actions"><button class="ghost small" id="dom-copy">${icon('copy', 'sm')} Copy</button></div>
    </section>`;

  wireDominant(all, state);
  updateDomBulkBar();
}

function wireDominant(all, state) {
  const tree = $('#dom-tree');
  if (tree) {
    tree.addEventListener('click', (e) => {
      // checkbox toggle is handled by change; don't also expand/preview
      if (e.target.closest('.tree-check')) return;

      const folder = e.target.closest('[data-folder]');
      if (folder) {
        const node = folder.closest('[data-folder-node]');
        if (!node) return;
        const open = node.classList.toggle('open');
        folder.setAttribute('aria-expanded', String(open));
        const ico = folder.querySelector('.tree-ico');
        if (ico) ico.innerHTML = icon(open ? 'folder-open' : 'folder', 'sm');
        return;
      }
      const file = e.target.closest('[data-file]');
      if (file) {
        $$('.tree-row.file.active-preview').forEach((el) => el.classList.remove('active-preview'));
        file.classList.add('active-preview');
        showFile(file.dataset.file);
      }
    });

    tree.addEventListener('change', (e) => {
      const folderBox = e.target.closest('[data-sel-folder]');
      if (folderBox) {
        const path = folderBox.dataset.selFolder;
        if (folderBox.checked) domSel.folders.add(path);
        else domSel.folders.delete(path);
        const row = folderBox.closest('.tree-row');
        if (row) row.classList.toggle('selected', folderBox.checked);
        updateDomBulkBar();
        return;
      }
      const fileBox = e.target.closest('[data-sel-file]');
      if (fileBox) {
        const path = fileBox.dataset.selFile;
        if (fileBox.checked) domSel.files.add(path);
        else domSel.files.delete(path);
        const row = fileBox.closest('.tree-row');
        if (row) row.classList.toggle('selected', fileBox.checked);
        updateDomBulkBar();
      }
    });
  }

  $('#dom-bulk-delete')?.addEventListener('click', () => deleteDominantSelection());
  $('#dom-bulk-clear')?.addEventListener('click', () => {
    domSel.files.clear();
    domSel.folders.clear();
    $$('#dom-tree input[type=checkbox]').forEach((el) => { el.checked = false; });
    $$('#dom-tree .tree-row.selected').forEach((el) => el.classList.remove('selected'));
    updateDomBulkBar();
  });

  $('#dom-expand-all')?.addEventListener('click', () => {
    $$('#dom-tree .tree-folder').forEach((n) => {
      n.classList.add('open');
      const row = n.querySelector(':scope > .tree-row');
      if (row) {
        row.setAttribute('aria-expanded', 'true');
        const ico = row.querySelector('.tree-ico');
        if (ico) ico.innerHTML = icon('folder-open', 'sm');
      }
    });
  });
  $('#dom-collapse-all')?.addEventListener('click', () => {
    $$('#dom-tree .tree-folder').forEach((n) => {
      n.classList.remove('open');
      const row = n.querySelector(':scope > .tree-row');
      if (row) {
        row.setAttribute('aria-expanded', 'false');
        const ico = row.querySelector('.tree-ico');
        if (ico) ico.innerHTML = icon('folder', 'sm');
      }
    });
  });

  $('#dom-search').addEventListener('input', (e) => {
    clearTimeout(wireDominant.timer);
    wireDominant.timer = setTimeout(() => renderDominant({ query: e.target.value }), 200);
  });

  $('#dom-upload-files').addEventListener('click', () => $('#dom-file-input').click());
  $('#dom-upload-folder').addEventListener('click', () => $('#dom-folder-input').click());
  $('#dom-file-input').addEventListener('change', (e) => uploadList(e.target.files, false));
  $('#dom-folder-input').addEventListener('change', (e) => uploadList(e.target.files, true));
  $('#dom-migrate')?.addEventListener('click', async () => {
    const button = $('#dom-migrate');
    if (!button || !confirm('Move old text files from D1 to B2? Each file is checked and removed from D1 only after the B2 write succeeds.')) return;
    button.disabled = true;
    let moved = 0;
    const errors = [];
    try {
      while (true) {
        const res = await api('api/dominant/migrate', { method: 'POST', body: { limit: 10 } });
        moved += Number(res.moved || 0);
        errors.push(...(res.errors || []));
        button.textContent = `Migrated ${moved}…`;
        if (errors.length || Number(res.remaining || 0) === 0 || Number(res.moved || 0) === 0) break;
      }
      toast(`Moved ${moved} D1 files to B2${errors.length ? ` · ${errors.length} errors` : ''}`, errors.length ? 'err' : 'ok');
      if (errors.length) console.warn('D1 to B2 migration errors', errors);
      renderDominant({ query: $('#dom-search')?.value || '' });
    } catch (err) {
      toast(`Migration failed: ${err.message}`, 'err');
    } finally {
      if (button.isConnected) button.disabled = false;
    }
  });
  $('#dom-new').addEventListener('click', async () => {
    const path = prompt('Path for the new file (for example core/config.lua)');
    if (!path) return;
    try {
      await api('api/dominant/files', { method: 'PUT', body: { path, content: '' } });
      toast('File created', 'ok');
      renderDominant({ query: $('#dom-search')?.value || '' });
    } catch (err) {
      toast(err.message, 'err');
    }
  });

  $('#dom-make').addEventListener('click', () => {
    const key = $('#dom-key').value.trim();
    const access = accessCode();
    $('#dom-snippet').textContent = `loadstring(game:HttpGet("${location.origin}/${access}/regex/api/dominant/load?key=${key || 'KEY'}"))()`;
  });
  $('#dom-copy').addEventListener('click', async () => {
    await navigator.clipboard.writeText($('#dom-snippet').textContent);
    toast('Copied', 'ok');
  });
}

const SAFE_MEDIA_TYPE = /^(image|audio|video)\/[\w.+-]+$/;

// Images, audio and video are shown inline from the base64 the server sends. Other binaries get a notice.
function mediaOrText(file) {
  const type = String(file.contentType || '');
  if (file.binary && SAFE_MEDIA_TYPE.test(type) && /^[A-Za-z0-9+/=]+$/.test(file.base64 || '')) {
    const src = `data:${type};base64,${file.base64}`;
    if (type.startsWith('image/')) return `<img class="media-preview" src="${src}" alt="${esc(file.path)}">`;
    if (type.startsWith('audio/')) return `<audio class="media-preview" controls preload="metadata" src="${src}"></audio>`;
    if (type.startsWith('video/')) return `<video class="media-preview" controls preload="metadata" src="${src}"></video>`;
  }
  if (file.binary) {
    return `<pre class="code-block code-preview">${esc('Binary file. Content type: ' + (type || 'application/octet-stream'))}</pre>`;
  }
  return `<pre class="code-block code-preview">${esc(String(file.content ?? ''))}</pre>`;
}

async function showFile(path) {
  const detail = $('#dom-detail');
  detail.innerHTML = '<div class="state"><div class="spinner"></div></div>';
  try {
    const { file } = await api('api/dominant/file?path=' + encodeURIComponent(path));
    const body = mediaOrText(file);
    detail.innerHTML = `
      <div class="card-head"><h3 class="dom-path">${esc(file.path)}</h3></div>
      <p class="muted2 fs09">${fmtBytes(file.size)} · updated ${esc(fmtDate(file.updated_at))} · sha ${esc(String(file.sha256 || '').slice(0, 12))}</p>
      ${body}
      <div class="row-actions">
        <button class="danger small" id="dom-delete-file">${icon('trash', 'sm')} Delete file</button>
        <button class="ghost small" id="dom-select-file">${icon('check', 'sm')} Add to selection</button>
      </div>`;
    $('#dom-delete-file').addEventListener('click', async () => {
      if (!confirm(`Delete ${file.path}?`)) return;
      await api('api/dominant/files?path=' + encodeURIComponent(file.path), { method: 'DELETE' });
      domSel.files.delete(file.path);
      toast('File deleted', 'ok');
      renderDominant({ query: $('#dom-search')?.value || '' });
    });
    $('#dom-select-file').addEventListener('click', () => {
      domSel.files.add(file.path);
      const box = $(`#dom-tree [data-sel-file="${CSS.escape(file.path)}"]`);
      if (box) {
        box.checked = true;
        box.closest('.tree-row')?.classList.add('selected');
      }
      updateDomBulkBar();
      toast('Added to selection', 'ok');
    });
  } catch (err) {
    detail.innerHTML = `<div class="state"><p class="err-text">${esc(err.message)}</p></div>`;
  }
}

async function fileToBase64(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

async function uploadList(fileList, fromFolder) {
  const files = [...fileList];
  if (!files.length) return;
  const skipped = { large: 0, hidden: 0 };
  const errors = [];
  let saved = 0;
  let processed = 0;
  let batch = [];

  const bar = $('#dom-progress');
  const barFill = $('#dom-progress-bar');
  const text = $('#dom-progress-text');
  bar.hidden = false;
  text.hidden = false;
  barFill.style.width = '0%';

  const sendBatch = async () => {
    if (!batch.length) return;
    const current = batch;
    batch = [];
    try {
      const res = await api('api/dominant/import', { method: 'POST', body: { files: current } });
      saved += Number(res.count || 0);
      errors.push(...(res.errors || []));
    } catch (err) {
      for (const item of current) errors.push({ path: item.path, error: err.message || String(err) });
    }
  };

  for (const file of files) {
    let path = file.name;
    if (fromFolder && file.webkitRelativePath) {
      const parts = file.webkitRelativePath.split('/');
      path = parts.slice(1).join('/');
    }

    if (!path || path.split('/').some((segment) => SKIP_SEGMENTS.has(segment))) {
      skipped.hidden++;
      processed++;
      continue;
    }

    const ext = extOf(file.name);
    let item;
    try {
      const namedBinary = BINARY_EXT.has(ext);
      if (namedBinary) {
        if (file.size > 8_000_000) {
          skipped.large++;
          processed++;
          continue;
        }
        item = { path, content: await fileToBase64(file), base64: true };
      } else {
        if (file.size > 2_000_000) {
          skipped.large++;
          processed++;
          continue;
        }
        const content = await file.text();
        if (content.includes('\u0000')) {
          if (file.size > 8_000_000) {
            skipped.large++;
            processed++;
            continue;
          }
          item = { path, content: await fileToBase64(file), base64: true };
        } else {
          item = { path, content };
        }
      }
      batch.push(item);
    } catch (err) {
      errors.push({ path, error: err.message || String(err) });
    }

    if (batch.length >= BATCH) await sendBatch();
    processed++;
    const percent = Math.round((processed / files.length) * 100);
    barFill.style.width = percent + '%';
    text.textContent = `Uploading ${processed} of ${files.length}…`;
  }
  await sendBatch();

  const summary = `Imported ${saved} · skipped ${skipped.large} oversized · ${skipped.hidden} hidden` + (errors.length ? ` · ${errors.length} errors` : '');
  toast(summary, errors.length ? 'err' : 'ok');
  if (errors.length) console.warn('Dominant import errors', errors);
  renderDominant();
}

/* ─── AI providers and infrastructure ─── */
const STATE_BADGE = {
  connected: ['ok', 'Connected'],
  not_configured: ['muted-badge', 'Not configured'],
  rejected: ['err', 'Key rejected'],
  unreachable: ['err', 'Unreachable'],
  invalid_endpoint: ['err', 'Invalid endpoint'],
  error: ['err', 'Error'],
  configured: ['warn', 'Configured, not verified'],
  missing: ['muted-badge', 'Missing'],
};

function stateBadge(state) {
  const [cls, label] = STATE_BADGE[state] || ['muted-badge', 'Unknown'];
  return `<span class="badge ${cls}">${esc(label)}</span>`;
}

function diffCount(before, after) {
  const a = before.split('\n');
  const b = after.split('\n');
  const inA = new Set(a);
  const inB = new Set(b);
  return { added: b.filter((l) => !inA.has(l)).length, removed: a.filter((l) => !inB.has(l)).length };
}

const AI_MODEL_DEFAULT = 'qwen/qwen3.8-max:free';
const AI_FILE_BLOCK = /<<<FILE ([^\n>]+?)>>>\n?([\s\S]*?)(<<<END FILE>>>|$)/g;

function formatThinkSecs(sec) {
  sec = Math.max(0, Math.round(Number(sec) || 0));
  if (sec < 60) return sec + 's';
  const m = Math.floor(sec / 60);
  const r = sec % 60;
  return m + 'm' + (r ? ' ' + r + 's' : '');
}
function extractFileProposals(text) {
  const out = [];
  if (!text) return out;
  const re = new RegExp(AI_FILE_BLOCK.source, 'g');
  let m;
  while ((m = re.exec(text))) {
    const path = (m[1] || '').trim();
    const proposed = m[2] || '';
    if (!path) continue;
    out.push({ path, proposed, original: '', isNew: true, edited: proposed });
  }
  return out;
}

const AI_PROMPTS = [
  'Explain what this file does and point out risky parts.',
  'Add short comments to the functions that have none.',
  'Find a bug in the attached file and fix it.',
];
const AI_ICON = {
  plus: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  up: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>',
  stop: '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><rect x="5" y="5" width="14" height="14" rx="3"/></svg>',
};

// Markdown for answers. Everything is escaped before any tag is added, so model text cannot inject markup.
function inlineMd(s) {
  return esc(s)
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*\w])\*([^*\n]+)\*/g, '$1<em>$2</em>');
}
const MD_HEAD = /^(#{1,3})\s+(.*)$/;
const MD_UL = /^\s*[-*]\s+(.*)$/;
const MD_OL = /^\s*\d+[.)]\s+(.*)$/;
const MD_QUOTE = /^>\s?(.*)$/;
const MD_RULE = /^\s*-{3,}\s*$/;
const MD_TABLE_ROW = /^\s*\|.*\|\s*$/;
const MD_TABLE_SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
function mdCells(line) {
  return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
}
function mdStartsBlock(line, next) {
  return MD_HEAD.test(line) || MD_RULE.test(line) || MD_QUOTE.test(line) || MD_UL.test(line) || MD_OL.test(line)
    || (MD_TABLE_ROW.test(line) && next !== undefined && MD_TABLE_SEP.test(next));
}
function markdownBlocks(text) {
  const lines = text.split('\n');
  let html = '';
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { i++; continue; }
    let m;
    if ((m = MD_HEAD.exec(line))) {
      const tag = 'h' + (m[1].length + 2);
      html += `<${tag}>${inlineMd(m[2])}</${tag}>`;
      i++;
      continue;
    }
    if (MD_RULE.test(line)) { html += '<hr>'; i++; continue; }
    if (MD_QUOTE.test(line)) {
      const q = [];
      while (i < lines.length && MD_QUOTE.test(lines[i])) { q.push(MD_QUOTE.exec(lines[i])[1]); i++; }
      html += `<blockquote>${inlineMd(q.join(' '))}</blockquote>`;
      continue;
    }
    if (MD_UL.test(line)) {
      const items = [];
      while (i < lines.length && MD_UL.test(lines[i])) { items.push(MD_UL.exec(lines[i])[1]); i++; }
      html += '<ul>' + items.map((t) => `<li>${inlineMd(t)}</li>`).join('') + '</ul>';
      continue;
    }
    if (MD_OL.test(line)) {
      const items = [];
      while (i < lines.length && MD_OL.test(lines[i])) { items.push(MD_OL.exec(lines[i])[1]); i++; }
      html += '<ol>' + items.map((t) => `<li>${inlineMd(t)}</li>`).join('') + '</ol>';
      continue;
    }
    if (MD_TABLE_ROW.test(line) && i + 1 < lines.length && MD_TABLE_SEP.test(lines[i + 1])) {
      const head = mdCells(line);
      i += 2;
      const rows = [];
      while (i < lines.length && MD_TABLE_ROW.test(lines[i])) { rows.push(mdCells(lines[i])); i++; }
      html += '<div class="ai-table-wrap"><table><thead><tr>' + head.map((c) => `<th>${inlineMd(c)}</th>`).join('')
        + '</tr></thead><tbody>' + rows.map((r) => '<tr>' + r.map((c) => `<td>${inlineMd(c)}</td>`).join('') + '</tr>').join('')
        + '</tbody></table></div>';
      continue;
    }
    const para = [];
    while (i < lines.length && lines[i].trim() && !mdStartsBlock(lines[i], lines[i + 1])) { para.push(lines[i]); i++; }
    if (!para.length) { para.push(lines[i]); i++; }
    html += `<p>${inlineMd(para.join(' '))}</p>`;
  }
  return html;
}

function codeCard(lang, code) {
  return `<figure class="ai-code"><figcaption><span>${esc(lang || 'code')}</span>
    <button type="button" class="ghost small ai-code-copy">Copy</button></figcaption><pre><code>${esc(code)}</code></pre></figure>`;
}

// Plain text and markdown outside code fences. "ui" blocks become component slots; other blocks become code cards.
function renderAiText(text, streaming, uiSpecs) {
  const parts = text.split('```');
  return parts.map((part, i) => {
    if (i % 2 === 1) {
      const closed = i < parts.length - 1;
      const nl = part.indexOf('\n');
      const lang = nl > -1 ? part.slice(0, nl).trim() : '';
      const code = (nl > -1 ? part.slice(nl + 1) : part).replace(/\n$/, '');
      if (lang === 'ui') {
        if (!closed || streaming) return '<div class="ai-ui-pending">Building an interactive component…</div>';
        const parsed = parseUiBlock(code);
        if (parsed.spec) {
          uiSpecs.push(parsed.spec);
          return `<div class="ai-ui-slot" data-ui="${uiSpecs.length - 1}"></div>`;
        }
        return `<div class="ai-text is-error">Component could not be shown: ${esc(parsed.error)}</div>` + codeCard('ui', code);
      }
      return codeCard(lang, code);
    }
    return part.trim() ? markdownBlocks(part) : '';
  }).join('');
}

// File blocks become progress cards while the model writes them, so raw markup never shows.
function renderAiAnswer(text, streaming) {
  const uiSpecs = [];
  let html = '';
  let last = 0;
  for (const m of text.matchAll(AI_FILE_BLOCK)) {
    html += renderAiText(text.slice(last, m.index), streaming, uiSpecs);
    const done = m[3] === '<<<END FILE>>>';
    const lines = m[2] ? m[2].split('\n').length : 0;
    const pathName = m[1].trim();
    if (done) {
      html += `<article class="ai-file-card is-done" data-msg-path="${esc(pathName)}">
        <div class="ai-file-card-top">
          <span class="ai-file-card-icon" aria-hidden="true"></span>
          <div class="ai-file-card-meta">
            <code class="ai-file-card-path">${esc(pathName)}</code>
            <span class="ai-file-card-badge">Ready · not written yet</span>
          </div>
        </div>
        <p class="ai-file-card-hint">Held as a proposal. Apply now or keep editing — nothing is saved until you confirm.</p>
        <div class="ai-file-card-actions">
          <button type="button" class="small ai-file-apply" data-apply-path="${esc(pathName)}">Apply now</button>
          <button type="button" class="ghost small ai-file-review" data-review-path="${esc(pathName)}">Review &amp; edit</button>
        </div>
      </article>`;
    } else {
      html += `<div class="ai-file-card is-writing">
        <span class="ai-file-dot" aria-hidden="true"></span>
        <span class="ai-file-name">${esc(pathName)}</span>
        <span class="chip-static">Writing… ${lines} lines</span></div>`;
    }
    last = m.index + m[0].length;
  }
  html += renderAiText(text.slice(last), streaming, uiSpecs);
  return { html, uiSpecs };
}

// ---- interactive components: the model describes them as JSON; only known types are drawn ----
const UI_MAX_CHARS = 20000;
const UI_MAX_NODES = 200;
const UI_TYPES = new Set(['card', 'row', 'stack', 'heading', 'text', 'badge', 'alert', 'icon', 'progress', 'table', 'chart', 'tabs', 'slider', 'select', 'checkbox', 'radio', 'input', 'textarea', 'date', 'button']);
function uiChildren(n) {
  const out = Array.isArray(n.children) ? n.children.slice() : [];
  if (Array.isArray(n.tabs)) for (const t of n.tabs) if (t && Array.isArray(t.children)) out.push(...t.children);
  return out;
}
function parseUiBlock(code) {
  if (code.length > UI_MAX_CHARS) return { error: 'the component is too large' };
  let spec;
  try {
    spec = JSON.parse(code);
  } catch {
    return { error: 'the JSON is not valid' };
  }
  let count = 0;
  const walk = (n, depth) => {
    if (!n || typeof n !== 'object' || typeof n.type !== 'string') return false;
    if (++count > UI_MAX_NODES || depth > 6) return false;
    for (const c of uiChildren(n)) if (!walk(c, depth + 1)) return false;
    return true;
  };
  if (!walk(spec, 0)) return { error: 'the component is too large or badly formed' };
  return { spec };
}
function uiSafeId(v) {
  return String(v || '').replace(/[^\w-]/g, '').slice(0, 40);
}
function uiSafeIcon(v) {
  const s = String(v || '').toLowerCase();
  return /^[a-z0-9-]{1,40}$/.test(s) ? s : 'circle';
}
function uiTone(v) {
  return ['ok', 'warn', 'err', 'info', 'muted', 'primary', 'ghost'].includes(v) ? v : 'muted';
}
function uiInterpolate(template, st) {
  return String(template).replace(/\{([\w-]{1,40})\}/g, (_, k) => (k in st ? String(st[k]) : ''));
}
function uiChart(spec) {
  const W = 320, H = 180, pad = 26;
  const labels = (Array.isArray(spec.labels) ? spec.labels : []).slice(0, 30).map(String);
  const values = (Array.isArray(spec.values) ? spec.values : []).slice(0, 30).map((v) => Number(v) || 0);
  const n = Math.min(labels.length, values.length);
  if (!n) return '';
  const max = Math.max(1, ...values.slice(0, n));
  const bw = (W - pad * 2) / n;
  const y = (v) => H - pad - (v / max) * (H - pad * 2);
  let body;
  if (spec.kind === 'line') {
    const pts = values.slice(0, n).map((v, i) => `${pad + bw * i + bw / 2},${y(v)}`).join(' ');
    body = `<polyline class="ai-ui-line" points="${pts}"></polyline>`
      + values.slice(0, n).map((v, i) => `<circle cx="${pad + bw * i + bw / 2}" cy="${y(v)}" r="3.5"></circle>`).join('');
  } else {
    body = values.slice(0, n).map((v, i) => `<rect class="ai-ui-bar" x="${pad + bw * i + bw * 0.18}" y="${y(v)}" width="${bw * 0.64}" height="${H - pad - y(v)}" rx="4" style="animation-delay:${i * 60}ms"></rect>`).join('');
  }
  const axis = labels.slice(0, n).map((l, i) => `<text x="${pad + bw * i + bw / 2}" y="${H - 6}" text-anchor="middle">${esc(l)}</text>`).join('');
  return `<svg class="ai-ui-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(spec.title || 'Chart')}">${body}${axis}</svg>`;
}

// Builds one component. st holds the live values of the controls, so they survive re-renders.
function buildUi(spec, st, onPrompt, depth = 0) {
  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  if (!spec || typeof spec !== 'object' || depth > 6 || !UI_TYPES.has(spec.type)) return el('span');
  const kids = (list) => (Array.isArray(list) ? list : []).map((c) => buildUi(c, st, onPrompt, depth + 1));
  const field = (id, label, control) => {
    const wrap = el('label', 'ai-ui-field');
    if (label) wrap.appendChild(el('span', 'ai-ui-label', String(label)));
    wrap.appendChild(control);
    return wrap;
  };
  const key = uiSafeId(spec.id) || 'value';
  switch (spec.type) {
    case 'card': {
      const box = el('section', 'ai-ui-card');
      if (spec.title) box.appendChild(el('h4', 'ai-ui-title', String(spec.title)));
      kids(spec.children).forEach((k) => box.appendChild(k));
      return box;
    }
    case 'row':
    case 'stack': {
      const box = el('div', spec.type === 'row' ? 'ai-ui-row' : 'ai-ui-stack');
      kids(spec.children).forEach((k) => box.appendChild(k));
      return box;
    }
    case 'heading': return el('h4', 'ai-ui-heading', String(spec.text || ''));
    case 'text': {
      const box = el('div', 'ai-ui-text');
      box.innerHTML = markdownBlocks(String(spec.text || ''));
      return box;
    }
    case 'badge': return el('span', `ai-ui-badge tone-${uiTone(spec.tone)}`, String(spec.text || ''));
    case 'alert': return el('div', `ai-ui-alert tone-${uiTone(spec.tone)}`, String(spec.text || ''));
    case 'icon': {
      const i = el('span', 'ai-ui-icon');
      i.innerHTML = icon(uiSafeIcon(spec.name));
      return i;
    }
    case 'progress': {
      const max = Number(spec.max) > 0 ? Number(spec.max) : 100;
      const value = Math.min(Math.max(Number(spec.value) || 0, 0), max);
      const box = el('div', 'ai-ui-progress');
      if (spec.label) box.appendChild(el('span', 'ai-ui-label', String(spec.label)));
      const bar = el('div', 'ai-ui-bar-track');
      const fill = el('div', 'ai-ui-bar-fill');
      fill.style.width = (value / max * 100).toFixed(1) + '%';
      bar.appendChild(fill);
      box.appendChild(bar);
      return box;
    }
    case 'table': {
      const cols = Array.isArray(spec.columns) ? spec.columns.map(String) : [];
      const rows = Array.isArray(spec.rows) ? spec.rows.slice(0, 200) : [];
      const table = el('table', 'ai-ui-table');
      const thead = el('thead');
      const hr = el('tr');
      cols.forEach((c) => hr.appendChild(el('th', '', c)));
      thead.appendChild(hr);
      table.appendChild(thead);
      const tbody = el('tbody');
      for (const r of rows) {
        const tr = el('tr');
        (Array.isArray(r) ? r : []).forEach((cell) => tr.appendChild(el('td', '', String(cell ?? ''))));
        tbody.appendChild(tr);
      }
      table.appendChild(tbody);
      const wrap = el('div', 'ai-table-wrap');
      wrap.appendChild(table);
      return wrap;
    }
    case 'chart': {
      const box = el('div', 'ai-ui-chartbox');
      if (spec.title) box.appendChild(el('div', 'ai-ui-label', String(spec.title)));
      box.innerHTML += uiChart(spec);
      return box;
    }
    case 'tabs': {
      const box = el('div', 'ai-ui-tabs');
      const bar = el('div', 'ai-ui-tabbar');
      const panel = el('div', 'ai-ui-panel');
      const tabs = Array.isArray(spec.tabs) ? spec.tabs : [];
      if (typeof st.tab !== 'number') st.tab = 0;
      const show = () => {
        [...bar.children].forEach((b, i) => b.classList.toggle('is-on', i === st.tab));
        panel.innerHTML = '';
        const current = tabs[st.tab];
        (current && Array.isArray(current.children) ? current.children : []).forEach((c) => panel.appendChild(buildUi(c, st, onPrompt, depth + 1)));
      };
      tabs.forEach((t, i) => {
        const b = el('button', 'ghost small ai-ui-tab', String(t?.label || 'Tab'));
        b.type = 'button';
        b.addEventListener('click', () => { st.tab = i; show(); });
        bar.appendChild(b);
      });
      box.appendChild(bar);
      box.appendChild(panel);
      show();
      return box;
    }
    case 'slider': {
      const min = Number(spec.min ?? 0), max = Number(spec.max ?? 100), step = Number(spec.step) > 0 ? Number(spec.step) : 1;
      if (st[key] === undefined) st[key] = Number(spec.value ?? min);
      const out = el('output', 'ai-ui-out', String(st[key]));
      const input = el('input', 'ai-ui-range');
      input.type = 'range';
      input.min = String(min); input.max = String(max); input.step = String(step); input.value = String(st[key]);
      input.addEventListener('input', () => { st[key] = Number(input.value); out.textContent = input.value; });
      const wrap = el('label', 'ai-ui-field');
      const top = el('div', 'ai-ui-field-top');
      top.appendChild(el('span', 'ai-ui-label', String(spec.label || '')));
      top.appendChild(out);
      wrap.appendChild(top);
      wrap.appendChild(input);
      return wrap;
    }
    case 'select': {
      if (st[key] === undefined) st[key] = String(spec.value ?? (Array.isArray(spec.options) ? spec.options[0] : ''));
      const sel = el('select', 'ai-ui-input');
      (Array.isArray(spec.options) ? spec.options : []).slice(0, 50).forEach((o) => {
        const opt = el('option', '', String(o));
        opt.value = String(o);
        if (String(o) === String(st[key])) opt.selected = true;
        sel.appendChild(opt);
      });
      sel.addEventListener('change', () => { st[key] = sel.value; });
      return field(key, spec.label, sel);
    }
    case 'checkbox': {
      if (st[key] === undefined) st[key] = Boolean(spec.value);
      const cb = el('input', 'ai-ui-check');
      cb.type = 'checkbox';
      cb.checked = Boolean(st[key]);
      cb.addEventListener('change', () => { st[key] = cb.checked; });
      const wrap = el('label', 'ai-ui-check-row');
      wrap.appendChild(cb);
      wrap.appendChild(el('span', '', String(spec.label || '')));
      return wrap;
    }
    case 'radio': {
      if (st[key] === undefined) st[key] = String(spec.value ?? '');
      const group = el('div', 'ai-ui-radios');
      group.setAttribute('role', 'radiogroup');
      const name = 'ai-r-' + key + '-' + Math.random().toString(36).slice(2, 8);
      (Array.isArray(spec.options) ? spec.options : []).slice(0, 50).forEach((o) => {
        const row = el('label', 'ai-ui-check-row');
        const r = el('input', 'ai-ui-check');
        r.type = 'radio'; r.name = name; r.value = String(o);
        r.checked = String(o) === String(st[key]);
        r.addEventListener('change', () => { if (r.checked) st[key] = r.value; });
        row.appendChild(r);
        row.appendChild(el('span', '', String(o)));
        group.appendChild(row);
      });
      return field(key, spec.label, group);
    }
    case 'input':
    case 'textarea':
    case 'date': {
      if (st[key] === undefined) st[key] = String(spec.value ?? '');
      const ctrl = spec.type === 'textarea' ? el('textarea', 'ai-ui-input') : el('input', 'ai-ui-input');
      if (spec.type === 'date') ctrl.type = 'date';
      if (spec.placeholder) ctrl.placeholder = String(spec.placeholder).slice(0, 120);
      ctrl.value = String(st[key]);
      ctrl.addEventListener('input', () => { st[key] = ctrl.value; });
      return field(key, spec.label, ctrl);
    }
    case 'button': {
      const b = el('button', spec.tone === 'ghost' ? 'ghost small ai-ui-btn' : 'small ai-ui-btn', String(spec.label || 'Button'));
      b.type = 'button';
      b.addEventListener('click', () => {
        if (typeof spec.prompt === 'string') {
          onPrompt(uiInterpolate(spec.prompt, st));
        } else if (typeof spec.copy === 'string') {
          navigator.clipboard.writeText(uiInterpolate(spec.copy, st)).then(() => toast('Copied', 'ok'));
        }
      });
      return b;
    }
    default: return el('span');
  }
}

// Folder tree of the Dominant files, for the attach sheet.
function folderTreeHtml(node, picks, depth) {
  const folders = Object.keys(node.folders).sort().map((name) => `
    <details class="ai-tree-folder" open>
      <summary style="padding-left:${8 + depth * 14}px">${esc(name)}</summary>
      ${folderTreeHtml(node.folders[name], picks, depth + 1)}
    </details>`).join('');
  const files = node.files.slice().sort().map((p) => `
    <label class="ai-tree-file" style="padding-left:${26 + depth * 14}px">
      <input type="checkbox" data-pick="${esc(p)}" ${picks.has(p) ? 'checked' : ''}>
      <span>${esc(p.split('/').pop())}</span>
    </label>`).join('');
  return folders + files;
}

async function streamAi(body, signal, onEvent, path = 'api/ai/stream') {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'RegexManager', Accept: 'text/event-stream' },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let end;
    while ((end = buffer.indexOf('\n\n')) !== -1) {
      const block = buffer.slice(0, end);
      buffer = buffer.slice(end + 2);
      const event = /^event: (.+)$/m.exec(block)?.[1];
      const data = /^data: (.+)$/m.exec(block)?.[1];
      if (event && data) onEvent(event, JSON.parse(data));
    }
  }
}

function summaryStepsFor(msg, fileCount, changeCount) {
  const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
  const steps = [];
  if (fileCount) steps.push(`Read ${plural(fileCount, 'attached file')}`);
  if (msg.searchNote === 'unavailable') steps.push('Web search unavailable');
  else if (typeof msg.searchNote === 'number') steps.push(`Searched the web (${msg.searchNote} result${msg.searchNote === 1 ? '' : 's'})`);
  if (msg.secs !== null) steps.push(`Thought for ${msg.secs} seconds`);
  if (changeCount) steps.push(`Proposed changes to ${plural(changeCount, 'file')}`);
  steps.push(msg.error ? 'Stopped with an error' : 'Answered');
  return steps;
}

async function renderProviders() {
  const view = $('#view');
  const state = {
    messages: [], files: [], changes: [], selected: new Set(), current: null,
    controller: null, stopped: false, picks: new Set(), tree: null, search: false,
    agentMode: false,
    lead: 0,
    agents: [
      { name: 'Analyst', model: AI_MODEL_DEFAULT, role: '', enabled: true },
      { name: 'Critic', model: AI_MODEL_DEFAULT, role: 'Challenge weak points and missing cases', enabled: true },
    ],
  };
  let frame = 0;

  view.innerHTML = `
    <div class="ai-shell">
      <header class="ai-head">
        <div class="ai-head-main">
          <img class="ai-logo-img" src="assets/xkiro.png" alt="xKiro" width="36" height="36">
          <div class="ai-head-copy">
            <h3>Assistant</h3>
            <p>Reads files, proposes edits — writes nothing until you apply.</p>
          </div>
        </div>
        <div class="ai-head-side">
          <span class="ai-pill" id="ai-pill" role="status">Ready</span>
          <div class="ai-model-wrap">
            <input id="ai-model" type="text" spellcheck="false" aria-label="Model" value="${esc(AI_MODEL_DEFAULT)}">
          </div>
          <button type="button" class="ai-icon-btn" id="ai-clear" title="Clear chat" aria-label="Clear chat">${icon('trash', 'sm')}</button>
        </div>
      </header>

      <section class="ai-thread" id="ai-thread" aria-live="polite"></section>

      <section class="ai-changes card" id="ai-changes" hidden></section>

      <div class="ai-composer-wrap">
        <div class="ai-agents-dock" id="ai-agents" hidden>
          <div class="ai-agents-dock-head">
            <label class="ai-switch">
              <input type="checkbox" id="ai-agents-toggle" checked>
              <span class="ai-switch-ui" aria-hidden="true"></span>
              <span class="ai-switch-text"><strong>Agents</strong> <span id="ai-agents-state">On</span></span>
            </label>
            <span class="chip-static" id="ai-agents-count">2 / 5</span>
            <button type="button" class="ai-icon-btn" id="ai-agents-close" aria-label="Hide agents panel" title="Hide">${icon('x', 'sm')}</button>
          </div>
          <p class="ai-agents-hint muted2 fs09">Only enabled agents run. Turn the switch off to chat with a single model.</p>
          <div class="ai-agents-list" id="ai-agents-list"></div>
          <div class="ai-agents-foot">
            <button type="button" class="ghost small" id="ai-agents-add">${icon('plus', 'sm')} Add</button>
            <label class="ai-rounds">Lead
              <select id="ai-agents-lead" aria-label="Agent that writes the conclusion"></select>
            </label>
            <label class="ai-rounds">Rounds
              <select id="ai-agents-rounds" aria-label="Rounds">
                <option value="1">1</option><option value="2" selected>2</option><option value="3">3</option>
              </select>
            </label>
          </div>
        </div>
        <div class="ai-slash" id="ai-slash" hidden role="listbox" aria-label="Shortcuts"></div>
        <div class="ai-sheet" id="ai-sheet" hidden>
          <div class="ai-sheet-head">
            <strong>Attach from Dominant</strong>
            <button type="button" class="ghost small" id="ai-sheet-close" aria-label="Close">Close</button>
          </div>
          <input class="ai-sheet-search" id="ai-sheet-search" type="search" placeholder="Filter files" aria-label="Filter files">
          <div class="ai-sheet-tree" id="ai-sheet-tree"></div>
          <div class="ai-sheet-foot">
            <span class="muted2 fs09" id="ai-sheet-count">0 selected</span>
            <button type="button" class="small" id="ai-sheet-attach" disabled>Attach</button>
          </div>
        </div>

        <form class="ai-composer" id="ai-composer">
          <div class="ai-chips" id="ai-chips" hidden></div>
          <textarea id="ai-input" rows="1" maxlength="16000" aria-label="Message" placeholder="Ask anything about Dominant files…"></textarea>
          <div class="ai-composer-bar">
            <div class="ai-composer-tools">
              <button type="button" class="ai-tool" id="ai-plus" aria-label="Attach files" aria-expanded="false" title="Attach">${icon('plus')}</button>
              <button type="button" class="ai-tool ai-agents-btn" id="ai-agents-btn" aria-pressed="false" aria-label="Agents" title="Agents on/off panel">${icon('users')}</button>
              <span class="ai-mode-chip" id="ai-mode-chip" hidden>Agents on</span>
              <button type="button" class="ai-tool" id="ai-search" aria-pressed="false" aria-label="Web search" title="Web search">${icon('globe')}</button>
            </div>
            <div class="ai-composer-actions">
              <button type="button" class="ai-tool ai-stop" id="ai-stop" hidden aria-label="Stop">${icon('square')}</button>
              <button type="submit" class="ai-send" id="ai-send" aria-label="Send" disabled>
                <span class="ai-send-label">Send</span>
                ${icon('arrow-up')}
              </button>
            </div>
          </div>
          <div class="ai-composer-meta">
            <span class="muted2 fs09">Ctrl+Enter to send · / for shortcuts</span>
          </div>
        </form>
      </div>
    </div>`;

  const thread = view.querySelector('#ai-thread');
  const chips = view.querySelector('#ai-chips');
  const changesBox = view.querySelector('#ai-changes');
  const input = view.querySelector('#ai-input');
  const send = view.querySelector('#ai-send');
  const stop = view.querySelector('#ai-stop');
  const plus = view.querySelector('#ai-plus');
  const pill = view.querySelector('#ai-pill');
  const sheet = view.querySelector('#ai-sheet');
  const treeEl = view.querySelector('#ai-sheet-tree');
  const search = view.querySelector('#ai-sheet-search');
  const countEl = view.querySelector('#ai-sheet-count');
  const attachBtn = view.querySelector('#ai-sheet-attach');

  const emptyHtml = `
    <div class="ai-empty">
      <img class="ai-empty-logo" src="assets/xkiro.png" alt="" width="72" height="72">
      <h4>What should we work on?</h4>
      <p class="muted fs09">Attach the files the assistant needs with the + button, then ask.</p>
      <div class="ai-suggest">${AI_PROMPTS.map((p) => `<button type="button" class="ghost small" data-prompt="${esc(p)}">${esc(p)}</button>`).join('')}</div>
    </div>`;

  function setPill(label, kind) {
    pill.textContent = label;
    pill.className = 'ai-pill' + (kind ? ' is-' + kind : '');
  }
  function setText(el, value) {
    if (el.textContent !== value) el.textContent = value;
  }

  // Each message keeps its own DOM row, so streaming only touches the text that changed.
  function createRow(m) {
    const row = document.createElement('div');
    row._msg = m;
    if (m.role === 'user') {
      row.className = 'ai-row ai-row-user';
      row.innerHTML = '<div class="ai-bubble ai-bubble-user"><div class="ai-msg-text"></div></div>';
    } else {
      row.className = 'ai-row ai-row-assistant';
      row.innerHTML = `
        <img class="ai-avatar-img" src="assets/xkiro.png" alt="" width="30" height="30">
        <div class="ai-bubble ai-bubble-assistant">
          <div class="ai-agent-tag" hidden></div>
          <div class="ai-think" hidden>
            <button type="button" class="ai-think-head" aria-expanded="false">
              <span class="ai-think-ico" aria-hidden="true"></span>
              <span class="ai-think-label">Thinking</span>
              <span class="ai-think-chev" aria-hidden="true"></span>
            </button>
            <div class="ai-think-panel" hidden>
              <div class="ai-think-panel-title">Thoughts</div>
              <div class="ai-think-body"></div>
            </div>
          </div>
          <div class="ai-waiting" hidden>
            <div class="ai-orb-stage" data-mode="single" aria-label="Generating">
              <span class="ai-orb ai-orb-solo"></span>
              <span class="ai-orb ai-orb-a"></span>
              <span class="ai-orb ai-orb-b"></span>
              <span class="ai-orb ai-orb-c"></span>
            </div>
            <span class="ai-waiting-label">Generating…</span>
          </div>
          <div class="ai-body"></div>
          <div class="ai-file-cards" hidden></div>
          <span class="ai-cursor" aria-hidden="true"></span>
          <div class="ai-sources" hidden></div>
          <div class="ai-foot">
            <details class="ai-summary"><summary>Summary</summary><ol></ol></details>
            <button type="button" class="ghost small ai-copy">Copy</button>
          </div>
        </div>`;
    }
    m.node = row;
    updateRow(m);
    return row;
  }

  function mountUi(body, m, specs) {
    m.uiState = m.uiState || {};
    body.querySelectorAll('.ai-ui-slot').forEach((slot) => {
      const idx = Number(slot.dataset.ui);
      if (!specs[idx]) return;
      m.uiState[idx] = m.uiState[idx] || {};
      slot.appendChild(buildUi(specs[idx], m.uiState[idx], (text) => sendMessage(text)));
    });
  }


  function updateRow(m) {
    const row = m.node;
    if (m.role === 'user') {
      setText(row.querySelector('.ai-msg-text'), m.text);
      return;
    }
    const tag = row.querySelector('.ai-agent-tag');
    tag.hidden = !m.agent;
    if (m.agent) {
      setText(tag, m.agent + (m.round === 'final' ? ' · conclusion' : m.round ? ' · round ' + m.round : ''));
      tag.className = 'ai-agent-tag c' + ((m.color || 0) % 5);
    }

    const think = row.querySelector('.ai-think');
    const hasThought = Boolean(m.thinking && String(m.thinking).trim());
    const hasAnswer = Boolean(m.text && String(m.text).trim()) || (m.tAnswer != null);
    // Live while streaming (duration keeps ticking); stays after if there is reasoning
    const liveThinking = Boolean(m.streaming);
    const showThink = liveThinking || hasThought || (m.secs != null && m.streaming === false && hasThought);
    // Always show a compact status while the model is working, even before reasoning arrives
    think.hidden = !(m.streaming || hasThought);

    if (m.thinkOpen === undefined) m.thinkOpen = false;
    if (!m.streaming && hasThought && !m.thinkClosed) {
      m.thinkOpen = false;
      m.thinkClosed = true;
    }

    const head = row.querySelector('.ai-think-head');
    const panel = row.querySelector('.ai-think-panel');
    const open = Boolean(m.thinkOpen) && hasThought;
    head.setAttribute('aria-expanded', String(open));
    head.classList.toggle('is-open', open);
    head.classList.toggle('is-live', liveThinking);
    head.classList.toggle('is-done', !liveThinking && hasThought);
    think.classList.toggle('is-expanded', open);
    if (panel) panel.hidden = !open;

    const thinkBody = row.querySelector('.ai-think-body');
    setText(thinkBody, m.thinking || '');

    // Live duration from tStart
    let liveSec = m.secs;
    if (m.streaming && m.tStart != null) {
      liveSec = Math.max(1, Math.round((performance.now() - m.tStart) / 1000));
    }
    const dur = formatThinkSecs(liveSec != null ? liveSec : 0);
    let label;
    if (liveThinking) {
      label = 'Thinking for ' + dur;
    } else if (hasThought) {
      label = 'Thought for ' + formatThinkSecs(m.secs != null ? m.secs : liveSec || 1);
    } else {
      label = 'Thought';
    }
    if (m.agent && !liveThinking) label = m.agent + ' · ' + label;
    setText(row.querySelector('.ai-think-label'), label);

    const waiting = row.querySelector('.ai-waiting');
    const showWait = Boolean(m.streaming && !m.text && !m.thinking);
    waiting.hidden = !showWait;
    if (showWait) {
      const stage = waiting.querySelector('.ai-orb-stage');
      const multi = Boolean(m.agent || m.agentMode || state.agentMode);
      stage.dataset.mode = multi ? 'multi' : 'single';
      setText(waiting.querySelector('.ai-waiting-label'), multi
        ? (m.agent ? (m.agent + ' is working…') : 'Agents discussing…')
        : 'Generating…');
    }
    const answer = row.querySelector('.ai-body');
    if (m.error) {
      if (m._html !== 'error') {
        answer.innerHTML = '<div class="ai-text is-error"></div>';
        answer.firstChild.textContent = m.text;
        m._html = 'error';
      }
    } else {
      const rendered = renderAiAnswer(m.text || '', m.streaming);
      if (m._html !== rendered.html) {
        answer.innerHTML = rendered.html;
        m._html = rendered.html;
        mountUi(answer, m, rendered.uiSpecs);
      }
    }
    row.querySelector('.ai-cursor').hidden = !(m.streaming && m.text);

    const sources = m.sources || [];
    const srcBox = row.querySelector('.ai-sources');
    const srcKey = sources.map((s) => s.url).join('|');
    if (srcBox._key !== srcKey) {
      srcBox._key = srcKey;
      srcBox.innerHTML = sources.length
        ? '<span class="ai-sources-label">Sources</span><ol>' + sources.map((s) =>
          `<li><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title || s.url)}</a></li>`).join('') + '</ol>'
        : '';
    }
    srcBox.hidden = !sources.length;

    const showSteps = !m.streaming && m.steps && m.steps.length > 0;
    const summaryEl = row.querySelector('.ai-summary');
    const foot = row.querySelector('.ai-foot');
    const bubble = think.parentNode;
    if (showSteps) {
      // Finished: the summary takes the thinking block's place at the top of the reply.
      if (summaryEl.parentNode !== bubble || summaryEl.previousElementSibling !== think) {
        bubble.insertBefore(summaryEl, think.nextSibling);
      }
      summaryEl.classList.add('ai-summary--top');
      if (!summaryEl.dataset.opened) {
        summaryEl.open = true;
        summaryEl.dataset.opened = '1';
      }
      think.hidden = true;
    } else {
      // Still working (or no steps): the summary waits in the footer, out of the way.
      summaryEl.classList.remove('ai-summary--top');
      if (summaryEl.parentNode !== foot) foot.insertBefore(summaryEl, foot.querySelector('.ai-copy'));
    }
    summaryEl.hidden = !showSteps;
    if (showSteps) {
      const ol = row.querySelector('.ai-summary ol');
      const key = m.steps.join('|');
      if (ol._key !== key) {
        ol.innerHTML = m.steps.map((s) => `<li>${esc(s)}</li>`).join('');
        ol._key = key;
      }
    }
    row.querySelector('.ai-copy').hidden = !(!m.streaming && m.text && !m.error);
  }

  function renderThread() {
    if (!state.messages.length) {
      thread.innerHTML = emptyHtml;
      return;
    }
    if (thread.querySelector('.ai-empty')) thread.innerHTML = '';
    const nearBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 90;
    for (const m of state.messages) {
      if (!m.node) thread.appendChild(createRow(m));
      else updateRow(m);
    }
    if (nearBottom) thread.scrollTop = thread.scrollHeight;
  }

  function scheduleRender() {
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      renderThread();
    });
  }

  function renderChips() {
    chips.innerHTML = state.files.map((p, i) =>
      `<span class="ai-chip"><span class="ai-file-dot-sm" aria-hidden="true"></span>${esc(p)}<button type="button" data-rm="${i}" aria-label="Remove ${esc(p)}">×</button></span>`).join('');
    chips.hidden = !state.files.length;
  }

  function renderChanges() {
    if (!state.changes.length) {
      changesBox.hidden = true;
      changesBox.innerHTML = '';
      return;
    }
    changesBox.hidden = false;
    const cur = state.current;
    const open = cur !== null ? state.changes[cur] : null;
    changesBox.innerHTML = `
      <div class="card-head"><h3>${icon('check')} Pending file changes</h3><span class="chip-static">${state.changes.length} held · not written yet</span></div>
      <p class="muted fs09 ai-pending-note">These files stay queued until you apply them. You can keep chatting and come back later.</p>
      <ul class="ai-file-list">
        ${state.changes.map((c, i) => {
          const d = diffCount(c.original, c.edited ?? c.proposed);
          return `<li class="${i === cur ? 'is-open' : ''}">
            <input type="checkbox" data-sel="${i}" aria-label="Apply ${esc(c.path)}" ${state.selected.has(i) ? 'checked' : ''}>
            <button type="button" class="ghost small ai-file-open" data-open="${i}">${esc(c.path)}</button>
            <span class="chip-static">${c.isNew ? 'New' : 'Modified'} · +${d.added} −${d.removed}</span>
          </li>`;
        }).join('')}
      </ul>
      ${open ? `<div class="ai-panes">
          <div class="ai-pane"><label>Current file</label><textarea readonly rows="14">${esc(open.original)}</textarea></div>
          <div class="ai-pane"><label>Proposed (you can edit it)</label><textarea id="ai-edit" rows="14" spellcheck="false">${esc(open.edited ?? open.proposed)}</textarea></div>
        </div>` : '<p class="muted fs09">Open a file to review it.</p>'}
      <div class="row-actions">
        <button type="button" class="ghost small" id="ai-discard">Discard all</button>
        <button type="button" class="small" id="ai-apply" ${state.selected.size ? '' : 'disabled'}>${icon('check', 'sm')} Apply selected (${state.selected.size})</button>
      </div>
      <p class="muted fs09 ai-status" id="ai-result" aria-live="polite"></p>`;
    const edit = changesBox.querySelector('#ai-edit');
    if (edit) edit.addEventListener('input', () => { open.edited = edit.value; });
  }

  function syncComposer() {
    const busy = Boolean(state.controller);
    send.disabled = busy || !input.value.trim();
    stop.hidden = !busy;
    plus.disabled = busy;
  }

  async function sendMessage(explicitText) {
    const text = (typeof explicitText === 'string' ? explicitText : input.value).trim();
    if (!text || state.controller) return;
    if (state.agentMode) {
      sendDiscussion(text);
      return;
    }
    const attached = state.files.slice();
    state.messages.push({ role: 'user', text });
    if (typeof explicitText !== 'string') {
      input.value = '';
      input.style.height = '';
    }
    const msg = {
      role: 'assistant', text: '', thinking: '', streaming: true, error: false, steps: [],
      tThink: null, tAnswer: null, secs: null, tStart: performance.now(),
    };
    state.messages.push(msg);
    state.controller = new AbortController();
    state.stopped = false;
    syncComposer();
    setPill('Thinking', 'busy');
    startTimer();
    scheduleRender();
    try {
      const history = state.messages.slice(0, -1).filter((m) => !m.error).map((m) => ({ role: m.role, content: m.text }));
      await streamAi({
        model: view.querySelector('#ai-model').value.trim(),
        messages: history,
        files: attached,
        search: state.search,
      }, state.controller.signal, (event, data) => {
        const now = performance.now();
        if (event === 'reasoning') {
          msg.thinking += data.text;
          if (msg.tThink === null) msg.tThink = now;
        } else if (event === 'content') {
          if (msg.tThink !== null && msg.tAnswer === null) msg.tAnswer = now;
          msg.text += data.text;
          setPill(/<<<FILE /.test(msg.text) ? 'Writing files' : 'Answering', 'busy');
        } else if (event === 'done') {
          msg.text = data.reply || msg.text || 'The model returned file changes only.';
          const incoming = data.changes || [];
          // Merge into global pending queue (never auto-write)
          for (const c of incoming) {
            const i = state.changes.findIndex((x) => x.path === c.path);
            if (i >= 0) state.changes[i] = { ...state.changes[i], ...c };
            else state.changes.push(c);
          }
          msg.fileChanges = incoming.length ? incoming : extractFileProposals(msg.text);
          // If model only returned FILE blocks, still register them pending
          if (!incoming.length && msg.fileChanges.length) {
            for (const c of msg.fileChanges) {
              if (!state.changes.some((x) => x.path === c.path)) state.changes.push(c);
            }
          }
          msg.sources = data.sources || [];
          msg.searchNote = data.searchNote ?? null;
          state.selected = new Set(state.changes.map((_, i) => i));
          state.current = state.changes.length ? 0 : null;
        } else if (event === 'error') {
          msg.error = true;
          msg.text = data.message;
        }
        scheduleRender();
      });
      setPill(msg.error ? 'Error' : 'Done', msg.error ? 'error' : 'ok');
    } catch (err) {
      if (state.stopped) {
        msg.text = msg.text || 'Stopped.';
        setPill('Stopped');
      } else {
        msg.error = true;
        msg.text = err.message;
        setPill('Error', 'error');
      }
    } finally {
      {
        const start = msg.tThink != null ? msg.tThink : msg.tStart;
        const end = msg.tAnswer != null ? msg.tAnswer : performance.now();
        if (start != null) msg.secs = Math.max(1, Math.round((end - start) / 1000));
      }
      msg.streaming = false;
      msg.thinkClosed = false; // allow collapse rule to run once on next paint
      if (msg.thinking && String(msg.thinking).trim()) {
        msg.thinkOpen = false;
        msg.thinkClosed = true;
      }
      msg.steps = summaryStepsFor(msg, attached.length, state.changes.length);
      state.controller = null;
      syncComposer();
      renderThread();
      renderChanges();
    }
  }

  // Attach sheet: the same folder tree as the Dominant tab, opened from the + button.
  function setSheet(open) {
    sheet.hidden = !open;
    plus.setAttribute('aria-expanded', String(open));
    if (!open) state.picks.clear();
    else loadTree();
  }
  function syncSheet() {
    countEl.textContent = `${state.picks.size} selected`;
    attachBtn.disabled = state.picks.size === 0;
  }
  function renderTree() {
    const openFolders = new Set([...treeEl.querySelectorAll('.tree-folder.open')].map((f) => f.dataset.path));
    const scroll = treeEl.scrollTop;
    const q = search.value.trim().toLowerCase();
    const list = (state.tree || []).filter((f) => !q || f.path.toLowerCase().includes(q));
    const saved = domSel;
    domSel = { files: state.picks, folders: new Set() };
    try {
      treeEl.innerHTML = list.length
        ? treeHtml(buildTree(list), '', 0, Boolean(q))
        : '<p class="muted fs09 ai-tree-empty">No files match.</p>';
    } finally {
      domSel = saved;
    }
    if (!q && openFolders.size) {
      treeEl.querySelectorAll('.tree-folder').forEach((f) => f.classList.toggle('open', openFolders.has(f.dataset.path)));
    }
    treeEl.scrollTop = scroll;
    syncSheet();
  }
  async function loadTree() {
    treeEl.innerHTML = '<p class="muted fs09 ai-tree-empty">Loading files…</p>';
    try {
      const data = await api('api/dominant/files');
      state.tree = (data.files || [])
        .filter((f) => f.binary !== true)
        .map((f) => ({ path: f.path, size: f.size || 0 }));
      renderTree();
    } catch (err) {
      treeEl.innerHTML = `<p class="err-text fs09">${esc(err.message)}</p>`;
    }
  }

  plus.addEventListener('click', () => setSheet(sheet.hidden));
  view.querySelector('#ai-sheet-close').addEventListener('click', () => setSheet(false));
  search.addEventListener('input', renderTree);
  treeEl.addEventListener('change', (e) => {
    const t = e.target;
    if (t.dataset.selFile !== undefined) {
      if (t.checked) state.picks.add(t.dataset.selFile); else state.picks.delete(t.dataset.selFile);
    } else if (t.dataset.selFolder !== undefined) {
      const prefix = t.dataset.selFolder + '/';
      for (const f of state.tree || []) {
        if (f.path.startsWith(prefix)) {
          if (t.checked) state.picks.add(f.path); else state.picks.delete(f.path);
        }
      }
    } else {
      return;
    }
    renderTree();
  });
  treeEl.addEventListener('click', (e) => {
    if (e.target.closest('.tree-check')) return;
    const folderRow = e.target.closest('.tree-folder > .tree-row');
    if (folderRow) {
      const box = folderRow.parentElement;
      box.classList.toggle('open');
      folderRow.setAttribute('aria-expanded', String(box.classList.contains('open')));
      return;
    }
    const fileRow = e.target.closest('.tree-row.file');
    if (fileRow) {
      const box = fileRow.querySelector('input');
      if (box) {
        box.checked = !box.checked;
        box.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
  });
  attachBtn.addEventListener('click', () => {
    let added = 0;
    for (const p of state.picks) {
      if (!state.files.includes(p) && state.files.length < 20) {
        state.files.push(p);
        added++;
      }
    }
    setSheet(false);
    renderChips();
    if (added) toast(`${added} file${added > 1 ? 's' : ''} attached`, 'ok');
  });
  chips.addEventListener('click', (e) => {
    const rm = e.target.closest('[data-rm]');
    if (!rm) return;
    state.files.splice(Number(rm.dataset.rm), 1);
    renderChips();
  });
  view.querySelector('#ai-search').addEventListener('click', (e) => {
    state.search = !state.search;
    e.currentTarget.setAttribute('aria-pressed', String(state.search));
    e.currentTarget.classList.toggle('is-on', state.search);
  });

  // Agents docked to the composer: switch on/off + per-agent enable.
  const agentsBtn = view.querySelector('#ai-agents-btn');
  const agentsPanel = view.querySelector('#ai-agents');
  const agentsToggle = view.querySelector('#ai-agents-toggle');
  const modeChip = view.querySelector('#ai-mode-chip');

  function syncAgentModeUi() {
    agentsBtn.setAttribute('aria-pressed', String(state.agentMode));
    agentsBtn.classList.toggle('is-on', state.agentMode);
    agentsPanel.hidden = !state.agentMode;
    agentsToggle.checked = state.agentMode;
    const st = view.querySelector('#ai-agents-state');
    if (st) st.textContent = state.agentMode ? 'On' : 'Off';
    modeChip.hidden = !state.agentMode;
    modeChip.textContent = state.agentMode
      ? `Agents · ${state.agents.filter((a) => a.enabled !== false).length}`
      : '';
  }

  function openAgentsPanel(on) {
    state.agentMode = on;
    syncAgentModeUi();
    if (on) renderAgentList();
  }

  agentsBtn.addEventListener('click', () => {
    // First click turns on + opens; if already on, toggles panel visibility only
    if (!state.agentMode) {
      openAgentsPanel(true);
      return;
    }
    agentsPanel.hidden = !agentsPanel.hidden;
  });
  agentsToggle.addEventListener('change', () => {
    openAgentsPanel(agentsToggle.checked);
  });
  view.querySelector('#ai-agents-close').addEventListener('click', () => {
    agentsPanel.hidden = true;
  });

  function renderAgentList() {
    const list = view.querySelector('#ai-agents-list');
    list.innerHTML = state.agents.map((a, i) => `
      <div class="ai-agent-row${a.enabled === false ? ' is-off' : ''}" data-agent="${i}">
        <label class="ai-agent-enable" title="Enable agent">
          <input type="checkbox" data-field="enabled" ${a.enabled === false ? '' : 'checked'} aria-label="Enable ${esc(a.name)}">
        </label>
        <span class="ai-agent-dot c${i % 5}" aria-hidden="true"></span>
        <input type="text" data-field="name" value="${esc(a.name)}" maxlength="30" aria-label="Agent name">
        <input type="text" data-field="model" value="${esc(a.model)}" maxlength="80" aria-label="Model">
        <input type="text" data-field="role" value="${esc(a.role || '')}" maxlength="200" placeholder="Role (optional)" aria-label="Role">
        <button type="button" class="ghost small ai-agent-remove" data-remove="${i}" aria-label="Remove agent" ${state.agents.length <= 1 ? 'disabled' : ''}>${icon('x', 'sm')}</button>
      </div>`).join('');
    const active = state.agents.filter((a) => a.enabled !== false).length;
    view.querySelector('#ai-agents-count').textContent = `${active} on · ${state.agents.length}/5`;
    view.querySelector('#ai-agents-add').disabled = state.agents.length >= 5;
    if (state.lead >= state.agents.length) state.lead = 0;
    const enabledIdx = state.agents.map((a, i) => (a.enabled === false ? -1 : i)).filter((i) => i >= 0);
    if (enabledIdx.length && !enabledIdx.includes(state.lead)) state.lead = enabledIdx[0];
    view.querySelector('#ai-agents-lead').innerHTML = state.agents
      .map((a, i) => `<option value="${i}"${i === state.lead ? ' selected' : ''}${a.enabled === false ? ' disabled' : ''}>${esc(a.name)}</option>`).join('');
    modeChip.textContent = state.agentMode ? `Agents · ${active}` : '';
  }
  const agentList = view.querySelector('#ai-agents-list');
  agentList.addEventListener('input', (e) => {
    const field = e.target.dataset.field;
    if (!field) return;
    const i = Number(e.target.closest('[data-agent]').dataset.agent);
    if (field === 'enabled') {
      state.agents[i].enabled = e.target.checked;
      renderAgentList();
      return;
    }
    state.agents[i][field] = e.target.value;
  });
  agentList.addEventListener('change', (e) => {
    if (e.target.dataset.field === 'enabled') {
      const i = Number(e.target.closest('[data-agent]').dataset.agent);
      state.agents[i].enabled = e.target.checked;
      renderAgentList();
    }
  });
  agentList.addEventListener('click', (e) => {
    const rm = e.target.closest('[data-remove]');
    if (!rm || state.agents.length <= 1) return;
    state.agents.splice(Number(rm.dataset.remove), 1);
    renderAgentList();
  });
  view.querySelector('#ai-agents-add').addEventListener('click', () => {
    if (state.agents.length >= 5) return;
    let n = state.agents.length + 1;
    while (state.agents.some((a) => a.name === 'Agent ' + n)) n++;
    state.agents.push({ name: 'Agent ' + n, model: AI_MODEL_DEFAULT, role: '', enabled: true });
    renderAgentList();
  });
  view.querySelector('#ai-agents-lead').addEventListener('change', (e) => {
    state.lead = Number(e.target.value);
  });
  syncAgentModeUi();

  function startTimer() {
    const tick = setInterval(() => {
      if (!state.controller) {
        clearInterval(tick);
        return;
      }
      for (const m of state.messages) if (m.streaming && m.node) updateRow(m);
    }, 1000);
  }

  async function sendDiscussion(topic) {
    const activeAgents = state.agents.filter((a) => a.enabled !== false);
    if (!activeAgents.length) {
      toast('Enable at least one agent, or turn Agents off', 'error');
      return;
    }
    state.messages.push({ role: 'user', text: topic });
    input.value = '';
    input.style.height = '';
    state.controller = new AbortController();
    state.stopped = false;
    syncComposer();
    setPill('Discussing', 'busy');
    startTimer();
    scheduleRender();
    let current = null;
    const addError = (message) => state.messages.push({
      role: 'assistant', agent: 'System', color: 0, text: message, error: true, streaming: false,
      steps: [], secs: null, tStart: performance.now(), tThink: null, tAnswer: null,
    });
    try {
      await streamAi({
        topic,
        agents: state.agents.filter((a) => a.enabled !== false).map((a) => ({ name: a.name, model: a.model, role: a.role })),
        rounds: Number(view.querySelector('#ai-agents-rounds').value),
        lead: (() => {
          const enabled = state.agents.map((a, i) => (a.enabled === false ? null : i)).filter((i) => i !== null);
          const leadName = state.agents[state.lead] && state.agents[state.lead].name;
          const idx = enabled.findIndex((i) => state.agents[i].name === leadName);
          return idx >= 0 ? idx : 0;
        })(),
        files: state.files.slice(),
      }, state.controller.signal, (event, data) => {
        if (event === 'turn_start') {
          current = {
            role: 'assistant', agent: data.agent, color: data.color, round: data.round,
            agentMode: true,
            text: '', thinking: '', streaming: true, error: false, steps: [],
            tStart: performance.now(), tThink: null, tAnswer: null, secs: null,
          };
          state.messages.push(current);
        } else if (event === 'turn_done') {
          if (current) {
            current.text = data.text;
            current.streaming = false;
            current.tAnswer = performance.now();
            current.secs = Math.max(1, Math.round((current.tAnswer - current.tStart) / 1000));
            current.fileChanges = extractFileProposals(current.text || '');
          }
          current = null;
        } else if (event === 'done') {
          const incoming = data.changes || [];
          for (const c of incoming) {
            const i = state.changes.findIndex((x) => x.path === c.path);
            if (i >= 0) state.changes[i] = { ...state.changes[i], ...c };
            else state.changes.push(c);
          }
          if (current) {
            current.fileChanges = incoming.length ? incoming : extractFileProposals(current.text || '');
          } else if (incoming.length && state.messages.length) {
            const last = [...state.messages].reverse().find((m) => m.role === 'assistant' && !m.error);
            if (last) last.fileChanges = incoming;
          }
          state.selected = new Set(state.changes.map((_, i) => i));
          state.current = state.changes.length ? 0 : null;
        } else if (event === 'error') {
          addError(data.message);
        }
        scheduleRender();
      }, 'api/ai/agents');
      setPill('Done', 'ok');
    } catch (err) {
      if (state.stopped) {
        setPill('Stopped');
      } else {
        addError(err.message);
        setPill('Error', 'error');
      }
    } finally {
      if (current) current.streaming = false;
      state.controller = null;
      syncComposer();
      renderThread();
      renderChanges();
    }
  }


  // Slash shortcuts (UI only — inserts prompt text)
  const SLASH = [
    { cmd: '/rewrite', desc: 'Rephrase the last response', prompt: 'Rewrite your last answer more clearly.' },
    { cmd: '/expand', desc: 'Elaborate on the last response', prompt: 'Expand on your last answer with more detail.' },
    { cmd: '/shorten', desc: 'Compress the last response', prompt: 'Shorten your last answer.' },
    { cmd: '/review', desc: 'Review attached files for bugs', prompt: 'Review the attached files for bugs and risks.' },
    { cmd: '/fix', desc: 'Propose a fix for the last issue', prompt: 'Propose a concrete fix for the issue you described.' },
  ];
  const slashBox = view.querySelector('#ai-slash');
  let slashIdx = 0;
  function filterSlash(q) {
    const t = (q || '').toLowerCase();
    return SLASH.filter((x) => x.cmd.startsWith(t) || x.cmd.includes(t.slice(1)));
  }
  function renderSlash(list) {
    if (!list.length) { slashBox.hidden = true; return; }
    slashBox.hidden = false;
    slashBox.innerHTML = list.map((x, i) => `
      <button type="button" class="ai-slash-item${i === slashIdx ? ' is-active' : ''}" data-slash="${esc(x.cmd)}" role="option" aria-selected="${i === slashIdx}">
        <code>${esc(x.cmd)}</code>
        <span>${esc(x.desc)}</span>
      </button>`).join('') + `
      <div class="ai-slash-hint">Tab to complete · ↑↓ navigate · Esc to close</div>`;
  }
  function applySlash(cmd) {
    const item = SLASH.find((x) => x.cmd === cmd);
    if (!item) return;
    input.value = item.prompt;
    slashBox.hidden = true;
    input.focus();
    syncComposer();
  }
  input.addEventListener('input', () => {
    const v = input.value;
    if (v.startsWith('/')) {
      const list = filterSlash(v.trim());
      slashIdx = 0;
      renderSlash(list);
    } else {
      slashBox.hidden = true;
    }
  });
  input.addEventListener('keydown', (e) => {
    if (slashBox.hidden) return;
    const list = filterSlash(input.value.trim());
    if (!list.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); slashIdx = (slashIdx + 1) % list.length; renderSlash(list); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); slashIdx = (slashIdx - 1 + list.length) % list.length; renderSlash(list); }
    else if (e.key === 'Tab' || e.key === 'Enter') {
      if (e.key === 'Tab' || (e.key === 'Enter' && input.value.trim().startsWith('/'))) {
        e.preventDefault();
        applySlash(list[slashIdx].cmd);
      }
    } else if (e.key === 'Escape') { slashBox.hidden = true; }
  });
  slashBox.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-slash]');
    if (btn) applySlash(btn.dataset.slash);
  });

  view.querySelector('#ai-composer').addEventListener('submit', (e) => { e.preventDefault(); sendMessage(); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) sendMessage(); });
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 220) + 'px';
    syncComposer();
  });
  stop.addEventListener('click', () => {
    state.stopped = true;
    if (state.controller) state.controller.abort();
  });

  view.querySelector('#ai-clear').addEventListener('click', () => {
    if (state.controller) return;
    state.messages = [];
    state.changes = [];
    state.selected = new Set();
    state.current = null;
    setPill('Ready');
    renderThread();
    renderChanges();
  });

  thread.addEventListener('click', (e) => {
    const head = e.target.closest('.ai-think-head');
    if (head) {
      const row = head.closest('.ai-row');
      if (row && row._msg) {
        row._msg.thinkOpen = !row._msg.thinkOpen;
        updateRow(row._msg);
      }
      return;
    }
    const prompt = e.target.closest('[data-prompt]');
    if (prompt) {
      input.value = prompt.dataset.prompt;
      input.focus();
      syncComposer();
      return;
    }
    const row = e.target.closest('.ai-row');
    if (row && e.target.closest('.ai-copy')) {
      navigator.clipboard.writeText(row._msg.text).then(() => toast('Copied', 'ok'));
      return;
    }
    const code = e.target.closest('.ai-code-copy');
    if (code) {
      const text = code.closest('.ai-code').querySelector('code').textContent;
      navigator.clipboard.writeText(text).then(() => toast('Code copied', 'ok'));
      return;
    }
    const applyOne = e.target.closest('[data-apply-path]');
    if (applyOne) {
      const p = applyOne.dataset.applyPath;
      let idx = state.changes.findIndex((c) => c.path === p);
      if (idx < 0) {
        const row = e.target.closest('.ai-row');
        const msg = row && row._msg;
        const prop = msg && (msg.fileChanges || []).find((c) => c.path === p);
        if (prop) {
          state.changes.push(prop);
          idx = state.changes.length - 1;
        }
      }
      if (idx < 0) return;
      state.selected = new Set([idx]);
      state.current = idx;
      renderChanges();
      // trigger same apply path as panel
      changesBox.querySelector('#ai-apply')?.click();
      return;
    }
    const review = e.target.closest('[data-review-path]');
    if (review) {
      const p = review.dataset.reviewPath;
      let idx = state.changes.findIndex((c) => c.path === p);
      if (idx < 0) {
        const row = e.target.closest('.ai-row');
        const msg = row && row._msg;
        const prop = msg && (msg.fileChanges || []).find((c) => c.path === p);
        if (prop) {
          state.changes.push(prop);
          idx = state.changes.length - 1;
        }
      }
      if (idx < 0) return;
      if (!state.selected.has(idx)) state.selected.add(idx);
      state.current = idx;
      renderChanges();
      changesBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      toast('File kept pending — review below', 'ok');
    }
  });

  changesBox.addEventListener('click', async (e) => {
    const open = e.target.closest('[data-open]');
    if (open) {
      state.current = Number(open.dataset.open);
      renderChanges();
      return;
    }
    if (e.target.closest('#ai-discard')) {
      state.changes = [];
      state.selected = new Set();
      state.current = null;
      renderChanges();
      return;
    }
    const apply = e.target.closest('#ai-apply');
    if (!apply) return;
    const result = changesBox.querySelector('#ai-result');
    const picks = [...state.selected].sort((a, b) => a - b);
    apply.disabled = true;
    result.innerHTML = '<span class="spinner ai-spin" aria-hidden="true"></span> Saving…';
    try {
      const r = await api('api/ai/apply', {
        method: 'POST',
        body: {
          model: view.querySelector('#ai-model').value.trim(),
          changes: picks.map((i) => ({ path: state.changes[i].path, content: state.changes[i].edited ?? state.changes[i].proposed })),
        },
      });
      const saved = new Set(r.results.filter((x) => x.ok).map((x) => x.path));
      state.changes = state.changes.filter((c) => !saved.has(c.path));
      state.selected = new Set(state.changes.map((_, i) => i));
      state.current = state.changes.length ? 0 : null;
      if (saved.size) toast(`${saved.size} file(s) saved`, 'ok');
      const report = r.results.map((x) => (x.ok
        ? `<span class="badge ok">Saved</span> ${esc(x.path)}`
        : `<span class="badge err">Failed</span> ${esc(x.path)}: ${esc(x.error || '')}`)).join('<br>');
      renderChanges();
      changesBox.querySelector('#ai-result').innerHTML = report;
    } catch (err) {
      result.textContent = err.message;
      apply.disabled = false;
    }
  });

  changesBox.addEventListener('change', (e) => {
    const box = e.target.closest('[data-sel]');
    if (!box) return;
    const i = Number(box.dataset.sel);
    if (box.checked) state.selected.add(i); else state.selected.delete(i);
    renderChanges();
  });

  renderThread();
  renderChips();
  renderChanges();
  syncComposer();
}

function infraCard(icoImg, title, rows) {
  return `<section class="card infra-card">
    <div class="card-head provider-head"><h3><img class="provider-icon" src="${esc(icoImg)}" alt="" width="28" height="28"> ${esc(title)}</h3></div>
    <dl class="infra-list">${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v}</dd>`).join('')}</dl>
  </section>`;
}

async function renderInfra() {
  const view = $('#view');
  const info = await api('api/services/infra');
  const d1 = info.d1;
  const b2 = info.b2;
  const dash = (v) => (v ? esc(v) : '<span class="muted">not set</span>');
  view.innerHTML = `<div class="grid providers-grid">
    ${infraCard('assets/cloudflare.png', 'Cloudflare', [
      ['Worker', '<span class="badge ok">Running</span> (this response)'],
      ['D1 database', stateBadge(d1.state)],
      ['Stores', 'Key metadata and indexes'],
    ])}
    ${infraCard('assets/backblaze.png', 'Backblaze B2', [
      ['Bucket', dash(b2.bucket)],
      ['Endpoint', dash(b2.endpoint)],
      ['Region', dash(b2.region)],
      ['Access key ID', b2.keyIdSet ? '<span class="badge ok">Set</span>' : '<span class="badge err">Missing</span>'],
      ['Application key', b2.appKeySet ? '<span class="badge ok">Set</span>' : '<span class="badge err">Missing</span>'],
      ['Status', b2.configured ? '<span class="badge ok">Configured</span>' : '<span class="badge err">Incomplete</span>'],
      ['Stores', 'Uploaded file contents'],
    ])}
  </div>`;
}
})();
