const $=s=>document.querySelector(s);
const screen=$("#screen");
let state={mode:localStorage.getItem("larry_mode")||"adulto",level:localStorage.getItem("larry_level")||"normal",progress:JSON.parse(localStorage.getItem("larry_progress")||"{}"),selectedSubject:"matematicas"};

const subjects=[
 ["matematicas","➗","Matemáticas"],["ciencias","🔬","Ciencias"],["ingles","🇬🇧","Inglés"],
 ["espanol","📖","Español"],["historia","🏛️","Historia"],["tecnologia","💻","Tecnología"]
];

function setNav(name){
 document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.nav===name));
}
function save(){localStorage.setItem("larry_mode",state.mode);localStorage.setItem("larry_level",state.level);localStorage.setItem("larry_progress",JSON.stringify(state.progress))}
function home(){
 setNav("inicio");
 screen.innerHTML=`
 <section class="hero"><div class="eyebrow">¡Hola, estudiante! 👋</div><h1>¿Qué vamos a aprender hoy?</h1><p>Tu aprendizaje comienza aquí. Aprende a tu ritmo con tu profesor inteligente.</p><button class="primary" data-action="tutor">HABLAR CON PROFE LARRY</button></section>
 <div class="section-title"><h2>Empieza aquí</h2></div>
 <div class="grid">
  <button class="card" data-action="clases"><div class="icon">📚</div><h3>Mis clases</h3><p>Aprende cualquier materia</p></button>
  <button class="card" data-action="quiz"><div class="icon">📝</div><h3>Cuestionarios</h3><p>Practica y evalúate</p></button>
  <button class="card" data-action="progreso"><div class="icon">📈</div><h3>Mi progreso</h3><p>Observa tus avances</p></button>
  <button class="card" data-action="voz"><div class="icon">🎙️</div><h3>Aprender con voz</h3><p>Habla y escucha</p></button>
 </div>
 <div class="section-title"><h2>Acceso rápido</h2><small>Ver todo</small></div>
 <div class="subjects">${subjects.map(s=>`<button class="subject" data-subject="${s[0]}"><span>${s[1]}</span>${s[2]}</button>`).join("")}</div>`;
}
function classes(){
 setNav("clases");
 screen.innerHTML=`<h1 class="page-title">Mis clases 📚</h1><p class="muted">Elige una materia y aprende paso a paso.</p><div class="subjects panel">${subjects.map(s=>`<button class="subject" data-subject="${s[0]}"><span>${s[1]}</span>${s[2]}</button>`).join("")}</div>`;
}
function subject(key){
 state.selectedSubject=key; const s=OFFLINE_CONTENT[key]||{title:"Materia",lessons:[]};
 setNav("clases");
 screen.innerHTML=`<button class="primary" data-action="clases">← Volver</button><h1 class="page-title">${s.title}</h1><p class="muted">Contenido disponible incluso sin internet.</p>${s.lessons.map(l=>`<article class="panel lesson"><h2>${l.title}</h2><p>${l.text}</p><button class="primary" data-lesson="${l.id}">Aprender y practicar</button></article>`).join("")}`;
}
function lesson(key,id){
 const s=OFFLINE_CONTENT[key], l=s.lessons.find(x=>x.id===id); if(!l)return;
 screen.innerHTML=`<button class="primary" data-subject="${key}">← ${s.title}</button><article class="panel lesson"><h2>${l.title}</h2><p>${l.text}</p>${l.quiz.map((q,qi)=>`<div class="quiz-q">${qi+1}. ${q[0]}</div>${q[1].map((a,ai)=>`<button class="answer" data-ans="${ai}" data-q="${qi}">${a}</button>`).join("")}`).join("")}<div id="result"></div></article>`;
}
function tutor(){
 setNav("tutor");
 screen.innerHTML=`<h1 class="page-title">Profe Larry 🧑‍🏫</h1><p class="muted">Pregúntame lo que quieras. Si no hay internet, te ayudaré con lo que esté disponible en el dispositivo.</p>
 <div class="panel"><strong>¿Cómo quieres que te explique?</strong><div class="select-row" style="margin-top:10px">${[["facil","Muy fácil"],["normal","Normal"],["profundo","Profundamente"],["experto","Nivel experto"]].map(x=>`<button class="choice ${state.level===x[0]?"selected":""}" data-level="${x[0]}"><strong>${x[1]}</strong><small>Adaptaré la explicación</small></button>`).join("")}</div></div>
 <div class="panel chat" id="chat"><div class="msg ai">¡Hola! Soy Profe Larry. 👋<br>Cuéntame qué quieres aprender.</div></div>
 <form class="composer" id="composer"><input id="question" placeholder="Escribe tu pregunta…" autocomplete="off"><button>➤</button></form>`;
}
function progress(){
 setNav("progreso");
 const vals=Object.values(state.progress), done=vals.length, total=subjects.length, pct=Math.min(100,Math.round(done/total*100));
 screen.innerHTML=`<h1 class="page-title">Mi progreso 📈</h1><p class="muted">Cada paso cuenta. Sigue aprendiendo.</p><div class="panel"><strong>Materias iniciadas</strong><h2>${done} de ${total}</h2><div class="progressbar"><i style="width:${pct}%"></i></div><p class="muted">${pct}% de avance general</p></div><div class="panel"><strong>Tu forma de aprender</strong><p>Modo: <b>${state.mode}</b><br>Nivel de explicación: <b>${state.level}</b></p><button class="primary" data-action="perfil">Cambiar preferencias</button></div>`;
}
function profile(){
 setNav("perfil");
 screen.innerHTML=`<h1 class="page-title">Mi perfil 🙂</h1><p class="muted">Personaliza cómo te enseña Profe Larry.</p><div class="panel"><strong>¿Quién está aprendiendo?</strong><div class="select-row" style="margin-top:10px">${[["nino","🧒 Niño"],["joven","🧑 Joven"],["adulto","🧑‍💼 Adulto"]].map(x=>`<button class="choice ${state.mode===x[0]?"selected":""}" data-mode="${x[0]}"><strong>${x[1]}</strong><small>Adaptaré ejemplos y lenguaje</small></button>`).join("")}</div></div><div class="panel"><strong>Instalación</strong><p class="muted">La app está preparada como PWA/Capacitor para Android. El contenido básico puede consultarse sin internet.</p></div>`;
}
async function ask(q){
 const chat=$("#chat"); chat.insertAdjacentHTML("beforeend",`<div class="msg me">${q}</div>`);
 try{
  const r=await fetch("/api/tutor",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:q,level:state.level,mode:state.mode})});
  const d=await r.json(); chat.insertAdjacentHTML("beforeend",`<div class="msg ai">${(d.answer||d.error||"No pude responder.").replace(/\n/g,"<br>")}</div>`);
 }catch(e){chat.insertAdjacentHTML("beforeend",`<div class="msg ai">Ahora mismo no tengo conexión. Puedes seguir con las clases descargadas y los cuestionarios.</div>`)}
 chat.scrollIntoView({behavior:"smooth",block:"end"});
}
document.addEventListener("click",e=>{
 const nav=e.target.closest("[data-nav]"); if(nav){const n=nav.dataset.nav; if(n==="inicio")home();if(n==="clases")classes();if(n==="tutor")tutor();if(n==="progreso")progress();if(n==="perfil")profile();return}
 const a=e.target.closest("[data-action]"); if(a){const x=a.dataset.action;if(x==="tutor")tutor();if(x==="clases")classes();if(x==="quiz")subject(state.selectedSubject);if(x==="progreso")progress();if(x==="perfil")profile();if(x==="voz")tutor();return}
 const sub=e.target.closest("[data-subject]"); if(sub){subject(sub.dataset.subject);state.progress[sub.dataset.subject]=true;save();return}
 const lev=e.target.closest("[data-level]"); if(lev){state.level=lev.dataset.level;save();tutor();return}
 const mode=e.target.closest("[data-mode]"); if(mode){state.mode=mode.dataset.mode;save();profile();return}
 const lessonBtn=e.target.closest("[data-lesson]"); if(lessonBtn){lesson(state.selectedSubject,lessonBtn.dataset.lesson);return}
 const ans=e.target.closest("[data-ans]"); if(ans){const l=OFFLINE_CONTENT[state.selectedSubject].lessons.find(x=>x.quiz.some((_,i)=>i===Number(ans.dataset.q)));const q=l.quiz[Number(ans.dataset.q)];document.querySelectorAll(`[data-q="${ans.dataset.q}"]`).forEach(b=>b.disabled=true);if(Number(ans.dataset.ans)===q[2]){ans.classList.add("correct");$("#result").textContent="¡Muy bien! 🎉"}else{ans.classList.add("wrong");$("#result").textContent="Casi. Mira de nuevo la explicación y vuelve a intentarlo."}return}
});
document.addEventListener("submit",e=>{if(e.target.id==="composer"){e.preventDefault();const i=$("#question");const q=i.value.trim();if(q){i.value="";ask(q)}}});
function online(){const el=$("#onlineState");el.innerHTML=navigator.onLine?'<i></i> Con internet':'<i style="background:#f0ad4e"></i> Sin internet · modo aprendizaje';}
window.addEventListener("online",online);window.addEventListener("offline",online);
home();online();

if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
