// Fallback service-worker.js redirecting to sw.js implementation
importScripts('/sw.js');
