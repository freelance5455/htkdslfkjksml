const CACHE_NAME = 'bd-blood-cache-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/css/style.css',
  '/css/components.css',
  '/css/auth.css',
  '/css/dashboard.css',
  '/css/responsive.css',
  '/css/dark-mode.css',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  // Network first with cache fallback for offline readiness
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});

// Push notification receiver for Web Push
self.addEventListener('push', (event) => {
  if (!event.data) return;
  try {
    const data = event.data.json();
    const title = data.title || 'BD BLOOD DONATION';
    const options = {
      body: data.message || 'জরুরি রক্তের আবেদন!',
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      data: data
    };
    event.waitUntil(self.registration.showNotification(title, options));
  } catch (e) {
    console.error('Push error:', e);
  }
});
