/* FLAPORA service worker
 *
 * At build time (see vite.config.ts) two globals are prepended to this file:
 *   self.__PRECACHE_URLS__  -> every file in dist/ (JS, CSS, images, audio, icons...)
 *   self.__CACHE_VERSION__  -> hash of the build, so each new build gets a fresh cache
 * In dev these are undefined and the fallbacks below are used (SW isn't registered in dev anyway).
 */

const VERSION = self.__CACHE_VERSION__ || 'dev';
const CACHE_NAME = `flapora-static-${VERSION}`;
const FONT_CACHE = 'flapora-fonts-v1';
const PRECACHE_URLS = self.__PRECACHE_URLS__ || ['/', '/index.html', '/manifest.json'];

// Must match the <link> in index.html so the CSS is already cached when the page asks for it.
const FONT_CSS_URL =
  'https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&family=Fredoka:wght@500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap';

const NAV_TIMEOUT_MS = 3000;

/* ---------- install: precache everything ---------- */
self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // cache:'reload' bypasses the HTTP cache so we never store stale copies.
      // If any file fails, install fails and the old SW (and its cache) stays active.
      await Promise.all(
        PRECACHE_URLS.map((url) => cache.add(new Request(url, { cache: 'reload' })))
      );
      await precacheFonts().catch(() => {}); // fonts are best-effort
      await self.skipWaiting();
    })()
  );
});

async function precacheFonts() {
  const fontCache = await caches.open(FONT_CACHE);
  const cssRes = await fetch(FONT_CSS_URL, { mode: 'cors' });
  if (!cssRes.ok) return;
  const css = await cssRes.clone().text();
  await fontCache.put(FONT_CSS_URL, cssRes);
  const fontUrls = [...css.matchAll(/url\((https:\/\/fonts\.gstatic\.com\/[^)]+)\)/g)].map((m) => m[1]);
  await Promise.all(
    [...new Set(fontUrls)].map(async (u) => {
      if (await fontCache.match(u)) return;
      const r = await fetch(u, { mode: 'cors' });
      if (r.ok) await fontCache.put(u, r);
    })
  );
}

/* ---------- activate: drop old caches ---------- */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keep = new Set([CACHE_NAME, FONT_CACHE]);
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => k.startsWith('flapora-') && !keep.has(k)).map((k) => caches.delete(k))
      );
      await self.clients.claim();
    })()
  );
});

/* ---------- fetch ---------- */
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // Google Fonts: cache-first, refresh in background
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(staleWhileRevalidate(req, FONT_CACHE));
    return;
  }

  // Ignore everything else that is cross-origin
  if (url.origin !== self.location.origin) return;

  // Page loads: network first (so updates arrive), fall back to the cached app shell
  if (req.mode === 'navigate') {
    event.respondWith(handleNavigation(req));
    return;
  }

  // Audio/video send Range requests; the cache returns whole files, so slice them ourselves
  if (req.headers.has('range')) {
    event.respondWith(handleRange(req));
    return;
  }

  // Static assets: cache first, then network (and cache what we got)
  event.respondWith(cacheFirst(req));
});

async function handleNavigation(req) {
  const cache = await caches.open(CACHE_NAME);
  try {
    const res = await withTimeout(fetch(req), NAV_TIMEOUT_MS);
    if (res && res.ok) cache.put('/', res.clone());
    return res;
  } catch {
    return (
      (await cache.match('/')) ||
      (await cache.match('/index.html')) ||
      new Response('Offline', { status: 503, statusText: 'Offline' })
    );
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(CACHE_NAME);
  const hit = await cache.match(req);
  if (hit) return hit;
  try {
    const res = await fetch(req);
    if (res.ok && res.type === 'basic') cache.put(req, res.clone());
    return res;
  } catch {
    return new Response('', { status: 504, statusText: 'Offline' });
  }
}

async function staleWhileRevalidate(req, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(req);
  const network = fetch(req)
    .then((res) => {
      if (res.ok || res.type === 'opaque') cache.put(req, res.clone());
      return res;
    })
    .catch(() => null);
  if (hit) return hit;
  return (await network) || new Response('', { status: 504, statusText: 'Offline' });
}

async function handleRange(req) {
  const cache = await caches.open(CACHE_NAME);
  const hit = await cache.match(req.url);
  if (!hit) return fetch(req); // not cached: let the network deal with it

  const buf = await hit.arrayBuffer();
  const size = buf.byteLength;
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  if (!m) return hit;

  let start;
  let end;
  if (m[1] === '') {
    // suffix range: last N bytes
    start = Math.max(0, size - Number(m[2]));
    end = size - 1;
  } else {
    start = Number(m[1]);
    end = m[2] === '' ? size - 1 : Math.min(Number(m[2]), size - 1);
  }

  if (start >= size || start > end) {
    return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
  }

  return new Response(buf.slice(start, end + 1), {
    status: 206,
    statusText: 'Partial Content',
    headers: {
      'Content-Type': hit.headers.get('Content-Type') || 'application/octet-stream',
      'Content-Range': `bytes ${start}-${end}/${size}`,
      'Content-Length': String(end - start + 1),
      'Accept-Ranges': 'bytes',
    },
  });
}

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then(
      (v) => { clearTimeout(t); resolve(v); },
      (e) => { clearTimeout(t); reject(e); }
    );
  });
}
