async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/login.html';
}

async function loadMe() {
  const res = await fetch('/api/me');
  if (!res.ok) { window.location.href = '/login.html'; return; }
  const user = await res.json();
  document.getElementById('username').textContent = user.username;
}

async function loadPhotos() {
  const res = await fetch('/api/my-photos');
  if (!res.ok) return;
  const photos = await res.json();
  document.getElementById('myPhotoCount').textContent = photos.length;

  if (photos.length > 0) {
    const last = photos[0];
    document.getElementById('lastActivity').innerHTML = `
      <div><span>Terakhir upload</span><span>${new Date(last.uploadedAt).toLocaleString('id-ID')}</span></div>
      <div><span>Total</span><span>${photos.length} foto</span></div>
    `;
  }

  const gallery = document.getElementById('gallery');
  if (photos.length === 0) {
    gallery.innerHTML = '<p style="color:#888">Belum ada foto. Yuk ambil foto pertamamu! 📸</p>';
    return;
  }
  gallery.innerHTML = photos.map(p => `
    <div class="gallery-item">
      <img src="${p.url}" alt="${p.filename}">
      <button class="delete-btn" onclick="deletePhoto(${p.id})">✕</button>
    </div>
  `).join('');
}

async function deletePhoto(id) {
  if (!confirm('Hapus foto ini?')) return;
  await fetch('/api/photos/' + id, { method: 'DELETE' });
  loadPhotos();
}

loadMe();
loadPhotos();
setInterval(loadPhotos, 8000);