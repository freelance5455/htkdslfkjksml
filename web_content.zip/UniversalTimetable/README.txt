Universal Timetable - Android project (WebView wrapper around the liquid glass HTML page)

Option A - Android Studio
  1. File > Open, choose this folder, wait for Gradle sync.
  2. Build > Build Bundle(s) / APK(s) > Build APK(s).
  3. The APK is at app/build/outputs/apk/debug/app-debug.apk

Option B - GitHub cloud build (no Android tools needed)
  1. Create a GitHub repository and upload everything in this folder,
     keeping the folder structure (including .github/workflows/build-apk.yml).
  2. Open the Actions tab > Build APK > wait for the green tick.
  3. Download the "UniversalTimetable-apk" artifact and unzip it to get app-debug.apk.

Install: copy the APK to your phone and allow "install unknown apps" for your file manager or browser.
To change the app later, edit app/src/main/assets/index.html.
