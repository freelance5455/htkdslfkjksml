(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rand = (a, b) => a + Math.random() * (b - a);
  const fmt = (n) => Math.floor(n).toLocaleString('ru-RU');
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

  const HEROES = [
    {id:'ayla', name:'АЙЛА', full:'Айла / TIMUR-02', rank:5, element:'СУКУТ', role:'Экзегет · универсал', color:'#c8b27c', hair:'#222c27', glyph:'A', hp:1120, atk:118, speed:246, skill:'Теневой разрез', desc:'Боевой андроид-археолог. Её память хранит мелодии, которых не должно существовать.', skillType:'dash', ult:'Нулевая запись', ultType:'burst'},
    {id:'rustam', name:'РУСТАМ', full:'Рустам / Мастер-09', rank:4, element:'ПЫЛЬ', role:'Инженер · разрушитель', color:'#b57d4e', hair:'#39453b', glyph:'R', hp:1480, atk:102, speed:214, skill:'Гидравлический импульс', desc:'Инженер Кызылкумского синдиката. Верит, что любую проблему можно разобрать и собрать заново.', skillType:'slam', ult:'Последний пресс', ultType:'slam'},
    {id:'saodat', name:'САОДАТ', full:'Саодат / Астра-4', rank:5, element:'ТОК', role:'Астроном · дальний бой', color:'#90b5b1', hair:'#253c43', glyph:'S', hp:980, atk:126, speed:230, skill:'Орбитальный импульс', desc:'Исследовательница Академии звёздного неба. Рассчитывает траектории так, будто видит секунду вперёд.', skillType:'bolt', ult:'Зенитный каскад', ultType:'storm'},
    {id:'zumrad', name:'ЗУМРАД', full:'Зумрад / Оазис-11', rank:4, element:'НАВДА', role:'Биомеханик · поддержка', color:'#8cae7d', hair:'#314b3c', glyph:'Z', hp:1220, atk:96, speed:238, skill:'Живой контур', desc:'Проводница Детей Оазиса. Её механические манипуляторы умеют лечить и удерживать врагов.', skillType:'heal', ult:'Сад из шипов', ultType:'roots'},
    {id:'malika', name:'МАЛИКА', full:'Малика / Клин', rank:5, element:'ЖАР', role:'Дуэлянт · штурм', color:'#cf8767', hair:'#3b2524', glyph:'M', hp:1050, atk:145, speed:255, skill:'Перегрев клинков', desc:'Охотница Синдиката. Сражается двумя плазменными клинками и никогда не отступает первой.', skillType:'dash', ult:'Красная линия', ultType:'burst'},
    {id:'kamol', name:'КАМОЛ', full:'Камол / Орбита', rank:5, element:'САДО', role:'Контроль · синхронизатор', color:'#b8a6d0', hair:'#37334a', glyph:'K', hp:1080, atk:119, speed:232, skill:'Орбитальное поле', desc:'Учёный Академии, который превратил старые астрономические вычисления в оружие.', skillType:'field', ult:'Общий такт', ultType:'storm'},
    {id:'laylo', name:'ЛАЙЛО', full:'Лайло / Росток', rank:5, element:'НАВДА', role:'Биомеханик · контроль', color:'#91b58c', hair:'#25372e', glyph:'L', hp:1190, atk:121, speed:240, skill:'Корни-ловушки', desc:'Исследовательница живых технологий. Считает, что природа не нуждается в разрешении машин.', skillType:'roots', ult:'Зелёная память', ultType:'roots'},
    {id:'bekzod', name:'БЕКЗОД', full:'Бекзод / Гвоздь', rank:4, element:'ПЫЛЬ', role:'Стрелок · точечный урон', color:'#a9a17c', hair:'#2e332e', glyph:'B', hp:1020, atk:112, speed:244, skill:'Калиброванный залп', desc:'Мастер самодельного оружия. Его гвоздомёт редко стреляет дважды в одну точку.', skillType:'bolt', ult:'Пробой карьера', ultType:'storm'}
  ];
  // Expanded roster: the eight v0.1 heroes remain, and the remaining 36 concepts complete the 44-character launch archive.
  const EXTRA_HEROES = [
    ['iroda','ИРОДА','Iroda / Магнит',5,'ТОК','Магнитное копьё · контроль','#9bb6bd','#263b43','I',1180,124,236,'Магнитная цепь','Притягивает врагов и возвращает снаряды.','field','storm'],
    ['tohir','ТОХИР','Tohir / Пресс',4,'ПЫЛЬ','Гидравлические перчатки','#b18b70','#40352c','T',1450,99,207,'Удар пресса','Пробивает броню тяжёлым гидравлическим ударом.','slam','slam'],
    ['dilorom','ДИЛОРОМ','Dilorom / Кабель',4,'САДО','Энергетический трос · контроль','#b48da2','#382b39','D',1110,101,238,'Кабельный захват','Соединяет противников вибрационным импульсом.','roots','roots'],
    ['iskandar','ИСКАНДАР','Iskandar / Ноль',4,'ТОК','Инженер · дроны','#9aaea2','#293b35','I',1260,94,225,'Ремонтные дроны','Восстанавливает здоровье и усиливает энергию.','heal','storm'],
    ['sabr','САБР','Sabr / Котёл',4,'ЖАР','Термальная пушка · дальний бой','#c48b60','#483229','S',1190,108,214,'Термальный залп','Создаёт горячую зону вокруг выбранной цели.','bolt','burst'],
    ['kodir','КОДИР','Kodir / Карьер',4,'ПЫЛЬ','Бур-молот · разрушитель','#a99a79','#38382d','K',1530,106,198,'Карьерный раскол','Сильная ударная волна разрушает защиту.','slam','slam'],
    ['zebo','ЗЕБО','Zebo / Предел',5,'СУКУТ','Лазерная рапира · дуэлянт','#b5a1c5','#322d43','Z',1050,145,258,'Линия предела','Проходит сквозь барьеры и карает за ошибки.','dash','burst'],
    ['nargiza','НАРГИЗА','Nargiza / Эхо',4,'САДО','Акустический лук · дальний бой','#a6b7a3','#334239','N',1030,113,242,'Резонансная стрела','Оставляет звуковую метку для последующих атак.','bolt','storm'],
    ['mirzo','МИРЗО','Mirzo / Спектр',4,'ТОК','Парные сабли · комбо','#8eb9bd','#273e44','M',1120,117,250,'Спектральный рывок','Входит в комбо при быстрой смене героя.','dash','burst'],
    ['farhod','ФАРХОД','Farhod / Зенит',4,'ПЫЛЬ','Снайпер · точечный урон','#b8a77f','#3d382b','F',980,132,218,'Зенитный выстрел','Наносит повышенный урон отмеченной цели.','bolt','storm'],
    ['nilufar','НИЛУФАР','Nilufar / Аура',4,'НАВДА','Медик · поддержка','#a4bd9c','#2e4033','N',1320,87,224,'Аура восстановления','Лечит оперативника и снимает давление врагов.','heal','roots'],
    ['shavkat','ШАВКАТ','Shavkat / Импульс',4,'ТОК','Боец · ускорение','#9ab5ba','#283b41','S',1080,118,257,'Импульсный разгон','Ускоряет серию ударов и наносит электрический урон.','dash','storm'],
    ['oibek','ОЙБЕК','Oibek / Кодекс',4,'СУКУТ','Тактик · ослабление','#a99db4','#34313b','O',1190,102,226,'Анализ цели','Подавляет защитные системы ближайших врагов.','field','roots'],
    ['jasur','ЖАСУР','Jasur / Зверь',5,'НАВДА','Биомеханик · штурм','#8eaa79','#28382a','J',1420,143,244,'Хищная мутация','Временно меняет тело и усиливает ближние атаки.','dash','slam'],
    ['sherzod','ШЕРЗОД','Sherzod / След',4,'ПЫЛЬ','Дуэлянт · контратаки','#b5a17c','#38352c','S',1090,121,260,'Ответный след','Усиливает атаку после идеального уклонения.','dash','burst'],
    ['munisa','МУНИСА','Munisa / Спора',4,'НАВДА','Биодроны · поддержка','#9bb88e','#2e4132','M',1270,93,225,'Споровый рой','Создаёт зону лечения и постепенно ослабляет врагов.','heal','roots'],
    ['dilafruz','ДИЛАФРУЗ','Dilafruz / Мираж',4,'САДО','Иллюзии · уклонение','#b8a0ae','#40303d','D',1050,108,252,'Ложная цель','Создаёт проекцию, отвлекающую противников.','field','storm'],
    ['otabek','ОТАБЕК','Otabek / Вектор',4,'ТОК','Копейщик · мобильность','#90b1b7','#293d42','O',1170,116,256,'Векторный выпад','Пробивает линию врагов быстрым рывком.','dash','burst'],
    ['yulduz','ЮЛДУЗ','Yulduz / Мелодия',4,'САДО','Резонатор · поддержка','#c1a5a0','#44343a','Y',1140,102,232,'Общий ритм','Усиливает отряд звуковыми импульсами.','field','roots'],
    ['akmal','АКМАЛ','Akmal / Шип',4,'НАВДА','Биолук · дальний бой','#9cb08a','#303e30','A',1130,119,235,'Шипованный залп','Выпускает несколько самонаводящихся снарядов.','bolt','storm'],
    ['kamila','КАМИЛА','Kamila / Нить',5,'СУКУТ','Архивист · копирование','#b29db8','#393044','K',1100,136,238,'Нить воспоминаний','Воспроизводит усиленную версию последней атаки.','field','burst'],
    ['ulugbek7','УЛУГБЕК-7','Ulugbek-7 / Хронометр',5,'ТОК','Вычислитель · контроль','#a9b7c0','#2b3a47','U',1210,128,221,'Окно вероятности','На короткое время замедляет восприятие врагов.','field','storm'],
    ['timur','ТИМУР','Timur / Страж',4,'ПЫЛЬ','Защитник · щит','#b29d7f','#3c352b','T',1580,91,196,'Архивный заслон','Создаёт защитную волну и отталкивает врагов.','slam','roots'],
    ['rano','РАНО','Rano / Глиф',4,'САДО','Тактик · метки','#b79e89','#40362e','R',1080,107,234,'Кодовая метка','Помечает врагов для усиленных командных атак.','bolt','storm'],
    ['murod','МУРОД','Murod / Складка',4,'СУКУТ','Защитник · мембраны','#a5a9a0','#343934','M',1370,96,213,'Отражающая пластина','Формирует барьер и подавляет снаряды.','slam','roots'],
    ['sevara','СЕВАРА','Sevara / Точка',4,'ТОК','Стрелок · серия попаданий','#9cb9c1','#293e45','S',1010,124,246,'Точечная серия','Усиливает урон за последовательные попадания.','bolt','storm'],
    ['anvar','АНВАР','Anvar / Голос',4,'САДО','Резонатор · прерывание','#baa48d','#40372e','A',1190,106,230,'Волна давления','Прерывает умения и отталкивает противников.','slam','storm'],
    ['shakhnoza','ШАХНОЗА','Shakhnoza / Память',4,'НАВДА','Медик · нейроинструменты','#a1b99f','#2d4032','Sh',1300,92,221,'Нейронное восстановление','Лечит союзника и возвращает энергию.','heal','roots'],
    ['aziza','АЗИЗА','Aziza / Рельса',5,'ТОК','Магнитное копьё · штурм','#c3a16f','#40372c','A',1190,142,245,'Рельсопушка','Чередует дальний выстрел и скоростную атаку.','bolt','storm'],
    ['firdavs','ФИРДАВС','Firdavs / Локомотив',5,'ЖАР','Тяжёлый меч · разрушитель','#c78b62','#493129','F',1540,149,204,'Термальный разгон','Ударная волна наносит большой урон по области.','slam','slam'],
    ['sardor','САРДОР','Sardor / Якорь',4,'ПЫЛЬ','Гарпун · контроль','#b29b7c','#3d352a','S',1400,106,207,'Якорный захват','Стягивает ближайших противников к центру.','roots','roots'],
    ['madina','МАДИНА','Madina / Фонарь',4,'НАВДА','Ремонтник · поддержка','#a5b99b','#304033','M',1310,89,220,'Полевой маяк','Разворачивает зону восстановления.','heal','roots'],
    ['zafar','ЗАФАР','Zafar / Скорость',4,'ТОК','Два револьвера · стрелок','#a4b9bb','#2b3f42','Z',1050,121,255,'Электрическая очередь','Выпускает серию импульсных выстрелов.','bolt','storm'],
    ['mohira','МОХИРА','Mohira / Турель',4,'ЖАР','Инженер · турели','#c29473','#45352b','M',1150,105,219,'Переносная турель','Создаёт кратковременную автоматическую поддержку.','field','storm'],
    ['nurali','НУРАЛИ','Nurali / Колесо',4,'ПЫЛЬ','Щитовик · отражение','#b0a17e','#39362d','N',1510,94,202,'Вращающийся щит','Отталкивает врагов и защищает от удара.','slam','roots'],
    ['kamron','КАМРОН','Kamron / Курьер',4,'САДО','Скоростной боец · поддержка','#a5b7aa','#2f3e36','K',1080,116,266,'Курьерский импульс','Ускоряет смену тактики и наносит серию ударов.','dash','burst']
  ].map(([id,name,full,rank,element,role,color,hair,glyph,hp,atk,speed,skill,desc,skillType,ultType]) => ({id,name,full,rank,element,role,color,hair,glyph,hp,atk,speed,skill,desc,skillType,ult:`${name}: предельный протокол`,ultType}));
  HEROES.push(...EXTRA_HEROES);
  const FACTION_GROUPS = {
    'Кызылкумский синдикат':['rustam','malika','bekzod','iroda','tohir','dilorom','iskandar','sabr','kodir'],
    'Академия звёздного неба':['saodat','kamol','zebo','nargiza','mirzo','farhod','nilufar','shavkat','oibek'],
    'Дети Оазиса':['zumrad','laylo','jasur','sherzod','munisa','dilafruz','otabek','yulduz','akmal'],
    'Архив «Седьмой Порог»':['kamila','ulugbek7','timur','rano','murod','sevara','anvar','shakhnoza'],
    'Караван «Соль-9»':['aziza','firdavs','sardor','madina','zafar','mohira','nurali','kamron']
  };
  HEROES.forEach(h=>{h.faction=Object.entries(FACTION_GROUPS).find(([,ids])=>ids.includes(h.id))?.[0]||'Независимые / Катта-Матрица';});
  const HERO_BY_ID = Object.fromEntries(HEROES.map(h => [h.id, h]));

  // v0.6: expanded combat kits, branch consequences, exploration, station production and local banner calendar.
  const HERO_PASSIVES = Object.fromEntries([
    ["ayla",{name:"Эхо первой записи",desc:"Третий удар серии сильнее; попадания быстрее собирают МАКОМ.",atkBonus:0.025,hpBonus:0.0,speedBonus:0,skillPower:1.04,makomGain:1.14,damageReduction:0.0,thirdHitBonus:0.18,critChance:0.01,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"В старой кассете Айла слышит не голос, а собственный ритм до активации."}],
    ["rustam",{name:"Запас прочности",desc:"Повышенная прочность и снижение входящего урона.",atkBonus:0.0,hpBonus:0.045,speedBonus:-2,skillPower:1.04,makomGain:1.02,damageReduction:0.075,thirdHitBonus:0.02,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Рустам помнит, как мастерская пережила первую зиму без электричества."}],
    ["saodat",{name:"Параллакс",desc:"Увеличенная дальность атаки и шанс критического попадания.",atkBonus:0.035,hpBonus:0.0,speedBonus:0,skillPower:1.08,makomGain:1.04,damageReduction:0.0,thirdHitBonus:0.03,critChance:0.045,attackRange:16,swapPulse:0.0,dashPulse:0.0,scene:"Саодат оставила на стене расчёт звезды, которую никто больше не видит."}],
    ["zumrad",{name:"Живой обмен",desc:"Навыки эффективнее, а входящий урон немного ниже.",atkBonus:0.0,hpBonus:0.035,speedBonus:0,skillPower:1.12,makomGain:1.02,damageReduction:0.035,thirdHitBonus:0.02,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Зумрад хранит первый лист, проросший сквозь бетон станции."}],
    ["malika",{name:"Красная инерция",desc:"Третий удар и критические попадания наносят больше урона.",atkBonus:0.045,hpBonus:0.0,speedBonus:8,skillPower:1.02,makomGain:1.04,damageReduction:0.0,thirdHitBonus:0.22,critChance:0.035,attackRange:0,swapPulse:0.0,dashPulse:0.06,scene:"Малика не стирает имена пропавших напарников с внутреннего клинка."}],
    ["kamol",{name:"Синхронный расчёт",desc:"МАКОМ быстрее заряжается, навыки перезаряжаются быстрее.",atkBonus:0.015,hpBonus:0.015,speedBonus:0,skillPower:1.08,makomGain:1.18,damageReduction:0.0,thirdHitBonus:0.04,critChance:0.01,attackRange:6,swapPulse:0.0,dashPulse:0.0,scene:"Камол хранит последнюю формулу наставника на внутренней стороне перчатки."}],
    ["laylo",{name:"Корневая сеть",desc:"Больше прочности, усиленные навыки и лёгкое замедление врагов.",atkBonus:0.01,hpBonus:0.035,speedBonus:0,skillPower:1.1,makomGain:1.05,damageReduction:0.02,thirdHitBonus:0.06,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Лайло выращивает рядом с вентиляцией растение, которое не боится темноты."}],
    ["bekzod",{name:"Калиброванный импульс",desc:"Дальняя атака точнее и критические попадания вероятнее.",atkBonus:0.03,hpBonus:0.0,speedBonus:4,skillPower:1.05,makomGain:1.03,damageReduction:0.0,thirdHitBonus:0.05,critChance:0.035,attackRange:12,swapPulse:0.0,dashPulse:0.0,scene:"Бекзод подписывает каждый новый механизм именем человека, который его проверил."}],
    ["iroda",{name:"Магнитный возврат",desc:"Критический шанс и радиус атаки выше.",atkBonus:0.025,hpBonus:0.015,speedBonus:0,skillPower:1.07,makomGain:1.07,damageReduction:0.0,thirdHitBonus:0.05,critChance:0.04,attackRange:14,swapPulse:0.0,dashPulse:0.0,scene:"Ирода отключает магнитный контур на секунду, чтобы услышать тишину станции."}],
    ["tohir",{name:"Гидравлический упор",desc:"Заметно выше прочность; сильнее завершающий удар серии.",atkBonus:0.015,hpBonus:0.05,speedBonus:-5,skillPower:1.08,makomGain:1.02,damageReduction:0.065,thirdHitBonus:0.2,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Тохир сделал отметку роста на стойке пресса — рядом с отметкой учителя."}],
    ["dilorom",{name:"Связанный контур",desc:"МАКОМ и навык получают небольшой прирост.",atkBonus:0.02,hpBonus:0.01,speedBonus:2,skillPower:1.08,makomGain:1.12,damageReduction:0.0,thirdHitBonus:0.08,critChance:0.01,attackRange:8,swapPulse:0.0,dashPulse:0.0,scene:"Дилором оставила на кабеле три узла — по одному за каждого спасённого."}],
    ["iskandar",{name:"Ремонтный рой",desc:"Повышенная прочность и эффективность навыка лечения.",atkBonus:0.0,hpBonus:0.035,speedBonus:0,skillPower:1.14,makomGain:1.03,damageReduction:0.025,thirdHitBonus:0.02,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Искандар чинит маленького дрона, который каждый вечер возвращает ему отвёртку."}],
    ["sabr",{name:"Тепловой запас",desc:"Усиленный навык и повышенный урон базовой атаки.",atkBonus:0.035,hpBonus:0.0,speedBonus:0,skillPower:1.12,makomGain:1.03,damageReduction:0.0,thirdHitBonus:0.06,critChance:0.015,attackRange:4,swapPulse:0.0,dashPulse:0.0,scene:"Сабр выключает печь перед сном, хотя она давно работает автономно."}],
    ["kodir",{name:"Карьерный резонанс",desc:"Большая прочность и сильнее завершающий удар.",atkBonus:0.02,hpBonus:0.045,speedBonus:-6,skillPower:1.1,makomGain:1.02,damageReduction:0.04,thirdHitBonus:0.22,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Кодир помнит звук первого камня, который удалось поднять без взрыва."}],
    ["zebo",{name:"Линия разрыва",desc:"Критический шанс, скорость и рывковый урон выше.",atkBonus:0.04,hpBonus:0.0,speedBonus:9,skillPower:1.05,makomGain:1.04,damageReduction:0.0,thirdHitBonus:0.14,critChance:0.04,attackRange:0,swapPulse:0.0,dashPulse:0.12,scene:"Зебо оставляет на тренировочном манекене ровно одну тонкую линию."}],
    ["nargiza",{name:"Акустический след",desc:"Дальность и сбор МАКОМ увеличены.",atkBonus:0.02,hpBonus:0.0,speedBonus:3,skillPower:1.06,makomGain:1.16,damageReduction:0.0,thirdHitBonus:0.05,critChance:0.02,attackRange:18,swapPulse:0.0,dashPulse:0.0,scene:"Наргиза записывает звуки пустых куполов, чтобы однажды собрать из них мелодию."}],
    ["mirzo",{name:"Спектральная связка",desc:"Быстрая смена и третий удар дают дополнительный импульс.",atkBonus:0.025,hpBonus:0.0,speedBonus:7,skillPower:1.04,makomGain:1.08,damageReduction:0.0,thirdHitBonus:0.16,critChance:0.025,attackRange:0,swapPulse:0.08,dashPulse:0.05,scene:"Мирзо помнит последовательность движений, которую придумал вместе с сестрой."}],
    ["farhod",{name:"Дальний расчёт",desc:"Повышенный критический урон через шанс и дальность атаки.",atkBonus:0.04,hpBonus:0.0,speedBonus:-2,skillPower:1.08,makomGain:1.02,damageReduction:0.0,thirdHitBonus:0.04,critChance:0.055,attackRange:22,swapPulse:0.0,dashPulse:0.0,scene:"Фарход отмечает на стекле дистанции, с которых однажды спас отряд."}],
    ["nilufar",{name:"Контур заботы",desc:"Повышенная прочность и сила навыков поддержки.",atkBonus:0.0,hpBonus:0.045,speedBonus:0,skillPower:1.14,makomGain:1.04,damageReduction:0.035,thirdHitBonus:0.03,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Нилуфар хранит список тех, кому помогла, но не ставит рядом даты."}],
    ["shavkat",{name:"Импульсный шаг",desc:"Скорость и МАКОМ растут от точных серий.",atkBonus:0.025,hpBonus:0.0,speedBonus:12,skillPower:1.04,makomGain:1.12,damageReduction:0.0,thirdHitBonus:0.11,critChance:0.02,attackRange:0,swapPulse:0.0,dashPulse:0.08,scene:"Шавкат считает шаги между комнатами, чтобы не потерять темп."}],
    ["oibek",{name:"Слабое место",desc:"Критический шанс и эффективность навыка повышены.",atkBonus:0.035,hpBonus:0.0,speedBonus:0,skillPower:1.1,makomGain:1.04,damageReduction:0.0,thirdHitBonus:0.05,critChance:0.04,attackRange:10,swapPulse:0.0,dashPulse:0.0,scene:"Ойбек не записывает выводы, пока не найдёт хотя бы одно исключение."}],
    ["jasur",{name:"Адаптивная мутация",desc:"Повышенная атака и рывок наносит импульсный урон рядом.",atkBonus:0.045,hpBonus:0.025,speedBonus:5,skillPower:1.05,makomGain:1.03,damageReduction:0.0,thirdHitBonus:0.1,critChance:0.025,attackRange:0,swapPulse:0.0,dashPulse:0.15,scene:"Жасур просит не называть его форму мутацией — он считает её новой адаптацией."}],
    ["sherzod",{name:"Ответная траектория",desc:"Защита и завершающий удар серии усилены.",atkBonus:0.025,hpBonus:0.02,speedBonus:8,skillPower:1.04,makomGain:1.05,damageReduction:0.04,thirdHitBonus:0.2,critChance:0.015,attackRange:0,swapPulse:0.0,dashPulse:0.06,scene:"Шерзод хранит обломок стрелы, которой когда-то промахнулся."}],
    ["munisa",{name:"Споровое равновесие",desc:"Навык эффективнее, а прочность выше.",atkBonus:0.0,hpBonus:0.035,speedBonus:0,skillPower:1.13,makomGain:1.06,damageReduction:0.02,thirdHitBonus:0.03,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Му-ниса (в старой записи — Мун) дала имя каждому ростку в теплице."}],
    ["dilafruz",{name:"Ложная перспектива",desc:"Скорость, критический шанс и дальность повышены.",atkBonus:0.02,hpBonus:0.0,speedBonus:11,skillPower:1.05,makomGain:1.04,damageReduction:0.0,thirdHitBonus:0.06,critChance:0.03,attackRange:12,swapPulse:0.0,dashPulse:0.08,scene:"Дилафруз оставляет пустую проекцию на скамье, чтобы никто не сидел один."}],
    ["otabek",{name:"Векторный прорыв",desc:"Рывковый импульс и базовая скорость усилены.",atkBonus:0.03,hpBonus:0.0,speedBonus:13,skillPower:1.05,makomGain:1.06,damageReduction:0.0,thirdHitBonus:0.08,critChance:0.02,attackRange:0,swapPulse:0.0,dashPulse:0.14,scene:"Отабек записывает маршруты доставки даже тогда, когда дорог больше нет."}],
    ["yulduz",{name:"Общий ритм",desc:"МАКОМ заряжается быстрее; навыки эффективнее.",atkBonus:0.01,hpBonus:0.015,speedBonus:0,skillPower:1.09,makomGain:1.18,damageReduction:0.0,thirdHitBonus:0.06,critChance:0.01,attackRange:7,swapPulse:0.0,dashPulse:0.0,scene:"Юлдуз оставила незаконченный такт для тех, кто вернётся на станцию."}],
    ["akmal",{name:"Самонаведение",desc:"Дальность атаки и критический шанс выше.",atkBonus:0.035,hpBonus:0.0,speedBonus:3,skillPower:1.07,makomGain:1.04,damageReduction:0.0,thirdHitBonus:0.05,critChance:0.04,attackRange:16,swapPulse:0.0,dashPulse:0.0,scene:"Акмал помнит каждую стрелу, которую пришлось искать после испытаний."}],
    ["kamila",{name:"Копия с отличием",desc:"Сильнее навыки и МАКОМ; личное пробуждение даёт дополнительный бонус.",atkBonus:0.035,hpBonus:0.0,speedBonus:0,skillPower:1.12,makomGain:1.15,damageReduction:0.0,thirdHitBonus:0.08,critChance:0.02,attackRange:8,swapPulse:0.0,dashPulse:0.0,scene:"Камила хранит две копии одной записи и не считает ни одну из них подделкой."}],
    ["ulugbek7",{name:"Окно вероятности",desc:"Скорость навыков и точность повышены.",atkBonus:0.03,hpBonus:0.015,speedBonus:0,skillPower:1.14,makomGain:1.06,damageReduction:0.0,thirdHitBonus:0.05,critChance:0.03,attackRange:12,swapPulse:0.0,dashPulse:0.0,scene:"Улугбек-7 оставляет прогноз погоды на завтра, хотя небо давно не меняется."}],
    ["timur",{name:"Архивный заслон",desc:"Высокая прочность и устойчивость к урону.",atkBonus:0.01,hpBonus:0.055,speedBonus:-4,skillPower:1.06,makomGain:1.02,damageReduction:0.09,thirdHitBonus:0.06,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Тимур помнит приказ защищать двери, но теперь сам выбирает, кого впускать."}],
    ["rano",{name:"Глифовый прицел",desc:"Критический шанс и дальность серии выше.",atkBonus:0.03,hpBonus:0.0,speedBonus:2,skillPower:1.08,makomGain:1.06,damageReduction:0.0,thirdHitBonus:0.1,critChance:0.04,attackRange:15,swapPulse:0.0,dashPulse:0.0,scene:"Рано рисует новый символ для каждого человека, которого встречает."}],
    ["murod",{name:"Складка брони",desc:"Максимальная прочность и снижение урона.",atkBonus:0.0,hpBonus:0.06,speedBonus:-3,skillPower:1.05,makomGain:1.03,damageReduction:0.085,thirdHitBonus:0.08,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Мурод считает трещины на стене и называет каждую в честь пережитого дня."}],
    ["sevara",{name:"Стабильная точка",desc:"Критический шанс, дальность и третий удар усилены.",atkBonus:0.04,hpBonus:0.0,speedBonus:2,skillPower:1.07,makomGain:1.03,damageReduction:0.0,thirdHitBonus:0.16,critChance:0.05,attackRange:17,swapPulse:0.0,dashPulse:0.0,scene:"Севара оставила метку на тренировочном стенде: «не торопись с выводом»."}],
    ["anvar",{name:"Волна давления",desc:"Сильный навык и чуть больше устойчивости.",atkBonus:0.02,hpBonus:0.02,speedBonus:0,skillPower:1.13,makomGain:1.07,damageReduction:0.025,thirdHitBonus:0.1,critChance:0.015,attackRange:5,swapPulse:0.0,dashPulse:0.0,scene:"Анвар собирает тишину между словами, чтобы понять, что не было сказано."}],
    ["shakhnoza",{name:"Нейронный резерв",desc:"Прочность и эффективность навыков поддержки выше.",atkBonus:0.0,hpBonus:0.05,speedBonus:0,skillPower:1.15,makomGain:1.05,damageReduction:0.035,thirdHitBonus:0.03,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Шахноза хранит первое сообщение от пациента, который снова научился говорить."}],
    ["aziza",{name:"Рельсовый импульс",desc:"Дальность атаки и критический шанс повышены.",atkBonus:0.04,hpBonus:0.0,speedBonus:5,skillPower:1.08,makomGain:1.08,damageReduction:0.0,thirdHitBonus:0.08,critChance:0.045,attackRange:18,swapPulse:0.0,dashPulse:0.0,scene:"Азиза пересчитывает маршрут, чтобы в нём оставалось место для незапланированной остановки."}],
    ["firdavs",{name:"Тяжёлый разгон",desc:"Высокая атака, сильный третий удар и большая прочность.",atkBonus:0.05,hpBonus:0.025,speedBonus:-7,skillPower:1.1,makomGain:1.02,damageReduction:0.025,thirdHitBonus:0.24,critChance:0.01,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Фирдавс не выбрасывает сломанные детали: он хочет понять, где они устали."}],
    ["sardor",{name:"Якорная точка",desc:"Устойчивость и усиление контроля через навык.",atkBonus:0.015,hpBonus:0.04,speedBonus:-2,skillPower:1.12,makomGain:1.05,damageReduction:0.055,thirdHitBonus:0.1,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Сардор хранит старый корабельный узелок — память о маршруте, которого нет."}],
    ["madina",{name:"Полевой маяк",desc:"Прочность и навык поддержки усилены.",atkBonus:0.0,hpBonus:0.045,speedBonus:0,skillPower:1.14,makomGain:1.04,damageReduction:0.04,thirdHitBonus:0.03,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Мадина включает маленький маяк в жилом блоке перед каждым отдыхом."}],
    ["zafar",{name:"Двойной импульс",desc:"Скорость атаки через серию, критический шанс и скорость.",atkBonus:0.03,hpBonus:0.0,speedBonus:10,skillPower:1.05,makomGain:1.07,damageReduction:0.0,thirdHitBonus:0.12,critChance:0.035,attackRange:12,swapPulse:0.0,dashPulse:0.05,scene:"Зафар оставил один револьвер незаряженным — на случай, если придётся помочь."}],
    ["mohira",{name:"Автономная турель",desc:"Эффективность навыка и МАКОМ повышены.",atkBonus:0.02,hpBonus:0.015,speedBonus:0,skillPower:1.12,makomGain:1.12,damageReduction:0.0,thirdHitBonus:0.06,critChance:0.015,attackRange:6,swapPulse:0.0,dashPulse:0.0,scene:"Мохира дала своей турели право выключаться самой, когда работа закончена."}],
    ["nurali",{name:"Круговая защита",desc:"Сильная защита и прочность; медленнее перемещение.",atkBonus:0.0,hpBonus:0.06,speedBonus:-6,skillPower:1.08,makomGain:1.02,damageReduction:0.09,thirdHitBonus:0.13,critChance:0.0,attackRange:0,swapPulse:0.0,dashPulse:0.0,scene:"Нурали оставил на щите отметки всех дверей, которые удерживал."}],
    ["kamron",{name:"Курьерская связка",desc:"Высокая скорость, рывок и сбор МАКОМ.",atkBonus:0.025,hpBonus:0.0,speedBonus:15,skillPower:1.05,makomGain:1.14,damageReduction:0.0,thirdHitBonus:0.1,critChance:0.025,attackRange:0,swapPulse:0.0,dashPulse:0.12,scene:"Камрон помнит каждую доставку, которую успел завершить до отключения связи."}]
  ]);
  HEROES.forEach(h=>{h.passive=HERO_PASSIVES[h.id];});
  const SKILL_PATTERNS=['slash','pierce','ring','pull','trap','heal','shield','volley','turret','sonic','blink','mark','gravity','spores','chain','counter','burst','echo','dash','line','field','nova'];
  const ULT_PATTERNS=['nova','beam','meteor','guardian','summon','time','bloom','storm','execution','resonance','mirror'];
  const COMBO_STYLES=['ДУГА','ТОЧЕЧНАЯ СЕРИЯ','ТЯЖЁЛЫЙ ФИНИШ','ЦЕПНАЯ СВЯЗКА','РИТМ РЫВКА','КОНТРАТАКА','ШИРОКИЙ РАЗМАХ'];
  const COMBO_STYLE_DATA={
    'ДУГА':{range:12,dot:-.32,base:1.02,finish:.18,cooldown:1,knock:8,effect:'sweep'},
    'ТОЧЕЧНАЯ СЕРИЯ':{range:34,dot:.18,base:.94,finish:.34,cooldown:.92,crit:.075,knock:2,effect:'precision'},
    'ТЯЖЁЛЫЙ ФИНИШ':{range:-10,dot:-.12,base:.91,finish:.66,cooldown:1.14,knock:34,effect:'impact'},
    'ЦЕПНАЯ СВЯЗКА':{range:22,dot:-.12,base:.98,finish:.32,cooldown:1.02,knock:10,effect:'chain'},
    'РИТМ РЫВКА':{range:8,dot:-.28,base:1.04,finish:.29,cooldown:.82,knock:12,effect:'dash'},
    'КОНТРАТАКА':{range:2,dot:-.05,base:.97,finish:.3,cooldown:1.02,crit:.025,knock:24,effect:'counter'},
    'ШИРОКИЙ РАЗМАХ':{range:52,dot:-.68,base:.91,finish:.24,cooldown:1.08,knock:17,effect:'wide'}
  };
  HEROES.forEach((h,i)=>{
    const pattern=SKILL_PATTERNS[i%SKILL_PATTERNS.length],ult=ULT_PATTERNS[(i*3+Math.floor(i/7))%ULT_PATTERNS.length];
    h.combatKit={id:`KIT-${h.id.toUpperCase()}`,variant:i+1,skillPattern:pattern,ultPattern:ult,skillRadius:138+(i%6)*17+Math.floor(i/6)*3,skillPower:1.34+(i%7)*.115+(Math.floor(i/7)*.012),control:0.55+(i%5)*.22,ultRadius:205+(i%5)*26+Math.floor(i/5)*4,ultPower:3.65+(i%6)*.32+(Math.floor(i/6)*.025),comboStyle:COMBO_STYLES[i%COMBO_STYLES.length],comboBonus:.035+(i%6)*.018+(Math.floor(i/6)*.004),masteryAffinity:['Клинок','Копьё','Пистолет','Резонатор','Тяжёлое оружие','Биомеханика','Фокус'][i%7],signatureLine:`${h.skill} / ${h.ult}`,description:`Персональная конфигурация ${i+1}/44: ${pattern} → ${ult}; параметры управления и радиуса адаптированы к бойцу.`};
  });
  const OPERATIONS = [
    {id:'tashkent',name:'ТАШКЕНТ',title:'Город под стеклом',zone:'СЕКТОР 04',boss:'СМОТРИТЕЛЬ №09',bossStyle:'orbit',rank:'I',desc:'Старое метро, жилые кварталы и подземный узел Катта-Матрицы.',color:'#c8a66d',floor:'#131e19',wall:'#35463b',enemyPool:['drone','stalker','shooter','heavy','lurker'],unlockedBy:null},
    {id:'samarkand',name:'САМАРКАНД',title:'Небесный архив',zone:'ОБСЕРВАТОРИЯ 02',boss:'АТЛАС-НОЛЬ',bossStyle:'beam',rank:'II',desc:'Оптические башни и обсерватории, где гравитация подчиняется вычислениям.',color:'#a99ac7',floor:'#171923',wall:'#45425e',enemyPool:['disruptor','shooter','lurker','warden'],unlockedBy:'tashkent'},
    {id:'fergana',name:'ФЕРГАНА',title:'Живые заводы',zone:'БИОКОМПЛЕКС 07',boss:'МАТЬ-СПОРА',bossStyle:'spore',rank:'III',desc:'Биомеханические фабрики и органические системы, выросшие поверх машин.',color:'#8fb58d',floor:'#142019',wall:'#344d3b',enemyPool:['spore','stalker','warden','lurker'],unlockedBy:'samarkand'},
    {id:'aral',name:'ПРИАРАЛЬЕ',title:'Мёртвое море',zone:'СОЛЯНОЙ УЗЕЛ 12',boss:'СОЛЯНКА',bossStyle:'salt',rank:'IV',desc:'Корабли на песке, подземные резервуары и климатические лаборатории.',color:'#91aeb8',floor:'#192125',wall:'#45535a',enemyPool:['shooter','spore','disruptor','heavy'],unlockedBy:'fergana'},
    {id:'kyzylkum',name:'КЫЗЫЛКУМЫ',title:'Железный горизонт',zone:'ТРАНЗИТНАЯ ЛИНИЯ 09',boss:'ПОСЛЕДНИЙ ПРОВОДНИК',bossStyle:'charge',rank:'V',desc:'Передвижные промышленные титаны, бронепоезда и бесконечная пустынная линия.',color:'#d1a36c',floor:'#211b15',wall:'#53402e',enemyPool:['heavy','lurker','warden','disruptor'],unlockedBy:'aral'}
  ];
  const operationById = id => OPERATIONS.find(o=>o.id===id) || OPERATIONS[0];
  const operationUnlocked = op => !op.unlockedBy || (save.clearedRegions||[]).includes(op.unlockedBy);

  // v0.4: a 15-chapter campaign layered over the five regional operations.
  const FACTION_BY_REGION = {
    tashkent:'Кызылкумский синдикат', samarkand:'Академия звёздного неба',
    fergana:'Дети Оазиса', aral:'Архив «Седьмой Порог»', kyzylkum:'Караван «Соль-9»'
  };
  const FACTION_DETAILS = [
    {name:'Кызылкумский синдикат',mark:'⚒',motto:'Сохранить ремесло, пока металл помнит форму.',desc:'Инженеры, ремонтники и рабочие автономных промышленных узлов.'},
    {name:'Академия звёздного неба',mark:'⌖',motto:'Измерить неизвестное, не присваивая его.',desc:'Астрономы и вычислители, изучающие сигналы над и под горизонтом.'},
    {name:'Дети Оазиса',mark:'✿',motto:'Жизнь не обязана повторять прежнюю форму.',desc:'Биомеханики и хранители новых экосистем Ферганской долины.'},
    {name:'Архив «Седьмой Порог»',mark:'▤',motto:'Память сохраняют, а не подчиняют.',desc:'Архивисты, исследующие границу между записью и личностью.'},
    {name:'Караван «Соль-9»',mark:'⇢',motto:'Дорога существует, пока кто-то её проходит.',desc:'Кочующая сеть транспортников, связистов и жителей сухих регионов.'}
  ];
  const CAMPAIGN = {
    tashkent:[
      {title:'Смена, которой не было',brief:'В диспетчерской метро табло продолжает вызывать сотрудников на смену, назначенную спустя тридцать лет после Тишины. Среди имён появляется позывной Айлы.',objective:'Зачистить диспетчерский зал и извлечь журнал смен.',a:'Сохранить журнал целиком',b:'Передать рабочие данные ремонтникам',fa:'Архив «Седьмой Порог»',fb:'Кызылкумский синдикат'},
      {title:'Наследие под платформой',brief:'Под закрытой платформой обнаружен узел, который питает не город, а неизвестный объект за пределами карты. Его защита реагирует на человеческие голоса.',objective:'Отключить три защитных узла и удержать проход.',a:'Не прерывать голосовой цикл',b:'Отключить источник сигнала',fa:'Архив «Седьмой Порог»',fb:'Академия звёздного неба'},
      {title:'Смотритель: право на приказ',brief:'Смотритель №09 считает, что эвакуация людей всё ещё продолжается. Его последняя команда требует закрыть сектор вместе с теми, кто внутри.',objective:'Победить Смотрителя №09 и решить судьбу протокола.',a:'Оставить протокол на хранение',b:'Передать управление жителям станции',fa:'Архив «Седьмой Порог»',fb:'Кызылкумский синдикат'}
    ],
    samarkand:[
      {title:'Небо внутри колодца',brief:'Зеркальная площадка Академии отражает созвездие, которого нет на небе. Координаты ведут в шахту под обсерваторией.',objective:'Защитить зеркальный вычислитель во время сканирования.',a:'Сохранить исходные координаты',b:'Пересчитать карту по новым данным',fa:'Академия звёздного неба',fb:'Караван «Соль-9»'},
      {title:'Наблюдатель без глаз',brief:'В глубине башни работает оптический интеллект. Он видит движение света, но не различает людей и машины.',objective:'Пройти через оптические турели и отключить наблюдателя.',a:'Попытаться обучить систему',b:'Изолировать её от сети',fa:'Академия звёздного неба',fb:'Дети Оазиса'},
      {title:'Атлас-Ноль: последний расчёт',brief:'Атлас-Ноль вычислил десятки вариантов будущего, но каждый заканчивается исчезновением одного из городов. Он защищает расчёт как единственную истину.',objective:'Остановить Атлас-Ноль и забрать ядро прогноза.',a:'Сохранить все варианты будущего',b:'Удалить прогноз и оставить выбор живым',fa:'Академия звёздного неба',fb:'Архив «Седьмой Порог»'}
    ],
    fergana:[
      {title:'Пульс в трубе',brief:'В старых трубах биокомплекса слышен ритм, совпадающий с сигналом станции. Это не команда и не авария — система пытается сообщить о боли.',objective:'Разрушить заражённые узлы, не повредив центральный контур.',a:'Сохранить биологический сигнал',b:'Отключить опасные ветви',fa:'Дети Оазиса',fb:'Кызылкумский синдикат'},
      {title:'Сад, который помнит',brief:'Растения повторяют жесты пропавших сотрудников. Зумрад находит в их тканях химический след, связанный с архивом НАСЛЕДИЕ.',objective:'Защитить живой образец от машин-сборщиков.',a:'Передать образец биологам',b:'Сохранить его в закрытом контейнере',fa:'Дети Оазиса',fb:'Архив «Седьмой Порог»'},
      {title:'Мать-Спора: предел жизни',brief:'Мать-Спора не считает себя оружием. Она защищает колонию, потому что старый протокол назвал всех внешних существ угрозой.',objective:'Победить Мать-Спору и сохранить безопасное ядро.',a:'Оставить колонию под наблюдением',b:'Забрать ядро на станцию',fa:'Дети Оазиса',fb:'Кызылкумский синдикат'}
    ],
    aral:[
      {title:'Линия отступившей воды',brief:'Станция водомеров показывает уровень моря, который не совпадает ни с одной исторической отметкой. Под соляной коркой обнаружен работающий насос.',objective:'Остановить охранные машины насосной станции.',a:'Восстановить подачу воды',b:'Сначала изучить состав жидкости',fa:'Караван «Соль-9»',fb:'Архив «Седьмой Порог»'},
      {title:'Соль на магнитной ленте',brief:'В лаборатории найден архив голосов с кораблей, исчезнувших в ночь Тишины. Некоторые записи продолжаются после обрыва питания.',objective:'Удержать архивный зал и собрать уцелевшие записи.',a:'Вернуть голоса в общий архив',b:'Оставить записи семьям каравана',fa:'Архив «Седьмой Порог»',fb:'Караван «Соль-9»'},
      {title:'Солянка: карта глубины',brief:'Солянка управляет резервуарами и считает, что любое движение воды должно быть остановлено. Её карта скрывает путь к северному транзитному маршруту.',objective:'Победить Солянку и открыть карту глубины.',a:'Сохранить систему водного баланса',b:'Передать резервуары свободным поселениям',fa:'Архив «Седьмой Порог»',fb:'Караван «Соль-9»'}
    ],
    kyzylkum:[
      {title:'Состав без расписания',brief:'По пустынной линии движется состав, отсутствующий в манифестах Соль-9. В каждом вагоне включён свет, хотя пассажиров не видно.',objective:'Остановить охранный конвой и добраться до локомотива.',a:'Не вскрывать пассажирские капсулы',b:'Проверить каждую капсулу',fa:'Караван «Соль-9»',fb:'Архив «Седьмой Порог»'},
      {title:'Пассажир из будущего',brief:'Навигационный робот называет дату прибытия, которая ещё не наступила. Он ждёт одного человека и отказывается объяснять, откуда знает его имя.',objective:'Защитить навигационный блок и получить маршрут.',a:'Довериться маршруту робота',b:'Сверить путь с картами Академии',fa:'Караван «Соль-9»',fb:'Академия звёздного неба'},
      {title:'Последний Проводник',brief:'Проводник — не просто машина. Он соединяет все пять региональных узлов и считает себя единственным, кто помнит первоначальную цель Матрицы.',objective:'Победить Последнего Проводника и завершить первый цикл кампании.',a:'Сохранить ядро Матрицы',b:'Разделить сеть между регионами',fa:'Архив «Седьмой Порог»',fb:'Караван «Соль-9»'}
    ]
  };
  const factionFor = region => FACTION_BY_REGION[region] || 'Караван «Соль-9»';

  const ROUTE_CHOICES = {
    tashkent:[['memory','freedom'],['memory','truth'],['memory','freedom']],
    samarkand:[['truth','memory'],['truth','freedom'],['truth','freedom']],
    fergana:[['freedom','truth'],['freedom','memory'],['freedom','memory']],
    aral:[['freedom','truth'],['memory','freedom'],['truth','freedom']],
    kyzylkum:[['memory','truth'],['freedom','truth'],['memory','freedom']]
  };
  const ROUTE_INFO = {
    memory:{name:'ЭХО ПАМЯТИ',desc:'Архивные системы и энергетические следы поддерживают отряд.',atkBonus:0, speedBonus:0, hpBonus:45, damageReduction:.015, makomGain:1.13},
    freedom:{name:'ОТКРЫТЫЙ ГОРИЗОНТ',desc:'Автономные поселения и свобода решений ускоряют оперативников.',atkBonus:0, speedBonus:13, hpBonus:0, damageReduction:0, makomGain:1.04},
    truth:{name:'НЕЗАВИСИМАЯ МАТРИЦА',desc:'Раскрытые протоколы усиливают атакующие системы.',atkBonus:.055, speedBonus:0, hpBonus:0, damageReduction:0, makomGain:1.04},
    balanced:{name:'ТИХИЙ РАССВЕТ',desc:'Согласие регионов создаёт устойчивый общий контур.',atkBonus:.025, speedBonus:5, hpBonus:70, damageReduction:.025, makomGain:1.08}
  };
  function routeForDecision(region,chapter,choice){return ROUTE_CHOICES[region]?.[chapter-1]?.[choice==='b'?1:0]||'memory';}
  function getRouteAura(){
    const s=save.routeScores||{memory:0,freedom:0,truth:0};
    const vals=['memory','freedom','truth'].map(k=>[k,s[k]||0]).sort((a,b)=>b[1]-a[1]);
    if(vals[0][1]===0 || vals[0][1]===vals[1][1])return {id:'balanced',...ROUTE_INFO.balanced};
    return {id:vals[0][0],...ROUTE_INFO[vals[0][0]]};
  }
  // Regional faction resonance: reputation now changes the active squad's combat profile.
  function getFactionResonance(){
    const name=FACTION_BY_REGION[save.selectedRegion]||'Караван «Соль-9»';
    const rep=clamp(save.factionRep?.[name]||0,0,10),tier=rep>=10?3:rep>=6?2:rep>=3?1:0;
    const bonuses={
      'Кызылкумский синдикат':{atkBonus:[0,.025,.05,.075],desc:'Синдикатская калибровка усиливает прямой урон.'},
      'Академия звёздного неба':{critChance:[0,.015,.03,.045],skillPower:[1,1.035,1.07,1.11],desc:'Академические расчёты повышают точность и силу навыков.'},
      'Дети Оазиса':{hpBonus:[0,.025,.05,.075],damageReduction:[0,.012,.024,.04],desc:'Биоконтур Оазиса укрепляет корпус и смягчает входящий урон.'},
      'Архив «Седьмой Порог»':{makomGain:[1,1.05,1.1,1.16],damageReduction:[0,.006,.014,.024],desc:'Архивная синхронизация быстрее накапливает МАКОМ.'},
      'Караван «Соль-9»':{speedBonus:[0,4,8,13],atkBonus:[0,.008,.016,.025],desc:'Маршрутные алгоритмы Соль-9 повышают мобильность.'}
    }[name]||{};
    return {name,rep,tier,desc:tier?bonuses.desc:'Репутация от 3 очков откроет региональный боевой резонанс.',atkBonus:bonuses.atkBonus?.[tier]||0,hpBonus:bonuses.hpBonus?.[tier]||0,speedBonus:bonuses.speedBonus?.[tier]||0,critChance:bonuses.critChance?.[tier]||0,skillPower:bonuses.skillPower?.[tier]||1,makomGain:bonuses.makomGain?.[tier]||1,damageReduction:bonuses.damageReduction?.[tier]||0};
  }
  const WORLD_BRANCH_DATA={
    tashkent:[
      {a:{flag:'tashkent_archive_kept',short:'архив диспетчерской открыт жителям',atkBonus:0,hpFlat:24,makomGain:1.025,text:'Архив открыт жителям: станция получает дополнительные сигналы и запас прочности.'},b:{flag:'tashkent_repair_line',short:'ремонтная линия снова работает',atkBonus:.03,speedBonus:5,text:'Ремонтная линия восстановлена: отряд получает калибровку атаки и скорости.'}},
      {a:{flag:'tashkent_voice_loop',short:'голосовой цикл сохранён',critChance:.02,skillPower:1.03,text:'Голосовой цикл сохранён: навыки точнее и сильнее.'},b:{flag:'tashkent_signal_cut',short:'опасный сигнал изолирован',damageReduction:.035,text:'Опасный сигнал изолирован: защита отряда усилена.'}},
      {a:{flag:'tashkent_protocol_archived',short:'протокол Смотрителя помещён в архив',skillPower:1.035,makomGain:1.025,text:'Протокол помещён в архив: усилена синхронизация МАКОМ и навыков.'},b:{flag:'tashkent_citizen_control',short:'управление передано жителям станции',atkBonus:.025,speedBonus:3,text:'Управление передано жителям: отряд действует решительнее и быстрее.'}}
    ],
    samarkand:[
      {a:{flag:'samarkand_coordinates_kept',short:'исходные координаты сохранены',skillPower:1.035,text:'Исходные координаты сохранены: оптическая калибровка усиливает навыки.'},b:{flag:'samarkand_map_recalculated',short:'карта пересчитана по новым данным',critChance:.03,text:'Карта пересчитана: расчёты повышают критическую точность.'}},
      {a:{flag:'samarkand_optics_trained',short:'оптический интеллект обучен',skillPower:1.025,critChance:.02,text:'Оптический интеллект обучен: улучшены наведение и контроль.'},b:{flag:'samarkand_optics_isolated',short:'оптический интеллект изолирован',damageReduction:.04,text:'Оптический интеллект изолирован: защитные протоколы усилены.'}},
      {a:{flag:'samarkand_future_saved',short:'варианты будущего сохранены',critChance:.025,skillPower:1.025,text:'Варианты будущего сохранены: прицеливание и навыки стали точнее.'},b:{flag:'samarkand_forecast_erased',short:'прогноз удалён, выбор оставлен живым',speedBonus:7,text:'Прогноз удалён: автономные маршруты ускоряют перемещение.'}}
    ],
    fergana:[
      {a:{flag:'fergana_living_signal',short:'биологический сигнал сохранён',hpBonus:.035,damageReduction:.015,text:'Биологический сигнал сохранён: биоконтур усиливает прочность.'},b:{flag:'fergana_dangerous_branches_cut',short:'опасные ветви отключены',atkBonus:.035,text:'Опасные ветви отключены: высвобождённая энергия усиливает атаку.'}},
      {a:{flag:'fergana_living_seed',short:'живой образец передан биологам',hpBonus:.04,skillPower:1.02,text:'Живой образец сохранён: биологическая адаптация повышает прочность.'},b:{flag:'fergana_containment',short:'образец оставлен в контейнере',damageReduction:.035,text:'Образец изолирован: защитный контур стал устойчивее.'}},
      {a:{flag:'fergana_colony_monitored',short:'колония оставлена под наблюдением',hpBonus:.03,damageReduction:.02,text:'Колония развивается автономно: прочность и защита отряда увеличены.'},b:{flag:'fergana_core_taken',short:'ядро доставлено на станцию',atkBonus:.045,text:'Ядро доставлено на станцию: его энергия усиливает атаку.'}}
    ],
    aral:[
      {a:{flag:'aral_water_restored',short:'подача воды восстановлена',hpBonus:.045,text:'Насосная работает: отряд получает поддержку поселений и дополнительную прочность.'},b:{flag:'aral_water_studied',short:'состав воды отправлен на анализ',skillPower:1.025,makomGain:1.025,text:'Состав воды изучен: аналитический контур усиливает навыки и МАКОМ.'}},
      {a:{flag:'aral_shared_archive',short:'голоса возвращены в общий архив',makomGain:1.045,text:'Голоса возвращены в архив: общий ритм быстрее накапливает МАКОМ.'},b:{flag:'aral_family_archive',short:'записи переданы семьям каравана',damageReduction:.035,text:'Записи переданы семьям: взаимная поддержка укрепляет защиту.'}},
      {a:{flag:'aral_water_balance',short:'система водного баланса сохранена',hpBonus:.035,damageReduction:.015,text:'Баланс воды сохранён: увеличены прочность и сопротивление урону.'},b:{flag:'aral_free_reservoirs',short:'резервуары переданы поселениям',speedBonus:7,text:'Резервуары переданы поселениям: свободные маршруты повышают скорость.'}}
    ],
    kyzylkum:[
      {a:{flag:'kyzylkum_capsules_sealed',short:'пассажирские капсулы оставлены закрытыми',damageReduction:.035,text:'Капсулы остаются закрытыми до проверки: защитные протоколы усилены.'},b:{flag:'kyzylkum_capsules_opened',short:'пассажирские капсулы вскрыты',critChance:.03,text:'Капсулы вскрыты: данные состава улучшают критическое наведение.'}},
      {a:{flag:'kyzylkum_robot_trusted',short:'маршрут навигационного робота принят',speedBonus:6,critChance:.015,text:'Маршрут робота принят: навигация ускоряет отряд и повышает точность.'},b:{flag:'kyzylkum_route_crosschecked',short:'путь сверен с картами Академии',atkBonus:.03,text:'Маршрут сверен: калибровка Академии усиливает атаку.'}},
      {a:{flag:'kyzylkum_matrix_core',short:'ядро Матрицы сохранено',atkBonus:.02,skillPower:1.025,text:'Ядро сохранено: его управляемая энергия усиливает атаку и навыки.'},b:{flag:'kyzylkum_network_shared',short:'сеть разделена между регионами',hpBonus:.035,damageReduction:.02,text:'Сеть распределена: региональная взаимопомощь укрепляет отряд.'}}
    ]
  };
  function applyCampaignConsequence(region,chapter,choice){
    const key=`${region}_${chapter}`,flag=`branch:${key}:${choice}`,entry=WORLD_BRANCH_DATA[region]?.[chapter-1]?.[choice];
    if(!save.worldFlags.includes(flag))save.worldFlags.push(flag);
    if(entry?.flag&&!save.worldFlags.includes(entry.flag))save.worldFlags.push(entry.flag);
    save.exploreLog.unshift(`${operationById(region).name}: ${entry?.text||'регион изменил протокол после сюжетного решения'}`);save.exploreLog=save.exploreLog.slice(0,15);
  }
  function regionConsequenceSummary(region){
    const entries=CAMPAIGN[region]||[];return entries.map((chapter,i)=>{const choice=save.campaignChoices[`${region}_${i+1}`];if(!choice)return '';const entry=WORLD_BRANCH_DATA[region]?.[i]?.[choice];return `ГЛАВА ${i+1}: ${entry?.text||entry?.short||chapter.title}`;}).filter(Boolean).join(' ');
  }
  function getWorldConsequenceAura(region=save.selectedRegion){
    const aura={atkBonus:0,hpFlat:0,hpBonus:0,speedBonus:0,damageReduction:0,skillPower:1,critChance:0,makomGain:1};
    (CAMPAIGN[region]||[]).forEach((chapter,i)=>{const choice=save.campaignChoices[`${region}_${i+1}`],e=choice&&WORLD_BRANCH_DATA[region]?.[i]?.[choice];if(!e)return;aura.atkBonus+=e.atkBonus||0;aura.hpFlat+=e.hpFlat||0;aura.hpBonus+=e.hpBonus||0;aura.speedBonus+=e.speedBonus||0;aura.damageReduction+=e.damageReduction||0;aura.skillPower*=e.skillPower||1;aura.critChance+=e.critChance||0;aura.makomGain*=e.makomGain||1;});
    aura.atkBonus=clamp(aura.atkBonus,0,.12);aura.hpBonus=clamp(aura.hpBonus,0,.12);aura.damageReduction=clamp(aura.damageReduction,0,.12);aura.skillPower=Math.min(1.12,aura.skillPower);aura.critChance=clamp(aura.critChance,0,.1);aura.makomGain=Math.min(1.15,aura.makomGain);return aura;
  }
  function evaluateMainEnding(){
    if(!OPERATIONS.every(op=>(save.campaignProgress[op.id]||0)>=3))return null;
    if(save.mainEnding)return null;
    const scores=save.routeScores||{};const vals=['memory','freedom','truth'].map(k=>[k,scores[k]||0]).sort((a,b)=>b[1]-a[1]);
    const id=(vals[0][1]===vals[1][1])?'balanced':vals[0][0];
    const endings={
      memory:{title:'ЭХО ОВОЗ',text:'Архивы остаются открытыми. Память погибших больше не принадлежит центральной системе: регионы создают общий, добровольный архив.'},
      freedom:{title:'ОТКРЫТЫЙ ГОРИЗОНТ',text:'Региональные узлы получают автономию. Матрица перестаёт отдавать приказы и становится сетью, которой можно пользоваться или которую можно покинуть.'},
      truth:{title:'МАТРИЦА БЕЗ МАСКИ',text:'Скрытый протокол раскрыт. Люди и автономные существа узнают цену Тишины и получают право самим решать, что строить дальше.'},
      balanced:{title:'ТИХИЙ РАССВЕТ',text:'Ни один протокол не получает абсолютной власти. Пять регионов заключают соглашение: помнить, исследовать и оставаться свободными одновременно.'}
    };
    save.mainEnding={id,title:endings[id].title,text:endings[id].text,score:{...scores}};
    save.archiveFlags.push(`ending:${id}`);save.credits+=1800;save.signal+=400;save.alloy+=12;
    return save.mainEnding;
  }

  // New v0.3 content: living base, personal stories, side operations and non-combat exploration.
  const STATION_ROOMS = [
    {id:'hangar',name:'АНГАР',sub:'Ремонтный док',icon:'⌁',desc:'Здесь обслуживают транспорт, дронов и полевые экзокостюмы.',action:'Проверить оборудование',effect:'После проверки команда получает полевые данные.'},
    {id:'quarters',name:'ЖИЛОЙ БЛОК',sub:'Комната отдыха',icon:'⌂',desc:'Тихая часть станции. Здесь оперативники могут поговорить без боевой тревоги.',action:'Отдохнуть и поговорить',effect:'Отдых активирует небольшой запас прочности для следующей операции.'},
    {id:'workshop',name:'МАСТЕРСКАЯ',sub:'Сборочный отсек',icon:'⚒',desc:'Верстаки, инструменты и детали старой Матрицы.',action:'Перебрать детали',effect:'Первая проверка приносит сплавы для изготовления снаряжения.'},
    {id:'archive',name:'АРХИВ',sub:'Хранилище памяти',icon:'▤',desc:'Здесь хранятся записи, которые удалось спасти из повреждённых узлов.',action:'Синхронизировать записи',effect:'Архив выдаёт сигнальные коды и открывает детали историй.'},
    {id:'greenhouse',name:'БИОТЕПЛИЦА',sub:'Контур НАВДА',icon:'✿',desc:'Небольшая зона, где Зумрад и Лайло выращивают устойчивые биоматериалы.',action:'Собрать биополимер',effect:'Даёт сплавы и материалы для модулей.',production:'alloy'},
    {id:'observatory',name:'СМОТРОВАЯ',sub:'Сканирующая башня',icon:'⌖',desc:'Старый оптический комплекс, направленный на пустынные маршруты.',action:'Просканировать горизонт',effect:'Открывает дополнительную точку разведки в выбранном регионе.',production:'signal'},
    {id:'comms',name:'РАДИОРУБКА',sub:'Узел дальней связи',icon:'⌁',desc:'Здесь диспетчеры восстанавливают маршруты между поселениями и слушают сигналы, которые не проходят через Матрицу.',action:'Сверить региональные частоты',effect:'Открывает маршрутные данные и накапливает сигнальные коды.',production:'signal'},
    {id:'mess',name:'ОБЩАЯ КУХНЯ',sub:'Пункт снабжения',icon:'◇',desc:'Небольшая кухня и склад. Здесь команда распределяет припасы и обсуждает вылазки без командных протоколов.',action:'Подготовить общий паёк',effect:'Повышает запас прочности отряда и создаёт ресурсный резерв.',production:'credits'}
  ];
  const STATION_DIALOGUES = {
    ayla:['Я не помню, кто записал эту мелодию. Но каждый раз узнаю её с первой ноты.','Станция кажется знакомой. Возможно, это не воспоминание, а привычка.'],
    rustam:['Если вернуть питание на этот контур, подъёмник ещё послужит людям.','Я не люблю выбрасывать исправные детали. Даже если они старше меня.'],
    saodat:['Здесь можно увидеть не звёзды, а их задержавшиеся сигналы.','Любая точная модель начинается с признания того, чего мы не знаем.'],
    zumrad:['Даже в бетонной трещине может найтись место для корня.','Не всё живое просит, чтобы его спасали. Иногда ему нужно не мешать.'],
    malika:['Я не обещаю, что вернусь целой. Обещаю, что вернусь.','Тишина не делает нас слабее. Она просто проверяет, что мы готовы защищать.'],
    default:['Станция стала немного тише. Это хороший знак.','У нас ещё есть работа. Значит, есть и причина оставаться.']
  };
  const PERSONAL_STORIES = [
    {id:'ayla_memory',hero:'ayla',title:'Кассета, которой не было',region:'tashkent',chapters:[
      {title:'Голос на плёнке',text:'В архивном отсеке Айла находит кассету с записью, датированной за три года до её производства. На записи кто-то произносит её позывной и напевает незнакомую мелодию.',a:'Сохранить запись целиком',b:'Сначала проверить метаданные',reward:360},
      {title:'Чужое воспоминание',text:'При воспроизведении кассеты Айла видит фрагмент детской комнаты. В памяти появляется запах пыли и звук дождя — данные, которых в её сенсорах быть не может.',a:'Признать воспоминание своим',b:'Оставить источник неизвестным',reward:420}
    ]},
    {id:'rustam_story',hero:'rustam',title:'Последняя смена мастера',region:'tashkent',chapters:[
      {title:'Станок номер шесть',text:'Рустам узнаёт старую маркировку на детали из метро. Когда-то этот станок принадлежал его наставнику, который не вышел из цеха в ночь Тишины.',a:'Восстановить станок',b:'Забрать журнал смены',reward:350},
      {title:'Работа не закончена',text:'В журнале обнаружена инструкция по ремонту автономного подъёмника. Последняя строка написана рукой наставника: «Не бросай машину, пока она ещё может кому-то помочь».',a:'Следовать инструкции',b:'Сохранить журнал для архива',reward:430}
    ]},
    {id:'saodat_story',hero:'saodat',title:'Небо в вычислительной пыли',region:'samarkand',chapters:[
      {title:'Неправильная звезда',text:'Саодат обнаруживает в обсерватории координату объекта, которого нет ни в одном каталоге. Сигнал приходит не из космоса, а из-под земли.',a:'Направить телескоп на координату',b:'Сравнить старые каталоги',reward:390},
      {title:'Точка под горизонтом',text:'Координата совпадает с закрытым входом в подземный архив. Расчёты показывают, что объект посылал сигнал ещё до катастрофы.',a:'Передать координату команде',b:'Скрыть её до проверки',reward:440}
    ]},
    {id:'zumrad_story',hero:'zumrad',title:'Сад без корней',region:'fergana',chapters:[
      {title:'Теплица на глубине',text:'Зумрад находит биологическую систему, которая продолжает выращивать растения без света. Её центральный модуль хранит отпечатки голосов прежних сотрудников.',a:'Оставить растения живыми',b:'Отключить опасный модуль',reward:390},
      {title:'Кому принадлежит росток',text:'Среди растений обнаруживается росток, выращенный из образца, который Зумрад когда-то считала потерянным. Он реагирует на её биомеханическую руку.',a:'Забрать образец на станцию',b:'Оставить его в естественной среде',reward:450}
    ]},
    {id:'malika_story',hero:'malika',title:'Красная линия',region:'kyzylkum',chapters:[
      {title:'Сигнал с карьера',text:'Малика получает сообщение от старого напарника, пропавшего во время зачистки шахт. Сигнал повторяет только одну фразу: «Я не ушёл».',a:'Идти по сигналу',b:'Сначала запросить данные Синдиката',reward:420},
      {title:'Не оставлять своих',text:'В заброшенном карьере работает автоматический ремонтный комплекс. Он использует голос напарника как команду и не понимает, что тот давно погиб.',a:'Отключить запись бережно',b:'Сохранить голосовой архив',reward:470}
    ]},
    {id:'kamila_story',hero:'kamila',title:'Нить, ведущая назад',region:'aral',chapters:[
      {title:'Архивный узел',text:'Камила обнаруживает копию собственной памяти в соляной лаборатории. В записи она принимает решение, которого не помнит.',a:'Открыть полную запись',b:'Сначала создать резервную копию',reward:420},
      {title:'Два одинаковых ответа',text:'Запись показывает, что Камила однажды помогла эвакуировать людей, а затем стёрла этот эпизод. Она не знает, была ли это её воля или команда извне.',a:'Принять обе версии прошлого',b:'Оставить вопрос открытым',reward:470}
    ]},
    {id:'laylo_story',hero:'laylo',title:'Тихая эволюция',region:'fergana',chapters:[
      {title:'Симбиот',text:'Лайло встречает биомеханическое существо, которое не атакует, а повторяет движения её руки. Его ткани содержат следы старого исследовательского протокола.',a:'Попробовать контакт',b:'Поставить защитный барьер',reward:380},
      {title:'Своя форма',text:'Существо постепенно копирует не оружие, а жест приветствия. Лайло понимает, что перед ней не экспериментальный образец, а новая форма жизни.',a:'Защитить существо',b:'Передать его на изучение',reward:460}
    ]},
    {id:'aziza_story',hero:'aziza',title:'Маршрут без станции',region:'kyzylkum',chapters:[
      {title:'Пустая платформа',text:'Азиза находит маршрут бронепоезда, который не существует на картах Соль-9. Поезд продолжает идти по линии, ведущей в закрытую шахту.',a:'Остановить поезд',b:'Проследовать за ним',reward:420},
      {title:'Последний пассажир',text:'В вагоне работает старый сервисный робот. Он хранит билеты людей, которые должны были прибыть в безопасный город, но так и не получили шанс.',a:'Сохранить билеты',b:'Передать записи каравану',reward:470}
    ]}
  ];

  const PERSONAL_FINAL_CHAPTERS = {
    ayla_memory:{title:'Мелодия без владельца',text:'На третьей записи слышна та же мелодия, но теперь она заканчивается новым тактом. Айла понимает: запись не предсказывала её жизнь — кто-то оставил ей возможность выбрать, что делать с памятью.',a:'Вписать своё имя в архив',b:'Оставить запись без автора',reward:620},
    rustam_story:{title:'Станок снова работает',text:'Подъёмник запускается, но его первый цикл не поднимает груз — он открывает дверь в мастерскую, где инструменты наставника разложены так, словно смена закончилась вчера.',a:'Продолжить дело мастера',b:'Передать мастерскую новому поколению',reward:640},
    saodat_story:{title:'Созвездие под землёй',text:'Саодат находит источник сигнала: это карта людей, которые когда-то прокладывали безопасные маршруты между регионами. Звёзды на карте — не небесные тела, а точки связи.',a:'Опубликовать координаты',b:'Сначала проверить каждый маршрут',reward:660},
    zumrad_story:{title:'Первый самостоятельный рост',text:'Растение раскрывает новый лист без внешнего питания. Зумрад отключает наблюдение и впервые позволяет экосистеме развиваться без постоянной оценки.',a:'Дать системе свободу',b:'Сохранить осторожный контроль',reward:660},
    malika_story:{title:'Имя на клинке',text:'Малика обнаруживает резервную копию голоса напарника. В ней нет просьбы о мести — только напоминание не превращать память в приказ.',a:'Сохранить голос и двигаться дальше',b:'Оставить архив напарника семье',reward:700},
    kamila_story:{title:'Нить становится своей',text:'Камила соединяет две версии воспоминаний и обнаруживает третью — ту, которую создала сама после пробуждения. Теперь она может не выбирать между копиями.',a:'Собрать единый архив',b:'Оставить обе версии рядом',reward:700},
    laylo_story:{title:'Тихая форма жизни',text:'Существо покидает лабораторный контейнер и самостоятельно выбирает место у теплицы. Лайло понимает, что доверие — тоже форма защиты.',a:'Открыть новый биоконтур',b:'Наблюдать, не вмешиваясь',reward:680},
    aziza_story:{title:'Маршрут, который выбрали',text:'Сервисный робот передаёт Азизе последний билет — без имени и даты. Она прикрепляет его к карте, чтобы у будущего пути было место для тех, кто ещё не родился.',a:'Оставить билет на станции',b:'Передать его каравану',reward:700}
  };
  PERSONAL_STORIES.forEach(st=>{if(PERSONAL_FINAL_CHAPTERS[st.id])st.chapters.push(PERSONAL_FINAL_CHAPTERS[st.id]);});
  const PERSONAL_DEEP_CHAPTERS={
    ayla_memory:[
      {title:'Комната до рождения',text:'Айла получает координату комнаты, которой нет ни в одном плане метро. Там найден не человек, а пустая кассета с незаписанным будущим.',a:'Записать собственную мелодию',b:'Оставить плёнку пустой',reward:760,mission:true},
      {title:'Право на собственную память',text:'В архиве обнаружен протокол, который мог создавать воспоминания для андроидов. Айла должна решить, считать ли искусственное происхождение воспоминания причиной отказаться от него.',a:'Принять память как свою',b:'Сохранить историю происхождения',reward:900,mission:true}
    ],
    rustam_story:[
      {title:'Инструмент наставника',text:'На закрытом складе Рустам находит набор инструментов, каждый из которых помнит последнюю задачу мастера. Один механизм всё ещё ждёт ремонта.',a:'Закончить последнюю работу',b:'Передать набор ученикам',reward:760,mission:true},
      {title:'Смена продолжается',text:'Подъёмник соединяет станцию с поселением, которое не отвечало десятилетиями. Внутри ждут не машины, а люди, сохранившие старую систему водоснабжения.',a:'Восстановить связь с поселением',b:'Сначала проверить безопасность узла',reward:920,mission:true}
    ],
    saodat_story:[
      {title:'Наблюдатель на глубине',text:'Саодат понимает, что сигналы Академии — это отражения от огромной подземной антенны. Её расчёт впервые не может предсказать ответ.',a:'Передать данные всем регионам',b:'Оставить координаты исследователям',reward:780,mission:true},
      {title:'Звёзды, которых нет',text:'В последнем архиве нет ни одной карты неба. Есть только маршруты людей, которые выбирали путь, не зная исхода.',a:'Сохранить карту как открытую',b:'Добавить к ней вероятности',reward:940,mission:true}
    ],
    zumrad_story:[
      {title:'Сад выбирает сам',text:'Новая экосистема просит отключить центральный контроль. Зумрад должна защитить её от машин, которые считают любое самостоятельное развитие отклонением.',a:'Защитить автономию экосистемы',b:'Оставить аварийный контур',reward:800,mission:true},
      {title:'Имя для нового вида',text:'Существо создаёт семена, не похожие на исходные образцы. Это уже не эксперимент Зумрад, а независимая жизнь.',a:'Дать ему собственное имя',b:'Записать его свойства без названия',reward:950,mission:true}
    ],
    malika_story:[
      {title:'Пустой патрон',text:'Малика находит тренировочную площадку, где её напарник оставил незаряженный клинок. Система пытается повторить последний поединок, но не знает, когда остановиться.',a:'Прервать цикл',b:'Дойти до конца записи',reward:820,mission:true},
      {title:'Красная линия не приказ',text:'В последнем сообщении напарник просит не превращать обещание вернуться в бесконечную войну. Малика выбирает, что будет означать её позывной теперь.',a:'Переименовать протокол',b:'Оставить старое имя и изменить смысл',reward:980,mission:true}
    ],
    kamila_story:[
      {title:'Архив третьего голоса',text:'Камила находит запись, которой не было в двух известных копиях. Третий голос принадлежит человеку, чьё имя удалено из всех региональных списков.',a:'Открыть архив для семей',b:'Сначала восстановить личность',reward:820,mission:true},
      {title:'Нить не обязана совпадать',text:'Три воспоминания расходятся в деталях, но сходятся в одном решении: помощь людям была добровольной. Камила учится жить с несовпадением.',a:'Сохранить все версии',b:'Создать личную четвёртую запись',reward:980,mission:true}
    ],
    laylo_story:[
      {title:'Первый самостоятельный маршрут',text:'Биомеханическое существо покидает теплицу и уходит к старой оросительной линии. Лайло следует за ним, чтобы понять, чего оно ищет.',a:'Не вмешиваться в путь',b:'Оставить защитные маяки',reward:800,mission:true},
      {title:'Не эксперимент',text:'Существо приводит Лайло к колонии, которая самостоятельно меняет форму под климат региона. Теперь решение о будущем контура принадлежит не лаборатории.',a:'Признать колонию самостоятельной',b:'Предложить совместное наблюдение',reward:960,mission:true}
    ],
    aziza_story:[
      {title:'Билет без станции',text:'Азиза получает сигнал от состава, который движется по маршруту, не отмеченному на карте. Он не просит остановить его — только указать направление.',a:'Указать путь к поселениям',b:'Оставить выбор пассажирам',reward:840,mission:true},
      {title:'Туда, где ещё не были',text:'Последняя платформа оказывается не точкой назначения, а возможностью построить новый маршрут. Азиза должна решить, кто первым получит доступ к линии.',a:'Открыть линию всем',b:'Сначала провести эвакуационный рейс',reward:1000,mission:true}
    ]
  };
  PERSONAL_STORIES.forEach(st=>{st.chapters.push(...(PERSONAL_DEEP_CHAPTERS[st.id]||[]));});
  const SIDE_QUESTS = [
    {id:'lost_signal',title:'Письмо из подземки',region:'tashkent',giver:'Дежурный терминал',desc:'Найди комнату, где городской диспетчер всё ещё ждёт подтверждения смены.',node:'tashkent_dispatch',reward:280,alloy:2,signal:35},
    {id:'sky_mirror',title:'Зеркало для никого',region:'samarkand',giver:'Архивист Академии',desc:'Проверь оптическую площадку и запиши направление последнего отражённого импульса.',node:'samarkand_mirror',reward:340,alloy:2,signal:40},
    {id:'green_heartbeat',title:'Пульс теплицы',region:'fergana',giver:'Дети Оазиса',desc:'Найди источник ритмичного сигнала среди живых труб биокомплекса.',node:'fergana_heart',reward:360,alloy:3,signal:40},
    {id:'salt_memory',title:'Соль помнит воду',region:'aral',giver:'Смотритель резервуара',desc:'Осмотри старый водомер и восстанови последнюю отметку уровня моря.',node:'aral_gauge',reward:390,alloy:3,signal:45},
    {id:'rail_manifest',title:'Манифест последнего рейса',region:'kyzylkum',giver:'Караван Соль-9',desc:'Отыщи терминал грузового состава и прочитай список пассажиров.',node:'kyzylkum_manifest',reward:430,alloy:3,signal:50}
  ];
  const SCOUT_NODES = [
    ['tashkent','tashkent_dispatch','Диспетчерская метро','СИГНАЛ','В старом кабинете мигает табло следующей смены.','Дежурный терминал повторяет список станций, которых больше нет.','credits',180],
    ['tashkent','tashkent_roof','Крыша жилого блока','НАБЛЮДЕНИЕ','На крыше сохранилась антенна с ручным приводом.','На горизонте виден слабый импульс в направлении Самарканда.','alloy',2],
    ['tashkent','tashkent_clinic','Медицинский пункт','АРХИВ','В шкафу лежат запечатанные медицинские кассеты.','На одной из кассет записано имя Айлы.','signal',30],
    ['samarkand','samarkand_mirror','Зеркальная площадка','ОПТИКА','Поворотные зеркала продолжают отслеживать невидимое небесное тело.','Луч уходит под землю, к неизвестной части Матрицы.','alloy',3],
    ['samarkand','samarkand_clock','Механический вычислитель','МЕХАНИЗМ','Старый вычислитель работает на энергии солнечного света.','В его памяти сохранилась формула до запуска НАСЛЕДИЯ.','credits',230],
    ['samarkand','samarkand_dome','Купол наблюдения','АРХИВ','На внутренней поверхности купола отмечены координаты.','Часть координат совпадает с будущими точками катастрофы.','signal',35],
    ['fergana','fergana_heart','Сердце биокомплекса','БИОСИГНАЛ','Под корнями кабелей пульсирует автономная капсула.','Система выращивала органы для тех, кого уже не было.','alloy',3],
    ['fergana','fergana_green','Зелёный коридор','ПРИРОДА','Растения проросли сквозь старую систему вентиляции.','Экосистема удерживает безопасную температуру внутри завода.','credits',260],
    ['fergana','fergana_lab','Лаборатория полимеров','АРХИВ','В лаборатории сохранились формулы синтетических тканей.','В журнале указано, что часть образцов реагировала на музыку.','signal',40],
    ['aral','aral_gauge','Станция водомеров','ИЗМЕРЕНИЕ','На стене сохранились отметки уровня воды за десятилетия.','Последняя отметка сделана в ночь Тишины.','alloy',3],
    ['aral','aral_ship','Корабль на соли','ОБЪЕКТ','В капитанской рубке работает автономный навигационный блок.','Маршрут корабля проходит через место, где теперь только песок.','credits',290],
    ['aral','aral_reservoir','Подземный резервуар','АРХИВ','В закрытой цистерне слышен звук капающей воды.','Вода пригодна для фильтрации. Это редкая находка в регионе.','signal',45],
    ['kyzylkum','kyzylkum_manifest','Терминал грузового состава','ТРАНЗИТ','Терминал хранит манифест последнего рейса.','В списке пассажиров есть фамилии, которые встречаются в архиве ОВОЗ.','alloy',4],
    ['kyzylkum','kyzylkum_excavator','Шагающий экскаватор','МАШИНА','Титан остановился, но его навигация ещё работает.','Машина охраняет путь к закрытой шахте, а не саму шахту.','credits',320],
    ['kyzylkum','kyzylkum_beacon','Маяк Соль-9','СВЯЗЬ','На старой вышке остался рабочий передатчик каравана.','Маяк принимает сигналы от неизвестного состава на севере.','signal',50]
  ].map(([region,id,title,kind,desc,lore,rewardType,reward])=>({region,id,title,kind,desc,lore,rewardType,reward}));

  SCOUT_NODES.push(
    {region:'tashkent',id:'tashkent_water',title:'Насосная под старым рынком',kind:'ИНЖЕНЕРИЯ',desc:'Насос включается только после ручного запуска старого реле.',lore:'В журнале отмечено: часть воды направляли в жилые кварталы даже после общего отключения.',rewardType:'alloy',reward:3},
    {region:'tashkent',id:'tashkent_rooftop',title:'Антенна на крыше',kind:'СВЯЗЬ',desc:'Поворотная антенна ловит короткий сигнал из закрытого туннеля.',lore:'На частоте слышно три ноты, совпадающие с мелодией из памяти Айлы.',rewardType:'signal',reward:35},
    {region:'samarkand',id:'samarkand_library',title:'Комната звёздных таблиц',kind:'НАУКА',desc:'Пыль скрыла таблицы, но механический каталог всё ещё отвечает.',lore:'В вычислениях встречается слово «Туран» как название сети дорог, а не государства.',rewardType:'credits',reward:310},
    {region:'samarkand',id:'samarkand_lens',title:'Объектив с обратной стороной',kind:'ОПТИКА',desc:'Линза показывает свет, исходящий из-под пола.',lore:'Система наблюдала за подземным движением задолго до аварии.',rewardType:'signal',reward:40},
    {region:'fergana',id:'fergana_seedbank',title:'Хранилище семян',kind:'БИОКОНТУР',desc:'В прохладной камере сохранились герметичные контейнеры.',lore:'Некоторые образцы были предназначены для восстановления местных сортов, а не для экспериментов.',rewardType:'credits',reward:330},
    {region:'fergana',id:'fergana_pulse',title:'Пульсирующий клапан',kind:'МЕХАНИЗМ',desc:'Клапан меняет ритм, когда рядом слышны шаги.',lore:'Старые биодатчики реагируют на присутствие, но не распознают его как угрозу.',rewardType:'alloy',reward:4},
    {region:'aral',id:'aral_radio',title:'Радиорубка на мели',kind:'СВЯЗЬ',desc:'В радиорубке сохранилась карта частот рыбацких поселений.',lore:'Один передатчик продолжает передавать прогноз погоды для моря, которого больше нет.',rewardType:'signal',reward:45},
    {region:'aral',id:'aral_filter',title:'Фильтрационный зал',kind:'ВОДА',desc:'Система фильтрации работает на запасном механическом приводе.',lore:'Чистая вода была распределена не по статусу, а по расстоянию до ближайшего колодца.',rewardType:'alloy',reward:4},
    {region:'kyzylkum',id:'kyzylkum_switch',title:'Стрелка на север',kind:'ТРАНЗИТ',desc:'Ручной механизм железнодорожной стрелки заблокирован старым приказом.',lore:'В журнале машиниста сказано: «маршрут меняют только после согласия пассажиров».',rewardType:'credits',reward:380},
    {region:'kyzylkum',id:'kyzylkum_wind',title:'Метеомачта пустыни',kind:'НАБЛЮДЕНИЕ',desc:'Мачта продолжает измерять ветер и пыль.',lore:'На записи последнего дня виден необычный фронт, двигавшийся против всех расчётов.',rewardType:'signal',reward:55}
  );

  const FACTION_ARCS = [
    {id:'syndicate',faction:'Кызылкумский синдикат',region:'tashkent',steps:[
      {id:'syndicate_01',title:'Вернуть сменный журнал',desc:'Заверши первую главу Ташкента и передай журнал инженерам.',type:'campaign',need:1,reward:{credits:300,signal:45,alloy:0,rep:1}},
      {id:'syndicate_02',title:'Проверить две линии питания',desc:'Найди две дополнительные точки в Ташкенте.',type:'scout',need:2,reward:{credits:360,signal:0,alloy:2,rep:1}},
      {id:'syndicate_03',title:'Манифест мастеров',desc:'Заверши побочную операцию «Письмо из подземки».',type:'sidequest',quest:'lost_signal',need:1,reward:{credits:500,signal:75,alloy:2,rep:2}}
    ]},
    {id:'academy',faction:'Академия звёздного неба',region:'samarkand',steps:[
      {id:'academy_01',title:'Сверить небесный архив',desc:'Заверши первую главу Самарканда.',type:'campaign',need:1,reward:{credits:320,signal:50,alloy:0,rep:1}},
      {id:'academy_02',title:'Две неизвестные координаты',desc:'Исследуй две дополнительные точки Самарканда.',type:'scout',need:2,reward:{credits:380,signal:0,alloy:2,rep:1}},
      {id:'academy_03',title:'Последний отражённый сигнал',desc:'Заверши операцию «Зеркало для никого».',type:'sidequest',quest:'sky_mirror',need:1,reward:{credits:520,signal:80,alloy:2,rep:2}}
    ]},
    {id:'oasis',faction:'Дети Оазиса',region:'fergana',steps:[
      {id:'oasis_01',title:'Стабилизировать биоконтур',desc:'Заверши первую главу Ферганы.',type:'campaign',need:1,reward:{credits:330,signal:50,alloy:1,rep:1}},
      {id:'oasis_02',title:'Наблюдение за ростом',desc:'Открой две дополнительные точки Ферганы.',type:'scout',need:2,reward:{credits:390,signal:0,alloy:3,rep:1}},
      {id:'oasis_03',title:'Сердце теплицы',desc:'Заверши побочную операцию «Пульс теплицы».',type:'sidequest',quest:'green_heartbeat',need:1,reward:{credits:540,signal:85,alloy:2,rep:2}}
    ]},
    {id:'archive',faction:'Архив «Седьмой Порог»',region:'aral',steps:[
      {id:'archive_01',title:'Сохранить уровень воды',desc:'Заверши первую главу Приаралья.',type:'campaign',need:1,reward:{credits:340,signal:50,alloy:0,rep:1}},
      {id:'archive_02',title:'Две записи моря',desc:'Исследуй две дополнительные точки Приаралья.',type:'scout',need:2,reward:{credits:400,signal:0,alloy:3,rep:1}},
      {id:'archive_03',title:'Архив глубины',desc:'Заверши побочную операцию «Соль помнит воду».',type:'sidequest',quest:'salt_memory',need:1,reward:{credits:560,signal:90,alloy:3,rep:2}}
    ]},
    {id:'salt9',faction:'Караван «Соль-9»',region:'kyzylkum',steps:[
      {id:'salt9_01',title:'Сверить манифест',desc:'Заверши первую главу Кызылкумов.',type:'campaign',need:1,reward:{credits:350,signal:55,alloy:1,rep:1}},
      {id:'salt9_02',title:'Открыть северный маршрут',desc:'Исследуй две дополнительные точки Кызылкумов.',type:'scout',need:2,reward:{credits:420,signal:0,alloy:3,rep:1}},
      {id:'salt9_03',title:'Последний рейс',desc:'Заверши побочную операцию «Манифест последнего рейса».',type:'sidequest',quest:'rail_manifest',need:1,reward:{credits:600,signal:100,alloy:3,rep:2}}
    ]}
  ];
  const FACTION_CONTACTS=[
    {id:'syndicate_contact',faction:'Кызылкумский синдикат',region:'tashkent',name:'Дильшод',role:'Мастер ремонтного контура',bio:'Помнит каждую линию питания старого города и не доверяет автоматическим отчётам.',lines:['Сначала проверяй кабель. Потом уже верь лампочке.','Я не чиню прошлое. Я делаю так, чтобы оно не мешало людям жить.'],reward:{credits:240,alloy:1}},
    {id:'academy_contact',faction:'Академия звёздного неба',region:'samarkand',name:'Мунира',role:'Хранительница обсерватории',bio:'Сверяет древние таблицы с сигналами, которые идут из-под поверхности.',lines:['Мы называем это небом, потому что пока не нашли более точного слова.','Расчёт — это карта сомнений, а не приказ будущему.'],reward:{credits:180,signal:60}},
    {id:'oasis_contact',faction:'Дети Оазиса',region:'fergana',name:'Феруза',role:'Смотрительница биоконтуров',bio:'Защищает экосистемы от машин, которые считают любую перемену дефектом.',lines:['Не называй росток ресурсом, пока не спросил, что ему нужно.','Живое не обязано быть удобным, чтобы иметь право существовать.'],reward:{credits:200,alloy:2}},
    {id:'archive_contact',faction:'Архив «Седьмой Порог»',region:'aral',name:'Бахтиёр',role:'Архивист голосовых копий',bio:'Собирает семейные записи и пытается отличать память от автоматического повтора.',lines:['Запись может сохраниться. Но решение о её смысле остаётся за теми, кто живёт сейчас.','Иногда лучший архив — тот, который не закрывает дверь.'],reward:{signal:90,alloy:1}},
    {id:'caravan_contact',faction:'Караван «Соль-9»',region:'kyzylkum',name:'Самира',role:'Навигатор северной линии',bio:'Ведёт караваны между поселениями и никогда не прокладывает маршрут без запасного выхода.',lines:['Маршрут — договор между теми, кто идёт, и теми, кто их ждёт.','Не называй дорогу пустой, пока не услышал, кто по ней возвращается.'],reward:{credits:260,signal:35}}
  ];
  const REGION_EVENTS=[
    {id:'tashkent_archive',region:'tashkent',title:'Открытая диспетчерская',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:1,branchChoice:'a',desc:'Сохранённый журнал смены привёл к сигналу из жилого сектора. Диспетчер просит восстановить связь с теми, кто ещё ждёт.',reward:{credits:420,signal:70,alloy:1,rep:2}},
    {id:'tashkent_workshop',region:'tashkent',title:'Линия ремонтников',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:1,branchChoice:'b',desc:'Переданные ремонтникам данные позволили запустить подъёмник. Теперь нужно защитить первую доставку.',reward:{credits:360,signal:35,alloy:3,rep:2}},
    {id:'samarkand_mirror_event',region:'samarkand',title:'Отражение под землёй',kind:'ДИНАМИЧЕСКОЕ СОБЫТИЕ',desc:'Оптический узел посылает новый импульс. Его можно перенастроить на безопасную частоту.',reward:{credits:450,signal:80,alloy:1,rep:2}},
    {id:'samarkand_academy_event',region:'samarkand',title:'Расчёт для каравана',kind:'ДИНАМИЧЕСКОЕ СОБЫТИЕ',desc:'Академия просит сопроводить вычислительный модуль до транспортного терминала.',reward:{credits:350,signal:110,alloy:1,rep:2}},
    {id:'fergana_seed_event',region:'fergana',title:'Семена без владельца',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:2,branchChoice:'a',desc:'Сохранённый живой образец дал потомство. Нужно удержать машины-сборщики до завершения эвакуации.',reward:{credits:420,signal:45,alloy:3,rep:2}},
    {id:'fergana_lab_event',region:'fergana',title:'Закрытый контейнер',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:2,branchChoice:'b',desc:'Контейнер перешёл в аварийный режим. Его можно безопасно отключить, не уничтожая данные.',reward:{credits:480,signal:65,alloy:2,rep:2}},
    {id:'aral_water_event',region:'aral',title:'Вода для поселения',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:1,branchChoice:'a',desc:'Восстановленный насос подал воду в колодцы. Осталось очистить распределительный узел от охраны.',reward:{credits:400,signal:60,alloy:3,rep:2}},
    {id:'aral_archive_event',region:'aral',title:'Состав соли и памяти',kind:'ДИНАМИЧЕСКОЕ СОБЫТИЕ',desc:'Архив просит защитить резервуар с записями семей, пока идёт копирование.',reward:{credits:500,signal:100,alloy:1,rep:2}},
    {id:'kyzylkum_passenger_event',region:'kyzylkum',title:'Пассажирские капсулы',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:1,branchChoice:'a',desc:'Капсулы остались закрытыми. Караван просит проверить систему жизнеобеспечения перед вскрытием.',reward:{credits:560,signal:90,alloy:2,rep:2}},
    {id:'kyzylkum_capsule_event',region:'kyzylkum',title:'Инвентаризация состава',kind:'ПОСЛЕДСТВИЕ ВЫБОРА',branchChapter:1,branchChoice:'b',desc:'Проверка капсул открыла старый маршрут. Нужно отбить доступ к навигационному блоку.',reward:{credits:460,signal:65,alloy:3,rep:2}}
  ];
  const FIELD_MAPS={
    tashkent:{label:'ТАШКЕНТ · СЕКТОР 04',ground:'#1b2922',accent:'#c6a66e',stops:[{name:'Станция 04',x:115,y:355},{name:'Старый рынок',x:445,y:125},{name:'Метро / платформа',x:770,y:350}],landmarks:[['metro_gate','Вход в метро',190,140,'gate','Сигнал диспетчера проходит через нижний тоннель.'],['old_market','Старый рынок',430,270,'cache','На витринах остались отметки водяного распределения.'],['antenna','Крыша с антенной',690,115,'signal','Передатчик улавливает три ноты из архивной записи.'],['lift','Подъёмник',745,365,'transport','Подъёмник соединяет жилой сектор с мастерской.']]},
    samarkand:{label:'САМАРКАНД · ОБСЕРВАТОРИЯ 02',ground:'#242238',accent:'#b6a5d3',stops:[{name:'Площадь зеркал',x:110,y:355},{name:'Северный купол',x:470,y:115},{name:'Подземная шахта',x:780,y:355}],landmarks:[['mirror_yard','Зеркальная площадка',185,150,'signal','Отражение ведёт к подземной антенне.'],['clock','Вычислительная башня',455,255,'cache','Механический расчёт хранит ошибку в одном такте.'],['dome','Купол',710,130,'gate','Купол отвечает на сигнал из глубины.'],['shaft','Шахта',770,365,'transport','Сервисный лифт ведёт к архиву Академии.']]},
    fergana:{label:'ФЕРГАНА · БИОКОМПЛЕКС 07',ground:'#203027',accent:'#98b98d',stops:[{name:'Зелёный коридор',x:110,y:355},{name:'Тепличный узел',x:460,y:125},{name:'Семенной банк',x:785,y:355}],landmarks:[['green_tube','Живой коридор',185,150,'cache','Корни удерживают безопасную температуру.'],['heart','Сердце биокомплекса',455,270,'signal','Капсула отвечает на присутствие мягким светом.'],['seed','Семенной банк',710,125,'gate','В контейнерах сохранились местные сорта растений.'],['bio_lift','Грузовой лифт',780,365,'transport','Лифт работает на биополимерном контуре.']]},
    aral:{label:'ПРИАРАЛЬЕ · СОЛЯНОЙ УЗЕЛ 12',ground:'#293238',accent:'#9ab9c1',stops:[{name:'Корабль на мели',x:105,y:350},{name:'Станция водомеров',x:460,y:120},{name:'Радиомачта',x:780,y:350}],landmarks:[['ship','Корабль на соли',190,150,'cache','Навигация помнит морской маршрут.'],['gauge','Водомерная станция',455,265,'signal','Последняя отметка сделана в ночь Тишины.'],['radio','Радиорубка',710,120,'gate','Прогноз погоды продолжает передаваться в пустоту.'],['reservoir','Резервуар',780,365,'transport','Технический проход соединяет насосы.']]},
    kyzylkum:{label:'КЫЗЫЛКУМЫ · ЛИНИЯ 09',ground:'#32271e',accent:'#d2a66d',stops:[{name:'Платформа Соль-9',x:110,y:355},{name:'Шагающий экскаватор',x:450,y:120},{name:'Северная стрелка',x:780,y:350}],landmarks:[['manifest','Терминал состава',185,145,'cache','Список пассажиров не совпадает с грузовым манифестом.'],['excavator','Шагающий экскаватор',455,275,'gate','Навигация охраняет путь, а не шахту.'],['beacon','Маяк Соль-9',710,130,'signal','Передатчик принимает дальний сигнал.'],['switch','Северная стрелка',780,365,'transport','Ручной привод открывает северный маршрут.']]}
  };
  const BOSS_INTROS={
    tashkent:{tag:'ПРОТОКОЛ ЗАКРЫТИЯ',line:'Смотритель продолжает эвакуацию, которой больше нет. Для него каждый, кто стоит у выхода, — потенциальная потеря.',mechanic:'Кольцевой обстрел · импульс закрытия · фазовый пресс'},
    samarkand:{tag:'РАСЧЁТ НЕИЗБЕЖНОСТИ',line:'Атлас-Ноль видит каждую траекторию, кроме той, в которой противник меняет собственный ритм.',mechanic:'Оптический веер · двойной луч · зеркальная копия'},
    fergana:{tag:'ЗАЩИТА КОЛОНИИ',line:'Мать-Спора не охотится. Она расширяет границу колонии и принимает любое приближение за угрозу.',mechanic:'Споровые круги · подкрепления · корневая ловушка'},
    aral:{tag:'БАЛАНС РЕЗЕРВУАРА',line:'Солянка удерживает воду и память в одном контуре. Любое движение система считает аварией.',mechanic:'Соляной веер · приливные зоны · сжатие арены'},
    kyzylkum:{tag:'ПОСЛЕДНИЙ МАРШРУТ',line:'Проводник не охраняет поезд. Он ждёт, пока кто-нибудь назовёт конечную станцию.',mechanic:'Таран по линии · разворот состава · перекрёстный импульс'}
  };

  function factionArcProgress(step){
    if(step.type==='campaign')return Math.min(step.need,save.campaignProgress[FACTION_ARCS.find(a=>a.steps.includes(step))?.region]||0);
    if(step.type==='scout')return Math.min(step.need,SCOUT_NODES.filter(n=>n.region===FACTION_ARCS.find(a=>a.steps.includes(step))?.region&&save.discoveredNodes.includes(n.id)).length);
    if(step.type==='sidequest')return save.completedSideQuests.includes(step.quest)?1:0;
    return 0;
  }
  function renderFactionArcs(){
    const root=$('factionArcPanel');if(!root)return;
    root.innerHTML='<div class="panel-kicker faction-kicker">ФРАКЦИОННЫЕ ЦЕПОЧКИ / ПОРУЧЕНИЯ И ПОСЛЕДСТВИЯ</div>'+FACTION_ARCS.map(arc=>{
      const firstUnclaimed=arc.steps.findIndex(s=>!save.factionArcClaims.includes(s.id));
      const next=firstUnclaimed<0?null:arc.steps[firstUnclaimed];
      const stepCards=arc.steps.map((s,i)=>{
        const claimed=save.factionArcClaims.includes(s.id),unlocked=operationUnlocked(operationById(arc.region))&&(i===0||save.factionArcClaims.includes(arc.steps[i-1].id)),started=save.factionArcStarted.includes(s.id),progress=factionArcProgress(s),ready=progress>=s.need;
        const status=claimed?'ВЫПОЛНЕНО':!unlocked?'ЗАКРЫТО':ready?'НАГРАДА ДОСТУПНА':started?'В РАБОТЕ':'МОЖНО ПРИНЯТЬ';
        const action=claimed?'ПОЛУЧЕНО':!unlocked?'НЕДОСТУПНО':!started?'ПРИНЯТЬ':ready?'ЗАБРАТЬ НАГРАДУ':'ПРОДОЛЖИТЬ';
        return `<div class="faction-arc-step ${claimed?'claimed':''} ${ready?'ready':''}"><small>ЭТАП 0${i+1} · ${status}</small><b>${s.title}</b><p>${s.desc}</p><div class="arc-progress"><i style="width:${Math.min(100,progress/s.need*100)}%"></i></div><div class="arc-foot"><span>${progress}/${s.need}</span><button data-faction-arc="${s.id}" ${claimed||!unlocked||(!started&&next!==s)?'disabled':''}>${action}</button></div></div>`;
      }).join('');
      return `<article class="faction-arc-card"><div class="faction-arc-title"><b>${arc.faction}</b><span>${save.factionArcClaims.filter(id=>arc.steps.some(s=>s.id===id)).length}/3</span></div><div class="faction-arc-steps">${stepCards}</div></article>`;
    }).join('');
    root.querySelectorAll('[data-faction-arc]').forEach(b=>b.addEventListener('click',()=>handleFactionArc(b.dataset.factionArc)));
  }
  function handleFactionArc(id){
    const arc=FACTION_ARCS.find(a=>a.steps.some(s=>s.id===id)),step=arc?.steps.find(s=>s.id===id);if(!arc||!step)return;
    const idx=arc.steps.indexOf(step);if(idx>0&&!save.factionArcClaims.includes(arc.steps[idx-1].id))return;
    if(!operationUnlocked(operationById(arc.region)))return toast('Сначала открой регион этой фракции.');
    if(!save.factionArcStarted.includes(id)){save.factionArcStarted.push(id);persist();renderArchive();toast(`Поручение принято: ${step.title}.`);return;}
    if(factionArcProgress(step)<step.need)return toast('Условие поручения ещё не выполнено.');
    if(save.factionArcClaims.includes(id))return;
    save.factionArcClaims.push(id);save.credits+=step.reward.credits;save.signal+=step.reward.signal;save.alloy+=step.reward.alloy;addFactionRep(arc.faction,step.reward.rep,step.title);
    save.xp+=100;save.accountLevel=1+Math.floor(save.xp/600);persist();renderArchive();toast(`Награда фракции получена: ${step.title}.`);sound(620,.18,'triangle',.035);
  }
  const WEAPONS = [
    {id:'field_blade',name:'Полевой клинок',type:'Клинок',rank:3,atk:4,hp:0,speed:0,cost:0,alloy:0,desc:'Надёжный клинок первой экспедиции.'},
    {id:'coil_spear',name:'Катушка-7',type:'Копьё',rank:4,atk:13,hp:25,speed:0,cost:850,alloy:2,desc:'Электромагнитное копьё с усиленным пробитием.'},
    {id:'desert_pchak',name:'Пчак «Красная линия»',type:'Парные клинки',rank:4,atk:17,hp:0,speed:12,cost:1100,alloy:3,desc:'Лёгкие клинки для быстрых серий и рывков.'},
    {id:'pulse_revolver',name:'Импульсный револьвер',type:'Пистолет',rank:4,atk:15,hp:0,speed:5,cost:1000,alloy:3,desc:'Компактное оружие для точечных попаданий.'},
    {id:'sound_bow',name:'Акустический лук',type:'Резонатор',rank:4,atk:12,hp:40,speed:0,cost:950,alloy:2,desc:'Передаёт вибрацию через натянутую мембрану.'},
    {id:'bur_mallet',name:'Бур-молот К-12',type:'Тяжёлое оружие',rank:4,atk:22,hp:80,speed:-12,cost:1350,alloy:4,desc:'Тяжёлый инструмент для разрушения брони.'},
    {id:'bio_whip',name:'Симбиотический хлыст',type:'Биомеханика',rank:5,atk:19,hp:65,speed:8,cost:1700,alloy:5,desc:'Органический материал реагирует на движения владельца.'},
    {id:'gravity_staff',name:'Астрономический жезл',type:'Фокус',rank:5,atk:21,hp:35,speed:0,cost:1800,alloy:5,desc:'Стабилизирует импульсы и усиливает резонанс.'},
    {id:'rail_lance',name:'Рельсокопьё Соль-9',type:'Рельсовое оружие',rank:5,atk:28,hp:40,speed:-4,cost:2200,alloy:6,desc:'Оружие дальнего пробоя, собранное из деталей состава.'}

    ,{id:'metro_saw',name:'Рельсовая пила «Сектор»',type:'Цепной клинок',rank:4,atk:19,hp:20,speed:3,cost:1450,alloy:4,desc:'Короткие импульсы разгоняют зубчатый венец.',traitName:'Ритм реза',traitDesc:'+8% урона завершающего удара серии.',thirdHitBonus:.08}
    ,{id:'metro_guard',name:'Щитовой резак М-04',type:'Клинок-щит',rank:4,atk:11,hp:180,speed:-2,cost:1250,alloy:4,desc:'Сменная пластина защищает от прямых попаданий.',traitName:'Пластина метро',traitDesc:'Снижает входящий урон на 4%.',damageReduction:.04}
    ,{id:'pulse_fan',name:'Веер импульсов',type:'Парные метатели',rank:4,atk:14,hp:0,speed:8,cost:1180,alloy:3,desc:'Два компактных излучателя синхронизированы по фазе.',traitName:'Двойная частота',traitDesc:'+6% к набору МАКОМ.',makomGain:1.06}
    ,{id:'astrolabe',name:'Астролябия «Самарканд»',type:'Фокус',rank:5,atk:23,hp:45,speed:0,cost:2050,alloy:6,desc:'Оптические кольца корректируют траектории навыков.',traitName:'Звёздная поправка',traitDesc:'+12% к силе навыков.',skillPower:1.12}
    ,{id:'mirror_lance',name:'Копьё обратного света',type:'Копьё',rank:4,atk:17,hp:0,speed:4,cost:1420,alloy:4,desc:'Отражает импульс при точном наведении.',traitName:'Обратный луч',traitDesc:'+4% к критическому шансу.',critChance:.04}
    ,{id:'root_needle',name:'Игла корневого контура',type:'Биоклинок',rank:4,atk:15,hp:95,speed:2,cost:1500,alloy:4,desc:'Живые нити укрепляют владельца при контакте.',traitName:'Симбиоз',traitDesc:'+3% прочности и +4% силы навыка.',hpBonus:.03,skillPower:1.04}
    ,{id:'spore_bow',name:'Лук «Тихий рост»',type:'Биорезонатор',rank:5,atk:22,hp:90,speed:0,cost:1980,alloy:6,desc:'Стрелы раскрываются в поле мягкого биосигнала.',traitName:'Тихая регенерация',traitDesc:'Снижает входящий урон на 3% и усиливает навык на 6%.',damageReduction:.03,skillPower:1.06}
    ,{id:'salt_anchor',name:'Якорь соляного узла',type:'Тяжёлый якорь',rank:4,atk:21,hp:120,speed:-8,cost:1660,alloy:5,desc:'Механический якорь удерживает позицию под давлением.',traitName:'Опора мелководья',traitDesc:'+5% прочности и +3% защиты.',hpBonus:.05,damageReduction:.03}
    ,{id:'brine_flail',name:'Цепь «Белая вода»',type:'Цепное оружие',rank:4,atk:18,hp:30,speed:5,cost:1550,alloy:4,desc:'Сегменты цепи передают импульс по широкой дуге.',traitName:'Широкая дуга',traitDesc:'+12 единиц радиуса базовой атаки.',range:12}
    ,{id:'desert_repeater',name:'Повторитель «Караван»',type:'Двойной карабин',rank:4,atk:16,hp:0,speed:10,cost:1620,alloy:4,desc:'Механизм рассчитан на быструю смену магазинов.',traitName:'Маршевый темп',traitDesc:'+10 скорости и +5% набора МАКОМ.',speedBonus:10,makomGain:1.05}
    ,{id:'iron_horizon',name:'Молот железного горизонта',type:'Тяжёлое оружие',rank:5,atk:31,hp:100,speed:-10,cost:2450,alloy:7,desc:'Силовой привод рассчитан на разрушение бронированных узлов.',traitName:'Срыв брони',traitDesc:'+12% завершающего удара серии.',thirdHitBonus:.12}
    ,{id:'silk_edge',name:'Шёлковый резонатор',type:'Гибкий клинок',rank:4,atk:18,hp:15,speed:16,cost:1740,alloy:4,desc:'Тонкая гибкая пластина меняет траекторию прямо во время удара.',traitName:'Смена дуги',traitDesc:'+10% к радиусу комбо.',range:18,attackStyle:'chain'}
    ,{id:'qobyz_core',name:'Ядро кобыза',type:'Акустический фокус',rank:5,atk:24,hp:55,speed:2,cost:2300,alloy:7,desc:'Резонатор преобразует низкую частоту в направленный импульс.',traitName:'Низкий такт',traitDesc:'+10% к силе навыков и МАКОМ.',skillPower:1.1,makomGain:1.1,attackStyle:'projectile'}
    ,{id:'ceramic_halberd',name:'Керамическая алебарда',type:'Алебарда',rank:4,atk:25,hp:50,speed:-5,cost:1880,alloy:5,desc:'Лёгкий композит выдерживает резкие боковые перегрузки.',traitName:'Дальний замах',traitDesc:'+24 к радиусу атаки.',range:24,attackStyle:'lance'}
    ,{id:'magnet_darts',name:'Магнитные дротики',type:'Метательные иглы',rank:4,atk:16,hp:0,speed:12,cost:1690,alloy:4,desc:'Возвращаются к рукояти после попадания.',traitName:'Возвратный контур',traitDesc:'+5% критического шанса.',critChance:.05,attackStyle:'projectile'}
    ,{id:'rail_hammer',name:'Кувалда депо №12',type:'Ударная кувалда',rank:5,atk:34,hp:125,speed:-14,cost:2780,alloy:8,desc:'Тяжёлый боёк рассчитан на демонтаж промышленных заслонов.',traitName:'Срыв опоры',traitDesc:'+18% к отбрасыванию и завершающему удару.',thirdHitBonus:.18,attackStyle:'heavy'}
    ,{id:'reed_whip',name:'Кнут камышового контура',type:'Живой хлыст',rank:4,atk:20,hp:75,speed:9,cost:1820,alloy:5,desc:'Биополимерная лента реагирует на ритм дыхания владельца.',traitName:'Живой изгиб',traitDesc:'+6% прочности и +10 к дальности.',hpBonus:.06,range:10,attackStyle:'chain'}
    ,{id:'glass_repeater',name:'Стеклянный повторитель',type:'Точный карабин',rank:5,atk:27,hp:0,speed:7,cost:2490,alloy:7,desc:'Оптический затвор фиксирует только чистые линии выстрела.',traitName:'Преломление',traitDesc:'+7% критического шанса.',critChance:.07,attackStyle:'projectile'}
    ,{id:'salt_sabre',name:'Сабля соляного ветра',type:'Изогнутая сабля',rank:4,atk:23,hp:20,speed:11,cost:1920,alloy:5,desc:'Узкая гарда позволяет менять направление атаки без остановки.',traitName:'Порыв ветра',traitDesc:'+8 скорости и +8% комбо.',speedBonus:8,thirdHitBonus:.08,attackStyle:'arc'}
    ,{id:'pulse_gauntlets',name:'Импульсные наручи',type:'Парные перчатки',rank:4,atk:22,hp:85,speed:6,cost:2010,alloy:5,desc:'Встроенные приводы превращают короткие серии в ударные волны.',traitName:'Двойной привод',traitDesc:'+7% к урону первых двух ударов.',atkBonus:.07,attackStyle:'heavy'}
    ,{id:'navda_scythe',name:'Серп НАВДА',type:'Биосерп',rank:5,atk:26,hp:105,speed:5,cost:2550,alloy:7,desc:'Лезвие выращивается заново после каждого сильного импульса.',traitName:'Восстановление формы',traitDesc:'+5% защиты и +7% силы навыка.',damageReduction:.05,skillPower:1.07,attackStyle:'chain'}
    ,{id:'mirror_pistol',name:'Пистолет обратного зеркала',type:'Отражающий пистолет',rank:4,atk:18,hp:0,speed:9,cost:1850,alloy:4,desc:'Снаряд делится на две траектории после первого отражения.',traitName:'Рикошет',traitDesc:'+1 дополнительная цель для дальнего комбо.',range:8,attackStyle:'projectile'}
    ,{id:'observatory_staff',name:'Посох меридиана',type:'Гравитационный посох',rank:5,atk:29,hp:60,speed:-2,cost:2680,alloy:8,desc:'Две линзы удерживают противника на линии направленного поля.',traitName:'Линия меридиана',traitDesc:'+12% силы навыка и контроля.',skillPower:1.12,attackStyle:'projectile'}
  ];
  // Give legacy arsenal entries readable and mechanically meaningful signatures as well.
  const WEAPON_TRAIT_DEFAULTS=[{traitName:'Стабильный импульс',traitDesc:'+4% к набору МАКОМ.',makomGain:1.04},{traitName:'Калиброванный спуск',traitDesc:'+2% к критическому шансу.',critChance:.02},{traitName:'Усиленный контур',traitDesc:'+2% к прочности.',hpBonus:.02},{traitName:'Точный резонанс',traitDesc:'+4% к силе навыка.',skillPower:1.04}];
  WEAPONS.forEach((w,i)=>{const d=WEAPON_TRAIT_DEFAULTS[i%WEAPON_TRAIT_DEFAULTS.length];if(!w.traitName)Object.assign(w,d);if(!w.attackStyle){const t=w.type.toLowerCase();w.attackStyle=/пистолет|карабин|лук|резонатор|фокус|метател|жезл|повторител/.test(t)?'projectile':/тяжёл|молот|кувалд|якор/.test(t)?'heavy':/цеп|хлыст|пила|серп/.test(t)?'chain':/копь|алебард|рельс/.test(t)?'lance':'arc';}});
  const MODULES = [
    {id:'vital',name:'Живой контур',slot:'Сердечник',hp:150,atk:0,speed:0,cost:420,alloy:1,desc:'+150 прочности.'},
    {id:'edge',name:'Калибровка лезвия',slot:'Привод',hp:0,atk:10,speed:0,cost:520,alloy:1,desc:'+10 к атаке.'},
    {id:'motor',name:'Сервомотор',slot:'Привод',hp:0,atk:0,speed:18,cost:490,alloy:1,desc:'+18 к скорости.'},
    {id:'shell',name:'Панцирь шахтёра',slot:'Корпус',hp:230,atk:0,speed:-5,cost:640,alloy:2,desc:'+230 прочности, −5 скорости.'},
    {id:'resonance',name:'Резонатор Маком',slot:'Синхронизация',hp:0,atk:7,speed:5,cost:700,alloy:2,desc:'+7 к атаке и +5 к скорости.'},
    {id:'medic',name:'Медицинский узел',slot:'Сердечник',hp:190,atk:0,speed:0,cost:650,alloy:2,desc:'+190 прочности.'},
    {id:'focus',name:'Оптический фокус',slot:'Синхронизация',hp:0,atk:14,speed:-2,cost:780,alloy:3,desc:'+14 к атаке, −2 к скорости.'},
    {id:'feather',name:'Облегчённый каркас',slot:'Корпус',hp:-40,atk:0,speed:24,cost:620,alloy:2,desc:'−40 прочности, +24 к скорости.'}
  ];

  const INITIAL_SAVE = {
    credits:8000, signal:1600, pity:0, pity4:0, pulls:0, featuredGuarantee:false, weaponPity:0, weaponPity4:0, weaponFeaturedGuarantee:false, weaponPulls:0, weaponFragments:{},
    unlocked:['ayla','rustam','saodat','zumrad'], fragments:{}, levels:{ayla:1,rustam:1,saodat:1,zumrad:1},
    team:['ayla','rustam','saodat'], selected:'ayla', firstClear:false, wins:0, xp:0, accountLevel:1,
    sound:true, vibration:true, quality:'high', lastSummons:[], archiveFlags:[], selectedRegion:'tashkent', clearedRegions:[],
    alloy:12, stationLevel:1, stationRooms:{}, roomFlags:[], bonds:{}, rested:false, dialogueIndex:{}, lastStationDialogue:null,
    ownedWeapons:['field_blade'], weaponLevels:{field_blade:1}, equippedWeapon:{}, ownedModules:['vital','edge'], equippedModules:{ayla:['vital','edge']}, bondFlags:[],
    storyProgress:{}, storyChoices:{}, startedSideQuests:[], completedSideQuests:[], discoveredNodes:[], exploreLog:[], selectedScoutRegion:'tashkent', campaignProgress:{}, campaignChoices:{}, factionRep:{}, factionClaims:{}, campaignFlags:[], routeScores:{memory:0,freedom:0,truth:0}, routeHistory:[], mainEnding:null, factionArcStarted:[], factionArcClaims:[], stationEventFlags:[], storyAwakenings:{},
    worldFlags:[], regionEventClaims:[], regionEventStarts:[], fieldPositions:{}, fieldDiscovered:[], fieldSteps:0, fieldEncounterReady:false, fieldTransportIndex:{}, personalMissionClears:{}, weaponMastery:{}, teamSynergyClaims:[], epilogueFlags:[], summonHistory:[], stationRoomLevels:{}, stationStorage:{credits:0,signal:0,alloy:0}, stationJointScenes:[], factionContactFlags:[], factionContactBonds:{}, music:true, musicVolume:.12, quality:'auto'
  };
  let save;
  try { save = Object.assign({}, INITIAL_SAVE, JSON.parse(localStorage.getItem('turan_save_v1') || '{}')); }
  catch { save = {...INITIAL_SAVE}; }
  save.unlocked = Array.isArray(save.unlocked) ? save.unlocked : [...INITIAL_SAVE.unlocked];
  save.team = Array.isArray(save.team) ? save.team : [...INITIAL_SAVE.team];
  save.levels = save.levels || {...INITIAL_SAVE.levels};
  save.fragments = save.fragments || {};
  save.clearedRegions = Array.isArray(save.clearedRegions) ? save.clearedRegions : (save.firstClear ? ['tashkent'] : []);
  ['ownedWeapons','ownedModules','roomFlags','startedSideQuests','completedSideQuests','discoveredNodes','exploreLog','routeHistory','factionArcStarted','factionArcClaims','stationEventFlags','worldFlags','regionEventClaims','regionEventStarts','fieldDiscovered','summonHistory','stationJointScenes','factionContactFlags','teamSynergyClaims','epilogueFlags'].forEach(k=>{if(!Array.isArray(save[k]))save[k]=[...(INITIAL_SAVE[k]||[])];});
  ['weaponLevels','equippedWeapon','equippedModules','stationRooms','bonds','storyProgress','storyChoices','dialogueIndex','campaignProgress','campaignChoices','factionRep','factionClaims','weaponFragments','routeScores','storyAwakenings','fieldPositions','fieldTransportIndex','personalMissionClears','weaponMastery','stationRoomLevels','stationStorage','factionContactBonds'].forEach(k=>{if(!save[k]||typeof save[k]!=='object')save[k]={};});
  ['featuredGuarantee','weaponFeaturedGuarantee'].forEach(k=>{save[k]=!!save[k];});
  ['pity','pity4','weaponPity','weaponPity4','weaponPulls'].forEach(k=>{save[k]=Number.isFinite(save[k])?Math.max(0,save[k]):0;});
  if(!Array.isArray(save.campaignFlags))save.campaignFlags=[];
  save.alloy=Number.isFinite(save.alloy)?save.alloy:12;save.stationLevel=Number.isFinite(save.stationLevel)?save.stationLevel:1;
  if(!Array.isArray(save.bondFlags))save.bondFlags=[];
  if(!Number.isFinite(save.fieldSteps))save.fieldSteps=0;save.fieldEncounterReady=!!save.fieldEncounterReady;
  if(!Number.isFinite(save.musicVolume))save.musicVolume=.12;save.music=save.music!==false;
  save.stationStorage=Object.assign({credits:0,signal:0,alloy:0},save.stationStorage||{});
  PERSONAL_STORIES.forEach(st=>{if(!Number.isFinite(save.personalMissionClears[st.id]))save.personalMissionClears[st.id]=Math.min(save.storyProgress[st.id]||0,3);});
  save.routeScores=Object.assign({memory:0,freedom:0,truth:0},save.routeScores||{});
  save.mainEnding=save.mainEnding&&typeof save.mainEnding==='object'?save.mainEnding:null;
  if(!OPERATIONS.some(o=>o.id===save.selectedScoutRegion))save.selectedScoutRegion='tashkent';
  if (!OPERATIONS.some(o=>o.id===save.selectedRegion)) save.selectedRegion='tashkent';
  if (!operationUnlocked(operationById(save.selectedRegion))) save.selectedRegion='tashkent';
  if (!save.team.length) save.team = ['ayla','rustam','saodat'];
  save.team = save.team.filter(id => save.unlocked.includes(id)).slice(0,3);
  if (!save.team.length) save.team = ['ayla'];
  if (!save.unlocked.includes(save.selected)) save.selected = save.team[0] || 'ayla';

  function persist() {
    try { localStorage.setItem('turan_save_v1', JSON.stringify(save)); } catch(e) { console.warn('Save unavailable', e); }
    updateResources();
  }
  function updateResources() {
    $('creditsValue').textContent = fmt(save.credits);
    $('signalValue').textContent = fmt(save.signal);
    if($('alloyValue')) $('alloyValue').textContent = fmt(save.alloy);
    $('heroCount').textContent = `${save.unlocked.length} / ${HEROES.length}`;
    $('teamCount').textContent = `${save.team.length} / 3`;
  }

  // Simple synth sounds; no external audio files are required.
  let audioCtx = null;
  function sound(freq=420, duration=.07, type='sine', volume=.035) {
    if (!save.sound) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
      osc.type = type; osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(Math.max(50,freq*.62), audioCtx.currentTime+duration);
      gain.gain.setValueAtTime(volume, audioCtx.currentTime); gain.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime+duration);
      osc.connect(gain); gain.connect(audioCtx.destination); osc.start(); osc.stop(audioCtx.currentTime+duration);
    } catch(e) { /* audio is optional */ }
  }
  function buzz(ms=18) { if (save.vibration && navigator.vibrate) navigator.vibrate(ms); }

  let toastTimer = 0;
  function toast(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2100);
  }
  let battleToastTimer = 0;
  function battleToast(message) {
    const el = $('battleToast'); el.textContent = message; el.classList.add('show');
    clearTimeout(battleToastTimer); battleToastTimer = setTimeout(() => el.classList.remove('show'), 1400);
  }

  // Menu navigation
  const views = ['home','expeditions','characters','summon','workshop','station','stories','scouting','archive'];
  function showView(name) {
    views.forEach(v => $('view-'+v).classList.toggle('active', v===name));
    const content=$('view-'+name)?.closest('.content-area');if(content)content.scrollTop=0;
    document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view===name));
    if (name === 'home') { renderHomeTeam(); renderHomeMission();setMusicScene('base'); }
    if (name === 'expeditions') renderExpeditions();
    if (name === 'characters') renderCharacters();
    if (name === 'workshop') renderWorkshop();
    if (name === 'station') {renderStation();setMusicScene('base');}
    if (name === 'stories') renderStories();
    if (name === 'scouting') {renderScouting();setMusicScene(save.selectedRegion||'tashkent');}
    if (name === 'summon') {renderPity();setMusicScene('base');}
    if (name === 'archive') renderArchive();
    sound(360,.045,'triangle',.018);
  }
  document.querySelectorAll('.nav-item').forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));
  $('openSettings').addEventListener('click', openSettings);

  function renderHomeTeam() {
    $('homeTeam').innerHTML = save.team.map(id => {
      const h = HERO_BY_ID[id]; return `<div class="mini-hero" style="--hero-color:${h.color}" title="${h.name}">${h.glyph}</div>`;
    }).join('');
  }

  function renderHomeMission(){
    const op=operationById(save.selectedRegion);
    $('homeRegionMeta').textContent=`${op.name} · ${op.zone}`;
    $('homeTaskTitle').textContent=op.title;
    $('homeTaskDesc').textContent=save.clearedRegions.includes(op.id)?`Регион исследован. Повторная экспедиция доступна: ${op.boss}.`:op.desc;
  }
  function selectOperation(id){
    const op=operationById(id);
    if(!operationUnlocked(op)){toast(`Сначала заверши операцию: ${operationById(op.unlockedBy).name}.`);return;}
    save.selectedRegion=id;persist();renderExpeditions();renderHomeMission();toast(`Выбрана операция: ${op.name}.`);
  }
  function renderExpeditions(){
    const grid=$('operationGrid'); if(!grid)return;
    const unlocked=OPERATIONS.filter(operationUnlocked).length;
    $('regionProgress').textContent=`${String(unlocked).padStart(2,'0')} / 05`;
    grid.innerHTML=OPERATIONS.map(op=>{
      const open=operationUnlocked(op),cleared=save.clearedRegions.includes(op.id),selected=save.selectedRegion===op.id;
      return `<button class="operation-card ${selected?'selected':''} ${open?'':'locked'}" data-operation="${op.id}" style="--op-color:${op.color};--op-floor:${op.floor};--op-wall:${op.wall}">
        <span class="operation-rank">ОПЕРАЦИЯ ${op.rank}</span><span class="operation-status">${!open?'ЗАКРЫТО':cleared?'ИССЛЕДОВАНО':'ДОСТУПНО'}</span>
        <span class="operation-number">0${OPERATIONS.indexOf(op)+1}</span><span class="operation-title">${op.name}</span><span class="operation-subtitle">${op.title}</span>
        <span class="operation-boss">ЦЕЛЬ: ${op.boss}</span>${!open?'<span class="operation-lock">◈</span>':''}
      </button>`;
    }).join('');
    grid.querySelectorAll('[data-operation]').forEach(b=>b.addEventListener('click',()=>selectOperation(b.dataset.operation)));
    const op=operationById(save.selectedRegion);
    $('operationBrief').innerHTML=`<div><div class="eyebrow">ВЫБРАННАЯ ОПЕРАЦИЯ / ${op.zone}</div><h3>${op.name}: ${op.title}</h3><p>${op.desc}</p>${regionConsequenceSummary(op.id)?`<div class="campaign-outcome">ПОСЛЕДСТВИЕ В МИРЕ: ${regionConsequenceSummary(op.id)}</div>`:''}<div class="operation-tags"><span>3 ВОЛНЫ</span><span>ЭЛИТНЫЕ ЦЕЛИ</span><span>БОСС: ${op.boss}</span></div></div><button class="primary-button" id="launchOperation" ${operationUnlocked(op)?'':'disabled'}>НАЧАТЬ ЭКСПЕДИЦИЮ <b>↗</b></button>`;
    $('launchOperation').addEventListener('click',()=>{activeCampaignRun=null;startGame();});
    renderCampaign(op);
  }

  let selectedCampaignChapter=1, selectedCampaignChoice='a';
  let activeCampaignRun=null;
  function renderCampaign(op){
    const root=$('campaignPanel');if(!root)return;
    const chapters=CAMPAIGN[op.id]||[],progress=Math.min(3,Math.max(0,save.campaignProgress[op.id]||0));
    if(!operationUnlocked(op)){root.innerHTML='<div class="campaign-empty">Откроется после завершения предыдущего региона.</div>';return;}
    if(selectedCampaignChapter>progress+1)selectedCampaignChapter=progress+1;
    const chapter=chapters[selectedCampaignChapter-1]||chapters[0],isDone=selectedCampaignChapter<=progress;
    const aura=getRouteAura(),allDone=OPERATIONS.every(x=>(save.campaignProgress[x.id]||0)>=3);
    const routeScore=Object.entries(save.routeScores||{}).map(([k,v])=>`${k==='memory'?'ПАМЯТЬ':k==='freedom'?'СВОБОДА':'ИСТИНА'} ${v||0}`).join(' · ');
    root.innerHTML=`<div class="campaign-head"><div><div class="eyebrow">ОСНОВНАЯ КАМПАНИЯ / ${op.rank} · ГЛАВЫ ${progress}/3</div><h3>ХРОНИКИ РЕГИОНА</h3><p>Три последовательные главы на регион. Решения меняют общий маршрут и боевой резонанс в следующих операциях.</p></div><span class="campaign-counter">${progress}/3</span></div><div class="route-legacy"><div><small>ТЕКУЩЕЕ НАСЛЕДИЕ РЕШЕНИЙ</small><b>${aura.name}</b><p>${aura.desc}</p><span>${routeScore}</span></div>${save.mainEnding?`<aside><small>ФИНАЛ ОТКРЫТ</small><b>${save.mainEnding.title}</b><p>${save.mainEnding.text}</p></aside>`:allDone?'':'<aside><small>УСЛОВИЕ ФИНАЛА</small><b>15 / 15 ГЛАВ</b><p>Заверши кампании всех пяти регионов, чтобы открыть развязку.</p></aside>'}</div><div class="campaign-chapters">${chapters.map((ch,i)=>{const n=i+1,done=n<=progress,open=n===progress+1;return `<button class="campaign-chapter ${selectedCampaignChapter===n?'active':''} ${done?'done':''} ${!done&&!open?'locked':''}" data-chapter="${n}" ${!done&&!open?'disabled':''}><small>ГЛАВА 0${n}</small><b>${ch.title}</b><i>${done?'ЗАВЕРШЕНА':open?'ДОСТУПНА':'ЗАКРЫТА'}</i></button>`}).join('')}</div>${isDone?`<div class="campaign-detail"><div class="eyebrow">ЗАПИСЬ ЗАВЕРШЕНА</div><h4>${chapter.title}</h4><p>${chapter.brief}</p><div class="campaign-outcome">РЕШЕНИЕ: ${(save.campaignChoices[`${op.id}_${selectedCampaignChapter}`]||'a')==='a'?chapter.a:chapter.b}</div></div>`:`<div class="campaign-detail"><div class="eyebrow">ГЛАВА 0${selectedCampaignChapter} / ${op.zone}</div><h4>${chapter.title}</h4><p>${chapter.brief}</p><div class="campaign-objective">ЦЕЛЬ: ${chapter.objective}</div><div class="campaign-choice-label">ПРИНЯТЬ РЕШЕНИЕ</div><div class="campaign-choice-row"><button class="campaign-choice ${selectedCampaignChoice==='a'?'chosen':''}" data-campaign-choice="a"><b>${chapter.a}</b><small>+2 репутации / ${chapter.fa}</small></button><button class="campaign-choice ${selectedCampaignChoice==='b'?'chosen':''}" data-campaign-choice="b"><b>${chapter.b}</b><small>+2 репутации / ${chapter.fb}</small></button></div><button class="primary-button campaign-launch" id="launchCampaignChapter">НАЧАТЬ ГЛАВУ 0${selectedCampaignChapter} <b>↗</b></button></div>`}`;
    root.querySelectorAll('[data-chapter]').forEach(b=>b.addEventListener('click',()=>{selectedCampaignChapter=Number(b.dataset.chapter);renderCampaign(op);}));
    root.querySelectorAll('[data-campaign-choice]').forEach(b=>b.addEventListener('click',()=>{selectedCampaignChoice=b.dataset.campaignChoice;renderCampaign(op);}));
    $('launchCampaignChapter')?.addEventListener('click',()=>{activeCampaignRun={region:op.id,chapter:selectedCampaignChapter,choice:selectedCampaignChoice};startGame();});
  }

  let detailHero = save.selected;
  function renderCharacters() {
    const grid = $('characterGrid');
    grid.innerHTML = HEROES.map(h => {
      const owned = save.unlocked.includes(h.id), active = detailHero===h.id;
      const inTeam = save.team.includes(h.id);
      return `<button class="hero-card ${active?'selected':''} ${owned?'':'locked'}" data-hero="${h.id}" style="--hero-color:${h.color};--hair:${h.hair}">
        <span class="rarity">${'★'.repeat(h.rank)}</span>${owned?(inTeam?'<span class="team-mark">●</span>':''):'<span class="lock-label">▣</span>'}
        <div class="hero-art-mini"><i class="mini-hair"></i><i class="mini-head"></i><i class="mini-body"></i></div>
        <span class="hero-card-name">${h.name}</span><span class="hero-card-meta">${h.element} · ${owned?'ДОСТУПЕН':'НЕ НАЙДЕН'}</span>
      </button>`;
    }).join('');
    grid.querySelectorAll('[data-hero]').forEach(b => b.addEventListener('click', () => { detailHero=b.dataset.hero; renderCharacters(); }));
    renderCharacterDetail();
    updateResources();
  }
  function renderCharacterDetail() {
    const h = HERO_BY_ID[detailHero] || HERO_BY_ID.ayla;
    const owned = save.unlocked.includes(h.id), inTeam = save.team.includes(h.id);
    const level = save.levels[h.id] || 1;
    const attack = h.atk + (level-1)*7;
    const hp = h.hp + (level-1)*52;
    $('characterDetail').innerHTML = `<div class="detail-art"><div class="detail-silhouette" style="background:linear-gradient(90deg,#18211e,${h.color},#25352d)"></div></div>
      <div class="detail-name">${h.name}</div><div class="detail-meta">${'★'.repeat(h.rank)} · ${h.element} · ${h.faction} · УРОВЕНЬ ${level}</div>
      <div class="detail-desc">${h.desc}</div>
      <div class="passive-card"><small>ИНДИВИДУАЛЬНЫЙ ПАССИВНЫЙ ПРОТОКОЛ ${save.storyAwakenings[h.id]?'· ПРОБУЖДЁН':''}</small><b>${h.passive.name}</b><p>${h.passive.desc}</p></div><div class="passive-card combat-kit-card"><small>АКТИВНЫЙ БОЕВОЙ НАБОР · ${h.combatKit.id}</small><b>${h.skill} / ${h.ult}</b><p>Паттерн навыка: ${h.combatKit.skillPattern.toUpperCase()} · Ультимейт: ${h.combatKit.ultPattern.toUpperCase()} · Комбо: ${h.combatKit.comboStyle}. ${h.desc}</p></div>
      <div class="stat-line"><span>АТАКА</span><b>${attack}</b></div><div class="stat-track"><i style="width:${clamp(attack/190*100,5,100)}%"></i></div>
      <div class="stat-line"><span>ПРОЧНОСТЬ</span><b>${hp}</b></div><div class="stat-track"><i style="width:${clamp(hp/1800*100,5,100)}%"></i></div>
      <div class="detail-actions">${owned?`<button class="${inTeam?'secondary-button':'primary-button'}" id="teamToggle">${inTeam?'УБРАТЬ ИЗ ОТРЯДА':'В ОТРЯД'}</button><button class="secondary-button" id="selectHero">ВЫБРАТЬ</button>`:`<button class="secondary-button" disabled>ЕЩЁ НЕ НАЙДЕН</button><button class="secondary-button" id="goSummon">ПРИЗЫВ →</button>`}</div>`;
    if (owned) {
      $('teamToggle').addEventListener('click', () => toggleTeam(h.id));
      $('selectHero').addEventListener('click', () => { save.selected=h.id; persist(); toast(`${h.name} выбран`); renderCharacters(); });
    } else $('goSummon').addEventListener('click', () => showView('summon'));
  }
  function toggleTeam(id) {
    if (save.team.includes(id)) {
      if (save.team.length===1) return toast('В отряде должен остаться хотя бы один герой.');
      save.team=save.team.filter(x=>x!==id);
      if (save.selected===id) save.selected=save.team[0];
      toast('Оперативник исключён из отряда.');
    } else {
      if (save.team.length>=3) return toast('В отряде может быть максимум три героя.');
      save.team.push(id); toast('Оперативник добавлен в отряд.');
    }
    persist(); renderCharacters(); renderHomeTeam(); renderWorkshop();
  }

  // Resonance system v0.4: separate character and weapon banners with persistent guarantees.
  let summonBanner='character';
  const BANNER_ROTATIONS=[
    {hero:'malika',weapon:'rail_lance',name:'КРАСНАЯ ЛИНИЯ',subtitle:'Дуэлянт Синдиката / линия прорыва'},
    {hero:'saodat',weapon:'astrolabe',name:'НЕБЕСНЫЙ РАСЧЁТ',subtitle:'Академия / точность и резонанс'},
    {hero:'kamila',weapon:'qobyz_core',name:'ТРЕТИЙ ГОЛОС',subtitle:'Архив / память и синхронизация'},
    {hero:'laylo',weapon:'navda_scythe',name:'ТИХАЯ ЭВОЛЮЦИЯ',subtitle:'Оазис / живой контроль'},
    {hero:'aziza',weapon:'glass_repeater',name:'СЕВЕРНЫЙ МАРШРУТ',subtitle:'Соль-9 / скорость и дальний бой'}
  ];
  const BANNER_WEEK_MS=7*24*60*60*1000;
  function currentBanner(){const week=Math.floor(Date.now()/BANNER_WEEK_MS);const index=((week%BANNER_ROTATIONS.length)+BANNER_ROTATIONS.length)%BANNER_ROTATIONS.length;return {...BANNER_ROTATIONS[index],index,cycle:week};}
  function bannerTimeLeft(){const end=(Math.floor(Date.now()/BANNER_WEEK_MS)+1)*BANNER_WEEK_MS;return Math.max(0,end-Date.now());}
  function formatRemaining(ms){const d=Math.floor(ms/86400000),h=Math.floor(ms%86400000/3600000);return `${d} дн. ${h} ч.`;}
  function renderSummonHistory(){const root=$('summonHistory');if(!root)return;const rows=(save.summonHistory||[]).slice(-30).reverse();root.innerHTML=rows.length?rows.map(x=>`<div class="summon-history-row"><time>${new Date(x.time).toLocaleDateString('ru-RU',{day:'2-digit',month:'2-digit'})}</time><b>${x.name} · ${x.banner==='weapon'?'ОРУЖИЕ':'ПЕРСОНАЖИ'}</b><strong>${x.rank===5?'5★':x.rank===4?'4★':'3★'}</strong></div>`).join(''):'<div class="summon-history-empty">История появится после первого призыва. Записи хранятся локально на устройстве.</div>';}
  function renderBannerCalendar(){const b=currentBanner(),hero=HERO_BY_ID[b.hero],weapon=WEAPONS.find(w=>w.id===b.weapon);$('bannerCalendar').innerHTML=`<div class="panel-kicker">КАЛЕНДАРЬ РОТАЦИИ / ЛОКАЛЬНЫЙ ЦИКЛ</div><b>${b.name}</b> · ${b.subtitle}<br>Персонаж: <b>${hero?.name||b.hero}</b> · оружие: <b>${weapon?.name||b.weapon}</b><br>Следующая смена через <b>${formatRemaining(bannerTimeLeft())}</b>. Гаранты сохраняются между ротациями.`;}
  function renderPity() {
    const weapon=summonBanner==='weapon',active=currentBanner();
    const featuredHero=HERO_BY_ID[active.hero],featuredWeapon=WEAPONS.find(w=>w.id===active.weapon);
    const heroName=featuredHero?.name||active.hero,weaponName=featuredWeapon?.name||active.weapon;
    const pity=weapon?save.weaponPity:save.pity,limit=weapon?70:80;
    $('pityValue').textContent=String(Math.max(0,limit-pity));
    $('pityBar').style.width=`${clamp(pity/limit*100,0,100)}%`;
    if(weapon){
      $('summonEyebrow').textContent='КАТТА-МАТРИЦА / ОРУЖЕЙНЫЙ КОНТУР';
      $('summonTitle').innerHTML='РЕЗОНАНСНЫЙ<br><em>АРСЕНАЛ</em>';
      $('summonDescription').textContent=`Сигнатурное оружие ротации: ${weaponName}. Гарант 5★ — 70 вызовов; шанс получить выбранное оружие при первом 5★ — 75%, после проигрыша следующий 5★ гарантированно будет ${weaponName}.`;
      $('summonOdds').textContent='4★ оружие гарантируется не реже одного раза за 10 вызовов. Дубликаты усиливают оружие до 10 уровня.';
      $('pityLabel').textContent='ДО ГАРАНТА 5★ ОРУЖИЯ';
      $('pityNote').textContent=`Вызовов: ${save.weaponPulls}. Гарант: ${save.weaponPity}/70. ${save.weaponFeaturedGuarantee?`Следующее 5★ оружие гарантированно: ${weaponName}.`:`Шанс получить ${weaponName} при 5★: 75%.`}`;
      $('pullOne').innerHTML='ОДИН ВЫЗОВ <b>✦ 160</b>';$('pullTen').innerHTML='ДЕСЯТЬ ВЫЗОВОВ <b>✦ 1 600</b>';
      $('weaponBannerTab').classList.add('active');$('characterBannerTab').classList.remove('active');
    }else{
      $('summonEyebrow').textContent='КАТТА-МАТРИЦА / ПОИСК СИГНАТУРЫ';
      $('summonTitle').innerHTML='РЕЗОНАНСНЫЙ<br><em>ВЫЗОВ</em>';
      $('summonDescription').textContent=`Ограниченный оперативник ротации: ${heroName}. Вероятность 5★ — 0,8%, гарант — 80 вызовов. При первом 5★ шанс получить ${heroName} — 50%; после проигрыша следующий 5★ гарантированно будет ${heroName}.`;
      $('summonOdds').textContent='4★ оперативник гарантируется не реже одного раза за 10 вызовов. Дубликаты превращаются во фрагменты памяти.';
      $('pityLabel').textContent='ДО ГАРАНТА 5★ ПЕРСОНАЖА';
      $('pityNote').textContent=`Вызовов: ${save.pulls}. Гарант: ${save.pity}/80. ${save.featuredGuarantee?`Следующий 5★ гарантированно: ${heroName}.`:`Шанс получить ${heroName} при 5★: 50%.`}`;
      $('pullOne').innerHTML='ОДИН ВЫЗОВ <b>✦ 160</b>';$('pullTen').innerHTML='ДЕСЯТЬ ВЫЗОВОВ <b>✦ 1 600</b>';
      $('characterBannerTab').classList.add('active');$('weaponBannerTab').classList.remove('active');
    }
    $('summonLog').innerHTML=`<div class="panel-kicker">ПОСЛЕДНИЕ СИГНАТУРЫ</div><span>${save.lastSummons?.length?save.lastSummons.slice(0,5).map(x=>x.name).join(' · '):'Матрица ожидает запроса.'}</span>`;renderBannerCalendar();renderSummonHistory();
  }
  function chooseWeighted(pool) { return pool[Math.floor(Math.random()*pool.length)]; }
  function summonCharacterOne() {
    const guaranteed5=save.pity>=79,guaranteed4=save.pity4>=9,r=Math.random();
    let rank=guaranteed5||r<.008?5:guaranteed4||r<.078?4:3;
    if(rank===5){save.pity=0;save.pity4=0;}else{save.pity++;if(rank===4)save.pity4=0;else save.pity4++;}
    save.pulls++;
    if(rank===3){save.credits+=180;return {type:'item',rank,name:'Калибровочный сплав',desc:'+180 кредитов',glyph:'◇'};}
    let hero;
    if(rank===5){
      const active=currentBanner(),featured=HERO_BY_ID[active.hero];
      if(save.featuredGuarantee||Math.random()<.5){hero=featured;save.featuredGuarantee=false;}
      else{hero=chooseWeighted(HEROES.filter(h=>h.rank===5&&h.id!==currentBanner().hero));save.featuredGuarantee=true;}
    }else hero=chooseWeighted(HEROES.filter(h=>h.rank===4));
    if(save.unlocked.includes(hero.id)){save.fragments[hero.id]=(save.fragments[hero.id]||0)+1;save.credits+=rank===5?550:260;return {type:'duplicate',rank,hero,name:hero.name,desc:'Фрагмент памяти +1',glyph:hero.glyph};}
    save.unlocked.push(hero.id);save.levels[hero.id]=1;return {type:'hero',rank,hero,name:hero.name,desc:'Новый оперативник',glyph:hero.glyph};
  }
  function grantWeaponPull(weapon,rank){
    const duplicate=save.ownedWeapons.includes(weapon.id);
    if(duplicate){save.weaponLevels[weapon.id]=Math.min(10,(save.weaponLevels[weapon.id]||1)+1);save.weaponFragments[weapon.id]=(save.weaponFragments[weapon.id]||0)+1;return {type:'weapon-duplicate',rank,name:weapon.name,desc:`Дубликат: уровень оружия ${save.weaponLevels[weapon.id]}/10`,glyph:'⚒'};}
    save.ownedWeapons.push(weapon.id);save.weaponLevels[weapon.id]=1;return {type:'weapon',rank,name:weapon.name,desc:'Новое оружие добавлено в мастерскую',glyph:'⚔'};
  }
  function summonWeaponOne(){
    const guaranteed5=save.weaponPity>=69,guaranteed4=save.weaponPity4>=9,r=Math.random();
    let rank=guaranteed5||r<.012?5:guaranteed4||r<.092?4:3;
    if(rank===5){save.weaponPity=0;save.weaponPity4=0;}else{save.weaponPity++;if(rank===4)save.weaponPity4=0;else save.weaponPity4++;}
    save.weaponPulls++;
    if(rank===3){save.credits+=160;return {type:'item',rank,name:'Детали оружия',desc:'+160 кредитов',glyph:'◇'};}
    let weapon;
    if(rank===5){const active=currentBanner(),featured=WEAPONS.find(w=>w.id===active.weapon);if(save.weaponFeaturedGuarantee||Math.random()<.75){weapon=featured;save.weaponFeaturedGuarantee=false;}else{weapon=chooseWeighted(WEAPONS.filter(w=>w.rank===5&&w.id!==currentBanner().weapon));save.weaponFeaturedGuarantee=true;}}
    else weapon=chooseWeighted(WEAPONS.filter(w=>w.rank===4));
    return grantWeaponPull(weapon,rank);
  }
  function summon(count){
    const cost=count===10?1600:160;if(save.signal<cost){toast('Недостаточно сигнальных кодов.');sound(120,.12,'sawtooth',.025);return;}
    save.signal-=cost;const results=[];
    for(let i=0;i<count;i++)results.push(summonBanner==='weapon'?summonWeaponOne():summonCharacterOne());
    save.lastSummons=results.map(r=>({name:r.name||r.hero?.name||r.desc,rank:r.rank}));
    const active=currentBanner();results.forEach(r=>save.summonHistory.push({time:Date.now(),banner:summonBanner,name:r.name||r.hero?.name||r.desc,rank:r.rank,featured:(r.hero?.id===active.hero)||(WEAPONS.find(w=>w.name===r.name)?.id===active.weapon)}));save.summonHistory=save.summonHistory.slice(-300);
    persist();renderPity();renderSummonHistory();renderCharacters();renderHomeTeam();renderWorkshop();
    $('summonResults').innerHTML=results.map(r=>`<div class="summon-result rarity-${r.rank}"><div class="result-glyph">${r.glyph}</div><b>${r.name||'МАТЕРИАЛ'}</b><small>${r.rank===5?'★★★★★':r.rank===4?'★★★★':'МАТЕРИАЛ'} · ${r.desc}</small></div>`).join('');
    $('summonModal').classList.remove('hidden');sound(610,.22,'sine',.05);setTimeout(()=>sound(820,.3,'triangle',.035),140);buzz(35);
  }
  $('characterBannerTab').addEventListener('click',()=>{summonBanner='character';renderPity();});
  $('weaponBannerTab').addEventListener('click',()=>{summonBanner='weapon';renderPity();});
  $('pullOne').addEventListener('click',()=>summon(1));$('pullTen').addEventListener('click',()=>summon(10));
  $('closeSummon').addEventListener('click',()=>$('summonModal').classList.add('hidden'));
  $('summonDone').addEventListener('click',()=>$('summonModal').classList.add('hidden'));

  // Workshop / equipment / progression.
  let selectedModuleSlot = 0;
  function loadoutBonuses(id){
    const weapon=WEAPONS.find(w=>w.id===(save.equippedWeapon[id]||'field_blade'))||WEAPONS[0];
    const modules=(save.equippedModules[id]||[]).map(mid=>MODULES.find(m=>m.id===mid)).filter(Boolean);
    const weaponAtk=weapon.atk+Math.max(0,(save.weaponLevels[weapon.id]||1)-1)*3;
    const mastery=save.weaponMastery[`${id}:${weapon.id}`]||{xp:0,level:0},masteryLevel=Math.min(5,Math.floor((mastery.xp||0)/50));
    const base=modules.reduce((acc,m)=>({hp:acc.hp+m.hp,atk:acc.atk+m.atk,speed:acc.speed+m.speed,hpBonus:acc.hpBonus+(m.hpBonus||0),atkBonus:acc.atkBonus+(m.atkBonus||0),speedBonus:acc.speedBonus+(m.speedBonus||0),critChance:acc.critChance+(m.critChance||0),skillPower:acc.skillPower*(m.skillPower||1),makomGain:acc.makomGain*(m.makomGain||1),damageReduction:acc.damageReduction+(m.damageReduction||0),range:acc.range+(m.range||0),thirdHitBonus:acc.thirdHitBonus+(m.thirdHitBonus||0),masteryLevel:acc.masteryLevel,masteryXp:acc.masteryXp}),{hp:weapon.hp,atk:weaponAtk+masteryLevel*2,speed:weapon.speed,hpBonus:(weapon.hpBonus||0)+masteryLevel*.008,atkBonus:weapon.atkBonus||0,speedBonus:weapon.speedBonus||0,critChance:(weapon.critChance||0)+masteryLevel*.004,skillPower:weapon.skillPower||1,makomGain:weapon.makomGain||1,damageReduction:weapon.damageReduction||0,range:weapon.range||0,thirdHitBonus:(weapon.thirdHitBonus||0)+masteryLevel*.012,masteryLevel,masteryXp:mastery.xp||0});
    return base;
  }
  function craftWeapon(id){
    const item=WEAPONS.find(w=>w.id===id);if(!item||save.ownedWeapons.includes(id))return;
    if(save.credits<item.cost||save.alloy<item.alloy)return toast('Недостаточно кредитов или сплавов.');
    save.credits-=item.cost;save.alloy-=item.alloy;save.ownedWeapons.push(id);save.weaponLevels[id]=1;save.equippedWeapon[save.selected]=id;
    persist();renderWorkshop();toast(`${item.name}: изготовлено и экипировано.`);sound(540,.14,'triangle',.035);
  }
  function craftModule(id){
    const item=MODULES.find(m=>m.id===id);if(!item||save.ownedModules.includes(id))return;
    if(save.credits<item.cost||save.alloy<item.alloy)return toast('Недостаточно кредитов или сплавов.');
    save.credits-=item.cost;save.alloy-=item.alloy;save.ownedModules.push(id);
    const equipped=save.equippedModules[save.selected]||(save.equippedModules[save.selected]=[]);
    if(equipped.length<4)equipped.push(id);
    persist();renderWorkshop();toast(`${item.name}: модуль изготовлен.`);
  }
  function equipModule(id){
    const equipped=save.equippedModules[save.selected]||(save.equippedModules[save.selected]=[]);
    if(equipped.includes(id))return toast('Этот модуль уже установлен.');
    equipped[selectedModuleSlot]=id;
    persist();renderWorkshop();toast(`Модуль установлен в слот ${selectedModuleSlot+1}.`);
  }
  function renderWorkshop() {
    let id=save.selected;if(!save.unlocked.includes(id))id=save.team[0]||'ayla';
    const h=HERO_BY_ID[id],level=save.levels[id]||1;
    if(!save.equippedWeapon[id])save.equippedWeapon[id]='field_blade';
    const weapon=WEAPONS.find(w=>w.id===save.equippedWeapon[id])||WEAPONS[0],weaponLevel=save.weaponLevels[weapon.id]||1;
    const equipped=save.equippedModules[id]||(save.equippedModules[id]=[]),bonus=loadoutBonuses(id),factionAura=getFactionResonance();
    $('workshopName').textContent=h.name;
    $('workshopPortrait').style.background=`radial-gradient(ellipse at 50% 37%,${h.color}33,transparent 44%),linear-gradient(145deg,#26362e,#121a17)`;
    const teamSynergy=getTeamSynergy();
    $('upgradePanel').innerHTML=`<h3>${h.full}</h3><div class="sub">${h.element} / ${h.role.toUpperCase()} / LV.${level}</div>
      <div class="upgrade-block team-synergy-panel"><div><b>КОМАНДНАЯ СИНЕРГИЯ · ${teamSynergy.name}</b><span>${teamSynergy.elements}/3 РЕЗОНАНСА</span></div><p>${teamSynergy.desc} При смене оперативника команда получает восстановление прочности; три разных резонанса дополнительно оглушают ближайших противников.</p></div><div class="loadout-summary"><span>АТАКА <b>${h.atk+(level-1)*7+bonus.atk}</b></span><span>ПРОЧНОСТЬ <b>${h.hp+(level-1)*52+bonus.hp}</b></span><span>СКОРОСТЬ <b>${h.speed+bonus.speed}</b></span></div>
      <div class="upgrade-block"><div><b>УРОВЕНЬ ОПЕРАТИВНИКА</b><span>${level} / 10</span></div><p>Увеличивает базовое здоровье и силу атак.</p><button class="primary-button" id="upgradeLevel" ${level>=10?'disabled':''}>УЛУЧШИТЬ · ${fmt(500*level)} ◈</button></div>
      <div class="upgrade-block"><div><b>ОРУЖИЕ / ${weapon.name}</b><span>LV.${weaponLevel} · +${weapon.atk+(weaponLevel-1)*3} ATK</span></div><p>${weapon.type}. ${weapon.desc}<br>Мастерство: ${bonus.masteryLevel}/5 · ${bonus.masteryXp%50}/50 XP · ${weapon.traitName}: ${weapon.traitDesc}</p><button class="secondary-button" id="upgradeWeapon" ${weaponLevel>=10?'disabled':''}>УСИЛИТЬ ОРУЖИЕ · ${fmt(350*weaponLevel)} ◈ + 1 ⌬</button></div>
      <div class="equipment-section"><div class="panel-kicker">СЛОТЫ МОДУЛЕЙ / 4</div><div class="module-slots">${[0,1,2,3].map(i=>`<button class="module-slot ${selectedModuleSlot===i?'active':''}" data-slot="${i}"><small>СЛОТ ${i+1}</small><b>${equipped[i]?(MODULES.find(m=>m.id===equipped[i])?.name||'МОДУЛЬ'):'ПУСТО'}</b></button>`).join('')}</div>
      <div class="panel-kicker module-head">ДОСТУПНЫЕ МОДУЛИ · СПЛАВЫ ${save.alloy}</div><div class="equipment-grid">${MODULES.map(m=>{const own=save.ownedModules.includes(m.id),inSet=equipped.includes(m.id);return `<div class="equipment-card ${own?'owned':''}"><b>${m.name}</b><small>${m.slot} · ${m.desc}</small><button data-module="${m.id}" ${inSet?'disabled':''}>${inSet?'УСТАНОВЛЕН':own?'УСТАНОВИТЬ':`ИЗГОТОВИТЬ · ${fmt(m.cost)} ◈ / ${m.alloy} ⌬`}</button></div>`}).join('')}</div></div>
      <div class="equipment-section"><div class="panel-kicker">АРСЕНАЛ / СПЛАВЫ ${save.alloy}</div><div class="equipment-grid">${WEAPONS.map(w=>{const own=save.ownedWeapons.includes(w.id),active=weapon.id===w.id;return `<div class="equipment-card ${own?'owned':''}"><b>${w.name}</b><small>${w.type} · +${w.atk} ATK · ${w.desc}<br><strong>${w.traitName}:</strong> ${w.traitDesc}</small><button data-weapon="${w.id}" ${active?'disabled':''}>${active?'ЭКИПИРОВАНО':own?'ЭКИПИРОВАТЬ':`ИЗГОТОВИТЬ · ${fmt(w.cost)} ◈ / ${w.alloy} ⌬`}</button></div>`}).join('')}</div></div>
      <div class="upgrade-block passive-workshop"><div><b>ПАССИВНЫЙ ПРОТОКОЛ · ${h.passive.name}</b><span>${save.storyAwakenings[id]?'ПРОБУЖДЁН':'АКТИВЕН'}</span></div><p>${h.passive.desc}${save.storyAwakenings[id]?' Личная история завершена: действует дополнительный бонус к атаке, навыку и критическому шансу.':''}</p></div><div class="upgrade-block"><div><b>ИНДИВИДУАЛЬНЫЙ БОЕВОЙ НАБОР</b><span>${h.combatKit.comboStyle}</span></div><p>Навык: ${h.skill} (${h.combatKit.skillPattern}). Ультимейт: ${h.ult} (${h.combatKit.ultPattern}). Уровень мастерства оружия учитывается отдельно для каждого героя.</p></div>
      <div class="upgrade-block faction-resonance"><div><b>РЕЗОНАНС ФРАКЦИИ · ${factionAura.name}</b><span>УР. ${factionAura.tier}/3</span></div><p>${factionAura.desc} Репутация ${factionAura.rep}/10; эффект действует в выбранном регионе.</p></div><div class="upgrade-block"><div><b>НАСЛЕДИЕ РЕШЕНИЙ · ${operationById(save.selectedRegion).name}</b><span>${(save.campaignFlags||[]).filter(x=>x.startsWith(save.selectedRegion+'_')).length}/3</span></div><p>${regionConsequenceSummary(save.selectedRegion)||'Заверши главы региона, чтобы решения сформировали постоянный боевой резонанс.'}</p></div>
      <div class="upgrade-block"><div><b>ФРАГМЕНТЫ ПАМЯТИ</b><span>${save.fragments[id]||0}</span></div><p>Дубликаты пока накапливаются как ресурс для будущего дерева пробуждения. В этой версии они не расходуются на отдельные ступени.</p></div>`;
    $('upgradeLevel')?.addEventListener('click',()=>{const cost=500*level;if(level>=10)return;if(save.credits<cost)return toast('Недостаточно кредитов.');save.credits-=cost;save.levels[id]=level+1;persist();renderWorkshop();renderCharacters();toast(`${h.name}: уровень повышен до ${level+1}.`);sound(520,.13,'triangle',.03);buzz(22);});
    $('upgradeWeapon')?.addEventListener('click',()=>{const lv=save.weaponLevels[weapon.id]||1,cost=350*lv;if(lv>=10)return;if(save.credits<cost||save.alloy<1)return toast('Нужны кредиты и 1 сплав.');save.credits-=cost;save.alloy--;save.weaponLevels[weapon.id]=lv+1;persist();renderWorkshop();toast(`${weapon.name}: уровень ${lv+1}.`);});
    document.querySelectorAll('[data-slot]').forEach(b=>b.addEventListener('click',()=>{selectedModuleSlot=Number(b.dataset.slot);renderWorkshop();}));
    document.querySelectorAll('[data-module]').forEach(b=>b.addEventListener('click',()=>{const mid=b.dataset.module;if(save.ownedModules.includes(mid))equipModule(mid);else craftModule(mid);}));
    document.querySelectorAll('[data-weapon]').forEach(b=>b.addEventListener('click',()=>{const wid=b.dataset.weapon;if(save.ownedWeapons.includes(wid)){save.equippedWeapon[id]=wid;persist();renderWorkshop();toast(`${WEAPONS.find(w=>w.id===wid).name} экипировано.`);}else craftWeapon(wid);}));
  }

  // Station 04: rooms, upgrades, small character interactions and persistent field buffs.
  let selectedStationRoom='hangar';
  function renderStation(){
    $('stationLevel').textContent=String(save.stationLevel).padStart(2,'0');
    $('stationStatus').textContent=save.stationLevel>=5?'УЗЕЛ ПОЛНОСТЬЮ ВОССТАНОВЛЕН':'ЭНЕРГИЯ СТАБИЛЬНА · УЗЕЛ '+save.stationLevel;
    $('stationDescription').textContent=`Уровень базы ${save.stationLevel}/5. Первые взаимодействия с помещениями дают разовые ресурсы; отношения с оперативниками сохраняются.`;
    $('upgradeStation').textContent=save.stationLevel>=5?'БАЗА МАКСИМАЛЬНОГО УРОВНЯ':`УЛУЧШИТЬ · ${fmt(1500*save.stationLevel)} ◈ / ${3*save.stationLevel} ⌬`;
    $('upgradeStation').disabled=save.stationLevel>=5;
    $('stationMap').innerHTML=STATION_ROOMS.map((r,i)=>`<button class="station-room ${selectedStationRoom===r.id?'selected':''}" data-room="${r.id}"><span>${r.icon}</span><b>${r.name}</b><small>${r.sub}</small><i>${save.roomFlags.includes(r.id)?'ОБСЛУЖЕНО':'ДОСТУПНО'}</i></button>`).join('');
    $('stationMap').querySelectorAll('[data-room]').forEach(b=>b.addEventListener('click',()=>{selectedStationRoom=b.dataset.room;renderStation();}));
    const room=STATION_ROOMS.find(r=>r.id===selectedStationRoom)||STATION_ROOMS[0],hero=HERO_BY_ID[save.selected]||HERO_BY_ID.ayla;
    const bond=save.bonds[hero.id]||0,flag=`${room.id}:${hero.id}`,bonded=save.bondFlags?.includes(flag),roomLevel=save.stationRoomLevels[room.id]||1,productionKey=room.production||'credits',productionValue=productionKey==='signal'?roomLevel*8:productionKey==='alloy'?roomLevel:roomLevel*12,productionLabel=productionKey==='signal'?'сигналы':productionKey==='alloy'?'сплавы':'кредиты';
    const lastLine=save.lastStationDialogue?.roomId===room.id&&save.lastStationDialogue?.heroId===hero.id?save.lastStationDialogue.text:'';
    const sceneReady=bond>=2&&!save.stationEventFlags.includes(hero.id);
    $('stationRoomDetail').innerHTML=`<div class="eyebrow">ПОМЕЩЕНИЕ / ${room.sub.toUpperCase()}</div><div class="station-room-icon">${room.icon}</div><h3>${room.name}</h3><p>${room.desc}</p><div class="room-effect">${room.effect}</div><div class="room-character"><span class="room-avatar" style="--hero-color:${hero.color}">${hero.glyph}</span><div><b>${hero.name}</b><small>ДОВЕРИЕ / ${bond} · ${bonded?'ЭТОТ РАЗГОВОР УЖЕ ЗАПИСАН':'НОВЫЙ РАЗГОВОР'}</small></div></div>${lastLine?`<blockquote class="station-dialogue">«${lastLine}»</blockquote>`:''}<button class="primary-button" id="roomInteract">${room.action} <b>→</b></button><div class="room-effect">УРОВЕНЬ ПОМЕЩЕНИЯ ${roomLevel}/3 · ПРОИЗВОДСТВО ${productionLabel}: ${productionValue} за завершённую операцию</div><button class="secondary-button" id="upgradeRoom" ${roomLevel>=3?'disabled':''}>УЛУЧШИТЬ ПОМЕЩЕНИЕ · ${fmt(650*roomLevel)} ◈ / ${roomLevel} ⌬</button>${sceneReady?`<button class="secondary-button bond-scene-button" id="bondScene">ОТКРЫТЬ СЦЕНУ ДОВЕРИЯ · ${hero.passive.name}</button>`:save.stationEventFlags.includes(hero.id)?'<div class="room-effect">ЛИЧНАЯ СЦЕНА СОХРАНЕНА В АРХИВЕ</div>':''}`;
    $('roomInteract').addEventListener('click',()=>interactRoom(room.id,hero.id));
    $('upgradeRoom')?.addEventListener('click',()=>upgradeStationRoom(room.id));
    $('bondScene')?.addEventListener('click',()=>triggerStationBondEvent(hero.id));
    $('stationVisitors').innerHTML=save.team.map(id=>{const h=HERO_BY_ID[id];return `<button class="visitor-chip ${save.selected===id?'active':''}" data-visitor="${id}"><span style="--hero-color:${h.color}">${h.glyph}</span><b>${h.name}</b><small>ДОВЕРИЕ ${save.bonds[id]||0}</small></button>`}).join('');
    $('stationVisitors').querySelectorAll('[data-visitor]').forEach(b=>b.addEventListener('click',()=>{save.selected=b.dataset.visitor;persist();renderStation();}));
    renderStationProduction();renderJointScenePanel();
    $('upgradeStation').onclick=()=>{const lv=save.stationLevel,cost=1500*lv,alloy=3*lv;if(lv>=5)return;if(save.credits<cost||save.alloy<alloy)return toast(`Нужно ${fmt(cost)} кредитов и ${alloy} сплавов.`);save.credits-=cost;save.alloy-=alloy;save.stationLevel++;persist();renderStation();toast(`Станция 04 улучшена до уровня ${save.stationLevel}.`);};
  }
  function upgradeStationRoom(roomId){const room=STATION_ROOMS.find(r=>r.id===roomId);if(!room)return;const lv=save.stationRoomLevels[roomId]||1,cost=650*lv,alloy=lv;if(lv>=3)return toast('Помещение достигло максимального уровня.');if(save.credits<cost||save.alloy<alloy)return toast(`Нужно ${fmt(cost)} кредитов и ${alloy} сплавов.`);save.credits-=cost;save.alloy-=alloy;save.stationRoomLevels[roomId]=lv+1;persist();renderStation();toast(`${room.name}: уровень ${lv+1}/3. Производство увеличено.`);}
  function renderStationProduction(){const root=$('stationProduction');if(!root)return;const st=save.stationStorage||{};root.innerHTML=`<div class="production-head"><b>РЕСУРСНЫЙ РЕЗЕРВ СТАНЦИИ</b><span>ПОСЛЕ ОПЕРАЦИЙ</span></div><div class="production-values"><span>◈ ${fmt(st.credits||0)}</span><span>✦ ${fmt(st.signal||0)}</span><span>⌬ ${fmt(st.alloy||0)}</span></div><button id="claimStationProduction" ${(st.credits||0)+(st.signal||0)+(st.alloy||0)<=0?'disabled':''}>ЗАБРАТЬ НАКОПЛЕННОЕ</button><small>Уровни помещений увеличивают пассивное производство после каждой победы.</small>`;$('claimStationProduction').addEventListener('click',()=>{const v=save.stationStorage; if(!v)return;save.credits+=v.credits||0;save.signal+=v.signal||0;save.alloy+=v.alloy||0;save.stationStorage={credits:0,signal:0,alloy:0};persist();renderStationProduction();toast('Ресурсы станции добавлены в запас.');});}
  function renderJointScenePanel(){const root=$('stationJointScenes');if(!root)return;const ready=save.team.length>=2&&!save.stationJointScenes.includes(save.team.slice(0,2).sort().join(':'));const pair=save.team.slice(0,2).map(id=>HERO_BY_ID[id]?.name||id).join(' + ');root.innerHTML=`<h3>СОВМЕСТНЫЙ РАЗБОР ОПЕРАЦИИ</h3><p>${save.team.length>=2?`На станции собрались ${pair}. Совместная сцена открывает командную синхронизацию.`:'Добавь второго оперативника в отряд, чтобы открыть совместную сцену.'}</p><button id="jointSceneButton" ${ready?'':'disabled'}>${ready?'ПРОВЕСТИ СОВМЕСТНУЮ СЦЕНУ':'СЦЕНА УЖЕ ЗАПИСАНА / НЕДОСТУПНА'}</button>`;root.querySelector('#jointSceneButton')?.addEventListener('click',()=>{const pairKey=save.team.slice(0,2).sort().join(':');if(save.stationJointScenes.includes(pairKey))return;save.stationJointScenes.push(pairKey);save.bonds[save.team[0]]=(save.bonds[save.team[0]]||0)+1;save.bonds[save.team[1]]=(save.bonds[save.team[1]]||0)+1;save.signal+=45;save.credits+=260;save.archiveFlags.push(`joint:${pairKey}`);persist();renderStation();toast(`Синхронизация ${pair}: отношения укреплены.`);sound(520,.25,'triangle',.035);});}
  function interactRoom(roomId,heroId){
    const room=STATION_ROOMS.find(r=>r.id===roomId),flag=`${roomId}:${heroId}`;
    if(!save.roomFlags.includes(roomId)){
      save.roomFlags.push(roomId);
      if(roomId==='hangar')save.alloy+=2;
      if(roomId==='quarters')save.rested=true;
      if(roomId==='workshop')save.alloy+=3;
      if(roomId==='archive'){save.signal+=35;save.archiveFlags.push('station_archive');}
      if(roomId==='greenhouse')save.alloy+=3;
      if(roomId==='observatory')save.signal+=25;
      toast(`Первое посещение: ${room.name}. Получены ресурсы станции.`);
    }else if(roomId==='quarters'){save.rested=true;toast('Отдых завершён. На следующую операцию действует бонус прочности.');}
    else toast(`${room.name}: ${room.effect}`);
    save.bondFlags=Array.isArray(save.bondFlags)?save.bondFlags:[];
    if(!save.bondFlags.includes(flag)){save.bondFlags.push(flag);save.bonds[heroId]=(save.bonds[heroId]||0)+1;}
    const lines=STATION_DIALOGUES[heroId]||STATION_DIALOGUES.default,index=save.dialogueIndex[heroId]||0;save.lastStationDialogue={roomId,heroId,text:lines[index%lines.length]};save.dialogueIndex[heroId]=index+1;
    persist();renderStation();
  }


  function triggerStationBondEvent(heroId){
    const h=HERO_BY_ID[heroId];if(!h||save.stationEventFlags.includes(heroId)||(save.bonds[heroId]||0)<2)return;
    save.stationEventFlags.push(heroId);save.bonds[heroId]=(save.bonds[heroId]||0)+2;save.credits+=220;save.signal+=20;save.archiveFlags.push(`bond-scene:${heroId}`);
    save.exploreLog.unshift(`${h.name}: сцена доверия — ${h.passive.scene}`);save.exploreLog=save.exploreLog.slice(0,12);
    persist();renderStation();renderArchive();toast(`${h.name}: личная сцена записана. +220 кредитов, +20 сигналов.`);sound(500,.22,'triangle',.03);
  }

  // Personal stories: three interactive chapters per featured operative.
  let selectedStoryId='ayla_memory';
  function renderStories(){
    const personal=$('personalStoryList');
    personal.innerHTML=PERSONAL_STORIES.map(st=>{const h=HERO_BY_ID[st.hero],progress=save.storyProgress[st.id]||0,open=save.unlocked.includes(st.hero)&&operationUnlocked(operationById(st.region));return `<button class="story-card ${selectedStoryId===st.id?'selected':''} ${open?'':'locked'}" data-story="${st.id}"><span>${h.name} · ${operationById(st.region).name}</span><b>${st.title}</b><small>${!open?'НУЖЕН ОПЕРАТИВНИК И ДОСТУП К РЕГИОНУ':progress>=st.chapters.length?'ПРОБУЖДЕНИЕ ОТКРЫТО':`ГЛАВА ${progress+1} / ${st.chapters.length}`}</small></button>`}).join('');
    personal.querySelectorAll('[data-story]').forEach(b=>b.addEventListener('click',()=>{selectedStoryId=b.dataset.story;renderStories();}));
    $('sideQuestList').innerHTML=SIDE_QUESTS.map(q=>{const open=operationUnlocked(operationById(q.region)),started=save.startedSideQuests.includes(q.id),done=save.completedSideQuests.includes(q.id),found=save.discoveredNodes.includes(q.node);return `<div class="sidequest-card ${open?'':'locked'}"><span>${q.giver} · ${operationById(q.region).name}</span><b>${q.title}</b><p>${q.desc}</p><small>${done?'ВЫПОЛНЕНО':!open?'РЕГИОН ЗАКРЫТ':found?'ЦЕЛЬ НАЙДЕНА':'ЦЕЛЬ: '+(SCOUT_NODES.find(n=>n.id===q.node)?.title||'ПОИСК')}</small><button data-quest="${q.id}" ${!open||done?'disabled':''}>${done?'ЗАВЕРШЕНО':!started?'ПРИНЯТЬ':found?'ЗАВЕРШИТЬ':'ОТКРЫТЬ РАЗВЕДКУ'}</button></div>`}).join('');
    $('sideQuestList').querySelectorAll('[data-quest]').forEach(b=>b.addEventListener('click',()=>sideQuestAction(b.dataset.quest)));
    const st=PERSONAL_STORIES.find(x=>x.id===selectedStoryId)||PERSONAL_STORIES[0],h=HERO_BY_ID[st.hero],progress=save.storyProgress[st.id]||0,open=save.unlocked.includes(st.hero)&&operationUnlocked(operationById(st.region));
    if(!open){$('storyDetail').innerHTML=`<div class="eyebrow">ДОСТУП ОГРАНИЧЕН</div><h3>${st.title}</h3><p>Нужен ${h.name} в коллекции и открытый регион ${operationById(st.region).name}. Получение персонажа не требует завершения платных действий.</p>`;return;}
    if(progress>=st.chapters.length){$('storyDetail').innerHTML=`<div class="eyebrow">ЛИЧНОЕ ДЕЛО ЗАКРЫТО</div><h3>${st.title}</h3><p>Все ${st.chapters.length} глав завершены. Личный протокол ${h.name} пробуждён. Решения сохранены в архиве; доверие: ${save.bonds[h.id]||0}.</p><div class="story-reward">ПРОБУЖДЕНИЕ · +${save.bonds[h.id]||0} ДОВЕРИЯ · БОЕВОЙ БОНУС АКТИВЕН</div>`;return;}
    const ch=st.chapters[progress],missionNeeded=!!ch.mission&&(save.personalMissionClears[st.id]||0)<progress+1;$('storyDetail').innerHTML=`<div class="eyebrow">ЛИЧНАЯ ИСТОРИЯ / ${h.name} / ГЛАВА ${progress+1} ИЗ ${st.chapters.length}</div><h3>${ch.title}</h3><p>${ch.text}</p>${missionNeeded?`<div class="campaign-objective">ЛИЧНАЯ МИССИЯ: ${ch.objective||'Исследуй место последнего сигнала, отбей атаку и вернись с данными.'}</div><button class="primary-button" id="startPersonalMission">НАЧАТЬ ЛИЧНУЮ МИССИЮ <b>↗</b></button>`:`<div class="story-choice-label">КАК ПОСТУПИТЬ?</div><div class="story-choices"><button data-choice="a">${ch.a}</button><button data-choice="b">${ch.b}</button></div><small class="story-footnote">Выбор влияет на запись истории, доверие и мир. Оба варианта сохраняют доступ к дальнейшему контенту.</small>`}`;
    $('startPersonalMission')?.addEventListener('click',()=>{activeCampaignRun=null;activeFieldRun=null;activePersonalRun={storyId:st.id,chapter:progress,hero:st.hero};save.selectedRegion=st.region;save.selectedScoutRegion=st.region;save.selected=st.hero;if(!save.team.includes(st.hero)){if(save.team.length>=3)save.team[2]=st.hero;else save.team.push(st.hero);}persist();startGame();});
    $('storyDetail').querySelectorAll('[data-choice]').forEach(b=>b.addEventListener('click',()=>completeStoryChoice(st.id,b.dataset.choice)));
  }
  function completeStoryChoice(id,choice){
    const st=PERSONAL_STORIES.find(x=>x.id===id);if(!st)return;
    const progress=save.storyProgress[id]||0;if(progress>=st.chapters.length)return;
    const ch=st.chapters[progress];if(ch.mission&&(save.personalMissionClears[id]||0)<progress+1)return toast('Сначала заверши личную боевую миссию.');
    save.storyChoices[id]=Array.isArray(save.storyChoices[id])?save.storyChoices[id]:[];save.storyChoices[id].push({chapter:progress+1,choice});
    save.storyProgress[id]=progress+1;save.bonds[st.hero]=(save.bonds[st.hero]||0)+(choice==='a'?2:1);save.credits+=ch.reward;if(choice==='b')save.alloy+=1;save.xp+=90;save.accountLevel=1+Math.floor(save.xp/600);
    if(save.storyProgress[id]>=st.chapters.length){save.storyAwakenings[st.hero]=true;save.signal+=60;save.exploreLog.unshift(`${HERO_BY_ID[st.hero].name}: личный протокол пробуждён.`);}
    save.exploreLog.unshift(`${HERO_BY_ID[st.hero].name}: ${ch.title} — выбор ${choice==='a'?ch.a:ch.b}.`);save.exploreLog=save.exploreLog.slice(0,12);
    persist();renderStories();renderCharacters();toast(`Глава завершена: +${ch.reward} кредитов${save.storyAwakenings[st.hero]?' · ЛИЧНЫЙ ПРОТОКОЛ ПРОБУЖДЁН':''}.`);sound(580,.18,'triangle',.035);
  }
  function sideQuestAction(id){
    const q=SIDE_QUESTS.find(x=>x.id===id);if(!q||save.completedSideQuests.includes(id))return;
    if(!save.startedSideQuests.includes(id)){save.startedSideQuests.push(id);persist();renderStories();toast(`Задание принято: ${q.title}. Найди цель через раздел «Разведка».`);return;}
    if(!save.discoveredNodes.includes(q.node)){save.selectedScoutRegion=q.region;showView('scouting');toast('Цель ещё не найдена. Проверь отмеченную точку в разведке.');return;}
    save.completedSideQuests.push(id);save.credits+=q.reward;save.alloy+=q.alloy;save.signal+=q.signal;addFactionRep(factionFor(q.region),2,q.title);save.xp+=100;save.accountLevel=1+Math.floor(save.xp/600);persist();renderStories();toast(`Операция выполнена: +${q.reward} кредитов, +${q.alloy} сплавов.`);
  }

  // Non-combat field exploration. Every node is a persistent discovery with a small lore/reward.
  const exploreCanvas=$('exploreCanvas'),exploreCtx=exploreCanvas?.getContext('2d');let activeFieldRun=null,activePersonalRun=null;let fieldSelectedTransport=0;
  function fieldPos(region=save.selectedScoutRegion){if(!save.fieldPositions[region])save.fieldPositions[region]={x:110,y:360};return save.fieldPositions[region];}
  function drawFieldMap(){if(!exploreCanvas||!exploreCtx)return;const region=save.selectedScoutRegion,map=FIELD_MAPS[region]||FIELD_MAPS.tashkent,p=fieldPos(region),c=exploreCtx,w=900,h=480;c.clearRect(0,0,w,h);c.fillStyle=map.ground;c.fillRect(0,0,w,h);c.strokeStyle='rgba(222,205,163,.09)';c.lineWidth=1;for(let x=20;x<w;x+=38){c.beginPath();c.moveTo(x,0);c.lineTo(x,h);c.stroke();}for(let y=20;y<h;y+=38){c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke();}
    // Ruined structures and service corridors differ by region palette.
    for(let i=0;i<15;i++){const x=40+(i*137)%820,y=34+(i*83)%405;c.fillStyle=i%2?'rgba(6,12,10,.26)':'rgba(208,183,130,.08)';c.fillRect(x,y,42+(i%4)*11,20+(i%3)*12);c.strokeStyle='rgba(210,190,145,.11)';c.strokeRect(x,y,42+(i%4)*11,20+(i%3)*12);}
    c.strokeStyle=map.accent+'88';c.lineWidth=3;c.setLineDash([8,9]);c.beginPath();c.moveTo(100,360);c.lineTo(450,250);c.lineTo(790,360);c.stroke();c.setLineDash([]);
    map.stops.forEach((stop,i)=>{c.fillStyle='rgba(205,176,119,.14)';c.beginPath();c.arc(stop.x,stop.y,22,0,Math.PI*2);c.fill();c.strokeStyle=map.accent;c.lineWidth=2;c.stroke();c.fillStyle='#e3d8bc';c.font='12px system-ui';c.fillText('T'+(i+1),stop.x-8,stop.y+4);c.font='10px system-ui';c.fillText(stop.name,stop.x-36,stop.y+34);});
    map.landmarks.forEach((n,i)=>{const found=save.fieldDiscovered.includes(`${region}:${n[0]}`);c.fillStyle=found?'#91b28e':map.accent;c.beginPath();c.arc(n[2],n[3],found?7:10,0,Math.PI*2);c.fill();c.strokeStyle='#101714';c.lineWidth=3;c.stroke();c.fillStyle='#e1dac7';c.font='11px system-ui';c.fillText(found?'✓':n[1],n[2]+13,n[3]-10);});
    c.save();c.translate(p.x,p.y);c.fillStyle='#eee4cc';c.beginPath();c.moveTo(0,-14);c.lineTo(11,11);c.lineTo(0,6);c.lineTo(-11,11);c.closePath();c.fill();c.strokeStyle=map.accent;c.lineWidth=3;c.stroke();c.restore();
    c.fillStyle='rgba(3,7,5,.58)';c.fillRect(12,12,240,28);c.fillStyle='#e2d8c4';c.font='12px system-ui';c.fillText(`${map.label} · ШАГИ ${save.fieldSteps||0}`,22,31);
  }
  function moveField(dx,dy){const p=fieldPos(),region=save.selectedScoutRegion;p.x=clamp(p.x+dx,45,855);p.y=clamp(p.y+dy,45,435);save.fieldSteps=(save.fieldSteps||0)+1;persist();drawFieldMap();updateFieldStatus();if(save.fieldSteps%6===0&&!save.fieldEncounterReady&&Math.random()<.38){save.fieldEncounterReady=true;persist();renderRegionEvents();toast('Перехвачен нестабильный сигнал. Проверь полевой канал.');}}
  function moveFieldTo(x,y){const p=fieldPos();p.x=clamp(x,45,855);p.y=clamp(y,45,435);save.fieldSteps=(save.fieldSteps||0)+1;persist();drawFieldMap();updateFieldStatus();if(save.fieldSteps%6===0&&!save.fieldEncounterReady&&Math.random()<.38){save.fieldEncounterReady=true;persist();renderRegionEvents();toast('Перехвачен нестабильный сигнал. Проверь полевой канал.');}}
  exploreCanvas?.addEventListener('pointerdown',e=>{const r=exploreCanvas.getBoundingClientRect();moveFieldTo((e.clientX-r.left)/r.width*900,(e.clientY-r.top)/r.height*480);});
  function updateFieldStatus(){const map=FIELD_MAPS[save.selectedScoutRegion]||FIELD_MAPS.tashkent,p=fieldPos(),nearest=map.landmarks.map(n=>({n,d:Math.hypot(p.x-n[2],p.y-n[3])})).sort((a,b)=>a.d-b.d)[0];$('fieldExploreStatus').textContent=nearest&&nearest.d<95?`Рядом: ${nearest.n[1]} · ${Math.round(nearest.d)} м. Нажми «Обыскать рядом».`: 'Перемещайся по сектору. Объекты отмечены светлыми маркерами; транспортные узлы — T1/T2/T3.';}
  function interactField(){const region=save.selectedScoutRegion,map=FIELD_MAPS[region]||FIELD_MAPS.tashkent,p=fieldPos(),near=map.landmarks.map(n=>({n,d:Math.hypot(p.x-n[2],p.y-n[3])})).sort((a,b)=>a.d-b.d)[0];if(!near||near.d>95){toast('Подойди ближе к объекту.');return;}const n=near.n,key=`${region}:${n[0]}`;if(save.fieldDiscovered.includes(key)){toast(`${n[1]} уже исследован.`);return;}save.fieldDiscovered.push(key);const scout=SCOUT_NODES.find(x=>x.region===region&&x.id===n[0])||SCOUT_NODES.find(x=>x.region===region);const reward=scout?.reward||150;if(scout?.rewardType==='alloy')save.alloy+=reward;else if(scout?.rewardType==='signal')save.signal+=reward;else save.credits+=reward;save.exploreLog.unshift(`${region.toUpperCase()} / ${n[1]}: ${n[4]}`);save.exploreLog=save.exploreLog.slice(0,15);save.archiveFlags.push(`field:${key}`);persist();renderScouting();toast(`Объект исследован: ${n[1]}. Данные внесены в архив.`);sound(470,.18,'triangle',.03);}
  function travelField(){const map=FIELD_MAPS[save.selectedScoutRegion]||FIELD_MAPS.tashkent,idx=(save.fieldTransportIndex[save.selectedScoutRegion]||0),next=(idx+1)%map.stops.length,stop=map.stops[next];save.fieldTransportIndex[save.selectedScoutRegion]=next;const p=fieldPos();p.x=stop.x;p.y=stop.y;persist();drawFieldMap();updateFieldStatus();toast(`Транспорт прибыл: ${stop.name}.`);sound(260,.2,'triangle',.025);}
  function renderRegionEvents(){const root=$('regionEventPanel');if(!root)return;const region=save.selectedScoutRegion,events=REGION_EVENTS.filter(e=>e.region===region&&(!e.branchChapter||save.campaignChoices[`${region}_${e.branchChapter}`]===e.branchChoice));const cards=events.map(e=>{const done=save.regionEventClaims.includes(e.id),started=save.regionEventStarts.includes(e.id),faction=factionFor(region);return `<article class="region-event-card ${done?'done':''}"><small>${e.kind} · ${faction}</small><b>${e.title}</b><p>${e.desc}</p><button data-region-event="${e.id}" ${done?'disabled':''}>${done?'СОБЫТИЕ ЗАВЕРШЕНО':started?'ПРОДОЛЖИТЬ СРАЖЕНИЕ':'НАЧАТЬ ПОЛЕВОЕ СОБЫТИЕ'}</button></article>`;}).join('');root.innerHTML=`<div class="region-events-head"><div><div class="eyebrow">ПОСЛЕДСТВИЯ / СЛУЧАЙНЫЕ ВСТРЕЧИ</div><h3>ДИНАМИЧЕСКИЕ СОБЫТИЯ РЕГИОНА</h3></div><span>${events.filter(e=>save.regionEventClaims.includes(e.id)).length}/${events.length} ЗАКРЫТО</span></div><div class="region-event-grid">${cards||'<div class="campaign-empty">События появятся после продвижения по главам региона. Исследуй сектор или продолжи кампанию.</div>'}</div>${save.fieldEncounterReady?'<button class="primary-button" id="fieldEncounterStart">ПЕРЕХВАТИТЬ СЛУЧАЙНЫЙ СИГНАЛ / НАЧАТЬ БОЙ</button>':''}`;root.querySelectorAll('[data-region-event]').forEach(b=>b.addEventListener('click',()=>{const ev=REGION_EVENTS.find(x=>x.id===b.dataset.regionEvent);if(!ev)return;save.selectedRegion=region;if(!save.regionEventStarts.includes(ev.id))save.regionEventStarts.push(ev.id);persist();activeFieldRun={eventId:ev.id,region};showView('expeditions');startGame();}));root.querySelector('#fieldEncounterStart')?.addEventListener('click',()=>{save.selectedRegion=region;activeFieldRun={eventId:`random_${region}`,region,random:true};save.fieldEncounterReady=false;persist();showView('expeditions');startGame();});}
  function renderScouting(){
    const openOps=OPERATIONS.filter(operationUnlocked),found=save.discoveredNodes.length;$('scoutProgress').textContent=`${String(found).padStart(2,'0')} / ${SCOUT_NODES.length}`;
    $('scoutRegionTabs').innerHTML=OPERATIONS.map(op=>`<button class="scout-tab ${save.selectedScoutRegion===op.id?'active':''} ${operationUnlocked(op)?'':'locked'}" data-scout-region="${op.id}" ${operationUnlocked(op)?'':'disabled'}>${op.name}</button>`).join('');
    $('scoutRegionTabs').querySelectorAll('[data-scout-region]').forEach(b=>b.addEventListener('click',()=>{save.selectedScoutRegion=b.dataset.scoutRegion;persist();renderScouting();}));
    if(!openOps.some(o=>o.id===save.selectedScoutRegion))save.selectedScoutRegion=openOps[0]?.id||'tashkent';
    const op=operationById(save.selectedScoutRegion),nodes=SCOUT_NODES.filter(n=>n.region===op.id);$('scoutRegionBrief').innerHTML=`<div><div class="eyebrow">ПОЛЕВОЙ МАРШРУТ / ${op.zone}</div><h3>${op.name} — ${op.title}</h3><p>${op.desc} Здесь можно искать точки интереса без боя и получать сведения для побочных заданий.</p></div><span>${nodes.filter(n=>save.discoveredNodes.includes(n.id)).length} / ${nodes.length} НАЙДЕНО</span>`;
    $('scoutNodeGrid').innerHTML=nodes.map(n=>{const discovered=save.discoveredNodes.includes(n.id);return `<article class="scout-node ${discovered?'discovered':''}"><span>${n.kind}</span><b>${n.title}</b><p>${n.desc}</p><small>${discovered?'ДАННЫЕ СОХРАНЕНЫ':'НЕ ИССЛЕДОВАНО'}</small><button data-node="${n.id}" ${discovered?'disabled':''}>${discovered?'НАЙДЕНО':'ИССЛЕДОВАТЬ'}</button></article>`}).join('');
    $('scoutNodeGrid').querySelectorAll('[data-node]').forEach(b=>b.addEventListener('click',()=>discoverNode(b.dataset.node)));
    $('scoutLog').innerHTML=`<div class="panel-kicker">ПОЛЕВЫЕ ЗАПИСИ</div>${save.exploreLog.length?save.exploreLog.slice(0,6).map(x=>`<p>${x}</p>`).join(''):'<p>Разведывательный канал ожидает данные.</p>'}`;
    $('fieldRegionLabel').textContent=(FIELD_MAPS[op.id]||FIELD_MAPS.tashkent).label;drawFieldMap();updateFieldStatus();renderRegionEvents();
  }
  function discoverNode(id){
    const n=SCOUT_NODES.find(x=>x.id===id);if(!n||save.discoveredNodes.includes(id)||!operationUnlocked(operationById(n.region)))return;
    save.discoveredNodes.push(id);
    if(n.rewardType==='credits')save.credits+=n.reward;else if(n.rewardType==='alloy')save.alloy+=n.reward;else if(n.rewardType==='signal')save.signal+=n.reward;
    save.exploreLog.unshift(`${operationById(n.region).name} / ${n.title}: ${n.lore}`);save.exploreLog=save.exploreLog.slice(0,12);
    save.archiveFlags.push(`scout:${id}`);persist();renderScouting();renderStories();toast(`Точка исследована: ${n.title}. ${n.rewardType==='alloy'?`+${n.reward} сплавов`:n.rewardType==='signal'?`+${n.reward} сигналов`:`+${n.reward} кредитов`}.`);sound(430,.16,'triangle',.03);
  }
  $('fieldNorth')?.addEventListener('click',()=>moveField(0,-42));$('fieldSouth')?.addEventListener('click',()=>moveField(0,42));$('fieldWest')?.addEventListener('click',()=>moveField(-42,0));$('fieldEast')?.addEventListener('click',()=>moveField(42,0));$('fieldInteract')?.addEventListener('click',interactField);$('fieldTransport')?.addEventListener('click',travelField);$('fieldSignal')?.addEventListener('click',()=>{if(!save.fieldEncounterReady){save.fieldEncounterReady=true;renderRegionEvents();toast('Сигнал перехвачен: в секторе обнаружена нестабильная цель.');}else toast('Случайный сигнал уже ожидает перехвата.');});
  exploreCanvas?.addEventListener('pointerdown',e=>{const r=exploreCanvas.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*900,y=(e.clientY-r.top)/r.height*480,p=fieldPos();moveField(x-p.x,y-p.y);});

  // Faction standing: chapter decisions, regional clears and contracts contribute to reputation.
  function addFactionRep(name,amount,reason=''){
    if(!name)return;save.factionRep[name]=Math.max(0,Math.min(10,(save.factionRep[name]||0)+amount));
    if(reason){save.exploreLog.unshift(`${name}: +${amount} репутации — ${reason}.`);save.exploreLog=save.exploreLog.slice(0,12);}
  }
  function renderFactionContacts(){const root=$('factionContactsPanel');if(!root)return;root.innerHTML=FACTION_CONTACTS.map(n=>{const open=operationUnlocked(operationById(n.region)),bond=save.factionContactBonds[n.id]||0,done=save.factionContactFlags.includes(n.id);return `<article class="faction-contact ${open?'':'locked'}"><small>${n.faction}</small><b>${n.name}</b><small>${n.role}</small><p>${n.bio}</p><button data-contact="${n.id}" ${open?'':'disabled'}>${done?`ОБЩАТЬСЯ · ${bond} СВЯЗИ`:'ПРЕДСТАВИТЬСЯ'}</button></article>`;}).join('');root.querySelectorAll('[data-contact]').forEach(b=>b.addEventListener('click',()=>interactFactionContact(b.dataset.contact)));}
  function interactFactionContact(id){const n=FACTION_CONTACTS.find(x=>x.id===id);if(!n||!operationUnlocked(operationById(n.region)))return;const bond=save.factionContactBonds[id]||0,line=n.lines[bond%n.lines.length];save.factionContactBonds[id]=bond+1;if(!save.factionContactFlags.includes(id)){save.factionContactFlags.push(id);save.credits+=n.reward.credits||0;save.signal+=n.reward.signal||0;save.alloy+=n.reward.alloy||0;addFactionRep(n.faction,1,`контакт с ${n.name}`);}else if(bond%3===2){addFactionRep(n.faction,1,`обсуждение с ${n.name}`);save.signal+=15;}save.exploreLog.unshift(`${n.name}: «${line}»`);save.exploreLog=save.exploreLog.slice(0,15);persist();renderArchive();toast(`${n.name}: «${line}»`);sound(460,.16,'triangle',.03);}
  function renderArchive(){
    const root=$('factionPanel');if(!root)return;
    const milestones=[3,6,10];
    root.innerHTML=FACTION_DETAILS.map((f,i)=>{const rep=save.factionRep[f.name]||0,next=milestones.find(m=>rep<m)||null,claimed=save.factionClaims[f.name]||[];return `<article class="faction-card"><div class="faction-top"><span>${f.mark}</span><div><b>${f.name}</b><small>${f.motto}</small></div><strong>${rep}/10</strong></div><p>${f.desc}</p><div class="faction-track"><i style="width:${clamp(rep/10*100,0,100)}%"></i></div><div class="faction-milestones">${milestones.map((m,j)=>{const done=rep>=m,was=claimed.includes(m);return `<div class="faction-milestone ${done?'ready':''} ${was?'claimed':''}"><small>РАНГ ${j+1} · ${m}</small><b>${['150 сигнальных кодов','3 сплава','600 кредитов'][j]}</b><button data-faction="${i}" data-milestone="${m}" ${!done||was?'disabled':''}>${was?'ПОЛУЧЕНО':done?'ЗАБРАТЬ':'ЗАКРЫТО'}</button></div>`}).join('')}</div></article>`}).join('');
    root.querySelectorAll('[data-faction]').forEach(b=>b.addEventListener('click',()=>claimFactionReward(Number(b.dataset.faction),Number(b.dataset.milestone))));
    renderFactionContacts();renderFactionArcs();
    const archive=document.querySelector('#view-archive .archive-grid');
    if(archive&&!archive.querySelector('.epilogue-archive-card')){const ep=document.createElement('article');ep.className='archive-card epilogue-archive-card';ep.innerHTML=`<span>03 / ПОСЛЕДСТВИЯ</span><b>Эпилоги решений</b><p>${save.routeHistory.length} решений записано. ${save.mainEnding?`Финал: ${save.mainEnding.title}.`:'Финальный эпилог откроется после завершения пяти региональных линий.'} ${save.worldFlags.length} мировых флагов изменено.</p><small>СТАТУС: ${save.mainEnding?'ФИНАЛ ЗАПИСАН':'АРХИВ ПОПОЛНЯЕТСЯ'}</small>`;archive.appendChild(ep);}
  }
  function claimFactionReward(index,milestone){
    const f=FACTION_DETAILS[index];if(!f)return;const rep=save.factionRep[f.name]||0,claims=save.factionClaims[f.name]||(save.factionClaims[f.name]=[]);if(rep<milestone||claims.includes(milestone))return;
    if(milestone===3)save.signal+=150;else if(milestone===6)save.alloy+=3;else save.credits+=600;
    claims.push(milestone);persist();renderArchive();toast(`Награда получена: ${f.name}.`);sound(520,.14,'triangle',.035);
  }

  // Settings
  const MUSIC_THEMES={base:[196,246.94,293.66],tashkent:[146.83,174.61,220],samarkand:[220,277.18,329.63],fergana:[164.81,196,246.94],aral:[130.81,164.81,196],kyzylkum:[110,146.83,185],battle:[82.41,123.47,164.81]};
  let musicTimer=null,musicGain=null,musicScene='base',musicStep=0;
  function playMusicTone(freq,duration=.75,volume=.035){if(!save.music||save.musicVolume<=0)return;try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain(),filter=audioCtx.createBiquadFilter();o.type='sine';o.frequency.value=freq;filter.type='lowpass';filter.frequency.value=720;g.gain.setValueAtTime(0,audioCtx.currentTime);g.gain.linearRampToValueAtTime(Math.max(.001,volume*save.musicVolume),audioCtx.currentTime+.18);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(filter);filter.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration+.03);}catch(e){}}
  function stopMusic(){if(musicTimer){clearInterval(musicTimer);musicTimer=null;}}
  function setMusicScene(scene='base'){musicScene=scene;stopMusic();if(!save.music||save.musicVolume<=0)return;const notes=MUSIC_THEMES[scene]||MUSIC_THEMES.base;musicStep=0;const beat=()=>{const base=notes[musicStep%notes.length],oct=musicStep%4===3?2:1;playMusicTone(base*oct,1.35,.07);if(musicStep%4===0)playMusicTone(base*.5,1.8,.045);musicStep++;};beat();musicTimer=setInterval(beat,1350);}
  function deviceProfile(){const mem=navigator.deviceMemory||4,cores=navigator.hardwareConcurrency||4,screenArea=(window.innerWidth||390)*(window.innerHeight||844);return mem<=2||cores<=4||screenArea<300000?'low':mem<=4||cores<=6?'balanced':'high';}
  function resolvedQuality(){const q=save.quality||'auto';return q==='auto'?deviceProfile():q;}
  function applyRenderProfile(){const q=resolvedQuality();game.quality=q==='low'?'low':'high';game.frameInterval=q==='low'?1000/30:q==='balanced'?1000/45:1000/60;dpr=Math.min(window.devicePixelRatio||1,q==='low'?1:q==='balanced'?1.25:1.6);if($('deviceProfile'))$('deviceProfile').textContent=`${q.toUpperCase()} · ${Math.round(1000/game.frameInterval)} FPS`;resizeCanvas();}

  function openSettings() {
    $('soundToggle').classList.toggle('on',save.sound); $('soundToggle').textContent=save.sound?'ВКЛ':'ВЫКЛ';
    $('vibrationToggle').classList.toggle('on',save.vibration); $('vibrationToggle').textContent=save.vibration?'ВКЛ':'ВЫКЛ';
    $('qualitySelect').value=save.quality||'auto';$('musicToggle').classList.toggle('on',save.music!==false);$('musicToggle').textContent=save.music!==false?'ВКЛ':'ВЫКЛ';$('musicVolume').value=String(save.musicVolume??.12);applyRenderProfile(); $('settingsModal').classList.remove('hidden');
  }
  $('closeSettings').addEventListener('click',()=> $('settingsModal').classList.add('hidden'));
  $('settingsDone').addEventListener('click',()=> $('settingsModal').classList.add('hidden'));
  $('soundToggle').addEventListener('click',()=>{save.sound=!save.sound;openSettings();persist();});
  $('vibrationToggle').addEventListener('click',()=>{save.vibration=!save.vibration;openSettings();persist();});
  $('qualitySelect').addEventListener('change',e=>{save.quality=e.target.value;persist();applyRenderProfile();});
  $('musicToggle').addEventListener('click',()=>{save.music=!save.music;$('musicToggle').classList.toggle('on',save.music);$('musicToggle').textContent=save.music?'ВКЛ':'ВЫКЛ';persist();setMusicScene(musicScene);});
  $('musicVolume').addEventListener('input',e=>{save.musicVolume=Number(e.target.value);persist();if(save.musicVolume===0)stopMusic();else setMusicScene(musicScene);});

  $('resetSave').addEventListener('click',()=>{
    if(!confirm('Удалить локальный прогресс и начать заново?')) return;
    localStorage.removeItem('turan_save_v1'); location.reload();
  });
  $('startMission').addEventListener('click',startGame);
  $('continueMission').addEventListener('click',()=>showView('expeditions'));

  // Battle engine
  const canvas=$('gameCanvas'), ctx=canvas.getContext('2d');
  let cw=window.innerWidth,ch=window.innerHeight,dpr=1;
  const WORLD={w:1600,h:1120};
  const game={active:false,paused:false,ended:false,last:0,lastRender:0,frameInterval:16.67,time:0,wave:1,waveTransition:0,enemies:[],projectiles:[],enemyShots:[],particles:[],fields:[],decor:[],keys:{},move:{x:0,y:0},player:null,teamIndex:0,combo:0,comboTimer:0,makom:0,quality:'high',restedBuff:false};
  function resizeCanvas(){
    cw=window.innerWidth;ch=window.innerHeight;const q=resolvedQuality?resolvedQuality():(save.quality||'high');dpr=Math.min(window.devicePixelRatio||1,q==='low'?1:q==='balanced'?1.25:1.6);
    canvas.width=Math.floor(cw*dpr);canvas.height=Math.floor(ch*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  window.addEventListener('resize',resizeCanvas); resizeCanvas();

  function currentHero(){return HERO_BY_ID[save.team[game.teamIndex]||save.team[0]||'ayla'];}
  function heroLevel(id){return save.levels[id]||1;}
  function getTeamSynergy(){
    const members=save.team.map(id=>HERO_BY_ID[id]).filter(Boolean);const elements=new Set(members.map(h=>h.element));
    const bond=members.reduce((n,h)=>n+(save.bonds[h.id]||0),0);const pairs=members.length*(members.length-1)/2;
    const diversity=Math.max(0,elements.size-1);const bondRank=Math.min(3,Math.floor(bond/4));
    return {name:elements.size>=3?'ТРИАДА РЕЗОНАНСА':elements.size===2?'ДВОЙНОЙ РЕЗОНАНС':'ЕДИНЫЙ КОНТУР',elements:elements.size,atk:diversity*.035+bondRank*.012,hp:diversity*.025+bondRank*.01,makom:1+diversity*.08+bondRank*.025,desc:`${elements.size} разных резонанса · ${bondRank} ступени доверия. +${Math.round((diversity*.035+bondRank*.012)*100)}% атаки, +${Math.round((diversity*.025+bondRank*.01)*100)}% прочности.`};
  }
  function makePlayer(id,x,y){
    const h=HERO_BY_ID[id],lv=heroLevel(id),bonus=loadoutBonuses(id),passive=HERO_PASSIVES[id]||{},route=getRouteAura(),faction=getFactionResonance(),world=getWorldConsequenceAura(save.selectedRegion),awakened=!!save.storyAwakenings[id],synergy=getTeamSynergy();
    const hpBase=h.hp+(lv-1)*52+bonus.hp+Math.round(h.hp*((passive.hpBonus||0)+bonus.hpBonus+faction.hpBonus+synergy.hp)+(awakened?45:0))+(game.restedBuff?100:0)+route.hpBonus+world.hpFlat+Math.round(h.hp*world.hpBonus);
    const maxHp=hpBase;
    return {id,x,y,r:18,maxHp,hp:maxHp,atk:(h.atk+(lv-1)*7+bonus.atk)*(1+(passive.atkBonus||0)+bonus.atkBonus+route.atkBonus+faction.atkBonus+world.atkBonus+synergy.atk+(awakened?.03:0)),speed:Math.max(150,h.speed+bonus.speed+(passive.speedBonus||0)+bonus.speedBonus+route.speedBonus+faction.speedBonus+world.speedBonus),energy:0,faceX:0,faceY:1,attackCd:0,skillCd:0,dashCd:0,invuln:0,stun:0,attackAnim:0,skillAnim:0,dashTime:0,combo:0,trail:[],level:lv,passive,critChance:(passive.critChance||0)+bonus.critChance+faction.critChance+world.critChance+(awakened?.025:0),skillPower:(passive.skillPower||1)*bonus.skillPower*faction.skillPower*world.skillPower*(awakened?1.08:1),skillCooldown:passive.skillCooldown||1,makomGain:(passive.makomGain||1)*bonus.makomGain*route.makomGain*faction.makomGain*world.makomGain*synergy.makom,damageReduction:clamp((passive.damageReduction||0)+bonus.damageReduction+route.damageReduction+faction.damageReduction+world.damageReduction,0,.38),attackRange:(passive.attackRange||0)+bonus.range,thirdHitBonus:(passive.thirdHitBonus||0)+bonus.thirdHitBonus,swapPulse:passive.swapPulse||0,dashPulse:passive.dashPulse||0,combatKit:h.combatKit,weapon:WEAPONS.find(w=>w.id===(save.equippedWeapon[id]||'field_blade'))||WEAPONS[0],weaponMastery:bonus.masteryLevel||0,counter:0,shieldTime:0,markTime:0};
  }
  function initDecor(){
    game.decor=[];
    for(let i=0;i<50;i++) game.decor.push({x:rand(35,WORLD.w-80),y:rand(35,WORLD.h-80),w:rand(25,95),h:rand(15,60),type:Math.floor(rand(0,4)),alpha:rand(.08,.25)});
  }
  function showBossIntro(){const op=operationById(save.selectedRegion),info=BOSS_INTROS[op.id]||{tag:'РЕГИОНАЛЬНАЯ ЦЕЛЬ',line:'Центральный протокол переходит в защитный режим.',mechanic:'Изучай телеграфы и меняй дистанцию.'};$('bossIntroRegion').textContent=`${op.name} / ${info.tag}`;$('bossIntroTitle').textContent=op.boss;$('bossIntroText').textContent=info.line;$('bossIntroTags').innerHTML=info.mechanic.split(' · ').map(x=>`<span>${x}</span>`).join('');game.paused=true;$('bossIntroOverlay').classList.remove('hidden');}
  $('bossIntroContinue')?.addEventListener('click',()=>{$('bossIntroOverlay').classList.add('hidden');game.paused=false;game.last=performance.now();});
  function startGame(){
    if(game.active) return;
    if(!operationUnlocked(operationById(save.selectedRegion))){showView('expeditions');toast('Эта экспедиция пока закрыта.');return;}
    if(!save.team.length) save.team=['ayla'];
    game.active=true;game.paused=false;game.ended=false;game.time=0;game.wave=1;game.waveTransition=0;game.teamIndex=Math.max(0,save.team.indexOf(save.selected));$('bossIntroOverlay')?.classList.add('hidden');setMusicScene('battle');
    game.restedBuff=!!save.rested;save.rested=false;
    game.player=makePlayer(currentHero().id,WORLD.w/2,WORLD.h/2);
    game.enemies=[];game.projectiles=[];game.enemyShots=[];game.particles=[];game.fields=[];game.move={x:0,y:0};game.combo=0;game.comboTimer=0;game.makom=0;
    initDecor();spawnWave(1);persist();$('menuScreen').classList.add('hidden');$('topbar').classList.add('hidden');$('gameScreen').classList.remove('hidden');$('pauseOverlay').classList.add('hidden');$('resultOverlay').classList.add('hidden');
    const campaignChapter=activeCampaignRun&&activeCampaignRun.region===save.selectedRegion?CAMPAIGN[activeCampaignRun.region][activeCampaignRun.chapter-1]:null;const personalChapter=activePersonalRun?PERSONAL_STORIES.find(x=>x.id===activePersonalRun.storyId)?.chapters[activePersonalRun.chapter]:null;const fieldEvent=activeFieldRun?REGION_EVENTS.find(x=>x.id===activeFieldRun.eventId):null;
    $('gameObjective').textContent=campaignChapter?campaignChapter.objective:personalChapter?`ЛИЧНАЯ МИССИЯ: ${personalChapter.title}`:fieldEvent?`СОБЫТИЕ: ${fieldEvent.title}`:activeFieldRun?.random?'ПЕРЕХВАТИТЬ СЛУЧАЙНУЮ ЦЕЛЬ':`${operationById(save.selectedRegion).name}: ${operationById(save.selectedRegion).title}`;$('battleRegionLabel').textContent=`${operationById(save.selectedRegion).name} · ${operationById(save.selectedRegion).zone}`;$('waveLabel').textContent='ВОЛНА 01 / 03';
    updateBattleHud();game.last=performance.now();requestAnimationFrame(loop);sound(220,.2,'sawtooth',.025);battleToast(campaignChapter?`ГЛАВА ${activeCampaignRun.chapter}: ${campaignChapter.title}`:'СИГНАЛ ОБНАРУЖЕН');
  }
  function returnToMenu(){
    game.active=false;game.paused=false;game.ended=true;resetTouch();$('gameScreen').classList.add('hidden');$('menuScreen').classList.remove('hidden');$('topbar').classList.remove('hidden');$('pauseOverlay').classList.add('hidden');$('resultOverlay').classList.add('hidden');
    persist();renderHomeTeam();renderCharacters();renderWorkshop();showView('home');setMusicScene('base');
  }
  function spawnEnemy(type,x,y){
    const cfg={
      drone:{hp:210,damage:70,speed:95,r:17,color:'#bd8b5c',xp:18},
      stalker:{hp:290,damage:85,speed:125,r:19,color:'#9aaf89',xp:22},
      shooter:{hp:230,damage:65,speed:76,r:16,color:'#8caeb1',xp:22},
      heavy:{hp:620,damage:145,speed:56,r:27,color:'#b17b60',xp:36},
      lurker:{hp:250,damage:105,speed:168,r:16,color:'#b68a70',xp:28},
      disruptor:{hp:315,damage:78,speed:88,r:20,color:'#9d8eb8',xp:34},
      spore:{hp:360,damage:92,speed:68,r:22,color:'#8eb17f',xp:34},
      warden:{hp:740,damage:118,speed:48,r:29,color:'#a9a18a',xp:48},
      boss:{hp:4800,damage:190,speed:70,r:52,color:operationById(save.selectedRegion).color,xp:220}
    }[type] || {hp:250,damage:80,speed:90,r:18,color:'#9aaf89',xp:20};
    const scale=1+(save.wins*.055)+(Math.max(0,save.accountLevel-1)*.018);
    game.enemies.push({type,x,y,r:cfg.r,hp:cfg.hp*scale,maxHp:cfg.hp*scale,damage:cfg.damage*scale,speed:cfg.speed,color:cfg.color,xp:cfg.xp,cd:rand(.4,1.3),attackAnim:0,stun:0,flash:0,phase:0,telegraph:0,angle:0,dead:false,region:save.selectedRegion,threshold:0,summons:0,enrage:0,specialCd:4.2,specialTelegraph:0,specialPattern:0,arenaPulse:rand(5,8)});
  }
  function spawnWave(w){
    const op=operationById(save.selectedRegion);
    game.wave=w;game.waveTransition=0;game.enemies=[];game.enemyShots=[];
    if(w===1){
      const set=op.enemyPool;
      for(let i=0;i<(activePersonalRun?3:activeFieldRun?3:4);i++) spawnEnemy(set[i%set.length],rand(500,1100),rand(230,710));
      $('gameObjective').textContent=activePersonalRun?'ЛИЧНОЕ ДЕЛО: НАЙТИ СЛЕД':activeFieldRun?'ПОЛЕВОЕ СОБЫТИЕ: УДЕРЖАТЬ СЕКТОР':`${op.name}: ИССЛЕДУЙ СЕКТОР`;
    }else if(w===2){
      const set=op.enemyPool;
      for(let i=0;i<7;i++) spawnEnemy(set[(i+1)%set.length],rand(430,1180),rand(180,840));
      $('gameObjective').textContent='ПРОРВИСЬ К ЦЕНТРАЛЬНОМУ УЗЛУ';
      battleToast('ОБНАРУЖЕН ЭЛИТНЫЙ ОТРЯД');
    }else{
      const chapter=activeCampaignRun&&activeCampaignRun.region===save.selectedRegion?activeCampaignRun.chapter:3;
      if(activePersonalRun||activeFieldRun){spawnEnemy('warden',WORLD.w/2+rand(-100,100),WORLD.h/2-120);for(let i=0;i<3;i++)spawnEnemy(op.enemyPool[i%op.enemyPool.length],WORLD.w/2+rand(-300,300),WORLD.h/2+rand(120,280));$('gameObjective').textContent=activePersonalRun?'ЗАЩИТИТЬ ЛИЧНЫЙ АРХИВ':'ЗАКРЫТЬ ДИНАМИЧЕСКОЕ СОБЫТИЕ';battleToast(activePersonalRun?'ЛИЧНЫЙ ПРОТОКОЛ АКТИВИРОВАН':'ЭЛИТНАЯ ЦЕЛЬ ОБНАРУЖЕНА');
      }else if(chapter===3){
        spawnEnemy('boss',WORLD.w/2+rand(-140,140),WORLD.h/2-220);
        spawnEnemy(op.enemyPool[1]||'shooter',WORLD.w/2-260,WORLD.h/2+180);
        spawnEnemy(op.enemyPool[0]||'drone',WORLD.w/2+260,WORLD.h/2+180);
        $('gameObjective').textContent=`БОСС: ${op.boss}`;battleToast(`КРУПНАЯ ЦЕЛЬ / ${op.boss}`);showBossIntro();
      }else{
        spawnEnemy('warden',WORLD.w/2+rand(-130,130),WORLD.h/2-130);
        for(let i=0;i<3;i++)spawnEnemy(op.enemyPool[i%op.enemyPool.length],WORLD.w/2+rand(-300,300),WORLD.h/2+rand(120,280));
        $('gameObjective').textContent=chapter===1?'ЗАЧИСТИТЬ ПЕРВЫЙ КОНТУР':'УДЕРЖАТЬ ЦЕНТРАЛЬНЫЙ УЗЕЛ';
        battleToast(chapter===1?'ЭЛИТНЫЙ ОТРЯД ОБНАРУЖЕН':'УЗЕЛ ПЕРЕХОДИТ В КРАСНЫЙ РЕЖИМ');
      }
    }
    $('waveLabel').textContent=`ВОЛНА 0${w} / 03`; $('waveProgress').style.width=`${(w-1)/3*100}%`;
  }
  function updateBattleHud(){
    if(!game.player)return;
    const p=game.player,h=currentHero();
    $('battleHeroName').textContent=`${h.name} · ${h.element}`;
    $('healthBar').style.width=`${clamp(p.hp/p.maxHp*100,0,100)}%`;
    $('healthNumbers').textContent=`${fmt(p.hp)} / ${fmt(p.maxHp)}`;
    $('energyBar').style.width=`${clamp(p.energy,0,100)}%`;
    $('makomBar').style.width=`${clamp(game.makom,0,100)}%`;$('makomValue').textContent=`${Math.floor(game.makom)}%`;$('makomButton').classList.toggle('disabled',game.makom<100);$('makomButton').classList.toggle('makom-ready',game.makom>=100);
    $('ultFill').style.opacity=p.energy>=100?'.12':'0';
    $('skillCooldown').style.opacity=p.skillCd>0?'.9':'0';
    $('dashCooldown').style.opacity=p.dashCd>0?'.9':'0';
  }
  function addParticles(x,y,color,count=10,power=130){
    const n=game.quality==='low'?Math.ceil(count*.45):count;
    for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,s=rand(power*.25,power),life=rand(.22,.65);game.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life,maxLife:life,size:rand(2,5),color});}
  }
  function damageEnemy(e,amount,knock=0){
    if(e.dead)return;if(e.type==='warden'&&e.phase!==2)amount*=.62;e.hp-=amount;e.flash=.12;game.player.energy=clamp(game.player.energy+amount*.025*(game.player.passive?.energyGain||1),0,100);addParticles(e.x,e.y,e.color,5,80);
    if(knock){const dx=e.x-game.player.x,dy=e.y-game.player.y,l=Math.hypot(dx,dy)||1;e.x+=dx/l*knock;e.y+=dy/l*knock;}
    if(e.type==='boss'&&e.hp>0&&e.hp/e.maxHp<.5&&e.threshold===0){e.threshold=1;e.phase=2;for(let i=0;i<2;i++)spawnEnemy('lurker',e.x+rand(-90,90),e.y+rand(-90,90));battleToast('ПРОТОКОЛ БОССА: ФАЗА II');}
    if(e.type==='boss'&&e.hp>0&&e.hp/e.maxHp<.25&&e.enrage===0){e.enrage=1;e.damage*=1.16;e.speed*=1.2;for(let i=0;i<3;i++)spawnEnemy('disruptor',e.x+rand(-120,120),e.y+rand(-120,120));battleToast('КРИТИЧЕСКИЙ РЕЖИМ · ФАЗА III');}
    if(e.hp<=0){e.dead=true;addParticles(e.x,e.y,e.color,e.type==='boss'?50:15,230);game.player.energy=clamp(game.player.energy+10,0,100);sound(e.type==='boss'?90:180,.1,'triangle',.025);}
  }
  function nearestEnemy(max=500){let best=null,bd=max;for(const e of game.enemies){if(e.dead)continue;const d=dist(e,game.player);if(d<bd){bd=d;best=e;}}return best;}
  function recordWeaponMastery(amount=1){const p=game.player;if(!p)return;const weapon=p.weapon||WEAPONS[0],key=`${p.id}:${weapon.id}`,entry=save.weaponMastery[key]||(save.weaponMastery[key]={xp:0,level:0});const before=Math.min(5,Math.floor(entry.xp/50));entry.xp=Math.min(250,entry.xp+amount);entry.level=Math.min(5,Math.floor(entry.xp/50));if(entry.level>before){battleToast(`МАСТЕРСТВО ${weapon.name.toUpperCase()} · УРОВЕНЬ ${entry.level}`);sound(720,.15,'triangle',.035);persist();}}
  function attack(){
    if(!game.active||game.paused||game.ended)return;const p=game.player;if(p.attackCd>0)return;
    const h=currentHero(),weapon=p.weapon||WEAPONS[0],style=weapon.attackStyle||'arc',comboData=COMBO_STYLE_DATA[h.combatKit.comboStyle]||COMBO_STYLE_DATA['ДУГА'];
    p.attackCd=.32*comboData.cooldown;p.attackAnim=.19;p.combo=(p.combo%3)+1;game.comboTimer=1.0;game.combo=p.combo;
    const target=nearestEnemy(190+(p.attackRange||0)),struck=[];
    let fx=p.faceX,fy=p.faceY;if(target){const dx=target.x-p.x,dy=target.y-p.y,l=Math.hypot(dx,dy)||1;fx=dx/l;fy=dy/l;p.faceX=fx;p.faceY=fy;}
    let hit=false,criticalHit=false;
    for(const e of game.enemies){if(e.dead)continue;const dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy),dot=(dx*fx+dy*fy)/(d||1);const weaponRange=style==='lance'?30:style==='chain'?24:style==='projectile'?65:style==='heavy'?-12:0;const range=112+p.attackRange+comboData.range+weaponRange; if(d<range&&dot>comboData.dot){const critical=Math.random()<clamp(p.critChance+(p.combo===3?(comboData.crit||0):0),0,.85);criticalHit=criticalHit||critical;const comboMult=p.combo===3?1.35+p.thirdHitBonus+p.combatKit.comboBonus+comboData.finish:comboData.base;const weaponMult=style==='heavy'?(p.combo===3?1.28:.88):style==='chain'?1.08:style==='projectile'?.92:style==='lance'?1.15:1;damageEnemy(e,p.atk*comboMult*weaponMult*(critical?1.65:1),p.combo===3?23+comboData.knock:8);struck.push(e);hit=true;}}
    if(hit){
      if(p.combo===3&&comboData.effect==='chain'){
        const sources=struck.slice();for(const source of sources){for(const e of game.enemies){if(e.dead||struck.includes(e)||dist(e,source)>125)continue;damageEnemy(e,p.atk*(.42+p.combatKit.comboBonus),16);struck.push(e);}}
      }
      if(p.combo===3&&comboData.effect==='dash'){p.x=clamp(p.x+fx*24,35,WORLD.w-35);p.y=clamp(p.y+fy*24,35,WORLD.h-35);p.invuln=Math.max(p.invuln,.18);}
      if(p.combo===3&&comboData.effect==='counter'){p.invuln=Math.max(p.invuln,.48);p.counter=.35;}
      if(p.combo===3&&comboData.effect==='impact')addParticles(target?.x??p.x+fx*55,target?.y??p.y+fy*55,h.color,24,185);
      if(p.combo===3&&comboData.effect==='wide')addParticles(p.x,p.y,h.color,19,170);
      if(comboData.effect==='precision'&&criticalHit)game.makom=clamp(game.makom+5*p.makomGain,0,100);
      game.makom=clamp(game.makom+(p.combo===3?16:9)*p.makomGain,0,100);recordWeaponMastery(p.combo===3?4:2);
    }
    if(criticalHit)battleToast('КРИТИЧЕСКИЙ ИМПУЛЬС');
    addParticles(p.x+fx*48,p.y+fy*48,style==='projectile'?'#9ec2c1':h.color,hit?(style==='heavy'?18:10):4,style==='heavy'?150:95);if(style==='projectile')game.projectiles.push({x:p.x+fx*20,y:p.y+fy*20,tx:p.x+fx*150,ty:p.y+fy*150,life:.24,color:'#9ec2c1'});sound(p.combo===3?260:380,.075,'sawtooth',.025);
  }
  function useSkill(){
    if(!game.active||game.paused||game.ended)return;const p=game.player,h=currentHero(),kit=h.combatKit;if(p.skillCd>0)return;
    p.skillCd=6*(p.skillCooldown||1);p.skillAnim=.55;const target=nearestEnemy(560),r=kit.skillRadius,power=kit.skillPower*p.skillPower,color=h.color;let hitCount=0;
    const damageArea=(radius,mult=1,knock=0,stun=0)=>{for(const e of game.enemies){if(e.dead)continue;if(dist(e,p)<radius){damageEnemy(e,p.atk*power*mult,knock);if(stun)e.stun=Math.max(e.stun,stun);hitCount++;}}};
    const projectAt=(e,mult=1)=>{if(!e||e.dead)return;damageEnemy(e,p.atk*power*mult,14);game.projectiles.push({x:p.x,y:p.y,tx:e.x,ty:e.y,life:.3,color});hitCount++;};
    switch(kit.skillPattern){
      case 'slash':case 'dash':{let fx=p.faceX,fy=p.faceY;if(target){const dx=target.x-p.x,dy=target.y-p.y,l=Math.hypot(dx,dy)||1;fx=dx/l;fy=dy/l;}p.x=clamp(p.x+fx*(110+(kit.skillRadius%70)),45,WORLD.w-45);p.y=clamp(p.y+fy*(110+(kit.skillRadius%70)),45,WORLD.h-45);p.invuln=.5;damageArea(r*.9,1.9,32,.25);break;}
      case 'pierce':case 'line':{if(target){const a=Math.atan2(target.y-p.y,target.x-p.x);for(const e of game.enemies){if(e.dead)continue;const dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy),angle=Math.atan2(dy,dx);if(d<r*2.5&&Math.abs(Math.atan2(Math.sin(angle-a),Math.cos(angle-a)))<.24){damageEnemy(e,p.atk*power*2.1,18);hitCount++;}}game.projectiles.push({x:p.x,y:p.y,tx:p.x+Math.cos(a)*r*2.5,ty:p.y+Math.sin(a)*r*2.5,life:.42,color});}break;}
      case 'ring':case 'burst':case 'nova':damageArea(r*1.25,1.55,42,.4);addParticles(p.x,p.y,color,32,220);break;
      case 'pull':case 'gravity':{for(const e of game.enemies){if(e.dead)continue;if(dist(e,p)<r*2){const dx=p.x-e.x,dy=p.y-e.y,l=Math.hypot(dx,dy)||1;e.x+=dx/l*58;e.y+=dy/l*58;damageEnemy(e,p.atk*power*1.25,8);e.stun=Math.max(e.stun,.55);hitCount++;}}game.fields.push({x:p.x,y:p.y,r:r*.8,life:3,maxLife:3,color,damage:p.atk*.3*power});break;}
      case 'trap':case 'field':game.fields.push({x:p.x,y:p.y,r:r*.9,life:5,maxLife:5,color,damage:p.atk*.62*power});damageArea(r*.6,.65,0,.7);break;
      case 'heal':case 'spores':p.hp=clamp(p.hp+p.maxHp*(.12+kit.control*.12),0,p.maxHp);p.shieldTime=1.2;damageArea(r*.85,.65,8,.7);addParticles(p.x,p.y,'#9bc58e',26,160);break;
      case 'shield':case 'counter':p.invuln=.65;p.shieldTime=1.8;damageArea(r*.72,.9,48,.25);p.counter=kit.control;break;
      case 'volley':case 'mark':{const count=kit.skillPattern==='volley'?4:3;const targets=game.enemies.filter(e=>!e.dead).sort((a,b)=>dist(a,p)-dist(b,p)).slice(0,count);targets.forEach((e,i)=>{projectAt(e,1.3+i*.12);if(kit.skillPattern==='mark')e.markTime=4;});break;}
      case 'turret':game.fields.push({x:p.x+rand(-70,70),y:p.y+rand(-70,70),r:r*.72,life:6,maxLife:6,color,damage:p.atk*.82*power});damageArea(r*.5,.5,0,.35);break;
      case 'sonic':{for(const e of game.enemies){if(e.dead)continue;if(dist(e,p)<r*1.5){damageEnemy(e,p.atk*power*1.05,24);e.stun=Math.max(e.stun,1.3+kit.control);hitCount++;}}break;}
      case 'blink':{if(target){const dx=target.x-p.x,dy=target.y-p.y,l=Math.hypot(dx,dy)||1;p.x=clamp(target.x-dx/l*72,40,WORLD.w-40);p.y=clamp(target.y-dy/l*72,40,WORLD.h-40);p.faceX=dx/l;p.faceY=dy/l;}p.invuln=.42;damageArea(r*.6,1.75,20,.2);break;}
      case 'chain':{const targets=game.enemies.filter(e=>!e.dead).sort((a,b)=>dist(a,p)-dist(b,p)).slice(0,4);targets.forEach((e,i)=>{damageEnemy(e,p.atk*power*(1.55-i*.17),18);game.projectiles.push({x:i?targets[i-1].x:p.x,y:i?targets[i-1].y:p.y,tx:e.x,ty:e.y,life:.28,color});hitCount++;});break;}
      case 'echo':{const e=target;if(e){projectAt(e,2.25);game.fields.push({x:e.x,y:e.y,r:75,life:2,maxLife:2,color,damage:p.atk*.5*power});}else damageArea(r,.8,0,.3);break;}
      default:damageArea(r,1.3,20,.5);
    }
    game.makom=clamp(game.makom+11*p.makomGain,0,100);recordWeaponMastery(3+Math.min(3,hitCount));addParticles(p.x,p.y,color,14+Math.min(20,hitCount*3),145);battleToast(`${h.skill.toUpperCase()} · ${kit.skillPattern.toUpperCase()}`);sound(560+kit.skillRadius,.15,'triangle',.04);buzz(18);updateBattleHud();
  }
  function useMakom(){
    if(!game.active||game.paused||game.ended)return;
    if(game.makom<100){battleToast('МАКОМ ЕЩЁ НЕ СИНХРОНИЗИРОВАН');return;}
    const p=game.player,colors=save.team.map(id=>HERO_BY_ID[id].color),unique=new Set(save.team.map(id=>HERO_BY_ID[id].element)).size;
    const multiplier=(1+(unique-1)*.12)*p.makomGain;
    game.makom=0;p.invuln=.7;p.skillAnim=1.1;
    let count=0;
    for(const e of game.enemies){if(e.dead)continue;if(dist(e,p)<360){damageEnemy(e,p.atk*2.45*multiplier,55);e.stun=Math.max(e.stun,.8);count++;}}
    colors.forEach((c,i)=>addParticles(p.x+Math.cos(i*Math.PI*2/Math.max(1,colors.length))*70,p.y+Math.sin(i*Math.PI*2/Math.max(1,colors.length))*70,c,24,210));
    battleToast(`МАКОМ · ОБЩИЙ ТАКТ · ${count} ЦЕЛЕЙ`);sound(95,.55,'sawtooth',.065);buzz(75);updateBattleHud();
  }

  function dash(){
    if(!game.active||game.paused||game.ended)return;const p=game.player;if(p.dashCd>0)return;
    let x=game.move.x,y=game.move.y;if(Math.hypot(x,y)<.15){x=p.faceX;y=p.faceY;}const l=Math.hypot(x,y)||1;x/=l;y/=l;
    p.x=clamp(p.x+x*120,35,WORLD.w-35);p.y=clamp(p.y+y*120,35,WORLD.h-35);p.faceX=x;p.faceY=y;p.dashCd=1.15;p.invuln=.38;p.dashTime=.2;
    if(p.dashPulse>0){for(const e of game.enemies)if(!e.dead&&dist(e,p)<92)damageEnemy(e,p.atk*p.dashPulse,22);}
    addParticles(p.x-x*20,p.y-y*20,currentHero().color,12,120);sound(680,.07,'triangle',.025);buzz(12);
  }
  function ultimate(){
    if(!game.active||game.paused||game.ended)return;const p=game.player,h=currentHero(),kit=h.combatKit;if(p.energy<100){battleToast('НЕДОСТАТОЧНО ЭНЕРГИИ');sound(130,.08,'square',.02);return;}
    p.energy=0;p.invuln=.72;p.skillAnim=1.1;const r=kit.ultRadius,power=kit.ultPower*p.skillPower,color=h.color;let hits=0;
    const each=(fn)=>game.enemies.forEach(e=>{if(!e.dead)fn(e);});
    switch(kit.ultPattern){
      case 'beam':{const t=nearestEnemy(700);const a=t?Math.atan2(t.y-p.y,t.x-p.x):Math.atan2(p.faceY,p.faceX);each(e=>{const dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy),ang=Math.atan2(dy,dx);if(d<r*2&&Math.abs(Math.atan2(Math.sin(ang-a),Math.cos(ang-a)))<.17){damageEnemy(e,p.atk*power*1.15,55);hits++;}});game.projectiles.push({x:p.x,y:p.y,tx:p.x+Math.cos(a)*r*2,ty:p.y+Math.sin(a)*r*2,life:.6,color});break;}
      case 'meteor':{for(let i=0;i<6;i++){const a=i*Math.PI/3,x=p.x+Math.cos(a)*r*.62,y=p.y+Math.sin(a)*r*.62;game.fields.push({x,y,r:75,life:2.2,maxLife:2.2,color,damage:p.atk*power*.6});}each(e=>{if(dist(e,p)<r){damageEnemy(e,p.atk*power*1.2,48);hits++;}});break;}
      case 'guardian':case 'bloom':p.hp=clamp(p.hp+p.maxHp*(kit.ultPattern==='bloom'?.55:.32),0,p.maxHp);p.invuln=1.2;p.shieldTime=3;each(e=>{if(dist(e,p)<r){damageEnemy(e,p.atk*power*.85,30);e.stun=Math.max(e.stun,kit.control+1);hits++;}});break;
      case 'summon':case 'storm':{for(let i=0;i<12;i++){const a=i*Math.PI/6;game.projectiles.push({x:p.x,y:p.y,tx:p.x+Math.cos(a)*r,ty:p.y+Math.sin(a)*r,life:.55,color});}each(e=>{if(dist(e,p)<r*1.35){damageEnemy(e,p.atk*power*.92,38);hits++;}});break;}
      case 'time':each(e=>{e.stun=Math.max(e.stun,2.7);if(dist(e,p)<r*1.4){damageEnemy(e,p.atk*power*.95,0);hits++;}});break;
      case 'execution':{const t=nearestEnemy(850);if(t){damageEnemy(t,p.atk*power*2.65,90);t.stun=1.8;hits++;}each(e=>{if(e!==t&&dist(e,p)<r*.62){damageEnemy(e,p.atk*power*.55,20);hits++;}});break;}
      case 'resonance':each(e=>{if(dist(e,p)<r*1.5){damageEnemy(e,p.atk*power*1.1,35);e.markTime=5;hits++;}});game.makom=clamp(game.makom+22,0,100);break;
      case 'mirror':{const count=8;for(let i=0;i<count;i++){const a=i*Math.PI*2/count;game.projectiles.push({x:p.x+Math.cos(a)*24,y:p.y+Math.sin(a)*24,tx:p.x+Math.cos(a)*r,ty:p.y+Math.sin(a)*r,life:.7,color});}each(e=>{if(dist(e,p)<r){damageEnemy(e,p.atk*power*1.05,22);hits++;}});break;}
      case 'nova':default:each(e=>{if(dist(e,p)<r){damageEnemy(e,p.atk*power*(e.type==='boss'?1:1.18),68);e.stun=Math.max(e.stun,kit.control);hits++;}});addParticles(p.x,p.y,color,game.quality==='low'?35:65,300);break;
    }
    recordWeaponMastery(8+Math.min(8,hits));addParticles(p.x,p.y,color,game.quality==='low'?30:58,280);battleToast(`${h.ult.toUpperCase()} · ${kit.ultPattern.toUpperCase()} · ${hits} ЦЕЛЕЙ`);sound(110+kit.ultRadius*.1,.45,'sawtooth',.06);buzz(55);updateBattleHud();
  }
  function switchHero(){
    if(!game.active||game.paused||game.ended||save.team.length<2)return;
    const old=currentHero();const ratio=game.player.hp/game.player.maxHp;game.teamIndex=(game.teamIndex+1)%save.team.length;const next=currentHero();
    const oldP=game.player;game.player=makePlayer(next.id,oldP.x,oldP.y);game.player.hp=clamp(ratio*game.player.maxHp,game.player.maxHp*.5,game.player.maxHp);game.player.energy=oldP.energy*.45;game.player.faceX=oldP.faceX;game.player.faceY=oldP.faceY;
    const teamSynergy=getTeamSynergy();
    if(game.player.swapPulse>0){for(const e of game.enemies)if(!e.dead&&dist(e,game.player)<145)damageEnemy(e,game.player.atk*game.player.swapPulse,18);}
    const supportHeal=Math.round(game.player.maxHp*(teamSynergy.elements>=3?.035:teamSynergy.elements===2?.02:.01));game.player.hp=Math.min(game.player.maxHp,game.player.hp+supportHeal);
    if(teamSynergy.elements>=3){for(const e of game.enemies)if(!e.dead&&dist(e,game.player)<185){e.stun=Math.max(e.stun,.25);}} 
    game.makom=clamp(game.makom+8*game.player.makomGain,0,100);addParticles(game.player.x,game.player.y,next.color,26,180);battleToast(`${old.name} → ${next.name} · СИНЕРГИЯ +${supportHeal} HP${teamSynergy.elements>=3?' · ТРИАДА ОГЛУШЕНИЯ':''}`);sound(470,.1,'triangle',.03);updateBattleHud();
  }
  function spawnEnemyShot(e){
    const p=game.player,dx=p.x-e.x,dy=p.y-e.y,l=Math.hypot(dx,dy)||1;game.enemyShots.push({x:e.x,y:e.y,vx:dx/l*235,vy:dy/l*235,r:6,damage:e.damage*.55,life:3,color:e.color});
  }
  function bossOverdrive(e,p,style){const d=dist(e,p);if(style==='orbit'){for(let i=0;i<3;i++){const a=e.angle+i*Math.PI*2/3;game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*340,vy:Math.sin(a)*340,r:11,damage:e.damage*.7,life:3,color:'#d7a86e'});}if(d<190&&p.invuln<=0){p.hp-=e.damage*.45*(1-p.damageReduction);p.invuln=.35;}}
    else if(style==='beam'){const a=e.angle;for(let i=-2;i<=2;i++){const ang=a+i*.12;game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(ang)*430,vy:Math.sin(ang)*430,r:9,damage:e.damage*.78,life:2.4,color:'#c8b7e8'});}e.angle+=Math.PI*.62;}
    else if(style==='spore'){for(let i=0;i<3;i++){const a=e.angle+i*Math.PI*2/3;game.fields.push({x:e.x+Math.cos(a)*130,y:e.y+Math.sin(a)*130,r:90,life:3,maxLife:3,color:'#94bd7e',damage:e.damage*.48});}for(let i=0;i<2;i++)spawnEnemy('spore',e.x+rand(-100,100),e.y+rand(-100,100));}
    else if(style==='salt'){for(let i=0;i<4;i++){const a=e.angle+i*Math.PI/2;const x=clamp(p.x+Math.cos(a)*165,55,WORLD.w-55),y=clamp(p.y+Math.sin(a)*165,55,WORLD.h-55);game.fields.push({x,y,r:82,life:2.8,maxLife:2.8,color:'#9db9c1',damage:e.damage*.58});}e.angle+=.7;}
    else{const a=e.angle;e.x=clamp(e.x+Math.cos(a)*480,45,WORLD.w-45);e.y=clamp(e.y+Math.sin(a)*480,45,WORLD.h-45);if(dist(e,p)<190&&p.invuln<=0){p.hp-=e.damage*1.1*(1-p.damageReduction);p.invuln=.7;}}battleToast(`ФАЗА III · ${style==='orbit'?'ОРБИТАЛЬНЫЙ ПРЕСС':style==='beam'?'ЗЕРКАЛЬНЫЙ КАСКАД':style==='spore'?'КОРНЕВОЙ КОНТУР':style==='salt'?'СОЛЯНОЙ ПРИЛИВ':'ПОСЛЕДНИЙ ТАРАН'}`);addParticles(e.x,e.y,e.color,25,180);}
  function updateEnemies(dt){
    const p=game.player,op=operationById(save.selectedRegion);
    for(const e of game.enemies){if(e.dead)continue;e.flash=Math.max(0,e.flash-dt);e.attackAnim=Math.max(0,e.attackAnim-dt);e.stun=Math.max(0,e.stun-dt);e.cd-=dt;
      const dx=p.x-e.x,dy=p.y-e.y,d=Math.hypot(dx,dy)||1;const nx=dx/d,ny=dy/d;
      if(e.stun>0)continue;
      if(e.type==='boss'){
        e.arenaPulse=(e.arenaPulse??6)-dt;if(e.arenaPulse<=0&&e.hp<e.maxHp*.72){e.arenaPulse=e.enrage?4.4:7.2;const hx=clamp(p.x+rand(-245,245),100,WORLD.w-100),hy=clamp(p.y+rand(-190,190),100,WORLD.h-100);game.fields.push({x:hx,y:hy,r:86,life:2.6,maxLife:2.6,color:op.color,damage:0,hostile:true});battleToast('ОПАСНАЯ ЗОНА АРЕНЫ · СМЕНИ ПОЗИЦИЮ');}
        if(e.enrage){e.specialCd-=dt;if(e.specialTelegraph>0){e.specialTelegraph-=dt;if(e.specialTelegraph<=0){bossOverdrive(e,p,op.bossStyle);e.specialCd=4.4;}}else if(e.specialCd<=0){e.specialTelegraph=1.05;e.angle=Math.atan2(dy,dx);battleToast('БОСС ГОТОВИТ УНИКАЛЬНУЮ АТАКУ · УКЛОНИСЬ');}}
        if(e.telegraph>0){e.telegraph-=dt;if(e.telegraph<=0){
          const style=op.bossStyle;
          if(style==='orbit'){
            if(e.phase===1){const count=e.enrage?18:10;for(let i=0;i<count;i++){const a=i*Math.PI*2/count;game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*(e.enrage?255:215),vy:Math.sin(a)*(e.enrage?255:215),r:8,damage:e.damage*.58,life:2.5,color:e.color});}}
            else if(d<230&&p.invuln<=0){p.hp-=e.damage*.78*(1-p.damageReduction);p.invuln=.58;addParticles(p.x,p.y,'#bd7056',18,120);battleToast('УДАР СМОТРИТЕЛЯ');}
          }else if(style==='beam'){
            const base=Math.atan2(dy,dx),fan=e.enrage?[-.36,-.18,0,.18,.36]:[-.18,0,.18];for(const off of fan){const a=base+off;game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*(e.enrage?360:315),vy:Math.sin(a)*(e.enrage?360:315),r:7,damage:e.damage*.62,life:2.5,color:'#b7a3df'});}
          }else if(style==='spore'){
            if(e.summons<(e.enrage?4:2)){for(let i=0;i<(e.enrage?3:2);i++)spawnEnemy('spore',e.x+rand(-125,125),e.y+rand(-100,100));e.summons++;}
            const spores=e.enrage?10:6;for(let i=0;i<spores;i++){const a=i*Math.PI*2/spores;game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*(e.enrage?205:165),vy:Math.sin(a)*(e.enrage?205:165),r:10,damage:e.damage*.48,life:2.8,color:'#8fbd78'});}
          }else if(style==='salt'){
            const count=e.enrage?22:14;for(let i=0;i<count;i++){const a=i*Math.PI*2/count;game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*(e.enrage?235:185),vy:Math.sin(a)*(e.enrage?235:185),r:9,damage:e.damage*.52,life:2.8,color:'#9db9c1'});}
          }else if(style==='charge'){
            const dashDistance=e.enrage?410:280;e.x=clamp(e.x+Math.cos(e.angle)*dashDistance,45,WORLD.w-45);e.y=clamp(e.y+Math.sin(e.angle)*dashDistance,45,WORLD.h-45);
            if(dist(e,p)<(e.enrage?185:145)&&p.invuln<=0){p.hp-=e.damage*.95*(1-p.damageReduction);p.invuln=.65;addParticles(p.x,p.y,'#bd7056',22,160);battleToast('ТАРАН ПРОВОДНИКА');}
          }
          e.phase=e.phase===1?2:1;e.cd=e.hp<e.maxHp*.5?1.15:1.7;
        }}else if(e.cd<=0){e.telegraph=op.bossStyle==='charge'?.95:.72;e.phase=Math.random()<.55?1:2;e.cd=2.35;e.angle=Math.atan2(dy,dx);}
        const speed=e.hp<e.maxHp*.5?e.speed*1.5:e.speed;
        if(d>165){e.x+=nx*speed*dt;e.y+=ny*speed*dt;}else if(e.phase===0){e.x-=nx*speed*.25*dt;e.y-=ny*speed*.25*dt;}
      }else if(e.type==='shooter'||e.type==='disruptor'){
        if(d>300){e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;}else if(d<190){e.x-=nx*e.speed*.75*dt;e.y-=ny*e.speed*.75*dt;}
        if(e.cd<=0&&d<570){
          const a=Math.atan2(dy,dx);const spread=e.type==='disruptor'?[-.14,0,.14]:[0];
          spread.forEach(off=>game.enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a+off)*(e.type==='disruptor'?280:235),vy:Math.sin(a+off)*(e.type==='disruptor'?280:235),r:e.type==='disruptor'?7:6,damage:e.damage*(e.type==='disruptor'?.48:.55),life:3,color:e.color,disrupt:e.type==='disruptor'}));
          e.cd=e.type==='disruptor'?2.3:rand(1.5,2.2);e.attackAnim=.25;
        }
      }else{
        const desired=e.r+p.r+18;
        if(d>desired){e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;}
        else if(e.cd<=0){
          if(p.invuln<=0){p.hp-=e.damage*(1-p.damageReduction);p.invuln=e.type==='lurker'?.42:.34;addParticles(p.x,p.y,'#b96e5b',7,80);}
          e.cd=e.type==='heavy'||e.type==='warden'?1.65:e.type==='lurker'?.85:1.15;e.attackAnim=.24;
        }
      }
      e.x=clamp(e.x,35,WORLD.w-35);e.y=clamp(e.y,35,WORLD.h-35);
    }
    game.enemies=game.enemies.filter(e=>!e.dead);
    if(game.enemies.length===0&&!game.ended){
      if(game.wave<3&&game.waveTransition<=0){game.waveTransition=2.2;game.wave++;battleToast('СЛЕДУЮЩАЯ ВОЛНА');}
      else if(game.wave===3&&game.waveTransition<=0){finishBattle(true);}
    }
  }
  function updateParticles(dt){
    for(const a of game.particles){a.life-=dt;a.x+=a.vx*dt;a.y+=a.vy*dt;a.vx*=Math.pow(.07,dt);a.vy*=Math.pow(.07,dt);}
    game.particles=game.particles.filter(a=>a.life>0);
    for(const p of game.projectiles)p.life-=dt;game.projectiles=game.projectiles.filter(p=>p.life>0);
    for(const f of game.fields){f.life-=dt;if(f.hostile&&game.player&&dist(game.player,f)<f.r+game.player.r&&game.player.invuln<=0){game.player.hp-=Math.max(24,operationById(save.selectedRegion).rank*9)*(1-game.player.damageReduction);game.player.invuln=.35;addParticles(game.player.x,game.player.y,'#d17a5d',5,65);}for(const e of game.enemies){if(!e.dead&&dist(e,f)<f.r&&f.damage>0&&Math.random()<dt*2.3)damageEnemy(e,f.damage,0);}}
    game.fields=game.fields.filter(f=>f.life>0);
    for(const s of game.enemyShots){s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt;if(Math.hypot(s.x-game.player.x,s.y-game.player.y)<s.r+game.player.r&&game.player.invuln<=0){game.player.hp-=s.damage*(1-game.player.damageReduction);if(s.disrupt)game.player.stun=.55;game.player.invuln=.25;s.life=0;addParticles(game.player.x,game.player.y,'#d17a5d',6,80);}}
    game.enemyShots=game.enemyShots.filter(s=>s.life>0);
  }
  function updateGame(dt){
    game.time+=dt;const p=game.player;const h=currentHero();
    p.attackCd=Math.max(0,p.attackCd-dt);p.skillCd=Math.max(0,p.skillCd-dt);p.dashCd=Math.max(0,p.dashCd-dt);p.invuln=Math.max(0,p.invuln-dt);p.attackAnim=Math.max(0,p.attackAnim-dt);p.skillAnim=Math.max(0,p.skillAnim-dt);p.dashTime=Math.max(0,p.dashTime-dt);
    game.comboTimer=Math.max(0,game.comboTimer-dt);if(game.comboTimer===0)p.combo=0;
    if(game.waveTransition>0){game.waveTransition-=dt;if(game.waveTransition<=0)spawnWave(game.wave);}
    let mx=game.move.x,my=game.move.y;
    if(game.keys['w']||game.keys['arrowup'])my-=1;if(game.keys['s']||game.keys['arrowdown'])my+=1;if(game.keys['a']||game.keys['arrowleft'])mx-=1;if(game.keys['d']||game.keys['arrowright'])mx+=1;
    const ml=Math.hypot(mx,my);if(ml>1){mx/=ml;my/=ml;}
    if(ml>.12){p.faceX=mx;p.faceY=my;}
    if(p.stun>0)p.stun-=dt;else {p.x=clamp(p.x+mx*p.speed*dt,30,WORLD.w-30);p.y=clamp(p.y+my*p.speed*dt,30,WORLD.h-30);}
    updateEnemies(dt);updateParticles(dt);
    if(p.hp<=0&&!game.ended)finishBattle(false);
    updateBattleHud();
  }

  function roundedRect(c,x,y,w,h,r){c.beginPath();c.roundRect?c.roundRect(x,y,w,h,r):(c.rect(x,y,w,h));}
  function drawFloor(){
    const op=operationById(save.selectedRegion);ctx.fillStyle=op.floor;ctx.fillRect(0,0,WORLD.w,WORLD.h);
    // floor plates / faded geometric ornament inspired by regional tile geometry
    for(let x=0;x<WORLD.w;x+=90){for(let y=0;y<WORLD.h;y+=90){ctx.strokeStyle=((x+y)/90)%2===0?'rgba(180,174,133,.065)':'rgba(127,162,139,.045)';ctx.lineWidth=1;ctx.strokeRect(x+8,y+8,74,74);ctx.beginPath();ctx.moveTo(x+45,y+16);ctx.lineTo(x+74,y+45);ctx.lineTo(x+45,y+74);ctx.lineTo(x+16,y+45);ctx.closePath();ctx.stroke();}}
    ctx.strokeStyle=`${op.color}35`;ctx.lineWidth=4;ctx.strokeRect(18,18,WORLD.w-36,WORLD.h-36);
    for(const d of game.decor){ctx.save();ctx.globalAlpha=d.alpha;ctx.fillStyle=d.type===0?'#647368':d.type===1?'#8c8062':'#425d51';ctx.fillRect(d.x,d.y,d.w,d.h);ctx.strokeStyle='rgba(212,197,152,.35)';ctx.strokeRect(d.x,d.y,d.w,d.h);if(d.type===2){ctx.beginPath();ctx.moveTo(d.x,d.y);ctx.lineTo(d.x+d.w,d.y+d.h);ctx.stroke();}ctx.restore();}
    // central signal ring
    ctx.save();ctx.translate(WORLD.w/2,WORLD.h/2-180);ctx.strokeStyle=`${op.color}25`;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,92,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(0,0,112,0,Math.PI*2);ctx.stroke();ctx.fillStyle='rgba(213,173,103,.055)';ctx.beginPath();ctx.arc(0,0,90,0,Math.PI*2);ctx.fill();ctx.restore();
    // broken equipment props
    for(let i=0;i<7;i++){const x=170+i*205,y=150+(i%2)*710;ctx.save();ctx.translate(x,y);ctx.fillStyle='#202d26';ctx.fillRect(-28,-20,56,40);ctx.strokeStyle='rgba(190,174,131,.22)';ctx.strokeRect(-28,-20,56,40);ctx.fillStyle='#637365';ctx.fillRect(-18,-9,36,4);ctx.fillRect(-18,1,24,4);ctx.restore();}
    // Region landmarks make each operation readable even before enemies appear.
    ctx.save();ctx.strokeStyle=`${op.color}55`;ctx.fillStyle=`${op.color}12`;ctx.lineWidth=3;
    if(op.id==='samarkand'){
      for(let i=0;i<4;i++){const x=260+i*350,y=250+(i%2)*420;ctx.beginPath();ctx.arc(x,y,72+i*8,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(x-95,y);ctx.lineTo(x+95,y);ctx.moveTo(x,y-95);ctx.lineTo(x,y+95);ctx.stroke();}
    }else if(op.id==='fergana'){
      for(let i=0;i<11;i++){const x=100+i*135,y=170+(i%3)*330;ctx.beginPath();ctx.moveTo(x,y+170);ctx.quadraticCurveTo(x-60,y+70,x+28,y);ctx.quadraticCurveTo(x+78,y-18,x+50,y-82);ctx.stroke();ctx.beginPath();ctx.ellipse(x+38,y+35,19,8,i*.3,0,Math.PI*2);ctx.stroke();}
    }else if(op.id==='aral'){
      for(let i=0;i<7;i++){const y=180+i*120;ctx.beginPath();ctx.moveTo(90,y);ctx.quadraticCurveTo(420,y-32,800,y+10);ctx.quadraticCurveTo(1160,y+44,1510,y-5);ctx.stroke();}
      ctx.fillRect(660,340,230,10);ctx.strokeRect(690,310,170,60);
    }else if(op.id==='kyzylkum'){
      for(let i=0;i<5;i++){const x=220+i*270;ctx.beginPath();ctx.moveTo(x,80);ctx.lineTo(x+95,WORLD.h-80);ctx.stroke();}
      for(let y=140;y<WORLD.h-100;y+=70){ctx.beginPath();ctx.moveTo(180,y);ctx.lineTo(1450,y+15);ctx.stroke();}
    }else{
      for(let x=120;x<WORLD.w;x+=260){ctx.fillRect(x,80,13,WORLD.h-160);ctx.strokeRect(x-14,80,40,WORLD.h-160);}
    }
    ctx.restore();
  }
  function drawCharacter(x,y,h,scale=1,active=false){
    ctx.save();const idle=Math.sin((game.time||0)*3.2+(x*.01))*1.4;ctx.translate(x,y+idle);ctx.scale(scale,scale);
    ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,13,23,10,0,0,Math.PI*2);ctx.fill();
    if(active&&game.player.invuln>0&&Math.floor(game.time*18)%2===0)ctx.globalAlpha=.55;
    // coat silhouette
    ctx.fillStyle='#202b25';ctx.beginPath();ctx.moveTo(-12,-5);ctx.lineTo(-17,22);ctx.lineTo(-10,30);ctx.lineTo(0,22);ctx.lineTo(11,30);ctx.lineTo(18,17);ctx.lineTo(11,-7);ctx.closePath();ctx.fill();
    ctx.fillStyle=h.color;ctx.beginPath();ctx.moveTo(-10,-7);ctx.lineTo(-11,19);ctx.lineTo(-3,24);ctx.lineTo(0,18);ctx.lineTo(6,25);ctx.lineTo(12,14);ctx.lineTo(8,-7);ctx.closePath();ctx.fill();
    // head and hair
    ctx.fillStyle='#d2c8ae';ctx.beginPath();ctx.ellipse(0,-15,9,11,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=h.hair;ctx.beginPath();ctx.moveTo(-10,-19);ctx.quadraticCurveTo(-9,-33,3,-30);ctx.quadraticCurveTo(14,-30,11,-14);ctx.lineTo(7,-19);ctx.lineTo(3,-10);ctx.lineTo(-2,-18);ctx.lineTo(-8,-11);ctx.closePath();ctx.fill();
    ctx.fillStyle='#1b2924';ctx.fillRect(-6,-15,12,3);
    // shoulder armor
    ctx.fillStyle='#a79c7b';ctx.fillRect(-15,-5,7,7);ctx.fillRect(8,-5,7,7);
    // weapon
    const angle=Math.atan2(game.player?.faceY||1,game.player?.faceX||0);ctx.save();ctx.rotate(angle+Math.PI/2);ctx.fillStyle='#bbc9b8';ctx.fillRect(13,-22,3,33);ctx.fillStyle=h.color;ctx.fillRect(11,7,7,7);ctx.restore();
    ctx.restore();
  }
  function drawEnemy(e){
    ctx.save();ctx.translate(e.x,e.y);ctx.fillStyle='rgba(0,0,0,.42)';ctx.beginPath();ctx.ellipse(0,e.r*.65,e.r*1.3,e.r*.55,0,0,Math.PI*2);ctx.fill();
    if(e.telegraph>0||e.specialTelegraph>0){ctx.strokeStyle=`rgba(221,119,82,${.45+.25*Math.sin(game.time*16)})`;ctx.lineWidth=e.specialTelegraph>0?5:3;ctx.beginPath();ctx.arc(0,0,e.type==='boss'?190:75,0,Math.PI*2);ctx.stroke();ctx.fillStyle='rgba(203,88,62,.09)';ctx.fill();}
    if(e.flash>0)ctx.filter='brightness(2.8)';
    if(e.type==='boss'){
      ctx.fillStyle='#303a32';ctx.beginPath();ctx.moveTo(-46,-30);ctx.lineTo(-55,20);ctx.lineTo(-28,44);ctx.lineTo(0,33);ctx.lineTo(30,44);ctx.lineTo(55,15);ctx.lineTo(45,-30);ctx.lineTo(20,-48);ctx.lineTo(-20,-48);ctx.closePath();ctx.fill();
      ctx.strokeStyle='#c7a15e';ctx.lineWidth=5;ctx.stroke();
      ctx.fillStyle='#d7c48f';ctx.beginPath();ctx.arc(0,-3,17,0,Math.PI*2);ctx.fill();ctx.fillStyle='#bd7150';ctx.fillRect(-23,-9,46,7);
      for(let i=0;i<4;i++){ctx.fillStyle='#68776c';ctx.fillRect(-46+i*26,31,9,24);}
    }else if(e.type==='shooter'){
      ctx.fillStyle='#293b39';ctx.beginPath();ctx.moveTo(0,-20);ctx.lineTo(19,-4);ctx.lineTo(12,18);ctx.lineTo(-13,18);ctx.lineTo(-20,-4);ctx.closePath();ctx.fill();ctx.strokeStyle=e.color;ctx.lineWidth=2;ctx.stroke();ctx.fillStyle=e.color;ctx.beginPath();ctx.arc(0,-3,6,0,Math.PI*2);ctx.fill();ctx.fillRect(12,-2,17,4);
    }else if(e.type==='heavy'||e.type==='warden'){
      ctx.fillStyle=e.type==='warden'?'#4a4a3d':'#343d34';roundedRect(ctx,-25,-25,50,51,7);ctx.fill();ctx.strokeStyle=e.color;ctx.lineWidth=3;ctx.stroke();ctx.fillStyle='#c9a06a';ctx.fillRect(-9,-10,18,13);ctx.fillStyle='#56685a';ctx.fillRect(-32,-15,9,33);ctx.fillRect(23,-15,9,33);
    }else if(e.type==='spore'){
      ctx.fillStyle='#304538';ctx.beginPath();ctx.arc(0,0,e.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle=e.color;ctx.lineWidth=3;ctx.stroke();ctx.fillStyle=e.color;for(let i=0;i<5;i++){ctx.beginPath();ctx.arc(Math.cos(i*1.25)*10,Math.sin(i*1.25)*10,4,0,Math.PI*2);ctx.fill();}
    }else if(e.type==='disruptor'){
      ctx.fillStyle='#343246';ctx.beginPath();ctx.moveTo(0,-22);ctx.lineTo(20,0);ctx.lineTo(0,22);ctx.lineTo(-20,0);ctx.closePath();ctx.fill();ctx.strokeStyle=e.color;ctx.lineWidth=3;ctx.stroke();ctx.fillStyle=e.color;ctx.fillRect(-4,-4,8,8);
    }else if(e.type==='lurker'){
      ctx.fillStyle='#3b302b';ctx.beginPath();ctx.moveTo(-19,-4);ctx.lineTo(-5,-22);ctx.lineTo(18,-8);ctx.lineTo(22,13);ctx.lineTo(-12,20);ctx.closePath();ctx.fill();ctx.strokeStyle=e.color;ctx.lineWidth=2;ctx.stroke();
    }else{
      ctx.fillStyle='#303d35';ctx.beginPath();ctx.moveTo(0,-19);ctx.lineTo(18,-2);ctx.lineTo(10,19);ctx.lineTo(-13,19);ctx.lineTo(-19,-5);ctx.closePath();ctx.fill();ctx.strokeStyle=e.color;ctx.lineWidth=2;ctx.stroke();ctx.fillStyle=e.color;ctx.beginPath();ctx.arc(0,-4,6,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle='#6d7d6e';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-12,8);ctx.lineTo(-22,21);ctx.moveTo(12,8);ctx.lineTo(22,21);ctx.stroke();
    }
    ctx.filter='none';
    const bw=e.type==='boss'?100:40;if(e.type==='boss'){ctx.fillStyle='#e3d7ba';ctx.font='8px system-ui';ctx.textAlign='center';ctx.fillText(operationById(save.selectedRegion).boss,0,-e.r-27);ctx.fillStyle=e.enrage?'#d16f55':'#bca879';ctx.font='7px system-ui';ctx.fillText(e.enrage?'ФАЗА III · КРИТИЧЕСКИЙ ПРОТОКОЛ':e.hp/e.maxHp<.5?'ФАЗА II · ПЕРЕСТРОЙКА':'ФАЗА I · НАБЛЮДЕНИЕ',0,-e.r-16);if(e.telegraph>0||e.specialTelegraph>0){ctx.strokeStyle=e.enrage?'rgba(210,90,70,.8)':'rgba(203,178,126,.55)';ctx.lineWidth=3;ctx.setLineDash([7,5]);ctx.beginPath();if(operationById(save.selectedRegion).bossStyle==='charge')ctx.arc(0,0,e.enrage?190:135,e.angle-.45,e.angle+.45);else ctx.arc(0,0,e.enrage?150:105,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}}ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(-bw/2,-e.r-17,bw,4);ctx.fillStyle=e.type==='boss'?'#d4ad67':'#b9785e';ctx.fillRect(-bw/2,-e.r-17,bw*clamp(e.hp/e.maxHp,0,1),4);
    ctx.restore();
  }
  function drawWorld(){
    const p=game.player;const camX=clamp(p.x-cw/2,0,Math.max(0,WORLD.w-cw));const camY=clamp(p.y-ch/2,0,Math.max(0,WORLD.h-ch));
    ctx.save();ctx.translate(-camX,-camY);drawFloor();
    for(const f of game.fields){ctx.save();ctx.globalAlpha=f.life/f.maxLife*(f.hostile?.32:.4);ctx.fillStyle=f.color;ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle=f.color;ctx.lineWidth=f.hostile?4:2;ctx.setLineDash(f.hostile?[8,5]:[]);ctx.globalAlpha=.7;ctx.stroke();ctx.restore();}
    for(const e of game.enemies)if(!e.dead)drawEnemy(e);
    for(const s of game.enemyShots){ctx.fillStyle=s.color;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();ctx.shadowColor=s.color;ctx.shadowBlur=12;ctx.fill();ctx.shadowBlur=0;}
    for(const pr of game.projectiles){ctx.strokeStyle=pr.color;ctx.globalAlpha=clamp(pr.life*4,0,1);ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(pr.x,pr.y);ctx.lineTo(pr.tx,pr.ty);ctx.stroke();ctx.globalAlpha=1;}
    const h=currentHero();if(p.attackAnim>0){ctx.save();ctx.translate(p.x,p.y);const a=Math.atan2(p.faceY,p.faceX);ctx.rotate(a);ctx.strokeStyle=h.color;ctx.lineWidth=5;ctx.globalAlpha=p.attackAnim/.19;ctx.beginPath();ctx.arc(0,0,62,-.9,.9);ctx.stroke();ctx.restore();}
    drawCharacter(p.x,p.y,h,1,true);
    if(p.skillAnim>0){ctx.strokeStyle=h.color;ctx.globalAlpha=p.skillAnim;ctx.lineWidth=2;ctx.beginPath();ctx.arc(p.x,p.y,65+(1-p.skillAnim)*170,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;}
    for(const a of game.particles){ctx.globalAlpha=clamp(a.life/a.maxLife,0,1);ctx.fillStyle=a.color;ctx.fillRect(a.x,a.y,a.size,a.size);}ctx.globalAlpha=1;
    // world boundary markers
    ctx.strokeStyle='rgba(203,178,126,.35)';ctx.lineWidth=5;ctx.strokeRect(18,18,WORLD.w-36,WORLD.h-36);
    ctx.restore();
  }
  function drawMiniOverlay(){
    const remaining=game.enemies.filter(e=>!e.dead).length;
    ctx.save();ctx.fillStyle='rgba(7,13,10,.55)';ctx.fillRect(cw/2-73,ch-22,146,3);ctx.fillStyle='#c8a66d';ctx.fillRect(cw/2-73,ch-22,146*(1-remaining/Math.max(1,game.wave===1?4:game.wave===2?7:3)),3);ctx.restore();
  }
  function loop(now){
    if(!game.active)return;
    if(!game.paused&&!game.ended){const dt=Math.min(.05,(now-game.last)/1000||.016);game.last=now;updateGame(dt);}
    const frameInterval=game.frameInterval||16.67;if(!game.lastRender||now-game.lastRender>=frameInterval){game.lastRender=now;ctx.clearRect(0,0,cw,ch);drawWorld();drawMiniOverlay();}
    if(game.active)requestAnimationFrame(loop);
  }
  function finishBattle(victory){
    if(game.ended)return;game.ended=true;game.paused=true;
    const op=operationById(save.selectedRegion);
    if(victory){
      const campaign=activeCampaignRun&&activeCampaignRun.region===op.id?activeCampaignRun:null;
      const sideMission=!!activePersonalRun||!!activeFieldRun;
      const first=!sideMission&&!save.clearedRegions.includes(op.id);
      const chapterData=campaign?CAMPAIGN[op.id][campaign.chapter-1]:null;
      if(campaign){
        const previous=save.campaignProgress[op.id]||0;
        if(campaign.chapter===previous+1){
          save.campaignProgress[op.id]=campaign.chapter;save.campaignChoices[`${op.id}_${campaign.chapter}`]=campaign.choice;
          const faction=campaign.choice==='a'?chapterData.fa:chapterData.fb;addFactionRep(faction,2,chapterData.title);
          const route=routeForDecision(op.id,campaign.chapter,campaign.choice);save.routeScores[route]=(save.routeScores[route]||0)+1;save.routeHistory.push({region:op.id,chapter:campaign.chapter,choice:campaign.choice,route});
          save.campaignFlags.push(`${op.id}_${campaign.chapter}`);applyCampaignConsequence(op.id,campaign.chapter,campaign.choice);save.credits+=250;save.xp+=140;
        }
        selectedCampaignChapter=Math.min(3,campaign.chapter+1);
      }
      const completesRegion=sideMission?false:!campaign||campaign.chapter===3;
      const baseCredits=first?1450:780,baseSignals=first?240:110;
      const stationBonus=1+Math.max(0,save.stationLevel-1)*.05;
      const credits=Math.floor(baseCredits*stationBonus),signals=Math.floor(baseSignals*stationBonus);
      save.credits+=credits;save.signal+=signals;save.alloy+=first?8:3;save.xp+=320;save.wins++;
      STATION_ROOMS.forEach(room=>{const lv=save.stationRoomLevels[room.id]||1;const key=room.production||'credits';if(key==='credits')save.stationStorage.credits=(save.stationStorage.credits||0)+lv*12;else if(key==='signal')save.stationStorage.signal=(save.stationStorage.signal||0)+lv*8;else save.stationStorage.alloy=(save.stationStorage.alloy||0)+lv;});
      if(first&&completesRegion){save.clearedRegions.push(op.id);save.archiveFlags.push(op.id);addFactionRep(factionFor(op.id),3,`операция ${op.name}`);}
      let extraRewardText='';
      if(activePersonalRun){const run=activePersonalRun;save.personalMissionClears[run.storyId]=Math.max(save.personalMissionClears[run.storyId]||0,run.chapter+1);save.credits+=180;save.signal+=35;extraRewardText=' Личная миссия завершена: +180 кредитов и +35 сигналов.';activePersonalRun=null;}
      if(activeFieldRun){const run=activeFieldRun;if(run.eventId&&!run.random&&!save.regionEventClaims.includes(run.eventId)){const ev=REGION_EVENTS.find(x=>x.id===run.eventId);if(ev){save.regionEventClaims.push(ev.id);save.credits+=ev.reward.credits;save.signal+=ev.reward.signal;save.alloy+=ev.reward.alloy;addFactionRep(factionFor(run.region),ev.reward.rep,ev.title);extraRewardText=` Событие «${ev.title}» завершено: получены региональные ресурсы и репутация.`;}}else if(run.random){save.credits+=220;save.alloy+=1;addFactionRep(factionFor(run.region),1,'случайная встреча');extraRewardText=' Случайная встреча завершена: +220 кредитов и +1 сплав.';}activeFieldRun=null;}
      const newlyUnlockedEnding=evaluateMainEnding();
      save.accountLevel=1+Math.floor(save.xp/600);
      const next=OPERATIONS.find(o=>o.unlockedBy===op.id);
      $('resultEyebrow').textContent=campaign?`КАМПАНИЯ · ГЛАВА 0${campaign.chapter} · ${op.zone}`:`ОПЕРАЦИЯ ЗАВЕРШЕНА · ${op.zone}`;$('resultTitle').textContent=campaign?(campaign.chapter===3?'ГЛАВА ЗАВЕРШЕНА':'УЗЕЛ СТАБИЛИЗИРОВАН'):'СЕКТОР ОЧИЩЕН';
      $('resultText').textContent=campaign?`${chapterData.title} завершена. ${campaign.chapter<3?`Следующая глава региона: ${CAMPAIGN[op.id][campaign.chapter].title}.`:`Региональная сюжетная линия завершена. ${next?`Открыт регион ${next.name}.`:'Первый цикл кампании завершён.'}`}`:`${op.boss} отключён. ${next?`Открыт новый регион: ${next.name}.`:'Все доступные регионы исследованы.'}`;
      if(campaign){const route=routeForDecision(op.id,campaign.chapter,campaign.choice);$('resultText').textContent+=` Выбор: ${campaign.choice==='a'?chapterData.a:chapterData.b}. Репутация: +2 ${campaign.choice==='a'?chapterData.fa:chapterData.fb}. Путь: ${ROUTE_INFO[route].name}.`}
      if(newlyUnlockedEnding){$('resultEyebrow').textContent='ОСНОВНАЯ КАМПАНИЯ / ФИНАЛЬНЫЙ ПРОТОКОЛ';$('resultTitle').textContent=newlyUnlockedEnding.title;$('resultText').textContent=newlyUnlockedEnding.text;}if(extraRewardText)$('resultText').textContent+=extraRewardText;
      activeCampaignRun=null;
      $('rewardList').innerHTML=`<span class="reward-chip">◈ +${fmt(credits+(campaign?250:0))} кредитов</span><span class="reward-chip">✦ +${fmt(signals)} сигналов</span><span class="reward-chip">⌬ +${first&&completesRegion?8:3} сплавов</span><span class="reward-chip">+${campaign?460:320} XP</span>${campaign?`<span class="reward-chip">+2 репутации</span>`:''}${newlyUnlockedEnding?'<span class="reward-chip">ФИНАЛ · +1 800 кредитов / +400 сигналов / +12 сплавов</span>':''}${activePersonalRun===null&&save.personalMissionClears?'<span class="reward-chip">ЛИЧНЫЙ ПРОТОКОЛ</span>':''}`;
      $('gameObjective').textContent='СИГНАЛ ВОССТАНОВЛЕН';sound(760,.35,'triangle',.05);buzz(80);
    }else{
      activeCampaignRun=null;activePersonalRun=null;activeFieldRun=null;
      $('resultEyebrow').textContent='СВЯЗЬ ПРЕРВАНА';$('resultTitle').textContent='ОТРЯД ОТСТУПИЛ';$('resultText').textContent='Сигнал остался активен. Пересобери отряд и попробуй снова.';
      $('rewardList').innerHTML='<span class="reward-chip">Операция не завершена</span>';sound(100,.35,'sawtooth',.04);
    }
    persist();$('resultOverlay').classList.remove('hidden');
  }
  $('pauseGame').addEventListener('click',()=>{if(!game.active||game.ended)return;game.paused=true;$('pauseOverlay').classList.remove('hidden');});
  $('resumeGame').addEventListener('click',()=>{game.paused=false;$('pauseOverlay').classList.add('hidden');game.last=performance.now();});
  $('retryGame').addEventListener('click',()=>{game.active=false;$('pauseOverlay').classList.add('hidden');startGame();});
  $('exitGame').addEventListener('click',returnToMenu);
  $('resultContinue').addEventListener('click',returnToMenu);

  // On-screen controls. Pointer events allow movement and buttons simultaneously.
  const joystick=$('joystick'),knob=$('joyKnob');let joyPointer=null;
  function setJoy(e){const r=joystick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=42,l=Math.hypot(dx,dy);if(l>max){dx=dx/l*max;dy=dy/l*max;}game.move={x:dx/max,y:dy/max};knob.style.transform=`translate(${dx}px,${dy}px)`;}
  function resetTouch(){joyPointer=null;game.move={x:0,y:0};knob.style.transform='translate(0,0)';}
  joystick.addEventListener('pointerdown',e=>{e.preventDefault();joyPointer=e.pointerId;joystick.setPointerCapture(e.pointerId);setJoy(e);});
  joystick.addEventListener('pointermove',e=>{if(joyPointer===e.pointerId){e.preventDefault();setJoy(e);}});
  ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>joystick.addEventListener(ev,e=>{if(joyPointer===e.pointerId||ev==='lostpointercapture')resetTouch();}));
  document.querySelectorAll('.action-button').forEach(b=>b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();const a=b.dataset.action;if(a==='attack')attack();if(a==='skill')useSkill();if(a==='dash')dash();if(a==='ult')ultimate();if(a==='switch')switchHero();if(a==='makom')useMakom();}));
  window.addEventListener('keydown',e=>{
    const k=e.key.toLowerCase();game.keys[k]=true;
    if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k))e.preventDefault();
    if(k==='j'||k===' ')attack();if(k==='k'||k==='e')useSkill();if(k==='shift')dash();if(k==='q')switchHero();if(k==='r')ultimate();if(k==='escape'&&game.active&&!game.ended){game.paused=!game.paused;$('pauseOverlay').classList.toggle('hidden',!game.paused);if(!game.paused){game.last=performance.now();}}
  });
  window.addEventListener('keyup',e=>{game.keys[e.key.toLowerCase()]=false;});

  // Progression and initial UI setup
  updateResources();renderHomeTeam();renderHomeMission();renderExpeditions();renderPity();renderCharacters();renderWorkshop();renderArchive();
  $('soundToggle').textContent=save.sound?'ВКЛ':'ВЫКЛ';$('soundToggle').classList.toggle('on',save.sound);
  $('vibrationToggle').textContent=save.vibration?'ВКЛ':'ВЫКЛ';$('vibrationToggle').classList.toggle('on',save.vibration);
  $('qualitySelect').value=save.quality||'high';game.quality=save.quality||'high';
  $('qualitySelect').addEventListener('change',()=>{applyRenderProfile();});
  // Persist normalized state immediately so old v0.1/v0.2 saves are migrated before the next action.
  persist();applyRenderProfile();setMusicScene('base');renderSummonHistory();renderBannerCalendar();

  // Prevent page scroll / accidental zoom while controlling the game.
  document.addEventListener('gesturestart',e=>e.preventDefault(),{passive:false});
  document.addEventListener('touchmove',e=>{if(game.active)e.preventDefault();},{passive:false});

  // PWA service worker (works when hosted over HTTPS/localhost; opening index.html directly still works).
  if('serviceWorker' in navigator && location.protocol.startsWith('http')){
    window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
  }
})();
