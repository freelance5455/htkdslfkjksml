# MegaSearch 2.0

A working privacy-first PWA + Node backend built around public SearXNG instances.

## Start

Requirements: Node.js 18+

```bash
npm start
```

Open http://localhost:3000

## What is automatic

- SearXNG directory discovery via searx.space
- Fallback instance pool
- Automatic pool refresh
- Parallel searches
- Failed-instance failover
- Canonical URL deduplication
- Duplicate-source merging
- Images / Videos / News categories where the instance supports them
- PWA shell and service-worker updates

## Important

MegaSearch cannot guarantee permanent availability of third-party public SearXNG servers. It automatically skips failed servers and refreshes its pool, but the underlying servers are independently operated.

Specialized modes such as Maps, Shopping, Books, Jobs and Travel are presented as product modes; public SearXNG instances do not expose identical native categories for all of them, so the backend falls back to general search when a native category is unavailable.

The app does not intentionally store search history. Browser/OS download behavior remains controlled by the user's browser and device.
