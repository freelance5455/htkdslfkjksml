#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js 18+ is required."; exit 1; }
node server.js &
PID=$!
trap 'kill $PID 2>/dev/null || true' EXIT
sleep 2
if command -v xdg-open >/dev/null; then xdg-open http://localhost:3000 >/dev/null 2>&1 || true; elif command -v open >/dev/null; then open http://localhost:3000 || true; fi
wait $PID
