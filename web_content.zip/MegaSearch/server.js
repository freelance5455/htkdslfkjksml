'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 3000);
const REQUEST_TIMEOUT = Number(process.env.REQUEST_TIMEOUT || 9000);
const MAX_INSTANCES = Number(process.env.MAX_INSTANCES || 30);
const PARALLEL = Number(process.env.PARALLEL || 12);
const POOL_TTL = 6 * 60 * 60 * 1000;
const DIRECTORY = 'https://searx.space/instances.json';
const FALLBACKS = [
  'https://www.isci.si/', 'https://search.anoni.net/', 'https://search.jeremyh.xyz/',
  'https://searx.oloke.xyz/', 'https://searx.thefloatinglab.world/', 'https://searx.tiekoetter.com/',
  'https://searxng.buffon.cloud/', 'https://search.serpensin.com/', 'https://searx.rhscz.eu/'
];
let pool = []; let lastRefresh = 0; let refreshing = null;

const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.svg':'image/svg+xml'};
function cleanBase(value) { try { const u = new URL(value); if (u.protocol !== 'https:') return null; u.username=''; u.password=''; u.search=''; u.hash=''; return u.toString().replace(/\/$/,'') + '/'; } catch { return null; } }
function extractUrls(node, out=[]) {
  if (typeof node === 'string') { const c=cleanBase(node); if(c) out.push(c); return out; }
  if (Array.isArray(node)) { for (const x of node) extractUrls(x,out); return out; }
  if (node && typeof node === 'object') for (const [k,v] of Object.entries(node)) { if (['url','href','base_url','alternative_url'].includes(k) && typeof v === 'string') { const c=cleanBase(v); if(c) out.push(c); } else extractUrls(v,out); }
  return out;
}
function request(raw, timeout=REQUEST_TIMEOUT) { return new Promise((resolve,reject)=>{
  let u; try { u=new URL(raw); } catch(e){ reject(e); return; }
  const lib=u.protocol==='https:'?https:http; const req=lib.get(u,{headers:{'User-Agent':'MegaSearch/2.0 (+privacy-first metasearch)','Accept':'application/json, text/plain, */*','Accept-Language':'en-US,en;q=0.8'},timeout},res=>{
    let body=''; res.setEncoding('utf8'); res.on('data',c=>{ if(body.length<8*1024*1024) body+=c; });
    res.on('end',()=>{ if(res.statusCode>=200&&res.statusCode<300) resolve(body); else reject(new Error('HTTP '+res.statusCode)); });
  });
  req.on('timeout',()=>req.destroy(new Error('timeout'))); req.on('error',reject);
}); }
async function refreshPool(force=false){
  if (!force && pool.length && Date.now()-lastRefresh<POOL_TTL) return pool;
  if (refreshing) return refreshing;
  refreshing=(async()=>{
    let discovered=[];
    try { discovered=extractUrls(JSON.parse(await request(DIRECTORY,7000))); } catch {}
    pool=[...new Set([...discovered,...FALLBACKS.map(cleanBase).filter(Boolean)])];
    lastRefresh=Date.now(); return pool;
  })().finally(()=>{refreshing=null;});
  return refreshing;
}
function canonical(url){ try { const u=new URL(url); u.hash=''; u.search=''; u.hostname=u.hostname.toLowerCase(); return u.origin+u.pathname.replace(/\/{2,}/g,'/').replace(/\/$/,''); } catch { return String(url||''); } }
function stripHtml(s){ return String(s||'').replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<style[\s\S]*?<\/style>/gi,'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim(); }
function normalize(r,base){ return {title:stripHtml(r.title),url:r.url||r.link||'',content:stripHtml(r.content||r.description),thumbnail:r.thumbnail||r.img_src||r.thumbnail_src||'',engine:Array.isArray(r.engines)?r.engines:[],instance:base,type:r.type||'',publishedDate:r.publishedDate||r.published||'',duration:r.duration||'',score:r.score||0}; }
function categoryParams(category){
  const map={images:'images',videos:'videos',news:'news',files:'files',academic:'science',social:'social',forums:'general',recipes:'general',jobs:'general',travel:'general',shopping:'general',books:'general',maps:'general',adult:'general',all:'general',general:'general'};
  return map[category]||'general';
}
async function queryInstance(base,q,category){
  const u=new URL('search',base); u.searchParams.set('q',q); u.searchParams.set('format','json'); u.searchParams.set('language','all'); u.searchParams.set('safesearch','0');
  const mapped=categoryParams(category); if(mapped!=='general') u.searchParams.set('categories',mapped);
  const raw=await request(u.toString()); const json=JSON.parse(raw); return {base,results:Array.isArray(json.results)?json.results:[]};
}
async function search(q,category){
  const all=await refreshPool(); const candidates=all.slice(0,MAX_INSTANCES); const map=new Map(); let succeeded=0,raw=0;
  for(let i=0;i<candidates.length;i+=PARALLEL){ const batch=candidates.slice(i,i+PARALLEL); const settled=await Promise.allSettled(batch.map(x=>queryInstance(x,q,category))); for(const s of settled){ if(s.status!=='fulfilled') continue; succeeded++; for(const item of s.value.results){ raw++; const n=normalize(item,s.value.base); if(!n.url) continue; const key=canonical(n.url); if(!key) continue; if(!map.has(key)) map.set(key,n); else { const old=map.get(key); old.engine=[...new Set([...(old.engine||[]),...(n.engine||[])])]; if(!old.thumbnail&&n.thumbnail) old.thumbnail=n.thumbnail; if(!old.content&&n.content) old.content=n.content; if(!old.publishedDate&&n.publishedDate) old.publishedDate=n.publishedDate; old.sources=(old.sources||1)+1; } } } }
  const results=[...map.values()]; results.sort((a,b)=>(Number(b.sources||1)-Number(a.sources||1)) || (Number(b.score||0)-Number(a.score||0)));
  return {results,meta:{instancesTried:candidates.length,instancesSucceeded:succeeded,rawResults:raw,uniqueResults:results.length,duplicatesRemoved:Math.max(0,raw-results.length),poolSize:all.length,updatedAt:lastRefresh,category}};
}
function send(res,status,type,body,extra={}){res.writeHead(status,{ 'Content-Type':type,'Cache-Control':'no-store','Access-Control-Allow-Origin':'*',...extra});res.end(body);}
const publicDir=path.join(__dirname,'public');
const server=http.createServer(async(req,res)=>{ try{
  const u=new URL(req.url,'http://localhost');
  if(req.method==='OPTIONS') return send(res,204,'text/plain','');
  if(u.pathname==='/api/health') return send(res,200,'application/json',JSON.stringify({ok:true,service:'MegaSearch',version:'2.0.0',time:new Date().toISOString()}));
  if(u.pathname==='/api/instances'){const p=await refreshPool(); return send(res,200,'application/json',JSON.stringify({count:p.length,instances:p,lastRefresh}));}
  if(u.pathname==='/api/refresh'){const p=await refreshPool(true); return send(res,200,'application/json',JSON.stringify({ok:true,count:p.length,lastRefresh}));}
  if(u.pathname==='/api/search'){const q=(u.searchParams.get('q')||'').trim(); if(!q)return send(res,400,'application/json',JSON.stringify({error:'Missing query'})); const category=u.searchParams.get('category')||'all'; return send(res,200,'application/json',JSON.stringify(await search(q,category)));}
  let requested=decodeURIComponent(u.pathname); if(requested==='/' ) requested='/index.html'; const file=path.normalize(path.join(publicDir,requested)); if(!file.startsWith(publicDir)) return send(res,403,'text/plain','Forbidden');
  if(fs.existsSync(file)&&fs.statSync(file).isFile()) return send(res,200,mime[path.extname(file)]||'application/octet-stream',fs.readFileSync(file));
  return send(res,404,'text/plain','Not found');
 } catch(e){ return send(res,500,'application/json',JSON.stringify({error:'Server error',message:e.message})); }
});
server.listen(PORT,()=>console.log(`MegaSearch 2.0 running at http://localhost:${PORT}`));
