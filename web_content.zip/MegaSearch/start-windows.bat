@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js 18+ is required. & pause & exit /b 1)
start "MegaSearch Server" cmd /c "node server.js"
timeout /t 2 >nul
start http://localhost:3000
