# GZ'NİN VPNSİ

Bu paket iki parçadan oluşur:
- `web/index.html`: WireGuard `.conf` dosyasının temel alanlarını yerel olarak kontrol eden web yardımcı ekranı. Tarayıcıdan VPN tüneli açmaz.
- `GZVPNAndroid/`: Android Studio kaynak projesi. WireGuard tunnel kütüphanesiyle seçilen `.conf` dosyasını kullanarak gerçek Android VPN tüneli açmayı hedefler.

## Gerçek ABD sunucusu şartı
Bu uygulama kendi başına ABD sunucusu sağlamaz. ABD'de WireGuard kurulu bir VPS/VPN hizmeti gerekir. Sunucudan istemciye özel `.conf` dosyası alın. Dosyada `[Interface]`, `PrivateKey`, `[Peer]`, `PublicKey`, `Endpoint` ve uygun `AllowedIPs` bulunmalıdır. Özel anahtarınızı kimseyle paylaşmayın.

## Android APK derleme
1. Android Studio'yu açın.
2. `GZVPNAndroid` klasörünü açın.
3. Gradle eşitlemesinin bitmesini bekleyin (internet gerekir; WireGuard kütüphanesi Maven Central'dan indirilir).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` içine çıkar.
6. Uygulamayı açın, sunucunuzun `.conf` dosyasını seçin ve Android VPN izin penceresini onaylayın.

## Sınırlamalar
- Bu sohbet ortamında Android SDK/Gradle derlemesi çalıştırılmadı; ZIP bir kaynak projedir, hazır APK değildir.
- Web tarayıcıları güvenlik nedeniyle cihaz genelinde VPN servisi başlatamaz. Gerçek tünel Android uygulamasındadır.
- Kaynak proje WireGuard'ın resmi Android tunnel kütüphanesini kullanır: https://git.zx2c4.com/wireguard-android/about/
