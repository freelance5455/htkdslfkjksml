package com.gz.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_CONFIG = 41;
    private static final int VPN_PERMISSION = 42;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private GoBackend backend;
    private Config config;
    private final Tunnel tunnel = new Tunnel() {
        public String getName() { return "GZ_USA"; }
        public void onStateChange(State state) { runOnUiThread(() -> status.setText(state == State.UP ? "Bağlandı" : "Bağlantı kesildi")); }
    };
    private TextView status, fileLabel;
    private Button connect;
    private Uri configUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        backend = new GoBackend(this);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(7,17,13));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(28,48,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this); title.setText("🛡️  GZ'NİN VPNSİ"); title.setTextColor(Color.WHITE); title.setTextSize(25); title.setGravity(Gravity.CENTER);
        TextView sub = new TextView(this); sub.setText("WireGuard • ABD sunucusu"); sub.setTextColor(0xffa8b8ae); sub.setTextSize(14);
        status = new TextView(this); status.setText("Bağlantı kurulmadı"); status.setTextColor(0xff35e58b); status.setTextSize(20); status.setGravity(Gravity.CENTER); status.setPadding(0,55,0,35);
        fileLabel = new TextView(this); fileLabel.setText("Henüz .conf dosyası seçilmedi"); fileLabel.setTextColor(Color.WHITE); fileLabel.setGravity(Gravity.CENTER); fileLabel.setPadding(0,15,0,20);
        Button choose = new Button(this); choose.setText("WireGuard dosyası seç");
        connect = new Button(this); connect.setText("VPN'e bağlan"); connect.setEnabled(false);
        TextView note = new TextView(this); note.setText("Gerçek bağlantı için ABD'deki WireGuard sunucunuzdan aldığınız .conf dosyasını seçin. Özel anahtarınızı kimseyle paylaşmayın."); note.setTextColor(0xffa8b8ae); note.setTextSize(13); note.setPadding(0,25,0,0);
        root.addView(title); root.addView(sub); root.addView(status); root.addView(fileLabel); root.addView(choose); root.addView(connect); root.addView(note);
        setContentView(root);
        choose.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, PICK_CONFIG); });
        connect.setOnClickListener(v -> connectOrDisconnect());
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_CONFIG && result == RESULT_OK && data != null) {
            configUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(configUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            worker.execute(() -> {
                try (InputStream in = getContentResolver().openInputStream(configUri)) {
                    Config parsed = Config.parse(in);
                    runOnUiThread(() -> { config = parsed; fileLabel.setText("Yapılandırma yüklendi ✓"); connect.setEnabled(true); });
                } catch (Exception e) {
                    runOnUiThread(() -> { config = null; fileLabel.setText("Dosya okunamadı veya geçersiz"); connect.setEnabled(false); });
                }
            });
        } else if (request == VPN_PERMISSION && result == RESULT_OK) {
            startTunnel();
        }
    }

    private void connectOrDisconnect() {
        worker.execute(() -> {
            try {
                if (backend.getState(tunnel) == Tunnel.State.UP) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null);
                    runOnUiThread(() -> connect.setText("VPN'e bağlan"));
                } else {
                    Intent permission = VpnService.prepare(this);
                    if (permission != null) runOnUiThread(() -> startActivityForResult(permission, VPN_PERMISSION));
                    else startTunnel();
                }
            } catch (Exception e) { showError("VPN durumu değiştirilemedi: " + e.getMessage()); }
        });
    }

    private void startTunnel() {
        worker.execute(() -> {
            try {
                if (config == null) { showError("Önce .conf dosyası seç."); return; }
                backend.setState(tunnel, Tunnel.State.UP, config);
                runOnUiThread(() -> connect.setText("Bağlantıyı kes"));
            } catch (Exception e) { showError("Bağlantı kurulamadı. Sunucu ve yapılandırmayı kontrol et."); }
        });
    }
    private void showError(String message) { runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show()); }
    @Override protected void onDestroy() { super.onDestroy(); worker.shutdown(); }
}
