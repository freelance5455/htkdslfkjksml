# Native Android APK build

This is a native Jetpack Compose Android app, not a WebView wrapper. It contains no PayPal secrets.

Build with Android SDK 35 and JDK 17:

`./gradlew :app:assembleRelease -PAPI_URL=https://get-money-machine-api.onrender.com`

Configure release signing outside source control. The APK reads only the production backend URL at build time; all PayPal credentials remain server-side.

Before release, install the APK on a real device and verify login, all stations (including the original Free Money station), master controls, opportunity separation, transfer center, transaction history, audit/security, notifications, and backend error handling.
