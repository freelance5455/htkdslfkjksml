plugins { id("com.android.application") }
android { namespace = "com.faltinhas.app"; compileSdk = 35
 defaultConfig { applicationId = "com.faltinhas.app"; minSdk = 24; targetSdk = 35; versionCode = 3; versionName = "1.2" } }
