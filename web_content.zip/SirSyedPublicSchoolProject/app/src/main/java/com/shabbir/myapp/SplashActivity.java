package com.shabbir.myapp;

// Splash Activity placeholder