const h=('<script>'+require('fs').readFileSync(require('path').join(__dirname,'..','app.js'),'utf8')+'<'+'/script>');const i0=h.indexOf('<script>')+8,i1=h.indexOf('</script>',i0);const s=h.slice(i0,i1);
try{new Function(s)}catch(e){console.log('SYNTAX',e.message)}
const vals={},txt={};const mk=sel=>({style:{},classList:{toggle(){}},focus(){},get value(){return vals[sel]==null?'':vals[sel]},set value(v){vals[sel]=String(v)},get textContent(){return txt[sel]||''},set textContent(v){txt[sel]=v},innerHTML:'',dataset:{},appendChild(){},click(){},remove(){}});
const doc={querySelector:mk,querySelectorAll:()=>[],body:mk('body'),activeElement:null,addEventListener(){},createElement:()=>mk('x')};
const store={};const ls={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};
const f=new Function('document','localStorage','window','navigator','URL','Blob','scrollTo',s+';return {V,get S(){return S},addFit,addBike,fitCode,edBike,go,bcost,set pst(v){pst=v},set svSel(v){svSel=v}}');
const api=f(doc,ls,{},{},{createObjectURL(){return ''}},function(){},()=>{});
const S=api.S;const ok=(n,c)=>console.log((c?'PASS ':'FAIL ')+n);
S.items=[{code:'t1',name:'Tyre',cat:'Wheel',buy:3000,whole:3300,sell:3800,qty:5,low:2},{code:'m2',name:'Mirror',cat:'Body',buy:400,sell:600,qty:4,low:1}];
S.bikes=[];api.go('bpur');api.pst='buy';
let t=api.V.bpur();const labels=[...t.matchAll(/<label[^>]*>([^<]*)</g)].map(m=>m[1]);
ok('Buy Bike form order matches the sketch',['Model','Color','Chassis no','Engine no','Buy price','Sale price','CNIC','Registration no','Payment method'].every((x,i)=>labels[i]===x));
ok('segment tabs named as sketch',t.includes('Buy Bike')&&t.includes('After Service Price'));
ok('only one bike form (no duplicate ids)',(t.match(/id="bm"/g)||[]).length===1&&(t.match(/onclick="addBike\(\)"/g)||[]).length===1);
Object.assign(vals,{'#bm':'CD70','#bc':'Red','#bch':'C1','#be':'E1','#bb':'100000','#bs':'150000','#bcn':'35202','#brg':'LEA1','#bpm':'Easypaisa','#bsn':'Z','#bsp':'03'});
api.addBike();const b=S.bikes[0];ok('bike saved with CNIC, reg and payment method',b&&b.seller.cnic==='35202'&&b.reg==='LEA1'&&b.pm==='Easypaisa');
api.pst='svc';api.svSel=b.id;t=api.V.bpur();ok('After Service Price card has Item code, Item price, Add',t.includes('After Service Price</h3>')&&t.includes('Item code')&&t.includes('Item price (wholesale)')&&t.includes('>Add</button>'));
vals['#fc']='t1';api.fitCode('t1');ok('item price auto-fills with wholesale price 3300',vals['#fp']==='3300');
vals['#fq']='2';api.addFit();ok('part fitted at wholesale price, stock 5 -> 3',b.parts[0].cost===3300&&S.items[0].qty===3);
vals['#fc']='m2';api.fitCode('m2');ok('no wholesale price: falls back to buy price 400',vals['#fp']==='400');
vals['#fp']='350';vals['#fq']='1';api.addFit();ok('price can be changed before Add',b.parts[1].cost===350);
ok('bike total cost = 100000 + 6600 + 350',api.bcost(b)===106950);
process.exit(0)
