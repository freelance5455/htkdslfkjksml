const fs=require('fs');const js=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const vals={},txt={};const mk=sel=>({style:{},classList:{toggle(){}},focus(){},get value(){return vals[sel]==null?'':vals[sel]},set value(v){vals[sel]=String(v)},get textContent(){return txt[sel]||''},set textContent(v){txt[sel]=v},get innerHTML(){return txt['H'+sel]||''},set innerHTML(v){txt['H'+sel]=v},dataset:{},appendChild(){},click(){},remove(){}});
const doc={querySelector:mk,querySelectorAll:()=>[],body:mk('body'),activeElement:null,addEventListener(){},createElement:()=>mk('x')};
const store={};const ls={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};
const f=new Function('document','localStorage','window','navigator','URL','Blob','scrollTo',js+';return {V,get S(){return S},addBike,sellBike,paySeller,addFee,addFit,flows,dayRep,lockedP,setPd,remCard,dataCheck,go,bcost,bDue,owedB,cashTill,thumbs,dues,set tmp(v){tmp=v},set pst(v){pst=v},set svSel(v){svSel=v},set cd(v){cd=v},set cd2(v){cd2=v}}');
const api=f(doc,ls,{},{},{createObjectURL(){return ''}},function(){},()=>{});
const S=api.S;const ok=(n,c)=>console.log((c?'PASS ':'FAIL ')+n);
const d=new Date(),ymd=x=>x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0');
const td=ymd(d);const yd=new Date();yd.setDate(yd.getDate()-1);const yday=ymd(yd);
S.items=[{code:'t1',name:'Tyre',cat:'W',buy:3000,whole:3300,sell:3800,qty:5,low:2}];S.bikes=[];S.bills=[];S.pay=[];S.exp=[];
// --- partial payment to seller + photos
api.go('bpur');api.pst='buy';
Object.assign(vals,{'#bm':'CD70','#bc':'Red','#bch':'C1','#be':'E1','#bb':'100000','#bs':'150000','#bcn':'35202','#brg':'LEA1','#bpm':'Cash','#bsn':'Seller','#bsp':'0300','#bpa':'40000'});
api.tmp={img:'data:image/jpeg;base64,AAA',cnic:'data:image/jpeg;base64,BBB'};api.addBike();
const b1=S.bikes[0];
ok('bike saved with photo and seller CNIC copy',b1.img.endsWith('AAA')&&b1.cnicImg.endsWith('BBB'));
ok('seller still to be paid = 60,000',api.owedB(b1)===60000);
const pur=api.V.bpur();ok('purchase card shows photos and the amount owed',pur.includes('data:image/jpeg;base64,AAA')&&pur.replace(/<[^>]*>/g,' ').includes('You owe the seller Rs 60,000'));
let fl=api.flows(td,td);ok('cash book: only the 40,000 paid today is cash out',fl.out.Cash===40000);
Object.assign(vals,{['#so'+b1.id]:'60000',['#sy'+b1.id]:'JazzCash'});api.paySeller(b1.id);
ok('seller fully paid, JazzCash out 60,000',api.owedB(b1)===0&&api.flows(td,td).out.JazzCash===60000);
// --- sale with trade-in, advance and monthly amount
Object.assign(vals,{'#sb':String(b1.id),'#sc':'Bilal','#sp':'0301','#sx':'150000','#sa':'30000','#sn':'4','#sm':'Cash','#scn':'35201','#srg':'R9','#sfs':td,'#smo':'20000','#tm':'Honda 70 old','#tc':'Blue','#tch':'OLD1','#te':'OE1','#tv':'40000'});
api.tmp={bcnic:'data:image/jpeg;base64,CCC'};api.sellBike();
const sold=S.bikes.find(x=>x.id==b1.id).sold;
ok('trade-in counted as a payment, balance = 150000-30000-40000',sold.ti===40000&&api.bDue(S.bikes[0])===80000);
ok('traded bike added to stock with its value as cost',S.bikes.length===2&&S.bikes[1].ch==='OLD1'&&S.bikes[1].buy===40000&&!S.bikes[1].sold);
ok('monthly amount override kept',sold.mo===20000&&sold.cnicImg.endsWith('CCC'));
let sale=api.V.bsale().replace(/<[^>]*>/g,' ');ok('sale tab shows monthly 20,000 and the next due date',sale.includes('Monthly Rs 20,000')&&sale.includes('Next due'));
// --- late fee
Object.assign(vals,{['#lf'+b1.id]:'2500'});api.addFee(b1.id);ok('late fee adds to the balance (82,500)',api.bDue(S.bikes[0])===82500);
// --- change costs after sale
api.pst='svc';api.svSel=b1.id;const before=api.bcost(S.bikes[0]);Object.assign(vals,{'#fc':'t1','#fp':'3300','#fq':'1'});api.addFit();
ok('service costs can still be added after the sale',api.bcost(S.bikes[0])===before+3300&&api.V.bpur().includes('(sold)'));
// --- cash book range and day report
S.exp.push({date:yday,note:'Rent',amt:5000,m:'Cash',cat:'Rent'});S.exp.push({date:td,note:'Tea',amt:300,m:'Cash',cat:'Tea / Misc'});
const one=api.flows(td,td),two=api.flows(yday,td);ok('range includes both days (expenses 5,300)',two.out.Cash-one.out.Cash===5000);
api.cd=yday;api.cd2=td;const cb=api.V.exp().replace(/<[^>]*>/g,' ');ok('cash book shows From and To dates and Print button',cb.includes('Print report for these dates')&&cb.includes('Cash book'));
api.dayRep();const rep=txt['H#pr'];ok('day report built with totals',rep.includes('DAILY REPORT')&&rep.includes('Total in')&&rep.includes('Cash in hand')&&rep.includes('Rent'));
ok('cash in hand till date equals report',rep.includes('Rs '+Math.round(api.cashTill(td)).toLocaleString('en-IN')));
// --- profit locked in udhaar + reminders
S.bills.push({no:'U1',date:td,cust:'Sara',phone:'0302',lines:[],total:1000,paid:0,due:1000,pay:'Cash',profit:400});
ok('profit locked in udhaar = 400',Math.round(api.lockedP())===400);
api.setPd(0,yday);const rc=api.remCard().replace(/<[^>]*>/g,' ');ok('reminder card lists Sara for her promise date',rc.includes('Sara')&&rc.includes('Promised'));
// --- data check
S.bills.push({no:'U1',date:td,cust:'Dup',phone:'',lines:[],total:1,paid:1,due:0,pay:'Cash',profit:0});api.dataCheck();
ok('data check reports the duplicate invoice',(txt['#t']||'').includes('Duplicate invoice U1'));
process.exit(0)
