const fs=require('fs');
const gs=fs.readFileSync(require('path').join(__dirname,'..','cloud-sync.gs'),'utf8').replace("'CHANGE-ME'","'my-secret'");
const grid={};const cell=(r,c)=>r+','+c;
function range(a,b,c,d){let r,col,nr,nc;
 if(typeof a=='string'){const m=a.match(/^([A-Z])(\d+)(?::([A-Z])(\d+))?$/);col=m[1].charCodeAt(0)-64;r=+m[2];nc=m[3]?m[3].charCodeAt(0)-64-col+1:1;nr=m[4]?+m[4]-r+1:1}else{r=a;col=b;nr=c;nc=d}
 return{getValue(){return grid[cell(r,col)]===undefined?'':grid[cell(r,col)]},getValues(){const o=[];for(let i=0;i<nr;i++){const row=[];for(let j=0;j<nc;j++)row.push(grid[cell(r+i,col+j)]===undefined?'':grid[cell(r+i,col+j)]);o.push(row)}return o},
  setValues(v){for(let i=0;i<nr;i++)for(let j=0;j<nc;j++)grid[cell(r+i,col+j)]=v[i][j]},clearContent(){for(let i=0;i<nr;i++)for(let j=0;j<nc;j++)delete grid[cell(r+i,col+j)]}}}
const sheetObj={getRange:range};
const SpreadsheetApp={getActive:()=>({getSheetByName:()=>sheetObj,insertSheet:()=>sheetObj})};
const ContentService={createTextOutput:s=>({s,setMimeType(){return this}}),MimeType:{JSON:1}};
const LockService={getScriptLock:()=>({waitLock(){},releaseLock(){}})};
// Drive mocks
const folders={};let today='2026-10-24',props={};
const mkFile=(name,content)=>({name,content,trashed:false,getName(){return this.name},setContent(c){this.content=c},setTrashed(t){this.trashed=t}});
const mkFolder=()=>({files:[],getFilesByName(n){const f=this.files.filter(x=>x.name==n&&!x.trashed);let i=0;return{hasNext:()=>i<f.length,next:()=>f[i++]}},createFile(n,c){const f=mkFile(n,c);this.files.push(f);return f},getFiles(){const f=this.files.filter(x=>!x.trashed);let i=0;return{hasNext:()=>i<f.length,next:()=>f[i++]}}});
const DriveApp={getFoldersByName(n){const f=folders[n]?[folders[n]]:[];let i=0;return{hasNext:()=>i<f.length,next:()=>f[i++]}},createFolder(n){return folders[n]=mkFolder()}};
const Utilities={formatDate:()=>today},Session={getScriptTimeZone:()=>'UTC'};
const PropertiesService={getScriptProperties:()=>({getProperty:k=>props[k],setProperty:(k,v)=>props[k]=v})};
const srv=new Function('SpreadsheetApp','ContentService','LockService','DriveApp','Utilities','Session','PropertiesService',gs+';return {doGet,doPost}')(SpreadsheetApp,ContentService,LockService,DriveApp,Utilities,Session,PropertiesService);
const fakeFetch=async(url,opt)=>{const u=new URL(url);let o;if(opt&&opt.method=='POST')o=srv.doPost({postData:{contents:opt.body}});else{const parameter={};u.searchParams.forEach((v,k)=>parameter[k]=v);o=srv.doGet({parameter})}return{json:async()=>JSON.parse(o.s)}};
const js=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
function device(){const vals={};const mk=sel=>({style:{},classList:{toggle(){}},focus(){},get value(){return vals[sel]==null?'':vals[sel]},set value(v){vals[sel]=String(v)},textContent:'',innerHTML:'',dataset:{},appendChild(){},click(){},remove(){}});
 const doc={querySelector:mk,querySelectorAll:()=>[],body:mk('body'),activeElement:null,addEventListener(){},createElement:()=>mk('x')};
 const store={};const ls={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};const pr={};
 const f=new Function('document','localStorage','window','navigator','URL','Blob','scrollTo','fetch','setInterval',js+';return {get S(){return S},save,csPush,csPull,csConnect,csShow,csJoin,csCode,inv,brc,V,pr:()=>document}');
 const inst=f(doc,ls,{},{clipboard:{writeText(){}}},URL,function(){},()=>{},fakeFetch,()=>0);inst.vals=vals;inst.doc=doc;return inst}
const ok=(n,c)=>console.log((c?'PASS ':'FAIL ')+n);
const A=device(),B=device();
(async()=>{
 // phone label on bill
 A.S.items=[{code:'a1',name:'Brake',cat:'x',buy:1,sell:2,qty:5,low:1}];
 const bill={no:'INV1',date:'2026-10-24',cust:'Ali',phone:'0300111',lines:[{name:'Brake',qty:1,rate:380,disc:0}],total:380,paid:380,due:0,pay:'Cash'};
 const html=A.inv(bill);ok('printed bill shows "Phone: 0300111"',html.includes('Phone: 0300111'));
 ok('bill without phone shows no empty label',!A.inv({...bill,phone:''}).includes('Phone:'));
 // sync + sync code
 A.S.ts=1000;A.S.bills=[bill];
 Object.assign(A.vals,{'#cu':'https://script.google.com/macros/s/X/exec','#ck':'my-secret'});await A.csConnect();
 A.A=null;A.csShow();const code=A.vals['#cc'];ok('sync code made ('+code.slice(0,6)+'...)',code.startsWith('AZ1.'));
 B.vals['#cj']=code;await B.csJoin();
 ok('new device joined only with the code and received all data',B.S.items.length===1&&B.S.bills[0].phone==='0300111');
 ok('bad code is refused',(await (async()=>{B.vals['#cj']='hello';await B.csJoin();return true})()));
 // Drive backup
 const fo=folders['AzeemAuto Backup'];
 ok('Drive folder and todays backup file created',fo&&fo.files.length===1&&fo.files[0].name==='azeem-backup-2026-10-24.json'&&fo.files[0].content.includes('Brake'));
 B.S.bills.push({...bill,no:'INV2'});B.S.ts=2000;await B.csPush();
 ok('quick second save does not rewrite Drive (10 minute limit)',!fo.files[0].content.includes('INV2'));
 props.lastDrive=String(Date.now()-700000);B.S.ts=3000;await B.csPush();
 ok('after 10 minutes the same-day file is updated',fo.files.length===1&&fo.files[0].content.includes('INV2'));
 for(let i=1;i<=16;i++){today='2026-11-'+String(i).padStart(2,'0');props.lastDrive=String(Date.now()-700000);B.S.ts=4000+i;await B.csPush()}
 ok('keeps only the latest 14 daily backups',fo.files.filter(f=>!f.trashed).length===14);
 process.exit(0)})();
