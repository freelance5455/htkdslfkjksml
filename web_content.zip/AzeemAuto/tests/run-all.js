// Run with:  node tests/run-all.js     (needs Node.js)
// Run it after every change to app.js or cloud-sync.gs. Every line must say PASS.
const fs=require('fs'),path=require('path'),cp=require('child_process');
let pass=0,fail=0;
fs.readdirSync(__dirname).filter(f=>f.endsWith('.js')&&f!=='run-all.js').sort().forEach(f=>{
  const r=cp.spawnSync(process.execPath,[path.join(__dirname,f)],{encoding:'utf8'});
  const out=(r.stdout||'')+(r.stderr||'');
  const p=(out.match(/^PASS/gm)||[]).length,x=(out.match(/^FAIL/gm)||[]).length+((r.status&&!/^FAIL/m.test(out))?1:0);
  pass+=p;fail+=x;console.log((x?'FAIL ':'ok   ')+f+'  ('+p+' passed'+(x?', '+x+' failed':'')+')');
  if(x)console.log(out.split('\n').filter(l=>/^FAIL|Error/.test(l)).join('\n'));
});
console.log('\nTotal: '+pass+' passed, '+fail+' failed');process.exit(fail?1:0);
