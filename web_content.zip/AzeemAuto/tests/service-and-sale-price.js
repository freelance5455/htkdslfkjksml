const h=('<script>'+require('fs').readFileSync(require('path').join(__dirname,'..','app.js'),'utf8')+'<'+'/script>');const i0=h.indexOf('<script>')+8,i1=h.indexOf('</script>',i0);const s=h.slice(i0,i1);
try{new Function(s)}catch(e){console.log('SYNTAX',e.message)}
const vals={},txt={};const mk=sel=>({style:{},classList:{toggle(){}},focus(){},get value(){return vals[sel]==null?'':vals[sel]},set value(v){vals[sel]=String(v)},get textContent(){return txt[sel]||''},set textContent(v){txt[sel]=v},innerHTML:'',dataset:{},appendChild(){},click(){},remove(){}});
const doc={querySelector:mk,querySelectorAll:()=>[],body:mk('body'),activeElement:null,addEventListener(){},createElement:()=>mk('x')};
const store={};const ls={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};
const f=new Function('document','localStorage','window','navigator','URL','Blob','scrollTo',s+';return {V,get S(){return S},addFit,addPrep,spQ,spU,spSet,go,bcost,set pst(v){pst=v},set svSel(v){svSel=v}}');
const api=f(doc,ls,{},{},{createObjectURL(){return ''}},function(){},()=>{});
const S=api.S;const ok=(n,c)=>console.log((c?'PASS ':'FAIL ')+n);
S.items=[{code:'l1',name:'New Light',cat:'Lights',buy:900,whole:1000,sell:1500,qty:3,low:1}];
S.bikes=[{id:3,model:'CD70',color:'Red',ch:'C3',en:'E3',buy:100000,sell:0,sold:null,prep:[]}];
api.go('bpur');api.pst='svc';api.svSel=3;
let t=api.V.bpur();ok('cost card and quick-name list shown',t.includes('Total cost and sale price')&&t.includes('Engine oil')&&t.includes('Polishing'));
Object.assign(vals,{'#fc':'l1','#fp':'1000','#fq':'1'});api.addFit();
Object.assign(vals,{'#xd3':'Engine oil','#xa3':'800'});api.addPrep(3);
Object.assign(vals,{'#xd3':'Polishing','#xa3':'1200'});api.addPrep(3);
Object.assign(vals,{'#xd3':'Washing','#xa3':'500'});api.addPrep(3);
const b=S.bikes[0];ok('total cost = 100000 + 1000 + 2500 = 103500',api.bcost(b)===103500);
t=api.V.bpur().replace(/<[^>]*>/g,' ');ok('card shows parts 1,000 and expenses 2,500 and total 1,03,500',t.includes('Rs 1,000')&&t.includes('Rs 2,500')&&t.includes('Rs 1,03,500'));
api.spQ(3,15);ok('Cost +15% fills sale price rounded up to 500 (119,025 -> 119,500)',vals['#ssp']==='119500');
ok('live profit text',txt['#spp'].includes('Rs 16,000'));
api.spSet(3);ok('sale price saved on the bike',b.sell===119500);
t=api.V.bpur().replace(/<[^>]*>/g,' ');ok('card now shows the saved profit',t.includes('Profit Rs 16,000'));
const sale=api.V.bsale();ok('Sale tab bike list shows cost and sale price',sale.includes('cost Rs 1,03,500')&&sale.includes('sale Rs 1,19,500'));
process.exit(0)
