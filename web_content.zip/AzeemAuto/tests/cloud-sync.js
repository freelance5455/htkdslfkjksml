const fs=require('fs');
const gs=fs.readFileSync(require('path').join(__dirname,'..','cloud-sync.gs'),'utf8').replace("'CHANGE-ME'","'my-secret'");
// ---- mock Google Apps Script environment ----
const grid={};const cell=(r,c)=>r+','+c;
function range(a,b,c,d){let r,col,nr,nc;
 if(typeof a=='string'){const m=a.match(/^([A-Z])(\d+)(?::([A-Z])(\d+))?$/);col=m[1].charCodeAt(0)-64;r=+m[2];nc=m[3]?m[3].charCodeAt(0)-64-col+1:1;nr=m[4]?+m[4]-r+1:1}else{r=a;col=b;nr=c;nc=d}
 return{getValue(){return grid[cell(r,col)]===undefined?'':grid[cell(r,col)]},getValues(){const o=[];for(let i=0;i<nr;i++){const row=[];for(let j=0;j<nc;j++)row.push(grid[cell(r+i,col+j)]===undefined?'':grid[cell(r+i,col+j)]);o.push(row)}return o},
  setValues(v){for(let i=0;i<nr;i++)for(let j=0;j<nc;j++)grid[cell(r+i,col+j)]=v[i][j]},clearContent(){for(let i=0;i<nr;i++)for(let j=0;j<nc;j++)delete grid[cell(r+i,col+j)]}}}
const sheetObj={getRange:range};
const SpreadsheetApp={getActive:()=>({getSheetByName:()=>sheetObj,insertSheet:()=>sheetObj})};
const ContentService={createTextOutput:s=>({s,setMimeType(){return this}}),MimeType:{JSON:1}};
const LockService={getScriptLock:()=>({waitLock(){},releaseLock(){}})};
const srv=new Function('SpreadsheetApp','ContentService','LockService',gs+';return {doGet,doPost}')(SpreadsheetApp,ContentService,LockService);
let calls=0;
const fakeFetch=async(url,opt)=>{calls++;const u=new URL(url);let o;
 if(opt&&opt.method=='POST')o=srv.doPost({postData:{contents:opt.body}});else{const parameter={};u.searchParams.forEach((v,k)=>parameter[k]=v);o=srv.doGet({parameter})}
 return{json:async()=>JSON.parse(o.s)}};
// ---- app instances (two devices) ----
const js=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
function device(){const vals={};const mk=sel=>({style:{},classList:{toggle(){}},focus(){},get value(){return vals[sel]==null?'':vals[sel]},set value(v){vals[sel]=String(v)},textContent:'',innerHTML:'',dataset:{},appendChild(){},click(){},remove(){}});
 const doc={querySelector:mk,querySelectorAll:()=>[],body:mk('body'),activeElement:null,addEventListener(){},createElement:()=>mk('x')};
 const store={};const ls={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};
 const f=new Function('document','localStorage','window','navigator','URL','Blob','scrollTo','fetch','setInterval',js+';return {get S(){return S},set S(v){S=v},save,csPush,csPull,csConnect,V}');
 const inst=f(doc,ls,{},{},URL,function(){},()=>{},fakeFetch,()=>0);inst.vals=vals;return inst}
const ok=(n,c)=>console.log((c?'PASS ':'FAIL ')+n);
const A=device(),B=device();
A.S.items=[{code:'a1',name:'Brake Shoe',cat:'Brake',buy:100,sell:380,qty:10,low:5}];A.S.bills=[{no:'INV0001',date:'2026-10-24',total:760,paid:760,due:0,lines:[],profit:300,pay:'Cash',cust:'Ali'}];A.S.ts=1000;
(async()=>{
 // wrong key
 Object.assign(A.vals,{'#cu':'https://script.google.com/macros/s/X/exec','#ck':'wrong'});await A.csConnect();
 ok('wrong key is rejected, nothing stored in sheet',grid['1,1']===undefined);
 // device A connects with right key, cloud empty -> pushes its data
 A.vals['#ck']='my-secret';await A.csConnect();
 ok('device A data is now in the Google Sheet',Number(grid['1,1'])===1000&&String(grid['2,1']).includes('Brake Shoe'));
 // device B (fresh) connects and receives the same data
 Object.assign(B.vals,{'#cu':'https://script.google.com/macros/s/X/exec','#ck':'my-secret'});await B.csConnect();
 ok('device B shows the same stock and bills',B.S.items.length===1&&B.S.items[0].name==='Brake Shoe'&&B.S.bills[0].no==='INV0001');
 // B makes a sale -> A gets it
 B.S.items[0].qty=8;B.S.bills.push({no:'INV0002',date:'2026-10-25',total:760,paid:760,due:0,lines:[],profit:300,pay:'Cash',cust:'Sara'});B.save();await B.csPush();
 const r=await A.csPull();
 ok('A receives B\'s new bill and stock 8',r==='loaded'&&A.S.items[0].qty===8&&A.S.bills.length===2);
 // no echo: A pulls again -> nothing new
 const before=calls;const r2=await A.csPull();ok('second pull finds nothing new',r2==='same');
 // stale push is refused and replaced by newer data
 A.S.items[0].qty=1;A.S.ts=500;await A.csPush();
 ok('stale device is brought up to date instead of overwriting',A.S.items[0].qty===8);
 // big data splits into several cells and comes back intact
 const big=[];for(let i=0;i<900;i++)big.push({no:'INV'+i,date:'2026-10-25',total:i,paid:i,due:0,lines:[{code:'a1',name:'Brake Shoe '+i,qty:1,rate:380,disc:0,cost:100}],profit:1,pay:'Cash',cust:'Customer '+i});
 B.S.bills=big;B.save();await B.csPush();const n=Number(grid['1,2']);await A.csPull();
 ok('large data ('+n+' cells) syncs intact',n>1&&A.S.bills.length===900&&A.S.bills[899].no==='INV899');
 process.exit(0)})();
