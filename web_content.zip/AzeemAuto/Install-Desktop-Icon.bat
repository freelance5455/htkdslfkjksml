@echo off
set "T=%~dp0Azeem-Auto.bat"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Azeem Auto.lnk');$s.TargetPath='%T%';$s.WorkingDirectory='%~dp0';$s.WindowStyle=7;$s.Save()"
echo Desktop par "Azeem Auto" ka icon ban gaya. Ab isko double click karke app chalayein.
pause
