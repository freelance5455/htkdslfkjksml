AZEEM AUTO - files aur use karne ke tareeqe

FILES
- index.html = HTML (screen ka dhancha)    - style.css = CSS (rang, design)    - app.js = JavaScript (saara kaam)
- manifest.json, sw.js, icon-*.png = phone/computer par "Install app" ke liye
- cloud-sync.gs = phone aur computer ka data ek jaisa rakhne ke liye (neeche dekhein)
- Azeem-Auto.bat, Install-Desktop-Icon.bat, Azeem-Auto.command = computer par software ki tarah kholne ke liye

1) PHONE AUR COMPUTER PAR "INSTALL APP" (APK ki zaroorat nahi)
- Folder (ya zip) ko app.netlify.com/drop par drag karein (free). Aapko ek link milega.
- Android: Chrome mein link kholein, teen dots, "Install app" ya "Add to Home screen".
- Computer: Chrome ya Edge mein link kholein, address bar ka install icon dabayein.
- Jab bhi koi file badlein, folder dobara drag karein.

2) PHONE AUR COMPUTER PAR SAME DATA (Cloud sync) - ek dafa ka setup
- Apni Google Sheet kholein. Extensions, phir Apps Script.
- Wahan jo code ho wo mita kar cloud-sync.gs ka poora code paste karein.
- Code ki pehli line mein 'CHANGE-ME' ki jagah apna koi password likhein (ye "secret key" hai). Save karein.
- Deploy, phir New deployment, type: Web app. "Execute as: Me", "Who has access: Anyone". Deploy dabayein, ijazat dein.
- Jo "Web app URL" mile use copy karein.
- App mein History tab kholein, "Cloud sync" card mein URL aur secret key likhein, "Connect & sync" dabayein.
- Doosre device par bhi yehi karein. Phir dono par same stock, bills, udhaar nazar aate hain. Har kuch second mein khud update hota hai.
- Naye device par (phone, laptop, PC): app kholein, History tab mein "Cloud sync" card mein pehle device ka "My sync code" copy karke "Paste a sync code here" mein daalein aur "Join with code" dabayein. Sara data aa jata hai. Ye code aapke account ki chabi ki tarah hai, kisi ko na dein.
- Google Drive mein "AzeemAuto Backup" folder ban jata hai, jisme har din ki backup file (aakhri 14 din) rakhi jati hai.
- Ek hi waqt mein dono par likhein to aakhri save wala jeetta hai.
- Data Sheet ke "AzeemSync" tab mein rehta hai. Us tab ko haath se mat badlein.
(Claude wale link par ye setup zaroori nahi, wahan ek hi Claude account se sync khud hota hai.)

3) ASLI APK
- Pehle tareeqa 1 se https link bana lein. pwabuilder.com par link daalein, "Package for stores", Android chunein, signed package lein.

4) ASLI EXE (Windows)
- Node.js install karein (nodejs.org). Command Prompt mein: npm install -g nativefier
- Phir: nativefier "apna-link" --name "Azeem Auto"
- Jo folder bane usme .exe hoga. Ye link ko exe ke andar kholta hai.

5) COMPUTER PAR INTERNET KE BAGHAIR
- Folder ko C:\AzeemAuto mein rakhein, Install-Desktop-Icon.bat chalayein. Chrome ya Edge chahiye. Mac par Azeem-Auto.command.

BACKUP
- Computer par roz pehli dafa app kholne par backup file Downloads mein khud ban jati hai.
- History tab mein "Full backup" aur "Restore" ke buttons hain.

TESTS (jab bhi code badlein)
- Node.js ke saath: folder mein jaa kar  node tests/run-all.js  chalayein. Har line PASS aani chahiye. Koi FAIL aaye to us tabdili ko wapas karein.

DEVICE CHECK (har naye phone/computer par ek dafa)
- App ke History tab mein "Device check" card mein "Run device check" dabayein. Ye storage, print, camera, photo, install, sync aur Google Drive check karta hai.
- "Copy report" dabakar report mujhe bhej dein, ya screenshot lein.
