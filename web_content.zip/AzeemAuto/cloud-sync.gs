// AZEEM AUTO - Cloud sync (Google Apps Script)
// 1) Change the secret below to your own password. Type the same password in the app.
var SECRET = 'CHANGE-ME';

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function sheet_() {
  var ss = SpreadsheetApp.getActive();
  return ss.getSheetByName('AzeemSync') || ss.insertSheet('AzeemSync');
}
function doGet(e) {
  if (e.parameter.k !== SECRET) return out_({ error: 'key' });
  var s = sheet_();
  var ts = Number(s.getRange('A1').getValue() || 0);
  if (e.parameter.check) return out_({ ts: ts, cells: Number(s.getRange('B1').getValue() || 0), drive: driveInfo_() });
  if (Number(e.parameter.since) >= ts) return out_({ ts: ts, same: true });
  var n = Number(s.getRange('B1').getValue() || 0), d = '';
  if (n > 0) {
    var v = s.getRange(2, 1, n, 1).getValues();
    for (var i = 0; i < n; i++) d += v[i][0];
  }
  return out_({ ts: ts, data: d });
}
function doPost(e) {
  var b = JSON.parse(e.postData.contents);
  if (b.k !== SECRET) return out_({ error: 'key' });
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var s = sheet_();
    if (Number(b.ts) < Number(s.getRange('A1').getValue() || 0)) return out_({ stale: true });
    var d = String(b.data), n = Math.ceil(d.length / 45000), old = Number(s.getRange('B1').getValue() || 0), arr = [];
    for (var i = 0; i < n; i++) arr.push([d.substr(i * 45000, 45000)]);
    var rows = Math.max(n, old);
    if (rows > 0) s.getRange(2, 1, rows, 1).clearContent();
    if (n > 0) s.getRange(2, 1, n, 1).setValues(arr);
    s.getRange('A1:B1').setValues([[Number(b.ts), n]]);
    driveBackup_(d);
    return out_({ ok: true, ts: Number(b.ts) });
  } finally {
    lock.releaseLock();
  }
}

// Keeps a dated copy of your data in Google Drive, folder "AzeemAuto Backup" (last 14 days).
// It updates at most once every 10 minutes.
function driveBackup_(d) {
  try {
    var props = PropertiesService.getScriptProperties();
    var now = new Date().getTime();
    if (now - Number(props.getProperty('lastDrive') || 0) < 600000) return;
    var fi = DriveApp.getFoldersByName('AzeemAuto Backup');
    var fo = fi.hasNext() ? fi.next() : DriveApp.createFolder('AzeemAuto Backup');
    var day = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
    var name = 'azeem-backup-' + day + '.json';
    var it = fo.getFilesByName(name);
    if (it.hasNext()) it.next().setContent(d); else fo.createFile(name, d, 'application/json');
    var all = [], a = fo.getFiles();
    while (a.hasNext()) { var x = a.next(); all.push([x.getName(), x]); }
    all.sort(function (p, q) { return p[0] < q[0] ? -1 : 1; });
    while (all.length > 14) all.shift()[1].setTrashed(true);
    props.setProperty('lastDrive', String(now));
  } catch (err) {}
}

function driveInfo_() {
  try {
    var fi = DriveApp.getFoldersByName('AzeemAuto Backup');
    if (!fi.hasNext()) return { files: 0 };
    var fo = fi.next(), a = fo.getFiles(), n = 0, last = '';
    while (a.hasNext()) { var x = a.next(); n++; if (x.getName() > last) last = x.getName(); }
    return { files: n, last: last };
  } catch (err) { return { error: String(err) }; }
}
