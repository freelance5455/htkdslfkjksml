#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open -na "Google Chrome" --args --app="file://$DIR/index.html" || open "$DIR/index.html"
