# CUBIQ: offline surface-area calculator (Android, WebView)

CUBIQ calculates the surface area of a cuboid (`SA = 2 × (L×W + L×H + W×H)`) for milling and
industrial work, with quantity, an optional rate in ₹ per cm², Hindi/English, and live results
that update on every keystroke. It runs fully offline: the app declares **no permissions at all**.

## Honest status

| Item | Status |
|---|---|
| Calculator page (`index.html`) | Written and run in headless desktop Chromium: 90 automated checks pass (`tests/ui_test.py`) |
| Android wrapper (Java, Gradle, manifest, resources) | Written; **not compiled**. The sandbox that produced this project had no Android SDK and no access to Maven/Gradle downloads |
| APK | **Not built here.** Build it with the steps below |
| Android 16 / any real device or emulator | **Not tested.** Use `TESTING.md` |
| Dependency versions (`gradle/libs.versions.toml`) | Chosen from memory, not verified online. Android Studio will tell you if newer ones exist |
| Your original `CUBIQ.apk` | **Not provided**, so nothing was inspected. Look and behaviour follow your written spec |

Nothing here claims compatibility with future Android versions. Re-test after each SDK bump.

## Project layout

```
CUBIQ/
├── app/
│   ├── build.gradle.kts            module config: SDK levels, signing, shrinking
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml     no permissions, one activity
│       ├── assets/www/
│       │   ├── index.html          the whole calculator (HTML + CSS + JS)
│       │   └── fonts/              Poppins 400/500/700 (.woff, subset for Latin + Devanagari + ₹) + OFL.txt
│       ├── java/app/cubiq/calculator/
│       │   ├── MainActivity.java   locked-down WebView, insets/keyboard, lifecycle, back, errors
│       │   └── LocalAssetHandler.java   serves assets/www over https://appassets.androidplatform.net
│       └── res/                    layout, strings (en + hi), colours, themes, adaptive icon
├── gradle/libs.versions.toml       dependency + plugin versions (edit here)
├── gradle/wrapper/                 Gradle wrapper (Gradle 8.13)
├── build.gradle.kts, settings.gradle.kts, gradle.properties
├── keystore.properties.example     template for release signing
├── tests/ui_test.py                browser regression tests for index.html
├── README.md, TESTING.md
```

Key choices: `minSdk 26` (Android 8.0), `targetSdk 36` and `compileSdk 36` (Android 16, which Google Play
requires for new apps and updates from 31 Aug 2026), Java 17, Android Gradle Plugin 8.13.0, Gradle 8.13.
Only three libraries are used: `androidx.activity`, `androidx.core`, `androidx.webkit`.
Default unit is **cm** (an assumption; change `DEFAULT_UNIT` in `index.html` if you prefer mm).

## Build a signed release APK

1. **Install** Android Studio (current stable). It bundles JDK 21 and offers to install the SDK.
   In *SDK Manager* install **Android SDK Platform 36** and the latest **Build-Tools**.
2. **Open** the `CUBIQ` folder in Android Studio and let Gradle sync. (If it reports a newer AGP, Gradle or
   library version, the *AGP Upgrade Assistant* or the version-catalog hints can apply it.)
3. **Create your signing key once** (keep it forever; losing it means you can never update the app):
   ```
   keytool -genkeypair -v -keystore cubiq-release.jks -alias cubiq -keyalg RSA -keysize 2048 -validity 10000
   ```
   Put `cubiq-release.jks` in the project root. **Back it up** (password manager plus an offline copy).
4. **Create `keystore.properties`**: copy `keystore.properties.example`, fill in the passwords and alias.
   Both files are in `.gitignore`.
5. **Build**
   - Android Studio: *Build ▸ Generate Signed App Bundle / APK*, or
   - Terminal (Windows: `gradlew.bat`):
     ```
     ./gradlew assembleRelease
     ```
   Output: `app/build/outputs/apk/release/app-release.apk`. If `keystore.properties` is missing the build stops
   with a message instead of producing an unsigned APK.
6. **Verify the signature**:
   ```
   <sdk>/build-tools/<version>/apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk
   ```
7. For Google Play, build an app bundle instead: `./gradlew bundleRelease` (`app/build/outputs/bundle/release/`).

Quick test build without a key: `./gradlew assembleDebug` gives `app/build/outputs/apk/debug/app-debug.apk`
(auto-signed with the debug key; fine for your own phone, not for distribution).

## Install and test

- **On a phone**: copy the APK over, open it, allow "install unknown apps" for your file manager when asked.
- **With adb** (USB debugging on): `adb install -r app-release.apk`
- Then follow `TESTING.md`. You need an Android 16 phone or an Android 16 emulator image for the Android 16 items.

## Updating and version management

- **Calculator changes** happen only in `app/src/main/assets/www/index.html`. The Android wrapper does not
  need to change. Run `python3 tests/ui_test.py` (needs `pip install playwright && playwright install chromium`).
- **Every release**: raise `versionCode` (a whole number that must always go up) and `versionName` in
  `app/build.gradle.kts`. Android refuses to install a lower `versionCode` over a higher one.
- **Keep the same `applicationId` and the same signing key** for every release, or Android treats it as a different app.
- **Yearly Android update**: Google Play raises the minimum `targetSdk` each year. Then: install the new SDK
  platform, bump `compileSdk` and `targetSdk`, read Google's behaviour-changes page for that API level,
  update AGP/Gradle/libraries via `libs.versions.toml`, rebuild, and run `TESTING.md` again.
- **WebView** updates through Google Play System/WebView independently of your app. The calculator uses
  only widely supported web features, and the tests catch regressions in the page itself.

## Your existing CUBIQ.apk

The new app uses the ID `app.cubiq.calculator`. Your old app's ID and signing key are unknown, so this build
**cannot be assumed to update it**; it will normally install **side by side** as a separate app. To check the old APK:

```
aapt2 dump badging CUBIQ.apk | head -5                       # package name, versionCode
apksigner verify --print-certs CUBIQ.apk                       # signing certificate
```

Android replaces an installed app only when package name and signing certificate both match and the
`versionCode` is higher. If you want that, set `applicationId` in `app/build.gradle.kts` to the old app's package
name **and** sign with the old key (only possible if you still have it). Otherwise keep both installed, or
uninstall the old one yourself. Nothing here overwrites or removes it.

## Security notes

- Content loads from `https://appassets.androidplatform.net/app/` via `WebViewAssetLoader`; no `file://` access.
- JavaScript is on (the calculator needs it) but only for bundled pages. DOM storage is on only to remember the language.
- File access, content access, mixed content, multiple windows and geolocation are off. No `addJavascriptInterface`.
- Every request that is not the app's own file gets an empty 403, and navigation away from the app is cancelled.
- `index.html` has a Content-Security-Policy with no remote origins. `'unsafe-inline'` is allowed only because CSS/JS
  are inline; splitting them into files would let you tighten that.
- `allowBackup=false`, cleartext traffic off, and no `INTERNET` permission.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `SDK location not found` | Open the project in Android Studio, or create `local.properties` with `sdk.dir=/path/to/Android/sdk` |
| `Failed to find target with hash string 'android-36'` | SDK Manager ▸ install *Android SDK Platform 36* |
| `Unsupported class file major version` / `requires Java 17` | Use Android Studio's bundled JDK (Settings ▸ Build Tools ▸ Gradle ▸ Gradle JDK) or any JDK 17+ |
| AGP/Gradle mismatch (`Minimum supported Gradle version is…`) | Edit `distributionUrl` in `gradle/wrapper/gradle-wrapper.properties` to the version the error names, or use the AGP Upgrade Assistant |
| `Could not resolve androidx…` | Needs internet for the first sync; check proxy settings. A library version in `libs.versions.toml` may not exist: pick one Android Studio suggests |
| `Release build needs signing` | Create `keystore.properties` (step 4) |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | An app with this ID but a different signature is installed. Uninstall it first (this deletes its data) |
| `INSTALL_FAILED_VERSION_DOWNGRADE` | Raise `versionCode` or uninstall the installed one |
| Blank/white screen | Debug build: open `chrome://inspect` on a PC with the phone attached and look at the console. Check that `assets/www/index.html` exists. Check the Android System WebView app is enabled and updated |
| "Couldn't show the calculator" screen | The page failed to load. Tap *Try again*; if it persists, check `assets/www` was not excluded from the build |
| Hindi shows empty boxes | The `fonts/` files are missing from `assets/www/fonts`, or `index.html` font paths were changed |
| Keyboard covers a field | Make sure `windowSoftInputMode="adjustResize"` is still in the manifest and the insets listener in `MainActivity` is intact |
| Release APK behaves differently from debug | Check `app/build/outputs/mapping/release/` and `proguard-rules.pro`; this app should need no keep rules |

## Licences

Poppins font: SIL Open Font License 1.1 (`assets/www/fonts/OFL.txt`). Gradle wrapper: Apache 2.0.
The Gradle wrapper JAR in this archive was generated by a locally installed Gradle; you can regenerate it with
`gradle wrapper --gradle-version 8.13` if you prefer to produce it yourself.
