#!/usr/bin/env python3
"""
Desktop-browser regression tests for the CUBIQ web app (app/src/main/assets/www).

These exercise the real page in headless Chromium: auto-recalculation on every
input, unit conversion, validation, reset, language switching, and "no network
requests". They do NOT replace testing on a real Android device / WebView.

Run:
    pip install playwright && playwright install chromium
    python3 tests/ui_test.py
Optional screenshots: python3 tests/ui_test.py --shots out_dir
"""
import functools
import http.server
import os
import sys
import threading

from playwright.sync_api import sync_playwright

WWW = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets", "www")
failures = []
checks = 0


def check(name, actual, expected):
    global checks
    checks += 1
    if actual != expected:
        failures.append(f"FAIL {name}: got {actual!r}, expected {expected!r}")
        print(failures[-1])


def serve():
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=WWW)
    handler.log_message = lambda *a, **k: None
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def txt(pg, sel):
    return pg.inner_text(sel).strip()


def enter(pg, sel, value):
    pg.click(sel)
    pg.fill(sel, "")
    if value:
        pg.type(sel, value)


def main():
    shots = sys.argv[sys.argv.index("--shots") + 1] if "--shots" in sys.argv else None
    srv = serve()
    base = f"http://127.0.0.1:{srv.server_address[1]}/index.html"
    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 360, "height": 740}, device_scale_factor=2, has_touch=True)
        pg = ctx.new_page()
        console_errors, external = [], []
        pg.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: console_errors.append(str(e)))
        pg.on("request", lambda r: external.append(r.url) if not r.url.startswith(f"http://127.0.0.1:{srv.server_address[1]}/") else None)
        pg.goto(base)
        pg.wait_for_function("document.fonts.status === 'loaded'")

        # ---------- core unit checks ----------
        ev = lambda js: pg.evaluate(js)
        check("indian grouping", ev("CubiqCore.formatIndian(1234567.5,2)"), "12,34,567.50")
        check("indian small", ev("CubiqCore.formatIndian(999.999,2)"), "1,000.00")
        check("inr", ev("CubiqCore.formatINR(100000)"), "₹1,00,000.00")
        check("parse comma decimal", ev("CubiqCore.parseNumeric('12,5').value"), 12.5)
        check("parse thousands", ev("CubiqCore.parseNumeric('1,234.5').value"), 1234.5)
        check("parse hindi digits", ev("CubiqCore.parseNumeric('१२.५').value"), 12.5)
        for bad in ["abc", "1e5", "Infinity", "NaN", "0x10", "1.2.3", "--1", "+5", "1,2,3"]:
            check(f"reject {bad}", ev(f"CubiqCore.parseNumeric({bad!r}).status"), "invalid")
        check("negative", ev("CubiqCore.parseNumeric('-5').status"), "negative")
        check("qty decimal", ev("CubiqCore.parseNumeric('2.5', true).status"), "notint")
        # math: 10x5x2 cm -> 2*(50+20+10)=160
        check("sa cm", ev("CubiqCore.compute({l:'10',w:'5',h:'2',unit:'cm',qty:'1',rate:''}).areaPerItem"), 160)
        check("sa mm", ev("Math.round(CubiqCore.compute({l:'100',w:'50',h:'20',unit:'mm',qty:'1',rate:''}).areaPerItem*1e6)/1e6"), 160)
        check("sa m", ev("Math.round(CubiqCore.compute({l:'0.1',w:'0.05',h:'0.02',unit:'m',qty:'1',rate:''}).areaPerItem*1e6)/1e6"), 160)
        check("sa in", ev("Math.round(CubiqCore.compute({l:'1',w:'1',h:'1',unit:'in',qty:'1',rate:''}).areaPerItem*1e4)/1e4"), 38.7096)
        check("no NaN/Infinity", ev("""(() => { const bad=['','abc','-1','0','1e400','9'.repeat(400)];
            for (const a of bad) for (const b of bad) { const r=CubiqCore.compute({l:a,w:b,h:'1',unit:'cm',qty:a,rate:b});
              for (const k of ['areaPerItem','totalArea','cost']) if (r[k]!==null && !Number.isFinite(r[k])) return false; }
            return true; })()"""), True)

        # ---------- UI: initial state ----------
        check("default unit", ev("document.querySelector('input[name=unit]:checked').value"), "cm")
        check("default qty", pg.input_value("#qty"), "1")
        check("initial total", txt(pg, "#r-tot"), "—")
        check("initial hint shown", "Enter length" in txt(pg, "#hint"), True)

        # ---------- UI: instant recalculation on every input ----------
        enter(pg, "#len", "10")
        enter(pg, "#wid", "5")
        check("two dims only: still empty", txt(pg, "#r-per"), "—")
        enter(pg, "#hei", "2")
        check("per item after 3rd dim (no button)", txt(pg, "#r-per"), "160.00")
        check("total qty 1", txt(pg, "#r-tot"), "160.00")
        check("cost blank without rate", txt(pg, "#r-cost"), "—")
        check("rate hint", "rate" in txt(pg, "#hint").lower(), True)
        enter(pg, "#rate", "0.5")
        check("cost with rate", txt(pg, "#r-cost"), "₹80.00")
        enter(pg, "#qty", "4")
        check("qty 4 total area", txt(pg, "#r-tot"), "640.00")
        check("qty 4 cost", txt(pg, "#r-cost"), "₹320.00")
        check("bar area", txt(pg, "#b-area"), "640.00")
        check("bar cost", txt(pg, "#b-cost"), "₹320.00")
        enter(pg, "#rate", "1")
        check("rate change updates cost", txt(pg, "#r-cost"), "₹640.00")
        pg.click("#qty-inc")
        check("stepper inc", pg.input_value("#qty"), "5")
        check("stepper updates total", txt(pg, "#r-tot"), "800.00")
        pg.click("#qty-dec"); pg.click("#qty-dec"); pg.click("#qty-dec"); pg.click("#qty-dec"); pg.click("#qty-dec")
        check("stepper floor at 1", pg.input_value("#qty"), "1")
        # faces
        check("face lw", txt(pg, "#f-lw"), "50.00 × 2 = 100.00")
        check("face lh", txt(pg, "#f-lh"), "20.00 × 2 = 40.00")
        check("face wh", txt(pg, "#f-wh"), "10.00 × 2 = 20.00")

        # units (select by clicking the visible label)
        for unit, l, w, h in [("mm", "100", "50", "20"), ("m", "0.1", "0.05", "0.02")]:
            pg.click(f"label:has(input[value='{unit}'])")
            enter(pg, "#len", l); enter(pg, "#wid", w); enter(pg, "#hei", h)
            check(f"unit {unit}", txt(pg, "#r-per"), "160.00")
        # change unit with values fixed -> instant update
        pg.click("label:has(input[value='cm'])")
        check("unit switch recalculates", txt(pg, "#r-per"), "0.0160")  # 0.1x0.05x0.02 cm -> tiny areas keep 4 decimals
        pg.click("label:has(input[value='in'])")
        enter(pg, "#len", "1"); enter(pg, "#wid", "1"); enter(pg, "#hei", "1")
        check("inch cube", txt(pg, "#r-per"), "38.71")

        # ---------- validation ----------
        pg.click("label:has(input[value='cm'])")
        enter(pg, "#len", "-3")
        check("negative message", "Negative" in txt(pg, "#len-e"), True)
        check("negative blocks result", txt(pg, "#r-per"), "—")
        enter(pg, "#len", "abc")
        check("non-numeric message", "valid number" in txt(pg, "#len-e"), True)
        enter(pg, "#len", "0")
        check("zero message", "greater than zero" in txt(pg, "#len-e"), True)
        enter(pg, "#len", "1e9")
        check("exponent rejected", "valid number" in txt(pg, "#len-e"), True)
        enter(pg, "#len", "99999999")
        check("too large message", "Too large" in txt(pg, "#len-e"), True)
        enter(pg, "#len", "100000"); enter(pg, "#wid", "100000"); enter(pg, "#hei", "100000")
        check("max cube per item", txt(pg, "#r-per"), "60,00,00,00,000.00")
        enter(pg, "#qty", "1000000")
        check("overflow total hidden", txt(pg, "#r-tot"), "—")
        check("overflow warning", "too large" in txt(pg, "#warn").lower(), True)
        enter(pg, "#qty", "")
        check("empty qty message", "quantity" in txt(pg, "#qty-e").lower(), True)
        check("empty qty: no stale total", txt(pg, "#r-tot"), "—")
        enter(pg, "#qty", "0")
        check("qty zero message", "greater than zero" in txt(pg, "#qty-e").lower(), True)
        enter(pg, "#qty", "2.5")
        check("qty decimal message", "whole number" in txt(pg, "#qty-e").lower(), True)
        enter(pg, "#qty", "1")
        enter(pg, "#rate", "-1")
        check("negative rate message", "Negative" in txt(pg, "#rate-e"), True)
        check("negative rate: no cost", txt(pg, "#r-cost"), "—")
        enter(pg, "#rate", "0")
        enter(pg, "#len", "10"); enter(pg, "#wid", "5"); enter(pg, "#hei", "2")
        check("rate zero gives zero cost", txt(pg, "#r-cost"), "₹0.00")
        enter(pg, "#rate", "1234.5")
        check("indian currency", txt(pg, "#r-cost"), "₹1,97,520.00")
        enter(pg, "#rate", "२")
        check("hindi digit rate", txt(pg, "#r-cost"), "₹320.00")

        # ---------- language ----------
        pg.click("#lang")
        check("lang attr hi", ev("document.documentElement.lang"), "hi")
        check("hindi label", txt(pg, "label[for=len]"), "लंबाई")
        check("hindi reset", txt(pg, "#reset"), "रीसेट")
        check("values survive language switch", txt(pg, "#r-cost"), "₹320.00")
        enter(pg, "#len", "-1")
        check("hindi error", "ऋणात्मक" in txt(pg, "#len-e"), True)
        pg.reload(); pg.wait_for_function("document.fonts.status === 'loaded'")
        check("language persisted", ev("document.documentElement.lang"), "hi")
        pg.click("#lang")
        check("back to english", txt(pg, "label[for=len]"), "Length")

        # ---------- reset ----------
        enter(pg, "#len", "10"); enter(pg, "#wid", "5"); enter(pg, "#hei", "2"); enter(pg, "#qty", "9"); enter(pg, "#rate", "3")
        pg.click("label:has(input[value='mm'])")
        pg.click("#reset")
        check("reset len", pg.input_value("#len"), "")
        check("reset qty", pg.input_value("#qty"), "1")
        check("reset rate", pg.input_value("#rate"), "")
        check("reset unit", ev("document.querySelector('input[name=unit]:checked').value"), "cm")
        check("reset results cleared", [txt(pg, "#r-per"), txt(pg, "#r-tot"), txt(pg, "#r-cost"), txt(pg, "#b-cost")], ["—"] * 4)
        check("reset keeps language", ev("document.documentElement.lang"), "en")
        check("reset clears errors", [txt(pg, "#len-e"), txt(pg, "#qty-e")], ["", ""])

        # ---------- environment ----------
        check("no external requests", external, [])
        check("no console/page errors", console_errors, [])
        # fonts actually come from the bundled files
        check("fonts loaded locally", ev("[...document.fonts].every(f => f.status === 'loaded' || f.status === 'unloaded')"), True)

        # ---------- layout on tiny + large screens ----------
        for w, h in [(320, 568), (360, 740), (412, 915), (800, 1280)]:
            pg.set_viewport_size({"width": w, "height": h})
            enter(pg, "#len", "1234.5"); enter(pg, "#wid", "678"); enter(pg, "#hei", "90"); enter(pg, "#rate", "0.75")
            check(f"no horizontal scroll {w}x{h}", ev("document.documentElement.scrollWidth <= window.innerWidth"), True)
            check(f"bar visible {w}x{h}", pg.is_visible(".bar"), True)
            if shots:
                os.makedirs(shots, exist_ok=True)
                pg.evaluate("window.scrollTo(0,0)")
                pg.screenshot(path=os.path.join(shots, f"cubiq_{w}x{h}.png"))
        if shots:
            pg.set_viewport_size({"width": 360, "height": 740})
            pg.click("#lang")
            pg.screenshot(path=os.path.join(shots, "cubiq_hindi.png"))
        browser.close()
    srv.shutdown()
    print(f"{checks} checks, {len(failures)} failures")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
