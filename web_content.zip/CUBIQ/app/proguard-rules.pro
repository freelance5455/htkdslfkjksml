# CUBIQ uses no reflection and exposes no JavaScript interfaces, so no keep rules are required.
# If you ever add @JavascriptInterface classes, keep their annotated methods here, e.g.:
# -keepclassmembers class app.cubiq.calculator.YourBridge { @android.webkit.JavascriptInterface <methods>; }
