import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
}

// Release signing values come from keystore.properties (never committed). See README.md.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val hasKeystore = !keystoreProps.isEmpty()

android {
    namespace = "app.cubiq.calculator"
    compileSdk = 36

    defaultConfig {
        // NOTE: change this ONLY if you deliberately want to replace an older CUBIQ install
        // (it must then match the old app's ID *and* signing key). See README.md.
        applicationId = "app.cubiq.calculator"
        minSdk = 26          // Android 8.0: adaptive icons, ~97% of active devices
        targetSdk = 36       // Android 16: Google Play's target-API requirement from 31 Aug 2026
        versionCode = 1      // integer, must increase with every release
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            if (hasKeystore) {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (hasKeystore) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // .woff files are already compressed; storing them uncompressed lets Android mmap them.
    androidResources {
        noCompress += listOf("woff", "woff2")
    }

    lint {
        abortOnError = true
        warningsAsErrors = false
    }
}

dependencies {
    implementation(libs.androidx.activity)
    implementation(libs.androidx.core)
    implementation(libs.androidx.webkit)
}

// Fail early with a clear message instead of producing an unsigned (uninstallable) release APK.
gradle.taskGraph.whenReady {
    val wantsRelease = hasTask(":app:assembleRelease") || hasTask(":app:bundleRelease")
    if (wantsRelease && !hasKeystore) {
        throw GradleException(
            "Release build needs signing. Copy keystore.properties.example to keystore.properties " +
                "and fill it in (see README.md, section 'Build a signed release APK')."
        )
    }
}
