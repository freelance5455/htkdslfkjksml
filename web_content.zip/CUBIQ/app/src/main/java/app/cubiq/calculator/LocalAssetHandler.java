package app.cubiq.calculator;

import android.content.Context;
import android.content.res.AssetManager;
import android.webkit.WebResourceResponse;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Serves ONLY files under assets/www/ and ONLY known web file types, with correct MIME types.
 * Plugged into {@link WebViewAssetLoader}, so the page is loaded from
 * https://appassets.androidplatform.net/app/... instead of file:// URLs. That means
 * file access can stay disabled and the page gets a proper secure origin.
 */
final class LocalAssetHandler implements WebViewAssetLoader.PathHandler {

    private final AssetManager assets;

    LocalAssetHandler(@NonNull Context context) {
        this.assets = context.getApplicationContext().getAssets();
    }

    @Nullable
    @Override
    public WebResourceResponse handle(@NonNull String path) {
        if (path.isEmpty() || path.endsWith("/")) {
            path = path + "index.html";
        }
        // No traversal, no absolute or odd paths.
        if (path.startsWith("/") || path.contains("..") || path.contains("\\") || path.contains("//")) {
            return null;
        }
        String mime = mimeFor(path);
        if (mime == null) {
            return null; // unknown type: refuse to serve
        }
        try {
            InputStream in = assets.open("www/" + path);
            Map<String, String> headers = new HashMap<>();
            headers.put("X-Content-Type-Options", "nosniff");
            String encoding = mime.startsWith("text/") || mime.endsWith("json") || mime.endsWith("svg+xml") ? "utf-8" : null;
            return new WebResourceResponse(mime, encoding, 200, "OK", headers, in);
        } catch (IOException e) {
            return null;
        }
    }

    @Nullable
    private static String mimeFor(@NonNull String path) {
        int dot = path.lastIndexOf('.');
        if (dot < 0) {
            return null;
        }
        switch (path.substring(dot + 1).toLowerCase(Locale.ROOT)) {
            case "html": return "text/html";
            case "js":   return "text/javascript";
            case "css":  return "text/css";
            case "json": return "application/json";
            case "woff": return "font/woff";
            case "woff2": return "font/woff2";
            case "png":  return "image/png";
            case "svg":  return "image/svg+xml";
            default:     return null;
        }
    }
}
