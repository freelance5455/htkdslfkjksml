package app.cubiq.calculator;

import android.annotation.SuppressLint;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.SystemBarStyle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewFeature;

import java.io.ByteArrayInputStream;
import java.util.Collections;

/**
 * Hosts the offline CUBIQ calculator (assets/www/index.html) in a locked-down WebView.
 *
 * Security posture:
 *  - Content comes only from the app's own assets via WebViewAssetLoader (https origin, no file://).
 *  - File and content-provider access disabled; mixed content never allowed.
 *  - Every non-app request is answered with an empty 403, and navigation away from the app is cancelled.
 *  - No JavaScript interfaces are registered.
 *  - The manifest declares no permissions (not even INTERNET).
 */
public class MainActivity extends ComponentActivity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String APP_PATH = "/app/";
    private static final String START_URL = "https://" + HOST + APP_PATH + "index.html";
    private static final int BACKGROUND = Color.parseColor("#0F0C29");

    @Nullable private WebView webView;
    private View errorView;
    private WebViewAssetLoader assetLoader;
    private boolean loadFailed;

    /** Enabled only while the WebView has history; otherwise the system handles Back (predictive-back friendly). */
    private final OnBackPressedCallback backCallback = new OnBackPressedCallback(false) {
        @Override
        public void handleOnBackPressed() {
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // Must be called before super.onCreate(). Dark icons-on-light are NOT wanted: our background is dark.
        EdgeToEdge.enable(this,
                SystemBarStyle.dark(Color.TRANSPARENT),
                SystemBarStyle.dark(Color.TRANSPARENT));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root);
        errorView = findViewById(R.id.error_view);
        webView = findViewById(R.id.webview);
        findViewById(R.id.retry).setOnClickListener(v -> loadCalculator());

        // Edge-to-edge: pad for system bars / cutouts, and for the keyboard so inputs and the
        // bottom summary bar are never hidden behind it.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler(APP_PATH, new LocalAssetHandler(this))
                .build();

        // Lets you inspect the page at chrome://inspect, in debug builds only (release builds are not debuggable).
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        configureWebView(webView);
        getOnBackPressedDispatcher().addCallback(this, backCallback);
        loadCalculator();
    }

    @SuppressLint("SetJavaScriptEnabled") // intentional: local, bundled content only (see class comment)
    private void configureWebView(@NonNull WebView view) {
        view.setBackgroundColor(BACKGROUND);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);

        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);   // required: the calculator logic is JavaScript (local content only)
        s.setDomStorageEnabled(true);   // localStorage, used only to remember the chosen language
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        // The page is already dark; stop the system from "darkening" it a second time.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, false);
        }

        view.setWebViewClient(new CubiqClient());
        // No addJavascriptInterface(): nothing from the page can call into native code.
    }

    private void loadCalculator() {
        if (webView == null) {
            return;
        }
        loadFailed = false;
        errorView.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        webView.loadUrl(START_URL);
    }

    private void showError() {
        loadFailed = true;
        if (webView != null) {
            webView.setVisibility(View.INVISIBLE);
        }
        errorView.setVisibility(View.VISIBLE);
    }

    private static boolean isAppUrl(@NonNull Uri uri) {
        String path = uri.getPath();
        return "https".equals(uri.getScheme())
                && HOST.equals(uri.getHost())
                && path != null && path.startsWith(APP_PATH);
    }

    private final class CubiqClient extends WebViewClient {

        @Nullable
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            WebResourceResponse local = assetLoader.shouldInterceptRequest(request.getUrl());
            if (local != null) {
                return local;
            }
            // Anything that is not our own bundled content (including accidental favicon or network
            // requests) is answered locally with an empty 403, so nothing ever leaves the device.
            return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked",
                    Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            // true = cancel. Only our own pages may load; no external navigation, no intents.
            return !isAppUrl(request.getUrl());
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                showError();
            }
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            if (request.isForMainFrame()) {
                showError();
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (!loadFailed) {
                errorView.setVisibility(View.GONE);
            }
        }

        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
            backCallback.setEnabled(view.canGoBack());
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // The renderer crashed or was killed to free memory. Returning true keeps the app alive;
            // we throw the dead WebView away and rebuild the screen.
            if (view == webView) {
                ViewGroup parent = (ViewGroup) view.getParent();
                if (parent != null) {
                    parent.removeView(view);
                }
                view.destroy();
                webView = null;
                recreate();
            }
            return true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        // Detach and destroy the WebView explicitly so it cannot leak the Activity.
        if (webView != null) {
            ViewGroup parent = (ViewGroup) webView.getParent();
            if (parent != null) {
                parent.removeView(webView);
            }
            webView.stopLoading();
            webView.setWebViewClient(new WebViewClient());
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
