# CUBIQ test checklist

**Test status at hand-over**

- Done: `tests/ui_test.py` ran in headless desktop Chromium: 90 checks passed (calculations, instant recalculation,
  validation, reset, language, no network requests, layout at 320/360/412/800 px wide).
- **Not done: any test on an Android 16 device, any other Android device, an emulator, or the real Android WebView.**
  Every box below is for you to tick on a real device. Nothing in this file has been run on Android.

Tester: ________  Device/model: ________  Android version: ________  WebView version: ________  App versionName: ________

## 1. Install and launch (Android 16)

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 1.1 | Install the release APK on an Android 16 device or emulator | Installs with no warning other than "unknown source" | |
| 1.2 | Launch from the home screen | Dark purple screen appears at once, no white flash, no loading screen | |
| 1.3 | Check launcher icon | White/lavender cube; themed (monochrome) icon works if themed icons are on | |
| 1.4 | Check status/navigation bars | Content is not hidden behind them; notch/cut-out respected | |
| 1.5 | Settings ▸ Apps ▸ CUBIQ ▸ Permissions | "No permissions requested" | |

## 2. Offline

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 2.1 | Turn on airplane mode, Wi-Fi off, force-stop and reopen the app | Opens and works exactly as online | |
| 2.2 | Run sections 3 to 6 in airplane mode | Everything passes | |
| 2.3 | Confirm fonts look the same offline (Poppins; Hindi renders properly) | No missing glyphs or boxes, ₹ shows | |

## 3. Instant recalculation (no Calculate button exists)

Start with Reset. Unit = cm.

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 3.1 | Type L=10, W=5 | Results still "—"; hint asks for all three | |
| 3.2 | Type H=2 | Per item **160.00 cm²** appears immediately; total **160.00**; cost "—" | |
| 3.3 | Faces | Top/Bottom 50.00 × 2 = 100.00; Front/Back 20.00 × 2 = 40.00; Left/Right 10.00 × 2 = 20.00 | |
| 3.4 | Type rate 0.5 | Cost **₹80.00** at once | |
| 3.5 | Set quantity 1 → 4 (typing) | Total **640.00 cm²**, cost **₹320.00** at once | |
| 3.6 | Tap **+** then **−** | Quantity changes; totals follow; cannot go below 1 | |
| 3.7 | Change rate to 2.75 | Cost **₹1,760.00** at once | |
| 3.8 | Change L to 20 | Every result updates at once | |
| 3.9 | Delete rate (empty) | Cost returns to "—" and a hint appears; no stale number | |
| 3.10 | Bottom bar (total area / cost) | Matches the Results card at every step | |

## 4. Units (each case must give the same 160.00 cm² per item)

| # | Unit | L × W × H | Expected per item |
|---|---|---|---|
| 4.1 | cm | 10 × 5 × 2 | 160.00 |
| 4.2 | mm | 100 × 50 × 20 | 160.00 |
| 4.3 | m | 0.1 × 0.05 × 0.02 | 160.00 |
| 4.4 | in | 1 × 1 × 1 | 38.71 (38.7096) |
| 4.5 | in | 10 × 5 × 2 | 1,032.26 |
| 4.6 | any | Switch the unit with values filled in | Result updates immediately, "In centimetres" line changes |
| 4.7 | cm | 1234.5 × 678 × 90, qty 1, rate 1 | per item 20,18,232.00 (Indian digit grouping) |

## 5. Quantity, rate, currency, reset

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 5.1 | 10×5×2 cm, rate 1234.5, qty 1 | ₹1,97,520.00 (lakh grouping, ₹ sign) | |
| 5.2 | Rate 0 | ₹0.00 (allowed) | |
| 5.3 | Fill everything, change unit to mm, tap **Reset** | Fields empty, quantity 1, unit cm, results "—", errors gone, language unchanged, cursor in Length | |

## 6. Hindi / English

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 6.1 | Tap "हिन्दी" | All labels, hints and errors switch to Hindi; button now says "English" | |
| 6.2 | Values entered earlier | Stay and stay correct | |
| 6.3 | Close and reopen the app | Language remembered | |
| 6.4 | Type with a Hindi keyboard, digits like १२ | Treated as 12 | |
| 6.5 | Switch back to English | All text English | |

## 7. Small screens, rotation and keyboard

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 7.1 | Smallest device / emulator (about 320 dp wide) | No horizontal scrolling; three dimension boxes readable; buttons easy to tap | |
| 7.2 | Tap each field | Numeric keyboard opens; the field and the bottom summary bar stay visible above the keyboard | |
| 7.3 | "Next" key on the keyboard | Moves Length → Width → Height → Quantity → Rate | |
| 7.4 | Rotate the phone | Values and results stay; layout stays usable | |
| 7.5 | Tablet / foldable / split-screen / large font (Settings ▸ Display ▸ Font size) | Layout still usable, nothing cut off | |
| 7.6 | Press **Back** | App closes (or goes to home with the predictive-back animation) | |
| 7.7 | Home, wait, return; also lock and unlock | Values still there, results correct | |

## 8. Invalid input and extreme values (no NaN, Infinity or blank/stuck screen anywhere)

| # | Enter | Expected |
|---|---|---|
| 8.1 | Length `-3` | "Negative values are not allowed."; no result |
| 8.2 | Length `abc`, `1e5`, `1.2.3`, `.` | "Enter a valid number." |
| 8.3 | Length `0` | "Must be greater than zero." |
| 8.4 | Length `99999999` (cm) | "Too large. Maximum is 1,00,000 cm." (units follow the selected unit) |
| 8.5 | 100000 × 100000 × 100000 cm | Per item 60,00,00,00,000.00 cm²; no error |
| 8.6 | The same with quantity 1000000 | Total hidden ("—") and a "result is too large" message |
| 8.7 | Quantity empty / 0 / 2.5 / -1 | "Enter a quantity (minimum 1)." / "Must be greater than zero." / "Enter a whole number." / negative message; totals blank, never stale |
| 8.8 | Rate -1 | Negative message; cost "—" |
| 8.9 | Decimal comma `12,5` | Read as 12.5 |
| 8.10 | Paste a very long number | No crash; "too large" or invalid message |

## 9. Reinstall and upgrade

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 9.1 | Install v1 (versionCode 1), set Hindi, then install v2 (higher versionCode, same key) with `adb install -r` | Upgrades in place, opens normally, language kept | |
| 9.2 | Try installing a lower versionCode | Android refuses (`VERSION_DOWNGRADE`); expected | |
| 9.3 | Try installing an APK signed with a different key | `UPDATE_INCOMPATIBLE`; expected | |
| 9.4 | Uninstall and reinstall | Clean start, English or system language default | |
| 9.5 | Old CUBIQ.apk installed too | New app (`app.cubiq.calculator`) installs separately unless ID **and** signing key match | |

## 10. Robustness

| # | Steps | Expected | ✔ |
|---|---|---|---|
| 10.1 | Developer options ▸ "Don't keep activities", switch away and back | App recovers; no crash | |
| 10.2 | Background the app for a long time, open many other apps, return | App recovers (it may reload; the error screen's *Try again* works if shown) | |
| 10.3 | Disable "Android System WebView" (only on a test device) and launch | Android handles it; re-enable afterwards | |
| 10.4 | Check `adb logcat` while using the app | No `FATAL EXCEPTION`, no blocked-request spam | |

## Automated page tests (desktop)

```
pip install playwright && playwright install chromium
python3 tests/ui_test.py                # expect "90 checks, 0 failures"
python3 tests/ui_test.py --shots shots  # also writes screenshots
```
These check only the web page in desktop Chromium, not the Android wrapper.

## Before every release

- [ ] `versionCode` raised, `versionName` updated
- [ ] `python3 tests/ui_test.py` passes
- [ ] Sections 1 to 9 run on at least one real device, one small-screen device or emulator, and the newest Android version available
- [ ] `apksigner verify --print-certs` shows your release certificate
