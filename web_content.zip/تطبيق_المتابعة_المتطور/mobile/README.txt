هذه حزمة مصدر للهاتف باستخدام Capacitor.
Android: npm install ثم npx cap add android ثم npx cap sync ثم npx cap open android، وبعدها Build APK من Android Studio.
iPhone: npm install ثم npx cap add ios ثم npx cap sync ثم npx cap open ios. يلزم Xcode وحساب Apple للتوقيع والتثبيت على أجهزة iPhone. لا يمكن إنشاء IPA موقّع للتوزيع على أي iPhone مباشرة دون شهادات Apple.
