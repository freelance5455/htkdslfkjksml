لتوليد EXE على ويندوز: ثبّت Node.js ثم داخل هذا المجلد نفّذ: npm install ثم npm run build. سينتج مثبت NSIS ونسخة Portable.
