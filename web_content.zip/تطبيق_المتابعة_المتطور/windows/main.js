const {app,BrowserWindow}=require("electron"); const path=require("path");
function create(){const w=new BrowserWindow({width:1200,height:800,webPreferences:{contextIsolation:true}});w.loadFile(path.join(__dirname,"..","pwa","index.html"))}
app.whenReady().then(()=>{create();app.on("activate",()=>BrowserWindow.getAllWindows().length||create())});
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit()});