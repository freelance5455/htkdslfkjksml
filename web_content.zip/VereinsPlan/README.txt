# VereinsPlan – Android-PWA

## Inhalt
- `index.html`: Kalender-App
- `manifest.webmanifest`: Installationsinformationen
- `sw.js`: Offline-Caching
- `icon-192.png` und `icon-512.png`: App-Symbole

## Installation auf Android
Eine installierbare PWA benötigt eine sichere HTTPS-Adresse (oder localhost). Eine ZIP-Datei allein kann Chrome nicht als installierbare App registrieren.

1. Entpacke diese ZIP-Datei.
2. Lade den gesamten Inhalt in einen statischen Webhoster hoch, der HTTPS bereitstellt (z. B. einen privaten Webspace).
3. Öffne die HTTPS-Adresse in Google Chrome auf deinem Android-Handy.
4. Tippe auf das Chrome-Menü ⋮ und wähle „App installieren“ bzw. „Zum Startbildschirm hinzufügen“.
5. Danach kannst du VereinsPlan über das App-Symbol öffnen.

## Datenspeicherung und Datenschutz
Vereine und Termine werden lokal im Browser auf diesem Gerät gespeichert (localStorage). Es gibt keine Anmeldung und keinen Server, der deine Kalenderdaten erhält. Die Daten werden nicht automatisch zwischen Geräten synchronisiert. Nutze „Daten sichern“ in der App regelmäßig, um eine JSON-Sicherung herunterzuladen. Beim Löschen der Browserdaten kann der lokale Kalender verloren gehen.

## Funktionen
- Bis zu fünf Vereine anlegen, umbenennen und löschen
- Termine mit Datum, Uhrzeit, Ort und Notiz erstellen, bearbeiten und löschen
- Gemeinsame Terminübersicht und Filter nach Verein
- Lokale Datenspeicherung und JSON-Backup/Wiederherstellung
- Installierbar als PWA und Offline-Grundfunktion nach dem ersten Laden

Hinweis: Erinnerungsbenachrichtigungen sind in dieser Version noch nicht enthalten.
