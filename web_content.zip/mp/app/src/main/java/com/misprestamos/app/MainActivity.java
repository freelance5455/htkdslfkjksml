package com.misprestamos.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.content.Intent;

public class MainActivity extends Activity {
    private WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        loadPage(web, getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (web != null) loadPage(web, intent);
    }

    private void loadPage(WebView web, Intent intent) {
        if (intent != null && "misprestamos".equals(intent.getScheme()) && "solicitar".equals(intent.getHost())) {
            web.loadUrl("file:///android_asset/index.html?solicitar=1");
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }
}
