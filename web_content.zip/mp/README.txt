MIS PRESTAMOS 3.6

UN SOLO PROYECTO, DOS ACCESOS SEPARADOS

Administracion:
- https://TU-DOMINIO/
- Protegida con PIN.

Solicitud publica:
- https://TU-DOMINIO/solicitar
- Muestra solamente el formulario de solicitud.
- No muestra clientes, prestamos, pagos ni seguridad.
- El boton envia la solicitud al WhatsApp configurado (por defecto +57 300 402 6303).

El enlace anterior ?solicitar=1 tambien sigue funcionando como compatibilidad.

Para publicar Firebase: firebase deploy --only hosting
