# Mis Préstamos — actualización v3.4

Esta versión conserva la aplicación Android existente y añade la carpeta `public/` para publicar la misma interfaz en Firebase Hosting.

Flujo para clientes: `?solicitar=1` abre directamente Solicitar préstamo y envía la solicitud por HTTPS a WhatsApp.

WhatsApp predeterminado: +57 300 402 6303.

Proyecto Firebase configurado: mis-prestamos-21fd9.
Directorio público: public.
SPA: sí, con rewrite a /index.html.

Para publicar: ejecutar `firebase deploy --only hosting` desde esta carpeta después de iniciar sesión en Firebase CLI.
