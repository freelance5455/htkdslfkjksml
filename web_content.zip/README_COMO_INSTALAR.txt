=====================================================
IRONLOG - PACOTE ANDROID / APK
=====================================================

COMO INSTALAR NO CELULAR:

OPÇÃO 1 (MAIS FÁCIL - INSTALAÇÃO DIRETA):
1. No seu celular Android, abra o Google Chrome.
2. Acesse a URL: https://ais-dev-ctkqseztozzscutzrskxmn-295129198716.us-west2.run.app/
3. Toque no botão "Instalar APK" no topo ou vá nos 3 pontinhos (⋮) do Chrome e selecione "Instalar aplicativo".
4. Pronto! O Android compila e instala o WebAPK oficial direto na gaveta de apps.

OPÇÃO 2 (GERAR O ARQUIVO .APK NO PWABUILDER):
1. Acesse: https://www.pwabuilder.com/reportcard?site=https%3A%2F%2Fais-dev-ctkqseztozzscutzrskxmn-295129198716.us-west2.run.app%2F
2. Clique em "Package for Android".
3. Baixe o instalador .apk para o seu smartphone.

OPÇÃO 3 (COMPILAR LOCALMENTE COM CAPACITOR/ANDROID STUDIO):
1. npm install @capacitor/core @capacitor/cli @capacitor/android
2. npx cap init IronLog com.ironlog.app --web-dir dist
3. npx cap add android
4. npx cap open android
=====================================================