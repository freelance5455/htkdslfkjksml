AZOBDEL Android Project (প্রথম সংস্করণ)

এটি Android Studio-তে APK বানানোর জন্য প্রস্তুত WebView project source।
এখনই APK নয়।

APK তৈরির নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio > Open থেকে এই ফোল্ডারটি নির্বাচন করুন।
3. Gradle Sync সম্পন্ন হতে দিন এবং Android SDK Platform 35 ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK পাবেন app/build/outputs/apk/debug/app-debug.apk ফাইলে।

গুরুত্বপূর্ণ:
- হিসাবের ডেটা অ্যাপের WebView local storage-এ থাকে; অ্যাপ ডেটা clear/uninstall করলে হারাতে পারে।
- Google Drive OAuth/backup এখনো যুক্ত করা হয়নি। এর জন্য Google Cloud Console-এ OAuth client ও Drive API কনফিগারেশন প্রয়োজন।
- এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে APK compile করা সম্ভব হয়নি।
