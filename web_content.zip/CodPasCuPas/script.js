const { useState, useEffect, useMemo, useRef, useCallback } = React;

function Icon({ n, size = 20, color = "currentColor", strokeWidth = 2, style }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", style };
  const paths = {
    home: <><path d="M3 11.5L12 4l9 7.5" /><path d="M5 10v10h5v-6h4v6h5V10" /></>,
    book: <path d="M12 6.5C10 5 7 4.5 4 5v13c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V5c-3-.5-6 0-8 1.5v13" />,
    code: <><path d="M9 8l-4 4 4 4" /><path d="M15 8l4 4-4 4" /></>,
    folder: <path d="M3 6h6l2 2h10v11H3z" />,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></>,
    moon: <path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z" />,
    sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.4 1.4M17.6 17.6L19 19M19 5l-1.4 1.4M6.4 17.6L5 19" /></>,
    check: <path d="M20 6L9 17l-5-5" />,
    lock: <><rect x="4" y="10" width="16" height="10" rx="2" /><path d="M7 10V7a5 5 0 0110 0v3" /></>,
    chevronRight: <path d="M9 6l6 6-6 6" />,
    chevronLeft: <path d="M15 6l-6 6 6 6" />,
    reset: <><path d="M3 12a9 9 0 109-9 9.8 9.8 0 00-7 3" /><path d="M3 3v6h6" /></>,
    play: <polygon points="6,4 20,12 6,20" />,
    award: <><circle cx="12" cy="8" r="5" /><path d="M8.5 12.5L7 21l5-2.5L17 21l-1.5-8.5" /></>,
    flame: <path d="M12 2c1 4-4 5-4 9a4 4 0 008 0c0-2-1-3-1-5 2 1 3 3 3 6a6 6 0 01-12 0c0-5 4-6 6-10z" />,
    circleCheck: <><circle cx="12" cy="12" r="9" /><path d="M8 12.5l2.5 2.5L16 9.5" /></>,
    alertCircle: <><circle cx="12" cy="12" r="9" /><path d="M12 8v5" /><circle cx="12" cy="16.2" r="0.6" fill={color} /></>,
    x: <path d="M6 6l12 12M18 6L6 18" />,
  };
  return <svg {...common}>{paths[n] || null}</svg>;
}



/* ============================================================
   DATE STATICE — cursuri, lecții, exerciții, proiecte
   ============================================================ */

const LANG = {
  html: { name: "HTML", color: "#E75A3C", colorSoft: "#FDE8E2" },
  css:  { name: "CSS",  color: "#2F5FEF", colorSoft: "#E3EAFD" },
  js:   { name: "JavaScript", color: "#C9950A", colorSoft: "#FBF0D4" },
};

const COURSES = {
  html: {
    key: "html",
    title: "HTML",
    subtitle: "Scheletul oricărei pagini web",
    lessons: [
      {
        id: "html-1",
        title: "Structura unei pagini HTML",
        topics: ["Structură", "Taguri", "Atribute"],
        explanation:
          "O pagină HTML e formată din taguri — cuvinte între semnele < și > care spun browserului ce este fiecare bucată de conținut. Orice pagină pornește cu un schelet fix: <!DOCTYPE html> anunță tipul documentului, <html> cuprinde tot, <head> conține informații despre pagină (nevăzute de utilizator), iar <body> conține tot ce se vede pe ecran.\n\nMulte taguri au un atribut — o informație suplimentară scrisă în interiorul tagului de deschidere, sub forma nume=\"valoare\". De exemplu lang=\"ro\" spune browserului că pagina e în română.",
        example: `<!DOCTYPE html>
<html lang="ro">
  <head>
    <title>Pagina mea</title>
  </head>
  <body>
    <h1>Salut, lume!</h1>
    <p>Aceasta este prima mea pagină.</p>
  </body>
</html>`,
        exampleNotes: [
          "<!DOCTYPE html> — trebuie să fie mereu prima linie.",
          "<title> — textul care apare în tab-ul browserului.",
          "<h1> și <p> — conținutul vizibil, un titlu și un paragraf.",
        ],
        exercise: {
          instructions:
            "Completează codul de mai jos ca să afișezi titlul paginii \"Prima mea pagină\" (în <title>) și un titlu principal <h1> cu textul \"Bun venit!\".",
          starter: { html: `<!DOCTYPE html>
<html lang="ro">
  <head>
    <title></title>
  </head>
  <body>

  </body>
</html>`, css: "", js: "" },
          check: (c) =>
            /<title>\s*Prima mea pagin[ăa]\s*<\/title>/i.test(c.html) &&
            /<h1>\s*Bun venit!?\s*<\/h1>/i.test(c.html),
          hint: "Nu uita: <title>Prima mea pagină</title> și <h1>Bun venit!</h1>",
        },
      },
      {
        id: "html-2",
        title: "Titluri, paragrafe și liste",
        topics: ["Titluri", "Paragrafe", "Liste"],
        explanation:
          "Există 6 nivele de titlu: <h1> (cel mai important) până la <h6> (cel mai mic). Textul obișnuit se scrie în paragrafe cu <p>.\n\nPentru liste ai două variante: <ul> pentru o listă neordonată (cu buline), și <ol> pentru o listă numerotată. Fiecare element din listă se scrie cu <li>.",
        example: `<h1>Rețeta zilei</h1>
<p>Ingrediente necesare pentru o cină rapidă:</p>
<ul>
  <li>Paste</li>
  <li>Roșii</li>
  <li>Usturoi</li>
</ul>
<h2>Pași</h2>
<ol>
  <li>Fierbe pastele</li>
  <li>Călește usturoiul</li>
</ol>`,
        exampleNotes: [
          "<ul> = listă cu buline (unordered list).",
          "<ol> = listă numerotată (ordered list).",
          "<li> = un element din oricare dintre cele două liste.",
        ],
        exercise: {
          instructions:
            "Creează un <h1> cu textul \"Listă de cumpărături\" și o listă neordonată <ul> cu 3 elemente <li>, oricare ar fi ele.",
          starter: { html: `<h1></h1>\n<ul>\n\n</ul>`, css: "", js: "" },
          check: (c) => {
            const liCount = (c.html.match(/<li>/gi) || []).length;
            return /<h1>[^<]+<\/h1>/i.test(c.html) && /<ul>/i.test(c.html) && liCount >= 3;
          },
          hint: "Ai nevoie de cel puțin 3 taguri <li> în interiorul lui <ul>.",
        },
      },
      {
        id: "html-3",
        title: "Linkuri și imagini",
        topics: ["Linkuri", "Imagini"],
        explanation:
          "Un link se creează cu <a href=\"...\">text</a>. Atributul href indică adresa către care duce linkul.\n\nO imagine se afișează cu <img src=\"...\" alt=\"...\">. Acest tag nu are pereche de închidere. Atributul src este calea către imagine, iar alt este un text alternativ afișat dacă imaginea nu se încarcă (și citit de utilizatorii cu deficiențe de vedere).",
        example: `<a href="https://exemplu.ro">Vizitează site-ul</a>

<img src="https://picsum.photos/200" alt="O imagine aleatorie">`,
        exampleNotes: [
          "href — adresa la care duce linkul.",
          "src — sursa (calea) imaginii.",
          "alt — text descriptiv, obligatoriu pentru accesibilitate.",
        ],
        exercise: {
          instructions:
            "Creează un link către \"https://exemplu.ro\" cu textul \"Click aici\" și adaugă o imagine cu src=\"https://picsum.photos/150\" și un alt descriptiv.",
          starter: { html: `<a href=""></a>\n<img src="" alt="">`, css: "", js: "" },
          check: (c) =>
            /<a\s+href=["']https:\/\/exemplu\.ro["']\s*>[^<]+<\/a>/i.test(c.html) &&
            /<img[^>]*src=["']https:\/\/picsum\.photos\/150["'][^>]*alt=["'][^"']+["']/i.test(c.html),
          hint: "Verifică href-ul exact și că <img> are ambele atribute, src și alt.",
        },
      },
      {
        id: "html-4",
        title: "Tabele",
        topics: ["Tabele"],
        explanation:
          "Un tabel se construiește cu <table>. Fiecare rând e <tr> (table row), iar în interiorul rândului, celulele de titlu sunt <th> (table header) și celulele obișnuite <td> (table data).",
        example: `<table>
  <tr>
    <th>Nume</th>
    <th>Vârstă</th>
  </tr>
  <tr>
    <td>Ana</td>
    <td>21</td>
  </tr>
  <tr>
    <td>Mihai</td>
    <td>24</td>
  </tr>
</table>`,
        exampleNotes: [
          "<tr> — un rând întreg.",
          "<th> — celulă de antet (de obicei îngroșată).",
          "<td> — o celulă obișnuită cu date.",
        ],
        exercise: {
          instructions:
            "Creează un tabel cu un rând de antet (\"Produs\" și \"Preț\") și cel puțin un rând de date.",
          starter: { html: `<table>\n\n</table>`, css: "", js: "" },
          check: (c) => {
            const trCount = (c.html.match(/<tr>/gi) || []).length;
            return /<th>\s*Produs\s*<\/th>/i.test(c.html) && /<th>\s*Pre[țt]\s*<\/th>/i.test(c.html) && trCount >= 2;
          },
          hint: "Primul <tr> conține cele două <th>, al doilea <tr> conține două <td> cu date.",
        },
      },
      {
        id: "html-5",
        title: "Formulare, inputuri și butoane",
        topics: ["Formulare", "Inputuri", "Butoane"],
        explanation:
          "Un formular <form> adună informații de la utilizator. În interior pui câmpuri <input>, al căror tip se stabilește prin atributul type: text, email, password, number etc.\n\nUn <button> este un buton apăsabil — folositor pentru a trimite formularul sau pentru a declanșa acțiuni cu JavaScript mai târziu.",
        example: `<form>
  <label>Nume:</label>
  <input type="text" placeholder="Scrie numele tău">

  <label>Email:</label>
  <input type="email" placeholder="nume@exemplu.ro">

  <button type="submit">Trimite</button>
</form>`,
        exampleNotes: [
          "<label> — o etichetă text pentru un câmp.",
          "type=\"text\" / \"email\" — tipul de date așteptat.",
          "placeholder — text gri de exemplu, care dispare la scris.",
        ],
        exercise: {
          instructions:
            "Creează un <form> cu un <input type=\"text\"> și un <button> cu textul \"Trimite\".",
          starter: { html: `<form>\n\n</form>`, css: "", js: "" },
          check: (c) => /type=["']text["']/i.test(c.html) && /<button[^>]*>\s*Trimite\s*<\/button>/i.test(c.html),
          hint: "Nu uita type=\"text\" pe input și textul exact \"Trimite\" pe buton.",
        },
      },
      {
        id: "html-6",
        title: "Elemente semantice",
        topics: ["Elemente semantice"],
        explanation:
          "Tagurile semantice descriu rolul conținutului, nu doar aspectul lui. În loc de <div> peste tot, HTML modern oferă: <header> (antet), <nav> (meniu de navigare), <main> (conținutul principal), <section> (o secțiune tematică), <article> (conținut de sine stătător) și <footer> (subsol).\n\nAcestea ajută motoarele de căutare și persoanele care folosesc cititoare de ecran să înțeleagă structura paginii.",
        example: `<header>
  <h1>Blogul meu</h1>
  <nav>Acasă | Articole | Contact</nav>
</header>
<main>
  <article>
    <h2>Primul articol</h2>
    <p>Conținutul articolului...</p>
  </article>
</main>
<footer>
  <p>© 2026 Blogul meu</p>
</footer>`,
        exampleNotes: [
          "<header> / <footer> — începutul și sfârșitul paginii sau al unei secțiuni.",
          "<nav> — grupul de linkuri de navigare.",
          "<main> — conținutul unic și principal al paginii.",
        ],
        exercise: {
          instructions:
            "Construiește o structură cu <header> conținând un <h1>, un <main> conținând un <p>, și un <footer> conținând un <p>.",
          starter: { html: `<header>\n\n</header>\n<main>\n\n</main>\n<footer>\n\n</footer>`, css: "", js: "" },
          check: (c) =>
            /<header>[\s\S]*<h1>[\s\S]*<\/h1>[\s\S]*<\/header>/i.test(c.html) &&
            /<main>[\s\S]*<p>[\s\S]*<\/p>[\s\S]*<\/main>/i.test(c.html) &&
            /<footer>[\s\S]*<p>[\s\S]*<\/p>[\s\S]*<\/footer>/i.test(c.html),
          hint: "Fiecare secțiune (header, main, footer) trebuie să conțină tagul cerut în interiorul ei.",
        },
      },
    ],
  },

  css: {
    key: "css",
    title: "CSS",
    subtitle: "Culoare, formă și aranjare",
    lessons: [
      {
        id: "css-1",
        title: "Selectori",
        topics: ["Selectori"],
        explanation:
          "CSS „selectează” elemente HTML ca să le stilizeze. Un selector de tip vizează un tag (p { }), un selector de clasă vizează orice element cu class=\"...\" folosind un punct (.card { }), iar un selector de id vizează un singur element cu id=\"...\" folosind un diez (#titlu { }).\n\nClasele se pot repeta pe mai multe elemente; id-urile trebuie să fie unice în pagină.",
        example: `<p class="atentie">Text important</p>
<h1 id="titlu-principal">Titlu</h1>

/* CSS */
p { color: gray; }
.atentie { font-weight: bold; }
#titlu-principal { text-align: center; }`,
        exampleNotes: [
          "p { } — toate tagurile <p>.",
          ".atentie { } — orice element cu class=\"atentie\".",
          "#titlu-principal { } — elementul cu id=\"titlu-principal\".",
        ],
        exercise: {
          instructions:
            "Ai un <p class=\"mesaj\"> în HTML. Scrie CSS care setează culoarea acelui paragraf în roșu, folosind selectorul de clasă.",
          starter: { html: `<p class="mesaj">Salut!</p>`, css: `\n`, js: "" },
          check: (c) => /\.mesaj\s*\{[^}]*color\s*:\s*red/i.test(c.css),
          hint: "Scrie: .mesaj { color: red; }",
        },
      },
      {
        id: "css-2",
        title: "Culori și fonturi",
        topics: ["Culori", "Fonturi"],
        explanation:
          "Culorile se pot scrie ca nume (red), coduri hexazecimale (#ff0000) sau rgb(255, 0, 0). Proprietatea color schimbă culoarea textului, iar background-color culoarea fundalului.\n\nFontul se schimbă cu font-family, mărimea cu font-size și grosimea cu font-weight (normal, bold sau un număr precum 700).",
        example: `p {
  color: #333333;
  background-color: #f5f5f5;
  font-family: Arial, sans-serif;
  font-size: 18px;
  font-weight: bold;
}`,
        exampleNotes: [
          "color — culoarea textului.",
          "background-color — culoarea fundalului elementului.",
          "font-size în px (pixeli) controlează mărimea textului.",
        ],
        exercise: {
          instructions:
            "Pentru <p class=\"card\"> setează background-color pe \"#f0f0f0\" și font-size pe \"20px\".",
          starter: { html: `<p class="card">Card de test</p>`, css: `\n`, js: "" },
          check: (c) => /\.card\s*\{[^}]*background-color\s*:\s*#f0f0f0[^}]*\}/i.test(c.css.replace(/\s/g, "")) ||
            (/background-color\s*:\s*#f0f0f0/i.test(c.css) && /font-size\s*:\s*20px/i.test(c.css)),
          hint: "În .card { } adaugă background-color: #f0f0f0; și font-size: 20px;",
        },
      },
      {
        id: "css-3",
        title: "Dimensiuni, margini și border",
        topics: ["Dimensiuni", "Margini și spațieri", "Border"],
        explanation:
          "Fiecare element are o lățime (width) și o înălțime (height). În jurul unui element, margin creează spațiu în exterior (între el și vecini), iar padding creează spațiu în interior (între margine și conținut). border desenează o linie în jurul elementului.",
        example: `.cutie {
  width: 200px;
  height: 100px;
  margin: 20px;
  padding: 10px;
  border: 2px solid black;
}`,
        exampleNotes: [
          "margin — spațiu în afara elementului.",
          "padding — spațiu în interiorul elementului, în jurul conținutului.",
          "border: grosime stil culoare — de exemplu 2px solid black.",
        ],
        exercise: {
          instructions:
            "Pentru <div class=\"cutie\"> setează width: 150px, padding: 20px și un border de 1px solid negru.",
          starter: { html: `<div class="cutie">Conținut</div>`, css: `\n`, js: "" },
          check: (c) =>
            /width\s*:\s*150px/i.test(c.css) && /padding\s*:\s*20px/i.test(c.css) && /border\s*:\s*1px\s+solid\s+black/i.test(c.css),
          hint: "Scrie width: 150px; padding: 20px; border: 1px solid black;",
        },
      },
      {
        id: "css-4",
        title: "Flexbox",
        topics: ["Flexbox"],
        explanation:
          "Flexbox aliniază elemente într-un rând sau o coloană cu ușurință. Se activează cu display: flex pe un container. justify-content controlează alinierea orizontală (flex-start, center, space-between), iar align-items controlează alinierea verticală.",
        example: `.container {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
}`,
        exampleNotes: [
          "display: flex — activează flexbox pe container.",
          "justify-content — aliniere pe axa principală (de obicei orizontală).",
          "gap — spațiu între elementele copil.",
        ],
        exercise: {
          instructions:
            "Pentru <div class=\"container\"> activează flexbox și centrează conținutul pe orizontală cu justify-content: center.",
          starter: { html: `<div class="container">\n  <p>A</p><p>B</p>\n</div>`, css: `\n`, js: "" },
          check: (c) => /display\s*:\s*flex/i.test(c.css) && /justify-content\s*:\s*center/i.test(c.css),
          hint: "Scrie display: flex; și justify-content: center; în .container { }",
        },
      },
      {
        id: "css-5",
        title: "Grid",
        topics: ["Grid"],
        explanation:
          "CSS Grid organizează elemente într-un grătar de rânduri și coloane. Se activează cu display: grid. grid-template-columns definește câte coloane există și cât de late sunt — de exemplu repeat(3, 1fr) creează 3 coloane egale.",
        example: `.grila {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}`,
        exampleNotes: [
          "display: grid — activează grila pe container.",
          "grid-template-columns — definește coloanele.",
          "1fr — o „fracțiune” din spațiul disponibil.",
        ],
        exercise: {
          instructions:
            "Pentru <div class=\"grila\"> activează grid cu 2 coloane egale, folosind grid-template-columns: repeat(2, 1fr).",
          starter: { html: `<div class="grila">\n  <p>1</p><p>2</p><p>3</p><p>4</p>\n</div>`, css: `\n`, js: "" },
          check: (c) => /display\s*:\s*grid/i.test(c.css) && /grid-template-columns\s*:\s*repeat\(\s*2\s*,\s*1fr\s*\)/i.test(c.css),
          hint: "Scrie display: grid; și grid-template-columns: repeat(2, 1fr);",
        },
      },
      {
        id: "css-6",
        title: "Responsive design, tranziții și animații",
        topics: ["Responsive design", "Tranziții", "Animații"],
        explanation:
          "Responsive design înseamnă ca pagina să arate bine pe orice ecran. @media (max-width: 600px) { } aplică reguli CSS doar când ecranul e mai îngust de 600px.\n\ntransition face schimbările de stil (culoare, mărime) să se întâmple lin, în loc de brusc. Se scrie ca transition: proprietate durată, de exemplu transition: background-color 0.3s.",
        example: `.buton {
  background-color: #2F5FEF;
  transition: background-color 0.3s;
}
.buton:hover {
  background-color: #1c3fb0;
}

@media (max-width: 600px) {
  .buton { width: 100%; }
}`,
        exampleNotes: [
          ":hover — un stil aplicat când mausul stă deasupra elementului.",
          "transition — animă lin schimbarea unei proprietăți.",
          "@media — reguli speciale pentru ecrane mici.",
        ],
        exercise: {
          instructions:
            "Pentru <div class=\"cutie\"> adaugă transition: background-color 0.3s, iar în interiorul unei reguli @media (max-width: 600px) setează width: 100% pentru .cutie.",
          starter: { html: `<div class="cutie">Redimensionează!</div>`, css: `.cutie {\n  width: 200px;\n  background-color: #eee;\n\n}\n`, js: "" },
          check: (c) => /transition\s*:\s*background-color/i.test(c.css) && /@media[^{]*max-width\s*:\s*600px/i.test(c.css),
          hint: "Adaugă transition: background-color 0.3s; în .cutie, apoi un bloc @media (max-width: 600px) { .cutie { width: 100%; } }",
        },
      },
    ],
  },

  js: {
    key: "js",
    title: "JavaScript",
    subtitle: "Interactivitate și logică",
    lessons: [
      {
        id: "js-1",
        title: "Variabile și tipuri de date",
        topics: ["Variabile", "Tipuri de date"],
        explanation:
          "O variabilă este o „cutie” cu nume care ține o valoare. Se declară cu let (poate fi schimbată mai târziu) sau const (rămâne fixă). Tipurile de bază sunt: numere (23), texte / string-uri (\"salut\"), boolean (true/false).",
        example: `let varsta = 20;
const nume = "Andrei";
let esteActiv = true;

console.log(nume, varsta, esteActiv);`,
        exampleNotes: [
          "let — variabilă care se poate schimba.",
          "const — variabilă constantă, nu se mai schimbă.",
          "console.log() — afișează o valoare (utilă pentru testare).",
        ],
        exercise: {
          instructions:
            "Declară o variabilă const numită oras cu valoarea \"Cluj\" și afișeaz-o cu console.log(oras).",
          starter: { html: "", css: "", js: `\n` },
          check: (c) => /const\s+oras\s*=\s*["']Cluj["']/i.test(c.js) && /console\.log\(\s*oras\s*\)/i.test(c.js),
          hint: "Scrie: const oras = \"Cluj\"; apoi console.log(oras);",
        },
      },
      {
        id: "js-2",
        title: "Operatori și condiții",
        topics: ["Operatori", "Condiții"],
        explanation:
          "Operatorii combină valori: + - * / pentru matematică, === pentru a compara egalitate, > < pentru comparații. Structura if / else execută cod diferit în funcție de o condiție.",
        example: `let varsta = 17;

if (varsta >= 18) {
  console.log("Ești major");
} else {
  console.log("Ești minor");
}`,
        exampleNotes: [
          "=== compară valori fără să le transforme (recomandat față de ==).",
          "if (condiție) { } — rulează codul doar dacă condiția e adevărată.",
          "else { } — codul care rulează dacă if e fals.",
        ],
        exercise: {
          instructions:
            "Scrie o variabilă let nota = 6; și un if/else care afișează \"Promovat\" dacă nota >= 5, altfel \"Picat\".",
          starter: { html: "", css: "", js: `let nota = 6;\n\n` },
          check: (c) => /if\s*\(\s*nota\s*>=\s*5\s*\)/i.test(c.js) && /Promovat/i.test(c.js) && /Picat/i.test(c.js),
          hint: "if (nota >= 5) { console.log(\"Promovat\"); } else { console.log(\"Picat\"); }",
        },
      },
      {
        id: "js-3",
        title: "Bucle",
        topics: ["Bucle"],
        explanation:
          "O buclă repetă cod de mai multe ori. for (let i = 0; i < 5; i++) { } rulează codul de 5 ori, cu i luând valorile 0,1,2,3,4. Bucla while repetă cât timp o condiție rămâne adevărată.",
        example: `for (let i = 1; i <= 5; i++) {
  console.log("Numărul " + i);
}`,
        exampleNotes: [
          "let i = 0 — valoarea de pornire.",
          "i < 5 — condiția care ține bucla activă.",
          "i++ — crește i cu 1 la fiecare pas.",
        ],
        exercise: {
          instructions:
            "Scrie o buclă for care afișează cu console.log numerele de la 1 la 3.",
          starter: { html: "", css: "", js: `\n` },
          check: (c) => /for\s*\(\s*let\s+i\s*=\s*1\s*;\s*i\s*<=\s*3\s*;\s*i\+\+\s*\)/i.test(c.js.replace(/\s/g, "")),
          hint: "for (let i = 1; i <= 3; i++) { console.log(i); }",
        },
      },
      {
        id: "js-4",
        title: "Funcții",
        topics: ["Funcții"],
        explanation:
          "O funcție este un bloc de cod reutilizabil, care poate primi date (parametri) și poate întoarce un rezultat cu return. Se declară cu function nume(parametri) { }.",
        example: `function aduna(a, b) {
  return a + b;
}

let rezultat = aduna(3, 4);
console.log(rezultat);`,
        exampleNotes: [
          "function aduna(a, b) — a și b sunt parametrii funcției.",
          "return — valoarea pe care o „scoate” funcția.",
          "aduna(3, 4) — apelarea funcției cu valori concrete.",
        ],
        exercise: {
          instructions:
            "Scrie o funcție inmulteste(a, b) care întoarce a * b, apoi apeleaz-o cu inmulteste(3, 4) și afișează rezultatul cu console.log.",
          starter: { html: "", css: "", js: `\n` },
          check: (c) => /function\s+inmulteste\s*\(\s*a\s*,\s*b\s*\)/i.test(c.js) && /return\s+a\s*\*\s*b/i.test(c.js) && /console\.log\(\s*inmulteste\(3,\s*4\)\s*\)/i.test(c.js.replace(/\s/g,"")),
          hint: "function inmulteste(a, b) { return a * b; } apoi console.log(inmulteste(3, 4));",
        },
      },
      {
        id: "js-5",
        title: "Array-uri și obiecte",
        topics: ["Array-uri", "Obiecte"],
        explanation:
          "Un array este o listă ordonată de valori: let fructe = [\"măr\", \"pară\"]. Se accesează cu index, pornind de la 0: fructe[0].\n\nUn obiect grupează date înrudite sub formă de perechi cheie: valoare: let persoana = { nume: \"Ana\", varsta: 22 }. Se accesează cu punct: persoana.nume.",
        example: `let fructe = ["măr", "pară", "banană"];
console.log(fructe[0]);

let persoana = { nume: "Ana", varsta: 22 };
console.log(persoana.nume);`,
        exampleNotes: [
          "fructe[0] — primul element al array-ului (index 0).",
          "persoana.nume — proprietatea „nume” a obiectului.",
          "Array-urile și obiectele pot fi combinate liber.",
        ],
        exercise: {
          instructions:
            "Creează un array culori cu 3 texte și afișează al doilea element (index 1) cu console.log.",
          starter: { html: "", css: "", js: `\n` },
          check: (c) => {
            const m = c.js.match(/let\s+culori\s*=\s*\[([^\]]+)\]/i);
            if (!m) return false;
            const items = m[1].split(",").filter(Boolean);
            return items.length >= 3 && /console\.log\(\s*culori\[1\]\s*\)/i.test(c.js);
          },
          hint: "let culori = [\"roșu\", \"verde\", \"albastru\"]; apoi console.log(culori[1]);",
        },
      },
      {
        id: "js-6",
        title: "Evenimente și DOM",
        topics: ["Evenimente", "DOM", "Interacțiunea cu elementele HTML"],
        explanation:
          "DOM (Document Object Model) este reprezentarea paginii HTML în JavaScript. document.querySelector(\"selector\") găsește un element din pagină.\n\nUn eveniment este o acțiune a utilizatorului (click, tastare). addEventListener(\"click\", funcție) rulează o funcție când elementul e apăsat.",
        example: `<button id="btn">Apasă-mă</button>

document.querySelector("#btn").addEventListener("click", function () {
  alert("Ai apăsat butonul!");
});`,
        exampleNotes: [
          "querySelector(\"#btn\") — găsește elementul cu id=\"btn\".",
          "addEventListener(\"click\", ...) — ascultă click-uri.",
          "alert() — afișează o fereastră cu mesaj.",
        ],
        exercise: {
          instructions:
            "Ai un <button id=\"salut\">Salută</button> în HTML. Scrie JS care, la click, afișează un alert cu textul \"Salut!\".",
          starter: { html: `<button id="salut">Salută</button>`, css: "", js: `\n` },
          check: (c) => /querySelector\(\s*["']#salut["']\s*\)/i.test(c.js) && /addEventListener\(\s*["']click["']/i.test(c.js) && /alert\(/i.test(c.js),
          hint: "document.querySelector(\"#salut\").addEventListener(\"click\", function() { alert(\"Salut!\"); });",
        },
      },
      {
        id: "js-7",
        title: "Formulare și funcții interactive",
        topics: ["Formulare", "Crearea funcțiilor interactive"],
        explanation:
          "Pentru a citi ce a scris utilizatorul într-un <input>, folosești .value pe elementul găsit cu querySelector. Combinând asta cu evenimente, poți crea funcții complet interactive: citești o valoare, o procesezi și afișezi rezultatul înapoi în pagină.",
        example: `<input id="numeInput" type="text">
<button id="btnSalut">Salută</button>
<p id="rezultat"></p>

document.querySelector("#btnSalut").addEventListener("click", function () {
  let nume = document.querySelector("#numeInput").value;
  document.querySelector("#rezultat").textContent = "Salut, " + nume + "!";
});`,
        exampleNotes: [
          ".value — citește textul scris într-un input.",
          ".textContent — schimbă textul afișat al unui element.",
          "Combinația querySelector + addEventListener + value e baza oricărei interacțiuni.",
        ],
        exercise: {
          instructions:
            "Ai un <input id=\"varsta\"> și un <button id=\"btnCheck\"> și un <p id=\"mesaj\">. La click, citește valoarea, transform-o în număr cu Number(...) și afișează în #mesaj \"Ești major\" sau \"Ești minor\".",
          starter: { html: `<input id="varsta" type="number">\n<button id="btnCheck">Verifică</button>\n<p id="mesaj"></p>`, css: "", js: `\n` },
          check: (c) => /Number\(/i.test(c.js) && /textContent/i.test(c.js) && /addEventListener\(\s*["']click["']/i.test(c.js),
          hint: "Citește cu Number(document.querySelector(\"#varsta\").value) și scrie rezultatul cu .textContent.",
        },
      },
    ],
  },
};

const ALL_LESSONS = [...COURSES.html.lessons, ...COURSES.css.lessons, ...COURSES.js.lessons];

const PROJECTS = [
  {
    id: "proj-pagina-personala",
    title: "Pagină personală",
    lang: "html",
    description: "O pagină simplă despre tine: nume, poză, câteva rânduri de prezentare și linkuri.",
    unlockAfter: 3,
    steps: [
      {
        title: "Structura de bază",
        instructions: "Creează scheletul HTML cu <header> conținând <h1> cu numele tău.",
        starter: { html: `<header>\n\n</header>`, css: "", js: "" },
        check: (c) => /<header>[\s\S]*<h1>[\s\S]+<\/h1>[\s\S]*<\/header>/i.test(c.html),
      },
      {
        title: "Prezentare",
        instructions: "Adaugă un <main> cu un <p> care te descrie în 1-2 propoziții.",
        starter: { html: `<header>\n  <h1>Numele tău</h1>\n</header>\n<main>\n\n</main>`, css: "", js: "" },
        check: (c) => /<main>[\s\S]*<p>[\s\S]+<\/p>[\s\S]*<\/main>/i.test(c.html),
      },
      {
        title: "Stilizare",
        instructions: "Adaugă CSS: centrează textul din <header> și dă un font-size mai mare titlului.",
        starter: { html: `<header>\n  <h1>Numele tău</h1>\n</header>\n<main>\n  <p>Despre mine...</p>\n</main>`, css: `header {\n\n}`, js: "" },
        check: (c) => /header\s*\{[^}]*text-align\s*:\s*center/i.test(c.css),
      },
      {
        title: "Link social",
        instructions: "Adaugă un link către o rețea socială la finalul paginii, cu <footer>.",
        starter: { html: `<footer>\n\n</footer>`, css: "", js: "" },
        check: (c) => /<footer>[\s\S]*<a\s+href=/i.test(c.html),
      },
    ],
  },
  { id: "proj-calculator", title: "Calculator", lang: "js", description: "Un calculator funcțional cu operațiile de bază.", unlockAfter: 8, comingSoon: true },
  { id: "proj-cronometru", title: "Cronometru", lang: "js", description: "Un cronometru pornit/oprit cu butoane.", unlockAfter: 10, comingSoon: true },
  { id: "proj-quiz", title: "Quiz", lang: "js", description: "Un quiz cu întrebări și scor final.", unlockAfter: 12, comingSoon: true },
  { id: "proj-todo", title: "Listă de activități", lang: "js", description: "Adaugă, bifează și șterge activități.", unlockAfter: 14, comingSoon: true },
  { id: "proj-galerie", title: "Galerie foto", lang: "css", description: "O galerie responsive cu CSS Grid.", unlockAfter: 9, comingSoon: true },
  { id: "proj-formular", title: "Formular interactiv", lang: "html", description: "Un formular cu validare simplă în JavaScript.", unlockAfter: 16, comingSoon: true },
  { id: "proj-notite", title: "Aplicație de notițe", lang: "js", description: "Scrie, salvează și șterge notițe.", unlockAfter: 19, comingSoon: true },
];

const TOTAL_LESSONS = ALL_LESSONS.length;
const TOTAL_ITEMS = TOTAL_LESSONS + PROJECTS.filter((p) => !p.comingSoon).length;

const BADGES = [
  { id: "prima-lectie", label: "Primul pas", desc: "Ai terminat prima lecție", check: (p) => p.completedLessons.length >= 1 },
  { id: "html-complet", label: "Stăpân HTML", desc: "Ai terminat toate lecțiile de HTML", check: (p) => COURSES.html.lessons.every((l) => p.completedLessons.includes(l.id)) },
  { id: "css-complet", label: "Stăpân CSS", desc: "Ai terminat toate lecțiile de CSS", check: (p) => COURSES.css.lessons.every((l) => p.completedLessons.includes(l.id)) },
  { id: "js-complet", label: "Stăpân JavaScript", desc: "Ai terminat toate lecțiile de JS", check: (p) => COURSES.js.lessons.every((l) => p.completedLessons.includes(l.id)) },
  { id: "primul-proiect", label: "Constructor", desc: "Ai terminat primul proiect", check: (p) => p.completedProjects.length >= 1 },
];

const DEFAULT_PROGRESS = {
  completedLessons: [],
  completedExercises: [],
  completedProjects: [],
  projectStepIndex: {},
  xp: 0,
};

function levelFromXp(xp) {
  return Math.floor(xp / 50) + 1;
}

/* ============================================================
   TEME
   ============================================================ */

function useTheme() {
  const [dark, setDark] = useState(false);
  const t = dark
    ? {
        bg: "#12141C", bgAlt: "#1A1D28", card: "#1E212D", cardBorder: "#2B2F3D",
        text: "#EDEFF3", textDim: "#9AA0B4", accent: "#5B7CFA", accentText: "#0E1220",
        navBg: "#181B26", inputBg: "#0F111A",
      }
    : {
        bg: "#F5F6F9", bgAlt: "#FFFFFF", card: "#FFFFFF", cardBorder: "#E4E7EF",
        text: "#1B1F2A", textDim: "#666C80", accent: "#3452E0", accentText: "#FFFFFF",
        navBg: "#FFFFFF", inputBg: "#F5F6F9",
      };
  return { dark, setDark, t };
}

/* ============================================================
   COMPONENTE MICI
   ============================================================ */

function ProgressRing({ percent, size = 56, stroke = 6, color = "#3452E0", track = "#E4E7EF" }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (percent / 100) * c;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
      <circle
        cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none"
        strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 0.6s ease" }}
      />
    </svg>
  );
}

function Badge({ children, color, colorSoft }) {
  return (
    <span style={{
      fontSize: 12, fontWeight: 600, color, background: colorSoft,
      padding: "3px 9px", borderRadius: 20, display: "inline-block",
    }}>{children}</span>
  );
}

/* ============================================================
   EDITOR DE COD
   ============================================================ */

function CodeEditor({ t, initial, onRunOutput, showTabs = { html: true, css: true, js: true } }) {
  const [tab, setTab] = useState(showTabs.html ? "html" : showTabs.css ? "css" : "js");
  const [view, setView] = useState("cod");
  const [code, setCode] = useState(initial);
  const [runCount, setRunCount] = useState(0);
  const iframeRef = useRef(null);

  useEffect(() => setCode(initial), [initial]);

  const tabs = Object.keys(showTabs).filter((k) => showTabs[k]);

  const buildDoc = useCallback(() => {
    return `<!DOCTYPE html><html><head><style>
      body{font-family:-apple-system,Manrope,sans-serif;padding:12px;color:#1B1F2A;}
      ${code.css || ""}
    </style></head><body>${code.html || ""}
    <script>
      window.onerror = function(msg){ document.body.innerHTML += '<pre style="color:#c0392b;white-space:pre-wrap;font-size:12px;margin-top:8px;">Eroare: '+msg+'</pre>'; };
      try { ${code.js || ""} } catch(e) { document.body.innerHTML += '<pre style="color:#c0392b;white-space:pre-wrap;font-size:12px;margin-top:8px;">Eroare: '+e.message+'</pre>'; }
    <\/script>
    </body></html>`;
  }, [code]);

  const run = () => {
    setRunCount((n) => n + 1);
    setView("rezultat");
    if (onRunOutput) onRunOutput(code);
  };

  const reset = () => setCode(initial);

  return (
    <div style={{ border: `1px solid ${t.cardBorder}`, borderRadius: 16, overflow: "hidden", background: t.card }}>
      <div style={{ display: "flex", borderBottom: `1px solid ${t.cardBorder}` }}>
        <button onClick={() => setView("cod")} style={{
          flex: 1, padding: "10px 0", fontWeight: 600, fontSize: 14, border: "none", cursor: "pointer",
          background: view === "cod" ? t.bgAlt : "transparent", color: view === "cod" ? t.text : t.textDim,
        }}>Cod</button>
        <button onClick={() => setView("rezultat")} style={{
          flex: 1, padding: "10px 0", fontWeight: 600, fontSize: 14, border: "none", cursor: "pointer",
          background: view === "rezultat" ? t.bgAlt : "transparent", color: view === "rezultat" ? t.text : t.textDim,
        }}>Rezultat</button>
      </div>

      {view === "cod" ? (
        <div>
          {tabs.length > 1 && (
            <div style={{ display: "flex", gap: 6, padding: "8px 10px", background: t.bgAlt }}>
              {tabs.map((k) => (
                <button key={k} onClick={() => setTab(k)} style={{
                  padding: "5px 12px", borderRadius: 8, fontSize: 12.5, fontWeight: 700, border: "none",
                  cursor: "pointer", color: tab === k ? LANG[k].color : t.textDim,
                  background: tab === k ? LANG[k].colorSoft : "transparent",
                }}>{LANG[k].name}</button>
              ))}
            </div>
          )}
          <textarea
            value={code[tab] || ""}
            onChange={(e) => setCode((c) => ({ ...c, [tab]: e.target.value }))}
            spellCheck={false}
            style={{
              width: "100%", minHeight: 200, resize: "vertical", border: "none", outline: "none",
              padding: 14, fontFamily: "'JetBrains Mono', monospace", fontSize: 13.5, lineHeight: 1.6,
              background: t.inputBg, color: t.text, boxSizing: "border-box",
            }}
          />
        </div>
      ) : (
        <iframe
          ref={iframeRef}
          key={runCount}
          title="rezultat"
          srcDoc={buildDoc()}
          sandbox="allow-scripts"
          style={{ width: "100%", height: 220, border: "none", background: "#fff" }}
        />
      )}

      <div style={{ display: "flex", gap: 8, padding: 10, borderTop: `1px solid ${t.cardBorder}` }}>
        <button onClick={run} style={{
          flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
          padding: "10px 0", borderRadius: 10, border: "none", background: t.accent, color: t.accentText,
          fontWeight: 700, fontSize: 14, cursor: "pointer",
        }}><Icon n="play" size={15} /> Rulează</button>
        <button onClick={reset} style={{
          padding: "10px 14px", borderRadius: 10, border: `1px solid ${t.cardBorder}`, background: "transparent",
          color: t.textDim, cursor: "pointer", display: "flex", alignItems: "center",
        }}><Icon n="reset" size={15} /></button>
      </div>
    </div>
  );
}

/* ============================================================
   ECRANE
   ============================================================ */

function TopBar({ t, title, onBack }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 8, padding: "16px 18px 8px",
      position: "sticky", top: 0, background: t.bg, zIndex: 5,
    }}>
      {onBack && (
        <button onClick={onBack} style={{ border: "none", background: "transparent", cursor: "pointer", color: t.text, padding: 4 }}>
          <Icon n="chevronLeft" size={22} />
        </button>
      )}
      <h1 style={{ fontSize: 19, fontWeight: 800, color: t.text, margin: 0 }}>{title}</h1>
    </div>
  );
}

function HomeScreen({ t, progress, goToLesson, goToTab }) {
  const percent = Math.round((progress.completedLessons.length / TOTAL_ITEMS) * 100);
  const level = levelFromXp(progress.xp);
  const nextLesson = ALL_LESSONS.find((l) => !progress.completedLessons.includes(l.id));

  return (
    <div style={{ padding: "16px 18px 100px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
        <div>
          <p style={{ margin: 0, color: t.textDim, fontSize: 13.5 }}>Bine ai revenit</p>
          <h1 style={{ margin: "2px 0 0", fontSize: 23, fontWeight: 800, color: t.text }}>Hai să învățăm ⚡</h1>
        </div>
        <div style={{ position: "relative", width: 56, height: 56 }}>
          <ProgressRing percent={percent} color={t.accent} track={t.cardBorder} />
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: t.text }}>
            {percent}%
          </div>
        </div>
      </div>

      <div style={{
        display: "flex", gap: 10, marginBottom: 22,
      }}>
        <div style={{ flex: 1, background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 14, padding: "12px 14px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#E0A100" }}>
            <Icon n="flame" size={16} /><span style={{ fontWeight: 800, fontSize: 16, color: t.text }}>Nivel {level}</span>
          </div>
          <p style={{ margin: "4px 0 0", fontSize: 12, color: t.textDim }}>{progress.xp} XP acumulat</p>
        </div>
        <div style={{ flex: 1, background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 14, padding: "12px 14px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, color: t.accent }}>
            <Icon n="award" size={16} /><span style={{ fontWeight: 800, fontSize: 16, color: t.text }}>{BADGES.filter((b) => b.check(progress)).length}</span>
          </div>
          <p style={{ margin: "4px 0 0", fontSize: 12, color: t.textDim }}>ecusoane obținute</p>
        </div>
      </div>

      {nextLesson && (
        <div onClick={() => goToLesson(nextLesson)} style={{
          background: t.accent, borderRadius: 18, padding: 18, marginBottom: 24, cursor: "pointer",
          color: t.accentText,
        }}>
          <p style={{ margin: 0, fontSize: 12.5, opacity: 0.85, fontWeight: 700, letterSpacing: 0.2 }}>Următoarea lecție</p>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>{nextLesson.title}</h3>
            <Icon n="chevronRight" size={22} />
          </div>
        </div>
      )}

      <h2 style={{ fontSize: 16, fontWeight: 800, color: t.text, margin: "0 0 12px" }}>Cursuri</h2>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
        {Object.values(COURSES).map((course) => {
          const done = course.lessons.filter((l) => progress.completedLessons.includes(l.id)).length;
          const pct = Math.round((done / course.lessons.length) * 100);
          return (
            <div key={course.key} onClick={() => goToTab("courses", course.key)} style={{
              display: "flex", alignItems: "center", gap: 12, background: t.card, border: `1px solid ${t.cardBorder}`,
              borderRadius: 14, padding: 14, cursor: "pointer",
            }}>
              <div style={{
                width: 42, height: 42, borderRadius: 12, background: LANG[course.key].colorSoft,
                display: "flex", alignItems: "center", justifyContent: "center", color: LANG[course.key].color, fontWeight: 800, fontSize: 14,
              }}>{course.title.slice(0, 2)}</div>
              <div style={{ flex: 1 }}>
                <p style={{ margin: 0, fontWeight: 700, color: t.text, fontSize: 15 }}>{course.title}</p>
                <p style={{ margin: "2px 0 0", fontSize: 12.5, color: t.textDim }}>{done}/{course.lessons.length} lecții · {course.subtitle}</p>
              </div>
              <Icon n="chevronRight" size={18} color={t.textDim} />
            </div>
          );
        })}
      </div>

      <h2 style={{ fontSize: 16, fontWeight: 800, color: t.text, margin: "0 0 12px" }}>Proiecte disponibile</h2>
      <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4 }}>
        {PROJECTS.slice(0, 4).map((p) => (
          <div key={p.id} onClick={() => goToTab("projects")} style={{
            minWidth: 140, background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 14, padding: 12, cursor: "pointer",
          }}>
            <Badge color={LANG[p.lang].color} colorSoft={LANG[p.lang].colorSoft}>{LANG[p.lang].name}</Badge>
            <p style={{ margin: "8px 0 0", fontWeight: 700, fontSize: 13.5, color: t.text }}>{p.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function CoursesScreen({ t, progress, initialLang, goToLesson }) {
  const [lang, setLang] = useState(initialLang || "html");
  useEffect(() => { if (initialLang) setLang(initialLang); }, [initialLang]);
  const course = COURSES[lang];

  return (
    <div style={{ padding: "16px 18px 100px" }}>
      <h1 style={{ fontSize: 21, fontWeight: 800, color: t.text, margin: "0 0 14px" }}>Cursuri</h1>
      <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
        {Object.values(COURSES).map((c) => (
          <button key={c.key} onClick={() => setLang(c.key)} style={{
            flex: 1, padding: "9px 0", borderRadius: 10, border: "none", cursor: "pointer",
            fontWeight: 700, fontSize: 13.5,
            background: lang === c.key ? LANG[c.key].color : t.card,
            color: lang === c.key ? "#fff" : t.textDim,
            border: lang === c.key ? "none" : `1px solid ${t.cardBorder}`,
          }}>{c.title}</button>
        ))}
      </div>

      <p style={{ color: t.textDim, fontSize: 13.5, margin: "0 0 16px" }}>{course.subtitle}</p>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {course.lessons.map((lesson, i) => {
          const done = progress.completedLessons.includes(lesson.id);
          const prevDone = i === 0 || progress.completedLessons.includes(course.lessons[i - 1].id);
          const locked = !prevDone && !done;
          return (
            <div key={lesson.id} onClick={() => !locked && goToLesson(lesson)} style={{
              display: "flex", alignItems: "center", gap: 12, background: t.card,
              border: `1px solid ${t.cardBorder}`, borderRadius: 14, padding: 14,
              opacity: locked ? 0.55 : 1, cursor: locked ? "default" : "pointer",
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: "50%", flexShrink: 0,
                background: done ? "#DCF5E3" : locked ? t.bgAlt : LANG[lang].colorSoft,
                display: "flex", alignItems: "center", justifyContent: "center",
                color: done ? "#1E9E4A" : locked ? t.textDim : LANG[lang].color, fontWeight: 800, fontSize: 13,
              }}>
                {done ? <Icon n="check" size={17} /> : locked ? <Icon n="lock" size={15} /> : i + 1}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ margin: 0, fontWeight: 700, color: t.text, fontSize: 14.5 }}>{lesson.title}</p>
                <p style={{ margin: "2px 0 0", fontSize: 12, color: t.textDim }}>{lesson.topics.join(" · ")}</p>
              </div>
              {!locked && <Icon n="chevronRight" size={17} color={t.textDim} />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function LessonScreen({ t, lesson, progress, setProgress, onBack }) {
  const [step, setStep] = useState("explicatie");
  const [checkState, setCheckState] = useState(null);
  const [lastCode, setLastCode] = useState(null);
  const lang = lesson.id.split("-")[0];
  const alreadyDone = progress.completedExercises.includes(lesson.id);

  const showTabs = {
    html: lesson.exercise.starter.html !== undefined && (lesson.exercise.starter.html !== "" || lang === "html"),
    css: lesson.exercise.starter.css !== undefined && (lesson.exercise.starter.css !== "" || lang === "css"),
    js: lesson.exercise.starter.js !== undefined && (lesson.exercise.starter.js !== "" || lang === "js"),
  };
  if (!showTabs.html && !showTabs.css && !showTabs.js) showTabs[lang] = true;

  const verify = (code) => {
    setLastCode(code);
    const ok = lesson.exercise.check(code);
    setCheckState(ok ? "ok" : "gresit");
    if (ok && !alreadyDone) {
      setProgress((p) => ({
        ...p,
        completedExercises: [...p.completedExercises, lesson.id],
        completedLessons: p.completedLessons.includes(lesson.id) ? p.completedLessons : [...p.completedLessons, lesson.id],
        xp: p.xp + 20,
      }));
    }
  };

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar t={t} title={lesson.title} onBack={onBack} />
      <div style={{ padding: "0 18px" }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          {["explicatie", "exemplu", "exercitiu"].map((s) => (
            <button key={s} onClick={() => setStep(s)} style={{
              padding: "7px 14px", borderRadius: 20, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 700,
              background: step === s ? t.accent : t.card, color: step === s ? t.accentText : t.textDim,
              border: step === s ? "none" : `1px solid ${t.cardBorder}`,
            }}>{s === "explicatie" ? "Explicație" : s === "exemplu" ? "Exemplu" : "Exercițiu"}</button>
          ))}
        </div>

        {step === "explicatie" && (
          <div>
            {lesson.explanation.split("\n\n").map((para, i) => (
              <p key={i} style={{ color: t.text, fontSize: 15, lineHeight: 1.65, marginBottom: 14 }}>{para}</p>
            ))}
            <button onClick={() => setStep("exemplu")} style={{
              marginTop: 6, width: "100%", padding: "13px 0", borderRadius: 12, border: "none",
              background: t.accent, color: t.accentText, fontWeight: 700, fontSize: 14.5, cursor: "pointer",
            }}>Vezi exemplul →</button>
          </div>
        )}

        {step === "exemplu" && (
          <div>
            <pre style={{
              background: t.inputBg, color: t.text, padding: 14, borderRadius: 12, overflowX: "auto",
              fontFamily: "'JetBrains Mono', monospace", fontSize: 12.5, lineHeight: 1.6, border: `1px solid ${t.cardBorder}`,
            }}>{lesson.example}</pre>
            <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 8 }}>
              {lesson.exampleNotes.map((n, i) => (
                <div key={i} style={{ display: "flex", gap: 8, fontSize: 13.5, color: t.textDim }}>
                  <span style={{ color: t.accent }}>•</span><span>{n}</span>
                </div>
              ))}
            </div>
            <button onClick={() => setStep("exercitiu")} style={{
              marginTop: 18, width: "100%", padding: "13px 0", borderRadius: 12, border: "none",
              background: t.accent, color: t.accentText, fontWeight: 700, fontSize: 14.5, cursor: "pointer",
            }}>Încearcă exercițiul →</button>
          </div>
        )}

        {step === "exercitiu" && (
          <div>
            <p style={{ color: t.text, fontSize: 14.5, lineHeight: 1.6, marginBottom: 14 }}>{lesson.exercise.instructions}</p>
            <CodeEditor t={t} initial={lesson.exercise.starter} onRunOutput={verify} showTabs={showTabs} />
            {checkState === "ok" && (
              <div style={{ marginTop: 14, display: "flex", gap: 8, alignItems: "center", background: "#DCF5E3", color: "#1E9E4A", padding: 12, borderRadius: 12, fontWeight: 700, fontSize: 13.5 }}>
                <Icon n="circleCheck" size={18} /> Corect! Ai câștigat 20 XP.
              </div>
            )}
            {checkState === "gresit" && (
              <div style={{ marginTop: 14, background: "#FDEDEA", color: "#C0392B", padding: 12, borderRadius: 12, fontSize: 13.5 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", fontWeight: 700, marginBottom: 4 }}>
                  <Icon n="alertCircle" size={18} /> Nu e chiar corect încă
                </div>
                <p style={{ margin: 0 }}>Indiciu: {lesson.exercise.hint}</p>
              </div>
            )}
            {(checkState === "ok" || alreadyDone) && (
              <button onClick={onBack} style={{
                marginTop: 16, width: "100%", padding: "13px 0", borderRadius: 12, border: "none",
                background: t.text, color: t.bg, fontWeight: 700, fontSize: 14.5, cursor: "pointer",
              }}>Înapoi la curs</button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ProjectScreen({ t, project, progress, setProgress, onBack }) {
  const currentStepIndex = progress.projectStepIndex[project.id] || 0;
  const [checkState, setCheckState] = useState(null);
  const step = project.steps[currentStepIndex];
  const done = progress.completedProjects.includes(project.id);

  const verify = (code) => {
    const ok = step.check(code);
    setCheckState(ok ? "ok" : "gresit");
    if (ok) {
      const isLast = currentStepIndex === project.steps.length - 1;
      setProgress((p) => ({
        ...p,
        projectStepIndex: { ...p.projectStepIndex, [project.id]: isLast ? currentStepIndex : currentStepIndex + 1 },
        completedProjects: isLast && !p.completedProjects.includes(project.id) ? [...p.completedProjects, project.id] : p.completedProjects,
        xp: p.xp + (isLast ? 40 : 15),
      }));
    }
  };

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar t={t} title={project.title} onBack={onBack} />
      <div style={{ padding: "0 18px" }}>
        {done ? (
          <div style={{ textAlign: "center", padding: "40px 0" }}>
            <Icon n="award" size={40} color={t.accent} style={{ marginBottom: 10 }} />
            <h2 style={{ color: t.text, margin: "0 0 8px" }}>Proiect finalizat!</h2>
            <p style={{ color: t.textDim, fontSize: 14 }}>Ai construit "{project.title}" pas cu pas. Bravo!</p>
          </div>
        ) : (
          <>
            <p style={{ color: t.textDim, fontSize: 12.5, fontWeight: 700, margin: "0 0 4px" }}>
              PASUL {currentStepIndex + 1} DIN {project.steps.length}
            </p>
            <h2 style={{ color: t.text, fontSize: 17, margin: "0 0 10px" }}>{step.title}</h2>
            <p style={{ color: t.text, fontSize: 14.5, lineHeight: 1.6, marginBottom: 16 }}>{step.instructions}</p>
            <CodeEditor t={t} initial={step.starter} onRunOutput={verify} />
            {checkState === "ok" && (
              <div style={{ marginTop: 14, display: "flex", gap: 8, alignItems: "center", background: "#DCF5E3", color: "#1E9E4A", padding: 12, borderRadius: 12, fontWeight: 700, fontSize: 13.5 }}>
                <Icon n="circleCheck" size={18} /> Pas finalizat!
              </div>
            )}
            {checkState === "gresit" && (
              <div style={{ marginTop: 14, background: "#FDEDEA", color: "#C0392B", padding: 12, borderRadius: 12, fontSize: 13.5, fontWeight: 600 }}>
                Mai încearcă — verifică cerința pasului cu atenție.
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function ProjectsScreen({ t, progress, goToProject }) {
  return (
    <div style={{ padding: "16px 18px 100px" }}>
      <h1 style={{ fontSize: 21, fontWeight: 800, color: t.text, margin: "0 0 6px" }}>Proiecte</h1>
      <p style={{ color: t.textDim, fontSize: 13.5, margin: "0 0 18px" }}>Construiește aplicații reale, pas cu pas.</p>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {PROJECTS.map((p) => {
          const done = progress.completedProjects.includes(p.id);
          const unlocked = progress.completedLessons.length >= p.unlockAfter && !p.comingSoon;
          return (
            <div key={p.id} onClick={() => unlocked && goToProject(p)} style={{
              background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 14, padding: 14,
              opacity: unlocked ? 1 : 0.55, cursor: unlocked ? "pointer" : "default",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <Badge color={LANG[p.lang].color} colorSoft={LANG[p.lang].colorSoft}>{LANG[p.lang].name}</Badge>
                {done ? <Icon n="check" size={18} color="#1E9E4A" /> : !unlocked && <Icon n="lock" size={16} color={t.textDim} />}
              </div>
              <p style={{ margin: "10px 0 3px", fontWeight: 700, color: t.text, fontSize: 15 }}>{p.title}</p>
              <p style={{ margin: 0, fontSize: 13, color: t.textDim, lineHeight: 1.5 }}>{p.description}</p>
              {p.comingSoon && <p style={{ margin: "8px 0 0", fontSize: 11.5, color: t.textDim, fontStyle: "italic" }}>Se adaugă într-o actualizare viitoare</p>}
              {!unlocked && !p.comingSoon && <p style={{ margin: "8px 0 0", fontSize: 11.5, color: t.textDim }}>Se deblochează după {p.unlockAfter} lecții</p>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FreeEditorScreen({ t }) {
  return (
    <div style={{ padding: "16px 18px 100px" }}>
      <h1 style={{ fontSize: 21, fontWeight: 800, color: t.text, margin: "0 0 6px" }}>Editor liber</h1>
      <p style={{ color: t.textDim, fontSize: 13.5, margin: "0 0 18px" }}>Experimentează liber cu HTML, CSS și JavaScript.</p>
      <CodeEditor
        t={t}
        initial={{
          html: `<h1>Bună!</h1>\n<p>Scrie orice cod vrei aici.</p>`,
          css: `h1 { color: #3452E0; }`,
          js: `console.log("Salut din JS!");`,
        }}
      />
    </div>
  );
}

function ProfileScreen({ t, progress, dark, setDark }) {
  const level = levelFromXp(progress.xp);
  const percent = Math.round((progress.completedLessons.length / TOTAL_ITEMS) * 100);
  return (
    <div style={{ padding: "16px 18px 100px" }}>
      <h1 style={{ fontSize: 21, fontWeight: 800, color: t.text, margin: "0 0 18px" }}>Profilul tău</h1>

      <div style={{ background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 16, padding: 18, marginBottom: 18, display: "flex", alignItems: "center", gap: 16 }}>
        <ProgressRing percent={percent} size={64} color={t.accent} track={t.cardBorder} />
        <div>
          <p style={{ margin: 0, fontWeight: 800, fontSize: 17, color: t.text }}>Nivel {level}</p>
          <p style={{ margin: "3px 0 0", fontSize: 13, color: t.textDim }}>{progress.xp} XP · {percent}% din curs finalizat</p>
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 16, padding: "14px 18px", marginBottom: 18 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {dark ? <Icon n="moon" size={18} color={t.text} /> : <Icon n="sun" size={18} color={t.text} />}
          <span style={{ color: t.text, fontWeight: 600, fontSize: 14.5 }}>Temă {dark ? "întunecată" : "deschisă"}</span>
        </div>
        <button onClick={() => setDark((d) => !d)} style={{
          width: 46, height: 26, borderRadius: 20, border: "none", cursor: "pointer",
          background: dark ? t.accent : "#D8DCE6", position: "relative",
        }}>
          <span style={{
            position: "absolute", top: 3, left: dark ? 23 : 3, width: 20, height: 20, borderRadius: "50%",
            background: "#fff", transition: "left 0.2s",
          }} />
        </button>
      </div>

      <h2 style={{ fontSize: 15, fontWeight: 800, color: t.text, margin: "0 0 12px" }}>Ecusoane</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {BADGES.map((b) => {
          const earned = b.check(progress);
          return (
            <div key={b.id} style={{
              background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 14, padding: 12,
              opacity: earned ? 1 : 0.4, textAlign: "center",
            }}>
              <Icon n="award" size={22} color={earned ? "#E0A100" : t.textDim} style={{ marginBottom: 6 }} />
              <p style={{ margin: 0, fontWeight: 700, fontSize: 12.5, color: t.text }}>{b.label}</p>
              <p style={{ margin: "2px 0 0", fontSize: 10.5, color: t.textDim }}>{b.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   APP PRINCIPAL
   ============================================================ */

function App() {
  const { dark, setDark, t } = useTheme();
  const [tab, setTab] = useState("home");
  const [coursesLang, setCoursesLang] = useState("html");
  const [activeLesson, setActiveLesson] = useState(null);
  const [activeProject, setActiveProject] = useState(null);
  const [progress, setProgressState] = useState(DEFAULT_PROGRESS);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const raw = localStorage.getItem("codpascupas_progress");
        if (raw) setProgressState(JSON.parse(raw));
      } catch (e) {
        /* nicio progresie salvată încă */
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const setProgress = useCallback((updater) => {
    setProgressState((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      try { localStorage.setItem("codpascupas_progress", JSON.stringify(next)); } catch (e) {}
      return next;
    });
  }, []);

  const goToTab = (tabName, lang) => {
    setTab(tabName);
    if (lang) setCoursesLang(lang);
    setActiveLesson(null);
    setActiveProject(null);
  };

  const goToLesson = (lesson) => setActiveLesson(lesson);
  const goToProject = (project) => setActiveProject(project);

  const NAV = [
    { key: "home", label: "Acasă", icon: "home" },
    { key: "courses", label: "Cursuri", icon: "book" },
    { key: "editor", label: "Editor", icon: "code" },
    { key: "projects", label: "Proiecte", icon: "folder" },
    { key: "profile", label: "Profil", icon: "user" },
  ];

  if (!loaded) {
    return <div style={{ height: "100vh", background: t.bg }} />;
  }

  let screen;
  if (activeLesson) {
    screen = <LessonScreen t={t} lesson={activeLesson} progress={progress} setProgress={setProgress} onBack={() => setActiveLesson(null)} />;
  } else if (activeProject) {
    screen = <ProjectScreen t={t} project={activeProject} progress={progress} setProgress={setProgress} onBack={() => setActiveProject(null)} />;
  } else if (tab === "home") {
    screen = <HomeScreen t={t} progress={progress} goToLesson={goToLesson} goToTab={goToTab} />;
  } else if (tab === "courses") {
    screen = <CoursesScreen t={t} progress={progress} initialLang={coursesLang} goToLesson={goToLesson} />;
  } else if (tab === "editor") {
    screen = <FreeEditorScreen t={t} />;
  } else if (tab === "projects") {
    screen = <ProjectsScreen t={t} progress={progress} goToProject={goToProject} />;
  } else if (tab === "profile") {
    screen = <ProfileScreen t={t} progress={progress} dark={dark} setDark={setDark} />;
  }

  return (
    <div style={{
      fontFamily: "'Manrope', -apple-system, sans-serif", background: t.bg, minHeight: "100vh",
      maxWidth: 480, margin: "0 auto", position: "relative",
    }}>
      {screen}

      {!activeLesson && !activeProject && (
        <nav style={{
          position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480,
          background: t.navBg, borderTop: `1px solid ${t.cardBorder}`, display: "flex",
          padding: "8px 4px calc(8px + env(safe-area-inset-bottom))", zIndex: 10,
        }}>
          {NAV.map((n) => {
            const active = tab === n.key;
            return (
              <button key={n.key} onClick={() => goToTab(n.key)} style={{
                flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
                border: "none", background: "transparent", cursor: "pointer", padding: "4px 0",
                color: active ? t.accent : t.textDim,
              }}>
                <Icon n={n.icon} size={21} strokeWidth={active ? 2.4 : 2} />
                <span style={{ fontSize: 10.5, fontWeight: active ? 800 : 600 }}>{n.label}</span>
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);