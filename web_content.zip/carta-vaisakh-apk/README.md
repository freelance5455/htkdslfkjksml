# Carta Vaisakh (APK)

App Android hecha con Capacitor a partir de `www/index.html` (la Carta Circular de Vaisakh con exportación a Excel).

## Generar el APK sin instalar nada (GitHub)

1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta.
2. Entra en la pestaña **Actions** → **Generar APK** → **Run workflow** (también corre solo al subir cambios).
3. Cuando termine, abre la ejecución y descarga **carta-vaisakh-apk** (contiene `app-debug.apk`).
4. Pasa el archivo al teléfono e instálalo (hay que permitir "instalar apps de orígenes desconocidos").

## Generarlo en tu computador

Requisitos: Node 22 o superior, JDK 21 y Android Studio (Otter 2025.2.1 o más nuevo).

```bash
npm install
npx cap add android        # solo la primera vez
npm run iconos             # icono y pantalla de inicio
npm run sync               # copia www/ al proyecto Android
npm run abrir              # abre Android Studio → Build > Build APK(s)
```

El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Cambios en la app

Edita `www/index.html`, luego repite `npm run sync` (o vuelve a subir a GitHub).

## Notas

- Los datos se guardan en el teléfono (almacenamiento local de la app).
- El botón de Excel crea el archivo y abre el menú de compartir/guardar de Android (plugins `@capacitor/filesystem` y `@capacitor/share`).
- El APK es de depuración: sirve para instalar y usar. Para publicar en Play Store hace falta uno firmado (release).
- Icono: `assets/icon-*.png`, pantalla de inicio: `assets/splash*.png`.
