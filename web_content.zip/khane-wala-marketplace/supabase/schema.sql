-- Khane Wala multi-restaurant marketplace starter schema.
-- Apply in a fresh Supabase project's SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer','restaurant_owner','delivery_partner','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id),
  name text not null,
  description text,
  phone text,
  address text,
  city text,
  logo_url text,
  is_approved boolean not null default false,
  is_open boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.menu_categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name text not null,
  sort_order int not null default 0
);

create table if not exists public.menu_items (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id uuid references public.menu_categories(id) on delete set null,
  name text not null,
  description text,
  price_paise integer not null check (price_paise >= 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.customer_addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  label text,
  address_line text not null,
  city text,
  postal_code text,
  latitude double precision,
  longitude double precision,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references auth.users(id),
  restaurant_id uuid not null references public.restaurants(id),
  order_type text not null check (order_type in ('delivery','pickup')),
  payment_method text not null check (payment_method in ('cod','online')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  order_status text not null default 'placed' check (order_status in ('placed','accepted','preparing','ready','assigned','picked_up','delivered','cancelled')),
  delivery_address jsonb,
  subtotal_paise integer not null default 0 check (subtotal_paise >= 0),
  delivery_fee_paise integer not null default 0 check (delivery_fee_paise >= 0),
  platform_fee_paise integer not null default 0 check (platform_fee_paise >= 0),
  total_paise integer not null default 0 check (total_paise >= 0),
  customer_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  menu_item_id uuid references public.menu_items(id),
  item_name_snapshot text not null,
  unit_price_paise integer not null check (unit_price_paise >= 0),
  quantity integer not null check (quantity > 0)
);

create table if not exists public.delivery_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  vehicle_type text,
  is_available boolean not null default false
);

create table if not exists public.delivery_assignments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  delivery_person_id uuid references auth.users(id),
  assigned_at timestamptz not null default now(),
  picked_up_at timestamptz,
  completed_at timestamptz
);

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  provider text not null,
  provider_payment_id text,
  event_type text not null,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_menu_items_restaurant on public.menu_items(restaurant_id);
create index if not exists idx_orders_customer_created on public.orders(customer_id, created_at desc);
create index if not exists idx_orders_restaurant_status on public.orders(restaurant_id, order_status);

-- Security policies are intentionally not opened to the public.
-- Configure Supabase Auth + tested RLS policies and secure server-side order/payment functions before use.
-- Never expose a service_role key in Flutter or browser code.
