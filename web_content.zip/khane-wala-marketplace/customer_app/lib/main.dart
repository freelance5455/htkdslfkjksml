import 'package:flutter/material.dart';
void main() => runApp(const KhaneWala());

class KhaneWala extends StatelessWidget {
  const KhaneWala({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Khane Wala', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.deepOrange, useMaterial3: true),
    home: const MarketplacePage(),
  );
}

class Food { final String name, restaurant, category; final int price; const Food(this.name,this.restaurant,this.category,this.price); }
const foods = [
  Food('Kanjak Thali (4 Puri)','Ghar Ka Khana','Thali',249),
  Food('Kanjak Thali (8 Puri)','Ghar Ka Khana','Thali',299),
  Food('Sama Ke Chawal Ki Khichdi','Ghar Ka Khana','Vrat Special',99),
  Food('Sama Ke Chawal Ki Kheer','Ghar Ka Khana','Vrat Special',180),
  Food('Paneer Butter Masala','Punjabi Zaika','North Indian',220),
  Food('Chole Bhature','Delhi Tadka','Popular',160),
  Food('Veg Hakka Noodles','Wok Express','Chinese',150),
];

class MarketplacePage extends StatefulWidget { const MarketplacePage({super.key}); @override State<MarketplacePage> createState()=>_MarketplacePageState(); }
class _MarketplacePageState extends State<MarketplacePage> {
  final Map<String,int> cart = {};
  String query = '';
  String orderType = 'Delivery';
  String payment = 'Cash on Delivery';
  int get total => foods.fold(0,(sum,f)=>sum+f.price*(cart[f.name]??0));
  @override Widget build(BuildContext context) {
    final shown=foods.where((f)=>('${f.name} ${f.restaurant} ${f.category}').toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('खाने वाला'), actions:[IconButton(onPressed:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('आपका कार्ट'),content:Text('कुल आइटम: ${cart.values.fold(0,(a,b)=>a+b)}\\nकुल: ₹$total'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('बंद करें'))])),icon:const Icon(Icons.shopping_bag_outlined))]),
      body: ListView(padding:const EdgeInsets.all(14),children:[
        const Text('आपका खाना, आपके पसंदीदा रेस्टोरेंट से',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'खाना या रेस्टोरेंट खोजें',border:OutlineInputBorder()),onChanged:(v)=>setState(()=>query=v)),
        const SizedBox(height:12),
        Wrap(spacing:8,children:['Delivery','Pickup'].map((v)=>ChoiceChip(label:Text(v=='Delivery'?'डिलीवरी':'खुद लेकर जाएँ'),selected:orderType==v,onSelected:(_)=>setState(()=>orderType=v)).toList()),
        const SizedBox(height:12),
        ...shown.map((f)=>Card(child:ListTile(
          leading:CircleAvatar(backgroundColor:Colors.orange.shade100,child:const Icon(Icons.restaurant,color:Colors.deepOrange)),
          title:Text(f.name),subtitle:Text('${f.restaurant} • ${f.category}\\n₹${f.price}'),
          isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.add_circle,color:Colors.deepOrange),onPressed:()=>setState(()=>cart[f.name]=(cart[f.name]??0)+1)),
        ))),
        Card(color:Colors.orange.shade50,child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('कुल: ₹$total',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
          const Text('पेमेंट विकल्प'),
          DropdownButton<String>(value:payment,isExpanded:true,items:const [DropdownMenuItem(value:'Cash on Delivery',child:Text('कैश ऑन डिलीवरी')),DropdownMenuItem(value:'Online Payment',child:Text('ऑनलाइन पेमेंट (इंटीग्रेशन बाकी)'))],onChanged:(v)=>setState(()=>payment=v!)),
          FilledButton(onPressed:cart.isEmpty?null:()=>showDialog<void>(context:context,builder:(_)=>AlertDialog(title:const Text('डेमो ऑर्डर'),content:Text('टाइप: $orderType\\nपेमेंट: $payment\\nकुल: ₹$total\\nयह केवल डेमो है; ऑर्डर सर्वर पर नहीं भेजा गया।'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('ठीक है'))])),child:const Text('ऑर्डर जारी रखें')),
        ])))
      ]),
    );
  }
}
