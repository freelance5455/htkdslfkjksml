# Khane Wala Marketplace — runnable starter

This is an original multi-restaurant food marketplace starter, not Swiggy's proprietary code. It contains a Flutter customer app prototype, a Flutter delivery app prototype, an admin/restaurant web demo, and Supabase SQL schema.

## Customer and delivery apps
Install Flutter + Android Studio. In each app folder:
```bash
flutter create .
flutter pub get
flutter run
```

## Web admin / restaurant demo
Open `admin_web/index.html` in a browser. This is a UI demo only; connect it to an authenticated backend before production.

## Database
Create a Supabase project, open SQL Editor, paste `supabase/schema.sql`, and run it. The SQL creates tables for restaurants, menu items, profiles, orders, order items, delivery partners and assignments. It deliberately does not enable public access or provide production RLS policies.

## Before real launch
Implement Supabase Auth, role-based RLS, server-side price calculation and order creation, real-time order updates, restaurant onboarding/approval, delivery assignment, address/maps, push notifications, Razorpay backend payment creation/signature/webhook verification, cancellations/refunds, audit logs, privacy/terms, and end-to-end tests. Never put service-role or payment secret keys in mobile/web client code.
