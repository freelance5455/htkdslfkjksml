import 'package:flutter/material.dart';
void main()=>runApp(const DeliveryApp());
class DeliveryApp extends StatelessWidget { const DeliveryApp({super.key}); @override Widget build(BuildContext context)=>MaterialApp(title:'Khane Wala Delivery',theme:ThemeData(colorSchemeSeed:Colors.teal,useMaterial3:true),home:const DeliveryHome()); }
class DeliveryHome extends StatefulWidget { const DeliveryHome({super.key}); @override State<DeliveryHome> createState()=>_DeliveryHomeState(); }
class _DeliveryHomeState extends State<DeliveryHome>{
 String status='कोई लाइव ऑर्डर नहीं — डेमो मोड';
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Khane Wala • Delivery')),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
 const Icon(Icons.delivery_dining,size:72),const Text('डिलीवरी पार्टनर',textAlign:TextAlign.center,style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:16),
 Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(status))),
 FilledButton(onPressed:()=>setState(()=>status='डेमो: डिलीवरी असाइन हुई'),child:const Text('डेमो: ऑर्डर स्वीकार करें')),
 OutlinedButton(onPressed:()=>setState(()=>status='डेमो: ऑर्डर पिकअप हुआ'),child:const Text('डेमो: खाना पिकअप करें')),
 OutlinedButton(onPressed:()=>setState(()=>status='डेमो: डिलीवरी पूरी हुई'),child:const Text('डेमो: डिलीवरी पूरी करें')),
 const SizedBox(height:12),const Text('लाइव ऑर्डर के लिए सुरक्षित लॉगिन और backend integration जरूरी है.')
 ])));
}
