CALCY — Fixed smiley layout

Smiley crop kengaytirildi: ikkala yonoq ham to'liq ko'rinadi, chetga kesilmaydi. Yuzcha sarlavha ichida kattaroq va markazlangan.
index.html va smiley.png bir papkada saqlansin. HTML to APK builderga shu papkani import qiling.
Rasmdagi qora X belgisi builderning ustki boshqaruv tugmasiga o'xshaydi; u HTML kalkulyator dizaynining qismi emas. Agar APK ichida ham ko'rinsa, builderdagi floating button/overlay sozlamasini o'chiring.
