Subway Craft 2.0 — Pixel Menu & Inventory Update

Extract this folder and open index.html in a modern browser with internet access. Three.js is loaded from a CDN. This update restyles the loading screen and inventory UI inspired by the screenshots, with Subway Craft branding.
