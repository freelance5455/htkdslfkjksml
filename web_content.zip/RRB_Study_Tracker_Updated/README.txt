RRB STUDY TRACKER - UPDATED WEB APP

Included updates:
- Home heading says "Welcome Dhruv".
- Removed the Focus tab and focus timer. Use Home > Log study time to record study minutes manually.
- Revision has only two views: Today's Revision and Revised Topics.
- Completed topics have a custom review-date field in Syllabus.
- Each revised topic has "100% Understand" and "Again Revision" actions with a selectable next revision date.
- Syllabus has an Add syllabus button in the top corner and clickable circular progress charts for each subject.
- Subject details show completed, in-progress, and not-started topics.
- Black background, white text, green highlights, and light-red status accents.

USAGE ON ANDROID:
1. Open index.html in Chrome to try the standalone web version.
2. For a home-screen installable/offline PWA, upload the contents of this folder to an HTTPS static host, then open that HTTPS URL in Chrome and choose Install app or Add to Home screen.
3. Data is saved in browser localStorage on this device. Export a backup from Reports before clearing Chrome site data.

This is a web app prototype, not an Android APK. Browser file mode may not support service workers/PWA installation; HTTPS hosting is needed for the full PWA offline cache.
