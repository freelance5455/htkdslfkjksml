# CPLS V2 — Stage 1150
## Real Candle Architecture
- Adds explicit candle-source metadata to the Futures feed.
- The current LBank Contract feed is truthfully marked as `sampled` because the public Contract API path in this build supplies last-price market data rather than a documented public Futures K-line stream.
- Prevents UI ambiguity between a real exchange candle and a candle aggregated from sampled prices.
