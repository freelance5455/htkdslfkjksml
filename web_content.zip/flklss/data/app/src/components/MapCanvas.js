limport React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { isInCanvas, normalizePoint, pointFromCanvas, pointToCanvas } from '../utils/geo';

function RouteLine({ points, color, canvasSize, region, dashed }) {
  const segments = useMemo(() => {
    if (!Array.isArray(points) || points.length < 2 || !canvasSize.width || !canvasSize.height) return [];
    return points.slice(1).map((point, index) => {
      const start = pointToCanvas(normalizePoint(points[index]), canvasSize, region);
      const end = pointToCanvas(normalizePoint(point), canvasSize, region);
      const deltaX = end.x - start.x;
      const deltaY = end.y - start.y;
      const length = Math.sqrt(deltaX ** 2 + deltaY ** 2);
      return { id: `${index}-${length}`, left: start.x, top: start.y, length, angle: `${Math.atan2(deltaY, deltaX)}rad` };
    }).filter((segment) => segment.length > 0);
  }, [canvasSize, points, region]);

  return (
    <>
      {segments.map((segment) => {
        const routeStyle = {
          backgroundColor: color,
          borderStyle: dashed ? 'dashed' : 'solid',
          left: segment.left,
          top: segment.top,
          width: segment.length,
          transform: [{ rotate: segment.angle }],
        };

        return <View key={segment.id} pointerEvents="none" style={[styles.routeLine, routeStyle]} />;
      })}
    </>
  );
}

function Pin({ point, label, type, canvasSize, region }) {
  if (!point) return null;
  const position = pointToCanvas(point, canvasSize, region);
  if (!isInCanvas(position, canvasSize)) return null;
  return (
    <View pointerEvents="none" style={[styles.pin, styles[`pin${type}`], { left: position.x - 11, top: position.y - 11 }]}>
      <Text style={styles.pinText}>{label}</Text>
    </View>
  );
}

export default function MapCanvas({ region, cameras, showCameras, start, destination, normalRoute, privacyRoute, onLongPress }) {
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const visibleCameras = useMemo(() => {
    if (!Array.isArray(cameras)) return [];
    return cameras
      .slice(0, 90)
      .map((camera) => ({ ...camera, position: pointToCanvas(camera, canvasSize, region) }))
      .filter((camera) => isInCanvas(camera.position, canvasSize));
  }, [cameras, canvasSize, region]);

  return (
    <Pressable
      accessibilityLabel="Route planning map"
      accessibilityHint="Long press once to select a starting point and again to select a destination"
      delayLongPress={450}
      onLayout={(event) => setCanvasSize(event.nativeEvent.layout)}
      onLongPress={(event) => {
        const { locationX: x, locationY: y } = event.nativeEvent;
        onLongPress?.(pointFromCanvas({ x, y }, canvasSize, region));
      }}
      style={styles.canvas}
    >
      <View pointerEvents="none" style={styles.grid}>
        {Array.from({ length: 9 }).map((_, index) => <View key={`vertical-${index}`} style={[styles.verticalLine, { left: `${index * 12.5}%` }]} />)}
        {Array.from({ length: 13 }).map((_, index) => <View key={`horizontal-${index}`} style={[styles.horizontalLine, { top: `${index * 8.33}%` }]} />)}
      </View>
      <View pointerEvents="none" style={styles.mapHeader}>
        <Text style={styles.mapHeaderText}>COMMUNITY MAP LAYER</Text>
        <View style={styles.liveDot} />
      </View>

      <RouteLine points={normalRoute?.geometry} color={colors.route} canvasSize={canvasSize} region={region} />
      <RouteLine points={privacyRoute?.geometry} color={colors.privacy} canvasSize={canvasSize} region={region} dashed />

      {showCameras && visibleCameras.map((camera) => (
        <View key={camera.id} pointerEvents="none" style={[styles.camera, { left: camera.position.x - 5, top: camera.position.y - 5 }]} />
      ))}
      <Pin point={start} label="S" type="Start" canvasSize={canvasSize} region={region} />
      <Pin point={destination} label="E" type="End" canvasSize={canvasSize} region={region} />
      {!start && (
        <View pointerEvents="none" style={styles.mapPrompt}>
          <Text style={styles.mapPromptTitle}>Hold anywhere to set a start</Text>
          <Text style={styles.mapPromptText}>Then hold again to compare routes.</Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  canvas: { flex: 1, backgroundColor: colors.map, overflow: 'hidden' },
  grid: { ...StyleSheet.absoluteFillObject, opacity: 0.75 },
  verticalLine: { position: 'absolute', width: 1, height: '100%', backgroundColor: colors.mapGrid },
  horizontalLine: { position: 'absolute', height: 1, width: '100%', backgroundColor: colors.mapGrid },
  mapHeader: { position: 'absolute', top: 56, left: 20, flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 999, backgroundColor: '#08111DDD', borderWidth: 1, borderColor: colors.border },
  mapHeaderText: { color: colors.textMuted, fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.privacy },
  routeLine: { position: 'absolute', height: 4, marginTop: -2, borderRadius: 3, opacity: 0.95 },
  camera: { position: 'absolute', width: 10, height: 10, borderRadius: 5, borderWidth: 2, borderColor: '#FFD7D7', backgroundColor: colors.danger, shadowColor: colors.danger, shadowOpacity: 0.8, shadowRadius: 7, elevation: 4 },
  pin: { position: 'absolute', width: 22, height: 22, alignItems: 'center', justifyContent: 'center', borderRadius: 11, borderWidth: 2 },
  pinStart: { backgroundColor: colors.accent, borderColor: '#D7FFF9' },
  pinEnd: { backgroundColor: colors.primary, borderColor: '#F0E8FF' },
  pinText: { color: colors.background, fontSize: 11, fontWeight: '900' },
  mapPrompt: { position: 'absolute', alignSelf: 'center', top: '42%', alignItems: 'center', padding: 18, borderRadius: 16, backgroundColor: '#0A1420E6', borderWidth: 1, borderColor: colors.border },
  mapPromptTitle: { color: colors.text, fontSize: 16, fontWeight: '800' },
  mapPromptText: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
});
