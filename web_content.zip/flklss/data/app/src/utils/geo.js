const EARTH_RADIUS_METERS = 6371008.8;

const radians = (value) => (value * Math.PI) / 180;

export function haversineMeters(first, second) {
  if (!first || !second) return 0;
  const deltaLatitude = radians(second.lat - first.lat);
  const deltaLongitude = radians(second.lng - first.lng);
  const latitudeOne = radians(first.lat);
  const latitudeTwo = radians(second.lat);
  const value =
    Math.sin(deltaLatitude / 2) ** 2 +
    Math.cos(latitudeOne) * Math.cos(latitudeTwo) * Math.sin(deltaLongitude / 2) ** 2;

  return 2 * EARTH_RADIUS_METERS * Math.asin(Math.sqrt(value));
}

export function formatDistance(meters) {
  if (!Number.isFinite(meters)) return '—';
  return meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${Math.round(meters)} m`;
}

export function formatDuration(seconds) {
  if (!Number.isFinite(seconds)) return '—';
  const minutes = Math.max(1, Math.round(seconds / 60));
  return minutes >= 60 ? `${Math.floor(minutes / 60)}h ${minutes % 60}m` : `${minutes} min`;
}

export function normalizePoint(point) {
  if (!point) return { lat: 0, lng: 0 };
  if (Array.isArray(point)) return { lng: Number(point[0]), lat: Number(point[1]) };
  return { lat: Number(point.lat ?? point.latitude), lng: Number(point.lng ?? point.lon ?? point.longitude) };
}

export function regionBounds(region) {
  if (!region) return { south: 0, west: 0, north: 0, east: 0 };
  return {
    south: region.latitude - region.latitudeDelta / 2,
    west: region.longitude - region.longitudeDelta / 2,
    north: region.latitude + region.latitudeDelta / 2,
    east: region.longitude + region.longitudeDelta / 2,
  };
}

export function pointFromCanvas(location, size, region) {
  if (!location || !size || !region || !size.width || !size.height) return { lat: 0, lng: 0 };
  const { width, height } = size;
  const longitude = region.longitude + (location.x / width - 0.5) * region.longitudeDelta;
  const latitude = region.latitude - (location.y / height - 0.5) * region.latitudeDelta;
  return { lat: Number(latitude.toFixed(6)), lng: Number(longitude.toFixed(6)) };
}

export function pointToCanvas(point, size, region) {
  if (!point || !size || !region || !region.longitudeDelta || !region.latitudeDelta) return { x: 0, y: 0 };
  const normalized = normalizePoint(point);
  return {
    x: ((normalized.lng - region.longitude) / region.longitudeDelta + 0.5) * size.width,
    y: (0.5 - (normalized.lat - region.latitude) / region.latitudeDelta) * size.height,
  };
}

export function isInCanvas(point, size) {
  if (!point || !size) return false;
  return point.x >= -16 && point.x <= size.width + 16 && point.y >= -16 && point.y <= size.height + 16;
}
