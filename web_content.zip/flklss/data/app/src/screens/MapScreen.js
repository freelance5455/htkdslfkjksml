import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { DEFAULT_BUFFER_KM, DEFAULT_REGION, MAX_BUFFER_KM, MIN_BUFFER_KM } from '../config/app';
import { getCameras, getRouteComparison } from '../services/api';
import { formatDistance, formatDuration, regionBounds } from '../utils/geo';
import MapCanvas from '../components/MapCanvas';

const BUFFER_STEPS = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5];

export default function MapScreen() {
  const [region, setRegion] = useState(DEFAULT_REGION);
  const [cameras, setCameras] = useState([]);
  const [camerasStatus, setCamerasStatus] = useState('idle');
  const [showCameras, setShowCameras] = useState(true);
  const [start, setStart] = useState(null);
  const [destination, setDestination] = useState(null);
  const [routeStatus, setRouteStatus] = useState('idle');
  const [comparison, setComparison] = useState(null);
  const [bufferKm, setBufferKm] = useState(DEFAULT_BUFFER_KM);
  const routeRequestId = useRef(0);

  useEffect(() => {
    let active = true;
    setCamerasStatus('loading');
    getCameras(regionBounds(region))
      .then((payload) => { if (active) { setCameras(payload.cameras || []); setCamerasStatus('ready'); } })
      .catch(() => { if (active) setCamerasStatus('error'); });
    return () => { active = false; };
  }, [region]);

  const planRoute = useCallback(async (origin, target, requestedBufferKm) => {
    const requestId = routeRequestId.current + 1;
    routeRequestId.current = requestId;
    setRouteStatus('loading');
    try {
      const payload = await getRouteComparison(origin, target, requestedBufferKm);
      if (routeRequestId.current !== requestId) return;
      setComparison(payload);
      setRouteStatus('ready');
    } catch (error) {
      if (routeRequestId.current !== requestId) return;
      setComparison(null);
      setRouteStatus('error');
      Alert.alert('Routing unavailable', error.message);
    }
  }, []);

  const handleMapPress = useCallback((point) => {
    if (!start || (start && destination)) {
      setStart(point);
      setDestination(null);
      setComparison(null);
      setRouteStatus('idle');
      return;
    }
    setDestination(point);
    planRoute(start, point, bufferKm);
  }, [bufferKm, planRoute, destination, start]);

  const recomputeBuffer = useCallback((nextBufferKm) => {
    setBufferKm(nextBufferKm);
    if (start && destination) planRoute(start, destination, nextBufferKm);
  }, [destination, planRoute, start]);

  const confirmWipe = useCallback(() => {
    Alert.alert('Wipe session', 'Clear the current trip, routes, and cached camera data for this session?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Wipe', style: 'destructive', onPress: () => {
        routeRequestId.current += 1;
        setStart(null); setDestination(null); setComparison(null);
        setRouteStatus('idle'); setCameras([]); setCamerasStatus('idle');
        setBufferKm(DEFAULT_BUFFER_KM); setShowCameras(true);
      } },
    ]);
  }, []);

  const summary = useMemo(() => {
    if (!comparison) return null;
    const { normalRoute, lowerExposureRoute } = comparison;
    if (!normalRoute) return null;
    const exposure = `${formatDistance(bufferKm * 1000)} buffer`;
    return {
      exposure,
      normal: `${formatDistance(normalRoute.distanceMeters)} • ${normalRoute.exposure.cameraCount} cams • ${formatDuration(normalRoute.durationSeconds)}`,
      privacy: lowerExposureRoute
        ? `${formatDistance(lowerExposureRoute.distanceMeters)} • ${lowerExposureRoute.exposure.cameraCount} cams • ${formatDuration(lowerExposureRoute.durationSeconds)}`
        : 'No lower-exposure alternative found',
    };
  }, [bufferKm, comparison]);

  return (
    <View style={styles.screen}>
      <MapCanvas
        region={region}
        cameras={cameras}
        showCameras={showCameras}
        start={start}
        destination={destination}
        normalRoute={comparison?.normalRoute}
        privacyRoute={comparison?.lowerExposureRoute}
        onLongPress={handleMapPress}
      />

      <View style={styles.panel} accessibilityLabel="Trip controls">
        <View style={styles.panelHeader}>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>Flockless Traveler</Text>
            <Text style={styles.subtitle}>Long-press map: 1st = start, 2nd = end</Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Wipe session"
            onPress={confirmWipe}
            style={({ pressed }) => [styles.wipeButton, pressed && styles.buttonPressed]}
          >
            <Text style={styles.wipeButtonText}>Wipe Session</Text>
          </Pressable>
        </View>

        {camerasStatus === 'loading' && (
          <View style={styles.statusRow}>
            <ActivityIndicator size="small" color={colors.primary} />
            <Text style={styles.statusText}>Loading community camera data…</Text>
          </View>
        )}
        {camerasStatus === 'error' && (
          <Text style={styles.errorText}>Camera data is unavailable right now. Routing still works.</Text>
        )}

        <View style={styles.bufferRow}>
          <Text style={styles.bufferLabel}>Buffer: {Math.round(bufferKm * 1000)} m</Text>
          <View style={styles.bufferSteps}>
            {BUFFER_STEPS.map((step) => (
              <Pressable
                key={step}
                accessibilityRole="button"
                accessibilityLabel={`Set buffer to ${Math.round(step * 1000)} meters`}
                accessibilityState={{ selected: step === bufferKm }}
                onPress={() => recomputeBuffer(step)}
                style={[styles.bufferStep, step === bufferKm && styles.bufferStepActive]}
              >
                <Text style={[styles.bufferStepText, step === bufferKm && styles.bufferStepTextActive]}>{Math.round(step * 100)}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        <Pressable
          accessibilityRole="switch"
          accessibilityState={{ checked: showCameras }}
          onPress={() => setShowCameras((value) => !value)}
          style={({ pressed }) => [styles.cameraToggle, pressed && styles.buttonPressed]}
        >
          <Text style={[styles.cameraToggleTrack, showCameras && styles.cameraToggleTrackOn]} />
          <Text style={styles.cameraToggleLabel}>{showCameras ? 'Cameras On' : 'Cameras Off'}</Text>
        </Pressable>

        {routeStatus === 'loading' && (
          <View style={styles.statusRow}>
            <ActivityIndicator size="small" color={colors.privacy} />
            <Text style={styles.statusText}>Comparing routes…</Text>
          </View>
        )}

        {summary && routeStatus !== 'loading' && (
          <View style={styles.results}>
            <View style={styles.resultRow}>
              <View style={[styles.resultDot, { backgroundColor: colors.route }]} />
              <Text style={styles.resultText} accessibilityLabel={`Normal route ${summary.normal} within ${summary.exposure}`}>
                Normal: {summary.normal}
              </Text>
            </View>
            <View style={styles.resultRow}>
              <View style={[styles.resultDot, { backgroundColor: colors.privacy }]} />
              <Text style={[styles.resultText, styles.privacyText]} accessibilityLabel={`Privacy route ${summary.privacy} within ${summary.exposure}`}>
                Privacy: {summary.privacy}
              </Text>
            </View>
            <Text style={styles.disclaimer}>{comparison.disclaimer}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  panel: { maxHeight: '52%', backgroundColor: colors.surface, borderTopLeftRadius: 22, borderTopRightRadius: 22, paddingHorizontal: 18, paddingTop: 16, paddingBottom: 26, borderWidth: 1, borderColor: colors.border },
  panelHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  title: { color: colors.text, fontSize: 19, fontWeight: '800', letterSpacing: 0.3 },
  subtitle: { color: colors.textMuted, fontSize: 12, marginTop: 3 },
  wipeButton: { backgroundColor: colors.surfaceMuted, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 12, borderWidth: 1, borderColor: colors.border },
  buttonPressed: { opacity: 0.7 },
  wipeButtonText: { color: colors.danger, fontSize: 12, fontWeight: '800' },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 9, marginTop: 14 },
  statusText: { color: colors.textMuted, fontSize: 12 },
  errorText: { color: colors.danger, fontSize: 12, marginTop: 12 },
  bufferRow: { marginTop: 14 },
  bufferLabel: { color: colors.text, fontSize: 13, fontWeight: '700', marginBottom: 9 },
  bufferSteps: { flexDirection: 'row', gap: 7, flexWrap: 'wrap' },
  bufferStep: { paddingHorizontal: 9, paddingVertical: 7, borderRadius: 10, backgroundColor: colors.surfaceMuted, borderWidth: 1, borderColor: colors.border },
  bufferStepActive: { backgroundColor: colors.primarySoft, borderColor: colors.primary },
  bufferStepText: { color: colors.textMuted, fontSize: 11, fontWeight: '700' },
  bufferStepTextActive: { color: colors.primary },
  cameraToggle: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14, alignSelf: 'flex-start' },
  cameraToggleTrack: { width: 38, height: 22, borderRadius: 12, backgroundColor: colors.surfaceMuted, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
  cameraToggleTrackOn: { backgroundColor: colors.privacy },
  cameraToggleLabel: { color: colors.text, fontSize: 13, fontWeight: '700' },
  results: { marginTop: 14, gap: 8 },
  resultRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  resultDot: { width: 9, height: 9, borderRadius: 5 },
  resultText: { color: colors.text, fontSize: 13, flex: 1 },
  privacyText: { color: colors.privacy, fontWeight: '700' },
  disclaimer: { color: colors.textMuted, fontSize: 10.5, lineHeight: 15 },
});
