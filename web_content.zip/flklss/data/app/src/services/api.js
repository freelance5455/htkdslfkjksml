import { API_BASE_URL } from '../config/app';

async function request(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  try {
    const response = await fetch(`${API_BASE_URL}${path}`, { ...options, signal: controller.signal });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || 'The service is unavailable. Please try again.');
    return payload;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('The request timed out. Check your connection and try again.');
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

export function getCameras(bounds) {
  const bbox = [bounds.south, bounds.west, bounds.north, bounds.east].join(',');
  return request(`/api/v1/cameras?bbox=${encodeURIComponent(bbox)}`);
}

export function getRouteComparison(origin, destination, bufferKm) {
  return request('/api/v1/routes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ origin, destination, bufferKm }),
  });
}
