export const API_BASE_URL = 'https://1984346a59b3ccdd22146b6a6633b19a455d199ed9a4604b0cafaecf3e83922.fly.dev:3000';

export const DEFAULT_REGION = {
  latitude: 37.7749,
  longitude: -122.4194,
  latitudeDelta: 0.14,
  longitudeDelta: 0.14,
};

export const DEFAULT_BUFFER_KM = 0.25;
export const MIN_BUFFER_KM = 0.05;
export const MAX_BUFFER_KM = 0.5;
