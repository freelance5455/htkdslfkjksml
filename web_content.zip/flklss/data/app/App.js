import { useEffect, useState } from 'react';
import { ActivityIndicator, PermissionsAndroid, Platform, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import MapScreen from './src/screens/MapScreen';
import { colors } from './src/theme/colors';

async function requestMapPermissions() {
  if (Platform.OS !== 'android') return true;

  const result = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
    {
      title: 'Location access',
      message: 'Flockless Traveler uses your location to open the map near you.',
      buttonPositive: 'Continue',
      buttonNegative: 'Not now',
    },
  );

  return result === PermissionsAndroid.RESULTS.GRANTED;
}

export default function App() {
  const [permissionsReady, setPermissionsReady] = useState(false);

  useEffect(() => {
    let active = true;

    requestMapPermissions()
      .catch(() => false)
      .finally(() => {
        if (active) setPermissionsReady(true);
      });

    return () => { active = false; };
  }, []);

  if (!permissionsReady) {
    return (
      <View style={styles.loading} accessibilityLabel="Preparing map">
        <StatusBar style="light" backgroundColor={colors.background} />
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <>
      <StatusBar style="light" backgroundColor={colors.background} />
      <MapScreen />
    </>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
  },
});
