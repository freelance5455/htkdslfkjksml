const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const multer = require('multer');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-this-secret';
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'k2signal.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 phone TEXT UNIQUE NOT NULL,
 email TEXT,
 password_hash TEXT NOT NULL,
 name TEXT NOT NULL,
 rank TEXT DEFAULT '',
 role TEXT DEFAULT 'soldier',
 callsign TEXT DEFAULT '',
 unit TEXT DEFAULT '',
 avatar TEXT DEFAULT '',
 twofa_enabled INTEGER DEFAULT 0,
 twofa_secret TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, token_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, contact_id INTEGER NOT NULL, UNIQUE(owner_id, contact_id));
CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, owner_id INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS group_members (group_id INTEGER NOT NULL, user_id INTEGER NOT NULL, UNIQUE(group_id,user_id));
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, receiver_id INTEGER, group_id INTEGER, body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL, body TEXT DEFAULT '', remind_at TEXT, done INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, item TEXT NOT NULL, qty INTEGER DEFAULT 0, status TEXT DEFAULT 'active', updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, category TEXT NOT NULL, title TEXT NOT NULL, description TEXT DEFAULT '', status TEXT DEFAULT 'new', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS courses (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL, lesson TEXT NOT NULL, video_url TEXT DEFAULT '', quiz_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS results (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, course_id INTEGER NOT NULL, score INTEGER NOT NULL, total INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

function seed() {
  if (db.prepare('SELECT COUNT(*) c FROM courses').get().c === 0) {
    const ins = db.prepare('INSERT INTO courses(title,description,lesson,video_url,quiz_json) VALUES(?,?,?,?,?)');
    const q = (arr) => JSON.stringify(arr);
    ins.run('Основи радіозв’язку','Базові поняття: канал, сигнал, радіомережа, дисципліна та відповідальне користування.','Радіозв’язок — це передавання інформації радіохвилями. Урок охоплює базову термінологію, ролі учасників зв’язку, загальні правила чіткого обміну повідомленнями та принцип мінімально необхідної інформації. Не використовуйте цей модуль як джерело оперативних частот, ключів або службових налаштувань.','https://www.youtube.com/results?search_query=основи+радіозв’язку',q([{q:'Що таке радіоканал?',a:['Спосіб передавання інформації через радіосередовище','Тип акумулятора','Формат документа','Роз’єм'],c:0},{q:'Що є важливою частиною радіодисципліни?',a:['Чіткість і лаконічність повідомлень','Передача паролів у відкритому вигляді','Ігнорування перевірок','Використання випадкових налаштувань'],c:0},{q:'Де зберігати службові ключі та секрети?',a:['У захищеному затвердженому контурі','У відкритому чаті','У публічному профілі','У коментарях соцмереж'],c:0}]));
    ins.run('Motorola: базова експлуатація','Загальна орієнтація у фізичних елементах і безпечній експлуатації портативної радіостанції.','Перед роботою перевіряють зовнішній стан, живлення, акумулятор, гарнітуру та справність дозволених налаштувань. Конкретні службові параметри повинні надходити лише від уповноваженого адміністратора зв’язку.','https://www.youtube.com/results?search_query=Motorola+R7+basic+operation',q([{q:'Що перевірити перед використанням?',a:['Стан пристрою та живлення','Лише колір корпусу','Тільки гучність','Нічого'],c:0},{q:'Хто має надавати службові параметри?',a:['Уповноважений адміністратор/відповідальна особа','Будь-хто з інтернету','Випадковий чат','Рекламний сайт'],c:0}]));
    ins.run('Акумулятори та живлення','Базові правила поводження з акумуляторами та заряджанням.','Оглядайте акумулятор на пошкодження, не використовуйте явно несправні елементи, застосовуйте сумісний зарядний пристрій і не залишайте пошкоджене обладнання без нагляду.','https://www.youtube.com/results?search_query=radio+battery+safety',q([{q:'Що робити з пошкодженим акумулятором?',a:['Припинити використання та передати відповідальному','Продовжувати заряджати','Розбирати самостійно','Заливати водою'],c:0},{q:'Який зарядний пристрій використовувати?',a:['Сумісний і дозволений для обладнання','Будь-який дешевий','Пошкоджений','Випадковий кабель'],c:0}]));
  }
}
seed();

function b64url(buf){ return Buffer.from(buf).toString('base64').replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_'); }
function base64urlDecode(s){ return Buffer.from(s.replace(/-/g,'+').replace(/_/g,'/'), 'base64'); }
function totp(secret, time=Date.now()) {
  const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits='';
  for(const ch of secret){ const v=chars.indexOf(ch.toUpperCase()); if(v>=0) bits+=v.toString(2).padStart(5,'0'); }
  const bytes=[]; for(let i=0;i+8<=bits.length;i+=8) bytes.push(parseInt(bits.slice(i,i+8),2));
  const counter=Math.floor(time/30000); const buf=Buffer.alloc(8); buf.writeUInt32BE(Math.floor(counter/0x100000000),0); buf.writeUInt32BE(counter>>>0,4);
  const key=Buffer.from(bytes); const h=crypto.createHmac('sha1',key).update(buf).digest(); const off=h[h.length-1]&15; const code=((h.readUInt32BE(off)&0x7fffffff)%1000000).toString().padStart(6,'0'); return code;
}
function randomSecret(){ const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let s=''; const b=crypto.randomBytes(20); for(const x of b) s+=chars[x%32]; return s; }
function auth(req,res,next){
  const h=req.headers.authorization||''; const token=h.startsWith('Bearer ')?h.slice(7):'';
  if(!token) return res.status(401).json({error:'Необхідна авторизація'});
  try { const p=jwt.verify(token,JWT_SECRET); const u=db.prepare('SELECT id,phone,email,name,rank,role,callsign,unit,avatar,twofa_enabled,created_at FROM users WHERE id=?').get(p.id); if(!u) throw new Error(); req.user=u; req.token=token; next(); } catch(e){ return res.status(401).json({error:'Сесія недійсна'}); }
}
function admin(req,res,next){ if(!['commander','admin'].includes(req.user.role)) return res.status(403).json({error:'Недостатньо прав'}); next(); }

app.use(express.json({limit:'2mb'}));
app.use(express.urlencoded({extended:true}));
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname,'public')));

const upload=multer({storage:multer.diskStorage({destination:UPLOAD_DIR,filename:(req,file,cb)=>cb(null,Date.now()+'-'+crypto.randomBytes(5).toString('hex')+path.extname(file.originalname).toLowerCase())}),limits:{fileSize:3*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(jpeg|png|webp)$/.test(file.mimetype))});

app.post('/api/register',(req,res)=>{
  const {phone,email,password,name,rank,callsign,unit}=req.body||{};
  if(!phone||!password||!name||password.length<8) return res.status(400).json({error:'Вкажіть ім’я, телефон і пароль від 8 символів'});
  try { const hash=bcrypt.hashSync(password,12); const info=db.prepare('INSERT INTO users(phone,email,password_hash,name,rank,callsign,unit) VALUES(?,?,?,?,?,?,?)').run(phone,email||'',hash,name,rank||'',callsign||'',unit||''); const token=jwt.sign({id:info.lastInsertRowid},JWT_SECRET,{expiresIn:'30d'}); res.json({token,user:db.prepare('SELECT id,phone,email,name,rank,role,callsign,unit,avatar,twofa_enabled FROM users WHERE id=?').get(info.lastInsertRowid)}); } catch(e){ res.status(400).json({error:'Такий номер уже зареєстрований'}); }
});
app.post('/api/login',(req,res)=>{
  const {phone,password,otp}=req.body||{}; const u=db.prepare('SELECT * FROM users WHERE phone=?').get(phone||'');
  if(!u||!bcrypt.compareSync(password||'',u.password_hash)) return res.status(401).json({error:'Невірний номер або пароль'});
  if(u.twofa_enabled && totp(u.twofa_secret)!==String(otp||'')) return res.status(401).json({error:'Потрібен правильний код 2FA'});
  const token=jwt.sign({id:u.id},JWT_SECRET,{expiresIn:'30d'}); res.json({token,user:{id:u.id,phone:u.phone,email:u.email,name:u.name,rank:u.rank,role:u.role,callsign:u.callsign,unit:u.unit,avatar:u.avatar,twofa_enabled:u.twofa_enabled}});
});
app.get('/api/me',auth,(req,res)=>res.json(req.user));
app.post('/api/profile',auth,(req,res)=>{const {name,email,rank,callsign,unit}=req.body; db.prepare('UPDATE users SET name=?,email=?,rank=?,callsign=?,unit=? WHERE id=?').run(name,email,rank,callsign,unit,req.user.id); res.json(db.prepare('SELECT id,phone,email,name,rank,role,callsign,unit,avatar,twofa_enabled FROM users WHERE id=?').get(req.user.id));});
app.post('/api/avatar',auth,upload.single('avatar'),(req,res)=>{ if(!req.file)return res.status(400).json({error:'Файл не отримано'}); const url='/uploads/'+req.file.filename; db.prepare('UPDATE users SET avatar=? WHERE id=?').run(url,req.user.id); res.json({avatar:url}); });
app.post('/api/change-password',auth,(req,res)=>{const {oldPassword,newPassword}=req.body; const u=db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id); if(!bcrypt.compareSync(oldPassword||'',u.password_hash)||!newPassword||newPassword.length<8)return res.status(400).json({error:'Невірний старий пароль або новий пароль надто короткий'}); db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(newPassword,12),req.user.id); res.json({ok:true});});
app.post('/api/2fa/setup',auth,(req,res)=>{const secret=randomSecret(); db.prepare('UPDATE users SET twofa_secret=? WHERE id=?').run(secret,req.user.id); const label=encodeURIComponent('K2 SIGNAL:'+req.user.phone); const issuer=encodeURIComponent('K2 SIGNAL'); const uri=`otpauth://totp/${label}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`; res.json({secret,uri});});
app.post('/api/2fa/enable',auth,(req,res)=>{const {code}=req.body; const u=db.prepare('SELECT twofa_secret FROM users WHERE id=?').get(req.user.id); if(!u.twofa_secret||totp(u.twofa_secret)!==String(code))return res.status(400).json({error:'Невірний код'}); db.prepare('UPDATE users SET twofa_enabled=1 WHERE id=?').run(req.user.id); res.json({ok:true});});
app.post('/api/2fa/disable',auth,(req,res)=>{db.prepare('UPDATE users SET twofa_enabled=0,twofa_secret="" WHERE id=?').run(req.user.id);res.json({ok:true});});

app.get('/api/users/search',auth,(req,res)=>{const q=String(req.query.q||'').trim(); if(!q)return res.json([]); const rows=db.prepare(`SELECT id,name,rank,callsign,unit,avatar,phone FROM users WHERE id!=? AND (phone LIKE ? OR name LIKE ? OR callsign LIKE ?) LIMIT 20`).all(req.user.id,`%${q}%`,`%${q}%`,`%${q}%`); res.json(rows);});
app.post('/api/contacts/:id',auth,(req,res)=>{db.prepare('INSERT OR IGNORE INTO contacts(owner_id,contact_id) VALUES(?,?)').run(req.user.id,Number(req.params.id));res.json({ok:true});});
app.get('/api/contacts',auth,(req,res)=>res.json(db.prepare(`SELECT u.id,u.name,u.rank,u.callsign,u.unit,u.avatar,u.phone FROM contacts c JOIN users u ON u.id=c.contact_id WHERE c.owner_id=? ORDER BY u.name`).all(req.user.id)));

app.get('/api/groups',auth,(req,res)=>res.json(db.prepare(`SELECT g.id,g.name,(SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id) members FROM groups g JOIN group_members gm0 ON gm0.group_id=g.id WHERE gm0.user_id=? ORDER BY g.id DESC`).all(req.user.id)));
app.post('/api/groups',auth,(req,res)=>{const {name}=req.body;if(!name)return res.status(400).json({error:'Вкажіть назву'});const tx=db.transaction(()=>{const g=db.prepare('INSERT INTO groups(name,owner_id) VALUES(?,?)').run(name,req.user.id);db.prepare('INSERT INTO group_members(group_id,user_id) VALUES(?,?)').run(g.lastInsertRowid,req.user.id);return g.lastInsertRowid;});res.json({id:tx()});});
app.post('/api/groups/:id/members',auth,(req,res)=>{const gid=Number(req.params.id),uid=Number(req.body.userId);const ok=db.prepare('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?').get(gid,req.user.id);if(!ok)return res.status(403).json({error:'Немає доступу'});db.prepare('INSERT OR IGNORE INTO group_members(group_id,user_id) VALUES(?,?)').run(gid,uid);res.json({ok:true});});
app.get('/api/messages',auth,(req,res)=>{const peer=Number(req.query.peer||0),gid=Number(req.query.group||0);let rows=[];if(peer) rows=db.prepare(`SELECT m.id,m.sender_id,m.receiver_id,m.body,m.created_at,u.name,u.avatar FROM messages m JOIN users u ON u.id=m.sender_id WHERE ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)) ORDER BY m.id DESC LIMIT 100`).all(req.user.id,peer,peer,req.user.id).reverse(); else if(gid){const member=db.prepare('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?').get(gid,req.user.id);if(!member)return res.status(403).json({error:'Немає доступу'});rows=db.prepare(`SELECT m.id,m.sender_id,m.group_id,m.body,m.created_at,u.name,u.avatar FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.group_id=? ORDER BY m.id DESC LIMIT 100`).all(gid).reverse();} res.json(rows);});
app.post('/api/messages',auth,(req,res)=>{const {peer,group,body}=req.body;if(!body?.trim())return res.status(400).json({error:'Порожнє повідомлення'});if(group){const ok=db.prepare('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?').get(Number(group),req.user.id);if(!ok)return res.status(403).json({error:'Немає доступу'});db.prepare('INSERT INTO messages(sender_id,group_id,body) VALUES(?,?,?)').run(req.user.id,Number(group),body.trim());}else if(peer){db.prepare('INSERT INTO messages(sender_id,receiver_id,body) VALUES(?,?,?)').run(req.user.id,Number(peer),body.trim());}else return res.status(400).json({error:'Вкажіть одержувача'});res.json({ok:true});});

app.get('/api/notes',auth,(req,res)=>res.json(db.prepare('SELECT * FROM notes WHERE user_id=? ORDER BY done,COALESCE(remind_at,"9999")').all(req.user.id)));
app.post('/api/notes',auth,(req,res)=>{const {title,body,remind_at}=req.body;if(!title)return res.status(400).json({error:'Назва обов’язкова'});const r=db.prepare('INSERT INTO notes(user_id,title,body,remind_at) VALUES(?,?,?,?)').run(req.user.id,title,body||'',remind_at||null);res.json({id:r.lastInsertRowid});});
app.patch('/api/notes/:id',auth,(req,res)=>{db.prepare('UPDATE notes SET done=? WHERE id=? AND user_id=?').run(req.body.done?1:0,Number(req.params.id),req.user.id);res.json({ok:true});});
app.delete('/api/notes/:id',auth,(req,res)=>{db.prepare('DELETE FROM notes WHERE id=? AND user_id=?').run(Number(req.params.id),req.user.id);res.json({ok:true});});

app.get('/api/inventory',auth,(req,res)=>res.json(db.prepare('SELECT * FROM inventory WHERE user_id=? ORDER BY item').all(req.user.id)));
app.post('/api/inventory',auth,(req,res)=>{const {item,qty}=req.body;if(!item)return res.status(400).json({error:'Назва майна обов’язкова'});db.prepare('INSERT INTO inventory(user_id,item,qty) VALUES(?,?,?)').run(req.user.id,item,Number(qty||0));res.json({ok:true});});
app.patch('/api/inventory/:id',auth,(req,res)=>{db.prepare('UPDATE inventory SET qty=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?').run(Number(req.body.qty||0),Number(req.params.id),req.user.id);res.json({ok:true});});

app.get('/api/requests',auth,(req,res)=>{const rows=req.user.role==='commander'||req.user.role==='admin'?db.prepare(`SELECT r.*,u.name,u.callsign FROM requests r JOIN users u ON u.id=r.user_id ORDER BY r.id DESC`).all():db.prepare('SELECT * FROM requests WHERE user_id=? ORDER BY id DESC').all(req.user.id);res.json(rows);});
app.post('/api/requests',auth,(req,res)=>{const {category,title,description}=req.body;if(!category||!title)return res.status(400).json({error:'Категорія та назва обов’язкові'});db.prepare('INSERT INTO requests(user_id,category,title,description) VALUES(?,?,?,?)').run(req.user.id,category,title,description||'');res.json({ok:true});});
app.patch('/api/requests/:id',auth,admin,(req,res)=>{db.prepare('UPDATE requests SET status=? WHERE id=?').run(req.body.status,Number(req.params.id));res.json({ok:true});});

app.get('/api/courses',auth,(req,res)=>{const rows=db.prepare('SELECT id,title,description,lesson,video_url FROM courses ORDER BY id').all(); const results=db.prepare('SELECT course_id,score,total FROM results WHERE user_id=?').all(req.user.id);const map=Object.fromEntries(results.map(x=>[x.course_id,x]));res.json(rows.map(x=>({...x,result:map[x.id]||null})));});
app.get('/api/courses/:id',auth,(req,res)=>{const c=db.prepare('SELECT id,title,description,lesson,video_url,quiz_json FROM courses WHERE id=?').get(Number(req.params.id));if(!c)return res.status(404).json({error:'Курс не знайдено'});res.json({...c,quiz:JSON.parse(c.quiz_json)});});
app.post('/api/courses/:id/result',auth,(req,res)=>{const c=db.prepare('SELECT quiz_json FROM courses WHERE id=?').get(Number(req.params.id));if(!c)return res.status(404).json({error:'Курс не знайдено'});const quiz=JSON.parse(c.quiz_json),answers=req.body.answers||[];let score=0;quiz.forEach((q,i)=>{if(Number(answers[i])===q.c)score++;});db.prepare('INSERT INTO results(user_id,course_id,score,total) VALUES(?,?,?,?)').run(req.user.id,Number(req.params.id),score,quiz.length);res.json({score,total:quiz.length,percent:Math.round(score/quiz.length*100)});});

app.get('/api/radio',auth,(req,res)=>res.json({stations:[{name:'Українське радіо',url:'https://ukr.radio/'},{name:'Громадське радіо',url:'https://hromadske.radio/'},{name:'YouTube Music',url:'https://music.youtube.com/'}],note:'Посилання ведуть на зовнішні легальні сервіси. Доступність залежить від мережі.'}));
app.get('/api/announcements',auth,(req,res)=>res.json([{title:'Навчання',text:'Перевірте незавершені курси у розділі Академія зв’язку.',type:'info'},{title:'Безпека',text:'Увімкніть 2FA та біометрію на своєму пристрої.',type:'security'}]));

app.get('/api/dashboard',auth,(req,res)=>{
 const courses=db.prepare('SELECT COUNT(*) c FROM courses').get().c; const done=db.prepare('SELECT COUNT(DISTINCT course_id) c FROM results WHERE user_id=? AND score*1.0/total>=0.7').get(req.user.id).c; const notes=db.prepare('SELECT COUNT(*) c FROM notes WHERE user_id=? AND done=0').get(req.user.id).c; const inv=db.prepare('SELECT COUNT(*) c FROM inventory WHERE user_id=?').get(req.user.id).c; const reqs=db.prepare('SELECT COUNT(*) c FROM requests WHERE user_id=? AND status NOT IN ("done","closed")').get(req.user.id).c; res.json({courses,done,progress:courses?Math.round(done/courses*100):0,notes,inventory:inv,requests:reqs});
});

app.get('/api/admin/users',auth,admin,(req,res)=>res.json(db.prepare('SELECT id,name,phone,rank,callsign,unit,role,twofa_enabled,created_at FROM users ORDER BY id DESC').all()));
app.patch('/api/admin/users/:id/role',auth,admin,(req,res)=>{const role=['soldier','commander','admin'].includes(req.body.role)?req.body.role:'soldier';db.prepare('UPDATE users SET role=? WHERE id=?').run(role,Number(req.params.id));res.json({ok:true});});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`K2 SIGNAL running on http://localhost:${PORT}`));
