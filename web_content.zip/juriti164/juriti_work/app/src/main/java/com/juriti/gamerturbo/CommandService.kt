package com.juriti.gamerturbo

import android.content.Intent
import android.os.IBinder
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/** Shizuku UserService: exposes only the command interface used by the app. */
class CommandService : Shizuku.UserService() {
    private val commandBinder = object : ICommandService.Stub() {
        override fun runCommand(command: String): String {
            if (command.isBlank()) return "ERRO: comando vazio."
            return try {
                val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
                val output = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
                val error = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
                val code = process.waitFor()
                if (code == 0) output.ifBlank { "OK" } else "ERRO: ${error.ifBlank { output }}"
            } catch (e: Throwable) {
                "ERRO: ${e.message ?: "falha ao executar comando"}"
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder = commandBinder
}
