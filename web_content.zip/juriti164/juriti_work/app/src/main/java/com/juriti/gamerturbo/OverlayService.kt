package com.juriti.gamerturbo

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.app.ActivityManager
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import rikka.shizuku.Shizuku

/** Small native overlay. It is independent from the WebView and can float over other apps. */
class OverlayService : Service() {
    companion object { @Volatile var isRunning: Boolean = false; private set }
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var metrics: TextView? = null
    private var expanded = false
    private val actionExecutor = Executors.newSingleThreadExecutor()
    private var dndEnabled = false
    private val update = object : Runnable {
        override fun run() {
            metrics?.text = readMetrics()
            handler.postDelayed(this, 700)
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            createNotification()
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            createOverlay()
            isRunning = true
            handler.post(update)
        } catch (e: Throwable) {
            isRunning = false
            Toast.makeText(this, "Não foi possível exibir o painel: ${e.message ?: "permissão ou serviço indisponível"}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun createNotification() {
        val channelId = "juriti_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Painel flutuante JURITI", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        notification.setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("JURITI Gamer Turbo ativo")
            .setContentText("Painel flutuante disponível sobre outros aplicativos")
            .setOngoing(true)
        startForeground(741, notification.build())
    }

    private fun background(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.argb(245, 9, 5, 24)); setStroke(2, Color.rgb(190, 45, 255)); cornerRadius = 24f
    }

    private fun createOverlay() {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val bubbleView = TextView(this).apply {
            text = "J"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = GradientDrawable().apply {
                colors = intArrayOf(Color.rgb(160, 0, 255), Color.rgb(40, 0, 80)); gradientType = GradientDrawable.RADIAL_GRADIENT; gradientRadius = 90f; setStroke(3, Color.rgb(240, 130, 255)); shape = GradientDrawable.OVAL
            }
        }
        val bubbleParams = WindowManager.LayoutParams(dp(54), dp(54), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or (if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) Gravity.START else Gravity.END); x = dp(12); y = dp(180)
        }
        bubbleView.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var dragged = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bubbleParams.x; oy=bubbleParams.y; dragged=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>12) dragged=true; if (dragged) { bubbleParams.x=(ox-dx).coerceAtLeast(0); bubbleParams.y=(oy+dy).coerceAtLeast(0); windowManager?.updateViewLayout(bubbleView,bubbleParams) }; return true }
                    MotionEvent.ACTION_UP -> { if (!dragged) togglePanel(); return true }
                }
                return false
            }
        })
        bubble = bubbleView
        windowManager?.addView(bubbleView, bubbleParams)
    }

    private fun togglePanel() {
        if (expanded) { panel?.let { try { windowManager?.removeView(it) } catch (_: Throwable) {} }; panel=null; panelRecorderButton=null; expanded=false; return }
        val panelPhoto = try { BitmapDrawable(resources, assets.open("assets/painel_zoro.jpg").use { BitmapFactory.decodeStream(it) }).apply { gravity = Gravity.FILL } } catch (_: Throwable) { null }
        val panelShade = GradientDrawable().apply { setColor(Color.argb(202, 4, 3, 19)); setStroke(dp(2), Color.rgb(190, 45, 255)); cornerRadius = dp(24).toFloat() }
        val panelLayers = if (panelPhoto != null) LayerDrawable(arrayOf<android.graphics.drawable.Drawable>(panelPhoto, panelShade)) else LayerDrawable(arrayOf<android.graphics.drawable.Drawable>(background()))
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background=panelLayers; clipToOutline=true; outlineProvider=ViewOutlineProvider.BACKGROUND; elevation=dp(12).toFloat() }
        val header = TextView(this).apply { text="JURITI  •  TURBO     ✕"; setTextColor(Color.rgb(230,175,255)); textSize=14f; setPadding(0,0,0,dp(8)); setOnClickListener { togglePanel() } }
        metrics = TextView(this).apply { setTextColor(Color.WHITE); textSize=13f; text=readMetrics() }
        val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(8),0,dp(2)) }
        fun actionButton(label: String, action: (TextView) -> Unit): TextView = TextView(this).apply {
            text=label; gravity=Gravity.CENTER; setTextColor(Color.WHITE); textSize=11f; setPadding(dp(7),dp(10),dp(7),dp(10))
            background=GradientDrawable().apply { setColor(Color.rgb(35,12,65)); setStroke(dp(1),Color.rgb(150,55,220)); cornerRadius=dp(10).toFloat() }
            val lp=LinearLayout.LayoutParams(0,dp(48),1f); lp.setMargins(dp(2),0,dp(2),0); layoutParams=lp
            setOnClickListener { action(this) }
        }
        actions.addView(actionButton("⚡\nAcelerar") { button -> runOverlayAction(button,"⚡ Acelerar","settings put global window_animation_scale 0.5 && settings put global transition_animation_scale 0.5 && settings put global animator_duration_scale 0.5") })
        actions.addView(actionButton("🧹\nLimpar") { button -> runOverlayAction(button,"🧹 Limpar","pm trim-caches 1073741824") })
        val dndButton = actionButton("🌙\nNão Perturbe") { button -> toggleOverlayDnd(button) }
        actions.addView(dndButton)
        renderOverlayDndState(dndButton, currentDndEnabled())
        val close = TextView(this).apply { text="FECHAR PAINEL"; gravity=Gravity.CENTER; setTextColor(Color.WHITE); textSize=12f; setPadding(dp(8),dp(10),dp(8),dp(4)); setOnClickListener { togglePanel() } }
        root.addView(header); root.addView(metrics); root.addView(actions); root.addView(close)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val params=WindowManager.LayoutParams(dp(230),WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or (if (landscape) Gravity.START else Gravity.END); x=dp(12); y=dp( if (landscape) 90 else 240) }
        panel=root; expanded=true; windowManager?.addView(root,params)
    }


    private fun animateToggle(button: TextView, original: String, enabled: Boolean) {
        val originalSize = button.textSize / resources.displayMetrics.scaledDensity
        val bgColor = if (enabled) Color.argb(225, 74, 18, 112) else Color.argb(225, 45, 35, 58)
        val strokeColor = if (enabled) Color.rgb(225, 155, 255) else Color.rgb(145, 125, 160)
        val stampBg = GradientDrawable().apply { setColor(bgColor); setStroke(dp(1), strokeColor); cornerRadius=dp(10).toFloat() }
        button.animate().cancel()
        button.text = if (enabled) "✓ ATIVADO" else "DESATIVADO"
        button.textSize = 7f
        button.setTextColor(if (enabled) Color.rgb(225, 255, 245) else Color.rgb(220, 210, 230))
        button.background = stampBg
        button.scaleX=0.94f; button.scaleY=0.94f; button.alpha=0.9f
        button.animate().scaleX(1.04f).scaleY(1.04f).alpha(1f).setDuration(150).withEndAction {
            button.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            handler.postDelayed({ if (button.isAttachedToWindow) {
                button.text=original; button.textSize=originalSize; button.setTextColor(Color.WHITE)
                button.background=GradientDrawable().apply { setColor(Color.rgb(35,12,65)); setStroke(dp(1),Color.rgb(150,55,220)); cornerRadius=dp(10).toFloat() }
            } }, 720)
        }.start()
    }

    private fun runOverlayAction(button: TextView, label: String, command: String) {
        button.isEnabled=false
        actionExecutor.execute {
            val result=runShizukuCommand(command)
            handler.post {
                button.isEnabled=true
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
                if (!result.startsWith("ERRO")) animateToggle(button,label,true)
            }
        }
    }

    private fun runShizukuCommand(command: String): String {
        return try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission()!=android.content.pm.PackageManager.PERMISSION_GRANTED)
                return "ERRO: inicie o Shizuku e conceda permissão ao JURITI."
            val latch=CountDownLatch(1); var remote: ICommandService?=null
            val args=Shizuku.UserServiceArgs(ComponentName(this,CommandService::class.java)).daemon(false).tag("juriti-overlay-command").version(1)
            val connection=object: ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, binder: IBinder?) { remote=ICommandService.Stub.asInterface(binder); latch.countDown() }
                override fun onServiceDisconnected(name: ComponentName?) { remote=null; latch.countDown() }
            }
            try {
                Shizuku.bindUserService(args,connection)
                if (!latch.await(8,TimeUnit.SECONDS)) "ERRO: tempo esgotado ao conectar ao Shizuku."
                else remote?.runCommand(command) ?: "ERRO: serviço Shizuku indisponível."
            } finally { try { Shizuku.unbindUserService(args,connection,true) } catch (_:Throwable) {} }
        } catch (e:Throwable) { "ERRO: ${e.message ?: "Shizuku indisponível"}" }
    }

    private fun currentDndEnabled(): Boolean {
        return try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: Throwable) { false }
    }

    private fun renderOverlayDndState(button: TextView, enabled: Boolean) {
        dndEnabled = enabled
        button.text = if (enabled) "🌙\nATIVADO" else "🌙\nDESATIVADO"
        button.setTextColor(if (enabled) Color.rgb(240, 210, 255) else Color.rgb(220, 210, 230))
        button.background = GradientDrawable().apply {
            setColor(if (enabled) Color.rgb(72, 20, 112) else Color.rgb(35, 12, 65))
            setStroke(dp(1), if (enabled) Color.rgb(225, 155, 255) else Color.rgb(150, 55, 220))
            cornerRadius = dp(10).toFloat()
        }
    }

    private fun animateOverlayDnd(button: TextView, enabled: Boolean) {
        button.animate().cancel()
        button.scaleX = 0.94f
        button.scaleY = 0.94f
        button.alpha = 0.82f
        button.animate().scaleX(1.08f).scaleY(1.08f).alpha(1f).setDuration(170).withEndAction {
            button.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }.start()
        renderOverlayDndState(button, enabled)
        button.setBackgroundColor(Color.TRANSPARENT)
        button.background = GradientDrawable().apply {
            setColor(if (enabled) Color.rgb(92, 28, 145) else Color.rgb(35, 12, 65))
            setStroke(dp(2), if (enabled) Color.rgb(240, 180, 255) else Color.rgb(150, 55, 220))
            cornerRadius = dp(10).toFloat()
        }
    }

    private fun toggleOverlayDnd(button: TextView) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {
                Toast.makeText(this, "Conceda acesso a Não Perturbe nas configurações.", Toast.LENGTH_LONG).show()
            }
            return
        }
        try {
            val targetEnabled = !currentDndEnabled()
            val targetFilter = if (targetEnabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(targetFilter)
            val confirmedEnabled = currentDndEnabled()
            if (confirmedEnabled == targetEnabled) {
                animateOverlayDnd(button, confirmedEnabled)
                Toast.makeText(this, if (confirmedEnabled) "Não Perturbe ATIVADO." else "Não Perturbe DESATIVADO.", Toast.LENGTH_SHORT).show()
            } else {
                renderOverlayDndState(button, confirmedEnabled)
                Toast.makeText(this, "O Android não confirmou a alteração de Não Perturbe. Verifique a permissão do JURITI.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Throwable) {
            Toast.makeText(this, "Não foi possível alterar Não Perturbe: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun readMetrics(): String {
        return try {
            val am=getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val info=ActivityManager.MemoryInfo(); am.getMemoryInfo(info)
            val total=info.totalMem/1024.0/1024.0/1024.0; val free=info.availMem/1024.0/1024.0/1024.0; val used=(total-free).coerceAtLeast(0.0)
            val thermal=if (Build.VERSION.SDK_INT>=29) { val p=getSystemService(POWER_SERVICE) as android.os.PowerManager; "\nTérmico: ${p.currentThermalStatus}/6" } else ""
            "RAM usada: ${String.format("%.1f",used)} / ${String.format("%.1f",total)} GB\nRAM livre: ${String.format("%.1f",free)} GB$thermal\nCPU/FPS do jogo: não exposto pelo Android padrão"
        } catch (_: Throwable) { "Métricas indisponíveis neste aparelho." }
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int)=START_STICKY
    override fun onDestroy() { isRunning = false; handler.removeCallbacks(update); actionExecutor.shutdownNow(); panel?.let { try { windowManager?.removeView(it) } catch (_:Throwable) {} }; bubble?.let { try { windowManager?.removeView(it) } catch (_:Throwable) {} }; panelRecorderButton=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
