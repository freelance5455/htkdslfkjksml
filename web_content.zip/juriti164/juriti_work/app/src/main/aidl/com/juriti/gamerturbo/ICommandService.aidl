package com.juriti.gamerturbo;

interface ICommandService {
    String runCommand(String command);
}
