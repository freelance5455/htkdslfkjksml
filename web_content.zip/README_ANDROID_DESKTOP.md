# Masha's Happy Home — Android APK & Desktop Build Guide

Because compiling a binary `.apk` requires the Android SDK (`aapt2`, `d8`, `android.jar`, and Gradle), this package includes **everything pre-configured** so you can generate the installable `.apk` in **1 click** using any of the 3 methods below:

---

## Method 1: Android Studio (Direct Local APK Build)
1. Extract `mashas_happy_home_android_project.zip`.
2. Open **Android Studio** and select **Open** -> choose the extracted folder.
3. Wait for Gradle sync to finish, then click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your installable APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## Method 2: Free Cloud Build via GitHub Actions (No Android Studio Needed)
1. Create a new repository on GitHub and upload the extracted files (including `.github/workflows/build-apk.yml`).
2. Go to the **Actions** tab in your GitHub repository and click **Build Masha's Happy Home APK** -> **Run workflow**.
3. Once completed (~2 minutes), download `Mashas-Happy-Home-APK` containing `app-debug.apk` and `app-release.apk`.

---

## Method 3: Capacitor CLI (Alternative Hybrid Build)
If you prefer using Node.js and Capacitor:
```bash
npm install
npx cap add android
npx cap sync
npx cap open android
```

---

## Instant Mobile Installation (No Build Required)
Open `www/index.html` (or `mashas_happy_home.html`) in Chrome on Android, tap the **three-dot menu**, and select **Add to Home screen / Install app** to run it fullscreen with full offline support (`localStorage` persistence).
