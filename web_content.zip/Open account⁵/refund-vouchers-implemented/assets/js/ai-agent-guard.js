/* ================================================================
   Open Account — حارس الوكيل الذكي
   الملف: ai-agent-guard.js
   الوصف: يراقب نشاط الوكيل ويُنبّه عند أي إرسال بيانات غير متوقع
   المبدأ: لا يُعدّل الملفات الأصلية — يُغلّف الدوال من الخارج
   ================================================================ */

(function() {
    'use strict';

    var LOG_KEY = 'oa_ai_activity_log';
    var SOUND_KEY = 'oa_ai_guard_sound';
    var MAX_LOG_ENTRIES = 200;
    var BIG_PAYLOAD_THRESHOLD = 50 * 1024; // 50 KB

    // ================================================================
    // ===== 1. أدوات مساعدة =====
    // ================================================================

    function _soundEnabled() {
        try {
            var v = localStorage.getItem(SOUND_KEY);
            return v === null ? true : v === 'true';
        } catch (e) { return true; }
    }

    function _log(level, category, message, details) {
        var entry = {
            timestamp: new Date().toISOString(),
            level: level,
            category: category,
            message: message,
            details: details || {}
        };

        // Console
        var prefix = '[AI-Guard][' + level + '][' + category + ']';
        if (level === 'alert') console.warn(prefix, message, details);
        else if (level === 'warning') console.warn(prefix, message, details);
        else console.log(prefix, message, details);

        // localStorage
        try {
            var raw = localStorage.getItem(LOG_KEY);
            var log = raw ? JSON.parse(raw) : [];
            if (!Array.isArray(log)) log = [];
            log.push(entry);
            // حد أقصى 200 سجل
            if (log.length > MAX_LOG_ENTRIES) {
                log = log.slice(-MAX_LOG_ENTRIES);
            }
            localStorage.setItem(LOG_KEY, JSON.stringify(log));
        } catch (e) { /* تجاهل */ }
    }

    function _beep(times) {
        if (!_soundEnabled()) return;
        try {
            var ctx = window._aiGuardAudioCtx;
            if (!ctx) {
                ctx = new (window.AudioContext || window.webkitAudioContext)();
                window._aiGuardAudioCtx = ctx;
            }
            var n = times || 1;
            for (var i = 0; i < n; i++) {
                (function(idx) {
                    setTimeout(function() {
                        try {
                            var osc = ctx.createOscillator();
                            var gain = ctx.createGain();
                            osc.connect(gain);
                            gain.connect(ctx.destination);
                            osc.frequency.value = 800;
                            gain.gain.setValueAtTime(0.08, ctx.currentTime);
                            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
                            osc.start(ctx.currentTime);
                            osc.stop(ctx.currentTime + 0.15);
                        } catch (e) { /* تجاهل */ }
                    }, idx * 200);
                })(i);
            }
        } catch (e) { /* تجاهل */ }
    }

    function _toast(msg, type) {
        if (typeof showToast === 'function') {
            showToast(msg, type || 'info', 6000);
        }
    }

    function _alertUser(level, title, msg) {
        if (level === 'alert') {
            _beep(3);
            _toast('🚨 ' + title + ' — ' + msg, 'error');
        } else if (level === 'warning') {
            _beep(2);
            _toast('⚠️ ' + title + ' — ' + msg, 'warning');
        } else {
            _toast('ℹ️ ' + title + ' — ' + msg, 'info');
        }
    }

    function _isShareDataEnabled() {
        try {
            var s = Storage.get(STORAGE_KEYS.AI_SETTINGS, {}) || {};
            return s.shareData === true;
        } catch (e) { return false; }
    }

    function _isLocalUrl(url) {
        if (!url) return true;
        var s = String(url).toLowerCase();
        return s.indexOf('localhost') !== -1 ||
               s.indexOf('127.0.0.1') !== -1 ||
               s.indexOf('file://') === 0 ||
               s.indexOf('data:') === 0 ||
               s.indexOf('blob:') === 0;
    }

    // ================================================================
    // ===== 2. اعتراض fetch =====
    // ================================================================

    var _originalFetch = window.fetch;

    window.fetch = function(input, init) {
        var url = (typeof input === 'string') ? input : (input && input.url);
        var method = (init && init.method) || 'GET';
        var body = (init && init.body) || '';
        var bodySize = (typeof body === 'string') ? body.length : 0;

        var isExternal = !_isLocalUrl(url);
        var shareData = _isShareDataEnabled();

        // فقط نراقب POST/PUT — لأنها التي تُرسل بيانات
       // نراقب POST/PUT فقط — لأنها التي تُرسل بيانات
if (isExternal && (method === 'POST' || method === 'PUT')) {
    var details = {
        url: url.substring(0, 150),
        method: method,
        bodySize: bodySize,
        bodySizeKB: (bodySize / 1024).toFixed(1),
        shareData: shareData
    };

    // القرار الذكي:
    // 1) حجم كبير جداً → تنبيه
    if (bodySize > BIG_PAYLOAD_THRESHOLD) {
        _log('alert', 'big-payload', 'إرسال بيانات كبيرة الحجم (' + details.bodySizeKB + ' KB)', details);
        _alertUser('alert', 'حجم كبير', 'يُرسَل ' + details.bodySizeKB + ' KB للخارج');
        return _originalFetch.apply(this, arguments);
    }

    // 2) حجم كبير مع shareData = false → تنبيه
    if (bodySize > 10000 && !shareData) {
        _log('warning', 'medium-no-share', 'إرسال ' + details.bodySizeKB + ' KB بدون تفعيل shareData', details);
        _alertUser('warning', 'حجم كبير بدون تصريح', details.bodySizeKB + ' KB');
        return _originalFetch.apply(this, arguments);
    }

    // 3) حجم صغير مع shareData = false → تسجيل صامت
    // (سؤال المستخدم ونتائج الأدوات — طبيعي)
    _log('info', 'fetch', 'إرسال خارجي (' + details.bodySizeKB + ' KB)', details);
}
}
        return _originalFetch.apply(this, arguments);
    };

    // ================================================================
    // ===== 3. اعتراض _aiDataSnapshot =====
    // ================================================================

    // ننتظر حتى يُحمَّل ai-agent-universal.js ثم نُغلّف الدالة
    var _snapshotWrapped = false;

    function _wrapSnapshot() {
        if (_snapshotWrapped) return;
        if (typeof window._aiDataSnapshot !== 'function') return;

        var original = window._aiDataSnapshot;
        window._aiDataSnapshot = function() {
            var result = original.apply(this, arguments);
            try {
                var size = JSON.stringify(result).length;
                var shareData = _isShareDataEnabled();

                var details = {
                    size: size,
                    sizeKB: (size / 1024).toFixed(1),
                    shareData: shareData,
                    hasCounts: !!result.counts
                };

                if (!shareData) {
                    _log('warning', 'snapshot-no-share', 'تم استدعاء snapshot بدون تفعيل shareData', details);
                    _alertUser('warning', 'تحضير بيانات', 'الوكيل يُحضّر snapshot — لكن shareData معطّل');
                } else {
                    _log('info', 'snapshot', 'تم تحضير snapshot (' + details.sizeKB + ' KB)', details);
                }
            } catch (e) { /* تجاهل */ }
            return result;
        };
        _snapshotWrapped = true;
        console.log('[AI-Guard] _aiDataSnapshot محميّ');
    }

    // ================================================================
    // ===== 4. اعتراض aiExecuteTool =====
    // ================================================================

    var _executeToolWrapped = false;

    function _wrapExecuteTool() {
        if (_executeToolWrapped) return;
        if (typeof window.aiExecuteTool !== 'function') return;

        var original = window.aiExecuteTool;
        window.aiExecuteTool = function(name, args) {
            var details = {
                tool: name,
                argsKeys: args ? Object.keys(args) : []
            };

            // تسجيل كل استدعاء
            _log('info', 'tool-call', 'استدعاء الأداة: ' + name, details);

            // فحص الأدوات الحساسة (التي قد تُرسل بيانات)
            var sensitiveTools = [
                'get_dashboard_stats',
                'get_system_summary',
                'get_audit_issues',
                'get_audit_log',
                'get_company_settings',
                'get_currency_rates'
            ];

            if (sensitiveTools.indexOf(name) !== -1) {
                var shareData = _isShareDataEnabled();
                if (!shareData) {
                    _log('warning', 'sensitive-tool-no-share', 'أداة حساسة بدون shareData: ' + name, details);
                }
            }

            try {
                var result = original.apply(this, arguments);
                return result;
            } catch (e) {
                _log('alert', 'tool-error', 'خطأ في الأداة: ' + name, { error: e.message });
                throw e;
            }
        };
        _executeToolWrapped = true;
        console.log('[AI-Guard] aiExecuteTool محميّ');
    }

    // ================================================================
    // ===== 5. محاولة التغليف بعد التحميل =====
    // ================================================================

    function _tryWrap() {
        _wrapSnapshot();
        _wrapExecuteTool();
        if (_snapshotWrapped && _executeToolWrapped) {
            console.log('[AI-Guard] جاهز — كل الدوال محميّة');
            return true;
        }
        return false;
    }

    // انتظر تحميل كل السكربتات
    window.addEventListener('load', function() {
        if (!_tryWrap()) {
            // حاول ثانية بعد 500ms
            setTimeout(_tryWrap, 500);
        }
    });

    // ================================================================
    // ===== 6. واجهة عرض السجل =====
    // ================================================================

    window.showAIGuardLog = function() {
        try {
            var raw = localStorage.getItem(LOG_KEY);
            var log = raw ? JSON.parse(raw) : [];

            var r = 'سجل نشاط الوكيل الذكي\n';
            r += 'عدد السجلات: ' + log.length + '\n';
            r += '═══════════════════════════════════════\n\n';

            if (!log.length) {
                r += 'لا توجد سجلات.';
            } else {
                log.slice(-50).forEach(function(entry, i) {
                    r += (i + 1) + ') [' + entry.level.toUpperCase() + '] ';
                    r += entry.timestamp.substring(0, 19) + '\n';
                    r += '   ' + entry.message + '\n';
                    if (entry.details && Object.keys(entry.details).length) {
                        r += '   ' + JSON.stringify(entry.details).substring(0, 100) + '\n';
                    }
                    r += '\n';
                });
            }

            var modal = document.createElement('div');
            modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.9);z-index:999999;display:flex;align-items:center;justify-content:center;padding:10px;';
            var box = document.createElement('div');
            box.style.cssText = 'background:white;padding:16px;border-radius:10px;max-width:600px;width:100%;max-height:90vh;display:flex;flex-direction:column;';
            var title = document.createElement('h3');
            title.textContent = 'سجل نشاط الوكيل';
            title.style.cssText = 'margin:0 0 10px 0;color:#000;font-size:14px;text-align:center;';
            var pre = document.createElement('pre');
            pre.textContent = r;
            pre.style.cssText = 'background:#f5f5f5;padding:12px;border-radius:6px;font-size:10px;white-space:pre-wrap;word-break:break-all;margin:0;user-select:all;direction:rtl;text-align:right;overflow:auto;flex:1;max-height:70vh;';

            var btnRow = document.createElement('div');
            btnRow.style.cssText = 'display:flex;gap:8px;margin-top:10px;';

            var clearBtn = document.createElement('button');
            clearBtn.textContent = 'حذف السجل';
            clearBtn.style.cssText = 'flex:1;padding:10px;background:#c0392b;color:white;border:none;border-radius:6px;font-size:13px;cursor:pointer;font-weight:700;';
            clearBtn.onclick = function() {
                if (confirm('حذف كل السجلات؟')) {
                    localStorage.removeItem(LOG_KEY);
                    document.body.removeChild(modal);
                    if (typeof showToast === 'function') showToast('تم حذف السجل', 'success');
                }
            };

            var copyBtn = document.createElement('button');
            copyBtn.textContent = 'نسخ';
            copyBtn.style.cssText = 'flex:1;padding:10px;background:#1a7a4a;color:white;border:none;border-radius:6px;font-size:13px;cursor:pointer;font-weight:700;';
            copyBtn.onclick = function() {
                var range = document.createRange();
                range.selectNodeContents(pre);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
                try { document.execCommand('copy'); copyBtn.textContent = '✅ تم'; }
                catch(e) { copyBtn.textContent = 'تعذّر'; }
            };

            var closeBtn = document.createElement('button');
            closeBtn.textContent = 'إغلاق';
            closeBtn.style.cssText = 'flex:1;padding:10px;background:#4a4a4a;color:white;border:none;border-radius:6px;font-size:13px;cursor:pointer;font-weight:700;';
            closeBtn.onclick = function() { document.body.removeChild(modal); };

            btnRow.appendChild(copyBtn);
            btnRow.appendChild(clearBtn);
            btnRow.appendChild(closeBtn);

            box.appendChild(title);
            box.appendChild(pre);
            box.appendChild(btnRow);
            modal.appendChild(box);
            document.body.appendChild(modal);
        } catch (e) {
            alert('خطأ: ' + e.message);
        }
    };

    window.toggleAIGuardSound = function() {
        var current = _soundEnabled();
        localStorage.setItem(SOUND_KEY, current ? 'false' : 'true');
        if (typeof showToast === 'function') {
            showToast('صوت الحارس: ' + (!current ? 'مفعّل' : 'مكتوم'), 'info');
        }
    };

    console.log('[AI-Guard] تم التحميل — انتظار جهوزية النظام');

})();