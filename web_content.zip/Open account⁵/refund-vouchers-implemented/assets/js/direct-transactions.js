// ================================================================
// Open Account — الحركات المالية المباشرة
// الملف: direct-transactions.js
// النسخة: v3 — مع الفلاتر الكاملة
// ================================================================

var directTransactions = [];


// ================================================================
// ===== 1. التحميل والحفظ =====
// ================================================================

function loadDirectTransactions() {
    directTransactions = Storage.get(STORAGE_KEYS.DIRECT_TRANSACTIONS, []);
    if (!Array.isArray(directTransactions)) directTransactions = [];

    var changed = false;
    directTransactions.forEach(function(t) {
        if (!t.direction) {
            t.direction = 'in';
            t.type = t.type || 'رأس المال';
            changed = true;
        }
    });
    if (changed) saveDirectTransactions();
}

function saveDirectTransactions() {
    Storage.set(STORAGE_KEYS.DIRECT_TRANSACTIONS, directTransactions);
}


// ================================================================
// ===== 2. الأنواع المتاحة =====
// ================================================================

var DIRECT_IN_TYPES = [
    'رأس المال',
    'رصيد أول المدة',
    'تمويل من المالك',
    'قرض مستلم',
    'بيع مستهلكات / خردة',
    'إيرادات متنوعة',
    'إيداع مباشر آخر'
];

var DIRECT_OUT_TYPES = [
    'سحب شخصي',
    'سداد قرض',
    'سحب متنوع'
];


// ================================================================
// ===== 3. نموذج الحركة =====
// ================================================================

function _directForm() {
    return '' +
        '<div class="form-field">' +
            '<label>اتجاه الحركة</label>' +
            '<select id="directDirection" onchange="_onDirectDirectionChange()">' +
                '<option value="in">↓ إيداع (داخل)</option>' +
                '<option value="out">↑ سحب (خارج)</option>' +
            '</select>' +
        '</div>' +
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="directDate">' +
            '</div>' +
            '<div class="form-field">' +
                '<label>المبلغ</label>' +
                '<input type="number" id="directAmount" min="0.01" step="0.01" placeholder="0.00">' +
            '</div>' +
        '</div>' +
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>الحساب</label>' +
                '<select id="directAccount">' +
                    '<option value="cashbox">الصندوق</option>' +
                    '<option value="bank">البنك</option>' +
                '</select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>العملة</label>' +
                '<select id="directCurrency">' +
                    '<option value="YER">ريال يمني</option>' +
                    '<option value="SAR">ريال سعودي</option>' +
                    '<option value="USD">دولار أمريكي</option>' +
                '</select>' +
            '</div>' +
        '</div>' +
        '<div class="form-field">' +
            '<label>نوع الحركة</label>' +
            '<select id="directType"></select>' +
        '</div>' +
        '<div class="form-field">' +
            '<label>البيان</label>' +
            '<input id="directNote" placeholder="وصف اختياري">' +
        '</div>';
}

function _onDirectDirectionChange() {
    var dirEl = document.getElementById('directDirection');
    var typeEl = document.getElementById('directType');
    if (!dirEl || !typeEl) return;

    var isIn = dirEl.value === 'in';
    var types = isIn ? DIRECT_IN_TYPES : DIRECT_OUT_TYPES;

    var html = '';
    types.forEach(function(t) {
        html += '<option value="' + esc(t) + '">' + esc(t) + '</option>';
    });
    typeEl.innerHTML = html;
}


// ================================================================
// ===== 4. فتح نافذة حركة جديدة =====
// ================================================================

function openDirectTransactionModal() {
    Modal.open({
        id: 'directTransactionModal',
        title: 'حركة مالية مباشرة',
        size: 'normal',
        body: _directForm(),
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'directTransactionModal\')">إلغاء</button>' +
            '<button class="btn btn-primary" onclick="saveDirectTransaction()">حفظ الحركة</button>',
        onOpen: function(modalEl) {
            var dateEl = document.getElementById('directDate');
            if (dateEl) dateEl.value = todayISO();

            _onDirectDirectionChange();

            var currEl = document.getElementById('directCurrency');
            if (currEl && typeof getBaseCurrency === 'function') {
                currEl.value = getBaseCurrency();
            }
        }
    });
}


// ================================================================
// ===== 5. حفظ الحركة =====
// ================================================================

function saveDirectTransaction() {
    var dirEl = document.getElementById('directDirection');
    var dateEl = document.getElementById('directDate');
    var amountEl = document.getElementById('directAmount');
    var accountEl = document.getElementById('directAccount');
    var currencyEl = document.getElementById('directCurrency');
    var typeEl = document.getElementById('directType');
    var noteEl = document.getElementById('directNote');

    var direction = dirEl ? dirEl.value : 'in';
    var date = dateEl ? dateEl.value : '';
    var amount = parseFloat(amountEl ? amountEl.value : 0) || 0;
    var account = accountEl ? accountEl.value : 'cashbox';
    var currency = currencyEl ? currencyEl.value : 'YER';
    var type = typeEl ? typeEl.value : '';
    var note = noteEl ? noteEl.value.trim() : '';

    if (!date) {
        return showToast('يرجى اختيار التاريخ', 'error');
    }
    if (amount <= 0) {
        return showToast('يرجى إدخال مبلغ صحيح', 'error');
    }
    if (!type) {
        return showToast('يرجى اختيار نوع الحركة', 'error');
    }

    if (direction === 'out') {
        var balance = _getDirectAccountBalance(account, currency);
        if (amount > balance + 0.0001) {
            return showToast(
                'الرصيد المتاح في ' + (account === 'bank' ? 'البنك' : 'الصندوق') +
                ' بعملة ' + currency + ' هو: ' +
                formatAmountWithCommas(balance),
                'error'
            );
        }
    }

    var newTx = {
        id: generateId(),
        date: date,
        direction: direction,
        amount: amount,
        currency: currency,
        exchangeRate: typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(currency) : 1,
        account: account,
        type: type,
        note: note,
        createdAt: new Date().toISOString()
    };

    directTransactions.push(newTx);
    saveDirectTransactions();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

    closeModal('directTransactionModal');

    if (typeof renderDirectTransactions === 'function') renderDirectTransactions();
    if (typeof renderCashbox === 'function') renderCashbox();
    if (typeof renderBank === 'function') renderBank();
    if (typeof updateDashboard === 'function') updateDashboard();

    var msg = direction === 'in'
        ? 'تم تسجيل الإيداع: ' + type
        : 'تم تسجيل السحب: ' + type;
    showToast(msg, 'success');
}


// ================================================================
// ===== 6. حساب رصيد الحساب =====
// ================================================================

function _getDirectAccountBalance(account, currency) {
    var balance = 0;

    var transactions = [];

    if (account === 'cashbox' && typeof getCashboxTransactions === 'function') {
        transactions = getCashboxTransactions();
    } else if (account === 'bank' && typeof getBankTransactions === 'function') {
        transactions = getBankTransactions();
    }

    transactions.forEach(function(t) {
        if ((t.currency || 'YER') !== currency) return;
        if (t.type === 'in') balance += t.amount;
        else if (t.type === 'out') balance -= t.amount;
    });

    return balance;
}


// ================================================================
// ===== 7. عرض جدول الحركات =====
// ================================================================

function renderDirectTransactions() {
    var tbody = document.getElementById('directTableBody');
    if (!tbody) return;

    var fromEl = document.getElementById('directFrom');
    var toEl = document.getElementById('directTo');
    var dirEl = document.getElementById('directDirectionFilter');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';
    var dirFilter = dirEl ? dirEl.value : '';

    localStorage.setItem('oa_direct_filter_from', from);
    localStorage.setItem('oa_direct_filter_to', to);
    localStorage.setItem('oa_direct_filter_direction', dirFilter);

    var filtered = directTransactions.filter(function(t) {
        if (from && t.date < from) return false;
        if (to && t.date > to) return false;
        if (dirFilter && t.direction !== dirFilter) return false;
        return true;
    });

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">لا توجد حركات في الفترة المحددة</td></tr>';
        return;
    }

    var sorted = filtered.slice().sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });

    var html = '';
    sorted.forEach(function(t, i) {
        var isIn = t.direction === 'in';
        var dirBadge = isIn
            ? '<span class="status-badge status-paid"><span class="status-dot"></span>إيداع</span>'
            : '<span class="status-badge status-unpaid"><span class="status-dot"></span>سحب</span>';

        var amountColor = isIn ? 'var(--color-green)' : 'var(--color-red)';
        var amountSign = isIn ? '+' : '−';
        var accountLabel = t.account === 'bank' ? 'البنك' : 'الصندوق';

        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + formatDate(t.date) + '</td>' +
            '<td>' + dirBadge + '</td>' +
            '<td>' + esc(t.type || '-') + '</td>' +
            '<td>' + esc(accountLabel) + '</td>' +
            '<td style="color:' + amountColor + ';font-weight:700;">' +
                amountSign + ' ' + formatCurrency(t.amount, t.currency) +
            '</td>' +
            '<td>' + esc(t.note || '-') + '</td>' +
        '</tr>';
    });

    tbody.innerHTML = html;
}


// ================================================================
// ===== 8. الحركات للحسابات (للتكامل مع الصندوق والبنك) =====
// ================================================================

function getDirectAccountTransactions(account) {
    return directTransactions.filter(function(x) {
        if (typeof _reportIsActive === 'function' && !_reportIsActive(x)) return false;
        return x.account === account;
    }).map(function(x) {
        var isIn = x.direction === 'in';
        return {
            date: x.date,
            type: isIn ? 'in' : 'out',
            desc: x.type + (x.note ? ' — ' + x.note : ''),
            invoiceRef: '-',
            amount: x.amount,
            currency: x.currency,
            id: x.id
        };
    });
}


// ================================================================
// ===== 9. التهيئة =====
// ================================================================

function initDirectTransactions() {
    loadDirectTransactions();

    var fromEl = document.getElementById('directFrom');
    var toEl = document.getElementById('directTo');
    var dirEl = document.getElementById('directDirectionFilter');

    var savedFrom = localStorage.getItem('oa_direct_filter_from') || '';
    var savedTo = localStorage.getItem('oa_direct_filter_to') || '';
    var savedDir = localStorage.getItem('oa_direct_filter_direction') || '';

    if (fromEl) fromEl.value = savedFrom;
    if (toEl) toEl.value = savedTo;
    if (dirEl) dirEl.value = savedDir;

    if (fromEl && !fromEl._oaBound) {
        fromEl._oaBound = true;
        fromEl.addEventListener('change', function() {
            localStorage.setItem('oa_direct_filter_from', fromEl.value || '');
        });
    }
    if (toEl && !toEl._oaBound) {
        toEl._oaBound = true;
        toEl.addEventListener('change', function() {
            localStorage.setItem('oa_direct_filter_to', toEl.value || '');
        });
    }
    if (dirEl && !dirEl._oaBound) {
        dirEl._oaBound = true;
        dirEl.addEventListener('change', function() {
            localStorage.setItem('oa_direct_filter_direction', dirEl.value || '');
        });
    }

    renderDirectTransactions();
    console.log('Direct Transactions: ' + directTransactions.length + ' حركة');
}


// ================================================================
// ===== END OF DIRECT-TRANSACTIONS.JS =====
// ================================================================