// ================================================================
// Open Account — نظام محاسبي
// الملف: inventory.js
// الوصف: المستودع — إدارة المنتجات + حركات المخزون
// النسخة: v2 — مع دعم التكلفة اليدوية (avgCost)
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var products = [];
var stockMovements = [];
var currentStockItems = [];
var _currentStockMode = 'in';
var _stockFilter = 'all';
var _stockViewTab = 'products';
var _currentProductType = 'finished';

var STOCK_IN_TYPES = [
    'سند إدخال (بدون فاتورة)',
    'إرجاع مبيعات (من عميل)',
    'سند إنتاج',
    'سند تحويل بين المخازن',
    'هدية / أمانة'
];

var STOCK_OUT_TYPES = [
    'سند إخراج (استخدام داخلي)',
    'إرجاع مشتريات (للمورد)',
    'سند إتلاف',
    'عينة (للتسويق)',
    'سند تحويل بين المخازن'
];


// ================================================================
// ===== 2. تحميل وحفظ المنتجات =====
// ================================================================

function loadProducts() {
    products = Storage.get(STORAGE_KEYS.PRODUCTS, []);
    if (!Array.isArray(products)) products = [];

    var changed = false;
    products = products.map(function(product) {
        var needsMigration = !product || !Array.isArray(product.units) || !product.baseUnit;
        var normalized = normalizeProductUnits(product);
        if (normalized.avgCost === undefined) {
            normalized.avgCost = null;
            changed = true;
        }
        if (needsMigration) changed = true;
        return normalized;
    });
    if (changed) saveProducts();
}

function createUnitId() {
    return 'unit_' + generateId();
}

function normalizeProductUnits(product) {
    product = product || {};
    var baseName = String(product.baseUnit || product.unit || 'وحدة').trim() || 'وحدة';
    var units = Array.isArray(product.units) ? product.units.slice() : [];

    if (!units.length) {
        units = [{ id: createUnitId(), name: baseName, factor: 1, isBase: true, isPurchaseUnit: true, isSaleUnit: true }];
    }

    var baseIndex = units.findIndex(function(unit) {
        return unit && (unit.isBase === true || String(unit.name || '').trim() === baseName);
    });
    if (baseIndex < 0) {
        units.unshift({ id: createUnitId(), name: baseName, factor: 1, isBase: true, isPurchaseUnit: true, isSaleUnit: true });
        baseIndex = 0;
    }

    units = units.map(function(unit, index) {
        unit = unit || {};
        return {
            id: unit.id || createUnitId(),
            name: String(unit.name || (index === baseIndex ? baseName : 'وحدة')).trim() || 'وحدة',
            factor: index === baseIndex ? 1 : Math.max(0.000001, Number(unit.factor) || 1),
            isBase: index === baseIndex,
            isPurchaseUnit: unit.isPurchaseUnit !== false,
            isSaleUnit: unit.isSaleUnit !== false
        };
    });

    product.baseUnit = units[baseIndex].name;
    product.units = units;
    return product;
}

function validateProductUnits(units) {
    if (!Array.isArray(units) || !units.length) return { ok: false, message: 'أضف وحدة واحدة على الأقل' };
    var names = {};
    var bases = 0;
    for (var i = 0; i < units.length; i++) {
        var unit = units[i];
        var name = String(unit.name || '').trim();
        var factor = Number(unit.factor);
        var key = name.toLowerCase();
        if (!name || !isFinite(factor) || factor <= 0) return { ok: false, message: 'بيانات الوحدة غير صحيحة' };
        if (names[key]) return { ok: false, message: 'لا يمكن تكرار اسم الوحدة' };
        names[key] = true;
        if (unit.isBase) bases++;
    }
    if (bases !== 1) return { ok: false, message: 'يجب وجود وحدة أساسية واحدة فقط' };
    return { ok: true };
}

function saveProducts() {
    Storage.set(STORAGE_KEYS.PRODUCTS, products);
}


// ================================================================
// ===== 3. تحميل وحفظ حركات المستودع =====
// ================================================================

function loadStockMovements() {
    stockMovements = Storage.get(STORAGE_KEYS.STOCK_MOVEMENTS, []);
    if (!Array.isArray(stockMovements)) stockMovements = [];
}

function saveStockMovements() {
    Storage.set(STORAGE_KEYS.STOCK_MOVEMENTS, stockMovements);
}


// ================================================================
// ===== 4. عرض واجهة المستودع =====
// ================================================================

function renderInventory() {
    renderInventoryProducts();
    renderStockMovements();
    updateInventoryStats();
}


// ================================================================
// ===== 5. عرض جدول المنتجات =====
// ================================================================

function renderInventoryProducts() {
    var tbody = document.getElementById('invTableBody');
    if (!tbody) return;

    var searchEl = document.getElementById('invSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';

    var filtered = products.filter(function(p) {
        var t = p.type || 'finished';
        return t === _currentProductType;
    });

    if (search) {
        filtered = filtered.filter(function(p) {
            return String(p.name || '').toLowerCase().indexOf(search) !== -1;
        });
    }

    if (!filtered.length) {
        var emptyMsg = _currentProductType === 'raw'
            ? 'لا توجد مواد خام'
            : 'لا توجد منتجات تامة';
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">' + emptyMsg + '</td></tr>';
        return;
    }

var html = '';
var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
// ✅ تحديث رؤوس الأعمدة بالعملة الحالية
var thCost = document.getElementById('thCost');
if (thCost) thCost.textContent = 'التكلفة (' + baseCurrency + ')';

var thCostValue = document.getElementById('thCostValue');
if (thCostValue) thCostValue.textContent = 'قيمة التكلفة (' + baseCurrency + ')';

var thSaleValue = document.getElementById('thSaleValue');
if (thSaleValue) thSaleValue.textContent = 'قيمة البيع (' + baseCurrency + ')';
filtered.forEach(function(p, i) {
    var qty = parseFloat(p.quantity) || 0;
    var qtyClass = qty === 0 ? 'style="color:var(--color-red);font-weight:700;"' :
                   qty < 5 ? 'style="color:var(--color-gold);font-weight:700;"' : '';

    var unitText = p.baseUnit ? ' <small style="opacity:0.6;">' + esc(p.baseUnit) + '</small>' : '';

    // التكلفة
    var cost = parseFloat(p.avgCost);
    if (!isFinite(cost) || cost < 0) cost = parseFloat(p.purchasePrice);
    if (!isFinite(cost) || cost < 0) cost = 0;
    var hasCost = cost > 0;

    // تحويل التكلفة إلى العملة الأساسية
var costInBase = cost;
var costCur = p.costCurrency || p.currency || baseCurrency;
if (costCur !== baseCurrency && typeof getEquivalent === 'function') {
    costInBase = getEquivalent(cost, costCur);
}

var costDisplay = hasCost
    ? '<span style="color:var(--color-blue);font-weight:700;">' + formatAmountWithCommas(costInBase) + '</span>'
    : '<span style="color:var(--color-red);font-size:10px;" title="لم تُحدَّد تكلفة">⚠️ غير محدّدة</span>';

    // السعر البيعي
    var salePrice = parseFloat(p.salePrice != null ? p.salePrice : p.price) || 0;

       // قيمة التكلفة = الكمية × التكلفة (بالعملة الأساسية)
var costValue = hasCost ? qty * costInBase : 0;
var costValueDisplay = hasCost
    ? '<span style="color:var(--color-blue);font-weight:700;">' +
        formatAmountWithCommas(costValue) +
      '</span>'
    : '—';

    // القيمة البيعية = الكمية × سعر البيع (بالعملة الأساسية)
var salePriceInBase = salePrice;
var saleCur = p.currency || baseCurrency;
if (saleCur !== baseCurrency && typeof getEquivalent === 'function') {
    salePriceInBase = getEquivalent(salePrice, saleCur);
}
var saleValue = qty * salePriceInBase;
var saleValueDisplay = salePrice > 0
    ? '<span style="color:var(--color-green);font-weight:700;">' + formatAmountWithCommas(saleValue) + '</span>'
    : '—';

    // العملة
    var curLabel = p.currency || baseCurrency;

    html += '<tr>' +
    '<td>' + (i + 1) + '</td>' +
    '<td>' + esc(p.name) + unitText + '</td>' +
    '<td>' + formatAmountWithCommas(salePrice) + ' <small style="opacity:0.6;">' + curLabel + '</small></td>' +
    '<td>' + costDisplay + '</td>' +
    '<td ' + qtyClass + '>' + qty + '</td>' +
    '<td>' + costValueDisplay + '</td>' +
    '<td>' + saleValueDisplay + '</td>' +
        '<td>' +
            '<button class="btn-edit" onclick="editInventory(\'' + p.id + '\')" title="تعديل">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>' +
            '</button>' +
            '<button class="btn-delete" onclick="deleteInventory(\'' + p.id + '\')" title="حذف">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
            '</button>' +
        '</td>' +
    '</tr>';
});
tbody.innerHTML = html;
}

// ================================================================
// ===== 6. عرض جدول حركات المخزون =====
// ================================================================

function renderStockMovements() {
    var tbody = document.getElementById('stockMovementsTableBody');
    if (!tbody) return;

    var searchEl = document.getElementById('stockMovementsSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';

    var filtered = stockMovements.slice();

    if (_stockFilter === 'in') {
        filtered = filtered.filter(function(m) { return m.type === 'in'; });
    } else if (_stockFilter === 'out') {
        filtered = filtered.filter(function(m) { return m.type === 'out'; });
    }

    if (search) {
        filtered = filtered.filter(function(m) {
            return String(m.productName || '').toLowerCase().indexOf(search) !== -1 ||
                   String(m.docId || '').toLowerCase().indexOf(search) !== -1 ||
                   String(m.docType || '').toLowerCase().indexOf(search) !== -1 ||
                   String(m.id || '').toLowerCase().indexOf(search) !== -1;
        });
    }

    filtered.sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || '')) ||
               String(b.id || '').localeCompare(String(a.id || ''));
    });

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">لا توجد حركات</td></tr>';
        return;
    }

    var html = '';
    var totalIn = 0;
    var totalOut = 0;

    filtered.forEach(function(m, i) {
        var isIn = m.type === 'in';
        var qty = parseFloat(m.qty) || 0;
        if (isIn) totalIn += qty; else totalOut += qty;

        var typeBadge = isIn
            ? '<span class="status-badge status-paid"><span class="status-dot"></span>إدخال</span>'
            : '<span class="status-badge status-unpaid"><span class="status-dot"></span>إخراج</span>';

        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + esc(m.id) + '</td>' +
            '<td>' + formatDate(m.date) + '</td>' +
            '<td>' + typeBadge + '</td>' +
          '<td>' + _renderDocLink(m.docType, m.docId) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(m.productName || '-') + '</td>' +
            '<td style="font-weight:700;color:' + (isIn ? 'var(--color-green)' : 'var(--color-red)') + ';">' +
                (isIn ? '+' : '−') + qty +
            '</td>' +
        '</tr>';
    });

    html += '<tr class="total-row">' +
        '<td colspan="6" style="text-align:right;padding-right:12px;">الإجمالي</td>' +
        '<td>';
    if (totalIn > 0) html += '<span style="color:var(--color-green);">+' + totalIn + '</span>';
    if (totalOut > 0) html += (totalIn > 0 ? ' / ' : '') + '<span style="color:var(--color-red);">−' + totalOut + '</span>';
    if (totalIn === 0 && totalOut === 0) html += '0';
    html += '</td></tr>';

    tbody.innerHTML = html;
}


// ================================================================
// ===== 7. إحصائيات المستودع =====
// ================================================================

function updateInventoryStats() {
    setText('dashProducts', products.length);
    setText('invTotalCount', products.length);

    var totalCostValue = 0;
    var lowStock = 0;
    var outOfStock = 0;

    products.forEach(function(p) {
    // ✅ القيمة بالعملة الأساسية عبر الدالة الموحدة
    var value = (typeof getProductCostValueBase === 'function')
        ? getProductCostValueBase(p)
        : 0;

    totalCostValue += value;

    var qty = parseFloat(p.quantity) || 0;
    if (qty === 0) outOfStock++;
    else if (qty < 5) lowStock++;
});

    setText('invTotalValue', formatAmountWithCommas(totalCostValue));
    setText('invLowStock', lowStock + outOfStock);

    var today = todayISO();
    var todayCount = stockMovements.filter(function(m) {
        return m.date === today;
    }).length;
    setText('invTodayMovements', todayCount);
}


// ================================================================
// ===== 8. التبديل بين تبويبات المستودع =====
// ================================================================

function switchStockView(view) {
    _stockViewTab = view;

    var productsView = document.getElementById('stockProductsView');
    var movementsView = document.getElementById('stockMovementsView');
    var btnProducts = document.getElementById('mainTabProducts');
    var btnMovements = document.getElementById('mainTabMovements');
    var typeTabs = document.getElementById('productTypeTabs');

    if (view === 'products') {
        if (productsView) productsView.classList.add('active');
        if (movementsView) movementsView.classList.remove('active');
        if (btnProducts) btnProducts.classList.add('active');
        if (btnMovements) btnMovements.classList.remove('active');
        if (typeTabs) typeTabs.style.display = '';
    } else {
        if (productsView) productsView.classList.remove('active');
        if (movementsView) movementsView.classList.add('active');
        if (btnProducts) btnProducts.classList.remove('active');
        if (btnMovements) btnMovements.classList.add('active');
        if (typeTabs) typeTabs.style.display = 'none';
    }
}


// ================================================================
// ===== 9. فلترة حركات المخزون =====
// ================================================================

function filterStockMovements(filter) {
    _stockFilter = filter;

    ['all', 'in', 'out'].forEach(function(f) {
        var btn = document.getElementById('stockFilter_' + f);
        if (btn) {
            if (f === filter) btn.classList.add('active');
            else btn.classList.remove('active');
        }
    });

    renderStockMovements();
}


// ================================================================
// ===== 10. نافذة إضافة/تعديل منتج =====
// ================================================================

function openInvModal(data) {
    var isEdit = data && data.id;

    var type = isEdit ? (data.type || 'finished') : 'finished';
    var normalized = normalizeProductUnits(isEdit ? data : { unit: '' });
    var baseUnit = normalized.baseUnit || 'وحدة';
    var alternateUnit = normalized.units.find(function(unit) { return !unit.isBase; });
    if (!alternateUnit && data && data.alternateUnit) alternateUnit = { name: data.alternateUnit, factor: Number(data.conversionFactor) || 1 };
    if (alternateUnit && data && Number(data.conversionFactor) > 0) alternateUnit.factor = Number(data.conversionFactor);

    var currentCost = isEdit ? parseFloat(data.avgCost) : 0;
    if (!isFinite(currentCost) || currentCost < 0) currentCost = '';

    var costHint = type === 'raw'
        ? 'تُحدَّث تلقائياً من فواتير الشراء'
        : 'أدخل التكلفة يدوياً أو احسبها من سند الإنتاج';

    var bodyHTML =
        '<input type="hidden" id="invEditId" value="' + (isEdit ? data.id : '') + '">' +

        '<div class="form-field">' +
            '<label>نوع المنتج</label>' +
            '<select id="invType" onchange="_onInvTypeChange()">' +
                '<option value="finished"' + (type === 'finished' ? ' selected' : '') + '>منتج تام</option>' +
                '<option value="raw"' + (type === 'raw' ? ' selected' : '') + '>مادة خام</option>' +
            '</select>' +
        '</div>' +

        '<div class="form-field">' +
            '<label>اسم المنتج</label>' +
            '<input type="text" id="invName" placeholder="أدخل اسم المنتج" value="' + (isEdit ? esc(data.name) : '') + '">' +
        '</div>' +

        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>سعر البيع الافتراضي</label>' +
                '<input type="number" id="invPrice" placeholder="0.00" step="0.01" min="0" value="' + (isEdit ? (data.price || '') : '') + '">' +
            '</div>' +
            '<div class="form-field">' +
                '<label>الوحدة الأساسية</label>' +
                '<input type="text" id="invBaseUnit" placeholder="علبة، كجم، متر..." value="' + esc(baseUnit) + '">' +
            '</div>' +
        '</div>' +

        '<div class="form-field" id="invCostField">' +
            '<label>تكلفة الوحدة (اختياري)</label>' +
            '<input type="number" id="invAvgCost" placeholder="0.00" step="0.01" min="0" value="' + currentCost + '">' +
            '<small style="display:block;margin-top:4px;font-size:10px;color:var(--color-text-3);" id="invCostHint">' + esc(costHint) + '</small>' +
        '</div>' +

        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>وحدة العرض (اختياري)</label>' +
                '<input type="text" id="invAltUnit" placeholder="بندل، كرتون، رول..." value="' + (alternateUnit ? esc(alternateUnit.name) : '') + '">' +
            '</div>' +
            '<div class="form-field">' +
                '<label>معامل التحويل</label>' +
                '<input type="number" id="invConversionFactor" placeholder="1" step="0.000001" min="0.000001" value="' + (alternateUnit ? alternateUnit.factor : 1) + '">' +
            '</div>' +
        '</div>' +

        (isEdit
            ? '<div class="info-message" style="font-size:11px;padding:8px 12px;text-align:right;">' +
                'الكمية الحالية: ' + (parseFloat(data.quantity) || 0) + ' — لتعديلها استخدم أزرار الإدخال/الإخراج' +
              '</div>'
            : '<div class="info-message" style="font-size:11px;padding:8px 12px;text-align:right;">' +
                'ملاحظة: الكمية تُضاف عبر سند الإدخال أو فاتورة الشراء' +
              '</div>'
        ) +

        '<div class="form-field">' +
            '<label>العملة</label>' +
            '<select id="invCurrency" class="currency-select">' +
                '<option value="YER">ريال يمني</option>' +
                '<option value="SAR">ريال سعودي</option>' +
                '<option value="USD">دولار أمريكي</option>' +
            '</select>' +
        '</div>';

    var footerHTML =
        '<button class="btn btn-cancel" onclick="closeModal(\'invModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="saveInventory()">حفظ</button>';

    Modal.open({
        id: 'invModal',
        title: isEdit ? 'تعديل منتج' : 'إضافة منتج جديد',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            var currencySelect = modalEl.querySelector('#invCurrency');
            if (currencySelect) {
                if (isEdit && data.currency) {
                    currencySelect.value = data.currency;
                } else if (typeof getBaseCurrency === 'function') {
                    currencySelect.value = getBaseCurrency();
                }
            }

            setTimeout(function() {
                var nameInput = modalEl.querySelector('#invName');
                if (nameInput) nameInput.focus();
            }, 200);
        }
    });
}

function _onInvTypeChange() {
    var typeEl = document.getElementById('invType');
    var hintEl = document.getElementById('invCostHint');
    if (!typeEl || !hintEl) return;
    if (typeEl.value === 'raw') {
        hintEl.textContent = 'تُحدَّث تلقائياً من فواتير الشراء';
    } else {
        hintEl.textContent = 'أدخل التكلفة يدوياً أو احسبها من سند الإنتاج';
    }
}


// ================================================================
// ===== 11. تعديل منتج =====
// ================================================================

function editInventory(id) {
    var product = products.find(function(p) { return p.id === id; });
    if (product) {
        openInvModal(product);
    }
}


// ================================================================
// ===== 12. حفظ منتج =====
// ================================================================

function saveInventory() {
    var idEl = document.getElementById('invEditId');
    var typeEl = document.getElementById('invType');
    var nameEl = document.getElementById('invName');
    var priceEl = document.getElementById('invPrice');
    var baseUnitEl = document.getElementById('invBaseUnit');
    var altUnitEl = document.getElementById('invAltUnit');
    var factorEl = document.getElementById('invConversionFactor');
    var currencyEl = document.getElementById('invCurrency');
    var avgCostEl = document.getElementById('invAvgCost');

    var id = idEl ? idEl.value : '';
    var type = typeEl ? typeEl.value : 'finished';
    var name = nameEl ? nameEl.value.trim() : '';
    var price = parseFloat(priceEl ? priceEl.value : 0) || 0;
    var baseUnit = baseUnitEl ? baseUnitEl.value.trim() : 'وحدة';
    var alternateUnit = altUnitEl ? altUnitEl.value.trim() : '';
    var conversionFactor = parseFloat(factorEl ? factorEl.value : 1);
    if (!isFinite(conversionFactor) || conversionFactor <= 0) conversionFactor = 1;
    var currency = currencyEl ? currencyEl.value : 'YER';

    var avgCostRaw = avgCostEl ? avgCostEl.value.trim() : '';
    var avgCost = null;
    if (avgCostRaw !== '') {
        var parsed = parseFloat(avgCostRaw);
        if (isFinite(parsed) && parsed >= 0) {
            avgCost = parsed;
        } else {
            showToast('تكلفة الوحدة غير صحيحة', 'error');
            return;
        }
    }

    if (!name) {
        showToast('يرجى إدخال اسم المنتج', 'error');
        return;
    }

    if (price < 0) {
        showToast('يرجى إدخال سعر صحيح', 'error');
        return;
    }

    if (!baseUnit) {
        showToast('يرجى إدخال الوحدة الأساسية', 'error');
        return;
    }
    if (alternateUnit && conversionFactor <= 0) {
        showToast('يرجى إدخال معامل تحويل صحيح', 'error');
        return;
    }

    var units = [{ id: createUnitId(), name: baseUnit, factor: 1, isBase: true, isPurchaseUnit: true, isSaleUnit: true }];
    if (alternateUnit) units.push({ id: createUnitId(), name: alternateUnit, factor: conversionFactor, isBase: false, isPurchaseUnit: true, isSaleUnit: true });
    var unitsValidation = validateProductUnits(units);
    if (!unitsValidation.ok) {
        showToast(unitsValidation.message, 'error');
        return;
    }

    if (id) {
        var index = products.findIndex(function(p) { return p.id === id; });
        if (index !== -1) {
            products[index].type = type;
            products[index].name = name;
            products[index].price = price;
            products[index].salePrice = price;
            products[index].saleUnit = alternateUnit || baseUnit;
            products[index].unit = baseUnit;
            products[index].baseUnit = baseUnit;
            products[index].units = units;
            products[index].alternateUnit = alternateUnit || '';
            products[index].conversionFactor = alternateUnit ? conversionFactor : 1;
            products[index].currency = currency;
            products[index].avgCost = avgCost;
        }
        showToast('تم تعديل المنتج', 'success');
    } else {
        products.push({
            id: generateId(),
            type: type,
            name: name,
            price: price,
            salePrice: price,
            saleUnit: alternateUnit || baseUnit,
            unit: baseUnit,
            baseUnit: baseUnit,
            units: units,
            alternateUnit: alternateUnit || '',
            conversionFactor: alternateUnit ? conversionFactor : 1,
            currency: currency,
            quantity: 0,
            avgCost: avgCost
        });
        showToast('تم إضافة المنتج', 'success');
    }

    saveProducts();
    closeModal('invModal');
    renderInventory();
}


// ================================================================
// ===== 13. حذف منتج =====
// ================================================================

function deleteInventory(id) {
    var product = products.find(function(p) { return p.id === id; });
    if (!product) return;

    var hasMovements = stockMovements.some(function(m) { return m.productId === id; });
    var message = 'هل أنت متأكد من حذف المنتج "' + product.name + '"؟';
    if (hasMovements) {
        message += '\nيوجد حركات مستودع مسجلة لهذا المنتج';
    }

    Modal.confirm({
        title: 'تأكيد الحذف',
        message: message,
        confirmText: 'حذف',
        cancelText: 'إلغاء',
        confirmColor: 'danger',
        onConfirm: function() {
            products = products.filter(function(p) { return p.id !== id; });
            saveProducts();
            renderInventory();
            showToast('تم حذف المنتج', 'success');
        }
    });
}


// ================================================================
// ===== 14. نافذة الإدخال / الإخراج =====
// ================================================================

function openStockInModal() {
    _openStockModal('in');
}

function openStockOutModal() {
    _openStockModal('out');
}

function _openStockModal(mode) {
    _currentStockMode = mode;
    currentStockItems = [];

    if (!products || products.length === 0) {
        showToast('يرجى إضافة منتج أولاً', 'error');
        return;
    }

    var isIn = mode === 'in';
    var title = isIn ? 'إدخال مخزون' : 'إخراج مخزون';
    var types = isIn ? STOCK_IN_TYPES : STOCK_OUT_TYPES;
    var btnClass = isIn ? 'btn-success' : 'btn-danger';

    var docTypeOptions = '';
    types.forEach(function(t) {
        docTypeOptions += '<option value="' + esc(t) + '">' + esc(t) + '</option>';
    });

    var bodyHTML =
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>نوع المستند</label>' +
                '<select id="stockDocType">' + docTypeOptions + '</select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="stockDate" value="' + todayISO() + '">' +
            '</div>' +
        '</div>' +

        '<div class="form-field">' +
            '<label>رقم المستند (اختياري)</label>' +
            '<input type="text" id="stockDocId" placeholder="اتركه فارغاً للتوليد التلقائي">' +
        '</div>' +

        '<div class="section-label">' +
            '<span>المنتجات</span>' +
        '</div>' +

        '<div class="add-item-row">' +
            '<select id="stockProductSelect">' +
                '<option value="">— اختر منتج —</option>' +
            '</select>' +
            '<input type="number" id="stockProductQty" placeholder="الكمية" value="1" min="0.000001" step="0.000001">' +
            '<button class="btn btn-add" onclick="addProductToStock()" title="إضافة">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
                    '<line x1="12" y1="5" x2="12" y2="19"/>' +
                    '<line x1="5" y1="12" x2="19" y2="12"/>' +
                '</svg>' +
            '</button>' +
        '</div>' +

        '<div class="items-list" id="stockItemsList">' +
            '<div class="empty-items">لا توجد منتجات مضافة</div>' +
        '</div>' +

        '<div class="form-field" style="margin-top:10px;">' +
            '<label>ملاحظة (اختياري)</label>' +
            '<input type="text" id="stockNote" placeholder="ملاحظة">' +
        '</div>';

    var footerHTML =
        '<button class="btn btn-cancel" onclick="closeModal(\'stockModal\')">إلغاء</button>' +
        '<button class="btn ' + btnClass + '" onclick="saveStockMovement()">حفظ</button>';

    Modal.open({
        id: 'stockModal',
        title: title,
        size: 'large',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            _populateStockProducts();
        }
    });
}


// ================================================================
// ===== 15. ملء قائمة المنتجات =====
// ================================================================

function _populateStockProducts() {
    var selectEl = document.getElementById('stockProductSelect');
    if (!selectEl) return;

    var html = '<option value="">— اختر منتج —</option>';
    products.forEach(function(p) {
        var qty = parseFloat(p.quantity) || 0;
        var label = p.name + ' (متوفر: ' + qty + ')';
        html += '<option value="' + p.id + '">' + esc(label) + '</option>';
    });
    selectEl.innerHTML = html;
}


// ================================================================
// ===== 16. إضافة منتج للنافذة =====
// ================================================================

function addProductToStock() {
    var productIdEl = document.getElementById('stockProductSelect');
    var qtyEl = document.getElementById('stockProductQty');

    var productId = productIdEl ? productIdEl.value : '';
    var qty = parseFloat(qtyEl ? qtyEl.value : 1) || 1;

    if (!productId) {
        showToast('يرجى اختيار منتج', 'error');
        return;
    }

    if (qty <= 0) {
        showToast('يرجى إدخال كمية صحيحة', 'error');
        return;
    }

    var product = products.find(function(p) { return p.id === productId; });
    if (!product) return;

    if (_currentStockMode === 'out') {
        var stock = parseFloat(product.quantity) || 0;
        var existing = currentStockItems.find(function(item) { return item.productId === productId; });
        var totalQty = (existing ? existing.qty : 0) + qty;

        if (totalQty > stock) {
            showToast('الكمية المتاحة: ' + stock + ' فقط', 'error');
            return;
        }
    }

    var existingItem = currentStockItems.find(function(item) { return item.productId === productId; });

    if (existingItem) {
        existingItem.qty += qty;
    } else {
        currentStockItems.push({
            productId: product.id,
            name: product.name,
            qty: qty
        });
    }

    renderStockItems();
    if (qtyEl) qtyEl.value = 1;
    showToast('تم إضافة المنتج', 'success');
}


// ================================================================
// ===== 17. عرض منتجات النافذة =====
// ================================================================

function renderStockItems() {
    var container = document.getElementById('stockItemsList');
    if (!container) return;

    if (!currentStockItems.length) {
        container.innerHTML = '<div class="empty-items">لا توجد منتجات مضافة</div>';
        return;
    }

    var html = '';
    currentStockItems.forEach(function(item, index) {
        html += '<div class="item-row">' +
            '<span>' + esc(item.name) + '</span>' +
            '<span>الكمية: ' + item.qty + '</span>' +
            '<button onclick="removeStockItem(' + index + ')" title="إزالة">×</button>' +
        '</div>';
    });
    container.innerHTML = html;
}


function removeStockItem(index) {
    if (index < 0 || index >= currentStockItems.length) return;
    currentStockItems.splice(index, 1);
    renderStockItems();
}


// ================================================================
// ===== 18. حفظ حركة المخزون =====
// ================================================================

function saveStockMovement() {
    var docTypeEl = document.getElementById('stockDocType');
    var dateEl = document.getElementById('stockDate');
    var docIdEl = document.getElementById('stockDocId');
    var noteEl = document.getElementById('stockNote');

    var docType = docTypeEl ? docTypeEl.value : '';
    var date = dateEl ? dateEl.value : '';
    var docId = docIdEl ? docIdEl.value.trim() : '';
    var note = noteEl ? noteEl.value.trim() : '';

    if (!date) {
        showToast('يرجى اختيار التاريخ', 'error');
        return;
    }

    if (!currentStockItems.length) {
        showToast('يرجى إضافة منتجات', 'error');
        return;
    }

    if (!docId) {
        var prefix = _currentStockMode === 'in' ? 'IN' : 'OUT';
        docId = generateDocNumber(prefix);
    }

    if (_currentStockMode === 'out') {
        for (var i = 0; i < currentStockItems.length; i++) {
            var item = currentStockItems[i];
            var product = products.find(function(p) { return p.id === item.productId; });
            if (!product) continue;
            var stock = parseFloat(product.quantity) || 0;
            if (item.qty > stock) {
                showToast('الكمية المتاحة من "' + product.name + '": ' + stock, 'error');
                return;
            }
        }
    }

    currentStockItems.forEach(function(item) {
        var product = products.find(function(p) { return p.id === item.productId; });
        if (!product) return;

        var currentQty = parseFloat(product.quantity) || 0;

        if (_currentStockMode === 'in') {
            product.quantity = currentQty + item.qty;
        } else {
            product.quantity = Math.max(0, currentQty - item.qty);
        }

        var movement = {
            id: generateId(),
            date: date,
            type: _currentStockMode,
            docType: docType,
            docId: docId,
            productId: product.id,
            productName: product.name,
            qty: item.qty,
            price: parseFloat(product.price) || 0,
            currency: product.currency || 'YER',
            note: note,
            createdAt: new Date().toISOString()
        };

        stockMovements.push(movement);
    });

    saveProducts();
    saveStockMovements();

    currentStockItems = [];
    closeModal('stockModal');
    renderInventory();

    if (typeof updateDashboard === 'function') {
        updateDashboard();
    }

    showToast(
        _currentStockMode === 'in' ? 'تم تسجيل الإدخال بنجاح' : 'تم تسجيل الإخراج بنجاح',
        'success'
    );
}


// ================================================================
// ===== 19. دوال مساعدة للتكامل مع الفواتير =====
// ================================================================

function recordStockMovement(data) {
    if (!data || !data.productId) return;

    var movement = {
        id: generateId(),
        date: data.date || todayISO(),
        type: data.type || 'in',
        docType: data.docType || '-',
        docId: data.docId || '-',
        productId: data.productId,
        productName: data.productName || '-',
        qty: parseFloat(data.qty) || 0,
        price: parseFloat(data.price) || 0,
        currency: data.currency || 'YER',
        note: data.note || '',
        createdAt: new Date().toISOString()
    };

    stockMovements.push(movement);
    saveStockMovements();
}


function removeStockMovementsByDoc(docId) {
    if (!docId) return;
    stockMovements = stockMovements.filter(function(m) { return m.docId !== docId; });
    saveStockMovements();
}


// ================================================================
// ===== 20. تهيئة المستودع =====
// ================================================================

function initInventory() {
    loadProducts();
    loadStockMovements();
    _migrateOpeningStock();
    renderInventory();

    var searchEl = document.getElementById('invSearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderInventoryProducts, 300));
    }

    var movSearchEl = document.getElementById('stockMovementsSearch');
    if (movSearchEl) {
        movSearchEl.addEventListener('input', debounce(renderStockMovements, 300));
    }

    console.log('Inventory: ' + products.length + ' منتج، ' + stockMovements.length + ' حركة');
}


function _migrateOpeningStock() {
    // ✅ إصلاح: لا نُنشئ حركات وهمية
    // إذا وُجد منتج بكمية > 0 بلا حركات، فهذا خطأ بيانات
    // نُسجّله في console فقط — دون إنشاء حركة
    // (وفق قرار المحاسب: لا حذف يدوي، لا ترحيل تلقائي)

    var orphans = products.filter(function(p) {
        var qty = parseFloat(p.quantity) || 0;
        if (qty <= 0) return false;
        return !stockMovements.some(function(m) { return m.productId === p.id; });
    });

    if (orphans.length > 0) {
        console.warn('[OA] ⚠️ منتجات بكميات بدون حركات مخزنية:');
        orphans.forEach(function(p) {
            console.warn('  - ' + p.name + ': كمية ' + p.quantity + ' بلا حركة');
        });
        console.warn('[OA] لم يتم إنشاء حركات وهمية — راجع البيانات يدوياً');
    }
}


function switchProductType(type) {
    _currentProductType = type;

    var btnFinished = document.getElementById('typeTabFinished');
    var btnRaw = document.getElementById('typeTabRaw');

    if (type === 'raw') {
        if (btnFinished) btnFinished.classList.remove('active');
        if (btnRaw) btnRaw.classList.add('active');
    } else {
        if (btnFinished) btnFinished.classList.add('active');
        if (btnRaw) btnRaw.classList.remove('active');
    }

    renderInventoryProducts();
}
// ================================================================
// ===== عرض رابط المستند في حركة المخزون =====
// ================================================================

function _renderDocLink(docType, docId) {
    if (!docType || docType === '-') return '-';
    if (!docId) return esc(docType);

    // تحديد المسار حسب نوع المستند
    var routeMap = {
        'فاتورة بيع': 'sales_invoice',
        'فاتورة شراء': 'purchase_invoice',
        'مرتجع مبيعات': 'return_sale',
        'مرتجع مشتريات': 'return_purchase',
        'سند إنتاج': 'production',
        'إلغاء فاتورة بيع': 'invoice_cancellation',
        'إلغاء فاتورة شراء': 'invoice_cancellation',
        'إلغاء سند إنتاج': 'production_cancellation',
        'سند إدخال (بدون فاتورة)': 'stock_adjustment_in',
        'سند إخراج (استخدام داخلي)': 'stock_adjustment_out',
        'سند إتلاف': 'stock_adjustment_out',
        'عينة (للتسويق)': 'stock_adjustment_out'
    };

    var refType = routeMap[docType];
    if (!refType) {
        // نوع غير معروف — نعرضه نصاً
        return esc(docType) + ' <span style="color:#888;font-size:10px;">#' + esc(docId) + '</span>';
    }

    // زر قابل للنقر
    return '<button onclick="OAInventory.openStockDocLink(\'' + esc(docType) + '\', \'' + esc(docId) + '\', \'' + refType + '\')" ' +
        'style="background:none;border:none;color:var(--color-blue);font-weight:700;text-decoration:underline;cursor:pointer;padding:0;font-family:inherit;font-size:inherit;text-align:right;">' +
        esc(docType) + ' <span style="font-size:11px;font-weight:600;">#' + esc(docId) + ' ↗</span>' +
    '</button>';
}

// ================================================================
// ===== فتح المستند من حركة المخزون =====
// ================================================================

function _openStockDocLink(docType, docId, refType) {
    if (!docId || !refType) return;

    var routeMap = {
        'sales_invoice': 'sales',
        'purchase_invoice': 'purchases',
        'return_sale': 'returns',
        'return_purchase': 'returns',
        'production': 'production',
        'production_cancellation': 'production',
        'invoice_cancellation': 'sales',
        'stock_adjustment_in': 'inventory',
        'stock_adjustment_out': 'inventory'
    };

    var tabId = routeMap[refType];
    if (!tabId) {
        if (typeof showToast === 'function') showToast('نوع المستند غير مدعوم', 'info');
        return;
    }

    // احفظ المرجع
    try {
        localStorage.setItem('oa_pending_open_doc', JSON.stringify({
            type: refType,
            id: docId,
            tab: tabId,
            timestamp: new Date().toISOString()
        }));
    } catch (e) {}

    // انتقل للتبويب
    if (typeof switchTab === 'function') {
        switchTab(tabId);
    }

    // انتظر ثانية → افتح المستند
    setTimeout(function() {
        _openPendingDocFromInventory(refType, docId);
    }, 500);
}

function _openPendingDocFromInventory(refType, docId) {
    // استخدم نفس منطق main.js
    if (refType === 'sales_invoice') {
        if (typeof viewSalesInvoice === 'function') viewSalesInvoice(docId);
    } else if (refType === 'purchase_invoice') {
        if (typeof viewPurchaseInvoice === 'function') viewPurchaseInvoice(docId);
    } else if (refType === 'return_sale' || refType === 'return_purchase') {
        if (typeof viewReturn === 'function') viewReturn(docId);
    } else if (refType === 'production') {
        if (typeof printProductionDocument === 'function') printProductionDocument(docId);
    }
}

// تصدير للاستخدام من onclick
window.OAInventory = {
    openStockDocLink: _openStockDocLink
};


// ================================================================
// ===== END OF INVENTORY.JS =====
// ================================================================