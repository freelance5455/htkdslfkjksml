// ================================================================
// Open Account — استيراد الأرشيف وعرض المستندات كـ PDF
// ================================================================
var archiveRestoreData = null;
var archiveImportedDocuments = [];

function initArchiveRestore() {
    var input = document.getElementById('archiveRestoreFileInput');
    if (input && !input._bound) { input.addEventListener('change', handleArchiveFileSelect); input._bound = true; }
}
function _archiveRestoreSources(data) {
    var docs = data && data.documents;
    if (!docs && data && data.data) {
        docs = {
            salesInvoices: data.data.oa_sales_invoices || [], purchaseInvoices: data.data.oa_purchase_invoices || [],
            receipts: data.data.oa_receipts || [], payments: data.data.oa_payments || [], expenses: data.data.oa_expenses || [],
            productionDocs: data.data.oa_production_docs || [], transfers: data.data.oa_transfers || [], stockMovements: data.data.oa_stock_movements || []
        };
    }
    return docs || {};
}
function handleArchiveFileSelect(event) {
    var file = event.target.files && event.target.files[0]; if (!file) return;
    var reader = new FileReader();
    reader.onload = function(e) { try {
        var parsed = JSON.parse(e.target.result);
        if (!parsed || !_archiveRestoreSources(parsed)) throw new Error('ملف الأرشيف غير صالح');
        archiveRestoreData = parsed; archiveImportedDocuments = [];
        var docs = _archiveRestoreSources(parsed), mapping = [
            ['salesInvoices','فاتورة بيع','sales'], ['purchaseInvoices','فاتورة شراء','purchases'], ['receipts','سند قبض','receipts'],
            ['payments','سند صرف','payments'], ['expenses','مصروف','expenses'], ['productionDocs','سند إنتاج','production'],
            ['transfers','تحويل','transfers'], ['stockMovements','حركة مخزون','stock']
        ];
        mapping.forEach(function(m) { (Array.isArray(docs[m[0]]) ? docs[m[0]] : []).forEach(function(doc) { archiveImportedDocuments.push({type:m[1],key:m[2],data:doc}); }); });
        displayArchiveFileInfo(file, parsed); renderArchiveRestoreTable();
    } catch (error) { alert('خطأ أثناء قراءة الملف: ' + error.message); clearArchiveRestoreView(); } };
    reader.onerror = function() { alert('فشل في قراءة الملف'); clearArchiveRestoreView(); };
    reader.readAsText(file);
}
function displayArchiveFileInfo(file, data) {
    var el = document.getElementById('archiveFileInfo'); if (!el) return;
    var period = data.period ? (data.period.from + ' إلى ' + data.period.to) : 'غير محددة';
    el.innerHTML = '<div class="info-message"><strong>الملف:</strong> '+esc(file.name)+' | <strong>عدد المستندات:</strong> '+archiveImportedDocuments.length+' | <strong>الفترة:</strong> '+esc(period)+'</div>';
}
function renderArchiveRestoreTable() {
    var tbody = document.getElementById('archiveRestoreTableBody'); if (!tbody) return;
    tbody.innerHTML = archiveImportedDocuments.length ? archiveImportedDocuments.map(function(item, i) {
        var d=item.data||{}, name=d.customerName||d.supplierName||d.productName||'-', amount=d.total!==undefined?d.total:(d.amount!==undefined?d.amount:'-');
        return '<tr><td>'+(i+1)+'</td><td>'+esc(item.type)+'</td><td>'+esc(d.id||'-')+'</td><td>'+esc(d.date||'-')+'</td><td>'+esc(name)+'</td><td>'+esc(String(amount))+'</td><td><button class="btn-view" onclick="printImportedArchiveDocument('+i+')">عرض / PDF</button></td></tr>';
    }).join('') : '<tr><td colspan="7" class="empty-cell">لا توجد مستندات داخل هذا الملف</td></tr>';
}
function printImportedArchiveDocument(index) {
    var item=archiveImportedDocuments[index]; if (!item) return;
    var d=item.data||{}, rows=[], cols=[], meta=[['النوع',item.type],['الرقم',d.id||'-'],['التاريخ',d.date||'-']];
    if (d.customerName) meta.push(['العميل',d.customerName]); if (d.supplierName) meta.push(['المورد',d.supplierName]); if (d.originalInvoiceId) meta.push(['الفاتورة الأصلية',d.originalInvoiceId]);
    if (d.currency) meta.push(['العملة',d.currency]); if (d.status) meta.push(['الحالة',d.status]);
    if (Array.isArray(d.items)) { cols=['#','الصنف','الكمية','السعر','الإجمالي']; d.items.forEach(function(x,n){ rows.push([n+1,x.name||'-',x.inputQty!==undefined?(x.inputQty+' '+(x.inputUnit||x.baseUnit||'')):(x.qty||0),x.inputUnitPrice!==undefined?x.inputUnitPrice:(x.price||0),(Number(x.price)||0)*(Number(x.qty)||0)]); }); }
    else { cols=['البيان','القيمة']; Object.keys(d).forEach(function(k){ if(['id','date','createdAt'].indexOf(k)<0 && ['string','number'].indexOf(typeof d[k])>=0) rows.push([k,d[k]]); }); }
    var table = '<div class="doc-wrapper"><div class="doc-title">'+esc(item.type)+'</div><table class="doc-table"><thead><tr>'+cols.map(function(c){return '<th>'+esc(String(c))+'</th>';}).join('')+'</tr></thead><tbody>'+rows.map(function(row){return '<tr>'+row.map(function(c){return '<td>'+esc(String(c === undefined ? '' : c))+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table><div class="doc-footer">مستند مستورد من الأرشيف</div></div>';
    if (typeof printHtmlDocument === 'function') { printHtmlDocument(item.type, table, meta); return; }
    alert('مسار الطباعة غير متاح');
}
function clearArchiveRestoreView() { archiveRestoreData=null; archiveImportedDocuments=[]; var info=document.getElementById('archiveFileInfo'),tbody=document.getElementById('archiveRestoreTableBody'); if(info)info.innerHTML=''; if(tbody)tbody.innerHTML='<tr><td colspan="7" class="empty-cell">اختر ملف أرشيف صالحاً لعرضه</td></tr>'; }
