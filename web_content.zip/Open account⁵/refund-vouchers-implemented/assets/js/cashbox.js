// ================================================================
// Open Account — نظام محاسبي
// الملف: cashbox.js
// الوصف: حساب الصندوق (النقد الفعلي)
// النسخة: v2 — مع الرصيد التراكمي لكل عملة
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var cashboxFrom = '';
var cashboxTo = '';


// ================================================================
// ===== 2. جمع حركات الصندوق =====
// ================================================================

/**
 * جمع كل الحركات النقدية (المقبوضات + المدفوعات)
 * @returns {array}
 */
function getCashboxTransactions() {
    var transactions = [];
    if (typeof getDirectAccountTransactions === 'function') transactions = transactions.concat(getDirectAccountTransactions('cashbox'));
    // ===== 1. المقبوضات النقدية =====
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
            if (r.cancelled || r.documentStatus === 'cancelled') return;
            if ((r.method || 'نقدي') === 'نقدي') {
                transactions.push({
                    date: r.date,
                    type: 'in',
                    desc: r.receiptType === 'supplier_refund' ? 'تحصيل من المورد: ' + (r.supplierName || '-') : 'قبض من ' + (r.customerName || '-'),
                    invoiceRef: r.invoiceId || '-',
                    amount: parseFloat(r.amount) || 0,
                    currency: r.currency || 'YER',
                    id: r.id
                });
            }
        });
    }

    // ===== 2. المدفوعات النقدية =====
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
    if (p.archived) return;
    if (p.cancelled || p.documentStatus === 'cancelled') return;
    if ((p.method || 'نقدي') !== 'نقدي') return;

            var desc = p.paymentType === 'customer_refund' ? 'رد مبلغ للعميل: ' + (p.customerName || '-') : (p.isExpense ? 'مصروف: ' + (p.supplierName || p.expenseType || '-') : 'دفع إلى ' + (p.supplierName || '-'));

            transactions.push({
                date: p.date,
                type: 'out',
                desc: desc,
                invoiceRef: p.invoiceId || '-',
                amount: parseFloat(p.amount) || 0,
                currency: p.currency || 'YER',
                id: p.id
            });
        });
    }

    // ===== 3. التحويلات الداخلية =====
    if (typeof transfers !== 'undefined' && Array.isArray(transfers)) {
        transfers.forEach(function(t) {
            if (t.status === 'cancelled') return;
            if (t.from && t.from.accountType === 'cashbox') {
                transactions.push({
                    date: t.date,
                    type: 'out',
                    desc: 'تحويل إلى ' + getTransferAccountLabel(t.to.accountType),
                    invoiceRef: t.number,
                    amount: parseFloat(t.from.amount) || 0,
                    currency: t.from.currency || 'YER',
                    id: t.number
                });
            }
            if (t.to && t.to.accountType === 'cashbox') {
                transactions.push({
                    date: t.date,
                    type: 'in',
                    desc: 'تحويل من ' + getTransferAccountLabel(t.from.accountType),
                    invoiceRef: t.number,
                    amount: parseFloat(t.to.amount) || 0,
                    currency: t.to.currency || 'YER',
                    id: t.number
                });
            }
        });
    }

    // ترتيب حسب التاريخ
    transactions.sort(function(a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
    });

    return transactions;
}


// ================================================================
// ===== 3. تنسيق الرصيد متعدد العملات =====
// ================================================================

/**
 * تنسيق كائن أرصدة (لكل عملة) إلى نص
 * @param {object} balances - {YER: 150, SAR: 50}
 * @param {boolean} includeZero - إظهار الأصفار
 * @returns {string}
 */
// ================================================================
// ===== 3. تنسيق الرصيد متعدد العملات (نسخة موحّدة) =====
// ================================================================

/**
 * حساب الإجمالي بالعملة الأساسية
 */
function _cashboxComputeBaseTotal(balances) {
    if (!balances) return 0;
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var total = 0;
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var amount = parseFloat(balances[c]) || 0;
        if (amount === 0) return;
        if (c === base) {
            total += amount;
        } else {
            var rate = (typeof getCurrentExchangeRateSnapshot === 'function')
                ? getCurrentExchangeRateSnapshot(c)
                : (typeof getRate === 'function' ? getRate(c) : 1);
            var baseRate = (typeof getRate === 'function') ? getRate(base) : 1;
            total += (amount * rate) / (baseRate || 1);
        }
    });
    return total;
}

/**
 * تنسيق الرصيد: قيمة أساسية + تفصيل بالعملات
 */
function _formatMultiCurrencyBalance(balances, includeZero) {
    if (!balances) return '0.00';
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var totalBase = _cashboxComputeBaseTotal(balances);
    var hasAny = false;
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if ((parseFloat(balances[c]) || 0) !== 0) hasAny = true;
    });
    if (!hasAny && !includeZero) return '0.00 ' + base;
    return formatAmountWithCommas(totalBase) + ' ' + base;
}

/**
 * تنسيق الرصيد بلون (HTML) — قيمة أساسية + تفصيل
 */
function _formatMultiCurrencyBalanceHTML(balances) {
    if (!balances) return '<span>0.00</span>';

    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var totalBase = _cashboxComputeBaseTotal(balances);

    // القيمة الأساسية
    var primaryColor = totalBase >= 0 ? 'var(--color-green)' : 'var(--color-red)';
    var html = '<div style="font-weight:800;color:' + primaryColor + ';font-size:14px;">' +
                   formatAmountWithCommas(totalBase) + ' ' + base +
               '</div>';

    // تفصيل العملات
    var details = [];
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var amount = parseFloat(balances[c]) || 0;
        if (amount !== 0) {
            var color = amount > 0 ? 'var(--color-green)' : 'var(--color-red)';
            details.push('<span style="color:' + color + ';font-weight:600;font-size:11px;">' +
                         formatAmountWithCommas(amount) + ' ' + c + '</span>');
        }
    });

    if (details.length > 1) {
        html += '<div style="font-size:10px;color:var(--color-text-3);margin-top:2px;">' +
                    '(' + details.join(' + ') + ')' +
                '</div>';
    } else if (details.length === 1) {
        html += '<div style="font-size:10px;color:var(--color-text-3);margin-top:2px;">' +
                    details[0] +
                '</div>';
    }

    return html;
}

/**
 * حساب الرصيد الإجمالي بالعملة الأساسية (للعرض)
 */
function _formatMultiCurrencyBalanceTotal(balances) {
    var total = _cashboxComputeBaseTotal(balances);
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    return formatAmountWithCommas(total) + ' ' + base;
}
    


// ================================================================
// ===== 4. عرض شاشة الصندوق =====
// ================================================================

function renderCashbox() {
    var tbody = document.getElementById('cashboxTableBody');
    if (!tbody) return;

    var fromEl = document.getElementById('cashboxFrom');
    var toEl = document.getElementById('cashboxTo');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    cashboxFrom = from;
    cashboxTo = to;

    var allTransactions = getCashboxTransactions();

    // فلترة الحركات
    var filtered = allTransactions.filter(function(t) {
        if (from && t.date < from) return false;
        if (to && t.date > to) return false;
        return true;
    });

    // ===== الأرصدة لكل عملة =====
    var balances = {};       // الأرصدة الحالية (بعد كل الحركات حتى تاريخ الإيقاف)
    var totalIn = {};        // مجموع الوارد في الفترة
    var totalOut = {};       // مجموع الصادر في الفترة
    var openingBalances = {}; // الرصيد الافتتاحي قبل from

    // 1. حساب الرصيد الافتتاحي (قبل from)
    if (from) {
        allTransactions.forEach(function(t) {
            if (t.date < from) {
                var c = t.currency || 'YER';
                openingBalances[c] = (openingBalances[c] || 0);
                if (t.type === 'in') {
                    openingBalances[c] += t.amount;
                } else {
                    openingBalances[c] -= t.amount;
                }
            }
        });
    }

    // نسخ الافتتاحي إلى الأرصدة الحالية
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if (openingBalances[c]) balances[c] = openingBalances[c];
    });

    // 2. تطبيق حركات الفترة على الأرصدة + جمع الإجماليات
    filtered.forEach(function(t) {
        var c = t.currency || 'YER';
        if (!balances[c]) balances[c] = 0;
        if (!totalIn[c]) totalIn[c] = 0;
        if (!totalOut[c]) totalOut[c] = 0;

        if (t.type === 'in') {
            balances[c] += t.amount;
            totalIn[c] += t.amount;
        } else {
            balances[c] -= t.amount;
            totalOut[c] += t.amount;
        }
    });

    // ===== بناء الجدول =====
    var html = '';

    // 3. صف الرصيد الافتتاحي (فقط إذا كان هناك فلتر "من")
    if (from) {
        var openingParts = [];
        ['YER', 'SAR', 'USD'].forEach(function(c) {
            if (openingBalances[c]) {
                var color = openingBalances[c] > 0 ? 'var(--color-green)' : 'var(--color-red)';
                openingParts.push('<span style="color:' + color + ';font-weight:700;">' +
                                  formatAmountWithCommas(openingBalances[c]) + ' ' + c + '</span>');
            }
        });

        if (openingParts.length) {
            html += '<tr style="background:rgba(255,107,53,0.08);font-weight:bold;">' +
                '<td>—</td>' +
                '<td>—</td>' +
                '<td style="text-align:right;padding-right:12px;">رصيد أول المدة</td>' +
                '<td>—</td>' +
                '<td>—</td>' +
                '<td>' + openingParts.join(' | ') + '</td>' +
            '</tr>';
        }
    }

    // 4. الحركات — مع حساب الرصيد التراكمي في كل صف
    // نبدأ الرصيد من openingBalances ثم نطبّق الحركات واحداً واحداً
    var runningBalances = {};
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if (openingBalances[c]) runningBalances[c] = openingBalances[c];
    });

    filtered.forEach(function(t, i) {
        var c = t.currency || 'YER';

        // تطبيق الحركة على الرصيد التراكمي
        if (!runningBalances[c]) runningBalances[c] = 0;
        if (t.type === 'in') {
            runningBalances[c] += t.amount;
        } else {
            runningBalances[c] -= t.amount;
        }

        var inAmount = t.type === 'in'
            ? '<span style="color:var(--color-green);font-weight:600;">' + formatAmountWithCommas(t.amount) + ' ' + c + '</span>'
            : '—';
        var outAmount = t.type === 'out'
            ? '<span style="color:var(--color-red);font-weight:600;">' + formatAmountWithCommas(t.amount) + ' ' + c + '</span>'
            : '—';

        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + formatDate(t.date) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(t.desc) + '</td>' +
            '<td>' + inAmount + '</td>' +
            '<td>' + outAmount + '</td>' +
            '<td style="font-weight:700;">' + _formatMultiCurrencyBalanceHTML(runningBalances) + '</td>' +
        '</tr>';
    });

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">لا توجد حركات في هذه الفترة</td></tr>';
    } else {
        tbody.innerHTML = html;
    }

    // ===== الإحصائيات =====
    setText('cashboxBalance', _formatMultiCurrencyBalance(balances));
    setText('cashboxTotalIn', _formatMultiCurrencyBalance(totalIn));
    setText('cashboxTotalOut', _formatMultiCurrencyBalance(totalOut));

    var dateEl = document.getElementById('cashboxDate');
    if (dateEl) dateEl.textContent = todayArabic();
}


// ================================================================
// ===== 5. تهيئة الصندوق =====
// ================================================================

function initCashbox() {
    // تعيين التواريخ الافتراضية
    var fromEl = document.getElementById('cashboxFrom');
    var toEl = document.getElementById('cashboxTo');

    if (fromEl && !fromEl.value) {
        fromEl.value = firstDayOfMonthISO();
    }
    if (toEl && !toEl.value) {
        toEl.value = todayISO();
    }

    // ربط زر التحديث
    var refreshBtn = document.getElementById('cashboxRefresh');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', renderCashbox);
    }

    renderCashbox();

    console.log('Cashbox: initialized');
}

// ================================================================
// ===== 6. طباعة كشف الصندوق (القالب الجديد) =====
// ================================================================

function printCashboxStatement() {
    // 1. اقرأ فلتر الفترة
    var fromEl = document.getElementById('cashboxFrom');
    var toEl = document.getElementById('cashboxTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    // 2. اقرأ الجدول الحالي من الصفحة
    var tbody = document.getElementById('cashboxTableBody');
    if (!tbody) {
        if (typeof showToast === 'function') showToast('لم يتم العثور على جدول الصندوق', 'error');
        return;
    }

    // 3. اجمع HTML الجدول كاملاً — الرأس + الصفوف
    var table = tbody.closest('table');
    if (!table) {
        if (typeof showToast === 'function') showToast('الجدول غير موجود', 'error');
        return;
    }

    var tableHtml = table.outerHTML;

    // 4. عدد الصفوف الفعلي
    var count = tbody.querySelectorAll('tr').length;

    // 5. اقرأ الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 6. احفظ الحمولة
    var payload = {
        type: 'cashbox_statement',
        tableHtml: tableHtml,
        settings: settings,
        meta: {
            from: from || '—',
            to: to || '—',
            count: count
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 7. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/cashbox-statement.html';
    window.location.href = url;
}

// ================================================================
// ===== END OF CASHBOX.JS =====
// ================================================================