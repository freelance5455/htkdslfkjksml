// ================================================================
// Open Account — أدوات الوكيل الذكي (قراءة فقط) v5
// الملف: ai-agent-tools.js
// ================================================================

var AI_TOOLS_REGISTRY = {};

// ================================================================
// ===== 0. مساعدات داخلية =====
// ================================================================

function _aiNorm(s) {
    return String(s == null ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();
}

function _aiNormAr(s) {
    return _aiNorm(s)
        .replace(/\([^)]*\)/g, ' ')
        .replace(/\[[^\]]*\]/g, ' ')
        .replace(/\{[^}]*\}/g, ' ')
        .replace(/[^\p{L}\p{N}\s]/gu, ' ')
        .replace(/[أإآا]/g, 'ا')
        .replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه')
        .replace(/[\u064B-\u065F\u0670]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function _aiFuzzy(list, query, fields) {
    if (!query || !Array.isArray(list)) return { match: null, candidates: [] };
    var nq = _aiNormAr(query);
    if (!nq) return { match: null, candidates: [] };
    var candidates = list.filter(function (item) {
        return fields.some(function (f) {
            return _aiNormAr(item && item[f]).indexOf(nq) !== -1;
        });
    });
    if (!candidates.length) return { match: null, candidates: [] };
    var exact = candidates.find(function (c) {
        return fields.some(function (f) {
            return _aiNormAr(c && c[f]) === nq;
        });
    });
    return {
        match: exact || (candidates.length === 1 ? candidates[0] : null),
        candidates: candidates
    };
}

function _aiPickBest(candidates) {
    if (!candidates || !candidates.length) return null;
    var sorted = candidates.slice().sort(function (a, b) {
        var qa = parseFloat(a.quantity) || 0;
        var qb = parseFloat(b.quantity) || 0;
        if (qb !== qa) return qb - qa;
        return String(a.id).localeCompare(String(b.id));
    });
    return sorted[0];
}

function _aiFindCustomer(q) { return _aiFuzzy(customers, q, ['name', 'phone']); }
function _aiFindSupplier(q) { return _aiFuzzy(suppliers, q, ['name', 'phone']); }

function _aiFindProduct(q) {
    var result = _aiFuzzy(products, q, ['name']);
    if (result.match) return result;
    if (result.candidates.length > 1) {
        return {
            match: _aiPickBest(result.candidates),
            candidates: result.candidates,
            hasDuplicates: true
        };
    }
    return result;
}

function _aiBaseUnit(p) {
    return (p && (p.baseUnit || p.unit)) || 'وحدة';
}

function _aiNum(v) {
    var n = parseFloat(v);
    return isFinite(n) ? n : 0;
}

function _aiStr(v) {
    return v == null ? '' : String(v).trim();
}

function _aiCurrency(code) {
    var c = String(code || '').toUpperCase().trim();
    if (c === 'YER' || c === 'SAR' || c === 'USD') return c;
    return (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
}

function _aiCurrencyName(code) {
    if (typeof getCurrencyName === 'function') return getCurrencyName(code);
    return code || '';
}

function _aiArabicToNum(v) {
    if (v === null || v === undefined) return v;
    if (typeof v === 'number') return v;
    var s = String(v).trim();
    var n = parseFloat(s);
    if (isFinite(n)) return n;
    var map = {
        'صفر': 0, 'واحد': 1, 'واحدة': 1,
        'اثنان': 2, 'اثنين': 2, 'اثنتان': 2, 'اثنتين': 2,
        'ثلاثة': 3, 'ثلاث': 3, 'أربعة': 4, 'أربع': 4,
        'خمسة': 5, 'خمس': 5, 'ستة': 6, 'ست': 6,
        'سبعة': 7, 'سبع': 7, 'ثمانية': 8, 'ثماني': 8,
        'تسعة': 9, 'تسع': 9, 'عشرة': 10, 'عشر': 10,
        'عشرون': 20, 'ثلاثون': 30, 'أربعون': 40,
        'خمسون': 50, 'ستون': 60, 'سبعون': 70,
        'ثمانون': 80, 'تسعون': 90,
        'مئة': 100, 'مائة': 100, 'مئتان': 200, 'مئتين': 200,
        'ألف': 1000, 'الف': 1000
    };
    var cleaned = _aiNormAr(s);
    if (map[cleaned] !== undefined) return map[cleaned];
    var match = s.match(/\d+(\.\d+)?/);
    if (match) return parseFloat(match[0]);
    return v;
}

function _aiOk(msg, extra) {
    var r = { ok: true, message: String(msg || '') };
    if (extra && typeof extra === 'object') {
        Object.keys(extra).forEach(function (k) { r[k] = extra[k]; });
    }
    return r;
}

function _aiErr(msg) {
    return { ok: false, message: String(msg || 'خطأ') };
}

function _aiRow(l, v) {
    return '<div style="display:flex;justify-content:space-between;gap:12px;padding:6px 4px;border-bottom:1px solid rgba(255,255,255,0.06);text-align:right;">' +
        '<strong style="color:var(--color-text-2);font-size:12px;">' + esc(l) + '</strong>' +
        '<span style="font-size:13px;">' + v + '</span></div>';
}

function _aiBox(title, rows, total) {
    var h = '<div style="background:rgba(0,212,255,0.06);border:1px solid rgba(0,212,255,0.2);border-radius:10px;padding:12px;">';
    if (title) {
        h += '<div style="font-weight:700;margin-bottom:8px;color:var(--color-blue);font-size:13px;">' + esc(title) + '</div>';
    }
    rows.forEach(function (r) { h += _aiRow(r[0], r[1]); });
    if (total) {
        h += '<div style="margin-top:8px;padding-top:8px;border-top:2px solid rgba(0,212,255,0.3);display:flex;justify-content:space-between;font-weight:700;">' +
            '<span>الإجمالي:</span><span style="color:var(--color-green);">' + total + '</span></div>';
    }
    return h + '</div>';
}

// تسجيل أداة قراءة فقط (لا كتابة)
function _aiR(name, description, params, required, handler) {
    AI_TOOLS_REGISTRY[name] = {
        definition: {
            name: name,
            description: description,
            parameters: {
                type: "object",
                properties: params,
                required: required || []
            }
        },
        isWrite: false,  // ✅ دائماً false
        execute: handler,
        preview: function () { return { ok: true, requiresConfirm: false }; }
    };
}

// ================================================================
// ===== 1. ask_user =====
// ================================================================

_aiR(
    'ask_user',
    'استخدم هذه الأداة للترحيب أو الرد بنص عادي أو طلب معلومة ناقصة.',
    { message: { type: 'string' } },
    ['message'],
    function (args) {
        return _aiOk(_aiStr(args.message) || 'حاضر.');
    }
);

// ================================================================
// ===== 2. البحث الأساسي =====
// ================================================================

_aiR(
    'search_customers',
    'عرض قائمة العملاء أو البحث فيهم.',
    { query: { type: 'string' } },
    [],
    function (args) {
        var q = _aiStr(args.query);
        var list = (customers || []).filter(function (c) {
            return !q || _aiNormAr(c.name).indexOf(_aiNormAr(q)) !== -1 || String(c.phone || '').indexOf(q) !== -1;
        }).slice(0, 100).map(function (c) {
            return { id: c.id, name: c.name, phone: c.phone || '-' };
        });
        var lines = [];
        for (var i = 0; i < list.length; i++) {
            var c = list[i];
            lines.push((i + 1) + '. ' + c.name + (c.phone && c.phone !== '-' ? ' — ' + c.phone : ''));
        }
        var msg = list.length ? ('قائمة العملاء (' + list.length + '):\n' + lines.join('\n')) : 'لا يوجد عملاء.';
        return _aiOk(msg, { customers: list, count: list.length });
    }
);

_aiR(
    'search_suppliers',
    'عرض قائمة الموردين أو البحث فيهم.',
    { query: { type: 'string' } },
    [],
    function (args) {
        var q = _aiStr(args.query);
        var list = (suppliers || []).filter(function (s) {
            return !q || _aiNormAr(s.name).indexOf(_aiNormAr(q)) !== -1 || String(s.phone || '').indexOf(q) !== -1;
        }).slice(0, 100).map(function (s) {
            return { id: s.id, name: s.name, phone: s.phone || '-' };
        });
        return _aiOk('الموردون (' + list.length + ')', { suppliers: list, count: list.length });
    }
);

_aiR(
    'search_products',
    'عرض قائمة المنتجات في المستودع.',
    { query: { type: 'string' } },
    [],
    function (args) {
        var q = _aiStr(args.query);
        var list = (products || []).filter(function (p) {
            return !q || _aiNormAr(p.name).indexOf(_aiNormAr(q)) !== -1;
        }).slice(0, 100).map(function (p) {
            return {
                id: p.id,
                name: p.name,
                type: (p.type === 'finished' ? 'منتج تام' : 'مادة خام'),
                quantity: _aiNum(p.quantity),
                unit: _aiBaseUnit(p),
                price: _aiNum(p.salePrice != null ? p.salePrice : p.price)
            };
        });
        var lines = [];
        for (var i = 0; i < list.length; i++) {
            var p = list[i];
            lines.push((i + 1) + '. ' + p.name + ' — ' + p.type + ' — الكمية: ' + p.quantity + ' ' + p.unit + ' — السعر: ' + formatAmountWithCommas(p.price));
        }
        var msg = list.length ? ('قائمة المنتجات (' + list.length + '):\n' + lines.join('\n')) : 'لا توجد منتجات.';
        return _aiOk(msg, { products: list, count: list.length });
    }
);

// ================================================================
// ===== 3. لوحة التحكم =====
// ================================================================

_aiR(
    'get_dashboard_stats',
    'لقطة شاملة عن المؤسسة: الأرصدة، الذمم، المخزون.',
    {},
    [],
    function () {
        try {
            return _aiOk('لقطة الحالة', { data: calculateDashboardStats() });
        } catch (e) {
            return _aiErr('تعذر الحساب.');
        }
    }
);

_aiR(
    'get_customer_ledger',
    'كشف حساب عميل مع الرصيد.',
    { customer: { type: 'string' } },
    ['customer'],
    function (args) {
        var q = _aiStr(args.customer);
        if (!q) return _aiErr('اسم العميل مطلوب.');
        var c = _aiFindCustomer(q);
        if (!c.match) {
            if (c.candidates.length > 1) {
                return _aiErr('اسم العميل غامض: ' + c.candidates.map(function (x) { return x.name; }).join('، '));
            }
            return _aiErr('العميل غير موجود: ' + q);
        }
        var cust = c.match;
        var invs = (salesInvoices || []).filter(function (i) { return i.customerId === cust.id; });
        var recs = (receipts || []).filter(function (r) { return r.customerId === cust.id; });
        var rets = (returnsDocs || []).filter(function (r) { return r.partyId === cust.id && r.kind === 'sale'; });
        var bal = {};
        invs.forEach(function (i) {
            var cur = i.currency || 'YER';
            bal[cur] = (bal[cur] || 0) + _aiNum(i.total);
        });
        recs.forEach(function (r) {
            var cur = r.currency || 'YER';
            bal[cur] = (bal[cur] || 0) - _aiNum(r.amount);
        });
        rets.forEach(function (r) {
            var cur = r.currency || 'YER';
            bal[cur] = (bal[cur] || 0) - _aiNum(r.amount);
        });
        return _aiOk('كشف: ' + cust.name, {
            customer: cust.name,
            balances: bal,
            invoices: invs.length,
            receipts: recs.length,
            returns: rets.length
        });
    }
);

_aiR(
    'get_supplier_ledger',
    'كشف حساب مورد.',
    { supplier: { type: 'string' } },
    ['supplier'],
    function (args) {
        var q = _aiStr(args.supplier);
        if (!q) return _aiErr('اسم المورد مطلوب.');
        var s = _aiFindSupplier(q);
        if (!s.match) {
            if (s.candidates.length > 1) {
                return _aiErr('اسم المورد غامض: ' + s.candidates.map(function (x) { return x.name; }).join('، '));
            }
            return _aiErr('المورد غير موجود: ' + q);
        }
        var sup = s.match;
        var invs = (purchaseInvoices || []).filter(function (i) { return i.supplierId === sup.id; });
        var pays = (payments || []).filter(function (p) { return p.supplierId === sup.id && !p.isExpense; });
        var rets = (returnsDocs || []).filter(function (r) { return r.partyId === sup.id && r.kind === 'purchase'; });
        var bal = {};
        invs.forEach(function (i) {
            var cur = i.currency || 'YER';
            bal[cur] = (bal[cur] || 0) + _aiNum(i.total);
        });
        pays.forEach(function (p) {
            var cur = p.currency || 'YER';
            bal[cur] = (bal[cur] || 0) - _aiNum(p.amount);
        });
        rets.forEach(function (r) {
            var cur = r.currency || 'YER';
            bal[cur] = (bal[cur] || 0) - _aiNum(r.amount);
        });
        return _aiOk('كشف: ' + sup.name, {
            supplier: sup.name,
            balances: bal,
            invoices: invs.length,
            payments: pays.length,
            returns: rets.length
        });
    }
);

_aiR(
    'check_overdue_debts',
    'الديون غير المسددة على العملاء والموردين.',
    {},
    [],
    function () {
        var cust = [], supp = [];
        (customers || []).forEach(function (c) {
            var invs = (salesInvoices || []).filter(function (i) {
                return i.customerId === c.id && i.status !== 'مسدد';
            });
            if (!invs.length) return;
            var bal = 0;
            invs.forEach(function (i) {
                var paid = (receipts || []).filter(function (r) {
                    return r.invoiceId === i.id;
                }).reduce(function (s, r) { return s + _aiNum(r.amount); }, 0);
                bal += _aiNum(i.total) - paid;
            });
            if (bal > 0.0001) cust.push({ name: c.name, balance: bal });
        });
        (suppliers || []).forEach(function (s) {
            var invs = (purchaseInvoices || []).filter(function (i) {
                return i.supplierId === s.id && i.status !== 'مسدد';
            });
            if (!invs.length) return;
            var bal = 0;
            invs.forEach(function (i) {
                var paid = (payments || []).filter(function (p) {
                    return p.invoiceId === i.id && !p.isExpense;
                }).reduce(function (a, p) { return a + _aiNum(p.amount); }, 0);
                bal += _aiNum(i.total) - paid;
            });
            if (bal > 0.0001) supp.push({ name: s.name, balance: bal });
        });
        return _aiOk('الديون', { customers: cust, suppliers: supp });
    }
);

_aiR(
    'get_low_stock',
    'المنتجات منخفضة المخزون.',
    { threshold: { type: 'number' } },
    [],
    function (args) {
        var t = _aiNum(args.threshold) || 5;
        var low = (products || []).filter(function (p) {
            return _aiNum(p.quantity) < t;
        }).map(function (p) {
            return {
                name: p.name,
                quantity: _aiNum(p.quantity),
                unit: _aiBaseUnit(p)
            };
        });
        return _aiOk('منخفض المخزون', { products: low, count: low.length });
    }
);

// ================================================================
// ===== 4. البحث المتقدم في المستندات =====
// ================================================================

_aiR(
    'search_invoice',
    'البحث عن فاتورة بيع أو شراء برقمها أو اسم الطرف أو التاريخ.',
    {
        invoiceId: { type: 'string' },
        party: { type: 'string' },
        date: { type: 'string' },
        kind: { type: 'string', enum: ['sale', 'purchase'] }
    },
    [],
    function (args) {
        var id = _aiStr(args.invoiceId);
        var party = _aiStr(args.party);
        var date = _aiStr(args.date);
        var kind = args.kind || null;
        var results = [];

        var checkMatch = function(inv, type) {
            if (id && _aiNormAr(inv.id).indexOf(_aiNormAr(id)) === -1) return false;
            if (date && inv.date !== date) return false;
            if (party) {
                var name = type === 'sale' ? inv.customerName : inv.supplierName;
                if (_aiNormAr(name).indexOf(_aiNormAr(party)) === -1) return false;
            }
            return true;
        };

        if (!kind || kind === 'sale') {
            (salesInvoices || []).forEach(function(inv) {
                if (checkMatch(inv, 'sale')) results.push({
                    kind: 'بيع', id: inv.id, date: inv.date,
                    party: inv.customerName, total: inv.total,
                    currency: inv.currency, status: inv.status || inv.paymentStatus
                });
            });
        }
        if (!kind || kind === 'purchase') {
            (purchaseInvoices || []).forEach(function(inv) {
                if (checkMatch(inv, 'purchase')) results.push({
                    kind: 'شراء', id: inv.id, date: inv.date,
                    party: inv.supplierName, total: inv.total,
                    currency: inv.currency, status: inv.status || inv.paymentStatus
                });
            });
        }
        if (!results.length) return _aiOk('لم أجد فواتير مطابقة.', { results: [] });
        var lines = results.map(function(r, i) {
            return (i+1) + '. ' + r.kind + ' — ' + r.id + ' — ' + r.date + ' — ' + r.party + ' — ' + formatAmountWithCommas(r.total) + ' ' + r.currency;
        });
        return _aiOk('الفواتير المطابقة (' + results.length + '):\n' + lines.join('\n'), { results: results });
    }
);

_aiR(
    'search_voucher',
    'البحث عن سند قبض أو صرف برقمه أو اسم الطرف.',
    {
        voucherId: { type: 'string' },
        party: { type: 'string' },
        kind: { type: 'string', enum: ['receipt', 'payment'] }
    },
    [],
    function (args) {
        var id = _aiStr(args.voucherId);
        var party = _aiStr(args.party);
        var kind = args.kind || null;
        var results = [];

        var checkMatch = function(v, type) {
            if (id && _aiNormAr(v.id).indexOf(_aiNormAr(id)) === -1) return false;
            if (party) {
                var name = type === 'receipt' ? v.customerName : v.supplierName;
                if (_aiNormAr(name || '').indexOf(_aiNormAr(party)) === -1) return false;
            }
            return true;
        };

        if (!kind || kind === 'receipt') {
            (receipts || []).forEach(function(v) {
                if (checkMatch(v, 'receipt')) results.push({
                    kind: 'قبض', id: v.id, date: v.date,
                    party: v.customerName, amount: v.amount, currency: v.currency
                });
            });
        }
        if (!kind || kind === 'payment') {
            (payments || []).forEach(function(v) {
                if (v.isExpense) return;
                if (checkMatch(v, 'payment')) results.push({
                    kind: 'صرف', id: v.id, date: v.date,
                    party: v.supplierName, amount: v.amount, currency: v.currency
                });
            });
        }
        if (!results.length) return _aiOk('لم أجد سندات مطابقة.', { results: [] });
        var lines = results.map(function(r, i) {
            return (i+1) + '. ' + r.kind + ' — ' + r.id + ' — ' + r.date + ' — ' + r.party + ' — ' + formatAmountWithCommas(r.amount) + ' ' + r.currency;
        });
        return _aiOk('السندات المطابقة (' + results.length + '):\n' + lines.join('\n'), { results: results });
    }
);

_aiR(
    'find_document_by_id',
    'البحث عن أي مستند برقمه (فاتورة، سند، قيد، مرتجع).',
    { documentId: { type: 'string' } },
    ['documentId'],
    function (args) {
        var id = _aiStr(args.documentId);
        if (!id) return _aiErr('رقم المستند مطلوب.');
        var results = [];

        var inv = (salesInvoices || []).find(function(x) { return x.id === id; });
        if (inv) results.push({ kind: 'فاتورة بيع', data: inv });

        inv = (purchaseInvoices || []).find(function(x) { return x.id === id; });
        if (inv) results.push({ kind: 'فاتورة شراء', data: inv });

        var v = (receipts || []).find(function(x) { return x.id === id; });
        if (v) results.push({ kind: 'سند قبض', data: v });

        v = (payments || []).find(function(x) { return x.id === id; });
        if (v) results.push({ kind: 'سند صرف', data: v });

        v = (returnsDocs || []).find(function(x) { return x.id === id; });
        if (v) results.push({ kind: 'مرتجع', data: v });

        var je = (journalEntries || []).find(function(x) { return x.id === id; });
        if (je) results.push({ kind: 'قيد', data: je });

        var prod = (productionDocs || []).find(function(x) { return x.id === id; });
        if (prod) results.push({ kind: 'سند إنتاج', data: prod });

        if (!results.length) return _aiOk('لم أجد أي مستند بالرقم: ' + id, { results: [] });
        return _aiOk('وجدت ' + results.length + ' مستند.', { results: results });
    }
);

_aiR(
    'search_journal_entries',
    'البحث في القيود المحاسبية.',
    {
        entryId: { type: 'string' },
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        type: { type: 'string' }
    },
    [],
    function (args) {
        var id = _aiStr(args.entryId);
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var type = _aiStr(args.type);

        var results = (journalEntries || []).filter(function(e) {
            if (id && _aiNormAr(e.id).indexOf(_aiNormAr(id)) === -1) return false;
            if (from && e.date < from) return false;
            if (to && e.date > to) return false;
            if (type && e.type !== type) return false;
            return true;
        }).slice(-100);

        if (!results.length) return _aiOk('لا توجد قيود مطابقة.', { count: 0 });
        var lines = results.map(function(e, i) {
            var debit = 0, credit = 0;
            (e.lines || []).forEach(function(l) {
                debit += _aiNum(l.debit);
                credit += _aiNum(l.credit);
            });
            return (i+1) + '. ' + e.id + ' — ' + e.date + ' — ' + e.description + ' — مدين: ' + formatAmountWithCommas(debit);
        });
        return _aiOk('القيود (' + results.length + '):\n' + lines.slice(0, 30).join('\n'), { count: results.length });
    }
);

// ================================================================
// ===== 5. تحليل المبيعات والمشتريات =====
// ================================================================

_aiR(
    'analyze_sales',
    'تحليل المبيعات خلال فترة محددة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var invs = (salesInvoices || []).filter(function(i) {
            if (i.cancelled || i.status === 'ملغاة') return false;
            if (from && i.date < from) return false;
            if (to && i.date > to) return false;
            return true;
        });
        var total = 0;
        var byCurrency = {};
        var byCustomer = {};
        invs.forEach(function(i) {
            var amt = _aiNum(i.total);
            var cur = i.currency || 'SAR';
            total += amt;
            byCurrency[cur] = (byCurrency[cur] || 0) + amt;
            byCustomer[i.customerName] = (byCustomer[i.customerName] || 0) + amt;
        });
        var top = Object.keys(byCustomer).map(function(k) {
            return { name: k, total: byCustomer[k] };
        }).sort(function(a, b) { return b.total - a.total; }).slice(0, 5);

        var lines = [
            'عدد الفواتير: ' + invs.length,
            'الإجمالي: ' + formatAmountWithCommas(total),
            'العملات: ' + Object.keys(byCurrency).map(function(c) {
                return c + ': ' + formatAmountWithCommas(byCurrency[c]);
            }).join(' — '),
            'الفترة: ' + (from || 'البداية') + ' → ' + (to || 'اليوم'),
            '',
            'أعلى 5 عملاء:'
        ];
        top.forEach(function(c, i) {
            lines.push((i+1) + '. ' + c.name + ': ' + formatAmountWithCommas(c.total));
        });
        return _aiOk(lines.join('\n'), { count: invs.length, total: total, byCurrency: byCurrency });
    }
);

_aiR(
    'analyze_purchases',
    'تحليل المشتريات خلال فترة محددة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var invs = (purchaseInvoices || []).filter(function(i) {
            if (i.cancelled || i.status === 'ملغاة') return false;
            if (from && i.date < from) return false;
            if (to && i.date > to) return false;
            return true;
        });
        var total = 0;
        var byCurrency = {};
        var bySupplier = {};
        invs.forEach(function(i) {
            var amt = _aiNum(i.total);
            var cur = i.currency || 'SAR';
            total += amt;
            byCurrency[cur] = (byCurrency[cur] || 0) + amt;
            bySupplier[i.supplierName] = (bySupplier[i.supplierName] || 0) + amt;
        });
        var top = Object.keys(bySupplier).map(function(k) {
            return { name: k, total: bySupplier[k] };
        }).sort(function(a, b) { return b.total - a.total; }).slice(0, 5);

        var lines = [
            'عدد الفواتير: ' + invs.length,
            'الإجمالي: ' + formatAmountWithCommas(total),
            'العملات: ' + Object.keys(byCurrency).map(function(c) {
                return c + ': ' + formatAmountWithCommas(byCurrency[c]);
            }).join(' — '),
            'الفترة: ' + (from || 'البداية') + ' → ' + (to || 'اليوم'),
            '',
            'أعلى 5 موردين:'
        ];
        top.forEach(function(s, i) {
            lines.push((i+1) + '. ' + s.name + ': ' + formatAmountWithCommas(s.total));
        });
        return _aiOk(lines.join('\n'), { count: invs.length, total: total });
    }
);

_aiR(
    'top_products',
    'أكثر المنتجات مبيعاً.',
    { limit: { type: 'number' } },
    [],
    function (args) {
        var limit = _aiNum(args.limit) || 10;
        var sales = {};
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            (inv.items || []).forEach(function(item) {
                var key = item.name;
                if (!sales[key]) sales[key] = { qty: 0, total: 0 };
                sales[key].qty += _aiNum(item.qty);
                sales[key].total += _aiNum(item.qty) * _aiNum(item.price);
            });
        });
        var arr = Object.keys(sales).map(function(k) {
            return { name: k, qty: sales[k].qty, total: sales[k].total };
        }).sort(function(a, b) { return b.total - a.total; }).slice(0, limit);

        var lines = arr.map(function(p, i) {
            return (i+1) + '. ' + p.name + ' — ' + p.qty + ' وحدة — ' + formatAmountWithCommas(p.total);
        });
        return _aiOk('أكثر المنتجات مبيعاً (' + arr.length + '):\n' + lines.join('\n'), { products: arr });
    }
);

_aiR(
    'top_customers',
    'أكبر العملاء من حيث قيمة التعاملات.',
    { limit: { type: 'number' } },
    [],
    function (args) {
        var limit = _aiNum(args.limit) || 10;
        var totals = {};
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            var name = inv.customerName;
            totals[name] = (totals[name] || 0) + _aiNum(inv.total);
        });
        var arr = Object.keys(totals).map(function(k) {
            return { name: k, total: totals[k] };
        }).sort(function(a, b) { return b.total - a.total; }).slice(0, limit);

        var lines = arr.map(function(c, i) {
            return (i+1) + '. ' + c.name + ' — ' + formatAmountWithCommas(c.total);
        });
        return _aiOk('أكبر العملاء (' + arr.length + '):\n' + lines.join('\n'), { customers: arr });
    }
);

_aiR(
    'top_suppliers',
    'أكبر الموردين من حيث قيمة التعاملات.',
    { limit: { type: 'number' } },
    [],
    function (args) {
        var limit = _aiNum(args.limit) || 10;
        var totals = {};
        (purchaseInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            var name = inv.supplierName;
            totals[name] = (totals[name] || 0) + _aiNum(inv.total);
        });
        var arr = Object.keys(totals).map(function(k) {
            return { name: k, total: totals[k] };
        }).sort(function(a, b) { return b.total - a.total; }).slice(0, limit);

        var lines = arr.map(function(s, i) {
            return (i+1) + '. ' + s.name + ' — ' + formatAmountWithCommas(s.total);
        });
        return _aiOk('أكبر الموردين (' + arr.length + '):\n' + lines.join('\n'), { suppliers: arr });
    }
);

// ================================================================
// ===== 6. تحليل المخزون =====
// ================================================================

_aiR(
    'analyze_inventory',
    'تحليل قيمة المخزون وكمياته.',
    {},
    [],
    function () {
        var finished = [];
        var raw = [];
        var totalValue = 0;
        (products || []).forEach(function(p) {
            var qty = _aiNum(p.quantity);
            var cost = _aiNum(p.avgCost);
            var value = qty * cost;
            totalValue += value;
            var obj = {
                name: p.name, qty: qty, unit: _aiBaseUnit(p),
                avgCost: cost, value: value, currency: p.currency || 'SAR'
            };
            if ((p.type || 'finished') === 'finished') finished.push(obj);
            else raw.push(obj);
        });
        var lines = [
            'المنتجات التامة: ' + finished.length,
            'المواد الخام: ' + raw.length,
            'قيمة المخزون: ' + formatAmountWithCommas(totalValue),
            '',
            'مواد خام:'
        ];
        raw.forEach(function(p, i) {
            lines.push((i+1) + '. ' + p.name + ' — ' + p.qty + ' ' + p.unit + ' — ' + formatAmountWithCommas(p.avgCost) + '/وحدة');
        });
        return _aiOk(lines.join('\n'), { totalValue: totalValue, finished: finished.length, raw: raw.length });
    }
);

_aiR(
    'check_stock_alerts',
    'تنبيهات المخزون: منتجات نافذة، قريبة من النفاذ، أو سالبة.',
    {},
    [],
    function () {
        var outOfStock = [];
        var low = [];
        var negative = [];
        var threshold = 5;
        (products || []).forEach(function(p) {
            var qty = _aiNum(p.quantity);
            if (qty < 0) negative.push({ name: p.name, qty: qty });
            else if (qty === 0) outOfStock.push({ name: p.name });
            else if (qty < threshold) low.push({ name: p.name, qty: qty, unit: _aiBaseUnit(p) });
        });
        var lines = [];
        if (negative.length) {
            lines.push('⚠️ كميات سالبة (' + negative.length + '):');
            negative.forEach(function(p) { lines.push('• ' + p.name + ' — ' + p.qty); });
        }
        if (outOfStock.length) {
            lines.push('🔴 نافذ (' + outOfStock.length + '):');
            outOfStock.forEach(function(p) { lines.push('• ' + p.name); });
        }
        if (low.length) {
            lines.push('🟡 قريب من النفاذ (' + low.length + '):');
            low.forEach(function(p) { lines.push('• ' + p.name + ' — ' + p.qty + ' ' + p.unit); });
        }
        if (!lines.length) lines.push('✅ لا توجد تنبيهات مخزون.');
        return _aiOk(lines.join('\n'), { outOfStock: outOfStock, low: low, negative: negative });
    }
);

// ================================================================
// ===== 7. تحليل الإنتاج =====
// ================================================================

_aiR(
    'calculate_production_requirements',
    'حساب المواد الخام اللازمة لإنتاج كمية محددة.',
    {
        product: { type: 'string' },
        qty: { type: 'number' }
    },
    ['product', 'qty'],
    function (args) {
        var prodName = _aiStr(args.product);
        var targetQty = _aiNum(_aiArabicToNum(args.qty));
        if (!prodName) return _aiErr('اسم المنتج مطلوب.');
        if (targetQty <= 0) return _aiErr('الكمية مطلوبة.');
        var prod = products.find(function(p) {
            return _aiNormAr(p.name).indexOf(_aiNormAr(prodName)) !== -1;
        });
        if (!prod) return _aiErr('المنتج غير موجود: ' + prodName);
        var recipe = (bomRecipes || []).find(function(r) { return r.productId === prod.id; });
        if (!recipe) return _aiErr('لا توجد وصفة BOM لهذا المنتج.');
        var batches = targetQty / _aiNum(recipe.outputQty);
        var lines = [
            'المنتج: ' + prod.name,
            'الكمية المطلوبة: ' + targetQty + ' ' + _aiBaseUnit(prod),
            'الوصفة تنتج: ' + recipe.outputQty + ' لكل دفعة',
            'عدد الدفعات: ' + batches.toFixed(2),
            '',
            'المواد المطلوبة:'
        ];
        recipe.items.forEach(function(item) {
            var requiredQty = _aiNum(item.qty) * batches;
            var raw = products.find(function(p) { return p.id === item.productId; });
            var available = raw ? _aiNum(raw.quantity) : 0;
            var status = available >= requiredQty ? '✅ متوفر' : '❌ ناقص ' + (requiredQty - available).toFixed(2);
            lines.push('• ' + item.name + ': ' + requiredQty.toFixed(2) + ' ' + (item.unit || '') + ' — ' + status);
        });
        return _aiOk(lines.join('\n'), { product: prod.name, batches: batches });
    }
);

_aiR(
    'estimate_production_cost',
    'تقدير تكلفة إنتاج كمية محددة.',
    {
        product: { type: 'string' },
        qty: { type: 'number' }
    },
    ['product', 'qty'],
    function (args) {
        var prodName = _aiStr(args.product);
        var targetQty = _aiNum(_aiArabicToNum(args.qty));
        if (!prodName) return _aiErr('اسم المنتج مطلوب.');
        if (targetQty <= 0) return _aiErr('الكمية مطلوبة.');
        var prod = products.find(function(p) {
            return _aiNormAr(p.name).indexOf(_aiNormAr(prodName)) !== -1;
        });
        if (!prod) return _aiErr('المنتج غير موجود: ' + prodName);
        var recipe = (bomRecipes || []).find(function(r) { return r.productId === prod.id; });
        if (!recipe) return _aiErr('لا توجد وصفة BOM لهذا المنتج.');
        var batches = targetQty / _aiNum(recipe.outputQty);
        var totalCost = 0;
        var lines = [
            'المنتج: ' + prod.name,
            'الكمية: ' + targetQty,
            'التكلفة التقديرية:',
            ''
        ];
        recipe.items.forEach(function(item) {
            var raw = products.find(function(p) { return p.id === item.productId; });
            var unitCost = raw ? _aiNum(raw.avgCost) : 0;
            var requiredQty = _aiNum(item.qty) * batches;
            var cost = unitCost * requiredQty;
            totalCost += cost;
            lines.push('• ' + item.name + ': ' + requiredQty.toFixed(2) + ' × ' + formatAmountWithCommas(unitCost) + ' = ' + formatAmountWithCommas(cost));
        });
        lines.push('');
        lines.push('الإجمالي التقديري: ' + formatAmountWithCommas(totalCost) + ' ' + (getBaseCurrency() || 'SAR'));
        lines.push('تكلفة الوحدة: ' + formatAmountWithCommas(totalCost / targetQty));
        lines.push('');
        lines.push('⚠️ تقديري — يعتمد على avgCost الحالي.');
        return _aiOk(lines.join('\n'), { totalCost: totalCost });
    }
);

// ================================================================
// ===== 8. القوائم المالية =====
// ================================================================

_aiR(
    'get_trial_balance',
    'ميزان المراجعة.',
    {},
    [],
    function () {
        var accounts = {};
        (journalEntries || []).forEach(function(e) {
            (e.lines || []).forEach(function(l) {
                var code = l.accountCode;
                if (!accounts[code]) accounts[code] = { name: l.accountName, debit: 0, credit: 0 };
                accounts[code].debit += _aiNum(l.debit);
                accounts[code].credit += _aiNum(l.credit);
            });
        });
        var lines = [];
        var totalD = 0, totalC = 0;
        Object.keys(accounts).sort().forEach(function(code) {
            var a = accounts[code];
            totalD += a.debit;
            totalC += a.credit;
            lines.push(code + ' ' + a.name + ' — مدين: ' + formatAmountWithCommas(a.debit) + ' — دائن: ' + formatAmountWithCommas(a.credit));
        });
        lines.push('');
        lines.push('إجمالي المدين: ' + formatAmountWithCommas(totalD));
        lines.push('إجمالي الدائن: ' + formatAmountWithCommas(totalC));
        lines.push('الفرق: ' + formatAmountWithCommas(totalD - totalC));
        return _aiOk(lines.join('\n'), { totalD: totalD, totalC: totalC });
    }
);

_aiR(
    'get_profit_loss',
    'قائمة الأرباح والخسائر.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var sales = 0, purchases = 0, cogs = 0, expenses = 0, returns = 0;
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            if (from && inv.date < from) return;
            if (to && inv.date > to) return;
            sales += _aiNum(inv.total);
            cogs += _aiNum(inv.cogsTotal);
        });
        (purchaseInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            if (from && inv.date < from) return;
            if (to && inv.date > to) return;
            purchases += _aiNum(inv.total);
        });
        (expenses || []).forEach(function(e) {
            if (from && e.date < from) return;
            if (to && e.date > to) return;
            expenses += _aiNum(e.amount);
        });
        (returnsDocs || []).forEach(function(r) {
            if (r.cancelled) return;
            if (r.kind !== 'sale') return;
            if (from && r.date < from) return;
            if (to && r.date > to) return;
            returns += _aiNum(r.amount);
        });
        var netSales = sales - returns;
        var grossProfit = netSales - cogs;
        var netProfit = grossProfit - expenses;
        var lines = [
            'المبيعات: ' + formatAmountWithCommas(sales),
            'المرتجعات: ' + formatAmountWithCommas(returns),
            'صافي المبيعات: ' + formatAmountWithCommas(netSales),
            'المشتريات: ' + formatAmountWithCommas(purchases),
            'COGS: ' + formatAmountWithCommas(cogs),
            'مجمل الربح: ' + formatAmountWithCommas(grossProfit),
            'المصاريف: ' + formatAmountWithCommas(expenses),
            'صافي الربح: ' + formatAmountWithCommas(netProfit),
            '',
            'الفترة: ' + (from || 'البداية') + ' → ' + (to || 'اليوم')
        ];
        return _aiOk(lines.join('\n'), { sales: sales, cogs: cogs, netProfit: netProfit });
    }
);

// ================================================================
// ===== 9. التدقيق المحاسبي =====
// ================================================================

_aiR(
    'get_audit_issues',
    'قراءة نتائج التدقيق المحاسبي مع الأسباب.',
    {},
    [],
    function () {
        if (typeof runAudit !== 'function') {
            return _aiErr('دالة التدقيق غير متوفرة.');
        }
        try {
            // نحفظ الحالة الحالية
            var prevState = window._auditState ? JSON.parse(JSON.stringify(window._auditState)) : null;
            
            // نشغل التدقيق
            runAudit();
            
            var state = window._auditState || { errors: [], warnings: [], infos: [] };
            
            var lines = [];
            lines.push('🔴 أخطاء: ' + state.errors.length);
            lines.push('🟡 تحذيرات: ' + state.warnings.length);
            lines.push('🔵 معلومات: ' + state.infos.length);
            lines.push('');
            
            if (state.errors.length) {
                lines.push('=== الأخطاء ===');
                state.errors.slice(0, 10).forEach(function(e, i) {
                    lines.push((i+1) + '. ' + e.title);
                    lines.push('   الكود: ' + e.code);
                    if (e.description) lines.push('   ' + e.description);
                    if (e.details) lines.push('   ' + e.details);
                });
            }
            
            if (state.warnings.length) {
                lines.push('');
                lines.push('=== التحذيرات ===');
                state.warnings.slice(0, 10).forEach(function(w, i) {
                    lines.push((i+1) + '. ' + w.title);
                    lines.push('   الكود: ' + w.code);
                    if (w.description) lines.push('   ' + w.description);
                    if (w.details) lines.push('   ' + w.details);
                });
            }
            
            // نعيد الحالة السابقة
            if (prevState) window._auditState = prevState;
            
            return _aiOk(lines.join('\n'), {
                errors: state.errors.length,
                warnings: state.warnings.length,
                infos: state.infos.length
            });
        } catch (e) {
            return _aiErr('فشل التدقيق: ' + (e.message || e));
        }
    }
);

_aiR(
    'detect_unlinked_invoices',
    'اكتشاف الفواتير التي لا يوجد لها قيد محاسبي.',
    {},
    [],
    function () {
        var unlinked = [];
        
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            var entry = (journalEntries || []).find(function(e) {
                return e.referenceId === inv.id && e.referenceType === 'sales_invoice';
            });
            if (!entry) unlinked.push({
                kind: 'فاتورة بيع', id: inv.id, date: inv.date, total: inv.total
            });
        });
        
        (purchaseInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            var entry = (journalEntries || []).find(function(e) {
                return e.referenceId === inv.id && e.referenceType === 'purchase_invoice';
            });
            if (!entry) unlinked.push({
                kind: 'فاتورة شراء', id: inv.id, date: inv.date, total: inv.total
            });
        });
        
        if (!unlinked.length) return _aiOk('✅ كل الفواتير مرتبطة بقيود.', { count: 0 });
        
        var lines = ['⚠️ فواتير بدون قيود (' + unlinked.length + '):'];
        unlinked.slice(0, 20).forEach(function(u, i) {
            lines.push((i+1) + '. ' + u.kind + ' — ' + u.id + ' — ' + u.date + ' — ' + formatAmountWithCommas(u.total));
        });
        return _aiOk(lines.join('\n'), { count: unlinked.length, unlinked: unlinked });
    }
);

_aiR(
    'detect_unbalanced_entries',
    'اكتشاف القيود غير المتوازنة.',
    {},
    [],
    function () {
        var unbalanced = [];
        (journalEntries || []).forEach(function(e) {
            var debit = 0, credit = 0;
            (e.lines || []).forEach(function(l) {
                debit += _aiNum(l.debit);
                credit += _aiNum(l.credit);
            });
            if (Math.abs(debit - credit) > 0.01) {
                unbalanced.push({
                    id: e.id, date: e.date, debit: debit, credit: credit,
                    diff: debit - credit
                });
            }
        });
        if (!unbalanced.length) return _aiOk('✅ كل القيود متوازنة.', { count: 0 });
        var lines = ['⚠️ قيود غير متوازنة (' + unbalanced.length + '):'];
        unbalanced.forEach(function(e, i) {
            lines.push((i+1) + '. ' + e.id + ' — ' + e.date + ' — الفرق: ' + formatAmountWithCommas(e.diff));
        });
        return _aiOk(lines.join('\n'), { count: unbalanced.length, entries: unbalanced });
    }
);

_aiR(
    'audit_inventory_values',
    'مقارنة قيمة المخزون التفصيلية مع حساب 1200.',
    {},
    [],
    function () {
        var detailValue = 0;
        (products || []).forEach(function(p) {
            detailValue += _aiNum(p.quantity) * _aiNum(p.avgCost);
        });
        
        var glValue = 0;
        (journalEntries || []).forEach(function(e) {
            (e.lines || []).forEach(function(l) {
                if (l.accountCode === '1200') {
                    glValue += _aiNum(l.debit) - _aiNum(l.credit);
                }
            });
        });
        
        var diff = detailValue - glValue;
        var lines = [
            'قيمة المخزون التفصيلية: ' + formatAmountWithCommas(detailValue),
            'قيمة حساب 1200 (الأستاذ): ' + formatAmountWithCommas(glValue),
            'الفرق: ' + formatAmountWithCommas(diff),
            ''
        ];
        if (Math.abs(diff) < 0.01) {
            lines.push('✅ مطابقة تامة.');
        } else {
            lines.push('⚠️ يوجد فرق يحتاج مراجعة.');
        }
        return _aiOk(lines.join('\n'), { detail: detailValue, gl: glValue, diff: diff });
    }
);

_aiR(
    'audit_consistency',
    'فحص شامل لاتساق النظام.',
    {},
    [],
    function () {
        var issues = [];
        
        // 1. فواتير بدون قيود
        var unlinkedInv = 0;
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            if (!(journalEntries || []).some(function(e) {
                return e.referenceId === inv.id && e.referenceType === 'sales_invoice';
            })) unlinkedInv++;
        });
        (purchaseInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            if (!(journalEntries || []).some(function(e) {
                return e.referenceId === inv.id && e.referenceType === 'purchase_invoice';
            })) unlinkedInv++;
        });
        if (unlinkedInv > 0) issues.push('• فواتير بدون قيود: ' + unlinkedInv);
        
        // 2. قيود غير متوازنة
        var unbalanced = 0;
        (journalEntries || []).forEach(function(e) {
            var d = 0, c = 0;
            (e.lines || []).forEach(function(l) {
                d += _aiNum(l.debit);
                c += _aiNum(l.credit);
            });
            if (Math.abs(d - c) > 0.01) unbalanced++;
        });
        if (unbalanced > 0) issues.push('• قيود غير متوازنة: ' + unbalanced);
        
        // 3. مخزون سالب
        var negativeStock = 0;
        (products || []).forEach(function(p) {
            if (_aiNum(p.quantity) < 0) negativeStock++;
        });
        if (negativeStock > 0) issues.push('• منتجات بمخزون سالب: ' + negativeStock);
        
        // 4. مخزون تفصيلي ≠ 1200
        var detailValue = 0;
        (products || []).forEach(function(p) {
            detailValue += _aiNum(p.quantity) * _aiNum(p.avgCost);
        });
        var glValue = 0;
        (journalEntries || []).forEach(function(e) {
            (e.lines || []).forEach(function(l) {
                if (l.accountCode === '1200') {
                    glValue += _aiNum(l.debit) - _aiNum(l.credit);
                }
            });
        });
        if (Math.abs(detailValue - glValue) > 0.01) {
            issues.push('• فرق المخزون: ' + formatAmountWithCommas(detailValue - glValue));
        }
        
        // 5. مستندات معلّقة
        var danglingReturns = 0;
        (returnsDocs || []).forEach(function(r) {
            if (r.kind === 'sale') {
                if (!(salesInvoices || []).some(function(i) { return i.id === r.invoiceId; })) danglingReturns++;
            } else {
                if (!(purchaseInvoices || []).some(function(i) { return i.id === r.invoiceId; })) danglingReturns++;
            }
        });
        if (danglingReturns > 0) issues.push('• مرتجعات بفواتير مفقودة: ' + danglingReturns);
        
        if (!issues.length) {
            return _aiOk('✅ النظام متسق — لا توجد مشاكل.', { issues: [] });
        }
        return _aiOk('⚠️ مشاكل الاتساق (' + issues.length + '):\n' + issues.join('\n'), { issues: issues });
    }
);

// ================================================================
// ===== 10. تحليل الفترات =====
// ================================================================

_aiR(
    'compare_periods',
    'مقارنة المبيعات أو المشتريات بين فترتين.',
    {
        metric: { type: 'string', enum: ['sales', 'purchases'] },
        period1From: { type: 'string' },
        period1To: { type: 'string' },
        period2From: { type: 'string' },
        period2To: { type: 'string' }
    },
    ['metric', 'period1From', 'period1To', 'period2From', 'period2To'],
    function (args) {
        var metric = args.metric === 'purchases' ? 'purchases' : 'sales';
        var list = metric === 'sales' ? (salesInvoices || []) : (purchaseInvoices || []);
        
        var sum = function(from, to) {
            return list.filter(function(i) {
                if (i.cancelled) return false;
                if (from && i.date < from) return false;
                if (to && i.date > to) return false;
                return true;
            }).reduce(function(s, i) { return s + _aiNum(i.total); }, 0);
        };
        
        var p1 = sum(args.period1From, args.period1To);
        var p2 = sum(args.period2From, args.period2To);
        var diff = p2 - p1;
        var pct = p1 > 0 ? (diff / p1 * 100) : 0;
        
        var label = metric === 'sales' ? 'المبيعات' : 'المشتريات';
        var lines = [
            label + ':',
            'الفترة 1 (' + args.period1From + ' → ' + args.period1To + '): ' + formatAmountWithCommas(p1),
            'الفترة 2 (' + args.period2From + ' → ' + args.period2To + '): ' + formatAmountWithCommas(p2),
            'الفرق: ' + formatAmountWithCommas(diff) + ' (' + pct.toFixed(1) + '%)',
            diff > 0 ? '📈 زيادة' : diff < 0 ? '📉 انخفاض' : '— ثابت'
        ];
        return _aiOk(lines.join('\n'), { p1: p1, p2: p2, diff: diff, pct: pct });
    }
);

// ================================================================
// ===== 11. أعمار الديون =====
// ================================================================

_aiR(
    'get_aging_report',
    'تحليل أعمار الديون (0-30، 31-60، 61-90، +90 يوم).',
    {},
    [],
    function () {
        var today = todayISO();
        var todayTime = new Date(today).getTime();
        var brackets = { '0-30': 0, '31-60': 0, '61-90': 0, '90+': 0 };
        var details = [];
        
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            var paid = (receipts || []).filter(function(r) { return r.invoiceId === inv.id; })
                .reduce(function(s, r) { return s + _aiNum(r.amount); }, 0);
            var outstanding = _aiNum(inv.total) - paid;
            if (outstanding <= 0.01) return;
            
            var invTime = new Date(inv.date).getTime();
            var days = Math.floor((todayTime - invTime) / (1000 * 60 * 60 * 24));
            var bracket = days <= 30 ? '0-30' : days <= 60 ? '31-60' : days <= 90 ? '61-90' : '90+';
            brackets[bracket] += outstanding;
            details.push({
                id: inv.id, customer: inv.customerName, date: inv.date,
                days: days, outstanding: outstanding, currency: inv.currency
            });
        });
        
        var lines = [
            'أعمار الديون:',
            '0-30 يوم: ' + formatAmountWithCommas(brackets['0-30']),
            '31-60 يوم: ' + formatAmountWithCommas(brackets['31-60']),
            '61-90 يوم: ' + formatAmountWithCommas(brackets['61-90']),
            '+90 يوم: ' + formatAmountWithCommas(brackets['90+']),
            '',
            'إجمالي: ' + formatAmountWithCommas(brackets['0-30'] + brackets['31-60'] + brackets['61-90'] + brackets['90+'])
        ];
        return _aiOk(lines.join('\n'), { brackets: brackets, details: details });
    }
);

// ================================================================
// ===== 12. الزكاة =====
// ================================================================

_aiR(
    'get_zakat_calculation',
    'حساب الزكاة بناءً على الأصول المتاحة.',
    { rate: { type: 'number' } },
    [],
    function (args) {
        var rate = _aiNum(args.rate) || 2.5;
        
        // حساب الصندوق والبنك من القيود
        var cash = 0, bank = 0;
        (journalEntries || []).forEach(function(e) {
            (e.lines || []).forEach(function(l) {
                if (l.accountCode === '1000') cash += _aiNum(l.debit) - _aiNum(l.credit);
                if (l.accountCode === '1010') bank += _aiNum(l.debit) - _aiNum(l.credit);
            });
        });
        
        // المواد الخام والمنتجات التامة
        var rawValue = 0, finishedValue = 0;
        (products || []).forEach(function(p) {
            var val = _aiNum(p.quantity) * _aiNum(p.avgCost);
            if ((p.type || 'finished') === 'finished') finishedValue += val;
            else rawValue += val;
        });
        
        // العملاء (لك عند العملاء)
        var receivables = 0;
        (journalEntries || []).forEach(function(e) {
            (e.lines || []).forEach(function(l) {
                if (l.accountCode === '1100') receivables += _aiNum(l.debit) - _aiNum(l.credit);
            });
        });
        if (receivables < 0) receivables = 0;
        
        var base = cash + bank + rawValue + finishedValue + receivables;
        var zakat = base * (rate / 100);
        
        var lines = [
            'الصندوق: ' + formatAmountWithCommas(cash),
            'البنك: ' + formatAmountWithCommas(bank),
            'المواد الخام: ' + formatAmountWithCommas(rawValue),
            'المنتجات التامة: ' + formatAmountWithCommas(finishedValue),
            'الذمم المدينة: ' + formatAmountWithCommas(receivables),
            'وعاء الزكاة: ' + formatAmountWithCommas(base),
            'النسبة: ' + rate + '%',
            'الزكاة: ' + formatAmountWithCommas(zakat),
            '',
            '⚠️ حساب تقديري — يعتمد على بيانات النظام.'
        ];
        return _aiOk(lines.join('\n'), { base: base, zakat: zakat, rate: rate });
    }
);

// ================================================================
// ===== 13. التوقع =====
// ================================================================

_aiR(
    'predict_demand',
    'توقع الطلب على منتج بناءً على سجل المبيعات.',
    { product: { type: 'string' } },
    ['product'],
    function (args) {
        var prodName = _aiStr(args.product);
        if (!prodName) return _aiErr('اسم المنتج مطلوب.');
        
        var sales = [];
        (salesInvoices || []).forEach(function(inv) {
            if (inv.cancelled) return;
            (inv.items || []).forEach(function(item) {
                if (_aiNormAr(item.name).indexOf(_aiNormAr(prodName)) !== -1) {
                    sales.push({
                        date: inv.date,
                        qty: _aiNum(item.qty),
                        customer: inv.customerName
                    });
                }
            });
        });
        
        if (!sales.length) return _aiOk('لا توجد مبيعات سابقة لهذا المنتج — لا يمكن التوقع.', { count: 0 });
        
        var totalQty = sales.reduce(function(s, x) { return s + x.qty; }, 0);
        var avgQty = totalQty / sales.length;
        
        // حساب الفترة
        var dates = sales.map(function(s) { return new Date(s.date).getTime(); });
        var minDate = Math.min.apply(null, dates);
        var maxDate = Math.max.apply(null, dates);
        var days = Math.max(1, Math.floor((maxDate - minDate) / (1000 * 60 * 60 * 24)));
        var dailyAvg = totalQty / days;
        
        var lines = [
            'المنتج: ' + prodName,
            'عدد المبيعات: ' + sales.length,
            'إجمالي الكمية: ' + totalQty,
            'المتوسط لكل عملية: ' + avgQty.toFixed(2),
            'المدة: ' + days + ' يوم',
            'المعدل اليومي: ' + dailyAvg.toFixed(2),
            '',
            'التوقع (7 أيام): ' + (dailyAvg * 7).toFixed(2),
            'التوقع (30 يوم): ' + (dailyAvg * 30).toFixed(2),
            '',
            '⚠️ توقع تقريبي — يعتمد على المعدل التاريخي.'
        ];
        return _aiOk(lines.join('\n'), { avgQty: avgQty, dailyAvg: dailyAvg });
    }
);

_aiR(
    'predict_customer_demand',
    'توقع متى سيطلب عميل معين بناءً على سجله.',
    { customer: { type: 'string' } },
    ['customer'],
    function (args) {
        var custName = _aiStr(args.customer);
        if (!custName) return _aiErr('اسم العميل مطلوب.');
        var c = _aiFindCustomer(custName);
        if (!c.match) return _aiErr('العميل غير موجود: ' + custName);
        
        var invs = (salesInvoices || []).filter(function(i) { return i.customerId === c.match.id && !i.cancelled; });
        if (!invs.length) return _aiOk('لا توجد فواتير لهذا العميل.', { count: 0 });
        
        invs.sort(function(a, b) { return String(a.date).localeCompare(String(b.date)); });
        
        // حساب الفواصل بين الطلبات
        var intervals = [];
        for (var i = 1; i < invs.length; i++) {
            var d1 = new Date(invs[i-1].date).getTime();
            var d2 = new Date(invs[i].date).getTime();
            intervals.push(Math.floor((d2 - d1) / (1000 * 60 * 60 * 24)));
        }
        
        var avgInterval = intervals.length ? intervals.reduce(function(s, x) { return s + x; }, 0) / intervals.length : 0;
        var lastDate = invs[invs.length - 1].date;
        var lastTime = new Date(lastDate).getTime();
        var today = new Date(todayISO()).getTime();
        var daysSince = Math.floor((today - lastTime) / (1000 * 60 * 60 * 24));
        var daysUntilNext = Math.max(0, avgInterval - daysSince);
        
        var lines = [
            'العميل: ' + c.match.name,
            'عدد الفواتير: ' + invs.length,
            'آخر طلب: ' + lastDate + ' (قبل ' + daysSince + ' يوم)',
            'متوسط الفاصل: ' + avgInterval.toFixed(1) + ' يوم',
            '',
            'التوقع: ' + (daysUntilNext > 0 ? 'خلال ' + Math.round(daysUntilNext) + ' يوم' : 'متوقع الآن'),
            '',
            '⚠️ توقع تقريبي.'
        ];
        return _aiOk(lines.join('\n'), { avgInterval: avgInterval, daysUntilNext: daysUntilNext });
    }
);

// ================================================================
// ===== 14. الواجهة العامة =====
// ================================================================

function aiGetToolDefinitions() {
    var arr = [];
    Object.keys(AI_TOOLS_REGISTRY).forEach(function (name) {
        arr.push({
            type: "function",
            function: AI_TOOLS_REGISTRY[name].definition
        });
    });
    return arr;
}

function aiPreviewTool(name, args) {
    var tool = AI_TOOLS_REGISTRY[name];
    if (!tool) return { ok: false, message: 'الأداة غير معروفة: ' + name };
    try {
        return tool.preview(args || {});
    } catch (e) {
        return { ok: false, message: 'خطأ: ' + (e.message || e) };
    }
}

function aiExecuteTool(name, args) {
    var tool = AI_TOOLS_REGISTRY[name];
    if (!tool) return _aiErr('الأداة غير معروفة: ' + name);
    // ✅ حماية إضافية: منع أي أداة تحمل isWrite = true
    if (tool.isWrite === true) {
        return _aiErr('❌ هذه الأداة للقراءة فقط — غير مسموح بالكتابة.');
    }
    try {
        return tool.execute(args || {});
    } catch (e) {
        return _aiErr('خطأ: ' + (e.message || e));
    }
}
// ================================================================
// ===== 15. أدوات قراءة شاملة — الدفعة 1 =====
// ================================================================

_aiR(
    'list_all_products',
    'قائمة كل المنتجات مع إمكانية الفلترة حسب النوع أو البحث بالاسم.',
    {
        type: { type: 'string', enum: ['finished', 'raw', 'all'] },
        query: { type: 'string' }
    },
    [],
    function (args) {
        var type = args.type || 'all';
        var q = _aiStr(args.query);
        var list = (products || []).filter(function (p) {
            if (type !== 'all') {
                var pt = p.type || p.productType || 'raw';
                if (pt !== type) return false;
            }
            if (q && _aiNormAr(p.name).indexOf(_aiNormAr(q)) === -1) return false;
            return true;
        }).map(function (p) {
            return {
                id: p.id,
                name: p.name,
                type: (p.type === 'finished' ? 'منتج تام' : 'مادة خام'),
                quantity: _aiNum(p.quantity),
                unit: _aiBaseUnit(p),
                salePrice: _aiNum(p.salePrice != null ? p.salePrice : p.price),
                avgCost: _aiNum(p.avgCost),
                currency: p.currency || 'SAR'
            };
        });
        var lines = list.slice(0, 100).map(function (p, i) {
            return (i + 1) + '. ' + p.name + ' — ' + p.type + ' — كمية: ' + p.quantity + ' ' + p.unit + ' — سعر: ' + formatAmountWithCommas(p.salePrice);
        });
        return _aiOk('المنتجات (' + list.length + '):\n' + lines.join('\n'), { products: list, count: list.length });
    }
);

_aiR(
    'get_product_details',
    'تفاصيل منتج واحد بالاسم أو الرقم.',
    {
        product: { type: 'string' }
    },
    ['product'],
    function (args) {
        var q = _aiStr(args.product);
        if (!q) return _aiErr('اسم المنتج أو رقمه مطلوب.');
        var p = products.find(function (x) {
            return x.id === q || _aiNormAr(x.name).indexOf(_aiNormAr(q)) !== -1;
        });
        if (!p) return _aiErr('المنتج غير موجود: ' + q);
        var lines = [
            'الاسم: ' + p.name,
            'الرقم: ' + p.id,
            'النوع: ' + (p.type === 'finished' ? 'منتج تام' : 'مادة خام'),
            'الكمية: ' + _aiNum(p.quantity) + ' ' + _aiBaseUnit(p),
            'سعر البيع: ' + formatAmountWithCommas(p.salePrice != null ? p.salePrice : p.price),
            'متوسط التكلفة: ' + formatAmountWithCommas(p.avgCost),
            'العملة: ' + (p.currency || 'SAR')
        ];
        return _aiOk(lines.join('\n'), { product: p });
    }
);

_aiR(
    'get_cashbox_balance',
    'رصيد الصندوق الحالي (كل العملات).',
    {},
    [],
    function () {
        var balances = {};
        if (typeof getCashboxTransactions === 'function') {
            var txs = getCashboxTransactions();
            txs.forEach(function (t) {
                var c = t.currency || 'SAR';
                if (!balances[c]) balances[c] = 0;
                if (t.type === 'in') balances[c] += _aiNum(t.amount);
                else balances[c] -= _aiNum(t.amount);
            });
        }
        var lines = [];
        var total = 0;
        ['YER', 'SAR', 'USD'].forEach(function (c) {
            if (balances[c] && Math.abs(balances[c]) > 0.001) {
                lines.push(c + ': ' + formatAmountWithCommas(balances[c]));
                total += balances[c];
            }
        });
        if (!lines.length) lines.push('لا توجد حركات — الرصيد صفر.');
        return _aiOk('رصيد الصندوق:\n' + lines.join('\n'), { balances: balances });
    }
);

_aiR(
    'get_bank_balance',
    'رصيد البنك الحالي (كل العملات).',
    {},
    [],
    function () {
        var balances = {};
        if (typeof getBankTransactions === 'function') {
            var txs = getBankTransactions();
            txs.forEach(function (t) {
                var c = t.currency || 'SAR';
                if (!balances[c]) balances[c] = 0;
                if (t.type === 'in') balances[c] += _aiNum(t.amount);
                else balances[c] -= _aiNum(t.amount);
            });
        }
        var lines = [];
        ['YER', 'SAR', 'USD'].forEach(function (c) {
            if (balances[c] && Math.abs(balances[c]) > 0.001) {
                lines.push(c + ': ' + formatAmountWithCommas(balances[c]));
            }
        });
        if (!lines.length) lines.push('لا توجد حركات — الرصيد صفر.');
        return _aiOk('رصيد البنك:\n' + lines.join('\n'), { balances: balances });
    }
);

_aiR(
    'get_cashbox_transactions',
    'حركات الصندوق خلال فترة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        if (typeof getCashboxTransactions !== 'function') {
            return _aiErr('دالة حركات الصندوق غير متوفرة.');
        }
        var txs = getCashboxTransactions().filter(function (t) {
            if (from && t.date < from) return false;
            if (to && t.date > to) return false;
            return true;
        });
        if (!txs.length) return _aiOk('لا توجد حركات في الفترة.');
        var lines = txs.slice(0, 50).map(function (t, i) {
            return (i + 1) + '. ' + t.date + ' — ' + t.desc + ' — ' +
                (t.type === 'in' ? 'وارد: +' : 'صادر: -') +
                formatAmountWithCommas(t.amount) + ' ' + (t.currency || '');
        });
        return _aiOk('حركات الصندوق (' + txs.length + '):\n' + lines.join('\n'), { count: txs.length });
    }
);

_aiR(
    'get_bank_transactions',
    'حركات البنك خلال فترة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        if (typeof getBankTransactions !== 'function') {
            return _aiErr('دالة حركات البنك غير متوفرة.');
        }
        var txs = getBankTransactions().filter(function (t) {
            if (from && t.date < from) return false;
            if (to && t.date > to) return false;
            return true;
        });
        if (!txs.length) return _aiOk('لا توجد حركات في الفترة.');
        var lines = txs.slice(0, 50).map(function (t, i) {
            return (i + 1) + '. ' + t.date + ' — ' + t.desc + ' — ' +
                (t.type === 'in' ? 'إيداع: +' : 'سحب: -') +
                formatAmountWithCommas(t.amount) + ' ' + (t.currency || '');
        });
        return _aiOk('حركات البنك (' + txs.length + '):\n' + lines.join('\n'), { count: txs.length });
    }
);

_aiR(
    'get_company_settings',
    'إعدادات المؤسسة (الاسم، العنوان، الهاتف، العملة الأساسية).',
    {},
    [],
    function () {
        var s = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
        var lines = [
            'الاسم: ' + (s.name || '—'),
            'العنوان: ' + (s.address || '—'),
            'الهاتف: ' + (s.phone || '—'),
            'البريد: ' + (s.email || '—'),
            'العملة الأساسية: ' + (s.baseCurrency || (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'SAR'))
        ];
        return _aiOk(lines.join('\n'), { settings: s });
    }
);

_aiR(
    'get_currency_rates',
    'أسعار الصرف الحالية.',
    {},
    [],
    function () {
        var rates = Storage.get('oa_exchange_rates', {}) || {};
        var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
        var lines = ['العملة الأساسية: ' + base];
        Object.keys(rates).forEach(function (c) {
            if (c !== base) {
                lines.push('1 ' + c + ' = ' + formatAmountWithCommas(rates[c]) + ' ' + base);
            }
        });
        return _aiOk(lines.join('\n'), { rates: rates, base: base });
    }
);

_aiR(
    'get_all_accounts',
    'دليل الحسابات المحاسبية مع الأرصدة.',
    {},
    [],
    function () {
        var ACCOUNTS_MAP = {
            '1000': 'الصندوق',
            '1010': 'البنك',
            '1100': 'العملاء',
            '1200': 'المخزون',
            '2000': 'الموردين',
            '3000': 'رأس المال',
            '4000': 'إيرادات المبيعات',
            '4010': 'مردودات المبيعات',
            '4100': 'إيرادات أخرى',
            '4200': 'أرباح فروقات العملة',
            '5000': 'تكلفة المبيعات COGS',
            '6000': 'المصاريف',
            '7000': 'خسائر فروقات العملة'
        };
        var balances = {};
        (journalEntries || []).forEach(function (e) {
            (e.lines || []).forEach(function (l) {
                var code = l.accountCode;
                if (!balances[code]) balances[code] = { debit: 0, credit: 0 };
                balances[code].debit += _aiNum(l.debit);
                balances[code].credit += _aiNum(l.credit);
            });
        });
        var lines = [];
        Object.keys(ACCOUNTS_MAP).forEach(function (code) {
            var b = balances[code] || { debit: 0, credit: 0 };
            var net = b.debit - b.credit;
            lines.push(code + ' — ' + ACCOUNTS_MAP[code] + ' — مدين: ' + formatAmountWithCommas(b.debit) + ' — دائن: ' + formatAmountWithCommas(b.credit) + ' — صافي: ' + formatAmountWithCommas(net));
        });
        return _aiOk('دليل الحسابات:\n' + lines.join('\n'), { balances: balances });
    }
);

_aiR(
    'get_system_summary',
    'ملخص شامل للنظام: عدد السجلات في كل جدول.',
    {},
    [],
    function () {
        var lines = [
            'المنتجات: ' + (products || []).length,
            'العملاء: ' + (customers || []).length,
            'الموردون: ' + (suppliers || []).length,
            'فواتير البيع: ' + (salesInvoices || []).length,
            'فواتير الشراء: ' + (purchaseInvoices || []).length,
            'سندات القبض: ' + (receipts || []).length,
            'سندات الصرف: ' + (payments || []).length,
            'المصاريف: ' + (expenses || []).length,
            'المرتجعات: ' + (returnsDocs || []).length,
            'القيود: ' + (journalEntries || []).length,
            'حركات المخزون: ' + (stockMovements || []).length,
            'التحويلات: ' + (transfers || []).length,
            'سندات الإنتاج: ' + (productionDocs || []).length,
            'وصفات BOM: ' + (bomRecipes || []).length,
            'الحركات المباشرة: ' + (directTransactions || []).length
        ];
        return _aiOk('ملخص النظام:\n' + lines.join('\n'), {});
    }
);
// ================================================================
// ===== 16. أدوات قراءة شاملة — الدفعة 2 =====
// ================================================================

_aiR(
    'list_journal_entries',
    'قائمة القيود المحاسبية بفلترة حسب التاريخ والنوع.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        type: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var type = _aiStr(args.type);
        var limit = _aiNum(args.limit) || 50;

        var filtered = (journalEntries || []).filter(function (e) {
            if (from && e.date < from) return false;
            if (to && e.date > to) return false;
            if (type && e.type !== type) return false;
            return true;
        });
        filtered.sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
        filtered = filtered.slice(0, limit);

        if (!filtered.length) return _aiOk('لا توجد قيود مطابقة.');

        var lines = filtered.map(function (e, i) {
            var debit = 0, credit = 0;
            (e.lines || []).forEach(function (l) {
                debit += _aiNum(l.debit);
                credit += _aiNum(l.credit);
            });
            return (i + 1) + '. ' + e.id + ' — ' + e.date + ' — ' + e.description +
                ' — مدين: ' + formatAmountWithCommas(debit) + ' — دائن: ' + formatAmountWithCommas(credit) +
                ' — ' + (e.currency || '');
        });
        return _aiOk('القيود (' + filtered.length + '):\n' + lines.join('\n'), { count: filtered.length });
    }
);

_aiR(
    'get_journal_entry_details',
    'تفاصيل قيد واحد بكل سطوره.',
    {
        entryId: { type: 'string' }
    },
    ['entryId'],
    function (args) {
        var id = _aiStr(args.entryId);
        if (!id) return _aiErr('رقم القيد مطلوب.');
        var e = (journalEntries || []).find(function (x) { return x.id === id; });
        if (!e) return _aiErr('القيد غير موجود: ' + id);
        var lines = [
            'رقم القيد: ' + e.id,
            'التاريخ: ' + e.date,
            'النوع: ' + (e.type || '—'),
            'البيان: ' + (e.description || '—'),
            'العملة: ' + (e.currency || '—'),
            'المرجع: ' + (e.referenceId || '—'),
            'نوع المرجع: ' + (e.referenceType || '—'),
            '',
            'السطور:'
        ];
        var totalD = 0, totalC = 0;
        (e.lines || []).forEach(function (l, i) {
            totalD += _aiNum(l.debit);
            totalC += _aiNum(l.credit);
            lines.push((i + 1) + '. ' + (l.accountCode || '') + ' — ' + (l.accountName || '') +
                ' — مدين: ' + formatAmountWithCommas(l.debit) +
                ' — دائن: ' + formatAmountWithCommas(l.credit));
        });
        lines.push('');
        lines.push('إجمالي المدين: ' + formatAmountWithCommas(totalD));
        lines.push('إجمالي الدائن: ' + formatAmountWithCommas(totalC));
        lines.push('التوازن: ' + (Math.abs(totalD - totalC) < 0.01 ? '✅ متوازن' : '⚠ فرق ' + formatAmountWithCommas(totalD - totalC)));
        return _aiOk(lines.join('\n'), { entry: e });
    }
);

_aiR(
    'list_transfers',
    'قائمة التحويلات الداخلية.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var list = (transfers || []).filter(function (t) {
            if (from && t.date < from) return false;
            if (to && t.date > to) return false;
            return true;
        });
        if (!list.length) return _aiOk('لا توجد تحويلات.');
        var lines = list.slice(0, 50).map(function (t, i) {
            var fromAcc = (t.from && t.from.accountType === 'cashbox') ? 'الصندوق' : 'البنك';
            var toAcc = (t.to && t.to.accountType === 'cashbox') ? 'الصندوق' : 'البنك';
            return (i + 1) + '. ' + t.date + ' — ' + fromAcc + ' → ' + toAcc + ' — ' +
                formatAmountWithCommas((t.from && t.from.amount) || 0) + ' ' + ((t.from && t.from.currency) || '');
        });
        return _aiOk('التحويلات (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'list_direct_transactions',
    'قائمة الحركات المباشرة (رأس المال، سحوبات، إيداعات).',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        direction: { type: 'string', enum: ['in', 'out'] }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var dir = _aiStr(args.direction);
        var list = (directTransactions || []).filter(function (t) {
            if (from && t.date < from) return false;
            if (to && t.date > to) return false;
            if (dir && t.direction !== dir) return false;
            return true;
        });
        if (!list.length) return _aiOk('لا توجد حركات مباشرة.');
        var lines = list.slice(0, 50).map(function (t, i) {
            return (i + 1) + '. ' + t.date + ' — ' + (t.direction === 'in' ? 'إيداع' : 'سحب') +
                ' — ' + (t.type || '—') + ' — ' + formatAmountWithCommas(t.amount) + ' ' + (t.currency || '');
        });
        return _aiOk('الحركات المباشرة (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'get_cash_flow',
    'التدفق النقدي خلال فترة (وارد، صادر، صافي).',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        if (typeof _reportRows !== 'function') {
            return _aiErr('دالة التدفق النقدي غير متوفرة.');
        }
        try {
            var result = _reportRows('cash_flow', from, to);
            if (!result || !result.rows) return _aiErr('لا توجد بيانات.');
            var lines = ['التدفق النقدي:', ''];
            result.rows.forEach(function (row) {
                lines.push(String(row[0]) + ': ' + String(row[1]));
            });
            return _aiOk(lines.join('\n'), { rows: result.rows });
        } catch (e) {
            return _aiErr('خطأ: ' + e.message);
        }
    }
);

_aiR(
    'get_general_ledger',
    'الأستاذ العام لحساب معين.',
    {
        accountCode: { type: 'string' },
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    ['accountCode'],
    function (args) {
        var code = _aiStr(args.accountCode);
        if (!code) return _aiErr('رمز الحساب مطلوب.');
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var movements = [];
        var runningBalance = 0;
        (journalEntries || []).forEach(function (e) {
            if (from && e.date < from) return;
            if (to && e.date > to) return;
            (e.lines || []).forEach(function (l) {
                if (l.accountCode === code) {
                    runningBalance += _aiNum(l.debit) - _aiNum(l.credit);
                    movements.push({
                        date: e.date,
                        entryId: e.id,
                        desc: e.description,
                        debit: _aiNum(l.debit),
                        credit: _aiNum(l.credit),
                        balance: runningBalance
                    });
                }
            });
        });
        movements.sort(function (a, b) { return String(a.date).localeCompare(String(b.date)); });
        if (!movements.length) return _aiOk('لا توجد حركات على الحساب: ' + code);
        var lines = ['حساب: ' + code, ''];
        movements.slice(0, 50).forEach(function (m, i) {
            lines.push((i + 1) + '. ' + m.date + ' — ' + m.desc + ' — مدين: ' + formatAmountWithCommas(m.debit) + ' — دائن: ' + formatAmountWithCommas(m.credit) + ' — رصيد: ' + formatAmountWithCommas(m.balance));
        });
        lines.push('');
        lines.push('الرصيد النهائي: ' + formatAmountWithCommas(runningBalance));
        return _aiOk(lines.join('\n'), { movements: movements, balance: runningBalance });
    }
);

_aiR(
    'get_account_balance',
    'رصيد حساب محاسبي معين.',
    {
        accountCode: { type: 'string' }
    },
    ['accountCode'],
    function (args) {
        var code = _aiStr(args.accountCode);
        if (!code) return _aiErr('رمز الحساب مطلوب.');
        var debit = 0, credit = 0;
        (journalEntries || []).forEach(function (e) {
            (e.lines || []).forEach(function (l) {
                if (l.accountCode === code) {
                    debit += _aiNum(l.debit);
                    credit += _aiNum(l.credit);
                }
            });
        });
        var balance = debit - credit;
        var lines = [
            'الحساب: ' + code,
            'إجمالي المدين: ' + formatAmountWithCommas(debit),
            'إجمالي الدائن: ' + formatAmountWithCommas(credit),
            'الرصيد: ' + formatAmountWithCommas(balance),
            balance >= 0 ? '(مدين)' : '(دائن)'
        ];
        return _aiOk(lines.join('\n'), { debit: debit, credit: credit, balance: balance });
    }
);

_aiR(
    'get_expenses_list',
    'قائمة المصاريف بفلترة حسب النوع أو الفترة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        type: { type: 'string' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var type = _aiStr(args.type);
        var list = (expenses || []).filter(function (e) {
            if (e.cancelled || e.archived) return false;
            if (from && e.date < from) return false;
            if (to && e.date > to) return false;
            if (type && _aiNormAr(e.type).indexOf(_aiNormAr(type)) === -1) return false;
            return true;
        });
        if (!list.length) return _aiOk('لا توجد مصاريف مطابقة.');
        var total = 0;
        var lines = list.slice(0, 50).map(function (e, i) {
            total += _aiNum(e.amount);
            return (i + 1) + '. ' + e.date + ' — ' + (e.type || '—') + ' — ' + formatAmountWithCommas(e.amount) + ' ' + (e.currency || '') + (e.recipient ? ' — ' + e.recipient : '');
        });
        lines.push('');
        lines.push('الإجمالي: ' + formatAmountWithCommas(total));
        return _aiOk('المصاريف (' + list.length + '):\n' + lines.join('\n'), { count: list.length, total: total });
    }
);

_aiR(
    'get_returns_list',
    'قائمة المرتجعات (مبيعات ومشتريات).',
    {
        kind: { type: 'string', enum: ['sale', 'purchase', 'all'] },
        fromDate: { type: 'string' },
        toDate: { type: 'string' }
    },
    [],
    function (args) {
        var kind = args.kind || 'all';
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var list = (returnsDocs || []).filter(function (r) {
            if (r.cancelled) return false;
            if (kind !== 'all' && r.kind !== kind) return false;
            if (from && r.date < from) return false;
            if (to && r.date > to) return false;
            return true;
        });
        if (!list.length) return _aiOk('لا توجد مرتجعات مطابقة.');
        var lines = list.slice(0, 50).map(function (r, i) {
            return (i + 1) + '. ' + r.date + ' — ' + (r.kind === 'sale' ? 'مرتجع مبيعات' : 'مرتجع مشتريات') +
                ' — ' + (r.productName || '') + ' — كمية: ' + r.qty +
                ' — ' + formatAmountWithCommas(r.amount) + ' ' + (r.currency || '');
        });
        return _aiOk('المرتجعات (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'get_return_details',
    'تفاصيل مرتجع معين.',
    {
        returnId: { type: 'string' }
    },
    ['returnId'],
    function (args) {
        var id = _aiStr(args.returnId);
        if (!id) return _aiErr('رقم المرتجع مطلوب.');
        var r = (returnsDocs || []).find(function (x) { return x.id === id; });
        if (!r) return _aiErr('المرتجع غير موجود: ' + id);
        var lines = [
            'رقم المرتجع: ' + r.id,
            'التاريخ: ' + r.date,
            'النوع: ' + (r.kind === 'sale' ? 'مرتجع مبيعات' : 'مرتجع مشتريات'),
            'الفاتورة الأصلية: ' + (r.invoiceId || '—'),
            'المنتج: ' + (r.productName || '—'),
            'الكمية الأصلية: ' + (r.originalQty || 0),
            'الكمية المرتجعة: ' + (r.qty || 0),
            'سعر الوحدة: ' + formatAmountWithCommas(r.unitPrice),
            'المبلغ: ' + formatAmountWithCommas(r.amount) + ' ' + (r.currency || ''),
            'الطرف: ' + (r.partyName || '—'),
            'الحالة: ' + (r.cancelled ? 'ملغى' : 'نشط')
        ];
        return _aiOk(lines.join('\n'), { return: r });
    }
);
// ================================================================
// ===== 17. أدوات قراءة شاملة — الدفعة 3 =====
// ================================================================

_aiR(
    'list_sales_invoices',
    'قائمة فواتير البيع بفلترة حسب التاريخ أو الحالة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        status: { type: 'string' },
        customer: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var status = _aiStr(args.status);
        var customer = _aiStr(args.customer);
        var limit = _aiNum(args.limit) || 50;

        var list = (salesInvoices || []).filter(function (i) {
            if (i.cancelled) return false;
            if (from && i.date < from) return false;
            if (to && i.date > to) return false;
            if (status && (i.status || '').indexOf(status) === -1) return false;
            if (customer && _aiNormAr(i.customerName || '').indexOf(_aiNormAr(customer)) === -1) return false;
            return true;
        });
        list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
        list = list.slice(0, limit);
        if (!list.length) return _aiOk('لا توجد فواتير مطابقة.');
        var lines = list.map(function (i, idx) {
            return (idx + 1) + '. ' + i.id + ' — ' + i.date + ' — ' + (i.customerName || '—') +
                ' — ' + formatAmountWithCommas(i.total) + ' ' + (i.currency || '') +
                ' — ' + (i.status || '');
        });
        return _aiOk('فواتير البيع (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'list_purchase_invoices',
    'قائمة فواتير الشراء بفلترة حسب التاريخ أو الحالة.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        status: { type: 'string' },
        supplier: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var status = _aiStr(args.status);
        var supplier = _aiStr(args.supplier);
        var limit = _aiNum(args.limit) || 50;

        var list = (purchaseInvoices || []).filter(function (i) {
            if (i.cancelled) return false;
            if (from && i.date < from) return false;
            if (to && i.date > to) return false;
            if (status && (i.status || '').indexOf(status) === -1) return false;
            if (supplier && _aiNormAr(i.supplierName || '').indexOf(_aiNormAr(supplier)) === -1) return false;
            return true;
        });
        list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
        list = list.slice(0, limit);
        if (!list.length) return _aiOk('لا توجد فواتير مطابقة.');
        var lines = list.map(function (i, idx) {
            return (idx + 1) + '. ' + i.id + ' — ' + i.date + ' — ' + (i.supplierName || '—') +
                ' — ' + formatAmountWithCommas(i.total) + ' ' + (i.currency || '') +
                ' — ' + (i.status || '');
        });
        return _aiOk('فواتير الشراء (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'list_receipts',
    'قائمة سندات القبض.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        customer: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var customer = _aiStr(args.customer);
        var limit = _aiNum(args.limit) || 50;

        var list = (receipts || []).filter(function (r) {
            if (r.cancelled) return false;
            if (from && r.date < from) return false;
            if (to && r.date > to) return false;
            if (customer && _aiNormAr(r.customerName || r.supplierName || '').indexOf(_aiNormAr(customer)) === -1) return false;
            return true;
        });
        list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
        list = list.slice(0, limit);
        if (!list.length) return _aiOk('لا توجد سندات مطابقة.');
        var lines = list.map(function (r, i) {
            var party = r.receiptType === 'supplier_refund' ? ('من مورد: ' + (r.supplierName || '')) : ('من عميل: ' + (r.customerName || ''));
            return (i + 1) + '. ' + r.id + ' — ' + r.date + ' — ' + party +
                ' — ' + formatAmountWithCommas(r.amount) + ' ' + (r.currency || '');
        });
        return _aiOk('سندات القبض (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'list_payments',
    'قائمة سندات الصرف (للموردين، للعملاء، للمصاريف).',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        party: { type: 'string' },
        paymentType: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var party = _aiStr(args.party);
        var pType = _aiStr(args.paymentType);
        var limit = _aiNum(args.limit) || 50;

        var list = (payments || []).filter(function (p) {
            if (p.cancelled || p.archived) return false;
            if (from && p.date < from) return false;
            if (to && p.date > to) return false;
            if (party) {
                var name = p.supplierName || p.customerName || '';
                if (_aiNormAr(name).indexOf(_aiNormAr(party)) === -1) return false;
            }
            if (pType && p.paymentType !== pType) return false;
            return true;
        });
        list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
        list = list.slice(0, limit);
        if (!list.length) return _aiOk('لا توجد سندات مطابقة.');
        var lines = list.map(function (p, i) {
            var type = p.isExpense ? 'مصروف' : (p.paymentType === 'customer_refund' ? 'رد لعميل' : 'صرف لمورد');
            var partyName = p.supplierName || p.customerName || '';
            return (i + 1) + '. ' + p.id + ' — ' + p.date + ' — ' + type + ' — ' + partyName +
                ' — ' + formatAmountWithCommas(p.amount) + ' ' + (p.currency || '');
        });
        return _aiOk('سندات الصرف (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'list_stock_movements',
    'حركات المخزون (إدخال وإخراج).',
    {
        product: { type: 'string' },
        type: { type: 'string', enum: ['in', 'out'] },
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var prodName = _aiStr(args.product);
        var type = _aiStr(args.type);
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var limit = _aiNum(args.limit) || 50;

        var list = (stockMovements || []).filter(function (m) {
            if (prodName && _aiNormAr(m.productName || '').indexOf(_aiNormAr(prodName)) === -1) return false;
            if (type && m.type !== type) return false;
            if (from && m.date < from) return false;
            if (to && m.date > to) return false;
            return true;
        });
        list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
        list = list.slice(0, limit);
        if (!list.length) return _aiOk('لا توجد حركات مطابقة.');
        var lines = list.map(function (m, i) {
            return (i + 1) + '. ' + m.date + ' — ' + (m.type === 'in' ? 'إدخال' : 'إخراج') +
                ' — ' + (m.productName || '') + ' — ' + m.qty + ' ' + (m.unit || '') +
                ' — ' + (m.docType || '') + (m.docId ? ' #' + m.docId : '');
        });
        return _aiOk('حركات المخزون (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'list_production_orders',
    'سندات الإنتاج.',
    {
        fromDate: { type: 'string' },
        toDate: { type: 'string' },
        product: { type: 'string' },
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var from = _aiStr(args.fromDate);
        var to = _aiStr(args.toDate);
        var prodName = _aiStr(args.product);
        var limit = _aiNum(args.limit) || 50;

        var list = (productionDocs || []).filter(function (d) {
            if (d.cancelled) return false;
            if (from && d.date < from) return false;
            if (to && d.date > to) return false;
            if (prodName && _aiNormAr(d.productName || '').indexOf(_aiNormAr(prodName)) === -1) return false;
            return true;
        });
        list.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
        list = list.slice(0, limit);
        if (!list.length) return _aiOk('لا توجد سندات إنتاج.');
        var lines = list.map(function (d, i) {
            return (i + 1) + '. ' + d.id + ' — ' + d.date + ' — ' + (d.productName || '') +
                ' — كمية: ' + d.outputQty + ' — تكلفة: ' + formatAmountWithCommas(d.productionCost) + ' ' + (d.currency || '');
        });
        return _aiOk('سندات الإنتاج (' + list.length + '):\n' + lines.join('\n'), { count: list.length });
    }
);

_aiR(
    'get_production_order_details',
    'تفاصيل سند إنتاج (مواد خام + ناتج + تكلفة).',
    {
        orderId: { type: 'string' }
    },
    ['orderId'],
    function (args) {
        var id = _aiStr(args.orderId);
        if (!id) return _aiErr('رقم السند مطلوب.');
        var d = (productionDocs || []).find(function (x) { return x.id === id; });
        if (!d) return _aiErr('السند غير موجود: ' + id);
        var lines = [
            'رقم السند: ' + d.id,
            'التاريخ: ' + d.date,
            'المنتج التام: ' + (d.productName || '—'),
            'عدد الدفعات: ' + (d.batches || 0),
            'الكمية المنتجة: ' + (d.outputQty || 0),
            'التكلفة الإجمالية: ' + formatAmountWithCommas(d.productionCost) + ' ' + (d.currency || ''),
            'تكلفة الوحدة: ' + formatAmountWithCommas(d.unitCost),
            '',
            'المواد الخام المستهلكة:'
        ];
        (d.inputs || []).forEach(function (inp, i) {
            lines.push('  ' + (i + 1) + '. ' + inp.name + ' — ' + inp.qty + ' ' + (inp.unit || ''));
        });
        lines.push('');
        lines.push('المنتجات الناتجة:');
        (d.outputs || []).forEach(function (out, i) {
            lines.push('  ' + (i + 1) + '. ' + out.name + ' — ' + out.qty + ' ' + (out.unit || '') + ' — تكلفة الوحدة: ' + formatAmountWithCommas(out.unitCost));
        });
        return _aiOk(lines.join('\n'), { order: d });
    }
);

_aiR(
    'list_bom_recipes',
    'وصفات BOM (قوائم المواد لكل منتج).',
    {},
    [],
    function () {
        if (!(bomRecipes || []).length) return _aiOk('لا توجد وصفات BOM.');
        var lines = (bomRecipes || []).map(function (r, i) {
            var p = (products || []).find(function (x) { return x.id === r.productId; });
            return (i + 1) + '. ' + (p ? p.name : r.productId) + ' — إنتاج: ' + r.outputQty + ' — عدد المواد: ' + (r.items || []).length;
        });
        return _aiOk('وصفات BOM (' + bomRecipes.length + '):\n' + lines.join('\n'), { count: bomRecipes.length });
    }
);

_aiR(
    'get_bom_details',
    'تفاصيل وصفة BOM لمنتج.',
    {
        product: { type: 'string' }
    },
    ['product'],
    function (args) {
        var q = _aiStr(args.product);
        if (!q) return _aiErr('اسم المنتج مطلوب.');
        var p = (products || []).find(function (x) {
            return x.id === q || _aiNormAr(x.name).indexOf(_aiNormAr(q)) !== -1;
        });
        if (!p) return _aiErr('المنتج غير موجود: ' + q);
        var recipe = (bomRecipes || []).find(function (r) { return r.productId === p.id; });
        if (!recipe) return _aiErr('لا توجد وصفة BOM لهذا المنتج.');
        var lines = [
            'المنتج: ' + p.name,
            'إنتاج الدفعة: ' + recipe.outputQty + ' ' + _aiBaseUnit(p),
            '',
            'المواد الخام:'
        ];
        (recipe.items || []).forEach(function (item, i) {
            var raw = (products || []).find(function (x) { return x.id === item.productId; });
            var rawName = raw ? raw.name : (item.name || item.productId);
            lines.push('  ' + (i + 1) + '. ' + rawName + ' — ' + item.qty + ' ' + (item.unit || '') + ' — تكلفة: ' + formatAmountWithCommas(raw ? raw.avgCost : 0));
        });
        return _aiOk(lines.join('\n'), { recipe: recipe });
    }
);

_aiR(
    'get_customer_balances_all',
    'أرصدة كل العملاء.',
    {},
    [],
    function () {
        var lines = [];
        (customers || []).forEach(function (c) {
            var invs = (salesInvoices || []).filter(function (i) { return i.customerId === c.id && !i.cancelled; });
            var recs = (receipts || []).filter(function (r) { return r.customerId === c.id && !r.cancelled; });
            var returns = (returnsDocs || []).filter(function (r) { return r.kind === 'sale' && r.partyId === c.id && !r.cancelled; });
            var totalInv = invs.reduce(function (s, i) { return s + _aiNum(i.total); }, 0);
            var totalRec = recs.reduce(function (s, r) { return s + _aiNum(r.amount); }, 0);
            var totalRet = returns.reduce(function (s, r) { return s + _aiNum(r.amount); }, 0);
            var balance = totalInv - totalRec - totalRet;
            lines.push(c.name + ': ' + formatAmountWithCommas(balance) + (balance > 0.01 ? ' (لك)' : balance < -0.01 ? ' (عليك)' : ' (صفر)'));
        });
        if (!lines.length) lines.push('لا يوجد عملاء.');
        return _aiOk('أرصدة العملاء:\n' + lines.join('\n'), {});
    }
);

_aiR(
    'get_supplier_balances_all',
    'أرصدة كل الموردين.',
    {},
    [],
    function () {
        var lines = [];
        (suppliers || []).forEach(function (s) {
            var invs = (purchaseInvoices || []).filter(function (i) { return i.supplierId === s.id && !i.cancelled; });
            var pays = (payments || []).filter(function (p) { return p.supplierId === s.id && !p.cancelled && !p.isExpense; });
            var returns = (returnsDocs || []).filter(function (r) { return r.kind === 'purchase' && r.partyId === s.id && !r.cancelled; });
            var totalInv = invs.reduce(function (a, i) { return a + _aiNum(i.total); }, 0);
            var totalPay = pays.reduce(function (a, p) { return a + _aiNum(p.amount); }, 0);
            var totalRet = returns.reduce(function (a, r) { return a + _aiNum(r.amount); }, 0);
            var balance = totalInv - totalPay - totalRet;
            lines.push(s.name + ': ' + formatAmountWithCommas(balance) + (balance > 0.01 ? ' (عليك)' : balance < -0.01 ? ' (لك)' : ' (صفر)'));
        });
        if (!lines.length) lines.push('لا يوجد موردون.');
        return _aiOk('أرصدة الموردين:\n' + lines.join('\n'), {});
    }
);

_aiR(
    'get_audit_log',
    'سجل التدقيق (كل الأحداث على النظام).',
    {
        limit: { type: 'number' }
    },
    [],
    function (args) {
        var limit = _aiNum(args.limit) || 30;
        var log = Storage.get('oa_audit_log', []) || [];
        if (!Array.isArray(log) || !log.length) return _aiOk('لا يوجد سجل تدقيق.');
        var lines = log.slice(-limit).map(function (entry, i) {
            return (i + 1) + '. ' + (entry.timestamp || entry.date || '—') + ' — ' + (entry.action || entry.type || '—') + ' — ' + (entry.description || '');
        });
        return _aiOk('سجل التدقيق (آخر ' + lines.length + '):\n' + lines.join('\n'), { count: log.length });
    }
);

_aiR(
    'get_inventory_value_detailed',
    'قيمة المخزون التفصيلية لكل منتج.',
    {},
    [],
    function () {
        var lines = [];
        var totalValue = 0;
        (products || []).forEach(function (p) {
            var qty = _aiNum(p.quantity);
            var cost = _aiNum(p.avgCost);
            var value = qty * cost;
            totalValue += value;
            lines.push(p.name + ': ' + qty + ' ' + _aiBaseUnit(p) + ' × ' + formatAmountWithCommas(cost) + ' = ' + formatAmountWithCommas(value));
        });
        lines.push('');
        lines.push('القيمة الإجمالية: ' + formatAmountWithCommas(totalValue));
        return _aiOk('قيمة المخزون التفصيلية:\n' + lines.join('\n'), { totalValue: totalValue });
    }
);
// ================================================================
// ===== END OF ai-agent-tools.js =====
// ================================================================