// ================================================================
// Open Account — نظام محاسبي
// الملف: suppliers.js
// الوصف: إدارة الموردين
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var suppliers = [];


// ================================================================
// ===== 2. تحميل وحفظ الموردين =====
// ================================================================

function loadSuppliers() {
    suppliers = Storage.get(STORAGE_KEYS.SUPPLIERS, []);
    if (!Array.isArray(suppliers)) suppliers = [];
}


function saveSuppliers() {
    Storage.set(STORAGE_KEYS.SUPPLIERS, suppliers);
}


// ================================================================
// ===== 3. عرض جدول الموردين =====
// ================================================================

function renderSuppliers() {
    var tbody = document.getElementById('supTableBody');
    if (!tbody) return;
    
    var searchEl = document.getElementById('supSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';
    
    var filtered = suppliers;
    if (search) {
        filtered = suppliers.filter(function(s) {
            return String(s.name || '').toLowerCase().indexOf(search) !== -1 ||
                   String(s.phone || '').indexOf(search) !== -1;
        });
    }
    
    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-cell">لا يوجد موردين</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function(s, i) {
            html += '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td>' + esc(s.name) + '</td>' +
                '<td>' + esc(s.phone || '-') + '</td>' +
                '<td>' + esc(s.address || '-') + '</td>' +
                '<td>' +
                    '<button class="btn-edit" onclick="editSupplier(\'' + s.id + '\')" title="تعديل">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>' +
                    '</button>' +
                    '<button class="btn-delete" onclick="deleteSupplier(\'' + s.id + '\')" title="حذف">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
                    '</button>' +
                '</td>' +
            '</tr>';
        });
        tbody.innerHTML = html;
    }
    
    updateSuppliersStats();
}


// ================================================================
// ===== 4. إحصائيات الموردين =====
// ================================================================

function updateSuppliersStats() {
    setText('dashSuppliers', suppliers.length);
    setText('supTotalCount', suppliers.length);

    // ✅ حساب "المستحق لهم" من الفواتير النشطة
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var totalDue = 0;

    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)
        && typeof getInvoiceOutstanding === 'function') {
        purchaseInvoices.forEach(function(inv) {
            if (typeof _reportIsActive === 'function' && !_reportIsActive(inv)) return;
            var o = getInvoiceOutstanding(inv.id, 'purchase');
            if (!o) return;
            if (o.outstanding > 0.01) {
                var val = o.outstanding;
                if (inv.currency && inv.currency !== base && typeof getEquivalent === 'function') {
                    val = getEquivalent(val, inv.currency);
                }
                totalDue += val;
            }
        });
    }

    setText('supDueAmount', formatAmountWithCommas(totalDue) + ' ' + base);
}


// ================================================================
// ===== 5. نافذة إضافة/تعديل مورد =====
// ================================================================

function openSupModal(data) {
    var isEdit = data && data.id;
    
    var bodyHTML = 
        '<input type="hidden" id="supEditId" value="' + (isEdit ? data.id : '') + '">' +
        
        '<div class="form-field">' +
            '<label>اسم المورد</label>' +
            '<input type="text" id="supName" placeholder="أدخل اسم المورد" value="' + (isEdit ? esc(data.name) : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>رقم الهاتف</label>' +
            '<input type="tel" id="supPhone" placeholder="7xxxxxxxx" value="' + (isEdit ? esc(data.phone || '') : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>البريد الإلكتروني (اختياري)</label>' +
            '<input type="email" id="supEmail" placeholder="example@email.com" value="' + (isEdit ? esc(data.email || '') : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>العنوان (اختياري)</label>' +
            '<input type="text" id="supAddress" placeholder="المدينة - المنطقة" value="' + (isEdit ? esc(data.address || '') : '') + '">' +
        '</div>';
    
    var footerHTML = 
        '<button class="btn btn-cancel" onclick="closeModal(\'supModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="saveSupplier()">حفظ</button>';
    
    Modal.open({
        id: 'supModal',
        title: isEdit ? 'تعديل مورد' : 'إضافة مورد جديد',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            setTimeout(function() {
                var nameInput = modalEl.querySelector('#supName');
                if (nameInput) nameInput.focus();
            }, 200);
        }
    });
}


// ================================================================
// ===== 6. تعديل مورد =====
// ================================================================

function editSupplier(id) {
    var supplier = suppliers.find(function(s) { return s.id === id; });
    if (supplier) {
        openSupModal(supplier);
    }
}


// ================================================================
// ===== 7. حفظ مورد =====
// ================================================================

function saveSupplier() {
    var idEl = document.getElementById('supEditId');
    var nameEl = document.getElementById('supName');
    var phoneEl = document.getElementById('supPhone');
    var emailEl = document.getElementById('supEmail');
    var addrEl = document.getElementById('supAddress');
    
    var id = idEl ? idEl.value : '';
    var name = nameEl ? nameEl.value.trim() : '';
    var phone = phoneEl ? phoneEl.value.trim() : '';
    var email = emailEl ? emailEl.value.trim() : '';
    var address = addrEl ? addrEl.value.trim() : '';
    
    if (!name) {
        showToast('يرجى إدخال اسم المورد', 'error');
        return;
    }
    
    if (id) {
        var index = suppliers.findIndex(function(s) { return s.id === id; });
        if (index !== -1) {
            suppliers[index] = {
                id: id,
                name: name,
                phone: phone,
                email: email,
                address: address
            };
        }
        showToast('تم تعديل المورد', 'success');
    } else {
        suppliers.push({
            id: generateId(),
            name: name,
            phone: phone,
            email: email,
            address: address
        });
        showToast('تم إضافة المورد', 'success');
    }
    
    saveSuppliers();
    closeModal('supModal');
    renderSuppliers();
}


// ================================================================
// ===== 8. حذف مورد =====
// ================================================================

function deleteSupplier(id) {
    var supplier = suppliers.find(function(s) { return s.id === id; });
    if (!supplier) return;
    
    Modal.confirm({
        title: 'تأكيد الحذف',
        message: 'هل أنت متأكد من حذف المورد "' + supplier.name + '"؟',
        confirmText: 'حذف',
        cancelText: 'إلغاء',
        confirmColor: 'danger',
        onConfirm: function() {
            suppliers = suppliers.filter(function(s) { return s.id !== id; });
            saveSuppliers();
            renderSuppliers();
            showToast('تم حذف المورد', 'success');
        }
    });
}


// ================================================================
// ===== 9. تهيئة الموردين =====
// ================================================================

function initSuppliers() {
    loadSuppliers();
    renderSuppliers();
    
    var searchEl = document.getElementById('supSearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderSuppliers, 300));
    }
    
    console.log('Suppliers: ' + suppliers.length + ' مورد');
}


// ================================================================
// ===== END OF SUPPLIERS.JS =====
// ================================================================