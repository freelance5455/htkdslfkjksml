// ================================================================
// Open Account — قسم التدقيق
// الملف: audit.js
// الوصف: فحص شامل للنظام — لا يُعدّل البيانات
// ================================================================


// ================================================================
// ===== 1. الحالة الداخلية =====
// ================================================================

var _auditState = {
    errors: [],
    warnings: [],
    infos: [],
    filter: 'all'
};


// ================================================================
// ===== 2. أدوات مساعدة =====
// ================================================================

function _auditNumber(v) {
    var n = parseFloat(v);
    return isFinite(n) ? n : 0;
}

function _auditText(v) {
    return (v === null || v === undefined) ? '' : String(v).trim();
}

function _auditDate(v) {
    return _auditText(v);
}

function _auditToday() {
    return (typeof todayISO === 'function') ? todayISO() : new Date().toISOString().slice(0, 10);
}

function _auditAddError(code, title, description, details) {
    _auditState.errors.push({
        type: 'error',
        code: code,
        title: title,
        description: description || '',
        details: details || ''
    });
}

function _auditAddWarning(code, title, description, details) {
    _auditState.warnings.push({
        type: 'warning',
        code: code,
        title: title,
        description: description || '',
        details: details || ''
    });
}

function _auditAddInfo(code, title, description, details) {
    _auditState.infos.push({
        type: 'info',
        code: code,
        title: title,
        description: description || '',
        details: details || ''
    });
}


// ================================================================
// ===== 3. فحوصات المنتجات =====
// ================================================================

function _auditProducts() {
    if (typeof products === 'undefined' || !Array.isArray(products)) return;

    products.forEach(function(p, idx) {
        if (!p) return;

        var name = _auditText(p.name);
        if (!name) {
            _auditAddError(
                'PRODUCT_NAME_MISSING',
                'اسم منتج ناقص',
                'المنتج رقم ' + (idx + 1) + ' لا يحتوي على اسم',
                ''
            );
        }

        var qty = _auditNumber(p.quantity);
        if (qty < 0) {
            _auditAddWarning(
                'PRODUCT_NEGATIVE_QTY',
                'كمية منتج سالبة',
                'المنتج: ' + name,
                'الكمية: ' + qty
            );
        }
    });
}


// ================================================================
// ===== 4. فحوصات العملاء والموردين =====
// ================================================================

function _auditCustomers() {
    if (typeof customers === 'undefined' || !Array.isArray(customers)) return;

    var seen = {};
    customers.forEach(function(c, idx) {
        if (!c) return;

        var name = _auditText(c.name);
        if (!name) {
            _auditAddError(
                'CUSTOMER_NAME_MISSING',
                'اسم عميل ناقص',
                'العميل رقم ' + (idx + 1) + ' لا يحتوي على اسم',
                ''
            );
        }

        if (c.id && seen[c.id]) {
            _auditAddError(
                'CUSTOMER_DUPLICATE_ID',
                'معرف عميل مكرر',
                'العميل: ' + name,
                'المعرف: ' + c.id
            );
        }
        if (c.id) seen[c.id] = true;
    });
}

function _auditSuppliers() {
    if (typeof suppliers === 'undefined' || !Array.isArray(suppliers)) return;

    var seen = {};
    suppliers.forEach(function(s, idx) {
        if (!s) return;

        var name = _auditText(s.name);
        if (!name) {
            _auditAddError(
                'SUPPLIER_NAME_MISSING',
                'اسم مورد ناقص',
                'المورد رقم ' + (idx + 1) + ' لا يحتوي على اسم',
                ''
            );
        }

        if (s.id && seen[s.id]) {
            _auditAddError(
                'SUPPLIER_DUPLICATE_ID',
                'معرف مورد مكرر',
                'المورد: ' + name,
                'المعرف: ' + s.id
            );
        }
        if (s.id) seen[s.id] = true;
    });
}


// ================================================================
// ===== 5. فحوصات فواتير البيع =====
// ================================================================

function _auditSalesInvoices() {
    if (typeof salesInvoices === 'undefined' || !Array.isArray(salesInvoices)) return;

    var today = _auditToday();
    var numbersSeen = {};

    salesInvoices.forEach(function(inv, idx) {
        if (!inv) return;

        // فحص تاريخ
        var dateStr = _auditDate(inv.date);
        if (!dateStr) {
            _auditAddError(
                'SALES_DATE_MISSING',
                'تاريخ فاتورة بيع ناقص',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
        } else {
            var d = new Date(dateStr);
            if (!isNaN(d.getTime()) && dateStr > today) {
                _auditAddWarning(
                    'SALES_FUTURE_DATE',
                    'تاريخ فاتورة بيع مستقبلي',
                    'الفاتورة: ' + (inv.id || idx + 1),
                    'التاريخ: ' + dateStr
                );
            }
        }

        // فحص رقم الفاتورة
        var num = _auditText(inv.id);
        if (!num) {
            _auditAddError(
                'SALES_INVOICE_NUMBER_MISSING',
                'رقم فاتورة بيع ناقص',
                'الفاتورة رقم ' + (idx + 1),
                ''
            );
        } else if (numbersSeen[num]) {
            _auditAddError(
                'SALES_DUPLICATE_NUMBER',
                'رقم فاتورة بيع مكرر',
                'الفاتورة: ' + num,
                'ظهر في سجلين'
            );
        } else {
            numbersSeen[num] = true;
        }

        // فحص العميل
        if (!inv.customerId) {
            _auditAddWarning(
                'SALES_CUSTOMER_MISSING',
                'عميل فاتورة بيع ناقص',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
        }

        // فحص الإجمالي
        var total = _auditNumber(inv.total);
        if (total < 0) {
            _auditAddError(
                'SALES_NEGATIVE_TOTAL',
                'إجمالي فاتورة بيع سالب',
                'الفاتورة: ' + (inv.id || idx + 1),
                'المبلغ: ' + total
            );
        }
        if (total === 0) {
            _auditAddWarning(
                'SALES_ZERO_TOTAL',
                'إجمالي فاتورة بيع = صفر',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
        }

        // فحص الأصناف
        var items = inv.items || [];
        if (!items.length) {
            _auditAddWarning(
                'SALES_NO_ITEMS',
                'فاتورة بيع بدون أصناف',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
            return;
        }

        // فحص كل صنف
        var computedTotal = 0;
        items.forEach(function(item, iIdx) {
            if (!item) return;

            var qty = _auditNumber(item.qty);
            var price = _auditNumber(item.price);
            var lineTotal = _auditNumber(item.total);

            if (qty <= 0) {
                _auditAddError(
                    'SALES_ITEM_QTY_INVALID',
                    'كمية صنف غير صحيحة',
                    'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || iIdx + 1),
                    'الكمية: ' + qty
                );
            }

            if (price < 0) {
                _auditAddError(
                    'SALES_ITEM_PRICE_NEGATIVE',
                    'سعر صنف سالب',
                    'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || iIdx + 1),
                    'السعر: ' + price
                );
            }

            var expected = qty * price;
            computedTotal += expected;

            if (lineTotal !== 0 && Math.abs(lineTotal - expected) > 0.01) {
                _auditAddWarning(
                    'SALES_ITEM_TOTAL_MISMATCH',
                    'إجمالي صنف غير مطابق',
                    'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || iIdx + 1),
                    'المحسوب: ' + expected + ' | المسجل: ' + lineTotal
                );
            }

            // فحص منتج موجود
            if (item.productId) {
                var productExists = (typeof products !== 'undefined') && products.some(function(p) {
                    return p && p.id === item.productId;
                });
                if (!productExists) {
                    _auditAddError(
                        'SALES_ITEM_PRODUCT_MISSING',
                        'منتج غير موجود',
                        'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || '-'),
                        'معرف المنتج: ' + item.productId
                    );
                }
            }
        });

        // مقارنة الإجمالي المحسوب
        var discount = _auditNumber(inv.discount);
        var expectedTotal = computedTotal - discount;
        if (Math.abs(expectedTotal - total) > 0.01) {
            _auditAddWarning(
                'SALES_TOTAL_MISMATCH',
                'إجمالي الفاتورة غير مطابق',
                'الفاتورة: ' + (inv.id || idx + 1),
                'المحسوب: ' + expectedTotal + ' | المسجل: ' + total
            );
        }
    });
}


// ================================================================
// ===== 6. فحوصات فواتير الشراء =====
// ================================================================

function _auditPurchaseInvoices() {
    if (typeof purchaseInvoices === 'undefined' || !Array.isArray(purchaseInvoices)) return;

    var today = _auditToday();
    var numbersSeen = {};

    purchaseInvoices.forEach(function(inv, idx) {
        if (!inv) return;

        // فحص تاريخ
        var dateStr = _auditDate(inv.date);
        if (!dateStr) {
            _auditAddError(
                'PURCHASE_DATE_MISSING',
                'تاريخ فاتورة شراء ناقص',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
        } else {
            var d = new Date(dateStr);
            if (!isNaN(d.getTime()) && dateStr > today) {
                _auditAddWarning(
                    'PURCHASE_FUTURE_DATE',
                    'تاريخ فاتورة شراء مستقبلي',
                    'الفاتورة: ' + (inv.id || idx + 1),
                    'التاريخ: ' + dateStr
                );
            }
        }

        // فحص رقم الفاتورة
        var num = _auditText(inv.id);
        if (!num) {
            _auditAddError(
                'PURCHASE_INVOICE_NUMBER_MISSING',
                'رقم فاتورة شراء ناقص',
                'الفاتورة رقم ' + (idx + 1),
                ''
            );
        } else if (numbersSeen[num]) {
            _auditAddError(
                'PURCHASE_DUPLICATE_NUMBER',
                'رقم فاتورة شراء مكرر',
                'الفاتورة: ' + num,
                'ظهر في سجلين'
            );
        } else {
            numbersSeen[num] = true;
        }

        // فحص المورد
        if (!inv.supplierId) {
            _auditAddWarning(
                'PURCHASE_SUPPLIER_MISSING',
                'مورد فاتورة شراء ناقص',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
        }

        // فحص الإجمالي
        var total = _auditNumber(inv.total);
        if (total < 0) {
            _auditAddError(
                'PURCHASE_NEGATIVE_TOTAL',
                'إجمالي فاتورة شراء سالب',
                'الفاتورة: ' + (inv.id || idx + 1),
                'المبلغ: ' + total
            );
        }
        if (total === 0) {
            _auditAddWarning(
                'PURCHASE_ZERO_TOTAL',
                'إجمالي فاتورة شراء = صفر',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
        }

        // فحص الأصناف
        var items = inv.items || [];
        if (!items.length) {
            _auditAddWarning(
                'PURCHASE_NO_ITEMS',
                'فاتورة شراء بدون أصناف',
                'الفاتورة: ' + (inv.id || idx + 1),
                ''
            );
            return;
        }

        // فحص كل صنف
        var computedTotal = 0;
        items.forEach(function(item, iIdx) {
            if (!item) return;

            var qty = _auditNumber(item.qty);
            var price = _auditNumber(item.price);
            var lineTotal = _auditNumber(item.total);

            if (qty <= 0) {
                _auditAddError(
                    'PURCHASE_ITEM_QTY_INVALID',
                    'كمية صنف غير صحيحة',
                    'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || iIdx + 1),
                    'الكمية: ' + qty
                );
            }

            if (price < 0) {
                _auditAddError(
                    'PURCHASE_ITEM_PRICE_NEGATIVE',
                    'سعر صنف سالب',
                    'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || iIdx + 1),
                    'السعر: ' + price
                );
            }

            var expected = qty * price;
            computedTotal += expected;

            if (lineTotal !== 0 && Math.abs(lineTotal - expected) > 0.01) {
                _auditAddWarning(
                    'PURCHASE_ITEM_TOTAL_MISMATCH',
                    'إجمالي صنف غير مطابق',
                    'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || iIdx + 1),
                    'المحسوب: ' + expected + ' | المسجل: ' + lineTotal
                );
            }

            // فحص منتج موجود
            if (item.productId) {
                var productExists = (typeof products !== 'undefined') && products.some(function(p) {
                    return p && p.id === item.productId;
                });
                if (!productExists) {
                    _auditAddError(
                        'PURCHASE_ITEM_PRODUCT_MISSING',
                        'منتج غير موجود',
                        'الفاتورة: ' + (inv.id || idx + 1) + ' — الصنف: ' + (item.name || '-'),
                        'معرف المنتج: ' + item.productId
                    );
                }
            }
        });

        // مقارنة الإجمالي المحسوب
        var discount = _auditNumber(inv.discount);
        var expectedTotal = computedTotal - discount;
        if (Math.abs(expectedTotal - total) > 0.01) {
            _auditAddWarning(
                'PURCHASE_TOTAL_MISMATCH',
                'إجمالي الفاتورة غير مطابق',
                'الفاتورة: ' + (inv.id || idx + 1),
                'المحسوب: ' + expectedTotal + ' | المسجل: ' + total
            );
        }
    });
}


// ================================================================
// ===== 7. فحوصات سندات القبض =====
// ================================================================

function _auditReceipts() {
    if (typeof receipts === 'undefined' || !Array.isArray(receipts)) return;

    receipts.forEach(function(r, idx) {
        if (!r) return;

        // فحص المبلغ
        var amount = _auditNumber(r.amount);
        if (amount <= 0) {
            _auditAddError(
                'RECEIPT_INVALID_AMOUNT',
                'مبلغ سند قبض غير صحيح',
                'السند: ' + (r.id || idx + 1),
                'المبلغ: ' + amount
            );
        }

        // ===== كشف نوع السند =====
        var rTypeStr = String(
            r.receiptType || r.type || r.docType || r.voucherType || ''
        ).trim();

        var isSupplierRefund = 
            (r.isSupplierRefund === true) ||
            (r.receiptType === 'supplier_refund') ||
            (rTypeStr === 'تحصيل من مورد') ||
            (rTypeStr.indexOf('تحصيل من مورد') !== -1);

        // ===== سندات supplier_refund — تفحص supplierId لا customerId =====
        if (isSupplierRefund) {
            if (!r.supplierId) {
                _auditAddWarning(
                    'RECEIPT_SUPPLIER_REFUND_NO_SUPPLIER',
                    'تحصيل من مورد بدون تحديد المورد',
                    'السند: ' + (r.id || idx + 1),
                    ''
                );
            }
            // لا نفحص customerId هنا
            return;
        }

        // ===== سند قبض عادي (السلوك الأصلي) =====
        if (!r.customerId) {
            _auditAddWarning(
                'RECEIPT_CUSTOMER_MISSING',
                'عميل سند قبض ناقص',
                'السند: ' + (r.id || idx + 1),
                ''
            );
        }

        if (!r.invoiceId || r.invoiceId === '-') {
            _auditAddInfo(
                'RECEIPT_NO_INVOICE',
                'سند قبض بدون فاتورة',
                'السند: ' + (r.id || idx + 1),
                'دفع مباشر أو دفعة على الحساب'
            );
        } else {
            var invoiceExists = (typeof salesInvoices !== 'undefined') && salesInvoices.some(function(inv) {
                return inv && inv.id === r.invoiceId;
            });
            if (!invoiceExists) {
                _auditAddWarning(
                    'RECEIPT_INVOICE_MISSING',
                    'فاتورة مرتبطة غير موجودة',
                    'السند: ' + (r.id || idx + 1),
                    'الفاتورة: ' + r.invoiceId
                );
            }
        }
    });
}


// ================================================================
// ===== 8. فحوصات سندات الصرف =====
// ================================================================

function _auditPayments() {
    if (typeof payments === 'undefined' || !Array.isArray(payments)) return;

    payments.forEach(function(p, idx) {
        if (!p || p.archived) return;

        // فحص المبلغ
        var amount = _auditNumber(p.amount);
        if (amount <= 0) {
            _auditAddError(
                'PAYMENT_INVALID_AMOUNT',
                'مبلغ سند صرف غير صحيح',
                'السند: ' + (p.id || idx + 1),
                'المبلغ: ' + amount
            );
        }

        // ===== كشف نوع السند =====
        var pTypeStr = String(
            p.paymentType || p.type || p.docType || p.voucherType || ''
        ).trim();

        var isRefundType = 
            (p.isCustomerRefund === true) ||
            (p.isSupplierRefund === true) ||
            (p.paymentType === 'customer_refund') ||
            (p.paymentType === 'supplier_refund') ||
            (pTypeStr === 'رد مبلغ لعميل') ||
            (pTypeStr === 'تحصيل من مورد') ||
            (pTypeStr.indexOf('رد مبلغ') !== -1) ||
            (pTypeStr.indexOf('تحصيل من مورد') !== -1);

        // فحص المصروف
        if (p.isExpense) {
            if (!p.expenseId) {
                _auditAddWarning(
                    'PAYMENT_EXPENSE_MISSING',
                    'سند صرف مصروف بدون مرجع',
                    'السند: ' + (p.id || idx + 1),
                    ''
                );
            }
            return;
        }

        // ===== سندات الرد — لا تفحص supplierId =====
        if (isRefundType) {
            if (p.invoiceId && p.invoiceId !== '-') {
                var refundInvoiceExists = (typeof purchaseInvoices !== 'undefined') && 
                    purchaseInvoices.some(function(inv) {
                        return inv && inv.id === p.invoiceId;
                    });
                if (!refundInvoiceExists) {
                    _auditAddWarning(
                        'PAYMENT_INVOICE_MISSING',
                        'فاتورة شراء مرتبطة غير موجودة',
                        'السند: ' + (p.id || idx + 1),
                        'الفاتورة: ' + p.invoiceId
                    );
                }
            }
            return;
        }

        // ===== سند صرف عادي (السلوك الأصلي — لم يتغير) =====
        if (!p.supplierId) {
            _auditAddWarning(
                'PAYMENT_SUPPLIER_MISSING',
                'مورد سند صرف ناقص',
                'السند: ' + (p.id || idx + 1),
                ''
            );
        }

        if (!p.invoiceId || p.invoiceId === '-') {
            _auditAddInfo(
                'PAYMENT_NO_INVOICE',
                'سند صرف بدون فاتورة',
                'السند: ' + (p.id || idx + 1),
                ''
            );
        } else {
            var invoiceExists = (typeof purchaseInvoices !== 'undefined') && 
                purchaseInvoices.some(function(inv) {
                    return inv && inv.id === p.invoiceId;
                });
            if (!invoiceExists) {
                _auditAddWarning(
                    'PAYMENT_INVOICE_MISSING',
                    'فاتورة شراء مرتبطة غير موجودة',
                    'السند: ' + (p.id || idx + 1),
                    'الفاتورة: ' + p.invoiceId
                );
            }
        }
    });
}

// ================================================================
// ===== 9. فحص التوازن (مدين = دائن لكل فاتورة) =====
// ================================================================

function _auditPaymentConsistency() {
    // ===== 1. فحص سداد فواتير البيع =====
    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)
        && typeof receipts !== 'undefined' && Array.isArray(receipts)) {

        salesInvoices.forEach(function(inv) {
            if (!inv) return;
            if (inv.status === 'ملغاة' || inv.cancelled) return;

            var c = inv.currency || 'SAR';

            // ===== استخدام المصدر الموحد =====
            if (typeof getInvoiceOutstanding === 'function') {
                var o = getInvoiceOutstanding(inv.id, 'sale');
                if (o && o.outstanding < -0.01) {
                    // ===== الرصيد السالب = رصيد دائن للعميل (ليس خطأ) =====
                    if (o.totalReturns > 0.01) {
                        _auditAddInfo(
                            'SALES_CUSTOMER_CREDIT',
                            'رصيد دائن لعميل (بسبب مرتجع)',
                            'الفاتورة: ' + inv.id + ' | العميل: ' + (inv.customerName || '-'),
                            'الإجمالي: ' + formatAmountWithCommas(o.invoiceTotal) + ' ' + c +
                            ' | المرتجعات: ' + formatAmountWithCommas(o.totalReturns) + ' ' + c +
                            ' | المقبوض: ' + formatAmountWithCommas(o.totalPaid) + ' ' + c +
                            ' | مستحق للعميل: ' + formatAmountWithCommas(Math.abs(o.outstanding)) + ' ' + c
                        );
                    } else {
                        _auditAddWarning(
                            'SALES_CUSTOMER_CREDIT_UNEXPLAINED',
                            'رصيد دائن لعميل (بدون مرتجع)',
                            'الفاتورة: ' + inv.id + ' | العميل: ' + (inv.customerName || '-'),
                            'الإجمالي: ' + formatAmountWithCommas(o.invoiceTotal) + ' ' + c +
                            ' | المقبوض: ' + formatAmountWithCommas(o.totalPaid) + ' ' + c +
                            ' | مستحق للعميل: ' + formatAmountWithCommas(Math.abs(o.outstanding)) + ' ' + c
                        );
                    }
                }
            } else {
                // ===== احتياطي: الطريقة القديمة =====
                var total = _auditNumber(inv.total);
                var paid = receipts.filter(function(r) {
                    return r && r.invoiceId === inv.id 
                        && r.cancelled !== true 
                        && r.documentStatus !== 'cancelled';
                }).reduce(function(sum, r) {
                    return sum + _auditNumber(r.amount);
                }, 0);

                if (paid > total + 0.01) {
                    _auditAddError(
                        'SALES_OVERPAYMENT',
                        'سداد زائد لفاتورة بيع',
                        'الفاتورة: ' + inv.id,
                        'الإجمالي: ' + total + ' | المقبوض: ' + paid
                    );
                }
            }
        });
    }

    // ===== 2. فحص سداد فواتير الشراء =====
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)
        && typeof payments !== 'undefined' && Array.isArray(payments)) {

        purchaseInvoices.forEach(function(inv) {
            if (!inv) return;
            if (inv.status === 'ملغاة' || inv.cancelled) return;

            var c = inv.currency || 'SAR';

            // ===== استخدام المصدر الموحد =====
            if (typeof getInvoiceOutstanding === 'function') {
                var o = getInvoiceOutstanding(inv.id, 'purchase');
                if (o && o.outstanding < -0.01) {
                    // ===== الرصيد السالب = رصيد دائن لنا عند المورد (ليس خطأ) =====
                    if (o.totalReturns > 0.01) {
                        _auditAddInfo(
                            'PURCHASE_SUPPLIER_CREDIT',
                            'رصيد دائن عند مورد (بسبب مرتجع)',
                            'الفاتورة: ' + inv.id + ' | المورد: ' + (inv.supplierName || '-'),
                            'الإجمالي: ' + formatAmountWithCommas(o.invoiceTotal) + ' ' + c +
                            ' | المرتجعات: ' + formatAmountWithCommas(o.totalReturns) + ' ' + c +
                            ' | المدفوع: ' + formatAmountWithCommas(o.totalPaid) + ' ' + c +
                            ' | مستحق لنا: ' + formatAmountWithCommas(Math.abs(o.outstanding)) + ' ' + c
                        );
                    } else {
                        _auditAddWarning(
                            'PURCHASE_SUPPLIER_CREDIT_UNEXPLAINED',
                            'رصيد دائن عند مورد (بدون مرتجع)',
                            'الفاتورة: ' + inv.id + ' | المورد: ' + (inv.supplierName || '-'),
                            'الإجمالي: ' + formatAmountWithCommas(o.invoiceTotal) + ' ' + c +
                            ' | المدفوع: ' + formatAmountWithCommas(o.totalPaid) + ' ' + c +
                            ' | مستحق لنا: ' + formatAmountWithCommas(Math.abs(o.outstanding)) + ' ' + c
                        );
                    }
                }
            } else {
                // ===== احتياطي: الطريقة القديمة =====
                var total = _auditNumber(inv.total);
                var paid = payments.filter(function(p) {
                    return p && !p.isExpense && p.invoiceId === inv.id 
                        && p.cancelled !== true 
                        && p.documentStatus !== 'cancelled';
                }).reduce(function(sum, p) {
                    return sum + _auditNumber(p.amount);
                }, 0);

                if (paid > total + 0.01) {
                    _auditAddError(
                        'PURCHASE_OVERPAYMENT',
                        'سداد زائد لفاتورة شراء',
                        'الفاتورة: ' + inv.id,
                        'الإجمالي: ' + total + ' | المدفوع: ' + paid
                    );
                }
            }
        });
    }
}

// ================================================================
// ===== 10. فحص أسعار الصرف =====
// ================================================================

function _auditExchangeRates() {
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';

    _auditAddInfo(
        'BASE_CURRENCY',
        'العملة المرجعية',
        'العملة الأساسية للنظام: ' + base,
        ''
    );

    if (typeof exchangeRates !== 'undefined') {
        Object.keys(exchangeRates).forEach(function(code) {
            var rate = _auditNumber(exchangeRates[code]);
            if (rate <= 0) {
                _auditAddError(
                    'INVALID_EXCHANGE_RATE',
                    'سعر صرف غير صالح',
                    'العملة: ' + code,
                    'السعر: ' + exchangeRates[code]
                );
            }
        });
    }
}


// ================================================================
// ===== 11. فحص المخزون السالب =====
// ================================================================

function _auditNegativeStock() {
    if (typeof products === 'undefined' || !Array.isArray(products)) return;

    products.forEach(function(p) {
        if (!p) return;
        var qty = _auditNumber(p.quantity);
        if (qty < 0) {
            _auditAddError(
                'NEGATIVE_STOCK',
                'مخزون سالب',
                'المنتج: ' + (p.name || '-'),
                'الكمية: ' + qty
            );
        }
    });
}

// ================================================================
// ===== 12.5 فحوصات المرتجعات =====
// ================================================================

function _auditReturns() {
    if (typeof returnsDocs === 'undefined' || !Array.isArray(returnsDocs)) {
        _auditAddInfo('RETURNS_EMPTY', 'لا توجد مرتجعات', 'لم يتم تسجيل أي مرتجع', '');
        return;
    }

    if (!returnsDocs.length) {
        _auditAddInfo('RETURNS_EMPTY', 'لا توجد مرتجعات', 'لم يتم تسجيل أي مرتجع', '');
        return;
    }

    var _auditNum = function(v) { return parseFloat(v) || 0; };

    // ===== عدد المرتجعات =====
    var activeReturns = returnsDocs.filter(function(r) {
        return r && r.cancelled !== true && r.documentStatus !== 'cancelled';
    });
    var cancelledReturns = returnsDocs.filter(function(r) {
        return r && (r.cancelled === true || r.documentStatus === 'cancelled');
    });

    _auditAddInfo(
        'RETURNS_SUMMARY',
        'ملخص المرتجعات',
        'المرتجعات النشطة: ' + activeReturns.length + ' | الملغاة: ' + cancelledReturns.length,
        'الإجمالي: ' + returnsDocs.length
    );

    // ===== تفاصيل كل مرتجع نشط =====
    activeReturns.forEach(function(r, idx) {
        if (!r) return;

        var kind = r.kind || 'sale';
        var kindLabel = kind === 'sale' ? 'مرتجع مبيعات' : 'مرتجع مشتريات';
        var invoiceId = r.invoiceId || '-';
        var partyName = r.partyName || '-';
        var productName = r.productName || '-';
        var qty = _auditNum(r.qty);
        var amount = _auditNum(r.amount);
        var currency = r.currency || 'SAR';
        var date = r.date || '-';

        // ===== 1. فحص الكمية =====
        if (qty <= 0) {
            _auditAddError(
                'RETURN_QTY_INVALID',
                'كمية مرتجع غير صحيحة',
                'المرتجع: ' + (r.id || idx + 1) + ' | الفاتورة: ' + invoiceId,
                'الكمية: ' + qty
            );
        }

        // ===== 2. فحص الفاتورة الأصلية =====
        var invoices = kind === 'sale'
            ? (typeof salesInvoices !== 'undefined' ? salesInvoices : [])
            : (typeof purchaseInvoices !== 'undefined' ? purchaseInvoices : []);

        var inv = invoices.find(function(x) { return x && x.id === invoiceId; });
        if (!inv) {
            _auditAddError(
                'RETURN_INVOICE_MISSING',
                'فاتورة المرتجع غير موجودة',
                'المرتجع: ' + (r.id || idx + 1),
                'الفاتورة: ' + invoiceId
            );
            return;
        }

        // ===== 3. تفاصيل المرتجع (معلومة) =====
        _auditAddInfo(
            'RETURN_DETAIL_' + (r.id || idx + 1),
            kindLabel + ' — ' + invoiceId,
            partyName + ' | ' + productName + ' | الكمية: ' + qty + ' | ' + date,
            'المرتجع: ' + (r.id || '-') + ' | القيمة: ' + formatAmountWithCommas(amount) + ' ' + currency
        );

        // ===== 4. فحص البند في الفاتورة =====
        var pid = r.productId;
        var item = (inv.items || []).find(function(x) { return x && x.productId === pid; });
        if (!item) {
            _auditAddWarning(
                'RETURN_ITEM_REMOVED',
                'بند المرتجع غير موجود في الفاتورة',
                'المرتجع: ' + (r.id || idx + 1),
                'المنتج: ' + (r.productName || pid) + ' — البند أُزيل بعد المرتجع'
            );
        }

        // ===== 5. فحص تجاوز الكمية =====
        var totalReturnsQty = activeReturns
            .filter(function(x) {
                return x && x.invoiceId === invoiceId && x.productId === pid;
            })
            .reduce(function(s, x) { return s + _auditNum(x.qty); }, 0);

        var originalQty = item ? _auditNum(item.qty) : 0;
        if (item && totalReturnsQty > originalQty + 0.0001) {
            _auditAddError(
                'RETURN_EXCEEDS_INVOICE',
                'المرتجع يتجاوز كمية الفاتورة',
                'الفاتورة: ' + invoiceId,
                'المنتج: ' + (r.productName || pid) +
                ' — المرتجع الكلي: ' + totalReturnsQty +
                ' | المتاح في الفاتورة: ' + originalQty
            );
        }

        // ===== 6. فحص قيمة المرتجع =====
        if (amount <= 0) {
            _auditAddWarning(
                'RETURN_AMOUNT_ZERO',
                'قيمة مرتجع صفرية',
                'المرتجع: ' + (r.id || idx + 1),
                'المنتج: ' + (r.productName || '-')
            );
        }
    });
}

    

// ================================================================
// ===== 12. ملخص عام =====
// ================================================================

function _auditTotals() {
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var salesTotal = 0;
    var purchasesTotal = 0;
    var receiptsTotal = 0;
    var paymentsTotal = 0;
    var expensesTotal = 0;

    // ✅ تحويل إلى العملة الأساسية
    function _convert(amount, currency, exchangeRate) {
        var a = _auditNumber(amount);
        var c = currency || base;
        if (c === base) return a;
        var rate = parseFloat(exchangeRate);
        if (isFinite(rate) && rate > 0) {
            var baseRate = (typeof getRate === 'function') ? getRate(base) : 1;
            return a * rate / (baseRate || 1);
        }
        if (typeof getEquivalent === 'function') return getEquivalent(a, c);
        return a;
    }

    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
        salesInvoices.forEach(function(inv) {
            if (inv && (inv.cancelled || inv.status === 'ملغاة')) return;
            salesTotal += _convert(inv && inv.total, inv && inv.currency, inv && inv.exchangeRate);
        });
    }
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
        purchaseInvoices.forEach(function(inv) {
            if (inv && (inv.cancelled || inv.status === 'ملغاة')) return;
            purchasesTotal += _convert(inv && inv.total, inv && inv.currency, inv && inv.exchangeRate);
        });
    }
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
            if (r && (r.cancelled || r.documentStatus === 'cancelled')) return;
            receiptsTotal += _convert(r && r.amount, r && r.currency, r && r.exchangeRate);
        });
    }
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (!p || p.archived) return;
            if (p.cancelled || p.documentStatus === 'cancelled') return;
            paymentsTotal += _convert(p.amount, p.currency, p.exchangeRate);
        });
    }
    if (typeof expenses !== 'undefined' && Array.isArray(expenses)) {
        expenses.forEach(function(e) {
            if (!e || e.archived) return;
            if (e.cancelled || e.documentStatus === 'cancelled') return;
            expensesTotal += _convert(e.amount, e.currency, e.exchangeRate);
        });
    }

    _auditAddInfo(
        'TOTAL_SALES',
        'إجمالي المبيعات',
        formatAmountWithCommas(salesTotal) + ' ' + base,
        'محوّلة إلى العملة الأساسية'
    );

    _auditAddInfo(
        'TOTAL_PURCHASES',
        'إجمالي المشتريات',
        formatAmountWithCommas(purchasesTotal) + ' ' + base,
        'محوّلة إلى العملة الأساسية'
    );

    _auditAddInfo(
        'TOTAL_RECEIPTS',
        'إجمالي المقبوضات',
        formatAmountWithCommas(receiptsTotal) + ' ' + base,
        'محوّلة إلى العملة الأساسية'
    );

    _auditAddInfo(
        'TOTAL_PAYMENTS',
        'إجمالي المدفوعات',
        formatAmountWithCommas(paymentsTotal) + ' ' + base,
        'محوّلة إلى العملة الأساسية'
    );

    _auditAddInfo(
        'TOTAL_EXPENSES',
        'إجمالي المصروفات',
        formatAmountWithCommas(expensesTotal) + ' ' + base,
        'محوّلة إلى العملة الأساسية'
    );
}
// ================================================================
// ===== 12-ب. فحص القيود المحاسبية (تكامل journal.js) =====
// ================================================================

function _auditAccountingIntegrity() {
    // التحقق من وجود دالة journal.js
    if (typeof auditAccountingIntegrity !== 'function') {
        _auditAddWarning(
            'JOURNAL_AUDIT_MISSING',
            'فحص القيود غير متوفر',
            'دالة auditAccountingIntegrity غير معرّفة — تحقق من journal.js',
            ''
        );
        return;
    }

    var result;
    try {
        result = auditAccountingIntegrity();
    } catch (e) {
        _auditAddError(
            'JOURNAL_AUDIT_FAILED',
            'فشل فحص القيود',
            'حدث خطأ أثناء فحص القيود المحاسبية',
            e.message || String(e)
        );
        return;
    }

    if (!result || typeof result !== 'object') {
        _auditAddWarning(
            'JOURNAL_AUDIT_EMPTY',
            'فحص القيود أعاد نتيجة فارغة',
            '',
            ''
        );
        return;
    }

    // 1. عدم التوازن العام (مدين ≠ دائن)
    if (result.ok === false) {
        var diff = (result.totalDebit || 0) - (result.totalCredit || 0);
        _auditAddError(
            'JOURNAL_UNBALANCED',
            'القيود غير متوازنة',
            'مجموع المدين ≠ مجموع الدائن',
            'المدين: ' + formatAmountWithCommas(result.totalDebit || 0) +
            ' | الدائن: ' + formatAmountWithCommas(result.totalCredit || 0) +
            ' | الفرق: ' + formatAmountWithCommas(Math.abs(diff)) +
            ' | عدد القيود: ' + (result.entries || 0)
        );
    } else {
        _auditAddInfo(
            'JOURNAL_BALANCED',
            'القيود متوازنة',
            'مجموع المدين = مجموع الدائن',
            'المدين: ' + formatAmountWithCommas(result.totalDebit || 0) +
            ' | عدد القيود: ' + (result.entries || 0)
        );
    }

    // 2. تفاصيل المشاكل (issues)
    var issues = result.issues || [];
    issues.forEach(function(issue) {
        var code = issue.code || issue.type || 'JOURNAL_ISSUE';
        var title = issue.title || issue.message || 'مشكلة في القيود';
        var desc = issue.description || '';
        var details = issue.details || '';

        if (issue.type === 'error') {
            _auditAddError('JOURNAL_' + code, title, desc, details);
        } else {
            _auditAddWarning('JOURNAL_' + code, title, desc, details);
        }
    });
}

// ================================================================
// ===== 13. تشغيل التدقيق =====
// ================================================================

function runAudit() {
    // إعادة تعيين الحالة
    _auditState.errors = [];
    _auditState.warnings = [];
    _auditState.infos = [];

    // 1) الفحوصات القديمة
    _auditProducts();
    _auditCustomers();
    _auditSuppliers();
    _auditSalesInvoices();
    _auditPurchaseInvoices();
    _auditReceipts();
    _auditPayments();
    _auditPaymentConsistency();
    _auditExchangeRates();
    _auditNegativeStock();
    _auditTotals();
    _auditReturns();
    _auditAccountingIntegrity();

    // 2) ✅ تشغيل قواعد التدقيق الجديدة (7 قواعد)
    if (typeof runRuleBasedAudit === 'function') {
        try {
            var ruleResults = runRuleBasedAudit({ phase: 1 });
            if (Array.isArray(ruleResults)) {
                ruleResults.forEach(function (r) {
                    if (r.type === 'error') {
                        _auditAddError(r.code, r.title, r.description, r.details);
                    } else if (r.type === 'warning') {
                        _auditAddWarning(r.code, r.title, r.description, r.details);
                    } else {
                        _auditAddInfo(r.code, r.title, r.description, r.details);
                    }
                });
            }
        } catch (e) {
            _auditAddError(
                'RULE_BASED_AUDIT_FAILED',
                'فشل تشغيل القواعد الجديدة',
                'حدث خطأ أثناء تشغيل AUDIT_RULES',
                e.message || String(e)
            );
        }
    }

    // 3) ✅ عرض النتائج
    _renderAuditResults();

    // 4) ✅ رسالة نجاح
    var total = _auditState.errors.length + _auditState.warnings.length + _auditState.infos.length;
    if (typeof showToast === 'function') {
        showToast('تم الفحص — ' + total + ' نتيجة', 'success');
    }
}
   


// ================================================================
// ===== 14. عرض النتائج =====
// ================================================================

function _renderAuditResults() {
    var container = document.getElementById('auditResults');
    if (!container) return;

    // تحديث الإحصائيات
    setText('auditErrorsCount', _auditState.errors.length);
    setText('auditWarningsCount', _auditState.warnings.length);
    setText('auditInfosCount', _auditState.infos.length);

    var total = _auditState.errors.length + _auditState.warnings.length + _auditState.infos.length;
    setText('auditTotalCount', total);

    // فلترة النتائج
    var items = [];
    if (_auditState.filter === 'all' || _auditState.filter === 'error') {
        items = items.concat(_auditState.errors);
    }
    if (_auditState.filter === 'all' || _auditState.filter === 'warning') {
        items = items.concat(_auditState.warnings);
    }
    if (_auditState.filter === 'all' || _auditState.filter === 'info') {
        items = items.concat(_auditState.infos);
    }

    if (!items.length) {
        container.innerHTML =
            '<div class="info-message" style="text-align:center;padding:30px;">' +
                'لا توجد نتائج في هذه الفئة.' +
            '</div>';
        return;
    }

    var html = '<div style="display:flex;flex-direction:column;gap:10px;">';

    items.forEach(function(item) {
        var color, bg, border, icon;

        if (item.type === 'error') {
            color = 'var(--color-red)';
            bg = 'rgba(255,71,87,0.08)';
            border = 'rgba(255,71,87,0.3)';
            icon = '🔴';
        } else if (item.type === 'warning') {
            color = 'var(--color-gold)';
            bg = 'rgba(247,147,30,0.08)';
            border = 'rgba(247,147,30,0.3)';
            icon = '🟡';
        } else {
            color = 'var(--color-blue)';
            bg = 'rgba(0,212,255,0.08)';
            border = 'rgba(0,212,255,0.3)';
            icon = '🔵';
        }

        html += '<div style="background:' + bg + ';border:1px solid ' + border + ';border-radius:10px;padding:12px;">' +
            '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;flex-wrap:wrap;">' +
                '<div style="text-align:right;flex:1;min-width:0;">' +
                    '<div style="font-size:13px;font-weight:800;color:' + color + ';">' +
                        icon + ' ' + esc(item.title) +
                    '</div>' +
                    '<div style="font-size:11px;color:var(--color-text-3);font-family:monospace;margin-top:2px;">' +
                        esc(item.code) +
                    '</div>' +
                '</div>' +
            '</div>' +
            (item.description ?
                '<div style="font-size:12px;color:var(--color-text-2);margin-top:8px;line-height:1.7;">' +
                    esc(item.description) +
                '</div>'
                : '') +
            (item.details ?
                '<div style="font-size:11px;color:var(--color-text-3);margin-top:6px;line-height:1.6;">' +
                    esc(item.details) +
                '</div>'
                : '') +
        '</div>';
    });

    html += '</div>';

    container.innerHTML = html;
}


// ================================================================
// ===== 15. فلترة النتائج =====
// ================================================================

function filterAuditResults(filter) {
    _auditState.filter = filter;

    ['all', 'error', 'warning', 'info'].forEach(function(f) {
        var btn = document.getElementById('auditFilter_' + f);
        if (btn) {
            if (f === filter) btn.classList.add('active');
            else btn.classList.remove('active');
        }
    });

    _renderAuditResults();
}

// ================================================================
// ===== 15.5 تصدير PDF =====
// ================================================================

function exportAuditPDF() {
    // إذا لم تكن هناك نتائج — شغّل الفحص أولاً
    if (_auditState.errors.length === 0 &&
        _auditState.warnings.length === 0 &&
        _auditState.infos.length === 0) {
        runAudit();
    }

    var settings = (typeof Storage !== 'undefined')
        ? (Storage.get(STORAGE_KEYS.SETTINGS, {}) || {})
        : {};
    var companyName = settings.name || 'Open Account';

    // إحصائيات
    var statsHtml =
        '<div class="doc-meta-grid">' +
            '<div><strong>🔴 أخطاء:</strong> ' + _auditState.errors.length + '</div>' +
            '<div><strong>🟡 تحذيرات:</strong> ' + _auditState.warnings.length + '</div>' +
            '<div><strong>🔵 معلومات:</strong> ' + _auditState.infos.length + '</div>' +
            '<div><strong>الإجمالي:</strong> ' +
                (_auditState.errors.length + _auditState.warnings.length + _auditState.infos.length) +
            '</div>' +
            '<div><strong>تاريخ الفحص:</strong> ' + todayISO() + '</div>' +
            '<div><strong>العملة المرجعية:</strong> ' +
                (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER') +
            '</div>' +
        '</div>';

    // جمع النتائج
    var allItems = [];
    _auditState.errors.forEach(function(i) { allItems.push(i); });
    _auditState.warnings.forEach(function(i) { allItems.push(i); });
    _auditState.infos.forEach(function(i) { allItems.push(i); });

    // بناء الجدول
    var tableHtml = '<table class="doc-table" style="width:100%;border-collapse:collapse;font-size:11px;">' +
        '<thead>' +
            '<tr>' +
                '<th style="width:30px;">#</th>' +
                '<th style="width:70px;">النوع</th>' +
                '<th>العنوان</th>' +
                '<th>التفاصيل</th>' +
            '</tr>' +
        '</thead>' +
        '<tbody>';

    allItems.forEach(function(item, i) {
        var typeLabel = item.type === 'error' ? '🔴 خطأ'
                      : item.type === 'warning' ? '🟡 تحذير'
                      : '🔵 معلومة';
        var rowBg = item.type === 'error' ? '#fff5f5'
                   : item.type === 'warning' ? '#fffbf0'
                   : '#f0f9ff';

        var detailText = item.description || '';
        if (item.details) {
            detailText += (detailText ? ' | ' : '') + item.details;
        }
        if (!detailText) detailText = '—';

        tableHtml += '<tr style="background:' + rowBg + ';">' +
            '<td>' + (i + 1) + '</td>' +
            '<td style="text-align:center;">' + typeLabel + '</td>' +
            '<td style="text-align:right;padding-right:8px;">' +
                esc(item.title) +
                '<br><small style="font-family:monospace;font-size:9px;color:#666;">' +
                esc(item.code) + '</small>' +
            '</td>' +
            '<td style="text-align:right;padding-right:8px;">' + esc(detailText) + '</td>' +
        '</tr>';
    });

    tableHtml += '</tbody></table>';

    // بناء المستند الكامل
    var html = '<div class="doc-wrapper">' +
        '<div class="doc-header">' +
            '<div class="company-name">' + esc(companyName) + '</div>' +
        '</div>' +
        '<div class="doc-title">تقرير التدقيق</div>' +
        statsHtml +
        '<div style="margin:16px 0 8px;font-weight:800;color:#1a1a2e;font-size:14px;">' +
            'النتائج (' + allItems.length + ')' +
        '</div>' +
        tableHtml +
        '<div class="doc-footer">' +
            'تقرير تدقيق رقمي' +
            '<small>هذا المستند معتمد رقمياً</small>' +
        '</div>' +
    '</div>';

    // فتح معاينة الطباعة
    Modal.open({
        id: 'auditPrintModal',
        title: 'معاينة تقرير التدقيق',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'auditPrintModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
    });
}



// ================================================================
// ===== 16. التهيئة =====
// ================================================================

function initAudit() {
    // تشغيل التدقيق تلقائياً عند فتح التبويب (المرة الأولى فقط)
    if (_auditState.errors.length === 0
        && _auditState.warnings.length === 0
        && _auditState.infos.length === 0) {
        runAudit();
    } else {
        _renderAuditResults();
    }

    console.log('Audit: initialized');
}
// ================================================================
// ===== طباعة تقرير التدقيق (القالب الجديد) =====
// ================================================================

function printAuditReport() {
    // 1. اقرأ نتائج التدقيق
    var container = document.getElementById('auditResults');
    if (!container) {
        if (typeof showToast === 'function') showToast('لم يتم العثور على نتائج التدقيق', 'error');
        return;
    }

    var resultsHtml = container.innerHTML;

    // 2. اقرأ الإحصائيات
    function getNum(id) {
        var el = document.getElementById(id);
        if (!el) return 0;
        var n = parseInt(el.textContent);
        return isNaN(n) ? 0 : n;
    }

    var errors = getNum('auditErrorsCount');
    var warnings = getNum('auditWarningsCount');
    var infos = getNum('auditInfosCount');
    var total = getNum('auditTotalCount');

    // 3. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 4. الحمولة
    var payload = {
        type: 'audit_report',
        resultsHtml: resultsHtml,
        settings: settings,
        meta: {
            date: new Date().toISOString().split('T')[0],
            errors: errors,
            warnings: warnings,
            infos: infos,
            total: total
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 5. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/audit-report.html';
    window.location.href = url;
}

// ================================================================
// ===== END OF AUDIT.JS =====
// ================================================================