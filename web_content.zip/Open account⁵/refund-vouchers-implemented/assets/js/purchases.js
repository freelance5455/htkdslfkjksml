// ================================================================
// Open Account — نظام محاسبي
// الملف: purchases.js
// الوصف: فواتير الشراء
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var purchaseInvoices = [];
var currentPurchaseItems = [];
// ✅ وضع الأرشفة
var _archivePurchasesMode = false;
var _showArchivedPurchases = false;
var _selectedPurchasesForArchive = {};

// ================================================================
// ===== 2. تحميل وحفظ فواتير الشراء =====
// ================================================================

function loadPurchaseInvoices() {
    purchaseInvoices = Storage.get(STORAGE_KEYS.PURCHASES, []);
    if (!Array.isArray(purchaseInvoices)) purchaseInvoices = [];
    
    var needsSave = false;
    
    purchaseInvoices.forEach(function(inv) {
        if (!inv) return;
        
        // قيم افتراضية للفواتير القديمة
        if (inv.discount === undefined) inv.discount = 0;
        if (inv.subtotal === undefined) {
            inv.subtotal = (inv.items || []).reduce(function(s, i) {
                return s + (parseFloat(i.price) || 0) * (parseInt(i.qty) || 0);
            }, 0);
        }
        
        // ===== ترحيل 3 أبعاد للفواتير القديمة =====
        if (inv.documentStatus === undefined) {
            inv.documentStatus = (inv.status === 'ملغاة' || inv.cancelled) ? 'cancelled' : 'active';
            needsSave = true;
        }
        if (inv.paymentStatus === undefined) {
            if (inv.status === 'مسدد') inv.paymentStatus = 'paid';
            else if (inv.status === 'دفع جزئي') inv.paymentStatus = 'partial';
            else inv.paymentStatus = 'unpaid';
            needsSave = true;
        }
        if (inv.returnStatus === undefined) {
            inv.returnStatus = 'none';
            needsSave = true;
        }
    });
    
    if (needsSave) {
        savePurchaseInvoices();
    }
}


function savePurchaseInvoices() {
    Storage.set(STORAGE_KEYS.PURCHASES, purchaseInvoices);
}


// ================================================================
// ===== 3. عرض جدول فواتير الشراء =====
// ================================================================

function renderPurchaseInvoices() {
    var tbody = document.getElementById('purchTableBody');
    if (!tbody) return;

    var searchEl = document.getElementById('purchSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';

    // ✅ فلترة المؤرشفة
    var filtered = purchaseInvoices.filter(function(inv) {
        if (_showArchivedPurchases) return inv.archived === true;
        return inv.archived !== true;
    });

    if (search) {
        filtered = filtered.filter(function (inv) {
            return String(inv.supplierName || '').toLowerCase().indexOf(search) !== -1 ||
                   String(inv.id || '').indexOf(search) !== -1;
        });
    }

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">' +
    (_showArchivedPurchases ? 'لا توجد فواتير مؤرشفة' : 'لا توجد فواتير') +
    '</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function (inv, i) {
            var statusClass = (inv.status === 'ملغاة' || inv.cancelled) ? 'status-cancelled' : (inv.status === 'مسدد' ? 'status-paid' : inv.status === 'دفع جزئي' ? 'status-partial' : 'status-unpaid');

            // ✅ checkbox في وضع الأرشفة
            var firstCell = (i + 1);
            if (_archivePurchasesMode && !_showArchivedPurchases) {
                var checked = _selectedPurchasesForArchive[inv.id] ? 'checked' : '';
                firstCell = '<input type="checkbox" class="purch-archive-cb" data-id="' + inv.id + '" ' + checked + ' onchange="onPurchasesArchiveCheckboxChange(this)">';
            }

            // ✅ أزرار الإجراءات
            var actionsHtml = '';
            if (_showArchivedPurchases) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewPurchaseInvoice(\'' + inv.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    '<button class="btn-edit" onclick="restorePurchaseInvoice(\'' + inv.id + '\')" title="استرجاع" style="margin-right:4px;">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>' +
                    '</button>';
            } else if (!_archivePurchasesMode) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewPurchaseInvoice(\'' + inv.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    (inv.status === 'ملغاة' || inv.cancelled ? '' : '<button class="btn-delete" onclick="cancelPurchaseInvoice(\'' + inv.id + '\')" title="إلغاء الفاتورة"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>');
            }

           html += '<tr>' +
    '<td>' + firstCell + '</td>' +
    '<td><strong style="font-family:monospace;font-size:12px;color:var(--color-blue);">' + esc(inv.id) + '</strong></td>' +
    '<td>' + esc(inv.supplierName) +
        (inv.returnStatus === 'partial' ? ' <span style="background:#f7931e;color:#fff;font-size:9px;padding:1px 5px;border-radius:6px;font-weight:700;">مرتجع جزئي</span>' : '') +
        (inv.returnStatus === 'full' ? ' <span style="background:#888;color:#fff;font-size:9px;padding:1px 5px;border-radius:6px;font-weight:700;">مرتجع كلي</span>' : '') +
    '</td>' +
    '<td>' + formatDate(inv.date) + '</td>' +
    '<td>' + displayAmount(inv.total, inv.currency) + '</td>' +
    '<td><span class="status-badge ' + statusClass + '"><span class="status-dot"></span>' + inv.status + '</span></td>' +
    '<td>' + actionsHtml + '</td>' +
'</tr>';
        });
        tbody.innerHTML = html;
    }

    // ✅ شريط أدوات الأرشفة
    _renderPurchasesArchiveToolbar();

    updatePurchaseStats();
}

// ✅ شريط أدوات الأرشفة
function _renderPurchasesArchiveToolbar() {
    var bar = document.getElementById('purchasesArchiveBar');
    if (!bar) return;

    if (!_archivePurchasesMode) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    var count = Object.keys(_selectedPurchasesForArchive).length;
    bar.style.display = 'flex';
    bar.innerHTML =
        '<button class="btn btn-secondary" onclick="toggleSelectAllPurchases()" style="flex:1;font-size:12px;">' +
            (_allActivePurchasesSelected() ? 'إلغاء الكل' : 'تحديد الكل') +
        '</button>' +
        '<button class="btn btn-warning" onclick="confirmArchivePurchases()" style="flex:1;font-size:12px;" ' + (count === 0 ? 'disabled' : '') + '>' +
            'أرشفة المحدد (' + count + ')' +
        '</button>' +
        '<button class="btn btn-cancel" onclick="toggleArchivePurchasesMode()" style="flex:1;font-size:12px;">' +
            'إلغاء' +
        '</button>';
}

function _allActivePurchasesSelected() {
    var active = purchaseInvoices.filter(function(i) { return !i.cancelled && !i.archived; });
    if (!active.length) return false;
    return active.every(function(i) { return _selectedPurchasesForArchive[i.id]; });
}

// ✅ دوال الأرشفة
function toggleArchivePurchasesMode() {
    _archivePurchasesMode = !_archivePurchasesMode;
    _selectedPurchasesForArchive = {};
    if (_archivePurchasesMode) _showArchivedPurchases = false;
    renderPurchaseInvoices();
}

function toggleShowArchivedPurchases() {
    _showArchivedPurchases = !_showArchivedPurchases;
    _archivePurchasesMode = false;
    _selectedPurchasesForArchive = {};
    renderPurchaseInvoices();
}

function onPurchasesArchiveCheckboxChange(cb) {
    var id = cb.getAttribute('data-id');
    if (cb.checked) _selectedPurchasesForArchive[id] = true;
    else delete _selectedPurchasesForArchive[id];
    _renderPurchasesArchiveToolbar();
}

function toggleSelectAllPurchases() {
    var active = purchaseInvoices.filter(function(i) { return !i.cancelled && !i.archived; });
    if (_allActivePurchasesSelected()) {
        _selectedPurchasesForArchive = {};
    } else {
        active.forEach(function(i) { _selectedPurchasesForArchive[i.id] = true; });
    }
    renderPurchaseInvoices();
}

function confirmArchivePurchases() {
    var ids = Object.keys(_selectedPurchasesForArchive);
    if (!ids.length) { showToast('لم تحدد أي فاتورة', 'warning'); return; }
    if (!confirm('سيتم أرشفة ' + ids.length + ' فاتورة.\nستُخفى من العرض — لا تُحذف.\n\nمتابعة؟')) return;

    var count = 0;
    purchaseInvoices.forEach(function(inv) {
        if (_selectedPurchasesForArchive[inv.id]) {
            inv.archived = true;
            inv.archivedAt = new Date().toISOString();
            count++;
        }
    });

    savePurchaseInvoices();
    _archivePurchasesMode = false;
    _selectedPurchasesForArchive = {};
    renderPurchaseInvoices();
    showToast('تمت أرشفة ' + count + ' فاتورة', 'success');
}

function restorePurchaseInvoice(id) {
    var inv = purchaseInvoices.find(function(x) { return x.id === id; });
    if (!inv) return;
    inv.archived = false;
    delete inv.archivedAt;
    savePurchaseInvoices();
    renderPurchaseInvoices();
    showToast('تم استرجاع الفاتورة', 'success');
}


// ================================================================
// ===== 4. إحصائيات فواتير الشراء =====
// ================================================================

function updatePurchaseStats() {
    setText('purchCount', purchaseInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).length);
    
    var total = 0;
    var subtotalTotal = 0;
    var discountTotal = 0;
    purchaseInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function(inv) {
        var _amt = parseFloat(inv.total) || 0;
if (inv.currency && typeof getEquivalent === 'function') _amt = getEquivalentAtRate(_amt, inv.currency, inv.exchangeRate);
total += _amt;
var _subtotal = parseFloat(inv.subtotal !== undefined ? inv.subtotal : inv.total) || 0;
if (inv.currency && typeof getEquivalent === 'function') _subtotal = getEquivalentAtRate(_subtotal, inv.currency, inv.exchangeRate);
subtotalTotal += _subtotal;
var _discount = parseFloat(inv.discount) || 0;
if (inv.currency && typeof getEquivalent === 'function') _discount = getEquivalentAtRate(_discount, inv.currency, inv.exchangeRate);
discountTotal += _discount;
    });
    setText('purchTotal', formatAmountWithCommas(total));
    setText('purchDiscountTotal', formatAmountWithCommas(discountTotal));
    setText('purchSubtotalTotal', formatAmountWithCommas(subtotalTotal));
    
    var paid = purchaseInvoices.filter(function(inv) { return inv.status === 'مسدد'; }).length;
    var unpaid = purchaseInvoices.filter(function(inv) { return inv.status === 'غير مسدد'; }).length;
    setText('purchPaid', paid);
    setText('purchUnpaid', unpaid);
    
    setText('dashPurchases', formatAmountWithCommas(total));
}


// ================================================================
// ===== 5. نافذة فاتورة شراء جديدة =====
// ================================================================

function openPurchaseModal() {
    currentPurchaseItems = [];
    
    if (!suppliers || suppliers.length === 0) {
        showToast('يرجى إضافة مورد أولاً', 'error');
        return;
    }
    
    if (!products || products.length === 0) {
        showToast('يرجى إضافة منتج أولاً', 'error');
        return;
    }
    
    var bodyHTML = _buildPurchaseFormHTML();
    
    var footerHTML = 
        '<button class="btn btn-cancel" onclick="closeModal(\'purchaseModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="savePurchase()">حفظ الفاتورة</button>';
    
    Modal.open({
        id: 'purchaseModal',
        title: 'فاتورة شراء جديدة',
        size: 'large',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            _populatePurchaseSuppliers();
            _populatePurchaseProducts();
            
            var dateEl = modalEl.querySelector('#purchaseDate');
            if (dateEl) dateEl.value = todayISO();
        }
    });
}


// ================================================================
// ===== 6. بناء HTML نموذج فاتورة الشراء =====
// ================================================================

function _buildPurchaseFormHTML() {
    return '' +
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>المورد</label>' +
                '<select id="purchaseSupplier">' +
                    '<option value="">— اختر مورد —</option>' +
                '</select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="purchaseDate">' +
            '</div>' +
        '</div>' +
        
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>رقم فاتورة المورد</label>' +
                '<input type="text" id="purchaseSupplierNumber" placeholder="INV-001">' +
            '</div>' +
            '<div class="form-field">' +
                '<label>العملة</label>' +
                '<select id="purchaseCurrency" class="currency-select">' +
                    '<option value="YER">ريال يمني</option>' +
                    '<option value="SAR">ريال سعودي</option>' +
                    '<option value="USD">دولار أمريكي</option>' +
                '</select>' +
            '</div>' +
        '</div>' +
        
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>نوع الفاتورة</label>' +
                '<select id="purchaseType">' +
                    '<option value="أجل">أجل</option>' +
                    '<option value="نقدي">نقدي</option>' +
                '</select>' +
            '</div>' +
        '</div>' +
        
        '<div class="section-label">' +
            '<span>المنتجات</span>' +
        '</div>' +
        
       '<div class="sales-items-wrap purchase-items-wrap">' +
    '<div class="sales-items-line sales-line-1">' +
        '<select id="purchaseProductSelect">' +
            '<option value="">— اختر منتج —</option>' +
        '</select>' +
    '</div>' +
    '<div class="sales-items-line sales-line-2">' +
        '<select id="purchaseProductUnit"><option value="">الوحدة</option></select>' +
        '<input type="number" id="purchaseProductQty" placeholder="الكمية" value="1" min="0.000001" step="0.000001">' +
        '<input type="number" id="purchaseProductPrice" placeholder="سعر شراء الوحدة" min="0" step="0.01">' +
        '<button class="btn btn-add" onclick="addProductToPurchase()" title="إضافة">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
                '<line x1="12" y1="5" x2="12" y2="19"/>' +
                '<line x1="5" y1="12" x2="19" y2="12"/>' +
            '</svg>' +
        '</button>' +
    '</div>' +
'</div>' +
'<div id="purchaseBaseUnitHint" class="form-hint" style="margin-top:-8px;margin-bottom:10px;text-align:right;"></div>' +
        
        '<div class="items-list" id="purchaseItemsList">' +
            '<div class="empty-items">لا توجد منتجات مضافة</div>' +
        '</div>' +
        
        '<div class="form-field"><label>الخصم (مبلغ ثابت)</label><input type="number" id="purchaseDiscount" min="0" step="0.01" value="0" oninput="updatePurchaseTotal()"></div>' +
        '<div class="total-display"><span>الإجمالي قبل الخصم:</span><strong id="purchaseSubtotalDisplay">0.00</strong></div>' +
        '<div class="total-display"><span>الخصم:</span><strong id="purchaseDiscountDisplay">0.00</strong></div>' +
        '<div class="total-display"><span>الإجمالي النهائي:</span><strong id="purchaseTotalDisplay">0.00</strong></div>';
}


// ================================================================
// ===== 7. ملء القوائم =====
// ================================================================

function _populatePurchaseSuppliers() {
    var selectEl = document.getElementById('purchaseSupplier');
    if (!selectEl) return;
    
    var html = '<option value="">— اختر مورد —</option>';
    suppliers.forEach(function(s) {
        html += '<option value="' + s.id + '">' + esc(s.name) + '</option>';
    });
    selectEl.innerHTML = html;
}


function _populatePurchaseProducts() {
    var selectEl = document.getElementById('purchaseProductSelect');
    if (!selectEl) return;
    
    var html = '<option value="">— اختر منتج —</option>';
    products.forEach(function(p) {
        var label = p.name + ' — ' + (p.baseUnit || p.unit || 'وحدة');
        html += '<option value="' + p.id + '">' + esc(label) + '</option>';
    });
    selectEl.innerHTML = html;
    
    selectEl.onchange = function() {
        _onPurchaseProductChange();
    };
    _populatePurchaseUnits();
}

function _purchaseUnitFactor(product, unitName) {
    var units = product && Array.isArray(product.units) ? product.units : [];
    var unit = units.find(function(u) { return u.name === unitName; });
    return unit ? (Number(unit.factor) || 1) : 1;
}

function _populatePurchaseUnits() {
    var productEl = document.getElementById('purchaseProductSelect');
    var unitEl = document.getElementById('purchaseProductUnit');
    if (!productEl || !unitEl) return;
    var product = products.find(function(p) { return p.id === productEl.value; });
    var units = product && Array.isArray(product.units) && product.units.length ? product.units.filter(function(u) { return u.isPurchaseUnit !== false; }) : [];
    if (!units.length && product) units = [{ name: product.baseUnit || product.unit || 'وحدة', factor: 1, isBase: true }];
    unitEl.innerHTML = units.map(function(u) { return '<option value="' + esc(u.name) + '">' + esc(u.name) + '</option>'; }).join('');
    var display = units.find(function(u) { return !u.isBase; }) || units[0];
    if (display) unitEl.value = display.name;
    var hint = document.getElementById('purchaseBaseUnitHint');
    if (hint && product) hint.textContent = 'الوحدة الأساسية: ' + (product.baseUnit || product.unit || 'وحدة') + ' — معامل التحويل: ' + _purchaseUnitFactor(product, unitEl.value);
}


function _onPurchaseProductChange() {
    var productIdEl = document.getElementById('purchaseProductSelect');
    if (!productIdEl) return;
    var productId = productIdEl.value;
    if (!productId) return;
    var product = products.find(function(p) { return p.id === productId; });
    if (!product) return;
    _populatePurchaseUnits();
}


// ================================================================
// ===== 8. إضافة منتج للفاتورة =====
// ================================================================

function addProductToPurchase() {
    var productIdEl = document.getElementById('purchaseProductSelect');
    var qtyEl = document.getElementById('purchaseProductQty');
    var unitEl = document.getElementById('purchaseProductUnit');
    var priceEl = document.getElementById('purchaseProductPrice');
    var currencyEl = document.getElementById('purchaseCurrency');
    
    var productId = productIdEl ? productIdEl.value : '';
    var inputQty = parseFloat(qtyEl ? qtyEl.value : 0) || 0;
    var inputPrice = parseFloat(priceEl ? priceEl.value : NaN);
    
    if (!productId) {
        showToast('يرجى اختيار منتج', 'error');
        return;
    }
    
    if (inputQty <= 0) {
        showToast('يرجى إدخال كمية صحيحة', 'error');
        return;
    }
    if (!isFinite(inputPrice) || inputPrice < 0) {
        showToast('يرجى إدخال سعر شراء الوحدة', 'error');
        return;
    }
    
    var product = products.find(function(p) { return p.id === productId; });
    if (!product) return;
    
    var inputUnit = unitEl && unitEl.value ? unitEl.value : (product.baseUnit || product.unit || 'وحدة');
    var factor = _purchaseUnitFactor(product, inputUnit);
    var baseQty = inputQty * factor;
    var baseUnitCost = factor > 0 ? inputPrice / factor : inputPrice;

currentPurchaseItems.push({
            productId: product.id,
            name: product.name,
            price: baseUnitCost,
            qty: baseQty,
            inputUnit: inputUnit,
            inputQty: inputQty,
            inputUnitPrice: inputPrice,
            baseUnit: product.baseUnit || product.unit || 'وحدة',
            conversionFactor: factor
        });
    
    renderPurchaseItems();
    
    if (qtyEl) qtyEl.value = 1;
    if (priceEl) priceEl.value = '';
    
    showToast('تم إضافة المنتج', 'success');
}


// ================================================================
// ===== 9. عرض وإزالة المنتجات =====
// ================================================================

function renderPurchaseItems() {
    var container = document.getElementById('purchaseItemsList');
    if (!container) return;
    
    if (!currentPurchaseItems.length) {
        container.innerHTML = '<div class="empty-items">لا توجد منتجات مضافة</div>';
        updatePurchaseTotal();
        return;
    }
    
    var html = '';
    currentPurchaseItems.forEach(function(item, index) {
        var lineTotal = (item.price || 0) * (item.qty || 0);
        var displayQty = item.inputQty !== undefined ? item.inputQty : item.qty;
        var displayUnit = item.inputUnit || item.baseUnit || 'وحدة';
        var displayPrice = item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price;
        html += '<div class="item-row">' +
            '<span>' + esc(item.name) + '</span>' +
            '<span>' + displayQty + ' ' + esc(displayUnit) + ' × ' + formatAmountWithCommas(displayPrice) + ' = ' + formatAmountWithCommas(lineTotal) + '</span>' +
            '<button onclick="removePurchaseItem(' + index + ')" title="إزالة">×</button>' +
        '</div>';
    });
    container.innerHTML = html;
    
    updatePurchaseTotal();
}


function removePurchaseItem(index) {
    if (index < 0 || index >= currentPurchaseItems.length) return;
    currentPurchaseItems.splice(index, 1);
    renderPurchaseItems();
}


function updatePurchaseTotal() {
    var subtotal = 0;
    currentPurchaseItems.forEach(function(item) {
        subtotal += (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
    });
    var discountEl = document.getElementById('purchaseDiscount');
    var discount = Math.max(0, parseFloat(discountEl ? discountEl.value : 0) || 0);
    if (discount > subtotal && discountEl) { discount = subtotal; discountEl.value = subtotal; }
    setText('purchaseSubtotalDisplay', formatAmountWithCommas(subtotal));
    setText('purchaseDiscountDisplay', formatAmountWithCommas(discount));
    setText('purchaseTotalDisplay', formatAmountWithCommas(subtotal - discount));
}


// ================================================================
// ===== 10. حفظ فاتورة الشراء =====
// ================================================================

function savePurchase() {
    var supEl = document.getElementById('purchaseSupplier');
    var dateEl = document.getElementById('purchaseDate');
    var typeEl = document.getElementById('purchaseType');
    var currencyEl = document.getElementById('purchaseCurrency');
    var supNumEl = document.getElementById('purchaseSupplierNumber');
    
    var supplierId = supEl ? supEl.value : '';
    var date = dateEl ? dateEl.value : '';
    var type = typeEl ? typeEl.value : 'أجل';
    var currency = currencyEl ? currencyEl.value : (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER');
    var supplierNumber = supNumEl ? supNumEl.value.trim() : '';
    var discountEl = document.getElementById('purchaseDiscount');
    
    if (!supplierId) {
        showToast('يرجى اختيار المورد', 'error');
        return;
    }
    
    if (!date) {
        showToast('يرجى اختيار التاريخ', 'error');
        return;
    }

    if (!currentPurchaseItems.length) {
        showToast('يرجى إضافة منتجات', 'error');
        return;
    }
    
    var supplier = suppliers.find(function(s) { return s.id === supplierId; });
    if (!supplier) {
        showToast('المورد غير موجود', 'error');
        return;
    }
    
    var subtotal = 0;
    currentPurchaseItems.forEach(function(item) {
        subtotal += (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
    });
    var discount = Math.max(0, parseFloat(discountEl ? discountEl.value : 0) || 0);
    if (discount > subtotal) { showToast('الخصم لا يمكن أن يتجاوز إجمالي الأصناف', 'error'); return; }
    var total = subtotal - discount;

    // ============================================================
    // التحقق من رصيد الصندوق عند الشراء النقدي
    // ============================================================
    if (type === 'نقدي') {
        if (typeof checkSufficientBalance !== 'function') {
            showToast('دالة التحقق من الرصيد غير متاحة', 'error');
            return;
        }
        var balanceCheck = checkSufficientBalance('cashbox', currency, total);
        if (!balanceCheck.ok) {
            _showInsufficientBalanceDialog(balanceCheck, currency);
            return;
        }
    }

    // ============================================================
    // 1. إنشاء الفاتورة أولاً — للحصول على invoice.id قبل حركة المخزون
    // ============================================================
    var invoiceId = generateId();
    var invoice = {
        id: invoiceId,
        supplierId: supplierId,
        supplierName: supplier.name,
        supplierInvoiceNumber: supplierNumber || '-',
        date: date,
        type: type,
        currency: currency,
        exchangeRate: typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(currency) : 1,
        items: currentPurchaseItems.map(function(item) {
            return {
                productId: item.productId,
                name: item.name,
                price: parseFloat(item.price) || 0,
                qty: parseFloat(item.qty) || 0,
                inputUnit: item.inputUnit || item.baseUnit || 'وحدة',
                inputQty: parseFloat(item.inputQty !== undefined ? item.inputQty : item.qty) || 0,
                inputUnitPrice: parseFloat(item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price) || 0,
                baseUnit: item.baseUnit || item.inputUnit || 'وحدة',
                conversionFactor: parseFloat(item.conversionFactor) || 1,
                baseQty: parseFloat(item.qty) || 0,
                baseUnitCost: parseFloat(item.price) || 0
            };
        }),
        subtotal: subtotal,
        discount: discount,
        total: total,
        documentStatus: 'active',
        paymentStatus: type === 'نقدي' ? 'paid' : 'unpaid',
        returnStatus: 'none',
        status: type === 'نقدي' ? 'مسدد' : 'غير مسدد'
    };

    purchaseInvoices.push(invoice);

    // ============================================================
    // 2. إضافة الكميات للمخزون + تسجيل حركة مخزنية بـ docId الحقيقي
    // ============================================================
    currentPurchaseItems.forEach(function(item) {
        var product = products.find(function(p) { return p.id === item.productId; });
        if (product) {
            var currentQty = parseFloat(product.quantity) || 0;
            var purchaseUnitCost = getPurchaseNetUnitCost(item, subtotal, discount);
            var invoiceRate = (typeof getCurrentExchangeRateSnapshot === 'function')
                ? getCurrentExchangeRateSnapshot(currency)
                : 1;

            if (typeof applyWeightedAverageCost === 'function') {
                applyWeightedAverageCost(product, item.qty, purchaseUnitCost, currency, invoiceRate);
            }

            product.purchasePrice = parseFloat(item.price) || 0;
            if ((product.type || product.productType || 'raw') === 'raw') {
                product.price = parseFloat(item.price) || 0;
                product.salePrice = product.price;
            }
            product.currency = currency;
            product.quantity = currentQty + item.qty;

            // ✅ تسجيل حركة مخزنية — docId = invoice.id (الحقيقي)
            if (typeof recordStockMovement === 'function') {
                recordStockMovement({
                    date: date,
                    type: 'in',
                    docType: 'فاتورة شراء',
                    docId: invoiceId,
                    productId: product.id,
                    productName: product.name,
                    qty: item.qty,
                    price: purchaseUnitCost,
                    currency: currency,
                    note: 'فاتورة شراء من ' + supplier.name
                });
            }
        }
    });
    saveProducts();

    // ============================================================
    // 3. سند صرف تلقائي للنقدي
    // ============================================================
    if (type === 'نقدي') {
        if (typeof payments !== 'undefined' && Array.isArray(payments)) {
            payments.push({
                id: generateId(),
                invoiceId: invoice.id,
                supplierId: supplierId,
                supplierName: supplier.name,
                amount: total,
                currency: currency,
                exchangeRate: (typeof getCurrentExchangeRateSnapshot === 'function') ? getCurrentExchangeRateSnapshot(currency) : 1,
                date: date,
                method: 'نقدي',
                note: 'دفع نقدي للفاتورة',
                invoiceTotal: total,
                paidBefore: 0,
                remainingAfter: 0,
                status: 'مدفوع بالكامل'
            });
            
            if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
                if (typeof saveCycleAwareArray === 'function') saveCycleAwareArray(STORAGE_KEYS.PAYMENTS, payments);
                else Storage.set(STORAGE_KEYS.PAYMENTS, payments);
            }
        }
    }

    // ============================================================
    // 4. حفظ + مزامنة
    // ============================================================
    savePurchaseInvoices();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
    currentPurchaseItems = [];
    closeModal('purchaseModal');

    if (typeof oaRefreshRelated === 'function') {
        oaRefreshRelated('purchase');
    } else {
        renderPurchaseInvoices();
        if (typeof renderInventory === 'function') renderInventory();
        if (typeof updateDashboard === 'function') updateDashboard();
    }

    showToast('تم حفظ الفاتورة بنجاح', 'success');
}


// ================================================================
// ===== 11. عرض فاتورة الشراء =====
// ================================================================

function viewPurchaseInvoice(id) {
    var invoice = purchaseInvoices.find(function(inv) { return inv.id === id; });
    if (!invoice) {
        showToast('الفاتورة غير موجودة', 'error');
        return;
    }
    
    var html = _buildPurchaseInvoiceView(invoice);
    
    Modal.open({
        id: 'purchaseViewModal',
        title: 'تفاصيل فاتورة الشراء',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'purchaseViewModal\')">إغلاق</button>' +
                '<button class="btn btn-secondary" onclick="saveInvoiceFile(\'purchase\', \'' + invoice.id + '\')">حفظ نسخة</button>' +
                '<button class="btn btn-primary" onclick="printIndividualDocument(\'purchases\', \'' + invoice.id + '\')">طباعة / حفظ PDF</button>'
    });
}


function _buildPurchaseInvoiceView(invoice) {
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';
    var companyAddress = settings.address || '';
    var companyPhone = settings.phone || '';
    
    var itemsRows = '';
    (invoice.items || []).forEach(function(item, i) {
        var lineTotal = (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
        var displayQty = item.inputQty !== undefined ? item.inputQty : item.qty;
        var displayUnit = item.inputUnit || item.baseUnit || 'وحدة';
        var displayPrice = item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price;
        itemsRows += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(item.name) + '</td>' +
            '<td>' + displayQty + ' ' + esc(displayUnit) + '</td>' +
            '<td>' + formatAmountWithCommas(displayPrice) + '</td>' +
            '<td>' + formatAmountWithCommas(lineTotal) + '</td>' +
        '</tr>';
    });
    
    var statusClass = invoice.status === 'مسدد' ? 'status-paid' : 
                      invoice.status === 'دفع جزئي' ? 'status-partial' : 'status-unpaid';
    
    return '' +
        '<div class="doc-wrapper">' +
            '<div class="doc-header">' +
                '<div class="company-name">' + esc(companyName) + '</div>' +
                '<div class="company-info">' +
                    esc(companyAddress) +
                    (companyPhone ? ' | هاتف: ' + esc(companyPhone) : '') +
                '</div>' +
            '</div>' +
            
            '<div class="doc-title">فاتورة شراء</div>' +
            
           '<div class="doc-meta-grid">' +
    '<div><strong>رقم الفاتورة:</strong> ' + esc(invoice.id) + '</div>' +
    '<div><strong>رقم فاتورة المورد:</strong> ' + esc(invoice.supplierInvoiceNumber || '-') + '</div>' +
    '<div><strong>التاريخ:</strong> ' + esc(invoice.date) + '</div>' +
    '<div><strong>النوع:</strong> ' + esc(invoice.type) + '</div>' +
    '<div><strong>الحالة:</strong> <span class="status-badge ' + statusClass + '">' + esc(invoice.status) + '</span></div>' +
    '<div><strong>المورد:</strong> ' + esc(invoice.supplierName) + '</div>' +
    '<div><strong>العملة:</strong> ' + getCurrencyName(invoice.currency) + '</div>' +
    (invoice.journalEntryId
        ? '<div><strong>القيد المحاسبي:</strong> <button onclick="OAPurchases.openLinkedEntry(\'' + invoice.journalEntryId + '\')" style="background:none;border:none;color:var(--color-blue);font-weight:700;text-decoration:underline;cursor:pointer;padding:0;font-family:inherit;font-size:inherit;">' + esc(invoice.journalEntryId) + ' ↗</button></div>'
        : '<div><strong>القيد المحاسبي:</strong> <span style="color:var(--color-text-3);">لا يوجد</span></div>') +
'</div>' +
            
            '<table class="doc-table">' +
                '<thead>' +
                    '<tr>' +
                        '<th>#</th>' +
                        '<th style="text-align:right;">المنتج</th>' +
                        '<th>الكمية</th>' +
                        '<th>السعر</th>' +
                        '<th>الإجمالي</th>' +
                    '</tr>' +
                '</thead>' +
                '<tbody>' + itemsRows + '</tbody>' +
            '</table>' +
            
            '<div class="doc-totals">' +
                '<div class="total-row"><span>الإجمالي قبل الخصم:</span><span class="amount">' + formatCurrency(invoice.subtotal !== undefined ? invoice.subtotal : invoice.total, invoice.currency) + '</span></div>' +
                '<div class="total-row"><span>الخصم:</span><span class="amount">' + formatCurrency(invoice.discount || 0, invoice.currency) + '</span></div>' +
                '<div class="total-row"><span>الإجمالي النهائي:</span><span class="amount">' + formatCurrency(invoice.total, invoice.currency) + '</span></div>' +
            '</div>' +
            
            '<div class="doc-footer">' +
                'شكراً لتعاملكم معنا' +
                '<small>هذا المستند معتمد رقمياً</small>' +
            '</div>' +
        '</div>';
}


// ================================================================
// ===== 12. إلغاء فاتورة الشراء =====
// ================================================================

function cancelPurchaseInvoice(id) {
    var invoice = purchaseInvoices.find(function(inv) { return inv.id === id; });
    if (!invoice || invoice.status === 'ملغاة' || invoice.cancelled) return;

    // ===== فحص المرتجعات المرتبطة وفق قاعدة المحاسب =====
// 1. مرتجع نشط → يمنع الإلغاء
// 2. مرتجع ملغى بدون عكس كامل → يمنع الإلغاء
// 3. مرتجع ملغى مع عكس كامل (reversalStatus='full') → لا يمنع
var linkedReturns = (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs))
    ? returnsDocs.filter(function(r){
        if (r.invoiceId !== id) return false;
        // نشط → يمنع
        if (_reportIsActive(r)) return true;
        // ملغى بدون عكس كامل → يمنع
        if (r.reversalStatus !== 'full') return true;
        // ملغى مع عكس كامل → لا يمنع
        return false;
    })
    : [];
if (linkedReturns.length) return showToast('لا يمكن إلغاء الفاتورة مباشرة لأنها مرتبطة بمرتجع نشط أو غير معكوس بالكامل. عالج المرتجع أولاً.', 'error');
    
    var reason = window.prompt('سبب إلغاء الفاتورة ' + invoice.id + ':', 'تصحيح خطأ في الفاتورة');
    if (reason === null) return;
    reason = String(reason).trim() || 'إلغاء دون تحديد سبب';
    
    var existingPayments = (typeof payments !== 'undefined' && Array.isArray(payments)) ? payments.filter(function(p){ return p.invoiceId === id && !p.isExpense; }) : [];
    if (!window.confirm('سيتم إلغاء الفاتورة ' + invoice.id + ' مع الاحتفاظ بها في السجل، وعكس أثرها على المخزون والقيود.' + (existingPayments.length ? '\nيوجد سند/سندات صرف مرتبطة؛ ستبقى محفوظة كسجل مالي.' : '') + '\nهل تريد المتابعة؟')) return;

    var canReverse = true;
    (invoice.items || []).forEach(function(item) {
        var product = products.find(function(p) { return p.id === item.productId; });
        if (product) {
            var currentQty = parseFloat(product.quantity) || 0;
            var removeQty = parseFloat(item.qty) || 0;
            if (removeQty > currentQty + 0.0000001) canReverse = false;
        }
    });
    if (!canReverse) return showToast('لا يمكن إلغاء الفاتورة: الكمية المشتراة استُهلكت جزئياً أو كلياً من المخزون', 'error');

  (invoice.items || []).forEach(function(item) {
    var product = products.find(function(p) { return p.id === item.productId; });
    if (product) {
        product.quantity = (parseFloat(product.quantity) || 0) - (parseFloat(item.qty) || 0);

        // ✅ إضافة: تسجيل حركة مخزنية عكسية
        if (typeof recordStockMovement === 'function') {
            recordStockMovement({
                date: todayISO(),
                type: 'out',
                docType: 'إلغاء فاتورة شراء',
                docId: invoice.id,
                productId: product.id,
                productName: product.name,
                qty: parseFloat(item.qty) || 0,
                price: parseFloat(item.price) || 0,
                currency: invoice.currency || 'SAR',
                note: 'إلغاء الفاتورة ' + invoice.id
            });
        }
    }
});
    saveProducts();
    
    invoice.status = 'ملغاة';
invoice.documentStatus = 'cancelled';   // ← البُعد الجديد
invoice.cancelled = true;
invoice.cancelledAt = new Date().toISOString();
invoice.cancelReason = reason;
invoice.cancelledBy = 'المستخدم';

    // ✅ إلغاء السندات التلقائية فقط (المرتبطة بفواتير شراء نقدية)
// السندات اليدوية تبقى نشطة — المال خرج فعلاً ولنا رصيد دائن عند المورد
if (typeof payments !== 'undefined' && Array.isArray(payments)) {
    payments.forEach(function(p) {
        if (p.invoiceId !== id || p.isExpense) return;
        if (p.cancelled === true) return;

        // تمييز السند التلقائي عن اليدوي
        var isAuto = p.note && p.note.indexOf('دفع نقدي') !== -1;

        if (!isAuto) {
            // سند يدوي — يبقى نشطاً
            // سيظهر لنا رصيد دائن عند المورد في getInvoiceOutstanding
            return;
        }

        // سند تلقائي (فاتورة شراء نقدية) — يُلغى مع الفاتورة
        p.cancelled = true;
        p.cancelledAt = new Date().toISOString();
        p.cancelReason = 'ملغى بموجب إلغاء الفاتورة النقدية ' + id;
        p.documentStatus = 'cancelled';
        p.sourceStatus = 'cancelled';
    });

    if (typeof savePayments === 'function') {
        savePayments();
    } else if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        Storage.set(STORAGE_KEYS.PAYMENTS, payments);
    }
}

    savePurchaseInvoices();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

    // ✅ مزامنة مركزية
    if (typeof oaRefreshRelated === 'function') {
        oaRefreshRelated('purchase');
    } else {
        renderPurchaseInvoices();
        if (typeof renderInventory === 'function') renderInventory();
        if (typeof renderPayments === 'function') renderPayments();
        if (typeof updateDashboard === 'function') updateDashboard();
    }

    showToast('تم إلغاء فاتورة الشراء والاحتفاظ بسجلها', 'success');
}

// ================================================================
// ===== 13. تهيئة فواتير الشراء =====
// ================================================================

function initPurchases() {
    loadPurchaseInvoices();
    renderPurchaseInvoices();
    
    var searchEl = document.getElementById('purchSearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderPurchaseInvoices, 300));
    }
    
    console.log('Purchases: ' + purchaseInvoices.length + ' فاتورة');
}
// ================================================================
// ===== 14. حساب رصيد الصندوق بعملة محددة =====
// ================================================================

function _purchaseGetCashBalance(currency) {
    var balance = 0;
    var c = currency || 'YER';
    
    // 1. من الحركات المباشرة
    if (typeof directTransactions !== 'undefined' && Array.isArray(directTransactions)) {
        directTransactions.forEach(function(t) {
            if (t.account !== 'cashbox') return;
            if ((t.currency || 'YER') !== c) return;
            if (t.direction === 'in') balance += parseFloat(t.amount) || 0;
            else balance -= parseFloat(t.amount) || 0;
        });
    }
    
    // 2. من سندات القبض النقدية
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
            if ((r.method || 'نقدي') !== 'نقدي') return;
            if ((r.currency || 'YER') !== c) return;
            balance += parseFloat(r.amount) || 0;
        });
    }
    
    // 3. من سندات الصرف النقدية
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.archived) return;
            if ((p.method || 'نقدي') !== 'نقدي') return;
            if ((p.currency || 'YER') !== c) return;
            balance -= parseFloat(p.amount) || 0;
        });
    }
    
    // 4. من التحويلات الداخلية
    if (typeof transfers !== 'undefined' && Array.isArray(transfers)) {
        transfers.forEach(function(t) {
            if (t.status === 'cancelled') return;
            if (t.from && t.from.accountType === 'cashbox' && (t.from.currency || 'YER') === c) {
                balance -= parseFloat(t.from.amount) || 0;
            }
            if (t.to && t.to.accountType === 'cashbox' && (t.to.currency || 'YER') === c) {
                balance += parseFloat(t.to.amount) || 0;
            }
        });
    }
    
    // 5. الرصيد الافتتاحي من الدورة
    if (typeof Storage !== 'undefined') {
        var cycleOpening = Storage.get('oa_cycle_opening_balances', null);
        if (cycleOpening && cycleOpening.accounts && cycleOpening.accounts.cashbox) {
            var openAmount = parseFloat(cycleOpening.accounts.cashbox[c]) || 0;
            balance += openAmount;
        }
    }
    
    return balance;
}

/**
 * عرض نافذة "رصيد غير كافٍ" مع تفاصيل + زر التحويل
 */
function _showInsufficientBalanceDialog(balanceCheck, invoiceCurrency) {
    var needed = balanceCheck.needed || 0;
    var available = balanceCheck.balance || 0;
    var shortfall = balanceCheck.short || (needed - available);
    var entryCurrency = balanceCheck.currency || invoiceCurrency;
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

    // بناء معلومات سعر الصرف (إذا كانت العملة مختلفة عن الأساسية)
    var rateInfo = '';
    var neededInBase = needed;

    if (entryCurrency !== baseCurrency) {
        var fromRate = (typeof getRate === 'function') ? getRate(entryCurrency) : 1;
        var toRate = (typeof getRate === 'function') ? getRate(baseCurrency) : 1;
        var rate = fromRate / (toRate || 1);
        neededInBase = needed * rate;

        rateInfo =
            '\n\n' +
            '━━━━━━━━━━━━━━━━\n' +
            'سعر الصرف:\n' +
            '1 ' + entryCurrency + ' = ' + rate.toFixed(4) + ' ' + baseCurrency + '\n' +
            '\n' +
            'المبلغ المطلوب بالـ ' + baseCurrency + ':\n' +
            neededInBase.toFixed(2) + ' ' + baseCurrency;
    }

    var message =
        'المطلوب: ' + needed.toFixed(2) + ' ' + entryCurrency + '\n' +
        'المتاح: ' + available.toFixed(2) + ' ' + entryCurrency + '\n' +
        'النقص: ' + shortfall.toFixed(2) + ' ' + entryCurrency +
        rateInfo +
        '\n\n' +
        'هل تريد فتح شاشة التحويل لتحويل المبلغ من عملة أخرى؟';

    if (typeof Modal === 'undefined' || typeof Modal.confirm !== 'function') {
        // بديل: رسالة عادية
        showToast('رصيد ' + (balanceCheck.accountLabel || 'الصندوق') + ' غير كافٍ — المطلوب ' + needed.toFixed(2) + ' ' + entryCurrency, 'error', 8000);
        return;
    }

    Modal.confirm({
        title: '⚠️ رصيد غير كافٍ بـ ' + entryCurrency,
        message: message,
        confirmText: 'تحويل العملة',
        cancelText: 'إلغاء',
        confirmColor: 'primary',
        onConfirm: function() {
            if (typeof openTransferModal === 'function') {
                openTransferModal('cashbox');
            } else {
                showToast('شاشة التحويل غير متاحة', 'error');
            }
        }
    });
}

// ================================================================
// ===== Migration: توليد حركات الشراء المفقودة =====
// ================================================================

/**
 * ترحيل حركات الشراء المفقودة من الفواتير القديمة
 * يُشغَّل مرة واحدة بعد إصلاح purchases.js
 *
 * @returns {object} { migrated, skipped }
 */
function migrateOldPurchaseMovements() {
    if (typeof purchaseInvoices === 'undefined' || !Array.isArray(purchaseInvoices)) {
        console.warn('[OA] migrateOldPurchaseMovements: purchaseInvoices غير معرّف');
        return { migrated: 0, skipped: 0 };
    }
    if (typeof stockMovements === 'undefined' || !Array.isArray(stockMovements)) {
        console.warn('[OA] migrateOldPurchaseMovements: stockMovements غير معرّف');
        return { migrated: 0, skipped: 0 };
    }

    var migrated = 0;
    var skipped = 0;
    var details = [];

    purchaseInvoices.forEach(function(inv) {
        // تجاهل الفواتير الملغاة
        if (inv.documentStatus === 'cancelled' || inv.cancelled) {
            skipped++;
            return;
        }

        (inv.items || []).forEach(function(item) {
            // هل الحركة موجودة؟
            var exists = stockMovements.some(function(m) {
                return m.docId === inv.id && m.productId === item.productId;
            });
            if (exists) {
                skipped++;
                return;
            }

            // أضف الحركة
            var price = parseFloat(item.price) || 0;
            if (item.inputUnitPrice !== undefined && item.conversionFactor) {
                price = parseFloat(item.inputUnitPrice) / parseFloat(item.conversionFactor) || price;
            }

            stockMovements.push({
                id: (typeof generateId === 'function' ? generateId() : 'MIG-' + Date.now() + '-' + Math.random()),
                date: inv.date || todayISO(),
                type: 'in',
                docType: 'فاتورة شراء',
                docId: inv.id,
                productId: item.productId,
                productName: item.name,
                qty: parseFloat(item.qty) || 0,
                price: price,
                currency: inv.currency || 'SAR',
                note: 'مرحّل تلقائياً من فاتورة شراء قديمة',
                createdAt: new Date().toISOString()
            });

            migrated++;
            details.push({
                invoiceId: inv.id,
                productName: item.name,
                qty: item.qty,
                price: price
            });
        });
    });

    if (migrated > 0 && typeof saveStockMovements === 'function') {
        saveStockMovements();
    }

    console.log('[OA] ✅ ترحيل الشراءات: ' + migrated + ' حركة جديدة، ' + skipped + ' متجاهلة');

    return {
        migrated: migrated,
        skipped: skipped,
        details: details
    };
}
// ================================================================
// ===== ربط: فتح القيد المرتبط من الفاتورة =====
// ================================================================

function _openLinkedEntry(entryId) {
    if (!entryId) return;

    var entry = null;
    if (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries)) {
        entry = journalEntries.find(function(e) { return e.id === entryId; });
    }

    if (!entry) {
        if (typeof showToast === 'function') {
            showToast('القيد ' + entryId + ' غير موجود في الذاكرة', 'warning');
        }
        return;
    }

    if (typeof Modal !== 'undefined' && Modal.closeAll) {
        Modal.closeAll();
    }

    if (typeof switchTab === 'function') {
        switchTab('journal');
    }

    setTimeout(function() {
        if (typeof viewJournalEntry === 'function') {
            viewJournalEntry(entryId);
        } else {
            if (typeof showToast === 'function') {
                showToast('القيد: ' + entryId + ' — افتح دفتر اليومية لعرضه', 'info', 6000);
            }
        }
    }, 300);
}

window.OAPurchases = {
    openLinkedEntry: _openLinkedEntry
};

// ================================================================
// ===== END OF PURCHASES.JS =====
// ================================================================
