/* ================================================================
   Open Account — طبقة ربط القوالب الجديدة بالنظام
   الملف: template-print.js
   الوصف: يعترض printIndividualDocument ويوجّه للقوالب الجديدة
   ================================================================ */

(function() {
    'use strict';

    /* ============================================================
       خريطة القوالب
       ============================================================ */
    var _oa_templates_map = {
    'purchases': {
        file:  'purchase-invoice.html',
        list:  'purchaseInvoices',
        party: 'supplier',
        paid:  'payments'
    },
    'sales': {
        file:  'sales-invoice.html',
        list:  'salesInvoices',
        party: 'customer',
        paid:  'receipts'
    },
    'receipts': {
        file:  'receipt-voucher.html',
        list:  'receipts',
        party: 'customer',
        paid:  null
    },
    'payments': {
        file:  'payment-voucher.html',
        list:  'payments',
        party: 'supplier',
        paid:  null
    },
    'expenses': {
        file:  'expense-voucher.html',
        list:  'expenses',
        party: null,
        paid:  null
    },
    'returns': {
        file:  'return-voucher.html',
        list:  'returnsDocs',
        party: null,
        paid:  null,
        isReturn: true
    }
};

    /* ============================================================
       التهيئة
       ============================================================ */
    window.addEventListener('load', function() {
        if (typeof window.printIndividualDocument !== 'function') {
            console.warn('[Template Print] printIndividualDocument غير موجود');
            return;
        }

        var _originalPrintIndividualDocument = window.printIndividualDocument;

        window.printIndividualDocument = function(type, id) {
            if (_oa_templates_map[type]) {
                try {
                    _openTemplate(type, id);
                    return;
                } catch(e) {
                    console.error('[Template Print] فشل فتح القالب:', e);
                }
            }
            return _originalPrintIndividualDocument.apply(this, arguments);
        };

        console.log('[Template Print] جاهز — الأنواع: ' + Object.keys(_oa_templates_map).join(', '));
    });

    /* ============================================================
       فتح القالب
       ============================================================ */
    function _openTemplate(type, id) {
        var config = _oa_templates_map[type];

        // 1. اقرأ المستند
        if (typeof window[config.list] === 'undefined' || !Array.isArray(window[config.list])) {
            throw new Error('قائمة المستندات غير متوفرة: ' + config.list);
        }
        var doc = window[config.list].find(function(x) { return x.id === id; });
        if (!doc) {
            throw new Error('المستند غير موجود: ' + id);
        }

        // 2. اقرأ الإعدادات
        var settings = {};
        if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
            settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
        }

        // 3. المبلغ المدفوع (للأنواع التي تحتاجه)
        var paidAmount = 0;
        if (config.paid && typeof window[config.paid] !== 'undefined' && Array.isArray(window[config.paid])) {
            paidAmount = window[config.paid]
                .filter(function(p) {
                    return p.invoiceId === doc.id
                        && !p.cancelled
                        && p.documentStatus !== 'cancelled'
                        && !p.archived
                        && !p.isExpense;
                })
                .reduce(function(sum, p) {
                    return sum + (parseFloat(p.amount) || 0);
                }, 0);
        }

        // 4. بيانات الطرف (مورد أو عميل)
        var party = null;
        if (config.party === 'supplier' && typeof suppliers !== 'undefined' && Array.isArray(suppliers)) {
            party = suppliers.find(function(s) { return s.id === doc.supplierId; }) || null;
        } else if (config.party === 'customer' && typeof customers !== 'undefined' && Array.isArray(customers)) {
            party = customers.find(function(c) { return c.id === doc.customerId; }) || null;
        }

        // 5. حالة خاصة للمرتجعات — جمع البنود
        var extra = {};
        if (config.isReturn) {
            extra = _buildReturnPayload(doc);
        }

        // 6. حفظ الحمولة
        var payload = {
            type: type,
            doc: doc,
            settings: settings,
            paidAmount: paidAmount,
            supplier: config.party === 'supplier' ? party : null,
            customer: config.party === 'customer' ? party : null,
            createdAt: new Date().toISOString()
        };

        // دمج extra (بنود المرتجع + meta)
        Object.keys(extra).forEach(function(k) {
            payload[k] = extra[k];
        });

        localStorage.setItem('oa_template_payload', JSON.stringify(payload));

        // 7. افتح القالب في نفس التبويب
        var base = window.location.href.replace(/\/[^\/]*$/, '/');
        var url = base + 'templates/' + config.file;
        localStorage.setItem('oa_return_url', window.location.href);
        window.location.href = url;
    }

    /* ============================================================
       جمع بنود المرتجع (نفس الفاتورة + نفس التاريخ)
       ============================================================ */
    function _buildReturnPayload(doc) {
        if (typeof returnsDocs === 'undefined' || !Array.isArray(returnsDocs)) {
            return { items: [], meta: {} };
        }

        // 1. اجمع السجلات — نفس invoiceId + نفس date
        var sameGroup = returnsDocs.filter(function(r) {
            return r.invoiceId === doc.invoiceId
                && r.date === doc.date;
        });

        // 2. ابنِ قائمة البنود
        var items = sameGroup.map(function(r) {
            // ابحث عن المنتج للحصول على الوحدة
            var product = null;
            if (typeof products !== 'undefined' && Array.isArray(products)) {
                product = products.find(function(p) { return p.id === r.productId; });
            }
            return {
                productName: r.productName || '—',
                unit: (product && (product.baseUnit || product.unit)) || 'وحدة',
                originalQty: r.originalQty || 0,
                qty: r.qty || 0,
                unitPrice: r.unitPrice || 0,
                amount: r.amount || 0
            };
        });

        // 3. إجمالي المرتجع
        var totalReturn = sameGroup.reduce(function(s, r) {
            return s + (parseFloat(r.amount) || 0);
        }, 0);

        // 4. قيمة الفاتورة الأصلية
        var originalTotal = 0;
        var invId = doc.invoiceId;
        if (doc.kind === 'sale' && typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
            var inv = salesInvoices.find(function(x) { return x.id === invId; });
            if (inv) originalTotal = parseFloat(inv.total) || 0;
        } else if (doc.kind === 'purchase' && typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
            var inv = purchaseInvoices.find(function(x) { return x.id === invId; });
            if (inv) originalTotal = parseFloat(inv.total) || 0;
        }

        // 5. بيانات الطرف
        var party = null;
        if (doc.kind === 'sale' && typeof customers !== 'undefined' && Array.isArray(customers)) {
            party = customers.find(function(c) { return c.id === doc.partyId; }) || null;
        } else if (doc.kind === 'purchase' && typeof suppliers !== 'undefined' && Array.isArray(suppliers)) {
            party = suppliers.find(function(s) { return s.id === doc.partyId; }) || null;
        }

        return {
            items: items,
            party: party,
            meta: {
                totalReturn: totalReturn,
                originalTotal: originalTotal
            }
        };
    }

})();