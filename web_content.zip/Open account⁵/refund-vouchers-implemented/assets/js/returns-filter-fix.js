// ================================================================
// returns-filter-fix.js
// إصلاح دالة switchReturnsFilter المفقودة
// هذا الملف لا يعدّل أي شيء آخر — فقط يعرّف الدالة الناقصة
// ================================================================

(function() {
    'use strict';

    // إذا كانت معرّفة مسبقاً، لا نلمسها
    if (typeof window.switchReturnsFilter === 'function') return;

    window.switchReturnsFilter = function(kind) {
        if (kind !== 'sale' && kind !== 'purchase') return;

        // تحديث المتغير العام
        if (typeof currentReturnsFilter !== 'undefined') {
            window.currentReturnsFilter = kind;
        } else {
            window.currentReturnsFilter = kind;
        }

        var tabSale = document.getElementById('returnsTabSale');
        var tabPurchase = document.getElementById('returnsTabPurchase');

        if (tabSale) {
            if (kind === 'sale') tabSale.classList.add('active-tab');
            else tabSale.classList.remove('active-tab');
        }
        if (tabPurchase) {
            if (kind === 'purchase') tabPurchase.classList.add('active-tab');
            else tabPurchase.classList.remove('active-tab');
        }

        // إعادة رسم الجدول
        if (typeof window.renderReturns === 'function') {
            try { window.renderReturns(); } catch(e) { console.warn('renderReturns failed:', e); }
        }
    };

    console.log('✅ returns-filter-fix.js: switchReturnsFilter جاهزة');
})();