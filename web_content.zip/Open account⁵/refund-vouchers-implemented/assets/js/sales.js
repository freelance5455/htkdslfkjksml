// ================================================================
// Open Account — نظام محاسبي
// الملف: sales.js (نسخة نظيفة v3 — مع stockMovement ومنع التكرار)
// ================================================================

var salesInvoices = [];
var currentSalesItems = [];

// ✅ منع التكرار
var _savingSales = false;
var _cancellingSales = false;
// ✅ وضع الأرشفة
var _archiveSalesMode = false;
var _showArchivedSales = false;
var _selectedSalesForArchive = {};

// ================================================================
// ===== 1. تحميل وحفظ =====
// ================================================================

function loadSalesInvoices() {
    salesInvoices = Storage.get(STORAGE_KEYS.SALES, []);
    if (!Array.isArray(salesInvoices)) salesInvoices = [];
    
    var needsSave = false;
    
    salesInvoices.forEach(function(inv) {
        if (!inv) return;
        
        if (inv.discount === undefined) inv.discount = 0;
        if (inv.subtotal === undefined) {
            inv.subtotal = (inv.items || []).reduce(function(s, i) {
                return s + (parseFloat(i.price) || 0) * (parseInt(i.qty) || 0);
            }, 0);
        }
        
        if (inv.documentStatus === undefined) {
            inv.documentStatus = (inv.status === 'ملغاة' || inv.cancelled) ? 'cancelled' : 'active';
            needsSave = true;
        }
        if (inv.paymentStatus === undefined) {
            if (inv.status === 'مسدد') inv.paymentStatus = 'paid';
            else if (inv.status === 'دفع جزئي') inv.paymentStatus = 'partial';
            else inv.paymentStatus = 'unpaid';
            needsSave = true;
        }
        if (inv.returnStatus === undefined) {
            inv.returnStatus = 'none';
            needsSave = true;
        }
    });
    
    if (needsSave) {
        saveSalesInvoices();
    }
}

function saveSalesInvoices() {
    Storage.set(STORAGE_KEYS.SALES, salesInvoices);
}

// ================================================================
// ===== 2. عرض الجدول =====
// ================================================================

function renderSalesInvoices() {
    var tbody = document.getElementById('salesTableBody');
    if (!tbody) return;
    var searchEl = document.getElementById('salesSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';

    // ✅ فلترة المؤرشفة
    var filtered = salesInvoices.filter(function(inv) {
        if (_showArchivedSales) return inv.archived === true;
        return inv.archived !== true;
    });

    if (search) {
        filtered = filtered.filter(function (inv) {
            return String(inv.customerName || '').toLowerCase().indexOf(search) !== -1 ||
                   String(inv.id || '').indexOf(search) !== -1;
        });
    }

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">' +
    (_showArchivedSales ? 'لا توجد فواتير مؤرشفة' : 'لا توجد فواتير') +
    '</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function (inv, i) {
            var statusClass = (inv.status === 'ملغاة' || inv.cancelled) ? 'status-cancelled' : (inv.status === 'مسدد' ? 'status-paid' : inv.status === 'دفع جزئي' ? 'status-partial' : 'status-unpaid');

            // ✅ checkbox في وضع الأرشفة
            var firstCell = (i + 1);
            if (_archiveSalesMode && !_showArchivedSales) {
                var checked = _selectedSalesForArchive[inv.id] ? 'checked' : '';
                firstCell = '<input type="checkbox" class="sales-archive-cb" data-id="' + inv.id + '" ' + checked + ' onchange="onSalesArchiveCheckboxChange(this)">';
            }

            // ✅ أزرار الإجراءات
            var actionsHtml = '';
            if (_showArchivedSales) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewSalesInvoice(\'' + inv.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    '<button class="btn-edit" onclick="restoreSalesInvoice(\'' + inv.id + '\')" title="استرجاع" style="margin-right:4px;">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>' +
                    '</button>';
            } else if (!_archiveSalesMode) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewSalesInvoice(\'' + inv.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    (inv.status === 'ملغاة' || inv.cancelled ? '' : '<button class="btn-delete" onclick="cancelSalesInvoice(\'' + inv.id + '\')" title="إلغاء الفاتورة"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>');
            }

            html += '<tr>' +
    '<td>' + firstCell + '</td>' +
    '<td><strong style="font-family:monospace;font-size:12px;color:var(--color-blue);">' + esc(inv.id) + '</strong></td>' +
    '<td>' + esc(inv.customerName) +
        (inv.returnStatus === 'partial' ? ' <span style="background:#f7931e;color:#fff;font-size:9px;padding:1px 5px;border-radius:6px;font-weight:700;">مرتجع جزئي</span>' : '') +
        (inv.returnStatus === 'full' ? ' <span style="background:#888;color:#fff;font-size:9px;padding:1px 5px;border-radius:6px;font-weight:700;">مرتجع كلي</span>' : '') +
    '</td>' +
    '<td>' + formatDate(inv.date) + '</td>' +
    '<td>' + formatCurrency(inv.total, inv.currency) + '</td>' +
    '<td><span class="status-badge ' + statusClass + '"><span class="status-dot"></span>' + inv.status + '</span></td>' +
    '<td>' + actionsHtml + '</td>' +
'</tr>';
        });
        tbody.innerHTML = html;
    }

    // ✅ شريط أدوات الأرشفة (يظهر في وضع الأرشفة)
    _renderSalesArchiveToolbar();

    updateSalesStats();
}

// ✅ شريط أدوات الأرشفة
function _renderSalesArchiveToolbar() {
    var bar = document.getElementById('salesArchiveBar');
    if (!bar) return;

    if (!_archiveSalesMode) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    var count = Object.keys(_selectedSalesForArchive).length;
    bar.style.display = 'flex';
    bar.innerHTML =
        '<button class="btn btn-secondary" onclick="toggleSelectAllSales()" style="flex:1;font-size:12px;">' +
            (_allActiveSalesSelected() ? 'إلغاء الكل' : 'تحديد الكل') +
        '</button>' +
        '<button class="btn btn-warning" onclick="confirmArchiveSales()" style="flex:1;font-size:12px;" ' + (count === 0 ? 'disabled' : '') + '>' +
            'أرشفة المحدد (' + count + ')' +
        '</button>' +
        '<button class="btn btn-cancel" onclick="toggleArchiveSalesMode()" style="flex:1;font-size:12px;">' +
            'إلغاء' +
        '</button>';
}

function _allActiveSalesSelected() {
    var active = salesInvoices.filter(function(i) { return !i.cancelled && !i.archived; });
    if (!active.length) return false;
    return active.every(function(i) { return _selectedSalesForArchive[i.id]; });
}

// ✅ دوال الأرشفة
function toggleArchiveSalesMode() {
    _archiveSalesMode = !_archiveSalesMode;
    _selectedSalesForArchive = {};
    if (_archiveSalesMode) _showArchivedSales = false;
    renderSalesInvoices();
}

function toggleShowArchivedSales() {
    _showArchivedSales = !_showArchivedSales;
    _archiveSalesMode = false;
    _selectedSalesForArchive = {};
    renderSalesInvoices();
}

function onSalesArchiveCheckboxChange(cb) {
    var id = cb.getAttribute('data-id');
    if (cb.checked) _selectedSalesForArchive[id] = true;
    else delete _selectedSalesForArchive[id];
    _renderSalesArchiveToolbar();
}

function toggleSelectAllSales() {
    var active = salesInvoices.filter(function(i) { return !i.cancelled && !i.archived; });
    if (_allActiveSalesSelected()) {
        _selectedSalesForArchive = {};
    } else {
        active.forEach(function(i) { _selectedSalesForArchive[i.id] = true; });
    }
    renderSalesInvoices();
}

function confirmArchiveSales() {
    var ids = Object.keys(_selectedSalesForArchive);
    if (!ids.length) { showToast('لم تحدد أي فاتورة', 'warning'); return; }
    if (!confirm('سيتم أرشفة ' + ids.length + ' فاتورة.\nستُخفى من العرض — لا تُحذف.\n\nمتابعة؟')) return;

    var count = 0;
    salesInvoices.forEach(function(inv) {
        if (_selectedSalesForArchive[inv.id]) {
            inv.archived = true;
            inv.archivedAt = new Date().toISOString();
            count++;
        }
    });

    saveSalesInvoices();
    _archiveSalesMode = false;
    _selectedSalesForArchive = {};
    renderSalesInvoices();
    showToast('تمت أرشفة ' + count + ' فاتورة', 'success');
}

function restoreSalesInvoice(id) {
    var inv = salesInvoices.find(function(x) { return x.id === id; });
    if (!inv) return;
    inv.archived = false;
    delete inv.archivedAt;
    saveSalesInvoices();
    renderSalesInvoices();
    showToast('تم استرجاع الفاتورة', 'success');
}

// ================================================================
// ===== 3. الإحصائيات =====
// ================================================================

function updateSalesStats() {
    setText('salesCount', salesInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).length);
    var totals = {}, subtotals = {}, discounts = {};
    salesInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function (inv) {
        var c = inv.currency || 'YER';
        totals[c] = (totals[c] || 0) + (parseFloat(inv.total) || 0);
        subtotals[c] = (subtotals[c] || 0) + (parseFloat(inv.subtotal !== undefined ? inv.subtotal : inv.total) || 0);
        discounts[c] = (discounts[c] || 0) + (parseFloat(inv.discount) || 0);
    });
    var parts = [];
    ['YER', 'SAR', 'USD'].forEach(function (c) { if (totals[c]) parts.push(formatAmountWithCommas(totals[c]) + ' ' + c); });
    setText('salesTotal', parts.length ? parts.join(' | ') : '0');

    var discountParts = [];
    ['YER', 'SAR', 'USD'].forEach(function (c) { if (discounts[c]) discountParts.push(formatAmountWithCommas(discounts[c]) + ' ' + c); });
    setText('salesDiscountTotal', discountParts.length ? discountParts.join(' | ') : '0');

    var subtotalParts = [];
    ['YER', 'SAR', 'USD'].forEach(function (c) { if (subtotals[c]) subtotalParts.push(formatAmountWithCommas(subtotals[c]) + ' ' + c); });
    setText('salesSubtotalTotal', subtotalParts.length ? subtotalParts.join(' | ') : '0');

    var paid = salesInvoices.filter(function (inv) { return inv.status === 'مسدد'; }).length;
    var unpaid = salesInvoices.filter(function (inv) { return inv.status === 'غير مسدد'; }).length;
    setText('salesPaid', paid);
    setText('salesUnpaid', unpaid);
}

// ================================================================
// ===== 4. التهيئة =====
// ================================================================

function initSales() {
    loadSalesInvoices();
    renderSalesInvoices();
    var searchEl = document.getElementById('salesSearch');
    if (searchEl) searchEl.addEventListener('input', debounce(renderSalesInvoices, 300));
    console.log('Sales: ' + salesInvoices.length + ' فاتورة');
}

// ================================================================
// ===== 5. نافذة فاتورة جديدة =====
// ================================================================

function openSalesModal() {
    currentSalesItems = [];
    if (!customers || customers.length === 0) return showToast('يرجى إضافة عميل أولاً', 'error');
    if (!products || products.length === 0) return showToast('يرجى إضافة منتج أولاً', 'error');

    var bodyHTML = _buildSalesFormHTML();
    var footerHTML =
        '<button class="btn btn-cancel" onclick="closeModal(\'salesModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="saveSales()">حفظ الفاتورة</button>';

    Modal.open({
        id: 'salesModal',
        title: 'فاتورة بيع جديدة',
        size: 'large',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function (modalEl) {
            _populateSalesCustomers();
            _populateSalesProducts();
            var dateEl = modalEl.querySelector('#salesDate');
            if (dateEl) dateEl.value = todayISO();
        }
    });
}

// ================================================================
// ===== 6. نموذج الفاتورة =====
// ================================================================

function _buildSalesFormHTML() {
    return '' +
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>العميل</label>' +
                '<select id="salesCustomer"><option value="">— اختر عميل —</option></select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="salesDate">' +
            '</div>' +
        '</div>' +

        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>العملة</label>' +
                '<select id="salesCurrency" class="currency-select" disabled style="background:#eef2f6;cursor:not-allowed;pointer-events:none;">' +
                    '<option value="YER">ريال يمني</option>' +
                    '<option value="SAR">ريال سعودي</option>' +
                    '<option value="USD">دولار أمريكي</option>' +
                '</select>' +
                '<small style="display:block;margin-top:4px;font-size:11px;color:var(--color-text-3);">تتبع عملة المنتج تلقائياً</small>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>نوع الفاتورة</label>' +
                '<select id="salesType">' +
                    '<option value="نقدي">نقدي</option>' +
                    '<option value="أجل">أجل</option>' +
                '</select>' +
            '</div>' +
        '</div>' +

        '<div class="section-label"><span>المنتجات</span></div>' +

     '<div class="sales-items-wrap">' +
    '<div class="sales-items-line sales-line-1">' +
        '<select id="salesFinishedProductSelect"><option value="">— اختر منتجًا تامًا —</option></select>' +
        '<select id="salesRawProductSelect"><option value="">— اختر مادة خام —</option></select>' +
    '</div>' +
    '<div class="sales-items-line sales-line-2">' +
        '<select id="salesProductUnit"><option value="">الوحدة</option></select>' +
        '<input type="number" id="salesProductQty" placeholder="الكمية" value="1" min="0.000001" step="0.000001">' +
        '<input type="number" id="salesProductPrice" placeholder="السعر" readonly style="background:#eef2f6;pointer-events:none;cursor:not-allowed;" title="السعر يتبع بطاقة المنتج">' +
        '<button class="btn btn-add" onclick="addProductToSales()" title="إضافة">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
                '<line x1="12" y1="5" x2="12" y2="19"/>' +
                '<line x1="5" y1="12" x2="19" y2="12"/>' +
            '</svg>' +
        '</button>' +
    '</div>' +
'</div>' +
        '<div id="salesBaseUnitHint" class="form-hint" style="margin-top:-8px;margin-bottom:10px;text-align:right;"></div>' +

        '<div class="items-list" id="salesItemsList"><div class="empty-items">لا توجد منتجات مضافة</div></div>' +

        '<div class="form-field"><label>الخصم (مبلغ ثابت)</label>' +
            '<input type="number" id="salesDiscount" min="0" step="0.01" value="0" oninput="updateSalesTotal()">' +
        '</div>' +
        '<div class="total-display"><span>الإجمالي قبل الخصم:</span><strong id="salesSubtotalDisplay">0.00</strong></div>' +
        '<div class="total-display"><span>الخصم:</span><strong id="salesDiscountDisplay">0.00</strong></div>' +
        '<div class="total-display"><span>الإجمالي النهائي:</span><strong id="salesTotalDisplay">0.00</strong></div>';
}

// ================================================================
// ===== 7. ملء القوائم =====
// ================================================================

function _populateSalesCustomers() {
    var selectEl = document.getElementById('salesCustomer');
    if (!selectEl) return;
    var html = '<option value="">— اختر عميل —</option>';
    customers.forEach(function (c) { html += '<option value="' + c.id + '">' + esc(c.name) + '</option>'; });
    selectEl.innerHTML = html;
}

function _populateSalesProducts() {
    ['finished', 'raw'].forEach(function (kind) {
        var selectEl = document.getElementById(kind === 'finished' ? 'salesFinishedProductSelect' : 'salesRawProductSelect');
        if (!selectEl) return;
        var html = '<option value="">— اختر ' + (kind === 'finished' ? 'منتجًا تامًا' : 'مادة خام') + ' —</option>';
        products.forEach(function (p) {
            var type = p.type || p.productType || 'raw';
            var qty = parseFloat(p.quantity) || 0;
            if (qty > 0 && ((kind === 'finished' && type === 'finished') || (kind === 'raw' && type !== 'finished'))) {
                html += '<option value="' + p.id + '">' + esc(p.name + ' — متبقي: ' + qty + ' ' + (p.baseUnit || p.unit || 'وحدة')) + '</option>';
            }
        });
        selectEl.innerHTML = html;
        selectEl.onchange = function () { _onSalesProductChange(selectEl); };
    });
}

function _salesUnitFactor(product, unitName) {
    var units = product && Array.isArray(product.units) ? product.units : [];
    var unit = units.find(function (u) { return u.name === unitName; });
    return unit ? (Number(unit.factor) || 1) : 1;
}

function _populateSalesUnits(product) {
    var unitEl = document.getElementById('salesProductUnit');
    if (!unitEl) return;
    var units = product && Array.isArray(product.units) && product.units.length
        ? product.units.filter(function (u) { return u.isSaleUnit !== false; })
        : [];
    if (!units.length && product) units = [{ name: product.baseUnit || product.unit || 'وحدة', factor: 1, isBase: true }];
    unitEl.innerHTML = units.map(function (u) { return '<option value="' + esc(u.name) + '">' + esc(u.name) + '</option>'; }).join('');
    var display = units.find(function (u) { return !u.isBase; }) || units[0];
    if (display) unitEl.value = display.name;
    var hint = document.getElementById('salesBaseUnitHint');
    if (hint && product) hint.textContent = 'الوحدة الأساسية: ' + (product.baseUnit || product.unit || 'وحدة') + ' — معامل التحويل: ' + _salesUnitFactor(product, unitEl.value);
    var updatePrice = function () {
        var priceEl = document.getElementById('salesProductPrice');
        if (!priceEl || !product) return;
        var savedPrice = parseFloat(product.salePrice !== undefined ? product.salePrice : product.price) || 0;
        var savedUnit = product.saleUnit || (units.find(function (u) { return !u.isBase; }) || units[0] || {}).name;
        var savedFactor = _salesUnitFactor(product, savedUnit);
        var selectedFactor = _salesUnitFactor(product, unitEl.value);
        priceEl.value = (savedFactor ? savedPrice * selectedFactor / savedFactor : savedPrice).toFixed(2);
    };
    unitEl.onchange = updatePrice;
    updatePrice();
}

function _onSalesProductChange(selectEl) {
    var productId = selectEl ? selectEl.value : '';
    var currencyEl = document.getElementById('salesCurrency');
    if (!currencyEl) return;
    document.querySelectorAll('#salesFinishedProductSelect,#salesRawProductSelect').forEach(function (el) { if (el !== selectEl) el.value = ''; });
    if (!productId) return;
    var product = products.find(function (p) { return p.id === productId; });
    if (!product) return;
    _populateSalesUnits(product);
    if (currentSalesItems.length > 0) return;
    currencyEl.value = product.currency || (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER');
}

// ================================================================
// ===== 8. إضافة منتج =====
// ================================================================

function addProductToSales() {
    var finishedEl = document.getElementById('salesFinishedProductSelect');
    var rawEl = document.getElementById('salesRawProductSelect');
    var unitEl = document.getElementById('salesProductUnit');
    var qtyEl = document.getElementById('salesProductQty');
    var priceEl = document.getElementById('salesProductPrice');
    var currencyEl = document.getElementById('salesCurrency');

    var productId = (finishedEl && finishedEl.value) || (rawEl && rawEl.value) || '';
    var inputQty = parseFloat(qtyEl ? qtyEl.value : 0) || 0;
    if (!productId) return showToast('يرجى اختيار منتج', 'error');
    if (inputQty <= 0) return showToast('يرجى إدخال كمية صحيحة', 'error');

    var product = products.find(function (p) { return p.id === productId; });
    if (!product) return;

    var productPrice = parseFloat(product.salePrice !== undefined ? product.salePrice : product.price);
    if (!isFinite(productPrice) || productPrice < 0) return showToast('سعر المنتج غير محدد', 'error');

    var productCurrency = product.currency || (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER');
    if (currencyEl) currencyEl.value = productCurrency;

    var inputUnit = (unitEl && unitEl.value) ? unitEl.value : (product.baseUnit || product.unit || 'وحدة');
    var factor = _salesUnitFactor(product, inputUnit);
    var baseQty = inputQty * factor;
    var baseUnitPrice = factor > 0 ? productPrice / factor : productPrice;
    var stock = parseFloat(product.quantity) || 0;
    var existing = currentSalesItems.find(function (item) { return item.productId === productId; });
    var totalQty = (existing ? existing.qty : 0) + baseQty;
    if (totalQty > stock + 0.0000001) return showToast('المتاح: ' + stock + ' ' + (product.baseUnit || product.unit || 'وحدة'), 'error');

if (currentSalesItems.length > 0) {
    var existingCurrencies = {};
    currentSalesItems.forEach(function (it) {
        var cp = products.find(function (x) { return x.id === it.productId; });
        var cur = (cp && cp.currency) ? cp.currency : (it.currency || 'YER');
        existingCurrencies[cur] = true;
    });
    var existingKeys = Object.keys(existingCurrencies);
    if (existingKeys.length > 0 && existingKeys.indexOf(productCurrency) === -1) {
        return showToast('لا يمكن خلط العملات. الفاتورة الحالية بعملة ' + existingKeys.join('، ') + ' — لا يمكن إضافة صنف بعملة ' + productCurrency, 'error');
    }
}
    if (existing && existing.inputUnit === inputUnit && existing.inputUnitPrice === productPrice) {
        existing.qty += baseQty;
        existing.inputQty += inputQty;
    } else {
        currentSalesItems.push({
            productId: product.id, name: product.name,
            price: baseUnitPrice, qty: baseQty,
            inputUnit: inputUnit, inputQty: inputQty, inputUnitPrice: productPrice,
            baseUnit: product.baseUnit || product.unit || 'وحدة',
            conversionFactor: factor, baseQty: baseQty, baseUnitPrice: baseUnitPrice,
            type: product.type || 'raw',
            currency: productCurrency
        });
    }
    renderSalesItems();
    if (qtyEl) qtyEl.value = 1;
    if (priceEl) priceEl.value = '';
    showToast('تم إضافة المنتج', 'success');
}

// ================================================================
// ===== 9. عرض الأصناف =====
// ================================================================

function renderSalesItems() {
    var container = document.getElementById('salesItemsList');
    if (!container) return;
    if (!currentSalesItems.length) {
        container.innerHTML = '<div class="empty-items">لا توجد منتجات مضافة</div>';
        updateSalesTotal();
        return;
    }
    var html = '';
    currentSalesItems.forEach(function (item, index) {
        var lineTotal = (item.price || 0) * (item.qty || 0);
        var displayQty = item.inputQty !== undefined ? item.inputQty : item.qty;
        var displayUnit = item.inputUnit || item.baseUnit || 'وحدة';
        var displayPrice = item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price;
        var itemCurrency = item.currency || 'YER';
        html += '<div class="item-row">' +
            '<span>' + esc(item.name) + '</span>' +
            '<span>' + displayQty + ' ' + esc(displayUnit) + ' × ' + formatAmountWithCommas(displayPrice) + ' ' + itemCurrency + ' = ' + formatAmountWithCommas(lineTotal) + ' ' + itemCurrency + '</span>' +
            '<button onclick="removeSalesItem(' + index + ')" title="إزالة">×</button>' +
        '</div>';
    });
    container.innerHTML = html;
    updateSalesTotal();
}

function removeSalesItem(index) {
    if (index < 0 || index >= currentSalesItems.length) return;
    currentSalesItems.splice(index, 1);
    if (currentSalesItems.length === 0) {
        var currencyEl = document.getElementById('salesCurrency');
        if (currencyEl && typeof getBaseCurrency === 'function') currencyEl.value = getBaseCurrency();
    }
    renderSalesItems();
}

function updateSalesTotal() {
    var subtotal = 0;
    currentSalesItems.forEach(function (item) { subtotal += (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0); });
    var discountEl = document.getElementById('salesDiscount');
    var discount = Math.max(0, parseFloat(discountEl ? discountEl.value : 0) || 0);
    if (discount > subtotal && discountEl) { discount = subtotal; discountEl.value = subtotal; }
    setText('salesSubtotalDisplay', formatAmountWithCommas(subtotal));
    setText('salesDiscountDisplay', formatAmountWithCommas(discount));
    setText('salesTotalDisplay', formatAmountWithCommas(subtotal - discount));
}

// ================================================================
// ===== 10. حفظ الفاتورة =====
// ================================================================

function saveSales() {
    // ✅ منع التكرار
    if (_savingSales) {
        showToast('جارٍ الحفظ...', 'info');
        return;
    }

    var custEl = document.getElementById('salesCustomer');
    var dateEl = document.getElementById('salesDate');
    var typeEl = document.getElementById('salesType');
    var discountEl = document.getElementById('salesDiscount');

    var customerId = custEl ? custEl.value : '';
    var date = dateEl ? dateEl.value : '';
    var type = typeEl ? typeEl.value : 'نقدي';

    if (!customerId) return showToast('يرجى اختيار العميل', 'error');
    if (!date) return showToast('يرجى اختيار التاريخ', 'error');
 
    if (!currentSalesItems.length) return showToast('يرجى إضافة منتجات', 'error');

    var customer = customers.find(function (c) { return c.id === customerId; });
    if (!customer) return showToast('العميل غير موجود', 'error');

    var currencies = {};
    currentSalesItems.forEach(function (item) {
        var p = products.find(function (x) { return x.id === item.productId; });
        var cur = (p && p.currency) ? p.currency : (item.currency || 'YER');
        currencies[cur] = (currencies[cur] || 0) + 1;
    });
    var currencyKeys = Object.keys(currencies);
    if (currencyKeys.length > 1) {
        return showToast('لا يمكن إصدار فاتورة بأصناف بعملات مختلفة (' + currencyKeys.join(' + ') + ')', 'error');
    }
    var finalCurrency = currencyKeys.length ? currencyKeys[0] : (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER');

    var subtotal = 0;
    currentSalesItems.forEach(function (item) {
        subtotal += (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
    });
    var discount = Math.max(0, parseFloat(discountEl ? discountEl.value : 0) || 0);
    if (discount > subtotal) return showToast('الخصم لا يمكن أن يتجاوز الإجمالي', 'error');
    var total = subtotal - discount;
    var saleCost = typeof calculateSaleCOGS === 'function' ? calculateSaleCOGS(currentSalesItems) : { total: 0, known: false };

    // ✅ تفعيل القفل
    _savingSales = true;

    try {
        // ✅ توليد invoiceId قبل الخصم
        var invoiceId = generateId();

        // خصم المخزون + تسجيل الحركات
        currentSalesItems.forEach(function (item) {
            var product = products.find(function (p) { return p.id === item.productId; });
            if (product) {
                var currentQty = parseFloat(product.quantity) || 0;
                product.quantity = Math.max(0, currentQty - item.qty);

                // ✅ تسجيل حركة مخزنية
                var unitCost = (typeof getProductAverageCost === 'function')
                    ? (getProductAverageCost(product) || 0)
                    : (parseFloat(product.avgCost) || 0);

                if (typeof recordStockMovement === 'function') {
                    recordStockMovement({
                        date: date,
                        type: 'out',
                        docType: 'فاتورة بيع',
                        docId: invoiceId,
                        productId: product.id,
                        productName: product.name,
                        qty: parseFloat(item.qty) || 0,
                        price: unitCost,
                        currency: finalCurrency,
                        note: 'فاتورة بيع للعميل ' + customer.name
                    });
                }
            }
        });
        saveProducts();

        // بناء الفاتورة
        var invoice = {
            id: invoiceId,
            customerId: customerId,
            customerName: customer.name,
            date: date,
            type: type,
            currency: finalCurrency,
            exchangeRate: typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(finalCurrency) : 1,
            items: currentSalesItems.map(function (item) {
                // ✅ إصلاح cogsUnitCost — من البند الأول فقط
                var cogsDetail = (saleCost.details || []).find(function(d) {
                    return d.productId === item.productId;
                });
                var cogsUnitCost = cogsDetail ? (parseFloat(cogsDetail.cost) || 0) : 0;

                return {
                    productId: item.productId,
                    name: item.name,
                    price: parseFloat(item.price) || 0,
                    qty: parseFloat(item.qty) || 0,
                    inputUnit: item.inputUnit || item.baseUnit || 'وحدة',
                    inputQty: parseFloat(item.inputQty !== undefined ? item.inputQty : item.qty) || 0,
                    inputUnitPrice: parseFloat(item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price) || 0,
                    baseUnit: item.baseUnit || item.inputUnit || 'وحدة',
                    conversionFactor: parseFloat(item.conversionFactor) || 1,
                    baseQty: parseFloat(item.qty) || 0,
                    baseUnitPrice: parseFloat(item.price) || 0,
                    type: item.type || 'raw',
                    cogsUnitCost: cogsUnitCost
                };
            }),
            subtotal: subtotal,
            discount: discount,
            total: total,
            cogsTotal: saleCost.total,
            cogsKnown: saleCost.known,
            documentStatus: 'active',
            paymentStatus: type === 'نقدي' ? 'paid' : 'unpaid',
            returnStatus: 'none',
            status: type === 'نقدي' ? 'مسدد' : 'غير مسدد'
        };
        salesInvoices.push(invoice);

        // سند قبض تلقائي للنقدي
        if (type === 'نقدي' && typeof receipts !== 'undefined' && Array.isArray(receipts)) {
            receipts.push({
                id: generateId(),
                invoiceId: invoice.id,
                customerId: customerId,
                customerName: customer.name,
                amount: total,
                currency: finalCurrency,
                exchangeRate: (typeof getCurrentExchangeRateSnapshot === 'function') ? getCurrentExchangeRateSnapshot(finalCurrency) : 1,
                date: date,
                method: 'نقدي',
                note: 'دفع نقدي للفاتورة',
                invoiceTotal: total,
                paidBefore: 0,
                remainingAfter: 0,
                status: 'مدفوع بالكامل'
            });
            if (typeof saveReceipts === 'function') saveReceipts();
        }

        saveSalesInvoices();
        if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
        currentSalesItems = [];
        closeModal('salesModal');

        if (typeof oaRefreshRelated === 'function') {
            oaRefreshRelated('sale');
        } else {
            renderSalesInvoices();
            if (typeof renderInventory === 'function') renderInventory();
            if (typeof updateDashboard === 'function') updateDashboard();
        }

        showToast('تم حفظ الفاتورة بنجاح', 'success');
    } finally {
        // ✅ إلغاء القفل (حتى لو حدث خطأ)
        _savingSales = false;
    }
}

// ================================================================
// ===== 11. عرض فاتورة =====
// ================================================================

function viewSalesInvoice(id) {
    var invoice = salesInvoices.find(function (inv) { return inv.id === id; });
    if (!invoice) return showToast('الفاتورة غير موجودة', 'error');
    var html = _buildSalesInvoiceView(invoice);
    Modal.open({
        id: 'salesViewModal',
        title: 'تفاصيل فاتورة البيع',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'salesViewModal\')">إغلاق</button>' +
                '<button class="btn btn-secondary" onclick="saveInvoiceFile(\'sales\', \'' + invoice.id + '\')">حفظ نسخة</button>' +
                '<button class="btn btn-primary" onclick="printIndividualDocument(\'sales\', \'' + invoice.id + '\')">طباعة / حفظ PDF</button>'
    });
}

// ================================================================
// ===== 12. بناء عرض الفاتورة =====
// ================================================================

function _buildSalesInvoiceView(invoice) {
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';
    var companyAddress = settings.address || '';
    var companyPhone = settings.phone || '';

    var itemsRows = '';
    (invoice.items || []).forEach(function (item, i) {
        var lineTotal = (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
        var displayQty = item.inputQty !== undefined ? item.inputQty : item.qty;
        var displayUnit = item.inputUnit || item.baseUnit || 'وحدة';
        var displayPrice = item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price;
        itemsRows += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(item.name) + '</td>' +
            '<td>' + displayQty + ' ' + esc(displayUnit) + '</td>' +
            '<td>' + formatAmountWithCommas(displayPrice) + '</td>' +
            '<td>' + formatAmountWithCommas(lineTotal) + '</td>' +
        '</tr>';
    });

    var statusClass = invoice.status === 'مسدد' ? 'status-paid' :
                      invoice.status === 'دفع جزئي' ? 'status-partial' : 'status-unpaid';

    return '' +
        '<div class="doc-wrapper">' +
            '<div class="doc-header">' +
                '<div class="company-name">' + esc(companyName) + '</div>' +
                '<div class="company-info">' + esc(companyAddress) + (companyPhone ? ' | هاتف: ' + esc(companyPhone) : '') + '</div>' +
            '</div>' +
            '<div class="doc-title">فاتورة بيع</div>' +
            '<div class="doc-meta-grid">' +
    '<div><strong>رقم الفاتورة:</strong> ' + esc(invoice.id) + '</div>' +
    '<div><strong>التاريخ:</strong> ' + esc(invoice.date) + '</div>' +
    '<div><strong>النوع:</strong> ' + esc(invoice.type) + '</div>' +
    '<div><strong>الحالة:</strong> <span class="status-badge ' + statusClass + '">' + esc(invoice.status) + '</span></div>' +
    '<div><strong>العميل:</strong> ' + esc(invoice.customerName) + '</div>' +
    '<div><strong>العملة:</strong> ' + getCurrencyName(invoice.currency) + '</div>' +
    (invoice.journalEntryId
        ? '<div><strong>القيد المحاسبي:</strong> <button onclick="OASales.openLinkedEntry(\'' + invoice.journalEntryId + '\')" style="background:none;border:none;color:var(--color-blue);font-weight:700;text-decoration:underline;cursor:pointer;padding:0;font-family:inherit;font-size:inherit;">' + esc(invoice.journalEntryId) + ' ↗</button></div>'
        : '<div><strong>القيد المحاسبي:</strong> <span style="color:var(--color-text-3);">لا يوجد</span></div>') +
'</div>' +
            '<table class="doc-table">' +
                '<thead><tr><th>#</th><th style="text-align:right;">المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead>' +
                '<tbody>' + itemsRows + '</tbody>' +
            '</table>' +
            '<div class="doc-totals">' +
                '<div class="total-row"><span>الإجمالي قبل الخصم:</span><span class="amount">' + formatCurrency(invoice.subtotal !== undefined ? invoice.subtotal : invoice.total, invoice.currency) + '</span></div>' +
                '<div class="total-row"><span>الخصم:</span><span class="amount">' + formatCurrency(invoice.discount || 0, invoice.currency) + '</span></div>' +
                '<div class="total-row"><span>الإجمالي النهائي:</span><span class="amount">' + formatCurrency(invoice.total, invoice.currency) + '</span></div>' +
            '</div>' +
            '<div class="doc-footer">شكراً لتعاملكم معنا<small>هذا المستند معتمد رقمياً</small></div>' +
        '</div>';
}

// ================================================================
// ===== 13. إلغاء فاتورة =====
// ================================================================

function cancelSalesInvoice(id) {
    // ✅ منع التكرار
    if (_cancellingSales) return;

    var invoice = salesInvoices.find(function(inv) { return inv.id === id; });
    if (!invoice || invoice.status === 'ملغاة' || invoice.cancelled) return;

    var linkedReceipts = (typeof receipts !== 'undefined' && Array.isArray(receipts)) ? receipts.filter(function(r){ return r.invoiceId === id; }) : [];

    var linkedReturns = (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs))
        ? returnsDocs.filter(function(r){
            if (r.invoiceId !== id) return false;
            if (_reportIsActive(r)) return true;
            if (r.reversalStatus !== 'full') return true;
            return false;
        })
        : [];
    if (linkedReturns.length) return showToast('لا يمكن إلغاء الفاتورة مباشرة لأنها مرتبطة بمرتجع نشط أو غير معكوس بالكامل. عالج المرتجع أولاً.', 'error');

    var activeReceipts = (typeof receipts !== 'undefined' && Array.isArray(receipts))
        ? receipts.filter(function(r) {
            return r.invoiceId === id
                && !r.cancelled
                && r.documentStatus !== 'cancelled'
                && r.sourceStatus !== 'cancelled';
        })
        : [];

    if (activeReceipts.length > 0) {
        showToast(
            'لا يمكن إلغاء هذه الفاتورة — لها سند قبض نشط.\n' +
            'استخدم "مرتجع مبيعات" لتسوية الحالة.',
            'error',
            8000
        );
        return;
    }

    var reason = window.prompt('سبب إلغاء الفاتورة ' + invoice.id + ':', 'تصحيح خطأ في الفاتورة');
    if (reason === null) return;
    reason = String(reason).trim() || 'إلغاء دون تحديد سبب';
    if (!window.confirm('سيتم إلغاء الفاتورة ' + invoice.id + ' مع الاحتفاظ بها في السجل، وعكس أثرها على المخزون والقيود.' + (linkedReceipts.length ? '\nيوجد سند/سندات قبض مرتبطة؛ ستبقى محفوظة كسجل مالي.' : '') + '\nهل تريد المتابعة؟')) return;

    // ✅ تفعيل القفل
    _cancellingSales = true;

    try {
        // إعادة الكمية + تسجيل حركة عكسية
        (invoice.items || []).forEach(function(item) {
            var product = products.find(function(p) { return p.id === item.productId; });
            if (product) {
                product.quantity = (parseFloat(product.quantity) || 0) + (parseFloat(item.qty) || 0);

                // ✅ حركة عكسية
                var unitCost = parseFloat(item.cogsUnitCost) || 0;
                if (typeof recordStockMovement === 'function') {
                    recordStockMovement({
                        date: todayISO(),
                        type: 'in',
                        docType: 'إلغاء فاتورة بيع',
                        docId: invoice.id,
                        productId: product.id,
                        productName: product.name,
                        qty: parseFloat(item.qty) || 0,
                        price: unitCost,
                        currency: invoice.currency || 'SAR',
                        note: 'إلغاء الفاتورة ' + invoice.id
                    });
                }
            }
        });
        saveProducts();

        invoice.status = 'ملغاة';
        invoice.documentStatus = 'cancelled';
        invoice.cancelled = true;
        invoice.cancelledAt = new Date().toISOString();
        invoice.cancelReason = reason;
        invoice.cancelledBy = 'المستخدم';

        // إلغاء السندات التلقائية
        if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
            receipts.forEach(function(r) {
                if (r.invoiceId !== id) return;
                if (r.cancelled === true) return;

                var isAuto = r.note && r.note.indexOf('دفع نقدي') !== -1;
                if (!isAuto) return;

                r.cancelled = true;
                r.cancelledAt = new Date().toISOString();
                r.cancelReason = 'ملغى بموجب إلغاء الفاتورة النقدية ' + id;
                r.documentStatus = 'cancelled';
                r.sourceStatus = 'cancelled';
            });

            if (typeof saveReceipts === 'function') {
                saveReceipts();
            } else if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
                Storage.set(STORAGE_KEYS.RECEIPTS, receipts);
            }
        }

        saveSalesInvoices();
        if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

        if (typeof oaRefreshRelated === 'function') {
            oaRefreshRelated('sale');
        } else {
            renderSalesInvoices();
            if (typeof renderInventory === 'function') renderInventory();
            if (typeof updateDashboard === 'function') updateDashboard();
        }

        showToast('تم إلغاء الفاتورة والاحتفاظ بسجلها', 'success');
    } finally {
        _cancellingSales = false;
    }
}
// ================================================================
// ===== ربط: فتح القيد المرتبط من الفاتورة =====
// ================================================================

function _openLinkedEntry(entryId) {
    if (!entryId) return;

    // ابحث عن القيد
    var entry = null;
    if (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries)) {
        entry = journalEntries.find(function(e) { return e.id === entryId; });
    }

    if (!entry) {
        if (typeof showToast === 'function') {
            showToast('القيد ' + entryId + ' غير موجود في الذاكرة', 'warning');
        }
        return;
    }

    // أغلاق النافذة الحالية (نافذة الفاتورة)
    if (typeof Modal !== 'undefined' && Modal.closeAll) {
        Modal.closeAll();
    }

    // انتقل إلى دفتر اليومية
    if (typeof switchTab === 'function') {
        switchTab('journal');
    }

    // بعد فتح دفتر اليومية — افتح القيد
    setTimeout(function() {
        if (typeof OANotes !== 'undefined') {
            // لا علاقة — تجاهل
        }

        // استخدم viewJournalEntry إن وُجدت
        if (typeof viewJournalEntry === 'function') {
            viewJournalEntry(entryId);
        } else {
            // fallback: رسالة
            if (typeof showToast === 'function') {
                showToast('القيد: ' + entryId + ' — افتح دفتر اليومية لعرضه', 'info', 6000);
            }
        }
    }, 300);
}

// ✅ تصدير للاستخدام من onclick
window.OASales = {
    openLinkedEntry: _openLinkedEntry
};
// ================================================================
// ===== END OF SALES.JS =====
// ================================================================