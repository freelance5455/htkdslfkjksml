// ================================================================
// Open Account — الساعة (تماثلية / رقمية)
// الملف: clock.js
// ================================================================

var _clockMode = 'analog'; // 'analog' | 'digital'
var _clockInterval = null;

function openClock() {
    var body =
        '<div class="clock-wrapper">' +
            '<div class="clock-tabs">' +
                '<button type="button" class="clock-tab active" data-mode="analog">تماثلية</button>' +
                '<button type="button" class="clock-tab" data-mode="digital">رقمية</button>' +
            '</div>' +
            '<div class="clock-stage">' +
                '<div id="clockAnalog" class="clock-view clock-view-analog">' + _clockBuildAnalog() + '</div>' +
                '<div id="clockDigital" class="clock-view clock-view-digital" style="display:none;"></div>' +
            '</div>' +
            '<div class="clock-date" id="clockDate"></div>' +
        '</div>';

    Modal.open({
        id: 'clockModal',
        title: 'الساعة',
        size: 'normal',
        body: body,
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'clockModal\')">إغلاق</button>',
        onOpen: function (modalEl) {
            _clockBindTabs(modalEl);
            _clockTick();
            _clockStart();
        },
        onClose: function () {
            _clockStop();
        }
    });
}

function _clockBuildAnalog() {
    return '' +
        '<svg viewBox="0 0 200 200" class="clock-svg">' +
            // الدائرة الخارجية
            '<circle cx="100" cy="100" r="92" class="clock-face"/>' +
            '<circle cx="100" cy="100" r="88" class="clock-face-inner"/>' +
            // علامات الساعات
            _clockBuildHourMarks() +
            // الأرقام
            _clockBuildNumbers() +
            // عقارب الساعة
            '<line id="clockHourHand" x1="100" y1="100" x2="100" y2="55" class="clock-hand clock-hour"/>' +
            '<line id="clockMinHand" x1="100" y1="100" x2="100" y2="30" class="clock-hand clock-minute"/>' +
            '<line id="clockSecHand" x1="100" y1="100" x2="100" y2="22" class="clock-hand clock-second"/>' +
            // المركز
            '<circle cx="100" cy="100" r="4" class="clock-center"/>' +
            '<circle cx="100" cy="100" r="2" class="clock-center-dot"/>' +
        '</svg>';
}

function _clockBuildHourMarks() {
    var marks = '';
    for (var i = 0; i < 12; i++) {
        var angle = (i * 30 - 90) * Math.PI / 180;
        var x1 = 100 + Math.cos(angle) * 78;
        var y1 = 100 + Math.sin(angle) * 78;
        var x2 = 100 + Math.cos(angle) * 84;
        var y2 = 100 + Math.sin(angle) * 84;
        marks += '<line x1="' + x1.toFixed(2) + '" y1="' + y1.toFixed(2) + '" x2="' + x2.toFixed(2) + '" y2="' + y2.toFixed(2) + '" class="clock-mark"/>';
    }
    return marks;
}

function _clockBuildNumbers() {
    var nums = '';
    var arr = [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
    for (var i = 0; i < 12; i++) {
        var angle = (i * 30 - 90) * Math.PI / 180;
        var x = 100 + Math.cos(angle) * 68;
        var y = 100 + Math.sin(angle) * 68;
        nums += '<text x="' + x.toFixed(2) + '" y="' + y.toFixed(2) + '" class="clock-number" text-anchor="middle" dominant-baseline="central">' + arr[i] + '</text>';
    }
    return nums;
}

function _clockBindTabs(modalEl) {
    var tabs = modalEl.querySelectorAll('.clock-tab');
    for (var i = 0; i < tabs.length; i++) {
        (function (tab) {
            tab.addEventListener('click', function () {
                var mode = tab.getAttribute('data-mode');
                _clockMode = mode;
                for (var j = 0; j < tabs.length; j++) tabs[j].classList.remove('active');
                tab.classList.add('active');
                var a = document.getElementById('clockAnalog');
                var d = document.getElementById('clockDigital');
                if (a && d) {
                    a.style.display = (mode === 'analog') ? 'flex' : 'none';
                    d.style.display = (mode === 'digital') ? 'flex' : 'none';
                }
                _clockTick();
            });
        })(tabs[i]);
    }
}

function _clockTick() {
    var now = new Date();
    var h = now.getHours();
    var m = now.getMinutes();
    var s = now.getSeconds();
    var ms = now.getMilliseconds();

    // التماثلية
    if (_clockMode === 'analog') {
        var smoothSec = s + ms / 1000;
        var secAngle = smoothSec * 6;                   // 360 / 60
        var minAngle = (m + s / 60) * 6;                // 360 / 60
        var hourAngle = ((h % 12) + m / 60 + s / 3600) * 30; // 360 / 12

        var hourHand = document.getElementById('clockHourHand');
        var minHand = document.getElementById('clockMinHand');
        var secHand = document.getElementById('clockSecHand');
        if (hourHand) hourHand.setAttribute('transform', 'rotate(' + hourAngle + ' 100 100)');
        if (minHand) minHand.setAttribute('transform', 'rotate(' + minAngle + ' 100 100)');
        if (secHand) secHand.setAttribute('transform', 'rotate(' + secAngle + ' 100 100)');
    }

    // الرقمية
    var digital = document.getElementById('clockDigital');
    if (digital) {
        digital.innerHTML =
            '<div class="clock-digital-time">' +
                _clockPad(h) + '<span class="clock-colon">:</span>' +
                _clockPad(m) + '<span class="clock-colon">:</span>' +
                _clockPad(s) +
            '</div>' +
            '<div class="clock-digital-period">' +
                (h >= 12 ? 'م' : 'ص') +
            '</div>';
    }

    // التاريخ بالعربية
    var dateEl = document.getElementById('clockDate');
    if (dateEl) {
        try {
            dateEl.textContent = now.toLocaleDateString('ar-EG', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
            });
        } catch (e) {
            dateEl.textContent = now.toDateString();
        }
    }
}

function _clockPad(n) { return n < 10 ? '0' + n : String(n); }

function _clockStart() {
    _clockStop();
    _clockInterval = setInterval(_clockTick, 1000);
}

function _clockStop() {
    if (_clockInterval) {
        clearInterval(_clockInterval);
        _clockInterval = null;
    }
}

function initClock() {
    // ربط زر الساعة (الموجود في القائمة المنسدلة)
    // لا نحتاج زراً في الشريط — القائمة تستدعي openClock مباشرة
    console.log('Clock: initialized');
}