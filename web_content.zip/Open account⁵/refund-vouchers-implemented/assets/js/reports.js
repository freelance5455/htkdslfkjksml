// ================================================================
// Open Account — تقارير شاملة
// الملف: reports.js
// النسخة: v3 — 14 تقرير مع التدفق النقدي
// ================================================================

var currentReportType = 'sales';

// ================================================================
// ===== 1. مساعدات =====
// ================================================================

function _reportArray(name) {
    return typeof window !== 'undefined' && Array.isArray(window[name]) ? window[name] : [];
}

function _reportDateOk(row, from, to) {
    var d = String(row.date || '');
    return (!from || d >= from) && (!to || d <= to);
}

function _reportIsActive(row) { return !!row && row.cancelled !== true && row.documentStatus !== 'cancelled' && row.status !== 'ملغاة'; }


function _reportMoneyByCurrency(rows, valueField) {
    var totals = {};
    rows.forEach(function(row) {
        var c = row.currency || getBaseCurrency();
        totals[c] = (totals[c] || 0) + (parseFloat(row[valueField]) || 0);
    });
    return Object.keys(totals).map(function(c) {
        return formatCurrency(totals[c], c);
    }).join(' + ') || formatCurrency(0, getBaseCurrency());
}

function _reportTypeTitle(type) {
    return ({
        sales: 'تقرير المبيعات',
        sales_with_returns: 'تقرير المبيعات والمردودات',
        purchases: 'تقرير المشتريات',
        purchases_with_returns: 'تقرير المشتريات والمردودات',
        expenses: 'تقرير المصاريف',
        vouchers: 'تقرير السندات',
        inventory: 'جرد المخزون',
        movements: 'حركات المخزون',
        customers_perf: 'أداء العملاء',
        suppliers_perf: 'أداء الموردين',
        products_perf: 'أداء المنتجات',
        customers_balance: 'أرصدة العملاء',
        suppliers_balance: 'أرصدة الموردين',
        transfers: 'تقرير التحويلات',
        profitloss: 'الأرباح والخسائر',
        cash_flow: 'التدفق النقدي'
    })[type] || 'تقرير';
}


// ================================================================
// ===== 2. حسابات مساعدة =====
// ================================================================

function _reportCustomerBalance(customerId) {
    var balances = {};
    var invoices = _reportArray('salesInvoices').filter(function(i) { return _reportIsActive(i) && i.customerId === customerId; });
    var receipts = _reportArray('receipts').filter(function(r) { return _reportIsActive(r) && r.customerId === customerId; });

    invoices.forEach(function(i) {
        var c = i.currency || 'YER';
        balances[c] = (balances[c] || 0) + (parseFloat(i.total) || 0);
    });
    receipts.forEach(function(r) {
        var c = r.currency || 'YER';
        balances[c] = (balances[c] || 0) - (parseFloat(r.amount) || 0);
    });
    _reportArray('payments').filter(function(p) { return _reportIsActive(p) && p.paymentType === 'customer_refund' && p.customerId === customerId; }).forEach(function(p) { var c=p.currency||'YER'; balances[c]=(balances[c]||0)+(parseFloat(p.amount)||0); });
    return balances;
}

function _reportSupplierBalance(supplierId) {
    var balances = {};
    var invoices = _reportArray('purchaseInvoices').filter(function(i) { return _reportIsActive(i) && i.supplierId === supplierId; });
    var payments = _reportArray('payments').filter(function(p) { return _reportIsActive(p) && p.supplierId === supplierId && !p.isExpense; });

    invoices.forEach(function(i) {
        var c = i.currency || 'YER';
        balances[c] = (balances[c] || 0) + (parseFloat(i.total) || 0);
    });
    payments.forEach(function(p) {
        var c = p.currency || 'YER';
        balances[c] = (balances[c] || 0) - (parseFloat(p.amount) || 0);
    });
    _reportArray('receipts').filter(function(r) { return _reportIsActive(r) && r.receiptType === 'supplier_refund' && r.supplierId === supplierId; }).forEach(function(r) {
        var c = r.currency || 'YER'; balances[c] = (balances[c] || 0) - (parseFloat(r.amount) || 0);
    });
    return balances;
}

function _formatBalancesObj(obj) {
    if (!obj) return '0.00';
    var parts = [];
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var amount = parseFloat(obj[c]) || 0;
        if (amount !== 0) parts.push(formatAmountWithCommas(amount) + ' ' + c);
    });
    return parts.length ? parts.join(' | ') : '0.00';
}


// ================================================================
// ===== 3. بناء صفوف التقارير =====
// ================================================================

function _reportRows(type, from, to) {
    var rows = [], source, columns = [], summary = '';

    // ============ 1. المبيعات ============
    if (type === 'sales') {
        source = _reportArray('salesInvoices').filter(function(x) { return _reportIsActive(x) && _reportDateOk(x, from, to); });
        source.sort(function(a, b) { return String(b.date).localeCompare(String(a.date)); });
        rows = source.map(function(x) {
            return [x.id, x.date, x.customerName || '-', x.type || '-', x.currency || 'YER',
                    formatAmountWithCommas(x.total || 0), x.status || '-'];
        });
        columns = ['رقم الفاتورة', 'التاريخ', 'العميل', 'النوع', 'العملة', 'الإجمالي', 'الحالة'];
        summary = 'الإجمالي: ' + _reportMoneyByCurrency(source, 'total');
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 2. المشتريات ============
    if (type === 'purchases') {
        source = _reportArray('purchaseInvoices').filter(function(x) { return _reportIsActive(x) && _reportDateOk(x, from, to); });
        source.sort(function(a, b) { return String(b.date).localeCompare(String(a.date)); });
        rows = source.map(function(x) {
            return [x.id, x.date, x.supplierName || '-', x.type || '-', x.currency || 'YER',
                    formatAmountWithCommas(x.total || 0), x.status || '-'];
        });
        columns = ['رقم الفاتورة', 'التاريخ', 'المورد', 'النوع', 'العملة', 'الإجمالي', 'الحالة'];
        summary = 'الإجمالي: ' + _reportMoneyByCurrency(source, 'total');
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 3. المصاريف ============
    if (type === 'expenses') {
        source = _reportArray('expenses').filter(function(x) { return _reportIsActive(x) && !x.archived && _reportDateOk(x, from, to); });
        source.sort(function(a, b) { return String(b.date).localeCompare(String(a.date)); });
        rows = source.map(function(x) {
            return [x.id || '-', x.date, x.type || '-', x.recipient || '-', x.currency || 'YER',
                    formatAmountWithCommas(x.amount || 0), x.note || '-'];
        });
        columns = ['#', 'التاريخ', 'النوع', 'المستلم', 'العملة', 'المبلغ', 'الملاحظة'];
        summary = 'الإجمالي: ' + _reportMoneyByCurrency(source, 'amount');
        return { columns: columns, rows: rows, summary: summary };
    }
       // ============ 2-أ. المبيعات والمردودات ============
if (type === 'sales_with_returns') {
    var baseC1 = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    
    var _conv1 = function(amt, cur, rate) {
        var n = parseFloat(amt) || 0;
        if (!cur || cur === baseC1) return n;
        if (rate && typeof getEquivalentAtRate === 'function') 
            return getEquivalentAtRate(n, cur, rate);
        if (typeof getEquivalent === 'function') 
            return getEquivalent(n, cur);
        return n;
    };
    
    source = _reportArray('salesInvoices').filter(function(x) {
    return _reportIsActive(x) && _reportDateOk(x, from, to);
});
    source.sort(function(a, b) { return String(b.date).localeCompare(String(a.date)); });
    
    var returnsSale = _reportArray('returnsDocs');
    var tGross1 = 0, tRet1 = 0, tNet1 = 0;
    
    rows = source.map(function(x) {
        var invReturns = returnsSale.filter(function(r) {
            return _reportIsActive(r) && r.kind === 'sale' && r.invoiceId === x.id;
        });
        var returnsTotal = invReturns.reduce(function(s, r) {
            return s + _conv1(r.amount, r.currency, r.exchangeRate);
        }, 0);
        
        var grossBase = _conv1(x.total, x.currency, x.exchangeRate);
        var netBase = grossBase - returnsTotal;
        
        tGross1 += grossBase;
        tRet1 += returnsTotal;
        tNet1 += netBase;
        
        return [
            x.id,
            x.date,
            x.customerName || '-',
            formatAmountWithCommas(grossBase),
            returnsTotal > 0 ? '− ' + formatAmountWithCommas(returnsTotal) : '—',
            formatAmountWithCommas(netBase),
            x.status || '-'
        ];
    });
    
    columns = ['رقم الفاتورة', 'التاريخ', 'العميل',
               'إجمالي (' + baseC1 + ')', 'مردودات (' + baseC1 + ')',
               'صافي (' + baseC1 + ')', 'الحالة'];
    summary = 'إجمالي: ' + formatAmountWithCommas(tGross1) +
              ' | مردودات: ' + formatAmountWithCommas(tRet1) +
              ' | صافي: ' + formatAmountWithCommas(tNet1) + ' ' + baseC1;
    return { columns: columns, rows: rows, summary: summary };
}

// ============ 2-ب. المشتريات والمردودات ============
if (type === 'purchases_with_returns') {
    var baseC2 = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    
    var _conv2 = function(amt, cur, rate) {
        var n = parseFloat(amt) || 0;
        if (!cur || cur === baseC2) return n;
        if (rate && typeof getEquivalentAtRate === 'function') 
            return getEquivalentAtRate(n, cur, rate);
        if (typeof getEquivalent === 'function') 
            return getEquivalent(n, cur);
        return n;
    };
    
    source = _reportArray('purchaseInvoices').filter(function(x) {
    return _reportIsActive(x) && _reportDateOk(x, from, to);
});
    source.sort(function(a, b) { return String(b.date).localeCompare(String(a.date)); });
    
    var returnsPurch = _reportArray('returnsDocs');
    var tGross2 = 0, tRet2 = 0, tNet2 = 0;
    
    rows = source.map(function(x) {
        var invReturns = returnsPurch.filter(function(r) {
            return _reportIsActive(r) && r.kind === 'purchase' && r.invoiceId === x.id;
        });
        var returnsTotal = invReturns.reduce(function(s, r) {
            return s + _conv2(r.amount, r.currency, r.exchangeRate);
        }, 0);
        
        var grossBase = _conv2(x.total, x.currency, x.exchangeRate);
        var netBase = grossBase - returnsTotal;
        
        tGross2 += grossBase;
        tRet2 += returnsTotal;
        tNet2 += netBase;
        
        return [
            x.id,
            x.date,
            x.supplierName || '-',
            formatAmountWithCommas(grossBase),
            returnsTotal > 0 ? '− ' + formatAmountWithCommas(returnsTotal) : '—',
            formatAmountWithCommas(netBase),
            x.status || '-'
        ];
    });
    
    columns = ['رقم الفاتورة', 'التاريخ', 'المورد',
               'إجمالي (' + baseC2 + ')', 'مردودات (' + baseC2 + ')',
               'صافي (' + baseC2 + ')', 'الحالة'];
    summary = 'إجمالي: ' + formatAmountWithCommas(tGross2) +
              ' | مردودات: ' + formatAmountWithCommas(tRet2) +
              ' | صافي: ' + formatAmountWithCommas(tNet2) + ' ' + baseC2;
    return { columns: columns, rows: rows, summary: summary };
}

    // ============ 4. السندات ============
    if (type === 'vouchers') {
        var rec = _reportArray('receipts').filter(function(x) { return _reportIsActive(x) && _reportDateOk(x, from, to); });
        var pay = _reportArray('payments').filter(function(x) { return _reportIsActive(x) && !x.archived && _reportDateOk(x, from, to); });

        var recRows = rec.map(function(x) {
            return [x.id, x.date, x.receiptType === 'supplier_refund' ? 'تحصيل من مورد' : 'قبض', x.customerName || x.supplierName || '-', x.currency || 'YER',
                    formatAmountWithCommas(x.amount || 0), x.method || '-'];
        });
        var payRows = pay.map(function(x) {
            return [x.id, x.date, x.paymentType === 'customer_refund' ? 'رد مبلغ لعميل' : (x.isExpense ? 'مصروف' : 'صرف'), x.supplierName || x.customerName || '-', x.currency || 'YER',
                    formatAmountWithCommas(x.amount || 0), x.method || '-'];
        });

        rows = recRows.concat(payRows).sort(function(a, b) {
            return String(b[1]).localeCompare(String(a[1]));
        });
        columns = ['رقم السند', 'التاريخ', 'النوع', 'الطرف', 'العملة', 'المبلغ', 'الطريقة'];
        summary = 'قبض: ' + _reportMoneyByCurrency(rec, 'amount') + ' — صرف: ' + _reportMoneyByCurrency(pay, 'amount');
        return { columns: columns, rows: rows, summary: summary };
    }

// ============ 5. جرد المخزون ============
 if (type === 'inventory') {
     source = _reportArray('products');
     var baseCurInv = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

     rows = source.map(function(x) {
         var qty = parseFloat(x.quantity) || 0;
         var typeLabel = x.type === 'finished' ? 'منتج تام' : 'مادة خام';
         var cost = parseFloat(x.avgCost);
         if (!isFinite(cost) || cost < 0) cost = parseFloat(x.purchasePrice);
         if (!isFinite(cost) || cost < 0) cost = 0;
         var salePrice = parseFloat(x.price) || 0;

         var productCur = x.currency || baseCurInv;
var costCur = x.costCurrency || productCur;

// ✅ تحويل التكلفة إلى عملة المنتج
var costInProductCur = cost;
if (cost > 0 && costCur !== productCur) {
    // التكلفة مُخزّنة بـ costCur (SAR) → نحوّلها لعملة المنتج
    if (typeof getEquivalent === 'function') {
        var baseRate = (typeof getRate === 'function') ? getRate(baseCurInv) : 1;
        var prodRate = (typeof getRate === 'function') ? getRate(productCur) : 1;
        costInProductCur = cost * baseRate / (prodRate || 1);
    }
}

var costDisplay = costInProductCur > 0
    ? formatAmountWithCommas(costInProductCur)
    : '⚠ غير محدّدة';

var value = costInProductCur > 0 ? qty * costInProductCur : 0;
var valueDisplay = costInProductCur > 0
    ? formatAmountWithCommas(value)
    : '—';

// ✅ القيمة بالعملة الأساسية
var valueBase = (typeof getProductCostValueBase === 'function')
    ? getProductCostValueBase(x)
    : 0;
var valueBaseDisplay = valueBase > 0
    ? formatAmountWithCommas(valueBase) + ' ' + baseCurInv
    : '—';

return [
    x.name,
    typeLabel,
    qty + ' ' + (x.baseUnit || x.unit || 'وحدة'),
    productCur,
    formatAmountWithCommas(salePrice),
    costDisplay,
    valueDisplay,
    valueBaseDisplay
];
     });

     columns = ['المنتج', 'النوع', 'الكمية', 'العملة', 'سعر البيع', 'التكلفة', 'القيمة', 'القيمة (' + baseCurInv + ')'];
     summary = 'عدد المنتجات: ' + source.length;
     return { columns: columns, rows: rows, summary: summary };
 }

    // ============ 7. أداء العملاء ============
    if (type === 'customers_perf') {
        var customersList = _reportArray('customers');
        rows = customersList.map(function(c) {
            var invs = _reportArray('salesInvoices').filter(function(i) {
              return _reportIsActive(i) && i.customerId === c.id && _reportDateOk(i, from, to);
    });
            var totalSales = 0;
            invs.forEach(function(i) { totalSales += parseFloat(i.total) || 0; });

            var lastDate = '-';
            if (invs.length) {
                var dates = invs.map(function(i) { return i.date; }).sort();
                lastDate = dates[dates.length - 1];
            }

            var balances = _reportCustomerBalance(c.id);

            return [c.name, invs.length, formatAmountWithCommas(totalSales), lastDate,
                    _formatBalancesObj(balances), c.phone || '-'];
        });
        columns = ['العميل', 'عدد الفواتير', 'إجمالي المبيعات', 'آخر تعامل', 'الرصيد', 'الهاتف'];
        summary = 'عدد العملاء: ' + customersList.length;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 8. أداء الموردين ============
    if (type === 'suppliers_perf') {
        var suppliersList = _reportArray('suppliers');
        rows = suppliersList.map(function(s) {
            var invs = _reportArray('purchaseInvoices').filter(function(i) {
                return _reportIsActive(i) && i.supplierId === s.id && _reportDateOk(i, from, to);
            });
            var totalPurchases = 0;
            invs.forEach(function(i) { totalPurchases += parseFloat(i.total) || 0; });

            var lastDate = '-';
            if (invs.length) {
                var dates = invs.map(function(i) { return i.date; }).sort();
                lastDate = dates[dates.length - 1];
            }

            var balances = _reportSupplierBalance(s.id);

            return [s.name, invs.length, formatAmountWithCommas(totalPurchases), lastDate,
                    _formatBalancesObj(balances), s.phone || '-'];
        });
        columns = ['المورد', 'عدد الفواتير', 'إجمالي المشتريات', 'آخر تعامل', 'الرصيد', 'الهاتف'];
        summary = 'عدد الموردين: ' + suppliersList.length;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 9. أداء المنتجات ============
    if (type === 'products_perf') {
        var productsList = _reportArray('products');
        var salesMap = {};

        _reportArray('salesInvoices').forEach(function(inv) {
            if (!_reportIsActive(inv)) return;
if (!_reportDateOk(inv, from, to)) return;
            (inv.items || []).forEach(function(item) {
                if (!item.productId) return;
                if (!salesMap[item.productId]) salesMap[item.productId] = { qty: 0, revenue: 0, cogs: 0 };
                salesMap[item.productId].qty += parseFloat(item.qty) || 0;
                salesMap[item.productId].revenue += (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
            });
        });

        rows = productsList.map(function(p) {
            var sales = salesMap[p.id] || { qty: 0, revenue: 0 };
            var cost = parseFloat(p.avgCost);
            var cogs = isFinite(cost) && cost > 0 ? cost * sales.qty : 0;
            var profit = sales.revenue - cogs;

            var stockStatus = '—';
            var qty = parseFloat(p.quantity) || 0;
            if (qty === 0) stockStatus = 'نافذ';
            else if (qty < 5) stockStatus = 'منخفض';
            else stockStatus = 'متوفر';

            return [p.name, p.type === 'finished' ? 'منتج تام' : 'مادة خام',
                    sales.qty, formatAmountWithCommas(sales.revenue),
                    formatAmountWithCommas(cogs), formatAmountWithCommas(profit), stockStatus];
        });
        columns = ['المنتج', 'النوع', 'الكمية المباعة', 'الإيرادات', 'COGS', 'الربح', 'المخزون'];
        summary = 'عدد المنتجات: ' + productsList.length;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 10. أرصدة العملاء ============
    if (type === 'customers_balance') {
        var customersList2 = _reportArray('customers');
        rows = customersList2.map(function(c) {
            var balances = _reportCustomerBalance(c.id);
            var hasBalance = Object.keys(balances).some(function(k) { return Math.abs(balances[k]) > 0.001; });
            return [c.name, c.phone || '-', c.address || '-', hasBalance ? _formatBalancesObj(balances) : '0.00'];
        });
        columns = ['العميل', 'الهاتف', 'العنوان', 'الرصيد'];
        summary = 'عدد العملاء: ' + customersList2.length;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 11. أرصدة الموردين ============
    if (type === 'suppliers_balance') {
        var suppliersList2 = _reportArray('suppliers');
        rows = suppliersList2.map(function(s) {
            var balances = _reportSupplierBalance(s.id);
            var hasBalance = Object.keys(balances).some(function(k) { return Math.abs(balances[k]) > 0.001; });
            return [s.name, s.phone || '-', s.address || '-', hasBalance ? _formatBalancesObj(balances) : '0.00'];
        });
        columns = ['المورد', 'الهاتف', 'العنوان', 'الرصيد'];
        summary = 'عدد الموردين: ' + suppliersList2.length;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 12. التحويلات ============
    if (type === 'transfers') {
        source = _reportArray('transfers').filter(function(x) { return _reportDateOk(x, from, to); });
        source.sort(function(a, b) { return String(b.date).localeCompare(String(a.date)); });
        rows = source.map(function(x) {
            var fromLabel = x.from && x.from.accountType === 'cashbox' ? 'الصندوق' : 'البنك';
            var toLabel = x.to && x.to.accountType === 'cashbox' ? 'الصندوق' : 'البنك';
            return [x.number || x.id, x.date, fromLabel, toLabel,
                    (x.from && x.from.currency) || '-', formatAmountWithCommas((x.from && x.from.amount) || 0),
                    (x.to && x.to.currency) || '-', formatAmountWithCommas((x.to && x.to.amount) || 0)];
        });
        columns = ['رقم التحويل', 'التاريخ', 'من', 'إلى', 'عملة المصدر', 'المبلغ', 'عملة الوجهة', 'المستلم'];
        summary = 'عدد التحويلات: ' + source.length;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 13. الأرباح والخسائر ============
    if (type === 'profitloss') {
        var data = typeof calculateProfitLoss === 'function' ? calculateProfitLoss(from, to) : null;
        if (!data) {
            return { columns: ['البيان', 'القيمة'], rows: [], summary: 'خطأ في الحساب' };
        }
        var baseC = getBaseCurrency();
        rows = [
            ['المبيعات', formatCurrency(data.salesTotal, baseC)],
            ['المشتريات', formatCurrency(data.purchasesTotal, baseC)],
            ['تكلفة البضاعة المباعة (COGS)', data.cogsKnown ? formatCurrency(data.cogsTotal, baseC) : 'غير مكتمل'],
            ['مجمل الربح', data.grossProfit === null ? 'غير مكتمل' : formatCurrency(data.grossProfit, baseC)],
            ['المصاريف', formatCurrency(data.expensesTotal, baseC)],
            ['صافي الربح المحاسبي', data.netProfit === null ? 'غير مكتمل' : formatCurrency(data.netProfit, baseC)],
            ['---', '---'],
            ['سندات القبض', formatCurrency(data.receiptsTotal, baseC)],
            ['سندات الصرف', formatCurrency(data.paymentsTotal, baseC)],
            ['صافي التدفق النقدي', formatCurrency(data.cashFlow, baseC)],
            ['---', '---'],
            ['لك عند العملاء', formatCurrency(data.receivables, baseC)],
            ['عليك للموردين', formatCurrency(data.payables, baseC)]
        ];
        columns = ['البيان', 'القيمة'];
        summary = 'الفترة: ' + (from || 'البداية') + ' إلى ' + (to || 'اليوم') + ' — العملة: ' + baseC;
        return { columns: columns, rows: rows, summary: summary };
    }

    // ============ 14. التدفق النقدي ============
    if (type === 'cash_flow') {
        var baseCur = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
        var convert = function(amount, currency, rate) {
            var n = parseFloat(amount) || 0;
            if (!currency || currency === baseCur) return n;
            if (rate && typeof getEquivalentAtRate === 'function') return getEquivalentAtRate(n, currency, rate);
            if (typeof getEquivalent === 'function') return getEquivalent(n, currency);
            return n;
        };

        var inGroups = {
            'رأس المال / تمويل': 0,
            'مبيعات نقدية': 0,
            'تحصيل من عملاء': 0,
            'إيداعات بنكية': 0,
            'إيرادات أخرى': 0,
            'تحصيل من موردين': 0
        };
        var outGroups = {
            'مشتريات نقدية': 0,
            'سداد لموردين': 0,
            'مصاريف': 0,
            'سحوبات مباشرة': 0,
            'رد مبالغ للعملاء': 0
        };

        // 1. الحركات المباشرة
        if (typeof directTransactions !== 'undefined' && Array.isArray(directTransactions)) {
            directTransactions.forEach(function(t) {
                if (!_reportIsActive(t)) return;
if (!_reportDateOk(t, from, to)) return;
                var amt = convert(t.amount, t.currency, t.exchangeRate);
                if (t.direction === 'in') {
                    if (t.type === 'بيع مستهلكات / خردة' || t.type === 'إيرادات متنوعة') {
                        inGroups['إيرادات أخرى'] += amt;
                    } else {
                        inGroups['رأس المال / تمويل'] += amt;
                    }
                } else {
                    outGroups['سحوبات مباشرة'] += amt;
                }
            });
        }

        // 2. المبيعات النقدية
        if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
            salesInvoices.forEach(function(inv) {
    if (!_reportIsActive(inv)) return;
    if (inv.type !== 'نقدي') return;
    if (!_reportDateOk(inv, from, to)) return;
    inGroups['مبيعات نقدية'] += convert(inv.total, inv.currency, inv.exchangeRate);
});
        }

        // 3. المشتريات النقدية
        if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
            purchaseInvoices.forEach(function(inv) {
    if (!_reportIsActive(inv)) return;
    if (inv.type !== 'نقدي') return;
    if (!_reportDateOk(inv, from, to)) return;
    outGroups['مشتريات نقدية'] += convert(inv.total, inv.currency, inv.exchangeRate);
});
        }

        // 4. سندات القبض
        if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
            receipts.forEach(function(r) {
    if (!_reportIsActive(r)) return;
    if (!_reportDateOk(r, from, to)) return;
    
    // استبعاد السند التلقائي لفاتورة بيع نقدية (لتجنّب الازدواج)
    if (r.invoiceId && r.invoiceId !== '-') {
        var linkedSale = (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices))
            ? salesInvoices.find(function(inv) { return inv.id === r.invoiceId; })
            : null;
        if (linkedSale && linkedSale.type === 'نقدي') {
            return; // ← السند تلقائي، يُحتسب في "مبيعات نقدية"
        }
    }
    
    var m = r.method || 'نقدي';
    var amt = convert(r.amount, r.currency, r.exchangeRate);
    if (r.receiptType === 'supplier_refund') { inGroups['تحصيل من موردين'] += amt; return; }
    if (m === 'تحويل بنكي' || m === 'بطاقة') {
        inGroups['إيداعات بنكية'] += amt;
    } else {
        inGroups['تحصيل من عملاء'] += amt;
    }
    });
  }

        // 5. سندات الصرف (استثناء المصاريف)
     // 5. سندات الصرف (استثناء المصاريف + السندات التلقائية للفواتير النقدية)
if (typeof payments !== 'undefined' && Array.isArray(payments)) {
    payments.forEach(function(p) {
    if (!_reportIsActive(p)) return;
    if (p.archived) return;
    if (!_reportDateOk(p, from, to)) return;
    if (p.isExpense) return;
        var pAmt = convert(p.amount, p.currency, p.exchangeRate);
        if (p.paymentType === 'customer_refund') { outGroups['رد مبالغ للعملاء'] += pAmt; return; }

        // تجاهل السندات التلقائية للفواتير النقدية (لتجنّب الازدواج)
        if (p.invoiceId && p.invoiceId !== '-') {
            var linkedInv = (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices))
                ? purchaseInvoices.find(function(inv) { return inv.id === p.invoiceId; })
                : null;
            if (linkedInv && linkedInv.type === 'نقدي') {
                return; // ← السند تلقائي، يُحتسب في "مشتريات نقدية"
            }
        }

        outGroups['سداد لموردين'] += pAmt;
    });
}

        // 6. المصاريف
        if (typeof expenses !== 'undefined' && Array.isArray(expenses)) {
            expenses.forEach(function(e) {
    if (!_reportIsActive(e)) return;
    if (e.archived) return;
    if (!_reportDateOk(e, from, to)) return;
    outGroups['مصاريف'] += convert(e.amount, e.currency, e.exchangeRate);
});
        }

        // بناء الصفوف
        var rowsArray = [];
        var totalIn = 0;
        var totalOut = 0;

        Object.keys(inGroups).forEach(function(k) {
            if (inGroups[k] > 0) {
                rowsArray.push(['📥 ' + k, '+ ' + formatAmountWithCommas(inGroups[k]) + ' ' + baseCur]);
                totalIn += inGroups[k];
            }
        });

        if (totalIn > 0) {
            rowsArray.push(['إجمالي الوارد', '+ ' + formatAmountWithCommas(totalIn) + ' ' + baseCur]);
            rowsArray.push(['---', '---']);
        }

        Object.keys(outGroups).forEach(function(k) {
            if (outGroups[k] > 0) {
                rowsArray.push(['📤 ' + k, '− ' + formatAmountWithCommas(outGroups[k]) + ' ' + baseCur]);
                totalOut += outGroups[k];
            }
        });

        if (totalOut > 0) {
            rowsArray.push(['إجمالي الصادر', '− ' + formatAmountWithCommas(totalOut) + ' ' + baseCur]);
            rowsArray.push(['---', '---']);
        }

        var netFlow = totalIn - totalOut;
        rowsArray.push(['💰 صافي التدفق النقدي', (netFlow >= 0 ? '+ ' : '− ') + formatAmountWithCommas(Math.abs(netFlow)) + ' ' + baseCur]);

        columns = ['البيان', 'المبلغ'];
        summary = 'الفترة: ' + (from || 'البداية') + ' إلى ' + (to || 'اليوم') +
                  ' | الوارد: ' + formatAmountWithCommas(totalIn) + ' | الصادر: ' + formatAmountWithCommas(totalOut) +
                  ' | الصافي: ' + formatAmountWithCommas(netFlow) + ' ' + baseCur;
        return { columns: columns, rows: rowsArray, summary: summary };
    }

    return { columns: ['البيان', 'القيمة'], rows: [['لا يوجد تقرير بهذا النوع', '-']], summary: '' };
}


// ================================================================
// ===== 4. عرض الشاشة =====
// ================================================================

function renderReports() {
    var section = document.getElementById('section-reports');
    if (!section) return;

    var ws = document.getElementById('reportWorkspace');
    if (!ws) {
        var placeholder = section.querySelector('.placeholder-box');
        if (placeholder) {
            placeholder.outerHTML = '<div id="reportWorkspace"></div>';
        }
    }

    ws = document.getElementById('reportWorkspace');
    if (!ws) return;

    ws.innerHTML =
        '<div class="report-controls" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;direction:rtl;padding:16px;background:#fff;border-radius:10px;margin-bottom:14px;">' +
            '<div class="form-field" style="flex:1 1 200px;min-width:180px;margin:0;">' +
                '<label>نوع التقرير</label>' +
                '<select id="reportType" style="width:100%;min-height:42px;">' +
                     '<optgroup label="العمليات">' +
       '<option value="sales">المبيعات</option>' +
        '<option value="sales_with_returns">المبيعات والمردودات</option>' +
         '<option value="purchases">المشتريات</option>' +
          '<option value="purchases_with_returns">المشتريات والمردودات</option>' +
           '<option value="expenses">المصاريف</option>' +
            '<option value="vouchers">السندات</option>' +
                   '</optgroup>' +
                    '<optgroup label="المخزون">' +
                        '<option value="inventory">جرد المخزون</option>' +
                        '<option value="movements">حركات المخزون</option>' +
                    '</optgroup>' +
                    '<optgroup label="الأداء">' +
                        '<option value="customers_perf">أداء العملاء</option>' +
                        '<option value="suppliers_perf">أداء الموردين</option>' +
                        '<option value="products_perf">أداء المنتجات</option>' +
                    '</optgroup>' +
                    '<optgroup label="الأرصدة">' +
                        '<option value="customers_balance">أرصدة العملاء</option>' +
                        '<option value="suppliers_balance">أرصدة الموردين</option>' +
                    '</optgroup>' +
                    '<optgroup label="المالية">' +
                        '<option value="transfers">التحويلات</option>' +
                        '<option value="profitloss">الأرباح والخسائر</option>' +
                        '<option value="cash_flow">التدفق النقدي</option>' +
                    '</optgroup>' +
                '</select>' +
            '</div>' +
            '<div class="form-field" style="flex:1 1 150px;min-width:130px;margin:0;">' +
                '<label>من تاريخ</label>' +
                '<input type="date" id="reportFrom" style="width:100%;min-height:42px;">' +
            '</div>' +
            '<div class="form-field" style="flex:1 1 150px;min-width:130px;margin:0;">' +
                '<label>إلى تاريخ</label>' +
                '<input type="date" id="reportTo" style="width:100%;min-height:42px;">' +
            '</div>' +
            '<button class="btn btn-primary" style="min-height:42px;" onclick="runCurrentReport()">عرض</button>' +
        '</div>' +
        '<div id="reportSummary" class="report-summary" style="padding:10px 14px;background:rgba(31,111,235,0.08);border-radius:8px;margin-bottom:12px;font-weight:700;color:var(--color-text-2);text-align:right;"></div>' +
        '<div class="table-container">' +
            '<table id="reportTable" class="data-table">' +
                '<thead></thead>' +
                '<tbody></tbody>' +
            '</table>' +
        '</div>';

    var typeEl = document.getElementById('reportType');
    typeEl.value = currentReportType;
    typeEl.addEventListener('change', runCurrentReport);

    var fromEl = document.getElementById('reportFrom');
    var toEl = document.getElementById('reportTo');
    if (fromEl && !fromEl.value) fromEl.value = firstDayOfMonthISO();
    if (toEl && !toEl.value) toEl.value = todayISO();
    fromEl.addEventListener('change', runCurrentReport);
    toEl.addEventListener('change', runCurrentReport);

    runCurrentReport();
}


// ================================================================
// ===== 5. تشغيل التقرير الحالي =====
// ================================================================

function runCurrentReport() {
    var typeEl = document.getElementById('reportType');
    if (!typeEl) return;

    currentReportType = typeEl.value;

    var from = (document.getElementById('reportFrom') || {}).value || '';
    var to = (document.getElementById('reportTo') || {}).value || '';

    var result = _reportRows(currentReportType, from, to);
    var table = document.getElementById('reportTable');
    if (!table) return;

    table.querySelector('thead').innerHTML = '<tr>' +
        result.columns.map(function(x) { return '<th>' + esc(x) + '</th>'; }).join('') + '</tr>';

    if (!result.rows.length) {
        table.querySelector('tbody').innerHTML = '<tr><td colspan="' + result.columns.length + '" class="empty-cell">لا توجد بيانات في الفترة المحددة</td></tr>';
    } else {
        table.querySelector('tbody').innerHTML = result.rows.map(function(row) {
            return '<tr>' + row.map(function(x) { return '<td>' + esc(String(x)) + '</td>'; }).join('') + '</tr>';
        }).join('');
    }

    setText('reportSummary', result.summary || '');
}


// ================================================================
// ===== 6. تصدير التقرير إلى PDF =====
// ================================================================

function exportCurrentReportPDF() {
    runCurrentReport();

    var from = (document.getElementById('reportFrom') || {}).value || '';
    var to = (document.getElementById('reportTo') || {}).value || '';

    var table = document.getElementById('reportTable');
    if (!table) return showToast('لم يتم العثور على جدول التقرير', 'error');

    var title = _reportTypeTitle(currentReportType);
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';

    var summaryEl = document.getElementById('reportSummary');
    var summary = summaryEl ? summaryEl.textContent : '';

    var html =
        '<div class="doc-wrapper">' +
            '<div class="doc-header">' +
                '<div class="company-name">' + esc(companyName) + '</div>' +
                '<div class="doc-title">' + esc(title) + '</div>' +
            '</div>' +
            '<div class="doc-meta-grid">' +
                '<div><strong>الفترة من:</strong> ' + esc(from || 'البداية') + '</div>' +
                '<div><strong>الفترة إلى:</strong> ' + esc(to || 'اليوم') + '</div>' +
                '<div><strong>تاريخ الإصدار:</strong> ' + esc(todayISO()) + '</div>' +
            '</div>' +
            table.outerHTML +
            (summary ? '<div class="doc-footer"><strong>' + esc(summary) + '</strong></div>' : '') +
        '</div>';

    Modal.open({
        id: 'reportPrintModal',
        title: 'معاينة ' + title,
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'reportPrintModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
    });
}


// ================================================================
// ===== 7. تهيئة =====
// ================================================================
// ================================================================
// ===== 9. طباعة تقرير التدفق النقدي (القالب الجديد) =====
// ================================================================

function printCashFlow() {
    // 1. اقرأ الفلاتر من قسم التقارير
    var fromEl = document.getElementById('reportFrom');
    var toEl = document.getElementById('reportTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    // 2. ابنِ بيانات التقرير
    var result = _reportRows('cash_flow', from, to);
    if (!result || !result.rows || !result.rows.length) {
        if (typeof showToast === 'function') showToast('لا توجد بيانات في الفترة المحددة', 'error');
        return;
    }

    // 3. العملة الأساسية
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

    // 4. استخرج صافي التدفق
    var netFlow = 0;
    var netFlowFormatted = '0.00';
    result.rows.forEach(function(row) {
        var label = String(row[0] || '');
        if (label.indexOf('صافي التدفق') !== -1) {
            var val = String(row[1] || '');
            // استخرج الرقم
            var cleaned = val.replace(/[^0-9.\-]/g, '');
            netFlow = parseFloat(cleaned) || 0;
            // احذف الإشارات
            cleaned = val.replace(/[^0-9.]/g, '');
            var parts = cleaned.split('.');
            if (parts[0]) {
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
            netFlowFormatted = parts.join('.');
        }
    });

    // 5. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 6. الحمولة
    var payload = {
        type: 'cashflow_report',
        rows: result.rows,
        settings: settings,
        meta: {
            from: from || 'البداية',
            to: to || 'اليوم',
            currency: baseCurrency,
            netFlow: netFlow,
            netFlowFormatted: netFlowFormatted
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 7. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/cashflow-report.html';
    window.location.href = url;
}



// ================================================================
// ===== END OF REPORTS.JS =====
// ================================================================