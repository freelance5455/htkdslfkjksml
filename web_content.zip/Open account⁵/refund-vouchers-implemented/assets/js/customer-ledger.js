// ================================================================
// Open Account — نظام محاسبي
// الملف: customer-ledger.js
// الوصف: كشف حساب العملاء
// النسخة: v2 — مع الرصيد التراكمي
// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var _clCurrentCustomer = '';
var _clCurrentCurrency = 'YER';


// ================================================================
// ===== 2. جمع حركات العميل =====
// ================================================================

function getCustomerTransactions(customerId, currency, from, to) {
    var transactions = [];

    // ===== 1. فواتير البيع (مدين — لك عنده) =====
    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
        salesInvoices.forEach(function(inv) {
            if (inv.customerId !== customerId) return;
            var c = inv.currency || 'YER';
            if (c !== currency) return;
            if (from && inv.date < from) return;
            if (to && inv.date > to) return;

            transactions.push({
                date: inv.date,
                type: 'invoice',
                desc: 'فاتورة بيع — ' + inv.id,
                debit: parseFloat(inv.total) || 0,
                credit: 0
            });
        });
    }

    // ===== 1-b. عكس الفواتير الملغاة (دائن للعميل) =====
    salesInvoices.forEach(function(inv) {
        if (!(inv.status === 'ملغاة' || inv.cancelled) || inv.customerId !== customerId) return;
        var c = inv.currency || 'YER';
        if (c !== currency) return;
        var d = inv.cancelledAt ? inv.cancelledAt.slice(0,10) : inv.date;
        if (from && d < from) return;
        if (to && d > to) return;
        transactions.push({date:d,type:'cancellation',desc:'إلغاء فاتورة بيع — '+inv.id,debit:0,credit:parseFloat(inv.total)||0});
    });

    // ===== 2. مردودات المبيعات (دائن للعميل في الفاتورة الآجلة) =====
   // ===== 2. مردودات المبيعات (دائن للعميل — نقدي أو آجل) =====
// القاعدة: سند القبض لا يُلغى عند المرتجع → الرصيد السالب يظهر كرصيد دائن
if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
    returnsDocs.forEach(function(ret) {
        if (ret.kind !== 'sale' || !ret.invoiceId) return;
        if (typeof _reportIsActive === 'function' && !_reportIsActive(ret)) return;
        var inv = (typeof salesInvoices !== 'undefined') ? salesInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null;
        if (!inv || inv.customerId !== customerId) return;
        var c = ret.currency || inv.currency || 'YER';
        if (c !== currency) return;
        if (from && ret.date < from) return;
        if (to && ret.date > to) return;
        transactions.push({
            date: ret.date,
            type: 'return',
            desc: 'مرتجع مبيعات — ' + ret.invoiceId,
            debit: 0,
            credit: parseFloat(ret.amount) || 0
        });
    });
}

    // ===== 3. سندات القبض (دائن — سدد) =====
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
            if (r.customerId !== customerId) return;
            if (r.cancelled || r.documentStatus === 'cancelled') return;
            var c = r.currency || 'YER';
            if (c !== currency) return;
            if (from && r.date < from) return;
            if (to && r.date > to) return;

            transactions.push({
                date: r.date,
                type: 'receipt',
                desc: 'سند قبض — ' + (r.method || 'نقدي'),
                debit: 0,
                credit: parseFloat(r.amount) || 0
            });
        });
    }

    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.paymentType !== 'customer_refund' || p.customerId !== customerId) return;
            if (p.cancelled || p.documentStatus === 'cancelled') return;
            if ((p.currency || 'YER') !== currency) return;
            if (from && p.date < from) return; if (to && p.date > to) return;
            transactions.push({date:p.date,type:'customer_refund',desc:'رد مبلغ للعميل — '+(p.sourceReceiptId || p.id),debit:parseFloat(p.amount)||0,credit:0});
        });
    }

    transactions.sort(function(a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
    });

    return transactions;
}


// ================================================================
// ===== 3. حساب الرصيد الافتتاحي =====
// ================================================================

function getCustomerOpeningBalance(customerId, currency, from) {
    if (!from) return 0;

    var opening = 0;

    // دورة مغلقة (رصيد مرحّل)
    var cycleOpening = typeof Storage !== 'undefined' ? Storage.get('oa_cycle_opening_balances', null) : null;
    if (cycleOpening && cycleOpening.customers && cycleOpening.customers[customerId] && cycleOpening.customers[customerId].currencies) {
        opening += parseFloat(cycleOpening.customers[customerId].currencies[currency]) || 0;
    }

    // فواتير البيع قبل from
    if (typeof salesInvoices !== 'undefined') {
        salesInvoices.forEach(function(inv) {
            if (inv.customerId !== customerId) return;
            if ((inv.currency || 'YER') !== currency) return;
            if (inv.date >= from) return;
            opening += parseFloat(inv.total) || 0;
        });
    }

    // عكس الفواتير الملغاة قبل from
    salesInvoices.forEach(function(inv) {
        if (!(inv.status === 'ملغاة' || inv.cancelled) || inv.customerId !== customerId) return;
        if ((inv.currency || 'YER') !== currency) return;
        var d = inv.cancelledAt ? inv.cancelledAt.slice(0,10) : inv.date;
        if (d < from) opening -= parseFloat(inv.total) || 0;
    });

    // مردودات المبيعات قبل from (نقدي أو آجل)
if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
    returnsDocs.forEach(function(ret) {
        if (ret.kind !== 'sale') return;
        if (typeof _reportIsActive === 'function' && !_reportIsActive(ret)) return;
        var inv = (typeof salesInvoices !== 'undefined') ? salesInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null;
        if (!inv || inv.customerId !== customerId) return;
        if ((ret.currency || inv.currency || 'YER') !== currency) return;
        if (ret.date >= from) return;
        opening -= parseFloat(ret.amount) || 0;
    });
}

    // سندات القبض قبل from
    if (typeof receipts !== 'undefined') {
        receipts.forEach(function(r) {
            if (r.customerId !== customerId) return
            if (r.cancelled || r.documentStatus === 'cancelled') return;
            if ((r.currency || 'YER') !== currency) return;
            if (r.date >= from) return;
            opening -= parseFloat(r.amount) || 0;
        });
    }

    if (typeof payments !== 'undefined') payments.forEach(function(p) {
        if (p.paymentType !== 'customer_refund' || p.customerId !== customerId || p.cancelled || p.documentStatus === 'cancelled') return;
        if ((p.currency || 'YER') !== currency || p.date >= from) return;
        opening += parseFloat(p.amount) || 0;
    });

    return opening;
}


// ================================================================
// ===== 4. عملات العميل =====
// ================================================================

function getCustomerCurrencies(customerId) {
    var currencies = {};

    if (typeof salesInvoices !== 'undefined') {
        salesInvoices.forEach(function(inv) {
            if (inv.customerId !== customerId) return;
            var c = inv.currency || 'YER';
            currencies[c] = (currencies[c] || 0) + 1;
        });
    }

    if (typeof receipts !== 'undefined') {
        receipts.forEach(function(r) {
            if (r.customerId !== customerId) return;
            if (r.cancelled || r.documentStatus === 'cancelled') return;
            var c = r.currency || 'YER';
            currencies[c] = (currencies[c] || 0) + 1;
        });
    }

    return Object.keys(currencies);
}


// ================================================================
// ===== 5. عرض الشاشة =====
// ================================================================

function renderCustomerLedger() {
    var customerSelect = document.getElementById('clCustomer');
    var currencySelect = document.getElementById('clCurrency');
    var tbody = document.getElementById('clTableBody');

    if (!customerSelect || !tbody) return;

    // ملء قائمة العملاء
    if (!customerSelect.options.length || customerSelect.options.length <= 1) {
        var html = '<option value="">— اختر عميل —</option>';
        if (typeof customers !== 'undefined') {
            customers.forEach(function(c) {
                html += '<option value="' + c.id + '">' + esc(c.name) + '</option>';
            });
        }
        customerSelect.innerHTML = html;
    }

    var customerId = customerSelect.value;

    if (!customerId) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">اختر عميلاً لعرض الكشف</td></tr>';
        var summaryEl = document.getElementById('clSummary');
        if (summaryEl) summaryEl.innerHTML = '';
        return;
    }

    // ملء قائمة العملات
    var currencies = getCustomerCurrencies(customerId);
    if (!currencies.length) currencies = ['YER'];

    var curHtml = '';
    currencies.forEach(function(c) {
        curHtml += '<option value="' + c + '">' + c + '</option>';
    });
    currencySelect.innerHTML = curHtml;

    if (_clCurrentCurrency && currencies.indexOf(_clCurrentCurrency) !== -1) {
        currencySelect.value = _clCurrentCurrency;
    } else {
        _clCurrentCurrency = currencies[0];
        currencySelect.value = _clCurrentCurrency;
    }

    var currency = currencySelect.value;
    _clCurrentCustomer = customerId;

    var fromEl = document.getElementById('clFrom');
    var toEl = document.getElementById('clTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    var opening = getCustomerOpeningBalance(customerId, currency, from);
    var transactions = getCustomerTransactions(customerId, currency, from, to);

    var html2 = '';
    var balance = opening;
    var totalDebit = 0;
    var totalCredit = 0;

    // ===== صف رصيد أول المدة =====
    html2 += '<tr style="background:rgba(0,212,255,0.08);font-weight:bold;">' +
        '<td>—</td><td>—</td>' +
        '<td style="text-align:right;padding-right:12px;">رصيد أول المدة</td>' +
        '<td>—</td><td>—</td>' +
        '<td style="color:' + (balance > 0 ? 'var(--color-red)' : balance < 0 ? 'var(--color-green)' : 'var(--color-text)') + ';font-weight:700;">' +
            formatAmountWithCommas(opening) +
        '</td>' +
    '</tr>';

    // ===== الحركات =====
    transactions.forEach(function(t, i) {
        balance += t.debit - t.credit;
        totalDebit += t.debit;
        totalCredit += t.credit;

        var debitText = t.debit > 0 ? formatAmountWithCommas(t.debit) : '—';
        var creditText = t.credit > 0 ? formatAmountWithCommas(t.credit) : '—';

        var balanceColor = balance > 0 ? 'var(--color-red)' : balance < 0 ? 'var(--color-green)' : 'var(--color-text)';
        var balanceLabel = balance > 0 ? 'لك' : balance < 0 ? 'عليك' : '';

        html2 += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + formatDate(t.date) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(t.desc) + '</td>' +
            '<td style="color:var(--color-red);">' + debitText + '</td>' +
            '<td style="color:var(--color-green);">' + creditText + '</td>' +
            '<td style="font-weight:700;color:' + balanceColor + ';">' +
                formatAmountWithCommas(Math.abs(balance)) +
                (balanceLabel ? ' <small style="opacity:0.6;">(' + balanceLabel + ')</small>' : '') +
            '</td>' +
        '</tr>';
    });

    tbody.innerHTML = html2;

    // ===== الملخص =====
    var summary = document.getElementById('clSummary');
    if (summary) {
        var statusText = '';
if (balance > 0) {
    statusText = 'لك عند العميل: ' + formatAmountWithCommas(balance) + ' ' + currency;
} else if (balance < 0) {
    statusText = 'عليك للعميل: ' + formatAmountWithCommas(Math.abs(balance)) + ' ' + currency +
        ' <small style="color:var(--color-green);font-weight:600;">(مبلغ مستحق للعميل — رصيد دائن)</small>';
} else {
    statusText = 'الرصيد صفر — مطابق';
}

        summary.innerHTML =
            '<div class="info-boxes" style="grid-template-columns:1fr 1fr;">' +
                '<div class="info-box"><span>إجمالي المدين</span><strong>' + formatAmountWithCommas(totalDebit) + ' ' + currency + '</strong></div>' +
                '<div class="info-box"><span>إجمالي الدائن</span><strong>' + formatAmountWithCommas(totalCredit) + ' ' + currency + '</strong></div>' +
                '<div class="info-box" style="grid-column:span 2;"><span>الرصيد الختامي</span><strong>' + statusText + '</strong></div>' +
            '</div>';
    }

    var dateEl = document.getElementById('clDate');
    if (dateEl) dateEl.textContent = todayArabic();
}


// ================================================================
// ===== 6. الطباعة =====
// ================================================================

// ================================================================
// ===== 6. الطباعة (القالب الجديد) =====
// ================================================================

function printCustomerLedger() {
    var customerId = _clCurrentCustomer;
    if (!customerId) { showToast('اختر عميلاً أولاً', 'error'); return; }

    var customer = customers.find(function(c) { return c.id === customerId; });
    if (!customer) { showToast('العميل غير موجود', 'error'); return; }

    var currencySelect = document.getElementById('clCurrency');
    var currency = currencySelect ? currencySelect.value : 'YER';

    var fromEl = document.getElementById('clFrom');
    var toEl = document.getElementById('clTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    // ===== اقرأ الجدول من الصفحة =====
    var tbody = document.getElementById('clTableBody');
    if (!tbody) { showToast('الجدول غير موجود', 'error'); return; }
    var table = tbody.closest('table');
    if (!table) { showToast('الجدول غير موجود', 'error'); return; }

    var count = tbody.querySelectorAll('tr').length;

    // ===== اقرأ الإجماليات =====
    function getText(id) {
        var el = document.getElementById(id);
        return el ? el.textContent.trim() : '—';
    }

    var totalDebit = '—';
    var totalCredit = '—';
    var finalBalance = '—';
    try {
        var opening = getCustomerOpeningBalance(customerId, currency, from);
        var transactions = getCustomerTransactions(customerId, currency, from, to);
        var bal = opening;
        var tDebit = 0, tCredit = 0;
        transactions.forEach(function(t) {
            bal += t.debit - t.credit;
            tDebit += t.debit;
            tCredit += t.credit;
        });
        totalDebit = formatAmountWithCommas(tDebit) + ' ' + currency;
        totalCredit = formatAmountWithCommas(tCredit) + ' ' + currency;
        var absBal = Math.abs(bal);
        var label = bal > 0 ? 'لك عند العميل' : (bal < 0 ? 'عليك للعميل' : 'الرصيد صفر');
        finalBalance = formatAmountWithCommas(absBal) + ' ' + currency + ' (' + label + ')';
    } catch(e) { /* تجاهل */ }

    // ===== الإعدادات =====
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // ===== الحمولة =====
    var payload = {
        type: 'customer_ledger',
        tableHtml: table.outerHTML,
        settings: settings,
        meta: {
            customerName: customer.name || '—',
            currency: currency,
            from: from || 'البداية',
            to: to || 'اليوم',
            totalDebit: totalDebit,
            totalCredit: totalCredit,
            finalBalance: finalBalance,
            count: count
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // ===== افتح القالب =====
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/customer-ledger-report.html';
    window.location.href = url;
}


// ================================================================
// ===== 7. تهيئة =====
// ================================================================

function initCustomerLedger() {
    var customerSelect = document.getElementById('clCustomer');
    if (customerSelect) {
        customerSelect.addEventListener('change', function() {
            _clCurrentCurrency = '';
            renderCustomerLedger();
        });
    }

    var currencySelect = document.getElementById('clCurrency');
    if (currencySelect) {
        currencySelect.addEventListener('change', function() {
            _clCurrentCurrency = this.value;
            renderCustomerLedger();
        });
    }

    var refreshBtn = document.getElementById('clRefresh');
    if (refreshBtn) refreshBtn.addEventListener('click', renderCustomerLedger);

    var printBtn = document.getElementById('clPrint');
    if (printBtn) printBtn.addEventListener('click', printCustomerLedger);

    var fromEl = document.getElementById('clFrom');
    var toEl = document.getElementById('clTo');
    if (fromEl && !fromEl.value) fromEl.value = firstDayOfMonthISO();
    if (toEl && !toEl.value) toEl.value = todayISO();

    renderCustomerLedger();
    console.log('Customer Ledger: initialized');
}


// ================================================================
// ===== END OF CUSTOMER-LEDGER.JS =====
// ================================================================